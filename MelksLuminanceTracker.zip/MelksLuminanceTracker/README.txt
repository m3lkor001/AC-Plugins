MelksLuminanceTracker for Asheron's Call (InfiniteLeaftide) - luminance and coins per hour
============================================================

What's in here
--------------
  MelksLuminanceTracker\MelksLuminanceTracker.dll

You need first
--------------
  - Decal
  - UtilityBelt (the windows are drawn with UtilityBelt's window system - it has to be installed and on)

Install
-------
  1. Put this zip in your Decal Plugins folder (where your other plugins live, e.g. C:\Games\Decal Plugins)
     and "Extract here".
  2. Open Decal (the Decal Agent - its tray icon), click Add, and pick
        MelksLuminanceTracker\MelksLuminanceTracker.dll
     Make sure it's ticked (enabled).
  3. Start the game. Your settings are saved next to the dll the first time you change something.

Updating later
--------------
  Extract a newer zip over the top - your settings and logs aren't in the zip, so they're kept.
  Close the game first - it only loads at start-up.
