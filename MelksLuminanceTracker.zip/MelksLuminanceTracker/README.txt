MelksLuminanceTracker (Nov 2026) - luminance / bounty tracker.

Install
1. Unzip so this folder is  C:\Games\Decal Plugins\MelksLuminanceTracker\bin\Debug  (where Decal has it registered),
   or anywhere you like and add it there.
2. Decal Agent > Add > pick MelksLuminanceTracker.dll, and tick it. Needs UtilityBelt (UtilityBelt.Service).
3. MelksLuminanceTracker.dll is a loader for MelksLuminanceTrackerCore.dll.
