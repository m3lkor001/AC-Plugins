MelkTank Remote for Windows (ACGodot)
=====================================

Control and watch your ACGodot characters from an Android phone. The pieces:
  - ACGodot Launcher     starts ACGodot for each account, logged in to its server
  - Phone service        a small background program the phone app talks to (it asks each running ACGodot)
  - MelkTankRemote.apk   the Android app (2.20)
  - Loot Editor          edits MelkTank loot profiles outside the game

(Playing the original Asheron's Call client with Decal instead? Use MelkTankRemote_Windows.)


NEEDS
-----
  - Windows 10 or 11 with ACGodotWin extracted somewhere (the ACGodotWin-Client zip - MelkTank and MelksQB are
    already in its plugins folder) and the AC data files (client_portal.dat ...)
  - The .NET 10 runtime (x64): https://dotnet.microsoft.com/download/dotnet/10.0
  - Python 3.10 or newer: https://www.python.org/downloads/windows/
    When you install it, tick "Add python.exe to PATH"
  - Tailscale (free) on the PC and on the phone, signed in to the same account:
    https://tailscale.com/download   (this is how the phone reaches the PC from anywhere)


INSTALL ON THE PC
-----------------
1. Extract this zip to a folder that will stay put, for example C:\Games\MelkTankRemote_Windows
   (right-click the zip > Extract All). Don't run it from inside the zip.
2. Double-click setup.bat. It:
     - installs what the programs need (into a .venv folder in that folder)
     - asks where ACGodotWin is (default: C:\Games\ACGodotWin)
     - downloads Godot 4.7.2 .NET into ACGodotWin's Godot folder if it isn't there yet (about 115 MB, once)
     - checks for .NET 10 and opens its download page when it's missing
     - adds Start menu shortcuts (MelkTank folder) and starts the phone service now and whenever you sign in
   If Windows asks whether Python may use the network, click Allow.
3. Start menu > MelkTank > ACGodot Launcher:
     - Settings > ACGodot: the Godot program and the ACGodot folder (setup filled them in)
     - Servers: your server (InfiniteLeaftide is already there)
     - Add your accounts (Play in: ACGodot - the default here - with the character to log in), then Launch

INSTALL THE PHONE APP
---------------------
1. Copy MelkTankRemote.apk to the phone and open it. Allow "install unknown apps" when Android asks.
2. In the app, open Settings:
     PC address   the PC's Tailscale IP (100.x.y.z - shown in the Tailscale app on the PC)
     Port         8765
     App key      the launcher's Settings > Phone service > Phone app key
   Tap Save and test.


GOOD TO KNOW
------------
  - Each running ACGodot answers the phone service on a port of its own, on this PC only (8766, 8767, ... -
    Settings > ACGodot); nothing outside the PC can reach them, and the firewall needs nothing for them
  - PC screen (in the app): pinch to zoom, tap to click there - left, double or right click, drag (tap where to pick
    up, then where to drop), or click and type
  - Settings and logs: %APPDATA%\MelkTank (config.json holds your passwords - don't share it); each ACGodot's
    output: %APPDATA%\MelkTank\logs\acgodot-<account>.log
  - ACGodot's own settings: %APPDATA%\Godot\app_userdata\ACGodot
  - Changed the port, or the service isn't answering: double-click restart_service.bat
  - Updating: extract the new zip over this folder, then run setup.bat again
  - The local ACE server controls are for the Linux setup only


TROUBLESHOOTING
---------------
  - The app says it can't reach the PC: is Tailscale on (both ends)? Is the PC awake?
    Try restart_service.bat. Firewall: run setup.bat once with "Run as administrator" to allow port 8765.
  - Launch says Godot isn't there: run ACGodotWin's Start ACGodot.bat once (it downloads Godot), or check
    Settings > ACGodot.
  - "Failed to load .NET runtime": install the .NET 10 runtime (x64).
  - A character shows as not running while its game is open: another program is using its port - change the
    first port in Settings > ACGodot.
  - Logs: %APPDATA%\MelkTank\logs\launcher.log (launcher and service), service-output.log and acgodot-<account>.log

LAUNCHER ARTWORK
----------------
The launcher's design and the artwork in its launcher/ folder were contributed by Vain. The artwork (the
background, the node icons and the portal medallion) comes from Asheron's Call itself: the ruins splash from
Turbine's original aclauncher.exe, stone textures from client_highres.dat and the medallion from the original
box art. Asheron's Call and its artwork are copyright Turbine, Inc. and WB Games Inc.; they belong to their
owners and are used here only in a free, non-commercial fan project. Asheron's Call was a registered trademark
of Turbine, Inc. and WB Games Inc which has since expired. This project is not associated or affiliated in any
way with Turbine, Inc. or WB Games Inc.
(launcher\ART-NOTICE.txt)
