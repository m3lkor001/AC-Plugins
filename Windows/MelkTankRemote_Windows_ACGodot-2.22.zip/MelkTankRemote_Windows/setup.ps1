﻿# MelkTank Remote for Windows - setup. Run setup.bat (it runs this, saying which game client this PC uses).
param([ValidateSet("retail", "acgodot")][string]$Mode = "retail")
$ErrorActionPreference = "Continue"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here

Write-Host ("MelkTank Remote setup (" + $(if ($Mode -eq "acgodot") { "ACGodot" } else { "Asheron's Call + Decal" }) + ")") -ForegroundColor Cyan

# 1. Python
$pyExe = $null; $pyArgs = @()
foreach ($c in @("py -3", "python")) {
    $parts = $c.Split(" ")
    $exe = $parts[0]; $args0 = @($parts | Select-Object -Skip 1)
    try {
        $v = & $exe @args0 -c "import sys; print('%d.%d' % sys.version_info[:2])" 2>$null
        if ($LASTEXITCODE -eq 0 -and $v -and [version]$v -ge [version]"3.10") { $pyExe = $exe; $pyArgs = $args0; break }
    } catch {}
}
if (-not $pyExe) {
    Write-Host "Python 3.10 or newer wasn't found. Install it from https://www.python.org/downloads/windows/" -ForegroundColor Red
    Write-Host "(tick 'Add python.exe to PATH'), then run setup.bat again."
    exit 1
}

# 2. A private Python for MelkTank (in this folder) with Qt, psutil and Pillow
if (-not (Test-Path "$here\.venv\Scripts\python.exe")) {
    Write-Host "Creating the Python environment..."
    & $pyExe @pyArgs -m venv "$here\.venv"
}
$vpy = "$here\.venv\Scripts\python.exe"
$vpyw = "$here\.venv\Scripts\pythonw.exe"
Write-Host "Installing PySide6, psutil and Pillow (a few minutes the first time)..."
& $vpy -m pip install --upgrade --quiet pip
& $vpy -m pip install --quiet PySide6 psutil pillow
if ($LASTEXITCODE -ne 0) { Write-Host "pip install failed - check the internet connection and run setup.bat again." -ForegroundColor Red; exit 1 }

if ($Mode -eq "acgodot") {
    # 3. Where ACGodotWin is
    $default = "C:\Games\ACGodotWin"
    $cur = & $vpy -c "import mtcore; print((mtcore.load_config().get('acgodot') or {}).get('project') or '')"
    if ($cur) { $default = $cur }
    $folder = Read-Host "ACGodotWin folder (the one with Start ACGodot.bat) [$default]"
    if (-not $folder) { $folder = $default }
    if (-not (Test-Path "$folder\Start ACGodot.bat")) {
        Write-Host "Note: Start ACGodot.bat isn't in $folder - you can fix the folder later in the launcher's Settings > ACGodot." -ForegroundColor Yellow
    }
    $env:MT_ACG = $folder
    & $vpy -c "import os, mtcore; c = mtcore.load_config(); p = os.environ['MT_ACG']; ag = c.setdefault('acgodot', {}); ag['project'] = p; ag['godot'] = os.path.join(p, 'Godot', 'Godot_v4.7.2-stable_mono_win64.exe'); ag['auto_build'] = False; c['default_client'] = 'acgodot'; mtcore.save_config(c)"
    if ((Test-Path "$folder\Start ACGodot.bat") -and -not (Test-Path "$folder\Godot\Godot_v4.7.2-stable_mono_win64.exe")) {
        Write-Host "Downloading Godot 4.7.2 .NET for ACGodot (about 115 MB, once)..."
        & $vpy -c "import os, winplat; ok, why = winplat._fetch_godot(os.path.join(os.environ['MT_ACG'], 'Godot')); print('Godot: ' + ('ready' if ok else 'not downloaded (' + why + ') - the launcher tries again at the first launch'))"
    }
    $net = (& dotnet --list-runtimes 2>$null) -match "^Microsoft\.NETCore\.App 10\."
    if (-not $net) {
        Write-Host "ACGodot needs the .NET 10 runtime (x64), and it isn't installed: https://dotnet.microsoft.com/download/dotnet/10.0" -ForegroundColor Yellow
        Start-Process "https://dotnet.microsoft.com/download/dotnet/10.0"
    }
} else {
    # 3. Where MelkTank is installed
    $default = "C:\Games\Decal Plugins\MelksTank"
    $cur = & $vpy -c "import mtcore; print(mtcore.load_config().get('plugin_dir') or '')"
    if ($cur) { $default = $cur }
    $plugin = Read-Host "MelkTank plugin folder (the one with MelkTank.dll) [$default]"
    if (-not $plugin) { $plugin = $default }
    if (-not (Test-Path "$plugin\MelkTank.dll")) {
        Write-Host "Note: MelkTank.dll isn't in $plugin - you can fix the folder later in the launcher's Settings > Game setup." -ForegroundColor Yellow
    }
    $env:MT_PLUGIN = $plugin
    $remote = & $vpy -c "import os, mtcore; c = mtcore.load_config(); c['plugin_dir'] = os.environ['MT_PLUGIN']; c['default_client'] = 'retail'; mtcore.save_config(c); print(mtcore.install_helper(c, 'mtlaunch.exe'))"
    Write-Host "mtlaunch.exe and MelkTankLogin.dll copied to $(Split-Path -Parent $remote)"
    # MelkTank's login filter (picks the character at the character screen): a Decal network filter - Windows asks
    # for an admin's OK once, to add it to Decal's settings
    Write-Host "Adding MelkTank's login filter to Decal (Windows may ask for an admin's OK)..."
    & $vpy -c "import mtcore; c = mtcore.load_config(); print(mtcore.register_login_filter(c)[1])"
}

# 4. Shortcuts: Start menu (Launcher, Loot Editor) and Startup (the phone service)
$ws = New-Object -ComObject WScript.Shell
function Link($path, $target, $arguments, $icon = $null) {
    $s = $ws.CreateShortcut($path)
    $s.TargetPath = $target
    $s.Arguments = $arguments
    $s.WorkingDirectory = $here
    if ($icon -and (Test-Path $icon)) { $s.IconLocation = "$icon,0" }
    $s.Save()
}
$menu = Join-Path ([Environment]::GetFolderPath("Programs")) "MelkTank"
New-Item -ItemType Directory -Force -Path $menu | Out-Null
Remove-Item -Force -ErrorAction SilentlyContinue "$menu\MelkTank Launcher.lnk"   # (its old name)
Link "$menu\ACGodot Launcher.lnk" $vpyw "`"$here\launcher.py`"" (Join-Path $here "launcher\ACGodot.ico")
Link "$menu\MelkTank Loot Editor.lnk" $vpyw "`"$here\loot_editor.py`""
Link "$menu\MelkTank Phone Service.lnk" $vpyw "`"$here\run_service.pyw`""
Link (Join-Path ([Environment]::GetFolderPath("Startup")) "MelkTank Phone Service.lnk") $vpyw "`"$here\run_service.pyw`""
Write-Host "Start menu shortcuts made (MelkTank folder); the phone service starts when you sign in."

# 5. Let the phone reach the service (port 8765)
$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if ($admin) {
    if (-not (Get-NetFirewallRule -DisplayName "MelkTank phone service" -ErrorAction SilentlyContinue)) {
        New-NetFirewallRule -DisplayName "MelkTank phone service" -Direction Inbound -Protocol TCP -LocalPort 8765 -Action Allow -Profile Any | Out-Null
    }
    Write-Host "Firewall: port 8765 allowed."
} else {
    Write-Host "Firewall: when Windows asks whether Python may use the network, click Allow (tick Private and Public)." -ForegroundColor Yellow
    Write-Host "  (or run setup.bat once with 'Run as administrator' to add the rule)"
}

# 6. Start the service now (a running one is restarted with these files)
& "$here\restart_service.bat" | Out-Null
Write-Host ""
Write-Host "Done. Next: open 'ACGodot Launcher' from the Start menu, add your accounts, then see README.txt for the phone." -ForegroundColor Green
