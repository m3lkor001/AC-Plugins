#!/usr/bin/env python3
"""
ACGodot Launcher (was MelkTank Launcher) - a replacement for ThwargLauncher's window (Linux and Windows), for
ACGodot and the retail client. The window's design and artwork were contributed by Vain (launcher/: the
background, icons and fonts); the artwork is Asheron's Call's own - see launcher/ART-NOTICE.txt.

Starts your Asheron's Call clients with Decal (through Wine), tells MelkTank which character to log in,
shows the server and each account's status, and never closes a client on its own.
"""

import json
import os
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone

from PySide6.QtCore import QObject, QPointF, QRectF, QSize, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QIcon, QPainter, QPen, QPixmap, QPolygonF
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFormLayout,
                               QHBoxLayout, QHeaderView, QLabel, QLineEdit, QMenu, QMessageBox,
                               QPushButton, QSpinBox, QTableWidget, QTableWidgetItem, QTreeWidget, QTreeWidgetItem,
                               QVBoxLayout, QWidget, QPlainTextEdit, QToolButton, QSizePolicy, QAbstractItemView)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mtcore  # noqa: E402

CHAR_SCREEN = "(character screen)"


def _open_file(path):
    """Opens a file (the log) in this PC's own program for it."""
    if os.name == "nt":
        os.startfile(path)
    else:
        subprocess.Popen(["xdg-open", path])


def ago(dt):
    if not dt:
        return "-"
    s = int((datetime.now(timezone.utc) - dt).total_seconds())
    if s < 60:
        return "%ds ago" % s
    if s < 3600:
        return "%dm ago" % (s // 60)
    return "%dh %dm ago" % (s // 3600, (s % 3600) // 60)


def since(dt):
    if not dt:
        return ""
    s = int((datetime.now(timezone.utc) - dt).total_seconds())
    return "%dh %02dm" % (s // 3600, (s % 3600) // 60)


class Bus(QObject):
    """Signals from worker threads to the window."""
    message = Signal(str)
    server = Signal(str, object)   # server name, True/False/None
    done = Signal()


# ── Dialogs ────────────────────────────────────────────────────────

class AccountDialog(QDialog):
    def __init__(self, cfg, acct=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Account")
        self.cfg = cfg
        acct = acct or {"account": "", "password": "", "server": cfg["servers"][0]["name"] if cfg["servers"] else "",
                        "character": "", "enabled": True}
        form = QFormLayout(self)
        self.account = QLineEdit(acct["account"])
        self.password = QLineEdit(acct.get("password", ""))
        self.password.setEchoMode(QLineEdit.Password)
        show = QCheckBox("Show")
        show.toggled.connect(lambda on: self.password.setEchoMode(QLineEdit.Normal if on else QLineEdit.Password))
        pw = QHBoxLayout()
        pw.addWidget(self.password)
        pw.addWidget(show)
        self.server = QComboBox()
        for s in cfg["servers"]:
            self.server.addItem(s["name"])
        i = self.server.findText(acct.get("server", ""))
        if i >= 0:
            self.server.setCurrentIndex(i)
        self.character = QComboBox()
        self.character.setEditable(True)
        self.character.addItem(CHAR_SCREEN)
        for c in mtcore.known_characters(cfg, acct["account"]) or list(acct.get("characters_seen") or []):
            self.character.addItem(c)
        self.character.setCurrentText(acct.get("character") or CHAR_SCREEN)
        self.client = QComboBox()
        self.client.addItem("Asheron's Call (Decal)" if os.name == "nt" else "Asheron's Call (Wine + Decal)", "retail")
        self.client.addItem("ACGodot", "acgodot")
        # (a new account: the client this PC was set up for - setup's choice, else Asheron's Call)
        self.client.setCurrentIndex(max(0, self.client.findData(acct.get("client") or cfg.get("default_client") or "retail")))
        self.client.setToolTip("ACGodot logs in to this account's server with this account and password itself;\n"
                               "its phone plugin shows it in the phone app with the others.")
        self.enabled = QCheckBox("Include in \"Launch ticked\"")
        self.enabled.setChecked(acct.get("enabled", True))
        self.restart = QCheckBox("Restart if it crashes (when that's on in Settings)")
        self.restart.setChecked(acct.get("auto_restart", True))
        self.corner = QComboBox()
        for text, val in (("Top-left corner", "top-left"), ("Bottom-right corner", "bottom-right"), ("Leave it where it is", "none")):
            self.corner.addItem(text, val)
        i = self.corner.findData(acct.get("window_corner") or "top-left")
        self.corner.setCurrentIndex(max(0, i))
        self.corner.setToolTip("Once the character is in the game (and the window has stopped resizing), its window is\n"
                               "moved here; 5 s later the focus is taken off the games so they stop drawing.")
        form.addRow("Account", self.account)
        form.addRow("Password", pw)
        form.addRow("Server", self.server)
        form.addRow("Play in", self.client)
        form.addRow("Character", self.character)
        form.addRow("", QLabel("Leave it on (character screen) to pick by hand.\n"
                               "The list fills in after this account has reached the character screen once."))
        form.addRow("", self.enabled)
        form.addRow("", self.restart)
        form.addRow("Game window after login", self.corner)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)

    def value(self):
        ch = self.character.currentText().strip()
        return {"account": self.account.text().strip(), "password": self.password.text(),
                "server": self.server.currentText(), "character": "" if ch == CHAR_SCREEN else ch,
                "enabled": self.enabled.isChecked(), "auto_restart": self.restart.isChecked(),
                "window_corner": self.corner.currentData(), "client": self.client.currentData()}


class ServersDialog(QDialog):
    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Servers")
        self.resize(640, 260)
        lay = QVBoxLayout(self)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Name", "Address", "Port", "Read-only dats", "Character slots"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        for s in cfg["servers"]:
            self._add(s)
        lay.addWidget(self.table)
        row = QHBoxLayout()
        add = QPushButton("Add")
        add.clicked.connect(lambda: self._add({"name": "", "host": "", "port": 9000, "rodat": False, "slots": 11}))
        rem = QPushButton("Remove")
        rem.clicked.connect(lambda: self.table.removeRow(self.table.currentRow()))
        row.addWidget(add)
        row.addWidget(rem)
        row.addStretch()
        lay.addLayout(row)
        lay.addWidget(QLabel("Character slots: how many rows the server's character screen has (ACE default 11) - "
                             "auto-login uses it to click the right row."))
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        lay.addWidget(buttons)

    def _add(self, s):
        r = self.table.rowCount()
        self.table.insertRow(r)
        self.table.setItem(r, 0, QTableWidgetItem(s["name"]))
        self.table.setItem(r, 1, QTableWidgetItem(s["host"]))
        self.table.setItem(r, 2, QTableWidgetItem(str(s["port"])))
        cb = QCheckBox()
        cb.setChecked(bool(s.get("rodat")))
        self.table.setCellWidget(r, 3, cb)
        self.table.setItem(r, 4, QTableWidgetItem(str(s.get("slots", 11))))

    def value(self):
        out = []
        for r in range(self.table.rowCount()):
            name = (self.table.item(r, 0).text() if self.table.item(r, 0) else "").strip()
            host = (self.table.item(r, 1).text() if self.table.item(r, 1) else "").strip()
            if not name or not host:
                continue
            try:
                port = int(self.table.item(r, 2).text())
            except Exception:
                port = 9000
            try:
                slots = int(self.table.item(r, 4).text())
            except Exception:
                slots = 11
            out.append({"name": name, "host": host, "port": port, "rodat": self.table.cellWidget(r, 3).isChecked(),
                        "slots": slots})
        return out


class SettingsDialog(QDialog):
    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Settings")
        self.resize(720, 0)
        w = cfg["wine"]
        self.mode = QComboBox()
        self.mode.addItems(["direct", "system"])
        self.mode.setCurrentText(w.get("mode", "direct"))
        self.wine_path = QLineEdit(w["wine_path"])
        self.prefix = QLineEdit(w["prefix"])
        self.esync = QCheckBox("esync")
        self.esync.setChecked(bool(w.get("esync")))
        self.fsync = QCheckBox("fsync")
        self.fsync.setChecked(bool(w.get("fsync")))
        syncs = QHBoxLayout()
        syncs.addWidget(self.esync)
        syncs.addWidget(self.fsync)
        syncs.addStretch()
        self.client = QLineEdit(cfg["client"])
        self.injector = QLineEdit(cfg["injector"])
        self.inject = QComboBox()
        self.inject.addItem("Built-in (no ThwargLauncher needed)", "builtin")
        self.inject.addItem("ThwargLauncher's injector.dll", "thwarg")
        self.inject.setCurrentIndex(max(0, self.inject.findData(cfg.get("inject") or "builtin")))
        self.injector.setEnabled(self.inject.currentData() == "thwarg")
        self.inject.currentIndexChanged.connect(lambda _i: self.injector.setEnabled(self.inject.currentData() == "thwarg"))
        self.plugin = QLineEdit(cfg.get("plugin_dir") or "")
        self.decal = QCheckBox("Load Decal")
        self.decal.setChecked(cfg.get("use_decal", True))
        self.picker = QComboBox()
        self.picker.addItem("MelkTank login filter", "melktank")
        self.picker.addItem("ThwargFilter", "thwargfilter")
        self.picker.setCurrentIndex(max(0, self.picker.findData(cfg.get("character_picker", "melktank"))))
        self.restart = QCheckBox("Restart a client automatically if it crashes")
        self.restart.setChecked(bool(cfg.get("auto_restart", False)))
        self.frozen = QCheckBox("Restart a client that stops answering, or whose login gets stuck")
        self.frozen.setChecked(bool(cfg.get("restart_frozen", False)))
        self.frozen_min = QSpinBox()
        self.frozen_min.setRange(1, 30)
        self.frozen_min.setValue(int(cfg.get("frozen_minutes", 3)))
        self.frozen_min.setSuffix(" min without word")
        self.frozen_wait = QSpinBox()
        self.frozen_wait.setRange(0, 600)
        self.frozen_wait.setValue(int(cfg.get("frozen_wait_seconds", 60)))
        self.frozen_wait.setSuffix(" s before starting it again")
        frozen_row = QHBoxLayout()
        frozen_row.addWidget(self.frozen_min)
        frozen_row.addWidget(self.frozen_wait)
        frozen_row.addStretch()
        self.delay = QSpinBox()
        self.delay.setRange(5, 300)
        self.delay.setValue(int(cfg.get("launch_delay", 20)))
        self.delay.setSuffix(" s")
        self.port = QSpinBox()
        self.port.setRange(1024, 65535)
        self.port.setValue(int(cfg["service"]["port"]))
        self.token = QLineEdit(cfg["service"]["token"])
        self.token.setReadOnly(True)
        self.back = QCheckBox("Start the game again when the server comes back after a shutdown (a patch, a restart)")
        self.back.setChecked(bool(cfg.get("server_back_restart", True)))
        self.back_window = QSpinBox()
        self.back_window.setRange(1, 120)
        self.back_window.setValue(int(cfg.get("server_back_window_minutes", 15)))
        self.back_window.setSuffix(" min before it went down")
        self.back_wait = QSpinBox()
        self.back_wait.setRange(0, 1800)
        self.back_wait.setValue(int(cfg.get("server_back_wait_seconds", 90)))
        self.back_wait.setSuffix(" s after it's back")
        back_row = QHBoxLayout()
        back_row.addWidget(QLabel("Logged out up to"))
        back_row.addWidget(self.back_window)
        back_row.addWidget(QLabel("  started"))
        back_row.addWidget(self.back_wait)
        back_row.addStretch()

        outer = QVBoxLayout(self)
        outer.setContentsMargins(16, 12, 16, 12)
        title = QLabel("Settings")
        title.setStyleSheet("color: %s; border-bottom: 1px solid %s; padding-bottom: 4px; %s"
                            % (C_GOLD, C_BRONZE, css_font(F_HEAD, 18, bold=True)))
        outer.addWidget(title)
        opened = set(cfg.get("settings_open") or ["tools", "restarts", "server"])
        self.sections = {}

        def section(key, title):
            box = QWidget()
            v = QVBoxLayout(box)
            v.setContentsMargins(0, 0, 0, 0)
            head = QToolButton()
            head.setText(title)
            head.setCheckable(True)
            head.setChecked(key in opened)
            head.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
            head.setArrowType(Qt.DownArrow if key in opened else Qt.RightArrow)
            head.setStyleSheet("QToolButton { %s }" % css_font(F_HEAD, 14, bold=True))
            head.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            body = QWidget()
            f = QFormLayout(body)
            f.setContentsMargins(18, 0, 0, 6)
            body.setVisible(key in opened)

            def toggled(on, h=head, b=body):
                h.setArrowType(Qt.DownArrow if on else Qt.RightArrow)
                b.setVisible(on)
                QTimer.singleShot(0, lambda: self.resize(self.width(), self.sizeHint().height()))
            head.toggled.connect(toggled)
            v.addWidget(head)
            v.addWidget(body)
            outer.addWidget(box)
            self.sections[key] = head
            return f

        main = parent if hasattr(parent, "decal_state") else None
        if main is not None:
            form = section("tools", "Services && tools")
            self.svc = []

            def service(name, state_fn, toggle_fn, extra=None):
                row = QHBoxLayout()
                lab = QLabel("")
                lab.setMinimumWidth(150)
                btn = QPushButton("Start")
                btn.setFixedWidth(90)
                btn.clicked.connect(lambda: (toggle_fn(), btn.setEnabled(False),
                                             QTimer.singleShot(3000, lambda: btn.setEnabled(True))))
                row.addWidget(lab)
                row.addWidget(btn)
                if extra:
                    row.addWidget(extra)
                row.addStretch()
                form.addRow(name, row)
                self.svc.append((state_fn, lab, btn))
            service("Decal", main.decal_state, main.toggle_decal)
            if main.ace_there():
                con = QPushButton("Console...")
                con.clicked.connect(lambda: main.open_server_console(self))
                service("ACE server", main.ace_state, main.toggle_ace, con)
            tools = QHBoxLayout()
            for text, fn, tip in (("Servers...", lambda: main.edit_servers(self), "Names, addresses, read-only dats, character slots"),
                                  ("ACGodot plugins...", lambda: main.edit_acg_plugins(self), "Which plugins start with ACGodot"),
                                  ("Client log...", lambda: main.open_client_log(self), "Launches, time in game, freezes, disconnects, crashes, restarts"),
                                  ("Launcher log", main.open_log, "The launcher's own log file"),
                                  ("Check servers", main.check_now, "Check the servers again right away")):
                b = QPushButton(text)
                b.setToolTip(tip)
                b.clicked.connect(fn)
                tools.addWidget(b)
            tools.addStretch()
            form.addRow("", tools)

            def show_services():
                for state_fn, lab, btn in self.svc:
                    try:
                        running, text, color = state_fn()
                    except Exception:
                        continue
                    lab.setText(text)
                    lab.setStyleSheet("color: %s; font-weight: bold;" % color)
                    btn.setText("Stop" if running else "Start")
            show_services()
            self._svc_timer = QTimer(self)
            self._svc_timer.timeout.connect(show_services)
            self._svc_timer.start(2000)

        form = section("restarts", "Restarts")
        form.addRow("", self.restart)
        form.addRow("", QLabel("Only clients that got into the game. A client you close yourself, or one that's frozen\n"
                               "but still open, isn't restarted. At most 3 restarts per account in 30 minutes.\n"
                               "The phone service does the watching, so it works with this window closed."))
        form.addRow("", self.frozen)
        form.addRow("", frozen_row)
        form.addRow("", QLabel("Stopped answering (frozen or lost its connection): closed (forced) after the time above,\n"
                               "then started again after the wait. Login stuck at the character screen: 1 more minute,\n"
                               "then closed, then started again after the wait. Only for accounts ticked to restart,\n"
                               "not while the server is down, at most 3 times per account in 30 minutes."))

        form = section("server", "Server shutdowns")
        form.addRow("", self.back)
        form.addRow("", back_row)
        form.addRow("", QLabel("A shutdown logs everyone off, which looks like a normal logout. Accounts (ticked to restart)\n"
                               "that logged out within the time above before the server stopped answering are started\n"
                               "again once it answers, after the wait (it may not take logins straight away).\n"
                               "The server is checked every minute - every 20 s while it's down."))

        form = section("launching", "Launching")
        form.addRow("Character picked by", self.picker)
        form.addRow("Time between launches", self.delay)

        if os.name == "nt":
            form = section("wine", "Game setup")
            form.addRow("acclient.exe", self.client)
            form.addRow("Load Decal with", self.inject)
            form.addRow("injector.dll", self.injector)
            form.addRow("MelkTank plugin folder", self.plugin)
            form.addRow("", self.decal)
        else:
            form = section("wine", "Game && Wine setup")
            form.addRow("Wine", self.mode)
            form.addRow("Wine program (direct)", self.wine_path)
            form.addRow("Wine prefix", self.prefix)
            form.addRow("", syncs)
            form.addRow("acclient.exe (Windows path)", self.client)
            form.addRow("Load Decal with", self.inject)
            form.addRow("injector.dll (Windows path)", self.injector)
            form.addRow("", self.decal)

        ag = cfg.get("acgodot") or {}
        self.godot = QLineEdit(ag.get("godot", ""))
        self.acg_project = QLineEdit(ag.get("project", ""))
        self.acg_port = QSpinBox()
        self.acg_port.setRange(1024, 65535)
        self.acg_port.setValue(int(ag.get("phone_port") or 8766))
        self.acg_build = QCheckBox("Build it before starting when its source has changed")
        self.acg_build.setToolTip("Runs 'dotnet build' first when ACGodot's source is newer than its last build (what the editor's\n"
                                  "Build button does) - updates take effect without opening the Godot editor.")
        self.acg_build.setChecked(bool(ag.get("auto_build", True)))
        form = section("acgodot", "ACGodot")
        form.addRow("Godot program", self.godot)
        form.addRow("ACGodot folder", self.acg_project)
        form.addRow("Its phone plugin's port", self.acg_port)
        form.addRow("", self.acg_build)
        form.addRow("", QLabel("Accounts set to \"Play in: ACGodot\" start Godot with that folder, logged in to their\n"
                               "server. Its phone plugin answers on the port above (only this PC asks it): the phone\n"
                               "app shows ACGodot characters with the others."))

        form = section("phone", "Phone service")
        form.addRow("Phone service port", self.port)
        form.addRow("Phone app key", self.token)
        form.addRow("", QLabel("Type the phone app key into the app once. Changes to the port apply when the "
                               "service restarts:\n  " + ("double-click restart_service.bat" if os.name == "nt" else
                                                           "systemctl --user restart melktank-service")))
        outer.addStretch()
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        outer.addWidget(buttons)

    def apply(self, cfg):
        w = cfg["wine"]
        w["mode"] = self.mode.currentText()
        w["wine_path"] = self.wine_path.text().strip()
        w["prefix"] = self.prefix.text().strip()
        w["esync"] = self.esync.isChecked()
        w["fsync"] = self.fsync.isChecked()
        cfg["client"] = self.client.text().strip()
        cfg["injector"] = self.injector.text().strip()
        cfg["inject"] = self.inject.currentData()
        if os.name == "nt" and self.plugin.text().strip():
            cfg["plugin_dir"] = self.plugin.text().strip()
        cfg["use_decal"] = self.decal.isChecked()
        cfg["character_picker"] = self.picker.currentData()
        cfg["auto_restart"] = self.restart.isChecked()
        cfg["restart_frozen"] = self.frozen.isChecked()
        cfg["frozen_minutes"] = self.frozen_min.value()
        cfg["frozen_wait_seconds"] = self.frozen_wait.value()
        cfg["launch_delay"] = self.delay.value()
        cfg["service"]["port"] = self.port.value()
        cfg["server_back_restart"] = self.back.isChecked()
        cfg["server_back_window_minutes"] = self.back_window.value()
        cfg["server_back_wait_seconds"] = self.back_wait.value()
        cfg["acgodot"] = {"godot": self.godot.text().strip(), "project": self.acg_project.text().strip(),
                          "phone_port": self.acg_port.value(), "auto_build": self.acg_build.isChecked()}
        cfg["settings_open"] = [k for k, h in self.sections.items() if h.isChecked()]


# ── Main window ────────────────────────────────────────────────────

COLS = ["Launch", "Account", "Character", "Status", "In game", ""]


def dur(secs):
    """3h 12m / 12m / 40s"""
    secs = int(secs or 0)
    if secs >= 86400:
        return "%dd %dh" % (secs // 86400, secs % 86400 // 3600)
    if secs >= 3600:
        return "%dh %02dm" % (secs // 3600, secs % 3600 // 60)
    if secs >= 60:
        return "%dm" % (secs // 60)
    return "%ds" % secs


KIND_COLOUR = {"in_game": "#5ccc6a", "launch": "#5ad6f2", "restart": "#5ad6f2", "closed": "#9a9a9a",
               "closed_phone": "#9a9a9a", "unresponsive": "#e8a33a", "disconnected": "#e8a33a", "killed": "#e8a33a",
               "server_down": "#e8a33a", "server_up": "#5ccc6a", "crashed": "#e06060", "stuck": "#e06060",
               "launch_failed": "#e06060", "gave_up": "#e06060", "reset": "#b685f2"}


class AcgPluginsDialog(QDialog):
    """ACGodot's plugins: which start with the game. The same file the game's Options > Plugins uses
    (<ACGodot folder>/plugins/plugins.json); a change applies the next time ACGodot starts."""

    BUILT_IN = ["XP Tracker", "Bounty", "Phone"]   # (until the game has run once and written its own list)

    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.setWindowTitle("ACGodot plugins")
        project = (cfg.get("acgodot") or {}).get("project") or os.path.expanduser("~/Games/ACGodot")
        self.dir = os.path.join(project, "plugins")
        self.path = os.path.join(self.dir, "plugins.json")
        data = {}
        try:
            with open(self.path, encoding="utf-8") as fh:
                data = json.load(fh)
        except Exception:
            pass
        self.disabled = set(data.get("disabled") or [])
        known = list(data.get("known") or self.BUILT_IN)
        # plugin folders (plugins/Name/Name.dll) - also ones added since the game last ran
        try:
            for name in sorted(os.listdir(self.dir), key=str.lower):
                if os.path.isfile(os.path.join(self.dir, name, name + ".dll")) and name not in known:
                    known.append(name)
        except Exception:
            pass
        self.known = known
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Plugins that start with ACGodot:"))
        self.boxes = {}
        for name in known:
            cb = QCheckBox(name)
            cb.setChecked(name not in self.disabled)
            lay.addWidget(cb)
            self.boxes[name] = cb
        if not known:
            lay.addWidget(QLabel("No plugins found in %s." % self.dir))
        note = QLabel("Applies the next time ACGodot starts. Each plugin is a folder in\n%s\n(Name/Name.dll, with its files beside it)." % self.dir)
        note.setStyleSheet("color: gray")
        lay.addWidget(note)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.save)
        buttons.rejected.connect(self.reject)
        lay.addWidget(buttons)

    def save(self):
        off = set(n for n in self.disabled if n not in self.boxes)   # (switched off ones no longer there: kept)
        off.update(n for n, cb in self.boxes.items() if not cb.isChecked())
        try:
            os.makedirs(self.dir, exist_ok=True)
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump({"disabled": sorted(off), "known": self.known}, fh, indent=2)
            os.replace(tmp, self.path)
        except Exception as e:
            QMessageBox.warning(self, "ACGodot plugins", "Couldn't save %s: %s" % (self.path, e))
            return
        self.accept()


ACE_LOG = "\x00ace-server"   # (the log window's entry for the ACE server's output: not an account)


class ServerConsoleDialog(QDialog):
    """The local ACE server's console: a command (every one its console takes, from its source) with what follows it,
    run into the server - and the last 100 lines it wrote, kept up to date while the window is open."""

    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.setWindowTitle("ACE server console")
        self.resize(1000, 600)
        lay = QVBoxLayout(self)
        top = QHBoxLayout()
        self.cmd = QComboBox()
        self.cmd.setMaxVisibleItems(25)
        self.cmd.setMinimumWidth(220)
        self.cmds = mtcore.ace_commands(cfg)
        for c in self.cmds:
            self.cmd.addItem(c["name"], c)
            self.cmd.setItemData(self.cmd.count() - 1, ("%s %s" % (c["help"], ("\nUsage: " + c["usage"]) if c["usage"] else "")).strip(), Qt.ToolTipRole)
        i = self.cmd.findText("serverstatus")
        if i >= 0:
            self.cmd.setCurrentIndex(i)
        self.cmd.currentIndexChanged.connect(self.picked)
        top.addWidget(self.cmd)
        self.args = QLineEdit()
        self.args.returnPressed.connect(self.run)
        top.addWidget(self.args, 1)
        b = QPushButton("Run")
        b.clicked.connect(self.run)
        top.addWidget(b)
        lay.addLayout(top)
        self.help = QLabel("")
        self.help.setWordWrap(True)
        self.help.setStyleSheet("color: #9a9a9a;")
        lay.addWidget(self.help)
        self.out = QPlainTextEdit()
        self.out.setReadOnly(True)
        self.out.setLineWrapMode(QPlainTextEdit.WidgetWidth)
        self.out.setMaximumBlockCount(100)
        mono = QFont("monospace")
        mono.setStyleHint(QFont.Monospace)
        self.out.setFont(mono)
        self.out.setStyleSheet("QPlainTextEdit { background: #000000; color: #d8d8d8; }")
        lay.addWidget(self.out, 1)
        self.status = QLabel("")
        lay.addWidget(self.status)
        self._mark = None
        self.picked()
        self.fill()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.fill)
        self.timer.start(1000)

    def picked(self):
        c = self.cmd.currentData() or {}
        self.args.setPlaceholderText(c.get("usage") or ("(nothing more)" if c.get("args", 0) == 0 else "arguments"))
        self.help.setText(c.get("help", ""))

    def run(self):
        c = self.cmd.currentData() or {}
        line = (c.get("name", "") + " " + self.args.text().strip()).strip()
        if not line:
            return
        ok, msg = mtcore.ace_command(line)
        self.status.setText(msg)
        if ok:
            self.args.clear()
        QTimer.singleShot(400, self.fill)

    def fill(self):
        con = mtcore.ace_console(100)
        if con["mark"] == self._mark and self._mark is not None:
            return
        first = self._mark is None
        self._mark = con["mark"]
        bar = self.out.verticalScrollBar()
        at_end = first or bar.value() >= bar.maximum() - 4
        lines = con["lines"] or ["No output yet. It's kept from when the server is started here (the launcher's Start ACE, "
                                 "or the phone); a server started in a terminal writes to that terminal instead."]
        self.out.setPlainText("\n".join(lines[-100:]))
        if at_end:
            bar.setValue(bar.maximum())
            QTimer.singleShot(0, lambda: bar.setValue(bar.maximum()))
        if not con["running"]:
            self.status.setText("The server isn't running.")
        elif not con["ours"]:
            self.status.setText("This server was started in a terminal: commands can't be typed into it from here.")

    def closeEvent(self, ev):
        self.timer.stop()
        super().closeEvent(ev)


class ClientLogDialog(QDialog):
    """The client history: when each client was launched, got in, stopped answering, crashed, was closed and
    restarted - with how long each run lasted, and a summary of the last 24 hours."""

    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.setWindowTitle("Client log")
        self.resize(980, 560)
        lay = QVBoxLayout(self)
        top = QHBoxLayout()
        top.addWidget(QLabel("Account"))
        self.who = QComboBox()
        self.who.addItem("All", "")
        for a in cfg["accounts"]:
            self.who.addItem(a.get("label") or a["account"], a["account"])
        # the local ACE server's own output (what its terminal showed), where ACE is on this PC
        if os.path.isdir(os.path.join(mtcore.ace_root(cfg), "Source", "ACE.Server")):
            self.who.addItem("ACE server (its console output)", ACE_LOG)
        self.who.currentIndexChanged.connect(self.fill)
        top.addWidget(self.who)
        top.addStretch()
        b = QPushButton("Refresh")
        b.clicked.connect(self.fill)
        top.addWidget(b)
        b = QPushButton("Full launcher log")
        b.clicked.connect(lambda: _open_file(mtcore.LOG_PATH))
        top.addWidget(b)
        lay.addLayout(top)
        self.summary = QLabel("")
        self.summary.setTextFormat(Qt.RichText)
        self.summary.setWordWrap(True)
        lay.addWidget(self.summary)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["When", "Account", "What", "Ran for", "Details"])
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.verticalHeader().setVisible(False)
        h = self.table.horizontalHeader()
        h.setSectionResizeMode(QHeaderView.ResizeToContents)
        h.setSectionResizeMode(4, QHeaderView.Stretch)
        lay.addWidget(self.table, 1)
        self.console = QPlainTextEdit()
        self.console.setReadOnly(True)
        self.console.setLineWrapMode(QPlainTextEdit.NoWrap)
        mono = QFont("monospace")
        mono.setStyleHint(QFont.Monospace)
        self.console.setFont(mono)
        self.console.setVisible(False)
        lay.addWidget(self.console, 1)
        self._console_seen = None
        self.fill()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.fill)
        self.timer.start(15000)
        # (the server's output is looked at more often than the history)
        self.fast = QTimer(self)
        self.fast.timeout.connect(lambda: self.fill_console() if self.who.currentData() == ACE_LOG else None)
        self.fast.start(2000)

    def name_of(self, account):
        a = mtcore.find_account(self.cfg, account)
        return (a.get("label") or account) if a else account

    def closeEvent(self, ev):
        # (nothing more to fill in once it's shut)
        self.timer.stop()
        self.fast.stop()
        super().closeEvent(ev)

    def fill_console(self):
        """The ACE server's console output (the end of it), kept at the bottom as it grows unless you've scrolled up."""
        path = mtcore.ACE_LOG_PATH
        try:
            st = os.stat(path)
            seen = (st.st_mtime, st.st_size)
            if seen == self._console_seen:
                return
            self._console_seen = seen
            with open(path, "rb") as f:
                if st.st_size > 400000:
                    f.seek(-400000, os.SEEK_END)
                    f.readline()
                text = f.read().decode("utf-8", "replace")
        except OSError:
            self._console_seen = None
            text = ("No output yet. It's kept from when the server is started here (the launcher's Start ACE, or the phone);\n"
                    "a server started in a terminal writes to that terminal instead.")
        bar = self.console.verticalScrollBar()
        at_end = bar.value() >= bar.maximum() - 4
        self.console.setPlainText(text)
        if at_end:
            bar.setValue(bar.maximum())

    def fill(self):
        acct = self.who.currentData() or None
        console = acct == ACE_LOG
        self.console.setVisible(console)
        self.table.setVisible(not console)
        if console:
            running = bool(mtcore.ace_pids())
            self.summary.setText("<b>ACE server</b> - %s &nbsp; (%s)" % (
                "<span style='color:#5ccc6a'>running</span>" if running else "<span style='color:#9a9a9a'>stopped</span>", mtcore.ACE_LOG_PATH))
            self.fill_console()
            return
        now = datetime.now().timestamp()
        parts = []
        for name, s in mtcore.events_summary(self.cfg).items():
            if acct and name.lower() != acct.lower():
                continue
            head = "<b>%s</b>" % self.name_of(name)
            if s["inGameSince"]:
                head += " - <span style='color:#5ccc6a'>in game %s</span>%s" % (
                    dur(now - s["inGameSince"]), (" as " + s["char"]) if s.get("char") else "")
            else:
                head += " - <span style='color:#9a9a9a'>not in game</span>"
            bits = ["%s in game" % dur(s["uptime"]), "longest run %s" % dur(s["longest"])]
            for key, word in (("restarts", "restart"), ("crashes", "crash"), ("unresponsive", "freeze"),
                              ("disconnects", "disconnect"), ("stuck", "stuck login")):
                if s[key]:
                    plural = "es" if word.endswith("sh") else "s"
                    bits.append("%d %s%s" % (s[key], word, plural if s[key] != 1 else ""))
            parts.append(head + "<br>&nbsp;&nbsp;last 24 h: " + ", ".join(bits))
        self.summary.setText("<br>".join(parts) or "Nothing recorded yet.")
        evs = mtcore.read_events(acct, limit=500)
        evs.reverse()
        # (unchanged since it was last filled in: left as it is - 500 rows laid out again every time was slow)
        stamp = (acct, len(evs), evs[0].get("t") if evs else None)
        if stamp == getattr(self, "_table_stamp", None):
            return
        self._table_stamp = stamp
        self.table.setUpdatesEnabled(False)
        self.table.setRowCount(len(evs))
        for r, e in enumerate(evs):
            t = datetime.fromtimestamp(e.get("t", 0))
            when = t.strftime("%H:%M:%S") if t.date() == datetime.now().date() else t.strftime("%b %d %H:%M")
            kind = e.get("kind", "")
            cells = [when, self.name_of(e.get("account", "")) + ((" (" + e["char"] + ")") if e.get("char") else ""),
                     mtcore.EVENT_KINDS.get(kind, kind), dur(e["ran"]) if e.get("ran") is not None else "", e.get("text", "")]
            for c, text in enumerate(cells):
                it = QTableWidgetItem(text)
                if c == 2:
                    it.setForeground(QColor(KIND_COLOUR.get(kind, "#e8e8e8")))
                self.table.setItem(r, c, it)
        self.table.setUpdatesEnabled(True)


# ── The look (window design contributed by Vain) ───────────────────

ART = os.path.join(os.path.dirname(os.path.abspath(__file__)), "launcher")
C_PANEL, C_FIELD, C_TEXT, C_DIM = "#0b0a09", "#1e1a15", "#e4d8c0", "#968870"
C_GOLD, C_BRONZE, C_BTN, C_BTN_HOT, C_SEL = "#d6b268", "#96743a", "#342818", "#544024", "#4a3920"
C_GREEN, C_AMBER, C_RED, C_BLUE = "#6fcf7c", "#e0a640", "#e06a5a", "#5ad6f2"
F_HEAD, F_UI = "Cinzel", "Lato"   # (both in launcher/fonts, so Windows and Linux look the same)

STYLE = """
QWidget { color: %(text)s; font-family: "%(ui)s"; font-size: 13px; }
QDialog, QMainWindow, QMessageBox { background: %(panel)s; }
QDialog { border: 1px solid %(bronze)s; }
QLabel, QCheckBox, QRadioButton { background: transparent; }
QLineEdit, QComboBox, QSpinBox, QPlainTextEdit, QTextEdit {
    background: %(field)s; color: %(text)s; border: 1px solid #5a4626; padding: 2px 5px;
    selection-background-color: %(sel)s; selection-color: %(text)s; }
QLineEdit:focus, QComboBox:focus, QSpinBox:focus { border: 1px solid %(bronze)s; }
QLineEdit:read-only { color: %(dim)s; }
QLineEdit:disabled, QComboBox:disabled, QSpinBox:disabled { color: #6a5e4c; border-color: #3a2e1c; }
QComboBox::drop-down { border: none; width: 18px; }
QComboBox::down-arrow { image: url("%(art)s/arrow-down.png"); width: 10px; height: 7px; margin-right: 6px; }
QComboBox QAbstractItemView { background: %(field)s; color: %(text)s; border: 1px solid %(bronze)s;
    selection-background-color: %(sel)s; outline: none; }
QSpinBox::up-button, QSpinBox::down-button { background: %(btn)s; border: none; width: 14px; }
QSpinBox::up-arrow { image: url("%(art)s/arrow-up.png"); width: 8px; height: 6px; }
QSpinBox::down-arrow { image: url("%(art)s/arrow-down.png"); width: 8px; height: 6px; }
QPushButton { background: %(btn)s; color: %(gold)s; border: 1px solid %(bronze)s; padding: 4px 12px;
    font-family: "%(head)s"; font-weight: bold; font-size: 13px; }
QPushButton:hover { background: %(hot)s; }
QPushButton:pressed { background: %(sel)s; }
QPushButton:disabled { color: #6a5e4c; border-color: #4a3a22; }
QPushButton:default { border: 1px solid %(gold)s; }
QCheckBox::indicator, QTreeView::indicator, QTableView::indicator {
    width: 12px; height: 12px; border: 1px solid %(bronze)s; background: %(field)s; }
QCheckBox::indicator:checked, QTreeView::indicator:checked, QTableView::indicator:checked {
    background: qradialgradient(cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 %(gold)s, stop:0.55 %(gold)s, stop:0.6 %(field)s); }
QCheckBox::indicator:disabled { border-color: #4a3a22; }
QToolButton { color: %(gold)s; background: transparent; border: none; font-family: "%(head)s"; font-weight: bold;
    font-size: 14px; padding: 4px 0; }
QTableWidget, QTreeWidget, QListWidget { background: %(panel)s; alternate-background-color: #14110d;
    gridline-color: #3a2e1c; border: 1px solid #3a2e1c; selection-background-color: %(sel)s; selection-color: %(text)s; }
QTreeWidget { border: none; outline: none; }
QTreeWidget::item { padding: 1px 2px; }
QTreeWidget::item:selected { background: %(sel)s; color: %(text)s; }
QHeaderView::section { background: #241c12; color: %(gold)s; border: none; border-right: 1px solid #3a2e1c;
    border-bottom: 1px solid %(bronze)s; padding: 3px 6px; font-family: "%(head)s"; font-weight: bold; }
QTableCornerButton::section { background: #241c12; border: none; }
QScrollBar:vertical { background: #14110d; width: 10px; margin: 0; }
QScrollBar:horizontal { background: #14110d; height: 10px; margin: 0; }
QScrollBar::handle { background: #5a4626; min-height: 20px; min-width: 20px; }
QScrollBar::handle:hover { background: %(bronze)s; }
QScrollBar::add-line, QScrollBar::sub-line { width: 0; height: 0; }
QScrollBar::add-page, QScrollBar::sub-page { background: none; }
QToolTip { background: %(field)s; color: %(text)s; border: 1px solid %(bronze)s; padding: 3px; }
QMenu { background: %(field)s; color: %(text)s; border: 1px solid %(bronze)s; padding: 2px; }
QMenu::item { padding: 4px 18px; }
QMenu::item:selected { background: %(sel)s; }
QMenu::separator { height: 1px; background: #5a4626; margin: 3px 6px; }
QMenuBar { background: %(panel)s; }
QMenuBar::item:selected { background: %(sel)s; }
""" % {"text": C_TEXT, "ui": F_UI, "head": F_HEAD, "panel": C_PANEL, "field": C_FIELD, "bronze": C_BRONZE,
       "sel": C_SEL, "dim": C_DIM, "gold": C_GOLD, "btn": C_BTN, "hot": C_BTN_HOT, "art": ART.replace("\\", "/")}


def load_look(app):
    """The fonts and colours, for every window of the launcher."""
    from PySide6.QtGui import QFontDatabase
    fonts = os.path.join(ART, "fonts")
    if os.path.isdir(fonts):
        for n in sorted(os.listdir(fonts)):
            if n.lower().endswith((".ttf", ".otf")):
                QFontDatabase.addApplicationFont(os.path.join(fonts, n))
    app.setStyle("Fusion")
    app.setStyleSheet(STYLE)
    ico = os.path.join(ART, "launcher.ico")
    if os.path.exists(ico):
        app.setWindowIcon(QIcon(ico))


def css_font(family, px, bold=False, italic=False):
    """A font as style-sheet text (the launcher's style sheet sets every widget's font, so fonts go this way)."""
    return 'font-family: "%s"; font-size: %dpx; font-weight: %s; font-style: %s;' % (
        family, px, "bold" if bold else "normal", "italic" if italic else "normal")


def head_font(px, bold=True, italic=False):
    f = QFont(F_HEAD)
    f.setPixelSize(px)
    f.setBold(bold)
    f.setItalic(italic)
    return f


def ui_font(px, bold=False, italic=False):
    f = QFont(F_UI)
    f.setPixelSize(px)
    f.setBold(bold)
    f.setItalic(italic)
    return f


# ── Main window ────────────────────────────────────────────────────

class Main(QWidget):
    """Realms & characters on the left (server > account > character, ticked to launch together), the selected
    account's login on the right. Drawn on Vain's artwork; 960 x 640 is the smallest it goes - bigger, the header art
    scales with the width and the two panels (drawn here over the artwork's) grow to fill the rest."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("ACGodot Launcher")
        self.setMinimumSize(960, 640)
        self.resize(960, 640)
        self.cfg = mtcore.load_config()
        self.bus = Bus(self)   # owned by the window, so it's cleaned up with it
        self.bus.message.connect(self.say)
        self.bus.server.connect(self.on_server)
        self.bus.done.connect(self.on_launch_done)
        self.server_states = {}
        self.busy = False
        self.current = None        # the account showing on the right (None: a new one)
        self.filling = False
        self.collapsed = set()
        self.acct_items = {}       # account name -> its tree item
        self.server_items = {}     # server name -> its tree item
        bg = os.path.join(ART, "launcher-bg.png")
        self.bg = QPixmap(bg) if os.path.exists(bg) else None
        self.icons = {k: QIcon(os.path.join(ART, "node-%s.png" % k)) for k in ("server", "account", "char")}

        # --- left: the tree ---
        self.tree = QTreeWidget(self)
        self.tree.setGeometry(30, 250, 330, 256)
        self.tree.setColumnCount(2)
        self.tree.setHeaderHidden(True)
        self.tree.setIndentation(16)
        self.tree.setIconSize(QSize(16, 16))
        self.tree.setRootIsDecorated(True)
        self.tree.header().setStretchLastSection(False)
        self.tree.header().setSectionResizeMode(0, QHeaderView.Stretch)
        self.tree.header().setSectionResizeMode(1, QHeaderView.Fixed)
        self.tree.setColumnWidth(1, 112)
        self.tree.setFont(ui_font(13))
        self.tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self.tree_menu)
        self.tree.itemChanged.connect(self.on_tick)
        self.tree.currentItemChanged.connect(lambda cur, _prev: self.on_select(cur))
        self.tree.itemDoubleClicked.connect(lambda it, _c: self.launch_item(it))
        self.tree.itemCollapsed.connect(lambda it: None if self.filling else self.collapsed.add(self.item_key(it)))
        self.tree.itemExpanded.connect(lambda it: None if self.filling else self.collapsed.discard(self.item_key(it)))
        self.new_btn = self.button("New account", 30, 516, 140, 30, self.new_account)
        self.launch_btn = self.button("Launch ticked", 180, 516, 180, 30, self.launch_ticked)
        self.launch_btn.setToolTip("Launches every ticked account, each as its gold (ticked) character")

        # --- right: the login ---
        x = 406
        self.l_server = self.label("Server", x, 248)
        self.server = self.field(QComboBox(self), x, 268, 140, 26)
        self.server.setEditable(True)
        self.server.activated.connect(self.server_picked)
        self.l_address = self.label("Address", x + 150, 248)
        self.host = self.field(QLineEdit(self), x + 150, 268, 230, 26)
        self.l_port = self.label("Port", x + 390, 248)
        self.port = self.field(QLineEdit(self), x + 390, 268, 70, 26)

        self.l_account = self.label("Account", x, 302)
        self.account = self.field(QLineEdit(self), x, 322, 225, 26)
        self.l_password = self.label("Password", x + 235, 302)
        self.password = self.field(QLineEdit(self), x + 235, 322, 225, 26)
        self.password.setEchoMode(QLineEdit.Password)
        self.password.setPlaceholderText("(empty keeps the saved one)")

        self.l_character = self.label("Character", x, 356)
        self.character = self.field(QComboBox(self), x, 376, 225, 26)
        self.character.setEditable(True)
        self.character.setToolTip("Leave it on %s to pick by hand. The list fills in once the account has\n"
                                  "reached the character screen." % CHAR_SCREEN)
        self.l_play_in = self.label("Play in", x + 235, 356)
        self.client = self.field(QComboBox(self), x + 235, 376, 225, 26)
        self.client.addItem("Asheron's Call (Decal)" if os.name == "nt" else "Asheron's Call (Wine + Decal)", "retail")
        self.client.addItem("ACGodot", "acgodot")

        self.restart = QCheckBox("Restart if it crashes", self)
        self.restart.setGeometry(x, 410, 190, 24)
        self.restart.setToolTip("When restarts are on in Settings")
        self.corner = self.field(QComboBox(self), x + 235, 409, 225, 26)
        for text, val in (("Window to the top-left", "top-left"), ("Window to the bottom-right", "bottom-right"),
                          ("Leave the window where it is", "none")):
            self.corner.addItem(text, val)
        self.corner.setToolTip("Once the character is in the game, its window is moved here; 5 s later the focus is\n"
                               "taken off the games so they stop drawing.")

        self.state = QLabel(self)
        self.state.setGeometry(x, 442, 290, 24)
        self.stop_btn = self.button("Stop", x + 300, 440, 76, 26, self.stop_current, size=12)
        self.stop_btn.setToolTip("MelkTank logs the character out and closes the game (like Exit on the phone).")
        self.kill_btn = self.button("Kill", x + 384, 440, 76, 26, self.kill_current, size=12)
        self.kill_btn.setToolTip("Ends the game's process straight away - for a frozen or stuck client.")

        self.save_btn = self.button("Save", x, 474, 146, 30, self.save_current)
        self.delete_btn = self.button("Delete", x + 157, 474, 146, 30, self.delete_selected)
        self.settings_btn = self.button("Settings", x + 314, 474, 146, 30, self.edit_settings)
        self.settings_btn.setToolTip("Restarts, server shutdowns, launching, game setup, ACGodot, the phone service,\n"
                                     "Decal and the ACE server, the servers list and the logs")
        self.enter_btn = self.button("Enter the World", x, 510, 460, 38, self.enter_world, size=20)
        self.enter_btn.setStyleSheet("QPushButton { background: #48341a; %s } QPushButton:hover { background: #64482a; }"
                                     % css_font(F_HEAD, 20, bold=True))
        self.enter_btn.setDefault(True)

        self.status = QLabel(self)
        self.status.setGeometry(16, 572, 700, 22)
        self.status.setStyleSheet("color: %s;" % C_DIM)
        self.credit = credit = QLabel("Contributed by Vain", self)
        credit.setStyleSheet("color: %s; %s" % (C_BRONZE, css_font(F_HEAD, 12, italic=True)))
        credit.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        credit.setGeometry(700, 572, 186, 22)
        credit.setToolTip("The launcher's design: Vain.\nArtwork from Asheron's Call - copyright Turbine, Inc. and WB Games Inc.\n"
                          "Not associated or affiliated with Turbine, Inc. or WB Games Inc.\n(launcher/ART-NOTICE.txt)")

        self.rebuild()
        first = next((a for a in self.cfg["accounts"] if a.get("enabled", True)), None) or \
            (self.cfg["accounts"][0] if self.cfg["accounts"] else None)
        if first and first["account"] in self.acct_items:
            self.tree.setCurrentItem(self.acct_items[first["account"]])
        else:
            self.show_account(None)
        problems = mtcore.check_setup(self.cfg)
        if problems:
            self.say("Setup: " + " ".join(problems))

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(5000)
        self.server_timer = QTimer(self)
        self.server_timer.timeout.connect(self.check_servers)
        self.server_timer.start(60000)
        self.check_servers()

    # ── building blocks ──

    # The artwork is 900 x 600: a 200-high header, then stone with the two panels baked in (left 16-372, right
    # 389-884, both 206-556) and a gold rule above the status line. Bigger, the header is scaled to the width
    # (cropped from the top if that would leave the panels less than 400), the stone between it and the bottom
    # 40 is stretched, and the panels are drawn again, crisply, over where the stretched ones landed.

    def art_map(self):
        W, H = self.width(), self.height()
        hh = max(200.0, min(200.0 * W / 900.0, H - 400.0))
        sx, sy = W / 900.0, (H - 40.0 - hh) / 360.0
        def panel(x0, x1):
            return QRectF(int(x0 * sx) - 1, int(hh + 6 * sy) - 1, int(x1 * sx + 1) - int(x0 * sx) + 2,
                          int(hh + 356 * sy + 1) - int(hh + 6 * sy) + 2)
        return hh, panel(16, 372), panel(389, 884)

    def paintEvent(self, ev):
        p = QPainter(self)
        W, H = self.width(), self.height()
        if self.bg is None:
            p.fillRect(self.rect(), QColor(C_PANEL))
        elif W == 900 and H == 600:
            p.drawPixmap(0, 0, self.bg)
        else:
            p.setRenderHint(QPainter.SmoothPixmapTransform)
            hh, left, right = self.art_map()
            src = hh * 900.0 / W
            p.drawPixmap(QRectF(0, 0, W, hh), self.bg, QRectF(0, 200 - src, 900, src))
            p.drawPixmap(QRectF(0, hh, W, H - 40 - hh), self.bg, QRectF(0, 200, 900, 360))
            p.drawPixmap(QRectF(0, H - 40, W, 40), self.bg, QRectF(0, 560, 900, 40))
            self.draw_panel(p, left, "REALMS & CHARACTERS")
            self.draw_panel(p, right, "LOGIN")
        p.end()

    @staticmethod
    def draw_panel(p, r, title):
        """One of the artwork's panels: a cut-cornered double gold border, near-black inside, a title over a rule."""
        def cut(rect, c):
            x0, y0, x1, y1 = rect.left(), rect.top(), rect.right(), rect.bottom()
            return QPolygonF([QPointF(x0 + c, y0), QPointF(x1 - c, y0), QPointF(x1, y0 + c), QPointF(x1, y1 - c),
                              QPointF(x1 - c, y1), QPointF(x0 + c, y1), QPointF(x0, y1 - c), QPointF(x0, y0 + c)])
        p.setRenderHint(QPainter.Antialiasing)
        outer = r.adjusted(1, 1, -1, -1)
        p.setPen(QPen(QColor(108, 84, 46), 2))
        p.setBrush(QColor(12, 11, 9))
        p.drawPolygon(cut(outer, 4))
        p.setBrush(Qt.NoBrush)
        p.setPen(QPen(QColor(60, 47, 28), 1))
        p.drawPolygon(cut(r.adjusted(4.5, 4.5, -4.5, -4.5), 3))
        p.setRenderHint(QPainter.Antialiasing, False)
        p.setPen(QPen(QColor(90, 70, 40), 1))
        p.drawLine(int(r.left() + 14), int(r.top() + 34), int(r.right() - 14), int(r.top() + 34))
        f = head_font(16)
        f.setLetterSpacing(QFont.AbsoluteSpacing, 1.5)
        p.setFont(f)
        p.setPen(QColor(C_GOLD))
        p.drawText(int(r.left() + 17), int(r.top() + 27), title)

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        self.relayout()

    def relayout(self):
        """Puts the widgets in the panels (at 900 x 600 exactly where they were drawn for the artwork)."""
        W, H = self.width(), self.height()
        _hh, L, R = self.art_map()
        lx, ly, lr, lb = int(L.left()) + 1, int(L.top()) + 1, int(L.right()), int(L.bottom())
        # left: the tree fills the panel, the two buttons along its bottom (Launch ticked takes the extra width)
        self.tree.setGeometry(lx + 14, ly + 44, lr - lx - 26, lb - ly - 94)
        self.new_btn.setGeometry(lx + 14, lb - 40, 140, 30)
        self.launch_btn.setGeometry(lx + 164, lb - 40, lr - lx - 176, 30)
        # right: the form from the top, its fields sharing the extra width; Enter the World along the bottom
        x, y, rb = int(R.left()) + 18, int(R.top()) + 1, int(R.bottom())
        cw = int(R.right()) - 18 - x
        half = (cw - 10) // 2
        aw = cw - 230
        self.l_server.move(x, y + 42); self.server.setGeometry(x, y + 62, 140, 26)
        self.l_address.move(x + 150, y + 42); self.host.setGeometry(x + 150, y + 62, aw, 26)
        self.l_port.move(x + 160 + aw, y + 42); self.port.setGeometry(x + 160 + aw, y + 62, 70, 26)
        self.l_account.move(x, y + 96); self.account.setGeometry(x, y + 116, half, 26)
        self.l_password.move(x + half + 10, y + 96); self.password.setGeometry(x + half + 10, y + 116, cw - half - 10, 26)
        self.l_character.move(x, y + 150); self.character.setGeometry(x, y + 170, half, 26)
        self.l_play_in.move(x + half + 10, y + 150); self.client.setGeometry(x + half + 10, y + 170, cw - half - 10, 26)
        self.restart.setGeometry(x, y + 204, min(190, half), 24)
        self.corner.setGeometry(x + half + 10, y + 203, cw - half - 10, 26)
        # Save / Delete / Settings with Stop and Kill at their right, then the account's state on a line of its own
        bw = cw - 170
        third = (bw - 22) // 3
        self.save_btn.setGeometry(x, y + 236, third, 30)
        self.delete_btn.setGeometry(x + third + 11, y + 236, third, 30)
        self.settings_btn.setGeometry(x + 2 * third + 22, y + 236, bw - 2 * third - 22, 30)
        self.stop_btn.setGeometry(x + cw - 160, y + 238, 76, 26)
        self.kill_btn.setGeometry(x + cw - 76, y + 238, 76, 26)
        self.state.setGeometry(x, y + 274, cw, 24)
        self.enter_btn.setGeometry(x, max(y + 308, rb - 46), cw, 38)
        # along the bottom
        self.status.setGeometry(16, H - 28, W - 216, 22)
        self.credit.setGeometry(W - 200, H - 28, 186, 22)

    def button(self, text, x, y, w, h, fn, size=14):
        b = QPushButton(text, self)
        b.setGeometry(x, y, w, h)
        b.setFont(head_font(size))
        b.setStyleSheet("QPushButton { %s }" % css_font(F_HEAD, size, bold=True))
        b.setCursor(Qt.PointingHandCursor)
        b.setAutoDefault(False)
        b.clicked.connect(fn)
        return b

    def label(self, text, x, y):
        lab = QLabel(text, self)
        lab.setStyleSheet("color: %s; %s" % (C_GOLD, css_font(F_HEAD, 13, bold=True)))
        lab.move(x, y)
        lab.adjustSize()
        return lab

    def field(self, w, x, y, wd, h):
        w.setGeometry(x, y, wd, h)
        w.setFont(ui_font(13))
        return w

    # ── the tree ──

    def item_key(self, it):
        d = it.data(0, Qt.UserRole) or {}
        return (d.get("kind"), d.get("server"), d.get("account"), d.get("char"))

    def characters_of(self, a, all_of_them=False):
        """The account's characters: the ones its character screen last listed (kept in the settings as
        "characters_seen", so they stay while it's in the game or closed). The tree leaves out the hidden ones; the
        Character list (all_of_them) has every one."""
        hidden = set() if all_of_them else set(a.get("hidden_characters") or [])
        out = []
        seen = mtcore.known_characters(self.cfg, a["account"]) or list(a.get("characters_seen") or [])
        for c in [a.get("character") or ""] + seen:
            if c and c not in out and (c not in hidden or c == a.get("character")):
                out.append(c)
        return out

    def remember_characters(self):
        """Keeps each account's character-screen list in the settings (it's what the screen showed last, so a
        character deleted there goes from it too). True if any changed."""
        changed = False
        for a in self.cfg["accounts"]:
            known = mtcore.known_characters(self.cfg, a["account"])
            if known and known != list(a.get("characters_seen") or []):
                a["characters_seen"] = list(known)
                changed = True
        if changed:
            mtcore.save_config(self.cfg)
        return changed

    def fill_characters(self, a, pick=None):
        """The Character list: the character screen first, then every character on the account."""
        keep = pick or self.character.currentText().strip()
        self.character.blockSignals(True)
        self.character.clear()
        self.character.addItem(CHAR_SCREEN)
        for c in (self.characters_of(a, all_of_them=True) if a else []):
            self.character.addItem(c)
        self.character.setCurrentText(keep or CHAR_SCREEN)
        self.character.blockSignals(False)

    def rebuild(self):
        self.filling = True
        sel = self.tree.currentItem()
        sel_key = self.item_key(sel) if sel else None
        self.tree.clear()
        self.acct_items.clear()
        self.server_items.clear()
        names = [s["name"] for s in self.cfg["servers"]]
        for a in self.cfg["accounts"]:
            if a.get("server") and a["server"] not in names:
                names.append(a["server"])
        bold = ui_font(13, bold=True)
        reselect = None
        for sname in names:
            accts = [a for a in self.cfg["accounts"] if a.get("server") == sname]
            s = mtcore.find_server(self.cfg, sname) if hasattr(mtcore, "find_server") else \
                next((x for x in self.cfg["servers"] if x["name"] == sname), None)
            si = QTreeWidgetItem([sname, ""])
            si.setIcon(0, self.icons["server"])
            si.setData(0, Qt.UserRole, {"kind": "server", "server": sname})
            si.setFont(0, bold)
            si.setForeground(0, QColor(C_GOLD))
            si.setToolTip(0, "%s:%s" % (s["host"], s["port"]) if s else "not in the servers list")
            si.setFlags(si.flags() | Qt.ItemIsUserCheckable)
            si.setCheckState(0, Qt.Checked if accts and all(a.get("enabled", True) for a in accts) else Qt.Unchecked)
            self.tree.addTopLevelItem(si)
            self.server_items[sname] = si
            for a in accts:
                ai = QTreeWidgetItem([a["account"], ""])
                ai.setIcon(0, self.icons["account"])
                ai.setData(0, Qt.UserRole, {"kind": "account", "server": sname, "account": a["account"]})
                ai.setFlags(ai.flags() | Qt.ItemIsUserCheckable)
                ai.setCheckState(0, Qt.Checked if a.get("enabled", True) else Qt.Unchecked)
                ai.setToolTip(0, "Played in ACGodot" if a.get("client") == "acgodot" else "Played in Asheron's Call")
                si.addChild(ai)
                self.acct_items[a["account"]] = ai
                for c in self.characters_of(a):
                    ci = QTreeWidgetItem([c, ""])
                    ci.setIcon(0, self.icons["char"])
                    ci.setData(0, Qt.UserRole, {"kind": "char", "server": sname, "account": a["account"], "char": c})
                    ci.setFlags(ci.flags() | Qt.ItemIsUserCheckable)
                    mine = c == (a.get("character") or "")
                    ci.setCheckState(0, Qt.Checked if mine and a.get("enabled", True) else Qt.Unchecked)
                    if mine:
                        ci.setFont(0, bold)
                        ci.setForeground(0, QColor(C_GOLD))
                        ci.setToolTip(0, "Logs in as this one")
                    ai.addChild(ci)
                    if sel_key and self.item_key(ci) == sel_key:
                        reselect = ci
                ai.setExpanded(self.item_key(ai) not in self.collapsed)
                if sel_key and self.item_key(ai) == sel_key:
                    reselect = ai
            si.setExpanded(self.item_key(si) not in self.collapsed)
            if sel_key and self.item_key(si) == sel_key:
                reselect = si
        if reselect is not None:
            self.tree.setCurrentItem(reselect)
        self.filling = False
        self.refresh_servers_list()
        self.update_ticked()
        self.refresh()
        self.paint_servers()

    def find_acct(self, name):
        return mtcore.find_account(self.cfg, name) if name else None

    def on_tick(self, it, col):
        if self.filling or col != 0:
            return
        d = it.data(0, Qt.UserRole) or {}
        on = it.checkState(0) == Qt.Checked
        if d.get("kind") == "server":
            for a in self.cfg["accounts"]:
                if a.get("server") == d["server"]:
                    a["enabled"] = on
        elif d.get("kind") == "account":
            a = self.find_acct(d["account"])
            if a:
                a["enabled"] = on
        elif d.get("kind") == "char":
            a = self.find_acct(d["account"])
            if a:
                if on:
                    a["character"] = d["char"]
                    a["enabled"] = True
                    if d["char"] in (a.get("hidden_characters") or []):
                        a["hidden_characters"].remove(d["char"])
                elif a.get("character") == d["char"]:
                    # (its character unticked: the account stays ticked and goes to the character screen instead)
                    a["character"] = ""
        mtcore.save_config(self.cfg)
        QTimer.singleShot(0, self.after_tick)   # (rebuilt once the click is over)

    def after_tick(self):
        self.rebuild()
        if self.current:
            self.show_account(self.current, keep_password=True)

    def update_ticked(self):
        n = sum(1 for a in self.cfg["accounts"] if a.get("enabled", True))
        self.launch_btn.setText("Launch ticked (%d)" % n if n else "Launch ticked")

    def on_select(self, it):
        if self.filling or it is None:
            return
        d = it.data(0, Qt.UserRole) or {}
        if d.get("kind") == "server":
            self.show_account(None, server=d["server"])
        else:
            a = self.find_acct(d.get("account"))
            self.show_account(a, pick=d.get("char"))

    def tree_menu(self, pos):
        it = self.tree.itemAt(pos)
        if it is None:
            return
        self.tree.setCurrentItem(it)
        d = it.data(0, Qt.UserRole) or {}
        kind = d.get("kind")
        m = QMenu(self)
        if kind != "server":
            act = m.addAction("Launch %s" % d["char"] if kind == "char" else "Launch")
            f = act.font()
            f.setBold(True)
            act.setFont(f)
            act.triggered.connect(lambda: self.launch_item(it))
            m.addAction("Stop game", self.stop_current)
            m.addAction("Kill", self.kill_current)
            m.addSeparator()
        m.addAction("Add an account here", self.new_account)
        m.addSeparator()
        m.addAction({"char": "Forget %s" % d.get("char"), "account": "Delete account"}.get(kind, "Delete server"),
                    self.delete_selected)
        m.exec(self.tree.viewport().mapToGlobal(pos))

    # ── the login side ──

    def refresh_servers_list(self):
        t = self.server.currentText()
        self.server.blockSignals(True)
        self.server.clear()
        for s in self.cfg["servers"]:
            self.server.addItem(s["name"])
        self.server.setCurrentText(t)
        self.server.blockSignals(False)

    def server_picked(self, _i):
        s = next((x for x in self.cfg["servers"] if x["name"] == self.server.currentText()), None)
        if s:
            self.host.setText(s["host"])
            self.port.setText(str(s["port"]))

    def show_server(self, name):
        s = next((x for x in self.cfg["servers"] if x["name"] == name), None)
        self.server.setCurrentText(name or "")
        self.host.setText(s["host"] if s else "")
        self.port.setText(str(s["port"]) if s else "9000")

    def show_account(self, a, pick=None, server=None, keep_password=False):
        self.current = a
        if a:
            self.show_server(a.get("server", ""))
            self.account.setText(a["account"])
            if not keep_password:
                self.password.clear()
            self.client.setCurrentIndex(max(0, self.client.findData(a.get("client") or self.cfg.get("default_client") or "retail")))
            self.restart.setChecked(a.get("auto_restart", True))
            self.corner.setCurrentIndex(max(0, self.corner.findData(a.get("window_corner") or "top-left")))
        else:
            if server:
                self.show_server(server)
            elif self.cfg["servers"]:
                self.show_server(self.cfg["servers"][0]["name"])
            self.account.clear()
            self.password.clear()
            self.client.setCurrentIndex(max(0, self.client.findData(self.cfg.get("default_client") or "retail")))
            self.restart.setChecked(True)
            self.corner.setCurrentIndex(0)
        self.fill_characters(a, pick or (a.get("character") if a else "") or CHAR_SCREEN)
        self.delete_btn.setEnabled(self.tree.currentItem() is not None)
        self.show_state()

    def show_state(self):
        a = self.current
        if not a:
            self.state.setText("New account: fill it in and Save" if not self.tree.currentItem() or
                               (self.tree.currentItem().data(0, Qt.UserRole) or {}).get("kind") != "server"
                               else "Edit the address and Save, or add an account")
            self.state.setStyleSheet("color: %s; %s" % (C_DIM, css_font(F_UI, 13, italic=True)))
            self.stop_btn.setEnabled(False)
            self.kill_btn.setEnabled(False)
            return
        text, short, color = self.account_state(a)
        self.state.setText(text)
        self.state.setToolTip(text)
        self.state.setStyleSheet("color: %s; %s" % (color, css_font(F_UI, 13, bold=True)))
        running = bool(mtcore.client_pids(a["account"]))
        self.stop_btn.setEnabled(running)
        self.kill_btn.setEnabled(running)

    def account_state(self, a, plans=None):
        """(long text, short text for the tree, colour)"""
        st = mtcore.read_status(self.cfg, a["account"])
        state = mtcore.client_state(st)
        if state == "offline":
            plan = (plans if plans is not None else self.back_plans()).get(a["account"], "")
            if plan:
                return "Offline - " + plan, "comes back", C_BLUE
            return "Offline", "offline", C_DIM
        if state == "charselect":
            note = (st.get("loginNote") or "").strip()
            return "Character screen" + (" - " + note if note else ""), "char screen", C_AMBER
        t = since(mtcore.parse_iso(st.get("loginTime")))
        text = "In game: %s" % st.get("character", "") + (" - %s" % t if t else "")
        if st.get("paused"):
            text += " (paused by %s)" % st.get("pausedBy", "")
        elif not st.get("master", True):
            text += " (MelkTank OFF)"
        return text, ("in game " + t) if t else "in game", C_GREEN

    def back_plans(self):
        try:
            # (what the phone service will do when the server comes back: it writes this, the launcher only reads it)
            path = os.path.join(mtcore.LOG_DIR, "server_back_plans.json")
            if os.path.exists(path) and time.time() - os.path.getmtime(path) < 6 * 3600:
                with open(path, encoding="utf-8") as f:
                    return json.load(f)
        except Exception:
            pass
        return {}

    def save_current(self, quiet=False):
        """Saves the server (always) and the account (when one is named). Returns the account, True for a server
        on its own, or None when something's missing."""
        name = self.account.text().strip()
        host = self.host.text().strip()
        sname = self.server.currentText().strip() or host
        try:
            port = int(self.port.text().strip())
        except ValueError:
            port = 0
        if not host or not port:
            QMessageBox.warning(self, "Save", "Fill in the server's address and port.")
            return None
        s = next((x for x in self.cfg["servers"] if x["name"] == sname), None)
        if s:
            s["host"], s["port"] = host, port
        else:
            self.cfg["servers"].append({"name": sname, "host": host, "port": port, "rodat": False, "slots": 11})
        if not name:
            if self.current:
                QMessageBox.warning(self, "Save", "Fill in the account name.")
                return None
            mtcore.save_config(self.cfg)
            self.rebuild()
            self.say("Saved the server %s." % sname)
            self.check_servers()
            return True
        a = self.current
        other = self.find_acct(name)
        if other is not None and other is not a:
            if a is not None:
                QMessageBox.warning(self, "Save", "%s is already in the list." % name)
                return None
            a = other
        if a is None:
            a = {"account": name, "password": "", "server": sname, "character": "", "enabled": True}
            self.cfg["accounts"].append(a)
        a["account"] = name
        a["server"] = sname
        if self.password.text():
            a["password"] = self.password.text()
            self.password.clear()
        ch = self.character.currentText().strip()
        a["character"] = "" if ch == CHAR_SCREEN else ch
        if a["character"] in (a.get("hidden_characters") or []):
            a["hidden_characters"].remove(a["character"])
        a["client"] = self.client.currentData()
        a["auto_restart"] = self.restart.isChecked()
        a["window_corner"] = self.corner.currentData()
        mtcore.save_config(self.cfg)
        self.current = a
        self.rebuild()
        it = self.acct_items.get(name)
        if it is not None:
            self.filling = True
            self.tree.setCurrentItem(it)
            self.filling = False
        self.show_account(a)
        if not quiet:
            self.say("Saved %s." % name + ("" if a.get("password") else " (no password saved yet)"))
        return a

    def new_account(self):
        it = self.tree.currentItem()
        sname = (it.data(0, Qt.UserRole) or {}).get("server") if it else None
        self.filling = True
        self.tree.setCurrentItem(None)
        self.tree.clearSelection()
        self.filling = False
        self.show_account(None, server=sname)
        self.say("New account: fill it in and click Save.")
        self.account.setFocus()

    def delete_selected(self):
        it = self.tree.currentItem()
        if it is None:
            return
        d = it.data(0, Qt.UserRole) or {}
        kind = d.get("kind")
        if kind == "char":
            a = self.find_acct(d["account"])
            c = d["char"]
            if not a or QMessageBox.question(self, "Forget", "Forget %s on %s?" % (c, a["account"])) != QMessageBox.Yes:
                return
            a.setdefault("hidden_characters", [])
            if c not in a["hidden_characters"]:
                a["hidden_characters"].append(c)
            if a.get("character") == c:
                a["character"] = ""
            self.say("Forgot %s." % c)
        elif kind == "account":
            a = self.find_acct(d["account"])
            if not a or QMessageBox.question(self, "Delete", "Delete %s from the launcher?" % a["account"]) != QMessageBox.Yes:
                return
            self.cfg["accounts"].remove(a)
            self.current = None
            self.say("Deleted %s." % a["account"])
        else:
            sname = d["server"]
            accts = [a for a in self.cfg["accounts"] if a.get("server") == sname]
            msg = ("Delete %s and its %d account(s) from the launcher?" % (sname, len(accts)) if accts
                   else "Delete %s from the launcher?" % sname)
            if QMessageBox.question(self, "Delete", msg) != QMessageBox.Yes:
                return
            for a in accts:
                self.cfg["accounts"].remove(a)
            self.cfg["servers"] = [s for s in self.cfg["servers"] if s["name"] != sname]
            self.current = None
            self.say("Deleted %s." % sname)
        mtcore.save_config(self.cfg)
        self.rebuild()
        if self.current is None:
            self.show_account(None)
        else:
            self.show_account(self.current)

    def stop_current(self):
        if self.current:
            self.stop_game(self.current["account"])

    def kill_current(self):
        if self.current:
            self.kill_game(self.current["account"])

    def enter_world(self):
        a = self.save_current(quiet=True)
        if not isinstance(a, dict):
            if a is True:
                self.say("Pick or add an account to launch.")
            return
        self.launch([a["account"]])

    def launch_item(self, it):
        d = it.data(0, Qt.UserRole) or {}
        if d.get("kind") == "server":
            return
        a = self.find_acct(d.get("account"))
        if not a:
            return
        if d.get("kind") == "char" and a.get("character") != d["char"]:
            a["character"] = d["char"]
            mtcore.save_config(self.cfg)
            self.rebuild()
        self.launch([a["account"]])

    # ── status ──

    def refresh(self):
        if self.remember_characters():
            self.rebuild()
            if self.current is not None and not self.character.hasFocus():
                self.fill_characters(self.current)
        plans = self.back_plans()
        for a in self.cfg["accounts"]:
            it = self.acct_items.get(a["account"])
            if it is None:
                continue
            text, short, color = self.account_state(a, plans)
            self.filling = True
            it.setText(1, short)
            it.setForeground(1, QColor(color))
            it.setTextAlignment(1, Qt.AlignRight | Qt.AlignVCenter)
            it.setToolTip(1, text)
            self.filling = False
        self.show_state()

    def stop_game(self, name):
        if not mtcore.client_pids(name):
            self.say("No running client found for %s." % name)
            return
        mtcore.send_command(self.cfg, name, "quit")
        mtcore.event(name, "closed_launcher", "Stop game from the launcher")
        self.say("Asked %s to log out and close the game." % name)

    def kill_game(self, name):
        if not mtcore.client_pids(name):
            self.say("No running client found for %s." % name)
            return
        if QMessageBox.question(self, "Kill the game", "End %s's game process right now?\n(Nothing is saved first - use Stop for a normal exit.)" % name) != QMessageBox.Yes:
            return

        def work():
            ok, msg = mtcore.kill_client(self.cfg, name, wait=1.0, kind="closed_launcher", why="Killed from the launcher",
                                         note="Closed from the launcher")
            self.bus.message.emit(msg)
        threading.Thread(target=work, daemon=True).start()

    # ── services (shown on the Settings page) ──

    def decal_state(self):
        running = bool(mtcore.decal_agent_pids())
        on = (mtcore.load_config().get("decal_agent") or {}).get("enabled", True)
        if running:
            return True, "Running", C_GREEN
        return False, "Stopped" + ("" if on else " (kept off)"), C_AMBER if on else C_DIM

    def ace_there(self):
        return os.path.isdir(os.path.join(mtcore.ace_root(self.cfg), "Source", "ACE.Server"))

    def ace_state(self):
        pids = mtcore.ace_pids()
        if not pids:
            return False, "Stopped", C_DIM
        started = ""
        try:
            started = since(datetime.fromtimestamp(os.stat("/proc/%d" % pids[0]).st_mtime, timezone.utc))
        except Exception:
            started = ""
        return True, "Running" + (" - " + started if started else ""), C_GREEN

    def toggle_ace(self):
        running = bool(mtcore.ace_pids())
        self.say("Stopping the ACE server (saving first)..." if running else "Starting the ACE server...")

        def work():
            ok, msg = mtcore.ace_stop(self.cfg) if running else mtcore.ace_start(self.cfg)
            self.bus.message.emit(msg)
        threading.Thread(target=work, daemon=True).start()

    def toggle_decal(self):
        running = bool(mtcore.decal_agent_pids())

        def work():
            ok, msg = mtcore.set_decal(not running)
            self.cfg.setdefault("decal_agent", {})["enabled"] = not running   # so saving Settings later keeps it
            self.bus.message.emit(msg)
        threading.Thread(target=work, daemon=True).start()

    # ── dialogs ──

    def edit_servers(self, parent=None):
        d = ServersDialog(self.cfg, parent or self)
        if d.exec():
            self.cfg["servers"] = d.value()
            mtcore.save_config(self.cfg)
            self.rebuild()
            self.check_servers()

    def edit_acg_plugins(self, parent=None):
        if AcgPluginsDialog(self.cfg, parent or self).exec():
            self.say("ACGodot plugins saved - they apply the next time ACGodot starts.")

    def edit_settings(self):
        d = SettingsDialog(self.cfg, self)
        if d.exec():
            d.apply(self.cfg)
            mtcore.save_config(self.cfg)
            problems = mtcore.check_setup(self.cfg)
            self.say("Setup: " + " ".join(problems) if problems else "Settings saved.")

    # ── servers ──

    def check_servers(self):
        servers = list(self.cfg["servers"])

        def work():
            for s in servers:
                self.bus.server.emit(s["name"], mtcore.server_up(s["host"], s["port"]))
        threading.Thread(target=work, daemon=True).start()

    def check_now(self):
        self.server_states.clear()
        self.paint_servers()
        mtcore.ask_server_check()
        self.check_servers()

    def on_server(self, name, up):
        self.server_states[name] = up
        self.paint_servers()

    def paint_servers(self):
        for name, it in self.server_items.items():
            v = self.server_states.get(name, "?")
            text, color = (("up", C_GREEN) if v is True else ("down", C_RED) if v is False
                           else ("no address", C_DIM) if v is None else ("checking", C_DIM))
            self.filling = True
            it.setText(1, text)
            it.setForeground(1, QColor(color))
            it.setTextAlignment(1, Qt.AlignRight | Qt.AlignVCenter)
            self.filling = False

    # ── launching ──

    def launch_ticked(self):
        self.launch([a["account"] for a in self.cfg["accounts"] if a.get("enabled", True)])

    def launch(self, names):
        if self.busy:
            self.say("Still launching - one moment.")
            return
        if not names:
            self.say("Nothing ticked - tick the characters (or accounts) to launch first.")
            return
        # online already (its status says so, or its game is running): asked first - No is the default, so Enter
        # (which also means Enter the World) doesn't start a second copy by accident
        running = []
        for n in names:
            st = mtcore.read_status(self.cfg, n)
            state = mtcore.client_state(st)
            if state == "online":
                running.append("%s (in game as %s)" % (n, st.get("character") or "?"))
            elif state == "charselect":
                running.append("%s (at the character screen)" % n)
            elif mtcore.client_pids(n):
                running.append("%s (its game is open)" % n)
        if running:
            box = QMessageBox(QMessageBox.Question, "Already online",
                              "This looks like it's already online:\n\n  " + "\n  ".join(running) +
                              "\n\nAre you sure you want to start another client?", QMessageBox.Yes | QMessageBox.No, self)
            box.setDefaultButton(QMessageBox.No)
            if box.exec() != QMessageBox.Yes:
                names = [n for n in names if not any(r.startswith(n + " (") for r in running)]
                if not names:
                    self.say("Not launched - already online.")
                    return
        self.busy = True
        self.launch_btn.setEnabled(False)
        self.enter_btn.setEnabled(False)
        cfg = mtcore.load_config()

        def work():
            mtcore.launch_many(cfg, names, progress=self.bus.message.emit, manual=True)   # you're at the PC: keep the focus
            self.bus.done.emit()
        threading.Thread(target=work, daemon=True).start()

    def on_launch_done(self):
        self.busy = False
        self.launch_btn.setEnabled(True)
        self.enter_btn.setEnabled(True)
        self.cfg = mtcore.load_config()   # (launching notes things in the config)
        self.current = self.find_acct(self.current["account"]) if self.current else None
        self.rebuild()

    def say(self, text):
        self.status.setText(datetime.now().strftime("%H:%M:%S  ") + text)
        self.status.setToolTip(text)

    def open_server_console(self, parent=None):
        d = ServerConsoleDialog(self.cfg, parent or self)
        d.setAttribute(Qt.WA_DeleteOnClose)
        d.show()

    def open_client_log(self, parent=None):
        d = ClientLogDialog(self.cfg, parent or self)
        d.setAttribute(Qt.WA_DeleteOnClose)
        d.show()

    def open_log(self):
        _open_file(mtcore.LOG_PATH)


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("ACGodot Launcher")
    load_look(app)
    w = Main()
    w.show()
    ret = app.exec()
    # tidy up while Qt is still running, so closing the window doesn't print
    # "shared QObject was deleted directly"
    w.timer.stop()
    w.server_timer.stop()
    w.deleteLater()
    app.processEvents()
    del w
    sys.exit(ret)


if __name__ == "__main__":
    main()
