# ACGodot for Windows

The same ACGodot as on Linux - the same game files, the same plugins (MelkTank, MelksQB). Godot itself isn't
included (it's big): `Start ACGodot.bat` downloads Godot 4.7.2 .NET for Windows from Godot's own releases on GitHub
the first time (about 115 MB) and puts it in the `Godot` folder.

## Starting it

1. Install the **.NET 10 runtime** (x64) - or the .NET 10 SDK - from https://dotnet.microsoft.com/download/dotnet/10.0
   (`Start ACGodot.bat` checks for it and opens that page when it's missing).
2. Double-click **Start ACGodot.bat**. (`ACGodot (with console).bat` is the same with a window showing what the game
   prints - for when something goes wrong.)
3. The AC data files (`client_portal.dat`, `client_cell_1.dat`, ...) are looked for in `C:\Turbine\Asheron's Call`,
   `C:\Program Files (x86)\Turbine\Asheron's Call`, `C:\Games\Asheron's Call` and `C:\AC`. Somewhere else: start with
   `"Start ACGodot.bat" --dat-dir="D:\Where\They Are"`, set the `ACGODOT_DAT_DIR` environment variable, or change
   `dat_dir` in `%APPDATA%\Godot\app_userdata\ACGodot\acgodot.cfg` (made on the first start).
4. The server and login: Options (in the game) - turn on playing on a server, then the server, port, account and
   password.

Your settings, window places and the game's own files are kept in `%APPDATA%\Godot\app_userdata\ACGodot`.

## What's here

| | |
|---|---|
| `Start ACGodot.bat` | starts the game |
| `Godot\` | Godot 4.7.2 .NET for Windows, fetched on the first start (MIT licence - https://godotengine.org/license). No internet there: unzip `Godot_v4.7.2-stable_mono_win64.zip` (godotengine.org/download/archive) into it yourself - the .exe files and `GodotSharp` |
| `.godot\mono\temp\bin\Debug\` | the game itself (`ACGodot.dll`) and what it uses |
| `plugins\` | MelkTank, MelksQB and the Decal shim they run through - the same files as the Linux client's |
| `data\`, `shaders\`, `scenes\` | the game's data, shaders and scene |
| `fonts\` | Noto Sans (SIL Open Font License, `fonts\OFL.txt`) - the plugins' windows' font, which Windows doesn't have |
| `src\`, `vendor\`, `tools\` | the source, to build it again (`dotnet build ACGodot.csproj` with the .NET 10 SDK) |

The MelkTank Remote phone link needs the Linux launcher's phone service, so it isn't used here.
