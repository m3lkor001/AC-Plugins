# ACGodot

An Asheron's Call client built on Godot 4.7 (C#, .NET 10).

## Status: the world viewer

It opens your AC data files and lets you fly over Dereth: the landscape (terrain heights and the retail texture
blending of base textures, overlays and roads) and what stands on it - buildings, placed objects and the procedural
scenery (trees, rocks, bushes), building interiors and dungeons - streamed around the camera. Not yet: the sky,
creatures and NPCs, and the server connection.

## Running it

1. You need the .NET 10 SDK (`dotnet --list-sdks`) and Godot 4.7.2 .NET (mono).
2. Start Godot from a terminal that has `dotnet` on its PATH, open `project.godot` in this folder, then press **Build**
   (the hammer, top right) once, then **Run** (F5).
3. The data files are read from `/home/m3lkor/Games/ac/drive_c/Turbine/Asheron's Call` by default. To use another
   folder, change `dat_dir` in `~/.local/share/godot/app_userdata/ACGodot/acgodot.cfg`, start with
   `--dat-dir=/path`, or set `ACGODOT_DAT_DIR`.

### Controls

| Key | |
|---|---|
| Right mouse (hold) | look around |
| W A S D | move |
| Space / E, C / Q | up, down |
| Shift | 5x faster |
| Mouse wheel | change speed |
| F1 / F2 / F3 / F4 | Holtburg / Yaraq / Shoushi / Arwic |
| F5 | drop to the ground |
| Enter (or /) | go to: map coordinates (`42.1N 33.6E`), a landblock (`A9B4`) or a cell (`8B04012B`, as `/loc` shows it in game) |
| Esc | quit |

## Layout

| Path | What |
|---|---|
| `src/Main.cs` | the scene: camera, light, sky, on-screen text, data folder |
| `src/Dats.cs` | the data files, through DatReaderWriter |
| `src/World.cs` | coordinates: AC is Z-up, Godot is Y-up; AC (x, y, z) = Godot (x, z, -y) |
| `src/Terrain/` | landscape textures, landblock meshes, streaming |
| `src/Objects/` | models and their textures, what stands on each landblock, streaming |
| `shaders/terrain.gdshader` | the landscape blending |
| `vendor/OpenAC/` | OpenAC's C# client code (game rules, data decoding, meshing) |

## Credits

- **OpenAC** (MIT, Erik Nihlén and OpenAC contributors): `vendor/OpenAC` is the C# client's `AcDream.Core` and
  `AcDream.Plugin.Abstractions` (deprecated branch, commit af92a57), unchanged. The terrain shader and texture setup are
  ported from its renderer. See `vendor/OpenAC/LICENSE` and `vendor/OpenAC/NOTICE.md` for its licence and the work it
  builds on (DatReaderWriter, WorldBuilder, ACE, and others).
- **DatReaderWriter** (MIT, Chorizite) reads the data files.
- No game data is included; you supply your own.
