using System;
using System.Linq;
using System.Collections.Concurrent;
using System.Collections.Generic;
using AcDream.Core.Meshing;
using AcDream.Core.Textures;
using DatReaderWriter.DBObjs;
using DatReaderWriter.Enums;
using Godot;

namespace ACGodot.Objects;

/// <summary>
/// Models (GfxObjs) and their surfaces as Godot meshes and materials, built once and shared by every copy in the world.
/// The geometry comes from OpenAC's GfxObjMesh (retail polygon rules); textures are decoded with its SurfaceDecoder.
/// Meshes stay in AC's own local axes (Z up); an instance's transform turns them into Godot's (see <see cref="Xf"/>).
///
/// Threading: <see cref="Prepare"/> does the slow part (reading and decoding) on a worker thread; <see cref="Mesh"/>
/// creates the Godot resources and must be called on the main thread.
/// </summary>
public sealed class ObjectAssets
{
    private readonly Dats _dats;

    /// <summary>A model's parts, read and decoded but not yet uploaded.</summary>
    public sealed class Prepared
    {
        public readonly List<(uint surfaceId, TranslucencyKind kind, float luminosity, Vector3[] pos, Vector3[] nrm, Vector2[] uv, int[] idx)> Subs = new();
    }

    private readonly ConcurrentDictionary<ulong, Prepared?> _prepared = new();
    // a surface's decoded pixels are only kept until its material (or texture) is made - then they're on the graphics
    // card and the copy here goes (null: decoded again from the dats if another kind of material needs them)
    private readonly ConcurrentDictionary<uint, (DecodedTexture? tex, TranslucencyKind kind, float lum)> _surfaces = new();
    private readonly ConcurrentDictionary<uint, bool> _opaque = new();

    /// <summary>A prepared surface's pixels: the kept copy, or decoded again if it was let go.</summary>
    private DecodedTexture Pixels(uint surfaceId)
    {
        if (!_surfaces.TryGetValue(surfaceId, out var s)) return DecodedTexture.Magenta;
        return s.tex ?? DecodeSurface(surfaceId);
    }

    /// <summary>The pixels are on the graphics card now: the copy here goes.</summary>
    private void Release(uint surfaceId)
    {
        if (_surfaces.TryGetValue(surfaceId, out var s) && s.tex != null) _surfaces[surfaceId] = (null, s.kind, s.lum);
    }
    private readonly Dictionary<ulong, ArrayMesh?> _meshes = new();
    private readonly Dictionary<(uint, TranslucencyKind, bool), Material> _materials = new();

    private BaseMaterial3D.CullModeEnum _cull = BaseMaterial3D.CullModeEnum.Back;

    public int MeshCount => _meshes.Count;

    /// <summary>Which faces every model material hides (main thread).</summary>
    public void SetCulling(BaseMaterial3D.CullModeEnum cull)
    {
        _cull = cull;
        foreach (Material m in _materials.Values) if (m is BaseMaterial3D b) b.CullMode = cull;
    }
    public int MaterialCount => _materials.Count;

    public ObjectAssets(Dats dats) { _dats = dats; }

    // ── unloading what nothing uses (Options > Video: "Unload graphics nothing is using") ──
    // when each model was last asked for (any thread), and each Godot mesh (main thread)
    private readonly ConcurrentDictionary<ulong, double> _prepUsed = new();
    private readonly Dictionary<ulong, double> _meshUsed = new();
    private static double NowS => System.Environment.TickCount64 / 1000.0;

    /// <summary>
    /// Lets go of what nothing in the world is drawing any more (main thread): a Godot mesh or material nothing but this
    /// cache holds (no model on screen uses it), not asked for in <paramref name="maxAge"/> seconds - its graphics-card
    /// copy goes with it - and the read model it was made from. Made again from the game's files if it's needed again.
    /// </summary>
    public (int meshes, int materials, int models) Trim(double maxAge)
    {
        double now = NowS;
        int nm = 0, nmat = 0, np = 0;
        foreach (var k in _meshes.Keys.ToList())
        {
            var m = _meshes[k];
            double used = _meshUsed.TryGetValue(k, out var u) ? u : 0;
            if (now - used < maxAge) continue;
            if (m != null && m.GetReferenceCount() > 1) { _meshUsed[k] = now; continue; }   // (on screen: kept)
            _meshes.Remove(k); _meshUsed.Remove(k); nm++;
        }
        foreach (var k in _materials.Keys.ToList())
            if (_materials[k].GetReferenceCount() <= 1) { _materials.Remove(k); nmat++; }
        foreach (var kv in _prepUsed.ToArray())
        {
            if (now - kv.Value < maxAge) continue;
            ulong k = kv.Key;
            if (_meshes.ContainsKey(k) || _meshes.ContainsKey(ShellKey((uint)k)) || _meshes.ContainsKey(InteriorKey((uint)k))) continue;
            if (_prepared.TryRemove(k, out _)) np++;
            _prepUsed.TryRemove(k, out _);
        }
        return (nm, nmat, np);
    }

    /// <summary>A model's prepared parts (after <see cref="Prepare"/>), or null.</summary>
    public Prepared? GetPrepared(uint gfxObjId) { _prepUsed[gfxObjId] = NowS; return _prepared.TryGetValue(gfxObjId, out var p) ? p : null; }

    private readonly Dictionary<uint, ImageTexture> _textures = new();

    /// <summary>Whether a prepared surface's texture is solid everywhere (no see-through texels).</summary>
    public bool SurfaceOpaque(uint surfaceId)
    {
        return _opaque.TryGetValue(surfaceId, out bool o) && o;
    }

    /// <summary>A prepared surface's texture (main thread), for materials made elsewhere (the sky).</summary>
    public ImageTexture SurfaceTexture(uint surfaceId)
    {
        if (_textures.TryGetValue(surfaceId, out var t)) return t;
        DecodedTexture d = Pixels(surfaceId);
        Image img = Image.CreateFromData(d.Width, d.Height, false, Image.Format.Rgba8, d.Rgba8);
        if (d.Width > 1 || d.Height > 1) img.GenerateMipmaps();
        var t2 = _textures[surfaceId] = ImageTexture.CreateFromImage(img);
        Release(surfaceId);
        return t2;
    }

    private readonly Dictionary<uint, ImageTexture?> _icons = new();

    /// <summary>An item's icon (a RenderSurface, 0x06...) as a texture (main thread); null if it can't be read.</summary>
    public ImageTexture? Icon(uint renderSurfaceId)
    {
        if (renderSurfaceId == 0) return null;
        if (_icons.TryGetValue(renderSurfaceId, out var t)) return t;
        t = null;
        try
        {
            var rs = _dats.Get<RenderSurface>(renderSurfaceId);
            if (rs != null)
            {
                Palette? pal = rs.DefaultPaletteId != 0 ? _dats.Get<Palette>(rs.DefaultPaletteId) : null;
                var d = SurfaceDecoder.DecodeRenderSurface(rs, pal);
                if (d.Width > 0 && d.Height > 0) t = ImageTexture.CreateFromImage(Image.CreateFromData(d.Width, d.Height, false, Image.Format.Rgba8, d.Rgba8));
            }
        }
        catch (Exception ex) { GD.PushWarning($"icon 0x{renderSurfaceId:X8}: {ex.Message}"); }
        return _icons[renderSurfaceId] = t;
    }

    private readonly Dictionary<uint, ImageTexture> _particleTextures = new();

    /// <summary>
    /// A surface's texture for particles (main thread): its full authored translucency, as the client draws it -
    /// not limited the way it is for glass on buildings, or faint effects (light shafts, haze) come out far too strong.
    /// </summary>
    public ImageTexture ParticleTexture(uint surfaceId)
    {
        if (_particleTextures.TryGetValue(surfaceId, out var t)) return t;
        DecodedTexture d;
        try { d = DecodeSurface(surfaceId, false); } catch { d = DecodedTexture.Magenta; }
        Image img = Image.CreateFromData(d.Width, d.Height, false, Image.Format.Rgba8, d.Rgba8);
        if (d.Width > 1 || d.Height > 1) img.GenerateMipmaps();
        return _particleTextures[surfaceId] = ImageTexture.CreateFromImage(img);
    }

    /// <summary>Reads a model and decodes its textures (any thread). Cheap when it's already done.</summary>
    public void Prepare(uint gfxObjId)
    {
        _prepUsed[gfxObjId] = NowS;   // (before the look: kept from being let go of while it's being used)
        if (_prepared.ContainsKey(gfxObjId)) return;
        Prepared? p = null;
        try
        {
            GfxObj? g = _dats.Get<GfxObj>(gfxObjId);
            if (g != null)
            {
                p = new Prepared();
                foreach (GfxObjSubMesh sm in GfxObjMesh.Build(g, _dats))
                {
                    if (sm.Indices.Length < 3) continue;
                    int n = sm.Vertices.Length;
                    var pos = new Vector3[n];
                    var nrm = new Vector3[n];
                    var uv = new Vector2[n];
                    for (int i = 0; i < n; i++)
                    {
                        var v = sm.Vertices[i];
                        pos[i] = new Vector3(v.Position.X, v.Position.Y, v.Position.Z);
                        nrm[i] = new Vector3(v.Normal.X, v.Normal.Y, v.Normal.Z);
                        uv[i] = new Vector2(v.TexCoord.X, v.TexCoord.Y);
                    }
                    FixNormals(sm.Indices, pos, nrm);
                    int[] idx = FrontFacesClockwise(sm.Indices, pos, nrm);
                    p.Subs.Add((sm.SurfaceId, sm.Translucency, sm.Luminosity, pos, nrm, uv, idx));
                    PrepareSurface(sm.SurfaceId, sm.Translucency, sm.Luminosity);
                }
            }
        }
        catch (Exception ex) { GD.PushWarning($"model 0x{gfxObjId:X8}: {ex.Message}"); p = null; }
        _prepared[gfxObjId] = p;
    }

    /// <summary>The key a dungeon or building room (EnvCell) is kept under, apart from the models' ids.</summary>
    public static ulong CellKey(uint envCellId) => (1UL << 32) | envCellId;

    /// <summary>
    /// A room's walls, floor and ceiling (an EnvCell's CellStruct from its Environment, textured with the cell's own
    /// surface list), in the cell's local axes. Side rules as OpenAC's MeshExtractor reads them. Any thread.
    /// </summary>
    public void PrepareCell(EnvCell cell, uint envCellId)
    {
        ulong key = CellKey(envCellId);
        _prepUsed[key] = NowS;
        if (_prepared.ContainsKey(key)) return;
        Prepared? p = null;
        try
        {
            var env = _dats.Get<DatReaderWriter.DBObjs.Environment>(0x0D000000u | cell.EnvironmentId);
            if (env != null && env.Cells.TryGetValue(cell.CellStructure, out var cs))
            {
                p = new Prepared();
                var bySurface = new Dictionary<uint, (List<Vector3> pos, List<Vector3> nrm, List<Vector2> uv, List<int> idx, TranslucencyKind kind)>();
                // a room's portal polygons (its openings onto the next room or the outside) aren't drawn - the client
                // looks through them; some carry a texture (a cave's dirt over the way down)
                var portalPolys = new HashSet<int>();
                foreach (var cp in cell.CellPortals) portalPolys.Add((int)cp.PolygonId);
                // ...but a room that is nothing except its openings is a cap: a ceiling laid over the room below as a room of
                // its own, its one face both the opening and the tiles (the Town Network's ceiling). Those faces are drawn
                // where they carry a picture on the side that shows.
                bool cap = cs.Polygons.Count > 0 && System.Linq.Enumerable.All(cs.Polygons, kv => portalPolys.Contains((int)kv.Key));
                foreach (var (polyId, poly) in cs.Polygons)
                {
                    if (poly.VertexIds.Count < 3) continue;
                    // (and an opening that carries a real picture on its showing side is a floor or ceiling you see and the
                    // rooms meet at - a walkway over the stalls below it; the plain see-through ones are doorways)
                    bool opening = portalPolys.Contains((int)polyId);
                    if (opening && poly.Stippling == DatReaderWriter.Enums.StipplingType.NoPos) continue;
                    foreach (var cand in CellStructSideCandidates.GetCandidates((int)poly.SidesType))
                    {
                        short slot = cand.SurfaceSlot == CellStructPolygonSurfaceSide.Positive ? poly.PosSurface : poly.NegSurface;
                        if (slot < 0 || slot >= cell.Surfaces.Count) continue;
                        uint surfaceId = 0x08000000u | cell.Surfaces[slot];
                        Surface? surf = _dats.Get<Surface>(surfaceId);
                        if (surf == null || Skipped(surf)) continue;
                        if (opening && !cap && ((surf.Type & DatReaderWriter.Enums.SurfaceType.Base1Image) == 0 || (surf.Type & DatReaderWriter.Enums.SurfaceType.Translucent) != 0)) continue;
                        if (!bySurface.TryGetValue(surfaceId, out var b))
                        {
                            var kind = TranslucencyKindExtensions.FromSurfaceType(surf.Type);
                            b = (new List<Vector3>(), new List<Vector3>(), new List<Vector2>(), new List<int>(), kind);
                            bySurface[surfaceId] = b;
                            PrepareSurface(surfaceId, kind, surf.Luminosity);
                        }
                        bool negUv = cand.UvSlot == CellStructPolygonSurfaceSide.Negative;
                        bool noUv = CellStructSideCandidates.IsUvAbsent(cand, poly.Stippling);
                        int first = b.pos.Count;
                        bool ok = true;
                        for (int i = 0; i < poly.VertexIds.Count; i++)
                        {
                            if (!cs.VertexArray.Vertices.TryGetValue((ushort)poly.VertexIds[i], out var sw)) { ok = false; break; }
                            int uvi = 0;
                            if (!noUv)
                            {
                                if (negUv && i < poly.NegUVIndices.Count) uvi = poly.NegUVIndices[i];
                                else if (i < poly.PosUVIndices.Count) uvi = poly.PosUVIndices[i];
                            }
                            var t = uvi >= 0 && uvi < sw.UVs.Count ? new Vector2(sw.UVs[uvi].U, sw.UVs[uvi].V) : Vector2.Zero;
                            var n = new Vector3(sw.Normal.X, sw.Normal.Y, sw.Normal.Z) * cand.NormalSign;
                            b.pos.Add(new Vector3(sw.Origin.X, sw.Origin.Y, sw.Origin.Z));
                            b.nrm.Add(n.Normalized());
                            b.uv.Add(t);
                        }
                        if (!ok) { int extra = b.pos.Count - first; b.pos.RemoveRange(first, extra); b.nrm.RemoveRange(first, extra); b.uv.RemoveRange(first, extra); continue; }
                        for (int i = 1; i + 1 < poly.VertexIds.Count; i++) { b.idx.Add(first); b.idx.Add(first + i); b.idx.Add(first + i + 1); }
                    }
                }
                foreach (var kv in bySurface)
                {
                    if (kv.Value.idx.Count < 3) continue;
                    var pos = kv.Value.pos.ToArray(); var nrm = kv.Value.nrm.ToArray();
                    var src = new uint[kv.Value.idx.Count];
                    for (int i = 0; i < src.Length; i++) src[i] = (uint)kv.Value.idx[i];
                    FixNormals(src, pos, nrm);
                    p.Subs.Add((kv.Key, kv.Value.kind, 0f, pos, nrm, kv.Value.uv.ToArray(), FrontFacesClockwise(src, pos, nrm)));
                }
            }
        }
        catch (Exception ex) { GD.PushWarning($"cell 0x{envCellId:X8}: {ex.Message}"); p = null; }
        _prepared[key] = p;
    }

    /// <summary>Some models carry zero-length normals (they come out NaN): those get their triangle's own normal.</summary>
    private static void FixNormals(uint[] idx, Vector3[] pos, Vector3[] nrm)
    {
        for (int t = 0; t + 2 < idx.Length; t += 3)
        {
            int a = (int)idx[t], b = (int)idx[t + 1], c = (int)idx[t + 2];
            Vector3 face = (pos[b] - pos[a]).Cross(pos[c] - pos[a]);
            Vector3 f = face.LengthSquared() > 1e-12f ? face.Normalized() : Vector3.Up;
            foreach (int i in new[] { a, b, c })
                if (!(nrm[i].IsFinite() && nrm[i].LengthSquared() > 1e-8f)) nrm[i] = f;
        }
        for (int i = 0; i < nrm.Length; i++) if (!(nrm[i].IsFinite() && nrm[i].LengthSquared() > 1e-8f)) nrm[i] = Vector3.Up;
    }

    /// <summary>
    /// Godot draws clockwise triangles as the front. AC's polygons carry outward normals, so each triangle is put in
    /// the order that's clockwise seen from the side its normals point to (so back-face culling keeps the right side).
    /// </summary>
    private static int[] FrontFacesClockwise(uint[] src, Vector3[] pos, Vector3[] nrm)
    {
        var idx = new int[src.Length];
        for (int i = 0; i + 2 < src.Length; i += 3)
        {
            int a = (int)src[i], b = (int)src[i + 1], c = (int)src[i + 2];
            Vector3 face = (pos[b] - pos[a]).Cross(pos[c] - pos[a]);
            Vector3 n = nrm[a] + nrm[b] + nrm[c];
            // counter-clockwise about the normal (right-hand rule) - swap to clockwise
            if (face.Dot(n) > 0) (b, c) = (c, b);
            idx[i] = a; idx[i + 1] = b; idx[i + 2] = c;
        }
        return idx;
    }

    private readonly ConcurrentDictionary<uint, bool> _untextured = new();

    /// <summary>The key a building's shell is kept under: the model without its untextured surfaces (doorway and
    /// window fills), which retail doesn't draw on buildings - you see into the rooms instead.</summary>
    public static ulong ShellKey(uint gfxObjId) => (2UL << 32) | gfxObjId;

    /// <summary>Plain-colour surfaces on buildings and rooms are the doorway and window fills retail doesn't draw.</summary>
    private static bool Skipped(Surface s) => RetailUntexturedSurfacePolicy.IsUntextured(s.Type);

    private void PrepareSurface(uint surfaceId, TranslucencyKind kind, float lum)
    {
        if (_surfaces.ContainsKey(surfaceId)) return;
        Surface? sf = _dats.Get<Surface>(surfaceId);
        _untextured[surfaceId] = sf != null && Skipped(sf);
        DecodedTexture d = DecodeSurface(surfaceId);
        bool opaque = true;
        byte[] px = d.Rgba8;
        for (int i = 3; i < px.Length; i += 4) if (px[i] < 250) { opaque = false; break; }
        _opaque[surfaceId] = opaque;
        _surfaces[surfaceId] = (d, kind, lum);
    }

    /// <summary>A Surface's texture (or solid colour), as OpenAC's TextureCache decodes it.</summary>
    private DecodedTexture DecodeSurface(uint surfaceId, bool capTranslucency = true)
    {
        Surface? s = _dats.Get<Surface>(surfaceId);
        if (s == null) return DecodedTexture.Magenta;
        // the dat's Translucency only counts when the surface is flagged Translucent (as retail and OpenAC's mesher do)
        float opacity = TranslucencyKindExtensions.OpacityFromSurfaceTranslucency(s.Type, s.Translucency);
        if (s.Type.HasFlag(SurfaceType.Base1Solid) || (uint)s.OrigTextureId == 0)
        {
            // a solid colour (window glass is usually one): the colour's own alpha byte is often 0 in the dat and
            // isn't used - only the surface's translucency is
            if (s.ColorValue == null) return DecodedTexture.Magenta;
            bool seeThrough = s.Type.HasFlag(SurfaceType.Translucent) || s.Type.HasFlag(SurfaceType.Alpha) || s.Type.HasFlag(SurfaceType.InvAlpha);
            float a = seeThrough ? opacity : 1f;
            return new DecodedTexture(new byte[] { s.ColorValue.Red, s.ColorValue.Green, s.ColorValue.Blue, (byte)(a * 255f) }, 1, 1);
        }
        SurfaceTexture? st = _dats.Get<SurfaceTexture>((uint)s.OrigTextureId);
        if (st == null || st.Textures.Count == 0) return DecodedTexture.Magenta;
        RenderSurface? rs = _dats.Get<RenderSurface>((uint)st.Textures[0]);
        if (rs == null) return DecodedTexture.Magenta;
        Palette? pal = rs.DefaultPaletteId != 0 ? _dats.Get<Palette>(rs.DefaultPaletteId) : null;
        bool clip = s.Type.HasFlag(SurfaceType.Base1ClipMap), add = s.Type.HasFlag(SurfaceType.Additive);
        DecodedTexture d = SurfaceDecoder.DecodeRenderSurface(rs, pal, clip, add);
        if (opacity < 1f && !ReferenceEquals(d, DecodedTexture.Magenta)) d = SurfaceDecoder.ApplyAuthoredTranslucency(d, capTranslucency ? Math.Min(1f - opacity, 0.8f) : 1f - opacity);
        return d;
    }

    /// <summary>
    /// Several prepared pieces (a landblock's rooms) joined into one set of vertex arrays in Godot world space, one
    /// per surface - a dungeon is then a handful of draws instead of one per room. Any thread.
    /// </summary>
    public Prepared Merge(IEnumerable<(ulong key, System.Numerics.Matrix4x4 world)> pieces)
    {
        var acc = new Dictionary<(uint, TranslucencyKind), (List<Vector3> pos, List<Vector3> nrm, List<Vector2> uv, List<int> idx, float lum)>();
        foreach (var (key, world) in pieces)
        {
            _prepUsed[key] = NowS;
            if (!_prepared.TryGetValue(key, out var p) || p == null) continue;
            Transform3D xf = Xf(world);
            foreach (var sub in p.Subs)
            {
                if (!acc.TryGetValue((sub.surfaceId, sub.kind), out var a))
                    acc[(sub.surfaceId, sub.kind)] = a = (new List<Vector3>(), new List<Vector3>(), new List<Vector2>(), new List<int>(), sub.luminosity);
                int baseIdx = a.pos.Count;
                for (int i = 0; i < sub.pos.Length; i++)
                {
                    a.pos.Add(xf * sub.pos[i]);
                    a.nrm.Add((xf.Basis * sub.nrm[i]).Normalized());
                }
                a.uv.AddRange(sub.uv);
                foreach (int i in sub.idx) a.idx.Add(baseIdx + i);
            }
        }
        var merged = new Prepared();
        foreach (var kv in acc)
            merged.Subs.Add((kv.Key.Item1, kv.Key.Item2, kv.Value.lum, kv.Value.pos.ToArray(), kv.Value.nrm.ToArray(), kv.Value.uv.ToArray(), kv.Value.idx.ToArray()));
        return merged;
    }

    /// <summary>A Godot mesh from merged arrays (main thread).</summary>
    public ArrayMesh? MeshOf(Prepared p, bool interior = false)
    {
        if (p.Subs.Count == 0) return null;
        var mesh = new ArrayMesh();
        foreach (var sub in p.Subs)
        {
            var arrays = new Godot.Collections.Array();
            arrays.Resize((int)Godot.Mesh.ArrayType.Max);
            arrays[(int)Godot.Mesh.ArrayType.Vertex] = sub.pos;
            arrays[(int)Godot.Mesh.ArrayType.Normal] = sub.nrm;
            arrays[(int)Godot.Mesh.ArrayType.TexUV] = sub.uv;
            arrays[(int)Godot.Mesh.ArrayType.Index] = sub.idx;
            mesh.AddSurfaceFromArrays(Godot.Mesh.PrimitiveType.Triangles, arrays);
            mesh.SurfaceSetMaterial(mesh.GetSurfaceCount() - 1, Material(sub.surfaceId, sub.kind, sub.luminosity, interior));
        }
        return mesh;
    }

    /// <summary>The Godot mesh for a prepared model (main thread); null if it has nothing to draw.</summary>
    public ArrayMesh? Mesh(ulong gfxObjId)
    {
        _meshUsed[gfxObjId] = NowS;
        if (_meshes.TryGetValue(gfxObjId, out var m)) return m;
        bool shell = (gfxObjId >> 32) == 2, interior = (gfxObjId >> 32) == 3;
        ulong src = shell || interior ? gfxObjId & 0xFFFFFFFFUL : gfxObjId;
        _prepUsed[src] = NowS;
        if (!_prepared.TryGetValue(src, out var p) || p == null || p.Subs.Count == 0) { _meshes[gfxObjId] = null; return null; }
        var mesh = new ArrayMesh();
        foreach (var sub in p.Subs)
        {
            if (shell && _untextured.TryGetValue(sub.surfaceId, out bool u) && u) continue;
            var arrays = new Godot.Collections.Array();
            arrays.Resize((int)Godot.Mesh.ArrayType.Max);
            arrays[(int)Godot.Mesh.ArrayType.Vertex] = sub.pos;
            arrays[(int)Godot.Mesh.ArrayType.Normal] = sub.nrm;
            arrays[(int)Godot.Mesh.ArrayType.TexUV] = sub.uv;
            arrays[(int)Godot.Mesh.ArrayType.Index] = sub.idx;
            mesh.AddSurfaceFromArrays(Godot.Mesh.PrimitiveType.Triangles, arrays);
            mesh.SurfaceSetMaterial(mesh.GetSurfaceCount() - 1, Material(sub.surfaceId, sub.kind, sub.luminosity, interior));
        }
        if (mesh.GetSurfaceCount() == 0) mesh = null;
        _meshes[gfxObjId] = mesh;
        return mesh;
    }

    /// <summary>
    /// The key a model inside a building is kept under. Building rooms and what's in them are drawn after the
    /// doorways have been "opened" (see PortalPunch): in Godot's transparent pass, still opaque-looking and writing
    /// depth, so the ground is never cut away and only shows the rooms through doors and windows - as retail does.
    /// </summary>
    public static ulong InteriorKey(uint gfxObjId) => (3UL << 32) | gfxObjId;

    /// <summary>Draw order in the transparent pass: doorway openings, then rooms, then see-through things.</summary>
    public const int PunchPriority = -20, InteriorPriority = -10, TranslucentPriority = 10;

    private Material Material(uint surfaceId, TranslucencyKind kind, float lum, bool interior = false)
    {
        if (_materials.TryGetValue((surfaceId, kind, interior), out var mat)) return mat;
        DecodedTexture d = Pixels(surfaceId);
        var built = _materials[(surfaceId, kind, interior)] = BuildMaterial(d, kind, lum, interior);
        Release(surfaceId);
        return built;
    }

    /// <summary>A material for a decoded texture with a surface's blending (main thread; not cached).</summary>
    public Material BuildMaterial(DecodedTexture d, TranslucencyKind kind, float lum, bool interior = false, bool repeat = true)
    {
        byte[] px = d.Rgba8;
        if (interior && kind == TranslucencyKind.Opaque)
        {
            // drawn in the transparent pass, so the alpha counts: an opaque surface's texture may carry any alpha
            // (unused when it's drawn opaque), so it's made solid
            px = (byte[])px.Clone();
            for (int i = 3; i < px.Length; i += 4) px[i] = 255;
        }
        Image img = Image.CreateFromData(d.Width, d.Height, false, Image.Format.Rgba8, px);
        if (d.Width > 1 || d.Height > 1) img.GenerateMipmaps();
        var m = new StandardMaterial3D
        {
            AlbedoTexture = ImageTexture.CreateFromImage(img),
            TextureFilter = BaseMaterial3D.TextureFilterEnum.LinearWithMipmapsAnisotropic,
            TextureRepeat = repeat,
            Roughness = 1f,
            SpecularMode = BaseMaterial3D.SpecularModeEnum.Disabled,
            CullMode = _cull,
        };
        switch (kind)
        {
            case TranslucencyKind.ClipMap:
                m.Transparency = BaseMaterial3D.TransparencyEnum.AlphaScissor;
                m.AlphaScissorThreshold = 0.5f;
                break;
            case TranslucencyKind.AlphaBlend:
            case TranslucencyKind.InvAlpha:
                m.Transparency = BaseMaterial3D.TransparencyEnum.Alpha;
                break;
            case TranslucencyKind.Additive:
                m.Transparency = BaseMaterial3D.TransparencyEnum.Alpha;
                m.BlendMode = BaseMaterial3D.BlendModeEnum.Add;
                m.ShadingMode = BaseMaterial3D.ShadingModeEnum.Unshaded;
                break;
        }
        if (kind == TranslucencyKind.AlphaBlend || kind == TranslucencyKind.InvAlpha || kind == TranslucencyKind.Additive)
        {
            m.RenderPriority = TranslucentPriority;   // after the rooms behind them (window glass)
            m.CullMode = BaseMaterial3D.CullModeEnum.Disabled;   // glass is one sheet, seen from both sides
        }
        else if (interior)
        {
            m.Transparency = BaseMaterial3D.TransparencyEnum.Alpha;
            m.DepthDrawMode = BaseMaterial3D.DepthDrawModeEnum.Always;
            m.RenderPriority = InteriorPriority;
            if (kind == TranslucencyKind.ClipMap) { m.AlphaScissorThreshold = 0.5f; }
        }
        if (lum > 0f)
        {
            m.EmissionEnabled = true;
            m.EmissionTexture = m.AlbedoTexture;
            m.EmissionEnergyMultiplier = Math.Clamp(lum, 0f, 1f);
        }
        return m;
    }

    /// <summary>
    /// An AC transform (System.Numerics, row vectors, Z up) as a Godot transform that takes AC-local model points
    /// straight to Godot world points: AC (x, y, z) is Godot (x, z, -y).
    /// </summary>
    public static Transform3D Xf(System.Numerics.Matrix4x4 m)
    {
        static Vector3 R(float x, float y, float z) => new(x, z, -y);
        var basis = new Basis(R(m.M11, m.M12, m.M13), R(m.M21, m.M22, m.M23), R(m.M31, m.M32, m.M33));
        return new Transform3D(basis, R(m.M41, m.M42, m.M43));
    }
}
