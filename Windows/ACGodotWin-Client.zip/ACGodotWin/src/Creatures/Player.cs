using System;
using System.Linq;
using System.Collections.Generic;
using AcDream.Core.Physics;
using Godot;

namespace ACGodot.Creatures;

/// <summary>
/// The player character (Tab switches between it and the free camera): a person dressed from ACE's world database
/// (<see cref="Wcid"/>), walking on the landscape with the client's own motion table, keys as in the game: W run
/// (Shift: walk; G runs on its own until W or S), S back up, A / D turn, Q / E side-step. They move at the speed their animation is made for (the
/// motion table's own velocity), so feet don't slide. The camera stays behind them; right mouse looks around
/// (number pad as in the game: 4 / 6 swing it left / right, 8 / 2 raise / lower it, 0 puts it back behind them at the usual distance, + / - zoom out / in, Enter looks
/// straight down from overhead),
/// the mouse wheel zooms.
///
/// They move with the client's own collision (<see cref="Physics.WorldPhysics"/>): walls and objects stop them, floors,
/// stairs and upper storeys carry them, they fall off edges, and Space jumps (hold to jump higher, as in the game).
/// Until the collision around them is loaded they walk on the landscape.
/// </summary>
public partial class Player : Node3D
{
    /// <summary>Who the player looks like: a weenie with a full set of clothes, face and colours (the Academy Crier).</summary>
    public const int Wcid = 13242;

    // AC motion commands
    private const uint Falling = 0x40000015;
    private const uint Ready = 0x41000003, WalkForward = 0x45000005, WalkBackward = 0x45000006, RunForward = 0x44000007,
                       TurnRight = 0x6500000D, TurnLeft = 0x6500000E, SideStepRight = 0x6500000F, SideStepLeft = 0x65000010;
    // used if a motion table gives no velocity (m/s)
    private const float RunSpeed = 6.5f, WalkSpeed = 3.1f, BackSpeed = 2.0f, StrafeSpeed = 3.1f;
    private const float RunAnimRateDefault = 1.6f;     // a well-trained run: the run cycle (and its speed) a little faster
    /// <summary>How fast they run for their Run skill and burden (the game's run rate: 1 at nothing, 4.5 at a skill of 800) -
    /// the run cycle's speed, and so how fast they cover ground. Not given: a well-trained run.</summary>
    public Func<float>? RunRateOf;
    private float RunAnimRate { get { try { return RunRateOf != null ? Math.Clamp(RunRateOf(), 0.5f, 4.5f) : RunAnimRateDefault; } catch { return RunAnimRateDefault; } } }
    private const float SideAnimRate = 1.6f;    // side-stepping likewise
    private const float TurnRate = 1.6f;        // rad/s

    private CreatureAssets _assets = null!;
    private Func<Vector3, float?> _ground = null!;
    private FlyCamera _cam = null!;
    private CreatureAssets.Key _key;
    private Node3D? _body;
    private Skeleton3D? _skeleton;
    private AnimationSequencer? _seq;
    private uint _motion;
    private float _yaw, _bodyYaw, _pitch = -0.25f, _dist = 4.5f;   // _yaw: the camera's offset from behind them
    // the view the camera starts at and goes back to (the default-view key): the game's, or the one kept for this character
    private float _defPitch = -0.25f, _defDist = 4.5f;
    private string _camOf = "";
    private const string CamFile = "user://camera.cfg";

    /// <summary>This character's own default camera view, if one was kept (Options > Gameplay > Interface): used from now on, and now.</summary>
    public void UseCameraOf(string character)
    {
        if ((character ?? "") == _camOf) return;   // (told who we are again: the view stays as it's been moved)
        _camOf = character ?? "";
        _defPitch = -0.25f; _defDist = 4.5f;
        var cfg = new ConfigFile();
        if (_camOf.Length > 0 && global::ACGodot.SafeConfig.Load(cfg, CamFile) == Error.Ok && cfg.HasSection(_camOf))
        {
            _defPitch = Mathf.Clamp((float)cfg.GetValue(_camOf, "pitch", -0.25f).AsDouble(), -1.55f, 1.0f);
            _defDist = Mathf.Clamp((float)cfg.GetValue(_camOf, "distance", 4.5f).AsDouble(), 1.5f, 25f);
        }
        _pitch = _defPitch; _dist = _defDist; _yaw = 0f;
    }

    /// <summary>Keeps the camera's distance and angle as they are now as this character's default view. What was kept, in words.</summary>
    public string KeepCameraAsDefault()
    {
        _defPitch = _pitch; _defDist = _dist;
        if (_camOf.Length == 0) return "Kept for now (no character to keep it under).";
        var cfg = new ConfigFile();
        global::ACGodot.SafeConfig.Load(cfg, CamFile);
        cfg.SetValue(_camOf, "pitch", (double)_pitch);
        cfg.SetValue(_camOf, "distance", (double)_dist);
        global::ACGodot.SafeConfig.Save(cfg, CamFile);
        return $"Camera default kept for {_camOf}: {_dist:0.#} m back, {-Mathf.RadToDeg(_pitch):0}° down.";
    }
    private bool _looking;

    // collision
    private Physics.WorldPhysics? _physics;
    private AcDream.Core.Physics.PhysicsBody? _pbody;   // null until placed in the collision
    private uint _cell, _seedCell;
    private bool _holdHeight;
    private int _holdFails;
    /// <summary>The cell they stand in (0 while they're not in the collision).</summary>
    public uint Cell => _pbody != null ? _cell : 0;
    private int _placeFails;
    private float _jumpCharge = -1f, _airTime, _stuckTime;
    private double _jumpedAt = -10;   // (a jump of their own isn't taken off a steep slope)
    private bool _chargeStill;   // the jump being charged began standing still
    private bool _stopTillKeysUp;

    /// <summary>Stops them where they are (auto-run off, held keys ignored till pressed again) - a change of stance stops you, as in the game.</summary>
    public void StopMoving() { _autoRun = false; ApproachTo = null; _stopTillKeysUp = true; }
    private bool _autoRun, _gWas, _lastOk = true, _lastHit;
    private System.Numerics.Vector2 _wallNormal;
    private readonly System.Collections.Generic.List<(System.Numerics.Vector2 n, float t)> _walls = new();   // the last two walls hit
    private float _wallTime;

    /// <summary>
    /// Running into a wall at an angle carries them along it, as in the game: the part of their motion into the wall
    /// is turned along it, and the shallower the angle the nearer full speed (about 90% at 45 degrees; head-on they
    /// stop). The wall is the one the collision last reported, for a quarter of a second.
    /// </summary>
    private System.Numerics.Vector2 AlongWall(System.Numerics.Vector3 v)
    {
        var h = new System.Numerics.Vector2(v.X, v.Y);
        float speed = h.Length();
        if (_wallTime <= 0f || speed < 1e-3f) return h;
        float into = System.Numerics.Vector2.Dot(h, _wallNormal);
        if (into >= 0f) return h;                      // moving away from it
        var along = h - into * _wallNormal;
        float frac = along.Length() / speed;           // cos of the angle to the wall's face
        if (frac < 1e-3f) return System.Numerics.Vector2.Zero;
        return along / along.Length() * speed * MathF.Pow(frac, 0.3f);
    }
    /// <summary>For a jump: your Jump skill and how burdened you are (your burden over what you can carry: 1 = full).</summary>
    public Func<(int skill, float burden)>? JumpStats;
    /// <summary>Your stamina now, and taking what a jump costs.</summary>
    public Func<int>? StaminaNow;
    public Action<int>? UseStamina;
    /// <summary>How far the jump's charged (0 to 1), or -1 when Space isn't held. In a precise jump: its power.</summary>
    public float JumpCharge => _precise ? _precisePower : _jumpCharge;
    private const float JumpChargeTime = 1.0f;   // seconds holding Space for a full jump

    // ── the precise jump (Ctrl+Space): let go of both, W / S set the power a percent at a time, A / D (or the mouse)
    // aim, Shift held makes it the short jump, Space jumps, Esc calls it off. The arc and where it lands are drawn ──
    private bool _precise, _preciseSpaceUp, _spaceTillUp;
    private float _precisePower = 0.5f, _wsHeld, _wsRep;
    private int _wsDir;
    /// <summary>A precise jump is being set up.</summary>
    public bool PreciseJump => _precise;
    /// <summary>The arc drawn while an ordinary jump charges too (the Options); a precise jump always has it.</summary>
    public bool ShowArc;
    /// <summary>The line under the jump meter: what the keys do in a precise jump.</summary>
    public string JumpNote => _precise ? $"PRECISE JUMP  {_precisePower * 100f:0}%{(_preciseShortNow ? "  short" : "")}   click a spot to aim  W/S power  A/D aim  Shift short  Space jump  Esc cancel" : "";
    private bool _preciseShortNow;
    public void CancelPrecise() { _precise = false; _spaceTillUp = false; _preciseShortAuto = false; HideArc(); }

    /// <summary>
    /// A jump's speed up, as the game works it out: the height from your Jump skill and the charge (and less when
    /// burdened past what you can carry), at least 0.35 m; it costs stamina (more the fuller the charge and your pack),
    /// and without the stamina for it the jump is only as strong as what you have left.
    /// </summary>
    private float JumpSpeed(float power, bool spend = true)
    {
        var (skill, burden) = JumpStats?.Invoke() ?? (100, 0f);
        power = Math.Clamp(power, 0f, 1f);
        float per = (Math.Max(burden, 0f) + 0.5f) * 8f;
        int cost = (int)MathF.Ceiling(per * power + 2f);
        if (StaminaNow?.Invoke() is int st && st < cost) { power = Math.Clamp((st - 2f) / per, 0f, 1f); cost = Math.Min(st, (int)MathF.Ceiling(per * power + 2f)); }
        if (spend) UseStamina?.Invoke(cost);   // (the arc's preview works it out without spending any)
        float burdenMod = burden < 1f ? 1f : burden < 2f ? 2f - burden : 0f;
        float height = Math.Max(0.35f, burdenMod * (skill / (skill + 1300f) * 22.2f + 0.05f) * power);
        return MathF.Sqrt(2f * 9.8f * height);
    }

    public bool Active { get; private set; }
    public Audio.WorldAudio? Audio { get; set; }
    public CreatureAssets.Key LookKey => _key;
    /// <summary>The stance they're in (non-combat, a weapon's, magic).</summary>
    public uint Stance => _stance;
    /// <summary>The animation hooks your motion fired this frame (your attacks land on their AttackHooks).</summary>
    public Action<System.Collections.Generic.IReadOnlyList<DatReaderWriter.Types.AnimationHook>>? HooksFired;
    /// <summary>Somewhere to run to (an enemy you're attacking that's out of reach); null: you're steering.</summary>
    public Vector3? ApproachTo;
    /// <summary>Movement keys a plugin holds down (its nav): 1 forward, 2 back, 4 turn left, 8 turn right, 16 step left, 32 step right.</summary>
    public int PluginKeys;
    /// <summary>Auto-run (G) on or off.</summary>
    public bool AutoRun { get => _autoRun; set => _autoRun = value && !_dead; }
    /// <summary>In portal space: no moving until you come out.</summary>
    public bool Frozen;
    /// <summary>Logging out: no moving, by the keys or a plugin's nav, until it's done.</summary>
    public bool Leaving;
    /// <summary>Whether a cast under way holds the feet still for now; and, asked as a step begins, whether a cast's gesture is to be cut short for it.</summary>
    public Func<bool>? CastHold, CastCut;
    /// <summary>Whether a cast is under way: sidestepping then slides you along with the cast's gestures still playing.</summary>
    public Func<bool>? CastSlide;
    /// <summary>A heading to turn to (Godot yaw), at the normal turn speed; cleared once facing it or when you steer.</summary>
    public float? TurnToYaw;
    /// <summary>Off the ground (in a jump or falling).</summary>
    public bool Airborne => _pbody != null && !_pbody.OnWalkable;
    private float _pjPower = -1f; private int _pjKeys; private bool _pjWalk;
    /// <summary>A plugin's jump: power 0..1 (as a held Space), the way to go (PluginKeys bits: 1 forward, 2 back, 16 left, 32 right), walking or running.</summary>
    public void PluginJump(float power, int keys, bool walk) { _pjPower = Math.Clamp(power, 0f, 1f); _pjKeys = keys; _pjWalk = walk; }
    /// <summary>The run up to ApproachTo is a melee charge (10% quicker than running).</summary>
    public bool Charging;
    /// <summary>Whether a movement key was down this frame (it calls off running up to attack).</summary>
    public bool MovedByKeys { get; private set; }
    public bool Dead => _dead;
    public float BodyYaw => _bodyYaw;
    private bool _dead;
    private uint _stance = NonCombatStance;
    private const uint NonCombatStance = 0x8000003D, DeadMotion = 0x40000011;

    /// <summary>Something to keep the camera turned toward (Keep in View: the enemy you're fighting); null: free.</summary>
    public Vector3? KeepInView;
    private BoneAttachment3D? _weaponHold;
    private int _weaponWcid, _wantWeapon;
    private bool _weaponLeft, _wantWeaponLeft;

    /// <summary>
    /// Puts a weapon's model in their hand, or takes it away (0): the right hand - or, for a bow or crossbow, the left
    /// (where the game holds one: the arrow is drawn with the right).
    /// </summary>
    public void Wield(int wcid, bool leftHand = false)
    {
        _wantWeapon = wcid; _wantWeaponLeft = leftHand;
        if (_skeleton == null) return;   // not made yet: it's put in their hand when they are
        if (wcid == _weaponWcid && leftHand == _weaponLeft && (_weaponHold != null || wcid == 0)) return;
        _weaponWcid = wcid; _weaponLeft = leftHand;
        _weaponHold?.QueueFree();
        _weaponHold = null;
        if (wcid == 0) return;
        _weaponHold = leftHand
            ? Attach(wcid, DatReaderWriter.Enums.ParentLocation.LeftHand, DatReaderWriter.Enums.Placement.LeftHand, "Weapon")
              ?? Attach(wcid, DatReaderWriter.Enums.ParentLocation.RightHand, DatReaderWriter.Enums.Placement.RightHandCombat, "Weapon")
            : Attach(wcid, DatReaderWriter.Enums.ParentLocation.RightHand, DatReaderWriter.Enums.Placement.RightHandCombat, "Weapon");
    }

    private int _shieldWcid, _wantShield;
    private bool _wantShieldWeapon;
    private BoneAttachment3D? _shieldHold;

    /// <summary>A shield on the left arm (0: none), held where the game holds one.</summary>
    public void WieldShield(int wcid) => WieldOffHand(wcid, false);

    /// <summary>The off hand: a shield on the arm, or a second weapon in the left hand (dual wielding); 0 none.</summary>
    public void WieldOffHand(int wcid, bool weapon)
    {
        _wantShield = wcid; _wantShieldWeapon = weapon;
        if (_skeleton == null) return;
        if (wcid == _shieldWcid && (_shieldHold != null || wcid == 0)) return;
        _shieldWcid = wcid;
        _shieldHold?.QueueFree();
        _shieldHold = null;
        if (wcid == 0) return;
        _shieldHold = weapon
            ? Attach(wcid, DatReaderWriter.Enums.ParentLocation.LeftWeapon, DatReaderWriter.Enums.Placement.LeftWeapon, "OffHand")
              ?? Attach(wcid, DatReaderWriter.Enums.ParentLocation.LeftHand, DatReaderWriter.Enums.Placement.LeftHand, "OffHand")
            : Attach(wcid, DatReaderWriter.Enums.ParentLocation.Shield, DatReaderWriter.Enums.Placement.Shield, "Shield")
              ?? Attach(wcid, DatReaderWriter.Enums.ParentLocation.LeftHand, DatReaderWriter.Enums.Placement.Shield, "Shield");
    }

    /// <summary>
    /// Something held: the item's model at one of the body's holding places (a hand, the shield arm), in the item's
    /// placement for it (as ACE wields it) rather than how it lies on the ground.
    /// </summary>
    private BoneAttachment3D? Attach(int wcid, DatReaderWriter.Enums.ParentLocation where, DatReaderWriter.Enums.Placement placement, string name)
    {
        if (_skeleton == null) return null;
        var (setup, _) = _assets.EffectSource(_key);
        if (setup == null || !setup.HoldingLocations.TryGetValue(where, out var hold)) return null;
        var key = new CreatureAssets.Key(wcid, 0, 0f);
        if (!_assets.Prepare(key) || _assets.Mesh(key) is not ArrayMesh mesh) return null;
        var holder = new BoneAttachment3D { BoneIdx = hold.PartId, Name = name };
        _skeleton.AddChild(holder);
        // at the holding place (a frame in the part's own axes - AC's, as everything under the skeleton is)
        var (itemSetup, _) = _assets.EffectSource(key);
        System.Numerics.Matrix4x4 adjust = System.Numerics.Matrix4x4.Identity;
        if (itemSetup != null && itemSetup.Parts.Count > 0)
        {
            var lying = AcDream.Core.Meshing.SetupMesh.Flatten(itemSetup);
            DatReaderWriter.Types.AnimationFrame? held = null;
            if (!itemSetup.PlacementFrames.TryGetValue(placement, out held))
                itemSetup.PlacementFrames.TryGetValue(DatReaderWriter.Enums.Placement.Default, out held);
            if (held != null && lying.Count > 0 && System.Numerics.Matrix4x4.Invert(lying[0].PartTransform, out var inv))
                adjust = inv * AcDream.Core.Meshing.SetupMesh.Flatten(itemSetup, held)[0].PartTransform;
        }
        var f = hold.Frame;
        float sc = _assets.ScaleOf(key);
        var holdM = System.Numerics.Matrix4x4.CreateFromQuaternion(f.Orientation) * System.Numerics.Matrix4x4.CreateTranslation(f.Origin);
        var m = System.Numerics.Matrix4x4.CreateScale(sc) * adjust * holdM;
        // row vectors (AC) to a Godot transform with the same axes: the matrix's rows are the basis columns
        var xf = new Transform3D(new Basis(new Vector3(m.M11, m.M12, m.M13), new Vector3(m.M21, m.M22, m.M23), new Vector3(m.M31, m.M32, m.M33)),
                                 new Vector3(m.M41, m.M42, m.M43));
        holder.AddChild(new MeshInstance3D { Mesh = mesh, Transform = xf });
        return holder;
    }

    /// <summary>Into a stance (fists up for combat, or at peace).</summary>
    public void SetStance(uint style)
    {
        _stance = style;
        if (_seq == null) return;
        try
        {
            // standing: just the stance change (its draw / sheathe animation plays) - asking for Ready again as
            // well cut that animation short, so it snapped to the new stance unless they'd been moving
            if (_motion == Ready || _motion == 0)
                _seq.Manager.PerformMovement(AcDream.Core.Physics.Motion.MotionTableMovement.Interpreted(style, 1f));
            else _seq.SetCycle(style, Ready, 1f);
            _motion = Ready;
        }
        catch (Exception ex) { GD.PushWarning("player stance: " + ex.Message); }
    }

    private const uint PickupMotion = 0x40000018;
    /// <summary>Bending down to pick something up or put it down.</summary>
    public bool Bending => _crouch > 0f;
    private float _crouch;   // bending down to pick something up or put it down: seconds left
    // picking up from a fighting stance, step by step: 1 putting the weapon away, 2 bent down, 3 up again, 4 weapon out again
    private int _pickStep;
    private float _pickT, _pickBend;
    private uint _pickBack;
    private const float StanceTime = 1.0f;   // about what putting a weapon away or drawing it takes
    private void PickSteps(float dt)
    {
        if (_pickStep == 0) return;
        if (_dead || _seq == null) { _pickStep = 0; return; }
        if ((_pickT -= dt) > 0f) return;
        switch (_pickStep)
        {
            case 1: SetMotion(PickupMotion, 1f); _pickT = _pickBend; _pickStep = 2; break;
            case 2: SetMotion(Ready, 1f); _pickT = _pickBend; _pickStep = 3; break;
            case 3: SetStance(_pickBack); _pickT = StanceTime; _pickStep = 4; break;
            default: _pickStep = 0; _crouch = 0f; break;
        }
        if (_pickStep != 0) _crouch = Math.Max(_crouch, _pickT + 0.01f);   // (busy till the last of it)
    }

    /// <summary>Bends down and up again (picking something up, or dropping it), as the game's character does.</summary>
    /// <returns>How long the bend down takes (seconds; the way back up is about as long).</returns>
    public float Crouch()
    {
        if (_seq == null || _dead) return 0f;
        _autoRun = false; ApproachTo = null;
        // in a fighting stance (weapon, bow or wand out): the weapon is put away first, then the bend, then it's out again -
        // every time, as the game does it (and the server, which takes nothing more from you till it's all done)
        if (_stance != NonCombatStance || _pickStep > 0)
        {
            float bend = _assets.ActionLength(_key, NonCombatStance, PickupMotion);
            if (bend <= 0f) bend = 0.73f;
            if (_pickStep == 0) _pickBack = _stance;
            if (_pickStep != 1) { SetStance(NonCombatStance); _pickStep = 1; _pickT = StanceTime; }
            _pickBend = bend;
            _crouch = _pickT + bend * 2f + StanceTime;
            return _pickT + bend;
        }
        SetMotion(PickupMotion, 1f);
        // straight back up the moment they're down (the bend down's own length, from the motion table), so it's
        // one smooth movement
        float down = _assets.ActionLength(_key, _stance, PickupMotion);
        _crouch = down > 0f ? down : 0.73f;
        return _crouch;
    }

    /// <summary>What they're doing by the keys (or what stands in for them): forward 1 / back -1, to the right 1 / left -1, turning left 1 / right -1, and walking (not running).</summary>
    public (int forward, int side, int turn, bool walk) Moving;
    /// <summary>Told as they leave the ground in a jump: how hard (0..1), and the way they go, in their own terms (to the right, forward, up - metres a second).</summary>
    public Action<float, System.Numerics.Vector3>? Jumped;
    /// <summary>A pose held while standing still (sitting, crouching, lying down, a held gesture): 0 for none.</summary>
    public uint Pose;
    /// <summary>Told when moving ended the pose.</summary>
    public Action? PoseEnded;

    /// <summary>Plays an action (an attack) over what they're doing.</summary>
    public void PlayAction(uint motion, float speed)
    {
        if (_seq == null) return;
        try { _seq.PlayAction(motion, speed); }
        catch (Exception ex) { GD.PushWarning("player action: " + ex.Message); }
    }

    /// <summary>
    /// Back to standing ready from a gesture that holds its last pose (a cast's crouch stays down until told to rise):
    /// asked of the motion table whatever we think we're doing.
    /// </summary>
    public void EndGesture()
    {
        if (_seq == null || _dead || (_motion != Ready && _motion != 0)) return;   // (already off doing something else)
        try { _seq.SetCycle(0, Ready, 1f); }
        catch (Exception ex) { GD.PushWarning("player gesture end: " + ex.Message); }
    }

    /// <summary>A cast's gestures stopped where they are for a step (fast casting): what's left of them is dropped, so the
    /// step is seen as it's taken - left to play out, you slid along with your hands up and stepped a second later.</summary>
    public void CutGesture()
    {
        if (_seq == null || _dead) return;
        try { _seq.RemoveAllLinkAnimations(); _seq.SetCycle(0, Ready, 1f); _motion = Ready; }
        catch (Exception ex) { GD.PushWarning("player gesture cut: " + ex.Message); }
    }

    /// <summary>Turns toward a point; true once facing it.</summary>
    /// <summary>How far (radians) you'd have to turn to face a spot.</summary>
    public float YawOffTo(Vector3 at)
    {
        var d = at - Position;
        if (new Vector2(d.X, d.Z).LengthSquared() < 1e-4f) return 0f;
        return Mathf.Wrap(MathF.Atan2(-d.X, -d.Z) - _bodyYaw, -MathF.PI, MathF.PI);
    }

    public bool FaceToward(Vector3 at, float dt)
    {
        var d = at - Position;
        if (new Vector2(d.X, d.Z).LengthSquared() < 1e-4f) return true;
        float want = MathF.Atan2(-d.X, -d.Z);
        float diff = Mathf.Wrap(want - _bodyYaw, -MathF.PI, MathF.PI);
        float step = 5f * dt;
        _bodyYaw += Math.Clamp(diff, -step, step);
        return MathF.Abs(diff) < 0.3f;
    }

    /// <summary>Killed: they fall down dead and can't move.</summary>
    public void Die()
    {
        _dead = true; _autoRun = false; ApproachTo = null; PluginKeys = 0; TurnToYaw = null;
        if (_seq == null) return;
        try { _seq.SetCycle(_stance, DeadMotion, 1f); _motion = DeadMotion; }
        catch (Exception ex) { GD.PushWarning("player death: " + ex.Message); }
    }

    /// <summary>Back to life (standing, at peace).</summary>
    public void Revive()
    {
        _dead = false;
        _stance = NonCombatStance;
        if (_seq == null) return;
        try { _seq.SetCycle(NonCombatStance, Ready, 1f); _motion = Ready; }
        catch (Exception ex) { GD.PushWarning("player revive: " + ex.Message); }
    }
    /// <summary>What the collision is doing, for the screen.</summary>
    /// <summary>The body in the collision, for finding where it sticks: where, how fast, what it stands on.</summary>
    public string BodyNote => _pbody == null ? $"no body in the collision (asked for cell {_seedCell:X8}, {_placeFails} tries failed)"
        : $"cell {_cell:X8} at {_pbody.Position.X:0.00},{_pbody.Position.Y:0.00},{_pbody.Position.Z:0.00} velocity {_pbody.Velocity.X:0.00},{_pbody.Velocity.Y:0.00},{_pbody.Velocity.Z:0.00} "
          + (_pbody.OnWalkable ? "on the ground" : "in the air") + (_pbody.ContactPlaneValid ? $", contact normal {_pbody.ContactPlane.Normal.X:0.00},{_pbody.ContactPlane.Normal.Y:0.00},{_pbody.ContactPlane.Normal.Z:0.00}" : ", no contact")
          + $", air time {_airTime:0.0}s, step up {_physics?.StepUp:0.00}";
    public string PhysicsText => _physics == null ? "" : _pbody == null ? "collision loading" :
        $"cell 0x{_cell:X8}" + (_pbody.OnWalkable ? "" : " (in the air)");
    /// <summary>Which way the character faces (Godot yaw).</summary>
    public float Heading => _bodyYaw;

    public void Setup(CreatureAssets assets, Func<Vector3, float?> ground, FlyCamera cam, Physics.WorldPhysics? physics = null)
    {
        // placed (and the camera with them) before the rest of the frame looks at where the camera is: otherwise the
        // inside/outside of buildings lagged a frame and the landscape flashed as the camera passed a doorway
        ProcessPriority = -20;
        _assets = assets; _ground = ground; _cam = cam; _physics = physics;
        _key = new CreatureAssets.Key(Wcid, 0, 0f);
    }

    /// <summary>Puts the player on the ground under a point, facing a direction (Godot yaw), and takes the camera.</summary>
    public bool Enter(Vector3 at, float yaw, uint cell = 0, bool serverHeight = false)
    {
        if (_body == null && !Build()) return false;
        // outdoors on the ground under the point; in a dungeon cell, where they're put (they settle onto its floor).
        // Put there by a server: at the height it gives (never below the ground) - a recall onto a building's floor, its
        // rooms not loaded yet, went to the ground under it and was pushed up out of the walls onto the roof once the
        // building's collision came in (Ulgrim's recall, Ayan Baqur)
        float? g = cell != 0 ? null : _ground(at);
        float y = g is float gy ? (serverHeight ? Math.Max(at.Y, gy) : gy) : at.Y;
        // (well above the ground - a building's floor, a deck: held at that height till the collision is there, not
        // dropped to the ground under it meanwhile)
        _holdHeight = serverHeight && g is float gh && at.Y > gh + 0.5f;
        _holdFails = 0;
        Position = new Vector3(at.X, y, at.Z);
        _pbody = null; _seedCell = cell; _jumpCharge = -1f; _airTime = 0f; _groundValid = false;
        _bodyYaw = yaw; _yaw = 0f;
        _pitch = _defPitch;
        Visible = true;
        Active = true;
        _cam.Free = false;
        _motion = 0;
        SetMotion(Ready, 1f);
        PlaceBody();
        PlaceCamera();
        return true;
    }

    /// <summary>Gives the camera back (it stays where it is).</summary>
    public void Leave()
    {
        Active = false;
        Visible = false;
        _cam.Free = true;
        _looking = false;
        Input.MouseMode = Input.MouseModeEnum.Visible;
        _cam.LookAtYawPitch(Mathf.RadToDeg(_bodyYaw + _yaw), Mathf.RadToDeg(_pitch));
    }

    /// <summary>The world's particle effects (the body's own are played there).</summary>
    public Effects.ParticleWorld? Particles;
    private uint _fx, _fxTable, _fxScript, _fxScriptOn;
    private float _fxStrength;
    private CreatureAssets.Key _fxKey = new(int.MinValue, 0, 0f);
    /// <summary>On a server: the body's standing effect (its effects table, which effect, how strong).</summary>
    public void SetEffect(uint table, uint effect, float strength) { _fxTable = table; _fxScript = effect; _fxStrength = strength; }

    private bool _lookGiven;
    /// <summary>On a server: the body and everything on it as the server describes it (a look number of its own).</summary>
    public void SetLook(int wcid)
    {
        var key = new CreatureAssets.Key(wcid, 0, 0f);
        // (the look they already have - the server tells of it again each time something is wielded or put away, a
        // weapon changing nothing of how the body looks: made again each time, they blinked out for a moment at every switch)
        if (_lookGiven && key == _key && _body != null && _skeleton != null) return;
        try
        {
            if (!_assets.Prepare(key) || _assets.Mesh(key) is not { } mesh) { GD.PushWarning("server look: nothing to draw"); return; }
            _lookGiven = true;
            _key = key;
            // a body of its own, made afresh: its own skeleton and motions (another race's differ from the one they
            // were first made with - the new skin on the old bones stood knee-deep in the floor)
            if (_body != null) { RemoveChild(_body); _body.QueueFree(); _body = null; }
            _skeleton = null; _seq = null;
            if (!Build()) return;
            uint was = _motion;
            _motion = 0;
            SetMotion(was != 0 ? was : Ready, 1f);
            PlaceBody();
        }
        catch (Exception ex) { GD.PushWarning("server look: " + ex.Message); }
    }

    /// <summary>
    /// What they wear shows on them: the look made again with the items' clothing over the body, swapped in under
    /// the same skeleton (the animation carries on).
    /// </summary>
    public void SetWorn(IEnumerable<string> worn)
    {
        if (_lookGiven) return;   // (on a server: how they look, clothes and all, is what the server says)
        // what they wear is all they wear (the body's own outfit is gone - "!" marks that, even with nothing on)
        string sig = "!" + string.Join(",", worn.OrderBy(x => x));
        if (sig == _key.Worn) return;
        var key = _key with { Worn = sig };
        try
        {
            if (!_assets.Prepare(key) || _assets.Mesh(key) is not { } mesh) return;
            _key = key;
            if (_skeleton != null)
            {
                foreach (var c in _skeleton.GetChildren())
                    if (c is MeshInstance3D mi && mi.Name != "Weapon" && mi.Skin != null) { mi.Mesh = mesh; mi.Skin = _assets.Rig(key).skin; break; }
            }
            else if (_body != null) foreach (var c in _body.GetChildren()) if (c is MeshInstance3D mi) { mi.Mesh = mesh; break; }
        }
        catch (Exception ex) { GD.PushWarning("worn look: " + ex.Message); }
    }

    private bool Build()
    {
        if (!_assets.Prepare(_key)) { GD.PushWarning($"player look {Wcid} has nothing to draw"); return false; }
        var mesh = _assets.Mesh(_key);
        if (mesh == null) return false;
        _body = new Node3D { Name = "Body" };
        AddChild(_body);
        if (_assets.IsAnimated(_key))
        {
            var (sk, skin) = _assets.Rig(_key);
            _skeleton = sk;
            _body.AddChild(sk);
            var mi = new MeshInstance3D { Mesh = mesh, Skin = skin };
            sk.AddChild(mi);
            mi.Skeleton = mi.GetPathTo(sk);
            _seq = _assets.Sequencer(_key);
            _weaponWcid = 0; _weaponHold = null;
            if (_wantWeapon != 0) Wield(_wantWeapon, _wantWeaponLeft);   // a weapon wielded before they were made (loaded with the character)
            _shieldWcid = 0; _shieldHold = null;
            if (_wantShield != 0) WieldOffHand(_wantShield, _wantShieldWeapon);
        }
        else _body.AddChild(new MeshInstance3D { Mesh = mesh });
        return true;
    }

    // side-steps and turns are modifiers in the motion table: they're stopped explicitly, not just replaced
    private static bool Modifier(uint m) => (m & 0x20000000u) != 0;
    private static uint Canonical(uint m) => m == TurnLeft ? TurnRight : m == SideStepLeft ? SideStepRight : m;

    private void SetMotion(uint motion, float speed)
    {
        if (motion == _motion || _seq == null) return;
        try
        {
            if (Modifier(_motion))
                _seq.PerformMovement(AcDream.Core.Physics.Motion.MotionTableMovement.StopInterpreted(Canonical(_motion), 1f));
            // a turn or side-step is laid over the standing pose: stop running/walking first, or they'd keep at it
            if (Modifier(motion) && !Modifier(_motion) && _motion != Ready && _motion != 0) _seq.SetCycle(0, Ready, 1f);
            _motion = motion;
            _seq.SetCycle(0, motion, speed);
        }
        catch (Exception ex) { GD.PushWarning("player motion: " + ex.Message); _motion = motion; }
    }

    private bool _rDown;
    private Vector2 _rStart;
    private float _rDrag;

    /// <summary>A right click (not a drag) in the world, at a screen point: identify what's there.</summary>
    public Action<Vector2>? RightClicked;

    public override void _UnhandledInput(InputEvent e)
    {
        if (!Active) return;
        if (e is InputEventMouseButton mb)
        {
            if (mb.ButtonIndex == MouseButton.Right)
            {
                // a right click identifies what's under the mouse; held and dragged, it looks round (and the mouse
                // comes back where it was)
                if (mb.Pressed) { _rDown = true; _rStart = mb.Position; _rDrag = 0f; }
                else if (_rDown)
                {
                    _rDown = false;
                    if (_looking)
                    {
                        _looking = false;
                        Input.MouseMode = Input.MouseModeEnum.Visible;
                        Input.WarpMouse(_rStart);
                    }
                    else RightClicked?.Invoke(_rStart);
                }
            }
            else if (mb.Pressed && mb.ButtonIndex == MouseButton.WheelUp) _dist = Math.Max(_dist / 1.15f, 1.5f);
            else if (mb.Pressed && mb.ButtonIndex == MouseButton.WheelDown) _dist = Math.Min(_dist * 1.15f, 25f);
        }
        else if (e is InputEventMouseMotion rm && _rDown && !_looking)
        {
            _rDrag += rm.Relative.Length();
            if (_rDrag > 5f) { _looking = true; Input.MouseMode = Input.MouseModeEnum.Captured; }
        }
        else if (e is InputEventMouseMotion mm && _looking)
        {
            _yaw -= mm.Relative.X * 0.003f;
            _pitch = Mathf.Clamp(_pitch - mm.Relative.Y * 0.003f, -1.55f, 1.0f);
        }
    }

    /// <summary>A text box has the keys - in the game window or in a dialog over it (a dialog is a window of its own,
    /// with its own focus: the map's "Add a point" boxes didn't count, so typing in them walked you about).</summary>
    public static bool TypingInBox(Viewport vp)
    {
        var focus = vp.GuiGetFocusOwner();
        if (focus is LineEdit or TextEdit && focus.IsVisibleInTree()) return true;
        foreach (var w in vp.GetEmbeddedSubwindows())
            if (w.Visible && w.HasFocus() && TypingInBox(w)) return true;
        return false;
    }

    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("Player");
        if (!Active) return;
        float dt = (float)Math.Min(delta, 0.1);
        // only typing in a text box stops the keys moving you (a window clicked last doesn't)
        bool typing = TypingInBox(GetViewport()) || UI.ImGuiLayer.WantsKeyboard;
        bool K(string command) => !typing && KeyMap.Held(command);   // (which keys: the keymap's)
        const string Mv = "MovementCommands.", Cm = "CameraControls.";
        // G: auto-run, until W or S is pressed
        bool gKey = K(Mv + "MovementRunLock");
        if (gKey && !_gWas) _autoRun = !_autoRun;
        _gWas = gKey;
        if (K(Mv + "MovementForward") || K(Mv + "MovementBackup")) _autoRun = false;
        if (_dead) { _autoRun = false; typing = true; }   // dead: no moving
        if (Frozen || Leaving) { _autoRun = false; typing = true; ApproachTo = null; if (Leaving) { TurnToYaw = null; PluginKeys = 0; } }
        PickSteps(dt);
        if (_crouch > 0f) { _crouch -= dt; typing = true; }  // bending down: not moving till they're up
        bool fwd = K(Mv + "MovementForward") || _autoRun, back = K(Mv + "MovementBackup"), turnL = K(Mv + "MovementTurnLeft"), turnR = K(Mv + "MovementTurnRight"),
             sideL = K(Mv + "MovementStrafeLeft"), sideR = K(Mv + "MovementStrafeRight");
        // casting (on a server): no stepping forward or back until the hands first reach their height - turning is free. A step
        // then cuts the gesture short (the game's fast casting); how far you may go before the spell fizzles is the server's
        // (the slide: a side key held together with the turn key the other way - Q and D, or A and E - carries you round
        // in a circle, still casting; how far before it fizzles is the server's. A side key on its own is a step like any
        // other: held, then one that cuts the gesture)
        bool castSlide = !_autoRun && ((sideL && !sideR && turnR && !turnL) || (sideR && !sideL && turnL && !turnR)) && CastSlide?.Invoke() == true;
        const float slideLean = 0f;
        if (castSlide) fwd = back = false;
        else if (CastHold?.Invoke() == true) { fwd = back = sideL = sideR = false; }
        else if ((fwd || back || sideL || sideR) && CastCut?.Invoke() == true) CutGesture();
        // stopped (a change of stance on the run): no going on until the keys are let go and pressed again
        if (_stopTillKeysUp) { if (fwd || back || sideL || sideR) fwd = back = sideL = sideR = false; else _stopTillKeysUp = false; }
        MovedByKeys = (fwd && !_autoRun) || back || turnL || turnR || sideL || sideR;   // (auto-run isn't steering)
        if (MovedByKeys && !_autoRun) TurnToYaw = null;
        // a plugin's nav: the keys it holds, and a heading to turn to
        if (!typing && PluginKeys != 0)
        {
            fwd |= (PluginKeys & 1) != 0; back |= (PluginKeys & 2) != 0; turnL |= (PluginKeys & 4) != 0;
            turnR |= (PluginKeys & 8) != 0; sideL |= (PluginKeys & 16) != 0; sideR |= (PluginKeys & 32) != 0;
        }
        float turnStep = -1f;   // (turning to TurnToYaw: just what's left, the last frame)
        if (TurnToYaw is { } ty && !typing && !turnL && !turnR)
        {
            float d = Mathf.Wrap(ty - _bodyYaw, -Mathf.Pi, Mathf.Pi);
            if (Math.Abs(d) < 0.01f) TurnToYaw = null;
            // (a few degrees: just faced, no turn begun - a nav steering by a heading moved it a hair each frame, and
            // each hair was a turn left then right told the server, 60 a second; the retail client sends none of that)
            else if (Math.Abs(d) < 0.08f) { _bodyYaw = ty; TurnToYaw = null; }
            else { turnL = d > 0; turnR = d < 0; turnStep = Math.Abs(d); }
        }
        // running up to an enemy to attack it: facing it and running (until close enough, or you steer)
        // (turned to face it first, then run: running while still turning, at a monster just behind or beside you, ran
        // you round it in a circle - the turn can't keep up with the run that close)
        if (ApproachTo is { } target && !MovedByKeys && !_dead) { FaceToward(target, dt); fwd = MathF.Abs(YawOffTo(target)) < 0.6f; }
        bool walk = KeyMap.Held(Mv + "MovementWalkMode");
        bool pluginJump = _pjPower >= 0f && !_dead && (_pbody == null || _pbody.OnWalkable);
        if (pluginJump)
        {
            fwd |= (_pjKeys & 1) != 0; back |= (_pjKeys & 2) != 0; sideL |= (_pjKeys & 16) != 0; sideR |= (_pjKeys & 32) != 0;
            walk |= _pjWalk;
        }

        // number pad camera: 4 / 6 swing round, 8 up (looking down), 2 down (looking up), 0 back behind them
        const float CamRate = 1.8f;   // rad/s
        if (K(Cm + "CameraRotateLeft")) _yaw -= CamRate * dt;
        if (K(Cm + "CameraRotateRight")) _yaw += CamRate * dt;
        if (K(Cm + "CameraRotateUp")) _pitch = Mathf.Clamp(_pitch - CamRate * 0.6f * dt, -1.55f, 1.0f);
        if (K(Cm + "CameraRotateDown")) _pitch = Mathf.Clamp(_pitch + CamRate * 0.6f * dt, -1.55f, 1.0f);
        if (K(Cm + "CameraViewDefault")) { _yaw = 0f; _pitch = _defPitch; _dist = _defDist; }
        if (K(Cm + "CameraMoveAway")) _dist = Math.Min(_dist * (1f + 1.5f * dt), 25f);        // + zooms out
        if (K(Cm + "CameraMoveToward")) _dist = Math.Max(_dist / (1f + 1.5f * dt), 1.5f);  // - zooms in
        if (K(Cm + "CameraViewMapMode")) { _pitch = -1.55f; _dist = 25f; }                   // straight overhead, zoomed right out

        // the collision around them: loaded as they go; placed in it once it's there
        if (_physics != null)
        {
            var (lbx, lby) = World.LandblockAt(Position);
            if (_physics.Update(lbx, lby, _pbody != null ? _cell : _seedCell) && _pbody != null) { _seedCell = _cell; _pbody = null; _groundValid = false; }   // a new frame: place again
            // (into a dungeon room: once that room's own landblock is there too - its rooms are often a landblock off
            // from where they stand in the world, and placed before them they fell out onto the sea)
            bool seedReady = (_seedCell & 0xFFFF) < 0x0100 || (_seedCell & 0xFFFF) >= 0xFFFE || _physics.IsReady((int)(_seedCell >> 24), (int)((_seedCell >> 16) & 0xFF));
            if (_pbody == null && _physics.IsReady(lbx, lby) && seedReady) PlaceInCollision();
        }

                // turning: the camera turns with them (it stays behind)
        int turn = (turnL ? 1 : 0) - (turnR ? 1 : 0);
        _bodyYaw += turn * (turnStep >= 0 ? Math.Min(TurnRate * dt, turnStep) : TurnRate * dt);

        bool airborne = _pbody != null && !_pbody.OnWalkable;
        _airTime = airborne ? _airTime + dt : 0f;

        // Space: held, the jump charges (up to a second); let go, they jump. Started standing still, they stay put
        // while it charges (the keys don't move them) and jump the way they're holding when they let go - forward
        // or back, or straight up; started on the move, they keep going and jump as they run
        bool space = K(Mv + "MovementJump") && !typing;
        bool jumpNow = false; float jumpPower = 0f;
        Vector3? jumpLocal = null;
        // (the next jump can be charged at once, still in the air from the last; let go while not standing solidly on
        // the ground, nothing happens. Enter - the chat taken up - calls the jump off without jumping)
        bool onGround = _pbody == null || _pbody.OnWalkable;
        if (_spaceTillUp) { if (!space) _spaceTillUp = false; space = false; }   // (Space still down from a precise jump)
        bool ctrl = !typing && Input.IsKeyPressed(Key.Ctrl);
        Vector3 arcLocal = Vector3.Zero; float arcPower = -1f;
        if (_precise)
        {
            if (typing || _dead || Frozen || Leaving) CancelPrecise();
            else
            {
                // W / S: a percent a press, quicker held
                int dir = fwd && !back ? 1 : back && !fwd ? -1 : 0;
                if (dir != 0 && dir != _wsDir) { _wsDir = dir; _wsHeld = 0f; _wsRep = 0f; _precisePower = Math.Clamp(_precisePower + dir * 0.01f, 0f, 1f); }
                else if (dir != 0)
                {
                    _wsHeld += dt;
                    if (_wsHeld > 0.35f) { _wsRep += dt; while (_wsRep >= 0.04f) { _wsRep -= 0.04f; _precisePower = Math.Clamp(_precisePower + dir * 0.01f, 0f, 1f); } }
                }
                else { _wsDir = 0; _wsHeld = 0f; _wsRep = 0f; }
                // (a click's pick of the short jump holds, nudged by hand or not; Shift makes any of them short)
                walk |= _preciseShortAuto;
                _preciseShortNow = walk;
                fwd = back = sideL = sideR = false; _autoRun = false;
                arcLocal = new Vector3(0, walk ? WalkSpeed : 4f * RunAnimRate, 0); arcPower = _precisePower;
                if (!space) _preciseSpaceUp = true;
                else if (_preciseSpaceUp && onGround)
                {
                    jumpNow = true; jumpPower = _precisePower; jumpLocal = arcLocal;
                    _precise = false; _spaceTillUp = true; arcPower = -1f; _preciseShortAuto = false;
                }
            }
        }
        else if (space && _jumpCharge < 0f && ctrl && onGround && !typing)
        {
            // Ctrl+Space: a precise jump (let go of both, then set it up)
            _precise = true; _preciseSpaceUp = false; _autoRun = false; _wsDir = 0; _preciseShortAuto = false;
        }
        else if (typing && _jumpCharge >= 0f) _jumpCharge = -1f;
        else if (space && _jumpCharge < 0f) { _jumpCharge = 0f; _chargeStill = onGround && !(fwd || back || sideL || sideR); }
        else if (space && _jumpCharge >= 0f) _jumpCharge = Math.Min(_jumpCharge + dt / JumpChargeTime, 1f);
        else if (!space && _jumpCharge >= 0f)
        {
            if (onGround)
            {
                jumpNow = true; jumpPower = _jumpCharge;
                if (_chargeStill) jumpLocal = fwd && !back ? new Vector3(0, walk ? WalkSpeed : 4f * RunAnimRate, 0) : back && !fwd ? new Vector3(0, -BackSpeed, 0) : Vector3.Zero;
            }
            _jumpCharge = -1f;
        }
        // the arc of an ordinary jump as it charges (the Options): the way it would go if let go now
        if (arcPower < 0f && ShowArc && _jumpCharge >= 0f && !typing)
        {
            arcPower = _jumpCharge;
            if (_chargeStill) arcLocal = fwd && !back ? new Vector3(0, walk ? WalkSpeed : 4f * RunAnimRate, 0) : back && !fwd ? new Vector3(0, -BackSpeed, 0) : Vector3.Zero;
            else if (fwd && !back) arcLocal = new Vector3(0, walk ? WalkSpeed : 4f * RunAnimRate, 0);
            else if (back && !fwd) arcLocal = new Vector3(0, -BackSpeed, 0);
            else if (sideL != sideR) arcLocal = new Vector3(sideR ? StrafeSpeed : -StrafeSpeed, 0, 0);
        }
        if (arcPower >= 0f) DrawArc(arcPower, arcLocal, dt); else HideArc();
        if (_jumpCharge >= 0f && _chargeStill) { fwd = back = sideL = sideR = false; }   // (charging from standing: held where they are)
        if (pluginJump) { jumpNow = true; jumpPower = _pjPower; _pjPower = -1f; }
        Vector3 fallback = Vector3.Zero;   // (x right, y forward) m/s, if the motion table gives no velocity
        if (fwd && !back) fallback = new Vector3(0, walk ? WalkSpeed : 4f * RunAnimRate, 0);
        else if (back && !fwd) fallback = new Vector3(0, -BackSpeed, 0);
        else if (sideL != sideR) fallback = new Vector3(sideR ? StrafeSpeed : -StrafeSpeed, castSlide ? StrafeSpeed * slideLean : 0, 0);
        Moving = _dead ? (0, 0, 0, false) : ((fwd && !back) ? 1 : (back && !fwd) ? -1 : 0, sideL == sideR ? 0 : sideR ? 1 : -1, turn, walk);
        if (_dead || _crouch > 0f) { }   // lying dead, or bending down
        else if (_airTime > 0.25f) SetMotion(Falling, 1f);   // off an edge or high in a jump
        else if (fwd && !back) SetMotion(walk ? WalkForward : RunForward, walk ? 1f : RunAnimRate * (Charging && ApproachTo != null && !MovedByKeys ? 1.1f : 1f));
        else if (back && !fwd) SetMotion(WalkBackward, 1f);
        else if (castSlide) SetMotion(Ready, 1f);   // (sliding to the side as the cast's gestures play on)
        else if (sideL != sideR) SetMotion(sideR ? SideStepRight : SideStepLeft, SideAnimRate);
        else if (turn != 0) SetMotion(turn < 0 ? TurnRight : TurnLeft, 1f);
        else SetMotion(Pose != 0 ? Pose : Ready, 1f);
        // (a pose is kept only standing still: moving, jumping or dying ends it)
        if (Pose != 0 && (fwd || back || sideL != sideR || turn != 0 || _airTime > 0.25f || _dead)) { Pose = 0; PoseEnded?.Invoke(); }


        if (_seq != null && _skeleton != null)
        {
            var posed = _seq.Advance(dt);
            _assets.Pose(_key, _skeleton, posed);
            if (_fx != 0) Particles?.SetParts(_fx, posed);
            var hooks = _seq.ConsumePendingHooks();   // footsteps and the like
            Physics.Animations.Finish(_seq, hooks);
            // the body's own effects (a shadow's mist, an aura): started with the body, following it, fed by its motions
            if (Particles != null)
            {
                var root = System.Numerics.Matrix4x4.CreateRotationZ(Heading) * System.Numerics.Matrix4x4.CreateTranslation(AcPosition);
                if (_fxKey != _key || _fxScript != _fxScriptOn)
                {
                    if (_fx != 0) Particles.Remove(_fx);
                    var (fxSetup, fxPose) = _assets.EffectSource(_key);
                    uint script = Particles.ScriptFrom(_fxTable, _fxScript, _fxStrength);
                    _fx = fxSetup != null ? Particles.Add(root, fxSetup, fxPose, script) : 0;
                    _fxKey = _key; _fxScriptOn = _fxScript;
                }
                if (_fx != 0) { Particles.Move(_fx, root); if (hooks.Count > 0) Particles.Hooks(_fx, hooks); }
            }
            if (Audio != null && hooks.Count > 0) Audio.Hooks(_assets.SoundTableOf(_key), Position, hooks);
            if (hooks.Count > 0) HooksFired?.Invoke(hooks);
        }

        // how far the animation carries them: its own velocity (object axes: x right, y forward)
        var v = _seq?.CurrentVelocity ?? System.Numerics.Vector3.Zero;
        Vector3 local = (Math.Abs(v.X) + Math.Abs(v.Y) > 0.05f) ? new Vector3(v.X, v.Y, 0) : fallback;
        if (fallback != Vector3.Zero && (local.Dot(fallback) <= 0f || local.Length() > 20f)) local = fallback;   // not the way the keys say
        if (castSlide && !_dead) local = fallback;   // (sliding as you cast: carried by the keys, standing as the gestures play)
        else if (_motion == Ready || _motion == DeadMotion || _motion == PickupMotion || Modifier(_motion) && (_motion == TurnRight || _motion == TurnLeft)) local = Vector3.Zero;
        if (jumpNow && jumpLocal is { } jl) local = jl;   // the standing jump's way (forward, back or straight up)
        // charging at an enemy: 10% quicker than running
        if (Charging && ApproachTo != null && !MovedByKeys && !_dead) local *= 1.1f;
        var forward = new Vector3(-MathF.Sin(_bodyYaw), 0, -MathF.Cos(_bodyYaw));
        var rightDir = new Vector3(MathF.Cos(_bodyYaw), 0, -MathF.Sin(_bodyYaw));
        Vector3 move = forward * local.Y + rightDir * local.X;
        // side-stepping while going forward or backing up: both at once (a diagonal)
        // (off at 45 degrees from the way you were going, at the same speed: running, Q or E carries you away to that
        // side as fast as you ran. A fixed crawl to the side it was, lost in a fast run: the keys hardly turned you)
        if (fwd != back && sideL != sideR && MathF.Abs(local.Y) > 0.01f)
        {
            const float half = 0.70710678f;
            float along = local.Y * half, sideways = MathF.Abs(local.Y) * half * (sideR ? 1f : -1f);
            local = new Vector3(sideways, along, local.Z);
            move = forward * along + rightDir * sideways;
        }

        if (_pbody != null && _physics != null) StepCollision(dt, local, jumpNow, jumpPower);
        else if (_physics != null && _holdHeight) { }   // put up on a floor by the server: held there till its collision is in
        else if (_physics != null && (_seedCell & 0xFFFF) >= 0x0100 && (_seedCell & 0xFFFF) < 0xFFFE) { }   // going into a room: held where they were put till its collision is there (put on the ground under it, they ended up on the sea)
        else
        {
            Vector3 p = Position + move * dt;
            if (_ground(p) is float g) p.Y = g;
            Position = p;
        }

        PlaceBody();
        if (KeepInView is { } kv && !_looking)
        {
            // the camera swings round (behind them) to keep what they're fighting in front of it
            var d = kv - Position;
            if (new Vector2(d.X, d.Z).LengthSquared() > 0.25f)
            {
                float want = Mathf.Wrap(MathF.Atan2(-d.X, -d.Z) - _bodyYaw, -MathF.PI, MathF.PI);
                float diff = Mathf.Wrap(want - _yaw, -MathF.PI, MathF.PI);
                _yaw += diff * Math.Min(1f, 4f * dt);
            }
        }
        PlaceCamera();
    }

    private System.Numerics.Quaternion Facing => System.Numerics.Quaternion.CreateFromAxisAngle(System.Numerics.Vector3.UnitZ, _bodyYaw);

    private System.Numerics.Vector3 AcPosition { get { var (x, y, z) = World.ToAc(Position); return new(x, y, z); } }

    /// <summary>Puts the body into the collision where the character stands (the cell that holds them).</summary>
    private void PlaceInCollision(bool rescue = false)
    {
        var w = _physics!;
        (System.Numerics.Vector3 position, uint cell, bool onWalkable, System.Numerics.Plane contact)? placed = null;
        // (a rescue - hung on an edge, neither standing nor falling: only somewhere to stand will do, the same spot
        // without footing is where they were)
        (System.Numerics.Vector3 position, uint cell, bool onWalkable, System.Numerics.Plane contact)? anyPlace = null;
        bool Good() { if (placed is { } g && rescue && !g.onWalkable) { anyPlace ??= placed; placed = null; } return placed != null; }
        // a little above where they are; in a dungeon room, a bit higher too if that fails (there's no landscape to fall back on)
        bool room = (_seedCell & 0xFFFF) >= 0x0100 && (_seedCell & 0xFFFF) < 0xFFFE;
        foreach (float up in rescue ? Array.Empty<float>() : room ? new[] { 0.02f, 0.3f, 0.8f } : new[] { 0.02f })
        {
            placed = w.Place(w.ToFrame(AcPosition + new System.Numerics.Vector3(0, 0, up)), Facing, w.HumanSpheres, w.StepUp, w.StepDown, _seedCell);
            if (Good()) break;
        }
        // (a room, and nowhere to stand right there - wedged in a stair, set down a hair inside a wall: the nearest
        // spot round about that will take a body, rather than no footing at all and a fall through the dark)
        if (placed == null && (room || rescue))
        {
            foreach (float up in new[] { 0.05f, 0.5f, 1.1f })
            {
                foreach (float out_ in new[] { 0.4f, 0.8f, 1.4f })
                {
                    for (int k = 0; k < 8 && placed == null; k++)
                    {
                        float a8 = k * MathF.PI / 4f;
                        placed = w.Place(w.ToFrame(AcPosition + new System.Numerics.Vector3(MathF.Cos(a8) * out_, MathF.Sin(a8) * out_, up)), Facing, w.HumanSpheres, w.StepUp, w.StepDown, _seedCell);
                        Good();
                    }
                    if (placed != null) break;
                }
                if (placed != null) break;
            }
        }
        placed ??= anyPlace;
        // outdoors, set down well above where they were put (pushed up out of a building onto its roof - Ulgrim's recall
        // in Ayan Baqur): the nearest spot round about at the height asked for, if there is one
        if (!room && !rescue && placed is { } up0 && w.FromFrame(up0.position).Z - AcPosition.Z > 2f)
        {
            var asked = AcPosition;
            (System.Numerics.Vector3 position, uint cell, bool onWalkable, System.Numerics.Plane contact)? near = null;
            foreach (float out_ in new[] { 0.6f, 1.2f, 2f, 3f, 4.5f })
            {
                for (int k = 0; k < 8 && near == null; k++)
                {
                    float a8 = k * MathF.PI / 4f;
                    var tryAt = w.Place(w.ToFrame(asked + new System.Numerics.Vector3(MathF.Cos(a8) * out_, MathF.Sin(a8) * out_, 0.05f)), Facing, w.HumanSpheres, w.StepUp, w.StepDown, _seedCell);
                    if (tryAt is { } t && t.onWalkable && MathF.Abs(w.FromFrame(t.position).Z - asked.Z) < 1.5f) near = tryAt;
                }
                if (near != null) break;
            }
            global::ACGodot.DebugLogs.Print($"[place] {DateTime.Now:HH:mm:ss} set down {w.FromFrame(up0.position).Z - asked.Z:0.0} m above where we were put (z {asked.Z:0.0})" +
                (near is { } nr ? $" - a spot {System.Numerics.Vector2.Distance(new(w.FromFrame(nr.position).X, w.FromFrame(nr.position).Y), new(asked.X, asked.Y)):0.0} m away at that height instead" : " - nowhere near at that height, kept it"));
            if (near != null) placed = near;
        }
        if (placed is { } plog) global::ACGodot.DebugLogs.Print($"[place] {DateTime.Now:HH:mm:ss} placed in cell {plog.cell:X8}, {System.Numerics.Vector3.Distance(w.FromFrame(plog.position), AcPosition):0.0} m from where we were put (seed {_seedCell:X8}{(_holdHeight ? ", held at the server's height" : "")})");
        if (placed is not { } pl)
        {
            // outdoors: try again from the landscape; in a room keep to the room (or they'd end up on the landscape over it)
            // (counted only once the room's landblock is in the collision: loading it after a recall took longer than the
            // 120 tries, and they were put on the landscape - in an apartment hall, landscape off the map)
            if (room && !w.CellReady(_seedCell)) return;
            // (held up at the server's height - a building's floor, or high in the sky on purpose: Mt Lethe's recall drops
            // you from there - and still nowhere it'll take a body after a good while: let go, to the ground as before)
            if (_holdHeight && ++_holdFails > 300) { _holdHeight = false; _holdFails = 0; global::ACGodot.DebugLogs.Print("[place] held at the server's height but nowhere to put a body there - down to the ground"); }
            if (!room || ++_placeFails > 120)
            {
                if (room) global::ACGodot.DebugLogs.Print($"[place] no room to stand in at cell {_seedCell:X8} after 120 tries - trying the landscape");
                _seedCell = 0; _placeFails = 0;
            }
            return;
        }
        _placeFails = 0;
        _holdHeight = false;
        var body = new AcDream.Core.Physics.PhysicsBody
        {
            State = AcDream.Core.Physics.PhysicsStateFlags.Gravity | AcDream.Core.Physics.PhysicsStateFlags.EdgeSlide,
            Orientation = Facing,
        };
        var wp = w.FromFrame(pl.position);
        int lx = (int)MathF.Floor(wp.X / 192f), ly = (int)MathF.Floor(wp.Y / 192f);
        body.SnapToCell(pl.cell, pl.position, new System.Numerics.Vector3(wp.X - lx * 192f, wp.Y - ly * 192f, wp.Z));
        body.TransientState = AcDream.Core.Physics.TransientStateFlags.Active;
        if (pl.onWalkable)
        {
            body.TransientState |= AcDream.Core.Physics.TransientStateFlags.Contact | AcDream.Core.Physics.TransientStateFlags.OnWalkable;
            body.ContactPlaneValid = true; body.ContactPlane = pl.contact; body.ContactPlaneCellId = pl.cell;
        }
        body.calc_acceleration();
        _pbody = body;
        _accum = 0f; _prevPhys = pl.position;
        _cell = pl.cell;
        _seedCell = 0;
        Position = World.ToGodot(wp);
    }

    // ── the jump's arc: worked out as the jump would go (the same speed up and along, gravity), swept through the
    // collision a thirtieth of a second at a time until it meets something - the ground, a floor, a wall - and drawn as
    // a ribbon with a ring where it lands. Worked out again ten times a second ──
    private MeshInstance3D? _arcNode;
    private ImmediateMesh? _arcMesh;
    private double _arcNext;
    private const float ArcBall = 0.35f;   // (the ball swept along: about a body's width; its centre this far over the feet)

    private void HideArc() { if (_arcNode != null) _arcNode.Visible = false; }

    /// <summary>The jump's path (feet, AC world) the way it faces now, to where something stops it (null: nothing did).</summary>
    private System.Collections.Generic.List<System.Numerics.Vector3> SimArc(float power, Vector3 local, out System.Numerics.Vector3? land, out System.Numerics.Vector3 v)
    {
        var w = _physics!;
        var up = new System.Numerics.Vector3(0, 0, ArcBall);
        v = System.Numerics.Vector3.Transform(new System.Numerics.Vector3(local.X, local.Y, 0f), Facing) + new System.Numerics.Vector3(0, 0, JumpSpeed(power, spend: false));
        var p = AcPosition + up;
        uint cell = _cell;
        var pts = new System.Collections.Generic.List<System.Numerics.Vector3> { AcPosition };
        land = null;
        const float Step = 1f / 30f;
        for (int i = 0; i < 150; i++)
        {
            var nv = v + new System.Numerics.Vector3(0, 0, -9.8f * Step);
            var np = p + (v + nv) * 0.5f * Step;
            var hit = w.SweepBall(p, cell, np, ArcBall);
            if (hit == null) break;   // (the collision isn't loaded there)
            var (at, c, stopped) = hit.Value;
            pts.Add(at - up);
            if (stopped) { land = at - up; break; }
            p = np; v = nv; if (c != 0) cell = c;
            if (p.Z < AcPosition.Z - 60f) break;
        }
        return pts;
    }

    // (a precise jump aimed by a click: the short jump picked for it, whatever Shift is doing)
    private bool _preciseShortAuto;

    /// <summary>
    /// A precise jump aimed at what was clicked: the spot under the mouse found in the collision, turned to face it, and
    /// the power (and the short jump or the long) worked out to come down on it - then tried along the real arc and put
    /// right until the ring's on it. What happened, for the status line.
    /// </summary>
    public string AimJumpAt(Camera3D cam, Vector2 screen)
    {
        if (!_precise || _physics == null || _pbody == null) return "";
        var o = cam.ProjectRayOrigin(screen);
        var far = o + cam.ProjectRayNormal(screen) * 80f;
        var (ox, oy, oz) = World.ToAc(o); var (fx, fy, fz) = World.ToAc(far);
        var hit = _physics.SweepBall(new System.Numerics.Vector3(ox, oy, oz), _cell, new System.Numerics.Vector3(fx, fy, fz), 0.05f);
        if (hit is not { stopped: true } h) return "precise jump: nothing there to land on";
        var target = h.acWorld;
        var me = AcPosition;
        var flat = new System.Numerics.Vector2(target.X - me.X, target.Y - me.Y);
        float d = flat.Length();
        if (d < 0.3f) return "precise jump: that's where you're standing";
        _bodyYaw = MathF.Atan2(-flat.X, flat.Y);
        TurnToYaw = null;
        float dz = target.Z - me.Z;
        var (skill, burden) = JumpStats?.Invoke() ?? (100, 0f);
        float burdenMod = burden < 1f ? 1f : burden < 2f ? 2f - burden : 0f;
        float maxH = burdenMod * (skill / (skill + 1300f) * 22.2f + 0.05f);
        // the power for a speed along: so long in the air to get there, so much speed up to be at that height then
        float? PowerFor(float along)
        {
            float t = d / along;
            float vz = (dz + 4.9f * t * t) / t;
            if (vz - 9.8f * t > -0.5f) return null;   // (still going up as it gets there: into its side, not onto it)
            float height = vz * vz / 19.6f;
            if (height < 0.35f - 0.01f || maxH <= 0f) return null;   // (the smallest jump goes further than that)
            float pw = height / maxH;
            return pw <= 1f ? pw : null;
        }
        float run = 4f * RunAnimRate;
        float? shortP = PowerFor(WalkSpeed), longP = PowerFor(run);
        if (shortP == null && longP == null) return $"precise jump: out of reach ({d:0.0} m away, {dz:+0.0;-0.0} m up)";
        bool useShort = shortP != null;
        float along2 = useShort ? WalkSpeed : run;
        float pow = (useShort ? shortP : longP)!.Value;
        // tried along the real arc, and put right: the power that brings it down nearest the spot
        var local = new Vector3(0, along2, 0);
        for (int i = 0; i < 6; i++)
        {
            SimArc(pow, local, out var land, out _);
            if (land is not { } l) break;
            float got = new System.Numerics.Vector2(l.X - me.X, l.Y - me.Y).Length();
            float err = d - got;
            if (MathF.Abs(err) < 0.1f) break;
            pow = Math.Clamp(pow + err / Math.Max(d, 1f) * pow * 0.8f, 0f, 1f);
        }
        _precisePower = pow;
        _preciseShortAuto = useShort;
        _arcNext = 0;
        return $"precise jump: aimed at {d:0.0} m, {dz:+0.0;-0.0} m up - {(useShort ? "short" : "long")} jump at {pow * 100f:0}% (Space to jump)";
    }

    private void DrawArc(float power, Vector3 local, float dt)
    {
        if (_physics == null || _pbody == null) { HideArc(); return; }
        double now = Time.GetTicksMsec() / 1000.0;
        if (_arcNode != null && _arcNode.Visible && now < _arcNext) return;
        _arcNext = now + 0.1;
        if (_arcNode == null)
        {
            _arcMesh = new ImmediateMesh();
            _arcNode = new MeshInstance3D
            {
                Mesh = _arcMesh, TopLevel = true, CastShadow = GeometryInstance3D.ShadowCastingSetting.Off,
                MaterialOverride = new StandardMaterial3D
                {
                    ShadingMode = BaseMaterial3D.ShadingModeEnum.Unshaded, AlbedoColor = new Color(0.25f, 0.55f, 1f, 0.9f),
                    Transparency = BaseMaterial3D.TransparencyEnum.Alpha, CullMode = BaseMaterial3D.CullModeEnum.Disabled,
                },
            };
            AddChild(_arcNode);
        }
        _arcNode.GlobalTransform = Transform3D.Identity;
        var pts = SimArc(power, local, out var land, out var v);
        var m = _arcMesh!;
        m.ClearSurfaces();
        if (pts.Count < 2) { HideArc(); return; }
        // a ribbon, flat and upright both (seen from any side)
        void Ribbon(System.Numerics.Vector3 side)
        {
            m.SurfaceBegin(Mesh.PrimitiveType.TriangleStrip);
            foreach (var q in pts) { m.SurfaceAddVertex(World.ToGodot(q - side)); m.SurfaceAddVertex(World.ToGodot(q + side)); }
            m.SurfaceEnd();
        }
        var dir = System.Numerics.Vector3.Normalize(new System.Numerics.Vector3(v.X, v.Y, 0) + new System.Numerics.Vector3(0.0001f, 0, 0));
        Ribbon(new System.Numerics.Vector3(-dir.Y, dir.X, 0) * 0.03f);
        Ribbon(new System.Numerics.Vector3(0, 0, 0.03f));
        if (land is { } l)
        {
            // the ring where they come down
            m.SurfaceBegin(Mesh.PrimitiveType.TriangleStrip);
            for (int a = 0; a <= 32; a++)
            {
                float t = a / 32f * MathF.Tau;
                var o = new System.Numerics.Vector3(MathF.Cos(t), MathF.Sin(t), 0);
                m.SurfaceAddVertex(World.ToGodot(l + o * 0.45f + new System.Numerics.Vector3(0, 0, 0.05f)));
                m.SurfaceAddVertex(World.ToGodot(l + o * 0.55f + new System.Numerics.Vector3(0, 0, 0.05f)));
            }
            m.SurfaceEnd();
        }
        _arcNode.Visible = true;
    }

    /// <summary>
    /// Moves the body as the client does, in steps of at most a thirtieth of a second: on the ground it goes at the
    /// animation's velocity; in the air gravity has it; each step is swept through the collision, which slides it
    /// along walls, lifts it up steps and stairs and finds the floor or ground under it.
    /// </summary>
    private void StepCollision(float dt, Vector3 local, bool jump, float jumpPower)
    {
        var w = _physics!; var body = _pbody!;
        const AcDream.Core.Physics.TransientStateFlags Contact = AcDream.Core.Physics.TransientStateFlags.Contact,
                                                       OnWalkable = AcDream.Core.Physics.TransientStateFlags.OnWalkable;
        body.Orientation = Facing;
        if (jump && body.OnWalkable)
        {
            var v0 = System.Numerics.Vector3.Transform(new System.Numerics.Vector3(local.X, local.Y, 0f), body.Orientation);
            body.set_velocity(new System.Numerics.Vector3(v0.X, v0.Y, JumpSpeed(jumpPower)));
            Jumped?.Invoke(jumpPower, new System.Numerics.Vector3(local.X, local.Y, JumpSpeed(jumpPower)));
            body.TransientState &= ~(Contact | OnWalkable);
            body.calc_acceleration();
            _airTime = 0.3f;   // (in the air from the start: the jump pose at once)
            _jumpedAt = Time.GetTicksMsec() / 1000.0;
        }
        Record(body, dt, local, jump, jumpPower);
        var start = body.Position;
        // the client moves things in steps of at least a thirtieth of a second (its physics quantum): shorter steps
        // break its maths - a body falling from rest never got past the "too slow to move" cut-off, so off a corner
        // they sank a millimetre a frame. The time is saved up until a whole step is due, and the character is
        // drawn between its last two steps
        const float Quantum = AcDream.Core.Physics.PhysicsBody.MinQuantum;
        _accum = Math.Min(_accum + dt, 0.2f);
        int steps = (int)(_accum / Quantum);
        _accum -= steps * Quantum;
        float q = Quantum;
        for (int i = 0; i < steps; i++)
        {
            _prevPhys = body.Position;
            var vw = System.Numerics.Vector3.Transform(new System.Numerics.Vector3(local.X, local.Y, 0f), body.Orientation);
            if (body.OnWalkable)
            {
                // on the ground no upward speed is kept: the climb itself comes from the step up and the slope under
                // them. Kept, the speed gained running up a rise carried on past its top (or off a ledge's lip) and threw
                // them into the air - and stopping on a rise made a little hop
                float vz = body.Velocity.Z;
                if (vz > 0f) vz = 0f;
                body.set_velocity(new System.Numerics.Vector3(AlongWall(vw), vz));
            }
            else
            {
                // in the air, none of the speed into the walls just hit: in a corner, a move into either wall is
                // refused whole, the drop with it, and they'd hang there (or the collision decides they're standing)
                var v = body.Velocity;
                foreach (var (wn, wt) in _walls)
                {
                    if (wt <= 0f) continue;
                    float into = v.X * wn.X + v.Y * wn.Y;
                    if (into < 0f) { v.X -= into * wn.X; v.Y -= into * wn.Y; }
                }
                // on ground too steep to stand on (touching it, steeper than the game's floor slope): straight down the
                // slope at a run's speed - the bounce off it each step took nearly all the speed, and they crept down
                if (body.InContact && body.ContactPlaneValid)
                {
                    var n = body.ContactPlane.Normal;
                    if (n.Z > 0.05f && n.Z < 0.664f)
                    {
                        var down = new System.Numerics.Vector3(0f, 0f, -1f);
                        var along = down - n * System.Numerics.Vector3.Dot(down, n);
                        if (along.LengthSquared() > 1e-6f)
                        {
                            along = System.Numerics.Vector3.Normalize(along);
                            float speed = Math.Max(4f * RunAnimRate, System.Numerics.Vector3.Dot(v, along));
                            v = along * speed;
                        }
                    }
                }
                body.Velocity = v;
            }
            for (int wi = 0; wi < _walls.Count; wi++) _walls[wi] = (_walls[wi].n, _walls[wi].t - q);
            var pre = body.Position;
            body.calc_acceleration();
            body.UpdatePhysicsInternal(q);
            var post = body.Position;
            bool moved = post != pre;
            AcDream.Core.Physics.ResolveResult r;
            AcDream.Core.Physics.ResolveResult Sweep() => SweepTo(post, body);
            AcDream.Core.Physics.ResolveResult SweepTo(System.Numerics.Vector3 to, AcDream.Core.Physics.PhysicsBody? b) => w.Engine.ResolveWithTransition(pre, to, _cell,
                AcDream.Core.Physics.DefaultPlayerBody.Radius, AcDream.Core.Physics.DefaultPlayerBody.Height,
                w.StepUp, w.StepDown, isOnGround: b == null || b.OnWalkable, body: b,
                moverFlags: AcDream.Core.Physics.ObjectInfoState.IsPlayer | AcDream.Core.Physics.ObjectInfoState.EdgeSlide | HouseRooms,
                movingEntityId: 0x000F4243u, sphereList: w.HumanSpheres);
            try
            {
                r = Sweep();
                // a sweep that went nowhere with a wall remembered from before: the remembered wall (its "sliding
                // normal") turned the whole move into nothing - at a corner or door frame it can point almost
                // straight up, and since a failed sweep doesn't update it, it held them there for good. Forget it
                // and sweep again
                if (!r.Ok && moved && (body.TransientState & AcDream.Core.Physics.TransientStateFlags.Sliding) != 0)
                {
                    body.SlidingNormal = System.Numerics.Vector3.Zero;
                    body.TransientState &= ~AcDream.Core.Physics.TransientStateFlags.Sliding;
                    r = Sweep();
                }
                // held at the edge of a door jamb or a corner: try the move turned a little either way (CornerSlip)
                var desired = vw * q;
                float progress = System.Numerics.Vector2.Dot(new System.Numerics.Vector2(r.Position.X - pre.X, r.Position.Y - pre.Y),
                                                            System.Numerics.Vector2.Normalize(new System.Numerics.Vector2(desired.X, desired.Y) + new System.Numerics.Vector2(1e-9f, 0)));
                if (body.OnWalkable && r.CollisionNormalValid && desired.LengthSquared() > 1e-6f && progress < desired.Length() * 0.5f
                    && Physics.CornerSlip.Try(to => SweepTo(to, null), pre, desired, progress) is { } slipTo)
                {
                    body.SlidingNormal = System.Numerics.Vector3.Zero;
                    body.TransientState &= ~AcDream.Core.Physics.TransientStateFlags.Sliding;
                    post = new System.Numerics.Vector3(slipTo.X, slipTo.Y, post.Z);
                    r = Sweep();
                }
            }
            catch (Exception ex) { GD.PushWarning("collision: " + ex.Message); body.Position = pre; break; }
            // an edge - a cliff's foot or its lip, a hill too steep to stand on, a drop: it's a wall, up or down. The step
            // off the walkable ground isn't taken, and from the next one they run along the edge by the angle they met it
            // at (AlongWall). Only a jump takes them over (a jump leaves the ground before this is asked).
            var hm = new System.Numerics.Vector2(vw.X, vw.Y);
            if (body.OnWalkable && r.Ok && !(r.InContact && r.OnWalkable) && hm.LengthSquared() > 0.01f && System.Numerics.Vector3.DistanceSquared(r.Position, pre) > 1e-8f)
            {
                var md = System.Numerics.Vector2.Normalize(hm);
                System.Numerics.Vector2? edgeN = null;
                var cn = r.ContactPlane.Normal;
                var hn = new System.Numerics.Vector2(cn.X, cn.Y);
                if (r.InContact && cn.Z > 0.05f && cn.Z < 0.664f && hn.LengthSquared() > 1e-6f)
                {
                    // a steep face (up it or down it): the face's own way round - a wall whose side faces back at them
                    hn = System.Numerics.Vector2.Normalize(hn);
                    edgeN = System.Numerics.Vector2.Dot(hn, md) > 0f ? -hn : hn;
                }
                else
                {
                    // a drop with nothing under it: which way along the edge still has ground is found by trying the step
                    // turned a little more each time, either way - the edge runs that way
                    float len = Math.Max(0.3f, (vw * q).Length());
                    foreach (float deg in new[] { 20f, 40f, 60f, 80f })
                    {
                        foreach (float sign in new[] { 1f, -1f })
                        {
                            float a = deg * MathF.PI / 180f * sign;
                            var d = new System.Numerics.Vector2(md.X * MathF.Cos(a) - md.Y * MathF.Sin(a), md.X * MathF.Sin(a) + md.Y * MathF.Cos(a));
                            AcDream.Core.Physics.ResolveResult t;
                            try { t = SweepTo(new System.Numerics.Vector3(pre.X + d.X * len, pre.Y + d.Y * len, pre.Z), null); } catch { continue; }
                            if (!(t.Ok && t.InContact && t.OnWalkable)) continue;
                            var perp = new System.Numerics.Vector2(-d.Y, d.X);
                            edgeN = System.Numerics.Vector2.Dot(perp, md) > 0f ? -perp : perp;
                            break;
                        }
                        if (edgeN != null) break;
                    }
                    edgeN ??= -md;   // (no way along it: stopped)
                }
                var en2 = edgeN.Value;
                _wallNormal = en2; _wallTime = 0.25f;
                _walls.RemoveAll(x => System.Numerics.Vector2.Dot(x.n, en2) > 0.9f);
                _walls.Insert(0, (en2, 0.25f));
                if (_walls.Count > 2) _walls.RemoveAt(2);
                body.Position = pre;
                body.set_velocity(new System.Numerics.Vector3(0f, 0f, Math.Min(0f, body.Velocity.Z)));
                continue;
            }
            _lastOk = r.Ok; _lastHit = r.CollisionNormalValid;
            // a wall (not a floor or step): remembered for a moment, to run along it - and ground too steep to stand on
            // (a cliff, a hill's edge) is a wall too: run into, you turn along it by the angle you met it at, not up it
            // and off into the air
            if (r.CollisionNormalValid && MathF.Abs(r.CollisionNormal.Z) < 0.664f)
            {
                var n = new System.Numerics.Vector2(r.CollisionNormal.X, r.CollisionNormal.Y);
                if (n.LengthSquared() > 1e-6f)
                {
                    // facing against the way they were going: some surfaces report their normal the other way round
                    // (which side of the character the wall was on decided whether running along it worked)
                    n = System.Numerics.Vector2.Normalize(n);
                    if (System.Numerics.Vector2.Dot(n, new System.Numerics.Vector2(vw.X, vw.Y)) > 0f) n = -n;
                    _wallNormal = n; _wallTime = 0.25f;
                    // (a ledge's edge held them on the floor - nothing was hit: not a wall to keep out of in the air,
                    // or a jump from running along the edge couldn't go over it)
                    if (r.CollidedWithEnvironment || r.LastCollidedObjectId != 0)
                    {
                        var wn2 = n;
                        _walls.RemoveAll(x => System.Numerics.Vector2.Dot(x.n, wn2) > 0.9f);
                        _walls.Insert(0, (n, 0.25f));
                        if (_walls.Count > 2) _walls.RemoveAt(2);
                    }
                }
            }
            else _wallTime -= q;
            body.CachedVelocity = moved ? (r.Position - pre) / q : System.Numerics.Vector3.Zero;
            bool prevContact = body.InContact, prevOnWalkable = body.OnWalkable;
            body.CommitTransitionPosition(r.CellId, r.Position);
            if (r.Ok && moved)
            {
                // ground flags only from a sweep that went somewhere: one cut short to nothing reports no ground under
                // them (the character flickered "in the air" against walls, and lost a step of movement each time)
                if (System.Numerics.Vector3.DistanceSquared(r.Position, pre) > 1e-10f)
                {
                    if (r.InContact) body.TransientState |= Contact; else body.TransientState &= ~Contact;
                    if (r.InContact && r.OnWalkable) body.TransientState |= OnWalkable; else body.TransientState &= ~OnWalkable;
                    if (r.InContact) { body.ContactPlaneValid = true; body.ContactPlane = r.ContactPlane; body.ContactPlaneCellId = r.ContactPlaneCellId; }
                }
                // but the bounce off what they hit always: jumping into a corner, it's what takes the run out of them
                // so they drop (without it they hung there in the air, falling ever faster and going nowhere)
                body.calc_acceleration();
                AcDream.Core.Physics.PhysicsObjUpdate.HandleAllCollisions(body, r.CollisionNormalValid, r.CollisionNormal,
                    prevContact, prevOnWalkable, body.OnWalkable);
                // run into ground too steep to stand on: no bounce up off it (it threw them into the air) - they're
                // stopped against it, or slide down it
                if (!body.OnWalkable && body.Velocity.Z > 0f)
                {
                    bool steepHit = r.CollisionNormalValid && r.CollisionNormal.Z > 0.05f && r.CollisionNormal.Z < 0.664f;
                    bool steepUnder = body.InContact && body.ContactPlaneValid && body.ContactPlane.Normal.Z > 0.05f && body.ContactPlane.Normal.Z < 0.664f;
                    if ((steepHit || steepUnder) && Time.GetTicksMsec() / 1000.0 - _jumpedAt > 0.6)
                    {
                        var bv = body.Velocity;
                        body.set_velocity(new System.Numerics.Vector3(bv.X, bv.Y, 0f));
                    }
                }
            }
            if (r.CellId != 0) { _cell = r.CellId; w.Engine.UpdatePlayerCurrCell(_cell); }
            if (body.OnWalkable && r.Ok) { _groundAt = body.Position; _groundCell = _cell; _groundValid = true; }
        }
        // through the floor of a dungeon: falling far below where they last stood, in a room (there's no landscape
        // under a dungeon to catch them - they fell through the dark for good). The movement is saved for a look at
        // why, and they're set back where they last stood
        bool inRoom = (_cell & 0xFFFF) >= 0x0100 && (_cell & 0xFFFF) < 0xFFFE;
        if (!body.OnWalkable && _groundValid && inRoom && body.Position.Z < _groundAt.Z - 40f)
        {
            string saved = "";
            if (!_fallSaved)
            {
                _fallSaved = true;
                try { saved = " - " + SaveCapture(ProjectSettings.GlobalizePath("res://capture-fall-" + DateTime.Now.ToString("HHmmss"))); }
                catch (Exception ex) { saved = " - capture failed: " + ex.Message; }
            }
            GD.PushWarning($"player fell through the floor: cell 0x{_cell:X8} at {body.Position}, last stood at {_groundAt} in 0x{_groundCell:X8}: set back there{saved}");
            _hungTime = 0f; _stuckTime = 0f; _airTime = 0f;
            Position = World.ToGodot(w.FromFrame(_groundAt + new System.Numerics.Vector3(0, 0, 0.05f)));
            _seedCell = _groundCell;
            _groundValid = false;
            PlaceInCollision(rescue: true);
            return;
        }
        // stuck: trying to go somewhere on the ground and getting nowhere for a moment (wedged into a slope or a
        // corner, where the sweep can't find a way out): put the body down again, clear of what holds it
        float stepped = steps * Quantum;
        float want = new System.Numerics.Vector2(local.X, local.Y).Length() * stepped;
        if (!body.OnWalkable) want = Math.Max(want, MathF.Abs(body.Velocity.Z) * stepped);   // falling and not getting lower
        float got = System.Numerics.Vector3.Distance(start, body.Position);
        // (a wall in the way is not stuck: that's the collision saying so)
        bool abnormal = !_lastOk || !_lastHit;
        if (steps > 0) _stuckTime = want > 0.02f && got < want * 0.1f && abnormal ? _stuckTime + stepped : 0f;
        // hung in the air: not standing, not falling, not going anywhere (caught on the lip between a stair's top and
        // the floor above it - nothing under the feet counts as ground, and nothing lets them drop): after a second of
        // it, set down again on the nearest footing
        if (!body.OnWalkable && System.Numerics.Vector3.DistanceSquared(body.Position, _hungAt) < 0.03f * 0.03f) _hungTime += stepped;
        else { _hungTime = 0f; _hungAt = body.Position; }
        if (_hungTime > 1.0f)
        {
            GD.PushWarning($"player hung in the air: cell 0x{_cell:X8} at {body.Position}: set down on the nearest footing");
            _hungTime = 0f; _stuckTime = 0f;
            Position = World.ToGodot(w.FromFrame(body.Position));
            _seedCell = _cell;
            PlaceInCollision(rescue: true);
            _airTime = 0f;
            return;
        }
        if (_stuckTime > 0.4f)
        {
            GD.PushWarning($"player stuck: cell 0x{_cell:X8} at {body.Position} ok={_lastOk} hit={_lastHit} onWalkable={body.OnWalkable} contact={body.InContact} " +
                           $"ground normal {body.GroundNormal} sliding={((body.TransientState & AcDream.Core.Physics.TransientStateFlags.Sliding) != 0)}: placing again");
            _stuckTime = 0f;
            Position = World.ToGodot(w.FromFrame(body.Position + new System.Numerics.Vector3(0, 0, 0.1f)));
            _seedCell = _cell;
            PlaceInCollision();
            return;
        }
        var shown = System.Numerics.Vector3.Lerp(_prevPhys, body.Position, Math.Clamp(_accum / Quantum, 0f, 1f));
        Position = World.ToGodot(w.FromFrame(shown));
    }
    private float _hungTime; private System.Numerics.Vector3 _hungAt;
    private System.Numerics.Vector3 _groundAt; private uint _groundCell; private bool _groundValid, _fallSaved;   // where they last stood
    private float _accum;                          // time not yet stepped (less than a quantum)
    private System.Numerics.Vector3 _prevPhys;     // where the body was before its last step

    // ── the last 30 seconds of movement, for saving with the collision's data (P) to replay elsewhere ──
    private readonly System.Collections.Generic.Queue<string> _recent = new();
    private static string F(float f) => f.ToString("R", System.Globalization.CultureInfo.InvariantCulture);
    private static string V(System.Numerics.Vector3 v) => $"{F(v.X)},{F(v.Y)},{F(v.Z)}";

    private void Record(AcDream.Core.Physics.PhysicsBody b, float dt, Vector3 local, bool jump, float jumpPower)
    {
        var verts = b.WalkableVertices is { } wv ? string.Join("|", Array.ConvertAll(wv, V)) : "";
        _recent.Enqueue(string.Join(";",
            F(dt), F(_bodyYaw), F(local.X), F(local.Y), jump ? "1" : "0", F(jumpPower),
            $"{_cell:X8}", V(b.Position), V(b.Velocity), ((uint)b.TransientState).ToString("X"), ((uint)b.State).ToString("X"),
            $"{b.CellPosition.ObjCellId:X8}", V(b.CellPosition.Frame.Origin),
            b.ContactPlaneValid ? "1" : "0", V(b.ContactPlane.Normal), F(b.ContactPlane.D), $"{b.ContactPlaneCellId:X8}", b.ContactPlaneIsWater ? "1" : "0",
            V(b.SlidingNormal), V(b.GroundNormal), b.FramesStationaryFall.ToString(),
            b.WalkablePolygonValid ? "1" : "0", V(b.WalkablePlane.Normal), F(b.WalkablePlane.D), V(b.WalkableUp), verts,
            $"{_wallNormal.X.ToString("R", System.Globalization.CultureInfo.InvariantCulture)},{_wallNormal.Y.ToString("R", System.Globalization.CultureInfo.InvariantCulture)}", F(_wallTime)));
        while (_recent.Count > 1800) _recent.Dequeue();
    }

    /// <summary>Writes the recent movement (one line a frame) and the collision's game data to a folder. Returns what it did.</summary>
    /// <summary>
    /// How much of a straight walk (bearing in degrees clockwise from north, metres) you could make before something
    /// stops you: 0..1, or -1 when it can't be checked (the collision isn't loaded). The same sweep a step takes, not moving you.
    /// </summary>
    public double Probe(double bearing, double metres)
    {
        if (_physics == null || _pbody == null || metres <= 0) return -1;
        var w = _physics;
        try
        {
            var from = _pbody.Position;
            double rad = bearing * Math.PI / 180.0;
            var to = from + new System.Numerics.Vector3((float)(Math.Sin(rad) * metres), (float)(Math.Cos(rad) * metres), 0f);
            var r = w.Engine.ResolveWithTransition(from, to, _cell,
                AcDream.Core.Physics.DefaultPlayerBody.Radius, AcDream.Core.Physics.DefaultPlayerBody.Height,
                w.StepUp, w.StepDown, isOnGround: true, body: null,
                moverFlags: AcDream.Core.Physics.ObjectInfoState.IsPlayer | AcDream.Core.Physics.ObjectInfoState.EdgeSlide | HouseRooms,
                movingEntityId: 0x000F4243u, sphereList: w.HumanSpheres);
            if (!r.Ok) return 0;
            var d = r.Position - from;
            double along = (d.X * (to.X - from.X) + d.Y * (to.Y - from.Y)) / metres;
            return Math.Clamp(along / metres, 0, 1);
        }
        catch { return -1; }
    }

    public string SaveCapture(string dir)
    {
        if (_physics == null) return "no collision";
        System.IO.Directory.CreateDirectory(dir);
        System.IO.File.WriteAllText(System.IO.Path.Combine(dir, ".gdignore"), "");   // not game resources: Godot leaves it alone
        var (ox, oy) = _physics.FrameOrigin;
        var lines = new System.Collections.Generic.List<string>
        {
            $"# ACGodot movement capture: frame origin landblock {ox} {oy}",
            "# loaded " + string.Join(" ", System.Linq.Enumerable.Select(_physics.Loaded, k => $"{k.x},{k.y}")),
            "# dt;yaw;localX;localY;jump;power;cell;pos;vel;transient;state;cellposCell;cellposOrigin;cpValid;cpN;cpD;cpCell;cpWater;slidingN;groundN;fsf;walkValid;walkN;walkD;walkUp;walkVerts;wallN;wallTime",
        };
        lines.AddRange(_recent);
        System.IO.File.WriteAllLines(System.IO.Path.Combine(dir, "movement.txt"), lines);
        if (_physics.Dats is Physics.RecordingDats rec)
        {
            // the character's body and motions too (to replay its animations elsewhere)
            try
            {
                var (setup, _) = _assets.EffectSource(_key);
                if (setup != null) rec.Get<DatReaderWriter.DBObjs.Setup>(setup.Id);
                if (_assets.MotionTableOf(_key) is { } mt)
                {
                    rec.Get<DatReaderWriter.DBObjs.MotionTable>(mt.Id);
                    var anims = new System.Collections.Generic.HashSet<uint>();
                    foreach (var md in mt.Cycles.Values) foreach (var ad in md.Anims) anims.Add((uint)ad.AnimId);
                    foreach (var l in mt.Links.Values) foreach (var md in l.MotionData.Values) foreach (var ad in md.Anims) anims.Add((uint)ad.AnimId);
                    foreach (uint a in anims) rec.Get<DatReaderWriter.DBObjs.Animation>(a);
                    if (setup != null && (uint)setup.DefaultAnimation != 0) rec.Get<DatReaderWriter.DBObjs.Animation>((uint)setup.DefaultAnimation);
                }
                rec.Get<DatReaderWriter.DBObjs.CombatTable>(0x30000000u);
            }
            catch (Exception ex) { GD.PushWarning("capture motions: " + ex.Message); }
            rec.Save(System.IO.Path.Combine(dir, "dats.bin.gz"));
        }
        return $"saved {_recent.Count} frames of movement and the collision's data to {dir}";
    }

    private void PlaceBody()
    {
        if (_body == null) return;
        float s = _assets.ScaleOf(_key);
        // the body's mesh is in AC's axes (Z up, facing +Y); its heading about Z is the Godot yaw
        var ac = System.Numerics.Matrix4x4.CreateScale(s) * System.Numerics.Matrix4x4.CreateRotationZ(_bodyYaw);
        _body.Transform = Objects.ObjectAssets.Xf(ac);
    }

    /// <summary>
    /// The camera as the client keeps it: a small sphere (0.3 m) swept from their head back to where the camera
    /// wants to be, stopping at the first wall, ceiling, floor or slope - so indoors it doesn't go through walls.
    /// </summary>
    private Vector3 CameraClear(Vector3 head, Vector3 want)
    {
        const float R = 0.3f;
        var w = _physics!;
        System.Numerics.Vector3 F(Vector3 g) { var (x, y, z) = World.ToAc(g); return w.ToFrame(new System.Numerics.Vector3(x, y, z)); }
        var down = new System.Numerics.Vector3(0, 0, R);
        try
        {
            var r = w.Engine.ResolveWithTransition(F(head) - down, F(want) - down, _cell, R, 0f, 0f, 0f, isOnGround: false, body: null,
                moverFlags: AcDream.Core.Physics.ObjectInfoState.IsViewer | AcDream.Core.Physics.ObjectInfoState.PathClipped
                          | AcDream.Core.Physics.ObjectInfoState.FreeRotate | AcDream.Core.Physics.ObjectInfoState.PerfectClip,
                movingEntityId: 0x000F4243u);
            if (!r.Ok) return want;
            return World.ToGodot(w.FromFrame(r.Position + down));
        }
        catch { return want; }
    }

    /// <summary>
    /// Whether a shot from chest height reaches a thing of the server's (its middle) without the world in the way - walls,
    /// shut doors, tables and the like; creatures (pets, monsters, people) don't count. Null when it can't be told.
    /// </summary>
    public (bool clear, string what)? ClearShot(uint guid)
    {
        var w = _physics;
        if (w == null || _pbody == null || _cell == 0 || w.ServerThingAc(guid) is not { } at) return null;
        // (to its middle, and failing that a little higher - an arrow's arc, a tall thing's chest: clear if either is)
        var from = AcPosition + new System.Numerics.Vector3(0, 0, 1.2f);
        var low = w.ClearLine(from, _cell, at + new System.Numerics.Vector3(0, 0, 1.0f), skipGuid: guid);
        if (low is not { clear: false }) return low;
        var high = w.ClearLine(from, _cell, at + new System.Numerics.Vector3(0, 0, 1.8f), skipGuid: guid);
        return high is { clear: true } ? high : low;
    }

    // a house's rooms carry who may come in, and the collision code looks that up on the house's own object - which isn't
    // kept where it looks, so it found none and stopped us at every house's door (only houses: other buildings' rooms
    // carry nothing). Let through here; the server keeps out whoever isn't allowed, putting them back outside.
    private const AcDream.Core.Physics.ObjectInfoState HouseRooms = AcDream.Core.Physics.ObjectInfoState.CanBypassMoveRestrictions;

    private void PlaceCamera()
    {
        var head = Position + new Vector3(0, 1.6f, 0);
        float cy = _bodyYaw + _yaw;
        var look = new Vector3(-MathF.Sin(cy) * MathF.Cos(_pitch), MathF.Sin(_pitch), -MathF.Cos(cy) * MathF.Cos(_pitch));
        Vector3 at = head - look * _dist;
        if (_pbody != null && _physics != null && _cell != 0) at = CameraClear(head, at);
        // not below the ground
        else if (_ground(at) is float g && at.Y < g + 0.4f) at.Y = g + 0.4f;
        // (pulled right in to the head - backed against a wall, in a doorway: just in front of it, looking the same way -
        // looking at where it already is, Godot errors every frame)
        if (at.DistanceSquaredTo(head) < 0.0025f) at = head - look * 0.06f;
        _cam.Position = at;
        _cam.LookAt(head, Vector3.Up);
    }
}
