using System;
using System.Collections.Generic;
using System.IO;
using System.Numerics;
using System.Text.Json;

namespace ACGodot.Creatures;

/// <summary>
/// What ACE's world database places in each landblock (creatures, NPCs, doors, chests, portals...), read from
/// data/spawns.json.gz and data/weenies.json (made by tools/ace_spawns.py). Generators are worked out here: what they'd
/// make when the world starts, at a position picked the same way every time.
/// </summary>
public sealed class SpawnData
{
    /// <summary>One weenie (object template): only what drawing it needs.</summary>
    public sealed class Weenie
    {
        /// <summary>A copy (to make a new kind of thing from an existing one).</summary>
        public Weenie Copy() => (Weenie)MemberwiseClone();
        public string Name = "";
        /// <summary>Its look is given whole (a server's description): no face or colouring of our own is made up for it.</summary>
        public bool Exact;
        public int Type;
        public uint Setup, MotionTable, PaletteBase, ClothingBase, SoundTable;
        /// <summary>The pose the server says it stands in (its placement), with no motions of its own: drawn still in that
        /// pose - not in an idle frame from its model's default motion table. -1: none said.</summary>
        public int Placement = -1;
        public int PaletteTemplate, ClothingPriority;
        public float Shade, Scale = 1f, GenRadius = 4f;
        public int GenInit = 1, GenMax = 1;
        public bool Hidden;
        public uint Eyes, Nose, Mouth, Head, HairPalette, EyesPalette, SkinPalette;   // a person's face
        public List<(int index, uint gfx)> AnimParts = new();
        public List<(uint id, int offset, int length)> Palettes = new();           // offsets/lengths in colours
        public List<(int index, uint oldTex, uint newTex)> TextureMaps = new();
        public List<(int wcid, int paletteTemplate, float shade)> Worn = new();
        public List<Profile> Generates = new();
        // fighting (from ACE's weenie): who it attacks, how well, how hard, and how much it takes
        public uint CombatTable;               // its attack moves (CombatManeuverTable, 0x30...)
        public int Level, Tolerance, ItemType;
        public bool Attackable = true, Immobile;
        public float Awareness, PowerupTime = 1f, Regen;   // awareness: how far it sees you (0: the usual 18 m)
        public int[] Attributes = new int[6];  // strength, endurance, quickness, coordination, focus, self
        public int Health;                     // its most health
        public Dictionary<int, int> Skills = new();   // skill: its base and ranks (the attribute share added when used)
        public List<BodyPart> BodyParts = new();
        public int Damage, DamageType, CombatStyle;   // a weapon's
        public float DamageVariance;
        // as an item, or what killing it gives
        public uint Icon, DeathTreasure;
        public int Xp, Value, Burden, WeaponSkill, WeaponTime, ValidLocations, ArmorLevel, MaxStack, Uses, MaxUses, Mana, MaxMana;
    }

    /// <summary>
    /// A creature's body part: what it hits with (damage type, most damage, variance), its armor against each kind
    /// of damage (slash, pierce, bludgeon, cold, fire, acid, electric, nether), and how likely a high, medium or
    /// low attack strikes it.
    /// </summary>
    public sealed record BodyPart(int Key, int DamageType, float Damage, float Variance, float[] Armor, float High, float Mid, float Low);

    /// <summary>A generator's line: what it makes, how many, and where.</summary>
    public sealed record Profile(float Probability, int Wcid, int Init, int Max, int Where, int PaletteTemplate, float Shade,
                                 uint Cell, Vector3 Origin, Quaternion Rotation);

    /// <summary>Something placed in the world: a weenie at a landblock-relative position (AC axes).</summary>
    public readonly record struct Placed(int Wcid, uint Cell, Vector3 Position, Quaternion Rotation, int PaletteTemplate, float Shade);

    /// <summary>Doors stand this much higher than their placement, to sit on their thresholds as in the game.</summary>
    public const float DoorLift = 0.05f;

    // (read by the landblock builders on their own threads while the network adds the server's looks on the main one:
    // a plain Dictionary read while it's written can throw, or loop forever)
    private readonly System.Collections.Concurrent.ConcurrentDictionary<int, Weenie> _weenies = new();
    private readonly Dictionary<int, List<(int wcid, uint cell, Vector3 pos, Quaternion rot)>> _spawns = new();

    public int WeenieCount => _weenies.Count;

    /// <summary>One creature of each kind of body (not people), for looking them over (K).</summary>
    public List<int> CreatureVariety()
    {
        var seen = new HashSet<uint>();
        var list = new List<int>();
        foreach (var kv in _weenies)
        {
            var w = kv.Value;
            if (w.Type != 10 || w.Setup == 0 || w.Hidden || w.Setup == 0x02000001u || w.Setup == 0x0200004Eu) continue;
            if (seen.Add(w.Setup)) list.Add(kv.Key);
        }
        list.Sort();
        return list;
    }

    public Weenie? Get(int wcid) => _weenies.TryGetValue(wcid, out var w) ? w : null;

    /// <summary>A new kind of thing (ACGodot's own, e.g. a test portal), under a wcid of its own.</summary>
    public void AddWeenie(int wcid, Weenie w) => _weenies[wcid] = w;

    /// <summary>Something more standing in a landblock when it loads (landblock-relative x, y; z -9999 = on the ground).</summary>
    public void AddPlaced(int lbX, int lbY, int wcid, uint cell, Vector3 pos, Quaternion rot)
    {
        int key = (lbX << 8) | lbY;
        if (!_spawns.TryGetValue(key, out var list)) _spawns[key] = list = new();
        list.Add((wcid, cell, pos, rot));
    }

    /// <summary>Reads the two files from a folder; null (with the reason) if they aren't there.</summary>
    public static SpawnData? Load(string dir, out string error)
    {
        error = "";
        string wf = Path.Combine(dir, "weenies.json"), sf = Path.Combine(dir, "spawns.json.gz");
        if (!File.Exists(wf) || !File.Exists(sf)) { error = $"no {wf} / {sf}"; return null; }
        var d = new SpawnData();
        using (var doc = JsonDocument.Parse(File.ReadAllBytes(wf)))
            foreach (var p in doc.RootElement.EnumerateObject())
                d._weenies[int.Parse(p.Name)] = ReadWeenie(p.Value);
        using (var gz = new System.IO.Compression.GZipStream(File.OpenRead(sf), System.IO.Compression.CompressionMode.Decompress))
        using (var doc = JsonDocument.Parse(gz))
            foreach (var p in doc.RootElement.EnumerateObject())
            {
                var list = new List<(int, uint, Vector3, Quaternion)>();
                foreach (var e in p.Value.EnumerateArray())
                {
                    var a = e.EnumerateArray().GetEnumerator();
                    float F() { a.MoveNext(); return a.Current.GetSingle(); }
                    a.MoveNext(); int wcid = a.Current.GetInt32();
                    a.MoveNext(); uint cell = a.Current.GetUInt32();
                    var pos = new Vector3(F(), F(), F());
                    float qw = F(), qx = F(), qy = F(), qz = F();
                    list.Add((wcid, cell, pos, new Quaternion(qx, qy, qz, qw)));
                }
                d._spawns[Convert.ToInt32(p.Name, 16)] = list;
            }
        return d;
    }

    private static Weenie ReadWeenie(JsonElement e)
    {
        var w = new Weenie();
        foreach (var p in e.EnumerateObject())
        {
            var v = p.Value;
            switch (p.Name)
            {
                case "n": w.Name = v.GetString() ?? ""; break;
                case "t": w.Type = v.GetInt32(); break;
                case "setup": w.Setup = (uint)v.GetInt64(); break;
                case "mt": w.MotionTable = (uint)v.GetInt64(); break;
                case "snd": w.SoundTable = (uint)v.GetInt64(); break;
                case "pb": w.PaletteBase = (uint)v.GetInt64(); break;
                case "cb": w.ClothingBase = (uint)v.GetInt64(); break;
                case "pt": w.PaletteTemplate = v.GetInt32(); break;
                case "cp": w.ClothingPriority = v.GetInt32(); break;
                case "sh": w.Shade = v.GetSingle(); break;
                case "sc": w.Scale = v.GetSingle(); break;
                case "gr": w.GenRadius = v.GetSingle(); break;
                case "ginit": w.GenInit = v.GetInt32(); break;
                case "gmax": w.GenMax = v.GetInt32(); break;
                case "eyes": w.Eyes = (uint)v.GetInt64(); break;
                case "nose": w.Nose = (uint)v.GetInt64(); break;
                case "mouth": w.Mouth = (uint)v.GetInt64(); break;
                case "head": w.Head = (uint)v.GetInt64(); break;
                case "hairp": w.HairPalette = (uint)v.GetInt64(); break;
                case "eyep": w.EyesPalette = (uint)v.GetInt64(); break;
                case "skinp": w.SkinPalette = (uint)v.GetInt64(); break;
                case "vis": w.Hidden = v.GetInt32() != 0; break;
                case "cmt": w.CombatTable = (uint)v.GetInt64(); break;
                case "lvl": w.Level = v.GetInt32(); break;
                case "tol": w.Tolerance = v.GetInt32(); break;
                case "it": w.ItemType = v.GetInt32(); break;
                case "atk": w.Attackable = v.GetInt32() != 0; break;
                case "imm": w.Immobile = v.GetInt32() != 0; break;
                case "var": w.Awareness = v.GetSingle(); break;
                case "pwr": w.PowerupTime = v.GetSingle(); break;
                case "regen": w.Regen = v.GetSingle(); break;
                case "hp": w.Health = v.GetInt32(); break;
                case "dmg": w.Damage = v.GetInt32(); break;
                case "dt": w.DamageType = v.GetInt32(); break;
                case "cstyle": w.CombatStyle = v.GetInt32(); break;
                case "dvar": w.DamageVariance = v.GetSingle(); break;
                case "icon": w.Icon = (uint)v.GetInt64(); break;
                case "dtt": w.DeathTreasure = (uint)v.GetInt64(); break;
                case "xp": w.Xp = v.GetInt32(); break;
                case "val": w.Value = v.GetInt32(); break;
                case "bur": w.Burden = v.GetInt32(); break;
                case "wsk": w.WeaponSkill = v.GetInt32(); break;
                case "wtime": w.WeaponTime = v.GetInt32(); break;
                case "loc": w.ValidLocations = v.GetInt32(); break;
                case "al": w.ArmorLevel = v.GetInt32(); break;
                case "maxstack": w.MaxStack = v.GetInt32(); break;
                case "struct": w.Uses = v.GetInt32(); break;
                case "maxstruct": w.MaxUses = v.GetInt32(); break;
                case "mana": w.Mana = v.GetInt32(); break;
                case "maxmana": w.MaxMana = v.GetInt32(); break;
                case "attr": { int i = 0; foreach (var x in v.EnumerateArray()) if (i < 6) w.Attributes[i++] = x.GetInt32(); break; }
                case "sk": foreach (var x in v.EnumerateObject()) w.Skills[int.Parse(x.Name)] = x.Value.GetInt32(); break;
                case "bp":
                    foreach (var x in v.EnumerateArray())
                    {
                        var armor = new float[8];
                        for (int i = 0; i < 8; i++) armor[i] = x[4 + i].GetSingle();
                        w.BodyParts.Add(new BodyPart(x[0].GetInt32(), x[1].GetInt32(), x[2].GetSingle(), x[3].GetSingle(), armor,
                                                     x[12].GetSingle(), x[13].GetSingle(), x[14].GetSingle()));
                    }
                    break;
                case "ap": foreach (var x in v.EnumerateArray()) w.AnimParts.Add((x[0].GetInt32(), (uint)x[1].GetInt64())); break;
                case "pal": foreach (var x in v.EnumerateArray()) w.Palettes.Add(((uint)x[0].GetInt64(), x[1].GetInt32() * 8, x[2].GetInt32() * 8)); break;
                case "tm": foreach (var x in v.EnumerateArray()) w.TextureMaps.Add((x[0].GetInt32(), (uint)x[1].GetInt64(), (uint)x[2].GetInt64())); break;
                case "wear": foreach (var x in v.EnumerateArray()) w.Worn.Add((x[0].GetInt32(), x[1].GetInt32(), x[2].GetSingle())); break;
                case "gen":
                    foreach (var x in v.EnumerateArray())
                        w.Generates.Add(new Profile(x[0].GetSingle(), x[1].GetInt32(), x[2].GetInt32(), x[3].GetInt32(), x[4].GetInt32(),
                            x[5].GetInt32(), x[6].GetSingle(), (uint)x[7].GetInt64(),
                            new Vector3(x[8].GetSingle(), x[9].GetSingle(), x[10].GetSingle()),
                            new Quaternion(x[12].GetSingle(), x[13].GetSingle(), x[14].GetSingle(), x[11].GetSingle())));
                    break;
            }
        }
        return w;
    }

    /// <summary>
    /// What stands in a landblock when the world starts: its placed objects, and what its generators make (picked
    /// with a fixed seed, so it's the same every visit). <paramref name="ground"/> gives the terrain height at a
    /// landblock-relative x, y.
    /// </summary>
    public List<Placed> ForLandblock(int lbX, int lbY, Func<float, float, float> ground)
    {
        var result = new List<Placed>();
        if (!_spawns.TryGetValue((lbX << 8) | lbY, out var list)) return result;
        var rng = new Random((lbX << 8) | lbY);
        foreach (var (wcid, cell, pos0, rot) in list)
        {
            Vector3 pos = pos0;
            if (pos.Z <= -9998f) pos.Z = ground(pos.X, pos.Y);
            Place(result, wcid, cell, pos, rot, 0, 0f, rng, ground, 0);
        }
        return result;
    }

    private void Place(List<Placed> result, int wcid, uint cell, Vector3 pos, Quaternion rot, int pt, float shade,
                       Random rng, Func<float, float, float> ground, int depth)
    {
        var w = Get(wcid);
        if (w == null) return;
        // a chest is drawn and also fills itself; a generator proper is hidden and only makes things
        // a creature standing on the landscape rests on it the way its body would: on a slope, on the highest ground
        // under it (not sunk into the hillside with its centre on the ground)
        if (w.Type == 10 && (cell & 0xFFFF) < 0x100 && pos.X >= 0f && pos.X < 192f && pos.Y >= 0f && pos.Y < 192f)
        {
            float g0 = ground(pos.X, pos.Y);
            if (pos.Z < g0 + 2f)   // on the ground, or under it (an outdoor cell has nothing below the landscape)
            {
                float r = 0.5f * Math.Max(w.Scale, 0.2f), top = g0;
                foreach (var (dx, dy) in new[] { (r, 0f), (-r, 0f), (0f, r), (0f, -r) })
                    top = Math.Max(top, ground(Math.Clamp(pos.X + dx, 0f, 191.99f), Math.Clamp(pos.Y + dy, 0f, 191.99f)));
                pos.Z = top;
            }
        }
        // anything else on open landscape (a portal, a chest, a sign) is never below the ground under it
        else if ((cell & 0xFFFF) < 0x100 && pos.X >= 0f && pos.X < 192f && pos.Y >= 0f && pos.Y < 192f)
        {
            float g0 = ground(pos.X, pos.Y);
            if (pos.Z < g0) pos.Z = g0;
        }
        if (!w.Hidden && w.Setup != 0)
            result.Add(new Placed(wcid, cell, w.Type == 19 ? pos + new Vector3(0, 0, DoorLift) : pos, rot, pt, shade));
        if (w.Generates.Count > 0) Generate(result, w, cell, pos, rot, rng, ground, depth);
    }

    private void Generate(List<Placed> result, Weenie gen, uint cell, Vector3 pos, Quaternion rot, Random rng,
                          Func<float, float, float> ground, int depth)
    {
        if (depth > 4) return;
        bool outdoors = (cell & 0xFFFF) < 0x100;
        void Make(Profile p, int count)
        {
            // only what ends up standing in the world: scattered or at a set spot (not inside a chest, worn, sold...)
            bool specific = (p.Where & 4) != 0, scatter = (p.Where & 2) != 0 || p.Where == 0 || (p.Where & 1) != 0;
            if (!specific && !scatter) return;
            for (int i = 0; i < Math.Min(count, 12); i++)
            {
                Vector3 at = pos;
                Quaternion r = rot;
                uint c = cell;
                if (specific)
                {
                    if (p.Cell != 0) { at = p.Origin; c = p.Cell; }
                    else
                    {
                        at = pos + p.Origin;
                        // a generator standing on the landscape: what it puts beside it stands on the ground there too
                        // (on a slope the generator's own height would leave it floating or buried)
                        if (outdoors && at.X >= 0f && at.X < 192f && at.Y >= 0f && at.Y < 192f && pos.X >= 0f && pos.X < 192f
                            && pos.Y >= 0f && pos.Y < 192f && Math.Abs(pos.Z - ground(pos.X, pos.Y)) < 0.5f)
                            at.Z = ground(at.X, at.Y) + p.Origin.Z;
                    }
                    r = p.Rotation;
                }
                else if (outdoors && gen.GenRadius > 0f)
                {
                    double a = rng.NextDouble() * Math.PI * 2, d = Math.Sqrt(rng.NextDouble()) * gen.GenRadius;
                    at = new Vector3(pos.X + (float)(Math.Cos(a) * d), pos.Y + (float)(Math.Sin(a) * d), 0f);
                    at.X = Math.Clamp(at.X, 0.5f, 191.5f); at.Y = Math.Clamp(at.Y, 0.5f, 191.5f);
                    at.Z = ground(at.X, at.Y);
                    r = Quaternion.CreateFromAxisAngle(Vector3.UnitZ, (float)(rng.NextDouble() * Math.PI * 2));
                }
                Place(result, p.Wcid, c, at, r, p.PaletteTemplate, p.Shade, rng, ground, depth + 1);
            }
        }
        // lines with probability -1 always make theirs; the rest share the generator's count by chance
        var chance = new List<Profile>();
        foreach (var p in gen.Generates)
        {
            if (p.Probability < 0f) Make(p, Math.Max(1, p.Init));
            else chance.Add(p);
        }
        if (chance.Count == 0) return;
        int n = Math.Clamp(gen.GenInit, 0, 12);
        for (int i = 0; i < n; i++)
        {
            double roll = rng.NextDouble();
            Profile pick = chance[^1];
            foreach (var p in chance) if (roll < p.Probability) { pick = p; break; }
            Make(pick, 1);
        }
    }
}
