using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using ACGodot.Objects;
using AcDream.Core.Meshing;
using AcDream.Core.Physics;
using AcDream.Core.Textures;
using DatReaderWriter.DBObjs;
using DatReaderWriter.Enums;
using Godot;
using NVector3 = System.Numerics.Vector3;
using NMatrix = System.Numerics.Matrix4x4;

namespace ACGodot.Creatures;

/// <summary>
/// How a creature, NPC or placed object looks, as ACE dresses it: the model (Setup) with its clothing table's part
/// swaps, retextures and colours for its palette template, the weenie's own changes, then what it wears (outer
/// layers last). Posed in its motion table's idle frame. Each look is merged into one mesh in the object's own
/// space; an instance's transform puts it in the world.
///
/// Threading: <see cref="Prepare"/> reads and decodes (any thread); <see cref="Mesh"/> uploads (main thread).
/// </summary>
public sealed class CreatureAssets
{
    /// <summary>A look: which weenie, and the colours a generator gave it.</summary>
    /// <summary>A look: the weenie, a palette template and shade over its own, and (the player) what's worn over it - the items' wcids.</summary>
    public readonly record struct Key(int Wcid, int PaletteTemplate, float Shade, string Worn = "");

    /// <summary>The body parts a wearing place covers (clothing and armor of a part count the same): head, chest,
    /// abdomen, upper arms, lower arms, hands, upper legs, lower legs, feet as bits 0-8.</summary>
    public static int BodyParts(int loc)
    {
        int p = 0;
        if ((loc & 0x1) != 0) p |= 1;
        if ((loc & (0x2 | 0x200)) != 0) p |= 2;
        if ((loc & (0x4 | 0x400)) != 0) p |= 4;
        if ((loc & (0x8 | 0x800)) != 0) p |= 8;
        if ((loc & (0x10 | 0x1000)) != 0) p |= 16;
        if ((loc & 0x20) != 0) p |= 32;
        if ((loc & (0x40 | 0x2000)) != 0) p |= 64;
        if ((loc & (0x80 | 0x4000)) != 0) p |= 128;
        if ((loc & 0x100) != 0) p |= 256;
        return p;
    }

    private sealed class Group
    {
        public readonly List<Vector3> Pos = new(), Nrm = new();
        public readonly List<Vector2> Uv = new();
        public readonly List<int> Idx = new(), Bone = new();
        public float Lum;
    }

    private sealed class Look
    {
        public readonly Dictionary<(string tex, TranslucencyKind kind), Group> Groups = new();
        // animated: the vertices stay in their parts' own axes, each part a bone the idle cycle moves
        public bool Animated;
        public int Parts;
        public NVector3[] PartScale = Array.Empty<NVector3>();
        public DatReaderWriter.DBObjs.Animation? Anim;
        public Setup? Setup;
        public DatReaderWriter.Types.AnimationFrame? Idle;
        public MotionTable? Table;
        public int Low, High;
        public float Fps = 30f, Scale = 1f;
    }

    private readonly Dats _dats;
    private readonly ObjectAssets _assets;
    private readonly SpawnData _data;
    private readonly ConcurrentDictionary<Key, Look?> _looks = new();
    // decoded pixels kept only until the material is made (then they're on the graphics card): null after that, and
    // decoded again by the recipe if another material needs them
    private readonly ConcurrentDictionary<string, DecodedTexture?> _textures = new();
    private readonly ConcurrentDictionary<string, Func<DecodedTexture>> _recipes = new();
    private readonly Dictionary<Key, ArrayMesh?> _meshes = new();
    private readonly Dictionary<(string, TranslucencyKind, float), Material> _materials = new();
    private readonly Loader _anims;

    private sealed class Loader : IAnimationLoader
    {
        private readonly Dats _d;
        public Loader(Dats d) { _d = d; }
        public DatReaderWriter.DBObjs.Animation? LoadAnimation(uint id) => _d.Get<DatReaderWriter.DBObjs.Animation>(id);
    }

    public CreatureAssets(Dats dats, ObjectAssets assets, SpawnData data)
    {
        _dats = dats; _assets = assets; _data = data; _anims = new Loader(dats);
    }

    public SpawnData Data => _data;

    private readonly Dictionary<Key, double> _meshUsed = new();

    /// <summary>Lets go of creature looks nothing in the world is drawing (main thread): a mesh nothing but this cache holds,
    /// not asked for in <paramref name="maxAge"/> seconds, with its look and materials no mesh uses. Made again if needed.</summary>
    public (int meshes, int materials) Trim(double maxAge)
    {
        double now = System.Environment.TickCount64 / 1000.0;
        int nm = 0, nmat = 0;
        foreach (var k in _meshes.Keys.ToList())
        {
            var m = _meshes[k];
            double used = _meshUsed.TryGetValue(k, out var u) ? u : 0;
            if (now - used < maxAge) continue;
            if (m != null && m.GetReferenceCount() > 1) { _meshUsed[k] = now; continue; }
            _meshes.Remove(k); _meshUsed.Remove(k); _looks.TryRemove(k, out _); _skins.Remove(k); nm++;
        }
        foreach (var k in _materials.Keys.ToList())
            if (_materials[k].GetReferenceCount() <= 1) { _materials.Remove(k); nmat++; }
        return (nm, nmat);
    }

    /// <summary>Works out a placed object's look (any thread); false if it has nothing to draw.</summary>
    public bool Prepare(Key key)
    {
        if (_looks.TryGetValue(key, out var have)) return have != null;
        Look? look = null;
        try { look = Build(key); }
        catch (Exception ex) { GD.PushWarning($"weenie {key.Wcid}: {ex.Message}"); }
        _looks[key] = look;
        return look != null;
    }

    private Look? Build(Key key)
    {
        var w = _data.Get(key.Wcid);
        if (w == null) return null;

        // the parts and their places, in the idle pose
        var parts = new List<(uint gfx, NMatrix at)>();
        uint setupId = w.Setup;
        Setup? setup = null;
        MotionResolver.IdleCycle? cycle = null;
        DatReaderWriter.Types.AnimationFrame? idlePose = null;
        if ((setupId >> 24) == 0x02)
        {
            setup = _dats.Get<Setup>(setupId);
            if (setup == null) return null;
            DatReaderWriter.Types.AnimationFrame? idle = null;
            // posed by the server, with no motions of its own (a Boundary Marker, resting): still, in that pose - its
            // model's default motion table stood it on its side
            if (w.Placement >= 0 && w.MotionTable == 0 && setup.PlacementFrames.TryGetValue((DatReaderWriter.Enums.Placement)w.Placement, out var placed))
            {
                foreach (var mr in SetupMesh.Flatten(setup, placed)) parts.Add((mr.GfxObjId, mr.PartTransform));
                idlePose = placed;
            }
            else
            try
            {
                cycle = MotionResolver.GetIdleCycle(setup, _dats, _anims, w.MotionTable != 0 ? w.MotionTable : null);
                idle = MotionResolver.GetIdleFrame(setup, _dats, _anims, w.MotionTable != 0 ? w.MotionTable : null);
            }
            catch { idle = null; cycle = null; }
            if (parts.Count == 0)
            {
                foreach (var mr in SetupMesh.Flatten(setup, idle)) parts.Add((mr.GfxObjId, mr.PartTransform));
                idlePose = idle;
            }
        }
        else if ((setupId >> 24) == 0x01) parts.Add((setupId, NMatrix.Identity));
        else return null;

        // the clothing, colours and retextures (ACE's CalculateObjDesc order)
        uint paletteBase = w.PaletteBase;
        var subPalettes = new List<(uint id, int offset, int length)>();
        var partSwaps = new Dictionary<int, uint>();
        var texSwaps = new Dictionary<int, Dictionary<uint, uint>>();
        void Clothing(uint clothingBase, int pt, float shade)
        {
            if (clothingBase == 0) return;
            var ct = _dats.Get<ClothingTable>(clothingBase);
            if (ct == null) return;
            if (ct.ClothingBaseEffects.TryGetValue(setupId, out var eff))
                foreach (var oe in eff.CloObjectEffects)
                {
                    int idx = (int)oe.Index;
                    if ((uint)oe.ModelId != 0) partSwaps[idx] = (uint)oe.ModelId;
                    foreach (var te in oe.CloTextureEffects)
                    {
                        if (!texSwaps.TryGetValue(idx, out var m)) texSwaps[idx] = m = new Dictionary<uint, uint>();
                        m[(uint)te.OldTexture] = (uint)te.NewTexture;
                    }
                }
            if (pt > 0 && ct.ClothingSubPalEffects.TryGetValue((uint)pt, out var spe))
                foreach (var csp in spe.CloSubPalettes)
                {
                    var set = _dats.Get<PalSet>((uint)csp.PaletteSet);
                    if (set == null || set.Palettes.Count == 0) continue;
                    int pi = Math.Clamp((int)Math.Floor(shade * (set.Palettes.Count - 0.000001f)), 0, set.Palettes.Count - 1);
                    uint pal = (uint)set.Palettes[pi];
                    foreach (var range in csp.Ranges) subPalettes.Add((pal, (int)range.Offset, (int)range.NumColors));
                }
        }
        // a person's own face and colouring first (ACE's order: skin, hair, eyes; then the head model and face
        // textures), so clothing laid over it afterwards wins where they share colours
        // (ACE's ranges are in eights of colours - skin 0x00/0x18, hair 0x18/0x08, eyes 0x20/0x08 - so in colours:
        // skin 0-191, hair 192-255, eyes 256-319; taken as plain colours only the first few changed, and the
        // creation screen's skin, hair and eye colours did nothing you could see)
        uint skinP = w.SkinPalette, hairP = w.HairPalette, eyesP = w.EyesPalette;
        uint headDefault = 0;
        if (skinP == 0 && !w.Exact && FaceDefaults(setupId, key.Wcid) is { } fd)
        {
            // a person with no colouring of their own gets one character creation could have made (the same each time):
            // skin, hair and eye colours and a hair style (without, they were bald and raw pink)
            skinP = fd.skin;
            if (hairP == 0) hairP = fd.hair;
            if (eyesP == 0) eyesP = fd.eyes;
            headDefault = fd.head;
        }
        if (skinP != 0) subPalettes.Add((skinP, 0x00 * 8, 0x18 * 8));
        if (hairP != 0) subPalettes.Add((hairP, 0x18 * 8, 0x08 * 8));
        if (eyesP != 0) subPalettes.Add((eyesP, 0x20 * 8, 0x08 * 8));
        if (w.Head != 0) partSwaps[0x10] = w.Head;
        else if (headDefault != 0) partSwaps[0x10] = headDefault;
        var faceSwaps = new Dictionary<uint, uint>();
        if (w.Eyes != 0 || w.Nose != 0 || w.Mouth != 0)
        {
            var (eyes, nose, mouth) = FaceTextures(setupId);
            void Face(HashSet<uint> set, uint to) { if (to != 0) foreach (uint t in set) if (t != to) faceSwaps[t] = to; }
            Face(eyes, w.Eyes); Face(nose, w.Nose); Face(mouth, w.Mouth);
        }
        bool overridden = key.PaletteTemplate != 0;
        Clothing(w.ClothingBase, overridden ? key.PaletteTemplate : w.PaletteTemplate, overridden ? key.Shade : w.Shade);
        foreach (var (index, gfx) in w.AnimParts) partSwaps[index] = gfx;
        foreach (var p in w.Palettes) subPalettes.Add(p);
        foreach (var (index, oldTex, newTex) in w.TextureMaps)
        {
            if (!texSwaps.TryGetValue(index, out var m)) texSwaps[index] = m = new Dictionary<uint, uint>();
            m[oldTex] = newTex;
        }
        var wornList = w.Worn.ToList();
        // what the player has on (armor, clothing) replaces the body's own outfit where they cover the same parts
        // (the starting robe comes off under a breastplate)
        if (!string.IsNullOrEmpty(key.Worn))
        {
            var mine = new List<(int wcid, int paletteTemplate, float shade)>();
            int covered = 0;
            bool only = key.Worn.StartsWith('!');   // the player: what they have on is all there is
            foreach (var part in key.Worn.TrimStart('!').Split(',', StringSplitOptions.RemoveEmptyEntries))
            {
                var f = part.Split(':');
                if (!int.TryParse(f[0], out int wcid)) continue;
                int pal = f.Length > 1 && int.TryParse(f[1], out int p0) ? p0 : 0;
                float sh = f.Length > 2 && float.TryParse(f[2], System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out float s0) ? s0 : 0f;
                mine.Add((wcid, pal, sh));
                covered |= BodyParts(_data.Get(wcid)?.ValidLocations ?? 0);
            }
            if (only) wornList.Clear();
            else wornList.RemoveAll(d => (BodyParts(_data.Get(d.wcid)?.ValidLocations ?? 0) & covered) != 0);
            wornList.AddRange(mine);
        }
        var worn = wornList.Select(it => (it, item: _data.Get(it.wcid))).Where(x => x.item != null && x.item.ClothingBase != 0)
                         .OrderBy(x => x.item!.ClothingPriority).ToList();
        foreach (var (it, item) in worn)
            Clothing(item!.ClothingBase, it.paletteTemplate != 0 ? it.paletteTemplate : item.PaletteTemplate,
                     it.paletteTemplate != 0 ? it.shade : item.Shade);
        // a palette of its own only counts with sub-palettes laid over it (a base alone changes nothing, as in the
        // client); a human with none set gets the human palette, else its textures' own default palettes show
        // their placeholder colours where the skin and clothes go
        bool recolour = subPalettes.Count > 0;
        if (recolour && paletteBase == 0 && (setupId == 0x02000001u || setupId == 0x0200004Eu)) paletteBase = 0x0400007Eu;
        string paletteSig = paletteBase.ToString("X") + ":" + string.Join(",", subPalettes.Select(s => $"{s.id:X}/{s.offset}/{s.length}"));

        // the parts, merged into one mesh per texture
        var look = new Look { Setup = setup, Idle = idlePose };
        float objScale = w.Scale <= 0f ? 1f : w.Scale;
        var scale = NMatrix.CreateScale(objScale);
        // a creature with an idle cycle of more than one frame is animated (a skinned mesh, one bone per part)
        // (a door too, though it stands still: it swings open and shut through its motion table; a chest, whose lid opens; and a house's sign, its
        // covenant crystal - still till the house is owned, then it drops a little and turns)
        if (setup != null && cycle != null && (cycle.HighFrame > cycle.LowFrame || (w.Type == 19 || w.Type == 20 || w.Type == 55) && w.MotionTable != 0) && cycle.Animation.PartFrames.Count > cycle.HighFrame)
        {
            look.Animated = true;
            look.Setup = setup;
            look.Table = _dats.Get<MotionTable>(w.MotionTable != 0 ? w.MotionTable : (uint)setup.DefaultMotionTable);
            look.Parts = parts.Count;
            look.Anim = cycle.Animation;
            look.Low = cycle.LowFrame; look.High = cycle.HighFrame;
            look.Fps = cycle.Framerate > 0f ? cycle.Framerate : 30f;
            look.Scale = objScale;
            look.PartScale = new NVector3[parts.Count];
            for (int i = 0; i < parts.Count; i++) look.PartScale[i] = i < setup.DefaultScale.Count ? setup.DefaultScale[i] : NVector3.One;
        }
        for (int i = 0; i < parts.Count; i++)
        {
            uint gfx = partSwaps.TryGetValue(i, out var sw) ? sw : parts[i].gfx;
            if (gfx == 0) continue;
            _assets.Prepare(gfx);
            var prep = _assets.GetPrepared(gfx);
            if (prep == null) continue;
            NMatrix at = look.Animated ? NMatrix.Identity : parts[i].at * scale;
            texSwaps.TryGetValue(i, out var swaps);
            if (faceSwaps.Count > 0)
            {
                var merged = new Dictionary<uint, uint>(faceSwaps);
                if (swaps != null) foreach (var kv in swaps) merged[kv.Key] = kv.Value;
                swaps = merged;
            }
            foreach (var sub in prep.Subs)
            {
                string tex = TextureFor(sub.surfaceId, swaps, recolour ? paletteSig : "", paletteBase, subPalettes);
                if (!look.Groups.TryGetValue((tex, sub.kind), out var g))
                    look.Groups[(tex, sub.kind)] = g = new Group { Lum = sub.luminosity };
                int first = g.Pos.Count;
                for (int v = 0; v < sub.pos.Length; v++)
                {
                    var p = NVector3.Transform(new NVector3(sub.pos[v].X, sub.pos[v].Y, sub.pos[v].Z), at);
                    var n = NVector3.Normalize(NVector3.TransformNormal(new NVector3(sub.nrm[v].X, sub.nrm[v].Y, sub.nrm[v].Z), at));
                    g.Pos.Add(new Vector3(p.X, p.Y, p.Z));
                    g.Nrm.Add(float.IsFinite(n.X) ? new Vector3(n.X, n.Y, n.Z) : Vector3.Up);
                    g.Uv.Add(sub.uv[v]);
                    g.Bone.Add(i);
                }
                foreach (int ix in sub.idx) g.Idx.Add(first + ix);
            }
        }
        return look.Groups.Count > 0 ? look : null;
    }

    private readonly ConcurrentDictionary<uint, (HashSet<uint>, HashSet<uint>, HashSet<uint>)> _faces = new();

    /// <summary>Skin, hair and eye palettes character creation offers for a body, picked by a number.</summary>
    private (uint skin, uint hair, uint eyes, uint head)? FaceDefaults(uint setupId, int seed)
    {
        try
        {
            var cg = _dats.Get<CharGen>(0x0E000002u);
            if (cg == null) return null;
            foreach (var hg in cg.HeritageGroups.Values)
                foreach (var sex in hg.Genders.Values)
                {
                    if ((uint)sex.SetupId != setupId) continue;
                    var rng = new Random(seed);
                    uint FromSet(uint id, double shade)
                    {
                        if ((id >> 24) != 0x0F) return id;   // already a palette
                        var set = _dats.Get<PalSet>(id);
                        if (set == null || set.Palettes.Count == 0) return 0;
                        return (uint)set.Palettes[Math.Clamp((int)(shade * set.Palettes.Count), 0, set.Palettes.Count - 1)];
                    }
                    // (the middle of the skin shades: the ends of the range came out raw pink)
                    uint skin = FromSet((uint)sex.SkinPalSet, 0.3 + rng.NextDouble() * 0.4);
                    uint hair = sex.HairColors.Count > 0 ? FromSet(sex.HairColors[rng.Next(sex.HairColors.Count)], rng.NextDouble()) : 0;
                    uint eyes = sex.EyeColors.Count > 0 ? FromSet(sex.EyeColors[rng.Next(sex.EyeColors.Count)], 0.5) : 0;
                    // a hair style (its head model)
                    uint head = 0;
                    var styles = sex.HairStyles.Where(h => !h.Bald && h.AlternateSetup == 0 && h.ObjDesc != null).ToList();
                    if (styles.Count > 0)
                        foreach (var ap in styles[rng.Next(styles.Count)].ObjDesc.AnimPartChanges)
                            if (ap.PartIndex == 0x10) head = (uint)ap.PartId;
                    return skin != 0 ? (skin, hair, eyes, head) : null;
                }
        }
        catch (Exception ex) { GD.PushWarning("character colours: " + ex.Message); }
        return null;
    }

    /// <summary>
    /// Every eyes, nose and mouth texture a body (Setup) can wear, from character creation's face strips: a person
    /// with face textures of their own has whichever of these their head shows swapped for theirs.
    /// </summary>
    private (HashSet<uint> eyes, HashSet<uint> nose, HashSet<uint> mouth) FaceTextures(uint setupId)
    {
        if (_faces.TryGetValue(setupId, out var have)) return have;
        var eyes = new HashSet<uint>(); var nose = new HashSet<uint>(); var mouth = new HashSet<uint>();
        try
        {
            var cg = _dats.Get<CharGen>(0x0E000002u);
            if (cg != null)
                foreach (var hg in cg.HeritageGroups.Values)
                    foreach (var sex in hg.Genders.Values)
                    {
                        if ((uint)sex.SetupId != setupId) continue;
                        void Add(HashSet<uint> set, DatReaderWriter.Types.ObjDesc? d)
                        {
                            if (d == null) return;
                            foreach (var tc in d.TextureChanges) { set.Add((uint)tc.OldTexture); set.Add((uint)tc.NewTexture); }
                        }
                        foreach (var e in sex.EyeStrips) { Add(eyes, e.ObjDesc); Add(eyes, e.BaldObjDesc); }
                        foreach (var n in sex.NoseStrips) Add(nose, n.ObjDesc);
                        foreach (var m in sex.MouthStrips) Add(mouth, m.ObjDesc);
                    }
        }
        catch (Exception ex) { GD.PushWarning("character faces: " + ex.Message); }
        var r = (eyes, nose, mouth);
        _faces[setupId] = r;
        return r;
    }

    /// <summary>The texture a part's surface shows (retextured and recoloured): decoded once, by a key.</summary>
    private string TextureFor(uint surfaceId, Dictionary<uint, uint>? swaps, string paletteSig, uint paletteBase,
                              List<(uint id, int offset, int length)> subPalettes)
    {
        Surface? s = _dats.Get<Surface>(surfaceId);
        if (s == null) return "magenta";
        uint tex = (uint)s.OrigTextureId;
        if (swaps != null && swaps.TryGetValue(tex, out var nt)) tex = nt;
        string key = $"{surfaceId:X}:{tex:X}:{paletteSig}";
        if (_textures.ContainsKey(key)) return key;
        bool recolour = paletteSig.Length > 0;
        var subs = new List<(uint id, int offset, int length)>(subPalettes);
        _recipes[key] = () => Decode(s, tex, recolour, paletteBase, subs);
        _textures[key] = Decode(s, tex, recolour, paletteBase, subs);
        return key;
    }

    private DecodedTexture Decode(Surface s, uint tex, bool recolour, uint paletteBase, List<(uint id, int offset, int length)> subPalettes)
    {
        float opacity = TranslucencyKindExtensions.OpacityFromSurfaceTranslucency(s.Type, s.Translucency);
        if (s.Type.HasFlag(SurfaceType.Base1Solid) || tex == 0)
        {
            if (s.ColorValue == null) return DecodedTexture.Magenta;
            bool seeThrough = s.Type.HasFlag(SurfaceType.Translucent) || s.Type.HasFlag(SurfaceType.Alpha) || s.Type.HasFlag(SurfaceType.InvAlpha);
            return new DecodedTexture(new byte[] { s.ColorValue.Red, s.ColorValue.Green, s.ColorValue.Blue, (byte)((seeThrough ? opacity : 1f) * 255f) }, 1, 1);
        }
        var st = _dats.Get<SurfaceTexture>(tex);
        if (st == null || st.Textures.Count == 0) return DecodedTexture.Magenta;
        var rs = _dats.Get<RenderSurface>((uint)st.Textures[0]);
        if (rs == null) return DecodedTexture.Magenta;
        Palette? pal = null;
        if (rs.DefaultPaletteId != 0)
        {
            pal = _dats.Get<Palette>(recolour && paletteBase != 0 ? paletteBase : rs.DefaultPaletteId);
            if (recolour && pal != null && subPalettes.Count > 0)
            {
                // the base palette with the colour ranges of the sub-palettes laid over it (same indices)
                var colours = new List<DatReaderWriter.Types.ColorARGB>(pal.Colors);
                foreach (var (id, offset, length) in subPalettes)
                {
                    var sp = _dats.Get<Palette>(id);
                    if (sp == null) continue;
                    // a full-size palette gives the same slots; a short one (a skin, hair or eye colour set) is laid
                    // in from its start
                    bool full = sp.Colors.Count >= offset + length;
                    for (int i = offset; i < offset + length && i < colours.Count; i++)
                    {
                        int from = full ? i : i - offset;
                        if (from < sp.Colors.Count) colours[i] = sp.Colors[from];
                    }
                }
                pal = new Palette { Colors = colours };
            }
        }
        bool clip = s.Type.HasFlag(SurfaceType.Base1ClipMap), add = s.Type.HasFlag(SurfaceType.Additive);
        DecodedTexture d = SurfaceDecoder.DecodeRenderSurface(rs, pal, clip, add);
        if (opacity < 1f && !ReferenceEquals(d, DecodedTexture.Magenta)) d = SurfaceDecoder.ApplyAuthoredTranslucency(d, Math.Min(1f - opacity, 0.8f));
        return d;
    }

    /// <summary>A look's body and resting pose, for its particle effects.</summary>
    public (Setup? setup, DatReaderWriter.Types.AnimationFrame? pose) EffectSource(Key key) =>
        _looks.TryGetValue(key, out var l) && l != null ? (l.Setup, l.Idle) : (null, null);

    /// <summary>Whether a look plays an idle cycle (drawn with a skeleton rather than as a fixed mesh).</summary>
    public bool IsAnimated(Key key) => _looks.TryGetValue(key, out var l) && l != null && l.Animated;

    /// <summary>The object's own scale (an animated look's mesh isn't scaled; its node is).</summary>
    /// <summary>How tall and wide the object stands (its model's height and radius, scaled), 0 if unknown.</summary>
    public (float height, float radius) SizeOf(Key key)
    {
        if (!_looks.TryGetValue(key, out var l) || l?.Setup == null) return (0f, 0f);
        float sc = _data.Get(key.Wcid)?.Scale is float f && f > 0f ? f : 1f;
        return (l.Setup.Height * sc, Math.Max(l.Setup.Radius, 0.2f) * sc);
    }

    /// <summary>The object's sound table (its own, or its model's default), 0 if none.</summary>
    public uint SoundTableOf(Key key)
    {
        if (_data.Get(key.Wcid)?.SoundTable is uint t && t != 0) return t;
        return _looks.TryGetValue(key, out var l) && l?.Setup != null ? (uint)l.Setup.DefaultSoundTable : 0u;
    }

    /// <summary>The look's motion table (its animations by stance and motion), if it has one.</summary>
    public MotionTable? MotionTableOf(Key key) => _looks.TryGetValue(key, out var l) && l != null ? l.Table : null;

    /// <summary>
    /// How long an action (an attack, say) takes from a stance at its usual speed: the transition's animations from
    /// standing ready, frame count over frame rate. 0 if the table has no such action.
    /// </summary>
    public float ActionLength(Key key, uint style, uint motion) => LinkLength(key, style, 0x41000003u, motion);

    /// <summary>How long the way from one motion to another takes in a stance (a held gesture back to standing ready, say). 0 if there's none.</summary>
    public float LinkLength(Key key, uint style, uint from, uint to)
    {
        if (MotionTableOf(key) is not { } table) return 0f;
        int k = (int)((style << 16) | (from & 0xFFFFFFu));
        if (!table.Links.TryGetValue(k, out var links) || !links.MotionData.TryGetValue((int)to, out var md)) return 0f;
        float t = 0f;
        foreach (var ad in md.Anims)
        {
            int frames;
            if (ad.HighFrame >= 0) frames = ad.HighFrame - ad.LowFrame + 1;
            else frames = (_anims.LoadAnimation((uint)ad.AnimId)?.PartFrames.Count ?? 0) - Math.Max(ad.LowFrame, 0);
            float rate = Math.Abs(ad.Framerate) > 0.01f ? Math.Abs(ad.Framerate) : 30f;
            t += Math.Max(frames, 0) / rate;
        }
        return t;
    }

    /// <summary>Whether the look's motion table can do a motion from a stance (an attack, or standing ready in it).</summary>
    public bool HasAction(Key key, uint style, uint motion)
    {
        if (MotionTableOf(key) is not { } table) return false;
        int k = (int)((style << 16) | (0x41000003u & 0xFFFFFFu));
        return table.Links.TryGetValue(k, out var links) && links.MotionData.ContainsKey((int)motion);
    }

    /// <summary>Whether the look's motion table has a stance (standing ready in it).</summary>
    public bool HasStance(Key key, uint style) =>
        MotionTableOf(key) is { } table && table.Cycles.ContainsKey((int)((style << 16) | (0x41000003u & 0xFFFFFFu)));

    public float ScaleOf(Key key) => _looks.TryGetValue(key, out var l) && l != null ? l.Scale : 1f;

    private readonly Dictionary<Key, Skin> _skins = new();

    /// <summary>A skeleton for an animated look (one bone per part) and the skin that binds its mesh to it.</summary>
    public (Skeleton3D skeleton, Skin skin) Rig(Key key)
    {
        if (!_looks.TryGetValue(key, out var look) || look == null) { Prepare(key); look = _looks[key]!; }
        var sk = new Skeleton3D();
        for (int i = 0; i < look.Parts; i++) sk.AddBone("p" + i);
        if (!_skins.TryGetValue(key, out var skin))
        {
            skin = new Skin();
            for (int i = 0; i < look.Parts; i++) skin.AddBind(i, Transform3D.Identity);
            _skins[key] = skin;
        }
        return (sk, skin);
    }

    /// <summary>
    /// A motion sequencer for one creature (OpenAC's port of the client's: it runs the motion table's default
    /// state - the idle cycle - with the client's own frame stepping and blending); null if it can't have one.
    /// </summary>
    public AnimationSequencer? Sequencer(Key key)
    {
        if (!_looks.TryGetValue(key, out var look) || look?.Setup == null || look.Table == null) return null;
        try
        {
            var seq = new AnimationSequencer(look.Setup, look.Table, _anims);
            seq.InitializeState();
            return seq;
        }
        catch (Exception ex) { GD.PushWarning($"weenie {key.Wcid} motion: {ex.Message}"); return null; }
    }

    /// <summary>Sets a skeleton's bones from a sequencer's part poses (each part's place in the object).</summary>
    public void Pose(Key key, Skeleton3D sk, IReadOnlyList<PartTransform> parts)
    {
        if (!_looks.TryGetValue(key, out var look) || look == null) return;
        int n = Math.Min(Math.Min(look.Parts, sk.GetBoneCount()), parts.Count);
        for (int i = 0; i < n; i++)
        {
            var o = parts[i].Origin;
            var q = parts[i].Orientation;
            var s = look.PartScale[i];
            sk.SetBonePosePosition(i, new Vector3(o.X, o.Y, o.Z));
            sk.SetBonePoseRotation(i, new Quaternion(q.X, q.Y, q.Z, q.W).Normalized());
            sk.SetBonePoseScale(i, new Vector3(s.X, s.Y, s.Z));
        }
    }

    /// <summary>Poses a skeleton at a time (seconds) through its look's idle cycle, blending between frames.</summary>
    public void Pose(Key key, Skeleton3D sk, double time)
    {
        if (!_looks.TryGetValue(key, out var look) || look == null || look.Anim == null) return;
        int span = look.High - look.Low + 1;
        double f = time * look.Fps;
        f -= Math.Floor(f / span) * span;
        int a = look.Low + (int)f, b = a + 1 > look.High ? look.Low : a + 1;
        float u = (float)(f - Math.Floor(f));
        var fa = look.Anim.PartFrames[a].Frames;
        var fb = look.Anim.PartFrames[b].Frames;
        int n = Math.Min(look.Parts, sk.GetBoneCount());
        for (int i = 0; i < n; i++)
        {
            if (i >= fa.Count || i >= fb.Count) break;
            var o = NVector3.Lerp(fa[i].Origin, fb[i].Origin, u);
            var q = System.Numerics.Quaternion.Slerp(fa[i].Orientation, fb[i].Orientation, u);
            var s = look.PartScale[i];
            sk.SetBonePosePosition(i, new Vector3(o.X, o.Y, o.Z));
            sk.SetBonePoseRotation(i, new Quaternion(q.X, q.Y, q.Z, q.W).Normalized());
            sk.SetBonePoseScale(i, new Vector3(s.X, s.Y, s.Z));
        }
    }

    /// <summary>The look's mesh (main thread), in AC object axes; null if nothing to draw.</summary>
    public ArrayMesh? Mesh(Key key)
    {
        _meshUsed[key] = System.Environment.TickCount64 / 1000.0;
        if (_meshes.TryGetValue(key, out var m)) return m;
        if (!_looks.TryGetValue(key, out var look) || look == null) { _meshes[key] = null; return null; }
        var mesh = new ArrayMesh();
        foreach (var kv in look.Groups)
        {
            var g = kv.Value;
            var arrays = new Godot.Collections.Array();
            arrays.Resize((int)Godot.Mesh.ArrayType.Max);
            arrays[(int)Godot.Mesh.ArrayType.Vertex] = g.Pos.ToArray();
            arrays[(int)Godot.Mesh.ArrayType.Normal] = g.Nrm.ToArray();
            arrays[(int)Godot.Mesh.ArrayType.TexUV] = g.Uv.ToArray();
            arrays[(int)Godot.Mesh.ArrayType.Index] = g.Idx.ToArray();
            if (look.Animated)
            {
                var bones = new int[g.Bone.Count * 4];
                var weights = new float[g.Bone.Count * 4];
                for (int v = 0; v < g.Bone.Count; v++) { bones[v * 4] = g.Bone[v]; weights[v * 4] = 1f; }
                arrays[(int)Godot.Mesh.ArrayType.Bones] = bones;
                arrays[(int)Godot.Mesh.ArrayType.Weights] = weights;
            }
            mesh.AddSurfaceFromArrays(Godot.Mesh.PrimitiveType.Triangles, arrays);
            // wrapped, a texture's edge texels blend with its far side and seams show as lines (down faces); only
            // one whose UVs run past its edges repeats
            bool tiles = g.Uv.Any(t => t.X < -0.01f || t.X > 1.01f || t.Y < -0.01f || t.Y > 1.01f);
            var mk = (kv.Key.tex + (tiles ? ":r" : ":c"), kv.Key.kind, g.Lum);
            if (!_materials.TryGetValue(mk, out var mat))
            {
                DecodedTexture d = DecodedTexture.Magenta;
                if (_textures.TryGetValue(kv.Key.tex, out var kept))
                    d = kept ?? (_recipes.TryGetValue(kv.Key.tex, out var again) ? again() : DecodedTexture.Magenta);
                _materials[mk] = mat = _assets.BuildMaterial(d, kv.Key.kind, g.Lum, repeat: tiles);
                if (kept != null) _textures[kv.Key.tex] = null;   // on the graphics card now
            }
            mesh.SurfaceSetMaterial(mesh.GetSurfaceCount() - 1, mat);
        }
        return _meshes[key] = mesh;
    }
}
