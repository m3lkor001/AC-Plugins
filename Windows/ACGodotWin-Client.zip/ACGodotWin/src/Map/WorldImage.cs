using System;
using System.Threading.Tasks;
using DatReaderWriter.DBObjs;
using Godot;

namespace ACGodot.Map;

/// <summary>
/// The world as a picture, from the game's own files: every landblock's 8 x 8 ground cells, coloured by their
/// terrain (each terrain type's texture averaged to one colour; water blue), lit by the slope. 2040 x 2040 pixels,
/// 10 to a map unit. Made once in the background (the first time takes a little while) and kept in
/// user://worldmap.png.
/// </summary>
public static class WorldImage
{
    public const int Size = 255 * 8;           // 2040
    public const float PxPerUnit = 10f;        // a landblock is 0.8 map units, 8 px
    private const string CachePath = "user://worldmap.png";

    /// <summary>Map coordinates to picture pixels (north up).</summary>
    public static Vector2 ToPx(double ns, double ew) => new((float)((ew + 101.95) * PxPerUnit), (float)(Size - (ns + 101.95) * PxPerUnit));
    public static (double ns, double ew) FromPx(Vector2 px) => (Size / PxPerUnit - px.Y / PxPerUnit - 101.95, px.X / PxPerUnit - 101.95);

    /// <summary>Loads the picture (made first if it isn't kept yet). Done is called on the game's thread.</summary>
    public static void Get(Dats dats, Terrain.TerrainTextures tex, Action<Image?> done)
    {
        if (FileAccess.FileExists(CachePath))
        {
            var img = Image.LoadFromFile(ProjectSettings.GlobalizePath(CachePath));
            if (img != null && img.GetWidth() == Size) { done(img); return; }
        }
        // the colours per terrain type, here (textures belong to the game's thread)
        var colors = new Color[32];
        for (int t = 0; t < 32; t++) colors[t] = new Color(0.35f, 0.4f, 0.25f);
        foreach (var kv in tex.Blending.TerrainTypeToLayer)
        {
            try
            {
                var layer = tex.Terrain.GetLayerData(kv.Value);
                if (layer.IsCompressed()) layer.Decompress();
                var small = (Image)layer.Duplicate();
                small.Resize(1, 1, Image.Interpolation.Bilinear);
                if (kv.Key < 32) colors[kv.Key] = small.GetPixel(0, 0);
            }
            catch { }
        }
        for (int t = 0x10; t <= 0x14; t++) colors[t] = colors[t].Lerp(new Color(0.15f, 0.3f, 0.55f), 0.5f);   // water: plainly water
        float[] heights = tex.HeightTable;
        string cacheFile = ProjectSettings.GlobalizePath(CachePath);
        Task.Run(() =>
        {
            Image? img = null;
            try
            {
                var data = new byte[Size * Size * 3];
                for (int lx = 0; lx < 255; lx++)
                    for (int ly = 0; ly < 255; ly++)
                    {
                        LandBlock? b;
                        try { b = dats.Cell<LandBlock>(((uint)lx << 24) | ((uint)ly << 16) | 0xFFFFu); } catch { b = null; }
                        for (int cx = 0; cx < 8; cx++)
                            for (int cy = 0; cy < 8; cy++)
                            {
                                Color c = new(0.08f, 0.12f, 0.2f);
                                if (b != null)
                                {
                                    int i = cx * 9 + cy;
                                    int type = (b.Terrain[i] >> 2) & 0x1F;
                                    bool road = (b.Terrain[i] & 3) != 0;
                                    c = road ? new Color(0.55f, 0.48f, 0.36f) : colors[type];
                                    // lit from the north-west by the slope
                                    float h = heights[b.Height[i]], hx = heights[b.Height[i + 9]], hy = heights[b.Height[i + 1]];
                                    float shade = Math.Clamp(1f + ((hy - h) - (hx - h)) * 0.025f, 0.6f, 1.35f);
                                    c = new Color(Math.Min(c.R * shade, 1f), Math.Min(c.G * shade, 1f), Math.Min(c.B * shade, 1f));
                                }
                                int px = lx * 8 + cx, py = Size - 1 - (ly * 8 + cy);
                                int o = (py * Size + px) * 3;
                                data[o] = (byte)(c.R * 255); data[o + 1] = (byte)(c.G * 255); data[o + 2] = (byte)(c.B * 255);
                            }
                    }
                img = Image.CreateFromData(Size, Size, false, Image.Format.Rgb8, data);
                img.SavePng(cacheFile);
            }
            catch (Exception ex) { GD.PushWarning("world map picture: " + ex.Message); }
            var made = img;
            Callable.From(() => done(made)).CallDeferred();
        });
    }
}
