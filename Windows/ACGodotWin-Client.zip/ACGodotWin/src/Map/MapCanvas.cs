using System;
using System.Collections.Generic;
using System.Linq;
using ACGodot.UI;
using Godot;
using NVec2 = System.Numerics.Vector2;

namespace ACGodot.Map;

/// <summary>
/// The map's drawing area: the world picture (or a dungeon's layout), the places, you, the arrow's target and the
/// nav route. Drag to move, wheel to zoom at the mouse, hover for a place's name and notes, double-click a place to
/// point the arrow at it, right-click for the menu.
/// </summary>
public partial class MapCanvas : Control
{
    public MapWindow Owner_ = null!;
    public DungeonLayout? Layout;
    /// <summary>A dungeon is picked but the game's files have no layout for it: nothing of the world behind.</summary>
    public bool NoLayout;
    public int Level = int.MinValue;
    public Place? Flash;

    private NVec2 _center = new(0, 0);       // map units: x east, y north
    private float _scale = 6f;               // pixels per map unit
    private bool _drag, _moved;
    private Vector2 _dragFrom;
    private NVec2 _centerFrom;
    private Place? _hover;

    // names that would have piled up, drawn as one with an arrow (the ones behind it in Members)
    private sealed class Group { public Rect2 Box; public Vector2 At; public int Size; public Color Color; public List<Place> Members = new(); }
    private readonly List<Group> _groups = new();
    private Group? _hoverGroup;

    private Group? GroupAt(Vector2 at) => _groups.FirstOrDefault(g => g.Members.Count > 1 && g.Box.HasPoint(at));
    private double _flashTime;

    private static readonly Dictionary<string, Color> LayerColor = new()
    {
        ["Towns"] = new Color(1f, 0.85f, 0.35f), ["Housing"] = new Color(0.75f, 0.6f, 0.45f), ["Portals"] = new Color(0.75f, 0.45f, 1f),
        ["Dungeons"] = new Color(0.95f, 0.35f, 0.3f), ["NPCs"] = new Color(0.45f, 0.85f, 1f), ["Vendors"] = new Color(0.4f, 1f, 0.5f),
        ["Lifestones"] = new Color(0.4f, 0.7f, 1f), ["Landmarks"] = new Color(0.9f, 0.9f, 0.9f), ["My points"] = new Color(1f, 0.5f, 0.85f),
    };

    // ── where things go ──
    private Vector2 ToScreen(double ns, double ew) => Size / 2 + new Vector2((float)(ew - _center.X) * _scale, -(float)(ns - _center.Y) * _scale);
    private (double ns, double ew) FromScreen(Vector2 p) { var d = (p - Size / 2) / _scale; return (_center.Y - d.Y, _center.X + d.X); }

    public void CenterOn(NVec2 at) { _center = at; QueueRedraw(); }
    public void ScaleAtLeast(float s) { _scale = Math.Max(_scale, s); QueueRedraw(); }
    /// <summary>How far in the map is zoomed (pixels to a map unit).</summary>
    public float ZoomLevel { get => _scale; set { _scale = Math.Clamp(value, 0.6f, 4000f); QueueRedraw(); } }
    /// <summary>Zoomed so that this many metres show each way from the middle (a map unit is 240 m).</summary>
    // (asked while the map is shut to its title bar, or not laid out yet, there's no size to fit to - it came out
    // zoomed as far out as it goes, a dungeon a speck in a blank map: kept, and done when the map has its size)
    private float _aroundWhenSized;
    public void ShowAround(float metres)
    {
        if (Math.Min(Size.X, Size.Y) < 60f)
        {
            if (_aroundWhenSized <= 0f) Resized += SizedNow;
            _aroundWhenSized = metres;
            return;
        }
        _scale = Math.Clamp(Math.Min(Size.X, Size.Y) / (2f * metres / 240f), 0.6f, 4000f); QueueRedraw();
    }
    private void SizedNow()
    {
        if (_aroundWhenSized <= 0f || Math.Min(Size.X, Size.Y) < 60f) return;
        float m = _aroundWhenSized; _aroundWhenSized = 0f;
        Resized -= SizedNow;
        ShowAround(m);
    }
    public void Zoom(float f) { _scale = Math.Clamp(_scale * f, 0.6f, 4000f); QueueRedraw(); }

    public void ShowWorld()
    {
        _center = new NVec2(0, 0);
        _scale = Math.Max(0.6f, Math.Min(Size.X, Size.Y) / 204f);
        QueueRedraw();
    }

    public void Frame(NVec2 min, NVec2 max)
    {
        _center = (min + max) / 2;
        var span = max - min;
        float sx = Size.X > 10 ? Size.X : 600, sy = Size.Y > 10 ? Size.Y : 440;
        _scale = Math.Clamp(Math.Min(sx / Math.Max(span.X, 0.01f), sy / Math.Max(span.Y, 0.01f)) * 0.9f, 0.6f, 4000f);
        QueueRedraw();
    }

    // ── what shows ──
    private IEnumerable<Place> Shown()
    {
        if (Layout != null)
        {
            // a dungeon's map: its own points (on the level shown, when one is picked)
            foreach (var p in Owner_.Data.Places)
            {
                if (p.DungeonLb != Layout.Landblock) continue;
                // (a version of the dungeon has its own points: "d:01D9v2" - the plain one's aren't its)
                if (Owner_.View.StartsWith("d:") && p.In != Owner_.View) continue;
                if (Level != int.MinValue && !double.IsNaN(p.Z) && (int)MathF.Round((float)p.Z / 6f) != Level) continue;
                yield return p;
            }
            yield break;
        }
        bool tier = Owner_.View == "tier11+";
        foreach (var p in Owner_.Data.Places)
        {
            if (tier ? p.In != "tier11+" && !(p.In == "" && Owner_.Data.Inside("tier11+", p.NS, p.EW)) : p.In != "") continue;
            if (!Owner_.LayerOn(p.Layer)) continue;
            if (p.Twin && Owner_.LayerOn("Dungeons")) continue;
            yield return p;
        }
    }

    private List<Place> PlacesAt(Vector2 screen)
    {
        var list = new List<Place>();
        foreach (var p in Shown())
            if (ToScreen(p.NS, p.EW).DistanceTo(screen) <= 7f) list.Add(p);
        return list;
    }

    public override void _Draw() { long __fw = ACGodot.FrameWatch.DrawStart(); try { DrawBody(); } finally { ACGodot.FrameWatch.Drew("Group", __fw); } }
    private void DrawBody()
    {
        DrawRect(new Rect2(Vector2.Zero, Size), new Color(0.04f, 0.05f, 0.08f));
        // the map's words in a smooth font of their own (bigger than the game's, with a dark edge to read over the picture)
        var font = ThemeDB.FallbackFont;
        if (Layout != null || NoLayout)   // (the world's names aren't on a dungeon's map)
        {
            _groups.Clear(); _hoverGroup = null;
            if (_hover != null && (Layout == null || _hover.DungeonLb != Layout.Landblock)) _hover = null;
        }
        if (Layout != null) DrawLayout(font);
        else if (NoLayout) { Words(font, new Vector2(8, Sz(18) + 6), "No layout for this dungeon in the game's files.", Sz(16), RetailTheme.Gold); ShowTip(); return; }
        else DrawWorld(font);
        // the nav route
        var route = Owner_.RoutePoints();
        if (route.Count > 0)
        {
            Vector2? last = null;
            var rc = new Color(0.3f, 1f, 1f);
            for (int i = 0; i < route.Count; i++)
            {
                var s = ToScreen(route[i].ns, route[i].ew);
                if (last is { } l) DrawLine(l, s, new Color(rc, 0.85f), 2f, true);
                DrawCircle(s, 5f, rc);
                Words(font, s + new Vector2(7, -5), (i + 1).ToString(), 13, rc);
                last = s;
            }
        }
        // the arrow's target
        if (Owner_.Arrow?.Target is { } t)
        {
            var s = ToScreen(t.ns, t.ew);
            DrawArc(s, 8f, 0, Mathf.Tau, 20, new Color(1f, 0.9f, 0.3f), 2f, true);
            DrawLine(s + new Vector2(-12, 0), s + new Vector2(12, 0), new Color(1f, 0.9f, 0.3f), 1f);
            DrawLine(s + new Vector2(0, -12), s + new Vector2(0, 12), new Color(1f, 0.9f, 0.3f), 1f);
        }
        // a plugin's travel target (MelksQB's arrow)
        if (Owner_.Mark is { } mk)
        {
            var s = ToScreen(mk.ns, mk.ew);
            var c = new Color(0.3f, 1f, 0.45f);
            DrawArc(s, 9f, 0, Mathf.Tau, 24, Colors.Black, 4f, true);
            DrawArc(s, 9f, 0, Mathf.Tau, 24, c, 2f, true);
            DrawCircle(s, 3f, c);
            if (!string.IsNullOrEmpty(mk.name))
            {
                Words(font, s + new Vector2(13, 5), mk.name, 14, c);
            }
        }
        // you
        uint myCell = Owner_.PlayerCell?.Invoke() ?? 0;
        // what's about you (within the radar's reach): in a dungeon on the level shown, outdoors once zoomed in
        if (Owner_.Player.Active && Owner_.Nearby != null && (Layout != null ? Layout.Landblock == (int)(myCell >> 16) : _scale > 1500))
        {
            var mePos = Owner_.Player.Position;
            foreach (var (feet, name, col, selected) in Owner_.Nearby())
            {
                if (feet.DistanceTo(mePos) > 75f) continue;
                var (cx, cy, cz) = World.ToAc(feet);
                if (Layout != null && Level != int.MinValue && DungeonLayout.LevelOf(cz + 0.5f) != Level) continue;
                var at = ToScreen(cy / 240f - 101.95f, cx / 240f - 101.95f);
                // (its colour: its name tag's - Options > Gameplay > Name tags - so a pet, a vendor, a portal look the same on both)
                DrawCircle(at, 4f, Colors.Black);
                DrawCircle(at, 3f, col);
                if (selected)   // what you have selected: a ring round it (as on the radar)
                {
                    DrawArc(at, 8f, 0, Mathf.Tau, 20, Colors.Black, 3f, true);
                    DrawArc(at, 8f, 0, Mathf.Tau, 20, col, 1.5f, true);
                }
                if (at.DistanceTo(GetLocalMousePosition()) < 9f) Words(font, at + new Vector2(10, 5), name, Sz(13), col);   // hovered: its name and level
            }
        }
        if (Owner_.Player.Active && (Layout == null || (myCell & 0xFFFF) >= 0x100 && Layout.Landblock == (int)(myCell >> 16)))
        {
            var me = Owner_.PlayerMap;
            var s = ToScreen(me.Y, me.X);
            float b = -Owner_.Player.Heading;              // the bearing you face (clockwise from north)
            var f = new Vector2(Mathf.Sin(b), -Mathf.Cos(b));
            var r = new Vector2(-f.Y, f.X);
            DrawColoredPolygon(new[] { s + f * 11, s - f * 6 + r * 6, s - f * 3, s - f * 6 - r * 6 }, new Color(1f, 0.25f, 0.2f));
            DrawPolyline(new[] { s + f * 11, s - f * 6 + r * 6, s - f * 3, s - f * 6 - r * 6, s + f * 11 }, Colors.Black, 1f, true);
        }
        ShowTip();
    }

    // the hovered place's name and notes: a box of its own over everything (it can go past the map's edge), wrapped
    private PanelContainer? _tip;
    private RichTextLabel? _tipText;

    private void ShowTip()
    {
        if ((_hover == null && _hoverGroup == null) || !IsVisibleInTree()) { if (_tip != null) _tip.Visible = false; return; }
        if (_tip == null)
        {
            _tip = new PanelContainer { TopLevel = true, MouseFilter = MouseFilterEnum.Ignore, ZIndex = 100 };
            _tip.AddThemeStyleboxOverride("panel", new StyleBoxFlat { BgColor = new Color(0.06f, 0.05f, 0.03f, 0.95f), BorderColor = new Color(0.62f, 0.47f, 0.22f),
                                                                       BorderWidthLeft = 1, BorderWidthRight = 1, BorderWidthTop = 1, BorderWidthBottom = 1,
                                                                       ContentMarginLeft = 6, ContentMarginRight = 6, ContentMarginTop = 4, ContentMarginBottom = 4 });
            _tipText = new RichTextLabel { BbcodeEnabled = true, FitContent = true, ScrollActive = false, MouseFilter = MouseFilterEnum.Ignore,
                                           AutowrapMode = TextServer.AutowrapMode.WordSmart };
            _tipText.AddThemeFontOverride("normal_font", ThemeDB.FallbackFont);
            _tipText.AddThemeFontOverride("bold_font", ThemeDB.FallbackFont);
            _tip.AddChild(_tipText);
            AddChild(_tip);
        }
        int fs = Sz(15);
        _tipText!.AddThemeFontSizeOverride("normal_font_size", fs);
        _tipText.AddThemeFontSizeOverride("bold_font_size", fs + 1);
        string head, notes;
        Vector2 spot;
        if (_hoverGroup is { } hg)
        {
            // a group: all its names (click to pick one)
            head = $"{hg.Members.Count} places here  (click to pick one)";
            notes = string.Join("\n", hg.Members.Take(40).Select(m => $"{m.Name}  ({m.Type})")) + (hg.Members.Count > 40 ? $"\n... and {hg.Members.Count - 40} more" : "");
            spot = hg.At + new Vector2(hg.Box.Size.X - 6, -hg.Size);
        }
        else
        {
            var hv = _hover!;
            head = $"{hv.Name}  ({hv.Type})";
            if (hv.MinLevel > 0 || hv.MaxLevel > 0) head += $"  lvl {hv.MinLevel}-{(hv.MaxLevel > 0 ? hv.MaxLevel : 999)}";
            notes = hv.Notes.Length > 600 ? hv.Notes[..600] + "..." : hv.Notes;
            spot = ToScreen(hv.NS, hv.EW);
        }
        _tipText.Text = $"[color=#{RetailTheme.Gold.ToHtml(false)}]{Esc(head)}[/color]" + (notes.Length > 0 ? $"\n[color=#{RetailTheme.Ink.ToHtml(false)}]{Esc(notes)}[/color]" : "");
        // as wide as it needs, up to a readable width
        float widest = ThemeDB.FallbackFont.GetStringSize(head, HorizontalAlignment.Left, -1, fs + 1).X;
        foreach (var line in notes.Split('\n')) widest = Math.Max(widest, ThemeDB.FallbackFont.GetStringSize(line, HorizontalAlignment.Left, -1, fs).X);
        float w = Math.Min(widest + 8, 30f * fs);
        _tipText.CustomMinimumSize = new Vector2(w, 0);
        _tip.Size = Vector2.Zero;   // (shrinks to fit)
        _tip.ResetSize();
        var screen = GetViewportRect().Size;
        var at = GlobalPosition + spot + new Vector2(14, -8);
        var size = _tip.GetCombinedMinimumSize();
        if (at.X + size.X > screen.X - 4) at.X = Math.Max(4, at.X - size.X - 28);
        at.Y = Math.Clamp(at.Y, 4, Math.Max(4, screen.Y - size.Y - 4));
        _tip.GlobalPosition = at;
        _tip.Visible = true;
    }

    private static string Esc(string s) => s.Replace("[", "[lb]");

    public override void _Notification(int what)
    {
        if (what == NotificationVisibilityChanged && !IsVisibleInTree() && _tip != null) _tip.Visible = false;
        if (what == NotificationMouseExit && (_hover != null || _hoverGroup != null)) { _hover = null; _hoverGroup = null; QueueRedraw(); }
    }

    private void DrawWorld(Font font)
    {
        if (Owner_.Picture is { } pic)
        {
            // the picture's corners: map (-101.95..102.05)
            var tl = ToScreen(WorldImage.Size / WorldImage.PxPerUnit - 101.95, -101.95);
            var br = ToScreen(-101.95, WorldImage.Size / WorldImage.PxPerUnit - 101.95);
            DrawTextureRect(pic, new Rect2(tl, br - tl), false);
        }
        // the tier 11+ area's boundary
        if (Owner_.View == "tier11+" && Owner_.Data.Boundaries.TryGetValue("tier11+", out var parts))
            foreach (var ring in parts)
            {
                var pts = ring.Select(p => ToScreen(p.ns, p.ew)).ToList();
                // (a ring is closed; a line walked from one shore to the other is left a line - joined end to end it drew a
                // chord straight across the area)
                if (ring.Length > 2 && Math.Abs(ring[0].ns - ring[^1].ns) + Math.Abs(ring[0].ew - ring[^1].ew) <= 0.3) pts.Add(pts[0]);
                DrawPolyline(pts.ToArray(), new Color(1f, 0.55f, 0.15f), 2f, true);
            }
        bool labels = Owner_.LayerOn("Labels");
        var rect = new Rect2(Vector2.Zero, Size).Grow(20);
        var names = new List<(Vector2 at, Place p, int size, Color c, int rank)>();
        foreach (var p in Shown())
        {
            var s = ToScreen(p.NS, p.EW);
            if (!rect.HasPoint(s)) continue;
            var c = p.Layer switch
            {
                // (portals, NPCs and vendors as their name tags are coloured)
                "Portals" => ACGodot.UI.NameTags.ColorOf("Portal"), "NPCs" => ACGodot.UI.NameTags.ColorOf("Npc"), "Vendors" => ACGodot.UI.NameTags.ColorOf("Vendor"),
                _ => LayerColor.TryGetValue(p.Layer, out var lc) ? lc : Colors.White,
            };
            if (p.Layer == "Towns") { DrawRect(new Rect2(s - new Vector2(4, 4), new Vector2(8, 8)), c); DrawRect(new Rect2(s - new Vector2(4, 4), new Vector2(8, 8)), Colors.Black, false, 1f); }
            else if (p.Layer == "Portals") { DrawCircle(s, 3.5f, c); DrawArc(s, 3.5f, 0, Mathf.Tau, 10, Colors.Black, 1f); }
            else if (p.Layer == "Dungeons") DrawColoredPolygon(new[] { s + new Vector2(0, -5), s + new Vector2(5, 0), s + new Vector2(0, 5), s + new Vector2(-5, 0) }, c);
            else DrawCircle(s, 2.5f, c);
            if (p.Random(Owner_.Data)) Words(font, s + new Vector2(5, -3), "?", Sz(15), c);
            // names: towns always (when labels are on); others once zoomed in enough
            if (labels && (p.Layer == "Towns" && _scale > 3f || _scale > 40f))
                names.Add((s + new Vector2(7, 5), p, p.Layer == "Towns" ? Sz(17) : Sz(14), c, LabelRank(p.Layer)));
        }
        // the names, most important first; one that would run into a name already there joins it instead (a group:
        // the first name shows, with a little arrow - hover for all of them, click to pick one)
        _groups.Clear();
        foreach (var (at, p, size, c, _) in names.OrderBy(n => n.rank))
        {
            var sz = font.GetStringSize(p.Name, HorizontalAlignment.Left, -1, size);
            var box = new Rect2(at.X - 2, at.Y - size, sz.X + 4, size + 4);
            var g = _groups.FirstOrDefault(x => x.Box.Intersects(box));
            if (g != null) { g.Members.Add(p); continue; }
            _groups.Add(new Group { Box = box, At = at, Size = size, Color = c, Members = { p } });
        }
        foreach (var g in _groups)
        {
            Words(font, g.At, g.Members[0].Name, g.Size, g.Color);
            if (g.Members.Count > 1)
            {
                // the arrow just after the name, and the box takes it in (to hover / click)
                float w = font.GetStringSize(g.Members[0].Name, HorizontalAlignment.Left, -1, g.Size).X;
                var tip = new Vector2(g.At.X + w + 5, g.At.Y - g.Size * 0.35f);
                float a = Math.Max(3f, g.Size * 0.3f);
                DrawColoredPolygon(new[] { tip + new Vector2(-a, -a * 0.6f), tip + new Vector2(a, -a * 0.6f), tip + new Vector2(0, a * 0.7f) }, Colors.Black);
                DrawColoredPolygon(new[] { tip + new Vector2(-a + 1, -a * 0.6f + 0.7f), tip + new Vector2(a - 1, -a * 0.6f + 0.7f), tip + new Vector2(0, a * 0.7f - 1.2f) }, RetailTheme.Gold);
                g.Box = new Rect2(g.Box.Position, new Vector2(Math.Max(g.Box.Size.X, w + 5 + a + 4), g.Box.Size.Y));
            }
        }
        if (Flash != null && Time.GetTicksMsec() / 1000.0 - _flashTime < 3)
            DrawArc(ToScreen(Flash.NS, Flash.EW), 10f + (float)(Time.GetTicksMsec() % 600) / 60f, 0, Mathf.Tau, 24, Colors.White, 2f, true);
    }

    private void DrawLayout(Font font)
    {
        var lay = Layout!;
        bool all = Level == int.MinValue;
        foreach (var (poly, level) in lay.Floors)
        {
            if (!all && level != Level) continue;
            var pts = poly.Select(v => ToScreen(v.Y, v.X)).ToArray();
            if (pts.Length >= 3 && Geometry2D.TriangulatePolygon(pts).Length > 0) DrawColoredPolygon(pts, all ? new Color(0.25f, 0.22f, 0.18f, 0.35f) : new Color(0.3f, 0.27f, 0.2f, 0.9f));
        }
        // where you've been in it this session: a trail of dots
        if (Owner_.Trails.TryGetValue(lay.Landblock, out var trail))
        {
            var tc = new Color(1f, 0.55f, 0.35f, all ? 0.45f : 0.8f);
            for (int i = 0; i < trail.Count; i++)
                if (all || trail[i].level == Level) DrawCircle(ToScreen(trail[i].at.Y, trail[i].at.X), 1.6f, tc);
        }
        // drops: a room two levels high seen from its upper level (its floor is a level down)
        foreach (var (poly, level) in lay.Drops)
        {
            if (!all && level != Level) continue;
            if (all) continue;   // (with every level shown, the room's floor below is there)
            var pts = poly.Select(v => ToScreen(v.Y, v.X)).ToArray();
            if (pts.Length >= 3 && Geometry2D.TriangulatePolygon(pts).Length > 0) DrawColoredPolygon(pts, new Color(0.32f, 0.32f, 0.34f, 0.95f));
        }
        // the tops of blocks standing in rooms: in the way
        foreach (var (poly, level) in lay.Raised)
        {
            if (!all && level != Level) continue;
            var pts = poly.Select(v => ToScreen(v.Y, v.X)).ToArray();
            if (pts.Length >= 3 && Geometry2D.TriangulatePolygon(pts).Length > 0) DrawColoredPolygon(pts, all ? new Color(0.1f, 0.09f, 0.07f, 0.4f) : new Color(0.12f, 0.1f, 0.08f, 0.95f));
        }
        // the ramps and stairs between levels: on every level they reach, with which way is up, and where they go
        foreach (var r in lay.Ramps)
        {
            int lo = DungeonLayout.LevelOf(r.ZLow), hi = DungeonLayout.LevelOf(r.ZHigh);
            if (!all && (Level < lo || Level > hi)) continue;
            var rampCol = new Color(0.35f, 0.75f, 0.85f, all ? 0.45f : 0.7f);
            foreach (var poly in r.Polys)
            {
                var pts = poly.Select(v => ToScreen(v.Y, v.X)).ToArray();
                if (pts.Length >= 3 && Geometry2D.TriangulatePolygon(pts).Length > 0) DrawColoredPolygon(pts, rampCol);
            }
            var c = ToScreen(r.Center.Y, r.Center.X);
            if (r.Up != System.Numerics.Vector2.Zero)
            {
                var dir = new Vector2(r.Up.X, -r.Up.Y);   // (screen y runs down)
                float len = Math.Clamp(_scale * 0.012f, 10f, 40f);
                var tail = c - dir * len * 0.5f; var tip = c + dir * len * 0.5f;
                DrawLine(tail, tip, Colors.White, 2f, true);
                var side = new Vector2(-dir.Y, dir.X);
                DrawColoredPolygon(new[] { tip + dir * 5f, tip - dir * 3f + side * 5f, tip - dir * 3f - side * 5f }, Colors.White);
            }
            if (!all && hi != lo)
            {
                string where = Level < hi && Level > lo ? $"up {lay.Label(hi)} / down {lay.Label(lo)}" : Level < hi ? $"up to level {lay.Label(hi)}" : $"down to level {lay.Label(lo)}";
                Words(font, c + new Vector2(8, -6), where, Sz(12), new Color(0.6f, 0.95f, 1f));
            }
        }
        foreach (var (a, b, level) in lay.Walls)
        {
            if (!all && level != Level) continue;
            // levels below the one shown are dimmer when all are shown
            float shade = all ? 0.45f + 0.55f * (lay.Levels.Count > 1 ? (float)(level - lay.Levels.Min) / (lay.Levels.Max - lay.Levels.Min) : 1f) : 1f;
            DrawLine(ToScreen(a.Y, a.X), ToScreen(b.Y, b.X), new Color(0.95f * shade, 0.85f * shade, 0.6f * shade), _scale > 400 ? 2f : 1f, true);
        }
        Words(font, new Vector2(8, Sz(18) + 6), Owner_.Data.DungeonName(lay.Landblock) + (all ? "" : $"  -  level {lay.Label(Level)}"), Sz(18), RetailTheme.Gold);
        // its points (doors, levers, chests ... - your own, and those brought over from ACMaps)
        foreach (var p in Shown())
        {
            var s = ToScreen(p.NS, p.EW);
            var c = PointColor(p.Type);
            DrawCircle(s, 4.5f, Colors.Black);
            DrawCircle(s, 3.5f, c);
            if (_scale > 300 || p == _hover) Words(font, s + new Vector2(6, 4), p.Name, Sz(12), c);
        }
    }

    private static Color PointColor(string type) => type switch
    {
        "Door" => new Color(0.95f, 0.65f, 0.3f), "Lever / switch" => new Color(0.4f, 0.9f, 1f), "Chest" => new Color(1f, 0.85f, 0.2f),
        "Portal" => new Color(0.85f, 0.5f, 1f), "Hunting spot" => new Color(1f, 0.4f, 0.4f), _ => new Color(0.6f, 1f, 0.6f),
    };

    // which names win a crowded spot: towns, then dungeons, portals, lifestones..., housing last
    private static int LabelRank(string layer) => layer switch
    {
        "Towns" => 0, "My points" => 1, "Dungeons" => 2, "Portals" => 3, "Lifestones" => 4, "Landmarks" => 5, "Vendors" => 6, "NPCs" => 7, _ => 8,
    };

    /// <summary>The right-click menu for a spot on the map (also when a right-click elsewhere shut the one open).</summary>
    public void RightClickAt(Vector2 local, Vector2 global)
    {
        var (ns, ew) = FromScreen(local);
        var places = PlacesAt(local);
        double z = 0;
        if (Owner_.Ground is { } g && g(World.FromMapCoords(ns, ew)) is float h) z = h;
        int dungeon = Layout?.Landblock ?? -1;
        Owner_.OpenMenu(new MapSpot(ns, ew, z, null, dungeon), places, global);
    }

    // a size at the chosen text size (Options > Character > Text size)
    private static int Sz(int size) => (int)MathF.Round(size * RetailTheme.Scale * MapWindow.TextScale);

    // words with a dark edge round them
    private void Words(Font font, Vector2 at, string text, int size, Color c)
    {
        DrawStringOutline(font, at, text, HorizontalAlignment.Left, -1, size, Math.Max(3, size / 4), new Color(0, 0, 0, 0.85f));
        DrawString(font, at, text, HorizontalAlignment.Left, -1, size, c);
    }

    // ── mouse ──
    public override void _GuiInput(InputEvent e)
    {
        switch (e)
        {
            case InputEventMouseButton { ButtonIndex: MouseButton.WheelUp or MouseButton.WheelDown, Pressed: true } wb:
            {
                var before = FromScreen(wb.Position);
                Zoom(wb.ButtonIndex == MouseButton.WheelUp ? 1.2f : 1 / 1.2f);
                var after = FromScreen(wb.Position);
                _center += new NVec2((float)(before.ew - after.ew), (float)(before.ns - after.ns));
                AcceptEvent();
                break;
            }
            case InputEventMouseButton { ButtonIndex: MouseButton.Left } mb:
                if (mb.DoubleClick && mb.Pressed)
                {
                    var at = PlacesAt(mb.Position);
                    var (ns, ew) = at.Count > 0 ? (at[0].NS, at[0].EW) : FromScreen(mb.Position);
                    string name = at.Count > 0 ? at[0].Name : new MapSpot(ns, ew, 0, null, -1).Coords;
                    Owner_.Arrow?.Point(ns, ew, name);
                    Owner_.SetStatus($"Arrow pointing to {name}");
                }
                else if (mb.Pressed) { _drag = true; _moved = false; _dragFrom = mb.Position; _centerFrom = _center; }
                else
                {
                    _drag = false;
                    // a click (not a drag) on a group's names: the list, to pick one (its menu)
                    if (!_moved && GroupAt(mb.Position) is { } grp) PickFrom(grp, mb.GlobalPosition);
                }
                AcceptEvent();
                break;
            case InputEventMouseButton { ButtonIndex: MouseButton.Right, Pressed: true } rb:
            {
                RightClickAt(rb.Position, rb.GlobalPosition);
                AcceptEvent();
                break;
            }
            case InputEventMouseMotion mm:
                if (_drag)
                {
                    var d = (mm.Position - _dragFrom) / _scale;
                    if ((mm.Position - _dragFrom).Length() > 3) _moved = true;
                    if (_moved) { _center = _centerFrom + new NVec2(-d.X, d.Y); Owner_.StopFollowing(); }
                }
                var hg = GroupAt(mm.Position);
                var hov = hg == null ? PlacesAt(mm.Position).FirstOrDefault() : null;
                if (hov != _hover || hg != _hoverGroup) { _hover = hov; _hoverGroup = hg; QueueRedraw(); }
                var (hns, hew) = FromScreen(mm.Position);
                if (!_drag) Owner_.SetStatus(new MapSpot(hns, hew, 0, null, -1).Coords);
                break;
        }
    }

    private PopupMenu? _pick;

    private void PickFrom(Group g, Vector2 screenAt)
    {
        _pick?.QueueFree();
        _pick = new PopupMenu();
        if (RetailTheme.Current is { } th) _pick.Theme = th;
        _pick.AddThemeFontOverride("font", ThemeDB.FallbackFont);
        _pick.AddThemeFontSizeOverride("font_size", Sz(15));
        var list = g.Members.Take(60).ToList();
        for (int i = 0; i < list.Count; i++) _pick.AddItem($"{list[i].Name}  ({list[i].Type})", i);
        _pick.IdPressed += id =>
        {
            var p = list[(int)id];
            // that place's own menu, as a right click on it alone
            double z = 0;
            if (Owner_.Ground is { } gr && gr(World.FromMapCoords(p.NS, p.EW)) is float h) z = h;
            Owner_.OpenMenu(new MapSpot(p.NS, p.EW, z, null, Layout?.Landblock ?? -1), new List<Place> { p }, screenAt);
        };
        AddChild(_pick);
        _pick.Popup(new Rect2I((Vector2I)screenAt, Vector2I.Zero));
        _hoverGroup = null; QueueRedraw();
    }

    public void StartFlash() => _flashTime = Time.GetTicksMsec() / 1000.0;
}

internal static class PlaceExt
{
    public static bool Random(this Place p, MapData d) => p.Layer == "Portals" && d.Random.Contains(p.Key);
}
