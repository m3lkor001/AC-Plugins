using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Xml;
using Godot;

namespace ACGodot.Map;

/// <summary>A place on the map: from the travel list, a learned portal, or one of your own points.</summary>
public sealed class Place
{
    /// <summary>A portal entry standing where the list also has its dungeon: not drawn while dungeons are.</summary>
    public bool Twin;
    public string Name = "", Type = "", Notes = "", Layer = "";
    public double NS, EW;
    public bool Mine;                 // one of your own points (can be changed and deleted)
    public string In = "";            // on a copy of an area's map ("tier11+"), not the world
    // a portal
    public bool HasExit;
    public double ExitNS, ExitEW;
    public uint Cell;                 // the cell it stands in (indoors): its dungeon's landblock
    public int MinLevel, MaxLevel;
    public double Z = double.NaN;     // in a dungeon: its height (which level it's on)
    /// <summary>In a dungeon's map ("d:01D9", or "d:01D9v2" for a version of it): that dungeon's landblock, else -1.</summary>
    public int DungeonLb => In.Length >= 6 && In.StartsWith("d:") && int.TryParse(In.AsSpan(2, 4), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out int lb) ? lb : -1;
    public string Key => $"{Name}@{NS.ToString("0.#####", CultureInfo.InvariantCulture)},{EW.ToString("0.#####", CultureInfo.InvariantCulture)}";
}

/// <summary>
/// What the map shows, as MelksQB's travel map has it: GoArrow's list of places (towns, portals, dungeons, NPCs,
/// vendors, lifestones, landmarks...), the portals learned in the game and your own points (MQT_Travel.xml, copied in
/// as data/map), Tou-Tou's tier 11+ area (its boundary, and what stands in its copies), dungeon names by landblock,
/// and which portals are random / not for routes. Your own points and portal flags are kept in user://map.cfg.
/// </summary>
public sealed class MapData
{
    private static readonly CultureInfo CI = CultureInfo.InvariantCulture;
    public readonly List<Place> Places = new();
    public readonly Dictionary<string, List<(double ns, double ew)[]>> Boundaries = new();
    public readonly Dictionary<int, string> DungeonNames = new();   // landblock (0xXXYY) -> name
    public readonly HashSet<string> Random = new(), Avoid = new();
    private const string UserPath = "user://map.cfg";

    public static readonly string[] Layers = { "Towns", "Housing", "Portals", "Dungeons", "NPCs", "Vendors", "Lifestones", "Landmarks", "My points", "Labels" };
    public static readonly string[] PointTypes = { "Custom", "Town", "Village", "Outpost", "Dungeon", "NPC", "Vendor", "Lifestone", "Landmark", "Portal" };

    public static string LayerOf(string type) => type switch
    {
        "Town" or "Outpost" or "CrossroadsOfDereth" => "Towns",
        // (the list's "Village"s are the housing settlements: cottages, villas, mansions)
        "Village" or "AllegianceHall" or "Housing" => "Housing",
        "SettlementPortal" or "PortalHub" or "WildernessPortal" or "UndergroundPortal" or "TownPortal" or "Portal" => "Portals",
        "Dungeon" => "Dungeons",
        "NPC" => "NPCs",
        "Vendor" => "Vendors",
        "Lifestone" or "Bindstone" => "Lifestones",
        "Landmark" => "Landmarks",
        _ => "My points",
    };

    /// <summary>MelksQB's own travel file, as it keeps it (portals it learns as you go): read in place of the copy when it's there.</summary>
    public static string LiveTravel => ProjectSettings.GlobalizePath("res://plugins/MelksQB/MQT_Travel.xml");

    public static MapData Load(string dir)
    {
        var d = new MapData();
        try { d.LoadList(Path.Combine(dir, "locations.xml")); } catch (Exception ex) { GD.PushWarning("map list: " + ex.Message); }
        string travel = File.Exists(LiveTravel) ? LiveTravel : Path.Combine(dir, "MQT_Travel.xml");
        try { d.LoadTravel(travel); } catch (Exception ex) { GD.PushWarning("map travel: " + ex.Message); }
        d.LoadUser();
        d.MarkTwins();
        return d;
    }

    private static bool Pair(string s, out double a, out double b)
    {
        a = b = 0;
        var p = (s ?? "").Split(',');
        return p.Length >= 2 && double.TryParse(p[0], NumberStyles.Float, CI, out a) && double.TryParse(p[1], NumberStyles.Float, CI, out b);
    }

    private void LoadList(string path)
    {
        if (!File.Exists(path)) return;
        var doc = new XmlDocument();
        doc.Load(path);
        foreach (XmlElement e in doc.SelectNodes("//loc")!)
        {
            if (!double.TryParse(e.GetAttribute("NS"), NumberStyles.Float, CI, out double ns) || !double.TryParse(e.GetAttribute("EW"), NumberStyles.Float, CI, out double ew)) continue;
            string type = e.GetAttribute("type");
            if (e.GetAttribute("customized") == "True") continue;   // GoArrow's own custom points come in through the travel file as "yours"
            var p = new Place { Name = e.GetAttribute("name"), Type = type, NS = ns, EW = ew, Layer = LayerOf(type), Notes = e.InnerText.Trim() };
            if (double.TryParse(e.GetAttribute("exitNS"), NumberStyles.Float, CI, out double xn) && double.TryParse(e.GetAttribute("exitEW"), NumberStyles.Float, CI, out double xe))
            { p.HasExit = true; p.ExitNS = xn; p.ExitEW = xe; }
            int.TryParse(e.GetAttribute("minLevel"), out p.MinLevel);
            int.TryParse(e.GetAttribute("maxLevel"), out p.MaxLevel);
            Places.Add(p);
        }
    }

    private void LoadTravel(string path)
    {
        if (!File.Exists(path)) return;
        var doc = new XmlDocument();
        doc.Load(path);
        var root = doc.DocumentElement!;
        foreach (XmlElement e in root.SelectNodes("portal")!)
        {
            if (!Pair(e.GetAttribute("a"), out double ns, out double ew)) continue;
            var p = new Place { Name = e.GetAttribute("n"), Type = "Portal", Layer = "Portals", NS = ns, EW = ew };
            if (Pair(e.GetAttribute("e"), out double xn, out double xe)) { p.HasExit = true; p.ExitNS = xn; p.ExitEW = xe; }
            if (uint.TryParse(e.GetAttribute("c"), NumberStyles.HexNumber, CI, out uint c)) p.Cell = c;
            int.TryParse(e.GetAttribute("min"), out p.MinLevel);
            int.TryParse(e.GetAttribute("max"), out p.MaxLevel);
            string inst = e.GetAttribute("in");
            p.In = inst.StartsWith("tier", StringComparison.OrdinalIgnoreCase) ? "tier11+" : "";
            // a learned portal replaces the list's portal at the same spot
            bool Twin(Place o) => o.Layer == "Portals" && !o.Mine && o.In == p.In && Math.Abs(o.NS - ns) < 0.25 && Math.Abs(o.EW - ew) < 0.25 && Same(o.Name, p.Name);
            // (where it goes, kept from the list's when the learned one doesn't know yet - not used yet, or it shows no destination)
            if (!p.HasExit && Places.FirstOrDefault(o => Twin(o) && o.HasExit) is { } listed) { p.HasExit = true; p.ExitNS = listed.ExitNS; p.ExitEW = listed.ExitEW; }
            if (p.MinLevel == 0 && p.MaxLevel == 0 && Places.FirstOrDefault(Twin) is { } lv) { p.MinLevel = lv.MinLevel; p.MaxLevel = lv.MaxLevel; }
            Places.RemoveAll(Twin);
            Places.Add(p);
        }
        foreach (XmlElement e in root.SelectNodes("boundary")!)
        {
            var parts = new List<(double, double)[]>();
            foreach (var ring in e.GetAttribute("pts").Split('|'))
            {
                var pts = new List<(double, double)>();
                foreach (var pt in ring.Split(';')) if (Pair(pt, out double a, out double b)) pts.Add((a, b));
                if (pts.Count > 1) parts.Add(pts.ToArray());
            }
            Boundaries[e.GetAttribute("k")] = parts;
        }
        foreach (XmlElement e in root.SelectNodes("vname")!)
        {
            string k = e.GetAttribute("k");
            if (k.Length >= 4 && int.TryParse(k[..4], NumberStyles.HexNumber, CI, out int lb)) DungeonNames[lb] = e.GetAttribute("n");
        }
        foreach (XmlElement e in root.SelectNodes("random")!) Random.Add(e.GetAttribute("k"));
        foreach (XmlElement e in root.SelectNodes("avoid")!) Avoid.Add(e.GetAttribute("k"));
        _travelPoints.Clear();
        foreach (XmlElement e in root.SelectNodes("point")!)
            if (Pair(e.GetAttribute("c"), out double ns, out double ew))
                _travelPoints.Add(new Place { Name = e.GetAttribute("n"), Type = e.GetAttribute("ty"), NS = ns, EW = ew, Mine = true, Layer = "My points", Notes = e.GetAttribute("no"), In = e.GetAttribute("in") });
    }

    private readonly List<Place> _travelPoints = new();

    /// <summary>The list's portal entries that stand where it also has the dungeon they lead into (the one place, twice on
    /// the map): marked, so only the dungeon's is drawn while dungeons are shown. Kept - routes go by the portal's.</summary>
    public void MarkTwins()
    {
        var dungeons = Places.Where(p => !p.Mine && p.Type == "Dungeon").ToList();
        foreach (var p in Places)
        {
            if (p.Mine || p.Type != "Portal") continue;
            p.Twin = dungeons.Any(d => d.In == p.In && Math.Abs(d.NS - p.NS) < 0.1 && Math.Abs(d.EW - p.EW) < 0.1 && Same(d.Name, p.Name));
        }
    }

    private static bool Same(string a, string b)
    {
        a = a.Replace(" Portal", "").Trim(); b = b.Replace(" Portal", "").Trim();
        return a.Equals(b, StringComparison.OrdinalIgnoreCase) || a.Contains(b, StringComparison.OrdinalIgnoreCase) || b.Contains(a, StringComparison.OrdinalIgnoreCase);
    }

    // ── your own points and portal flags (user://map.cfg; MelksQB's points the first time) ──

    private void LoadUser()
    {
        var cfg = new ConfigFile();
        if (global::ACGodot.SafeConfig.Load(cfg, UserPath) != Error.Ok)
        {
            Places.AddRange(_travelPoints);
            SaveUser();
            return;
        }
        foreach (var line in ((string)cfg.GetValue("map", "points", "")).Split('\n', StringSplitOptions.RemoveEmptyEntries))
        {
            var f = line.Split('\t');
            if (f.Length < 4 || !double.TryParse(f[2], NumberStyles.Float, CI, out double ns) || !double.TryParse(f[3], NumberStyles.Float, CI, out double ew)) continue;
            var pl = new Place { Name = f[0], Type = f[1], NS = ns, EW = ew, Mine = true, Layer = "My points", Notes = f.Length > 4 ? f[4] : "", In = f.Length > 5 ? f[5] : "" };
            if (f.Length > 6 && double.TryParse(f[6], NumberStyles.Float, CI, out double z)) pl.Z = z;
            Places.Add(pl);
        }
        Random.UnionWith(((string)cfg.GetValue("map", "random", "")).Split('\n', StringSplitOptions.RemoveEmptyEntries));
        Avoid.UnionWith(((string)cfg.GetValue("map", "avoid", "")).Split('\n', StringSplitOptions.RemoveEmptyEntries));
    }

    public void SaveUser()
    {
        var cfg = new ConfigFile();
        global::ACGodot.SafeConfig.Load(cfg, UserPath);
        cfg.SetValue("map", "points", string.Join("\n", Places.Where(p => p.Mine).Select(p =>
            $"{p.Name.Replace('\t', ' ')}\t{p.Type}\t{p.NS.ToString(CI)}\t{p.EW.ToString(CI)}\t{p.Notes.Replace('\t', ' ').Replace('\n', ' ')}\t{p.In}" +
            (double.IsNaN(p.Z) ? "" : "\t" + p.Z.ToString(CI)))));
        cfg.SetValue("map", "random", string.Join("\n", Random));
        cfg.SetValue("map", "avoid", string.Join("\n", Avoid));
        global::ACGodot.SafeConfig.Save(cfg, UserPath);
    }

    /// <summary>A dungeon's landblock for a place, if it's known: a learned portal standing in it, or the name.</summary>
    public int DungeonOf(Place p)
    {
        if (p.Cell != 0 && (p.Cell & 0xFFFF) >= 0x100) return (int)(p.Cell >> 16);
        foreach (var kv in DungeonNames) if (kv.Value.Equals(p.Name, StringComparison.OrdinalIgnoreCase)) return kv.Key;
        // a portal into a dungeon: where it goes is learned - the dungeon of the portals standing at its exit
        if (p.HasExit)
            foreach (var o in Places)
                if (o.Cell != 0 && (o.Cell & 0xFFFF) >= 0x100 && Math.Abs(o.NS - p.ExitNS) < 2 && Math.Abs(o.EW - p.ExitEW) < 2) return (int)(o.Cell >> 16);
        return -1;
    }

    public string DungeonName(int lb) => DungeonNames.TryGetValue(lb, out var n) ? n : $"dungeon 0x{lb:X4}";

    /// <summary>Whether a spot is inside a copy's boundary (the tier 11+ area).</summary>
    public bool Inside(string group, double ns, double ew)
    {
        if (!Boundaries.TryGetValue(group, out var parts)) return false;
        var ring = parts.SelectMany(x => x).ToList();
        if (ring.Count < 2) return false;
        // (a line walked along the area's southern edge, from water to water - not a ring: the area is everything north
        // of it between its two ends, up to the sea. Closed for the test by carrying each end straight up to the map's top;
        // joined end to end as it stood, it made a sliver along the line and most of the area counted as outside)
        var (firstNs, firstEw) = ring[0]; var (lastNs, lastEw) = ring[^1];
        if (Math.Abs(firstNs - lastNs) + Math.Abs(firstEw - lastEw) > 0.3)
        {
            ring.Add((102.0, lastEw));
            ring.Add((102.0, firstEw));
        }
        bool inside = false;
        for (int i = 0, j = ring.Count - 1; i < ring.Count; j = i++)
        {
            var (ai, bi) = ring[i]; var (aj, bj) = ring[j];
            if ((ai > ns) != (aj > ns) && ew < (bj - bi) * (ns - ai) / (aj - ai) + bi) inside = !inside;
        }
        return inside;
    }
}
