using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using ACGodot.UI;
using Godot;

namespace ACGodot.Map;

/// <summary>A spot on the map, as the right-click menu acts on it: where, the ground's height there, the place (if one), the dungeon (if one).</summary>
public sealed record MapSpot(double NS, double EW, double Z, Place? Place, int Dungeon)
{
    public string Coords => $"{Math.Abs(NS).ToString("0.0#", CultureInfo.InvariantCulture)}{(NS >= 0 ? "N" : "S")}, {Math.Abs(EW).ToString("0.0#", CultureInfo.InvariantCulture)}{(EW >= 0 ? "E" : "W")}";
}

/// <summary>An item on the map's right-click menu (built in, or from a plugin).</summary>
public sealed record MapMenuItem(string Label, Action<MapSpot> Run, Func<MapSpot, bool>? Show);

/// <summary>
/// The world map (M): MelksQB's travel map as part of the game - the ground from the game's files with the towns,
/// portals, dungeons, NPCs, vendors, lifestones and landmarks, the portals learned in the game and your own points; you,
/// the arrow's target and the nav route. Views: the world, Tou-Tou's tier 11+ area (its copies' own portals and
/// places, inside its boundary) and dungeon layouts (the one you're in, or one picked from the map), by level.
/// Drag to move, wheel to zoom, double-click a place to point the arrow at it, right-click for everything else
/// (plugins add their own items there).
/// </summary>
public partial class MapWindow : PanelContainer
{
    public MapData Data = null!;

    /// <summary>The map's places read again (MelksQB has learned a portal): shown as they are now.</summary>
    public void Reload(MapData d) { Data = d; try { _canvas?.QueueRedraw(); } catch { } }
    public Dats Dats = null!;
    public Creatures.Player Player = null!;
    public NavArrow? Arrow;
    /// <summary>Where "point the arrow here" goes (the quest tracker's travel window when it's there); null: the arrow itself.</summary>
    public Action<double, double, string>? PointAt;
    /// <summary>Points at a spot: through PointAt when set, else the arrow.</summary>
    public void PointTo(double ns, double ew, string name) { if (PointAt != null) PointAt(ns, ew, name); else Arrow?.Point(ns, ew, name); }
    /// <summary>A plugin's travel target (MelksQB's destination), drawn as a marked spot with its name.</summary>
    public (double ns, double ew, string name)? Mark;
    /// <summary>MelkTank's "Map route" (the points it publishes as "ns,ew,z;..." in AppDomain data "MelkTank.MapRoute").</summary>
    public List<(double ns, double ew, double z)> RoutePoints()
    {
        string v = "";
        try { v = AppDomain.CurrentDomain.GetData("MelkTank.MapRoute") as string ?? ""; } catch { }
        if (v == _routeRaw) return _route;
        _routeRaw = v;
        var l = new List<(double, double, double)>();
        var ci = System.Globalization.CultureInfo.InvariantCulture;
        foreach (var part in v.Split(';', StringSplitOptions.RemoveEmptyEntries))
        {
            var f = part.Split(',');
            if (f.Length < 2 || !double.TryParse(f[0], System.Globalization.NumberStyles.Float, ci, out double ns) || !double.TryParse(f[1], System.Globalization.NumberStyles.Float, ci, out double ew)) continue;
            double z = 0; if (f.Length > 2) double.TryParse(f[2], System.Globalization.NumberStyles.Float, ci, out z);
            l.Add((ns, ew, z));
        }
        return _route = l;
    }
    private string _routeRaw = "";
    private List<(double ns, double ew, double z)> _route = new();
    /// <summary>A plugin's set of points for a dungeon (in = "d:01D9", tag = whose they are, e.g. "from ACMaps"): replaces the
    /// set it sent before; shown on the dungeon's layout, kept with your points.</summary>
    public void SetPoints(string inMap, string tag, IReadOnlyList<(string name, string type, double ns, double ew, double z)> pts)
    {
        Data.Places.RemoveAll(p => p.Mine && p.In == inMap && p.Notes == tag);
        foreach (var (name, type, ns, ew, z) in pts)
            Data.Places.Add(new Place { Name = name, Type = type, NS = ns, EW = ew, Z = z, Mine = true, Layer = "My points", In = inMap, Notes = tag });
        Data.SaveUser();
        _canvas.QueueRedraw();
    }

    private bool HasMelkTank => Plugins?.Plugins.Any(p => p.Name == "MelkTank") == true;
    private void Cmd(string c) => Plugins?.OfferCommand(c);
    public Plugins.PluginHost? Plugins;
    public Func<Vector3, float?>? Ground;
    public Action<string, Color>? Say;
    public Func<uint>? PlayerCell;
    /// <summary>The creatures and people near you (where they stand, their name, 2 a monster / 1 an NPC), for the map.</summary>
    public Func<IEnumerable<(Vector3 feet, string name, Color color, bool selected)>>? Nearby;

    private MapCanvas _canvas = null!;
    private LineEdit _search = null!;
    private ItemList _results = null!;
    private CheckBox _follow = null!;
    private OptionButton _view = null!, _level = null!;
    private MenuButton _layers = null!;
    private HSlider _alpha = null!;
    private Label _status = null!;
    private Vector2? _at, _size;
    private const string SavePath = "user://ui.cfg";

    public void Setup()
    {
        if (RetailTheme.Current is { } th) Theme = th;
        MouseFilter = MouseFilterEnum.Stop;
        Load();
        var v = new VBoxContainer();
        v.AddThemeConstantOverride("separation", 3);
        AddChild(v);
        // title strip
        var strip = new PanelContainer { MouseFilter = MouseFilterEnum.Stop };
        strip.AddThemeStyleboxOverride("panel", new StyleBoxFlat { BgColor = new Color(0.08f, 0.06f, 0.03f, 0.95f), BorderColor = new Color(0.62f, 0.47f, 0.22f),
                                                                   BorderWidthLeft = 1, BorderWidthRight = 1, BorderWidthTop = 1, BorderWidthBottom = 1, ContentMarginLeft = 4 });
        var bar = new HBoxContainer();
        strip.AddChild(bar);
        // the arrow: shuts it down to its title strip, or opens it again
        _fold = new Button { Text = "▼", Flat = true, FocusMode = FocusModeEnum.None, TooltipText = "Collapse / expand" };
        _fold.AddThemeColorOverride("font_color", RetailTheme.Gold);
        _fold.Pressed += () => SetCollapsed(!_collapsed);
        bar.AddChild(_fold);
        var title = new Label { Text = "World Map", SizeFlagsHorizontal = SizeFlags.ExpandFill, HorizontalAlignment = HorizontalAlignment.Center, MouseFilter = MouseFilterEnum.Stop };
        title.AddThemeColorOverride("font_color", RetailTheme.Gold);
        bar.AddChild(title);
        var close = new Button { Text = "X", Flat = true, FocusMode = FocusModeEnum.None };
        close.Pressed += () => Visible = false;
        bar.AddChild(close);
        v.AddChild(strip);
        bool down = false; Vector2 grab = Vector2.Zero;
        title.GuiInput += e =>
        {
            if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb) { down = mb.Pressed; grab = GetGlobalMousePosition() - Position; if (!mb.Pressed) { _at = Position; Save(); } }
            else if (e is InputEventMouseMotion && down && !UiLock.Locked)
            {
                var p = GetGlobalMousePosition() - grab;
                var vp = GetViewportRect().Size;
                Position = new Vector2(Math.Clamp(p.X, 0, Math.Max(0, vp.X - Size.X)), Math.Clamp(p.Y, 0, Math.Max(0, vp.Y - Size.Y)));   // (stops at the screen's edges)
            }
        };
        // toolbar
        var tools = new HBoxContainer();
        tools.AddThemeConstantOverride("separation", 4);
        _search = new LineEdit { PlaceholderText = "find a place...", CustomMinimumSize = new Vector2(150, 0) };
        _search.TextChanged += _ => Search();
        tools.AddChild(_search);
        _follow = new CheckBox { Text = "Follow me", ButtonPressed = true, FocusMode = FocusModeEnum.None };
        tools.AddChild(_follow);
        Readable(_follow);
        // ticked by hand: to the map you're on now - into the dungeon you went into while it was off, back out to the land
        _follow.Toggled += on => { if (on) { RefreshViews(); FollowHere(); _followedAt = null; } };
        var minus = Btn("−", () => _canvas.Zoom(1 / 1.4f)); var plus = Btn("+", () => _canvas.Zoom(1.4f));
        foreach (var zb in new[] { minus, plus }) { zb.CustomMinimumSize = new Vector2(34, 30); zb.AddThemeFontSizeOverride("font_size", 22); }
        minus.TooltipText = "Zoom out"; plus.TooltipText = "Zoom in";
        tools.AddChild(minus);
        tools.AddChild(plus);
        // the crosshair: in on yourself, 50 m showing each way (and following you again)
        // (the crosshair: to you - on the map you're on, whichever it was showing: the world's, a tier copy's, a dungeon's)
        var me = Btn("", () => { _follow.ButtonPressed = true; RefreshViews(); FollowHere(); if (Player.Active) _canvas.CenterOn(PlayerMap); _canvas.ShowAround(50f); });
        me.CustomMinimumSize = new Vector2(34, 30); me.TooltipText = "Zoom in on your character (50 m around)";
        me.Draw += () =>
        {
            var c = me.Size / 2; var col = new Color(1f, 0.92f, 0.6f);
            me.DrawArc(c, 7, 0, Mathf.Tau, 24, col, 1.5f, true);
            foreach (var d in new[] { Vector2.Up, Vector2.Down, Vector2.Left, Vector2.Right }) me.DrawLine(c + d * 4, c + d * 11, col, 1.5f, true);
            me.DrawCircle(c, 1.3f, col);
        };
        tools.AddChild(me);
        tools.AddChild(Btn("World", () => { _follow.ButtonPressed = false; _canvas.ShowWorld(); }));
        _layers = new MenuButton { Text = "Layers", Flat = false, FocusMode = FocusModeEnum.None };
        var lp = _layers.GetPopup();
        for (int i = 0; i < MapData.Layers.Length; i++) { lp.AddCheckItem(MapData.Layers[i], i); lp.SetItemChecked(i, _canvas_LayerOn(MapData.Layers[i])); }
        // what's seen as you go, put on the map if it isn't there (the world's and each dungeon's)
        lp.AddSeparator();
        lp.AddCheckItem("Auto-add portals", 100); lp.SetItemChecked(lp.GetItemIndex(100), _autoPortals);
        lp.AddCheckItem("Auto-add NPCs", 101); lp.SetItemChecked(lp.GetItemIndex(101), _autoNpcs);
        lp.HideOnCheckableItemSelection = false;
        lp.IdPressed += id =>
        {
            if (id >= 100)
            {
                int at = lp.GetItemIndex((int)id);
                bool now = !lp.IsItemChecked(at);
                lp.SetItemChecked(at, now);
                if (id == 100) _autoPortals = now; else _autoNpcs = now;
                Save();
                return;
            }
            int i = (int)id;
            bool on = !lp.IsItemChecked(i);
            lp.SetItemChecked(i, on);
            SetLayer(MapData.Layers[i], on);
            _canvas.QueueRedraw();
        };
        Readable(_layers); ReadableMenu(lp);
        tools.AddChild(_layers);
        _view = new OptionButton { FocusMode = FocusModeEnum.None };
        _view.ItemSelected += _ => ViewChanged();
        Readable(_view); ReadableMenu(_view.GetPopup());
        tools.AddChild(_view);
        _level = new OptionButton { FocusMode = FocusModeEnum.None, Visible = false, TooltipText = "The dungeon's level shown" };
        // a level picked by hand: looking elsewhere, so Follow me goes off (it would move the view back)
        _level.ItemSelected += i => { _canvas.Level = LevelAt((int)i); _follow.ButtonPressed = false; _canvas.QueueRedraw(); };
        Readable(_level); ReadableMenu(_level.GetPopup());
        tools.AddChild(_level);
        _alpha = new HSlider { MinValue = 15, MaxValue = 100, Value = _opacity * 100, CustomMinimumSize = new Vector2(70, 0), TooltipText = "Opacity", SizeFlagsVertical = SizeFlags.ShrinkCenter };
        _alpha.ValueChanged += x => { _opacity = (float)x / 100f; Modulate = new Color(1, 1, 1, _opacity); Save(); };
        tools.AddChild(_alpha);
        v.AddChild(tools);
        _results = new ItemList { Visible = false, CustomMinimumSize = new Vector2(0, 90), SelectMode = ItemList.SelectModeEnum.Single };
        _results.ItemActivated += i => PickResult((int)i);
        _results.ItemSelected += i => PickResult((int)i);
        v.AddChild(_results);
        _canvas = new MapCanvas { Owner_ = this, SizeFlagsVertical = SizeFlags.ExpandFill, SizeFlagsHorizontal = SizeFlags.ExpandFill, ClipContents = true, MouseFilter = MouseFilterEnum.Stop };
        v.AddChild(_canvas);
        var foot = new HBoxContainer();
        _status = new Label { Text = "", SizeFlagsHorizontal = SizeFlags.ExpandFill, ClipText = true };
        _status.AddThemeColorOverride("font_color", RetailTheme.Dim);
        foot.AddChild(_status);
        // the corner grip: resizes it
        var grip = new Label { Text = "◢", MouseFilter = MouseFilterEnum.Stop, MouseDefaultCursorShape = CursorShape.Fdiagsize };
        bool sizing = false; Vector2 from = Vector2.Zero, start = Vector2.Zero;
        grip.GuiInput += e =>
        {
            if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb) { sizing = mb.Pressed; from = GetGlobalMousePosition(); start = Size; if (!mb.Pressed) { _size = Size; Save(); } }
            else if (e is InputEventMouseMotion && sizing) { CustomMinimumSize = (start + GetGlobalMousePosition() - from).Max(new Vector2(420, 320)); Size = CustomMinimumSize; }
        };
        foot.AddChild(grip);
        v.AddChild(foot);
        _folded = new Control[] { tools, _results, _canvas, foot };
        CustomMinimumSize = _size ?? new Vector2(640, 560);
        Size = CustomMinimumSize;
        Modulate = new Color(1, 1, 1, _opacity);
        Visible = false;
        RefreshViews();
        if (TextScale != 1f) ApplyTextScale(false);
        if (_collapsed) { _collapsed = false; SetCollapsed(true); }
        // open again if it was open when you last left (collapsed or not, where it was)
        var oc = new ConfigFile();
        if (oc.Load(SavePath) == Error.Ok && (bool)oc.GetValue("map", "open", false)) Callable.From(() => { Open(); if (_collapsed) { _collapsed = false; SetCollapsed(true); } }).CallDeferred();
        _ready = true;
    }

    private bool _ready;

    /// <summary>The map's text size (Map panel): the words on the map, its buttons and lines at the top, the coordinates at the bottom.</summary>
    public static float TextScale = 1f;
    /// <summary>The right-click menu's text size (Map panel).</summary>
    public static float MenuScale = 1f;

    private static void MenuSize(PopupMenu m)
    {
        int baseFs = m.GetThemeFontSize("font_size");
        int fs = Math.Max(6, (int)MathF.Round(baseFs * MenuScale));
        m.AddThemeFontSizeOverride("font_size", fs);
        m.AddThemeFontSizeOverride("font_separator_size", fs);
    }

    public static void SaveMenuScale() { var cfg = new ConfigFile(); global::ACGodot.SafeConfig.Load(cfg, SavePath); cfg.SetValue("map", "menu_scale", (double)MenuScale); global::ACGodot.SafeConfig.Save(cfg, SavePath); }

    /// <summary>Puts the text size on the map's own buttons and lines (the canvas draws its words at it itself) and keeps it.</summary>
    public void ApplyTextScale(bool save = true)
    {
        void Walk(Node n)
        {
            foreach (var ch in n.GetChildren())
            {
                if (ch is Control c && c != _canvas && (c is Label || c is BaseButton || c is LineEdit || c is ItemList))
                {
                    int baseFs = c.HasMeta("base_fs") ? (int)c.GetMeta("base_fs") : c.GetThemeFontSize("font_size");
                    if (!c.HasMeta("base_fs")) c.SetMeta("base_fs", baseFs);
                    c.AddThemeFontSizeOverride("font_size", Math.Max(6, (int)MathF.Round(baseFs * TextScale)));
                }
                if (ch != _canvas) Walk(ch);
            }
        }
        Walk(this);
        _canvas?.QueueRedraw();
        if (save) { var cfg = new ConfigFile(); global::ACGodot.SafeConfig.Load(cfg, SavePath); cfg.SetValue("map", "text_scale", (double)TextScale); global::ACGodot.SafeConfig.Save(cfg, SavePath); }
    }

    // open or shut: remembered for next time
    public override void _Notification(int what)
    {
        if (what != NotificationVisibilityChanged || !_ready) return;
        var c = new ConfigFile(); global::ACGodot.SafeConfig.Load(c, SavePath); c.SetValue("map", "open", Visible); global::ACGodot.SafeConfig.Save(c, SavePath);
    }

    // ── collapsed to its title strip ──
    private Button? _fold;
    private Control[] _folded = Array.Empty<Control>();
    private bool _collapsed;

    private void SetCollapsed(bool on)
    {
        if (on == _collapsed) return;
        _collapsed = on;
        if (_fold != null) _fold.Text = on ? "▶" : "▼";
        foreach (var c in _folded) c.Visible = !on && (c != _results || _results.ItemCount > 0 && _search.Text.Length > 0);
        if (on) { CustomMinimumSize = new Vector2(Size.X, 0); Size = new Vector2(Size.X, 0); }
        else
        {
            CustomMinimumSize = _size ?? new Vector2(640, 560); Size = CustomMinimumSize;
            // once its parts are laid out again (next frame), the size and the view once more: drawn before that, the
            // canvas had no size yet and stayed black
            Callable.From(() => { Size = CustomMinimumSize; ViewChanged(false); _canvas.QueueRedraw(); }).CallDeferred();
        }
        var cfg = new ConfigFile(); global::ACGodot.SafeConfig.Load(cfg, SavePath); cfg.SetValue("map", "collapsed", on); global::ACGodot.SafeConfig.Save(cfg, SavePath);
    }

    private static Button Btn(string text, Action a) { var b = new Button { Text = text, FocusMode = FocusModeEnum.None }; b.Pressed += a; Readable(b); return b; }

    // the toolbar's buttons and drop-downs, easy to read: light words on dark, a gold edge (brighter under the mouse)
    private static StyleBoxFlat Plate(Color fill, Color edge) => new()
    {
        BgColor = fill, BorderColor = edge, BorderWidthLeft = 1, BorderWidthRight = 1, BorderWidthTop = 1, BorderWidthBottom = 1,
        ContentMarginLeft = 8, ContentMarginRight = 8, ContentMarginTop = 3, ContentMarginBottom = 3,
        CornerRadiusTopLeft = 2, CornerRadiusTopRight = 2, CornerRadiusBottomLeft = 2, CornerRadiusBottomRight = 2,
    };
    private static void ReadableMenu(PopupMenu c)
    {
        var words = new Color(0.96f, 0.93f, 0.82f); var edge = new Color(0.62f, 0.47f, 0.22f);
        c.AddThemeStyleboxOverride("panel", Plate(new Color(0.10f, 0.09f, 0.07f, 0.97f), edge));
        c.AddThemeStyleboxOverride("hover", Plate(new Color(0.30f, 0.24f, 0.12f), edge));
        foreach (var k in new[] { "font_color", "font_accelerator_color" }) c.AddThemeColorOverride(k, words);
        c.AddThemeColorOverride("font_hover_color", Colors.White);
        c.AddThemeColorOverride("font_disabled_color", new Color(0.6f, 0.58f, 0.5f));
    }
    private static void Readable(Control c)
    {
        var words = new Color(0.96f, 0.93f, 0.82f); var lit = new Color(1f, 0.95f, 0.65f);
        var dark = new Color(0.10f, 0.09f, 0.07f, 0.97f); var edge = new Color(0.62f, 0.47f, 0.22f);
        if (c is not CheckBox)
        {
            c.AddThemeStyleboxOverride("normal", Plate(dark, edge));
            c.AddThemeStyleboxOverride("hover", Plate(new Color(0.20f, 0.17f, 0.10f, 0.98f), lit));
            c.AddThemeStyleboxOverride("pressed", Plate(new Color(0.30f, 0.24f, 0.12f), lit));
            c.AddThemeStyleboxOverride("focus", new StyleBoxEmpty());
        }
        foreach (var k in new[] { "font_color", "font_focus_color" }) c.AddThemeColorOverride(k, words);
        foreach (var k in new[] { "font_hover_color", "font_pressed_color", "font_hover_pressed_color" }) c.AddThemeColorOverride(k, lit);
    }

    // ── layers (which kinds of place show) ──
    private readonly HashSet<string> _hidden = new();
    private float _opacity = 0.95f;
    private bool _canvas_LayerOn(string l) => !_hidden.Contains(l);
    public bool LayerOn(string l) => !_hidden.Contains(l);
    private void SetLayer(string l, bool on) { if (on) _hidden.Remove(l); else _hidden.Add(l); Save(); }

    // ── views: the world, the tier 11+ area, dungeons ──
    private int _shownDungeon = -1;
    public string View => _view.Selected >= 0 ? (string)_view.GetItemMetadata(_view.Selected) : "";
    public int ViewDungeon => View.StartsWith("d:") && View.Length >= 6 ? Convert.ToInt32(View.Substring(2, 4), 16) : -1;

    // ── a dungeon's versions (a server's copies of it, told apart by what /location answers: "v:2"): each its own map ──
    private string _hereVer = "";
    private bool _verKnown;
    private int _verLb = -2;
    private double _verSaidAt = -100, _verSince;
    /// <summary>The map you're standing on: "" the world, "d:01D9" a dungeon, "d:01D9v2" its version 2.</summary>
    public string HereIn => CurrentDungeon is int h && h >= 0 ? $"d:{h:X4}{_hereVer}" : InTier ? "tier11+" : "";
    // outdoors in one of the server's tier 11+ copies of the land (what /location answers there: "v:11", "v:12"...): its
    // own map, not the world's - the people and portals seen there were being put on the world's
    private int _outTier;
    private string _lastHereIn = "";
    private double _outSince = -100;   // when you last came to be somewhere else (out of a dungeon, through a portal)
    private bool InTier
    {
        get
        {
            int tier = _outTier;
            // (or as MelkTank last heard it - it asks /location after every portal, and keeps the answer where others can read it)
            if (tier == 0)
                try
                {
                    if (AppDomain.CurrentDomain.GetData("MelkTank.Variation") is string v && v.Split('|') is { Length: 2 } p && int.TryParse(p[0], out int n)
                        && long.TryParse(p[1], out long ticks) && new DateTime(ticks, DateTimeKind.Utc) > DateTime.UtcNow.AddSeconds(-(Time.GetTicksMsec() / 1000.0 - _outSince) - 5)) tier = n;
                }
                catch { }
            // (wherever in it you stand: the boundary drawn for the area is only as much of it as has been walked - gone
            // by, you were "outside" it most of the time and the map stayed the world's)
            return tier >= 11 && Player != null && Player.Active && CurrentDungeon < 0;
        }
    }
    private static readonly System.Text.RegularExpressions.Regex LocVer = new(@"\bv:\s*(\d+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);

    /// <summary>A line of chat: the server's answer to /location says which version of a dungeon this is.</summary>
    public void Heard(string line)
    {
        if (!line.StartsWith("Your location is:", StringComparison.OrdinalIgnoreCase)) return;
        var m = LocVer.Match(line);
        int n = m.Success && int.TryParse(m.Groups[1].Value, out int v) ? v : 0;
        string ver = n > 0 && CurrentDungeon >= 0 ? "v" + n : "";
        _verSaidAt = Time.GetTicksMsec() / 1000.0;
        string wasIn = HereIn;
        if (CurrentDungeon < 0) _outTier = n;
        bool changed = ver != _hereVer || HereIn != wasIn;
        _hereVer = ver; _verKnown = true;
        if (changed && _view != null) { RefreshViews(); FollowHere(); }
    }

    private void TrackVersion()
    {
        int here = CurrentDungeon;
        if (here == _verLb) return;
        _verLb = here;
        double now = Time.GetTicksMsec() / 1000.0;
        _verSince = now;
        // (an answer just heard is this place's: it can come a moment before the place is seen to change)
        if (now - _verSaidAt > 3.0) { _hereVer = ""; _verKnown = false; _outTier = 0; }
        _outSince = now;
        if (here < 0) { _hereVer = ""; _verKnown = true; }
    }

    private void FollowHere()
    {
        if (!_follow.ButtonPressed) return;
        string want = HereIn;
        for (int i = 0; i < _view.ItemCount; i++) if ((string)_view.GetItemMetadata(i) == want) { if (_view.Selected != i) { _view.Select(i); ViewChanged(false); } break; }
    }

    // a dungeon in the list of views: the one asked for, and each other version of it that has points of its own
    private void AddDungeonViews(Action<string, string> add, int lb, string first, string label)
    {
        string plain = $"d:{lb:X4}";
        add(label + (first.Length > plain.Length ? " " + first[plain.Length..] : ""), first);
        foreach (var other in Data.Places.Select(p => p.In).Where(i => i.StartsWith(plain) && i != first).Distinct().OrderBy(i => i).ToList())
            add($"{Data.DungeonName(lb)} {(other.Length > plain.Length ? other[plain.Length..] : "(plain)")}", other);
    }

    private void RefreshViews()
    {
        string keep = View;
        _view.Clear();
        void Add(string text, string meta) { _view.AddItem(text); _view.SetItemMetadata(_view.ItemCount - 1, meta); }
        Add("The world", "");
        if (Data.Boundaries.ContainsKey("tier11+") || Data.Places.Any(p => p.In == "tier11+") || InTier) Add("Tou-Tou Tier 11+", "tier11+");
        int here = CurrentDungeon;
        if (here >= 0) AddDungeonViews(Add, here, HereIn, $"Here: {Data.DungeonName(here)}");
        if (_shownDungeon >= 0 && _shownDungeon != here) AddDungeonViews(Add, _shownDungeon, $"d:{_shownDungeon:X4}", Data.DungeonName(_shownDungeon));
        for (int i = 0; i < _view.ItemCount; i++) if ((string)_view.GetItemMetadata(i) == keep) { _view.Select(i); break; }
        ViewChanged(false);
    }

    private int _lastDungeonSeen = -2;
    private float _worldZoom;

    /// <summary>The dungeon you're in (its landblock), or -1.</summary>
    public int CurrentDungeon
    {
        get
        {
            uint c = PlayerCell?.Invoke() ?? 0;
            if ((c & 0xFFFF) < 0x100) return -1;
            int lb = (int)(c >> 16);
            var info = Dats.Cell<DatReaderWriter.DBObjs.LandBlockInfo>(((uint)lb << 16) | 0xFFFEu);
            if (info == null || info.NumCells == 0) return -1;
            if (info.Buildings.Count == 0) return lb;
            // a cave or a cellar maze under the landscape (a building's rooms, by the files): mapped like a dungeon when
            // there's enough of it joined together to get lost in - a cottage's few rooms aren't
            return JoinedRooms(c) >= 15 ? lb : -1;
        }
    }

    private readonly Dictionary<uint, int> _joined = new();
    /// <summary>How many rooms are joined (room to room) to this one, itself included.</summary>
    private int JoinedRooms(uint start)
    {
        if (_joined.TryGetValue(start, out int n)) return n;
        var seen = new HashSet<uint> { start };
        var todo = new Stack<uint>();
        todo.Push(start);
        uint hi = start & 0xFFFF0000u;
        try
        {
            while (todo.Count > 0)
            {
                var cell = Dats.Cell<DatReaderWriter.DBObjs.EnvCell>(todo.Pop());
                if (cell == null) continue;
                foreach (var portal in cell.CellPortals)
                    if (portal.OtherCellId != 0xFFFF && seen.Add(hi | portal.OtherCellId)) todo.Push(hi | portal.OtherCellId);
            }
        }
        catch { }
        foreach (uint id in seen) _joined[id] = seen.Count;
        return seen.Count;
    }

    private int _framedLb = -1;
    private int? _wantLevel;

    private void ViewChanged(bool move = true)
    {
        int d = ViewDungeon;
        _level.Visible = d >= 0;
        // into a dungeon's layout the map zooms right in on it; back at the world it's as far out as it was before (left
        // zoomed in on the few metres round you, the world looked as if it hadn't come back)
        bool wasDungeon = _canvas.Layout != null || _canvas.NoLayout;
        if (d >= 0 && !wasDungeon) _worldZoom = _canvas.ZoomLevel;
        else if (d < 0 && wasDungeon && _worldZoom > 0) { _canvas.ZoomLevel = _worldZoom; if (Player.Active) _canvas.CenterOn(PlayerMap); }
        // the same dungeon again (re-laid out, reopened): the level picked stays
        int keep = _canvas.Layout != null && _canvas.Layout.Landblock == d ? _canvas.Level : int.MinValue;
        if (_wantLevel is int wl) { keep = wl; _wantLevel = null; }
        // (a dungeon come to fresh that you're standing in - logged in there, or just walked in: the floor you're on, not all of them)
        if (keep == int.MinValue && d >= 0 && Player.Active && CurrentDungeon == d && (_canvas.Layout == null || _canvas.Layout.Landblock != d))
        {
            var (_, _, pz) = World.ToAc(Player.Position);
            keep = DungeonLayout.LevelOf(pz + 0.5f);
        }
        _canvas.Layout = d >= 0 ? DungeonLayout.Of(Dats, d) : null;
        _canvas.NoLayout = d >= 0 && _canvas.Layout == null;
        if (_canvas.Layout is { } lay)
        {
            _level.Clear();
            // (each item's level kept in its metadata: as an item's id, -1 means "number it yourself" - level -1 became its
            // place in the list, showed nothing, and couldn't be followed to)
            _level.AddItem("All levels"); _level.SetItemMetadata(0, int.MinValue);
            foreach (int l in lay.Levels.Reverse()) { _level.AddItem($"Level {lay.Label(l)}"); _level.SetItemMetadata(_level.ItemCount - 1, l); }
            int pick = 0;
            if (keep != int.MinValue && lay.Levels.Count > 0)
            {
                int best = lay.Levels.OrderBy(l => Math.Abs(l - keep)).First();   // that level, or the nearest it has
                for (int i = 0; i < _level.ItemCount; i++) if (LevelAt(i) == best) pick = i;
            }
            _level.Select(pick);
            _canvas.Level = LevelAt(pick);
            // a different dungeon from the one last framed: framed on it (left at the world's zoom it's a dot - black)
            if (move || lay.Landblock != _framedLb) { _canvas.Frame(lay.Min, lay.Max); _framedLb = lay.Landblock; }
        }
        else if (View == "tier11+" && move && Data.Boundaries.TryGetValue("tier11+", out var parts))
        {
            var pts = parts.SelectMany(x => x).ToList();
            _canvas.Frame(new System.Numerics.Vector2((float)pts.Min(p => p.ew), (float)pts.Min(p => p.ns)), new System.Numerics.Vector2((float)pts.Max(p => p.ew), (float)pts.Max(p => p.ns)));
        }
        if (move) _follow.ButtonPressed = false;
        // following you into another area (a dungeon, or back out): in on yourself as the crosshair does it - the area
        // framed whole, or the world's zoom kept, could leave you a speck in a blank map
        else if (_follow.ButtonPressed && Player.Active && d != _followedInto)
        {
            _canvas.CenterOn(PlayerMap);
            _canvas.ShowAround(50f);
        }
        // (not yet in the world - the map made before you are: nothing followed yet, so the first place you stand is zoomed in on)
        if (Player.Active || !_follow.ButtonPressed) _followedInto = d;
        _canvas.QueueRedraw();
    }
    private System.Numerics.Vector2? _followedAt;
    private int _followedInto = int.MinValue;

    /// <summary>Shows a dungeon's layout (from a place's menu, or /map dungeon 01D9).</summary>
    public void ShowDungeon(int lb)
    {
        // the dungeon you're standing in (a plugin shows it as you go in): that's the map following you, not a layout picked
        // by hand - Follow me stays as it was, and the map leaves with you
        if (lb == CurrentDungeon)
        {
            RefreshViews();
            for (int i = 0; i < _view.ItemCount; i++) if ((string)_view.GetItemMetadata(i) == HereIn) { if (_view.Selected != i) { _view.Select(i); ViewChanged(false); } break; }
            Open();
            return;
        }
        _shownDungeon = lb;
        SetCollapsed(false);
        RefreshViews();
        // opened on a dungeon (from ACMaps, a place's menu): its level 0, not all of them at once
        for (int i = 0; i < _view.ItemCount; i++) if ((string)_view.GetItemMetadata(i) == $"d:{lb:X4}") { _view.Select(i); _wantLevel = 0; ViewChanged(); break; }
        Open();
    }

    public void Open()
    {
        Visible = true;
        Position = _at ?? new Vector2(80, 60);
        RefreshViews();
        if (_image == null) LoadImage();
    }

    /// <summary>
    /// M: not on the screen - it opens (as it was left: collapsed, if it was). On the screen: with "M collapses the map" (Options) it collapses / expands;
    /// without, a collapsed one opens up and an open one closes.
    /// </summary>
    public void Toggle()
    {
        // (not on the screen: it comes back as it was left - collapsed if it was)
        if (!Visible) { Open(); return; }
        if (MKeyCollapses) SetCollapsed(!_collapsed);
        else if (_collapsed) SetCollapsed(false);
        else Visible = false;
    }

    /// <summary>Options: M collapses / expands the map once it's on the screen (instead of closing it).</summary>
    public static bool MKeyCollapses
    {
        get { var c = new ConfigFile(); return global::ACGodot.SafeConfig.Load(c, SavePath) == Error.Ok && (bool)c.GetValue("map", "m_collapses", false); }
        set { var c = new ConfigFile(); global::ACGodot.SafeConfig.Load(c, SavePath); c.SetValue("map", "m_collapses", value); global::ACGodot.SafeConfig.Save(c, SavePath); }
    }

    // ── the picture ──
    private ImageTexture? _image;
    private bool _imageAsked;
    public Terrain.TerrainTextures? Textures;
    public ImageTexture? Picture => _image;

    private void LoadImage()
    {
        if (_imageAsked || Textures == null) return;
        _imageAsked = true;
        _status.Text = "Drawing the world from the game's files (only the first time)...";
        WorldImage.Get(Dats, Textures, img =>
        {
            if (img != null) _image = ImageTexture.CreateFromImage(img);
            _status.Text = img != null ? "" : "Couldn't draw the world map.";
            _canvas.QueueRedraw();
        });
    }

    // ── portals and NPCs seen as you go: added to the map (the world's, or the dungeon's you're in) if they aren't on it ──
    private bool _autoPortals = true, _autoNpcs = true;
    /// <summary>The players seen since the game started (and you): what's named "theirs" is a pet of theirs, not someone who lives there.</summary>
    public static readonly HashSet<string> PlayersSeen = new(StringComparer.OrdinalIgnoreCase);
    /// <summary>A name like "Someone's Shade of Dule", where Someone is a player: a pet.</summary>
    public static bool PetName(string name)
    {
        int at = name.IndexOf("'s ", StringComparison.Ordinal);
        return at > 0 && PlayersSeen.Contains(name[..at]);
    }
    /// <summary>The portals and people in view: where they stand, their name, what (1 an NPC, 2 a vendor, 3 a portal), their cell.</summary>
    public Func<IEnumerable<(Vector3 feet, string name, int what, uint cell)>>? Fixtures;
    private double _autoIn;
    private readonly Dictionary<string, (Vector3 at, double since)> _stood = new();
    private readonly Dictionary<string, double> _gone = new();

    private void AutoAdd(double delta)
    {
        if ((_autoIn -= delta) > 0 || Fixtures == null || !Player.Active || (!_autoPortals && !_autoNpcs)) return;
        _autoIn = 2.0;
        if (!_tidied) { _tidied = true; Tidy(); }
        int here = CurrentDungeon;
        double now = Time.GetTicksMsec() / 1000.0;
        // (in a dungeon: once its version is known - or nothing has said, a while after coming in)
        if (here >= 0 && !_verKnown && now - _verSince < 8.0) return;
        // (outdoors, just arrived: once /location has said which copy of the land this is - or nothing has, a while after)
        if (here < 0 && _verSaidAt < _outSince && now - _outSince < 8.0) return;
        string inMap = HereIn;
        bool added = false;
        var portalsUp = new List<(double ns, double ew, string name)>();
        var fixtures = Fixtures().ToList();
        foreach (var (pf, pn, pw, _) in fixtures)
            if (pw == 3) { var (px, py, _) = World.ToAc(pf); portalsUp.Add((py / 240.0 - 101.95, px / 240.0 - 101.95, pn)); }
        // a portal that was put on the map as you went, and isn't standing there now (one someone opened for a while -
        // a portal bot's, a gem's): off the map again. Looked for from close by, a few seconds running (things come
        // into view a moment after you do)
        var (mx, my, mz) = World.ToAc(Player.Position);
        double mns = my / 240.0 - 101.95, mew = mx / 240.0 - 101.95;
        foreach (var o in Data.Places.Where(o => o.Mine && o.Notes == "seen" && o.Type == "Portal" && o.In == inMap).ToList())
        {
            string k = $"{o.Name}|{o.In}|{o.NS:0.000}|{o.EW:0.000}";
            bool close = Math.Abs(o.NS - mns) < 0.1 && Math.Abs(o.EW - mew) < 0.1 && (double.IsNaN(o.Z) || Math.Abs(o.Z - mz) < 4.0);   // (about 25 m, on your floor)
            bool up = portalsUp.Any(u => Math.Abs(u.ns - o.NS) < 0.03 && Math.Abs(u.ew - o.EW) < 0.03 && SameName(u.name, o.Name));
            if (!close || up) { _gone.Remove(k); continue; }
            if (!_gone.TryGetValue(k, out double since)) { _gone[k] = now; continue; }
            if (now - since < 6.0) continue;
            _gone.Remove(k);
            Data.Places.Remove(o);
            added = true;
        }
        // (a person put on over a mark that was already there for them: taken off again). Only after something was put
        // on (or the first time on this map): outdoors the world map holds thousands of points, and comparing every
        // seen person with all of them (IndexOf each time) every 2 s froze the game for ~175 ms.
        if (_dedupeFor != inMap || _dedupeWanted)
        {
            _dedupeFor = inMap; _dedupeWanted = false;
            var order = new Dictionary<Place, int>(ReferenceEqualityComparer.Instance);
            var grid = new Dictionary<(long, long), List<Place>>();
            for (int i = 0; i < Data.Places.Count; i++)
            {
                var x = Data.Places[i];
                order[x] = i;
                if (x.In != inMap || x.Type == "Portal") continue;
                var key = ((long)Math.Floor(x.NS / 0.3), (long)Math.Floor(x.EW / 0.3));
                if (!grid.TryGetValue(key, out var cell)) grid[key] = cell = new List<Place>();
                cell.Add(x);
            }
            var drop = new List<Place>();
            foreach (var o in Data.Places)
            {
                if (!o.Mine || o.Notes != "seen" || o.Type == "Portal" || o.In != inMap) continue;
                long gx = (long)Math.Floor(o.NS / 0.3), gy = (long)Math.Floor(o.EW / 0.3);
                bool dup = false;
                for (long dx = -1; dx <= 1 && !dup; dx++)
                    for (long dy = -1; dy <= 1 && !dup; dy++)
                    {
                        if (!grid.TryGetValue((gx + dx, gy + dy), out var cell)) continue;
                        foreach (var x in cell)
                        {
                            if (x == o || drop.Contains(x) || !(x.Notes != "seen" || order[x] < order[o])) continue;
                            double near = x.Mine || here >= 0 ? 0.1 : 0.3;
                            if (Math.Abs(x.NS - o.NS) < near && Math.Abs(x.EW - o.EW) < near && LikeName(x.Name, o.Name)) { dup = true; break; }
                        }
                    }
                if (dup) drop.Add(o);
            }
            foreach (var o in drop) Data.Places.Remove(o);
            if (drop.Count > 0) added = true;
        }
        // (pets put on before their owner was known for a player: taken off)
        if (Data.Places.RemoveAll(o => o.Mine && o.Notes == "seen" && o.Type != "Portal" && PetName(o.Name)) > 0) added = true;
        foreach (var (feet, name, what, cell) in fixtures)
        {
            if (name.Length == 0 || (what == 3 ? !_autoPortals : !_autoNpcs)) continue;
            if (feet.DistanceTo(Player.Position) > 60f) continue;
            // (in a dungeon: only what stands in it)
            if (here >= 0 && ((cell & 0xFFFF) < 0x100 || (int)(cell >> 16) != here)) continue;
            // people: only those who stay where they are (seen at the one spot a few seconds running)
            if (what != 3)
            {
                string k = name + "|" + inMap;
                if (!_stood.TryGetValue(k, out var st) || st.at.DistanceTo(feet) > 1f) { _stood[k] = (feet, now); continue; }
                if (now - st.since < 4.0) continue;
            }
            var (cx, cy, cz) = World.ToAc(feet);
            double ns = cy / 240.0 - 101.95, ew = cx / 240.0 - 101.95;
            string type = what == 3 ? "Portal" : what == 2 ? "Vendor" : "NPC";
            bool there = false;
            foreach (var o in Data.Places)
            {
                if (o.In != inMap) continue;
                // (the list's places are set down roughly; your own, where they stand; a person already marked in the
                // room - by a plugin's set of points, a little off - is that person). Near first: the name test is the slow part.
                double near = here >= 0 || o.Mine ? (what == 3 ? 0.03 : 0.1) : 0.3;
                if (Math.Abs(o.NS - ns) < near && Math.Abs(o.EW - ew) < near && LikeName(o.Name, name)) { there = true; break; }
            }
            if (there) continue;
            Data.Places.Add(new Place { Name = name, Type = type, NS = Math.Round(ns, 3), EW = Math.Round(ew, 3), Z = here >= 0 ? Math.Round(cz, 1) : double.NaN,
                                        Mine = true, Layer = "My points", In = inMap, Notes = "seen" });
            added = true;
        }
        if (added) { _dedupeWanted = true; Data.SaveUser(); _canvas.QueueRedraw(); }
    }
    private string? _dedupeFor;
    private bool _dedupeWanted;
    // once a run, over every map: your own points that are the same point twice (name, map and spot alike) down to one,
    // and a point put on as seen that stands on a mark already there for the same thing, off
    private bool _tidied;
    private void Tidy()
    {
        int before = Data.Places.Count;
        var kept = new HashSet<(string, string, long, long)>();
        foreach (var o in Data.Places.Where(p => p.Mine).OrderBy(p => p.Notes == "seen" ? 1 : 0).ToList())
            if (!kept.Add((o.In, o.Name.Trim().ToLowerInvariant(), (long)Math.Round(o.NS * 200), (long)Math.Round(o.EW * 200)))) Data.Places.Remove(o);
        foreach (var o in Data.Places.Where(o => o.Mine && o.Notes == "seen").ToList())
        {
            bool portal = o.Type == "Portal";
            if (Data.Places.Any(x => x != o && x.Notes != "seen" && x.In == o.In && (x.Type == "Portal") == portal && LikeName(x.Name, o.Name)
                                     && Math.Abs(x.NS - o.NS) < (portal ? 0.03 : x.Mine || o.In.Length > 0 ? 0.1 : 0.3) && Math.Abs(x.EW - o.EW) < (portal ? 0.03 : x.Mine || o.In.Length > 0 ? 0.1 : 0.3)))
                Data.Places.Remove(o);
        }
        // the same point more than once on a map (name alike, a few metres apart): MelksQB's points brought in the first
        // time held a person once for every time it was seen (twenty of a wandering creature), and the list's portals
        // over again. Your own points that aren't the first of their name there go - not ones you made yourself
        // ("Custom", or with notes of your own)
        var byName = new Dictionary<(string, string), List<Place>>();
        foreach (var x in Data.Places)
        {
            var key = (x.In, x.Name.Replace(" Portal", "").Trim().ToLowerInvariant());
            if (key.Item2.Length == 0) continue;
            if (!byName.TryGetValue(key, out var l)) byName[key] = l = new List<Place>();
            l.Add(x);
        }
        var gone = new HashSet<Place>(ReferenceEqualityComparer.Instance);
        foreach (var l in byName.Values)
        {
            if (l.Count < 2) continue;
            // (the list's first, then yours in the order they were put on)
            var ordered = l.OrderBy(x => x.Mine ? 1 : 0).ToList();
            for (int i = 0; i < ordered.Count; i++)
            {
                var o = ordered[i];
                if (!o.Mine || o.Type == "Custom" || !(o.Notes.Length == 0 || o.Notes == "seen")) continue;
                for (int j = 0; j < i; j++)
                {
                    var x = ordered[j];
                    if (gone.Contains(x)) continue;
                    double near = o.Type == "Portal" && x.Type == "Portal" ? 0.03 : 0.1;
                    if (Math.Abs(x.NS - o.NS) < near && Math.Abs(x.EW - o.EW) < near) { gone.Add(o); break; }
                }
            }
        }
        if (gone.Count > 0) { Data.Places.RemoveAll(gone.Contains); global::ACGodot.DebugLogs.Print($"[map] tidied {gone.Count} doubled points"); }
        if (Data.Places.Count != before) { Data.SaveUser(); _canvas.QueueRedraw(); }
    }

    /// <summary>For finding doubled points: your own points (or those named like the text), and what else of the same name stands near each.</summary>
    public IEnumerable<string> PointNotes(string like)
    {
        yield return $"{Data.Places.Count} places; {Data.Places.Count(p => p.Mine)} your own, {Data.Places.Count(p => p.Notes == "seen")} put on as seen; here is '{HereIn}'";
        // (what still shows twice on one map: the same name within a few metres, whatever kind of point each is)
        var twice = new List<string>();
        var byMap = Data.Places.GroupBy(p => p.In);
        foreach (var g in byMap)
        {
            var l = g.ToList();
            for (int i = 0; i < l.Count; i++)
                for (int j = i + 1; j < l.Count; j++)
                    if (Math.Abs(l[i].NS - l[j].NS) < 0.1 && Math.Abs(l[i].EW - l[j].EW) < 0.1 && l[i].Name.Trim().Equals(l[j].Name.Trim(), StringComparison.OrdinalIgnoreCase))
                        twice.Add($"  twice in '{g.Key}': {l[i].Name} [{l[i].Type}/{l[i].Layer}/mine {l[i].Mine}/'{l[i].Notes}'] and [{l[j].Type}/{l[j].Layer}/mine {l[j].Mine}/'{l[j].Notes}'] {Math.Max(Math.Abs(l[i].NS - l[j].NS), Math.Abs(l[i].EW - l[j].EW)):0.000} apart at {l[i].NS:0.00},{l[i].EW:0.00}");
        }
        yield return $"{twice.Count} pairs of the same name within 0.1 on one map";
        foreach (var t in twice.Take(like == "all" ? 400 : 40)) yield return t;
        if (like.Length == 0 || like == "all") yield break;
        int said = 0;
        foreach (var o in Data.Places.Where(p => like.Length > 0 ? p.Name.Contains(like, StringComparison.OrdinalIgnoreCase) : p.Notes == "seen"))
        {
            var twins = Data.Places.Where(x => x != o && LikeName(x.Name, o.Name) && Math.Abs(x.NS - o.NS) < 1.0 && Math.Abs(x.EW - o.EW) < 1.0).ToList();
            if (like.Length == 0 && twins.Count == 0) continue;
            if (said++ > 60) yield break;
            yield return $"  {o.Name} [{o.Type}] in '{o.In}' at {o.NS:0.000},{o.EW:0.000} layer {o.Layer} mine {o.Mine} notes '{o.Notes}'";
            foreach (var x in twins) yield return $"      near it: {x.Name} [{x.Type}] in '{x.In}' at {x.NS:0.000},{x.EW:0.000} layer {x.Layer} mine {x.Mine} notes '{x.Notes}' ({Math.Max(Math.Abs(x.NS - o.NS), Math.Abs(x.EW - o.EW)):0.000} off)";
        }
    }

    private static bool LikeName(string a, string b)
    {
        a = a.Replace(" Portal", "").Trim(); b = b.Replace(" Portal", "").Trim();
        return a.Length > 0 && b.Length > 0 && (a.Contains(b, StringComparison.OrdinalIgnoreCase) || b.Contains(a, StringComparison.OrdinalIgnoreCase));
    }
    private static bool SameName(string a, string b)
    {
        a = a.Replace(" Portal", "").Trim(); b = b.Replace(" Portal", "").Trim();
        return a.Equals(b, StringComparison.OrdinalIgnoreCase);
    }

    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("MapWindow");
        RecordTrail();
        TrackVersion();
        AutoAdd(delta);
        if (!Visible) return;
        // collapsed stays collapsed: whatever lays the window out again (coming into the world did) doesn't open it up
        if (_collapsed)
        {
            foreach (var c in _folded) if (c.Visible) c.Visible = false;
            if (CustomMinimumSize.Y > 0f) CustomMinimumSize = new Vector2(CustomMinimumSize.X, 0);
            if (Size.Y > GetCombinedMinimumSize().Y + 0.5f) Size = new Vector2(Size.X, 0);
        }
        int here = CurrentDungeon;
        if (here != _lastDungeonSeen)
        {
            int was = _lastDungeonSeen;
            _lastDungeonSeen = here;
            // out of the dungeon whose layout is showing: the map goes with you, whether it was following or the layout was
            // opened by hand (from a place's menu) - left on it, the map looked stuck in the place you'd left
            bool left = was >= 0 && ViewDungeon == was;
            if (left && _shownDungeon == was) _shownDungeon = -1;
            RefreshViews();
            // following you: the view goes where you are (into the dungeon, back out)
            if (_follow.ButtonPressed || left)
                for (int i = 0; i < _view.ItemCount; i++)
                    if ((string)_view.GetItemMetadata(i) == HereIn) { _view.Select(i); ViewChanged(false); break; }
        }
        // (the map you're on has changed with nothing else to say so - into a tier copy of the land or out of it, once
        // /location has answered: following, the view goes with you)
        string hereIn = HereIn;
        if (hereIn != _lastHereIn) { _lastHereIn = hereIn; if (_follow.ButtonPressed) { RefreshViews(); FollowHere(); } }
        if (_follow.ButtonPressed && Player.Active)
        {
            var at = PlayerMap;
            // in the world for the first time, or somewhere else in it all at once (a portal, a recall): in on yourself, as
            // going into a dungeon or out of one does
            bool jumped = _followedAt is { } was2 && (at - was2).Length() > 0.5f;
            // (somewhere else all at once: which copy of the land this is isn't known till /location is answered again)
            if (jumped) _outSince = Time.GetTicksMsec() / 1000.0;
            if (jumped && Time.GetTicksMsec() / 1000.0 - _verSaidAt > 3.0 && _outTier != 0) { _outTier = 0; RefreshViews(); FollowHere(); }
            if (here < 0 && ViewDungeon < 0 && View == "" && (_followedInto != -1 || jumped))
            { _followedInto = -1; _canvas.ShowAround(50f); }
            _followedAt = at;
            _canvas.CenterOn(at);
        }
        else _followedAt = null;
        FollowLevel(here);
        _canvas.QueueRedraw();
    }

    /// <summary>Where you've been in each dungeon this session (map points, with their level): drawn as a trail.</summary>
    public readonly Dictionary<int, List<(System.Numerics.Vector2 at, int level)>> Trails = new();

    // a point every couple of metres you go, in the dungeon you're in (kept while the map is shut too)
    private void RecordTrail()
    {
        uint c = PlayerCell?.Invoke() ?? 0;
        if (!Player.Active || (c & 0xFFFF) < 0x100 || (c & 0xFFFF) >= 0xFFFE) return;
        int lb = (int)(c >> 16);
        var at = PlayerMap;
        var (_, _, z) = World.ToAc(Player.Position);
        if (!Trails.TryGetValue(lb, out var list)) Trails[lb] = list = new();
        if (list.Count > 0 && System.Numerics.Vector2.Distance(list[^1].at, at) < 2f / 240f) return;
        list.Add((at, DungeonLayout.LevelOf(z + 0.5f)));
        if (list.Count > 20000) list.RemoveRange(0, 5000);
    }

    // following you in a dungeon: the level shown is the one you're on, changing as you take the ramps and stairs (a level
    // picked by hand stays till you go to another)
    private int _playerLevel = int.MinValue;
    private int LevelAt(int item) => item >= 0 && item < _level.ItemCount && _level.GetItemMetadata(item).VariantType == Variant.Type.Int ? (int)_level.GetItemMetadata(item) : int.MinValue;
    private void FollowLevel(int here)
    {
        if (!_follow.ButtonPressed || !Player.Active || here < 0 || ViewDungeon != here || _canvas.Layout is not { } lay) { _playerLevel = int.MinValue; return; }
        var (_, _, z) = World.ToAc(Player.Position);
        int lvl = DungeonLayout.LevelOf(z + 0.5f);
        if (lvl == _playerLevel || !lay.Levels.Contains(lvl)) return;
        _playerLevel = lvl;
        for (int i = 0; i < _level.ItemCount; i++)
            if (LevelAt(i) == lvl) { _level.Select(i); _canvas.Level = lvl; break; }
    }

    /// <summary>Where you are on the map (east, north).</summary>
    public System.Numerics.Vector2 PlayerMap
    {
        get { var (x, y, _) = World.ToAc(Player.Position); return new System.Numerics.Vector2(x / 240f - 101.95f, y / 240f - 101.95f); }
    }

    public void SetStatus(string s) => _status.Text = s;
    public void StopFollowing() => _follow.ButtonPressed = false;

    // ── search ──
    private List<Place> _found = new();

    private void Search()
    {
        string q = _search.Text.Trim();
        _results.Clear();
        _found.Clear();
        if (q.Length < 2) { _results.Visible = false; return; }
        foreach (var p in Data.Places)
            if (p.Name.Contains(q, StringComparison.OrdinalIgnoreCase)) { _found.Add(p); if (_found.Count >= 60) break; }
        foreach (var p in _found) _results.AddItem($"{p.Name}  ({p.Type})  {new MapSpot(p.NS, p.EW, 0, p, -1).Coords}");
        _results.Visible = _found.Count > 0;
    }

    private void PickResult(int i)
    {
        if (i < 0 || i >= _found.Count) return;
        var p = _found[i];
        _follow.ButtonPressed = false;
        if (p.In == "tier11+" && View != "tier11+") for (int k = 0; k < _view.ItemCount; k++) if ((string)_view.GetItemMetadata(k) == "tier11+") { _view.Select(k); ViewChanged(false); }
        _canvas.CenterOn(new System.Numerics.Vector2((float)p.EW, (float)p.NS));
        _canvas.ScaleAtLeast(60f);
        _canvas.Flash = p;
        _canvas.StartFlash();
        _search.Text = "";
        _results.Visible = false;
    }

    /// <summary>Opens the map on a spot (a plugin's "show on the map"), ringed for a moment.</summary>
    public void ShowSpot(double ns, double ew, string name)
    {
        Open();
        SetCollapsed(false);
        _follow.ButtonPressed = false;
        _canvas.CenterOn(new System.Numerics.Vector2((float)ew, (float)ns));
        _canvas.ScaleAtLeast(60f);
        _canvas.Flash = new Place { Name = name, NS = ns, EW = ew };
        _canvas.StartFlash();
    }

    // ── the right-click menu ──
    private PopupMenu? _menu;
    private readonly List<Action> _menuActions = new();
    private readonly HashSet<PopupMenu> _hooked = new();

    public void OpenMenu(MapSpot spot, List<Place> places, Vector2 screenAt)
    {
        _menu?.QueueFree();
        _menuActions.Clear();
        _hooked.Clear();
        _menu = new PopupMenu();
        if (RetailTheme.Current is { } th) _menu.Theme = th;
        AddChild(_menu);
        // (a right-click somewhere else on the map shuts this menu - and opens it again there)
        _menu.PopupHide += () =>
        {
            if (!Input.IsMouseButtonPressed(MouseButton.Right) || _canvas == null || !_canvas.IsVisibleInTree()) return;
            var gm = _canvas.GetGlobalMousePosition();
            if (!_canvas.GetGlobalRect().HasPoint(gm)) return;
            var local = _canvas.GetLocalMousePosition();
            Callable.From(() => _canvas.RightClickAt(local, gm)).CallDeferred();
        };
        if (places.Count <= 1)
        {
            var place = places.Count == 1 ? places[0] : null;
            Items(_menu, spot with { Place = place, Dungeon = place != null ? Data.DungeonOf(place) : spot.Dungeon });
        }
        else
        {
            _menu.AddSeparator($"{places.Count} places here");
            foreach (var p in places.Take(30))
            {
                var sub = new PopupMenu();
                if (RetailTheme.Current is { } th2) sub.Theme = th2;
                MenuSize(sub);
                Items(sub, spot with { NS = p.NS, EW = p.EW, Place = p, Dungeon = Data.DungeonOf(p) });
                _menu.AddSubmenuNodeItem($"{p.Name}  ({p.Type})", sub);
            }
            _menu.AddSeparator();
            AddItem(_menu, "Add a point here...", () => EditPoint(NewPoint(spot.NS, spot.EW), true));
        }
        MenuSize(_menu);
        _menu.Position = (Vector2I)(GetViewport().GetMousePosition());
        _menu.Popup();
    }

    private void AddItem(PopupMenu m, string label, Action a, bool check = false, bool on = false)
    {
        int id = _menuActions.Count;
        _menuActions.Add(a);
        if (check) { m.AddCheckItem(label, id); m.SetItemChecked(m.ItemCount - 1, on); }
        else m.AddItem(label, id);
        if (_hooked.Add(m))
            m.IdPressed += i => { if (i >= 0 && i < _menuActions.Count) _menuActions[(int)i](); };
    }

    /// <summary>How far a spot is from you in a straight line ("  -  350 m" / "  -  2.4 km"), when it's on the map you're in:
    /// a spot in the world while you're outside, or in the dungeon you're in. Nothing otherwise.</summary>
    private string HowFar(MapSpot s)
    {
        if (!Player.Active) return "";
        if (Math.Max(s.Dungeon, -1) != Math.Max(CurrentDungeon, -1)) return "";
        double ns = s.Place?.NS ?? s.NS, ew = s.Place?.EW ?? s.EW;
        var me = PlayerMap;
        double d = Math.Sqrt((ew - me.X) * (ew - me.X) + (ns - me.Y) * (ns - me.Y)) * 240.0;
        var ci = System.Globalization.CultureInfo.InvariantCulture;
        return d < 1000 ? $"  -  {d.ToString("0", ci)} m" : $"  -  {(d / 1000).ToString("0.0#", ci)} km";
    }

    private void Items(PopupMenu m, MapSpot s)
    {
        var p = s.Place;
        m.AddSeparator((p != null ? $"{p.Name}  -  {p.Type}  {new MapSpot(p.NS, p.EW, 0, p, -1).Coords}" : s.Coords) + HowFar(s));
        string name = p?.Name ?? s.Coords;
        AddItem(m, "Point the arrow here", () => { PointTo(s.NS, s.EW, name); });
        var ci = System.Globalization.CultureInfo.InvariantCulture;
        string at = $"{s.NS.ToString("0.#####", ci)} {s.EW.ToString("0.#####", ci)} {s.Z.ToString("0.##", ci)}";
        if (HasMelkTank)
        {
            AddItem(m, "Run here (Nav)", () => { Cmd("/mtank maproute clear"); Cmd("/mtank maproute add " + at); });
            AddItem(m, "Add next nav point here", () => Cmd("/mtank maproute add " + at));
            // (the whole way there - portals, recalls, running - as the quest tracker's travel plans it)
            if (s.Dungeon < 0)
            {
                string coords = p != null ? new MapSpot(p.NS, p.EW, 0, p, -1).Coords : s.Coords;
                AddItem(m, "Auto-nav here (travel)", () => Cmd("/mqt travel auto " + coords));
            }
        }
        // the map route, or a quest tracker point: cleared, and the nav / travel to it stopped
        if (RoutePoints().Count > 0 || Mark != null)
            AddItem(m, "Clear the map route", () =>
            {
                if (RoutePoints().Count > 0) Cmd("/mtank maproute clear");
                if (Mark != null) { Cmd("/ga stop"); Mark = null; }
                if (HasMelkTank) Cmd("/mtank travel stop");
            });
        AddItem(m, "Put the coordinates in chat", () => Say?.Invoke($"{name}: {s.Coords}", new Color(1f, 0.9f, 0.4f)));
        if (s.Dungeon >= 0) AddItem(m, $"Show the dungeon's layout ({Data.DungeonName(s.Dungeon)})", () => ShowDungeon(s.Dungeon));
        m.AddSeparator();
        if (p == null) AddItem(m, "Add a point here...", () => EditPoint(NewPoint(s.NS, s.EW), true));
        else if (p.Mine)
        {
            AddItem(m, "Change...", () => EditPoint(p, false));
            AddItem(m, "Delete", () => { Data.Places.Remove(p); Data.SaveUser(); _canvas.QueueRedraw(); });
        }
        else AddItem(m, "Copy to my points (to change it)...", () => EditPoint(new Place { Name = p.Name, Type = Array.IndexOf(MapData.PointTypes, p.Type) >= 0 ? p.Type : "Custom", NS = p.NS, EW = p.EW, Notes = p.Notes, Mine = true, Layer = "My points", In = p.In }, true));
        if (p != null && p.Layer == "Portals")
        {
            bool rnd = Data.Random.Contains(p.Key);
            AddItem(m, "Random destination", () => { if (rnd) Data.Random.Remove(p.Key); else Data.Random.Add(p.Key); Data.SaveUser(); }, true, rnd);
            bool use = !Data.Avoid.Contains(p.Key);
            AddItem(m, "Use it for routes", () => { if (use) Data.Avoid.Add(p.Key); else Data.Avoid.Remove(p.Key); Data.SaveUser(); }, true, use);
        }
        // what plugins add
        if (Plugins != null)
        {
            bool sep = false;
            foreach (var item in Plugins.MapMenu)
            {
                bool show;
                try { show = item.Show?.Invoke(s) ?? true; } catch { show = false; }
                if (!show) continue;
                if (!sep) { m.AddSeparator(); sep = true; }
                var it = item;
                AddItem(m, it.Label, () => { try { it.Run(s); } catch (Exception ex) { Say?.Invoke($"{it.Label}: {ex.Message}", new Color(1f, 0.5f, 0.4f)); } });
            }
        }
    }

    // ── adding / changing your own points ──
    // a new point of yours on the map shown: a dungeon's (its own points, on the level shown), Tier 11+'s, or the world's
    // (a point added on a dungeon's map went to the world's - saved, but never shown on the dungeon)
    private Place NewPoint(double ns, double ew)
    {
        string inMap = View.StartsWith("d:") ? View : View == "tier11+" ? "tier11+" : "";
        double z = inMap.StartsWith("d:") && _canvas.Level != int.MinValue ? _canvas.Level * 6.0 : double.NaN;
        return new Place { Type = "Custom", NS = ns, EW = ew, Z = z, Mine = true, Layer = "My points", In = inMap };
    }

    private void EditPoint(Place p, bool isNew)
    {
        var dlg = new ConfirmationDialog { Title = isNew ? "Add a point" : "Change the point", OkButtonText = "Save" };
        if (RetailTheme.Current is { } th) dlg.Theme = th;
        var g = new GridContainer { Columns = 2 };
        var nameE = new LineEdit { Text = p.Name, CustomMinimumSize = new Vector2(240, 0) };
        var typeE = new OptionButton();
        foreach (var t in MapData.PointTypes) typeE.AddItem(t);
        typeE.Select(Math.Max(0, Array.IndexOf(MapData.PointTypes, p.Type)));
        var coordsE = new LineEdit { Text = new MapSpot(p.NS, p.EW, 0, p, -1).Coords };
        var notesE = new LineEdit { Text = p.Notes };
        g.AddChild(new Label { Text = "Name" }); g.AddChild(nameE);
        g.AddChild(new Label { Text = "Type" }); g.AddChild(typeE);
        g.AddChild(new Label { Text = "Where" }); g.AddChild(coordsE);
        g.AddChild(new Label { Text = "Notes" }); g.AddChild(notesE);
        dlg.AddChild(g);
        AddChild(dlg);
        dlg.Confirmed += () =>
        {
            var m = System.Text.RegularExpressions.Regex.Match(coordsE.Text.ToUpperInvariant(), @"([\d.]+)\s*([NS])[\s,]+([\d.]+)\s*([EW])");
            if (m.Success)
            {
                p.NS = double.Parse(m.Groups[1].Value, CultureInfo.InvariantCulture) * (m.Groups[2].Value == "S" ? -1 : 1);
                p.EW = double.Parse(m.Groups[3].Value, CultureInfo.InvariantCulture) * (m.Groups[4].Value == "W" ? -1 : 1);
            }
            p.Name = nameE.Text.Trim().Length > 0 ? nameE.Text.Trim() : "My point";
            p.Type = MapData.PointTypes[Math.Max(0, typeE.Selected)];
            p.Notes = notesE.Text.Trim();
            if (isNew) Data.Places.Add(p);
            Data.SaveUser();
            _canvas.QueueRedraw();
            dlg.QueueFree();
        };
        dlg.Canceled += () => dlg.QueueFree();
        dlg.PopupCentered();
    }

    // ── kept: place, size, opacity, hidden layers ──
    private void Load()
    {
        var cfg = new ConfigFile();
        if (global::ACGodot.SafeConfig.Load(cfg, SavePath) != Error.Ok) return;
        if (cfg.HasSectionKey("map", "at")) _at = (Vector2)cfg.GetValue("map", "at");
        if (cfg.HasSectionKey("map", "size")) _size = (Vector2)cfg.GetValue("map", "size");
        _opacity = (float)cfg.GetValue("map", "opacity", 0.95f);
        _collapsed = (bool)cfg.GetValue("map", "collapsed", false);
        foreach (var l in ((string)cfg.GetValue("map", "hidden", "")).Split(',', StringSplitOptions.RemoveEmptyEntries)) _hidden.Add(l);
        _autoPortals = (bool)cfg.GetValue("map", "auto_portals", true);
        _autoNpcs = (bool)cfg.GetValue("map", "auto_npcs", true);
        TextScale = Math.Clamp((float)(double)cfg.GetValue("map", "text_scale", 1.0), 0.5f, 3f);
        MenuScale = Math.Clamp((float)(double)cfg.GetValue("map", "menu_scale", 1.0), 0.5f, 3f);
    }

    private void Save()
    {
        var cfg = new ConfigFile();
        global::ACGodot.SafeConfig.Load(cfg, SavePath);
        if (_at is { } a) cfg.SetValue("map", "at", a);
        if (_size is { } s) cfg.SetValue("map", "size", s);
        cfg.SetValue("map", "opacity", _opacity);
        cfg.SetValue("map", "hidden", string.Join(",", _hidden));
        cfg.SetValue("map", "auto_portals", _autoPortals);
        cfg.SetValue("map", "auto_npcs", _autoNpcs);
        global::ACGodot.SafeConfig.Save(cfg, SavePath);
    }
}
