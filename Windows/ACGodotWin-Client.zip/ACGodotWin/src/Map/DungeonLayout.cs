using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using DatReaderWriter.DBObjs;

namespace ACGodot.Map;

/// <summary>
/// A dungeon's layout from the game's files: every room's walls where they meet its floor, seen from above, in map
/// coordinates, by level (6 m apart), with each room's floor filled in. Read once per dungeon.
/// </summary>
public sealed class DungeonLayout
{
    public int Landblock;
    public readonly List<(Vector2 a, Vector2 b, int level)> Walls = new();
    /// <summary>For each wall (same order): how high its room's floor lies, lowest to highest (a sloping passage's rise).</summary>
    public readonly List<(float low, float high)> WallHeights = new();
    public readonly List<(Vector2[] poly, int level)> Floors = new();
    /// <summary>Tops of blocks standing in rooms (daises, crates built in): in the way, drawn darker.</summary>
    public readonly List<(Vector2[] poly, int level)> Raised = new();
    /// <summary>Drops: the open floor of a room's upper half (the room goes on down a level - you can't walk on across).</summary>
    public readonly List<(Vector2[] poly, int level)> Drops = new();
    public readonly SortedSet<int> Levels = new();
    /// <summary>
    /// The ways between levels: each room's ramps and stairs (its floor parts that slope or step up), how high they go
    /// (world z, low to high), and which way is up on the map.
    /// </summary>
    public readonly List<Ramp> Ramps = new();
    public sealed class Ramp { public List<Vector2[]> Polys = new(); public float ZLow, ZHigh; public Vector2 Center, Up; }
    public static int LevelOf(float z) => (int)MathF.Round(z / 6f);
    /// <summary>Rooms under the landscape (a cave, cellars) rather than a dungeon of its own: its levels are named from
    /// the top down (0 at the way in, -1 under it ...), a dungeon's as the game's heights give them.</summary>
    public bool Surface;
    public int Label(int level) => Surface && Levels.Count > 0 ? level - Levels.Max : level;
    public Vector2 Min = new(float.MaxValue), Max = new(float.MinValue);   // map units (x east, y north)

    private static readonly Dictionary<int, DungeonLayout?> Cache = new();

    public static DungeonLayout? Of(Dats dats, int lb)
    {
        lock (Cache) if (Cache.TryGetValue(lb, out var c)) return c;
        DungeonLayout? d = null;
        try { d = Read(dats, lb); } catch { d = null; }
        lock (Cache) Cache[lb] = d;
        return d;
    }

    private static DungeonLayout? Read(Dats dats, int lb)
    {
        uint hi = (uint)lb << 16;
        var info = dats.Cell<LandBlockInfo>(hi | 0xFFFEu);
        if (info == null || info.NumCells == 0) return null;
        var d = new DungeonLayout { Landblock = lb };
        int lx = lb >> 8, ly = lb & 0xFF;
        var leftOver = ACGodot.Objects.LandblockObjects.LeftOverCells(id => dats.Cell<EnvCell>(id), info, hi | 0x100u);
        d.Surface = info.Buildings.Count > 0;
        for (uint i = 0; i < info.NumCells; i++)
        {
            if (leftOver.Contains(hi | (0x100u + i))) continue;
            var cell = dats.Cell<EnvCell>(hi | (0x100u + i));
            if (cell == null) continue;
            var env = dats.Get<DatReaderWriter.DBObjs.Environment>(0x0D000000u | cell.EnvironmentId);
            if (env == null || !env.Cells.TryGetValue(cell.CellStructure, out var cs)) continue;
            var o = cell.Position.Origin;
            var q = new Quaternion(cell.Position.Orientation.X, cell.Position.Orientation.Y, cell.Position.Orientation.Z, cell.Position.Orientation.W);
            int level = (int)MathF.Round(o.Z / 6f);   // (set again below from where its floor is)
            Vector2 Map(Vector3 v)
            {
                var w = Vector3.Transform(v, q) + new Vector3(o.X, o.Y, o.Z);
                // map units: east = x, north = y (the landblock's own place in the world)
                float ew = (lx * 192f + w.X) / 240f - 101.95f, ns = (ly * 192f + w.Y) / 240f - 101.95f;
                return new Vector2(ew, ns);
            }
            // this room's ramps and stairs: (its map outline, its height in the world, its middle, uphill on the map)
            var ways = new List<(Vector2[] poly, float zlo, float zhi, Vector2 mid, Vector2 up)>();
            // each room's polygons as MelksQB's dungeon map read them: the floor is the lowest of what faces up (not the
            // cell's own origin - many rooms sit with their floor well off it); what faces up within 3 m of that is floor
            // (ramps too), starting more than 0.5 m above it a block's top; walls are what you bump into, their line on the floor
            var ups = new List<(Vector3[] pts, Vector2[] map, float avg, float low, float nz, Vector2 down)>();
            float minZ = float.MaxValue;
            // the openings to the next rooms are polygons too: an opening in the floor is no floor - it's the top of a room
            // two levels high (the room's upper half is a room of its own, standing on the lower one): a drop
            var openings = new HashSet<ushort>(cell.CellPortals.Select(cp => (ushort)cp.PolygonId));
            float cellLow = float.MaxValue;
            foreach (var vv in cs.VertexArray.Vertices.Values) cellLow = Math.Min(cellLow, Vector3.Transform(new Vector3(vv.Origin.X, vv.Origin.Y, vv.Origin.Z), q).Z);
            var drops = new List<Vector2[]>();
            var banks = new List<(float low, float top)>();
            foreach (var kvp in cs.Polygons)
            {
                var poly = kvp.Value;
                var (pts, map) = Points(poly.VertexIds);
                if (pts == null) continue;
                var n = Newell(pts);
                if (n.LengthSquared() < 1e-12f) continue;
                n = Vector3.Normalize(n);
                if (openings.Contains(kvp.Key))
                {
                    if (MathF.Abs(n.Z) > 0.7f && pts.Average(p => p.Z) < cellLow + 0.5f) drops.Add(map!);
                    continue;
                }
                if (n.Z > 0.3f) banks.Add((pts.Min(p => p.Z), pts.Max(p => p.Z)));   // floor, and the slopes and banks up from it
                if (n.Z < 0.7f) continue;   // not facing up (walls; a ceiling faces down)
                float avg = pts.Average(p => p.Z), low = pts.Min(p => p.Z);
                ups.Add((pts, map!, avg, low, n.Z, new Vector2(n.X, n.Y)));
                minZ = Math.Min(minZ, avg);
            }
            // a space over a room and open only to it (a vaulted ceiling, a dome): not somewhere to be - left off
            if (drops.Count > 0 && drops.Count >= openings.Count) continue;
            var floorParts = ups.Where(u => u.avg <= minZ + 3.0f).ToList();
            if (minZ != float.MaxValue) level = (int)MathF.Round((o.Z + minZ) / 6f);   // its level: where you stand in it
            d.Levels.Add(level);
            foreach (var dp in drops) { d.Drops.Add((dp, level)); foreach (var v in dp) { d.Min = Vector2.Min(d.Min, v); d.Max = Vector2.Max(d.Max, v); } }
            // a ramp or stairs: the room's floor climbs a good way (not a step up onto a dais)
            float span = floorParts.Count > 0 ? floorParts.Max(u => u.avg) - minZ : 0f;
            bool climbs = span >= 1.5f;
            foreach (var u in floorParts)
            {
                bool sloped = u.nz < 0.97f;
                if (climbs && (sloped || u.low > minZ + 0.2f))
                {
                    var mid = new Vector2(u.map.Average(v => v.X), u.map.Average(v => v.Y));
                    ways.Add((u.map, u.low + o.Z, u.pts.Max(p => p.Z) + o.Z, mid, sloped ? Vector2.Normalize(-u.down) : Vector2.Zero));
                    continue;
                }
                if (u.low > minZ + 0.5f) d.Raised.Add((u.map, level));   // the top of a block standing in the room
                else d.Floors.Add((u.map, level));
                foreach (var v in u.map) { d.Min = Vector2.Min(d.Min, v); d.Max = Vector2.Max(d.Max, v); }
            }
            // how high a wall can start and still be a wall of this floor: a little over the floor - and over any slope or
            // bank the floor climbs to first (a cave's floor rises to its walls; a ramp's walls climb with it)
            float wallReach = minZ + 1.5f;
            for (bool grew = true; grew;)
            {
                grew = false;
                foreach (var (bl, bt) in banks) if (bl <= wallReach && bt + 0.75f > wallReach) { wallReach = bt + 0.75f; grew = true; }
            }
            // walls: from what you bump into (the physics polygons) when the room has them, else from what's drawn
            var wallPolys = cs.PhysicsPolygons != null && cs.PhysicsPolygons.Count > 0 ? cs.PhysicsPolygons.Values : cs.Polygons.Values;
            foreach (var poly in wallPolys)
            {
                var (pts, map) = Points(poly.VertexIds);
                if (pts == null) continue;
                var n = Newell(pts);
                if (n.LengthSquared() < 1e-12f) continue;
                n = Vector3.Normalize(n);
                if (MathF.Abs(n.Z) >= 0.3f) continue;
                if (minZ != float.MaxValue && pts.Min(p => p.Z) > wallReach) continue;   // high up (a ledge, an arch's top)
                // seen from above a wall is a line: its two points furthest apart
                int a = 0, b = 0; float best = -1;
                for (int x = 0; x < map!.Length; x++)
                    for (int y = x + 1; y < map.Length; y++)
                    {
                        float dd = Vector2.DistanceSquared(map[x], map[y]);
                        if (dd > best) { best = dd; a = x; b = y; }
                    }
                if (best < (0.2f / 240f) * (0.2f / 240f)) continue;   // end-on (a pillar's face is drawn by its others)
                d.Walls.Add((map[a], map[b], level));
                d.WallHeights.Add((o.Z + (minZ != float.MaxValue ? minZ : 0f), o.Z + (minZ != float.MaxValue ? minZ : 0f) + span));
                d.Min = Vector2.Min(d.Min, Vector2.Min(map[a], map[b]));
                d.Max = Vector2.Max(d.Max, Vector2.Max(map[a], map[b]));
            }
            (Vector3[]? pts, Vector2[]? map) Points(IEnumerable<short> ids)
            {
                var pl = new List<Vector3>(); var ml = new List<Vector2>();
                foreach (var vid in ids)
                {
                    if (!cs.VertexArray.Vertices.TryGetValue((ushort)vid, out var sw)) return (null, null);
                    var raw = new Vector3(sw.Origin.X, sw.Origin.Y, sw.Origin.Z);
                    pl.Add(Vector3.Transform(raw, q)); ml.Add(Map(raw));
                }
                return pl.Count >= 3 ? (pl.ToArray(), ml.ToArray()) : (null, null);
            }
            // its ramps and stairs as one way between levels
            if (ways.Count > 0)
            {
                float zlo = ways.Min(w => w.zlo), zhi = ways.Max(w => w.zhi);
                var r = new Ramp { ZLow = zlo, ZHigh = zhi };
                foreach (var w in ways) { r.Polys.Add(w.poly); foreach (var v in w.poly) { d.Min = Vector2.Min(d.Min, v); d.Max = Vector2.Max(d.Max, v); } }
                r.Center = new Vector2(ways.Average(w => w.mid.X), ways.Average(w => w.mid.Y));
                var slope = ways.Where(w => w.up != Vector2.Zero).Select(w => w.up).Aggregate(Vector2.Zero, (a, b) => a + b);
                if (slope.LengthSquared() > 1e-6f) r.Up = Vector2.Normalize(slope);
                else
                {
                    // stairs: from the lowest step to the highest
                    var ordered = ways.OrderBy(w => w.zlo).ToList();
                    if (Vector2.DistanceSquared(ordered[0].mid, ordered[^1].mid) > 1e-12f) r.Up = Vector2.Normalize(ordered[^1].mid - ordered[0].mid);
                }
                d.Ramps.Add(r);
            }
        }
        return d.Walls.Count > 0 || d.Floors.Count > 0 ? d : null;
    }

    /// <summary>A polygon's normal (Newell's way: sound for any number of points).</summary>
    private static Vector3 Newell(Vector3[] p)
    {
        Vector3 n = Vector3.Zero;
        for (int i = 0; i < p.Length; i++)
        {
            var a = p[i]; var b = p[(i + 1) % p.Length];
            n.X += (a.Y - b.Y) * (a.Z + b.Z); n.Y += (a.Z - b.Z) * (a.X + b.X); n.Z += (a.X - b.X) * (a.Y + b.Y);
        }
        return n;
    }
}
