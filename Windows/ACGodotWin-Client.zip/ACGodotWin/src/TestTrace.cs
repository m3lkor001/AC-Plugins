using System;
using System.IO;
using System.Threading;

namespace ACGodot;

/// <summary>
/// For finding where the game stops answering (with the test folder switched on): the main thread notes what it's
/// about to do (a string set - no cost to speak of) and ticks each frame; a watcher thread, seeing no tick for a few
/// seconds, writes the last note to claude-test/out/hang.txt.
/// </summary>
public static class TestTrace
{
    public static volatile string Last = "";
    private static long _tick;
    private static Thread? _watch;
    private static string _dir = "";

    public static void Start(string dir)
    {
        if (_watch != null) return;
        _dir = dir;
        Interlocked.Exchange(ref _tick, Environment.TickCount64);
        _watch = new Thread(() =>
        {
            bool said = false;
            while (true)
            {
                Thread.Sleep(1000);
                long quiet = Environment.TickCount64 - Interlocked.Read(ref _tick);
                if (quiet < 4000) { said = false; continue; }
                if (said) continue;
                said = true;
                try
                {
                    Directory.CreateDirectory(Path.Combine(_dir, "out"));
                    File.WriteAllText(Path.Combine(_dir, "out", "hang.txt"), $"{DateTime.Now:HH:mm:ss} no frame for {quiet / 1000.0:0.0} s; last: {Last}\n");
                }
                catch { }
            }
        }) { IsBackground = true, Name = "TestTrace" };
        _watch.Start();
    }

    public static void Tick() => Interlocked.Exchange(ref _tick, Environment.TickCount64);
}
