using System;
using System.Collections.Generic;
using Godot;

namespace ACGodot;

/// <summary>
/// The console's test logging by kind ([use], [pos], [order], [place], [map], [ench] - each line starts with its kind),
/// each switched on or off in Options > Plugins > Debug (kept in ui.cfg; all on until switched off).
/// </summary>
public static class DebugLogs
{
    public static readonly (string tag, string what)[] Kinds =
    {
        ("use", "Using things: corpses, doors, run-ups (and which plugin asked)"),
        ("pos", "Movement the server forces (turning to, walking to)"),
        ("order", "Pack contents and moves (the order things are laid out)"),
        ("place", "Where things are put in packs"),
        ("ench", "Spells on you: added, refreshed, gone"),
        ("map", "The map's loading and markers"),
        ("assets", "Graphics unloaded that nothing was using"),
    };

    private static HashSet<string>? _off;

    private static HashSet<string> Off()
    {
        if (_off != null) return _off;
        _off = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var c = new ConfigFile();
        if (SafeConfig.Load(c, "user://ui.cfg") == Error.Ok)
            foreach (var (tag, _) in Kinds) if (!(bool)c.GetValue("debuglogs", tag, true)) _off.Add(tag);
        return _off;
    }

    public static bool On(string tag) => !Off().Contains(tag);

    public static void Set(string tag, bool on)
    {
        if (on) Off().Remove(tag); else Off().Add(tag);
        var c = new ConfigFile();
        SafeConfig.Load(c, "user://ui.cfg");
        c.SetValue("debuglogs", tag, on);
        SafeConfig.Save(c, "user://ui.cfg");
    }

    /// <summary>A console line "[kind] ...": printed when its kind is on.</summary>
    public static void Print(string line)
    {
        if (line.Length > 2 && line[0] == '[')
        {
            int end = line.IndexOf(']');
            if (end > 1 && Off().Contains(line.Substring(1, end - 1))) return;
        }
        GD.Print(line);
    }
}
