using Godot;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using ACGodot.Objects;

namespace ACGodot;

/// <summary>
/// A way to drive the game from files, for testing from outside: while the folder "claude-test" (beside the project; a game started for an account uses "claude-test/<account>")
/// holds a file named "on", command files dropped in "claude-test/in" are run - a command a line - and what happened
/// is written to "claude-test/out" under the same name (with any pictures asked for). No folder, or no "on": nothing.
///
///   /anything            a chat line or command, as typed
///   wait 1.5             seconds
///   shot name            the game view to out/name.png (half size)
///   state                where you are, your numbers, what's selected, what's on you
///   inv                  the pack, what's worn, the side packs
///   near [text]          the things round you (whose name has the text), nearest first
///   select text|self|none   the nearest thing whose name has the text
///   use / pickup / identify   on what's selected
///   cast spell name      a spell you know, by (part of) its name
///   combat               into or out of combat    attack high|mid|low    stop
///   equip|unequip|drop|give|idi  item name   (give: to what's selected; idi: identify an item of yours)
///   loot                 what the open corpse holds    take item name
///   pack name|main       open a side pack in the inventory
///   key W 1.5            a key held for so long (walking)
///   vendor               the open vendor's wares    buy name | 5    sell name
///   friends              the friends list and fellowship    friend name    fellowship name|quit
///   move item | pack     an item of yours into a side pack (or main)
///   teleto [name]        (an admin account) the server's @teleloc to just in front of a thing
///   place item | 3       to that place in its pack    split item | 5    merge item
///   want item | 40       the number wanted (Components tab)    buylist    buynow
///   skills               the skills you have trained, and what they stand at
///   exit                 leave the game
/// </summary>
public partial class Main
{
    private string? _testDir, _testRoot;
    private double _testPoll, _testWait;
    private readonly Queue<string> _testLines = new();
    private StringBuilder? _testOut;
    private string _testName = "";
    private readonly List<(Key key, double until)> _testKeys = new();
    private double _testClock;
    private ulong _testTickMs;

    // ── frames that stall (the monitor asleep: the screen's refresh the game waits on never comes, and the game
    // crawls - a frame every second or two - its server connection with it): the wait for the screen's refresh is
    // dropped (frames held to 60 a second instead) until the window is the active one again ──
    private ulong _lastFrameMs;
    private int _slowFrames;
    private bool _vsyncDropped;

    private void FrameStallGuard()
    {
        ulong now = Time.GetTicksMsec();
        if (_lastFrameMs != 0 && !_vsyncDropped)
        {
            if (now - _lastFrameMs > 400)
            {
                if (++_slowFrames >= 5)
                {
                    DisplayServer.WindowSetVsyncMode(DisplayServer.VSyncMode.Disabled);
                    Engine.MaxFps = 60;
                    _vsyncDropped = true;
                    GD.Print("Frames were stalling (the screen asleep?): no longer waiting on the screen's refresh.");
                }
            }
            else _slowFrames = 0;
        }
        _lastFrameMs = now;
    }

    // someone's at the keyboard or mouse (the screen's awake, then): back to keeping time with the screen
    public override void _Input(InputEvent e)
    {
        if (_vsyncDropped && e is InputEventKey or InputEventMouseButton or InputEventMouseMotion && !_testKeys.Any()) FrameStallOver();
    }

    /// <summary>The window's the active one again: back to keeping time with the screen.</summary>
    private void FrameStallOver()
    {
        if (!_vsyncDropped) return;
        ACGodot.UI.Video.ApplyFrames();
        _vsyncDropped = false; _slowFrames = 0;
    }

    private void TestBridgeTick(double delta)
    {
        FrameStallGuard();
        // (by the clock, not the frame's own count of time - which the engine caps when frames come slowly)
        ulong tickNow = Time.GetTicksMsec();
        delta = _testTickMs == 0 ? delta : Math.Min((tickNow - _testTickMs) / 1000.0, 5.0);
        _testTickMs = tickNow;
        _testClock += delta;
        TestTrace.Tick();
        TestTrace.Last = "frame";
        for (int i = _testKeys.Count - 1; i >= 0; i--)
            if (_testClock >= _testKeys[i].until) { Input.ParseInputEvent(new InputEventKey { Keycode = _testKeys[i].key, PhysicalKeycode = _testKeys[i].key, Pressed = false }); _testKeys.RemoveAt(i); }
        if (_testOut != null)
        {
            // a file under way: its lines one at a time, waits between
            if ((_testWait -= delta) > 0) return;
            if (_testLines.Count == 0) { TestFinish(); return; }
            string line = _testLines.Dequeue().Trim();
            if (line.Length == 0 || line.StartsWith("#")) return;
            _testOut.AppendLine("> " + line);
            TestFlush();   // (written as it goes: if the game stops answering, the file shows how far it got)
            try { TestRun(line); }
            catch (Exception ex) { _testOut?.AppendLine("  ! " + ex.GetType().Name + ": " + ex.Message); }
            TestFlush();
            return;
        }
        if ((_testPoll -= delta) > 0) return;
        _testPoll = 0.5;
        // each account's game has its own folder under it (claude-test/<account>/in and /out), so two games running at once
        // each take their own commands; a game started with no account uses the folder itself, as before
        _testRoot ??= ProjectSettings.GlobalizePath("res://claude-test");
        try
        {
            if (!File.Exists(Path.Combine(_testRoot, "on"))) return;
            if (_testDir == null)
            {
                string account = new string((System.Environment.GetEnvironmentVariable("ACGODOT_ACCOUNT") ?? "").Where(ch => char.IsLetterOrDigit(ch) || ch is '-' or '_' or '.').ToArray()).Trim('.');
                _testDir = account.Length > 0 ? Path.Combine(_testRoot, account) : _testRoot;
                Directory.CreateDirectory(Path.Combine(_testDir, "in"));
                Directory.CreateDirectory(Path.Combine(_testDir, "out"));
            }
            TestTrace.Start(_testDir);
            string inDir = Path.Combine(_testDir, "in");
            if (!Directory.Exists(inDir)) return;
            string? next = Directory.GetFiles(inDir, "*.txt").OrderBy(f => f, StringComparer.Ordinal).FirstOrDefault();
            if (next == null) return;
            string[] lines = File.ReadAllLines(next);
            File.Delete(next);
            _testName = Path.GetFileNameWithoutExtension(next);
            foreach (var l in lines) _testLines.Enqueue(l);
            _testOut = new StringBuilder();
            _testOut.AppendLine($"# {_testName} started {DateTime.Now:HH:mm:ss}");
        }
        catch (Exception ex) { GD.PushWarning("test bridge: " + ex.Message); }
    }

    private void TestFlush()
    {
        if (_testOut == null || _testDir == null) return;
        try
        {
            string outDir = Path.Combine(_testDir, "out");
            Directory.CreateDirectory(outDir);
            File.WriteAllText(Path.Combine(outDir, _testName + ".txt"), _testOut.ToString());
        }
        catch (Exception ex) { GD.PushWarning("test bridge: " + ex.Message); }
    }

    private void TestFinish()
    {
        try
        {
            string outDir = Path.Combine(_testDir!, "out");
            Directory.CreateDirectory(outDir);
            _testOut!.AppendLine($"# done {DateTime.Now:HH:mm:ss}");
            File.WriteAllText(Path.Combine(outDir, _testName + ".txt"), _testOut.ToString());
        }
        catch (Exception ex) { GD.PushWarning("test bridge: " + ex.Message); }
        _testOut = null;
    }

    /// <summary>What's said in chat while a test file runs goes into its result.</summary>
    private void TestHeard(string text) => _testOut?.AppendLine("  | " + text);
    // (what the line at the top of the screen says: the server's refusals mostly go there, not to the chat)
    private static uint TestId(object v) { try { return v is uint u ? u : v is int i ? (uint)i : Convert.ToUInt32(v.GetType().GetProperty("DataId")?.GetValue(v) ?? v); } catch { return 0; } }
    // a thing's own simple values (numbers, flags, ids), for reading what the game's data says
    private static string TestDump(object o)
    {
        var parts = new List<string>();
        foreach (var p in o.GetType().GetProperties())
        {
            if (p.GetIndexParameters().Length > 0) continue;
            object? v; try { v = p.GetValue(o); } catch { continue; }
            if (v == null) continue;
            var t = v.GetType();
            if (t.IsPrimitive || t.IsEnum) parts.Add($"{p.Name}={(v is uint u ? u.ToString("X") : v is float f ? f.ToString("0.###") : v.ToString())}");
            else if (t.Name.Contains("DataId")) parts.Add($"{p.Name}={TestId(v):X8}");
            else if (t.Name.StartsWith("Vector") || t.Name == "Frame") parts.Add($"{p.Name}={v}");
        }
        foreach (var fi in o.GetType().GetFields())
        {
            object? v; try { v = fi.GetValue(o); } catch { continue; }
            if (v == null) continue;
            var t = v.GetType();
            if (t.IsPrimitive || t.IsEnum) parts.Add($"{fi.Name}={(v is uint u ? u.ToString("X") : v is float f ? f.ToString("0.###") : v.ToString())}");
            else if (t.Name.Contains("DataId")) parts.Add($"{fi.Name}={TestId(v):X8}");
            else if (t.Name.StartsWith("Vector") || t.Name == "Frame") parts.Add($"{fi.Name}={v}");
        }
        return string.Join(" ", parts);
    }

    private void TestStatus(string text) => _testOut?.AppendLine("  ~ " + text);

    private void TestSay(string text) => _testOut?.AppendLine("  " + text);

    private ACGodot.Combat.Item? TestItem(string name)
    {
        var inv = _combat?.Inv;
        if (inv == null) return null;
        return inv.Worn.Concat(inv.Pack).Concat(inv.SidePacks).FirstOrDefault(i => i.Name.Contains(name, StringComparison.OrdinalIgnoreCase));
    }

    private void TestRun(string line)
    {
        if (line.StartsWith("/") || line.StartsWith("@")) { OnChat(line); return; }   // (@: a server command, said as chat)
        int sp = line.IndexOf(' ');
        string cmd = (sp < 0 ? line : line[..sp]).ToLowerInvariant(), arg = sp < 0 ? "" : line[(sp + 1)..].Trim();
        var me = _player?.Position ?? Vector3.Zero;
        switch (cmd)
        {
            case "wait": _testWait = double.TryParse(arg, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double w) ? Math.Clamp(w, 0, 60) : 1; break;
            case "chargen": TestSay(CharGenTest(arg)); break;
            case "shot":
            {
                var img = GetViewport().GetTexture().GetImage();
                img.Resize(Math.Max(1, img.GetWidth() / 2), Math.Max(1, img.GetHeight() / 2), Image.Interpolation.Bilinear);
                string dir = Path.Combine(_testDir!, "out");
                Directory.CreateDirectory(dir);
                string file = Path.Combine(dir, (arg.Length > 0 ? arg : _testName) + ".png");
                TestSay(img.SavePng(file) == Error.Ok ? "saved " + Path.GetFileName(file) : "couldn't save the picture");
                break;
            }
            case "state":
            {
                var (x, y, z) = World.ToAc(me);
                TestSay($"at {x:0.0},{y:0.0},{z:0.0} cell {_player?.Cell:X8}  {(_net?.InWorld == true ? "on the server" : "not on a server")}");
                if (_combat?.Me is { } c)
                {
                    TestSay($"{c.Name} level {c.Level}  xp {c.TotalXp:N0} ({c.UnassignedXp:N0} unassigned, {c.SkillCredits} credits)");
                    TestSay($"health {c.Health}/{c.MaxHealth} stamina {c.Stamina}/{c.MaxStamina} mana {c.Mana}/{c.MaxMana}  {(_combat.CombatMode ? "combat" : "peace")} mode {_combat.ModeNumber}");
                    TestSay("attributes " + string.Join(" ", Enumerable.Range(0, 6).Select(i => $"{ACGodot.Combat.Character.AttributeNames[i][..3]} {c.Attribute(i)}")));
                }
                var sel = _objects?.Selected;
                TestSay(sel == null ? "nothing selected" : $"selected: {sel.Name} (type {sel.Type}, kind {sel.Kind}, {sel.Feet.DistanceTo(me):0.0} m{(sel.Open ? ", open" : "")})");
                if (_magic != null) TestSay("on you: " + string.Join(", ", _magic.Active().Select(a => $"{a.spell.Name} {a.left:0}s")));
                if (_net != null) foreach (var l in _net.Report()) TestSay(l);
                break;
            }
            case "inv":
            {
                var inv = _combat?.Inv;
                if (inv == null) break;
                TestSay($"pyreals {inv.Pyreals:N0}, burden {inv.TotalBurden:N0}");
                if (_net != null) TestSay("pack order: " + _net.PackOrderNote);
                foreach (var i in inv.Worn) TestSay($"worn  {i.Name} (at 0x{i.WornAt:X}) dmg {i.Damage} al {i.ArmorLevel} slots 0x{i.Locations:X} covers 0x{i.Coverage:X}");
                // (what the server says of anything that can be worn: the slots it goes in, the parts it covers)
                foreach (var i in inv.Pack.Where(i => i.Locations != 0 && (arg.Length == 0 || i.Name.Contains(arg, StringComparison.OrdinalIgnoreCase))))
                    TestSay($"wearable  {i.Name}: slots 0x{i.Locations:X} covers 0x{i.Coverage:X} type 0x{i.ItemType:X}");
                foreach (var i in inv.SidePacks) TestSay($"side pack  {i.Name} (holds {i.Capacity}, icon {i.Icon:X8}, id {i.Guid:X8}, order {_net?.PackOrderOf(i)})");
                foreach (var i in inv.Pack) TestSay($"pack{(i.Holder != 0 ? "*" : " ")} {(i.Stack > 1 ? i.Stack + " " : "")}{i.Name}  value {i.Value} burden {i.Burden}{(i.MaxUses > 0 ? $" uses {i.Uses}/{i.MaxUses}" : "")}{(i.CooldownId != 0 ? $" cooldown {i.CooldownId} ({i.CooldownTime:0.#} s, {i.Cooling:0.00} left)" : "")}  icon {i.Icon:X8} under {i.IconUnder:X8} over {i.IconOver:X8} type {i.ItemType:X}");
                break;
            }
            case "cell":
            {
                // the room we're in (or the one named, in hex) and the rooms its openings lead to, as the data files have
                // them: each one's surfaces, how many faces each has, which way they face, where its openings go
                uint id0 = arg.Length > 0 && uint.TryParse(arg.Replace("0x", ""), System.Globalization.NumberStyles.HexNumber, null, out uint named) ? named : _player?.Cell ?? 0;
                if (_dats == null) break;
                var todo = new List<uint> { id0 };
                var first = _dats.Cell<DatReaderWriter.DBObjs.EnvCell>(id0);
                if (first != null) foreach (var cp in first.CellPortals) if (cp.OtherCellId != 0xFFFF && !todo.Contains((id0 & 0xFFFF0000u) | cp.OtherCellId)) todo.Add((id0 & 0xFFFF0000u) | cp.OtherCellId);
                var info = _dats.Cell<DatReaderWriter.DBObjs.LandBlockInfo>((id0 & 0xFFFF0000u) | 0xFFFEu);
                var left = info != null ? ACGodot.Objects.LandblockObjects.LeftOverCells(c => _dats.Get<DatReaderWriter.DBObjs.EnvCell>(c), info, (id0 & 0xFFFF0000u) | 0x100u) : new HashSet<uint>();
                TestSay($"landblock has {info?.NumCells ?? 0} rooms, {info?.Buildings.Count ?? 0} buildings");
                foreach (uint id in todo.Take(12))
                {
                    var cell = _dats.Cell<DatReaderWriter.DBObjs.EnvCell>(id);
                    if (cell == null) { TestSay($"cell {id:X8}: not a room"); continue; }
                    var env = _dats.Get<DatReaderWriter.DBObjs.Environment>(0x0D000000u | cell.EnvironmentId);
                    TestSay($"cell {id:X8}: environment {cell.EnvironmentId:X4} structure {cell.CellStructure}, flags {cell.Flags}, at {cell.Position.Origin.X:0.#},{cell.Position.Origin.Y:0.#},{cell.Position.Origin.Z:0.#}, {cell.Surfaces.Count} surfaces, {cell.StaticObjects.Count} objects{(left.Contains(id) ? ", LEFT OUT (nothing leads in)" : "")}{((id & 0xFFFF) - 0x100 >= (info?.NumCells ?? 0) ? ", PAST THE COUNT" : "")}");
                    TestSay("  openings: " + string.Join(", ", cell.CellPortals.Select(cp => $"poly {cp.PolygonId} -> {cp.OtherCellId:X4} ({cp.Flags})")));
                    if (env == null || !env.Cells.TryGetValue(cell.CellStructure, out var cs)) { TestSay("  no structure"); continue; }
                    var portals = new HashSet<int>(cell.CellPortals.Select(cp => (int)cp.PolygonId));
                    var rows = new Dictionary<string, int>();
                    foreach (var (pid, poly) in cs.Polygons)
                    {
                        var pts = poly.VertexIds.Select(v => cs.VertexArray.Vertices.TryGetValue((ushort)v, out var sw) ? sw.Origin : default).ToList();
                        float nz = 0, zlo = pts.Count > 0 ? pts.Min(q => q.Z) : 0, zhi = pts.Count > 0 ? pts.Max(q => q.Z) : 0;
                        if (pts.Count >= 3) { var nn = System.Numerics.Vector3.Cross(pts[1] - pts[0], pts[2] - pts[0]); if (nn.Length() > 0) nz = System.Numerics.Vector3.Normalize(nn).Z; }
                        string Side(short slot)
                        {
                            if (slot < 0 || slot >= cell.Surfaces.Count) return slot < 0 ? "-" : $"slot {slot} OUT OF RANGE";
                            var sf = _dats.Get<DatReaderWriter.DBObjs.Surface>(0x08000000u | cell.Surfaces[slot]);
                            return $"08{cell.Surfaces[slot]:X6}[{(sf == null ? "missing" : sf.Type.ToString())}{(sf != null && sf.Luminosity > 0 ? $" lum {sf.Luminosity:0.##}" : "")}{(sf != null && sf.Translucency > 0 ? $" transl {sf.Translucency:0.##}" : "")}]";
                        }
                        string key = $"sides {poly.SidesType} stip {poly.Stippling} pos {Side(poly.PosSurface)} neg {Side(poly.NegSurface)}{(portals.Contains((int)pid) ? " PORTAL" : "")} {pts.Count} corners facing {(nz > 0.7f ? "up" : nz < -0.7f ? "down" : "side")} z {zlo:0.#}..{zhi:0.#}";
                        rows[key] = rows.TryGetValue(key, out int r0) ? r0 + 1 : 1;
                    }
                    foreach (var kv in rows.OrderByDescending(k => k.Value)) TestSay($"  {kv.Value,3} x {kv.Key}");
                }
                break;
            }
            case "phys":
            {
                // where the body is in the collision, and the solid faces of the room it's in (and the rooms next to it)
                // within a few metres: which way each faces and how high it stands - to see what stops a step
                if (_player == null || _dats == null) break;
                TestSay(_player.BodyNote);
                uint id0 = _player.Cell;
                var (wx, wy, wz) = World.ToAc(_player.Position);
                int lbx = (int)(id0 >> 24), lby = (int)((id0 >> 16) & 0xFF);
                var here = new System.Numerics.Vector3(wx - lbx * 192f, wy - lby * 192f, wz);
                TestSay($"in the landblock at {here.X:0.00},{here.Y:0.00},{here.Z:0.00}");
                var todo = new List<uint> { id0 };
                var first = _dats.Cell<DatReaderWriter.DBObjs.EnvCell>(id0);
                if (first != null) foreach (var cp in first.CellPortals) if (cp.OtherCellId != 0xFFFF && !todo.Contains((id0 & 0xFFFF0000u) | cp.OtherCellId)) todo.Add((id0 & 0xFFFF0000u) | cp.OtherCellId);
                foreach (uint id in todo.Take(8))
                {
                    var cell = _dats.Cell<DatReaderWriter.DBObjs.EnvCell>(id);
                    if (cell == null) continue;
                    var env = _dats.Get<DatReaderWriter.DBObjs.Environment>(0x0D000000u | cell.EnvironmentId);
                    if (env == null || !env.Cells.TryGetValue(cell.CellStructure, out var cs)) continue;
                    var inv = System.Numerics.Quaternion.Conjugate(cell.Position.Orientation);
                    var p = System.Numerics.Vector3.Transform(here - cell.Position.Origin, inv);
                    TestSay($"cell {id:X8} (structure {cell.CellStructure}): you're at {p.X:0.00},{p.Y:0.00},{p.Z:0.00} in it; {cs.PhysicsPolygons.Count} solid faces, {cell.StaticObjects.Count} things standing in it");
                    foreach (var so in cell.StaticObjects)
                        TestSay($"    thing {so.Id:X8} at {so.Frame.Origin.X:0.00},{so.Frame.Origin.Y:0.00},{so.Frame.Origin.Z:0.00} ({System.Numerics.Vector3.Distance(so.Frame.Origin, here):0.0} m from you)");
                    int said = 0;
                    foreach (var (pid, poly) in cs.PhysicsPolygons)
                    {
                        var pts = poly.VertexIds.Select(v => cs.VertexArray.Vertices.TryGetValue((ushort)v, out var sw) ? sw.Origin : default).ToList();
                        if (pts.Count < 3) continue;
                        float d = pts.Min(q => new System.Numerics.Vector2(q.X - p.X, q.Y - p.Y).Length());
                        var c = new System.Numerics.Vector3(pts.Average(q => q.X), pts.Average(q => q.Y), pts.Average(q => q.Z));
                        if (d > 3.5f && new System.Numerics.Vector2(c.X - p.X, c.Y - p.Y).Length() > 3.5f) continue;
                        var nn = System.Numerics.Vector3.Cross(pts[1] - pts[0], pts[2] - pts[0]);
                        nn = nn.Length() > 0 ? System.Numerics.Vector3.Normalize(nn) : nn;
                        if (said++ < 40)
                            TestSay($"    face {pid}: {pts.Count} corners, normal {nn.X:0.00},{nn.Y:0.00},{nn.Z:0.00}, z {pts.Min(q => q.Z):0.00}..{pts.Max(q => q.Z):0.00}, x {pts.Min(q => q.X):0.0}..{pts.Max(q => q.X):0.0}, y {pts.Min(q => q.Y):0.0}..{pts.Max(q => q.Y):0.0}{(cell.CellPortals.Any(cp => cp.PolygonId == pid) ? " (opening)" : "")}");
                    }
                }
                break;
            }
            case "mappts": foreach (var d in _map?.PointNotes(arg) ?? Enumerable.Empty<string>()) TestSay(d); break;
            case "draw": _testDraws = arg != "off"; ApplyBackground(); TestSay(_testDraws ? "world drawn while the window isn't active" : "world rested again while the window isn't active"); break;
            case "skills":
                if (_combat?.Me is { } who)
                    foreach (var (id, name) in who.AllSkills())
                        if (who.TrainingOf(id) != ACGodot.Combat.Character.Training.Untrained) TestSay($"{name} {who.Skill(id)} ({who.TrainingOf(id)})");
                break;
            case "held": foreach (var d in _net?.HeldNotes() ?? Enumerable.Empty<string>()) TestSay(d); break;
            case "near":
                foreach (var s in (_objects?.AllSelectables ?? Enumerable.Empty<ObjectStreamer.Selectable>())
                             .Where(s => !s.Gone && s.Name.Contains(arg, StringComparison.OrdinalIgnoreCase)).OrderBy(s => s.Feet.DistanceTo(me)).Take(40))
                    TestSay($"{s.Feet.DistanceTo(me),6:0.0} m  {s.Name} (type {s.Type}, kind {s.Kind}{(s.Remote ? ", server" : "")}{(s.Open ? ", open" : "")})");
                break;
            case "select":
            {
                if (_objects == null) break;
                // ("#55 Cottage": of that type only - a house and its sign share a name)
                int wantType = -1;
                if (arg.StartsWith("#") && arg.IndexOf(' ') is int tsp && tsp > 1 && int.TryParse(arg.AsSpan(1, tsp - 1), out int wt)) { wantType = wt; arg = arg[(tsp + 1)..].Trim(); }
                var s = arg.Equals("none", StringComparison.OrdinalIgnoreCase) ? null
                      : arg.Equals("self", StringComparison.OrdinalIgnoreCase) ? _objects.Self
                      : _objects.AllSelectables.Where(s => !s.Gone && (wantType < 0 || s.Type == wantType) && s.Name.Contains(arg, StringComparison.OrdinalIgnoreCase)).OrderBy(s => s.Feet.DistanceTo(me)).FirstOrDefault();
                _objects.Select(s);
                TestSay(s == null ? "nothing selected" : $"selected {s.Name}, {s.Feet.DistanceTo(me):0.0} m");
                break;
            }
            case "use": UseSelected(); TestSay(_status); break;
            case "pickup": PickUpSelected(); TestSay(_status); break;
            case "identify": Identify(_objects?.Selected, false); break;
            case "cast":
            {
                var spell = _magic?.Known().FirstOrDefault(s => s.Name.Contains(arg, StringComparison.OrdinalIgnoreCase));
                if (spell == null) TestSay("no known spell named that"); else { TestSay("casting " + spell.Name); CastSpell(spell.Id); }
                break;
            }
            case "combat": TestSay(_combat?.ToggleCombat() ?? ""); break;
            case "attack": TestSay(_combat?.AttackKey(arg.StartsWith("h") ? 0 : arg.StartsWith("l") ? 2 : 1) ?? ""); break;
            case "stop": _combat?.CancelAttack(); break;
            case "book":
            {
                // a book of yours opened (used): its pages as they come, each page's first words
                var bk = TestItem(arg);
                if (bk == null || _net == null) { TestSay("no item of yours named that"); break; }
                if (!_bookTest) { _bookTest = true; _net.BookPage += (g, page, pages, text) => TestSay(page < 0 ? $"book {g:X8} opened: {pages} pages" : $"book {g:X8} page {page + 1}: {(text ?? "").Length} letters: {(text ?? "").Replace("\n", " / ")[..Math.Min(70, (text ?? "").Replace("\n", " / ").Length)]}"); }
                UseCarried(bk);
                break;
            }
            case "equip": case "unequip": case "drop": case "give": case "idi":
            {
                var it = TestItem(arg);
                var inv = _combat?.Inv;
                if (it == null || inv == null) { TestSay("no item of yours named that"); break; }
                if (cmd == "equip") TestSay(inv.Equip(it));
                else if (cmd == "unequip") TestSay(inv.Unequip(it));
                else if (cmd == "drop") { if (inv.Worn.Contains(it)) inv.Unequip(it); inv.Remove(it); _combat!.Drop(it); }
                // (asked of the server too, so it's the server's "last identified" - what its admin commands act on)
                else if (cmd == "idi") { IdentifyItem(it); if (it.Guid != 0) { _net?.Appraise(it.Guid); _net?.QueryHealth(it.Guid); } TestSay($"identified {it.Name} (id {it.Guid:X8})"); }
                else if (_objects?.Selected is { } to && _net != null) _net.Give(to, it, Math.Max(1, it.Stack));
                else TestSay("nobody selected to give it to");
                break;
            }
            case "loot":
                if (_lootWin is { Visible: true, Contents: { } inside }) { foreach (var i in inside) TestSay($"{(i.Stack > 1 ? i.Stack + " " : "")}{i.Name}"); if (inside.Count == 0) TestSay("it's empty"); }
                else TestSay("no corpse or chest open");
                break;
            case "take":
            {
                var it = _lootWin is { Visible: true, Contents: { } held } ? held.FirstOrDefault(i => i.Name.Contains(arg, StringComparison.OrdinalIgnoreCase)) : null;
                if (it == null) TestSay("nothing of that name in an open corpse"); else _lootWin!.TakeIt(it);
                break;
            }
            case "pack":
            {
                var inv = _combat?.Inv;
                if (inv == null) break;
                inv.Viewing = inv.SidePacks.FirstOrDefault(p => p.Name.Contains(arg, StringComparison.OrdinalIgnoreCase) && !arg.Equals("main", StringComparison.OrdinalIgnoreCase))?.Guid ?? 0;
                _invPanel?.Refresh();
                break;
            }
            case "key":
            {
                var parts = arg.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length == 0 || !Enum.TryParse<Key>(parts[0], true, out var key)) { TestSay("no such key"); break; }
                double secs = parts.Length > 1 && double.TryParse(parts[1], System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double hs) ? Math.Clamp(hs, 0.05, 20) : 0.1;
                Input.ParseInputEvent(new InputEventKey { Keycode = key, PhysicalKeycode = key, Pressed = true });
                _testKeys.Add((key, _testClock + secs));
                _testWait = secs;
                break;
            }
            case "useitem":
            {
                // useitem name: one of your things used (one that needs a target: on what's selected, or yourself with "useitem name | self")
                var up = arg.Split('|');
                var ui = TestItem(up[0].Trim());
                if (ui == null || _net == null) { TestSay("nothing of that name"); break; }
                if (ui.NeedsTarget)
                {
                    uint tg = up.Length > 1 && up[1].Trim() == "self" ? _net.GuidOf(_objects!.Self) : _objects?.Selected is { } ts ? _net.GuidOf(ts) : 0;
                    if (tg == 0) { TestSay($"{ui.Name} needs a target (select one, or | self)"); break; }
                    _net.UseOn(ui, tg); TestSay($"used {ui.Name} on {tg:X8}");
                }
                else { _net.UseItem(ui); TestSay($"used {ui.Name} (useable {ui.Useable:X})"); }
                break;
            }
            case "contracts":
                if (_net == null) break;
                foreach (var c in _net.Contracts.Values) TestSay($"contract {c.Id}: {ContractInfo(c.Id)?.Name ?? "?"} at {ContractInfo(c.Id)?.ContactAt} / {ContractInfo(c.Id)?.QuestAt} stage {c.Stage} done {c.Done} repeats {c.Repeats}");
                if (_net.Contracts.Count == 0) TestSay("no contracts");
                break;
            case "posstats": if (_net != null) TestSay(_net.PosReport); break;
            // srvuse: the selected thing used straight away, from wherever we are (as a plugin does - the server walks us)
            case "srvuse": if (_net != null && _objects?.Selected is { } suse) TestSay(_net.Use(suse) ? $"asked to use {suse.Name} from {suse.Feet.DistanceTo(me):0.0} m" : "couldn't"); break;
            case "los":
            {
                // los name: whether a shot reaches each thing of that name about (walls and objects only - creatures don't count)
                if (_net == null || _player == null) break;
                int n = 0;
                foreach (string d in _net.Described(arg).Take(20))
                {
                    if (!uint.TryParse(d.Split(' ')[0], System.Globalization.NumberStyles.HexNumber, null, out uint g)) continue;
                    var r = _player.ClearShot(g);
                    TestSay($"{d.Split('|')[0].Trim()}: " + (r == null ? "can't tell" : r.Value.clear ? "clear" : "blocked - " + r.Value.what));
                    n++;
                }
                if (n == 0) TestSay("nothing called that about");
                break;
            }
            case "titles":
                if (_net == null) break;
                TestSay($"{_net.Titles.Count} titles, shown {_net.DisplayTitle} ({TitleName(_net.DisplayTitle)}): " + string.Join(", ", _net.Titles.Take(12).Select(t => $"{t} {TitleName(t)}")));
                if (arg.Length > 0 && uint.TryParse(arg, out uint useT)) { _net.SetTitle(useT); TestSay($"asked to show {useT}"); }
                break;
            case "datfind":
            {
                // datfind text: the string tables and name tables of the game's data that hold it (which, under what number)
                if (_dats == null || arg.Length == 0) break;
                int found = 0;
                foreach (uint id in _dats.AllIds<DatReaderWriter.DBObjs.StringTable>())
                {
                    DatReaderWriter.DBObjs.StringTable? t = null;
                    try { t = _dats.Get<DatReaderWriter.DBObjs.StringTable>(id); } catch { }
                    if (t == null) continue;
                    foreach (var kv in t.Strings)
                    {
                        string v = string.Concat(kv.Value.Strings);
                        if (v.Contains(arg, StringComparison.OrdinalIgnoreCase) && found++ < 40) TestSay($"strings {id:X8} [{kv.Key:X8}] of {t.Strings.Count}: {(v.Length > 80 ? v[..80] : v)}");
                    }
                }
                foreach (uint id in _dats.AllIds<DatReaderWriter.DBObjs.EnumMapper>())
                {
                    DatReaderWriter.DBObjs.EnumMapper? t = null;
                    try { t = _dats.Get<DatReaderWriter.DBObjs.EnumMapper>(id); } catch { }
                    if (t == null) continue;
                    foreach (var kv in t.IdToStringMap)
                    {
                        string v = kv.Value?.ToString() ?? "";
                        if (v.Contains(arg, StringComparison.OrdinalIgnoreCase) && found++ < 40) TestSay($"names {id:X8} [{kv.Key}] of {t.IdToStringMap.Count}: {v}");
                    }
                }
                TestSay($"{found} found");
                break;
            }
            case "panel":
            {
                // panel quests 1: a side panel opened on a tab (social, quests)
                var pp = arg.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                int tabNo = pp.Length > 1 && int.TryParse(pp[1], out int tn) ? tn : 0;
                var which = pp.Length > 0 && pp[0].StartsWith("soc") ? _socialPanel : _questPanel;
                which?.Show(tabNo);
                break;
            }
            case "thingbox":
            {
                // where a thing's drawn model really is: its meshes' box in the world (bottom and top), against its feet and the ground
                foreach (var sb in (_objects?.AllSelectables ?? Enumerable.Empty<ObjectStreamer.Selectable>()).Where(x => !x.Gone && x.Name.Contains(arg, StringComparison.OrdinalIgnoreCase)).OrderBy(x => x.Feet.DistanceTo(me)).Take(3))
                {
                    if (sb.Node == null) { TestSay($"{sb.Name}: no node"); continue; }
                    float lo = float.MaxValue, hi = float.MinValue;
                    void Walk(Node n)
                    {
                        if (n is MeshInstance3D mi && mi.Mesh != null)
                        {
                            var bx = mi.GlobalTransform * mi.GetAabb();
                            lo = Math.Min(lo, bx.Position.Y); hi = Math.Max(hi, bx.End.Y);
                            TestSay($"  mesh {mi.Name}: local {mi.Transform.Origin} basis scale {mi.Transform.Basis.Scale}, box y {bx.Position.Y:0.##}..{bx.End.Y:0.##}, own box {mi.GetAabb()}, parent {mi.GetParent()?.GetType().Name}");
                        }
                        foreach (var c in n.GetChildren()) Walk(c);
                    }
                    Walk(sb.Node);
                    TestSay("  " + _objects!.LookNote(sb));
                    TestSay($"{sb.Name}: feet {sb.Feet.Y:0.##}, ground {_objects?.Ground?.Invoke(sb.Feet)?.ToString("0.##") ?? "?"}, drawn {lo:0.##}..{hi:0.##}, node scale {sb.Node.Scale}, server turn {(sb.Tilt is { } tq ? $"w {tq.W:0.###} x {tq.X:0.###} y {tq.Y:0.###} z {tq.Z:0.###}" : "upright")}, yaw {sb.Yaw:0.##}, node basis {sb.Node.Transform.Basis}");
                }
                break;
            }
            case "thing": { int nth = 0; foreach (var d in _net?.Described(arg) ?? Array.Empty<string>()) { TestSay(d); if (++nth >= 6) break; } if (nth == 0) TestSay("no server thing named like that near"); break; }
            case "setup":
            {
                // what a setup is made of (why a thing is or isn't drawn): its parts' surfaces, and the script it starts with
                if (_dats == null) break;
                try
                {
                    uint id = Convert.ToUInt32(arg.Trim(), 16);
                    var su = _dats.Get<DatReaderWriter.DBObjs.Setup>(id);
                    if (su == null) { TestSay("no such setup"); break; }
                    TestSay($"setup {id:X8}: {su.Parts.Count} parts, default script {(uint)su.DefaultScript:X8}, script table {(uint)su.DefaultScriptTable:X8}, flags {su.Flags}");
                    TestSay($"  height {su.Height:0.###} radius {su.Radius:0.###} step up {su.StepUpHeight:0.###} down {su.StepDownHeight:0.###}, sorting sphere {su.SortingSphere?.Origin} r {su.SortingSphere?.Radius:0.##}, selection sphere {su.SelectionSphere?.Origin} r {su.SelectionSphere?.Radius:0.##}");
                    foreach (var (pl, fr) in su.PlacementFrames)
                        TestSay($"  placement {pl} ({(int)pl}): " + string.Join("; ", fr.Frames.Take(4).Select(f => $"at {f.Origin.X:0.###},{f.Origin.Y:0.###},{f.Origin.Z:0.###} turn {f.Orientation.W:0.##},{f.Orientation.X:0.##},{f.Orientation.Y:0.##},{f.Orientation.Z:0.##}")));
                    foreach (var part in su.Parts.Take(6))
                    {
                        var g = _dats.Get<DatReaderWriter.DBObjs.GfxObj>((uint)part);
                        if (g == null) { TestSay($"  part {(uint)part:X8}: not found"); continue; }
                        if (g.VertexArray?.Vertices is { Count: > 0 } vs)
                            TestSay($"  part {(uint)part:X8} spans z {vs.Values.Min(v => v.Origin.Z):0.###}..{vs.Values.Max(v => v.Origin.Z):0.###}, x {vs.Values.Min(v => v.Origin.X):0.###}..{vs.Values.Max(v => v.Origin.X):0.###}");
                        TestSay($"  part {(uint)part:X8}: {g.Polygons.Count} polygons, {g.VertexArray?.Vertices?.Count ?? 0} vertices, surfaces " +
                                string.Join(" ", g.Surfaces.Take(6).Select(sid => { var sf = _dats.Get<DatReaderWriter.DBObjs.Surface>((uint)sid); return sf == null ? $"{(uint)sid:X8}?" : $"{(uint)sid:X8}[{sf.Type} tr {sf.Translucency:0.##} lum {sf.Luminosity:0.##}]"; })));
                    }
                    if ((uint)su.DefaultScript != 0 && _dats.Get<DatReaderWriter.DBObjs.PhysicsScript>((uint)su.DefaultScript) is { } ps)
                    {
                        TestSay("  script: " + string.Join(", ", ps.ScriptData.Take(10).Select(h => $"{h.StartTime:0.##}s {h.Hook?.GetType().Name}")));
                        // each hook's own numbers, and the emitter a particle hook names (what it draws, how big, how long)
                        foreach (var h in ps.ScriptData.Take(10))
                        {
                            if (h.Hook == null) continue;
                            TestSay("    " + h.Hook.GetType().Name + ": " + TestDump(h.Hook));
                            var eid = h.Hook.GetType().GetProperty("EmitterInfoId")?.GetValue(h.Hook) ?? h.Hook.GetType().GetField("EmitterInfoId")?.GetValue(h.Hook);
                            if (eid == null) continue;
                            uint emId = TestId(eid);
                            var em = _dats.Get<DatReaderWriter.DBObjs.ParticleEmitter>(emId);
                            if (em == null) { TestSay($"      emitter {emId:X8}: not found"); continue; }
                            TestSay($"      emitter {emId:X8}: " + TestDump(em));
                            foreach (string f in new[] { "HwGfxObjId", "GfxObjId" })
                            {
                                var gv = em.GetType().GetProperty(f)?.GetValue(em) ?? em.GetType().GetField(f)?.GetValue(em);
                                uint gid = gv == null ? 0 : TestId(gv);
                                if (gid == 0) continue;
                                var g2 = _dats.Get<DatReaderWriter.DBObjs.GfxObj>(gid);
                                TestSay($"      {f} {gid:X8}: " + (g2 == null ? "not found" : $"{g2.Polygons.Count} polygons, surfaces " +
                                    string.Join(" ", g2.Surfaces.Take(6).Select(sid => { var sf = _dats.Get<DatReaderWriter.DBObjs.Surface>((uint)sid); return sf == null ? $"{(uint)sid:X8}?" : $"{(uint)sid:X8}[{sf.Type} tr {sf.Translucency:0.##} lum {sf.Luminosity:0.##} tex {TestDump(sf)}]"; }))));
                            }
                        }
                    }
                }
                catch (Exception ex) { TestSay("setup: " + ex.Message); }
                break;
            }
            case "mods":
            {
                // every enchantment on us as the server keeps it: family, strength, what it changes (type, key) and by how much
                if (_net == null) break;
                foreach (var m in _net.EnchantMods.Values.OrderBy(m => m.Type & 0x1F).ThenBy(m => m.Key).ThenBy(m => m.Category))
                    TestSay($"{_magic?.NameOf(m.Spell) ?? m.Spell.ToString()} (#{m.Spell}): family {m.Category} power {m.Power} type {m.Type:X} key {m.Key} value {m.Value:0.###}");
                break;
            }
            case "ints":
                if (_net?.Character is { } ch) TestSay(string.Join(" ", ch.Ints.OrderBy(k => k.Key).Select(k => $"{k.Key}={k.Value}")));
                if (_combat != null) TestSay($"attributes base+ranks: {string.Join(" ", Enumerable.Range(0, 6).Select(i => $"{_combat.Me.AttributeBase[i]}+{_combat.Me.AttributeRanks[i]}+buff {_combat.Me.AttributeBuff[i]}"))}; vital ranks {string.Join(" ", _combat.Me.VitalRanks)} buffs {string.Join(" ", _combat.Me.VitalBuff)}");
                break;
            case "particles": { int nth = 0; foreach (var d in _particles?.Report(me) ?? Enumerable.Empty<string>()) { if (arg.Length == 0 || d.Contains(arg, StringComparison.OrdinalIgnoreCase)) TestSay(d); nth++; } TestSay($"{nth} emitters near, {_particles?.Particles} particles in all"); foreach (var d in _particles?.Diagnostics ?? new List<string>()) TestSay("said: " + d); break; }
            case "chatui":
            {
                // the chat window's pieces as the layout has them: number, kind, where (on screen), shown or not
                void Walk(Node n, int depth)
                {
                    if (n is ACGodot.UI.UiNode u) { var r = u.GetGlobalRect(); TestSay($"{new string(' ', depth * 2)}{u.Id:X8} type {u.R.Type} at {r.Position.X:0},{r.Position.Y:0} size {r.Size.X:0}x{r.Size.Y:0}{(u.Visible ? "" : " hidden")}{(u.R.States.Count > 0 ? " states " + string.Join("/", u.R.States.Keys) : "")}"); }
                    else if (n is Control c) { var r = c.GetGlobalRect(); TestSay($"{new string(' ', depth * 2)}[{n.GetType().Name}] at {r.Position.X:0},{r.Position.Y:0} size {r.Size.X:0}x{r.Size.Y:0}"); }
                    foreach (var k in n.GetChildren()) Walk(k, depth + 1);
                }
                if (arg == "spell") { if (_spellBar != null) Walk(_spellBar, 0); }
                else if (_chat?.Window != null) Walk(_chat.Window, 0);
                break;
            }
            case "icons":
            {
                // a sheet of the game's icons from a number on (16 across, each twice its size, on grey): which is which
                if (_objects == null) break;
                try
                {
                    var ws = arg.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    uint first = Convert.ToUInt32(ws[0], 16); int count = ws.Length > 1 ? int.Parse(ws[1]) : 64;
                    int rows = (count + 15) / 16;
                    var sheet = Image.CreateEmpty(16 * 68, rows * 68, false, Image.Format.Rgba8);
                    sheet.Fill(new Color(0.35f, 0.35f, 0.35f));
                    for (int i = 0; i < count; i++)
                    {
                        if (_objects.Assets.Icon(first + (uint)i)?.GetImage() is not { } im) continue;
                        if (im.IsCompressed()) im.Decompress();
                        im.Convert(Image.Format.Rgba8);
                        im.Resize(64, 64, Image.Interpolation.Nearest);
                        sheet.BlendRect(im, new Rect2I(0, 0, 64, 64), new Vector2I(i % 16 * 68 + 2, i / 16 * 68 + 2));
                    }
                    string dir = Path.Combine(_testDir!, "out");
                    Directory.CreateDirectory(dir);
                    TestSay(sheet.SavePng(Path.Combine(dir, $"icons_{first:X8}.png")) == Error.Ok ? $"saved icons_{first:X8}.png" : "couldn't save");
                }
                catch (Exception ex) { TestSay("icons: " + ex.Message); }
                break;
            }
            case "chatlog": TestSay(ChatLogCommand(arg)); break;
            case "mymotions": foreach (var d in _net?.MyMotions() ?? Array.Empty<string>()) TestSay(d); break;
            case "missiles": { int nth = 0; foreach (var d in _net?.Missiles() ?? Array.Empty<string>()) { TestSay(d); if (++nth >= 12) break; } if (nth == 0) TestSay("nothing has flown yet"); break; }
            case "imgui": TestSay(ACGodot.UI.ImGuiLayer.State); foreach (var ev in ACGodot.UI.ImGuiLayer.Seen) TestSay("  " + ev); break;
            case "errors": TestSay(ACGodot.UI.ImGuiLayer.Errors == 0 ? "no plugin window errors" : $"{ACGodot.UI.ImGuiLayer.Errors} plugin window errors, the last: {ACGodot.UI.ImGuiLayer.LastError}"); break;
            case "click":
            {
                // click 395 37 [right|double]: a mouse click where a picture from "shot" shows that spot (pictures are half size)
                var cp = arg.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                if (cp.Length < 2 || !float.TryParse(cp[0], out float cx) || !float.TryParse(cp[1], out float cy)) { TestSay("click x y [right|double]"); break; }
                var at = new Vector2(cx * 2, cy * 2);
                var btn = cp.Length > 2 && cp[2].StartsWith("r") ? MouseButton.Right : MouseButton.Left;
                bool dbl = cp.Length > 2 && cp[2].StartsWith("d");
                Input.ParseInputEvent(new InputEventMouseMotion { Position = at, GlobalPosition = at });
                void Press(bool down, bool twice) => Input.ParseInputEvent(new InputEventMouseButton { Position = at, GlobalPosition = at, ButtonIndex = btn, Pressed = down, DoubleClick = twice && down,
                                                                                                          ButtonMask = down ? (btn == MouseButton.Right ? MouseButtonMask.Right : MouseButtonMask.Left) : 0 });
                GetTree().CreateTimer(0.05).Timeout += () => Press(true, false);
                GetTree().CreateTimer(0.13).Timeout += () => Press(false, false);
                if (dbl) { GetTree().CreateTimer(0.20).Timeout += () => Press(true, true); GetTree().CreateTimer(0.28).Timeout += () => Press(false, false); }
                _testWait = 0.5;
                TestSay($"clicked {at.X:0},{at.Y:0}");
                break;
            }
            case "motions":
                if (_objects == null) break;
                foreach (var m in _objects.MotionLog) TestSay(m);
                _objects.MotionLog.Clear();
                if (_objects.Physics is { } ph0) { var (px, py, pz) = World.ToAc(me); foreach (var srv in ph0.ServerReport(new System.Numerics.Vector3(px, py, pz))) TestSay(srv); }
                if (_objects.Physics is { } ph) TestSay($"collision: {ph.ServerThingsIn} of {ph.ServerThings} server things in ({ph.ServerAdds} added, {ph.ServerRemoves} removed) {ph.LastServerError}");
                break;
            case "face":
                // face: the character turned to what's selected
                if (_player != null && _objects?.Selected is { } fs)
                {
                    var fd = fs.Center - _player.Position;
                    _player.TurnToYaw = MathF.Atan2(-fd.X, -fd.Z);
                }
                break;
            case "turn":
                // turn 90: the character turned that many degrees (to see what's beside or behind)
                if (_player != null && float.TryParse(arg, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out float deg))
                    _player.TurnToYaw = _player.BodyYaw - deg * MathF.PI / 180f;
                break;
            case "vendor":
                if (_vendorWin?.Vendor is { } shop)
                {
                    TestSay($"{shop.Name}: sells at {shop.SellRate:0.00}, buys at {shop.BuyRate:0.00}, {shop.ForSale.Count} wares");
                    foreach (var i in shop.ForSale) TestSay($"  {i.Name} (wcid {i.Wcid}) value {i.Value}");
                }
                else TestSay("no vendor open");
                break;
            case "buy": case "sell":
            {
                // buy name | 5      sell name
                var parts = arg.Split('|');
                string what = parts[0].Trim();
                int many = parts.Length > 1 && int.TryParse(parts[1].Trim(), out int pm) ? pm : 1;
                if (_vendorWin?.Vendor is not { } at || _net == null) { TestSay("no vendor open"); break; }
                var thing = cmd == "buy" ? at.ForSale.FirstOrDefault(i => i.Name.Contains(what, StringComparison.OrdinalIgnoreCase)) : TestItem(what);
                if (thing == null) { TestSay("nothing of that name"); break; }
                var list = new List<(ACGodot.Combat.Item, int)> { (thing, cmd == "buy" ? many : Math.Max(1, thing.Stack)) };
                if (cmd == "buy") _net.Buy(at.Guid, list); else _net.Sell(at.Guid, list);
                TestSay($"{cmd} {list[0].Item2} x {thing.Name}");
                break;
            }
            case "friends":
                if (_net == null) break;
                foreach (var f in _net.Friends) TestSay($"friend {f.Name} ({(f.Online ? "online" : "offline")})");
                TestSay(_net.FellowshipName.Length == 0 ? "no fellowship" : $"fellowship {_net.FellowshipName}: " + string.Join(", ", _net.Fellows.Select(f => $"{f.Name} [{f.Level}]")));
                break;
            case "friend": _net?.AddFriend(arg); break;
            case "fellowship": if (arg.Equals("quit", StringComparison.OrdinalIgnoreCase)) _net?.QuitFellowship(false); else _net?.CreateFellowship(arg, true); break;
            case "move":
            {
                // move item name | pack name or main
                var parts = arg.Split('|');
                var it = TestItem(parts[0].Trim());
                var inv = _combat?.Inv;
                if (it == null || inv == null || _net == null) { TestSay("no item of yours named that"); break; }
                string to = parts.Length > 1 ? parts[1].Trim() : "main";
                uint pack = to.Equals("main", StringComparison.OrdinalIgnoreCase) ? 0 : inv.SidePacks.FirstOrDefault(p => p.Name.Contains(to, StringComparison.OrdinalIgnoreCase))?.Guid ?? 0;
                _net.Move(it, pack, parts.Length > 2 && int.TryParse(parts[2].Trim(), out int mvAt) ? mvAt : 0);
                TestSay($"moving {it.Name} to {(pack == 0 ? "the main pack" : to)}");
                break;
            }
            case "teleto":
            {
                // an admin's teleport (the server's @teleloc) to just in front of a thing of the server's - there's no
                // finding a way round walls from here
                var s = arg.Length == 0 ? _objects?.Selected : _objects?.AllSelectables.Where(s => !s.Gone && s.Name.Contains(arg, StringComparison.OrdinalIgnoreCase)).OrderBy(s => s.Feet.DistanceTo(me)).FirstOrDefault();
                if (s == null || _net?.WhereIs(s) is not { } spot) { TestSay("nothing of the server's by that name"); break; }
                float dist = s.Radius + 1.2f;
                var at = spot.local + new System.Numerics.Vector3(-MathF.Sin(spot.yaw), MathF.Cos(spot.yaw), 0) * dist;
                string line2 = FormattableString.Invariant($"@teleloc 0x{spot.cell:X8} [{at.X:0.000} {at.Y:0.000} {at.Z + 0.05f:0.000}] 1 0 0 0");
                _objects!.Select(s);
                TestSay(line2);
                OnChat(line2);
                break;
            }
            case "place":
            {
                // place item | 3     (to that place in the main pack, as a drag to that slot does)
                var parts = arg.Split('|');
                var it = TestItem(parts[0].Trim());
                var inv = _combat?.Inv;
                if (it == null || inv == null || !inv.Pack.Contains(it)) { TestSay("no item in your pack named that"); break; }
                int slot = parts.Length > 1 && int.TryParse(parts[1].Trim(), out int ps) ? ps : 0;
                var open = inv.Pack.Where(i => i.Holder == it.Holder && i != it).ToList();
                inv.Place(it, slot >= 0 && slot < open.Count ? inv.Pack.IndexOf(open[slot]) : inv.Pack.Count);
                _invPanel?.Refresh();
                TestSay($"placed {it.Name} at {slot}");
                break;
            }
            case "split":
            {
                // split item | 5     (five off the stack, to the top of the main pack)
                var parts = arg.Split('|');
                var it = TestItem(parts[0].Trim());
                int many = parts.Length > 1 && int.TryParse(parts[1].Trim(), out int sm) ? sm : 1;
                if (it == null || _net == null || many < 1 || many >= it.Stack) { TestSay("no stack of yours named that with more than that many"); break; }
                _net.Split(it, 0, 0, many);
                TestSay($"splitting {many} off {it.Stack} {it.Name}");
                break;
            }
            case "merge":
            {
                // merge item     (the smallest stack of it onto the biggest)
                var inv = _combat?.Inv;
                var stacks = inv?.Pack.Where(i => i.Guid != 0 && i.Name.Contains(arg, StringComparison.OrdinalIgnoreCase)).OrderBy(i => i.Stack).ToList();
                if (inv == null || stacks == null || stacks.Count < 2) { TestSay("fewer than two stacks of that"); break; }
                TestSay($"merging {stacks[0].Stack} onto {stacks[^1].Stack} {stacks[0].Name}");
                inv.StackOnto(stacks[0], stacks[^1]);
                break;
            }
            case "want":
            {
                // want component name | 40     (the number wanted on the spellbook's Components tab)
                var parts = arg.Split('|');
                var it = TestItem(parts[0].Trim());
                int many = parts.Length > 1 && int.TryParse(parts[1].Trim(), out int wm) ? wm : 0;
                if (it == null) { TestSay("no item of yours named that"); break; }
                ACGodot.UI.SpellbookPanel.SetWanted(it.Wcid, many);
                TestSay($"want {many} {it.Name} (wcid {it.Wcid})");
                break;
            }
            case "buylist":
                if (_vendorWin?.Vendor == null) { TestSay("no vendor open"); break; }
                foreach (var (item, amount) in _vendorWin.BuyList) TestSay($"{amount} x {item.Name}");
                if (_vendorWin.BuyList.Count == 0) TestSay("the buy list is empty");
                break;
            case "buynow": _vendorWin?.BuyNow(); break;
            case "exit": TestFinish(); GetTree().Quit(); break;
            // out of the world properly, closed at the character screen (the phone's Log out & close)
            case "logoutexit": TestSay("logging out, then closing"); TestFinish(); if (_net != null) _net.LogOutThenQuit(() => GetTree().Quit()); else GetTree().Quit(); break;
            default: TestSay("unknown command"); break;
        }
    }

    /// <summary>
    /// The character creation screen opened for a look at it (test bridge "chargen [page 0-5 | off]"), wherever the game is
    /// - in the world, Finish just says it can't (the server only makes characters at the character screen).
    /// </summary>
    private string CharGenTest(string arg)
    {
        if (arg == "off") { _charGen?.Close(); return "character creation closed"; }
        if (_charGen == null)
        {
            if (_dats == null) return "no data files";
            var layer = new CanvasLayer { Name = "CharGenTestLayer", Layer = 96 };
            AddChild(layer);
            var black = new ColorRect { Color = Colors.Black, MouseFilter = Control.MouseFilterEnum.Ignore };
            black.SetAnchorsPreset(Control.LayoutPreset.FullRect);
            layer.AddChild(black);
            _charGen = new ACGodot.UI.CharGen { Name = "CharGen", Dats = _dats, Looks = _creatureAssets, Create = c => _net?.CreateCharacter(c) == true };
            _charGen.Exit = () => layer.QueueFree();
            _charGen.VisibilityChanged += () => black.Visible = _charGen?.Visible == true;
            layer.AddChild(_charGen);
        }
        if (!_charGen.Visible && !_charGen.Open()) return "couldn't open it (no interface data?)";
        if (int.TryParse(arg, out int page)) _charGen.TestPage(page);
        return "character creation open" + (arg.Length > 0 ? " on page " + arg : "");
    }
}
