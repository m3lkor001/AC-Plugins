namespace ACGodot;

/// <summary>Which build of ACGodot this is: build-all.py adds one to Number and sets Time for each build.</summary>
public static class BuildInfo
{
    public const int Number = 57;

    public const string Time = "Nov 27 22:04";

    public static string Label => "b" + Number + " (" + Time + ")";
}
