namespace ACGodot;

/// <summary>Which build of ACGodot this is: build-all.py adds one to Number and sets Time for each build.</summary>
public static class BuildInfo
{
    public const int Number = 11;

    public const string Time = "Nov 25 11:40";

    public static string Label => "b" + Number + " (" + Time + ")";
}
