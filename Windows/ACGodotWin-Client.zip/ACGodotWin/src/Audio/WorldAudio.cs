using System;
using System.Collections.Generic;
using AcDream.Core.Audio;
using DatReaderWriter.DBObjs;
using DatReaderWriter.Types;
using Godot;
using DRWSound = DatReaderWriter.Enums.Sound;
using NVector3 = System.Numerics.Vector3;

namespace ACGodot.Audio;

/// <summary>
/// The game's sounds, played as the client plays them (OpenAC's ports of its mixer and ambient scheduler):
/// - sounds an animation's hooks make (footsteps, swings, creature noises) - a bare wave, or a slot in the thing's
///   sound table (one of the slot's variants, by chance);
/// - the landscape's ambient sounds (wind, birds, insects... the region's sounds for the terrain around the camera);
/// - sounds asked for by name (a door's open and close).
/// A sound's loudness is fixed when it starts, from its distance (full within 5 m, falling off with the square of
/// the distance beyond), and Godot places it left or right. At most 16 sounds at once, as the client; a new one
/// takes the place of the quietest playing one.
/// </summary>
public partial class WorldAudio : Node3D
{
    private const int Voices = 16, AmbientVoices = 6;
    public float EffectVolume = 1f, AmbientVolume = 0.7f;

    private Dats _dats = null!;
    private readonly Dictionary<uint, AudioStream?> _streams = new();
    private readonly Dictionary<uint, SoundTable?> _tables = new();
    private readonly List<(AudioStreamPlayer3D p, float prio)> _voices = new();
    private readonly List<AudioStreamPlayer3D> _ambient = new();
    private AudioStreamPlayer _flat = null!;
    private readonly SoundRandom _rng = new();
    private readonly Random _pick = new();

    // ambient
    private Region? _region;
    private readonly AmbientSoundScheduler _scheduler;
    private readonly AmbientSoundGatherer _gatherer;
    private readonly List<AmbientSoundFiring> _firings = new();
    private uint _ambientCell;
    private double _clock;

    public WorldAudio()
    {
        _scheduler = new AmbientSoundScheduler(_rng);
        _gatherer = new AmbientSoundGatherer(_scheduler);
    }

    public void Setup(Dats dats)
    {
        _dats = dats;
        for (int i = 0; i < Voices; i++)
        {
            var p = new AudioStreamPlayer3D { AttenuationModel = AudioStreamPlayer3D.AttenuationModelEnum.Disabled, MaxPolyphony = 1 };
            AddChild(p);
            _voices.Add((p, 0f));
        }
        for (int i = 0; i < AmbientVoices; i++)
        {
            var p = new AudioStreamPlayer3D { AttenuationModel = AudioStreamPlayer3D.AttenuationModelEnum.Disabled, MaxPolyphony = 1 };
            AddChild(p);
            _ambient.Add(p);
        }
        _flat = new AudioStreamPlayer { MaxPolyphony = 4 };
        AddChild(_flat);
        _region = dats.Get<Region>(0x13000000u);
    }

    // ── waves → Godot streams ──

    /// <summary>A wave from the game data as a Godot stream: PCM (8 or 16 bit) or MP3; null if neither.</summary>
    private AudioStream? Stream(uint waveId)
    {
        if (_streams.TryGetValue(waveId, out var s)) return s;
        s = null;
        try
        {
            var wave = _dats.Get<Wave>(waveId);
            if (wave != null && wave.Header.Length >= 14)
            {
                var fmt = WaveDecoder.PeekFormat(wave.Header);
                if (fmt == WaveDecoder.WaveFormatTag.Mp3)
                    s = new AudioStreamMP3 { Data = wave.Data };
                else if (WaveDecoder.Decode(wave.Header, wave.Data) is { } pcm)
                {
                    byte[] data = pcm.PcmBytes;
                    if (pcm.BitsPerSample == 8)
                    {
                        // a wave file's 8-bit samples are unsigned; Godot's are signed
                        data = (byte[])data.Clone();
                        for (int i = 0; i < data.Length; i++) data[i] = (byte)(data[i] - 128);
                    }
                    s = new AudioStreamWav
                    {
                        Format = pcm.BitsPerSample == 8 ? AudioStreamWav.FormatEnum.Format8Bits : AudioStreamWav.FormatEnum.Format16Bits,
                        Stereo = pcm.ChannelCount == 2,
                        MixRate = pcm.SampleRate,
                        Data = data,
                    };
                }
            }
        }
        catch (Exception ex) { GD.PushWarning($"wave 0x{waveId:X8}: {ex.Message}"); s = null; }
        _streams[waveId] = s;
        return s;
    }

    public SoundTable? Table(uint id)
    {
        if (id == 0) return null;
        if (_tables.TryGetValue(id, out var t)) return t;
        try { t = _dats.Get<SoundTable>(id); } catch { t = null; }
        return _tables[id] = t;
    }

    private Vector3 Listener => GetViewport()?.GetCamera3D()?.GlobalPosition ?? Vector3.Zero;

    // ── playing ──

    /// <summary>Plays a wave at a place (Godot), at a volume (0-1) and priority, as the client mixes it.</summary>
    public bool Play(uint waveId, Vector3 at, float volume, float priority = 0f)
    {
        if (waveId == 0 || Stream(waveId) is not { } stream) return false;
        float d = Listener.DistanceTo(at);
        if (!RetailSoundMixer.TryGetAttenuation(d, volume, EffectVolume, out int db)) return false;
        // a free voice, or the one playing the least important sound
        int pick = -1; float worst = float.MaxValue;
        for (int i = 0; i < _voices.Count; i++)
        {
            var (p, prio) = _voices[i];
            if (!p.Playing) { pick = i; break; }
            float score = prio + p.VolumeDb * 0.01f;
            if (score < worst) { worst = score; pick = i; }
        }
        if (pick < 0) return false;
        var v = _voices[pick].p;
        v.Stop();
        v.Stream = stream;
        v.GlobalPosition = at;
        v.VolumeDb = db;
        v.Play();
        _voices[pick] = (v, priority);
        return true;
    }

    /// <summary>A sound from a thing's sound table (one of the slot's variants, if its chance comes up).</summary>
    public bool PlayFromTable(uint tableId, DRWSound sound, Vector3 at, float volumeScale = 1f)
    {
        if (Table(tableId) is not { } table) return false;
        var entry = SoundCookbook.Select(table, sound, _rng);
        return entry != null && Play((uint)entry.Id, at, entry.Volume * volumeScale, entry.Priority);
    }

    /// <summary>The sounds in a thing's table (for trying them out).</summary>
    public IReadOnlyList<DRWSound> SoundsIn(uint tableId)
    {
        var list = new List<DRWSound>();
        if (Table(tableId) is { } table) foreach (var kv in table.Sounds) if (kv.Value.Entries.Count > 0) list.Add(kv.Key);
        return list;
    }

    /// <summary>Plays one of a table's sounds, whichever variant, ignoring its chance (to hear what it has).</summary>
    public bool PlayAny(uint tableId, DRWSound sound, Vector3 at)
    {
        if (Table(tableId) is not { } table || !table.Sounds.TryGetValue(sound, out var data) || data.Entries.Count == 0) return false;
        var entry = data.Entries[_pick.Next(data.Entries.Count)];
        return Play((uint)entry.Id, at, Math.Max(entry.Volume, 0.5f), entry.Priority);
    }

    /// <summary>The sound hooks an animation fired (footsteps and the like), for a thing with a sound table, at a place.</summary>
    /// <param name="trace">Print what became of each sound (for the log).</param>
    public void Hooks(uint tableId, Vector3 at, IReadOnlyList<AnimationHook> hooks, bool trace = false)
    {
        foreach (var hook in hooks)
        {
            switch (hook)
            {
                case SoundHook s:
                {
                    bool ok = Play((uint)s.Id, at, 1f);
                    if (trace) GD.Print($"sound hook: wave 0x{(uint)s.Id:X8} -> {(ok ? "played" : "not played")}");
                    break;
                }
                case SoundTableHook st:
                {
                    if (!trace) { PlayFromTable(tableId, st.SoundType, at); break; }
                    string what;
                    if (Table(tableId) is not { } table) what = $"no sound table 0x{tableId:X8}";
                    else if (!table.Sounds.TryGetValue(st.SoundType, out var data) || data.Entries.Count == 0) what = "the table has no such sound";
                    else
                    {
                        var entry = SoundCookbook.Select(table, st.SoundType, _rng);
                        if (entry == null) what = "chance didn't come up";
                        else
                        {
                            float d = Listener.DistanceTo(at);
                            RetailSoundMixer.TryGetAttenuation(d, entry.Volume, EffectVolume, out int db);
                            bool ok = Stream((uint)entry.Id) != null && Play((uint)entry.Id, at, entry.Volume, entry.Priority);
                            what = $"wave 0x{(uint)entry.Id:X8} vol {entry.Volume:0.##} at {d:0.0} m ({db} dB) -> {(ok ? "played" : "not played")}";
                        }
                    }
                    GD.Print($"sound hook: {st.SoundType} -> {what}");
                    break;
                }
                case SoundTweakedHook tw:
                {
                    bool ok = TweakedSoundHooks.TryRoll(tw, _rng, out uint wave, out float vol) && Play(wave, at, vol, TweakedSoundHooks.AuthoredPriority(tw));
                    if (trace) GD.Print($"sound hook: tweaked 0x{(uint)tw.SoundId:X8} -> {(ok ? "played" : "not played")}");
                    break;
                }
            }
        }
    }

    /// <summary>What a table has for a sound (for the log): each variant's wave, volume and chance.</summary>
    public string Describe(uint tableId, DRWSound sound)
    {
        if (Table(tableId) is not { } table) return $"no sound table 0x{tableId:X8}";
        if (!table.Sounds.TryGetValue(sound, out var data) || data.Entries.Count == 0) return $"{sound}: none";
        var parts = new List<string>();
        foreach (var e in data.Entries) parts.Add($"wave 0x{(uint)e.Id:X8} vol {e.Volume:0.##} chance {e.Probability:0.##}{(Stream((uint)e.Id) == null ? " (can't decode)" : "")}");
        return $"{sound}: {string.Join("; ", parts)}";
    }

    // ── the landscape's ambient sounds ──

    /// <summary>
    /// Each frame: where the listener is (AC world) and whether it's indoors (a building's rooms or a dungeon -
    /// no landscape sounds there). The ambient sounds around it are worked out again when it moves to another
    /// landscape cell.
    /// </summary>
    public void Update(double delta, NVector3 acWorld, bool indoors)
    {
        _clock += delta;
        if (_region == null) return;
        int lx = (int)MathF.Floor(acWorld.X / 192f), ly = (int)MathF.Floor(acWorld.Y / 192f);
        if (lx < 0 || ly < 0 || lx > 254 || ly > 254) return;
        float localX = acWorld.X - lx * 192f, localY = acWorld.Y - ly * 192f;
        uint lb = ((uint)lx << 24) | ((uint)ly << 16);
        uint cell = indoors ? 0xFFFFFFFFu : lb | (uint)((int)(localX / 24f) * 8 + (int)(localY / 24f) + 1);
        if (cell != _ambientCell)
        {
            _ambientCell = cell;
            if (indoors) _scheduler.Clear();
            else
            {
                try
                {
                    _gatherer.Rebuild(_region, lb | 0xFFFFu, new NVector3(localX, localY, acWorld.Z), TerrainWords, _clock);
                }
                catch (Exception ex) { GD.PushWarning("ambient: " + ex.Message); }
            }
        }
        _firings.Clear();
        _scheduler.Tick(_clock, _firings, acWorld);
        foreach (var f in _firings) PlayAmbient(f);
    }

    private ushort[]? TerrainWords(uint landblockId)
    {
        var block = _dats.Cell<LandBlock>(landblockId);
        if (block == null) return null;
        var words = new ushort[block.Terrain.Length];
        for (int i = 0; i < words.Length; i++) words[i] = (ushort)block.Terrain[i];
        return words;
    }

    private void PlayAmbient(in AmbientSoundFiring f)
    {
        if (Table(f.Instance.SoundTableDid) is not { } table) return;
        var entry = SoundCookbook.Select(table, (DRWSound)(uint)f.Instance.Descriptor.Sound, _rng);
        if (entry == null || Stream((uint)entry.Id) is not { } stream) return;
        float volume = f.Volume * AmbientVolume;
        if (f.Position is { } p)
        {
            var at = World.ToGodot(p.X, p.Y, p.Z);
            if (!RetailSoundMixer.TryGetAttenuation(Listener.DistanceTo(at), volume, 1f, out int db)) return;
            AudioStreamPlayer3D? v = null;
            foreach (var a in _ambient) if (!a.Playing) { v = a; break; }
            if (v == null) return;
            v.Stream = stream; v.GlobalPosition = at; v.VolumeDb = db; v.Play();
        }
        else
        {
            if (!RetailSoundMixer.TryGetAttenuation(0f, volume, 1f, out int db)) return;
            _flat.Stream = stream; _flat.VolumeDb = db; _flat.Play();
        }
    }
}
