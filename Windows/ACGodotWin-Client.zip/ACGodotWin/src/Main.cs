using System.Collections.Generic;
using System;
using System.IO;
using System.Linq;
using ACGodot.Objects;
using ACGodot.Terrain;
using Godot;

namespace ACGodot;

/// <summary>
/// The world viewer (milestone 1): opens your AC data files and lets you fly around Dereth's landscape.
/// F1 Holtburg, F2 Yaraq, F3 Shoushi, F4 Arwic; F5 drops you to the ground. Settings in user://acgodot.cfg.
/// </summary>
public partial class Main : Node3D
{
    /// <summary>Where the AC data files usually are: the Wine install here on Linux; on Windows the first of the usual
    /// install folders that has them (C:\Turbine\Asheron's Call when none does).</summary>
    private static string DefaultDatDir
    {
        get
        {
            if (!OperatingSystem.IsWindows()) return System.IO.Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.UserProfile), "Games/ac/drive_c/Turbine/Asheron's Call");
            string pf86 = System.Environment.GetFolderPath(System.Environment.SpecialFolder.ProgramFilesX86);
            foreach (string d in new[] { @"C:\Turbine\Asheron's Call", System.IO.Path.Combine(pf86, "Turbine", "Asheron's Call"),
                                         @"C:\Games\Asheron's Call", @"C:\Games\Turbine\Asheron's Call", @"C:\AC", @"D:\Turbine\Asheron's Call" })
                if (System.IO.File.Exists(System.IO.Path.Combine(d, "client_portal.dat"))) return d;
            return @"C:\Turbine\Asheron's Call";
        }
    }

    private Dats? _dats;
    private TerrainStreamer? _terrain;
    private FarTerrain? _far;
    private ACGodot.Objects.FarScenery? _farScenery;
    private ObjectStreamer? _objects;
    private Godot.Environment _env = null!;
    private DirectionalLight3D _sunLight = null!;
    private ACGodot.Sky.SkyController? _sky;
    private ACGodot.Creatures.Player? _player;
    private readonly List<ACGodot.Combat.Item> _lootQueue = new();   // taken from a corpse while bending down: waiting their turn
    private double _lootBusyUntil;

    /// <summary>The next thing waiting to be taken from the corpse, once you're back up (the queue empties if the corpse shuts).</summary>
    private void TakeQueuedLoot()
    {
        if (_lootQueue.Count == 0 || _lootWin == null) return;
        if (!_lootWin.Visible || _lootWin.Contents == null) { _lootQueue.Clear(); return; }
        if (Time.GetTicksMsec() / 1000.0 < _lootBusyUntil) return;
        var it = _lootQueue[0];
        _lootQueue.RemoveAt(0);
        if (_lootWin.Contents.Contains(it)) _lootWin.TakeIt(it);
    }
    private ACGodot.Audio.WorldAudio? _audio;
    private ACGodot.Effects.ParticleWorld? _particles;
    private ACGodot.Combat.CombatSystem? _combat;
    private ACGodot.Combat.CombatHud _combatHud = null!;
    private Vector3 _start;   // where you come back to life
    private CanvasLayer _ui = null!;
    private ACGodot.UI.StatusLine? _statusLine;
    private int _lastMode = -1;
    /// <summary>Says something on the line at the top of the screen (what you're doing, or why you can't).</summary>
    public void Status(string text) { TestStatus(text); _statusLine?.Show(text); }
    public void Status(string text, string kind) { TestStatus(text); _statusLine?.Show(text, kind); }
    /// <summary>An item chosen (in a pack, on the character, in a corpse, at a vendor, on the shortcut bar): the one thing selected - whatever was chosen in the world no longer is.</summary>
    private void PickItem(ACGodot.Combat.Item? it)
    {
        // (choosing a target for something used: the item clicked is it - even the one already picked, which changed nothing
        // and left the use waiting until it gave up)
        if (it != null && _useSource is { } src && it != src && it.Guid != 0 && _net != null) { _useSource = null; TargetCursor(false); _net.UseOn(src, it.Guid); }
        _selItem = it; if (it != null && _objects?.Selected != null) _objects.Select(null);
    }
    // the cursor while choosing what something's used on: a target's cross, as the game's own
    // (drawn as the arrow's own image: a shape asked for alone was set straight back by the panels and plugin windows)
    private bool _targetCursor;
    private static ImageTexture? _targetTex;
    // the rings while choosing a target: drawn here over everything, following the mouse, with the system's own pointer
    // hidden meanwhile. (Setting the system cursor's picture worked one way only: on this desktop it never came back to
    // the arrow, whatever was tried.)
    private CanvasLayer? _ringsLayer;
    private TextureRect? _rings;
    private void CursorFixTick()
    {
        if (!_targetCursor || _rings == null) return;
        _rings.Position = GetViewport().GetMousePosition() - new Vector2(16, 16);
        // (mouse-look ended, or something else showed the pointer: hidden again while the rings are up)
        if (Input.MouseMode == Input.MouseModeEnum.Visible) Input.MouseMode = Input.MouseModeEnum.Hidden;
    }

    private void TargetCursor(bool on)
    {
        if (on == _targetCursor) return;
        _targetCursor = on;
        if (!on)
        {
            if (_rings != null) _rings.Visible = false;
            if (Input.MouseMode == Input.MouseModeEnum.Hidden) Input.MouseMode = Input.MouseModeEnum.Visible;
            return;
        }
        if (_targetTex == null)
        {
            // three rings, gold edged in black, the middle the click's point
            const int N = 32; var img = Image.CreateEmpty(N, N, false, Image.Format.Rgba8);
            var gold = new Color(1f, 0.85f, 0.3f); var edge = new Color(0f, 0f, 0f, 0.85f);
            float c = (N - 1) / 2f;
            for (int y = 0; y < N; y++)
                for (int x = 0; x < N; x++)
                {
                    float d = MathF.Sqrt((x - c) * (x - c) + (y - c) * (y - c));
                    Color px = new(0, 0, 0, 0);
                    foreach (float r in new[] { 14f, 9f, 4f })
                    {
                        float off = MathF.Abs(d - r);
                        if (off < 0.8f) { px = gold; break; }
                        if (off < 1.6f) px = edge;
                    }
                    if (d < 1.2f) px = gold;
                    img.SetPixel(x, y, px);
                }
            _targetTex = ImageTexture.CreateFromImage(img);
        }
        if (_rings == null)
        {
            _ringsLayer = new CanvasLayer { Layer = 128, Name = "TargetRings" };
            AddChild(_ringsLayer);
            _rings = new TextureRect { Texture = _targetTex, MouseFilter = Control.MouseFilterEnum.Ignore, Size = new Vector2(32, 32) };
            _ringsLayer.AddChild(_rings);
        }
        _rings.Visible = true;
        _rings.Position = GetViewport().GetMousePosition() - new Vector2(16, 16);
        if (Input.MouseMode == Input.MouseModeEnum.Visible) Input.MouseMode = Input.MouseModeEnum.Hidden;
    }
    private double _healthAskedAt;
    // a corpse to be opened once we've turned to face it
    private ACGodot.Objects.ObjectStreamer.Selectable? _useAfterTurn;
    private bool _useAfterTurnQuiet;
    private double _useTurnAt;
    private float _useTurnYaw;
    private bool _useTurned;
    // the open corpse to be shut once the pickup under way is done
    private ACGodot.Objects.ObjectStreamer.Selectable? _shutAfterPickup;
    private bool _closeAfterPickup;
    private void ShutOncePickedUp()
    {
        if (_shutAfterPickup == null && !_closeAfterPickup) return;
        if (_player?.Bending == true) return;
        var corpse = _shutAfterPickup; _shutAfterPickup = null;
        bool close = _closeAfterPickup; _closeAfterPickup = false;
        if (_net == null || _net.OpenContainer == 0) return;
        if (corpse != null && _objects != null && !corpse.Gone && _net.GuidOf(corpse) == _net.OpenContainer)
        {
            // (used again, as was asked: on it, whatever's selected by now)
            _useTurned = true;
            UseOn(corpse, true);
        }
        else if (close) _net.CloseContainer();
    }
    private void UseOnceFacing()
    {
        if (_useAfterTurn is not { } corpse) return;
        if (_objects == null || _player == null || corpse.Gone || (!_useAfterTurnQuiet && _objects.Selected != corpse)) { _useAfterTurn = null; return; }
        double waited = Time.GetTicksMsec() / 1000.0 - _useTurnAt;
        bool facing = MathF.Abs(Mathf.Wrap(_useTurnYaw - _player.Heading, -MathF.PI, MathF.PI)) <= 0.15f;
        if (!facing && waited < 2.0) return;
        _useAfterTurn = null;
        _useTurned = true;   // (turned - or as near as it got: opened now, not turned for again)
        UseOn(corpse, _useAfterTurnQuiet);
    }
    private ACGodot.Combat.CharacterWindow? _charWin;
    private ACGodot.Combat.PackWindow? _packWin;
    private ACGodot.Combat.LootWindow? _lootWin;
    private uint _lootBoxGuid;
    private float _lootOpenDist;
    private bool _examFromLoot;
    private ACGodot.UI.RetailHud? _retail;
    private ACGodot.UI.ChatWindow? _chat;
    private readonly List<ACGodot.UI.ChatWindow> _chats = new();
    private ACGodot.UI.OptionsWindow? _options;
    private ACGodot.UI.ShortcutBar? _bar;
    private ACGodot.Magic.MagicSystem? _magic;
    private ACGodot.Magic.SpellbookWindow? _spellbook;
    private ACGodot.Plugins.PluginHost? _plugins;
    private ACGodot.Net.NetSettings _netCfg = new();
    private ACGodot.Net.NetGame? _net;
    private ACGodot.UI.CharacterSelect? _characterSelect;
    private ACGodot.UI.CharGen? _charGen;
    private ACGodot.UI.CharSelect? _charSelect;
    private ACGodot.Creatures.CreatureAssets? _creatureAssets;
    private ACGodot.UI.VendorWindow? _vendorWin;
    private bool _bookRefresh;   // the spellbook changed (spells learned): shown afresh once, not for each of many
    private string _fellowName = "", _friendName = "";
    private ACGodot.UI.NavArrow? _arrow;
    private ACGodot.Map.MapWindow? _map;
    private ACGodot.UI.ExaminePanel? _examine;
    private ACGodot.UI.InventoryPanel? _invPanel;
    private ACGodot.UI.CharacterPanel? _charPanel;
    private ACGodot.UI.SpellbookPanel? _bookPanel;
    private ACGodot.UI.TextPanel? _infoPanel;
    private ACGodot.UI.TabbedPanel? _socialPanel, _questPanel, _mapPanel, _optionsPanel;
    private ACGodot.UI.ControlBar? _controlBar;
    private ACGodot.UI.StatusIcons? _statusIcons;
    private ACGodot.UI.SpellsInEffectPanel? _effectsPanel;
    private ACGodot.UI.TextPanel? _vitaePanel, _chessPanel;
    // portals: where ACGodot's own ones go (by their wcid), and the tunnel going through
    private readonly Dictionary<int, (uint cell, string name)> _portalTo = new();
    private ACGodot.UI.PortalSpace? _portalSpace;
    private const int TestPortalWcid = 990001;
    private ACGodot.UI.SpellBar? _spellBar;
    private ACGodot.UI.PluginBar? _pluginBar;
    private ACGodot.Combat.Item? _selItem;                         // an item clicked in a pack or corpse (the control bar shows it)
    private ACGodot.Objects.ObjectStreamer.Selectable? _lastSel;   // the world selection last seen (a new one replaces the item)
    private object? _lastChosen;                                     // what was chosen last (item or thing), for the ID panel
    private TerrainTextures? _tex;

    /// <summary>A line into every chat window that shows its kind.</summary>
    // logging in to a server: a plain screen over the world until the server has put the character in it (the world on
    // its own, with its stand-in character, isn't where anyone is)
    private ACGodot.UI.ConfirmWindow? _confirm;
    private ACGodot.UI.KeyboardWindow? _keysWin;
    private ACGodot.UI.SalvageWindow? _salvageWin;
    private CanvasLayer? _connectCover;
    private Label? _connectNote;
    private void ShowConnecting(string text)
    {
        if (_connectCover == null)
        {
            _connectCover = new CanvasLayer { Name = "Connecting", Layer = 40 };
            var black = new ColorRect { Color = Colors.Black, MouseFilter = Control.MouseFilterEnum.Stop };
            black.SetAnchorsPreset(Control.LayoutPreset.FullRect);
            _connectCover.AddChild(black);
            var box = new VBoxContainer { Alignment = BoxContainer.AlignmentMode.Center };
            box.SetAnchorsPreset(Control.LayoutPreset.FullRect);
            box.AddThemeConstantOverride("separation", 18);
            _connectNote = new Label { HorizontalAlignment = HorizontalAlignment.Center, AutowrapMode = TextServer.AutowrapMode.WordSmart };
            _connectNote.AddThemeColorOverride("font_color", ACGodot.UI.RetailTheme.Gold);
            _connectNote.AddThemeFontSizeOverride("font_size", 20);
            box.AddChild(_connectNote);
            var exit = new Button { Text = "Exit the game", FocusMode = Control.FocusModeEnum.None, SizeFlagsHorizontal = Control.SizeFlags.ShrinkCenter };
            exit.Pressed += () => GetTree().Quit();
            box.AddChild(exit);
            black.AddChild(box);
            AddChild(_connectCover);
        }
        _connectNote!.Text = text;
        _connectCover.Visible = true;
        if (_player != null) _player.Frozen = true;
    }
    private void HideConnecting()
    {
        if (_connectCover?.Visible != true) return;
        _connectCover.Visible = false;
        if (_player != null && _characterSelect?.Visible != true && _charSelect?.Visible != true) _player.Frozen = false;
    }

    // ── a chat log for a while: everything said (and what plugins hide) into logs/<Character>/chatlog.txt, for working out
    // what the server says. /chatlog [minutes] (5 if not said), /chatlog off, /chatlog clear - and the same from the test
    // bridge. It turns itself off when the time's up. ──
    private DateTime _chatLogUntil = DateTime.MinValue;
    private string ChatLogPath => System.IO.Path.Combine(_net?.CharLogDir() ?? System.IO.Path.GetTempPath(), "chatlog.txt");
    private string ChatLogCommand(string arg)
    {
        arg = arg.Trim().ToLowerInvariant();
        if (arg == "off" || arg == "stop") { _chatLogUntil = DateTime.MinValue; return "Chat log off (" + ChatLogPath + ")."; }
        if (arg == "clear" || arg == "empty")
        {
            try { System.IO.File.WriteAllText(ChatLogPath, ""); return "Chat log emptied."; } catch (Exception ex) { return "Couldn't empty the chat log: " + ex.Message; }
        }
        if (arg == "" || arg == "on" || double.TryParse(arg, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out _))
        {
            double min = double.TryParse(arg, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double m) ? Math.Clamp(m, 0.5, 120) : 5;
            _chatLogUntil = DateTime.Now.AddMinutes(min);
            return $"Chat log on for {min:0.#} min, till {_chatLogUntil:HH:mm} - {ChatLogPath}";
        }
        return "/chatlog [minutes] - log the chat to a file for a while (5 min if not said);  /chatlog off;  /chatlog clear - empty it";
    }
    private void ChatLogLine(string text, ACGodot.UI.ChatKind kind)
    {
        if (_chatLogUntil == DateTime.MinValue) return;
        if (DateTime.Now > _chatLogUntil) { _chatLogUntil = DateTime.MinValue; try { System.IO.File.AppendAllText(ChatLogPath, $"{DateTime.Now:HH:mm:ss} -- chat log off (time's up)\n"); } catch { } return; }
        try
        {
            var fi = new System.IO.FileInfo(ChatLogPath);
            if (fi.Exists && fi.Length > 5_000_000) return;   // (a cap: 5 MB)
            System.IO.Directory.CreateDirectory(fi.DirectoryName!);
            System.IO.File.AppendAllText(ChatLogPath, $"{DateTime.Now:HH:mm:ss} [{kind}] {text}\n");
        }
        catch { }
    }

    private void Say(string text, Color color, ACGodot.UI.ChatKind kind = ACGodot.UI.ChatKind.Gameplay)
    {
        ChatLogLine(text, kind);
        _map?.Heard(text);
        TestHeard(text);
        // plugins see it first (Decal's chat intercept): one may hide it (MelkTank's chat filter)
        bool hidden = _plugins?.InterceptChat(text, kind) == true;
        if (!hidden) foreach (var c in _chats) c.Add(text, color, kind);
        _plugins?.OnChatLine(text, kind);
    }
    private bool _underground;
    private bool _terrainHidden;
    private FlyCamera _cam = null!;
    private Label _hud = null!;
    private LineEdit _goto = null!;
    private string _status = "";

    // a title's name: the game's data names each number (ID_CharacterTitle_...), and its words are in the titles' string table under that name
    private DatReaderWriter.DBObjs.EnumMapper? _titleIds; private DatReaderWriter.DBObjs.StringTable? _titleWords; private bool _titlesRead;
    private string TitleName(uint title)
    {
        if (!_titlesRead && _dats != null)
        {
            _titlesRead = true;
            try { _titleIds = _dats.Get<DatReaderWriter.DBObjs.EnumMapper>(0x22000041); _titleWords = _dats.Get<DatReaderWriter.DBObjs.StringTable>(0x2300000E); } catch { }
        }
        if (_titleIds == null || !_titleIds.IdToStringMap.TryGetValue(title, out var key) || key == null) return "";
        string k = key.ToString() ?? "";
        uint h = 0;
        foreach (char c in k)
        {
            h = (h << 4) + (byte)c;
            uint g = h & 0xF0000000;
            if (g != 0) h ^= g >> 24;
            h &= ~g;
        }
        if (_titleWords != null && _titleWords.Strings.TryGetValue(h, out var w) && w.Strings.Count > 0) return string.Concat(w.Strings);
        return k.StartsWith("ID_CharacterTitle_") ? k["ID_CharacterTitle_".Length..].Replace('_', ' ') : k;
    }

    public override void _Ready()
    {
        // (the kept Sound off / background settings put on at the start - they were only put on when the window first
        // lost or got the focus, so a game started with sound off played sound till then)
        CallDeferred(nameof(ApplyBackground));
        // (warnings and errors kept in the character's logs folder, to be looked at afterwards)
        // slow frames written down (logs/<Character>/hitches.txt), and the garbage collector kept from stopping
        // everything for a full collection while playing (it does them alongside instead)
        try
        {
            System.Runtime.GCSettings.LatencyMode = System.Runtime.GCLatencyMode.SustainedLowLatency;
            ACGodot.FrameWatch.Dir = () => _net?.CharLogDir() ?? System.IO.Path.GetTempPath();
            ACGodot.FrameWatch.Extra = () => (_windowActive ? "active, " : "background, ") + (GetViewport().Disable3D ? "3D off, " : "") + (_particles != null ? $"{_particles.Emitters} effects ({_particles.Drawn} drawn), {_particles.Particles} particles" + (_objects != null ? $", building {_objects.Pending}" : "") : "");
            GetTree().Root.CallDeferred(Node.MethodName.AddChild, new ACGodot.FrameWatch { Name = "FrameWatchFirst" });
            GetTree().Root.CallDeferred(Node.MethodName.AddChild, new ACGodot.FrameWatch { Name = "FrameWatchLast", IsLast = true });
        }
        catch (Exception ex) { GD.Print("frame watch: " + ex.Message); }
        try { OS.AddLogger(new WarningLog(() => _net?.CharLogDir() ?? System.IO.Path.GetTempPath())); } catch (Exception ex) { GD.Print("warning log: " + ex.Message); }
        KeyMap.Start();   // which keys do what (the game's keymap file)
        AddChild(new ACGodot.UI.Video { Name = "Video", TerrainOf = () => _terrain, ObjectsOf = () => _objects, CamOf = () => _cam, SunOf = () => _sunLight, EnvOf = () => _env });   // (Options > Video)
        if (ACGodot.UI.OptionsWindow.StartMaximized) GetWindow().Mode = Window.ModeEnum.Maximized;   // (Options > Display)
        // light and the world's environment (the sky sets both as the day goes)
        _sunLight = new DirectionalLight3D { RotationDegrees = new Vector3(-50, -30, 0), ShadowEnabled = false, LightEnergy = 1.1f };
        AddChild(_sunLight);
        var env = new Godot.Environment
        {
            BackgroundMode = Godot.Environment.BGMode.Color,
            BackgroundColor = new Color(0.72f, 0.8f, 0.88f),
            AmbientLightSource = Godot.Environment.AmbientSource.Color,
            AmbientLightColor = new Color(0.5f, 0.5f, 0.5f),
            FogEnabled = true,
            FogLightColor = new Color(0.72f, 0.8f, 0.88f),
            FogDensity = 0.0006f,
            FogSkyAffect = 0f,
            TonemapMode = Godot.Environment.ToneMapper.Filmic,
        };
        AddChild(new WorldEnvironment { Environment = env });
        _env = env;

        _cam = new FlyCamera { ProcessPriority = -10 };
        AddChild(_cam);
        _cam.MakeCurrent();

        var ui = new CanvasLayer();
        AddChild(ui);
        _ui = ui;
        _statusLine = new ACGodot.UI.StatusLine();
        // (on a layer of its own, over the windows - the plugins' too)
        var over = new CanvasLayer { Layer = 50 };
        AddChild(over);
        over.AddChild(_statusLine);
        _hud = new Label { Position = new Vector2(10, 8) };
        _hud.AddThemeColorOverride("font_color", Colors.White);
        _hud.AddThemeColorOverride("font_outline_color", Colors.Black);
        _hud.AddThemeConstantOverride("outline_size", 4);
        ui.AddChild(_hud);
        { var cfg = new ConfigFile(); if (global::ACGodot.SafeConfig.Load(cfg, "user://ui.cfg") == Error.Ok) _hud.Visible = (bool)cfg.GetValue("debug", "shown", true); }
        _goto = new LineEdit
        {
            PlaceholderText = "Go to: 42.1N 33.6E, a landblock (A9B4) or a cell (01D90108) - Enter to go, Esc to cancel",
            Visible = false,
            Position = new Vector2(10, 150),
            Size = new Vector2(620, 32),
        };
        _goto.TextSubmitted += OnGotoSubmitted;
        ui.AddChild(_goto);

        // the data files
        string dir = DatDir();
        Dats.HighResTextures = !BackgroundFlag("lowres_textures");
        _dats = Dats.Open(dir, out string err);
        if (_dats == null)
        {
            _status = "Can't load the game data: " + err + "\nSet dat_dir in " + ProjectSettings.GlobalizePath("user://acgodot.cfg") +
                      " (or start with --dat-dir=/path).";
            GD.PushError(_status);
            return;
        }
        try
        {
            var tex = TerrainTextures.Build(_dats);
            _tex = tex;
            _terrain = new TerrainStreamer { Name = "Terrain" };
            AddChild(_terrain);
            _terrain.Setup(_dats, tex);
            _far = new FarTerrain { Name = "FarTerrain" };
            AddChild(_far);
            _far.Setup(_dats, tex);
            _objects = new ObjectStreamer { Name = "Objects" };
            AddChild(_objects);
            _objects.Setup(_dats, tex.HeightTable);
            _farScenery = new ACGodot.Objects.FarScenery { Name = "FarScenery" };
            AddChild(_farScenery);
            _farScenery.Setup(_dats, _objects.Assets, tex.HeightTable);
            _objects.FloorMaskChanged = (k, mask, size) => _terrain.SetFloorMask(k, mask, size);
            _objects.PortalsChanged = (tex, n, inside) => _terrain.SetPortals(tex, n, inside);
            // creatures and NPCs, from ACE's world database (data/ in the project, made by tools/ace_spawns.py)
            var spawns = ACGodot.Creatures.SpawnData.Load(ProjectSettings.GlobalizePath("res://data"), out string serr);
            // playing on a server (switched on in the options): what's in the world comes from it
            // playing on a server is the launcher's doing: it starts the game for an account with the server and login, for
            // this run only (started on its own, the game is the world on its own)
            _netCfg = ACGodot.Net.NetSettings.FromLauncher() ?? new ACGodot.Net.NetSettings();
            if (_netCfg.Enabled) _objects.NoSpawns = true;
            if (spawns != null)
            {
                // a test portal by Holtburg's lifestone (8 m east of it): to A Red Rat Lair, coming out in the same spot each time
                if (spawns.Get(19717) is { } portalLook)
                {
                    var tp = portalLook.Copy();
                    tp.Name = "Test Portal: A Red Rat Lair";
                    spawns.AddWeenie(TestPortalWcid, tp);
                    spawns.AddPlaced(0xA9, 0xB4, TestPortalWcid, 0xA9B40019u, new System.Numerics.Vector3(89.3f, 11.8f, -9999f),
                                     new System.Numerics.Quaternion(0, 0, -0.543991f, 0.839091f));
                    _portalTo[TestPortalWcid] = (0x01D90108u, "A Red Rat Lair");
                }
                var creatures = new ACGodot.Creatures.CreatureAssets(_dats, _objects.Assets, spawns);
                _creatureAssets = creatures;
                _objects.UseSpawns(creatures);
                // name tags over what's around (Options > Gameplay > Name tags)
                ACGodot.UI.NameTags.PetTest = s => _net?.IsPet(s) == true;
                ACGodot.UI.NameTags.InAllegiance = s => _net?.InMyAllegiance(s) == true;
                AddChild(new ACGodot.UI.NameTags { Name = "NameTags", Objects = _objects, Me = () => _player?.Position ?? Vector3.Zero,
                                                   LevelOf = wcid => spawns.Get(wcid)?.Level ?? 0, IsPet = s => _net?.IsPet(s) == true });
                _player = new ACGodot.Creatures.Player { Name = "Player", Visible = false };
                AddChild(_player);
                var physics = new ACGodot.Physics.WorldPhysics(new ACGodot.Physics.RecordingDats(_dats), _netCfg.Enabled ? null! : spawns);
                _player.Setup(creatures, p => _terrain.GroundAt(p), _cam, physics);
                _objects.DoorChanged = (lb, index, open) => physics.SetDoorOpen(lb.x, lb.y, index, open);
                if (_netCfg.Enabled)
                {
                    // on a server: its things go into the collision as it places them
                    _objects.Physics = physics;
                    _objects.Ground = p => _terrain?.GroundAt(p);
                    physics.PlayerAc = () => { var (ax, ay, az) = World.ToAc(_player!.Position); return new System.Numerics.Vector3(ax, ay, az); };
                }
                _objects.OnlyChanged = lb => physics.SetOnlyLandblock(lb);   // another dungeon's things: walked through
                _combatHud = new ACGodot.Combat.CombatHud { Visible = false };
                _ui.AddChild(_combatHud);
                // your character and what you carry (kept in user://character.json)
                var inv = new ACGodot.Combat.Inventory();
                inv.Attach(spawns);
                var me = ACGodot.Combat.Character.Load(inv);
                me.Attach(_dats);
                if (me.Health <= 0 || me.Health > me.MaxHealth) me.Health = me.MaxHealth;
                me.Stamina = me.MaxStamina; me.Mana = me.MaxMana;
                _combat = new ACGodot.Combat.CombatSystem { Name = "Combat", Hud = _combatHud, Me = me, Inv = inv,
                                                           Loot = new ACGodot.Combat.Loot(spawns, ProjectSettings.GlobalizePath("res://data")) };
                AddChild(_combat);
                _combat.Icon = id => _objects.Assets.Icon(id);
                _combat.Setup(_objects, _player, creatures, _dats, physics, p => _terrain.GroundAt(p));
                // magic: the spells you know, bolts, buffs, magic items' spells
                _magic = new ACGodot.Magic.MagicSystem { Name = "Magic", Combat = _combat };
                AddChild(_magic);
                _magic.Load(_dats);
                _magic.CasterAt = () => _player.Position + new Vector3(0, 1.3f, 0);
                _magic.Player = _player; _magic.Assets = creatures;
                // a jump's height from your Jump skill and burden, and its stamina
                _player.ShowArc = BackgroundFlag("jump_arc");
                _player.JumpStats = () => (_combat.Me.Skill(22), inv.TotalBurden / (float)Math.Max(1, _combat.Me.Attribute(0) * 150));
                _player.StaminaNow = () => _combat.Me.Stamina;
                // how fast you run: from your Run skill, less as you're overburdened (the game's own run rate; worked
                // out a couple of times a second - adding up the pack's burden every frame would be work for nothing)
                {
                    float rate = 1.6f; double ratedAt = -1;
                    _player.RunRateOf = () =>
                    {
                        double now = Time.GetTicksMsec() / 1000.0;
                        if (ratedAt >= 0 && now - ratedAt < 0.5) return rate;
                        ratedAt = now;
                        var me = _combat.Me;
                        int aug = 0; _net?.Character?.Ints.TryGetValue(231, out aug);
                        double cap = Math.Max(1.0, (double)me.Attribute(0) * 150 + (double)me.Attribute(0) * 30 * Math.Clamp(aug, 0, 5));
                        double load = inv.TotalBurden / cap;
                        float loadMod = load >= 2.0 ? 0f : load >= 1.0 ? (float)(2.0 - load) : 1f;
                        int run = me.Skill(24);
                        rate = run >= 800 ? 4.5f : (loadMod * ((float)run / (run + 200) * 11f) + 4f) / 4f;
                        return rate;
                    };
                }
                _player.UseStamina = n => _combat.Me.Stamina = Math.Max(0, _combat.Me.Stamina - n);
                _magic.Say = (t, c) => Say(t, c, ACGodot.UI.ChatKind.Magic);
                ACGodot.Combat.Item.SpellNames = i => _magic.SpellNames(i);
                ACGodot.Combat.Item.SpellInfo = id => _magic.All.TryGetValue(id, out var spi) ? (spi.Name, spi.Description) : null;
                ACGodot.Combat.Item.SkillNameOf = id => _combat.Me.AllSkills().Where(k => k.id == id).Select(k => k.name).FirstOrDefault();
                _combat.Loot.Made = item => _magic.Enchant(item);
                _combat.GearUpdated = () => _magic.GearChanged(inv.Worn);
                _magic.GearChanged(inv.Worn);
                _combat.ShowWorn();
                _spellbook = new ACGodot.Magic.SpellbookWindow { Visible = false, Position = new Vector2(80, 120), Magic = _magic, Icon = id => _objects.Assets.Icon(id) };
                _ui.AddChild(_spellbook);
                // the windows: character (C), inventory (I), a corpse's contents (R on it)
                _charWin = new ACGodot.Combat.CharacterWindow { Visible = false, Position = new Vector2(20, 120) };
                _ui.AddChild(_charWin);
                _charWin.Changed = () => { me.Save(inv); _status = "raised"; };
                _combat.XpChanged = () => _charWin.Refresh();
                _packWin = new ACGodot.Combat.PackWindow { Visible = false };
                _ui.AddChild(_packWin);
                _packWin.Said = t => { if (t.Length > 0) _combatHud.Log(t, ACGodot.Combat.CombatHud.Plain); };
                _packWin.Equipped = () => _combat.GearChanged();
                _packWin.Dropped = item => _combat.Drop(item);
                inv.Changed = () => _packWin.Refresh();
                _lootWin = new ACGodot.Combat.LootWindow { Visible = false };
                _ui.AddChild(_lootWin);
                _lootWin.Take = item =>
                {
                    // bending down to the corpse and back up for each thing taken, as in the game: while that lasts
                    // nothing else can be taken - what's asked for meanwhile waits its turn (taken once you're back up)
                    // on a server: asked of it (it's in the pack when the server says so)
                    if (item.Guid != 0 && _net != null) { _net.TakeOut(item); _player?.Crouch(); return true; }
                    double now = Time.GetTicksMsec() / 1000.0;
                    if (now < _lootBusyUntil) { if (!_lootQueue.Contains(item)) _lootQueue.Add(item); return false; }
                    if (!inv.Add(item)) { _combatHud.Log("Your pack is full.", ACGodot.Combat.CombatHud.Plain); return false; }
                    float down = _player?.Crouch() ?? 0f;
                    _lootBusyUntil = now + (down > 0f ? down : 0.73f) * 2f;
                    _combatHud.Log(item.IsCoins ? $"You take {item.Stack:N0} pyreals." : $"You take the {item.Name}.", ACGodot.Combat.CombatHud.Plain);
                    me.Save(inv);
                    return true;
                };
                _combat.LootUi = _lootWin;
                _combat.IsPet = sel => _net?.IsPet(sel) == true;
                _lootWin.Picked = PickItem;
                _combatHud.AutoTargetSet = on => _combat.AutoTarget = on;
                // the game's own screen parts (radar, vitals), from its interface data
                try
                {
                    var rui = new ACGodot.UI.RetailUi(_dats, _objects.Assets);
                    ACGodot.UI.RetailTheme.Build(rui);
                    _retail = new ACGodot.UI.RetailHud { Name = "RetailHud", Visible = false };
                    _ui.AddChild(_retail);
                    _ui.MoveChild(_retail, 0);
                    _retail.Setup(rui);
                    _chat = new ACGodot.UI.ChatWindow { Name = "Chat" };
                    _ui.AddChild(_chat);
                    _ui.MoveChild(_chat, 1);
                    _chat.Setup(rui);
                    if (_chat.Window != null)
                    {
                        _chats.Add(_chat);
                        // the extra chat windows (1-4 as the game's, 5 for plugins' text), opened by the main one's buttons
                        for (int i = 1; i <= 5; i++)
                        {
                            var extra = new ACGodot.UI.ChatWindow { Name = $"Chat{i}", Index = i };
                            _ui.AddChild(extra);
                            _ui.MoveChild(extra, 1 + i);
                            extra.Setup(rui);
                            if (extra.Window == null) { extra.QueueFree(); continue; }
                            extra.Submitted = OnChat;
                            extra.SelectedName = () => _objects?.Selected is { } so && !so.Gone ? so.Name : null;
                            _chats.Add(extra);
                            _chat.SetWindowLit(i, extra.Shown);
                            int n = i;
                            extra.Closed = () => _chat.SetWindowLit(n, false);
                        }
                        _chat.ToggleWindow = n =>
                        {
                            foreach (var c in _chats) if (c.Index == n) { c.SetShown(!c.Shown); _chat.SetWindowLit(n, c.Shown); }
                        };
                        _combatHud.LogTo = (t, c) => Say(t, c, ACGodot.UI.ChatKind.Combat);
                        _chat.Submitted = OnChat;
                        _chat.SelectedName = () => _objects?.Selected is { } so && !so.Gone ? so.Name : null;
                        Say("Welcome to Asheron's Call (ACGodot). Type /help for commands.", new Color(1f, 0.9f, 0.4f));
                    }
                    else { _chat.QueueFree(); _chat = null; }
                    // the shortcut bar (I-VIII), above the vitals
                    _bar = new ACGodot.UI.ShortcutBar { Name = "Shortcuts", Visible = false };
                    _ui.AddChild(_bar);
                    _bar.Icon = id => _objects.Assets.Icon(id);
                    _bar.Use = UseShortcut;
                    // (your own standing as a player killer, for the colour you're marked in when you select yourself)
                    ACGodot.UI.SelectionMarks.SelfPk = () => { int v = 0; _net?.Character?.Ints.TryGetValue(134, out v); return (v & 0x4) != 0 ? 1 : (v & 0x40) != 0 ? 2 : 0; };
                    { var bar = _bar; ACGodot.Combat.ItemSlot.QuickNumber = it => bar.NumberOf(it); }
                    _bar.ItemOf = e =>
                    {
                        var inv = _combat?.Inv;
                        if (inv == null) return null;
                        // the very object the slot was given (a server's): that one and no other - two wands of a kind are
                        // two different wands. Gone, only what stacks or is used up is stood in for by more of its kind
                        // (the next stack of potions, the next kit)
                        if (e.Guid != 0)
                        {
                            foreach (var i in inv.Worn) if (i.Guid == e.Guid) return i;
                            foreach (var i in inv.Pack) if (i.Guid == e.Guid) return i;
                            return inv.Pack.FirstOrDefault(i => i.Wcid == e.Id && i.Name == e.Name && (i.MaxStack > 1 || i.MaxUses > 0));
                        }
                        // (one put there before slots kept the object: of several of a kind, the one of that name first)
                        var all = inv.Worn.Concat(inv.Pack).Where(i => i.Wcid == e.Id).ToList();
                        return all.FirstOrDefault(i => i.Name == e.Name) ?? all.FirstOrDefault();
                    };
                    _bar.CountOf = e => _combat?.Inv.Pack.Where(i => i.Wcid == e.Id).Sum(i => i.Stack) ?? 0;
                    _bar.Select = e =>
                    {
                        var it = _bar?.ItemOf?.Invoke(e);
                        if (it != null) PickItem(it); else _combatHud?.Log($"You don't have {e.Name}", ACGodot.Combat.CombatHud.Plain);
                    };
                    _bar.Identify = e =>
                    {
                        if (e.Kind == "spell") { if (_magic != null && _magic.All.TryGetValue(e.Id, out var sp)) _examine?.ShowSpell(sp); return; }
                        var it = _bar?.ItemOf?.Invoke(e);
                        if (it != null) IdentifyItem(it); else _combatHud?.Log($"You don't have {e.Name}", ACGodot.Combat.CombatHud.Plain);
                    };
                    _bar.Refresh();   // its icons, now they can be found
                    ACGodot.Combat.ItemGrid.Identify = IdentifyItem;
                    if (_packWin != null) _packWin.Shortcut = item =>
                    {
                        bool ok = _bar.Add(new ACGodot.UI.ShortcutBar.Entry("item", item.Wcid, item.Name, item.Icon, item.Guid));
                        _combatHud.Log(ok ? $"{item.Name} added to the shortcut bar" : "That shortcut bar is full", ACGodot.Combat.CombatHud.Plain);
                    };
                    if (_spellbook != null) _spellbook.Shortcut = sp =>
                    {
                        bool ok = _bar.Add(new ACGodot.UI.ShortcutBar.Entry("spell", sp.Id, sp.Name, sp.Icon));
                        Say(ok ? $"{sp.Name} added to the shortcut bar" : "That shortcut bar is full", new Color(1f, 0.9f, 0.4f));
                    };
                    // plugins: the built-in ones (MelkTank, Nav, XP tracker, bounties, quest timers) and any DLLs in the plugins folder
                    if (_combat != null && _player != null)
                    {
                        // ImGui over the game, for plugins whose windows are ImGui (MelksQB, MelkTank)
                        AddChild(new ACGodot.UI.ImGuiLayer { Name = "ImGui" });
                        _plugins = new ACGodot.Plugins.PluginHost { Name = "Plugins", Combat = _combat, Objects = _objects, Player = _player, Magic = _magic, Ui = _ui,
                                                                    SayTo = (t, c, k) => Say(t, c, k), Type = OnChat,
                                                                    ServerName = _netCfg.Enabled ? _netCfg.Host : "", Account = _netCfg.Enabled ? _netCfg.Account : (System.Environment.GetEnvironmentVariable("ACGODOT_ACCOUNT") ?? "") };
                        _plugins.DatDir = DatDir();
                        AddChild(_plugins);
                        // (a plugin's use - a looter opening a corpse - is on the thing itself: the player's selection is left alone)
                        _plugins.Use = s => { _useWhy = "a plugin: " + PluginCaller(); UseOn(s, true); };
                        _plugins.PickedItem = () => _selItem;
                        _plugins.AccountCharacters = () => _net?.AccountCharacters ?? (IReadOnlyList<(uint, string)>)Array.Empty<(uint, string)>();
                        _plugins.PickItem = it => _selItem = it;
                        _plugins.QuietIdentify = it => { if (it.Guid != 0) _net?.Appraise(it.Guid); };
                        _plugins.UseItem = UseExact;
                        _plugins.Quit = () => GetTree().Quit();
                        _plugins.ClearShot = g => _player?.ClearShot(g);
                        _plugins.LogoutQuit = () => { if (_net != null) _net.LogOutThenQuit(() => GetTree().Quit()); else GetTree().Quit(); };
                        _plugins.Start(ACGodot.Plugins.BuiltIn.All());
                    }
                    if (_netCfg.Enabled && _player != null)
                    {
                        _net = new ACGodot.Net.NetGame { Name = "Network", Objects = _objects, Player = _player, Say = (t, c, k) => { Say(t, c, k); if (_connectNote != null && _connectCover?.Visible == true && t.StartsWith("[Network] ")) _connectNote.Text = t[10..]; } };
                        _net.ServerPeace = () => _combat?.ServerPeace();
                        _net.UsedOn = UsedElsewhere;
                        if (_plugins != null) _plugins.Net = _net;
                        _net.Killed = t => _plugins?.RaiseServerKilled(t);
                        // (the plugins know the server by the world's own name, as Decal gives it - where it gives one)
                        // (a test server on this computer keeps its address as its name: what's kept under that stays found)
                        _net.WorldNamed = n => { if (n.Length > 0 && _plugins != null && _netCfg.Host is not ("127.0.0.1" or "localhost" or "::1")) _plugins.ServerName = n; };
                        AddChild(_net);
                        // the character screen: the account's characters to pick from (none named by the launcher; after logging out)
                        _net.PickCharacter = (list, account) =>
                        {
                            if (_characterSelect == null)
                            {
                                // the character screen is its own place: the world behind it isn't shown or walked about in
                                // (on a layer of its own over everything - the game's own windows and readouts, the plugins'
                                // ImGui windows - so the screen is blank but for the characters list)
                                var layer = new CanvasLayer { Name = "CharacterScreenLayer", Layer = 95 };
                                AddChild(layer);
                                var behind = new ColorRect { Name = "CharacterScreen", Color = Colors.Black, Visible = false, MouseFilter = Control.MouseFilterEnum.Stop };
                                behind.SetAnchorsPreset(Control.LayoutPreset.FullRect);
                                layer.AddChild(behind);
                                _characterSelect = new ACGodot.UI.CharacterSelect { Name = "CharacterSelect", Visible = false, Enter = id => { ShowConnecting("Entering the world..."); _net?.EnterAs(id); }, Quit = () => GetTree().Quit(),
                                                                                 Dats = _dats, Create = c => _net?.CreateCharacter(c) == true };
                                var screen = _characterSelect;
                                screen.Closed = () => screen.Visible = true;   // (its X: there's nowhere else to be)
                                // the game's own character creation screen, over the same black (Exit: back to the list)
                                var gen = new ACGodot.UI.CharGen { Name = "CharGen", Dats = _dats!, Looks = _creatureAssets, Create = c => _net?.CreateCharacter(c) == true };
                                // the game's own character screen (the plain list above if it can't be built)
                                var pick = new ACGodot.UI.CharSelect { Name = "CharSelect", Visible = false,
                                                                       Enter = id => { ShowConnecting("Entering the world..."); _net?.EnterAs(id); }, Quit = () => GetTree().Quit(),
                                                                       Delete = id => _net?.DeleteCharacter(id) == true, Restore = id => _net?.RestoreCharacter(id) == true,
                                                                       DeletingIn = id => _net?.DeletingIn(id) ?? -1, World = () => _net?.WorldName ?? "" };
                                pick.OpenCreate = () => gen.Open();
                                _charSelect = pick;
                                gen.Exit = () => { if (!pick.ShowAgain()) screen.Visible = true; };
                                _charGen = gen;
                                screen.OpenCreate = () => gen.Open();
                                void Shown()
                                {
                                    bool on = screen.Visible || gen.Visible || pick.Visible;
                                    behind.Visible = on; ACGodot.UI.ImGuiLayer.Hidden = on; if (_player != null) _player.Frozen = on;
                                }
                                screen.VisibilityChanged += Shown;
                                gen.VisibilityChanged += Shown;
                                pick.VisibilityChanged += Shown;
                                layer.AddChild(_characterSelect);
                                layer.AddChild(pick);
                                layer.AddChild(gen);
                            }
                            HideConnecting();
                            _portalSpace?.Release();
                            _charGen?.Close();   // (a character just made: back to the list, with it there)
                            if (_charSelect?.Show(list, account) != true) _characterSelect.Show(list, account);
                        };
                        _net.CreateFailed = why => { if (_charGen?.Visible == true) _charGen.Failed(why); else _characterSelect?.CreateFailed(why); };
                        // the server gone: the game closes (as the old client did) a few seconds after saying so - plugins stop
                        // with it instead of casting into nothing, and a launcher can start it again
                        _net.ConnectionLost = () =>
                        {
                            _chat?.Add("Lost the connection to the server - the game closes in 5 seconds.", new Color(1f, 0.4f, 0.4f));
                            GetTree().CreateTimer(5.0).Timeout += () => GetTree().Quit();
                        };
                        // the server's yes-or-no questions
                        _net.ConfirmAsked = (kind, context, about) =>
                        {
                            if (_confirm == null) { _confirm = new ACGodot.UI.ConfirmWindow { Name = "Confirm", Visible = false }; _ui.AddChild(_confirm); }
                            string words = kind switch
                            {
                                1 => $"Swear allegiance to {about}? They become your patron, and a share of the experience you earn passes up to them.",
                                4 when !about.Contains(' ') => $"{about} invites you to join a fellowship. Join?",
                                _ => about.Length > 0 ? about : "Are you sure?",
                            };
                            ChatLogLine($"(popup {kind}) {words}", ACGodot.UI.ChatKind.Gameplay);
                            try { if (_plugins?.ConfirmAutoYes?.Invoke(words) == true) { ChatLogLine("(popup answered Yes by a plugin)", ACGodot.UI.ChatKind.Gameplay); _net?.Confirm(kind, context, true); return; } } catch { }
                            _confirm.Ask(words, yes => { ChatLogLine($"(popup answered {(yes ? "Yes" : "No")})", ACGodot.UI.ChatKind.Gameplay); _net?.Confirm(kind, context, yes); });
                        };
                        _net.ConfirmDone = () => { ChatLogLine("(popup closed by the server)", ACGodot.UI.ChatKind.Gameplay); _confirm?.Withdraw(); };
                        // a book or parchment you used yourself opens to read (one a plugin opens for itself - the Monster-Dex - doesn't)
                        _net.BookPage += (book, page, pages, text) =>
                        {
                            if (page < 0)
                            {
                                if (book != _readBook || Time.GetTicksMsec() / 1000.0 - _readBookAt > 10) return;
                                _readBook = 0;
                                if (_bookWin == null) { _bookWin = new ACGodot.UI.BookWindow { Name = "Book", Visible = false }; _ui.AddChild(_bookWin); }
                                _bookWin.Open(book, _readBookName, pages);
                            }
                            else if (text != null && _bookWin != null && _bookWin.BookId == book) _bookWin.Page(book, page, pages, text);
                        };
                        // straight to whoever is logging in: nothing of the world is shown till the server has put them in it
                        ShowConnecting($"Connecting to {_netCfg.Host}...");
                        _net.Placed = () => OutWhenLoaded(Time.GetTicksMsec());
                        _net.CharacterRead = ApplyServerCharacter;
                        // (named at once - plugins starting as the world loads (their settings are kept per character) saw
                        // the placeholder "Adventurer" till the server's character came; it's the server's from here, so
                        // it's never written over the offline character's file)
                        _net.ChosenGuid = () => _objects?.Selected is { Gone: false } cs && cs != _objects.Self && cs.Kind is 1 or 2 && !cs.Corpse ? _net.GuidOf(cs) : 0;
                        _net.Entering = name => { if (_combat?.Me is { } me && name.Length > 0) { me.OnServer = true; me.Name = name; } PortalHold(); };
                        // logging out: portal space once the leaving gesture has played, till the character screen comes back
                        _net.LeavingWorld = () => GetTree().CreateTimer(1.6).Timeout += () => { if (_net?.LoggingOut == true) PortalHold(); };
                        _net.AppraisalRead = ShowAppraisal;
                        _net.CreatureHealthTold = (s, h, m) => _combat?.NetHealthTold(s, h, m);
                        _net.SocialChanged = () => _socialPanel?.Refresh();
                        // a vendor used: their window (made the first time), their wares in it
                        _net.VendorOpened = v =>
                        {
                            if (_vendorWin == null)
                            {
                                _vendorWin = new ACGodot.UI.VendorWindow { Visible = false, Position = new Vector2(420, 140), Icon = id => _objects!.Assets.Icon(id), Inv = _combat?.Inv,
                                                                           Buy = (g, things) => _net?.Buy(g, things), Sell = (g, things) => _net?.Sell(g, things), Identify = IdentifyItem, Picked = PickItem,
                                                                           ServerCoins = () => _net?.CoinValue ?? -1 };
                                _ui.AddChild(_vendorWin);
                                var vw = _vendorWin; var vn = _net;
                                vw.VisibilityChanged += () => { if (!vw.Visible && vn != null) vn.OpenVendorInfo = null; };   // (shut: no vendor open, for plugins)
                            }
                            _vendorWin.Show(v);
                        };
                        // (its window shut: the corpse is shut - else it came back up at the next change in the pack)
                        if (_lootWin != null) { var nw = _net; var lw0 = _lootWin; lw0.VisibilityChanged += () => { if (!lw0.Visible) { if (_player?.Bending == true) _closeAfterPickup = true; else nw.CloseContainer(); } }; }
                        _net.ContainerShown = (title, things) =>
                        {
                            if (_lootWin == null) return;
                            if (things == null) { _lootWin.Visible = false; return; }
                            var cn = _net;
                            _lootWin.Slots = cn.OpenContainerSlots;
                            _lootWin.PackSlots = cn.OpenContainerPackSlots;
                            _lootWin.Box = cn.OpenContainer;
                            _lootWin.BoxIcon = cn.OpenContainerIcon;
                            _lootWin.PutIn = (it, into, place) => cn.Move(it, into, place);
                            _lootWin.MergeOnto = (from, onto) => cn.Merge(from, onto);
                            _lootWin.ContentsOf = cn.ContentsOf;
                            _lootWin.OpenPack = cn.UseItem;
                            _lootWin.MainPackIcon = () => _controlBar?.PanelIcon(7);
                            _lootWin.Show(title, things, id => _objects!.Assets.Icon(id));
                        };
                        if (_magic != null)
                        {
                            var net = _net; var magic = _magic;
                            magic.NetCast = (sp, self, given) =>
                            {
                                // an "Other" spell is for someone else: not cast on yourself (nothing selected, or yourself selected)
                                var at = given ?? _objects?.Selected;
                                if (!self && System.Text.RegularExpressions.Regex.IsMatch(sp.Name, @"\bOther\b") && (at == null || at == _objects!.Self || net.GuidOf(at) == 0))
                                { Status($"{sp.Name} can't be cast on yourself: select someone else first.", "cast"); return null; }
                                bool asked = net.Cast(sp.Id, self, at, sp.NoTarget); if (asked) Status($"Casting {sp.Name}", "cast");
                                // cast at something: you turn to face it as you cast (by hand, or a plugin's cast at a target it gave)
                                if (asked && !self && !sp.NoTarget && at != null && at != _objects?.Self && !at.Gone && _player != null)
                                {
                                    var d = at.Feet - _player.Position;
                                    if (d.X * d.X + d.Z * d.Z > 0.04f) _player.TurnToYaw = MathF.Atan2(-d.X, -d.Z);
                                }
                                return (bool?)asked;
                            };
                            // (what the server refuses - a fizzle, no components, too busy - is on the status line; the game also put
                            // it in the chat, where plugins read it: they're told, though the chat window isn't)
                            net.Status = t =>
                            {
                                ChatLogLine("(top of the screen) " + t, ACGodot.UI.ChatKind.Gameplay);
                                Status(t);
                                try { _plugins?.InterceptChat(t, ACGodot.UI.ChatKind.Gameplay); _plugins?.OnChatLine(t, ACGodot.UI.ChatKind.Gameplay); } catch { }
                            };
                            net.UseDone = magic.NetCastDone;
                            net.UseFailed = magic.NetCastRefused;
                            net.Enchanted = (id, left, on) => { magic.ServerEnchant(id, left, on); _effectsPanel?.Refresh(); _plugins?.OnEnchant(id, left, on); };
                        }
                        _net.VitalRead = (vital, now) =>
                        {
                            if (_combat?.Me is not { } me) return;
                            if (vital == 0) { me.Health = now; _combat.Health = now; } else if (vital == 1) me.Stamina = now; else me.Mana = now;
                        };
                        if (_combat != null)
                        {
                            var net = _net; var cinv = _combat.Inv;
                            net.Inv = cinv;
                            // (said at the top of the screen as it's asked: what goes on, and what comes off)
                            cinv.NetWield = (it, at) => { Status($"{((it.ItemType & 0x8101) != 0 || it.IsMeleeWeapon ? "Wielding" : "Putting on")} {it.Name}", "gear"); net.Wield(it, at); };
                            cinv.NetToPack = it => { if (it.WornAt != 0) Status($"Removing {it.Name}", "gear"); net.ToPack(it); };
                            cinv.NetDrop = net.Drop;
                            // your greatest health as the server has it: your health now over the part of the whole it says that is
                            // (taken when two answers running agree, or when you're whole - your health moves between the asking and the answer)
                            {
                                int lastMax = 0;
                                net.SelfHealthPart = part =>
                                {
                                    var me = _combat?.Me;
                                    if (me == null || part <= 0.01f || me.Health <= 0) return;
                                    int max = part >= 0.9999f ? me.Health : (int)MathF.Round(me.Health / part);
                                    bool agrees = lastMax > 0 && Math.Abs(max - lastMax) <= Math.Max(2, lastMax / 200);
                                    lastMax = max;
                                    if (part >= 0.9999f || agrees) { if (me.ServerMaxHealth != max) { me.ServerMaxHealth = max; } }
                                };
                            }
                            cinv.NetMove = net.Move; cinv.NetSplit = net.Split; cinv.NetMerge = net.Merge;
                            var combat = _combat;
                            net.Me = combat.Me;
                            combat.Me.NetRaise = net.Raise;
                            net.StatsChanged = () => combat.XpChanged?.Invoke();
                            combat.NetAttack = net.Attack; combat.NetCancelAttack = net.CancelAttack; combat.NetRepeatIs = () => net.OptionsRead ? net.Option("AutoRepeatAttacks") : null; combat.NetRepeat = on => net.SetOption("AutoRepeatAttacks", on); combat.NetCombatMode = net.CombatMode; combat.NetSettling = () => net.Settling; net.TitlesChanged = () => _charPanel?.Refresh();
                            net.AttackDone = combat.NetAttackDone; net.HealthRead = combat.NetHealth; net.Died = combat.NetDied; net.Teleporting = ServerPortal; net.SelfAction = (m, sp) => _player?.PlayAction(m, sp); net.SelfMissilePose = m => { if (_player == null) return; if (m != 0) _player.Pose = m; else if (_player.Pose == 0x40000016 || (_player.Pose >= 0x4000001E && _player.Pose <= 0x4000002A)) _player.Pose = 0; };
                            net.SelfGesture = (m, sp) => _magic?.NetGesture(m, sp);
                            if (_player != null) { _player.CastHold = () => _magic?.HoldsMovement == true; _player.CastCut = () => _magic?.TakeCut() == true; _player.CastSlide = () => _magic?.Casting == true; }
                            net.LeaveCombat = () => { if (_combat?.CombatMode != true) return false; _combat.ToggleCombat(); return true; };
                            net.ContractsChanged = () => { if (!ACGodot.UI.SocialViews.JournalShowing) _questPanel?.Refresh(); };
                            net.EffectPlayed = (thing, table, effect, mod, direct) => { _objects?.Note($"effect {(direct ? "script " : "")}{effect:X} x{mod:0.##} on {thing?.Name ?? "you"} (table {table:X8})"); _magic?.ServerEffect(table, effect, mod, direct, net.SetupOf(thing),
                                thing == null ? () => _player != null ? (_player.Position, _player.Heading) : null
                                              : () => thing.Gone ? null : (thing.Feet, thing.Yaw), net.SoundTableOf(thing), (object?)thing ?? net); }; net.SpellLearned = (id, known) => { if (_magic?.ServerSpells is { } book) { if (known) book.Add(id); else book.Remove(id); _bookRefresh = true; } }; _objects!.ThingDied = combat.NetCreatureDied;
                            net.InventoryChanged = () => { if (_barDrawnFor != (_combat.Inv.Pack.Count + _combat.Inv.Worn.Count > 0)) { _barDrawnFor = !_barDrawnFor; _bar?.Refresh(); } else _bar?.RefreshIfFound(); _combat.GearChanged(); _invPanel?.Refresh(); _bookPanel?.Refresh(); _vendorWin?.Refresh(); _salvageWin?.Refresh(); };
                        }
                        _net.Start(_netCfg);
                    }
                    // the arrow: coordinates clicked in any chat window (or /arrow) point it there
                    _arrow = new ACGodot.UI.NavArrow { Name = "Arrow" };
                    _ui.AddChild(_arrow);
                    foreach (var cw in _chats) cw.CoordsClicked = PointAt;
                    if (_plugins != null) { _plugins.PointArrow = (ns, ew, text) => _arrow.Point(ns, ew, text); _plugins.ClearArrow = _arrow.Clear; _plugins.ArrowTarget = () => _arrow.Target; }
                    // what's selected: the game's four marks round it
                    _ui.AddChild(new ACGodot.UI.SelectionMarks { Name = "SelectionMarks", Objects = _objects });
                    // identifying (a right click, or the magnifying glass): the game's examine panel
                    _examine = new ACGodot.UI.ExaminePanel { Name = "Examine", Icon = id => _objects.Assets.Icon(id), Now = () => _combat?.Now ?? 0,
                                                             SelfVitals = () => _combat == null ? (0, 0, 0) : (_combat.Health, _combat.Me.Stamina, _combat.Me.Mana) };
                    if (_combat != null) _examine.Killer = _combat.Me.Name;
                    _examine.ItemShown = it => { if (it.Guid != 0) _net?.Appraise(it.Guid); };
                    _examine.ItemGone = it => _net != null && _net.Deleted(it.Guid);
                    { var examine = _examine; _objects.ThingDied += dead => examine.Died(dead); }
                    _ui.AddChild(_examine);
                    try { if (!_examine.Setup()) { _examine.QueueFree(); _examine = null; } }
                    catch (Exception ex) { GD.PushWarning("examine panel: " + ex.Message); _examine.QueueFree(); _examine = null; }
                    if (_player != null) _player.RightClicked = at =>
                    {
                        // (what someone holds, right under the mouse - a monster's weapon, another player's: that)
                        if (_net?.InWorld == true && _net.HeldAt(GetViewport().GetCamera3D(), at) is { } held) { PickItem(held); IdentifyItem(held); return; }
                        var picked = _objects.Pick(GetViewport().GetCamera3D(), at);
                        if (MeBefore(picked, at)) IdentifySelf(); else Identify(picked, true);
                    };
                    // the game's side panels, control bar, status icons, spell bar, and the plugin bar
                    SetupRetailPanels();
                    // the world map (M): MelksQB's travel map, dungeon layouts, the tier 11+ area; plugins add to its right-click menu
                    if (_player != null)
                    {
                        _map = new ACGodot.Map.MapWindow { Name = "WorldMap", Data = ACGodot.Map.MapData.Load(ProjectSettings.GlobalizePath("res://data/map")), Dats = _dats, Player = _player,
                                                           Arrow = _arrow, PointAt = PointAt, Plugins = _plugins, Textures = _tex,
                                                           Ground = p => _terrain?.GroundAt(p), Say = (t, c) => Say(t, c), PlayerCell = () => _player.Cell,
                                                           Fixtures = () => (_objects?.AllSelectables ?? Enumerable.Empty<ObjectStreamer.Selectable>())
                                                               .Where(s => { if (s.Kind >= 3 && s.Name.Length > 0) ACGodot.Map.MapWindow.PlayersSeen.Add(s.Name); return true; })
                                                               .Where(s => !s.Gone && s != _objects!.Self && (s.Type == 7 || s.Kind == 1) && _net?.IsPet(s) != true && !ACGodot.Map.MapWindow.PetName(s.Name))
                                                               .Select(s => (s.Feet, s.Name, s.Type == 7 ? 3 : s.Type == 12 ? 2 : 1, s.Cell != 0 ? s.Cell : s.Remote ? 0u : _player.Cell)),
                                                           Nearby = () => (_objects?.AllSelectables ?? Enumerable.Empty<ObjectStreamer.Selectable>())
                                                               .Where(s => !s.Gone && s.Node is not { Visible: false } && s.Kind > 0 && s.Fight is not ACGodot.Combat.Fighter { St: ACGodot.Combat.Fighter.State.Dead })
                                                               // (a level the server has told - a player's only once they've been looked at: every player is the one kind of thing in the game's data)
                                                               .Select(s => (s.Feet, (_net?.LevelOf(s) is int told && told > 0 ? told : s.Kind >= 3 ? 0 : spawns.Get(s.Wcid)?.Level ?? 0) is int lv && lv > 0 ? $"{s.Name} [{lv}]" : s.Name,
                                                                             ACGodot.UI.NameTags.Classify(s) is string tk ? ACGodot.UI.NameTags.ColorOf(tk) : new Color(0.85f, 0.85f, 0.85f), s == _objects!.Selected)) };
                        _ui.AddChild(_map);
                        _map.Setup();
                        if (_plugins != null) { _plugins.ShowOnMap = (ns, ew, name) => _map.ShowSpot(ns, ew, name); _plugins.ShowDungeonMap = lb => { _map.ShowDungeon(lb); _map.Open(); }; _plugins.MarkOnMap = (ns, ew, name) => _map.Mark = (ns, ew, name); _plugins.MapPoints = (inMap, tag, pts) => _map.SetPoints(inMap, tag, pts); _plugins.ClearMapMark = () => _map.Mark = null; }
                    }
                    _options = new ACGodot.UI.OptionsWindow { Visible = false, Position = new Vector2(60, 80) };
                    _ui.AddChild(_options);
                    _options.Chats = () => _chats;
                    _options.Hud = _retail;
                    _options.Combat = _combat;
                    _options.ConfigureKeyboard = () =>
                    {
                        if (_keysWin == null) { _keysWin = new ACGodot.UI.KeyboardWindow { Name = "ConfigureKeyboard", Visible = false }; _ui.AddChild(_keysWin); }
                        _keysWin.Open();
                    };
                    _options.ServerOption = n => _net?.OptionsRead == true ? _net.Option(n) : null;
                    _options.SetServerOption = (n, v) => { _net?.SetOption(n, v); if (n == "AutoRepeatAttacks" && _combat != null) _combat.RepeatAttacks = v; if (n == "SideBySideVitals") _retail?.SetVitalsStacked(!v); };
                    _options.DebugShown = () => _hud.Visible;
                    _options.Host = () => _plugins;
                    _options.SetDebugShown = v => { _hud.Visible = v; SaveDebugShown(); };
                    // (logged off the server first, as its tooltip says: the character saved, the game closed at the character screen)
                    _options.Quit = () => { _options.Visible = false; if (_net != null) _net.LogOutThenQuit(() => GetTree().Quit()); else GetTree().Quit(); };
                    _options.KeepCamera = () => { if (_player != null) Status(_player.KeepCameraAsDefault()); };
                    _options.CanLogOut = () => _net?.InWorld == true;
                    _options.LogOut = () => { _net?.LogOut(); _options.Visible = false; };
                    _options.RestWorld = () => _restWorld;
                    _options.SetRestWorld = v => { _restWorld = v; SetBackgroundFlag("no_3d", v); ApplyBackground(); };
                    _options.RestSound = () => _restSound;
                    _options.SetRestSound = v => { _restSound = v; SetBackgroundFlag("no_sound", v); ApplyBackground(); };
                    _options.JumpArc = () => BackgroundFlag("jump_arc");
                    _options.SetJumpArc = v => { SetBackgroundFlag("jump_arc", v); if (_player != null) _player.ShowArc = v; };
                    _options.HighRes = () => !BackgroundFlag("lowres_textures");
                    _options.SetHighRes = v => SetBackgroundFlag("lowres_textures", !v);
                    _options.SoundOn = () => !_soundOff;
                    _options.SetSoundOn = v => { _soundOff = !v; SetBackgroundFlag("sound_off", !v); ApplyBackground(); };
                    SetupOptionsPanel();
                    _retail.BlipClicked = o =>
                    {
                        if (o is not ACGodot.Objects.ObjectStreamer.Selectable sel) return;
                        _objects.Select(sel);
                        _status = $"selected: {sel.Name}";
                    };
                }
                catch (Exception ex) { GD.PushWarning("interface: " + ex.Message); _retail = null; }
                _combatHud.KeepInViewSet = on => _combat.KeepInView = on;
                _combat.Respawn = () => { if (_player.Active) _player.Enter(_start, 0); };
                _combatHud.AttackClicked = h => _status = _combat.AttackKey(h);
                _combatHud.PowerSet = v => _combat.Power = v;
                _combatHud.RepeatSet = on => _combat.RepeatAttacks = on;
            }
            else GD.PushWarning("No creatures: " + serr);
            _audio = new ACGodot.Audio.WorldAudio { Name = "Audio" };
            AddChild(_audio);
            _audio.Setup(_dats);
            _objects.Audio = _audio;
            if (_player != null) _player.Audio = _audio;
            if (_combat != null) _combat.Audio = _audio;
            _particles = new ACGodot.Effects.ParticleWorld { Name = "Particles" };
            AddChild(_particles);
            _particles.Setup(_dats, _objects.Assets);
            _particles.Audio = _audio;
            _objects.UseParticles(_particles);
            if (_magic != null) _magic.Particles = _particles;
            if (_player != null) _player.Particles = _particles;
            _sky = new ACGodot.Sky.SkyController { Name = "Sky" };
            AddChild(_sky);
            _sky.Setup(_dats, _objects.Assets, _sunLight, _env);
            _sky.Particles = _particles;
        }
        catch (Exception ex)
        {
            _status = "Couldn't build the landscape textures: " + ex.Message;
            GD.PushError(ex.ToString());
            return;
        }
        GoTo(42.1, 33.6, "Holtburg");
        // straight into the game, behind your character (; flies the camera about instead)
        if (_player != null && _player.Enter(_cam.Position, 0)) _status = "Holtburg   (; free camera)";
    }

    /// <summary>Identifies something (selecting it too, from the world): the examine panel shows it.</summary>
    private void Identify(ACGodot.Objects.ObjectStreamer.Selectable? sel, bool select)
    {
        if (sel == null) return;
        if (select) _objects?.Select(sel);
        if (sel == _objects?.Self) { IdentifySelf(); return; }
        if (_examine == null) return;
        var f = _combat?.Of(sel);
        _examine.ShowThing(sel, f, sel.Item as ACGodot.Combat.Item);
        // the server's own: asked about (its answer fills the panel in)
        if (_net != null && sel.Item is ACGodot.Net.NetGame.NetObject) _net.Appraise(_net.GuidOf(sel));
        _plugins?.OnIdentified(sel);
    }

    // a drag let go where nothing took it: an item from the pack dropped over the world goes on the ground; a
    // shortcut dragged off the bar is cleared
    public override void _Notification(int what)
    {
        base._Notification(what);
        if (what == NotificationApplicationFocusOut || what == NotificationApplicationFocusIn)
        {
            _windowActive = what == NotificationApplicationFocusIn;
            if (_windowActive) FrameStallOver();
            ApplyBackground();
            return;
        }
        if (what != NotificationDragEnd) return;
        bool taken = GetViewport().GuiIsDragSuccessful();
        var item = ACGodot.Combat.ItemSlot.Dragging;
        var slot = ACGodot.UI.ShortcutBar.DraggingSlot;
        if (!taken)
        {
            bool overWorld = GetViewport().GuiGetHoveredControl() == null;
            // a side pack (or focus) dropped on another place in the pack column: moved there, the rest shifting along
            if (item != null && item.Guid != 0 && _net != null && _combat?.Inv.SidePacks.Contains(item) == true
                && _invPanel?.SideSlotUnder(GetViewport().GuiGetHoveredControl()) is int toSlot && toSlot >= 0)
            {
                _net.MovePack(item, toSlot);
                _invPanel?.Refresh();
                return;
            }
            // one of the server's things dropped on a pack in the inventory's pack column: into that pack
            if (item != null && item.Guid != 0 && _net != null && _invPanel?.PackUnder(GetViewport().GuiGetHoveredControl()) is uint intoPack)
            {
                if (item.Holder != intoPack || item.WornAt != 0) _net.Move(item, intoPack, 0);
                return;
            }
            // one of the server's things dropped on someone in the world (an NPC, another player): given to them
            if (item != null && item.Guid != 0 && overWorld && _net != null && _objects != null
                && _objects.Pick(GetViewport().GetCamera3D(), GetViewport().GetMousePosition()) is { Remote: true } to && to.Type != 19 && !_net.CanCarry(to))
            {
                if (_player?.Active == true && to.Feet.DistanceTo(_player.Position) > 6f) Say($"{to.Name} is too far away to give that to.", new Color(1f, 0.9f, 0.4f));
                else _net.Give(to, item, Math.Max(1, ACGodot.Combat.ItemSlot.Splitting(item)));
                return;
            }
            if (item != null && ACGodot.Combat.ItemSlot.DraggingFrom == "worn" && overWorld && _combat != null && _combat.Inv.Worn.Contains(item))
            {
                // something worn dragged into the world: taken off and dropped
                _combat.Inv.Unequip(item);
                _combat.GearChanged();
                _combat.Inv.Remove(item); _combat.Drop(item); _invPanel?.Refresh();
            }
            else if (item != null && overWorld && item.Guid != 0 && _net != null && _combat != null && _combat.Inv.SidePacks.Contains(item))
            {
                // a side pack dragged into the world: put down, with what's in it (a focus can't be: it stays)
                if (item.Capacity > 0) _net.Drop(item);
                else Status($"The {item.Name} can't be dropped.");
            }
            else if (item != null && ACGodot.Combat.ItemSlot.DraggingFrom == "pack" && overWorld)
            {
                if (_invPanel != null && _combat != null && _combat.Inv.Pack.Contains(item)) { _combat.Inv.Remove(item); _combat.Drop(item); _invPanel.Refresh(); }
                else _packWin?.Drop(item);
            }
            var spellSlot = ACGodot.UI.SpellBar.Dragging;
            if (!taken && spellSlot is { } ss) _spellBar?.ClearSlot(ss.tab, ss.slot);
            ACGodot.UI.SpellBar.Dragging = null;
            if (slot is { } sl) _bar?.ClearSlot(sl.tab, sl.slot);
        }
        // part of a stack split off to drag, and the drag went nowhere (or onto the shortcut bar): back onto its stack
        if (ACGodot.Combat.ItemSlot.SplitFrom is { } whole && item != null && _combat != null && _combat.Inv.Pack.Contains(item) && _combat.Inv.Pack.Contains(whole)
            && (!taken || GetViewport().GuiGetHoveredControl() is ACGodot.UI.ShortcutBar.SlotButton))
        {
            _combat.Inv.StackOnto(item, whole);
            _invPanel?.Refresh();
        }
        ACGodot.Combat.ItemSlot.SplitFrom = null;
        ACGodot.Combat.ItemSlot.Dragging = null;
        ACGodot.UI.ShortcutBar.DraggingSlot = null;
        ACGodot.UI.ShortcutBar.DraggingSpell = null;
    }

    /// <summary>Identifies an item in a pack, a corpse or on the shortcut bar.</summary>
    /// <summary>
    /// The Split Stack key: the stack selected in your packs is split - as many as the control bar's amount box says (half
    /// of it when the box says the whole stack) - the part going to the top of the same pack.
    /// </summary>
    private void SplitSelected()
    {
        var inv = _combat?.Inv;
        var it = _selItem;
        if (inv == null || it == null || it.Stack < 2) { _status = "Split Stack: select a stack in your pack first"; return; }
        bool ours = inv.Pack.Contains(it) || (it.Holder != 0 && inv.SidePacks.Exists(p => p.Guid == it.Holder));
        if (!ours) { _status = "Split Stack: only a stack in your own packs"; return; }
        int n = _controlBar?.SplitAmount ?? 0;
        if (n <= 0 || n >= it.Stack) n = it.Stack / 2;
        if (it.Guid != 0)
        {
            if (_net == null) return;
            _net.Split(it, it.Holder, 0, n);
        }
        else if (inv.Split(it, n) == null) { _status = "Split Stack: no room in the pack"; return; }
        _status = $"Split {n} off {it.Name}";
    }

    public void IdentifyItem(ACGodot.Combat.Item item) { _selItem = item; _examine?.ShowItem(item); _plugins?.OnIdentified(item); }   // (identifying picks it, as the game does)

    private void GoTo(double ns, double ew, string name)
    {
        Vector3 p = World.FromMapCoords(ns, ew);
        float ground = _terrain?.HeightAt(p) ?? 60f;
        _cam.Position = new Vector3(p.X, ground + 40f, p.Z);
        _cam.LookAtYawPitch(0, -20);
        _status = name;
        _start = _cam.Position;
        if (_player?.Active == true) _player.Enter(_cam.Position, 0);   // playing: the character goes there
    }

    private readonly List<ACGodot.Objects.ObjectStreamer.Selectable> _radarThings = new();
    private ACGodot.Objects.ObjectStreamer.Selectable? _selNow, _selBefore;

    /// <summary>A gesture done once (a wave), or a pose held while standing still (sitting; the same again stands up).</summary>
    private void DoMotion(uint command)
    {
        if (_player?.Active != true) return;
        const uint Ready = 0x41000003;
        _player.PoseEnded ??= () => _net?.SendMotion(Ready);
        if ((command & 0x40000000u) != 0)
        {
            _player.Pose = command == Ready || _player.Pose == command ? 0 : command;
            _net?.SendMotion(_player.Pose == 0 ? Ready : command);
        }
        else
        {
            if (_player.Pose != 0) { _player.Pose = 0; _net?.SendMotion(Ready); }
            _player.PlayAction(command, 1f);
            _net?.SendMotion(command);
        }
    }

    public override void _UnhandledInput(InputEvent e)
    {
        // left click: select what's under the mouse (as in the game)
        // a precise jump being set up: a click aims it at the spot clicked
        if (e is InputEventMouseButton { Pressed: true, ButtonIndex: MouseButton.Left } jumpClick && _player?.PreciseJump == true && GetViewport().GetCamera3D() is { } jumpCam)
        {
            string said = _player.AimJumpAt(jumpCam, jumpClick.Position);
            if (said.Length > 0) { _status = said; Say(said, new Color(0.7f, 0.85f, 1f)); }
            GetViewport().SetInputAsHandled();
            return;
        }
        if (e is InputEventMouseButton { Pressed: true, ButtonIndex: MouseButton.Left } click && _objects != null && !_goto.Visible)
        {
            GetViewport().GuiReleaseFocus();   // a click in the world: the keys are the game's again
            // what someone holds - a monster's weapon, another player's - right under the mouse: that, looked at as an item
            // (a left click selects it; a right click looks at it)
            if (_net?.InWorld == true && _net.HeldAt(GetViewport().GetCamera3D(), click.Position) is { } heldItem)
            {
                PickItem(heldItem);
                _status = $"selected: {heldItem.Name}";
                return;
            }
            var sel = _objects.Pick(GetViewport().GetCamera3D(), click.Position);
            // choosing a target, and clicked nothing (a wall, the floor): that's a cancel, as in the game
            if (sel == null && _useSource is { } stopUse) { StopUsing(stopUse); return; }
            // on you, with nothing nearer the eye there: yourself (to cast on, to give to, to look at)
            if (_player?.Active == true && MeBefore(sel, click.Position)) { sel = _objects.Self; if (click.DoubleClick) { _objects.Select(sel); return; } }
            _objects.Select(sel);
            // a double-click uses it: an item on the ground is picked up, a corpse or chest opened, a door swung
            if (click.DoubleClick && sel != null && _player?.Active == true && _combat != null)
            {
                _useWhy = "a double-click";
                if (sel.Item != null) PickUpSelected();
                else UseSelected();
                return;
            }
            _status = sel == null ? "nothing selected" : $"selected: {sel.Name}" + (sel.Type == 19 ? "   R: open / shut" : "");
            return;
        }
        if (e is not InputEventKey { Pressed: true, Echo: false } k) return;
        if (_goto.Visible) { if (k.Keycode == Key.Escape) { _goto.Visible = false; GetViewport().SetInputAsHandled(); } return; }
        if (k.Keycode == Key.Escape && _player?.PreciseJump == true) { _player.CancelPrecise(); GetViewport().SetInputAsHandled(); return; }   // (a precise jump called off)
        if (k.Keycode == Key.Escape && _useSource is { } escUse) { StopUsing(escUse); GetViewport().SetInputAsHandled(); return; }
        bool playing = _player?.Active == true;
        bool A(string name) => KeyMap.Is(k, name);
        // talking: Enter (a /command starts with the slash)
        if (_chat != null && A("ChatCommands.EnterChatMode")) { _chat.StartTyping(); GetViewport().SetInputAsHandled(); return; }
        if (_chat != null && A("ACGodot.ChatSlash")) { _chat.StartTyping("/"); GetViewport().SetInputAsHandled(); return; }
        if (_chat == null && k.Keycode is Key.Enter or Key.Slash) { _goto.Text = ""; _goto.Visible = true; _goto.GrabFocus(); GetViewport().SetInputAsHandled(); return; }
        // the quick slots (in magic combat, the spell bar's)
        if (_bar != null && playing)
        {
            for (int n = 1; n <= 18; n++)
            {
                if (n <= 9 && _combat?.MagicMode == true && _spellBar != null && !k.CtrlPressed && !k.AltPressed && A("MagicCombat.UseSpellSlot_" + n)) { _spellBar.Activate(n - 1); return; }
                if (A("QuickslotCommands.UseQuickSlot_" + n)) { _bar.Activate(n - 1); return; }
            }
            if (A("QuickslotCommands.CreateShortcut"))
            {
                if (_selItem is { } si) Status(_bar.Add(new ACGodot.UI.ShortcutBar.Entry("item", si.Wcid, si.Name, si.Icon, si.Guid)) ? $"{si.Name} added to the shortcut bar" : "The shortcut bar is full.");
                return;
            }
        }
        // the panels
        if (A("UICommands.ToggleWorldPanel") && _map != null && playing) { _map.Toggle(); return; }
        if (A("UICommands.ToggleSpellbookPanel") && playing)
        {
            if (_bookPanel != null) _bookPanel.Toggle();
            else if (_spellbook != null) { if (_spellbook.Visible) _spellbook.Visible = false; else _spellbook.Open(); }
            return;
        }
        if ((A("UICommands.ToggleOptionsPanel") || A("ACGodot.OptionsPanel")) && (_options != null || _optionsPanel != null)) { ToggleOptions(); return; }
        if ((A("UICommands.ToggleAttributesPanel") || A("UICommands.ToggleSkillsPanel")) && playing)
        {
            if (_charPanel != null) _charPanel.Toggle();
            else if (_charWin != null && _combat != null) { _charWin.Visible = !_charWin.Visible; if (_charWin.Visible) _charWin.Show(_combat.Me); }
            return;
        }
        if (A("UICommands.ToggleInventoryPanel") && playing)
        {
            if (_invPanel != null) _invPanel.Toggle();
            else if (_packWin != null && _combat != null)
            {
                _packWin.Visible = !_packWin.Visible;
                if (_packWin.Visible)
                {
                    _packWin.Position = new Vector2(GetViewport().GetVisibleRect().Size.X - 360, 120);
                    _packWin.Show(_combat.Inv, id => _objects!.Assets.Icon(id));
                }
            }
            return;
        }
        if ((A("UICommands.ToggleAllegiancePanel") || A("UICommands.ToggleFellowshipPanel")) && playing) { _socialPanel?.Toggle(); return; }
        if (A("UICommands.LOGOUT")) { _net?.LogOut(); return; }
        if (A("UICommands.EscapeKey"))
        {
            // a side panel open (the backpack, spellbook, character, options, quests...): Esc shuts it. None open: the options,
            // on their first page (with the Exit button) - not out of the game on one key press
            var openPanel = ACGodot.UI.SidePanel.All.FirstOrDefault(p => p.Visible && IsInstanceValid(p));
            if (openPanel != null) { openPanel.Toggle(); return; }
            if (_options == null && _optionsPanel == null) GetTree().Quit();
            else if (_optionsPanel != null) _optionsPanel.Show(0);
            else ToggleOptions();
            return;
        }
        if (A("UICommands.USE")) { _useWhy = "the Use key"; UseSelected(); return; }
        // selecting
        if (A("ItemSelectionCommands.SelectionPickUp"))
        {
            // the item highlighted in a corpse or chest: take it; else pick up the selected item off the ground
            if (_lootWin is { Visible: true, Selected: { } lootItem }) _lootWin.TakeIt(lootItem);
            else PickUpSelected();
            return;
        }
        if (A("ItemSelectionCommands.SelectionSplitStack")) { if (playing) SplitSelected(); return; }
        if (A("ItemSelectionCommands.SelectionNextMonster") || A("ItemSelectionCommands.SelectionPreviousMonster"))
        {
            if (_player == null) { _status = "no player: the creature data isn't loaded"; return; }
            // the next enemy (the nearest first): round you, or round the camera while flying it about
            if (_combat != null) _status = _combat.NextTarget(_player.Active ? null : _cam.Position);
            GetViewport().SetInputAsHandled();
            return;
        }
        if (A("ItemSelectionCommands.SelectionClosestMonster")) { if (_combat != null && playing) _status = _combat.NearestTarget(); return; }
        if (A("ItemSelectionCommands.SelectionClosestItem")) { if (_combat != null && playing) _status = _combat.NearestItem(); return; }
        if (A("ItemSelectionCommands.SelectionPreviousItem")) { if (_combat != null && playing) _status = _combat.CycleItem(-1); return; }
        if (A("ItemSelectionCommands.SelectionNextItem")) { if (_combat != null && playing) _status = _combat.CycleItem(1); return; }
        // what's on the radar (the compass), other players, your fellows, and what was selected before
        if (playing && _objects != null)
        {
            var me = _player!.Position;
            List<ACGodot.Objects.ObjectStreamer.Selectable> Near(IEnumerable<ACGodot.Objects.ObjectStreamer.Selectable> from) => from.Where(x => !x.Gone).OrderBy(x => x.Feet.DistanceSquaredTo(me)).ToList();
            bool Step(string closest, string previous, string next, Func<List<ACGodot.Objects.ObjectStreamer.Selectable>> list, string none)
            {
                int step = A(closest) ? 0 : A(previous) ? -1 : A(next) ? 1 : 2;
                if (step == 2) return false;
                var l = list();
                if (l.Count == 0) { Status(none); return true; }
                int at = _objects.Selected != null ? l.IndexOf(_objects.Selected) : -1;
                var pick = step == 0 ? l[0] : at < 0 ? (step > 0 ? l[0] : l[^1]) : l[(at + step + l.Count) % l.Count];
                _objects.Select(pick);
                _status = $"selected: {pick.Name}";
                return true;
            }
            if (Step("ItemSelectionCommands.SelectionClosestCompassItem", "ItemSelectionCommands.SelectionPreviousCompassItem", "ItemSelectionCommands.SelectionNextCompassItem",
                     () => Near(_radarThings), "Nothing on the radar.")) return;
            if (Step("ItemSelectionCommands.SelectionClosestPlayer", "ItemSelectionCommands.SelectionPreviousPlayer", "ItemSelectionCommands.SelectionNextPlayer",
                     () => Near(_objects.AllSelectables.Where(x => x.Kind >= 3)), "No other players nearby.")) return;
            if (Step("-", "ItemSelectionCommands.SelectionPreviousFellow", "ItemSelectionCommands.SelectionNextFellow",
                     () => Near(_net == null ? Enumerable.Empty<ACGodot.Objects.ObjectStreamer.Selectable>() : _net.Fellows.Select(f => _net.ThingAt(f.Id)).Where(x => x != null)!),
                     _net?.FellowshipName.Length > 0 ? "None of your fellows are nearby." : "You aren't in a fellowship.")) return;
            if (A("ItemSelectionCommands.SelectionPreviousSelection"))
            {
                if (_selBefore is { Gone: false } before) { _objects.Select(before); _status = $"selected: {before.Name}"; } else Status("Nothing was selected before.");
                return;
            }
        }
        if (A("UICommands.ToggleSpellComponentsPanel") && playing) { _bookPanel?.ToggleComponents(); return; }
        // gestures and poses (the server shows them to everyone near)
        if (playing)
        {
            foreach (var (name, _, command) in KeyMap.Motions)
                if (A(name)) { DoMotion(command); return; }
        }
        // combat
        if (A("Combat.CombatToggleCombat")) { if (_combat != null && playing) _status = _combat.ToggleCombat(); return; }
        if (A("MeleeCombat.CombatHighAttack") || A("MissileCombat.CombatAimHigh")) { if (_combat != null && playing) _status = _combat.AttackKey(0); return; }
        if (A("MeleeCombat.CombatMediumAttack") || A("MissileCombat.CombatAimMedium") || A("MagicCombat.CombatCastCurrentSpell")) { if (_combat != null && playing) _status = _combat.AttackKey(1); return; }
        if (A("MeleeCombat.CombatLowAttack") || A("MissileCombat.CombatAimLow")) { if (_combat != null && playing) _status = _combat.AttackKey(2); return; }
        if (A("MeleeCombat.CombatDecreaseAttackPower") || A("MissileCombat.CombatDecreaseMissileAccuracy")) { if (_combat != null && _combat.CombatMode) _status = _combat.ChangePower(-0.1f); return; }
        if (A("MeleeCombat.CombatIncreaseAttackPower") || A("MissileCombat.CombatIncreaseMissileAccuracy")) { if (_combat != null && _combat.CombatMode) _status = _combat.ChangePower(0.1f); return; }
        // ACGodot's own (none of them the game's): the free camera, the hour, and things for looking into problems
        if (A("ACGodot.FreeCamera"))
        {
            if (_player == null) { _status = "no player: the creature data isn't loaded"; return; }
            if (_player.Active) { _player.Leave(); _status = "free camera (the same keys to play)"; }
            else _status = _player.Enter(_cam.Position, _cam.Yaw) ? "playing" : "couldn't make the player";
            return;
        }
        if (A("ACGodot.DebugText")) { _hud.Visible = !_hud.Visible; SaveDebugShown(); return; }
        if (A("ACGodot.HourBack")) { _sky?.ShiftHours(-1); return; }
        if (A("ACGodot.HourOn")) { _sky?.ShiftHours(1); return; }
        if (A("ACGodot.GoHoltburg")) { GoTo(42.1, 33.6, "Holtburg"); return; }
        if (A("ACGodot.GoYaraq")) { GoTo(-21.5, -1.8, "Yaraq"); return; }
        if (A("ACGodot.GoShoushi")) { GoTo(-33.6, 72.8, "Shoushi"); return; }
        if (A("ACGodot.GoArwic")) { GoTo(33.6, 56.8, "Arwic"); return; }
        if (A("ACGodot.CameraToGround")) { if (_terrain?.HeightAt(_cam.Position) is float h) _cam.Position = new Vector3(_cam.Position.X, h + 1.8f, _cam.Position.Z); return; }
        if (A("ACGodot.Culling")) { if (_objects != null) _status = _objects.CycleCulling(); return; }
        if (A("ACGodot.Beacons")) { if (_objects != null) _status = _objects.ToggleBeacons(); return; }
        if (A("ACGodot.Showcase"))
        {
            if (_objects != null && _terrain != null)
            {
                Vector3 from = playing ? _player!.Position : _cam.Position;
                float yaw = playing ? _player!.Heading : _cam.Yaw;
                _status = _objects.Showcase(from, yaw, p => _terrain.GroundAt(p));
            }
            return;
        }
        if (A("ACGodot.HideBuildings")) { if (_objects != null) _status = _objects.CycleHide(); return; }
        if (A("ACGodot.SkyLayers")) { if (_sky != null) _status = _sky.StepHidden(); return; }
        if (A("ACGodot.Openings")) { if (_objects != null) _status = _objects.ToggleOpenings(); return; }
        if (A("ACGodot.ExportInterface")) { if (_dats != null) _status = ACGodot.UI.UiExport.Export(_dats, ProjectSettings.GlobalizePath("res://capture/ui.zip")); return; }
        if (A("ACGodot.Capture"))
        {
            // save the recent movement and the collision data around the player, to look into a collision problem
            if (_player != null)
            {
                _status = _player.SaveCapture(ProjectSettings.GlobalizePath("res://capture"));
                // and the creatures around (where each stands, its room, its size) - to replay how they move
                try
                {
                    var lines = new List<string> { "# name;feetAc x y z;cell;homeCell;radius;height;lbx;lby;index;state;last step;held up" };
                    foreach (var s in _objects!.AllSelectables)
                        if (s.Fight is ACGodot.Combat.Fighter f && s.Feet.DistanceTo(_player.Position) < 40f)
                        {
                            var (x, y, z) = World.ToAc(s.Feet);
                            lines.Add(string.Join(";", s.Name, $"{x:0.###} {y:0.###} {z:0.###}", $"{f.Cell:X8}", $"{f.HomeCell:X8}", s.Radius.ToString("0.###"),
                                                  (s.Top - s.Feet.Y).ToString("0.###"), s.Lb.x, s.Lb.y, s.Index, f.St, f.LastStep, $"held {f.Moving:0.0}s"));
                        }
                    System.IO.File.WriteAllLines(System.IO.Path.Combine(ProjectSettings.GlobalizePath("res://capture"), "creatures.txt"), lines);
                }
                catch (Exception ex) { GD.PushWarning("creature capture: " + ex.Message); }
            }
            return;
        }
    }

    private void OnGotoSubmitted(string text)
    {
        _goto.Visible = false;
        _goto.ReleaseFocus();
        string t = text.Trim().ToUpperInvariant().Replace("0X", "");
        if (t.Length == 0) return;
        // map coordinates: "42.1N 33.6E", "42.1N, 33.6E"
        var m = System.Text.RegularExpressions.Regex.Match(t, @"^([\d.]+)\s*([NS])[\s,]+([\d.]+)\s*([EW])$");
        if (m.Success)
        {
            double ns = double.Parse(m.Groups[1].Value, System.Globalization.CultureInfo.InvariantCulture) * (m.Groups[2].Value == "S" ? -1 : 1);
            double ew = double.Parse(m.Groups[3].Value, System.Globalization.CultureInfo.InvariantCulture) * (m.Groups[4].Value == "W" ? -1 : 1);
            GoTo(ns, ew, $"{text.Trim()}");
            return;
        }
        if (!System.Text.RegularExpressions.Regex.IsMatch(t, "^[0-9A-F]{4}([0-9A-F]{4})?$") || _dats == null) { _status = "Didn't understand: " + text; return; }
        uint id = uint.Parse(t, System.Globalization.NumberStyles.HexNumber);
        if (t.Length == 4) id = (id << 16) | 0xFFFF;
        int lx = (int)(id >> 24), ly = (int)((id >> 16) & 0xFF);
        uint low = id & 0xFFFF;
        if (low >= 0x0100 && low < 0xFFFE)
        {
            var cell = _dats.Cell<DatReaderWriter.DBObjs.EnvCell>(id);
            if (cell == null) { _status = $"No cell 0x{id:X8}"; return; }
            // the middle of the room's floor (its origin can be outside it - at a wall, or in the next room)
            var o = Physics.CellSpawn.FloorPoint(eid => _dats.Get<DatReaderWriter.DBObjs.Environment>(eid), cell);
            _cam.Position = World.ToGodot(lx * World.LandblockSize + o.X, ly * World.LandblockSize + o.Y, o.Z + 1.6f);
            _cam.LookAtYawPitch(0, 0);
            _cam.Speed = 6f;
            _status = $"cell 0x{id:X8}";
            if (_player?.Active == true) _player.Enter(_cam.Position - new Vector3(0, 1.5f, 0), 0, id);   // into the cell: they settle onto its floor
            return;
        }
        // a dungeon's landblock (rooms, but no buildings on the landscape): into its first room, not onto the landscape over it
        var info = _dats.Cell<DatReaderWriter.DBObjs.LandBlockInfo>((id & 0xFFFF0000u) | 0xFFFEu);
        if (info != null && info.NumCells > 0 && info.Buildings.Count == 0)
        {
            OnGotoSubmitted($"{(id & 0xFFFF0000u) | 0x0100u:X8}");
            _status = $"dungeon 0x{lx:X2}{ly:X2} (" + _status + ")";
            return;
        }
        Vector3 p = World.ToGodot(lx * World.LandblockSize + 96f, ly * World.LandblockSize + 96f, 0);
        float ground = _terrain?.HeightAt(p) ?? 60f;
        _cam.Position = new Vector3(p.X, ground + 40f, p.Z);
        _cam.LookAtYawPitch(0, -20);
        _status = $"landblock 0x{lx:X2}{ly:X2}";
        if (_player?.Active == true) _player.Enter(_cam.Position, 0);
    }

    private double _abandonAskedAt = -100;
    private bool _houseAnswerShown;

    // the window's title: who's playing (at the login screen, just that it's there)
    private string _title = "";
    private double _titleAt;
    private void UpdateTitle()
    {
        double now = Time.GetTicksMsec() / 1000.0;
        if (now < _titleAt) return;
        _titleAt = now + 0.5;
        string? who = _net?.InWorld == true ? _net.Character?.Name : null;
        string t = string.IsNullOrEmpty(who) ? "ACGodot - Login" : "ACGodot - " + who;
        if (t == _title) return;
        _title = t;
        try { DisplayServer.WindowSetTitle(t); } catch { }
    }

    // MelksQB's travel file changed (a portal learned): the map read again, a few seconds after (it may write more than once)
    private DateTime _travelSeen = DateTime.MinValue;
    private double _travelCheckAt, _travelChangedAt = -1;
    private void WatchTravel()
    {
        if (_map == null) return;
        double now = Time.GetTicksMsec() / 1000.0;
        if (now < _travelCheckAt) return;
        _travelCheckAt = now + 3;
        try
        {
            string f = ACGodot.Map.MapData.LiveTravel;
            if (!System.IO.File.Exists(f)) return;
            var t = System.IO.File.GetLastWriteTimeUtc(f);
            if (_travelSeen == DateTime.MinValue) { _travelSeen = t; return; }
            if (t != _travelSeen) { _travelSeen = t; _travelChangedAt = now; return; }
            if (_travelChangedAt >= 0 && now - _travelChangedAt >= 3)
            {
                _travelChangedAt = -1;
                _map.Reload(ACGodot.Map.MapData.Load(ProjectSettings.GlobalizePath("res://data/map")));
            }
        }
        catch (Exception ex) { GD.PushWarning("map reload: " + ex.Message); }
    }

    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("Main");
        ACGodot.UI.ChatColors.Tick();
        CheckFocus(delta);
        // the settings (ui.cfg, map, spell bars, keymap, character...) copied into ACGodot's Backup folder now and then
        ACGodot.Backups.Tick(ProjectSettings.GlobalizePath("user://").TrimEnd('/'), SettingsFile, null, ProjectSettings.GlobalizePath("res://Backup"));
        UpdateTitle();
        WatchTravel();
        // logging out: nothing moves or acts until the server's done (a plugin running everywhere, swinging at things...)
        if (_player != null)
        {
            bool leaving = _net?.LoggingOut == true;
            if (leaving && !_player.Leaving) { _player.StopMoving(); _combat?.CancelAttack(); }
            _player.Leaving = leaving;
        }
        WalkIntoPortals(delta);
        UseOnceFacing();
        ShutOncePickedUp();
        TakeQueuedLoot();
if (_bookRefresh) { _bookRefresh = false; _bookPanel?.Refresh(); }
                UseOnNextChosen();
                CursorFixTick();
                TestBridgeTick(delta);
        // walked away from the corpse (or chest) that's open: its window shuts - as the vendor's does
        // (from where you stood when it opened: opened from its very edge - as the server allows - it isn't shut straight away)
        if (_lootWin is { Visible: true } && _player?.Active == true && _net is { OpenContainer: not 0 } lnet
            && lnet.ThingAt(lnet.OpenContainer) is { Gone: false } box)
        {
            float d = box.Feet.DistanceTo(_player.Position);
            if (lnet.OpenContainer != _lootBoxGuid) { _lootBoxGuid = lnet.OpenContainer; _lootOpenDist = d; }
            if (d > Math.Max(4f, _lootOpenDist + 2f)) _lootWin.Visible = false;
        }
        else if (_lootWin is not { Visible: true }) _lootBoxGuid = 0;
        // walked away from the vendor: their window shuts
        if (_vendorWin?.Vendor is { } shop && _player != null && (_net?.ThingAt(shop.Guid) is not { Gone: false } keeper || keeper.Feet.DistanceTo(_player.Position) > 6f)) _vendorWin.Visible = false;
        if (_objects != null && _player != null) _objects.PlaceSelf(_player.Position, _combat?.Me.Name ?? "you");
        if (_combatHud != null) { _combatHud.JumpCharge = _player?.Active == true ? _player.JumpCharge : -1f; _combatHud.JumpNote = _player?.Active == true ? _player.JumpNote : ""; }
        // in a dungeon: only its landblock (the next dungeons over in the grid are other places)
        if (_objects != null)
            _objects.OnlyLandblock = _player?.Active == true && _objects.IsDungeonCell(_player.Cell)
                ? ((int)(_player.Cell >> 24), (int)((_player.Cell >> 16) & 0xFF)) : null;
        ACGodot.FrameWatch.Enter("Main: world streaming");
        _terrain?.Follow(_cam.Position);
        if (_objects != null && _player != null) _objects.KeepCell = _player.Cell;
        _objects?.Follow(_cam.Position);
        // in a dungeon there's no outside: no landscape, no sky, no fog - just the dark, as in the game
        // (playing: by the room they're in - the camera can be up over the walls - else by where the camera is)
        bool under = _objects != null && (_player?.Active == true && _player.Cell != 0
            ? _objects.IsDungeonCell(_player.Cell) : _objects.InDungeon(_cam.Position));
        // deep in a cave or a cellar (rooms the outside can't be seen from, or well under the ground): the same - and what
        // stands on the landscape above (buildings' outsides and their footings, trees) isn't drawn through the rock
        bool deep = false;
        if (_objects != null && _player?.Active == true && (_player.Cell & 0xFFFF) >= 0x100 && (_player.Cell & 0xFFFF) < 0xFFFE && !under)
            deep = _objects.IsDeepCell(_player.Cell) || (_terrain?.GroundAt(_player.Position) is float gy && _player.Position.Y < gy - 1.5f);
        if (_objects != null) _objects.OutsideHidden = deep;
        _deepNow = deep;
        under |= deep;
        if (under != _underground)
        {
            _underground = under;
            
            if (under)
            {
                _env.BackgroundColor = Colors.Black;
                _env.FogEnabled = false;
                _env.AmbientLightColor = new Color(0.55f, 0.55f, 0.55f);
            }
        }
        if (_terrain != null) _terrain.Visible = !under && !_terrainHidden;
        ACGodot.UI.Video.Underground = under;
        if (_far != null)
        {
            _far.Visible = !under && !_terrainHidden;
            if (_terrain != null) _far.Near = _terrain.Radius;
            if (_far.Visible) _far.Follow(_cam.Position);
        }
        if (_farScenery != null)
        {
            _farScenery.Visible = !under && !_terrainHidden;
            if (_objects != null) _farScenery.Near = _objects.Radius;
            if (_terrain != null) _farScenery.Land = _terrain.Radius;
            if (_farScenery.Visible) _farScenery.Follow(_cam.Position);
        }
        // the game's own lights (lamps, torches) and the soft light around your character; moving textures
        ACGodot.Effects.Lamps.Update(_sky?.Daylight ?? 1f, under || (_objects?.CameraInBuilding ?? false), this,
                                     _player?.Active == true ? _player.Position : _cam.Position);
        ACGodot.FrameWatch.Enter("Main: sky");
        if (_sky != null)
        {
            // no weather inside buildings (seen from in or out)
            _sky.Indoors = _objects?.CameraInBuilding ?? false;
            _sky.NoWeather = _net?.OptionsRead == true && _net.Option("DisableMostWeatherEffects");
            if (_objects != null) _sky.SetRooms(_objects.RoomsNear(_cam.Position, 40f, Sky.SkyController.MaxRooms));
        }
        _sky?.Update(_cam.Position, under);
        if (_audio != null)
        {
            // the landscape's sounds around whoever is listening: the character when playing, else the camera
            var (ax, ay, az) = World.ToAc(_player?.Active == true ? _player.Position : _cam.Position);
            _audio.Update(delta, new System.Numerics.Vector3(ax, ay, az), under || (_objects?.CameraInBuilding ?? false));
        }
        ACGodot.FrameWatch.Enter("Main: radar");
        UpdateRetailHud();
        ACGodot.FrameWatch.Enter("Main: particles");
        if (_particles != null) _particles.CameraIndoors = under || (_objects?.CameraInBuilding ?? false);
        _particles?.Step(delta, _cam.Position);
        ACGodot.FrameWatch.Enter("Main: hud text");
        var (lx, ly) = World.LandblockAt(_cam.Position);
        _hud.Text = $"ACGodot - world viewer   {Engine.GetFramesPerSecond()} fps\n" +
                    $"{World.MapCoords(_cam.Position)}   landblock 0x{lx:X2}{ly:X2}   height {_cam.Position.Y:0}m   speed {_cam.Speed:0} m/s\n" +
                    (_terrain != null ? $"landblocks {_terrain.Loaded} (building {_terrain.Pending})" : "") +
                    (_objects != null ? $"   objects {_objects.Instances} on {_objects.Loaded} landblocks (building {_objects.Pending}), {_objects.Assets.MeshCount} models, {_objects.Creatures} creatures/NPCs/objects" +
                                         (_particles != null ? $", {_particles.Emitters} effects ({_particles.Particles} particles)" : "") + "\n" : "\n") +
                    (_player?.Active == true ? "Right mouse: look   WASD: run / back / side-step   Shift: walk   G: auto-run   Space: jump (hold: higher)   click: select   R: use   Wheel: zoom   ; free camera\n` combat mode   Tab: next enemy   PgDn/End/Del: attack high/med/low    ': nearest   Ins/PgUp: power   C: character   I: inventory   F: pick up   \\ [ ]: items   " + _player.PhysicsText + "\n"
                                              : "Right mouse: look   WASD: move   Space/C: up/down   Shift: fast   Wheel: speed   Tab: next monster   ;: play\n") +
                    "F1 Holtburg  F2 Yaraq  F3 Shoushi  F4 Arwic  F5 to the ground  F7 find creatures  K show creature kinds  Enter: go to...  Esc options (Exit is there)\n" +
                    (_sky != null ? _sky.Text + "\n" : "") + _status;
    }

    /// <summary>The radar and vitals: where you are, what's around, your health, stamina and mana.</summary>
    private bool _deepNow;
    private void UpdateRetailHud()
    {
        if (_retail == null || _combat == null || _player == null || _objects == null) return;
        // the radar stays up flying the free camera too (centred on the camera, turned its way)
        _retail.Visible = true;
        _combatHud.RetailVitals = _retail.Visible && _retail.Ready2;
        bool playing = _player.Active;
        var camFwd = -_cam.GlobalTransform.Basis.Z;
        float heading = playing ? _player.Heading : MathF.Atan2(-camFwd.X, -camFwd.Z);
        Vector3 here = playing ? _player.Position : _cam.Position;
        // how far the radar sees: less indoors (a building's rooms or a dungeon)
        var at0 = here;
        bool inRoom = playing && (_player.Cell & 0xFFFF) >= 0x100 && (_player.Cell & 0xFFFF) < 0xFFFE;
        bool inside = inRoom || _objects.InBuilding(at0) != null || _objects.InDungeon(at0);
        _retail.Indoors = inside;
        float Reach = (inside ? 18f : 60f) / _retail.Zoom;   // (the radar's + and -: one zoom indoors, one outdoors)
        _retail.Range = Reach;
        var at = here;
        // the game's colours: monsters orange, people (NPCs) yellow, portals purple, lifestones blue (players white, player killers red)
        var blips = new List<(Vector2, Color, object)>();
        foreach (var s in _objects.AllSelectables)
        {
            if (s.Gone || s.Type is not (10 or 12 or 7 or 25) || s.Node is { Visible: false }) continue;
            var d = s.Feet - at;
            if (Math.Abs(d.X) > Reach || Math.Abs(d.Z) > Reach) continue;
            // underground: not what's up on the surface (or in the passage a floor up or down)
            if (_deepNow && s.Cell == 0) continue;
            if (inRoom && Math.Abs(d.Y) > 7f) continue;
            if (s.Fight is ACGodot.Combat.Fighter { St: ACGodot.Combat.Fighter.State.Dead }) continue;
            Color c = s.Type == 7 ? new Color(0.75f, 0.35f, 1f)
                    : s.Type == 25 ? new Color(0.3f, 0.55f, 1f)   // lifestones
                    : s.Kind == 3 ? new Color(0.95f, 0.95f, 0.95f) : s.Kind == 4 ? new Color(1f, 0.15f, 0.15f) : s.Kind == 5 ? new Color(1f, 0.6f, 0.8f)   // other players
                    : s.Type == 10 && _combat.Of(s) != null ? new Color(1f, 0.55f, 0.1f)
                    : new Color(1f, 0.92f, 0.25f);
            if (ACGodot.UI.NameTags.RadarColorOf(s) is Color tagColor) c = tagColor;   // (Options > Name tags: the radar uses these colours)
            blips.Add((new Vector2(d.X, d.Z) / Reach, c, s));
        }
        var me = _combat.Me;

        // the map: walls on the floor you're on (from a little below your feet to a little above)
        var walls = new List<(Vector2, Vector2)>();
        // in a dungeon or a cave: the same clean walls as the dungeon map (what you bump into, each wall one line) for the
        // rooms whose floor you're level with
        ACGodot.Map.DungeonLayout? lay = inRoom && _map != null && _dats != null && _map.CurrentDungeon >= 0
            ? ACGodot.Map.DungeonLayout.Of(_dats, (int)(_player.Cell >> 16)) : null;
        if (lay != null)
        {
            for (int wi = 0; wi < lay.Walls.Count && wi < lay.WallHeights.Count; wi++)
            {
                var (low, high) = lay.WallHeights[wi];
                if (at.Y < low - 1.5f || at.Y > high + 2.5f) continue;
                var (wa, wb, _) = lay.Walls[wi];
                var ga = new Vector2((wa.X + 101.95f) * 240f - at.X, -(wa.Y + 101.95f) * 240f - at.Z);
                var gb = new Vector2((wb.X + 101.95f) * 240f - at.X, -(wb.Y + 101.95f) * 240f - at.Z);
                if (MathF.Min(MathF.Abs(ga.X), MathF.Abs(gb.X)) > Reach + 5f || MathF.Min(MathF.Abs(ga.Y), MathF.Abs(gb.Y)) > Reach + 5f) continue;
                walls.Add((ga / Reach, gb / Reach));
            }
        }
        else foreach (var (a, b, y) in _objects.MapLinesNear(at, Reach))
        {
            // (a cave's floor rises and falls: its walls start anywhere along the slope)
            if (y < at.Y - (_deepNow ? 3.5f : 1.2f) || y > at.Y + (_deepNow ? 2.5f : 1.5f)) continue;
            walls.Add((new Vector2(a.X - at.X, a.Y - at.Z) / Reach, new Vector2(b.X - at.X, b.Y - at.Z) / Reach));
        }
        if (_objects.Selected != _selNow) { if (_selNow != null) _selBefore = _selNow; _selNow = _objects.Selected; }
        _radarThings.Clear(); foreach (var (_, _, what) in blips) if (what is ACGodot.Objects.ObjectStreamer.Selectable rs) _radarThings.Add(rs);
        _retail.Show(World.MapCoords(at), heading, blips, walls, _objects.Selected, _combat.Health, me.MaxHealth, me.Stamina, me.MaxStamina, me.Mana, me.MaxMana);
        _arrow?.Update(at, heading, GetViewport().GetVisibleRect().Size);
        float limit = _retail.VitalsTop;
        if (_bar != null)
        {
            _bar.Visible = true;
            _bar.Place(GetViewport().GetVisibleRect().Size, limit);
            if (!_bar.Moved) limit = Math.Min(limit, _bar.Top);
        }
        _combatHud.BottomLimit = limit;
        UpdateRetailPanels();
        UpdateWalkTo();
    }

    /// <summary>Whether a screen point is on your own character.</summary>
    /// <summary>Whether a click there is on you and not on what was picked: you're under it, and nearer the eye than that is
    /// (a monster or a door beyond you, in line with you, was taken for what you clicked).</summary>
    private bool MeBefore(ACGodot.Objects.ObjectStreamer.Selectable? picked, Vector2 at)
    {
        // something else under the mouse: you only when the click is squarely on your body (not the air just over
        // your head or beside your shoulders, where what's in front of you shows)
        if (!OnMe(at, picked == null ? 1f : 0.7f)) return false;
        if (picked == null) return true;
        var cam = GetViewport().GetCamera3D();
        if (cam == null || _player == null) return false;
        Vector3 eye = cam.GlobalPosition;
        return eye.DistanceTo(_player.Position + new Vector3(0, 0.9f, 0)) < eye.DistanceTo(picked.Center);
    }

    private bool OnMe(Vector2 at, float size = 1f)
    {
        var cam = GetViewport().GetCamera3D();
        if (_player == null || cam == null) return false;
        // your body: feet to the top of your head (1.7 m), a box as wide as you - no rounded cap reaching up over your head
        Vector3 feet = _player.Position, top = feet + new Vector3(0, 1.7f * size, 0);
        if (cam.IsPositionBehind(feet) || cam.IsPositionBehind(top)) return false;
        Vector2 a = cam.UnprojectPosition(feet), b = cam.UnprojectPosition(top);
        Vector3 mid = feet + new Vector3(0, 0.9f, 0);
        float r = Math.Max(cam.UnprojectPosition(mid).DistanceTo(cam.UnprojectPosition(mid + cam.GlobalTransform.Basis.X * 0.32f * size)), 6f);
        Vector2 ab = b - a;
        if (ab.LengthSquared() <= 1e-4f) return a.DistanceTo(at) <= r;
        float t = (at - a).Dot(ab) / ab.LengthSquared();
        if (t < 0f || t > 1f) return false;
        return (a + ab * t).DistanceTo(at) <= r;
    }

    /// <summary>Identifies yourself (the examine panel's character view).</summary>
    private void IdentifySelf()
    {
        if (_examine == null || _combat == null || _player == null) return;
        var me = _combat.Me;
        _examine.ShowSelf(me, _player, _combat.Health, me.Stamina, me.Mana);
        if (_net?.InWorld == true && _objects != null) _net.Appraise(_net.GuidOf(_objects.Self));   // (what the server says of you fills in the rest)
        _plugins?.OnIdentified(ACGodot.Plugins.PluginHost.Self);
    }

    /// <summary>Uses the selected thing (a corpse: look in it; a door: open or shut it), from where the character stands (R, or the hand).</summary>
    // (for now: says in chat what asked for a corpse to be opened - a key, a click or a plugin and where in it)
    private string _useWhy = "";
    private static string PluginCaller()
    {
        try
        {
            foreach (var f in new System.Diagnostics.StackTrace().GetFrames())
            {
                var m = f.GetMethod(); string asm = m?.DeclaringType?.Assembly.GetName().Name ?? "";
                if (asm.Length > 0 && asm != "ACGodot" && !asm.StartsWith("ACGodot.") && !asm.StartsWith("System") && !asm.StartsWith("Godot")) return $"{asm}: {m!.DeclaringType!.Name}.{m.Name}";
            }
        }
        catch (Exception) { }
        return "?";
    }

    private void UseSelected() => UseOn(_objects?.Selected, false);

    /// <summary>Uses a thing in the world: the selection (R, the hand button), or - quiet - one a plugin names, without
    /// touching the selection.</summary>
    private void UseOn(ACGodot.Objects.ObjectStreamer.Selectable? target, bool quiet)
    {
        if (_objects == null) return;
        if (!quiet && target != null && _net != null) ReadingIt(_net.GuidOf(target), target.Name);
        // the open corpse (or chest) used again - shut - while you're still picking something up out of it: not till the
        // pickup is done, whoever asks (a plugin's looter shuts it the moment it has asked for the last thing)
        if (_net != null && _player != null && _player.Bending && _net.OpenContainer != 0 && target is { } open && _net.GuidOf(open) == _net.OpenContainer)
        { _shutAfterPickup = open; return; }
        // a corpse: you turn to face it first, and it's opened once you do (by hand, or a plugin's looting) - the server
        // won't open one you have your back to
        if (target is { Corpse: true, Gone: false } facing && _player != null && !_useTurned)
        {
            var fd = facing.Feet - _player.Position;
            if (fd.X * fd.X + fd.Z * fd.Z > 0.04f)
            {
                float want = MathF.Atan2(-fd.X, -fd.Z);
                if (MathF.Abs(Mathf.Wrap(want - _player.Heading, -MathF.PI, MathF.PI)) > 0.3f)
                {
                    _player.TurnToYaw = want;
                    _useAfterTurn = facing; _useAfterTurnQuiet = quiet; _useTurnAt = Time.GetTicksMsec() / 1000.0; _useTurnYaw = want;
                    return;
                }
            }
        }
        _useTurned = false;
        // (which plugin opened a corpse: in the log, not the chat)
        if (target is { Corpse: true } body && _useWhy.Length > 0) { global::ACGodot.DebugLogs.Print($"[use] {body.Name} used by {_useWhy}"); _useWhy = ""; }
        // one of your own things chosen (nothing in the world): used - at once, or on what's chosen next
        // (the item is what the control bar shows as chosen, whatever was last picked in the world)
        if (!quiet && _selItem is { Guid: not 0, Wearable: false } mine && _combat?.Inv.Pack.Contains(mine) == true) { UseCarried(mine); return; }
        // too far: run up to it, then use it there
        if (target is { } far && _player?.Active == true && TooFar(far, false)) { WalkTo(far, false, quiet); return; }
        // a thing on the ground that can be carried: picked up (the server has no "use" for armour lying there - it
        // only complains: "ActOnUse ... undefined")
        if (!quiet && target is { Item: ACGodot.Net.NetGame.NetObject } loose && _net?.CanCarry(loose) == true && _objects?.Selected == loose) { PickUpSelected(); return; }
        // the server's own (a door, an NPC, a portal): asked of it
        if (target is { } theirs && _net?.Use(theirs) == true) { global::ACGodot.DebugLogs.Print($"[use] {DateTime.Now:HH:mm:ss} asked the server to use {theirs.Name} ({(_player != null ? theirs.Feet.DistanceTo(_player.Position) : 0):0.0} m)"); return; }
        if (target is { Type: 7 } portal && _player?.Active == true && _portalTo.TryGetValue(portal.Wcid, out var to)) { EnterPortal(to.cell, to.name); return; }
        string? corpse = target != null && _combat != null && _player?.Active == true ? _combat.OpenCorpse(target) : null;
        if (corpse != null) { _status = corpse; return; }
        // (the world on its own: its use is of the selection - a plugin's thing selected for it, the player's put back)
        var was = _objects.Selected;
        if (quiet && target != null && was != target) _objects.Select(target);
        _status = _objects.Use(_player?.Active == true ? _player.Position : _cam.Position);
        if (quiet && target != null && was != target) _objects.Select(was is { Gone: false } ? was : null);
    }

    // walking (or running) into one of ACGodot's own portals takes you through it, as in the game
    private double _portalLook;
    private void WalkIntoPortals(double delta)
    {
        if (_portalTo.Count == 0 || _player?.Active != true || _player.Frozen || _objects == null || _portalSpace?.Busy == true) return;
        if ((_portalLook -= delta) > 0) return;
        _portalLook = 0.1;
        var me = _player.Position;
        foreach (var s in _objects.AllSelectables)
        {
            if (s.Type != 7 || s.Gone || !_portalTo.TryGetValue(s.Wcid, out var to)) continue;
            var d = new Vector2(s.Center.X - me.X, s.Center.Z - me.Z);
            float reach = Math.Max(1.0f, s.Radius * 0.8f);
            if (d.Length() <= reach && me.Y > s.Feet.Y - 1.5f && me.Y < s.Top + 0.5f) { EnterPortal(to.cell, to.name); return; }
        }
    }

    // ── using what you carry (on a server): at once, or - a thing that's used on something - on what's chosen next ──
    private ACGodot.Combat.Item? _useSource;
    private double _useUntil;

    /// <summary>Uses a carried thing: a healing kit, key or tool waits for its target (the next thing or item chosen); the rest are used at once.</summary>
    private bool _bookTest;
    // the book (or parchment) you last used yourself, to open for reading when the server sends it
    private uint _readBook; private double _readBookAt; private string _readBookName = "";
    private ACGodot.UI.BookWindow? _bookWin;
    private void ReadingIt(uint guid, string name) { _readBook = guid; _readBookAt = Time.GetTicksMsec() / 1000.0; _readBookName = name ?? ""; }
    private void UseCarried(ACGodot.Combat.Item item)
    {
        if (item.Guid == 0 || _net?.InWorld != true) return;
        ChatLogLine($"(using {item.Name}{(item.NeedsTarget ? " - it wants a target: the next click" : "")})", ACGodot.UI.ChatKind.Gameplay);
        // an Ust: the salvage panel (the things to break down are put on it, then salvaged together)
        if (item.Name == "Ust" || item.Wcid == 20646)
        {
            if (_salvageWin == null)
            {
                _salvageWin = new ACGodot.UI.SalvageWindow { Name = "Salvage", Visible = false, Position = new Vector2(440, 160), Icon = id => _objects!.Assets.Icon(id), Inv = _combat?.Inv,
                                                             Salvage = (ust, things) => _net?.Salvage(ust, things) == true, Selected = () => _selItem, Identify = IdentifyItem };
                _ui.AddChild(_salvageWin);
            }
            _salvageWin.Open(item);
            return;
        }
        if (!item.NeedsTarget)
        {
            // an essence: its pet comes, or goes if it's out (one of ours near: its name starts "+<our name>'s")
            if (item.Name.Contains(" Essence"))
            {
                string pet = item.Name[..item.Name.IndexOf(" Essence")];
                bool isOut = _objects?.AllSelectables.Any(x => !x.Gone && x.Name.StartsWith("+") && x.Name.Contains("'s ") && pet.EndsWith(x.Name[(x.Name.IndexOf("'s ") + 3)..])) == true;
                Status($"{(isOut ? "Dismissing" : "Summoning")} {pet}", "pet");
            }
            ReadingIt(item.Guid, item.Name);
            _net.UseItem(item); return;
        }
        _useSource = item; _useUntil = Time.GetTicksMsec() / 1000.0 + 20; _selItem = null;   // (what was picked before isn't the target: the next click is)
        _objects?.Select(null);
        Say($"Choose a target for the {item.Name}: click a thing, an item, or yourself.", new Color(1f, 0.9f, 0.4f));
    }

    /// <summary>The item waiting for a target was used on something by other means (a plugin's lockpicking): no
    /// target to choose any more - the rings cursor goes.</summary>
    private void UsedElsewhere(ACGodot.Combat.Item used)
    {
        if (_useSource == null || used != _useSource) return;
        _useSource = null; TargetCursor(false);
    }

    private void StopUsing(ACGodot.Combat.Item src)
    {
        _useSource = null; TargetCursor(false);
        Say($"You stop using the {src.Name}.", new Color(1f, 0.9f, 0.4f));
    }

    private void UseOnNextChosen()
    {
        if (_useSource is not { } src || _net == null || _combat == null) { TargetCursor(false); return; }
        if (!_combat.Inv.Pack.Contains(src) && !_combat.Inv.Worn.Contains(src)) { _useSource = null; TargetCursor(false); return; }
        if (Time.GetTicksMsec() / 1000.0 > _useUntil) { _useSource = null; TargetCursor(false); Say($"You stop using the {src.Name}.", new Color(1f, 0.9f, 0.4f)); return; }
        TargetCursor(true);
        uint onThing = _objects?.Selected is { } thing ? _net.GuidOf(thing) : 0;
        uint target = onThing != 0 ? onThing : _selItem is { Guid: not 0 } it && it != src ? it.Guid : 0;
        if (target == 0) return;
        _useSource = null; TargetCursor(false);
        _net.UseOn(src, target);
    }

    // the game's contracts (the names and descriptions the server's numbers stand for)
    private DatReaderWriter.DBObjs.ContractTable? _contractTable;
    private ACGodot.UI.SocialViews.ContractText? ContractInfo(uint id)
    {
        try
        {
            _contractTable ??= _dats?.Get<DatReaderWriter.DBObjs.ContractTable>(0x0E00001Du);
            if (_contractTable == null || !_contractTable.Contracts.TryGetValue(id, out var c)) return null;
            // a place in the game's files as map coordinates (none given: empty)
            static string At(DatReaderWriter.Types.Position? p)
            {
                if (p == null || p.CellId == 0) return "";
                int lx = (int)(p.CellId >> 24), ly = (int)((p.CellId >> 16) & 0xFF);
                return World.MapCoords(World.ToGodot(lx * World.LandblockSize + p.Frame.Origin.X, ly * World.LandblockSize + p.Frame.Origin.Y, p.Frame.Origin.Z));
            }
            return new ACGodot.UI.SocialViews.ContractText(c.ContractName?.Value ?? "", c.Description?.Value ?? "", c.DescriptionProgress?.Value ?? "",
                                                         c.NameNPCStart?.Value ?? "", At(c.LocationNPCStart), At(c.LocationQuestArea));
        }
        catch { return null; }
    }

    /// <summary>
    /// Placed in the world: out of portal space (and the "entering" cover) once what's around you is built - the
    /// landblocks and your dungeon's rooms, the ground - and has stayed so for half a second; at least 1 s, at most 20 s.
    /// (Out after a fixed second, a dungeon's walls could still be missing: you saw through them.)
    /// </summary>
    private void OutWhenLoaded(ulong since, ulong settledAt = 0)
    {
        ulong now = Time.GetTicksMsec();
        bool settled = (_objects?.Settled ?? true) && (_terrain?.Settled ?? true);
        if (!settled) settledAt = 0;
        else if (settledAt == 0) settledAt = now;
        if ((now - since >= 1000 && settledAt != 0 && now - settledAt >= 500) || now - since >= 20000)
        {
            HideConnecting();
            _portalSpace?.Release();
            return;
        }
        ulong at = settledAt;
        GetTree().CreateTimer(0.1).Timeout += () => OutWhenLoaded(since, at);
    }

    /// <summary>Portal space for as long as entering or leaving the world takes (out again with its Release).</summary>
    private void PortalHold()
    {
        CloseShopWindows();
        if (_portalSpace == null) { _portalSpace = new ACGodot.UI.PortalSpace { Name = "PortalSpace" }; AddChild(_portalSpace); }
        _portalSpace.Hold();
    }

    /// <summary>The server sends you somewhere else: portal space while it does (the place itself comes from the server).</summary>
    private void ServerPortal()
    {
        CloseShopWindows();
        if (_player == null) return;
        if (_portalSpace == null) { _portalSpace = new ACGodot.UI.PortalSpace { Name = "PortalSpace" }; AddChild(_portalSpace); }
        if (_portalSpace.Busy) return;
        _player.Frozen = true;
        _objects?.Select(null);
        _portalSpace.Go(() => { GetTree().CreateTimer(2.2).Timeout += () => { if (_player != null) _player.Frozen = false; }; }, 3.0);
    }

    /// <summary>Through a portal: portal space, out in the cell (the same spot each time: the middle of its floor).</summary>
    /// <summary>Coordinates clicked in chat, or /arrow: the quest tracker's travel window when it's there (its arrow, and its
    /// Auto travel button - nothing started), else our own arrow.</summary>
    private void PointAt(double ns, double ew, string text)
    {
        if (_plugins?.CoordsWanted is { } want)
        {
            try { _arrow?.Clear(); want(ns, ew, text); return; }
            catch (Exception ex) { GD.PushWarning("travel window: " + ex.Message); }
        }
        _arrow?.Point(ns, ew, text);
        Say($"Arrow pointing to {text}", new Color(1f, 0.9f, 0.4f));
    }

    /// <summary>Into portal space: an open chest's or corpse's window and a vendor's shut (the chest is told it's shut).</summary>
    private void CloseShopWindows()
    {
        if (_vendorWin != null) _vendorWin.Visible = false;
        if (_lootWin != null && _lootWin.Visible) _lootWin.Visible = false;
        else _net?.CloseContainer();
    }

    private void EnterPortal(uint cell, string name)
    {
        CloseShopWindows();
        if (_player == null) return;
        if (_portalSpace == null) { _portalSpace = new ACGodot.UI.PortalSpace { Name = "PortalSpace" }; AddChild(_portalSpace); }
        if (_portalSpace.Busy) return;
        _player.Frozen = true;
        _objects?.Select(null);
        Say($"You enter the portal to {name}.", new Color(0.8f, 0.6f, 1f));
        _portalSpace.Go(() =>
        {
            OnGotoSubmitted($"{cell:X8}");
            // out of portal space a moment after arriving (the tunnel fades over where you came out)
            GetTree().CreateTimer(2.4).Timeout += () => { if (_player != null) _player.Frozen = false; };
        });
    }

    /// <summary>Picks up the selected item, running up to it first if it's too far.</summary>
    private void PickUpSelected()
    {
        if (_combat == null || _player?.Active != true) return;
        if (_objects?.Selected is { Item: not null } far && TooFar(far, true)) { WalkTo(far, true); return; }
        // the server's own: picked up if it can be (the pack changes when the server says so), else used
        if (_objects?.Selected is { Item: ACGodot.Net.NetGame.NetObject } theirs)
        {
            if (_net?.PickUp(theirs) == true) _player.Crouch(); else UseSelected();
            return;
        }
        _status = _combat.PickUp(_objects?.Selected);
    }

    // using something out of reach: you run up to it and use it (or pick it up) once you're there; steering, choosing
    // something else or it going away calls it off
    private ACGodot.Objects.ObjectStreamer.Selectable? _walkTarget;
    private bool _walkPickUp;

    private bool TooFar(ACGodot.Objects.ObjectStreamer.Selectable sel, bool pickUp)
    {
        var me = _player!.Position;
        // (the server only hands a thing over from within its reach - measured between you and it, less your width)
        if (_net != null && _net.CanCarry(sel)) return sel.Feet.DistanceTo(me) > _net.Reach(sel) + 0.2f;
        // (picking it up; used - a statue, a chest the server counts as an item - goes by its edge, below)
        if (pickUp) return sel.Feet.DistanceTo(me) - Math.Max(0f, Math.Min(sel.Radius, 1f)) > 2.6f;
        // a door: across the ground to its middle (a tall one - a portcullis - has its middle metres up: measured
        // straight to it, you were never near enough however close you stood)
        if (sel.Type == 19) return new Vector2(sel.Center.X - me.X, sel.Center.Z - me.Z).Length() > 3.6f;
        // (from its edge, not its middle: a big thing - a statue, a large creature - is used from beside it, and can't be
        // got nearer its middle than its width; measured from the middle, it was run into and never reached)
        float edge = new Vector2(sel.Feet.X - me.X, sel.Feet.Z - me.Z).Length() - Math.Max(0f, sel.Radius);
        // a corpse: the server opens one from 2 m (edge to edge) - stopped further off, it walked us the rest itself
        if (sel.Fight is ACGodot.Combat.Fighter { St: ACGodot.Combat.Fighter.State.Dead } || sel.Corpse) return edge > 1.6f;
        return edge > 3f;
    }

    private bool _walkQuiet;
    private void WalkTo(ACGodot.Objects.ObjectStreamer.Selectable sel, bool pickUp, bool quiet = false)
    {
        _walkTarget = sel; _walkPickUp = pickUp; _walkQuiet = quiet;
        _player!.Charging = false;
        _player.ApproachTo = sel.Feet;
        _status = $"going to {sel.Name}";
    }

    private void UpdateWalkTo()
    {
        if (_walkTarget is not { } t || _player == null) return;
        if (!_player.Active || t.Gone || (!_walkQuiet && _objects?.Selected != t) || _player.MovedByKeys || _player.ApproachTo == null)
        {
            global::ACGodot.DebugLogs.Print($"[use] {DateTime.Now:HH:mm:ss} run up to {t.Name} called off ({t.Feet.DistanceTo(_player.Position):0.0} m): "
                     + (!_player.Active ? "not active" : t.Gone ? "it's gone" : _objects?.Selected != t ? $"selection changed to {_objects?.Selected?.Name ?? "nothing"}" : _player.MovedByKeys ? "steered off" : "the run was stopped"));
            _walkTarget = null;
            if (_player.ApproachTo != null && !_player.Charging) _player.ApproachTo = null;
            return;
        }
        if (TooFar(t, _walkPickUp)) { _player.ApproachTo = t.Feet; return; }
        _player.ApproachTo = null;
        _walkTarget = null;
        // (picked up: asked to, or a thing that can be carried; anything else - a statue the server counts as an item - used)
        bool take = _walkPickUp || (t.Item != null && _net?.CanCarry(t) != false);
        global::ACGodot.DebugLogs.Print($"[use] {DateTime.Now:HH:mm:ss} reached {t.Name} ({t.Feet.DistanceTo(_player.Position):0.0} m) - {(take ? "picking it up" : "using it")}");
        if (!take) { UseOn(t, _walkQuiet); return; }
        if (_walkQuiet && _objects != null && _objects.Selected != t) { var was = _objects.Selected; _objects.Select(t); PickUpSelected(); if (_objects.Selected == t) _objects.Select(was is { Gone: false } ? was : null); return; }
        PickUpSelected();
    }

    /// <summary>The game's own windows from its layouts: side panels, control bar, status icons, spell bar; and the plugin bar.</summary>
    private void SetupRetailPanels()
    {
        if (_combat == null || _player == null || _objects == null) return;
        var inv = _combat.Inv;
        Texture2D? Icon(uint id) => _objects.Assets.Icon(id);
        // dragging part of a stack: as many as the control bar's box says (for the stack that's selected)
        ACGodot.Combat.ItemSlot.Splitting = it => it == _selItem && _controlBar != null ? _controlBar.SplitAmount : it.Stack;
        ACGodot.Combat.ItemSlot.SplitOff = (it, n) => inv.Split(it, n);
        void Opened(ACGodot.UI.SidePanel p, bool open) => _controlBar?.SetPanelOpen(p.PanelId, open);
        try
        {
            _invPanel = new ACGodot.UI.InventoryPanel { Name = "Inventory", Inv = inv, Me = () => _combat.Me, Icon = Icon, Player = _player, MainPackIcon = () => _controlBar?.PanelIcon(7) };
            _ui.AddChild(_invPanel);
            if (_invPanel.Setup())
            {
                _invPanel.Said = t => { if (t.Length > 0) _combatHud.Log(t, ACGodot.Combat.CombatHud.Plain); };
                _invPanel.Equipped = () => _combat.GearChanged();
                _invPanel.Dropped = item => _combat.Drop(item);
                _invPanel.Identify = IdentifyItem;
                _invPanel.UseItem = UseCarried;
                _invPanel.Shown = Opened;
                _invPanel.Picked = PickItem;
                _invPanel.TakeFromCorpse = (it, pack, place) =>
                {
                    if (_lootWin?.Contents == null || !_lootWin.Contents.Contains(it)) return false;
                    // (on a server: into the pack it was dropped in, at the place - it's there when the server says so)
                    if (it.Guid != 0 && _net != null) { _net.TakeOut(it, pack, place); _player?.Crouch(); _lootWin.Removed(it); return false; }
                    _lootWin.TakeIt(it);
                    return inv.Pack.Contains(it);
                };
                _invPanel.MergeFromCorpse = (it, onto) => { if (_net != null && it.Guid != 0) { _net.Merge(it, onto); _player?.Crouch(); } };
                var before = inv.Changed;
                inv.Changed = () => { before?.Invoke(); _invPanel.Refresh(); };
            }
            else { _invPanel.QueueFree(); _invPanel = null; }

            _charPanel = new ACGodot.UI.CharacterPanel { Name = "CharacterPanel", Me = () => _combat.Me, Icon = Icon,
                                                         Titles = () => _net is { InWorld: true } tn ? (tn.DisplayTitle, tn.Titles) : null,
                                                         TitleName = TitleName, UseTitle = t => _net?.SetTitle(t) };
            if (_net != null) _net.TitlesChanged = () => _charPanel?.Refresh();
            _ui.AddChild(_charPanel);
            if (_charPanel.Setup())
            {
                _charPanel.Changed = () => { _combat.Me.Save(inv); _status = "raised"; };
                _charPanel.Shown = Opened;
                var xp = _combat.XpChanged;
                _combat.XpChanged = () => { xp?.Invoke(); _charPanel.Refresh(); };
            }
            else { _charPanel.QueueFree(); _charPanel = null; }

            _bookPanel = new ACGodot.UI.SpellbookPanel { Name = "SpellbookPanel", Magic = _magic, Icon = Icon, Inv = inv };
            _ui.AddChild(_bookPanel);
            _bookPanel.Identify = sp => _examine?.ShowSpell(sp);
            if (_bookPanel.Setup()) _bookPanel.Shown = Opened; else { _bookPanel.QueueFree(); _bookPanel = null; }

            _infoPanel = new ACGodot.UI.TextPanel { Name = "CharacterInformation", Content = CharacterInformation };
            _ui.AddChild(_infoPanel);
            if (!_infoPanel.Setup(1, "Character Information")) { _infoPanel.QueueFree(); _infoPanel = null; }

            // the game's own tabbed panels (their frames, tabs and names from the game's layouts), one open at a time with
            // the others: Social, Quests, Map / House and the options
            var dim = ACGodot.UI.RetailTheme.Dim;
            Label L(string t, Color? c = null, HorizontalAlignment al = HorizontalAlignment.Left) => ACGodot.UI.SidePanel.Line(t, c, al);
            Button Soon(string t) { var bt = ACGodot.UI.SidePanel.Btn(t, () => { }, false); bt.TooltipText = "Not yet in ACGodot."; return bt; }
            HBoxContainer RowOf(params Control[] cs) { var row = new HBoxContainer { Alignment = BoxContainer.AlignmentMode.Center }; row.AddThemeConstantOverride("separation", 8); foreach (var c in cs) row.AddChild(c); return row; }
            bool Online() => _net?.InWorld == true;

            _socialPanel = new ACGodot.UI.TabbedPanel { Name = "Social" };
            _ui.AddChild(_socialPanel);
            if (_socialPanel.Setup(ACGodot.UI.SidePanel.Social, 0x21000031, 0x1000028B, 0x10000290))
            {
                _socialPanel.Shown = Opened;
                _socialPanel.Fill = (tab, name, box) =>
                {
                    string n = name.ToLowerInvariant();
                    string none = Online() ? "" : "\n\n(You're playing offline.)";
                    if (n.Contains("alleg")) { ACGodot.UI.SocialViews.Allegiance(box, Online() ? _net : null, () => _objects?.Selected, () => _socialPanel?.Refresh(), t => Status(t)); return; }
                    else if (n.Contains("fellow") && Online() && _net != null) { ACGodot.UI.SocialViews.Fellowship(box, _net, () => _objects?.Selected, () => _socialPanel?.Refresh()); return; }
                    else if (n.Contains("friend") && Online() && _net != null) { ACGodot.UI.SocialViews.Friends(box, _net, () => _socialPanel?.Refresh()); return; }
                    else if (n.Contains("fellow"))
                    {
                        box.AddChild(L("You do not belong to a fellowship.\nTo create a fellowship, enter a name in the box below, then click Create Fellowship. Once you've created a fellowship, you can start recruiting members." + none));
                        box.AddChild(L(""));
                        box.AddChild(L("Fellowship Name:"));
                        box.AddChild(new LineEdit { Editable = false, PlaceholderText = "not yet in ACGodot" });
                        box.AddChild(RowOf(Soon("Create Fellowship")));
                    }
                    else if (n.Contains("friend"))
                    {
                        box.AddChild(L("Your friends list is empty." + none, null, HorizontalAlignment.Center));
                        box.AddChild(L(""));
                        box.AddChild(RowOf(Soon("Add Friend"), Soon("Remove")));
                    }
                    else
                    {
                        box.AddChild(L("You have not squelched anyone." + none, null, HorizontalAlignment.Center));
                        box.AddChild(L(""));
                        box.AddChild(RowOf(Soon("Squelch"), Soon("Unsquelch")));
                    }
                    if (Online()) box.AddChild(L("\nACGodot doesn't read this from the server yet.", dim, HorizontalAlignment.Center));
                };
            }
            else { _socialPanel.QueueFree(); _socialPanel = null; }

            _questPanel = new ACGodot.UI.TabbedPanel { Name = "Quests" };
            _ui.AddChild(_questPanel);
            if (_questPanel.Setup(ACGodot.UI.SidePanel.Quests, 0x21000063, 0x1000055F, 0x10000562))
            {
                _questPanel.Shown = Opened;
                _questPanel.Fill = (tab, name, box) =>
                {
                    string n = name.ToLowerInvariant();
                    ACGodot.UI.SocialViews.JournalShowing = n.Contains("journal");
                    // (these pages in the font the tabs' names are in: clearer to read than the small text font)
                    box.Theme = n.Contains("journal") || n.Contains("page") || n.Contains("contract") ? _questPanel?.TabFontTheme : null;
                    // your own notes (kept on this PC, by character): the journal's pages and the list of them
                    string who = (_net?.InWorld == true ? "server:" : "offline:") + (_combat?.Me.Name ?? "");
                    if (n.Contains("journal")) { ACGodot.UI.SocialViews.Journal(box, who, () => World.MapCoords(_player?.Active == true ? _player.Position : _cam.Position), () => _questPanel?.Refresh()); return; }
                    if (n.Contains("page")) { ACGodot.UI.SocialViews.PageList(box, who, _ => _questPanel?.Show(tab - 1), () => _questPanel?.Refresh()); return; }
                    if (n.Contains("contract") && Online() && _net != null) { ACGodot.UI.SocialViews.Contracts(box, _net, ContractInfo, () => _questPanel?.Refresh()); return; }
                    box.AddChild(L(n.Contains("contract") ? "You have no active contracts." : n.Contains("journal") || n.Contains("quest") ? "Your quest journal is empty." : $"{name}: nothing here.", null, HorizontalAlignment.Center));
                    box.AddChild(L(Online() ? "\nACGodot doesn't read this from the server yet." : "\n(You're playing offline.)", dim, HorizontalAlignment.Center));
                    box.AddChild(L("\nQuest tracking: MelksQB (/mqt)", dim, HorizontalAlignment.Center));
                };
            }
            else { _questPanel.QueueFree(); _questPanel = null; }

            // Map / House: the control bar's map button opens this (the world map itself is M, or the button here)
            _mapPanel = new ACGodot.UI.TabbedPanel { Name = "MapHouse" };
            _ui.AddChild(_mapPanel);
            if (_mapPanel.Setup(ACGodot.UI.SidePanel.MapPanel, 0x21000027, 0x100001F2, 0x100001F5))
            {
                _mapPanel.Shown = Opened;
                if (_net != null) { var mp = _mapPanel; _net.HouseChanged = () => { _houseAnswerShown = true; try { mp.Refresh(); } finally { _houseAnswerShown = false; } }; }
                // a house's sign used: what it costs (or its upkeep), to buy or pay from
                if (_net != null)
                {
                    var hw = new ACGodot.UI.HouseWindow { Name = "House", Visible = false, Position = new Vector2(440, 150), Net = _net, Inv = _combat.Inv,
                                                          Icon = id => _objects!.Assets.Icon(id), Say = (t, c) => Say(t, c) };
                    _ui.AddChild(hw);
                    _net.HouseOffered = o => hw.ShowOffer(o);
                }
                _mapPanel.Fill = (tab, name, box) =>
                {
                    if (name.ToLowerInvariant().Contains("hous"))
                    {
                        if (!Online() || _net == null) box.AddChild(L("You do not own a house.\n\n(You're playing offline.)", null, HorizontalAlignment.Center));
                        else
                        {
                            if (!_houseAnswerShown) _net.QueryHouse();   // (asked when it's looked at - not again for the answer's own redraw)
                            if (_net.House is { } h)
                            {
                                string D(DateTime t) => t == DateTime.MinValue ? "?" : t.ToString("MMM d, yyyy  h:mm tt");
                                box.AddChild(L($"Your {h.TypeName.ToLowerInvariant()}", ACGodot.UI.RetailTheme.Gold, HorizontalAlignment.Center));
                                if (_net.HouseWhere.Length > 0) box.AddChild(L("at " + _net.HouseWhere, null, HorizontalAlignment.Center));
                                box.AddChild(L(""));
                                var nr = _net;
                                // abandoning: a second press within a few seconds to make sure (it can't be undone)
                                var abandon = ACGodot.UI.SidePanel.Btn("Abandon House", () => { });
                                abandon.Pressed += () =>
                                {
                                    double now2 = Time.GetTicksMsec() / 1000.0;
                                    if (now2 - _abandonAskedAt < 5) { _abandonAskedAt = -100; nr.AbandonHouse(); abandon.Text = "Abandon House"; }
                                    else { _abandonAskedAt = now2; abandon.Text = "Press again to abandon"; }
                                };
                                box.AddChild(RowOf(ACGodot.UI.SidePanel.Btn("House Recall", () => nr.HouseRecall()), abandon));
                                box.AddChild(L(""));
                                box.AddChild(L("Purchased: " + D(h.Bought)));
                                if (h.Free) box.AddChild(L("Maintenance: free this period"));
                                else
                                {
                                    box.AddChild(L("This maintenance period began: " + D(h.RentFrom)));
                                    bool paid = h.Rent.Count > 0 && h.Rent.All(p => p.Left <= 0);
                                    box.AddChild(L(paid ? "The maintenance has been paid." : "The maintenance has not been paid.", paid ? new Color(0.55f, 0.95f, 0.45f) : new Color(1f, 0.45f, 0.35f)));
                                    if (h.Rent.Count > 0)
                                    {
                                        box.AddChild(L("Upkeep:", dim));
                                        foreach (var p in h.Rent)
                                            box.AddChild(L($"   {p.Name}: {Math.Min(p.Paid, p.Need):N0} of {p.Need:N0}" + (p.Left <= 0 ? "  (paid)" : ""), p.Left <= 0 ? null : new Color(1f, 0.75f, 0.45f)));
                                    }
                                }
                            }
                            else box.AddChild(L(_net.HouseAnswered ? "You do not own a house." : "Asking the server about your house...", null, HorizontalAlignment.Center));
                        }
                    }
                    else
                    {
                        var at = _player?.Active == true ? _player.Position : _cam.Position;
                        box.AddChild(L("You are at " + World.MapCoords(at), null, HorizontalAlignment.Center));
                    }
                    box.AddChild(L(""));
                    box.AddChild(RowOf(ACGodot.UI.SidePanel.Btn("World Map", () => _map?.Toggle(), _map != null)));
                    box.AddChild(L("(M opens the world map too)", dim, HorizontalAlignment.Center));
                    // the arrow's size, how solid it is, its words' size; the map's text size
                    Control Slider(string label, float value, float min, float max, Action<float> set, Action done)
                    {
                        var row = new HBoxContainer();
                        var lbl = new Label { Text = $"{label} {(int)Math.Round(value * 100)}%", CustomMinimumSize = new Vector2(150, 0) };
                        var sl = new HSlider { MinValue = min * 100, MaxValue = max * 100, Step = 5, Value = Math.Round(value * 100), SizeFlagsHorizontal = Control.SizeFlags.ExpandFill, FocusMode = Control.FocusModeEnum.None };
                        sl.ValueChanged += v => { lbl.Text = $"{label} {(int)v}%"; set((float)v / 100f); };
                        sl.DragEnded += _ => done();
                        row.AddChild(lbl); row.AddChild(sl);
                        return row;
                    }
                    box.AddChild(L(""));
                    if (_arrow != null)
                    {
                        var ar = _arrow;
                        box.AddChild(L("Arrow", ACGodot.UI.RetailTheme.Gold, HorizontalAlignment.Left));
                        box.AddChild(Slider("Arrow size", ar.ArrowScale, 0.5f, 3f, v => { ar.ArrowScale = v; ar.ApplyLook(); }, ar.SaveLook));
                        box.AddChild(Slider("Arrow opacity", ar.Opacity, 0.15f, 1f, v => { ar.Opacity = v; ar.ApplyLook(); }, ar.SaveLook));
                        box.AddChild(Slider("Distance text size", ar.TextScale, 0.5f, 3f, v => { ar.TextScale = v; ar.ApplyLook(); }, ar.SaveLook));
                    }
                    if (_map != null)
                    {
                        var mw = _map;
                        box.AddChild(L("World map", ACGodot.UI.RetailTheme.Gold, HorizontalAlignment.Left));
                        box.AddChild(Slider("Map text size", ACGodot.Map.MapWindow.TextScale, 0.5f, 3f, v => { ACGodot.Map.MapWindow.TextScale = v; mw.ApplyTextScale(false); }, () => mw.ApplyTextScale(true)));
                        box.AddChild(Slider("Right-click menu size", ACGodot.Map.MapWindow.MenuScale, 0.5f, 3f, v => ACGodot.Map.MapWindow.MenuScale = v, ACGodot.Map.MapWindow.SaveMenuScale));
                    }
                };
            }
            else { _mapPanel.QueueFree(); _mapPanel = null; }

            _effectsPanel = new ACGodot.UI.SpellsInEffectPanel { Name = "SpellsInEffect", Magic = _magic, Icon = Icon, Identify = sp => _examine?.ShowSpell(sp) };
            _ui.AddChild(_effectsPanel);
            if (!_effectsPanel.Setup()) { _effectsPanel.QueueFree(); _effectsPanel = null; }

            _vitaePanel = new ACGodot.UI.TextPanel { Name = "Vitae", Content = () =>
            {
                var me = _combat.Me;
                if (me.Vitae >= 1f) return "You are not suffering from any vitae penalty.";
                long need = me.VitaeXpPerPercent - me.VitaePool;
                return $"You are suffering from a {(1f - me.Vitae) * 100:0}% vitae penalty.\n\n" +
                       $"{need:N0} more experience wins back the next percent.";
            } };
            _ui.AddChild(_vitaePanel);
            if (!_vitaePanel.Setup(15, "Vitae")) { _vitaePanel.QueueFree(); _vitaePanel = null; }

            _chessPanel = new ACGodot.UI.TextPanel { Name = "Chess", Content = () => "Chess Rank: 1400\n\nGames of chess are played against other players on a server." };
            _ui.AddChild(_chessPanel);
            if (!_chessPanel.Setup(14, "Chess")) { _chessPanel.QueueFree(); _chessPanel = null; }

            _controlBar = new ACGodot.UI.ControlBar { Name = "ControlBar" };
            _ui.AddChild(_controlBar);
            if (_controlBar.Setup())
            {
                _controlBar.PanelClicked = id =>
                {
                    switch (id)
                    {
                        case ACGodot.UI.SidePanel.Inventory: _invPanel?.Toggle(); break;
                        case ACGodot.UI.SidePanel.CharacterInfo: _charPanel?.Toggle(); break;
                        case ACGodot.UI.SidePanel.Spellbook: _bookPanel?.Toggle(); break;
                        case ACGodot.UI.SidePanel.Social: _socialPanel?.Toggle(); break;
                        case ACGodot.UI.SidePanel.Quests: _questPanel?.Toggle(); break;
                        case ACGodot.UI.SidePanel.MapPanel: if (_mapPanel != null) _mapPanel.Toggle(); else _map?.Toggle(); break;
                        case ACGodot.UI.SidePanel.Options: ToggleOptions(); break;
                    }
                };
                // (an item chosen in a corpse or the pack comes first: the glass identifies it and keeps it chosen, the hand takes it)
                _controlBar.UseClicked = () => { if (_selItem != null && _lootWin is { Visible: true } lw && lw.Contents?.Contains(_selItem) == true) lw.TakeIt(_selItem); else { _useWhy = "the hand button"; UseSelected(); } };
                _controlBar.ExamineClicked = () =>
                {
                    if (_selItem != null) IdentifyItem(_selItem);
                    else if (_objects.Selected is { Gone: false } sel) Identify(sel, false);
                    else IdentifySelf();
                };
                _controlBar.CombatClicked = () => _status = _combat.ToggleCombat();
                _combatHud.HideTarget = true;
            }
            else { _controlBar.QueueFree(); _controlBar = null; }

            _statusIcons = new ACGodot.UI.StatusIcons { Name = "StatusIcons" };
            _ui.AddChild(_statusIcons);
            if (_statusIcons.Setup())
            {
                _statusIcons.BurdenClicked = () => _infoPanel?.Toggle();
                _statusIcons.BuffsClicked = () => _effectsPanel?.Show(0);
                _statusIcons.DebuffsClicked = () => _effectsPanel?.Show(1);
                _statusIcons.VitaeClicked = () => _vitaePanel?.Toggle();
                _statusIcons.ChessClicked = () => _chessPanel?.Toggle();
                if (_statusIcons.Position == Vector2.Zero && _controlBar != null) _statusIcons.Position = _controlBar.Position + new Vector2(-_statusIcons.Size.X - 4, _controlBar.Size.Y - _statusIcons.Size.Y);
            }
            else { _statusIcons.QueueFree(); _statusIcons = null; }

            _spellBar = new ACGodot.UI.SpellBar { Name = "SpellBar", Icon = Icon, Cast = e => CastSpell(e.Id),
                                                  Identify = e => { if (_magic != null && _magic.All.TryGetValue(e.Id, out var sp)) _examine?.ShowSpell(sp); } };
            _ui.AddChild(_spellBar);
            if (!_spellBar.Setup()) { _spellBar.QueueFree(); _spellBar = null; }
        }
        catch (Exception ex) { GD.PushWarning("retail panels: " + ex.Message); }
        if (_plugins != null)
        {
            _pluginBar = new ACGodot.UI.PluginBar { Name = "PluginBar", Host = _plugins, Icon = Icon };
            _ui.AddChild(_pluginBar);
        }
    }

    /// <summary>Character Information (the burden backpack): your burden and what augments you.</summary>
    // (the game's own augmentations, by the number the server keeps each under)
    private static readonly (int key, string name)[] AugNames =
    {
        (218, "Reinforcement of the Lugians / Bleeargh's Fortitude / Oswald's Enhancement / Siraluun's Blessing / Enduring Calm / Steadfast Will (innate attributes)"),
        (225, "Ciandra's Essence (Salvaging)"), (226, "Yoshi's Essence (Item Tinkering)"), (227, "Jibril's Essence (Armor Tinkering)"),
        (228, "Celdiseth's Essence (Magic Item Tinkering)"), (229, "Koga's Essence (Weapon Tinkering)"),
        (230, "Shadow of the Seventh Mule (extra pack slot)"), (231, "Might of the Seventh Mule (carrying capacity)"),
        (232, "Clutch of the Miser (fewer items lost on death)"), (233, "Enduring Enchantment (spells kept past death)"),
        (234, "Critical Protection"), (235, "Quick Learner (bonus experience)"), (236, "Ciandra's Fortune (bonus salvage)"),
        (237, "Charmed Smith (imbue chance)"), (238, "Innate Renewal (faster regeneration)"), (239, "Archmage's Endurance (spell duration)"),
        (240, "Resistances (Storm's / Fiery / Icy / Caustic / Blade / Piercing / Bludgeoning Enhancement)"),
        (294, "Infused Creature Magic"), (295, "Infused Item Magic"), (296, "Infused Life Magic"), (297, "Infused War Magic"), (328, "Infused Void Magic"),
        (298, "Eye of the Remorseless (critical chance)"), (299, "Hand of the Remorseless (critical damage)"),
        (300, "Master of the Steel Circle (melee)"), (301, "Master of the Focused Eye (missile)"), (302, "Master of the Five Fold Path (magic)"),
        (309, "Frenzy of the Slayer (damage)"), (310, "Iron Skin of the Invincible (damage reduction)"), (326, "Jack of All Trades"),
    };
    private static readonly (int key, string name)[] LumAugNames =
    {
        (333, "Aura of Valor (damage)"), (334, "Aura of Protection (damage reduction)"), (335, "Aura of Glory (critical damage)"),
        (336, "Aura of Temperance (critical damage reduction)"), (338, "Aura of Aetheric Vision (surge chance)"),
        (339, "Aura of Mana Flow (mana use)"), (340, "Aura of Mana Infusion (mana gain)"), (341, "Aura of Vitality (health)"),
        (342, "Aura of Purity (healing)"), (343, "Aura of Craftsman (crafting)"), (344, "Aura of Specialization (specialized skills)"),
        (365, "Aura of the World (all skills)"),
    };

    private bool _barDrawnFor;   // (the shortcut bar drawn again once the server has said what we carry: its items' pictures come from them)

    private string CharacterInformation()
    {
        if (_combat == null) return "";
        var me = _combat.Me; var inv = _combat.Inv;
        // (150 for each point of strength, and a fifth as much again for each carrying-capacity augmentation)
        var ints = _net?.Character?.Ints;
        int Aug(int k) { int v = 0; ints?.TryGetValue(k, out v); return v; }
        long capL = (long)me.Attribute(0) * 150 + (long)me.Attribute(0) * 30 * Math.Clamp(Aug(231), 0, 5);
        int cap = (int)Math.Clamp(capL, 1, int.MaxValue);
        int burden = inv.TotalBurden;
        var t = new System.Text.StringBuilder();
        t.AppendLine($"{me.Name}, level {me.Level} {me.Heritage}");
        t.AppendLine();
        t.AppendLine(burden <= cap ? "You are not overburdened at this time." : burden <= cap * 2 ? "You are encumbered." : "You are heavily encumbered.");
        t.AppendLine($"Burden: {burden:N0} of {cap:N0} ({burden * 100 / cap}%)");
        if (burden < cap) t.AppendLine($"You can carry {cap - burden:N0} more before you're overburdened.");
        t.AppendLine();
        if (Aug(390) > 0) { t.AppendLine($"Enlightenment: {Aug(390):N0}"); t.AppendLine(); }
        // the attributes you were made with (innate), as the server has them - the daily attribute quest raises them past
        // what creation allows (Strength, Endurance, Coordination, Quickness, Focus, Self)
        if (_net?.Character is { } sc && sc.AttributeStart.Any(v => v > 0))
        {
            int[] order = { 0, 1, 3, 2, 4, 5 };   // (kept as strength, endurance, quickness, coordination, focus, self)
            string[] names = { "Strength", "Endurance", "Quickness", "Coordination", "Focus", "Self" };
            t.AppendLine("Base attributes: " + string.Join("/", order.Select(i => sc.AttributeStart[i].ToString())));
            foreach (int i in order) t.AppendLine($"  {names[i]} {sc.AttributeStart[i]:N0}");
            t.AppendLine();
        }
        void List(string title, (int key, string name)[] of)
        {
            var have = of.Where(a => Aug(a.key) > 0).ToList();
            if (have.Count == 0) { t.AppendLine(title + ": none yet."); return; }
            t.AppendLine(title + ":");
            foreach (var (key, name) in have) t.AppendLine($"  {name}{(Aug(key) > 1 ? $" x{Aug(key):N0}" : "")}");
        }
        List("Augmentations", AugNames);
        t.AppendLine();
        List("Luminance Augmentations", LumAugNames);
        return t.ToString();
    }

    /// <summary>The control bar, status icons and spell bar kept up to date (each frame).</summary>
    private void UpdateRetailPanels()
    {
        if (_combat == null || _objects == null || _player?.Active != true) return;
        var screen = GetViewport().GetVisibleRect().Size;
        if (_controlBar != null)
        {
            var sel = _objects.Selected is { Gone: false } s ? s : null;
            bool newSel = sel != _lastSel;
            if (sel != _lastSel) { _lastSel = sel; if (sel != null) _selItem = null; }   // something new chosen in the world
            // on a server: how hurt the creature chosen is has to be asked for - as it's chosen (the server then sends word
            // as it's hurt), and again every couple of seconds while it stays chosen (its bar stood still otherwise)
            if (_net != null && sel != null && sel != _objects.Self && sel.Kind is 1 or 2 or 4 or 5 && !sel.Corpse)
            {
                double hnow = Time.GetTicksMsec() / 1000.0;
                if (newSel || hnow - _healthAskedAt > 4.0) { _healthAskedAt = hnow; uint hg = _net.GuidOf(sel); if (hg != 0) _net.QueryHealth(hg); }
            }
            // the ID panel open and something else chosen: it's identified (or, by choice, the panel shuts)
            // (the inventory's highlighted square follows: one thing is selected at a time, wherever it was chosen)
            _invPanel?.ShowPicked(_selItem);
            object? chosen = (object?)_selItem ?? sel;
            if (chosen != _lastChosen)
            {
                _lastChosen = chosen;
                if (_examine is { Visible: true } && chosen != null)
                {
                    if (ACGodot.UI.ExaminePanel.CloseOnSelect) _examine.Visible = false;
                    else if (_selItem != null) { _examine.ShowItem(_selItem); _plugins?.OnIdentified(_selItem); }
                    else if (sel != null) Identify(sel, false);
                }
            }
            // identifying something in a corpse or chest, and it shuts (you ran off): the ID panel shuts with it
            // (and doesn't come back for whatever's chosen next)
            if (_lootWin is { Visible: true, Contents: { } inLoot } && _examine is { Visible: true, ShownItem: { } shown }) _examFromLoot = inLoot.Contains(shown);
            else if (_examine is { Visible: true } && _examine.ShownItem == null) _examFromLoot = false;
            if (_lootWin?.Visible != true && _examFromLoot)
            {
                _examFromLoot = false;
                if (_examine != null) _examine.Visible = false;
                _selItem = null;
                _lastChosen = (object?)_selItem ?? sel;
            }
            // an item stays chosen while it's still yours (or still in the open corpse)
            if (_selItem != null && !_combat.Inv.Pack.Contains(_selItem) && !_combat.Inv.Worn.Contains(_selItem)
                && !(_lootWin is { Visible: true, Contents: { } lc } && lc.Contains(_selItem)) && _vendorWin?.Has(_selItem) != true
                && _net?.HeldByOther(_selItem.Guid) != true) _selItem = null;   // (or still in someone's hand)
            float hp = -1; int stack = 0;
            if (_selItem != null) _controlBar.SetSelection(_selItem.Shown, -1, _selItem.Stack, _selItem.MaxUses > 0 ? _selItem.Uses : -1,
                                                           _selItem.MaxMana > 0 && _selItem.Mana > 0 ? _selItem.Mana / (float)_selItem.MaxMana : -1);
            else
            {
                // a creature's health, live
                if (sel != null && _combat.Of(sel) is { } f) hp = f.MaxHealth > 0 ? Math.Max(0, f.Health) / (float)f.MaxHealth : -1;
                int uses = -1; float mana = -1;
                if (sel?.Item is ACGodot.Combat.Item it) { stack = it.Stack; if (it.MaxUses > 0) uses = it.Uses; if (it.MaxMana > 0 && it.Mana > 0) mana = it.Mana / (float)it.MaxMana; }
                // a corpse: its burden too - what's still in it, without opening it
                string? selName = sel?.Name;
                _controlBar.SetSelection(selName, hp, stack, uses, mana);
            }
            // (lit for an item chosen in a pack, on the character or in a corpse too)
            _controlBar.SetUsable(_selItem != null || sel != null && (sel.Type == 19 || sel.Kind == 1 || sel.Item != null || sel.Fight is ACGodot.Combat.Fighter { St: ACGodot.Combat.Fighter.State.Dead } || sel.Kind == 0));
            _controlBar.SetMode(_combat.ModeNumber);
            if (_combat.ModeNumber != _lastMode)
            {
                if (_lastMode >= 0) Status(_combat.ModeNumber switch { 1 => "Entering Melee Combat mode", 2 => "Entering Missile Combat mode", 3 => "Entering Magic Combat mode", _ => "Entering Peace mode" }, "mode");
                _lastMode = _combat.ModeNumber;
            }
        }
        if (_statusIcons != null)
        {
            int cap = Math.Max(1, _combat.Me.Attribute(0) * 150);
            _statusIcons.SetBurden(_combat.Inv.TotalBurden / (float)cap);
            _statusIcons.SetStates(_magic != null && _magic.Active().Any(), false, _combat.Me.Vitae);
        }
        bool magic = _combat.MagicMode;
        _combatHud.HideCombatBar = magic && _spellBar != null;
        if (_spellBar != null && _spellBar.Visible != magic)
        {
            _spellBar.Visible = magic;
            if (magic && _spellBar.Position == Vector2.Zero) _spellBar.Position = new Vector2((screen.X - _spellBar.Size.X) * 0.5f, Math.Max(0, (_retail?.VitalsTop ?? screen.Y - 60) - _spellBar.Size.Y - 50));
        }
    }

    /// <summary>A shortcut used: an item wielded/worn (or taken off), a spell cast.</summary>
    private void UseShortcut(ACGodot.UI.ShortcutBar.Entry e)
    {
        if (_combat == null || _player?.Active != true) return;
        if (e.Kind == "item")
        {
            var inv = _combat.Inv;
            // (the item the slot stands for - the very one, where it knows which)
            var item = _bar?.ItemOf?.Invoke(e);
            var worn = item != null && inv.Worn.Contains(item) ? item : null;
            if (item == null) { _combatHud.Log($"You don't have {e.Name}", ACGodot.Combat.CombatHud.Plain); return; }
            // on a server, a thing that isn't worn or wielded: used (a gem, food, a kit - as a double click in the pack)
            if (worn == null && !item.Wearable && item.Guid != 0) { UseCarried(item); return; }
            string said = worn != null ? inv.Unequip(item) : item.Wearable ? inv.Equip(item) : $"You can't use {item.Name} like that";
            if (said.Length > 0) _combatHud.Log(said, ACGodot.Combat.CombatHud.Plain);
            _combat.GearChanged();
            _packWin?.Refresh();
            _invPanel?.Refresh();
        }
        else if (e.Kind == "spell") CastSpell(e.Id);
    }

    /// <summary>A plugin uses this very item (not another of its kind): taken off if worn, worn or wielded if it can be, else used.</summary>
    private void UseExact(ACGodot.Combat.Item item)
    {
        if (_combat == null || _player?.Active != true) return;
        var inv = _combat.Inv;
        bool worn = inv.Worn.Contains(item);
        if (!worn && !inv.Pack.Contains(item)) return;
        if (!worn && !item.Wearable && item.Guid != 0) { UseCarried(item); return; }
        string said = worn ? inv.Unequip(item) : item.Wearable ? inv.Equip(item) : $"You can't use {item.Name} like that";
        if (said.Length > 0) _combatHud.Log(said, ACGodot.Combat.CombatHud.Plain);
        _combat.GearChanged();
        _packWin?.Refresh();
        _invPanel?.Refresh();
    }

    /// <summary>A spell cast (the magic system, once there).</summary>
    private void CastSpell(int spellId) => _magic?.Cast(spellId);

    /// <summary>A line typed in the chat: a /command, or something said.</summary>
    private void OnChat(string text)
    {
        var sys = new Color(1f, 0.9f, 0.4f);
        if (!text.StartsWith("/"))
        {
            if (_net?.Talk(text) == true) return;   // on a server: it says it back
            Say($"You say, \"{text}\"", Colors.White, ACGodot.UI.ChatKind.AreaChat);
            return;
        }
        // plugins see a command first (as Decal's do), and can take it
        if (_plugins?.OfferCommand(text) == true) return;
        var parts = text.Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
        string cmd = parts[0].ToLowerInvariant(), rest = parts.Length > 1 ? parts[1] : "";
        switch (cmd)
        {
            case "/chatlog":
                Say(ChatLogCommand(rest), sys);
                return;
            case "/help":
                Say("Commands:", sys);
                Say("  Where you are: /loc - where you are;  /go <42.1N 33.6E | landblock A9B4 | cell 01D90108> - go there;  /arrow <coords | clear> - point the arrow (or click coordinates in chat);  /map [dungeon 01D9] - the world map (M), or a dungeon's layout", sys);
                Say("  Recalls (on a server): /ls (/lifestone), /mp (/marketplace), /hr (/house), /hom (/mansion), /ah (allegiance hometown), /pka, /pkl", sys);
                Say("  Talking: /tell <name, message> (/t);  /f, /a, /general, /trade, /lfg, /society <message> - the channels;  /channel <name> <message>", sys);
                Say("  Magic: /spells - the spellbook (Shift+M);  /cast <spell name>", sys);
                Say("  Windows: /options - the options (Ctrl+O);  /plugins - what's loaded;  /xp, /bounty - the built-in plugins;  /mt (or /mtank) - MelkTank;  /mqt - MelksQB (quests, travel: /ga)", sys);
                Say("  Debugging: /debug - the debug text on or off (Ctrl+D);  /debug landscape - hide or show the landscape (to tell it from a model)", sys);
                Say("  Drawing: /3d [on | off] - stop or start drawing the 3D world by hand, to try it (Options > Display stops it while the window isn't the active one)", sys);
                Say("  /help - this list", sys);
                break;
            // the recalls: asked of the server, which takes you there after the usual wait
            case "/lifestone": case "/ls": case "/marketplace": case "/mp": case "/house": case "/hr": case "/mansion": case "/hom":
            case "/ah": case "/pkarena": case "/pka": case "/pklarena": case "/pkl":
            {
                uint act = cmd switch
                {
                    "/lifestone" or "/ls" => 0x0063u, "/marketplace" or "/mp" => 0x028Du, "/house" or "/hr" => 0x0262u, "/mansion" or "/hom" => 0x0278u,
                    "/ah" => 0x02ABu, "/pkarena" or "/pka" => 0x0027u, _ => 0x0026u,
                };
                // (the short forms, and the game's own first words where no other command has them)
                if (_net?.Recall(act) != true) Say("Recalls are the server's to do: there's none here.", sys);
                break;
            }
            case "/tell":
            case "/t":
                // "name, what to say" (there's no one else in the world yet to hear it)
                int comma = rest.IndexOf(',');
                if (comma <= 0 || comma == rest.Length - 1) Say("Tell who what? /tell name, message", sys);
                else
                {
                    string to = rest[..comma].Trim(), msg = rest[(comma + 1)..].Trim();
                    // (on a server it says "You tell ..." itself: not said here too)
                    if (_net != null) _net.Tell(to, msg);
                    else Say($"You tell {to}, \"{msg}\"", new Color(0.85f, 0.75f, 0.4f), ACGodot.UI.ChatKind.Tells);
                }
                break;
            case "/r":
            case "/reply":
                // an answer to whoever last told us something
                if (_net?.LastTeller is not { Length: > 0 } teller) Say("No one has sent you a tell to reply to.", sys);
                else if (rest.Trim().Length == 0) Say($"Reply to {teller} with what? /r message", sys);
                else _net.Tell(teller, rest.Trim());
                break;
            case "/channel":
                // "General what to say" (no one else on the channels yet)
                var cp = rest.Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
                if (cp.Length == 2) SayOn(cp[0], cp[1]);
                break;
            case "/f": case "/fellowship": SayOn("Fellowship", rest); break;
            case "/a": case "/allegiance": SayOn("Allegiance", rest); break;
            case "/general": SayOn("General", rest); break;
            case "/trade": SayOn("Trade", rest); break;
            case "/lfg": SayOn("LFG", rest); break;
            case "/society": SayOn("Society", rest); break;
            case "/map":
            {
                // /map (open / shut), /map dungeon 01D9 (a dungeon's layout)
                var mparts = rest.Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries);
                if (_map == null) break;
                if (mparts.Length == 2 && mparts[0].Equals("dungeon", StringComparison.OrdinalIgnoreCase) && int.TryParse(mparts[1].Replace("0x", ""), System.Globalization.NumberStyles.HexNumber, null, out int dlb)) _map.ShowDungeon(dlb);
                else _map.Toggle();
                break;
            }
            case "/arrow":
            {
                // /arrow 42.1N 33.6E (or "clear")
                if (rest.Trim().Equals("clear", StringComparison.OrdinalIgnoreCase) || rest.Trim().Length == 0) { _arrow?.Clear(); break; }
                var am = System.Text.RegularExpressions.Regex.Match(rest.ToUpperInvariant(), @"([\d.]+)\s*([NS])[\s,]+([\d.]+)\s*([EW])");
                if (!am.Success) { Say("Point where? /arrow 42.1N 33.6E (or /arrow clear)", sys); break; }
                double ans = double.Parse(am.Groups[1].Value, System.Globalization.CultureInfo.InvariantCulture) * (am.Groups[2].Value == "S" ? -1 : 1);
                double aew = double.Parse(am.Groups[3].Value, System.Globalization.CultureInfo.InvariantCulture) * (am.Groups[4].Value == "W" ? -1 : 1);
                PointAt(ans, aew, rest.Trim());
                break;
            }
            case "/spells":
                _spellbook?.Open();
                break;
            case "/cast":
                // /cast <spell name>: the first known spell with that name
                var known = _magic?.Known().FirstOrDefault(sp => sp.Name.Equals(rest.Trim(), StringComparison.OrdinalIgnoreCase));
                if (known != null) CastSpell(known.Id); else Say($"You don't know a spell called {rest.Trim()}", sys);
                break;
            case "/options":
                ToggleOptions();
                break;
            case "/fillcomps":
            {
                // what's short of the numbers wanted on the spellbook's Components tab (at a component vendor the game
                // adds these to the buy list - ACGodot has no vendor windows yet, so it only says)
                var want = ACGodot.UI.SpellbookPanel.Wanted();
                var held = ACGodot.UI.SpellbookPanel.ComponentsHeld(_combat?.Inv);
                if (want.Count == 0) { Say("Fill components: set how many of each you want on the spellbook's Components tab first.", sys); break; }
                int shortOf = 0, listed = 0;
                bool shopOpen = _vendorWin?.Vendor != null;
                foreach (var (wcid, name, _, have) in held)
                    if (want.TryGetValue(wcid, out int w) && w > have)
                    {
                        shortOf++;
                        bool added = shopOpen && _vendorWin!.AddToBuy(wcid, w - have);
                        if (added) listed++;
                        Say($"  {name}: {have} of {w} - {w - have} {(added ? "added to the buy list" : shopOpen ? "to buy (not sold here)" : "to buy")}", sys);
                    }
                Say(shortOf == 0 ? "Fill components: you have all you want of every component you carry."
                    : shopOpen ? $"Fill components: {listed} of {shortOf} added to the buy list."
                    : "Open a spell component vendor and use /fillcomps again to put these on the buy list.", sys);
                break;
            }
            case "/net":
                // playing on a server: what's come from it so far (for working out what's missing)
                if (_net == null) Say("Not playing on a server (Options > Network).", sys);
                else foreach (var line in _net.Report()) Say("[Network] " + line, sys);
                break;
            case "/3d":
            {
                // the 3D world's drawing off / on (the interface and plugins are drawn either way; the game carries on)
                string w3 = rest.Trim().ToLowerInvariant();
                bool draw = w3 == "on" || (w3 != "off" && _noWorldByHand);
                _noWorldByHand = !draw;
                ApplyBackground();
                Say(draw ? "3D world drawn" : "3D world not drawn - the interface and plugins carry on (/3d draws it again)", sys);
                break;
            }
            case "/debug":
                if (rest.Trim().Equals("landscape", StringComparison.OrdinalIgnoreCase))
                {
                    // check whether something is the landscape or a model: hide the landscape
                    _terrainHidden = !_terrainHidden;
                    Say(_terrainHidden ? "Landscape hidden (/debug landscape shows it again)" : "Landscape shown", sys);
                    break;
                }
                _hud.Visible = !_hud.Visible;
                SaveDebugShown();
                Say($"Debug text {(_hud.Visible ? "on" : "off")}", sys);
                break;
            case "/loc":
                var at = _player?.Active == true ? _player.Position : _cam.Position;
                var (lx, ly) = World.LandblockAt(at);
                Say($"You are at {World.MapCoords(at)} (landblock 0x{lx:X2}{ly:X2})", sys);
                break;
            case "/go":
            case "/goto":
                if (rest.Length == 0) Say("Go where? /go 42.1N 33.6E, a landblock (A9B4) or a cell (01D90108)", sys);
                else { OnGotoSubmitted(rest); Say(_status, sys); }
                break;
            default:
                // (a plugin's own typing on a server is for the server - its /xp is the server's, not the experience window's)
                if (_plugins?.QuietUnknown == true && _net?.Talk("@" + text[1..]) == true) break;
                // (/xp typed on a server is the server's own command; the experience window is its button on the plugin
                // bar, or /xptrack typed)
                if (cmd.Equals("/xp", StringComparison.OrdinalIgnoreCase) && _net?.InWorld == true && _net.Talk("@" + text[1..])) break;
                if (cmd.Equals("/xptrack", StringComparison.OrdinalIgnoreCase)) { _plugins?.TryCommand("/xp", rest); break; }
                if (_plugins?.TryCommand(cmd, rest) == true) break;
                // not one of ours: the server's to answer (its own commands - /bank and the like - come as things said)
                if (_net?.Talk("@" + text[1..]) == true) break;   // (the server takes its commands with an @)
                if (_plugins?.QuietUnknown == true) break;   // (a plugin's server command: nothing here does it)
                Say($"Unknown command {cmd} (/help for the list)", sys);
                break;
        }
    }

    /// <summary>A line said on a channel (fellowship, allegiance, general, trade...), in its colour.</summary>
    private void SayOn(string channel, string text)
    {
        text = text.Trim();
        if (text.Length == 0) { Say($"Say what on {channel}?", new Color(1f, 0.9f, 0.4f)); return; }
        var color = channel switch
        {
            "Fellowship" => new Color(1f, 1f, 0.45f),
            "Allegiance" => new Color(0.45f, 1f, 0.45f),
            "Trade" => new Color(1f, 0.75f, 0.45f),
            _ => new Color(0.55f, 0.85f, 1f),
        };
        var kind = channel switch
        {
            "Fellowship" => ACGodot.UI.ChatKind.Fellowship, "Allegiance" => ACGodot.UI.ChatKind.Allegiance, "Trade" => ACGodot.UI.ChatKind.Trade,
            "LFG" => ACGodot.UI.ChatKind.LFG, "Society" => ACGodot.UI.ChatKind.Society, "Roleplay" => ACGodot.UI.ChatKind.Roleplay,
            _ => ACGodot.UI.ChatKind.General,
        };
        // on a server: said there (it shows it back to us with everyone else's); playing alone, just shown
        if (_net?.InWorld == true)
        {
            bool sent = channel == "Fellowship" ? _net.SayToFellowship(text) : _net.SayOnChannel(channel, text);
            if (!sent) Say($"You're not on the {channel} channel.", new Color(1f, 0.9f, 0.4f));
            return;
        }
        Say($"[{channel}] You say, \"{text}\"", color, kind);
    }

    // ── not the active window: the 3D world's drawing and the sound can stop (Options > Display); /3d stops the drawing
    //    by hand, to try it ──
    private bool _windowActive = true, _noWorldByHand;
    private bool _testDraws;   // (a test asked for the world drawn though the window isn't the active one: its pictures need it)
    private static bool BackgroundFlag(string key) { var c = new ConfigFile(); return global::ACGodot.SafeConfig.Load(c, "user://ui.cfg") == Error.Ok && (bool)c.GetValue("background", key, false); }
    /// <summary>What of ACGodot's own files is backed up: its settings - not logs, caches or the drawn world map.</summary>
    private static bool SettingsFile(string rel)
    {
        string low = rel.Replace('\\', '/').ToLowerInvariant();
        foreach (string d in new[] { "logs/", "shader_cache/", "vulkan/", "objectdb_snapshots/" }) if (low.StartsWith(d)) return false;
        if (low.Contains(".tmp")) return false;
        string ext = System.IO.Path.GetExtension(low);
        return ext is ".cfg" or ".json" or ".keymap" or ".ini" or ".txt" or ".xml";
    }

    private static void SetBackgroundFlag(string key, bool on) { var c = new ConfigFile(); global::ACGodot.SafeConfig.Load(c, "user://ui.cfg"); c.SetValue("background", key, on); global::ACGodot.SafeConfig.Save(c, "user://ui.cfg"); }
    private bool _restWorld = BackgroundFlag("no_3d"), _restSound = BackgroundFlag("no_sound"), _soundOff = BackgroundFlag("sound_off");
    private void ApplyBackground()
    {
        RenderingServer.SetDefaultClearColor(Colors.Black);   // (what's behind the windows with the world not drawn: black, not Godot's grey)
        GetViewport().Disable3D = _noWorldByHand || (_restWorld && !_windowActive && !_testDraws);
        AudioServer.SetBusMute(0, _soundOff || (_restSound && !_windowActive));
        // a window you're not playing in: drawn at most 30 times a second, so two games on one graphics card don't
        // slow each other down (the active one back to its own settings)
        // (and not waiting on the screen's refresh either: the game you're watching was left waiting on it behind the
        // other's frames - smooth till a second game started, then a frame every 60-80 ms though neither the graphics card
        // nor the game's code was busy)
        if (!_windowActive && !_testDraws)
        {
            DisplayServer.WindowSetVsyncMode(DisplayServer.VSyncMode.Disabled);
            Engine.MaxFps = ACGodot.UI.Video.FrameCap > 0 ? Math.Min(ACGodot.UI.Video.FrameCap, BackgroundFps) : BackgroundFps;
        }
        else if (!_vsyncDropped) ACGodot.UI.Video.ApplyFrames();
    }
    private const int BackgroundFps = 30;

    // whether the window is the active one, asked now and then as well as told: a game started behind another window
    // is never told it lost the focus it never had, and went on drawing at full speed as if you were playing in it
    private double _focusCheckIn;
    private void CheckFocus(double delta)
    {
        if ((_focusCheckIn -= delta) > 0) return;
        _focusCheckIn = 0.5;
        bool active = DisplayServer.WindowIsFocused();
        if (active == _windowActive) return;
        _windowActive = active;
        if (active) FrameStallOver();
        ApplyBackground();
    }
    public bool WindowActive => _windowActive;

    private static readonly string[] HeritageNames = { "", "Aluvian", "Gharu'ndim", "Sho", "Viamontian", "Umbraen", "Gearknight", "Tumerok", "Lugian", "Empyrean", "Penumbraen", "Undead", "Olthoi", "Olthoi" };

    // on a server: the character is the server's (its name, level, attributes, vitals and skills as it describes them) -
    // put over the one in hand, which from then on isn't saved (the offline character's file stays as it was)
    // the server's answer about something looked at: the panel, if it's still showing that thing, filled in
    // a player as the game sets them out when identified: who they are, their allegiance, armor, ratings, and what they let be seen
    private void PlayerRows(ACGodot.Net.NetGame.Appraisal a, string name, List<(string, string)> rows, out string line1, out string line2, out string line3)
    {
        // another player, as the game sets them out: who they are, their allegiance, armor, ratings, and what they let be seen
        string S(int k) => a.Strings.TryGetValue(k, out var v) ? v : "";
        int I(int k) => a.Ints.TryGetValue(k, out int v) ? v : 0;
        line1 = $"{S(3)} {S(4)}".Trim();
        // (the title they show - told by its number - in place of the template they were made from)
        line2 = I(261) > 0 && TitleName((uint)I(261)) is { Length: > 0 } shownTitle ? shownTitle : S(5);
        line3 = (I(134) & 0x4) != 0 ? "Player Killer" : (I(134) & 0x40) != 0 ? "Player Killer Lite" : "Non-Player Killer";
        rows.Add(("", ""));
        foreach (var (k, society) in new[] { (287, "Celestial Hand"), (288, "Eldrytch Web"), (289, "Radiant Blood") })
            if (I(k) > 0) rows.Add(("Society", $"{society} - {(I(k) >= 1001 ? "Master" : I(k) >= 601 ? "Lord" : I(k) >= 301 ? "Knight" : I(k) >= 101 ? "Adept" : "Initiate")}"));
        if (S(47).Length > 0) rows.Add(("Allegiance", S(47)));
        if (S(21).Length > 0) rows.Add(("Monarch", S(21)));
        else if (a.Ints.ContainsKey(35)) rows.Add(("Monarch", $"{name} ({I(35):N0} followers)"));
        if (S(35).Length > 0) rows.Add(("Patron", S(35)));
        if (S(10).Length > 0) rows.Add(("Fellowship", S(10)));
        if (a.ArmorLevels is { } al)
        {
            rows.Add(("", ""));
            rows.Add(("Head/Chest/Groin", $"AL: {al[0]}/{al[1]}/{al[2]}"));
            rows.Add(("Bicep/Wrist/Hand", $"AL: {al[3]}/{al[4]}/{al[5]}"));
            rows.Add(("Thigh/Shin/Foot", $"AL: {al[6]}/{al[7]}/{al[8]}"));
        }
        if (I(307) != 0 || I(314) != 0 || I(308) != 0 || I(316) != 0)
        {
            rows.Add(("", ""));
            rows.Add(("Dmg/CritDmg", $"Rating: {I(307)}/{I(314)}"));
            rows.Add(("Dmg/CritDmg", $"Resist: {I(308)}/{I(316)}"));
        }
        rows.Add(("", ""));
        if (S(43).Length > 0) rows.Add(("Arrived in Dereth", S(43)));
        if (a.Ints.ContainsKey(125)) { int age = I(125); rows.Add(("Age", age >= 86400 ? $"{age / 86400}d {age % 86400 / 3600}h" : $"{age / 3600}h {age % 3600 / 60}m")); }
        if (a.Ints.ContainsKey(181)) rows.Add(("Chess Rank", I(181).ToString("N0")));
        if (a.Ints.ContainsKey(192)) rows.Add(("Fishing Skill", I(192).ToString("N0")));
        if (a.Ints.ContainsKey(43)) rows.Add(("Deaths", I(43).ToString("N0")));
        if (a.Ints.ContainsKey(262)) rows.Add(("Titles", I(262).ToString("N0")));
        if (I(390) > 0) rows.Add(("Enlightenment", I(390).ToString("N0")));
    }

    private void ShowAppraisal(ACGodot.Net.NetGame.Appraisal a)
    {
        // the plugins hear of it when the server has answered (an ID they asked for themselves too)
        if (a.Success) _plugins?.OnIdentified(a.Item != null ? a.Item : a.Thing != null ? a.Thing : _net != null && _objects != null && a.Guid == _net.GuidOf(_objects.Self) ? ACGodot.Plugins.PluginHost.Self : null);
        if (_examine == null) return;
        if (a.Success && _net != null && _objects != null && a.Guid == _net.GuidOf(_objects.Self) && _examine.ShowingSelf)
        {
            var mine = new List<(string, string)>();
            PlayerRows(a, _combat?.Me.Name ?? "", mine, out string m1, out string m2, out string m3);
            if (_net is { DisplayTitle: > 0 } tnet && TitleName(tnet.DisplayTitle) is { Length: > 0 } myTitle) m2 = myTitle;
            _examine.SelfMore(m1, m2, m3, mine);
            return;
        }
        if (a.Item != null && a.Thing == null)
        {
            if (_examine.Visible && _examine.ShownItem == a.Item) _examine.ShowItem(a.Item, false);
            _invPanel?.Refresh();
            return;
        }
        if (a.Thing == null || !_examine.Visible || _examine.ShownThing != a.Thing) return;
        if (a.Item != null && !a.Creature) { _examine.ShowItem(a.Item, false); return; }
        var rows = new List<(string, string)>();
        // (not assessed - your Assess Creature didn't beat it: ??? for each, as the game shows them)
        if (a.Attributes || (a.Creature && a.Thing.Kind < 3))
        {
            string[] names = { "Strength", "Endurance", "Coordination", "Quickness", "Focus", "Self" };
            int[] order = { 0, 1, 3, 2, 4, 5 };   // the game lists coordination before quickness
            for (int k = 0; k < 6; k++) rows.Add((names[k], a.Attributes ? a.Attribute[order[k]].ToString("N0") : "???"));
        }
        if (a.Creature)
        {
            rows.Add(("Health", $"{a.Health:N0}/{a.HealthMax:N0} ({(a.HealthMax > 0 ? (long)a.Health * 100 / a.HealthMax : 0)} %)"));
            if (a.Attributes) { rows.Add(("Stamina", $"{a.Stamina:N0}/{a.StaminaMax:N0}")); rows.Add(("Mana", $"{a.Mana:N0}/{a.ManaMax:N0}")); }
            else if (a.Thing.Kind < 3) { rows.Add(("Stamina", "???")); rows.Add(("Mana", "???")); }
        }
        string line1 = "", line2 = "", line3 = a.Thing.Kind == 1 ? "Non-Player Killer" : "";
        if (a.Thing.Kind >= 3) PlayerRows(a, a.Thing.Name, rows, out line1, out line2, out line3);
        else if (a.Creature)
        {
            // a creature's ratings, set out as a player's are: damage and critical damage, and its resistance to each
            int R(int k) => a.Ints.TryGetValue(k, out int v) ? v : 0;
            if (R(307) != 0 || R(314) != 0 || R(308) != 0 || R(316) != 0)
            {
                rows.Add(("", ""));
                rows.Add(("Damage Rating", R(307).ToString("N0")));
                rows.Add(("Crit Damage Rating", R(314).ToString("N0")));
                rows.Add(("Damage Resist", R(308).ToString("N0")));
                rows.Add(("Crit Damage Resist", R(316).ToString("N0")));
            }

        }
        var text = new List<string>();
        foreach (int k in new[] { 14, 15, 16 }) if (a.Strings.TryGetValue(k, out var t) && t.Length > 0 && !text.Contains(t)) text.Add(t);
        if (a.Thing.Type == 7) text.AddRange(PortalLines(a));
        // (a corpse's burden - and a chest's: in its ID, not by its name in the selection bar)
        if (a.Thing.Corpse || a.Thing.Type is 20 or 21 || ((_net?.ItemTypeOf(a.Thing.Guid) ?? 0) & 0x200) != 0)
        {
            int bu = a.Ints.TryGetValue(5, out int b5) ? b5 : (_net?.BurdenOf(a.Thing.Guid) ?? -1);
            if (bu >= 0) text.Insert(0, $"Burden: {bu:N0}");
        }
        // locked or not (a chest, a door): the server sends its lock's resistance and your chance to pick it only while locked
        {
            bool? locked = a.Bools.TryGetValue(3, out bool lk) ? lk : a.Ints.ContainsKey(38) ? true : null;
            if (locked == true)
            {
                var lines = new List<string> { "Locked" };
                if (a.Ints.TryGetValue(38, out int resist)) lines.Add($"Lock resistance: {resist:N0}");
                if (a.Ints.TryGetValue(173, out int chance)) lines.Add($"Your chance to pick it: {chance}%");
                text.Insert(Math.Min(1, text.Count), string.Join("\n", lines));
            }
            else if (locked == false) text.Insert(Math.Min(1, text.Count), "Unlocked");
        }
        if (!a.Creature && text.Count == 0) return;   // (nothing more to say of it: a door stays "It's shut.")
        _examine.ShowAppraised(a.Thing, a.Creature, a.Ints.TryGetValue(25, out int lv) ? lv : 0, rows, string.Join("\n\n", text), line1, line2, line3);
    }

    // a portal looked at closely: where it goes (as the server says, or - when it doesn't - as the map has it), and who may use it
    private List<string> PortalLines(ACGodot.Net.NetGame.Appraisal a)
    {
        var lines = new List<string>();
        if (a.Strings.TryGetValue(38, out var dest) && dest.Trim().Length > 0) lines.Add("Destination: " + dest.Trim());
        else
        {
            string known = "";
            try
            {
                if (_map?.Data != null && a.Thing != null)
                {
                    var (x, y, _) = World.ToAc(a.Thing.Feet);
                    double ns = y / 240.0 - 101.95, ew = x / 240.0 - 101.95;
                    static string C(double v, char pos, char neg) => $"{Math.Abs(v):0.0}{(v >= 0 ? pos : neg)}";
                    var p = _map.Data.Places.Where(o => o.HasExit && o.Type.Contains("Portal") && Math.Abs(o.NS - ns) < 0.3 && Math.Abs(o.EW - ew) < 0.3
                                                        && (o.Name.Equals(a.Thing.Name, StringComparison.OrdinalIgnoreCase) || o.Name.Contains(a.Thing.Name, StringComparison.OrdinalIgnoreCase) || a.Thing.Name.Contains(o.Name, StringComparison.OrdinalIgnoreCase)))
                                            .OrderBy(o => Math.Abs(o.NS - ns) + Math.Abs(o.EW - ew)).FirstOrDefault();
                    if (p != null) known = $"{C(p.ExitNS, 'N', 'S')}, {C(p.ExitEW, 'E', 'W')}";
                }
            }
            catch { }
            lines.Add(known.Length > 0 ? $"Destination: not shown by the server - the map has it going to {known}." : "Destination: not shown by the server.");
        }
        int I(int k) => a.Ints.TryGetValue(k, out int v) ? v : 0;
        int min = I(86), max = I(87);
        if (min > 0 || max > 0) lines.Add(max > 0 ? $"Restricted to characters of level {min} to {max}." : $"Restricted to characters of level {min} and above.");
        int bits = I(111);
        var rules = new List<string>();
        if ((bits & 0x10) != 0) rules.Add("no summoning it");
        if ((bits & 0x20) != 0) rules.Add("no recalling to it");
        if ((bits & 0x02) != 0) rules.Add("not for player killers");
        if ((bits & 0x04) != 0) rules.Add("not for PK lites");
        if ((bits & 0x08) != 0) rules.Add("not for non-player killers");
        if (rules.Count > 0) lines.Add("Rules: " + string.Join(", ", rules) + ".");
        // a portal that's only up a while (summoned, the cow level, the thieves' parlor): how long it has left, as the
        // server counted it when looked at (RemainingLifespan, else Lifespan from when it appeared)
        int left = a.Ints.TryGetValue(268, out int rl) ? rl : -1;
        if (left < 0 && a.Ints.TryGetValue(267, out int life) && life > 0 && a.Floats.TryGetValue(98, out double made) && made > 0)
            left = (int)Math.Max(0, made + life - DateTimeOffset.UtcNow.ToUnixTimeSeconds());
        if (left >= 0)
        {
            var ts = TimeSpan.FromSeconds(left);
            string howLong = ts.TotalHours >= 1 ? $"{(int)ts.TotalHours}h {ts.Minutes:00}m" : ts.TotalMinutes >= 1 ? $"{ts.Minutes}m {ts.Seconds:00}s" : $"{ts.Seconds}s";
            lines.Add($"Time left: {howLong} (gone at {DateTime.Now.AddSeconds(left):h:mm:ss tt}).");
        }
        return lines;
    }

    private void ApplyServerCharacter(ACGodot.Net.NetGame.ServerCharacter c)
    {
        if (_combat?.Me is not { } me) return;
        me.OnServer = true;
        me.Name = c.Name;
        if (_net?.OptionsRead == true) _retail?.SetVitalsStacked(!_net.Option("SideBySideVitals"));
        // the shortcut bar and the spell bars are each character's own
        if (c.Name.Length > 0) { string who = $"{_netCfg.Host}/{c.Name}"; _bar?.ForCharacter(who); _spellBar?.ForCharacter(who); }
        me.Level = c.Level; me.SkillCredits = c.SkillCredits;
        me.TotalXp = c.TotalXp; me.UnassignedXp = c.UnassignedXp;
        if (c.Heritage > 0 && c.Heritage < HeritageNames.Length) me.Heritage = HeritageNames[c.Heritage];
        for (int i = 0; i < 6; i++) { me.AttributeBase[i] = c.AttributeStart[i]; me.AttributeRanks[i] = c.AttributeRanks[i]; }
        for (int v = 0; v < 3; v++) me.VitalRanks[v] = c.VitalRanks[v];
        me.Skills.Clear();
        foreach (var (id, (training, ranks)) in c.Skills)
            me.Skills[id] = new ACGodot.Combat.Character.SkillState
            {
                Training = training >= 3 ? ACGodot.Combat.Character.Training.Specialized : training == 2 ? ACGodot.Combat.Character.Training.Trained : ACGodot.Combat.Character.Training.Untrained,
                Ranks = ranks,
            };
        ACGodot.Net.NetGame.ApplyOwnNumbers(c, me);
        me.Health = c.VitalNow[0]; me.Stamina = c.VitalNow[1]; me.Mana = c.VitalNow[2];
        if (_magic != null)
        {
            _player?.UseCameraOf(c.Name); _magic.ServerSpells = new HashSet<int>(c.Spells); if (_net != null) { var netm = _net; _magic.ServerMods = () => netm.EnchantMods.Values; } _magic.ServerBuffs();
            foreach (var (spell, left) in c.Enchantments) _magic.ServerEnchant(spell, left, true);
            _effectsPanel?.Refresh();
        }
        _bookPanel?.Refresh();
        _charPanel?.Refresh();
        _invPanel?.Refresh();
    }

    // the options: the game's side panel when it's there (the control bar's button, Esc, Ctrl+O, /options), else the old window
    private void ToggleOptions()
    {
        if (_optionsPanel != null) _optionsPanel.Toggle();
        else if (_options != null) { if (_options.Visible) _options.Visible = false; else _options.Open(); }
    }

    // the options: the game's own panel (one of the side panels - one open at a time with the others - not a window of
    // its own), our settings on its tabs
    private void SetupOptionsPanel()
    {
        if (_options == null || _optionsPanel != null) return;
        try
        {
            _optionsPanel = new ACGodot.UI.TabbedPanel { Name = "OptionsPanel" };
            _ui.AddChild(_optionsPanel);
            if (!_optionsPanel.Setup(ACGodot.UI.SidePanel.Options, 0x2100002B, 0x10000208, 0x10000210)) { _optionsPanel.QueueFree(); _optionsPanel = null; return; }
            var op = _optionsPanel;
            op.Shown = (p, open) => _controlBar?.SetPanelOpen(p.PanelId, open);
            _options.Rebuild = () => op.Refresh();
            op.Fill = (tab, name, box) =>
            {
                string n = name.ToLowerInvariant();
                if (n.Contains("character")) box.AddChild(_options.PageContent(1));
                else if (n.Contains("chat")) box.AddChild(_options.PageContent(2));
                else if (n.Contains("config")) box.AddChild(_options.PageContent(4));
                else
                {
                    // as the game has them at the top of its first page
                    var leave = new VBoxContainer();
                    if (_net?.InWorld == true) leave.AddChild(ACGodot.UI.SidePanel.Btn("Exit to Character Selection", () => { _net?.LogOut(); op.Visible = false; }));
                    leave.AddChild(ACGodot.UI.SidePanel.Btn("Exit Game", () => { op.Visible = false; if (_net != null) _net.LogOutThenQuit(() => GetTree().Quit()); else GetTree().Quit(); }));   // (logged out first, closed the moment it's done)
                    box.AddChild(leave);
                    box.AddChild(new HSeparator());
                    box.AddChild(_options.PageContent(0));
                }
            };
        }
        catch (Exception ex) { GD.PushWarning("options panel: " + ex.Message); _optionsPanel = null; }
    }

    private void SaveDebugShown()
    {
        var cfg = new ConfigFile();
        global::ACGodot.SafeConfig.Load(cfg, "user://ui.cfg");
        cfg.SetValue("debug", "shown", _hud.Visible);
        global::ACGodot.SafeConfig.Save(cfg, "user://ui.cfg");
    }

    public override void _ExitTree()
    {
        _combat?.Me.Save(_combat.Inv);
        _dats?.Dispose();
    }

    /// <summary>Where the data files are: --dat-dir=..., then ACGODOT_DAT_DIR, then user://acgodot.cfg, then the default.</summary>
    private static string DatDir()
    {
        foreach (string a in OS.GetCmdlineUserArgs())
            if (a.StartsWith("--dat-dir=")) return a.Substring("--dat-dir=".Length);
        foreach (string a in OS.GetCmdlineArgs())
            if (a.StartsWith("--dat-dir=")) return a.Substring("--dat-dir=".Length);
        string? env = System.Environment.GetEnvironmentVariable("ACGODOT_DAT_DIR");
        if (!string.IsNullOrEmpty(env)) return env;
        var cfg = new ConfigFile();
        if (global::ACGodot.SafeConfig.Load(cfg, "user://acgodot.cfg") == Error.Ok)
        {
            string d = (string)cfg.GetValue("data", "dat_dir", "");
            if (d.Length > 0) return d;
        }
        else
        {
            cfg.SetValue("data", "dat_dir", DefaultDatDir);
            global::ACGodot.SafeConfig.Save(cfg, "user://acgodot.cfg");
        }
        return DefaultDatDir;
    }
}
