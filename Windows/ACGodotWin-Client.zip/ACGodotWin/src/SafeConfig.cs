using System.Runtime.CompilerServices;
using System.Threading;
using Godot;

namespace ACGodot;

/// <summary>
/// Settings files (ui.cfg and the rest) read and written safely when more than one client shares them: a file another
/// client is in the middle of writing is read again (a moment later) rather than taken as empty, a settings file that
/// couldn't be read is never written back (that wrote just the one changed setting over everything else), and a file
/// is written whole to a side file and then swapped in, so nobody ever reads it half-written.
/// </summary>
public static class SafeConfig
{
    private static readonly ConditionalWeakTable<ConfigFile, object> _unread = new();

    /// <summary>As <see cref="ConfigFile.Load"/>: Ok, or FileNotFound for a file that isn't there yet.</summary>
    public static Error Load(ConfigFile c, string path)
    {
        _unread.Remove(c);
        if (!FileAccess.FileExists(path)) return Error.FileNotFound;
        Error e = Error.Failed;
        for (int i = 0; i < 8; i++)
        {
            e = c.Load(path);
            if (e == Error.Ok) return e;
            c.Clear();
            Thread.Sleep(30);
        }
        _unread.AddOrUpdate(c, new object());
        GD.PushWarning($"settings: {path} couldn't be read ({e}) - not saving over it");
        return e;
    }

    public static Error Save(ConfigFile c, string path)
    {
        if (_unread.TryGetValue(c, out _)) return Error.Locked;
        string tmp = path + ".tmp" + OS.GetProcessId();
        Error e = c.Save(tmp);
        if (e != Error.Ok) return e;
        e = DirAccess.RenameAbsolute(ProjectSettings.GlobalizePath(tmp), ProjectSettings.GlobalizePath(path));
        if (e != Error.Ok) { e = c.Save(path); DirAccess.RemoveAbsolute(ProjectSettings.GlobalizePath(tmp)); }
        return e;
    }
}
