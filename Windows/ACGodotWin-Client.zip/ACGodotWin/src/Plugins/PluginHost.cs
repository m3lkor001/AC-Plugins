using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using ACGodot.Combat;
using ACGodot.Objects;
using ACGodot.UI;
using Godot;

namespace ACGodot.Plugins;

/// <summary>
/// A plugin: ACGodot's own (built in) or one loaded from a DLL in the plugins folder. Started once the world is up;
/// it talks to the game through the <see cref="PluginHost"/> it's given.
/// </summary>
/// <summary>A plugin's on / off switches the phone app works (MelkTank's: master, combat, nav, loot, buff) and its routes.</summary>
/// <summary>A plugin's test / logging switch, shown in Options > Plugins > Debug.</summary>
public sealed record DebugSwitch(string Name, string Tip, Func<bool> Get, Action<bool> Set);

/// <summary>A plugin that has test or logging switches for Options > Plugins > Debug.</summary>
public interface IDebugSwitches
{
    IEnumerable<DebugSwitch> DebugSwitches();
}

public interface IBotSwitches
{
    bool Get(string feature);
    bool SetFeature(string feature, bool on);
    IEnumerable<string> Routes();
    void LoadRoute(string name);
    string RouteName { get; }
    string NavMode { get; }
    string Status { get; }
    /// <summary>The bot's own status for the phone, as its status file has it (JSON; "" if it keeps none): its session's kills, bank, bounties and the rest.</summary>
    string StatusJson() => "";
    /// <summary>The bot's own session for the phone, as its session file has it (JSON; "" if it keeps none).</summary>
    string SessionJson() => "";
    /// <summary>A phone command the game doesn't carry out itself (action and its values, as the phone service sends them),
    /// handed to the bot to do as its own phone commands are done; false if it won't.</summary>
    bool PhoneCommand(string action, IReadOnlyDictionary<string, string> values) => false;
}

public interface IPlugin
{
    string Name { get; }
    void Start(PluginHost host);
    void Stop();
}

/// <summary>A plugin that can be stopped for a reload (its new copy takes over at once) without telling the others the
/// character logged off - which a plain Stop may do.</summary>
public interface IReloadable
{
    void StopForReload();
}

/// <summary>
/// The load context a plugin folder's DLL lives in: collectible, so a new copy can replace it while the game runs.
/// What the game itself has (ACGodot, Godot, ImGui...) and the shared library folder (the Decal stand-in) are the game's
/// own, shared by every plugin and never unloaded; only the plugin and what's in its own folder are its.
/// </summary>
public sealed class PluginContext : System.Runtime.Loader.AssemblyLoadContext
{
    private readonly string _dir, _lib;
    private readonly System.Runtime.Loader.AssemblyLoadContext _game;
    public PluginContext(string name, string dir, string lib, System.Runtime.Loader.AssemblyLoadContext game) : base("plugin " + name, isCollectible: true)
    { _dir = dir; _lib = lib; _game = game; }
    protected override System.Reflection.Assembly? Load(System.Reflection.AssemblyName n)
    {
        // (already loaded by the game - in its own context, the default one (Godot's GodotSharp is there), or any other
        // that isn't a plugin's: that copy, shared)
        bool Named(System.Reflection.Assembly a) => string.Equals(a.GetName().Name, n.Name, StringComparison.OrdinalIgnoreCase);
        var have = _game.Assemblies.FirstOrDefault(Named)
                   ?? Default.Assemblies.FirstOrDefault(Named)
                   ?? All.Where(c => c is not PluginContext && !ReferenceEquals(c, this)).SelectMany(c => c.Assemblies).FirstOrDefault(Named);
        if (have != null) return have;
        string lib = Path.Combine(_lib, n.Name + ".dll");
        if (File.Exists(lib)) return _game.LoadFromAssemblyPath(Path.GetFullPath(lib));
        string own = Path.Combine(_dir, n.Name + ".dll");
        if (File.Exists(own)) return LoadFromAssemblyPath(Path.GetFullPath(own));
        return null;   // (the framework's: as usual)
    }
}

/// <summary>A window for a plugin, in the game's look: put controls in <see cref="Content"/>.</summary>
public partial class PluginWindow : GameWindow
{
    public PluginWindow(string title, Vector2 size) : base(title, size) { }
    public VBoxContainer Content => Body;
    public void ClearContent() => Clear();
    public new static Label Text(string s, int size = 13, Color? color = null) => GameWindow.Text(s, size, color);
    public new static Label Heading(string s) => GameWindow.Heading(s);
    public new static Button Small(string s, Action onPress, bool enabled = true) => GameWindow.Small(s, onPress, enabled);
}

/// <summary>
/// What plugins can see and do: events (chat lines, kills, each frame), the character, what's around (creatures,
/// corpses), and acting (select, attack, cast, move to a spot, loot), plus their own chat commands, windows and
/// text (which goes to chat window 5, "Plugins"). Loads the built-in plugins and any DLLs in the plugins folder
/// (a folder each in the "plugins" folder beside the game: plugins/Name/Name.dll; plugins/plugins.json says which are off).
/// </summary>
public partial class PluginHost : Node
{
    // what the host works with (set by Main)
    public CombatSystem Combat = null!;
    public ObjectStreamer Objects = null!;
    public Creatures.Player Player = null!;
    public Magic.MagicSystem? Magic;
    public Node Ui = null!;
    /// <summary>The server connection (null offline): what a plugin does to the server's things goes through it.</summary>
    public Net.NetGame? Net;
    public bool OnServer => Net?.InWorld == true;
    public Action<string, Color, ChatKind>? SayTo;
    /// <summary>Leaves the game (as Options > Exit the game does).</summary>
    public Action? Quit;
    /// <summary>Out of the world properly, then the game closed at the character screen.</summary>
    public Action? LogoutQuit;
    /// <summary>Whether a shot from you reaches a thing of the server's (by its id) with nothing of the world in the way -
    /// creatures (pets too) not counted. Null when it can't be told; else (clear, what was in the way).</summary>
    public Func<uint, (bool clear, string what)?>? ClearShot;
    /// <summary>Runs a line as if typed in the chat (a /command or something said).</summary>
    public Action<string>? Type;
    /// <summary>A /command typed: offered to plugins first (true: one took it - the game doesn't see it).</summary>
    public event Func<string, bool>? CommandTyped;
    public bool OfferCommand(string text)
    {
        foreach (Func<string, bool> f in CommandTyped?.GetInvocationList() ?? Array.Empty<Delegate>())
        {
            try { if (f(text)) return true; } catch (Exception ex) { GD.PushWarning("plugin command: " + ex.Message); }
        }
        return false;
    }
    /// <summary>The folder with the game's data files (client_portal.dat, client_cell_1.dat).</summary>
    public string DatDir = "";
    /// <summary>The server and account playing on (empty offline).</summary>
    public string ServerName = "", Account = "";
    /// <summary>The arrow (point it at coordinates, or clear it) and the world map (open it on a spot, or a dungeon's layout).</summary>
    public Action<double, double, string>? PointArrow, ShowOnMap;
    /// <summary>Set by a plugin that takes coordinates clicked in chat (or /arrow) itself - a travel window: our own arrow then stays away.</summary>
    public Action<double, double, string>? CoordsWanted;
    public Action? ClearArrow;
    /// <summary>A plugin's travel target marked on the map (name shown beside it); null clears it.</summary>
    public Action<double, double, string>? MarkOnMap;
    public Action? ClearMapMark;
    /// <summary>A plugin's points for a dungeon's map: (in = "d:01D9", tag, points) - replaces what it sent before with that tag.</summary>
    public Action<string, string, IReadOnlyList<(string name, string type, double ns, double ew, double z)>>? MapPoints;
    public Action<int>? ShowDungeonMap;
    /// <summary>Where the arrow points (null: nowhere).</summary>
    public Func<(double ns, double ew)?>? ArrowTarget;
    /// <summary>ImGui is drawn (plugins with ImGui windows draw in this, each frame).</summary>
    public static event Action? ImGuiRender
    {
        add => UI.ImGuiLayer.Render += value;
        remove => UI.ImGuiLayer.Render -= value;
    }
    /// <summary>A built-in plugin by its type.</summary>
    public T? Find<T>() where T : class, IPlugin => _plugins.OfType<T>().FirstOrDefault();

    // events
    /// <summary>A line in the chat (its text and kind).</summary>
    public event Action<string, ChatKind>? ChatLine;
    /// <summary>A creature you killed: name, wcid, experience, corpse.</summary>
    public event Action<string, int, long, ObjectStreamer.Selectable>? Killed;
    /// <summary>On a server: it said we killed something (the line it sent about it).</summary>
    public event Action<string>? ServerKilled;
    public void RaiseServerKilled(string text) { try { ServerKilled?.Invoke(text); } catch (Exception ex) { GD.PushWarning("plugin kill: " + ex.Message); } }
    /// <summary>Every frame (seconds since the last).</summary>
    public event Action<double>? Tick;

    private readonly List<IPlugin> _plugins = new();
    private static readonly HashSet<System.Runtime.Loader.AssemblyLoadContext> _resolving = new();
    private readonly Dictionary<string, (IPlugin owner, Action<string> run, string help)> _commands = new(StringComparer.OrdinalIgnoreCase);
    private IPlugin? _starting;

    public IReadOnlyList<IPlugin> Plugins => _plugins;

    // ── which plugins start: plugins/plugins.json ({"disabled": [...], "known": [...]}) - the game, Options and the
    //    MelkTank Launcher all read and write it; a change applies the next time the game starts ──
    public static string PluginsDir => ProjectSettings.GlobalizePath("res://plugins");
    public static string SwitchFile => Path.Combine(PluginsDir, "plugins.json");

    /// <summary>The plugins switched off (by name: a built-in's name, or a plugin folder's name).</summary>
    public static HashSet<string> Disabled()
    {
        var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        try
        {
            if (!File.Exists(SwitchFile)) return set;
            var j = System.Text.Json.Nodes.JsonNode.Parse(File.ReadAllText(SwitchFile));
            if (j?["disabled"] is System.Text.Json.Nodes.JsonArray a) foreach (var n in a) if (n?.GetValue<string>() is { Length: > 0 } v) set.Add(v);
        }
        catch (Exception ex) { GD.PushWarning("plugins.json: " + ex.Message); }
        return set;
    }

    /// <summary>Every plugin there is: the built-in ones, then a folder each (plugins/Name/Name.dll).</summary>
    public static List<string> Known { get; } = new();

    public static void SaveSwitches(IEnumerable<string> disabled)
    {
        try
        {
            Directory.CreateDirectory(PluginsDir);
            var j = new System.Text.Json.Nodes.JsonObject
            {
                ["disabled"] = new System.Text.Json.Nodes.JsonArray(disabled.Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x).Select(x => (System.Text.Json.Nodes.JsonNode?)x).ToArray()),
                ["known"] = new System.Text.Json.Nodes.JsonArray(Known.Select(x => (System.Text.Json.Nodes.JsonNode?)x).ToArray()),
            };
            File.WriteAllText(SwitchFile, j.ToJsonString(new System.Text.Json.JsonSerializerOptions { WriteIndented = true }));
        }
        catch (Exception ex) { GD.PushWarning("plugins.json: " + ex.Message); }
    }

    /// <summary>Switches a plugin on or off (from the next start). False if there's no plugin by that name.</summary>
    public static bool Switch(string name, bool on)
    {
        string? real = Known.FirstOrDefault(k => k.Equals(name, StringComparison.OrdinalIgnoreCase));
        if (real == null) return false;
        var off = Disabled();
        if (on) off.Remove(real); else off.Add(real);
        SaveSwitches(off);
        return true;
    }

    /// <summary>The plugin folders: plugins/Name/ holding Name.dll (its own files beside it, as in Decal Plugins).</summary>
    private static IEnumerable<(string name, string dll)> Folders()
    {
        if (!Directory.Exists(PluginsDir)) yield break;
        foreach (var d in Directory.GetDirectories(PluginsDir).OrderBy(x => x, StringComparer.OrdinalIgnoreCase))
        {
            string name = Path.GetFileName(d), dll = Path.Combine(d, name + ".dll");
            if (File.Exists(dll)) yield return (name, dll);
        }
    }

    public void Start(IEnumerable<IPlugin> builtIn)
    {
        Combat.Killed += (n, w, xp, s) => Killed?.Invoke(n, w, xp, s);
        var off = Disabled();
        var builtInList = builtIn.ToList();
        var folders = Folders().ToList();
        Known.Clear();
        Known.AddRange(builtInList.Select(p => p.Name));
        Known.AddRange(folders.Select(f => f.name));
        SaveSwitches(off);   // (the list of what there is, for Options and the launcher)
        foreach (var p in builtInList) if (!off.Contains(p.Name)) Run(p);
        // into the game's own load context (so plugins see the same ACGodot and Godot types as the game); what they
        // need of their own (the Decal stand-in in lib/, ...) from plugins/lib or their own folder
        var ctx = System.Runtime.Loader.AssemblyLoadContext.GetLoadContext(typeof(PluginHost).Assembly) ?? System.Runtime.Loader.AssemblyLoadContext.Default;
        if (!_resolving.Contains(ctx))
        {
            _resolving.Add(ctx);
            var dirs = new List<string> { Path.Combine(PluginsDir, "lib") };
            dirs.AddRange(folders.Select(f => Path.GetDirectoryName(f.dll)!));
            ctx.Resolving += (c, name) =>
            {
                foreach (var d in dirs)
                {
                    string f = Path.Combine(d, name.Name + ".dll");
                    if (File.Exists(f)) return c.LoadFromAssemblyPath(Path.GetFullPath(f));
                }
                return null;
            };
        }
        _gameCtx = ctx;
        foreach (var (name, dll) in folders)
        {
            if (off.Contains(name)) continue;
            LoadFolder(name, dll);
        }
        // DLLs left loose in plugins/ (the old layout): said, not loaded
        try
        {
            foreach (var loose in Directory.Exists(PluginsDir) ? Directory.GetFiles(PluginsDir, "*.dll") : Array.Empty<string>())
                Print("Plugins", $"{Path.GetFileName(loose)} is loose in plugins - move it into plugins/{Path.GetFileNameWithoutExtension(loose)}/ to load it.", new Color(1f, 0.75f, 0.4f));
        }
        catch { }
        string offText = off.Count > 0 ? $" Off: {string.Join(", ", Known.Where(off.Contains))}." : "";
        Print("Plugins", $"{_plugins.Count} plugin{(_plugins.Count == 1 ? "" : "s")} running: {string.Join(", ", _plugins.Select(p => p.Name))}.{offText} /plugins to list them.");
    }

    // ── plugin folders loaded each in a context of its own, so a new copy of a DLL can take over while the game runs ──

    private sealed class Loaded
    {
        public string Name = "", Dll = "";
        public PluginContext? Ctx;
        public readonly List<IPlugin> Plugins = new();
        public DateTime Stamp;
        public long Size;
    }
    private readonly Dictionary<string, Loaded> _loaded = new(StringComparer.OrdinalIgnoreCase);
    private System.Runtime.Loader.AssemblyLoadContext? _gameCtx;
    private double _reloadCheck;
    /// <summary>A plugin's DLL replaced: reloaded by itself (once the new file has stopped changing).</summary>
    public static bool AutoReload = true;

    private bool LoadFolder(string name, string dll, bool again = false)
    {
        var l = new Loaded { Name = name, Dll = dll };
        try
        {
            var fi = new FileInfo(dll); l.Stamp = fi.LastWriteTimeUtc; l.Size = fi.Length;
            string dir = Path.GetDirectoryName(Path.GetFullPath(dll))!;
            // (a reload loads a copy under a name of its own, beside the real one: the runtime keeps a file it has loaded
            // by its path, and while the old copy is still in memory a load from the same path gave back the OLD code.
            // Beside it, so the plugin still finds its own folder. Copies from earlier runs are tidied away first.)
            string from = Path.GetFullPath(dll);
            try { foreach (var old in Directory.GetFiles(dir, ".reload.*.dll")) if (!again) File.Delete(old); } catch { }
            if (again)
            {
                from = Path.Combine(dir, $".reload.{name}.{DateTime.UtcNow.Ticks}.dll");
                File.Copy(dll, from, true);
            }
            l.Ctx = new PluginContext(name, dir, Path.Combine(PluginsDir, "lib"), _gameCtx ?? System.Runtime.Loader.AssemblyLoadContext.Default);
            var asm = l.Ctx.LoadFromAssemblyPath(from);
            foreach (var t in asm.GetTypes().Where(t => typeof(IPlugin).IsAssignableFrom(t) && !t.IsAbstract && t.GetConstructor(System.Type.EmptyTypes) != null))
            {
                var p = (IPlugin)Activator.CreateInstance(t)!;
                int before = _plugins.Count;
                Run(p);
                if (_plugins.Count > before) l.Plugins.Add(p);
            }
            _loaded[name] = l;
            return true;
        }
        catch (Exception ex)
        {
            Print("Plugins", $"Couldn't load {name}: {ex.Message}", new Color(1f, 0.5f, 0.4f));
            try { l.Ctx?.Unload(); } catch { }
            return false;
        }
    }

    /// <summary>Stops a plugin folder's plugins, lets go of everything of theirs the game holds, unloads the old copy and
    /// loads the DLL that's there now. Said in the Plugins chat.</summary>
    public bool Reload(string name)
    {
        string? key = _loaded.Keys.FirstOrDefault(k => k.Equals(name, StringComparison.OrdinalIgnoreCase))
                      ?? _loaded.Keys.FirstOrDefault(k => k.StartsWith(name, StringComparison.OrdinalIgnoreCase));
        if (key == null || !_loaded.TryGetValue(key, out var l)) { Print("Plugins", $"No plugin folder loaded called {name} (loaded: {string.Join(", ", _loaded.Keys)})."); return false; }
        if (!File.Exists(l.Dll)) { Print("Plugins", $"{key}: there's no {Path.GetFileName(l.Dll)} to load just now."); return false; }
        var gone = l.Ctx?.Assemblies.ToHashSet() ?? new HashSet<System.Reflection.Assembly>();
        foreach (var p in l.Plugins)
        {
            try { if (p is IReloadable r) r.StopForReload(); else p.Stop(); }
            catch (Exception ex) { Print("Plugins", $"{p.Name} didn't stop cleanly: {ex.Message}", new Color(1f, 0.75f, 0.4f)); }
            Forget(p);
        }
        bool Gone(Delegate? d) => d != null && (gone.Contains(d.Method.Module.Assembly) || d.Target != null && gone.Contains(d.Target.GetType().Assembly));
        if (MapMenu.RemoveAll(m => Gone(m.Run) || Gone(m.Show)) > 0) { }
        if (BarItems.RemoveAll(b => Gone(b.Run)) > 0) BarChanged?.Invoke();
        int cut = Sweep(gone);
        var weak = new WeakReference(l.Ctx);
        try { l.Ctx?.Unload(); } catch { }
        l.Ctx = null;
        _loaded.Remove(key);
        bool ok = LoadFolder(key, l.Dll, again: true);
        Print("Plugins", ok ? $"{key} reloaded ({l.Plugins.Count} stopped, {cut} leftover hook{(cut == 1 ? "" : "s")} let go)." : $"{key} stopped; the new copy didn't load (see above).");
        // (the old copy is freed once nothing holds it: said if something still does - it then just sits in memory)
        GetTree().CreateTimer(5.0).Timeout += () =>
        {
            for (int i = 0; i < 3; i++) { GC.Collect(); GC.WaitForPendingFinalizers(); }
            if (weak.IsAlive) GD.Print($"[Plugins] the old copy of {key} is still held in memory (something kept a hold of it)");
        };
        return ok;
    }

    /// <summary>Everything the game holds for a plugin: its commands (and their bar buttons), its windows.</summary>
    private void Forget(IPlugin p)
    {
        _plugins.Remove(p);
        foreach (var k in _commands.Where(kv => ReferenceEquals(kv.Value.owner, p)).Select(kv => kv.Key).ToList())
        {
            _commands.Remove(k);
            if (BarItems.RemoveAll(b => b.Label == k.TrimStart('/')) > 0) BarChanged?.Invoke();
        }
        if (_windowsOf.Remove(p, out var wins)) foreach (var w in wins) if (IsInstanceValid(w)) w.QueueFree();
    }

    /// <summary>
    /// Lets go of every hook into a plugin that's being unloaded: any delegate (event handler, callback) of its, in the
    /// game's and the shared libraries' objects - their static fields, this host, and what those hold (a few levels down).
    /// Returns how many were cut.
    /// </summary>
    private int Sweep(HashSet<System.Reflection.Assembly> gone)
    {
        if (gone.Count == 0) return 0;
        int cut = 0;
        var seen = new HashSet<object>(ReferenceEqualityComparer.Instance);
        var ours = new HashSet<System.Reflection.Assembly> { typeof(PluginHost).Assembly };
        foreach (var a in (_gameCtx ?? System.Runtime.Loader.AssemblyLoadContext.Default).Assemblies)
            if (a.Location.StartsWith(Path.Combine(PluginsDir, "lib"), StringComparison.Ordinal)) ours.Add(a);
        bool Gone(Delegate d) => gone.Contains(d.Method.Module.Assembly) || d.Target != null && gone.Contains(d.Target.GetType().Assembly);
        const System.Reflection.BindingFlags Inst = System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic;
        const System.Reflection.BindingFlags Stat = System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.DeclaredOnly;
        object? Clean(object? v, int depth)
        {
            if (v is Delegate d)
            {
                var keep = d.GetInvocationList().Where(x => !Gone(x)).ToArray();
                if (keep.Length == d.GetInvocationList().Length) return v;
                cut += d.GetInvocationList().Length - keep.Length;
                return keep.Length == 0 ? null : Delegate.Combine(keep);
            }
            if (v != null && depth > 0 && !v.GetType().IsValueType && ours.Contains(v.GetType().Assembly) && seen.Add(v)) Walk(v, depth - 1);
            return v;
        }
        void Walk(object o, int depth)
        {
            for (var t = o.GetType(); t != null && ours.Contains(t.Assembly); t = t.BaseType)
                foreach (var f in t.GetFields(Inst | System.Reflection.BindingFlags.DeclaredOnly))
                {
                    if (f.FieldType.IsValueType || f.FieldType == typeof(string)) continue;
                    try { var v = f.GetValue(o); var n = Clean(v, depth); if (!ReferenceEquals(v, n)) f.SetValue(o, n); } catch { }
                }
        }
        seen.Add(this);
        Walk(this, 3);
        foreach (var a in ours)
        {
            System.Type[] types;
            try { types = a.GetTypes(); } catch (System.Reflection.ReflectionTypeLoadException e) { types = e.Types.Where(x => x != null).ToArray()!; }
            foreach (var t in types)
            {
                if (t.ContainsGenericParameters) continue;
                foreach (var f in t.GetFields(Stat))
                {
                    if (f.FieldType.IsValueType || f.FieldType == typeof(string) || f.IsLiteral) continue;
                    try { var v = f.GetValue(null); var n = Clean(v, 3); if (!ReferenceEquals(v, n) && !f.IsInitOnly) f.SetValue(null, n); } catch { }
                }
            }
        }
        return cut;
    }

    /// <summary>Each plugin DLL looked at every couple of seconds: replaced (and settled), its plugin is reloaded.</summary>
    private void WatchDlls(double delta)
    {
        _reloadCheck += delta;
        if (!AutoReload || _reloadCheck < 2.0) return;
        _reloadCheck = 0;
        foreach (var l in _loaded.Values.ToList())
        {
            try
            {
                var fi = new FileInfo(l.Dll);
                if (!fi.Exists || (fi.LastWriteTimeUtc == l.Stamp && fi.Length == l.Size)) continue;
                if ((DateTime.UtcNow - fi.LastWriteTimeUtc).TotalSeconds < 2) continue;   // (still being written)
                Print("Plugins", $"A new {Path.GetFileName(l.Dll)} - reloading {l.Name}.");
                Reload(l.Name);
            }
            catch (Exception ex) { GD.PushWarning("plugin reload: " + ex.Message); }
        }
    }

    private void Run(IPlugin p)
    {
        try { _starting = p; p.Start(this); _plugins.Add(p); }
        catch (Exception ex) { Print("Plugins", $"{p.Name} didn't start: {ex.Message}", new Color(1f, 0.5f, 0.4f)); }
        finally { _starting = null; }
    }

    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("Loaded");
        try { Tick?.Invoke(delta); }
        catch (Exception ex) { GD.PushWarning("plugin tick: " + ex.Message); }
        WatchDlls(delta);
    }

    /// <summary>Says to the launcher that we're leaving on purpose (a logout asked for, the window shut): whatever becomes of the client after, it isn't a crash to start again from.</summary>
    public static void MarkLeaving()
    {
        try
        {
            string? exitFile = System.Environment.GetEnvironmentVariable("ACGODOT_EXIT_FILE");
            if (!string.IsNullOrEmpty(exitFile)) System.IO.File.WriteAllText(exitFile, "{\"closed\": \"" + DateTime.UtcNow.ToString("o") + "\"}");
        }
        catch { }
    }
    /// <summary>Back in the world: a later disappearance is a crash again.</summary>
    public static void MarkStaying()
    {
        try
        {
            string? exitFile = System.Environment.GetEnvironmentVariable("ACGODOT_EXIT_FILE");
            if (!string.IsNullOrEmpty(exitFile) && System.IO.File.Exists(exitFile)) System.IO.File.Delete(exitFile);
        }
        catch { }
    }

    public override void _ExitTree()
    {
        // closed on purpose (the window shut, Exit Game): said to the launcher, which otherwise takes a client that's
        // gone for one that crashed and starts it again. Written before the plugins stop answering it.
        MarkLeaving();
        foreach (var p in _plugins) { try { p.Stop(); } catch { } }
    }

    // ── talking ──

    /// <summary>Text from a plugin, in the Plugins chat window ("[name] text").</summary>
    public void Print(string from, string text, Color? color = null) =>
        SayTo?.Invoke($"[{from}] {text}", color ?? new Color(1f, 0.75f, 0.45f), ChatKind.Plugin);

    /// <summary>Main passes every chat line on.</summary>
    public void OnChatLine(string text, ChatKind kind) { try { ChatLine?.Invoke(text, kind); } catch { } }

    /// <summary>A chat line about to show: each plugin sees it and may hide it (its chat filter) - true: one did.</summary>
    public event Func<string, ChatKind, bool>? ChatIntercept;
    public bool InterceptChat(string text, ChatKind kind)
    {
        bool eat = false;
        foreach (Func<string, ChatKind, bool> f in ChatIntercept?.GetInvocationList() ?? Array.Empty<Delegate>())
        {
            try { eat |= f(text, kind); } catch (Exception ex) { GD.PushWarning("chat filter: " + ex.Message); }
        }
        return eat;
    }

    /// <summary>A plugin's own chat command ("/name args").</summary>
    public void Command(string name, Action<string> run, string help)
    {
        if (!name.StartsWith('/')) name = "/" + name;
        _commands[name] = (_starting ?? _plugins.LastOrDefault()!, run, help);
        // its button on the plugin bar (its command with nothing after it: usually its window)
        string cmd = name;
        if (!BarItems.Any(b => b.Label == name.TrimStart('/'))) AddBarButton(name.TrimStart('/'), help, () => ToggleFromBar(cmd));
    }

    // which plugin made which windows (to shut them from the bar), and who's running a command now
    private readonly Dictionary<IPlugin, List<PluginWindow>> _windowsOf = new();
    private IPlugin? _running;

    /// <summary>A plugin's bar button: shuts its open windows, or (none open) runs its command (which opens one).</summary>
    private void ToggleFromBar(string cmd)
    {
        if (_commands.TryGetValue(cmd, out var c) && c.owner != null && _windowsOf.TryGetValue(c.owner, out var wins))
        {
            var open = wins.Where(w => IsInstanceValid(w) && w.Visible).ToList();
            if (open.Count > 0) { foreach (var w in open) w.Visible = false; return; }
        }
        TryCommand(cmd, "");
    }

    // ── the plugin bar (top left): a button for each plugin ──

    public sealed record BarItem(string Label, string Tip, Action Run, uint Icon);
    public readonly List<BarItem> BarItems = new();
    public event Action? BarChanged;

    /// <summary>Puts a button on the plugin bar (a label, or an icon from the game's pictures, and what it does).</summary>
    public void AddBarButton(string label, string tip, Action run, uint icon = 0)
    {
        BarItems.Add(new BarItem(label, tip, run, icon));
        BarChanged?.Invoke();
    }

    /// <summary>Takes a button off the plugin bar (the one with this tip).</summary>
    public void RemoveBarButton(string tip)
    {
        if (BarItems.RemoveAll(b => b.Tip == tip) > 0) BarChanged?.Invoke();
    }

    /// <summary>Runs a plugin command, if it's one. True if it was.</summary>
    public bool TryCommand(string cmd, string rest)
    {
        if (cmd == "/plugins")
        {
            var w = rest.Trim().Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
            if (w.Length == 2 && (w[0].Equals("on", StringComparison.OrdinalIgnoreCase) || w[0].Equals("off", StringComparison.OrdinalIgnoreCase)))
            {
                bool on = w[0].Equals("on", StringComparison.OrdinalIgnoreCase);
                Print("Plugins", Switch(w[1].Trim(), on) ? $"{w[1].Trim()} switched {(on ? "on" : "off")} - from the next time the game starts."
                                                          : $"No plugin called {w[1].Trim()} (there are: {string.Join(", ", Known)}).");
                return true;
            }
            if (w.Length == 2 && w[0].Equals("reload", StringComparison.OrdinalIgnoreCase)) { Reload(w[1].Trim()); return true; }
            if (w.Length >= 1 && w[0].Equals("autoreload", StringComparison.OrdinalIgnoreCase))
            {
                AutoReload = w.Length < 2 || !w[1].Trim().Equals("off", StringComparison.OrdinalIgnoreCase);
                Print("Plugins", AutoReload ? "A plugin whose DLL is replaced reloads by itself." : "Plugins reload only when asked (/plugins reload <name>).");
                return true;
            }
            var offNow = Disabled();
            Print("Plugins", "Running: " + string.Join(", ", _plugins.Select(p => p.Name)) +
                             (offNow.Count > 0 ? "   Off: " + string.Join(", ", Known.Where(offNow.Contains)) : "") + "   (/plugins on|off <name>, /plugins reload <name>, /plugins autoreload on|off)");
            foreach (var kv in _commands.OrderBy(k => k.Key)) Print("Plugins", $"{kv.Key} - {kv.Value.help}");
            return true;
        }
        if (!_commands.TryGetValue(cmd, out var c)) return false;
        _running = c.owner;
        try { c.run(rest); } catch (Exception ex) { Print(c.owner?.Name ?? "Plugins", "error: " + ex.Message, new Color(1f, 0.5f, 0.4f)); }
        finally { _running = null; }
        return true;
    }

    /// <summary>A window for a plugin (hidden to start).</summary>
    public PluginWindow Window(string title, Vector2 size)
    {
        var w = new PluginWindow(title, size) { Visible = false, Position = new Vector2(240, 140) };
        Ui.AddChild(w);
        if ((_running ?? _starting) is { } owner)
        {
            if (!_windowsOf.TryGetValue(owner, out var list)) _windowsOf[owner] = list = new();
            list.Add(w);
        }
        return w;
    }

    // ── the map's right-click menu ──

    /// <summary>Things plugins put on the world map's right-click menu (shown when Show says so for the spot).</summary>
    public readonly List<Map.MapMenuItem> MapMenu = new();

    /// <summary>Adds an item to the world map's right-click menu: its label, what it does with the spot, and when it's shown (always if null).</summary>
    public void AddMapMenuItem(string label, Action<Map.MapSpot> run, Func<Map.MapSpot, bool>? show = null) => MapMenu.Add(new Map.MapMenuItem(label, run, show));

    // ── what's around ──

    public Vector3 Position => Player.Position;
    public string MapCoords => World.MapCoords(Player.Position);
    /// <summary>Where you are on the map (north and east positive).</summary>
    public (double ns, double ew) Map
    {
        get { var (x, y, _) = World.ToAc(Player.Position); return (y / 240.0 - 101.95, x / 240.0 - 101.95); }
    }
    public bool Playing => Player.Active;
    public Character Me => Combat.Me;
    public Inventory Inv => Combat.Inv;

    /// <summary>Creatures you could fight, alive, nearest first (within a distance).</summary>
    public List<ObjectStreamer.Selectable> Enemies(float within = 60f) =>
        Objects.AllSelectables.Where(s => !s.Gone && (s.Type is 10 or 15) && s.Kind < 3 && Combat.IsEnemy(s) && s.Feet.DistanceTo(Player.Position) <= within)
               .OrderBy(s => s.Feet.DistanceTo(Player.Position)).ToList();

    /// <summary>Corpses with something in them, nearest first.</summary>
    public List<ObjectStreamer.Selectable> Corpses(float within = 30f) =>
        Objects.AllSelectables.Where(s => !s.Gone && Combat.CorpseContents(s) is { Count: > 0 } && s.Feet.DistanceTo(Player.Position) <= within)
               .OrderBy(s => s.Feet.DistanceTo(Player.Position)).ToList();

    public float Distance(ObjectStreamer.Selectable s) => s.Feet.DistanceTo(Player.Position);
    public ObjectStreamer.Selectable? Selected => Objects.Selected;
    public Fighter? FighterOf(ObjectStreamer.Selectable s) => Combat.Of(s);

    // ── doing ──

    public void Select(ObjectStreamer.Selectable? s) => Objects.Select(s);
    /// <summary>Uses something in the world (a door, a corpse, an NPC, a portal...) as R does - running up to it first if it's far.</summary>
    public Action<ObjectStreamer.Selectable>? Use;
    /// <summary>Uses an item of yours (wears / wields it, takes it off, or uses it).</summary>
    public Action<Item>? UseItem;
    /// <summary>A yes-or-no question from the server: true to answer Yes at once, without asking (a plugin expecting it).</summary>
    public Func<string, bool>? ConfirmAutoYes;
    /// <summary>The item picked in a pack or corpse (the game's selection when there is one), and picking one.</summary>
    /// <summary>Has an item identified without choosing it or opening its panel (the phone's inventory page): its details fill in when the server answers.</summary>
    public Action<Item>? QuietIdentify;
    public Func<Item?>? PickedItem;
    /// <summary>Every character on the account, as the server listed them at the character screen (id, name).</summary>
    public Func<IReadOnlyList<(uint id, string name)>>? AccountCharacters;
    public Action<Item?>? PickItem;
    /// <summary>Something identified (an Item, or a Selectable in the world): plugins get its ID as from the server.</summary>
    /// <summary>A spell come onto you (its id, seconds left) or gone, as the server says.</summary>
    public event Action<int, double, bool>? Enchant;
    public void OnEnchant(int spell, double left, bool on) { try { Enchant?.Invoke(spell, left, on); } catch (Exception ex) { GD.PushWarning("enchant: " + ex.Message); } }
    public event Action<object>? Identified;
    /// <summary>Stands for your own character in <see cref="Identified"/> (identifying yourself).</summary>
    public static readonly object Self = new();
    public void OnIdentified(object? o) { if (o == null) return; try { Identified?.Invoke(o); } catch (Exception ex) { GD.PushWarning("identified: " + ex.Message); } }
    /// <summary>True while a plugin's command runs through the game: an unknown one isn't said in chat.</summary>
    public bool QuietUnknown;
    public void Quietly(string text)
    {
        QuietUnknown = true;
        try { Type?.Invoke(text); } finally { QuietUnknown = false; }
    }
    public bool InCombat => Combat.CombatMode;
    /// <summary>Logging out: a plugin's moving, attacking, casting and stance changes are let go.</summary>
    private bool Leaving => Net?.LoggingOut == true;
    public void SetCombat(bool on) { if (Leaving && on) return; if (Combat.CombatMode != on) Combat.ToggleCombat(); }
    /// <summary>Attacks the selected creature at a height (0 high, 1 medium, 2 low).</summary>
    public string Attack(int height = 1) => Leaving ? "logging out" : Combat.AttackKey(height);
    public bool Attacking => Combat.Attacking;
    /// <summary>Runs to a spot (null: stop). Moving with the keys takes over.</summary>
    public void MoveTo(Vector3? spot) => Player.ApproachTo = Leaving ? null : spot;
    /// <summary>Movement keys held for a plugin's nav (Player.PluginKeys bits); auto-run; turning to a heading (degrees clockwise from north).</summary>
    public int NavKeys { get => Player.PluginKeys; set => Player.PluginKeys = Leaving ? 0 : value; }
    public bool AutoRun { get => Player.AutoRun; set => Player.AutoRun = value && !Leaving; }
    public void FaceHeading(double degrees) => Player.TurnToYaw = (float)(-degrees * Math.PI / 180.0);
    /// <summary>How far (0..1) a straight walk that way could go before something stops it; -1 unknown.</summary>
    public double Probe(double bearing, double metres) => Player.Probe(bearing, metres);
    /// <summary>Stops an attack asked for (and the run up to it).</summary>
    public void CancelAttack() => Combat.CancelAttack();
    public bool KnowsSpell(string name) => Magic?.Known().Any(s => s.Name.Equals(name, StringComparison.OrdinalIgnoreCase)) == true;
    public void Cast(string name)
    {
        var s = Magic?.Known().FirstOrDefault(x => x.Name.Equals(name, StringComparison.OrdinalIgnoreCase));
        if (s != null && !Leaving) Magic!.Cast(s.Id);
    }
    /// <summary>Takes everything out of a corpse (if you're close enough). How many items.</summary>
    public int LootAll(ObjectStreamer.Selectable corpse, Func<Item, bool>? want = null)
    {
        if (Distance(corpse) > 5f || Combat.CorpseContents(corpse) is not { } items) return 0;
        int n = 0;
        foreach (var it in items.ToList())
        {
            if (want != null && !want(it)) continue;
            if (it.IsCoins) Inv.Pyreals += it.Stack;
            else if (Inv.Pack.Count < Inventory.PackSize) Inv.Pack.Add(it);
            else continue;
            items.Remove(it);
            n++;
        }
        if (n > 0) { Inv.Changed?.Invoke(); Me.Save(Inv); }
        return n;
    }
}
