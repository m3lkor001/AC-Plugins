using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using ACGodot.Objects;
using Godot;

namespace ACGodot.Plugins;

/// <summary>The plugins ACGodot comes with: versions of the MelkTank and MelksQB Decal plugins for the world on its own.</summary>
public static class BuiltIn
{
    public static IEnumerable<IPlugin> All()
    {
        yield return new XpTrackerPlugin();
        yield return new PhonePlugin();
    }

    internal static string Dir(string name)
    {
        string d = ProjectSettings.GlobalizePath("user://" + name);
        try { Directory.CreateDirectory(d); } catch { }
        return d;
    }

    internal static readonly CultureInfo Inv = CultureInfo.InvariantCulture;
}

// ───────────────────────────── XP tracker ─────────────────────────────

/// <summary>The lum tracker's job for the world on its own: experience and kills, totals and per hour (/xp).</summary>
public sealed class XpTrackerPlugin : IPlugin
{
    /// <summary>A number short from a million up: 20.3 Mil, 20.2 Bil, 1.5 Tril; whole with commas below that.</summary>
    private static string Short(double n)
    {
        double a = Math.Abs(n);
        var ci = System.Globalization.CultureInfo.InvariantCulture;
        if (a >= 1e15) return (n / 1e15).ToString("0.#", ci) + " Quad";
        if (a >= 1e12) return (n / 1e12).ToString("0.#", ci) + " Tril";
        if (a >= 1e9) return (n / 1e9).ToString("0.#", ci) + " Bil";
        if (a >= 1e6) return (n / 1e6).ToString("0.#", ci) + " Mil";
        return n.ToString("N0");
    }
    public string Name => "XP Tracker";
    private PluginHost _h = null!;
    private double _run;
    private long _xp, _xpAt = -1;
    private int _kills;
    private string _last = "";
    private PluginWindow? _win;
    private double _refresh;

    public void Start(PluginHost host)
    {
        _h = host;
        host.Killed += (name, _, xp, _) => { _xp += xp; _kills++; _last = name; };
        // on a server: a kill is the server saying so, and the experience is what the character's total has grown by
        host.ServerKilled += text => { _kills++; _last = text; };
        host.Tick += dt =>
        {
            if (!host.OnServer) { _xpAt = -1; return; }
            long total = host.Me.TotalXp;
            if (_xpAt >= 0 && total > _xpAt) _xp += total - _xpAt;
            _xpAt = total;
        };
        host.Tick += dt => { _run += dt; if (_win != null && _win.Visible && (_refresh -= dt) <= 0) { _refresh = 1; Refresh(); } };
        host.Command("xp", r =>
        {
            if (r.Trim() == "reset") { _run = 0; _xp = 0; _kills = 0; _last = ""; _h.Print(Name, "reset"); return; }
            Show(_win == null || !_win.Visible);
            _h.Print(Name, Summary());
        }, "experience and kills per hour: /xp | /xp reset");
        // open again if it was open when the game last closed
        var cfg = new ConfigFile();
        if (global::ACGodot.SafeConfig.Load(cfg, SavePath) == Error.Ok && (bool)cfg.GetValue("xp", "open", false)) Show(true);
    }

    private const string SavePath = "user://xptracker.cfg";

    private void Show(bool on)
    {
        if (_win == null)
        {
            _win = _h.Window("XP Tracker", new Vector2(240, 170));
            _win.Closed += () => Remember(false);
        }
        _win.Visible = on;
        Remember(on);
        Refresh();
    }

    private static void Remember(bool open)
    {
        var cfg = new ConfigFile();
        global::ACGodot.SafeConfig.Load(cfg, SavePath);
        cfg.SetValue("xp", "open", open);
        global::ACGodot.SafeConfig.Save(cfg, SavePath);
    }
    public void Stop() { }

    private string Summary()
    {
        double hrs = Math.Max(_run / 3600.0, 1e-6);
        return $"{Short(_xp)} XP ({Short(_xp / hrs)}/hr), {_kills} kills ({_kills / hrs:0}/hr) in {TimeSpan.FromSeconds(_run):h\\:mm\\:ss}";
    }

    private void Refresh()
    {
        if (_win == null || !_win.Visible) return;
        _win.ClearContent();
        double hrs = Math.Max(_run / 3600.0, 1e-6);
        _win.Content.AddChild(PluginWindow.Text($"Run time: {TimeSpan.FromSeconds(_run):h\\:mm\\:ss}"));
        _win.Content.AddChild(PluginWindow.Text($"Experience: {Short(_xp)}   ({Short(_xp / hrs)}/hr)"));
        _win.Content.AddChild(PluginWindow.Text($"Kills: {_kills}   ({_kills / hrs:0}/hr)"));
        _win.Content.AddChild(PluginWindow.Text($"Level {_h.Me.Level}, {Short(_h.Me.UnassignedXp)} unassigned"));
        if (_last.Length > 0) _win.Content.AddChild(PluginWindow.Text($"Last kill: {_last}", 12, UI.RetailTheme.Dim));
        _win.Content.AddChild(PluginWindow.Small("Reset", () => { _run = 0; _xp = 0; _kills = 0; _last = ""; Refresh(); }));
    }
}


