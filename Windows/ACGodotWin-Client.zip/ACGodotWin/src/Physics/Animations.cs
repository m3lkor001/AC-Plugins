using System.Collections.Generic;
using AcDream.Core.Physics;
using DatReaderWriter.Types;

namespace ACGodot.Physics;

public static class Animations
{
    /// <summary>
    /// Tells a motion sequencer which of its animations finished this frame (the "animation done" marks among the
    /// hooks it fired), as the client does each frame. Without it the motion table's queue of motions under way never
    /// emptied: a stance change while standing snapped straight to the end, and actions (attacks) piled up.
    /// </summary>
    public static void Finish(AnimationSequencer seq, IReadOnlyList<AnimationHook> hooks)
    {
        foreach (var h in hooks)
            if (h is AnimationDoneHook) seq.Manager.AnimationDone(success: true);
        seq.Manager.UseTime();
    }
}
