using System;
using System.Numerics;
using AcDream.Core.Physics;

namespace ACGodot.Physics;

/// <summary>
/// Getting round corners and into doorways. The collision treats a sphere touching a polygon's edge as touching its
/// face, so at a convex edge - a door jamb, a building's corner - it reports the two faces in turn and every move into
/// the edge is refused, though the character only has to edge a few centimetres sideways to pass. When a move is
/// refused at such an edge, this tries the same move turned a little to either side (up to 60 degrees) and takes the
/// one that gets furthest the way they want to go.
/// </summary>
public static class CornerSlip
{
    private static readonly float[] Turns = { 20f, -20f, 40f, -40f, 60f, -60f };

    /// <param name="sweep">Sweeps the body from where it is to a point (it doesn't move the body).</param>
    /// <param name="pre">Where the body is.</param>
    /// <param name="move">The horizontal move they want this step.</param>
    /// <returns>Where to sweep to instead (sweep there again to move), or null if no turn does better than <paramref name="got"/> metres of progress.</returns>
    public static Vector3? Try(Func<Vector3, ResolveResult> sweep, Vector3 pre, Vector3 move, float got)
    {
        float len = new Vector2(move.X, move.Y).Length();
        if (len < 1e-4f) return null;
        var dir = new Vector2(move.X, move.Y) / len;
        Vector3? best = null;
        float bestGain = Math.Max(got, len * 0.25f);   // worth taking only if it really gets them on
        foreach (float deg in Turns)
        {
            float a = deg * MathF.PI / 180f, c = MathF.Cos(a), s = MathF.Sin(a);
            var d = new Vector2(dir.X * c - dir.Y * s, dir.X * s + dir.Y * c);
            var target = pre + new Vector3(d.X, d.Y, 0f) * len;
            var r = sweep(target);
            if (!r.Ok) continue;
            var disp = r.Position - pre;
            float gain = Vector2.Dot(new Vector2(disp.X, disp.Y), dir);
            if (gain > bestGain) { best = target; bestGain = gain; }
            if (gain > len * 0.6f) break;                  // good enough: the smallest turn that works
        }
        return best;
    }
}
