using System;
using System.Collections.Concurrent;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.IO.Compression;
using DatReaderWriter.Lib.IO;

namespace ACGodot.Physics;

/// <summary>
/// The game data as the collision reads it, keeping a copy of every object read, so the objects a piece of the world's
/// collision is made from can be saved to one small file (P) and the same collision rebuilt from it elsewhere - to
/// work out a collision problem without the whole game data at hand.
/// </summary>
public sealed class RecordingDats : AcDream.Core.Content.IDatObjectSource
{
    private readonly Dats _dats;
    private readonly ConcurrentDictionary<(int file, uint id), byte[]> _seen = new();

    public RecordingDats(Dats dats) => _dats = dats;

    [return: MaybeNull]
    public T Get<T>(uint fileId) where T : IDBObj => TryGet<T>(fileId, out var v) ? v : default!;

    public bool TryGet<T>(uint fileId, [MaybeNullWhen(false)] out T value) where T : IDBObj
    {
        if (!_dats.TryGet(fileId, out value)) return false;
        if (_dats.TryRaw<T>(fileId, out byte[] bytes, out int file)) _seen.TryAdd((file, fileId), bytes);
        return true;
    }

    public int Count => _seen.Count;

    /// <summary>Writes every object read so far: gzip of (file byte, id uint, length int, bytes)...</summary>
    public void Save(string path)
    {
        using var fs = File.Create(path);
        using var gz = new GZipStream(fs, CompressionLevel.Optimal);
        using var w = new BinaryWriter(gz);
        foreach (var kv in _seen)
        {
            w.Write((byte)kv.Key.file);
            w.Write(kv.Key.id);
            w.Write(kv.Value.Length);
            w.Write(kv.Value);
        }
    }
}
