using System;
using System.Numerics;
using DatReaderWriter.DBObjs;

namespace ACGodot.Physics;

/// <summary>Where to stand in a dungeon room: the middle of its biggest floor (a room's own origin can lie outside it).</summary>
public static class CellSpawn
{
    /// <summary>The point (landblock-local AC coordinates, on the floor), or the room's origin if it has no floor.</summary>
    public static Vector3 FloorPoint(Func<uint, DatReaderWriter.DBObjs.Environment?> envOf, EnvCell cell)
    {
        var at = cell.Position;
        var o = new Vector3(at.Origin.X, at.Origin.Y, at.Origin.Z);
        var q = new Quaternion(at.Orientation.X, at.Orientation.Y, at.Orientation.Z, at.Orientation.W);
        var env = envOf(0x0D000000u | cell.EnvironmentId);
        if (env == null || !env.Cells.TryGetValue(cell.CellStructure, out var cs)) return o;
        float bestArea = 0f; Vector3 best = o;
        var pts = new System.Collections.Generic.List<Vector3>();
        foreach (var poly in cs.Polygons.Values)
        {
            pts.Clear();
            foreach (var vid in poly.VertexIds)
                if (cs.VertexArray.Vertices.TryGetValue((ushort)vid, out var v))
                    pts.Add(Vector3.Transform(new Vector3(v.Origin.X, v.Origin.Y, v.Origin.Z), q) + o);
            if (pts.Count < 3) continue;
            Vector3 n = Vector3.Zero, c = Vector3.Zero;
            for (int i = 0; i < pts.Count; i++) { n += Vector3.Cross(pts[i], pts[(i + 1) % pts.Count]); c += pts[i]; }
            float area = n.Length() / 2f;
            if (area < 1e-4f || MathF.Abs(n.Z) / (2f * area) < 0.9f) continue;   // floors (and ceilings) only
            c /= pts.Count;
            // the floor: the lowest flat polygon; among the lowest, the biggest
            if (bestArea == 0f || c.Z < best.Z - 0.5f || (MathF.Abs(c.Z - best.Z) <= 0.5f && area > bestArea)) { bestArea = area; best = c; }
        }
        return best;
    }
}
