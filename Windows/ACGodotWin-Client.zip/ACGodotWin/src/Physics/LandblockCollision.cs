using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Collections.Immutable;
using System.Numerics;
using AcDream.Core.Meshing;
using AcDream.Core.Physics;
using AcDream.Core.World;
using DatReaderWriter.DBObjs;
using DatReaderWriter.Types;
using DatEnvironment = DatReaderWriter.DBObjs.Environment;

namespace ACGodot.Physics;

/// <summary>
/// One landblock's collision built straight from the game data: a port of OpenAC's
/// LandblockPhysicsContentBuilder (MIT), with the shapes flattened from the dats here instead of
/// read from OpenAC's prepared asset package.
/// </summary>
public static class LandblockCollision
{
    public readonly record struct StaticCollisionPublication(
        int BspOwnerCount,
        int SetupOwnerCount,
        int NoCollisionCount);

    /// <summary>
    /// One landblock's collision content as a host with no renderer loads it: its static
    /// objects, procedural scenery and the objects inside its cells, the game data they need,
    /// and their prepared collision.
    /// False when the game data has no such landblock.
    /// </summary>
    public static bool TryLoadCollisionLandblock(
        AcDream.Core.Content.IDatObjectSource dats,
        ReadOnlySpan<float> heightTable,
        uint landblockId,
        Vector3 origin,
        out LoadedLandblock landblock,
        out LandblockCollisionBuild collisions,
        Func<LandBlock, IReadOnlyList<WorldEntity>>? extra = null)
    {
        ArgumentNullException.ThrowIfNull(dats);
        landblock = null!;
        collisions = null!;
        if (LandblockLoader.Load(dats, landblockId) is not { } source)
        {
            // no landscape record (the FF row and column, off the map) but rooms of its own - the apartment halls: a flat
            // nothing for the landscape, and its rooms and what stands in them as usual
            if (dats.Get<LandBlockInfo>((landblockId & 0xFFFF0000u) | 0xFFFEu) is not { } info) return false;
            source = new LoadedLandblock(landblockId, new LandBlock(), LandblockLoader.BuildEntitiesFromInfo(info, landblockId));
        }

        IReadOnlyList<WorldEntity> staticEntities =
            HydrateStaticEntities(dats, source, origin, includeVisualBounds: false);
        IReadOnlyList<WorldEntity> scenery =
            HydrateProceduralScenery(dats, source, origin, heightTable, includeVisualBounds: false);
        IReadOnlyList<WorldEntity> interior =
            HydrateInteriorEntities(dats, landblockId, origin, includeVisualBounds: false);
        var entities = new List<WorldEntity>(staticEntities.Count + scenery.Count + interior.Count);
        entities.AddRange(staticEntities);
        entities.AddRange(scenery);
        entities.AddRange(interior);
        // and what else stands there (ACGodot: the doors, creatures and NPCs from ACE's world database)
        if (extra != null) entities.AddRange(extra(source.Heightmap));
        landblock = new LoadedLandblock(
            source.LandblockId,
            source.Heightmap,
            entities,
            BuildDatBundle(dats, landblockId, entities));
        collisions = BuildCollisionClosure(dats, landblock);
        return true;
    }

    public static IReadOnlyList<WorldEntity> HydrateStaticEntities(
        AcDream.Core.Content.IDatObjectSource dats,
        LoadedLandblock source,
        Vector3 worldOffset,
        bool includeVisualBounds = true)
    {
        ArgumentNullException.ThrowIfNull(dats);
        ArgumentNullException.ThrowIfNull(source);

        var hydrated = new List<WorldEntity>(source.Entities.Count);
        foreach (WorldEntity candidate in source.Entities)
        {
            var meshRefs = new List<MeshRef>();
            var bounds = new LocalBoundsAccumulator();
            uint sourceId = candidate.SourceGfxObjOrSetupId;
            if ((sourceId & 0xFF000000u) == 0x01000000u)
            {
                GfxObj? gfx = dats.Get<GfxObj>(sourceId);
                if (gfx is not null)
                {
                    if (includeVisualBounds
                        && GfxObjBounds.Get(gfx) is { } partBounds)
                    {
                        bounds.Add(
                            Matrix4x4.Identity,
                            partBounds);
                    }
                    meshRefs.Add(new MeshRef(
                        sourceId,
                        Matrix4x4.Identity));
                }
            }
            else if ((sourceId & 0xFF000000u) == 0x02000000u)
            {
                Setup? setup = dats.Get<Setup>(sourceId);
                if (setup is not null)
                {
                    foreach (MeshRef meshRef in SetupMesh.Flatten(setup))
                    {
                        GfxObj? gfx =
                            dats.Get<GfxObj>(meshRef.GfxObjId);
                        if (gfx is null)
                            continue;
                        if (includeVisualBounds
                            && GfxObjBounds.Get(gfx) is { } partBounds)
                        {
                            bounds.Add(
                                meshRef.PartTransform,
                                partBounds);
                        }
                        meshRefs.Add(meshRef);
                    }
                }
            }

            if (meshRefs.Count == 0)
                continue;

            var entity = new WorldEntity
            {
                Id = candidate.Id,
                SourceGfxObjOrSetupId = sourceId,
                Position = candidate.Position + worldOffset,
                Rotation = candidate.Rotation,
                MeshRefs = meshRefs,
                EffectCellId = candidate.EffectCellId,
                IsBuildingShell = candidate.IsBuildingShell,
                BuildingShellAnchorCellId =
                    candidate.BuildingShellAnchorCellId,
            };
            if (bounds.TryGet(out Vector3 min, out Vector3 max))
                entity.SetLocalBounds(min, max);
            hydrated.Add(entity);
        }
        return hydrated;
    }

    /// <summary>
    /// The objects placed inside a landblock's cells, such as a dungeon's furniture and the
    /// marker parts that carry collision: each with the parts it draws or collides with, in
    /// cell order, with ids from <see cref="InteriorEntityIdAllocator"/>.
    /// </summary>
    public static IReadOnlyList<WorldEntity> HydrateInteriorEntities(
        AcDream.Core.Content.IDatObjectSource dats,
        uint landblockId,
        Vector3 worldOffset,
        bool includeVisualBounds = true)
    {
        ArgumentNullException.ThrowIfNull(dats);

        var result = new List<WorldEntity>();
        LandBlockInfo? info = dats.Get<LandBlockInfo>((landblockId & 0xFFFF0000u) | 0xFFFEu);
        if (info is null || info.NumCells == 0)
            return result;

        uint landblockX = (landblockId >> 24) & 0xFFu;
        uint landblockY = (landblockId >> 16) & 0xFFu;
        uint localCounter = 0;
        uint firstCellId = (landblockId & 0xFFFF0000u) | 0x0100u;
        for (uint offset = 0; offset < info.NumCells; offset++)
        {
            uint envCellId = firstCellId + offset;
            if (dats.Get<EnvCell>(envCellId) is not { } envCell)
                continue;

            foreach (Stab stab in envCell.StaticObjects)
            {
                if ((stab.Id & 0xFF000000u) == 0x01000000u
                    && !KeepsInteriorPart(dats, stab.Id))
                {
                    continue;
                }

                var meshRefs = new List<MeshRef>();
                var bounds = new LocalBoundsAccumulator();
                int lightCount = 0;
                bool hasDefaultScript = false;
                if ((stab.Id & 0xFF000000u) == 0x01000000u)
                {
                    if (dats.Get<GfxObj>(stab.Id) is { } gfx)
                    {
                        if (includeVisualBounds && GfxObjBounds.Get(gfx) is { } partBounds)
                            bounds.Add(Matrix4x4.Identity, partBounds);
                        meshRefs.Add(new MeshRef(stab.Id, Matrix4x4.Identity));
                    }
                }
                else if ((stab.Id & 0xFF000000u) == 0x02000000u)
                {
                    if (dats.Get<Setup>(stab.Id) is { } setup)
                    {
                        lightCount = setup.Lights.Count;
                        hasDefaultScript = setup.DefaultScript.DataId != 0
                            || (uint)setup.DefaultScriptTable != 0;
                        foreach (MeshRef meshRef in SetupMesh.Flatten(setup))
                        {
                            if (!KeepsInteriorPart(dats, meshRef.GfxObjId))
                                continue;
                            if (dats.Get<GfxObj>(meshRef.GfxObjId) is not { } gfx)
                                continue;
                            if (includeVisualBounds && GfxObjBounds.Get(gfx) is { } partBounds)
                                bounds.Add(meshRef.PartTransform, partBounds);
                            meshRefs.Add(meshRef);
                        }
                    }
                }

                if (!EntityHydrationRules.ShouldKeepEntity(meshRefs.Count, lightCount, hasDefaultScript))
                    continue;

                var entity = new WorldEntity
                {
                    Id = InteriorEntityIdAllocator.Allocate(landblockX, landblockY, ref localCounter),
                    SourceGfxObjOrSetupId = stab.Id,
                    Position = stab.Frame.Origin + worldOffset,
                    Rotation = stab.Frame.Orientation,
                    MeshRefs = meshRefs,
                    ParentCellId = envCellId,
                };
                if (bounds.TryGet(out Vector3 min, out Vector3 max))
                    entity.SetLocalBounds(min, max);
                result.Add(entity);
            }
        }
        return result;
    }

    /// <summary>Whether an interior part is kept: never an editor marker, unless it carries collision.</summary>
    private static bool KeepsInteriorPart(AcDream.Core.Content.IDatObjectSource dats, uint gfxObjId) =>
        EntityHydrationRules.ShouldKeepPart(
            GfxObjDegradeResolver.IsRuntimeHiddenMarker(dats, gfxObjId),
            dats.Get<GfxObj>(gfxObjId) is { } gfx
                && gfx.Flags.HasFlag(DatReaderWriter.Enums.GfxObjFlags.HasPhysics)
                && gfx.PhysicsBSP?.Root is not null
                && gfx.VertexArray is not null);

    public static IReadOnlyList<WorldEntity> HydrateProceduralScenery(
        AcDream.Core.Content.IDatObjectSource dats,
        LoadedLandblock source,
        Vector3 worldOffset,
        ReadOnlySpan<float> heightTable,
        bool includeVisualBounds = true)
    {
        ArgumentNullException.ThrowIfNull(dats);
        ArgumentNullException.ThrowIfNull(source);
        if (heightTable.Length < 256)
        {
            throw new ArgumentException(
                "The terrain height table must contain at least 256 entries.",
                nameof(heightTable));
        }

        Region? region = dats.Get<Region>(0x13000000u);
        if (region is null)
            return [];

        HashSet<int>? buildingCells = null;
        LandBlockInfo? info = dats.Get<LandBlockInfo>(
            (source.LandblockId & 0xFFFF0000u) | 0xFFFEu);
        if (info is not null)
        {
            buildingCells = [];
            foreach (BuildingInfo building in info.Buildings)
            {
                int cellX = Math.Clamp(
                    (int)(building.Frame.Origin.X / 24f),
                    0,
                    8);
                int cellY = Math.Clamp(
                    (int)(building.Frame.Origin.Y / 24f),
                    0,
                    8);
                buildingCells.Add(cellX * 9 + cellY);
            }
        }

        IReadOnlyList<SceneryGenerator.ScenerySpawn> spawns =
            SceneryGenerator.Generate(
                dats,
                region,
                source.Heightmap,
                source.LandblockId,
                buildingCells);
        if (spawns.Count == 0)
            return [];

        var entities = new List<WorldEntity>(spawns.Count);
        uint landblockX =
            (source.LandblockId >> 24) & 0xFFu;
        uint landblockY =
            (source.LandblockId >> 16) & 0xFFu;
        uint sceneryCounter = 0u;
        foreach (SceneryGenerator.ScenerySpawn spawn in spawns)
        {
            var meshRefs = new List<MeshRef>();
            var bounds = new LocalBoundsAccumulator();
            Matrix4x4 scale =
                Matrix4x4.CreateScale(spawn.Scale);
            if ((spawn.ObjectId & 0xFF000000u) == 0x01000000u)
            {
                GfxObj? gfx = dats.Get<GfxObj>(spawn.ObjectId);
                if (gfx is not null)
                {
                    if (includeVisualBounds
                        && GfxObjBounds.Get(gfx) is { } partBounds)
                    {
                        bounds.Add(scale, partBounds);
                    }
                    meshRefs.Add(new MeshRef(spawn.ObjectId, scale));
                }
            }
            else if ((spawn.ObjectId & 0xFF000000u) == 0x02000000u)
            {
                Setup? setup = dats.Get<Setup>(spawn.ObjectId);
                if (setup is not null)
                {
                    foreach (MeshRef meshRef in SetupMesh.Flatten(setup))
                    {
                        GfxObj? gfx =
                            dats.Get<GfxObj>(meshRef.GfxObjId);
                        if (gfx is null)
                            continue;
                        Matrix4x4 partTransform =
                            meshRef.PartTransform * scale;
                        if (includeVisualBounds
                            && GfxObjBounds.Get(gfx) is { } partBounds)
                        {
                            bounds.Add(partTransform, partBounds);
                        }
                        meshRefs.Add(new MeshRef(
                            meshRef.GfxObjId,
                            partTransform));
                    }
                }
            }
            if (meshRefs.Count == 0)
                continue;

            float localX = spawn.LocalPosition.X;
            float localY = spawn.LocalPosition.Y;
            float groundZ = TerrainSurface.SampleZFromHeightmap(
                source.Heightmap.Height,
                heightTable,
                landblockX,
                landblockY,
                localX,
                localY);
            var entity = new WorldEntity
            {
                Id = ProceduralSceneryIdAllocator.Allocate(
                    landblockX,
                    landblockY,
                    ref sceneryCounter),
                SourceGfxObjOrSetupId = spawn.ObjectId,
                Position = new Vector3(
                    localX,
                    localY,
                    groundZ + spawn.LocalPosition.Z)
                    + worldOffset,
                Rotation = spawn.Rotation,
                MeshRefs = meshRefs,
                Scale = spawn.Scale,
                EffectCellId =
                    TerrainSurface.ComputeOutdoorCellId(
                        source.LandblockId,
                        localX,
                        localY),
            };
            if (bounds.TryGet(out Vector3 min, out Vector3 max))
                entity.SetLocalBounds(min, max);
            entities.Add(entity);
        }
        return entities;
    }

    /// <summary>
    /// What drawing a landblock reads from its game data beside the meshes:
    /// the landblock's building list and the setups its buildings and objects
    /// are made from (their lights). The cells, environments and part shapes
    /// collision needs are not read; collision is built by
    /// <see cref="TryLoadCollisionLandblock"/>.
    /// </summary>
    public static PhysicsDatBundle BuildPresentationDatBundle(
        AcDream.Core.Content.IDatObjectSource dats,
        uint landblockId,
        IReadOnlyList<WorldEntity> entities)
    {
        ArgumentNullException.ThrowIfNull(dats);
        ArgumentNullException.ThrowIfNull(entities);

        var setups = new Dictionary<uint, Setup>();
        LandBlockInfo? info = dats.Get<LandBlockInfo>(
            (landblockId & 0xFFFF0000u) | 0xFFFEu);
        if (info is not null)
        {
            foreach (var building in info.Buildings)
                AddSetup(dats, setups, building.ModelId);
        }
        foreach (WorldEntity entity in entities)
            AddSetup(dats, setups, entity.SourceGfxObjOrSetupId);

        return new PhysicsDatBundle(
            info,
            PhysicsDatBundle.Empty.EnvCells,
            PhysicsDatBundle.Empty.Environments,
            setups,
            PhysicsDatBundle.Empty.GfxObjs);

        static void AddSetup(
            AcDream.Core.Content.IDatObjectSource dats,
            Dictionary<uint, Setup> setups,
            uint setupId)
        {
            if ((setupId & 0xFF000000u) == 0x02000000u
                && !setups.ContainsKey(setupId)
                && dats.Get<Setup>(setupId) is { } setup)
            {
                setups[setupId] = setup;
            }
        }
    }

    public static PhysicsDatBundle BuildDatBundle(
        AcDream.Core.Content.IDatObjectSource dats,
        uint landblockId,
        IReadOnlyList<WorldEntity> entities)
    {
        ArgumentNullException.ThrowIfNull(dats);
        ArgumentNullException.ThrowIfNull(entities);

        var envCells = new Dictionary<uint, EnvCell>();
        var environments = new Dictionary<uint, DatEnvironment>();
        var setups = new Dictionary<uint, Setup>();
        var gfxObjs = new Dictionary<uint, GfxObj>();
        LandBlockInfo? info = dats.Get<LandBlockInfo>(
            (landblockId & 0xFFFF0000u) | 0xFFFEu);

        if (info is not null)
        {
            uint firstCellId =
                (landblockId & 0xFFFF0000u) | 0x0100u;
            for (uint offset = 0; offset < info.NumCells; offset++)
            {
                uint envCellId = firstCellId + offset;
                EnvCell? envCell = dats.Get<EnvCell>(envCellId);
                if (envCell is null)
                    continue;
                envCells[envCellId] = envCell;
                if (envCell.EnvironmentId == 0)
                    continue;
                uint environmentId =
                    0x0D000000u | envCell.EnvironmentId;
                if (!environments.ContainsKey(environmentId)
                    && dats.Get<DatEnvironment>(
                        environmentId) is { } environment)
                {
                    environments[environmentId] = environment;
                }
            }

            foreach (var building in info.Buildings)
            {
                uint setupId = building.ModelId;
                if ((setupId & 0xFF000000u) == 0x02000000u
                    && !setups.ContainsKey(setupId)
                    && dats.Get<Setup>(setupId) is { } setup)
                {
                    setups[setupId] = setup;
                }
            }
        }

        foreach (WorldEntity entity in entities)
        {
            uint sourceId = entity.SourceGfxObjOrSetupId;
            if ((sourceId & 0xFF000000u) == 0x02000000u
                && !setups.ContainsKey(sourceId)
                && dats.Get<Setup>(sourceId) is { } setup)
            {
                setups[sourceId] = setup;
            }

            foreach (MeshRef meshRef in entity.MeshRefs)
            {
                uint gfxObjId = meshRef.GfxObjId;
                if ((gfxObjId & 0xFF000000u) != 0x01000000u
                    || gfxObjs.ContainsKey(gfxObjId))
                {
                    continue;
                }
                if (dats.Get<GfxObj>(gfxObjId) is { } gfxObj)
                    gfxObjs[gfxObjId] = gfxObj;
            }
        }

        return new PhysicsDatBundle(
            info,
            envCells,
            environments,
            setups,
            gfxObjs);
    }

    /// <summary>The collision shapes of everything the landblock's collision uses, flattened from the dats.</summary>
    public static LandblockCollisionBuild BuildCollisionClosure(
        AcDream.Core.Content.IDatObjectSource dats,
        LoadedLandblock landblock)
    {
        PhysicsDatBundle bundle = landblock.PhysicsDats ?? PhysicsDatBundle.Empty;
        ImmutableArray<uint> gfxObjIds = [.. bundle.GfxObjs.Keys.Order()];
        ImmutableArray<uint> setupIds = [.. bundle.Setups.Keys.Order()];
        var gfxObjs = ImmutableDictionary.CreateBuilder<uint, FlatGfxObjCollisionAsset>();
        var setups = ImmutableDictionary.CreateBuilder<uint, FlatSetupCollision>();
        var cellStructures = ImmutableDictionary.CreateBuilder<uint, FlatCellStructureCollisionAsset>();
        var envCells = ImmutableDictionary.CreateBuilder<uint, FlatEnvCellTopology>();
        var cellIds = new List<uint>();

        foreach (uint id in gfxObjIds)
        {
            try { gfxObjs.Add(id, FlatCollisionAssetBuilder.FlattenGfxObj(bundle.GfxObjs[id])); }
            catch (Exception) { }
        }
        foreach (uint id in setupIds)
        {
            try { setups.Add(id, FlatCollisionAssetBuilder.FlattenSetup(bundle.Setups[id])); }
            catch (Exception) { }
        }
        foreach ((uint id, EnvCell envCell) in bundle.EnvCells.OrderBy(kv => kv.Key))
        {
            try
            {
                uint environmentId = 0x0D000000u | envCell.EnvironmentId;
                if (!bundle.Environments.TryGetValue(environmentId, out DatEnvironment? environment)
                    || !environment.Cells.TryGetValue(envCell.CellStructure, out CellStruct? structure))
                    continue;
                FlatCellStructureCollisionAsset flat = FlatCollisionAssetBuilder.FlattenCellStructure(structure);
                FlatEnvCellTopology topology = FlatCollisionAssetBuilder.FlattenEnvCellTopology(id, envCell, flat.PortalPolygons);
                cellStructures.Add(id, flat);
                envCells.Add(id, topology);
                cellIds.Add(id);
            }
            catch (Exception) { }
        }

        return new LandblockCollisionBuild(
            gfxObjs.ToImmutable(),
            setups.ToImmutable(),
            cellStructures.ToImmutable(),
            envCells.ToImmutable(),
            [.. gfxObjs.Keys.Order()],
            [.. setups.Keys.Order()],
            [.. cellIds]);
    }

    public static TerrainSurface BuildTerrainSurface(
        LoadedLandblock landblock,
        ReadOnlySpan<float> heightTable)
    {
        ArgumentNullException.ThrowIfNull(landblock);
        if (heightTable.Length < 256)
        {
            throw new ArgumentException(
                "The terrain height table must contain at least 256 entries.",
                nameof(heightTable));
        }

        uint landblockX = (landblock.LandblockId >> 24) & 0xFFu;
        uint landblockY = (landblock.LandblockId >> 16) & 0xFFu;
        var terrainBytes = new byte[81];
        for (int index = 0; index < terrainBytes.Length; index++)
        {
            terrainBytes[index] =
                (byte)(ushort)landblock.Heightmap.Terrain[index];
        }
        return new TerrainSurface(
            landblock.Heightmap.Height,
            heightTable,
            landblockX,
            landblockY,
            terrainBytes);
    }

    public static void PublishPreparedCells(
        PhysicsDataCache cache,
        LoadedLandblock landblock,
        LandblockCollisionBuild collisions,
        Vector3 origin,
        ICollection<CellSurface> cellSurfaces,
        ICollection<PortalPlane> portalPlanes)
    {
        uint count = CellCount(landblock);
        for (uint offset = 0; offset < count; offset++)
        {
            PublishPreparedCell(
                cache,
                landblock,
                collisions,
                origin,
                offset,
                cellSurfaces,
                portalPlanes);
        }
    }

    /// <summary>How many interior cells the landblock's game data lists.</summary>
    public static uint CellCount(LoadedLandblock landblock)
    {
        ArgumentNullException.ThrowIfNull(landblock);
        return landblock.PhysicsDats?.Info?.NumCells ?? 0u;
    }

    /// <summary>
    /// One interior cell, the <paramref name="offset"/>th the landblock lists:
    /// its structure into the cache, its portals and floor into the lists the
    /// landblock's collision is made from. A cell with no prepared collision
    /// adds nothing.
    /// </summary>
    public static void PublishPreparedCell(
        PhysicsDataCache cache,
        LoadedLandblock landblock,
        LandblockCollisionBuild collisions,
        Vector3 origin,
        uint offset,
        ICollection<CellSurface> cellSurfaces,
        ICollection<PortalPlane> portalPlanes)
    {
        ArgumentNullException.ThrowIfNull(cache);
        ArgumentNullException.ThrowIfNull(landblock);
        ArgumentNullException.ThrowIfNull(collisions);
        ArgumentNullException.ThrowIfNull(cellSurfaces);
        ArgumentNullException.ThrowIfNull(portalPlanes);

        PhysicsDatBundle dats =
            landblock.PhysicsDats ?? PhysicsDatBundle.Empty;
        uint envCellId =
            (landblock.LandblockId & 0xFFFF0000u)
            | (0x0100u + offset);
        if (!dats.EnvCells.TryGetValue(
                envCellId,
                out EnvCell? envCell)
            || !collisions.CellStructures.TryGetValue(
                envCellId,
                out FlatCellStructureCollisionAsset? structure)
            || !collisions.EnvCells.TryGetValue(
                envCellId,
                out FlatEnvCellTopology? topology))
        {
            return;
        }

        Quaternion rotation = envCell.Position.Orientation;
        Vector3 cellOriginWorld =
            envCell.Position.Origin + origin;
        Matrix4x4 transform =
            Matrix4x4.CreateFromQuaternion(rotation)
            * Matrix4x4.CreateTranslation(cellOriginWorld);
        cache.CacheCellStruct(
            envCellId,
            envCell,
            transform,
            structure,
            topology);

        FlatPolygonTable portalPolygons =
            structure.PortalPolygons;
        for (int portalIndex = 0;
            portalIndex < topology.Portals.Length;
            portalIndex++)
        {
            FlatEnvCellPortal portal =
                topology.Portals[portalIndex];
            if ((uint)portal.PolygonIndex
                >= (uint)portalPolygons.Polygons.Length)
            {
                continue;
            }
            FlatCollisionPolygon polygon =
                portalPolygons.Polygons[portal.PolygonIndex];
            if (polygon.VertexRange.Count < 3)
                continue;

            var vertices =
                new Vector3[polygon.VertexRange.Count];
            for (int index = 0; index < vertices.Length; index++)
            {
                Vector3 local = portalPolygons.Vertices[
                    polygon.VertexRange.Start + index];
                vertices[index] =
                    Vector3.Transform(local, rotation)
                    + cellOriginWorld;
            }
            portalPlanes.Add(PortalPlane.FromVertices(
                vertices.AsSpan(),
                portal.OtherCellId,
                envCellId & 0xFFFFu,
                portal.Flags));
        }

        cellSurfaces.Add(new CellSurface(
            envCellId,
            structure.PhysicsBsp.PolygonTable,
            rotation,
            cellOriginWorld));
    }

    public static void CacheBuildings(
        PhysicsDataCache cache,
        LoadedLandblock landblock,
        TerrainSurface terrain,
        Vector3 origin)
    {
        int count = BuildingCount(landblock);
        for (int index = 0; index < count; index++)
            CacheBuilding(cache, landblock, terrain, origin, index);
    }

    /// <summary>How many buildings the landblock's game data lists.</summary>
    public static int BuildingCount(LoadedLandblock landblock)
    {
        ArgumentNullException.ThrowIfNull(landblock);
        return landblock.PhysicsDats?.Info?.Buildings.Count ?? 0;
    }

    /// <summary>The <paramref name="index"/>th building the landblock lists, into the cache.</summary>
    public static void CacheBuilding(
        PhysicsDataCache cache,
        LoadedLandblock landblock,
        TerrainSurface terrain,
        Vector3 origin,
        int index)
    {
        ArgumentNullException.ThrowIfNull(cache);
        ArgumentNullException.ThrowIfNull(landblock);
        ArgumentNullException.ThrowIfNull(terrain);
        PhysicsDatBundle dats =
            landblock.PhysicsDats ?? PhysicsDatBundle.Empty;
        if (dats.Info is not { } info)
            return;

        uint prefix = landblock.LandblockId & 0xFFFF0000u;
        BuildingInfo building = info.Buildings[index];
        var portals =
            new List<BldPortalInfo>(building.Portals.Count);
        foreach (var portal in building.Portals)
        {
            portals.Add(new BldPortalInfo(
                prefix | (uint)portal.OtherCellId,
                unchecked((short)portal.OtherPortalId),
                (ushort)portal.Flags));
        }

        Vector3 buildingOrigin = building.Frame.Origin + origin;
        Matrix4x4 transform =
            Matrix4x4.CreateFromQuaternion(
                building.Frame.Orientation)
            * Matrix4x4.CreateTranslation(buildingOrigin);
        uint landcellId = prefix
            | terrain.ComputeOutdoorCellId(
                building.Frame.Origin.X,
                building.Frame.Origin.Y);
        uint shellPartZero = building.ModelId;
        if ((shellPartZero & 0xFF000000u) == 0x02000000u)
        {
            dats.Setups.TryGetValue(
                building.ModelId,
                out Setup? setup);
            shellPartZero =
                setup is not null && setup.Parts.Count > 0
                    ? setup.Parts[0]
                    : 0u;
        }
        cache.CacheBuilding(
            landcellId,
            portals,
            transform,
            shellPartZero);
    }

    public static void CachePreparedObjects(
        PhysicsDataCache cache,
        LandblockCollisionBuild collisions)
    {
        ArgumentNullException.ThrowIfNull(cache);
        ArgumentNullException.ThrowIfNull(collisions);
        foreach ((uint id, FlatGfxObjCollisionAsset asset) in
            collisions.GfxObjs)
        {
            cache.CacheGfxObj(id, asset);
        }
        foreach ((uint id, FlatSetupCollision setup) in
            collisions.Setups)
        {
            cache.CacheSetup(id, setup);
        }
    }

    /// <summary>What publishing one static object's collision came to.</summary>
    public enum StaticCollisionKind
    {
        /// <summary>A building's shell: its collision is the building's cells.</summary>
        BuildingShell,

        /// <summary>Collision from its parts' own shapes.</summary>
        Bsp,

        /// <summary>Collision from its setup's cylinders or spheres.</summary>
        Setup,

        /// <summary>Drawn, with nothing to collide with.</summary>
        NoCollision,
    }

    public static StaticCollisionPublication PublishStaticCollision(
        PhysicsEngine engine,
        PhysicsDataCache cache,
        LoadedLandblock landblock,
        LandblockCollisionBuild collisions,
        Vector3 origin)
    {
        ArgumentNullException.ThrowIfNull(engine);
        ArgumentNullException.ThrowIfNull(cache);
        ArgumentNullException.ThrowIfNull(landblock);
        ArgumentNullException.ThrowIfNull(collisions);

        int bspOwners = 0;
        int setupOwners = 0;
        int noCollision = 0;
        foreach (WorldEntity entity in landblock.Entities)
        {
            switch (PublishStaticEntity(engine, cache, landblock, origin, entity))
            {
                case StaticCollisionKind.Bsp:
                    bspOwners++;
                    break;
                case StaticCollisionKind.Setup:
                    setupOwners++;
                    break;
                case StaticCollisionKind.NoCollision:
                    noCollision++;
                    break;
            }
        }

        RefloodStaticOwners(engine, landblock.LandblockId);
        return new StaticCollisionPublication(
            bspOwners,
            setupOwners,
            noCollision);
    }

    /// <summary>
    /// The physics state of an object made from the dats: static, so an
    /// ethereal mover still collides with it.
    /// </summary>
    private const uint DatStaticState = (uint)PhysicsStateFlags.Static;

    /// <summary>
    /// One static object's collision, registered with the engine's shadow
    /// objects in the landblock. The prepared objects must be in the cache.
    /// </summary>
    public static StaticCollisionKind PublishStaticEntity(
        PhysicsEngine engine,
        PhysicsDataCache cache,
        LoadedLandblock landblock,
        Vector3 origin,
        WorldEntity entity)
    {
        ArgumentNullException.ThrowIfNull(engine);
        ArgumentNullException.ThrowIfNull(cache);
        ArgumentNullException.ThrowIfNull(landblock);
        ArgumentNullException.ThrowIfNull(entity);

        if (entity.IsBuildingShell)
            return StaticCollisionKind.BuildingShell;

        IReadOnlyList<ShadowShape> bspShapes =
            ShadowShapeBuilder.FromLandblockBspParts(
                entity.MeshRefs,
                entity.IsBuildingShell,
                cache.GetGfxObj);

        IReadOnlyList<ShadowShape> partArray =
            ShadowShapeBuilder.FromStaticRenderParts(
                entity.MeshRefs,
                cache.GetGfxObj,
                cache.GetVisualBounds,
                out _);

        if (bspShapes.Count > 0)
        {
            engine.ShadowObjects.RegisterMultiPart(
                entity.Id,
                entity.Position,
                entity.Rotation,
                bspShapes,
                DatStaticState,
                EntityCollisionFlags.None,
                worldOffsetX: origin.X,
                worldOffsetY: origin.Y,
                landblockId: landblock.LandblockId,
                seedCellId: entity.ParentCellId ?? 0u,
                isStatic: true,
                partArray: partArray);
            return StaticCollisionKind.Bsp;
        }

        FlatSetupCollision? setup =
            cache.GetFlatSetup(
                entity.SourceGfxObjOrSetupId);
        if (setup is null)
        {
            RegisterRenderOnlyStatic(
                engine, entity, partArray, landblock, origin);
            return StaticCollisionKind.NoCollision;
        }

        float scale = entity.Scale > 0f ? entity.Scale : 1f;
        var setupShapes = new List<ShadowShape>();
        for (int index = 0;
            index < setup.Cylinders.Length;
            index++)
        {
            FlatCollisionCylinder cylinder =
                setup.Cylinders[index];
            float radius = cylinder.Radius * scale;
            float height = (cylinder.Height > 0f
                ? cylinder.Height
                : cylinder.Radius * 4f) * scale;
            if (radius <= 0f)
                continue;
            setupShapes.Add(ShadowShape.Cylinder(
                entity.SourceGfxObjOrSetupId,
                cylinder.Origin * scale,
                Quaternion.Identity,
                scale,
                radius,
                height));
        }

        if (setup.Cylinders.Length == 0)
        {
            for (int index = 0;
                index < setup.Spheres.Length;
                index++)
            {
                FlatCollisionSphere sphere = setup.Spheres[index];
                if (sphere.Radius <= 0f)
                    continue;
                float radius = sphere.Radius * scale;
                Vector3 localOffset = sphere.Origin * scale;
                setupShapes.Add(
                ShadowShape.Sphere(
                    entity.SourceGfxObjOrSetupId,
                    localOffset,
                    Quaternion.Identity,
                    scale,
                    radius));
            }
        }

        if (setupShapes.Count == 0)
        {
            RegisterRenderOnlyStatic(
                engine, entity, partArray, landblock, origin);
            return StaticCollisionKind.NoCollision;
        }
        engine.ShadowObjects.RegisterMultiPart(
            entity.Id,
            entity.Position,
            entity.Rotation,
            setupShapes,
            DatStaticState,
            EntityCollisionFlags.None,
            worldOffsetX: origin.X,
            worldOffsetY: origin.Y,
            landblockId: landblock.LandblockId,
            seedCellId: entity.ParentCellId ?? 0u,
            isStatic: true,
            partArray: partArray);
        return StaticCollisionKind.Setup;
    }

    /// <summary>
    /// Re-files every owner the landblock's statics overlap into the cells
    /// they reach, once all of them are registered.
    /// </summary>
    public static void RefloodStaticOwners(PhysicsEngine engine, uint landblockId)
    {
        ArgumentNullException.ThrowIfNull(engine);
        uint[] reflood =
            engine.ShadowObjects.CaptureRefloodOwnersForLandblock(
                landblockId);
        foreach (uint ownerId in reflood)
        {
            engine.ShadowObjects.RefloodOwnerForLandblock(
                ownerId,
                landblockId);
        }
    }

    private static void RegisterRenderOnlyStatic(
        PhysicsEngine engine,
        WorldEntity entity,
        IReadOnlyList<ShadowShape> partArray,
        LoadedLandblock landblock,
        Vector3 origin)
    {
        if (partArray.Count == 0)
            return;
        engine.ShadowObjects.RegisterMultiPart(
            entity.Id,
            entity.Position,
            entity.Rotation,
            Array.Empty<ShadowShape>(),
            DatStaticState,
            EntityCollisionFlags.None,
            worldOffsetX: origin.X,
            worldOffsetY: origin.Y,
            landblockId: landblock.LandblockId,
            seedCellId: entity.ParentCellId ?? 0u,
            isStatic: true,
            partArray: partArray);
    }
}
