using System;
using Godot;

namespace ACGodot;

/// <summary>
/// A free camera for looking around the world: hold the right mouse button to look, WASD to move, Space / C (or E / Q)
/// up and down, Shift for fast, the mouse wheel changes the speed.
/// </summary>
public partial class FlyCamera : Camera3D
{
    public float Speed { get; set; } = 30f;     // m/s
    private float _yaw, _pitch;
    private bool _looking;
    /// <summary>False while the player character has the camera (it's placed behind them instead).</summary>
    public bool Free { get; set; } = true;
    public float Yaw => _yaw;

    public override void _Ready()
    {
        Far = 4000f;
        Near = 0.25f;
        Fov = 70f;
        _yaw = Rotation.Y; _pitch = Rotation.X;
    }

    public void LookAtYawPitch(float yawDeg, float pitchDeg)
    {
        _yaw = Mathf.DegToRad(yawDeg); _pitch = Mathf.DegToRad(pitchDeg);
        Rotation = new Vector3(_pitch, _yaw, 0);
    }

    public override void _UnhandledInput(InputEvent e)
    {
        if (!Free) return;
        if (e is InputEventMouseButton mb)
        {
            if (mb.ButtonIndex == MouseButton.Right)
            {
                _looking = mb.Pressed;
                Input.MouseMode = _looking ? Input.MouseModeEnum.Captured : Input.MouseModeEnum.Visible;
            }
            else if (mb.Pressed && mb.ButtonIndex == MouseButton.WheelUp) Speed = Math.Min(Speed * 1.25f, 2000f);
            else if (mb.Pressed && mb.ButtonIndex == MouseButton.WheelDown) Speed = Math.Max(Speed / 1.25f, 2f);
        }
        else if (e is InputEventMouseMotion mm && _looking)
        {
            _yaw -= mm.Relative.X * 0.003f;
            _pitch = Mathf.Clamp(_pitch - mm.Relative.Y * 0.003f, -1.55f, 1.55f);
            Rotation = new Vector3(_pitch, _yaw, 0);
        }
    }

    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("FlyCamera");
        if (!Free || GetViewport().GuiGetFocusOwner() is LineEdit or TextEdit) return;   // the player has it, or typing in a box
        var dir = Vector3.Zero;
        if (Input.IsKeyPressed(Key.W)) dir -= Transform.Basis.Z;
        if (Input.IsKeyPressed(Key.S)) dir += Transform.Basis.Z;
        if (Input.IsKeyPressed(Key.A)) dir -= Transform.Basis.X;
        if (Input.IsKeyPressed(Key.D)) dir += Transform.Basis.X;
        if (Input.IsKeyPressed(Key.Space) || Input.IsKeyPressed(Key.E)) dir += Vector3.Up;
        if (Input.IsKeyPressed(Key.C) || Input.IsKeyPressed(Key.Q)) dir -= Vector3.Up;
        if (dir == Vector3.Zero) return;
        float s = Speed * (Input.IsKeyPressed(Key.Shift) ? 5f : 1f);
        Position += dir.Normalized() * s * (float)delta;
    }
}
