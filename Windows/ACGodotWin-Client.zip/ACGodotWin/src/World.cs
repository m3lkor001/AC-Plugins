using System;
using Godot;

namespace ACGodot;

/// <summary>
/// Where things are. AC's world is 255 x 255 landblocks of 192 m, Z up, x east, y north. Godot is Y up with -Z
/// forward, so AC (x, y, z) is drawn at Godot (x, z, -y), with x and y counted from the world's south-west corner.
/// </summary>
public static class World
{
    public const float LandblockSize = 192f;

    public static Vector3 ToGodot(System.Numerics.Vector3 ac) => new(ac.X, ac.Z, -ac.Y);
    public static Vector3 ToGodot(float x, float y, float z) => new(x, z, -y);

    /// <summary>AC world position (x east, y north, z up) of a Godot position.</summary>
    public static (float x, float y, float z) ToAc(Vector3 g) => (g.X, -g.Z, g.Y);

    /// <summary>The landblock under a Godot position.</summary>
    public static (int x, int y) LandblockAt(Vector3 g)
    {
        var (x, y, _) = ToAc(g);
        return ((int)Math.Floor(x / LandblockSize), (int)Math.Floor(y / LandblockSize));
    }

    /// <summary>Map coordinates the way the game shows them, e.g. "42.1N, 33.6E".</summary>
    public static string MapCoords(Vector3 g)
    {
        var (x, y, _) = ToAc(g);
        double ew = x / 240.0 - 101.95, ns = y / 240.0 - 101.95;
        return $"{Math.Abs(ns):0.0}{(ns >= 0 ? "N" : "S")}, {Math.Abs(ew):0.0}{(ew >= 0 ? "E" : "W")}";
    }

    /// <summary>The Godot position for map coordinates (north and east positive), at height 0.</summary>
    public static Vector3 FromMapCoords(double ns, double ew)
    {
        float x = (float)((ew + 101.95) * 240.0), y = (float)((ns + 101.95) * 240.0);
        return ToGodot(x, y, 0);
    }
}
