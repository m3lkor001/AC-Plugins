using Godot;

namespace ACGodot.Net;

/// <summary>Whether to play on a server, and which (user://net.cfg). Off unless switched on in the options.</summary>
public sealed class NetSettings
{
    private const string Path = "user://net.cfg";
    public bool Enabled;
    public string Host = "127.0.0.1";
    public int Port = 9000;
    public string Account = "", Password = "", Character = "";

    /// <summary>
    /// The server and login the launcher started the game with (environment variables ACGODOT_SERVER, _PORT,
    /// _ACCOUNT, _PASSWORD, _CHARACTER - not the command line, where others could read the password); null if it
    /// wasn't started that way. Used for that run only, never saved.
    /// </summary>
    public static NetSettings? FromLauncher()
    {
        string? host = System.Environment.GetEnvironmentVariable("ACGODOT_SERVER");
        if (string.IsNullOrEmpty(host)) return null;
        return new NetSettings
        {
            Enabled = true, Host = host,
            Port = int.TryParse(System.Environment.GetEnvironmentVariable("ACGODOT_PORT"), out int p) ? p : 9000,
            Account = System.Environment.GetEnvironmentVariable("ACGODOT_ACCOUNT") ?? "",
            Password = System.Environment.GetEnvironmentVariable("ACGODOT_PASSWORD") ?? "",
            Character = System.Environment.GetEnvironmentVariable("ACGODOT_CHARACTER") ?? "",
        };
    }

    public static NetSettings Load()
    {
        var s = new NetSettings();
        var cfg = new ConfigFile();
        if (global::ACGodot.SafeConfig.Load(cfg, Path) != Error.Ok) return s;
        s.Enabled = (bool)cfg.GetValue("server", "enabled", false);
        s.Host = (string)cfg.GetValue("server", "host", s.Host);
        s.Port = (int)cfg.GetValue("server", "port", s.Port);
        s.Account = (string)cfg.GetValue("server", "account", "");
        s.Password = (string)cfg.GetValue("server", "password", "");
        s.Character = (string)cfg.GetValue("server", "character", "");
        return s;
    }

    public void Save()
    {
        var cfg = new ConfigFile();
        cfg.SetValue("server", "enabled", Enabled);
        cfg.SetValue("server", "host", Host);
        cfg.SetValue("server", "port", Port);
        cfg.SetValue("server", "account", Account);
        cfg.SetValue("server", "password", Password);
        cfg.SetValue("server", "character", Character);
        global::ACGodot.SafeConfig.Save(cfg, Path);
    }
}
