using System;
using System.Linq;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace ACGodot.Net;

/// <summary>
/// Asheron's Call's network protocol, the client's end (as ACE speaks it): UDP packets with a 20-byte header (sequence,
/// flags, checksum, client id, time, size, iteration), optional header parts by flag, and game messages carried in
/// fragments (split when big). Logging in is a three-way handshake: LoginRequest to the server's port, its
/// ConnectRequest back (a cookie, our client id and the two ISAAC seeds), our ConnectResponse to the port after it.
/// After that game messages flow both ways; we acknowledge the server's packets as they come. Our checksums go
/// unencrypted (the server accepts those); the server's aren't checked.
/// </summary>
public sealed class AcClient : IDisposable
{
    // header flags
    public const uint Retransmission = 0x1, EncryptedChecksum = 0x2, BlobFragments = 0x4, RequestRetransmit = 0x1000,
                      RejectRetransmit = 0x2000, AckSequence = 0x4000, DisconnectFlag = 0x8000, LoginRequest = 0x10000,
                      WorldLoginRequest = 0x20000, ConnectRequest = 0x40000, ConnectResponse = 0x80000, NetError = 0x100000,
                      NetErrorDisconnect = 0x200000, CICMDCommand = 0x400000, TimeSync = 0x1000000, EchoRequest = 0x2000000,
                      EchoResponse = 0x4000000, Flow = 0x8000000, ServerSwitch = 0x100, Referral = 0x800;

    private readonly UdpClient _udp;
    private readonly IPEndPoint _login, _world;
    private ushort _clientId;
    private ulong _cookie;
    private uint _sequence = 1;          // our last data packet's sequence (the first is 2, as ACE expects)
    private uint _fragmentSequence;      // our last message's sequence (the first is 1: ACE takes them strictly in order from 1 - a
                                         // first message numbered 2 is "early", put aside for a 1 that never comes)
    private uint _serverSeqHighest;      // the server's highest packet sequence seen (for acks)
    private uint _ackedServer;
    // what's come from the server, packet by packet: the internet drops some, and the server sends a dropped one again
    // only when asked - and only while it hasn't been told (by an ack) that everything up to there arrived. So: acks
    // go no further than the last packet with none missing before it, and the missing ones are asked for.
    private readonly object _recvLock = new();
    private bool _recvStarted;
    private uint _contig;                                   // every packet up to this one has arrived
    private readonly HashSet<uint> _got = new();            // arrived, beyond a gap
    // what those packets beyond a gap carry, kept until the gap is filled: the game reads the server's messages in the
    // order they were sent (a dropped packet that comes again later otherwise lands after everything sent after it -
    // a /qb list's lines came out of order, and a block of completed flags read as in progress)
    private readonly SortedDictionary<uint, byte[]> _held = new();
    private readonly Dictionary<uint, (DateTime first, DateTime asked)> _missing = new();
    /// <summary>Packets the server sent that didn't arrive; how many came on asking again; how many never did.</summary>
    public int Lost, Recovered, GaveUp;
    /// <summary>How many of ours the server asked for again (they never reached it) and were sent again.</summary>
    public int Resent;
    private readonly Dictionary<uint, byte[]> _sent = new();
    private uint _actionSequence;
    private readonly Thread _reader;
    private volatile bool _closed;
    private DateTime _lastAck = DateTime.MinValue, _lastHeard = DateTime.UtcNow;
    private readonly Dictionary<uint, (int count, byte[]?[] parts)> _partial = new();
    private readonly object _sendLock = new();
    private volatile bool _handshaking;
    private DateTime _handshakeAt;
    private int _handshakeTries;

    /// <summary>Game messages received (opcode, payload after the opcode), to be taken on the main thread.</summary>
    public readonly ConcurrentQueue<(uint opcode, byte[] payload)> Inbox = new();
    /// <summary>Things worth telling the player about the connection.</summary>
    public readonly ConcurrentQueue<string> Notes = new();

    public bool Connected { get; private set; }
    public bool Failed { get; private set; }

    public AcClient(string host, int port)
    {
        var addr = Dns.GetHostAddresses(host)[0];
        if (addr.AddressFamily != AddressFamily.InterNetwork)
            foreach (var a in Dns.GetHostAddresses(host)) if (a.AddressFamily == AddressFamily.InterNetwork) { addr = a; break; }
        _login = new IPEndPoint(addr, port);
        _world = new IPEndPoint(addr, port + 1);
        _udp = new UdpClient(0);
        _udp.Client.ReceiveTimeout = 500;
        _reader = new Thread(ReadLoop) { IsBackground = true, Name = "AC network" };
        _reader.Start();
    }

    // ── logging in ──

    public void Login(string account, string password)
    {
        // the login data: client version "1802", the rest's length, auth type 2 (account and password), flags,
        // timestamp, account, account to log in as (none), password
        _account = account; _password = password; _logins++;
        var body = new MemoryStream();
        var w = new BinaryWriter(body);
        WriteString16L(w, "1802");
        var rest = new MemoryStream();
        var r = new BinaryWriter(rest);
        r.Write(2u);                               // NetAuthType.AccountPassword
        r.Write(0u);                               // auth flags
        r.Write((uint)(DateTimeOffset.UtcNow.ToUnixTimeSeconds()));
        WriteString16L(r, account);
        WriteString16L(r, "");
        WriteString32L(r, password);
        w.Write((uint)rest.Length);
        w.Write(rest.ToArray());
        SendRaw(_login, 0, LoginRequest, 0, body.ToArray(), null);
        Notes.Enqueue($"Logging in to {_login} as {account}...");
    }

    // ── sending game messages ──

    /// <summary>Sends a game message (opcode and payload) in a fragment (or several, if big), on a message queue.</summary>
    /// <summary>Every game message sent (its opcode and what follows it), for plugins that watch them (Decal's ClientDispatch).</summary>
    public readonly System.Collections.Concurrent.ConcurrentQueue<(uint op, byte[] payload)> SentLog = new();
    public bool KeepSent;
    public void Send(uint opcode, byte[] payload, ushort queue = 9)
    {
        if (!Connected) return;
        if (KeepSent && SentLog.Count < 2000) SentLog.Enqueue((opcode, payload));
        var msg = new byte[4 + payload.Length];
        BitConverter.GetBytes(opcode).CopyTo(msg, 0);
        payload.CopyTo(msg, 4);
        const int MaxChunk = 448;
        int count = (msg.Length + MaxChunk - 1) / MaxChunk;
        uint fseq;
        lock (_sendLock) fseq = ++_fragmentSequence;
        for (int i = 0; i < count; i++)
        {
            int len = Math.Min(MaxChunk, msg.Length - i * MaxChunk);
            var frag = new byte[16 + len];
            BitConverter.GetBytes(fseq).CopyTo(frag, 0);
            BitConverter.GetBytes(0x80000000u).CopyTo(frag, 4);
            BitConverter.GetBytes((ushort)count).CopyTo(frag, 8);
            BitConverter.GetBytes((ushort)(16 + len)).CopyTo(frag, 10);
            BitConverter.GetBytes((ushort)i).CopyTo(frag, 12);
            BitConverter.GetBytes(queue).CopyTo(frag, 14);
            Array.Copy(msg, i * MaxChunk, frag, 16, len);
            uint seq;
            lock (_sendLock)
            {
                seq = ++_sequence;
                // (kept until the server says it has it: one that never arrives is asked for again, and has to be sent
                // again - the server takes ours in order, and does nothing with any that come after a gap)
                _sent[seq] = frag;
                if (_sent.Count > 4000) foreach (uint old in _sent.Keys.Where(k => k + 3000 < seq).ToList()) _sent.Remove(old);
            }
            SendRaw(_login, seq, BlobFragments, _clientId, null, frag);
        }
    }

    /// <summary>Sends a game action (0xF7B1: our action sequence, the action, its data).</summary>
    /// <summary>Actions not to send just now (logging out: no attacks, casts, uses or item moves).</summary>
    public Func<uint, bool>? Holds;
    // (a runaway - a plugin or a loop asking the same thing over and over: held back, so the server isn't flooded.
    // Moving and saying where we are go as often as they need)
    private readonly Dictionary<uint, Queue<long>> _recent = new();
    private (uint action, int hash, int times, long since) _same;
    private long _floodNoted;
    public int Flooded;
    private readonly List<byte[]> _waitingIds = new();

    /// <summary>Sends the appraisals that waited (30 a second at most), oldest first.</summary>
    private void SendWaitingIds()
    {
        if (_waitingIds.Count == 0) return;
        long now = Environment.TickCount64;
        if (!_recent.TryGetValue(0x00C8, out var q)) _recent[0x00C8] = q = new Queue<long>();
        while (q.Count > 0 && now - q.Peek() > 1000) q.Dequeue();
        while (_waitingIds.Count > 0 && q.Count < 30)
        {
            var payload = _waitingIds[0]; _waitingIds.RemoveAt(0);
            q.Enqueue(now);
            var b = new byte[8 + payload.Length];
            BitConverter.GetBytes(++_actionSequence).CopyTo(b, 0);
            BitConverter.GetBytes(0x00C8u).CopyTo(b, 4);
            payload.CopyTo(b, 8);
            Send(0xF7B1, b, 5);
        }
    }

    public void SendAction(uint action, byte[] payload)
    {
        if (Holds?.Invoke(action) == true) return;
        if (action is not (0xF61C or 0xF753 or 0xF61B))
        {
            long now = Environment.TickCount64;
            if (!_recent.TryGetValue(action, out var q)) _recent[action] = q = new Queue<long>();
            while (q.Count > 0 && now - q.Peek() > 1000) q.Dequeue();
            int hash = 17; foreach (byte x in payload) hash = hash * 31 + x;
            if (_same.action == action && _same.hash == hash && now - _same.since < 1000) _same.times++;
            else _same = (action, hash, 1, now);
            // appraisals (0x00C8) past 30 a second wait their turn instead: plugins ask for a whole pack's at login, and
            // one held back was never answered - its asker waited on it for good
            if (action == 0x00C8 && (q.Count >= 30 || _waitingIds.Count > 0) && _same.times <= 12)
            {
                if (_waitingIds.Count < 2000 && !_waitingIds.Exists(w => w.AsSpan().SequenceEqual(payload))) _waitingIds.Add(payload);
                return;
            }
            // more than 40 of one kind in a second, or the very same one more than 12 times in a second
            if (q.Count >= 40 || _same.times > 12)
            {
                Flooded++;
                if (now - _floodNoted > 10000) { _floodNoted = now; Notes.Enqueue($"held back a flood of action 0x{action:X4} ({q.Count} in the last second{(_same.times > 12 ? $", the same one {_same.times} times" : "")}) - something is asking too fast"); }
                return;
            }
            q.Enqueue(now);
        }
        var b = new byte[8 + payload.Length];
        BitConverter.GetBytes(++_actionSequence).CopyTo(b, 0);
        BitConverter.GetBytes(action).CopyTo(b, 4);
        payload.CopyTo(b, 8);
        Send(0xF7B1, b, 5);
    }

    /// <summary>Keeps the connection up: acknowledges what the server sent (called often).</summary>
    public void Pump()
    {
        if (!Connected || _closed) return;
        var now = DateTime.UtcNow;
        if (_handshaking) return;   // (the network thread is finishing the handshake)
        SendWaitingIds();
        uint upTo; List<uint>? ask = null;
        lock (_recvLock)
        {
            foreach (var (m, t) in _missing.ToList())
            {
                // (never came, however often asked: let go, so the acks can move on)
                // (sooner while packets after it are held back waiting for it: the game's messages stop till then)
                if ((now - t.first).TotalSeconds > (_held.Count > 0 ? 2 : 6)) { _missing.Remove(m); _got.Add(m); GaveUp++; continue; }
                // (a moment's grace first: packets also just arrive out of order)
                if ((now - t.first).TotalMilliseconds < 120 || (now - t.asked).TotalMilliseconds < 400 || ask?.Count >= 60) continue;
                (ask ??= new()).Add(m);
                _missing[m] = (t.first, now);
            }
            while (_got.Remove(_contig + 1)) _contig++;
            ReleaseHeld();
            upTo = _recvStarted ? _contig : _serverSeqHighest;
        }
        if (ask != null)
        {
            var opt = new byte[4 + 4 * ask.Count];
            BitConverter.GetBytes((uint)ask.Count).CopyTo(opt, 0);
            for (int i = 0; i < ask.Count; i++) BitConverter.GetBytes(ask[i]).CopyTo(opt, 4 + 4 * i);
            uint seq; lock (_sendLock) seq = _sequence;
            SendRaw(_login, seq, RequestRetransmit, _clientId, opt, null);
        }
        if (upTo != _ackedServer && (now - _lastAck).TotalMilliseconds > 200 || (now - _lastAck).TotalSeconds > 2)
        {
            _lastAck = now;
            _ackedServer = upTo;
            var opt = BitConverter.GetBytes(upTo);
            uint seq; lock (_sendLock) seq = _sequence;
            SendRaw(_login, seq, AckSequence, _clientId, opt, null);
        }
        if ((now - _lastHeard).TotalSeconds > 30 && Connected) { Notes.Enqueue("The server has stopped answering."); Connected = false; Failed = true; }
    }

    public void Disconnect()
    {
        if (Connected) { uint seq; lock (_sendLock) seq = _sequence; SendRaw(_login, seq, DisconnectFlag, _clientId, null, null); }
        Connected = false;
    }

    // ── packets ──

    private static uint Hash32(byte[] data, int offset, int length)
    {
        uint checksum = (uint)length << 16;
        for (int i = 0; i + 4 <= length; i += 4) checksum += BitConverter.ToUInt32(data, offset + i);
        int shift = 3, j = length / 4 * 4;
        while (j < length) checksum += (uint)(data[offset + j++] << (8 * shift--));
        return checksum;
    }

    /// <summary>
    /// Sends a packet: the header, the optional part (raw bytes, in the flag order the caller built) and fragments.
    /// The checksum: the header's (with 0xBADD70DD in its place) plus the optional part's plus each fragment's
    /// (its header's and its data's).
    /// </summary>
    private void SendRaw(IPEndPoint to, uint sequence, uint flags, ushort id, byte[]? optional, byte[]? fragment)
    {
        int optLen = optional?.Length ?? 0, fragLen = fragment?.Length ?? 0;
        var buf = new byte[20 + optLen + fragLen];
        BitConverter.GetBytes(sequence).CopyTo(buf, 0);
        BitConverter.GetBytes(flags).CopyTo(buf, 4);
        BitConverter.GetBytes(0xBADD70DDu).CopyTo(buf, 8);
        BitConverter.GetBytes(id).CopyTo(buf, 12);
        BitConverter.GetBytes((ushort)0).CopyTo(buf, 14);
        BitConverter.GetBytes((ushort)(optLen + fragLen)).CopyTo(buf, 16);
        BitConverter.GetBytes((ushort)0).CopyTo(buf, 18);
        if (optional != null) optional.CopyTo(buf, 20);
        if (fragment != null) fragment.CopyTo(buf, 20 + optLen);
        uint headerHash = Hash32(buf, 0, 20);
        uint payload = 0;
        if (optLen > 0) payload += Hash32(buf, 20, optLen);
        if (fragLen > 0) payload += Hash32(buf, 20 + optLen, 16) + Hash32(buf, 20 + optLen + 16, fragLen - 16);
        BitConverter.GetBytes(headerHash + payload).CopyTo(buf, 8);
        try { lock (_sendLock) _udp.Send(buf, buf.Length, to); }
        catch (Exception ex) { Notes.Enqueue("Send failed: " + ex.Message); }
    }

    private void ReadLoop()
    {
        var any = new IPEndPoint(IPAddress.Any, 0);
        while (!_closed)
        {
            byte[] data;
            HandshakeTick();
            try { data = _udp.Receive(ref any); }
            catch (SocketException) { continue; }
            catch (ObjectDisposedException) { break; }
            try { Handle(data); }
            catch (Exception ex) { Notes.Enqueue("Bad packet: " + ex.Message); }
        }
    }

    // the handshake's third step, on the network's own thread (not the game's: the game is busy loading the world just
    // then, and the server gives up on a login not answered within 15 seconds): our answer a moment after the server's
    // request, again each second till it talks; no luck after a while - the login from the start, a couple of times
    private void HandshakeTick()
    {
        if (!_handshaking) return;
        var now = DateTime.UtcNow;
        if (now < _handshakeAt) return;
        if (_handshakeTries >= 8)
        {
            _handshaking = false;
            if (_logins < 3 && _account != null)
            {
                Notes.Enqueue("No answer to the handshake - logging in again...");
                lock (_sendLock) { _sequence = 1; _fragmentSequence = 0; }
                Connected = false;
                Login(_account, _password ?? "");
            }
            else { Notes.Enqueue("The server didn't take the connection (no answer to the handshake)."); Connected = false; Failed = true; }
            return;
        }
        _handshakeTries++;
        _handshakeAt = now.AddSeconds(1);
        SendRaw(_world, 0, ConnectResponse, 0, BitConverter.GetBytes(_cookie), null);
    }

    private string? _account, _password;
    private int _logins;

    // the server's clock (seconds since its epoch - what the game's day and night go by): as last told, and when
    private double _serverTime; private long _serverTimeAt;
    private void NoteServerTime(double t) { if (t > 0) { _serverTime = t; _serverTimeAt = System.Diagnostics.Stopwatch.GetTimestamp(); } }
    /// <summary>The server's clock now (0: not told yet).</summary>
    public double ServerTime => _serverTime <= 0 ? 0 : _serverTime + (System.Diagnostics.Stopwatch.GetTimestamp() - _serverTimeAt) / (double)System.Diagnostics.Stopwatch.Frequency;

    private void Handle(byte[] d)
    {
        if (d.Length < 20) return;
        _lastHeard = DateTime.UtcNow;
        uint seq = BitConverter.ToUInt32(d, 0), flags = BitConverter.ToUInt32(d, 4);
        int size = BitConverter.ToUInt16(d, 16);
        var r = new BinaryReader(new MemoryStream(d, 20, Math.Min(size, d.Length - 20)));
        if ((flags & DisconnectFlag) != 0 || (flags & NetErrorDisconnect) != 0) { Notes.Enqueue("The server closed the connection."); Connected = false; Failed = true; return; }
        // the optional parts, in the order ACE reads them
        if ((flags & ServerSwitch) != 0) r.ReadBytes(8);
        if ((flags & RequestRetransmit) != 0)
        {
            // one of ours never reached the server: sent again, marked as such
            uint n = r.ReadUInt32();
            var gone = new List<uint>();
            for (uint i = 0; i < n; i++)
            {
                uint want = r.ReadUInt32();
                byte[]? frag;
                lock (_sendLock) _sent.TryGetValue(want, out frag);
                if (frag != null) { SendRaw(_login, want, BlobFragments | Retransmission, _clientId, null, frag); Resent++; }
                else gone.Add(want);
            }
            if (gone.Count > 0)
            {
                // (not ours to send again any more: said so, so the server stops waiting for it)
                var opt = new byte[4 + 4 * gone.Count];
                BitConverter.GetBytes((uint)gone.Count).CopyTo(opt, 0);
                for (int i = 0; i < gone.Count; i++) BitConverter.GetBytes(gone[i]).CopyTo(opt, 4 + 4 * i);
                uint cur; lock (_sendLock) cur = _sequence;
                SendRaw(_login, cur, RejectRetransmit, _clientId, opt, null);
            }
        }
        if ((flags & RejectRetransmit) != 0)
        {
            // (the server hasn't got these to send again: nothing more to wait for)
            uint n = r.ReadUInt32();
            lock (_recvLock) for (uint i = 0; i < n; i++) { uint gone = r.ReadUInt32(); if (_missing.Remove(gone)) { _got.Add(gone); GaveUp++; } }
        }
        if ((flags & AckSequence) != 0)
        {
            // (the server has everything of ours up to here)
            uint acked = r.ReadUInt32();
            lock (_sendLock) if (_sent.Count > 0) foreach (uint old in _sent.Keys.Where(k => k <= acked).ToList()) _sent.Remove(old);
        }
        if ((flags & Referral) != 0) { /* not used by ACE */ }
        if ((flags & ConnectRequest) != 0)
        {
            NoteServerTime(r.ReadDouble());  // server time
            _cookie = r.ReadUInt64();
            _clientId = (ushort)r.ReadUInt32();
            r.ReadBytes(4); r.ReadBytes(4);  // the ISAAC seeds (we don't encrypt)
            r.ReadUInt32();
            // the third step: the cookie back, to the port after the server's - but not at once: ACE sends this request
            // and only then checks the password and marks the session as waiting for the answer; an answer that's there
            // first (a server on this computer) is dropped without a word. So a moment later, and again each second
            // until the server starts talking (Pump)
            _handshakeTries = 0;
            _handshakeAt = DateTime.UtcNow.AddMilliseconds(400);
            _handshaking = true;
            lock (_recvLock) { _recvStarted = false; _contig = 0; _got.Clear(); _missing.Clear(); _held.Clear(); _serverSeqHighest = 0; _ackedServer = 0; }
            Connected = true;
            Notes.Enqueue("Connected.");
            return;
        }
        if ((flags & CICMDCommand) != 0) r.ReadBytes(8);
        if ((flags & TimeSync) != 0) NoteServerTime(r.ReadDouble());
        if ((flags & EchoRequest) != 0) r.ReadSingle();
        if ((flags & EchoResponse) != 0) { r.ReadSingle(); r.ReadSingle(); }
        if ((flags & Flow) != 0) { r.ReadUInt32(); r.ReadUInt16(); }
        _handshaking = false;   // the server's talking: it took our answer
        // (the server gives a number of its own to every packet but a bare ack or its own asking-again - from 2 on - and
        // keeps each to send again if asked)
        if (seq >= 2 && (flags & ~Retransmission) != AckSequence && (flags & RequestRetransmit) == 0)
        {
            lock (_recvLock)
            {
                // (its first is 2: ones lost before the first to arrive are asked for too)
                if (!_recvStarted) { _recvStarted = true; _contig = seq < 50 ? 1 : seq - 1; _serverSeqHighest = _contig; }
                if (seq <= _contig || !_got.Add(seq)) return;   // (had it already: one sent again that wasn't needed)
                if (_missing.Remove(seq)) Recovered++;
                if (seq > _serverSeqHighest)
                {
                    var at = DateTime.UtcNow;
                    for (uint m = _serverSeqHighest + 1; m < seq && _missing.Count < 4000; m++)
                        if (m > _contig && !_got.Contains(m) && _missing.TryAdd(m, (at, DateTime.MinValue))) Lost++;
                    _serverSeqHighest = seq;
                }
                while (_got.Remove(_contig + 1)) _contig++;
                if (seq > _contig)
                {
                    // beyond a gap: kept till the packets before it are in
                    if ((flags & BlobFragments) != 0) _held[seq] = r.ReadBytes((int)(r.BaseStream.Length - r.BaseStream.Position));
                    return;
                }
                if ((flags & BlobFragments) != 0) Fragments(r);
                ReleaseHeld();
                return;
            }
        }
        if ((flags & BlobFragments) == 0) return;
        Fragments(r);
    }

    /// <summary>Held packets now in order (nothing missing before them), read in turn. (Under _recvLock.)</summary>
    private void ReleaseHeld()
    {
        while (_held.Count > 0)
        {
            uint first = _held.Keys.First();
            if (first > _contig) break;
            byte[] b = _held[first];
            _held.Remove(first);
            try { Fragments(new BinaryReader(new MemoryStream(b))); } catch { }
        }
    }

    private void Fragments(BinaryReader r)
    {
        while (r.BaseStream.Position + 16 <= r.BaseStream.Length)
        {
            uint fseq = r.ReadUInt32(); r.ReadUInt32();
            ushort count = r.ReadUInt16(), fsize = r.ReadUInt16(), index = r.ReadUInt16(); r.ReadUInt16();
            if (fsize < 16) break;
            var part = r.ReadBytes(fsize - 16);
            if (count <= 1) { Message(part); continue; }
            lock (_partial)
            {
                if (!_partial.TryGetValue(fseq, out var p)) _partial[fseq] = p = (count, new byte[count][]);
                if (index < p.parts.Length) p.parts[index] = part;
                if (Array.TrueForAll(p.parts, x => x != null))
                {
                    _partial.Remove(fseq);
                    var all = new MemoryStream();
                    foreach (var x in p.parts) all.Write(x!);
                    Message(all.ToArray());
                }
            }
        }
    }

    private void Message(byte[] m)
    {
        if (m.Length < 4) return;
        uint opcode = BitConverter.ToUInt32(m, 0);
        var payload = new byte[m.Length - 4];
        Array.Copy(m, 4, payload, 0, payload.Length);
        Inbox.Enqueue((opcode, payload));
    }

    public void Dispose()
    {
        try { Disconnect(); } catch { }
        _closed = true;
        try { _udp.Close(); } catch { }
    }

    // ── the protocol's strings ──

    private static readonly Encoding Latin = Encoding.Latin1;

    /// <summary>A string with a 16-bit length, padded so length and text fill a multiple of 4 bytes.</summary>
    public static void WriteString16L(BinaryWriter w, string s)
    {
        var b = Latin.GetBytes(s ?? "");
        w.Write((ushort)b.Length);
        w.Write(b);
        int pad = (4 - (2 + b.Length) % 4) % 4;
        for (int i = 0; i < pad; i++) w.Write((byte)0);
    }

    /// <summary>A string with a 32-bit length (the password): the length, then a 16-bit-length-style string? No - ACE's ReadString32L.</summary>
    public static void WriteString32L(BinaryWriter w, string s)
    {
        // ACE's ReadString32L: a uint length (of what follows), then a byte length (packed), the text, padded to 4
        var b = Latin.GetBytes(s ?? "");
        int lenBytes = b.Length > 255 ? 2 : 1;
        int total = lenBytes + b.Length;
        w.Write((uint)total);
        if (lenBytes == 1) w.Write((byte)b.Length);
        else { w.Write((byte)((b.Length >> 8) | 0x80)); w.Write((byte)(b.Length & 0xFF)); }
        w.Write(b);
        int pad = (4 - (4 + total) % 4) % 4;
        for (int i = 0; i < pad; i++) w.Write((byte)0);
    }

    public static string ReadString16L(BinaryReader r)
    {
        int len = r.ReadUInt16();
        var s = Latin.GetString(r.ReadBytes(len));
        int pad = (4 - (2 + len) % 4) % 4;
        r.ReadBytes(pad);
        return s;
    }

    /// <summary>A packed dword: two bytes if the top bit of the first word is clear, else four.</summary>
    public static uint ReadPackedDword(BinaryReader r)
    {
        ushort a = r.ReadUInt16();
        if ((a & 0x8000) == 0) return a;
        ushort b = r.ReadUInt16();
        return (uint)(((a & 0x7FFF) << 16) | b);
    }

    public static void Align(BinaryReader r)
    {
        long pad = (4 - r.BaseStream.Position % 4) % 4;
        r.BaseStream.Position += pad;
    }
}
