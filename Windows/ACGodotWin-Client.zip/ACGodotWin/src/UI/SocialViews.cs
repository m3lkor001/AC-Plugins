using Godot;
using System;
using System.Linq;

namespace ACGodot.UI;

/// <summary>
/// The Social panel's pages as the game lays them out: the fellowship (its name, each fellow on a blue band with their
/// level and three bars - health, stamina, mana - and the six buttons), the allegiance (its name, followers and rank,
/// then MONARCH, PATRON and VASSALS between gold lines), and the friends list.
/// </summary>
public static class SocialViews
{
    private static readonly Color Band = new(0.13f, 0.2f, 0.3f, 0.95f), BandPicked = new(0.22f, 0.34f, 0.5f, 0.95f);
    private static readonly Color GoldLine = new(0.78f, 0.56f, 0.2f);
    private static uint _pickedFellow, _pickedFriend;
    private static string _fellowName = "", _friendName = "";
    private static bool _shareXp = true;

    private static Label Text(string s, Color? c = null, HorizontalAlignment al = HorizontalAlignment.Left)
    {
        var l = new Label { Text = s, HorizontalAlignment = al, AutowrapMode = TextServer.AutowrapMode.Off, ClipText = true, MouseFilter = Control.MouseFilterEnum.Ignore, SizeFlagsHorizontal = Control.SizeFlags.ExpandFill };
        l.AddThemeColorOverride("font_color", c ?? RetailTheme.Ink);
        return l;
    }

    /// <summary>A button as the game draws these: dark red-brown, lined in gold (a brighter red for Quit); dim when it can't be used.</summary>
    public static Control Button(string text, Action press, bool enabled = true, bool red = false)
    {
        var box = new PanelContainer { MouseFilter = Control.MouseFilterEnum.Stop, CustomMinimumSize = new Vector2(0, 22), SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
                                       MouseDefaultCursorShape = enabled ? Control.CursorShape.PointingHand : Control.CursorShape.Arrow };
        StyleBoxFlat Look(bool lit) => new()
        {
            BgColor = red ? new Color(lit ? 0.6f : 0.42f, 0.03f, 0.03f, 0.95f) : new Color(lit ? 0.3f : 0.18f, lit ? 0.09f : 0.05f, 0.04f, 0.95f),
            BorderColor = enabled ? new Color(0.7f, 0.55f, 0.28f) : new Color(0.35f, 0.28f, 0.15f),
            BorderWidthLeft = 2, BorderWidthRight = 2, BorderWidthTop = 2, BorderWidthBottom = 2, ContentMarginLeft = 4, ContentMarginRight = 4, ContentMarginTop = 1, ContentMarginBottom = 1,
        };
        box.AddThemeStyleboxOverride("panel", Look(false));
        box.AddChild(Text(text, enabled ? RetailTheme.Ink : RetailTheme.Dim, HorizontalAlignment.Center));
        if (!enabled) return box;
        box.MouseEntered += () => box.AddThemeStyleboxOverride("panel", Look(true));
        box.MouseExited += () => box.AddThemeStyleboxOverride("panel", Look(false));
        box.GuiInput += e => { if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true }) { box.AcceptEvent(); press(); } };
        return box;
    }

    // one of the three bars: rounded, its colour filled as far as it's full, "now/most" over it
    private static Control Bar(int now, int most, Color color)
    {
        var bar = new ProgressBar { MinValue = 0, MaxValue = Math.Max(1, most), Value = Math.Clamp(now, 0, Math.Max(1, most)), ShowPercentage = false,
                                    CustomMinimumSize = new Vector2(0, 14), SizeFlagsHorizontal = Control.SizeFlags.ExpandFill, MouseFilter = Control.MouseFilterEnum.Ignore };
        bar.AddThemeStyleboxOverride("background", new StyleBoxFlat { BgColor = new Color(color.R * 0.22f, color.G * 0.22f, color.B * 0.22f, 0.95f), CornerRadiusTopLeft = 7, CornerRadiusTopRight = 7, CornerRadiusBottomLeft = 7, CornerRadiusBottomRight = 7 });
        bar.AddThemeStyleboxOverride("fill", new StyleBoxFlat { BgColor = color, CornerRadiusTopLeft = 7, CornerRadiusTopRight = 7, CornerRadiusBottomLeft = 7, CornerRadiusBottomRight = 7 });
        var t = Text($"{now:N0}/{most:N0}", new Color(0.85f, 0.85f, 0.85f), HorizontalAlignment.Center);
        t.VerticalAlignment = VerticalAlignment.Center;
        t.SetAnchorsPreset(Control.LayoutPreset.FullRect);
        bar.AddChild(t);
        return bar;
    }

    private static Control Banded(Control inside, bool picked, Action? click)
    {
        var p = new PanelContainer { MouseFilter = click != null ? Control.MouseFilterEnum.Stop : Control.MouseFilterEnum.Ignore };
        p.AddThemeStyleboxOverride("panel", new StyleBoxFlat { BgColor = picked ? BandPicked : Band, ContentMarginLeft = 4, ContentMarginRight = 4 });
        p.AddChild(inside);
        if (click != null) p.GuiInput += e => { if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true }) { p.AcceptEvent(); click(); } };
        return p;
    }

    private static Control Line() => new ColorRect { Color = GoldLine, CustomMinimumSize = new Vector2(0, 3), MouseFilter = Control.MouseFilterEnum.Ignore };

    private static GridContainer Grid(int columns, params Control[] cs)
    {
        var g = new GridContainer { Columns = columns, SizeFlagsHorizontal = Control.SizeFlags.ExpandFill };
        g.AddThemeConstantOverride("h_separation", 6); g.AddThemeConstantOverride("v_separation", 4);
        foreach (var c in cs) g.AddChild(c);
        return g;
    }

    private static Control Gap(float h) => new Control { CustomMinimumSize = new Vector2(0, h), MouseFilter = Control.MouseFilterEnum.Ignore };

    /// <summary>The fellowship page (on a server): making one, or the one you're in.</summary>
    public static void Fellowship(VBoxContainer box, Net.NetGame net, Func<Objects.ObjectStreamer.Selectable?> selected, Action refresh)
    {
        box.AddThemeConstantOverride("separation", 1);
        if (net.FellowshipName.Length == 0)
        {
            var say = SidePanel.Line("You do not belong to a fellowship.\n\nTo create a fellowship, enter a name in the box below, then click Create Fellowship. Once you've created a fellowship, you can start recruiting members.", null, HorizontalAlignment.Center);
            box.AddChild(say);
            box.AddChild(Gap(8));
            box.AddChild(Text("Fellowship Name:"));
            var name = new LineEdit { Text = _fellowName, MaxLength = 32 };
            name.TextChanged += t => _fellowName = t;
            name.TextSubmitted += t => { _fellowName = t; net.CreateFellowship(_fellowName, _shareXp); };
            box.AddChild(name);
            box.AddChild(Gap(4));
            box.AddChild(Grid(2, Button(_shareXp ? "Share XP: Yes" : "Share XP: No", () => { _shareXp = !_shareXp; refresh(); }), Button("Create Fellowship", () => net.CreateFellowship(_fellowName, _shareXp))));
            return;
        }
        if (_pickedFellow != 0 && net.Fellows.All(f => f.Id != _pickedFellow)) _pickedFellow = 0;
        box.AddChild(Text(net.FellowshipName, new Color(0.95f, 0.95f, 0.95f), HorizontalAlignment.Center));
        var head = new HBoxContainer();
        head.AddChild(Text("FELLOW"));
        head.AddChild(Text("LVL", null, HorizontalAlignment.Right));
        box.AddChild(head);
        foreach (var f in net.Fellows)
        {
            uint id = f.Id;
            var top = new HBoxContainer();
            var who = Text(f.Name, id == net.FellowLeader ? RetailTheme.Gold : new Color(0.9f, 0.9f, 0.9f));
            who.SizeFlagsStretchRatio = 3f;
            top.AddChild(who);
            top.AddChild(Text($"{f.Level:N0}", new Color(0.9f, 0.9f, 0.9f), HorizontalAlignment.Right));
            box.AddChild(Banded(top, id == _pickedFellow, () => { _pickedFellow = _pickedFellow == id ? 0 : id; refresh(); }));
            var bars = new HBoxContainer();
            bars.AddThemeConstantOverride("separation", 3);
            bars.AddChild(Bar(f.Health, f.MaxHealth, new Color(0.85f, 0.08f, 0.08f)));
            bars.AddChild(Bar(f.Stamina, f.MaxStamina, new Color(0.88f, 0.62f, 0.05f)));
            bars.AddChild(Bar(f.Mana, f.MaxMana, new Color(0.1f, 0.4f, 0.95f)));
            box.AddChild(bars);
        }
        box.AddChild(Gap(10));
        bool lead = net.LeadsFellowship;
        bool other = _pickedFellow != 0 && _pickedFellow != net.FellowLeader;
        // the six buttons, as the game sets them out: Leader, Quit, Open over Recruit, Dismiss, Disband
        box.AddChild(Grid(3,
            Button("Leader", () => { net.FellowLeaderTo(_pickedFellow); }, lead && other),
            Button("Quit", () => net.QuitFellowship(false), true, red: true),
            Button(net.FellowshipOpen ? "Close" : "Open", () => { net.FellowOpenness(!net.FellowshipOpen); refresh(); }, lead),
            Button("Recruit", () => { if (selected() is { } who) net.RecruitFellow(who); }),
            Button("Dismiss", () => { net.DismissFellow(_pickedFellow); }, lead && other),
            Button("Disband", () => net.QuitFellowship(true), lead)));
    }

    private static uint _pickedVassal;

    /// <summary>The allegiance page, laid out as the game's: your allegiance as the server tells it (asked for as the page opens).</summary>
    public static void Allegiance(VBoxContainer box, Net.NetGame? net, Func<Objects.ObjectStreamer.Selectable?> selected, Action refresh, Action<string> say)
    {
        box.AddThemeConstantOverride("separation", 2);
        net?.AskAllegiance();
        bool inOne = net != null && net.AllegianceName.Length > 0 && net.Monarch != null;
        if (net != null && _pickedVassal != 0 && net.Vassals.All(v => v.Id != _pickedVassal)) _pickedVassal = 0;
        box.AddChild(Text(inOne ? net!.AllegianceName : "No Allegiance", new Color(0.95f, 0.95f, 0.95f), HorizontalAlignment.Center));
        var top = new HBoxContainer();
        top.AddChild(Text($"Followers: {(inOne ? net!.AllegianceFollowers : 0):N0}"));
        top.AddChild(Text(inOne ? $"Rank: {net!.AllegianceRank}" : "Rank: -"));
        box.AddChild(top);
        box.AddChild(Line());
        box.AddChild(Text("MONARCH", RetailTheme.Dim));
        box.AddChild(Text(inOne ? net!.Monarch!.Name : "-", inOne ? (net!.Monarch!.Online ? new Color(0.95f, 0.95f, 0.95f) : RetailTheme.Dim) : RetailTheme.Dim));
        box.AddChild(Text(inOne ? $"Followers: {Math.Max(0, net!.AllegianceMembers - 1):N0}" : "Followers: -", RetailTheme.Dim));
        box.AddChild(Line());
        var patron = new HBoxContainer();
        patron.AddChild(Text("PATRON", RetailTheme.Dim)); patron.AddChild(Text("XP Produced", null, HorizontalAlignment.Right));
        box.AddChild(patron);
        var pat = inOne ? net!.Patron : null;
        if (pat != null)
        {
            var row = new HBoxContainer();
            row.AddChild(Text(pat.Name, pat.Online ? new Color(0.95f, 0.95f, 0.95f) : RetailTheme.Dim));
            row.AddChild(Text($"{net!.AllegianceSelf?.XpGenerated ?? 0:N0}", null, HorizontalAlignment.Right));
            box.AddChild(row);
        }
        else box.AddChild(Text("-", RetailTheme.Dim));
        box.AddChild(Line());
        var vassals = new HBoxContainer();
        vassals.AddChild(Text("VASSALS")); vassals.AddChild(Text("XP Produced", null, HorizontalAlignment.Right));
        box.AddChild(vassals);
        if (inOne)
            foreach (var v in net!.Vassals)
            {
                uint id = v.Id;
                var row = new HBoxContainer();
                var who = Text(v.Name, v.Online ? new Color(0.95f, 0.95f, 0.95f) : RetailTheme.Dim);
                who.SizeFlagsStretchRatio = 2f;
                row.AddChild(who);
                row.AddChild(Text($"{v.XpGenerated:N0}", null, HorizontalAlignment.Right));
                box.AddChild(Banded(row, id == _pickedVassal, () => { _pickedVassal = _pickedVassal == id ? 0 : id; refresh(); }));
            }
        box.AddChild(Gap(10));
        if (net == null) box.AddChild(SidePanel.Line("You're playing offline.", RetailTheme.Dim, HorizontalAlignment.Center));
        box.AddChild(Gap(6));
        // Swear: to the player selected. Break: with the vassal picked here, else from your patron. Boot: the monarch's.
        var picked = inOne ? net!.Vassals.FirstOrDefault(v => v.Id == _pickedVassal) : null;
        bool monarch = inOne && net!.Monarch!.Id == net.AllegianceSelf?.Id;
        box.AddChild(Grid(3,
            Button("Swear", () =>
            {
                if (selected() is not { Remote: true } to || net!.Swear(to) != true) say("Select the player to swear allegiance to first.");
            }, net != null && pat == null && !(inOne && !monarch)),
            Button("Break", () => { net!.BreakAllegiance(picked?.Id ?? pat!.Id); _pickedVassal = 0; }, net != null && (picked != null || pat != null), red: true),
            Button("Boot", () => { net!.BootFromAllegiance(picked!.Name); _pickedVassal = 0; }, monarch && picked != null)));
    }

    private static uint _pickedContract;
    private static readonly Color Green = new(0.1f, 0.85f, 0.2f), Value = new(0.85f, 0.7f, 0.3f);

    /// <summary>What the game's files say of a contract: its name and what to do, who gives it and where, and where it's done.</summary>
    public readonly record struct ContractText(string Name, string About, string Progress, string Contact, string ContactAt, string QuestAt);

    // "Label:  value", the value in the game's gold
    private static Control Pair(string label, string value)
    {
        var row = new HBoxContainer();
        row.AddThemeConstantOverride("separation", 8);
        var l = Text(label); l.SizeFlagsHorizontal = Control.SizeFlags.ShrinkBegin; l.ClipText = false;
        var v = Text(value, Value); v.ClipText = true;
        row.AddChild(l); row.AddChild(v);
        return row;
    }

    /// <summary>
    /// The contracts you hold (on a server), as the game lists them: Contract and Status in green over the names, the
    /// picked one lit grey with its status, contact and places, what to do and its timer under the list, and Abandon.
    /// </summary>
    public static void Contracts(VBoxContainer box, Net.NetGame net, Func<uint, ContractText?> lookUp, Action refresh)
    {
        box.AddThemeConstantOverride("separation", 0);
        if (_pickedContract != 0 && !net.Contracts.ContainsKey(_pickedContract)) _pickedContract = 0;
        long now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        static string State(Net.NetGame.Contract c) => c.Stage switch { 1 => "Available", 2 => "In Progress", 3 => "Done", _ => "Stage " + c.Stage };
        var head = new HBoxContainer();
        var hc = Text("Contract", Green); hc.SizeFlagsStretchRatio = 1.5f;
        head.AddChild(hc);
        head.AddChild(Text("Status", Green));
        box.AddChild(head);
        box.AddChild(Gap(3));
        foreach (var c in net.Contracts.Values.OrderBy(c => lookUp(c.Id)?.Name ?? ""))
        {
            uint id = c.Id;
            var row = new HBoxContainer();
            var name = Text(lookUp(id)?.Name ?? $"Contract {id}", new Color(0.88f, 0.88f, 0.88f));
            name.SizeFlagsStretchRatio = 1.5f;
            row.AddChild(name);
            row.AddChild(Text(State(c), new Color(0.88f, 0.88f, 0.88f)));
            var p = new PanelContainer { MouseFilter = Control.MouseFilterEnum.Stop };
            p.AddThemeStyleboxOverride("panel", new StyleBoxFlat { BgColor = id == _pickedContract ? new Color(0.32f, 0.32f, 0.32f, 0.9f) : new Color(0, 0, 0, 0), ContentMarginLeft = 6, ContentMarginRight = 2 });
            p.AddChild(row);
            p.GuiInput += e => { if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true }) { p.AcceptEvent(); _pickedContract = _pickedContract == id ? 0 : id; refresh(); } };
            box.AddChild(p);
        }
        if (net.Contracts.Count == 0) box.AddChild(SidePanel.Line("You have no active contracts.", RetailTheme.Dim, HorizontalAlignment.Center));
        box.AddChild(Gap(14));
        // the picked one, under the list
        if (_pickedContract == 0 || !net.Contracts.TryGetValue(_pickedContract, out var picked)) return;
        var info = lookUp(_pickedContract);
        box.AddChild(Pair("Status:", State(picked)));
        if (info is { } i)
        {
            if (i.Contact.Length > 0) box.AddChild(Pair("Contact:", i.Contact));
            if (i.ContactAt.Length > 0) box.AddChild(Pair("Contact Location:", i.ContactAt));
            if (i.QuestAt.Length > 0) box.AddChild(Pair("Quest Location:", i.QuestAt));
            string about = picked.Stage >= 2 && i.Progress.Length > 0 ? i.Progress : i.About;
            if (about.Length > 0) { box.AddChild(Gap(4)); box.AddChild(SidePanel.Line(about, new Color(0.88f, 0.88f, 0.88f))); }
        }
        box.AddChild(Gap(10));
        var foot = new HBoxContainer();
        long left = picked.Stage == 3 ? picked.Repeats - now : picked.Done - now;
        foot.AddChild(Pair("Timed:", left > 0 && left < 400L * 86400 ? Span(left) : "None"));
        uint which = _pickedContract;
        var abandon = new Label { Text = "Abandon", MouseFilter = Control.MouseFilterEnum.Stop, MouseDefaultCursorShape = Control.CursorShape.PointingHand };
        abandon.AddThemeColorOverride("font_color", Green);
        abandon.GuiInput += e => { if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true }) { abandon.AcceptEvent(); net.AbandonContract(which); } };
        foot.AddChild(abandon);
        box.AddChild(foot);
    }

    // ── the journal: pages of your own notes (a title, a label, the notes, a place and a timer), kept on this PC by
    //    character (user://journal.json) - and the page list that indexes them ──
    public sealed class JournalPage
    {
        public string Title { get; set; } = "New Quest";
        public string Label { get; set; } = "";
        public string Notes { get; set; } = "";
        public string Location { get; set; } = "";
        public long TimerEnds { get; set; }           // unix seconds (0: none)
        public int Days { get; set; }
        public int Hours { get; set; }
        public int Minutes { get; set; }
    }
    private static System.Collections.Generic.Dictionary<string, System.Collections.Generic.List<JournalPage>>? _journals;
    private static int _page, _pickedPage = -1;
    private static string _search = "";
    /// <summary>The journal page is the one showing (it's being typed in: nothing else redraws the panel under it).</summary>
    public static bool JournalShowing;
    private const string JournalFile = "user://journal.json";
    // (on the panel's own dark backing, in its light text: brown ink on parchment couldn't be read in the game's font)
    private static readonly Color Parchment = new(0f, 0f, 0f, 0f), InkBrown = new(0.88f, 0.88f, 0.88f);
    private static StyleBoxFlat Dark(bool lit) => new() { BgColor = new Color(0.07f, 0.06f, 0.05f, 0.9f), BorderColor = lit ? new Color(0.78f, 0.6f, 0.26f) : new Color(0.4f, 0.32f, 0.15f), BorderWidthLeft = 1, BorderWidthRight = 1, BorderWidthTop = 1, BorderWidthBottom = 1, ContentMarginLeft = 4, ContentMarginRight = 4, ContentMarginTop = 2, ContentMarginBottom = 2 };

    private static System.Collections.Generic.List<JournalPage> Pages(string who)
    {
        if (_journals == null)
        {
            _journals = new();
            try
            {
                using var f = FileAccess.Open(JournalFile, FileAccess.ModeFlags.Read);
                if (f != null) _journals = System.Text.Json.JsonSerializer.Deserialize<System.Collections.Generic.Dictionary<string, System.Collections.Generic.List<JournalPage>>>(f.GetAsText()) ?? new();
            }
            catch (Exception ex) { GD.PushWarning("journal: " + ex.Message); }
        }
        if (!_journals.TryGetValue(who, out var list)) _journals[who] = list = new();
        return list;
    }

    private static void SaveJournal()
    {
        try
        {
            using var f = FileAccess.Open(JournalFile, FileAccess.ModeFlags.Write);
            f?.StoreString(System.Text.Json.JsonSerializer.Serialize(_journals, new System.Text.Json.JsonSerializerOptions { WriteIndented = true }));
        }
        catch (Exception ex) { GD.PushWarning("journal save: " + ex.Message); }
    }

    private static string TimerOf(JournalPage p)
    {
        if (p.TimerEnds == 0) return "None";
        long left = p.TimerEnds - DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        return left <= 0 ? "Done" : left >= 86400 ? $"{left / 86400}d {left % 86400 / 3600}h" : left >= 3600 ? $"{left / 3600}h {left % 3600 / 60}m" : $"{left / 60}m {left % 60}s";
    }

    // a word to click, in the game's green
    private static Label Word(string text, Action press, bool enabled = true)
    {
        var l = new Label { Text = text, MouseFilter = enabled ? Control.MouseFilterEnum.Stop : Control.MouseFilterEnum.Ignore, MouseDefaultCursorShape = Control.CursorShape.PointingHand };
        l.AddThemeColorOverride("font_color", enabled ? Green : new Color(0.15f, 0.4f, 0.18f));
        if (enabled) l.GuiInput += e => { if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true }) { l.AcceptEvent(); press(); } };
        return l;
    }

    private static LineEdit Field(string text, Action<string> changed, float width = 0)
    {
        var e = new LineEdit { Text = text, SizeFlagsHorizontal = width > 0 ? Control.SizeFlags.ShrinkBegin : Control.SizeFlags.ExpandFill, CustomMinimumSize = new Vector2(width, 0), ContextMenuEnabled = false };
        e.AddThemeStyleboxOverride("normal", Dark(false));
        e.AddThemeStyleboxOverride("focus", Dark(true));
        e.AddThemeColorOverride("font_color", InkBrown); e.AddThemeColorOverride("caret_color", InkBrown);
        e.TextChanged += t => changed(t);
        return e;
    }

    private static Label Brown(string s) { var l = Text(s, InkBrown); l.SizeFlagsHorizontal = Control.SizeFlags.ShrinkBegin; l.ClipText = false; return l; }

    /// <summary>The journal: one page of your notes on parchment - New, its label and title, the notes, a place recorded, a timer, and the way through the pages.</summary>
    public static void Journal(VBoxContainer box, string who, Func<string> where, Action refresh)
    {
        var pages = Pages(who);
        if (pages.Count == 0) { pages.Add(new JournalPage()); SaveJournal(); }
        _page = Math.Clamp(_page, 0, pages.Count - 1);
        var pg = pages[_page];
        box.AddThemeConstantOverride("separation", 0);
        var sheet = new PanelContainer { SizeFlagsHorizontal = Control.SizeFlags.ExpandFill };
        sheet.AddThemeStyleboxOverride("panel", new StyleBoxFlat { BgColor = Parchment, ContentMarginLeft = 2, ContentMarginRight = 2, ContentMarginTop = 2, ContentMarginBottom = 2 });
        var v = new VBoxContainer();
        v.AddThemeConstantOverride("separation", 3);
        sheet.AddChild(v);
        box.AddChild(sheet);

        var top = new HBoxContainer();
        top.AddThemeConstantOverride("separation", 8);
        top.AddChild(Word("New", () => { pages.Add(new JournalPage { Title = "New Quest" + (pages.Count > 0 ? " " + (pages.Count + 1) : "") }); _page = pages.Count - 1; SaveJournal(); refresh(); }));
        top.AddChild(Brown("Label:"));
        top.AddChild(Field(pg.Label, t => { pg.Label = t; SaveJournal(); }));
        v.AddChild(top);
        var title = new HBoxContainer();
        title.AddChild(Brown("Title:"));
        title.AddChild(Field(pg.Title, t => { pg.Title = t; SaveJournal(); }));
        v.AddChild(title);
        v.AddChild(Brown("Notes:"));
        var notes = new TextEdit { Text = pg.Notes, CustomMinimumSize = new Vector2(0, 300), WrapMode = TextEdit.LineWrappingMode.Boundary, ContextMenuEnabled = false, SizeFlagsHorizontal = Control.SizeFlags.ExpandFill };
        notes.AddThemeStyleboxOverride("normal", Dark(false));
        notes.AddThemeStyleboxOverride("focus", Dark(true));
        notes.AddThemeColorOverride("font_color", InkBrown); notes.AddThemeColorOverride("caret_color", InkBrown);
        notes.TextChanged += () => { pg.Notes = notes.Text; SaveJournal(); };
        v.AddChild(notes);

        var loc = new HBoxContainer();
        loc.AddThemeConstantOverride("separation", 6);
        loc.AddChild(Brown("Location:"));
        var at = Text(pg.Location.Length > 0 ? pg.Location : "None", InkBrown);
        loc.AddChild(at);
        loc.AddChild(Word("Record", () => { pg.Location = where(); SaveJournal(); refresh(); }));
        v.AddChild(loc);

        var timer = new HBoxContainer();
        timer.AddThemeConstantOverride("separation", 3);
        timer.AddChild(Brown("Timer:"));
        timer.AddChild(Field(pg.Days.ToString(), t => { pg.Days = int.TryParse(t, out int d) ? Math.Clamp(d, 0, 999) : 0; SaveJournal(); }, 30)); timer.AddChild(Brown("d"));
        timer.AddChild(Field(pg.Hours.ToString(), t => { pg.Hours = int.TryParse(t, out int h) ? Math.Clamp(h, 0, 23) : 0; SaveJournal(); }, 26)); timer.AddChild(Brown("h"));
        timer.AddChild(Field(pg.Minutes.ToString(), t => { pg.Minutes = int.TryParse(t, out int m) ? Math.Clamp(m, 0, 59) : 0; SaveJournal(); }, 26)); timer.AddChild(Brown("m"));
        var left = Text(pg.TimerEnds != 0 ? TimerOf(pg) : "", InkBrown, HorizontalAlignment.Right);
        timer.AddChild(left);
        timer.AddChild(pg.TimerEnds != 0
            ? Word("Stop", () => { pg.TimerEnds = 0; SaveJournal(); refresh(); })
            : Word("Start", () => { long secs = pg.Days * 86400L + pg.Hours * 3600L + pg.Minutes * 60L; if (secs > 0) { pg.TimerEnds = DateTimeOffset.UtcNow.ToUnixTimeSeconds() + secs; SaveJournal(); refresh(); } }));
        v.AddChild(timer);

        var nav = new HBoxContainer();
        nav.AddChild(Word("First", () => { _page = 0; refresh(); }, _page > 0));
        nav.AddChild(Word("  <", () => { _page--; refresh(); }, _page > 0));
        nav.AddChild(Text($"- {_page + 1} -", InkBrown, HorizontalAlignment.Center));
        nav.AddChild(Word(">  ", () => { _page++; refresh(); }, _page < pages.Count - 1));
        nav.AddChild(Word("Last", () => { _page = pages.Count - 1; refresh(); }, _page < pages.Count - 1));
        v.AddChild(nav);
    }

    /// <summary>The page list: every journal page by number, with its title, timer and label; a click picks one (again: opens it); Delete, a search, Reset.</summary>
    public static void PageList(VBoxContainer box, string who, Action<int> open, Action refresh)
    {
        var pages = Pages(who);
        box.AddThemeConstantOverride("separation", 0);
        if (_pickedPage >= pages.Count) _pickedPage = -1;
        HBoxContainer Row(string n, string title, string timer, string label, Color c)
        {
            var row = new HBoxContainer();
            row.AddThemeConstantOverride("separation", 4);
            var num = Text(n, c); num.SizeFlagsHorizontal = Control.SizeFlags.ShrinkBegin; num.CustomMinimumSize = new Vector2(22, 0);
            var t = Text(title, c); t.SizeFlagsStretchRatio = 2f;
            row.AddChild(num); row.AddChild(t); row.AddChild(Text(timer, c)); row.AddChild(Text(label, c));
            return row;
        }
        box.AddChild(Row("#", "Title", "Timer", "Label", Green));
        box.AddChild(Gap(3));
        string find = _search.Trim();
        int shown = 0;
        for (int n = 0; n < pages.Count; n++)
        {
            var pg = pages[n];
            if (find.Length > 0 && !(pg.Title + "\n" + pg.Label + "\n" + pg.Notes).Contains(find, StringComparison.OrdinalIgnoreCase)) continue;
            shown++;
            int at = n;
            var p = new PanelContainer { MouseFilter = Control.MouseFilterEnum.Stop };
            p.AddThemeStyleboxOverride("panel", new StyleBoxFlat { BgColor = at == _pickedPage ? new Color(0.32f, 0.32f, 0.32f, 0.9f) : new Color(0, 0, 0, 0), ContentMarginLeft = 6, ContentMarginRight = 2 });
            p.AddChild(Row((n + 1).ToString(), pg.Title, TimerOf(pg), pg.Label, new Color(0.88f, 0.88f, 0.88f)));
            p.GuiInput += e =>
            {
                if (e is not InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true } mb) return;
                p.AcceptEvent();
                // (a double click, or a click on the one already picked: its page in the journal)
                if (mb.DoubleClick || _pickedPage == at) { _page = at; open(at); return; }
                _pickedPage = at; refresh();
            };
            box.AddChild(p);
        }
        if (shown == 0) box.AddChild(SidePanel.Line(pages.Count == 0 ? "Your journal has no pages yet (New, on the Journal tab)." : "No page has that in it.", RetailTheme.Dim, HorizontalAlignment.Center));
        box.AddChild(Gap(12));
        var foot = new HBoxContainer();
        foot.AddThemeConstantOverride("separation", 8);
        foot.AddChild(Word("Delete", () => { if (_pickedPage >= 0 && _pickedPage < pages.Count) { pages.RemoveAt(_pickedPage); _pickedPage = -1; _page = Math.Min(_page, Math.Max(0, pages.Count - 1)); SaveJournal(); refresh(); } }, _pickedPage >= 0));
        var sl = new Label { Text = "Search:" }; sl.AddThemeColorOverride("font_color", Green);
        foot.AddChild(sl);
        var search = new LineEdit { Text = _search, SizeFlagsHorizontal = Control.SizeFlags.ExpandFill, ContextMenuEnabled = false };
        search.AddThemeStyleboxOverride("normal", Dark(false)); search.AddThemeStyleboxOverride("focus", Dark(true));
        search.TextSubmitted += t => { _search = t; refresh(); };
        search.TextChanged += t => _search = t;
        foot.AddChild(search);
        foot.AddChild(Word("Reset", () => { _search = ""; _pickedPage = -1; refresh(); }));
        box.AddChild(foot);
    }

    private static string Span(long secs) => secs >= 86400 ? $"{secs / 86400}d {secs % 86400 / 3600}h" : secs >= 3600 ? $"{secs / 3600}h {secs % 3600 / 60}m" : $"{Math.Max(1, secs / 60)}m";

    /// <summary>The friends list (on a server): each friend on a band (those in the game brighter), a name to add, Add and Remove.</summary>
    public static void Friends(VBoxContainer box, Net.NetGame net, Action refresh)
    {
        box.AddThemeConstantOverride("separation", 1);
        if (_pickedFriend != 0 && net.Friends.All(f => f.Id != _pickedFriend)) _pickedFriend = 0;
        var head = new HBoxContainer();
        head.AddChild(Text("FRIEND"));
        head.AddChild(Text("STATUS", null, HorizontalAlignment.Right));
        box.AddChild(head);
        foreach (var f in net.Friends.OrderByDescending(f => f.Online).ThenBy(f => f.Name))
        {
            uint id = f.Id;
            var row = new HBoxContainer();
            var who = Text(f.Name, f.Online ? new Color(0.95f, 0.95f, 0.95f) : RetailTheme.Dim);
            who.SizeFlagsStretchRatio = 3f;
            row.AddChild(who);
            row.AddChild(Text(f.Online ? "Online" : "Offline", f.Online ? new Color(0.5f, 1f, 0.5f) : RetailTheme.Dim, HorizontalAlignment.Right));
            box.AddChild(Banded(row, id == _pickedFriend, () => { _pickedFriend = _pickedFriend == id ? 0 : id; refresh(); }));
        }
        if (net.Friends.Count == 0) box.AddChild(SidePanel.Line("Your friends list is empty.", RetailTheme.Dim, HorizontalAlignment.Center));
        box.AddChild(Gap(10));
        box.AddChild(Text("Character Name:"));
        var name = new LineEdit { Text = _friendName, MaxLength = 32 };
        name.TextChanged += t => _friendName = t;
        name.TextSubmitted += t => { net.AddFriend(t); _friendName = ""; refresh(); };
        box.AddChild(name);
        box.AddChild(Gap(4));
        box.AddChild(Grid(2, Button("Add Friend", () => { net.AddFriend(_friendName); _friendName = ""; refresh(); }),
                             Button("Remove", () => { net.RemoveFriend(_pickedFriend); _pickedFriend = 0; }, _pickedFriend != 0, red: true)));
    }
}
