using System;
using Godot;

namespace ACGodot.UI;

/// <summary>
/// The game's selection marks: four small triangles at the corners of what's selected, pointing in at it, in its
/// kind's colour - orange for a monster, yellow for an NPC, white for anything else.
/// </summary>
public partial class SelectionMarks : Control
{
    public Objects.ObjectStreamer? Objects;
    /// <summary>Your own standing: 0 not a player killer, 1 a player killer, 2 PK-lite.</summary>
    public static Func<int>? SelfPk;
    private static readonly Color Monster = new(1f, 0.55f, 0.1f), Npc = new(1f, 0.92f, 0.2f), Thing = new(0.95f, 0.95f, 0.95f);

    public override void _Ready()
    {
        MouseFilter = MouseFilterEnum.Ignore;
        SetAnchorsPreset(LayoutPreset.FullRect);
    }

    public override void _Process(double delta) => QueueRedraw();

    public override void _Draw() { long __fw = ACGodot.FrameWatch.DrawStart(); try { DrawBody(); } finally { ACGodot.FrameWatch.Drew("SelectionMarks", __fw); } }
    private void DrawBody()
    {
        var sel = Objects?.Selected;
        var cam = GetViewport().GetCamera3D();
        if (sel == null || cam == null || sel.Gone || (sel.Node != null && !sel.Node.Visible)) return;
        // its box on screen: the corners of a column from its feet to its top, as wide as it is
        var right = cam.GlobalTransform.Basis.X;
        float r = sel.Radius;
        Vector2 min = new(float.MaxValue, float.MaxValue), max = new(float.MinValue, float.MinValue);
        foreach (float y in new[] { sel.Feet.Y, sel.Top })
            foreach (float s in new[] { -r, r })
            {
                var p = new Vector3(sel.Center.X, y, sel.Center.Z) + right * s;
                if (cam.IsPositionBehind(p)) return;
                var q = cam.UnprojectPosition(p);
                min = min.Min(q); max = max.Max(q);
            }
        // not too small to see round small things
        var mid = (min + max) * 0.5f;
        var half = ((max - min) * 0.5f).Max(new Vector2(10, 10));
        float t = Math.Max(7f, GetViewportRect().Size.Y / 90f);   // sized with the window (1080 high: 12)
        // the triangles sit just outside the box (their points at its corners), so they never cover a far-off creature
        half += new Vector2(t + 2f, t + 2f);
        min = mid - half; max = mid + half;
        bool dead = sel.Fight is Combat.Fighter { St: Combat.Fighter.State.Dead };   // a corpse: a thing, white
        // (yourself: white like any other player - red as a player killer, pink PK-lite)
        bool self = sel.Index == -1 && sel.Lb == (-3, -3);
        int pk = self ? (SelfPk?.Invoke() ?? 0) : 0;
        var c = self ? (pk == 1 ? new Color(1f, 0.15f, 0.15f) : pk == 2 ? new Color(1f, 0.6f, 0.8f) : Thing) : dead ? Thing : sel.Kind == 2 ? Monster : sel.Kind == 1 ? Npc : sel.Kind == 4 ? new Color(1f, 0.15f, 0.15f) : sel.Kind == 5 ? new Color(1f, 0.6f, 0.8f) : Thing;   // (other players: white; player killers red, PK-lite pink)
        Tri(new Vector2(min.X, min.Y), new Vector2(1, 1), t, c);
        Tri(new Vector2(max.X, min.Y), new Vector2(-1, 1), t, c);
        Tri(new Vector2(min.X, max.Y), new Vector2(1, -1), t, c);
        Tri(new Vector2(max.X, max.Y), new Vector2(-1, -1), t, c);
    }

    // a small triangle at a corner, its point toward the middle
    private void Tri(Vector2 at, Vector2 inward, float size, Color c)
    {
        var tip = at + inward * size;
        var a = at + new Vector2(inward.X * size, 0) * 0.15f - new Vector2(0, inward.Y) * size * 0.35f;
        var b = at + new Vector2(0, inward.Y * size) * 0.15f - new Vector2(inward.X, 0) * size * 0.35f;
        var pts = new[] { tip, a, b };
        DrawColoredPolygon(pts, c);
        DrawPolyline(new[] { tip, a, b, tip }, new Color(0, 0, 0, 0.8f), 1f, true);
    }
}
