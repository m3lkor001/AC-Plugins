using System;
using System.Collections.Generic;
using System.Linq;
using Godot;

namespace ACGodot.UI;

/// <summary>
/// Playing on a server: the account's characters, to pick one to enter the world as - shown when the launcher named no
/// character, and after logging out (Options > Log out).
/// </summary>
public partial class CharacterSelect : Combat.GameWindow
{
    /// <summary>Enter the world as this character (its id).</summary>
    public Action<uint>? Enter;
    public Action? Quit;

    public CharacterSelect() : base("Characters", new Vector2(320, 300)) { }

    public void Show(IReadOnlyList<(uint id, string name)> characters, string account)
    {
        foreach (var c in Body.GetChildren()) { Body.RemoveChild(c); c.QueueFree(); }
        var head = new Label { Text = characters.Count > 0 ? $"Account {account}: enter the world as" : $"Account {account} has no characters yet.", HorizontalAlignment = HorizontalAlignment.Center,
                               AutowrapMode = TextServer.AutowrapMode.WordSmart };
        head.AddThemeColorOverride("font_color", RetailTheme.Gold);
        Body.AddChild(head);
        foreach (var (id, name) in characters)
        {
            uint pick = id;
            var b = new Button { Text = name, FocusMode = FocusModeEnum.None, SizeFlagsHorizontal = SizeFlags.ExpandFill };
            b.Pressed += () => { Visible = false; Enter?.Invoke(pick); };
            Body.AddChild(b);
        }
        _list = characters; _account = account;
        var make = new Button { Text = "Create a character", FocusMode = FocusModeEnum.None, SizeFlagsHorizontal = SizeFlags.ExpandFill };
        make.Pressed += () => { if (OpenCreate?.Invoke() == true) Visible = false; else ShowCreate(); };
        Body.AddChild(make);
        Body.AddChild(new HSeparator());
        var exit = new Button { Text = "Exit the game", FocusMode = FocusModeEnum.None, SizeFlagsHorizontal = SizeFlags.ShrinkCenter };
        exit.Pressed += () => Quit?.Invoke();
        Body.AddChild(exit);
        Visible = true;
        FitLater();
    }

    /// <summary>
    /// Tall enough for everything on it (every character, without scrolling) - up to what the screen has room for - and in
    /// the middle of the screen. Measured once the page's buttons are laid out (the frame after they're made).
    /// </summary>
    private void FitLater() { _fitPasses = 2; Callable.From(Fit).CallDeferred(); }
    private int _fitPasses;
    private void Fit()
    {
        if (!IsInstanceValid(this) || !IsInsideTree()) return;
        var screen = GetViewportRect().Size;
        float need = Body.GetCombinedMinimumSize().Y + 8;
        float h = Math.Clamp(need, 120f, Math.Max(120f, screen.Y - 100f));
        Scroll.CustomMinimumSize = new Vector2(Scroll.CustomMinimumSize.X, h);
        CustomMinimumSize = new Vector2(CustomMinimumSize.X, h + 40);
        Size = CustomMinimumSize;
        Position = ((screen - Size) * 0.5f).Max(Vector2.Zero);
        // (once more next frame: labels that wrap only know their height once they've been laid out at their width)
        if (--_fitPasses > 0) Callable.From(Fit).CallDeferred();
    }

    private IReadOnlyList<(uint id, string name)> _list = Array.Empty<(uint, string)>();
    private string _account = "";
    private Label? _note;
    private Button? _go;

    /// <summary>The game's data files: the heritages, professions and towns a new character is made from.</summary>
    public Dats? Dats;
    /// <summary>The game's own creation screen (CharGen): opened instead of the short form here; false if it couldn't be.</summary>
    public Func<bool>? OpenCreate;
    /// <summary>Ask the server for this character; false if it couldn't be asked.</summary>
    public Func<Net.NewCharacter, bool>? Create;

    /// <summary>The server said no to the character asked for: why, on the form.</summary>
    public void CreateFailed(string why)
    {
        if (_note != null && IsInstanceValid(_note)) { _note.Text = why; _note.AddThemeColorOverride("font_color", new Color(1f, 0.55f, 0.45f)); }
        if (_go != null && IsInstanceValid(_go)) _go.Disabled = false;
    }

    // a short form: heritage, sex, profession, town, name. The looks are picked for you (there's no dressing room here yet)
    private void ShowCreate()
    {
        foreach (var c in Body.GetChildren()) { Body.RemoveChild(c); c.QueueFree(); }
        var head = new Label { Text = "A new character", HorizontalAlignment = HorizontalAlignment.Center };
        head.AddThemeColorOverride("font_color", RetailTheme.Gold);
        Body.AddChild(head);
        DatReaderWriter.DBObjs.CharGen? gen = null;
        DatReaderWriter.DBObjs.SkillTable? skills = null;
        try { gen = Dats?.Portal<DatReaderWriter.DBObjs.CharGen>(0x0E000002); skills = Dats?.Portal<DatReaderWriter.DBObjs.SkillTable>(Combat.Character.SkillTableId); } catch { }
        void BackButton()
        {
            var back = new Button { Text = "Back", FocusMode = FocusModeEnum.None, SizeFlagsHorizontal = SizeFlags.ShrinkCenter };
            back.Pressed += () => Show(_list, _account);
            Body.AddChild(back);
        }
        if (gen == null || skills == null || gen.HeritageGroups.Count == 0)
        {
            Body.AddChild(new Label { Text = "The game's data files don't have what a new character is made from.", AutowrapMode = TextServer.AutowrapMode.WordSmart });
            BackButton();
            return;
        }
        OptionButton Row(string label)
        {
            var row = new HBoxContainer();
            row.AddChild(new Label { Text = label, CustomMinimumSize = new Vector2(84, 0) });
            var o = new OptionButton { FocusMode = FocusModeEnum.None, SizeFlagsHorizontal = SizeFlags.ExpandFill };
            row.AddChild(o);
            Body.AddChild(row);
            return o;
        }
        var heritage = Row("Heritage"); var sex = Row("Sex"); var job = Row("Profession"); var town = Row("Start in");
        // (the Olthoi are a different game - servers mostly keep them off)
        var groups = new List<(uint id, DatReaderWriter.Types.HeritageGroupCG g)>();
        foreach (var kv in gen.HeritageGroups)
            if (kv.Value.Genders.Count > 0 && kv.Value.Templates.Count > 0 && !kv.Value.Name.Value.Contains("Olthoi", StringComparison.OrdinalIgnoreCase)) groups.Add((kv.Key, kv.Value));
        groups.Sort((a, b) => a.id.CompareTo(b.id));
        foreach (var (_, g) in groups) heritage.AddItem(g.Name.Value);
        for (int i = 0; i < gen.StartingAreas.Count; i++)
            if (!gen.StartingAreas[i].Name.Value.Contains("Olthoi", StringComparison.OrdinalIgnoreCase)) { town.AddItem(gen.StartingAreas[i].Name.Value); town.SetItemMetadata(town.ItemCount - 1, i); }
        void Fill()
        {
            var g = groups[Math.Max(0, heritage.Selected)].g;
            string keepJob = job.Selected >= 0 ? job.GetItemText(job.Selected) : "";
            int keepSex = sex.Selected >= 0 ? (int)sex.GetItemMetadata(sex.Selected) : 1;
            sex.Clear(); job.Clear();
            foreach (var kv in g.Genders.OrderBy(k => k.Key)) { sex.AddItem(kv.Value.Name.Value); sex.SetItemMetadata(sex.ItemCount - 1, kv.Key); if (kv.Key == keepSex) sex.Select(sex.ItemCount - 1); }
            for (int i = 0; i < g.Templates.Count; i++)
            {
                var t = g.Templates[i];
                if (t.NormalSkills.Count + t.PrimarySkills.Count == 0) continue;   // (the "make your own" one: nothing picked in it)
                job.AddItem(t.Name.Value); job.SetItemMetadata(job.ItemCount - 1, i);
                if (t.Name.Value == keepJob) job.Select(job.ItemCount - 1);
            }
        }
        if (groups.Count == 0) { Body.AddChild(new Label { Text = "The data files list no heritages." }); BackButton(); return; }
        heritage.Select(0);
        Fill();
        heritage.ItemSelected += _ => Fill();
        var nameRow = new HBoxContainer();
        nameRow.AddChild(new Label { Text = "Name", CustomMinimumSize = new Vector2(84, 0) });
        var name = new LineEdit { SizeFlagsHorizontal = SizeFlags.ExpandFill, MaxLength = 32, PlaceholderText = "letters, spaces, ' and -" };
        nameRow.AddChild(name);
        Body.AddChild(nameRow);
        _note = new Label { Text = "Face, hair and clothes are picked for you.", AutowrapMode = TextServer.AutowrapMode.WordSmart };
        _note.AddThemeColorOverride("font_color", RetailTheme.Dim);
        _note.AddThemeFontSizeOverride("font_size", 12);
        Body.AddChild(_note);
        _go = new Button { Text = "Create", FocusMode = FocusModeEnum.None, SizeFlagsHorizontal = SizeFlags.ExpandFill };
        var note = _note; var go = _go;
        void Fail(string why) { note.Text = why; note.AddThemeColorOverride("font_color", new Color(1f, 0.55f, 0.45f)); }
        go.Pressed += () =>
        {
            string n = name.Text.Trim();
            if (n.Length < 3) { Fail("The name needs at least three letters."); return; }
            if (!n.All(ch => char.IsAsciiLetter(ch) || ch is ' ' or '\'' or '-') || !char.IsAsciiLetter(n[0])) { Fail("Names are letters, spaces, ' and - (starting with a letter)."); return; }
            if (job.Selected < 0 || sex.Selected < 0 || town.Selected < 0) { Fail("Pick a profession, a sex and a town."); return; }
            var (hid, g) = groups[heritage.Selected];
            int sexId = (int)sex.GetItemMetadata(sex.Selected);
            var look = g.Genders[sexId];
            int ti = (int)job.GetItemMetadata(job.Selected);
            var t = g.Templates[ti];
            var rng = new Random();
            uint Any(int count) => count > 0 ? (uint)rng.Next(count) : 0u;
            uint Colour() => look.ClothingColors.Count > 0 ? look.ClothingColors[rng.Next(look.ClothingColors.Count)] : 0u;
            var c = new Net.NewCharacter
            {
                Name = n, Heritage = hid, Gender = (uint)sexId, Template = ti, StartArea = (uint)(int)town.GetItemMetadata(town.Selected),
                Attributes = new[] { (uint)t.Strength, (uint)t.Endurance, (uint)t.Coordination, (uint)t.Quickness, (uint)t.Focus, (uint)t.Self },
                Eyes = Any(look.EyeStrips.Count), Nose = Any(look.NoseStrips.Count), Mouth = Any(look.MouthStrips.Count),
                HairColor = Any(look.HairColors.Count), EyeColor = Any(look.EyeColors.Count), HairStyle = Any(look.HairStyles.Count),
                Shirt = Any(look.Shirts.Count), ShirtColor = Colour(), Pants = Any(look.Pants.Count), PantsColor = Colour(), Shoes = Any(look.Footwear.Count), ShoesColor = Colour(),
                SkinHue = rng.NextDouble(), HairHue = rng.NextDouble(), ShirtHue = rng.NextDouble(), PantsHue = rng.NextDouble(), ShoesHue = rng.NextDouble(),
            };
            // every skill the game has starts untrained; the profession's are trained or specialized
            foreach (var kv in skills.Skills) { int id = (int)kv.Key; if (id > 0 && id < c.Skills.Length && kv.Value.ChargenUse) c.Skills[id] = 1; }
            foreach (var sk in t.NormalSkills) if ((int)sk > 0 && (int)sk < c.Skills.Length) c.Skills[(int)sk] = 2;
            foreach (var sk in t.PrimarySkills) if ((int)sk > 0 && (int)sk < c.Skills.Length) c.Skills[(int)sk] = 3;
            if (Create?.Invoke(c) != true) { Fail("Not connected to the server."); return; }
            note.Text = $"Asking the server for {n}...";
            note.AddThemeColorOverride("font_color", RetailTheme.Dim);
            go.Disabled = true;
        };
        Body.AddChild(go);
        BackButton();
        FitLater();
    }
}
