using Godot;
using System;
using System.Collections.Generic;
using System.Linq;
using ACGodot.Combat;

namespace ACGodot.UI;

/// <summary>
/// A vendor's window (on a server), as the game's: three tabs, each one row of things. Buy - their wares of one kind
/// (the drop-down picks the kind), with Buy (the picked one, now) and Add to List; Buy List - what's been added, with
/// Buy Selected and Buy All; Sell - what of yours is to be sold (dropped on any of the rows) and what you'd get, with Sell.
/// </summary>
public partial class VendorWindow : GameWindow
{
    public Func<uint, Texture2D?> Icon = _ => null;
    public Inventory? Inv;
    public Action<uint, List<(Item item, int amount)>>? Buy, Sell;
    public Action<Item>? Identify;
    /// <summary>A thing clicked here (a ware, or one of yours on the sell row): it's the one chosen.</summary>
    public Action<Item?>? Picked;

    private Net.NetGame.VendorInfo? _v;
    private readonly List<(Item item, int amount)> _buying = new(), _selling = new();
    private int _tab;            // 0 buy, 1 the buy list, 2 sell
    private int _kind;           // the kind of ware shown (an ItemType bit; 0: the first there is)
    private Item? _picked;
    private int _amount = 1;
    private const int Across = 12;

    private static readonly Vector2 Least = new(470, 190);
    private int _across = Across;
    private int _waresAt;        // how far down the wares are scrolled (kept as the window is built again)
    private ScrollContainer? _wares;

    public VendorWindow() : base("Vendor", Least)
    {
        Scroll.HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled;
        Scroll.VerticalScrollMode = ScrollContainer.ScrollMode.Disabled;   // (the wares scroll in their own part; the buttons stay put)
        Body.SizeFlagsVertical = SizeFlags.ExpandFill;
        // a grip in the bottom-right corner sizes it: more across in a wider window, more rows in a taller one
        var grip = new Control { CustomMinimumSize = new Vector2(14, 14), MouseDefaultCursorShape = CursorShape.Fdiagsize, MouseFilter = MouseFilterEnum.Stop,
                                 SizeFlagsHorizontal = SizeFlags.ShrinkEnd, SizeFlagsVertical = SizeFlags.ShrinkEnd };
        grip.Draw += () =>
        {
            var c = new Color(0.8f, 0.65f, 0.3f, 0.9f);
            for (int i = 0; i < 3; i++) grip.DrawLine(new Vector2(13, 3 + i * 4), new Vector2(3 + i * 4, 13), c, 1f);
        };
        bool down = false; Vector2 from = Vector2.Zero, start = Vector2.Zero;
        grip.GuiInput += e =>
        {
            if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb)
            {
                down = mb.Pressed && !UiLock.Locked; from = GetGlobalMousePosition(); start = Size;
                if (!mb.Pressed) { var c = new ConfigFile(); global::ACGodot.SafeConfig.Load(c, "user://ui.cfg"); c.SetValue("windows", "size_VendorWindow", Size); global::ACGodot.SafeConfig.Save(c, "user://ui.cfg"); }
                grip.AcceptEvent();
            }
            else if (e is InputEventMouseMotion && down)
            {
                var screen = GetViewportRect().Size;
                var want = start + GetGlobalMousePosition() - from;
                Size = new Vector2(Math.Clamp(want.X, Least.X, Math.Max(Least.X, screen.X - Position.X)), Math.Clamp(want.Y, Least.Y, Math.Max(Least.Y, screen.Y - Position.Y)));
                grip.AcceptEvent();
            }
        };
        AddChild(grip);
        Resized += () => { if (Fit() != _across && Visible) Refresh(); };
    }

    public override void _Ready()
    {
        base._Ready();
        var c = new ConfigFile();
        if (global::ACGodot.SafeConfig.Load(c, "user://ui.cfg") == Error.Ok && c.HasSectionKey("windows", "size_VendorWindow")) Size = ((Vector2)c.GetValue("windows", "size_VendorWindow")).Max(Least);
    }

    // how many squares go across the window as wide as it is
    private int Fit() => Math.Max(Across, (int)((Size.X - 16 - 14 + 2) / 36f));

    /// <summary>What's on the buy list (for /fillcomps to be checked).</summary>
    public IReadOnlyList<(Item item, int amount)> BuyList => _buying;
    /// <summary>Buys all that's on the buy list (Buy All).</summary>
    public void BuyNow() { if (_v != null && _buying.Count > 0) { var all = _buying.ToList(); _buying.Clear(); _picked = null; Buy?.Invoke(_v.Guid, all); Refresh(); } }

    /// <summary>The vendor it's showing (null: none).</summary>
    public Net.NetGame.VendorInfo? Vendor => Visible ? _v : null;
    /// <summary>Whether a thing is one of the wares shown (it can stay chosen though it isn't yours).</summary>
    public bool Has(Item i) => Visible && _v != null && _v.ForSale.Contains(i);

    public void Show(Net.NetGame.VendorInfo v)
    {
        if (_v?.Guid == v.Guid)
        {
            // the same vendor again (after a sale): the lists and the tab stay - the buy list on their wares as now sent
            var keep = _buying.ToList(); _buying.Clear();
            foreach (var (item, amount) in keep) if (v.ForSale.FirstOrDefault(i => i.Wcid == item.Wcid && i.Name == item.Name) is { } now) _buying.Add((now, amount));
            if (_picked != null && _tab != 2) _picked = v.ForSale.FirstOrDefault(i => i.Wcid == _picked.Wcid && i.Name == _picked.Name);
        }
        else { _tab = 0; _kind = 0; _buying.Clear(); _selling.Clear(); _picked = null; _amount = 1; }
        _v = v;
        Title = v.Name;
        Visible = true;
        MoveToFront();
        Refresh();
    }

    // (as the server works it out: for each one, its value at their rate, rounded up, never less than 1; trade notes at 1.15)
    /// <summary>The pyreals the server says are yours (-1 or unset: not told - the packs' are counted).</summary>
    public Func<long>? ServerCoins;
    private int Cost(Item i, int n) => (int)Math.Max(1, Math.Ceiling(i.Value * (double)((i.ItemType & 0x40000) != 0 ? 1.15f : _v?.SellRate ?? 1f) - 0.1)) * n;
    /// <summary>What this vendor is paid in: pyreals, or their own coin by its name.</summary>
    private string Coin => _v is { Currency: not 0 } v ? v.CurrencyName : "pyreals";
    private int Gain(Item i, int n) => (int)Math.Floor(i.Value * (double)(_v?.BuyRate ?? 1f) * n);

    /// <summary>Puts so many of a ware (by its kind) on the buy list; false if they don't sell it.</summary>
    public bool AddToBuy(int wcid, int amount)
    {
        var ware = _v?.ForSale.FirstOrDefault(i => i.Wcid == wcid);
        if (ware == null || amount <= 0) return false;
        Add(_buying, ware, amount);
        Refresh();
        return true;
    }

    /// <summary>One of your things onto the sell row (dropped on the window): the sell tab opens with it.</summary>
    public void AddToSell(Item it, int amount = 0)
    {
        if (_v == null || Inv == null || it.Guid == 0 || !Inv.Pack.Contains(it)) return;
        int n = amount > 0 && amount < it.Stack ? amount : Math.Max(1, it.Stack);
        _selling.RemoveAll(x => x.item == it);
        _selling.Add((it, n));
        _tab = 2; _picked = it; Picked?.Invoke(it);
        Refresh();
    }

    // (dropped anywhere on the window, not just on the row)
    public override bool _CanDropData(Vector2 at, Variant data) =>
        data.VariantType == Variant.Type.String && (string)data == "acgodot-item" && ItemSlot.Dragging is { Guid: not 0 } && ItemSlot.DraggingFrom == "pack";
    public override void _DropData(Vector2 at, Variant data)
    {
        if (ItemSlot.Dragging is { } it) AddToSell(ItemSlot.SplitFrom ?? it, ItemSlot.SplitFrom != null ? it.Stack : ItemSlot.Splitting?.Invoke(it) ?? 0);
        ItemSlot.Dragging = null;
    }

    private static void Add(List<(Item item, int amount)> list, Item it, int n)
    {
        int at = list.FindIndex(x => x.item == it);
        if (at >= 0) list[at] = (it, list[at].amount + n); else list.Add((it, n));
    }

    // the kinds of thing in the drop-down, as the game names them (by the item's type)
    private static readonly (int bits, string name)[] Kinds =
    {
        (0x1, "Melee Weapons"), (0x100, "Missile Weapons"), (0x8000, "Casters"), (0x2, "Armor"), (0x4, "Clothing"), (0x8, "Jewelry"),
        (0x20, "Food"), (0x800, "Gems"), (0x1000, "Spell Components"), (0x80000, "Mana Stones"), (0x2000, "Books and Scrolls"),
        (0x4000, "Keys"), (0x200, "Containers"), (0x40000, "Trade Notes"), (0x100000, "Services"),
        (0x400000 | 0x800000 | 0x1000000 | 0x2000000 | 0x4000000 | 0x8000000, "Crafting"), (0x20000000 | 0x40000000, "Tinkering"),
    };
    private const int Other = -1;
    private static int KindOf(Item i) { foreach (var (bits, _) in Kinds) if ((i.ItemType & bits) != 0) return bits; return Other; }
    private static string KindName(int k) { foreach (var (bits, name) in Kinds) if (bits == k) return name; return "Miscellaneous"; }

    // a row of squares that takes a thing of yours dropped on it (to sell)
    private sealed partial class Row : ItemGrid
    {
        public VendorWindow Win = null!;
        public Row(int columns) : base(columns) { }
        public override bool CanTake(Item? onto) => ItemSlot.Dragging is { Guid: not 0 } && ItemSlot.DraggingFrom == "pack";
        public override void TakeDrop(int index, Item? onto)
        {
            if (ItemSlot.Dragging is { } it) Win.AddToSell(ItemSlot.SplitFrom ?? it, ItemSlot.SplitFrom != null ? it.Stack : ItemSlot.Splitting?.Invoke(it) ?? 0);
            ItemSlot.Dragging = null;
        }
    }

    // the things in rows as wide as the window, scrolled up and down when there are more than fit
    private void AddRow(List<Item> things, Func<Item, int>? count, Action<Item> doubled)
    {
        _across = Fit();
        var row = new Row(_across) { Source = "vendor", Win = this, Count = count, DoubleClicked = doubled };
        int spare = things.Count < _across ? _across - things.Count : (_across - things.Count % _across) % _across;
        row.Fill(things, Icon, i => { _picked = i; _amount = 1; Picked?.Invoke(i); Refresh(); }, _picked, spare);
        if (_wares != null && IsInstanceValid(_wares)) _waresAt = _wares.ScrollVertical;
        var area = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled, VerticalScrollMode = ScrollContainer.ScrollMode.Auto,
                                         SizeFlagsVertical = SizeFlags.ExpandFill, CustomMinimumSize = new Vector2(0, row.Slot + 4) };
        area.AddChild(row);
        Body.AddChild(area);
        _wares = area;
        int at = _waresAt;
        area.Ready += () => area.CallDeferred(ScrollContainer.MethodName.SetVScroll, at);
    }

    public void Refresh()
    {
        if (_v == null || !Visible) return;
        Clear();
        // (what you have of what they take, in your packs - a server may count more than that (a bank it keeps for you),
        // so buying is never held back here: the server says if you can't afford it)
        long pyreals = _v.Currency != 0 ? _v.CurrencyHave : ServerCoins?.Invoke() is long told && told >= 0 ? told : Inv?.Pyreals ?? 0;
        if (Inv != null) _selling.RemoveAll(s => !Inv.Pack.Contains(s.item));
        uint vendor = _v.Guid;
        var tabs = new HBoxContainer();
        string[] names = { "Buy", $"Buy List ({_buying.Count})", $"Sell ({_selling.Count})" };
        for (int t = 0; t < 3; t++)
        {
            int tab = t;
            var b = new Button { Text = names[t], FocusMode = FocusModeEnum.None, ToggleMode = true, ButtonPressed = _tab == t };
            b.Pressed += () => { _tab = tab; _picked = null; _waresAt = 0; _wares = null; Refresh(); };
            tabs.AddChild(b);
        }
        var purse = Text($"{pyreals:N0} {Coin}{(_v.Currency == 0 && !(ServerCoins?.Invoke() >= 0) ? " carried" : "")}", 12, RetailTheme.Dim);
        purse.SizeFlagsHorizontal = SizeFlags.ExpandFill; purse.HorizontalAlignment = HorizontalAlignment.Right; purse.AutowrapMode = TextServer.AutowrapMode.Off;
        tabs.AddChild(purse);
        Body.AddChild(tabs);

        if (_tab == 0)
        {
            // their wares of one kind: the drop-down's (the first kind they have, to begin with)
            var kinds = new List<int>();
            foreach (var w in _v.ForSale) { int k = KindOf(w); if (!kinds.Contains(k)) kinds.Add(k); }
            if (!kinds.Contains(_kind)) _kind = kinds.Count > 0 ? kinds[0] : 0;
            var pick = new OptionButton { FocusMode = FocusModeEnum.None };
            foreach (int k in kinds) pick.AddItem(KindName(k));
            if (kinds.Count > 0) pick.Selected = kinds.IndexOf(_kind);
            pick.ItemSelected += n => { _kind = kinds[(int)n]; _picked = null; _waresAt = 0; _wares = null; Refresh(); };
            Body.AddChild(pick);
            var wares = _v.ForSale.Where(w => KindOf(w) == _kind).ToList();
            if (_picked != null && !wares.Contains(_picked)) _picked = null;
            AddRow(wares, null, i => { Add(_buying, i, 1); Refresh(); });
            var p = _picked;
            Body.AddChild(Text(p != null ? $"{p.Name}: {Cost(p, 1):N0} {Coin} each" : wares.Count == 0 ? "They have nothing for sale." : "Click a ware to pick it.", 13, p != null ? RetailTheme.Gold : RetailTheme.Dim));
            var foot = new HBoxContainer();
            var many = new SpinBox { MinValue = 1, MaxValue = 5000, Step = 1, Value = Math.Clamp(_amount, 1, 5000), CustomMinimumSize = new Vector2(80, 0), Editable = p != null };
            many.ValueChanged += v => _amount = (int)v;
            foot.AddChild(many);
            foot.AddChild(Small("Buy", () => { if (p != null) { many.Apply(); Buy?.Invoke(vendor, new List<(Item, int)> { (p, Math.Max(1, _amount)) }); } }, p != null));
            foot.AddChild(Small("Add to List", () => { if (p != null) { many.Apply(); Add(_buying, p, Math.Max(1, _amount)); _amount = 1; Refresh(); } }, p != null));
            Body.AddChild(foot);
        }
        else if (_tab == 1)
        {
            if (_picked != null && !_buying.Any(x => x.item == _picked)) _picked = null;
            AddRow(_buying.Select(x => x.item).ToList(), i => _buying.FirstOrDefault(x => x.item == i).amount, i => { _buying.RemoveAll(x => x.item == i); Refresh(); });
            long total = _buying.Sum(x => (long)Cost(x.item, x.amount));
            var p = _picked;
            int pn = p != null ? _buying.First(x => x.item == p).amount : 0;
            Body.AddChild(Text(p != null ? $"{pn:N0} x {p.Name}: {Cost(p, pn):N0} {Coin}" : _buying.Count == 0 ? "Nothing on the list yet (Add to List on the Buy tab)." : "Click one to pick it.", 13, p != null ? RetailTheme.Gold : RetailTheme.Dim));
            Body.AddChild(Text($"Total: {total:N0} {Coin}", 13, null));
            var foot = new HBoxContainer();
            foot.AddChild(Small("Buy Selected", () => { if (p != null) { _buying.RemoveAll(x => x.item == p); _picked = null; Buy?.Invoke(vendor, new List<(Item, int)> { (p, pn) }); Refresh(); } }, p != null));
            foot.AddChild(Small("Buy All", BuyNow, _buying.Count > 0));
            foot.AddChild(Small("Remove", () => { if (p != null) { _buying.RemoveAll(x => x.item == p); _picked = null; Refresh(); } }, p != null));
            foot.AddChild(Small("Clear", () => { _buying.Clear(); _picked = null; Refresh(); }, _buying.Count > 0));
            Body.AddChild(foot);
        }
        else
        {
            if (_picked != null && !_selling.Any(x => x.item == _picked)) _picked = null;
            AddRow(_selling.Select(x => x.item).ToList(), i => _selling.FirstOrDefault(x => x.item == i).amount, i => { _selling.RemoveAll(x => x.item == i); Refresh(); });
            long total = _selling.Sum(x => (long)Gain(x.item, x.amount));
            var p = _picked;
            int pn = p != null ? _selling.First(x => x.item == p).amount : 0;
            Body.AddChild(Text(p != null ? $"{pn:N0} x {p.Name}: {Gain(p, pn):N0} pyreals" : _selling.Count == 0 ? "Drop things of yours here to sell them." : "Click one to pick it.", 13, p != null ? RetailTheme.Gold : RetailTheme.Dim));
            Body.AddChild(Text($"You'd get: {total:N0} pyreals", 13));
            var foot = new HBoxContainer();
            foot.AddChild(Small("Sell", () => { var all = _selling.ToList(); _selling.Clear(); _picked = null; Sell?.Invoke(vendor, all); Refresh(); }, _selling.Count > 0));
            foot.AddChild(Small("Remove", () => { if (p != null) { _selling.RemoveAll(x => x.item == p); _picked = null; Refresh(); } }, p != null));
            foot.AddChild(Small("Clear", () => { _selling.Clear(); _picked = null; Refresh(); }, _selling.Count > 0));
            Body.AddChild(foot);
        }
    }
}
