using System;
using System.Collections.Generic;
using DatReaderWriter.Enums;
using Godot;

namespace ACGodot.UI;

/// <summary>
/// The game's control bar (layout 0x21000016), bottom right: the combat-mode button, the side panel buttons
/// (social, spellbook, character, quests, map, options) and the bag (inventory), each lit while its panel is open;
/// the hand (use what's selected, lit when it can be used) and the magnifying glass (identify it); and what's
/// selected - its name, and its health if it has any. (The shortcuts are the separate, sizeable shortcut bar.)
/// Dragged about with the interface unlocked.
/// </summary>
public partial class ControlBar : RetailWindow
{
    public const uint Layout = 0x21000016;
    public Action<int>? PanelClicked;
    public Action? UseClicked, ExamineClicked, CombatClicked;
    private readonly Dictionary<int, UiNode> _panelButtons = new();
    private UiNode? _use, _examine, _selBox, _selName, _selCount, _health, _health2;
    private readonly UiNode?[] _modes = new UiNode?[4];
    private string? _lastName, _lastShownName;
    private UiNode? _slider, _thumb;
    private LineEdit? _amountBox;
    private double _litFor;
    private bool _lit;
    private int _stack;

    /// <summary>How many of the selected stack you're taking (the box and slider under its name): all of it at first.
    /// Dragged from the pack, that many split off.</summary>
    public int SplitAmount { get; private set; }

    // the stack box: the number (type how many) and the slider (its knob at the right is the whole stack; drag it left for fewer)
    private void SetupSplit()
    {
        if (_selCount != null)
        {
            _selCount.Text = "";
            _amountBox = new LineEdit { Alignment = HorizontalAlignment.Center, Flat = true, MaxLength = 6, SelectAllOnFocus = true, ZIndex = 2,
                                        ContextMenuEnabled = false, CaretBlink = true, Theme = RetailTheme.Current };
            _amountBox.SetAnchorsPreset(LayoutPreset.FullRect);
            _amountBox.OffsetLeft = -3; _amountBox.OffsetRight = -1; _amountBox.OffsetTop = -2; _amountBox.OffsetBottom = 1;   // (centred in the box as drawn)
            _amountBox.AddThemeStyleboxOverride("normal", new StyleBoxEmpty());
            _amountBox.AddThemeStyleboxOverride("focus", new StyleBoxEmpty());
            _amountBox.AddThemeColorOverride("font_color", Colors.White);
            _amountBox.AddThemeConstantOverride("minimum_character_width", 1);
            _amountBox.TextChanged += t =>
            {
                string digits = new string(Array.FindAll(t.ToCharArray(), char.IsDigit));
                if (digits != t) { int c = _amountBox.CaretColumn; _amountBox.Text = digits; _amountBox.CaretColumn = Math.Min(c, digits.Length); }
                if (int.TryParse(digits, out int n)) { SplitAmount = Math.Clamp(n, 1, Math.Max(1, _stack)); PlaceThumb(); }
            };
            _amountBox.TextSubmitted += _ => { _amountBox.Text = SplitAmount.ToString(); _amountBox.ReleaseFocus(); };
            _amountBox.FocusExited += () => _amountBox.Text = SplitAmount.ToString();
            _selCount.AddChild(_amountBox);
            _selCount.MouseFilter = MouseFilterEnum.Pass;
        }
        if (_slider != null)
        {
            foreach (var c in _slider.GetChildren()) if (c is UiNode n && n.Id == 1) _thumb = n;
            if (_thumb != null) _slider.MoveChild(_thumb, _slider.GetChildCount() - 1);   // the knob over the line
            bool down = false;
            _slider.OnInput = e =>
            {
                if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb) { down = mb.Pressed; if (down) SlideTo(mb.Position.X); _slider.AcceptEvent(); }
                else if (e is InputEventMouseMotion mm && down) { SlideTo(mm.Position.X); _slider.AcceptEvent(); }
            };
        }
    }

    private void SlideTo(float x)
    {
        if (_slider == null || _stack <= 1) return;
        float knob = _thumb?.Size.X ?? 16f, span = Math.Max(1f, _slider.Size.X - knob);
        float f = Math.Clamp((x - knob * 0.5f) / span, 0f, 1f);
        SplitAmount = Math.Clamp(1 + (int)MathF.Round(f * (_stack - 1)), 1, _stack);
        if (_amountBox != null) _amountBox.Text = SplitAmount.ToString();
        PlaceThumb();
    }

    private void PlaceThumb()
    {
        if (_thumb == null || _slider == null) return;
        float knob = _thumb.Size.X, span = Math.Max(0f, _slider.Size.X - knob);
        float f = _stack > 1 ? (SplitAmount - 1) / (float)(_stack - 1) : 1f;
        _thumb.Position = new Vector2(MathF.Round(span * f), _thumb.Position.Y);
    }

    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("ControlBar");
        if (_litFor > 0 && (_litFor -= delta) <= 0) _selBox?.SetState(UIStateId.Normal);
    }

    /// <summary>A panel button's picture as it is with its panel shut (7: the bag).</summary>
    public Texture2D? PanelIcon(int id) => _panelButtons.TryGetValue(id, out var b) ? b.ImageFor(UIStateId.Normal) : null;

    public bool Setup()
    {
        if (!BuildFrom(Layout, 0x10000191, "controlbar")) return false;
        var r = Root!;
        // the shortcut rows under the buttons are the shortcut bar's job: put away, the bar's height just the buttons
        foreach (var c in r.GetChildren()) if (c is UiNode n && n.Position.Y >= 58) n.Visible = false;
        SetLimits(new Vector2(300, 58), new Vector2(300, 58));
        SetSize2(new Vector2(300, 58));
        ClipContents = true;
        DragAnywhere = true;
        foreach (var c in r.GetChildren())
        {
            if (c is not UiNode n) continue;
            if (n.R.Props.TryGetValue(0x10000029, out var p) && p is DatReaderWriter.Types.EnumBaseProperty e && n.Position.Y < 30)
            {
                int id = (int)e.Value;
                _panelButtons[id] = n;
                n.OnInput = ev => { if (ev is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true }) { PanelClicked?.Invoke(id); n.AcceptEvent(); } };
                n.TooltipText = id switch { 7 => "Inventory", 10 => "Options", 11 => "Character", 12 => "Social", 13 => "Spellbook", 16 => "Map", 25 => "Quests", _ => "" };
            }
        }
        _use = r.Find(0x1000019D);
        _examine = r.Find(0x100001A5);
        if (_use != null) { _use.TooltipText = "Use"; Press(_use, () => UseClicked?.Invoke()); }
        if (_examine != null) { _examine.TooltipText = "Identify"; Press(_examine, () => ExamineClicked?.Invoke()); }
        _modes[0] = r.Find(0x10000192); _modes[1] = r.Find(0x10000193); _modes[2] = r.Find(0x10000194); _modes[3] = r.Find(0x10000195);
        foreach (var m in _modes) if (m != null) { m.TooltipText = "Combat mode (`)"; Press(m, () => CombatClicked?.Invoke()); }
        _selBox = r.Find(0x1000019E);
        _selName = r.Find(0x1000019F);
        _selCount = r.Find(0x100001A3);
        _slider = r.Find(0x100001A4);
        _health = r.Find(0x100001A1);
        _health2 = r.Find(0x100001A2);
        _selName?.TopText();
        SetupSplit();
        SetSelection(null, -1, 0);
        SetMode(0);
        LoadPlace();
        if (Position == Vector2.Zero) { var s = GetViewportRect().Size; Position = new Vector2(s.X - Size.X - 6, s.Y - Size.Y - 6); }
        return true;
    }

    private static void Press(UiNode n, Action run)
    {
        n.OnInput = ev =>
        {
            if (ev is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb)
            {
                if (n.R.States.ContainsKey(UIStateId.Normal_pressed)) n.SetState(mb.Pressed ? UIStateId.Normal_pressed : UIStateId.Normal);
                if (!mb.Pressed) run();
                n.AcceptEvent();
            }
        };
    }

    // the bar is the layout's top part as it is (the shortcut rows cut off, nothing laid out again)
    protected override void SetSize2(Vector2 size) { CustomMinimumSize = size; Size = size; }

    /// <summary>Lights a panel's button while its panel is open.</summary>
    public void SetPanelOpen(int id, bool open)
    {
        if (_panelButtons.TryGetValue(id, out var b)) b.SetState(open && b.R.States.ContainsKey(UIStateId.Highlight) ? UIStateId.Highlight : UIStateId.Normal);
    }

    /// <summary>0 peace, 1 melee, 2 missile, 3 magic: which face the combat button shows.</summary>
    public void SetMode(int mode)
    {
        for (int i = 0; i < 4; i++) if (_modes[i] != null) _modes[i]!.Visible = i == Math.Clamp(mode, 0, 3);
    }

    /// <summary>What's selected: its name, its health (0..1, or below 0 for none) and how many in its stack.</summary>
    public void SetSelection(string? name, float health, int stack, int uses = -1, float mana = -1)
    {
        if (_selName != null) _selName.Text = name ?? "";
        // the box lights up green for a moment when something new is chosen, then goes back to its usual look
        if (name != _lastName) { _lastName = name; _litFor = name == null ? 0 : 1.0; _selBox?.SetState(name == null ? UIStateId.Normal : stack > 1 ? UIStateId.StackedItemSelected : UIStateId.ObjectSelected); }
        // a stack: how many you're taking (all of it, until you say fewer) in the box, and the slider for it
        if (name != _lastShownName || stack != _stack)
        {
            _lastShownName = name; _stack = stack;
            SplitAmount = Math.Max(1, stack);
            if (_amountBox != null && !_amountBox.HasFocus()) _amountBox.Text = stack > 1 ? stack.ToString() : "";
            PlaceThumb();
        }
        if (_selCount != null) _selCount.Visible = stack > 1 || uses >= 0;
        if (_amountBox != null)
        {
            // (a healing kit's or lockpick's uses left show in the box, not to be typed in)
            _amountBox.Editable = stack > 1;
            if (uses >= 0 && stack <= 1) _amountBox.Text = uses.ToString();
        }
        if (_slider != null) _slider.Visible = stack > 1;
        // a creature's health bar - after the box's green flash, which it would cover
        // (a mana stone's charge: the same bar, blue)
        float bar = health >= 0 ? health : mana;
        if (_health != null)
        {
            _health.Visible = bar >= 0 && _litFor <= 0;
            if (bar >= 0) _health.Fraction = bar;
            _health.Modulate = health < 0 && mana >= 0 ? new Color(0.35f, 0.55f, 1.6f) : Colors.White;
        }
        if (_health2 != null) _health2.Visible = false;
    }

    /// <summary>The hand lit when what's selected can be used.</summary>
    public void SetUsable(bool usable) => _use?.SetState(usable ? UIStateId.Normal : UIStateId.Ghosted);
}

/// <summary>
/// The game's status icons (layout 0x21000071): connection, burden (the little backpack: unencumbered, encumbered or
/// heavily encumbered - a click shows Character Information) and the others.
/// </summary>
public partial class StatusIcons : RetailWindow
{
    public const uint Layout = 0x21000071;
    public Action? BurdenClicked, BuffsClicked, DebuffsClicked, VitaeClicked, ChessClicked;
    private UiNode? _burden, _buffs, _debuffs, _vitae, _chess;

    public bool Setup()
    {
        if (!BuildFrom(Layout, 0x10000610, "statusicons")) return false;
        DragAnywhere = true;
        _burden = Root!.Find(0x100000F7);
        if (_burden != null)
        {
            _burden.TooltipText = "Character Information";
            _burden.OnInput = e => { if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true }) { BurdenClicked?.Invoke(); _burden.AcceptEvent(); } };
        }
        Root.Find(0x100000F8)?.SetState(UIStateId.Connection_good);
        // the spells on you (good and bad: one panel, two tabs), vitae, and the chess rook
        UiNode? Icon(uint id, string tip, Func<Action?> run)
        {
            var n = Root!.Find(id);
            if (n == null) return null;
            n.TooltipText = tip;
            n.OnInput = e =>
            {
                if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb)
                {
                    if (n.Find(0x100000F2) is { } glow) glow.SetState(mb.Pressed ? UIStateId.Normal_pressed : UIStateId.Normal);
                    if (!mb.Pressed) run()?.Invoke();
                    n.AcceptEvent();
                }
            };
            return n;
        }
        _buffs = Icon(0x100000F5, "Beneficial spells in effect", () => BuffsClicked);
        _debuffs = Icon(0x100000F6, "Harmful spells in effect", () => DebuffsClicked);
        _vitae = Icon(0x100000F4, "Vitae", () => VitaeClicked);
        _chess = Icon(0x100000F3, "Chess", () => ChessClicked);
        LoadPlace();
        return true;
    }

    /// <summary>The icons lit when there's something to see (spells on you, vitae lost), ghosted when not.</summary>
    public void SetStates(bool buffs, bool debuffs, float vitae)
    {
        _buffs?.SetState(buffs ? UIStateId.Normal : UIStateId.Ghosted);
        _debuffs?.SetState(debuffs ? UIStateId.Normal : UIStateId.Ghosted);
        _vitae?.SetState(vitae < 1f ? UIStateId.Normal : UIStateId.Ghosted);
        if (_vitae != null) _vitae.TooltipText = vitae < 1f ? $"Vitae {vitae * 100:0}%" : "Vitae (none lost)";
    }

    /// <summary>How loaded you are (burden over capacity: up to 1 fine, to 2 encumbered, more heavily).</summary>
    public void SetBurden(float fraction)
    {
        _burden?.SetState(fraction <= 1f ? UIStateId.Unencumbered : fraction <= 2f ? UIStateId.Encumbered : UIStateId.Heavily_encumbered);
        if (_burden != null) _burden.TooltipText = $"Burden {(int)(fraction * 100)}% - Character Information";
    }
}
