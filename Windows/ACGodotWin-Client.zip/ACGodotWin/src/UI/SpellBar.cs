using System.Linq;
using System;
using System.Collections.Generic;
using Godot;

namespace ACGodot.UI;

/// <summary>
/// The game's spell bar (layout 0x21000010), shown in magic combat mode (a wand or staff wielded) in place of the
/// combat bar: eight tabs of favourite spells, the chosen spell's name, and Cast. Spells are dragged onto it from the
/// spellbook (going in where dropped, the rest moving right; always together from the left), moved about on it, or
/// dragged off to remove them; a click chooses one, a double-click (or 1-9, 0, or
/// Cast) casts it at what's selected. Kept in user://spellbar.cfg.
/// </summary>
public partial class SpellBar : RetailWindow
{
    public const uint Layout = 0x21000010;
    public const int Tabs = 8, PerTab = 256;   // (as many as you like on a tab, for all that matters)
    private const string SavePath = "user://spellbar.cfg";
    private readonly ShortcutBar.Entry?[,] _spells = new ShortcutBar.Entry?[Tabs, PerTab];
    private readonly List<HBoxContainer> _rows = new();
    // each tab's strip: the window on its row of squares (which stops short of the arrows), its two arrows, and how
    // many squares along it's scrolled
    private readonly List<Control> _views = new();
    private readonly List<(UiNode? left, UiNode? right, UiNode strip)> _arrows = new();
    private readonly int[] _scrolled = new int[Tabs];
    private int _tab, _chosen = -1, _fit = PerTab;
    private UiNode? _name;
    private Action<int> _choose = _ => { };
    public Action<ShortcutBar.Entry>? Cast;
    /// <summary>A right click on a spell: identify it.</summary>
    public Action<ShortcutBar.Entry>? Identify;
    public Func<uint, Texture2D?> Icon = _ => null;
    public static (int tab, int slot)? Dragging;

    public bool Setup()
    {
        if (!BuildFrom(Layout, 0x1000009F, "spellbar")) return false;
        var r = Root!;
        DragAnywhere = true;
        _name = r.Find(0x1000048B);
        var (tabNodes, pages, choose) = TabsFrom(r.Find(0x100000A2), t => { _tab = t; _chosen = -1; Fill(); SaveSpells(); });
        _choose = choose; _tabNodes = tabNodes;
        foreach (var page in pages)
        {
            var strip = page.Find(0x100000B6) ?? page;
            foreach (var c in strip.GetChildren()) if (c is UiNode n) n.Visible = false;
            // the squares sit in a window that ends where the arrows begin; the arrows move the row along under it
            var view = new Control { ClipContents = true, MouseFilter = MouseFilterEnum.Pass, Size = new Vector2(strip.Size.X, 32) };
            strip.AddChild(view);
            var row = new HBoxContainer { MouseFilter = MouseFilterEnum.Pass };
            row.AddThemeConstantOverride("separation", 0);
            view.AddChild(row);
            _rows.Add(row); _views.Add(view);
            UiNode? a1 = page.Find(0x10000071), a2 = page.Find(0x10000072);
            UiNode? left = a1, right = a2;
            if (a1 != null && a2 != null && a2.Position.X + a2.GetParent<Control>().Position.X < a1.Position.X + a1.GetParent<Control>().Position.X) { left = a2; right = a1; }
            _arrows.Add((left, right, strip));
            int tabOf = _views.Count - 1;
            void Hook(UiNode? arrow, int by)
            {
                if (arrow == null) return;
                arrow.OnInput = e =>
                {
                    if (e is not InputEventMouseButton { ButtonIndex: MouseButton.Left } mb) return;
                    arrow.SetState(mb.Pressed ? DatReaderWriter.Enums.UIStateId.Normal_pressed : DatReaderWriter.Enums.UIStateId.Normal);
                    // (one along as it's pressed, and one more every half second it's held)
                    if (mb.Pressed && tabOf < Tabs) { _scrolled[tabOf] += by; Fill(); _heldBy = by; _heldTab = tabOf; _heldFor = 0; _heldArrow = arrow; }
                    else if (!mb.Pressed) _heldBy = 0;
                    arrow.AcceptEvent();
                };
            }
            Hook(left, -1); Hook(right, 1);
            // the two arrows half as far apart as the layout has them: the left one kept that much from the right one
            if (left != null && right != null)
            {
                _arrowGap = Math.Max(0f, (right.Position.X - (left.Position.X + left.Size.X)) * 0.5f);
                left.Pinned = true;
            }
        }
        if (r.Find(0x100000B2) is { } cast)
        {
            cast.CenterText();
            cast.OnInput = e =>
            {
                if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb)
                {
                    cast.SetState(mb.Pressed ? DatReaderWriter.Enums.UIStateId.Normal_pressed : DatReaderWriter.Enums.UIStateId.Normal);
                    if (!mb.Pressed && _chosen >= 0) Activate(_chosen);
                    cast.AcceptEvent();
                }
            };
        }
        Load();
        _choose(Math.Clamp(_tab, 0, Math.Max(0, _rows.Count - 1)));
        Visible = false;
        // sized by a grip in its corner: wider (more spells show) or narrower
        SetLimits(new Vector2(Math.Min(260, r.Size.X), r.Size.Y), new Vector2(2400, r.Size.Y * 2));
        AddGrip();
        LoadPlace();
        return true;
    }

    /// <summary>Casts a slot of the tab showing (0-based: 1-9, 0 on the keys).</summary>
    public void Activate(int slot)
    {
        if (slot < 0 || slot >= PerTab || _spells[_tab, slot] is not { } e) return;
        _chosen = slot;
        Cast?.Invoke(e);
        Fill();
    }

    private void Fill()
    {
        if (_tab < 0 || _tab >= _rows.Count) return;
        var row = _rows[_tab];
        foreach (var c in row.GetChildren()) { row.RemoveChild(c); c.QueueFree(); }
        // the window on the squares: from the strip's start to the first of the arrows (the whole strip if there are none)
        var view = _views[_tab];
        var (arrowL, arrowR, strip) = _arrows[_tab];
        if (arrowL != null && arrowR != null && arrowL.Pinned) arrowL.Position = new Vector2(arrowR.Position.X - arrowL.Size.X - _arrowGap, arrowR.Position.Y);
        float wide = strip.Size.X;
        float stripX = strip.GetGlobalRect().Position.X;
        foreach (var arrow in new[] { arrowL, arrowR })
            if (arrow != null && arrow.Visible) { float ax = arrow.GetGlobalRect().Position.X - stripX; if (ax > 16 && ax < wide) wide = ax; }
        view.Position = Vector2.Zero; view.Size = new Vector2(Math.Max(32, wide), 32);
        int fit = Math.Clamp((int)(wide / 32), 1, PerTab);
        _fit = fit;
        // a square for every spell and one more to put the next in - at least as many as show
        int have = 0; for (int i = 0; i < PerTab; i++) if (_spells[_tab, i] != null) have = i + 1;
        int count = Math.Min(PerTab, Math.Max(fit, have + 1));
        _scrolled[_tab] = Math.Clamp(_scrolled[_tab], 0, Math.Max(0, count - fit));
        row.Position = new Vector2(-_scrolled[_tab] * 32, 0);
        row.Size = new Vector2(count * 32, 32);
        for (int i = 0; i < count; i++)
        {
            var e = _spells[_tab, i];
            var b = new SpellSlot { Bar = this, Tab = _tab, Slot = i, CustomMinimumSize = new Vector2(32, 32), FocusMode = FocusModeEnum.None, ExpandIcon = true,
                                    IconAlignment = HorizontalAlignment.Center, VerticalIconAlignment = VerticalAlignment.Center, TooltipText = e?.Name ?? "" };
            var normal = new StyleBoxFlat { BgColor = new Color(0, 0, 0, 0.35f), BorderColor = i == _chosen ? new Color(1f, 0.9f, 0.4f) : new Color(0.3f, 0.25f, 0.12f),
                                            BorderWidthLeft = 1, BorderWidthRight = 1, BorderWidthTop = 1, BorderWidthBottom = 1 };
            b.AddThemeStyleboxOverride("normal", normal); b.AddThemeStyleboxOverride("hover", normal); b.AddThemeStyleboxOverride("pressed", normal);
            b.AddThemeStyleboxOverride("focus", new StyleBoxEmpty());
            if (e != null) b.Icon = Icon(e.Icon);
            if (i < 10)
            {
                var num = new Label { Text = ((i + 1) % 10).ToString(), MouseFilter = MouseFilterEnum.Ignore, Position = new Vector2(2, -2) };
                num.AddThemeColorOverride("font_color", new Color(1f, 0.95f, 0.7f));
                b.AddChild(num);
            }
            int ii = i;
            b.GuiInput += ev =>
            {
                if (ev is InputEventMouseButton { ButtonIndex: MouseButton.Left, DoubleClick: true }) { Activate(ii); b.AcceptEvent(); }
                // (chosen without making the squares again: made again under the mouse, the press was lost and the
                // spell couldn't be picked up and dragged)
                else if (ev is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true }) { _chosen = ii; ShowName(); Restyle(); }
                else if (ev is InputEventMouseButton { ButtonIndex: MouseButton.Right, Pressed: true }) { if (_spells[_tab, ii] is { } se) Identify?.Invoke(se); b.AcceptEvent(); }
            };
            row.AddChild(b);
        }
        ShowName();
    }

    // the chosen square's gold edge moved, the squares left as they are
    private void Restyle()
    {
        if (_tab < 0 || _tab >= _rows.Count) return;
        foreach (var c in _rows[_tab].GetChildren())
            if (c is SpellSlot b && b.GetThemeStylebox("normal") is StyleBoxFlat sb)
            {
                var n = (StyleBoxFlat)sb.Duplicate();
                n.BorderColor = b.Slot == _chosen ? new Color(1f, 0.9f, 0.4f) : new Color(0.3f, 0.25f, 0.12f);
                b.AddThemeStyleboxOverride("normal", n); b.AddThemeStyleboxOverride("hover", n); b.AddThemeStyleboxOverride("pressed", n);
            }
    }

    // dragging a spell over one of the bar's tabs: that tab opens (to drop it there)
    private List<UiNode> _tabNodes = new();
    private double _overTabFor;
    private int _overTab = -1;
    private int _heldBy, _heldTab;
    private double _heldFor;
    private UiNode? _heldArrow;
    private float _arrowGap;
    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("SpellBar");
        // an arrow held down: the spells go by one more every half second
        if (_heldBy != 0)
        {
            if (!Visible || !Input.IsMouseButtonPressed(MouseButton.Left))
            { _heldBy = 0; try { _heldArrow?.SetState(DatReaderWriter.Enums.UIStateId.Normal); } catch { } }
            else if ((_heldFor += delta) >= 0.5) { _heldFor = 0; if (_heldTab == _tab) { _scrolled[_tab] += _heldBy; Fill(); } }
        }
        if ((Dragging == null && ShortcutBar.DraggingSpell == null) || !Visible) { _overTab = -1; return; }
        var m = GetGlobalMousePosition();
        int over = -1;
        for (int i = 0; i < _tabNodes.Count; i++) if (_tabNodes[i].GetGlobalRect().HasPoint(m)) over = i;
        if (over != _overTab) { _overTab = over; _overTabFor = 0; return; }
        if (over < 0 || over == _tab) return;
        _overTabFor += delta;
        if (_overTabFor > 0.35) _choose(over);
    }

    private void ShowName() { if (_name != null) _name.Text = _chosen >= 0 && _spells[_tab, _chosen] is { } e ? e.Name : ""; }

    protected override void Resized2() => Fill();

    internal ShortcutBar.Entry? Get(int tab, int slot) => _spells[tab, slot];

    /// <summary>
    /// A spell dropped on the bar: it goes in at that place (what's there and after moves along to the right), or at
    /// the end if dropped past the last (a full bar: it replaces the one it's dropped on) - the spells always sit together from the left, no gaps. Moved from elsewhere
    /// on the bar, it comes out of where it was first.
    /// </summary>
    internal void Put(int tab, int slot, ShortcutBar.Entry e, (int tab, int slot)? from)
    {
        var list = Row(tab);
        if (from is { } f)
        {
            if (f.tab == tab)
            {
                if (f.slot >= list.Count) return;
                list.RemoveAt(f.slot);
                if (f.slot < slot) slot--;   // (the ones after it moved left)
            }
            else { var other = Row(f.tab); if (f.slot < other.Count) other.RemoveAt(f.slot); SetRow(f.tab, other); }
        }
        // (there's always room for one more: the bar grows a square past the last, and the arrows bring it into view)
        if (list.Count >= PerTab) list[Math.Clamp(slot, 0, list.Count - 1)] = e;
        else list.Insert(Math.Clamp(slot, 0, list.Count), e);
        SetRow(tab, list);
        SaveSpells(); Fill();
    }

    // a tab's spells, left to right (no gaps)
    private List<ShortcutBar.Entry> Row(int tab)
    {
        var l = new List<ShortcutBar.Entry>();
        for (int i = 0; i < PerTab; i++) if (_spells[tab, i] is { } e) l.Add(e);
        return l;
    }

    private void SetRow(int tab, List<ShortcutBar.Entry> l)
    {
        for (int i = 0; i < PerTab; i++) _spells[tab, i] = i < l.Count ? l[i] : null;
    }

    /// <summary>A spell dragged off the bar: gone, the ones after it move left.</summary>
    public void ClearSlot(int tab, int slot)
    {
        var l = Row(tab);
        if (slot < l.Count) l.RemoveAt(slot);
        SetRow(tab, l);
        SaveSpells(); Fill();
    }

    private bool _loaded;

    private void Load()
    {
        _loaded = true;
        var cfg = new ConfigFile();
        if (global::ACGodot.SafeConfig.Load(cfg, SavePath) != Error.Ok) return;
        _tab = Math.Clamp((int)cfg.GetValue("bar", "tab", 0), 0, Tabs - 1);
        ReadSpells(cfg);
    }

    // whose spell bars these are: each character on a server has its own
    private string _who = "";
    private string Section => _who.Length == 0 ? "spells" : "spells:" + _who;

    private void ReadSpells(ConfigFile cfg)
    {
        for (int t = 0; t < Tabs; t++) for (int i = 0; i < PerTab; i++) _spells[t, i] = null;
        // (none kept for this character yet: the ones kept before characters had their own go to the first to come)
        string from = Section;
        if (!cfg.HasSection(from)) { if (_who.Length == 0 || cfg.GetSections().Any(x => x.StartsWith("spells:"))) return; from = "spells"; }
        if (!cfg.HasSection(from)) return;
        for (int t = 0; t < Tabs; t++)
            for (int i = 0; i < PerTab; i++)
                if (cfg.HasSectionKey(from, $"t{t}s{i}"))
                {
                    var p = ((string)cfg.GetValue(from, $"t{t}s{i}")).Split('|');
                    if (p.Length >= 3 && int.TryParse(p[0], out int id) && uint.TryParse(p[^1], out uint icon))
                        _spells[t, i] = new ShortcutBar.Entry("spell", id, string.Join("|", p[1..^1]), icon);
                }
        for (int t = 0; t < Tabs; t++) SetRow(t, Row(t));   // (kept before with gaps: closed up)
    }

    /// <summary>The bars are this character's from now (a server and a name): theirs are shown, kept apart from others'.</summary>
    public void ForCharacter(string who)
    {
        if (who == _who || !_loaded) { if (!_loaded) _pendingWho = who; return; }
        _who = who;
        var cfg = new ConfigFile();
        global::ACGodot.SafeConfig.Load(cfg, SavePath);
        ReadSpells(cfg);
        SaveSpells();
        _chosen = -1;
        Fill();
        ShowName();
    }
    private string? _pendingWho;

    private void SaveSpells()
    {
        if (!_loaded) return;
        var cfg = new ConfigFile();
        global::ACGodot.SafeConfig.Load(cfg, SavePath);   // (the other characters' stay)
        if (cfg.HasSection(Section)) cfg.EraseSection(Section);
        cfg.SetValue("bar", "tab", _tab);
        for (int t = 0; t < Tabs; t++)
            for (int i = 0; i < PerTab; i++)
                if (_spells[t, i] is { } e) cfg.SetValue(Section, $"t{t}s{i}", $"{e.Id}|{e.Name.Replace("|", "/")}|{e.Icon}");
        global::ACGodot.SafeConfig.Save(cfg, SavePath);
    }

    /// <summary>A spell's square on the bar: takes spells dropped from the spellbook; dragged, carries its spell.</summary>
    public partial class SpellSlot : Button
    {
        public SpellBar Bar = null!;
        public int Tab, Slot;

        public override Variant _GetDragData(Vector2 at)
        {
            if (Bar.Get(Tab, Slot) == null) return default;
            Dragging = (Tab, Slot);
            var pic = new TextureRect { Texture = Icon, Size = new Vector2(32, 32), ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize };
            var holder = new Control(); holder.AddChild(pic); pic.Position = new Vector2(-16, -16);
            holder.ZIndex = 1000; holder.ZAsRelative = false;   // (over everything: some squares sit a layer up)
            SetDragPreview(holder);
            return "acgodot-spellslot";
        }

        public override bool _CanDropData(Vector2 at, Variant data)
        {
            string s = data.VariantType == Variant.Type.String ? (string)data : "";
            return s == "acgodot-spell" || s == "acgodot-spellslot";
        }

        public override void _DropData(Vector2 at, Variant data)
        {
            string s = (string)data;
            if (s == "acgodot-spell" && ShortcutBar.DraggingSpell is { } sp) Bar.Put(Tab, Slot, sp, null);
            else if (s == "acgodot-spellslot" && Dragging is { } from && Bar.Get(from.tab, from.slot) is { } e) Bar.Put(Tab, Slot, e, from);
            ShortcutBar.DraggingSpell = null; Dragging = null;
        }
    }
}
