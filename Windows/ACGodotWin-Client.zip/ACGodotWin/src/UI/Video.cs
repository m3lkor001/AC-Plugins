using System;
using Godot;

namespace ACGodot.UI;

/// <summary>
/// The video settings (Options > Video): kept in user://ui.cfg, put in force when the game starts and whenever one is
/// changed. What draws the landscape and what stands on it are found as they come to be (the world is made after the
/// game starts), so this is a node that keeps their distances as set.
/// </summary>
public partial class Video : Node
{
    private const string Cfg = "user://ui.cfg";

    public static bool Fullscreen, VSync = true, Fxaa;
    public static int FrameCap;            // 0: no limit
    public static int Msaa = 2;            // 0 off, 1 2x, 2 4x, 3 8x
    public static int Aniso = 4;           // 0 off, 1 2x, 2 4x, 3 8x, 4 16x
    public static int Scale = 100;         // the 3D world drawn at so much of the window's size (%)
    public static int Land = 5;            // landblocks of landscape each way
    public static int Things = 3;          // landblocks of buildings, trees and the rest each way
    public static int Fov = 70;
    public static bool Steep;
    public static bool Unload = true;      // models, textures and looks nothing on screen uses: unloaded after a few minutes              // ground too steep to walk up tinted dark red

    public Func<Terrain.TerrainStreamer?>? TerrainOf;
    public Func<Objects.ObjectStreamer?>? ObjectsOf;
    public Func<Camera3D?>? CamOf;
    private static Video? _one;

    public static void Load()
    {
        var c = new ConfigFile();
        if (global::ACGodot.SafeConfig.Load(c, Cfg) != Error.Ok) return;
        Fullscreen = (bool)c.GetValue("video", "fullscreen", Fullscreen);
        VSync = (bool)c.GetValue("video", "vsync", VSync);
        Fxaa = (bool)c.GetValue("video", "fxaa", Fxaa);
        FrameCap = Math.Clamp((int)c.GetValue("video", "cap", FrameCap), 0, 500);
        Msaa = Math.Clamp((int)c.GetValue("video", "msaa", Msaa), 0, 3);
        Aniso = Math.Clamp((int)c.GetValue("video", "aniso", Aniso), 0, 4);
        Scale = Math.Clamp((int)c.GetValue("video", "scale", Scale), 50, 100);
        Land = Math.Clamp((int)c.GetValue("video", "land", Land), 2, 8);
        Things = Math.Clamp((int)c.GetValue("video", "things", Things), 1, 5);
        Fov = Math.Clamp((int)c.GetValue("video", "fov", Fov), 50, 100);
        Steep = (bool)c.GetValue("video", "steep", Steep);
        Unload = (bool)c.GetValue("video", "unload", Unload);
    }

    public static void Save()
    {
        var c = new ConfigFile();
        global::ACGodot.SafeConfig.Load(c, Cfg);
        c.SetValue("video", "fullscreen", Fullscreen); c.SetValue("video", "vsync", VSync); c.SetValue("video", "fxaa", Fxaa);
        c.SetValue("video", "cap", FrameCap); c.SetValue("video", "msaa", Msaa); c.SetValue("video", "aniso", Aniso);
        c.SetValue("video", "scale", Scale); c.SetValue("video", "land", Land); c.SetValue("video", "things", Things); c.SetValue("video", "fov", Fov); c.SetValue("video", "steep", Steep); c.SetValue("video", "unload", Unload);
        global::ACGodot.SafeConfig.Save(c, Cfg);
    }

    public override void _Ready() { _one = this; Load(); Apply(); }

    /// <summary>A setting was changed: kept, and put in force.</summary>
    public static void Changed() { Save(); _one?.Apply(); }

    /// <summary>Keeping time with the screen, and the most frames a second (also put back after a stall, see TestBridge).</summary>
    public static void ApplyFrames()
    {
        DisplayServer.WindowSetVsyncMode(VSync ? DisplayServer.VSyncMode.Enabled : DisplayServer.VSyncMode.Disabled);
        Engine.MaxFps = FrameCap;
    }

    private void Apply()
    {
        ApplyFrames();
        var win = GetWindow();
        if (win != null)
        {
            bool full = win.Mode is Window.ModeEnum.Fullscreen or Window.ModeEnum.ExclusiveFullscreen;
            if (Fullscreen && !full) win.Mode = Window.ModeEnum.Fullscreen;
            else if (!Fullscreen && full) win.Mode = OptionsWindow.StartMaximized ? Window.ModeEnum.Maximized : Window.ModeEnum.Windowed;
        }
        var vp = GetViewport();
        if (vp != null)
        {
            vp.Msaa3D = Msaa switch { 0 => Viewport.Msaa.Disabled, 1 => Viewport.Msaa.Msaa2X, 3 => Viewport.Msaa.Msaa8X, _ => Viewport.Msaa.Msaa4X };
            vp.ScreenSpaceAA = Fxaa ? Viewport.ScreenSpaceAAEnum.Fxaa : Viewport.ScreenSpaceAAEnum.Disabled;
            vp.Scaling3DScale = Scale / 100f;
            try { vp.AnisotropicFilteringLevel = (Viewport.AnisotropicFiltering)Aniso; } catch { }
        }
    }

    // (the distances and the view's width: on what's there now - made after the game starts, and made again)
    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("Video");
        if (TerrainOf?.Invoke() is { } t) { if (t.Radius != Land) t.Radius = Land; t.SteepTint = Steep; }
        if (ObjectsOf?.Invoke() is { } o) { if (o.Radius != Things) o.Radius = Things; if (Unload) o.TrimAssets(); }
        if (CamOf?.Invoke() is { } c && Math.Abs(c.Fov - Fov) > 0.01f) c.Fov = Fov;
    }
}
