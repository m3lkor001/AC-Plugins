using System;
using System.Collections.Generic;
using System.Linq;
using DatReaderWriter.Enums;
using Godot;

namespace ACGodot.UI;

/// <summary>
/// The game's own character screen (layout 0x21000004, built from the data files as the retail client drew it): the
/// world's name under "World", the account's characters under "Characters", Create Character, the round ENTER button,
/// and Delete (Restore for one being deleted) / Credits / Exit along the bottom. Its questions use the game's own
/// boxes (layout 0x2100003C). Drawn at 800 x 600 and scaled to the window, like the creation screen (CharGen).
/// </summary>
public partial class CharSelect : Control
{
    /// <summary>Enter the world as this character.</summary>
    public Action<uint>? Enter;
    public Action? Quit;
    /// <summary>The creation screen; false if it couldn't be opened.</summary>
    public Func<bool>? OpenCreate;
    /// <summary>Start deleting / take back the deleting of a character; false if the server couldn't be asked.</summary>
    public Func<uint, bool>? Delete, Restore;
    /// <summary>Seconds until a character is deleted, or -1 if it isn't being.</summary>
    public Func<uint, int>? DeletingIn;
    /// <summary>The world's (server's) name.</summary>
    public Func<string>? World;

    private const uint Screen = 0x21000004, Dialogs = 0x2100003C;
    private const uint WorldBox = 0x1000039B, List = 0x1000039D, RestoreBtn = 0x1000039E, DeleteBtn = 0x1000039F,
                       CreateBtn = 0x100003A0, EnterBtn = 0x100003A2, CreditsBtn = 0x100003A3, ExitBtn = 0x100003A4, Row = 0x100003A5;

    private RetailUi _ui = null!;
    private Control _stage = null!;
    private UiNode _root = null!;
    private bool _built;
    private List<(uint id, string name)> _chars = new();
    private string _account = "";
    private uint _picked;
    private readonly List<UiNode> _rows = new();
    private UiNode? _dialog, _world;
    private double _tick;

    /// <summary>Shows the account's characters; false if the game's screen couldn't be built (the plain list is used then).</summary>
    public bool Show(IReadOnlyList<(uint id, string name)> characters, string account)
    {
        if (!_built && !Build()) return false;
        _chars = characters.ToList();
        _account = account;
        if (!_chars.Any(c => c.id == _picked)) _picked = _chars.Count > 0 ? _chars[0].id : 0;
        HideDialog();
        Fill();
        Visible = true;
        Fit();
        return true;
    }

    /// <summary>Back to the screen (from the creation screen's Exit) with the list it had; false if it was never built.</summary>
    public bool ShowAgain() => _built && Show(_chars, _account);

    private bool Build()
    {
        _ui = RetailUi.Current!;
        if (_ui == null) return false;
        var root = _ui.Build(Screen);
        if (root == null || root.Find(List) == null) return false;
        _root = root;
        SetAnchorsPreset(LayoutPreset.FullRect);
        MouseFilter = MouseFilterEnum.Stop;
        _stage = new Control { MouseFilter = MouseFilterEnum.Pass, Size = new Vector2(800, 600) };
        AddChild(_stage);
        _stage.AddChild(_root);
        _root.Position = Vector2.Zero;
        Native(_root);
        FirstStates(_root);
        _world = N(WorldBox);
        _world?.CenterText();
        if (N(RestoreBtn) is { } r) r.Visible = false;
        if (N(List) is { } list) list.ClipContents = true;
        if (N(List)?.GetParent() is UiNode box) Frame(box);
        // (the buttons' words in the middle of their pictures - the layout leaves them at the left)
        foreach (uint b in new[] { RestoreBtn, DeleteBtn, CreateBtn, EnterBtn, CreditsBtn, ExitBtn }) N(b)?.CenterText();
        Click(N(CreateBtn), () => { if (OpenCreate?.Invoke() == true) Visible = false; });
        Click(N(EnterBtn), EnterPicked);
        Click(N(DeleteBtn), AskDelete);
        Click(N(RestoreBtn), () => { if (_picked != 0 && Restore?.Invoke(_picked) == true) Say("Restoring " + NameOf(_picked) + "..."); });
        Click(N(CreditsBtn), () => Say("Asheron's Call - copyright Turbine, Inc. and WB Games Inc.\nACGodot: a client for it, made with Godot."));
        Click(N(ExitBtn), () => Quit?.Invoke());
        Resized += Fit;
        _built = true;
        return true;
    }

    private UiNode? N(uint id) => _root.Find(id);
    private string NameOf(uint id) => _chars.FirstOrDefault(c => c.id == id).name ?? "";
    private int Deleting(uint id) => DeletingIn?.Invoke(id) ?? -1;

    private void Fill()
    {
        if (_world != null) _world.Text = World?.Invoke() ?? "";
        var list = N(List);
        foreach (var r in _rows) r.QueueFree();
        _rows.Clear();
        if (list == null) return;
        for (int i = 0; i < _chars.Count; i++)
        {
            var (id, name) = _chars[i];
            var row = _ui.Build(Screen, Row);
            if (row == null) break;
            Native(row);
            row.Position = new Vector2(0, i * row.Size.Y);
            row.Size = new Vector2(list.Size.X, row.Size.Y);
            row.Text = name;
            row.TextLeft = row.R.Props.TryGetValue(0x23, out var p) && p is DatReaderWriter.Types.IntegerBaseProperty ip ? ip.Value : 6;
            row.SetTextAlign(1);
            row.SetMeta("id", id);
            uint pick = id;
            row.OnInput = e =>
            {
                if (e is not InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true } mb) return;
                _picked = pick;
                Mark();
                if (mb.DoubleClick) EnterPicked();
            };
            row.MouseEntered += () => { if (row.CurrentState == UIStateId.Normal || row.CurrentState == UIStateId.Undef) row.SetState(State("Normal_rollover")); };
            row.MouseExited += () => { if (row.CurrentState == State("Normal_rollover")) row.SetState(UIStateId.Normal); };
            list.AddChild(row);
            _rows.Add(row);
        }
        Mark();
    }

    /// <summary>The picked character highlighted; one being deleted dimmed, with Restore in Delete's place while it's picked.</summary>
    private void Mark()
    {
        foreach (var row in _rows)
        {
            uint id = (uint)row.GetMeta("id");
            int left = Deleting(id);
            row.SetState(id == _picked ? UIStateId.Highlight : UIStateId.Normal);
            row.Modulate = left >= 0 ? new Color(0.55f, 0.55f, 0.55f) : Colors.White;
            row.TooltipText = left >= 0 ? $"Being deleted - gone in {Math.Max(1, (left + 59) / 60)} min unless restored" : "";
        }
        bool deleting = _picked != 0 && Deleting(_picked) >= 0;
        if (N(RestoreBtn) is { } r) r.Visible = deleting;
        if (N(DeleteBtn) is { } d) { d.Visible = !deleting; Ghost(d, _picked == 0); }
        Ghost(N(EnterBtn), _picked == 0 || deleting);
        Ghost(N(CreateBtn), _chars.Count >= 11);
    }

    private static void Ghost(UiNode? n, bool off)
    {
        if (n == null || !n.R.States.ContainsKey(UIStateId.Ghosted)) return;
        if (off) n.SetState(UIStateId.Ghosted, children: false);
        else if (n.CurrentState == UIStateId.Ghosted) n.SetState(UIStateId.Normal, children: false);
    }

    private static bool Ghosted(UiNode? n) => n?.CurrentState == UIStateId.Ghosted;

    private void EnterPicked()
    {
        if (_dialog != null || _picked == 0) return;
        if (Deleting(_picked) >= 0) { Say(NameOf(_picked) + " is being deleted - Restore it first."); return; }
        uint id = _picked;
        Visible = false;
        Enter?.Invoke(id);
    }

    private void AskDelete()
    {
        if (_dialog != null || _picked == 0) return;
        uint id = _picked;
        Ask($"Delete {NameOf(id)}? (Restore brings it back for an hour.)", yes => { if (yes && Delete?.Invoke(id) == true) Say("Deleting " + NameOf(id) + "..."); });
    }

    public override void _Process(double delta)
    {
        if (!Visible || !_built) return;
        if (_world != null && World?.Invoke() is { } w && w != _world.Text) _world.Text = w;   // (the name can come after the list)
        // (the minutes left on characters being deleted)
        if ((_tick += delta) >= 15) { _tick = 0; Mark(); }
    }

    public override void _UnhandledKeyInput(InputEvent e)
    {
        if (!Visible || e is not InputEventKey { Pressed: true } k) return;
        if (_dialog != null)
        {
            if (k.Keycode is Key.Escape) { HideDialog(); GetViewport().SetInputAsHandled(); }
            return;
        }
        int i = _chars.FindIndex(c => c.id == _picked);
        if (k.Keycode is Key.Up or Key.Down && _chars.Count > 0)
        {
            i = Math.Clamp(i + (k.Keycode == Key.Up ? -1 : 1), 0, _chars.Count - 1);
            _picked = _chars[i].id;
            Mark();
            GetViewport().SetInputAsHandled();
        }
        else if (k.Keycode is Key.Enter or Key.KpEnter) { EnterPicked(); GetViewport().SetInputAsHandled(); }
    }

    // ── the game's question boxes ──

    /// <summary>A Yes / No box (0x2100003C element 0x15).</summary>
    private void Ask(string words, Action<bool> answer)
    {
        if (!OpenDialog(0x15, words)) { answer(true); return; }
        Click(_dialog!.Find(0x17), () => { HideDialog(); answer(true); });
        Click(_dialog.Find(0x19), () => { HideDialog(); answer(false); });
    }

    /// <summary>A box with words and OK (0x2100003C element 0x24).</summary>
    private void Say(string words)
    {
        if (!OpenDialog(0x24, words)) return;
        Click(_dialog!.Find(0x26), HideDialog);
    }

    private bool OpenDialog(uint id, string words)
    {
        HideDialog();
        var d = _ui.Build(Dialogs, id);
        if (d == null) return false;
        Native(d);
        FirstStates(d);
        d.Position = Vector2.Zero;
        d.Size = new Vector2(800, 600);
        d.OnInput = _ => { };   // (nothing behind it takes clicks while it's up)
        if (d.Find(0x3D) is { } panel) panel.Position = ((new Vector2(800, 600) - panel.Size) * 0.5f).Floor();
        if (d.Find(0x3E) is { } text)
        {
            int lines = words.Count(ch => ch == '\n');
            if (lines > 0 && d.Find(0x3D) is { } box)
            {
                // (room for more lines: the box taller, its words' box with it)
                float more = lines * 14;
                box.Resize(new Vector2(box.Size.X, box.Size.Y + more));
                box.Position -= new Vector2(0, more * 0.5f);
                text.Pinned = true;
                text.Size = new Vector2(text.Size.X, text.Size.Y + more);
            }
            text.Text = words;
            text.CenterText();
        }
        _stage.AddChild(d);
        _dialog = d;
        return true;
    }

    private void HideDialog() { _dialog?.QueueFree(); _dialog = null; }

    // ── as the creation screen does it ──

    private void Fit() => RetailScreen.Fit(this, _stage);

    /// <summary>The characters list's box (a 21000042 0x100002B0: corners and edges) laid out round its real size
    /// (built, it stays the small square it was drawn as).</summary>
    private static void Frame(UiNode box)
    {
        float w = box.Size.X, h = box.Size.Y;
        void At(uint id, float x, float y, float? sw = null, float? sh = null)
        {
            foreach (var c in box.GetChildren())
                if (c is UiNode n && n.Id == id)
                {
                    n.Pinned = true;
                    n.Position = new Vector2(x, y);
                    if (sw != null || sh != null) n.Size = new Vector2(sw ?? n.Size.X, sh ?? n.Size.Y);
                }
        }
        At(0x100002B1, 0, 0); At(0x100002B2, w - 34, 0); At(0x100002B3, 0, h - 35); At(0x100002B4, w - 34, h - 35);
        At(0x100002B5, 34, 0, w - 68, 7); At(0x1000020B, 34, h - 7, w - 68, 7);
        At(0x10000209, 0, 34, 5, h - 69); At(0x1000020A, w - 5, 34, 5, h - 69);
    }

    private static void Native(Node n) => RetailScreen.Native(n);

    private static void FirstStates(Node n) => RetailScreen.FirstStates(n);

    private static UIStateId State(string name) => RetailScreen.State(name);

    /// <summary>A left click on it does something (not while it's greyed out); its rollover look while the mouse is over it.</summary>
    private static void Click(UiNode? n, Action act)
    {
        if (n == null) return;
        n.OnInput = e => { if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true } && !Ghosted(n)) act(); };
        var over = State("Normal_rollover");
        if (n.R.States.ContainsKey(over))
        {
            n.MouseEntered += () => { if (n.CurrentState == UIStateId.Normal) n.SetState(over, children: false); };
            n.MouseExited += () => { if (n.CurrentState == over) n.SetState(UIStateId.Normal, children: false); };
        }
    }
}
