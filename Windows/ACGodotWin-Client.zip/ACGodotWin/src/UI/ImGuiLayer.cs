using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Godot;
using ImGuiNET;
using NVec2 = System.Numerics.Vector2;

namespace ACGodot.UI;

/// <summary>
/// Dear ImGui drawn over the game (as UtilityBelt does in the real client), for plugins whose windows are ImGui -
/// MelksQB, MelkTank: each frame <see cref="Render"/> runs between ImGui's NewFrame and Render, and what it drew is
/// put on screen with Godot's canvas. While the mouse is over an ImGui window, or a text box of one is being typed
/// in, the game doesn't see those clicks and keys. Window places are kept in user://imgui.ini.
/// </summary>
public partial class ImGuiLayer : CanvasLayer
{
    public static ImGuiLayer? Instance { get; private set; }
    /// <summary>Plugins draw their ImGui windows here, every frame.</summary>
    public static event Action? Render;
    /// <summary>ImGui has the mouse (it's over one of its windows) / the keyboard (typing in one of its boxes).</summary>
    public static bool WantsMouse, WantsKeyboard, TypingAny;
    /// <summary>The plugins' windows aren't drawn (the character screen is up: nothing but the characters list).</summary>
    public static bool Hidden;
    private readonly bool[] _ownPress = new bool[3];

    private IntPtr _ctx;
    private Rid _root;
    private readonly List<Rid> _items = new();
    private static readonly Dictionary<IntPtr, Texture2D> _textures = new();
    private static long _nextTex = 1;
    private Texture2D? _fontTex;
    private float _fontScale = -1;
    private IntPtr _iniPath, _clipText;
    // (kept alive: ImGui calls them)
    private SetClipFn? _setClip;
    private GetClipFn? _getClip;

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate void SetClipFn(IntPtr user, IntPtr text);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate IntPtr GetClipFn(IntPtr user);

    /// <summary>A texture for ImGui.Image and the like: its id (the same texture keeps its id).</summary>
    public static IntPtr Bind(Texture2D tex)
    {
        foreach (var kv in _textures) if (kv.Value == tex) return kv.Key;
        var id = new IntPtr(_nextTex++);
        _textures[id] = tex;
        return id;
    }

    public static void Unbind(IntPtr id) => _textures.Remove(id);

    public override unsafe void _Ready()
    {
        Instance = this;
        Layer = 90;
        ProcessMode = ProcessModeEnum.Always;
        _ctx = ImGui.CreateContext();
        ImGui.SetCurrentContext(_ctx);
        var io = ImGui.GetIO();
        io.ConfigFlags |= ImGuiConfigFlags.NavEnableKeyboard;
        io.BackendFlags |= ImGuiBackendFlags.RendererHasVtxOffset;
        _iniPath = Marshal.StringToCoTaskMemUTF8(ProjectSettings.GlobalizePath("user://imgui.ini"));
        io.NativePtr->IniFilename = (byte*)_iniPath;
        _setClip = (_, text) => { try { DisplayServer.ClipboardSet(Marshal.PtrToStringUTF8(text) ?? ""); } catch { } };
        _getClip = _ =>
        {
            if (_clipText != IntPtr.Zero) Marshal.FreeCoTaskMem(_clipText);
            _clipText = Marshal.StringToCoTaskMemUTF8(DisplayServer.ClipboardGet() ?? "");
            return _clipText;
        };
        io.SetClipboardTextFn = Marshal.GetFunctionPointerForDelegate(_setClip);
        io.GetClipboardTextFn = Marshal.GetFunctionPointerForDelegate(_getClip);
        Style();
        _root = RenderingServer.CanvasItemCreate();
        RenderingServer.CanvasItemSetParent(_root, GetCanvas());
    }

    // UtilityBelt's look: dark, slightly see-through windows
    private static void Style()
    {
        ImGui.StyleColorsDark();
        var s = ImGui.GetStyle();
        s.WindowRounding = 3; s.FrameRounding = 2; s.ScrollbarRounding = 2; s.GrabRounding = 2;
        s.Colors[(int)ImGuiCol.WindowBg] = new System.Numerics.Vector4(0.06f, 0.06f, 0.07f, 0.92f);
    }

    // the font at the chosen text size (Options > Character > Text size)
    private unsafe void Fonts()
    {
        float scale = RetailFont.Scale;
        if (Math.Abs(scale - _fontScale) < 0.01f && _fontTex != null) return;
        _fontScale = scale;
        var io = ImGui.GetIO();
        io.Fonts.Clear();
        // UtilityBelt's font (Noto Sans, 16) when the system has it - the plugins' windows are laid out for it
        string? ttf = null;
        foreach (var f in global::ACGodot.UI.RetailTheme.NotoPaths)
            if (System.IO.File.Exists(f)) { ttf = f; break; }
        if (ttf != null) io.Fonts.AddFontFromFileTTF(ttf, 16f * scale);
        else
        {
            var cfg = ImGuiNative.ImFontConfig_ImFontConfig();
            cfg->SizePixels = 13f * scale;
            cfg->OversampleH = 2; cfg->OversampleV = 2;
            io.Fonts.AddFontDefault(cfg);
            ImGuiNative.ImFontConfig_destroy(cfg);
        }
        io.Fonts.GetTexDataAsRGBA32(out IntPtr px, out int w, out int h, out int bpp);
        var bytes = new byte[w * h * bpp];
        Marshal.Copy(px, bytes, 0, bytes.Length);
        var img = Image.CreateFromData(w, h, false, Image.Format.Rgba8, bytes);
        _fontTex = ImageTexture.CreateFromImage(img);
        var id = new IntPtr(-1);
        _textures[id] = _fontTex;
        io.Fonts.SetTexID(id);
        io.Fonts.ClearTexData();
    }

    /// <summary>The last thing that went wrong drawing a plugin's windows, and how often (for the test bridge).</summary>
    public static string LastError = "";
    public static int Errors;

    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("ImGuiLayer");
        if (_ctx == IntPtr.Zero) return;
        ImGui.SetCurrentContext(_ctx);
        Fonts();
        var io = ImGui.GetIO();
        var size = GetViewport().GetVisibleRect().Size;
        io.DisplaySize = new NVec2(size.X, size.Y);
        io.DeltaTime = (float)Math.Max(delta, 1e-4);
        // a button ImGui has as held that isn't: let go. (A press it saw and a release it didn't - a right click on the
        // map opens a menu, and the menu took the release: with a button "held" since a click outside its windows, ImGui
        // takes no clicks at all, and every plugin window went dead.)
        for (int mbn = 0; mbn < 3; mbn++)
            if (io.MouseDown[mbn] && !Input.IsMouseButtonPressed(mbn == 0 ? MouseButton.Left : mbn == 1 ? MouseButton.Right : MouseButton.Middle))
                io.AddMouseButtonEvent(mbn, false);
        ImGui.NewFrame();
        try { if (!Hidden) Render?.Invoke(); }
        catch (Exception ex) { GD.PushWarning("ImGui: " + ex.Message); LastError = ex.ToString(); Errors++; }
        // (asked for inside the frame - after it, asking starts them afresh)
        unsafe { _bgList = (IntPtr)ImGui.GetBackgroundDrawList().NativePtr; _fgList = (IntPtr)ImGui.GetForegroundDrawList().NativePtr; }
        ImGui.Render();
        Draw(ImGui.GetDrawData());
        WantsMouse = io.WantCaptureMouse;
        WantsKeyboard = io.WantTextInput;
        // (or one of the game's own text boxes - the chat, a dialog's: plugins asking whether you're typing - their hotkeys)
        try { TypingAny = WantsKeyboard || ACGodot.Creatures.Player.TypingInBox(GetViewport()); } catch { TypingAny = WantsKeyboard; }
        // (for the test bridge: how ImGui stands with the mouse)
        State = $"mouse {io.MousePos.X:0},{io.MousePos.Y:0} down {io.MouseDown[0]}/{io.MouseDown[1]} wants mouse {io.WantCaptureMouse} keys {io.WantCaptureKeyboard} text {io.WantTextInput}; " +
                $"item active {ImGui.IsAnyItemActive()} focused {ImGui.IsAnyItemFocused()} hovered {ImGui.IsAnyItemHovered()}; window hovered {ImGui.IsWindowHovered(ImGuiHoveredFlags.AnyWindow)} " +
                $"focused {ImGui.IsWindowFocused(ImGuiFocusedFlags.AnyWindow)}; popup open {ImGui.IsPopupOpen("", ImGuiPopupFlags.AnyPopupId | ImGuiPopupFlags.AnyPopupLevel)}; " +
                $"ctrl {io.KeyCtrl} alt {io.KeyAlt} shift {io.KeyShift}; windows (back to front): {string.Join(" | ", _windowNames)}";
    }
    public static string State = "";
    public static readonly List<string> Seen = new();
    private readonly List<string> _windowNames = new();

    // where its windows were drawn last frame (each window's own drawing, its box): a click there is its own, even on the
    // frame the mouse arrived (ImGui's own "wants the mouse" lags a frame - the click went through to the world)
    private readonly List<Rect2> _windowRects = new();
    private IntPtr _bgList, _fgList;
    private bool OverWindow(Vector2 at) { foreach (var r in _windowRects) if (r.HasPoint(at)) return true; return false; }

    private unsafe void Draw(ImDrawDataPtr data)
    {
        int used = 0;
        _windowRects.Clear();
        _windowNames.Clear();
        // (the lists drawn over or under everything - a plugin's marks in the world - aren't windows)
        IntPtr bg = _bgList, fg = _fgList;
        for (int n = 0; n < data.CmdListsCount; n++)
        {
            var list = data.CmdListsRange[n];
            int vn = list.VtxBuffer.Size;
            var vtx = (ImDrawVert*)list.VtxBuffer.Data;
            if (vn > 0 && (IntPtr)list.NativePtr != bg && (IntPtr)list.NativePtr != fg)
            {
                float x0 = float.MaxValue, y0 = float.MaxValue, x1 = float.MinValue, y1 = float.MinValue;
                for (int i = 0; i < vn; i++) { var v = vtx[i].pos; if (v.X < x0) x0 = v.X; if (v.Y < y0) y0 = v.Y; if (v.X > x1) x1 = v.X; if (v.Y > y1) y1 = v.Y; }
                // (only what's drawn: a long list in a window carries the rows scrolled out of sight too, cut off by its
                // clip rectangles - counted, the expanded quest tracker's list reached down over the spell bar's tabs and
                // took their clicks)
                float cx0 = float.MaxValue, cy0 = float.MaxValue, cx1 = float.MinValue, cy1 = float.MinValue;
                for (int c = 0; c < list.CmdBuffer.Size; c++)
                {
                    var cr = list.CmdBuffer[c].ClipRect;
                    if (cr.Z <= cr.X || cr.W <= cr.Y) continue;
                    cx0 = Math.Min(cx0, cr.X); cy0 = Math.Min(cy0, cr.Y); cx1 = Math.Max(cx1, cr.Z); cy1 = Math.Max(cy1, cr.W);
                }
                if (cx1 > cx0 && cy1 > cy0) { x0 = Math.Max(x0, cx0); y0 = Math.Max(y0, cy0); x1 = Math.Min(x1, cx1); y1 = Math.Min(y1, cy1); }
                var vs = data.DisplaySize;
                // (one over nearly the whole screen is an overlay drawn in a see-through window, not something to click)
                if (x1 > x0 && y1 > y0 && !((x1 - x0) > vs.X * 0.8f && (y1 - y0) > vs.Y * 0.8f)) _windowRects.Add(new Rect2(x0, y0, x1 - x0, y1 - y0));
                try { _windowNames.Add($"{Marshal.PtrToStringUTF8((IntPtr)list.NativePtr->_OwnerName)} {x0:0},{y0:0} {x1 - x0:0}x{y1 - y0:0}"); } catch { }
            }
            var idx = (ushort*)list.IdxBuffer.Data;
            for (int c = 0; c < list.CmdBuffer.Size; c++)
            {
                var cmd = list.CmdBuffer[c];
                if (cmd.UserCallback != IntPtr.Zero || cmd.ElemCount == 0) continue;
                var clip = cmd.ClipRect;
                if (clip.Z <= clip.X || clip.W <= clip.Y) continue;
                // the vertices this command uses (a slice), and its indices into that slice
                int lo = int.MaxValue, hi = -1;
                for (uint i = 0; i < cmd.ElemCount; i++)
                {
                    int v = idx[cmd.IdxOffset + i] + (int)cmd.VtxOffset;
                    if (v < lo) lo = v;
                    if (v > hi) hi = v;
                }
                if (hi < 0 || hi >= vn) continue;
                int count = hi - lo + 1;
                var pts = new Vector2[count]; var cols = new Color[count]; var uvs = new Vector2[count];
                for (int i = 0; i < count; i++)
                {
                    var v = vtx[lo + i];
                    pts[i] = new Vector2(v.pos.X, v.pos.Y);
                    uvs[i] = new Vector2(v.uv.X, v.uv.Y);
                    uint col = v.col;
                    cols[i] = new Color((col & 0xFF) / 255f, ((col >> 8) & 0xFF) / 255f, ((col >> 16) & 0xFF) / 255f, ((col >> 24) & 0xFF) / 255f);
                }
                var ind = new int[cmd.ElemCount];
                for (uint i = 0; i < cmd.ElemCount; i++) ind[i] = idx[cmd.IdxOffset + i] + (int)cmd.VtxOffset - lo;
                if (used >= _items.Count)
                {
                    var ci = RenderingServer.CanvasItemCreate();
                    RenderingServer.CanvasItemSetParent(ci, _root);
                    _items.Add(ci);
                }
                var item = _items[used++];
                RenderingServer.CanvasItemClear(item);
                RenderingServer.CanvasItemSetDrawIndex(item, used);
                RenderingServer.CanvasItemSetClip(item, true);
                RenderingServer.CanvasItemSetCustomRect(item, true, new Rect2(clip.X, clip.Y, clip.Z - clip.X, clip.W - clip.Y));
                Rid tex = _textures.TryGetValue(cmd.TextureId, out var t) && t != null ? t.GetRid() : default;
                RenderingServer.CanvasItemAddTriangleArray(item, ind, pts, cols, uvs, null, null, tex);
            }
        }
        for (int i = used; i < _items.Count; i++) RenderingServer.CanvasItemClear(_items[i]);
    }

    public override void _Input(InputEvent e)
    {
        if (_ctx == IntPtr.Zero) return;
        ImGui.SetCurrentContext(_ctx);
        var io = ImGui.GetIO();
        switch (e)
        {
            case InputEventMouseMotion mm:
                io.AddMousePosEvent(mm.Position.X, mm.Position.Y);
                break;
            case InputEventMouseButton mb:
                io.AddMousePosEvent(mb.Position.X, mb.Position.Y);
                int b = mb.ButtonIndex switch { MouseButton.Left => 0, MouseButton.Right => 1, MouseButton.Middle => 2, _ => -1 };
                if (b >= 0) io.AddMouseButtonEvent(b, mb.Pressed);
                else if (mb.Pressed && mb.ButtonIndex is MouseButton.WheelUp or MouseButton.WheelDown) io.AddMouseWheelEvent(0, mb.ButtonIndex == MouseButton.WheelUp ? 1 : -1);
                else if (mb.Pressed && mb.ButtonIndex is MouseButton.WheelLeft or MouseButton.WheelRight) io.AddMouseWheelEvent(mb.ButtonIndex == MouseButton.WheelLeft ? 1 : -1, 0);
                // over one of its windows: the game doesn't get the click (a release after a press it had, it does)
                // a click on one of its windows is its own: the press, and the release after it too (let through, a
                // release clicked whatever stood under the window - a HUD button selected and attacked the mob behind it)
                bool mine = io.WantCaptureMouse || OverWindow(mb.Position);
                // (for the test bridge: the last clicks as they came in)
                Seen.Add($"{Time.GetTicksMsec() / 1000.0:0.00} {(mb.Pressed ? "press" : "release")} {mb.ButtonIndex} at {mb.Position.X:0},{mb.Position.Y:0} device {mb.Device} wants {io.WantCaptureMouse} over {OverWindow(mb.Position)} focused {DisplayServer.WindowIsFocused()}");
                if (Seen.Count > 12) Seen.RemoveAt(0);
                if (b >= 0 && mb.Pressed) _ownPress[b] = mine;
                if (mine && (mb.Pressed || b < 0)) GetViewport().SetInputAsHandled();
                else if (b >= 0 && !mb.Pressed && _ownPress[b]) { _ownPress[b] = false; GetViewport().SetInputAsHandled(); }
                break;
            case InputEventKey k:
                io.AddKeyEvent(ImGuiKey.ModCtrl, k.CtrlPressed);
                io.AddKeyEvent(ImGuiKey.ModShift, k.ShiftPressed);
                io.AddKeyEvent(ImGuiKey.ModAlt, k.AltPressed);
                io.AddKeyEvent(ImGuiKey.ModSuper, k.MetaPressed);
                var key = Map(k.Keycode);
                if (key != ImGuiKey.None) io.AddKeyEvent(key, k.Pressed);
                if (k.Pressed && k.Unicode >= 32 && !k.CtrlPressed) io.AddInputCharacter((uint)k.Unicode);
                if (io.WantTextInput) GetViewport().SetInputAsHandled();   // typing in one of its boxes
                break;
        }
    }

    private static ImGuiKey Map(Key k) => k switch
    {
        Key.Tab => ImGuiKey.Tab, Key.Left => ImGuiKey.LeftArrow, Key.Right => ImGuiKey.RightArrow, Key.Up => ImGuiKey.UpArrow,
        Key.Down => ImGuiKey.DownArrow, Key.Pageup => ImGuiKey.PageUp, Key.Pagedown => ImGuiKey.PageDown, Key.Home => ImGuiKey.Home,
        Key.End => ImGuiKey.End, Key.Insert => ImGuiKey.Insert, Key.Delete => ImGuiKey.Delete, Key.Backspace => ImGuiKey.Backspace,
        Key.Space => ImGuiKey.Space, Key.Enter => ImGuiKey.Enter, Key.KpEnter => ImGuiKey.KeypadEnter, Key.Escape => ImGuiKey.Escape,
        Key.Ctrl => ImGuiKey.LeftCtrl, Key.Shift => ImGuiKey.LeftShift, Key.Alt => ImGuiKey.LeftAlt,
        Key.A => ImGuiKey.A, Key.C => ImGuiKey.C, Key.V => ImGuiKey.V, Key.X => ImGuiKey.X, Key.Y => ImGuiKey.Y, Key.Z => ImGuiKey.Z,
        _ => ImGuiKey.None,
    };

    public override void _ExitTree()
    {
        foreach (var ci in _items) RenderingServer.FreeRid(ci);
        if (_root.IsValid) RenderingServer.FreeRid(_root);
        if (_ctx != IntPtr.Zero) { ImGui.DestroyContext(_ctx); _ctx = IntPtr.Zero; }
        Instance = null;
    }
}
