using System;
using System.Collections.Generic;
using System.Linq;
using Godot;
using ACGodot.Combat;

namespace ACGodot.UI;

/// <summary>
/// Salvaging, as the game's panel does it: opened by using an Ust; drag the things to break down onto it (or press
/// "Add selected"), then Salvage. The server makes the bags of salvage and says what came of each material.
/// </summary>
public partial class SalvageWindow : GameWindow
{
    public Func<uint, Texture2D?> Icon = _ => null;
    public Inventory? Inv;
    /// <summary>Salvage these with the Ust; false if it couldn't be asked.</summary>
    public Func<Item, List<Item>, bool>? Salvage;
    /// <summary>The thing chosen in the pack (for "Add selected").</summary>
    public Func<Item?>? Selected;
    public Action<Item>? Identify;

    private Item? _ust;
    private readonly List<Item> _things = new();
    private const int Across = 8;

    public SalvageWindow() : base("Salvage", new Vector2(330, 200)) { Scroll.HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled; }

    public void Open(Item ust)
    {
        _ust = ust;
        Visible = true;
        MoveToFront();
        Refresh();
    }

    public void Add(Item it)
    {
        if (Inv == null || it == _ust || it.Guid == 0 || !Inv.Pack.Contains(it) || _things.Contains(it)) return;
        if (Inv.SidePacks.Contains(it)) return;   // (a pack isn't salvaged)
        _things.Add(it);
        Refresh();
    }

    // (dropped anywhere on the window)
    public override bool _CanDropData(Vector2 at, Variant data) =>
        data.VariantType == Variant.Type.String && (string)data == "acgodot-item" && ItemSlot.Dragging is { Guid: not 0 } && ItemSlot.DraggingFrom == "pack";
    public override void _DropData(Vector2 at, Variant data)
    {
        if (ItemSlot.Dragging is { } it) Add(ItemSlot.SplitFrom ?? it);
        ItemSlot.Dragging = null;
    }

    private sealed partial class Row : ItemGrid
    {
        public SalvageWindow Win = null!;
        public Row(int columns) : base(columns) { }
        public override bool CanTake(Item? onto) => ItemSlot.Dragging is { Guid: not 0 } && ItemSlot.DraggingFrom == "pack";
        public override void TakeDrop(int index, Item? onto)
        {
            if (ItemSlot.Dragging is { } it) Win.Add(ItemSlot.SplitFrom ?? it);
            ItemSlot.Dragging = null;
        }
    }

    public void Refresh()
    {
        if (!Visible) return;
        Clear();
        if (Inv != null) _things.RemoveAll(t => !Inv.Pack.Contains(t));
        if (_ust != null && Inv != null && !Inv.Pack.Contains(_ust) && !Inv.Worn.Contains(_ust)) { Visible = false; return; }
        Body.AddChild(Text("Drag the things to salvage here. Click one to take it back out.", 12, RetailTheme.Dim));
        int rows = Math.Max(2, (_things.Count + Across - 1) / Across);
        var grid = new Row(Across) { Source = "salvage", Win = this };
        grid.Fill(_things, Icon, i => { _things.Remove(i); Refresh(); }, null, rows * Across - _things.Count);
        Body.AddChild(grid);
        var foot = new HBoxContainer();
        foot.AddThemeConstantOverride("separation", 8);
        foot.AddChild(Small("Add selected", () => { if (Selected?.Invoke() is { } s) Add(s); }));
        foot.AddChild(Small("Clear", () => { _things.Clear(); Refresh(); }, _things.Count > 0));
        foot.AddChild(new Control { SizeFlagsHorizontal = SizeFlags.ExpandFill });
        foot.AddChild(Small("Salvage", () =>
        {
            if (_ust == null || _things.Count == 0) return;
            if (Salvage?.Invoke(_ust, _things.ToList()) == true) { _things.Clear(); Refresh(); }
        }, _things.Count > 0));
        Body.AddChild(foot);
    }
}
