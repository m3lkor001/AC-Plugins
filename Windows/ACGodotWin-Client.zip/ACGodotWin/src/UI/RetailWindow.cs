using System;
using System.Collections.Generic;
using DatReaderWriter.Types;
using Godot;

namespace ACGodot.UI;

/// <summary>
/// A floating window built from one of the game's layouts: drawn as the game draws it, moved by its title, sized by
/// the layout's own edge and corner handles (within its least and greatest size), shut by its X; where it is and
/// how big is kept in user://ui.cfg.
/// </summary>
public partial class RetailWindow : Control
{
    public UiNode? Root { get; private set; }
    protected string SaveKey = "";
    private Vector2 _min = new(120, 80), _max = new(4000, 4000);
    private const string SavePath = "user://ui.cfg";

    /// <summary>Builds it from a layout's element. False if the game's interface data isn't there.</summary>
    protected bool BuildFrom(uint layout, uint element, string saveKey)
    {
        SaveKey = saveKey;
        Root = RetailUi.Current?.Build(layout, element);
        if (Root == null) return false;
        Root.Position = Vector2.Zero;
        AddChild(Root);
        Root.Visible = true;   // a panel the game keeps hidden until it's opened (its starting state hides it)
        HideDefaults(Root);
        MouseFilter = MouseFilterEnum.Stop;
        // its least and greatest size (properties 0x3E/0x3F least height/width, 0x3C/0x3D greatest)
        int P(uint k, int d) => Root.R.Props.TryGetValue(k, out var p) && p is IntegerBaseProperty i ? i.Value : d;
        _min = new Vector2(P(0x3F, (int)Root.Size.X), P(0x3E, (int)Root.Size.Y));
        _max = new Vector2(Math.Max(P(0x3D, 4000), (int)_min.X), Math.Max(P(0x3C, 4000), (int)_min.Y));
        _min = _min.Min(Root.Size);
        Hook(Root);
        Size = Root.Size;
        CustomMinimumSize = Size;
        return true;
    }

    /// <summary>Back where it was left, at the size it was left (once what's laid over it is made).</summary>
    protected void LoadPlace() => Load();

    /// <summary>Lets it be any size from its least to its greatest (for a panel the game made one size).</summary>
    protected void SetLimits(Vector2 min, Vector2 max) { _min = min; _max = max; }

    /// <summary>
    /// A grip in its bottom-right corner to size it (for panels whose layout has no handles of its own).
    /// </summary>
    protected void AddGrip()
    {
        var grip = new Control { CustomMinimumSize = new Vector2(12, 12), Size = new Vector2(12, 12), MouseDefaultCursorShape = CursorShape.Fdiagsize, MouseFilter = MouseFilterEnum.Stop };
        grip.SetAnchorsPreset(LayoutPreset.BottomRight);
        grip.OffsetLeft = -12; grip.OffsetTop = -12; grip.OffsetRight = 0; grip.OffsetBottom = 0;
        grip.Draw += () =>
        {
            var c = new Color(0.8f, 0.65f, 0.3f, 0.8f);
            for (int i = 0; i < 3; i++) grip.DrawLine(new Vector2(11, 3 + i * 4), new Vector2(3 + i * 4, 11), c, 1f);
        };
        bool down = false; Vector2 from = Vector2.Zero, start = Vector2.Zero;
        grip.GuiInput += e =>
        {
            if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true } && UiLock.Locked) { grip.AcceptEvent(); return; }   // (locked: stays its size)
            if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb) { down = mb.Pressed; from = GetGlobalMousePosition(); start = Size; if (!mb.Pressed) Save(); grip.AcceptEvent(); }
            else if (e is InputEventMouseMotion && down) { SetSize2((start + GetGlobalMousePosition() - from).Clamp(_min, _max)); grip.AcceptEvent(); }
        };
        AddChild(grip);
    }

    /// <summary>Dragged about by any empty part of it while the interface is unlocked (bars with no title).</summary>
    protected bool DragAnywhere;
    private bool _dragging;
    private Vector2 _dragGrab;

    /// <summary>
    /// A tabbed element (type 8): its tab buttons show their pages (property 0x2E pairs each tab with its page,
    /// one starting chosen); the chosen tab looks Open, the others Closed. Returns the pages in tab order (left to
    /// right) and a way to choose one.
    /// </summary>
    protected (List<UiNode> tabs, List<UiNode> pages, Action<int> choose) TabsFrom(UiNode? tabbed, Action<int>? chosen = null)
    {
        var tabs = new List<UiNode>(); var pages = new List<UiNode>();
        if (tabbed == null || !tabbed.R.Props.TryGetValue(0x2E, out var p) || p is not ArrayBaseProperty arr) return (tabs, pages, _ => { });
        int start = 0;
        var pairs = new List<(UiNode tab, UiNode page, bool on)>();
        foreach (var it in arr.Value)
        {
            if (it is not StructBaseProperty st) continue;
            uint tid = st.Value.TryGetValue(48, out var a) && a is EnumBaseProperty ea ? ea.Value : 0;
            uint pid = st.Value.TryGetValue(49, out var b) && b is EnumBaseProperty eb ? eb.Value : 0;
            bool on = st.Value.TryGetValue(50, out var c) && c is BoolBaseProperty bc && bc.Value;
            if (tabbed.Find(tid) is { } tn && tabbed.Find(pid) is { } pn) pairs.Add((tn, pn, on));
        }
        pairs.Sort((x, y) => x.tab.Position.X.CompareTo(y.tab.Position.X));
        for (int i = 0; i < pairs.Count; i++) { tabs.Add(pairs[i].tab); pages.Add(pairs[i].page); if (pairs[i].on) start = i; }
        void Choose(int i)
        {
            for (int k = 0; k < pairs.Count; k++)
            {
                pages[k].Visible = k == i;
                tabs[k].SetState(k == i ? DatReaderWriter.Enums.UIStateId.Open : DatReaderWriter.Enums.UIStateId.Closed);
            }
            chosen?.Invoke(i);
        }
        for (int i = 0; i < tabs.Count; i++)
        {
            int ii = i;
            tabs[i].OnInput = e => { if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true }) { Choose(ii); tabs[ii].AcceptEvent(); } };
            tabs[i].CenterText();
        }
        if (tabs.Count > 0) Choose(start);
        return (tabs, pages, Choose);
    }

    /// <summary>Pieces the layout starts hidden (property 0x3B), e.g. the other frame style.</summary>
    private static void HideDefaults(UiNode n)
    {
        if (n.R.Props.TryGetValue(0x3B, out var p) && p is BoolBaseProperty b && b.Value) n.Visible = false;
        foreach (var c in n.GetChildren()) if (c is UiNode u) HideDefaults(u);
    }

    // the layout's handles: edge and corner pieces (types 9 and 2) that say which sides they move
    // (0x2A bottom, 0x2B left, 0x2C right, 0x2D top)
    private void Hook(UiNode n)
    {
        if ((n.R.Type == 9 || n.R.Type == 2) && n.Visible)
        {
            bool B(uint k) => n.R.Props.TryGetValue(k, out var p) && p is BoolBaseProperty b && b.Value;
            bool bottom = B(0x2A), left = B(0x2B), right = B(0x2C), top = B(0x2D);
            if (bottom || left || right || top)
            {
                n.MouseDefaultCursorShape = (left || right) && (top || bottom) ? ((left && top) || (right && bottom) ? CursorShape.Fdiagsize : CursorShape.Bdiagsize)
                                           : (left || right) ? CursorShape.Hsize : CursorShape.Vsize;
                bool down = false; Vector2 from = Vector2.Zero, startPos = Vector2.Zero, startSize = Vector2.Zero;
                n.OnInput = e =>
                {
                    if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb)
                    {
                        // (the interface locked: its edges don't drag - it stays its size)
                        bool was = down;
                        down = mb.Pressed && !UiLock.Locked; from = GetGlobalMousePosition(); startPos = Position; startSize = Size;
                        if (!mb.Pressed && was) Save();
                        n.AcceptEvent();
                    }
                    else if (e is InputEventMouseMotion && down)
                    {
                        var d = GetGlobalMousePosition() - from;
                        var size = startSize; var pos = startPos;
                        if (right) size.X = startSize.X + d.X;
                        if (bottom) size.Y = startSize.Y + d.Y;
                        if (left) size.X = startSize.X - d.X;
                        if (top) size.Y = startSize.Y - d.Y;
                        size = size.Clamp(_min, _max);
                        if (left) pos.X = startPos.X + startSize.X - size.X;
                        if (top) pos.Y = startPos.Y + startSize.Y - size.Y;
                        Position = pos;
                        SetSize2(size);
                        n.AcceptEvent();
                    }
                };
            }
        }
        foreach (var c in n.GetChildren()) if (c is UiNode u) Hook(u);
    }

    /// <summary>Makes an element the window's title: dragging it moves the window.</summary>
    protected void TitleFrom(UiNode? title)
    {
        if (title == null) return;
        bool down = false; Vector2 grab = Vector2.Zero;
        title.OnInput = e =>
        {
            if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb) { down = mb.Pressed; grab = GetGlobalMousePosition() - Position; if (!mb.Pressed) Save(); title.AcceptEvent(); }
            else if (e is InputEventMouseMotion && down && !UiLock.Locked) { Position = OnScreen(GetGlobalMousePosition() - grab); title.AcceptEvent(); }
        };
    }

    /// <summary>Makes an element the window's close button.</summary>
    protected void CloseFrom(UiNode? close)
    {
        if (close == null) return;
        CloseNode = close;
        close.OnInput = e =>
        {
            if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb)
            {
                close.SetState(mb.Pressed ? DatReaderWriter.Enums.UIStateId.Normal_pressed : DatReaderWriter.Enums.UIStateId.Normal);
                if (!mb.Pressed) { Visible = false; Closed?.Invoke(); }
                close.AcceptEvent();
            }
        };
    }

    public Action? Closed;

    /// <summary>A place for the window that keeps all of it on the screen.</summary>
    protected Vector2 OnScreen(Vector2 at)
    {
        var vp = GetViewportRect().Size;
        return new Vector2(Math.Clamp(at.X, 0, Math.Max(0, vp.X - Size.X)), Math.Clamp(at.Y, 0, Math.Max(0, vp.Y - Size.Y)));
    }
    /// <summary>The window's X (kept its own size, at the right, as the window is sized).</summary>
    protected UiNode? CloseNode;

    protected virtual void SetSize2(Vector2 size)
    {
        CustomMinimumSize = size;
        Size = size;
        Root?.Resize(size);
        Resized2();
    }

    /// <summary>After it changed size (for what's laid over it by hand).</summary>
    protected virtual void Resized2() { }

    public override void _GuiInput(InputEvent e)
    {
        // a click on the window itself (not the world under it); with the interface unlocked a bar drags about
        if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb && DragAnywhere)
        {
            _dragging = mb.Pressed && !UiLock.Locked; _dragGrab = GetGlobalMousePosition() - Position;
            if (!mb.Pressed) Save();
        }
        else if (e is InputEventMouseMotion && _dragging) Position = OnScreen(GetGlobalMousePosition() - _dragGrab);
        if (e is InputEventMouseButton) AcceptEvent();
    }

    private void Load()
    {
        var cfg = new ConfigFile();
        if (global::ACGodot.SafeConfig.Load(cfg, SavePath) != Error.Ok || SaveKey.Length == 0) return;
        if (cfg.HasSectionKey("windows", SaveKey + "_at")) Position = (Vector2)cfg.GetValue("windows", SaveKey + "_at");
        if (cfg.HasSectionKey("windows", SaveKey + "_size")) SetSize2(((Vector2)cfg.GetValue("windows", SaveKey + "_size")).Clamp(_min, _max));
    }

    protected void Save()
    {
        if (SaveKey.Length == 0) return;
        var cfg = new ConfigFile();
        global::ACGodot.SafeConfig.Load(cfg, SavePath);
        cfg.SetValue("windows", SaveKey + "_at", Position);
        cfg.SetValue("windows", SaveKey + "_size", Size);
        global::ACGodot.SafeConfig.Save(cfg, SavePath);
    }

    /// <summary>A text box laid over an element of the layout, in the game's font, filling it and following its size.</summary>
    protected static RichTextLabel TextOver(UiNode at, Color? color = null)
    {
        var t = new RichTextLabel
        {
            // the text can be highlighted with the mouse and copied (Ctrl+C, or right-click > Copy)
            BbcodeEnabled = true, ScrollActive = true, ScrollFollowing = false, FitContent = false, SelectionEnabled = true, ContextMenuEnabled = true,
            MouseFilter = MouseFilterEnum.Pass, FocusMode = FocusModeEnum.Click,
        };
        t.SetAnchorsPreset(LayoutPreset.FullRect);
        if (RetailTheme.TextFont != null) { t.AddThemeFontOverride("normal_font", RetailTheme.TextFont); t.AddThemeFontSizeOverride("normal_font_size", RetailTheme.Px(RetailTheme.TextSize)); }
        t.AddThemeColorOverride("default_color", color ?? (at.FontStyle != null ? at.TextColor : RetailTheme.Ink));
        t.AddThemeConstantOverride("line_separation", 1);
        if (RetailTheme.Current != null) t.Theme = RetailTheme.Current;
        t.ZIndex = 2;   // over the layout's other pieces (a translucent fill drawn after would dim it)
        at.AddChild(t);
        return t;
    }
}
