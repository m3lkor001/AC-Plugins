using System;
using System.Collections.Generic;
using System.Linq;
using DatReaderWriter.DBObjs;
using DatReaderWriter.Enums;
using DatReaderWriter.Types;
using Godot;
using CharGenData = DatReaderWriter.DBObjs.CharGen;

namespace ACGodot.UI;

/// <summary>
/// The game's own character creation screen (layout 0x21000038 and its pages 0x21000046-4B, built from the data files
/// as the retail client drew it): Heritage, Profession (attributes), Skills, Appearance, Town and Summary, the tab bar
/// across the top, the arrows / Help / Exit / Random / Finish along the bottom. What each part does follows the retail
/// client (screenshots of it, 24 Nov 2026); the texts are the game's own string table's. Drawn at 800 x 600 and scaled
/// to the window. The new character goes to the server in the game's creation message (NetGame.CreateCharacter).
/// </summary>
public partial class CharGen : Control
{
    public Dats Dats = null!;
    public global::ACGodot.Creatures.CreatureAssets? Looks;
    /// <summary>Ask the server for the character; false if it couldn't be asked (not at the character screen).</summary>
    public Func<Net.NewCharacter, bool>? Create;
    /// <summary>Back to the character list (Exit).</summary>
    public Action? Exit;

    private const uint Screen = 0x21000038, Widgets = 0x2100004C, Strings = 0x23000002;
    private static readonly string[] Pages = { "Heritage", "Profession", "Skills", "Appearance", "Town", "Summary" };
    private static readonly uint[] TabIds = { 0x100003EF, 0x100003F0, 0x100003F1, 0x100003F2, 0x100003F3, 0x100003F4 };
    private static readonly uint[] PageIds = { 0x100003D1, 0x100003D2, 0x100003D3, 0x100003D4, 0x100003D5, 0x100003D6 };

    private RetailUi _ui = null!;
    private Control _stage = null!;
    private UiNode _root = null!;
    private CharGenData _gen = null!;
    private SkillTable _skills = null!;
    private bool _built;
    private int _page;

    // ── the choices ──
    private uint _heritage = 1;
    private int _gender = 1;
    private int _template;                       // index in the heritage's Templates (0 = Custom / "Adventurer")
    private readonly int[] _attr = new int[6];   // strength, endurance, coordination, quickness, focus, self
    private readonly bool[] _lock = new bool[6];
    private readonly Dictionary<int, int> _train = new();   // skill id -> 1 untrained, 2 trained, 3 specialized
    private int _town;
    private int _hairStyle, _hairColor, _eyes, _eyeColor, _nose, _mouth;
    private int _headgear = -1, _shirt, _pants, _shoes;      // (-1: no headgear)
    private int _headColor, _shirtColor, _pantsColor, _shoesColor;   // places in the clothing colours
    private float _skinHue = 0.5f, _hairHue = 0.5f, _headHue = 0.5f, _shirtHue = 0.5f, _pantsHue = 0.5f, _shoesHue = 0.5f;
    private bool _clothes;       // the appearance page on clothes (else the face)
    private int _row;            // the appearance row whose colour the wheel changes
    private int _skillPick = -1; // the skill whose description shows

    // ── pieces wired up ──
    private readonly List<(uint heritage, UiNode node)> _heritageRadios = new();
    private readonly List<(int template, UiNode node)> _jobRadios = new();
    private RetailText _heritageText = null!, _jobText = null!, _skillName = null!, _skillDesc = null!, _skillHelp = null!,
                       _lookHelp = null!, _townText = null!, _summary = null!, _summaryHelp = null!;
    private readonly List<RetailSlider> _sliders = new();
    private Control _skillList = null!;
    private RetailScroll? _skillScroll;
    private float _skillTop;
    private readonly List<UiNode> _skillRows = new();
    private Preview? _lookView, _summaryView;
    private LineEdit _nameBox = null!;
    private Label _tip = null!;
    private Panel _tipBox = null!;
    private string? _tipText;
    private double _tipAt;
    private Panel? _msgBox;

    // the game's texts for the heritages, professions and towns (its string table 0x23000002)
    private static readonly Dictionary<uint, uint> HeritageText = new()
    {
        [1] = 0x04BF27A4, [2] = 0x03E311E4, [3] = 0x05633754, [4] = 0x00413754, [5] = 0x050016A4, [6] = 0x00FE11E4,
        [7] = 0x014011B4, [8] = 0x0F0B3714, [9] = 0x08F23724, [10] = 0x050016A4, [11] = 0x08FE3754, [12] = 0x01214F24, [13] = 0x08E00424,
    };
    private static readonly Dictionary<uint, uint> RacialText = new()
    {
        [1] = 0x0206BBD4, [2] = 0x0630F8A4, [3] = 0x06166A24, [4] = 0x00166F04, [5] = 0x0335BA44, [6] = 0x0D30FF94,
        [7] = 0x0330CE04, [8] = 0x0E162C44, [9] = 0x01163794, [10] = 0x0335BA44, [11] = 0x0D166794, [12] = 0x032337A4, [13] = 0x006E3E64,
    };
    private static readonly Dictionary<string, uint> JobText = new()
    {
        ["Adventurer"] = 0x04FFCB24, ["Bow Hunter"] = 0x05DB3724, ["Life Caster"] = 0x04B31214, ["War Mage"] = 0x01303754,
        ["Wayfarer"] = 0x01393754, ["Soldier"] = 0x046159C4, ["Swashbuckler"] = 0x0F060A94,
    };
    private static readonly uint[] TownText = { 0x0F4011C4, 0x024BCDA4, 0x0F1D0FC4, 0x08227F04 };   // Holtburg, Shoushi, Yaraq, Sanamar
    private static readonly string[] TownState = { "Holtburg", "Shoushi", "Yaraq", "Sanamar" };
    // naming advice on the summary page, by heritage and sex (male, female)
    private static readonly Dictionary<uint, (uint m, uint f)> NameText = new()
    {
        [1] = (0x0F6C9913, 0x0A817D03), [2] = (0x07745DB3, 0x02C5D553), [3] = (0x08D23913, 0x04E17AF3), [4] = (0x08A05913, 0x06C17A43),
        [5] = (0x07D46B23, 0x029365F3), [6] = (0x03948B73, 0x0D731143), [7] = (0x06906B73, 0x069314B3), [8] = (0x02617E53, 0x0C74B913),
        [9] = (0x0F2B4913, 0x0DB17CC3), [10] = (0x07D46B23, 0x029365F3), [11] = (0x08148913, 0x0D7179C3), [12] = (0x0F2A49C3, 0x0CB24CC3),
        [13] = (0x00A6FDB3, 0x0F967E93),
    };
    // the heritage list's order on the page, and each one's picture
    private static readonly (uint id, string picture)[] HeritageOrder =
    {
        (1, "Aluvian"), (2, "Gharundim"), (3, "Sho"), (4, "Viamont"), (5, "Shadow"), (10, "Penumbraen"), (6, "Gearknight"),
        (11, "Undead"), (9, "Empyrean"), (7, "Auntumerok"), (8, "Lugian"), (12, "Olthoi"), (13, "Olthoiacid"),
    };
    private static readonly uint[] HeritageRadioIds = { 0x100003BF, 0x100003C1, 0x100003C2, 0x100003C3, 0x10000590, 0x10000591, 0x100005A9, 0x100005BF, 0x100005C4, 0x100005E8, 0x100005F1, 0x100005C7, 0x100005C8 };
    // the professions in the page's order (the data's "Adventurer" is the page's Custom), and their pictures
    private static readonly (string name, string picture, uint radio)[] JobOrder =
    {
        ("Adventurer", "Custom", 0x100003D9), ("Bow Hunter", "Bow_hunter", 0x100003DA), ("Life Caster", "Life_caster", 0x100003DB),
        ("War Mage", "War_mage", 0x100003DC), ("Wayfarer", "Wayfarer", 0x100003DD), ("Soldier", "Soldier", 0x100003DE), ("Swashbuckler", "Swashbuckler", 0x100003DF),
    };
    private static readonly string[] AttrNames = { "Strength", "Endurance", "Coordination", "Quickness", "Focus", "Self" };
    private static readonly uint[] AttrRows = { 0x100003E6, 0x100003E7, 0x100003E8, 0x100003E9, 0x100003EA, 0x100003EB };
    private static readonly uint[] FaceRows = { 0x100003AF, 0x100003B0, 0x100003B1, 0x100003B2, 0x100003B3 };   // hair style, eyes, nose, mouth, skin
    private static readonly uint[] ClothesRows = { 0x100003B5, 0x100003B6, 0x100003B7, 0x100003B8 };           // headgear, shirt, trousers, footwear
    private static readonly uint[] Swatches = { 0x1000030F, 0x10000310, 0x10000311, 0x10000312, 0x10000313, 0x10000314, 0x10000315, 0x10000316, 0x10000317 };
    private static readonly uint[] SwatchDots = { 0x10000318, 0x10000319, 0x1000031A, 0x1000031B, 0x1000031C, 0x1000031D, 0x1000031E, 0x1000031F, 0x10000320 };
    private static readonly uint[] TownMarks = { 0x1000040D, 0x1000040F, 0x1000040E, 0x1000040B };   // Holtburg, Shoushi, Yaraq, Sanamar

    public CharGen()
    {
        SetAnchorsPreset(LayoutPreset.FullRect);
        MouseFilter = MouseFilterEnum.Stop;
        Visible = false;
    }

    // ── opening ──

    /// <summary>Opens the screen on a new character (Aluvian, male, Bow Hunter, Holtburg, as the retail client starts).</summary>
    public bool Open()
    {
        if (!_built && !Build()) return false;
        _heritage = 1; _gender = 1; _town = 0; _clothes = false; _row = 0; _skillPick = -1;
        _nameBox.Text = "";
        Array.Clear(_lock);
        PickHeritage(1, keepLooks: false);
        PickTemplate(TemplateIndex("Bow Hunter"));
        ShowPage(0);
        Visible = true;
        Fit();
        return true;
    }

    public void Close() { Visible = false; HideMessage(); }

    /// <summary>The server said no: why, in a box over the screen.</summary>
    public void Failed(string why) => ShowMessage(why);

    private bool Build()
    {
        _ui = RetailUi.Current!;
        if (_ui == null) return false;
        try
        {
            _gen = Dats.Portal<CharGenData>(0x0E000002)!;
            _skills = Dats.Portal<SkillTable>(Combat.Character.SkillTableId)!;
        }
        catch (Exception ex) { GD.PushWarning("character creation data: " + ex.Message); return false; }
        if (_gen == null || _skills == null) return false;
        var root = _ui.Build(Screen);
        if (root == null) return false;
        _root = root;
        _stage = new Control { MouseFilter = MouseFilterEnum.Pass, Size = new Vector2(800, 600) };
        AddChild(_stage);
        _stage.AddChild(_root);
        _root.Position = Vector2.Zero;
        // every page made visible or hidden by us (the layout switches them by state; set on the pages' parent that
        // would also set every element inside them to that state)
        for (int i = 0; i < PageIds.Length; i++) if (N(PageIds[i]) is { } p) p.Visible = i == 0;
        Native(_root);
        FirstStates(_root);
        Frame(N(0x1000040A));
        WireFrame();
        WireHeritage();
        WireProfession();
        WireSkills();
        WireAppearance();
        WireTown();
        WireSummary();
        WireTips(_root);
        _tipBox = new Panel { Visible = false, MouseFilter = MouseFilterEnum.Ignore, ZIndex = 50 };
        _tipBox.AddThemeStyleboxOverride("panel", new StyleBoxFlat { BgColor = new Color(0.02f, 0.02f, 0.04f, 0.92f), BorderColor = new Color(0.75f, 0.6f, 0.3f),
                                                                      BorderWidthLeft = 1, BorderWidthTop = 1, BorderWidthRight = 1, BorderWidthBottom = 1 });
        _tip = new Label { AutowrapMode = TextServer.AutowrapMode.WordSmart, Position = new Vector2(4, 2), MouseFilter = MouseFilterEnum.Ignore };
        if (RetailTheme.TextFont != null) _tip.AddThemeFontOverride("font", RetailTheme.TextFont);
        _tip.AddThemeFontSizeOverride("font_size", 11);
        _tip.AddThemeColorOverride("font_color", new Color(1f, 0.95f, 0.85f));
        _tipBox.AddChild(_tip);
        _stage.AddChild(_tipBox);
        Resized += Fit;
        _built = true;
        return true;
    }

    /// <summary>The game's own letters at their own size in all of it (the screen is drawn at 800 x 600 and scaled whole).</summary>
    private static void Native(Node n) => RetailScreen.Native(n);

    /// <summary>A label's number at the right of it (the layout's number sits at its narrower base's right edge).</summary>
    private static void NumberRight(UiNode? row, uint number, float past = 0)
    {
        if (row?.Find(number) is not { } n) return;
        n.Pinned = true;
        n.Position = new Vector2(row.Size.X - n.Size.X + past, n.Position.Y);
    }

    /// <summary>
    /// Every element back in its own first state: building the screen put them all in the page container's state
    /// ("Heritage"), which most don't have - so the appearance rows' arrow buttons had no picture at all.
    /// </summary>
    private static void FirstStates(Node n) => RetailScreen.FirstStates(n);

    /// <summary>A plain box of the layout's (a 2100004C 0x100002DD: corners, edges) bigger than it was drawn for: its
    /// border laid out round its real size (the town map's frame - its border was left as a small square in its corner).</summary>
    private static void Frame(UiNode? box)
    {
        if (box == null) return;
        float w = box.Size.X, h = box.Size.Y;
        void At(uint id, float x, float y, float? sw = null, float? sh = null)
        {
            foreach (var c in box.GetChildren())
                if (c is UiNode n && n.Id == id)
                {
                    n.Pinned = true;
                    n.Position = new Vector2(x, y);
                    if (sw != null || sh != null) n.Size = new Vector2(sw ?? n.Size.X, sh ?? n.Size.Y);
                }
        }
        At(0x100002DE, 0, 0); At(0x100002DF, w - 34, 0); At(0x100002E0, 0, h - 35); At(0x100002E1, w - 34, h - 35);
        At(0x100002E2, 34, 0, w - 68, 7); At(0x100002E3, 34, h - 7, w - 68, 7);
        At(0x100000E8, 0, 34, 5, h - 69); At(0x100000EA, w - 5, 34, 5, h - 69);
    }

    private void Fit() => RetailScreen.Fit(this, _stage);

    private UiNode? N(uint id) => _root.Find(id);
    private UiNode? In(UiNode? parent, uint id) => parent?.Find(id);
    private string Text(uint id)
    {
        try
        {
            var t = Dats.Get<StringTable>(Strings);
            if (t != null && t.Strings.TryGetValue(id, out var s) && s.Strings.Count > 0) return string.Concat(s.Strings).Replace("\\n", "\n").Replace("\r", "");
        }
        catch { }
        return "";
    }
    private static UIStateId State(string name) => RetailScreen.State(name);

    /// <summary>A radio button's words at the left, past its round button (the layout's left margin, property 0x23).</summary>
    private static void RadioText(UiNode? n)
    {
        if (n == null) return;
        n.TextLeft = n.R.Props.TryGetValue(0x23, out var p) && p is IntegerBaseProperty ip ? ip.Value : 40;
        n.SetTextAlign(1);
    }

    /// <summary>A left click on it does something; it shows its rollover look while the mouse is over it.</summary>
    private static void Click(UiNode? n, Action act, bool rollover = true)
    {
        if (n == null) return;
        n.OnInput = e => { if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true }) act(); };
        if (!rollover) return;
        var over = State("Normal_rollover");
        if (n.R.States.ContainsKey(over))
        {
            n.MouseEntered += () => { if (n.CurrentState == UIStateId.Normal) n.SetState(over); };
            n.MouseExited += () => { if (n.CurrentState == over) n.SetState(UIStateId.Normal); };
        }
    }

    // ── tooltips: an element's own help line (property 0x49), after a moment over it ──

    private void WireTips(Node n)
    {
        foreach (var c in n.GetChildren())
        {
            if (c is not UiNode u) continue;
            if (u.R.Props.TryGetValue(0x49, out var p) && p is StringInfoBaseProperty si && _ui.String(si.Value) is { Length: > 0 } words)
            {
                if (u.MouseFilter == MouseFilterEnum.Ignore) u.MouseFilter = MouseFilterEnum.Pass;
                u.MouseEntered += () => { _tipText = words; _tipAt = Time.GetTicksMsec() / 1000.0 + 0.6; };
                u.MouseExited += () => { if (_tipText == words) { _tipText = null; _tipBox.Visible = false; } };
            }
            WireTips(u);
        }
    }

    public override void _Process(double delta)
    {
        if (!Visible || !_built) return;
        double now = Time.GetTicksMsec() / 1000.0;
        if (_tipText != null && now >= _tipAt && !_tipBox.Visible)
        {
            _tip.Text = _tipText;
            _tip.Size = new Vector2(230, 0);
            _tip.CustomMinimumSize = new Vector2(230, 0);
            var need = _tip.GetCombinedMinimumSize();
            _tipBox.Size = new Vector2(238, need.Y + 6);
            var m = _stage.GetLocalMousePosition();
            var at = m + new Vector2(14, 18);
            if (at.X + _tipBox.Size.X > 800) at.X = m.X - _tipBox.Size.X - 6;
            if (at.Y + _tipBox.Size.Y > 600) at.Y = m.Y - _tipBox.Size.Y - 6;
            _tipBox.Position = at;
            _tipBox.Visible = true;
        }
    }

    // ── the frame: tabs, arrows, Help / Exit / Random / Finish ──

    private void WireFrame()
    {
        for (int i = 0; i < TabIds.Length; i++) { int page = i; Click(N(TabIds[i]), () => ShowPage(page), rollover: false); }
        Click(N(0x100003C6), () => { if (_page > 0) ShowPage(_page - 1); });
        Click(N(0x100003C7), () => { if (_page < Pages.Length - 1) ShowPage(_page + 1); });
        Click(N(0x100003C8), Finish);
        Click(N(0x100003C9), () => ShowMessage("There's no in-game help here - hover over anything for a description of it."));
        Click(N(0x100003CA), () => { Close(); Exit?.Invoke(); });
        Click(N(0x100003CB), RandomPage);
    }

    /// <summary>A page shown (the test bridge: 0 Heritage .. 5 Summary).</summary>
    public void TestPage(int page) { if (page >= 0 && page < Pages.Length) ShowPage(page); }

    private void ShowPage(int page)
    {
        _page = page;
        for (int i = 0; i < PageIds.Length; i++) if (N(PageIds[i]) is { } p) p.Visible = i == page;
        for (int i = 0; i < TabIds.Length; i++) N(TabIds[i])?.SetState(i == page ? UIStateId.Highlight : UIStateId.Normal);
        // the left arrow from the second page on; the right arrow till the summary, where Finish takes its place
        if (N(0x100003C6) is { } back) back.Visible = page > 0;
        if (N(0x100003C7) is { } next) next.Visible = page < Pages.Length - 1;
        if (N(0x100003C8) is { } fin) fin.Visible = page == Pages.Length - 1;
        _tipBox.Visible = false; _tipText = null;
        if (Pages[page] == "Skills") ShowSkills();
        if (Pages[page] == "Summary") ShowSummary();
        if (Pages[page] is "Appearance" or "Summary") ShowLook();
    }

    // ── Heritage ──

    private HeritageGroupCG Heritage => _gen.HeritageGroups[_heritage];
    private SexCG Sex => Heritage.Genders.TryGetValue(_gender, out var s) ? s : Heritage.Genders.Values.First();

    private void WireHeritage()
    {
        for (int i = 0; i < HeritageOrder.Length && i < HeritageRadioIds.Length; i++)
        {
            uint id = HeritageOrder[i].id;
            if (N(HeritageRadioIds[i]) is not { } r) continue;
            if (!_gen.HeritageGroups.ContainsKey(id)) { r.Visible = false; continue; }
            _heritageRadios.Add((id, r));
            RadioText(r);
            Click(r, () => PickHeritage(id, keepLooks: false), rollover: false);
        }
        _heritageText = TextBox(N(0x100003C4), N(0x100003C4)?.Find(0x100002E7));
    }

    private void PickHeritage(uint id, bool keepLooks)
    {
        if (!_gen.HeritageGroups.ContainsKey(id)) return;
        _heritage = id;
        if (!Heritage.Genders.ContainsKey(_gender)) _gender = Heritage.Genders.Keys.Min();
        foreach (var (h, node) in _heritageRadios) node.SetState(h == id ? UIStateId.Selected : UIStateId.Unselected);
        var pic = HeritageOrder.FirstOrDefault(x => x.id == id).picture;
        if (pic != null) N(0x100003BE)?.SetState(State(pic));
        // the text: trained starting skills, the racial bonus, then the heritage's story
        string trained = string.Join(", ", FreeSkills().Select(SkillName));
        int last = trained.LastIndexOf(", ", StringComparison.Ordinal);
        if (last >= 0) trained = trained[..last] + " and " + trained[(last + 2)..];
        string text = "";
        var everyone = ChargenSkills().Where(x => x.s.TrainedCost == 0).Select(x => x.id).ToList();
        trained = string.Join(", ", everyone.Select(SkillName));
        last = trained.LastIndexOf(", ", StringComparison.Ordinal);
        if (last >= 0) trained = trained[..last] + " and " + trained[(last + 2)..];
        if (everyone.Count > 0) text += RetailText.Color(1) + Text(0x0F9C8FC2).TrimEnd('\n') + RetailText.Color(0) + "\n" + trained + ".\n\n";
        if (RacialText.TryGetValue(id, out var rt)) text += RetailText.Color(1) + Text(0x004B7EE2).TrimEnd('\n') + RetailText.Color(0) + "\n" + Text(rt);
        if (HeritageText.TryGetValue(id, out var ht)) text += Text(ht);
        _heritageText.Text = text.TrimEnd();
        // a heritage's own skill costs and its towns: the professions' skills worked out again, the town its first
        PickTemplate(Math.Min(_template, Heritage.Templates.Count - 1));
        var towns = Towns();
        if (!towns.Contains(_town)) _town = towns.Count > 0 ? towns[0] : 0;
        ShowTown();
        if (!keepLooks) RandomLooks(sameEach: true);
    }

    // ── Profession and attributes ──

    private int TemplateIndex(string name)
    {
        for (int i = 0; i < Heritage.Templates.Count; i++) if (Heritage.Templates[i].Name.Value == name) return i;
        return 0;
    }

    private void WireProfession()
    {
        foreach (var (name, _, radio) in JobOrder)
        {
            if (N(radio) is not { } r) continue;
            string nm = name;
            _jobRadios.Add((-1, r));
            RadioText(r);
            Click(r, () => PickTemplate(TemplateIndex(nm)), rollover: false);
        }
        _jobText = TextBox(N(0x100003E0), null);
        TextBox(N(0x100003EC), null);   // (the page's own hint across the top)
        NumberRight(N(0x100003E2), 0x100002F1);
        foreach (uint v in new uint[] { 0x100003E3, 0x100003E4, 0x100003E5 }) NumberRight(N(v), 0x100002F3);
        for (int i = 0; i < 6; i++)
        {
            int a = i;
            var row = N(AttrRows[i]);
            if (row == null) { _sliders.Add(null!); continue; }
            if (In(row, 0x100002ED) is { } label) { label.Text = AttrNames[i]; label.CenterText(); label.SetTextAlign(1); }
            Click(In(row, 0x100002EC), () => { _lock[a] = !_lock[a]; ShowAttributes(); }, rollover: false);
            var slider = new RetailSlider(In(row, 0x100002EE), 10, 100) { Changed = v => SetAttribute(a, v) };
            _sliders.Add(slider);
        }
    }

    private void PickTemplate(int index)
    {
        var tpl = Heritage.Templates;
        if (tpl.Count == 0) return;
        _template = Math.Clamp(index, 0, tpl.Count - 1);
        var t = tpl[_template];
        // the data's "Adventurer" (Custom): attributes left even, nothing trained but what everyone gets
        _attr[0] = (int)t.Strength; _attr[1] = (int)t.Endurance; _attr[2] = (int)t.Coordination;
        _attr[3] = (int)t.Quickness; _attr[4] = (int)t.Focus; _attr[5] = (int)t.Self;
        foreach (var (name, picture, radio) in JobOrder)
            if (N(radio) is { } r) r.SetState(name == t.Name.Value ? UIStateId.Selected : UIStateId.Unselected);
        var pic = JobOrder.FirstOrDefault(j => j.name == t.Name.Value).picture;
        if (pic != null) N(0x100003D8)?.SetState(State(pic));
        _jobText.Text = JobText.TryGetValue(t.Name.Value, out var jt) ? Text(jt) : "";
        ResetSkills();
        foreach (var sk in t.NormalSkills) _train[(int)sk] = 2;
        foreach (var sk in t.PrimarySkills) _train[(int)sk] = 3;
        ShowAttributes();
    }

    private int AttributeTotal => (int)Heritage.AttributeCredits;
    private int AttributeCredits => AttributeTotal - _attr.Sum();

    /// <summary>
    /// An attribute moved: credits left are used first; with none left, the other unlocked attributes give up what's
    /// needed (evenly), as the retail sliders do. Lowering one puts its points back in the credits.
    /// </summary>
    private void SetAttribute(int a, int value)
    {
        value = Math.Clamp(value, 10, 100);
        if (_lock[a]) { ShowAttributes(); return; }
        int need = value - _attr[a];
        if (need > 0)
        {
            int free = Math.Max(0, AttributeCredits);
            int fromFree = Math.Min(free, need);
            int rest = need - fromFree;
            int got = 0;
            while (rest > 0)
            {
                var givers = Enumerable.Range(0, 6).Where(i => i != a && !_lock[i] && _attr[i] > 10).ToList();
                if (givers.Count == 0) break;
                foreach (int g in givers) { if (rest == 0) break; _attr[g]--; rest--; got++; }
            }
            _attr[a] += fromFree + got;
        }
        else _attr[a] = value;
        ShowAttributes();
    }

    private void ShowAttributes()
    {
        for (int i = 0; i < 6; i++)
        {
            var row = N(AttrRows[i]);
            if (row == null) continue;
            var st = _lock[i] ? UIStateId.Locked : UIStateId.Unlocked;
            In(row, 0x100002EC)?.SetState(st);   // (only the lock itself shows it: the bar's fill is the value's)
            _sliders[i]?.Show(_attr[i]);
            if (In(row, 0x100002EF) is { } v) v.Text = _attr[i].ToString();
        }
        if (N(0x100003E2)?.Find(0x100002F1) is { } cr) cr.Text = AttributeCredits.ToString();
        if (N(0x100003E3)?.Find(0x100002F3) is { } h) h.Text = ((_attr[1] + 1) / 2).ToString();
        if (N(0x100003E4)?.Find(0x100002F3) is { } s) s.Text = _attr[1].ToString();
        if (N(0x100003E5)?.Find(0x100002F3) is { } m) m.Text = _attr[5].ToString();
        if (_page == 2) ShowSkills();
    }

    // ── Skills ──

    private IEnumerable<(int id, SkillBase s)> ChargenSkills() =>
        _skills.Skills.Where(kv => kv.Value.ChargenUse).Select(kv => ((int)kv.Key, kv.Value)).OrderBy(x => x.Value.Name.Value);

    private string SkillName(int id) => _skills.Skills.TryGetValue((SkillId)id, out var s) ? s.Name.Value : id.ToString();

    /// <summary>What it costs to train it (the heritage's own cost where it has one; 0: everyone starts trained in it).</summary>
    private int TrainCost(int id)
    {
        foreach (var hs in Heritage.Skills) if ((int)hs.Id == id) return (int)hs.NormalCost;
        return _skills.Skills.TryGetValue((SkillId)id, out var s) ? (int)s.TrainedCost : 999;
    }
    /// <summary>What it costs to go from trained to specialized (999 or more: it can't be).</summary>
    private int SpecCost(int id)
    {
        foreach (var hs in Heritage.Skills) if ((int)hs.Id == id) return (int)hs.PrimaryCost;
        if (!_skills.Skills.TryGetValue((SkillId)id, out var s)) return 999;
        return s.SpecializedCost >= 999 ? 999 : (int)s.SpecializedCost - (int)s.TrainedCost;
    }
    private List<int> FreeSkills() => ChargenSkills().Where(x => TrainCost(x.id) == 0).Select(x => x.id).ToList();

    private void ResetSkills()
    {
        _train.Clear();
        foreach (var (id, _) in ChargenSkills()) _train[id] = TrainCost(id) == 0 ? 2 : 1;
    }

    private int SkillCreditsLeft
    {
        get
        {
            int spent = 0;
            foreach (var (id, lvl) in _train)
            {
                if (lvl >= 2) spent += TrainCost(id);
                if (lvl >= 3) spent += SpecCost(id);
            }
            return (int)Heritage.SkillCredits - spent;
        }
    }

    private int Attr(AttributeId a) => a switch
    {
        AttributeId.Strength => _attr[0], AttributeId.Endurance => _attr[1], AttributeId.Coordination => _attr[2],
        AttributeId.Quickness => _attr[3], AttributeId.Focus => _attr[4], AttributeId.Self => _attr[5], _ => 0,
    };

    private int SkillLevel(int id)
    {
        if (!_skills.Skills.TryGetValue((SkillId)id, out var s)) return 0;
        var f = s.Formula;
        double v = f.Divisor > 0 ? (Attr(f.Attribute1) * (double)f.Attribute1Multiplier + Attr(f.Attribute2) * (double)f.Attribute2Multiplier) / f.Divisor : 0;
        int lvl = (int)Math.Round(v + f.AdditiveBonus, MidpointRounding.AwayFromZero);
        int t = _train.TryGetValue(id, out var x) ? x : 1;
        if (t == 2) lvl += 5; else if (t == 3) lvl += 10;
        else if (s.MinLevel >= 2) lvl = 0;   // (unusable untrained)
        return lvl;
    }

    private void WireSkills()
    {
        var list = N(0x100003F7);
        if (list != null)
        {
            _skillList = new Control { ClipContents = true, MouseFilter = MouseFilterEnum.Pass, Size = list.Size };
            list.AddChild(_skillList);
            _skillList.GuiInput += e =>
            {
                if (e is InputEventMouseButton { Pressed: true, ButtonIndex: MouseButton.WheelUp }) ScrollSkills(-26 * 3);
                if (e is InputEventMouseButton { Pressed: true, ButtonIndex: MouseButton.WheelDown }) ScrollSkills(26 * 3);
            };
            _skillScroll = new RetailScroll(N(0x100003F8)) { Moved = f => { _skillTop = f * Math.Max(0, SkillsHeight - _skillList.Size.Y); LayoutSkills(); }, Step = d => ScrollSkills(d * 26) };
        }
        NumberRight(N(0x100003F9), 0x100002F3, 18);
        _skillName = new RetailText(_ui, N(0x100003FB));
        _skillDesc = new RetailText(_ui, N(0x100003FC));
        _skillHelp = TextBox(N(0x100003FD), null);
    }

    private float SkillsHeight;
    private void ScrollSkills(float by)
    {
        _skillTop = Math.Clamp(_skillTop + by, 0, Math.Max(0, SkillsHeight - _skillList.Size.Y));
        LayoutSkills();
    }

    private void ShowSkills()
    {
        if (_skillList == null) return;
        foreach (var r in _skillRows) r.QueueFree();
        _skillRows.Clear();
        if (N(0x100003F9)?.Find(0x100002F3) is { } cr) cr.Text = SkillCreditsLeft.ToString();
        var all = ChargenSkills().ToList();
        void Section(string title, IEnumerable<(int id, SkillBase s)> skills)
        {
            var these = skills.ToList();
            if (these.Count == 0) return;
            if (_ui.Build(Widgets, 0x100002F4) is { } head)
            {
                if (head.Find(0x100002F6) is { } t) t.Text = title;
                _skillRows.Add(head);
            }
            foreach (var (id, s) in these) if (SkillRow(id, s) is { } row) _skillRows.Add(row);
        }
        int T(int id) => _train.TryGetValue(id, out var t) ? t : 1;
        Section("Specialized Skills", all.Where(x => T(x.id) == 3));
        Section("Trained Skills", all.Where(x => T(x.id) == 2));
        Section("Useable Untrained Skills", all.Where(x => T(x.id) <= 1 && x.s.MinLevel < 2));
        Section("Unuseable Untrained Skills", all.Where(x => T(x.id) <= 1 && x.s.MinLevel >= 2));
        foreach (var r in _skillRows) { Native(r); _skillList.AddChild(r); }
        SkillsHeight = _skillRows.Sum(r => r.Size.Y);
        _skillTop = Math.Clamp(_skillTop, 0, Math.Max(0, SkillsHeight - _skillList.Size.Y));
        LayoutSkills();
        ShowSkillPick();
    }

    private void LayoutSkills()
    {
        float y = -_skillTop;
        foreach (var r in _skillRows) { r.Position = new Vector2(0, y); y += r.Size.Y; }
        _skillScroll?.Show(SkillsHeight <= _skillList.Size.Y ? 0f : _skillTop / Math.Max(1f, SkillsHeight - _skillList.Size.Y));
    }

    private UiNode? SkillRow(int id, SkillBase s)
    {
        var row = _ui.Build(Widgets, 0x100002FF);
        if (row == null) return null;
        int t = _train.TryGetValue(id, out var x) ? x : 1;
        int up = t <= 1 ? TrainCost(id) : t == 2 ? SpecCost(id) : 0;
        int down = t == 3 ? SpecCost(id) : t == 2 ? TrainCost(id) : 0;
        bool canUp = t < 3 && up < 999 && up <= SkillCreditsLeft;
        bool canDown = t >= 2 && !(t == 2 && TrainCost(id) == 0) && !IsTemplateLocked(id);
        var hi = id == _skillPick ? UIStateId.Highlight : UIStateId.Normal;
        if (row.Find(0x10000301) is { } nm) { nm.Text = s.Name.Value; nm.SetTextAlign(1); nm.SetState(t >= 2 || id == _skillPick ? UIStateId.Highlight : UIStateId.Normal); }
        if (row.Find(0x10000302) is { } lv) { lv.Text = SkillLevel(id).ToString(); lv.SetState(hi); }
        if (row.Find(0x10000303) is { } uc) { uc.Text = t < 3 && up < 999 ? up.ToString() : ""; uc.SetState(hi); }
        if (row.Find(0x10000306) is { } dc) { dc.Text = t >= 2 ? down.ToString() : "0"; dc.SetState(hi); dc.SetTextAlign(1); }
        if (row.Find(0x10000304) is { } ua) { ua.SetState(canUp ? State("Active") : State("Inactive")); Click(ua, () => { if (canUp) { _train[id] = t + 1; _skillPick = id; ShowSkills(); } }, rollover: false); }
        if (row.Find(0x10000305) is { } da) { da.SetState(canDown ? State("Active") : State("Inactive")); Click(da, () => { if (canDown) { _train[id] = t - 1; _skillPick = id; ShowSkills(); } }, rollover: false); }
        // a click on the row: its description below the list
        row.MouseFilter = MouseFilterEnum.Pass;
        row.GuiInput += e => { if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true }) { _skillPick = id; ShowSkills(); } };
        return row;
    }

    // (a skill the heritage trains for free can't be untrained; the retail client lets a profession's be changed)
    private bool IsTemplateLocked(int id) => false;

    private void ShowSkillPick()
    {
        if (_skillPick < 0 || !_skills.Skills.TryGetValue((SkillId)_skillPick, out var s)) { _skillName.Text = ""; _skillDesc.Text = ""; return; }
        _skillName.Text = $"{s.Name.Value} ({SkillLevel(_skillPick)})";
        string formula = "";
        var f = s.Formula;
        if (f.Divisor > 0 && f.Attribute1Multiplier > 0)
        {
            string a1 = f.Attribute1.ToString(), a2 = f.Attribute2Multiplier > 0 ? f.Attribute2.ToString() : "";
            formula = f.Divisor == 1 && a2 == "" ? a1 : a2 == "" ? $"{a1} / {f.Divisor}" : $"({a1} + {a2}) / {f.Divisor}";
        }
        int t = _train.TryGetValue(_skillPick, out var x) ? x : 1;
        string bonus = t == 3 ? "Specialized Bonus : +10\n" : t == 2 ? "Training Bonus : +5\n" : "";
        _skillDesc.Text = "\n" + s.Description.Value + "\n" + bonus + "Formula : " + formula;
    }

    // ── Appearance ──

    private void WireAppearance()
    {
        Click(N(0x100003A7), () => PickGender(2), rollover: false);
        Click(N(0x100003A8), () => PickGender(1), rollover: false);
        RadioText(N(0x100003A9)); RadioText(N(0x100003AA));
        Click(N(0x100003A9), () => { _clothes = false; _row = 0; ShowLookControls(); ShowLook(); }, rollover: false);
        Click(N(0x100003AA), () => { _clothes = true; _row = 1; ShowLookControls(); ShowLook(); }, rollover: false);
        _lookHelp = TextBox(N(0x100003AB), N(0x100003AB)?.Find(0x100002E7));
        void Rows(uint[] rows, bool clothes)
        {
            for (int i = 0; i < rows.Length; i++)
            {
                int r = i;
                var row = N(rows[i]);
                if (row == null) continue;
                row.MouseFilter = MouseFilterEnum.Pass;
                row.GuiInput += e => { if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true }) { _row = r; ShowLookControls(); } };
                Click(row.Find(0x1000030A), () => { _row = r; Step(clothes, r, -1); });
                Click(row.Find(0x1000030B), () => { _row = r; Step(clothes, r, +1); });
            }
        }
        Rows(FaceRows, false);
        Rows(ClothesRows, true);
        for (int i = 0; i < Swatches.Length; i++) { int c = i; Click(N(Swatches[i]), () => PickColour(c), rollover: false); }
        _shade = new RetailSlider(N(0x10000321), 0, 1000, vertical: true) { Changed = v => SetShade(v / 1000f) };
        _lookView = AddPreview(N(0x100003BB));
        Click(N(0x10000323), () => { _lookView?.Turn(-0.4f); _summaryView?.Turn(-0.4f); });
        Click(N(0x10000324), () => { _lookView?.Turn(0.4f); _summaryView?.Turn(0.4f); });
        Click(N(0x10000325), () => _lookView?.Zoom(0.85f));
        Click(N(0x10000326), () => _lookView?.Zoom(1.18f));
    }

    private RetailSlider? _shade;

    /// <summary>A swatch's colour (painted in its ring's hole, as the retail client does).</summary>
    private sealed partial class Swatch : Control
    {
        public Color Fill { get => _fill; set { _fill = value; QueueRedraw(); } }
        private Color _fill = Colors.Black;
        public override void _Draw() => DrawCircle(Size / 2, Math.Min(Size.X, Size.Y) / 2, _fill);
    }

    private static Swatch Dot(UiNode ring)
    {
        foreach (var c in ring.GetChildren()) if (c is Swatch s) return s;
        var d = new Swatch { MouseFilter = MouseFilterEnum.Ignore, Size = new Vector2(20, 20), Position = new Vector2(ring.Size.X / 2 - 10, ring.Size.Y / 2 - 10) };
        ring.AddChild(d);
        return d;
    }

    private int ChosenColour() => !_clothes
        ? _row switch { 0 => _hairColor, 1 => _eyeColor, _ => 0 }
        : _row switch { 0 => _headColor, 1 => _shirtColor, 2 => _pantsColor, _ => _shoesColor };

    // the clothing colours' looks (the game's palette templates: 2 blue, 3 blue-purple, 4 brown, 5 dark blue, 6 deep
    // brown, 7 deep green, 8 green, 9 grey, 13 purple ...)
    private static readonly Dictionary<uint, Color> TemplateColours = new()
    {
        [1] = new(0.2f, 0.7f, 0.75f), [2] = new(0.2f, 0.35f, 0.85f), [3] = new(0.4f, 0.3f, 0.8f), [4] = new(0.55f, 0.36f, 0.18f),
        [5] = new(0.1f, 0.15f, 0.45f), [6] = new(0.35f, 0.2f, 0.1f), [7] = new(0.1f, 0.35f, 0.12f), [8] = new(0.2f, 0.6f, 0.2f),
        [9] = new(0.5f, 0.5f, 0.5f), [10] = new(0.5f, 0.7f, 0.95f), [11] = new(0.5f, 0.1f, 0.15f), [12] = new(0.1f, 0.12f, 0.35f),
        [13] = new(0.5f, 0.2f, 0.6f), [14] = new(0.75f, 0.12f, 0.1f), [15] = new(0.65f, 0.15f, 0.45f), [16] = new(0.85f, 0.45f, 0.55f),
        [17] = new(0.9f, 0.8f, 0.2f), [18] = new(0.65f, 0.5f, 0.2f),
    };

    /// <summary>The colour a swatch stands for: a clothing colour's look, or the hair's / eyes' own palette's average.</summary>
    private Color SwatchColour(int i, float shade)
    {
        var sx = Sex;
        Color c = Colors.Gray;
        if (_clothes) { if (sx.ClothingColors.Count > 0 && TemplateColours.TryGetValue(sx.ClothingColors[Wrap(i, sx.ClothingColors.Count)], out var t)) c = t; }
        else if (_row == 0 && sx.HairColors.Count > 0) c = PaletteAverage(sx.HairColors[Wrap(i, sx.HairColors.Count)], shade, 24 * 8, 8 * 8);
        else if (_row == 1 && sx.EyeColors.Count > 0) c = PaletteAverage(sx.EyeColors[Wrap(i, sx.EyeColors.Count)], 0.5f, 32 * 8, 8 * 8);
        else if (_row == 4) c = PaletteAverage((uint)sx.SkinPalSet, shade, 0, 24 * 8);
        if (_clothes) c = c.Lerp(shade < 0.5f ? Colors.Black : Colors.White, Math.Abs(shade - 0.5f) * 0.8f);
        return c;
    }

    private Color PaletteAverage(uint id, float shade, int from, int count)
    {
        try
        {
            if ((id >> 24) == 0x0F)
            {
                var set = Dats.Get<PalSet>(id);
                if (set == null || set.Palettes.Count == 0) return Colors.Gray;
                id = (uint)set.Palettes[Math.Clamp((int)(shade * set.Palettes.Count), 0, set.Palettes.Count - 1)];
            }
            var pal = Dats.Get<Palette>(id);
            if (pal == null || pal.Colors.Count == 0) return Colors.Gray;
            // (a small palette holds just this part's colours; a full one, the whole body's)
            if (pal.Colors.Count <= count) from = 0;
            float r = 0, g = 0, b = 0; int n = 0;
            for (int k = from; k < Math.Min(pal.Colors.Count, from + count); k++) { var col = pal.Colors[k]; r += col.Red; g += col.Green; b += col.Blue; n++; }
            return n > 0 ? new Color(r / n / 255f, g / n / 255f, b / n / 255f) : Colors.Gray;
        }
        catch { return Colors.Gray; }
    }

    private void PickGender(int g)
    {
        if (!Heritage.Genders.ContainsKey(g)) return;
        _gender = g;
        RandomLooks(sameEach: true);
        ShowLookControls();
        ShowLook();
    }

    private static int Wrap(int v, int n) => n <= 0 ? 0 : ((v % n) + n) % n;

    private void Step(bool clothes, int row, int by)
    {
        var sx = Sex;
        if (!clothes)
            switch (row)
            {
                case 0: _hairStyle = Wrap(_hairStyle + by, sx.HairStyles.Count); break;
                case 1: _eyes = Wrap(_eyes + by, sx.EyeStrips.Count); break;
                case 2: _nose = Wrap(_nose + by, sx.NoseStrips.Count); break;
                case 3: _mouth = Wrap(_mouth + by, sx.MouthStrips.Count); break;
            }
        else
            switch (row)
            {
                case 0: { int n = sx.Headgears.Count + 1; _headgear = Wrap(_headgear + 1 + by, n) - 1; break; }   // (none, then each)
                case 1: _shirt = Wrap(_shirt + by, sx.Shirts.Count); break;
                case 2: _pants = Wrap(_pants + by, sx.Pants.Count); break;
                case 3: _shoes = Wrap(_shoes + by, sx.Footwear.Count); break;
            }
        ShowLookControls();
        ShowLook();
    }

    /// <summary>How many colours the selected row has on the wheel (0: none - the nose, the mouth).</summary>
    private int Colours()
    {
        var sx = Sex;
        if (!_clothes) return _row switch { 0 => sx.HairColors.Count, 1 => sx.EyeColors.Count, _ => 0 };
        return sx.ClothingColors.Count;
    }

    private void PickColour(int c)
    {
        if (c >= Colours()) return;
        if (!_clothes) { if (_row == 0) _hairColor = c; else if (_row == 1) _eyeColor = c; }
        else switch (_row) { case 0: _headColor = c; break; case 1: _shirtColor = c; break; case 2: _pantsColor = c; break; case 3: _shoesColor = c; break; }
        ShowLookControls();
        ShowLook();
    }

    private float CurrentShade() => !_clothes
        ? _row switch { 0 => _hairHue, 4 => _skinHue, _ => 0.5f }
        : _row switch { 0 => _headHue, 1 => _shirtHue, 2 => _pantsHue, _ => _shoesHue };

    private void SetShade(float s)
    {
        if (!_clothes) { if (_row == 0) _hairHue = s; else if (_row == 4) _skinHue = s; else return; }
        else switch (_row) { case 0: _headHue = s; break; case 1: _shirtHue = s; break; case 2: _pantsHue = s; break; case 3: _shoesHue = s; break; }
        if (N(0x1000030E) is { } mid && Colours() > 0) mid.Modulate = SwatchColour(ChosenColour(), s);
        ShowLook();
    }

    private void ShowLookControls()
    {
        N(0x100003A7)?.SetState(_gender == 2 ? UIStateId.Selected : UIStateId.Unselected);
        N(0x100003A8)?.SetState(_gender == 1 ? UIStateId.Selected : UIStateId.Unselected);
        N(0x100003A9)?.SetState(!_clothes ? UIStateId.Selected : UIStateId.Unselected);
        N(0x100003AA)?.SetState(_clothes ? UIStateId.Selected : UIStateId.Unselected);
        if (N(0x100003AE) is { } face) face.Visible = !_clothes;
        if (N(0x100003B4) is { } clo) clo.Visible = _clothes;
        var rows = _clothes ? ClothesRows : FaceRows;
        for (int i = 0; i < rows.Length; i++)
        {
            if (N(rows[i]) is not { } row) continue;
            row.SetState(i == _row ? UIStateId.Highlight : UIStateId.Normal, children: false);
            // the skin has no styles to step through: its arrows ghosted
            if (!_clothes && i == 4) { row.Find(0x1000030A)?.SetState(UIStateId.Ghosted); row.Find(0x1000030B)?.SetState(UIStateId.Ghosted); }
        }
        _lookHelp.Text = Text(0x029124C3);
        int n = Colours();
        for (int i = 0; i < Swatches.Length; i++)
        {
            if (N(Swatches[i]) is { } sw) { sw.Visible = i < n; if (i < n) Dot(sw).Fill = SwatchColour(i, 0.5f); }
            if (N(SwatchDots[i]) is { } d) d.Visible = i < n;
        }
        // the middle: the chosen colour at its shade
        if (N(0x1000030E) is { } mid) mid.Modulate = n > 0 ? SwatchColour(ChosenColour(), CurrentShade()) : Colors.White;
        bool shade = !_clothes ? _row is 0 or 4 : true;
        if (N(0x10000321) is { } sh) sh.Visible = shade;
        _shade?.Show((int)(CurrentShade() * 1000));
    }

    /// <summary>Random looks for the heritage and sex (Random on the Appearance page; a new heritage starts from the same picks each time).</summary>
    private void RandomLooks(bool sameEach)
    {
        var sx = Sex;
        var rng = sameEach ? new Random((int)(_heritage * 7 + _gender)) : new Random();
        int R(int n) => n > 0 ? rng.Next(n) : 0;
        var styles = Enumerable.Range(0, sx.HairStyles.Count).Where(i => sx.HairStyles[i].AlternateSetup == 0).ToList();
        _hairStyle = styles.Count > 0 ? styles[R(styles.Count)] : 0;
        _hairColor = R(sx.HairColors.Count); _eyeColor = R(sx.EyeColors.Count);
        _eyes = R(sx.EyeStrips.Count); _nose = R(sx.NoseStrips.Count); _mouth = R(sx.MouthStrips.Count);
        _headgear = -1; _shirt = R(sx.Shirts.Count); _pants = R(sx.Pants.Count); _shoes = R(sx.Footwear.Count);
        int C() => R(sx.ClothingColors.Count);
        _headColor = C(); _shirtColor = C(); _pantsColor = C(); _shoesColor = C();
        _skinHue = sameEach ? 0.5f : (float)(0.2 + rng.NextDouble() * 0.6);
        _hairHue = (float)rng.NextDouble(); _headHue = (float)rng.NextDouble();
        _shirtHue = (float)rng.NextDouble(); _pantsHue = (float)rng.NextDouble(); _shoesHue = (float)rng.NextDouble();
        if (_built) ShowLookControls();
    }

    private Preview? AddPreview(UiNode? frame)
    {
        if (frame == null || Looks == null) return null;
        var p = new Preview(Looks);
        p.Size = frame.Size;
        frame.AddChild(p);
        return p;
    }

    private int _lookN;
    /// <summary>The character as chosen so far, in the appearance and summary pages' pictures.</summary>
    private void ShowLook()
    {
        if (Looks == null || (_lookView == null && _summaryView == null)) return;
        int wcid;
        try { wcid = MakeLook(); }
        catch (Exception ex) { GD.PushWarning("character look: " + ex.Message); return; }
        if (wcid == 0) return;
        _lookView?.Show(wcid, face: !_clothes);
        _summaryView?.Show(wcid, face: false);
    }

    private int MakeLook()
    {
        var data = Looks!.Data;
        var sx = Sex;
        uint FromSet(uint id, float shade)
        {
            if ((id >> 24) != 0x0F) return id;
            var set = Dats.Get<PalSet>(id);
            if (set == null || set.Palettes.Count == 0) return 0;
            return (uint)set.Palettes[Math.Clamp((int)(shade * set.Palettes.Count), 0, set.Palettes.Count - 1)];
        }
        var w = new global::ACGodot.Creatures.SpawnData.Weenie
        {
            Name = "New character", Type = 10, ItemType = 0x10, Setup = (uint)sx.SetupId, MotionTable = (uint)sx.MotionTable,
            PaletteBase = (uint)sx.BasePalette, Scale = sx.Scale > 0 ? sx.Scale / 100f : 1f, Exact = false,
            SkinPalette = FromSet((uint)sx.SkinPalSet, _skinHue),
        };
        if (sx.HairColors.Count > 0) w.HairPalette = FromSet(sx.HairColors[Wrap(_hairColor, sx.HairColors.Count)], _hairHue);
        if (sx.EyeColors.Count > 0) w.EyesPalette = FromSet(sx.EyeColors[Wrap(_eyeColor, sx.EyeColors.Count)], 0.5f);
        void Desc(ObjDesc? d)
        {
            if (d == null) return;
            foreach (var ap in d.AnimPartChanges) w.AnimParts.Add((ap.PartIndex, (uint)ap.PartId));
            foreach (var tc in d.TextureChanges) w.TextureMaps.Add((tc.PartIndex, (uint)tc.OldTexture, (uint)tc.NewTexture));
        }
        Desc(sx.BaseObjDesc);
        bool bald = false;
        if (sx.HairStyles.Count > 0)
        {
            var hs = sx.HairStyles[Wrap(_hairStyle, sx.HairStyles.Count)];
            bald = hs.Bald;
            Desc(hs.ObjDesc);
            if (hs.AlternateSetup != 0) w.Setup = hs.AlternateSetup;
        }
        if (sx.EyeStrips.Count > 0) { var e = sx.EyeStrips[Wrap(_eyes, sx.EyeStrips.Count)]; Desc(bald && e.BaldObjDesc != null ? e.BaldObjDesc : e.ObjDesc); }
        if (sx.NoseStrips.Count > 0) Desc(sx.NoseStrips[Wrap(_nose, sx.NoseStrips.Count)].ObjDesc);
        if (sx.MouthStrips.Count > 0) Desc(sx.MouthStrips[Wrap(_mouth, sx.MouthStrips.Count)].ObjDesc);
        int Col(int i) => sx.ClothingColors.Count > 0 ? (int)sx.ClothingColors[Wrap(i, sx.ClothingColors.Count)] : 0;
        void Wear(List<GearCG> list, int i, int colour, float hue)
        {
            if (i < 0 || list.Count == 0) return;
            var g = list[Wrap(i, list.Count)];
            if (g.WeenieDefault != 0 && data.Get((int)g.WeenieDefault) != null) w.Worn.Add(((int)g.WeenieDefault, Col(colour), hue));
            else if ((uint)g.ClothingTable != 0)
            {
                // (an item that isn't in our weenie data: one made for it from its clothing table)
                int id = -1900000 - (int)((uint)g.ClothingTable & 0xFFFF);
                if (data.Get(id) == null) data.AddWeenie(id, new global::ACGodot.Creatures.SpawnData.Weenie { Name = g.Name.Value, ClothingBase = (uint)g.ClothingTable, Type = 1 });
                w.Worn.Add((id, Col(colour), hue));
            }
        }
        Wear(sx.Shirts, _shirt, _shirtColor, _shirtHue);
        Wear(sx.Pants, _pants, _pantsColor, _pantsHue);
        Wear(sx.Footwear, _shoes, _shoesColor, _shoesHue);
        Wear(sx.Headgears, _headgear, _headColor, _headHue);
        int wcid = -1800000 - (_lookN++ % 400);
        data.AddWeenie(wcid, w);
        return wcid;
    }

    // ── Town ──

    private List<int> Towns()
    {
        var all = new List<int>();
        foreach (var t in Heritage.PrimaryStartAreas) all.Add((int)t);
        foreach (var t in Heritage.SecondaryStartAreas) if (!all.Contains((int)t)) all.Add((int)t);
        return all.Where(t => t >= 0 && t < 4).ToList();
    }

    private void WireTown()
    {
        _townText = TextBox(N(0x10000409), null);
        for (int i = 0; i < TownMarks.Length; i++) { int t = i; Click(N(TownMarks[i]), () => { if (Towns().Contains(t)) { _town = t; ShowTown(); } }, rollover: false); }
    }

    private void ShowTown()
    {
        if (!_built && _townText == null) return;
        var allowed = Towns();
        for (int i = 0; i < TownMarks.Length; i++)
            if (N(TownMarks[i]) is { } m) { m.SetState(i == _town ? UIStateId.Highlight : UIStateId.Normal); m.Visible = allowed.Contains(i); }
        // the town's name over its description (the page's own states)
        if (N(0x10000408) is { } name) name.SetState(State(TownState[Math.Clamp(_town, 0, 3)]));
        _townText.Text = Text(TownText[Math.Clamp(_town, 0, 3)]) + "\n\n" + Text(0x0BB6CB7F);
    }

    // ── Summary ──

    private void WireSummary()
    {
        _summary = new RetailText(_ui, N(0x10000400), font: 0x40000009);
        _summary.Colors.Clear(); _summary.Colors.Add(Colors.White); _summary.Colors.Add(new Color(1f, 0.86f, 0.25f));
        new RetailScroll(N(0x10000401)) { Moved = f => _summary.ScrollTo(f), Step = d => _summary.ScrollBy(d * _summary.LineHeight) }.Follow(_summary);
        _summaryHelp = TextBox(N(0x10000404), N(0x10000404)?.Find(0x100002E7));
        var box = N(0x10000402);
        _nameBox = new LineEdit { MaxLength = 32, Flat = true, Position = new Vector2(10, 8), Size = new Vector2((box?.Size.X ?? 247) - 20, 26),
                                  PlaceholderText = "[ Name ]", CaretBlink = true, ContextMenuEnabled = false };
        var clear = new StyleBoxEmpty();
        _nameBox.AddThemeStyleboxOverride("normal", clear);
        _nameBox.AddThemeStyleboxOverride("focus", clear);
        _nameBox.AddThemeColorOverride("font_color", Colors.White);
        _nameBox.AddThemeColorOverride("font_placeholder_color", new Color(1, 1, 1, 0.85f));
        if (RetailTheme.TextFont != null) _nameBox.AddThemeFontOverride("font", RetailTheme.TextFont);
        _nameBox.AddThemeFontSizeOverride("font_size", 15);
        box?.AddChild(_nameBox);
        _summaryView = AddPreview(N(0x10000406));
        for (int i = 0; i < 2; i++) if (N(i == 0 ? 0x10000403u : 0x10000494u) is { } adm) adm.Visible = false;   // (admin / envoy: the server's to decide)
    }

    private void ShowSummary()
    {
        var t = Heritage.Templates[_template];
        string Y(string s) => RetailText.Color(1) + s + RetailText.Color(0);
        var lines = new List<string>
        {
            "Profession: " + (t.Name.Value == "Adventurer" ? "Custom" : t.Name.Value),
            "Gender : " + Sex.Name.Value,
            "Heritage: " + Heritage.Name.Value,
            "Starting Town: " + _gen.StartingAreas[Math.Clamp(_town, 0, _gen.StartingAreas.Count - 1)].Name.Value,
            RetailText.Center + Y("Attributes"),
        };
        for (int i = 0; i < 6; i++) lines.Add(AttrNames[i] + RetailText.Tab + _attr[i]);
        lines.Add("Health" + RetailText.Tab + (_attr[1] + 1) / 2);
        lines.Add("Stamina" + RetailText.Tab + _attr[1]);
        lines.Add("Mana" + RetailText.Tab + _attr[5]);
        lines.Add("Skill Credits" + RetailText.Tab + SkillCreditsLeft);
        void Skills(string title, int level)
        {
            var these = ChargenSkills().Where(x => (_train.TryGetValue(x.id, out var v) ? v : 1) == level).ToList();
            if (these.Count == 0) return;
            lines.Add(RetailText.Center + Y(title));
            foreach (var (id, s) in these) lines.Add(s.Name.Value + RetailText.Tab + SkillLevel(id));
        }
        Skills("Specialized Skills", 3);
        Skills("Trained Skills", 2);
        _summary.Text = string.Join("\n", lines);
        string names = NameText.TryGetValue(_heritage, out var nt) ? Text(_gender == 2 ? nt.f : nt.m) : "";
        _summaryHelp.Text = Text(0x03C0369F) + "\n\n" + names + Text(0x036A0844);
    }

    // ── Random, Finish ──

    private void RandomPage()
    {
        var rng = new Random();
        switch (Pages[_page])
        {
            case "Heritage":
            {
                var ids = _heritageRadios.Select(h => h.heritage).Where(h => h < 12).ToList();
                PickHeritage(ids[rng.Next(ids.Count)], keepLooks: false);
                break;
            }
            case "Profession": PickTemplate(rng.Next(Heritage.Templates.Count)); break;
            case "Appearance":
                if (Heritage.Genders.Count > 1) _gender = Heritage.Genders.Keys.ElementAt(rng.Next(Heritage.Genders.Count));
                RandomLooks(sameEach: false); ShowLookControls(); ShowLook(); break;
            case "Town": { var t = Towns(); if (t.Count > 0) { _town = t[rng.Next(t.Count)]; ShowTown(); } break; }
        }
    }

    private void Finish()
    {
        string n = _nameBox.Text.Trim();
        if (n.Length == 0) { ShowMessage(Text(0x041CB807)); return; }
        if (n.Length > 32) { ShowMessage(Text(0x02CD0277)); return; }
        if (!n.All(ch => char.IsAsciiLetter(ch) || ch is ' ' or '\'' or '-') || !char.IsAsciiLetter(n[0])) { ShowMessage(Text(0x02826F85)); return; }
        var sx = Sex;
        var c = new Net.NewCharacter
        {
            Name = n, Heritage = _heritage, Gender = (uint)_gender, Template = _template, StartArea = (uint)_town,
            Attributes = _attr.Select(a => (uint)a).ToArray(),
            Eyes = (uint)Wrap(_eyes, sx.EyeStrips.Count), Nose = (uint)Wrap(_nose, sx.NoseStrips.Count), Mouth = (uint)Wrap(_mouth, sx.MouthStrips.Count),
            HairColor = (uint)Wrap(_hairColor, sx.HairColors.Count), EyeColor = (uint)Wrap(_eyeColor, sx.EyeColors.Count), HairStyle = (uint)Wrap(_hairStyle, sx.HairStyles.Count),
            Headgear = _headgear < 0 ? 0xFFFFFFFFu : (uint)_headgear, HeadgearColor = _headgear < 0 ? 0u : ColourValue(_headColor),
            Shirt = (uint)Wrap(_shirt, sx.Shirts.Count), ShirtColor = ColourValue(_shirtColor), Pants = (uint)Wrap(_pants, sx.Pants.Count), PantsColor = ColourValue(_pantsColor),
            Shoes = (uint)Wrap(_shoes, sx.Footwear.Count), ShoesColor = ColourValue(_shoesColor),
            SkinHue = _skinHue, HairHue = _hairHue, HeadgearHue = _headHue, ShirtHue = _shirtHue, PantsHue = _pantsHue, ShoesHue = _shoesHue,
        };
        foreach (var (id, lvl) in _train) if (id > 0 && id < c.Skills.Length) c.Skills[id] = (uint)lvl;
        if (Create?.Invoke(c) != true) { ShowMessage("Not connected to the server's character screen."); return; }
        ShowMessage($"Asking the server for {n}...", ok: false);
    }

    private uint ColourValue(int i) => Sex.ClothingColors.Count > 0 ? Sex.ClothingColors[Wrap(i, Sex.ClothingColors.Count)] : 0u;

    // ── a message over the screen (the retail client's popups) ──

    private void ShowMessage(string words, bool ok = true)
    {
        HideMessage();
        _msgBox = new Panel { Size = new Vector2(320, 140), Position = new Vector2(240, 230), ZIndex = 60, MouseFilter = MouseFilterEnum.Stop };
        _msgBox.AddThemeStyleboxOverride("panel", new StyleBoxFlat { BgColor = new Color(0.05f, 0.07f, 0.13f, 0.97f), BorderColor = new Color(0.85f, 0.68f, 0.3f),
                                                                      BorderWidthLeft = 2, BorderWidthTop = 2, BorderWidthRight = 2, BorderWidthBottom = 2 });
        var label = new Label { Text = words, AutowrapMode = TextServer.AutowrapMode.WordSmart, Position = new Vector2(14, 12), Size = new Vector2(292, 80),
                                HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
        if (RetailTheme.TextFont != null) label.AddThemeFontOverride("font", RetailTheme.TextFont);
        label.AddThemeFontSizeOverride("font_size", 13);
        label.AddThemeColorOverride("font_color", new Color(1f, 0.95f, 0.75f));
        _msgBox.AddChild(label);
        if (ok)
        {
            var b = new Button { Text = "OK", Position = new Vector2(125, 100), Size = new Vector2(70, 26), FocusMode = FocusModeEnum.None, Theme = RetailTheme.Current };
            b.Pressed += HideMessage;
            _msgBox.AddChild(b);
        }
        _stage.AddChild(_msgBox);
    }

    private void HideMessage() { _msgBox?.QueueFree(); _msgBox = null; }

    // ── text boxes ──

    /// <summary>A text box of the layout (a 2100004C box), its words drawn in its font, with its scroll bar if it has one.</summary>
    private RetailText TextBox(UiNode? box, UiNode? scroll)
    {
        var t = new RetailText(_ui, box);
        if (scroll != null) new RetailScroll(scroll) { Moved = f => t.ScrollTo(f), Step = d => t.ScrollBy(d * t.LineHeight) }.Follow(t);
        return t;
    }

    public override void _UnhandledKeyInput(InputEvent e)
    {
        if (!Visible || e is not InputEventKey { Pressed: true } k) return;
        if (k.Keycode == Key.Escape && _msgBox != null) { HideMessage(); GetViewport().SetInputAsHandled(); }
    }
}

/// <summary>
/// Words drawn in one of the game's fonts inside a layout box (its margins: properties 0x23 left, 0x24 right, 0x25 top,
/// 0x26 bottom), wrapped, scrolled. Colours from the box's list (property 0x1B: the first for the text, the next for
/// headings); markers in the text switch colour (Color(n)), centre a line (Center) or put the rest of a line at the
/// right (Tab).
/// </summary>
public partial class RetailText : Control
{
    public static string Color(int i) => "\u0001" + (char)('0' + i);
    public const string Center = "\u0002", Tab = "\u0003";
    private RetailFont? _font;
    public readonly List<Color> Colors = new();
    private string _text = "";
    private float _scroll, _content;
    public Action? Relaid;

    public RetailText(RetailUi ui, UiNode? box, uint font = 0)
    {
        MouseFilter = MouseFilterEnum.Pass;
        ClipContents = true;
        if (box == null) return;
        var p = box.R.Props;
        int M(uint k) => p.TryGetValue(k, out var v) && v is IntegerBaseProperty ip ? ip.Value : 0;
        float l = M(0x23), r = M(0x24), t = M(0x25), b = M(0x26);
        if (l == 0 && r == 0 && t == 0 && b == 0) { l = 8; r = 8; t = 6; b = 6; }
        // (a box with a scroll bar: the words stop short of it)
        if (box.Find(0x100002E7) is { } sb && sb.Visible) r = Math.Max(r, box.Size.X - sb.Position.X + 2);
        Position = new Vector2(l, t);
        Size = new Vector2(Math.Max(10, box.Size.X - l - r), Math.Max(10, box.Size.Y - t - b));
        uint fid = font;
        if (fid == 0 && p.TryGetValue(0x1A, out var fp) && (fp is ArrayBaseProperty fa ? fa.Value.FirstOrDefault() : fp) is DataIdBaseProperty d) fid = d.Value;
        _font = fid != 0 ? ui.Font(fid) : null;
        _font ??= RetailTheme.Text;
        if (p.TryGetValue(0x1B, out var cp) && cp is ArrayBaseProperty ca)
            foreach (var c in ca.Value) if (c is ColorBaseProperty cc) Colors.Add(new Color(cc.Value.Red / 255f, cc.Value.Green / 255f, cc.Value.Blue / 255f));
        if (Colors.Count == 0) Colors.Add(Godot.Colors.White);
        if (Colors.Count == 1) Colors.Add(new Color(0.2f, 1f, 0.2f));
        // the box's own words (drawn on one line by the box itself) taken over here, wrapped
        if (!string.IsNullOrEmpty(box.Text)) { _text = box.Text; box.Text = null; }
        box.AddChild(this);
    }

    public int LineHeight => _font != null ? Math.Max(1, _font.Height) : 14;
    public float ContentHeight => _content;
    public float Offset => _scroll;

    public string Text { get => _text; set { _text = value ?? ""; _scroll = 0; QueueRedraw(); Relaid?.Invoke(); } }

    public void ScrollTo(float f) { _scroll = Math.Clamp(f, 0f, 1f) * Math.Max(0, _content - Size.Y); QueueRedraw(); }
    public void ScrollBy(float px) { _scroll = Math.Clamp(_scroll + px, 0, Math.Max(0, _content - Size.Y)); QueueRedraw(); Relaid?.Invoke(); }
    public float Fraction => _content <= Size.Y ? 0f : _scroll / (_content - Size.Y);

    public override void _GuiInput(InputEvent e)
    {
        if (e is InputEventMouseButton { Pressed: true, ButtonIndex: MouseButton.WheelUp }) { ScrollBy(-LineHeight * 3); AcceptEvent(); }
        if (e is InputEventMouseButton { Pressed: true, ButtonIndex: MouseButton.WheelDown }) { ScrollBy(LineHeight * 3); AcceptEvent(); }
    }

    private float W(string s) => _font?.MeasureNative(s).X ?? s.Length * 6;

    public override void _Draw()
    {
        if (_font == null) return;
        float y = -_scroll, lh = LineHeight, width = Size.X;
        int colour = 0;
        foreach (var raw in _text.Split('\n'))
        {
            string line = raw;
            bool center = line.StartsWith(Center, StringComparison.Ordinal);
            if (center) line = line[1..];
            string? right = null;
            int tab = line.IndexOf(Tab, StringComparison.Ordinal);
            if (tab >= 0) { right = line[(tab + 1)..]; line = line[..tab]; }
            // words wrapped at the width (colour markers carried along)
            var words = line.Split(' ');
            var row = new List<(string w, int c)>();
            float x = 0;
            void Flush()
            {
                float total = row.Sum(r => W(Strip(r.w))) + Math.Max(0, row.Count - 1) * W(" ");
                float cx = center ? Math.Max(0, (width - total) / 2) : 0;
                if (y + lh > 0 && y < Size.Y)
                    foreach (var (w, c) in row)
                    {
                        int cc = c;
                        foreach (var (piece, pc) in Pieces(w, cc)) { _font.DrawNative(this, piece, new Vector2(MathF.Round(cx), MathF.Round(y)), Colors[Math.Clamp(pc, 0, Colors.Count - 1)]); cx += W(piece); }
                        cx += W(" ");
                    }
                row.Clear(); x = 0; y += lh;
            }
            foreach (var word in words)
            {
                float ww = W(Strip(word));
                if (row.Count > 0 && x + ww > width - (right != null ? W(right) + 8 : 0)) Flush();
                row.Add((word, colour));
                foreach (var (_, pc) in Pieces(word, colour)) colour = pc;
                x += ww + W(" ");
            }
            if (right != null && y + lh > 0 && y < Size.Y) _font.DrawNative(this, right, new Vector2(MathF.Round(width - W(right)), MathF.Round(y)), Colors[Math.Clamp(colour, 0, Colors.Count - 1)]);
            Flush();
        }
        float content = y + _scroll;
        if (Math.Abs(content - _content) > 0.5f) { _content = content; Relaid?.Invoke(); }
    }

    private static string Strip(string w)
    {
        var sb = new System.Text.StringBuilder();
        for (int i = 0; i < w.Length; i++) { if (w[i] == '\u0001') { i++; continue; } sb.Append(w[i]); }
        return sb.ToString();
    }

    private static IEnumerable<(string piece, int colour)> Pieces(string w, int colour)
    {
        var sb = new System.Text.StringBuilder();
        for (int i = 0; i < w.Length; i++)
        {
            if (w[i] == '\u0001' && i + 1 < w.Length)
            {
                if (sb.Length > 0) { yield return (sb.ToString(), colour); sb.Clear(); }
                colour = w[i + 1] - '0';
                i++;
                continue;
            }
            sb.Append(w[i]);
        }
        yield return (sb.ToString(), colour);
    }
}

/// <summary>
/// The game's scroll bar (a 2100004C 0x100002DC: its up and down buttons and the thumb that slides between them),
/// working: the buttons step, the thumb drags, and it follows what it scrolls.
/// </summary>
public sealed class RetailScroll
{
    private readonly UiNode? _bar, _thumb, _up, _down;
    public Action<float>? Moved;
    public Action<int>? Step;
    private bool _drag;

    public RetailScroll(UiNode? bar)
    {
        _bar = bar;
        if (bar == null) return;
        _thumb = bar.Find(0x00000001);
        _up = bar.Find(0x10000072);
        _down = bar.Find(0x10000071);
        if (_up != null) _up.OnInput = e => { if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true }) Step?.Invoke(-1); };
        if (_down != null) _down.OnInput = e => { if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true }) Step?.Invoke(1); };
        bar.OnInput = e =>
        {
            if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb) { _drag = mb.Pressed; if (mb.Pressed) DragTo(mb.Position.Y); }
            else if (e is InputEventMouseMotion mm && _drag) DragTo(mm.Position.Y);
        };
    }

    private (float top, float span) Track()
    {
        float top = _up?.Size.Y ?? 0, bottom = _down?.Size.Y ?? 0, th = _thumb?.Size.Y ?? 0;
        return (top, Math.Max(1f, (_bar?.Size.Y ?? 0) - top - bottom - th));
    }

    private void DragTo(float y)
    {
        var (top, span) = Track();
        float f = Math.Clamp((y - top - (_thumb?.Size.Y ?? 0) / 2) / span, 0f, 1f);
        Show(f);
        Moved?.Invoke(f);
    }

    public void Show(float f)
    {
        if (_thumb == null) return;
        var (top, span) = Track();
        _thumb.Pinned = true;
        _thumb.Position = new Vector2(_thumb.Position.X, top + span * Math.Clamp(f, 0f, 1f));
    }

    /// <summary>Kept at what a text box shows (and shown only when it has more than fits).</summary>
    public void Follow(RetailText t)
    {
        t.Relaid += () => { Show(t.Fraction); if (_bar != null) _bar.Visible = t.ContentHeight > t.Size.Y + 1; };
    }
}

/// <summary>A slider of the game's (type 11: its track, and the thumb - element 1 - dragged along it) for a whole-number value.</summary>
public sealed class RetailSlider
{
    private readonly UiNode? _bar, _thumb;
    private readonly TextureRect? _fill;   // the bar filled (its "Locked" picture) up to the thumb, over its empty track
    private readonly int _min, _max;
    private readonly bool _vertical;
    public Action<int>? Changed;
    private bool _drag;

    public RetailSlider(UiNode? bar, int min, int max, bool vertical = false)
    {
        _bar = bar; _min = min; _max = max; _vertical = vertical;
        if (bar == null) return;
        _thumb = bar.Find(0x00000001);
        // an attribute bar: its track (element 4) empty, and filled up to the thumb (as the game draws it)
        if (!vertical && bar.Find(0x00000004) is { } track && track.ImageFor(UIStateId.Locked) is { } full)
        {
            track.SetState(UIStateId.Unlocked, children: false);
            _fill = new TextureRect { Texture = full, StretchMode = TextureRect.StretchModeEnum.Tile, ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize,
                                      MouseFilter = Control.MouseFilterEnum.Ignore, Position = Vector2.Zero, Size = new Vector2(0, track.Size.Y) };
            track.AddChild(_fill);
        }
        bar.OnInput = e =>
        {
            if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb) { _drag = mb.Pressed; if (mb.Pressed) To(mb.Position); }
            else if (e is InputEventMouseMotion mm && _drag) To(mm.Position);
        };
    }

    private float Span => _bar == null || _thumb == null ? 1f : Math.Max(1f, _vertical ? _bar.Size.Y - _thumb.Size.Y : _bar.Size.X - _thumb.Size.X);

    private void To(Vector2 at)
    {
        if (_thumb == null) return;
        float p = _vertical ? at.Y - _thumb.Size.Y / 2 : at.X - _thumb.Size.X / 2;
        float f = Math.Clamp(p / Span, 0f, 1f);
        if (_vertical) f = 1f - f;   // (up is more)
        Changed?.Invoke((int)Math.Round(_min + f * (_max - _min)));
    }

    public void Show(int value)
    {
        if (_thumb == null) return;
        float f = _max > _min ? (Math.Clamp(value, _min, _max) - _min) / (float)(_max - _min) : 0f;
        _thumb.Pinned = true;
        if (_vertical) _thumb.Position = new Vector2(_thumb.Position.X, (1f - f) * Span);
        else _thumb.Position = new Vector2(f * Span, _thumb.Position.Y);
        if (_fill?.GetParent() is Control track)
            _fill.Size = new Vector2(Math.Clamp(_thumb.Position.X + _thumb.Size.X * 0.5f - track.Position.X, 0f, track.Size.X), track.Size.Y);
    }
}

/// <summary>A character drawn live (its idle motion) in a picture of its own: turned by the arrows, zoomed by the dial.</summary>
public partial class Preview : SubViewportContainer
{
    private readonly global::ACGodot.Creatures.CreatureAssets _assets;
    private readonly SubViewport _view;
    private readonly Camera3D _cam;
    private readonly Node3D _turn;
    private Node3D? _holder;
    private Skeleton3D? _skel;
    private global::ACGodot.Creatures.CreatureAssets.Key _key;
    private float _yaw, _zoom = 1f, _height = 1.8f;
    private bool _face;
    private double _t;

    public Preview(global::ACGodot.Creatures.CreatureAssets assets)
    {
        _assets = assets;
        Stretch = true;
        MouseFilter = MouseFilterEnum.Ignore;
        _view = new SubViewport { OwnWorld3D = true, TransparentBg = false, RenderTargetUpdateMode = SubViewport.UpdateMode.WhenVisible, Size = new Vector2I(256, 384), Msaa3D = Viewport.Msaa.Msaa4X };
        var env = new Godot.Environment
        {
            BackgroundMode = Godot.Environment.BGMode.Color, BackgroundColor = new Color(0.12f, 0.08f, 0.16f),
            AmbientLightSource = Godot.Environment.AmbientSource.Color, AmbientLightColor = new Color(0.75f, 0.72f, 0.7f), AmbientLightEnergy = 0.9f,
        };
        _view.AddChild(new WorldEnvironment { Environment = env });
        var sun = new DirectionalLight3D { LightEnergy = 0.9f };
        _view.AddChild(sun);
        sun.RotationDegrees = new Vector3(-35, 160, 0);
        _turn = new Node3D();
        _view.AddChild(_turn);
        _cam = new Camera3D { Fov = 30f, Current = true };
        _view.AddChild(_cam);
        AddChild(_view);
    }

    public void Show(int wcid, bool face)
    {
        _face = face;
        _holder?.QueueFree();
        _holder = null; _skel = null;
        _key = new global::ACGodot.Creatures.CreatureAssets.Key(wcid, 0, 0f);
        if (!_assets.Prepare(_key) || _assets.Mesh(_key) is not ArrayMesh mesh) return;
        float sc = _assets.ScaleOf(_key);
        _height = Math.Max(0.5f, _assets.SizeOf(_key).height);
        // (AC's axes: facing its +y, which is Godot's -z - the camera is on that side)
        _holder = new Node3D { Transform = Objects.ObjectAssets.Xf(System.Numerics.Matrix4x4.CreateScale(sc)) };
        if (_assets.IsAnimated(_key))
        {
            var (sk, skin) = _assets.Rig(_key);
            _holder.AddChild(sk);
            var mi = new MeshInstance3D { Mesh = mesh, Skin = skin };
            sk.AddChild(mi);
            mi.Skeleton = mi.GetPathTo(sk);
            _assets.Pose(_key, sk, _t);
            _skel = sk;
        }
        else _holder.AddChild(new MeshInstance3D { Mesh = mesh });
        _turn.AddChild(_holder);
        // where its joints are, posed (a creature's parts sit at its bones, so the mesh's own box says little): the
        // whole body, or the head - its highest joint - framed
        var corners = new List<Vector3>();
        if (_skel != null)
        {
            _skel.ForceUpdateAllBoneTransforms();
            for (int i = 0; i < _skel.GetBoneCount(); i++) corners.Add(_holder.Transform * _skel.GetBoneGlobalPose(i).Origin);
        }
        if (corners.Count < 2) { var box = mesh.GetAabb(); for (int i = 0; i < 8; i++) corners.Add(_holder.Transform * box.GetEndpoint(i)); }
        float minY = Math.Min(0f, corners.Min(c => c.Y)), maxY = corners.Max(c => c.Y);
        // (the top joint is the head's: the head itself reaches a little higher)
        float full = Math.Max(0.3f, (maxY - minY) * 1.12f);
        _height = full;
        _bottom = minY;
        _head = maxY + full * 0.02f;
        _middle = new Vector2((corners.Min(c => c.X) + corners.Max(c => c.X)) / 2, (corners.Min(c => c.Z) + corners.Max(c => c.Z)) / 2);
        Aim();
    }

    private float _bottom, _head;
    private Vector2 _middle;

    public void Turn(float by) { _yaw += by; _turn.Rotation = new Vector3(0, _yaw, 0); }
    public void Zoom(float by) { _zoom = Math.Clamp(_zoom * by, 0.35f, 2.2f); Aim(); }

    private void Aim()
    {
        float h = _height;
        // whole body: all of it in the picture with a little room; the face: the top eighth of it (the head)
        float span = _face ? h * 0.22f : h * 1.08f;
        Vector3 at = new(_middle.X, _face ? _head : _bottom + h * 0.5f, _middle.Y);
        float dist = span / 2 / MathF.Tan(Mathf.DegToRad(_cam.Fov / 2)) * _zoom;
        _cam.Position = at + new Vector3(0, 0, -dist);
        _cam.LookAt(at, Vector3.Up);
    }

    public override void _Process(double delta)
    {
        if (!IsVisibleInTree()) return;
        _t += delta;
        if (_skel != null && IsInstanceValid(_skel)) _assets.Pose(_key, _skel, _t);
    }
}
