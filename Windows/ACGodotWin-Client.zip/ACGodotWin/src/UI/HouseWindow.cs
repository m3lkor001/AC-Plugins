using System;
using System.Collections.Generic;
using System.Linq;
using Godot;
using ACGodot.Combat;
using ACGodot.Net;

namespace ACGodot.UI;

/// <summary>
/// A house's sign (its covenant crystal) used: laid out as a vendor's window. Up top, what the house costs - or, owned,
/// its upkeep - each thing with how much is due and how much you've put in; below, a row you drop your money and the
/// things it asks for onto; then Buy (or Pay upkeep) hands those over.
/// </summary>
public partial class HouseWindow : GameWindow
{
    public NetGame? Net;
    public Inventory? Inv;
    public Func<uint, Texture2D?> Icon = _ => null;
    public Action<string, Color>? Say;
    private NetGame.HouseOffer? _offer;
    private readonly List<(Item item, int amount)> _given = new();
    private Item? _picked;
    private const int Across = 10;

    public HouseWindow() : base("House", new Vector2(470, 330)) { }

    // a cell of the cost table: on one line (the window's text wraps, and wrapped in a grid it stood one letter a line)
    private static Label Cell(string s, int size, Color? c)
    {
        var l = Text(s, size, c);
        l.AutowrapMode = TextServer.AutowrapMode.Off;
        l.SizeFlagsHorizontal = SizeFlags.Fill;
        return l;
    }

    public void ShowOffer(NetGame.HouseOffer o)
    {
        if (_offer?.Sign != o.Sign) { _given.Clear(); _picked = null; }
        _offer = o;
        Title = o.TypeName;
        Visible = true;
        GetParent()?.MoveChild(this, -1);
        Refresh();
    }

    // what you've put in towards one thing it asks for (pyreals: coins, and trade notes at their worth)
    private long PutIn(NetGame.HousePayment p) => _given.Sum(g =>
        g.item.Wcid == (int)p.Wcid ? (long)g.amount
        : p.Wcid == 273 && (g.item.ItemType & 0x40000) != 0 ? (long)g.item.Value * g.amount : 0L);

    public void Give(Item it, int amount)
    {
        if (it.Guid == 0) return;
        int n = amount > 0 ? Math.Min(amount, Math.Max(1, it.Stack)) : Math.Max(1, it.Stack);
        _given.RemoveAll(g => g.item == it);
        _given.Add((it, n));
        Refresh();
    }

    public override bool _CanDropData(Vector2 at, Variant data) =>
        data.VariantType == Variant.Type.String && (string)data == "acgodot-item" && ItemSlot.Dragging is { Guid: not 0 } && ItemSlot.DraggingFrom == "pack";
    public override void _DropData(Vector2 at, Variant data)
    {
        if (ItemSlot.Dragging is { } it) Give(ItemSlot.SplitFrom ?? it, ItemSlot.SplitFrom != null ? it.Stack : ItemSlot.Splitting?.Invoke(it) ?? 0);
        ItemSlot.Dragging = null;
    }

    public void Refresh()
    {
        if (_offer is not { } o || !Visible) return;
        Clear();
        if (Inv != null) _given.RemoveAll(g => !Inv.Pack.Contains(g.item));
        bool buying = !o.Owned;
        var due = buying ? o.Buy : o.Rent;

        // up top: the house, who has it, who may have it, and what it costs
        Body.AddChild(Heading(buying ? $"This {o.TypeName.ToLowerInvariant()} is for sale" : $"Upkeep for this {o.TypeName.ToLowerInvariant()}"));
        if (o.Owned) Body.AddChild(Text($"Owned by {(o.OwnerName.Length > 0 ? o.OwnerName : "someone")}", 13));
        var rules = new List<string>();
        if (o.MinLevel > 0 || (o.MaxLevel > 0 && o.MaxLevel < 9999)) rules.Add(o.MaxLevel > 0 && o.MaxLevel < 9999 ? $"levels {o.MinLevel} to {o.MaxLevel}" : $"level {o.MinLevel} or above");
        if (o.MinRank > 0) rules.Add($"allegiance rank {o.MinRank} or above");
        if (rules.Count > 0) Body.AddChild(Text("For characters of " + string.Join(", ", rules) + " (as the server has it).", 12, RetailTheme.Dim));

        var cost = new PanelContainer { CustomMinimumSize = new Vector2(0, 96) };
        cost.AddThemeStyleboxOverride("panel", new StyleBoxFlat { BgColor = new Color(0, 0, 0, 0.35f), BorderColor = new Color(0.45f, 0.35f, 0.18f),
            BorderWidthLeft = 1, BorderWidthRight = 1, BorderWidthTop = 1, BorderWidthBottom = 1, ContentMarginLeft = 8, ContentMarginRight = 8, ContentMarginTop = 6, ContentMarginBottom = 6 });
        var lines = new GridContainer { Columns = 3 };
        lines.AddThemeConstantOverride("h_separation", 18);
        cost.AddChild(lines);
        bool covered = true, anyDue = false;
        if (!buying && o.Free) lines.AddChild(Cell("Maintenance is free this period.", 13, new Color(0.55f, 0.95f, 0.45f)));
        else if (due.Count == 0) lines.AddChild(Cell(buying ? "It asks for nothing." : "No upkeep is asked.", 13, RetailTheme.Dim));
        else
        {
            lines.AddChild(Cell("It asks for", 12, RetailTheme.Dim)); lines.AddChild(Cell("due", 12, RetailTheme.Dim)); lines.AddChild(Cell("put in", 12, RetailTheme.Dim));
            foreach (var p in due)
            {
                long put = PutIn(p);
                bool done = p.Left <= 0, enough = done || put >= p.Left;
                if (!done) anyDue = true;
                if (!enough) covered = false;
                var colour = done ? new Color(0.55f, 0.95f, 0.45f) : enough ? RetailTheme.Ink : new Color(1f, 0.6f, 0.45f);
                lines.AddChild(Cell(p.Name, 13, colour));
                lines.AddChild(Cell(done ? "paid" : $"{p.Left:N0}" + (p.Paid > 0 ? $" (of {p.Need:N0})" : ""), 13, colour));
                lines.AddChild(Cell(done ? "" : $"{put:N0}", 13, colour));
            }
        }
        Body.AddChild(cost);

        // below: what you're handing over - dropped here from your packs
        Body.AddChild(Text(_given.Count == 0 ? "Drop your money and the things it asks for here:" : "Handing over (click one, then Remove; double-click takes it back):", 12, RetailTheme.Dim));
        var row = new GiveRow(Across) { Source = "house", Win = this, Count = i => _given.FirstOrDefault(g => g.item == i).amount,
                                        DoubleClicked = i => { _given.RemoveAll(g => g.item == i); if (_picked == i) _picked = null; Refresh(); } };
        int spare = _given.Count < Across ? Across - _given.Count : (Across - _given.Count % Across) % Across;
        row.Fill(_given.Select(g => g.item).ToList(), Icon, i => { _picked = i; Refresh(); }, _picked, spare);
        Body.AddChild(row);
        if (_picked != null && !_given.Any(g => g.item == _picked)) _picked = null;

        var foot = new HBoxContainer { Alignment = BoxContainer.AlignmentMode.Center };
        foot.AddThemeConstantOverride("separation", 8);
        if (buying || (!o.Free && anyDue))
        {
            var go = Small(buying ? "Buy" : "Pay upkeep", () => Pay(buying), _given.Count > 0 && covered);
            go.TooltipText = covered ? "Hands over what you've put in." : "Put in what it asks for first.";
            foot.AddChild(go);
        }
        foot.AddChild(Small("Remove", () => { if (_picked != null) { _given.RemoveAll(g => g.item == _picked); _picked = null; Refresh(); } }, _picked != null));
        foot.AddChild(Small("Clear", () => { _given.Clear(); _picked = null; Refresh(); }, _given.Count > 0));
        foot.AddChild(Small("Close", () => Visible = false));
        Body.AddChild(foot);
        ResetSize();
    }

    private void Pay(bool buy)
    {
        if (_offer is not { } o || Net == null || _given.Count == 0) return;
        Net.HousePay(o, buy, _given.Select(g => g.item.Guid).Distinct().ToList());
        _given.Clear(); _picked = null;
        Visible = false;
    }

    // the row of squares that takes a thing of yours dropped on it
    private sealed partial class GiveRow : ItemGrid
    {
        public HouseWindow Win = null!;
        public GiveRow(int columns) : base(columns) { }
        public override bool CanTake(Item? onto) => ItemSlot.Dragging is { Guid: not 0 } && ItemSlot.DraggingFrom == "pack";
        public override void TakeDrop(int index, Item? onto)
        {
            if (ItemSlot.Dragging is { } it) Win.Give(ItemSlot.SplitFrom ?? it, ItemSlot.SplitFrom != null ? it.Stack : ItemSlot.Splitting?.Invoke(it) ?? 0);
            ItemSlot.Dragging = null;
        }
    }
}
