using System;
using Godot;

namespace ACGodot.UI;

/// <summary>
/// The arrow (as the VVS / GoArrow one): points from where you face to a spot on the map, with how far it is and
/// which way. Set by clicking coordinates in the chat, or /arrow 42.1N 33.6E; a click on it (or /arrow clear) puts
/// it away. Dragged about with the interface unlocked; its place is kept.
/// </summary>
public partial class NavArrow : Control
{
    private Vector3? _target;
    private string _label = "";
    private Vector3 _from;
    private float _facing;
    private Vector2? _at;
    private bool _down, _dragged;
    private Vector2 _grab;
    private const string SavePath = "user://ui.cfg";
    /// <summary>The arrow's size, how solid it is, and its words' size (Map panel) - kept.</summary>
    public float ArrowScale = 1f, Opacity = 1f, TextScale = 1f;

    public void SaveLook()
    {
        var cfg = new ConfigFile(); global::ACGodot.SafeConfig.Load(cfg, SavePath);
        cfg.SetValue("ui", "arrow_scale", (double)ArrowScale); cfg.SetValue("ui", "arrow_opacity", (double)Opacity); cfg.SetValue("ui", "arrow_text", (double)TextScale);
        global::ACGodot.SafeConfig.Save(cfg, SavePath);
    }

    public void ApplyLook() { Modulate = new Color(1, 1, 1, Opacity); QueueRedraw(); }

    public bool Active => _target != null;
    public string Label => _label;

    /// <summary>Where it points, in map coordinates (north, east), or null.</summary>
    public (double ns, double ew)? Target
    {
        get { if (_target is not { } t) return null; var (x, y, _) = World.ToAc(t); return (y / 240.0 - 101.95, x / 240.0 - 101.95); }
    }

    public override void _Ready()
    {
        MouseFilter = MouseFilterEnum.Stop;
        Size = new Vector2(150, 92);
        Visible = false;
        var cfg = new ConfigFile();
        if (global::ACGodot.SafeConfig.Load(cfg, SavePath) == Error.Ok)
        {
            if (cfg.HasSectionKey("ui", "arrow")) _at = (Vector2)cfg.GetValue("ui", "arrow");
            ArrowScale = Math.Clamp((float)(double)cfg.GetValue("ui", "arrow_scale", 1.0), 0.5f, 3f);
            Opacity = Math.Clamp((float)(double)cfg.GetValue("ui", "arrow_opacity", 1.0), 0.15f, 1f);
            TextScale = Math.Clamp((float)(double)cfg.GetValue("ui", "arrow_text", 1.0), 0.5f, 3f);
        }
        ApplyLook();
    }

    public void Point(double ns, double ew, string label)
    {
        var g = World.FromMapCoords(ns, ew);
        _target = g;
        _label = label;
        Visible = true;
        QueueRedraw();
    }

    public void Clear() { _target = null; Visible = false; }

    /// <summary>Each frame: where you are and which way you face (Godot yaw).</summary>
    public void Update(Vector3 from, float facing, Vector2 screen)
    {
        if (_target == null) return;
        _from = from; _facing = facing;
        Position = _at ?? new Vector2((screen.X - Size.X) * 0.5f, 58);
        QueueRedraw();
    }

    // drawn as MelksQB's travel window draws its arrow: the same shape, colours and font - green when you face it (within
    // 15 degrees), yellow when you don't, the place in yellow and the distance in white beside it, on a dark panel
    private static readonly Color Green = new(0.45f, 0.9f, 0.45f), Yellow = new(0.95f, 0.85f, 0.35f), Edge = new(0, 0, 0, 0.8f), Panel = new(0.06f, 0.06f, 0.08f, 0.8f);
    private static Font? _font;

    /// <summary>The plugins' windows' font (Noto Sans, as UtilityBelt's), else Godot's own.</summary>
    private static Font TextFont()
    {
        if (_font != null) return _font;
        foreach (var f in global::ACGodot.UI.RetailTheme.NotoPaths)
            if (System.IO.File.Exists(f)) { var ff = new FontFile(); if (ff.LoadDynamicFont(f) == Error.Ok) { _font = ff; return ff; } }
        return _font = ThemeDB.FallbackFont;
    }

    public override void _Draw() { long __fw = ACGodot.FrameWatch.DrawStart(); try { DrawBody(); } finally { ACGodot.FrameWatch.Drew("NavArrow", __fw); } }
    private void DrawBody()
    {
        if (_target is not { } t) return;
        var font = TextFont();
        float dx = t.X - _from.X, dz = t.Z - _from.Z;
        float dist = MathF.Sqrt(dx * dx + dz * dz);
        float bearing = MathF.Atan2(dx, -dz);                  // clockwise from north
        float rel = bearing + _facing;                          // from where you face (your facing's bearing is -yaw)
        float k = ArrowScale;
        int fs = Math.Max(8, (int)MathF.Round(16f * RetailFont.Scale * TextScale));
        bool here = dist < 3f;
        float off = ((rel % MathF.Tau) + MathF.Tau + MathF.PI) % MathF.Tau - MathF.PI;
        bool facing = MathF.Abs(off) < 15f * MathF.PI / 180f;
        float units = dist / 240f;
        string distText = units < 0.2f ? $"{(int)MathF.Round(dist)} m" : units.ToString(units < 10 ? "0.00" : "0.0", System.Globalization.CultureInfo.InvariantCulture);
        string line1 = here ? "You're there" : _label;
        string line2 = here ? _label : $"{distText}  {Compass(bearing)}";
        float lineH = font.GetHeight(fs);
        float textW = Math.Max(font.GetStringSize(line1, HorizontalAlignment.Left, -1, fs).X, font.GetStringSize(line2, HorizontalAlignment.Left, -1, fs).X);
        float size = 64f * k, pad = 8f;
        var want = new Vector2(pad + size + 8f + textW + pad, pad * 2 + Math.Max(size, lineH * 2 + 4f));
        if (Size != want) Size = want;
        DrawStyleBox(new StyleBoxFlat { BgColor = Panel, CornerRadiusTopLeft = 6, CornerRadiusTopRight = 6, CornerRadiusBottomLeft = 6, CornerRadiusBottomRight = 6 }, new Rect2(Vector2.Zero, Size));
        var c = new Vector2(pad + size / 2, Size.Y / 2);
        if (here) DrawCircle(c, size * 0.2f, Green);
        else
        {
            float r = size * 0.42f, cs = MathF.Cos(rel), sn = MathF.Sin(rel);
            Vector2 P(float x, float y) => c + new Vector2(x * cs - y * sn, x * sn + y * cs);
            Vector2 tip = P(0, -r), left = P(-0.6f * r, 0.7f * r), notch = P(0, 0.3f * r), right = P(0.6f * r, 0.7f * r);
            var col = facing ? Green : Yellow;
            DrawColoredPolygon(new[] { tip, left, notch }, col);
            DrawColoredPolygon(new[] { tip, notch, right }, col);
            DrawPolyline(new[] { tip, left, notch, right, tip }, Edge, 1.5f * k, true);
        }
        float tx = pad + size + 8f, ty = Size.Y / 2 - lineH - 2f + font.GetAscent(fs);
        DrawString(font, new Vector2(tx, ty), line1, HorizontalAlignment.Left, -1, fs, here ? Green : Yellow);
        DrawString(font, new Vector2(tx, ty + lineH + 4f), line2, HorizontalAlignment.Left, -1, fs, here ? Yellow : Colors.White);
    }

    private static string Compass(float bearing)
    {
        string[] names = { "N", "NE", "E", "SE", "S", "SW", "W", "NW" };
        int i = (int)MathF.Round(((bearing % MathF.Tau) + MathF.Tau) % MathF.Tau / (MathF.Tau / 8)) % 8;
        return names[i];
    }

    public override void _GuiInput(InputEvent e)
    {
        if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb)
        {
            if (mb.Pressed) { _down = true; _dragged = false; _grab = GetGlobalMousePosition() - Position; }
            else
            {
                if (_down && !_dragged) Clear();   // a click: put it away
                if (_dragged) { var cfg = new ConfigFile(); global::ACGodot.SafeConfig.Load(cfg, SavePath); cfg.SetValue("ui", "arrow", Position); global::ACGodot.SafeConfig.Save(cfg, SavePath); }
                _down = false;
            }
            AcceptEvent();
        }
        else if (e is InputEventMouseMotion && _down && !UiLock.Locked)
        {
            var p = GetGlobalMousePosition() - _grab;
            if (!_dragged && p.DistanceTo(Position) < 3) return;
            _dragged = true;
            Position = p; _at = p;
            AcceptEvent();
        }
    }
}
