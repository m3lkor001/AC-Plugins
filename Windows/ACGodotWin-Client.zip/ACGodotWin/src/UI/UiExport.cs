using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.Json;
using AcDream.Core.Textures;
using DatReaderWriter.DBObjs;
using DatReaderWriter.Types;
using Godot;

namespace ACGodot.UI;

/// <summary>
/// Writes the game's own interface (its layouts: every window and panel, from the data files) to a zip: each layout
/// as JSON (its elements, their places, states, images and properties), a picture of each as it first appears, and
/// every image they use - to work out which layout is which and build the game's interface from them.
/// </summary>
public static class UiExport
{
    public static string Export(Dats dats, string path)
    {
        var images = new Dictionary<uint, Image?>();
        Image? Img(uint id)
        {
            if (images.TryGetValue(id, out var im)) return im;
            im = null;
            try
            {
                var rs = dats.Portal<RenderSurface>(id);
                if (rs != null)
                {
                    Palette? pal = rs.DefaultPaletteId != 0 ? dats.Portal<Palette>(rs.DefaultPaletteId) : null;
                    var d = SurfaceDecoder.DecodeRenderSurface(rs, pal);
                    if (d.Width > 0 && d.Height > 0) im = Image.CreateFromData(d.Width, d.Height, false, Image.Format.Rgba8, d.Rgba8);
                }
            }
            catch { im = null; }
            return images[id] = im;
        }

        System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(path)!);
        System.IO.File.WriteAllText(System.IO.Path.Combine(System.IO.Path.GetDirectoryName(path)!, ".gdignore"), "");
        var zip = new ZipPacker();
        if (zip.Open(path) != Error.Ok) return "couldn't write " + path;
        int layouts = 0;
        foreach (uint id in dats.AllIds<LayoutDesc>())
        {
            LayoutDesc? l;
            try { l = dats.Get<LayoutDesc>(id); } catch (Exception ex) { GD.PushWarning($"layout {id:X8}: {ex.Message}"); continue; }
            if (l == null) continue;
            layouts++;
            var json = JsonSerializer.Serialize(new { id = $"{id:X8}", width = l.Width, height = l.Height, elements = l.Elements.Values.Select(Elem).ToList() },
                                                new JsonSerializerOptions { WriteIndented = true });
            Add(zip, $"layouts/{id:X8}.json", Encoding.UTF8.GetBytes(json));
            // a picture: each element's first image, where it is
            int W = (int)Math.Clamp(l.Width, 1, 2048), H = (int)Math.Clamp(l.Height, 1, 2048);
            var pic = Image.CreateEmpty(W, H, false, Image.Format.Rgba8);
            pic.Fill(new Color(0.2f, 0.0f, 0.2f, 1f));
            foreach (var e in l.Elements.Values.OrderBy(e => e.ZLevel)) Draw(pic, e, 0, 0, Img);
            Add(zip, $"pictures/{id:X8}.png", pic.SavePngToBuffer());
        }
        foreach (var kv in images)
            if (kv.Value != null) Add(zip, $"images/{kv.Key:X8}.png", kv.Value.SavePngToBuffer());
        zip.Close();
        return $"wrote {layouts} interface layouts and {images.Count(i => i.Value != null)} images to {path}";
    }

    private static void Add(ZipPacker zip, string name, byte[] data)
    {
        zip.StartFile(name);
        zip.WriteFile(data);
        zip.CloseFile();
    }

    private static uint FirstImage(StateDesc? s)
    {
        if (s == null) return 0;
        foreach (var m in s.Media)
        {
            if (m is MediaDescImage im) return im.File;
            if (m is MediaDescAnimation an && an.Frames.Count > 0) return an.Frames[0];
        }
        return 0;
    }

    private static void Draw(Image pic, ElementDesc e, int ox, int oy, Func<uint, Image?> img)
    {
        int x = ox + (int)e.X, y = oy + (int)e.Y, w = (int)e.Width, h = (int)e.Height;
        uint file = FirstImage(e.StateDesc);
        if (file == 0 && e.States.TryGetValue(e.DefaultState, out var ds)) file = FirstImage(ds);
        if (file != 0 && w > 0 && h > 0 && w <= 4096 && h <= 4096 && img(file) is { } src)
        {
            var part = (Image)src.Duplicate();
            if (part.GetWidth() != w || part.GetHeight() != h)
            {
                // tiled, as the game draws a small image over a larger element
                var tiled = Image.CreateEmpty(w, h, false, Image.Format.Rgba8);
                for (int ty = 0; ty < h; ty += part.GetHeight())
                    for (int tx = 0; tx < w; tx += part.GetWidth())
                        tiled.BlendRect(part, new Rect2I(0, 0, Math.Min(part.GetWidth(), w - tx), Math.Min(part.GetHeight(), h - ty)), new Vector2I(tx, ty));
                part = tiled;
            }
            pic.BlendRect(part, new Rect2I(0, 0, w, h), new Vector2I(x, y));
        }
        foreach (var c in e.Children.Values.OrderBy(c => c.ZLevel)) Draw(pic, c, x, y, img);
    }

    private static object Elem(ElementDesc e) => new
    {
        id = $"{e.ElementId:X8}", type = e.Type, x = e.X, y = e.Y, w = e.Width, h = e.Height, z = e.ZLevel,
        edges = new[] { e.LeftEdge, e.TopEdge, e.RightEdge, e.BottomEdge },
        baseElement = e.BaseElement != 0 ? $"{e.BaseElement:X8}" : null,
        baseLayout = e.BaseLayoutId != 0 ? $"{e.BaseLayoutId:X8}" : null,
        defaultState = e.DefaultState.ToString(),
        state = State(e.StateDesc),
        states = e.States.ToDictionary(kv => kv.Key.ToString(), kv => State(kv.Value)),
        children = e.Children.Values.Select(Elem).ToList(),
    };

    private static object? State(StateDesc? s)
    {
        if (s == null) return null;
        return new
        {
            media = s.Media.Select(Media).ToList(),
            props = s.Properties.ToDictionary(kv => $"{kv.Key:X8}", kv => PropText(kv.Value)),
        };
    }

    private static string Media(MediaDesc m) => m switch
    {
        MediaDescImage im => $"image {im.File:X8} {im.DrawMode}",
        MediaDescAnimation an => $"animation {an.Duration} {string.Join(",", an.Frames.Select(f => f.ToString("X8")))}",
        MediaDescCursor c => $"cursor {c.File:X8}",
        MediaDescSound so => $"sound {so.File:X8} {so.Sound}",
        MediaDescAlpha a => $"alpha {a.File:X8}",
        MediaDescState st => $"state {st.StateId}",
        _ => m.Type.ToString(),
    };

    private static string PropText(BaseProperty p)
    {
        try
        {
            var v = p.GetType().GetField("Value")?.GetValue(p) ?? p.GetType().GetProperty("Value")?.GetValue(p);
            string val = v switch
            {
                null => p.ToString() ?? "",
                System.Collections.IEnumerable list when v is not string => "[" + string.Join(", ", list.Cast<object>().Select(o => o is BaseProperty bp ? PropText(bp) : o?.ToString())) + "]",
                _ => v.ToString() ?? "",
            };
            return $"{p.PropertyType}: {val}";
        }
        catch (Exception ex) { return "?" + ex.Message; }
    }
}
