using System;
using Godot;

namespace ACGodot.UI;

/// <summary>
/// The plugin bar (top left, as Decal's): a small button for each plugin - its window, or its command - and any a
/// plugin adds itself. Dragged by its handle with the interface unlocked; its place is kept.
/// </summary>
public partial class PluginBar : PanelContainer
{
    public Plugins.PluginHost? Host;
    public Func<uint, Texture2D?> Icon = _ => null;
    private HBoxContainer _row = null!;
    private const string SavePath = "user://ui.cfg";

    public override void _Ready()
    {
        if (RetailTheme.Current is { } th) Theme = th;
        AddThemeStyleboxOverride("panel", new StyleBoxFlat { BgColor = new Color(0.05f, 0.04f, 0.02f, 0.85f), BorderColor = new Color(0.55f, 0.43f, 0.2f),
                                                             BorderWidthLeft = 1, BorderWidthRight = 1, BorderWidthTop = 1, BorderWidthBottom = 1,
                                                             ContentMarginLeft = 2, ContentMarginRight = 2, ContentMarginTop = 1, ContentMarginBottom = 1 });
        MouseFilter = MouseFilterEnum.Stop;
        var h = new HBoxContainer();
        h.AddThemeConstantOverride("separation", 2);
        AddChild(h);
        var handle = new ColorRect { Color = new Color(0.55f, 0.43f, 0.2f, 0.8f), CustomMinimumSize = new Vector2(5, 16), MouseDefaultCursorShape = CursorShape.Move, TooltipText = "Plugins (drag to move when unlocked)" };
        bool down = false; Vector2 grab = Vector2.Zero;
        handle.GuiInput += e =>
        {
            if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb) { down = mb.Pressed && !UiLock.Locked; grab = GetGlobalMousePosition() - Position; if (!mb.Pressed) Save(); handle.AcceptEvent(); }
            else if (e is InputEventMouseMotion && down) { Position = GetGlobalMousePosition() - grab; handle.AcceptEvent(); }
        };
        h.AddChild(handle);
        _row = new HBoxContainer();
        _row.AddThemeConstantOverride("separation", 2);
        h.AddChild(_row);
        var cfg = new ConfigFile();
        Position = global::ACGodot.SafeConfig.Load(cfg, SavePath) == Error.Ok && cfg.HasSectionKey("ui", "pluginbar") ? (Vector2)cfg.GetValue("ui", "pluginbar") : new Vector2(4, 4);
        if (Host != null) Host.BarChanged += Rebuild;
        Rebuild();
    }

    private void Save() { var c = new ConfigFile(); global::ACGodot.SafeConfig.Load(c, SavePath); c.SetValue("ui", "pluginbar", Position); global::ACGodot.SafeConfig.Save(c, SavePath); }

    public void Rebuild()
    {
        if (_row == null || Host == null) return;
        foreach (var c in _row.GetChildren()) { _row.RemoveChild(c); c.QueueFree(); }
        foreach (var it in Host.BarItems)
        {
            var item = it;
            var b = new Button { FocusMode = FocusModeEnum.None, TooltipText = string.IsNullOrEmpty(it.Tip) ? it.Label : $"{it.Label}: {it.Tip}", CustomMinimumSize = new Vector2(18, 18) };
            var tex = it.Icon != 0 ? Icon(it.Icon) : null;
            if (tex != null) { b.Icon = tex; b.ExpandIcon = true; b.CustomMinimumSize = new Vector2(20, 20); }
            else b.Text = it.Label.Length > 6 ? it.Label[..6] : it.Label;
            b.AddThemeStyleboxOverride("normal", new StyleBoxFlat { BgColor = new Color(0.15f, 0.1f, 0.05f, 0.9f), ContentMarginLeft = 3, ContentMarginRight = 3 });
            b.AddThemeStyleboxOverride("hover", new StyleBoxFlat { BgColor = new Color(0.35f, 0.25f, 0.1f, 0.95f), ContentMarginLeft = 3, ContentMarginRight = 3 });
            b.AddThemeStyleboxOverride("pressed", new StyleBoxFlat { BgColor = new Color(0.5f, 0.35f, 0.1f, 0.95f), ContentMarginLeft = 3, ContentMarginRight = 3 });
            b.Pressed += () => item.Run();
            _row.AddChild(b);
        }
        Size = GetCombinedMinimumSize();
    }
}
