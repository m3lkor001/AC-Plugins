using System;
using Godot;

namespace ACGodot.UI;

/// <summary>A yes-or-no the server asks (swearing allegiance, a fellowship's invitation, a risky craft): its words, Yes and No.</summary>
public partial class ConfirmWindow : Combat.GameWindow
{
    private Action<bool>? _answer;

    // (twice as wide as it was, and as tall as its words need: never a scroll bar to read a question by)
    private const float Wide = 680f;
    public ConfirmWindow() : base("Confirm", new Vector2(Wide, 0))
    {
        Closed = () => Answer(false);
        Scroll.VerticalScrollMode = ScrollContainer.ScrollMode.Disabled;
        Scroll.CustomMinimumSize = new Vector2(Wide - 16f, 0);
        Scroll.HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled;
    }

    public void Ask(string words, Action<bool> answer)
    {
        if (Visible) Answer(false);   // (one still up: it's a no)
        _answer = answer;
        Clear();
        var text = Text(words, 13);
        text.HorizontalAlignment = HorizontalAlignment.Center;
        Body.AddChild(text);
        var row = new HBoxContainer { Alignment = BoxContainer.AlignmentMode.Center };
        row.AddThemeConstantOverride("separation", 24);
        row.AddChild(Small("Yes", () => Answer(true)));
        row.AddChild(Small("No", () => Answer(false)));
        Body.AddChild(row);
        text.AutowrapMode = TextServer.AutowrapMode.WordSmart;
        text.CustomMinimumSize = new Vector2(Wide - 40f, 0);
        Visible = true;
        MoveToFront();
        // as small as its words allow (it grows to fit them), then put in the middle once it knows its height
        CustomMinimumSize = new Vector2(Wide, 0);
        Size = new Vector2(Wide, 0);
        Position = (GetViewportRect().Size - new Vector2(Wide, 160)) * 0.5f;
        Callable.From(() => { if (Visible) { Size = new Vector2(Wide, 0); Position = ((GetViewportRect().Size - GetCombinedMinimumSize().Max(new Vector2(Wide, 0))) * 0.5f).Max(Vector2.Zero); } }).CallDeferred();
    }

    /// <summary>The server took the question back (it ran out).</summary>
    public void Withdraw() { _answer = null; Visible = false; }

    private void Answer(bool yes)
    {
        var a = _answer; _answer = null;
        Visible = false;
        a?.Invoke(yes);
    }
}
