using System;
using System.Collections.Generic;
using System.Linq;
using Godot;

namespace ACGodot.UI;

/// <summary>
/// The lines at the top of the screen saying what you're doing or why you can't ("Casting Strength Self I",
/// "You're too busy!", "Entering Magic Combat mode"): the newest where the game puts it, the ones before pushed up
/// above it - three at most, each gone after a few seconds. Which kinds show is chosen in Options > Gameplay
/// (kept in user://ui.cfg).
/// </summary>
public partial class StatusLine : Label
{
    /// <summary>The kinds of message that can be switched off, each with what the options call it.</summary>
    public static readonly (string key, string name)[] Kinds =
    {
        ("cast", "Casting a spell"),
        ("mode", "Changing combat mode"),
        ("gear", "Wielding, putting on and removing things"),
        ("pet", "Summoning and dismissing pets"),
        ("server", "What the server says (too busy, not ready, out of range...)"),
    };
    private const string Cfg = "user://ui.cfg";
    private static Dictionary<string, bool>? _on;
    private static Dictionary<string, bool> On
    {
        get
        {
            if (_on != null) return _on;
            _on = new();
            var c = new ConfigFile(); global::ACGodot.SafeConfig.Load(c, Cfg);
            _on["all"] = (bool)c.GetValue("status", "all", true);
            foreach (var (k, _) in Kinds) _on[k] = (bool)c.GetValue("status", k, true);
            return _on;
        }
    }
    /// <summary>Whether a kind shows ("all": any of them).</summary>
    public static bool Shows(string kind) => !On.TryGetValue(kind, out bool v) || v;
    public static void SetShows(string kind, bool on)
    {
        On[kind] = on;
        var c = new ConfigFile(); global::ACGodot.SafeConfig.Load(c, Cfg); c.SetValue("status", kind, on); global::ACGodot.SafeConfig.Save(c, Cfg);
    }

    private const int Most = 3;
    private const double Stays = 5;
    private readonly List<(string text, double left)> _lines = new();

    public StatusLine()
    {
        MouseFilter = MouseFilterEnum.Ignore;
        HorizontalAlignment = HorizontalAlignment.Center;
        VerticalAlignment = VerticalAlignment.Bottom;
        // (the newest line sits where one alone does; the ones before it are above)
        AnchorLeft = 0; AnchorRight = 1; OffsetTop = 60; OffsetBottom = 84;
        GrowVertical = GrowDirection.Begin;   // (more lines: upwards)
        AddThemeFontSizeOverride("font_size", 18);
        AddThemeConstantOverride("line_spacing", 0);
        AddThemeColorOverride("font_color", new Color(1f, 0.95f, 0.6f));
        AddThemeColorOverride("font_outline_color", Colors.Black);
        AddThemeConstantOverride("outline_size", 5);
        ZIndex = 50;   // (over the windows that sit along the top)
        Visible = false;
    }

    public void Show(string text, string kind = "server")
    {
        if (string.IsNullOrWhiteSpace(text) || !Shows("all") || !Shows(kind)) return;
        _lines.Add((text, Stays));
        while (_lines.Count > Most) _lines.RemoveAt(0);
        Lay();
    }

    private void Lay()
    {
        Text = string.Join("\n", _lines.Select(l => l.text));
        Visible = _lines.Count > 0;
    }

    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("StatusLine");
        if (_lines.Count == 0) return;
        bool gone = false;
        for (int i = _lines.Count - 1; i >= 0; i--)
        {
            var l = _lines[i];
            l.left -= delta;
            if (l.left <= 0) { _lines.RemoveAt(i); gone = true; } else _lines[i] = l;
        }
        if (gone) Lay();
    }
}
