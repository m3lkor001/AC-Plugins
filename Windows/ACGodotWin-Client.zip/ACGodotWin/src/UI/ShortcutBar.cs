using System;
using System.Collections.Generic;
using System.Linq;
using Godot;

namespace ACGodot.UI;

/// <summary>
/// The shortcut bar: eight tabs (I-VIII) of slots for items and spells, as many rows and as long as you size it
/// (drag its bottom-right corner; drag its left handle to move it). Items are dragged onto it from the pack, spells
/// from the spellbook; slots are dragged about on it, or off it to clear them (one dropped on another pushes it along to the next empty slot; right-click identifies). A click selects an item (a
/// double-click, or 1-9, 0 for the first ten of the tab showing, uses it); a click casts a spell: an item is wielded/worn or taken off, a spell is cast.
/// Kept in user://shortcuts.cfg.
/// </summary>
public partial class ShortcutBar : PanelContainer
{
    public const int Tabs = 8, MaxSlots = 120, SlotSize = 32;
    private static readonly string[] TabNames = { "I", "II", "III", "IV", "V", "VI", "VII", "VIII" };
    private const string SavePath = "user://shortcuts.cfg";

    /// <summary>One slot's contents: an item (by its kind) or a spell (by its id).</summary>
    /// <param name="Guid">An item on a server: the server's own number for that very object (0: none - by its kind and name).</param>
    public record Entry(string Kind, int Id, string Name, uint Icon, uint Guid = 0);

    private readonly Entry?[,] _slots = new Entry?[Tabs, MaxSlots];
    private int _tab, _rows = 2, _cols = 9;
    private HBoxContainer _tabRow = null!;
    private GridContainer _grid = null!;
    private Label _caption = null!;
    private Vector2? _at;
    private bool _loaded;

    /// <summary>Uses an entry (Main wires items to the pack, spells to magic).</summary>
    public Action<Entry>? Use;
    /// <summary>A right click on a slot: identify what's in it.</summary>
    public Action<Entry>? Identify;
    /// <summary>A click on an item's slot: select it.</summary>
    public Action<Entry>? Select;
    /// <summary>The item an entry stands for, as carried just now (null: none on you), and how many of its kind are.</summary>
    public Func<Entry, Combat.Item?>? ItemOf;
    public Func<Entry, int>? CountOf;
    /// <summary>An icon for a picture id.</summary>
    public Func<uint, Texture2D?>? Icon;

    /// <summary>What a slot being dragged carries (to move it on the bar).</summary>
    public static (int tab, int slot)? DraggingSlot;
    /// <summary>A spell being dragged from the spellbook (its entry).</summary>
    public static Entry? DraggingSpell;

    public int Slots => _rows * _cols;

    /// <summary>The number key (1-9, 0) of the slot an item is on in the tab showing, or -1 when it's on none of the numbered ones.</summary>
    public int NumberOf(Combat.Item it)
    {
        if (ItemOf == null) return -1;
        for (int i = 0; i < 10 && i < Slots; i++)
            if (_slots[_tab, i] is { Kind: "item" } e && ReferenceEquals(ItemOf(e), it)) return (i + 1) % 10;
        return -1;
    }

    public override void _Ready()
    {
        MouseFilter = MouseFilterEnum.Stop;
        if (RetailTheme.Current is { } th) Theme = th;
        var h = new HBoxContainer();
        h.AddThemeConstantOverride("separation", 3);
        AddChild(h);
        // the handle: drag to move it
        var handle = new ColorRect { Color = new Color(0.55f, 0.43f, 0.2f, 0.7f), CustomMinimumSize = new Vector2(6, 0), MouseDefaultCursorShape = CursorShape.Move,
                                     TooltipText = "Drag to move the shortcut bar" };
        h.AddChild(handle);
        bool down = false; Vector2 grab = Vector2.Zero;
        handle.GuiInput += e =>
        {
            if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb) { down = mb.Pressed; grab = GetGlobalMousePosition() - Position; if (!mb.Pressed) Save(); handle.AcceptEvent(); }
            else if (e is InputEventMouseMotion && down && !UiLock.Locked)
            {
                var p = GetGlobalMousePosition() - grab;
                var vp = GetViewportRect().Size;
                Position = new Vector2(Math.Clamp(p.X, 0, Math.Max(0, vp.X - Size.X)), Math.Clamp(p.Y, 0, Math.Max(0, vp.Y - Size.Y)));   // (stops at the screen's edges)
                _at = Position; handle.AcceptEvent();
            }
        };
        var v = new VBoxContainer();
        v.AddThemeConstantOverride("separation", 2);
        h.AddChild(v);
        _tabRow = new HBoxContainer();
        _tabRow.AddThemeConstantOverride("separation", 1);
        v.AddChild(_tabRow);
        _grid = new GridContainer();
        _grid.AddThemeConstantOverride("h_separation", 2);
        _grid.AddThemeConstantOverride("v_separation", 2);
        v.AddChild(_grid);
        var foot = new HBoxContainer();
        _caption = new Label { Text = "", CustomMinimumSize = new Vector2(0, 14), SizeFlagsHorizontal = SizeFlags.ExpandFill, ClipText = true };
        foot.AddChild(_caption);
        // the corner: drag to give it more or fewer rows and slots
        var grip = new Label { Text = "◢", MouseFilter = MouseFilterEnum.Stop, MouseDefaultCursorShape = CursorShape.Fdiagsize, TooltipText = "Drag to size the shortcut bar" };
        grip.AddThemeColorOverride("font_color", new Color(0.8f, 0.65f, 0.3f));
        bool sizing = false; Vector2 from = Vector2.Zero; int r0 = 0, c0 = 0;
        grip.GuiInput += e =>
        {
            if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb) { sizing = mb.Pressed; from = GetGlobalMousePosition(); r0 = _rows; c0 = _cols; if (!mb.Pressed) Save(); grip.AcceptEvent(); }
            else if (e is InputEventMouseMotion && sizing)
            {
                var d = GetGlobalMousePosition() - from;
                int cols = Math.Clamp(c0 + (int)Math.Round(d.X / (SlotSize + 2)), 4, 40);
                int rows = Math.Clamp(r0 + (int)Math.Round(d.Y / (SlotSize + 2)), 1, 10);
                while (rows * cols > MaxSlots) cols--;
                if (rows != _rows || cols != _cols) { _rows = rows; _cols = cols; Rebuild(); }
                grip.AcceptEvent();
            }
        };
        foot.AddChild(grip);
        v.AddChild(foot);
        Load();
        Rebuild();
    }

    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("ShortcutBar");
        if (Theme == null && RetailTheme.Current is { } th) Theme = th;
    }

    /// <summary>Draws it again (once its icons can be found).</summary>
    public void Refresh() => Rebuild();

    /// <summary>Where it sits: where it was left, or just above the vitals in the middle.</summary>
    public void Place(Vector2 screen, float above)
    {
        Vector2 size = GetCombinedMinimumSize();
        Size = size;
        Vector2 p = _at ?? new Vector2((screen.X - size.X) * 0.5f, above - size.Y - 4);
        Position = new Vector2(Math.Clamp(p.X, 0, Math.Max(0, screen.X - size.X)), Math.Clamp(p.Y, 0, Math.Max(0, screen.Y - size.Y)));
    }

    /// <summary>Its top, for what sits above it.</summary>
    public float Top => Visible ? Position.Y : float.MaxValue;
    public bool Moved => _at != null;

    private readonly List<Entry> _notYet = new();
    /// <summary>Drawn again if an item on it that wasn't known when it was drawn now is (its picture on its backing).</summary>
    public void RefreshIfFound()
    {
        if (_notYet.Count == 0 || ItemOf == null) return;
        foreach (var e in _notYet) if (ItemOf(e) != null) { Rebuild(); return; }
    }

    private void Rebuild()
    {
        if (_tabRow == null) return;
        _notYet.Clear();
        Combat.ItemSlot.QuickRedraw();   // (the numbers on the pack's squares go by what's on the bar)
        foreach (var c in _tabRow.GetChildren()) { _tabRow.RemoveChild(c); c.QueueFree(); }
        foreach (var c in _grid.GetChildren()) { _grid.RemoveChild(c); c.QueueFree(); }
        for (int t = 0; t < Tabs; t++)
        {
            int tt = t;
            var b = new Button { Text = TabNames[t], ToggleMode = true, ButtonPressed = t == _tab, FocusMode = FocusModeEnum.None, CustomMinimumSize = new Vector2(30, 0) };
            b.Pressed += () => { _tab = tt; Save(); Rebuild(); };
            _tabRow.AddChild(b);
        }
        _grid.Columns = _cols;
        var empty = new StyleBoxFlat { BgColor = new Color(0f, 0f, 0f, 0.55f), BorderColor = new Color(0.35f, 0.28f, 0.15f),
                                       BorderWidthLeft = 1, BorderWidthRight = 1, BorderWidthTop = 1, BorderWidthBottom = 1 };
        var hover = (StyleBoxFlat)empty.Duplicate(); hover.BorderColor = new Color(0.85f, 0.7f, 0.3f);
        for (int i = 0; i < Slots; i++)
        {
            int ii = i;
            var e = _slots[_tab, i];
            var b = new SlotButton { Bar = this, Tab = _tab, Slot = i, CustomMinimumSize = new Vector2(SlotSize, SlotSize), FocusMode = FocusModeEnum.None, ExpandIcon = true,
                                     IconAlignment = HorizontalAlignment.Center, VerticalIconAlignment = VerticalAlignment.Center,
                                     TooltipText = e == null ? "" : e.Name };
            b.AddThemeStyleboxOverride("normal", empty); b.AddThemeStyleboxOverride("hover", hover); b.AddThemeStyleboxOverride("pressed", hover);
            b.AddThemeStyleboxOverride("focus", new StyleBoxEmpty());
            // (an item: its picture as the pack shows it - on its backing, whose colour says what a weapon's rend is)
            if (e != null) b.Icon = e.Kind == "item" && Icon != null && ItemOf?.Invoke(e) is { } held ? held.Picture(Icon) : Icon?.Invoke(e.Icon);
            // (an item not known yet - its things still coming in after logging in: drawn plain for now, again once it's there)
            if (e is { Kind: "item" } && ItemOf != null && ItemOf(e) == null) _notYet.Add(e);
            if (e != null && b.Icon == null) { b.Text = e.Name.Length > 3 ? e.Name[..3] : e.Name; b.ClipText = true; }
            // an item: its uses left and its cooldown, as on its square in the pack
            if (e is { Kind: "item" } ie && ItemOf != null) b.AddChild(new Combat.UseBar(() => ItemOf(ie), SlotSize));
            if (i < 10)
            {
                var num = new Label { Text = ((i + 1) % 10).ToString(), MouseFilter = MouseFilterEnum.Ignore, Position = new Vector2(2, 0) };
                num.AddThemeColorOverride("font_color", new Color(1f, 0.95f, 0.7f));
                b.AddChild(num);
            }
            b.GuiInput += ev =>
            {
                if (ev is InputEventMouseButton { ButtonIndex: MouseButton.Right, Pressed: true }) { if (_slots[_tab, ii] is { } se) Identify?.Invoke(se); b.AcceptEvent(); }
            };
            // an item: a click selects it (its name in the control bar), a double-click uses it; a spell: a click casts it
            b.Pressed += () => { if (_slots[_tab, ii] is { Kind: "item" } it) Select?.Invoke(it); else Activate(ii); };
            b.GuiInput += ev =>
            {
                if (ev is InputEventMouseButton { ButtonIndex: MouseButton.Left, DoubleClick: true } && _slots[_tab, ii] is { Kind: "item" }) { Activate(ii); b.AcceptEvent(); }
            };
            b.MouseEntered += () => _caption.Text = _slots[_tab, ii]?.Name ?? "";
            b.MouseExited += () => _caption.Text = "";
            _grid.AddChild(b);
        }
        Size = GetCombinedMinimumSize();
    }

    /// <summary>Uses a slot of the tab showing (0-based).</summary>
    public void Activate(int slot)
    {
        if (slot < 0 || slot >= Slots) return;
        if (_slots[_tab, slot] is { } e) Use?.Invoke(e);
    }

    /// <summary>Puts something in the first empty slot of the tab showing. False if it's full.</summary>
    public bool Add(Entry e)
    {
        for (int i = 0; i < Slots; i++)
            if (_slots[_tab, i] == null) { _slots[_tab, i] = e; Save(); Rebuild(); return true; }
        return false;
    }

    public Entry? Get(int tab, int slot) => _slots[tab, slot];

    /// <summary>Puts an entry in a slot (a drop); what was there swaps to where the dropped one came from, if it came off the bar.</summary>
    public void Put(int tab, int slot, Entry e, (int tab, int slot)? from)
    {
        if (from == (tab, slot)) return;
        if (from is { } f) _slots[f.tab, f.slot] = null;
        var old = _slots[tab, slot];
        _slots[tab, slot] = e;
        // what was there moves along to the next empty slot (gone if there's none)
        if (old != null)
            for (int k = 1; k < Slots; k++)
            {
                int i = (slot + k) % Slots;
                if (_slots[tab, i] == null) { _slots[tab, i] = old; break; }
            }
        Save(); Rebuild();
    }

    /// <summary>A slot dragged off the bar (dropped anywhere else): cleared.</summary>
    public void ClearSlot(int tab, int slot) { _slots[tab, slot] = null; Save(); Rebuild(); }

    private void Load()
    {
        if (_loaded) return;
        _loaded = true;
        var cfg = new ConfigFile();
        if (global::ACGodot.SafeConfig.Load(cfg, SavePath) != Error.Ok) return;
        _tab = Math.Clamp((int)cfg.GetValue("bar", "tab", 0), 0, Tabs - 1);
        _rows = Math.Clamp((int)cfg.GetValue("bar", "rows", 2), 1, 10);
        _cols = Math.Clamp((int)cfg.GetValue("bar", "cols", 9), 4, 40);
        if (cfg.HasSectionKey("bar", "at")) _at = (Vector2)cfg.GetValue("bar", "at");
        ReadSlots(cfg);
    }

    // whose shortcuts these are: each character on a server has its own (the bar's place and shape are everyone's)
    private string _who = "";
    private string Section => _who.Length == 0 ? "slots" : "slots:" + _who;

    private void ReadSlots(ConfigFile cfg)
    {
        for (int t = 0; t < Tabs; t++) for (int i = 0; i < MaxSlots; i++) _slots[t, i] = null;
        // (a character with none kept yet: the ones kept before characters had their own go to the first to come - after
        // that, a new character starts with an empty bar)
        string from = Section;
        if (!cfg.HasSection(from)) { if (_who.Length == 0 || cfg.GetSections().Any(x => x.StartsWith("slots:"))) return; from = "slots"; }
        if (!cfg.HasSection(from)) return;
        for (int t = 0; t < Tabs; t++)
            for (int i = 0; i < MaxSlots; i++)
            {
                string key = $"t{t}s{i}";
                if (!cfg.HasSectionKey(from, key)) continue;
                var p = ((string)cfg.GetValue(from, key)).Split('|');
                // (a last part "g<number>": the very object it is)
                uint guid = 0;
                if (p.Length >= 5 && p[^1].Length > 1 && p[^1][0] == 'g' && uint.TryParse(p[^1][1..], System.Globalization.NumberStyles.HexNumber, null, out guid)) p = p[..^1];
                if (p.Length >= 4 && int.TryParse(p[1], out int id) && uint.TryParse(p[^1], out uint icon))
                    _slots[t, i] = new Entry(p[0], id, string.Join("|", p[2..^1]), icon, guid);
            }
    }

    /// <summary>The bar is this character's from now (a server and a name): theirs are shown, and kept apart from others'.</summary>
    public void ForCharacter(string who)
    {
        if (who == _who) return;
        Load();
        _who = who;
        var cfg = new ConfigFile();
        global::ACGodot.SafeConfig.Load(cfg, SavePath);
        ReadSlots(cfg);
        Save();
        Rebuild();
    }

    private void Save()
    {
        if (!_loaded) return;   // never over what's kept before it's been read
        var cfg = new ConfigFile();
        global::ACGodot.SafeConfig.Load(cfg, SavePath);   // (the other characters' stay)
        if (cfg.HasSection(Section)) cfg.EraseSection(Section);
        cfg.SetValue("bar", "tab", _tab);
        cfg.SetValue("bar", "rows", _rows);
        cfg.SetValue("bar", "cols", _cols);
        if (_at is { } a) cfg.SetValue("bar", "at", a);
        for (int t = 0; t < Tabs; t++)
            for (int i = 0; i < MaxSlots; i++)
                if (_slots[t, i] is { } e) cfg.SetValue(Section, $"t{t}s{i}", $"{e.Kind}|{e.Id}|{e.Name.Replace("|", "/")}|{e.Icon}" + (e.Guid != 0 ? $"|g{e.Guid:X}" : ""));
        var err = global::ACGodot.SafeConfig.Save(cfg, SavePath);
        if (err != Error.Ok) GD.PushWarning($"shortcut bar: couldn't keep it ({err})");
    }

    /// <summary>A slot: takes items and spells dropped on it; dragged, it carries its entry.</summary>
    public partial class SlotButton : Button
    {
        public ShortcutBar Bar = null!;
        public int Tab, Slot;

        // hovering: an item's name, how many are carried, its uses left and cooldown, as they are just then
        public override string _GetTooltip(Vector2 at)
        {
            if (Bar.Get(Tab, Slot) is not { } e) return "";
            if (e.Kind == "item" && Combat.ItemSlot.PluginTipShowing) return "";   // (a plugin's pop-up for it showing)
            if (e.Kind != "item" || Bar.ItemOf == null) return e.Name;
            var it = Bar.ItemOf(e);
            return it == null ? $"{e.Name}\n(none on you)" : it.HoverText(Bar.CountOf?.Invoke(e) ?? 0);
        }

        public override GodotObject? _MakeCustomTooltip(string forText) => Combat.ItemSlot.WrappedTip(forText);

        // (an item here hovered: plugins' item pop-ups - MelkTank's - show for it as for one in a pack)
        public override void _Notification(int what)
        {
            if (what == NotificationMouseEnter) Combat.ItemSlot.HoverOther(this, () => Bar.Get(Tab, Slot) is { Kind: "item" } e && Bar.ItemOf != null ? Bar.ItemOf(e) : null);
            else if (what == NotificationMouseExit) Combat.ItemSlot.UnhoverOther(this);
        }

        public override Variant _GetDragData(Vector2 at)
        {
            if (Bar.Get(Tab, Slot) == null) return default;
            DraggingSlot = (Tab, Slot);
            var pic = new TextureRect { Texture = Icon, Size = new Vector2(32, 32), ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize, StretchMode = TextureRect.StretchModeEnum.KeepAspectCentered };
            var holder = new Control(); holder.AddChild(pic); pic.Position = new Vector2(-16, -16);
            holder.ZIndex = 1000; holder.ZAsRelative = false;   // (over everything: some squares sit a layer up)
            SetDragPreview(holder);
            return "acgodot-slot";
        }

        public override bool _CanDropData(Vector2 at, Variant data)
        {
            string s = data.VariantType == Variant.Type.String ? (string)data : "";
            return s == "acgodot-item" || s == "acgodot-spell" || s == "acgodot-slot";
        }

        public override void _DropData(Vector2 at, Variant data)
        {
            string s = (string)data;
            if (s == "acgodot-item" && Combat.ItemSlot.Dragging is { } item)
                Bar.Put(Tab, Slot, new Entry("item", item.Wcid, item.Name, item.Icon, item.Guid), null);
            else if (s == "acgodot-spell" && DraggingSpell is { } sp)
                Bar.Put(Tab, Slot, sp, null);
            else if (s == "acgodot-slot" && DraggingSlot is { } from && Bar.Get(from.tab, from.slot) is { } e)
                Bar.Put(Tab, Slot, e, from);
            Combat.ItemSlot.Dragging = null; DraggingSpell = null; DraggingSlot = null;
        }
    }
}
