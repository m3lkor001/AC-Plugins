using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using Godot;

namespace ACGodot.UI;

/// <summary>
/// Your own colours for the chat's messages, in Options > Chat > Message colors. Messages are sorted into set kinds -
/// Combat (pet damage, your hits, magic hits, damage taken, evades/resists, Nether Fracture, DoTs, kills), Magic
/// (debuffs on you, debuffs you cast, buffs, war casts, DoT casts, dispels, item spells), Channels (each channel, area,
/// tells, NPCs), Plugins and System - each one line with its latest example and one colour for all of it. A message
/// that fits none of them is listed once under "Other messages" (one line per kind), to be sorted later or ignored.
/// </summary>
public static class ChatColors
{
    public sealed class Kind
    {
        public string Key = "";
        public string Section = "";
        public string Name = "";
        public ChatKind Chat;
        public Color Default;
        public bool HasDefault;
        public Color? Mine;
        public string Example = "";
        public bool Ignored;
        public bool Other;
    }

    private const string Cfg = "user://ui.cfg", Sec = "chat_colors2";
    private static readonly Dictionary<string, Kind> _kinds = new();
    private static readonly List<(string key, string section, string name, Func<string, ChatKind, bool> match)> _cats = new();
    private static bool _loaded;
    private static double _dirtyAt = -1;
    public static event Action? Changed;
    public static event Action? Added;

    /// <summary>Set by the network just before an NPC's words (area or tell) go to the chat - NPC chatter / NPC tells.</summary>
    public static bool FromNpc;

    public static readonly string[] Sections = { "Combat", "Magic", "Channels", "Plugins", "System", "Other messages" };

    private static readonly Regex DotRx = new("Corrosion|Corruption|Destructive Curse|Fester|Rot\\b", RegexOptions.IgnoreCase);
    private static readonly Regex WarRx = new("Bolt|Arc\\b|Streak|Blast|Volley|Ring\\b|Wall\\b|Stream|Spines|Spray|Fracture", RegexOptions.IgnoreCase);
    private static readonly Regex DebuffRx = new("Vulnerab|Imperil|Weakness|Clumsiness|Slowness|Bafflement|Feeblemind|Frailty|Yield|Decrepitude|Lethargy|Gossamer|Ineptitude|Drain|Expose", RegexOptions.IgnoreCase);
    private static readonly Regex PointsRx = new("\\d[\\d,]* (points?|damage)\\b", RegexOptions.IgnoreCase);
    private static readonly Regex HealRx = new("\\bheal(s|ed)?\\b", RegexOptions.IgnoreCase);
    private static readonly Regex HealingRx = new("periodic healing|^You (\\w+ )?heal|\\bheals? you\\b|^You (restore|regain)|restores? [\\d,]+ (points of )?health|bandage", RegexOptions.IgnoreCase);
    private static readonly Regex SpreadRx = new("\\bspreads?\\b|\\bspread to\\b", RegexOptions.IgnoreCase);
    // ("Sneak Attack! You ...", "Recklessness! X hits you ...", "Critical hit! ..." - the kind of hit is what follows)
    private static readonly Regex HitPrefixRx = new("^(?:(?:Sneak Attack|Critical hit|Reckless(?:ness)?|Overpower(?:ed)?)[!:]?\\s+)+", RegexOptions.IgnoreCase);
    private static readonly Regex HitTagRx = new("\\s*[\\[(](?:Sneak Attack|Reckless(?:ness)?)[^\\])]*[\\])]", RegexOptions.IgnoreCase);
    private static string Plain(string text) => HitTagRx.Replace(HitPrefixRx.Replace(text.TrimStart(), ""), "");
    private static readonly Regex GivenRx = new("^.+? gives you .+|^You find .+ on the (creature|corpse)", RegexOptions.IgnoreCase);
    private static readonly Regex ResistRx = new("\\bresist(s|ed)?\\b", RegexOptions.IgnoreCase);
    private static readonly Regex EvadeRx = new("\\b(evade[sd]?|resist(s|ed)?)\\b", RegexOptions.IgnoreCase);
    private static readonly Regex OthersCastOnYouRx = new("^(.+?) casts? (.+?) on you", RegexOptions.IgnoreCase);
    private static readonly Regex WorldRx = new("^\\S+(?: \\S+){0,3} has (achieved|killed|defeated|slain|completed|reached|been)\\b|^\\[(Lottery|Announce|World|Server)[^\\]]*\\]", RegexOptions.IgnoreCase);
    private static readonly Regex XpRx = new("^\\[(XP|ATTR)\\]|experience|attribute raised|You are now level|You've banked [\\d,]+ Luminance|skill credit|raised your", RegexOptions.IgnoreCase);
    private static readonly Regex SurgeRx = new("^Surge of |^Aetheria surge|\\bsurges? (on|from|through)\\b", RegexOptions.IgnoreCase);
    private static readonly string[] CastKeys = { "dotcast", "debuffcast", "buffcast", "dispel" };
    private static string? _lastCast;   // the kind of the last spell you cast: its components line goes with it
    private static readonly Regex EnlRx = new("Enlightenment|you have been enlightened|enlighten(ed)? (to|you)", RegexOptions.IgnoreCase);

    private static bool StartsMine(string t) => t.StartsWith("You ") || t.StartsWith("Your ") || t.StartsWith("Critical hit! You");
    private static string? Tag(string t)
    {
        t = t.TrimStart();
        if (!t.StartsWith('[') && !t.StartsWith("<{")) return null;
        int end = t.StartsWith("<{") ? t.IndexOf("}>") : t.IndexOf(']');
        if (end <= 1 || end > 30) return null;
        return t[(t.StartsWith("<{") ? 2 : 1)..end];
    }

    private static void Cat(string key, string section, string name, Func<string, ChatKind, bool> match) => _cats.Add((key, section, name, match));

    static ChatColors()
    {
        // (checked in this order - the first that fits is the message's kind)
        Cat("pet", "Combat", "Pet damage", (t, k) => t.StartsWith("[Pet]"));
        // (periodic healing, healing kits, spells that restore health - before DoT damage: "periodic healing" isn't a DoT)
        Cat("healing", "Combat", "Healing", (t, k) => k is ChatKind.Combat or ChatKind.Magic or ChatKind.Gameplay && Tag(t) == null && HealingRx.IsMatch(t));
        Cat("nf", "Combat", "Nether Fracture hits", (t, k) => k is ChatKind.Combat or ChatKind.Magic && t.Contains("Nether Fracture") && !t.StartsWith("You cast"));
        Cat("dotdmg", "Combat", "DoT damage", (t, k) => (k is ChatKind.Combat or ChatKind.Magic && t.Contains("periodic")) || (t.StartsWith("Your ") && SpreadRx.IsMatch(t)));
        // (spell resists are magic's: a monster resisting yours, and you resisting one - checked before evades)
        Cat("mobresist", "Magic", "Monster resists your spell", (t, k) => k is ChatKind.Combat or ChatKind.Magic && (t.StartsWith("You fail to affect") || (!t.StartsWith("You ") && ResistRx.IsMatch(t))));
        Cat("meresist", "Magic", "You resist a spell", (t, k) => k is ChatKind.Combat or ChatKind.Magic && t.StartsWith("You ") && ResistRx.IsMatch(t));
        Cat("evade", "Combat", "Evades", (t, k) => k is ChatKind.Combat or ChatKind.Magic && EvadeRx.IsMatch(t));
        // (a death message - "X is desiccated by your attack!", "X's last strength withers before you!" - has no points in it)
        Cat("kills", "Combat", "Kills", (t, k) => k == ChatKind.Combat && (t.Contains("[Overkill") || !PointsRx.IsMatch(t)) && !t.StartsWith("You heal"));
        Cat("magictaken", "Combat", "Magic damage received", (t, k) => k is ChatKind.Combat or ChatKind.Magic && PointsRx.IsMatch(t) && !HealRx.IsMatch(t)
                                                                       && (t.StartsWith("You lose ") || (!StartsMine(t) && (t.Contains(" you ") || t.Contains(" your ")) && t.Contains(" with "))));
        Cat("taken", "Combat", "Damage received", (t, k) => k is ChatKind.Combat or ChatKind.Magic && PointsRx.IsMatch(t) && !StartsMine(t) && (t.Contains(" your ") || t.Contains(" you ")));
        Cat("magicdmg", "Combat", "Magic damage dealt", (t, k) => PointsRx.IsMatch(t) && !HealRx.IsMatch(t) && StartsMine(t)
                                                                 && (k == ChatKind.Magic || (k == ChatKind.Combat && (t.Contains(" with ") || t.StartsWith("Your ") || t.StartsWith("Critical hit! Your")))));
        Cat("meleedmg", "Combat", "Melee / missile damage dealt", (t, k) => k == ChatKind.Combat && PointsRx.IsMatch(t));

        Cat("dispel", "Magic", "Dispels", (t, k) => k == ChatKind.Magic && t.Contains("ispel"));
        Cat("debuffme", "Magic", "Vulns / imps / DoTs on you", (t, k) => k == ChatKind.Magic && !t.StartsWith("You cast") && t.Contains(" on you") && (DebuffRx.IsMatch(t) || DotRx.IsMatch(t)));
        Cat("dotcast", "Magic", "DoT casts", (t, k) => k == ChatKind.Magic && t.StartsWith("You cast") && DotRx.IsMatch(t));
        Cat("debuffcast", "Magic", "Vulns / imps on others", (t, k) => k == ChatKind.Magic && t.StartsWith("You cast") && DebuffRx.IsMatch(t));
        Cat("buffcast", "Magic", "Buffs cast", (t, k) => k == ChatKind.Magic && t.StartsWith("You cast"));
        // (and the surges your gear throws off - "Surge of Regeneration wears off")
        Cat("itembuff", "Magic", "Item buffs (spells cast on equip)", (t, k) => (k == ChatKind.Magic && OthersCastOnYouRx.IsMatch(t)) || SurgeRx.IsMatch(t));

        foreach (var (ck, nm) in new[] { (ChatKind.General, "General"), (ChatKind.Trade, "Trade"), (ChatKind.LFG, "LFG"), (ChatKind.Roleplay, "Roleplay"),
                                         (ChatKind.Society, "Society"), (ChatKind.Allegiance, "Allegiance"), (ChatKind.Fellowship, "Fellowship") })
        {
            var c = ck;
            string tag = nm == "Fellowship" ? "Fellow" : nm;
            // (by the channel's own tag too: one said with coordinates in it came in another way and landed in Other)
            Cat("ch:" + nm, "Channels", nm, (t, k) => k == c || (Tag(t) is { } tg && (tg.Equals(nm, StringComparison.OrdinalIgnoreCase) || tg.Equals(tag, StringComparison.OrdinalIgnoreCase))));
        }
        Cat("npcsay", "Channels", "NPC chatter", (t, k) => k == ChatKind.AreaChat && FromNpc);
        Cat("area", "Channels", "Area chat", (t, k) => k == ChatKind.AreaChat);
        Cat("npctell", "Channels", "NPC tells", (t, k) => k == ChatKind.Tells && FromNpc);
        Cat("tells", "Channels", "Tells", (t, k) => k == ChatKind.Tells);

        Cat("melktank", "Plugins", "MelkTank", (t, k) => t.StartsWith("[MelkTank]") || t.StartsWith("MelkTank:"));
        Cat("qb", "Plugins", "Quest tracker", (t, k) => t.StartsWith("<{Melks") || t.StartsWith("[MelksQB]") || t.StartsWith("[QB]"));
        Cat("phone", "Plugins", "Phone", (t, k) => t.StartsWith("[Phone]"));
        Cat("acgplugins", "Plugins", "Plugin loading ([Plugins])", (t, k) => t.StartsWith("[Plugins]"));
        Cat("errors", "Plugins", "Error messages (ours)", (t, k) => k == ChatKind.Errors);

        Cat("network", "System", "Network messages", (t, k) => t.StartsWith("[Network]"));
        Cat("breeding", "System", "Breeding messages", (t, k) => t.StartsWith("[Breeding]"));
        Cat("stamps", "System", "QB stamps", (t, k) => t.StartsWith("You've stamped "));
        Cat("bank", "System", "Bank", (t, k) => t.StartsWith("[BANK]") || t.StartsWith("[Bank]") || t.Contains("Your balances") || t.Contains("to your bank"));
        Cat("given", "System", "Item given", (t, k) => k == ChatKind.Gameplay && Tag(t) == null && GivenRx.IsMatch(t));
        // (anyone's enlightenment - "Krom has achieved the 109th level of Enlightenment!" - before world status)
        Cat("enl", "System", "Enlightenment messages", (t, k) => EnlRx.IsMatch(t));
        Cat("world", "System", "World status messages", (t, k) => k == ChatKind.Gameplay && WorldRx.IsMatch(t));
        Cat("xp", "System", "Attribute / XP messages", (t, k) => XpRx.IsMatch(t));
        Cat("server", "System", "Server messages", (t, k) => k == ChatKind.Gameplay && (Tag(t) != null || t.StartsWith("Welcome to Asheron's Call")));
        Cat("general", "System", "General", (t, k) => k == ChatKind.Gameplay && Tag(t) == null && !t.Contains(" gives you "));
    }

    /// <summary>The set kinds (in their order), then the other messages seen (not the ignored ones).</summary>
    public static IReadOnlyList<Kind> All
    {
        get
        {
            Load();
            var l = new List<Kind>();
            // (listed by section - a kind checked early, like the spell resists, still shows under its own section)
            foreach (var c in _cats.OrderBy(c => Array.IndexOf(Sections, c.section))) l.Add(Get(c.key, c.section, c.name));
            l.AddRange(_kinds.Values.Where(k => k.Other && !k.Ignored).OrderBy(k => k.Chat).ThenBy(k => k.Example));
            return l;
        }
    }

    public static int IgnoredCount { get { Load(); return _kinds.Values.Count(k => k.Other && k.Ignored); } }

    private static Kind Get(string key, string section, string name)
    {
        if (!_kinds.TryGetValue(key, out var k)) _kinds[key] = k = new Kind { Key = key };
        k.Section = section; k.Name = name;
        return k;
    }

    // (an uncategorised message: one line per tag, else per chat kind and colour)
    private static string OtherKey(ChatKind chat, Color c, string text) => Tag(text) is { } tag ? $"other:{chat}#tag:{tag}" : $"other:{chat}#{c.ToHtml(false)}";

    /// <summary>The colour a message is shown in: yours for its kind if you've set one; else the kind's own (the colour
    /// its first message came in - so a kind is one colour, whatever its messages come in); for an other message, the game's.</summary>
    public static Color For(string text, Color color, ChatKind chat)
    {
        Load();
        string t = Plain(text);
        // "The spell consumed the following components" - with whichever casting it came after
        bool parts = t.StartsWith("The spell consumed", StringComparison.OrdinalIgnoreCase);
        foreach (var c in _cats)
        {
            bool hit;
            if (parts && _lastCast != null) hit = c.key == _lastCast;
            else try { hit = c.match(t, chat); } catch { hit = false; }
            if (!hit) continue;
            if (Array.IndexOf(CastKeys, c.key) >= 0) _lastCast = c.key;
            var k = Get(c.key, c.section, c.name);
            k.Chat = chat;
            bool fresh = !k.HasDefault;
            if (fresh) { k.Default = color; k.HasDefault = true; }
            string ex = Shorten(text);
            if (k.Example != ex) { k.Example = ex; MarkDirty(slow: true); }
            if (fresh) Added?.Invoke();
            return k.Mine ?? k.Default;
        }
        string key = OtherKey(chat, color, text);
        if (!_kinds.TryGetValue(key, out var o))
        {
            if (_kinds.Count >= 400) return color;
            _kinds[key] = o = new Kind { Key = key, Other = true, Section = "Other messages", Name = chat.ToString(), Chat = chat, Default = color, HasDefault = true, Example = Shorten(text) };
            MarkDirty();
            Added?.Invoke();
        }
        return o.Mine ?? color;
    }

    private static string Shorten(string s)
    {
        s = s.Replace('\n', ' ').Replace('|', '/').Trim();
        return s.Length > 60 ? s[..57] + "..." : s;
    }

    public static void Set(Kind k, Color? c) { k.Mine = c; Save(); Changed?.Invoke(); }
    public static void Ignore(Kind k) { k.Ignored = true; Save(); Changed?.Invoke(); }
    public static void UnignoreAll() { foreach (var k in _kinds.Values) k.Ignored = false; Save(); Changed?.Invoke(); }
    /// <summary>Your colours (and ignored other messages), as text for the shared chat settings file.</summary>
    public static string ExportText()
    {
        Load();
        var lines = new List<string>();
        foreach (var k in _kinds.Values)
            if (k.Mine != null || k.Ignored)
                lines.Add(k.Key + "|" + (k.Mine?.ToHtml(false) ?? "") + "|" + (k.Ignored ? "1" : "0") + "|" + k.Chat + "|" + k.Example);
        return string.Join("\n", lines);
    }

    /// <summary>Colours from the shared chat settings file (yours are replaced by them).</summary>
    public static int ImportText(string text)
    {
        Load();
        foreach (var k in _kinds.Values) { k.Mine = null; k.Ignored = false; }
        int n = 0;
        foreach (var line in text.Split('\n'))
        {
            var v = line.Split('|', 5);
            if (v.Length < 3 || v[0].Length == 0) continue;
            if (!_kinds.TryGetValue(v[0], out var k))
            {
                bool other = v[0].StartsWith("other:");
                k = new Kind { Key = v[0], Other = other, Section = other ? "Other messages" : "", Example = v.Length > 4 ? v[4] : "" };
                if (v.Length > 3 && Enum.TryParse<ChatKind>(v[3], out var ck)) { k.Chat = ck; if (other) { k.Name = ck.ToString(); k.HasDefault = false; } }
                _kinds[v[0]] = k;
            }
            k.Mine = v[1].Length > 0 && Color.HtmlIsValid(v[1]) ? Color.FromHtml(v[1]) : null;
            k.Ignored = v[2] == "1";
            n++;
        }
        Save();
        Changed?.Invoke();
        return n;
    }

    public static void ResetAll() { foreach (var k in _kinds.Values) k.Mine = null; Save(); Changed?.Invoke(); }

    // (only the example line changing - every combat message does that - waits 5 minutes: ui.cfg isn't written
    // every few seconds by every client sharing it)
    private static bool _slowOnly;
    private static void MarkDirty(bool slow = false)
    {
        if (_dirtyAt < 0) { _dirtyAt = Time.GetTicksMsec() / 1000.0; _slowOnly = slow; }
        else if (!slow) _slowOnly = false;
    }

    /// <summary>Changes written out now and then, not on every message.</summary>
    public static void Tick()
    {
        if (_dirtyAt >= 0 && Time.GetTicksMsec() / 1000.0 - _dirtyAt > (_slowOnly ? 300 : 10)) Save();
    }

    private static void Load()
    {
        if (_loaded) return;
        _loaded = true;
        var cfg = new ConfigFile();
        if (global::ACGodot.SafeConfig.Load(cfg, Cfg) != Error.Ok || !cfg.HasSection(Sec)) return;
        // (once: the other messages collected so far were sorted into the kinds above (Nov 21) - cleared, to start fresh)
        bool clearOthers = !cfg.HasSectionKey("chat_colors_meta", "others_cleared_1121b");
        if (clearOthers) { cfg.SetValue("chat_colors_meta", "others_cleared_1121b", true); global::ACGodot.SafeConfig.Save(cfg, Cfg); _dirtyAt = 0; }
        foreach (var key in cfg.GetSectionKeys(Sec))
        {
            if (clearOthers && key.StartsWith("other:")) continue;
            // key = "mine|default|example|chat|ignored"
            var v = ((string)cfg.GetValue(Sec, key)).Split('|');
            if (v.Length < 5) continue;
            var k = new Kind { Key = key, Other = key.StartsWith("other:"), Example = v[2], Ignored = v[4] == "1" };
            if (v[0].Length > 0 && Color.HtmlIsValid(v[0])) k.Mine = Color.FromHtml(v[0]);
            if (v[1].Length > 0 && Color.HtmlIsValid(v[1])) { k.Default = Color.FromHtml(v[1]); k.HasDefault = true; }
            if (Enum.TryParse<ChatKind>(v[3], out var ck)) k.Chat = ck;
            if (k.Other) { k.Section = "Other messages"; k.Name = k.Chat.ToString(); }
            _kinds[key] = k;
        }
        // (an other message that one of the kinds now takes - sorted in since it was listed - is dropped from the list)
        foreach (var o in _kinds.Values.Where(k => k.Other).ToList())
        {
            bool taken = false;
            foreach (var c in _cats) { try { if (c.match(Plain(o.Example), o.Chat)) { taken = true; break; } } catch { } }
            if (taken) { _kinds.Remove(o.Key); _dirtyAt = 0; }
        }
    }

    private static void Save()
    {
        _dirtyAt = -1;
        try
        {
            var cfg = new ConfigFile();
            global::ACGodot.SafeConfig.Load(cfg, Cfg);
            if (cfg.HasSection(Sec)) cfg.EraseSection(Sec);
            foreach (var k in _kinds.Values)
                cfg.SetValue(Sec, k.Key, (k.Mine?.ToHtml(false) ?? "") + "|" + (k.HasDefault ? k.Default.ToHtml(false) : "") + "|" + k.Example + "|" + k.Chat + "|" + (k.Ignored ? "1" : "0"));
            global::ACGodot.SafeConfig.Save(cfg, Cfg);
        }
        catch { }
    }
}
