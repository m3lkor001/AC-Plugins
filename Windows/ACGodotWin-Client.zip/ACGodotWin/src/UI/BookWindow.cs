using System;
using System.Collections.Generic;
using Godot;

namespace ACGodot.UI;

/// <summary>A book or parchment being read: one page at a time, turned with Previous and Next.</summary>
public partial class BookWindow : Combat.GameWindow
{
    private uint _book;
    private int _pages, _page;
    private readonly Dictionary<int, string> _text = new();
    private Label _words = null!, _at = null!;
    private Button _prev = null!, _next = null!;

    public BookWindow() : base("Book", new Vector2(460, 420))
    {
        _words = Text("", 13);
        _words.CustomMinimumSize = new Vector2(420, 0);
        Body.AddChild(_words);
        var row = new HBoxContainer { Alignment = BoxContainer.AlignmentMode.Center };
        row.AddThemeConstantOverride("separation", 16);
        _prev = Small("< Previous", () => Turn(-1));
        _at = Text("", 12, RetailTheme.Gold);
        _next = Small("Next >", () => Turn(1));
        // (the page count on one line, and the buttons their own size - not stretched to the window's height)
        _at.AutowrapMode = TextServer.AutowrapMode.Off;
        _at.CustomMinimumSize = new Vector2(110, 0);
        _at.HorizontalAlignment = HorizontalAlignment.Center;
        _at.SizeFlagsVertical = SizeFlags.ShrinkCenter;
        foreach (var b in new[] { _prev, _next }) { b.CustomMinimumSize = new Vector2(100, 26); b.SizeFlagsVertical = SizeFlags.ShrinkCenter; }
        row.SizeFlagsVertical = SizeFlags.ShrinkEnd;
        row.AddChild(_prev); row.AddChild(_at); row.AddChild(_next);
        // the page turns sit under the scrolling words, always in reach
        GetChild(0).AddChild(row);
        // a grip in the bottom-right corner sizes it - more of a page seen at once - kept for next time
        var grip = new Control { CustomMinimumSize = new Vector2(14, 14), MouseDefaultCursorShape = CursorShape.Fdiagsize, MouseFilter = MouseFilterEnum.Stop,
                                 SizeFlagsHorizontal = SizeFlags.ShrinkEnd, SizeFlagsVertical = SizeFlags.ShrinkEnd };
        grip.Draw += () => { var c = new Color(0.8f, 0.65f, 0.3f, 0.9f); for (int i = 0; i < 3; i++) grip.DrawLine(new Vector2(13, 3 + i * 4), new Vector2(3 + i * 4, 13), c, 1f); };
        bool down = false; Vector2 from = Vector2.Zero, start = Vector2.Zero;
        grip.GuiInput += e =>
        {
            if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb)
            {
                down = mb.Pressed; from = GetGlobalMousePosition(); start = Size;
                if (!mb.Pressed) { var c = new ConfigFile(); global::ACGodot.SafeConfig.Load(c, "user://ui.cfg"); c.SetValue("windows", "size_BookWindow", Size); global::ACGodot.SafeConfig.Save(c, "user://ui.cfg"); }
                grip.AcceptEvent();
            }
            else if (e is InputEventMouseMotion && down)
            {
                var screen = GetViewportRect().Size;
                var want = start + GetGlobalMousePosition() - from;
                Size = new Vector2(Math.Clamp(want.X, Least.X, Math.Max(Least.X, screen.X - Position.X)), Math.Clamp(want.Y, Least.Y, Math.Max(Least.Y, screen.Y - Position.Y)));
                grip.AcceptEvent();
            }
        };
        AddChild(grip);
        // (the words wrap to the window's width)
        Resized += () => _words.CustomMinimumSize = new Vector2(Math.Max(420f, Size.X - 40f), 0);
    }

    private static readonly Vector2 Least = new(460, 420);

    public override void _Ready()
    {
        base._Ready();
        var c = new ConfigFile();
        if (global::ACGodot.SafeConfig.Load(c, "user://ui.cfg") == Error.Ok && c.HasSectionKey("windows", "size_BookWindow"))
        {
            var sz = (Vector2)c.GetValue("windows", "size_BookWindow");
            Size = new Vector2(Math.Max(Least.X, sz.X), Math.Max(Least.Y, sz.Y));
        }
    }

    /// <summary>A book the server has opened (pages: how many it has).</summary>
    public void Open(uint book, string name, int pages)
    {
        _book = book; _pages = Math.Max(0, pages); _page = 0;
        _text.Clear();
        Title = string.IsNullOrEmpty(name) ? "Book" : name;
        Visible = true;
        MoveToFront();
        if (!Placed) Position = ((GetViewportRect().Size - Size) * 0.5f).Max(Vector2.Zero);
        Show();
    }

    /// <summary>One of its pages' words (they come one by one).</summary>
    public void Page(uint book, int page, int pages, string text)
    {
        if (book != _book) return;
        if (pages > 0) _pages = Math.Max(_pages, pages);
        _pages = Math.Max(_pages, page + 1);
        _text[page] = text ?? "";
        if (page == _page) Show();
        else UpdateTurns();
    }

    public uint BookId => Visible ? _book : 0;

    private void Turn(int by)
    {
        int to = Math.Clamp(_page + by, 0, Math.Max(0, _pages - 1));
        if (to == _page) return;
        _page = to;
        Show();
    }

    private new void Show()
    {
        _words.Text = _pages == 0 ? "(It's blank.)" : _text.TryGetValue(_page, out var t) ? (t.Length > 0 ? t : "(This page is blank.)") : "...";
        Scroll.ScrollVertical = 0;
        UpdateTurns();
    }

    private void UpdateTurns()
    {
        _at.Text = _pages == 0 ? "" : $"Page {_page + 1} of {_pages}";
        _prev.Disabled = _page <= 0;
        _next.Disabled = _page >= _pages - 1;
    }
}
