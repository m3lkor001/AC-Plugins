using System;
using System.Collections.Generic;
using ACGodot.Objects;
using AcDream.Core.Meshing;
using AcDream.Core.Physics;
using AcDream.Core.Vfx;
using DatReaderWriter.DBObjs;
using Godot;
using NMatrix = System.Numerics.Matrix4x4;
using NVector3 = System.Numerics.Vector3;

namespace ACGodot.Effects;

/// <summary>
/// Particle effects - auras, fog, fires, sparkles, weather - run by OpenAC's ports of the client's particle code:
/// a thing's PhysicsScript (its Setup's default script, or a sky layer's) and the particle hooks in its animations
/// create emitters; the particle system moves their particles. Here each emitter's live particles are drawn as
/// one MultiMesh of the emitter's model (usually a small textured card turned to face the camera), tinted and
/// faded per particle.
///
/// Positions are AC world coordinates (landblock x * 192 + local x, ...). Main thread only.
/// </summary>
public partial class ParticleWorld : Node3D, IEntityEffectPoseSource, IEntityEffectPoseChangeSource
{
    private const float DrawRange = 150f;   // emitters further than this from the camera aren't drawn

    private Dats _dats = null!;
    private ObjectAssets _assets = null!;
    private ParticleSystem _system = null!;
    private ParticleHookSink _sink = null!;
    private PhysicsScriptRunner _runner = null!;
    private readonly Dictionary<uint, (NMatrix root, NMatrix[] parts)> _owners = new();
    private uint _nextId = 1;
    private readonly Dictionary<int, MultiMeshInstance3D> _drawn = new();
    private readonly Dictionary<(uint gfx, bool add), ArrayMesh?> _meshes = new();
    private readonly Shader _mix = GD.Load<Shader>("res://shaders/particle_mix.gdshader");
    private readonly Shader _add = GD.Load<Shader>("res://shaders/particle_add.gdshader");

    public event Action<uint>? EffectPoseChanged;

    // effects of things inside rooms: drawn only while the camera is indoors too. The client only draws a building's
    // rooms (and what's in them) when they're in view through its openings; a glow there would otherwise show through
    // the walls from outside
    private readonly HashSet<uint> _indoors = new();
    /// <summary>Whether the camera is inside (a building's rooms or a dungeon); set each frame.</summary>
    public bool CameraIndoors { get; set; }

    /// <summary>What the particle system said it couldn't do (an emitter not made, and why).</summary>
    public readonly List<string> Diagnostics = new();
    /// <summary>Every emitter there is, and how it stands (for working out why one doesn't show).</summary>
    public IEnumerable<string> Report(Vector3 near)
    {
        var (nx, ny, nz) = World.ToAc(near);
        var at = new NVector3(nx, ny, nz);
        foreach (AcDream.Core.Vfx.ParticleEmitter em in _system.EnumerateEmitters())
        {
            float d = NVector3.Distance(em.AnchorPos, at);
            if (d > 40f) continue;
            int alive = 0; foreach (var p in em.Particles) if (p.Alive) alive++;
            yield return $"{d:0.0} m gfx {em.Desc.GfxObjId:X8}/{em.Desc.HwGfxObjId:X8} {em.Desc.EmitterKind} rate {em.Desc.Birthrate:0.###} max {em.Desc.MaxParticles} alive {alive} emitted {em.TotalEmitted} active {em.ActiveCount}" +
                         $"{(em.Finished ? " finished" : "")}{(em.PresentationVisible ? "" : " not-visible")}{(em.SimulationEnabled ? "" : " sim-off")}{(em.ViewEligible ? "" : " not-eligible")}{(em.DegradedOut ? " degraded-out" : "")}" +
                         $" owner {em.AttachedObjectId} part {em.AttachedPartIndex} anchor {em.AnchorPos.X:0.0},{em.AnchorPos.Y:0.0},{em.AnchorPos.Z:0.0} last {em.LastEmitOffset.X:0.0},{em.LastEmitOffset.Y:0.0},{em.LastEmitOffset.Z:0.0}";
        }
    }
    public int Particles => _system?.ActiveParticleCount ?? 0;

    /// <summary>Where effects' sounds are played.</summary>
    public ACGodot.Audio.WorldAudio? Audio;
    private readonly Dictionary<uint, uint> _soundTables = new();   // (an effect owner's sound table, for its sounds named by kind)

    private void Sound(uint id, NVector3 at, DatReaderWriter.Types.AnimationHook hook)
    {
        if (Audio == null) return;
        if (_owners.TryGetValue(id, out var o)) at = o.root.Translation;
        _soundTables.TryGetValue(id, out uint table);
        // (what became of each effect sound, for the test bridge's "particles")
        string what = hook switch
        {
            DatReaderWriter.Types.SoundHook sh => $"wave 0x{(uint)sh.Id:X8}",
            DatReaderWriter.Types.SoundTableHook st => $"{st.SoundType} from table 0x{table:X8}",
            DatReaderWriter.Types.SoundTweakedHook tw => $"tweaked 0x{(uint)tw.SoundId:X8}",
            _ => hook.GetType().Name,
        };
        Diagnostics.Add($"{Time.GetTicksMsec() / 1000.0:0.0} sound {what} (owner {id})"); if (Diagnostics.Count > 20) Diagnostics.RemoveAt(0);
        try { Audio.Hooks(table, World.ToGodot(at), new[] { hook }); }
        catch (Exception ex) { GD.PushWarning($"effect sound: {ex.Message}"); }
    }

    private sealed class SoundingSink : IAnimationHookSink
    {
        private readonly ParticleHookSink _particles;
        private readonly ParticleWorld _world;
        public SoundingSink(ParticleHookSink particles, ParticleWorld world) { _particles = particles; _world = world; }
        public void OnHook(uint entityId, NVector3 entityWorldPosition, DatReaderWriter.Types.AnimationHook hook)
        {
            if (hook is DatReaderWriter.Types.SoundHook or DatReaderWriter.Types.SoundTableHook or DatReaderWriter.Types.SoundTweakedHook)
                _world.Sound(entityId, entityWorldPosition, hook);
            else _particles.OnHook(entityId, entityWorldPosition, hook);
        }
    }
    public int Emitters => _system?.ActiveEmitterCount ?? 0;
    /// <summary>How many effects are being drawn (each its own instance on screen).</summary>
    public int Drawn => _drawn.Count;

    public void Setup(Dats dats, ObjectAssets assets)
    {
        _dats = dats; _assets = assets;
        _system = new ParticleSystem(new EmitterDescRegistry(dats));
        _sink = new ParticleHookSink(_system, this);
        _sink.DiagnosticSink = s => { Diagnostics.Add($"{Time.GetTicksMsec() / 1000.0:0.0} {s}"); if (Diagnostics.Count > 20) Diagnostics.RemoveAt(0); };
        // (an effect's script plays sounds too - a spell's launch and impact, a netherfracture's - which the particle code
        // passed over: its sound hooks go to the world's sounds here; the rest to the particles)
        _runner = new PhysicsScriptRunner(id => SafeScript(id), new SoundingSink(_sink, this));
        _runner.DiagnosticSink = s => { Diagnostics.Add($"{Time.GetTicksMsec() / 1000.0:0.0} runner: {s}"); if (Diagnostics.Count > 20) Diagnostics.RemoveAt(0); };
    }

    private DatReaderWriter.DBObjs.PhysicsScript? SafeScript(uint id)
    {
        try { return _dats.Get<DatReaderWriter.DBObjs.PhysicsScript>(id); } catch { return null; }
    }

    /// <summary>
    /// Something that can have effects: where it is (AC world, as a matrix) and its parts' places in it (for effects
    /// on a hand or head). Plays its Setup's default script, if any. Returns its id for <see cref="Hooks"/> etc.
    /// </summary>
    public uint Add(NMatrix root, Setup? setup, DatReaderWriter.Types.AnimationFrame? pose = null, uint script = 0, bool indoors = false, uint soundTable = 0)
    {
        uint id = _nextId++;
        if (soundTable == 0 && setup != null) soundTable = (uint)setup.DefaultSoundTable;
        if (soundTable != 0) _soundTables[id] = soundTable;
        if (indoors) _indoors.Add(id);
        NMatrix[] parts = Array.Empty<NMatrix>();
        if (setup != null)
        {
            var flat = SetupMesh.Flatten(setup, pose);
            parts = new NMatrix[flat.Count];
            for (int i = 0; i < flat.Count; i++) parts[i] = flat[i].PartTransform;
            if (script == 0) script = (uint)setup.DefaultScript;
        }
        _owners[id] = (root, parts);
        if (script != 0)
        {
            try { _runner.Play(script, id, root.Translation); }
            catch (Exception ex) { GD.PushWarning($"effect script 0x{script:X8}: {ex.Message}"); }
        }
        return id;
    }

    /// <summary>
    /// The script for one of a body's named effects (as a server gives them: the body's effects table, which effect,
    /// how strong): the strongest version that strength reaches. 0 if there's none.
    /// </summary>
    public uint ScriptFrom(uint table, uint effect, float strength)
    {
        if (table == 0 || effect == 0) return 0;
        try
        {
            var t = _dats.Get<PhysicsScriptTable>(table);
            if (t == null || !t.ScriptTable.TryGetValue((DatReaderWriter.Enums.PlayScript)effect, out var d) || d.Scripts.Count == 0) return 0;
            uint script = (uint)d.Scripts[0].ScriptId;
            foreach (var sm in d.Scripts) if (sm.Mod <= strength + 1e-4f) script = (uint)sm.ScriptId;
            return script;
        }
        catch { return 0; }
    }

    /// <summary>Whether a Setup has effects of its own (a default script).</summary>
    public static bool HasScript(Setup? setup) => setup != null && (uint)setup.DefaultScript != 0;

    /// <summary>Animation hooks from a thing's motion (particles made and stopped as it moves).</summary>
    public void Hooks(uint id, IReadOnlyList<DatReaderWriter.Types.AnimationHook> hooks)
    {
        if (hooks.Count == 0 || !_owners.TryGetValue(id, out var o)) return;
        foreach (var h in hooks)
        {
            try { _sink.OnHook(id, o.root.Translation, h); }
            catch (Exception ex) { GD.PushWarning($"effect hook: {ex.Message}"); }
        }
    }

    /// <summary>Moves a thing (its effects follow).</summary>
    public void Move(uint id, NMatrix root)
    {
        if (!_owners.TryGetValue(id, out var o)) return;
        _owners[id] = (root, o.parts);
        _runner.SetOwnerAnchor(id, root.Translation);
        EffectPoseChanged?.Invoke(id);
    }

    /// <summary>A thing's parts as its motion has them now (effects on a hand go where the hand is).</summary>
    public void SetParts(uint id, IReadOnlyList<PartTransform> pose)
    {
        if (!_owners.TryGetValue(id, out var o) || o.parts.Length == 0) return;
        int n = Math.Min(o.parts.Length, pose.Count);
        for (int i = 0; i < n; i++)
            o.parts[i] = NMatrix.CreateFromQuaternion(pose[i].Orientation) * NMatrix.CreateTranslation(pose[i].Origin);
        EffectPoseChanged?.Invoke(id);
    }

    /// <summary>Ends a thing's effects (it's gone).</summary>
    public void Remove(uint id)
    {
        _indoors.Remove(id);
        _soundTables.Remove(id);
        if (!_owners.Remove(id)) return;
        try { _sink.StopAllForEntity(id, false); _runner.StopAllForEntity(id); }
        catch (Exception ex) { GD.PushWarning($"effect stop: {ex.Message}"); }
    }

    public bool TryGetRootPose(uint id, out NMatrix rootWorld)
    {
        if (_owners.TryGetValue(id, out var o)) { rootWorld = o.root; return true; }
        rootWorld = NMatrix.Identity; return false;
    }

    public bool TryGetPartPose(uint id, int part, out NMatrix partLocal)
    {
        partLocal = NMatrix.Identity;
        if (!_owners.TryGetValue(id, out var o)) return false;
        if (part >= 0 && part < o.parts.Length) { partLocal = o.parts[part]; return true; }
        // something without parts (a sky layer's rain): its effects sit at its own place
        return o.parts.Length == 0 || part < 0;
    }

    public void Step(double delta, Vector3 camera)
    {
        if (_system == null) return;
        float dt = (float)Math.Min(delta, 0.1);
        try
        {
            _runner.Tick(dt);
            _sink.RefreshAttachedEmitters();
            _system.Tick(dt);
        }
        catch (Exception ex) { GD.PushWarning("particles: " + ex.Message); }
        Draw(camera);
    }

    /// <summary>Where the ID panel's figure stands (null: none shown) - the effects on it are drawn in its picture too
    /// (its camera sees this layer).</summary>
    public static Vector3? FigureAt;
    public const uint FigureLayer = 1u << 18;

    private void Draw(Vector3 camera)
    {
        var (cx, cy, cz) = World.ToAc(camera);
        var cam = new NVector3(cx, cy, cz);
        NVector3? fig = null;
        if (FigureAt is { } fa) { var (fx, fy, fz) = World.ToAc(fa); fig = new NVector3(fx, fy, fz); }
        var alive = new HashSet<int>();
        foreach (AcDream.Core.Vfx.ParticleEmitter em in _system.EnumerateEmitters())
        {
            if (!em.PresentationVisible || NVector3.Distance(em.OwnerPosition, cam) > DrawRange) continue;
            if (!CameraIndoors && _indoors.Contains(em.AttachedObjectId)) continue;
            uint gfx = em.Desc.HwGfxObjId != 0 ? em.Desc.HwGfxObjId : em.Desc.GfxObjId;
            if (gfx == 0) continue;
            bool add = (em.Desc.Flags & EmitterFlags.Additive) != 0;
            ArrayMesh? mesh = MeshFor(gfx, add);
            if (mesh == null) continue;
            uint facing = FacingOf(gfx);
            int count = 0;
            foreach (var p in em.Particles) if (p.Alive) count++;
            if (count == 0) continue;
            alive.Add(em.Handle);
            if (!_drawn.TryGetValue(em.Handle, out var mmi))
            {
                mmi = new MultiMeshInstance3D
                {
                    Multimesh = new MultiMesh { TransformFormat = MultiMesh.TransformFormatEnum.Transform3D, UseColors = true, Mesh = mesh },
                    CastShadow = GeometryInstance3D.ShadowCastingSetting.Off,
                    ExtraCullMargin = 50f,
                };
                AddChild(mmi);
                _drawn[em.Handle] = mmi;
            }
            // (on the figure in the ID panel - your umbra's smoke, a spell on them: in its picture as well)
            bool onFigure = fig is { } f0 && MathF.Abs(em.OwnerPosition.Z - f0.Z) < 4f && new System.Numerics.Vector2(em.OwnerPosition.X - f0.X, em.OwnerPosition.Y - f0.Y).Length() < 2.5f;
            uint layers = onFigure ? 1u | FigureLayer : 1u;
            if (mmi.Layers != layers) mmi.Layers = layers;
            var mm = mmi.Multimesh;
            if (mm.InstanceCount < count) mm.InstanceCount = Math.Max(count, em.Particles.Length);
            int i = 0;
            foreach (var p in em.Particles)
            {
                if (!p.Alive) continue;
                mm.SetInstanceTransform(i, Place(p, facing, cam));
                uint c = p.ColorArgb;
                mm.SetInstanceColor(i, new Color(((c >> 16) & 0xFF) / 255f, ((c >> 8) & 0xFF) / 255f, (c & 0xFF) / 255f, ((c >> 24) & 0xFF) / 255f));
                i++;
            }
            mm.VisibleInstanceCount = i;
        }
        // emitters gone or out of range
        var gone = new List<int>();
        foreach (var kv in _drawn) if (!alive.Contains(kv.Key)) gone.Add(kv.Key);
        foreach (int h in gone) { _drawn[h].QueueFree(); _drawn.Remove(h); }
    }

    /// <summary>
    /// How a particle model turns, as the client does it (its close degrade's mode): 2 faces the viewer, staying
    /// upright; 3 / 4 / 5 spin about their own X / Y / Z to face the viewer as far as that allows; anything else
    /// keeps the particle's own orientation (ground glows lie flat).
    /// </summary>
    private uint FacingOf(uint gfx)
    {
        if (_facing.TryGetValue(gfx, out uint f)) return f;
        f = 0;
        try
        {
            var g = _dats.Get<GfxObj>(gfx);
            if (g != null && g.Flags.HasFlag(DatReaderWriter.Enums.GfxObjFlags.HasDIDDegrade) && g.DIDDegrade != 0
                && _dats.Get<GfxObjDegradeInfo>(g.DIDDegrade) is { } d && d.Degrades.Count > 0)
                f = (uint)d.Degrades[0].DegradeMode;
        }
        catch { f = 0; }
        _facing[gfx] = f;
        return f;
    }
    private readonly Dictionary<uint, uint> _facing = new();

    /// <summary>
    /// Where a particle's model goes (AC world -> Godot). Particle cards lie in their model's X-Z plane, seen
    /// from -Y (as the client's camera looks along +Y).
    /// </summary>
    private static Transform3D Place(in Particle p, uint facing, NVector3 cam)
    {
        float s = Math.Max(p.Size, 0.001f);
        var rot = p.SpawnRotation;
        NVector3 x, y, z;
        NVector3 toCam = cam - p.Position;
        float dist = toCam.Length();
        if (dist < 1e-4f || !RetailParticleFacing.Faces(facing))
        {
            x = NVector3.Transform(NVector3.UnitX, rot); y = NVector3.Transform(NVector3.UnitY, rot); z = NVector3.Transform(NVector3.UnitZ, rot);
        }
        else
        {
            NVector3 view = -toCam / dist;   // from the viewer to the particle
            if (facing == 2)
            {
                x = NVector3.Cross(view, NVector3.UnitZ);
                if (x.LengthSquared() < 1e-8f) x = NVector3.UnitX; else x = NVector3.Normalize(x);
                z = NVector3.Cross(x, view);
            }
            else
            {
                (x, z) = RetailParticleFacing.OrientQuad(facing, rot, NVector3.UnitX, NVector3.UnitZ, toCam / dist, NVector3.UnitX, NVector3.UnitZ);
                x = NVector3.Normalize(x); z = NVector3.Normalize(z);
            }
            y = NVector3.Cross(z, x);
            if (p.Rotation != 0f)
            {
                // the particle's spin, in the card's plane
                var spin = System.Numerics.Quaternion.CreateFromAxisAngle(y, p.Rotation);
                x = NVector3.Transform(x, spin); z = NVector3.Transform(z, spin);
            }
        }
        var m = new NMatrix(x.X * s, x.Y * s, x.Z * s, 0, y.X * s, y.Y * s, y.Z * s, 0, z.X * s, z.Y * s, z.Z * s, 0,
                            p.Position.X, p.Position.Y, p.Position.Z, 1);
        return ObjectAssets.Xf(m);
    }

    /// <summary>
    /// A particle model with the particle materials (tinted per instance). Turned per particle by <see cref="Place"/>.
    /// </summary>
    private ArrayMesh? MeshFor(uint gfx, bool add)
    {
        if (_meshes.TryGetValue((gfx, add), out var m)) return m;
        m = null;
        try
        {
            _assets.Prepare(gfx);
            if (_assets.GetPrepared(gfx) is { } p && p.Subs.Count > 0)
            {
                m = new ArrayMesh();
                foreach (var sub in p.Subs)
                {
                    var pos = new Vector3[sub.pos.Length];
                    for (int i = 0; i < pos.Length; i++) pos[i] = sub.pos[i];
                    var arrays = new Godot.Collections.Array();
                    arrays.Resize((int)Mesh.ArrayType.Max);
                    arrays[(int)Mesh.ArrayType.Vertex] = pos;
                    arrays[(int)Mesh.ArrayType.TexUV] = sub.uv;
                    arrays[(int)Mesh.ArrayType.Index] = sub.idx;
                    m.AddSurfaceFromArrays(Mesh.PrimitiveType.Triangles, arrays);
                    bool additive = add || sub.kind == TranslucencyKind.Additive;
                    var mat = new ShaderMaterial { Shader = additive ? _add : _mix, RenderPriority = 20 };
                    mat.SetShaderParameter("tex", _assets.ParticleTexture(sub.surfaceId));
                    m.SurfaceSetMaterial(m.GetSurfaceCount() - 1, mat);
                }
            }
        }
        catch (Exception ex) { GD.PushWarning($"particle model 0x{gfx:X8}: {ex.Message}"); m = null; }
        _meshes[(gfx, add)] = m;
        return m;
    }
}
