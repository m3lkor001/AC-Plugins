using System;
using System.Collections.Generic;

namespace ACGodot.Combat;

/// <summary>
/// The game's combat sums, as ACE has them (ACE.Server: SkillCheck, SkillFormula, DamageEvent, Strings): the chance
/// to hit from attack against defense, the strength bonus to damage, armor, and the words for hits and deaths.
/// </summary>
public static class Rules
{
    public static readonly Random Rng = new();

    /// <summary>The chance a skill beats a difficulty (attack skill against defense): 50% when equal.</summary>
    public static double SkillChance(int skill, int difficulty, float factor = 0.03f)
    {
        double chance = 1.0 - 1.0 / (1.0 + Math.Exp(factor * (skill - difficulty)));
        return Math.Clamp(chance, 0.0, 1.0);
    }

    /// <summary>The damage bonus from strength (coordination for bows): 1 up to 55, then 1.1% a point.</summary>
    public static float AttributeMod(int attribute, bool bow = false) => Math.Max(1f + (attribute - 55) * (bow ? 0.008f : 0.011f), 1f);

    /// <summary>How much damage gets through armor of a level (200/3 armor halves it).</summary>
    public static float ArmorMod(float armor)
    {
        const float A = 200f / 3f;
        if (armor > 0) return A / (armor + A);
        if (armor < 0) return 1f - armor / A;
        return 1f;
    }

    /// <summary>A roll of damage between its least (the most less the variance) and its most.</summary>
    public static float RollDamage(float max, float variance) => max * (1f - variance * (float)Rng.NextDouble());

    // damage types (ACE DamageType flags)
    public const int Slash = 1, Pierce = 2, Bludgeon = 4, Cold = 8, Fire = 16, Acid = 32, Electric = 64, Nether = 1024;

    /// <summary>The first damage type in a set of them (a body part's can hold several).</summary>
    public static int FirstType(int types)
    {
        foreach (int t in new[] { Slash, Pierce, Bludgeon, Cold, Fire, Acid, Electric, Nether }) if ((types & t) != 0) return t;
        return Bludgeon;
    }

    /// <summary>Which of a body part's armor values is against a damage type (slash, pierce, bludgeon, cold, fire, acid, electric, nether).</summary>
    public static int ArmorIndex(int type) => type switch
    {
        Slash => 0, Pierce => 1, Bludgeon => 2, Cold => 3, Fire => 4, Acid => 5, Electric => 6, Nether => 7, _ => 2,
    };

    public static string TypeName(int type) => type switch
    {
        Slash => "slashing", Pierce => "piercing", Bludgeon => "bludgeoning", Cold => "cold", Fire => "fire",
        Acid => "acid", Electric => "electric", Nether => "nether", _ => "bludgeoning",
    };

    /// <summary>The short name the game uses for damage done to you ("bludgeon damage").</summary>
    public static string TypeShort(int type) => type switch
    {
        Slash => "slash", Pierce => "pierce", Bludgeon => "bludgeon", Cold => "cold", Fire => "fire",
        Acid => "acid", Electric => "electric", Nether => "nether", _ => "bludgeon",
    };

    /// <summary>The word for a hit, by how much of the victim's health it took (single: "you graze", plural: "it grazes").</summary>
    public static (string single, string plural) AttackVerb(int type, float percent)
    {
        string[] w = type switch
        {
            Slash => new[] { "mangle", "slash", "cut", "scratch" },
            Pierce => new[] { "gore", "impale", "stab", "nick" },
            Fire => new[] { "incinerate", "burn", "scorch", "singe" },
            Cold => new[] { "freeze", "frost", "chill", "numb" },
            Acid => new[] { "dissolve", "corrode", "sear", "blister" },
            Electric => new[] { "blast", "jolt", "shock", "spark" },
            Nether => new[] { "eradicate", "wither", "twist", "scar" },
            _ => new[] { "crush", "smash", "bash", "graze" },
        };
        string s = percent > 0.5f ? w[0] : percent > 0.25f ? w[1] : percent > 0.1f ? w[2] : w[3];
        string p = s.EndsWith("sh") || s.EndsWith("ch") || s.EndsWith("ss") ? s + "es" : s + "s";
        return (s, p);
    }

    /// <summary>The game's death messages for a damage type: what you see when you kill ({0} the victim), and when it kills you ({1} the killer).</summary>
    private static readonly Dictionary<int, (string you, string them)[]> Deaths = new()
    {
        [Slash] = new[]
        {
            ("You split {0} apart!", "{1} splits you apart!"),
            ("You cleave {0} in twain!", "{1} cleaves you in twain!"),
            ("{0} is torn to ribbons by your assault!", "You are torn to ribbons by {1}'s assault!"),
            ("Your killing blow nearly turns {0} inside-out!", "{1}'s killing blow nearly turns you inside-out!"),
        },
        [Pierce] = new[]
        {
            ("You run {0} through!", "{1} runs you through!"),
            ("{0} is fatally punctured!", "You are fatally punctured by {1}!"),
            ("{0}'s perforated corpse falls before you!", "Your perforated corpse falls before {1}!"),
            ("{0}'s death is preceded by a sharp, stabbing pain!", "Your death is preceded by a sharp, stabbing pain, courtesy of {1}!"),
        },
        [Bludgeon] = new[]
        {
            ("You beat {0} to a lifeless pulp!", "{1} beats you to a lifeless pulp!"),
            ("{0} is shattered by your assault!", "Your body is shattered by {1}'s attack!"),
            ("You flatten {0}'s body with the force of your assault!", "The force of {1}'s assault flattens you!"),
            ("The thunder of crushing {0} is followed by the deafening silence of death!", "The thunder of {1} crushing {0} is followed by the deafening silence of your death!"),
        },
        [Fire] = new[]
        {
            ("You bring {0} to a fiery end!", "{1} brings you to a fiery end!"),
            ("{0} is reduced to cinders!", "You are reduced to cinders by {1}!"),
            ("{0} is incinerated by your assault!", "You are incinerated by {1}'s assault!"),
            ("{0}'s seared corpse smolders before you!", "Your seared corpse smolders before {1}!"),
        },
        [Cold] = new[]
        {
            ("Your attack stops {0} cold!", "{1}'s attack stops you cold!"),
            ("Your assault sends {0} to an icy death!", "{1}'s assault sends you to an icy death!"),
            ("{0} suffers a frozen fate!", "You suffer a frozen fate at the hands of {1}!"),
        },
        [Acid] = new[]
        {
            ("{0} is liquified by your attack!", "You are liquified by {1}'s attack!"),
            ("{0}'s last strength dissolves before you!", "Your last strength dissolves before {1}!"),
            ("You reduce {0} to a sizzling, oozing mass!", "{1} reduces you to a sizzling, oozing mass!"),
        },
        [Electric] = new[]
        {
            ("Blistered by lightning, {0} falls!", "Blistered by {1}'s lightning, you die!"),
            ("Electricity tears {0} apart!", "Electricity from {1}'s attack tears you apart!"),
            ("Your lightning coruscates over {0}'s mortal remains!", "{1}'s lightning coruscates over your mortal remains!"),
        },
        [Nether] = new[]
        {
            ("{0} is dessicated by your attack!", "You are dessicated by {1}'s attack!"),
            ("{0}'s last strength withers before you!", "Your last strength withers before {1}!"),
            ("You reduce {0} to a drained, twisted corpse!", "{1} reduces you to a drained, twisted corpse!"),
        },
    };

    public static string DeathByYou(int type, string victim)
    {
        var list = Deaths.TryGetValue(type, out var l) ? l : Deaths[Bludgeon];
        return string.Format(list[Rng.Next(list.Length)].you, victim, "you");
    }

    public static string DeathOfYou(int type, string killer)
    {
        var list = Deaths.TryGetValue(type, out var l) ? l : Deaths[Bludgeon];
        return string.Format(list[Rng.Next(list.Length)].them, "you", killer);
    }

    // a creature's body parts (ACE CombatBodyPart)
    public static string PartName(int key) => key switch
    {
        0 => "head", 1 => "chest", 2 => "abdomen", 3 => "upper arm", 4 => "lower arm", 5 => "hand",
        6 => "upper leg", 7 => "lower leg", 8 => "foot", _ => "body",
    };

    /// <summary>The body part of yours an attack at a height strikes (as ACE picks a player's).</summary>
    public static string PlayerPart(int height) => height switch
    {
        0 => new[] { "head", "chest", "upperarm" }[Rng.Next(3)],
        1 => new[] { "chest", "abdomen", "upperarm", "lowerarm", "hand", "upperleg" }[Rng.Next(6)],
        _ => new[] { "foot", "lowerleg", "upperleg" }[Rng.Next(3)],
    };

    // skills (ACE Skill): the melee weapon skills, and defense
    public static readonly int[] MeleeSkills = { 1, 4, 5, 9, 10, 11, 13, 41, 44, 45, 46 };
    public const int MeleeDefense = 6, MissileDefense = 7, MagicDefense = 15, Run = 24;
    public const int CreatureEnchantment = 31, ItemEnchantment = 32, LifeMagic = 33, WarMagic = 34, ManaConversion = 16;

    /// <summary>
    /// A creature's skill as used: its base and ranks, with its attributes' share (a third of strength and
    /// coordination for attacks, of coordination and quickness for defense; quickness for running).
    /// </summary>
    public static int CreatureSkill(Creatures.SpawnData.Weenie w, int skill)
    {
        int str = w.Attributes[0], quick = w.Attributes[2], coord = w.Attributes[3];
        int share = skill switch
        {
            MeleeDefense => (coord + quick) / 3,
            Run => quick,
            4 or 46 => (coord + quick) / 3,   // dagger, finesse weapons
            _ => (str + coord) / 3,
        };
        return (w.Skills.TryGetValue(skill, out int b) ? b : 0) + share;
    }

    /// <summary>A creature's best melee attack skill.</summary>
    public static int CreatureAttack(Creatures.SpawnData.Weenie w)
    {
        int best = 0;
        foreach (int s in MeleeSkills) if (w.Skills.ContainsKey(s)) best = Math.Max(best, CreatureSkill(w, s));
        if (best == 0) best = (w.Attributes[0] + w.Attributes[3]) / 3;
        return best;
    }

    /// <summary>How fast a run skill runs (ACE MovementSystem.GetRunRate): 1 at nothing, up to 4.5.</summary>
    public static float RunRate(int runSkill)
    {
        if (runSkill >= 800) return 18f / 4f;
        return ((float)runSkill / (runSkill + 200) * 11f + 4f) / 4f;
    }
}
