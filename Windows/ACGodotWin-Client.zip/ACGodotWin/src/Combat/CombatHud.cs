using System;
using System.Collections.Generic;
using Godot;

namespace ACGodot.Combat;

/// <summary>
/// The fighting part of the screen, laid out as the game's: your health, stamina and mana bars at the bottom; above
/// them in combat mode the combat bar (the Speed - Power slider, the High / Medium / Low attack buttons and Repeat
/// Attacks); the selected creature's name and health at the top; and the combat messages at the bottom left.
/// </summary>
public partial class CombatHud : Control
{
    public static readonly Color Plain = new(0.92f, 0.92f, 0.92f), Hurt = new(1f, 0.33f, 0.3f), Hit = new(0.85f, 0.9f, 1f),
                                 Kill = new(1f, 0.9f, 0.35f);

    /// <summary>An attack button clicked: 0 high, 1 medium, 2 low.</summary>
    public Action<int>? AttackClicked;
    /// <summary>The power slider moved (0 speed .. 1 power).</summary>
    public Action<float>? PowerSet;
    public Action<bool>? RepeatSet, AutoTargetSet, KeepInViewSet;
    private CheckBox _auto = null!, _keep = null!;
    private ProgressBar _charge = null!;
    private readonly Button[] _heights = new Button[3];

    private ProgressBar _hp = null!, _st = null!, _mp = null!, _targetHp = null!;
    private Label _hpText = null!, _stText = null!, _mpText = null!, _targetName = null!;
    private PanelContainer _combatBar = null!, _target = null!;
    private HSlider _power = null!;
    private CheckBox _repeat = null!;
    private VBoxContainer _log = null!;
    private readonly Queue<Label> _lines = new();
    private bool _setting;
    private VBoxContainer _bottom = null!;
    private PanelContainer _vitalsPanel = null!;
    /// <summary>The game's own vitals bar is showing (then these simple ones aren't), and how far up the screen its top is.</summary>
    public bool RetailVitals;
    /// <summary>The combat bar put away (magic mode: the spell bar shows instead).</summary>
    public bool HideCombatBar;
    /// <summary>The jump being charged (0 to 1; -1: none): shown in the combat bar's power meter, or a bar of its own over the vitals.</summary>
    public float JumpCharge = -1f;
    private ProgressBar _jumpBar = null!;
    private Vector2? _jumpAt;
    private bool _jumpDrag;
    private Vector2 _jumpGrab;
    private float _powerShown;
    /// <summary>The selection's box at the top put away (the control bar shows what's selected).</summary>
    public bool HideTarget;
    public float BottomLimit = -1;

    /// <summary>
    /// Lays the parts out on the screen each frame (fitted to the window by hand: anchors under a CanvasLayer left
    /// this a zero-sized box, everything piled in the top corner).
    /// </summary>
    private Vector2? _barAt;
    private float _barWidth;   // sized by its grip (0: as it's made)
    private Control _grip = null!;
    private bool _gripDown;
    private float _gripFrom, _gripStart;
    private bool _barDrag;
    private Vector2 _barGrab;

    // the combat bar out of the stack over the vitals, placed on its own
    private void FreeBar()
    {
        if (_combatBar.GetParent() == this) return;
        var at = _combatBar.GlobalPosition;   // where it is on the screen now (before it leaves the stack)
        _combatBar.GetParent()?.RemoveChild(_combatBar);
        AddChild(_combatBar);
        _barAt ??= at;
        _combatBar.Position = _barAt.Value;
    }

    private void SaveBar()
    {
        var c = new ConfigFile(); global::ACGodot.SafeConfig.Load(c, "user://ui.cfg");
        if (_barAt is { } b) c.SetValue("ui", "combatbar", b);
        if (_barWidth > 0) c.SetValue("ui", "combatbar_w", _barWidth);
        if (_jumpAt is { } ja) c.SetValue("ui", "jumpbar", ja);
        global::ACGodot.SafeConfig.Save(c, "user://ui.cfg");
    }

    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("CombatHud");
        Vector2 screen = GetViewportRect().Size;
        if (_barDrag)
        {
            if (Input.IsMouseButtonPressed(MouseButton.Left)) _barAt = GetGlobalMousePosition() - _barGrab;
            else { _barDrag = false; SaveBar(); }
        }
        // its grip (bottom right, the interface unlocked): wider or narrower
        if (_gripDown)
        {
            if (Input.IsMouseButtonPressed(MouseButton.Left))
                _barWidth = Math.Clamp(_gripStart + GetGlobalMousePosition().X - _gripFrom, 360f, Math.Max(400f, screen.X - 20f));
            else { _gripDown = false; SaveBar(); }
            _combatBar.CustomMinimumSize = new Vector2(_barWidth, 0);
        }
        _grip.Visible = _combatBar.Visible && _combatBar.IsVisibleInTree() && !ACGodot.UI.UiLock.Locked;
        if (_barAt is { } ba && _combatBar.GetParent() == this)
        {
            _combatBar.Size = _combatBar.GetCombinedMinimumSize();
            // always on the screen (a place kept from a smaller window, or a bad drag, is pulled back)
            var max = (screen - _combatBar.Size).Max(Vector2.Zero);
            var p = ba.Clamp(Vector2.Zero, max);
            _barAt = p;
            _combatBar.Position = p;
        }
        _grip.Position = _combatBar.GlobalPosition + _combatBar.Size - _grip.Size;
        // the jump meter: a bar of its own (over the vitals unless it's been moved), only while a jump charges; with the
        // interface unlocked it can be grabbed then (hold Space) and dragged where you want it
        bool jumping = JumpCharge >= 0f;
        bool unlocked = !ACGodot.UI.UiLock.Locked;
        _charge.Value = _powerShown;
        _jumpBar.Visible = jumping || _jumpDrag;
        if (_jumpBar.Visible)
        {
            _jumpBar.Value = jumping ? JumpCharge : 0f;
            float bw = Math.Min(360f, screen.X * 0.3f);
            _jumpBar.Size = new Vector2(bw, 12f);
            if (_jumpDrag)
            {
                if (Input.IsMouseButtonPressed(MouseButton.Left)) _jumpAt = GetGlobalMousePosition() - _jumpGrab;
                else { _jumpDrag = false; SaveBar(); }
            }
            float top = RetailVitals && BottomLimit > 0 ? BottomLimit - 26f : screen.Y - (_vitalsPanel.Size.Y + 30f);
            var at = _jumpAt ?? new Vector2((screen.X - bw) * 0.5f, top);
            _jumpBar.Position = at.Clamp(Vector2.Zero, (screen - _jumpBar.Size).Max(Vector2.Zero));
            _jumpBar.MouseFilter = unlocked ? MouseFilterEnum.Stop : MouseFilterEnum.Ignore;
            _jumpBar.TooltipText = "";
        }
        Position = Vector2.Zero;
        Size = screen;
        _vitalsPanel.Visible = !RetailVitals;
        Vector2 b = _bottom.GetCombinedMinimumSize();
        _bottom.Size = b;
        float bottom = RetailVitals && BottomLimit > 0 ? BottomLimit - 4f : screen.Y - 8f;
        _bottom.Position = new Vector2((screen.X - b.X) * 0.5f, bottom - b.Y);
        if (HideTarget) _target.Visible = false;
        Vector2 t = _target.GetCombinedMinimumSize();
        _target.Size = t;
        _target.Position = new Vector2((screen.X - t.X) * 0.5f, 8f);
        Vector2 l = _log.GetCombinedMinimumSize();
        _log.Size = l;
        _log.Position = new Vector2(10f, screen.Y - l.Y - 10f);
    }

    public override void _Ready()
    {
        MouseFilter = MouseFilterEnum.Ignore;

        // bottom middle: the combat bar over the vitals
        var bottom = new VBoxContainer { MouseFilter = MouseFilterEnum.Ignore, CustomMinimumSize = new Vector2(520, 0) };
        AddChild(bottom);
        _bottom = bottom;

        _combatBar = Panel(new Color(0.08f, 0.06f, 0.04f, 0.85f));
        var cb = new HBoxContainer();
        cb.AddThemeConstantOverride("separation", 8);
        _combatBar.AddChild(cb);
        var left = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        var sliderRow = new HBoxContainer();
        sliderRow.AddChild(Small("Speed"));
        _power = new HSlider { MinValue = 0, MaxValue = 1, Step = 0.05, SizeFlagsHorizontal = SizeFlags.ExpandFill, FocusMode = FocusModeEnum.None };
        _power.ValueChanged += v => { if (!_setting) PowerSet?.Invoke((float)v); };
        sliderRow.AddChild(_power);
        sliderRow.AddChild(Small("Power"));
        left.AddChild(sliderRow);
        // the power meter: fills as your next swing gets ready
        // the power meter, in the slider's track: it fills from the left up to where the slider is set
        _charge = new ProgressBar { ShowPercentage = false, MaxValue = 1, ShowBehindParent = true, MouseFilter = MouseFilterEnum.Ignore };
        _charge.AddThemeStyleboxOverride("fill", new StyleBoxFlat { BgColor = new Color(1f, 0.75f, 0.2f, 0.85f) });
        _charge.AddThemeStyleboxOverride("background", new StyleBoxFlat { BgColor = new Color(0.2f, 0.15f, 0.05f, 0.8f) });
        _charge.SetAnchorsAndOffsetsPreset(LayoutPreset.FullRect);
        _power.AddChild(_charge);
        var checks = new HBoxContainer();
        CheckBox Check(string text, Action<bool> set)
        {
            var c = new CheckBox { Text = text, FocusMode = FocusModeEnum.None };
            c.AddThemeFontSizeOverride("font_size", ACGodot.UI.RetailTheme.Px(12));
            c.Toggled += on => { if (!_setting) set(on); };
            checks.AddChild(c);
            return c;
        }
        _repeat = Check("Repeat Attacks", on => RepeatSet?.Invoke(on));
        _auto = Check("Auto Target", on => AutoTargetSet?.Invoke(on));
        _keep = Check("Keep in View", on => KeepInViewSet?.Invoke(on));
        left.AddChild(checks);
        cb.AddChild(left);
        var buttons = new VBoxContainer();
        buttons.AddThemeConstantOverride("separation", 2);
        string[] names = { "High", "Medium", "Low" };
        for (int i = 0; i < 3; i++)
        {
            int h = i;
            var b = new Button { Text = names[i], CustomMinimumSize = new Vector2(76, 0), FocusMode = FocusModeEnum.None };
            b.AddThemeFontSizeOverride("font_size", ACGodot.UI.RetailTheme.Px(12));
            b.AddThemeColorOverride("font_color", new Color(1f, 0.85f, 0.8f));
            var sb = new StyleBoxFlat { BgColor = new Color(0.55f, 0.05f, 0.05f), ContentMarginTop = 1, ContentMarginBottom = 1 };
            b.AddThemeStyleboxOverride("normal", sb);
            b.AddThemeStyleboxOverride("hover", new StyleBoxFlat { BgColor = new Color(0.75f, 0.1f, 0.1f), ContentMarginTop = 1, ContentMarginBottom = 1 });
            b.AddThemeStyleboxOverride("pressed", new StyleBoxFlat { BgColor = new Color(0.95f, 0.2f, 0.15f), ContentMarginTop = 1, ContentMarginBottom = 1 });
            b.Pressed += () => AttackClicked?.Invoke(h);
            buttons.AddChild(b);
            _heights[i] = b;
        }
        cb.AddChild(buttons);
        bottom.AddChild(_combatBar);
        // with the interface unlocked the combat bar drags anywhere (kept); till then it sits over the vitals
        _combatBar.MouseFilter = MouseFilterEnum.Stop;
        _combatBar.GuiInput += e =>
        {
            // a press starts the drag; it follows the mouse until the button is let go (watched each frame, so a
            // release anywhere ends it)
            if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true } && !ACGodot.UI.UiLock.Locked)
            {
                FreeBar();
                _barGrab = GetGlobalMousePosition() - _combatBar.GlobalPosition;
                _barDrag = true;
                _combatBar.AcceptEvent();
            }
        };
        _jumpBar = new ProgressBar { ShowPercentage = false, MaxValue = 1, Visible = false, MouseFilter = MouseFilterEnum.Ignore };
        _jumpBar.AddThemeStyleboxOverride("fill", new StyleBoxFlat { BgColor = new Color(1f, 0.75f, 0.2f, 0.9f) });
        _jumpBar.AddThemeStyleboxOverride("background", new StyleBoxFlat { BgColor = new Color(0.12f, 0.09f, 0.04f, 0.85f), BorderColor = new Color(0.55f, 0.45f, 0.2f), BorderWidthLeft = 1, BorderWidthRight = 1, BorderWidthTop = 1, BorderWidthBottom = 1 });
        _jumpBar.GuiInput += e =>
        {
            if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true } && !ACGodot.UI.UiLock.Locked)
            { _jumpGrab = GetGlobalMousePosition() - _jumpBar.GlobalPosition; _jumpDrag = true; _jumpBar.AcceptEvent(); }
        };
        AddChild(_jumpBar);
        // the grip that sizes it (the interface unlocked): it comes out of the stack over the vitals to be its own size
        _grip = new Control { Size = new Vector2(14, 14), MouseDefaultCursorShape = CursorShape.Hsize, MouseFilter = MouseFilterEnum.Stop, ZIndex = 5 };
        _grip.Draw += () =>
        {
            var gc = new Color(0.8f, 0.65f, 0.3f, 0.9f);
            for (int i = 0; i < 3; i++) _grip.DrawLine(new Vector2(13, 4 + i * 4), new Vector2(4 + i * 4, 13), gc, 1f);
        };
        _grip.GuiInput += e =>
        {
            if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true } && !ACGodot.UI.UiLock.Locked)
            {
                FreeBar();
                _gripDown = true; _gripFrom = GetGlobalMousePosition().X; _gripStart = _combatBar.Size.X;
                _grip.AcceptEvent();
            }
        };
        AddChild(_grip);
        var cfg = new ConfigFile();
        if (global::ACGodot.SafeConfig.Load(cfg, "user://ui.cfg") == Error.Ok && cfg.HasSectionKey("ui", "combatbar")) { FreeBar(); _barAt = (Vector2)cfg.GetValue("ui", "combatbar"); }
        if (cfg.HasSectionKey("ui", "jumpbar")) _jumpAt = (Vector2)cfg.GetValue("ui", "jumpbar");
        if (cfg.HasSectionKey("ui", "combatbar_w")) { _barWidth = (float)cfg.GetValue("ui", "combatbar_w"); _combatBar.CustomMinimumSize = new Vector2(_barWidth, 0); }

        var vitals = Panel(new Color(0f, 0f, 0f, 0.6f));
        _vitalsPanel = vitals;
        var vb = new VBoxContainer();
        vb.AddThemeConstantOverride("separation", 2);
        vitals.AddChild(vb);
        (_hp, _hpText) = Bar(vb, new Color(0.8f, 0.08f, 0.08f));
        (_st, _stText) = Bar(vb, new Color(0.85f, 0.7f, 0.1f));
        (_mp, _mpText) = Bar(vb, new Color(0.15f, 0.35f, 0.9f));
        bottom.AddChild(vitals);

        // top middle: the selected creature
        _target = Panel(new Color(0f, 0f, 0f, 0.6f));
        _target.CustomMinimumSize = new Vector2(320, 0);
        var tv = new VBoxContainer();
        _target.AddChild(tv);
        _targetName = new Label { HorizontalAlignment = HorizontalAlignment.Center };
        _targetName.AddThemeFontSizeOverride("font_size", ACGodot.UI.RetailTheme.Px(18));
        _targetName.AddThemeColorOverride("font_color", new Color(1f, 0.95f, 0.6f));
        tv.AddChild(_targetName);
        _targetHp = new ProgressBar { ShowPercentage = false, CustomMinimumSize = new Vector2(300, 14), MaxValue = 1 };
        _targetHp.AddThemeStyleboxOverride("fill", new StyleBoxFlat { BgColor = new Color(0.8f, 0.08f, 0.08f) });
        _targetHp.AddThemeStyleboxOverride("background", new StyleBoxFlat { BgColor = new Color(0.15f, 0.02f, 0.02f) });
        tv.AddChild(_targetHp);
        AddChild(_target);

        // bottom left: the combat messages
        _log = new VBoxContainer { MouseFilter = MouseFilterEnum.Ignore };
        _log.AddThemeConstantOverride("separation", 0);
        AddChild(_log);
    }

    private static PanelContainer Panel(Color bg)
    {
        var p = new PanelContainer();
        p.AddThemeStyleboxOverride("panel", new StyleBoxFlat
        {
            BgColor = bg, ContentMarginLeft = 8, ContentMarginRight = 8, ContentMarginTop = 4, ContentMarginBottom = 4,
            BorderColor = new Color(0.55f, 0.42f, 0.2f), BorderWidthTop = 1, BorderWidthBottom = 1, BorderWidthLeft = 1, BorderWidthRight = 1,
        });
        return p;
    }

    private static Label Small(string text)
    {
        var l = new Label { Text = text };
        l.AddThemeFontSizeOverride("font_size", ACGodot.UI.RetailTheme.Px(12));
        l.AddThemeColorOverride("font_color", new Color(0.95f, 0.88f, 0.7f));
        return l;
    }

    private static (ProgressBar, Label) Bar(Container parent, Color color)
    {
        var bar = new ProgressBar { ShowPercentage = false, CustomMinimumSize = new Vector2(500, 12), MaxValue = 1 };
        bar.AddThemeStyleboxOverride("fill", new StyleBoxFlat { BgColor = color });
        bar.AddThemeStyleboxOverride("background", new StyleBoxFlat { BgColor = color.Darkened(0.8f) });
        var text = new Label { HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
        text.SetAnchorsPreset(LayoutPreset.FullRect);
        text.AddThemeFontSizeOverride("font_size", ACGodot.UI.RetailTheme.Px(10));
        text.AddThemeColorOverride("font_outline_color", Colors.Black);
        text.AddThemeConstantOverride("outline_size", 3);
        bar.AddChild(text);
        parent.AddChild(bar);
        return (bar, text);
    }

    /// <summary>Brings the bars up to date (target health -1: the selection isn't something that fights).</summary>
    public void Show(int health, int maxHealth, bool combat, float power, bool repeat, string? target, int targetHealth, int targetMax,
                     int stamina, int maxStamina, int mana, int maxMana, bool autoTarget, bool keepInView, int height, float charge)
    {
        if (_hp == null) return;
        _hp.Value = maxHealth > 0 ? (double)health / maxHealth : 0; _hpText.Text = $"{Math.Max(health, 0)}/{maxHealth}";
        _st.Value = maxStamina > 0 ? (double)stamina / maxStamina : 0; _stText.Text = $"{stamina}/{maxStamina}";
        _mp.Value = maxMana > 0 ? (double)mana / maxMana : 0; _mpText.Text = $"{mana}/{maxMana}";
        _combatBar.Visible = combat && !HideCombatBar;
        _setting = true;
        if (Math.Abs(_power.Value - power) > 0.001) _power.Value = power;
        if (_repeat.ButtonPressed != repeat) _repeat.ButtonPressed = repeat;
        if (_auto.ButtonPressed != autoTarget) _auto.ButtonPressed = autoTarget;
        if (_keep.ButtonPressed != keepInView) _keep.ButtonPressed = keepInView;
        _setting = false;
        _powerShown = charge * power;
        _charge.Value = _powerShown;
        // the attack under way: its button lit
        for (int i = 0; i < 3; i++) _heights[i].Modulate = i == height ? new Color(1.6f, 1.5f, 1.1f) : Colors.White;
        _target.Visible = target != null && !HideTarget;
        if (target != null)
        {
            _targetName.Text = target;
            _targetHp.Visible = targetHealth >= 0;
            if (targetHealth >= 0) _targetHp.Value = targetMax > 0 ? (double)Math.Max(targetHealth, 0) / targetMax : 0;
        }
    }

    /// <summary>A combat message at the bottom left (the last ten stay).</summary>
    /// <summary>Where messages go instead (the game's chat window), once there is one.</summary>
    public Action<string, Color>? LogTo;

    public void Log(string text, Color color)
    {
        if (LogTo != null) { LogTo(text, color); return; }
        if (_log == null) return;
        var l = new Label { Text = text, AutowrapMode = TextServer.AutowrapMode.WordSmart, CustomMinimumSize = new Vector2(550, 0) };
        l.AddThemeFontSizeOverride("font_size", ACGodot.UI.RetailTheme.Px(13));
        l.AddThemeColorOverride("font_color", color);
        l.AddThemeColorOverride("font_outline_color", Colors.Black);
        l.AddThemeConstantOverride("outline_size", 4);
        _log.AddChild(l);
        _lines.Enqueue(l);
        while (_lines.Count > 10) _lines.Dequeue().QueueFree();
    }
}
