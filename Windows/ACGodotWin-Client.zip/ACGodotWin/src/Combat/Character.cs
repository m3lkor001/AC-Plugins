using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using DatReaderWriter.DBObjs;
using DatReaderWriter.Enums;
using Godot;

namespace ACGodot.Combat;

/// <summary>
/// The character you play: its attributes, vitals and skills, worked out as the game does (the skill table's formula
/// of attributes, plus 5 for a trained skill or 10 for a specialized one, plus the ranks bought with experience), and
/// its experience, level and skill credits (from the game's experience table). Kept between runs in
/// user://character.json.
/// </summary>
public sealed class Character
{
    public const uint ExperienceTableId = 0x0E000018, SkillTableId = 0x0E000004;
    public static readonly string[] AttributeNames = { "Strength", "Endurance", "Quickness", "Coordination", "Focus", "Self" };
    public static readonly string[] VitalNames = { "Health", "Stamina", "Mana" };
    /// <summary>Skills the game retired (folded into Heavy, Light and Finesse Weapons, and Missile Weapons): not shown.</summary>
    public static readonly HashSet<int> Retired = new() { 1, 2, 3, 4, 5, 8, 9, 10, 11, 12, 13 };

    public enum Training { Untrained, Trained, Specialized }
    public sealed class SkillState { public Training Training; public int Ranks; }

    public string Name = "Adventurer";
    /// <summary>The body's starting outfit (the robe...) has been made into worn items.</summary>
    public bool OutfitGiven;
    public string Heritage = "Aluvian";
    public int[] AttributeBase = { 100, 90, 50, 70, 10, 10 };   // as made: 330 points, as the game allows
    public int[] AttributeRanks = new int[6];
    public int[] VitalRanks = new int[3];
    public Dictionary<int, SkillState> Skills = new();
    public long TotalXp, UnassignedXp;
    public int Level = 1, SkillCredits;
    public int Health, Stamina, Mana;   // now

    private ExperienceTable? _xp;
    private SkillTable? _skills;

    /// <summary>A ready-made level 1 Aluvian fighter: heavy weapons and melee defense specialized.</summary>
    public static Character Starter()
    {
        var c = new Character();
        void S(int id, Training t) => c.Skills[id] = new SkillState { Training = t };
        S(44, Training.Specialized);   // Heavy Weapons
        S(6, Training.Specialized);    // Melee Defense
        foreach (int id in new[] { 7, 15, 21, 22, 24, 14, 48, 36 }) S(id, Training.Trained);   // missile & magic defense, healing, jump, run, arcane lore, shield, loyalty
        foreach (int id in new[] { 34, 33, 31 }) S(id, Training.Trained);   // war and life magic, creature enchantment (to cast with)
        return c;
    }

    public void Attach(Dats dats)
    {
        try { _xp = dats.Get<ExperienceTable>(ExperienceTableId); } catch { _xp = null; }
        try { _skills = dats.Get<SkillTable>(SkillTableId); } catch { _skills = null; }
    }

    // what spells and magic items add for now (not kept: they wear off)
    [System.Text.Json.Serialization.JsonIgnore] public readonly int[] AttributeBuff = new int[6];
    [System.Text.Json.Serialization.JsonIgnore] public readonly int[] VitalBuff = new int[3];
    [System.Text.Json.Serialization.JsonIgnore] public readonly Dictionary<int, int> SkillBuff = new();

    public int Attribute(int i) => AttributeBase[i] + AttributeRanks[i] + AttributeBuff[i];
    // (on a server, as it works them out: what multiplies a vital's top (a benediction's tenth more) is taken of the
    // whole before what's added on; health has what's worn and each enlightenment in it too)
    [System.Text.Json.Serialization.JsonIgnore] public readonly float[] VitalMult = { 1f, 1f, 1f };
    [System.Text.Json.Serialization.JsonIgnore] public int HealthBonus;
    /// <summary>Added to every skill (enlightenments, the all-skills aura, Jack of All Trades), to specialized ones besides, and to single skills (the weapon and magic masteries).</summary>
    [System.Text.Json.Serialization.JsonIgnore] public int SkillBonusAll, SkillBonusSpec;
    [System.Text.Json.Serialization.JsonIgnore] public readonly Dictionary<int, int> SkillBonus = new();
    /// <summary>On a server: your greatest health as the server has it (worked out from what it says of how hurt you are);
    /// 0: not known - worked out here. A server's own rules (a zone that lowers it) aren't ours to guess.</summary>
    public int ServerMaxHealth;
    public int MaxHealth => ServerMaxHealth > 0 ? ServerMaxHealth : (int)MathF.Round((Attribute(1) / 2 + VitalRanks[0] + HealthBonus) * VitalMult[0] + VitalBuff[0]);
    public int MaxStamina => (int)MathF.Round((Attribute(1) + VitalRanks[1]) * VitalMult[1] + VitalBuff[1]);
    public int MaxMana => (int)MathF.Round((Attribute(5) + VitalRanks[2]) * VitalMult[2] + VitalBuff[2]);
    public int MaxVital(int v) => v switch { 0 => MaxHealth, 1 => MaxStamina, _ => MaxMana };

    /// <summary>The skills the game has (by the skill table), its name for each.</summary>
    /// <summary>A skill's icon (the game's own).</summary>
    public uint SkillIcon(int id)
    {
        if (_skills == null) return 0;
        foreach (var kv in _skills.Skills) if ((int)kv.Key == id) return kv.Value.IconId;
        return 0;
    }

    public IEnumerable<(int id, string name)> AllSkills()
    {
        if (_skills == null) yield break;
        foreach (var kv in _skills.Skills.OrderBy(k => k.Value.Name.Value))
        {
            int id = (int)kv.Key;
            if (Retired.Contains(id)) continue;
            yield return (id, kv.Value.Name.Value);
        }
    }

    public Training TrainingOf(int skill) => Skills.TryGetValue(skill, out var s) ? s.Training : Training.Untrained;

    /// <summary>A skill as used: the skill table's formula of attributes, the training bonus and the ranks.</summary>
    public int Skill(int id)
    {
        int formula = 0;
        if (_skills != null && _skills.Skills.TryGetValue((SkillId)id, out var b) && b.Formula is { } f && f.Divisor > 0)
        {
            int a1 = f.Attribute1 > 0 ? Attribute((int)f.Attribute1 - 1) * Math.Max(f.Attribute1Multiplier, 1) : 0;
            int a2 = f.Attribute2 > 0 ? Attribute((int)f.Attribute2 - 1) * Math.Max(f.Attribute2Multiplier, 1) : 0;
            formula = (a1 + a2) / f.Divisor + f.AdditiveBonus;
        }
        var t = TrainingOf(id);
        int bonus = t == Training.Specialized ? 10 : t == Training.Trained ? 5 : 0;
        int extra = t == Training.Specialized || t == Training.Trained ? SkillBonusAll + (t == Training.Specialized ? SkillBonusSpec : 0) + (SkillBonus.TryGetValue(id, out int own) ? own : 0) : 0;
        return formula + bonus + extra + (Skills.TryGetValue(id, out var s) ? s.Ranks : 0) + (SkillBuff.TryGetValue(id, out int buff) ? buff : 0);
    }

    /// <summary>
    /// How a skill comes to what it is (for its tooltip): the skill table's formula of attributes - so you know which
    /// to raise to help it - with your numbers, then training, ranks and spells.
    /// </summary>
    public string SkillBreakdown(int id)
    {
        var lines = new List<string>();
        int formula = 0;
        if (_skills != null && _skills.Skills.TryGetValue((SkillId)id, out var b) && b.Formula is { } f && f.Divisor > 0)
        {
            string Part(uint attr, int mult) => (mult > 1 ? mult + " x " : "") + AttributeNames[(int)attr - 1];
            string Num(uint attr, int mult) => (mult > 1 ? mult + " x " : "") + Attribute((int)attr - 1);
            var names = new List<string>(); var nums = new List<string>();
            if (f.Attribute1 > 0) { names.Add(Part((uint)f.Attribute1, (int)f.Attribute1Multiplier)); nums.Add(Num((uint)f.Attribute1, (int)f.Attribute1Multiplier)); }
            if (f.Attribute2 > 0) { names.Add(Part((uint)f.Attribute2, (int)f.Attribute2Multiplier)); nums.Add(Num((uint)f.Attribute2, (int)f.Attribute2Multiplier)); }
            int a1 = f.Attribute1 > 0 ? Attribute((int)f.Attribute1 - 1) * Math.Max(f.Attribute1Multiplier, 1) : 0;
            int a2 = f.Attribute2 > 0 ? Attribute((int)f.Attribute2 - 1) * Math.Max(f.Attribute2Multiplier, 1) : 0;
            formula = (a1 + a2) / f.Divisor + f.AdditiveBonus;
            string div = f.Divisor > 1 ? $" / {f.Divisor}" : "";
            string add = f.AdditiveBonus != 0 ? $" + {f.AdditiveBonus}" : "";
            if (names.Count > 0)
            {
                lines.Add($"Formula: ({string.Join(" + ", names)}){div}{add}");
                lines.Add($"   = ({string.Join(" + ", nums)}){div}{add} = {formula}");
            }
        }
        if (lines.Count == 0) lines.Add("No attributes count towards it.");
        var t = TrainingOf(id);
        int bonus = t == Training.Specialized ? 10 : t == Training.Trained ? 5 : 0;
        if (bonus > 0) lines.Add($"{t}: +{bonus}");
        int ranks = Skills.TryGetValue(id, out var st) ? st.Ranks : 0;
        if (ranks > 0) lines.Add($"Raised with experience: +{ranks}");
        if (SkillBuff.TryGetValue(id, out int buff) && buff != 0) lines.Add($"Spells: {(buff > 0 ? "+" : "")}{buff}");
        lines.Add($"Total: {Skill(id)}");
        return string.Join("\n", lines);
    }

    /// <summary>Your attack skill bare-handed: the best of your melee weapon skills (as ACE has it).</summary>
    public int MeleeAttack => new[] { 44, 45, 46, 41 }.Max(Skill);

    // ── raising things with experience ──

    private static long Step(uint[]? table, int rank) =>
        table == null || rank + 1 >= table.Length ? -1 : (long)table[rank + 1] - table[rank];

    /// <summary>What the next rank of an attribute costs (-1: can't go higher).</summary>
    public long AttributeCost(int i) => Step(_xp?.Attributes, AttributeRanks[i]);
    public long VitalCost(int v) => Step(_xp?.Vitals, VitalRanks[v]);
    public long SkillCost(int id)
    {
        var t = TrainingOf(id);
        if (t == Training.Untrained) return -1;
        return Step(t == Training.Specialized ? _xp?.SpecializedSkills : _xp?.TrainedSkills, Skills[id].Ranks);
    }

    /// <summary>The skill credits training a skill takes (-1: it can't be trained).</summary>
    public int TrainCost(int id) => _skills != null && _skills.Skills.TryGetValue((SkillId)id, out var b) ? b.TrainedCost : -1;

    /// <summary>
    /// On a server, what's raised or trained is asked of it too (0 an attribute, 1 a vital, 2 a skill, 3 a skill trained;
    /// which one; the experience or credits it costs) - the server's own numbers follow.
    /// </summary>
    [System.Text.Json.Serialization.JsonIgnore] public Action<int, int, long>? NetRaise;

    public bool RaiseAttribute(int i) { long c = AttributeCost(i); if (c < 0 || c > UnassignedXp) return false; UnassignedXp -= c; AttributeRanks[i]++; if (OnServer) NetRaise?.Invoke(0, i, c); return true; }
    public bool RaiseVital(int v) { long c = VitalCost(v); if (c < 0 || c > UnassignedXp) return false; UnassignedXp -= c; VitalRanks[v]++; if (OnServer) NetRaise?.Invoke(1, v, c); return true; }
    public bool RaiseSkill(int id) { long c = SkillCost(id); if (c < 0 || c > UnassignedXp) return false; UnassignedXp -= c; Skills[id].Ranks++; if (OnServer) NetRaise?.Invoke(2, id, c); return true; }

    public bool TrainSkill(int id)
    {
        int c = TrainCost(id);
        if (c < 0 || c > SkillCredits || TrainingOf(id) != Training.Untrained) return false;
        SkillCredits -= c;
        Skills[id] = new SkillState { Training = Training.Trained };
        if (OnServer) NetRaise?.Invoke(3, id, c);
        return true;
    }

    /// <summary>Vitae: 1 is none; each death takes 5% (down to 60%), won back by earning experience.</summary>
    public float Vitae = 1f;
    public long VitaePool;
    /// <summary>The experience that wins back one percent of vitae (more the higher you are).</summary>
    public long VitaeXpPerPercent => Math.Max(50, (long)Level * Level * 5);

    /// <summary>You died: vitae lost. Returns the vitae now.</summary>
    public float LoseVitae()
    {
        Vitae = Math.Max(0.6f, MathF.Round((Vitae - 0.05f) * 100f) / 100f);
        VitaePool = 0;
        return Vitae;
    }

    /// <summary>Experience to reach the next level (-1 at the top).</summary>
    public long NextLevelXp => _xp != null && Level + 1 < _xp.Levels.Length ? (long)_xp.Levels[Level + 1] : -1;

    /// <summary>Earns experience; returns the levels gained (each brings its skill credits).</summary>
    public int AddXp(long amount)
    {
        TotalXp += amount; UnassignedXp += amount;
        // experience earned wins vitae back, a percent at a time
        if (Vitae < 1f)
        {
            VitaePool += amount;
            long per = VitaeXpPerPercent;
            while (Vitae < 1f && VitaePool >= per) { VitaePool -= per; Vitae = Math.Min(1f, MathF.Round((Vitae + 0.01f) * 100f) / 100f); }
            if (Vitae >= 1f) VitaePool = 0;
        }
        int gained = 0;
        while (_xp != null && Level + 1 < _xp.Levels.Length && (ulong)TotalXp >= _xp.Levels[Level + 1])
        {
            Level++; gained++;
            if (Level < _xp.SkillCredits.Length) SkillCredits += (int)_xp.SkillCredits[Level];
        }
        return gained;
    }

    // ── keeping it between runs ──

    private const string SavePath = "user://character.json";

    private sealed class Saved
    {
        public string Name { get; set; } = "";
        public int[] AttributeBase { get; set; } = Array.Empty<int>();
        public int[] AttributeRanks { get; set; } = Array.Empty<int>();
        public int[] VitalRanks { get; set; } = Array.Empty<int>();
        public Dictionary<string, int[]> Skills { get; set; } = new();
        public long TotalXp { get; set; }
        public long UnassignedXp { get; set; }
        public int Level { get; set; }
        public int SkillCredits { get; set; }
        public List<Inventory.SavedItem>? Pack { get; set; }
        public List<Inventory.SavedItem>? Worn { get; set; }
        public long Pyreals { get; set; }
        public bool OutfitGiven { get; set; }
        public float Vitae { get; set; } = 1f;
        public long VitaePool { get; set; }
    }

    public static Character Load(Inventory? into = null)
    {
        try
        {
            using var f = Godot.FileAccess.Open(SavePath, Godot.FileAccess.ModeFlags.Read);
            if (f != null)
            {
                var s = JsonSerializer.Deserialize<Saved>(f.GetAsText());
                if (s != null && s.AttributeBase.Length == 6)
                {
                    var c = new Character
                    {
                        Name = s.Name, AttributeBase = s.AttributeBase, AttributeRanks = s.AttributeRanks.Length == 6 ? s.AttributeRanks : new int[6],
                        VitalRanks = s.VitalRanks.Length == 3 ? s.VitalRanks : new int[3],
                        TotalXp = s.TotalXp, UnassignedXp = s.UnassignedXp, Level = Math.Max(1, s.Level), SkillCredits = s.SkillCredits,
                        OutfitGiven = s.OutfitGiven, Vitae = s.Vitae is > 0f and <= 1f ? s.Vitae : 1f, VitaePool = s.VitaePool,
                    };
                    foreach (var kv in s.Skills)
                        if (int.TryParse(kv.Key, out int id) && kv.Value.Length == 2)
                            c.Skills[id] = new SkillState { Training = (Training)kv.Value[0], Ranks = kv.Value[1] };
                    into?.Restore(s.Pack, s.Worn, s.Pyreals);
                    return c;
                }
            }
        }
        catch (Exception ex) { GD.PushWarning("character: " + ex.Message); }
        return Starter();
    }

    /// <summary>Playing on a server: this is the server's character (read from it) - never written over the offline one's file.</summary>
    [System.Text.Json.Serialization.JsonIgnore] public bool OnServer;

    public void Save(Inventory? inv = null)
    {
        if (OnServer) return;
        try
        {
            var s = new Saved
            {
                Name = Name, AttributeBase = AttributeBase, AttributeRanks = AttributeRanks, VitalRanks = VitalRanks,
                Skills = Skills.ToDictionary(kv => kv.Key.ToString(), kv => new[] { (int)kv.Value.Training, kv.Value.Ranks }),
                TotalXp = TotalXp, UnassignedXp = UnassignedXp, Level = Level, SkillCredits = SkillCredits,
                Pack = inv?.SavePack(), Worn = inv?.SaveWorn(), Pyreals = inv?.Pyreals ?? 0, OutfitGiven = OutfitGiven,
                Vitae = Vitae, VitaePool = VitaePool,
            };
            using var f = Godot.FileAccess.Open(SavePath, Godot.FileAccess.ModeFlags.Write);
            f?.StoreString(JsonSerializer.Serialize(s));
        }
        catch (Exception ex) { GD.PushWarning("character save: " + ex.Message); }
    }
}
