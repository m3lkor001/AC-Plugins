using System;
using System.Collections.Generic;
using System.IO;
using Godot;

namespace ACGodot;

/// <summary>
/// Every warning and error the engine or our code reports (GD.PushWarning / PushError, an exception in a callback, a
/// shader that wouldn't build) kept in the character's own logs folder - logs/&lt;Character&gt;/warnings.txt - with the
/// time, where it came from, and how many times it has come up. The same one over and over is written once, then
/// counted (its count written again every 100 and at the hour), so a runaway doesn't fill the disk.
/// </summary>
public partial class WarningLog : Logger
{
    private readonly Func<string> _dir;
    private readonly object _lock = new();
    private readonly Dictionary<string, int> _seen = new();
    private DateTime _hour = DateTime.Now;

    public WarningLog(Func<string> dir) { _dir = dir; }

    public override void _LogError(string function, string file, int line, string code, string rationale, bool editorNotify, int errorType, Godot.Collections.Array<ScriptBacktrace> scriptBacktraces)
    {
        string kind = errorType switch { 1 => "WARNING", 2 => "SCRIPT ERROR", 3 => "SHADER ERROR", _ => "ERROR" };
        string what = string.IsNullOrEmpty(rationale) ? code : rationale;
        string where = string.IsNullOrEmpty(file) ? "" : $" ({Path.GetFileName(file)}:{line}{(string.IsNullOrEmpty(function) ? "" : " " + function)})";
        Write($"{kind}: {what}{where}");
    }

    public override void _LogMessage(string message, bool error)
    {
        // (plain prints go to the client's log already; only what's printed as an error is kept here too)
        if (error) Write("ERROR: " + message.TrimEnd());
    }

    private void Write(string line)
    {
        try
        {
            lock (_lock)
            {
                if (DateTime.Now - _hour > TimeSpan.FromHours(1)) { _seen.Clear(); _hour = DateTime.Now; }
                _seen.TryGetValue(line, out int n);
                _seen[line] = ++n;
                if (n > 1 && n % 100 != 0) return;
                if (_seen.Count > 5000) _seen.Clear();
                string path = Path.Combine(_dir(), "warnings.txt");
                var fi = new FileInfo(path);
                if (fi.Exists && fi.Length > 4_000_000) File.Move(path, Path.Combine(_dir(), "warnings.prev.txt"), true);
                File.AppendAllText(path, $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} {(n > 1 ? $"[x{n}] " : "")}{line}\n");
            }
        }
        catch { }
    }
}
