using System;
using System.Linq;
using ACGodot.Combat;
using DatReaderWriter.Enums;
using Godot;

namespace ACGodot.Magic;

/// <summary>The spellbook (M or /spells): the spells you can cast by school, each to cast or put on the shortcut bar, and what's on you now.</summary>
public partial class SpellbookWindow : GameWindow
{
    public MagicSystem? Magic;
    public Func<uint, Texture2D?> Icon = _ => null;
    public Action<Spell>? Shortcut;
    private int _tab;
    private double _refreshIn;

    public SpellbookWindow() : base("Spellbook", new Vector2(360, 480)) { }

    public void Open() { Visible = true; Refresh(); }

    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("SpellbookWindow");
        base._Process(delta);
        // the Active tab's times count down
        if (Visible && _tab == 4 && (_refreshIn -= delta) <= 0) { _refreshIn = 1; Refresh(); }
    }

    public void Refresh()
    {
        if (!Visible || Magic == null) return;
        Clear();
        var tabs = new TabContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, CustomMinimumSize = new Vector2(330, 420) };
        foreach (var (school, name) in new[] { (MagicSchool.WarMagic, "War"), (MagicSchool.LifeMagic, "Life"), (MagicSchool.CreatureEnchantment, "Creature"), (MagicSchool.ItemEnchantment, "Item"), (MagicSchool.VoidMagic, "Void") })
        {
            var page = new ScrollContainer { Name = name, HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled };
            var box = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
            page.AddChild(box);
            var spells = Magic.Known().Where(s => s.School == school).ToList();
            if (spells.Count == 0) box.AddChild(Text(Magic.MaxLevel(spells.FirstOrDefault()?.SkillId ?? SkillOf(school)) == 0 ? $"You haven't trained {name} Magic." : "No spells here yet.", 12, ACGodot.UI.RetailTheme.Dim));
            foreach (var s in spells)
            {
                var sp = s;
                var row = new HBoxContainer();
                // the spell's icon: drag it onto the shortcut bar (or the spell bar)
                var icon = new SpellIcon { Texture = Icon(s.Icon), CustomMinimumSize = new Vector2(24, 24), ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize, StretchMode = TextureRect.StretchModeEnum.KeepAspectCentered,
                                           Entry = new ACGodot.UI.ShortcutBar.Entry("spell", s.Id, s.Name, s.Icon), TooltipText = "Drag onto the shortcut bar", MouseFilter = MouseFilterEnum.Stop,
                                           MouseDefaultCursorShape = CursorShape.Drag };
                row.AddChild(icon);
                row.AddChild(new Label { Text = s.Name, SizeFlagsHorizontal = SizeFlags.ExpandFill, TooltipText = s.Description, MouseFilter = MouseFilterEnum.Pass });
                row.AddChild(new Label { Text = $"{s.Mana}", CustomMinimumSize = new Vector2(30, 0), HorizontalAlignment = HorizontalAlignment.Right });
                row.AddChild(Small("Cast", () => Magic.Cast(sp.Id)));
                box.AddChild(row);
            }
            tabs.AddChild(page);
        }
        var active = new ScrollContainer { Name = "Active", HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled };
        var abox = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        active.AddChild(abox);
        var on = Magic.Active().ToList();
        if (on.Count == 0) abox.AddChild(Text("No spells are on you.", 12, ACGodot.UI.RetailTheme.Dim));
        foreach (var (spell, left, amount) in on)
            abox.AddChild(new Label { Text = $"{spell.Name} (+{amount})" + (left < 0 ? "  - from an item" : $"  - {(int)left / 60}:{(int)left % 60:00}") });
        tabs.AddChild(active);
        tabs.CurrentTab = Math.Clamp(_tab, 0, 4);
        tabs.TabChanged += t => _tab = (int)t;
        Body.AddChild(tabs);
    }

    private static int SkillOf(MagicSchool s) => s switch
    {
        MagicSchool.WarMagic => Rules.WarMagic, MagicSchool.LifeMagic => Rules.LifeMagic,
        MagicSchool.CreatureEnchantment => Rules.CreatureEnchantment, _ => Rules.ItemEnchantment,
    };
}

/// <summary>A spell's icon that drags onto the shortcut bar.</summary>
public partial class SpellIcon : TextureRect
{
    public ACGodot.UI.ShortcutBar.Entry? Entry;

    public override Variant _GetDragData(Vector2 at)
    {
        if (Entry == null) return default;
        ACGodot.UI.ShortcutBar.DraggingSpell = Entry;
        var pic = new TextureRect { Texture = Texture, Size = new Vector2(32, 32), ExpandMode = ExpandModeEnum.IgnoreSize, StretchMode = StretchModeEnum.KeepAspectCentered };
        var holder = new Control(); holder.AddChild(pic); pic.Position = new Vector2(-16, -16);
        holder.ZIndex = 1000; holder.ZAsRelative = false;   // (over everything: some squares sit a layer up)
        SetDragPreview(holder);
        return "acgodot-spell";
    }
}
