using System.Collections.Generic;
using AcDream.Core.Terrain;
using DatReaderWriter.DBObjs;
using Godot;

namespace ACGodot.Terrain;

/// <summary>
/// One landblock's terrain (192 m square, 8 x 8 cells of two triangles) as a Godot mesh. The triangles, normals and
/// texture recipe come from OpenAC's LandblockMesh (the retail rules); this turns them into Godot vertex arrays.
/// AC is Z-up; Godot is Y-up: AC (x, y, z) is Godot (x, z, -y) - see <see cref="World.ToGodot"/>.
/// </summary>
public static class LandblockMeshes
{
    /// <summary>The vertex arrays for a landblock (built on any thread); null when the cell file has no such landblock.</summary>
    public static Godot.Collections.Array? BuildArrays(Dats dats, int lbX, int lbY, TerrainTextures tex, IDictionary<uint, SurfaceInfo> surfaceCache)
    {
        uint id = ((uint)lbX << 24) | ((uint)lbY << 16) | 0xFFFFu;
        LandBlock? block = dats.Cell<LandBlock>(id);
        if (block == null) return null;
        LandblockMeshData data;
        lock (surfaceCache) data = LandblockMesh.Build(block, (uint)lbX, (uint)lbY, tex.HeightTable, tex.Blending, surfaceCache);

        int n = data.Vertices.Length;
        var pos = new Vector3[n];
        var nrm = new Vector3[n];
        var uv = new Vector2[n];
        var c0 = new float[n * 4];
        var c1 = new float[n * 4];
        var c2 = new float[n * 4];
        var c3 = new float[n * 4];
        var idx = new int[n];
        // water that can't be walked into: the server only stops you in a landblock that's water all through (every corner
        // of all 64 cells water - ACE's EntirelyWater block: the open sea, a great lake). Water in a landblock that has any
        // land in it is waded, deep or not. Shown red with "Tint ground too steep to walk up" - flagged in custom3.x
        // (+4 on its rotation)
        bool blockWater = true;
        for (int x = 0; x < 9 && blockWater; x++)
            for (int y = 0; y < 9 && blockWater; y++)
            {
                int t = ((ushort)block.Terrain[x * 9 + y] >> 2) & 0x1F;
                if (t < 0x10 || t > 0x14) blockWater = false;
            }
        bool WaterCell(int i0) => blockWater;
        bool water = false;
        for (int i = 0; i < n; i++)
        {
            if (i % 6 == 0) water = WaterCell(i);
            TerrainVertex v = data.Vertices[i];
            pos[i] = World.ToGodot(v.Position);
            nrm[i] = World.ToGodot(v.Normal);
            uint d0 = v.Data0, d1 = v.Data1, d2 = v.Data2, d3 = v.Data3;
            uint split = (d3 >> 12) & 1u;
            uv[i] = CornerUv(i % 6, split);
            // custom0: base layer, overlay 0 layer, overlay 0 alpha, overlay 0 rotation
            Put(c0, i, d0 & 0xFF, (d0 >> 16) & 0xFF, (d0 >> 24) & 0xFF, (d3 >> 2) & 3);
            // custom1: overlay 1 layer / alpha, overlay 2 layer / alpha
            Put(c1, i, d1 & 0xFF, (d1 >> 8) & 0xFF, (d1 >> 16) & 0xFF, (d1 >> 24) & 0xFF);
            // custom2: road 0 layer / alpha, road 1 layer / alpha
            Put(c2, i, d2 & 0xFF, (d2 >> 8) & 0xFF, (d2 >> 16) & 0xFF, (d2 >> 24) & 0xFF);
            // custom3: overlay 1, overlay 2, road 0, road 1 rotations
            Put(c3, i, ((d3 >> 4) & 3) + (water ? 4u : 0u), (d3 >> 6) & 3, (d3 >> 8) & 3, (d3 >> 10) & 3);
            idx[i] = (int)data.Indices[i];
        }
        // AC's triangles wind counter-clockwise seen from above; Godot's front faces are clockwise
        for (int i = 0; i + 2 < n; i += 3) (idx[i + 1], idx[i + 2]) = (idx[i + 2], idx[i + 1]);

        var arrays = new Godot.Collections.Array();
        arrays.Resize((int)Mesh.ArrayType.Max);
        arrays[(int)Mesh.ArrayType.Vertex] = pos;
        arrays[(int)Mesh.ArrayType.Normal] = nrm;
        arrays[(int)Mesh.ArrayType.TexUV] = uv;
        arrays[(int)Mesh.ArrayType.Custom0] = c0;
        arrays[(int)Mesh.ArrayType.Custom1] = c1;
        arrays[(int)Mesh.ArrayType.Custom2] = c2;
        arrays[(int)Mesh.ArrayType.Custom3] = c3;
        arrays[(int)Mesh.ArrayType.Index] = idx;
        return arrays;
    }

    /// <summary>The flags that say the four custom arrays are RGBA floats.</summary>
    public static Mesh.ArrayFormat CustomFormats =>
        (Mesh.ArrayFormat)(((long)Mesh.ArrayCustomFormat.RgbaFloat << (int)Mesh.ArrayFormat.FormatCustom0Shift) |
                           ((long)Mesh.ArrayCustomFormat.RgbaFloat << (int)Mesh.ArrayFormat.FormatCustom1Shift) |
                           ((long)Mesh.ArrayCustomFormat.RgbaFloat << (int)Mesh.ArrayFormat.FormatCustom2Shift) |
                           ((long)Mesh.ArrayCustomFormat.RgbaFloat << (int)Mesh.ArrayFormat.FormatCustom3Shift));

    public static ArrayMesh ToMesh(Godot.Collections.Array arrays, Material material)
    {
        var mesh = new ArrayMesh();
        mesh.AddSurfaceFromArrays(Mesh.PrimitiveType.Triangles, arrays, null, null, CustomFormats);
        mesh.SurfaceSetMaterial(0, material);
        return mesh;
    }

    private static void Put(float[] a, int i, uint x, uint y, uint z, uint w)
    {
        a[i * 4] = x; a[i * 4 + 1] = y; a[i * 4 + 2] = z; a[i * 4 + 3] = w;
    }

    /// <summary>The cell UV of vertex <paramref name="v"/> (0..5) of a cell, as OpenAC's terrain shader works it out.</summary>
    private static Vector2 CornerUv(int v, uint split)
    {
        int corner = split == 0
            ? v switch { 0 => 0, 1 => 1, 2 => 2, 3 => 0, 4 => 2, _ => 3 }
            : v switch { 0 => 0, 1 => 1, 2 => 3, 3 => 1, 4 => 2, _ => 3 };
        return corner switch { 0 => new Vector2(0, 1), 1 => new Vector2(1, 1), 2 => new Vector2(1, 0), _ => new Vector2(0, 0) };
    }
}
