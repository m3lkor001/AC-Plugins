using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using AcDream.Core.Terrain;
using Godot;

namespace ACGodot.Terrain;

/// <summary>
/// Keeps the landblocks around a point loaded: meshes are built on worker threads and added on the main thread
/// a few per frame; landblocks that fall out of range are freed.
/// </summary>
public partial class TerrainStreamer : Node3D
{
    // (changed - Options > Video: what's loaded is gone over again straight away, not when you next cross into another landblock)
    private int _radius = 5;
    public int Radius { get => _radius; set { if (value == _radius) return; _radius = value; _center = (-1, -1); } }   // landblocks each way (11 x 11 around you)
    public int MaxAddsPerFrame { get; set; } = 6;
    public int Loaded => _blocks.Count;
    public int Pending => _inFlight.Count;
    /// <summary>The ground around you all built (nothing being made or waiting to be added).</summary>
    public bool Settled => _inFlight.IsEmpty && _ready.IsEmpty;

    private Dats _dats = null!;
    private TerrainTextures _tex = null!;
    private ShaderMaterial _material = null!;
    private readonly Dictionary<(int, int), MeshInstance3D?> _blocks = new();
    private readonly ConcurrentDictionary<(int, int), byte> _inFlight = new();
    private readonly ConcurrentQueue<((int, int) key, Godot.Collections.Array? arrays)> _ready = new();
    private readonly Dictionary<uint, SurfaceInfo> _surfaceCache = new();
    private readonly SemaphoreSlim _workers = new(Math.Max(1, System.Environment.ProcessorCount - 2));
    private (int, int) _center = (-1, -1);
    private readonly Dictionary<(int, int), ImageTexture> _floorMasks = new();

    /// <summary>A landblock's building-floor mask (from the object streamer): the ground isn't drawn under floors.</summary>
    public void SetFloorMask((int, int) key, byte[]? mask, int size)
    {
        if (mask == null) { _floorMasks.Remove(key); ApplyMask(key); return; }
        _floorMasks[key] = ImageTexture.CreateFromImage(Image.CreateFromData(size, size, false, Image.Format.L8, mask));
        ApplyMask(key);
    }

    private (int, int)? _maskOn;

    /// <summary>
    /// The floor mask is only used for the landblock whose building the camera is inside: from outside, the rooms
    /// show through the doorways (drawn after the openings clear the depth), so the ground needn't be cut at all.
    /// </summary>
    public void SetMaskActive((int, int)? key)
    {
        if (key == _maskOn) return;
        var was = _maskOn;
        _maskOn = key;
        if (was is { } w) ApplyMask(w);
        if (key is { } k) ApplyMask(k);
    }

    private ImageTexture? _portalTex;
    private int _portalCount, _portalInside = -1;

    /// <summary>The doorway and window openings near the camera (see ObjectStreamer.PortalsChanged).</summary>
    public void SetPortals(ImageTexture tex, int count, int inside)
    {
        _portalTex = tex; _portalCount = count; _portalInside = inside;
        SetPortalParams(_material);
        foreach (var mi in _blocks.Values)
            if (mi?.MaterialOverride is ShaderMaterial m) SetPortalParams(m);
    }

    private bool _steep;
    /// <summary>Ground too steep to walk up tinted dark red (Options > Video).</summary>
    public bool SteepTint
    {
        get => _steep;
        set
        {
            if (value == _steep) return;
            _steep = value;
            _material?.SetShaderParameter("steep_tint", value);
            foreach (var mi in _blocks.Values)
                if (mi?.MaterialOverride is ShaderMaterial m) m.SetShaderParameter("steep_tint", value);
        }
    }

    private void SetPortalParams(ShaderMaterial m)
    {
        m.SetShaderParameter("portal_data", _portalTex);
        m.SetShaderParameter("portal_count", _portalCount);
        m.SetShaderParameter("portal_inside", _portalInside);
    }

    private void ApplyMask((int, int) key)
    {
        if (!_blocks.TryGetValue(key, out var mi) || mi == null) return;
        if (_maskOn != key || !_floorMasks.TryGetValue(key, out var tex)) { mi.MaterialOverride = null; return; }
        var m = (ShaderMaterial)_material.Duplicate();
        m.SetShaderParameter("floor_mask", tex);
        m.SetShaderParameter("has_floor_mask", true);
        if (_portalTex != null) SetPortalParams(m);
        mi.MaterialOverride = m;
    }

    public void Setup(Dats dats, TerrainTextures tex)
    {
        _dats = dats; _tex = tex;
        _material = new ShaderMaterial { Shader = GD.Load<Shader>("res://shaders/terrain.gdshader") };
        _material.SetShaderParameter("terrain_tex", tex.Terrain);
        _material.SetShaderParameter("alpha_tex", tex.Alpha);
        _material.SetShaderParameter("tiling", tex.Tiling);
        _material.SetShaderParameter("steep_tint", _steep);
    }

    /// <summary>Call each frame with the camera's position.</summary>
    public void Follow(Vector3 godotPos)
    {
        var c = World.LandblockAt(godotPos);
        if (c != _center)
        {
            _center = c;
            Refresh();
        }
        for (int i = 0; i < MaxAddsPerFrame && _ready.TryDequeue(out var r); i++)
        {
            _inFlight.TryRemove(r.key, out _);
            if (!_blocks.ContainsKey(r.key)) continue;   // went out of range while it was built
            if (r.arrays == null) continue;              // no landblock there (the world's edge)
            var mi = new MeshInstance3D
            {
                Mesh = LandblockMeshes.ToMesh(r.arrays, _material),
                Position = World.ToGodot(r.key.Item1 * World.LandblockSize, r.key.Item2 * World.LandblockSize, 0),
                Name = $"LB_{r.key.Item1:X2}{r.key.Item2:X2}",
            };
            AddChild(mi);
            _blocks[r.key] = mi;
            ApplyMask(r.key);
        }
    }

    private void Refresh()
    {
        var want = new HashSet<(int, int)>();
        var (cx, cy) = _center;
        for (int dx = -Radius; dx <= Radius; dx++)
        for (int dy = -Radius; dy <= Radius; dy++)
        {
            int x = cx + dx, y = cy + dy;
            if (x < 0 || y < 0 || x > 254 || y > 254) continue;
            want.Add((x, y));
        }
        // free what's out of range
        var drop = new List<(int, int)>();
        foreach (var kv in _blocks) if (!want.Contains(kv.Key)) drop.Add(kv.Key);
        foreach (var k in drop)
        {
            _blocks[k]?.QueueFree();
            _blocks.Remove(k);
            _floorMasks.Remove(k);
        }
        // start the new ones, nearest first
        var add = new List<(int, int)>();
        foreach (var k in want) if (!_blocks.ContainsKey(k)) add.Add(k);
        add.Sort((a, b) => Dist(a).CompareTo(Dist(b)));
        foreach (var k in add)
        {
            _blocks[k] = null;
            if (!_inFlight.TryAdd(k, 0)) continue;
            var key = k;
            Task.Run(async () =>
            {
                await _workers.WaitAsync();
                try { _ready.Enqueue((key, LandblockMeshes.BuildArrays(_dats, key.Item1, key.Item2, _tex, _surfaceCache))); }
                catch (Exception ex) { GD.PushError($"landblock {key.Item1:X2}{key.Item2:X2}: {ex.Message}"); _ready.Enqueue((key, null)); }
                finally { _workers.Release(); }
            });
        }
    }

    private int Dist((int x, int y) k) => Math.Abs(k.x - _center.Item1) + Math.Abs(k.y - _center.Item2);

    /// <summary>The ground's exact height (Godot Y) at a Godot position, on the landscape's own triangles; null off the world.</summary>
    public float? GroundAt(Vector3 g)
    {
        var (x, y, _) = World.ToAc(g);
        int lx = (int)Math.Floor(x / World.LandblockSize), ly = (int)Math.Floor(y / World.LandblockSize);
        if (lx < 0 || ly < 0 || lx > 254 || ly > 254) return null;
        var block = _dats.Cell<DatReaderWriter.DBObjs.LandBlock>(((uint)lx << 24) | ((uint)ly << 16) | 0xFFFFu);
        if (block == null) return null;
        return AcDream.Core.Physics.TerrainSurface.SampleZFromHeightmap(block.Height, _tex.HeightTable, (uint)lx, (uint)ly,
            x - lx * World.LandblockSize, y - ly * World.LandblockSize);
    }

    /// <summary>The terrain height (Godot Y) at a Godot position, from the loaded landblock's heights; null if not loaded.</summary>
    public float? HeightAt(Vector3 g)
    {
        var (x, y, _) = World.ToAc(g);
        int lx = (int)Math.Floor(x / World.LandblockSize), ly = (int)Math.Floor(y / World.LandblockSize);
        var block = _dats.Cell<DatReaderWriter.DBObjs.LandBlock>(((uint)lx << 24) | ((uint)ly << 16) | 0xFFFFu);
        if (block == null) return null;
        float fx = (x - lx * World.LandblockSize) / 24f, fy = (y - ly * World.LandblockSize) / 24f;
        int ix = Math.Clamp((int)Math.Round(fx), 0, 8), iy = Math.Clamp((int)Math.Round(fy), 0, 8);
        return _tex.HeightTable[block.Height[ix * 9 + iy]];
    }
}
