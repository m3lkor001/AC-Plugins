#!/usr/bin/env python3
"""
Builds ACGodot's spawn data from ACE's world database (github.com/ACEmulator/ACE-World-16PY-Patches, AGPL data):
data/weenies.json - for each weenie the viewer may draw: its name, type, model (Setup), motion table, palettes,
                    clothing, scale, worn items and, for generators, what they spawn.
data/spawns.json  - for each landblock (hex "A9B4"), the objects placed in it:
                    [weenie, cell, x, y, z, qw, qx, qy, qz].

usage: ace_spawns.py <output data dir> <database folder>...
  the folders in order, later ones replacing earlier ones' weenies and landblocks: the full database
  (ACE-World-16PY/Database/3-Core), then the patches (ACE-World-16PY-Patches/Database/Patches)
"""
import json, os, re, sys

out, roots = sys.argv[1], sys.argv[2:]

def sql_files(root, sub):
    """The .sql files under root/sub (any depth), in name order."""
    found = []
    for dirpath, _, files in os.walk(os.path.join(root, sub)):
        found += [os.path.join(dirpath, f) for f in files if f.endswith('.sql')]
    return sorted(found)

def tuples(text):
    """Yields (table, [values...]) for every row of every INSERT in a SQL file."""
    for m in re.finditer(r"INSERT INTO `(\w+)` \(([^)]*)\)\s*VALUES\s*", text):
        table = m.group(1)
        i = m.end()
        n = len(text)
        while i < n:
            # skip to '('
            while i < n and text[i] in " \t\r\n,":
                i += 1
            if i >= n or text[i] != '(':
                break
            i += 1
            vals, cur, q = [], [], False
            while i < n:
                c = text[i]
                if q:
                    if c == "'" and i + 1 < n and text[i + 1] == "'":
                        cur.append("'"); i += 2; continue
                    if c == "\\" and i + 1 < n:
                        cur.append(text[i + 1]); i += 2; continue
                    if c == "'":
                        q = False
                    else:
                        cur.append(c)
                    i += 1; continue
                if c == "'":
                    q = True; i += 1; continue
                if c == '/' and text.startswith('/*', i):
                    i = text.index('*/', i) + 2; continue
                if c == ',':
                    vals.append(''.join(cur).strip()); cur = []; i += 1; continue
                if c == ')':
                    vals.append(''.join(cur).strip()); i += 1; break
                cur.append(c); i += 1
            yield table, vals
            # after the tuple: comment, then ',' (more) or ';' (end)
            while i < n and text[i] in " \t\r\n":
                i += 1
            if text.startswith('/*', i):
                i = text.index('*/', i) + 2
            while i < n and text[i] in " \t\r\n":
                i += 1
            if i < n and text[i] == ';':
                break

def num(v):
    if v in ('True', 'true'): return 1
    if v in ('False', 'false'): return 0
    if v == 'NULL': return None
    try:
        return int(v, 0)
    except ValueError:
        return float(v)

weenies = {}
for dirpath, _, files in [(os.path.dirname(f), None, [os.path.basename(f)]) for r in roots for f in sql_files(r, '9 WeenieDefaults')]:
    for f in files:
        if not f.endswith('.sql'): continue
        text = open(os.path.join(dirpath, f), encoding='utf-8', errors='replace').read()
        w = {}
        wid = None
        for table, v in tuples(text):
            if table == 'weenie':
                wid = num(v[0]); w['t'] = num(v[2])
            elif table == 'weenie_properties_string' and num(v[1]) == 1:
                w['n'] = v[2]
            elif table == 'weenie_properties_d_i_d':
                k, val = num(v[1]), num(v[2])
                if k == 1: w['setup'] = val
                elif k == 2: w['mt'] = val
                elif k == 3: w['snd'] = val     # SoundTable
                elif k == 6: w['pb'] = val
                elif k == 7: w['cb'] = val
                elif k == 9: w['eyes'] = val      # face textures
                elif k == 10: w['nose'] = val
                elif k == 11: w['mouth'] = val
                elif k == 18: w['head'] = val     # HeadObject
                elif k == 4: w['cmt'] = val       # CombatTable (attack moves)
                elif k == 8: w['icon'] = val      # Icon
                elif k == 35: w['dtt'] = val      # DeathTreasureType (what loot it drops)
                elif k == 15: w['hairp'] = val    # palettes
                elif k == 16: w['eyep'] = val
                elif k == 17: w['skinp'] = val
            elif table == 'weenie_properties_int':
                k, val = num(v[1]), num(v[2])
                if k == 3: w['pt'] = val
                elif k == 4: w['cp'] = val
                elif k == 81: w['gmax'] = val
                elif k == 82: w['ginit'] = val
                elif k == 25: w['lvl'] = val      # Level
                elif k == 44: w['dmg'] = val      # Damage (a weapon's)
                elif k == 45: w['dt'] = val       # DamageType (a weapon's)
                elif k == 46: w['cstyle'] = val   # DefaultCombatStyle (a weapon's)
                elif k == 1: w['it'] = val        # ItemType
                elif k == 67: w['tol'] = val      # Tolerance (who it attacks: 0 anyone in range, 1 never...)
                elif k == 146: w['xp'] = val      # XpOverride (experience for killing it)
                elif k == 19: w['val'] = val      # Value (pyreals)
                elif k == 5: w['bur'] = val       # EncumbranceVal (burden)
                elif k == 48: w['wsk'] = val      # WeaponSkill
                elif k == 49: w['wtime'] = val    # WeaponTime (speed)
                elif k == 9: w['loc'] = val       # ValidLocations (where it's worn or wielded)
                elif k == 28: w['al'] = val       # ArmorLevel
                elif k == 11: w['maxstack'] = val # MaxStackSize
                elif k == 91: w['maxstruct'] = val # MaxStructure (uses: a healing kit's, a lockpick's)
                elif k == 92: w['struct'] = val    # Structure (uses left)
                elif k == 107: w['mana'] = val     # ItemCurMana
                elif k == 108: w['maxmana'] = val  # ItemMaxMana
            elif table == 'weenie_properties_float':
                k, val = num(v[1]), num(v[2])
                if k == 12: w['sh'] = val
                elif k == 39: w['sc'] = val
                elif k == 43: w['gr'] = val
                elif k == 22: w['dvar'] = val     # DamageVariance (a weapon's)
                elif k == 31: w['var'] = val      # VisualAwarenessRange
                elif k == 41: w['regen'] = val    # RegenerationInterval (a generator's: how soon it makes another)
                elif k == 34: w['pwr'] = val      # PowerupTime (most delay between attacks)
            elif table == 'weenie_properties_bool':
                k, val = num(v[1]), num(v[2])
                if k == 18: w['vis'] = val          # Visibility (false: hidden)
                elif k == 19: w['atk'] = val        # Attackable
                elif k == 52: w['imm'] = val        # AiImmobile (never moves)
            elif table == 'weenie_properties_attribute':
                # strength, endurance, quickness, coordination, focus, self
                k = num(v[1])
                if 1 <= k <= 6:
                    w.setdefault('attr', [0] * 6)[k - 1] = (num(v[2]) or 0) + (num(v[3]) or 0)
            elif table == 'weenie_properties_attribute_2nd':
                k = num(v[1])
                if k == 1:   # MaxHealth: its current level (with endurance's share), else its base
                    w['hp'] = num(v[5]) if len(v) > 5 and num(v[5]) else (num(v[2]) or 0)
            elif table == 'weenie_properties_skill':
                # skill: its base (init_level) and ranks
                w.setdefault('sk', {})[str(num(v[1]))] = (num(v[5]) or 0) + (num(v[2]) or 0)
            elif table == 'weenie_properties_body_part':
                # key, damage type, damage, variance, armor vs slash/pierce/bludgeon/cold/fire/acid/electric/nether,
                # then how likely it's struck by a high, medium and low attack (its front and back, left and right)
                f = [num(x) or 0 for x in v[1:]]
                hi = f[14] + f[17] + f[20] + f[23]; mid = f[15] + f[18] + f[21] + f[24]; lo = f[16] + f[19] + f[22] + f[25]
                w.setdefault('bp', []).append([f[0], f[1], f[2], round(f[3], 3)] + f[5:13] + [round(hi, 3), round(mid, 3), round(lo, 3)])
            elif table == 'weenie_properties_anim_part':
                w.setdefault('ap', []).append([num(v[1]), num(v[2])])
            elif table == 'weenie_properties_palette':
                w.setdefault('pal', []).append([num(v[1]), num(v[2]), num(v[3])])
            elif table == 'weenie_properties_texture_map':
                w.setdefault('tm', []).append([num(v[1]), num(v[2]), num(v[3])])
            elif table == 'weenie_properties_create_list':
                dest = num(v[1])
                if dest is not None and dest & 2:   # wielded / worn
                    w.setdefault('wear', []).append([num(v[2]), num(v[4]) or 0, num(v[5]) or 0])
            elif table == 'weenie_properties_generator':
                # probability, wcid, delay, init, max, when, where, stack, palette, shade, cell, x, y, z, qw, qx, qy, qz
                w.setdefault('gen', []).append([num(x) if x != 'NULL' else 0 for x in v[1:]][:1] +
                                                [num(v[2]), num(v[4]), num(v[5]), num(v[7]), num(v[9]) or 0, num(v[10]) or 0,
                                                 num(v[11]) or 0, num(v[12]) or 0, num(v[13]) or 0, num(v[14]) or 0,
                                                 num(v[15]) or 1, num(v[16]) or 0, num(v[17]) or 0, num(v[18]) or 0])
        if wid is not None:
            weenies[wid] = w

# placed objects and wilderness encounters, per landblock; a later folder's landblock replaces an earlier one's
placed, encounters = {}, {}
for r in roots:
    for path in sql_files(r, '6 LandBlockExtendedData'):
        text = open(path, encoding='utf-8', errors='replace').read()
        rows = {}
        for table, v in tuples(text):
            if table != 'landblock_instance': continue
            wcid, cell = num(v[1]), num(v[2])
            x, y, z, qw, qx, qy, qz = (num(a) for a in v[3:10])
            rows.setdefault('%04X' % (cell >> 16), []).append([wcid, cell, round(x, 3), round(y, 3), round(z, 3),
                                                              round(qw, 6), round(qx, 6), round(qy, 6), round(qz, 6)])
        placed.update(rows)
    # wilderness encounters: a generator in the middle of a landscape cell, standing on the ground (z -9999)
    for path in sql_files(r, '1 RegionDescExtendedData'):
        text = open(path, encoding='utf-8', errors='replace').read()
        rows = {}
        for table, v in tuples(text):
            if table != 'encounter': continue
            lbid, wcid, cx, cy = num(v[0]), num(v[1]), num(v[2]), num(v[3])
            cell = (lbid << 16) | (cx * 8 + cy + 1)
            rows.setdefault('%04X' % lbid, []).append([wcid, cell, cx * 24 + 12, cy * 24 + 12, -9999, 1, 0, 0, 0])
        encounters.update(rows)
spawns = {}
for d in (placed, encounters):
    for lb, rows in d.items(): spawns.setdefault(lb, []).extend(rows)

# keep only weenies something can place: the instances, what generators make (recursively) and what's worn
need = set()
def want(wcid, depth=0):
    if wcid in need or wcid not in weenies or depth > 6: return
    need.add(wcid)
    w = weenies[wcid]
    for g in w.get('gen', []): want(g[1], depth + 1)
    for it in w.get('wear', []): want(it[0], depth + 1)
for lst in spawns.values():
    for s in lst: want(s[0])

# what creatures' death treasure can be (ACE's loot tables, copied into vendor/ACELoot): every weenie they name
here = os.path.dirname(os.path.abspath(__file__))
loot_src = os.path.join(here, '..', 'vendor', 'ACELoot', 'src')
if os.path.isdir(loot_src):
    names = {}
    for line in open(os.path.join(loot_src, 'WeenieClassName.cs'), encoding='utf-8'):
        m = re.match(r'\s*(\w+)\s*=\s*(\d+)\s*,', line)
        if m: names[m.group(1)] = int(m.group(2))
    for dirpath, _, files in os.walk(loot_src):
        for f in files:
            if not f.endswith('.cs') or f == 'WeenieClassName.cs': continue
            for n in re.findall(r'WeenieClassName\.(\w+)', open(os.path.join(dirpath, f), encoding='utf-8').read()):
                if n in names: want(names[n])

# death treasure profiles: treasure type -> tier, quality, then the item, magic item and mundane item chances,
# counts and kind tables (ACE's treasure_death)
treasure = {}
for r in roots:
    for path in sql_files(r, '3 TreasureTable'):
        text = open(path, encoding='utf-8', errors='replace').read()
        for table, v in tuples(text):
            if table == 'treasure_death':
                treasure[str(num(v[0]))] = [num(x) for x in v[1:16]]
json.dump(treasure, open(os.path.join(out, 'treasure.json'), 'w'), separators=(',', ':'))

os.makedirs(out, exist_ok=True)
json.dump({str(k): weenies[k] for k in sorted(need)}, open(os.path.join(out, 'weenies.json'), 'w'), separators=(',', ':'))
import gzip
with gzip.open(os.path.join(out, 'spawns.json.gz'), 'wt') as f: json.dump(spawns, f, separators=(',', ':'))
if os.path.exists(os.path.join(out, 'spawns.json')): os.remove(os.path.join(out, 'spawns.json'))
print(len(weenies), 'weenies read,', len(need), 'kept;', sum(len(l) for l in spawns.values()), 'instances in', len(spawns), 'landblocks')
