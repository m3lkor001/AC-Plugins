// A building's doorway and window openings: drawn after the landscape and the outer walls, they draw nothing but
// push the depth back to the far plane, so the rooms drawn next show through the openings even where the ground
// lies higher than a floor - the way retail opens a building's portals. Only where the opening itself is visible
// (nothing in front of it) is the depth cleared.
shader_type spatial;
render_mode unshaded, cull_disabled, depth_draw_always, blend_mix, shadows_disabled, fog_disabled;

void fragment() {
	ALBEDO = vec3(0.0);
	ALPHA = 0.0;
#if CURRENT_RENDERER == RENDERER_COMPATIBILITY
	DEPTH = 1.0;
#else
	DEPTH = 0.0;   // Forward+ / Mobile use reversed depth: the far plane is 0
#endif
}
