// A particle: its card (turned per particle), its texture tinted and faded by the particle's colour (the
// MultiMesh instance colour). Drawn after the world's solid parts, without writing depth.
shader_type spatial;
render_mode unshaded, cull_disabled, depth_draw_never, blend_add;

uniform sampler2D tex : source_color, filter_linear_mipmap, repeat_disable;

varying float near_fade;

void vertex() {
	// turned to face the camera (or not) per particle, by the instance transform
	// fade out right in front of the camera, so a particle there doesn't fill the view
	near_fade = clamp((length((MODELVIEW_MATRIX * vec4(0.0, 0.0, 0.0, 1.0)).xyz) - 0.5) / 1.5, 0.0, 1.0);
}

void fragment() {
	vec4 t = texture(tex, UV);
	ALBEDO = t.rgb * COLOR.rgb;
	ALPHA = t.a * COLOR.a * near_fade;
}
