// One layer of AC's sky (the dome, sun, moon, clouds, stars...), as retail draws it: the surface's texture
// tinted by a per-vertex light (its own glow + the sky's ambient + the sun on it), never fogged, drawn in the
// sky objects' order behind everything. Ported from OpenAC's sky shader (MIT).
shader_type spatial;
render_mode unshaded, fog_disabled, depth_draw_never, cull_disabled, blend_add;

uniform sampler2D tex : source_color, filter_linear_mipmap, repeat_disable;   // clamped: this layer neither scrolls nor tiles, so its edges mustn't pick up the far side
uniform vec3 ambient = vec3(0.5);
uniform vec3 sun_color = vec3(0.5);
uniform vec3 sun_dir = vec3(0.0, 1.0, 0.0);   // towards the sun, Godot world axes
uniform float emissive = 0.0;
uniform float diffuse = 1.0;
uniform float transparency = 0.0;             // 0 visible, 1 gone (the time of day fades layers)
uniform vec2 uv_scroll = vec2(0.0);

varying vec3 tint;

void vertex() {
	UV += uv_scroll;
	vec3 n = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
	float d = max(dot(n, sun_dir), 0.0);
	tint = clamp(vec3(emissive) + ambient + sun_color * diffuse * d, 0.0, 1.0);
}

void fragment() {
	vec4 s = texture(tex, UV);
	float a = s.a * (1.0 - transparency);
	if (a < 0.01) discard;
	ALBEDO = s.rgb * tint;
	ALPHA = a;
}
