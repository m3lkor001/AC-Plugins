@echo off
setlocal
cd /d "%~dp0"
set "ACG_DIR=%~dp0"
set "GODOT=%~dp0Godot\Godot_v4.7.2-stable_mono_win64.exe"
if exist "%GODOT%" goto :havegodot
rem Godot isn't shipped with ACGodot (it's big): fetched the first time from Godot's own releases on GitHub
echo Godot 4.7.2 .NET isn't here yet - downloading it from Godot's releases on GitHub (about 115 MB), once...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; $u='https://github.com/godotengine/godot-builds/releases/download/4.7.2-stable/Godot_v4.7.2-stable_mono_win64.zip'; $z=Join-Path $env:TEMP 'acgodot-godot-4.7.2.zip'; $t=Join-Path $env:TEMP 'acgodot-godot-4.7.2'; Invoke-WebRequest -Uri $u -OutFile $z -UseBasicParsing; if (Test-Path $t) { Remove-Item $t -Recurse -Force }; Expand-Archive -Path $z -DestinationPath $t; $g=Join-Path $env:ACG_DIR 'Godot'; New-Item -ItemType Directory -Force -Path $g | Out-Null; Copy-Item -Path (Join-Path $t 'Godot_v4.7.2-stable_mono_win64\*') -Destination $g -Recurse -Force; Remove-Item $t -Recurse -Force; Remove-Item $z -Force"
if exist "%GODOT%" goto :havegodot
echo Couldn't download Godot. Get Godot_v4.7.2-stable_mono_win64.zip from https://godotengine.org/download/archive/
echo and unzip what's in its folder (the .exe files and GodotSharp) into the Godot folder next to this file.
pause
exit /b 1
:havegodot
rem ACGodot is a .NET 10 program: Godot needs the .NET 10 runtime (or SDK) installed to run it
set "HAVE_NET="
for /f "tokens=2" %%v in ('dotnet --list-runtimes 2^>nul ^| findstr /b /c:"Microsoft.NETCore.App 10."') do set "HAVE_NET=%%v"
if defined HAVE_NET goto :havenet
echo ACGodot needs the .NET 10 runtime, and it isn't installed.
echo Opening the download page: get ".NET Runtime 10" (x64) or the .NET 10 SDK, install it, then start ACGodot again.
start "" "https://dotnet.microsoft.com/download/dotnet/10.0"
pause
exit /b 1
:havenet
start "" "%GODOT%" --path "%~dp0." %*
