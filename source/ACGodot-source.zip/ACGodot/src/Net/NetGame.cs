using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using ACGodot.Objects;
using ACGodot.UI;
using Godot;

namespace ACGodot.Net;

/// <summary>
/// Playing on a server (when it's switched on in the options): logs in, picks the character named in the settings
/// (or the first), enters the world, and from then on puts what the server sends into the game - where you are,
/// the creatures, people and things around you (drawn from the game's own data by what they are), their moves, chat
/// and the server's messages - and sends what you do: where you've moved, what you say.
/// </summary>
public partial class NetGame : Node
{
    public AcClient? Client { get; private set; }
    public ObjectStreamer Objects = null!;
    public Creatures.Player Player = null!;
    public Action<string, Color, ChatKind>? Say;
    /// <summary>Your pack and what you wear: in the world, what the server says you carry.</summary>
    public Combat.Inventory? Inv;

    private NetSettings _cfg = new();
    private uint _me;                          // our character's object id
    private readonly Dictionary<uint, ObjectStreamer.Selectable> _things = new();
    private readonly Dictionary<uint, string> _characters = new();
    private readonly HashSet<uint> _badOps = new();
    private string _account = "";
    private bool _inWorld, _placed, _teleporting;
    private int _enterTries;
    private ushort _instanceSeq, _teleportSeq, _forceSeq, _serverControlSeq;
    private double _driftAt, _arrivedSaidAt = -100; private int _driftCount, _posSnaps;
    private double _echoClock; private Vector3 _echoMe, _echoSrv; private float _mySpeed, _srvSpeed;

    // each time we were put back where the server had us: kept in logs/<character>/drift.txt (in the game's folder), run after run -
    // how often, and how fast we were going against how fast the server had us going (too fast here, and it pulls us back)

    // this character's own folder for its logs (logs/<name> in the game's folder; before one's chosen, the account's)
    public string CharLogDir()
    {
        string root = ProjectSettings.GlobalizePath("res://logs");
        System.IO.Directory.CreateDirectory(root);
        if (!System.IO.File.Exists(System.IO.Path.Combine(root, ".gdignore"))) System.IO.File.WriteAllText(System.IO.Path.Combine(root, ".gdignore"), "");
        string who = Character?.Name ?? (_myName.Length > 0 ? _myName : _cfg?.Account ?? "unknown");
        foreach (char c in System.IO.Path.GetInvalidFileNameChars()) who = who.Replace(c, '_');
        string dir = System.IO.Path.Combine(root, who);
        System.IO.Directory.CreateDirectory(dir);
        return dir;
    }
    private void DriftNote(float off)
    {
        try
        {
            string f = System.IO.Path.Combine(CharLogDir(), "drift.txt");
            if (!System.IO.File.Exists(f)) System.IO.File.WriteAllText(f, "when | who | how far off (m) | our speed here (m/s) | the server's speed for us (m/s) | stance | landblock cell | times this run\n");
            System.IO.File.AppendAllText(f, $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} | {Character?.Name ?? _myName} | {off:0.0} | {_mySpeed:0.0} | {_srvSpeed:0.0} | {_combatMode} | {_myCell:X8} | {_posSnaps}\n");
        }
        catch { }
    }
    private double _sendIn;
    private Vector3 _lastSent;
    private float _lastHeading;   // (the way we faced when the server was last told: turning on the spot is told too)
    private bool Turned => MathF.Abs(MathF.IEEERemainder(Player.Heading - _lastHeading, MathF.Tau)) > 0.03f;

    public bool InWorld => _inWorld;
    /// <summary>Told once when the connection is lost while in the world.</summary>
    public Action? ConnectionLost;
    private bool _lostSaid;

    private static readonly Color SysColor = new(1f, 0.9f, 0.4f), Speech = Colors.White, TellColor = new(1f, 1f, 0.45f);   // (a tell: the yellow the game gives an NPC's tell - the old pink was hard to read)

    public void Start(NetSettings cfg)
    {
        _cfg = cfg;
        _account = cfg.Account;
        try
        {
            Client = new AcClient(cfg.Host, cfg.Port);
            Client.Holds = a => _loggingOut && HeldWhileLeaving.Contains(a);
            Client.Login(cfg.Account, cfg.Password);
        }
        catch (Exception ex) { Say?.Invoke($"Couldn't reach {cfg.Host}:{cfg.Port}: {ex.Message}", SysColor, ChatKind.Errors); Client = null; }
    }

    public override void _ExitTree() { Client?.Dispose(); }

    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("NetGame");
        if (Client == null) return;
        while (Client.Notes.TryDequeue(out var note)) Say?.Invoke("[Network] " + note, SysColor, ChatKind.Gameplay);
        Client.Pump();
        // the connection gone while in the world (the server went down, or stopped answering): said once, and the game
        // told - it stayed in the world doing nothing, plugins healing and summoning into the void for good
        if (Client.Failed && _inWorld && !_lostSaid)
        {
            _lostSaid = true;
            GD.PrintErr($"[net] {DateTime.Now:HH:mm:ss} the connection to the server is gone - leaving the game");
            ConnectionLost?.Invoke();
        }
        int n = 0;
        while (n++ < 200 && Client.Inbox.TryDequeue(out var m))
        {
            TestTrace.Last = $"net message 0x{m.opcode:X4} ({m.payload.Length} bytes{(m.opcode == 0xF7B0 && m.payload.Length >= 12 ? $", event 0x{BitConverter.ToUInt32(m.payload, 8):X4}" : "")})";
            try { Handle(m.opcode, m.payload); }
            catch (Exception ex)
            {
                GD.PushWarning($"net message 0x{m.opcode:X4}: {ex.Message}");
                // (once per kind of message, in chat: what couldn't be read is what to fix next)
                if (_badOps.Add(m.opcode)) Say?.Invoke($"[Network] couldn't read message 0x{m.opcode:X4} ({m.payload.Length} bytes): {ex.Message}", SysColor, ChatKind.Errors);
            }
            if (RawIn != null) try { RawIn(m.opcode, m.payload); } catch (Exception ex) { GD.PushWarning("plugin server message: " + ex.Message); }
        }
        // (what was sent, likewise, for plugins: on this thread, whatever thread sent it)
        if (RawOut != null && Client != null)
        {
            Client.KeepSent = true;
            while (Client.SentLog.TryDequeue(out var o)) try { RawOut(o.op, o.payload); } catch (Exception ex) { GD.PushWarning("plugin client message: " + ex.Message); }
        }
        TestTrace.Last = "net: after messages";
        _clock += delta;
        if (_leftBehindAt > 0 && _clock >= _leftBehindAt) { _leftBehindAt = -1; DropLeftBehind(); }
        CheckGhosts();
        // (how hurt we are, as a part of our greatest health: asked every few seconds - what that greatest is can be
        // worked out from it, whatever rules of its own the server has for it)
        if (_inWorld && _me != 0 && _clock - _selfHealthAsked > 30.0) { _selfHealthAsked = _clock; QueryHealth(_me); }
        CheckInventoryComplete();
        if (_orderDumpAt > 0 && _clock >= _orderDumpAt && _inWorld) { _orderDumpAt = -1; DumpOrder("at login"); }
        for (int i = 0; i < _soon.Count; i++)
            if (_soon[i].at <= _clock) { var act = _soon[i].act; _soon.RemoveAt(i--); act(); }
        // (one of our own packs, listed before the pack itself was described: not a corpse opened; nor is anything
        // that isn't out in the world)
        if (_openContainer != 0 && (_held.TryGetValue(_openContainer, out var own) && Mine(own, out _) || !_things.ContainsKey(_openContainer))) _openContainer = 0;
        if ((_containerDirty || _invDirty) && _openContainer != 0)
        {
            _containerDirty = false;
            var inside = _held.Values.Where(h => h.Container == _openContainer).Select(ItemOf).ToList();
            ContainerShown?.Invoke(_held.TryGetValue(_openContainer, out var box) ? box.Name : "Contents", inside);
        }
        SaveUnknown();
        if (_invDirty)
        {
            // (what's in hand changed: the stance is asked again. Only then - a stack counting down, as the tapers do with
            // every spell, isn't that, and asking for the stance again before each cast upsets the cast)
            RebuildInventory();
            long hand = 0;
            if (Inv != null) foreach (var i in Inv.Worn) if (i.Guid != 0 && (i.WornAt & 0x3F00000) != 0) hand = hand * 31 + i.Guid;
            if (hand != _inHand) { _inHand = hand; _combatMode = 0; }
        }
        // where we are, to the server: twice a second while moving
        UpdateServerWalk();
        TellMovement();
        if (_inWorld && _placed && (_sendIn -= delta) <= 0)
        {
            _sendIn = 1.0;   // (about once a second while moving, as the retail client does - PacketWatch, Nov 19: retail ~1 s, ours was 0.5)
            if (Player.Position.DistanceTo(_lastSent) > 0.2f || Turned) SendPosition();
        }
    }

    // ── what the server says ──

    private void Handle(uint op, byte[] p)
    {
        var r = new BinaryReader(new MemoryStream(p));
        switch (op)
        {
            case 0xF658: CharacterList(r); if (_quitAfterOut != null) _soon.Add((_clock + 0.5, () => QuitNow())); break;
            case 0xF643: CharacterCreated(r); break;
            case 0xF7E1:   // the world's name (what plugins know the server by: their settings are kept under it)
            {
                // (how many are on, and how many it holds, come first)
                string world = "";
                try { r.ReadUInt32(); r.ReadUInt32(); world = AcClient.ReadString16L(r); } catch (Exception) { }
                if (world.Length == 0 || world.Any(ch => ch < 32)) { r.BaseStream.Position = 0; try { world = AcClient.ReadString16L(r); } catch (Exception) { world = ""; } }
                WorldName = world;
                Say?.Invoke($"[Network] World: {world}", SysColor, ChatKind.Gameplay);
                WorldNamed?.Invoke(world);
                break;
            }
            case 0xF7DF:   // ready for us to enter: the character
                using (var b = new MemoryStream())
                {
                    var w = new BinaryWriter(b);
                    w.Write(_me);
                    AcClient.WriteString16L(w, _account);
                    Client!.Send(0xF657, b.ToArray(), 4);
                }
                break;
            case 0xF653: LoggedOut(); break;   // CharacterLogOff: we're out
            case 0xF659:
            {
                uint err = r.ReadUInt32();
                // (1: the server still has the character in the world - the last client went without logging out, and
                // the server hasn't noticed yet: asked again every ten seconds for a while)
                if (err == 1 && !_inWorld && _enterTries < 9)
                {
                    _enterTries++;
                    Say?.Invoke("[Network] The server still has this account in the world (the last client didn't log out). Trying again in 15 seconds...", SysColor, ChatKind.Gameplay);
                    // (the whole login again: the server turned this one away)
                    _soon.Add((_clock + 15, () => { if (_inWorld) return; try { Client?.Dispose(); } catch { } Client = null; _listSeen = false; Start(_cfg); }));
                }
                else Say?.Invoke($"[Network] Character error 0x{err:X}", SysColor, ChatKind.Errors);
                break;
            }
            case 0xF746:   // PlayerCreate: we're in
                _me = r.ReadUInt32();
                _inWorld = true;
                _enterTries = 0;
                Client!.SendAction(0x00A1, Array.Empty<byte>());   // LoginComplete
                ACGodot.Plugins.PluginHost.MarkStaying();
                Say?.Invoke("[Network] You've entered the world.", SysColor, ChatKind.Gameplay);
                break;
            case 0xF745: CreateObject(r); break;
            case 0xF7DB:   // UpdateObject: a thing described over again - a house's hook with something hung on it takes that thing's look
            {
                long at0 = r.BaseStream.Position;
                uint ug = r.ReadUInt32();
                r.BaseStream.Position = at0;
                if (ug == _me) break;   // (ourselves: not made again here)
                bool wasSelected = _things.TryGetValue(ug, out var before) && Objects.Selected == before;
                CreateObject(r);
                if (wasSelected && _things.TryGetValue(ug, out var after)) Objects.Select(after);
                break;
            }
            case 0xF747:   // ObjectDelete
                uint gone = r.ReadUInt32();
                if (_deleted.Count > 4000) _deleted.Clear();
                _deleted.Add(gone);
                if (_things.Remove(gone, out var sel)) Objects.RemoveGroundItem(sel);
                if (_held.Remove(gone)) { _invDirty = true; _lastWord[gone] = "F747 deleted"; }
                LetGo(gone);
                foreach (uint c in _heldBy.Where(kv => kv.Value.parent == gone).Select(kv => kv.Key).ToList()) _heldBy.Remove(c);   // (its holder gone, its model with it)
                break;
            case 0xF749:   // ParentEvent: a creature takes something in hand (a monster draws its weapon)
            {
                uint parent = r.ReadUInt32(), child = r.ReadUInt32(), loc = r.ReadUInt32(), placement = r.ReadUInt32();
                if (parent != _me && _held.TryGetValue(child, out var ph) && ph.Look != 0)
                {
                    if (_things.Remove(child, out var lying)) Objects.RemoveGroundItem(lying);   // (it was on the ground: now in the hand)
                    HoldIn(child, parent, ph.Look, loc, placement);
                }
                break;
            }
            case 0xF625: LookChanged(r); break;   // ObjDescEvent
            // our numbers as they change: experience, level, credits; an attribute or skill raised
            case 0x02CF:
            {
                r.ReadByte();
                uint prop = r.ReadUInt32(); long v = r.ReadInt64();
                if (Me == null) break;
                if (prop == 1) Me.TotalXp = v; else if (prop == 2) Me.UnassignedXp = v; else break;
                StatsChanged?.Invoke();
                break;
            }
            case 0x02CE:   // PublicUpdatePropertyInt: a number of a thing's has changed (an item's uses left, its mana, its worth)
            {
                r.ReadByte();
                uint g = r.ReadUInt32(), prop = r.ReadUInt32(); int v = r.ReadInt32();
                if (!_held.TryGetValue(g, out var ph)) break;
                var pit = ph.Item;
                if (pit?.PropInts != null) pit.PropInts[(int)prop] = v;
                switch (prop)
                {
                    case 92: ph.Uses = v; if (pit != null) pit.Uses = v; break;                 // uses left (a kit, an essence recharged)
                    case 91: ph.MaxUses = v; if (pit != null) pit.MaxUses = v; break;
                    case 107: if (pit != null) pit.Mana = v; break;
                    case 108: if (pit != null) pit.MaxMana = v; break;
                    case 19: ph.Value = v; break;
                    case 5: ph.Burden = v; ph.BurdenSaid = true; break;
                    default: goto done02CE;
                }
                _invDirty = true;
                done02CE:
                break;
            }
            // ── a thing's other properties changed (the server's own among them): kept on the item, for plugins ──
            case 0x02D0:   // PublicUpdatePropertyInt64
            {
                r.ReadByte(); uint g = r.ReadUInt32(), prop = r.ReadUInt32(); long v = r.ReadInt64();
                if (_held.TryGetValue(g, out var ph) && ph.Item is { } pit) (pit.PropInt64s ??= new())[(int)prop] = v;
                break;
            }
            case 0x02D2:   // PublicUpdatePropertyBool
            {
                r.ReadByte(); uint g = r.ReadUInt32(), prop = r.ReadUInt32(); bool v = r.ReadUInt32() != 0;
                if (_held.TryGetValue(g, out var ph) && ph.Item is { } pit) (pit.PropBools ??= new())[(int)prop] = v;
                break;
            }
            case 0x02D4:   // PublicUpdatePropertyFloat
            {
                r.ReadByte(); uint g = r.ReadUInt32(), prop = r.ReadUInt32(); double v = r.ReadDouble();
                if (_held.TryGetValue(g, out var ph) && ph.Item is { } pit) (pit.PropFloats ??= new())[(int)prop] = v;
                break;
            }
            case 0x02D6:   // PublicUpdatePropertyString: a thing renamed (an essence as it's used up), or another of its words
            {
                r.ReadByte(); uint g = r.ReadUInt32(), prop = r.ReadUInt32(); string v = AcClient.ReadString16L(r);
                if (_held.TryGetValue(g, out var ph))
                {
                    if (ph.Item is { } pit) (pit.PropStrings ??= new())[(int)prop] = v;
                    if (prop == 1 && v.Length > 0) { ph.Name = v; if (ph.Item != null) ph.Item.Name = v; _invDirty = true; }
                }
                if (prop == 1 && v.Length > 0 && _things.TryGetValue(g, out var ts)) ts.Name = v;
                break;
            }
            case 0x02D9:   // PrivateUpdatePropertyInstanceID: one of ours - who's attacking us, above all
            {
                r.ReadByte(); uint prop = r.ReadUInt32(), v = r.ReadUInt32();
                if (prop == 11 && v != CurrentAttacker) { CurrentAttacker = v; AttackerChanged?.Invoke(v); }
                break;
            }
            case 0x02DA:   // PublicUpdateInstanceId: whose or where a thing is - its container, who wields it
            {
                r.ReadByte(); uint g = r.ReadUInt32(), prop = r.ReadUInt32(), v = r.ReadUInt32();
                if (!_held.TryGetValue(g, out var ph)) break;
                if (prop == 2 && ph.Container != v) { ph.Container = v; if (v != 0) ph.Wielder = 0; _invDirty = true; OrderLog($"server says {ph.Name} [{g:X8}] is now in {Named(v)}"); }
                else if (prop == 3 && ph.Wielder != v) { ph.Wielder = v; if (v != 0) ph.Container = 0; _invDirty = true; }
                break;
            }
            case 0xF7DE: TurbineChat(r); break;   // the global channels: General, Trade, LFG, Roleplay, Society, Allegiance
            case 0xF7E5: break;                   // DDD_Interrogation: which game files we have (nothing is asked of it here)
            case 0x02CD:
            {
                r.ReadByte();
                uint prop = r.ReadUInt32(); int v = r.ReadInt32();
                if (prop == 20) { CoinValue = v; InventoryChanged?.Invoke(); break; }
                if (prop == 40) { _combatMode = (uint)v; if (v <= 1) ServerPeace?.Invoke(); break; }   // (the stance, where the server changes it itself - wearing armor puts you in peace)
                if (Me == null) break;
                if (Character != null) { Character.Ints[(int)prop] = v; ApplyOwnNumbers(Character, Me); }
                if (prop == 25) Me.Level = v;   // (the server says "You are now level N!" itself)
                else if (prop == 24) Me.SkillCredits = v;
                else break;
                StatsChanged?.Invoke();
                break;
            }
            case 0x02E3:   // PrivateUpdateAttribute
            {
                r.ReadByte();
                int attr = (int)r.ReadUInt32() - 1; int ranks = (int)r.ReadUInt32(), start = (int)r.ReadUInt32();
                if (Me == null || attr < 0 || attr > 5) break;
                Me.AttributeRanks[attr] = ranks; Me.AttributeBase[attr] = start;
                if (Character != null) { Character.AttributeRanks[attr] = ranks; Character.AttributeStart[attr] = start; }   // (the character panel's base attributes)
                StatsChanged?.Invoke();
                break;
            }
            case 0x02DD:   // PrivateUpdateSkill
            {
                r.ReadByte();
                int skill = (int)r.ReadUInt32(); int ranks = r.ReadUInt16(); r.ReadUInt16(); int training = (int)r.ReadUInt32();
                if (Me == null) break;
                Me.Skills[skill] = new Combat.Character.SkillState
                {
                    Training = training >= 3 ? Combat.Character.Training.Specialized : training == 2 ? Combat.Character.Training.Trained : Combat.Character.Training.Untrained,
                    Ranks = ranks,
                };
                StatsChanged?.Invoke();
                break;
            }
            case 0xF750:   // Sound: a thing makes one of its sounds
            {
                uint g = r.ReadUInt32(), sound = r.ReadUInt32(); float volume = r.ReadSingle();
                if (_things.TryGetValue(g, out var ss)) Objects.PlayThingSound(ss, ss.Center, sound, volume);
                break;
            }
            case 0xF755:   // PlayEffect: one of a thing's named effects (a spell's glow, a portal's swirl, a level's shower of light)
            case 0xF754:   // ...or a script by its own number
            {
                uint g = r.ReadUInt32(), script = r.ReadUInt32(); float mod = op == 0xF755 ? r.ReadSingle() : 1f;
                if (g == _me) EffectPlayed?.Invoke(null, _myFxTable, script, mod, op == 0xF754);
                else if (_things.TryGetValue(g, out var fs) && !fs.Gone)
                {
                    // (its burst: where it hit - a spell in flight stops there and is seen no more, only the burst)
                    if (op == 0xF755 && script == 5) { Objects.Land(fs); if (fs.Unselectable && fs.Node != null && GodotObject.IsInstanceValid(fs.Node)) fs.Node.Visible = false; }
                    EffectPlayed?.Invoke(fs, _fxTables.TryGetValue(g, out uint ft) ? ft : 0, script, mod, op == 0xF754);
                }
                break;
            }
            case 0xF74C: Motion(r); break;
            case 0xF74E:   // VectorUpdate: someone has left the ground (a jump): the way they're thrown
            {
                uint g = r.ReadUInt32();
                var v = new System.Numerics.Vector3(r.ReadSingle(), r.ReadSingle(), r.ReadSingle());
                if (g != _me && _things.TryGetValue(g, out var js) && !js.Gone && v.Z > 0.5f) Objects.JumpThing(js, World.ToGodot(v));
                break;
            }
            case 0x02E9:   // PrivateUpdateAttribute2ndLevel: health, stamina or mana as it is now
            {
                r.ReadByte();
                uint vital = r.ReadUInt32(); int now = (int)r.ReadUInt32();
                if (vital is 2 or 4 or 6) VitalRead?.Invoke((int)vital / 2 - 1, now);
                break;
            }
            case 0x02E7:   // PrivateUpdateVital: the same, with its ranks
            {
                r.ReadByte();
                uint vital = r.ReadUInt32(); int vranks = (int)r.ReadUInt32(); r.ReadUInt32(); r.ReadUInt32(); int now = (int)r.ReadUInt32();
                if (vital is 1 or 3 or 5)
                {
                    if (Me != null) { Me.VitalRanks[((int)vital - 1) / 2] = vranks; StatsChanged?.Invoke(); }
                    VitalRead?.Invoke(((int)vital - 1) / 2, now);
                }
                break;
            }
            case 0xF74B:   // SetState: a door opened (passable) or shut
            {
                uint g = r.ReadUInt32(), state = r.ReadUInt32();
                // (a spell in flight that has hit: the server stops drawing it - NoDraw - a few seconds before it takes it away)
                if (_things.TryGetValue(g, out var hs) && hs.Unselectable && (state & 0x20) != 0) { Objects.Land(hs); if (hs.Node != null && GodotObject.IsInstanceValid(hs.Node)) hs.Node.Visible = false; }
                if (_things.TryGetValue(g, out var ds)) { if (ds.Type == 19) Objects.SetServerDoor(ds, (state & 0x4) != 0); else Objects.Physics?.SetServerThingSolid(g, (state & 0x4) == 0); }
                // hidden, or shown again (not a spell in flight that's landed - that one's gone for good)
                if (g != _me && _things.TryGetValue(g, out var vs) && !vs.Unselectable && vs.Type != 53) ShowThing(vs, !ServerHides(state));
                break;
            }
            case 0xF74A:   // PickupEvent: taken off the ground (by anyone)
            {
                uint taken = r.ReadUInt32();
                if (_things.Remove(taken, out var ts)) Objects.RemoveGroundItem(ts);
                LetGo(taken);   // (out of a creature's hand too)
                break;
            }
            case 0x0024:   // InventoryRemoveObject: no longer ours (given, sold, used up)
            {
                Answered(0);
                if (_held.TryGetValue(r.ReadUInt32(), out var h)) { _lastWord[h.Guid] = "0024 removed from inventory"; h.Container = h.Wielder = 0; h.WornAt = 0; _invDirty = true; }
                break;
            }
            case 0x0197:   // SetStackSize
            {
                r.ReadByte();
                uint g = r.ReadUInt32(); int stack = (int)r.ReadUInt32(), value = (int)r.ReadUInt32();
                Answered(0);
                if (_held.TryGetValue(g, out var h)) { h.SetStack(stack, value); _invDirty = true; }
                break;
            }
            case 0xF748: UpdatePosition(r); break;
            case 0xF751: _teleporting = true; if (!_inPortal) { _inPortal = true; PortalsEntered++; } Teleporting?.Invoke(); break;   // PlayerTeleport: the place we're put next is somewhere else (a portal, a recall)
            case 0x02BB:   // HearSpeech
            case 0x02BC:
            {
                string text = AcClient.ReadString16L(r), who = AcClient.ReadString16L(r);
                // (who said it and what kind of line it is: our own words read "You say", and a spell's words are
                // magic's - its colour, and its place among the chat window's kinds)
                uint from = 0, type = 2;
                try { from = r.ReadUInt32(); type = r.ReadUInt32(); } catch (EndOfStreamException) { }
                bool me = who.Length == 0 || (from != 0 && from == _me);
                // (an NPC's words - not a player's - are NPC chatter, a colour of their own)
                ChatColors.FromNpc = !me && from != 0 && _things.TryGetValue(from, out var spk) && spk.Kind < 3;
                try { Say?.Invoke(me ? $"You say, \"{text}\"" : $"{who} says, \"{text}\"", type == 2 ? Speech : ChatColor(type), type is 7 or 17 ? ChatKind.Magic : ChatKind.AreaChat); }
                finally { ChatColors.FromNpc = false; }
                break;
            }
            case 0xF7E0:   // ServerMessage
            {
                string text = AcClient.ReadString16L(r);
                // (a quest stamp, on Infinite Leaftide: the blue the quest tracker and its wiki pages show stamps in)
                // (the kind of line it is, which is what the game colours it by)
                uint type = 0;
                try { type = r.ReadUInt32(); } catch (EndOfStreamException) { }
                Say?.Invoke(text, text.StartsWith("You've stamped ") ? new Color(0.20f, 0.85f, 1.00f) : ChatColor(type),
                            type is 7 or 17 ? ChatKind.Magic : type is 6 or 21 or 22 ? ChatKind.Combat
                            // (a tell, and yours to someone - "You tell Bob, ..." - with the tells, both ways)
                            : type is 3 or 4 || text.StartsWith("You tell ") ? ChatKind.Tells : ChatKind.Gameplay);
                break;
            }
            case 0xF7B0: GameEvent(r); break;
            default: Unknown("message", op, p); break;
        }
    }

    private void CharacterList(BinaryReader r)
    {
        r.ReadUInt32();
        uint count = r.ReadUInt32();
        _characters.Clear();
        _deleteIn.Clear();
        _listAt = DateTime.UtcNow;
        uint pick = 0;
        var order = new List<(uint id, string name)>();
        for (uint i = 0; i < count; i++)
        {
            uint id = r.ReadUInt32();
            string name = AcClient.ReadString16L(r).TrimStart('+');
            uint deleteIn = r.ReadUInt32();   // (seconds until it's deleted: 0 if it isn't being)
            if (deleteIn > 0) _deleteIn[id] = deleteIn;
            _characters[id] = name;
            order.Add((id, name));
            if (name.Equals(_cfg.Character, StringComparison.OrdinalIgnoreCase)) pick = id;
        }
        r.ReadUInt32(); r.ReadUInt32();
        _account = AcClient.ReadString16L(r);
        _order = order;
        Say?.Invoke($"[Network] Characters: {string.Join(", ", _characters.Values)}", SysColor, ChatKind.Gameplay);
        // the character the launcher named goes straight in (the first time); otherwise - none named, or back here after
        // logging out - the list, to pick from
        bool first = !_listSeen;
        _listSeen = true;
        if (first && pick != 0) { EnterAs(pick); return; }
        PickCharacter?.Invoke(order, _account);
    }

    // (for the test bridge: each thing as the server described it)
    private readonly Dictionary<uint, string> _described = new();
    private readonly List<string> _missiles = new();
    /// <summary>The last things the server sent flying (arrows, spell bolts), as it described them.</summary>
    public IEnumerable<string> Missiles() => _missiles.AsEnumerable().Reverse();
    private readonly List<string> _myMotions = new();
    /// <summary>The last things the server had our own character do (other than stand).</summary>
    public IEnumerable<string> MyMotions() => _myMotions;
    public IEnumerable<string> Described(string nameHas) =>
        _things.Where(kv => kv.Value.Name.Contains(nameHas, StringComparison.OrdinalIgnoreCase)).Select(kv => $"{kv.Key:X8} " + (_described.TryGetValue(kv.Key, out var d) ? d : kv.Value.Name)
            + $" | drawn: type {kv.Value.Type} kind {kv.Value.Kind} key {kv.Value.Key} scale {kv.Value.Scale:0.##} {(kv.Value.Node == null ? "no node" : "node")}, feet height {kv.Value.Feet.Y:0.##} (ground {Objects.Ground?.Invoke(kv.Value.Feet)?.ToString("0.##") ?? "?"}), top {kv.Value.Top:0.##}, placement {(_placementOf.TryGetValue(kv.Key, out var pl0) ? pl0.ToString() : "none")}");

    /// <summary>The world's name as the server gives it ("" until it has, or if it gives none).</summary>
    public string WorldName = "";
    public Action<string>? WorldNamed;

    // ── what the server sent that isn't understood here: kept in logs/<character>/server-unknown.txt (in the game's folder), each kind
    //    once with how often and what it looked like - to see what a server needs that's missing ──
    private static readonly Dictionary<string, (int count, string first, string sample)> _unknown = new();
    private static double _unknownSaved; private static bool _unknownDirty;
    private void Unknown(string kind, uint id, byte[]? data)
    {
        string key = $"{kind} 0x{id:X4}";
        lock (_unknown)
        {
            if (_unknown.TryGetValue(key, out var u)) _unknown[key] = (u.count + 1, u.first, u.sample);
            else
            {
                string hex = data == null ? "" : BitConverter.ToString(data, 0, Math.Min(data.Length, 48)).Replace("-", " ") + (data.Length > 48 ? $" ... ({data.Length} bytes)" : "");
                _unknown[key] = (1, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), hex);
            }
            _unknownDirty = true;
        }
    }
    private void SaveUnknown(bool now = false)
    {
        if (!_unknownDirty || (!now && _clock - _unknownSaved < 15)) return;
        _unknownSaved = _clock; _unknownDirty = false;
        try
        {
            string dir = CharLogDir();
            var lines = new List<string> { $"What the server ({(WorldName.Length > 0 ? WorldName : _cfg?.Host ?? "?")}) sent that ACGodot doesn't understand yet - this run of the game, as of {DateTime.Now:yyyy-MM-dd HH:mm:ss}.",
                                           "kind and number | how often | first seen | how it began", "" };
            lock (_unknown) foreach (var kv in _unknown.OrderBy(k => k.Key)) lines.Add($"{kv.Key} | {kv.Value.count} | {kv.Value.first} | {kv.Value.sample}");
            System.IO.File.WriteAllLines(System.IO.Path.Combine(dir, "server-unknown.txt"), lines);
        }
        catch (Exception) { }
    }

    private bool _listSeen, _loggingOut;
    /// <summary>The account's characters, to pick one from (the character screen): each one's id and name, and the account.</summary>
    public Action<IReadOnlyList<(uint id, string name)>, string>? PickCharacter;

    private List<(uint id, string name)> _order = new();
    /// <summary>The account's characters as the server listed them (ids and names), in its order.</summary>
    public IReadOnlyList<(uint id, string name)> AccountCharacters => _order;
    private string _creating = "";
    /// <summary>Making a character came to nothing: why (shown where it was asked for).</summary>
    public Action<string>? CreateFailed;
    /// <summary>The server put us in the world (the first time for this character): what's shown can be looked at.</summary>
    public Action? Placed;
    public bool AtCharacterScreen => Client != null && _listSeen && !_inWorld;

    /// <summary>
    /// Asks the server to make a character on this account (at the character screen). What's sent is the game's own
    /// creation message: heritage, sex, looks (places in the data files' lists), a profession's attributes and skills,
    /// the name and the starting town.
    /// </summary>
    public bool CreateCharacter(NewCharacter c)
    {
        if (Client == null || _inWorld) return false;
        var ms = new MemoryStream(); var w = new BinaryWriter(ms);
        AcClient.WriteString16L(w, _account);
        w.Write(1u);
        w.Write(c.Heritage); w.Write(c.Gender);
        w.Write(c.Eyes); w.Write(c.Nose); w.Write(c.Mouth); w.Write(c.HairColor); w.Write(c.EyeColor); w.Write(c.HairStyle);
        w.Write(c.Headgear); w.Write(c.HeadgearColor);     // (0xFFFFFFFF: no headgear)
        w.Write(c.Shirt); w.Write(c.ShirtColor); w.Write(c.Pants); w.Write(c.PantsColor); w.Write(c.Shoes); w.Write(c.ShoesColor);
        w.Write(c.SkinHue); w.Write(c.HairHue); w.Write(c.HeadgearHue); w.Write(c.ShirtHue); w.Write(c.PantsHue); w.Write(c.ShoesHue);
        w.Write(c.Template);
        foreach (uint a in c.Attributes) w.Write(a);
        w.Write((uint)_order.Count);                       // the slot in the list
        w.Write(1u);                                       // class id
        w.Write((uint)c.Skills.Length);
        foreach (uint sk in c.Skills) w.Write(sk);
        AcClient.WriteString16L(w, c.Name);
        w.Write(c.StartArea);
        w.Write(0u); w.Write(0u);                          // not an admin, not a sentinel (the server decides by the account)
        _creating = c.Name;
        Say?.Invoke($"[Network] Asking the server to make {c.Name}...", SysColor, ChatKind.Gameplay);
        Client.Send(0xF656, ms.ToArray(), 4);
        return true;
    }

    private void CharacterCreated(BinaryReader r)
    {
        uint result = r.ReadUInt32();
        if (result == 1)
        {
            uint id = r.ReadUInt32();
            string name = AcClient.ReadString16L(r).TrimStart('+');
            _characters[id] = name;
            // (the same answer comes back for a character restored - one already in the list)
            bool restored = _order.Any(o => o.id == id);
            _deleteIn.Remove(id);
            if (!restored) _order.Add((id, name));
            Say?.Invoke(restored ? $"[Network] {name} was restored." : $"[Network] {name} was made.", SysColor, ChatKind.Gameplay);
            PickCharacter?.Invoke(_order, _account);
            return;
        }
        string why = result switch
        {
            2 => "The server won't make that kind of character.",
            3 => $"The name {_creating} is already taken.",
            4 => $"The server doesn't allow the name {_creating}.",
            5 => "The server turned the character down (something in it didn't add up).",
            6 => "The server's database isn't answering. Try again in a moment.",
            7 => "This account isn't allowed to make that character.",
            _ => $"The server said no (reason {result}).",
        };
        Say?.Invoke("[Network] " + why, SysColor, ChatKind.Errors);
        CreateFailed?.Invoke(why);
    }

    /// <summary>The character being entered (or in the world): its name from the character list, "" before one's picked.</summary>
    public string EnteringName => _me != 0 && _characters.TryGetValue(_me, out var n) ? n : "";

    /// <summary>Enters the world as one of the account's characters.</summary>
    private readonly Dictionary<uint, uint> _deleteIn = new();
    private DateTime _listAt;

    /// <summary>Seconds until a character on the list is deleted (Delete starts an hour's wait); -1 if it isn't being.</summary>
    public int DeletingIn(uint id) =>
        _deleteIn.TryGetValue(id, out var s) ? (int)Math.Max(0, s - (DateTime.UtcNow - _listAt).TotalSeconds) : -1;

    /// <summary>Starts deleting a character (the server keeps it an hour, restorable, then it's gone; it sends the list again).</summary>
    public bool DeleteCharacter(uint id)
    {
        int slot = _order.FindIndex(o => o.id == id);
        if (Client == null || _inWorld || slot < 0) return false;
        var ms = new MemoryStream(); var w = new BinaryWriter(ms);
        AcClient.WriteString16L(w, _account);
        w.Write((uint)slot);
        Say?.Invoke($"[Network] Deleting {_order[slot].name}...", SysColor, ChatKind.Gameplay);
        Client.Send(0xF655, ms.ToArray(), 4);   // CharacterDelete
        return true;
    }

    /// <summary>Takes back a Delete (within its hour).</summary>
    public bool RestoreCharacter(uint id)
    {
        if (Client == null || _inWorld || !_characters.ContainsKey(id)) return false;
        Client.Send(0xF7D9, BitConverter.GetBytes(id), 4);   // CharacterRestore
        return true;
    }

    public void EnterAs(uint id)
    {
        if (Client == null || _inWorld || !_characters.TryGetValue(id, out var name)) return;
        _me = id;
        _placed = false;
        CharacterKnown = false;
        Entering?.Invoke(name);
        Say?.Invoke($"[Network] Entering as {name}...", SysColor, ChatKind.Gameplay);
        Client.Send(0xF7C8, Array.Empty<byte>(), 4);   // CharacterEnterWorldRequest
    }

    /// <summary>Leaves the world for the character screen (the server takes a few seconds over it, as in the game).</summary>
    public void LogOut()
    {
        if (!_loggingOut) DumpOrder("before logout");
        if (Client == null || !_inWorld || _loggingOut) return;
        _loggingOut = true;
        ACGodot.Plugins.PluginHost.MarkLeaving();
        Say?.Invoke("[Network] Logging out...", SysColor, ChatKind.Gameplay);
        // as the game does it: out of a fighting stance first (the weapon put away), then the leaving gesture while the
        // server takes its few seconds over it
        bool fighting = LeaveCombat?.Invoke() == true;
        _soon.Add((_clock + (fighting ? 1.3 : 0.0), () =>
        {
            if (Client == null) return;
            Client.Send(0xF653, Array.Empty<byte>(), 4);   // CharacterLogOff
            SelfAction?.Invoke(0x1000011E, 1f);
            LeavingWorld?.Invoke();
        }));
    }
    private Action? _quitAfterOut;
    /// <summary>Told when the logging out has been asked of the server (the leaving gesture starting).</summary>
    public Action? LeavingWorld;
    /// <summary>Out of the world properly (the server saving the character), then the game closed once the character screen
    /// is back - or after 30 s if the server never says. Not in the world: closed straight away.</summary>
    public void LogOutThenQuit(Action quit)
    {
        if (Client == null || !_inWorld) { quit(); return; }
        if (_quitAfterOut != null) return;
        _quitAfterOut = quit;
        Say?.Invoke("[Network] Logging out, then closing the game...", SysColor, ChatKind.Gameplay);
        LogOut();
        _soon.Add((_clock + 30, () => QuitNow("the server never brought the character screen back - closing anyway")));
    }
    private void QuitNow(string? why = null)
    {
        var q = _quitAfterOut; _quitAfterOut = null;
        if (q == null) return;
        if (why != null) GD.Print("[Network] " + why);
        q();
    }
    /// <summary>Logging out (the server's few seconds over it): nothing is done meanwhile - no moving, attacking, casting or using.</summary>
    public bool LoggingOut => _loggingOut;
    // attacks, casts, uses, picking up / moving / dropping / giving items, jumping
    private static readonly HashSet<uint> HeldWhileLeaving = new() { 0x0008, 0x000A, 0x0019, 0x001A, 0x001B, 0x0035, 0x0036, 0x0048, 0x004A,
                                                                     0x0054, 0x0055, 0x0056, 0x00CD, 0xF61B };
    /// <summary>Puts us in peace mode if we're in a fighting stance; true if we were.</summary>
    public Func<bool>? LeaveCombat;

    // out of the world: what the server showed us goes (the characters' list follows, and brings the character screen)
    private void LoggedOut()
    {
        _loggingOut = false;
        _inWorld = false;
        _placed = false;
        _me = 0;
        CharacterKnown = false;
        _unanswered.Clear(); _heard.Clear(); _probed.Clear(); _looked.Clear(); _quietLook.Clear();
        foreach (var sel in _things.Values) Objects.RemoveGroundItem(sel);
        _things.Clear();
        _held.Clear(); _invFilled = false; _invDirty = false; _listed.Clear(); _relayout.Clear(); _expectPacks.Clear(); _invWaitFrom = -1; InventoryComplete = false;
        Friends.Clear(); Fellows.Clear(); FellowshipName = ""; FellowLeader = 0;
        Contracts.Clear(); _fxTables.Clear(); _setupOf.Clear();
        Say?.Invoke("[Network] Logged out.", SysColor, ChatKind.Gameplay);
    }

    private void GameEvent(BinaryReader r)
    {
        r.ReadUInt32(); r.ReadUInt32();
        uint ev = r.ReadUInt32();
        switch (ev)
        {
            case 0x0029:   // CharacterTitle: the titles we've earned, and the one shown
            {
                r.ReadUInt32();
                DisplayTitle = r.ReadUInt32();
                int n = r.ReadInt32();
                Titles.Clear();
                for (int i = 0; i < n && i < 5000; i++) Titles.Add(r.ReadUInt32());
                TitlesChanged?.Invoke();
                break;
            }
            case 0x002B:   // UpdateTitle: one earned (and shown, when it says so)
            {
                uint t = r.ReadUInt32(); bool show = r.ReadUInt32() != 0;
                if (!Titles.Contains(t)) Titles.Add(t);
                if (show) DisplayTitle = t;
                TitlesChanged?.Invoke();
                break;
            }
            case 0x021D: ReadHouseOffer(r); break;   // HouseProfile: a house's sign used - what it costs, or its upkeep
            case 0x0225: House = ReadHouse(r); HouseAnswered = true; HouseChanged?.Invoke(); break;   // HouseData: the house we own
            case 0x0226: r.ReadUInt32(); House = null; HouseAnswered = true; HouseChanged?.Invoke(); break;   // HouseStatus: we own none
            case 0x02BD:   // Tell
            {
                string text = AcClient.ReadString16L(r), who = AcClient.ReadString16L(r);
                uint teller = 0;
                try { teller = r.ReadUInt32(); } catch (EndOfStreamException) { }
                bool npcTell = teller != 0 && _things.TryGetValue(teller, out var tsel) && tsel.Kind < 3;
                if (who.Length > 0 && !npcTell) LastTeller = who;   // (for /r - a player's, not an NPC's)
                ChatColors.FromNpc = npcTell;
                try { Say?.Invoke($"{who} tells you, \"{text}\"", TellColor, ChatKind.Tells); }
                finally { ChatColors.FromNpc = false; }
                break;
            }
            case 0x0147:   // ChannelBroadcast
            {
                uint channel = r.ReadUInt32();
                string who = AcClient.ReadString16L(r), text = AcClient.ReadString16L(r);
                // (named as the game names them: a fellowship's or an allegiance's channel - the number was shown instead)
                var (cname, ckind) = channel switch
                {
                    0x800 => ("Fellow", ChatKind.Fellowship), 0x1000 => ("Vassals", ChatKind.Allegiance), 0x2000 => ("Patron", ChatKind.Allegiance),
                    0x4000 => ("Monarch", ChatKind.Allegiance), 0x1000000 => ("Covassals", ChatKind.Allegiance), 0x2000000 => ("Allegiance", ChatKind.Allegiance),
                    _ => ($"{channel:X}", ChatKind.General),
                };
                var ccolor = ckind == ChatKind.Fellowship ? new Color(1f, 1f, 0.55f) : ckind == ChatKind.Allegiance ? RoomColor(ChatKind.Allegiance) : new Color(0.55f, 0.85f, 1f);
                Say?.Invoke(who.Length == 0 ? $"[{cname}] You say, \"{text}\"" : $"[{cname}] {who} says, \"{text}\"", ccolor, ckind);
                break;
            }
            case 0x0013: PlayerDescription(r); break;   // who we are: attributes, vitals, skills...
            case 0x00C9: Appraised(r); break;   // IdentifyObjectResponse
            case 0x0062: Vendor(r); break;        // ApproachVendor
            case 0x0021:   // FriendsListUpdate: the whole list, or one friend added, removed, come or gone
            {
                int n = (int)r.ReadUInt32();
                var got = new List<Friend>();
                for (int i = 0; i < n; i++)
                {
                    var f = new Friend { Id = r.ReadUInt32(), Online = r.ReadUInt32() != 0 };
                    r.ReadUInt32();
                    f.Name = AcClient.ReadString16L(r);
                    int a = (int)r.ReadUInt32(); for (int k = 0; k < a; k++) r.ReadUInt32();
                    int b = (int)r.ReadUInt32(); for (int k = 0; k < b; k++) r.ReadUInt32();
                    got.Add(f);
                }
                uint how = r.ReadUInt32();
                if (how == 0) { Friends.Clear(); Friends.AddRange(got); }
                else foreach (var f in got)
                {
                    Friends.RemoveAll(x => x.Id == f.Id);
                    if (how != 2) Friends.Add(f);   // (2: removed)
                }
                SocialChanged?.Invoke();
                break;
            }
            case 0x0274:   // CharacterConfirmationRequest: the server wants a yes or no (swearing allegiance, a fellowship's invitation, a craft...)
            {
                uint kind = r.ReadUInt32(), context = r.ReadUInt32(); string about = AcClient.ReadString16L(r);
                if (ConfirmAsked != null) ConfirmAsked(kind, context, about); else Confirm(kind, context, false);
                break;
            }
            case 0x0276: ConfirmDone?.Invoke(); break;   // CharacterConfirmationDone: the question's off (it ran out, or was answered)
            case 0x02B4:   // SalvageOperationsResult: what salvaging came to (each material: how much, at what workmanship)
            {
                uint skill = r.ReadUInt32();
                int not = r.ReadInt32(); for (int i = 0; i < not && i < 200; i++) r.ReadUInt32();
                int n = r.ReadInt32();
                for (int i = 0; i < n && i < 50; i++)
                {
                    uint material = r.ReadUInt32(); double work = r.ReadDouble(); uint units = r.ReadUInt32();
                    string name = Materials.TryGetValue((int)material, out var mn) ? mn : $"material {material}";
                    Say?.Invoke($"You obtain {units} {name} (ws {work:0.00}) using your knowledge of {(skill == 40 ? "Salvaging" : skill == 28 ? "Weapon Tinkering" : skill == 29 ? "Armor Tinkering" : skill == 30 ? "Magic Item Tinkering" : skill == 18 ? "Item Tinkering" : "tinkering")}.", SysColor, ChatKind.Gameplay);
                }
                Salvaged?.Invoke();
                break;
            }
            case 0x0020: ReadAllegiance(r); break;   // AllegianceUpdate: our place in an allegiance (or none)
            case 0x02BE:   // FellowshipFullUpdate
            {
                Fellows.Clear();
                int n = r.ReadUInt16(); r.ReadUInt16();
                for (int i = 0; i < n; i++) Fellows.Add(ReadFellow(r));
                FellowshipName = AcClient.ReadString16L(r);
                FellowLeader = r.ReadUInt32();
                SocialChanged?.Invoke();
                break;
            }
            case 0x02C0:   // FellowshipUpdateFellow
            {
                var f = ReadFellow(r);
                int at = Fellows.FindIndex(x => x.Id == f.Id);
                if (at >= 0) Fellows[at] = f; else Fellows.Add(f);
                SocialChanged?.Invoke();
                break;
            }
            case 0x00A3: case 0x00A4:   // FellowshipQuit, FellowshipDismiss: someone's left (us: we're out of it)
            {
                uint who = r.ReadUInt32();
                if (who == _me) { Fellows.Clear(); FellowshipName = ""; FellowLeader = 0; }
                else Fellows.RemoveAll(x => x.Id == who);
                SocialChanged?.Invoke();
                break;
            }
            case 0x02BF: Fellows.Clear(); FellowshipName = ""; FellowLeader = 0; SocialChanged?.Invoke(); break;   // FellowshipDisband
            case 0x00B4:   // BookDataResponse: a book opened - how many pages, and those of them that came with it
            {
                uint book = r.ReadUInt32();
                int max = r.ReadInt32(), used = r.ReadInt32();
                r.ReadInt32();   // the most letters to a page
                int count = r.ReadInt32();
                int pages = Math.Clamp(Math.Max(used, count), 0, Math.Max(max, 0));
                BookPage?.Invoke(book, -1, pages, null);
                var have = new HashSet<int>();
                try { for (int i = 0; i < count; i++) if (ReadPage(r) is { } text) { have.Add(i); BookPage?.Invoke(book, i, pages, text); } }
                catch (Exception) { }   // (cut short or laid out some other way: the pages are asked for one by one instead)
                // the rest: each asked for (as the game does when its page is turned to)
                for (int i = 0; i < pages; i++)
                    if (!have.Contains(i)) { using var b = new MemoryStream(); var w = new BinaryWriter(b); w.Write(book); w.Write(i); Client?.SendAction(0x00AE, b.ToArray()); }
                break;
            }
            case 0x00B8:   // BookPageDataResponse: one page of it
            {
                uint book = r.ReadUInt32(); int page = r.ReadInt32();
                try { if (ReadPage(r) is { } text) BookPage?.Invoke(book, page, -1, text); } catch (Exception) { }
                break;
            }
            case 0x00A0:   // InventoryServerSaveFailed: the server wouldn't move a thing as asked - the pack goes back to what it has
            {
                uint g = r.ReadUInt32(); uint why = r.BaseStream.Position + 4 <= r.BaseStream.Length ? r.ReadUInt32() : 0; Answered(g);
                _comingOff.Remove(g);
                _invDirty = true;
                try
                {
                    string Thing(uint id) => _held.TryGetValue(id, out var t) ? $"{t.Name} x{t.Stack}/{t.MaxStack} [{id:X8}]" : id == _me ? "you" : $"{id:X8}";
                    GD.Print(_lastAsk.TryGetValue(g, out var ask)
                        ? $"[items] the server refused {Thing(g)} (reason {why:X}): asked {_clock - ask.at:0.00}s before, action {ask.action:X4} with {string.Join(", ", ask.values.Select((v, i) => i < 2 ? Thing(v) : v.ToString()))}"
                        : $"[items] the server refused {Thing(g)} (reason {why:X}): nothing was asked of it here");
                }
                catch { }
                if (why != 0) Refused(why, _held.TryGetValue(g, out var named) ? named.Name : null);
                else if (_lastAsk.TryGetValue(g, out var la) && la.action == 0x0054 && _clock - la.at < 5) { if (_held.Remove(g)) { _deleted.Add(g); _invDirty = true; } }   // (a stack put onto another that the server had already merged itself - \"Source stack not found!\", it says: the one we still showed is no more)
                else if (_quietAsk.Contains(g)) { }
                else if (!_loggingOut && _held.TryGetValue(g, out var fh)) Say?.Invoke($"The server wouldn't do that with the {fh.Name}.", SysColor, ChatKind.Gameplay);
                break;
            }
            case 0x0196:   // ViewContents: a corpse or chest opened - what's in it (the things themselves are described alongside)
            {
                // (the server lists our own side packs' contents this way too, at login: those aren't a corpse opened)
                uint box = r.ReadUInt32();
                // (a pack inside the chest that's open - clicked in its window: what's in it, the chest still the one open)
                bool subPack = _openContainer != 0 && box != _openContainer && _held.TryGetValue(box, out var sp0) && sp0.Container == _openContainer;
                // (what's in it, in the places the server keeps them: a side pack of ours is laid out in that order)
                try
                {
                    int inBox = (int)r.ReadUInt32();
                    bool ours = !_things.ContainsKey(box) && !subPack;   // (not something out in the world: a corpse's or chest's order isn't the pack's)
                    var listed = new List<uint>();
                    for (int i = 0; i < inBox && i < 400; i++) { uint g = r.ReadUInt32(); r.ReadUInt32(); if (ours) { _packOrder[g] = i; listed.Add(g); } }
                    // (that pack laid out as listed - only that one: the others keep the places since told)
                    if (ours && box != _me) { _listed[box] = listed; _invNewsAt = _clock; }
                    if (ours && inBox > 0 && box != _me) { _relayout.Add(box); _invDirty = true; OrderLog($"server listed {Named(box)}'s contents ({inBox}) - laid out as listed"); }
                }
                catch (EndOfStreamException) { }
                if (_held.TryGetValue(box, out var bh) && Mine(bh, out _)) break;
                if (!subPack) _openContainer = box;
                _containerDirty = true;
                break;
            }
            case 0x0052:   // CloseGroundContainer
                if (r.ReadUInt32() == _openContainer) { _openContainer = 0; ContainerShown?.Invoke("", null); }
                break;
            // fighting: how our blows and theirs went, as the game words them
            case 0x01B1:
            {
                string who = AcClient.ReadString16L(r); int type = (int)r.ReadUInt32(); r.ReadDouble(); uint dmg = r.ReadUInt32(); bool crit = r.ReadUInt32() != 0;
                Say?.Invoke($"{(crit ? "Critical hit! " : "")}You hit {who} for {dmg} point{(dmg == 1 ? "" : "s")} of {Combat.Rules.TypeName(type)} damage!", HitColor, ChatKind.Combat);
                break;
            }
            case 0x01B3: Say?.Invoke($"{AcClient.ReadString16L(r)} evaded your attack.", HitColor, ChatKind.Combat); break;
            case 0x01B2:
            {
                string who = AcClient.ReadString16L(r); int type = (int)r.ReadUInt32(); r.ReadDouble(); uint dmg = r.ReadUInt32(); r.ReadUInt32(); bool crit = r.ReadUInt32() != 0;
                Say?.Invoke($"{(crit ? "Critical hit! " : "")}{who} hits you for {dmg} point{(dmg == 1 ? "" : "s")} of {Combat.Rules.TypeName(type)} damage!", HurtColor, ChatKind.Combat);
                break;
            }
            case 0x01B4: Say?.Invoke($"You evaded {AcClient.ReadString16L(r)}!", HurtColor, ChatKind.Combat); break;
            case 0x01AC: case 0x01AD:   // who died, and how (0x01AD: something we killed)
            {
                string how = AcClient.ReadString16L(r);
                Say?.Invoke(how, HitColor, ChatKind.Combat);
                if (ev == 0x01AD) Killed?.Invoke(how);
                break;
            }
            case 0x01A7: AttackDone?.Invoke(); break;
            case 0x01C0:   // UpdateHealth: how hurt something is
            {
                uint g = r.ReadUInt32(); float part = r.ReadSingle();
                _unanswered.Remove(g);
                _heard[g] = _clock;
                if (g == _me) { SelfHealthPart?.Invoke(part); break; }
                if (_things.TryGetValue(g, out var hs)) HealthRead?.Invoke(hs, part);
                break;
            }
            case 0x02C1: SpellLearned?.Invoke((int)(r.ReadUInt32() & 0xFFFF), true); break;    // MagicUpdateSpell: a spell learned
            case 0x01A8: SpellLearned?.Invoke((int)(r.ReadUInt32() & 0xFFFF), false); break;   // MagicRemoveSpell: forgotten
            case 0x0314:   // SendClientContractTrackerTable: the contracts we hold
            {
                Contracts.Clear();
                int n = r.ReadUInt16(); r.ReadUInt16();
                for (int i = 0; i < n; i++) { r.ReadUInt32(); var c = ReadContract(r); Contracts[c.Id] = c; }
                ContractsChanged?.Invoke();
                break;
            }
            case 0x0315:   // SendClientContractTracker: one taken, moved on or given up
            {
                var c = ReadContract(r);
                bool gone = r.ReadUInt32() != 0;
                if (gone) Contracts.Remove(c.Id); else Contracts[c.Id] = c;
                ContractsChanged?.Invoke();
                break;
            }
            case 0x02C2: Enchantment(r); break;   // MagicUpdateEnchantment: a spell on us
            case 0x02C4: { int n = r.ReadInt32(); for (int i = 0; i < n; i++) Enchantment(r); break; }
            case 0x02C3: case 0x02C7:   // MagicRemoveEnchantment, MagicDispelEnchantment
            { int sp = r.ReadUInt16(); int ly = r.ReadUInt16(); if (sp < 0x8000) global::ACGodot.DebugLogs.Print($"[ench] {DateTime.Now:HH:mm:ss} server: {(ev == 0x02C7 ? "dispelled" : "ended")} spell {sp} layer {ly}"); Unenchanted(sp, ly); break; }
            case 0x02C5: case 0x02C8:   // ...several
            { int n = r.ReadInt32(); for (int i = 0; i < n; i++) { int sp = r.ReadUInt16(); int ly = r.ReadUInt16(); if (sp < 0x8000) global::ACGodot.DebugLogs.Print($"[ench] {DateTime.Now:HH:mm:ss} server: {(ev == 0x02C8 ? "dispelled" : "ended")} spell {sp} layer {ly} (one of {n})"); Unenchanted(sp, ly); } break; }
            case 0x0022:   // InventoryPutObjInContainer: into a pack (ours, when the pack is)
            {
                uint g = r.ReadUInt32(), into = r.ReadUInt32(); Answered(g);
                _comingOff.Remove(g);
                if (_held.TryGetValue(g, out var h)) { _lastWord[g] = $"0022 put in {into:X8}"; h.Container = into; h.Wielder = 0; h.WornAt = 0; _invDirty = true;
                    // (and the place in that pack it was put at: kept, so the pack shows it there)
                    try
                    {
                        int place = r.ReadInt32(); if (!h.IsPack && place >= 0) _placedAt[g] = place;
                        // (a side pack's listing kept as the server now has it: out of where it was, in at its place here)
                        if (!h.IsPack && place >= 0)
                        {
                            foreach (var l in _listed.Values) l.Remove(g);
                            if (_listed.TryGetValue(into, out var li)) li.Insert(Math.Min(place, li.Count), g);
                        }
                        if (into == _me || _held.TryGetValue(into, out var ih) && Mine(ih, out _))
                            OrderLog($"server put {h.Name} [{g:X8}] in {Named(into)} at {place}" +
                                     (_lastAsk.TryGetValue(g, out var ak) && _clock - ak.at < 15 ? $" (asked {ak.action:X4}{(ak.action == 0x0019 && ak.values.Length > 2 ? " at " + ak.values[2] : "")}, {_clock - ak.at:0.0}s before)" : " (not asked here)"));
                    }
                    catch { } }
                if (_things.Remove(g, out var gs)) Objects.RemoveGroundItem(gs);
                break;
            }
            case 0x0023:   // WieldObject: worn or wielded by us
            {
                uint g = r.ReadUInt32(); int at = r.ReadInt32(); Answered(g);
                if (_held.TryGetValue(g, out var h)) { h.Container = 0; h.Wielder = _me; h.WornAt = at; _invDirty = true; }
                if (_things.Remove(g, out var gs)) Objects.RemoveGroundItem(gs);
                break;
            }
            case 0x019A:   // InventoryPutObjectIn3D: out of our hands into the world
            {
                Answered(0);
                if (_held.TryGetValue(r.ReadUInt32(), out var h)) { _lastWord[h.Guid] = "019A put in the world"; h.Container = h.Wielder = 0; h.WornAt = 0; _invDirty = true; }
                break;
            }
            case 0x028A: Answered(0); Refused(r.ReadUInt32()); break;   // WeenieError
            case 0x01C7:   // UseDone: what was asked (a use, a cast) is over - and why, if it didn't come off
                uint whyNot = r.ReadUInt32();
                Refused(whyNot);
                if (whyNot != 0) UseFailed?.Invoke();
                UseDone?.Invoke();
                break;
            case 0x028B:   // WeenieErrorWithString
            {
                uint err = r.ReadUInt32(); string about = AcClient.ReadString16L(r);
                // (the fellowship opened or closed: the button follows what the server says)
                if (err is 0x050B or 0x050C) { FellowshipOpen = err == 0x050B; SocialChanged?.Invoke(); }
                string said = err switch
                {
                    0x051B => $"You have entered the {about} channel.",
                    0x051C => $"You have left the {about} channel.",
                    0x050B => $"{about} is now an open fellowship; anyone may recruit new members.",
                    0x050C => $"{about} is now a closed fellowship.",
                    0x050D => $"{about} is now the leader of this fellowship.",
                    0x050E => $"You have passed leadership of the fellowship to {about}.",
                    0x04FF => $"{about} is already at full health!",
                    _ => UnknownError(err, about),
                };
                Say?.Invoke(said, SysColor, err is >= 0x050B and <= 0x050E ? ChatKind.Fellowship : ChatKind.Gameplay);
                break;
            }
            case 0x0295:   // SetTurbineChatChannels: the global channels' numbers (allegiance and society ones are ours)
            {
                uint alleg = r.ReadUInt32(), gen = r.ReadUInt32(), trade = r.ReadUInt32(), lfg = r.ReadUInt32(), rp = r.ReadUInt32(), olthoi = r.ReadUInt32(), soc = r.ReadUInt32();
                _rooms.Clear();
                void Room(uint id, string name, ChatKind k) { if (id != 0) _rooms[id] = (name, k); }
                Room(alleg, "Allegiance", ChatKind.Allegiance); Room(gen, "General", ChatKind.General); Room(trade, "Trade", ChatKind.Trade);
                Room(lfg, "LFG", ChatKind.LFG); Room(rp, "Roleplay", ChatKind.Roleplay); Room(olthoi, "Olthoi", ChatKind.General); Room(soc, "Society", ChatKind.Society);
                break;
            }
            case 0x01B8: break;   // CombatCommenceAttack (the power bar's start, retail's: ours keeps its own)
            case 0x01C8: break;   // AllegianceUpdateDone
            case 0x01C9: break;   // FellowshipUpdateDone
            case 0x027A: break;   // AllegianceLoginNotification (a member came on: retail showed nothing either)
            default: Unknown("game event", ev, ((MemoryStream)r.BaseStream).ToArray()); break;
            case 0x02EB: { string t = AcClient.ReadString16L(r); if (Status != null) Status(t); else Say?.Invoke(t, SysColor, ChatKind.Gameplay); break; }   // a passing message ("You must remove your...")
        }
    }

    // ModelData: how a thing is coloured, textured and which of its parts are swapped (clothes, a face)
    private static (uint palBase, List<(uint id, int offset, int length)> subPals, List<(int index, uint oldTex, uint newTex)> texMaps, List<(int index, uint gfx)> partSwaps) ReadModel(BinaryReader r)
    {
        r.ReadByte();
        int pals = r.ReadByte(), texs = r.ReadByte(), anims = r.ReadByte();
        // (ids are sent without their kind's top byte: palettes 04, textures 05, models 01; palette ranges in eights)
        uint palBase = pals > 0 ? AcClient.ReadPackedDword(r) | 0x04000000u : 0;
        var subPals = new List<(uint id, int offset, int length)>();
        var texMaps = new List<(int index, uint oldTex, uint newTex)>();
        var partSwaps = new List<(int index, uint gfx)>();
        for (int i = 0; i < pals; i++) { uint id = AcClient.ReadPackedDword(r) | 0x04000000u; int off = r.ReadByte() * 8, len = r.ReadByte() * 8; subPals.Add((id, off, len == 0 ? 2048 : len)); }
        for (int i = 0; i < texs; i++) { int idx = r.ReadByte(); uint o = AcClient.ReadPackedDword(r) | 0x05000000u, n = AcClient.ReadPackedDword(r) | 0x05000000u; texMaps.Add((idx, o, n)); }
        for (int i = 0; i < anims; i++) { int idx = r.ReadByte(); partSwaps.Add((idx, AcClient.ReadPackedDword(r) | 0x01000000u)); }
        AcClient.Align(r);
        return (palBase, subPals, texMaps, partSwaps);
    }

    // our own body as the server made it (kept: a change of clothes sends only the look, not the body)
    private uint _mySetup, _myMotionTable, _myItemType, _myWhat, _myWcid;
    private float _myScale = 1f;
    private string _myName = "";

    // ObjDescEvent: someone's look has changed (ours: what we wear or wield)
    private void LookChanged(BinaryReader r)
    {
        uint guid = r.ReadUInt32();
        if (guid != _me) { OthersLookChanged(guid, r); return; }
        if (_mySetup == 0) return;
        var (palBase, subPals, texMaps, partSwaps) = ReadModel(r);
        int look = LookFor(_myWcid, _myName, _mySetup, _myMotionTable, _myScale, palBase, subPals, texMaps, partSwaps, _myItemType, _myWhat);
        if (look != (int)_myWcid) Player.SetLook(look);
    }

    // another player as the server first described them (what their look is made from), and the look they have now
    private readonly Dictionary<uint, (uint wcid, string name, uint setup, uint motionTable, float scale, uint itemType, uint what, uint sound, int look)> _made = new();

    // another player has put something on or taken it off: they're shown again in their new look, where they stand
    private void OthersLookChanged(uint guid, BinaryReader r)
    {
        if (!_made.ContainsKey(guid) || !_madeRest.TryGetValue(guid, out var rest) || !_things.TryGetValue(guid, out var old) || old.Corpse) return;
        // made again the way they were first made - the server's description of them, with the new look in the old
        // one's place - where they stand now (put in on their own they came out unseen)
        long from = r.BaseStream.Position;
        ReadModel(r);
        int n = (int)(r.BaseStream.Position - from);
        if (r.BaseStream is not MemoryStream src) return;
        var again = new byte[4 + n + rest.Length];
        BitConverter.GetBytes(guid).CopyTo(again, 0);
        Array.Copy(src.ToArray(), (int)from, again, 4, n);
        rest.CopyTo(again, 4 + n);
        bool selected = Objects.Selected == old;
        var where = _where.TryGetValue(guid, out var w0) ? w0 : default;
        _putAt = (old.Feet, old.Yaw);
        try { using var ms = new MemoryStream(again); using var mr = new BinaryReader(ms); CreateObject(mr); }
        finally { _putAt = null; }
        if (where.cell != 0) _where[guid] = where;
        if (_things.TryGetValue(guid, out var sel) && sel != old)
        {
            // (standing as they were, not doing again what they were at when first seen)
            Objects.SetThingMotion(sel, 0x8000003D, 0x41000003, 1f, Array.Empty<(uint, float)>());
            if (selected) Objects.Select(sel);
        }
    }
    private readonly Dictionary<uint, byte[]> _madeRest = new();   // a player's first description, from after their look
    private (Vector3 feet, float yaw)? _putAt;

    /// <summary>Whether a thing in the world is the server's and can be picked up (not fixed in place, not a creature).</summary>
    /// <summary>How near the server wants you before it lets you pick a thing up or use it (its own figure, or the usual 0.6).</summary>
    public float Reach(ObjectStreamer.Selectable sel) => sel.Item is NetObject no && _held.TryGetValue(no.Guid, out var h) && h.UseRadius > 0f ? h.UseRadius : 0.6f;
    /// <summary>Someone's pet (a summoned creature: the server names its owner), not a person of the place.</summary>
    /// <summary>A player in our allegiance, as far as we know it (our monarch, patron and vassals).</summary>
    public bool InMyAllegiance(ObjectStreamer.Selectable sel)
    {
        if (sel.Kind < 3 || sel == Objects.Self || string.IsNullOrEmpty(sel.Name)) return false;
        // anyone with the same monarch (theirs learned by looking them over)
        if (Monarch != null && _monarchOf.TryGetValue(sel.Name, out var theirs) && theirs.Length > 0)
            return string.Equals(theirs, Monarch.Name, StringComparison.OrdinalIgnoreCase);
        bool Is(AllegianceMember? m) => m != null && (m.Name == sel.Name || (sel.Item is NetObject no && no.Guid == m.Id));
        if (Is(Monarch) || Is(Patron)) return true;
        foreach (var v in Vassals) if (Is(v)) return true;
        return false;
    }

    public bool IsPet(ObjectStreamer.Selectable sel) => sel.Item is NetObject no && (_pets.Contains(no.Guid) || _held.TryGetValue(no.Guid, out var h) && h.PetOwner != 0);
    private readonly HashSet<uint> _pets = new();   // (creatures the server described with an owner)
    private readonly Dictionary<uint, int> _levels = new();
    /// <summary>A creature's or player's level as the server told it when it was looked at (0: not looked at yet).</summary>
    public int LevelOf(ObjectStreamer.Selectable sel) => sel.Guid != 0 && _levels.TryGetValue(sel.Guid, out int l) ? l : 0;
    public bool CanCarry(ObjectStreamer.Selectable sel) => sel.Item is NetObject no && _held.TryGetValue(no.Guid, out var h) && !h.Stuck;
    /// <summary>Uses a thing of the server's (a door, an NPC, a portal...): what comes of it is the server's to say.</summary>
    public bool Use(ObjectStreamer.Selectable sel)
    {
        uint g = GuidOf(sel);
        if (g == 0 || !_inWorld || Client == null) return false;
        StoppedFirst();
        HereFirst();
        Client.SendAction(0x0036, BitConverter.GetBytes(g));
        return true;
    }
    /// <summary>Picks a thing of the server's up off the ground, into the pack.</summary>
    public bool PickUp(ObjectStreamer.Selectable sel)
    {
        if (!CanCarry(sel)) return false;
        // (stopped and where we are, told first - the stop from the run up to it said after the pick-up, ACE took it
        // for us walking off and cancelled the pick-up: "ActionCancelled", and nothing came)
        StoppedFirst();
        HereFirst();
        ItemAction(0x0019, GuidOf(sel), _me, 0);
        return true;
    }

    /// <summary>An object coming into view: its look data skipped, its physics read for where it is, its name and kind.</summary>
    private void CreateObject(BinaryReader r)
    {
        uint guid = r.ReadUInt32();
        var (palBase, subPals, texMaps, partSwaps) = ReadModel(r);
        long afterLook = r.BaseStream.Position;
        // PhysicsData
        uint pf = r.ReadUInt32();
        uint physState = r.ReadUInt32();
        byte[]? moving = null;
        if ((pf & 0x10000) != 0) { uint len = r.ReadUInt32(); if (len > 0) { moving = r.ReadBytes((int)len); r.ReadUInt32(); } }
        uint placement = 0;
        // (how it's held, when held; how it stands, on the ground - 0 its default frame: a Boundary Marker's lantern up
        // on its post, where the mesh made "resting" laid it on the grass)
        if ((pf & 0x10000) == 0 && (pf & 0x20000) != 0) placement = r.ReadUInt32();
        bool hasPos = (pf & 0x8000) != 0;
        uint cell = 0; System.Numerics.Vector3 local = default; System.Numerics.Quaternion rot = System.Numerics.Quaternion.Identity;
        if (hasPos)
        {
            cell = r.ReadUInt32();
            local = new(r.ReadSingle(), r.ReadSingle(), r.ReadSingle());
            float qw = r.ReadSingle(), qx = r.ReadSingle(), qy = r.ReadSingle(), qz = r.ReadSingle();
            rot = new System.Numerics.Quaternion(qx, qy, qz, qw);
        }
        uint motionTable = (pf & 0x2) != 0 ? r.ReadUInt32() : 0;
        uint soundTable = (pf & 0x800) != 0 ? r.ReadUInt32() : 0;
        uint effectTable = (pf & 0x1000) != 0 ? r.ReadUInt32() : 0;
        uint setupId = (pf & 0x1) != 0 ? r.ReadUInt32() : 0;
        bool parented = (pf & 0x20) != 0;
        uint parentGuid = 0, parentLoc = 0;
        if (parented) { parentGuid = r.ReadUInt32(); parentLoc = r.ReadUInt32(); }
        if ((pf & 0x40) != 0) { int c = r.ReadInt32(); for (int i = 0; i < c; i++) { r.ReadUInt32(); r.ReadUInt32(); } }
        float objScale = (pf & 0x80) != 0 ? r.ReadSingle() : 1f;
        if ((pf & 0x100) != 0) r.ReadSingle();
        if ((pf & 0x200) != 0) r.ReadSingle();
        float translucency = (pf & 0x40000) != 0 ? r.ReadSingle() : 0f;
        System.Numerics.Vector3 velocity = default, omega = default;
        if ((pf & 0x4) != 0) velocity = new(r.ReadSingle(), r.ReadSingle(), r.ReadSingle());
        if ((pf & 0x8) != 0) { r.ReadSingle(); r.ReadSingle(); r.ReadSingle(); }
        if ((pf & 0x10) != 0) omega = new(r.ReadSingle(), r.ReadSingle(), r.ReadSingle());
        uint effect = (pf & 0x2000) != 0 ? r.ReadUInt32() : 0;
        float effectStrength = (pf & 0x4000) != 0 ? r.ReadSingle() : 0f;
        ushort posSeq = r.ReadUInt16(); r.ReadUInt16(); r.ReadUInt16(); r.ReadUInt16();
        ushort teleSeq = r.ReadUInt16(), serverCtl = r.ReadUInt16(), forceSeq = r.ReadUInt16(); r.ReadUInt16();
        ushort instSeq = r.ReadUInt16();
        AcClient.Align(r);
        // WeenieDesc: its name and kind, whose it is, what it weighs
        Held held;
        try { held = ReadHeader(r, guid, false); }
        catch (EndOfStreamException) { return; }
        string name = held.Name; uint wcid = (uint)held.Wcid, itemType = (uint)held.ItemType, what = held.What;
        TestTrace.Last = $"create object {name} (wcid {wcid}, {guid:X8})";
        if (held.PetOwner != 0) _pets.Add(guid); else _pets.Remove(guid);
        if (guid != _me && itemType != 0x10)   // (not creatures)
        {
            if (_held.TryGetValue(guid, out var was))
            {
                held.Item = was.Item;
                if (was.Container != held.Container || was.Wielder != held.Wielder) _lastWord[guid] = $"described again (was container {was.Container:X8} wielder {was.Wielder:X8})";
            }
            _held[guid] = held;
            _invDirty = true;
        }
        // how it looks is what the server says (its model, colours, clothes and face all worked out there), under a
        // look number of our own - not what the game's files alone would make of its kind
        bool posedOnGround = (pf & 0x10000) == 0 && (pf & 0x20000) != 0 && !parented && (physState & 0x40) == 0;   // (not in flight: a missile's pose is its own business)
        int look = LookFor(wcid, name, setupId, motionTable, objScale, palBase, subPals, texMaps, partSwaps, itemType, what, soundTable, posedOnGround ? (int)placement : -1);
        // (an item: kept with it - in the hand it's drawn as the server describes it, not as the game's files have its kind,
        // which don't know a server's own weapons at all)
        if (guid != _me && itemType != 0x10 && setupId != 0 && _held.TryGetValue(guid, out var lh)) { lh.Look = look; if (lh.Item != null) lh.Item.Look = look; }
        if ((what & 0x8) != 0 && guid != _me)
        {
            _made[guid] = (wcid, name, setupId, motionTable, objScale, itemType, what, soundTable, look);   // (another player: their look can change)
            if (_putAt == null && r.BaseStream is MemoryStream whole)
            {
                _madeRest[guid] = whole.ToArray()[(int)afterLook..];
            }
        }
        _described[guid] = $"{name}: wcid {wcid}, setup {setupId:X8}, motion table {motionTable:X8}, effects table {effectTable:X8}, script {effect:X} x{effectStrength:0.##}, " +
                           $"physics flags {pf:X} state {physState:X}, scale {objScale:0.###}, kind {itemType:X} what {what:X}, look {look}, palettes {subPals.Count} (base {palBase:X}), textures {texMaps.Count}, parts swapped {partSwaps.Count}" +
                           (partSwaps.Count > 0 ? " [" + string.Join(" ", partSwaps.Take(40).Select(p => $"{p.index}:{p.gfx:X8}")) + "]" : "");
        if (guid == _me)
        {
            _mySoundTable = soundTable;
            _mySetup = setupId; _myMotionTable = motionTable; _myScale = objScale; _myItemType = itemType; _myWhat = what; _myWcid = wcid; _myName = name;
            // (described again with a new place - a recall the server does this way: through a portal, as far as the server
            // knows, so it waits to hear we've arrived; told nothing, it took nothing more from us - a door wouldn't open)
            bool arrived = _placed && hasPos && (teleSeq != _teleportSeq || _teleporting || Godot(cell, local).DistanceTo(Player.Position) > 50f);
            _instanceSeq = instSeq; _teleportSeq = teleSeq; _forceSeq = forceSeq; _serverControlSeq = serverCtl;
            _myFxTable = effectTable;
            Player.SetEffect(effectTable, effect, effectStrength);
            if (look != (int)wcid) Player.SetLook(look);
            if (hasPos) PlaceMe(cell, local, rot);
            if (arrived)
            {
                _teleporting = false;
                PosLog("described again somewhere else (a recall) - telling the server we've arrived");
                SayArrived();
            }
            return;
        }
        _seen++;
        // (its effects table - or, given none, its setup: the table the setup itself names is then the one to use, as
        // the game does. A spell's bolt has no table of its own, and its own bursts are in its setup's)
        if (setupId != 0) _setupOf[guid] = setupId;
        if (soundTable != 0) _soundOf[guid] = soundTable; else _soundOf.Remove(guid);
        if (effectTable != 0) _fxTables[guid] = effectTable; else if (setupId != 0 && guid != _me && (what & 0x8) == 0) _fxTables[guid] = setupId; else _fxTables.Remove(guid);
        // held by a creature (a monster's weapon, a pet's): drawn in its hand
        if (parented && parentGuid != _me && setupId != 0) HoldIn(guid, parentGuid, look, parentLoc, placement);
        if (!hasPos || parented) { _carried++; return; }   // in someone's pack or hand: not on the ground
        var feet = Godot(cell, local);
        float yaw = 2f * MathF.Atan2(rot.Z, rot.W);
        if (_putAt is { } pa) { feet = pa.feet; yaw = pa.yaw; }   // (made again for a new look: where they stand now)
        if (_things.Remove(guid, out var old)) Objects.RemoveGroundItem(old);
        _where[guid] = (cell, local, yaw);
        TestTrace.Last = $"showing {name} (wcid {wcid}, look {look})";
        var sel = Objects.AddGroundItem(new NetObject(guid, name, (int)wcid), look, name, feet, yaw, alive: true);
        // in flight (an arrow, a spell's bolt): it flies on from here at the speed given - one with nothing to draw
        // (a bolt is all particles) as a glowing ball
        bool missile = (physState & 0x40) != 0 && velocity.LengthSquared() > 0.01f;
        if (sel == null && missile) sel = Objects.AddGlow(name, feet, GlowOf(name));
        // (a spell's bolt is little or nothing but the particles its setup starts with: played on it as it flies)
        // (and nothing in flight is ever selected - a spell's bolts least of all)
        if (missile && sel != null) sel.Unselectable = true;
        if (missile && sel != null && setupId != 0) EffectPlayed?.Invoke(sel, setupId, 0, 1f, true);
        if (missile)
        {
            // (kept a while, for working out why one is drawn as it is: they're gone in a second)
            _missiles.Add($"{DateTime.Now:HH:mm:ss} {(_described.TryGetValue(guid, out var md) ? md : name)} | {(sel == null ? "nothing drawn" : sel.Node == null ? "a glow" : "its model")}" +
                          (sel != null ? $", r {sel.Radius:0.##} h {sel.Top - sel.Feet.Y:0.##}, node {(sel.Node == null ? "none" : sel.Node.Visible ? "shown" : "hidden")} scale {sel.Scale:0.##}, speed {velocity.Length():0.#}" : ""));
            if (_missiles.Count > 40) _missiles.RemoveAt(0);
        }
        TestTrace.Last = $"shown {name}; its state";
        if (sel != null)
        {
            _things[guid] = sel;
            _heard[guid] = _clock;
            // (what it holds, told before it was shown)
            foreach (var kv in _heldBy.Where(kv => kv.Value.parent == guid && (kv.Value.node == null || !GodotObject.IsInstanceValid(kv.Value.node))).ToList())
                HoldIn(kv.Key, guid, kv.Value.look, kv.Value.loc, kv.Value.placement);
            sel.Guid = guid; sel.Cell = (cell & 0xFFFF) >= 0x100 ? cell : 0;
            sel.Desc = what;
            // scenery: not a creature, stuck where it is, no use (Useable none or "no"), and not a door, chest, portal,
            // lifestone, bindstone, book ... - or hidden from the interface (0x80)
            sel.Scenery = itemType != 0x10 && (what & 0x2008) == 0 && ((what & 0x80) != 0 ||
                          (what & 0x4) != 0 && held.Useable <= 1 && (what & (0x1u | 0x2u | 0x100u | 0x200u | 0x1000u | 0x4000u | 0x8000u | 0x10000u | 0x20000u | 0x40000u | 0x8000000u)) == 0);
            // another player (the server says so of them): not a monster, and not an NPC - 3; a player killer 4, a PK-lite one 5
            if ((what & 0x8) != 0) sel.Kind = (what & 0x20) != 0 ? 4 : (what & 0x2000000) != 0 ? 5 : 3;
            // not upright (a notice board hung on a wall): turned as the server has it, not only faced
            if (!missile && itemType != 0x10 && (MathF.Abs(rot.X) > 0.05f || MathF.Abs(rot.Y) > 0.05f)) Objects.TiltThing(sel, System.Numerics.Quaternion.Normalize(rot));
            // (set down in one of its poses - on a house's hook: a weapon flat against the wall, handle down)
            if ((pf & 0x10000) == 0 && (pf & 0x20000) != 0) _placementOf[guid] = placement; else _placementOf.Remove(guid);
            if (!missile && itemType != 0x10 && (pf & 0x10000) == 0 && (pf & 0x20000) != 0) try { Objects.SetPlacement(sel, placement); } catch (Exception ex) { GD.PushWarning("placement: " + ex.Message); }
            // (not lifted to sit on the ground by its lowest point - things set into it, a lifestone's base, were left
            // hovering; the Boundary Marker that seemed to need it was the pose turned twice, since put right)
            // (see-through, as the server has it: a ghost, a wisp; and turning round of itself: a spinning gem)
            if (translucency > 0.01f) Objects.SeeThrough(sel, translucency);
            if (!missile && MathF.Abs(omega.Z) > 1e-3f) Objects.SpinThing(sel, omega.Z);
            // not drawn: a house's own object (the building is the landscape's; this one stood in its doorway as a little model of it)
            if (sel.Type == 53 && sel.Node != null && GodotObject.IsInstanceValid(sel.Node)) sel.Node.Visible = false;
            // not drawn either: what the server says isn't to be (NoDraw, Hidden - an empty house hook, someone in portal
            // space, a cloaked admin); shown again when it says so
            else if (ServerHides(physState)) ShowThing(sel, false);
            if (missile) Objects.Fly(sel, World.ToGodot(velocity), (physState & 0x400) != 0);
            else if ((what & 0x2000) != 0) { sel.Corpse = true; Objects.LayDead(sel); }   // a corpse
            else if ((physState & 0x4) != 0 && sel.Type == 19) Objects.SetServerDoor(sel, true);    // a door standing open
            // what a body bumps into: creatures and people (not other players), and things that stay where they are
            // (doors, chests, forges, lifestones) - unless it's one that's walked through
            bool creature = itemType == 0x10;
            if (!missile && (what & 0x2008) == 0 && sel.Type != 53 && (creature || (what & 0x4) != 0 || sel.Type == 19) && Objects.Physics != null)
            {
                int lx = (int)(cell >> 24), ly = (int)((cell >> 16) & 0xFF);
                Objects.Physics.AddServerThing(guid, setupId, motionTable, creature ? 0 : 1, objScale,
                    new System.Numerics.Vector3(lx * World.LandblockSize + local.X, ly * World.LandblockSize + local.Y, local.Z), rot, cell, (physState & 0x4) == 0, $"{name} state {physState:X}");
            }
            // what it was doing when we came upon it (walking, in a fighting stance, lying dead)
            if (moving != null && !missile && sel.Type != 19 && (what & 0x2000) == 0)
                try { using var ms = new MemoryStream(moving); using var mr = new BinaryReader(ms); ApplyMovement(mr, sel); }
                catch (Exception) { }
        }
        else if (_notShown.Count < 60) _notShown.Add($"{name} (wcid {wcid}, cell {cell:X8})");
    }

    /// <summary>
    /// A thing's header (ACE's SerializeCreateObject, in its order): name, kind, icon, what it is and does, then
    /// whatever of the rest it has - read as far as what it weighs, or (whole) to its end, where the next thing starts.
    /// </summary>
    private static Held ReadHeader(BinaryReader r, uint guid, bool whole)
    {
        uint wf = r.ReadUInt32();
        string name = AcClient.ReadString16L(r);
        uint wcid = AcClient.ReadPackedDword(r);
        uint icon = AcClient.ReadPackedDword(r) | 0x06000000u;
        uint itemType = r.ReadUInt32(), what = r.ReadUInt32();   // the kind of thing; what it is and does (a door, a portal, attackable...)
        AcClient.Align(r);
        var held = new Held { Guid = guid, Name = name, Wcid = (int)wcid, Icon = icon, ItemType = (int)itemType, Stuck = (what & 0x4) != 0, What = what };
        try
        {
            uint wf2 = (what & 0x04000000) != 0 ? r.ReadUInt32() : 0;
            if ((wf & 0x1) != 0) AcClient.ReadString16L(r);
            if ((wf & 0x2) != 0) { held.Capacity = r.ReadByte(); held.IsPack = held.Capacity > 0; }
            if ((wf & 0x4) != 0) held.PackSlots = r.ReadByte();   // (how many packs it takes: a chest's bag slots - an apartment's storage, one)
            if ((wf & 0x100) != 0) held.AmmoType = r.ReadUInt16();   // (what it shoots or is shot from: 1 arrows, 2 quarrels, 4 darts)
            if ((wf & 0x8) != 0) held.Value = r.ReadInt32();
            if ((wf & 0x10) != 0) held.Useable = (int)r.ReadUInt32();
            if ((wf & 0x20) != 0) held.UseRadius = r.ReadSingle();
            if ((wf & 0x80000) != 0) r.ReadUInt32();
            if ((wf & 0x80) != 0) r.ReadUInt32();
            if ((wf & 0x200) != 0) r.ReadByte();
            if ((wf & 0x400) != 0) held.Uses = r.ReadUInt16();
            if ((wf & 0x800) != 0) held.MaxUses = r.ReadUInt16();
            if ((wf & 0x1000) != 0) held.Stack = r.ReadUInt16();
            if ((wf & 0x2000) != 0) held.MaxStack = r.ReadUInt16();
            if ((wf & 0x4000) != 0) held.Container = r.ReadUInt32();
            if ((wf & 0x8000) != 0) held.Wielder = r.ReadUInt32();
            if ((wf & 0x10000) != 0) held.Locations = (int)r.ReadUInt32();
            if ((wf & 0x20000) != 0) held.WornAt = (int)r.ReadUInt32();
            if ((wf & 0x40000) != 0) held.Priority = (int)r.ReadUInt32();
            if ((wf & 0x100000) != 0) r.ReadByte();
            if ((wf & 0x800000) != 0) r.ReadByte();
            if ((wf & 0x08000000) != 0) r.ReadUInt16();
            if ((wf & 0x01000000) != 0) r.ReadSingle();
            if ((wf & 0x200000) != 0) { held.Burden = r.ReadUInt16(); held.BurdenSaid = true; }
            if ((wf & 0x400000) != 0) r.ReadUInt16();
            if ((wf & 0x02000000) != 0) r.ReadUInt32();
            // (read on to its cooldown either way; a house's restrictions aren't read, and only matter when the next thing follows)
            if ((wf & 0x04000000) != 0)
            {
                // a house's restrictions (who may come in): version, open or not, the monarch, then the guests' table
                r.ReadUInt32(); r.ReadUInt32(); r.ReadUInt32();
                int guests = r.ReadUInt16(); r.ReadUInt16();
                if (guests > 2000) { if (!whole) return held; throw new InvalidDataException("a house's restrictions don't read right"); }
                for (int gi = 0; gi < guests; gi++) { r.ReadUInt32(); r.ReadUInt32(); }
            }
            if ((wf & 0x20000000) != 0) r.ReadUInt32();
            if ((wf & 0x40) != 0) r.ReadUInt32();
            if ((wf & 0x10000000) != 0) r.ReadUInt16();
            if ((wf & 0x40000000) != 0) held.IconOver = AcClient.ReadPackedDword(r) | 0x06000000u;
            if ((wf2 & 0x1) != 0) held.IconUnder = AcClient.ReadPackedDword(r) | 0x06000000u;
            if ((wf & 0x80000000) != 0) held.Material = (int)r.ReadUInt32();
            if ((wf2 & 0x2) != 0) held.CooldownId = (int)r.ReadUInt32();
            if ((wf2 & 0x4) != 0) held.CooldownTime = r.ReadDouble();
            if ((wf2 & 0x8) != 0) held.PetOwner = r.ReadUInt32();   // (a pet: whose it is)
            AcClient.Align(r);
        }
        catch (EndOfStreamException) when (!whole) { }   // (a header that runs short: the thing itself still shows)
        return held;
    }

    // ── a vendor: what they sell and at what rates; buying and selling are asked of the server ──

    /// <summary>A vendor we've walked up to, as the server describes them.</summary>
    public sealed class VendorInfo
    {
        public uint Guid;
        public string Name = "";
        /// <summary>What they pay for a thing (a part of its value), and what they charge.</summary>
        public float BuyRate, SellRate;
        public int BuysTypes, MinValue, MaxValue;
        /// <summary>What they're paid in when it isn't pyreals (trade tokens, a server's own coin): its kind, its name, how many you have. 0: pyreals.</summary>
        public uint Currency;
        public string CurrencyName = "";
        public long CurrencyHave;
        public List<Combat.Item> ForSale = new();
    }
    /// <summary>Told when a vendor's wares arrive (using them; again after each sale).</summary>
    public Action<VendorInfo>? VendorOpened;
    /// <summary>The pyreals the server counts as ours (its own figure for the character - what the game's vendor window shows; a server may count more than is carried); -1: not told.</summary>
    public long CoinValue = -1;

    private void Vendor(BinaryReader r)
    {
        var v = new VendorInfo { Guid = r.ReadUInt32() };
        v.Name = _things.TryGetValue(v.Guid, out var vs) ? vs.Name : "Vendor";
        v.BuysTypes = (int)r.ReadUInt32(); v.MinValue = (int)r.ReadUInt32(); v.MaxValue = (int)r.ReadUInt32();
        r.ReadUInt32();
        v.BuyRate = r.ReadSingle(); v.SellRate = r.ReadSingle();
        uint coin = r.ReadUInt32(); uint coinHave = r.ReadUInt32(); string coinName = AcClient.ReadString16L(r);
        if (coin != 0 && coin != 273) { v.Currency = coin; v.CurrencyHave = coinHave; v.CurrencyName = coinName.Length > 0 ? coinName : $"of item {coin}"; }   // (273: pyreals)
        int n = r.ReadInt32();
        try
        {
            for (int i = 0; i < n; i++)
            {
                r.ReadInt32();   // how many they have (-1: no end of them)
                uint g = r.ReadUInt32();
                var h = ReadHeader(r, g, true);
                var it = ItemOf(h);
                // (a vendor's things are priced one at a time, whatever the stack they're kept in)
                it.Stack = 1; it.Value = h.Value; it.Burden = h.Burden;
                v.ForSale.Add(it);
            }
        }
        catch (Exception ex) { Say?.Invoke($"[Network] couldn't read all of {v.Name}'s wares ({v.ForSale.Count} of {n}): {ex.Message}", SysColor, ChatKind.Errors); }
        OpenVendorInfo = v;
        VendorOpened?.Invoke(v);
    }
    /// <summary>The vendor whose window is open (null once it's shut): for plugins.</summary>
    public VendorInfo? OpenVendorInfo;

    /// <summary>Buys from a vendor: each thing of theirs and how many.</summary>
    public void Buy(uint vendor, IReadOnlyList<(Combat.Item item, int amount)> things) => Trade(0x005F, vendor, things);
    /// <summary>Sells to a vendor: each thing of ours and how many.</summary>
    public void Sell(uint vendor, IReadOnlyList<(Combat.Item item, int amount)> things) => Trade(0x0060, vendor, things);
    private void Trade(uint action, uint vendor, IReadOnlyList<(Combat.Item item, int amount)> things)
    {
        if (!_inWorld || Client == null || things.Count == 0) return;
        HereFirst();
        using var b = new MemoryStream();
        var w = new BinaryWriter(b);
        w.Write(vendor); w.Write((uint)things.Count);
        foreach (var (item, amount) in things) { w.Write(amount); w.Write(item.Guid); }
        if (action == 0x005F) w.Write(0u);   // (the other currency: none)
        Client.SendAction(action, b.ToArray());
        _invDirty = true;
    }

    // ── what we carry ──

    // a thing the server has described that can be carried: whose it is, and the item it is in our pack
    private sealed class Held
    {
        public uint Guid, Icon, Container, Wielder;
        public bool BurdenSaid;   // (its burden came with it, or since)
        public string Name = "";
        public int Wcid, ItemType, Value, Stack, MaxStack, Locations, WornAt, Priority, Burden, Uses, MaxUses;
        public bool IsPack, Stuck;
        /// <summary>How it looks, as the server describes it (a look number of ours: its model and colours); 0: not known.</summary>
        public int Look;
        public uint What, IconOver, IconUnder;
        public int AmmoType;
        public int Capacity, PackSlots = -1, Useable, CooldownId, Material;
        public double CooldownTime;
        public float UseRadius = -1f;
        public uint PetOwner;
        public Combat.Item? Item;
        public void SetStack(int stack, int value)
        {
            // (a stack's weight goes with its count)
            if (Stack > 0 && stack > 0) Burden = Burden / Stack * stack;
            Stack = stack; Value = value;
        }
    }
    private readonly Dictionary<uint, Held> _held = new();
    private bool _invDirty;
    private readonly Dictionary<uint, int> _placedAt = new();

    // ours: worn or wielded by us, or in our pack or a pack in it
    private bool Mine(Held h, out bool worn)
    {
        worn = h.Wielder == _me && h.WornAt != 0;
        if (worn) return true;
        uint c = h.Container;
        for (int i = 0; i < 3 && c != 0; i++)
        {
            if (c == _me) return true;
            c = _held.TryGetValue(c, out var up) ? up.Container : 0;
        }
        return false;
    }

    private Combat.Item ItemOf(Held h)
    {
        var data = Objects.SpawnInfo;
        var it = h.Item ?? (data != null ? Combat.Item.Make(data, h.Wcid) : null) ?? new Combat.Item { Uid = Combat.Item.NextUid++, Wcid = h.Wcid };
        h.Item = it;
        int n = Math.Max(1, h.Stack);
        if (h.Look != 0) it.Look = h.Look;
        it.Guid = h.Guid; it.Name = h.Name; it.IconOver = h.IconOver; it.IconUnder = h.IconUnder; it.AmmoType = h.AmmoType; if (h.Material != 0) it.Material = h.Material; it.Icon = h.Icon; it.ItemType = h.ItemType; it.Locations = h.Locations;
        it.Stack = n; if (h.MaxStack > 0) it.MaxStack = h.MaxStack;
        it.Value = h.Value / n; it.Burden = h.Burden / n;
        if (h.MaxUses > 0) { it.MaxUses = h.MaxUses; it.Uses = h.Uses; }
        it.Capacity = h.Capacity;
        it.Useable = h.Useable;
        it.CooldownId = h.CooldownId; it.CooldownTime = h.CooldownTime;
        if (h.Priority != 0) it.Coverage = h.Priority;
        return it;
    }

    // the pack and what's worn, made over from what the server has said (things stay where they were in the pack; what's
    // new goes in at the top, as the game puts it - at login, in the order the server sent them)
    private void RebuildInventory()
    {
        _invDirty = false;
        if (Inv == null || !_inWorld) return;
        TestTrace.Last = "rebuilding the inventory";
        var pack = new List<Combat.Item>(); var worn = new List<Combat.Item>(); var fresh = new List<Combat.Item>();
        long coins = 0;
        var mine = new HashSet<Combat.Item>(); var side = new List<Combat.Item>();
        foreach (var h in _held.Values)
        {
            if (!Mine(h, out bool isWorn)) continue;
            // (pyreals: counted for the purse, and in the pack as the stacks they are - as the game shows them)
            if (h.Wcid == 273) coins += Math.Max(1, h.Stack);
            // (the packs themselves - bags, foci - go in the pack column; what's in them is listed with the rest)
            if (!isWorn && (h.IsPack || h.ItemType == 0x200 || h.Name.StartsWith("Foci of", StringComparison.OrdinalIgnoreCase))) { if (h.Container == _me) side.Add(ItemOf(h)); continue; }
            var it = ItemOf(h);
            it.WornAt = isWorn ? h.WornAt : 0;
            it.Holder = isWorn || h.Container == _me ? 0 : h.Container;
            mine.Add(it);
            if (isWorn) worn.Add(it);
            else if (!Inv.Pack.Contains(it)) fresh.Add(it);
        }
        foreach (var it in Inv.Pack) if (mine.Contains(it) && it.WornAt == 0) pack.Add(it);
        bool wasFilled = _invFilled;
        if (_invFilled)
        {
            fresh.Reverse(); pack.InsertRange(0, fresh);
            foreach (var f in fresh) if (!_placedAt.ContainsKey(f.Guid) && !(_listed.TryGetValue(f.Holder == 0 ? _me : f.Holder, out var fl0) && fl0.Contains(f.Guid))) OrderLog($"new in {(f.Holder == 0 ? "Main pack" : Named(f.Holder))}: {f.Name} [{f.Guid:X8}] - no place told, shown first");
        }
        else
        {
            // (at login: in the places the server keeps them)
            int Order(Combat.Item i) => _packOrder.TryGetValue(i.Guid, out int o) ? o : int.MaxValue;
            pack.AddRange(fresh.Select((it, i) => (it, i)).OrderBy(x => Order(x.it)).ThenBy(x => x.i).Select(x => x.it));
        }
        _invFilled = true;
        // (something new in a side pack the server has listed - its things often come after the listing: laid out as listed,
        //  not shown first)
        foreach (var f in fresh) if (_listed.TryGetValue(f.Holder == 0 ? _me : f.Holder, out var fl) && fl.Contains(f.Guid)) _relayout.Add(f.Holder == 0 ? _me : f.Holder);
        // (something new the listing doesn't have - made in the pack, not put: at the front, where the server puts those)
        if (wasFilled)
            for (int i = fresh.Count - 1; i >= 0; i--)
            {
                var f = fresh[i];
                if (_placedAt.ContainsKey(f.Guid) || !_listed.TryGetValue(f.Holder == 0 ? _me : f.Holder, out var fl2) || fl2.Contains(f.Guid)) continue;
                fl2.Insert(0, f.Guid);
            }
        // (a side pack just listed: its things in the server's places, in the spots that pack's things take in the list)
        foreach (uint box in _relayout)
        {
            if (!_listed.TryGetValue(box, out var order)) continue;
            var rank = new Dictionary<uint, int>();
            for (int i = 0; i < order.Count; i++) rank[order[i]] = i;
            var spots = new List<int>(); var things = new List<Combat.Item>();
            uint holder = box == _me ? 0 : box;
            for (int i = 0; i < pack.Count; i++) if (pack[i].Holder == holder) { spots.Add(i); things.Add(pack[i]); }
            var laid = things.Select((it, i) => (it, i)).OrderBy(x => rank.TryGetValue(x.it.Guid, out int o) ? o : int.MaxValue).ThenBy(x => x.i).Select(x => x.it).ToList();
            for (int i = 0; i < spots.Count; i++) pack[spots[i]] = laid[i];
        }
        _relayout.Clear();
        // (what the server just put at a place in a pack: moved there among the others of that pack)
        if (_placedAt.Count > 0)
        {
            foreach (var kv in _placedAt)
            {
                var it = pack.FirstOrDefault(i => i.Guid == kv.Key);
                if (it == null) continue;
                pack.Remove(it);
                int seen = 0, at = pack.Count;
                for (int i = 0; i < pack.Count; i++)
                {
                    if (pack[i].Holder != it.Holder) continue;
                    if (seen == kv.Value) { at = i; break; }
                    seen++; at = i + 1;
                }
                pack.Insert(Math.Min(at, pack.Count), it);
            }
            _placedAt.Clear();
        }
        Inv.Pack.Clear(); Inv.Pack.AddRange(pack);
        Inv.Worn.Clear(); Inv.Worn.AddRange(worn);
        // (the side packs in the places the server keeps them, as far as it's said)
        Inv.SidePacks.Clear(); Inv.SidePacks.AddRange(side.Select((it, i) => (it, i)).OrderBy(x => _packOrder.TryGetValue(x.it.Guid, out int o) ? o : int.MaxValue).ThenBy(x => x.i).Select(x => x.it));
        Inv.Pyreals = coins;
        Inv.Changed?.Invoke();
        InventoryChanged?.Invoke();
    }
    private bool _invFilled;
    /// <summary>Told when the pack or what's worn has changed on the server's word.</summary>
    public Action? InventoryChanged;

    /// <summary>A book being read: its server number, the page (0 on; -1: it has just opened), how many pages it has (-1: not said
    /// with this page) and the page's words (null as it opens). Every page of a book opened is asked for, so all of them come.</summary>
    public Action<uint, int, int, string?>? BookPage;
    // a page as the server sends it: who wrote it, then its words if they're sent along (null: not)
    private static string? ReadPage(BinaryReader r)
    {
        r.ReadUInt32();                       // the author's number
        AcClient.ReadString16L(r);            // their name
        AcClient.ReadString16L(r);            // their account
        uint version = r.ReadUInt32();
        bool text = true;
        if (version >> 16 == 0xFFFF) { text = r.ReadUInt32() != 0; r.ReadUInt32(); }   // (words sent along; the author to be left out)
        return text ? AcClient.ReadString16L(r) : null;
    }
    private double _selfHealthAsked;
    /// <summary>The server's answer about ourselves: our health as a part (0-1) of the most it can be.</summary>
    public Action<float>? SelfHealthPart;
    // what the server has taken out of the world (destroyed, used up, merged into another stack)
    private readonly HashSet<uint> _deleted = new();
    /// <summary>The server has done away with this (an item used up or merged, a creature's body gone).</summary>
    public bool Deleted(uint guid) => guid != 0 && _deleted.Contains(guid);
    /// <summary>A thing's burden as the server last said (-1: not said) - a corpse's counts what's in it.</summary>
    /// <summary>The kind of thing the server says it is (its ItemType: 0x200 a container - a chest, a crate), or 0.</summary>
    public int ItemTypeOf(uint guid) => guid != 0 && _held.TryGetValue(guid, out var h) ? h.ItemType : 0;
    public int BurdenOf(uint guid) => guid != 0 && _held.TryGetValue(guid, out var h) && h.BurdenSaid ? h.Burden : -1;
    /// <summary>Set by a plugin's stand-in while it asks for something of its own accord (tidying packs): a refusal of
    /// that is logged but not said in chat - the game's own client says nothing either, and it wasn't you who asked.</summary>
    public bool PluginAsking;
    private readonly HashSet<uint> _quietAsk = new();
    // what was last asked of the server about each thing (for the log, when it says no without saying why)
    private readonly Dictionary<uint, (uint action, uint[] values, double at)> _lastAsk = new();
    private void ItemAction(uint action, params uint[] values)
    {
        if (!_inWorld || Client == null) return;
        // (leaving the world: nothing more is asked of the server about what we hold - a plugin still fighting asked for
        // its weapon back again and again, and the server said no each time)
        if (_loggingOut) return;
        if (values.Length > 0) { _lastAsk[values[0]] = (action, values, _clock); if (PluginAsking) _quietAsk.Add(values[0]); else _quietAsk.Remove(values[0]); }
        if (ItemAsks.Contains(action)) { _pendingAsk = values.Length > 0 ? values[0] : 1; _pendingAt = _clock; }
        if (action == 0x0019 && values.Length > 2) OrderLog($"asked to move {Named(values[0])} [{values[0]:X8}] into {Named(values[1])} at {values[2]}{(PluginAsking ? " (a plugin)" : "")}");
        else if (action == 0x0055 && values.Length > 3) OrderLog($"asked to split {values[3]} off {Named(values[0])} into {Named(values[1])} at {values[2]}");
        else if (action == 0x0054 && values.Length > 1) OrderLog($"asked to stack {Named(values[0])} onto {Named(values[1])}");
        HereFirst();
        using var b = new MemoryStream();
        var w = new BinaryWriter(b);
        foreach (uint v in values) w.Write(v);
        Client.SendAction(action, b.ToArray());
        if (values.Length > 0) _lastActed = values[0];
        _invDirty = true;   // (if the server says no, the pack goes back to what it has)
    }
    /// <summary>Wears or wields something of ours (GetAndWieldItem).</summary>
    /// <remarks>
    /// The server won't put a thing where another is, and is busy a moment while that one comes off: asked just after
    /// taking something off, the wielding waits until the server says it's off (or a few seconds at most).
    /// </remarks>
    public void Wield(Combat.Item it, int at)
    {
        if (_comingOff.Count == 0) { ItemAction(0x001A, it.Guid, (uint)at); return; }
        uint g = it.Guid;
        void Try(int left)
        {
            if (_comingOff.Count > 0 && left > 0) { _soon.Add((_clock + 0.2, () => Try(left - 1))); return; }
            _comingOff.Clear();
            _soon.Add((_clock + 0.3, () => ItemAction(0x001A, g, (uint)at)));
        }
        Try(15);
    }
    private readonly HashSet<uint> _comingOff = new();
    /// <summary>Takes something off, back into the pack (PutItemInContainer, at the top).</summary>
    public void ToPack(Combat.Item it)
    {
        if (it.WornAt != 0)
        {
            _comingOff.Add(it.Guid);
            // (a plugin keeping the packs sorted can say where it belongs - straight there, not to the front and moved after)
            (uint pack, int slot)? at = null;
            try { at = PlaceTakenOff?.Invoke(it); } catch { }
            if (at is { } a) { ItemAction(0x0019, it.Guid, a.pack == 0 ? _me : a.pack, (uint)Math.Max(0, a.slot)); return; }
        }
        ItemAction(0x0019, it.Guid, _me, 0);
    }
    /// <summary>Where something taken off goes (pack: 0 the main one), when a plugin knows; null for the front of the main pack.</summary>
    public Func<Combat.Item, (uint pack, int slot)?>? PlaceTakenOff;

    // where we stand, told to the server before asking something of it that goes by how near we are (it would
    // otherwise go by where we were up to half a second ago, and try to walk us there itself)
    // (a use straight off a run: the stop said before it, not after - said after, ACE took it for us walking off and
    // dropped the walk to the thing it had just started for that use; and nothing more said of our moves for a moment)
    private void StoppedFirst()
    {
        if (_moveSent.f != 0 || _moveSent.s != 0 || _moveSent.t != 0) SendMotion(0, true);
        _quietUntil = _clock + 0.5;
    }
    private double _quietUntil = -1;

    private void HereFirst()
    {
        if (_placed && (Player.Position.DistanceTo(_lastSent) > 0.02f || Turned)) SendPosition();
    }
    /// <summary>Gives something of ours (so many of a stack) to someone in the world (GiveObjectRequest).</summary>
    public void Give(ObjectStreamer.Selectable to, Combat.Item it, int amount)
    {
        uint g = GuidOf(to);
        if (g != 0 && it.Guid != 0) ItemAction(0x00CD, g, it.Guid, (uint)Math.Clamp(amount, 1, Math.Max(1, it.Stack)));
    }
    /// <summary>Moves something of ours to a place in a pack (0: the main pack).</summary>
    /// <summary>One of our side packs (or foci) to another place in the pack column: the others shift along.</summary>
    public void MovePack(Combat.Item pack, int place)
    {
        var order = Inv.SidePacks.ToList();
        int from = order.IndexOf(pack);
        if (from < 0 || pack.Guid == 0) return;
        place = Math.Clamp(place, 0, order.Count - 1);
        if (place == from) return;
        order.RemoveAt(from); order.Insert(place, pack);
        for (int i = 0; i < order.Count; i++) _packOrder[order[i].Guid] = i;
        Inv.SidePacks.Clear(); Inv.SidePacks.AddRange(order);
        ItemAction(0x0019, pack.Guid, _me, (uint)place);
        PackOrderNote += $"; then {pack.Name} moved to place {place}";
        _invDirty = true;
    }

    /// <summary>Who last sent us a tell (what /r answers).</summary>
    public string? LastTeller;

    public void Move(Combat.Item it, uint pack, int place)
    {
        // (a pack can't go in a pack: dropped on one of yours - a bag taken out of a house's storage onto your side
        // packs - it goes to your pack slots, which the server would otherwise refuse)
        if (pack != 0 && pack != _me && _held.TryGetValue(it.Guid, out var moving) && moving.IsPack && _held.TryGetValue(pack, out var into) && into.IsPack && Mine(into, out _)) { pack = _me; place = 0; }
        ItemAction(0x0019, it.Guid, pack == 0 ? _me : pack, (uint)Math.Max(0, place));
    }
    /// <summary>Splits so many off a stack: into a pack at a place (0: the main pack), or (pack uint.MaxValue) onto the ground.</summary>
    public void Split(Combat.Item it, uint pack, int place, int amount)
    {
        if (pack == uint.MaxValue) ItemAction(0x0056, it.Guid, (uint)amount);
        else ItemAction(0x0055, it.Guid, pack == 0 ? _me : pack, (uint)Math.Max(0, place), (uint)amount);
    }
    /// <summary>Puts one stack onto another of the same thing (as many as fit; or only so many of it).</summary>
    public void Merge(Combat.Item from, Combat.Item onto) => Merge(from, onto, 0);
    public void Merge(Combat.Item from, Combat.Item onto, int amount)
    {
        int room = onto.MaxStack > 1 ? onto.MaxStack - onto.Stack : from.Stack;
        int n = Math.Min(amount > 0 ? Math.Min(amount, from.Stack) : from.Stack, room);
        if (n > 0) ItemAction(0x0054, from.Guid, onto.Guid, (uint)n);
    }
    /// <summary>Asks how hurt something is (the answer comes as its health, as after a blow).</summary>
    public void QueryHealth(uint guid)
    {
        if (!_inWorld || guid == 0) return;
        Client?.SendAction(0x01BF, BitConverter.GetBytes(guid));
        if (guid != _me && !_unanswered.ContainsKey(guid)) _unanswered[guid] = _clock;
    }

    // Ghosts: monsters we still show that the server has forgotten - one that died or went while we were out of its sight
    // (a long dungeon route: the server stops telling us about what's far off, and never says it's gone). Asked how hurt
    // it is (as it's chosen, and every few seconds while it is), the server answers for anything real; a monster on our
    // landblock that's had no answer in 10 s isn't there - it's taken away (VTank had a ghost timeout for the same).
    private readonly Dictionary<uint, double> _unanswered = new();
    public int GhostsRemoved { get; private set; }
    // the ones not chosen are asked about too, one every 3 s: a monster on our landblock the server's said nothing of in
    // 30 s (a real one standing still says nothing either - asked, it answers). The server takes the one asked about as the
    // one whose health it keeps us told of, so the one really chosen is asked about again straight after.
    private readonly Dictionary<uint, double> _heard = new(), _probed = new();
    private double _probeAt;
    /// <summary>The creature chosen in the game (its health is kept up to date by the server): asked about again after a check.</summary>
    public Func<uint>? ChosenGuid;
    private void ProbeQuiet()
    {
        if (!_inWorld || _clock < _probeAt) return;
        _probeAt = _clock + 3;
        uint mine = Player.Cell != 0 ? Player.Cell : _myCell;
        if (mine == 0) return;
        uint pick = 0; float best = float.MaxValue;
        foreach (var (g, sel) in _things)
        {
            if (sel.Kind != 2 || sel.Corpse || _unanswered.ContainsKey(g)) continue;
            if (_heard.TryGetValue(g, out var h) && _clock - h < 30) continue;
            if (_probed.TryGetValue(g, out var p) && _clock - p < 60) continue;
            uint its = sel.Cell != 0 ? sel.Cell : _where.TryGetValue(g, out var w) ? w.cell : 0;
            if (its == 0 || (its >> 16) != (mine >> 16)) continue;
            float d = sel.Feet.DistanceTo(Player.Position);
            if (d < best) { best = d; pick = g; }
        }
        if (pick == 0) return;
        _probed[pick] = _clock;
        QueryHealth(pick);
        uint chosen = ChosenGuid?.Invoke() ?? 0;
        if (chosen != 0 && chosen != pick) Client?.SendAction(0x01BF, BitConverter.GetBytes(chosen));
    }

    private void CheckGhosts()
    {
        ProbeQuiet();
        LookOverPlayers();
        if (_unanswered.Count == 0) return;
        foreach (var (g, at) in _unanswered.ToList())
        {
            if (_clock - at < 10) continue;
            _unanswered.Remove(g);
            if (!_things.TryGetValue(g, out var sel) || sel.Kind != 2 || sel.Corpse) continue;
            // (the server only answers for what's on our own landblock: one on the next one over may just be out of reach)
            uint mine = Player.Cell != 0 ? Player.Cell : _myCell;
            uint its = sel.Cell != 0 ? sel.Cell : _where.TryGetValue(g, out var w) ? w.cell : 0;
            if (mine == 0 || its == 0 || (mine >> 16) != (its >> 16)) continue;
            GhostsRemoved++;
            Say?.Invoke($"[Network] {sel.Name} (id {g:X8}) isn't really there - the server doesn't know it (a ghost). Taken off the screen.", SysColor, ChatKind.Gameplay);
            if (_things.Remove(g, out var gone)) Objects.RemoveGroundItem(gone);
            _heard.Remove(g); _probed.Remove(g);
            LetGo(g);
            foreach (uint c in _heldBy.Where(kv => kv.Value.parent == g).Select(kv => kv.Key).ToList()) _heldBy.Remove(c);
        }
    }
    /// <summary>Drops something of ours on the ground (DropItem).</summary>
    public void Drop(Combat.Item it) => ItemAction(0x001B, it.Guid);

    // Motion: what something's doing. Read for turning - to face someone (a person spoken to turns to you) or a heading.
    private void Motion(BinaryReader r)
    {
        uint guid = r.ReadUInt32();
        _heard[guid] = _clock;
        r.ReadUInt16(); r.ReadUInt16(); r.ReadUInt16(); r.ReadByte();
        AcClient.Align(r);
        if (guid == _me) { MyMotion(r); return; }
        if (!_things.TryGetValue(guid, out var sel) || sel.Type == 19) return;
        ApplyMovement(r, sel);
    }

    /// <summary>Told of an effect the server plays on a thing (null: on us): the thing's effects table, the effect (or, direct, a script's own number) and its strength.</summary>
    public Action<ObjectStreamer.Selectable?, uint, uint, float, bool>? EffectPlayed;
    private readonly Dictionary<uint, uint> _fxTables = new();
    private readonly Dictionary<uint, uint> _setupOf = new();
    // (each thing's sound table as the server gives it - a spell's bolt names its sounds by kind, launch and burst, in it)
    private readonly Dictionary<uint, uint> _soundOf = new();
    private uint _mySoundTable;
    public uint SoundTableOf(ObjectStreamer.Selectable? s) => s == null ? _mySoundTable : _soundOf.TryGetValue(s.Guid, out uint id) ? id : 0;
    /// <summary>A server thing's setup (null: ours) - an effect's particles sit on its parts, not all at its feet.</summary>
    public uint SetupOf(ObjectStreamer.Selectable? s) => s == null ? _mySetup : _setupOf.TryGetValue(s.Guid, out uint id) ? id : 0;
    private uint _myFxTable;

    // ── contracts ──
    public sealed class Contract { public uint Id; public int Stage; public long Done, Repeats; }
    public readonly Dictionary<uint, Contract> Contracts = new();
    public Action? ContractsChanged;
    private static Contract ReadContract(BinaryReader r)
    {
        r.ReadUInt32();
        var c = new Contract { Id = r.ReadUInt32(), Stage = (int)r.ReadUInt32() };
        c.Done = r.ReadInt64(); c.Repeats = r.ReadInt64();
        return c;
    }
    /// <summary>Gives a contract up.</summary>
    public void AbandonContract(uint id) { if (_inWorld) Client?.SendAction(0x0316, BitConverter.GetBytes(id)); }

    // ── using what we carry ──
    /// <summary>Uses one of our things (eats it, reads it, sets it off).</summary>
    public void UseItem(Combat.Item item) { if (_inWorld && item.Guid != 0) { StoppedFirst(); HereFirst(); Client?.SendAction(0x0036, BitConverter.GetBytes(item.Guid)); } }
    /// <summary>Uses one of our things on something (a healing kit on someone, a key on a door, a tool on an item).</summary>
    public void UseOn(Combat.Item item, uint target)
    {
        if (!_inWorld || item.Guid == 0 || target == 0 || Client == null) return;
        HereFirst();
        var b = new byte[8];
        BitConverter.GetBytes(item.Guid).CopyTo(b, 0); BitConverter.GetBytes(target).CopyTo(b, 4);
        Client.SendAction(0x0035, b);
        UsedOn?.Invoke(item);
    }
    /// <summary>Something of ours was used on a thing (by the player, or a plugin).</summary>
    public Action<Combat.Item>? UsedOn;

    /// <summary>Told when the server sends us somewhere else (a portal, a recall, back to the lifestone): portal space.</summary>
    public Action? Teleporting;
    /// <summary>Told when the server adds a spell to the spellbook (true) or takes one out.</summary>
    public Action<int, bool>? SpellLearned;
    /// <summary>Told when the server has us fall dead (true), and when we're up again (false).</summary>
    public Action<bool>? Died;

    // what the server has our own character do: only dying and getting up again are its to say (the rest we do ourselves)
    // things the server has us do that nothing here starts by itself: a healing kit's bandaging (on ourselves or
    // another), eating, drinking, reading - played as it says, in whatever stance we're in
    // (healing, eating, drinking, reading, crafting's clap; and the recalls' gestures - house, lifestone, marketplace, allegiance hometown, PK arena)
    private static readonly HashSet<uint> ServerPlayed = new() { 0x1000010Eu, 0x1000010Fu, 0x4000001Au, 0x4000001Bu, 0x4000001Cu,
                                                                 0x1000013Au, 0x10000153u, 0x10000166u, 0x10000171u, 0x10000172u,
                                                                 0x1300007Eu };   // (and the clap of crafting: a tool used on something - salvage, aetheria, tailoring)

    /// <summary>The server put us in peace mode itself (equipping armor does, in combat).</summary>
    public Action? ServerPeace;

    private void MyMotion(BinaryReader r)
    {
        int kind = r.ReadByte(); r.ReadByte(); uint myStyle = r.ReadUInt16();
        if (kind == 0 && myStyle == 0x3D) ServerPeace?.Invoke();   // (our stance, as the server has it: NonCombat)
        if (kind != 0)
        {
            // the server walking or turning us itself (to something used out of reach, a corpse, a monster): done here
            // too, so where it has us and where we are stay the same
            _posServerMoves++;
            try { FollowServer(kind, r); } catch (EndOfStreamException) { }
            return;
        }
        uint f = r.ReadUInt32(); int n = (int)(f >> 7);
        if ((f & 0x1) != 0) r.ReadUInt16();
        uint forward = (f & 0x2) != 0 ? AcDream.Core.Physics.MotionCommandResolver.ReconstructFullCommand(r.ReadUInt16()) : 0;
        if ((f & 0x8) != 0) r.ReadUInt16();
        if ((f & 0x20) != 0) r.ReadUInt16();
        float speed = (f & 0x4) != 0 ? r.ReadSingle() : 1f;
        if ((f & 0x10) != 0) r.ReadSingle();
        if ((f & 0x40) != 0) r.ReadSingle();
        var once = new List<uint>();
        for (int i = 0; i < n && i < 16; i++) { once.Add(AcDream.Core.Physics.MotionCommandResolver.ReconstructFullCommand(r.ReadUInt16())); r.ReadUInt16(); r.ReadSingle(); }
        if (forward != 0x41000003 || once.Count > 0) _myMotions.Add($"{DateTime.Now:HH:mm:ss.ff} forward {forward:X8} x{speed:0.##}" + (once.Count > 0 ? " once " + string.Join(",", once.Select(o => o.ToString("X8"))) : ""));
        if (_myMotions.Count > 30) _myMotions.RemoveAt(0);
        Objects.Note($"you: forward {forward:X8} speed {speed:0.##}" + (once.Count > 0 ? " once " + string.Join(",", once.Select(o => o.ToString("X8"))) : ""));
        if (forward == 0x40000011) { if (!Player.Dead) Died?.Invoke(true); return; }
        if (Player.Dead) Died?.Invoke(false);
        // something the server has us do that we didn't start ourselves (kneeling at a lifestone): played
        // and, out of combat, anything else it has us do - an action or an emote (a crafting tool's clap, a quest's bow):
        // the server's to say. (In combat our own blows and casts are ours, played here already: the server's echo of
        // them isn't played again; nor is a gesture we've just asked for ourselves - a wave - coming back)
        // shooting (missile combat): the draw and loose (an aim, at the height the server worked out) and the reload are
        // the server's to time - played as it says, held standing till it says Ready (nothing here plays them itself)
        // (back to ready comes as no forward motion at all - the default - or as Ready itself)
        if (_combatMode == 4)
        {
            if (forward == 0x40000016 || (forward >= 0x4000001E && forward <= 0x4000002A)) SelfMissilePose?.Invoke(forward);
            else if (forward == 0 || forward == 0x41000003) SelfMissilePose?.Invoke(0);
        }
        else SelfMissilePose?.Invoke(0);   // (out of missile combat - out of arrows: a held aim or reload let go)
        bool peace = _combatMode <= 1;
        foreach (uint m in once.Prepend(forward))
        {
            if (m == 0 || m == 0x41000003) continue;
            uint cls = m >> 24;
            bool action = cls is 0x10 or 0x12 or 0x13;
            bool ours = m == _ownGesture && _clock - _ownGestureAt < 3;
            if (m == Sanctuary || ServerPlayed.Contains(m) || (peace && action && !ours)) SelfAction?.Invoke(m, speed);
        }
        // (a cast's gestures, as the server times them: the spell goes off as the last one ends)
        // (they come as what we're doing now, one after another - or as things done once)
        foreach (uint m in once.Prepend(forward)) if (m != 0 && m != 0x41000003) SelfGesture?.Invoke(m, speed);
    }
    // ── things creatures hold: child -> its holder, how, and its model in their hand once drawn ──
    private readonly Dictionary<uint, (uint parent, int look, uint loc, uint placement, Node3D? node)> _heldBy = new();
    private readonly Dictionary<uint, uint> _placementOf = new();   // (the pose each thing on the ground was told to stand in)

    private void HoldIn(uint child, uint parent, int look, uint loc, uint placement)
    {
        if (_heldBy.TryGetValue(child, out var was) && was.node != null && GodotObject.IsInstanceValid(was.node)) was.node.QueueFree();
        Node3D? node = null;
        if (_things.TryGetValue(parent, out var holder))
            try { node = Objects.Hold(holder, look, loc, placement); } catch (Exception ex) { GD.PushWarning("held item: " + ex.Message); }
        _heldBy[child] = (parent, look, loc, placement, node);
    }

    /// <summary>What a creature or person holds (a monster's weapon, another player's) under this point on the screen:
    /// the item, as one of ours would be (to look at, to identify) - null if nothing held is there.</summary>
    public Combat.Item? HeldAt(Camera3D cam, Vector2 screen)
    {
        Combat.Item? best = null; float bestOff = float.MaxValue;
        foreach (var (child, h) in _heldBy)
        {
            if (h.node is not { } n || !GodotObject.IsInstanceValid(n) || !n.IsVisibleInTree()) continue;
            if (!_held.TryGetValue(child, out var held)) continue;
            foreach (var c in n.GetChildren())
            {
                if (c is not MeshInstance3D mi || mi.Mesh == null) continue;
                var box = mi.GetAabb();
                var xf = mi.GlobalTransform;
                Vector3 centre = xf * box.GetCenter();
                if (cam.IsPositionBehind(centre) || cam.GlobalPosition.DistanceTo(centre) > 60f) continue;
                // (its outline on screen: from one end of it to the other - a sword, a bow, a staff are long and thin)
                Vector3 e = box.Size * 0.5f;
                var ends = new[] { xf * (box.GetCenter() + new Vector3(e.X, 0, 0)), xf * (box.GetCenter() - new Vector3(e.X, 0, 0)),
                                   xf * (box.GetCenter() + new Vector3(0, e.Y, 0)), xf * (box.GetCenter() - new Vector3(0, e.Y, 0)),
                                   xf * (box.GetCenter() + new Vector3(0, 0, e.Z)), xf * (box.GetCenter() - new Vector3(0, 0, e.Z)) };
                // the longest way through it, and how far the point is from that line
                Vector2 a0 = cam.UnprojectPosition(ends[0]), a1 = cam.UnprojectPosition(ends[1]);
                for (int k = 2; k < 6; k += 2)
                {
                    Vector2 b0 = cam.UnprojectPosition(ends[k]), b1 = cam.UnprojectPosition(ends[k + 1]);
                    if (b0.DistanceTo(b1) > a0.DistanceTo(a1)) { a0 = b0; a1 = b1; }
                }
                Vector2 ab = a1 - a0;
                float t = ab.LengthSquared() > 1e-4f ? Math.Clamp((screen - a0).Dot(ab) / ab.LengthSquared(), 0f, 1f) : 0f;
                float off = (a0 + ab * t).DistanceTo(screen);
                if (off > 9f || off >= bestOff) continue;
                best = ItemOf(held); bestOff = off;
            }
        }
        return best;
    }

    // ── the house we own (the housing tab): asked for, the server answers with it - or that there's none ──
    public sealed class HouseInfo
    {
        public DateTime Bought, RentFrom;   // (local time)
        public int Type;                    // 1 cottage, 2 villa, 3 mansion, 4 apartment
        public bool Free;                   // maintenance free this period
        public readonly List<HousePayment> Buy = new(), Rent = new();
        public uint Cell;
        public System.Numerics.Vector3 At;
        public string TypeName => Type switch { 1 => "Cottage", 2 => "Villa", 3 => "Mansion", 4 => "Apartment", _ => "House" };
    }
    public HouseInfo? House { get; private set; }
    public bool HouseAnswered { get; private set; }
    public Action? HouseChanged;
    private double _houseAskedAt = -100;

    /// <summary>Asks the server about the house we own (at most every few seconds).</summary>
    public void QueryHouse()
    {
        if (!_inWorld || Client == null || _clock - _houseAskedAt < 5) return;
        _houseAskedAt = _clock;
        Client.SendAction(0x021E, Array.Empty<byte>());
    }

    /// <summary>House recall: to the house we own (the server plays the gesture and takes us there).</summary>
    public bool HouseRecall()
    {
        if (!_inWorld || Client == null) return false;
        Client.SendAction(0x0262, Array.Empty<byte>());   // TeleToHouse
        return true;
    }

    /// <summary>Gives up the house we own (the server takes it back; it can't be undone).</summary>
    public bool AbandonHouse()
    {
        if (!_inWorld || Client == null) return false;
        Client.SendAction(0x021F, Array.Empty<byte>());   // AbandonHouse
        _houseAskedAt = -100;
        return true;
    }

    /// <summary>Where the house is, as the game shows map coordinates.</summary>
    public string HouseWhere => House is { } h && h.Cell != 0 ? World.MapCoords(Godot(h.Cell, h.At)) : "";

    private static HouseInfo ReadHouse(BinaryReader r)
    {
        var h = new HouseInfo();
        static DateTime When(uint t) => t == 0 ? DateTime.MinValue : DateTimeOffset.FromUnixTimeSeconds(t).LocalDateTime;
        h.Bought = When(r.ReadUInt32()); h.RentFrom = When(r.ReadUInt32());
        h.Type = (int)r.ReadUInt32(); h.Free = r.ReadUInt32() != 0;
        try
        {
            ReadPayments(r, h.Buy); ReadPayments(r, h.Rent);
            h.Cell = r.ReadUInt32(); h.At = new System.Numerics.Vector3(r.ReadSingle(), r.ReadSingle(), r.ReadSingle());
        }
        catch (EndOfStreamException) { }
        return h;
    }

    /// <summary>One thing a house costs, or its upkeep: what (its kind, by weenie), how many, how many paid so far.</summary>
    public sealed record HousePayment(uint Wcid, string Name, int Need, int Paid)
    {
        public int Left => Math.Max(0, Need - Paid);
    }

    private static void ReadPayments(BinaryReader r, List<HousePayment> into)
    {
        int n = r.ReadInt32();
        for (int i = 0; i < n && i < 64; i++)
        {
            int need = r.ReadInt32(), paid = r.ReadInt32(); uint wcid = r.ReadUInt32();
            string name = AcClient.ReadString16L(r), plural = AcClient.ReadString16L(r);
            into.Add(new HousePayment(wcid, need == 1 || plural.Length == 0 ? name : plural, need, paid));
        }
    }

    // ── a house's sign (its covenant crystal) used: what it costs to buy, or its upkeep - the panel to buy or pay from ──
    public sealed class HouseOffer
    {
        public uint Sign, Owner;
        public string OwnerName = "";
        public int Type, MinLevel, MaxLevel, MinRank, MaxRank;
        public bool Free;
        public readonly List<HousePayment> Buy = new(), Rent = new();
        public string TypeName => Type switch { 1 => "Cottage", 2 => "Villa", 3 => "Mansion", 4 => "Apartment", _ => "House" };
        public bool Owned => Owner != 0;
    }
    /// <summary>Told when a house's sign answers (used): the offer to show.</summary>
    public Action<HouseOffer>? HouseOffered;

    private void ReadHouseOffer(BinaryReader r)
    {
        var o = new HouseOffer { Sign = r.ReadUInt32() };
        r.ReadUInt32();   // (its dwelling)
        o.Owner = r.ReadUInt32(); r.ReadUInt32();
        o.MinLevel = r.ReadInt32(); o.MaxLevel = r.ReadInt32(); o.MinRank = r.ReadInt32(); o.MaxRank = r.ReadInt32();
        o.Free = r.ReadUInt32() != 0; o.Type = (int)r.ReadUInt32();
        o.OwnerName = AcClient.ReadString16L(r);
        try { ReadPayments(r, o.Buy); ReadPayments(r, o.Rent); } catch (EndOfStreamException) { }
        Objects.Note($"house offer {o.TypeName} (sign {o.Sign:X8}, owner {o.Owner:X8} {o.OwnerName}): buy {string.Join(", ", o.Buy.Select(p => $"{p.Need} {p.Name} [wcid {p.Wcid}] paid {p.Paid}"))}; rent {string.Join(", ", o.Rent.Select(p => $"{p.Need} {p.Name} [wcid {p.Wcid}] paid {p.Paid}"))}");
        HouseOffered?.Invoke(o);
    }

    /// <summary>What of ours pays these (the things the house asks for, from the packs): the server takes what's due from them.
    /// Pyreals can be paid in coins or trade notes. Null if something's short (and what).</summary>
    public List<uint>? PaymentFrom(List<HousePayment> due, out string shortOf)
    {
        shortOf = "";
        var ids = new List<uint>();
        var mine = _held.Values.Where(h => h.Guid != 0 && Mine(h, out _)).ToList();
        foreach (var p in due)
        {
            if (p.Left <= 0) continue;
            long got = 0;
            bool pyreals = p.Wcid == 273;
            foreach (var h in mine.OrderBy(h => h.Wcid == p.Wcid ? 0 : 1))
            {
                if (got >= p.Left) break;
                bool coins = h.Wcid == p.Wcid;
                bool note = pyreals && !coins && h.Name.Contains("Trade Note", StringComparison.OrdinalIgnoreCase);
                if (!coins && !note) continue;
                ids.Add(h.Guid);
                got += coins ? Math.Max(1, h.Stack) : h.Value;
            }
            if (got < p.Left) shortOf += (shortOf.Length > 0 ? ", " : "") + $"{p.Left - got:N0} {p.Name}";
        }
        return shortOf.Length > 0 ? null : ids;
    }

    /// <summary>How many of a kind of thing we carry (pyreals: coins and trade notes' worth together).</summary>
    public long CarriedOf(uint wcid)
    {
        long n = 0;
        foreach (var h in _held.Values)
        {
            if (h.Guid == 0 || !Mine(h, out _)) continue;
            if (h.Wcid == wcid) n += Math.Max(1, h.Stack);
            else if (wcid == 273 && h.Name.Contains("Trade Note", StringComparison.OrdinalIgnoreCase)) n += h.Value;
        }
        return n;
    }

    /// <summary>Buys the house at this sign, or pays its upkeep, with these things of ours.</summary>
    public bool HousePay(HouseOffer o, bool buy, List<uint> items)
    {
        if (!_inWorld || Client == null) return false;
        var b = new byte[8 + 4 * items.Count];
        BitConverter.GetBytes(o.Sign).CopyTo(b, 0);
        BitConverter.GetBytes((uint)items.Count).CopyTo(b, 4);
        for (int i = 0; i < items.Count; i++) BitConverter.GetBytes(items[i]).CopyTo(b, 8 + 4 * i);
        Client.SendAction(buy ? 0x021Cu : 0x0221u, b);
        _houseAskedAt = -100;   // (the house tab asks again)
        return true;
    }

    /// <summary>The thing is in a creature's or another person's hand.</summary>
    public bool HeldByOther(uint guid) => guid != 0 && _heldBy.ContainsKey(guid);

    private void LetGo(uint child)
    {
        if (!_heldBy.Remove(child, out var h)) return;
        if (h.node != null && GodotObject.IsInstanceValid(h.node)) h.node.QueueFree();
    }

    // ── the server's own movement of us: a walk to a thing or a spot, a turn to a thing or a heading ──
    private (uint guid, Vector3 at, float within, float heading, double until)? _srvWalk;
    private float _srvWalkBest; private double _srvWalkBestAt;

    private void FollowServer(int kind, BinaryReader r)
    {
        if (kind == 6 || kind == 7)
        {
            uint target = kind == 6 ? r.ReadUInt32() : 0;
            uint cell = r.ReadUInt32();
            var o = new System.Numerics.Vector3(r.ReadSingle(), r.ReadSingle(), r.ReadSingle());
            r.ReadUInt32();                                   // (how it may move: walk, run, side-step...)
            float within = r.ReadSingle(); r.ReadSingle();    // (within this of it; the least to move)
            float fail = r.ReadSingle(); r.ReadSingle(); r.ReadSingle();
            float heading = r.ReadSingle();
            var at = target != 0 && _things.TryGetValue(target, out var ts) ? ts.Feet : Godot(cell, o);
            // (the client's own run up to something, or a melee charge, already going there: left to it)
            // (as is our own run up to something we used - it uses it on arriving: not taken over, or that use was lost)
            if (Player.ApproachTo != null && _srvWalk == null) { PosLog($"the server has us walking to a thing - our own {(Player.Charging ? "charge" : "walk")} is already on it"); return; }
            _srvWalk = (target, at, Math.Max(0.6f, within), heading, _clock + Math.Clamp(fail > 0 ? fail / 3f : 20f, 5f, 40f));
            _srvWalkBest = float.MaxValue; _srvWalkBestAt = _clock;
            PosLog($"the server has us walking to {(target == 0 ? "a spot" : _things.TryGetValue(target, out var tn) ? tn.Name : Named(target))} ({Player.Position.DistanceTo(at):0.0} m, till within {within:0.0} m) - following it");
        }
        else if (kind == 8)
        {
            uint target = r.ReadUInt32(); float heading = r.ReadSingle();
            if (_things.TryGetValue(target, out var ts))
            {
                var d = ts.Feet - Player.Position;
                if (new Vector2(d.X, d.Z).LengthSquared() > 1e-4f) Player.TurnToYaw = MathF.Atan2(-d.X, -d.Z);
            }
            else Player.TurnToYaw = -heading * MathF.PI / 180f;
            _srvTurnYaw = Player.TurnToYaw;
            PosLog($"the server has us turning to {(_things.TryGetValue(target, out var tn2) ? tn2.Name : Named(target))} - following it");
        }
        else if (kind == 9)
        {
            r.ReadUInt32(); r.ReadSingle(); float heading = r.ReadSingle();
            Player.TurnToYaw = -heading * MathF.PI / 180f;
            _srvTurnYaw = Player.TurnToYaw;
            PosLog($"the server has us turning to heading {heading:0} - following it");
        }
    }

    // each frame while the server walks us: on toward it (a thing that moves, followed) till within reach - called off by
    // our own steering, a time limit, or the server moving us elsewhere
    private void UpdateServerWalk()
    {
        if (_srvWalk is not { } w) return;
        bool done = false; string why = "";
        if (!_inWorld || !_placed || Player.Dead) { done = true; why = "not in the world"; }
        else if (Player.MovedByKeys) { done = true; why = "steered off it"; }
        else if (Player.ApproachTo is { } own && own.DistanceTo(w.at) > 0.5f && _srvWalkBestAt < _clock - 0.05) { done = true; why = "our own walk took over"; }
        else if (_clock > w.until) { done = true; why = "took too long"; }
        else
        {
            var at = w.guid != 0 && _things.TryGetValue(w.guid, out var ts) ? ts.Feet : w.at;
            var d = at - Player.Position;
            float dist = new Vector2(d.X, d.Z).Length();
            // (the server's reach is edge to edge - its width and ours on top: measured centre to centre here)
            // (as near as it asks, our width on top - not a generous bit more: stopped 0.8 m short, the server, which
            // measures it itself, never had us there and the use was dropped)
            float theirs = w.guid != 0 && _things.TryGetValue(w.guid, out var tg) ? Math.Min(tg.Radius, 0.5f) : 0f;
            if (dist <= w.within + 0.3f + theirs * 0.5f) { done = true; why = "there"; }
            // (not getting any nearer for a second - up against it, or something in the way: stopped, not run on the spot)
            else if (_srvWalkBest - dist < 0.1f && _clock - _srvWalkBestAt > 2.0) { done = true; why = "no nearer in 2 s (against it?)"; }
            else
            {
                if (dist < _srvWalkBest - 0.1f) { _srvWalkBest = dist; _srvWalkBestAt = _clock; }
                Player.ApproachTo = at; _srvWalk = (w.guid, at, w.within, w.heading, w.until);
            }
        }
        if (!done) return;
        _srvWalk = null;
        // (only the approach this set: our own walk or charge, started since, carries on)
        if (!Player.Charging && Player.ApproachTo is { } ap && ap.DistanceTo(w.at) < 0.5f) Player.ApproachTo = null;
        PosLog($"the server's walk ended: {why} ({Player.Position.DistanceTo(w.at):0.0} m from it)");
        if (why == "there") HereFirst();   // (where we stopped, to the server straight away)
    }

    /// <summary>Told of each thing the server has our character do once (a cast's gestures among them), as it starts.</summary>
    public Action<uint, float>? SelfGesture;
    private const uint Sanctuary = 0x10000057;
    /// <summary>Told of a gesture the server has our character make (one we didn't start): the motion and its speed.</summary>
    public Action<uint, float>? SelfAction;
    /// <summary>Shooting: the aim or reload the server has us in (0: back to ready).</summary>
    public Action<uint>? SelfMissilePose;

    // a spell's bolt with nothing to draw: a ball in its element's colour (by its name)
    private static Color GlowOf(string name)
    {
        string n = name.ToLowerInvariant();
        return n.Contains("flame") || n.Contains("fire") ? new Color(1f, 0.45f, 0.1f) : n.Contains("frost") || n.Contains("cold") || n.Contains("ice") ? new Color(0.55f, 0.85f, 1f)
             : n.Contains("acid") ? new Color(0.4f, 1f, 0.3f) : n.Contains("lightning") || n.Contains("shock") ? new Color(0.75f, 0.6f, 1f)
             : n.Contains("nether") || n.Contains("corro") ? new Color(0.5f, 0.2f, 0.7f) : new Color(0.95f, 0.95f, 0.85f);
    }

    // a thing's movement as the server describes it (in a motion message, or with the thing when it's first seen)
    private void ApplyMovement(BinaryReader r, ObjectStreamer.Selectable sel)
    {
        int kind = r.ReadByte(); int mflags = r.ReadByte(); uint style = r.ReadUInt16();
        if (style != 0) style |= 0x80000000u;
        if (kind == 0)
        {
            // what it's doing: a stance, standing or walking or running (or lying dead), and things done once (blows)
            uint f = r.ReadUInt32(); int n = (int)(f >> 7);
            uint st = style, forward = 0; float speed = 1f;
            if ((f & 0x1) != 0) { uint s = r.ReadUInt16(); if (s != 0) st = s | 0x80000000u; }
            if ((f & 0x2) != 0) forward = AcDream.Core.Physics.MotionCommandResolver.ReconstructFullCommand(r.ReadUInt16());
            float side = 0f, turn = 0f;
            bool hasSide = (f & 0x8) != 0, hasTurn = (f & 0x20) != 0;
            if (hasSide) r.ReadUInt16();
            if (hasTurn) r.ReadUInt16();
            if ((f & 0x4) != 0) speed = r.ReadSingle();
            if ((f & 0x10) != 0) side = r.ReadSingle(); else if (hasSide) side = 1f;     // (to the right; below zero, to the left)
            if ((f & 0x40) != 0) turn = r.ReadSingle(); else if (hasTurn) turn = 1f;
            var once = new List<(uint, float)>();
            for (int i = 0; i < n && i < 16; i++) { uint m = AcDream.Core.Physics.MotionCommandResolver.ReconstructFullCommand(r.ReadUInt16()); r.ReadUInt16(); once.Add((m, r.ReadSingle())); }
            // (side-stepping and turning as they go is a player's, steered by keys: a creature turns to face what it's
            // after when told to - a turn carried on from here left it spinning on the spot)
            if (sel.Kind < 3) { side = 0f; turn = 0f; }
            Objects.SetThingMotion(sel, st, forward, speed, once, side, turn);
            return;
        }
        // (walked or turned by the server: any side-step or turn it was doing by keys is over)
        if (kind >= 6) Objects.StopStepping(sel);
        if (kind == 6 || kind == 7)
        {
            // going after something, or to a spot (a creature closing on you): run there, stopping as far short as told
            uint target = kind == 6 ? r.ReadUInt32() : 0;
            uint cell = r.ReadUInt32(); var spot = new System.Numerics.Vector3(r.ReadSingle(), r.ReadSingle(), r.ReadSingle());
            r.ReadUInt32(); float within = r.ReadSingle(); r.ReadSingle(); r.ReadSingle(); float mspeed = r.ReadSingle(); r.ReadSingle(); r.ReadSingle();
            float runRate = r.ReadSingle();
            var fixedAt = Godot(cell, spot);
            Func<Vector3?> toward = kind == 7 ? () => fixedAt
                : target == _me ? () => Player.Position
                : () => _things.TryGetValue(target, out var ts) && !ts.Gone ? ts.Feet : null;
            Objects.SendThingToward(sel, toward, within, runRate * (mspeed > 0f ? mspeed : 1f), style);
            return;
        }
        if (kind == 8)
        {
            uint target = r.ReadUInt32();
            Vector3 at;
            if (target == _me) at = Player.Position;
            else if (_things.TryGetValue(target, out var ts)) at = ts.Feet;
            else return;
            var d = at - sel.Feet;
            if (new Vector2(d.X, d.Z).LengthSquared() > 1e-4f) Objects.TurnThing(sel, MathF.Atan2(-d.X, -d.Z));
        }
        else if (kind == 9)
        {
            r.ReadUInt32(); r.ReadSingle();
            float heading = r.ReadSingle();   // degrees, clockwise from north
            Objects.TurnThing(sel, -heading * MathF.PI / 180f);
        }
    }

    /// <summary>Our character's numbers here (kept as the server has them).</summary>
    public Combat.Character? Me;
    /// <summary>Told when the server has changed them (experience, level, an attribute or skill).</summary>
    public Action? StatsChanged;

    /// <summary>Asks the server to raise or train: 0 an attribute (0-5), 1 a vital (0-2), 2 a skill, 3 a skill trained; with the experience (or credits) spent.</summary>
    public void Raise(int kind, int id, long cost)
    {
        if (!_inWorld || Client == null) return;
        // several raises of the one thing asked at once (+10): one request with what they cost together, as the
        // game's own client sends it - the server then says where it ended up once, not for every point
        if (kind != 3)
        {
            if (_raising.TryGetValue((kind, id), out long sofar)) { _raising[(kind, id)] = sofar + cost; return; }
            _raising[(kind, id)] = cost;
            _soon.Add((_clock, () => { if (_raising.Remove((kind, id), out long all)) SendRaise(kind, id, all); }));
            return;
        }
        SendRaise(kind, id, cost);
    }
    private readonly Dictionary<(int kind, int id), long> _raising = new();
    private void SendRaise(int kind, int id, long cost)
    {
        if (Client == null) return;
        var b = new byte[8];
        uint which = kind switch { 0 => (uint)id + 1, 1 => (uint)id * 2 + 1, _ => (uint)id };
        BitConverter.GetBytes(which).CopyTo(b, 0); BitConverter.GetBytes((uint)Math.Clamp(cost, 0, uint.MaxValue)).CopyTo(b, 4);
        Client.SendAction(kind switch { 0 => 0x0045u, 1 => 0x0044u, 2 => 0x0046u, _ => 0x0047u }, b);
    }

    /// <summary>Told when the server says what was asked of it is over.</summary>
    public Action? UseDone;
    /// <summary>Told (before UseDone) when what was asked didn't come off: a cast with too little mana, a thing out of reach.</summary>
    public Action? UseFailed;

    // why the server wouldn't: said as the game says it where known, else by its number
    /// <summary>Asks the server for a recall (the action's number: to the lifestone 0x63, the marketplace 0x28D, the house
    /// 0x262, the mansion 0x278, the allegiance's hometown 0x2AB, the arenas 0x27 / 0x26). False: not on a server.</summary>
    public bool Recall(uint action)
    {
        if (!_inWorld || Client == null) return false;
        HereFirst();
        Client.SendAction(action, Array.Empty<byte>());
        return true;
    }

    /// <summary>Told when the server says we killed something (its line about it).</summary>
    public Action<string>? Killed;
    /// <summary>Told what goes on the line at the top of the screen (too busy, not ready, ...).</summary>
    public Action<string>? Status;

    private string UnknownError(uint err, string about)
    {
        if (WeenieErrors.WithWord.TryGetValue(err, out var f)) return f.Replace("{0}", about);
        return UnknownError2(err, about);
    }
    private string UnknownError2(uint err, string about) { Unknown("error with words", err, System.Text.Encoding.UTF8.GetBytes(about)); return $"[Network] (error 0x{err:X}: {about})"; }

    private uint _lastActed;   // the thing last asked about (an error with a gap for a name is about it)
    private void Refused(uint error, string? about = null)
    {
        if (error == 0 || error == 0x051D || error == 0x003C) return;   // (0x51D: only that the chat channels are on; 0x3C: that we've teleported)
        string? text = error switch
        {
            0x001D => "You're too busy!",
            0x003D => "You charged too far!",
            0x0036 => "Action cancelled.",
            0x0039 => "You can't get there.",
            0x003E => "You are too tired to do that!",
            0x03FE => "You don't know that spell!",
            0x03FF => "That's not a valid target for that spell.",
            0x0400 => "You don't have all the components for this spell.",
            0x0401 => "You don't have enough Mana to cast this spell.",
            0x0402 => "Your spell fizzled.",
            0x0406 => "Your target is out of range.",
            0x042C => "Target not acquired.",
            0x0550 => "Your target is out of range.",
            _ => null,
        };
        // (what the game says at the top of the screen; one we've no words for goes to the chat as it came)
        // (one with no wording of ours: the game's own, where its list has it)
        if (text == null && WeenieErrors.Text.TryGetValue(error, out var known)) text = known;
        // (the game's wording leaves a gap, "_", for the thing it's about - the thing that wouldn't move)
        if (text != null && text.Contains('_')) text = text.Replace("_", !string.IsNullOrEmpty(about) ? about : _held.TryGetValue(_lastActed, out var acted) ? acted.Name : "That");
        if (text == null) Unknown("error", error, null);
        if (text != null && Status != null) Status(text);
        else Say?.Invoke(text ?? $"[Network] (error 0x{error:X})", SysColor, ChatKind.Gameplay);
    }

    // ── friends and the fellowship ──

    public sealed class Friend { public uint Id; public string Name = ""; public bool Online; }
    public sealed class Fellow { public uint Id; public string Name = ""; public int Level, Health, MaxHealth, Stamina, MaxStamina, Mana, MaxMana; }
    public readonly List<Friend> Friends = new();
    public readonly List<Fellow> Fellows = new();
    public string FellowshipName = "";
    public uint FellowLeader;
    public bool LeadsFellowship => FellowLeader != 0 && FellowLeader == _me;
    /// <summary>Told when the friends list or the fellowship changes.</summary>
    public Action? SocialChanged;

    /// <summary>The server asks yes or no: the kind of question (1 swearing allegiance, 2 a skill changed, 3 an attribute, 4 a
    /// fellowship's invitation, 5 a craft, 6 an augmentation, 7 any other), its number to answer with, and its words.</summary>
    public Action<uint, uint, string>? ConfirmAsked;
    public Action? ConfirmDone;
    public void Confirm(uint kind, uint context, bool yes)
    {
        if (!_inWorld || Client == null) return;
        var ms = new MemoryStream(); var w = new BinaryWriter(ms);
        w.Write(kind); w.Write(context); w.Write(yes ? 1 : 0);
        Client.SendAction(0x0275, ms.ToArray());
        if (kind == 1) _allegianceAsked = -100;
    }

    // ── the character's options (kept by the server) ──

    /// <summary>The two sets of option switches as the server has them (read at login).</summary>
    public uint Options1 = 0x50C4A54A, Options2 = 0x948700;
    public bool OptionsRead;
    /// <summary>An option's switches: its number (as the server is told of a change), which set it's in (1 or 2) and its bit.</summary>
    public static readonly Dictionary<string, (uint id, int set, uint bit)> OptionBits = new()
    {
        ["AutoRepeatAttacks"] = (0x00, 1, 0x00000002u),
        ["IgnoreAllegianceRequests"] = (0x01, 1, 0x00000004u),
        ["IgnoreFellowshipRequests"] = (0x02, 1, 0x00000008u),
        ["IgnoreAllTradeRequests"] = (0x03, 1, 0x00020000u),
        ["DisableMostWeatherEffects"] = (0x04, 1, 0x00010000u),
        ["AlwaysDaylightOutdoors"] = (0x05, 2, 0x00000001u),
        ["LetOtherPlayersGiveYouItems"] = (0x06, 1, 0x00000040u),
        ["KeepCombatTargetsInView"] = (0x07, 1, 0x00000080u),
        ["Display3dTooltips"] = (0x08, 1, 0x00000100u),
        ["AttemptToDeceiveOtherPlayers"] = (0x09, 1, 0x00000200u),
        ["RunAsDefaultMovement"] = (0x0A, 1, 0x00000400u),
        ["StayInChatModeAfterSendingMessage"] = (0x0B, 1, 0x00000800u),
        ["AdvancedCombatInterface"] = (0x0C, 1, 0x00001000u),
        ["AutoTarget"] = (0x0D, 1, 0x00002000u),
        ["VividTargetingIndicator"] = (0x0E, 1, 0x00008000u),
        ["ShareFellowshipExpAndLuminance"] = (0x0F, 1, 0x00040000u),
        ["AcceptCorpseLootingPermissions"] = (0x10, 1, 0x00080000u),
        ["ShareFellowshipLoot"] = (0x11, 1, 0x00100000u),
        ["AutomaticallyAcceptFellowshipRequests"] = (0x12, 1, 0x20000000u),
        ["SideBySideVitals"] = (0x13, 1, 0x00200000u),
        ["ShowCoordinatesByTheRadar"] = (0x14, 1, 0x00400000u),
        ["DisplaySpellDurations"] = (0x15, 1, 0x00800000u),
        ["DisableHouseRestrictionEffects"] = (0x16, 1, 0x02000000u),
        ["DragItemToPlayerOpensTrade"] = (0x17, 1, 0x04000000u),
        ["ShowAllegianceLogons"] = (0x18, 1, 0x08000000u),
        ["UseChargeAttack"] = (0x19, 1, 0x10000000u),
        ["UseCraftingChanceOfSuccessDialog"] = (0x1A, 1, 0x80000000u),
        ["ListenToAllegianceChat"] = (0x1B, 1, 0x40000000u),
        ["AllowOthersToSeeYourDateOfBirth"] = (0x1C, 2, 0x00000002u),
        ["AllowOthersToSeeYourAge"] = (0x1D, 2, 0x00000020u),
        ["AllowOthersToSeeYourChessRank"] = (0x1E, 2, 0x00000004u),
        ["AllowOthersToSeeYourFishingSkill"] = (0x1F, 2, 0x00000008u),
        ["AllowOthersToSeeYourNumberOfDeaths"] = (0x20, 2, 0x00000010u),
        ["DisplayTimestamps"] = (0x21, 2, 0x00000040u),
        ["SalvageMultipleMaterialsAtOnce"] = (0x22, 2, 0x00000080u),
        ["ListenToGeneralChat"] = (0x23, 2, 0x00000100u),
        ["ListenToTradeChat"] = (0x24, 2, 0x00000200u),
        ["ListenToLFGChat"] = (0x25, 2, 0x00000400u),
        ["ListenToRoleplayChat"] = (0x26, 2, 0x00000800u),
        ["AppearOffline"] = (0x27, 2, 0x00001000u),
        ["AllowOthersToSeeYourNumberOfTitles"] = (0x28, 2, 0x00002000u),
        ["UseMainPackAsDefaultForPickingUpItems"] = (0x29, 2, 0x00004000u),
        ["LeadMissileTargets"] = (0x2A, 2, 0x00008000u),
        ["UseFastMissiles"] = (0x2B, 2, 0x00010000u),
        ["FilterLanguage"] = (0x2C, 2, 0x00020000u),
        ["ConfirmUseOfRareGems"] = (0x2D, 2, 0x00040000u),
        ["ListenToSocietyChat"] = (0x2E, 2, 0x00080000u),
        ["ShowYourHelmOrHeadGear"] = (0x2F, 2, 0x00100000u),
        ["DisableDistanceFog"] = (0x30, 2, 0x00200000u),
        ["UseMouseTurning"] = (0x31, 2, 0x00400000u),
        ["ShowYourCloak"] = (0x32, 2, 0x00800000u),
        ["LockUI"] = (0x33, 2, 0x01000000u),
        ["ListenToPKDeathMessages"] = (0x34, 2, 0x02000000u),
    };
    public bool Option(string name) => OptionBits.TryGetValue(name, out var o) && ((o.set == 1 ? Options1 : Options2) & o.bit) != 0;
    public Action<string, bool>? OptionChanged;
    public void SetOption(string name, bool on)
    {
        if (!OptionBits.TryGetValue(name, out var o)) return;
        if (o.set == 1) Options1 = on ? Options1 | o.bit : Options1 & ~o.bit; else Options2 = on ? Options2 | o.bit : Options2 & ~o.bit;
        if (_inWorld && Client != null)
        {
            var ms = new MemoryStream(); var w = new BinaryWriter(ms);
            w.Write(o.id); w.Write(on ? 1u : 0u);
            Client.SendAction(0x0005, ms.ToArray());
        }
        OptionChanged?.Invoke(name, on);
    }

    // ── salvaging ──

    /// <summary>The materials things are made of, by the game's numbers.</summary>
    public static readonly Dictionary<int, string> Materials = new() { [1] = "Ceramic", [2] = "Porcelain", [3] = "Cloth", [4] = "Linen", [5] = "Satin", [6] = "Silk", [7] = "Velvet", [8] = "Wool", [9] = "Gem", [10] = "Agate", [11] = "Amber", [12] = "Amethyst", [13] = "Aquamarine", [14] = "Azurite", [15] = "Black Garnet", [16] = "Black Opal", [17] = "Bloodstone", [18] = "Carnelian", [19] = "Citrine", [20] = "Diamond", [21] = "Emerald", [22] = "Fire Opal", [23] = "Green Garnet", [24] = "Green Jade", [25] = "Hematite", [26] = "Imperial Topaz", [27] = "Jet", [28] = "Lapis Lazuli", [29] = "Lavender Jade", [30] = "Malachite", [31] = "Moonstone", [32] = "Onyx", [33] = "Opal", [34] = "Peridot", [35] = "Red Garnet", [36] = "Red Jade", [37] = "Rose Quartz", [38] = "Ruby", [39] = "Sapphire", [40] = "Smokey Quartz", [41] = "Sunstone", [42] = "Tiger Eye", [43] = "Tourmaline", [44] = "Turquoise", [45] = "White Jade", [46] = "White Quartz", [47] = "White Sapphire", [48] = "Yellow Garnet", [49] = "Yellow Topaz", [50] = "Zircon", [51] = "Ivory", [52] = "Leather", [53] = "Armoredillo Hide", [54] = "Gromnie Hide", [55] = "Reed Shark Hide", [56] = "Metal", [57] = "Brass", [58] = "Bronze", [59] = "Copper", [60] = "Gold", [61] = "Iron", [62] = "Pyreal", [63] = "Silver", [64] = "Steel", [65] = "Stone", [66] = "Alabaster", [67] = "Granite", [68] = "Marble", [69] = "Obsidian", [70] = "Sandstone", [71] = "Serpentine", [72] = "Wood", [73] = "Ebony", [74] = "Mahogany", [75] = "Oak", [76] = "Pine", [77] = "Teak" };
    /// <summary>Told when the server has answered a salvaging.</summary>
    public Action? Salvaged;
    /// <summary>Salvages things of ours with an Ust (the server makes the bags of salvage and says what came of it).</summary>
    public bool Salvage(Combat.Item ust, IEnumerable<Combat.Item> things)
    {
        var ids = things.Where(t => t.Guid != 0 && t != ust).Select(t => t.Guid).Distinct().ToList();
        if (!_inWorld || Client == null || ust.Guid == 0 || ids.Count == 0) return false;
        var ms = new MemoryStream(); var w = new BinaryWriter(ms);
        w.Write(ust.Guid); w.Write((uint)ids.Count);
        foreach (uint id in ids) w.Write(id);
        Client.SendAction(0x027D, ms.ToArray());
        _invDirty = true;
        return true;
    }

    // ── the allegiance ──

    public sealed class AllegianceMember { public uint Id, Parent, XpCached, XpGenerated, Level; public int Rank; public bool Online; public string Name = ""; }
    /// <summary>Our allegiance as the server last told it: its name (empty: none), our rank, the monarch, our patron, our vassals.</summary>
    public string AllegianceName = "";
    public int AllegianceRank, AllegianceMembers, AllegianceFollowers;
    public AllegianceMember? Monarch, Patron, AllegianceSelf;
    public readonly List<AllegianceMember> Vassals = new();
    public bool AllegianceRead;
    private double _allegianceAsked = -100;

    /// <summary>Asks the server for our allegiance (the social panel's page opened); not more than every few seconds.</summary>
    public void AskAllegiance()
    {
        if (!_inWorld || Client == null || _clock - _allegianceAsked < 4) return;
        _allegianceAsked = _clock;
        Client.SendAction(0x001F, BitConverter.GetBytes(1u));
    }
    /// <summary>Swears allegiance to a player (the one selected).</summary>
    public bool Swear(ObjectStreamer.Selectable to)
    {
        uint g = GuidOf(to);
        if (g == 0 || g == _me || !_inWorld) return false;
        Client?.SendAction(0x001D, BitConverter.GetBytes(g));
        _allegianceAsked = -100;
        return true;
    }
    /// <summary>Breaks from our patron, or with one of our vassals.</summary>
    public void BreakAllegiance(uint who) { if (who != 0 && _inWorld) { Client?.SendAction(0x001E, BitConverter.GetBytes(who)); _allegianceAsked = -100; } }
    /// <summary>The monarch's: puts someone out of the allegiance, by name.</summary>
    public void BootFromAllegiance(string name)
    {
        if (!_inWorld || Client == null || name.Length == 0) return;
        var ms = new MemoryStream(); var w = new BinaryWriter(ms);
        AcClient.WriteString16L(w, name); w.Write(0u);
        Client.SendAction(0x0277, ms.ToArray());
        _allegianceAsked = -100;
    }

    private void ReadAllegiance(BinaryReader r)
    {
        Vassals.Clear(); Monarch = Patron = AllegianceSelf = null; AllegianceName = "";
        AllegianceRead = true;
        try
        {
            AllegianceRank = (int)r.ReadUInt32();
            AllegianceMembers = (int)r.ReadUInt32();
            AllegianceFollowers = (int)r.ReadUInt32();
            int records = r.ReadUInt16(); r.ReadUInt16();
            int officers = r.ReadUInt16(); r.ReadUInt16();
            for (int i = 0; i < officers; i++) { r.ReadUInt32(); r.ReadUInt32(); }
            int titles = r.ReadInt32();
            for (int i = 0; i < titles && i < 16; i++) AcClient.ReadString16L(r);
            r.ReadUInt32(); r.ReadUInt32(); r.ReadUInt32(); r.ReadUInt32();
            AcClient.ReadString16L(r); AcClient.ReadString16L(r);   // the message of the day, and who set it
            r.ReadUInt32();                                         // the chat room
            r.ReadBytes(32);                                        // the allegiance's hometown (a cell, a place, a facing)
            string name = AcClient.ReadString16L(r);
            r.ReadUInt32(); r.ReadUInt32(); r.ReadInt32();
            AllegianceMember One(uint parent)
            {
                var m = new AllegianceMember { Parent = parent, Id = r.ReadUInt32(), XpCached = r.ReadUInt32(), XpGenerated = r.ReadUInt32() };
                uint bits = r.ReadUInt32();
                m.Online = (bits & 0x1) != 0;
                r.ReadByte(); r.ReadByte(); m.Rank = r.ReadUInt16();
                if ((bits & 0x8) != 0) m.Level = r.ReadUInt32();
                r.ReadUInt16(); r.ReadUInt16();   // loyalty, leadership
                r.ReadUInt64();                   // time online (and how long sworn)
                m.Name = AcClient.ReadString16L(r).TrimStart('+');
                return m;
            }
            if (records > 0)
            {
                Monarch = One(0);
                var rest = new List<AllegianceMember>();
                for (int i = 1; i < records; i++) rest.Add(One(r.ReadUInt32()));
                AllegianceSelf = Monarch.Id == _me ? Monarch : rest.FirstOrDefault(m => m.Id == _me);
                if (AllegianceSelf != null && AllegianceSelf != Monarch)
                    Patron = AllegianceSelf.Parent == Monarch.Id ? Monarch : rest.FirstOrDefault(m => m.Id == AllegianceSelf.Parent);
                Vassals.AddRange(rest.Where(m => m.Parent == _me && m.Id != _me));
                AllegianceName = name.Length > 0 ? name : Monarch.Name;
            }
        }
        catch (EndOfStreamException) { }
        catch (Exception ex) { GD.PushWarning("allegiance: " + ex.Message); }
        SocialChanged?.Invoke();
    }

    private static Fellow ReadFellow(BinaryReader r)
    {
        var f = new Fellow { Id = r.ReadUInt32() };
        r.ReadUInt32(); r.ReadUInt32();
        f.Level = (int)r.ReadUInt32();
        f.MaxHealth = (int)r.ReadUInt32(); f.MaxStamina = (int)r.ReadUInt32(); f.MaxMana = (int)r.ReadUInt32();
        f.Health = (int)r.ReadUInt32(); f.Stamina = (int)r.ReadUInt32(); f.Mana = (int)r.ReadUInt32();
        r.ReadUInt32();
        f.Name = AcClient.ReadString16L(r);
        return f;
    }

    private void SendText(uint action, string text, params uint[] after)
    {
        if (!_inWorld || Client == null) return;
        using var b = new MemoryStream();
        var w = new BinaryWriter(b);
        AcClient.WriteString16L(w, text);
        foreach (uint v in after) w.Write(v);
        Client.SendAction(action, b.ToArray());
    }
    public void AddFriend(string name) { if (name.Trim().Length > 0) SendText(0x0018, name.Trim()); }
    public void RemoveFriend(uint id) { if (_inWorld) Client?.SendAction(0x0017, BitConverter.GetBytes(id)); }
    public void CreateFellowship(string name, bool shareXp) { if (name.Trim().Length > 0) SendText(0x00A2, name.Trim(), shareXp ? 1u : 0u); }
    /// <summary>Leaves the fellowship (its leader: or disbands it).</summary>
    public void QuitFellowship(bool disband) { if (_inWorld) Client?.SendAction(0x00A3, BitConverter.GetBytes(disband ? 1u : 0u)); }
    public void RecruitFellow(ObjectStreamer.Selectable who) { uint g = GuidOf(who); if (g != 0 && _inWorld) Client?.SendAction(0x00A5, BitConverter.GetBytes(g)); }
    public void DismissFellow(uint id) { if (_inWorld) Client?.SendAction(0x00A4, BitConverter.GetBytes(id)); }
    /// <summary>Hands the fellowship to another fellow (its leader's to do).</summary>
    public void FellowLeaderTo(uint id) { if (_inWorld && id != 0) Client?.SendAction(0x0290, BitConverter.GetBytes(id)); }
    /// <summary>Whether anyone in it can recruit (open) or only its leader - as last set from here.</summary>
    public bool FellowshipOpen;
    public void FellowOpenness(bool open) { if (!_inWorld) return; FellowshipOpen = open; Client?.SendAction(0x0291, BitConverter.GetBytes(open ? 1u : 0u)); }

    // ── a corpse or chest open on the ground ──

    private uint _openContainer;
    private bool _containerDirty;
    /// <summary>Told what's in the corpse or chest that's open (its name, its things) - again as that changes; null: it's shut.</summary>
    public Action<string, List<Combat.Item>?>? ContainerShown;
    /// <summary>Takes a thing out of the open corpse or chest, into the pack.</summary>
    public void TakeOut(Combat.Item it) => ItemAction(0x0019, it.Guid, _me, 0);
    /// <summary>The corpse or chest that's open (the server's number for it; 0: none), and what's in it.</summary>
    public uint OpenContainer => _openContainer;
    /// <summary>The open container's own picture (its icon).</summary>
    public uint OpenContainerIcon => _held.TryGetValue(_openContainer, out var oi) ? oi.Icon : 0;
    /// <summary>What's in a container (one of an open chest's packs), as far as the server has said.</summary>
    public List<Combat.Item> ContentsOf(uint box) => _held.Values.Where(h => h.Container == box && box != 0).Select(ItemOf).ToList();
    /// <summary>How many things the open container holds (a house's hook: one), 0 if not known.</summary>
    public int OpenContainerSlots => _held.TryGetValue(_openContainer, out var oc) ? oc.Capacity : 0;
    /// <summary>How many packs the open container takes (-1: not said).</summary>
    public int OpenContainerPackSlots => _held.TryGetValue(_openContainer, out var oc) ? oc.PackSlots : -1;
    /// <summary>The open corpse or chest shut from here (its window closed): the server's told we're done looking in it.</summary>
    public void CloseContainer()
    {
        if (_openContainer == 0) return;
        if (_inWorld) Client?.SendAction(0x0195, BitConverter.GetBytes(_openContainer));
        _openContainer = 0;
    }
    public List<Combat.Item> OpenContents() => _openContainer == 0 ? new() : _held.Values.Where(h => h.Container == _openContainer).Select(ItemOf).ToList();
    /// <summary>The time on the server's clock (seconds, as the game counts them), kept running between its updates; 0: not known.</summary>
    public double ServerClock => Client?.ServerTime ?? 0;

    // ── fighting: attacks are asked of the server ──

    private static readonly Color HitColor = new(1f, 0.42f, 1f), HurtColor = new(1f, 0.27f, 0.22f);   // (as the game colours them: your blows rose, theirs red)

    /// <summary>The game's colour for a kind of chat line (the kind the server sends with it).</summary>
    private static Color ChatColor(uint type) => type switch
    {
        0 or 1 or 6 or 16 or 25 => new Color(0.55f, 0.95f, 0.45f),   // what happens in the world (a kill among them), what you find looking at something: green
        2 => Colors.White,                                            // said aloud
        3 or 19 => new Color(1f, 1f, 0.45f),                          // a tell, the fellowship: yellow
        4 or 10 or 11 or 18 or 24 => new Color(0.85f, 0.75f, 0.4f),   // your own tells, allegiance, crafting: a duller yellow
        5 => new Color(0.85f, 0.45f, 1f),                             // the system: purple
        21 => new Color(1f, 0.27f, 0.22f),                            // what's done to you in a fight: red (and only that)
        7 or 17 => new Color(0.45f, 0.75f, 1f),                       // magic and spell words: light blue
        8 or 9 or 22 => new Color(1f, 0.42f, 1f),                     // what you and your pets do in a fight: the game's bright purple
        12 => new Color(0.7f, 0.7f, 0.7f),                            // an emote: grey
        13 or 14 or 15 or 23 => new Color(0.35f, 0.95f, 1f),          // advancement, help, recalls: cyan
        20 => new Color(1f, 0.6f, 0.25f),                             // to the whole world: orange
        _ => SysColor,
    };
    public Action? AttackDone;
    public Action<ObjectStreamer.Selectable, float>? HealthRead;

    /// <summary>Attacks a creature of the server's (height 0 high, 1 middle, 2 low; power or accuracy 0-1).</summary>
    public void Attack(ObjectStreamer.Selectable sel, int height, float power, bool missile)
    {
        uint g = GuidOf(sel);
        if (g == 0 || !_inWorld || Client == null) return;
        HereFirst();
        var b = new byte[12];
        BitConverter.GetBytes(g).CopyTo(b, 0); BitConverter.GetBytes((uint)(Math.Clamp(height, 0, 2) + 1)).CopyTo(b, 4); BitConverter.GetBytes(Math.Clamp(power, 0f, 1f)).CopyTo(b, 8);
        Client.SendAction(missile ? 0x000Au : 0x0008u, b);
    }
    public void CancelAttack() { if (_inWorld) Client?.SendAction(0x01B7, Array.Empty<byte>()); }
    /// <summary>The stance, to the server: 1 peace, 2 melee, 4 missile, 8 magic.</summary>
    /// <summary>The titles the character has earned (their numbers), and the one shown under the name.</summary>
    public readonly List<uint> Titles = new();
    public uint DisplayTitle;
    public Action? TitlesChanged;
    /// <summary>Shows one of our titles (SetDisplayCharacterTitle).</summary>
    public void SetTitle(uint title)
    {
        if (!_inWorld || Client == null || !Titles.Contains(title)) return;
        var b = new byte[8];
        BitConverter.GetBytes(title).CopyTo(b, 0); BitConverter.GetBytes(1u).CopyTo(b, 4);
        Client.SendAction(0x002C, b);
        DisplayTitle = title;
        TitlesChanged?.Invoke();
    }
    // ---- pack order, written to the log: what the client shows before logging out and what the server lists at login, and
    // each thing that changes the order meanwhile - to find where what's shown and what the server keeps part ways ----
    /// <summary>Who the server says is attacking us now (0: no one).</summary>
    public uint CurrentAttacker { get; private set; }
    public event Action<uint>? AttackerChanged;

    // ── the global channels (TurbineChat): room number -> its name and chat tab ──
    private readonly Dictionary<uint, (string name, ChatKind kind)> _rooms = new();
    private static readonly Dictionary<string, (uint room, uint type)> StockRooms = new(StringComparer.OrdinalIgnoreCase)
    {
        ["General"] = (2, 2), ["Trade"] = (3, 3), ["LFG"] = (4, 4), ["Roleplay"] = (5, 5), ["Society"] = (6, 6), ["Olthoi"] = (10, 10),
    };
    private static string ReadWide(BinaryReader r)
    {
        int n = r.ReadByte();
        if ((n & 0x80) != 0) n = ((n & 0x7F) << 8) | r.ReadByte();
        return System.Text.Encoding.Unicode.GetString(r.ReadBytes(n * 2));
    }
    private static void WriteWide(BinaryWriter w, string s)
    {
        if (s.Length < 128) w.Write((byte)s.Length); else { w.Write((byte)(0x80 | (s.Length >> 8))); w.Write((byte)(s.Length & 0xFF)); }
        w.Write(System.Text.Encoding.Unicode.GetBytes(s));
    }
    private static Color RoomColor(ChatKind k) => k switch
    {
        ChatKind.Allegiance => new Color(0.45f, 1f, 0.45f), ChatKind.Trade => new Color(1f, 0.75f, 0.45f),
        ChatKind.LFG => new Color(0.75f, 0.6f, 1f), ChatKind.Roleplay => new Color(1f, 0.6f, 0.8f), ChatKind.Society => new Color(0.6f, 1f, 0.9f),
        _ => new Color(0.55f, 0.85f, 1f),
    };

    private void TurbineChat(BinaryReader r)
    {
        r.ReadUInt32();
        uint blob = r.ReadUInt32(), dispatch = r.ReadUInt32();
        r.ReadUInt32(); r.ReadUInt32(); r.ReadUInt32(); r.ReadUInt32(); r.ReadUInt32(); r.ReadUInt32();
        if (blob != 1 || dispatch != 1) return;   // (only what's said in a room - the answers to ours aren't needed)
        uint room = r.ReadUInt32();
        string who = ReadWide(r), text = ReadWide(r);
        r.ReadUInt32(); uint sender = r.ReadUInt32(); r.ReadUInt32(); uint type = r.ReadUInt32();
        var (name, kind) = _rooms.TryGetValue(room, out var rm) ? rm
            : type switch { 1 => ("Allegiance", ChatKind.Allegiance), 2 => ("General", ChatKind.General), 3 => ("Trade", ChatKind.Trade), 4 => ("LFG", ChatKind.LFG),
                            5 => ("Roleplay", ChatKind.Roleplay), >= 6 and <= 9 => ("Society", ChatKind.Society), 10 => ("Olthoi", ChatKind.General), _ => ($"Channel {room}", ChatKind.General) };
        bool me = sender == _me;
        Say?.Invoke(me ? $"[{name}] You say, \"{text}\"" : $"[{name}] {who} says, \"{text}\"", RoomColor(kind), kind);
    }

    /// <summary>Says something on a global channel (General, Trade, LFG, Roleplay, Society, Olthoi, Allegiance) - the
    /// server shows it back to us with everyone else's. False when there's no such channel to say it on.</summary>
    public bool SayOnChannel(string channel, string text)
    {
        if (!_inWorld || Client == null || text.Length == 0) return false;
        uint room, type;
        if (string.Equals(channel, "Allegiance", StringComparison.OrdinalIgnoreCase))
        {
            room = _rooms.FirstOrDefault(kv => kv.Value.kind == ChatKind.Allegiance).Key; type = 1;
            if (room == 0) return false;
        }
        else if (StockRooms.TryGetValue(channel, out var st))
        {
            room = _rooms.FirstOrDefault(kv => string.Equals(kv.Value.name, channel, StringComparison.OrdinalIgnoreCase)).Key;
            if (room == 0) room = st.room;
            type = st.type;
        }
        else return false;
        var inner = new MemoryStream(); var iw = new BinaryWriter(inner);
        iw.Write(++_chatContext); iw.Write(2u); iw.Write(2u); iw.Write(room);
        WriteWide(iw, text);
        iw.Write(0x0Cu); iw.Write(_me); iw.Write(0u); iw.Write(type);
        var body = inner.ToArray();
        var b = new MemoryStream(); var w = new BinaryWriter(b);
        w.Write((uint)(4 * 7 + 4 + body.Length));   // the bytes to follow
        w.Write(3u); w.Write(2u);                    // a request: said in a room, by its number
        w.Write(1u); w.Write(0u); w.Write(0u); w.Write(0u); w.Write(0u);
        w.Write((uint)body.Length); w.Write(body);
        Client.Send(0xF7DE, b.ToArray());
        return true;
    }
    private uint _chatContext;

    /// <summary>Says something to the fellowship (its channel, 0x800).</summary>
    public bool SayToFellowship(string text)
    {
        if (!_inWorld || Client == null || text.Length == 0) return false;
        var b = new MemoryStream(); var w = new BinaryWriter(b);
        w.Write(0x800u); AcClient.WriteString16L(w, text);
        Client.SendAction(0x0147, b.ToArray());
        return true;
    }

    private static void OrderLog(string s) => global::ACGodot.DebugLogs.Print($"[order] {DateTime.Now:HH:mm:ss} {s}");

    // ── where we are, the server's account against ours (in the log as [pos]) ──
    private int _posEchoes, _posOff, _posServerMoves, _posSends, _headOff;
    private readonly Queue<Vector3> _sentAt = new();
    private void NoteSent() { _sentAt.Enqueue(Player.Position); while (_sentAt.Count > 8) _sentAt.Dequeue(); }
    private float _posWorst;
    private static void PosLog(string s) => global::ACGodot.DebugLogs.Print($"[pos] {DateTime.Now:HH:mm:ss} {s}");
    /// <summary>How well the server's account of where we are has kept with ours this session.</summary>
    public string PosReport => $"positions sent {_posSends}, the server's echoes {_posEchoes} ({_posOff} more than half a metre off, worst {_posWorst:0.0} m); "
                              + $"facing more than 20 degrees off {_headOff}; times the server walked or turned us itself {_posServerMoves}; put where the server had us (out of step) {_posSnaps}";
    private double _orderDumpAt = -1;
    private void DumpOrder(string when)
    {
        try
        {
            if (Inv == null) return;
            foreach (var g in Inv.Pack.GroupBy(i => i.Holder))
            {
                string pack = g.Key == 0 ? "Main pack" : _held.TryGetValue(g.Key, out var ph) ? ph.Name : $"{g.Key:X8}";
                OrderLog($"{when}, {pack} ({g.Count()}): " + string.Join(", ", g.Select(i => i.Name)));
            }
        }
        catch (Exception ex) { OrderLog("couldn't list the order: " + ex.Message); }
    }
    private string Named(uint g) => _held.TryGetValue(g, out var t) ? t.Name : g == _me ? "Main pack" : $"{g:X8}";

    /// <summary>Every game message as it came (opcode, then what follows it), after the game has read it - and every one
    /// sent: for plugins, as Decal's network filter passed them on.</summary>
    public Action<uint, byte[]>? RawIn, RawOut;
    // an item asked to move / be used / stacked / given, not yet answered: the client is "busy" (Decal's BusyState) till
    // the server says what came of it (or a moment passes)
    private static readonly HashSet<uint> ItemAsks = new() { 0x0019, 0x001A, 0x001B, 0x0035, 0x0036, 0x0054, 0x0055, 0x0056, 0x00CD };
    private uint _pendingAsk; private double _pendingAt;
    public bool ItemPending => _pendingAsk != 0 && _clock - _pendingAt < 2.0;
    private void Answered(uint g) { if (_pendingAsk != 0 && (g == 0 || g == _pendingAsk || _pendingAsk == 1)) _pendingAsk = 0; }
    private double _settledAt;
    /// <summary>Just into the world (through a portal the stance is kept): the server won't take a change of stance yet.</summary>
    public bool Settling => _inWorld && (!_placed || _clock < _settledAt);
    public void CombatMode(int mode)
    {
        if (!_inWorld || Client == null || (_loggingOut && mode != 1)) return;
        Client.SendAction(0x0053, BitConverter.GetBytes((uint)mode));
        _combatMode = (uint)mode;
    }

    // ── magic: casting is asked of the server; what's on us is what it says ──

    /// <summary>Told of a spell on us (its id, how long it lasts) or one that's gone.</summary>
    public Action<int, double, bool>? Enchanted;
    /// <summary>Told when health (0), stamina (1) or mana (2) changes.</summary>
    public Action<int, int>? VitalRead;
    private uint _combatMode;
    private long _inHand;
    private double _clock;
    private readonly List<(double at, Action act)> _soon = new();

    private void Enchantment(BinaryReader r)
    {
        var (spell, left) = ReadEnchantment(r);
        if (spell < 0x8000) Enchanted?.Invoke(spell, left, true);
    }

    // (0x8000 and up aren't spells but cooldowns: what was used can't be again until it has run)
    private void Unenchanted(int spell, int layer)
    {
        if (spell >= 0x8000) { Combat.Item.Cooldowns.Remove(spell & 0x7FFF); CooldownsChanged?.Invoke(); }
        else
        {
            // (one layer of it gone: the same spell can be on us more than once - cast again while it's on, from an item
            // as well - and it's still on while another layer is; taken off whole, plugins saw a buff "dispelled")
            if (EnchantMods.Remove((spell, layer))) ModsChanged = true;
            if (EnchantMods.Keys.Any(k => k.spell == spell)) { Objects.Note($"spell {spell}: layer {layer} gone, another still on"); global::ACGodot.DebugLogs.Print($"[ench] spell {spell}: layer {layer} gone, another layer still on - kept"); return; }
            Enchanted?.Invoke(spell, 0, false);
        }
    }
    /// <summary>Told when a cooldown starts or ends (the squares showing those items are drawn again).</summary>
    public static Action? CooldownsChanged;

    /// <summary>One enchantment on us as the server keeps it: its family (one of a family counts - the strongest), what it changes, by how much.</summary>
    /// <summary>What the server's own numbers of us add: to health (what's worn, each enlightenment), to skills (enlightenments, auras, augmentations).</summary>
    public static void ApplyOwnNumbers(ServerCharacter c, Combat.Character me)
    {
        int I(int k) => c.Ints.TryGetValue(k, out int v) ? v : 0;
        me.HealthBonus = I(379) + 2 * I(390);
        me.SkillBonusAll = I(390) + I(365) + 5 * I(326);
        me.SkillBonusSpec = 2 * I(344);
        me.SkillBonus.Clear();
        foreach (int s in new[] { 41, 44, 45, 46 }) if (I(300) > 0) me.SkillBonus[s] = 10;   // (melee mastery: two handed, heavy, light, finesse)
        if (I(301) > 0) me.SkillBonus[47] = 10;                                             // (missile)
        foreach (int s in new[] { 31, 32, 33, 34, 43 }) if (I(302) > 0) me.SkillBonus[s] = 10;   // (magic: creature, item, life, war, void)
    }

    public readonly record struct EnchantMod(int Spell, int Category, uint Power, uint Type, uint Key, float Value);
    public readonly Dictionary<(int spell, int layer), EnchantMod> EnchantMods = new();
    public bool ModsChanged;

    private (int spell, double left) ReadEnchantment(BinaryReader r)
    {
        int spell = r.ReadUInt16(); int layer = r.ReadUInt16(); int category = r.ReadUInt16();
        int hasSet = r.ReadUInt16();
        uint power = r.ReadUInt32();
        double start = r.ReadDouble(), duration = r.ReadDouble();
        uint caster = r.ReadUInt32(); float degMod = r.ReadSingle(), degLimit = r.ReadSingle(); double lastDeg = r.ReadDouble();
        // (a deed's spells come from caster 0x00DEED00 and a worn thing's from the thing, both with no duration (-1): shown with no time)
        // what it changes and by how much, as the server has it (a server's own rules can make a spell worth far more
        // than the spell's own number: what's shown of us is worked out from these)
        uint modType = r.ReadUInt32(), modKey = r.ReadUInt32(); float modValue = r.ReadSingle();
        if (hasSet != 0) r.ReadUInt32();
        if (spell < 0x8000) { EnchantMods[(spell, layer)] = new EnchantMod(spell, category, power, modType, modKey, modValue); ModsChanged = true; }
        if (spell >= 0x8000)
        {
            double still = duration > 0 ? duration + start : 0;
            Objects.Note($"cooldown {spell & 0x7FFF}: {still:0.#} s of {duration:0.#}");
            if (still > 0) Combat.Item.Cooldowns[spell & 0x7FFF] = (Time.GetTicksMsec() / 1000.0 + still, duration);
            CooldownsChanged?.Invoke();
        }
        // (its start is how long it has run already, below zero)
        return (spell, duration > 0 ? Math.Max(1, duration + start) : -1);
    }

    /// <summary>
    /// Asks the server to cast: on ourselves, or at what's selected (ourselves if nothing of the server's is). A wand
    /// has to be in hand and the magic stance taken, as the server sees it - done first if they aren't, the cast a
    /// moment after. True if it was asked.
    /// </summary>
    public bool Cast(int spellId, bool self, ObjectStreamer.Selectable? selected, bool noTarget = false)
    {
        if (!_inWorld || Client == null || _loggingOut) return false;
        static bool Caster(Combat.Item i) => i.Guid != 0 && (i.ItemType & Combat.Item.TypeCaster) != 0;
        uint target = selected != null ? GuidOf(selected) : 0;
        if (target == 0) target = _me;
        void Send()
        {
            if (Client == null) return;
            double wait = 0;
            if (_combatMode != 8)
            {
                Client.SendAction(0x0053, BitConverter.GetBytes(8u));   // ChangeCombatMode: magic
                _combatMode = 8;
                wait = 0.6;
            }
            _soon.Add((_clock + wait, () =>
            {
                if (Client == null) return;
                HereFirst();
                // (a spell on yourself is cast at yourself, by name: cast with no target, the server takes it as one with no one to
                // show its effect on - the buff landed, but neither you nor anyone watching saw it)
                // (a ring or a wall is cast at no one - asked for as the game asks: without a target. Asked for at
                // yourself or at whatever's selected, a server may never say the cast is over)
                if (noTarget && !self) Client.SendAction(0x0048, BitConverter.GetBytes((uint)spellId));
                else
                {
                    var b = new byte[8];
                    BitConverter.GetBytes(self ? _me : target).CopyTo(b, 0); BitConverter.GetBytes((uint)spellId).CopyTo(b, 4);
                    Client.SendAction(0x004A, b);
                }
            }));
        }
        if (Inv == null || Inv.Worn.Any(Caster)) { Send(); return true; }
        var wand = Inv.Pack.FirstOrDefault(Caster);
        if (wand == null) { Say?.Invoke("You need a wand, staff or orb to cast with.", SysColor, ChatKind.Magic); return true; }
        Inv.Equip(wand);
        _combatMode = 0;
        // (once the server says the wand's in hand - what was there has to come off first)
        void Wait(int left)
        {
            if (Inv.Worn.Any(Caster)) { _soon.Add((_clock + 0.3, Send)); return; }
            if (left > 0) _soon.Add((_clock + 0.25, () => Wait(left - 1)));
        }
        Wait(24);
        return true;
    }

    // ── appraising (IdentifyObject): what the server tells of a thing when it's looked at closely ──

    /// <summary>What the server said of something appraised (ACE's AppraiseInfo).</summary>
    public sealed class Appraisal
    {
        public uint Guid;
        public bool Success;
        public Dictionary<int, int> Ints = new();
        public Dictionary<int, double> Floats = new();
        public Dictionary<int, uint> Dids = new();
        public Dictionary<int, string> Strings = new();
        public Dictionary<int, long> Longs = new();
        public List<int> Spells = new();
        public bool Weapon, Creature, Attributes;
        public int DamageType, WeaponTime, WeaponSkill, Damage;
        public double Variance, DamageMod, MaxVelocity, WeaponOffense;
        public Dictionary<int, bool> Bools = new();
        public float[]? Prots;
        public int Health, HealthMax, Stamina, StaminaMax, Mana, ManaMax;
        public int[] Attribute = new int[6];   // strength, endurance, quickness, coordination, focus, self
        public int[]? ArmorLevels;
        /// <summary>The item it is, if it's one that can be carried (its details filled in from this).</summary>
        public Combat.Item? Item;
        /// <summary>The thing in the world it is, if it's shown there.</summary>
        public ObjectStreamer.Selectable? Thing;
    }
    /// <summary>What the server told of ourselves when we last looked ourselves over (null: not yet).</summary>
    public Dictionary<int, int>? SelfInts;
    public Dictionary<int, double>? SelfFloats;
    /// <summary>A creature looked at closely: its health now and the most it can be, in the server's own numbers.</summary>
    public Action<ObjectStreamer.Selectable, int, int>? CreatureHealthTold;
    /// <summary>Told when the server answers an appraisal.</summary>
    public Action<Appraisal>? AppraisalRead;

    /// <summary>Asks the server about something (an item of ours, or a thing in the world).</summary>
    public void Appraise(uint guid)
    {
        if (!_inWorld || Client == null || guid == 0) return;
        Client.SendAction(0x00C8, BitConverter.GetBytes(guid));
    }
    // where the server last put each thing, in its own terms (a cell and a spot in it)
    private readonly Dictionary<uint, (uint cell, System.Numerics.Vector3 local, float yaw)> _where = new();
    /// <summary>Where the server has a thing (its cell, the spot in it, the way it faces), for testing: null if it isn't the server's.</summary>
    public (uint cell, System.Numerics.Vector3 local, float yaw)? WhereIs(ObjectStreamer.Selectable sel) => _where.TryGetValue(GuidOf(sel), out var w) ? w : null;
    /// <summary>The thing shown in the world with this server id, if there is one.</summary>
    public ObjectStreamer.Selectable? ThingAt(uint guid) => _things.TryGetValue(guid, out var s) ? s : null;
    /// <summary>The server's id of a thing shown in the world (0 if it isn't the server's).</summary>
    public uint GuidOf(ObjectStreamer.Selectable sel) => sel == Objects.Self ? (_inWorld ? _me : 0) : sel.Item is NetObject no ? no.Guid : sel.Item is Combat.Item { Guid: not 0 } it ? it.Guid : 0;

    private void Appraised(BinaryReader r)
    {
        var a = new Appraisal { Guid = r.ReadUInt32() };
        uint flags = r.ReadUInt32();
        a.Success = r.ReadUInt32() != 0;
        void Table(Action each) { int n = r.ReadUInt16(); r.ReadUInt16(); for (int i = 0; i < n; i++) each(); }
        if ((flags & 0x0001) != 0) Table(() => { int k = (int)r.ReadUInt32(); a.Ints[k] = r.ReadInt32(); });
        if ((flags & 0x2000) != 0) Table(() => { int k = (int)r.ReadUInt32(); a.Longs[k] = r.ReadInt64(); });
        if ((flags & 0x0002) != 0) Table(() => { int k = (int)r.ReadUInt32(); a.Bools[k] = r.ReadUInt32() != 0; });
        if ((flags & 0x0004) != 0) Table(() => { int k = (int)r.ReadUInt32(); a.Floats[k] = r.ReadDouble(); });
        if ((flags & 0x0008) != 0) Table(() => { int k = (int)r.ReadUInt32(); a.Strings[k] = AcClient.ReadString16L(r); });
        if ((flags & 0x1000) != 0) Table(() => { int k = (int)r.ReadUInt32(); a.Dids[k] = r.ReadUInt32(); });
        if ((flags & 0x0010) != 0) { int n = r.ReadInt32(); for (int i = 0; i < n; i++) a.Spells.Add((int)(r.ReadUInt32() & 0x7FFFFFFF)); }
        if ((flags & 0x0080) != 0) { a.Prots = new float[8]; for (int i = 0; i < 8; i++) a.Prots[i] = r.ReadSingle(); }   // armor's protection against each kind of damage
        if ((flags & 0x0100) != 0)
        {
            a.Creature = true;
            uint cf = r.ReadUInt32();
            a.Health = (int)r.ReadUInt32(); a.HealthMax = (int)r.ReadUInt32();
            if ((cf & 0x8) != 0)
            {
                a.Attributes = true;
                for (int i = 0; i < 6; i++) a.Attribute[i] = (int)r.ReadUInt32();
                a.Stamina = (int)r.ReadUInt32(); a.Mana = (int)r.ReadUInt32(); a.StaminaMax = (int)r.ReadUInt32(); a.ManaMax = (int)r.ReadUInt32();
            }
            // (with spells on them: which attributes are changed, and which for the better - without these read, what
            // followed was read four bytes out: a player's armor by body part came out shifted along one)
            if ((cf & 0x1) != 0) { r.ReadUInt16(); r.ReadUInt16(); }
        }
        if ((flags & 0x0020) != 0)
        {
            a.Weapon = true;
            a.DamageType = (int)r.ReadUInt32(); a.WeaponTime = (int)r.ReadUInt32(); a.WeaponSkill = (int)r.ReadUInt32(); a.Damage = (int)r.ReadUInt32();
            a.Variance = r.ReadDouble(); a.DamageMod = r.ReadDouble();
            // (its length, a missile's speed, its attack bonus, and whether that speed is a guess: left unread, what
            // followed - which of its numbers spells have changed - was read from the middle of these)
            r.ReadDouble(); a.MaxVelocity = r.ReadDouble(); a.WeaponOffense = r.ReadDouble(); r.ReadUInt32();
        }
        int weaponLit = 0, weaponUp = 0;
        if ((flags & 0x0040) != 0) r.ReadBytes(12);                       // a hook's
        if ((flags & 0x0200) != 0) { r.ReadUInt16(); r.ReadUInt16(); }    // armor's highlights
        if ((flags & 0x0800) != 0) { weaponLit = r.ReadUInt16(); weaponUp = r.ReadUInt16(); }   // a weapon's: what spells have changed, and which of those for the better
        try
        {
            if ((flags & 0x0400) != 0) { r.ReadUInt16(); r.ReadUInt16(); }   // resistances' highlights
            // armor by body part (a player's, an NPC's): head, chest, groin, upper arm, wrist, hand, thigh, shin, foot
            if ((flags & 0x4000) != 0) { a.ArmorLevels = new int[9]; for (int i = 0; i < 9; i++) a.ArmorLevels[i] = (int)r.ReadUInt32(); }
        }
        catch (EndOfStreamException) { }
        // (ours, or a vendor's ware: those aren't kept with what we hold, and went undescribed)
        Held? h = _held.TryGetValue(a.Guid, out var hh) && !hh.Stuck ? hh : null;
        Combat.Item? ware = h == null ? OpenVendorInfo?.ForSale.FirstOrDefault(x => x.Guid == a.Guid) : null;
        if (h != null || ware != null)
        {
            var it = h != null ? ItemOf(h) : ware!;
            a.Item = it;
            it.Raised = weaponLit & weaponUp; it.Lowered = weaponLit & ~weaponUp;
            if (a.Success)
            {
                it.PropInts = a.Ints; it.PropFloats = a.Floats; it.PropStrings = a.Strings; it.PropBools = a.Bools; it.Prots = a.Prots; if (a.Longs.Count > 0) { it.PropInt64s ??= new(); foreach (var kv in a.Longs) it.PropInt64s[kv.Key] = kv.Value; }
                if (a.Weapon) { it.DamageMod = a.DamageMod; it.WeaponOffense = a.WeaponOffense; it.MaxVelocity = a.MaxVelocity; }
            }
            if (a.Weapon) { it.Damage = a.Damage; it.DamageType = a.DamageType; it.WeaponSkill = a.WeaponSkill; it.WeaponTime = a.WeaponTime; it.Variance = (float)a.Variance; }
            if (a.Ints.TryGetValue(28, out int al)) it.ArmorLevel = al;
            if (a.Ints.TryGetValue(108, out int mm) && mm > 0) { it.MaxMana = mm; it.Mana = a.Ints.TryGetValue(107, out int cm) ? cm : 0; }
            if (a.Spells.Count > 0) { it.Spells = a.Spells.Distinct().ToList(); it.Magical = true; }
            var notes = new List<string>();
            foreach (int k in new[] { 14, 15, 16 }) if (a.Strings.TryGetValue(k, out var t) && t.Length > 0 && !notes.Contains(t)) notes.Add(t);
            it.Notes = string.Join("\n\n", notes);
            // what using it asks of you (a level, a skill and how high, specialized; a mastery), its cooldown and
            // properties - worded and ordered as the game's own panel has them
            var needs = new List<string>();
            static string Skill(int id) => System.Text.RegularExpressions.Regex.Replace(((DatReaderWriter.Enums.SkillId)id).ToString(), "(?<=[a-z])(?=[A-Z])", " ");
            if (a.Ints.TryGetValue(369, out int useLevel) && useLevel > 0) needs.Add($"Use requires level {useLevel}.");
            a.Ints.TryGetValue(367, out int skillLevel);
            if (a.Ints.TryGetValue(366, out int useSkill) && useSkill > 0)
                needs.Add(skillLevel > 0 ? $"Use requires {Skill(useSkill)} of at least {skillLevel}." : $"Use requires {Skill(useSkill)}.");
            if (a.Ints.TryGetValue(368, out int specSkill) && specSkill > 0)
            {
                if (useSkill <= 0 && skillLevel > 0) needs.Add($"Use requires {Skill(specSkill)} of at least {skillLevel}.");
                needs.Add($"Use requires specialized {Skill(specSkill)}.");
            }
            if (a.Ints.TryGetValue(362, out int mastery) && mastery > 0)
                needs.Add($"Use requires the {mastery switch { 1 => "Primalist", 2 => "Necromancer", 3 => "Naturalist", _ => mastery.ToString() }} mastery.");
            else if (it.Name.Contains(" Essence") && specSkill <= 0 && !(a.Ints.TryGetValue(33, out int b33) && b33 == 1 && !(a.Ints.TryGetValue(114, out int a114) && a114 > 0)))
                // (the server doesn't tell an essence's mastery when it's looked at, only when using it is refused. What
                // it does tell apart: the golems' essences, which ask for none, are bonded; the masteries' aren't. On
                // Infinite Leaftide a pet's bond level makes its essence attuned and bonded both (all but the newborn):
                // bonded and attuned together is that, not a golem's, and still asks for the specialization)
                needs.Add("Use requires specialized Summoning.");
            it.UseNotes = string.Join("\n", needs);
            var top = new List<string>();
            if (a.Ints.TryGetValue(131, out int made) && made > 0) { it.Material = made; if (h != null) h.Material = made; }
            if (a.Ints.TryGetValue(105, out int work) && work > 0)
            {
                // (salvage keeps the workmanship of all that went into it, added up: shown as the average, to two places)
                bool salvage = (it.ItemType & Combat.Item.TypeSalvage) != 0;
                int from = a.Ints.TryGetValue(170, out int nf) && nf > 0 ? nf : 1;
                double w = salvage ? (double)work / from : work;
                string wn = (int)Math.Clamp(Math.Round(w), 1, 10) switch { 1 => "Poorly crafted", 2 => "Well-crafted", 3 => "Finely crafted", 4 => "Exquisitely crafted", 5 => "Magnificent",
                    6 => "Nearly flawless", 7 => "Flawless", 8 => "Utterly flawless", 9 => "Incomparable", _ => "Priceless" };
                top.Add(salvage ? $"Workmanship: {wn} ({w:0.00})" : $"Workmanship: {wn} ({work})");
                if (salvage) top.Add($"Salvaged from {from} items.");
            }
            if (a.Floats.TryGetValue(167, out double cd) && cd > 0) { top.Add(""); top.Add($"Cooldown When Used: {cd:0.#}s"); }
            var props = Combat.Item.PropertyNames(a.Ints, a.Floats, a.Dids, (it.ItemType & Combat.Item.TypeCaster) != 0);
            if (a.Ints.TryGetValue(114, out int att) && att > 0) props.Add("Attuned");
            if (a.Ints.TryGetValue(33, out int bond) && bond != 0) props.Add(bond == -2 ? "Destroyed On Death" : bond == -1 ? "Dropped On Death" : "Bonded");   // (the server's bonded status: -2 destroyed, -1 slippery - dropped, 1 bonded, 2 sticky)
            // tinkering, as the game's panel says it: how many times, who imbued it, who tinkered it last
            var tink = new List<string>();
            if (a.Ints.TryGetValue(171, out int tinkered) && tinkered > 0) tink.Add($"This item has been tinkered {tinkered} time{(tinkered == 1 ? "" : "s")}.");
            if (a.Strings.TryGetValue(40, out var imbuer) && imbuer.Length > 0) tink.Add($"Imbued by {imbuer}.");
            if (a.Strings.TryGetValue(39, out var tinker) && tinker.Length > 0) tink.Add($"Last tinkered by {tinker}.");
            if (a.Strings.TryGetValue(25, out var crafter) && crafter.Length > 0) tink.Add($"Crafted by {crafter}.");
            it.TinkerNotes = string.Join("\n", tink);
            it.Properties = props.Count > 0 ? "Properties: " + string.Join(", ", props) : "";   // (shown below the weapon's numbers, above the spells)
            it.TopNotes = string.Join("\n", top);
            // an aetheria's (any set item's) built-in buff - its set's spells at its level - and its ratings; and what it casts
            it.BuiltIn = Combat.Item.BuiltInLines(a.Ints, a.Longs, !(a.Strings.TryGetValue(16, out var ld16) && ld16.IndexOf("Rating", StringComparison.OrdinalIgnoreCase) >= 0));
            it.ProcSpell = a.Floats.TryGetValue(156, out double prate) && prate > 0 && a.Dids.TryGetValue(55, out uint pspell) && pspell != 0
                && Combat.Item.SpellInfo?.Invoke((int)pspell) is { } psp ? psp.name : "";
            Objects.Note($"appraised {it.Name}: ints {string.Join(" ", a.Ints.Select(kv => $"{kv.Key}={kv.Value}"))}; floats {string.Join(" ", a.Floats.Select(kv => $"{kv.Key}={kv.Value:0.##}"))}");
        }
        _things.TryGetValue(a.Guid, out a.Thing);
        if (a.Thing != null && a.Item == null)
            Objects.Note($"appraised {a.Thing.Name} (type {a.Thing.Type}): flags {flags:X}, ok {a.Success}; ints {string.Join(" ", a.Ints.Select(kv => $"{kv.Key}={kv.Value}"))}; strings {string.Join(" | ", a.Strings.Select(kv => $"{kv.Key}={kv.Value}"))}; {r.BaseStream.Length - r.BaseStream.Position} bytes left");
        if (a.Ints.TryGetValue(25, out int toldLevel) && toldLevel > 0) _levels[a.Guid] = toldLevel;
        // (kept for plugins: a creature's or person's own numbers - its ratings, your enlightenment - are read from these)
        if (a.Success && a.Thing != null) { a.Thing.PropInts = a.Ints; a.Thing.PropFloats = a.Floats; a.Thing.PropStrings = a.Strings; }
        if (a.Success && a.Guid == _me) { SelfInts = a.Ints; SelfFloats = a.Floats; }
        if (a.Success && a.Creature && a.Thing != null && a.HealthMax > 0) CreatureHealthTold?.Invoke(a.Thing, a.Health, a.HealthMax);
        // (a player looked at quietly for their monarch - who's in our allegiance: their name tag's and map dot's colour)
        if (a.Thing is { Kind: >= 3 } pl && pl.Name.Length > 0 && a.Success)
            _monarchOf[pl.Name] = a.Strings.TryGetValue(21, out var mon) && mon.Length > 0 ? mon : a.Ints.ContainsKey(35) ? pl.Name : "";
        if (_quietLook.Remove(a.Guid)) return;
        AppraisalRead?.Invoke(a);
    }

    // players' monarchs, by name ("" none), learned by looking each new player over once, quietly
    private readonly Dictionary<string, string> _monarchOf = new();
    private readonly HashSet<uint> _quietLook = new(), _looked = new();
    private double _lookAt;
    private void LookOverPlayers()
    {
        if (!_inWorld || _clock < _lookAt) return;
        _lookAt = _clock + 1.5;
        foreach (var (g, sel) in _things)
        {
            if (sel.Kind < 3 || sel.Name.Length == 0 || g == _me || _looked.Contains(g) || _monarchOf.ContainsKey(sel.Name)) continue;
            _looked.Add(g);
            _quietLook.Add(g);
            Appraise(g);
            return;
        }
    }

    /// <summary>The character as the server has it (its login description).</summary>
    public sealed class ServerCharacter
    {
        public string Name = "";
        public int Level = 1, SkillCredits, Heritage;
        public long TotalXp, UnassignedXp;
        public int[] AttributeStart = new int[6], AttributeRanks = new int[6];   // strength, endurance, quickness, coordination, focus, self
        public int[] VitalRanks = new int[3], VitalNow = new int[3];             // health, stamina, mana
        public Dictionary<int, (int training, int ranks)> Skills = new();        // training: 1 untrained, 2 trained, 3 specialized
        public List<int> Spells = new();
        /// <summary>The spells on us at login: each one's id and how long it has left (below zero: until taken off).</summary>
        public List<(int spell, double left)> Enchantments = new();
        /// <summary>The numbers the server keeps of us (augmentations and the like), by its own number for each.</summary>
        public Dictionary<int, int> Ints = new();
    }
    // the place of each thing in our packs as the server keeps them (from the login description)
    private readonly Dictionary<uint, int> _packOrder = new();
    // the side packs' contents in the order the server last listed them (kept up as it puts things in them)
    private readonly Dictionary<uint, List<uint>> _listed = new();
    private readonly HashSet<uint> _relayout = new();

    // ── everything we carry come in, after logging in: the server lists it all first (the pack and each side pack), the
    //    things themselves follow - for one who carries a lot, well after. Plugins are told they're logged in once it's
    //    all here, so nothing goes by a half-filled pack (a wand not there yet, a stack not counted, the order wrong) ──
    /// <summary>Everything listed at login has come in (or 20 s went by without it all).</summary>
    public bool InventoryComplete { get; private set; }
    public event Action? InventoryCompleted;
    private readonly HashSet<uint> _expectPacks = new();
    private double _invWaitFrom = -1, _invNewsAt;
    private int _invHeldSeen = -1;
    private void CheckInventoryComplete()
    {
        if (_invWaitFrom < 0 || InventoryComplete || !_inWorld) return;
        if (_held.Count != _invHeldSeen) { _invHeldSeen = _held.Count; _invNewsAt = _clock; }
        int want = 0, have = 0, packsListed = 0;
        void Count(IEnumerable<uint> gs) { foreach (var g in gs) { want++; if (_held.ContainsKey(g)) have++; } }
        if (_listed.TryGetValue(_me, out var main)) Count(main);
        Count(_wornAtLogin);
        foreach (var p in _expectPacks) if (_listed.TryGetValue(p, out var l)) { packsListed++; Count(l); }
        // (a side pack the server never lists - an empty one, maybe: not waited on once things have gone quiet for 2 s)
        bool packsDone = packsListed == _expectPacks.Count || _clock - _invNewsAt > 2.0;
        bool done = have == want && packsDone;
        if (!done && _clock - _invWaitFrom < 20) return;
        InventoryComplete = true; _invWaitFrom = -1;
        OrderLog(done ? $"inventory complete: {have} things, {packsListed} of {_expectPacks.Count} side packs listed, {_clock - _invWaitFrom:0.0}s after the character"
                      : $"inventory not all in after 20 s ({have} of {want} things, {packsListed} of {_expectPacks.Count} side packs listed) - going on without it");
        _orderDumpAt = _clock + 1;
        _invDirty = true;
        try { InventoryCompleted?.Invoke(); } catch (Exception ex) { GD.PushWarning("inventory complete: " + ex.Message); }
    }
    /// <summary>What the server's list of the pack's order came to at login (for the test bridge).</summary>
    public string PackOrderNote = "the server's pack order wasn't found";
    /// <summary>For finding things that should be ours and aren't shown: what the server listed at login that isn't in the packs now, and why.</summary>
    public IEnumerable<string> HeldNotes()
    {
        yield return $"me {_me:X8}; {_held.Count} things described; {_held.Values.Count(h => Mine(h, out _))} of them ours";
        foreach (var g in _packOrder.Keys.Concat(_wornAtLogin).Distinct())
        {
            if (!_held.TryGetValue(g, out var h)) { yield return $"  {g:X8}: listed at login, never described (or deleted since)"; continue; }
            if (Mine(h, out _)) continue;
            yield return $"  {g:X8} {h.Name}: listed at login, not ours now - container {h.Container:X8} wielder {h.Wielder:X8} worn {h.WornAt:X} type {h.ItemType:X} pack {h.IsPack} last {(_lastWord.TryGetValue(g, out var w) ? w : "create")}";
        }
        foreach (var h in _held.Values.Where(h => !Mine(h, out _) && (h.Wielder == _me || h.Container == _me || _held.TryGetValue(h.Container, out var up) && _packOrder.ContainsKey(up.Guid))).Take(40))
            yield return $"  {h.Guid:X8} {h.Name}: points at us but isn't counted - container {h.Container:X8} wielder {h.Wielder:X8} worn {h.WornAt:X}";
    }
    private readonly List<uint> _wornAtLogin = new();
    private readonly Dictionary<uint, string> _lastWord = new();
    public string PackOrderOf(Combat.Item i) => _packOrder.TryGetValue(i.Guid, out int o) ? o.ToString() : "?";
    /// <summary>Told when the server's description of our character has been read.</summary>
    public Action<ServerCharacter>? CharacterRead;
    /// <summary>The server has said who we are in the world now (our character read) - false at the character screen
    /// and while entering, when our character's name is still the last one's (or the placeholder).</summary>
    public bool CharacterKnown { get; private set; }
    /// <summary>Entering the world as this character (its name from the list): called before the server's said anything.</summary>
    public Action<string>? Entering;
    public ServerCharacter? Character { get; private set; }

    // PlayerDescription (as ACE's GameEventPlayerDescription writes it): the property tables, then attributes and
    // vitals, skills, spells... (what follows - enchantments, options, the pack's lists - isn't read yet)
    private void PlayerDescription(BinaryReader r)
    {
        var c = new ServerCharacter();
        EnchantMods.Clear();   // (what's on us is told afresh)
        uint flags = r.ReadUInt32();
        r.ReadUInt32();                                   // the kind of thing we are
        var ints = new Dictionary<uint, int>(); var longs = new Dictionary<uint, long>(); var strings = new Dictionary<uint, string>();
        void Table(Action each) { int n = r.ReadUInt16(); r.ReadUInt16(); for (int i = 0; i < n; i++) each(); }
        if ((flags & 0x01) != 0) Table(() => { uint k = r.ReadUInt32(); ints[k] = r.ReadInt32(); });
        if (ints.TryGetValue(20, out int coinsTold)) CoinValue = coinsTold;
        if ((flags & 0x80) != 0) Table(() => { uint k = r.ReadUInt32(); longs[k] = r.ReadInt64(); });
        if ((flags & 0x02) != 0) Table(() => { r.ReadUInt32(); r.ReadUInt32(); });
        if ((flags & 0x04) != 0) Table(() => { r.ReadUInt32(); r.ReadDouble(); });
        if ((flags & 0x10) != 0) Table(() => { uint k = r.ReadUInt32(); strings[k] = AcClient.ReadString16L(r); });
        if ((flags & 0x08) != 0) Table(() => { r.ReadUInt32(); r.ReadUInt32(); });
        if ((flags & 0x40) != 0) Table(() => { r.ReadUInt32(); r.ReadUInt32(); });
        if ((flags & 0x20) != 0) Table(() => { r.ReadUInt32(); r.ReadBytes(32); });   // a position: cell, place, facing
        c.Name = strings.TryGetValue(1, out var nm) ? nm.TrimStart('+') : _characters.TryGetValue(_me, out var cn) ? cn : "";
        foreach (var kv in ints) c.Ints[(int)kv.Key] = kv.Value;
        c.Level = ints.TryGetValue(25, out int lv) ? lv : 1;
        c.SkillCredits = ints.TryGetValue(24, out int sc) ? sc : 0;
        c.Heritage = ints.TryGetValue(188, out int hg) ? hg : 0;
        c.TotalXp = longs.TryGetValue(1, out long tx) ? tx : 0;
        c.UnassignedXp = longs.TryGetValue(2, out long ux) ? ux : 0;
        uint vectors = r.ReadUInt32();
        r.ReadUInt32();
        if ((vectors & 0x1) != 0)
        {
            uint af = r.ReadUInt32();
            for (int i = 0; i < 6; i++)
                if ((af & (1u << i)) != 0) { c.AttributeRanks[i] = (int)r.ReadUInt32(); c.AttributeStart[i] = (int)r.ReadUInt32(); r.ReadUInt32(); }
            for (int v = 0; v < 3; v++)
                if ((af & (1u << (6 + v))) != 0) { c.VitalRanks[v] = (int)r.ReadUInt32(); r.ReadUInt32(); r.ReadUInt32(); c.VitalNow[v] = (int)r.ReadUInt32(); }
        }
        if ((vectors & 0x2) != 0)
            Table(() =>
            {
                int id = (int)r.ReadUInt32(); int ranks = r.ReadUInt16(); r.ReadUInt16();
                int training = (int)r.ReadUInt32();
                r.ReadUInt32(); r.ReadUInt32(); r.ReadUInt32(); r.ReadDouble();
                c.Skills[id] = (training, ranks);
            });
        if ((vectors & 0x100) != 0) Table(() => { c.Spells.Add(r.ReadInt32()); r.ReadSingle(); });
        TestTrace.Last = "player description: enchantments";
        // the spells on us (those that multiply, those that add; cooldowns and vitae aren't shown)
        try
        {
            if ((vectors & 0x200) != 0)
            {
                uint mask = r.ReadUInt32();
                foreach (uint list in new uint[] { 1, 2, 8 })
                {
                    if ((mask & list) == 0) continue;
                    int n = r.ReadInt32();
                    for (int i = 0; i < n; i++) { var (sp, left) = ReadEnchantment(r); if (list != 8 && sp < 0x8000) c.Enchantments.Add((sp, left)); }
                }
                if ((mask & 4) != 0) ReadEnchantment(r);   // (vitae: one, with no count)
            }
        }
        catch (EndOfStreamException) { }
        // our options, as the server keeps them (two sets of switches; what lies between them is skipped by its own lengths)
        try
        {
            long back = r.BaseStream.Position;
            uint of = r.ReadUInt32();
            if (of < 0x800)
            {
                uint o1 = r.ReadUInt32(), o2 = Options2;
                if ((of & 0x1) != 0) { int n = r.ReadInt32(); r.ReadBytes(12 * Math.Clamp(n, 0, 200)); }
                int lists = (of & 0x400) != 0 ? 8 : (of & 0x10) != 0 ? 7 : (of & 0x4) != 0 ? 5 : 1;
                for (int i = 0; i < lists; i++) { int n = r.ReadInt32(); r.ReadBytes(4 * Math.Clamp(n, 0, 400)); }
                if ((of & 0x8) != 0) { int n = r.ReadUInt16(); r.ReadUInt16(); r.ReadBytes(8 * n); }
                if ((of & 0x20) != 0) r.ReadUInt32();
                bool two = (of & 0x40) != 0;
                if (two) o2 = r.ReadUInt32();
                Options1 = o1; if (two) Options2 = o2;
                OptionsRead = true;
            }
            r.BaseStream.Position = back;
        }
        catch (EndOfStreamException) { }
        TestTrace.Last = "player description: pack order";
        // our packs in order: the message ends with the pack's list (each thing's id and whether it's a pack) and then
        // what's worn (id, place, layer) - found from the end, past the options in between (whose length isn't said)
        try
        {
            var buf = ((MemoryStream)r.BaseStream).ToArray();
            uint U(int at) => BitConverter.ToUInt32(buf, at);
            bool found = false;
            for (int worn = 0; worn <= 60 && !found; worn++)
            {
                int p = buf.Length - 4 - 12 * worn;
                if (p < 0) break;
                if (U(p) != worn) continue;
                // (the longest list that fits: the last few of the real list look like a short list of their own - a focus's
                // kind, 2, read as "two things" before the two packs after it - which had the order come out wrong)
                int best = -1, bestAt = 0;
                for (int n = 0; n <= 400; n++)
                {
                    int q = p - 4 - 8 * n;
                    if (q < 0) break;
                    if (U(q) != n) continue;
                    bool ok = true;
                    // (each thing listed is one of the server's own things - ids from 0x80000000 - and says what kind of
                    // place it takes; each thing worn says where: numbers elsewhere in the message don't look like that)
                    for (int i = 0; i < n && ok; i++) ok = U(q + 4 + 8 * i) >= 0x80000000u && U(q + 8 + 8 * i) <= 2;
                    for (int i = 0; i < worn && ok; i++) ok = U(p + 4 + 12 * i) >= 0x80000000u && U(p + 8 + 12 * i) != 0;
                    if (ok) { best = n; bestAt = q; }
                }
                if (best < 0) continue;
                _packOrder.Clear();
                for (int i = 0; i < best; i++) _packOrder[U(bestAt + 4 + 8 * i)] = i;
                // (the main pack's things, in the server's places - its own listing, as the side packs have theirs)
                var mainList = new List<uint>();
                for (int i = 0; i < best; i++) if (U(bestAt + 8 + 8 * i) == 0) mainList.Add(U(bestAt + 4 + 8 * i));
                _listed[_me] = mainList; _relayout.Add(_me);
                _expectPacks.Clear();
                for (int i = 0; i < best; i++) if (U(bestAt + 8 + 8 * i) == 1) _expectPacks.Add(U(bestAt + 4 + 8 * i));
                InventoryComplete = false; _invWaitFrom = _clock; _invNewsAt = _clock; _invHeldSeen = -1;
                _wornAtLogin.Clear(); _lastWord.Clear();
                for (int i = 0; i < worn; i++) _wornAtLogin.Add(U(p + 4 + 12 * i));
                int sideCount = 0; for (int i = 0; i < best; i++) if (U(bestAt + 8 + 8 * i) != 0) sideCount++;
                PackOrderNote = $"the server listed {best} things in the pack ({sideCount} in side places) and {worn} worn";
                found = true;
            }
        }
        catch (Exception ex) { GD.PushWarning("pack order: " + ex.Message); }
        TestTrace.Last = "player description: applying";
        Character = c;
        if (_invWaitFrom < 0 && !InventoryComplete) { _invWaitFrom = _clock; _invNewsAt = _clock; _invHeldSeen = -1; }
        _orderDumpAt = _clock + 30;   // (the order at login: once everything's in - a second after - or this as a fallback)
        Say?.Invoke($"[Network] You are {c.Name}, level {c.Level}.", SysColor, ChatKind.Gameplay);
        CharacterKnown = true;
        CharacterRead?.Invoke(c);
    }

    private readonly Dictionary<string, int> _looks = new();

    /// <summary>
    /// The look number for something as the server describes it: a kind of thing of our own (numbered below zero, so
    /// never one of the game's) carrying the server's model, motion table, size, palettes, retextures and part swaps -
    /// and, where the game's data knows the kind, the rest of what it knows (what it is, its level...).
    /// </summary>
    private int LookFor(uint wcid, string name, uint setup, uint motionTable, float scale, uint palBase,
                        List<(uint id, int offset, int length)> pals, List<(int index, uint oldTex, uint newTex)> texs, List<(int index, uint gfx)> parts, uint itemType, uint what, uint soundTable = 0, int placement = -1)
    {
        var data = Objects.SpawnInfo;
        if (data == null || setup == 0) return (int)wcid;
        // (a pose counts only for a thing with no motions of its own that isn't a creature)
        if (motionTable != 0 || itemType == 0x10) placement = -1;
        string sig = $"{wcid}|{soundTable:X}|{setup:X}|{motionTable:X}|{scale:0.###}|{palBase:X}|{string.Join(",", pals)}|{string.Join(",", texs)}|{string.Join(",", parts)}|{placement}";
        if (_looks.TryGetValue(sig, out int id)) return id;
        id = -1000 - _looks.Count;
        var w = data.Get((int)wcid)?.Copy() ?? new Creatures.SpawnData.Weenie
        {
            Name = name, ItemType = (int)itemType, Attackable = (what & 0x10) != 0,
            // (the game's kinds: 10 a creature, 19 a door, 7 a portal, 25 a lifestone, 12 a vendor)
            Type = (what & 0x1000) != 0 ? 19 : (what & 0x40000) != 0 ? 7 : (what & 0x4000) != 0 ? 25 : (what & 0x200) != 0 ? 12 : itemType == 0x10 ? 10 : 1,
        };
        // a creature: whether it can be attacked is the server's to say (its own monsters aren't in our data, and
        // one of ours may be something else there)
        if (itemType == 0x10 && (what & 0x8) == 0)
        {
            w.Attackable = (what & 0x10) != 0;
            if (w.Type is not (10 or 12 or 15)) w.Type = (what & 0x200) != 0 ? 12 : 10;
        }
        if (soundTable != 0) w.SoundTable = soundTable;
        w.Setup = setup; w.MotionTable = motionTable; w.Scale = scale > 0f ? scale : 1f; w.Placement = placement;
        w.PaletteBase = palBase; w.Palettes = pals; w.TextureMaps = texs; w.AnimParts = parts;
        // (nothing of its own worked out on top: the server's description is the whole look)
        w.ClothingBase = 0; w.PaletteTemplate = 0; w.Shade = 0f; w.Worn = new();
        w.Eyes = w.Nose = w.Mouth = w.Head = w.HairPalette = w.EyesPalette = w.SkinPalette = 0;
        w.Exact = true;
        data.AddWeenie(id, w);
        _looks[sig] = id;
        return id;
    }

    // ── /net: what's come from the server, for working out what's missing ──
    private int _seen, _carried;
    private readonly List<string> _notShown = new();
    private uint _myCell;

    /// <summary>The connection's state in a few lines (/net).</summary>
    public IEnumerable<string> Report()
    {
        yield return Client == null ? "not connected" : $"connected: {(_inWorld ? "in the world" : "at the character screen")}, character id {_me:X8}, placed by the server in cell {_myCell:X8}; now in cell {Player.Cell:X8}";
        if (Client != null) yield return $"packets from the server that went missing: {Client.Lost} ({Client.Recovered} came on asking again, {Client.GaveUp} never did); ours it asked for again: {Client.Resent}";
        yield return $"objects the server has described: {_seen} ({_carried} carried or worn, {Inv?.Pack.Count ?? 0} in your pack, {Inv?.Worn.Count ?? 0} on you, {_things.Count} shown in the world, {_notShown.Count} it couldn't show)";
        if (_notShown.Count > 0) yield return "not shown: " + string.Join("; ", _notShown);
        if (Objects.LastDoorSound.Length > 0) yield return Objects.LastDoorSound;
        if (_badOps.Count > 0) yield return "messages it couldn't read: " + string.Join(", ", _badOps.Select(o => $"0x{o:X4}"));
    }

    /// <summary>What a server object is (kept on its selectable).</summary>
    public sealed record NetObject(uint Guid, string Name, int Wcid);

    private void UpdatePosition(BinaryReader r)
    {
        uint guid = r.ReadUInt32();
        _heard[guid] = _clock;
        uint flags = r.ReadUInt32();
        uint cell = r.ReadUInt32();
        var local = new System.Numerics.Vector3(r.ReadSingle(), r.ReadSingle(), r.ReadSingle());
        float qw = 0, qx = 0, qy = 0, qz = 0;
        if ((flags & 0x08) == 0) qw = r.ReadSingle();
        if ((flags & 0x10) == 0) qx = r.ReadSingle();
        if ((flags & 0x20) == 0) qy = r.ReadSingle();
        if ((flags & 0x40) == 0) qz = r.ReadSingle();
        if ((flags & 0x01) != 0) { r.ReadSingle(); r.ReadSingle(); r.ReadSingle(); }
        if ((flags & 0x02) != 0) r.ReadUInt32();
        ushort inst = r.ReadUInt16(); r.ReadUInt16();
        ushort tele = r.ReadUInt16(), force = r.ReadUInt16();
        if (guid == _me)
        {
            _instanceSeq = inst;
            bool jump = tele != _teleportSeq || force != _forceSeq || _teleporting;
            _teleporting = false;
            _teleportSeq = tele; _forceSeq = force;
            // (how far the server's account of where we are is from where we said we were - and from where we are now)
            if (!jump && _placed)
            {
                var srv = Godot(cell, local);
                // (how fast we're going here and how fast the server has us going, between its answers)
                if (_echoClock > 0 && _clock - _echoClock > 0.05 && _clock - _echoClock < 3)
                {
                    float gap = (float)(_clock - _echoClock);
                    Vector2 F(Vector3 v) => new(v.X, v.Z);
                    _mySpeed = F(Player.Position).DistanceTo(F(_echoMe)) / gap;
                    _srvSpeed = F(srv).DistanceTo(F(_echoSrv)) / gap;
                }
                _echoClock = _clock; _echoMe = Player.Position; _echoSrv = srv;
                // (it answers each position we send, a little after: the nearest of the last few we sent)
                float fromSaid = _sentAt.Count == 0 ? srv.DistanceTo(_lastSent) : _sentAt.Min(p => srv.DistanceTo(p)), fromHere = srv.DistanceTo(Player.Position);
                _posEchoes++;
                // (somewhere else entirely and we weren't told it was a teleport - but it was one: the server waits to hear
                // we've arrived before it takes anything more from us)
                // (only when we haven't just said so: a second "arrived" during a recall has been followed by the server
                // going down - ILT twice, 21:13 and 21:22 on Nov 18)
                if (fromSaid > 200f && fromHere < 5f && _clock - _arrivedSaidAt > 60)
                {
                    PosLog($"moved {fromSaid:0} m without a teleport said - telling the server we've arrived");
                    SayArrived();
                }
                if (fromSaid > 0.5f) { _posOff++; if (fromSaid > _posWorst) _posWorst = fromSaid;
                    PosLog($"the server has us {fromSaid:0.0} m from where we last said (and {fromHere:0.0} m from where we are now)"); }
                // the server keeps having us somewhere else (it isn't taking our moves - blocked, held, rubber-banding): go
                // where it has us, rather than carry on apart from it (ILT logs a client that stays out of step off)
                if (fromSaid > 2f && fromHere > 3f)
                {
                    if (_clock - _driftAt > 1.5) _driftCount = 0;
                    _driftAt = _clock; _driftCount++;
                    if (_driftCount >= 2 && !_teleporting && !Player.Dead)
                    {
                        PosLog($"out of step with the server ({fromHere:0.0} m, {_driftCount} answers running; us {_mySpeed:0.0} m/s here, {_srvSpeed:0.0} m/s by the server) - going where it has us");
                        DriftNote(fromHere);
                        _driftCount = 0; _posSnaps++;
                        PlaceMe(cell, local, new System.Numerics.Quaternion(qx, qy, qz, qw));
                        _sentAt.Clear();
                        return;
                    }
                }
                else _driftCount = 0;
                // (and the way it has us facing - the rotation with each of its answers)
                if (qw != 0 || qz != 0)
                {
                    float srvYaw = 2f * MathF.Atan2(qz, qw);
                    float off = MathF.Abs(Mathf.Wrap(srvYaw - _lastHeading, -MathF.PI, MathF.PI)) * 180f / MathF.PI;
                    if (off > 20f) { _headOff++; PosLog($"the server has us facing {off:0} degrees off the way we last said"); }
                }
            }
            // the server moving us (a teleport, a portal, a correction): go there
            if (jump || !_placed)
            {
                bool first = !_placed;
                if (first) _settledAt = _clock + 2.5;   // (just into the world: the server takes no stance from us for a moment)
                PlaceMe(cell, local, new System.Numerics.Quaternion(qx, qy, qz, qw));
                if (Player.Dead) Died?.Invoke(false);   // (dead and put at the lifestone: up again)
                // (through a portal: the server waits to hear we've arrived before it lets us act)
                if (!first && jump)
                {
                    if (_clock - _arrivedSaidAt > 2) SayArrived();
                    else PosLog("moved again by the server just after we said we'd arrived - not saying it twice");
                    // what was round us where we were is left behind - but kept for 25 s, as the server keeps it known to us
                    // that long (ACE's ObjectMaint.DestructionTime): back within that (a recall there and straight home),
                    // it doesn't send it again, and dropped at once the place stood empty - no doors, nothing
                    _leftBehindAt = _clock + 25;
                    _openContainer = 0;
                }
            }
            return;
        }
        if (!_things.TryGetValue(guid, out var sel) || sel.Node == null) return;
        // (a door's place is its hinge and it doesn't go anywhere: left where its box was measured)
        _where[guid] = (cell, local, 2f * MathF.Atan2(qz, qw));
        if (sel.Type != 19) { sel.Cell = (cell & 0xFFFF) >= 0x100 ? cell : 0; Objects.MoveThing(sel, Godot(cell, local), 2f * MathF.Atan2(qz, qw)); }
    }

    private double _leftBehindAt = -1;
    // what's still far from us 25 s after the server moved us: the server has forgotten it's ours to see, so we do too
    private void DropLeftBehind()
    {
        int n = 0;
        foreach (var (g, far) in _things.Where(kv => kv.Value.Feet.DistanceTo(Player.Position) > 250f).ToList())
        {
            Objects.RemoveGroundItem(far); _things.Remove(g); n++;
            if (_held.TryGetValue(g, out var fh) && !Mine(fh, out _)) _held.Remove(g);
        }
        if (n > 0) PosLog($"dropped {n} things left behind where we were (25 s after the move)");
    }

    private static bool ServerHides(uint physState) => (physState & 0x20) != 0 || (physState & 0x4000) != 0;   // NoDraw, Hidden

    private void ShowThing(ObjectStreamer.Selectable sel, bool show)
    {
        if (sel.Node == null || !GodotObject.IsInstanceValid(sel.Node) || sel.Node.Visible == show) return;
        sel.Node.Visible = show;
        if (!show) Objects.Physics?.SetServerThingSolid(GuidOf(sel), false);   // (shown again: solid as its state says - set with it)
    }

    // "we're out of portal space" - said once for each move the server makes
    // through a portal (a portal, a recall, a summons): counted going in (the server's word we're off somewhere else) and
    // coming out (placed there and saying we've arrived) - the plugins' portal space (Decal's ChangePortalMode), which
    // metas wait on after a recall
    private bool _inPortal;
    public int PortalsEntered { get; private set; }
    public int PortalsExited { get; private set; }

    private void SayArrived()
    {
        if (_inPortal) { _inPortal = false; PortalsExited++; }
        _arrivedSaidAt = _clock;
        Client?.SendAction(0x00A1, Array.Empty<byte>());
    }

    private void PlaceMe(uint cell, System.Numerics.Vector3 local, System.Numerics.Quaternion rot)
    {
        var at = Godot(cell, local);
        _myCell = cell;
        _lastGoodRoom = (cell & 0xFFFF) >= 0x100 ? cell : 0;
        _lastBodyCell = cell;   // (put somewhere by the server: its cell, till the body has one of its own)
        float yaw = 2f * MathF.Atan2(rot.Z, rot.W);
        bool room = (cell & 0xFFFF) >= 0x100;
        // the server has us outdoors where there's a room (a dungeon's rooms lie off their own square of the map - a
        // position sent with the wrong cell lands "outside" there): the room it really is
        if (!room && Objects.RoomCellAt(at + new Vector3(0, 0.5f, 0)) is uint inRoom && inRoom != 0) { cell = inRoom; room = true; }
        PosLog($"put by the server in cell {cell:X8} at {local.X:0.0}, {local.Y:0.0}, z {local.Z:0.00}" + (room ? " (a room)" : ""));
        Player.Enter(at + new Vector3(0, 0.1f, 0), yaw, room ? cell : 0, serverHeight: true);
        if (!_placed) Placed?.Invoke();
        _placed = true;
        _lastSent = Player.Position;
        _sentAt.Clear();   // (the places we said before this are somewhere else now: the server's next answers aren't to them)
    }

    /// <summary>A server position (a cell and a spot in its landblock) in Godot's world.</summary>
    private static Vector3 Godot(uint cell, System.Numerics.Vector3 local)
    {
        int lx = (int)(cell >> 24), ly = (int)((cell >> 16) & 0xFF);
        return World.ToGodot(lx * World.LandblockSize + local.X, ly * World.LandblockSize + local.Y, local.Z);
    }

    // ── what we do ──

    // where we are, as the server takes it: the cell, the spot in its landblock, the way we face
    private uint _lastGoodRoom, _lastBodyCell; private double _badCellNoted = -100;
    private (uint cell, float x, float y, float z, float half) _lastGoodPlace;
    // where we are, written for the server; false (nothing written) if there's no good place to tell it yet
    private bool WritePlace(BinaryWriter w)
    {
        var (x, y, z) = World.ToAc(Player.Position);
        int lx = (int)MathF.Floor(x / World.LandblockSize), ly = (int)MathF.Floor(y / World.LandblockSize);
        float px = x - lx * World.LandblockSize, py = y - ly * World.LandblockSize;
        uint cell = Player.Cell;
        // (no body yet - just in, or just moved, and its room's collision still loading: the cell the server put us in,
        // not one made up from the position. In a room south of its landblock - an apartment hall - that made-up cell
        // was out on the landscape a landblock away, and the server turned it down: "movement pre-validation failed
        // from 53640157 to 5363000D", Nov 18 22:09 at login)
        // (and between, the last cell the body was in: put down afresh, the collision's moved on, it's a moment without)
        if (cell != 0) _lastBodyCell = cell;
        else if (_lastBodyCell != 0) cell = _lastBodyCell;
        bool outdoors = (cell & 0xFFFF) < 0x100 || (cell & 0xFFFF) >= 0xFFFE;
        // outdoors where there's no landscape - off the map's 255 x 255 landblocks (0 to FE), as in an apartment hall,
        // whose landblock is row FF: a place no server can load. ILT went down three times on a position like that
        // (Nov 18, each a house recall to Melka's apartment; their fix #611 "Validate client positions before loading
        // their landblock"). Never sent: the room the server last put us in stands in for it
        if (outdoors && (lx < 0 || lx > 0xFE || ly < 0 || ly > 0xFE))
        {
            uint stand = (_lastGoodRoom & 0xFFFF) >= 0x100 ? _lastGoodRoom : _myCell;
            if (_clock - _badCellNoted > 10)
            {
                _badCellNoted = _clock;
                PosLog($"we're 'outdoors' at landblock {lx:X}{ly:X2} (off the map, in cell {Player.Cell:X8}) - telling the server cell {stand:X8} instead");
            }
            cell = stand; outdoors = (cell & 0xFFFF) < 0x100;
            if (outdoors)
            {
                lx = (int)(cell >> 24); ly = (int)((cell >> 16) & 0xFF);
                px = Math.Clamp(x - lx * World.LandblockSize, 0f, World.LandblockSize - 0.01f);
                py = Math.Clamp(y - ly * World.LandblockSize, 0f, World.LandblockSize - 0.01f);
            }
        }
        if (outdoors)
        {
            // outdoors: the landscape cell under us (8x8 cells of 24 m)
            int cx = Math.Clamp((int)(px / 24f), 0, 7), cy = Math.Clamp((int)(py / 24f), 0, 7);
            cell = ((uint)lx << 24) | ((uint)ly << 16) | (uint)(cx * 8 + cy + 1);
        }
        else
        {
            // a room: its own landblock's frame
            lx = (int)(cell >> 24); ly = (int)((cell >> 16) & 0xFF);
            px = x - lx * World.LandblockSize; py = y - ly * World.LandblockSize;
            _lastGoodRoom = cell;
        }
        float half = Player.Heading * 0.5f;   // Godot yaw is the AC heading (about +Z, which is Godot +Y)
        // (never a number that isn't one: a NaN or infinity from the physics, sent as where we are, is a place no
        // server can work out - the last good one goes instead)
        if (!float.IsFinite(px) || !float.IsFinite(py) || !float.IsFinite(z) || !float.IsFinite(half) || cell == 0)
        {
            if (_clock - _badCellNoted > 10) { _badCellNoted = _clock; PosLog($"our place isn't a place ({px},{py},{z} heading {half * 2f} cell {cell:X8}) - sending the last good one"); }
            (cell, px, py, z, half) = _lastGoodPlace;
        }
        else _lastGoodPlace = (cell, px, py, z, half);
        if (cell == 0) return false;
        w.Write(cell); w.Write(px); w.Write(py); w.Write(z);
        w.Write(MathF.Cos(half)); w.Write(0f); w.Write(0f); w.Write(MathF.Sin(half));
        return true;
    }

    private ushort _motionSeq;
    private uint _ownGesture; private double _ownGestureAt = -100;   // (the last gesture we asked for ourselves)
    private (int f, int s, int t, bool walk, uint stance, uint pose) _moveSent = (0, 0, 0, false, 0, 0);

    /// <summary>
    /// What we're doing, told to the server as the game's own client tells it, so everyone near sees it: the keys held
    /// (forward or back, a side-step, a turn; walking or running), the stance, a pose held (sitting, crouching), and with it a
    /// gesture done once (a wave). Sent when any of it changes. False: not on a server.
    /// </summary>
    public bool SendMotion(uint command = 0) => SendMotion(command, false);

    private bool SendMotion(uint command, bool stopped)
    {
        if (!_inWorld || Client == null || !_placed) return false;
        var (f, sd, t, walk) = stopped ? (0, 0, 0, Player.Moving.walk) : Player.Moving;
        uint pose = Player.Pose;
        if (command != 0 && (command & 0x40000000u) != 0) { pose = command == 0x41000003u ? 0 : command; command = 0; }   // (a pose asked for by name)
        using var b = new MemoryStream();
        var w = new BinaryWriter(b);
        uint forward = f > 0 ? 0x45000005u : f < 0 ? 0x45000006u : pose;
        uint stance = Player.Stance;
        uint flags = 0x1u | (stance != 0 ? 0x2u : 0) | (forward != 0 ? 0x4u : 0) | (sd != 0 ? 0x20u : 0) | (t != 0 ? 0x100u : 0) | (command != 0 ? 1u << 11 : 0);
        w.Write(flags);
        w.Write(walk ? 1u : 2u);                 // the hold key: none (walking), or run
        if (stance != 0) w.Write(stance);
        if (forward != 0) w.Write(forward);      // walking forward (a run, with the run key) or back; or the pose
        if (sd != 0) w.Write(sd > 0 ? 0x6500000Fu : 0x65000010u);
        if (t != 0) w.Write(t > 0 ? 0x6500000Eu : 0x6500000Du);   // (to the left is the greater heading)
        if (command != 0) { _ownGesture = command; _ownGestureAt = _clock; }
        if (command != 0) { w.Write((ushort)(command & 0xFFFF)); w.Write((ushort)(0x8000 | (++_motionSeq & 0x7FFF))); w.Write(1f); }
        if (!WritePlace(w)) return false;
        w.Write(_instanceSeq); w.Write(_serverControlSeq); w.Write(_teleportSeq); w.Write(_forceSeq);
        w.Write((byte)1);
        while (b.Length % 4 != 0) w.Write((byte)0);
        Client.SendAction(0xF61C, b.ToArray());
        NoteSent();
        _moveSent = (f, sd, t, walk, Player.Stance, pose);
        _lastSent = Player.Position; _lastHeading = Player.Heading;
        return true;
    }

    // a jump of ours, told to the server (which shows it to everyone near): how hard, and the way we leave the ground
    private void TellJump(float extent, System.Numerics.Vector3 local)
    {
        if (!_inWorld || !_placed || Client == null) return;
        HereFirst();
        using var b = new MemoryStream();
        var w = new BinaryWriter(b);
        if (!float.IsFinite(extent) || !float.IsFinite(local.X) || !float.IsFinite(local.Y) || !float.IsFinite(local.Z)) return;
        w.Write(Math.Clamp(extent, 0f, 1f));
        w.Write(local.X); w.Write(local.Y); w.Write(local.Z);
        w.Write(_instanceSeq); w.Write(_serverControlSeq); w.Write(_teleportSeq); w.Write(_forceSeq);
        w.Write(0u); w.Write(0u);   // (nothing jumped at, no spell)
        Client.SendAction(0xF61B, b.ToArray());
    }

    // (each frame: what we're doing has changed since the server was last told)
    private void TellMovement()
    {
        if (!_inWorld || !_placed || Client == null) return;
        Player.Jumped ??= TellJump;
        var (f, sd, t, walk) = Player.Moving;
        // (the server walking or turning us itself - to something used: the game's client says nothing of that move, and
        // ACE calls off what it's walking us to on any movement we send - a corpse used from 2.6 m was turned to, our
        // turn sent, and the use dropped every time; used again when already facing it, it opened)
        bool serverTurn = Player.TurnToYaw is float ty && _srvTurnYaw is float sy && MathF.Abs(ty - sy) < 1e-4f;
        if (_clock < _quietUntil && !Player.MovedByKeys) return;
        if (_srvWalk != null || serverTurn)
        {
            _moveSuppressed = true;
            return;
        }
        if (_moveSuppressed)
        {
            // (the server's move over: standing as it left us - nothing to say of that either)
            _moveSuppressed = false;
            _srvTurnYaw = null;
            if (f == 0 && sd == 0 && t == 0) { _moveSent = (f, sd, t, walk, Player.Stance, Player.Pose); return; }
        }
        if ((f, sd, t, walk, Player.Stance, Player.Pose) != _moveSent) SendMotion();
    }
    private float? _srvTurnYaw;      // (the heading the server last turned us to)
    private bool _moveSuppressed;

    private void SendPosition()
    {
        using var b = new MemoryStream();
        var w = new BinaryWriter(b);
        if (!WritePlace(w)) return;
        w.Write(_instanceSeq); w.Write(_serverControlSeq); w.Write(_teleportSeq); w.Write(_forceSeq);
        w.Write((byte)1);
        while (b.Length % 4 != 0) w.Write((byte)0);
        Client!.SendAction(0xF753, b.ToArray());
        _posSends++; NoteSent();
        _lastSent = Player.Position; _lastHeading = Player.Heading;
    }

    /// <summary>Says something aloud (Talk). True if it went to the server.</summary>
    public bool Talk(string text)
    {
        if (!_inWorld || Client == null) return false;
        using var b = new MemoryStream();
        AcClient.WriteString16L(new BinaryWriter(b), text);
        Client.SendAction(0x0015, b.ToArray());
        return true;
    }

    /// <summary>A tell (Tell: the message, then who to).</summary>
    public bool Tell(string who, string text)
    {
        if (!_inWorld || Client == null) return false;
        using var b = new MemoryStream();
        var w = new BinaryWriter(b);
        AcClient.WriteString16L(w, text);
        AcClient.WriteString16L(w, who);
        Client.SendAction(0x005D, b.ToArray());
        return true;
    }
}
