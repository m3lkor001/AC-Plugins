using System;
using System.Collections.Generic;
using System.Globalization;
using Godot;
using ACGodot.Objects;

namespace ACGodot.UI;

/// <summary>
/// Name tags (as MelkTank / UtilityBelt do them): text over players (with level and &lt;allegiance&gt;), pets, portals
/// (&lt;where they go&gt;), NPCs, vendors and monsters (with level) within a range, each kind with its own colours and
/// sizes. Options > Gameplay > Name tags. Kept in user://ui.cfg [nametags].
/// </summary>
public partial class NameTags : Node3D
{
    public static readonly string[] Kinds = { "Player", "Pet", "AllegiancePlayer", "Portal", "Npc", "Vendor", "Monster" };
    public static readonly string[] Labels = { "Players", "Pets", "Allegiance players", "Portals", "NPCs", "Vendors", "Monsters" };

    public sealed class Style { public bool On = true; public Color TagColor, TickerColor; public float TagSize = 0.15f, TickerSize = 0.1f; }

    public static bool Enabled;
    public static float MaxRange = 35f;
    public static bool Expanded;   // the settings section open
    private static readonly Dictionary<string, Style> _styles = new();
    private static bool _loaded, _restyle;

    public ObjectStreamer? Objects;
    public Func<Vector3>? Me;
    /// <summary>A creature's level from its weenie (0: unknown).</summary>
    public Func<int, int>? LevelOf;
    public Func<ObjectStreamer.Selectable, bool>? IsPet;   // (someone's pet - the server marks them as monsters)

    private sealed class Tag { public Label3D Text = null!, Ticker = null!; public string Kind = ""; public string Name = ""; }
    private readonly Dictionary<ObjectStreamer.Selectable, Tag> _tags = new();
    private double _scanIn;

    private const string Cfg = "user://ui.cfg";

    public static Style StyleFor(string kind)
    {
        Load();
        if (!_styles.TryGetValue(kind, out var s)) _styles[kind] = s = Default(kind);
        return s;
    }

    private static Style Default(string kind)
    {
        var c = kind switch
        {
            "AllegiancePlayer" or "Portal" => new Color(0f, 1f, 0f),
            "Npc" => new Color(1f, 1f, 0f),
            "Vendor" => new Color(1f, 0f, 1f),
            "Monster" => new Color(1f, 0f, 0f),
            _ => new Color(0f, 1f, 1f),   // players, pets
        };
        return new Style { TagColor = c, TickerColor = c };
    }

    public static void Defaults() { _styles.Clear(); foreach (var k in Kinds) _styles[k] = Default(k); Save(); }

    private static void Load()
    {
        if (_loaded) return;
        _loaded = true;
        var cfg = new ConfigFile();
        if (global::ACGodot.SafeConfig.Load(cfg, Cfg) != Error.Ok) return;
        Enabled = (bool)cfg.GetValue("nametags", "enabled", false);
        MaxRange = (float)cfg.GetValue("nametags", "range", 35f);
        Expanded = (bool)cfg.GetValue("nametags", "expanded", false);
        foreach (var k in Kinds)
        {
            if (!cfg.HasSectionKey("nametags", k)) continue;
            var v = ((string)cfg.GetValue("nametags", k)).Split(',');
            if (v.Length < 5) continue;
            var s = Default(k);
            s.On = v[0] != "0";
            s.TagColor = Color.FromHtml(v[1]);
            float.TryParse(v[2], NumberStyles.Float, CultureInfo.InvariantCulture, out s.TagSize);
            s.TickerColor = Color.FromHtml(v[3]);
            float.TryParse(v[4], NumberStyles.Float, CultureInfo.InvariantCulture, out s.TickerSize);
            _styles[k] = s;
        }
    }

    /// <summary>Keeps the settings (and the tags take them on).</summary>
    public static void Save()
    {
        Load();
        var cfg = new ConfigFile();
        global::ACGodot.SafeConfig.Load(cfg, Cfg);
        cfg.SetValue("nametags", "enabled", Enabled);
        cfg.SetValue("nametags", "range", MaxRange);
        cfg.SetValue("nametags", "expanded", Expanded);
        foreach (var k in Kinds)
        {
            var s = StyleFor(k);
            cfg.SetValue("nametags", k, string.Join(",", s.On ? "1" : "0", s.TagColor.ToHtml(), s.TagSize.ToString("0.###", CultureInfo.InvariantCulture),
                                                   s.TickerColor.ToHtml(), s.TickerSize.ToString("0.###", CultureInfo.InvariantCulture)));
        }
        global::ACGodot.SafeConfig.Save(cfg, Cfg);
        _restyle = true;
    }

    public override void _Ready() => Load();

    // what kind of tag something gets (null: none)
    private string? KindOf(ObjectStreamer.Selectable s)
    {
        if (s.Type == 7) return "Portal";
        if (s.Kind == 2 && IsPet?.Invoke(s) == true) return "Pet";
        if (s.Kind == 2) return s.Fight is Combat.Fighter { St: Combat.Fighter.State.Dead } ? null : "Monster";
        if (s.Kind == 1) return s.Type == 12 ? "Vendor" : "Npc";
        if (s.Kind >= 3) return "Player";
        return null;
    }

    private string TextOf(ObjectStreamer.Selectable s, string kind)
    {
        if (kind != "Monster") return s.Name;
        int lvl = s.Fight is Combat.Fighter f && f.W.Level > 0 ? f.W.Level : LevelOf?.Invoke(s.Wcid) ?? 0;
        return lvl > 0 ? $"{s.Name} [{lvl}]" : s.Name;
    }

    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("Tag");
        if (Objects == null || Me == null) return;
        if (!Enabled) { if (_tags.Count > 0) ClearAll(); return; }
        var me = Me();
        float range2 = MaxRange * MaxRange;
        if (_restyle) { _restyle = false; ClearAll(); _scanIn = 0; }
        if ((_scanIn -= delta) <= 0)
        {
            _scanIn = 0.5;
            var seen = new HashSet<ObjectStreamer.Selectable>();
            foreach (var s in Objects.AllSelectables)
            {
                if (s.Gone || string.IsNullOrEmpty(s.Name)) continue;
                if (s.Node != null && GodotObject.IsInstanceValid(s.Node) && !s.Node.Visible) continue;   // (hidden by the server)
                string? kind = KindOf(s);
                if (kind == null || !StyleFor(kind).On || s.Center.DistanceSquaredTo(me) > range2) continue;
                seen.Add(s);
                // (made again when it turns out to be another kind - a pet is known for one a moment after it's seen)
                if (_tags.TryGetValue(s, out var had) && had.Kind != kind) { Drop(had); _tags.Remove(s); }
                if (!_tags.ContainsKey(s)) _tags[s] = Make(s, kind);
            }
            foreach (var s in new List<ObjectStreamer.Selectable>(_tags.Keys))
                if (!seen.Contains(s)) { Drop(_tags[s]); _tags.Remove(s); }
        }
        // over each one, as it moves (the name and level kept up)
        foreach (var (s, t) in _tags)
        {
            string text = TextOf(s, t.Kind);
            if (text != t.Name) { t.Name = text; t.Text.Text = text; }
            float top = Math.Max(s.Top, s.Center.Y + 0.5f) + 0.15f;
            if (t.Ticker.Visible) { t.Ticker.Position = new Vector3(s.Center.X, top, s.Center.Z); top += StyleFor(t.Kind).TickerSize * 1.3f; }
            t.Text.Position = new Vector3(s.Center.X, top, s.Center.Z);
        }
    }

    private Tag Make(ObjectStreamer.Selectable s, string kind)
    {
        var st = StyleFor(kind);
        Label3D L(Color c, float size) => new()
        {
            Billboard = BaseMaterial3D.BillboardModeEnum.Enabled, FontSize = 64, PixelSize = Math.Max(0.02f, size) * 1.3f / 64f,
            Modulate = c, OutlineModulate = new Color(0, 0, 0, c.A * 0.85f), OutlineSize = 10, VerticalAlignment = VerticalAlignment.Bottom,
            DoubleSided = true, Shaded = false,
            // drawn after everything else, so walls (the buildings' rooms are drawn late, in the see-through pass) hide it
            RenderPriority = 127, OutlineRenderPriority = 126,
        };
        var t = new Tag { Kind = kind, Text = L(st.TagColor, st.TagSize), Ticker = L(st.TickerColor, st.TickerSize) };
        t.Name = TextOf(s, kind); t.Text.Text = t.Name;
        // line 2: <allegiance> over players, <destination> over portals (once there's something to show)
        t.Ticker.Visible = false;
        AddChild(t.Text); AddChild(t.Ticker);
        return t;
    }

    private static void Drop(Tag t) { t.Text.QueueFree(); t.Ticker.QueueFree(); }

    private void ClearAll() { foreach (var t in _tags.Values) Drop(t); _tags.Clear(); }
}
