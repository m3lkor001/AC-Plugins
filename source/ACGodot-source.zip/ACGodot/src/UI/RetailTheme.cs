using System;
using System.Collections.Generic;
using Godot;

namespace ACGodot.UI;

/// <summary>
/// The game's look for ACGodot's own windows (character, pack, loot, options...): its font as a Godot font (so labels,
/// buttons and text boxes write in it), its translucent panel with the gold frame pieces round it, its title strip
/// and its gold buttons. Built once the game's interface data is open.
/// </summary>
public static class RetailTheme
{
    /// <summary>The theme (null until the game's interface data is open).</summary>
    public static Theme? Current { get; private set; }
    /// <summary>The game's usual text font, as drawn by the chat (and its size in pixels).</summary>
    public static RetailFont? Text { get; private set; }
    public static FontFile? TextFont { get; private set; }
    public static int TextSize { get; private set; } = 12;

    /// <summary>The text size chosen in the options (1 = the game's own), kept in user://ui.cfg [ui] textscale.</summary>
    public static float Scale => RetailFont.Scale;

    /// <summary>A font size in pixels for our own text, at the chosen text size (the game's font has the one size it's drawn at).</summary>
    public static int Px(int size) => TextFont != null ? (int)MathF.Round(TextSize * Scale) : (int)MathF.Round(size * Scale);

    /// <summary>Reads the chosen text size (before the interface is built).</summary>
    public static void LoadScale()
    {
        var cfg = new ConfigFile();
        if (global::ACGodot.SafeConfig.Load(cfg, "user://ui.cfg") == Error.Ok) RetailFont.Scale = Math.Clamp((float)cfg.GetValue("ui", "textscale", 1f), 1f, 3f);
    }

    /// <summary>A new text size: kept, and everything drawn again in it (a few windows take it when next opened).</summary>
    public static void SetScale(float scale, SceneTree? tree)
    {
        RetailFont.Scale = Math.Clamp(scale, 1f, 3f);
        var cfg = new ConfigFile();
        global::ACGodot.SafeConfig.Load(cfg, "user://ui.cfg");
        cfg.SetValue("ui", "textscale", RetailFont.Scale);
        global::ACGodot.SafeConfig.Save(cfg, "user://ui.cfg");
        if (Current != null && TextFont != null) Current.DefaultFontSize = Px(TextSize);
        tree?.Root.PropagateCall("queue_redraw");
    }

    // ── the font everything is written in: Noto Sans (the plugins' windows' font, the travel arrow's) unless the game's
    // own letters are chosen - user://ui.cfg [ui] font: "noto" (the default), "game", or a font file's path ──

    /// <summary>The fonts to choose from: (what's kept, what's shown) - the ones this computer has.</summary>
    public static List<(string key, string label)> FontChoices()
    {
        var l = new List<(string, string)> { ("noto", "Noto Sans (default)"), ("game", "The game's own") };
        foreach (var (path, label) in new[] { ("/usr/share/fonts/TTF/DejaVuSans.ttf", "DejaVu Sans"), ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "DejaVu Sans"),
                                              ("/usr/share/fonts/liberation/LiberationSans-Regular.ttf", "Liberation Sans"), ("/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf", "Liberation Sans"),
                                              ("/usr/share/fonts/TTF/Roboto-Regular.ttf", "Roboto"), ("/usr/share/fonts/noto/NotoSerif-Regular.ttf", "Noto Serif"),
                                              ("/usr/share/fonts/ubuntu/Ubuntu-R.ttf", "Ubuntu"), ("/usr/share/fonts/cantarell/Cantarell-VF.otf", "Cantarell"),
                                              ("C:/Windows/Fonts/segoeui.ttf", "Segoe UI"), ("C:/Windows/Fonts/arial.ttf", "Arial"), ("C:/Windows/Fonts/tahoma.ttf", "Tahoma"),
                                              ("C:/Windows/Fonts/verdana.ttf", "Verdana"), ("C:/Windows/Fonts/calibri.ttf", "Calibri"), ("C:/Windows/Fonts/georgia.ttf", "Georgia") })
            if (System.IO.File.Exists(path) && !l.Exists(x => x.Item2 == label)) l.Add((path, label));
        return l;
    }

    public static string FontChoice { get; private set; } = "noto";

    /// <summary>Where Noto Sans may be (the plugins' windows' font, as UtilityBelt's): the system's, else the copy that comes
    /// with the game (fonts/ - Windows has none of its own), else a look-alike.</summary>
    public static readonly string[] NotoPaths = { "/usr/share/fonts/noto/NotoSans-Regular.ttf", "/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf",
                                                  "/usr/share/fonts/google-noto/NotoSans-Regular.ttf", ProjectSettings.GlobalizePath("res://fonts/NotoSans-Regular.ttf"),
                                                  "/usr/share/fonts/TTF/DejaVuSans.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "C:/Windows/Fonts/segoeui.ttf" };

    private static FontFile? LoadFontFile(string key)
    {
        if (key == "game") return null;
        foreach (var f in key == "noto" ? NotoPaths : new[] { key })
            if (System.IO.File.Exists(f)) { var ff = new FontFile { Antialiasing = TextServer.FontAntialiasing.Gray, Hinting = TextServer.Hinting.Light }; if (ff.LoadDynamicFont(f) == Error.Ok) return ff; }
        return null;
    }

    private static void LoadFontChoice()
    {
        var cfg = new ConfigFile();
        FontChoice = global::ACGodot.SafeConfig.Load(cfg, "user://ui.cfg") == Error.Ok ? (string)cfg.GetValue("ui", "font", "noto") : "noto";
        RetailFont.Override = LoadFontFile(FontChoice);
        UseAsFallback();
    }

    private static Font? _godotFallback;
    // (Godot's own font - the map's labels, the selection's name over it, a few of our windows - is the chosen one too)
    private static void UseAsFallback()
    {
        try
        {
            _godotFallback ??= ThemeDB.FallbackFont;
            ThemeDB.FallbackFont = RetailFont.Override ?? _godotFallback;
        }
        catch { }
    }

    /// <summary>A new font: kept, and everything drawn again in it (some windows take it when next opened).</summary>
    public static void SetFont(string key, SceneTree? tree)
    {
        FontChoice = key;
        var cfg = new ConfigFile();
        global::ACGodot.SafeConfig.Load(cfg, "user://ui.cfg");
        cfg.SetValue("ui", "font", key);
        global::ACGodot.SafeConfig.Save(cfg, "user://ui.cfg");
        RetailFont.Override = LoadFontFile(key);
        UseAsFallback();
        if (Current != null && Text != null)
        {
            if (RetailFont.Override is FontFile chosen) { TextFont = chosen; TextSize = Math.Max(8, (int)MathF.Round(Text.Height * 1.15f)); }
            else { TextFont = Text.ToGodotFont(); TextSize = Math.Max(Text.Height, 8); }
            if (TextFont != null) { Current.DefaultFont = TextFont; Current.DefaultFontSize = Px(TextSize); }
        }
        tree?.Root.PropagateCall("queue_redraw");
    }

    public static readonly Color Ink = new(0.95f, 0.91f, 0.78f);
    public static readonly Color Gold = new(1f, 0.85f, 0.45f);
    public static readonly Color Dim = new(0.65f, 0.6f, 0.5f);

    // the game's floating-window pieces: corners, edges and the translucent fill (as in its chat window)
    private const uint Fill = 0x06004CC2, Top = 0x060074BF, Left = 0x060074C0, Bottom = 0x060074C1, Right = 0x060074C2,
                       TopLeft = 0x060074C3, TopRight = 0x060074C4, BottomLeft = 0x060074C5, BottomRight = 0x060074C6;
    // the game's button faces (the chat's Send button)
    private const uint ButtonUp = 0x06001915, ButtonDown = 0x06001916, ButtonGhost = 0x06001934;
    private const uint TextFontId = 0x40000002;

    public static void Build(RetailUi ui)
    {
        try
        {
            Text = ui.Font(TextFontId);
            LoadScale();
            LoadFontChoice();
            if (RetailFont.Override is FontFile chosen && Text != null) { TextFont = chosen; TextSize = Math.Max(8, (int)MathF.Round(Text.Height * 1.15f)); }
            else if (Text != null) { TextFont = Text.ToGodotFont(); TextSize = Math.Max(Text.Height, 8); }
            var t = new Theme();
            if (TextFont != null) { t.DefaultFont = TextFont; t.DefaultFontSize = Px(TextSize); }

            var panel = PanelStyle(ui);
            t.SetStylebox("panel", "PanelContainer", panel);
            t.SetStylebox("panel", "Panel", panel);
            t.SetStylebox("panel", "PopupPanel", panel);

            foreach (var type in new[] { "Label", "Button", "CheckBox", "CheckButton", "LineEdit", "OptionButton", "MenuButton", "ItemList", "Tree", "TabBar", "TabContainer", "RichTextLabel" })
            {
                t.SetColor("font_color", type, Ink);
                t.SetColor("font_hover_color", type, Gold);
                t.SetColor("font_pressed_color", type, Gold);
                t.SetColor("font_focus_color", type, Ink);
                t.SetColor("font_disabled_color", type, Dim);
                t.SetColor("default_color", type, Ink);
            }
            t.SetColor("font_selected_color", "TabBar", Gold);
            t.SetColor("font_selected_color", "TabContainer", Gold);
            t.SetColor("font_unselected_color", "TabContainer", Dim);

            // buttons: the game's gold face, darker when held, grey when ghosted
            var up = ButtonStyle(ui, ButtonUp, new Color(0.55f, 0.42f, 0.18f));
            var down = ButtonStyle(ui, ButtonDown, new Color(0.4f, 0.3f, 0.12f));
            var ghost = ButtonStyle(ui, ButtonGhost, new Color(0.3f, 0.28f, 0.25f));
            foreach (var type in new[] { "Button", "OptionButton", "MenuButton" })
            {
                t.SetStylebox("normal", type, up);
                t.SetStylebox("hover", type, up);
                t.SetStylebox("pressed", type, down);
                t.SetStylebox("disabled", type, ghost);
                t.SetStylebox("focus", type, new StyleBoxEmpty());
                // the game writes its buttons' words in white (the font's black outline round them), never dark
                t.SetColor("font_color", type, new Color(1f, 0.97f, 0.9f));
                t.SetColor("font_hover_color", type, new Color(1f, 1f, 0.75f));
                t.SetColor("font_pressed_color", type, new Color(1f, 0.85f, 0.45f));
                t.SetColor("font_focus_color", type, new Color(1f, 0.97f, 0.9f));
                t.SetColor("font_disabled_color", type, new Color(0.6f, 0.58f, 0.55f));
            }
            // check boxes and text boxes on the dark fill
            t.SetStylebox("normal", "CheckBox", new StyleBoxEmpty());
            t.SetStylebox("hover", "CheckBox", new StyleBoxEmpty());
            t.SetStylebox("pressed", "CheckBox", new StyleBoxEmpty());
            t.SetStylebox("focus", "CheckBox", new StyleBoxEmpty());
            var box = new StyleBoxFlat { BgColor = new Color(0f, 0f, 0f, 0.6f), BorderColor = new Color(0.55f, 0.43f, 0.2f),
                                         BorderWidthLeft = 1, BorderWidthRight = 1, BorderWidthTop = 1, BorderWidthBottom = 1,
                                         ContentMarginLeft = 3, ContentMarginRight = 3, ContentMarginTop = 1, ContentMarginBottom = 1 };
            t.SetStylebox("normal", "LineEdit", box);
            t.SetStylebox("focus", "LineEdit", box);
            // tabs: dark, the chosen one lit
            var tab = new StyleBoxFlat { BgColor = new Color(0.12f, 0.09f, 0.05f, 0.95f), BorderColor = new Color(0.55f, 0.43f, 0.2f),
                                         BorderWidthLeft = 1, BorderWidthRight = 1, BorderWidthTop = 1, ContentMarginLeft = 6, ContentMarginRight = 6,
                                         ContentMarginTop = 2, ContentMarginBottom = 2 };
            var tabOn = (StyleBoxFlat)tab.Duplicate(); tabOn.BgColor = new Color(0.35f, 0.25f, 0.1f, 0.95f);
            t.SetStylebox("tab_unselected", "TabContainer", tab);
            t.SetStylebox("tab_hovered", "TabContainer", tab);
            t.SetStylebox("tab_selected", "TabContainer", tabOn);
            t.SetStylebox("panel", "TabContainer", new StyleBoxEmpty());
            // scroll bars: thin, gold on dark
            var track = new StyleBoxFlat { BgColor = new Color(0f, 0f, 0f, 0.5f), ContentMarginLeft = 4, ContentMarginRight = 4 };
            var grab = new StyleBoxFlat { BgColor = new Color(0.6f, 0.47f, 0.2f), CornerRadiusTopLeft = 2, CornerRadiusTopRight = 2, CornerRadiusBottomLeft = 2, CornerRadiusBottomRight = 2 };
            var grabHi = (StyleBoxFlat)grab.Duplicate(); grabHi.BgColor = new Color(0.8f, 0.63f, 0.3f);
            t.SetStylebox("scroll", "VScrollBar", track);
            t.SetStylebox("grabber", "VScrollBar", grab);
            t.SetStylebox("grabber_highlight", "VScrollBar", grabHi);
            t.SetStylebox("grabber_pressed", "VScrollBar", grabHi);
            t.SetStylebox("scroll", "HScrollBar", track);
            t.SetStylebox("grabber", "HScrollBar", grab);
            t.SetStylebox("grabber_highlight", "HScrollBar", grabHi);
            t.SetStylebox("grabber_pressed", "HScrollBar", grabHi);
            // tooltips
            var tip = new StyleBoxFlat { BgColor = new Color(0.05f, 0.04f, 0.02f, 0.95f), BorderColor = new Color(0.62f, 0.47f, 0.22f),
                                         BorderWidthLeft = 1, BorderWidthRight = 1, BorderWidthTop = 1, BorderWidthBottom = 1,
                                         ContentMarginLeft = 4, ContentMarginRight = 4, ContentMarginTop = 2, ContentMarginBottom = 2 };
            t.SetStylebox("panel", "TooltipPanel", tip);
            t.SetColor("font_color", "TooltipLabel", Ink);
            Current = t;
        }
        catch (Exception ex) { GD.PushWarning("retail theme: " + ex.Message); }
    }

    /// <summary>The game's floating-window look as one nine-part picture: the translucent fill inside its gold frame.</summary>
    private static StyleBox PanelStyle(RetailUi ui)
    {
        Image? I(uint id) { var tex = ui.Image(id); var img = tex?.GetImage(); if (img != null && img.IsCompressed()) img.Decompress(); img?.Convert(Image.Format.Rgba8); return img; }
        var fill = I(Fill); var top = I(Top); var left = I(Left); var bottom = I(Bottom); var right = I(Right);
        var tl = I(TopLeft); var tr = I(TopRight); var bl = I(BottomLeft); var br = I(BottomRight);
        if (fill == null || top == null || left == null || bottom == null || right == null || tl == null || tr == null || bl == null || br == null)
            return new StyleBoxFlat { BgColor = new Color(0.08f, 0.06f, 0.04f, 0.9f), BorderColor = new Color(0.62f, 0.47f, 0.22f),
                                      BorderWidthLeft = 2, BorderWidthRight = 2, BorderWidthTop = 2, BorderWidthBottom = 2,
                                      ContentMarginLeft = 8, ContentMarginRight = 8, ContentMarginTop = 6, ContentMarginBottom = 8 };
        const int E = 5, M = 48;   // edge thickness, middle size
        int size = M + 2 * E;
        var img = Image.CreateEmpty(size, size, false, Image.Format.Rgba8);
        for (int y = 0; y < M; y += fill.GetHeight()) for (int x = 0; x < M; x += fill.GetWidth())
            img.BlitRect(fill, new Rect2I(0, 0, Math.Min(fill.GetWidth(), M - x), Math.Min(fill.GetHeight(), M - y)), new Vector2I(E + x, E + y));
        for (int x = 0; x < M; x += top.GetWidth())
        {
            img.BlitRect(top, new Rect2I(0, 0, Math.Min(top.GetWidth(), M - x), E), new Vector2I(E + x, 0));
            img.BlitRect(bottom, new Rect2I(0, 0, Math.Min(bottom.GetWidth(), M - x), E), new Vector2I(E + x, size - E));
        }
        for (int y = 0; y < M; y += left.GetHeight())
        {
            img.BlitRect(left, new Rect2I(0, 0, E, Math.Min(left.GetHeight(), M - y)), new Vector2I(0, E + y));
            img.BlitRect(right, new Rect2I(0, 0, E, Math.Min(right.GetHeight(), M - y)), new Vector2I(size - E, E + y));
        }
        img.BlitRect(tl, new Rect2I(0, 0, E, E), Vector2I.Zero);
        img.BlitRect(tr, new Rect2I(0, 0, E, E), new Vector2I(size - E, 0));
        img.BlitRect(bl, new Rect2I(0, 0, E, E), new Vector2I(0, size - E));
        img.BlitRect(br, new Rect2I(0, 0, E, E), new Vector2I(size - E, size - E));
        return new StyleBoxTexture
        {
            Texture = ImageTexture.CreateFromImage(img),
            TextureMarginLeft = E, TextureMarginRight = E, TextureMarginTop = E, TextureMarginBottom = E,
            AxisStretchHorizontal = StyleBoxTexture.AxisStretchMode.Tile, AxisStretchVertical = StyleBoxTexture.AxisStretchMode.Tile,
            ContentMarginLeft = 8, ContentMarginRight = 8, ContentMarginTop = 6, ContentMarginBottom = 8,
        };
    }

    private static StyleBox ButtonStyle(RetailUi ui, uint image, Color fallback)
    {
        var tex = ui.Image(image);
        if (tex == null)
            return new StyleBoxFlat { BgColor = fallback, BorderColor = new Color(0.25f, 0.15f, 0.05f), BorderWidthLeft = 1, BorderWidthRight = 1,
                                      BorderWidthTop = 1, BorderWidthBottom = 1, ContentMarginLeft = 6, ContentMarginRight = 6, ContentMarginTop = 1, ContentMarginBottom = 1 };
        int m = Math.Max(2, Math.Min(5, (int)tex.GetSize().Y / 3));
        return new StyleBoxTexture
        {
            Texture = tex, TextureMarginLeft = m, TextureMarginRight = m, TextureMarginTop = m, TextureMarginBottom = m,
            ContentMarginLeft = 6, ContentMarginRight = 6, ContentMarginTop = 1, ContentMarginBottom = 1,
        };
    }

    /// <summary>A label in the game's font.</summary>
    public static Label Label(string text, Color? color = null)
    {
        var l = new Label { Text = text };
        if (color is { } c) l.AddThemeColorOverride("font_color", c);
        return l;
    }
}
