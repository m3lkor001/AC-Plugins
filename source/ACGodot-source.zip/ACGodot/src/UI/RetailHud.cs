using System;
using System.Collections.Generic;
using DatReaderWriter.Enums;
using Godot;

namespace ACGodot.UI;

/// <summary>Whether the interface is locked (the radar's lock button): unlocked, windows and bars can be dragged anywhere.</summary>
public static class UiLock
{
    public static bool Locked = true;
    public static event Action? Changed;
    public static void Set(bool locked) { Locked = locked; Changed?.Invoke(); }
}

/// <summary>
/// The parts of the game's own screen built so far, from its interface data: the radar (top right, coordinates under
/// it; its dots select what they stand for; its lock button unlocks the interface for moving things; its arrow button
/// drags it about) and the vitals bar (health, stamina and mana; a click shows or hides the numbers). Where they've
/// been moved to is kept in user://ui.cfg.
/// </summary>
public partial class RetailHud : Control
{
    public const uint RadarLayout = 0x21000074, VitalsStacked = 0x2100006C, VitalsRow = 0x21000075;
    /// <summary>The vitals bars stacked (one above another) or in a row - the game's own two choices.</summary>
    public static bool VitalsStackedChoice = true;
    private float _vitalsWidth;   // widened (0: as the layout has it)
    private const uint RadarCoords = 0x1000003E, RadarCircle = 0x1000003F, RadarMove = 0x100006A3, RadarLock = 0x10000619;
    private const uint HealthMeter = 0x100000E6, StaminaMeter = 0x100000EC, ManaMeter = 0x100000EE;
    private const uint HealthText = 0x100000EB, StaminaText = 0x100000ED, ManaText = 0x100000EF;
    private const string SavePath = "user://ui.cfg";

    private UiNode? _radar, _vitals;
    private RadarBlips? _blips;
    private Vector2? _radarAt, _vitalsAt;   // moved there (null: the usual place)
    private bool _showNumbers;

    /// <summary>A radar dot clicked: what it stands for.</summary>
    public Action<object>? BlipClicked;

    public void Setup(RetailUi ui)
    {
        MouseFilter = MouseFilterEnum.Ignore;
        Load();
        _radar = ui.Build(RadarLayout);
        if (_radar != null)
        {
            AddChild(_radar);
            // the coordinates' backdrop a little darker than the game's (easier to read over a bright sky)
            if (_radar.Find(RadarCoords) is { } coordsBox)
            {
                var back = new ColorRect { Color = new Color(0f, 0f, 0f, 0.5f), MouseFilter = MouseFilterEnum.Ignore, ShowBehindParent = true };
                coordsBox.AddChild(back);
                back.Size = coordsBox.Size;
                coordsBox.Resized += () => back.Size = coordsBox.Size;
                coordsBox.CenterText();   // (in the middle of its strip, not hard against its left)
                // the time of day (the real one), on a strip of its own just under the coordinates
                try
                {
                    _clock = new UiNode(ui, coordsBox.R.E) { Position = coordsBox.Position + new Vector2(0, coordsBox.Size.Y), Pinned = true };
                    coordsBox.GetParent().AddChild(_clock);
                    var clockBack = new ColorRect { Color = new Color(0f, 0f, 0f, 0.5f), MouseFilter = MouseFilterEnum.Ignore, ShowBehindParent = true, Size = _clock.Size };
                    _clock.AddChild(clockBack);
                    _clock.CenterText();
                }
                catch (Exception ex) { GD.PushWarning("radar clock: " + ex.Message); _clock = null; }
            }
            if (_radar.Find(RadarCircle) is { } circle)
            {
                _blips = new RadarBlips { Size = circle.Size, MouseFilter = MouseFilterEnum.Stop };
                _blips.Clicked = o => BlipClicked?.Invoke(o);
                circle.AddChild(_blips);
            }
            if (_radar.Find(RadarMove) is { } move) Draggable(move, _radar, p => _radarAt = p, always: false);
            if (_radar.Find(RadarLock) is { } lk)
            {
                lk.SetState(UiLock.Locked ? UIStateId.LockedUI : UIStateId.UnlockedUI);
                _lockIcon = lk;
                // (locked or unlocked from anywhere - this button or Options - the radar's lock shows it and it's kept)
                if (!_lockHooked) { _lockHooked = true; UiLock.Changed += LockChanged; }
                lk.OnInput = e =>
                {
                    if (e is InputEventMouseButton { Pressed: true, ButtonIndex: MouseButton.Left })
                        UiLock.Set(!UiLock.Locked);
                };
            }
        }
        _ui = ui;
        BuildVitals();
    }

    private RetailUi? _ui;

    /// <summary>The health, stamina and mana bars stacked, or in a row (the character options' choice), rebuilt now.</summary>
    public void SetVitalsStacked(bool stacked)
    {
        if (stacked == VitalsStackedChoice && _vitals != null) return;
        VitalsStackedChoice = stacked;
        _vitalsWidth = 0;
        Save();
        BuildVitals();
    }

    private void BuildVitals()
    {
        if (_ui == null) return;
        if (_vitals != null) { _vitals.QueueFree(); _vitals = null; }
        _vitals = _ui.Build(VitalsStackedChoice ? VitalsStacked : VitalsRow);
        if (_vitals != null)
        {
            AddChild(_vitals);
            if (_vitalsWidth > 0) _vitals.Resize(new Vector2(Math.Clamp(_vitalsWidth, MinWidth(_vitals), MaxWidth(_vitals)), _vitals.DesignSize.Y));
            // its right-hand edge and corners widen it (unlocked), between the layout's least and most widths
            foreach (uint h in new uint[] { 0x10000642, 0x1000063D, 0x10000641, 0x100006E5, 0x100006E0, 0x100006E4 })
                if (_vitals.Find(h) is { } edge) Widener(edge, _vitals);
            Draggable(_vitals, _vitals, p => _vitalsAt = p, always: false, click: () => { _showNumbers = !_showNumbers; ShowNumbers(); Save(); });
            ShowNumbers();
        }
    }

    /// <summary>
    /// Makes an element drag something about (always, or only with the interface unlocked); a click that doesn't move
    /// does the click instead.
    /// </summary>
    private void Draggable(UiNode handle, Control moves, Action<Vector2> moved, bool always, Action? click = null)
    {
        bool down = false, dragged = false;
        Vector2 grab = Vector2.Zero;
        handle.OnInput = e =>
        {
            if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb)
            {
                if (mb.Pressed) { down = true; dragged = false; grab = moves.GetGlobalMousePosition() - moves.Position; }
                else
                {
                    if (down && !dragged) click?.Invoke();
                    if (down && dragged) Save();
                    down = false;
                }
                handle.AcceptEvent();
            }
            else if (e is InputEventMouseMotion && down && (always || !UiLock.Locked))
            {
                var p = moves.GetGlobalMousePosition() - grab;
                // kept all on the screen (it stops at the edges)
                var vp = moves.GetViewportRect().Size;
                p = new Vector2(Math.Clamp(p.X, 0, Math.Max(0, vp.X - moves.Size.X)), Math.Clamp(p.Y, 0, Math.Max(0, vp.Y - moves.Size.Y)));
                if (!dragged && p.DistanceTo(moves.Position) < 3f) return;
                dragged = true;
                moves.Position = p;
                moved(p);
                handle.AcceptEvent();
            }
        };
    }

    // a window's least and most widths (its properties 0x3F and 0x3D)
    private static float MinWidth(UiNode n) => n.R.Props.TryGetValue(0x3F, out var p) && p is DatReaderWriter.Types.IntegerBaseProperty i ? i.Value : n.DesignSize.X;
    private static float MaxWidth(UiNode n) => n.R.Props.TryGetValue(0x3D, out var p) && p is DatReaderWriter.Types.IntegerBaseProperty i ? Math.Max(i.Value, n.DesignSize.X) : n.DesignSize.X;

    private void Widener(UiNode edge, UiNode window)
    {
        bool down = false;
        edge.OnInput = e =>
        {
            if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb)
            {
                down = mb.Pressed && !UiLock.Locked;
                if (!mb.Pressed) Save();
                edge.AcceptEvent();
            }
            else if (e is InputEventMouseMotion && down)
            {
                float w = Math.Clamp(window.GetGlobalMousePosition().X - window.GlobalPosition.X, MinWidth(window), MaxWidth(window));
                window.Resize(new Vector2(w, window.DesignSize.Y));
                _vitalsWidth = w;
                edge.AcceptEvent();
            }
        };
    }

    private void ShowNumbers()
    {
        if (_vitals == null) return;
        // the numbers, in the middle of each bar; without them, each bar's icon shows there instead
        _vitals.SetState(_showNumbers ? UIStateId.HideDetail : UIStateId.ShowDetail);
        foreach (uint t in new[] { HealthText, StaminaText, ManaText })
            if (_vitals.Find(t) is { } n) { n.Visible = _showNumbers; n.CenterText(); }
    }

    public bool Ready2 => _radar != null || _vitals != null;

    /// <summary>Brings it up to date: where you are and face, what's around, and your vitals.</summary>
    private UiNode? _clock;
    public void Show(string coords, float heading, IEnumerable<(Vector2 offset, Color color, object what)> blips,
                     IEnumerable<(Vector2 a, Vector2 b)> walls, object? selected,
                     int hp, int maxHp, int st, int maxSt, int mp, int maxMp)
    {
        Vector2 screen = GetViewportRect().Size;
        Position = Vector2.Zero; Size = screen;
        if (_radar != null)
        {
            _radar.Position = Clamp(_radarAt ?? new Vector2(screen.X - _radar.Size.X - 8, 8), _radar.Size, screen);
            if (_radar.Find(RadarCoords) is { } c) c.Text = coords;
            if (_clock != null) { string now = DateTime.Now.ToString("h:mm tt", System.Globalization.CultureInfo.InvariantCulture); if (_clock.Text != now) _clock.Text = now; }
            if (_blips != null)
            {
                _blips.Heading = heading; _blips.Selected = selected;
                _blips.Points.Clear(); _blips.Points.AddRange(blips);
                _blips.Walls.Clear(); _blips.Walls.AddRange(walls);
                _blips.QueueRedraw();
            }
            // the compass letters go round the ring as you turn (what's ahead is always up)
            var centre = new Vector2(60, 60);
            foreach (var (id, ang) in new[] { (0x10000040u, 0f), (0x10000041u, MathF.PI / 2), (0x10000042u, MathF.PI), (0x10000043u, -MathF.PI / 2) })
                if (_radar.Find(id) is { } letter)
                {
                    float a = ang + heading;
                    var dir = new Vector2(MathF.Sin(a), -MathF.Cos(a));
                    letter.Position = centre + dir * 55f - letter.Size * 0.5f;
                }
        }
        if (_vitals != null)
        {
            _vitals.Position = Clamp(_vitalsAt ?? new Vector2((screen.X - _vitals.Size.X) * 0.5f, screen.Y - _vitals.Size.Y - 6), _vitals.Size, screen);
            Set(HealthMeter, HealthText, hp, maxHp);
            Set(StaminaMeter, StaminaText, st, maxSt);
            Set(ManaMeter, ManaText, mp, maxMp);
        }
    }

    private static Vector2 Clamp(Vector2 p, Vector2 size, Vector2 screen) =>
        new(Math.Clamp(p.X, 0, Math.Max(0, screen.X - size.X)), Math.Clamp(p.Y, 0, Math.Max(0, screen.Y - size.Y)));

    private void Set(uint meter, uint text, int v, int max)
    {
        if (_vitals?.Find(meter) is { } m) m.Fraction = max > 0 ? (float)v / max : 0f;
        if (_vitals?.Find(text) is { } t) t.Text = $"{Math.Max(v, 0)}/{max}";
    }

    public float VitalsTop => _vitals != null && _vitalsAt == null ? _vitals.Position.Y : GetViewportRect().Size.Y;

    private void Load()
    {
        var cfg = new ConfigFile();
        if (global::ACGodot.SafeConfig.Load(cfg, SavePath) != Error.Ok) return;
        if (cfg.HasSectionKey("ui", "radar")) _radarAt = (Vector2)cfg.GetValue("ui", "radar");
        if (cfg.HasSectionKey("ui", "vitals")) _vitalsAt = (Vector2)cfg.GetValue("ui", "vitals");
        _showNumbers = (bool)cfg.GetValue("ui", "vital_numbers", false);
        _vitalsWidth = (float)cfg.GetValue("ui", "vitals_width", 0f);
        VitalsStackedChoice = (bool)cfg.GetValue("ui", "vitals_stacked", true);
        UiLock.Locked = (bool)cfg.GetValue("ui", "locked", true);
    }

    private UiNode? _lockIcon;
    private bool _lockHooked;

    private void LockChanged()
    {
        if (_lockIcon != null && IsInstanceValid(_lockIcon)) _lockIcon.SetState(UiLock.Locked ? UIStateId.LockedUI : UIStateId.UnlockedUI);
        Save();
    }

    public override void _ExitTree()
    {
        if (_lockHooked) { UiLock.Changed -= LockChanged; _lockHooked = false; }
        base._ExitTree();
    }

    private void Save()
    {
        var cfg = new ConfigFile();
        global::ACGodot.SafeConfig.Load(cfg, SavePath);
        if (_radarAt is { } r) cfg.SetValue("ui", "radar", r);
        if (_vitalsAt is { } v) cfg.SetValue("ui", "vitals", v);
        cfg.SetValue("ui", "vital_numbers", _showNumbers);
        cfg.SetValue("ui", "vitals_width", _vitalsWidth);
        cfg.SetValue("ui", "vitals_stacked", VitalsStackedChoice);
        cfg.SetValue("ui", "locked", UiLock.Locked);
        global::ACGodot.SafeConfig.Save(cfg, SavePath);
    }

    /// <summary>The dots on the radar: what's around, turned so the way you face is up (the lighter wedge is what you can see). Click a dot to select it.</summary>
    private sealed partial class RadarBlips : Control
    {
        public readonly List<(Vector2 offset, Color color, object what)> Points = new();   // offset: -1..1 of the radar's reach (x east, y south)
        public readonly List<(Vector2 a, Vector2 b)> Walls = new();   // the map: walls, in the same -1..1 terms
        public float Heading;
        public object? Selected;
        public Action<object>? Clicked;

        private Vector2 Centre => Size * 0.5f;
        private const float ViewHalf = 0.75f;   // half the view's width, radians
        // north-up offsets turned so the way you face is up
        private Vector2 Turn(Vector2 v) { float c = MathF.Cos(Heading), s = MathF.Sin(Heading); return new Vector2(v.X * c - v.Y * s, v.X * s + v.Y * c); }
        private float Reach => Size.X * 0.5f - 6f;

        /// <summary>A line cut to the radar's circle (null if none of it is inside).</summary>
        private static (Vector2, Vector2)? Clip(Vector2 a, Vector2 b)
        {
            bool ina = a.LengthSquared() <= 1f, inb = b.LengthSquared() <= 1f;
            if (ina && inb) return (a, b);
            Vector2 d = b - a;
            float A = d.Dot(d), B = 2 * a.Dot(d), C = a.Dot(a) - 1f, disc = B * B - 4 * A * C;
            if (A < 1e-9f || disc < 0) return null;
            float sq = MathF.Sqrt(disc), t0 = (-B - sq) / (2 * A), t1 = (-B + sq) / (2 * A);
            t0 = Math.Max(t0, 0f); t1 = Math.Min(t1, 1f);
            if (t0 >= t1) return null;
            return (a + d * t0, a + d * t1);
        }

        public override void _Draw() { long __fw = ACGodot.FrameWatch.DrawStart(); try { DrawBody(); } finally { ACGodot.FrameWatch.Drew("RadarBlips", __fw); } }
        private void DrawBody()
        {
            // the map: walls of the building or dungeon you're in, and of buildings around
            // what you can see: a lighter wedge straight ahead (up)
            var cone = new List<Vector2> { Centre };
            for (int i = 0; i <= 16; i++) { float a = -ViewHalf + 2 * ViewHalf * i / 16f; cone.Add(Centre + new Vector2(MathF.Sin(a), -MathF.Cos(a)) * (Reach + 4f)); }
            DrawColoredPolygon(cone.ToArray(), new Color(1f, 1f, 0.9f, 0.13f));
            var wall = new Color(0.78f, 0.74f, 0.6f, 0.85f);
            foreach (var (a, b) in Walls)
                if (Clip(Turn(a), Turn(b)) is var (ca, cb)) DrawLine(Centre + ca * Reach, Centre + cb * Reach, wall, 1f);
            foreach (var (o0, col, what) in Points)
            {
                var o = Turn(o0);
                if (o.LengthSquared() > 1f) continue;
                Vector2 p = Centre + o * Reach;
                DrawRect(new Rect2(p - new Vector2(1.5f, 1.5f), new Vector2(3, 3)), col);
                // what's selected: ringed in its own colour
                if (Selected != null && ReferenceEquals(what, Selected)) DrawArc(p, 5f, 0, MathF.Tau, 16, col, 1f);
            }
            // you: a small white arrow in the middle, pointing ahead (up)
            Vector2 f = new(0, -1);
            Vector2 side = new(-f.Y, f.X);
            Vector2 c = Centre;
            DrawColoredPolygon(new[] { c + f * 5f, c - f * 3f + side * 3f, c - f * 3f - side * 3f }, Colors.White);
        }

        /// <summary>The dot under this point (within a few pixels), or null.</summary>
        private object? DotAt(Vector2 at)
        {
            object? best = null; float bestD = 6f;
            foreach (var (o0, _, what) in Points)
            {
                var o = Turn(o0);
                if (o.LengthSquared() > 1f) continue;
                float d = (Centre + o * Reach).DistanceTo(at);
                if (d < bestD) { bestD = d; best = what; }
            }
            return best;
        }

        public override void _GuiInput(InputEvent e)
        {
            if (e is not InputEventMouseButton { Pressed: true, ButtonIndex: MouseButton.Left } mb) return;
            if (DotAt(mb.Position) is { } best) { Clicked?.Invoke(best); AcceptEvent(); }
        }

        // hovering a dot: what it is (its name)
        public override void _Ready() { TooltipText = " "; }
        public override string _GetTooltip(Vector2 at)
        {
            var w = DotAt(at);
            string name = w switch
            {
                ACGodot.Objects.ObjectStreamer.Selectable s => s.Name,
                ACGodot.Combat.Item i => i.Name,
                null => "",
                _ => w.ToString() ?? "",
            };
            return name;
        }
    }
}
