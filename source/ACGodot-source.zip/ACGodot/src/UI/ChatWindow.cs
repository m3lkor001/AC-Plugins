using System;
using System.Collections.Generic;
using DatReaderWriter.Types;
using Godot;

namespace ACGodot.UI;

/// <summary>
/// Moving and resizing one of the game's floating windows by its own frame: its edge and corner pieces resize it
/// (which sides each one moves is in its properties: 0x2A bottom, 0x2B left, 0x2C right, 0x2D top), its plain border
/// pieces move it - with the interface unlocked. Its least and most sizes are its properties 0x3F/0x3E (width,
/// height) and 0x3D/0x3C.
/// </summary>
public static class WindowFrame
{
    public static Vector2 MinSize(UiNode w) => new(Int(w, 0x3F) ?? w.DesignSize.X, Int(w, 0x3E) ?? w.DesignSize.Y);
    public static Vector2 MaxSize(UiNode w) => new(Math.Max(Int(w, 0x3D) ?? w.DesignSize.X, w.DesignSize.X), Math.Max(Int(w, 0x3C) ?? w.DesignSize.Y, w.DesignSize.Y));

    private static int? Int(UiNode n, uint key) => n.R.Props.TryGetValue(key, out var p) && p is IntegerBaseProperty i ? i.Value : null;
    private static bool Flag(UiNode n, uint key) => n.R.Props.TryGetValue(key, out var p) && p is BoolBaseProperty b && b.Value;

    /// <summary>Hooks up a window's frame. <paramref name="changed"/> is told its new place and size after a move or resize.</summary>
    public static void Attach(UiNode window, Action<Vector2, Vector2> changed)
    {
        foreach (var n in All(window))
        {
            if (n == window || (n.R.E.Type != 9 && n.R.E.Type != 2)) continue;
            bool bottom = Flag(n, 0x2A), left = Flag(n, 0x2B), right = Flag(n, 0x2C), top = Flag(n, 0x2D);
            bool resize = bottom || left || right || top;
            bool down = false;
            Vector2 grabMouse = Vector2.Zero, grabPos = Vector2.Zero, grabSize = Vector2.Zero;
            var node = n;
            node.OnInput = e =>
            {
                if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb)
                {
                    down = mb.Pressed && !UiLock.Locked;
                    grabMouse = node.GetGlobalMousePosition(); grabPos = window.Position; grabSize = window.Size;
                    if (!mb.Pressed) changed(window.Position, window.Size);
                    node.AcceptEvent();
                }
                else if (e is InputEventMouseMotion && down)
                {
                    Vector2 d = node.GetGlobalMousePosition() - grabMouse;
                    if (!resize) { window.Position = grabPos + d; node.AcceptEvent(); return; }
                    Vector2 min = MinSize(window), max = MaxSize(window);
                    Vector2 pos = grabPos, size = grabSize;
                    if (right) size.X = Math.Clamp(grabSize.X + d.X, min.X, max.X);
                    if (bottom) size.Y = Math.Clamp(grabSize.Y + d.Y, min.Y, max.Y);
                    if (left) { size.X = Math.Clamp(grabSize.X - d.X, min.X, max.X); pos.X = grabPos.X + grabSize.X - size.X; }
                    if (top) { size.Y = Math.Clamp(grabSize.Y - d.Y, min.Y, max.Y); pos.Y = grabPos.Y + grabSize.Y - size.Y; }
                    window.Position = pos;
                    window.Resize(size);
                    node.AcceptEvent();
                }
            };
        }
    }

    public static IEnumerable<UiNode> All(UiNode n)
    {
        yield return n;
        foreach (var c in n.GetChildren()) if (c is UiNode u) foreach (var x in All(u)) yield return x;
    }
}

/// <summary>What a chat line is, for which chat windows show it (the game's chat filters, and plugins' text).</summary>
public enum ChatKind { Gameplay, Combat, Magic, AreaChat, Tells, Allegiance, Fellowship, General, Trade, LFG, Roleplay, Society, Errors, Plugin }

/// <summary>
/// The game's floating chat window (layout 0x2100006F): what's said and done, in the game's font and colours,
/// scrolled with the wheel; a line at the bottom to type in (Enter to start typing, Enter to send) and the Send
/// button. Typed lines starting with / are commands.
/// </summary>
public partial class ChatWindow : Control
{
    public const uint Layout = 0x2100006F;
    private const uint MoreBelow = 0x1000048C, MaxButton = 0x1000046F;
    private Vector2? _restore;   // its size before it was maximized
    private UiNode? _more;
    private const uint ScrollBarId = 0x10000012, ArrowUp = 0x10000071, ArrowDown = 0x10000072;
    private const uint TextArea = 0x10000011, Entry = 0x10000016, SendButton = 0x10000019, SayButton = 0x10000014, SayLabel = 0x10000015;
    private const string SavePath = "user://ui.cfg";

    public UiNode? Window { get; private set; }
    /// <summary>0: the main chat; 1-5: the extra windows its buttons (top left) open.</summary>
    public int Index;
    /// <summary>The kinds of line it shows.</summary>
    public HashSet<ChatKind> Filters = new();
    /// <summary>How solid its window is (0.1 - 1): the frame and background fade, the words stay as they are.</summary>
    /// <remarks>The game's own window art is partly see-through: 70% is it as drawn, above that a solid backing fills in
    /// behind it (100%: nothing shows through), below it the art itself fades.</remarks>
    public float Opacity = AsDrawn;
    public const float AsDrawn = 0.7f;
    private ColorRect? _backing;

    private void FitBacking() { if (_backing != null && Window != null) { _backing.Position = Window.Position; _backing.Size = Window.Size; } }

    /// <summary>Its frame and background drawn this solid (each part's own drawing - the chat's lines, drawn over them, aren't).</summary>
    public void ApplyOpacity()
    {
        if (Window == null) return;
        Opacity = Math.Clamp(Opacity, 0.1f, 1f);
        float art = Math.Min(1f, Opacity / AsDrawn), solid = Math.Clamp((Opacity - AsDrawn) / (1f - AsDrawn), 0f, 1f);
        if (_backing == null)
        {
            // (behind the window, not in it: in it, it would be drawn over the window's own art)
            _backing = new ColorRect { Name = "Backing", MouseFilter = MouseFilterEnum.Ignore };
            Window.GetParent().AddChild(_backing);
            Window.GetParent().MoveChild(_backing, Window.GetIndex());
            Window.ItemRectChanged += FitBacking;
        }
        FitBacking();
        _backing.Color = new Color(0.05f, 0.04f, 0.025f, solid);
        _backing.Visible = solid > 0.001f;
        void Each(Node n)
        {
            if (n is UiNode u) { var c = u.SelfModulate; c.A = art; u.SelfModulate = c; }
            else if (n is TitleBar t) { var c = t.SelfModulate; c.A = art; t.SelfModulate = c; }
            foreach (var ch in n.GetChildren()) Each(ch);
        }
        Each(this);
    }
    /// <summary>The main chat's buttons: a window (1-5) to open or shut.</summary>
    public Action<int>? ToggleWindow;
    private readonly UiNode?[] _windowButtons = new UiNode?[6];
    // its buttons for the extra windows, top to bottom (the fifth is ACGodot's: plugin text)
    private static readonly uint[] WindowButtonIds = { 0x10000522, 0x10000523, 0x10000524, 0x10000525 };

    /// <summary>What each window shows to begin with (as the game's defaults; 5 is plugins' text).</summary>
    public static HashSet<ChatKind> DefaultFilters(int index) => index switch
    {
        0 => new() { ChatKind.Gameplay, ChatKind.Combat, ChatKind.Magic, ChatKind.AreaChat, ChatKind.Tells, ChatKind.Allegiance, ChatKind.Fellowship,
                     ChatKind.General, ChatKind.Trade, ChatKind.LFG, ChatKind.Roleplay, ChatKind.Society, ChatKind.Plugin },
        1 => new() { ChatKind.Tells },
        2 => new() { ChatKind.Allegiance },
        3 => new() { ChatKind.Fellowship },
        4 => new() { ChatKind.General, ChatKind.Trade, ChatKind.LFG, ChatKind.Roleplay, ChatKind.Society },
        _ => new() { ChatKind.Plugin },
    };

    private string Section => Index == 0 ? "chat" : $"chat{Index}";
    /// <summary>Shown (an extra window: open).</summary>
    public bool Shown = true;
    private ChatLog? _log;
    private LineEdit? _input;
    /// <summary>Map coordinates clicked in the chat (north, east, as written).</summary>
    public Action<double, double, string>? CoordsClicked;
    /// <summary>A line typed and sent.</summary>
    public Action<string>? Submitted;
    private Vector2? _at, _size;
    private const int HistorySize = 20;
    private readonly List<string> _history = new();
    private int _back = -1;          // how far back through them (-1: what's being typed now)
    private string _draft = "";
    private string? _target;         // where lines go: null everyone near, "selected", or a channel's name
    /// <summary>The selected thing's name, for "Tell to Selected" (null: nothing selected).</summary>
    public Func<string?>? SelectedName;
    private Control? _menu;

    // the Chat menu, as the game has it: two columns; the ones there's nothing for yet are greyed
    private static readonly (string text, string? target, bool on, string label)[] MenuLeft =
    {
        ("Squelch (ignore)", null, false, "Chat"), ("Tell to Selected", "selected", true, "Tell"), ("Chat to All", null, true, "Chat"),
        ("Tell to Fellows", "Fellowship", true, "Fel"), ("Tell to General Chat", "General", true, "Gen"), ("Tell to LFG Chat", "LFG", true, "LFG"),
        ("Tell to Society Chat", "Society", true, "Soc"),
    };
    private static readonly (string text, string? target, bool on, string label)[] MenuRight =
    {
        ("Tell to Monarch", null, false, "Chat"), ("Tell to Patron", null, false, "Chat"), ("Tell to Vassals", null, false, "Chat"),
        ("Tell to Allegiance", "Allegiance", true, "Alg"), ("Tell to Trade Chat", "Trade", true, "Trd"), ("Tell to Roleplay Chat", "Roleplay", false, "RP"),
        ("Tell to Olthoi Chat", "Olthoi", false, "Olt"),
    };
    private UiNode? _chatLabel;

    private void ToggleMenu(Control button)
    {
        if (_menu != null) { _menu.QueueFree(); _menu = null; return; }
        var panel = new PanelContainer { MouseFilter = MouseFilterEnum.Stop };
        panel.AddThemeStyleboxOverride("panel", new StyleBoxFlat
        {
            BgColor = new Color(0.62f, 0.27f, 0.12f, 0.95f), BorderColor = new Color(0.3f, 0.12f, 0.05f),
            BorderWidthLeft = 1, BorderWidthRight = 1, BorderWidthTop = 1, BorderWidthBottom = 1,
            ContentMarginLeft = 4, ContentMarginRight = 4, ContentMarginTop = 2, ContentMarginBottom = 2,
        });
        var cols = new HBoxContainer();
        cols.AddThemeConstantOverride("separation", 10);
        panel.AddChild(cols);
        bool hasSel = SelectedName?.Invoke() is { Length: > 0 };
        foreach (var column in new[] { MenuLeft, MenuRight })
        {
            var box = new VBoxContainer();
            box.AddThemeConstantOverride("separation", 0);
            foreach (var (text, target, on, short_) in column)
            {
                bool enabled = on && (target != "selected" || hasSel);
                var b = new Button { Text = text, Flat = true, FocusMode = FocusModeEnum.None, Disabled = !enabled, Alignment = HorizontalAlignment.Left };
                b.AddThemeFontSizeOverride("font_size", RetailTheme.Px(11));
                b.AddThemeColorOverride("font_color", new Color(1f, 0.93f, 0.8f));
                b.AddThemeColorOverride("font_hover_color", new Color(1f, 1f, 0.6f));
                b.AddThemeColorOverride("font_disabled_color", new Color(0.85f, 0.6f, 0.5f));
                b.AddThemeConstantOverride("v_separation", 0);
                foreach (var st in new[] { "normal", "hover", "pressed", "disabled", "focus" }) b.AddThemeStyleboxOverride(st, new StyleBoxEmpty { ContentMarginTop = 0, ContentMarginBottom = 0 });
                var t = target; var lbl = short_;
                // where lines go from now on, shown on the button (Chat: everyone near)
                b.Pressed += () => { _target = t; if (_chatLabel != null) _chatLabel.Text = lbl; _menu?.QueueFree(); _menu = null; StartTyping(); };
                box.AddChild(b);
            }
            cols.AddChild(box);
        }
        AddChild(panel);
        _menu = panel;
        // above the button, its left edge on the window's
        panel.ResetSize();
        Vector2 sz = panel.GetCombinedMinimumSize();
        panel.Position = new Vector2(Window!.GlobalPosition.X, button.GlobalPosition.Y - sz.Y);
    }
    private bool _placed;

    public void Setup(RetailUi ui)
    {
        MouseFilter = MouseFilterEnum.Ignore;
        Window = ui.Build(Layout);
        if (Window == null) return;
        AddChild(Window);
        Load();
        Window.Resize(_size ?? (Index == 0 ? new Vector2(560, 210) : new Vector2(420, 150)));
        _textFont = Window.Find(TextArea)?.FontStyle;
        if (Index != 0) { Visible = Shown; AddTitle(); }
        // the buttons down its left for the extra windows: on the main chat (plus a fifth, under the four); not on those
        UiNode? lastButton = null;
        for (int i = 0; i < WindowButtonIds.Length; i++)
            if (Window.Find(WindowButtonIds[i]) is { } wb)
            {
                if (Index != 0) { wb.Visible = false; continue; }
                lastButton = wb;
                HookWindowButton(wb, i + 1);
            }
        if (Index == 0 && lastButton != null)
        {
            // (shifted on every resize too: put back where the layout has its original, it sat on button 4 and hid it)
            var fifth = new UiNode(ui, lastButton.R.E) { Position = lastButton.Position + new Vector2(0, 17), DesignShift = lastButton.DesignShift + new Vector2(0, 17) };
            lastButton.GetParent().AddChild(fifth);
            HookWindowButton(fifth, 5);
        }
        WindowFrame.Attach(Window, (p, s) => { _at = p; _size = s; Save(); });
        if (MathF.Abs(Opacity - AsDrawn) > 0.001f) CallDeferred(nameof(ApplyOpacity));   // (as it was left - once its parts are all in)
        if (Window.Find(TextArea) is { } area)
        {
            _log = new ChatLog { Font = area.FontStyle, MouseFilter = MouseFilterEnum.Stop, TextScale = TextScale };
            _log.CoordsClicked = (ns, ew, text) => CoordsClicked?.Invoke(ns, ew, text);
            // a name clicked: ready to /tell them (whatever channel they spoke in)
            _log.NameClicked = who =>
            {
                if (_input == null) return;
                _input.Text = $"/tell {who}, ";
                _input.GrabFocus();
                _back = -1;
                _input.CaretColumn = _input.Text.Length;
            };
            area.AddChild(_log);
            _log.Size = area.Size;
            area.Resized += () => _log.Size = area.Size;
            // the "more below" arrow: at the right, beside the scroll bar; shown while scrolled back, a click goes to the newest
            if (area.Find(MoreBelow) is { } more)
            {
                _more = more;
                more.Pinned = true;
                more.Visible = false;
                area.MoveChild(more, area.GetChildCount() - 1);
                more.OnInput = e => { if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true }) { _log.ToNewest(); more.AcceptEvent(); } };
            }
            // the window's own scroll bar (right of the text: an arrow at each end): the blue bar rides in it, the arrows scroll
            if (Window.Find(ScrollBarId) is { } sb)
            {
                foreach (var c in sb.GetChildren()) if (c is UiNode t && t.Id == 1) t.Visible = false;   // the layout's plain thumb: ours instead
                var bar = new ChatBar { Log = _log, Up = sb.Find(ArrowUp), Down = sb.Find(ArrowDown), Size = sb.Size };
                // (the layout's arrows come out pointing the wrong way up: each turned over about its middle)
                foreach (var arrow in new[] { bar.Up, bar.Down })
                    if (arrow != null) { arrow.PivotOffset = arrow.Size / 2; arrow.Scale = new Vector2(1, -1); }
                sb.AddChild(bar);
                sb.Resized += () => bar.Size = sb.Size;
            }
        }
        if (Window.Find(Entry) is { } entry)
        {
            _input = new LineEdit { Flat = true, ContextMenuEnabled = false, CaretBlink = true };
            _input.AddThemeFontSizeOverride("font_size", RetailTheme.Px(12));
            _input.AddThemeConstantOverride("minimum_character_width", 0);
            _input.AddThemeColorOverride("font_color", new Color(0.95f, 0.92f, 0.8f));
            _input.AddThemeStyleboxOverride("normal", new StyleBoxEmpty());
            _input.AddThemeStyleboxOverride("focus", new StyleBoxEmpty());
            entry.AddChild(_input);
            // the line's text in the middle of the entry box, not hanging below it
            void Fit()
            {
                float h = _input.GetCombinedMinimumSize().Y;
                _input.Size = new Vector2(entry.Size.X - 4, h);
                _input.Position = new Vector2(2, MathF.Round((entry.Size.Y - h) / 2f));
            }
            Fit();
            entry.Resized += Fit;
            _input.FocusEntered += () => entry.SetState(DatReaderWriter.Enums.UIStateId.Normal_focussed);
            _input.FocusExited += () => entry.SetState(DatReaderWriter.Enums.UIStateId.Normal);
            _input.TextSubmitted += Send;
            // Escape: stop typing; up and down: back and forth through the last lines typed
            _input.GuiInput += e =>
            {
                if (e is not InputEventKey { Pressed: true } k) return;
                if (k.Keycode == Key.Escape) { _input.ReleaseFocus(); _input.AcceptEvent(); }
                else if (k.Keycode is Key.Up or Key.Down && _history.Count > 0)
                {
                    if (_back < 0) _draft = _input.Text;
                    _back = k.Keycode == Key.Up ? Math.Min(_back + 1, _history.Count - 1) : _back - 1;
                    if (_back < 0) { _back = -1; _input.Text = _draft; }
                    else _input.Text = _history[_history.Count - 1 - _back];
                    _input.CaretColumn = _input.Text.Length;
                    _input.AcceptEvent();
                }
            };
        }
        // the maximize button (top right): taller, its bottom staying put; again for its own size back
        if (Window.Find(MaxButton) is { } maxB)
            maxB.OnInput = e =>
            {
                if (e is not InputEventMouseButton { ButtonIndex: MouseButton.Left } mb) return;
                maxB.AcceptEvent();
                if (mb.Pressed) return;
                var w = Window!;
                float bottom = w.Position.Y + w.Size.Y;
                if (_restore is { } back)
                {
                    w.Resize(back); _restore = null;
                    maxB.SetState(DatReaderWriter.Enums.UIStateId.Minimized);
                }
                else
                {
                    _restore = w.Size;
                    float tall = Math.Min(GetViewportRect().Size.Y * 0.7f, WindowFrame.MaxSize(w).Y);
                    w.Resize(new Vector2(w.Size.X, Math.Max(tall, w.Size.Y)));
                    maxB.SetState(DatReaderWriter.Enums.UIStateId.Maximized);
                }
                w.Position = new Vector2(w.Position.X, bottom - w.Size.Y);
                _size = _restore ?? w.Size; _at = new Vector2(w.Position.X, bottom - _size.Value.Y); Save();   // (remembered at its own size)
            };
        // the Chat button left of the line: a menu of where a typed line goes (everyone near, the selected, a channel)
        if (Window.Find(SayButton) is { } say)
        {
            var label = say.Find(SayLabel) ?? say;
            label.Text = "Chat"; label.CenterText();
            _chatLabel = label;
            say.OnInput = e =>
            {
                if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb)
                {
                    say.SetState(mb.Pressed ? DatReaderWriter.Enums.UIStateId.Normal_pressed : DatReaderWriter.Enums.UIStateId.Normal);
                    if (!mb.Pressed) ToggleMenu(say);
                    say.AcceptEvent();
                }
            };
        }
        if (Window.Find(SendButton) is { } send)
        {
            send.Text = "Send"; send.CenterText();
        }
        if (Window.Find(SendButton) is { } sendB)
            sendB.OnInput = e =>
            {
                if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb)
                {
                    sendB.SetState(mb.Pressed ? DatReaderWriter.Enums.UIStateId.Normal_pressed : DatReaderWriter.Enums.UIStateId.Normal);
                    if (!mb.Pressed && _input != null) Send(_input.Text);
                    sendB.AcceptEvent();
                }
            };
    }

    /// <summary>The extra windows' names, as the game's ("Chat Window 2: Allegiance").</summary>
    private static readonly string[] WindowNames = { "Main", "Speech", "Allegiance", "Fellowship", "Channels", "Plugins" };
    public const float TitleHeight = 14f;
    private RetailFont? _textFont;
    /// <summary>Shut with its title bar's X.</summary>
    public Action? Closed;

    // a title bar over an extra window: its name, an X to shut it; it drags the window (with the interface unlocked)
    private void AddTitle()
    {
        var bar = new TitleBar { Text = $"Chat Window {Index}: {WindowNames[Math.Min(Index, WindowNames.Length - 1)]}", Font = _textFont,
                                 Position = new Vector2(0, -TitleHeight), MouseFilter = MouseFilterEnum.Stop };
        Window!.AddChild(bar);
        bar.Size = new Vector2(Window.Size.X, TitleHeight);
        Window.Resized += () => bar.Size = new Vector2(Window.Size.X, TitleHeight);
        bool down = false; Vector2 grab = Vector2.Zero, from = Vector2.Zero;
        bar.GuiInput += e =>
        {
            if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb)
            {
                if (mb.Pressed && mb.Position.X > bar.Size.X - TitleHeight) { SetShown(false); Closed?.Invoke(); bar.AcceptEvent(); return; }
                down = mb.Pressed && !UiLock.Locked; grab = bar.GetGlobalMousePosition(); from = Window.Position;
                if (!mb.Pressed) { _at = Window.Position; Save(); }
                bar.AcceptEvent();
            }
            else if (e is InputEventMouseMotion && down) { Window.Position = from + bar.GetGlobalMousePosition() - grab; bar.AcceptEvent(); }
        };
    }

    private sealed partial class TitleBar : Control
    {
        public string Text = "";
        public RetailFont? Font;
        public override void _Draw() { long __fw = ACGodot.FrameWatch.DrawStart(); try { DrawBody(); } finally { ACGodot.FrameWatch.Drew("TitleBar", __fw); } }
        private void DrawBody()
        {
            DrawRect(new Rect2(Vector2.Zero, Size), new Color(0.08f, 0.06f, 0.03f, 0.95f));
            DrawRect(new Rect2(Vector2.Zero, Size), new Color(0.62f, 0.47f, 0.22f), false, 1f);
            if (Font != null)
            {
                Vector2 sz = Font.Measure(Text);
                Font.Draw(this, Text, new Vector2(MathF.Round((Size.X - sz.X) / 2f), MathF.Round((Size.Y - sz.Y) / 2f)), new Color(1f, 0.95f, 0.8f));
                Vector2 xs = Font.Measure("X");
                Font.Draw(this, "X", new Vector2(Size.X - TitleHeight + MathF.Round((TitleHeight - xs.X) / 2f), MathF.Round((Size.Y - xs.Y) / 2f)), new Color(1f, 0.8f, 0.5f));
            }
        }
        public override void _Notification(int what) { if (what == NotificationResized) QueueRedraw(); }
    }

    private void HookWindowButton(UiNode b, int n)
    {
        _windowButtons[n] = b;
        b.SetTextStyle(_textFont, new Color(1f, 0.95f, 0.75f));
        b.Text = n.ToString(); b.CenterText();
        b.TooltipText = n == 5 ? "Chat Window 5 (plugins)" : $"Chat Window {n}";
        b.OnInput = e =>
        {
            if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: false }) { ToggleWindow?.Invoke(n); b.AcceptEvent(); }
            else if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left }) b.AcceptEvent();
        };
    }

    /// <summary>Lights a window's button while that window is open.</summary>
    public void SetWindowLit(int n, bool lit) =>
        _windowButtons[n]?.SetState(lit ? DatReaderWriter.Enums.UIStateId.Highlight : DatReaderWriter.Enums.UIStateId.Normal);

    /// <summary>Opens or shuts an extra window (remembered).</summary>
    public void SetShown(bool shown) { Shown = shown; Visible = shown; Save(); }

    private void Send(string text)
    {
        if (_input == null) return;
        _input.Text = "";
        _input.ReleaseFocus();
        text = text.Trim();
        _back = -1;
        if (text.Length == 0) return;
        // the last 20 lines typed, newest last (the same line twice running kept once)
        if (_history.Count == 0 || _history[^1] != text) _history.Add(text);
        if (_history.Count > HistorySize) _history.RemoveAt(0);
        if (!text.StartsWith('/'))
        {
            if (_target == "selected") text = SelectedName?.Invoke() is { Length: > 0 } who ? $"/tell {who}, {text}" : text;
            else if (_target != null) text = $"/channel {_target} {text}";
        }
        Submitted?.Invoke(text);
    }

    public bool Typing => _input?.HasFocus() == true;

    /// <summary>Starts typing (Enter), optionally with something already there (/).</summary>
    public void StartTyping(string with = "")
    {
        if (_input == null) return;
        _input.GrabFocus();
        _back = -1;
        // carrying on where they left off (a click away stops typing but keeps the line); / starts a fresh command
        if (with.Length > 0 && _input.Text.Length == 0) _input.Text = with;
        _input.CaretColumn = _input.Text.Length;
    }

    /// <summary>A line, if it's a kind this window shows.</summary>
    public void Add(string text, Color color, ChatKind kind = ChatKind.Gameplay)
    {
        color = ChatColors.For(text, color, kind);   // (your colour for its kind, if you've set one)
        if (Filters.Contains(kind)) _log?.Add(text, color);
    }

    /// <summary>How big this window's text is, times the game's text size (Options > Chat).</summary>
    public float TextScale = 1f;
    public void ApplyTextScale() { if (_log != null) { _log.TextScale = TextScale; _log.QueueRedraw(); } }

    // a click anywhere else while typing stops typing (what's typed stays for Enter to carry on with)
    public override void _Input(InputEvent e)
    {
        if (e is not InputEventMouseButton { Pressed: true } mb || _input == null || !_input.HasFocus()) return;
        if (_input.GetGlobalRect().HasPoint(mb.GlobalPosition)) return;
        if (_menu != null && _menu.GetGlobalRect().HasPoint(mb.GlobalPosition)) return;
        _input.ReleaseFocus();
    }

    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("TitleBar");
        if (Window == null) return;
        if (_more != null && _log != null && _more.GetParent() is Control area)
        {
            _more.Position = new Vector2(area.Size.X - _more.Size.X - 1, area.Size.Y - _more.Size.Y - 1);
            _more.Visible = _log.ScrolledBack;
        }
        Vector2 screen = GetViewportRect().Size;
        Position = Vector2.Zero; Size = screen;
        // its place: where it was left (or the bottom left, at first); kept on the screen
        if (!_placed)
        {
            Window.Position = _at ?? (Index == 0 ? new Vector2(8, screen.Y - Window.Size.Y - 8)
                                                 : new Vector2(8 + 24 * Index, screen.Y - 230 - Window.Size.Y - 24 * Index));
            _placed = true;
        }
        var p = Window.Position;
        float top = Index != 0 ? TitleHeight : 0f;
        Window.Position = new Vector2(Math.Clamp(p.X, 0, Math.Max(0, screen.X - Window.Size.X)), Math.Clamp(p.Y, top, Math.Max(top, screen.Y - Window.Size.Y)));
    }

    private void Load()
    {
        Filters = DefaultFilters(Index);
        Shown = Index == 0;
        var cfg = new ConfigFile();
        if (global::ACGodot.SafeConfig.Load(cfg, SavePath) != Error.Ok) return;
        if (cfg.HasSectionKey(Section, "at")) _at = (Vector2)cfg.GetValue(Section, "at");
        if (cfg.HasSectionKey(Section, "size")) _size = (Vector2)cfg.GetValue(Section, "size");
        if (Index != 0 && cfg.HasSectionKey(Section, "shown")) Shown = (bool)cfg.GetValue(Section, "shown");
        if (cfg.HasSectionKey(Section, "opacity")) Opacity = (float)(double)cfg.GetValue(Section, "opacity");
        if (cfg.HasSectionKey(Section, "text_scale")) TextScale = Math.Clamp((float)(double)cfg.GetValue(Section, "text_scale"), 0.5f, 3f);
        if (cfg.HasSectionKey(Section, "filters"))
        {
            Filters = new();
            foreach (var name in ((string)cfg.GetValue(Section, "filters")).Split(',', StringSplitOptions.RemoveEmptyEntries))
                if (Enum.TryParse<ChatKind>(name, out var k)) Filters.Add(k);
        }
    }

    /// <summary>Its settings into a shared file (Options > Chat > Export): place, size, open, filters, opacity, text size.</summary>
    public void ExportTo(ConfigFile cfg)
    {
        string sec = "win" + Index;
        if (Window != null) { cfg.SetValue(sec, "at", Window.Position); cfg.SetValue(sec, "size", Window.Size); }
        cfg.SetValue(sec, "shown", Shown);
        cfg.SetValue(sec, "filters", string.Join(",", Filters));
        cfg.SetValue(sec, "opacity", (double)Opacity);
        cfg.SetValue(sec, "text_scale", (double)TextScale);
    }

    /// <summary>Its settings from the shared file, put to use now and kept.</summary>
    public void ImportFrom(ConfigFile cfg)
    {
        string sec = "win" + Index;
        if (!cfg.HasSection(sec)) return;
        if (cfg.HasSectionKey(sec, "filters"))
        {
            Filters = new();
            foreach (var name in ((string)cfg.GetValue(sec, "filters")).Split(',', StringSplitOptions.RemoveEmptyEntries))
                if (Enum.TryParse<ChatKind>(name, out var k)) Filters.Add(k);
        }
        if (cfg.HasSectionKey(sec, "opacity")) { Opacity = (float)(double)cfg.GetValue(sec, "opacity"); ApplyOpacity(); }
        if (cfg.HasSectionKey(sec, "text_scale")) { TextScale = Math.Clamp((float)(double)cfg.GetValue(sec, "text_scale"), 0.5f, 3f); ApplyTextScale(); }
        if (cfg.HasSectionKey(sec, "size")) { _size = (Vector2)cfg.GetValue(sec, "size"); if (Window != null) Window.Size = _size.Value; }
        if (cfg.HasSectionKey(sec, "at")) { _at = (Vector2)cfg.GetValue(sec, "at"); if (Window != null) Window.Position = _at.Value; }
        if (Index != 0 && cfg.HasSectionKey(sec, "shown")) { Shown = (bool)cfg.GetValue(sec, "shown"); Visible = Shown; }
        Save();
    }

    /// <summary>Saves its place, size, whether it's open and its filters.</summary>
    public void SaveSettings() => Save();

    private void Save()
    {
        var cfg = new ConfigFile();
        global::ACGodot.SafeConfig.Load(cfg, SavePath);
        if (_at is { } a) cfg.SetValue(Section, "at", a);
        if (_size is { } s) cfg.SetValue(Section, "size", s);
        if (Index != 0) cfg.SetValue(Section, "shown", Shown);
        cfg.SetValue(Section, "filters", string.Join(",", Filters));
        cfg.SetValue(Section, "opacity", (double)Opacity);
        cfg.SetValue(Section, "text_scale", (double)TextScale);
        global::ACGodot.SafeConfig.Save(cfg, SavePath);
    }

    /// <summary>The chat's lines, wrapped to its width in the game's font, newest at the bottom; the wheel scrolls back.</summary>
    /// <summary>
    /// The chat's lines, wrapped to its width in the game's font, newest at the bottom; the wheel scrolls back. Map
    /// coordinates in a line (42.1N, 33.6E) are links: clicking one points the arrow there.
    /// </summary>
    private sealed partial class ChatBar : Control
    {
        public ChatLog Log = null!;
        public UiNode? Up, Down;
        private const float Arrow = 16f;
        private static readonly Color Thumb = new(0.2f, 0.38f, 0.85f), Edge = new(0.55f, 0.7f, 1f);
        private bool _drag;
        private float _grab;
        private int _held;        // an arrow held down: 1 up (back), -1 down (to newer)
        private double _repeat;
        private (int, int, int) _shown;

        public ChatBar() { MouseFilter = MouseFilterEnum.Stop; }

        // the room between the arrows, and the bar in it
        private float Top => Arrow;
        private float Room => Math.Max(0f, Size.Y - Arrow * 2);
        private Rect2 ThumbRect()
        {
            float h = Room;
            float th = Log.Total <= Log.Fit ? h : Math.Clamp(h * Log.Fit / Math.Max(1, Log.Total), Math.Min(16f, h), h);
            float top = Log.MaxScroll == 0 ? h - th : (h - th) * (1f - (float)Log.Scroll / Log.MaxScroll);
            return new Rect2(3, Top + top, Size.X - 6, th);
        }
        private void FromThumb(float thumbTop)
        {
            float room = Room - ThumbRect().Size.Y;
            if (room <= 0 || Log.MaxScroll == 0) { Log.Scroll = 0; return; }
            Log.Scroll = (int)MathF.Round((1f - Math.Clamp((thumbTop - Top) / room, 0f, 1f)) * Log.MaxScroll);
        }

        public override void _Draw() { long __fw = ACGodot.FrameWatch.DrawStart(); try { DrawBody(); } finally { ACGodot.FrameWatch.Drew("ChatBar", __fw); } }
        private void DrawBody()
        {
            if (Log.Total <= Log.Fit || Room < 8) return;
            var tr = ThumbRect();
            DrawRect(tr, Thumb);
            DrawRect(tr.Grow(-0.5f), Edge, false, 1f);
        }

        private void Hold(int dir)
        {
            _held = dir; _repeat = 0.35;
            try { Up?.SetState(dir > 0 ? DatReaderWriter.Enums.UIStateId.Normal_pressed : DatReaderWriter.Enums.UIStateId.Normal); Down?.SetState(dir < 0 ? DatReaderWriter.Enums.UIStateId.Normal_pressed : DatReaderWriter.Enums.UIStateId.Normal); } catch { }
            if (dir != 0) Log.Scroll += dir;
        }

        public override void _Process(double delta)
        {
            ACGodot.FrameWatch.Enter("ChatBar");
            if (_held != 0)
            {
                if (!Input.IsMouseButtonPressed(MouseButton.Left)) Hold(0);
                else if ((_repeat -= delta) <= 0) { _repeat = 0.05; Log.Scroll += _held; }
            }
            var now = (Log.Total, Log.Fit, Log.Scroll);
            if (now != _shown) { _shown = now; QueueRedraw(); }
        }

        public override void _GuiInput(InputEvent e)
        {
            if (e is InputEventMouseButton { Pressed: true } w && (w.ButtonIndex == MouseButton.WheelUp || w.ButtonIndex == MouseButton.WheelDown))
            { Log.Scroll += w.ButtonIndex == MouseButton.WheelUp ? 3 : -3; AcceptEvent(); }
            else if (e is InputEventMouseButton { Pressed: true, ButtonIndex: MouseButton.Left } mb)
            {
                var tr = ThumbRect();
                if (mb.Position.Y < Arrow) Hold(1);
                else if (mb.Position.Y >= Size.Y - Arrow) Hold(-1);
                else if (Log.Total > Log.Fit && mb.Position.Y >= tr.Position.Y && mb.Position.Y < tr.End.Y) { _drag = true; _grab = mb.Position.Y - tr.Position.Y; }
                else Log.Scroll += (mb.Position.Y < tr.Position.Y ? 1 : -1) * Math.Max(1, Log.Fit - 1);
                AcceptEvent();
            }
            else if (e is InputEventMouseButton { Pressed: false, ButtonIndex: MouseButton.Left }) { _drag = false; if (_held != 0) Hold(0); AcceptEvent(); }
            else if (e is InputEventMouseMotion mm && _drag) { FromThumb(mm.Position.Y - _grab); AcceptEvent(); }
        }
    }

    private sealed partial class ChatLog : Control
    {
        public RetailFont? Font;
        public float TextScale = 1f;   // (this window's text size, times the game's)
        private float K => RetailFont.Scale * TextScale;
        public Action<double, double, string>? CoordsClicked;
        private readonly List<(string text, Color color)> _lines = new();
        private int _scroll;   // lines scrolled back from the newest
        private const int Keep = 300;   // (each chat window its own: the main one and every floating one)
        private const char Glue = '\u0001';   // holds a coordinate's words together when wrapping
        private static readonly System.Text.RegularExpressions.Regex Coords =
            new(@"(\d{1,3}(?:\.\d+)?)\s*([NnSs])[,\s]+(\d{1,3}(?:\.\d+)?)\s*([EeWw])\b");
        private static readonly Color LinkColor = new(0.45f, 0.85f, 1f);
        private readonly List<(Rect2 at, double ns, double ew, string text)> _links = new();
        // who said it (a tell, a channel, someone near): click the name to /tell them
        private readonly List<(Rect2 at, string name)> _names = new();
        public Action<string>? NameClicked;
        private static readonly System.Text.RegularExpressions.Regex Speaker = new(
            @"^(?:\[[^\]]{1,30}\]\s+)?(?:You tell (?<n>\+?[A-Za-z][A-Za-z'\- ]{0,30}?), |(?<n>\+?[A-Za-z][A-Za-z'\- ]{0,30}?) (?:says|tells you|yells|shouts|whispers|says to you)(?: to you)?, )");
        // highlighting with the mouse: from (wrapped line, character) to (line, character); copied when let go (and Ctrl+C)
        private (int line, int ch)? _selA, _selB;
        private bool _selecting;
        private readonly List<(int line, float y)> _drawn = new();
        private List<(string text, Color color, int msg)> _wrap = new();
        private static readonly Color SelColor = new(0.35f, 0.5f, 0.9f, 0.45f);
        // how much there is and how much fits, for the scroll bar beside it (the window's own: ChatBar)
        private int _total, _fit;
        public int MaxScroll => Math.Max(0, _total - _fit);
        public int Total => _total;
        public int Fit => _fit;
        /// <summary>Lines scrolled back from the newest.</summary>
        public int Scroll { get => _scroll; set { int v = Math.Clamp(value, 0, MaxScroll); if (v != _scroll) { _scroll = v; QueueRedraw(); } } }
        public ChatLog() { ClipContents = true; FocusMode = FocusModeEnum.Click; }
        public bool ScrolledBack => _scroll > 0;
        public void ToNewest() { _scroll = 0; QueueRedraw(); }

        public void Add(string text, Color color)
        {
            // a coordinate's spaces glued, so wrapping never splits it
            text = Coords.Replace(text, m => m.Value.Replace(' ', Glue));
            _lines.Add((text, color));
            _wrapped.Add(null);
            if (_lines.Count > Keep) { _lines.RemoveRange(0, _lines.Count - Keep); _wrapped.RemoveRange(0, _wrapped.Count - Keep); }
            if (_scroll > 0) _scroll++;   // reading back: stay on what you're reading
            QueueRedraw();
        }

        // inline colours a plugin can put in a line: \u0011 better (green), \u0012 worse (red), \u0010 back to the line's colour
        public const char Better = '\u0011', Worse = '\u0012', Plain = '\u0010';
        private static readonly Color BetterColor = new(0.45f, 0.95f, 0.45f), WorseColor = new(1f, 0.45f, 0.4f);
        private static bool IsMark(char ch) => ch == Better || ch == Worse || ch == Plain;
        public static string NoMarks(string s) => s.IndexOfAny(new[] { Better, Worse, Plain }) < 0 ? s : new string(System.Linq.Enumerable.ToArray(System.Linq.Enumerable.Where(s, ch => !IsMark(ch))));
        private float Width(string s) => Font?.Measure(NoMarks(s.Replace(Glue, ' ')), K).X ?? s.Length * 7 * TextScale;

        // each message's wrapped lines, worked out once (and again only when the window's width or text size changes):
        // wrapping all the kept messages on every redraw - measuring each line again word by word - took 60-70 ms a
        // frame once the chat had filled, and the chat redraws with every new line
        private readonly List<List<string>?> _wrapped = new();
        private float _wrapW = -1, _wrapK = -1;
        private List<(string, Color, int)> Wrapped()
        {
            float width = Size.X - 6;
            if (width != _wrapW || K != _wrapK || Font == null)
            {
                _wrapW = width; _wrapK = K;
                for (int i = 0; i < _wrapped.Count; i++) _wrapped[i] = null;
            }
            var outL = new List<(string, Color, int)>(_lines.Count + 32);
            for (int n = 0; n < _lines.Count; n++)
            {
                var (text, col) = _lines[n];
                if (Font == null) { outL.Add((text, col, n)); continue; }
                var pieces = _wrapped[n] ??= WrapOne(text, width);
                foreach (var piece in pieces) outL.Add((piece, col, n));
            }
            return outL;
        }

        private List<string> WrapOne(string text, float width)
        {
            var pieces = new List<string>(2);
            if (Width(text) <= width) { pieces.Add(text); return pieces; }
            string line = "";
            float lineW = 0f, space = Width(" ");
            foreach (var word in text.Split(' '))
            {
                float ww = Width(word);
                float tryW = line.Length == 0 ? ww : lineW + space + ww;
                if (tryW > width && line.Length > 0)
                {
                    pieces.Add(line);
                    // (a coloured part going on past the wrap: the next line starts in that colour)
                    int lm = line.LastIndexOfAny(new[] { Better, Worse, Plain });
                    line = lm >= 0 && line[lm] != Plain ? line[lm] + word : word;
                    lineW = Width(line);
                }
                else { line = line.Length == 0 ? word : line + " " + word; lineW = tryW; }
            }
            pieces.Add(line);
            return pieces;
        }

        private float Measure(string s) { s = NoMarks(s); return s.Length == 0 ? 0f : Font != null ? Font.Measure(s, K).X : ThemeDB.FallbackFont.GetStringSize(s, HorizontalAlignment.Left, -1, (int)(RetailTheme.Px(12) * TextScale)).X; }

        /// <summary>The (wrapped line, character) under a point of the log.</summary>
        private (int line, int ch)? HitText(Vector2 p)
        {
            if (_drawn.Count == 0) return null;
            int lh = LineH;
            var best = _drawn[0];
            foreach (var d in _drawn) if (p.Y >= d.y && p.Y < d.y + lh) { best = d; goto found; }
            best = p.Y < _drawn[^1].y ? _drawn[^1] : _drawn[0];   // above the top / below the bottom
            found:
            string t = _wrap[best.line].text.Replace(Glue, ' ');
            float x = 2; int ch = 0;
            while (ch < t.Length) { float w = Measure(t[ch].ToString()); if (p.X < x + w / 2) break; x += w; ch++; }
            return (best.line, ch);
        }

        private ((int line, int ch) a, (int line, int ch) b)? Sel()
        {
            if (_selA is not { } a || _selB is not { } b || a == b) return null;
            return (a.line < b.line || a.line == b.line && a.ch <= b.ch) ? (a, b) : (b, a);
        }

        private string SelectedText()
        {
            if (Sel() is not { } s) return "";
            var sb = new System.Text.StringBuilder();
            for (int i = s.a.line; i <= s.b.line && i < _wrap.Count; i++)
            {
                string t = _wrap[i].text.Replace(Glue, ' ');
                int from = i == s.a.line ? Math.Min(s.a.ch, t.Length) : 0, to = i == s.b.line ? Math.Min(s.b.ch, t.Length) : t.Length;
                if (i > s.a.line) sb.Append(_wrap[i].msg == _wrap[i - 1].msg ? " " : "\n");
                if (to > from) sb.Append(t, from, to - from);
            }
            return NoMarks(sb.ToString());
        }

        private int LineH => Font != null ? Math.Max(Font.LineHeightAt(K), (int)(12 * K)) : (int)(14 * K);

        public override void _Draw() { long __fw = ACGodot.FrameWatch.DrawStart(); try { DrawBody(); } finally { ACGodot.FrameWatch.Drew("ChatLog", __fw); } }
        private void DrawBody()
        {
            _links.Clear();
            _names.Clear();
            _drawn.Clear();
            int lh = LineH;
            var lines = Wrapped();
            _wrap = lines;
            var sel = Sel();
            int fit = Math.Max(1, (int)(Size.Y / lh));
            _scroll = Math.Clamp(_scroll, 0, Math.Max(0, lines.Count - fit));
            _total = lines.Count; _fit = fit;
            int end = lines.Count - _scroll;
            float y = Size.Y - lh;
            for (int i = end - 1; i >= 0 && y > -lh; i--, y -= lh)
            {
                var (raw, c, _) = lines[i];
                string t = raw.Replace(Glue, ' ');
                _drawn.Add((i, y));
                if (sel is { } s && i >= s.a.line && i <= s.b.line)
                {
                    int from = i == s.a.line ? Math.Min(s.a.ch, t.Length) : 0, to = i == s.b.line ? Math.Min(s.b.ch, t.Length) : t.Length;
                    float x0 = 2 + Measure(t[..from]), x1 = 2 + Measure(t[..to]);
                    if (i != s.b.line) x1 += 4;
                    if (x1 > x0) DrawRect(new Rect2(x0, y, x1 - x0, lh), SelColor);
                }
                if (Font == null) { DrawString(ThemeDB.FallbackFont, new Vector2(2, y + lh - 3), NoMarks(t), HorizontalAlignment.Left, -1, (int)(RetailTheme.Px(12) * TextScale), c); continue; }
                // the line in pieces: plain text in its colour (a plugin's better / worse parts green / red), coordinates as links
                float x = 2;
                int at = 0;
                Color cur = c;
                void Runs(string piece)
                {
                    int from = 0;
                    for (int k = 0; k <= piece.Length; k++)
                    {
                        if (k < piece.Length && !IsMark(piece[k])) continue;
                        if (k > from) { string run = piece[from..k]; Font.Draw(this, run, new Vector2(x, y), cur, K); x += Font.Measure(run, K).X; }
                        if (k < piece.Length) cur = piece[k] == Better ? BetterColor : piece[k] == Worse ? WorseColor : c;
                        from = k + 1;
                    }
                }
                // (the first line of a message: who said it)
                if (i == 0 || lines[i - 1].Item3 != lines[i].Item3)
                {
                    var sm = Speaker.Match(NoMarks(t));
                    if (sm.Success && sm.Groups["n"].Value.TrimStart('+') is { Length: > 1 } who && who != "You")
                    {
                        string plain = NoMarks(t);
                        var g = sm.Groups["n"];
                        float nx = 2 + Measure(plain[..g.Index]), nw = Measure(g.Value);
                        _names.Add((new Rect2(nx, y, nw, lh), who));
                    }
                }
                foreach (System.Text.RegularExpressions.Match m in Coords.Matches(t))
                {
                    if (m.Index > at) Runs(t[at..m.Index]);
                    float w = Font.Measure(m.Value, K).X;
                    Font.Draw(this, m.Value, new Vector2(x, y), LinkColor, K);
                    DrawLine(new Vector2(x, y + Font.LineHeightAt(K) - 1), new Vector2(x + w, y + Font.LineHeightAt(K) - 1), LinkColor, 1f);
                    double ns = double.Parse(m.Groups[1].Value, System.Globalization.CultureInfo.InvariantCulture) * (char.ToUpperInvariant(m.Groups[2].Value[0]) == 'S' ? -1 : 1);
                    double ew = double.Parse(m.Groups[3].Value, System.Globalization.CultureInfo.InvariantCulture) * (char.ToUpperInvariant(m.Groups[4].Value[0]) == 'W' ? -1 : 1);
                    _links.Add((new Rect2(x, y, w, lh), ns, ew, m.Value));
                    x += w;
                    at = m.Index + m.Length;
                }
                if (at < t.Length) Runs(t[at..]);
            }
        }

        public override void _GuiInput(InputEvent e)
        {
            if (e is InputEventMouseButton { Pressed: true } mb && (mb.ButtonIndex == MouseButton.WheelUp || mb.ButtonIndex == MouseButton.WheelDown))
            {
                _scroll += mb.ButtonIndex == MouseButton.WheelUp ? 3 : -3;
                if (_scroll < 0) _scroll = 0;
                QueueRedraw();
                AcceptEvent();
            }
            else if (e is InputEventMouseButton { Pressed: true, ButtonIndex: MouseButton.Left } click)
            {
                foreach (var (rect, ns, ew, text) in _links)
                    if (rect.HasPoint(click.Position)) { CoordsClicked?.Invoke(ns, ew, text); AcceptEvent(); return; }
                foreach (var (rect, who) in _names)
                    if (rect.HasPoint(click.Position)) { NameClicked?.Invoke(who); AcceptEvent(); return; }
                // highlighting starts here
                _selA = _selB = HitText(click.Position);
                _selecting = true;
                GrabFocus();
                QueueRedraw();
                AcceptEvent();
            }
            else if (e is InputEventMouseButton { Pressed: false, ButtonIndex: MouseButton.Left } && _selecting)
            {
                _selecting = false;
                string t = SelectedText();
                if (t.Length > 0) DisplayServer.ClipboardSet(t);   // let go: copied
                AcceptEvent();
            }
            else if (e is InputEventMouseMotion drag && _selecting)
            {
                _selB = HitText(drag.Position);
                QueueRedraw();
                AcceptEvent();
            }
            else if (e is InputEventKey { Pressed: true, Keycode: Key.C, CtrlPressed: true } && Sel() != null)
            {
                DisplayServer.ClipboardSet(SelectedText());
                AcceptEvent();
            }
            else if (e is InputEventMouseMotion mm)
            {
                bool over = false;
                foreach (var l in _links) if (l.at.HasPoint(mm.Position)) { over = true; break; }
                foreach (var l in _names) if (l.at.HasPoint(mm.Position)) { over = true; break; }
                MouseDefaultCursorShape = over ? CursorShape.PointingHand : CursorShape.Arrow;
            }
        }
    }
}
