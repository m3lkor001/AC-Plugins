using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading;
using Godot;

namespace ACGodot.Plugins;

/// <summary>
/// The phone service, as a plugin: answers the MelkTank Remote app (the same calls and app key as the PC's phone
/// service) for this ACGodot character - its status (in the game since, last attack, kills and experience per hour,
/// MelkTank's switches, the nav route, where it is), commands (switches, a route, chat), and a picture of the game.
/// Listens on port 8766 (the launcher passes its app key and port); the PC's phone service shows ACGodot characters
/// alongside the others by asking it.
/// </summary>
public sealed class PhonePlugin : IPlugin
{
    public string Name => "Phone";
    private PluginHost _h = null!;
    private HttpListener? _http;
    private Thread? _thread;
    private string _key = "";
    private int _port = 8766;
    private readonly ConcurrentQueue<(HttpListenerContext ctx, ManualResetEventSlim done)> _work = new();
    private readonly DateTime _started = DateTime.UtcNow;
    private DateTime _lastAttack = DateTime.MinValue;
    private int _kills;
    private long _xp;
    private int _deaths;
    private readonly List<(string text, string kind, DateTime at)> _chat = new();
    private const string SavePath = "user://phone.cfg";

    public void Start(PluginHost host)
    {
        _h = host;
        // the app key and port: from the launcher when it started the game, else this game's own (made once)
        var cfg = new ConfigFile();
        global::ACGodot.SafeConfig.Load(cfg, SavePath);
        _key = System.Environment.GetEnvironmentVariable("ACGODOT_PHONE_KEY") ?? "";
        if (_key.Length == 0)
        {
            _key = (string)cfg.GetValue("phone", "key", "");
            if (_key.Length == 0) { _key = Convert.ToBase64String(System.Security.Cryptography.RandomNumberGenerator.GetBytes(18)).Replace('+', '-').Replace('/', '_'); cfg.SetValue("phone", "key", _key); global::ACGodot.SafeConfig.Save(cfg, SavePath); }
        }
        if (int.TryParse(System.Environment.GetEnvironmentVariable("ACGODOT_PHONE_PORT"), out int envPort)) _port = envPort;
        else _port = (int)cfg.GetValue("phone", "port", 8766);
        host.Killed += (_, _, xp, _) => { _kills++; _xp += xp; _lastAttack = DateTime.UtcNow; };
        host.ChatLine += (text, kind) =>
        {
            lock (_chat) { _chat.Add((text, kind.ToString(), DateTime.UtcNow)); if (_chat.Count > 300) _chat.RemoveAt(0); }
            if (text.StartsWith("You have returned to life")) _deaths++;
        };
        host.Tick += _ => Serve();
        host.Command("phone", r =>
        {
            if (r.Trim() == "key") { host.Print(Name, $"app key: {_key}"); return; }
            host.Print(Name, _http != null ? $"answering the phone app on port {_port}" : "not running");
        }, "the phone service: /phone | /phone key");
        Listen();
    }

    public void Stop()
    {
        try { _http?.Stop(); _http?.Close(); } catch { }
        _http = null;
    }

    private void Listen()
    {
        try
        {
            _http = new HttpListener();
            _http.Prefixes.Add($"http://*:{_port}/");
            try { _http.Start(); }
            catch (HttpListenerException) when (OperatingSystem.IsWindows())
            {
                // Windows lets a program listen on every address only with an admin's say-so (netsh http add urlacl);
                // this PC's own address it may - and the phone service, on this PC, is all that asks
                try { _http.Close(); } catch { }
                _http = new HttpListener();
                _http.Prefixes.Add($"http://localhost:{_port}/");
                _http.Start();
            }
            _thread = new Thread(() =>
            {
                while (_http != null && _http.IsListening)
                {
                    HttpListenerContext ctx;
                    try { ctx = _http.GetContext(); } catch { break; }
                    // answered on the game's thread (that's where the game's state is), waited for here
                    var done = new ManualResetEventSlim();
                    _work.Enqueue((ctx, done));
                    if (!done.Wait(8000)) { try { Reply(ctx, 503, new JsonObject { ["error"] = "the game is busy" }); } catch { } }
                }
            }) { IsBackground = true, Name = "Phone service" };
            _thread.Start();
            _h.Print(Name, $"phone service on port {_port}");
        }
        catch (Exception ex) { _h.Print(Name, $"couldn't start the phone service on port {_port}: {ex.Message}", new Color(1f, 0.5f, 0.4f)); _http = null; }
    }

    private void Serve()
    {
        while (_work.TryDequeue(out var w))
        {
            try { Handle(w.ctx); }
            catch (Exception ex) { try { Reply(w.ctx, 500, new JsonObject { ["error"] = ex.Message }); } catch { } }
            finally { w.done.Set(); }
        }
    }

    private void Handle(HttpListenerContext ctx)
    {
        string path = ctx.Request.Url?.AbsolutePath ?? "";
        if (path == "/api/ping") { Reply(ctx, 200, new JsonObject { ["ok"] = true }); return; }
        string given = ctx.Request.Headers["X-Token"] ?? "";
        if (_key.Length == 0 || !CryptographicOperations.FixedTimeEquals(Encoding.UTF8.GetBytes(given), Encoding.UTF8.GetBytes(_key)))
        { Reply(ctx, 401, new JsonObject { ["error"] = "wrong app key" }); return; }
        var mt = _h.Plugins.OfType<IBotSwitches>().FirstOrDefault();
        switch ((ctx.Request.HttpMethod, path))
        {
            case ("GET", "/api/status"):
                Reply(ctx, 200, new JsonObject
                {
                    ["time"] = DateTime.UtcNow.ToString("o"), ["interval"] = 15,
                    ["servers"] = new JsonArray(new JsonObject { ["name"] = _h.ServerName.Length > 0 ? _h.ServerName : "ACGodot (offline)", ["up"] = true }),
                    ["clients"] = 1,
                    ["accounts"] = new JsonArray(Entry(mt)),
                    ["decal"] = new JsonObject { ["running"] = true, ["note"] = "", ["enabled"] = true },
                });
                return;
            case ("GET", "/api/session"):
            {
                // this session's numbers, in the shape MelkTank's session file has (what ACGodot keeps of them)
                var e = Entry(mt);
                double hrs = Math.Max((DateTime.UtcNow - _started).TotalHours, 1e-6);
                e["started"] = _started.ToString("o");
                e["playedSecs"] = (long)(DateTime.UtcNow - _started).TotalSeconds;
                e["kills"] = _kills; e["xpEarned"] = _xp;
                e["killsPerHourRecent"] = Math.Round(_kills / hrs); e["xpPerHourRecent"] = Math.Round(_xp / hrs);
                // (MelkTank's own session - kills by monster, what was looted, the bank, augmentations, bounties - over ours)
                Overlay(e, Bot(mt, session: true));
                Reply(ctx, 200, e);
                return;
            }
            case ("GET", "/api/inventory"):
                Reply(ctx, 200, InventoryJson());
                return;
            case ("GET", "/api/chat"):
            {
                var lines = new JsonArray();
                lock (_chat) foreach (var (text, kind, at) in _chat) lines.Add(new JsonObject { ["text"] = text, ["kind"] = kind, ["t"] = at.ToString("o") });
                Reply(ctx, 200, new JsonObject { ["account"] = AccountName, ["lines"] = lines });
                return;
            }
            case ("GET", "/api/screenshot"):
            {
                var img = _h.GetViewport().GetTexture().GetImage();
                var jpg = img.SaveJpgToBuffer(0.8f);
                ctx.Response.StatusCode = 200;
                ctx.Response.ContentType = "image/jpeg";
                ctx.Response.ContentLength64 = jpg.Length;
                ctx.Response.OutputStream.Write(jpg);
                ctx.Response.Close();
                return;
            }
            case ("POST", "/api/command"):
            {
                var b = Body(ctx);
                string action = (b?["action"]?.GetValue<string>() ?? "").ToLowerInvariant();
                string msg = "Done.";
                if (action == "set")
                {
                    string feature = (b?["feature"]?.GetValue<string>() ?? "").ToLowerInvariant(), value = (b?["value"]?.GetValue<string>() ?? "").ToLowerInvariant();
                    if (mt == null || !mt.SetFeature(feature, value == "on")) { Reply(ctx, 400, new JsonObject { ["error"] = $"ACGodot's MelkTank has no {feature} switch" }); return; }
                    msg = $"{feature} {value}.";
                }
                else if (action == "navroute")
                {
                    string name = b?["name"]?.GetValue<string>() ?? "";
                    mt?.LoadRoute(name);
                    msg = $"Route {name} loaded.";
                }
                else if (action == "chat")
                {
                    string text = (b?["text"]?.GetValue<string>() ?? "").Trim();
                    if (text.Length > 0) _h.Type?.Invoke(text);
                    msg = "Sent.";
                }
                else if (action == "identify")
                {
                    // an item tapped on the phone's inventory page: identified in the game (its ID then goes with it)
                    long id = NumberIn(b);
                    var item = _h.Inv.Worn.Concat(_h.Inv.Pack).Concat(_h.Inv.SidePacks).FirstOrDefault(i => IdOf(i) == id);
                    if (item == null) { Reply(ctx, 400, new JsonObject { ["error"] = "That item isn't on the character any more." }); return; }
                    _identified.Add(id);
                    // (quietly: nothing in the game is chosen or opened - a fight going on isn't disturbed)
                    _h.QuietIdentify?.Invoke(item);
                    msg = "Identifying.";
                }
                else if (action == "useitem")
                {
                    // "Use" on the phone's inventory page: that item used in the game (worn, taken off, or used)
                    long id = NumberIn(b);
                    var item = _h.Inv.Worn.Concat(_h.Inv.Pack).FirstOrDefault(i => IdOf(i) == id);
                    if (item == null) { Reply(ctx, 400, new JsonObject { ["error"] = "That item isn't on the character any more." }); return; }
                    _h.UseItem?.Invoke(item);
                    msg = $"Using {item.Name}.";
                }
                else if (action == "showpack")
                {
                    _openPack = NumberIn(b);
                    msg = "OK.";
                }
                else if (action == "quit")
                {
                    // the phone's Log out & close: out of the world properly (the server saves the character), the game closed
                    // once the character screen is back
                    Reply(ctx, 200, new JsonObject { ["ok"] = true, ["message"] = "Logging out, then closing." });
                    (_h.LogoutQuit ?? _h.Quit)?.Invoke();
                    return;
                }
                else if (action == "closenow")
                {
                    // the phone's Close now: the game closed straight away (the server just told it's gone)
                    Reply(ctx, 200, new JsonObject { ["ok"] = true, ["message"] = "Closing." });
                    _h.Quit?.Invoke();
                    return;
                }
                else if (action is "refresh" or "note") msg = "OK.";
                // anything else: the bot's own (the bank transfers, organizing, rebuffing...), done as its phone commands are
                else if (mt != null && mt.PhoneCommand(action, Values(b))) msg = b?["message"]?.GetValue<string>() ?? "Sent.";
                else { Reply(ctx, 400, new JsonObject { ["error"] = $"ACGodot doesn't do {action} yet" }); return; }
                Reply(ctx, 200, new JsonObject { ["ok"] = true, ["message"] = msg });
                return;
            }
            case ("POST", "/api/interval"):
                Reply(ctx, 200, new JsonObject { ["ok"] = true, ["interval"] = 15 });
                return;
        }
        Reply(ctx, 404, new JsonObject { ["error"] = "not found" });
    }

    // the item or pack a command is about: its number, sent as "id" or (through the PC's service) as the text "name"
    private static long NumberIn(JsonNode? b)
    {
        try { if (b?["id"] is JsonValue v && v.TryGetValue(out long n)) return n; } catch { }
        return long.TryParse(b?["name"]?.ToString(), out long m) ? m : 0;
    }
    private readonly HashSet<long> _identified = new();
    private long _openPack;
    private static long IdOf(ACGodot.Combat.Item i) => i.Guid != 0 ? i.Guid : i.Uid;

    private static string SlotOf(ACGodot.Combat.Item i)
    {
        string n = ACGodot.UI.InventoryPanel.SlotName(i.WornAt);
        return n.Length > 0 ? n : "Worn";
    }

    private static string KindOf(ACGodot.Combat.Item i)
    {
        int t = i.ItemType;
        return (t & 0x1) != 0 ? "Melee weapon" : (t & 0x100) != 0 ? "Missile weapon" : (t & 0x8000) != 0 ? "Caster" : (t & 0x2) != 0 ? "Armor" : (t & 0x4) != 0 ? "Clothing"
             : (t & 0x8) != 0 ? "Jewelry" : (t & 0x20) != 0 ? "Food" : (t & 0x800) != 0 ? "Gem" : (t & 0x1000) != 0 ? "Spell component" : (t & 0x40000) != 0 ? "Mana stone"
             : (t & 0x2000) != 0 ? "Book" : (t & 0x4000) != 0 ? "Key" : (t & 0x200) != 0 ? "Container" : (t & 0x20000) != 0 ? "Trade note" : "Misc";
    }

    /// <summary>What's worn and carried, in the shape MelkTank's inventory file has: items (worn ones with their slot, the rest with the pack they're in) and the side packs.</summary>
    private JsonObject InventoryJson()
    {
        var inv = _h.Inv;
        var items = new JsonArray();
        JsonObject One(ACGodot.Combat.Item i, string eq, long pack)
        {
            long id = IdOf(i);
            // (a server's item says little until it's identified: its ID goes with it once asked for)
            string d = i.Guid == 0 || _identified.Contains(id) ? i.Describe() + (i.Notes.Length > 0 ? "\n" + i.Notes : "") : "";
            return new JsonObject { ["id"] = id, ["n"] = i.Name, ["c"] = KindOf(i), ["q"] = Math.Max(1, i.Stack), ["eq"] = eq, ["pk"] = pack, ["d"] = d, ["r"] = "" };
        }
        foreach (var i in inv.Worn) items.Add(One(i, SlotOf(i), 0));
        foreach (var i in inv.Pack) items.Add(One(i, "", i.Holder));
        var packs = new JsonArray();
        foreach (var p in inv.SidePacks)
            packs.Add(new JsonObject { ["id"] = IdOf(p), ["n"] = p.Name, ["count"] = inv.Pack.Count(i => i.Holder != 0 && i.Holder == p.Guid), ["cap"] = p.Capacity });
        return new JsonObject { ["account"] = AccountName, ["character"] = _h.Net == null || _h.Net.CharacterKnown ? _h.Me.Name : _h.Net.EnteringName, ["updated"] = DateTime.UtcNow.ToString("o"), ["items"] = items, ["packs"] = packs, ["openPack"] = _openPack };
    }

    private string AccountName => _h.Account.Length > 0 ? _h.Account : "ACGodot";

    /// <summary>This character as the app shows an account (the same fields MelkTank's status file has).</summary>
    // what the bot itself reports (its status and its session), asked for at most every second and a half
    private string _botStatus = "", _botSession = "";
    private DateTime _botStatusAt, _botSessionAt;
    /// <summary>A command's values as text (what isn't text written as JSON), for the bot.</summary>
    private static Dictionary<string, string> Values(JsonNode? b)
    {
        var d = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (b is JsonObject o)
            foreach (var kv in o)
                d[kv.Key] = kv.Value is JsonValue v && v.TryGetValue<string>(out var str) ? str : kv.Value?.ToJsonString() ?? "";
        return d;
    }

    private string Bot(IBotSwitches? mt, bool session)
    {
        if (mt == null) return "";
        var now = DateTime.UtcNow;
        try
        {
            if (session) { if ((now - _botSessionAt).TotalSeconds > 1.5) { _botSessionAt = now; _botSession = mt.SessionJson() ?? ""; } return _botSession; }
            if ((now - _botStatusAt).TotalSeconds > 1.5) { _botStatusAt = now; _botStatus = mt.StatusJson() ?? ""; }
            return _botStatus;
        }
        catch { return ""; }
    }
    // (what's ours to say stays ours: which account and client this is, and that it's running)
    private static readonly HashSet<string> Ours = new() { "account", "server", "character", "configuredCharacter", "state", "launching", "restartNote", "clientOpen", "running", "loggedIn", "updated", "interval", "clientStarted", "client", "build", "hp", "hpMax", "st", "stMax", "mp", "mpMax" };
    private static void Overlay(JsonObject e, string json)
    {
        if (string.IsNullOrEmpty(json)) return;
        try
        {
            if (JsonNode.Parse(json) is not JsonObject from) return;
            foreach (var kv in from.ToList())
            {
                if (Ours.Contains(kv.Key)) continue;
                from.Remove(kv.Key);
                e[kv.Key] = kv.Value;
            }
        }
        catch { }
    }

    private JsonObject Entry(IBotSwitches? mt)
    {
        var entry = EntryOwn(mt);
        Overlay(entry, Bot(mt, session: false));
        return entry;
    }

    private JsonObject EntryOwn(IBotSwitches? mt)
    {
        double hrs = Math.Max((DateTime.UtcNow - _started).TotalHours, 1e-6);
        var routes = new JsonArray();
        if (mt != null) foreach (var r in mt.Routes()) routes.Add(r);
        // (logging in, the character isn't ours yet - its name is still the placeholder "Adventurer": it's the one
        // being entered, and not in the game until the server has said who it is)
        bool online = _h.Net == null || (_h.OnServer && _h.Net.CharacterKnown);
        string me = online ? _h.Me.Name : _h.Net?.EnteringName ?? "";
        return new JsonObject
        {
            ["account"] = AccountName, ["server"] = _h.ServerName, ["configuredCharacter"] = me,
            ["state"] = "online", ["launching"] = "", ["restartNote"] = "", ["clientOpen"] = true,
            ["character"] = me, ["loggedIn"] = _h.Playing && online, ["running"] = true, ["updated"] = DateTime.UtcNow.ToString("o"), ["interval"] = 15,
            ["clientStarted"] = _started.ToString("o"), ["loginTime"] = _started.ToString("o"),
            ["lastAttack"] = _lastAttack == DateTime.MinValue ? "" : _lastAttack.ToString("o"),
            ["coins"] = _h.Inv.Pyreals, ["deaths"] = _deaths,
            ["master"] = mt?.Get("master") ?? false, ["combat"] = mt?.Get("combat") ?? false, ["nav"] = mt?.Get("nav") ?? false,
            ["loot"] = mt?.Get("loot") ?? false, ["buff"] = mt?.Get("buff") ?? false, ["summon"] = false,
            ["navRoute"] = mt?.RouteName ?? "", ["navRoutes"] = routes, ["navMode"] = mt?.NavMode ?? "",
            ["engineStatus"] = mt?.Status ?? "", ["location"] = _h.MapCoords,
            ["killsPerHour"] = Math.Round(_kills / hrs), ["xpPerHour"] = Math.Round(_xp / hrs),
            ["mobs"] = _h.Enemies(40f).Count, ["corpses"] = _h.Corpses(30f).Count,
            ["hp"] = _h.Me.Health, ["hpMax"] = _h.Me.MaxHealth, ["st"] = _h.Me.Stamina, ["stMax"] = _h.Me.MaxStamina, ["mp"] = _h.Me.Mana, ["mpMax"] = _h.Me.MaxMana,
            ["kills"] = _kills, ["xpEarned"] = _xp,
            ["build"] = "ACGodot", ["client"] = "acgodot",
        };
    }

    private static JsonNode? Body(HttpListenerContext ctx)
    {
        try { using var r = new StreamReader(ctx.Request.InputStream, Encoding.UTF8); var t = r.ReadToEnd(); return t.Length > 0 ? JsonNode.Parse(t) : null; }
        catch { return null; }
    }

    private static void Reply(HttpListenerContext ctx, int code, JsonNode body)
    {
        var bytes = Encoding.UTF8.GetBytes(body.ToJsonString());
        ctx.Response.StatusCode = code;
        ctx.Response.ContentType = "application/json";
        ctx.Response.Headers["Cache-Control"] = "no-store";
        ctx.Response.ContentLength64 = bytes.Length;
        ctx.Response.OutputStream.Write(bytes);
        ctx.Response.Close();
    }
}
