using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using ACGodot.DecalShim;
using ACGodot.Objects;
using Godot;
using Item = ACGodot.Combat.Item;

namespace Decal.Adapter.Wrappers
{






    public class CoordsObject
    {
        public CoordsObject(double ns, double ew) { NorthSouth = ns; EastWest = ew; }
        public double NorthSouth { get; }
        public double EastWest { get; }
        public double DistanceToCoords(CoordsObject o) => Math.Sqrt(Math.Pow(o.NorthSouth - NorthSouth, 2) + Math.Pow(o.EastWest - EastWest, 2));
        public override string ToString() => $"{Math.Abs(NorthSouth):0.0}{(NorthSouth >= 0 ? "N" : "S")}, {Math.Abs(EastWest):0.0}{(EastWest >= 0 ? "E" : "W")}";
    }

    public class Vector3Object
    {
        public Vector3Object(double x, double y, double z) { X = x; Y = y; Z = z; }
        public double X { get; } public double Y { get; } public double Z { get; }
    }

    /// <summary>A thing in the world or in your pack, as Decal shows it: a creature, NPC, door, portal, corpse or item.</summary>
    public class WorldObject
    {
        internal readonly object Thing;   // a Selectable, an Item, or the player (null)
        internal WorldObject(object thing, int id) { Thing = thing; Id = id; }

        public int Id { get; }
        private ObjectStreamer.Selectable Sel => Thing as ObjectStreamer.Selectable;
        private Item It => Thing as Item ?? Sel?.Item as Item;
        public bool IsPlayer => Id == Bridge.PlayerId;

        public string Name => IsPlayer ? CoreManager.Current.CharacterFilter.Name
                            : Sel != null ? (Bridge.IsCorpse(Sel, Id) && !Sel.Name.StartsWith("Corpse of ") ? "Corpse of " + Sel.Name : Sel.Name)
                            : It?.Name ?? "";

        public ObjectClass ObjectClass
        {
            get
            {
                if (IsPlayer) return ObjectClass.Player;
                if (Sel is { } s)
                {
                    if (s.Item is Item gi) return ClassOf(gi);
                    if (s.Kind >= 3) return ObjectClass.Player;   // (another player on the server)
                    if (s.Type == 7) return ObjectClass.Portal;
                    if (s.Type == 19) return ObjectClass.Door;
                    if (s.Type == 22) return ObjectClass.Lifestone;
                    if (s.Corpse) return ObjectClass.Corpse;   // (a server's corpse: a thing of its own)
                    // (on a server what's left of the creature that died isn't the corpse - the server makes that - and goes in a moment)
                    if (s.Fight is ACGodot.Combat.Fighter { St: ACGodot.Combat.Fighter.State.Dead }) return Bridge.Online ? ObjectClass.Misc : ObjectClass.Corpse;
                    if (s.Kind == 2) return ObjectClass.Monster;
                    if (s.Kind == 1) return s.Type == 12 ? ObjectClass.Vendor : ObjectClass.Npc;
                    return ObjectClass.Misc;
                }
                return It != null ? ClassOf(It) : ObjectClass.Unknown;
            }
        }

        private static ObjectClass ClassOf(Item i)
        {
            if (i.IsCoins) return ObjectClass.Money;
            if (i.Capacity > 0) return ObjectClass.Container;   // (a pack, a sack, a focus)
            if ((i.ItemType & 0x40000000) != 0) return ObjectClass.Salvage;
            if (i.MaxUses > 0) return i.Name.Contains("Lockpick", StringComparison.OrdinalIgnoreCase) ? ObjectClass.Lockpick : ObjectClass.HealingKit;
            if (i.MaxMana > 0) return ObjectClass.ManaStone;
            int t = i.ItemType;
            if ((t & 1) != 0) return ObjectClass.MeleeWeapon;
            if ((t & 2) != 0) return ObjectClass.Armor;
            if ((t & 4) != 0) return ObjectClass.Clothing;
            if ((t & 8) != 0) return ObjectClass.Jewelry;
            if ((t & 0x20) != 0) return ObjectClass.Food;
            if ((t & 0x100) != 0) return ObjectClass.MissileWeapon;
            if ((t & 0x200) != 0) return ObjectClass.Container;
            if ((t & 0x800) != 0) return ObjectClass.Gem;
            if ((t & 0x1000) != 0) return ObjectClass.SpellComponent;
            if ((t & 0x2000) != 0) return ObjectClass.Book;
            if ((t & 0x4000) != 0) return ObjectClass.Key;
            if ((t & 0x8000) != 0) return ObjectClass.WandStaffOrb;
            if ((t & 0x40000) != 0) return ObjectClass.Ust;
            if ((t & 0x80000) != 0) return ObjectClass.ManaStone;
            if ((t & 0x40000000) != 0) return ObjectClass.Salvage;
            return ObjectClass.Misc;
        }

        public int Type => Sel?.Wcid ?? It?.Wcid ?? 0;
        public int Icon => (int)(It?.Icon ?? 0);
        public int Category => 0;
        public int Behavior => 0;
        /// <summary>Where it is: your pack (you), the open corpse, or the world (0).</summary>
        public int Container
        {
            get
            {
                if (It == null || Sel != null) return 0;
                var h = Bridge.Host;
                if (h == null) return 0;
                // (in a side pack: that pack, as Decal has it - what's in the main pack, worn, or a side pack itself: you)
                if (It.Holder != 0 && h.Inv.Pack.Contains(It) && h.Inv.SidePacks.FirstOrDefault(p => p.Guid == It.Holder) is { } inPack) return Bridge.IdOf(inPack);
                if (h.Inv.Pack.Contains(It) || h.Inv.Worn.Contains(It) || h.Inv.SidePacks.Contains(It)) return Bridge.PlayerId;
                if (h.Combat.OpenedCorpse is { } c && h.Combat.CorpseContents(c)?.Contains(It) == true) return Bridge.IdOf(c);
                // (in the corpse or chest open on a server)
                if (Bridge.Online && It.Guid != 0 && h.Net.OpenContainer != 0 && h.Net.OpenContents().Contains(It)) return Bridge.OpenContainerId();
                return 0;
            }
        }
        public bool HasIdData => true;
        public int GameDataFlags1 => 0;
        public int LastIdTime => 0;
        public int Values(LongValueKey k) => Values(k, 0);
        public int SpellCount => It?.Spells.Count ?? 0;
        public int ActiveSpellCount => It != null && It.WornAt != 0 ? It.Spells.Count : 0;
        public int Spell(int i) => It != null && i >= 0 && i < It.Spells.Count ? It.Spells[i] : 0;
        public int ActiveSpell(int i) => ActiveSpellCount > i ? Spell(i) : 0;
        public List<int> LongKeys => new() { (int)LongValueKey.Value, (int)LongValueKey.Burden };
        public List<int> StringKeys => new() { (int)StringValueKey.Name };
        public List<int> DoubleKeys => new();
        public List<int> BoolKeys => new();
        public Vector4Object Orientation() => new Vector4Object(1, 0, 0, 0);

        public int Values(LongValueKey k, int dflt)
        {
            var it = It;
            switch (k)
            {
                case (LongValueKey)218103812: return it != null && it.Capacity > 0 ? it.Capacity : dflt;   // ItemSlots
                case LongValueKey.Material: return it != null && it.Material != 0 ? it.Material : dflt;
                case LongValueKey.StackCount: return it != null ? Math.Max(1, it.Stack) : dflt;
                case LongValueKey.StackMax: return it?.MaxStack ?? dflt;
                case LongValueKey.Value: return it?.Value ?? dflt;
                case LongValueKey.Burden: return it?.Burden ?? dflt;
                case LongValueKey.Icon: return (int)(it?.Icon ?? 0);
                case LongValueKey.EquippedSlots: return it?.WornAt ?? 0;
                case LongValueKey.Wielder:   // (worn or wielded: you)
                {
                    var h = Bridge.Host;
                    return it != null && Sel == null && h != null && h.Inv.Worn.Contains(it) ? Bridge.PlayerId : 0;
                }
                case LongValueKey.EquipableSlots: return it?.Locations ?? 0;
                case LongValueKey.ArmorLevel: return it?.ArmorLevel ?? dflt;
                case LongValueKey.MaxDamage: return it?.Damage ?? dflt;
                case LongValueKey.UsesRemaining: return it != null && it.MaxUses > 0 ? it.Uses : dflt;
                case LongValueKey.UsesTotal: return it != null && it.MaxUses > 0 ? it.MaxUses : dflt;
                case LongValueKey.CurrentMana: return it != null && it.MaxMana > 0 ? it.Mana : dflt;
                case LongValueKey.MaximumMana: return it != null && it.MaxMana > 0 ? it.MaxMana : dflt;
                case LongValueKey.Container: return Container;
                case LongValueKey.Landblock:
                {
                    var pos = Position;
                    if (pos == null) return dflt;
                    return unchecked((int)Bridge.Place(pos.Value, Sel?.Cell ?? 0).cell);
                }
                case LongValueKey.CreatureLevel:
                    if (IsPlayer) return CoreManager.Current.CharacterFilter.Level;
                    if (Sel?.Fight is ACGodot.Combat.Fighter f && f.W.Level > 0) return f.W.Level;
                    return dflt;
                case LongValueKey.Species: return dflt;
                case LongValueKey.Heritage: return IsPlayer ? 1 : dflt;
                case LongValueKey.Type: return Type;
                default: return dflt;
            }
        }

        public string Values(StringValueKey k) => Values(k, "");
        public string Values(StringValueKey k, string dflt)
        {
            if (k == StringValueKey.Name) return Name;
            // a corpse's appraisal: who killed it (the world on its own: only you kill things)
            if (k == StringValueKey.FullDescription && ObjectClass == ObjectClass.Corpse && Sel != null)
                return "Killed by " + CoreManager.Current.CharacterFilter.Name + ".";
            return dflt;
        }
        public double Values(DoubleValueKey k) => Values(k, 0.0);
        public double Values(DoubleValueKey k, double dflt) => k == DoubleValueKey.Heading && Sel != null ? 0 : dflt;
        public bool Values(BoolValueKey k) => Values(k, false);
        public bool Values(BoolValueKey k, bool dflt) => k == BoolValueKey.Open && Sel != null ? Sel.Open : dflt;

        internal Vector3? Position
        {
            get
            {
                if (IsPlayer) return Bridge.Host?.Player?.Position;
                if (Sel != null) return Sel.Feet;
                return It != null ? Bridge.Host?.Player?.Position : null;   // in your pack: where you are
            }
        }

        public CoordsObject Coordinates()
        {
            var p = Position;
            if (p == null) return null;
            var (ns, ew) = Bridge.Coords(p.Value);
            return new CoordsObject(ns, ew);
        }

        public Vector3Object RawCoordinates()
        {
            var p = Position;
            if (p == null) return new Vector3Object(0, 0, 0);
            var (_, x, y, z) = Bridge.Place(p.Value, Sel?.Cell ?? 0);
            return new Vector3Object(x, y, z);
        }

        public double Distance(WorldObject o)
        {
            var a = Position; var b = o?.Position;
            return a == null || b == null ? double.MaxValue : a.Value.DistanceTo(b.Value) / 240.0;
        }

        public override bool Equals(object obj) => obj is WorldObject w && w.Id == Id;
        public override int GetHashCode() => Id;
    }

    public class WorldObjectCollection : IEnumerable<WorldObject>
    {
        private readonly List<WorldObject> _l;
        public WorldObjectCollection(IEnumerable<WorldObject> l) { _l = l.ToList(); }
        public int Count => _l.Count;
        public int Quantity => _l.Count;
        public WorldObject First => _l.FirstOrDefault();
        public WorldObject this[int i] => _l[i];
        public IEnumerator<WorldObject> GetEnumerator() => _l.GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => _l.GetEnumerator();
        public void SetFilter(object f) { }
        public void Dispose() { }
    }

    public class CreateObjectEventArgs : EventArgs { public CreateObjectEventArgs(WorldObject o) { New = o; } public WorldObject New { get; } }
    public class ChangeObjectEventArgs : EventArgs { public ChangeObjectEventArgs(WorldObject o, WorldChangeType change = WorldChangeType.IdentReceived) { Changed = o; Change = change; } public WorldObject Changed { get; } public WorldChangeType Change { get; } }
    public class ReleaseObjectEventArgs : EventArgs { public ReleaseObjectEventArgs(WorldObject o) { Released = o; } public WorldObject Released { get; } }
    public class MoveObjectEventArgs : EventArgs { public MoveObjectEventArgs(WorldObject o) { Moved = o; } public WorldObject Moved { get; } }

    /// <summary>Everything Decal knows about: what's around you and what you carry.</summary>
    public class WorldFilter
    {
        public event EventHandler<CreateObjectEventArgs> CreateObject;
        public event EventHandler<ChangeObjectEventArgs> ChangeObject;
        public event EventHandler<ReleaseObjectEventArgs> ReleaseObject;
        public event EventHandler<MoveObjectEventArgs> MoveObject;

        private static readonly Dictionary<int, WorldObject> _wrapped = new();

        internal static WorldObject Wrap(object thing)
        {
            if (thing == null) return null;
            int id = Bridge.IdOf(thing);
            if (!_wrapped.TryGetValue(id, out var w)) _wrapped[id] = w = new WorldObject(thing, id);
            return w;
        }

        private static WorldObject _me;
        internal static WorldObject Me => _me ??= new WorldObject(null, Bridge.PlayerId);

        public WorldObject this[int id]
        {
            get
            {
                if (id == Bridge.PlayerId) return Me;
                if (_wrapped.TryGetValue(id, out var w)) return Alive(w) ? w : null;
                var t = Bridge.ThingOf(id);
                if (t is ObjectStreamer.Selectable s && Bridge.Host?.Objects?.IsHere(s) == false) return null;
                return t != null ? Wrap(t) : null;
            }
        }

        private static bool Alive(WorldObject w)
        {
            if (w.Thing is ObjectStreamer.Selectable s) return !s.Gone && Bridge.IdOf(s) == w.Id && Bridge.Host?.Objects?.IsHere(s) != false;   // (another dungeon's: not here)   // (a monster's id ends at its death: the corpse has its own)
            if (w.Thing is Item i) { var h = Bridge.Host; return h == null || h.Inv.Pack.Contains(i) || h.Inv.Worn.Contains(i) || true; }
            return true;
        }

        private static IEnumerable<ObjectStreamer.Selectable> Around()
        {
            var h = Bridge.Host;
            if (h?.Objects == null) yield break;
            foreach (var s in h.Objects.AllSelectables) if (!s.Gone) yield return s;
        }

        public Vendor OpenVendor => null;
        public WorldObjectCollection GetLandscape() => new(Around().Select(Wrap).Prepend(Me));
        public WorldObjectCollection GetAll() => new(Around().Select(Wrap).Concat(Inventory()).Prepend(Me));
        public WorldObjectCollection GetInventory() => new(Inventory());
        public WorldObjectCollection GetByObjectClass(ObjectClass c) => new(GetAll().Where(o => o.ObjectClass == c));
        public WorldObjectCollection GetByName(string n) => new(GetAll().Where(o => string.Equals(o.Name, n, StringComparison.OrdinalIgnoreCase)));
        public WorldObjectCollection GetByNameSubstring(string n) => new(GetAll().Where(o => o.Name.IndexOf(n, StringComparison.OrdinalIgnoreCase) >= 0));
        public WorldObjectCollection GetByContainer(int id)
        {
            // (yours: what's on you and in the main pack, and the side packs themselves; a side pack's: what's in it)
            if (id == Bridge.PlayerId && Bridge.Host?.Combat != null)
            {
                var inv = Bridge.Host.Inv;
                return new(inv.Worn.ToList().Concat(inv.Pack.Where(i => i.Holder == 0).ToList()).Concat(inv.SidePacks.ToList()).Select(Wrap));
            }
            if (id == Bridge.PlayerId) return GetInventory();
            if (Bridge.ThingOf(id) is Item sidePack && sidePack.Guid != 0 && Bridge.Host?.Inv.SidePacks.Contains(sidePack) == true)
                return new(Bridge.Host.Inv.Pack.Where(i => i.Holder == sidePack.Guid).ToList().Select(Wrap));
            // a corpse: what's in it
            // (a server's: the one that's open, as the server listed it)
            if (Bridge.Online && id != 0 && id == Bridge.OpenContainerId()) return new(Bridge.Host.Net.OpenContents().Select(Wrap));
            if (Bridge.ThingOf(id) is ObjectStreamer.Selectable s && Bridge.Host?.Combat?.CorpseContents(s) is { } loot)
                return new(loot.ToList().Select(Wrap));
            return new(Enumerable.Empty<WorldObject>());
        }

        private static IEnumerable<WorldObject> Inventory()
        {
            var h = Bridge.Host;
            if (h?.Combat == null) yield break;
            foreach (var i in h.Inv.Worn.ToList()) yield return Wrap(i);
            foreach (var i in h.Inv.Pack.ToList()) yield return Wrap(i);
            foreach (var i in h.Inv.SidePacks.ToList()) yield return Wrap(i);
        }

        public double Distance(int a, int b)
        {
            var wa = this[a]; var wb = this[b];
            return wa == null || wb == null ? double.MaxValue : wa.Distance(wb);
        }

        // what's come into view since the last look: CreateObject for each (a second at a time)
        private static readonly HashSet<int> _seen = new();
        private static double _lookIn;

        // the pack changed (picked up, dropped, stacked, split, worn...): Decal's "storage change", so plugins' inventory
        // lists start again at once (MelkTank's stacker waits for one)
        private static int _invSig;
        private static void InvWatch()
        {
            var h = Bridge.Host;
            if (h?.Combat == null) return;
            int sig = 17;
            foreach (var i in h.Inv.Pack) sig = sig * 31 + System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode(i) * 7 + i.Stack;
            foreach (var i in h.Inv.Worn) sig = sig * 31 + System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode(i) + 1;
            if (sig == _invSig) return;
            _invSig = sig;
            var wf = CoreManager.Current.WorldFilter;
            try { wf.ChangeObject?.Invoke(wf, new ChangeObjectEventArgs(Me, WorldChangeType.StorageChange)); } catch (Exception ex) { GD.PushWarning("plugin inventory: " + ex.Message); }
        }

        internal static void Track()
        {
            FlushIds();
            InvWatch();
            // (every frame: a thing gone - a monster dead, its id the corpse's from then on - is told the frame it goes)
            var wf = CoreManager.Current.WorldFilter;
            var now = new HashSet<int>();
            foreach (var s in Around())
            {
                var w = Wrap(s);
                now.Add(w.Id);
                if (_seen.Add(w.Id)) { try { wf.CreateObject?.Invoke(wf, new CreateObjectEventArgs(w)); } catch (Exception ex) { GD.PushWarning("plugin create: " + ex.Message); } }
            }
            foreach (var id in _seen.Where(i => !now.Contains(i)).ToList())
            {
                _seen.Remove(id);
                if (_wrapped.TryGetValue(id, out var w)) { try { wf.ReleaseObject?.Invoke(wf, new ReleaseObjectEventArgs(w)); } catch { } }
            }
        }

        internal void RaiseChanged(WorldObject w) { try { ChangeObject?.Invoke(this, new ChangeObjectEventArgs(w)); } catch { } }

        // IDs answered on the next frame
        private static readonly List<int> _idsDue = new();
        internal void RaiseChangedSoon(int id) { lock (_idsDue) if (!_idsDue.Contains(id)) _idsDue.Add(id); }
        internal static void FlushIds()
        {
            int[] due;
            lock (_idsDue) { if (_idsDue.Count == 0) return; due = _idsDue.ToArray(); _idsDue.Clear(); }
            var wf = CoreManager.Current.WorldFilter;
            foreach (int id in due) { var w = wf[id]; if (w != null) wf.RaiseChanged(w); }
        }
    }

    public class LogoffEventArgs : EventArgs { public LogoffEventType Type { get; set; } }
    public class ChangePortalModeEventArgs : EventArgs { public ChangePortalModeEventArgs(PortalEventType t) { Type = t; } public PortalEventType Type { get; } }
    public class LoginEventArgs : EventArgs { public int Id { get; set; } }
    public class ChangeVitalEventArgs : EventArgs { public int Type { get; set; } public int Amount { get; set; } }
    public class SpellCastEventArgs : EventArgs { public int SpellId { get; set; } public int TargetId { get; set; } }



    public class SkillInfoWrapper
    {
        public SkillInfoWrapper(int id) { Id = id; }
        public int Id { get; }
        private ACGodot.Combat.Character Me => Bridge.Host?.Me;
        public int Current => Me?.Skill(Id) ?? 0;
        public int Base => Me?.Skill(Id) ?? 0;
        public int Buffed => Current;
        public TrainingType Training => Me == null ? TrainingType.Untrained : Me.TrainingOf(Id) switch
        {
            ACGodot.Combat.Character.Training.Specialized => TrainingType.Specialized, ACGodot.Combat.Character.Training.Trained => TrainingType.Trained,
            _ => TrainingType.Untrained,
        };
        public string Name => Me?.AllSkills().FirstOrDefault(s => s.id == Id).name ?? "";
    }

    public class AttributeInfoWrapper
    {
        public AttributeInfoWrapper(int i) { _i = i; }
        private readonly int _i;
        public int Current => Bridge.Host?.Me?.Attribute(_i) ?? 0;
        public int Base => Current;
        public int Buffed => Current;
    }

    public class VitalInfoWrapper
    {
        public VitalInfoWrapper(int i) { _i = i; }
        private readonly int _i;
        public int Current => Bridge.Host?.Combat == null ? 0 : _i switch { 0 => Bridge.Host.Combat.Health, 1 => Bridge.Host.Me.Stamina, _ => Bridge.Host.Me.Mana };
        public int Base => Buffed;
        public int Buffed => Bridge.Host?.Me == null ? 0 : _i switch { 0 => Bridge.Host.Me.MaxHealth, 1 => Bridge.Host.Me.MaxStamina, _ => Bridge.Host.Me.MaxMana };
    }

    /// <summary>Your character, as Decal shows it.</summary>
    public class CharacterFilter
    {
        public event EventHandler LoginComplete;
        public event EventHandler<LogoffEventArgs> Logoff;
        public event EventHandler<ChangePortalModeEventArgs> ChangePortalMode;
        public event EventHandler<LoginEventArgs> Login;
        public event EventHandler<ChangeVitalEventArgs> ChangeVital;
        public event EventHandler<SpellCastEventArgs> SpellCast;
        public event EventHandler ChangeExperience, ChangeFellowship, ChangeEnchantments, ActionComplete;
        public event EventHandler<DeathEventArgs> Death;
        public IEnumerable<AccountCharInfo> Characters => new[] { new AccountCharInfo { Id = Bridge.PlayerId, Name = Name } };

        internal void RaiseLogin() => LoginComplete?.Invoke(this, EventArgs.Empty);
        internal void RaisePortal(PortalEventType t) { try { ChangePortalMode?.Invoke(this, new ChangePortalModeEventArgs(t)); } catch (Exception ex) { GD.PushWarning("plugin portal: " + ex.Message); } }
        public void RaiseLogoff() => Logoff?.Invoke(this, new LogoffEventArgs());

        public int Id => Bridge.PlayerId;
        public string Name => Bridge.Host?.Me?.Name ?? "";
        public string Server => string.IsNullOrEmpty(Bridge.Host?.ServerName) ? "ACGodot" : Bridge.Host.ServerName;
        public string AccountName => Bridge.Host?.Account ?? "";
        public int Level => Bridge.Host?.Me?.Level ?? 1;
        public int LoginStatus => Bridge.LoginStatus;
        public long TotalXP => Bridge.Host?.Me?.TotalXp ?? 0;
        public long UnassignedXP => Bridge.Host?.Me?.UnassignedXp ?? 0;
        public int Burden => Bridge.Host?.Inv.TotalBurden ?? 0;
        public int Health => Bridge.Host?.Combat?.Health ?? 0;
        public int Stamina => Bridge.Host?.Me?.Stamina ?? 0;
        public int Mana => Bridge.Host?.Me?.Mana ?? 0;
        public int Vitae => (int)Math.Round((1f - (Bridge.Host?.Me?.Vitae ?? 1f)) * 100);
        public int Monarch => 0;
        public string Race => "Aluvian";
        public string Gender => "Male";
        public SkillsIndexer Skills { get; } = new();
        public AttributesIndexer Attributes { get; } = new();
        public VitalsIndexer Vitals { get; } = new();
        public System.Collections.ObjectModel.ReadOnlyCollection<int> SpellBook => new((Bridge.Host?.Magic?.Known().Select(s => s.Id) ?? Enumerable.Empty<int>()).ToList());
        public int SkillPoints => Bridge.Host?.Me?.SkillCredits ?? 0;
        public int GetCharProperty(int key) => 0;
        public EffectiveIndexer<CharFilterVitalType> EffectiveVital { get; } = new(t => t switch
        {
            CharFilterVitalType.Health => Bridge.Host?.Me?.MaxHealth ?? 0, CharFilterVitalType.Stamina => Bridge.Host?.Me?.MaxStamina ?? 0, _ => Bridge.Host?.Me?.MaxMana ?? 0,
        });
        public EffectiveIndexer<CharFilterSkillType> EffectiveSkill { get; } = new(t => Bridge.Host?.Me?.Skill((int)t) ?? 0);
        public EffectiveIndexer<CharFilterAttributeType> EffectiveAttribute { get; } = new(t => Bridge.Host?.Me?.Attribute((int)t - 1) ?? 0);
        public class EffectiveIndexer<T> { private readonly Func<T, int> _f; public EffectiveIndexer(Func<T, int> f) { _f = f; } public int this[T t] => _f(t); }
        public bool IsSpellKnown(int id) => Bridge.Host?.Magic?.Known().Any(s => s.Id == id) == true;
        /// <summary>The spells on you, as the game has them (what's left of each in seconds; -1: while its item is worn).</summary>
        public IEnumerable<EnchantmentWrapper> Enchantments
        {
            get
            {
                var m = Bridge.Host?.Magic;
                if (m == null) return Enumerable.Empty<EnchantmentWrapper>();
                return m.Active().Select(a => new EnchantmentWrapper { SpellId = a.spell.Id, Layer = 1, Family = (int)a.spell.Category,
                    TimeRemaining = a.left < 0 ? -1 : (int)a.left, Duration = a.left < 0 ? -1 : a.left, Adjustment = a.amount }).ToList();
            }
        }
        internal void RaiseEnchantment(int spell, double left, bool on)
        {
            var ew = new EnchantmentWrapper { SpellId = spell, Layer = 1, TimeRemaining = left < 0 ? -1 : (int)left, Duration = left };
            try { ChangeEnchantments?.Invoke(this, new ChangeEnchantmentsEventArgs { Enchantment = ew, Type = on ? AddRemoveEventType.Add : AddRemoveEventType.Delete }); }
            catch (Exception ex) { GD.PushWarning("plugin enchantment: " + ex.Message); }
        }

        public class SkillsIndexer { public SkillInfoWrapper this[CharFilterSkillType t] => new((int)t); }
        public class AttributesIndexer { public AttributeInfoWrapper this[CharFilterAttributeType t] => new((int)t - 1); }
        public class VitalsIndexer { public VitalInfoWrapper this[CharFilterVitalType t] => new(t == CharFilterVitalType.Health ? 0 : t == CharFilterVitalType.Stamina ? 1 : 2); }
    }

    /// <summary>Doing things: chat text, using and selecting things, casting, where you are.</summary>
    public class HooksWrapper
    {
        private static ACGodot.Plugins.PluginHost H => Bridge.Host;

        public void AddChatText(string text, int color) => Bridge.Say(text, color);
        public void AddChatText(string text, int color, int target) => Bridge.Say(text, color);
        public void AddChatTextRaw(string text, int color, int target) => Bridge.Say(text, color);
        public void AddChatTextRaw(string text, int color) => Bridge.Say(text, color);
        public void AddStatusText(string text) => Bridge.Say(text, 5);
        /// <summary>A command as if typed: the plugins first, then the game - quietly (a server command the world on its own
        /// doesn't have isn't "Unknown command" in chat).</summary>
        public void InvokeChatParser(string text)
        {
            if (H == null || string.IsNullOrEmpty(text)) return;
            if (text.StartsWith("/") || text.StartsWith("@")) { if (CoreManager.Current.RaiseCommand(text)) return; }
            H.Quietly(text);
        }

        public int CurrentSelection
        {
            get => (DateTime.Now - Bridge.SelfIdAt).TotalSeconds < 3 ? Bridge.PlayerId   // just identified yourself: you, for a moment
                 : H?.PickedItem?.Invoke() is { } it ? Bridge.IdOf(it) : H?.Objects?.Selected is { } s ? Bridge.IdOf(s) : 0;
            set => SelectItem(value);
        }
        public int PreviousSelection => 0;
        public void SelectItem(int id)
        {
            var t = Bridge.ThingOf(id);
            if (t is ObjectStreamer.Selectable s) H?.Select(s);
            else if (t is Item i) H?.PickItem?.Invoke(i);
        }

        public void UseItem(int id, int how) => UseItem(id, how, 0);
        public void UseItem(int id, int how, int target)
        {
            var t = Bridge.ThingOf(id);
            if (t is ObjectStreamer.Selectable s) { H?.Use?.Invoke(s); return; }
            if (t is not Item i || H == null) return;
            if (Bridge.Online && i.Guid != 0)
            {
                // on something: the target given, or (Decal's "use on the selection") what's selected - asked of the server
                // at once, nothing chosen or opened in the game
                uint on = target != 0 ? Bridge.GuidOf(target) : how == 1 ? Bridge.GuidOf(CurrentSelection) : 0;
                if (on != 0 && on != i.Guid) { H.Net.UseOn(i, on); return; }
            }
            H.UseItem?.Invoke(i);
        }
        public void ApplyItem(int item, int target) => UseItem(item, 1, target);
        /// <summary>Asks for an ID: it "comes back" on the next frame (as from the server - never inside the asking call).</summary>
        public void RequestId(int id)
        {
            // on a server: asked of it (quietly - nothing chosen, no panel); the ID "comes back" when it answers
            uint g = Bridge.Online ? Bridge.GuidOf(id) : 0;
            if (g != 0) { H.Net.Appraise(g); return; }
            CoreManager.Current.WorldFilter.RaiseChangedSoon(id);
        }

        public void CastSpell(int spellId, int target)
        {
            if (H?.Magic == null) return;
            // at the target given (the game casts at what's selected): chosen first - you yourself, or a thing in the world
            if (target == Bridge.PlayerId) { if (H.Objects.Selected != H.Objects.Self) H.Select(H.Objects.Self); }
            else if (target != 0 && Bridge.ThingOf(target) is ObjectStreamer.Selectable s && H.Objects.Selected != s) H.Select(s);
            H.Magic.Cast(spellId, quiet: true);
        }
        public CombatState CombatMode => H?.Combat == null ? CombatState.Peace : !H.Combat.CombatMode ? CombatState.Peace : H.Combat.MagicMode ? CombatState.Magic
                               : H.Inv.Weapon is { IsMissileWeapon: true } ? CombatState.Missile : CombatState.Melee;
        public void SetCombatMode(CombatState s) => H?.SetCombat(s != CombatState.Peace);
        public void SetAutorun(bool on) { if (H?.Player == null) return; H.AutoRun = on; if (!on) H.MoveTo(null); }
        public int BusyState => 0;
        public int OpenedContainer => Bridge.Online ? Bridge.OpenContainerId() : Bridge.IdOf(Bridge.Host?.Combat?.OpenedCorpse);
        public int VendorId => 0;
        public HookIndexer Attribute { get; } = new HookIndexer();
        public void SetIdleTime(double timeout) { }
        public IntPtr UIElementLookup(UIElementType t) => IntPtr.Zero;
        public System.Drawing.Rectangle UIElementRegion(UIElementType t) => default;
        public void VendorBuyAll() { }
        public void VendorAddBuyList(int templateId, int count) { }
        public void VendorClearBuyList() { }
        public void VendorSellAll() { }
        public void VendorAddSellList(int id) { }
        public void VendorClearSellList() { }
        /// <summary>The client's physics object for a thing (none here: plugins skip what needs it).</summary>
        public int GetPhysicsObjectPtr(int id) => 0;
        public int GetWeenieObjectPtr(int id) => 0;
        public void MoveItem(int objectId, int destinationId) => MoveItem(objectId, destinationId, 0, true);
        public void MoveItem(int objectId, int destinationId, int moveFlags) => MoveItem(objectId, destinationId, 0, true);
        public int BusyStateId => 0;
        public bool ChatState => UI.ImGuiLayer_Typing;
        public bool PointerState => false;
        public int SelectedStackCount { get; set; }

        public int Landcell => H?.Player?.Active == true ? unchecked((int)Bridge.Place(H.Player.Position, H.Player.Cell).cell) : 0;
        public double LocationX => H?.Player == null ? 0 : Bridge.Place(H.Player.Position, H.Player.Cell).x;
        public double LocationY => H?.Player == null ? 0 : Bridge.Place(H.Player.Position, H.Player.Cell).y;
        public double LocationZ => H?.Player == null ? 0 : Bridge.Place(H.Player.Position, H.Player.Cell).z;
        /// <summary>The way you face, degrees clockwise from north.</summary>
        public double Heading => H?.Player == null ? 0 : ((-H.Player.Heading * 180.0 / Math.PI) % 360 + 360) % 360;
        public double HeadingDegrees => Heading;
        public double HeadingRadians => Heading * Math.PI / 180;
        public HooksWrapper Underlying => this;

        /// <summary>Moves an item: out of the open corpse into your pack (taken, as the loot window's take does).</summary>
        public void MoveItem(int item, int container, int slot, bool stack)
        {
            if (H == null || Bridge.ThingOf(item) is not Item it) return;
            // on a server, something of yours into a pack of yours (the main one: your own id) at a place
            if (Bridge.Online && it.Guid != 0 && (H.Inv.Pack.Contains(it) || H.Inv.Worn.Contains(it)))
            {
                var dest = Bridge.ThingOf(container);
                if (dest is Item on2 && on2 != it && H.Inv.Pack.Contains(on2) && ACGodot.Combat.Inventory.Stackable(it, on2)) { H.Inv.StackOnto(it, on2); return; }
                if (container == Bridge.PlayerId) { H.Net.Move(it, 0, slot); return; }
                if (dest is Item pack && pack.Guid != 0 && H.Inv.SidePacks.Contains(pack)) { H.Net.Move(it, pack.Guid, slot); return; }
                return;
            }
            // onto another stack of the same thing in the pack: stacked (what Decal's move onto an item does)
            if (H.Inv.Pack.Contains(it) && Bridge.ThingOf(container) is Item onto && onto != it && H.Inv.Pack.Contains(onto) && ACGodot.Combat.Inventory.Stackable(it, onto))
            {
                H.Inv.StackOnto(it, onto);
                H.Me.Save(H.Inv);
                return;
            }
            if (H.Inv.Pack.Contains(it) || H.Inv.Worn.Contains(it)) return;   // (moving within the pack: one pack here)
            // out of the corpse or chest open on a server: asked of it
            if (Bridge.Online && it.Guid != 0 && H.Net.OpenContainer != 0 && H.Net.OpenContents().Contains(it)) { H.Net.TakeOut(it); return; }
            if (H.Combat.OpenedCorpse is { } c && H.Combat.CorpseContents(c)?.Contains(it) == true && H.Combat.LootUi is { } lw) lw.TakeIt(it);
        }
        public void DropItem(int item) { if (Bridge.ThingOf(item) is Item i && H != null && H.Inv.Pack.Contains(i)) { H.Inv.Remove(i); H.Combat.Drop(i); } }
        public void GiveItem(int item, int target) => AcClient.CM_Inventory.Event_GiveObjectRequest(unchecked((uint)target), unchecked((uint)item), 0);
        public void SelectItem(int id, int a) => SelectItem(id);
        public bool IsValidObject(int id) => CoreManager.Current.WorldFilter[id] != null;
        public void Logout() { }
        public void FaceHeading(double deg, bool unused) => H?.FaceHeading(deg);
        public void SetCursorPosition(int x, int y) { }
        public void UIElementMove(int a, int x, int y) { }
        public void SalvagePanelAdd(int id) { }
        public void SalvagePanelSalvage() { }
    }

    internal static class UI { public static bool ImGuiLayer_Typing => ACGodot.UI.ImGuiLayer.WantsKeyboard; }

    /// <summary>A Decal plugin's host (its Actions).</summary>
    public class PluginHost
    {
        public HooksWrapper Actions => CoreManager.Current.Actions;
        public object Render => null;
    }

    /// <summary>Things Decal draws in the world: the arrow pointing to coordinates (ACGodot's arrow).</summary>
    public class D3DService
    {
        public D3DObj PointToCoords(float ns, float ew, float z, int color)
        {
            Bridge.Host?.PointArrow?.Invoke(ns, ew, $"{Math.Abs(ns):0.0}{(ns >= 0 ? "N" : "S")}, {Math.Abs(ew):0.0}{(ew >= 0 ? "E" : "W")}");
            return new D3DObj(true);
        }
        public D3DObj PointToObject(int id, int color) => new D3DObj(false);
        public D3DObj MarkObjectWith3DText(int id, string text, string font, int opts) => new D3DObj(false);
        public D3DObj MarkObjectWithIcon(int id, int icon) => new D3DObj(false);
        public D3DObj NewD3DObj() => new D3DObj(false);
        public D3DObj MarkObjectWithShape(int guid, D3DShape shape, int color) => new D3DObj(false);
        public D3DObj MarkObjectWithShapeFromFile(int guid, string file, int color) => new D3DObj(false);
        public D3DObj MarkObjectWith2DText(int guid, string text, string font, int options) => new D3DObj(false);
        public D3DObj MarkCoordsWithIcon(float lat, float lng, float alt, int icon) => new D3DObj(false);
        public D3DObj MarkCoordsWithShape(float lat, float lng, float alt, D3DShape shape, int color) => new D3DObj(false);
        public D3DObj MarkCoordsWithShapeFromFile(float lat, float lng, float alt, string file, int color) => new D3DObj(false);
        public D3DObj MarkCoordsWith2DText(float lat, float lng, float alt, string text, string font, int options) => new D3DObj(false);
        public D3DObj MarkCoordsWith3DText(float lat, float lng, float alt, string text, string font, int options) => new D3DObj(false);
    }

    public class D3DObj : IDisposable
    {
        private readonly bool _arrow;
        internal D3DObj(bool arrow) { _arrow = arrow; }
        private bool _visible = true;
        public bool Visible { get => _visible; set { _visible = value; if (_arrow && !value) Bridge.Host?.ClearArrow?.Invoke(); } }
        public int Color { get; set; }
        public float ScaleX { get; set; } = 1; public float ScaleY { get; set; } = 1;
        public void Scale(float s) { ScaleX = ScaleY = s; }
        public void OrientToCamera(bool b) { }
        public void Anchor(int id, float h, float x, float y, float z) { }
        public void Anchor(float ns, float ew, float z) { }
        public void SetText(D3DTextType type, string text, string font, int opts) { }
        public void SetIcon(int icon) { }
        public void SetIcon(string file) { }
        public void SetShape(D3DShape shape) { }
        public void SetText(string text) { }
        public void SetText(string text, string font) { }
        public void SetText(string text, string font, int options) { }
        public int Color2 { get; set; }
        public bool Autoscale { get; set; }
        public bool DrawBackface { get; set; }
        public float HBounce { get; set; } public float PBounce { get; set; } public float PFade { get; set; } public float POrbit { get; set; }
        public float PSpin { get; set; } public float ROrbit { get; set; } public float ScaleZ { get; set; } = 1; public float AnimationPhaseOffset { get; set; }
        public void OrientToCoords(float lat, float lng, float alt, bool tilt) { }
        public void OrientToObject(int guid, float h, bool tilt) { }
        public void OrientToPlayer(bool tilt) { }
        public void Dispose() { if (_arrow) Bridge.Host?.ClearArrow?.Invoke(); }
    }

}


namespace Decal.Adapter.Wrappers
{
    public class HookIndexer { public int this[AttributeType t] => 0; public int this[int i] => 0; }

    public class ChangeEnchantmentsEventArgs : EventArgs { public EnchantmentWrapper Enchantment { get; set; } public AddRemoveEventType Type { get; set; } }

    public class EnchantmentWrapper : IDisposable
    {
        public double Adjustment { get; set; } public int Affected { get; set; } public int AffectedMask { get; set; } public double Duration { get; set; }
        public int Family { get; set; } public int Layer { get; set; } public int SpellId { get; set; } public int TimeRemaining { get; set; }
        public DateTime Expires => DateTime.Now.AddSeconds(TimeRemaining);
        public void Dispose() { }
    }

    public class Vector4Object
    {
        public Vector4Object(double w, double x, double y, double z) { W = w; X = x; Y = y; Z = z; }
        public double W { get; } public double X { get; } public double Y { get; } public double Z { get; }
    }

    /// <summary>A vendor's window (none: the world on its own has no shops open).</summary>
    public class Vendor : IEnumerable<WorldObject>, IDisposable
    {
        public int MerchantId => 0; public int MaxValue => 0; public float SellRate => 1; public float BuyRate => 1; public int Categories => 0;
        public int Count => 0; public int Quantity => 0; public WorldObject First => null; public WorldObject this[int id] => null;
        public IEnumerator<WorldObject> GetEnumerator() { yield break; }
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
        public void Dispose() { }
    }
}
