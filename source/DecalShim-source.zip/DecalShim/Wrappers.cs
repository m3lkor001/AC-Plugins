using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using ACGodot.DecalShim;
using ACGodot.Objects;
using Godot;
using Item = ACGodot.Combat.Item;

namespace Decal.Adapter.Wrappers
{






    public class CoordsObject
    {
        public CoordsObject(double ns, double ew) { NorthSouth = ns; EastWest = ew; }
        public double NorthSouth { get; }
        public double EastWest { get; }
        public double DistanceToCoords(CoordsObject o) => Math.Sqrt(Math.Pow(o.NorthSouth - NorthSouth, 2) + Math.Pow(o.EastWest - EastWest, 2));
        public override string ToString() => $"{Math.Abs(NorthSouth):0.0}{(NorthSouth >= 0 ? "N" : "S")}, {Math.Abs(EastWest):0.0}{(EastWest >= 0 ? "E" : "W")}";
    }

    public class Vector3Object
    {
        public Vector3Object(double x, double y, double z) { X = x; Y = y; Z = z; }
        public double X { get; } public double Y { get; } public double Z { get; }
    }

    /// <summary>A thing in the world or in your pack, as Decal shows it: a creature, NPC, door, portal, corpse or item.</summary>
    public class WorldObject
    {
        internal readonly object Thing;   // a Selectable, an Item, or the player (null)
        internal WorldObject(object thing, int id) { Thing = thing; Id = id; }

        public int Id { get; }
        private ObjectStreamer.Selectable Sel => Thing as ObjectStreamer.Selectable;
        // the cell it's in: yours is the body's (your Selectable has none - in a room south of its landblock, a dungeon's
        // or an apartment hall, the cell worked out from the place was the next landblock over, and nothing near was "near")
        private uint CellOf => IsPlayer && Bridge.Host?.Player is { } pl && pl.Cell != 0 ? pl.Cell : Sel?.Cell ?? 0;
        private Item It => Thing as Item ?? Sel?.Item as Item;
        public bool IsPlayer => Id == Bridge.PlayerId;

        public string Name => IsPlayer ? CoreManager.Current.CharacterFilter.Name
                            : Sel != null ? (Bridge.IsCorpse(Sel, Id) && !Sel.Name.StartsWith("Corpse of ") ? "Corpse of " + Sel.Name : Sel.Name)
                            : It?.Name ?? "";

        public ObjectClass ObjectClass
        {
            get
            {
                if (IsPlayer) return ObjectClass.Player;
                if (Sel is { } s)
                {
                    // (a corpse first: one the server names otherwise - "Treasure of Frost", killed by misadventure - is
                    // also an item that holds things, and read as a container it was taken for a chest and opened over and over)
                    if (s.Corpse) return ObjectClass.Corpse;
                    if (s.Item is Item gi) return ClassOf(gi);
                    if (s.Kind >= 3) return ObjectClass.Player;   // (another player on the server)
                    if (s.Type == 7) return ObjectClass.Portal;
                    if (s.Type == 19) return ObjectClass.Door;
                    if (s.Type == 22) return ObjectClass.Lifestone;
                    if (s.Corpse) return ObjectClass.Corpse;   // (a server's corpse: a thing of its own)
                    // a chest or crate in the world (a Chest / Container, or one the server calls a container): looted and
                    // checked as chests are - it was "something else", and the looter never went to it
                    if (s.Type is 20 or 21 || (Bridge.Online && ((Bridge.Host?.Net?.ItemTypeOf(s.Guid) ?? 0) & 0x200) != 0)) return ObjectClass.Container;
                    // (on a server what's left of the creature that died isn't the corpse - the server makes that - and goes in a moment)
                    if (s.Fight is ACGodot.Combat.Fighter { St: ACGodot.Combat.Fighter.State.Dead }) return Bridge.Online ? ObjectClass.Misc : ObjectClass.Corpse;
                    if (s.Kind == 2) return ObjectClass.Monster;
                    if (s.Kind == 1) return s.Type == 12 ? ObjectClass.Vendor : ObjectClass.Npc;
                    // (a creature you can't fight - a statue that speaks, a guardian, a forge: the game counts it an NPC)
                    if ((s.Type == 10 || s.Type == 12) && Bridge.Host?.Net?.IsPet(s) != true) return s.Type == 12 ? ObjectClass.Vendor : ObjectClass.Npc;
                    return ObjectClass.Misc;
                }
                return It != null ? ClassOf(It) : ObjectClass.Unknown;
            }
        }

        private static ObjectClass ClassOf(Item i)
        {
            if (i.IsCoins) return ObjectClass.Money;
            if (i.Capacity > 0) return ObjectClass.Container;   // (a pack, a sack, a focus)
            if ((i.ItemType & 0x40000000) != 0) return ObjectClass.Salvage;
            if (i.MaxUses > 0) return i.Name.Contains("Lockpick", StringComparison.OrdinalIgnoreCase) ? ObjectClass.Lockpick : ObjectClass.HealingKit;
            // (holding mana doesn't make a mana stone: every enchanted wand, weapon and piece of armor holds some - only a
            // thing of no other kind that does, or one the server calls a mana stone)
            if (i.MaxMana > 0 && (i.ItemType & ~0x80000) == 0) return ObjectClass.ManaStone;
            int t = i.ItemType;
            if ((t & 1) != 0) return ObjectClass.MeleeWeapon;
            if ((t & 2) != 0) return ObjectClass.Armor;
            if ((t & 4) != 0) return ObjectClass.Clothing;
            if ((t & 8) != 0) return ObjectClass.Jewelry;
            if ((t & 0x20) != 0) return ObjectClass.Food;
            if ((t & 0x100) != 0) return ObjectClass.MissileWeapon;
            if ((t & 0x200) != 0) return ObjectClass.Container;
            if ((t & 0x800) != 0) return ObjectClass.Gem;
            if ((t & 0x1000) != 0) return ObjectClass.SpellComponent;
            if ((t & 0x2000) != 0) return ObjectClass.Book;
            if ((t & 0x4000) != 0) return ObjectClass.Key;
            if ((t & 0x8000) != 0) return ObjectClass.WandStaffOrb;
            if ((t & 0x40000) != 0) return ObjectClass.Ust;
            if ((t & 0x80000) != 0) return ObjectClass.ManaStone;
            if ((t & 0x40000000) != 0) return ObjectClass.Salvage;
            return ObjectClass.Misc;
        }

        public int Type => Sel?.Wcid ?? It?.Wcid ?? 0;
        public int Icon => (int)(It?.Icon ?? 0);
        public int Category => 0;
        public int Behavior => 0;
        /// <summary>Where it is: your pack (you), the open corpse, or the world (0).</summary>
        public int Container
        {
            get
            {
                if (It == null || Sel != null) return 0;
                var h = Bridge.Host;
                if (h == null) return 0;
                // (in a side pack: that pack, as Decal has it - what's in the main pack, worn, or a side pack itself: you)
                if (It.Holder != 0 && h.Inv.Pack.Contains(It) && h.Inv.SidePacks.FirstOrDefault(p => p.Guid == It.Holder) is { } inPack) return Bridge.IdOf(inPack);
                if (h.Inv.Pack.Contains(It) || h.Inv.Worn.Contains(It) || h.Inv.SidePacks.Contains(It)) return Bridge.PlayerId;
                if (h.Combat.OpenedCorpse is { } c && h.Combat.CorpseContents(c)?.Contains(It) == true) return Bridge.IdOf(c);
                // (in the corpse or chest open on a server)
                if (Bridge.Online && It.Guid != 0 && h.Net.OpenContainer != 0 && h.Net.OpenContents().Contains(It)) return Bridge.OpenContainerId();
                return 0;
            }
        }
        /// <summary>A server's item: once it's been looked at closely (its details told). Anything else: always.</summary>
        public bool HasIdData => It == null || It.Guid == 0 || It.PropInts != null;
        public int GameDataFlags1 => 0;
        public int LastIdTime => 0;
        public int Values(LongValueKey k) => Values(k, 0);
        public int SpellCount => It?.Spells.Count ?? 0;
        public int ActiveSpellCount => It != null && It.WornAt != 0 ? It.Spells.Count : 0;
        public int Spell(int i) => It != null && i >= 0 && i < It.Spells.Count ? It.Spells[i] : 0;
        public int ActiveSpell(int i) => ActiveSpellCount > i ? Spell(i) : 0;
        // (what it has a value for: the basics, and - once looked at closely - every property the server told of it,
        // under the game's own property numbers, as Decal has them)
        public List<int> LongKeys
        {
            get
            {
                var l = new List<int> { (int)LongValueKey.Value, (int)LongValueKey.Burden };
                if (It?.PropInts is { } pi) foreach (int k in pi.Keys) if (!l.Contains(k)) l.Add(k);
                return l;
            }
        }
        public List<int> StringKeys
        {
            get
            {
                var l = new List<int> { (int)StringValueKey.Name };
                if (It?.PropStrings is { } ps) foreach (int k in ps.Keys) if (!l.Contains(k)) l.Add(k);
                return l;
            }
        }
        public List<int> DoubleKeys => It?.PropFloats is { } pf ? new List<int>(pf.Keys) : new();
        public List<int> BoolKeys => It?.PropBools is { } pb ? new List<int>(pb.Keys) : new();
        public Vector4Object Orientation() => new Vector4Object(1, 0, 0, 0);

        public int Values(LongValueKey k, int dflt)
        {
            var it = It;
            switch (k)
            {
                case LongValueKey.Slot:   // its place in the pack it's in (counted among what else is in that pack)
                {
                    var hs = Bridge.Host;
                    if (it == null || hs == null) return dflt;
                    int n = 0;
                    foreach (var o in hs.Inv.Pack) { if (ReferenceEquals(o, it)) return n; if (o.Holder == it.Holder) n++; }
                    int sp = hs.Inv.SidePacks.IndexOf(it);
                    return sp >= 0 ? sp : dflt;
                }
                case (LongValueKey)218103812: return it != null && it.Capacity > 0 ? it.Capacity : dflt;   // ItemSlots
                case LongValueKey.Material: return it != null && it.Material != 0 ? it.Material : dflt;
                case LongValueKey.StackCount: return it != null ? Math.Max(1, it.Stack) : dflt;
                case LongValueKey.StackMax: return it?.MaxStack ?? dflt;
                case LongValueKey.Value: return it?.Value ?? dflt;
                case LongValueKey.Burden: return it?.Burden ?? dflt;
                case LongValueKey.Icon: return (int)(it?.Icon ?? 0);
                case LongValueKey.EquippedSlots: return it?.WornAt ?? 0;
                case LongValueKey.Wielder:   // (worn or wielded: you)
                {
                    var h = Bridge.Host;
                    return it != null && Sel == null && h != null && h.Inv.Worn.Contains(it) ? Bridge.PlayerId : 0;
                }
                case LongValueKey.EquipableSlots: return it?.Locations ?? 0;
                case LongValueKey.MissileType: return it != null && it.AmmoType != 0 ? it.AmmoType : dflt;   // (a bow and its arrows share it: how a plugin finds the ammunition for the weapon)
                case LongValueKey.ArmorLevel: return it?.ArmorLevel ?? dflt;
                case LongValueKey.MaxDamage: return it?.Damage ?? dflt;
                case LongValueKey.UsesRemaining: return it != null && it.MaxUses > 0 ? it.Uses : dflt;
                case LongValueKey.UsesTotal: return it != null && it.MaxUses > 0 ? it.MaxUses : dflt;
                case LongValueKey.CurrentMana: return it != null && it.MaxMana > 0 ? it.Mana : dflt;
                case LongValueKey.MaximumMana: return it != null && it.MaxMana > 0 ? it.MaxMana : dflt;
                case LongValueKey.Container: return Container;
                case LongValueKey.Landblock:
                {
                    var pos = Position;
                    if (pos == null) return dflt;
                    return unchecked((int)Bridge.Place(pos.Value, CellOf).cell);
                }
                case LongValueKey.CreatureLevel:
                    if (IsPlayer) return CoreManager.Current.CharacterFilter.Level;
                    // (someone or something looked at closely: the level the server gave - another player's fighter here
                    // only has a stand-in level of 1)
                    if (Sel?.PropInts is { } spi && spi.TryGetValue(25, out int slv) && slv > 0) return slv;
                    if (Sel?.Fight is ACGodot.Combat.Fighter f && f.W.Level > 0) return f.W.Level;
                    return dflt;
                case LongValueKey.Species: return dflt;
                case LongValueKey.Heritage: return IsPlayer ? 1 : dflt;
                case LongValueKey.Type: return Type;
                case LongValueKey.WeapSpeed: return it != null && it.WeaponTime != 0 ? it.WeaponTime : dflt;
                case LongValueKey.EquipSkill: return it != null && it.WeaponSkill != 0 ? it.WeaponSkill : dflt;
                case LongValueKey.DamageType: return it != null && it.DamageType != 0 ? it.DamageType : dflt;
                case LongValueKey.SpellCount: return it?.Spells.Count ?? dflt;
                case LongValueKey.ActiveSpellCount: return ActiveSpellCount;
                // (anything else: as the server told it when the item was looked at closely - Decal's keys below its own
                // made-up ones are the game's property numbers)
                default:
                {
                    // (an item's; a creature's or person's; your own)
                    var told = it?.PropInts ?? (IsPlayer ? Bridge.Host?.Net?.SelfInts ?? Bridge.Host?.Net?.Character?.Ints : Sel?.PropInts);
                    return told != null && (int)k >= 0 && (int)k < 0x0A000000 && told.TryGetValue((int)k, out int pv) ? pv : dflt;
                }
            }
        }

        public string Values(StringValueKey k) => Values(k, "");
        public string Values(StringValueKey k, string dflt)
        {
            if (k == StringValueKey.Name) return Name;
            if (It?.PropStrings != null && (int)k >= 0 && (int)k < 0x0A000000 && It.PropStrings.TryGetValue((int)k, out var told)) return told;
            // (the server's appraisal of something in the world that isn't an item here - a corpse: "Killed by ...")
            if (Sel?.PropStrings != null && (int)k >= 0 && (int)k < 0x0A000000 && Sel.PropStrings.TryGetValue((int)k, out var toldW)) return toldW;
            // a corpse's appraisal: who killed it (the world on its own: only you kill things). Not on a server: there
            // the server says, and a corpse not appraised yet was called yours - another player's corpse, or one
            // "killed by misadventure", was then opened and looted
            if (k == StringValueKey.FullDescription && !Bridge.Online && ObjectClass == ObjectClass.Corpse && Sel != null)
                return "Killed by " + CoreManager.Current.CharacterFilter.Name + ".";
            return dflt;
        }
        public double Values(DoubleValueKey k) => Values(k, 0.0);
        public double Values(DoubleValueKey k, double dflt)
        {
            if (k == DoubleValueKey.Heading && Sel != null) return 0;
            var it = It;
            if (it == null)
            {
                var toldF = IsPlayer ? Bridge.Host?.Net?.SelfFloats : Sel?.PropFloats;
                return toldF != null && (int)k >= 0 && (int)k < 0x0A000000 && toldF.TryGetValue((int)k, out double tf) ? tf : dflt;
            }
            // armor's protections (the server's order: slash, pierce, bludgeon, cold, fire, acid, nether, lightning)
            int prot = k switch { DoubleValueKey.SlashProt => 0, DoubleValueKey.PierceProt => 1, DoubleValueKey.BludgeonProt => 2, DoubleValueKey.ColdProt => 3,
                                  DoubleValueKey.FireProt => 4, DoubleValueKey.AcidProt => 5, DoubleValueKey.LightningProt => 7, _ => -1 };
            if (prot >= 0) return it.Prots != null ? it.Prots[prot] : dflt;
            switch (k)
            {
                case DoubleValueKey.Variance: return it.PropInts != null || it.Variance != 0 ? it.Variance : dflt;
                case DoubleValueKey.AttackBonus: return it.WeaponOffense != 0 ? it.WeaponOffense : dflt;
                case DoubleValueKey.DamageBonus: return it.DamageMod != 0 ? it.DamageMod : dflt;
                case DoubleValueKey.Range: return it.MaxVelocity != 0 ? it.MaxVelocity : dflt;
                case DoubleValueKey.SalvageWorkmanship: return it.PropInts != null && it.PropInts.TryGetValue(105, out int w) ? w : dflt;
            }
            return it.PropFloats != null && (int)k >= 0 && (int)k < 0x0A000000 && it.PropFloats.TryGetValue((int)k, out double fv) ? fv : dflt;
        }
        public bool Values(BoolValueKey k) => Values(k, false);
        public bool Values(BoolValueKey k, bool dflt)
        {
            if (k == BoolValueKey.Open && Sel != null) return Sel.Open;
            return It?.PropBools != null && (int)k >= 0 && (int)k < 0x0A000000 && It.PropBools.TryGetValue((int)k, out bool bv) ? bv : dflt;
        }

        internal Vector3? Position
        {
            get
            {
                if (IsPlayer) return Bridge.Host?.Player?.Position;
                if (Sel != null) return Sel.Feet;
                return It != null ? Bridge.Host?.Player?.Position : null;   // in your pack: where you are
            }
        }

        public CoordsObject Coordinates()
        {
            var p = Position;
            if (p == null) return null;
            var (ns, ew) = Bridge.Coords(p.Value);
            return new CoordsObject(ns, ew);
        }

        public Vector3Object RawCoordinates()
        {
            var p = Position;
            if (p == null) return new Vector3Object(0, 0, 0);
            var (_, x, y, z) = Bridge.Place(p.Value, CellOf);
            return new Vector3Object(x, y, z);
        }

        public double Distance(WorldObject o)
        {
            var a = Position; var b = o?.Position;
            return a == null || b == null ? double.MaxValue : a.Value.DistanceTo(b.Value) / 240.0;
        }

        public override bool Equals(object obj) => obj is WorldObject w && w.Id == Id;
        public override int GetHashCode() => Id;
    }

    public class WorldObjectCollection : IEnumerable<WorldObject>
    {
        private readonly List<WorldObject> _l;
        public WorldObjectCollection(IEnumerable<WorldObject> l) { _l = l.ToList(); }
        public int Count => _l.Count;
        public int Quantity => _l.Count;
        public WorldObject First => _l.FirstOrDefault();
        public WorldObject this[int i] => _l[i];
        public IEnumerator<WorldObject> GetEnumerator() => _l.GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => _l.GetEnumerator();
        public void SetFilter(object f) { }
        public void Dispose() { }
    }

    public class CreateObjectEventArgs : EventArgs { public CreateObjectEventArgs(WorldObject o) { New = o; } public WorldObject New { get; } }
    public class ChangeObjectEventArgs : EventArgs { public ChangeObjectEventArgs(WorldObject o, WorldChangeType change = WorldChangeType.IdentReceived) { Changed = o; Change = change; } public WorldObject Changed { get; } public WorldChangeType Change { get; } }
    public class ReleaseObjectEventArgs : EventArgs { public ReleaseObjectEventArgs(WorldObject o) { Released = o; } public WorldObject Released { get; } }
    public class MoveObjectEventArgs : EventArgs { public MoveObjectEventArgs(WorldObject o) { Moved = o; } public WorldObject Moved { get; } }

    /// <summary>Everything Decal knows about: what's around you and what you carry.</summary>
    public class WorldFilter
    {
        public event EventHandler<CreateObjectEventArgs> CreateObject;
        public event EventHandler<ChangeObjectEventArgs> ChangeObject;
        public event EventHandler<ReleaseObjectEventArgs> ReleaseObject;
        public event EventHandler<MoveObjectEventArgs> MoveObject;

        private static readonly Dictionary<int, WorldObject> _wrapped = new();

        internal static WorldObject Wrap(object thing)
        {
            if (thing == null) return null;
            int id = Bridge.IdOf(thing);
            if (!_wrapped.TryGetValue(id, out var w)) _wrapped[id] = w = new WorldObject(thing, id);
            return w;
        }

        private static WorldObject _me;
        internal static WorldObject Me => _me ??= new WorldObject(null, Bridge.PlayerId);

        public WorldObject this[int id]
        {
            get
            {
                if (id == Bridge.PlayerId) return Me;
                if (_wrapped.TryGetValue(id, out var w)) return Alive(w) ? w : null;
                var t = Bridge.ThingOf(id);
                if (t is ObjectStreamer.Selectable s && Bridge.Host?.Objects?.IsHere(s) == false) return null;
                return t != null ? Wrap(t) : null;
            }
        }

        private static bool Alive(WorldObject w)
        {
            if (w.Thing is ObjectStreamer.Selectable s) return !s.Gone && Bridge.IdOf(s) == w.Id && Bridge.Host?.Objects?.IsHere(s) != false;   // (another dungeon's: not here)   // (a monster's id ends at its death: the corpse has its own)
            if (w.Thing is Item i) { var h = Bridge.Host; return h == null || h.Inv.Pack.Contains(i) || h.Inv.Worn.Contains(i) || true; }
            return true;
        }

        private static IEnumerable<ObjectStreamer.Selectable> Around()
        {
            var h = Bridge.Host;
            if (h?.Objects == null) yield break;
            foreach (var s in h.Objects.AllSelectables) if (!s.Gone) yield return s;
        }

        public Vendor OpenVendor => Bridge.Online && Bridge.Host.Net.OpenVendorInfo is { } v ? new Vendor(v) : null;
        public WorldObjectCollection GetLandscape() => new(Around().Select(Wrap).Prepend(Me));
        public WorldObjectCollection GetAll() => new(Around().Select(Wrap).Concat(Inventory()).Prepend(Me));
        public WorldObjectCollection GetInventory() => new(Inventory());
        public WorldObjectCollection GetByObjectClass(ObjectClass c) => new(GetAll().Where(o => o.ObjectClass == c));
        public WorldObjectCollection GetByName(string n) => new(GetAll().Where(o => string.Equals(o.Name, n, StringComparison.OrdinalIgnoreCase)));
        public WorldObjectCollection GetByNameSubstring(string n) => new(GetAll().Where(o => o.Name.IndexOf(n, StringComparison.OrdinalIgnoreCase) >= 0));
        public WorldObjectCollection GetByContainer(int id)
        {
            // (yours: what's on you and in the main pack, and the side packs themselves; a side pack's: what's in it)
            if (id == Bridge.PlayerId && Bridge.Host?.Combat != null)
            {
                var inv = Bridge.Host.Inv;
                return new(inv.Worn.ToList().Concat(inv.Pack.Where(i => i.Holder == 0).ToList()).Concat(inv.SidePacks.ToList()).Select(Wrap));
            }
            if (id == Bridge.PlayerId) return GetInventory();
            if (Bridge.ThingOf(id) is Item sidePack && sidePack.Guid != 0 && Bridge.Host?.Inv.SidePacks.Contains(sidePack) == true)
                return new(Bridge.Host.Inv.Pack.Where(i => i.Holder == sidePack.Guid).ToList().Select(Wrap));
            // a pack inside the open chest (a house's storage bags): what's in it, as the server listed it with the chest
            if (Bridge.Online && Bridge.ThingOf(id) is Item inBox && inBox.Guid != 0 && Bridge.Host?.Inv.SidePacks.Contains(inBox) != true)
            {
                var inside = Bridge.Host.Net.ContentsOf(inBox.Guid);
                if (inside.Count > 0) return new(inside.Select(Wrap));
            }
            // a corpse: what's in it
            // (a server's: the one that's open, as the server listed it)
            if (Bridge.Online && id != 0 && id == Bridge.OpenContainerId()) return new(Bridge.Host.Net.OpenContents().Select(Wrap));
            if (Bridge.ThingOf(id) is ObjectStreamer.Selectable s && Bridge.Host?.Combat?.CorpseContents(s) is { } loot)
                return new(loot.ToList().Select(Wrap));
            return new(Enumerable.Empty<WorldObject>());
        }

        private static IEnumerable<WorldObject> Inventory()
        {
            var h = Bridge.Host;
            if (h?.Combat == null) yield break;
            foreach (var i in h.Inv.Worn.ToList()) yield return Wrap(i);
            foreach (var i in h.Inv.Pack.ToList()) yield return Wrap(i);
            foreach (var i in h.Inv.SidePacks.ToList()) yield return Wrap(i);
        }

        public double Distance(int a, int b)
        {
            var wa = this[a]; var wb = this[b];
            return wa == null || wb == null ? double.MaxValue : wa.Distance(wb);
        }

        // what's come into view since the last look: CreateObject for each (a second at a time)
        private static readonly HashSet<int> _seen = new();
        private static double _lookIn;

        // the pack changed (picked up, dropped, stacked, split, worn...): Decal's "storage change", so plugins' inventory
        // lists start again at once (MelkTank's stacker waits for one)
        private static int _invSig;
        private static void InvWatch()
        {
            var h = Bridge.Host;
            if (h?.Combat == null) return;
            int sig = 17;
            foreach (var i in h.Inv.Pack) sig = sig * 31 + System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode(i) * 7 + i.Stack;
            foreach (var i in h.Inv.Worn) sig = sig * 31 + System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode(i) + 1;
            if (sig == _invSig) return;
            _invSig = sig;
            var wf = CoreManager.Current.WorldFilter;
            try { wf.ChangeObject?.Invoke(wf, new ChangeObjectEventArgs(Me, WorldChangeType.StorageChange)); } catch (Exception ex) { GD.PushWarning("plugin inventory: " + ex.Message); }
        }

        internal static void Track()
        {
            FlushIds();
            InvWatch();
            // (every frame: a thing gone - a monster dead, its id the corpse's from then on - is told the frame it goes)
            var wf = CoreManager.Current.WorldFilter;
            var now = new HashSet<int>();
            foreach (var s in Around())
            {
                var w = Wrap(s);
                now.Add(w.Id);
                if (_seen.Add(w.Id)) { var ce = new CreateObjectEventArgs(w); Hitch.Each(wf.CreateObject, "create object", h => ((EventHandler<CreateObjectEventArgs>)h)(wf, ce)); }
            }
            foreach (var id in _seen.Where(i => !now.Contains(i)).ToList())
            {
                _seen.Remove(id);
                if (_wrapped.TryGetValue(id, out var w)) { try { wf.ReleaseObject?.Invoke(wf, new ReleaseObjectEventArgs(w)); } catch { } }
            }
        }

        internal void RaiseChanged(WorldObject w) { var e = new ChangeObjectEventArgs(w); Hitch.Each(ChangeObject, "change object", h => ((EventHandler<ChangeObjectEventArgs>)h)(this, e)); }

        // IDs answered on the next frame
        private static readonly List<int> _idsDue = new();
        internal void RaiseChangedSoon(int id) { lock (_idsDue) if (!_idsDue.Contains(id)) _idsDue.Add(id); }
        internal static void FlushIds()
        {
            int[] due;
            lock (_idsDue) { if (_idsDue.Count == 0) return; due = _idsDue.ToArray(); _idsDue.Clear(); }
            var wf = CoreManager.Current.WorldFilter;
            foreach (int id in due) { var w = wf[id]; if (w != null) wf.RaiseChanged(w); }
        }
    }

    public class LogoffEventArgs : EventArgs { public LogoffEventType Type { get; set; } }
    public class ChangePortalModeEventArgs : EventArgs { public ChangePortalModeEventArgs(PortalEventType t) { Type = t; } public PortalEventType Type { get; } }
    public class LoginEventArgs : EventArgs { public int Id { get; set; } }
    public class ChangeVitalEventArgs : EventArgs { public int Type { get; set; } public int Amount { get; set; } }
    public class SpellCastEventArgs : EventArgs { public int SpellId { get; set; } public int TargetId { get; set; } }



    public class SkillInfoWrapper
    {
        public SkillInfoWrapper(int id) { Id = id; }
        public int Id { get; }
        private ACGodot.Combat.Character Me => Bridge.Host?.Me;
        public int Current => Me?.Skill(Id) ?? 0;
        public int Base => Me?.Skill(Id) ?? 0;
        public int Buffed => Current;
        public TrainingType Training => Me == null ? TrainingType.Untrained : Me.TrainingOf(Id) switch
        {
            ACGodot.Combat.Character.Training.Specialized => TrainingType.Specialized, ACGodot.Combat.Character.Training.Trained => TrainingType.Trained,
            _ => TrainingType.Untrained,
        };
        public string Name => Me?.AllSkills().FirstOrDefault(s => s.id == Id).name ?? "";
    }

    public class AttributeInfoWrapper
    {
        public AttributeInfoWrapper(int i) { _i = i; }
        private readonly int _i;
        public int Current => Bridge.Host?.Me?.Attribute(_i) ?? 0;
        public int Base => Current;
        public int Buffed => Current;
    }

    public class VitalInfoWrapper
    {
        public VitalInfoWrapper(int i) { _i = i; }
        private readonly int _i;
        public int Current => Bridge.Host?.Combat == null ? 0 : _i switch { 0 => Bridge.Host.Combat.Health, 1 => Bridge.Host.Me.Stamina, _ => Bridge.Host.Me.Mana };
        public int Base => Buffed;
        public int Buffed => Bridge.Host?.Me == null ? 0 : _i switch { 0 => Bridge.Host.Me.MaxHealth, 1 => Bridge.Host.Me.MaxStamina, _ => Bridge.Host.Me.MaxMana };
    }

    /// <summary>Your character, as Decal shows it.</summary>
    public class CharacterFilter
    {
        public event EventHandler LoginComplete;
        public event EventHandler<LogoffEventArgs> Logoff;
        public event EventHandler<ChangePortalModeEventArgs> ChangePortalMode;
        public event EventHandler<LoginEventArgs> Login;
        public event EventHandler<ChangeVitalEventArgs> ChangeVital;
        public event EventHandler<SpellCastEventArgs> SpellCast;
        public event EventHandler ChangeExperience, ChangeFellowship, ChangeEnchantments, ActionComplete;
        public event EventHandler<DeathEventArgs> Death;
        // every character on the account (as the server listed them at the character screen), as Decal gives them
        public IEnumerable<AccountCharInfo> Characters
        {
            get
            {
                var all = Bridge.Host?.AccountCharacters?.Invoke();
                if (all == null || all.Count == 0) return new[] { new AccountCharInfo { Id = Bridge.PlayerId, Name = Name } };
                var list = new List<AccountCharInfo>();
                foreach (var (id, name) in all) list.Add(new AccountCharInfo { Id = (int)id, Name = name });
                return list;
            }
        }

        internal void RaiseLogin() => LoginComplete?.Invoke(this, EventArgs.Empty);
        internal void RaisePortal(PortalEventType t) { try { ChangePortalMode?.Invoke(this, new ChangePortalModeEventArgs(t)); } catch (Exception ex) { GD.PushWarning("plugin portal: " + ex.Message); } }
        public void RaiseLogoff() => Logoff?.Invoke(this, new LogoffEventArgs());

        public int Id => Bridge.PlayerId;
        public string Name => Bridge.Host?.Me?.Name ?? "";
        public string Server => string.IsNullOrEmpty(Bridge.Host?.ServerName) ? "ACGodot" : Bridge.Host.ServerName;
        public string AccountName => Bridge.Host?.Account ?? "";
        public int Level => Bridge.Host?.Me?.Level ?? 1;
        public int LoginStatus => Bridge.LoginStatus;
        public long TotalXP => Bridge.Host?.Me?.TotalXp ?? 0;
        public long UnassignedXP => Bridge.Host?.Me?.UnassignedXp ?? 0;
        public int Burden => Bridge.Host?.Inv.TotalBurden ?? 0;
        public int Health => Bridge.Host?.Combat?.Health ?? 0;
        public int Stamina => Bridge.Host?.Me?.Stamina ?? 0;
        public int Mana => Bridge.Host?.Me?.Mana ?? 0;
        public int Vitae => (int)Math.Round((1f - (Bridge.Host?.Me?.Vitae ?? 1f)) * 100);
        public int Monarch => 0;
        public string Race => "Aluvian";
        public string Gender => "Male";
        public SkillsIndexer Skills { get; } = new();
        public AttributesIndexer Attributes { get; } = new();
        public VitalsIndexer Vitals { get; } = new();
        public System.Collections.ObjectModel.ReadOnlyCollection<int> SpellBook => new((Bridge.Host?.Magic?.Known().Select(s => s.Id) ?? Enumerable.Empty<int>()).ToList());
        public int SkillPoints => Bridge.Host?.Me?.SkillCredits ?? 0;
        /// <summary>One of the character's own numbers (enlightenment, augmentations...), as the server last said.</summary>
        public int GetCharProperty(int key) => Bridge.Online && Bridge.Host.Net.SelfInts is { } si && si.TryGetValue(key, out int cv) ? cv : 0;
        public EffectiveIndexer<CharFilterVitalType> EffectiveVital { get; } = new(t => t switch
        {
            CharFilterVitalType.Health => Bridge.Host?.Me?.MaxHealth ?? 0, CharFilterVitalType.Stamina => Bridge.Host?.Me?.MaxStamina ?? 0, _ => Bridge.Host?.Me?.MaxMana ?? 0,
        });
        public EffectiveIndexer<CharFilterSkillType> EffectiveSkill { get; } = new(t => Bridge.Host?.Me?.Skill((int)t) ?? 0);
        public EffectiveIndexer<CharFilterAttributeType> EffectiveAttribute { get; } = new(t => Bridge.Host?.Me?.Attribute((int)t - 1) ?? 0);
        public class EffectiveIndexer<T> { private readonly Func<T, int> _f; public EffectiveIndexer(Func<T, int> f) { _f = f; } public int this[T t] => _f(t); }
        public bool IsSpellKnown(int id) => Bridge.Host?.Magic?.Known().Any(s => s.Id == id) == true;
        /// <summary>The spells on you, as the game has them (what's left of each in seconds; -1: while its item is worn).</summary>
        public IEnumerable<EnchantmentWrapper> Enchantments
        {
            get
            {
                var m = Bridge.Host?.Magic;
                if (m == null) return Enumerable.Empty<EnchantmentWrapper>();
                return m.Active().Select(a => new EnchantmentWrapper { SpellId = a.spell.Id, Layer = 1, Family = (int)a.spell.Category,
                    TimeRemaining = a.left < 0 ? -1 : (int)a.left, Duration = a.left < 0 ? -1 : a.left, Adjustment = a.amount }).ToList();
            }
        }
        internal void RaiseEnchantment(int spell, double left, bool on)
        {
            var ew = new EnchantmentWrapper { SpellId = spell, Layer = 1, TimeRemaining = left < 0 ? -1 : (int)left, Duration = left };
            try { ChangeEnchantments?.Invoke(this, new ChangeEnchantmentsEventArgs { Enchantment = ew, Type = on ? AddRemoveEventType.Add : AddRemoveEventType.Delete }); }
            catch (Exception ex) { GD.PushWarning("plugin enchantment: " + ex.Message); }
        }

        public class SkillsIndexer { public SkillInfoWrapper this[CharFilterSkillType t] => new((int)t); }
        public class AttributesIndexer { public AttributeInfoWrapper this[CharFilterAttributeType t] => new((int)t - 1); }
        public class VitalsIndexer { public VitalInfoWrapper this[CharFilterVitalType t] => new(t == CharFilterVitalType.Health ? 0 : t == CharFilterVitalType.Stamina ? 1 : 2); }
    }

    /// <summary>Doing things: chat text, using and selecting things, casting, where you are.</summary>
    public class HooksWrapper
    {
        private static ACGodot.Plugins.PluginHost H => Bridge.Host;

        public void AddChatText(string text, int color) => Bridge.Say(text, color);
        public void AddChatText(string text, int color, int target) => Bridge.Say(text, color);
        public void AddChatTextRaw(string text, int color, int target) => Bridge.Say(text, color);
        public void AddChatTextRaw(string text, int color) => Bridge.Say(text, color);
        public void AddStatusText(string text) => Bridge.Say(text, 5);
        /// <summary>A command as if typed: the plugins first, then the game - quietly (a server command the world on its own
        /// doesn't have isn't "Unknown command" in chat).</summary>
        public void InvokeChatParser(string text)
        {
            if (H == null || string.IsNullOrEmpty(text)) return;
            if (text.StartsWith("/") || text.StartsWith("@")) { if (CoreManager.Current.RaiseCommand(text)) return; }
            H.Quietly(text);
        }

        public int CurrentSelection
        {
            get => (DateTime.Now - Bridge.SelfIdAt).TotalSeconds < 3 ? Bridge.PlayerId   // just identified yourself: you, for a moment
                 : H?.PickedItem?.Invoke() is { } it ? Bridge.IdOf(it) : H?.Objects?.Selected is { } s ? Bridge.IdOf(s) : 0;
            set => SelectItem(value);
        }
        public int PreviousSelection => 0;
        public void SelectItem(int id)
        {
            var t = Bridge.ThingOf(id);
            if (t is ObjectStreamer.Selectable s) H?.Select(s);
            else if (t is Item i) H?.PickItem?.Invoke(i);
        }

        public void UseItem(int id, int how) => UseItem(id, how, 0);
        public void UseItem(int id, int how, int target)
        {
            var t = Bridge.ThingOf(id);
            if (t is ObjectStreamer.Selectable s) { H?.Use?.Invoke(s); return; }
            if (t is not Item i || H == null) return;
            if (i.Name == "Ust") LastUst = i;
            if (Bridge.Online && i.Guid != 0)
            {
                // on something: the target given, or (Decal's "use on the selection") what's selected - asked of the server
                // at once, nothing chosen or opened in the game
                // (a target given that isn't known here by its id: a server's number is its own guid - never the selection instead,
                // which put a breeding incense on whatever essence was picked in the pack)
                uint on = target != 0 ? Bridge.GuidOf(target) : how == 1 ? Bridge.GuidOf(CurrentSelection) : 0;
                if (target != 0 && on == 0)
                {
                    if (unchecked((uint)target) >= 0x80000000u) { H.Net.UseOn(i, unchecked((uint)target)); }
                    return;
                }
                // something the game uses on its own (a siphon lens: no target to choose - Useable's target half 0): the
                // server goes by the selection, so the server is told of it (a health ask is how it hears of it) and the
                // item plainly used; used "on" it instead, the server takes it for a trade skill
                // (a target given: only the server's idea of the selection changes - what you have selected here is
                // left alone, so a corpse or an item you're looting isn't taken off you)
                if (on != 0 && on != i.Guid && !i.NeedsTarget && Bridge.ThingOf(target != 0 ? target : CurrentSelection) is ObjectStreamer.Selectable onThing)
                {
                    if (target == 0) H?.Select(onThing);
                    H.Net.QueryHealth(on);
                    H.Net.UseItem(i);
                    return;
                }
                if (on != 0 && on != i.Guid) { H.Net.UseOn(i, on); return; }
            }
            H.UseItem?.Invoke(i);
        }
        public void ApplyItem(int item, int target) => UseItem(item, 1, target);
        /// <summary>Asks for an ID: it "comes back" on the next frame (as from the server - never inside the asking call).</summary>
        public void RequestId(int id)
        {
            // on a server: asked of it (quietly - nothing chosen, no panel); the ID "comes back" when it answers
            uint g = Bridge.Online ? Bridge.GuidOf(id) : 0;
            if (g != 0) { H.Net.Appraise(g); return; }
            CoreManager.Current.WorldFilter.RaiseChangedSoon(id);
        }

        public void CastSpell(int spellId, int target)
        {
            if (H?.Magic == null) return;
            // at the target given (the game casts at what's selected): chosen first - you yourself, or a thing in the world
            // on a server the cast names its target itself: what you have selected is left alone (magic needs no selection)
            if (H.Magic.NetCast != null)
            {
                ObjectStreamer.Selectable? at = target == Bridge.PlayerId ? H.Objects.Self : target != 0 ? Bridge.ThingOf(target) as ObjectStreamer.Selectable : null;
                // (not a thing in the world - an item in your packs, a bane going on your shield: cast at it by its id, so
                // what's selected - a monster, or a look through your packs - doesn't decide where it goes)
                H.Magic.CastAtGuid = at == null && target != 0 && target != Bridge.PlayerId ? (uint)target : 0;
                H.Magic.Cast(spellId, quiet: true, at: at);
                H.Magic.CastAtGuid = 0;
                return;
            }
            if (target == Bridge.PlayerId) { if (H.Objects.Selected != H.Objects.Self) H.Select(H.Objects.Self); }
            else if (target != 0 && Bridge.ThingOf(target) is ObjectStreamer.Selectable s && H.Objects.Selected != s) H.Select(s);
            H.Magic.Cast(spellId, quiet: true);
        }
        public CombatState CombatMode => H?.Combat == null ? CombatState.Peace : !H.Combat.CombatMode ? CombatState.Peace : H.Combat.MagicMode ? CombatState.Magic
                               : H.Inv.Weapon is { IsMissileWeapon: true } ? CombatState.Missile : CombatState.Melee;
        public void SetCombatMode(CombatState s) => H?.SetCombat(s != CombatState.Peace);
        public void SetAutorun(bool on) { if (H?.Player == null) return; H.AutoRun = on; if (!on) H.MoveTo(null); }
        /// <summary>Busy as the game client was: an item asked to move / be used not yet answered by the server, or bending down for something.</summary>
        public int BusyState => Bridge.Online && (H.Net.ItemPending || H.Player?.Bending == true) ? 1 : 0;
        public int OpenedContainer => Bridge.Online ? Bridge.OpenContainerId() : Bridge.IdOf(Bridge.Host?.Combat?.OpenedCorpse);
        public int VendorId => Bridge.Online && H.Net.OpenVendorInfo is { } ov ? Bridge.VendorIdOf(ov.Guid) : 0;
        public HookIndexer Attribute { get; } = new HookIndexer();
        public void SetIdleTime(double timeout) { }
        public IntPtr UIElementLookup(UIElementType t) => IntPtr.Zero;
        public System.Drawing.Rectangle UIElementRegion(UIElementType t) => default;
        // buying and selling, as the vendor window's lists: what's added, then all of it asked of the server at once
        private readonly List<(Item item, int amount)> _buy = new(), _sell = new();
        public void VendorAddBuyList(int templateId, int count)
        {
            if (Bridge.ThingOf(templateId) is not Item it || count <= 0) return;
            int i = _buy.FindIndex(b => ReferenceEquals(b.item, it));
            if (i >= 0) _buy[i] = (it, _buy[i].amount + count); else _buy.Add((it, count));
        }
        public void VendorClearBuyList() => _buy.Clear();
        public void VendorBuyAll()
        {
            if (Bridge.Online && H.Net.OpenVendorInfo is { } v && _buy.Count > 0) H.Net.Buy(v.Guid, _buy.ToList());
            _buy.Clear();
        }
        public void VendorAddSellList(int id)
        {
            if (Bridge.ThingOf(id) is Item it && !_sell.Exists(x => ReferenceEquals(x.item, it))) _sell.Add((it, Math.Max(1, it.Stack)));
        }
        public void VendorClearSellList() => _sell.Clear();
        public void VendorSellAll()
        {
            if (Bridge.Online && H.Net.OpenVendorInfo is { } v && _sell.Count > 0) H.Net.Sell(v.Guid, _sell.ToList());
            _sell.Clear();
        }
        /// <summary>The client's physics object for a thing (none here: plugins skip what needs it).</summary>
        public int GetPhysicsObjectPtr(int id) => 0;
        public int GetWeenieObjectPtr(int id) => 0;
        public void MoveItem(int objectId, int destinationId) => MoveItem(objectId, destinationId, 0, true);
        public void MoveItem(int objectId, int destinationId, int moveFlags) => MoveItem(objectId, destinationId, 0, true);
        public int BusyStateId => 0;
        public bool ChatState => UI.ImGuiLayer_Typing;
        public bool PointerState => false;
        public int SelectedStackCount { get; set; }

        public int Landcell => H?.Player?.Active == true ? unchecked((int)Bridge.Place(H.Player.Position, H.Player.Cell).cell) : 0;
        public double LocationX => H?.Player == null ? 0 : Bridge.Place(H.Player.Position, H.Player.Cell).x;
        public double LocationY => H?.Player == null ? 0 : Bridge.Place(H.Player.Position, H.Player.Cell).y;
        public double LocationZ => H?.Player == null ? 0 : Bridge.Place(H.Player.Position, H.Player.Cell).z;
        /// <summary>The way you face, degrees clockwise from north.</summary>
        public double Heading => H?.Player == null ? 0 : ((-H.Player.Heading * 180.0 / Math.PI) % 360 + 360) % 360;
        public double HeadingDegrees => Heading;
        public double HeadingRadians => Heading * Math.PI / 180;
        public HooksWrapper Underlying => this;

        /// <summary>Moves an item: out of the open corpse into your pack (taken, as the loot window's take does).</summary>
        public void MoveItem(int item, int container, int slot, bool stack)
        {
            if (H == null || Bridge.ThingOf(item) is not Item it) return;
            // on a server, something of yours into a pack of yours (the main one: your own id) at a place
            // (Decal's SelectedStackCount set first: that many split off the stack, not the whole stack moved)
            int split = SelectedStackCount; SelectedStackCount = 0;
            if (Bridge.Online && it.Guid != 0 && split > 0 && split < it.Stack && H.Inv.Pack.Contains(it))
            {
                var into = Bridge.ThingOf(container);
                uint packGuid = container == Bridge.PlayerId ? 0u : into is Item sp && sp.Guid != 0 && H.Inv.SidePacks.Contains(sp) ? sp.Guid : 0u;
                H.Net.PluginAsking = true;
                try { H.Net.Split(it, packGuid, slot, split); } finally { H.Net.PluginAsking = false; }
                return;
            }
            if (Bridge.Online && it.Guid != 0 && (H.Inv.Pack.Contains(it) || H.Inv.Worn.Contains(it)))
            {
                var dest = Bridge.ThingOf(container);
                if (dest is Item on2 && on2 != it && H.Inv.Pack.Contains(on2) && ACGodot.Combat.Inventory.Stackable(it, on2)) { H.Inv.StackOnto(it, on2); return; }
                // (a plugin's own doing: if the server won't, it's logged, not said in chat)
                H.Net.PluginAsking = true;
                try
                {
                    if (container == Bridge.PlayerId) { H.Net.Move(it, 0, slot); return; }
                    if (dest is Item pack && pack.Guid != 0 && H.Inv.SidePacks.Contains(pack)) { H.Net.Move(it, pack.Guid, slot); return; }
                }
                finally { H.Net.PluginAsking = false; }
                return;
            }
            // onto another stack of the same thing in the pack: stacked (what Decal's move onto an item does)
            if (H.Inv.Pack.Contains(it) && Bridge.ThingOf(container) is Item onto && onto != it && H.Inv.Pack.Contains(onto) && ACGodot.Combat.Inventory.Stackable(it, onto))
            {
                H.Inv.StackOnto(it, onto);
                H.Me.Save(H.Inv);
                return;
            }
            if (H.Inv.Pack.Contains(it) || H.Inv.Worn.Contains(it)) return;   // (moving within the pack: one pack here)
            // out of the corpse or chest open on a server: asked of it
            // (bending down for it, as taking it from the loot window does - a plugin's looting took things standing up)
            if (Bridge.Online && it.Guid != 0 && H.Net.OpenContainer != 0 && H.Net.OpenContents().Contains(it)) { H.Net.TakeOut(it); try { H.Player?.Crouch(); } catch { } return; }
            if (H.Combat.OpenedCorpse is { } c && H.Combat.CorpseContents(c)?.Contains(it) == true && H.Combat.LootUi is { } lw) lw.TakeIt(it);
        }
        public void DropItem(int item) { if (Bridge.ThingOf(item) is Item i && H != null && H.Inv.Pack.Contains(i)) { H.Inv.Remove(i); H.Combat.Drop(i); } }
        public void GiveItem(int item, int target) => AcClient.CM_Inventory.Event_GiveObjectRequest(unchecked((uint)target), unchecked((uint)item), 0);
        public void SelectItem(int id, int a) => SelectItem(id);
        public bool IsValidObject(int id) => CoreManager.Current.WorldFilter[id] != null;
        public void Logout() { if (Bridge.Online) H.Net.LogOut(); }
        public void FaceHeading(double deg, bool unused) => H?.FaceHeading(deg);
        public void SetCursorPosition(int x, int y) { }
        public void UIElementMove(int a, int x, int y) { }
        // the salvage window: what's put in it, then salvaged with the Ust last used (or the first one in the pack)
        private readonly List<Item> _salvage = new();
        internal static Item LastUst;
        public void SalvagePanelAdd(int id) { if (Bridge.ThingOf(id) is Item it && !_salvage.Contains(it)) _salvage.Add(it); }
        public void SalvagePanelSalvage()
        {
            if (!Bridge.Online || _salvage.Count == 0) { _salvage.Clear(); return; }
            var ust = LastUst != null && H.Inv.Pack.Contains(LastUst) ? LastUst : H.Inv.Pack.FirstOrDefault(i => i.Name == "Ust");
            if (ust != null) H.Net.Salvage(ust, _salvage.ToList());
            _salvage.Clear();
        }
    }

    internal static class UI { public static bool ImGuiLayer_Typing => ACGodot.UI.ImGuiLayer.TypingAny; }

    /// <summary>A Decal plugin's host (its Actions).</summary>
    public class PluginHost
    {
        public HooksWrapper Actions => CoreManager.Current.Actions;
        public object Render => null;
    }

    /// <summary>Things Decal draws in the world: the arrow pointing to coordinates (ACGodot's arrow), and marks at a
    /// place or on a thing - a shape (ring, ball, ...) or words - drawn in ACGodot's world.</summary>
    public class D3DService
    {
        public D3DObj PointToCoords(float ns, float ew, float z, int color)
        {
            Bridge.Host?.PointArrow?.Invoke(ns, ew, $"{Math.Abs(ns):0.0}{(ns >= 0 ? "N" : "S")}, {Math.Abs(ew):0.0}{(ew >= 0 ? "E" : "W")}");
            return new D3DObj(true);
        }
        public D3DObj PointToObject(int id, int color) => new D3DObj(false);
        public D3DObj MarkObjectWith3DText(int id, string text, string font, int opts) { var o = new D3DObj(false) { Color = -1 }; o.SetText(text); o.Anchor(id, 1.1f, 0, 0, 0); return o; }
        public D3DObj MarkObjectWithIcon(int id, int icon) => new D3DObj(false);
        public D3DObj NewD3DObj() => new D3DObj(false);
        public D3DObj MarkObjectWithShape(int guid, D3DShape shape, int color) { var o = new D3DObj(false) { Color = color }; o.SetShape(shape); o.Anchor(guid, 0f, 0, 0, 0); return o; }
        public D3DObj MarkObjectWithShapeFromFile(int guid, string file, int color) => new D3DObj(false);
        public D3DObj MarkObjectWith2DText(int guid, string text, string font, int options) => MarkObjectWith3DText(guid, text, font, options);
        public D3DObj MarkCoordsWithIcon(float lat, float lng, float alt, int icon) => new D3DObj(false);
        public D3DObj MarkCoordsWithShape(float lat, float lng, float alt, D3DShape shape, int color) { var o = new D3DObj(false) { Color = color }; o.SetShape(shape); o.Anchor(lat, lng, alt); return o; }
        public D3DObj MarkCoordsWithShapeFromFile(float lat, float lng, float alt, string file, int color) => new D3DObj(false);
        public D3DObj MarkCoordsWith2DText(float lat, float lng, float alt, string text, string font, int options) => MarkCoordsWith3DText(lat, lng, alt, text, font, options);
        public D3DObj MarkCoordsWith3DText(float lat, float lng, float alt, string text, string font, int options) { var o = new D3DObj(false) { Color = -1 }; o.SetText(text); o.Anchor(lat, lng, alt); return o; }
    }

    /// <summary>A mark in the world (or the arrow): made as a node in ACGodot's scene when it's given a shape or words.</summary>
    public class D3DObj : IDisposable
    {
        private readonly bool _arrow;
        internal D3DObj(bool arrow) { _arrow = arrow; }
        private bool _visible = true, _gone;
        private Node3D _node;
        private MeshInstance3D _mesh;
        private Label3D _label;
        private int _color = -1, _anchorId;
        private float _anchorH, _sx = 1, _sy = 1, _sz = 1;
        private Vector3 _at;
        private bool _toCamera;

        // every mark sits under one node in the world; those on a thing follow it each frame
        private static Node3D _root;
        private static readonly List<D3DObj> Following = new();
        private static bool _ticking;
        private static readonly Dictionary<D3DShape, Mesh> Meshes = new();
        private static readonly Dictionary<int, StandardMaterial3D> Materials = new();

        private static Node3D Root()
        {
            if (_root != null && GodotObject.IsInstanceValid(_root) && _root.IsInsideTree()) return _root;
            var h = Bridge.Host;
            var parent = h?.Player?.GetParent();
            if (parent == null) return null;
            _root = new Node3D { Name = "PluginMarks" };
            parent.AddChild(_root);
            if (!_ticking && h != null)
            {
                _ticking = true;
                h.Tick += _ => { for (int i = Following.Count - 1; i >= 0; i--) { var o = Following[i]; if (o._gone) Following.RemoveAt(i); else o.Follow(); } };
            }
            return _root;
        }

        private static Mesh MeshOf(D3DShape shape)
        {
            if (Meshes.TryGetValue(shape, out var m)) return m;
            m = shape switch
            {
                D3DShape.Ring => new TorusMesh { InnerRadius = 0.4f, OuterRadius = 0.5f, Rings = 28, RingSegments = 6 },
                D3DShape.Sphere => new SphereMesh { Radius = 0.5f, Height = 1f, RadialSegments = 12, Rings = 6 },
                D3DShape.Cylinder => new CylinderMesh { TopRadius = 0.5f, BottomRadius = 0.5f, Height = 1f, RadialSegments = 16 },
                D3DShape.VerticalArrow or D3DShape.HorizontalArrow => new CylinderMesh { TopRadius = 0.35f, BottomRadius = 0f, Height = 1f, RadialSegments = 12 },
                _ => new BoxMesh { Size = Vector3.One },
            };
            return Meshes[shape] = m;
        }

        private static Color ColorOf(int argb)
        {
            uint c = unchecked((uint)argb);
            float a = (c >> 24) / 255f;
            return new Color(((c >> 16) & 0xFF) / 255f, ((c >> 8) & 0xFF) / 255f, (c & 0xFF) / 255f, a <= 0 ? 1f : a);
        }

        private static StandardMaterial3D MaterialOf(int argb)
        {
            if (Materials.TryGetValue(argb, out var m)) return m;
            var col = ColorOf(argb);
            m = new StandardMaterial3D { ShadingMode = BaseMaterial3D.ShadingModeEnum.Unshaded, AlbedoColor = col, CullMode = BaseMaterial3D.CullModeEnum.Disabled };
            if (col.A < 0.99f) m.Transparency = BaseMaterial3D.TransparencyEnum.Alpha;
            return Materials[argb] = m;
        }

        private bool Make()
        {
            if (_gone) return false;
            if (_node != null && GodotObject.IsInstanceValid(_node)) return true;
            var root = Root();
            if (root == null) return false;
            _node = new Node3D { Visible = _visible };
            root.AddChild(_node);
            return true;
        }

        private void Apply()
        {
            if (_node == null || !GodotObject.IsInstanceValid(_node)) return;
            _node.Visible = _visible;
            if (_mesh != null) { _mesh.Scale = new Vector3(_sx, _sz, _sy); _mesh.MaterialOverride = MaterialOf(_color); }
            if (_label != null)
            {
                _label.PixelSize = Math.Max(0.0005f, _sx / 64f);
                _label.Modulate = ColorOf(_color);
                _label.Billboard = _toCamera ? BaseMaterial3D.BillboardModeEnum.Enabled : BaseMaterial3D.BillboardModeEnum.Disabled;
            }
        }

        private void Follow()
        {
            if (_node == null || !GodotObject.IsInstanceValid(_node) || _anchorId == 0) return;
            var h = Bridge.Host;
            if (h == null) return;
            Vector3? p = _anchorId == Bridge.PlayerId ? (h.Player != null && h.Player.Active ? h.Player.Position : (Vector3?)null)
                : Bridge.ThingOf(_anchorId) is ObjectStreamer.Selectable s ? s.Feet : null;
            if (p is { } at) { _node.Position = at + _at + new Vector3(0, _anchorH * 1.8f, 0); _node.Visible = _visible; }
            else _node.Visible = false;
        }

        public bool Visible { get => _visible; set { _visible = value; if (_arrow && !value) Bridge.Host?.ClearArrow?.Invoke(); Apply(); } }
        public int Color { get => _color; set { _color = value; Apply(); } }
        public float ScaleX { get => _sx; set { _sx = value; Apply(); } }
        public float ScaleY { get => _sy; set { _sy = value; Apply(); } }
        public float ScaleZ { get => _sz; set { _sz = value; Apply(); } }
        public void Scale(float s) { _sx = _sy = _sz = s; Apply(); }
        public void OrientToCamera(bool b) { _toCamera = b; Apply(); }
        /// <summary>On a thing (h: how far up it, 0 its feet to 1 its head), moved over by so much.</summary>
        public void Anchor(int id, float h, float x, float y, float z)
        {
            if (_arrow || !Make()) return;
            _anchorId = id; _anchorH = h; _at = new Vector3(x, z, -y);
            if (!Following.Contains(this)) Following.Add(this);
            Follow();
        }
        /// <summary>At a place: map coordinates and the height there.</summary>
        public void Anchor(float ns, float ew, float z)
        {
            if (_arrow || !Make()) return;
            _anchorId = 0; Following.Remove(this);
            var p = ACGodot.World.FromMapCoords(ns, ew);
            _node.Position = new Vector3(p.X, z, p.Z);
        }
        public void SetShape(D3DShape shape)
        {
            if (_arrow || !Make()) return;
            if (_label != null) { _label.QueueFree(); _label = null; }
            if (_mesh == null) { _mesh = new MeshInstance3D { CastShadow = GeometryInstance3D.ShadowCastingSetting.Off }; _node.AddChild(_mesh); }
            _mesh.Mesh = MeshOf(shape);
            _mesh.Rotation = shape == D3DShape.HorizontalArrow ? new Vector3(Mathf.Pi / 2, 0, 0) : shape == D3DShape.TiltedCube ? new Vector3(Mathf.Pi / 4, 0, Mathf.Pi / 4) : Vector3.Zero;
            Apply();
        }
        public void SetText(string text)
        {
            if (_arrow || !Make()) return;
            if (_mesh != null) { _mesh.QueueFree(); _mesh = null; }
            if (_label == null)
            {
                _label = new Label3D { FontSize = 64, OutlineSize = 12, OutlineModulate = new Color(0, 0, 0, 0.9f), Shaded = false, DoubleSided = true, FixedSize = false };
                _node.AddChild(_label);
            }
            _label.Text = text ?? "";
            Apply();
        }
        public void SetText(D3DTextType type, string text, string font, int opts) => SetText(text);
        public void SetText(string text, string font) => SetText(text);
        public void SetText(string text, string font, int options) => SetText(text);
        public void SetIcon(int icon) { }
        public void SetIcon(string file) { }
        public int Color2 { get; set; }
        public bool Autoscale { get; set; }
        public bool DrawBackface { get; set; }
        public float HBounce { get; set; } public float PBounce { get; set; } public float PFade { get; set; } public float POrbit { get; set; }
        public float PSpin { get; set; } public float ROrbit { get; set; } public float AnimationPhaseOffset { get; set; }
        public void OrientToCoords(float lat, float lng, float alt, bool tilt)
        {
            if (_node == null || !GodotObject.IsInstanceValid(_node)) return;
            var p = ACGodot.World.FromMapCoords(lat, lng);
            var to = new Vector3(p.X, tilt ? alt : _node.Position.Y, p.Z);
            if (to.DistanceTo(_node.Position) > 0.01f) _node.LookAt(to, Vector3.Up);
        }
        public void OrientToObject(int guid, float h, bool tilt) { }
        public void OrientToPlayer(bool tilt) { }
        public void Dispose()
        {
            if (_arrow) Bridge.Host?.ClearArrow?.Invoke();
            _gone = true;
            Following.Remove(this);
            if (_node != null && GodotObject.IsInstanceValid(_node)) _node.QueueFree();
            _node = null; _mesh = null; _label = null;
        }
    }

}


namespace Decal.Adapter.Wrappers
{
    public class HookIndexer { public int this[AttributeType t] => 0; public int this[int i] => 0; }

    public class ChangeEnchantmentsEventArgs : EventArgs { public EnchantmentWrapper Enchantment { get; set; } public AddRemoveEventType Type { get; set; } }

    public class EnchantmentWrapper : IDisposable
    {
        public double Adjustment { get; set; } public int Affected { get; set; } public int AffectedMask { get; set; } public double Duration { get; set; }
        public int Family { get; set; } public int Layer { get; set; } public int SpellId { get; set; } public int TimeRemaining { get; set; }
        public DateTime Expires => DateTime.Now.AddSeconds(TimeRemaining);
        public void Dispose() { }
    }

    public class Vector4Object
    {
        public Vector4Object(double w, double x, double y, double z) { W = w; X = x; Y = y; Z = z; }
        public double W { get; } public double X { get; } public double Y { get; } public double Z { get; }
    }

    /// <summary>A vendor's window (none: the world on its own has no shops open).</summary>
    public class Vendor : IEnumerable<WorldObject>, IDisposable
    {
        private readonly ACGodot.Net.NetGame.VendorInfo _v;
        public Vendor() { }
        internal Vendor(ACGodot.Net.NetGame.VendorInfo v) { _v = v; }
        private IEnumerable<WorldObject> Wares => _v == null ? Enumerable.Empty<WorldObject>() : _v.ForSale.Select(i => { Bridge.IdOf(i); return WorldFilter.Wrap(i); });
        public int MerchantId => _v == null ? 0 : Bridge.VendorIdOf(_v.Guid);
        public int MaxValue => _v?.MaxValue ?? 0; public float SellRate => _v?.SellRate ?? 1; public float BuyRate => _v?.BuyRate ?? 1; public int Categories => _v?.BuysTypes ?? 0;
        public int Count => _v?.ForSale.Count ?? 0; public int Quantity => Count;
        public WorldObject First => Wares.FirstOrDefault();
        public WorldObject this[int id] => Wares.FirstOrDefault(w => w.Id == id);
        public IEnumerator<WorldObject> GetEnumerator() => Wares.GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
        public void Dispose() { }
    }
}
