using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using ACGodot.Objects;
using Godot;

namespace ACGodot.DecalShim
{
    /// <summary>
    /// Decal and UtilityBelt as plugins written for the real client know them (CoreManager, WorldObject, Hud...),
    /// standing on ACGodot's plugin host: the plugins' own code builds and runs unchanged. <see cref="Start"/> once,
    /// from the plugin's ACGodot side, before it starts.
    /// </summary>
    public static class Bridge
    {
        public static ACGodot.Plugins.PluginHost Host { get; private set; }
        /// <summary>The player's own object id (Decal's CharacterFilter.Id).</summary>
        public const int PlayerId = 0x50000001;
        private static bool _started;
        private static int _loginStatus;
        private static Vector3? _lastAt;

        /// <summary>
        /// .NET's culture data puts a narrow no-break space (U+202F) between the time and AM/PM ("12:10 PM"): the game's
        /// fonts don't have it, so every time a plugin printed showed "12:10?PM". The patterns get a plain space.
        /// </summary>
        private static void PlainTimeSpaces()
        {
            try
            {
                var c = (System.Globalization.CultureInfo)System.Globalization.CultureInfo.CurrentCulture.Clone();
                var f = c.DateTimeFormat;
                static string P(string p) => p.Replace('\u202F', ' ').Replace('\u00A0', ' ');
                f.ShortTimePattern = P(f.ShortTimePattern);
                f.LongTimePattern = P(f.LongTimePattern);
                f.FullDateTimePattern = P(f.FullDateTimePattern);
                System.Globalization.CultureInfo.CurrentCulture = c;
                System.Globalization.CultureInfo.DefaultThreadCurrentCulture = c;
            }
            catch { }
        }

        public static void Start(ACGodot.Plugins.PluginHost host)
        {
            Host = host;
            if (_started) return;
            _started = true;
            PlainTimeSpaces();
            host.ChatIntercept += (text, kind) => Decal.Adapter.CoreManager.Current.RaiseChat(text, kind);
            host.CommandTyped += text => Decal.Adapter.CoreManager.Current.RaiseCommand(text);
            // the server's "you killed it" notice, as Decal's network filter passes it on (game event 0x01AD)
            // (the real one comes with every other message now: see below)
            // a spell come onto you or gone (the server's word): Decal's "enchantments changed"
            host.Enchant += (spell, left, on) => Decal.Adapter.CoreManager.Current.CharacterFilter.RaiseEnchantment(spell, left, on);
            // identified in the game: the plugins hear of it as Decal's "ID received"
            // a book's pages as the server sends them (every page of a book opened is asked for by the game)
            // (hooked once there's a server connection to hook: see the tick below)
            host.Identified += o =>
            {
                var wf = Decal.Adapter.CoreManager.Current.WorldFilter;
                if (ReferenceEquals(o, ACGodot.Plugins.PluginHost.Self)) { SelfIdAt = DateTime.Now; wf.RaiseChangedSoon(PlayerId); return; }
                wf.RaiseChangedSoon(IdOf(o));
            };
            host.Tick += dt =>
            {
                // logged in, as the plugins see it: once the character is the one that will be played. With a server
                // to connect to that's the server's character, in its world - not the offline one the game starts
                // with (a plugin that keeps its settings by character would load that one's and save the other's).
                // (No server answering after a minute: the offline character it is.)
                _sinceStart += dt;
                if (!_bookHooked && host.Net != null)
                {
                    _bookHooked = true;
                    // every game message the server sends, and every one sent to it: Decal's network filter
                    var echo = Decal.Adapter.CoreManager.Current.EchoFilter;
                    host.Net.RawIn = (op, payload) => echo.RaiseServer(new Decal.Adapter.Message(op, payload));
                    host.Net.RawOut = (op, payload) => echo.RaiseClient(new Decal.Adapter.Message(op, payload));
                    host.Net.BookPage += (guid, page, pages, text) => { try { BookPage?.Invoke(unchecked((int)guid), page, pages, text); } catch (Exception ex) { GD.PushWarning("plugin book page: " + ex.Message); } };
                }
                // (in its world AND told who we are there: the server's account of the character - its name with it -
                // comes after we're let in, in pieces for one who carries a lot. Logged in before it had come, a plugin
                // took the character's name to be the offline one's, loaded no settings for it, and then saved those
                // empty settings over the real character's)
                // (and everything carried come in: the things follow the server's list of them, for one who carries a lot
                // well after - a plugin starting on a half-filled pack picked the wrong wand, miscounted, sorted wrongly)
                bool ready = string.IsNullOrEmpty(host.ServerName) || (host.Net?.InWorld == true && host.Net.Character != null && host.Net.InventoryComplete) || (_sinceStart > 60 && host.Net?.InWorld != true);
                if (_loginStatus < 3 && ready && host.Player != null && host.Player.Active)
                {
                    _loginStatus = 3;
                    try { Decal.Adapter.CoreManager.Current.CharacterFilter.RaiseLogin(); } catch (Exception ex) { GD.PushWarning("plugin login: " + ex); }
                }
                // through a portal on a server (a portal, a recall, a summons): Decal's portal space - in as the server
                // sends us somewhere else, out once we're placed there (as the game's own client tells Decal). (A jump of
                // the player's position missed some: a recall wasn't always seen as one.)
                if (host.Net != null)
                {
                    var cf = Decal.Adapter.CoreManager.Current.CharacterFilter;
                    if (_portalIn < 0) { _portalIn = host.Net.PortalsEntered; _portalOut = host.Net.PortalsExited; }
                    while (_portalIn < host.Net.PortalsEntered) { _portalIn++; cf.RaisePortal(Decal.Adapter.Wrappers.PortalEventType.EnterPortal); }
                    while (_portalOut < host.Net.PortalsExited) { _portalOut++; cf.RaisePortal(Decal.Adapter.Wrappers.PortalEventType.ExitPortal); }
                }
                // offline: a jump across the world (/go) is the portal space, in and out
                else if (host.Player != null && host.Player.Active)
                {
                    var at = host.Player.Position;
                    if (_lastAt is { } was && was.DistanceTo(at) > 60f)
                    {
                        Decal.Adapter.CoreManager.Current.CharacterFilter.RaisePortal(Decal.Adapter.Wrappers.PortalEventType.EnterPortal);
                        Decal.Adapter.CoreManager.Current.CharacterFilter.RaisePortal(Decal.Adapter.Wrappers.PortalEventType.ExitPortal);
                    }
                    _lastAt = at;
                }
                // (what's come and gone is told before the plugins' own frame, as Decal does: a monster that died is
                // "released" while a plugin still has it on its list - MelkTank's kill count goes by that)
                Decal.Adapter.Wrappers.WorldFilter.Track();
                Decal.Adapter.CoreManager.Current.RaiseFrame();
            };
        }

        private static double _sinceStart;
        private static int _portalIn = -1, _portalOut = -1;
        public static int LoginStatus => _loginStatus;
        /// <summary>When you last identified yourself (you count as the selection for a moment, as in the game).</summary>
        public static DateTime SelfIdAt = DateTime.MinValue;

        // ── ids: the game's things get ids the way the server's do (the same thing keeps its id) ──
        private static readonly ConditionalWeakTable<object, object> _ids = new();
        private static readonly Dictionary<int, WeakReference<object>> _byId = new();
        private static int _nextId = 0x70000001;

        // a monster that dies leaves a corpse: a new thing with an id of its own (as the server does), so plugins see the
        // monster go and the corpse come; each death its own corpse
        private sealed class CorpseKey { }
        private static readonly ConditionalWeakTable<ObjectStreamer.Selectable, CorpseKey> _corpses = new();
        private static bool Dead(ObjectStreamer.Selectable s) => s.Fight is ACGodot.Combat.Fighter { St: ACGodot.Combat.Fighter.State.Dead };

        public static int IdOf(object o)
        {
            if (o == null) return 0;
            object key = o;
            if (o is ObjectStreamer.Selectable s)
            {
                if (Dead(s)) key = _corpses.GetValue(s, _ => new CorpseKey());
                else _corpses.Remove(s);   // (alive again: its next death is a new corpse)
            }
            // an item has its own number, kept with it from run to run (plugins keep item ids in their settings)
            // (a server's item: from the server's own number for it, which it keeps - the game's own count of items starts
            // afresh each time, and the weapons a plugin had listed came back as other things)
            if (o is ACGodot.Combat.Item it && (it.Uid > 0 || it.Guid != 0))
            {
                // (the server's number itself, as the game's own client with Decal gives it: an item listed by a plugin there
                // is the same item here - under an id of our own making, everything listed there showed as missing)
                int iid = it.Guid != 0 ? unchecked((int)it.Guid) : 0x40000000 | (it.Uid & 0x0FFFFFFF);   // (0x50000001 is you)
                if (!_byId.TryGetValue(iid, out var wr) || !wr.TryGetTarget(out var cur) || !ReferenceEquals(cur, o)) _byId[iid] = new WeakReference<object>(o);
                return iid;
            }
            if (_ids.TryGetValue(key, out var boxed)) return (int)boxed;
            int id = _nextId++;
            _ids.Add(key, id);
            _byId[id] = new WeakReference<object>(o);
            return id;
        }

        /// <summary>The id is a corpse's (the monster dead).</summary>
        public static bool IsCorpse(object o, int id) => o is ObjectStreamer.Selectable s && Dead(s) && IdOf(s) == id;

        /// <summary>The id of the item under the mouse in ACGodot's packs, a corpse or on you (0: none).</summary>
        public static int HoveredItemId() => ACGodot.Combat.ItemSlot.Hovered is { } i ? IdOf(i) : 0;

        /// <summary>The plugins' id of a vendor (the NPC as the world filter gives it - not the server's number for it).</summary>
        public static int VendorIdOf(uint guid)
        {
            var h = Host;
            return h?.Net?.ThingAt(guid) is { } s ? IdOf(s) : unchecked((int)guid);
        }

        /// <summary>The plugins' id of the corpse or chest open on a server (0: none).</summary>
        public static int OpenContainerId()
        {
            var h = Host;
            if (h?.Net == null || h.Net.OpenContainer == 0) return 0;
            return h.Net.ThingAt(h.Net.OpenContainer) is { } s ? IdOf(s) : 0;
        }

        /// <summary>A book being read: its id, the page (0 on; -1: it has just opened), how many pages (-1: not said with this
        /// page), the page's words (null as it opens).</summary>
        public static event Action<int, int, int, string> BookPage;
        private static bool _bookHooked;

        /// <summary>A spell is being cast (on a server): from asking for it to the end of its gestures. The server refuses
        /// to move things about in the packs meanwhile.</summary>
        public static bool Casting => Host?.Magic?.Casting == true;

        /// <summary>Busy, as the server sees it - casting, in the middle of a melee or missile attack, bending down to pick
        /// something up or put it down: it won't move things about in the packs till that's done.</summary>
        private static DateTime _busyAt = DateTime.MinValue;
        public static bool Busy
        {
            get
            {
                var h = Host;
                if (h == null) return false;
                // (and for a moment after: casting one spell after another, the gap between two is too short for the server
                // to take a move - it refused one asked in such a gap)
                try
                {
                    if (h.Magic?.Casting == true || h.Combat?.InAttack == true || h.Player?.Bending == true) { _busyAt = DateTime.UtcNow; return true; }
                    return (DateTime.UtcNow - _busyAt).TotalSeconds < 1.5;
                }
                catch { return false; }
            }
        }

        /// <summary>The server's clock, as the game's own client keeps it (seconds); 0 when there's none (not on a server).</summary>
        public static double ServerClock => Host?.Net?.ServerClock ?? 0;

        /// <summary>On a server (the plugins' actions go to it, not to the world ACGodot runs on its own).</summary>
        public static bool Online => Host?.Net != null && Host.Net.InWorld;

        /// <summary>The server's own number for what a plugin's id stands for (you, an item, a thing in the world); 0 if it has none.</summary>
        public static uint GuidOf(int id)
        {
            var h = Host;
            if (h?.Net == null || id == 0) return 0;
            if (id == PlayerId) return h.Net.GuidOf(h.Objects.Self);
            var t = ThingOf(id);
            uint g = t is ACGodot.Combat.Item i ? i.Guid : t is ObjectStreamer.Selectable s ? h.Net.GuidOf(s) : 0;
            // (not held here by that id just now - its item made again, the old one let go: a server's item's id is its
            // own number, so that's what's asked for. An ID asked for a weapon this way was never sent, and its
            // zone-reduced numbers stayed until it was ID'd by hand)
            uint u = unchecked((uint)id);
            if (g == 0 && t == null && u >= 0x80000000u) g = u;
            return g;
        }

        public static object ThingOf(int id) => _byId.TryGetValue(id, out var w) && w.TryGetTarget(out var o) ? o : null;

        // ── where things are, the way Decal says it ──

        /// <summary>Godot position → (landcell, local x, y, z): the landblock's cell, metres inside the landblock.</summary>
        public static (uint cell, double x, double y, double z) Place(Vector3 g, uint cell)
        {
            var (ax, ay, az) = World.ToAc(g);
            int lbx = (int)Math.Floor(ax / World.LandblockSize), lby = (int)Math.Floor(ay / World.LandblockSize);
            // (a cell given: outdoors it's only good if it's this landblock's - one kept from the landblock just left put
            // the place a whole landblock, 192 m, off; a room's is kept, the place counted from its landblock)
            if (cell != 0 && (cell & 0xFFFF) < 0x100 && ((int)(cell >> 24) != (lbx & 0xFF) || (int)((cell >> 16) & 0xFF) != (lby & 0xFF))) cell = 0;
            if (cell != 0 && (cell & 0xFFFF) >= 0x100) { lbx = (int)(cell >> 24); lby = (int)((cell >> 16) & 0xFF); }
            double lx = ax - lbx * World.LandblockSize, ly = ay - lby * World.LandblockSize;
            // (no room known and the place off the map - just in, in an apartment hall south of its landblock: no cell
            // at all, not one wrapped round to the far side of the world - Nav read that as 49152 m off)
            if (cell == 0 && (lbx < 0 || lby < 0 || lbx > 254 || lby > 254)) return (0, lx, ly, az);
            uint lc = cell != 0 ? cell : ((uint)(lbx & 0xFF) << 24) | ((uint)(lby & 0xFF) << 16) | (uint)(1 + (int)(lx / 24) * 8 + (int)(ly / 24));
            return (lc, lx, ly, az);
        }

        /// <summary>Map coordinates (north, east) of a Godot position.</summary>
        public static (double ns, double ew) Coords(Vector3 g)
        {
            var (x, y, _) = World.ToAc(g);
            return (y / 240.0 - 101.95, x / 240.0 - 101.95);
        }

        // Decal's chat link markup (<Tell:IIDString:...>text<\Tell>): just the text (ACGodot's chat makes coordinates links itself)
        private static readonly System.Text.RegularExpressions.Regex LinkRx = new(@"<Tell:[^>]*>(.*?)<\\Tell>", System.Text.RegularExpressions.RegexOptions.Singleline);

        public static void Say(string text, int color)
        {
            if (Host == null || text == null) return;
            text = LinkRx.Replace(text, "$1").TrimEnd('\n', '\r');
            var c = color switch
            {
                0 => new Color(0.6f, 1f, 0.6f), 2 => Colors.White, 3 => new Color(1f, 0.9f, 0.4f), 5 => new Color(1f, 0.75f, 0.45f),
                6 => new Color(1f, 0.4f, 0.4f), 7 => new Color(0.6f, 0.8f, 1f), 13 => new Color(0.5f, 1f, 1f), 17 => new Color(0.9f, 0.6f, 1f),
                21 => new Color(0.4f, 1f, 0.4f), 22 => new Color(1f, 0.5f, 0.5f), _ => new Color(1f, 0.85f, 0.6f),
            };
            // (a pet's hit put back by a plugin - with commas - is still combat, not a plugin's own line)
            var kind = text.StartsWith("[Pet]", StringComparison.Ordinal) ? ACGodot.UI.ChatKind.Combat : ACGodot.UI.ChatKind.Plugin;
            Host.SayTo?.Invoke(text, c, kind);
        }
    }
}
