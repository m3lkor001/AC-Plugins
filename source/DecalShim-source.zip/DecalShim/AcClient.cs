using System;
using System.Linq;
using ACGodot.DecalShim;

namespace AcClient
{
    /// <summary>The client's own calls some plugins make directly (giving an item to an NPC).</summary>
    public static class CM_Inventory
    {
        private static ACGodot.Combat.Item ItemOf(uint id) => Bridge.ThingOf(unchecked((int)id)) as ACGodot.Combat.Item;

        /// <summary>Uses one thing on another. You (the player) "using" something is just using it: a door, a corpse, an NPC.</summary>
        public static void Event_UseWithTargetEvent(uint item, uint target)
        {
            var h = Bridge.Host;
            if (h == null) return;
            if (unchecked((int)item) == Bridge.PlayerId || item == 0) { Decal.Adapter.CoreManager.Current.Actions.UseItem(unchecked((int)target), 0); return; }
            // (offline the game uses a thing on what's selected: chosen first. On a server it's asked directly)
            if (!Bridge.Online && Bridge.ThingOf(unchecked((int)target)) is ACGodot.Objects.ObjectStreamer.Selectable s) h.Select(s);
            Decal.Adapter.CoreManager.Current.Actions.UseItem(unchecked((int)item), 1, unchecked((int)target));
        }

        /// <summary>Wields something from the pack (the slot is where it goes; the game works that out from the item).</summary>
        public static void Event_GetAndWieldItem(uint item, uint slot)
        {
            var h = Bridge.Host;
            if (h == null || ItemOf(item) is not { } it || h.Inv.Worn.Contains(it)) return;
            h.UseItem?.Invoke(it);
        }

        /// <summary>Puts (some of) one stack onto another of the same thing.</summary>
        public static void Event_StackableMerge(uint from, uint to, int amount)
        {
            var h = Bridge.Host;
            if (h == null || ItemOf(from) is not { } a || ItemOf(to) is not { } b || a == b) return;
            if (!h.Inv.Pack.Contains(a) || !h.Inv.Pack.Contains(b) || !ACGodot.Combat.Inventory.Stackable(a, b)) return;
            if (Bridge.Online && a.Guid != 0 && b.Guid != 0) { h.Net.Merge(a, b, amount); return; }
            if (amount > 0 && amount < a.Stack) a = h.Inv.Split(a, amount) ?? a;
            h.Inv.StackOnto(a, b);
            h.Me.Save(h.Inv);
        }

        /// <summary>Gives (some of) an item to someone: out of your pack (the world on its own has no one to take it).</summary>
        public static bool Event_GiveObjectRequest(uint target, uint item, uint amount)
        {
            var h = Bridge.Host;
            if (h == null || Bridge.ThingOf(unchecked((int)item)) is not ACGodot.Combat.Item it || !h.Inv.Pack.Contains(it)) return false;
            if (Bridge.Online && it.Guid != 0)
            {
                // on a server: handed over there (it leaves the pack when the server says so)
                if (Bridge.ThingOf(unchecked((int)target)) is not ACGodot.Objects.ObjectStreamer.Selectable who) return false;
                h.Net.Give(who, it, amount == 0 ? Math.Max(1, it.Stack) : (int)Math.Min(amount, (uint)Math.Max(1, it.Stack)));
                return true;
            }
            string to = Decal.Adapter.CoreManager.Current.WorldFilter[unchecked((int)target)]?.Name ?? "them";
            int n = amount == 0 ? it.Stack : (int)Math.Min(amount, (uint)Math.Max(1, it.Stack));
            if (n >= it.Stack) h.Inv.Remove(it); else { it.Stack -= n; h.Inv.Changed?.Invoke(); }
            h.Me.Save(h.Inv);
            Bridge.Say($"You give {to} {(n > 1 ? n + " " : "")}{it.Name}.", 0);
            return true;
        }
    }

    /// <summary>The attack heights, as the client numbers them.</summary>
    public enum ATTACK_HEIGHT : uint { UNDEF_ATTACK_HEIGHT = 0, HIGH_ATTACK_HEIGHT = 1, MEDIUM_ATTACK_HEIGHT = 2, LOW_ATTACK_HEIGHT = 3, NUM_ATTACK_HEIGHTS = 4 }

    /// <summary>Attacking: the target selected, the power bar set, and ACGodot's own attack asked for.</summary>
    public static class CM_Combat
    {
        private static void Attack(uint target, ATTACK_HEIGHT height, float power)
        {
            var h = Bridge.Host;
            if (h == null) return;
            if (Bridge.ThingOf(unchecked((int)target)) is ACGodot.Objects.ObjectStreamer.Selectable s && h.Selected != s) h.Select(s);
            h.Combat.Power = Math.Clamp(power, 0f, 1f);
            int at = height == ATTACK_HEIGHT.HIGH_ATTACK_HEIGHT ? 0 : height == ATTACK_HEIGHT.LOW_ATTACK_HEIGHT ? 2 : 1;
            h.Attack(at);
        }
        public static void Event_TargetedMeleeAttack(uint target, ATTACK_HEIGHT height, float power) => Attack(target, height, power);
        public static void Event_TargetedMissileAttack(uint target, ATTACK_HEIGHT height, float power) => Attack(target, height, power);
        public static void Event_CancelAttack() => Bridge.Host?.CancelAttack();
        /// <summary>Asks for a monster's health (ACGodot always knows it: nothing to ask).</summary>
        public static void Event_QueryHealth(uint target) { if (Bridge.Online) Bridge.Host.Net.QueryHealth(Bridge.GuidOf(unchecked((int)target))); }
    }

    /// <summary>Fellowships: on a server, asked of it (the world ACGodot runs on its own has none).</summary>
    public static class CM_Fellowship
    {
        private static ACGodot.Net.NetGame Net() { if (Bridge.Online) return Bridge.Host.Net; Bridge.Say("There are no fellowships here yet.", 0); return null; }
        public static void Event_Quit(int disband) => Net()?.QuitFellowship(disband != 0);
        public static void Event_ChangeFellowOpeness(int open) => Net()?.FellowOpenness(open != 0);
        public static void Event_Recruit(uint id) { if (Net() is { } n && Bridge.ThingOf(unchecked((int)id)) is ACGodot.Objects.ObjectStreamer.Selectable who) n.RecruitFellow(who); }
        public static void Event_Dismiss(uint id) { if (Net() is { } n) n.DismissFellow(Bridge.GuidOf(unchecked((int)id))); }
        public static void Event_AssignNewLeader(uint id) { if (Net() is { } n) n.FellowLeaderTo(Bridge.GuidOf(unchecked((int)id))); }
    }

    /// <summary>The client's own window calls (not available: the caller's fallback runs).</summary>
    public static class CM_UI
    {
        public static void SendNotice_SetDisplayInventory(int show) => throw new NotSupportedException("ACGodot: no client inventory call");
        public static void SendNotice_OpenContainedContainer(uint id) => throw new NotSupportedException("ACGodot: no client container call");
    }

    /// <summary>The answer to a yes / no pop-up (ACGodot's world asks none).</summary>
    public static class CM_Character
    {
        public static void Event_ConfirmationResponse(int type, uint context, int yes) { }
    }

    /// <summary>Raising skills with credits (not in ACGodot's world yet).</summary>
    public static class CM_Train
    {
        public static void Event_TrainSkillAdvancementClass(uint skill, uint cost)
        {
            if (Bridge.Online) Bridge.Host.Net.Raise(3, (int)skill, cost);
            else Bridge.Say("Training skills isn't in this world yet.", 0);
        }
    }
}
