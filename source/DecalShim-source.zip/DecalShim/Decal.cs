using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using ACGodot.DecalShim;
using Decal.Adapter.Wrappers;

namespace Decal.Adapter
{
    public class ChatTextInterceptEventArgs : EventArgs
    {
        public ChatTextInterceptEventArgs(string text, int color, int target) { Text = text; Color = color; Target = target; }
        public string Text { get; set; }
        public int Color { get; set; }
        public int Target { get; set; }
        public bool Eat { get; set; }
    }

    public class ChatParserInterceptEventArgs : EventArgs
    {
        public ChatParserInterceptEventArgs(string text) { Text = text; }
        public string Text { get; set; }
        public bool Eat { get; set; }
    }

    public class NetworkMessageEventArgs : EventArgs { public Message Message { get; set; } }
    /// <summary>
    /// A game message as Decal's network filter passed it on: Type is its opcode, RawData the whole message (the opcode
    /// first). Fields by name are read for what the plugins ask: a game event's "event" and "object" (an ID answer's
    /// "success"), a game action's "action", "object", "target", "spell", the character list's "slotCount". Fields by
    /// number are the message's 4-byte words after the opcode.
    /// </summary>
    public class Message
    {
        public int Type;
        internal int Event;
        private readonly byte[] _raw = Array.Empty<byte>();
        public Message() { }
        internal Message(uint opcode, byte[] payload)
        {
            Type = unchecked((int)opcode);
            _raw = new byte[4 + (payload?.Length ?? 0)];
            BitConverter.GetBytes(opcode).CopyTo(_raw, 0);
            payload?.CopyTo(_raw, 4);
        }
        public byte[] RawData => _raw;
        public int Count => Math.Max(0, (_raw.Length - 4) / 4);
        public string Name(int i) => "";
        public object this[string name] => Field(name);
        public object this[int i] => Word(4 + 4 * i);
        public T Value<T>(string name)
        {
            object v = Field(name);
            return v == null ? default : (T)Convert.ChangeType(v, typeof(T));
        }
        public T Value<T>(int index) { object v = Word(4 + 4 * index); return v == null ? default : (T)Convert.ChangeType(v, typeof(T)); }
        public MessageStruct Struct(string n) => new MessageStruct(); public MessageStruct Struct(int i) => new MessageStruct();

        private object Word(int at) => at >= 0 && at + 4 <= _raw.Length ? BitConverter.ToInt32(_raw, at) : (object)null;

        private object Field(string name)
        {
            uint t = unchecked((uint)Type);
            if (t == 0xF7B0)   // a game event: character, sequence, event, then the event's own
            {
                if (_raw.Length < 16) return name == "event" && Event != 0 ? Event : (object)null;
                int ev = BitConverter.ToInt32(_raw, 12);
                switch (name)
                {
                    case "character": return Word(4);
                    case "sequence": return Word(8);
                    case "event": return ev;
                    case "object": return Word(16);
                    case "success": return ev == 0x00C9 ? Word(24) : null;   // IdentifyObjectResponse: object, flags, success
                    case "flags": return ev == 0x00C9 ? Word(20) : null;
                }
                return null;
            }
            if (t == 0xF7B1)   // a game action sent: sequence, action, then the action's own
            {
                int act = _raw.Length >= 12 ? BitConverter.ToInt32(_raw, 8) : 0;
                switch (name)
                {
                    case "sequence": return Word(4);
                    case "action": return act;
                    case "object": return Word(12);
                    case "target": return act == 0x004A ? Word(12) : act == 0x0035 ? Word(16) : null;
                    case "spell": return act == 0x004A ? Word(16) : act == 0x0048 ? Word(12) : null;
                    case "container": return act == 0x0019 ? Word(16) : null;
                    case "slot": return act == 0x0019 ? Word(20) : null;
                }
                return null;
            }
            if (t == 0xF658 && name == "slotCount")   // the character list: ?, count, each (id, name, delete timeout), ?, slots
            {
                try
                {
                    int at = 8, n = BitConverter.ToInt32(_raw, at); at += 4;
                    for (int i = 0; i < n; i++)
                    {
                        at += 4;
                        int len = BitConverter.ToUInt16(_raw, at);
                        at += 2 + len; at = (at + 3) & ~3;   // (a 16-bit length, the text, padded to 4)
                        at += 4;
                    }
                    at += 4;
                    return Word(at);
                }
                catch { return null; }
            }
            return null;
        }
    }
    public class DecalWrapper { public IntPtr Hwnd => IntPtr.Zero; }

    public class EchoFilter
    {
        public event EventHandler<NetworkMessageEventArgs> ClientDispatch, ServerDispatch;
        internal void RaiseServer(Message m) { var e = new NetworkMessageEventArgs { Message = m }; Hitch.Each(ServerDispatch, "server message", h => ((EventHandler<NetworkMessageEventArgs>)h)(this, e)); }
        internal void RaiseClient(Message m) { try { ClientDispatch?.Invoke(this, new NetworkMessageEventArgs { Message = m }); } catch { } }
    }

    /// <summary>Decal's core: the world, your character, actions, and the events (chat, every frame, commands typed).</summary>
    public class CoreManager
    {
        private static CoreManager _current;
        public static CoreManager Current => _current ??= new CoreManager();

        public HooksWrapper Actions { get; } = new HooksWrapper();
        public WorldFilter WorldFilter { get; } = new WorldFilter();
        public CharacterFilter CharacterFilter { get; } = new CharacterFilter();
        public D3DService D3DService { get; } = new D3DService();
        public EchoFilter EchoFilter { get; } = new EchoFilter();
        public global::Decal.Filters.FileService FileService { get; } = new global::Decal.Filters.FileService();
        public DecalWrapper Decal { get; } = new DecalWrapper();
        public event EventHandler<StatusTextInterceptEventArgs> StatusBoxMessage;
        public int QueryKeyBoardMap(string name) => 0;
        public T Filter<T>() where T : class => null;

        public event EventHandler<ChatTextInterceptEventArgs> ChatBoxMessage;
        public event EventHandler<ChatParserInterceptEventArgs> CommandLineText;
        public event EventHandler RenderFrame;
        public event EventHandler<ItemSelectedEventArgs> ItemSelected;
        public event EventHandler<ChatClickInterceptEventArgs> ChatNameClicked;
        public event EventHandler<WindowMessageEventArgs> WindowMessage;
        public event EventHandler<StatusTextInterceptEventArgs> StatusTextIntercept;
        public event EventHandler<EventArgs> ContainerOpened;

        /// <summary>A chat line to the plugins; true when one ate it (it isn't shown).</summary>
        internal bool RaiseChat(string text, ACGodot.UI.ChatKind kind)
        {
            if (kind == ACGodot.UI.ChatKind.Plugin) return false;   // (Decal never shows a plugin its own lines)
            int color = kind switch
            {
                ACGodot.UI.ChatKind.Combat => 6, ACGodot.UI.ChatKind.Magic => 7, ACGodot.UI.ChatKind.Tells => 3, ACGodot.UI.ChatKind.AreaChat => 2,
                ACGodot.UI.ChatKind.Errors => 22, _ => 0,
            };
            var e = new ChatTextInterceptEventArgs(text.EndsWith("\n") ? text : text + "\n", color, 1);
            Hitch.Each(ChatBoxMessage, "chat", h => ((EventHandler<ChatTextInterceptEventArgs>)h)(this, e));
            return e.Eat;
        }

        internal void RaiseFrame()
        {
            Hitch.Each(RenderFrame, "frame", h => ((EventHandler)h)(this, EventArgs.Empty));
        }

        /// <summary>A /command typed: the plugins' turn first (true: one took it).</summary>
        public bool RaiseCommand(string text)
        {
            var e = new ChatParserInterceptEventArgs(text);
            foreach (EventHandler<ChatParserInterceptEventArgs> h in CommandLineText?.GetInvocationList() ?? Array.Empty<Delegate>())
            {
                try { h(this, e); } catch (Exception ex) { Godot.GD.PushWarning("plugin command: " + ex); }
                if (e.Eat) return true;
            }
            return false;
        }

        internal void RaiseSelected(int id) { try { ItemSelected?.Invoke(this, new ItemSelectedEventArgs(id)); } catch { } }
    }

    public class ItemSelectedEventArgs : EventArgs { public ItemSelectedEventArgs(int id) { ItemGuid = id; } public int ItemGuid { get; } }
    public class ChatClickInterceptEventArgs : EventArgs { public string Text { get; set; } public int Id { get; set; } public bool Eat { get; set; } }
    public class WindowMessageEventArgs : EventArgs { public int Msg; public int WParam; public int LParam; public bool Eat; }
    public class StatusTextInterceptEventArgs : EventArgs { public string Text { get; set; } public bool Eat { get; set; } }

    // the attributes Decal plugins put on their classes and handlers (nothing reads them here)
    [AttributeUsage(AttributeTargets.All, AllowMultiple = true)] public sealed class WireUpBaseEventsAttribute : Attribute { }
    [AttributeUsage(AttributeTargets.All, AllowMultiple = true)] public sealed class FriendlyNameAttribute : Attribute { public FriendlyNameAttribute(string n) { } }
    [AttributeUsage(AttributeTargets.All, AllowMultiple = true)] public sealed class BaseEventAttribute : Attribute { public BaseEventAttribute(string a, string b = null) { } }

    /// <summary>A Decal plugin's base class (the ACGodot side calls Startup / Shutdown).</summary>
    public abstract class PluginBase
    {
        protected Wrappers.PluginHost Host { get; private set; } = new Wrappers.PluginHost();
        protected CoreManager Core => CoreManager.Current;
        protected abstract void Startup();
        protected abstract void Shutdown();
        public void RunStartup() => Startup();
        public void RunShutdown() => Shutdown();
    }
}


namespace Decal.Filters
{
    /// <summary>Decal's file service, as far as plugins use it: the spell table (a spell's name and nature by its number),
    /// from the game's own files as ACGodot read them.</summary>
    public class FileService
    {
        public SpellTable SpellTable { get; } = new SpellTable();
    }

    public class SpellTable
    {
        public Spell GetById(int id)
        {
            var all = ACGodot.DecalShim.Bridge.Host?.Magic?.All;
            return all != null && all.TryGetValue(id, out var s) ? new Spell(s) : null;
        }
        public Spell GetByName(string name)
        {
            var all = ACGodot.DecalShim.Bridge.Host?.Magic?.All;
            if (all == null || string.IsNullOrEmpty(name)) return null;
            foreach (var s in all.Values) if (string.Equals(s.Name, name, System.StringComparison.OrdinalIgnoreCase)) return new Spell(s);
            return null;
        }
        public int Length => ACGodot.DecalShim.Bridge.Host?.Magic?.All.Count ?? 0;
    }

    public class Spell
    {
        private readonly ACGodot.Magic.Spell _s;
        internal Spell(ACGodot.Magic.Spell s) { _s = s; }
        public int Id => _s.Id;
        public string Name => _s.Name;
        public string Description => _s.Description;
        public int Mana => _s.Mana;
        public int Difficulty => _s.Power;
        public double Duration => _s.Duration;
        public int IconId => unchecked((int)_s.Icon);
        public int Family => (int)_s.Category;
        public int Flags => (int)_s.Flags;
        public bool IsDebuff => ((int)_s.Flags & 0x4) == 0;       // not marked beneficial
        public bool IsOffensive => IsDebuff;
        public bool IsUntargetted => _s.NoTarget;
        public bool IsFellowship => ((int)_s.Flags & 0x2000) != 0;
        public int Type => (int)_s.Type;
        public int School => (int)_s.School;
        public override string ToString() => _s.Name;
    }
}
