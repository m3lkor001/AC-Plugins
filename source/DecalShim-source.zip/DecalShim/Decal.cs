using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using ACGodot.DecalShim;
using Decal.Adapter.Wrappers;

namespace Decal.Adapter
{
    public class ChatTextInterceptEventArgs : EventArgs
    {
        public ChatTextInterceptEventArgs(string text, int color, int target) { Text = text; Color = color; Target = target; }
        public string Text { get; set; }
        public int Color { get; set; }
        public int Target { get; set; }
        public bool Eat { get; set; }
    }

    public class ChatParserInterceptEventArgs : EventArgs
    {
        public ChatParserInterceptEventArgs(string text) { Text = text; }
        public string Text { get; set; }
        public bool Eat { get; set; }
    }

    public class NetworkMessageEventArgs : EventArgs { public Message Message { get; set; } }
    public class Message
    {
        public int Type; internal int Event; public int Count => 0; public byte[] RawData => Array.Empty<byte>(); public string Name(int i) => "";
        public object this[string name] => null; public object this[int i] => null;
        public T Value<T>(string name) => name == "event" && Event != 0 ? (T)Convert.ChangeType(Event, typeof(T)) : default; public T Value<T>(int index) => default;
        public MessageStruct Struct(string n) => new MessageStruct(); public MessageStruct Struct(int i) => new MessageStruct();
    }
    public class DecalWrapper { public IntPtr Hwnd => IntPtr.Zero; }

    public class EchoFilter
    {
        public event EventHandler<NetworkMessageEventArgs> ClientDispatch, ServerDispatch;
        internal void RaiseServer(Message m) { try { ServerDispatch?.Invoke(this, new NetworkMessageEventArgs { Message = m }); } catch { } }
    }

    /// <summary>Decal's core: the world, your character, actions, and the events (chat, every frame, commands typed).</summary>
    public class CoreManager
    {
        private static CoreManager _current;
        public static CoreManager Current => _current ??= new CoreManager();

        public HooksWrapper Actions { get; } = new HooksWrapper();
        public WorldFilter WorldFilter { get; } = new WorldFilter();
        public CharacterFilter CharacterFilter { get; } = new CharacterFilter();
        public D3DService D3DService { get; } = new D3DService();
        public EchoFilter EchoFilter { get; } = new EchoFilter();
        public object FileService => null;
        public DecalWrapper Decal { get; } = new DecalWrapper();
        public event EventHandler<StatusTextInterceptEventArgs> StatusBoxMessage;
        public int QueryKeyBoardMap(string name) => 0;
        public T Filter<T>() where T : class => null;

        public event EventHandler<ChatTextInterceptEventArgs> ChatBoxMessage;
        public event EventHandler<ChatParserInterceptEventArgs> CommandLineText;
        public event EventHandler RenderFrame;
        public event EventHandler<ItemSelectedEventArgs> ItemSelected;
        public event EventHandler<ChatClickInterceptEventArgs> ChatNameClicked;
        public event EventHandler<WindowMessageEventArgs> WindowMessage;
        public event EventHandler<StatusTextInterceptEventArgs> StatusTextIntercept;
        public event EventHandler<EventArgs> ContainerOpened;

        /// <summary>A chat line to the plugins; true when one ate it (it isn't shown).</summary>
        internal bool RaiseChat(string text, ACGodot.UI.ChatKind kind)
        {
            if (kind == ACGodot.UI.ChatKind.Plugin) return false;   // (Decal never shows a plugin its own lines)
            int color = kind switch
            {
                ACGodot.UI.ChatKind.Combat => 6, ACGodot.UI.ChatKind.Magic => 7, ACGodot.UI.ChatKind.Tells => 3, ACGodot.UI.ChatKind.AreaChat => 2,
                ACGodot.UI.ChatKind.Errors => 22, _ => 0,
            };
            var e = new ChatTextInterceptEventArgs(text.EndsWith("\n") ? text : text + "\n", color, 1);
            foreach (EventHandler<ChatTextInterceptEventArgs> h in ChatBoxMessage?.GetInvocationList() ?? Array.Empty<Delegate>())
            {
                try { h(this, e); } catch (Exception ex) { Godot.GD.PushWarning("plugin chat: " + ex); }
            }
            return e.Eat;
        }

        internal void RaiseFrame()
        {
            foreach (EventHandler h in RenderFrame?.GetInvocationList() ?? Array.Empty<Delegate>())
            {
                try { h(this, EventArgs.Empty); } catch (Exception ex) { Godot.GD.PushWarning("plugin frame: " + ex); }
            }
        }

        /// <summary>A /command typed: the plugins' turn first (true: one took it).</summary>
        public bool RaiseCommand(string text)
        {
            var e = new ChatParserInterceptEventArgs(text);
            foreach (EventHandler<ChatParserInterceptEventArgs> h in CommandLineText?.GetInvocationList() ?? Array.Empty<Delegate>())
            {
                try { h(this, e); } catch (Exception ex) { Godot.GD.PushWarning("plugin command: " + ex); }
                if (e.Eat) return true;
            }
            return false;
        }

        internal void RaiseSelected(int id) { try { ItemSelected?.Invoke(this, new ItemSelectedEventArgs(id)); } catch { } }
    }

    public class ItemSelectedEventArgs : EventArgs { public ItemSelectedEventArgs(int id) { ItemGuid = id; } public int ItemGuid { get; } }
    public class ChatClickInterceptEventArgs : EventArgs { public string Text { get; set; } public int Id { get; set; } public bool Eat { get; set; } }
    public class WindowMessageEventArgs : EventArgs { public int Msg; public int WParam; public int LParam; public bool Eat; }
    public class StatusTextInterceptEventArgs : EventArgs { public string Text { get; set; } public bool Eat { get; set; } }

    // the attributes Decal plugins put on their classes and handlers (nothing reads them here)
    [AttributeUsage(AttributeTargets.All, AllowMultiple = true)] public sealed class WireUpBaseEventsAttribute : Attribute { }
    [AttributeUsage(AttributeTargets.All, AllowMultiple = true)] public sealed class FriendlyNameAttribute : Attribute { public FriendlyNameAttribute(string n) { } }
    [AttributeUsage(AttributeTargets.All, AllowMultiple = true)] public sealed class BaseEventAttribute : Attribute { public BaseEventAttribute(string a, string b = null) { } }

    /// <summary>A Decal plugin's base class (the ACGodot side calls Startup / Shutdown).</summary>
    public abstract class PluginBase
    {
        protected Wrappers.PluginHost Host { get; private set; } = new Wrappers.PluginHost();
        protected CoreManager Core => CoreManager.Current;
        protected abstract void Startup();
        protected abstract void Shutdown();
        public void RunStartup() => Startup();
        public void RunShutdown() => Shutdown();
    }
}
