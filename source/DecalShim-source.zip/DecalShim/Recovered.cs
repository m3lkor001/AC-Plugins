// The parts of the Decal stand-in whose own source files were lost: recovered from ACGodot.DecalShim.dll (so without
// their comments). Enums and small types Decal plugins expect, and the spell tables read from the game's dat.
using ACE.DatLoader.Entity;
using ACGodot.DecalShim;
using ACGodot.Magic;
using DatReaderWriter.Enums;
using Godot;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System;

namespace ACE.DatLoader.Entity
{
	public class SpellBase
	{
		public string Name { get; set; } = "";

		public string Desc { get; set; } = "";

		public uint School { get; set; }

		public uint Category { get; set; }

		public uint Bitfield { get; set; }

		public uint Power { get; set; }

		public uint BaseMana { get; set; }

		public double Duration { get; set; }

		public uint Icon { get; set; }

		public float BaseRangeConstant { get; set; }

		public float BaseRangeMod { get; set; }

		public List<uint> Formula { get; set; } = new List<uint>();

		public uint MetaSpellType { get; set; }
	}
}

namespace ACE.DatLoader.Entity
{
	public class SpellComponentBase
	{
		public string Name { get; set; } = "";

		public uint Category { get; set; }

		public uint Icon { get; set; }

		public uint Type { get; set; }
	}
}

namespace ACE.DatLoader.FileTypes
{
	public static class SpellTable
	{
		public static List<uint> GetSpellFormula(ACE.DatLoader.SpellTable table, uint id, string account)
		{
			SpellBase value;
			return (table != null && table.Spells.TryGetValue(id, out value)) ? value.Formula : new List<uint>();
		}
	}
}

namespace ACE.DatLoader
{
	public class PortalDatDatabase
	{
		public SpellTable SpellTable { get; } = new SpellTable();

		public SpellComponentsTable SpellComponentsTable => null;

		internal static PortalDatDatabase FromGame()
		{
			MagicSystem magicSystem = Bridge.Host?.Magic;
			if (magicSystem == null)
			{
				return null;
			}
			PortalDatDatabase portalDatDatabase = new PortalDatDatabase();
			foreach (Spell value in magicSystem.All.Values)
			{
				MagicSchool school = value.School;
				if (1 == 0)
				{
				}
				int num = school switch
				{
					MagicSchool.WarMagic => 1, 
					MagicSchool.LifeMagic => 2, 
					MagicSchool.ItemEnchantment => 3, 
					MagicSchool.CreatureEnchantment => 4, 
					_ => 5, 
				};
				if (1 == 0)
				{
				}
				int school2 = num;
				portalDatDatabase.SpellTable.Spells[(uint)value.Id] = new SpellBase
				{
					Name = value.Name,
					Desc = value.Description,
					School = (uint)school2,
					Category = (uint)value.Category,
					Bitfield = (uint)value.Flags,
					Power = (uint)value.Power,
					BaseMana = (uint)value.Mana,
					Duration = value.Duration,
					Icon = value.Icon,
					BaseRangeConstant = value.RangeConstant,
					BaseRangeMod = value.RangeMod,
					MetaSpellType = (uint)value.Type
				};
			}
			return portalDatDatabase;
		}
	}
}

namespace ACE.DatLoader
{
	public class SpellComponentsTable
	{
		public Dictionary<uint, SpellComponentBase> SpellComponents { get; } = new Dictionary<uint, SpellComponentBase>();
	}
}

namespace ACE.DatLoader
{
	public class SpellTable
	{
		public Dictionary<uint, SpellBase> Spells { get; } = new Dictionary<uint, SpellBase>();
	}
}

namespace ACGodot.DecalShim
{
	public static class Pictures
	{
		public static byte[] LoadRgba(string file, out int width, out int height)
		{
			width = (height = 0);
			try
			{
				byte[] array = File.ReadAllBytes(file);
				if (array.Length > 6 && array[0] == 71 && array[1] == 73 && array[2] == 70)
				{
					return Gif(array, out width, out height);
				}
				Image image = new Image();
				string text = Path.GetExtension(file).ToLowerInvariant();
				if (1 == 0)
				{
				}
				Error error;
				switch (text)
				{
				case ".png":
					error = image.LoadPngFromBuffer(array);
					break;
				case ".jpg":
				case ".jpeg":
					error = image.LoadJpgFromBuffer(array);
					break;
				case ".bmp":
					error = image.LoadBmpFromBuffer(array);
					break;
				case ".webp":
					error = image.LoadWebpFromBuffer(array);
					break;
				default:
					error = ((image.LoadPngFromBuffer(array) == Error.Ok) ? Error.Ok : image.LoadJpgFromBuffer(array));
					break;
				}
				if (1 == 0)
				{
				}
				Error error2 = error;
				if (error2 != Error.Ok)
				{
					return null;
				}
				image.Convert(Image.Format.Rgba8);
				width = image.GetWidth();
				height = image.GetHeight();
				return image.GetData();
			}
			catch
			{
				return null;
			}
		}

		public static ImageTexture Texture(string file)
		{
			byte[] array = LoadRgba(file, out var width, out var height);
			if (array == null || width <= 0 || height <= 0)
			{
				return null;
			}
			return ImageTexture.CreateFromImage(Image.CreateFromData(width, height, useMipmaps: false, Image.Format.Rgba8, array));
		}

		private static byte[] Gif(byte[] d, out int width, out int height)
		{
			int num = 6;
			width = d[num] | (d[num + 1] << 8);
			height = d[num + 2] | (d[num + 3] << 8);
			int num2 = d[num + 4];
			num += 7;
			byte[] array = null;
			if ((num2 & 0x80) != 0)
			{
				int num3 = 3 << (num2 & 7) + 1;
				array = new byte[num3];
				Array.Copy(d, num, array, 0, num3);
				num += num3;
			}
			byte[] array2 = new byte[width * height * 4];
			int num4 = -1;
			for (; num < d.Length; num++)
			{
				switch (d[num++])
				{
				case 33:
				{
					byte b = d[num++];
					if (b == 249 && d[num] >= 4 && (d[num + 1] & 1) != 0)
					{
						num4 = d[num + 4];
					}
					for (; num < d.Length && d[num] != 0; num += d[num] + 1)
					{
					}
					continue;
				}
				case 44:
				{
					int num5 = d[num] | (d[num + 1] << 8);
					int num6 = d[num + 2] | (d[num + 3] << 8);
					int num7 = d[num + 4] | (d[num + 5] << 8);
					int num8 = d[num + 6] | (d[num + 7] << 8);
					int num9 = d[num + 8];
					num += 9;
					byte[] array3 = array;
					if ((num9 & 0x80) != 0)
					{
						int num10 = 3 << (num9 & 7) + 1;
						array3 = new byte[num10];
						Array.Copy(d, num, array3, 0, num10);
						num += num10;
					}
					bool flag = (num9 & 0x40) != 0;
					int minCode = d[num++];
					using MemoryStream memoryStream = new MemoryStream();
					for (; num < d.Length && d[num] != 0; num += d[num] + 1)
					{
						memoryStream.Write(d, num + 1, d[num]);
					}
					num++;
					byte[] array4 = Lzw(memoryStream.ToArray(), minCode, num7 * num8);
					if (array3 == null)
					{
						return array2;
					}
					int[] array5 = new int[num8];
					if (!flag)
					{
						for (int i = 0; i < num8; i++)
						{
							array5[i] = i;
						}
					}
					else
					{
						int num11 = 0;
						(int, int)[] array6 = new (int, int)[4]
						{
							(0, 8),
							(4, 8),
							(2, 4),
							(1, 2)
						};
						for (int j = 0; j < array6.Length; j++)
						{
							(int, int) tuple = array6[j];
							int item = tuple.Item1;
							int item2 = tuple.Item2;
							for (int k = item; k < num8; k += item2)
							{
								array5[num11++] = k;
							}
						}
					}
					for (int l = 0; l < num8; l++)
					{
						int num12 = num6 + array5[l];
						if (num12 < 0 || num12 >= height)
						{
							continue;
						}
						for (int m = 0; m < num7; m++)
						{
							int num13 = l * num7 + m;
							if (num13 >= array4.Length)
							{
								break;
							}
							int num14 = array4[num13];
							if (num14 != num4 && num14 * 3 + 2 < array3.Length)
							{
								int num15 = num5 + m;
								if (num15 >= 0 && num15 < width)
								{
									int num16 = (num12 * width + num15) * 4;
									array2[num16] = array3[num14 * 3];
									array2[num16 + 1] = array3[num14 * 3 + 1];
									array2[num16 + 2] = array3[num14 * 3 + 2];
									array2[num16 + 3] = byte.MaxValue;
								}
							}
						}
					}
					return array2;
				}
				}
				break;
			}
			return array2;
		}

		private static byte[] Lzw(byte[] data, int minCode, int count)
		{
			byte[] array = new byte[count];
			int num = 1 << minCode;
			int num2 = num + 1;
			int num3 = minCode + 1;
			int num4 = num + 2;
			short[] array2 = new short[4096];
			byte[] array3 = new byte[4096];
			byte[] array4 = new byte[4097];
			for (int i = 0; i < num; i++)
			{
				array2[i] = -1;
				array3[i] = (byte)i;
			}
			int j = 0;
			int num5 = 0;
			int num6 = 0;
			int num7 = 0;
			int num8 = -1;
			byte b = 0;
			while (num7 < count)
			{
				for (; j < num3; j += 8)
				{
					if (num6 >= data.Length)
					{
						return array;
					}
					num5 |= data[num6++] << j;
				}
				int num9 = num5 & ((1 << num3) - 1);
				num5 >>= num3;
				j -= num3;
				if (num9 == num)
				{
					num3 = minCode + 1;
					num4 = num + 2;
					num8 = -1;
					continue;
				}
				if (num9 == num2)
				{
					break;
				}
				if (num8 == -1)
				{
					if (num9 >= num)
					{
						break;
					}
					array[num7++] = array3[num9];
					num8 = num9;
					b = array3[num9];
					continue;
				}
				int num10 = 0;
				int num11 = num9;
				if (num9 >= num4)
				{
					array4[num10++] = b;
					num11 = num8;
				}
				while (num11 >= num && num10 < array4.Length - 1)
				{
					array4[num10++] = array3[num11];
					num11 = array2[num11];
				}
				if (num11 < 0 || num11 >= 4096)
				{
					break;
				}
				array4[num10++] = array3[num11];
				b = array3[num11];
				while (num10 > 0 && num7 < count)
				{
					array[num7++] = array4[--num10];
				}
				if (num4 < 4096)
				{
					array2[num4] = (short)num8;
					array3[num4] = b;
					num4++;
					if (num4 == 1 << num3 && num3 < 12)
					{
						num3++;
					}
				}
				num8 = num9;
			}
			return array;
		}
	}
}

namespace Decal.Adapter.Wrappers
{
	public class AccountCharInfo
	{
		public int Id { get; set; }

		public string Name { get; set; } = "";

		public int Index { get; set; }

		public int DeleteTimeout { get; set; }
	}
}

namespace Decal.Adapter.Wrappers
{
	[CLSCompliant(true)]
	public enum AddRemoveEventType
	{
		Add,
		Delete
	}
}

namespace Decal.Adapter.Wrappers
{
	[CLSCompliant(true)]
	public enum AttributeType
	{
		CurrentStrength = 1,
		CurrentEndurance,
		CurrentQuickness,
		CurrentCoordination,
		CurrentFocus,
		CurrentSelf,
		BaseStrength,
		BaseEndurance,
		BaseQuickness,
		BaseCoordination,
		BaseFocus,
		BaseSelf
	}
}

namespace Decal.Adapter.Wrappers
{
	[CLSCompliant(true)]
	public enum Augmentations
	{
		ReinforcementLugians = 218,
		BleearghFortitude = 219,
		OswaldEnchancement = 220,
		SiraluunBlessing = 221,
		EnduringCalm = 222,
		SteadfastWill = 223,
		CiandraEssence = 224,
		YoshiEssence = 225,
		JibrilEssence = 226,
		CeldisethEssence = 227,
		KogaEssence = 228,
		ShadowSeventhMule = 229,
		MightSeventhMule = 230,
		ClutchMiser = 231,
		EnduringEnchantment = 232,
		CriticalProtection = 233,
		QuickLearner = 234,
		CiandraFortune = 235,
		CharmedSmith = 236,
		InnateRenewal = 237,
		ArchmageEndurance = 238,
		BladeTurner = 240,
		ArrowTurner = 241,
		MaceTurner = 242,
		CausticEnhancement = 243,
		FieryEnchancment = 244,
		IcyEnchancement = 245,
		LightningEnhancement = 246,
		InfusedCreature = 294,
		InfusedItem = 295,
		InfusedLife = 296,
		InfusedWar = 297,
		EyeRemorseless = 298,
		HandRemorseless = 299,
		MasterSteelCircle = 300,
		MasterFocusedEyed = 301,
		MasterFiveFoldPath = 302,
		FrenzySlayer = 309,
		IronSkinInvincible = 310,
		JackOfAllTrades = 326,
		InfusedVoid = 328,
		[Obsolete("Use InfusedVoid")]
		UnknownAug1 = InfusedVoid,
		[Obsolete("Not an aug")]
		UnknownAug2 = 329,
		[Obsolete("Not an aug")]
		UnknownAug3 = 330,
		[Obsolete("Not an aug")]
		UnknownAug4 = 331,
		[Obsolete("Not an aug")]
		UnknownAug5 = 332,
		AuraValor = 333,
		AuraProtection = 334,
		AuraGlory = 335,
		AuraTemperance = 336,
		AuraSurge = 337,
		[Obsolete("Not an aug")]
		UnknownAug6 = AuraSurge,
		AuraAethericVision = 338,
		AuraManaFlow = 339,
		AuraManaInfusion = 340,
		[Obsolete("Use AuraManaInfusion")]
		UnknownAug7 = AuraManaInfusion,
		AuraVitality = 341,
		[Obsolete("Use AuraVitality")]
		UnknownAug8 = AuraVitality,
		AuraPurity = 342,
		AuraCraftsman = 343,
		AuraSpecialization = 344,
		AuraWorld = 365
	}
}

namespace Decal.Adapter.Wrappers
{
	public enum BoolValueKey
	{
		Lockable = 201326592,
		Inscribable = 201326593,
		Open = 2,
		Locked = 3,
		HookVisibility = 24,
		UnlimitedUses = 63,
		CanBeSold = 69,
		Retained = 91,
		Ivoryable = 99,
		Dyeable = 100,
		AwayFromKeyboard = 110
	}
}

namespace Decal.Adapter.Wrappers
{
	[CLSCompliant(true)]
	public enum CastEventType
	{
		Untargetted,
		Targetted
	}
}

namespace Decal.Adapter.Wrappers
{
	[CLSCompliant(true)]
	public enum CharFilterAttributeType
	{
		Strength = 1,
		Endurance,
		Quickness,
		Coordination,
		Focus,
		Self
	}
}

namespace Decal.Adapter.Wrappers
{
	public enum CharFilterIndex
	{
		Vassals,
		Enchantments,
		Vitals,
		Attributes,
		Skills,
		Characters,
		Spells,
		Augmentations,
		EffectiveAttributes,
		EffectiveVitals,
		EffectiveSkills
	}
}

namespace Decal.Adapter.Wrappers
{
	[CLSCompliant(true)]
	public enum CharFilterSkillType
	{
		Axe = 1,
		Bow = 2,
		Crossbow = 3,
		Dagger = 4,
		Mace = 5,
		MeleeDefense = 6,
		MissileDefense = 7,
		Spear = 9,
		Staff = 10,
		Sword = 11,
		ThrownWeapons = 12,
		Unarmed = 13,
		ArcaneLore = 14,
		MagicDefense = 15,
		ManaConversion = 16,
		ItemTinkering = 18,
		AssessPerson = 19,
		Deception = 20,
		Healing = 21,
		Jump = 22,
		Lockpick = 23,
		Run = 24,
		AssessCreature = 27,
		WeaponTinkering = 28,
		ArmorTinkering = 29,
		MagicItemTinkering = 30,
		CreatureEnchantment = 31,
		ItemEnchantment = 32,
		LifeMagic = 33,
		WarMagic = 34,
		Leadership = 35,
		Loyalty = 36,
		Fletching = 37,
		Alchemy = 38,
		Cooking = 39,
		Salvaging = 40,
		TwoHandedCombat = 41,
		Gearcraft = 42,
		VoidMagic = 43,
		HeavyWeapons = 44,
		LightWeapons = 45,
		FinesseWeapons = 46,
		MissileWeapons = 47,
		Shield = 48,
		DualWield = 49,
		Recklessness = 50,
		SneakAttack = 51,
		DirtyFighting = 52,
		Summoning = 54
	}
}

namespace Decal.Adapter.Wrappers
{
	[CLSCompliant(true)]
	public enum CharFilterVitalType
	{
		Health = 2,
		Stamina = 4,
		Mana = 6
	}
}

namespace Decal.Adapter.Wrappers
{
	[CLSCompliant(true)]
	public enum CombatState
	{
		Peace = 1,
		Melee = 2,
		Missile = 4,
		Magic = 8
	}
}

namespace Decal.Adapter.Wrappers
{
	public enum D3DShape
	{
		HorizontalArrow,
		VerticalArrow,
		Ring,
		Cylinder,
		Sphere,
		Cube,
		TiltedCube
	}
}

namespace Decal.Adapter.Wrappers
{
	public enum D3DTextType
	{
		Text2D,
		Text3D
	}
}

namespace Decal.Adapter.Wrappers
{
	public class DeathEventArgs : EventArgs
	{
		public string Text { get; set; } = "";
	}
}

namespace Decal.Adapter.Wrappers
{
	public enum DoubleValueKey
	{
		SlashProt = 167772160,
		PierceProt = 167772161,
		BludgeonProt = 167772162,
		AcidProt = 167772163,
		LightningProt = 167772164,
		FireProt = 167772165,
		ColdProt = 167772166,
		Heading = 167772167,
		ApproachDistance = 167772168,
		SalvageWorkmanship = 167772169,
		Scale = 167772170,
		Variance = 167772171,
		AttackBonus = 167772172,
		Range = 167772173,
		DamageBonus = 167772174,
		ManaRateOfChange = 5,
		MeleeDefenseBonus = 29,
		ManaTransferEfficiency = 87,
		HealingKitRestoreBonus = 100,
		ManaStoneChanceDestruct = 137,
		ManaCBonus = 144,
		MissileDBonus = 149,
		MagicDBonus = 150,
		ElementalDamageVersusMonsters = 152
	}
}

namespace Decal.Adapter.Wrappers
{
	[CLSCompliant(true)]
	public enum FellowshipEventType
	{
		Create,
		Quit,
		Dismiss,
		Recruit,
		Disband
	}
}

namespace Decal.Adapter.Wrappers
{
	[CLSCompliant(true)]
	public enum FontWeight
	{
		Black = 900,
		Bold = 700,
		DemiBold = 600,
		DoNotCare = 0,
		ExtraBold = 800,
		ExtraLight = 200,
		Heavy = Black,
		Light = 300,
		Medium = 500,
		Normal = 400,
		Regular = Normal,
		SemiBold = DemiBold,
		Thin = 100,
		UltraBold = ExtraBold,
		UltraLight = ExtraLight
	}
}

namespace Decal.Adapter.Wrappers
{
	[CLSCompliant(true)]
	public enum LogoffEventType
	{
		Requested,
		Authorized
	}
}

namespace Decal.Adapter.Wrappers
{
	public enum LongValueKey
	{
		Type = 218103808,
		Icon = 218103809,
		Container = 218103810,
		Landblock = 218103811,
		ItemSlots = 218103812,
		PackSlots = 218103813,
		StackCount = 218103814,
		StackMax = 218103815,
		AssociatedSpell = 218103816,
		SlotLegacy = 218103817,
		Wielder = 218103818,
		WieldingSlot = 218103819,
		Monarch = 218103820,
		Coverage = 218103821,
		EquipableSlots = 218103822,
		EquipType = 218103823,
		IconOutline = 218103824,
		MissileType = 218103825,
		UsageMask = 218103826,
		HouseOwner = 218103827,
		HookMask = 218103828,
		HookType = 218103829,
		Model = 218103830,
		Flags = 218103831,
		CreateFlags1 = 218103832,
		CreateFlags2 = 218103833,
		Category = 218103834,
		Behavior = 218103835,
		MagicDef = 218103836,
		SpecialProps = 218103837,
		SpellCount = 218103838,
		WeapSpeed = 218103839,
		EquipSkill = 218103840,
		DamageType = 218103841,
		MaxDamage = 218103842,
		Unknown10 = 218103843,
		Unknown100000 = 218103844,
		Unknown800000 = 218103845,
		Unknown8000000 = 218103846,
		PhysicsDataFlags = 218103847,
		ActiveSpellCount = 218103848,
		IconOverlay = 218103849,
		IconUnderlay = 218103850,
		Species = 2,
		Burden = 5,
		EquippedSlots = 10,
		RareId = 17,
		Value = 19,
		TotalValue = 20,
		SkillCreditsAvail = 24,
		CreatureLevel = 25,
		RestrictedToToD = 26,
		ArmorLevel = 28,
		Rank = 30,
		Bonded = 33,
		NumberFollowers = 35,
		Unenchantable = 36,
		LockpickDifficulty = 38,
		Deaths = 43,
		WandElemDmgType = 45,
		MinLevelRestrict = 86,
		MaxLevelRestrict = 87,
		LockpickSkillBonus = 88,
		AffectsVitalId = 89,
		AffectsVitalAmt = 90,
		HealKitSkillBonus = AffectsVitalAmt,
		UsesTotal = 91,
		UsesRemaining = 92,
		DateOfBirth = 98,
		Workmanship = 105,
		Spellcraft = 106,
		CurrentMana = 107,
		MaximumMana = 108,
		LoreRequirement = 109,
		RankRequirement = 110,
		PortalRestrictions = 111,
		Gender = 113,
		Attuned = 114,
		SkillLevelReq = 115,
		ManaCost = 117,
		Age = 125,
		XPForVPReduction = 129,
		Material = 131,
		WieldReqType = 158,
		WieldReqAttribute = 159,
		WieldReqValue = 160,
		SlayerSpecies = 166,
		NumberItemsSalvagedFrom = 170,
		NumberTimesTinkered = 171,
		DescriptionFormat = 172,
		PagesUsed = 174,
		PagesTotal = 175,
		ActivationReqSkillId = 176,
		GemSettingQty = 177,
		GemSettingType = 178,
		Imbued = 179,
		Heritage = 188,
		FishingSkill = 192,
		KeysHeld = 193,
		ElementalDmgBonus = 204,
		CleaveType = 263,
		ArmorSet = 265,
		Slot = 231735296
	}
}

namespace Decal.Adapter.Wrappers
{
	public enum ObjectClass
	{
		Unknown,
		MeleeWeapon,
		Armor,
		Clothing,
		Jewelry,
		Monster,
		Food,
		Money,
		Misc,
		MissileWeapon,
		Container,
		Gem,
		SpellComponent,
		Key,
		Portal,
		TradeNote,
		ManaStone,
		Plant,
		BaseCooking,
		BaseAlchemy,
		BaseFletching,
		CraftedCooking,
		CraftedAlchemy,
		CraftedFletching,
		Player,
		Vendor,
		Door,
		Corpse,
		Lifestone,
		HealingKit,
		Lockpick,
		WandStaffOrb,
		Bundle,
		Book,
		Journal,
		Sign,
		Housing,
		Npc,
		Foci,
		Salvage,
		Ust,
		Services,
		Scroll,
		NumObjectClasses
	}
}

namespace Decal.Adapter.Wrappers
{
	[CLSCompliant(true)]
	public enum PlayerModifyEventType
	{
		Skill,
		Attribute,
		Vital,
		Statistic,
		Allegiance,
		Augmentation
	}
}

namespace Decal.Adapter.Wrappers
{
	[CLSCompliant(true)]
	public enum PlayerXPEventType
	{
		Total,
		Unassigned
	}
}

namespace Decal.Adapter.Wrappers
{
	[CLSCompliant(true)]
	public enum PortalEventType
	{
		EnterPortal,
		ExitPortal
	}
}

namespace Decal.Adapter.Wrappers
{
	[CLSCompliant(true)]
	public enum SkillType
	{
		CurrentMeleeDefense = 6,
		CurrentMissileDefense = 7,
		CurrentArcaneLore = 14,
		CurrentMagicDefense = 15,
		CurrentManaConversion = 16,
		CurrentItemTinkering = 18,
		CurrentAssessPerson = 19,
		CurrentDeception = 20,
		CurrentHealing = 21,
		CurrentJump = 22,
		CurrentLockpick = 23,
		CurrentRun = 24,
		CurrentAssessCreature = 27,
		CurrentWeaponTinkering = 28,
		CurrentArmorTinkering = 29,
		CurrentMagicItemTinkering = 30,
		CurrentCreatureEnchantment = 31,
		CurrentItemEnchantment = 32,
		CurrentLifeMagic = 33,
		CurrentWarMagic = 34,
		CurrentLeadership = 35,
		CurrentLoyalty = 36,
		CurrentFletchingSkill = 37,
		CurrentAlchemySkill = 38,
		CurrentCookingSkill = 39,
		CurrentSkillSalvaging = 40,
		CurrentTwoHandedCombat = 41,
		CurrentGearcraft = 42,
		CurrentVoidMagic = 43,
		CurrentHeavyWeapons = 44,
		CurrentLightWeapons = 45,
		CurrentFinesseWeapons = 46,
		CurrentMissileWeapons = 47,
		CurrentShield = 48,
		CurrentDualWield = 49,
		CurrentRecklessness = 50,
		CurrentSneakAttack = 51,
		CurrentDirtyFighting = 52,
		CurrentSummoning = 54,
		BaseMeleeDefense = 56,
		BaseMissileDefense = 57,
		BaseArcaneLore = 64,
		BaseMagicDefense = 65,
		BaseManaConversion = 66,
		BaseItemTinkering = 68,
		BaseAssessPerson = 69,
		BaseDeception = 70,
		BaseHealing = 71,
		BaseJump = 72,
		BaseLockpick = 73,
		BaseRun = 74,
		BaseAssessCreature = 77,
		BaseWeaponTinkering = 78,
		BaseArmorTinkering = 79,
		BaseMagicItemTinkering = 80,
		BaseCreatureEnchantment = 81,
		BaseItemEnchantment = 82,
		BaseLifeMagic = 83,
		BaseWarMagic = 84,
		BaseLeadership = 85,
		BaseLoyalty = 86,
		BaseFletchingSkill = 87,
		BaseAlchemySkill = 88,
		BaseCookingSkill = 89,
		BaseSkillSalvaging = 90,
		BaseTwoHandedCombat = 91,
		BaseGearcraft = 92,
		BaseVoidMagic = 93,
		BaseHeavyWeapons = 94,
		BaseLightWeapons = 95,
		BaseFinesseWeapons = 96,
		BaseMissileWeapons = 97,
		BaseShield = 98,
		BaseDualWield = 99,
		BaseRecklessness = 100,
		BaseSneakAttack = 101,
		BaseDirtyFighting = 102,
		BaseSummoning = 104
	}
}

namespace Decal.Adapter.Wrappers
{
	public enum StringValueKey
	{
		SecondaryName = 184549376,
		Name = 1,
		Title = 5,
		Inscription = 7,
		InscribedBy = 8,
		FellowshipName = 10,
		UsageInstructions = 14,
		SimpleDescription = 15,
		FullDescription = 16,
		MonarchName = 21,
		OnlyActivatedBy = 25,
		Patron = 35,
		PortalDestination = 38,
		LastTinkeredBy = 39,
		ImbuedBy = 40,
		DateBorn = 43,
		MonarchyTitle = 47
	}
}

namespace Decal.Adapter.Wrappers
{
	[CLSCompliant(true)]
	public enum TrainingType
	{
		Unusable,
		Untrained,
		Trained,
		Specialized
	}
}

namespace Decal.Adapter.Wrappers
{
	[CLSCompliant(true)]
	public enum UIElementType
	{
		Smartbox = 268436634,
		Chat = 268436993,
		FloatChat1 = 268436741,
		FloatChat2 = 268436750,
		FloatChat3 = 268436751,
		FloatChat4 = 268436752,
		Examination = 268436983,
		Vitals = 268436986,
		EnvPack = 268436989,
		Panels = 268436991,
		TBar = 268436995,
		Indicators = 268437009,
		ProgressBar = 268437011,
		Combat = 268437173,
		Radar = 268437202
	}
}

namespace Decal.Adapter.Wrappers
{
	[CLSCompliant(true)]
	public enum VitalType
	{
		MaximumHealth = 1,
		CurrentHealth,
		MaximumStamina,
		CurrentStamina,
		MaximumMana,
		CurrentMana,
		BaseHealth,
		BaseStamina,
		BaseMana
	}
}

namespace Decal.Adapter.Wrappers
{
	public enum WorldChangeType
	{
		SizeChange,
		StorageChange,
		IdentReceived,
		VendorIdentReceived,
		ManaChange
	}
}

namespace Decal.Adapter.Wrappers
{
	[Flags]
	[CLSCompliant(true)]
	public enum WriteTextFormats
	{
		Bottom = 8,
		Center = 1,
		ExpandTabs = 0x40,
		NoClip = 0x100,
		None = 0,
		Right = 2,
		RightToLeftReading = 0x20000,
		SingleLine = 0x20,
		VerticalCenter = 4,
		WordBreak = 0x10
	}
}

namespace Decal.Adapter
{
	public class MessageStruct
	{
		public int Count => 0;

		public object this[int i] => null;

		public object this[string n] => null;

		public byte[] RawData => Array.Empty<byte>();

		public string Name(int i)
		{
			return "";
		}

		public T Value<T>(string n)
		{
			return default;
		}

		public T Value<T>(int i)
		{
			return default;
		}

		public MessageStruct Struct(string n)
		{
			return new MessageStruct();
		}

		public MessageStruct Struct(int i)
		{
			return new MessageStruct();
		}
	}
}

namespace System.Windows.Forms
{
	public static class Clipboard
	{
		public static void SetText(string s)
		{
			try
			{
				DisplayServer.ClipboardSet(s ?? "");
			}
			catch
			{
			}
		}

		public static string GetText()
		{
			try
			{
				return DisplayServer.ClipboardGet();
			}
			catch
			{
				return "";
			}
		}
	}
}

namespace System.Windows.Forms
{
	public class Timer : IDisposable
	{
		private static readonly List<Timer> _all = new List<Timer>();

		private static bool _hooked;

		private double _left;

		private bool _enabled;

		public int Interval { get; set; } = 100;

		public object Tag { get; set; }

		public bool Enabled
		{
			get
			{
				return _enabled;
			}
			set
			{
				_enabled = value;
				if (value)
				{
					_left = (double)Interval / 1000.0;
					if (!_all.Contains(this))
					{
						_all.Add(this);
					}
					if (!_hooked && Bridge.Host != null)
					{
						_hooked = true;
						Bridge.Host.Tick += Run;
					}
				}
				else
				{
					_all.Remove(this);
				}
			}
		}

		public event EventHandler Tick;

		public Timer()
		{
		}

		public Timer(IContainer c)
		{
		}

		public void Start()
		{
			Enabled = true;
		}

		public void Stop()
		{
			Enabled = false;
		}

		public void Dispose()
		{
			Enabled = false;
		}

		private static void Run(double dt)
		{
			Timer[] array = _all.ToArray();
			foreach (Timer timer in array)
			{
				if (timer._enabled && !((timer._left -= dt) > 0.0))
				{
					timer._left = Math.Max(0.001, (double)timer.Interval / 1000.0);
					Hitch.Each(timer.Tick, "timer", h => ((EventHandler)h)(timer, EventArgs.Empty));
				}
			}
		}
	}
}
