using System;
using System.Diagnostics;
using System.IO;
using System.Text;

namespace ACGodot.DecalShim
{
    /// <summary>
    /// Finds what freezes the game: times every plugin handler the shim calls (frame, timers, chat, world changes,
    /// network messages, windows) and writes the slow ones to plugins/hitches.txt. A gap between frames that no plugin
    /// handler accounts for is written too ("frame gap") - then it's the client itself, not a plugin.
    /// </summary>
    public static class Hitch
    {
        private const double SlowMs = 25.0, GapMs = 80.0;
        private static readonly double ToMs = 1000.0 / Stopwatch.Frequency;
        private static long _lastFrame;
        private static double _pluginMs;           // plugin time since the last frame
        private static readonly StringBuilder _since = new StringBuilder();   // slow handlers since the last frame
        private static string _path;
        private static int _lines;

        public static long T() => Stopwatch.GetTimestamp();

        /// <summary>A handler finished: counted towards this frame, written down if it was slow.</summary>
        public static void Done(long t0, string what, Delegate d = null)
        {
            double ms = (Stopwatch.GetTimestamp() - t0) * ToMs;
            _pluginMs += ms;
            if (ms < SlowMs) return;
            string who = Who(d);
            string line = $"{ms,6:0} ms  {what}{(who.Length > 0 ? "  " + who : "")}";
            if (_since.Length < 2000) _since.Append(line.Trim()).Append(" ; ");
            Write(line);
        }

        /// <summary>Every handler of a multicast event, each timed on its own.</summary>
        public static void Each(Delegate multicast, string what, Action<Delegate> call)
        {
            if (multicast == null) return;
            foreach (Delegate h in multicast.GetInvocationList())
            {
                long t0 = T();
                try { call(h); }
                catch (Exception ex) { Godot.GD.PushWarning("plugin " + what + ": " + ex.Message); }
                Done(t0, what, h);
            }
        }

        /// <summary>Once a frame (the windows' draw): a long gap since the last one is written with how much of it the plugins took.</summary>
        public static void Frame()
        {
            long now = Stopwatch.GetTimestamp();
            if (_lastFrame != 0)
            {
                double gap = (now - _lastFrame) * ToMs;
                if (gap >= GapMs)
                    Write($"{gap,6:0} ms  frame gap - plugins took {_pluginMs:0} ms of it{(_since.Length > 0 ? ": " + _since : " (so the client itself)")}");
            }
            _lastFrame = now;
            _pluginMs = 0;
            _since.Clear();
        }

        private static string Who(Delegate d)
        {
            try { return d?.Method == null ? "" : (d.Method.DeclaringType?.FullName ?? "?") + "." + d.Method.Name; }
            catch { return ""; }
        }

        private static void Write(string line)
        {
            try
            {
                if (_path == null)
                {
                    string dir = Path.GetDirectoryName(typeof(Hitch).Assembly.Location) ?? ".";
                    _path = Path.Combine(Path.GetDirectoryName(dir.TrimEnd('/', '\\')) ?? dir, "hitches.txt");
                }
                if (++_lines % 200 == 0 && File.Exists(_path) && new FileInfo(_path).Length > 300_000) File.Delete(_path);
                File.AppendAllText(_path, DateTime.Now.ToString("HH:mm:ss.fff") + line + Environment.NewLine);
            }
            catch { }
        }
    }
}
