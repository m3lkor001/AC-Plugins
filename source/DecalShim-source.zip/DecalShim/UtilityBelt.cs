using System;
using System.Collections.Generic;
using System.Linq;
using ACGodot.DecalShim;
using Godot;
using ImGuiNET;

namespace UtilityBelt.Service
{
    /// <summary>UtilityBelt's service: its HUD manager (ImGui windows over the game).</summary>
    public static class UBService
    {
        private static Views.HudManager _huds;
        public static Views.HudManager Huds => _huds ??= new Views.HudManager();
        public static bool IsInGame => Bridge.LoginStatus == 3;
        public static void WriteLog(string s, object level = null) { }
        public static void LogException(Exception ex) => GD.PushWarning("UB: " + ex.Message);
    }
}

namespace UtilityBelt.Service.Views
{
    /// <summary>A UtilityBelt window: drawn each frame while visible (ImGui.Begin with its title and flags, then OnRender).</summary>
    public class Hud : IDisposable
    {
        private bool _open, _lastVisible;
        public bool ShowInBar { get; set; } = true;
        public bool DontDrawDefaultWindow { get; set; }
        public ImGuiWindowFlags WindowSettings { get; set; }
        public string Name { get; }
        public string Title { get; set; }
        public uint WindowX { get; set; }
        public uint WindowY { get; set; }
        public double LastPreRenderTimeMS => 0;
        public double LastRenderTimeMS => 0;
        public object Icon { get; }

        public event EventHandler OnPreRender, OnRender, OnPostRender, OnShow, OnHide, OnDestroyTextures, OnCreateTextures;

        internal Hud(string name, object icon) { Name = name; Title = name; Icon = icon; }

        public bool Visible
        {
            get => _open;
            set
            {
                if (_lastVisible == value) return;
                _lastVisible = value; _open = value;
                (value ? OnShow : OnHide)?.Invoke(this, EventArgs.Empty);
            }
        }

        internal void CallRender()
        {
            Visible = _open;
            if (!_open) return;
            bool begun = false;
            try
            {
                OnPreRender?.Invoke(this, EventArgs.Empty);
                if (!DontDrawDefaultWindow)
                {
                    begun = true;
                    if (ImGui.Begin(Title + "###" + Name, ref _open, WindowSettings)) OnRender?.Invoke(this, EventArgs.Empty);
                }
                else OnRender?.Invoke(this, EventArgs.Empty);
                OnPostRender?.Invoke(this, EventArgs.Empty);
            }
            catch (Exception ex) { GD.PushWarning($"{Name}: {ex}"); }
            finally
            {
                if (begun)
                {
                    var p = ImGui.GetWindowPos();
                    ImGui.End();
                    WindowX = (uint)Math.Max(0, p.X); WindowY = (uint)Math.Max(0, p.Y);
                }
            }
        }

        public void Dispose() { UBService.Huds.Remove(this); }
    }

    /// <summary>UtilityBelt's HUD manager: makes the windows and draws them (in ACGodot's ImGui layer).</summary>
    public class HudManager : IDisposable
    {
        private readonly List<Hud> _huds = new();
        public IList<Hud> Huds => _huds.ToArray();
        public event EventHandler<EventArgs> OnBeforeRender, OnAfterRender;

        internal HudManager()
        {
            ACGodot.UI.ImGuiLayer.Render += Draw;
        }

        public Hud CreateHud(string name, object icon = null)
        {
            var h = new Hud(name, icon);
            _huds.Add(h);
            // on ACGodot's plugin bar (a button showing / hiding it), as on UtilityBelt's bar
            Bridge.Host?.AddBarButton(Short(name), name, () => { if (h.ShowInBar) h.Visible = !h.Visible; });
            return h;
        }

        private static string Short(string name)
        {
            string t = name ?? "";
            switch (t)
            {
                case "MelkTank": return "Tank";
                case "MelksQuestTracker": return "QB";
            }
            if (t.StartsWith("Melks")) t = t.Substring(5);
            return t.Length > 8 ? t.Substring(0, 8) : t;
        }

        internal void Remove(Hud h) => _huds.Remove(h);

        private void Draw()
        {
            try { OnBeforeRender?.Invoke(this, EventArgs.Empty); } catch { }
            foreach (var h in _huds.ToArray()) h.CallRender();
            try { OnAfterRender?.Invoke(this, EventArgs.Empty); } catch { }
        }

        public void Dispose() { ACGodot.UI.ImGuiLayer.Render -= Draw; }
    }

    /// <summary>A picture for ImGui (a game icon by its id, or an image file).</summary>
    public class ManagedTexture : IDisposable
    {
        private Texture2D _tex;
        private IntPtr _id;

        public ManagedTexture(uint icon = 0)
        {
            if (icon != 0) _tex = Bridge.Host?.Objects?.Assets.Icon(icon);
        }

        public ManagedTexture(string file)
        {
            try { var img = Image.LoadFromFile(file); if (img != null) _tex = ImageTexture.CreateFromImage(img); } catch { }
        }

        public ManagedTexture(System.IO.Stream stream)
        {
            try
            {
                using var ms = new System.IO.MemoryStream();
                stream.CopyTo(ms);
                var img = new Image();
                var bytes = ms.ToArray();
                if (img.LoadPngFromBuffer(bytes) == Error.Ok || img.LoadJpgFromBuffer(bytes) == Error.Ok || img.LoadBmpFromBuffer(bytes) == Error.Ok)
                    _tex = ImageTexture.CreateFromImage(img);
            }
            catch { }
        }

        /// <summary>From raw RGBA pixels (width x height, 4 bytes each).</summary>
        public ManagedTexture(byte[] rgba, int width, int height)
        {
            _tex = ImageTexture.CreateFromImage(Image.CreateFromData(width, height, false, Image.Format.Rgba8, rgba));
        }

        public IntPtr TexturePtr => _tex == null ? IntPtr.Zero : _id != IntPtr.Zero ? _id : (_id = ACGodot.UI.ImGuiLayer.Bind(_tex));
        public System.Numerics.Vector2 Size => _tex == null ? System.Numerics.Vector2.Zero : new System.Numerics.Vector2(_tex.GetWidth(), _tex.GetHeight());

        public void Dispose()
        {
            if (_id != IntPtr.Zero) ACGodot.UI.ImGuiLayer.Unbind(_id);
            _id = IntPtr.Zero; _tex = null;
        }
    }
}
