// UtilityBelt's service as the plugins use it (the dat tables, the HUD windows). Recovered from ACGodot.DecalShim.dll: the
// source file kept on the PC was older than the DLL, so this one has no comments.
using ACE.DatLoader;
using ACGodot.DecalShim;
using ACGodot.Plugins;
using ACGodot.UI;
using Godot;
using ImGuiNET;
using System.Collections.Generic;
using System.IO;
using System.Numerics;
using System;
using UtilityBelt.Service.Views;

namespace UtilityBelt.Service.Views
{
	public class Hud : IDisposable
	{
		private bool _open;

		private bool _lastVisible;

		internal bool OnBar;

		public bool ShowInBar { get; set; } = true;

		public bool? InBar { get; set; }

		internal bool WantBar => InBar ?? ShowInBar;

		public bool DontDrawDefaultWindow { get; set; }

		public ImGuiWindowFlags WindowSettings { get; set; }

		public string Name { get; }

		public string Title { get; set; }

		public uint WindowX { get; set; }

		public uint WindowY { get; set; }

		public double LastPreRenderTimeMS => 0.0;

		public double LastRenderTimeMS => 0.0;

		public object Icon { get; }

		public bool Visible
		{
			get
			{
				return _open;
			}
			set
			{
				if (_lastVisible != value)
				{
					_lastVisible = value;
					_open = value;
					(value ? OnShow : OnHide)?.Invoke(this, EventArgs.Empty);
				}
			}
		}

		public event EventHandler OnPreRender;

		public event EventHandler OnRender;

		public event EventHandler OnPostRender;

		public event EventHandler OnShow;

		public event EventHandler OnHide;

		public event EventHandler OnDestroyTextures;

		public event EventHandler OnCreateTextures;

		internal Hud(string name, object icon)
		{
			Name = name;
			Title = name;
			Icon = icon;
		}

		internal void CallRender()
		{
			Visible = _open;
			if (!_open)
			{
				return;
			}
			long hitchT0 = Hitch.T();
			try { CallRenderInner(); } finally { Hitch.Done(hitchT0, "window " + Name, OnRender); }
		}

		private void CallRenderInner()
		{
			bool flag = false;
			try
			{
				OnPreRender?.Invoke(this, EventArgs.Empty);
				if (!DontDrawDefaultWindow)
				{
					flag = true;
					if (ImGui.Begin(Title + "###" + Name, ref _open, WindowSettings))
					{
						OnRender?.Invoke(this, EventArgs.Empty);
					}
				}
				else
				{
					OnRender?.Invoke(this, EventArgs.Empty);
				}
				OnPostRender?.Invoke(this, EventArgs.Empty);
			}
			catch (Exception value)
			{
				GD.PushWarning($"{Name}: {value}");
			}
			finally
			{
				if (flag)
				{
					System.Numerics.Vector2 windowPos = ImGui.GetWindowPos();
					ImGui.End();
					WindowX = (uint)Math.Max(0f, windowPos.X);
					WindowY = (uint)Math.Max(0f, windowPos.Y);
				}
			}
		}

		public void Dispose()
		{
			UBService.Huds.Remove(this);
		}
	}
}

namespace UtilityBelt.Service.Views
{
	public class HudManager : IDisposable
	{
		private readonly List<Hud> _huds = new List<Hud>();

		public IList<Hud> Huds => _huds.ToArray();

		public event EventHandler<EventArgs> OnBeforeRender;

		public event EventHandler<EventArgs> OnAfterRender;

		internal HudManager()
		{
			ImGuiLayer.Render += Draw;
		}

		public Hud CreateHud(string name, object icon = null)
		{
			Hud hud = new Hud(name, icon);
			_huds.Add(hud);
			SyncBar(hud);
			return hud;
		}

		private static string Short(string name)
		{
			string text = name ?? "";
			switch (text)
			{
			case "MelkTank":
				return "Tank";
			case "MelksQuestTracker":
				return "QB";
			case "MelksQB Travel":
			case "MelksQuestTracker Travel":
				return "Travel";
			default:
				switch (text)
				{
				case "MelkTank Tracking":
					return "Track";
				case "MelkTank Bounty":
					return "Bounty";
				case "MelkTank Mini":
					return "HUD";
				default:
					if (text.StartsWith("MelkTank "))
					{
						text = text.Substring(9);
					}
					if (text.StartsWith("Melks"))
					{
						text = text.Substring(5);
					}
					return (text.Length > 8) ? text.Substring(0, 8) : text;
				}
			}
		}

		internal void SyncBar(Hud h)
		{
			PluginHost host = Bridge.Host;
			if (host == null || h.OnBar == h.WantBar)
			{
				return;
			}
			h.OnBar = h.WantBar;
			if (h.WantBar)
			{
				host.AddBarButton(Short(h.Name), h.Name, () =>
				{
					h.Visible = !h.Visible;
				});
			}
			else
			{
				host.RemoveBarButton(h.Name);
			}
		}

		internal void Remove(Hud h)
		{
			_huds.Remove(h);
			if (h.OnBar)
			{
				h.OnBar = false;
				Bridge.Host?.RemoveBarButton(h.Name);
			}
		}

		private void Draw()
		{
			Hitch.Frame();
			try
			{
				OnBeforeRender?.Invoke(this, EventArgs.Empty);
			}
			catch
			{
			}
			Hud[] array = _huds.ToArray();
			foreach (Hud hud in array)
			{
				SyncBar(hud);
				hud.CallRender();
			}
			try
			{
				OnAfterRender?.Invoke(this, EventArgs.Empty);
			}
			catch
			{
			}
		}

		public void Dispose()
		{
			ImGuiLayer.Render -= Draw;
		}
	}
}

namespace UtilityBelt.Service.Views
{
	public class ManagedTexture : IDisposable
	{
		private Texture2D _tex;

		private nint _id;

		public nint TexturePtr
		{
			get
			{
				nint result;
				if (_tex == null)
				{
					result = IntPtr.Zero;
				}
				else
				{
					result = ((_id != IntPtr.Zero) ? _id : (_id = ImGuiLayer.Bind(_tex)));
				}
				return result;
			}
		}

		public System.Numerics.Vector2 Size => (_tex == null) ? System.Numerics.Vector2.Zero : new System.Numerics.Vector2(_tex.GetWidth(), _tex.GetHeight());

		public ManagedTexture(uint icon = 0u)
		{
			if (icon != 0)
			{
				_tex = Bridge.Host?.Objects?.Assets.Icon(icon);
			}
		}

		public ManagedTexture(string file)
		{
			try
			{
				_tex = Pictures.Texture(file);
			}
			catch
			{
			}
		}

		public ManagedTexture(Stream stream)
		{
			try
			{
				using MemoryStream memoryStream = new MemoryStream();
				stream.CopyTo(memoryStream);
				Image image = new Image();
				byte[] buffer = memoryStream.ToArray();
				if (image.LoadPngFromBuffer(buffer) == Error.Ok || image.LoadJpgFromBuffer(buffer) == Error.Ok || image.LoadBmpFromBuffer(buffer) == Error.Ok)
				{
					_tex = ImageTexture.CreateFromImage(image);
				}
			}
			catch
			{
			}
		}

		public ManagedTexture(byte[] rgba, int width, int height)
		{
			_tex = ImageTexture.CreateFromImage(Image.CreateFromData(width, height, useMipmaps: false, Image.Format.Rgba8, rgba));
		}

		public void Dispose()
		{
			if (_id != IntPtr.Zero)
			{
				ImGuiLayer.Unbind(_id);
			}
			_id = IntPtr.Zero;
			_tex = null;
		}
	}
}

namespace UtilityBelt.Service
{
	public static class UBService
	{
		private static HudManager _huds;

		private static PortalDatDatabase _portal;

		public static HudManager Huds => _huds ?? (_huds = new HudManager());

		public static bool IsInGame => Bridge.LoginStatus == 3;

		public static PortalDatDatabase PortalDat => _portal ?? (_portal = PortalDatDatabase.FromGame());

		public static void WriteLog(string s, object level = null)
		{
		}

		public static void LogException(Exception ex)
		{
			GD.PushWarning("UB: " + ex.Message);
		}
	}
}
