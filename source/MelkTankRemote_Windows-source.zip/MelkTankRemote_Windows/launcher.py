#!/usr/bin/env python3
"""
MelkTank Launcher - a Linux replacement for ThwargLauncher's window.

Starts your Asheron's Call clients with Decal (through Wine), tells MelkTank which character to log in,
shows the server and each account's status, and never closes a client on its own.
"""

import json
import os
import subprocess
import sys
import threading
from datetime import datetime, timezone

from PySide6.QtCore import QObject, Qt, QTimer, Signal
from PySide6.QtGui import QAction, QColor, QFont
from PySide6.QtWidgets import (QPlainTextEdit, QApplication, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFormLayout,
                               QHBoxLayout, QHeaderView, QLabel, QLineEdit, QMainWindow, QMessageBox,
                               QPushButton, QSpinBox, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
                               QAbstractItemView, QPlainTextEdit, QToolButton, QSizePolicy)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mtcore  # noqa: E402

CHAR_SCREEN = "(character screen)"


def _open_file(path):
    """Opens a file (the log) in this PC's own program for it."""
    if os.name == "nt":
        os.startfile(path)
    else:
        subprocess.Popen(["xdg-open", path])


def ago(dt):
    if not dt:
        return "-"
    s = int((datetime.now(timezone.utc) - dt).total_seconds())
    if s < 60:
        return "%ds ago" % s
    if s < 3600:
        return "%dm ago" % (s // 60)
    return "%dh %dm ago" % (s // 3600, (s % 3600) // 60)


def since(dt):
    if not dt:
        return ""
    s = int((datetime.now(timezone.utc) - dt).total_seconds())
    return "%dh %02dm" % (s // 3600, (s % 3600) // 60)


class Bus(QObject):
    """Signals from worker threads to the window."""
    message = Signal(str)
    server = Signal(str, object)   # server name, True/False/None
    done = Signal()


# ── Dialogs ────────────────────────────────────────────────────────

class AccountDialog(QDialog):
    def __init__(self, cfg, acct=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Account")
        self.cfg = cfg
        acct = acct or {"account": "", "password": "", "server": cfg["servers"][0]["name"] if cfg["servers"] else "",
                        "character": "", "enabled": True}
        form = QFormLayout(self)
        self.account = QLineEdit(acct["account"])
        self.password = QLineEdit(acct.get("password", ""))
        self.password.setEchoMode(QLineEdit.Password)
        show = QCheckBox("Show")
        show.toggled.connect(lambda on: self.password.setEchoMode(QLineEdit.Normal if on else QLineEdit.Password))
        pw = QHBoxLayout()
        pw.addWidget(self.password)
        pw.addWidget(show)
        self.server = QComboBox()
        for s in cfg["servers"]:
            self.server.addItem(s["name"])
        i = self.server.findText(acct.get("server", ""))
        if i >= 0:
            self.server.setCurrentIndex(i)
        self.character = QComboBox()
        self.character.setEditable(True)
        self.character.addItem(CHAR_SCREEN)
        for c in mtcore.known_characters(cfg, acct["account"]):
            self.character.addItem(c)
        self.character.setCurrentText(acct.get("character") or CHAR_SCREEN)
        self.client = QComboBox()
        self.client.addItem("Asheron's Call (Decal)" if os.name == "nt" else "Asheron's Call (Wine + Decal)", "retail")
        self.client.addItem("ACGodot", "acgodot")
        # (a new account: the client this PC was set up for - setup's choice, else Asheron's Call)
        self.client.setCurrentIndex(max(0, self.client.findData(acct.get("client") or cfg.get("default_client") or "retail")))
        self.client.setToolTip("ACGodot logs in to this account's server with this account and password itself;\n"
                               "its phone plugin shows it in the phone app with the others.")
        self.enabled = QCheckBox("Include in \"Launch ticked\"")
        self.enabled.setChecked(acct.get("enabled", True))
        self.restart = QCheckBox("Restart if it crashes (when that's on in Settings)")
        self.restart.setChecked(acct.get("auto_restart", True))
        self.corner = QComboBox()
        for text, val in (("Top-left corner", "top-left"), ("Bottom-right corner", "bottom-right"), ("Leave it where it is", "none")):
            self.corner.addItem(text, val)
        i = self.corner.findData(acct.get("window_corner") or "top-left")
        self.corner.setCurrentIndex(max(0, i))
        self.corner.setToolTip("Once the character is in the game (and the window has stopped resizing), its window is\n"
                               "moved here; 5 s later the focus is taken off the games so they stop drawing.")
        form.addRow("Account", self.account)
        form.addRow("Password", pw)
        form.addRow("Server", self.server)
        form.addRow("Play in", self.client)
        form.addRow("Character", self.character)
        form.addRow("", QLabel("Leave it on (character screen) to pick by hand.\n"
                               "The list fills in after this account has reached the character screen once."))
        form.addRow("", self.enabled)
        form.addRow("", self.restart)
        form.addRow("Game window after login", self.corner)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)

    def value(self):
        ch = self.character.currentText().strip()
        return {"account": self.account.text().strip(), "password": self.password.text(),
                "server": self.server.currentText(), "character": "" if ch == CHAR_SCREEN else ch,
                "enabled": self.enabled.isChecked(), "auto_restart": self.restart.isChecked(),
                "window_corner": self.corner.currentData(), "client": self.client.currentData()}


class ServersDialog(QDialog):
    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Servers")
        self.resize(640, 260)
        lay = QVBoxLayout(self)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Name", "Address", "Port", "Read-only dats", "Character slots"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        for s in cfg["servers"]:
            self._add(s)
        lay.addWidget(self.table)
        row = QHBoxLayout()
        add = QPushButton("Add")
        add.clicked.connect(lambda: self._add({"name": "", "host": "", "port": 9000, "rodat": False, "slots": 11}))
        rem = QPushButton("Remove")
        rem.clicked.connect(lambda: self.table.removeRow(self.table.currentRow()))
        row.addWidget(add)
        row.addWidget(rem)
        row.addStretch()
        lay.addLayout(row)
        lay.addWidget(QLabel("Character slots: how many rows the server's character screen has (ACE default 11) - "
                             "auto-login uses it to click the right row."))
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        lay.addWidget(buttons)

    def _add(self, s):
        r = self.table.rowCount()
        self.table.insertRow(r)
        self.table.setItem(r, 0, QTableWidgetItem(s["name"]))
        self.table.setItem(r, 1, QTableWidgetItem(s["host"]))
        self.table.setItem(r, 2, QTableWidgetItem(str(s["port"])))
        cb = QCheckBox()
        cb.setChecked(bool(s.get("rodat")))
        self.table.setCellWidget(r, 3, cb)
        self.table.setItem(r, 4, QTableWidgetItem(str(s.get("slots", 11))))

    def value(self):
        out = []
        for r in range(self.table.rowCount()):
            name = (self.table.item(r, 0).text() if self.table.item(r, 0) else "").strip()
            host = (self.table.item(r, 1).text() if self.table.item(r, 1) else "").strip()
            if not name or not host:
                continue
            try:
                port = int(self.table.item(r, 2).text())
            except Exception:
                port = 9000
            try:
                slots = int(self.table.item(r, 4).text())
            except Exception:
                slots = 11
            out.append({"name": name, "host": host, "port": port, "rodat": self.table.cellWidget(r, 3).isChecked(),
                        "slots": slots})
        return out


class SettingsDialog(QDialog):
    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Settings")
        self.resize(720, 0)
        w = cfg["wine"]
        self.mode = QComboBox()
        self.mode.addItems(["direct", "system"])
        self.mode.setCurrentText(w.get("mode", "direct"))
        self.wine_path = QLineEdit(w["wine_path"])
        self.prefix = QLineEdit(w["prefix"])
        self.esync = QCheckBox("esync")
        self.esync.setChecked(bool(w.get("esync")))
        self.fsync = QCheckBox("fsync")
        self.fsync.setChecked(bool(w.get("fsync")))
        syncs = QHBoxLayout()
        syncs.addWidget(self.esync)
        syncs.addWidget(self.fsync)
        syncs.addStretch()
        self.client = QLineEdit(cfg["client"])
        self.injector = QLineEdit(cfg["injector"])
        self.inject = QComboBox()
        self.inject.addItem("Built-in (no ThwargLauncher needed)", "builtin")
        self.inject.addItem("ThwargLauncher's injector.dll", "thwarg")
        self.inject.setCurrentIndex(max(0, self.inject.findData(cfg.get("inject") or "builtin")))
        self.injector.setEnabled(self.inject.currentData() == "thwarg")
        self.inject.currentIndexChanged.connect(lambda _i: self.injector.setEnabled(self.inject.currentData() == "thwarg"))
        self.plugin = QLineEdit(cfg.get("plugin_dir") or "")
        self.decal = QCheckBox("Load Decal")
        self.decal.setChecked(cfg.get("use_decal", True))
        self.picker = QComboBox()
        self.picker.addItem("MelkTank login filter", "melktank")
        self.picker.addItem("ThwargFilter", "thwargfilter")
        self.picker.setCurrentIndex(max(0, self.picker.findData(cfg.get("character_picker", "melktank"))))
        self.restart = QCheckBox("Restart a client automatically if it crashes")
        self.restart.setChecked(bool(cfg.get("auto_restart", False)))
        self.frozen = QCheckBox("Restart a client that stops answering, or whose login gets stuck")
        self.frozen.setChecked(bool(cfg.get("restart_frozen", False)))
        self.frozen_min = QSpinBox()
        self.frozen_min.setRange(1, 30)
        self.frozen_min.setValue(int(cfg.get("frozen_minutes", 3)))
        self.frozen_min.setSuffix(" min without word")
        self.frozen_wait = QSpinBox()
        self.frozen_wait.setRange(0, 600)
        self.frozen_wait.setValue(int(cfg.get("frozen_wait_seconds", 60)))
        self.frozen_wait.setSuffix(" s before starting it again")
        frozen_row = QHBoxLayout()
        frozen_row.addWidget(self.frozen_min)
        frozen_row.addWidget(self.frozen_wait)
        frozen_row.addStretch()
        self.delay = QSpinBox()
        self.delay.setRange(5, 300)
        self.delay.setValue(int(cfg.get("launch_delay", 20)))
        self.delay.setSuffix(" s")
        self.port = QSpinBox()
        self.port.setRange(1024, 65535)
        self.port.setValue(int(cfg["service"]["port"]))
        self.token = QLineEdit(cfg["service"]["token"])
        self.token.setReadOnly(True)
        self.back = QCheckBox("Start the game again when the server comes back after a shutdown (a patch, a restart)")
        self.back.setChecked(bool(cfg.get("server_back_restart", True)))
        self.back_window = QSpinBox()
        self.back_window.setRange(1, 120)
        self.back_window.setValue(int(cfg.get("server_back_window_minutes", 15)))
        self.back_window.setSuffix(" min before it went down")
        self.back_wait = QSpinBox()
        self.back_wait.setRange(0, 1800)
        self.back_wait.setValue(int(cfg.get("server_back_wait_seconds", 90)))
        self.back_wait.setSuffix(" s after it's back")
        back_row = QHBoxLayout()
        back_row.addWidget(QLabel("Logged out up to"))
        back_row.addWidget(self.back_window)
        back_row.addWidget(QLabel("  started"))
        back_row.addWidget(self.back_wait)
        back_row.addStretch()

        outer = QVBoxLayout(self)
        opened = set(cfg.get("settings_open") or ["restarts", "server"])
        self.sections = {}

        def section(key, title):
            box = QWidget()
            v = QVBoxLayout(box)
            v.setContentsMargins(0, 0, 0, 0)
            head = QToolButton()
            head.setText(title)
            head.setCheckable(True)
            head.setChecked(key in opened)
            head.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
            head.setArrowType(Qt.DownArrow if key in opened else Qt.RightArrow)
            head.setStyleSheet("QToolButton { border: none; font-weight: bold; }")
            head.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            body = QWidget()
            f = QFormLayout(body)
            f.setContentsMargins(18, 0, 0, 6)
            body.setVisible(key in opened)

            def toggled(on, h=head, b=body):
                h.setArrowType(Qt.DownArrow if on else Qt.RightArrow)
                b.setVisible(on)
                QTimer.singleShot(0, lambda: self.resize(self.width(), self.sizeHint().height()))
            head.toggled.connect(toggled)
            v.addWidget(head)
            v.addWidget(body)
            outer.addWidget(box)
            self.sections[key] = head
            return f

        form = section("restarts", "Restarts")
        form.addRow("", self.restart)
        form.addRow("", QLabel("Only clients that got into the game. A client you close yourself, or one that's frozen\n"
                               "but still open, isn't restarted. At most 3 restarts per account in 30 minutes.\n"
                               "The phone service does the watching, so it works with this window closed."))
        form.addRow("", self.frozen)
        form.addRow("", frozen_row)
        form.addRow("", QLabel("Stopped answering (frozen or lost its connection): closed (forced) after the time above,\n"
                               "then started again after the wait. Login stuck at the character screen: 1 more minute,\n"
                               "then closed, then started again after the wait. Only for accounts ticked to restart,\n"
                               "not while the server is down, at most 3 times per account in 30 minutes."))

        form = section("server", "Server shutdowns")
        form.addRow("", self.back)
        form.addRow("", back_row)
        form.addRow("", QLabel("A shutdown logs everyone off, which looks like a normal logout. Accounts (ticked to restart)\n"
                               "that logged out within the time above before the server stopped answering are started\n"
                               "again once it answers, after the wait (it may not take logins straight away).\n"
                               "The server is checked every minute - every 20 s while it's down."))

        form = section("launching", "Launching")
        form.addRow("Character picked by", self.picker)
        form.addRow("Time between launches", self.delay)

        if os.name == "nt":
            form = section("wine", "Game setup")
            form.addRow("acclient.exe", self.client)
            form.addRow("Load Decal with", self.inject)
            form.addRow("injector.dll", self.injector)
            form.addRow("MelkTank plugin folder", self.plugin)
            form.addRow("", self.decal)
        else:
            form = section("wine", "Game && Wine setup")
            form.addRow("Wine", self.mode)
            form.addRow("Wine program (direct)", self.wine_path)
            form.addRow("Wine prefix", self.prefix)
            form.addRow("", syncs)
            form.addRow("acclient.exe (Windows path)", self.client)
            form.addRow("Load Decal with", self.inject)
            form.addRow("injector.dll (Windows path)", self.injector)
            form.addRow("", self.decal)

        ag = cfg.get("acgodot") or {}
        self.godot = QLineEdit(ag.get("godot", ""))
        self.acg_project = QLineEdit(ag.get("project", ""))
        self.acg_port = QSpinBox()
        self.acg_port.setRange(1024, 65535)
        self.acg_port.setValue(int(ag.get("phone_port") or 8766))
        self.acg_build = QCheckBox("Build it before starting when its source has changed")
        self.acg_build.setToolTip("Runs 'dotnet build' first when ACGodot's source is newer than its last build (what the editor's\n"
                                  "Build button does) - updates take effect without opening the Godot editor.")
        self.acg_build.setChecked(bool(ag.get("auto_build", True)))
        form = section("acgodot", "ACGodot")
        form.addRow("Godot program", self.godot)
        form.addRow("ACGodot folder", self.acg_project)
        form.addRow("Its phone plugin's port", self.acg_port)
        form.addRow("", self.acg_build)
        form.addRow("", QLabel("Accounts set to \"Play in: ACGodot\" start Godot with that folder, logged in to their\n"
                               "server. Its phone plugin answers on the port above (only this PC asks it): the phone\n"
                               "app shows ACGodot characters with the others."))

        form = section("phone", "Phone service")
        form.addRow("Phone service port", self.port)
        form.addRow("Phone app key", self.token)
        form.addRow("", QLabel("Type the phone app key into the app once. Changes to the port apply when the "
                               "service restarts:\n  " + ("double-click restart_service.bat" if os.name == "nt" else
                                                           "systemctl --user restart melktank-service")))
        outer.addStretch()
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        outer.addWidget(buttons)

    def apply(self, cfg):
        w = cfg["wine"]
        w["mode"] = self.mode.currentText()
        w["wine_path"] = self.wine_path.text().strip()
        w["prefix"] = self.prefix.text().strip()
        w["esync"] = self.esync.isChecked()
        w["fsync"] = self.fsync.isChecked()
        cfg["client"] = self.client.text().strip()
        cfg["injector"] = self.injector.text().strip()
        cfg["inject"] = self.inject.currentData()
        if os.name == "nt" and self.plugin.text().strip():
            cfg["plugin_dir"] = self.plugin.text().strip()
        cfg["use_decal"] = self.decal.isChecked()
        cfg["character_picker"] = self.picker.currentData()
        cfg["auto_restart"] = self.restart.isChecked()
        cfg["restart_frozen"] = self.frozen.isChecked()
        cfg["frozen_minutes"] = self.frozen_min.value()
        cfg["frozen_wait_seconds"] = self.frozen_wait.value()
        cfg["launch_delay"] = self.delay.value()
        cfg["service"]["port"] = self.port.value()
        cfg["server_back_restart"] = self.back.isChecked()
        cfg["server_back_window_minutes"] = self.back_window.value()
        cfg["server_back_wait_seconds"] = self.back_wait.value()
        cfg["acgodot"] = {"godot": self.godot.text().strip(), "project": self.acg_project.text().strip(),
                          "phone_port": self.acg_port.value(), "auto_build": self.acg_build.isChecked()}
        cfg["settings_open"] = [k for k, h in self.sections.items() if h.isChecked()]


# ── Main window ────────────────────────────────────────────────────

COLS = ["Launch", "Account", "Character", "Status", "In game", ""]


def dur(secs):
    """3h 12m / 12m / 40s"""
    secs = int(secs or 0)
    if secs >= 86400:
        return "%dd %dh" % (secs // 86400, secs % 86400 // 3600)
    if secs >= 3600:
        return "%dh %02dm" % (secs // 3600, secs % 3600 // 60)
    if secs >= 60:
        return "%dm" % (secs // 60)
    return "%ds" % secs


KIND_COLOUR = {"in_game": "#5ccc6a", "launch": "#5ad6f2", "restart": "#5ad6f2", "closed": "#9a9a9a",
               "closed_phone": "#9a9a9a", "unresponsive": "#e8a33a", "disconnected": "#e8a33a", "killed": "#e8a33a",
               "server_down": "#e8a33a", "server_up": "#5ccc6a", "crashed": "#e06060", "stuck": "#e06060",
               "launch_failed": "#e06060", "gave_up": "#e06060", "reset": "#b685f2"}


class AcgPluginsDialog(QDialog):
    """ACGodot's plugins: which start with the game. The same file the game's Options > Plugins uses
    (<ACGodot folder>/plugins/plugins.json); a change applies the next time ACGodot starts."""

    BUILT_IN = ["XP Tracker", "Bounty", "Phone"]   # (until the game has run once and written its own list)

    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.setWindowTitle("ACGodot plugins")
        project = (cfg.get("acgodot") or {}).get("project") or os.path.expanduser("~/Games/ACGodot")
        self.dir = os.path.join(project, "plugins")
        self.path = os.path.join(self.dir, "plugins.json")
        data = {}
        try:
            with open(self.path, encoding="utf-8") as fh:
                data = json.load(fh)
        except Exception:
            pass
        self.disabled = set(data.get("disabled") or [])
        known = list(data.get("known") or self.BUILT_IN)
        # plugin folders (plugins/Name/Name.dll) - also ones added since the game last ran
        try:
            for name in sorted(os.listdir(self.dir), key=str.lower):
                if os.path.isfile(os.path.join(self.dir, name, name + ".dll")) and name not in known:
                    known.append(name)
        except Exception:
            pass
        self.known = known
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Plugins that start with ACGodot:"))
        self.boxes = {}
        for name in known:
            cb = QCheckBox(name)
            cb.setChecked(name not in self.disabled)
            lay.addWidget(cb)
            self.boxes[name] = cb
        if not known:
            lay.addWidget(QLabel("No plugins found in %s." % self.dir))
        note = QLabel("Applies the next time ACGodot starts. Each plugin is a folder in\n%s\n(Name/Name.dll, with its files beside it)." % self.dir)
        note.setStyleSheet("color: gray")
        lay.addWidget(note)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.save)
        buttons.rejected.connect(self.reject)
        lay.addWidget(buttons)

    def save(self):
        off = set(n for n in self.disabled if n not in self.boxes)   # (switched off ones no longer there: kept)
        off.update(n for n, cb in self.boxes.items() if not cb.isChecked())
        try:
            os.makedirs(self.dir, exist_ok=True)
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump({"disabled": sorted(off), "known": self.known}, fh, indent=2)
            os.replace(tmp, self.path)
        except Exception as e:
            QMessageBox.warning(self, "ACGodot plugins", "Couldn't save %s: %s" % (self.path, e))
            return
        self.accept()


ACE_LOG = "\x00ace-server"   # (the log window's entry for the ACE server's output: not an account)


class ServerConsoleDialog(QDialog):
    """The local ACE server's console: a command (every one its console takes, from its source) with what follows it,
    run into the server - and the last 100 lines it wrote, kept up to date while the window is open."""

    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.setWindowTitle("ACE server console")
        self.resize(1000, 600)
        lay = QVBoxLayout(self)
        top = QHBoxLayout()
        self.cmd = QComboBox()
        self.cmd.setMaxVisibleItems(25)
        self.cmd.setMinimumWidth(220)
        self.cmds = mtcore.ace_commands(cfg)
        for c in self.cmds:
            self.cmd.addItem(c["name"], c)
            self.cmd.setItemData(self.cmd.count() - 1, ("%s %s" % (c["help"], ("\nUsage: " + c["usage"]) if c["usage"] else "")).strip(), Qt.ToolTipRole)
        i = self.cmd.findText("serverstatus")
        if i >= 0:
            self.cmd.setCurrentIndex(i)
        self.cmd.currentIndexChanged.connect(self.picked)
        top.addWidget(self.cmd)
        self.args = QLineEdit()
        self.args.returnPressed.connect(self.run)
        top.addWidget(self.args, 1)
        b = QPushButton("Run")
        b.clicked.connect(self.run)
        top.addWidget(b)
        lay.addLayout(top)
        self.help = QLabel("")
        self.help.setWordWrap(True)
        self.help.setStyleSheet("color: #9a9a9a;")
        lay.addWidget(self.help)
        self.out = QPlainTextEdit()
        self.out.setReadOnly(True)
        self.out.setLineWrapMode(QPlainTextEdit.WidgetWidth)
        self.out.setMaximumBlockCount(100)
        mono = QFont("monospace")
        mono.setStyleHint(QFont.Monospace)
        self.out.setFont(mono)
        self.out.setStyleSheet("QPlainTextEdit { background: #000000; color: #d8d8d8; }")
        lay.addWidget(self.out, 1)
        self.status = QLabel("")
        lay.addWidget(self.status)
        self._mark = None
        self.picked()
        self.fill()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.fill)
        self.timer.start(1000)

    def picked(self):
        c = self.cmd.currentData() or {}
        self.args.setPlaceholderText(c.get("usage") or ("(nothing more)" if c.get("args", 0) == 0 else "arguments"))
        self.help.setText(c.get("help", ""))

    def run(self):
        c = self.cmd.currentData() or {}
        line = (c.get("name", "") + " " + self.args.text().strip()).strip()
        if not line:
            return
        ok, msg = mtcore.ace_command(line)
        self.status.setText(msg)
        if ok:
            self.args.clear()
        QTimer.singleShot(400, self.fill)

    def fill(self):
        con = mtcore.ace_console(100)
        if con["mark"] == self._mark and self._mark is not None:
            return
        first = self._mark is None
        self._mark = con["mark"]
        bar = self.out.verticalScrollBar()
        at_end = first or bar.value() >= bar.maximum() - 4
        lines = con["lines"] or ["No output yet. It's kept from when the server is started here (the launcher's Start ACE, "
                                 "or the phone); a server started in a terminal writes to that terminal instead."]
        self.out.setPlainText("\n".join(lines[-100:]))
        if at_end:
            bar.setValue(bar.maximum())
            QTimer.singleShot(0, lambda: bar.setValue(bar.maximum()))
        if not con["running"]:
            self.status.setText("The server isn't running.")
        elif not con["ours"]:
            self.status.setText("This server was started in a terminal: commands can't be typed into it from here.")

    def closeEvent(self, ev):
        self.timer.stop()
        super().closeEvent(ev)


class ClientLogDialog(QDialog):
    """The client history: when each client was launched, got in, stopped answering, crashed, was closed and
    restarted - with how long each run lasted, and a summary of the last 24 hours."""

    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.setWindowTitle("Client log")
        self.resize(980, 560)
        lay = QVBoxLayout(self)
        top = QHBoxLayout()
        top.addWidget(QLabel("Account"))
        self.who = QComboBox()
        self.who.addItem("All", "")
        for a in cfg["accounts"]:
            self.who.addItem(a.get("label") or a["account"], a["account"])
        # the local ACE server's own output (what its terminal showed), where ACE is on this PC
        if os.path.isdir(os.path.join(mtcore.ace_root(cfg), "Source", "ACE.Server")):
            self.who.addItem("ACE server (its console output)", ACE_LOG)
        self.who.currentIndexChanged.connect(self.fill)
        top.addWidget(self.who)
        top.addStretch()
        b = QPushButton("Refresh")
        b.clicked.connect(self.fill)
        top.addWidget(b)
        b = QPushButton("Full launcher log")
        b.clicked.connect(lambda: _open_file(mtcore.LOG_PATH))
        top.addWidget(b)
        lay.addLayout(top)
        self.summary = QLabel("")
        self.summary.setTextFormat(Qt.RichText)
        self.summary.setWordWrap(True)
        lay.addWidget(self.summary)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["When", "Account", "What", "Ran for", "Details"])
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.verticalHeader().setVisible(False)
        h = self.table.horizontalHeader()
        h.setSectionResizeMode(QHeaderView.ResizeToContents)
        h.setSectionResizeMode(4, QHeaderView.Stretch)
        lay.addWidget(self.table, 1)
        self.console = QPlainTextEdit()
        self.console.setReadOnly(True)
        self.console.setLineWrapMode(QPlainTextEdit.NoWrap)
        mono = QFont("monospace")
        mono.setStyleHint(QFont.Monospace)
        self.console.setFont(mono)
        self.console.setVisible(False)
        lay.addWidget(self.console, 1)
        self._console_seen = None
        self.fill()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.fill)
        self.timer.start(15000)
        # (the server's output is looked at more often than the history)
        self.fast = QTimer(self)
        self.fast.timeout.connect(lambda: self.fill_console() if self.who.currentData() == ACE_LOG else None)
        self.fast.start(2000)

    def name_of(self, account):
        a = mtcore.find_account(self.cfg, account)
        return (a.get("label") or account) if a else account

    def closeEvent(self, ev):
        # (nothing more to fill in once it's shut)
        self.timer.stop()
        self.fast.stop()
        super().closeEvent(ev)

    def fill_console(self):
        """The ACE server's console output (the end of it), kept at the bottom as it grows unless you've scrolled up."""
        path = mtcore.ACE_LOG_PATH
        try:
            st = os.stat(path)
            seen = (st.st_mtime, st.st_size)
            if seen == self._console_seen:
                return
            self._console_seen = seen
            with open(path, "rb") as f:
                if st.st_size > 400000:
                    f.seek(-400000, os.SEEK_END)
                    f.readline()
                text = f.read().decode("utf-8", "replace")
        except OSError:
            self._console_seen = None
            text = ("No output yet. It's kept from when the server is started here (the launcher's Start ACE, or the phone);\n"
                    "a server started in a terminal writes to that terminal instead.")
        bar = self.console.verticalScrollBar()
        at_end = bar.value() >= bar.maximum() - 4
        self.console.setPlainText(text)
        if at_end:
            bar.setValue(bar.maximum())

    def fill(self):
        acct = self.who.currentData() or None
        console = acct == ACE_LOG
        self.console.setVisible(console)
        self.table.setVisible(not console)
        if console:
            running = bool(mtcore.ace_pids())
            self.summary.setText("<b>ACE server</b> - %s &nbsp; (%s)" % (
                "<span style='color:#5ccc6a'>running</span>" if running else "<span style='color:#9a9a9a'>stopped</span>", mtcore.ACE_LOG_PATH))
            self.fill_console()
            return
        now = datetime.now().timestamp()
        parts = []
        for name, s in mtcore.events_summary(self.cfg).items():
            if acct and name.lower() != acct.lower():
                continue
            head = "<b>%s</b>" % self.name_of(name)
            if s["inGameSince"]:
                head += " - <span style='color:#5ccc6a'>in game %s</span>%s" % (
                    dur(now - s["inGameSince"]), (" as " + s["char"]) if s.get("char") else "")
            else:
                head += " - <span style='color:#9a9a9a'>not in game</span>"
            bits = ["%s in game" % dur(s["uptime"]), "longest run %s" % dur(s["longest"])]
            for key, word in (("restarts", "restart"), ("crashes", "crash"), ("unresponsive", "freeze"),
                              ("disconnects", "disconnect"), ("stuck", "stuck login")):
                if s[key]:
                    plural = "es" if word.endswith("sh") else "s"
                    bits.append("%d %s%s" % (s[key], word, plural if s[key] != 1 else ""))
            parts.append(head + "<br>&nbsp;&nbsp;last 24 h: " + ", ".join(bits))
        self.summary.setText("<br>".join(parts) or "Nothing recorded yet.")
        evs = mtcore.read_events(acct, limit=500)
        evs.reverse()
        # (unchanged since it was last filled in: left as it is - 500 rows laid out again every time was slow)
        stamp = (acct, len(evs), evs[0].get("t") if evs else None)
        if stamp == getattr(self, "_table_stamp", None):
            return
        self._table_stamp = stamp
        self.table.setUpdatesEnabled(False)
        self.table.setRowCount(len(evs))
        for r, e in enumerate(evs):
            t = datetime.fromtimestamp(e.get("t", 0))
            when = t.strftime("%H:%M:%S") if t.date() == datetime.now().date() else t.strftime("%b %d %H:%M")
            kind = e.get("kind", "")
            cells = [when, self.name_of(e.get("account", "")) + ((" (" + e["char"] + ")") if e.get("char") else ""),
                     mtcore.EVENT_KINDS.get(kind, kind), dur(e["ran"]) if e.get("ran") is not None else "", e.get("text", "")]
            for c, text in enumerate(cells):
                it = QTableWidgetItem(text)
                if c == 2:
                    it.setForeground(QColor(KIND_COLOUR.get(kind, "#e8e8e8")))
                self.table.setItem(r, c, it)
        self.table.setUpdatesEnabled(True)


class Main(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("MelkTank Launcher")
        self.resize(760, 460)
        self.cfg = mtcore.load_config()
        self.bus = Bus(self)   # owned by the window, so it's cleaned up with it
        self.bus.message.connect(self.say)
        self.bus.server.connect(self.on_server)
        self.bus.done.connect(self.on_launch_done)
        self.server_states = {}
        self.busy = False

        central = QWidget()
        lay = QVBoxLayout(central)

        top = QHBoxLayout()
        self.server_label = QLabel("Servers: checking...")
        f = QFont()
        f.setPointSize(f.pointSize() + 1)
        self.server_label.setFont(f)
        top.addWidget(self.server_label)
        b = QPushButton("Check now")
        b.setToolTip("Check the servers again right away (the phone service checks too, for its restarts)")
        b.clicked.connect(self.check_now)
        top.addWidget(b)
        top.addStretch()
        b = QPushButton("Log...")
        b.setToolTip("Client history: launches, time in game, freezes, disconnects, crashes, restarts")
        b.clicked.connect(self.open_client_log)
        top.addWidget(b)
        b = QPushButton("Servers...")
        b.clicked.connect(self.edit_servers)
        top.addWidget(b)
        b = QPushButton("Settings...")
        b.clicked.connect(self.edit_settings)
        top.addWidget(b)
        b = QPushButton("ACGodot plugins...")
        b.setToolTip("Which plugins start with ACGodot (applies the next time it starts)")
        b.clicked.connect(self.edit_acg_plugins)
        top.addWidget(b)
        lay.addLayout(top)

        self.table = QTableWidget(0, len(COLS))
        self.table.setHorizontalHeaderLabels(COLS)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        h = self.table.horizontalHeader()
        h.setSectionResizeMode(QHeaderView.ResizeToContents)
        h.setSectionResizeMode(3, QHeaderView.Stretch)
        self.table.doubleClicked.connect(lambda _: self.edit_account())
        lay.addWidget(self.table, 1)

        # services: Decal and the local ACE server, a row each - their start / stop and console in the same column as
        # the characters' buttons, their state in the same column as the characters' status
        self.decal_btn = QPushButton("Start")
        self.decal_btn.setToolTip("Starts / stops the Decal agent (Decal for the retail clients).")
        self.decal_btn.clicked.connect(self.toggle_decal)
        self.ace_btn = QPushButton("Start")
        self.ace_btn.setToolTip("Starts / stops the local ACE server. Stopping saves the characters first (stop-now in its console).")
        self.ace_btn.clicked.connect(self.toggle_ace)
        self.ace_con = QPushButton("Console...")
        self.ace_con.setToolTip("The ACE server's console: run its commands and watch what it writes.")
        self.ace_con.clicked.connect(self.open_server_console)
        self.ace_there = os.path.isdir(os.path.join(mtcore.ace_root(self.cfg), "Source", "ACE.Server"))
        self.services = QTableWidget(0, len(COLS))
        self.services.setHorizontalHeaderLabels(["", "Service", "", "Status", "Since", ""])
        self.services.setSelectionMode(QAbstractItemView.NoSelection)
        self.services.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.services.verticalHeader().setVisible(False)
        self.services.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.services.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        sh = self.services.horizontalHeader()
        sh.setSectionResizeMode(QHeaderView.Fixed)
        sh.setStretchLastSection(False)
        self.service_rows = [("decal", "Decal", "retail clients", [self.decal_btn])]
        if self.ace_there:
            self.service_rows.append(("ace", "ACE server", "local test server", [self.ace_btn, self.ace_con]))
        for key, name, what, buttons in self.service_rows:
            r = self.services.rowCount()
            self.services.insertRow(r)
            self.services.setItem(r, 1, QTableWidgetItem(name))
            it = QTableWidgetItem(what)
            it.setForeground(QColor("#9e9e9e"))
            self.services.setItem(r, 2, it)
            cell = QWidget()
            bl = QHBoxLayout(cell)
            bl.setContentsMargins(2, 0, 2, 0)
            bl.setSpacing(4)
            for b in buttons:
                bl.addWidget(b)
            bl.addStretch()
            self.services.setCellWidget(r, 5, cell)
        self.services.setWordWrap(False)
        self.services.resizeRowsToContents()
        # (the columns line up with the characters' list above)
        self.table.horizontalHeader().sectionResized.connect(lambda i, _o, n: self.services.setColumnWidth(i, n))
        QTimer.singleShot(0, self.fit_services)

        row = QHBoxLayout()
        for text, fn in (("Add account", self.add_account), ("Edit", self.edit_account), ("Remove", self.remove_account)):
            b = QPushButton(text)
            b.clicked.connect(fn)
            row.addWidget(b)
        row.addStretch()
        self.launch_btn = QPushButton("Launch ticked")
        self.launch_btn.setDefault(True)
        self.launch_btn.clicked.connect(self.launch_ticked)
        row.addWidget(self.launch_btn)
        lay.addLayout(row)
        lay.addWidget(self.services)

        self.status = QLabel("")
        self.status.setWordWrap(True)
        lay.addWidget(self.status)
        self.setCentralWidget(central)

        log_action = QAction("Open launcher log", self)
        log_action.triggered.connect(self.open_log)
        self.menuBar().addMenu("&Help").addAction(log_action)

        self.rebuild()
        problems = mtcore.check_setup(self.cfg)
        if problems:
            self.say("Setup: " + " ".join(problems))

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(5000)
        self.server_timer = QTimer(self)
        self.server_timer.timeout.connect(self.check_servers)
        self.server_timer.start(60000)
        self.check_servers()

    # ── table ──

    def rebuild(self):
        self.table.setRowCount(0)
        for a in self.cfg["accounts"]:
            r = self.table.rowCount()
            self.table.insertRow(r)
            cb = QCheckBox()
            cb.setChecked(a.get("enabled", True))
            cb.toggled.connect(lambda on, acct=a: self.set_enabled(acct, on))
            cell = QWidget()
            cl = QHBoxLayout(cell)
            cl.setContentsMargins(8, 0, 0, 0)
            cl.addWidget(cb)
            self.table.setCellWidget(r, 0, cell)
            self.table.setItem(r, 1, QTableWidgetItem(a["account"]))
            self.table.setItem(r, 2, QTableWidgetItem(a.get("character") or CHAR_SCREEN))
            # Launch / Stop (MelkTank logs out and closes the game) / Kill (ends the process at once)
            cell2 = QWidget()
            bl = QHBoxLayout(cell2)
            bl.setContentsMargins(2, 0, 2, 0)
            bl.setSpacing(4)
            btn = QPushButton("Launch")
            btn.clicked.connect(lambda _=False, name=a["account"]: self.launch([name]))
            bl.addWidget(btn)
            stop = QPushButton("Stop game")
            stop.setToolTip("MelkTank logs the character out and closes the game (like Exit on the phone).")
            stop.clicked.connect(lambda _=False, name=a["account"]: self.stop_game(name))
            bl.addWidget(stop)
            kill = QPushButton("Kill")
            kill.setToolTip("Ends the game's process straight away - for a frozen or stuck client. Not restarted as a crash.")
            kill.clicked.connect(lambda _=False, name=a["account"]: self.kill_game(name))
            bl.addWidget(kill)
            self.table.setCellWidget(r, 5, cell2)
        self.refresh()

    def stop_game(self, name):
        if not mtcore.client_pids(name):
            self.say("No running client found for %s." % name)
            return
        mtcore.send_command(self.cfg, name, "quit")
        mtcore.event(name, "closed_launcher", "Stop game from the launcher")
        self.say("Asked %s to log out and close the game." % name)

    def kill_game(self, name):
        if not mtcore.client_pids(name):
            self.say("No running client found for %s." % name)
            return
        if QMessageBox.question(self, "Kill the game", "End %s's game process right now?\n(Nothing is saved first - use Stop game for a normal exit.)" % name) != QMessageBox.Yes:
            return

        def work():
            ok, msg = mtcore.kill_client(self.cfg, name, wait=1.0, kind="closed_launcher", why="Killed from the launcher",
                                         note="Closed from the launcher")
            self.bus.message.emit(msg)
        threading.Thread(target=work, daemon=True).start()

    def fit_services(self):
        """The services list: its columns as wide as the characters' list's, and just tall enough for its rows."""
        for i in range(len(COLS)):
            self.services.setColumnWidth(i, self.table.columnWidth(i))
        h = self.services.horizontalHeader().height() + sum(self.services.rowHeight(r) for r in range(self.services.rowCount())) + 4
        self.services.setFixedHeight(h)

    def service_state(self, key, text, color, since_text=""):
        r = next((i for i, row in enumerate(self.service_rows) if row[0] == key), None)
        if r is None:
            return
        item = QTableWidgetItem(text)
        item.setForeground(QColor(color))
        self.services.setItem(r, 3, item)
        self.services.setItem(r, 4, QTableWidgetItem(since_text))

    def refresh_decal(self):
        running = bool(mtcore.decal_agent_pids())
        on = (mtcore.load_config().get("decal_agent") or {}).get("enabled", True)
        if running:
            self.service_state("decal", "Running", "#2e9d4f")
        else:
            self.service_state("decal", "Stopped" + ("" if on else " (kept off)"), "#9e9e9e" if not on else "#d79b00")
        self.decal_btn.setText("Stop" if running else "Start")

    def refresh_ace(self):
        if not self.ace_there:
            return
        pids = mtcore.ace_pids()
        running = bool(pids)
        started = ""
        if running:
            try:
                started = since(datetime.fromtimestamp(os.stat("/proc/%d" % pids[0]).st_mtime, timezone.utc))
            except (OSError, Exception):
                started = ""
        self.service_state("ace", "Running" if running else "Stopped", "#2e9d4f" if running else "#9e9e9e", started)
        self.ace_btn.setText("Stop" if running else "Start")

    def toggle_ace(self):
        running = bool(mtcore.ace_pids())
        self.ace_btn.setEnabled(False)
        self.say("Stopping the ACE server (saving first)..." if running else "Starting the ACE server...")

        def work():
            ok, msg = mtcore.ace_stop(self.cfg) if running else mtcore.ace_start(self.cfg)
            self.bus.message.emit(msg)
        threading.Thread(target=work, daemon=True).start()
        QTimer.singleShot(3000, lambda: (self.ace_btn.setEnabled(True), self.refresh_ace()))

    def toggle_decal(self):
        running = bool(mtcore.decal_agent_pids())
        self.decal_btn.setEnabled(False)

        def work():
            ok, msg = mtcore.set_decal(not running)
            self.cfg.setdefault("decal_agent", {})["enabled"] = not running   # so saving Settings later keeps it
            self.bus.message.emit(msg)
        threading.Thread(target=work, daemon=True).start()
        QTimer.singleShot(2500, lambda: (self.decal_btn.setEnabled(True), self.refresh_decal()))

    def refresh(self):
        try:
            self.refresh_decal()
        except Exception:
            pass
        try:
            self.refresh_ace()
        except Exception:
            pass
        for r, a in enumerate(self.cfg["accounts"]):
            st = mtcore.read_status(self.cfg, a["account"])
            state = mtcore.client_state(st)
            if state == "offline":
                text, color = "Offline", QColor("#9e9e9e")
            elif state == "charselect":
                note = (st.get("loginNote") or "").strip()
                text, color = "Character screen" + (" - " + note if note else ""), QColor("#d79b00")
            else:
                text = "In game: %s" % st.get("character", "")
                if st.get("paused"):
                    text += " (paused by %s)" % st.get("pausedBy", "")
                elif not st.get("master", True):
                    text += " (MelkTank OFF)"
                color = QColor("#2e9d4f")
            item = QTableWidgetItem(text)
            item.setForeground(color)
            self.table.setItem(r, 3, item)
            online = state == "online"
            self.table.setItem(r, 4, QTableWidgetItem(since(mtcore.parse_iso(st.get("loginTime"))) if online else ""))

    def selected_account(self):
        r = self.table.currentRow()
        return self.cfg["accounts"][r] if 0 <= r < len(self.cfg["accounts"]) else None

    def set_enabled(self, acct, on):
        acct["enabled"] = on
        mtcore.save_config(self.cfg)

    def add_account(self):
        d = AccountDialog(self.cfg, None, self)
        if d.exec():
            v = d.value()
            if not v["account"]:
                return
            if mtcore.find_account(self.cfg, v["account"]):
                QMessageBox.warning(self, "Account", "%s is already in the list." % v["account"])
                return
            self.cfg["accounts"].append(v)
            mtcore.save_config(self.cfg)
            self.rebuild()

    def edit_account(self):
        a = self.selected_account()
        if not a:
            return
        d = AccountDialog(self.cfg, a, self)
        if d.exec():
            a.update(d.value())
            mtcore.save_config(self.cfg)
            self.rebuild()

    def remove_account(self):
        a = self.selected_account()
        if a and QMessageBox.question(self, "Remove", "Remove %s from the launcher?" % a["account"]) == QMessageBox.Yes:
            self.cfg["accounts"].remove(a)
            mtcore.save_config(self.cfg)
            self.rebuild()

    def edit_servers(self):
        d = ServersDialog(self.cfg, self)
        if d.exec():
            self.cfg["servers"] = d.value()
            mtcore.save_config(self.cfg)
            self.check_servers()

    def edit_acg_plugins(self):
        if AcgPluginsDialog(self.cfg, self).exec():
            self.say("ACGodot plugins saved - they apply the next time ACGodot starts.")

    def edit_settings(self):
        d = SettingsDialog(self.cfg, self)
        if d.exec():
            d.apply(self.cfg)
            mtcore.save_config(self.cfg)
            problems = mtcore.check_setup(self.cfg)
            self.say("Setup: " + " ".join(problems) if problems else "Settings saved.")

    # ── servers ──

    def check_servers(self):
        servers = list(self.cfg["servers"])

        def work():
            for s in servers:
                self.bus.server.emit(s["name"], mtcore.server_up(s["host"], s["port"]))
        threading.Thread(target=work, daemon=True).start()

    def check_now(self):
        self.server_label.setText("Servers: checking...")
        mtcore.ask_server_check()
        self.check_servers()

    def on_server(self, name, up):
        self.server_states[name] = up
        parts = []
        for s in self.cfg["servers"]:
            v = self.server_states.get(s["name"], "?")
            mark = "✓ up" if v is True else "✗ down" if v is False else "? no address" if v is None else "…"
            parts.append("%s  %s" % (s["name"], mark))
        self.server_label.setText("   |   ".join(parts) or "No servers set up")

    # ── launching ──

    def launch_ticked(self):
        self.launch([a["account"] for a in self.cfg["accounts"] if a.get("enabled", True)])

    def launch(self, names):
        if self.busy:
            self.say("Still launching - one moment.")
            return
        if not names:
            self.say("Nothing ticked.")
            return
        running = [n for n in names if mtcore.client_state(mtcore.read_status(self.cfg, n)) != "offline"]
        if running and QMessageBox.question(
                self, "Already running",
                "%s looks like it's already running. Start another client anyway?" % ", ".join(running)) != QMessageBox.Yes:
            names = [n for n in names if n not in running]
            if not names:
                return
        self.busy = True
        self.launch_btn.setEnabled(False)
        cfg = mtcore.load_config()

        def work():
            mtcore.launch_many(cfg, names, progress=self.bus.message.emit, manual=True)   # you're at the PC: keep the focus
            self.bus.done.emit()
        threading.Thread(target=work, daemon=True).start()

    def on_launch_done(self):
        self.busy = False
        self.launch_btn.setEnabled(True)
        self.refresh()

    def say(self, text):
        self.status.setText(datetime.now().strftime("%H:%M:%S  ") + text)

    def open_server_console(self):
        d = ServerConsoleDialog(self.cfg, self)
        d.setAttribute(Qt.WA_DeleteOnClose)
        d.show()

    def open_client_log(self):
        d = ClientLogDialog(self.cfg, self)
        d.setAttribute(Qt.WA_DeleteOnClose)
        d.show()

    def open_log(self):
        _open_file(mtcore.LOG_PATH)


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("MelkTank Launcher")
    w = Main()
    w.show()
    ret = app.exec()
    # tidy up while Qt is still running, so closing the window doesn't print
    # "shared QObject was deleted directly"
    w.timer.stop()
    w.server_timer.stop()
    w.deleteLater()
    app.processEvents()
    del w
    sys.exit(ret)


if __name__ == "__main__":
    main()
