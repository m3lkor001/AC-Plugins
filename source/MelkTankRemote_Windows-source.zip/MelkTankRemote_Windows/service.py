#!/usr/bin/env python3
"""
MelkTank phone service - the small web service the Android app talks to (over Tailscale).

    GET  /api/status                      every account: state, MelkTank's status file, server up/down
    POST /api/command   {account, action, feature, value, name}
                        action "set" + feature master|combat|nav|loot|summon|buff|debug + value on|off
                        action "navroute" + name, or "navspot" + name
    POST /api/interval  {seconds}         how often MelkTank writes its status file (15-600)
    POST /api/launch    {account}         start a client for that account (the app's Relaunch button)
    POST /api/reset     {relaunch}        close every game client and stop Wine (clears a stuck crash);
                        relaunch: start the ticked accounts again afterwards
    GET  /api/screenshot                  the PC's screen as a JPEG
    POST /api/kill      {account, mode, relaunch}  mode "normal": logs out properly, closed at the character screen;
                        "close": the game closed straight away (ACGodot; others as normal); "force": the client
                        process killed. relaunch: start it again afterwards

Every request needs the app key (Settings in the launcher) in an "X-Token" header.
Run by systemd:  systemctl --user status melktank-service
(Windows: started by run_service.pyw from the Startup folder, which starts it again when it stops.)
"""

import json
import re
import os
import secrets
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mtcore  # noqa: E402

_server_state = {}          # name -> {"up": bool|None, "checked": epoch}
_launch_lock = threading.Lock()
_launching = {}             # account -> message while a launch is running


_server_seen = {}           # name -> {"up": last recorded state, "fails": no answer in a row}


def _took(secs):
    m = int(round(secs / 60.0))
    return "%d h %d min" % (m // 60, m % 60) if m >= 60 else "%d min" % max(1, m)


def _server_change(name, up):
    """Records a server going down / coming back up (only the changes) - in the log and the client history."""
    seen = _server_seen.setdefault(name, {"up": None, "fails": 0, "since": time.time()})
    if up is None:
        return
    seen["fails"] = 0 if up else seen["fails"] + 1
    if not up and seen["fails"] < 2:
        return                          # one missed answer isn't "down" - two in a row (a minute apart) is
    if seen["up"] is None:
        seen["up"], seen["since"] = up, time.time()   # the first reading after the service starts: no change to record
        return
    if seen["up"] == up:
        return
    took = time.time() - seen["since"]
    seen["up"], seen["since"] = up, time.time()
    if up:
        text = "%s is back up (it was down %s)" % (name, _took(took))
    else:
        text = "%s isn't answering - down" % name
    mtcore.log("server " + text)
    mtcore.event(name, "server_up" if up else "server_down", text[:1].upper() + text[1:])
    if not up:
        seen["downAt"] = time.time()
    else:
        _back_after_server(name, seen.get("downAt") or (time.time() - took))




SERVER_BACK_MIN_WAIT = 120   # (asked for: clients start again only once the server has been back 2 min)


def _back_wait(cfg):
    """How long after a server comes back before clients are started on it: the setting, at least 2 min."""
    return max(SERVER_BACK_MIN_WAIT, int(cfg.get("server_back_wait_seconds", 90) or 0))


def _back_hold(cfg, server):
    """Seconds still to wait before starting a client on this server: it's down (None) or came back a moment ago."""
    st = _server_state.get(server, {})
    if st.get("up") is False:
        return None
    seen = _server_seen.get(server) or {}
    if seen.get("up") and seen.get("downAt"):
        left = _back_wait(cfg) - (time.time() - seen.get("since", 0))
        if left > 0:
            return left
    return 0


def _back_after_server(server, down_at):
    """The server is back: start the accounts its shutdown (a patch, a restart) logged out - they read as 'closed
    normally', since the server logs everyone off itself - and the ones that went while it was down."""
    try:
        cfg = mtcore.load_config()
        if not cfg.get("server_back_restart", True):
            mtcore.log("server %s is back: starting logged-out accounts is off (Settings)" % server)
            return
        window = max(0, int(cfg.get("server_back_window_minutes", 15))) * 60   # a "normal" logout this long before it went down
        wait = _back_wait(cfg)                                                  # after it answers again: time to take logins
        names, skipped = [], []
        for a in cfg["accounts"]:
            srv = mtcore.find_server(cfg, a.get("server"))
            if not srv or srv["name"] != server:
                continue
            w = _watch.get(a["account"].lower(), {})
            closed = w.get("closedAt", 0)
            if not closed:
                continue
            if not a.get("auto_restart", True):
                skipped.append("%s (not ticked to restart)" % a["account"])
            elif closed < down_at - window:
                skipped.append("%s (logged out %d min before it went down)" % (a["account"], (down_at - closed) // 60))
            elif w.get("armed") or mtcore.client_pids(a["account"]):
                skipped.append("%s (already running)" % a["account"])
            else:
                names.append(a["account"])
        if skipped:
            mtcore.log("server %s is back: not starting %s" % (server, ", ".join(skipped)))
        if not names:
            return
        mtcore.log("server %s is back: starting %s in %d s (logged out by its shutdown)" % (server, ", ".join(names), wait))

        def go():
            time.sleep(wait)
            for n in names:
                w = _watch.get(n.lower(), {})
                if mtcore.client_pids(n) or w.get("armed"):
                    mtcore.log("server back %s: already running - not starting another" % n)
                    continue
                w.pop("closedAt", None)
                ok, msg = start_launch(n)
                mtcore.log("server back %s: %s" % (n, msg))
                mtcore.event(n, "restart", "Starting it again - the server is back up")
        threading.Thread(target=go, daemon=True).start()
    except Exception as ex:
        mtcore.log("server back: %s" % ex)


def _seed_closed():
    """After a service restart: accounts whose last event is a normal logout in the last hour (a server shutdown
    may be under way) - so they're still started when the server comes back."""
    try:
        last = {}
        with open(mtcore.EVENTS_PATH, encoding="utf-8") as f:
            for line in f.readlines()[-300:]:
                try:
                    e = json.loads(line)
                except Exception:
                    continue
                last[(e.get("account") or "").lower()] = e
        now = time.time()
        for key, e in last.items():
            if e.get("kind") == "closed" and now - e.get("t", 0) < 60 * 60:
                _watch.setdefault(key, {"armed": False, "restarts": [], "note": ""})["closedAt"] = e["t"]
                mtcore.log("server watch: %s logged out %d min ago - started again if the server's down and comes back" % (key, (now - e["t"]) // 60))
        # a server that came back after those logouts (while this service wasn't watching it come back): start them now
        cfg = mtcore.load_config()
        for srv in cfg["servers"]:
            up = last.get(srv["name"].lower())
            if not up or up.get("kind") != "server_up" or now - up.get("t", 0) > 30 * 60:
                continue
            if any(w.get("closedAt", 0) and w["closedAt"] < up["t"] for w in _watch.values()):
                mtcore.log("server watch: %s came back %d min ago, after those logouts" % (srv["name"], (now - up["t"]) // 60))
                _back_after_server(srv["name"], up["t"] - 60 * 60)
    except Exception as ex:
        mtcore.log("seed closed: %s" % ex)


def server_watch():
    """Every 60 s - every 20 s while a server is down (so it's seen coming back sooner) - or right away when the
    launcher's Check now (or the phone) asks."""
    flag = mtcore.server_check_path()
    while True:
        try:
            cfg = mtcore.load_config()
            for s in cfg["servers"]:
                up = mtcore.server_up(s["host"], s["port"])
                _server_state[s["name"]] = {"up": up, "checked": time.time()}
                _server_change(s["name"], up)
        except Exception as ex:
            mtcore.log("server check failed: %s" % ex)
        down = any(v.get("up") is False for v in _server_state.values())
        until = time.time() + (20 if down else 60)
        while time.time() < until:
            if os.path.exists(flag):
                try: os.remove(flag)
                except Exception: pass
                mtcore.log("server check: asked for one now")
                break
            time.sleep(2)


SERVICE_VERSION = "2026-11-22a"
_pc_note = None   # {"text", "at"}: a note for the phone (notify.req), sent with the status


def _settings_lists(cfg, account):
    """The settings that are lists (one entry each, so an entry can hold commas), from the character's live mirror:
    {"TrackItems": [...], "TrackProfiles": [...], "TrackProfile": name} - the item tracking list in use and the item profiles."""
    import xml.etree.ElementTree as ET
    out = {}
    try:
        st = mtcore.read_status(cfg, account) or {}
        char = st.get("character") or ""
        if not char:
            return out
        part = mtcore._char_file_part(char)
        with open(mtcore.plugin_file(cfg, "MelkTank_Live_%s.xml" % part, part, account), encoding="utf-8-sig") as f:
            text = f.read()
        root = ET.fromstring(text[text.index("\n") + 1:])
        tl = root.find("TrackLive")   # the list in use (TrackList is the character's own)
        if tl is None:
            tl = root.find("TrackList")
        if tl is not None:
            out["TrackItems"] = [(i.text or "").strip() for i in tl.findall("Item") if (i.text or "").strip()]
        tp = root.find("TrackProfiles")
        out["TrackProfiles"] = [(i.text or "").strip() for i in tp.findall("Item") if (i.text or "").strip()] if tp is not None else []
        out["TrackProfile"] = (root.findtext("TrackProfile") or "").strip()
        cf = root.find("ChatFilter")
        out["ChatFilter"] = [(i.text or "").strip() for i in cf.findall("Item") if (i.text or "").strip()] if cf is not None else []
    except Exception as ex:
        mtcore.log("settings lists: %s" % ex)
    return out

_inv_open = {}   # account -> the game's inventory window was opened from the phone (and not closed since)

STATUS_FIELDS = ["character", "loggedIn", "running", "updated", "interval", "loginTime", "lastAttack", "lum", "lumMax",
                 "lumBank", "coins", "coinsBank", "deaths", "lastDeath", "master", "combat", "nav", "loot", "summon",
                 "buff", "debug", "paused", "pausedBy", "navMode", "navRoute", "navRoutes", "engineStatus", "loginNote",
                 "lastCommand", "characters", "clientStarted", "location", "navSpot", "navSpots", "loginStuck", "killsPerHour", "navStatus", "lumPerHour", "xpPerHour", "packAvg", "mobs", "corpses", "confirmText", "confirmAt", "confirmType", "build", "relogMB", "relogPending", "meta", "metaName", "metaState", "metas", "hp", "hpMax", "st", "stMax", "mp", "mpMax", "landcell", "enlOn", "enlStatus", "enlTarget", "enlNow", "enlLines", "tellSeq", "tellLast"]


def build_status():
    cfg = mtcore.load_config()
    accounts = []
    try:
        mem = mtcore.client_memory()   # {account: (in use, virtual)} - read from the system, so it works even if MelkTank is stuck
    except Exception:
        mem = {}
    memlc = {k.lower(): v for k, v in mem.items()}
    for a in cfg["accounts"]:
        st = mtcore.read_status(cfg, a["account"])
        entry = {
            "account": a["account"],
            "server": a.get("server", ""),
            "client": "ACGodot" if mtcore.is_acgodot(a) else "Retail",   # the card shows this in place of the account's name
            "configuredCharacter": a.get("character", ""),
            "state": mtcore.client_state(st),
            "launching": _launching.get(a["account"].lower(), ""),
            "restartNote": _watch.get(a["account"].lower(), {}).get("note", ""),
            "clientOpen": bool(mtcore.client_pids(a["account"])),
        }
        if a["account"].lower() in memlc:
            entry["memInUse"] = memlc[a["account"].lower()][0]
        if st:
            for k in STATUS_FIELDS:
                if k in st:
                    entry[k] = st[k]
        accounts.append(entry)
    servers = [{"name": s["name"], "up": _server_state.get(s["name"], {}).get("up")} for s in cfg["servers"]]
    return {"time": mtcore.utc_now_iso(), "interval": mtcore.get_interval(cfg), "servers": servers,
            "clients": mtcore.running_clients(), "accounts": accounts,
            "decal": {"running": _decal["running"], "note": _decal["note"],
                      "enabled": (cfg.get("decal_agent") or {}).get("enabled", True)},
            "pcNote": _pc_note or {}, "ace": _ace_brief(cfg)}


def _ace_brief(cfg):
    """The local ACE server in the status the phone polls: only whether it's there and its state (cheap: no login asked of it)."""
    try:
        root = mtcore.ace_root(cfg)
        if not os.path.isdir(os.path.join(root, "Source", "ACE.Server")):
            return {"installed": False}
        pids = mtcore.ace_pids()
        return {"installed": True, "running": bool(pids)}
    except Exception:
        return {"installed": False}


def start_launch(account):
    cfg = mtcore.load_config()
    if not mtcore.find_account(cfg, account):
        return False, "No account named %s." % account
    key = account.lower()
    if key in _launching:
        return False, "Already starting %s." % account
    if mtcore.client_pids(account):
        # a second client for the same account knocks the first out of the world
        return False, "%s's game is already running - close it first." % account

    def work():
        with _launch_lock:   # one launch at a time, and launch_delay apart
            _launching[key] = "starting"
            try:
                ok, msg = mtcore.launch_account(mtcore.load_config(), account)
                _launching[key] = msg
                time.sleep(int(cfg.get("launch_delay") or 20))
            finally:
                _launching.pop(key, None)
    threading.Thread(target=work, daemon=True).start()
    return True, "Starting %s." % account


_relaunching = set()   # accounts with a relaunch_after_exit already waiting (MelkTank's relog and its status can both ask)


def relaunch_after_exit(account, timeout=120):
    """After a normal exit from the phone: wait for the client to close, then start it again."""
    key = account.lower()
    if key in _relaunching:
        mtcore.log("relaunch after exit: already waiting on %s" % account)
        return
    _relaunching.add(key)
    try:
        _relaunch_after_exit(account, timeout)
    finally:
        _relaunching.discard(key)


def _relaunch_after_exit(account, timeout):
    deadline = time.time() + timeout
    orig = set(mtcore.client_pids(account))   # the client that's logging out - a new one isn't ours to close
    while time.time() < deadline:
        time.sleep(3)
        now = set(mtcore.client_pids(account))
        if not now:
            time.sleep(5)   # let the server finish the logout
            if mtcore.client_pids(account) or account.lower() in _launching:
                mtcore.log("relaunch after exit: %s was already started again - not starting another" % account)
                return
            start_launch(account)
            return
        if (orig and not (now & orig)) or account.lower() in _launching:
            # the old client closed and a new one is already up (started elsewhere, between two looks): done -
            # closing it at the time limit would throw the fresh login out
            mtcore.log("relaunch after exit: %s closed and was started again already" % account)
            return
    # still open after the logout (it sits on the character screen or a box): it's out of the world, so close it
    # and start it again - leaving it there means that account stays offline until someone looks
    ok, msg = mtcore.kill_client(mtcore.load_config(), account, kind="restart", why="planned relog: the client didn't close after logging out")
    mtcore.log("relaunch after exit: %s didn't close within %ds - %s" % (account, timeout, msg))
    for _ in range(10):
        if not mtcore.client_pids(account):
            break
        time.sleep(2)
    if mtcore.client_pids(account):
        mtcore.log("relaunch after exit: %s's client is still open - not relaunched" % account)
        return
    time.sleep(5)
    start_launch(account)


# ── Auto-restart ───────────────────────────────────────────────────
# An account is "armed" once its character is in the game. If its status then goes stale (MelkTank stopped
# writing without saying it was closing) and its acclient.exe is gone, it crashed: start it again.
# Not restarted: a client you closed (MelkTank writes running=false on the way out), one that's frozen but still
# open, one still on the character screen, or one that crashed 3 times in 30 minutes.

_watch = {}   # account (lower) -> {"armed": bool, "restarts": [epoch], "note": str}
RESTART_LIMIT, RESTART_WINDOW = 3, 30 * 60


def _note(w, account, text, kind=None):
    """Logs a watchdog note once (when it changes); kind also records it in the client history."""
    if w["note"] != text:
        w["note"] = text
        mtcore.log("auto-restart %s: %s" % (account, text))
        if kind:
            mtcore.event(account, kind, text[:1].upper() + text[1:])


def check_crashes(cfg):
    states = {}
    for a in cfg["accounts"]:
        st = mtcore.read_status(cfg, a["account"])
        states[a["account"]] = (st, mtcore.client_state(st))
    alive = sum(1 for st, state in states.values() if state != "offline")
    procs = mtcore.running_clients()
    for a in cfg["accounts"]:
        name = a["account"]
        key = name.lower()
        st, state = states[name]
        w = _watch.setdefault(key, {"armed": False, "restarts": [], "note": ""})
        if state == "online" and not w.get("seen"):
            mtcore.note_in_game(cfg, name, st)   # the start of this run, once (at its login time)
        w["seen"] = state == "online"
        if not a.get("auto_restart", True) or not (cfg.get("auto_restart") or cfg.get("restart_frozen")):
            w["armed"] = False
            if state == "offline" and mtcore._open_run(name):
                # not watched for restarts, but still worth a line in the history
                gone = st and st.get("running") is False
                mtcore.event(name, "closed" if gone else "crashed" if not mtcore.client_pids(name) else "unresponsive",
                             "Left the game" if gone else "Its client is gone" if not mtcore.client_pids(name) else "No word from it")
            continue
        if state == "online":
            # its status is still fresh, but the game process is gone: crashed just now - don't wait ~2 min for the
            # status to go stale. Seen on 2 checks in a row (15 s apart), so a slow process listing can't fool it.
            if w["armed"] and key not in _launching and not mtcore.client_pids(name):
                w["gone"] = w.get("gone", 0) + 1
                if w["gone"] < 2:
                    continue
                mtcore.log("auto-restart %s: its client process is gone (status still fresh) - treating it as a crash" % name)
                state = "offline"
                w["seen"] = False      # the restarted client's login is a new run
            else:
                w["gone"] = 0
                w["armed"] = True
                w["note"] = ""
                continue
        w["gone"] = 0
        if state != "offline" or not w["armed"] or key in _launching:
            continue
        dropped = False
        crashed_out = False
        if st and st.get("running") is False:
            # MelkTank stopped: a logout you (or the phone) asked for - or a disconnect, where the client stays
            # open on its "disconnected" box (restarted with the frozen-client option), or the client closed without
            # a logout (a crash - restarted like one).
            asked = st.get("logoffRequested")
            if asked and st.get("relaunch"):
                # MelkTank's planned relog (memory): start it again once the client has closed
                w["armed"] = False
                if mtcore._open_run(name):
                    mtcore.event(name, "restart", (st or {}).get("loginNote") or "Planned relog")
                _note(w, name, "planned relog - starting it again once it's closed")
                threading.Thread(target=relaunch_after_exit, args=(name,), daemon=True).start()
                continue
            if asked and "phone" not in (st.get("loginNote") or "").lower():
                # A logout while the screen is asleep wasn't you (the phone's own exit says "from the phone"):
                # the client gave up on a lost connection - treat it as a disconnect / crash, not "closed normally".
                asleep, how = mtcore.screen_asleep()
                if asleep:
                    mtcore.log("auto-restart %s: logged out while the screen was asleep (%s) - not you: treating it as a disconnect" % (name, how))
                    asked = False
            if not asked and not mtcore.client_pids(name):
                crashed_out = True
            elif not asked:
                dropped = True
                if not cfg.get("restart_frozen"):
                    w["armed"] = False
                    _note(w, name, "left the game without a logout (disconnected?) - not restarting (the frozen-client option is off)", "disconnected")
                    continue
            else:
                w["armed"] = False
                if mtcore._open_run(name):
                    mtcore.event(name, "closed", (st or {}).get("loginNote") or "Logged out / closed normally")
                w["closedAt"] = time.time()   # if the server goes down soon after, it was its shutdown: started when it's back
                _note(w, name, "closed normally - not restarting")
                continue
        if not crashed_out and (mtcore.client_pids(name) or (procs > alive and not cfg.get("restart_frozen"))):
            # its client is still open but MelkTank has gone quiet: frozen, or lost its connection
            if not cfg.get("restart_frozen"):
                _note(w, name, "stopped answering but a client is still open (frozen?) - not restarting", "unresponsive")
                continue
            if not mtcore.client_pids(name):
                continue
            age = (st or {}).get("_file_age", 0)
            limit = max(1, int(cfg.get("frozen_minutes", 3))) * 60
            if age < limit:
                _note(w, name, ("left the game without a logout (disconnected?) but its client is still open" if dropped else "no word from it") +
                      " - closing and restarting it if it's still like that at %d min" % (limit // 60),
                      "disconnected" if dropped else "unresponsive")
                continue
            srv = mtcore.find_server(cfg, a.get("server"))
            if srv and _server_state.get(srv["name"], {}).get("up") is False:
                _note(w, name, "no word from it - the server is down, waiting for it to come back", "server_down")
                continue
            if srv and _back_hold(cfg, srv["name"]):
                _note(w, name, "no word from it - the server is back, waiting until it's been back %d min" % (_back_wait(cfg) // 60))
                continue
            now = time.time()
            w["restarts"] = [t for t in w["restarts"] if now - t < RESTART_WINDOW]
            if len(w["restarts"]) >= RESTART_LIMIT:
                w["armed"] = False
                _note(w, name, "frozen - restarted %d times in 30 minutes already, leaving it" % RESTART_LIMIT, "gave_up")
                continue
            w["restarts"].append(now)
            w["armed"] = False
            wait = max(0, int(cfg.get("frozen_wait_seconds", 60)))
            ok, msg = mtcore.kill_client(cfg, name, kind="killed",
                                         why="No word from it for %d min - closed it" % (limit // 60))
            _note(w, name, "no word from it for %d min - %s Starting it again in %d s (%d of %d)." % (
                limit // 60, msg, wait, len(w["restarts"]), RESTART_LIMIT))
            mtcore.event(name, "restart", "Starting it again in %d s (%d of %d in 30 min)" % (wait, len(w["restarts"]), RESTART_LIMIT))

            def again(n=name, secs=wait):
                time.sleep(secs)
                if mtcore.client_pids(n):
                    # something else started it meanwhile (the phone, a login retry): a second client would knock the
                    # first one out of the world
                    mtcore.log("auto-restart %s: a client is already running again - not starting another" % n)
                    return
                ok2, msg2 = start_launch(n)
                mtcore.log("auto-restart %s: %s" % (n, msg2))
            threading.Thread(target=again, daemon=True).start()
            continue
        if mtcore._open_run(name):
            mtcore.event(name, "crashed", "Left the game without a logout and its client closed" if crashed_out else "Its client closed without logging out")
        if not cfg.get("auto_restart"):
            continue
        srv = mtcore.find_server(cfg, a.get("server"))
        if srv and _server_state.get(srv["name"], {}).get("up") is not False:
            # asked now: a client that closed because the server went away can close before the minute's check has
            # seen it go - started straight away, it failed to log in three times and was given up on
            try:
                if mtcore.server_up(srv["host"], srv["port"]) is False:
                    _server_state[srv["name"]] = {"up": False, "checked": time.time()}
            except Exception:
                pass
        if srv and _server_state.get(srv["name"], {}).get("up") is False:
            # (ACGodot closes itself when the server goes away: started again once it's been back a while)
            _note(w, name, "closed with the server down - starting it again once the server has been back %d min" % (_back_wait(cfg) // 60), "server_down")
            continue
        hold = _back_hold(cfg, srv["name"]) if srv else 0
        if hold:
            _note(w, name, "the server is back - starting it again once it's been back %d min" % (_back_wait(cfg) // 60))
            continue
        now = time.time()
        w["restarts"] = [t for t in w["restarts"] if now - t < RESTART_WINDOW]
        if len(w["restarts"]) >= RESTART_LIMIT:
            w["armed"] = False
            _note(w, name, "crashed %d times in 30 minutes - stopped restarting it" % RESTART_LIMIT, "gave_up")
            continue
        w["restarts"].append(now)
        w["armed"] = False   # armed again once it's back in the game
        ok, msg = start_launch(name)
        _note(w, name, "crashed - restarting (%d of %d): %s" % (len(w["restarts"]), RESTART_LIMIT, msg))
        mtcore.event(name, "restart", "Restarting after the crash (%d of %d in 30 min)" % (len(w["restarts"]), RESTART_LIMIT))


def crash_watch():
    while True:
        try:
            check_crashes(mtcore.load_config())
        except Exception as ex:
            mtcore.log("auto-restart check failed: %s" % ex)
        time.sleep(15)


_decal = {"running": False, "note": ""}


def _test_server(cfg, folder, line):
    """One server.txt request (see test_watch)."""
    try:
        verb, _, rest = line.partition(" ")
        verb = verb.lower()
        if verb == "start":
            ok, msg = mtcore.ace_start(cfg)
        elif verb == "stop":
            ok, msg = mtcore.ace_stop(cfg, wait=90)
        elif verb == "restart":
            ok, msg = mtcore.ace_stop(cfg, wait=90)
            if ok and not mtcore.ace_pids():
                ok, msg = mtcore.ace_start(cfg)
        elif verb == "cmd":
            ok, msg = mtcore.ace_command(rest)
            time.sleep(3)   # (what it answered, in the lines below)
        elif verb == "status":
            ok, msg = True, "status"
        else:
            ok, msg = False, "start, stop, restart, status or  cmd <console line>"
        mtcore.log("test server %s: %s" % (line, msg))
        st = mtcore.ace_status(cfg)
        os.makedirs(os.path.join(folder, "out"), exist_ok=True)
        with open(os.path.join(folder, "out", "server.txt"), "w") as f:
            f.write("%s %s %s: %s\n" % (time.strftime("%H:%M:%S"), line, "ok" if ok else "no", msg))
            f.write("state %s, ours %s, answering %s, database %s, since %s %s\n" % (
                st.get("state"), st.get("ours"), st.get("answering"), st.get("database"), st.get("since"), st.get("note") or ""))
            f.write("\n".join(mtcore.ace_log_tail(40)) + "\n")
    except Exception as ex:
        mtcore.log("test server: %s" % ex)


def test_watch(every=2):
    """A launch asked for by a file, for testing ACGodot from outside (Claude can reach this PC's files, not its
    network): while <the ACGodot project>/claude-test/on exists, a file claude-test/launch.txt naming an account on
    its first line starts that account's client - through the same queue as the phone's Launch - and what came of it
    is written to claude-test/out/launch.txt. No "on" file: nothing is looked at."""
    while True:
        time.sleep(every)
        try:
            cfg = mtcore.load_config()
            project = (cfg.get("acgodot") or {}).get("project", "")
            folder = os.path.join(project, "claude-test")
            if not project or not os.path.exists(os.path.join(folder, "on")):
                continue
            # (kill.txt, likewise naming an account: its client is closed - for one that's hung and can't be told to exit)
            stop = os.path.join(folder, "kill.txt")
            if os.path.exists(stop):
                with open(stop) as f:
                    account = f.readline().strip()
                os.remove(stop)
                ok, msg = mtcore.kill_client(cfg, account, note="Closed by a test") if account else (False, "No account named in kill.txt.")
                mtcore.log("test kill %s: %s" % (account, msg))
                os.makedirs(os.path.join(folder, "out"), exist_ok=True)
                with open(os.path.join(folder, "out", "kill.txt"), "w") as f:
                    f.write("%s %s: %s\n" % (time.strftime("%H:%M:%S"), "ok" if ok else "no", msg))
                continue
            # (server.txt: the local ACE server - start / stop / restart / status, or  cmd <a console line> - answered in
            # out/server.txt with how it stands and the last lines it wrote; slow ones go on by themselves)
            srv = os.path.join(folder, "server.txt")
            if os.path.exists(srv):
                with open(srv) as f:
                    line = f.readline().strip()
                os.remove(srv)
                threading.Thread(target=_test_server, args=(cfg, folder, line), daemon=True).start()
            st = os.path.join(folder, "selftest.txt")
            if os.path.exists(st):
                os.remove(st)
                threading.Thread(target=selftest, args=("asked for",), daemon=True).start()
            ask = os.path.join(folder, "launch.txt")
            if not os.path.exists(ask):
                continue
            with open(ask) as f:
                account = f.readline().strip()
            os.remove(ask)
            ok, msg = start_launch(account) if account else (False, "No account named in launch.txt.")
            mtcore.log("test launch %s: %s" % (account, msg))
            os.makedirs(os.path.join(folder, "out"), exist_ok=True)
            with open(os.path.join(folder, "out", "launch.txt"), "w") as f:
                f.write("%s %s: %s\n" % (time.strftime("%H:%M:%S"), "ok" if ok else "no", msg))
        except Exception as ex:
            mtcore.log("test launch: %s" % ex)


_selftest = {"running": False}


def _bridge(folder, name, lines, wait=60):
    """One request to a test client's bridge (claude-test/<account>/in/<name>.txt) and its answer, or None."""
    out = os.path.join(folder, "out", name + ".txt")
    try:
        os.remove(out)
    except OSError:
        pass
    os.makedirs(os.path.join(folder, "in"), exist_ok=True)
    tmp = os.path.join(folder, name + ".tmp")
    with open(tmp, "w") as f:
        f.write("\n".join(lines) + "\n")
    os.replace(tmp, os.path.join(folder, "in", name + ".txt"))
    end = time.time() + wait
    while time.time() < end:
        time.sleep(1)
        try:
            with open(out) as f:
                t = f.read()
            if "# done" in t:
                return t
        except OSError:
            pass
    return None


def _inv_name(line):
    """The name in an inventory line of the bridge's  inv  ("pack  Long Sword  value 240 ...")."""
    return line.strip()[5:].strip().split("  ")[0]


def selftest(why="after a build"):
    """
    The automatic test after each build: the test account (config "selftest_account", on the local ACE server) is started, and checked -
    logged in, its inventory there, an item moved in the pack and the server agreeing, a helmet taken off and put back,
    MelkTank reloaded in place, then out and back in to see the pack order kept - and closed again. Each check PASS or
    FAIL in claude-test/out/selftest.txt (and the launcher log). Skipped when the server isn't up or that client is
    already running (being used for something else).
    """
    if _selftest["running"]:
        return
    cfg = mtcore.load_config()
    # (only with a test account named in the settings - none by default)
    acct = (cfg.get("selftest_account") or "").strip()
    if not acct:
        return
    _selftest["running"] = True
    results, notes = [], []
    project = (cfg.get("acgodot") or {}).get("project", "")
    root = os.path.join(project, "claude-test")
    folder = os.path.join(root, acct)
    report = os.path.join(root, "out", "selftest.txt")

    def check(name, ok, detail=""):
        results.append(("PASS" if ok else "FAIL", name, detail))

    def write(state):
        try:
            os.makedirs(os.path.dirname(report), exist_ok=True)
            with open(report, "w") as f:
                f.write("%s self-test %s (%s)\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), state, why))
                for r in results:
                    f.write("%s  %s%s\n" % (r[0], r[1], ("  - " + r[2]) if r[2] else ""))
                for n in notes:
                    f.write("note: %s\n" % n)
        except OSError:
            pass

    def errors_size():
        try:
            return os.path.getsize(os.path.join(project, "plugins", "MelksTank", "Logs", "MelkTank_errors.txt"))
        except OSError:
            return 0

    def logged_in(wait):
        end = time.time() + wait
        while time.time() < end:
            t = _bridge(folder, "zst-held-%d" % int(time.time()), ["held"], wait=10)
            if t and "things described" in t and " 0 things described" not in t:
                return t
            time.sleep(5)
        return None

    try:
        if not project or not os.path.exists(os.path.join(root, "on")):
            return
        if not mtcore.find_account(cfg, acct):
            return
        if not mtcore.ace_status(cfg).get("answering"):
            mtcore.log("self-test skipped: the local ACE server isn't answering")
            return
        if mtcore.acgodot_running(acct):
            mtcore.log("self-test skipped: %s is already running" % acct)
            return
        write("running")
        err0 = errors_size()
        ok, msg = start_launch(acct)
        if not ok:
            check("start the test client", False, msg)
            return
        held = logged_in(150)
        check("logs in to the local server", held is not None, (held or "no answer in 150 s").strip().splitlines()[-2] if held else "no answer in 150 s")
        if not held:
            return
        inv = _bridge(folder, "zst-inv", ["inv zzqq"], wait=20) or ""
        packed = [l.strip() for l in inv.splitlines() if l.strip().startswith("pack  ") or l.strip().startswith("pack* ")]
        check("inventory is there", len(packed) > 0, "%d things in the packs" % len(packed))
        # an item moved to the front of the main pack: the server says where it went
        main_items = [_inv_name(l) for l in packed if l.startswith("pack  ")]
        pick = next((n for n in main_items[1:] if n and not n[0].isdigit()), None)
        if pick:
            t = _bridge(folder, "zst-move", ["move %s | main | 0" % pick, "wait 3", "inv zzqq"], wait=30) or ""
            first = next((_inv_name(l) for l in t.splitlines() if l.strip().startswith("pack  ")), "")
            check("an item moved in the pack lands where asked", first == pick, "%s first in the main pack: %s" % (pick, first or "?"))
        else:
            check("an item moved in the pack lands where asked", False, "nothing in the main pack to move")
        # the helmet off and on again
        t = _bridge(folder, "zst-equip", ["unequip Pathwarden Helm", "wait 3", "inv zzqq", "equip Pathwarden Helm", "wait 3", "inv zzqq"], wait=40) or ""
        parts = t.split("> inv zzqq")
        off = len(parts) > 2 and "worn  Pathwarden Helm" not in parts[1]
        on = len(parts) > 2 and "worn  Pathwarden Helm" in parts[2]
        check("a helmet comes off and goes back on", off and on, "off: %s, on again: %s" % (off, on))
        # MelkTank reloaded in place
        t = _bridge(folder, "zst-reload", ["/plugins reload MelksTank", "wait 12"], wait=40) or ""
        # (and that the copy now running is the DLL on disk: its build number, as MelkTank notes it taking over)
        want = ""
        try:
            with open(os.path.join(project, "plugins", "MelksTank", "BuildInfo.cs")) as f:
                m = re.search(r"Number\s*=\s*(\d+)", f.read())
                want = "b" + m.group(1) if m else ""
        except OSError:
            pass
        took, took_at = "", ""
        try:
            logs = os.path.join(project, "plugins", "MelksTank", "Logs")
            for d in os.listdir(logs):
                p = os.path.join(logs, d)
                if os.path.isdir(p):
                    for n in os.listdir(p):
                        if n.startswith("MelkTank_debug_") and time.time() - os.path.getmtime(os.path.join(p, n)) < 120:
                            with open(os.path.join(p, n), "rb") as f:
                                f.seek(0, 2); f.seek(max(0, f.tell() - 200000))
                                hits = re.findall(r"^(\d\d:\d\d:\d\d)\.\d+ .*?build (b\d+) \([^)]*\) took over", f.read().decode("utf-8", "replace"), re.M)
                                if hits and hits[-1][0] > took_at:   # (the newest across the characters' logs: the test one's)
                                    took_at, took = hits[-1]
        except OSError:
            pass
        check("MelkTank reloads without restarting the game", "reloaded" in t and "didn't load" not in t and (not want or took == want),
              "%s; running %s, on disk %s" % (next((l.strip(" |") for l in t.splitlines() if "reloaded" in l or "didn't" in l), "no answer"), took or "?", want or "?"))
        # out and back in: the pack order the server keeps
        _bridge(folder, "zst-exit", ["logoutexit"], wait=5)   # (logged out properly, closed at the character screen)
        time.sleep(15)
        ok, msg = start_launch(acct)
        held = logged_in(150) if ok else None
        check("logs in again", held is not None, msg if not ok else "")
        if held and pick:
            t = _bridge(folder, "zst-inv2", ["inv zzqq"], wait=20) or ""
            first = next((_inv_name(l) for l in t.splitlines() if l.strip().startswith("pack  ")), "")
            check("the pack order is kept after logging out", first == pick, "first in the main pack: %s" % (first or "?"))
        grew = errors_size() - err0
        check("MelkTank logged no errors", grew <= 0, "" if grew <= 0 else "%d bytes added to MelkTank_errors.txt" % grew)
    except Exception as ex:
        notes.append("the test itself failed: %s" % ex)
    finally:
        try:
            if mtcore.acgodot_running(acct):
                _bridge(folder, "zst-close", ["exit"], wait=5)
        except Exception:
            pass
        fails = sum(1 for r in results if r[0] == "FAIL")
        if results or notes:
            write("done: %d passed, %d failed" % (len(results) - fails, fails))
            mtcore.log("self-test (%s): %d passed, %d failed%s" % (why, len(results) - fails, fails,
                       "".join("; FAIL %s" % r[1] for r in results if r[0] == "FAIL")))
        _selftest["running"] = False


def build_watch(every=5, settle=4):
    """Builds ACGodot in the background as soon as its source changes (once the files have stopped changing for a few
    seconds), so launching doesn't have to - a launch still checks, and waits on this one if it's mid-build. What came
    of the last build is in ~/.cache/melktank/acgodot-build.txt (and claude-test/out/build.txt while testing is on)."""
    last = None
    while True:
        time.sleep(every)
        try:
            cfg = mtcore.load_config()
            project = (cfg.get("acgodot") or {}).get("project", "")
            if not project or not os.path.isdir(project):
                continue
            newest = mtcore._acgodot_newest(project, (".cs",))
            dll = os.path.join(project, ".godot", "mono", "temp", "bin", "Debug", "ACGodot.dll")
            built = os.path.getmtime(dll) if os.path.exists(dll) else 0.0
            if newest <= built or time.time() - newest < settle or newest == last:
                continue
            last = newest   # (a failed build isn't tried again till something changes)
            t0 = time.time()
            ok, msg = mtcore.acgodot_build_if_needed(project)
            note = "%s %s: %s (%.0f s)" % (time.strftime("%Y-%m-%d %H:%M:%S"), "built" if ok else "FAILED", msg, time.time() - t0)
            mtcore.log("background build: %s" % note)
            # (no self-test after a build: the build is the check, and the test character is kept for real testing -
            # a self-test runs only when asked for, claude-test/selftest.txt)
            for path in [os.path.join(mtcore.LOG_DIR, "acgodot-build.txt")] + (
                    [os.path.join(project, "claude-test", "out", "build.txt")] if os.path.exists(os.path.join(project, "claude-test", "on")) else []):
                try:
                    os.makedirs(os.path.dirname(path), exist_ok=True)
                    with open(path, "w") as f:
                        f.write(note + "\n")
                except OSError:
                    pass
        except Exception as ex:
            mtcore.log("background build: %s" % ex)


def decal_watch(every=30):
    """Keeps Decal's agent running: starts it when the service starts and again whenever it has closed
    (Reset game stops it too). Off with "decal_agent": {"enabled": false} in the config."""
    fails = 0
    while True:
        try:
            cfg = mtcore.load_config()
            on = (cfg.get("decal_agent") or {}).get("enabled", True)
            running = bool(mtcore.decal_agent_pids())
            _decal["running"] = running
            if on and not running and fails < 3:
                ok, msg = mtcore.start_decal_agent(cfg)
                _decal["note"] = msg
                if ok:
                    fails = 0
                    time.sleep(10)
                    if not mtcore.decal_agent_pids():
                        fails += 1
                        mtcore.log("decal agent: closed again straight after starting (%d of 3)" % fails)
                else:
                    fails = 3
                    mtcore.log("decal agent: " + msg)
            elif running:
                fails = 0
                _decal["note"] = ""
        except Exception as ex:
            mtcore.log("decal watch failed: %s" % ex)
        time.sleep(every)


def memory_watch(every=600):
    """Writes each game client's memory use to the log every 10 minutes, so a crash after hours of play shows
    whether memory was climbing (AC is a 32-bit program: it falls over near 4 GB virtual / ~2-3 GB in use)."""
    def gb(n):
        return "%.2f GB" % (n / 1024.0 ** 3)
    while True:
        time.sleep(every)
        try:
            mem = mtcore.client_memory()
            if mem:
                asleep, how = mtcore.screen_asleep()
                mtcore.log("memory: " + "; ".join("%s %s in use, %s virtual" % (a, gb(r), gb(v))
                                                  for a, (r, v) in sorted(mem.items())) + ("; screen: " + how if how else ""))
        except Exception as ex:
            mtcore.log("memory check failed: %s" % ex)


BACKUP_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Backup")


def _backup_launcher_config(keep=30):
    """The launcher's own settings (~/.config/melktank: accounts, options) copied into Backup/launcher - a dated copy
    when they've changed, the newest few kept. Private (only you can read them): they hold your logins."""
    import shutil
    src = mtcore.CONFIG_DIR
    if not os.path.isdir(src):
        return
    dest = os.path.join(BACKUP_DIR, "launcher")
    os.makedirs(dest, exist_ok=True)
    os.chmod(BACKUP_DIR, 0o700)
    os.chmod(dest, 0o700)
    names = sorted(n for n in os.listdir(src) if os.path.isfile(os.path.join(src, n)) and not n.endswith(".tmp"))
    snaps = sorted(d for d in os.listdir(dest) if re.match(r"^\d{4}-\d\d-\d\d_\d{4}$", d))
    if snaps:
        last = os.path.join(dest, snaps[-1])
        same = True
        for n in names:
            a, b = os.path.join(src, n), os.path.join(last, n)
            try:
                with open(a, "rb") as fa, open(b, "rb") as fb:
                    if fa.read() != fb.read():
                        same = False
                        break
            except OSError:
                same = False
                break
        if same:
            return
    to = os.path.join(dest, time.strftime("%Y-%m-%d_%H%M"))
    os.makedirs(to, exist_ok=True)
    os.chmod(to, 0o700)
    for n in names:
        shutil.copy2(os.path.join(src, n), os.path.join(to, n))
        os.chmod(os.path.join(to, n), 0o600)
    snaps.append(os.path.basename(to))
    while len(snaps) > keep:
        shutil.rmtree(os.path.join(dest, snaps.pop(0)), ignore_errors=True)
    mtcore.log("backup: launcher settings copied (%d file(s)) to %s" % (len(names), to))


def _ace_databases(cfg):
    """The ACE server's databases as its Config.js names them: [(label, host, port, database, user, password)]."""
    root = mtcore.ace_root(cfg)
    b = mtcore._ace_bin(root)
    path = os.path.join(b or os.path.join(root, "Source", "ACE.Server"), "Config.js")
    with open(path, encoding="utf-8-sig") as f:
        t = f.read()
    t = re.sub(r"^\s*//.*$", "", t, flags=re.M)          # (Config.js carries // comments)
    t = re.sub(r'([,{\[\]}"\d]|true|false|null)[ \t]*//[^\n]*', r"\1", t)   # (comments after a value too)
    t = re.sub(r",(\s*[}\]])", r"\1", t)                 # (and trailing commas)
    my = json.loads(t).get("MySql") or {}
    out = []
    for label in ("Authentication", "Shard", "World"):
        d = my.get(label) or {}
        if d.get("Database"):
            out.append((label, d.get("Host") or "127.0.0.1", int(d.get("Port") or 3306), d["Database"],
                        d.get("Username") or "", d.get("Password") or ""))
    return out


def _backup_ace(cfg, keep_days=14, world_every_days=7):
    """A dump of the local ACE server's databases (characters and accounts every day; the world, which hardly changes
    and is big, once a week) into ACE's Backup folder as .sql.gz, the last two weeks kept."""
    import gzip
    import shutil
    import subprocess
    import tempfile
    tool = shutil.which("mariadb-dump") or shutil.which("mysqldump")
    if not tool:
        mtcore.log("backup: no mysqldump / mariadb-dump on this PC - the ACE database isn't backed up")
        return
    dest = os.path.join(mtcore.ace_root(cfg), "Backup")
    os.makedirs(dest, exist_ok=True)
    os.chmod(dest, 0o700)
    today = time.strftime("%Y-%m-%d")
    for label, host, port, db, user, pw in _ace_databases(cfg):
        existing = sorted(n for n in os.listdir(dest) if n.startswith(db + "_") and n.endswith(".sql.gz"))
        if any(n.startswith(db + "_" + today) for n in existing):
            continue
        if label == "World" and existing:
            try:
                newest = time.mktime(time.strptime(existing[-1][len(db) + 1:len(db) + 11], "%Y-%m-%d"))
                if time.time() - newest < world_every_days * 86400:
                    continue
            except ValueError:
                pass
        # (the login goes in a private file the dump reads - never on the command line, where any program can see it)
        fd, opt = tempfile.mkstemp(prefix="acedump-", suffix=".cnf")
        out = os.path.join(dest, "%s_%s.sql.gz" % (db, time.strftime("%Y-%m-%d_%H%M")))
        try:
            with os.fdopen(fd, "w") as f:
                f.write("[client]\nhost=%s\nport=%d\nuser=%s\npassword=\"%s\"\n" % (host, port, user, pw.replace("\\", "\\\\").replace('"', '\\"')))
            os.chmod(opt, 0o600)
            p = subprocess.Popen([tool, "--defaults-extra-file=" + opt, "--single-transaction", "--quick", "--routines",
                                  "--events", "--triggers", "--databases", db], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            with gzip.open(out + ".part", "wb") as g:
                shutil.copyfileobj(p.stdout, g, 1 << 20)
            err = p.stderr.read().decode("utf-8", "replace").strip()
            if p.wait() != 0:
                os.remove(out + ".part")
                mtcore.log("backup: dumping ACE's %s database failed: %s" % (db, err[:300]))
                continue
            os.replace(out + ".part", out)
            os.chmod(out, 0o600)
            mtcore.log("backup: ACE's %s database dumped to %s (%.1f MB)" % (db, out, os.path.getsize(out) / 1048576.0))
        finally:
            try:
                os.remove(opt)
            except OSError:
                pass
        cutoff = time.time() - keep_days * 86400
        for n in existing:
            try:
                if time.mktime(time.strptime(n[len(db) + 1:len(db) + 11], "%Y-%m-%d")) < cutoff:
                    os.remove(os.path.join(dest, n))
            except (ValueError, OSError):
                pass


_backup_now = threading.Event()


def backup_watch(every=3600):
    """Backups: the launcher's settings (when they change) and the ACE server's databases (once a day)."""
    time.sleep(60)
    while True:
        cfg = mtcore.load_config()
        try:
            _backup_launcher_config()
        except Exception as ex:
            mtcore.log("backup: launcher settings failed: %s" % ex)
        try:
            if mtcore._mariadb_active() is not False and os.path.isdir(mtcore.ace_root(cfg)):
                _backup_ace(cfg)
        except Exception as ex:
            mtcore.log("backup: ACE database failed: %s" % ex)
        _backup_now.wait(every)
        _backup_now.clear()


class Handler(BaseHTTPRequestHandler):
    server_version = "MelkTankService/1.0"

    def log_message(self, fmt, *args):   # quiet: only errors go to the log
        pass

    def _send(self, code, obj):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _authorized(self):
        token = mtcore.load_config()["service"]["token"]
        given = self.headers.get("X-Token", "")
        return bool(token) and secrets.compare_digest(given.encode(), token.encode())

    def _body(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
            return json.loads(self.rfile.read(n).decode("utf-8")) if n > 0 else {}
        except Exception:
            return {}

    def do_GET(self):
        if self.path.split("?")[0] == "/api/ping":
            return self._send(200, {"ok": True})
        if not self._authorized():
            return self._send(401, {"error": "wrong app key"})
        if self.path.split("?")[0] == "/api/status":
            return self._send(200, build_status())
        if self.path.split("?")[0] == "/api/ace":
            # the local ACE test server: is it there, running, answering (the phone's card for it)
            return self._send(200, mtcore.ace_status(mtcore.load_config()))
        if self.path.split("?")[0] == "/api/ace/console":
            # its console output, the last 100 lines (asked for only while the phone's server page is open)
            return self._send(200, mtcore.ace_console(100))
        if self.path.split("?")[0] == "/api/ace/commands":
            # the commands its console takes, for the server page's list
            return self._send(200, {"commands": mtcore.ace_commands(mtcore.load_config())})
        if self.path.split("?")[0] == "/api/plugins":
            # Decal's plugins, on / off (the phone's Decal plugins page)
            try:
                return self._send(200, {"plugins": mtcore.decal_plugins(mtcore.load_config())})
            except Exception as ex:
                return self._send(500, {"error": "Couldn't read Decal's plugins (%s)." % ex})
        if self.path.split("?")[0] == "/api/builds":
            return self._send(200, mtcore.core_builds(mtcore.load_config()))
        if self.path.split("?")[0] == "/api/settings":
            from urllib.parse import urlparse, parse_qs
            cfg = mtcore.load_config()
            acct = mtcore.find_account(cfg, (parse_qs(urlparse(self.path).query).get("account") or [""])[0])
            if not acct:
                return self._send(400, {"error": "unknown account"})
            try:
                data = mtcore.read_settings(cfg, acct["account"])
            except Exception as ex:
                return self._send(404, {"error": "Couldn't read the settings file (%s)." % ex})
            if data is None:
                return self._send(404, {"error": "The character has to be in the game first."})
            data["lists"] = _settings_lists(cfg, acct["account"])
            return self._send(200, data)
        if self.path.split("?")[0] == "/api/session":
            from urllib.parse import urlparse, parse_qs
            cfg = mtcore.load_config()
            acct = mtcore.find_account(cfg, (parse_qs(urlparse(self.path).query).get("account") or [""])[0])
            if not acct:
                return self._send(400, {"error": "unknown account"})
            data = mtcore.read_session(cfg, acct["account"])
            if data is None:
                return self._send(404, {"error": "No session yet - the character has to be in the game with the new MelkTank."})
            return self._send(200, data)
        if self.path.split("?")[0] in ("/api/navs", "/api/nav", "/api/metas", "/api/meta", "/api/preset"):
            # the phone's nav / meta editors
            from urllib.parse import urlparse, parse_qs
            import navmeta
            cfg = mtcore.load_config()
            q = parse_qs(urlparse(self.path).query)
            p = self.path.split("?")[0]
            try:
                if p == "/api/navs":
                    return self._send(200, navmeta.nav_list(cfg))
                if p == "/api/nav":
                    return self._send(200, navmeta.nav_read(cfg, (q.get("file") or [""])[0]))
                if p == "/api/preset":
                    return self._send(200, navmeta.preset_read(cfg, (q.get("name") or [""])[0]))
                if p == "/api/metas":
                    return self._send(200, navmeta.meta_list(cfg))
                return self._send(200, navmeta.meta_read(cfg, (q.get("file") or [""])[0]))
            except FileNotFoundError:
                return self._send(404, {"error": "That file isn't there any more."})
            except Exception as ex:
                return self._send(500, {"error": "Couldn't read it (%s)." % ex})
        if self.path.split("?")[0] == "/api/organize":
            from urllib.parse import urlparse, parse_qs
            cfg = mtcore.load_config()
            acct = mtcore.find_account(cfg, (parse_qs(urlparse(self.path).query).get("account") or [""])[0])
            if not acct:
                return self._send(400, {"error": "unknown account"})
            data = mtcore.read_organize(cfg, acct["account"])
            if data is None:
                return self._send(404, {"error": "Nothing yet - the character has to be in the game with MelkTank b73 or later."})
            return self._send(200, data)
        if self.path.split("?")[0] == "/api/chat":
            from urllib.parse import urlparse, parse_qs
            cfg = mtcore.load_config()
            acct = mtcore.find_account(cfg, (parse_qs(urlparse(self.path).query).get("account") or [""])[0])
            if not acct:
                return self._send(400, {"error": "unknown account"})
            data = mtcore.read_chat(cfg, acct["account"])
            if data is None:
                return self._send(404, {"error": "No chat yet - the character has to be in the game with the new MelkTank."})
            return self._send(200, data)
        if self.path.split("?")[0].startswith("/api/loot/"):
            from urllib.parse import urlparse, parse_qs
            cfg = mtcore.load_config()
            route = self.path.split("?")[0]
            q = parse_qs(urlparse(self.path).query)
            try:
                if route == "/api/loot/spec":
                    import lootmodel
                    return self._send(200, lootmodel.SPEC)
                if route == "/api/loot/list":
                    return self._send(200, mtcore.loot_list(cfg))
                if route == "/api/loot/profile":
                    import lootmodel
                    name = (q.get("name") or [""])[0]
                    p, mt = mtcore.loot_load(cfg, name)
                    return self._send(200, lootmodel.profile_json(p, name, mt))
            except (OSError, ValueError, Exception) as ex:
                return self._send(400, {"error": str(ex)})
            return self._send(404, {"error": "no such loot call"})
        if self.path.split("?")[0] == "/api/events":
            # the client history: newest first, plus a summary of the last 24 hours per account
            from urllib.parse import urlparse, parse_qs
            cfg = mtcore.load_config()
            q = parse_qs(urlparse(self.path).query)
            acct = (q.get("account") or [""])[0] or None
            try:
                limit = max(1, min(2000, int((q.get("limit") or ["300"])[0])))
            except ValueError:
                limit = 300
            evs = mtcore.read_events(acct, limit=limit)
            evs.reverse()
            for e in evs:
                e["kindName"] = mtcore.EVENT_KINDS.get(e.get("kind"), e.get("kind"))
            return self._send(200, {"events": evs, "summary": mtcore.events_summary(cfg), "now": int(time.time())})
        if self.path.split("?")[0] == "/api/inventory":
            from urllib.parse import urlparse, parse_qs
            cfg = mtcore.load_config()
            acct = mtcore.find_account(cfg, (parse_qs(urlparse(self.path).query).get("account") or [""])[0])
            if not acct:
                return self._send(400, {"error": "unknown account"})
            data = mtcore.read_inventory(cfg, acct["account"])
            if data is None:
                return self._send(404, {"error": "No inventory yet - the character has to be in the game with the new MelkTank."})
            return self._send(200, data)
        if self.path.split("?")[0] == "/api/screenshot":
            try:
                img = mtcore.screenshot()
            except Exception as ex:
                return self._send(500, {"error": str(ex)})
            self.send_response(200)
            self.send_header("Content-Type", "image/jpeg")
            self.send_header("Content-Length", str(len(img)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(img)
            return
        self._send(404, {"error": "not found"})

    def do_POST(self):
        if not self._authorized():
            return self._send(401, {"error": "wrong app key"})
        path = self.path.split("?")[0]
        b = self._body()
        cfg = mtcore.load_config()
        try:
            if path == "/api/logincmds":
                # MelkTank's Settings > Commands from the phone's settings page: the whole list back
                acct = mtcore.find_account(cfg, b.get("account", "")) if b.get("account") else None
                ok, r = mtcore.save_login_cmds(cfg, b.get("commands") or [], b.get("mtime"), bool(b.get("force")),
                                               account=acct["account"] if acct else None)
                if not ok:
                    return self._send(409, {"error": r})
                return self._send(200, {"ok": True, "mtime": r, "message": "Saved - MelkTank picks it up in a few seconds."})
            if path == "/api/plugins":
                ok, msg = mtcore.set_decal_plugin(cfg, str(b.get("id") or ""), bool(b.get("enabled")))
                return self._send(200 if ok else 400, {"ok": ok, "message": msg})
            if path == "/api/ace/command":
                # a line typed into the server's console: a command and what follows it
                line = (str(b.get("command") or "") + " " + str(b.get("args") or "")).strip()
                ok, msg = mtcore.ace_command(line)
                mtcore.log("phone: ACE console - %s" % msg)
                return self._send(200 if ok else 400, {"ok": ok, "message": msg})
            if path == "/api/ace":
                # the local ACE test server started or stopped from the phone
                act = str(b.get("action") or "").lower()
                if act not in ("start", "stop", "restart"):
                    return self._send(400, {"error": "action: start, stop or restart"})
                if act == "start":
                    ok, msg = mtcore.ace_start(cfg)
                elif act == "stop":
                    ok, msg = mtcore.ace_stop(cfg, wait=6)   # (the phone doesn't wait out the whole save)
                else:
                    pids = mtcore.ace_pids()
                    if pids and mtcore._ace_ours(pids) is None:
                        ok, msg = mtcore.ace_stop(cfg, wait=0)   # (started in a terminal: says so)
                    else:
                        def again():
                            ok2, m2 = mtcore.ace_stop(cfg, wait=90)
                            if ok2 and not mtcore.ace_pids():
                                ok2, m2 = mtcore.ace_start(cfg)
                            mtcore.log("phone: ACE server restart - %s" % m2)
                        threading.Thread(target=again, daemon=True).start()
                        ok, msg = True, "Restarting the ACE server: it saves, stops, and starts again (about a minute)."
                mtcore.log("phone: ACE server %s - %s" % (act, msg))
                return self._send(200 if ok else 400, {"ok": ok, "message": msg, "status": mtcore.ace_status(cfg)})
            if path == "/api/click":
                # the phone's PC screen page: you tapped there (in screenshot pixels) and said yes - a real click
                if "to_x" in b and "to_y" in b:   # (a drag: pressed at x,y, let go at to_x,to_y)
                    ok, msg = mtcore.drag_screen(float(b.get("x", 0)), float(b.get("y", 0)), float(b["to_x"]), float(b["to_y"]))
                else:
                    ok, msg = mtcore.click_screen(float(b.get("x", 0)), float(b.get("y", 0)), button=3 if str(b.get("button", "")).lower() == "right" else 1,
                                                   double=bool(b.get("double")))
                if ok and str(b.get("text") or "") != "" or (ok and b.get("enter") and "text" in b):
                    # click and type: the click puts the keyboard there, then the text is typed (it isn't logged)
                    time.sleep(0.4)
                    ok2, msg2 = mtcore.type_text(str(b.get("text") or ""), bool(b.get("enter")))
                    ok, msg = ok2, msg + " " + msg2
                mtcore.log("phone click: " + msg)
                return self._send(200 if ok else 500, {"ok": ok, "message": msg})
            if path == "/api/loot/profile":
                # save an edited profile (the phone's loot editor); push = the running characters read it again
                import lootmodel
                name = b.get("name") or ""
                prof = lootmodel.profile_from_json(b.get("profile") or {})
                ok, mt = mtcore.loot_save(cfg, name, prof, b.get("mtime"), bool(b.get("force")))
                if not ok:
                    return self._send(409, {"error": "The profile was changed on the PC since you opened it - Sync to get the new copy (or save anyway).", "mtime": mt})
                sent = mtcore.loot_push(cfg, name) if b.get("push") else []
                p2, mt2 = mtcore.loot_load(cfg, name)
                return self._send(200, {"ok": True, "message": "Saved" + (" and pushed to " + ", ".join(sent) if sent else (" - no game running to push to" if b.get("push") else "")) + ".",
                                        "profile": lootmodel.profile_json(p2, name, mt2)})
            if path.startswith("/api/preset/"):
                import navmeta
                op = path.split("/")[3]
                if op == "save":
                    res, err = navmeta.preset_save(cfg, b.get("old") or None, b.get("data") or {}, b.get("mtime"), bool(b.get("force")))
                elif op == "new":
                    res, err = navmeta.preset_new(cfg, b.get("name") or "", b.get("copy") or None)
                elif op == "delete":
                    res, err = navmeta.preset_delete(cfg, b.get("name") or ""), None
                else:
                    return self._send(404, {"error": "unknown"})
                if err:
                    return self._send(409, {"error": err})
                return self._send(200, res)
            if path.startswith("/api/nav/") or path.startswith("/api/meta/"):
                import navmeta
                kind, op = path.split("/")[2], path.split("/")[3]
                if op == "save":
                    fn = navmeta.nav_save if kind == "nav" else navmeta.meta_save
                    res, err = fn(cfg, b.get("file") or None, b.get("data") or {}, b.get("mtime"), bool(b.get("force")))
                elif op == "new":
                    fn = navmeta.nav_new if kind == "nav" else navmeta.meta_new
                    res, err = fn(cfg, b.get("name") or "", b.get("copy") or None)
                elif op == "delete":
                    res, err = (navmeta.nav_delete if kind == "nav" else navmeta.meta_delete)(cfg, b.get("file") or ""), None
                else:
                    return self._send(404, {"error": "unknown"})
                if err:
                    return self._send(409, {"error": err})
                return self._send(200, res)
            if path == "/api/loot/row":
                import lootmodel
                return self._send(200, lootmodel.row_req_json(b))
            if path == "/api/loot/push":
                sent = mtcore.loot_push(cfg, b.get("name") or "")
                return self._send(200, {"ok": True, "message": ("Pushed to " + ", ".join(sent)) if sent else "No game running to push to."})
            if path == "/api/command":
                acct = mtcore.find_account(cfg, b.get("account", ""))
                if not acct:
                    return self._send(400, {"error": "unknown account"})
                action = (b.get("action") or "").lower()
                if action == "set":
                    feature = (b.get("feature") or "").lower()
                    value = (b.get("value") or "").lower()
                    if feature not in mtcore.FEATURES or value not in ("on", "off"):
                        return self._send(400, {"error": "bad feature or value"})
                    mtcore.send_command(cfg, acct["account"], "set", feature, value)
                elif action == "navroute":
                    name = (b.get("name") or "").strip()
                    if not name:
                        return self._send(400, {"error": "no route name"})
                    mtcore.send_command(cfg, acct["account"], "navroute", name=name)
                elif action == "metaload":
                    name = (b.get("name") or "").strip()
                    if not name:
                        return self._send(400, {"error": "no meta name"})
                    mtcore.send_command(cfg, acct["account"], "metaload", name=name)
                elif action == "navspot":
                    name = (b.get("name") or "").strip()
                    if not name:
                        return self._send(400, {"error": "no spot name"})
                    mtcore.send_command(cfg, acct["account"], "navspot", name=name)
                elif action == "banktransfer":
                    kind = (b.get("kind") or "").lower()
                    target = (b.get("target") or "").strip()
                    names = {"l": "luminance", "e": "enlightened coins", "we": "weakly enlightened coins",
                             "p": "pyreals", "k": "legendary keys", "mk": "mythical keys"}
                    if kind not in names or not target:
                        return self._send(400, {"error": "bad transfer"})
                    mtcore.send_command(cfg, acct["account"], "banktransfer", value=kind, name=target)
                    return self._send(200, {"ok": True, "message": "Checking the bank, then sending all but 1 %s to %s." % (
                        names[kind], target)})
                elif action == "organize":
                    what = (b.get("value") or "").lower()
                    if what not in ("run", "on", "off", "mergeon", "mergeoff", "rules", "subs"):
                        return self._send(400, {"error": "bad organize command"})
                    rules = (b.get("rules") or "").replace("\r", " ").replace("\n", " ")
                    mtcore.send_command(cfg, acct["account"], "organize", value=what, name=rules if what in ("rules", "subs") else "")
                    return self._send(200, {"ok": True, "message": {"run": "Organizing now (in quiet moments).", "on": "Organize automatically: on.",
                                                                   "off": "Organize automatically: off.", "rules": "List sent.", "subs": "Sub-groups sent."}[what]})
                elif action == "resetsession":
                    mtcore.send_command(cfg, acct["account"], "resetsession")
                    return self._send(200, {"ok": True, "message": "Resetting the session."})
                elif action == "rebuff":
                    cancel = (b.get("value") or "").lower() == "cancel"
                    mtcore.send_command(cfg, acct["account"], "rebuff", value="cancel" if cancel else "start")
                    return self._send(200, {"ok": True, "message": "Cancelling the rebuff." if cancel else "Rebuffing now."})
                elif action == "openpack":
                    # the game's inventory window: MelkTank clicks the toolbar's backpack button, then "uses" the side pack
                    if (b.get("value") or "") == "close":
                        mtcore.send_command(cfg, acct["account"], "openpack", name="close")
                        return self._send(200, {"ok": True, "message": "Closing the inventory window."})
                    if (b.get("value") or "") == "toggle":
                        mtcore.send_command(cfg, acct["account"], "openpack", name="toggle")
                        return self._send(200, {"ok": True, "message": "Clicked the backpack once."})
                    try:
                        pack = int(b.get("id") or 0)
                    except (TypeError, ValueError):
                        pack = 0
                    mtcore.send_command(cfg, acct["account"], "openpack", name=str(pack))
                    return self._send(200, {"ok": True, "message": "Opening it in the game's inventory window."})
                elif action == "showpack":
                    try:
                        pack = int(b.get("id") or 0)
                    except (TypeError, ValueError):
                        pack = 0
                    mtcore.send_command(cfg, acct["account"], "showpack", name=str(pack))
                    return self._send(200, {"ok": True, "message": "Opening the pack..."})
                elif action == "useitem":
                    try:
                        item = int(b.get("id") or 0)
                    except (TypeError, ValueError):
                        item = 0
                    if not item:
                        return self._send(400, {"error": "no item"})
                    mtcore.send_command(cfg, acct["account"], "useitem", name=str(item))
                    return self._send(200, {"ok": True, "message": "MelkTank pauses, uses it once the character is idle, then resumes."})
                elif action == "identify":
                    try:
                        item = int(b.get("id") or 0)
                    except (TypeError, ValueError):
                        item = 0
                    if not item:
                        return self._send(400, {"error": "no item"})
                    mtcore.send_command(cfg, acct["account"], "identify", name=str(item))
                    return self._send(200, {"ok": True, "message": "Identifying..."})
                elif action == "chat":
                    text = (b.get("text") or "").strip()
                    if not text:
                        return self._send(400, {"error": "nothing to send"})
                    mtcore.send_command(cfg, acct["account"], "chat", value="wait" if b.get("wait") else "now", name=text)
                    if b.get("wait") and text.lower() in ("/b d", "/bank d", "/bank deposit"):
                        return self._send(200, {"ok": True, "message": "Pausing 2 s, depositing, then carrying on."})
                    return self._send(200, {"ok": True, "message": "Waiting until the character isn't busy, then sending." if b.get("wait") else "Sent."})
                elif action == "note":
                    text = (b.get("text") or "").strip()[:300]
                    mtcore.send_command(cfg, acct["account"], "note", name=text or "(mark)")
                    return self._send(200, {"ok": True, "message": "Note added to the logs."})
                elif action == "refresh":
                    mtcore.send_command(cfg, acct["account"], "refresh")
                    mtcore.ask_server_check()   # the phone's pull-to-refresh: the server too
                else:
                    return self._send(400, {"error": "unknown action"})
                return self._send(200, {"ok": True, "message": "Sent - MelkTank picks it up within a couple of seconds."})
            if path == "/api/interval":
                secs = mtcore.set_interval(cfg, int(b.get("seconds") or 45))
                return self._send(200, {"ok": True, "interval": secs})
            if path == "/api/kill":
                acct = mtcore.find_account(cfg, b.get("account", ""))
                if not acct:
                    return self._send(400, {"error": "unknown account"})
                name = acct["account"]
                w = _watch.setdefault(name.lower(), {"armed": False, "restarts": [], "note": ""})
                w["armed"] = False   # closed on purpose: not a crash
                relaunch = bool(b.get("relaunch"))
                mtcore.log("phone: %s close %s%s" % ((b.get("mode") or "normal").lower(), name, " and start again" if relaunch else ""))
                mode = (b.get("mode") or "normal").lower()
                if mode in ("force", "kill"):
                    # (killed outright: no waiting on it to close itself)
                    ok, msg = mtcore.kill_client(cfg, name, wait=0.0, why="Process killed from the phone", note="Killed from the phone", hard=True)
                    if ok and relaunch:
                        msg += " " + start_launch(name)[1]
                    return self._send(200 if ok else 409, {"ok": ok, "message": msg})
                # normal: MelkTank logs out and closes the game itself
                if not mtcore.client_pids(name):
                    return self._send(409, {"ok": False, "message": "No running client found for %s." % name})
                now = mode == "close" and mtcore.is_acgodot(acct)
                mtcore.send_command(cfg, name, "closenow" if now else "quit")
                mtcore.event(name, "closed_phone", ("Close asked from the phone" if now else "Log out and close asked from the phone")
                             + (" - starting again once it's closed" if relaunch else ""))
                if relaunch:
                    threading.Thread(target=relaunch_after_exit, args=(name,), daemon=True).start()
                return self._send(200, {"ok": True, "message": "%s %s%s." % (
                    "Closing" if now else "Logging out and closing", name, " - it starts again once it's closed" if relaunch else "")})
            if path == "/api/reset":
                for acc in cfg["accounts"]:   # closed on purpose: not crashes
                    _watch.setdefault(acc["account"].lower(), {"armed": False, "restarts": [], "note": ""})["armed"] = False
                ok, msg = mtcore.reset_game(cfg)
                if b.get("relaunch"):
                    names = [acc["account"] for acc in cfg["accounts"] if acc.get("enabled", True)]

                    def again():
                        time.sleep(5)
                        for n in names:   # start_launch queues them, launch_delay apart
                            start_launch(n)
                            time.sleep(1)
                    threading.Thread(target=again, daemon=True).start()
                    msg += " Starting %s again." % ", ".join(names) if names else " No accounts are ticked to start."
                return self._send(200 if ok else 409, {"ok": ok, "message": msg})
            if path == "/api/focus":
                acct = mtcore.find_account(cfg, b.get("account", ""))
                if not acct:
                    return self._send(400, {"error": "unknown account"})
                mtcore.wake_screen()
                ok, msg = mtcore.focus_client(acct["account"])
                if not ok:
                    mtcore.log("focus %s: %s" % (acct["account"], msg))
                return self._send(200 if ok else 409, {"ok": ok, "message": msg})
            if path == "/api/live":
                mtcore.set_live(cfg, bool(b.get("on")), bool(b.get("session")), chat=bool(b.get("chat")))
                return self._send(200, {"ok": True})
            if path == "/api/unfocus":
                ok, msg = mtcore.unfocus_games()
                if not ok:
                    mtcore.log("unfocus: " + msg)
                return self._send(200 if ok else 409, {"ok": ok, "message": msg})
            if path == "/api/movewindow":
                acct = mtcore.find_account(cfg, b.get("account", ""))
                if not acct:
                    return self._send(400, {"error": "unknown account"})
                mtcore.wake_screen()
                ok, msg = mtcore.move_client_window(acct["account"], int(b.get("x") or 0), int(b.get("y") or 0))
                if not ok:
                    mtcore.log("move window %s: %s" % (acct["account"], msg))
                return self._send(200 if ok else 409, {"ok": ok, "message": msg})
            if path == "/api/decal":
                act = (b.get("action") or "start").lower()
                if act == "show":
                    ok, msg = mtcore.show_decal(cfg)
                else:
                    ok, msg = mtcore.set_decal(act != "stop")
                _decal["running"] = bool(mtcore.decal_agent_pids())
                return self._send(200 if ok else 409, {"ok": ok, "message": msg, "running": _decal["running"]})
            if path == "/api/settings":
                acct = mtcore.find_account(cfg, b.get("account", ""))
                if not acct:
                    return self._send(400, {"error": "unknown account"})
                ch = b.get("changes") or {}
                if not isinstance(ch, dict) or not ch:
                    return self._send(400, {"error": "no changes"})
                bad = [k for k in ch if not re.fullmatch(r"[A-Za-z0-9_]+", str(k))]
                if bad:
                    return self._send(400, {"error": "bad setting name " + bad[0]})
                payload = "\x03".join("%s\x02%s" % (k, str(v).replace("\x02", " ").replace("\x03", " ")) for k, v in ch.items())
                mtcore.send_command(cfg, acct["account"], "setmany", name=payload)
                return self._send(200, {"ok": True, "message": "Sent %d change%s - MelkTank applies them within a couple of seconds." % (len(ch), "" if len(ch) == 1 else "s")})
            if path == "/api/snapshot":
                acct = mtcore.find_account(cfg, b.get("account", ""))
                if not acct:
                    return self._send(400, {"error": "unknown account"})
                act = (b.get("action") or "").lower()
                nm = (b.get("name") or "").strip()
                if act not in ("save", "restore", "delete") or (act != "save" and not nm):
                    return self._send(400, {"error": "bad snapshot request"})
                mtcore.send_command(cfg, acct["account"], "snap", value=act, name=nm)
                return self._send(200, {"ok": True, "message": {"save": "Saving the snapshot...", "restore": "Restoring " + nm + " (the current settings are kept as before-restore)...", "delete": "Deleting " + nm + "..."}[act]})
            if path == "/api/rollback":
                ok, msg = mtcore.rollback_core(cfg)
                return self._send(200 if ok else 409, {"ok": ok, "message": msg, "builds": mtcore.core_builds(cfg)})
            if path == "/api/launch":
                mtcore.log("phone: start %s" % b.get("account", ""))
                ok, msg = start_launch(b.get("account", ""))
                return self._send(200 if ok else 409, {"ok": ok, "message": msg})
        except Exception as ex:
            mtcore.log("service error on %s: %s" % (path, ex))
            return self._send(500, {"error": str(ex)})
        self._send(404, {"error": "not found"})



def _unpack(lines):
    """unpack.req's lines (see the watcher): join pieces into a zip, unpack a zip into a new folder under ~/Games.
    Only plain names - nothing outside ~/Games/Packages is read, nothing outside a new ~/Games/<Folder> written."""
    import shutil, zipfile
    games = os.path.join(os.path.expanduser("~"), "Games")
    pk = os.path.join(games, "Packages")
    def plain(n):
        if not n or n != os.path.basename(n) or n in (".", "..") or "\\" in n:
            raise ValueError("not a plain name: %r" % n)
        return n
    out = []
    for parts in lines:
        cmd = parts[0].lower()
        if cmd == "join" and len(parts) >= 3:
            target = os.path.join(pk, plain(parts[1]))
            pieces = [os.path.join(pk, plain(p)) for p in parts[2:]]
            missing = [os.path.basename(p) for p in pieces if not os.path.exists(p)]
            if missing:
                out.append("join %s: missing %s" % (parts[1], ", ".join(missing)))
                continue
            tmp = target + ".joining"
            with open(tmp, "wb") as w:
                for p in pieces:
                    with open(p, "rb") as r:
                        shutil.copyfileobj(r, w, 1 << 20)
            if not zipfile.is_zipfile(tmp):
                os.remove(tmp)
                out.append("join %s: the pieces don't make a zip - kept the pieces" % parts[1])
                continue
            os.replace(tmp, target)
            for p in pieces:
                os.remove(p)
            out.append("joined %d pieces into %s (%d MB)" % (len(pieces), parts[1], os.path.getsize(target) >> 20))
        elif cmd == "extract" and len(parts) == 3:
            src = os.path.join(pk, plain(parts[1]))
            dest = os.path.join(games, plain(parts[2]))
            if os.path.exists(dest) and os.listdir(dest):
                out.append("extract %s: %s is already there - left alone" % (parts[1], parts[2]))
                continue
            root = os.path.realpath(dest)
            n = 0
            with zipfile.ZipFile(src) as z:
                for m in z.infolist():
                    to = os.path.realpath(os.path.join(dest, m.filename))
                    if not (to == root or to.startswith(root + os.sep)):
                        raise ValueError("zip entry outside the folder: %s" % m.filename)
                z.extractall(dest)
                n = len(z.infolist())
            out.append("extracted %s into ~/Games/%s (%d entries)" % (parts[1], parts[2], n))
        else:
            out.append("didn't understand: %s" % " ".join(parts))
    return out

def reload_watch():
    """Restarts this service by itself when service.py, mtcore.py, navmeta.py, lootmodel.py or the two .json lists are updated (so an update from Claude applies
    without anyone at the PC). The port is reused straight away."""
    here = os.path.dirname(os.path.abspath(__file__))
    files = [os.path.join(here, n) for n in ("service.py", "mtcore.py", "navmeta.py", "lootmodel.py", "metatypes.json", "loot_spec.json")]

    def stamp():
        return tuple(os.path.getmtime(f) if os.path.exists(f) else 0 for f in files)
    first = stamp()
    shot_req = os.path.join(here, "shot.req")
    while True:
        time.sleep(10)
        # a screenshot asked for by dropping shot.req next to this file (Claude can't call the web API, only copy files):
        # saved as ~/.cache/melktank/remote_shot.jpg
        if os.path.exists(shot_req):
            try:
                os.remove(shot_req)
                with open(os.path.join(mtcore.LOG_DIR, "remote_shot.jpg"), "wb") as f:
                    f.write(mtcore.screenshot())
                mtcore.log("screenshot saved for a file request")
            except Exception as ex:
                mtcore.log("screenshot request failed: %s" % ex)
        # a note for the phone (notify.req: one line of text) - e.g. Claude: "there's an approval waiting on the PC screen";
        # it goes out with the status as pcNote and the phone shows it as a notification (opening the PC screen page)
        note_req = os.path.join(here, "notify.req")
        if os.path.exists(note_req):
            try:
                with open(note_req, encoding="utf-8") as f:
                    text = f.read().strip()[:300]
                os.remove(note_req)
                if text:
                    global _pc_note
                    _pc_note = {"text": text, "at": time.strftime("%Y-%m-%dT%H:%M:%S")}
                    mtcore.log("note for the phone: " + text)
            except Exception as ex:
                mtcore.log("note request failed: %s" % ex)
        # a package unpacked the same way (unpack.req - files bigger than Claude can copy in one go come in pieces):
        #   join <name.zip> <part> <part> ...   the pieces (in ~/Games/Packages) put back together as name.zip there
        #   extract <name.zip> <Folder>         that zip unpacked into ~/Games/<Folder> (a new folder, not one that's there)
        # result in unpack.out next to this file
        unpack_req = os.path.join(here, "unpack.req")
        if os.path.exists(unpack_req):
            out = []
            try:
                with open(unpack_req, encoding="utf-8") as f:
                    lines = [ln.split() for ln in f.read().splitlines() if ln.strip()]
                os.remove(unpack_req)
                out = _unpack(lines)
            except Exception as ex:
                out.append("failed: %s" % ex)
            for ln in out:
                mtcore.log("unpack: " + ln)
            try:
                with open(os.path.join(here, "unpack.out"), "w", encoding="utf-8") as f:
                    f.write("\n".join(out) + "\n")
            except Exception:
                pass
        # a click asked for the same way: click.req = "<account> <x> <y>" in screenshot pixels
        click_req = os.path.join(here, "click.req")
        if os.path.exists(click_req):
            try:
                with open(click_req) as f:
                    parts = f.read().split()
                os.remove(click_req)
                ok, msg = mtcore.click_game_screen(parts[0], float(parts[1]), float(parts[2]))
                mtcore.log("click request: " + msg)
            except Exception as ex:
                mtcore.log("click request failed: %s" % ex)
        try:
            now = stamp()
            if now != first:
                time.sleep(3)   # let the copy finish
                import py_compile, tempfile
                for f in files:   # a broken file: keep running the old code (compiled to /tmp - __pycache__ may be root's)
                    if f.endswith(".json"):
                        with open(f, encoding="utf-8") as jf: json.load(jf)   # a broken list: keep the old one
                        continue
                    if not os.path.exists(f): continue
                    py_compile.compile(f, cfile=os.path.join(tempfile.gettempdir(), "mt-check-%s.pyc" % os.path.basename(f)),
                                       doraise=True)
                mtcore.log("service files changed - restarting the phone service")
                if os.name == "nt":
                    os._exit(3)   # (Windows: run_service.pyw starts it again with the new files)
                os.execv(sys.executable, [sys.executable] + sys.argv)
        except Exception as ex:
            mtcore.log("service reload skipped: %s" % ex)
            first = stamp()


def prune_old_copies(keep=10):
    """Keeps the newest `keep` of each kind of old copy next to this file (MelkTankRemote.old-*.apk, service.old-*.py,
    mtcore.old-*.py, launcher.old-*.py, navmeta.old-*.py); older ones are deleted. Only those name patterns."""
    import glob
    here = os.path.dirname(os.path.abspath(__file__))
    for pat in ("MelkTankRemote.old-*.apk", "service.old-*.py", "mtcore.old-*.py", "launcher.old-*.py", "navmeta.old-*.py"):
        try:
            files = sorted(glob.glob(os.path.join(here, pat)), key=os.path.getmtime, reverse=True)
            for f in files[keep:]:
                os.remove(f)
            if len(files) > keep:
                mtcore.log("old copies: removed %d of %s, kept the newest %d" % (len(files) - keep, pat, keep))
        except Exception as ex:
            mtcore.log("prune %s: %s" % (pat, ex))


def main():
    prune_old_copies()
    cfg = mtcore.load_config()
    bind = cfg["service"].get("bind") or "0.0.0.0"
    port = int(cfg["service"].get("port") or 8765)
    _seed_closed()
    threading.Thread(target=server_watch, daemon=True).start()
    threading.Thread(target=crash_watch, daemon=True).start()
    threading.Thread(target=reload_watch, daemon=True).start()
    threading.Thread(target=memory_watch, daemon=True).start()
    threading.Thread(target=decal_watch, daemon=True).start()
    threading.Thread(target=test_watch, daemon=True).start()
    threading.Thread(target=build_watch, daemon=True).start()
    threading.Thread(target=backup_watch, daemon=True).start()
    mtcore.relaunch_hook = start_launch   # a stuck login's retry goes through the same launch queue
    httpd = ThreadingHTTPServer((bind, port), Handler)
    mtcore.log("phone service listening on %s:%d (version %s)" % (bind, port, SERVICE_VERSION))
    c0 = mtcore.load_config()
    mtcore.log("restart options: crashed clients %s, frozen / disconnected / stuck clients %s (after %s min)" % (
        "on" if c0.get("auto_restart") else "OFF", "on" if c0.get("restart_frozen") else "OFF", c0.get("frozen_minutes", 3)))
    print("MelkTank phone service on %s:%d" % (bind, port), flush=True)
    httpd.serve_forever()


if __name__ == "__main__":
    main()
