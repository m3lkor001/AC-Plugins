@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" -Mode retail
pause
