MelkTank Remote for Windows (Asheron's Call + Decal)
====================================================

Control and watch your Asheron's Call characters from an Android phone. The pieces:
  - MelkTank Launcher    starts your clients with Decal and logs the right character in
  - Phone service        a small background program the phone app talks to
  - MelkTankRemote.apk   the Android app (2.20)
  - Loot Editor          edits MelkTank loot profiles outside the game

(Playing in ACGodot instead? Use MelkTankRemote_Windows_ACGodot.)


NEEDS
-----
  - Windows 10 or 11, with Asheron's Call and Decal installed. ThwargLauncher isn't needed any more: the launcher
    loads Decal into the game itself (Settings > Game setup > Load Decal with - ThwargLauncher's injector.dll still
    works if you'd rather).
  - The MelkTank plugin added in Decal (see README.md in the MelkTank zip)
  - Python 3.10 or newer: https://www.python.org/downloads/windows/
    When you install it, tick "Add python.exe to PATH"
  - Tailscale (free) on the PC and on the phone, signed in to the same account:
    https://tailscale.com/download   (this is how the phone reaches the PC from anywhere)


INSTALL ON THE PC
-----------------
1. Extract this zip to a folder that will stay put, for example C:\Games\MelkTankRemote_Windows
   (right-click the zip > Extract All). Don't run it from inside the zip.
2. Double-click setup.bat. It:
     - installs what the programs need (into a .venv folder in that folder)
     - asks where the MelkTank plugin is (default: C:\Games\Decal Plugins\MelksTank)
     - copies mtlaunch.exe and MelkTankLogin.dll into the MelkTankRemote folder next to "Decal Plugins"
     - adds MelkTank's login filter to Decal (it picks your character at the character screen) - Windows asks
       for an admin's OK once for that
     - adds Start menu shortcuts (MelkTank folder) and starts the phone service now and whenever you sign in
   If Windows asks whether Python may use the network, click Allow.
3. Start menu > MelkTank > MelkTank Launcher:
     - Settings > Game setup: check the acclient.exe path and the plugin folder
     - Servers: your server (InfiniteLeaftide is already there)
     - Add your accounts (with the character to log in), then Launch

INSTALL THE PHONE APP
---------------------
1. Copy MelkTankRemote.apk to the phone and open it. Allow "install unknown apps" when Android asks.
2. In the app, open Settings:
     PC address   the PC's Tailscale IP (100.x.y.z - shown in the Tailscale app on the PC)
     Port         8765
     App key      the launcher's Settings > Phone service > Phone app key
   Tap Save and test.


GOOD TO KNOW
------------
  - PC screen (in the app): pinch to zoom, tap to click there - left, double or right click, drag (tap where to pick
    up, then where to drop), or click and type
  - The phone's Decal card menu: Show Decal on the PC (opens Decal's plugin list - then use PC screen to see it)
    and Decal plugins (turn plugins on / off; they apply at the next game start)
  - Settings and logs: %APPDATA%\MelkTank (config.json holds your passwords - don't share it)
  - Changed the port, or the service isn't answering: double-click restart_service.bat
  - The plugin and the service talk through C:\Games\MelkTankRemote (the folder next to "Decal Plugins")
  - Updating: extract the new zip over this folder, then run setup.bat again
  - The local ACE server controls are for the Linux setup only


TROUBLESHOOTING
---------------
  - The app says it can't reach the PC: is Tailscale on (both ends)? Is the PC awake?
    Try restart_service.bat. Firewall: run setup.bat once with "Run as administrator" to allow port 8765.
  - Launch says acclient.exe not found: fix the path in the launcher's Settings > Game setup.
  - The character isn't picked at the character screen: run setup.bat again and say yes when Windows asks
    (that adds the login filter to Decal).
  - The phone shows no characters: MelkTank must be loaded in the game (Decal), and its plugin folder
    must be set right in Settings > Game setup.
  - Logs: %APPDATA%\MelkTank\logs\launcher.log (launcher and service) and service-output.log
