using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;

namespace MelksQuestTracker
{
    // One row from the "Quest List" tab of the tracking spreadsheet.
    public class QuestDefinition
    {
        public string Name = "";
        public string WikiLink = "";
        public string StartTown = "";
        // Name(s) of the NPC(s) who give the quest, taken from the "Quest Giver" column of the
        // Qb List tab. Comma separated if more than one. Empty when not known.
        public string QuestGiver = "";
        public bool Repeatable = false;
        public string RepeatNote = "";
        public int PossibleQb = 0;
        public bool LockpickRequired = false;
        public bool FellowRequired = false;
        public bool AceRequired = false;
        public bool HasOptionalQb = false;
        public double MinLevel = 0;
        public double RecLevel = 0;
        public double TimeMinutes = 0;
        public string Notes = "";
        public string Wiki = "";          // the walkthrough (QuestDatabase.xml <Wiki>, made from the wiki page) - see QuestWiki.cs
        public string WikiPage = "";      // the wiki page it came from
        public bool NeedsReview = false;
        public List<string> QbFlags = new List<string>();
        /// <summary>timerFlag="...": the flag whose /myquests timer is the quest's timer (e.g. the daily one of a quest
        /// that also has week-long flags). "" = the latest of all its flags' timers.</summary>
        public string TimerFlag = "";
        /// <summary>ktMobs="Moarsmen, Reedsharks, Sleeches": the names kill task chat lines use for this quest's kill task
        /// (for tasks where several monsters count, and the line names the monster rather than the task).</summary>
        public List<string> KtMobs = new List<string>();
        /// <summary>collectItems="Moarsman Ichor x10, Water-Stained Cask x5": items the quest has you collect (handed to you
        /// on a kill: "Shallows Moarsman gives you Moarsman Ichor."). Counted in your pack and shown on the Tracking tab.</summary>
        public List<KeyValuePair<string, int>> CollectItems = new List<KeyValuePair<string, int>>();
        /// <summary>turnInText="You have slain many of the terrible beasts | ...": any chat line containing one of these
        /// clears the quest's kill task (for turn-ins that aren't "Giver gives you ...", e.g. a "tells you" line).</summary>
        public List<string> TurnInText = new List<string>();

        private static readonly System.Text.RegularExpressions.Regex CollectRx =
            new System.Text.RegularExpressions.Regex(@"^(?<name>.+?)(?:\s*[x\u00d7*]\s*(?<n>\d+))?$", System.Text.RegularExpressions.RegexOptions.IgnoreCase);

        /// <summary>"Moarsman Ichor x10, Water-Stained Cask" -> (Moarsman Ichor, 10), (Water-Stained Cask, 0 = no number given).</summary>
        public static List<KeyValuePair<string, int>> ParseCollect(string text)
        {
            List<KeyValuePair<string, int>> l = new List<KeyValuePair<string, int>>();
            foreach (string part in (text ?? "").Split(new[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries))
            {
                System.Text.RegularExpressions.Match m = CollectRx.Match(part.Trim());
                if (!m.Success) continue;
                string name = m.Groups["name"].Value.Trim();
                int n = 0;
                if (m.Groups["n"].Success) int.TryParse(m.Groups["n"].Value, out n);
                if (name.Length > 0) l.Add(new KeyValuePair<string, int>(name, n));
            }
            return l;
        }
        /// <summary>Runtime only: a kill task from /myquests that isn't in QuestDatabase.xml yet (shown on the Main list).</summary>
        public bool Unregistered = false;

        /// <summary>
        /// How long until a repeatable quest can be done again, in hours, read from repeatNote ("20hr",
        /// "4hr each essnce", "30min", "1 day") or a cooldownHours="20" attribute. 0 = not known.
        /// </summary>
        public double CooldownHours = 0;

        // Runtime-only, recomputed every time progress changes. Not persisted here -
        // the source of truth for "is this flag done" lives in ProgressStore.
        public int CompletedCount = 0;
        public int InProgressCount = 0;

        public int RemainingCount
        {
            get { return Math.Max(0, PossibleQb - CompletedCount); }
        }

        public double PercentComplete
        {
            get { return PossibleQb > 0 ? (CompletedCount * 100.0 / PossibleQb) : 0.0; }
        }

        public bool IsComplete
        {
            get { return PossibleQb > 0 && CompletedCount >= PossibleQb; }
        }
    }

    // Static, shared across all characters - this is the "easy to update" reference data,
    // loaded fresh from QuestDatabase.xml (an external, hand-editable file, NOT compiled
    // into the DLL) every time it's (re)loaded.
    public static class QuestDatabase
    {
        public static List<QuestDefinition> Quests = new List<QuestDefinition>();

        // flag name (case-insensitive) -> the quest(s) it belongs to. Normally one quest per flag,
        // but the dictionary supports more just in case the data ever needs it.
        public static Dictionary<string, List<QuestDefinition>> FlagToQuests =
            new Dictionary<string, List<QuestDefinition>>(StringComparer.OrdinalIgnoreCase);

        // The full universe of known QB flag names, independent of whether they've been mapped
        // to a specific quest yet. This is what chat-capture uses to decide "is this line really
        // a QB flag" - built from every <Flag> element across the whole file, so even flags sitting
        // in a [REVIEW] bucket still count as "known" and get captured/persisted correctly.
        public static HashSet<string> AllKnownFlags =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        public static bool Loaded = false;
        public static int LoadCount;   // goes up on every load (link lookups rebuild)

        public static void Load(string path)
        {
            Quests.Clear();
            FlagToQuests.Clear();
            AllKnownFlags.Clear();
            Loaded = false;

            if (!File.Exists(path))
            {
                Util.WriteToChat($"Quest database not found at: {path}");
                Util.WriteToChat("Copy QuestDatabase.xml next to the plugin DLL, or update the path on the Config tab.");
                return;
            }

            try
            {
                XmlDocument doc = new XmlDocument();
                Util.LoadXml(doc, path);
                XmlNodeList questNodes = doc.SelectNodes("/QuestDatabase/Quest");
                foreach (XmlNode qNode in questNodes)
                {
                    QuestDefinition q = new QuestDefinition();
                    q.Name = GetAttr(qNode, "name");
                    q.WikiLink = GetAttr(qNode, "link");
                    q.StartTown = GetAttr(qNode, "startTown");
                    q.QuestGiver = GetAttr(qNode, "questGiver");
                    q.Repeatable = GetBoolAttr(qNode, "repeatable");
                    q.RepeatNote = GetAttr(qNode, "repeatNote");
                    q.TimerFlag = GetAttr(qNode, "timerFlag");
                    foreach (string m in GetAttr(qNode, "ktMobs").Split(new[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries))
                        if (m.Trim().Length > 0) q.KtMobs.Add(m.Trim());
                    q.CollectItems = QuestDefinition.ParseCollect(GetAttr(qNode, "collectItems"));
                    foreach (string m in GetAttr(qNode, "turnInText").Split('|'))
                        if (m.Trim().Length > 0) q.TurnInText.Add(m.Trim());
                    q.PossibleQb = GetIntAttr(qNode, "possibleQb");
                    q.LockpickRequired = GetBoolAttr(qNode, "lockpickRequired");
                    q.FellowRequired = GetBoolAttr(qNode, "fellowRequired");
                    q.AceRequired = GetBoolAttr(qNode, "aceRequired");
                    q.HasOptionalQb = GetBoolAttr(qNode, "hasOptionalQb");
                    q.MinLevel = GetDoubleAttr(qNode, "minLevel");
                    q.RecLevel = GetDoubleAttr(qNode, "recLevel");
                    q.TimeMinutes = GetDoubleAttr(qNode, "timeMinutes");
                    q.Notes = GetAttr(qNode, "notes");
                    q.NeedsReview = GetBoolAttr(qNode, "needsReview");
                    q.CooldownHours = GetDoubleAttr(qNode, "cooldownHours");
                    if (q.CooldownHours <= 0) q.CooldownHours = ParseCooldown(q.RepeatNote);

                    XmlNode wNode = qNode.SelectSingleNode("Wiki");
                    if (wNode != null)
                    {
                        q.Wiki = (wNode.InnerText ?? "").Replace("\r\n", "\n").Replace("\r", "").Trim();
                        if (wNode.Attributes != null && wNode.Attributes["page"] != null) q.WikiPage = wNode.Attributes["page"].Value;
                    }

                    foreach (XmlNode fNode in qNode.SelectNodes("Flag"))
                    {
                        string flag = (fNode.InnerText ?? "").Trim();
                        if (flag.Length == 0) continue;
                        q.QbFlags.Add(flag);
                        AllKnownFlags.Add(flag);
                        if (!FlagToQuests.ContainsKey(flag))
                            FlagToQuests[flag] = new List<QuestDefinition>();
                        FlagToQuests[flag].Add(q);
                    }
                    Quests.Add(q);
                }
                Loaded = true;
                LoadCount++;
                Util.WriteToChat($"Loaded {Quests.Count} quests, {AllKnownFlags.Count} known QB flags.");
            }
            catch (Exception ex)
            {
                Util.WriteToChat($"QuestDatabase Load Error: {ex.Message}");
                Util.LogError(ex);
            }
        }

        // Recompute CompletedCount/InProgressCount on every quest from the current ProgressStore state.
        // Call this after any change to ProgressStore (capture finished, manual edit, settings loaded).
        public static void RecalculateProgress()
        {
            foreach (QuestDefinition q in Quests)
            {
                int completed = 0;
                int inProgress = 0;
                foreach (string flag in q.QbFlags)
                {
                    FlagState state;
                    if (ProgressStore.Flags.TryGetValue(flag, out state))
                    {
                        if (state == FlagState.Completed) completed++;
                        else if (state == FlagState.InProgress) inProgress++;
                    }
                }
                q.CompletedCount = completed;
                q.InProgressCount = inProgress;
            }
            PublishWanted();
        }

        /// <summary>
        /// The QB stamps this character doesn't have yet, for MelkTank's looter ("pick up items that give a QB stamp"): AppDomain
        /// "MelksQB.WantedStamps" = "flag|quest" lines (the flag as in the quest list). Only quests whose flags are stamps you
        /// get by picking something up count - any flag of an unfinished quest is offered, MelkTank matches item names to them.
        /// </summary>
        public static void PublishWanted()
        {
            try
            {
                List<string> l = new List<string>(), have = new List<string>();
                foreach (QuestDefinition q in Quests)
                    foreach (string flag in q.QbFlags)
                    {
                        FlagState st;
                        if (ProgressStore.Flags.TryGetValue(flag, out st) && st == FlagState.Completed) { have.Add(flag + "|" + q.Name); continue; }
                        l.Add(flag + "|" + q.Name);
                    }
                AppDomain.CurrentDomain.SetData("MelksQB.WantedStamps", l.ToArray());
                // (and the ones you have - MelkTank's ID line says "(QB Collected)" for an item that gives one)
                AppDomain.CurrentDomain.SetData("MelksQB.HaveStamps", have.ToArray());
            }
            catch { }
        }

        private static string GetAttr(XmlNode n, string name)
        {
            XmlAttribute a = n.Attributes[name];
            return a != null ? a.Value : "";
        }
        private static bool GetBoolAttr(XmlNode n, string name)
        {
            bool b;
            return bool.TryParse(GetAttr(n, name), out b) && b;
        }
        private static int GetIntAttr(XmlNode n, string name)
        {
            int v;
            int.TryParse(GetAttr(n, name), out v);
            return v;
        }
        // Lenient: "40+" reads as 40 (the spreadsheet has a few of those).
        private static double GetDoubleAttr(XmlNode n, string name)
        {
            System.Text.RegularExpressions.Match m = System.Text.RegularExpressions.Regex.Match(GetAttr(n, name), @"\d+(?:\.\d+)?");
            double v;
            return m.Success && double.TryParse(m.Value, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out v) ? v : 0;
        }

        /// <summary>"20hr" -> 20, "4hr each essnce" -> 4, "30min" -> 0.5, "1 day" -> 24. 0 when there's no time in it.</summary>
        public static double ParseCooldown(string note)
        {
            if (string.IsNullOrEmpty(note)) return 0;
            System.Text.RegularExpressions.Match m = System.Text.RegularExpressions.Regex.Match(note,
                @"(\d+(?:\.\d+)?)\s*(d|days?|h|hrs?|hours?|m|mins?|minutes?)\b", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (!m.Success) return 0;
            double v = double.Parse(m.Groups[1].Value, System.Globalization.CultureInfo.InvariantCulture);
            string u = m.Groups[2].Value.ToLowerInvariant();
            if (u.StartsWith("d")) return v * 24;
            if (u.StartsWith("m")) return v / 60;
            return v;
        }
    }

    /// <summary>
    /// QB flags seen in /qb list that aren't in QuestDatabase.xml yet (same green chat lines as the known
    /// ones). Shared by all characters, kept in MQT_NewFlags.xml, for the Edit Quest tab to pick from.
    /// A flag drops off the list once it's in the database (or you Forget it).
    /// </summary>
    public static class NewFlagStore
    {
        public static Dictionary<string, DateTime> Flags = new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);
        private static string _path;

        public static void Load(string path)
        {
            _path = path;
            Flags.Clear();
            if (!File.Exists(path)) return;
            try
            {
                XmlDocument doc = new XmlDocument();
                Util.LoadXml(doc, path);
                foreach (XmlNode n in doc.SelectNodes("/MQT_NewFlags/Flag"))
                {
                    string name = n.Attributes["name"] != null ? n.Attributes["name"].Value.Trim() : "";
                    DateTime at = DateTime.Now;
                    if (n.Attributes["firstSeen"] != null) DateTime.TryParse(n.Attributes["firstSeen"].Value, out at);
                    if (name.Length > 0) Flags[name] = at;
                }
            }
            catch (Exception ex) { Util.LogError(ex); }
        }

        public static void Save()
        {
            Util.Locked(_path, () => Save_Locked());   // another client may be writing it too
        }

        public static void Save_Locked()
        {
            if (_path == null) return;
            try
            {
                XmlDocument doc = new XmlDocument();
                XmlElement root = doc.CreateElement("MQT_NewFlags");
                doc.AppendChild(root);
                foreach (var kv in Flags)
                {
                    XmlElement e = doc.CreateElement("Flag");
                    e.SetAttribute("name", kv.Key);
                    e.SetAttribute("firstSeen", kv.Value.ToString("o"));
                    root.AppendChild(e);
                }
                Util.SaveXml(doc, _path);
            }
            catch (Exception ex) { Util.LogError(ex); }
        }

        /// <summary>The ones still not in the database, newest first (so ones just moved here are at the top).</summary>
        public static List<string> Pending()
        {
            List<KeyValuePair<string, DateTime>> l = new List<KeyValuePair<string, DateTime>>();
            foreach (var kv in Flags) if (!QuestDatabase.AllKnownFlags.Contains(kv.Key)) l.Add(kv);
            l.Sort((a, b) => a.Value != b.Value ? b.Value.CompareTo(a.Value) : string.Compare(a.Key, b.Key, StringComparison.OrdinalIgnoreCase));
            List<string> r = new List<string>();
            foreach (var kv in l) r.Add(kv.Key);
            return r;
        }
    }

    public class ServerTimer
    {
        public DateTime Completed;     // local time of the last completion
        public long RepeatSeconds;     // how long before it can be done again (0 or less = no repeat)
        public int Solves;
        public int MaxSolves = -1;     // -1 = no limit
        public string Description = "";   // the server's name for it, e.g. "Aluvian Beef Kill Task Main Flag"
        /// <summary>Can be done again: it has a wait time and isn't capped at one solve.</summary>
        public bool Repeats { get { return RepeatSeconds > 0 && (MaxSolves < 0 || MaxSolves > 1); } }
        public DateTime ReadyAt { get { return Completed.AddSeconds(Math.Max(0, RepeatSeconds)); } }
    }

    public enum FlagState
    {
        Completed,   // appeared in the "completed" section of /qb list
        InProgress   // appeared in the "incomplete quest bonus list" section - started, not finished
    }

    // Per-character cache of which QB flags are known to be done/in-progress, persisted to disk so
    // the plugin doesn't need to re-run /qb list every session to know where you stand.
    public static class ProgressStore
    {
        public static Dictionary<string, FlagState> Flags =
            new Dictionary<string, FlagState>(StringComparer.OrdinalIgnoreCase);
        public static DateTime LastCollected = DateTime.MinValue;

        /// <summary>Repeatable quests: when this character last finished each one (quest name -> time), for the "ready again in" timers.</summary>
        public static Dictionary<string, DateTime> QuestDone =
            new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);

        /// <summary>Quests seen counting down (on this character). Once ready they sort just under the running ones
        /// (Main tab, Sort: CD) until the detail panel's Clear is pressed.</summary>
        public static HashSet<string> Watched = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        /// <summary>From the server's /myquests: flag -> when you last completed it and its repeat time (seconds).</summary>
        public static Dictionary<string, ServerTimer> ServerTimers =
            new Dictionary<string, ServerTimer>(StringComparer.OrdinalIgnoreCase);
        public static DateTime ServerTimersRead = DateTime.MinValue;

        /// <summary>
        /// /qb list puts a flag you've earned back in its "incomplete" section once the quest can be done again. Those
        /// are done, not half done: a flag listed as incomplete that /myquests says you've solved counts as completed.
        /// Returns how many were changed.
        /// </summary>
        public static int SolvedAreDone(Dictionary<string, FlagState> flags)
        {
            List<string> up = new List<string>();
            foreach (KeyValuePair<string, FlagState> kv in flags)
            {
                ServerTimer t;
                if (kv.Value == FlagState.InProgress && ServerTimers.TryGetValue(kv.Key, out t) && t != null && t.Solves >= 1) up.Add(kv.Key);
            }
            foreach (string k in up) flags[k] = FlagState.Completed;
            return up.Count;
        }

        public static void Load(string path, string characterKey)
        {
            Flags.Clear();
            QuestDone.Clear();
            Watched.Clear();
            ServerTimers.Clear();
            ServerTimersRead = DateTime.MinValue;
            LastCollected = DateTime.MinValue;
            if (!File.Exists(path)) return;

            try
            {
                XmlDocument doc = new XmlDocument();
                Util.LoadXml(doc, path);
                XmlNode charNode = doc.SelectSingleNode($"/MQT_Progress/Character[@key='{characterKey}']");
                if (charNode == null) return;

                XmlAttribute lc = charNode.Attributes["lastCollected"];
                if (lc != null) DateTime.TryParse(lc.Value, out LastCollected);

                foreach (XmlNode f in charNode.SelectNodes("Completed"))
                {
                    string name = (f.InnerText ?? "").Trim();
                    if (name.Length > 0) Flags[name] = FlagState.Completed;
                }
                foreach (XmlNode f in charNode.SelectNodes("InProgress"))
                {
                    string name = (f.InnerText ?? "").Trim();
                    if (name.Length > 0 && !Flags.ContainsKey(name)) Flags[name] = FlagState.InProgress;
                }
                XmlAttribute str = charNode.Attributes["serverTimersRead"];
                if (str != null) DateTime.TryParse(str.Value, null, System.Globalization.DateTimeStyles.RoundtripKind, out ServerTimersRead);
                foreach (XmlNode t in charNode.SelectNodes("QFlag"))
                {
                    try
                    {
                        ServerTimers[t.Attributes["name"].Value] = new ServerTimer
                        {
                            Completed = DateTime.Parse(t.Attributes["completed"].Value, null, System.Globalization.DateTimeStyles.RoundtripKind),
                            RepeatSeconds = long.Parse(t.Attributes["repeat"].Value),
                            Solves = int.Parse(t.Attributes["solves"].Value),
                            MaxSolves = t.Attributes["max"] != null ? int.Parse(t.Attributes["max"].Value) : -1,
                            Description = t.Attributes["desc"] != null ? t.Attributes["desc"].Value : ""
                        };
                    }
                    catch { }
                }
                foreach (XmlNode t in charNode.SelectNodes("Timer"))
                {
                    XmlAttribute qa = t.Attributes["quest"], aa = t.Attributes["at"];
                    DateTime at;
                    if (qa != null && aa != null && DateTime.TryParse(aa.Value, null, System.Globalization.DateTimeStyles.RoundtripKind, out at))
                        QuestDone[qa.Value] = at;
                }
                foreach (XmlNode w in charNode.SelectNodes("Watched"))
                    if (w.Attributes["quest"] != null) Watched.Add(w.Attributes["quest"].Value);
                SolvedAreDone(Flags);
            }
            catch (Exception ex)
            {
                Util.WriteToChat($"ProgressStore Load Error: {ex.Message}");
                Util.LogError(ex);
            }
        }

        public static void Save(string path, string characterKey)
        {
            Util.Locked(path, () => Save_Locked(path, characterKey));   // another client may be writing it too
        }

        public static void Save_Locked(string path, string characterKey)
        {
            try
            {
                XmlDocument doc = new XmlDocument();
                XmlElement root;
                if (File.Exists(path))
                {
                    Util.LoadXml(doc, path);
                    root = doc.DocumentElement;
                }
                else
                {
                    root = doc.CreateElement("MQT_Progress");
                    doc.AppendChild(root);
                }

                XmlNode existing = root.SelectSingleNode($"Character[@key='{characterKey}']");
                if (existing != null) root.RemoveChild(existing);

                XmlElement charNode = doc.CreateElement("Character");
                charNode.SetAttribute("key", characterKey);
                charNode.SetAttribute("lastCollected", LastCollected.ToString("o"));
                if (ServerTimersRead != DateTime.MinValue) charNode.SetAttribute("serverTimersRead", ServerTimersRead.ToString("o"));

                foreach (var kvp in Flags)
                {
                    XmlElement fe = doc.CreateElement(kvp.Value == FlagState.Completed ? "Completed" : "InProgress");
                    fe.InnerText = kvp.Key;
                    charNode.AppendChild(fe);
                }
                foreach (var t in ServerTimers)
                {
                    XmlElement te = doc.CreateElement("QFlag");
                    te.SetAttribute("name", t.Key);
                    te.SetAttribute("completed", t.Value.Completed.ToString("o"));
                    te.SetAttribute("repeat", t.Value.RepeatSeconds.ToString());
                    te.SetAttribute("solves", t.Value.Solves.ToString());
                    te.SetAttribute("max", t.Value.MaxSolves.ToString());
                    if (!string.IsNullOrEmpty(t.Value.Description)) te.SetAttribute("desc", t.Value.Description);
                    charNode.AppendChild(te);
                }
                foreach (var t in QuestDone)
                {
                    XmlElement te = doc.CreateElement("Timer");
                    te.SetAttribute("quest", t.Key);
                    te.SetAttribute("at", t.Value.ToString("o"));
                    charNode.AppendChild(te);
                }
                foreach (string w in Watched)
                {
                    XmlElement we = doc.CreateElement("Watched");
                    we.SetAttribute("quest", w);
                    charNode.AppendChild(we);
                }
                root.AppendChild(charNode);
                Util.SaveXml(doc, path);
            }
            catch (Exception ex)
            {
                Util.WriteToChat($"ProgressStore Save Error: {ex.Message}");
                Util.LogError(ex);
            }
        }
    }
}
