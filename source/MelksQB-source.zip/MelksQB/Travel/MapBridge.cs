// ACGodot: MelksQB's own map windows (the world map, the dungeon map, ACMaps pictures) aren't brought over - ACGodot's
// built-in map (M) does that. These stand in for them: their calls open ACGodot's map instead, and the data they
// gathered as you went (NPCs and vendors seen, added as points) still is.
using System;
using System.Collections.Generic;
using Decal.Adapter;
using Decal.Adapter.Wrappers;

namespace MelksQuestTracker
{
}

namespace MelksQuestTracker.Travel
{
    internal static class WorldView
    {
        public static bool AutoAddNpcs = true;
        public static bool Visible => false;
        public static void Toggle() { var h = ACGodot.DecalShim.Bridge.Host; var c = Travel.Here(); if (h?.ShowOnMap != null && c.Valid) h.ShowOnMap(c.NS, c.EW, "You"); }
        public static void ShowAt(Coords c) { if (c.Valid) ACGodot.DecalShim.Bridge.Host?.ShowOnMap?.Invoke(c.NS, c.EW, c.ToString()); }
        public static void EnsureBar() { }
        public static void PlaceRequestTick() { }
        public static void Dispose() { }

        // ── NPCs / vendors seen: added as points ──
        public static void ScanNpcs()
        {
            if (!AutoAddNpcs && Travel.HereGroup.Length == 0) return;
            if (!Travel.PlaceKnown) return;
            foreach (WorldObject o in CoreManager.Current.WorldFilter.GetLandscape())
                if (o.ObjectClass == ObjectClass.Npc || o.ObjectClass == ObjectClass.Vendor) Seen(o);
        }

        public static void Seen(WorldObject o)
        {
            try
            {
                if (!Travel.PlaceKnown) return;
                string grp = Travel.HereGroup;
                if (o == null || (!AutoAddNpcs && grp.Length == 0)) return;
                if (o.ObjectClass != ObjectClass.Npc && o.ObjectClass != ObjectClass.Vendor) return;
                if (!StaysPut(o)) return;
                uint cell = Travel.Cell();
                if (TravelData.AreaOfCell(cell) >= 0) return;   // (in a dungeon: its map was MelksQB's own)
                Coords c;
                try { CoordsObject co = o.Coordinates(); c = new Coords(co.NorthSouth, co.EastWest); } catch { return; }
                if (!c.Valid || c.DistanceTo(Travel.Here()) > 2) return;
                string type = o.ObjectClass == ObjectClass.Vendor ? "Vendor" : "NPC";
                string name = TravelData.Plain(o.Name ?? "");
                if (name.Length == 0) return;
                if (grp.Length == 0)
                    foreach (Loc l in TravelData.Locs) if ((l.Type == "NPC" || l.Type == "Vendor") && l.At.DistanceTo(c) < 0.3 && string.Equals(l.Name, name, StringComparison.OrdinalIgnoreCase)) return;
                foreach (TravelData.Point p in TravelData.Points.Values) if (p.In == grp && p.At.DistanceTo(c) < 0.3 && string.Equals(p.Name, name, StringComparison.OrdinalIgnoreCase)) return;
                TravelData.AddPoint(new TravelData.Point { Name = name, Type = type, At = new Coords(Math.Round(c.NS, 2), Math.Round(c.EW, 2)), Auto = true, In = grp });
            }
            catch { }
        }

        private static readonly Dictionary<int, KeyValuePair<double[], DateTime>> _firstSeen = new Dictionary<int, KeyValuePair<double[], DateTime>>();
        private static readonly HashSet<int> _moved = new HashSet<int>();
        private static bool StaysPut(WorldObject o)
        {
            double[] p;
            try { CoordsObject co = o.Coordinates(); p = new[] { co.NorthSouth, co.EastWest }; } catch { return false; }
            if (_moved.Contains(o.Id)) return false;
            if (!_firstSeen.TryGetValue(o.Id, out var f))
            {
                if (_firstSeen.Count > 2000) _firstSeen.Clear();
                _firstSeen[o.Id] = new KeyValuePair<double[], DateTime>(p, DateTime.Now);
                return false;
            }
            double dm = Math.Sqrt((p[0] - f.Key[0]) * (p[0] - f.Key[0]) + (p[1] - f.Key[1]) * (p[1] - f.Key[1])) * 240.0;
            if (dm > 1.5) { _moved.Add(o.Id); return false; }
            return (DateTime.Now - f.Value).TotalSeconds >= 8;
        }
    }

    internal static class DungeonView
    {
        /// <summary>Open the map on going into a dungeon (Config).</summary>
        public static bool AutoOpen = true;
        public static bool Visible => false;
        private static int _lb = -1;

        private static int HereLb() { uint cell = Travel.Cell(); return (cell & 0xFFFF) >= 0x100 ? (int)(cell >> 16) : -1; }

        public static void Show()
        {
            int lb = HereLb();
            if (lb >= 0) ACGodot.DecalShim.Bridge.Host?.ShowDungeonMap?.Invoke(lb);
            else WorldView.Toggle();
        }
        public static void Hide() { }
        /// <summary>The ACMaps picture for a dungeon (its version: only a picture made for that version's name), or null.</summary>
        public static string MapIdFor(int lb, string inst)
        {
            if (string.IsNullOrEmpty(inst) || !inst.StartsWith("v")) { string hex = lb.ToString("X4"); return MapView.Has(hex) ? hex : null; }
            string n = TravelData.LocName(lb, inst);
            if (n == null) TravelData.VarNames.TryGetValue(lb.ToString("X4") + inst, out n);
            return n != null && MapView.Has(n) ? n : null;
        }
        public static void SeePortals() { }
        public static void Dispose() { }

        /// <summary>Into a dungeon: its layout on ACGodot's map (when Config says so).</summary>
        public static void Tick()
        {
            int lb = HereLb();
            if (lb >= 0 && TravelData.AreaOfCell(Travel.Cell()) < 0) lb = -1;   // a house / building
            if (lb == _lb) { AcMapTick(); return; }
            _lb = lb;
            if (lb >= 0 && AutoOpen) { ACGodot.DecalShim.Bridge.Host?.ShowDungeonMap?.Invoke(lb); _wantAcMap = lb; }
        }

        // the ACMaps picture opens too, once the dungeon's version is known (a version reusing the rooms gets none,
        // unless there's a picture under its own name)
        private static int _wantAcMap = -1;
        private static void AcMapTick()
        {
            if (_wantAcMap < 0 || !Travel.PlaceKnown) return;
            int lb = _wantAcMap; _wantAcMap = -1;
            if (lb != _lb) return;
            string id = MapIdFor(lb, Travel.DungeonInst(lb));
            if (id != null && MapView.Showing != id) MapView.Show(id, false);
        }
    }
}
