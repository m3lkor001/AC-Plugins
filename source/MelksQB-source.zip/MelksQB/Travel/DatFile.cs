using System;
using System.Collections.Generic;
using System.IO;

namespace MelksQuestTracker.Travel
{
    /// <summary>Reads files out of one of the game's .dat archives (read only, shared with the running game).</summary>
    internal class DatFile : IDisposable
    {
        private readonly FileStream _fs;
        private readonly uint _blockSize, _root;
        private readonly Dictionary<uint, uint[]> _nodeCache = new Dictionary<uint, uint[]>();

        public DatFile(string path)
        {
            _fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete, 65536);
            byte[] h = new byte[64];
            _fs.Position = 0x140;
            _fs.Read(h, 0, h.Length);
            _blockSize = BitConverter.ToUInt32(h, 4);
            _root = BitConverter.ToUInt32(h, 32);
        }

        public void Dispose() { try { _fs.Dispose(); } catch { } }

        private byte[] ReadChain(uint offset, int size)
        {
            // the game writes to this file while it runs: anything that doesn't look right is "not there", never a big read
            if (size <= 0 || size > 8 * 1024 * 1024 || _blockSize < 64 || _blockSize > 65536) return null;
            byte[] outb = new byte[size];
            byte[] blk = new byte[_blockSize];
            int got = 0;
            uint addr = offset;
            int guard = size / (int)(_blockSize - 4) + 8;
            while (got < size && addr != 0)
            {
                if (--guard < 0 || addr >= _fs.Length) return null;
                _fs.Position = addr;
                int want = (int)Math.Min(_blockSize, 4 + (size - got));
                int r = _fs.Read(blk, 0, want);
                if (r < 4) break;
                uint next = BitConverter.ToUInt32(blk, 0) & 0x7FFFFFFF;
                int n = Math.Min(r - 4, size - got);
                Buffer.BlockCopy(blk, 4, outb, got, n);
                got += n;
                addr = next;
            }
            return outb;
        }

        // a directory node: 62 branches, the entry count, up to 61 entries of 6 uints
        private uint[] Node(uint offset)
        {
            uint[] n;
            if (_nodeCache.TryGetValue(offset, out n)) return n;
            byte[] b = ReadChain(offset, 62 * 4 + 4 + 61 * 24);
            if (b == null) return null;
            n = new uint[b.Length / 4];
            Buffer.BlockCopy(b, 0, n, 0, n.Length * 4);
            if (_nodeCache.Count > 4000) _nodeCache.Clear();
            _nodeCache[offset] = n;
            return n;
        }

        /// <summary>The file with this id, or null.</summary>
        public byte[] Get(uint id)
        {
            uint off = _root;
            for (int depth = 0; depth < 64 && off != 0; depth++)
            {
                uint[] n = Node(off);
                if (n == null) return null;
                uint count = n[62];
                if (count > 61) return null;
                int lo = 0, hi = (int)count - 1;
                while (lo <= hi)
                {
                    int mid = (lo + hi) / 2;
                    uint oid = n[63 + mid * 6 + 1];
                    if (oid == id) return ReadChain(n[63 + mid * 6 + 2], (int)n[63 + mid * 6 + 3]);
                    if (oid < id) lo = mid + 1; else hi = mid - 1;
                }
                if (n[0] == 0) return null;   // a leaf
                off = n[lo];
            }
            return null;
        }
    }
}
