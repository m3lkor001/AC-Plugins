using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Xml;

namespace MelksQuestTracker.Travel
{
    /// <summary>A place from the locations list, or a portal (it has an exit).</summary>
    internal class Loc
    {
        public int Id;
        public string Name = "";
        public string Type = "";
        public string Notes = "";
        public Coords At = Coords.None;
        public Coords Exit = Coords.None;
        public int Area = -1;        // -1 outdoors, else the indoor landblock it's in (a hub / dungeon)
        public int ExitArea = -1;
        public int MinLevel, MaxLevel;
        public uint Cell;            // learned portals: the game cell it stands in (for walking to it indoors)
        public bool Learned;         // seen in the game (MQT_Travel.xml), not only the list
        public bool HasExit { get { return Exit.Valid; } }
        public string Instance = "";   // a copy of an area at the same coordinates (Tou-Tou's tier11, tier12 ...) - what /loc says
        public bool Mine;   // one of your GoArrow custom points (shown on the map as your point, not twice)
        public string In = "";        // stands in a copy of an area ("tier11+": Tou-Tou's tier 11-15 copies), seen there
        public string BotName = "", BotWord = "";
        public List<string> Exits;   // learned portals that go to different places: every place seen ("ns,ew@area")   // a portal bot's place: tell BotName BotWord, then go through what it opens
        public string Key { get { return Name + "@" + At.Raw() + (In.Length > 0 ? "#" + In : ""); } }
    }

    /// <summary>Something you can use from anywhere: a recall spell, a portal gem, a typed command (/ls), a portal tie.</summary>
    internal class StartOpt
    {
        public string Kind = "";     // spell, gem, cmd
        public string Name = "";     // the spell / gem name, or the command ("/ls")
        public Coords Exit = Coords.None;
        public int ExitArea = -1;
        public long Ticks;           // when it was learned
        public bool PerChar;         // this character's (a tie, the lifestone, your house) rather than everyone's
        public int SpellId;          // set when listed as usable
        public int ItemId;
        public bool OpensPortal;     // a gem that opens a portal you then go through (not one that sends you)
        public string Instance = "";  // lands in a copy of an area at the same coordinates (tier11 ...) - what /loc says
    }

    /// <summary>
    /// The places and portals (Travel\locations.xml - GoArrow's list, with fixes), plus what MelksQB learns in the game
    /// (MQT_Travel.xml, shared by every client: portals seen or used, where recalls / gems / commands land, each character's
    /// ties). Saved when something changes, merged with what other clients saved (the newer entry wins).
    /// </summary>
    internal static class TravelData
    {
        public static readonly List<Loc> Locs = new List<Loc>();          // the list + learned portals, merged
        public static readonly Dictionary<string, Loc> LearnedPortals = new Dictionary<string, Loc>(StringComparer.OrdinalIgnoreCase);
        public static readonly Dictionary<string, StartOpt> SharedStarts = new Dictionary<string, StartOpt>(StringComparer.OrdinalIgnoreCase);
        public static readonly Dictionary<string, StartOpt> CharStarts = new Dictionary<string, StartOpt>(StringComparer.OrdinalIgnoreCase);
        public static readonly HashSet<string> Avoid = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        public static readonly HashSet<int> LearnedIndoor = new HashSet<int>();

        /// <summary>A point on the world map you added (or GoArrow's custom points, or an NPC / vendor seen in the game).</summary>
        internal class Point
        {
            public string Name = "", Type = "Custom", Notes = "";
            public Coords At = Coords.None;
            public bool Auto;   // added by itself (an NPC seen), not by you
            public string In = "";   // on the map of a copy of an area ("tier11+"), or of a dungeon ("d:0123"), not the world
            public double Z = double.NaN;   // in a dungeon: the height (which level it's on)
            public string Key { get { return Type + "|" + Name + "|" + At.NS.ToString("0.00", CultureInfo.InvariantCulture) + "," + At.EW.ToString("0.00", CultureInfo.InvariantCulture) + (In.Length > 0 ? "#" + In : ""); } }
        }
        public static readonly Dictionary<string, Point> Points = new Dictionary<string, Point>(StringComparer.OrdinalIgnoreCase);
        private static readonly HashSet<string> _removedPoints = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        public static readonly HashSet<string> Random = new HashSet<string>(StringComparer.OrdinalIgnoreCase);   // portals that go somewhere different each time
        private static readonly HashSet<string> _removedRandom = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        public static readonly HashSet<string> Flags = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        public static readonly List<Point> GoArrowCustom = new List<Point>();   // the list's customized="True" entries (yours from GoArrow)
        public static int PointsVersion;

        /// <summary>Names as the map's font can show them: curly quotes / apostrophes (Val’Kaesyn) as plain ones.</summary>
        public static string Plain(string s)
        {
            if (string.IsNullOrEmpty(s)) return s ?? "";
            return s.Replace('\u2019', '\'').Replace('\u2018', '\'').Replace('\u02BC', '\'').Replace('\u201C', '"').Replace('\u201D', '"');
        }

        public static void AddPoint(Point p)
        {
            if (p == null || !p.At.Valid || p.Name.Length == 0) return;
            p.Name = Plain(p.Name);
            Points[p.Key] = p; _removedPoints.Remove(p.Key);
            PointsVersion++; Changed();
        }

        public static void RemovePoint(Point p)
        {
            if (p == null || !Points.Remove(p.Key)) return;
            _removedPoints.Add(p.Key);
            PointsVersion++; Changed();
        }

        public static void SetRandom(string key, bool on)
        {
            bool ch = on ? Random.Add(key) : Random.Remove(key);
            if (!ch) return;
            if (on) _removedRandom.Remove(key); else _removedRandom.Add(key);
            Changed(); Version++;
        }

        // ── copies of an area at the same coordinates (Tou-Tou's tier 11 / 12 / 13 areas are at Tou-Tou's own coordinates,
        //    but walled off from it): known by /loc ("tier11"), else by the name ("... Gem v11", "Tou Tou Tier 13") ──
        private static readonly System.Text.RegularExpressions.Regex InstRx =
            new System.Text.RegularExpressions.Regex(@"\b(?:tier|t|v)\s*-?\s*(1\d)\b", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        public static string InstanceFromName(string name)
        {
            System.Text.RegularExpressions.Match m = InstRx.Match(name ?? "");
            return m.Success ? "tier" + m.Groups[1].Value : "";
        }
        // Instance "-" = /location said it's the ordinary area (no v:), whatever the name says
        public static string Inst(Loc l) { return l == null ? "" : Real(l.Instance.Length > 0 ? l.Instance : l.HasExit ? InstanceFromName(l.Name) : ""); }
        public static string Inst(StartOpt o) { return o == null ? "" : Real(o.Instance.Length > 0 ? o.Instance : InstanceFromName(o.Name)); }
        /// <summary>Only tier 11+ copies are their own place (v:3 in a dungeon etc. is just its tier): anything else is "".</summary>
        public static string Real(string inst)
        {
            int n;
            if (string.IsNullOrEmpty(inst) || inst == "-") return "";
            if (inst.StartsWith("tier", StringComparison.OrdinalIgnoreCase) && int.TryParse(inst.Substring(4), out n) && n < 11) return "";
            return inst;
        }
        /// <summary>" (tier11)" after coordinates in a copy of an area, else "".</summary>
        public static string InstLabel(string inst) { return string.IsNullOrEmpty(inst) || inst.StartsWith("v") ? "" : " (" + inst + ")"; }

        /// <summary>/loc said which copy you're in: the portal / recall / gem that brought you here (learned in the last
        /// 10 minutes) lands there.</summary>
        private static Loc _arrivedPortal;
        private static StartOpt _arrivedStart;
        private static DateTime _arrivedAt = DateTime.MinValue;

        /// <summary>A dungeon's versions' names ("0110v2" = "Toxic Tunnels"): from the portal that took you there.</summary>
        public static readonly Dictionary<string, string> VarNames = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        public static void VariantSeen(int lb, string inst)
        {
            if (string.IsNullOrEmpty(inst) || !inst.StartsWith("v")) return;
            string key = lb.ToString("X4") + inst;
            if (VarNames.ContainsKey(key)) return;
            if ((DateTime.UtcNow - _arrivedAt).TotalMinutes > 2 || _arrivedPortal == null) return;
            string n = _arrivedPortal.Name ?? "";
            if (n.EndsWith(" Portal", StringComparison.OrdinalIgnoreCase)) n = n.Substring(0, n.Length - 7);
            if (n.StartsWith("Portal to ", StringComparison.OrdinalIgnoreCase)) n = n.Substring(10);
            n = n.Trim();
            if (n.Length == 0) return;
            VarNames[key] = n; Changed(); Version++;
        }

        /// <summary>A dungeon's name, for its version ("v2") if it's one: the name learned for it, else the dungeon's own and " v:2".</summary>
        /// <summary>MelkTank's Nav > Locations name for a dungeon / version ("0106v2"), or null.</summary>
        public static string LocName(int area, string inst)
        {
            try
            {
                Dictionary<string, string> d = AppDomain.CurrentDomain.GetData("MelkTank.LocNames") as Dictionary<string, string>;
                string n;
                if (d != null && d.TryGetValue(area.ToString("X4") + (inst != null && inst.StartsWith("v") ? inst : ""), out n)) return n;
            }
            catch { }
            return null;
        }

        public static string AreaName(int area, string inst)
        {
            if (area < 0) return "";
            { string ln = LocName(area, inst); if (ln != null) return ln; }
            if (string.IsNullOrEmpty(inst) || !inst.StartsWith("v")) return AreaName(area);
            string n; if (VarNames.TryGetValue(area.ToString("X4") + inst, out n)) return n;
            return AreaName(area) + " " + inst.Replace("v", "v:");
        }

        /// <summary>"0110", or "0110 v:2" for a version.</summary>
        public static string LbLabel(int area, string inst)
        {
            return area.ToString("X4") + (!string.IsNullOrEmpty(inst) && inst.StartsWith("v") ? " " + inst.Replace("v", "v:") : "");
        }

        public static void InstanceSeen(string inst)
        {
            // what brought you here: the portal / recall / gem MelksQB saw you arrive by in the last 2 minutes
            if ((DateTime.UtcNow - _arrivedAt).TotalMinutes > 2) return;
            StartOpt bs = _arrivedStart; Loc bl = _arrivedPortal;
            if (bs != null && bs.Instance != inst) { bs.Instance = inst; Changed(); Version++; }
            if (bl != null && bl.Instance != inst) { bl.Instance = inst; Changed(); Version++; NeedRebuild = true; }
        }

        // ── a copy of an area's own map: its boundary (run along it to record it) ──
        /// <summary>A tier copy's edge: lines you ran along it (each run its own line, carrying on straight past its ends).
        /// The side away from the south of each - and on the same land - is in the copy.</summary>
        internal class Bound
        {
            public List<List<Coords>> Runs = new List<List<Coords>>();
            public long Ticks;
            public int Count { get { int n = 0; foreach (List<Coords> r in Runs) n += r.Count; return n; } }
            public int Region;   // the land it's on (worked out when needed)
            public List<int> Sides;  // each run: which side the tier area is
        }
        public static readonly Dictionary<string, Bound> Bounds = new Dictionary<string, Bound>(StringComparer.OrdinalIgnoreCase);
        private static readonly HashSet<string> _removedBounds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        public static int BoundsVersion;

        /// <summary>The map a copy of an area belongs to: Tou-Tou's tier 11-15 copies share one ("tier11+"); "" = the world.</summary>
        public static string Group(string inst)
        {
            inst = Real(inst);
            return inst.Length > 0 && inst.StartsWith("tier", StringComparison.OrdinalIgnoreCase) ? "tier11+" : inst;
        }

        public static string GroupTitle(string g) { return g == "tier11+" ? "Tou-Tou Tier 11+" : g.Length == 0 ? "The world" : g; }

        /// <summary>Adds a run along the edge (null: clears it).</summary>
        public static void SetBound(string group, List<Coords> run)
        {
            if (string.IsNullOrEmpty(group)) return;
            if (run == null) { if (Bounds.Remove(group)) { _removedBounds.Add(group); BoundsVersion++; Changed(); } return; }
            if (run.Count < 2) return;
            Bound b;
            if (!Bounds.TryGetValue(group, out b)) Bounds[group] = b = new Bound();
            b.Runs.Add(run); b.Ticks = DateTime.UtcNow.Ticks; b.Region = 0; b.Sides = null;
            _removedBounds.Remove(group);
            BoundsVersion++; Changed();
        }

        /// <summary>Which side of a run the tier area is (+1 right, -1 left): run west along the bottom and north is on your
        /// right; run east and it's on your left. A run mostly north / south (a side edge): the inside is to the east going
        /// north (a west-side edge), to the west going south.</summary>
        private static int RunSide(List<Coords> r)
        {
            double dEW = r[r.Count - 1].EW - r[0].EW, dNS = r[r.Count - 1].NS - r[0].NS;
            if (Math.Abs(dEW) >= 0.3 * Math.Abs(dNS)) return dEW <= 0 ? 1 : -1;
            return 1;   // going north the right is east, going south it's west: run it with the tier area on your right
        }

        /// <summary>The side of the run a point is on, by its nearest segment: + right, - left. beyond = nearest to one of the
        /// run's ends from past it (there the water is the edge, not the line).</summary>
        private static double SideOf(List<Coords> r, Coords c, out int seg, out double dist) { bool b; return SideOf(r, c, out seg, out dist, out b); }
        private static double SideOf(List<Coords> r, Coords c, out int seg, out double dist, out bool beyond)
        {
            seg = -1; dist = double.MaxValue; double side = 0; beyond = false;
            for (int i = 1; i < r.Count; i++)
            {
                Coords p = r[i - 1], q = r[i];
                double dx = q.EW - p.EW, dy = q.NS - p.NS, l2 = dx * dx + dy * dy;
                if (l2 <= 0) continue;
                double t = ((c.EW - p.EW) * dx + (c.NS - p.NS) * dy) / l2;
                bool past = (i == 1 && t < 0) || (i == r.Count - 1 && t > 1);
                t = Math.Max(0, Math.Min(1, t));
                double ex = p.EW + t * dx - c.EW, ey = p.NS + t * dy - c.NS, d = ex * ex + ey * ey;
                if (d < dist) { dist = d; seg = i; beyond = past; side = -(dx * (c.NS - p.NS) - dy * (c.EW - p.EW)); }   // > 0: right of p->q (east = +x, north = +y)
            }
            return side;
        }

        /// <summary>In that copy: on the tier side of its edge (the side away from the south - north of the bottom line, east of a
        /// west-side line) and on the same land. True when no edge is recorded yet.</summary>
        public static bool InsideBound(string group, Coords c)
        {
            Bound b;
            if (string.IsNullOrEmpty(group) || !Bounds.TryGetValue(group, out b) || b.Runs.Count == 0 || !c.Valid) return true;
            if (b.Region == 0)
            {
                // an old "east / west limit" mark (a north-south line through the land): now the bottom edge carried on to that spot
                List<List<Coords>> old = b.Runs.FindAll(rr => rr.Count == 2 && Math.Abs(rr[0].EW - rr[1].EW) < 1e-6 && Math.Abs(Math.Abs(rr[0].NS - rr[1].NS) - 4) < 1e-3);
                if (old.Count > 0)
                {
                    foreach (List<Coords> o in old) b.Runs.Remove(o);
                    foreach (List<Coords> o in old)
                    {
                        bool east = o[0].NS > o[1].NS;   // it was run southward for an east limit
                        Coords h = new Coords((o[0].NS + o[1].NS) / 2, o[0].EW), end = Coords.None;
                        foreach (List<Coords> r in b.Runs) foreach (Coords q in new[] { r[0], r[r.Count - 1] }) if (!end.Valid || (east ? q.EW > end.EW : q.EW < end.EW)) end = q;
                        if (end.Valid && (east ? h.EW > end.EW : h.EW < end.EW)) b.Runs.Add(east ? new List<Coords> { h, end } : new List<Coords> { end, h });
                    }
                    BoundsVersion++; Changed();
                }
                if (b.Runs.Count == 0) return true;
                // the land the edge was run on: the commonest walking area along it
                Dictionary<int, int> cnt = new Dictionary<int, int>();
                foreach (List<Coords> r in b.Runs) foreach (Coords p in r) { int g = WorldMap.Region(p); if (g == 0) continue; int v; cnt.TryGetValue(g, out v); cnt[g] = v + 1; }
                int bn = 0; foreach (KeyValuePair<int, int> kv in cnt) if (kv.Value > bn) { bn = kv.Value; b.Region = kv.Key; }
                b.Sides = new List<int>(); foreach (List<Coords> r in b.Runs) b.Sides.Add(RunSide(r));
            }
            if (b.Region != 0) { int rc = WorldMap.Region(c); if (rc != 0 && rc != b.Region) return false; }
            // the area is small: nothing more than 7 map units from the edge counts (past its ends the land carries on to
            // the mainland, and without this all of it - towns, the Facility Hub - came out "in the tier")
            {
                double near = double.MaxValue;
                foreach (List<Coords> r in b.Runs) foreach (Coords p in r) near = Math.Min(near, p.DistanceTo(c));
                if (near > 7) return false;
            }
            // the nearest run decides
            double best = double.MaxValue, bestSide = 1;
            for (int k = 0; k < b.Runs.Count; k++)
            {
                if (b.Runs[k].Count < 2) continue;
                int seg; double d; bool past;
                double sd = SideOf(b.Runs[k], c, out seg, out d, out past) * (b.Sides != null && k < b.Sides.Count ? b.Sides[k] : 1);
                if (past) sd = 1;   // past the line's end: the water is the edge there
                if (d < best) { best = d; bestSide = sd; }
            }
            return bestSide >= -1e-7;
        }

        public static bool InPoly(List<Coords> p, Coords c)
        {
            bool inside = false;
            for (int i = 0, j = p.Count - 1; i < p.Count; j = i++)
            {
                if ((p[i].NS > c.NS) != (p[j].NS > c.NS) &&
                    c.EW < (p[j].EW - p[i].EW) * (c.NS - p[i].NS) / (p[j].NS - p[i].NS) + p[i].EW) inside = !inside;
            }
            return inside;
        }

        public static void SetFlag(string f) { if (Flags.Add(f)) { _removedFlags.Remove(f); Changed(); } }
        public static void ClearFlag(string f) { if (Flags.Remove(f)) { _removedFlags.Add(f); Changed(); } }
        private static readonly HashSet<string> _removedFlags = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        /// <summary>GoArrow's own custom points (its locations.xml, customized="True"), added to yours (ones already there are skipped). null = the ones in our list.</summary>
        public static int ImportGoArrow(string file)
        {
            List<Point> l = new List<Point>();
            if (file == null) l.AddRange(GoArrowCustom);
            else
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(file);
                foreach (XmlNode n in doc.SelectNodes("/locations/loc"))
                {
                    if (Attr(n, "customized") != "True") continue;
                    Point p = new Point { Name = Attr(n, "name"), Type = Attr(n, "type"), Notes = (n.InnerText ?? "").Trim(), At = new Coords(Num(Attr(n, "NS")), Num(Attr(n, "EW"))) };
                    if (p.Type.Length == 0) p.Type = "Custom";
                    if (p.At.Valid && p.Name.Length > 0) l.Add(p);
                }
            }
            int added = 0;
            foreach (Point p in l) if (!Points.ContainsKey(p.Key)) { Points[p.Key] = p; _removedPoints.Remove(p.Key); added++; }
            if (added > 0) { PointsVersion++; Changed(); }
            return added;
        }

        /// <summary>An area you can't walk into or out of (only portals): marked on the Travel tab while standing in it.</summary>
        internal class Wall { public string Name = ""; public Coords At = Coords.None; public double R = 1.5; public string Key { get { return At.Raw(); } } }
        public static readonly Dictionary<string, Wall> Walls = new Dictionary<string, Wall>(StringComparer.OrdinalIgnoreCase);
        private static readonly HashSet<string> _removedWalls = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        /// <summary>The walled-in area a place is in (null if none).</summary>
        public static Wall WallAt(Coords c)
        {
            if (!c.Valid) return null;
            foreach (Wall w in Walls.Values) if (w.At.DistanceTo(c) <= w.R) return w;
            return null;
        }

        public static void AddWall(string name, Coords at, double r)
        {
            if (!at.Valid) return;
            Wall w = new Wall { Name = name ?? "", At = at, R = Math.Max(0.2, Math.Min(10, r)) };
            Walls[w.Key] = w;
            _removedWalls.Remove(w.Key);
            Changed(); Version++;
        }

        public static void RemoveWall(Wall w)
        {
            if (w == null || !Walls.Remove(w.Key)) return;
            _removedWalls.Add(w.Key);
            Changed(); Version++;
        }
        public static string CharKey = "";
        public static string LoadError = "";

        // ── the hubs everyone can use ──
        public static readonly Coords TownNetworkArrival = new Coords(-96.68392, -101.65892);
        public static readonly Coords FacilityHubArrival = new Coords(-100.72468, 8.69433);

        // ── indoor landblocks ──
        private static Dictionary<int, string> _dungeons;
        private static Dictionary<int, string> DungeonNames
        {
            get
            {
                if (_dungeons == null)
                {
                    _dungeons = new Dictionary<int, string>();
                    foreach (string l in Dungeons.List)
                    {
                        int bar = l.IndexOf('|');
                        int lb;
                        if (bar == 4 && int.TryParse(l.Substring(0, 4), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out lb) && !_dungeons.ContainsKey(lb))
                            _dungeons[lb] = l.Substring(5);
                    }
                }
                return _dungeons;
            }
        }

        public static bool IsEdge(int lb) { int x = lb >> 8, y = lb & 0xFF; return x <= 3 || y <= 3 || x >= 252 || y >= 252; }
        public static bool IsDungeon(int lb) { return DungeonNames.ContainsKey(lb) || LearnedIndoor.Contains(lb) || WorldMap.CellsNoBuildings(lb); }

        public static string AreaName(int area)
        {
            if (area < 0) return "";
            string n;
            if (DungeonNames.TryGetValue(area, out n)) return n;
            foreach (int d in new[] { -1, 1 })
            {
                if (DungeonNames.TryGetValue(area + d, out n)) return n;
                if (DungeonNames.TryGetValue(area + (d << 8), out n)) return n;
            }
            return "dungeon " + area.ToString("X4");
        }

        /// <summary>The indoor area (an edge landblock - the hubs and dungeons in the sea) that list coordinates fall in, or -1.</summary>
        public static int AreaOfCoords(Coords c)
        {
            if (!c.Valid) return -1;
            int x = (int)Math.Floor((c.EW + 101.95) / 0.8), y = (int)Math.Floor((c.NS + 101.95) / 0.8);
            int lb = (x << 8) | (y & 0xFF);
            if (x < 0 || y < 0 || x > 255 || y > 255) return -1;
            // dungeon cells mostly sit south of their landblock's corner (negative y): the landblock north is the likeliest
            foreach (int dx in new[] { 0, 1, -1 })
                foreach (int dy in new[] { 1, 0, -1 })
                {
                    int l2 = ((x + dx) << 8) | ((y + dy) & 0xFF);
                    if (x + dx < 0 || y + dy < 0 || x + dx > 255 || y + dy > 255) continue;
                    if (IsEdge(l2) && IsDungeon(l2)) return l2;
                }
            return -1;
        }

        /// <summary>The area of a game landcell: an indoor cell in a dungeon landblock, else outdoors (-1) - a house is outdoors.</summary>
        public static int AreaOfCell(uint cell)
        {
            if (cell == 0 || (cell & 0xFFFF) < 0x100) return -1;
            int lb = (int)(cell >> 16);
            return IsDungeon(lb) ? lb : -1;
        }

        /// <summary>Two areas you can run between: both outdoors, or the same dungeon (next-door landblocks count - the
        /// list's coordinates are a landblock off now and then).</summary>
        public static bool SameArea(int a, int b)
        {
            if (a < 0 || b < 0) return a < 0 && b < 0;
            return Math.Abs((a >> 8) - (b >> 8)) <= 1 && Math.Abs((a & 0xFF) - (b & 0xFF)) <= 1;
        }

        // ── files ──
        public static string ListPath { get { return Util.FullPath(System.IO.Path.Combine("Travel", "locations.xml")); } }
        public static string LearnPath { get { return Util.FullPath("MQT_Travel.xml"); } }
        private static DateTime _learnStamp = DateTime.MinValue;
        private static readonly List<Loc> _base = new List<Loc>();
        private static bool _baseLoaded;

        public static void Load(string charKey)
        {
            CharKey = charKey ?? "";
            LoadBase();
            ReadLearned();
            try { UndoWrongRandom(); } catch (Exception ex) { Util.LogError(ex); }
            try { DropVersionCopies(); } catch (Exception ex) { Util.LogError(ex); }
            if (!Flags.Contains("goarrow-imported") && GoArrowCustom.Count > 0) { ImportGoArrow(null); SetFlag("goarrow-imported"); }
            Rebuild();
        }

        private static void LoadBase()
        {
            if (_baseLoaded) return;
            _baseLoaded = true;
            _base.Clear();
            LoadError = "";
            try
            {
                if (!File.Exists(ListPath)) { LoadError = "No locations list: " + ListPath; return; }
                XmlDocument doc = new XmlDocument();
                doc.Load(ListPath);
                Dictionary<string, List<Loc>> twins = new Dictionary<string, List<Loc>>();
                foreach (XmlNode n in doc.SelectNodes("/locations/loc"))
                {
                    Loc l = new Loc();
                    int.TryParse(Attr(n, "id"), out l.Id);
                    l.Name = Plain(Attr(n, "name"));
                    l.Type = Attr(n, "type");
                    l.Notes = (n.InnerText ?? "").Trim();
                    l.At = new Coords(Num(Attr(n, "NS")), Num(Attr(n, "EW")));
                    string en = Attr(n, "exitNS"), ee = Attr(n, "exitEW");
                    if (en.Length > 0 && ee.Length > 0) l.Exit = new Coords(Num(en), Num(ee));
                    if (!l.At.Valid || l.Name.Length == 0) continue;
                    if (Attr(n, "customized") == "True" && !l.HasExit)
                    {
                        // one of your own GoArrow points: a world map point you can change, not part of the list
                        GoArrowCustom.Add(new Point { Name = l.Name, Type = l.Type.Length > 0 ? l.Type : "Custom", Notes = l.Notes, At = l.At });
                        l.Mine = true;   // still searchable / routable; the map shows it as your point
                    }
                    Fix(l);
                    // the list has some places twice (the same name and kind a few metres apart, from two sources): kept once,
                    // with the longer notes
                    Loc twin = null;
                    string tk = (l.Mine ? "m|" : "|") + l.Name.ToLowerInvariant() + "|" + (l.Type ?? "").ToLowerInvariant();
                    List<Loc> same;
                    if (!twins.TryGetValue(tk, out same)) twins[tk] = same = new List<Loc>();
                    foreach (Loc b in same)
                        if (b.At.DistanceTo(l.At) < 0.15 && b.HasExit == l.HasExit && (!b.HasExit || b.Exit.DistanceTo(l.Exit) < 0.15)) { twin = b; break; }
                    if (twin != null) { if ((l.Notes ?? "").Length > (twin.Notes ?? "").Length) twin.Notes = l.Notes; continue; }
                    same.Add(l);
                    _base.Add(l);
                }
            }
            catch (Exception ex) { LoadError = "Couldn't read " + ListPath + ": " + ex.Message; }
        }

        /// <summary>Known mistakes in GoArrow's list: most town portals into the Town Network say they lead to an old spot
        /// (99.1S, 8.7E) where no portal of the network is in reach; Crater Lake's has no exit at all.</summary>
        private static void Fix(Loc l)
        {
            if (l.Name.StartsWith("Town Network Portal(", StringComparison.OrdinalIgnoreCase) ||
                l.Name.StartsWith("Town Network Portal (", StringComparison.OrdinalIgnoreCase))
            {
                if (!l.HasExit || l.Exit.DistanceTo(TownNetworkArrival) > 0.5) l.Exit = TownNetworkArrival;
            }
        }

        private static string Attr(XmlNode n, string a) { XmlAttribute x = n.Attributes == null ? null : n.Attributes[a]; return x == null ? "" : x.Value; }
        private static double Num(string s) { double d; return double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out d) ? d : double.NaN; }
        private static int Int(string s) { int i; return int.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out i) ? i : 0; }
        private static long Long(string s) { long i; return long.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out i) ? i : 0; }

        /// <summary>The list and the learned portals, merged: a learned portal replaces the list's portal at the same spot
        /// (keeping the list's name), anything else learned is added.</summary>
        public static void Rebuild()
        {
            Version++;
            Locs.Clear();
            // portals that move around: only where each was seen last (the list's spot for one is no use)
            Dictionary<string, Loc> newestMoving = new Dictionary<string, Loc>(StringComparer.OrdinalIgnoreCase);
            foreach (Loc p in LearnedPortals.Values)
            {
                if (!Moves(p.Name)) continue;
                string mk = p.Name.ToLowerInvariant() + "|" + p.In;
                Loc had;
                if (!newestMoving.TryGetValue(mk, out had) || TicksOf(p) > TicksOf(had)) newestMoving[mk] = p;
            }
            foreach (Loc b in _base)
            {
                if (Moves(b.Name) && (b.HasExit || IsPortalType(b.Type))) continue;
                Loc c = new Loc { Id = b.Id, Name = b.Name, Type = b.Type, Notes = b.Notes, At = b.At, Exit = b.Exit, Mine = b.Mine };   // (Mine: drawn as your point, not twice)
                c.Area = AreaOfCoords(c.At);
                c.ExitArea = c.HasExit ? AreaOfCoords(c.Exit) : -1;
                Locs.Add(c);
            }
            List<Loc> portalLike = new List<Loc>();
            foreach (Loc c in Locs) if (c.HasExit || IsPortalType(c.Type)) portalLike.Add(c);
            foreach (Loc p in LearnedPortals.Values)
            {
                if (PortalBots.InZone(p.At, p.Area)) continue;   // one a portal bot opened: only there a moment
                if (Moves(p.Name)) { Loc nw; if (!newestMoving.TryGetValue(p.Name.ToLowerInvariant() + "|" + p.In, out nw) || nw != p) continue; }   // an older spot of one that moves
                // the list's portal at this spot: one whose exit agrees (the list's coordinates are rough: within 60 m outdoors),
                // else one right on the spot (7 m) - the list had its exit wrong, and the game's own is used from now on
                double r = p.Area >= 0 ? 0.015 : 0.25, tight = p.Area >= 0 ? 0.015 : 0.03;
                Loc best = null; double bd = double.MaxValue; bool bestAgrees = false;
                foreach (Loc c in portalLike)
                {
                    if (c.Learned || !SameArea(c.Area, p.Area) || p.In.Length > 0) continue;   // (one in a tier copy is its own)
                    double d = c.At.DistanceTo(p.At);
                    if (d >= r) continue;
                    bool agrees = !c.HasExit || !p.HasExit || (c.Exit.DistanceTo(p.Exit) < 3 && SameArea(c.ExitArea, p.ExitArea));
                    if (!agrees && d >= tight) continue;
                    if (best == null || (agrees && !bestAgrees) || (agrees == bestAgrees && d < bd)) { best = c; bd = d; bestAgrees = agrees; }
                }
                if (best != null) best.Name = p.Name;   // the game's own name: what's on the portal you'll be looking for
                if (best != null)
                {
                    best.At = p.At; best.Area = p.Area;
                    if (p.HasExit) { best.Exit = p.Exit; best.ExitArea = p.ExitArea; }
                    best.MinLevel = p.MinLevel; best.MaxLevel = p.MaxLevel;
                    best.Cell = p.Cell;
                    best.Instance = p.Instance;
                    best.Learned = true;
                }
                else
                {
                    Locs.Add(new Loc { Name = p.Name, Type = "Portal", At = p.At, Area = p.Area, Exit = p.Exit, ExitArea = p.ExitArea,
                                       MinLevel = p.MinLevel, MaxLevel = p.MaxLevel, Cell = p.Cell, Learned = true, Instance = p.Instance, In = p.In });
                }
            }
        }

        public static bool IsPortalType(string t)
        {
            return t != null && (t.IndexOf("Portal", StringComparison.OrdinalIgnoreCase) >= 0);
        }

        // ── learned: read / merge / write (MQT_Travel.xml) ──

        private static void ReadLearned()
        {
            try
            {
                string p = LearnPath;
                if (!File.Exists(p)) return;
                _learnStamp = File.GetLastWriteTimeUtc(p);
                XmlDocument doc = new XmlDocument();
                Util.LoadXml(doc, p);
                ReadInto(doc, LearnedPortals, SharedStarts, CharStarts, Avoid, LearnedIndoor, Walls, Points, Random, Flags); PointsVersion++;
            }
            catch (Exception ex) { Util.LogError(ex); }
        }

        private static void ReadInto(XmlDocument doc, Dictionary<string, Loc> portals, Dictionary<string, StartOpt> shared,
                                     Dictionary<string, StartOpt> mine, HashSet<string> avoid, HashSet<int> indoor, Dictionary<string, Wall> walls,
                                     Dictionary<string, Point> points, HashSet<string> random, HashSet<string> flags)
        {
            XmlElement root = doc.DocumentElement;
            if (root == null) return;
            foreach (XmlNode n in root.SelectNodes("portal"))
            {
                Loc l = new Loc { Name = Attr(n, "n"), At = Coords.FromRaw(Attr(n, "a")), Exit = Coords.FromRaw(Attr(n, "e")),
                                  Area = Attr(n, "al").Length > 0 ? Int(Attr(n, "al")) : -1, ExitArea = Attr(n, "el").Length > 0 ? Int(Attr(n, "el")) : -1,
                                  MinLevel = Int(Attr(n, "min")), MaxLevel = Int(Attr(n, "max")), Learned = true, Instance = Attr(n, "in"), In = Attr(n, "si") };
                uint cl; if (uint.TryParse(Attr(n, "c"), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out cl)) l.Cell = cl;
                string ex = Attr(n, "ex");
                if (ex.Length > 0) l.Exits = new List<string>(ex.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries));
                l.Id = 0;
                { Loc old; if (portals.TryGetValue(l.Key, out old)) MergeExits(l, old); }
                long t = Long(Attr(n, "t"));
                if (!l.At.Valid) continue;
                Loc have;
                if (!portals.TryGetValue(l.Key, out have) || TicksOf(have) <= t) { _ticks[l.Key] = t; portals[l.Key] = l; }
            }
            foreach (XmlNode n in root.SelectNodes("start")) MergeStart(shared, ReadStart(n, false));
            foreach (XmlNode n in root.SelectNodes("avoid")) { string k = Attr(n, "k"); if (k.Length > 0) avoid.Add(k); }
            foreach (XmlNode n in root.SelectNodes("point"))
            {
                Point p = new Point { Name = Plain(Attr(n, "n")), Type = Attr(n, "ty"), Notes = Attr(n, "note"), At = Coords.FromRaw(Attr(n, "c")), Auto = Attr(n, "auto") == "1", In = Attr(n, "si") };
                { double pz; if (double.TryParse(Attr(n, "z"), NumberStyles.Float, CultureInfo.InvariantCulture, out pz)) p.Z = pz; }
                if (p.Type.Length == 0) p.Type = "Custom";
                if (p.At.Valid && p.Name.Length > 0 && !_removedPoints.Contains(p.Key)) points[p.Key] = p;
            }
            foreach (XmlNode n in root.SelectNodes("boundary"))
            {
                string k = Attr(n, "k"); long t = Long(Attr(n, "t"));
                if (k.Length == 0 || _removedBounds.Contains(k)) continue;
                Bound nb = new Bound { Ticks = t };
                foreach (string run in Attr(n, "pts").Split('|'))
                {
                    List<Coords> pts = new List<Coords>();
                    foreach (string s in run.Split(';')) { Coords c = Coords.FromRaw(s); if (c.Valid) pts.Add(c); }
                    if (pts.Count >= 2) nb.Runs.Add(pts);
                }
                Bound have;
                if (nb.Runs.Count > 0 && (!Bounds.TryGetValue(k, out have) || have.Ticks < t)) { Bounds[k] = nb; BoundsVersion++; }
            }
            foreach (XmlNode n in root.SelectNodes("random")) { string k = Attr(n, "k"); if (k.Length > 0 && !_removedRandom.Contains(k)) random.Add(k); }
            foreach (XmlNode n in root.SelectNodes("flag")) { string k = Attr(n, "k"); if (k.Length > 0 && !_removedFlags.Contains(k)) flags.Add(k); }
            foreach (XmlNode n in root.SelectNodes("vname")) { string k = Attr(n, "k"), nm = Attr(n, "n"); if (k.Length > 0 && nm.Length > 0 && !VarNames.ContainsKey(k)) VarNames[k] = nm; }
            foreach (XmlNode n in root.SelectNodes("walled"))
            {
                Wall w = new Wall { Name = Attr(n, "n"), At = Coords.FromRaw(Attr(n, "c")) };
                double r; if (double.TryParse(Attr(n, "r"), NumberStyles.Float, CultureInfo.InvariantCulture, out r)) w.R = r;
                if (w.At.Valid) walls[w.Key] = w;
            }
            foreach (XmlNode n in root.SelectNodes("indoor")) { int lb; if (int.TryParse(Attr(n, "lb"), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out lb)) indoor.Add(lb); }
            XmlNode me = root.SelectSingleNode("char[@key=" + XPathString(CharKey) + "]");
            if (me != null) foreach (XmlNode n in me.SelectNodes("start")) MergeStart(mine, ReadStart(n, true));
        }

        private static readonly Dictionary<string, long> _ticks = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase);
        private static long TicksOf(Loc l) { long t; return _ticks.TryGetValue(l.Key, out t) ? t : 0; }

        // ── portals that turn up in different places (Cow Level, Thieves' Parlor): marked by name ──
        public static double MovesFreshMin = 15;   // seen this recently: routes may use it where it was seen
        private static string MovesFlag(string name) { return "moves|" + Plain(name ?? "").Trim().ToLowerInvariant(); }
        public static bool Moves(string name) { return !string.IsNullOrEmpty(name) && Flags.Contains(MovesFlag(name)); }
        public static void SetMoves(string name, bool on)
        {
            if (on) SetFlag(MovesFlag(name)); else ClearFlag(MovesFlag(name));
            Version++; NeedRebuild = true;
        }
        /// <summary>When a learned portal was last seen / used there (UTC), or MinValue.</summary>
        public static DateTime LastSeen(Loc l)
        {
            long t = 0;
            if (l == null || !_ticks.TryGetValue(l.Key, out t) || t <= 0) return DateTime.MinValue;
            return new DateTime(t, DateTimeKind.Utc);
        }
        /// <summary>A portal that moves around, seen where it is in the last few minutes.</summary>
        public static bool MovesFresh(Loc l) { DateTime t = LastSeen(l); return t != DateTime.MinValue && (DateTime.UtcNow - t).TotalMinutes <= MovesFreshMin; }

        private static StartOpt ReadStart(XmlNode n, bool perChar)
        {
            return new StartOpt { Kind = Attr(n, "k"), Name = Attr(n, "n"), Exit = Coords.FromRaw(Attr(n, "e")),
                                  ExitArea = Attr(n, "el").Length > 0 ? Int(Attr(n, "el")) : -1, Ticks = Long(Attr(n, "t")), PerChar = perChar,
                                  OpensPortal = Attr(n, "o") == "1", Instance = Attr(n, "in") };
        }

        private static string StartKey(StartOpt s) { return s.Kind + "|" + s.Name; }

        private static void MergeStart(Dictionary<string, StartOpt> d, StartOpt s)
        {
            if (s == null || s.Name.Length == 0 || !s.Exit.Valid) return;
            StartOpt have;
            if (!d.TryGetValue(StartKey(s), out have) || have.Ticks <= s.Ticks) d[StartKey(s)] = s;
        }

        private static string XPathString(string s)
        {
            if (s.IndexOf('\'') < 0) return "'" + s + "'";
            return "concat('" + s.Replace("'", "',\"'\",'") + "')";
        }

        /// <summary>Picks up what other clients saved (every few seconds from the frame).</summary>
        public static void PickUpOthers()
        {
            try
            {
                string p = LearnPath;
                if (!File.Exists(p)) return;
                DateTime w = File.GetLastWriteTimeUtc(p);
                if (w == _learnStamp) return;
                _learnStamp = w;
                XmlDocument doc = new XmlDocument();
                Util.LoadXml(doc, p);
                ReadInto(doc, LearnedPortals, SharedStarts, CharStarts, Avoid, LearnedIndoor, Walls, Points, Random, Flags); PointsVersion++;
                DropVersionCopies(LearnedPortals);
                NeedRebuild = true;
            }
            catch (Exception ex) { Util.LogError(ex); }
        }

        // ── changes ──
        private static bool _dirty;
        private static DateTime _dirtyAt = DateTime.MinValue;

        public static void LearnPortal(string name, Coords at, int area, Coords exit, int exitArea, int min, int max, uint cell = 0)
        {
            if ((cell & 0xFFFF) < 0x100) cell = 0;   // outdoors: not needed
            if (!at.Valid || string.IsNullOrEmpty(name)) return;
            if (PortalBots.IsBotName(name)) return;
            if (PortalBots.LearnExit(name, at, area, exit, exitArea)) { _arrivedPortal = null; _arrivedStart = null; _arrivedAt = DateTime.UtcNow; return; }   // a portal bot's: its place's exit
            string standIn = area >= 0 ? (Travel.HereInstance.StartsWith("v") ? Travel.HereInstance : "") : Travel.HereGroup;   // seen in a tier copy: on that copy's map, not the world's (in a dungeon's version: that version)
            _arrivedPortal = null; _arrivedStart = null; _arrivedAt = DateTime.UtcNow;
            string key = null;
            foreach (Loc l in LearnedPortals.Values)
                if (string.Equals(l.Name, name, StringComparison.OrdinalIgnoreCase) && SameArea(l.Area, area) && l.In == standIn && l.At.DistanceTo(at) < (area >= 0 ? 0.01 : 0.05)) { key = l.Key; break; }
            Loc p;
            if (key != null && LearnedPortals.TryGetValue(key, out p))
            {
                _arrivedPortal = p;
                bool changed = false;
                // a portal in a dungeon (surface portals...) is its own portal, one per spot - never "random"; and a landing a
                // little way from the destination its description gives (rounded coordinates) is the same place
                if (exit.Valid && p.HasExit && p.Area < 0 && (p.Exit.DistanceTo(exit) > SamePlace || p.ExitArea != exitArea))
                {
                    // somewhere else this time: it goes to different places - every one is kept, and it's marked random
                    if (p.Exits == null) p.Exits = new List<string>();
                    AddExit(p, p.Exit, p.ExitArea);
                    bool fresh = AddExit(p, exit, exitArea);
                    if (fresh && !Random.Contains(p.Key))
                    {
                        SetRandom(p.Key, true);
                        Util.WriteToChat("Travel: " + p.Name + " goes to different places - marked Random destination (not used for routes). " + p.Exits.Count + " places seen so far.");
                    }
                    else if (fresh) Util.WriteToChat("Travel: " + p.Name + " - another place it goes (" + p.Exits.Count + " seen).");
                }
                if (exit.Valid && (!p.HasExit || p.Exit.DistanceTo(exit) > 0.05 || p.ExitArea != exitArea)) { p.Exit = exit; p.ExitArea = exitArea; changed = true; }
                if (min != p.MinLevel || max != p.MaxLevel) { p.MinLevel = min; p.MaxLevel = max; changed = true; }
                if (cell != 0 && cell != p.Cell) { p.Cell = cell; changed = true; }
                if (Moves(name)) changed = true;   // one that moves around: "seen here" is now
                if (!changed) return;
                _ticks[key] = DateTime.UtcNow.Ticks;
            }
            else
            {
                p = new Loc { Name = name, At = at, Area = area, Exit = exit, ExitArea = exitArea, MinLevel = min, MaxLevel = max, Cell = cell, Learned = true, In = standIn };
                LearnedPortals[p.Key] = p;
                _ticks[p.Key] = DateTime.UtcNow.Ticks;
                _arrivedPortal = p;
            }
            Changed();
            NeedRebuild = true;
        }

        private const double SamePlace = 0.3;   // map units (~70 m): two landings closer than this are one destination

        /// <summary>Older builds marked portals in dungeons (and ones whose two landings were a few metres apart) as going to
        /// different places: put right once at load.</summary>
        /// <summary>An older build saved portals seen in a dungeon's other version (v:2) a second time without the version, so
        /// the plain dungeon got them too - a portal that isn't there (Death Dillow Flats in the Facility Hub, where Catacombs
        /// of the Forgotten stands). The plain copy of one also kept for a version is dropped once at load.</summary>
        private static void DropVersionCopies()
        {
            int n = DropVersionCopies(LearnedPortals);
            if (n > 0) { Changed(); NeedRebuild = true; Util.WriteToChat("Travel: dropped " + n + " portal" + (n == 1 ? "" : "s") + " saved for the plain dungeon that belong to its other version."); }
        }
        /// <summary>(also on what's read back from the file - saving merges it in again, and other clients' copies)</summary>
        private static int DropVersionCopies(Dictionary<string, Loc> portals)
        {
            List<string> drop = new List<string>();
            foreach (Loc p in portals.Values)
            {
                if (p.In.Length > 0 || p.Area < 0) continue;
                foreach (Loc q in portals.Values)
                    if (q.In.StartsWith("v") && string.Equals(q.Name, p.Name, StringComparison.OrdinalIgnoreCase) && SameArea(q.Area, p.Area) && q.At.DistanceTo(p.At) < 0.01)
                    { drop.Add(p.Key); break; }
            }
            foreach (string k in drop) { portals.Remove(k); if (portals == LearnedPortals) _ticks.Remove(k); }
            return drop.Count;
        }

        private static void UndoWrongRandom()
        {
            foreach (Loc p in LearnedPortals.Values)
            {
                if (p.Exits == null || p.Exits.Count < 2) continue;
                bool far = false;
                if (p.Area < 0)
                {
                    List<Coords> cs = new List<Coords>();
                    foreach (string s in p.Exits) { Coords c; int a; if (ParseExit(s, out c, out a)) cs.Add(c); }
                    for (int i = 0; i < cs.Count && !far; i++) for (int j = 0; j < i; j++) if (cs[i].DistanceTo(cs[j]) >= SamePlace) { far = true; break; }
                }
                if (far) continue;
                p.Exits = null;
                if (Random.Contains(p.Key)) SetRandom(p.Key, false);
                _ticks[p.Key] = DateTime.UtcNow.Ticks;
                Changed();
            }
        }

        private static string ExitRaw(Coords c, int area) { return c.Raw() + "@" + area.ToString(CultureInfo.InvariantCulture); }

        /// <summary>A place a portal has put you, added to its list unless one within ~12 m is there. True = new.</summary>
        private static bool AddExit(Loc p, Coords c, int area)
        {
            if (!c.Valid) return false;
            if (p.Exits == null) p.Exits = new List<string>();
            foreach (string s in p.Exits)
            {
                Coords h; int ha;
                if (ParseExit(s, out h, out ha) && ha == area && h.DistanceTo(c) < SamePlace) return false;
            }
            p.Exits.Add(ExitRaw(c, area));
            return true;
        }

        public static bool ParseExit(string s, out Coords c, out int area)
        {
            c = Coords.None; area = -1;
            if (string.IsNullOrEmpty(s)) return false;
            int at = s.LastIndexOf('@');
            c = Coords.FromRaw(at >= 0 ? s.Substring(0, at) : s);
            if (at >= 0) int.TryParse(s.Substring(at + 1), NumberStyles.Integer, CultureInfo.InvariantCulture, out area);
            return c.Valid;
        }

        /// <summary>Every place either copy has seen.</summary>
        private static void MergeExits(Loc into, Loc from)
        {
            if (from == null || from.Exits == null) return;
            foreach (string s in from.Exits) { Coords c; int a; if (ParseExit(s, out c, out a)) AddExit(into, c, a); }
        }

        /// <summary>The places a learned portal has been seen to go (more than one: it goes somewhere different each time).</summary>
        public static List<string> ExitsOf(string key)
        {
            Loc l;
            return key != null && LearnedPortals.TryGetValue(key, out l) && l.Exits != null && l.Exits.Count > 1 ? l.Exits : null;
        }

        public static void LearnStart(string kind, string name, Coords exit, int exitArea, bool perChar, bool opensPortal = false)
        {
            if (string.IsNullOrEmpty(name) || !exit.Valid) return;
            StartOpt s = new StartOpt { Kind = kind, Name = name, Exit = exit, ExitArea = exitArea, Ticks = DateTime.UtcNow.Ticks, PerChar = perChar, OpensPortal = opensPortal };
            Dictionary<string, StartOpt> d = perChar ? CharStarts : SharedStarts;
            StartOpt have;
            _arrivedPortal = null; _arrivedAt = DateTime.UtcNow;
            if (d.TryGetValue(StartKey(s), out have) && have.Exit.DistanceTo(exit) < 0.05 && have.ExitArea == exitArea && have.OpensPortal == opensPortal) { _arrivedStart = have; return; }
            if (have != null && have.Exit.DistanceTo(exit) < 0.05) s.Instance = have.Instance;   // the same place: the same copy
            d[StartKey(s)] = s;
            _arrivedStart = s;
            Changed();
        }

        public static void ForgetStart(StartOpt s)
        {
            if (s == null) return;
            Dictionary<string, StartOpt> d = s.PerChar ? CharStarts : SharedStarts;
            if (d.Remove(StartKey(s))) { _removedStarts.Add((s.PerChar ? "c|" : "s|") + StartKey(s)); Changed(); }
        }
        private static readonly HashSet<string> _removedStarts = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        public static void SetAvoid(string key, bool on)
        {
            if (on ? Avoid.Add(key) : Avoid.Remove(key)) { if (!on) _removedAvoid.Add(key); Changed(); }
        }
        private static readonly HashSet<string> _removedAvoid = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        public static void LearnIndoor(int lb)
        {
            if (lb <= 0 || IsDungeon(lb)) return;
            LearnedIndoor.Add(lb);
            Changed();
            NeedRebuild = true;
        }

        private static void Changed() { _dirty = true; _dirtyAt = DateTime.Now; }

        /// <summary>From the frame: saves 2 s after the last change.</summary>
        public static bool NeedRebuild;
        public static int Version;   // goes up when the places change (routes worked out before are re-checked)

        public static void Tick()
        {
            if (_dirty && (DateTime.Now - _dirtyAt).TotalSeconds > 2) Save();
            if (NeedRebuild) { NeedRebuild = false; Rebuild(); }
        }

        public static void Flush() { if (_dirty) Save(); }

        private static void Save()
        {
            _dirty = false;
            string path = LearnPath;
            Util.Locked(path, () =>
            {
                try
                {
                    // merge with the file first (another client may have saved since): theirs + ours, the newer wins
                    if (File.Exists(path))
                    {
                        XmlDocument cur = new XmlDocument();
                        try { cur.Load(path); } catch { cur = null; }
                        if (cur != null)
                        {
                            Dictionary<string, Loc> fp = new Dictionary<string, Loc>(StringComparer.OrdinalIgnoreCase);
                            Dictionary<string, StartOpt> fs = new Dictionary<string, StartOpt>(StringComparer.OrdinalIgnoreCase);
                            Dictionary<string, StartOpt> fm = new Dictionary<string, StartOpt>(StringComparer.OrdinalIgnoreCase);
                            HashSet<string> fa = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                            HashSet<int> fi = new HashSet<int>();
                            Dictionary<string, Wall> fw = new Dictionary<string, Wall>(StringComparer.OrdinalIgnoreCase);
                            Dictionary<string, Point> fpt = new Dictionary<string, Point>(StringComparer.OrdinalIgnoreCase);
                            HashSet<string> frn = new HashSet<string>(StringComparer.OrdinalIgnoreCase), ffl = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                            Dictionary<string, long> keep = new Dictionary<string, long>(_ticks, StringComparer.OrdinalIgnoreCase);
                            ReadInto(cur, fp, fs, fm, fa, fi, fw, fpt, frn, ffl);
                            DropVersionCopies(fp);
                            foreach (KeyValuePair<string, Loc> kv in fp)
                            {
                                long theirs; _ticks.TryGetValue(kv.Key, out theirs);
                                long mine; keep.TryGetValue(kv.Key, out mine);
                                Loc ours; LearnedPortals.TryGetValue(kv.Key, out ours);
                                if (ours != null) MergeExits(ours, kv.Value);
                                if (ours == null || theirs > mine) { if (ours != null) MergeExits(kv.Value, ours); LearnedPortals[kv.Key] = kv.Value; }
                                _ticks[kv.Key] = Math.Max(theirs, mine);
                            }
                            foreach (StartOpt s in fs.Values) if (!_removedStarts.Contains("s|" + StartKey(s))) MergeStart(SharedStarts, s);
                            foreach (StartOpt s in fm.Values) if (!_removedStarts.Contains("c|" + StartKey(s))) MergeStart(CharStarts, s);
                            foreach (string a in fa) if (!_removedAvoid.Contains(a)) Avoid.Add(a);
                            foreach (int i in fi) LearnedIndoor.Add(i);
                            foreach (Wall w in fw.Values) if (!_removedWalls.Contains(w.Key) && !Walls.ContainsKey(w.Key)) Walls[w.Key] = w;
                            foreach (Point pt in fpt.Values) if (!Points.ContainsKey(pt.Key)) { Points[pt.Key] = pt; PointsVersion++; }
                            foreach (string r in frn) Random.Add(r);
                            foreach (string f in ffl) Flags.Add(f);   // (ones you turned off were skipped as read)
                            Write(cur, path);
                            return;
                        }
                    }
                    Write(null, path);
                }
                catch (Exception ex) { Util.LogError(ex); }
            });
            try { _learnStamp = File.GetLastWriteTimeUtc(path); } catch { }
            NeedRebuild = true;
        }

        private static void Write(XmlDocument old, string path)
        {
            XmlDocument doc = new XmlDocument();
            XmlElement root = doc.CreateElement("MQT_Travel");
            doc.AppendChild(root);
            foreach (KeyValuePair<string, Loc> kv in LearnedPortals)
            {
                Loc l = kv.Value;
                XmlElement e = doc.CreateElement("portal");
                e.SetAttribute("n", l.Name);
                e.SetAttribute("a", l.At.Raw());
                if (l.Area >= 0) e.SetAttribute("al", l.Area.ToString(CultureInfo.InvariantCulture));
                if (l.HasExit) e.SetAttribute("e", l.Exit.Raw());
                if (l.ExitArea >= 0) e.SetAttribute("el", l.ExitArea.ToString(CultureInfo.InvariantCulture));
                if (l.MinLevel > 0) e.SetAttribute("min", l.MinLevel.ToString(CultureInfo.InvariantCulture));
                if (l.MaxLevel > 0) e.SetAttribute("max", l.MaxLevel.ToString(CultureInfo.InvariantCulture));
                if (l.Cell != 0) e.SetAttribute("c", l.Cell.ToString("X8"));
                if (l.Instance.Length > 0) e.SetAttribute("in", l.Instance);
                if (l.In.Length > 0) e.SetAttribute("si", l.In);
                if (l.Exits != null && l.Exits.Count > 1) e.SetAttribute("ex", string.Join(";", l.Exits.ToArray()));
                e.SetAttribute("t", TicksOf(l).ToString(CultureInfo.InvariantCulture));
                root.AppendChild(e);
            }
            foreach (StartOpt s in SharedStarts.Values) root.AppendChild(StartEl(doc, s));
            foreach (string a in Avoid) { XmlElement e = doc.CreateElement("avoid"); e.SetAttribute("k", a); root.AppendChild(e); }
            foreach (Point pt in Points.Values)
            {
                XmlElement e = doc.CreateElement("point");
                e.SetAttribute("n", pt.Name); e.SetAttribute("ty", pt.Type); e.SetAttribute("c", pt.At.Raw());
                if (pt.Notes.Length > 0) e.SetAttribute("note", pt.Notes);
                if (pt.Auto) e.SetAttribute("auto", "1");
                if (pt.In.Length > 0) e.SetAttribute("si", pt.In);
                if (!double.IsNaN(pt.Z)) e.SetAttribute("z", pt.Z.ToString("0.00", CultureInfo.InvariantCulture));
                root.AppendChild(e);
            }
            foreach (KeyValuePair<string, Bound> b in Bounds)
            {
                XmlElement e = doc.CreateElement("boundary");
                e.SetAttribute("k", b.Key);
                List<string> runs = new List<string>();
                foreach (List<Coords> run in b.Value.Runs)
                {
                    List<string> ps = new List<string>();
                    foreach (Coords c in run) ps.Add(c.Raw());
                    runs.Add(string.Join(";", ps.ToArray()));
                }
                e.SetAttribute("pts", string.Join("|", runs.ToArray()));
                e.SetAttribute("t", b.Value.Ticks.ToString(CultureInfo.InvariantCulture));
                root.AppendChild(e);
            }
            foreach (string r in Random) { XmlElement e = doc.CreateElement("random"); e.SetAttribute("k", r); root.AppendChild(e); }
            foreach (string f in Flags) { XmlElement e = doc.CreateElement("flag"); e.SetAttribute("k", f); root.AppendChild(e); }
            foreach (KeyValuePair<string, string> vn in VarNames) { XmlElement e = doc.CreateElement("vname"); e.SetAttribute("k", vn.Key); e.SetAttribute("n", vn.Value); root.AppendChild(e); }
            foreach (Wall w in Walls.Values)
            {
                XmlElement e = doc.CreateElement("walled");
                e.SetAttribute("n", w.Name); e.SetAttribute("c", w.At.Raw()); e.SetAttribute("r", w.R.ToString("0.##", CultureInfo.InvariantCulture));
                root.AppendChild(e);
            }
            foreach (int i in LearnedIndoor) { XmlElement e = doc.CreateElement("indoor"); e.SetAttribute("lb", i.ToString("X4")); root.AppendChild(e); }
            // every character's section: the others as they are in the file, this one from memory
            if (old != null && old.DocumentElement != null)
                foreach (XmlNode c in old.DocumentElement.SelectNodes("char"))
                {
                    if (string.Equals(Attr(c, "key"), CharKey, StringComparison.OrdinalIgnoreCase)) continue;
                    root.AppendChild(doc.ImportNode(c, true));
                }
            if (CharKey.Length > 0)
            {
                XmlElement me = doc.CreateElement("char");
                me.SetAttribute("key", CharKey);
                foreach (StartOpt s in CharStarts.Values) me.AppendChild(StartEl(doc, s));
                root.AppendChild(me);
            }
            string tmp = path + ".tmp";
            doc.Save(tmp);
            if (File.Exists(path)) File.Replace(tmp, path, null); else File.Move(tmp, path);
        }

        private static XmlElement StartEl(XmlDocument doc, StartOpt s)
        {
            XmlElement e = doc.CreateElement("start");
            e.SetAttribute("k", s.Kind);
            e.SetAttribute("n", s.Name);
            e.SetAttribute("e", s.Exit.Raw());
            if (s.ExitArea >= 0) e.SetAttribute("el", s.ExitArea.ToString(CultureInfo.InvariantCulture));
            if (s.OpensPortal) e.SetAttribute("o", "1");
            if (s.Instance.Length > 0) e.SetAttribute("in", s.Instance);
            e.SetAttribute("t", s.Ticks.ToString(CultureInfo.InvariantCulture));
            return e;
        }

        // ── seeds: where the fixed recalls and a few gems lead, until the game shows otherwise ──
        public static readonly string[] SeedSpells =
        {
            "Glenden Wood Recall|29.7,26.5", "Recall Aphus Lassel|2.3,95.5", "Ulgrim's Recall|-59.7,-88.0", "Return to the Keep|-87.5,-67.0",
            "Recall the Sanctuary|-82.5,93.4", "Mount Lethe Recall|-33.8,-85.3", "Aerlinthe Recall|84.1,47.2", "Recall to the Singularity Caul|-98.0,-94.7",
            "Call of the Mhoire Forge|-65.4,-44.0", "Gear Knight Invasion Area Camp Recall|-12.3,-74.9", "Paradox-touched Olthoi Infested Area Recall|43.8,54.9",
            "Lost City of Neftet Recall|-22.2,6.2", "Rynthid Recall|-61.6,-63.2", "Viridian Rise Great Tree Recall|-42.7,42.8",
            "Radiant Blood Stronghold Recall|12.8,0.7", "Celestial Hand Stronghold Recall|-39.7,83.6", "Eldrytch Web Stronghold Recall|26.3,49.6",
        };
        /// <summary>Gems that open a portal you then go through (rather than sending you). Also learned in the game: a portal
        /// appearing right by you just after using a gem.</summary>
        public static readonly HashSet<string> PortalOpeningGems = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        { "Infinite Town Network Portal Gem", "Eldrytch Web Stronghold Portal Gem" };

        public static readonly string[] SeedGems =
        {
            // "|portal": opens a portal you then go through (slower: the sending gems are picked first when you have both)
            "Infinite Town Network Portal Gem|TN|portal", "Infinite Town Network Sending Gem|TN", "Town Network Sending Gem|TN", "Facility Hub Portal Gem|FH",
        };

        /// <summary>A seed for a spell / gem by name (Coords.None if there isn't one).</summary>
        public static bool Seed(string kind, string name, out Coords c, out int area) { bool o; return Seed(kind, name, out c, out area, out o); }

        public static bool Seed(string kind, string name, out Coords c, out int area, out bool opensPortal)
        {
            c = Coords.None; area = -1; opensPortal = false;
            foreach (string s in kind == "gem" ? SeedGems : SeedSpells)
            {
                int bar = s.IndexOf('|');
                if (!string.Equals(s.Substring(0, bar), name, StringComparison.OrdinalIgnoreCase)) continue;
                string v = s.Substring(bar + 1);
                if (v.EndsWith("|portal", StringComparison.Ordinal)) { opensPortal = true; v = v.Substring(0, v.Length - 7); }
                if (v == "TN") c = TownNetworkArrival;
                else if (v == "FH") c = FacilityHubArrival;
                else c = Coords.FromRaw(v);
                area = AreaOfCoords(c);
                return c.Valid;
            }
            return false;
        }

        // ── finding places by name ──
        public static List<Loc> Find(string text, int max)
        {
            List<Loc> l = new List<Loc>();
            text = (text ?? "").Trim();
            if (text.Length == 0) return l;
            string[] words = text.ToLowerInvariant().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            List<KeyValuePair<int, Loc>> scored = new List<KeyValuePair<int, Loc>>();
            foreach (Loc x in Locs)
            {
                string n = x.Name.ToLowerInvariant();
                bool all = true;
                foreach (string w in words) if (n.IndexOf(w, StringComparison.Ordinal) < 0) { all = false; break; }
                if (!all) continue;
                int score = n == text.ToLowerInvariant() ? 0 : n.StartsWith(text.ToLowerInvariant(), StringComparison.Ordinal) ? 1 : 2;
                if (IsPortalType(x.Type) || x.HasExit) score += 3;   // places first, the portals to them after
                scored.Add(new KeyValuePair<int, Loc>(score * 1000 + Math.Min(999, x.Name.Length), x));
            }
            scored.Sort((a, b) => a.Key.CompareTo(b.Key));
            foreach (KeyValuePair<int, Loc> kv in scored) { l.Add(kv.Value); if (l.Count >= max) break; }
            return l;
        }
    }
}
