using System;
using System.Collections.Generic;
using System.IO;

namespace MelksQuestTracker.Travel
{
    /// <summary>A point to walk to: map coordinates, height (metres) and, indoors, the game cell it's in.</summary>
    internal struct Pt
    {
        public double NS, EW, Z;
        public uint Cell;
        public double Jump;   // outdoors: jump off here, this way (heading, degrees + 1; 0 = no jump) - the edge of a drop
        public Pt(double ns, double ew, double z, uint cell) { NS = ns; EW = ew; Z = z; Cell = cell; Jump = 0; }
        public Coords C { get { return new Coords(NS, EW); } }
    }

    /// <summary>One dungeon cell (a room / corridor piece) from the game's cell file: where it is and which cells it opens into.</summary>
    internal class DCell
    {
        public uint Id;
        public double X, Y, Z;            // in the landblock, metres
        public float QW = 1, QX, QY, QZ;  // its turn
        public ushort Env, Struct;        // the room shape: environment 0x0D00xxxx in client_portal.dat, which of its shapes
        public readonly List<float[]> Statics = new List<float[]>();   // things placed in it (fountains, trees, statues ...): x, y, z
        public readonly List<uint> Next = new List<uint>();
        public readonly List<ushort> NextPoly = new List<ushort>();   // for each of Next: the opening's polygon in the room's shape
    }

    /// <summary>
    /// The game's own map, read from its files (client_cell_1.dat: the ground's heights and types for every landblock, and every
    /// dungeon's cells and how they connect; client_portal.dat: the height table). Read only, a landblock at a time, cached.
    /// </summary>
    internal static class WorldMap
    {
        private static DatFile _cell, _portal;
        private static bool _opened;
        private static volatile bool _released;

        /// <summary>MelksQB stopping (a reload / logoff): lets go of the map's big data. An old build stays loaded after a
        /// reload, and without this its copy of the world (the picture, the areas, the cached ground) stayed in memory too.</summary>
        public static void Release()
        {
            _released = true;
#if ACGODOT
            WorldImage = null;
#else
            try { System.Drawing.Bitmap b = WorldImage; WorldImage = null; if (b != null) b.Dispose(); } catch { }
#endif
            _region = null; _sea = null;
            lock (_blocks) _blocks.Clear();
            try { _walk.Clear(); } catch { }
            try { _dungeons.Clear(); } catch { }
            try { if (_cell != null) _cell.Dispose(); } catch { }
            try { if (_portal != null) _portal.Dispose(); } catch { }
            _cell = null; _portal = null; _opened = false; _heights = null;
            _regionStarted = false; _seaStarted = false;   // started again if MelksQB starts again (logging back in)
        }
        public static string Error = "";
        private static float[] _heights;
        public static bool IndexXMajor = true;   // heights[x * 9 + y] (else y * 9 + x) - checked against where you stand

        public const double FloorZ = 0.664;     // the steepest ground you can walk up (the game's walkable normal)

        public static string DirOverride;
        public static string GameDir
        {
            get
            {
                if (DirOverride != null) return DirOverride;
#if ACGODOT
                try { string d = ACGodot.DecalShim.Bridge.Host?.DatDir; if (!string.IsNullOrEmpty(d)) return d; return Path.GetDirectoryName(System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName); }
#else
                try { return Path.GetDirectoryName(System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName); }
#endif
                catch { return @"C:\Turbine\Asheron's Call"; }
            }
        }

        public static bool Open()
        {
            if (_opened) return _cell != null;
            _opened = true;
            try
            {
                string dir = GameDir;
                _cell = new DatFile(Path.Combine(dir, "client_cell_1.dat"));
                try { _portal = new DatFile(Path.Combine(dir, "client_portal.dat")); } catch (Exception ex) { Error = "client_portal.dat: " + ex.Message; }
                _heights = ReadHeightTable();
            }
            catch (Exception ex) { Error = "Couldn't open the game's map file: " + ex.Message; _cell = null; }
            return _cell != null;
        }

        public static void Close()
        {
            try { if (_cell != null) _cell.Dispose(); } catch { }
            try { if (_portal != null) _portal.Dispose(); } catch { }
            _cell = _portal = null; _opened = false;
            _blocks.Clear(); _dungeons.Clear();
        }

        // ── the height table (Region 0x13000000: id, number, version, name, then LandDefs ... 256 heights) ──
        private static float[] ReadHeightTable()
        {
            float[] t = null;
            try
            {
                byte[] b = _portal == null ? null : _portal.Get(0x13000000);
                if (b != null)
                {
                    int p = 12;
                    int len = BitConverter.ToUInt16(b, p); p += 2;
                    p += len;
                    p = (p + 3) & ~3;                    // aligned to 4
                    p += 4 + 4 + 4 + 4 + 4 + 4 + 4 + 4;  // block length / width, square length, lblock length, vertex per cell, max obj height, sky height, road width
                    t = new float[256];
                    for (int i = 0; i < 256; i++) t[i] = BitConverter.ToSingle(b, p + i * 4);
                    for (int i = 1; i < 256; i++) if (t[i] < t[i - 1] || t[i] > 10000 || float.IsNaN(t[i])) { t = null; break; }
                    if (t != null && t[255] < 100) t = null;
                }
            }
            catch { t = null; }
            if (t == null)
            {
                Error = "Couldn't read the game's height table - using a guess.";
                t = new float[256];
                for (int i = 0; i < 256; i++) t[i] = i * 2f;
            }
            return t;
        }

        // ── landblocks (the ground) ──
        private class Block { public ushort[] Terrain = new ushort[81]; public float[] H = new float[81]; public bool Ok; }
        private static readonly Dictionary<int, Block> _blocks = new Dictionary<int, Block>();

        private static Block Get(int lbx, int lby)
        {
            int key = (lbx << 8) | lby;
            Block b;
            if (_blocks.TryGetValue(key, out b)) return b;
            b = new Block();
            try
            {
                byte[] d = _cell == null || lbx < 0 || lby < 0 || lbx > 254 || lby > 254 ? null : _cell.Get((uint)((lbx << 24) | (lby << 16) | 0xFFFF));
                if (d != null && d.Length >= 8 + 162 + 81)
                {
                    for (int i = 0; i < 81; i++) { b.Terrain[i] = BitConverter.ToUInt16(d, 8 + i * 2); b.H[i] = _heights[d[8 + 162 + i]]; }
                    b.Ok = true;
                }
            }
            catch { }
            if (_blocks.Count > 6000) _blocks.Clear();
            _blocks[key] = b;
            return b;
        }

        private static int Idx(int x, int y) { return IndexXMajor ? x * 9 + y : y * 9 + x; }

        /// <summary>A landblock's 81 ground words (x * 9 + y: road bits, type, scene type), or null.</summary>
        public static ushort[] TerrainWords(int lbx, int lby)
        {
            if (!Open()) return null;
            Block b = Get(lbx, lby);
            if (!b.Ok) return null;
            if (IndexXMajor) return b.Terrain;
            ushort[] t = new ushort[81];
            for (int x = 0; x < 9; x++) for (int y = 0; y < 9; y++) t[x * 9 + y] = b.Terrain[y * 9 + x];
            return t;
        }

        /// <summary>A ground vertex's height (x, y 0..8 in the landblock).</summary>
        public static float VertexHeight(int lbx, int lby, int x, int y)
        {
            Block b = Get(lbx, lby);
            return b.Ok ? b.H[Idx(Math.Min(8, x), Math.Min(8, y))] : 0;
        }

        /// <summary>A file from client_cell_1.dat (a landblock's info: id 0xXXYYFFFE), or null.</summary>
        public static byte[] CellFile(uint id) { try { return Open() && _cell != null ? _cell.Get(id) : null; } catch { return null; } }

        /// <summary>A vertex of the ground: global vertex coordinates (8 per landblock, 0..2040).</summary>
        private static bool Vertex(int vx, int vy, out float h, out int type)
        {
            int lbx = vx / 8, lby = vy / 8, x = vx % 8, y = vy % 8;
            if (lbx > 254) { lbx = 254; x = 8; }
            if (lby > 254) { lby = 254; y = 8; }
            Block b = Get(lbx, lby);
            if (!b.Ok) { h = 0; type = -1; return false; }
            int i = Idx(x, y);
            h = b.H[i];
            type = (b.Terrain[i] >> 2) & 0x1F;
            return true;
        }

        // Water you can't walk into: the server (ACE's EntirelyWater) only stops you in a landblock that's water all through -
        // every one of its 81 ground corners water (0x10-0x14): the open sea, a great lake. Water in a landblock with any land
        // in it is waded, deep or not (the deep-sea corners alone put the edge a block or two short of the real one).
        private static readonly Dictionary<int, bool> _allWater = new Dictionary<int, bool>();
        private static bool BlockAllWater(int gx, int gy)
        {
            int lbx = Math.Min(254, gx / 8), lby = Math.Min(254, gy / 8), key = (lbx << 8) | lby;
            bool w;
            if (_allWater.TryGetValue(key, out w)) return w;
            Block b = Get(lbx, lby);
            w = b.Ok;
            if (w)
                for (int i = 0; i < 81 && w; i++) { int t = (b.Terrain[i] >> 2) & 0x1F; if (t < 0x10 || t > 0x14) w = false; }
            _allWater[key] = w;
            return w;
        }

        private static double Nz(double ax, double ay, double ah, double bx, double by, double bh, double cx, double cy, double ch)
        {
            double ux = bx - ax, uy = by - ay, uz = bh - ah, vx = cx - ax, vy = cy - ay, vz = ch - ah;
            double nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
            double len = Math.Sqrt(nx * nx + ny * ny + nz * nz);
            return len == 0 ? 1 : Math.Abs(nz) / len;
        }

        private static readonly Dictionary<int, bool> _walk = new Dictionary<int, bool>();

        /// <summary>Can you walk on this ground cell (24 m square; global cell coordinates 0..2039)? Not deep sea, not too steep -
        /// either way the square's split into triangles.</summary>
        public static bool Walkable(int gx, int gy)
        {
            if (gx < 0 || gy < 0 || gx > 2039 || gy > 2039) return false;
            int key = (gx << 12) | gy;
            bool w;
            if (_walk.TryGetValue(key, out w)) return w;
            float h00, h10, h01, h11; int t00, t10, t01, t11;
            w = Vertex(gx, gy, out h00, out t00) & Vertex(gx + 1, gy, out h10, out t10) & Vertex(gx, gy + 1, out h01, out t01) & Vertex(gx + 1, gy + 1, out h11, out t11);
            if (w)
            {
                if (BlockAllWater(gx, gy)) w = false;
                else
                {
                    const double S = 24;
                    double a = Nz(0, 0, h00, S, 0, h10, S, S, h11), b = Nz(0, 0, h00, S, S, h11, 0, S, h01);   // split SW-NE
                    double c = Nz(0, 0, h00, S, 0, h10, 0, S, h01), d = Nz(S, 0, h10, S, S, h11, 0, S, h01);   // split SE-NW
                    w = SWtoNE(gx, gy) ? (a >= FloorZ && b >= FloorZ) : (c >= FloorZ && d >= FloorZ);   // the game's own cut
                }
            }
            if (_walk.Count > 400000) _walk.Clear();
            _walk[key] = w;
            return w;
        }

        public static void ForgetWalkable() { _walk.Clear(); _tri.Clear(); _allWater.Clear(); }

        /// <summary>How the game splits a ground cell into its two triangles (global cell coordinates): true = the cut
        /// runs SW-NE, false = SE-NW. (The client's own formula, as in ACE's LandblockStruct.ConstructPolygons.)</summary>
        public static bool SWtoNE(int gx, int gy)
        {
            uint X = (uint)gx, Y = (uint)gy;
            uint split = unchecked(Y * (X * 214614067u + 1813693831u) - X * 1109124029u - 1369149221u);
            return split * 2.3283064e-10 >= 0.5;
        }

        /// <summary>The ground triangle under a point (world metres, the landblock grid's own: x east, y north) is too steep to
        /// walk on, or deep sea. The real triangle - not the whole 24 m cell (a cliff is one triangle, the floor of a pit
        /// beside it the other).</summary>
        public static bool SteepAt(double wx, double wy)
        {
            int gx = (int)Math.Floor(wx / 24.0), gy = (int)Math.Floor(wy / 24.0);
            if (gx < 0 || gy < 0 || gx > 2039 || gy > 2039) return true;
            int key = (gx << 12) | gy;
            byte m;
            if (!_tri.TryGetValue(key, out m))
            {
                m = 4;
                float h00, h10, h01, h11; int t00, t10, t01, t11;
                if (!(Vertex(gx, gy, out h00, out t00) & Vertex(gx + 1, gy, out h10, out t10) & Vertex(gx, gy + 1, out h01, out t01) & Vertex(gx + 1, gy + 1, out h11, out t11))) m |= 3;
                else
                {
                    const double S = 24;
                    bool a, b, sea = BlockAllWater(gx, gy);
                    if (SWtoNE(gx, gy))
                    {
                        a = Nz(0, 0, h00, S, 0, h10, S, S, h11) < FloorZ || sea;
                        b = Nz(0, 0, h00, S, S, h11, 0, S, h01) < FloorZ || sea;
                    }
                    else
                    {
                        a = Nz(0, 0, h00, S, 0, h10, 0, S, h01) < FloorZ || sea;
                        b = Nz(S, 0, h10, S, S, h11, 0, S, h01) < FloorZ || sea;
                    }
                    if (a) m |= 1;
                    if (b) m |= 2;
                }
                if (_tri.Count > 400000) _tri.Clear();
                _tri[key] = m;
            }
            double lx = wx - gx * 24.0, ly = wy - gy * 24.0;
            bool first = SWtoNE(gx, gy) ? lx >= ly : lx + ly <= 24.0;   // which of its two triangles
            return (m & (first ? 1 : 2)) != 0;
        }
        private static readonly Dictionary<int, byte> _tri = new Dictionary<int, byte>();

        /// <summary>Triangle k (0: on the cell's south edge, 1: on its north edge) of cell (gx, gy) can be walked on.</summary>
        public static bool TriWalkable(int gx, int gy, int k)
        {
            double cx, cy; TriCenter(gx, gy, k, out cx, out cy);
            return !SteepAt(cx, cy);
        }

        /// <summary>The middle of triangle k of cell (gx, gy), world metres.</summary>
        public static void TriCenter(int gx, int gy, int k, out double x, out double y)
        {
            bool sw = SWtoNE(gx, gy);
            double lx, ly;
            if (sw) { lx = k == 0 ? 16 : 8; ly = k == 0 ? 8 : 16; }
            else { lx = k == 0 ? 8 : 16; ly = k == 0 ? 8 : 16; }
            x = gx * 24.0 + lx; y = gy * 24.0 + ly;
        }

        /// <summary>The triangles sharing an edge with triangle k of cell (gx, gy): {gx, gy, k} each (up to 3).</summary>
        public static int TriNeighbours(int gx, int gy, int k, int[] outXYK)
        {
            int m = 0;
            outXYK[m * 3] = gx; outXYK[m * 3 + 1] = gy; outXYK[m * 3 + 2] = k ^ 1; m++;   // across the diagonal
            bool sw = SWtoNE(gx, gy);
            if (k == 0)
            {
                if (gy > 0) { outXYK[m * 3] = gx; outXYK[m * 3 + 1] = gy - 1; outXYK[m * 3 + 2] = 1; m++; }
                if (sw) { if (gx + 1 < 2040) { outXYK[m * 3] = gx + 1; outXYK[m * 3 + 1] = gy; outXYK[m * 3 + 2] = SWtoNE(gx + 1, gy) == false ? 0 : 1; m++; } }
                else { if (gx > 0) { outXYK[m * 3] = gx - 1; outXYK[m * 3 + 1] = gy; outXYK[m * 3 + 2] = SWtoNE(gx - 1, gy) == true ? 0 : 1; m++; } }
            }
            else
            {
                if (gy + 1 < 2040) { outXYK[m * 3] = gx; outXYK[m * 3 + 1] = gy + 1; outXYK[m * 3 + 2] = 0; m++; }
                if (sw) { if (gx > 0) { outXYK[m * 3] = gx - 1; outXYK[m * 3 + 1] = gy; outXYK[m * 3 + 2] = SWtoNE(gx - 1, gy) == true ? 0 : 1; m++; } }
                else { if (gx + 1 < 2040) { outXYK[m * 3] = gx + 1; outXYK[m * 3 + 1] = gy; outXYK[m * 3 + 2] = SWtoNE(gx + 1, gy) == false ? 0 : 1; m++; } }
            }
            return m;
        }

        /// <summary>Some of the cell can be walked on (one of its two real triangles) - for the rough 24 m search, whose
        /// route the 0.5 m pass then fits to the triangles themselves.</summary>
        public static bool PartWalkable(int gx, int gy)
        {
            if (Walkable(gx, gy)) return true;
            double x0 = gx * 24.0, y0 = gy * 24.0;
            bool sw = SWtoNE(gx, gy);
            // a point well inside each triangle
            return sw ? (!SteepAt(x0 + 16, y0 + 8) || !SteepAt(x0 + 8, y0 + 16)) : (!SteepAt(x0 + 8, y0 + 8) || !SteepAt(x0 + 16, y0 + 16));
        }

        // ── areas on foot: the whole map's walkable ground cells, numbered by which ones join up ──
        // An island, a valley sealed by cliffs or deep sea, ... each gets its own number; you can only run between places
        // with the same number. Made on a background thread at login (a second or two), from the game's map file.
        private const int GN = 2040;
        private static volatile ushort[] _region;
        public static bool RegionsReady { get { return _region != null; } }
        public static int RegionCount;
        public static string RegionError = "";
        private static bool _regionStarted;

        public static void EnsureRegions()
        {
            if (_regionStarted) return;
            _regionStarted = true;
            _released = false;
            if (!Open()) return;
            float[] table = _heights;
            bool xMajor = IndexXMajor;
            string dat = Path.Combine(GameDir, "client_cell_1.dat");
            System.Threading.Thread t = new System.Threading.Thread(() =>
            {
                try
                {
                    const int VN = GN + 1;
                    byte[] hb = new byte[VN * VN];
                    byte[] deep = new byte[VN * VN];
                    byte[] ty = new byte[VN * VN];   // the ground's type (5 bits) and road (bit 5) - for the world map's picture
                    using (DatFile d = new DatFile(dat))
                    {
                        for (int lbx = 0; lbx < 255; lbx++)
                            for (int lby = 0; lby < 255; lby++)
                            {
                                byte[] lb = d.Get((uint)((lbx << 24) | (lby << 16) | 0xFFFF));
                                if (lb == null || lb.Length < 8 + 162 + 81) continue;
                                for (int x = 0; x <= 8; x++)
                                    for (int y = 0; y <= 8; y++)
                                    {
                                        int vx = lbx * 8 + x, vy = lby * 8 + y;
                                        if (vx > GN || vy > GN) continue;
                                        int i = xMajor ? x * 9 + y : y * 9 + x;
                                        hb[vx * VN + vy] = lb[8 + 162 + i];
                                        ushort tt = BitConverter.ToUInt16(lb, 8 + i * 2);
                                        deep[vx * VN + vy] = (byte)(((tt >> 2) & 0x1F) == 0x14 ? 1 : 0);
                                        ty[vx * VN + vy] = (byte)(((tt >> 2) & 0x1F) | ((tt & 3) != 0 ? 0x20 : 0));
                                    }
                            }
                    }
                    // walkable ground, triangle by triangle (each 24 m cell is the game's two triangles: [cell*2] the one on its
                    // south edge, [cell*2+1] the one on its north edge) - a cliff is one triangle, a ramp beside it the other
                    byte[] walk = new byte[GN * GN * 2];
                    const double S = 24;
                    for (int gx = 0; gx < GN; gx++)
                        for (int gy = 0; gy < GN; gy++)
                        {
                            int v = gx * VN + gy;
                            double h00 = table[hb[v]], h10 = table[hb[v + VN]], h01 = table[hb[v + 1]], h11 = table[hb[v + VN + 1]];
                            int d00 = deep[v], d10 = deep[v + VN], d01 = deep[v + 1], d11 = deep[v + VN + 1];
                            bool w0, w1;
                            if (SWtoNE(gx, gy))
                            {
                                w0 = Nz(0, 0, h00, S, 0, h10, S, S, h11) >= FloorZ && d00 + d10 + d11 < 2;
                                w1 = Nz(0, 0, h00, S, S, h11, 0, S, h01) >= FloorZ && d00 + d11 + d01 < 2;
                            }
                            else
                            {
                                w0 = Nz(0, 0, h00, S, 0, h10, 0, S, h01) >= FloorZ && d00 + d10 + d01 < 2;
                                w1 = Nz(S, 0, h10, S, S, h11, 0, S, h01) >= FloorZ && d10 + d11 + d01 < 2;
                            }
                            int c2 = (gx * GN + gy) * 2;
                            if (w0) walk[c2] = 1;
                            if (w1) walk[c2 + 1] = 1;
                        }
                    if (_released) return;   // MelksQB stopped meanwhile
#if !ACGODOT
                    // (retail: the world map's picture is made here; ACGodot draws its own map)
                    try { WorldImage = Picture(hb, ty, table); } catch (Exception ex) { WorldImageError = ex.Message; }
                    if (_released) { try { WorldImage.Dispose(); } catch { } WorldImage = null; return; }
#endif
                    if (_released) { WorldImage = null; return; }
                    hb = null; deep = null; ty = null;
                    // number the joined-up areas: triangles joined across their shared edges (the cell's diagonal, and each
                    // side to the next cell's triangle on that side). Tiny scraps past 65534 aren't numbered (0 = unknown).
                    ushort[] reg = new ushort[GN * GN * 2];
                    int[] q = new int[1 << 20];
                    int next = 0;
                    int[] nb = new int[3];
                    for (int s0 = 0; s0 < GN * GN * 2; s0++)
                    {
                        if (walk[s0] != 1) continue;
                        ushort id = next < 65534 ? (ushort)(++next) : (ushort)0;
                        int head = 0, tail = 0;
                        walk[s0] = 2; reg[s0] = id; q[tail++ & (q.Length - 1)] = s0;
                        while (head != tail)
                        {
                            int tri = q[head++ & (q.Length - 1)];
                            int cell = tri >> 1, k = tri & 1, cx = cell / GN, cy = cell % GN;
                            bool sw = SWtoNE(cx, cy);
                            int m = 0;
                            nb[m++] = tri ^ 1;   // the other half of the cell, across the diagonal
                            if (k == 0)
                            {
                                if (cy > 0) nb[m++] = ((cx * GN + cy - 1) * 2) + 1;                       // south edge: the cell below's north triangle
                                if (sw) { if (cx + 1 < GN) nb[m++] = TriOnSide(cx + 1, cy, false); }      // east edge
                                else { if (cx > 0) nb[m++] = TriOnSide(cx - 1, cy, true); }               // west edge
                            }
                            else
                            {
                                if (cy + 1 < GN) nb[m++] = (cx * GN + cy + 1) * 2;                         // north edge: the cell above's south triangle
                                if (sw) { if (cx > 0) nb[m++] = TriOnSide(cx - 1, cy, true); }            // west edge
                                else { if (cx + 1 < GN) nb[m++] = TriOnSide(cx + 1, cy, false); }         // east edge
                            }
                            for (int i = 0; i < m; i++)
                            {
                                int n = nb[i];
                                if (walk[n] != 1) continue;
                                walk[n] = 2; reg[n] = id;
                                if (tail - head >= q.Length - 1)
                                {
                                    int[] q2 = new int[q.Length * 2];
                                    for (int j = 0; j < tail - head; j++) q2[j] = q[(head + j) & (q.Length - 1)];
                                    tail -= head; head = 0; q = q2;
                                }
                                q[tail++ & (q.Length - 1)] = n;
                            }
                        }
                    }
                    {
                        int[] sz = new int[next + 1];
                        for (int i = 0; i < reg.Length; i++) if (reg[i] != 0) sz[reg[i]]++;
                        _regionTris = sz;
                    }
                    RegionCount = next;
                    if (_released) return;
                    _region = reg;
                }
                catch (Exception ex) { RegionError = ex.Message; Util.LogError(ex); }
            });
            t.IsBackground = true;
            t.Priority = System.Threading.ThreadPriority.BelowNormal;
            t.Start();
        }

        /// <summary>The world map's picture, made from the game's own ground (one pixel = 24 m, north up): set once it's made.</summary>
#if ACGODOT
        public static volatile object WorldImage;   // (ACGodot: the map's picture is ACGodot's own map - not made here)
#else
        public static volatile System.Drawing.Bitmap WorldImage;

        // the picture: each 24 m cell its ground's colour, shaded for the slope (lit from the north-west)
        private static System.Drawing.Bitmap Picture(byte[] hb, byte[] ty, float[] table)
        {
            const int VN = GN + 1, N = ImageSize;
            System.Drawing.Bitmap bmp = new System.Drawing.Bitmap(N, N, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
            System.Drawing.Imaging.BitmapData bd = bmp.LockBits(new System.Drawing.Rectangle(0, 0, N, N), System.Drawing.Imaging.ImageLockMode.WriteOnly, bmp.PixelFormat);
            int[] row = new int[N];
            try
            {
                for (int py = 0; py < N; py++)
                {
                    int gy = N - 1 - py;
                    for (int gx = 0; gx < N; gx++)
                    {
                        int v = gx * VN + gy;
                        int t = ty[v];
                        int c = (t & 0x20) != 0 && (t & 0x1F) < 0x10 ? 0xA8946C : Palette[t & 0x1F];
                        // hill shading: lit from the north-west
                        double h00 = table[hb[v]], h10 = table[hb[v + VN]], h01 = table[hb[v + 1]], h11 = table[hb[v + VN + 1]];
                        double dzdx = ((h10 + h11) - (h00 + h01)) / 48.0, dzdy = ((h01 + h11) - (h00 + h10)) / 48.0;
                        double shade = 1.0 + (-dzdx * 0.7 + dzdy * 0.7) * 1.6;
                        if ((t & 0x1F) >= 0x10 && (t & 0x1F) <= 0x14) shade = 1.0;   // water is flat
                        shade = Math.Max(0.55, Math.Min(1.35, shade));
                        int r = Math.Min(255, (int)(((c >> 16) & 0xFF) * shade)), g = Math.Min(255, (int)(((c >> 8) & 0xFF) * shade)), b = Math.Min(255, (int)((c & 0xFF) * shade));
                        row[gx] = unchecked((int)0xFF000000) | (r << 16) | (g << 8) | b;
                    }
                    System.Runtime.InteropServices.Marshal.Copy(row, 0, new IntPtr(bd.Scan0.ToInt64() + (long)py * bd.Stride), N);
                }
            }
            finally { bmp.UnlockBits(bd); }
            return bmp;
        }
#endif
        public static string WorldImageError = "";
        public const int ImageSize = 2040;   // pixels a side: EW = x / 10 - 101.95, NS = (2040 - y) / 10 - 101.95

        private static readonly int[] Palette =
        {
            0x786E64, 0x608C3C, 0xC8DCEB, 0x46822D, 0x55693C, 0x6E5537, 0x2D2832, 0x967D5A,   // rock, grass, ice, lush grass, marsh, mud, obsidian, packed dirt
            0x8C7855, 0x738C4B, 0xD7C382, 0xAFAA9B, 0xA59678, 0x827364, 0x877D69, 0xF0F0F5,   // patchy dirt, patchy grass, sand, grey sand, rocky sand, sediment, semi-barren, snow
            0x4678B4, 0x4673AA, 0x508CBE, 0x4B82B4, 0x192D5F, 0x6E6E64, 0x6E6E64, 0x6E6E64,   // running water, fresh, shallow sea, still sea, DEEP SEA, ...
            0x6E6E64, 0x6E6E64, 0x6E6E64, 0x6E6E64, 0x6E6E64, 0x6E6E64, 0x6E6E64, 0x6E6E64,
        };

        /// <summary>The triangle of cell (gx, gy) on its east side (east = true) or west side.</summary>
        private static int TriOnSide(int gx, int gy, bool east)
        {
            int c2 = (gx * GN + gy) * 2;
            // SW-NE cut: the south triangle has the east side; SE-NW cut: the south triangle has the west side
            return SWtoNE(gx, gy) == east ? c2 : c2 + 1;
        }

        /// <summary>Which area on foot a place is in (0 = not known: the map isn't ready, or nothing walkable near it).</summary>
        public static int Region(Coords c)
        {
            ushort[] reg = _region;
            if (reg == null || !c.Valid) return 0;
            double wx = (c.EW + 101.95) * 240.0, wy = (c.NS + 101.95) * 240.0;
            int gx = (int)Math.Floor(wx / 24.0), gy = (int)Math.Floor(wy / 24.0);
            if (gx >= 0 && gy >= 0 && gx < GN && gy < GN)
            {
                double lx = wx - gx * 24.0, ly = wy - gy * 24.0;
                bool first = SWtoNE(gx, gy) ? lx >= ly : lx + ly <= 24.0;
                ushort v0 = reg[(gx * GN + gy) * 2 + (first ? 0 : 1)];
                if (v0 != 0) return v0;
            }
            for (int r = 0; r <= 2; r++)
                for (int dx = -r; dx <= r; dx++)
                    for (int dy = -r; dy <= r; dy++)
                    {
                        if (Math.Max(Math.Abs(dx), Math.Abs(dy)) != r) continue;
                        int x = gx + dx, y = gy + dy;
                        if (x < 0 || y < 0 || x >= GN || y >= GN) continue;
                        ushort v = reg[(x * GN + y) * 2];
                        if (v != 0) return v;
                        v = reg[(x * GN + y) * 2 + 1];
                        if (v != 0) return v;
                    }
            return 0;
        }

        private static volatile int[] _regionTris;   // triangles in each area on foot
        public static int RegionSize(int id)
        {
            int[] sz = _regionTris;
            if (sz == null || id <= 0 || id >= sz.Length) return 0;
            return (sz[id] + 1) / 2;   // (triangles: two to a cell)
        }

        // ── the sea you can't walk into (whole landblocks of water), for the whole map: one bit every 48 m (1020 x 1020), for the route finder ──
        // Made once from the game's map file on a background thread (a few seconds) and kept in Travel\sea.bin.
        private const int SeaN = 1020;
        private static volatile byte[] _sea;
        private static bool _seaStarted;
        public static bool SeaReady { get { return _sea != null; } }

        public static void EnsureSea()
        {
            if (_seaStarted) return;
            _seaStarted = true;
            string file = Util.FullPath(System.IO.Path.Combine("Travel", "sea2.bin"));   // (sea2: the server's rule - see BlockAllWater)
            try
            {
                if (File.Exists(file))
                {
                    byte[] b = File.ReadAllBytes(file);
                    if (b.Length == SeaN * SeaN / 8) { _sea = b; return; }
                }
            }
            catch { }
            string dat = Path.Combine(GameDir, "client_cell_1.dat");
            System.Threading.Thread t = new System.Threading.Thread(() =>
            {
                try
                {
                    byte[] bits = new byte[SeaN * SeaN / 8];
                    using (DatFile d = new DatFile(dat))   // its own reader: nothing shared with the game thread
                    {
                        for (int lbx = 0; lbx < 255; lbx++)
                            for (int lby = 0; lby < 255; lby++)
                            {
                                byte[] lb = d.Get((uint)((lbx << 24) | (lby << 16) | 0xFFFF));
                                if (lb == null || lb.Length < 8 + 162) continue;
                                // (a landblock that's water all through - every corner - can't be walked into; any land in it and
                                // its water is waded)
                                bool all = true;
                                for (int v = 0; v < 81 && all; v++)
                                {
                                    int type = (BitConverter.ToUInt16(lb, 8 + v * 2) >> 2) & 0x1F;
                                    if (type < 0x10 || type > 0x14) all = false;
                                }
                                if (!all) continue;
                                for (int x = 0; x < 4; x++)
                                    for (int y = 0; y < 4; y++)
                                    {
                                        int i = (lbx * 4 + x) * SeaN + lby * 4 + y;
                                        bits[i >> 3] |= (byte)(1 << (i & 7));
                                    }
                            }
                    }
                    try { Directory.CreateDirectory(Path.GetDirectoryName(file)); File.WriteAllBytes(file, bits); } catch { }
                    _sea = bits;
                }
                catch (Exception ex) { Util.LogError(ex); }
            });
            t.IsBackground = true;
            t.Priority = System.Threading.ThreadPriority.BelowNormal;
            t.Start();
        }

        private static bool DeepAt(byte[] sea, double ns, double ew)
        {
            int x = (int)Math.Floor((ew + 101.95) * 5.0), y = (int)Math.Floor((ns + 101.95) * 5.0);   // 240 m a unit / 48 m
            if (x < 0 || y < 0 || x >= SeaN || y >= SeaN) return true;
            int i = x * SeaN + y;
            return (sea[i >> 3] & (1 << (i & 7))) != 0;
        }

        /// <summary>The straight line between two places goes over deep sea (false while the sea map isn't ready yet).</summary>
        public static bool SeaBetween(Coords a, Coords b)
        {
            byte[] sea = _sea;
            if (sea == null || !a.Valid || !b.Valid) return false;
            int n = (int)Math.Ceiling(a.DistanceTo(b) / 0.2);
            for (int i = 1; i < n; i++)
            {
                double f = (double)i / n;
                if (DeepAt(sea, a.NS + (b.NS - a.NS) * f, a.EW + (b.EW - a.EW) * f)) return true;
            }
            return false;
        }

        /// <summary>The ground's height at map coordinates (metres), NaN if unknown.</summary>
        public static double GroundZ(Coords c)
        {
            if (!Open() || !c.Valid) return double.NaN;
            double gxm = (c.EW + 101.95) * 240.0, gym = (c.NS + 101.95) * 240.0;
            int gx = (int)Math.Floor(gxm / 24), gy = (int)Math.Floor(gym / 24);
            double fx = (gxm - gx * 24) / 24, fy = (gym - gy * 24) / 24;
            float h00, h10, h01, h11; int t;
            if (!(Vertex(gx, gy, out h00, out t) & Vertex(gx + 1, gy, out h10, out t) & Vertex(gx, gy + 1, out h01, out t) & Vertex(gx + 1, gy + 1, out h11, out t))) return double.NaN;
            return h00 * (1 - fx) * (1 - fy) + h10 * fx * (1 - fy) + h01 * (1 - fx) * fy + h11 * fx * fy;
        }

        public static void ResetBlocks() { _blocks.Clear(); _walk.Clear(); }

        // which way round the dat's 9x9 heights go: checked against where you stand (outdoors), a few times
        private static double _errX, _errY;
        private static int _samples;
        public static void Calibrate(Coords c, double z)
        {
            if (_samples >= 6 || !c.Valid || double.IsNaN(z) || !Open()) return;
            bool keep = IndexXMajor;
            IndexXMajor = true; _blocks.Clear(); double a = GroundZ(c);
            IndexXMajor = false; _blocks.Clear(); double b = GroundZ(c);
            IndexXMajor = keep; _blocks.Clear();
            if (double.IsNaN(a) || double.IsNaN(b)) return;
            _errX += Math.Abs(a - z); _errY += Math.Abs(b - z); _samples++;
            if (_samples == 6)
            {
                bool want = _errX <= _errY;
                if (want != IndexXMajor) { IndexXMajor = want; ResetBlocks(); }
                Calibration = "height check: " + (_errX / 6).ToString("0.0") + " m off one way, " + (_errY / 6).ToString("0.0") + " m the other - using " + (IndexXMajor ? "x-major" : "y-major");
            }
        }
        public static string Calibration = "";

        // ── dungeons ──
        private static readonly Dictionary<int, Dictionary<uint, DCell>> _dungeons = new Dictionary<int, Dictionary<uint, DCell>>();

        /// <summary>A dungeon's cells (null if it has none).</summary>
        /// <summary>A landblock with rooms (cells) but no buildings: a dungeon or hub of its own (the QB Penthouse, out in the
        /// sea), not a house's or tower's insides.</summary>
        private static readonly Dictionary<int, bool> _noBld = new Dictionary<int, bool>();
        public static bool CellsNoBuildings(int lb)
        {
            bool r;
            if (_noBld.TryGetValue(lb, out r)) return r;
            r = false;
            try
            {
                if (Open())
                {
                    byte[] info = _cell.Get((uint)((lb << 16) | 0xFFFE));
                    if (info != null && info.Length >= 12)
                    {
                        uint cells = BitConverter.ToUInt32(info, 4), objs = BitConverter.ToUInt32(info, 8);
                        long at = 12 + objs * 32L;   // each: id + frame (7 floats)
                        if (cells > 0 && cells < 5000 && at + 2 <= info.Length) r = BitConverter.ToUInt16(info, (int)at) == 0;
                    }
                }
            }
            catch { r = false; }
            _noBld[lb] = r;
            return r;
        }

        public static Dictionary<uint, DCell> Dungeon(int lb)
        {
            Dictionary<uint, DCell> d;
            if (_dungeons.TryGetValue(lb, out d)) return d;
            d = null;
            try
            {
                if (Open())
                {
                    byte[] info = _cell.Get((uint)((lb << 16) | 0xFFFE));
                    uint n = info != null && info.Length >= 8 ? BitConverter.ToUInt32(info, 4) : 0;
                    if (n > 0 && n < 5000)
                    {
                        d = new Dictionary<uint, DCell>();
                        for (uint i = 0; i < n; i++)
                        {
                            uint id = (uint)(lb << 16) | (0x100 + i);
                            DCell c = ReadCell(_cell.Get(id), id);
                            if (c != null) d[id] = c;
                        }
                    }
                }
            }
            catch (Exception ex) { Util.LogError(ex); d = null; }
            _dungeons[lb] = d;
            return d;
        }

        private static DCell ReadCell(byte[] e, uint id)
        {
            if (e == null || e.Length < 20) return null;
            using (BinaryReader r = new BinaryReader(new MemoryStream(e)))
            {
                r.ReadUInt32();
                uint flags = r.ReadUInt32();
                r.ReadUInt32();                 // the id again
                byte ns = r.ReadByte(), np = r.ReadByte();
                ushort nv = r.ReadUInt16();     // visible cells
                for (int i = 0; i < ns; i++) r.ReadUInt16();
                ushort env = r.ReadUInt16(), st = r.ReadUInt16();
                DCell c = new DCell { Id = id, Env = env, Struct = st, X = r.ReadSingle(), Y = r.ReadSingle(), Z = r.ReadSingle() };
                c.QW = r.ReadSingle(); c.QX = r.ReadSingle(); c.QY = r.ReadSingle(); c.QZ = r.ReadSingle();
                for (int i = 0; i < np; i++)
                {
                    r.ReadUInt16();
                    ushort poly = r.ReadUInt16();
                    ushort other = r.ReadUInt16();
                    r.ReadUInt16();
                    if (other != 0xFFFF) { c.Next.Add((id & 0xFFFF0000) | other); c.NextPoly.Add(poly); }
                }
                try
                {
                    for (int i = 0; i < nv; i++) r.ReadUInt16();
                    if ((flags & 2) != 0)
                    {
                        uint cnt = r.ReadUInt32();
                        for (uint i = 0; i < cnt && i < 500 && r.BaseStream.Position + 32 <= e.Length; i++)
                        {
                            r.ReadUInt32();   // the model
                            float sx = r.ReadSingle(), sy = r.ReadSingle(), sz = r.ReadSingle();
                            r.ReadSingle(); r.ReadSingle(); r.ReadSingle(); r.ReadSingle();
                            c.Statics.Add(new[] { sx, sy, sz });
                        }
                    }
                }
                catch { }
                return c;
            }
        }

        /// <summary>A file from client_portal.dat (null if it can't be read).</summary>
        public static byte[] PortalFile(uint id)
        {
            try { return Open() && _portal != null ? _portal.Get(id) : null; } catch { return null; }
        }

        public static Coords CellCoords(uint cellId, double x, double y)
        {
            int lbx = (int)(cellId >> 24), lby = (int)((cellId >> 16) & 0xFF);
            return new Coords((lby * 192 + y) / 240.0 - 101.95, (lbx * 192 + x) / 240.0 - 101.95);
        }
    }
}
