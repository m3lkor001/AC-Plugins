using System;
using System.Collections.Generic;
using ImGuiNET;
using Vec2 = System.Numerics.Vector2;
using Vec4 = System.Numerics.Vector4;

namespace MelksQuestTracker.Travel
{
    /// <summary>The Travel tab: where to (coordinates or a place's name), the route, and what you can travel with.</summary>
    internal static class TravelPage
    {
        private static string _text = "";
        private static string _found = null;
        private static List<Loc> _results = new List<Loc>();
        // the preview: the route it would take to the typed coordinates, or the place clicked in the list
        private static Loc _picked;
        private static Route _preview;
        private static string _previewKey = "";
        private static DateTime _previewAt = DateTime.MinValue;

        public static void Draw(float w, float h)
        {
            if (!ImGui.BeginChild("##travel", new Vec2(w, h), true)) { ImGui.EndChild(); return; }
            try { Body(w); }
            catch (Exception ex) { Util.LogError(ex); }
            ImGui.EndChild();
        }

        private static void Body(float w)
        {
            if (TravelData.LoadError.Length > 0) Im.TextColored(TravelHud.Orange, TravelData.LoadError);

            // the maps
            if (ImGui.SmallButton(WorldView.Visible ? "Hide world map##tvwm" : "Show world map##tvwm")) WorldView.Toggle();
            ImGui.SameLine();
            if (ImGui.SmallButton(DungeonView.Visible ? "Hide dungeon map##tvdm" : "Show dungeon map##tvdm")) { if (DungeonView.Visible) DungeonView.Hide(); else DungeonView.Show(); }
            if (ImGui.IsItemHovered()) Im.SetTooltip("The live map of the dungeon you're in, drawn from the game's files (you, the portals, the route).");
            ImGui.SameLine();
            {
                uint cell = Travel.Cell();
                string hex = (cell & 0xFFFF) >= 0x100 ? (cell >> 16).ToString("X4") : "";
                string acId = hex.Length > 0 ? DungeonView.MapIdFor((int)(cell >> 16), Travel.DungeonInst((int)(cell >> 16))) : null;
                bool has = acId != null;
                if (has) hex = acId;
                if (!has) ImGui.BeginDisabled();
                if (ImGui.SmallButton(MapView.Showing == hex && has ? "Hide ACMaps dungeon map##tvam" : "Show ACMaps dungeon map##tvam"))
                {
                    if (MapView.Showing == hex) MapView.Hide(); else MapView.Show(hex);
                }
                if (!has) ImGui.EndDisabled();
                if (ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenDisabled))
                    Im.SetTooltip(has ? "The ACMaps picture of this dungeon (" + hex + ")." : hex.Length == 0 ? "You're not in a dungeon." : "No ACMaps picture for this dungeon (" + hex + ").");
            }

            Im.Text("Go to:");
            ImGui.SameLine();
            ImGui.SetNextItemWidth(330);
            bool enter = ImGui.InputText("##tvto", ref _text, 200, ImGuiInputTextFlags.EnterReturnsTrue);
            if (ImGui.IsItemHovered()) Im.SetTooltip("Coordinates (33.6N, 56.8E) or part of a place's name.\nEnter: go there.");
            ImGui.SameLine();
            if (ImGui.Button("Route##tvr") || enter) Travel.Go(_text, enter ? 0 : 1);
            ImGui.SameLine();
            if (ImGui.Button("Arrow##tva")) Travel.Go(_text, 2);
            ImGui.SameLine();
            if (ImGui.Button("Where am I##tvw")) Travel.Run("loc");
            Im.TextDisabled("Clicking coordinates in chat or on a quest's page goes there too (" + (Travel.RouteMode ? "route" : "arrow only") + " - set on the Config tab).");

            // places by name, as you type
            string t = _text.Trim();
            if (t != _found)
            {
                _found = t;
                Coords c;
                _results = t.Length < 2 || Coords.TryParse(t, out c) ? new List<Loc>() : TravelData.Find(t, 40);
                _picked = _results.Count > 0 ? _results[0] : null;
            }
            if (_results.Count > 0)
            {
                float hh = Math.Min(200, 24 + _results.Count * ImGui.GetTextLineHeightWithSpacing());
                if (ImGui.BeginTable("##tvres", 4, ImGuiTableFlags.RowBg | ImGuiTableFlags.ScrollY | ImGuiTableFlags.SizingFixedFit, new Vec2(w - 20, hh)))
                {
                    ImGui.TableSetupColumn("Place", ImGuiTableColumnFlags.WidthStretch);
                    ImGui.TableSetupColumn("Type", ImGuiTableColumnFlags.WidthFixed, 120);
                    ImGui.TableSetupColumn("Where", ImGuiTableColumnFlags.WidthFixed, 110);
                    ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 110);
                    for (int i = 0; i < _results.Count; i++)
                    {
                        Loc l = _results[i];
                        ImGui.TableNextRow();
                        ImGui.TableSetColumnIndex(0);
                        if (ImGui.Selectable(l.Name + "##tvsel" + i, l == _picked)) _picked = l;
                        if (ImGui.IsItemHovered()) Im.SetTooltip((l.Notes.Length > 400 ? l.Notes.Substring(0, 400) + "..." : l.Notes) + (l.Notes.Length > 0 ? "\n\n" : "") + "Click: show the route to it below");
                        ImGui.TableSetColumnIndex(1);
                        Im.TextDisabled(l.Learned && l.Type == "Portal" ? "Portal (seen)" : l.Type);
                        ImGui.TableSetColumnIndex(2);
                        Im.Text(l.At.ToString());
                        ImGui.TableSetColumnIndex(3);
                        if (ImGui.SmallButton("Route##tvrr" + i)) Travel.GoTo(l.At, l.Area, l.Name, 1);
                        ImGui.SameLine();
                        if (ImGui.SmallButton("Arrow##tvra" + i)) Travel.GoTo(l.At, l.Area, l.Name, 2);
                    }
                    ImGui.EndTable();
                }
            }

            DrawPreview(w);

            ImGui.Separator();
            if (Travel.Active)
            {
                Im.TextColored(TravelHud.Cyan, (Travel.ArrowOnly ? "Arrow to " : "Route to ") + Travel.DestName + " (" + Travel.DestAt + ")");
                ImGui.SameLine();
                if (ImGui.SmallButton(TravelHud.Visible ? "Hide window##tvhw" : "Show window##tvhw")) { if (TravelHud.Visible) TravelHud.Hide(); else TravelHud.Show(); }
                ImGui.SameLine();
                if (ImGui.SmallButton(AutoTravel.On ? "Auto travel: ON##tvap" : "Auto travel##tvap")) AutoTravel.Toggle();
                ImGui.SameLine();
                if (!Travel.ArrowOnly && ImGui.SmallButton("Reroute##tvrp")) Travel.Reroute(true, true);
                if (!Travel.ArrowOnly) ImGui.SameLine();
                if (ImGui.SmallButton("Stop##tvsp")) Travel.Clear();
                if (!string.IsNullOrEmpty(Travel.Note)) Im.TextColored(TravelHud.Orange, Travel.Note);
                if (AutoTravel.On && AutoTravel.Status.Length > 0) Im.TextDisabled("Walking: " + AutoTravel.Status);
                if (!Travel.ArrowOnly) TravelHud.DrawSteps(w - 40);
            }
            else Im.TextDisabled("No destination.");

            ImGui.Separator();
            if (ImGui.CollapsingHeader("What you can travel with##tvwith", ImGuiTreeNodeFlags.DefaultOpen)) DrawStarts(w);
            if (ImGui.CollapsingHeader("Portals##tvlearn")) DrawLearned();
            if (ImGui.CollapsingHeader("The game's map##tvmap")) DrawMap();
        }

        /// <summary>The route it would take to what's typed / picked - worked out again every few seconds (you move, gems change).</summary>
        private static void DrawPreview(float w)
        {
            string t = _text.Trim();
            Coords c; int area; string name;
            if (Coords.TryParse(t, out c)) { area = TravelData.AreaOfCoords(c); name = c.ToString(); }
            else if (_picked != null && _results.Contains(_picked)) { c = _picked.At; area = _picked.Area; name = _picked.Name; }
            else return;
            string key = c.Raw() + "|" + name;
            if (key != _previewKey || (DateTime.Now - _previewAt).TotalSeconds > 5 || TravelData.NeedRebuild)
            {
                _previewKey = key; _previewAt = DateTime.Now;
                _preview = Travel.Preview(c, area, name);
            }
            ImGui.Separator();
            Im.TextColored(TravelHud.Cyan, "The route to " + name + (name == c.ToString() ? "" : " (" + c + ")") + ":");
            ImGui.SameLine();
            if (ImGui.SmallButton("Go##tvpgo")) Travel.GoTo(c, area, name, 1);
            ImGui.SameLine();
            if (ImGui.SmallButton("Auto travel##tvpauto")) { Travel.GoTo(c, area, name, 1); AutoTravel.Start(); }
            if (_preview == null) { Im.TextColored(TravelHud.Orange, "No route from here - no portals, recalls or gems known that get there (an arrow would point straight at it)."); return; }
            if (_preview.Legs.Count == 0) { Im.TextDisabled("You're there."); return; }
            TravelHud.DrawRoute(_preview, name, c, w - 40);
        }

        private static void DrawStarts(float w)
        {
            Im.TextDisabled("Where a recall, gem or command lands is learned the first time you use it (and kept for every character).");
            Im.TextDisabled(MelkTankGems.List() != null ? "Gems: the ones in your pack that are on this character's MelkTank Portals tab list." : "Gems: anything in your pack named like a portal gem (MelkTank isn't here).");
            if (!ImGui.BeginTable("##tvstarts", 4, ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit, new Vec2(w - 20, 0))) return;
            ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 50);
            ImGui.TableSetupColumn("Name", ImGuiTableColumnFlags.WidthStretch);
            ImGui.TableSetupColumn("Lands at", ImGuiTableColumnFlags.WidthFixed, 230);
            ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 60);
            int row = 0;
            foreach (KeyValuePair<int, string> sp in Travel.RecallSpells()) StartRow("Spell", "spell", sp.Value, ref row);
            foreach (KeyValuePair<string, int> g in Travel.Gems()) StartRow("Gem", "gem", g.Key, ref row);
            foreach (StartOpt c in new List<StartOpt>(TravelData.CharStarts.Values)) if (c.Kind == "cmd") StartRow("Typed", "cmd", c.Name, ref row);
            ImGui.EndTable();
            if (row == 0) Im.TextDisabled("No recall spells, portal gems or travel commands found yet.");
        }

        private static void StartRow(string what, string kind, string name, ref int row)
        {
            StartOpt k = Travel.Known(kind, name);
            ImGui.TableNextRow();
            ImGui.TableSetColumnIndex(0);
            Im.TextDisabled(what);
            ImGui.TableSetColumnIndex(1);
            Im.Text(name);
            ImGui.TableSetColumnIndex(2);
            if (k == null || !k.Exit.Valid) Im.TextColored(TravelHud.Grey, "not known yet - use it once");
            else
            {
                string ki = TravelData.Inst(k);
                Im.Text(k.Exit + TravelData.InstLabel(ki) + (k.ExitArea >= 0 ? " (" + TravelData.AreaName(k.ExitArea, ki) + ")" : ""));
                if (ki.Length > 0 && !ki.StartsWith("v") && ImGui.IsItemHovered()) Im.SetTooltip("Lands in " + ki + " - a walled-off copy at Tou-Tou's coordinates, not Tou-Tou itself.\nRoutes use it only for places on that copy's map (the world map's Tier 11+ view); /location there says which copy.");
                if (ImGui.IsItemHovered()) Im.SetTooltip(k.Ticks == 0 ? "Built-in guess - corrected the first time you use it." : (k.PerChar ? "This character's." : "Learned in the game (every character)."));
            }
            ImGui.TableSetColumnIndex(3);
            if (k != null && k.Ticks > 0 && ImGui.SmallButton("Forget##tvf" + row)) TravelData.ForgetStart(k);
            row++;
        }

        private static float _wallR = 1.5f;
        private static string _wallName = "";

        private static void DrawMap()
        {
            bool ok = WorldMap.Open();
            Im.Text(ok ? "Reading the ground and the dungeons from " + System.IO.Path.Combine(WorldMap.GameDir, "client_cell_1.dat") : "Can't read the game's map file.");
            if (WorldMap.Error.Length > 0) Im.TextColored(TravelHud.Orange, WorldMap.Error);
            Coords h = Travel.Here();
            if (ok && h.Valid && Travel.HereArea() < 0)
            {
                if ((Travel.Cell() & 0xFFFF) >= 0x100) Im.TextDisabled("You're inside a building - the height check needs you outdoors.");
                else
                {
                    double gz = WorldMap.GroundZ(h), mz = Travel.HereZ();
                    Im.Text("Ground here by the map: " + gz.ToString("0.0") + " m, you: " + mz.ToString("0.0") + " m" + (Math.Abs(gz - mz) < 2.5 ? "  (matches)" : "  (doesn't match - standing on something?)"));
                }
                TravelData.Wall wl = TravelData.WallAt(h);
                if (wl != null)
                {
                    Im.TextColored(TravelHud.Cyan, "Walled-in area" + (wl.Name.Length > 0 ? " \"" + wl.Name + "\"" : "") + ": " + wl.R.ToString("0.0") + " around " + wl.At + " - routes only use portals in and out.");
                    ImGui.SameLine();
                    if (ImGui.SmallButton("Not walled in##tvwr")) TravelData.RemoveWall(wl);
                }
                else
                {
                    if (ImGui.SmallButton("This area is walled in (portals only)##tvwa")) TravelData.AddWall(_wallName.Trim(), h, _wallR);
                    if (ImGui.IsItemHovered()) Im.SetTooltip("For places you can't walk into or out of (the T11+ zones): routes won't plan a run across the edge.\nEverything within the size below, around where you stand, counts.");
                    ImGui.SameLine(); ImGui.SetNextItemWidth(70); ImGui.InputFloat("size##tvwsz", ref _wallR, 0.5f, 1f, "%.1f"); _wallR = Math.Max(0.2f, Math.Min(10f, _wallR));
                    ImGui.SameLine(); ImGui.SetNextItemWidth(160); ImGui.InputText("name##tvwn", ref _wallName, 60);
                    Im.TextDisabled("(size in map units: 1.0 = 240 m - make it cover the zone, but not the land outside its walls)");
                }
                if (WorldMap.RegionsReady)
                {
                    int rg = WorldMap.Region(h);
                    Im.TextDisabled(rg == 0 ? "Area on foot here: not known (no walkable ground right here)." :
                        "Area on foot here: #" + rg + " - " + (WorldMap.RegionSize(rg) * 0.0576).ToString("0.#") + " km2 you can walk round without a portal.");
                }
            }
            Im.TextDisabled(WorldMap.SeaReady ? "Deep sea map ready (routes don't run across the ocean or the inland sea)." : "Deep sea map: being made...");
            Im.TextDisabled(WorldMap.RegionsReady ? "Areas on foot: " + WorldMap.RegionCount + " (places sealed off by cliffs or deep sea aren't run between)." :
                WorldMap.RegionError.Length > 0 ? "Areas on foot: couldn't be made - " + WorldMap.RegionError : "Areas on foot: being worked out...");
            if (WorldMap.Calibration.Length > 0) Im.TextDisabled(WorldMap.Calibration);
            if (PathPlan.Last.Length > 0) Im.TextDisabled("Last path: " + PathPlan.Last);
        }

        // ── the portals: every one the route finder knows ──
        private static List<Loc> _portals = new List<Loc>();
        private static int _portalsVersion = -1, _sortCol = -1;   // -1: destination not known first, then by name
        private static bool _sortDesc, _unknownOnly, _avoidedOnly;
        private static string _pFilter = "", _pFilterWas = null;

        private static string LeadsTo(Loc l)
        {
            if (!l.HasExit) return "";
            string li = TravelData.Inst(l);
            return l.Exit + TravelData.InstLabel(li) + (l.ExitArea >= 0 ? " (" + TravelData.AreaName(l.ExitArea, li) + " " + TravelData.LbLabel(l.ExitArea, li) + ")" : "");
        }

        private static string WhereAt(Loc l) { return l.At + (l.Area >= 0 ? " (" + TravelData.AreaName(l.Area, l.In) + " " + TravelData.LbLabel(l.Area, l.In) + ")" : ""); }

        private static int Compare(Loc x, Loc y)
        {
            int c;
            switch (_sortCol)
            {
                case 0: c = TravelData.Avoid.Contains(x.Key).CompareTo(TravelData.Avoid.Contains(y.Key)); break;
                case 6: c = TravelData.Random.Contains(y.Key).CompareTo(TravelData.Random.Contains(x.Key)); break;
                case 7: c = TravelData.Moves(y.Name).CompareTo(TravelData.Moves(x.Name)); break;
                case 2: c = x.At.NS != y.At.NS ? y.At.NS.CompareTo(x.At.NS) : x.At.EW.CompareTo(y.At.EW); break;
                case 3: c = x.HasExit.CompareTo(y.HasExit); break;   // not known first, then by name
                case 4: c = x.Learned.CompareTo(y.Learned); break;
                case 5: c = x.MinLevel.CompareTo(y.MinLevel); break;
                case 1: c = 0; break;
                default: c = x.HasExit.CompareTo(y.HasExit); break;   // not known first
            }
            if (_sortDesc) c = -c;
            if (c == 0) c = string.Compare(x.Name, y.Name, StringComparison.OrdinalIgnoreCase) * (_sortCol == 1 && _sortDesc ? -1 : 1);
            return c;
        }

        private static void RefreshPortals()
        {
            List<Loc> l = new List<Loc>();
            string f = _pFilter.Trim().ToLowerInvariant();
            foreach (Loc x in TravelData.Locs)
            {
                if (!x.HasExit && !TravelData.IsPortalType(x.Type)) continue;
                if (_unknownOnly && x.HasExit) continue;
                if (_avoidedOnly && !TravelData.Avoid.Contains(x.Key)) continue;
                if (f.Length > 0 && x.Name.ToLowerInvariant().IndexOf(f, StringComparison.Ordinal) < 0 && LeadsTo(x).ToLowerInvariant().IndexOf(f, StringComparison.Ordinal) < 0) continue;
                l.Add(x);
            }
            l.Sort(Compare);
            _portals = l;
            _portalsVersion = TravelData.Version;
            _pFilterWas = _pFilter;
        }

        private static unsafe void DrawLearned()
        {
            int known = 0, unknown = 0, seen = 0;
            foreach (Loc l in TravelData.Locs)
            {
                if (!l.HasExit && !TravelData.IsPortalType(l.Type)) continue;
                if (l.HasExit) known++; else unknown++;
                if (l.Learned) seen++;
            }
            Im.Text(known + " portals with a known destination, " + unknown + " without (go through one, or walk past it, to learn it); " + seen + " checked in the game.");
            Im.TextDisabled("Untick a portal and routes won't use it. Click a column's name to sort by it.");
            bool refresh = _portalsVersion != TravelData.Version || _pFilterWas != _pFilter;
            ImGui.SetNextItemWidth(220);
            ImGui.InputText("find##tvpf", ref _pFilter, 80);
            ImGui.SameLine();
            if (ImGui.Checkbox("destination not known##tvpu", ref _unknownOnly)) refresh = true;
            ImGui.SameLine();
            if (ImGui.Checkbox("not used##tvpa", ref _avoidedOnly)) refresh = true;
            ImGui.SameLine();
            Im.TextDisabled(_portals.Count + " shown");

            ImGuiTableFlags fl = ImGuiTableFlags.RowBg | ImGuiTableFlags.ScrollY | ImGuiTableFlags.Sortable | ImGuiTableFlags.Resizable |
                                 ImGuiTableFlags.BordersInnerV | ImGuiTableFlags.SizingFixedFit;
            if (!ImGui.BeginTable("##tvportals", 8, fl, new Vec2(0, 330))) { if (refresh) RefreshPortals(); return; }
            ImGui.TableSetupScrollFreeze(0, 1);
            ImGui.TableSetupColumn("Use", ImGuiTableColumnFlags.WidthFixed, 34);
            ImGui.TableSetupColumn("Portal", ImGuiTableColumnFlags.WidthStretch);
            ImGui.TableSetupColumn("Where it is", ImGuiTableColumnFlags.WidthFixed, 150);
            ImGui.TableSetupColumn("Leads to", ImGuiTableColumnFlags.WidthFixed | ImGuiTableColumnFlags.DefaultSort, 200);
            ImGui.TableSetupColumn("From", ImGuiTableColumnFlags.WidthFixed, 50);
            ImGui.TableSetupColumn("Level", ImGuiTableColumnFlags.WidthFixed, 60);
            ImGui.TableSetupColumn("Random", ImGuiTableColumnFlags.WidthFixed, 56);
            ImGui.TableSetupColumn("Moves", ImGuiTableColumnFlags.WidthFixed, 50);
            ImGui.TableHeadersRow();
            ImGuiTableSortSpecsPtr ss = ImGui.TableGetSortSpecs();
            if (ss.NativePtr != null && ss.SpecsDirty)
            {
                if (ss.SpecsCount > 0) { _sortCol = ss.Specs.ColumnIndex; _sortDesc = ss.Specs.SortDirection == ImGuiSortDirection.Descending; }
                ss.SpecsDirty = false;
                refresh = true;
            }
            if (refresh) RefreshPortals();

            ImGuiListClipperPtr clip = new ImGuiListClipperPtr(ImGuiNative.ImGuiListClipper_ImGuiListClipper());
            clip.Begin(_portals.Count);
            Loc toggled = null, randomed = null, moved = null; bool toggledTo = false, randomTo = false, movedTo = false;
            while (clip.Step())
            {
                for (int i = clip.DisplayStart; i < clip.DisplayEnd && i < _portals.Count; i++)
                {
                    Loc l = _portals[i];
                    ImGui.TableNextRow();
                    ImGui.TableSetColumnIndex(0);
                    bool use = !TravelData.Avoid.Contains(l.Key);
                    if (ImGui.Checkbox("##tvpu" + i, ref use)) { toggled = l; toggledTo = use; }
                    ImGui.TableSetColumnIndex(1);
                    Im.Text(l.Name);
                    if (ImGui.IsItemHovered() && l.Notes.Length > 0) Im.SetTooltip(l.Notes.Length > 400 ? l.Notes.Substring(0, 400) + "..." : l.Notes);
                    ImGui.TableSetColumnIndex(2);
                    // a link, like coordinates in chat: click = go there; right-click = show it on the world map
                    ImGui.PushStyleColor(ImGuiCol.Text, new Vec4(0.45f, 0.75f, 1f, 1f));
                    if (ImGui.Selectable(WhereAt(l) + "##tvpw" + i, false)) Travel.GoTo(l.At, l.Area, l.Name, 0);
                    ImGui.PopStyleColor();
                    if (ImGui.IsItemClicked(ImGuiMouseButton.Right)) WorldView.ShowAt(l.At);
                    if (ImGui.IsItemHovered()) Im.SetTooltip("Click: go there (" + l.At + ")\nRight-click: show it on the world map");
                    ImGui.TableSetColumnIndex(3);
                    if (l.HasExit) Im.Text(LeadsTo(l));
                    else Im.TextColored(TravelHud.Orange, "not known");
                    ImGui.TableSetColumnIndex(4);
                    Im.TextDisabled(l.Learned ? "game" : "list");
                    if (ImGui.IsItemHovered()) Im.SetTooltip(l.Learned ? "Seen or used in the game - its coordinates and destination are the game's own." : "From the travel list (GoArrow's) - not checked in the game yet.");
                    ImGui.TableSetColumnIndex(5);
                    if (l.MinLevel > 0 || l.MaxLevel > 0) Im.TextDisabled((l.MinLevel > 0 ? l.MinLevel.ToString() : "") + (l.MaxLevel > 0 ? "-" + l.MaxLevel : "+"));
                    ImGui.TableSetColumnIndex(6);
                    bool rnd = TravelData.Random.Contains(l.Key);
                    if (ImGui.Checkbox("##tvpr" + i, ref rnd)) { randomed = l; randomTo = rnd; }
                    if (ImGui.IsItemHovered()) Im.SetTooltip("Goes somewhere different each time - routes don't use it");
                    ImGui.TableSetColumnIndex(7);
                    bool mv = TravelData.Moves(l.Name);
                    if (ImGui.Checkbox("##tvpm" + i, ref mv)) { moved = l; movedTo = mv; }
                    if (ImGui.IsItemHovered()) Im.SetTooltip("Turns up in different places (Cow Level, Thieves' Parlor) - every portal with this name.\nOnly the spot it was last seen is kept; routes use it only within " + TravelData.MovesFreshMin.ToString("0") + " minutes of it being seen there.");
                }
            }
            clip.End();
            clip.Destroy();
            ImGui.EndTable();
            if (toggled != null) { TravelData.SetAvoid(toggled.Key, !toggledTo); _portalsVersion = -1; if (Travel.Active) Travel.Reroute(false); }
            if (moved != null) { TravelData.SetMoves(moved.Name, movedTo); _portalsVersion = -1; if (Travel.Active) Travel.Reroute(false); }
            if (randomed != null) { TravelData.SetRandom(randomed.Key, randomTo); _portalsVersion = -1; if (Travel.Active) Travel.Reroute(false); }
        }
    }
}
