using System;
using System.Collections.Generic;
using System.IO;
using ACGodot.DecalShim;

namespace MelksQuestTracker.Travel;

internal static class AcMapsCore
{
	public class CellD
	{
		public double X;

		public double Y;

		public double Z;

		public int Lv;

		public List<float[]> F;
	}

	public class Found
	{
		public int Kind;

		public int Px;

		public int Py;

		public double X;

		public double Y;

		public double Z;

		public bool Placed;

		public float Score;
	}

	private class Match
	{
		public double Score;

		public double S;

		public double OX;

		public double OY;

		public int Li;

		public Comp P;
	}

	private class Comp
	{
		public List<int> Pix = new List<int>();

		public int X0 = int.MaxValue;

		public int Y0 = int.MaxValue;

		public int X1;

		public int Y1;

		public int Cx;

		public int Cy;

		public int N => Pix.Count;

		public int W => X1 - X0 + 1;

		public int H => Y1 - Y0 + 1;

		public bool Any(bool[] m)
		{
			foreach (int item in Pix)
			{
				if (m[item])
				{
					return true;
				}
			}
			return false;
		}

		public bool[] Sub()
		{
			bool[] array = new bool[W * H];
			foreach (int item in Pix)
			{
				array[(item / AcMapsCore.W - Y0) * W + item % AcMapsCore.W - X0] = true;
			}
			return array;
		}
	}

	public const int Door = 0;

	public const int Gate = 1;

	public const int Lever = 2;

	public const int Chest = 3;

	public const int Locked = 4;

	public const int Exit = 5;

	public const int Start = 6;

	public const int Spawn = 7;

	private const double G = 4.0;

	public static Action<string> Log;

	private static int W;

	private static int H;

	private static int[] _rgb;

	private static bool[] _room;

	private static bool[] _roomOk;

	private static bool[] _big;

	private static bool[] _near3;

	private static bool[] _near12;

	private static bool[] _dark;

	private static int[] _piece;

	private static bool[] _white;

	private static bool y0ok(int i, int fy0, int fy1, int fx0, int fx1)
	{
		int num = i % W;
		int num2 = i / W;
		return num2 >= fy0 && num2 < fy1 && num >= fx0 && num < fx1;
	}

	public static List<Found> Run(string file, List<CellD> cells, out string status)
	{
		List<Found> list = new List<Found>();
		byte[] array = Pictures.LoadRgba(file, out W, out H);
		if (array == null)
		{
			status = "Couldn't read " + Path.GetFileName(file) + ".";
			return list;
		}
		_rgb = new int[W * H];
		int num = 0;
		int num2 = 0;
		while (num < _rgb.Length)
		{
			_rgb[num] = (array[num2 + 3] << 24) | (array[num2] << 16) | (array[num2 + 1] << 8) | array[num2 + 2];
			num++;
			num2 += 4;
		}
		int num3 = W * H;
		bool[] array2 = new bool[num3];
		bool[] array3 = new bool[num3];
		bool[] array4 = new bool[num3];
		bool[] array5 = new bool[num3];
		bool[] array6 = new bool[num3];
		_dark = new bool[num3];
		_room = new bool[num3];
		for (int i = 0; i < num3; i++)
		{
			int num4 = _rgb[i];
			int num5 = (num4 >> 16) & 0xFF;
			int num6 = (num4 >> 8) & 0xFF;
			int num7 = num4 & 0xFF;
			array2[i] = num5 > 235 && num6 > 235 && num7 > 235;
			_dark[i] = num5 < 90 && num6 < 90 && num7 < 90;
			array3[i] = num7 > 180 && num5 < 90 && num6 < 90;
			array4[i] = num5 > 200 && num6 < 90 && num7 < 90;
			array5[i] = num5 > 200 && num7 > 200 && num6 < 90;
			array6[i] = num6 > 110 && num5 < 90 && num7 < 90;
			_room[i] = !array2[i] && !_dark[i] && !array3[i] && !array4[i] && !array5[i] && !array6[i];
		}
		int num8 = 0;
		int num9 = H;
		int num10 = 0;
		int num11 = W;
		for (int j = 0; j < H; j++)
		{
			int num12 = 0;
			for (int k = 0; k < W; k++)
			{
				if (_dark[j * W + k])
				{
					num12++;
				}
			}
			if ((double)num12 > (double)W * 0.7)
			{
				if ((double)j < (double)H * 0.2)
				{
					num8 = Math.Max(num8, j + 2);
				}
				else if ((double)j > (double)H * 0.7)
				{
					num9 = Math.Min(num9, j - 2);
				}
			}
		}
		for (int l = 0; l < W; l++)
		{
			int num13 = 0;
			for (int m = 0; m < H; m++)
			{
				if (_dark[m * W + l])
				{
					num13++;
				}
			}
			if ((double)num13 > (double)H * 0.7)
			{
				if ((double)l < (double)W * 0.2)
				{
					num10 = Math.Max(num10, l + 2);
				}
				else if ((double)l > (double)W * 0.8)
				{
					num11 = Math.Min(num11, l - 2);
				}
			}
		}
		bool[][] array7 = new bool[7][] { array2, array3, array4, array5, array6, _dark, _room };
		bool[][] array8 = array7;
		foreach (bool[] array9 in array8)
		{
			for (int num14 = 0; num14 < H; num14++)
			{
				for (int num15 = 0; num15 < W; num15++)
				{
					if (num14 < num8 || num14 >= num9 || num15 < num10 || num15 >= num11)
					{
						array9[num14 * W + num15] = false;
					}
				}
			}
		}
		bool[] array10 = new bool[num3];
		for (int num16 = 0; num16 < num3; num16++)
		{
			array10[num16] = !array2[num16] && y0ok(num16, num8, num9, num10, num11);
		}
		bool[] array11 = Erode(Dilate(_room, 2), 2);
		for (int num17 = 0; num17 < num3; num17++)
		{
			array11[num17] = array11[num17] && array10[num17];
		}
		_big = Dilate(Erode(array11, 2), 2);
		_white = array2;
		bool[] array12 = Dilate(_big, 4);
		_roomOk = new bool[num3];
		for (int num18 = 0; num18 < num3; num18++)
		{
			_roomOk[num18] = _room[num18] && array12[num18];
		}
		_near3 = Dilate(_big, 3);
		_near12 = Dilate(_big, 12);
		List<Found> list2 = new List<Found>();
		foreach (Comp item in Comps(array6))
		{
			if (item.N >= 8 && _near3[item.Cy * W + item.Cx])
			{
				list2.Add(new Found
				{
					Kind = 3,
					Px = item.Cx,
					Py = item.Cy
				});
			}
		}
		foreach (Comp item2 in Comps(array5))
		{
			if (item2.N >= 20 && _near3[item2.Cy * W + item2.Cx])
			{
				list2.Add(new Found
				{
					Kind = 5,
					Px = item2.Cx,
					Py = item2.Cy
				});
			}
		}
		foreach (Comp item3 in Comps(array4))
		{
			if (item3.Any(_near12))
			{
				int w = item3.W;
				int h = item3.H;
				if (w <= 5 && h <= 6 && Math.Abs(w - h) <= 1 && item3.N >= 5 && (double)item3.N >= 0.45 * (double)w * (double)h && _near3[item3.Cy * W + item3.Cx])
				{
					list2.Add(new Found
					{
						Kind = 7,
						Px = item3.Cx,
						Py = item3.Cy
					});
				}
				else if (w >= 7 && h <= 5 && item3.N >= 8)
				{
					list2.Add(new Found
					{
						Kind = 4,
						Px = item3.Cx,
						Py = item3.Cy
					});
				}
			}
		}
		foreach (Comp item4 in Comps(array3))
		{
			if (item4.Any(_near3))
			{
				if (item4.H >= 7 && item4.H <= 9 && item4.W >= 4 && item4.W <= 6 && IsLever(item4))
				{
					list2.Add(new Found
					{
						Kind = 2,
						Px = item4.Cx,
						Py = item4.Cy
					});
				}
				else if (item4.H >= 9 && item4.H <= 12 && item4.W >= 7 && item4.W <= 11 && item4.N >= 45 && _near3[item4.Cy * W + item4.Cx])
				{
					list2.Add(new Found
					{
						Kind = 6,
						Px = item4.Cx,
						Py = item4.Cy
					});
				}
			}
		}
		Doors(list2);
		if (Log != null)
		{
			foreach (Found item5 in list2)
			{
				Log("icon " + item5.Kind + " " + item5.Px + "," + item5.Py);
			}
		}
		_piece = new int[num3];
		List<Comp> list3 = new List<Comp>();
		foreach (Comp item6 in Comps(_big))
		{
			if (item6.N < 300)
			{
				continue;
			}
			list3.Add(item6);
			foreach (int item7 in item6.Pix)
			{
				_piece[item7] = list3.Count;
			}
		}
		double num19 = double.MaxValue;
		double num20 = double.MinValue;
		double num21 = double.MaxValue;
		double num22 = double.MinValue;
		foreach (CellD cell in cells)
		{
			num19 = Math.Min(num19, cell.X - 6.0);
			num20 = Math.Max(num20, cell.X + 6.0);
			num21 = Math.Min(num21, cell.Y - 6.0);
			num22 = Math.Max(num22, cell.Y + 6.0);
			if (cell.F == null)
			{
				continue;
			}
			foreach (float[] item8 in cell.F)
			{
				if (item8[0] == 0f)
				{
					for (int num23 = 1; num23 + 1 < item8.Length; num23 += 2)
					{
						num19 = Math.Min(num19, item8[num23]);
						num20 = Math.Max(num20, item8[num23]);
						num21 = Math.Min(num21, item8[num23 + 1]);
						num22 = Math.Max(num22, item8[num23 + 1]);
					}
				}
			}
		}
		num19 -= 30.0;
		num21 -= 30.0;
		num20 += 30.0;
		num22 += 30.0;
		int num24 = (int)Math.Ceiling(num20 - num19);
		int num25 = (int)Math.Ceiling(num22 - num21);
		SortedSet<int> sortedSet = new SortedSet<int>();
		foreach (CellD cell2 in cells)
		{
			sortedSet.Add(cell2.Lv);
		}
		List<int> list4 = new List<int>(sortedSet);
		list4.Add(int.MinValue);
		List<int[]> list5 = new List<int[]>();
		foreach (int item9 in list4)
		{
			int[] array13 = new int[num24 * num25];
			for (int num26 = 0; num26 < cells.Count; num26++)
			{
				CellD cellD = cells[num26];
				if (item9 != int.MinValue && cellD.Lv != item9)
				{
					continue;
				}
				bool flag = false;
				if (cellD.F != null)
				{
					foreach (float[] item10 in cellD.F)
					{
						if (item10[0] == 0f)
						{
							Fill(array13, num24, num25, item10, num19, num22, num26 + 1);
							flag = true;
						}
					}
				}
				if (!flag)
				{
					Fill(array13, num24, num25, new float[9]
					{
						0f,
						(float)cellD.X - 5f,
						(float)cellD.Y - 5f,
						(float)cellD.X + 5f,
						(float)cellD.Y - 5f,
						(float)cellD.X + 5f,
						(float)cellD.Y + 5f,
						(float)cellD.X - 5f,
						(float)cellD.Y + 5f
					}, num19, num22, num26 + 1);
				}
			}
			list5.Add(array13);
		}
		int num27 = (int)Math.Ceiling((double)num24 / 4.0);
		int num28 = (int)Math.Ceiling((double)num25 / 4.0);
		int num29 = 0;
		foreach (Comp item11 in list3)
		{
			num29 = Math.Max(num29, Math.Max(item11.W, item11.H));
		}
		int num30 = Math.Max(num27, num28) + (int)Math.Ceiling((double)num29 / 6.0) + 2;
		int num31;
		for (num31 = 16; num31 < num30; num31 *= 2)
		{
		}
		List<double[]> list6 = new List<double[]>();
		List<double[]> list7 = new List<double[]>();
		foreach (int[] item12 in list5)
		{
			double[] array14 = new double[num31 * num31];
			double[] array15 = new double[num31 * num31];
			for (int num32 = 0; num32 < num28; num32++)
			{
				for (int num33 = 0; num33 < num27; num33++)
				{
					int num34 = 0;
					int num35 = 0;
					for (int num36 = (int)((double)num32 * 4.0); num36 < Math.Min(num25, (int)((double)(num32 + 1) * 4.0)); num36++)
					{
						for (int num37 = (int)((double)num33 * 4.0); num37 < Math.Min(num24, (int)((double)(num33 + 1) * 4.0)); num37++)
						{
							num35++;
							if (item12[num36 * num24 + num37] != 0)
							{
								num34++;
							}
						}
					}
					array14[num32 * num31 + num33] = ((num35 == 0) ? (-1.0) : (2.0 * (double)num34 / (double)num35 - 1.0));
				}
			}
			Fft2(array14, array15, num31, inv: false);
			list6.Add(array14);
			list7.Add(array15);
		}
		list3.Sort((Comp a, Comp c) => c.N.CompareTo(a.N));
		Match[] array16 = new Match[list3.Count + 1];
		double num38 = 0.0;
		int num39 = 0;
		double val = 0.0;
		for (int num40 = 0; num40 < list3.Count; num40++)
		{
			Comp comp = list3[num40];
			List<double> list8 = new List<double>();
			if (num40 == 0)
			{
				for (double num41 = 1.5; num41 <= 4.51; num41 += 0.1)
				{
					list8.Add(num41);
				}
			}
			else
			{
				for (double num42 = num38 - 0.1; num42 <= num38 + 0.101; num42 += 0.05)
				{
					list8.Add(num42);
				}
			}
			Match match = null;
			foreach (double item13 in list8)
			{
				double num43 = 4.0 * item13;
				int num44 = (int)Math.Ceiling((double)comp.W / num43);
				int num45 = (int)Math.Ceiling((double)comp.H / num43);
				if (num44 >= num31 || num45 >= num31)
				{
					continue;
				}
				double[] array17 = new double[num31 * num31];
				double[] array18 = new double[num31 * num31];
				PieceGrid(comp, num43, num44, num45, array17, num31);
				double num46 = num44 * num45;
				if (num46 < 3.0)
				{
					continue;
				}
				Fft2(array17, array18, num31, inv: false);
				for (int num47 = 0; num47 < list4.Count; num47++)
				{
					double[] array19 = new double[num31 * num31];
					double[] array20 = new double[num31 * num31];
					double[] array21 = list6[num47];
					double[] array22 = list7[num47];
					for (int num48 = 0; num48 < array19.Length; num48++)
					{
						array19[num48] = array21[num48] * array17[num48] + array22[num48] * array18[num48];
						array20[num48] = array22[num48] * array17[num48] - array21[num48] * array18[num48];
					}
					Fft2(array19, array20, num31, inv: true);
					for (int num49 = -num45 + 1; num49 < num28; num49++)
					{
						for (int num50 = -num44 + 1; num50 < num27; num50++)
						{
							double num51 = array19[(num49 + num31) % num31 * num31 + (num50 + num31) % num31] / num46;
							if (match == null || num51 > match.Score || (num47 == match.Li && false))
							{
								match = new Match
								{
									Score = num51,
									S = item13,
									OX = (double)num50 * 4.0,
									OY = (double)num49 * 4.0,
									Li = num47
								};
							}
						}
					}
				}
			}
			if (match != null)
			{
				match = Fine(comp, match, list5, num24, num25, list4.Count);
				if (Log != null)
				{
					Log("piece " + num40 + " n=" + comp.N + " at " + comp.X0 + "," + comp.Y0 + " " + comp.W + "x" + comp.H + " s=" + match.S.ToString("0.00") + " score=" + match.Score.ToString("0.00") + " lv=" + match.Li + " off=" + match.OX + "," + match.OY);
				}
				if (num40 == 0)
				{
					num38 = match.S;
				}
				val = Math.Max(val, match.Score);
				if (!(match.Score < 0.12))
				{
					array16[_piece[comp.Pix[0]]] = match;
					match.P = comp;
					num39++;
				}
			}
		}
		Dictionary<int, Dictionary<int, int[]>> cache = new Dictionary<int, Dictionary<int, int[]>>();
		foreach (Found item14 in list2)
		{
			int num52 = PieceNear(item14.Px, item14.Py, 20);
			if (num52 == 0 || array16[num52] == null)
			{
				continue;
			}
			Match match2 = array16[num52];
			double num53 = num19 + match2.OX + (double)(item14.Px - match2.P.X0) / match2.S;
			double num54 = num22 - (match2.OY + (double)(item14.Py - match2.P.Y0) / match2.S);
			int[] id = list5[match2.Li];
			double num55 = double.MinValue;
			double num56 = num53;
			double num57 = num54;
			num56 = num53;
			num57 = num54;
			int[][] array23 = new int[3][]
			{
				new int[4] { 70, 44, 4, 3 },
				new int[4] { 36, 10, 2, 2 },
				new int[4] { 16, 3, 1, 1 }
			};
			int[][] array24 = array23;
			foreach (int[] array25 in array24)
			{
				double num59 = Local(item14.Px, item14.Py, match2.S, id, num24, num25, num19, num22, array25[0], array25[1], array25[2], array25[3], ref num56, ref num57);
				num55 = num59;
			}
			item14.X = num56;
			item14.Y = num57;
			item14.Score = (float)num55;
			int num60 = match2.Li;
			if (list4[num60] == int.MinValue && list4.Count > 2)
			{
				int shade = ShadeAt(item14.Px, item14.Py);
				int num61 = ShadeLevel(cache, match2, num52, shade, list5, list4, num24, num25, num19, num22);
				if (num61 >= 0)
				{
					num60 = num61;
				}
			}
			int num62 = Snap(list5[num60], num24, num25, num19, num22, ref item14.X, ref item14.Y, 8);
			if (num62 == 0 && num60 != match2.Li)
			{
				num62 = Snap(list5[match2.Li], num24, num25, num19, num22, ref item14.X, ref item14.Y, 8);
			}
			if (num62 != 0)
			{
				item14.Z = cells[num62 - 1].Z;
				item14.Placed = true;
				list.Add(item14);
			}
		}
		List<Found> list9 = new List<Found>();
		foreach (Found item15 in list)
		{
			bool flag2 = false;
			foreach (Found item16 in list9)
			{
				if (item16.Kind == item15.Kind && Math.Abs(item16.Z - item15.Z) < 3.0 && (item16.X - item15.X) * (item16.X - item15.X) + (item16.Y - item15.Y) * (item16.Y - item15.Y) < 6.25)
				{
					flag2 = true;
					break;
				}
			}
			if (!flag2)
			{
				list9.Add(item15);
			}
		}
		status = "Matched " + num39 + " of " + list3.Count + " parts of the picture (best fit " + val.ToString("0.00") + "), scale " + num38.ToString("0.00") + " px/m; " + list9.Count + " things placed (" + list2.Count + " found).";
		return list9;
	}

	private static Match Fine(Comp p, Match m, List<int[]> ids, int RW, int RH, int nl)
	{
		Match result = m;
		double num = double.MinValue;
		for (int i = 0; i < nl; i++)
		{
			int[] array = ids[i];
			for (double num2 = m.S - 0.08; num2 <= m.S + 0.081; num2 += 0.02)
			{
				int num3 = (int)Math.Ceiling((double)p.W / num2);
				int num4 = (int)Math.Ceiling((double)p.H / num2);
				double[] array2 = new double[num3 * num4];
				PieceGrid(p, 1.0 * num2, num3, num4, array2, num3);
				double num5 = num3 * num4;
				List<int> list = new List<int>();
				for (int j = 0; j < array2.Length; j++)
				{
					if (Math.Abs(array2[j]) > 0.05)
					{
						list.Add(j);
					}
				}
				if (list.Count < 1)
				{
					continue;
				}
				for (int k = (int)m.OY - 6; k <= (int)m.OY + 6; k++)
				{
					for (int l = (int)m.OX - 6; l <= (int)m.OX + 6; l++)
					{
						double num6 = 0.0;
						foreach (int item in list)
						{
							int num7 = l + item % num3;
							int num8 = k + item / num3;
							bool flag = num7 >= 0 && num8 >= 0 && num7 < RW && num8 < RH && array[num8 * RW + num7] != 0;
							num6 += (flag ? array2[item] : (0.0 - array2[item]));
						}
						num6 /= num5;
						double num9 = ((i == nl - 1) ? (num6 - 0.03) : num6);
						if (num9 > num)
						{
							num = num9;
							result = new Match
							{
								Score = num6,
								S = num2,
								OX = l,
								OY = k,
								Li = i
							};
						}
					}
				}
			}
		}
		return result;
	}

	private static void PieceGrid(Comp p, double bs, int pw, int ph, double[] g, int stride)
	{
		int num = _piece[p.Pix[0]];
		double[] array = new double[pw * ph];
		for (int i = p.Y0; i <= p.Y1; i++)
		{
			for (int j = p.X0; j <= p.X1; j++)
			{
				int num2 = (int)((double)(j - p.X0) / bs);
				int num3 = (int)((double)(i - p.Y0) / bs);
				if (num2 < pw && num3 < ph)
				{
					int num4 = i * W + j;
					int num5 = num3 * pw + num2;
					array[num5]++;
					if (_piece[num4] == num)
					{
						g[num3 * stride + num2]++;
					}
					else if (_white[num4])
					{
						g[num3 * stride + num2]--;
					}
				}
			}
		}
		for (int k = 0; k < ph; k++)
		{
			for (int l = 0; l < pw; l++)
			{
				if (array[k * pw + l] > 0.0)
				{
					g[k * stride + l] /= array[k * pw + l];
				}
			}
		}
	}

	private static double Local(int px, int py, double sc, int[] id, int RW, int RH, double minX, double maxY, int r, int reach, int step, int ws, ref double x, ref double y)
	{
		int num = 2 * r + 1;
		double[] array = new double[num * num];
		double num2 = 0.0;
		for (int i = -r; i <= r; i += ws)
		{
			for (int j = -r; j <= r; j += ws)
			{
				int num3 = (int)Math.Round((double)px + (double)j * sc);
				int num4 = (int)Math.Round((double)py - (double)i * sc);
				double num5 = 0.0;
				if (num3 >= 0 && num4 >= 0 && num3 < W && num4 < H)
				{
					int num6 = num4 * W + num3;
					num5 = (_big[num6] ? 1 : (_white[num6] ? (-1) : 0));
				}
				array[(i + r) * num + j + r] = num5;
				num2 += Math.Abs(num5);
			}
		}
		if (num2 <= 0.0)
		{
			return 0.0;
		}
		double num7 = x;
		double num8 = y;
		double num9 = double.MinValue;
		double num10 = x;
		double num11 = y;
		for (int k = -reach; k <= reach; k += step)
		{
			for (int l = -reach; l <= reach; l += step)
			{
				double num12 = num7 + (double)l;
				double num13 = num8 + (double)k;
				double num14 = 0.0;
				for (int m = -r; m <= r; m += ws)
				{
					for (int n = -r; n <= r; n += ws)
					{
						double num15 = array[(m + r) * num + n + r];
						if (num15 != 0.0)
						{
							int num16 = (int)Math.Floor(num12 + (double)n - minX);
							int num17 = (int)Math.Floor(maxY - (num13 + (double)m));
							bool flag = num16 >= 0 && num17 >= 0 && num16 < RW && num17 < RH && id[num17 * RW + num16] != 0;
							num14 += (flag ? num15 : (0.0 - num15));
						}
					}
				}
				num14 = num14 / num2 - ((reach > 20) ? 5E-05 : 0.0003) * (double)(l * l + k * k);
				if (num14 > num9)
				{
					num9 = num14;
					num10 = num12;
					num11 = num13;
				}
			}
		}
		x = num10;
		y = num11;
		return num9;
	}

	private static int ShadeAt(int px, int py)
	{
		Dictionary<int, int> dictionary = new Dictionary<int, int>();
		for (int i = -6; i <= 6; i++)
		{
			for (int j = -6; j <= 6; j++)
			{
				int num = px + j;
				int num2 = py + i;
				if (num >= 0 && num2 >= 0 && num < W && num2 < H && _roomOk[num2 * W + num])
				{
					int key = _rgb[num2 * W + num] & 0xFFFFFF;
					dictionary.TryGetValue(key, out var value);
					dictionary[key] = value + 1;
				}
			}
		}
		int result = -1;
		int num3 = 0;
		foreach (KeyValuePair<int, int> item in dictionary)
		{
			if (item.Value > num3)
			{
				num3 = item.Value;
				result = item.Key;
			}
		}
		return result;
	}

	private static int ShadeLevel(Dictionary<int, Dictionary<int, int[]>> cache, Match m, int pid, int shade, List<int[]> ids, List<int> levels, int RW, int RH, double minX, double maxY)
	{
		if (shade < 0)
		{
			return -1;
		}
		if (!cache.TryGetValue(pid, out var value))
		{
			value = new Dictionary<int, int[]>();
			int num = levels.Count - 1;
			for (int i = 0; i < m.P.Pix.Count; i += 3)
			{
				int num2 = m.P.Pix[i];
				if (!_roomOk[num2])
				{
					continue;
				}
				double num3 = minX + m.OX + (double)(num2 % W - m.P.X0) / m.S;
				double num4 = maxY - (m.OY + (double)(num2 / W - m.P.Y0) / m.S);
				int num5 = (int)Math.Floor(num3 - minX);
				int num6 = (int)Math.Floor(maxY - num4);
				if (num5 < 0 || num6 < 0 || num5 >= RW || num6 >= RH)
				{
					continue;
				}
				int num7 = -1;
				int num8 = 0;
				for (int j = 0; j < num; j++)
				{
					if (ids[j][num6 * RW + num5] != 0)
					{
						num7 = j;
						num8++;
					}
				}
				if (num8 == 1)
				{
					int key = _rgb[num2] & 0xFFFFFF;
					if (!value.TryGetValue(key, out var value2))
					{
						value2 = (value[key] = new int[num]);
					}
					value2[num7]++;
				}
			}
			cache[pid] = value;
		}
		if (!value.TryGetValue(shade, out var value3))
		{
			return -1;
		}
		int num9 = -1;
		int num10 = 0;
		int num11 = 0;
		for (int k = 0; k < value3.Length; k++)
		{
			num11 += value3[k];
			if (value3[k] > num10)
			{
				num10 = value3[k];
				num9 = k;
			}
		}
		return (num10 >= 10 && (double)num10 >= (double)num11 * 0.5) ? num9 : (-1);
	}

	private static int Snap(int[] id, int RW, int RH, double minX, double maxY, ref double x, ref double y, int r)
	{
		int num = (int)Math.Floor(x - minX);
		int num2 = (int)Math.Floor(maxY - y);
		int num3 = 0;
		double num4 = double.MaxValue;
		int num5 = 0;
		int num6 = 0;
		for (int i = -r; i <= r; i++)
		{
			for (int j = -r; j <= r; j++)
			{
				int num7 = num + j;
				int num8 = num2 + i;
				if (num7 >= 0 && num8 >= 0 && num7 < RW && num8 < RH && id[num8 * RW + num7] != 0)
				{
					double num9 = j * j + i * i;
					if (num9 < num4)
					{
						num4 = num9;
						num3 = id[num8 * RW + num7];
						num5 = num7;
						num6 = num8;
					}
				}
			}
		}
		if (num3 != 0 && num4 > 0.0)
		{
			x = minX + (double)num5 + 0.5;
			y = maxY - (double)num6 - 0.5;
		}
		return num3;
	}

	private static int PieceNear(int px, int py, int r)
	{
		int result = 0;
		int num = int.MaxValue;
		for (int i = -r; i <= r; i++)
		{
			for (int j = -r; j <= r; j++)
			{
				int num2 = px + j;
				int num3 = py + i;
				if (num2 >= 0 && num3 >= 0 && num2 < W && num3 < H)
				{
					int num4 = _piece[num3 * W + num2];
					if (num4 != 0 && j * j + i * i < num)
					{
						num = j * j + i * i;
						result = num4;
					}
				}
			}
		}
		return result;
	}

	private static bool IsLever(Comp c)
	{
		bool[] array = c.Sub();
		int num = 0;
		for (int i = 0; i < c.W; i++)
		{
			if (array[(c.H - 1) * c.W + i])
			{
				num++;
			}
		}
		if (num < c.W - 1)
		{
			return false;
		}
		int num2 = 0;
		for (int j = 0; j < c.W; j++)
		{
			if (array[j])
			{
				num2++;
				if (j == 0 || j == c.W - 1)
				{
					return false;
				}
			}
		}
		return num2 > 0;
	}

	private static void Doors(List<Found> icons)
	{
		int num = W * H;
		bool[] array = new bool[num];
		for (int i = 3; i < H - 3; i++)
		{
			for (int j = 3; j < W - 3; j++)
			{
				int num2 = i * W + j;
				if (_dark[num2])
				{
					bool flag = false;
					bool flag2 = false;
					bool flag3 = false;
					bool flag4 = false;
					for (int k = 1; k <= 3; k++)
					{
						flag |= _roomOk[num2 - k];
						flag2 |= _roomOk[num2 + k];
						flag3 |= _roomOk[num2 - k * W];
						flag4 |= _roomOk[num2 + k * W];
					}
					array[num2] = (flag & flag2) || (flag3 & flag4);
				}
			}
		}
		foreach (Comp item in Comps(array))
		{
			bool flag5 = item.H >= item.W;
			int num3 = (flag5 ? item.H : item.W);
			int num4 = (flag5 ? item.W : item.H);
			if (num3 < 5 || num4 > 7)
			{
				continue;
			}
			bool[] array2 = item.Sub();
			int[] array3 = new int[num3];
			for (int l = 0; l < item.H; l++)
			{
				for (int m = 0; m < item.W; m++)
				{
					if (array2[l * item.W + m])
					{
						array3[flag5 ? l : m]++;
					}
				}
			}
			int[] array4 = (int[])array3.Clone();
			Array.Sort(array4);
			int num5 = array4[num3 / 2];
			if (num5 > 2)
			{
				continue;
			}
			int num6 = 0;
			bool flag6 = false;
			int[] array5 = array3;
			foreach (int num7 in array5)
			{
				bool flag7 = num7 >= num5 + 2;
				if (flag7 && !flag6)
				{
					num6++;
				}
				flag6 = flag7;
			}
			if (num6 == 1)
			{
				icons.Add(new Found
				{
					Kind = 0,
					Px = item.Cx,
					Py = item.Cy
				});
			}
			else if (num6 >= 2)
			{
				icons.Add(new Found
				{
					Kind = 1,
					Px = item.Cx,
					Py = item.Cy
				});
			}
		}
	}

	private static List<Comp> Comps(bool[] m)
	{
		List<Comp> list = new List<Comp>();
		bool[] array = new bool[m.Length];
		Stack<int> stack = new Stack<int>();
		for (int i = 0; i < m.Length; i++)
		{
			if (!m[i] || array[i])
			{
				continue;
			}
			Comp comp = new Comp();
			long num = 0L;
			long num2 = 0L;
			array[i] = true;
			stack.Push(i);
			while (stack.Count > 0)
			{
				int num3 = stack.Pop();
				int num4 = num3 % W;
				int num5 = num3 / W;
				comp.Pix.Add(num3);
				num += num4;
				num2 += num5;
				if (num4 < comp.X0)
				{
					comp.X0 = num4;
				}
				if (num4 > comp.X1)
				{
					comp.X1 = num4;
				}
				if (num5 < comp.Y0)
				{
					comp.Y0 = num5;
				}
				if (num5 > comp.Y1)
				{
					comp.Y1 = num5;
				}
				for (int j = -1; j <= 1; j++)
				{
					for (int k = -1; k <= 1; k++)
					{
						int num6 = num4 + k;
						int num7 = num5 + j;
						if (num6 >= 0 && num7 >= 0 && num6 < W && num7 < H)
						{
							int num8 = num7 * W + num6;
							if (m[num8] && !array[num8])
							{
								array[num8] = true;
								stack.Push(num8);
							}
						}
					}
				}
			}
			comp.Cx = (int)(num / comp.N);
			comp.Cy = (int)(num2 / comp.N);
			list.Add(comp);
		}
		return list;
	}

	private static bool[] Dilate(bool[] a, int r)
	{
		return Box(Box(a, r, horiz: true, any: true), r, horiz: false, any: true);
	}

	private static bool[] Erode(bool[] a, int r)
	{
		return Box(Box(a, r, horiz: true, any: false), r, horiz: false, any: false);
	}

	private static bool[] Box(bool[] a, int r, bool horiz, bool any)
	{
		bool[] array = new bool[a.Length];
		int num = (horiz ? W : H);
		int num2 = (horiz ? H : W);
		int ln;
		for (ln = 0; ln < num2; ln++)
		{
			int num3 = 0;
			Func<int, int> func = (horiz ? ((Func<int, int>)((int k) => ln * W + k)) : ((Func<int, int>)((int k) => k * W + ln)));
			for (int num4 = 0; num4 < Math.Min(r, num); num4++)
			{
				if (a[func(num4)])
				{
					num3++;
				}
			}
			for (int num5 = 0; num5 < num; num5++)
			{
				int num6 = num5 + r;
				if (num6 < num && a[func(num6)])
				{
					num3++;
				}
				int num7 = Math.Min(num - 1, num5 + r) - Math.Max(0, num5 - r) + 1;
				array[func(num5)] = (any ? (num3 > 0) : (num3 == num7 && num5 - r >= 0 && num5 + r < num));
				int num8 = num5 - r;
				if (num8 >= 0 && a[func(num8)])
				{
					num3--;
				}
			}
		}
		return array;
	}

	private static void Fill(int[] id, int RW, int RH, float[] pg, double minX, double maxY, int v)
	{
		int num = (pg.Length - 1) / 2;
		if (num < 3)
		{
			return;
		}
		double num2 = double.MaxValue;
		double num3 = double.MinValue;
		for (int i = 0; i < num; i++)
		{
			double val = maxY - (double)pg[2 + 2 * i];
			num2 = Math.Min(num2, val);
			num3 = Math.Max(num3, val);
		}
		List<double> list = new List<double>();
		for (int j = Math.Max(0, (int)Math.Floor(num2)); j <= Math.Min(RH - 1, (int)Math.Ceiling(num3)); j++)
		{
			double num4 = (double)j + 0.5;
			list.Clear();
			for (int k = 0; k < num; k++)
			{
				int num5 = (k + 1) % num;
				double num6 = (double)pg[1 + 2 * k] - minX;
				double num7 = maxY - (double)pg[2 + 2 * k];
				double num8 = (double)pg[1 + 2 * num5] - minX;
				double num9 = maxY - (double)pg[2 + 2 * num5];
				if ((num7 <= num4 && num9 > num4) || (num9 <= num4 && num7 > num4))
				{
					list.Add(num6 + (num4 - num7) / (num9 - num7) * (num8 - num6));
				}
			}
			list.Sort();
			for (int l = 0; l + 1 < list.Count; l += 2)
			{
				for (int m = Math.Max(0, (int)Math.Round(list[l])); m < Math.Min(RW, (int)Math.Round(list[l + 1])); m++)
				{
					id[j * RW + m] = v;
				}
			}
		}
	}

	private static void Fft2(double[] re, double[] im, int N, bool inv)
	{
		double[] array = new double[N];
		double[] array2 = new double[N];
		for (int i = 0; i < N; i++)
		{
			Array.Copy(re, i * N, array, 0, N);
			Array.Copy(im, i * N, array2, 0, N);
			Fft(array, array2, inv);
			Array.Copy(array, 0, re, i * N, N);
			Array.Copy(array2, 0, im, i * N, N);
		}
		for (int j = 0; j < N; j++)
		{
			for (int k = 0; k < N; k++)
			{
				array[k] = re[k * N + j];
				array2[k] = im[k * N + j];
			}
			Fft(array, array2, inv);
			for (int l = 0; l < N; l++)
			{
				re[l * N + j] = array[l];
				im[l * N + j] = array2[l];
			}
		}
		if (inv)
		{
			double num = 1.0 / ((double)N * (double)N);
			for (int m = 0; m < re.Length; m++)
			{
				re[m] *= num;
				im[m] *= num;
			}
		}
	}

	private static void Fft(double[] re, double[] im, bool inv)
	{
		int num = re.Length;
		int i = 1;
		int num2 = 0;
		for (; i < num; i++)
		{
			int num3 = num >> 1;
			while ((num2 & num3) != 0)
			{
				num2 ^= num3;
				num3 >>= 1;
			}
			num2 ^= num3;
			if (i < num2)
			{
				double num4 = re[i];
				re[i] = re[num2];
				re[num2] = num4;
				num4 = im[i];
				im[i] = im[num2];
				im[num2] = num4;
			}
		}
		for (int num5 = 2; num5 <= num; num5 <<= 1)
		{
			double num6 = Math.PI * 2.0 / (double)num5 * (double)(inv ? 1 : (-1));
			double num7 = Math.Cos(num6);
			double num8 = Math.Sin(num6);
			for (int j = 0; j < num; j += num5)
			{
				double num9 = 1.0;
				double num10 = 0.0;
				for (int k = 0; k < num5 / 2; k++)
				{
					int num11 = j + k;
					int num12 = j + k + num5 / 2;
					double num13 = re[num12] * num9 - im[num12] * num10;
					double num14 = re[num12] * num10 + im[num12] * num9;
					re[num12] = re[num11] - num13;
					im[num12] = im[num11] - num14;
					re[num11] += num13;
					im[num11] += num14;
					double num15 = num9 * num7 - num10 * num8;
					num10 = num9 * num8 + num10 * num7;
					num9 = num15;
				}
			}
		}
	}
}
