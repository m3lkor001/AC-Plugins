using System;
using System.Collections.Generic;

namespace MelksQuestTracker.Travel
{
    /// <summary>
    /// What's in the way outdoors, from the game's files: buildings and the things placed on each landblock (rocks, fences,
    /// statues ... - client_cell_1.dat's landblock info), and the trees, bushes and rocks the game scatters over the ground
    /// itself (worked out from the ground's types the same way the game does - they aren't stored anywhere). Each one's solid
    /// shape is its physics faces (client_portal.dat), so grass and anything you can walk through isn't counted.
    /// Kept as a 0.5 m grid per landblock: Blocked(x, y) in world metres.
    /// </summary>
    internal static class Obstacles
    {
        public const double Res = 0.5;            // metres a grid square
        private const int N = 384;                // squares a side (192 m)
        public static double Clearance = 0.7;     // how far to keep from anything solid (you're about this wide)
        private const float BandLo = 0.35f, BandHi = 2.2f;   // the height you'd walk into (above the ground under it)

        public static string Error = "";

        // ── per landblock ──
        private static readonly Dictionary<int, byte[]> _grid = new Dictionary<int, byte[]>();
        private static readonly LinkedList<int> _order = new LinkedList<int>();

        /// <summary>Is the spot (world metres: x = (EW + 101.95) * 240, y = (NS + 101.95) * 240) blocked?</summary>
        public static bool Blocked(double x, double y)
        {
            int lbx = (int)Math.Floor(x / 192.0), lby = (int)Math.Floor(y / 192.0);
            if (lbx < 0 || lby < 0 || lbx > 254 || lby > 254) return false;
            byte[] g = Grid(lbx, lby);
            if (g == null) return false;
            int gx = (int)((x - lbx * 192.0) / Res), gy = (int)((y - lby * 192.0) / Res);
            if (gx < 0 || gy < 0 || gx >= N || gy >= N) return false;
            return g[gx * N + gy] != 0;
        }

        private static byte[] Grid(int lbx, int lby)
        {
            int key = (lbx << 8) | lby;
            byte[] g;
            if (_grid.TryGetValue(key, out g)) return g;
            try { g = Build(lbx, lby); }
            catch (Exception ex) { Error = "landblock " + key.ToString("X4") + ": " + ex.Message; g = null; }
            _grid[key] = g; _order.AddLast(key);
            while (_order.Count > 80) { _grid.Remove(_order.First.Value); _order.RemoveFirst(); }
            return g;
        }

        public static void Forget() { _grid.Clear(); _order.Clear(); }

        private static byte[] Build(int lbx, int lby)
        {
            byte[] solid = new byte[N * N];
            uint lb = (uint)((lbx << 8) | lby);
            ushort[] terrain = WorldMap.TerrainWords(lbx, lby);
            // buildings and placed things
            HashSet<int> bldCells = new HashSet<int>();
            byte[] info = WorldMap.CellFile((lb << 16) | 0xFFFE);
            if (info != null && info.Length >= 12)
            {
                int p = 8;
                uint objs = U32(info, ref p);
                for (uint i = 0; i < objs && p + 32 <= info.Length; i++)
                {
                    uint id = U32(info, ref p);
                    float[] fr = Frame(info, ref p);
                    Stamp(solid, id, fr, 1f);
                }
                if (p + 4 <= info.Length)
                {
                    int nb = BitConverter.ToUInt16(info, p); p += 4;   // count, then flags
                    for (int i = 0; i < nb && p + 40 <= info.Length; i++)
                    {
                        uint id = U32(info, ref p);
                        float[] fr = Frame(info, ref p);
                        p += 4;   // leaves
                        uint np = U32(info, ref p);
                        HashSet<int> inside = new HashSet<int>();   // the building's rooms (the cells its doors lead into, and what they see)
                        for (uint k = 0; k < np && p + 8 <= info.Length; k++)
                        {
                            int other = BitConverter.ToUInt16(info, p + 2);
                            if (other >= 0x100) inside.Add(other);
                            p += 6; int ns = BitConverter.ToUInt16(info, p); p += 2;
                            for (int q = 0; q < ns && p + 2 <= info.Length; q++) { int st = BitConverter.ToUInt16(info, p); if (st >= 0x100) inside.Add(st); p += 2; }
                            p = (p + 3) & ~3;
                        }
                        Stamp(solid, id, fr, 1f);
                        // a building's rooms aren't a way through (its outer walls alone left room in it - a route went in
                        // through a tower's one door). Only its rooms: a gatehouse's arch is outdoors, and stays open.
                        StampRooms(solid, lb, inside, terrain, lbx, lby);
                        int cx = (int)(fr[0] / 24), cy = (int)(fr[1] / 24);
                        if (cx >= 0 && cy >= 0 && cx < 8 && cy < 8) bldCells.Add(cx * 8 + cy);
                    }
                }
            }
            // what the game scatters over the ground
            if (terrain != null) Scenery(solid, lbx, lby, terrain, bldCells);
            // keep your width away from all of it
            return Grow(solid, (int)Math.Ceiling(Clearance / Res));
        }

        private static byte[] Grow(byte[] s, int r)
        {
            byte[] o = new byte[N * N];
            List<int[]> disk = new List<int[]>();
            for (int dx = -r; dx <= r; dx++) for (int dy = -r; dy <= r; dy++) if (dx * dx + dy * dy <= r * r + r) disk.Add(new[] { dx, dy });
            for (int x = 0; x < N; x++)
                for (int y = 0; y < N; y++)
                {
                    if (s[x * N + y] == 0) continue;
                    foreach (int[] d in disk)
                    {
                        int qx = x + d[0], qy = y + d[1];
                        if (qx >= 0 && qy >= 0 && qx < N && qy < N) o[qx * N + qy] = 1;
                    }
                }
            return o;
        }

        // ── scenery: the game's own scatter of trees / rocks / bushes over each ground vertex ──
        private static List<uint>[] _terrainScenes;   // per terrain type: its scene-type numbers
        private static List<uint>[] _sceneTypes;      // per scene type: its scenes
        private static bool _regionTried;

        private class Obj { public uint Id; public float[] Base; public float Freq, DispX, DispY, MinScale, MaxScale, MaxRot, MinSlope, MaxSlope; public uint Align, Weenie; }
        private static readonly Dictionary<uint, List<Obj>> _scenes = new Dictionary<uint, List<Obj>>();

        private static void Scenery(byte[] solid, int lbx, int lby, ushort[] terrain, HashSet<int> bldCells)
        {
            if (!Region()) return;
            uint bx = (uint)lbx * 8, by = (uint)lby * 8;
            for (int i = 0; i < 81; i++)
            {
                ushort t = terrain[i];
                int type = (t >> 2) & 0x1F, st = t >> 11;
                if (type >= _terrainScenes.Length || _terrainScenes[type] == null || st >= _terrainScenes[type].Count) continue;
                uint sti = _terrainScenes[type][st];
                if (sti >= _sceneTypes.Length || _sceneTypes[sti] == null || _sceneTypes[sti].Count == 0) continue;
                List<uint> scenes = _sceneTypes[sti];
                uint cx = (uint)(i / 9), cy = (uint)(i % 9);
                uint gx = cx + bx, gy = cy + by;
                // which of the scene type's scenes this vertex gets
                uint pick = unchecked(gy * (712977289u * gx + 1813693831u) - 1109124029u * gx + 2139937281u);
                int si = (int)(scenes.Count * (pick * 2.3283064e-10));
                if (si >= scenes.Count) si = 0;
                List<Obj> objs = Scene(scenes[si]);
                if (objs == null) continue;
                uint a = unchecked(1813693831u * gy - 1109124029u * gx), m = unchecked(1360117743u * gx * gy + 1888038839u);
                for (uint j = 0; j < objs.Count; j++)
                {
                    Obj o = objs[(int)j];
                    double noise = unchecked(a - m * (23399u + j)) * 2.3283064e-10;
                    if (noise >= o.Freq || o.Weenie != 0) continue;
                    float px, py;
                    Place(o, gx, gy, j, out px, out py);
                    float lx = cx * 24f + px, ly = cy * 24f + py;
                    if (lx < 0 || ly < 0 || lx >= 192 || ly >= 192) continue;
                    if (OnRoad(terrain, lx, ly)) continue;
                    int cell = (int)(lx / 24) * 8 + (int)(ly / 24);
                    if (bldCells.Contains(cell)) continue;
                    double nz = GroundNz(lbx, lby, terrain, lx, ly);
                    if (nz < o.MinSlope || nz > o.MaxSlope) continue;
                    float heading = 0;
                    if (o.Align == 0 && o.MaxRot > 0) heading = (float)(unchecked(1813693831u * gy - (j + 63127u) * m - 1109124029u * gx) * 2.3283064e-10 * o.MaxRot);
                    float scale = o.MinScale == o.MaxScale ? o.MaxScale : (float)(Math.Pow(o.MaxScale / o.MinScale, unchecked(1813693831u * gy - (j + 32593u) * m - 1109124029u * gx) * 2.3283064e-10) * o.MinScale);
                    // the object's turn: its base turn, then the heading (degrees clockwise from north)
                    float[] q = HeadingQuat(heading, o.Base);
                    float[] fr = { lx, ly, 0, q[0], q[1], q[2], q[3] };
                    Stamp(solid, o.Id, fr, scale <= 0 ? 1f : scale);
                }
            }
        }

        private static void Place(Obj o, uint ix, uint iy, uint iq, out float x, out float y)
        {
            uint m = unchecked(1360117743u * iy * ix + 1888038839u);
            x = o.DispX <= 0 ? o.Base[0] : (float)(unchecked(1813693831u * iy - (iq + 45773u) * m - 1109124029u * ix) * 2.3283064e-10 * o.DispX + o.Base[0]);
            y = o.DispY <= 0 ? o.Base[1] : (float)(unchecked(1813693831u * iy - (iq + 72719u) * m - 1109124029u * ix) * 2.3283064e-10 * o.DispY + o.Base[1]);
            double quad = unchecked(1813693831u * iy - ix * (1870387557u * iy + 1109124029u) - 402451965u) * 2.3283064e-10;
            float tx = x, ty = y;
            if (quad >= 0.75) { x = ty; y = -tx; }
            else if (quad >= 0.5) { x = -tx; y = -ty; }
            else if (quad >= 0.25) { x = -ty; y = tx; }
        }

        private static float[] HeadingQuat(float deg, float[] baseFrame)
        {
            // heading only (scenery's base turn is nearly always none)
            double r = -deg * Math.PI / 180.0 / 2.0;
            return new float[] { (float)Math.Cos(r), 0, 0, (float)Math.Sin(r) };
        }

        /// <summary>Road squares (5 m either side of a road) get no scenery.</summary>
        private static bool OnRoad(ushort[] t, float px, float py)
        {
            int x = (int)(px / 24), y = (int)(py / 24);
            const float rMin = 5f, rMax = 19f, L = 24f;
            Func<int, int, bool> R = (vx, vy) => vx >= 0 && vy >= 0 && vx < 9 && vy < 9 && (t[vx * 9 + vy] & 3) != 0;
            bool r0 = R(x, y), r1 = R(x, y + 1), r2 = R(x + 1, y), r3 = R(x + 1, y + 1);
            if (!r0 && !r1 && !r2 && !r3) return false;
            float dx = px - x * L, dy = py - y * L;
            if (r0)
            {
                if (r1) { if (r2) return r3 || dx < rMin || dy < rMin; return r3 ? (dx < rMin || dy > rMax) : dx < rMin; }
                if (r2) return r3 ? (dx > rMax || dy < rMin) : dy < rMin;
                return r3 ? Math.Abs(dx - dy) < rMin : dx + dy < rMin;
            }
            if (r1)
            {
                if (r2) return r3 ? (dx > rMax || dy > rMax) : Math.Abs(dx + dy - L) < rMin;
                return r3 ? dy > rMax : L + dx - dy < rMin;
            }
            if (r2) return r3 ? dx > rMax : L - dx + dy < rMin;
            return r3 && L * 2f - dx - dy < rMin;
        }

        /// <summary>How flat the ground is at a spot (the up part of its slope: 1 = flat), using the game's own split of each
        /// 24 m square into two triangles.</summary>
        private static double GroundNz(int lbx, int lby, ushort[] t, float lx, float ly)
        {
            int cx = Math.Min(7, (int)(lx / 24)), cy = Math.Min(7, (int)(ly / 24));
            float h00 = WorldMap.VertexHeight(lbx, lby, cx, cy), h10 = WorldMap.VertexHeight(lbx, lby, cx + 1, cy);
            float h01 = WorldMap.VertexHeight(lbx, lby, cx, cy + 1), h11 = WorldMap.VertexHeight(lbx, lby, cx + 1, cy + 1);
            uint gx = (uint)(lbx * 8 + cx), gy = (uint)(lby * 8 + cy);
            uint split = unchecked(gy * (gx * 214614067u + 1813693831u) - gx * 1109124029u - 1369149221u);
            bool swNe = split * 2.3283064e-10 >= 0.5;
            double dx = lx - cx * 24, dy = ly - cy * 24;
            if (swNe)
                return dx > dy ? Nz(0, 0, h00, 24, 0, h10, 24, 24, h11) : Nz(0, 0, h00, 24, 24, h11, 0, 24, h01);
            return dx + dy < 24 ? Nz(0, 0, h00, 24, 0, h10, 0, 24, h01) : Nz(24, 0, h10, 24, 24, h11, 0, 24, h01);
        }

        private static double Nz(double ax, double ay, double ah, double bx, double by, double bh, double cx, double cy, double ch)
        {
            double ux = bx - ax, uy = by - ay, uz = bh - ah, vx = cx - ax, vy = cy - ay, vz = ch - ah;
            double nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
            double len = Math.Sqrt(nx * nx + ny * ny + nz * nz);
            return len == 0 ? 1 : Math.Abs(nz) / len;
        }

        // ── the region: which scenes go with which ground ──
        private static bool Region()
        {
            if (_terrainScenes != null) return true;
            if (_regionTried) return false;
            _regionTried = true;
            try
            {
                byte[] b = WorldMap.PortalFile(0x13000000);
                if (b == null) { Error = "no region file"; return false; }
                int p = 12;
                PStr(b, ref p); Align(ref p);
                p += 32 + 256 * 4;                       // land defs, height table
                p += 8 + 4 + 4 + 4; PStr(b, ref p); Align(ref p);   // game time: zero time, year, day length, days a year, year name
                uint n = U32(b, ref p);
                for (uint i = 0; i < n; i++) { p += 8; PStr(b, ref p); Align(ref p); }   // times of day
                n = U32(b, ref p);
                for (uint i = 0; i < n; i++) { PStr(b, ref p); Align(ref p); }            // days of the week
                n = U32(b, ref p);
                for (uint i = 0; i < n; i++) { p += 4; PStr(b, ref p); Align(ref p); }   // seasons
                uint parts = U32(b, ref p);
                if ((parts & 0x10) != 0)
                {   // sky
                    p += 16; Align(ref p);
                    uint groups = U32(b, ref p);
                    for (uint g = 0; g < groups; g++)
                    {
                        p += 4; PStr(b, ref p); Align(ref p);
                        uint so = U32(b, ref p); p += (int)so * 36;
                        uint times = U32(b, ref p);
                        for (uint k = 0; k < times; k++) { p += 44; uint rep = U32(b, ref p); p += (int)rep * 24; }
                    }
                }
                if ((parts & 0x01) != 0)
                {   // sounds
                    uint sd = U32(b, ref p);
                    for (uint k = 0; k < sd; k++) { p += 4; uint am = U32(b, ref p); p += (int)am * 20; }
                }
                if ((parts & 0x02) == 0) { Error = "the region has no scenes"; return false; }
                uint stc = U32(b, ref p);
                if (stc > 1000) { Error = "region scenes unreadable"; return false; }
                List<uint>[] sts = new List<uint>[stc];
                for (uint k = 0; k < stc; k++)
                {
                    p += 4; int c = (int)U32(b, ref p);
                    List<uint> l = new List<uint>(c);
                    for (int q = 0; q < c; q++) l.Add(U32(b, ref p));
                    sts[k] = l;
                }
                uint ttc = U32(b, ref p);
                if (ttc > 64) { Error = "region ground types unreadable"; return false; }
                List<uint>[] tts = new List<uint>[ttc];
                for (uint k = 0; k < ttc; k++)
                {
                    PStr(b, ref p); Align(ref p); p += 4;
                    int c = (int)U32(b, ref p);
                    List<uint> l = new List<uint>(c);
                    for (int q = 0; q < c; q++) l.Add(U32(b, ref p));
                    tts[k] = l;
                }
                _sceneTypes = sts; _terrainScenes = tts;
                return true;
            }
            catch (Exception ex) { Error = "region: " + ex.Message; return false; }
        }

        private static List<Obj> Scene(uint id)
        {
            List<Obj> l;
            if (_scenes.TryGetValue(id, out l)) return l;
            l = null;
            try
            {
                byte[] b = WorldMap.PortalFile(id);
                if (b != null && b.Length >= 8)
                {
                    int p = 4;
                    uint n = U32(b, ref p);
                    l = new List<Obj>();
                    for (uint i = 0; i < n && p + 76 <= b.Length; i++)
                    {
                        Obj o = new Obj();
                        o.Id = U32(b, ref p); o.Base = Frame(b, ref p);
                        o.Freq = F(b, ref p); o.DispX = F(b, ref p); o.DispY = F(b, ref p);
                        o.MinScale = F(b, ref p); o.MaxScale = F(b, ref p); o.MaxRot = F(b, ref p);
                        o.MinSlope = F(b, ref p); o.MaxSlope = F(b, ref p);
                        o.Align = U32(b, ref p); p += 4; o.Weenie = U32(b, ref p);
                        l.Add(o);
                    }
                }
            }
            catch { l = null; }
            _scenes[id] = l;
            return l;
        }

        // ── models: their solid faces, in their own space ──
        private class Shape { public List<float[]> Faces = new List<float[]>(); public List<float[]> Circles = new List<float[]>(); }
        private static readonly Dictionary<uint, Shape> _shapes = new Dictionary<uint, Shape>();

        private static Shape ShapeOf(uint id)
        {
            Shape s;
            if (_shapes.TryGetValue(id, out s)) return s;
            s = new Shape();
            _shapes[id] = s;   // (a part pointing back at its setup can't loop)
            try
            {
                if ((id >> 24) == 0x01) GfxFaces(id, null, 1f, s);
                else if ((id >> 24) == 0x02) Setup(id, s);
            }
            catch { }
            return s;
        }

        private static void Setup(uint id, Shape s)
        {
            byte[] b = WorldMap.PortalFile(id);
            if (b == null) return;
            int p = 4;
            uint flags = U32(b, ref p);
            uint np = U32(b, ref p);
            if (np > 256) return;
            uint[] parts = new uint[np];
            for (int i = 0; i < np; i++) parts[i] = U32(b, ref p);
            if ((flags & 1) != 0) p += (int)np * 4;                   // parents
            float[][] scales = null;
            if ((flags & 2) != 0) { scales = new float[np][]; for (int i = 0; i < np; i++) scales[i] = new[] { F(b, ref p), F(b, ref p), F(b, ref p) }; }
            float[][] place = null;
            bool ok = true;
            for (int d = 0; d < 2 && ok; d++)
            {   // holding locations, connection points
                int c = (int)U32(b, ref p);
                if (c < 0 || c > 64) { ok = false; break; }
                p += c * (4 + 4 + 28);
            }
            if (ok)
            {
                int pc = (int)U32(b, ref p);
                if (pc < 0 || pc > 64) ok = false;
                for (int k = 0; k < pc && ok; k++)
                {
                    p += 4;   // which placement
                    float[][] frames = new float[np][];
                    for (int i = 0; i < np; i++) frames[i] = Frame(b, ref p);
                    uint hooks = U32(b, ref p);
                    if (hooks != 0) { ok = false; break; }   // (animation hooks: can't step over them - parts used where they are)
                    if (place == null) place = frames;
                }
            }
            if (ok)
            {
                uint cyl = U32(b, ref p);
                if (cyl < 64) for (int i = 0; i < cyl; i++) { float x = F(b, ref p), y = F(b, ref p), z = F(b, ref p), r = F(b, ref p), h = F(b, ref p); s.Circles.Add(new[] { x, y, z, z + h, r }); }
                uint sph = cyl < 64 ? U32(b, ref p) : 99;
                if (sph < 64) for (int i = 0; i < sph; i++) { float x = F(b, ref p), y = F(b, ref p), z = F(b, ref p), r = F(b, ref p); s.Circles.Add(new[] { x, y, z - r, z + r, r }); }
            }
            for (int i = 0; i < np; i++)
            {
                if ((parts[i] >> 24) != 0x01) continue;
                float[] fr = place != null ? place[i] : null;
                float sc = scales != null ? scales[i][0] : 1f;
                GfxFaces(parts[i], fr, sc, s);
            }
        }

        /// <summary>A model's physics faces (moved by fr / scaled by sc - a setup's part), into s.</summary>
        private static void GfxFaces(uint id, float[] fr, float sc, Shape s)
        {
            byte[] b = WorldMap.PortalFile(id);
            if (b == null || b.Length < 12) return;
            int p = 4;
            uint flags = U32(b, ref p);
            if ((flags & 1) == 0) return;   // nothing solid (grass, leaves ...)
            uint ns = CU32(b, ref p); p += (int)ns * 4;   // surfaces
            p += 4;   // vertex type
            uint nv = U32(b, ref p);
            if (nv > 20000) return;
            Dictionary<int, float[]> verts = new Dictionary<int, float[]>();
            for (uint i = 0; i < nv; i++)
            {
                int vid = BitConverter.ToUInt16(b, p); p += 2;
                int nuv = BitConverter.ToUInt16(b, p); p += 2;
                float x = F(b, ref p), y = F(b, ref p), z = F(b, ref p);
                p += 12 + nuv * 8;
                float[] v = { x * sc, y * sc, z * sc };
                if (fr != null) v = Xf(fr, v);
                verts[vid] = v;
            }
            uint npoly = CU32(b, ref p);
            if (npoly > 20000) return;
            for (uint i = 0; i < npoly; i++)
            {
                p += 2;   // key
                int n = b[p]; int stip = b[p + 1]; p += 2;
                int sides = BitConverter.ToInt32(b, p); p += 4;
                p += 4;   // surfaces
                float[] face = new float[n * 3];
                for (int k = 0; k < n; k++)
                {
                    int vid = BitConverter.ToInt16(b, p); p += 2;
                    float[] v; if (!verts.TryGetValue(vid, out v)) v = new float[3];
                    face[k * 3] = v[0]; face[k * 3 + 1] = v[1]; face[k * 3 + 2] = v[2];
                }
                if ((stip & 4) == 0) p += n;
                if (sides == 2 && (stip & 8) == 0) p += n;
                s.Faces.Add(face);
            }
        }

        /// <summary>Puts a model's solid part (what you'd walk into) on the grid: at frame fr (x, y, z, then its turn), scaled.</summary>
        private static void Stamp(byte[] solid, uint id, float[] fr, float scale)
        {
            Shape s = ShapeOf(id);
            if (s.Faces.Count == 0 && s.Circles.Count == 0) return;
            foreach (float[] f in s.Faces)
            {
                int n = f.Length / 3;
                if (n < 2) continue;
                float zlo = float.MaxValue, zhi = float.MinValue;
                float[] xs = new float[n], ys = new float[n];
                for (int k = 0; k < n; k++)
                {
                    float[] v = Rot(fr, f[k * 3] * scale, f[k * 3 + 1] * scale, f[k * 3 + 2] * scale);
                    xs[k] = v[0] + fr[0]; ys[k] = v[1] + fr[1];
                    zlo = Math.Min(zlo, v[2]); zhi = Math.Max(zhi, v[2]);
                }
                if (zhi < BandLo || zlo > BandHi) continue;        // under your feet / over your head
                if (zhi - zlo < 0.25f && zhi < 0.8f) continue;     // a floor or step you'd walk onto
                // ground you'd walk up: a face no steeper than the game lets you climb, starting at your feet (a big rock's
                // gentle flank, a ramp) - those were all marked solid, so whole slopes of sand were "in the way"
                if (n >= 3 && zlo < 0.8f)
                {
                    float[] p0 = Rot(fr, f[0], f[1], f[2]), p1 = Rot(fr, f[3], f[4], f[5]), p2 = Rot(fr, f[6], f[7], f[8]);
                    double ux = p1[0] - p0[0], uy = p1[1] - p0[1], uz = p1[2] - p0[2], vx = p2[0] - p0[0], vy = p2[1] - p0[1], vz = p2[2] - p0[2];
                    double nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx, nl = Math.Sqrt(nx * nx + ny * ny + nz * nz);
                    if (nl > 0 && Math.Abs(nz) / nl >= 0.664) continue;
                }
                FillPoly(solid, xs, ys);
            }
            foreach (float[] c in s.Circles)
            {
                if (c[3] * scale < BandLo || c[2] * scale > BandHi) continue;
                float[] v = Rot(fr, c[0] * scale, c[1] * scale, 0);
                FillCircle(solid, v[0] + fr[0], v[1] + fr[1], c[4] * scale);
            }
        }

        private static void StampRooms(byte[] solid, uint lb, HashSet<int> cells, ushort[] terrain, int lbx, int lby)
        {
            if (cells.Count == 0) return;
            Dictionary<uint, DCell> d = WorldMap.Dungeon((int)lb);
            if (d == null) return;
            foreach (int cid in cells)
            {
                DCell c;
                if (!d.TryGetValue((lb << 16) | (uint)cid, out c)) continue;
                // the ground floor only (an upper storey or a cellar isn't in your way out here)
                double gz = WorldMap.GroundZ(WorldMap.CellCoords(c.Id, c.X, c.Y));
                if (!double.IsNaN(gz) && Math.Abs(c.Z - gz) > 2.5) continue;
                List<float[]> fl = CellShapes.Floor(c);
                if (fl == null) continue;
                foreach (float[] pg in fl)
                {
                    if (pg[0] != 0) continue;
                    int nv = (pg.Length - 1) / 2;
                    if (nv < 3) continue;
                    float[] xs = new float[nv], ys = new float[nv];
                    for (int i = 0; i < nv; i++) { xs[i] = pg[1 + 2 * i]; ys[i] = pg[2 + 2 * i]; }
                    FillPoly(solid, xs, ys);
                }
            }
        }

        /// <summary>The whole of a building's outline seen from above, filled: a route was led in through its one door
        /// and stuck inside it.</summary>
        private static void StampFootprint(byte[] solid, uint id, float[] fr)
        {
            Shape s = ShapeOf(id);
            List<double[]> pts = new List<double[]>();
            foreach (float[] f in s.Faces)
            {
                int n = f.Length / 3;
                for (int k = 0; k < n; k++)
                {
                    float[] v = Rot(fr, f[k * 3], f[k * 3 + 1], f[k * 3 + 2]);
                    if (v[2] < BandLo - 0.5f || v[2] > 12f) continue;   // its walls near the ground, not an overhanging roof
                    pts.Add(new double[] { v[0] + fr[0], v[1] + fr[1] });
                }
            }
            if (pts.Count < 3) return;
            pts.Sort((a, b) => a[0] != b[0] ? a[0].CompareTo(b[0]) : a[1].CompareTo(b[1]));
            List<double[]> h = new List<double[]>();
            for (int pass = 0; pass < 2; pass++)
            {
                int start = h.Count;
                for (int i = 0; i < pts.Count; i++)
                {
                    double[] p = pass == 0 ? pts[i] : pts[pts.Count - 1 - i];
                    while (h.Count >= start + 2)
                    {
                        double[] a = h[h.Count - 2], b = h[h.Count - 1];
                        if ((b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0]) <= 0) h.RemoveAt(h.Count - 1); else break;
                    }
                    h.Add(p);
                }
                h.RemoveAt(h.Count - 1);
            }
            if (h.Count < 3) return;
            // (a huge one - a walled town, a plaza model - isn't one building's inside)
            double area = 0;
            for (int i = 0; i < h.Count; i++) { double[] a = h[i], b = h[(i + 1) % h.Count]; area += a[0] * b[1] - b[0] * a[1]; }
            if (Math.Abs(area) / 2 > 900) return;
            float[] xs = new float[h.Count], ys = new float[h.Count];
            for (int i = 0; i < h.Count; i++) { xs[i] = (float)h[i][0]; ys[i] = (float)h[i][1]; }
            FillPoly(solid, xs, ys);
        }

        private static void FillCircle(byte[] g, double cx, double cy, double r)
        {
            int x0 = (int)Math.Floor((cx - r) / Res), x1 = (int)Math.Ceiling((cx + r) / Res), y0 = (int)Math.Floor((cy - r) / Res), y1 = (int)Math.Ceiling((cy + r) / Res);
            for (int x = Math.Max(0, x0); x <= Math.Min(N - 1, x1); x++)
                for (int y = Math.Max(0, y0); y <= Math.Min(N - 1, y1); y++)
                {
                    double dx = (x + 0.5) * Res - cx, dy = (y + 0.5) * Res - cy;
                    if (dx * dx + dy * dy <= r * r) g[x * N + y] = 1;
                }
        }

        /// <summary>A face seen from above: filled (a wall seen edge-on is its line).</summary>
        private static void FillPoly(byte[] g, float[] xs, float[] ys)
        {
            int n = xs.Length;
            for (int k = 0; k < n; k++) Line(g, xs[k], ys[k], xs[(k + 1) % n], ys[(k + 1) % n]);
            if (n < 3) return;
            float minY = float.MaxValue, maxY = float.MinValue;
            for (int k = 0; k < n; k++) { minY = Math.Min(minY, ys[k]); maxY = Math.Max(maxY, ys[k]); }
            List<float> cut = new List<float>();
            for (int gy = Math.Max(0, (int)Math.Floor(minY / Res)); gy <= Math.Min(N - 1, (int)Math.Ceiling(maxY / Res)); gy++)
            {
                float yc = (float)((gy + 0.5) * Res); cut.Clear();
                for (int k = 0; k < n; k++)
                {
                    float y1 = ys[k], y2 = ys[(k + 1) % n];
                    if ((y1 <= yc && y2 > yc) || (y2 <= yc && y1 > yc)) cut.Add(xs[k] + (yc - y1) / (y2 - y1) * (xs[(k + 1) % n] - xs[k]));
                }
                cut.Sort();
                for (int k = 0; k + 1 < cut.Count; k += 2)
                    for (int gx = Math.Max(0, (int)Math.Floor(cut[k] / Res)); gx <= Math.Min(N - 1, (int)Math.Floor(cut[k + 1] / Res)); gx++) g[gx * N + gy] = 1;
            }
        }

        private static void Line(byte[] g, double x0, double y0, double x1, double y1)
        {
            double len = Math.Sqrt((x1 - x0) * (x1 - x0) + (y1 - y0) * (y1 - y0));
            int steps = Math.Max(1, (int)Math.Ceiling(len / (Res * 0.5)));
            for (int i = 0; i <= steps; i++)
            {
                double f = (double)i / steps;
                int gx = (int)Math.Floor((x0 + (x1 - x0) * f) / Res), gy = (int)Math.Floor((y0 + (y1 - y0) * f) / Res);
                if (gx >= 0 && gy >= 0 && gx < N && gy < N) g[gx * N + gy] = 1;
            }
        }

        // ── small helpers ──
        private static float[] Frame(byte[] b, ref int p)
        {
            float[] f = new float[7];
            for (int i = 0; i < 7; i++) f[i] = F(b, ref p);   // x y z, then the turn: w x y z
            return f;
        }

        /// <summary>A point turned by a frame's turn (no move).</summary>
        private static float[] Rot(float[] fr, float x, float y, float z)
        {
            float w = fr[3], qx = fr[4], qy = fr[5], qz = fr[6];
            float tx = 2 * (qy * z - qz * y), ty = 2 * (qz * x - qx * z), tz = 2 * (qx * y - qy * x);
            return new[] { x + w * tx + (qy * tz - qz * ty), y + w * ty + (qz * tx - qx * tz), z + w * tz + (qx * ty - qy * tx) };
        }

        private static float[] Xf(float[] fr, float[] v) { float[] r = Rot(fr, v[0], v[1], v[2]); r[0] += fr[0]; r[1] += fr[1]; r[2] += fr[2]; return r; }

        private static uint U32(byte[] b, ref int p) { uint v = BitConverter.ToUInt32(b, p); p += 4; return v; }
        private static float F(byte[] b, ref int p) { float v = BitConverter.ToSingle(b, p); p += 4; return v; }
        private static void Align(ref int p) { p = (p + 3) & ~3; }
        private static void PStr(byte[] b, ref int p) { int len = BitConverter.ToUInt16(b, p); p += 2; p += len; }
        private static uint CU32(byte[] b, ref int p)
        {
            byte b0 = b[p++];
            if ((b0 & 0x80) == 0) return b0;
            byte b1 = b[p++];
            if ((b0 & 0x40) == 0) return (uint)(((b0 & 0x7F) << 8) | b1);
            ushort s = BitConverter.ToUInt16(b, p); p += 2;
            return (uint)(((((b0 & 0x3F) << 8) | b1) << 16) | s);
        }
    }
}
