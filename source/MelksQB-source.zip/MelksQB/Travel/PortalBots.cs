using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;
using System.Xml;
using Decal.Adapter;
using Decal.Adapter.Wrappers;

namespace MelksQuestTracker.Travel
{
    /// <summary>One place a portal bot sends you: the word you tell it, where it says it goes, and (once used, or worked
    /// out from the list) where its portal really puts you.</summary>
    internal class BotDest
    {
        public string Word = "", Dest = "";
        public string PortalName = "";      // the game's name for the portal it opens (seen once used)
        public Coords Exit = Coords.None;
        public int ExitArea = -1;
        public bool Guessed;                // the exit is the list's place of that name, not where the portal was seen to go
        public long Ticks;
    }

    internal class PortalBot
    {
        public string Name = "";
        public Coords At = Coords.None;
        public int Area = -1;
        public double Z = double.NaN;
        public uint Cell;
        public long Ticks;
        public readonly List<BotDest> Dests = new List<BotDest>();
    }

    /// <summary>
    /// Portal bots (Korway in the Town Network): an NPC that opens a portal to where you ask, when you send it a tell
    /// with the word it gave you. Learned from its own tells ("Say swamp for a portal to the East Direlands Swamp."), and
    /// where it stands from seeing it. The portals it opens aren't learned as portals that stay there (they're only there
    /// a moment), and aren't drawn on the map; each of its places is a step routes can use instead: walk up to it, send
    /// the tell, go through the portal it opens. Kept in MQT_PortalBots.xml, shared by every client.
    /// </summary>
    internal static class PortalBots
    {
        public static readonly Dictionary<string, PortalBot> All = new Dictionary<string, PortalBot>(StringComparer.OrdinalIgnoreCase);
        public static int Version;
        public const double ZoneM = 8;   // its portals open within this of it
        public static double SummonSecs = 6;   // the tell, and waiting for the portal

        private static string FilePath { get { return Util.FullPath("MQT_PortalBots.xml"); } }
        private static readonly CultureInfo CI = CultureInfo.InvariantCulture;

        private static readonly Regex OfferRx = new Regex(@"^(?<bot>[^""]+?) tells you, ""Say (?<w>[^""\s]+) for a portal (?:directly )?to (?:the )?(?<d>.+?)(?:\s+-\s.*?)?[.!]?""$", RegexOptions.IgnoreCase);
        private static readonly Regex IAmRx = new Regex(@"^(?<bot>[^""]+?) tells you, ""I am a portal bot", RegexOptions.IgnoreCase);

        // ── where its portals open ──
        public static bool InZone(Coords at, int area)
        {
            if (!at.Valid) return false;
            foreach (PortalBot b in All.Values)
                if (b.At.Valid && TravelData.SameArea(b.Area, area) && b.At.DistanceTo(at) * 240.0 < ZoneM) return true;
            return false;
        }

        public static bool IsBotName(string n) { return !string.IsNullOrEmpty(n) && All.ContainsKey(n); }

        // ── learning ──
        /// <summary>Chat: its tells name it and list its words.</summary>
        public static void OnChat(string t)
        {
            try
            {
                Match m = OfferRx.Match(t ?? "");
                if (m.Success)
                {
                    PortalBot b = Bot(m.Groups["bot"].Value.Trim());
                    string w = m.Groups["w"].Value.Trim(), d = m.Groups["d"].Value.Trim();
                    BotDest bd = b.Dests.Find(x => string.Equals(x.Word, w, StringComparison.OrdinalIgnoreCase));
                    if (bd == null) { bd = new BotDest { Word = w, Dest = d, Ticks = DateTime.UtcNow.Ticks }; b.Dests.Add(bd); Changed(); }
                    else if (!string.Equals(bd.Dest, d, StringComparison.OrdinalIgnoreCase)) { bd.Dest = d; bd.Exit = Coords.None; bd.Guessed = false; bd.PortalName = ""; bd.Ticks = DateTime.UtcNow.Ticks; Changed(); }
                    if (!bd.Exit.Valid) Guess(bd);
                    return;
                }
                m = IAmRx.Match(t ?? "");
                if (m.Success) Bot(m.Groups["bot"].Value.Trim());
            }
            catch (Exception ex) { Util.LogError(ex); }
        }

        private static PortalBot Bot(string name)
        {
            PortalBot b;
            if (!All.TryGetValue(name, out b))
            {
                b = new PortalBot { Name = name, Ticks = DateTime.UtcNow.Ticks };
                All[name] = b;
                Changed();
                Util.WriteToChat("Travel: " + name + " is a portal bot - its places can be used for routes once it's been seen.");
            }
            Locate(b);
            return b;
        }

        /// <summary>Every few seconds: where each bot stands, if it's in sight (it shows on the dungeon's map as one).</summary>
        public static void Tick()
        {
            if (All.Count == 0) return;
            foreach (PortalBot b in All.Values) Locate(b);
            Flush();
        }

        private static void Locate(PortalBot b)
        {
            try
            {
                WorldObject o = null;
                foreach (WorldObject x in CoreManager.Current.WorldFilter.GetLandscape())
                    if (string.Equals(x.Name, b.Name, StringComparison.OrdinalIgnoreCase)) { o = x; break; }
                if (o == null) return;
                CoordsObject c = o.Coordinates();
                Coords at = new Coords(c.NorthSouth, c.EastWest);
                uint cell = 0; try { cell = (uint)o.Values(LongValueKey.Landblock); } catch { }
                double z = double.NaN; try { z = o.RawCoordinates().Z; } catch { }
                int area = TravelData.AreaOfCell(cell);
                if (b.At.Valid && b.At.DistanceTo(at) * 240.0 < 1.5 && b.Area == area) return;
                b.At = at; b.Area = area; b.Cell = (cell & 0xFFFF) >= 0x100 ? cell : 0; b.Z = z; b.Ticks = DateTime.UtcNow.Ticks;
                Changed();
                // on the dungeon's map as itself (once)
                if (area >= 0)
                {
                    string din = Travel.DungeonIn(area);
                    bool have = false;
                    foreach (TravelData.Point p in TravelData.Points.Values)
                        if (p.In == din && p.Type == "Portal bot" && string.Equals(p.Name, b.Name, StringComparison.OrdinalIgnoreCase) && p.At.DistanceTo(at) * 240 < 3) { have = true; break; }
                    if (!have) TravelData.AddPoint(new TravelData.Point { Name = b.Name, Type = "Portal bot", At = at, Z = z, In = din, Auto = true, Notes = "Opens portals: send it a tell with the word." });
                }
                TravelData.NeedRebuild = true;
            }
            catch { }
        }

        /// <summary>A portal by a bot was used (or seen): where it goes is that place's exit. True = it was the bot's (not learned as a portal).</summary>
        public static bool LearnExit(string portalName, Coords at, int area, Coords exit, int exitArea)
        {
            if (!InZone(at, area)) return false;
            if (!exit.Valid) return true;
            PortalBot b = Nearest(at, area);
            if (b == null) return true;
            BotDest best = null; double bs = 0;
            foreach (BotDest d in b.Dests)
            {
                double s = string.Equals(d.PortalName, portalName, StringComparison.OrdinalIgnoreCase) ? 2 : Match(d.Dest, portalName);
                if (s > bs) { bs = s; best = d; }
            }
            if (best == null || bs < 0.5) return true;
            if (best.Exit.Valid && !best.Guessed && best.Exit.DistanceTo(exit) < 0.05 && best.ExitArea == exitArea && best.PortalName == portalName) return true;
            best.PortalName = portalName; best.Exit = exit; best.ExitArea = exitArea; best.Guessed = false; best.Ticks = DateTime.UtcNow.Ticks;
            Changed();
            return true;
        }

        private static PortalBot Nearest(Coords at, int area)
        {
            PortalBot best = null; double bd = double.MaxValue;
            foreach (PortalBot b in All.Values)
            {
                if (!b.At.Valid || !TravelData.SameArea(b.Area, area)) continue;
                double d = b.At.DistanceTo(at);
                if (d < bd) { bd = d; best = b; }
            }
            return best;
        }

        // ── names ──
        private static readonly HashSet<string> Small = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "the", "of", "to", "a", "portal", "for", "and", "in", "at" };
        private static List<string> Words(string s)
        {
            List<string> l = new List<string>();
            foreach (string w in Regex.Split((s ?? "").Replace('`', '\'').Replace('’', '\'').ToLowerInvariant(), @"[^a-z0-9']+"))
                if (w.Length > 0 && !Small.Contains(w)) l.Add(w.EndsWith("'s") ? w.Substring(0, w.Length - 2) : w);
            return l;
        }

        /// <summary>How well a name fits where the bot says it goes: the share of the shorter one's words in the other (0..1), 0 unless the first words agree.</summary>
        private static double Match(string dest, string name)
        {
            List<string> a = Words(dest), b = Words(name);
            if (a.Count == 0 || b.Count == 0) return 0;
            if (a[0] != b[0] && !b.Contains(a[0]) && !a.Contains(b[0])) return 0;
            List<string> sh = a.Count <= b.Count ? a : b, lo = a.Count <= b.Count ? b : a;
            int n = 0; foreach (string w in sh) if (lo.Contains(w)) n++;
            return (double)n / sh.Count * (sh.Count == lo.Count ? 1 : 0.95);
        }

        /// <summary>Not used yet: the exit of a portal elsewhere with that name, else the list's place of that name.</summary>
        private static void Guess(BotDest d)
        {
            Loc best = null; double bs = 0; bool bestPortal = false;
            foreach (Loc l in TravelData.Locs)
            {
                if (!l.At.Valid || InZone(l.At, l.Area)) continue;
                double s = Match(d.Dest, l.Name);
                if (s < 0.99) continue;
                bool portal = l.HasExit;
                // a portal of that name (it goes there) beats the place itself; the place beats a portal elsewhere that merely shares words
                if (best == null || s > bs || (s == bs && portal && !bestPortal)) { best = l; bs = s; bestPortal = portal; }
            }
            if (best == null) return;
            if (bestPortal) { d.Exit = best.Exit; d.ExitArea = best.ExitArea; }
            else { d.Exit = best.At; d.ExitArea = best.Area; }
            d.Guessed = true;
            Changed();
        }

        /// <summary>Portals already learned where a bot opens them (before it was known as one): their exits go to its places.</summary>
        public static void TakeLearned()
        {
            foreach (Loc p in TravelData.LearnedPortals.Values)
                if (p.HasExit && InZone(p.At, p.Area)) LearnExit(p.Name, p.At, p.Area, p.Exit, p.ExitArea);
            foreach (PortalBot b in All.Values) foreach (BotDest d in b.Dests) if (!d.Exit.Valid) Guess(d);
        }

        /// <summary>For the router: each place a bot sends you, as a portal at the bot (Loc.BotName / BotWord set).</summary>
        public static List<Loc> RouteLocs()
        {
            List<Loc> l = new List<Loc>();
            foreach (PortalBot b in All.Values)
            {
                if (!b.At.Valid) continue;
                foreach (BotDest d in b.Dests)
                {
                    if (!d.Exit.Valid) continue;
                    l.Add(new Loc { Name = d.PortalName.Length > 0 ? d.PortalName : d.Dest, Type = "Portal bot", At = b.At, Area = b.Area, Exit = d.Exit, ExitArea = d.ExitArea,
                                    Cell = b.Cell, Learned = true, BotName = b.Name, BotWord = d.Word, Notes = d.Dest });
                }
            }
            return l;
        }

        // ── file ──
        private static bool _dirty;
        private static DateTime _stamp = DateTime.MinValue;
        private static void Changed() { _dirty = true; Version++; }

        public static void Load()
        {
            try
            {
                string p = FilePath;
                if (!File.Exists(p)) return;
                DateTime w = File.GetLastWriteTimeUtc(p);
                if (w == _stamp) return;
                _stamp = w;
                XmlDocument doc = new XmlDocument();
                Util.LoadXml(doc, p);
                Merge(doc);
                Version++;
            }
            catch (Exception ex) { Util.LogError(ex); }
        }

        /// <summary>Theirs into ours: the newer of each wins.</summary>
        private static void Merge(XmlDocument doc)
        {
            if (doc.DocumentElement == null) return;
            foreach (XmlNode n in doc.DocumentElement.SelectNodes("bot"))
            {
                string name = A(n, "n");
                if (name.Length == 0) continue;
                long t = L(A(n, "t"));
                PortalBot b;
                if (!All.TryGetValue(name, out b)) { b = new PortalBot { Name = name }; All[name] = b; }
                if (t > b.Ticks)
                {
                    b.At = Coords.FromRaw(A(n, "a")); b.Ticks = t;
                    int ar; b.Area = int.TryParse(A(n, "al"), NumberStyles.Integer, CI, out ar) ? ar : -1;
                    double z; b.Z = double.TryParse(A(n, "z"), NumberStyles.Float, CI, out z) ? z : double.NaN;
                    uint c; b.Cell = uint.TryParse(A(n, "c"), NumberStyles.HexNumber, CI, out c) ? c : 0;
                }
                foreach (XmlNode dn in n.SelectNodes("dest"))
                {
                    string w = A(dn, "w");
                    if (w.Length == 0) continue;
                    long dt = L(A(dn, "t"));
                    BotDest d = b.Dests.Find(x => string.Equals(x.Word, w, StringComparison.OrdinalIgnoreCase));
                    if (d == null) { d = new BotDest { Word = w }; b.Dests.Add(d); }
                    else if (d.Ticks >= dt) continue;
                    d.Dest = A(dn, "d"); d.PortalName = A(dn, "pn"); d.Exit = Coords.FromRaw(A(dn, "e")); d.Guessed = A(dn, "g") == "1"; d.Ticks = dt;
                    int ea; d.ExitArea = int.TryParse(A(dn, "el"), NumberStyles.Integer, CI, out ea) ? ea : -1;
                }
            }
        }

        public static void Flush()
        {
            if (!_dirty) return;
            _dirty = false;
            string path = FilePath;
            Util.Locked(path, () =>
            {
                try
                {
                    if (File.Exists(path)) { XmlDocument cur = new XmlDocument(); try { cur.Load(path); Merge(cur); } catch { } }
                    XmlDocument doc = new XmlDocument();
                    XmlElement root = doc.CreateElement("MQT_PortalBots");
                    doc.AppendChild(root);
                    foreach (PortalBot b in All.Values)
                    {
                        XmlElement e = doc.CreateElement("bot");
                        e.SetAttribute("n", b.Name);
                        if (b.At.Valid) e.SetAttribute("a", b.At.Raw());
                        e.SetAttribute("al", b.Area.ToString(CI));
                        if (!double.IsNaN(b.Z)) e.SetAttribute("z", b.Z.ToString("0.00", CI));
                        if (b.Cell != 0) e.SetAttribute("c", b.Cell.ToString("X8"));
                        e.SetAttribute("t", b.Ticks.ToString(CI));
                        foreach (BotDest d in b.Dests)
                        {
                            XmlElement de = doc.CreateElement("dest");
                            de.SetAttribute("w", d.Word); de.SetAttribute("d", d.Dest);
                            if (d.PortalName.Length > 0) de.SetAttribute("pn", d.PortalName);
                            if (d.Exit.Valid) { de.SetAttribute("e", d.Exit.Raw()); de.SetAttribute("el", d.ExitArea.ToString(CI)); }
                            if (d.Guessed) de.SetAttribute("g", "1");
                            de.SetAttribute("t", d.Ticks.ToString(CI));
                            e.AppendChild(de);
                        }
                        root.AppendChild(e);
                    }
                    string tmp = path + ".tmp";
                    doc.Save(tmp);
                    if (File.Exists(path)) File.Delete(path);
                    File.Move(tmp, path);
                }
                catch (Exception ex) { Util.LogError(ex); }
            });
            try { _stamp = File.GetLastWriteTimeUtc(path); } catch { }
            TravelData.NeedRebuild = true;
        }

        private static string A(XmlNode n, string k) { XmlAttribute a = n.Attributes == null ? null : n.Attributes[k]; return a == null ? "" : a.Value; }
        private static long L(string s) { long v; return long.TryParse(s, NumberStyles.Integer, CI, out v) ? v : 0; }
    }
}
