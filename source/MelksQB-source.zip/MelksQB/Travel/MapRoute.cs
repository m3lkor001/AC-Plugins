using System;
using System.Collections.Generic;
using System.Globalization;
using ImGuiNET;
using Vec2 = System.Numerics.Vector2;
using Vec4 = System.Numerics.Vector4;

namespace MelksQuestTracker.Travel
{
    /// <summary>
    /// A quick route made on the map: right-click "Add next nav point here" - MelkTank keeps it as its "Map route" (the
    /// first point starts a new one), picked as Nav's route; turn Nav on to run it. Drawn on the map from what MelkTank
    /// says it holds (AppDomain "MelkTank.MapRoute").
    /// </summary>
    internal static class MapRoute
    {
        private const string Key = "MelkTank.MapRoute";
        private static readonly CultureInfo CI = CultureInfo.InvariantCulture;
        private static string _raw;
        private static List<double[]> _pts = new List<double[]>();

        /// <summary>The points (ns, ew, z), as MelkTank has them.</summary>
        public static List<double[]> Points()
        {
            string v = null;
            try { v = AppDomain.CurrentDomain.GetData(Key) as string; } catch { }
            v = v ?? "";
            if (v == _raw) return _pts;
            _raw = v;
            List<double[]> l = new List<double[]>();
            foreach (string p in v.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries))
            {
                string[] f = p.Split(',');
                double ns, ew, z = 0;
                if (f.Length < 2 || !double.TryParse(f[0], NumberStyles.Float, CI, out ns) || !double.TryParse(f[1], NumberStyles.Float, CI, out ew)) continue;
                if (f.Length > 2) double.TryParse(f[2], NumberStyles.Float, CI, out z);
                l.Add(new[] { ns, ew, z });
            }
            _pts = l;
            return l;
        }

        public static void Add(Coords at, double z)
        {
            if (!at.Valid) return;
            if (double.IsNaN(z)) z = 0;
            Util.Command("/mtank maproute add " + at.NS.ToString("0.#####", CI) + " " + at.EW.ToString("0.#####", CI) + " " + z.ToString("0.##", CI));
        }

        public static void Clear() { Util.Command("/mtank maproute clear"); }

        /// <summary>The right-click menu's items.</summary>
        public static void MenuItems(Coords at, double z)
        {
            if (ImGui.MenuItem("Add next nav point here")) Add(at, z);
            if (ImGui.IsItemHovered()) Im.SetTooltip("A quick route for MelkTank's Nav (its \"Map route\"): the first point starts a new one, each next one is added on.\nIt's picked as Nav's route - turn Nav on to run it. Runs once (change it on Nav > Routes to run back and forth).");
            if (Points().Count > 0 && ImGui.MenuItem("Clear the map route")) Clear();
        }

        /// <summary>On the map: numbered points joined by a line. S takes (ns, ew, z); null = not on this map.</summary>
        public static void Draw(ImDrawListPtr dl, Func<double, double, double, Vec2?> S)
        {
            List<double[]> l = Points();
            if (l.Count == 0) return;
            uint col = ImGui.GetColorU32(new Vec4(0.3f, 1f, 1f, 1f)), black = ImGui.GetColorU32(new Vec4(0, 0, 0, 0.9f));
            Vec2? prev = null;
            for (int i = 0; i < l.Count; i++)
            {
                Vec2? a = S(l[i][0], l[i][1], l[i][2]);
                if (a == null) { prev = null; continue; }
                if (prev != null) dl.AddLine(prev.Value, a.Value, col, 2f);
                dl.AddCircleFilled(a.Value, 5f, col);
                dl.AddCircle(a.Value, 5f, black);
                string t = (i + 1).ToString(CI);
                if (!string.IsNullOrEmpty(t)) dl.AddText(new Vec2(a.Value.X + 7, a.Value.Y - 7), black, t);
                if (!string.IsNullOrEmpty(t)) dl.AddText(new Vec2(a.Value.X + 6, a.Value.Y - 8), col, t);
                prev = a;
            }
        }
    }
}
