using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Xml;

namespace MelksQuestTracker.Travel
{
    /// <summary>
    /// Auto travel: the route turned into a MelkTank nav route (walk points around the ground / through the dungeon's cells, use
    /// the portal, cast the recall, use the gem, type the command) and handed to MelkTank, which does the moving. Moving
    /// yourself stops it (MelkTank says so in chat).
    /// </summary>
    internal static class AutoTravel
    {
        public static bool On;
        public static bool FightOnTheWay = true;   // Config: stop for monsters (MelkTank's combat) - else combat is off for the trip
        public static string Status = "";
        public const string RouteName = "MelksQB Travel";

        public static string FilePath { get { return Util.FullPath(System.IO.Path.Combine("Travel", RouteName + ".mtnav")); } }

        public static void Toggle() { if (On) Stop(true); else Start(); }

        // ── "Show route": the trip drawn in the world by MelkTank (rings, step numbers, dots; portals in yellow), not walked ──
        public static bool Showing;
        private static string _shownLegs = "";
        public static string PreviewPath { get { return Util.FullPath(System.IO.Path.Combine("Travel", RouteName + " (shown).mtnav")); } }

        public static void ToggleShow()
        {
            if (Showing) { HideRoute(); return; }
            if (!Travel.Active || Travel.Route == null) { Util.WriteToChat("Travel: no route to show."); return; }
            Showing = true; _shownLegs = "";
            ShowTick();
        }

        public static void HideRoute()
        {
            if (!Showing) return;
            Showing = false; _shownLegs = "";
            Util.Command("/mtank travel hide");
        }

        /// <summary>4 times a second: the drawing follows the route as it changes (a new step, a reroute).</summary>
        public static void ShowTick()
        {
            if (!Showing) return;
            if (On || !Travel.Active || Travel.Route == null || Travel.Arrived) { if (!On) HideRoute(); else { Showing = false; _shownLegs = ""; } return; }
            string sig = LegSig() + "@" + Travel.Step;
            if (sig == _shownLegs) return;
            _shownLegs = sig;
            int n;
            try { n = Write(PreviewPath); } catch (Exception ex) { Util.LogError(ex); n = 0; }
            if (n == 0) { HideRoute(); return; }
            Util.Command("/mtank travel show " + PreviewPath);
        }

        // MelkTank says what it's doing in AppDomain data (see its NavTravel.cs): "running|ticks", "finished|ticks",
        // "stopped|ticks|why". Chat lines one plugin writes aren't seen by another.
        private const string StateKey = "MelkTank.Travel";
        private static long _sentTicks;
        private static DateTime _sentAt = DateTime.MinValue;
        private static string _sentLegs = "";
        private static int _offRoute;
        public static bool ForceNext;

        public static void Start()
        {
            if (!Travel.Active) { Util.WriteToChat("Travel: pick a destination first."); return; }
            if (Travel.Arrived && (!Travel.AtDestHeight() || !Travel.NearDest())) { Travel.Arrived = false; Travel.Reroute(false); }   // "there" was on another floor / short of it
            if (Travel.Arrived) { Util.WriteToChat("Travel: you're there."); return; }
            if (Travel.ArrowOnly) Travel.GoTo(Travel.DestAt, Travel.DestArea, Travel.DestName, 1);   // auto travel needs the route
            if (Travel.Route == null) { Util.WriteToChat("Travel: no route to follow."); return; }
            _offRoute = 0;
            Showing = false; _shownLegs = "";   // (MelkTank drops the drawing when it starts walking)
            On = true;
            if (!Send()) { On = false; Util.WriteToChat("Travel: nothing to do - you're there."); }
        }

        private static bool Send()
        {
            int n;
            try { n = Write(); } catch (Exception ex) { Util.LogError(ex); n = 0; }
            if (n == 0) return false;
            _sentLegs = LegSig();
            _sentTicks = DateTime.UtcNow.Ticks;
            _sentAt = DateTime.Now;
            Util.Command("/mtank travel " + (FightOnTheWay ? "fight" : "nofight") + " " + FilePath);
            return true;
        }

        /// <summary>The steps still to do, as text: the same steps aren't sent to MelkTank again (it would stop and start over).</summary>
        private static string LegSig()
        {
            StringBuilder sb = new StringBuilder();
            Route r = Travel.Route;
            if (r != null)
                for (int i = Travel.Step; i < r.Legs.Count; i++)
                    sb.Append(r.Legs[i].Kind).Append('|').Append(r.Legs[i].Name).Append('|').Append(r.Legs[i].Target.Raw()).Append(';');
            return sb.ToString();
        }

        public static void Stop(bool tellMelkTank)
        {
            if (!On) return;
            On = false;
            Status = "";
            if (tellMelkTank) Util.Command("/mtank travel stop");
        }

        /// <summary>The route changed, or you've just come out of a portal / recall: MelkTank gets the rest of the trip,
        /// planned from where you really are. force = send it even if the steps are the same as last time.</summary>
        public static void RouteChanged(bool force)
        {
            if (ForceNext) { force = true; ForceNext = false; }
            if (!On) return;
            if (Travel.Route == null || !Travel.Active || Travel.Arrived) { Stop(true); return; }
            if (!force && LegSig() == _sentLegs) return;
            if (!Send()) Stop(true);
        }

        /// <summary>You came out somewhere the route didn't expect. More than 4 times in one trip: give up rather than go round in circles.</summary>
        public static void OffRoute()
        {
            if (!On) return;
            if (++_offRoute > 4)
            {
                Stop(true);
                Travel.Note = "Auto travel stopped - kept ending up off the route.";
                Util.WriteToChat("Travel: auto travel stopped - you kept ending up somewhere the route didn't expect.");
                return;
            }
            ForceNext = true;
        }

        /// <summary>4 times a second: has MelkTank finished, stopped (you moved, it got stuck ...), or never answered?</summary>
        public static void Tick()
        {
            if (!On) return;
            string st = null;
            try { st = AppDomain.CurrentDomain.GetData(StateKey) as string; } catch { }
            string[] p = (st ?? "").Split(new[] { '|' }, 3);
            long ticks = 0;
            if (p.Length >= 2) long.TryParse(p[1], out ticks);
            if (ticks >= _sentTicks && p[0] != "")
            {
                if (p[0] == "running") return;
                On = false;
                Status = "";
                if (p[0] == "stopped") Travel.Note = "Auto travel stopped - " + (p.Length > 2 ? p[2] : "") + ".";
                return;
            }
            if ((DateTime.Now - _sentAt).TotalSeconds > 3)
            {
                On = false;
                Status = "";
                Travel.Note = "Auto travel: MelkTank didn't answer (it needs to be running, b296 or newer).";
                Util.WriteToChat("Travel: MelkTank didn't answer - auto travel needs MelkTank (b296 or newer) running.");
            }
        }

        // ── building the nav route ──
        private class Step { public string Kind; public double NS, EW, Z; public string Text = ""; public int Wait = 1000; }

        private static int Write() { return Write(FilePath); }

        private static int Write(string path)
        {
            List<Step> steps = Build();
            if (steps.Count == 0) return 0;
            XmlDocument doc = new XmlDocument();
            XmlElement re = doc.CreateElement("MelkTankRoute");
            doc.AppendChild(re);
            re.SetAttribute("name", RouteName);
            re.SetAttribute("mode", "0");
            re.SetAttribute("arrive", "2.5");
            re.SetAttribute("stuck", "2"); re.SetAttribute("stuckback", "2"); re.SetAttribute("stuckafter", "1");
            foreach (Step s in steps)
            {
                XmlElement e = doc.CreateElement("Step");
                e.SetAttribute("kind", s.Kind);
                e.SetAttribute("ns", s.NS.ToString("R", CultureInfo.InvariantCulture));
                e.SetAttribute("ew", s.EW.ToString("R", CultureInfo.InvariantCulture));
                e.SetAttribute("z", s.Z.ToString("R", CultureInfo.InvariantCulture));
                e.SetAttribute("text", s.Text ?? "");
                e.SetAttribute("wait", s.Wait.ToString(CultureInfo.InvariantCulture));
                re.AppendChild(e);
            }
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            doc.Save(path);
            return steps.Count;
        }

        private static List<Step> Build()
        {
            List<Step> l = new List<Step>();
            Route r = Travel.Route;
            if (r == null) return l;
            Coords pos = Travel.Here();
            int area = Travel.HereArea();
            uint cell = Travel.Cell();
            if ((cell & 0xFFFF) < 0x100) cell = 0;
            StringBuilder how = new StringBuilder();
            for (int i = Travel.Step; i < r.Legs.Count; i++)
            {
                Leg g = r.Legs[i];
                switch (g.Kind)
                {
                    case "spell":
                        l.Add(new Step { Kind = "Cast", Text = g.Opt != null ? g.Opt.SpellId.ToString(CultureInfo.InvariantCulture) : "0", Wait = 1000 });
                        break;
                    case "gem":
                        if (g.Opt != null && g.Opt.OpensPortal)
                        {
                            // it opens a portal: use the gem, then go through the portal that's appeared by you (MelkTank takes
                            // the nearest portal to this spot for a travel route's nameless Use step)
                            l.Add(new Step { Kind = "UseItem", Text = g.Name, Wait = 4000 });
                            l.Add(new Step { Kind = "Use", NS = pos.NS, EW = pos.EW, Z = 0, Text = "", Wait = 1000 });
                        }
                        else l.Add(new Step { Kind = "UseItem", Text = g.Name, Wait = 10000 });
                        break;
                    case "cmd":
                        l.Add(new Step { Kind = "Command", Text = g.Name, Wait = g.Name == "/ls" ? 25000 : 10000 });
                        break;
                    case "portal":
                        {
                            uint pc = PortalCell(g);
                            List<Pt> path = Densify(pos, PathPlan.Walk(pos, area, cell, g.Target, g.TargetArea, pc));
                            how.Append(PathPlan.Last).Append("; ");
                            // walk up to it, but not into it (walking into a portal takes it before the Use step) - Use walks the last bit
                            AddWalk(l, path, 1);
                            Pt last = path[path.Count - 1];
                            if (g.TargetArea < 0)
                            {
                                // outdoors: stop 5 m short of it (indoors the room before it is close enough)
                                Coords prev = path.Count > 1 ? path[path.Count - 2].C : pos;
                                double dm = prev.DistanceTo(g.Target) * 240.0;
                                if (dm > 7)
                                {
                                    double f = 5.0 / dm;
                                    l.Add(Point(new Pt(g.Target.NS + (prev.NS - g.Target.NS) * f, g.Target.EW + (prev.EW - g.Target.EW) * f, last.Z, 0)));
                                }
                            }
                            if (g.Bot.Length > 0)
                            {
                                // a portal bot: tell it the word, then go through the portal it opens by it
                                l.Add(new Step { Kind = "Command", Text = g.Say, Wait = 2500 });
                                l.Add(new Step { Kind = "Use", NS = g.Target.NS, EW = g.Target.EW, Z = last.Z, Text = g.Name, Wait = 1000 });
                                break;
                            }
                            l.Add(new Step { Kind = "Use", NS = g.Target.NS, EW = g.Target.EW, Z = last.Z, Text = g.Name, Wait = 1000 });
                            break;
                        }
                    case "run":
                        {
                            uint dc = Travel.DestCell != 0 && g.TargetArea >= 0 && g.Target.Raw() == Travel.DestAt.Raw() ? Travel.DestCell : 0;   // a room picked on a dungeon map
                            List<Pt> path = Densify(pos, PathPlan.Walk(pos, area, cell, g.Target, g.TargetArea, dc));
                            how.Append(PathPlan.Last).Append("; ");
                            AddWalk(l, path, 0);
                            break;
                        }
                }
                if (g.Exit.Valid) { pos = g.Exit; area = g.ExitArea; cell = 0; }
                else if (g.Target.Valid) { pos = g.Target; area = g.TargetArea; }
            }
            Status = how.ToString().TrimEnd(' ', ';');
            return l;
        }

        /// <summary>Outdoors, a point every 48 m or so along each straight bit (MelkTank's nav won't run at a point
        /// further than its "don't run more than" distance).</summary>
        private static List<Pt> Densify(Coords from, List<Pt> path)
        {
            List<Pt> l = new List<Pt>();
            Coords a = from;
            foreach (Pt p in path)
            {
                double d = a.Valid ? a.DistanceTo(p.C) : 0;
                if (p.Cell == 0 && d > 0.25)
                {
                    int n = (int)Math.Ceiling(d / 0.2);
                    for (int i = 1; i < n; i++)
                    {
                        double f = (double)i / n;
                        Coords c = new Coords(a.NS + (p.NS - a.NS) * f, a.EW + (p.EW - a.EW) * f);
                        if (WorldMap.SteepAt((c.EW + 101.95) * 240.0, (c.NS + 101.95) * 240.0)) continue;   // not on a slope you'd slide down
                        double z = WorldMap.GroundZ(c);
                        l.Add(new Pt(c.NS, c.EW, double.IsNaN(z) ? p.Z : z, 0));
                    }
                }
                l.Add(p);
                a = p.C;
            }
            return l;
        }

        private static Step Point(Pt p) { return new Step { Kind = "Point", NS = p.NS, EW = p.EW, Z = p.Z, Wait = 1000 }; }

        /// <summary>The steps for a walk: each point, and at the edge of a drop a forward jump off it (UB's jumpw, done by
        /// MelkTank: face that way, hold jump a moment, go).</summary>
        private static void AddWalk(List<Step> l, List<Pt> path, int skipLast)
        {
            for (int k = 0; k < path.Count - skipLast; k++)
            {
                Pt p = path[k];
                l.Add(Point(p));
                if (p.Jump > 0)
                    l.Add(new Step { Kind = "Command", Text = "/ub jumpw " + ((int)Math.Round(p.Jump - 1) % 360).ToString(System.Globalization.CultureInfo.InvariantCulture) + " 1000", Wait = 2500 });   // (a full jump: as far as it goes)
            }
        }

        private static uint PortalCell(Leg g)
        {
            Loc l;
            if (!string.IsNullOrEmpty(g.PortalKey) && TravelData.LearnedPortals.TryGetValue(g.PortalKey, out l)) return l.Cell;
            foreach (Loc x in TravelData.Locs) if (x.Key == g.PortalKey && x.Cell != 0) return x.Cell;
            // not known yet: the portal itself, if it's in sight (in a hub with floors above one another the spot alone
            // can be the walkway right over it - the cell says which floor)
            try
            {
                string want = Norm(g.Name);
                int to = want.LastIndexOf(" to ", StringComparison.Ordinal);
                string dest = to >= 0 ? want.Substring(to + 4).Trim() : want;
                uint best = 0; int bScore = 0; double bd = double.MaxValue;
                foreach (Decal.Adapter.Wrappers.WorldObject o in Decal.Adapter.CoreManager.Current.WorldFilter.GetLandscape())
                {
                    if (!Travel.IsPortal(o)) continue;
                    Decal.Adapter.Wrappers.CoordsObject c = o.Coordinates();
                    double d = new Coords(c.NorthSouth, c.EastWest).DistanceTo(g.Target) * 240.0;
                    if (d > 30) continue;
                    string n = Norm(o.Name);
                    string core = n.EndsWith(" portal", StringComparison.Ordinal) ? n.Substring(0, n.Length - 7).Trim() : n;
                    int score = core == dest || n == want ? 3 : core.StartsWith(dest, StringComparison.Ordinal) || dest.StartsWith(core, StringComparison.Ordinal) ? 2 : n.Contains(dest) || dest.Contains(core) ? 1 : 0;
                    if (score == 0 && d > 3) continue;
                    if (score > bScore || (score == bScore && d < bd))
                    {
                        uint cell = 0;
                        try { cell = (uint)o.Values(Decal.Adapter.Wrappers.LongValueKey.Landblock); } catch { }
                        if (cell == 0 || (cell & 0xFFFF) < 0x100) continue;
                        bScore = score; bd = d; best = cell;
                    }
                }
                return best;
            }
            catch { return 0; }
        }

        private static string Norm(string s) { return (s ?? "").Replace('`', '\'').Replace('\u2019', '\'').Trim().ToLowerInvariant(); }
    }
}
