using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using Decal.Adapter;
using Decal.Adapter.Wrappers;

namespace MelksQuestTracker.Travel
{
    /// <summary>
    /// Getting somewhere: the destination, the route to it (or just an arrow), following along as you travel, learning portals /
    /// recalls / gems / ties as you use them, GoArrow's commands, and coordinates in chat made clickable.
    /// </summary>
    internal static class Travel
    {
        // ── settings (Config tab) ──
        public static bool RouteMode = true;    // false = just an arrow at the coordinates
        public static bool LinkChat = true;     // coordinates in chat become links
        public static int ArrowStyle = 0;       // 0 the on-screen window (drag it anywhere), 1 MelkTank-style 3D arrow in the game, 2 both
        public static Action SaveSettings;

        // ── the trip ──
        public static Route Route;
        public static int Step;
        public static bool Active, ArrowOnly, Arrived;
        public static Coords DestAt = Coords.None;
        public static int DestArea = -1;
        public static string DestName = "";
        public static string Note = "";          // "No route found - showing the arrow", "Off the route - new route from here" ...
        private static int _routeVersion;

        public const int LinkId = 110011;        // GoArrow's link id - links it made before it was turned off still work

        private static bool _hooked;

        public static void Start(string charKey)
        {
            try { PortalBots.Load(); } catch (Exception ex) { Util.LogError(ex); }
            TravelData.Load(charKey);
            TakeCarry();
            try { PortalBots.TakeLearned(); PortalBots.Flush(); } catch (Exception ex) { Util.LogError(ex); }
            try { WorldMap.EnsureSea(); } catch (Exception ex) { Util.LogError(ex); }
            try { WorldMap.EnsureRegions(); } catch (Exception ex) { Util.LogError(ex); }
            // the ground's height anywhere outdoors, for MelkTank's wall check on hills (NaN when not known)
            try
            {
                Func<double, double, double> gz = (ns, ew) => { try { return WorldMap.GroundZ(new Coords(ns, ew)); } catch { return double.NaN; } };
                AppDomain.CurrentDomain.SetData("MelksQB.GroundZ", gz);
            }
            catch { }
            if (_hooked) return;
            _hooked = true;
            try
            {
                CoreManager c = CoreManager.Current;
                c.EchoFilter.ClientDispatch += OnClientMessage;
                c.CharacterFilter.ChangePortalMode += OnPortalMode;
                c.WorldFilter.CreateObject += OnCreate;
                c.WorldFilter.ChangeObject += OnChange;
                c.ChatNameClicked += OnChatClick;
                foreach (WorldObject o in c.WorldFilter.GetByObjectClass(ObjectClass.Portal)) QueuePortal(o);
            }
            catch (Exception ex) { Util.LogError(ex); }
        }

        public static void Stop()
        {
            try { TravelData.Flush(); } catch { }
            try { PortalBots.Flush(); } catch { }
            try { AutoTravel.HideRoute(); } catch { }
            try { AppDomain.CurrentDomain.SetData("MelksQB.GroundZ", null); } catch { }
            try { WorldView.Dispose(); } catch { }
            try { WorldMap.Release(); } catch { }
            if (!_hooked) return;
            _hooked = false;
            try
            {
                CoreManager c = CoreManager.Current;
                c.EchoFilter.ClientDispatch -= OnClientMessage;
                c.CharacterFilter.ChangePortalMode -= OnPortalMode;
                c.WorldFilter.CreateObject -= OnCreate;
                c.WorldFilter.ChangeObject -= OnChange;
                c.ChatNameClicked -= OnChatClick;
            }
            catch { }
            try { TravelHud.Dispose(); } catch { }
            try { Arrow3D.Clear(); Arrow3D.ClearMark(); } catch { }
            try { DungeonView.Dispose(); } catch { }
            try { WorldView.Dispose(); } catch { }
        }

        // ── where you are ──
        public static Coords Here()
        {
            // the live position (where the client has you now) - the world filter's copy of your own object only moves
            // when the server sends one, and had a route start 200 m behind you
            try
            {
                uint lc = (uint)CoreManager.Current.Actions.Landcell;
                if (lc != 0)
                {
                    double x = CoreManager.Current.Actions.LocationX, y = CoreManager.Current.Actions.LocationY;
                    int lbx = (int)((lc >> 24) & 0xFF), lby = (int)((lc >> 16) & 0xFF);
                    Coords live = new Coords((lby * 192.0 + y) / 240.0 - 101.95, (lbx * 192.0 + x) / 240.0 - 101.95);
                    if (live.Valid) return live;
                }
            }
            catch { }
            try
            {
                WorldObject me = CoreManager.Current.WorldFilter[CoreManager.Current.CharacterFilter.Id];
                if (me == null) return Coords.None;
                CoordsObject c = me.Coordinates();
                return new Coords(c.NorthSouth, c.EastWest);
            }
            catch { return Coords.None; }
        }

        public static double HereZ()
        {
            try { return Decal.Adapter.CoreManager.Current.WorldFilter[Decal.Adapter.CoreManager.Current.CharacterFilter.Id].RawCoordinates().Z; } catch { return double.NaN; }
        }

        public static uint Cell() { try { return (uint)CoreManager.Current.Actions.Landcell; } catch { return 0; } }
        public static int HereArea() { return TravelData.AreaOfCell(Cell()); }
        /// <summary>The route it would take from here, without going anywhere (the Travel tab's preview).</summary>
        public static Route Preview(Coords to, int area, string name)
        {
            Coords here = Here();
            if (!here.Valid || !to.Valid) return null;
            try { return Router.Find(here, HereArea(), to, area, name, Options(), Level()); }
            catch (Exception ex) { Util.LogError(ex); return null; }
        }

        private static int Level() { try { return CoreManager.Current.CharacterFilter.Level; } catch { return 0; } }

        // ── setting a destination ──

        /// <summary>"33.6N, 56.8E" or a place's name. mode 0 = the Config setting, 1 = a route, 2 = just the arrow.</summary>
        public static void Go(string text, int mode)
        {
            text = (text ?? "").Trim();
            if (text.Length == 0) { Util.WriteToChat("Where to? Coordinates (33.6N, 56.8E) or a place's name."); return; }
            Coords c;
            if (Coords.TryParse(text, out c))
            {
                string rest = Coords.Rx.Replace(text, "").Trim(' ', '-', ',', ':');
                GoTo(c, TravelData.AreaOfCoords(c), rest.Length > 0 ? rest : c.ToString(), mode);
                return;
            }
            List<Loc> found = TravelData.Find(text, 8);
            if (found.Count == 0) { Util.WriteToChat("No place called \"" + text + "\" in the travel list."); return; }
            GoTo(found[0].At, found[0].Area, found[0].Name, mode);
            if (found.Count > 1)
            {
                StringBuilder sb = new StringBuilder("Also: ");
                for (int i = 1; i < found.Count && i < 5; i++) sb.Append(i > 1 ? ", " : "").Append(found[i].Name).Append(" ").Append(Link(found[i].At.ToString()));
                Util.WriteToChat(sb.ToString());
            }
        }

        /// <summary>The dungeon room the destination is in (picked on a dungeon map: its level), or 0.</summary>
        public static uint DestCell;

        public static void GoTo(Coords c, int area, string name, int mode) { GoTo(c, area, name, mode, 0); }

        public static void GoTo(Coords c, int area, string name, int mode, uint cell)
        {
            if (!c.Valid) return;
            DestCell = cell;
            DestAt = c; DestArea = area; DestName = string.IsNullOrEmpty(name) ? c.ToString() : name;
            DestGroup = NextDestGroup; NextDestGroup = "";
            ArrowOnly = mode == 2 || (mode == 0 && !RouteMode);
            Active = true; Arrived = false; Note = "";
            Carry();
            Route = null; Step = 0;
            if (!ArrowOnly) Reroute(false);
            if (ArrowStyle != 1) TravelHud.Show();
            if (Route != null)
                Util.WriteToChat("Route to " + DestName + " (" + c + "): " + Route.Legs.Count + " step" + (Route.Legs.Count == 1 ? "" : "s") + ", about " + Time(Route.Secs) + ".");
            else Util.WriteToChat("Arrow pointing at " + DestName + " (" + c + ").");
        }

        // ── the trip carried over a reload (a new build): where to, for this character, kept in the game's process ──
        private const string CarryKey = "MelksQB.TravelCarry";
        private static bool _carryPending;

        private static void Carry()
        {
            try
            {
                if (!Active) { AppDomain.CurrentDomain.SetData(CarryKey, null); return; }
                System.Globalization.CultureInfo ci = System.Globalization.CultureInfo.InvariantCulture;
                string v = string.Join("\u0001", new[] {
                    TravelData.CharKey ?? "", DateTime.UtcNow.Ticks.ToString(ci),
                    DestAt.NS.ToString("R", ci), DestAt.EW.ToString("R", ci), DestArea.ToString(ci), DestName ?? "",
                    ArrowOnly ? "1" : "0", DestGroup ?? "", DestCell.ToString(ci) });
                AppDomain.CurrentDomain.SetData(CarryKey, v);
            }
            catch { }
        }

        /// <summary>After a reload: the trip you had going, picked up again (worked out once you're in the world).</summary>
        private static void TakeCarry()
        {
            try
            {
                string v = AppDomain.CurrentDomain.GetData(CarryKey) as string;
                if (string.IsNullOrEmpty(v)) return;
                string[] p = v.Split('\u0001');
                if (p.Length < 9 || p[0] != (TravelData.CharKey ?? "")) return;
                System.Globalization.CultureInfo ci = System.Globalization.CultureInfo.InvariantCulture;
                long t = long.Parse(p[1], ci);
                if ((DateTime.UtcNow.Ticks - t) > TimeSpan.TicksPerHour * 2) return;
                DestAt = new Coords(double.Parse(p[2], ci), double.Parse(p[3], ci));
                DestArea = int.Parse(p[4], ci); DestName = p[5]; ArrowOnly = p[6] == "1"; DestGroup = p[7];
                DestCell = uint.Parse(p[8], ci);
                if (!DestAt.Valid) return;
                Active = true; Arrived = false; Note = ""; Route = null; Step = 0;
                _carryPending = true;
            }
            catch { }
        }

        private static void CarryTick()
        {
            if (!_carryPending) return;
            if (!PlaceKnown && (Cell() & 0xFFFF) >= 0x100) return;   // in a dungeon: once its version is known
            _carryPending = false;
            if (!ArrowOnly) Reroute(false);
            if (ArrowStyle != 1) TravelHud.Show();
            Util.WriteToChat("Travel: still going to " + DestName + " (carried over the reload).");
        }

        public static void Clear()
        {
            AutoTravel.Stop(true);
            AutoTravel.HideRoute();
            Active = false; Route = null; Arrived = false; Note = "";
            Carry();
            TravelHud.Hide(); TravelHud.SyncBar();
            Arrow3D.Clear(); Arrow3D.ClearMark();
        }

        /// <summary>Works the route out again from where you are now.</summary>
        public static void Reroute(bool say) { Reroute(say, false); }

        public static void Reroute(bool say, bool force)
        {
            if (!Active || ArrowOnly) return;
            Coords here = Here();
            if (!here.Valid) { Note = "Can't tell where you are yet."; return; }
            Route r = null;
            try { r = Router.Find(here, HereArea(), DestAt, DestArea, DestName, Options(), Level()); }
            catch (Exception ex) { Util.LogError(ex); }
            _routeVersion = TravelData.Version;
            Route = r; Step = 0;
            Note = r == null ? "No route found from here - the arrow points straight at it." : "";
            AutoTravel.RouteChanged(force);
            Arrow3D.Remark();
            if (say && r != null) Util.WriteToChat("New route from here: " + r.Legs.Count + " step" + (r.Legs.Count == 1 ? "" : "s") + ", about " + Time(r.Secs) + ".");
        }

        public static Leg Current { get { return Route != null && Step < Route.Legs.Count ? Route.Legs[Step] : null; } }

        /// <summary>Where the arrow points now: the current step's portal, else the destination.</summary>
        public static Coords ArrowTarget(out string label)
        {
            Leg l = Current;
            if (!ArrowOnly && l != null && l.Target.Valid) { label = l.Kind == "run" ? DestName : l.Name; return l.Target; }
            label = DestName;
            return DestAt;
        }

        public static string Time(double secs)
        {
            if (secs < 90) return Math.Max(1, (int)Math.Round(secs)) + " s";
            return ((int)Math.Round(secs / 60)) + " min";
        }

        // ── what you can travel with from anywhere ──
        private static readonly Regex RecallRx = new Regex(@"recall|sending|^return to |^call of the ", RegexOptions.IgnoreCase);
        private static readonly Regex NotRecallRx = new Regex(@"\btie\b|recall the spirits|^summon ", RegexOptions.IgnoreCase);
        private static readonly HashSet<string> PerCharSpells = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        { "Lifestone Recall", "Primary Portal Recall", "Secondary Portal Recall", "Portal Recall", "Lifestone Sending" };

        public static bool IsPerCharSpell(string name) { return PerCharSpells.Contains(name ?? ""); }
        /// <summary>A gem routes may use: one on this character's MelkTank Portals tab list (by name).</summary>
        public static bool IsGemName(string n)
        {
            n = n ?? "";
            List<string> mt = MelkTankGems.List();
            if (mt != null) return mt.Exists(g => string.Equals(g, n, StringComparison.OrdinalIgnoreCase));
            // no MelkTank here: anything named like a portal gem
            if (TravelData.SharedStarts.ContainsKey("gem|" + n)) return true;
            return n.IndexOf("Gem", StringComparison.OrdinalIgnoreCase) >= 0 &&
                   (RecallRx.IsMatch(n) || n.IndexOf("Portal", StringComparison.OrdinalIgnoreCase) >= 0 || n.IndexOf("Town Network", StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private static List<KeyValuePair<int, string>> _spells = new List<KeyValuePair<int, string>>();
        private static DateTime _spellsAt = DateTime.MinValue;

        /// <summary>The recall / portal spells in your spellbook (id, name).</summary>
        public static List<KeyValuePair<int, string>> RecallSpells()
        {
            if ((DateTime.Now - _spellsAt).TotalSeconds < 20) return _spells;
            _spellsAt = DateTime.Now;
            List<KeyValuePair<int, string>> l = new List<KeyValuePair<int, string>>();
            foreach (int id in Spells.Known())
            {
                string n = Spells.Name(id);
                if (string.IsNullOrEmpty(n) || !RecallRx.IsMatch(n) || NotRecallRx.IsMatch(n)) continue;
                if (!l.Exists(x => x.Value == n)) l.Add(new KeyValuePair<int, string>(id, n));
            }
            l.Sort((a, b) => string.Compare(a.Value, b.Value, StringComparison.OrdinalIgnoreCase));
            _spells = l;
            return l;
        }

        /// <summary>Portal gems in your pack (name, an item id).</summary>
        public static List<KeyValuePair<string, int>> Gems()
        {
            List<KeyValuePair<string, int>> l = new List<KeyValuePair<string, int>>();
            try
            {
                foreach (WorldObject o in CoreManager.Current.WorldFilter.GetInventory())
                {
                    string n = o.Name ?? "";
                    if (!IsGemName(n) || l.Exists(x => string.Equals(x.Key, n, StringComparison.OrdinalIgnoreCase))) continue;
                    l.Add(new KeyValuePair<string, int>(n, o.Id));
                }
            }
            catch { }
            l.Sort((a, b) => string.Compare(a.Key, b.Key, StringComparison.OrdinalIgnoreCase));
            return l;
        }

        /// <summary>Where a spell / gem / command takes you: this character's, else everyone's, else the built-in guess.</summary>
        public static StartOpt Known(string kind, string name)
        {
            StartOpt s;
            if (TravelData.CharStarts.TryGetValue(kind + "|" + name, out s)) return OpensCheck(s);
            if (kind != "cmd" && !(kind == "spell" && IsPerCharSpell(name)) && TravelData.SharedStarts.TryGetValue(kind + "|" + name, out s)) return OpensCheck(s);
            Coords c; int a; bool op;
            if (TravelData.Seed(kind, name, out c, out a, out op)) return new StartOpt { Kind = kind, Name = name, Exit = c, ExitArea = a, OpensPortal = op };
            return null;
        }

        private static StartOpt OpensCheck(StartOpt s)
        {
            if (s != null && s.Kind == "gem" && !s.OpensPortal && TravelData.PortalOpeningGems.Contains(s.Name)) s.OpensPortal = true;
            return s;
        }

        /// <summary>Everything usable right now with a known landing spot.</summary>
        public static List<StartOpt> Options()
        {
            List<StartOpt> l = new List<StartOpt>();
            foreach (KeyValuePair<int, string> sp in RecallSpells())
            {
                StartOpt k = Known("spell", sp.Value);
                if (k == null || !k.Exit.Valid) continue;   // (one landing in a tier copy only leads to places on that copy's map)
                l.Add(new StartOpt { Kind = "spell", Name = sp.Value, Exit = k.Exit, ExitArea = k.ExitArea, SpellId = sp.Key, PerChar = k.PerChar, Instance = k.Instance });
            }
            foreach (KeyValuePair<string, int> g in Gems())
            {
                StartOpt k = Known("gem", g.Key);
                if (k == null || !k.Exit.Valid) continue;   // (one landing in a tier copy only leads to places on that copy's map)
                l.Add(new StartOpt { Kind = "gem", Name = g.Key, Exit = k.Exit, ExitArea = k.ExitArea, ItemId = g.Value, OpensPortal = k.OpensPortal, Instance = k.Instance });
            }
            foreach (StartOpt c in TravelData.CharStarts.Values)
                if (c.Kind == "cmd" && c.Exit.Valid) l.Add(c);
            return l;
        }

        // ── doing a step ──
        private static int _pendingSpell;
        private static DateTime _pendingUntil = DateTime.MinValue;

        /// <summary>Goes through the portal your gem opened (the travel window's second button on such a step).</summary>
        public static void UseGemPortal() { DoStep(new Leg { Kind = "gemportal", Opt = new StartOpt() }); }

        public static void DoStep(Leg l)
        {
            if (l == null || l.Opt == null) return;
            try
            {
                if (l.Kind == "gem")
                {
                    int id = l.Opt.ItemId;
                    foreach (KeyValuePair<string, int> g in Gems()) if (string.Equals(g.Key, l.Name, StringComparison.OrdinalIgnoreCase)) id = g.Value;
                    if (id == 0) { Util.WriteToChat("No " + l.Name + " in your pack."); return; }
                    CoreManager.Current.Actions.UseItem(id, 0);
                }
                else if (l.Kind == "cmd") Util.Command(l.Name);
                else if (l.Kind == "gemportal")
                {
                    WorldObject p = _gemPortal != 0 ? CoreManager.Current.WorldFilter[_gemPortal] : null;
                    if (p == null) p = NearestPortal(Here(), 0.05);
                    if (p == null) { Util.WriteToChat("No portal open by you - use the gem first."); return; }
                    CoreManager.Current.Actions.UseItem(p.Id, 0);
                }
                else if (l.Kind == "spell") Cast(l.Opt.SpellId);
            }
            catch (Exception ex) { Util.LogError(ex); }
        }

        private static bool InMagicMode() { try { return (int)CoreManager.Current.Actions.CombatMode == (int)CombatState.Magic; } catch { return false; } }

        private static void Cast(int id)
        {
            if (id == 0) return;
            if (InMagicMode()) { CoreManager.Current.Actions.CastSpell(id, CoreManager.Current.CharacterFilter.Id); return; }
            try { CoreManager.Current.Actions.SetCombatMode(CombatState.Magic); } catch { }
            _pendingSpell = id; _pendingUntil = DateTime.Now.AddSeconds(4);
        }

        // ── every frame ──
        private static DateTime _nextTick = DateTime.MinValue, _nextPick = DateTime.MinValue;
        private static bool _inPortal;
        private static DateTime _arrivalDue = DateTime.MaxValue;
        private static Coords _lastPos = Coords.None, _prePos = Coords.None;
        private static int _lastArea = -1, _preArea = -1;
        private static DateTime _jumpAt = DateTime.MinValue;

        public static void Tick()
        {
            DateTime now = DateTime.Now;
            try { WorldView.EnsureBar(); } catch { }
            try { MapView.Draw(); } catch { }   // the ACMaps window, with the tracker collapsed too
            try { VariationTick(); } catch { }
            try { CarryTick(); } catch (Exception ex) { Util.LogError(ex); }
            try { RecordTick(); } catch (Exception ex) { Util.LogError(ex); }
            if (DateTime.Now >= _npcScanAt) { _npcScanAt = DateTime.Now.AddSeconds(3); try { WorldView.ScanNpcs(); } catch { } try { PortalBots.Tick(); } catch { } }
            if (_pendingSpell != 0)
            {
                if (InMagicMode()) { int id = _pendingSpell; _pendingSpell = 0; try { CoreManager.Current.Actions.CastSpell(id, CoreManager.Current.CharacterFilter.Id); } catch { } }
                else if (now > _pendingUntil) { _pendingSpell = 0; Util.WriteToChat("Couldn't cast it - wield a wand first (magic mode didn't come on)."); }
            }
            if (now < _nextTick) return;
            _nextTick = now.AddMilliseconds(250);
            try
            {
                TravelData.Tick();
                if (now >= _nextPick) { _nextPick = now.AddSeconds(5); TravelData.PickUpOthers(); PortalBots.Load(); }
                IdNextPortal();
                if (_inPortal) return;
                Coords here = Here();
                int area = HereArea();
                if (!here.Valid) return;
                if (_arrivalDue != DateTime.MaxValue)
                {
                    if (now < _arrivalDue) return;
                    _arrivalDue = DateTime.MaxValue;
                    Arrival(here, area, Cell());
                }
                else if (_lastPos.Valid && (here.DistanceTo(_lastPos) > 1.5 || !TravelData.SameArea(area, _lastArea)) && (now - _jumpAt).TotalSeconds > 3)
                {
                    // moved without a portal-space event (a hot reload in between, a summoned portal ...): the same as arriving
                    _jumpAt = now;
                    _prePos = _lastPos; _preArea = _lastArea;
                    Arrival(here, area, Cell());
                }
                _lastPos = here; _lastArea = area;
                if (area < 0 && (now - _calAt).TotalSeconds > 10 && (Cell() & 0xFFFF) < 0x100) { _calAt = now; WorldMap.Calibrate(here, HereZ()); }
                if (Active && !Arrived) CheckArrived(here, area);
                Arrow3D.Update();
                try { DungeonView.Tick(); } catch (Exception ex) { Util.LogError(ex); }
                try { WorldView.PlaceRequestTick(); } catch (Exception ex) { Util.LogError(ex); }
                if (DateTime.Now >= _portalScanAt)
                {
                    _portalScanAt = DateTime.Now.AddSeconds(3);
                    try { DungeonView.SeePortals(); } catch { }
                    // every portal around (ones already here before a reload too): identified once, so where it leads is learned
                    // and routes can use it (one into a dungeon shows no coordinates - that's learned the first time it's used)
                    try
                    {
                        foreach (WorldObject o in CoreManager.Current.WorldFilter.GetLandscape())
                            if (IsPortal(o) && _portalsSeen.Add(o.Id)) QueuePortal(o);
                    }
                    catch { }
                }
                // 3D arrow only: the window still comes up for a step you have to do (cast, use, type) and on arriving
                if (Active && ArrowStyle == 1)
                {
                    Leg cl = Current;
                    bool need = Arrived || (!ArrowOnly && cl != null && cl.Opt != null);
                    if (need && !TravelHud.Visible && !_autoShown) { TravelHud.Show(); _autoShown = true; }
                    if (!need) _autoShown = false;
                }
                // new portals learned: the route is looked at again (not more than every 5 s)
                if (Active && !ArrowOnly && Route != null && _routeVersion != TravelData.Version && Step == 0 && (now - _versionRerouteAt).TotalSeconds > 5)
                { _versionRerouteAt = now; Reroute(false); }
                AutoTravel.Tick();
                AutoTravel.ShowTick();
            }
            catch (Exception ex) { Util.LogError(ex); }
        }

        private static bool _autoShown;
        private static DateTime _versionRerouteAt = DateTime.MinValue;
        private static DateTime _calAt = DateTime.MinValue;

        /// <summary>At the destination's floor: a room picked on a dungeon map is on one level - standing two floors above
        /// it isn't being there.</summary>
        public static bool AtDestHeight()
        {
            if (DestCell == 0) return true;
            try
            {
                Dictionary<uint, DCell> d = WorldMap.Dungeon((int)(DestCell >> 16));
                DCell c;
                if (d == null || !d.TryGetValue(DestCell, out c)) return true;
                return Math.Abs(CoreManager.Current.Actions.LocationZ - c.Z) < 3.0;
            }
            catch { return true; }
        }

        // how near counts as there (indoors 2.5 m: 9.6 m had you "there" at the door before the room it's in)
        private static double ThereRange(int area) { return area >= 0 ? 2.5 / 240.0 : 0.04; }
        public static bool NearDest()
        {
            try { Coords h = Here(); return !DestAt.Valid || !h.Valid || h.DistanceTo(DestAt) <= ThereRange(DestArea) * 1.5; }
            catch { return true; }
        }

        private static void CheckArrived(Coords here, int area)
        {
            if (!DestAt.Valid || !TravelData.SameArea(area, DestArea)) return;
            if (here.DistanceTo(DestAt) > ThereRange(area)) return;
            if (!AtDestHeight()) return;   // right above / below it (another floor): not there yet
            Leg l = Current;
            if (!ArrowOnly && l != null && l.Kind != "run") return;   // still steps to go
            Arrived = true;
            Util.WriteToChat("Arrived at " + DestName + ".");
        }

        // ── portal space ──
        private static void OnPortalMode(object sender, ChangePortalModeEventArgs e)
        {
            try
            {
                if (e.Type == PortalEventType.EnterPortal)
                {
                    _inPortal = true;
                    HereInstance = "";
                    _prePos = _lastPos.Valid ? _lastPos : Here();
                    _preArea = _lastArea;
                    _preCell = Cell();
                }
                else
                {
                    _inPortal = false;
                    _arrivalDue = DateTime.Now.AddSeconds(1.5);   // the position settles first
                    _placeAskedAt = DateTime.UtcNow;   // which copy you're in: not known until /location answers
                }
            }
            catch (Exception ex) { Util.LogError(ex); }
        }
        private static uint _preCell;

        // the last thing that could have moved you
        private class Act { public string Kind = ""; public string Name = ""; public DateTime At; public int SpellId; public int Target;
                            public Coords PortalAt = Coords.None; public int PortalArea = -1; public int Min, Max; public uint PortalCell;
                            public bool OpensPortal; public bool NoRecall; }
        private static int _gemPortal;   // the portal a gem just opened (not a portal that stays there - never learned as one)
        private static Act _act;

        /// <summary>Out of a portal that can be recalled to: where Portal Recall - the spell and the Portal Recall Gem
        /// (it casts the same) - now takes you.</summary>
        private static void LastPortal(Coords here, int area)
        {
            TravelData.LearnStart("spell", "Portal Recall", here, area, true);
            TravelData.LearnStart("gem", "Portal Recall Gem", here, area, true);
        }

        /// <summary>A portal the game won't let you portal-recall to (its "no recall" restriction).</summary>
        private static bool NoRecall(WorldObject p)
        {
            try { return p != null && (p.Values((LongValueKey)111, 0) & 0x20) != 0; }   // (PortalBitmask: 0x20 no recall)
            catch { return false; }
        }

        private static void Arrival(Coords here, int area, uint cell)
        {
            _jumpAt = DateTime.Now;
            // an indoor cell in a sea landblock that isn't on the dungeon list: it is one now
            int lb = (int)(cell >> 16);
            if ((cell & 0xFFFF) >= 0x100 && TravelData.IsEdge(lb) && !TravelData.IsDungeon(lb)) { TravelData.LearnIndoor(lb); area = lb; }
            Act a = _act;
            _act = null;
            double age = a == null ? 999 : (DateTime.Now - a.At).TotalSeconds;
            bool fresh = a != null && age < (a.Kind == "portal" || a.Name == "/ls" ? 40 : 25);
            if (fresh && a.Kind == "portal")
            {
                TravelData.LearnPortal(a.Name, a.PortalAt, a.PortalArea, here, area, a.Min, a.Max, a.PortalCell);
                if (!a.NoRecall) LastPortal(here, area);   // Portal Recall takes you back out of the last portal used
            }
            else if (fresh && a.Kind == "spell")
            {
                string n = Spells.Name(a.SpellId) ?? "";
                if (n.Length > 0 && RecallRx.IsMatch(n) && !NotRecallRx.IsMatch(n)) TravelData.LearnStart("spell", n, here, area, IsPerCharSpell(n));
            }
            else if (fresh && a.Kind == "gem") TravelData.LearnStart("gem", a.Name, here, area, false, a.OpensPortal);
            else if (fresh && a.Kind == "cmd") TravelData.LearnStart("cmd", a.Name, here, area, true);
            else
            {
                // walked into a portal (no Use was sent): the portal right where you stood
                WorldObject p = NearestPortal(_prePos, 0.05);
                if (p != null && p.Id == _gemPortal) p = null;
                if (p != null)
                {
                    Coords pa = Pos(p);
                    TravelData.LearnPortal(p.Name, pa, TravelData.AreaOfCell(CellOf(p)), here, area, Lv(p, true), Lv(p, false), CellOf(p));
                    if (!NoRecall(p)) LastPortal(here, area);
                }
            }
            if (Active) AfterMove(here, area);
        }

        /// <summary>You've moved (portal, recall ...): the next step if it put you where the route expected, else a new route.</summary>
        private static void AfterMove(Coords here, int area)
        {
            if (ArrowOnly || Route == null || Arrived) return;
            for (int i = Step; i < Route.Legs.Count; i++)
            {
                Leg l = Route.Legs[i];
                if (!l.Exit.Valid) continue;
                double tol = l.ExitArea >= 0 ? 0.6 : 1.2;
                if (TravelData.SameArea(area, l.ExitArea) && here.DistanceTo(l.Exit) <= tol)
                {
                    Step = i + 1; Note = "";
                    AutoTravel.RouteChanged(true);   // the rest of the trip, planned from where you really came out
                    return;
                }
            }
            AutoTravel.OffRoute();
            Reroute(true, true);
            Note = Route != null ? "Off the route - this is a new one from here." : Note;
        }

        // ── learning from what you do ──
        private static readonly Regex TravelCmdRx = new Regex(@"^[/@](ls|lifestone|hr|house\s+recall|hom|house\s+mansion_recall|mansion\s+recall|ah|allegiance\s+hometown|mp|marketplace|pkarena|pklarena)\b", RegexOptions.IgnoreCase);

        /// <summary>A command typed in chat: travel ones (/ls, /hr ...) are remembered for a moment - where they land is learned.</summary>
        public static void OnTyped(string text)
        {
            string t = (text ?? "").Trim();
            Match m = TravelCmdRx.Match(t);
            if (!m.Success) return;
            string cmd = "/" + Regex.Replace(m.Value.Substring(1).ToLowerInvariant(), @"\s+", " ");
            if (cmd == "/lifestone") cmd = "/ls";
            _act = new Act { Kind = "cmd", Name = cmd, At = DateTime.Now };
        }

        private static void OnClientMessage(object sender, NetworkMessageEventArgs e)
        {
            try
            {
                Message m = e.Message;
                if (m == null || m.Type != 0xF7B1) return;
                int action = m.Value<int>("action");
                if (action == 0x0048 || action == 0x004A)
                {
                    int spell = 0, target = 0;
                    try { spell = m.Value<int>("spell"); } catch { }
                    if (action == 0x004A) try { target = m.Value<int>("target"); } catch { }
                    if (spell == 0) try { spell = m.Value<int>(m.Count - 1); } catch { }
                    _lastSpell = spell; _lastTarget = target; _lastSpellAt = DateTime.Now;
                    string n = Spells.Name(spell) ?? "";
                    if (RecallRx.IsMatch(n) && !NotRecallRx.IsMatch(n)) _act = new Act { Kind = "spell", SpellId = spell, Name = n, At = DateTime.Now };
                }
                else if (action == 0x0036)
                {
                    int id = 0;
                    try { id = m.Value<int>("object"); } catch { }
                    if (id == 0) try { id = m.Value<int>(m.Count - 1); } catch { }
                    WorldObject o = id == 0 ? null : CoreManager.Current.WorldFilter[id];
                    if (o == null) return;
                    if (IsPortal(o))
                    {
                        // the portal your gem opened: going through it is the gem's trip (where the gem takes you)
                        if (o.Id == _gemPortal && _act != null && _act.Kind == "gem") { _act.OpensPortal = true; _act.At = DateTime.Now; }
                        else if (!Summoned(o.Name)) _act = new Act { Kind = "portal", Name = o.Name, At = DateTime.Now, PortalAt = Pos(o), PortalArea = TravelData.AreaOfCell(CellOf(o)), Min = Lv(o, true), Max = Lv(o, false), PortalCell = CellOf(o), NoRecall = NoRecall(o) };
                    }
                    else if (IsGemName(o.Name)) _act = new Act { Kind = "gem", Name = o.Name, At = DateTime.Now };
                }
            }
            catch { }
        }
        private static int _lastSpell, _lastTarget;
        private static DateTime _lastSpellAt = DateTime.MinValue;

        /// <summary>A portal - or something the game doesn't class as one but is named like one (some that go to several places).</summary>
        public static bool IsPortal(WorldObject o)
        {
            if (o == null) return false;
            if (o.ObjectClass == ObjectClass.Portal) return true;
            if (o.Container != 0 || !(o.Name ?? "").EndsWith(" Portal", StringComparison.OrdinalIgnoreCase)) return false;
            ObjectClass c = o.ObjectClass;
            return c != ObjectClass.Npc && c != ObjectClass.Vendor && c != ObjectClass.Monster && c != ObjectClass.Player && c != ObjectClass.Corpse;
        }

        private static bool Summoned(string n)
        {
            n = n ?? "";
            return n.IndexOf("Summoned", StringComparison.OrdinalIgnoreCase) >= 0 || n.StartsWith("Gateway", StringComparison.OrdinalIgnoreCase) ||
                   n.IndexOf("'s Portal", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static Coords Pos(WorldObject o)
        {
            try { CoordsObject c = o.Coordinates(); return new Coords(c.NorthSouth, c.EastWest); } catch { return Coords.None; }
        }
        private static uint CellOf(WorldObject o) { try { return (uint)o.Values(LongValueKey.Landblock); } catch { return 0; } }
        private static int Lv(WorldObject o, bool min) { try { return o.Values(min ? LongValueKey.MinLevelRestrict : LongValueKey.MaxLevelRestrict); } catch { return 0; } }

        private static WorldObject NearestPortal(Coords at, double within)
        {
            if (!at.Valid) return null;
            WorldObject best = null; double bd = within;
            try
            {
                foreach (WorldObject o in CoreManager.Current.WorldFilter.GetLandscape())
                {
                    if (!IsPortal(o)) continue;
                    if (Summoned(o.Name)) continue;
                    double d = Pos(o).DistanceTo(at);
                    if (d < bd) { bd = d; best = o; }
                }
            }
            catch { }
            return best;
        }

        // ── portals you see: their destination (appraisal) ──
        private static readonly Queue<int> _idQueue = new Queue<int>();
        private static readonly HashSet<int> _idQueued = new HashSet<int>();
        private static DateTime _idAt = DateTime.MinValue;

        private static void OnCreate(object sender, CreateObjectEventArgs e)
        {
            try
            {
                if (e.New == null) return;
                if (e.New.ObjectClass == ObjectClass.Npc || e.New.ObjectClass == ObjectClass.Vendor) { WorldView.Seen(e.New); return; }
                if (!IsPortal(e.New)) return;
                // a portal appearing right by you just after using a gem: the gem opened it
                Act a = _act;
                if (a != null && a.Kind == "gem" && (DateTime.Now - a.At).TotalSeconds < 10 && Pos(e.New).DistanceTo(Here()) < 0.05)
                { _gemPortal = e.New.Id; a.OpensPortal = true; return; }
                QueuePortal(e.New);
            }
            catch { }
        }

        private static void QueuePortal(WorldObject o)
        {
            if (o == null || Summoned(o.Name) || _idQueued.Contains(o.Id)) return;
            if (o.HasIdData) { ReadPortal(o); return; }
            _idQueued.Add(o.Id);
            _idQueue.Enqueue(o.Id);
        }

        private static void IdNextPortal()
        {
            if (_idQueue.Count == 0 || (DateTime.Now - _idAt).TotalMilliseconds < 600) return;
            _idAt = DateTime.Now;
            int id = _idQueue.Dequeue();
            WorldObject o = CoreManager.Current.WorldFilter[id];
            if (o == null) { _idQueued.Remove(id); return; }
            if (o.HasIdData) { ReadPortal(o); return; }
            try { CoreManager.Current.Actions.RequestId(id); } catch { }
        }

        private static void OnChange(object sender, ChangeObjectEventArgs e)
        {
            try
            {
                if (e.Change != WorldChangeType.IdentReceived || e.Changed == null) return;
                WorldObject co = e.Changed;
                // a portal - or one the game doesn't class as one but is named like one (some that go to several places)
                if (IsPortal(co)) ReadPortal(co);
                if (_tieWanted != null && e.Changed.Id == _tieTarget) ResolveTie(e.Changed);
            }
            catch (Exception ex) { Util.LogError(ex); }
        }

        private static readonly HashSet<string> _saidNoDest = new HashSet<string>(StringComparer.OrdinalIgnoreCase);   // said once a session per portal

        private static void ReadPortal(WorldObject o)
        {
            _idQueued.Remove(o.Id);
            if (o.Id == _gemPortal) return;
            string dest = "";
            try { dest = o.Values((StringValueKey)38, ""); } catch { }
            Coords d;
            if (!Coords.TryParse(dest, out d))
            {
                // a dungeon, or one that goes to several places (no coordinates shown): on the map now, where it goes is
                // learned the first time it's used
                TravelData.LearnPortal(o.Name, Pos(o), TravelData.AreaOfCell(CellOf(o)), Coords.None, -1, Lv(o, true), Lv(o, false), CellOf(o));
                try { if (CoreManager.Current.Actions.CurrentSelection == o.Id && _saidNoDest.Add(o.Name ?? "")) Util.WriteToChat("Travel: " + o.Name + " is on the map - it shows no destination, so where it goes is learned when you use it."); } catch { }
                return;
            }
            TravelData.LearnPortal(o.Name, Pos(o), TravelData.AreaOfCell(CellOf(o)), d, TravelData.AreaOfCoords(d), Lv(o, true), Lv(o, false), CellOf(o));
        }

        // ── ties (from chat) ──
        private static string _tieWanted;
        private static int _tieTarget;

        /// <summary>Chat lines: portal / lifestone ties, the lifestone you're attuned to, and (if on) coordinates made into links.</summary>
        private static readonly System.Text.RegularExpressions.Regex LocTierRx = new System.Text.RegularExpressions.Regex(@"^Your location is:.*\bv:\s*(\d+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        private static long _varSeen;
        private static DateTime _placeAskedAt = DateTime.MinValue;
        /// <summary>Which copy you're in is known: /location has answered since the last portal (MelkTank's own quiet one after
        /// each portal, or one you typed that shows v:). Until then nothing is added to the map.</summary>
        public static bool PlaceKnown { get { return _placeKnown > _placeAskedAt.Ticks; } }
        private static long _placeKnown;
        private static DateTime _startedAt = DateTime.Now;
        private static DateTime _npcScanAt = DateTime.MinValue, _portalScanAt = DateTime.MinValue;
        private static readonly HashSet<int> _portalsSeen = new HashSet<int>();

        /// <summary>MelkTank asks /location itself after each portal: its answer (v:12, or none) says which copy you're in.</summary>
        private static void VariationTick()
        {
            string v = null;
            try { v = AppDomain.CurrentDomain.GetData("MelkTank.Variation") as string; } catch { }
            if (string.IsNullOrEmpty(v)) return;
            string[] p = v.Split('|');
            long ticks; int n;
            if (p.Length < 2 || !long.TryParse(p[1], out ticks) || !int.TryParse(p[0], out n) || ticks <= _varSeen) return;
            bool first = _varSeen == 0;
            _varSeen = ticks;
            if (ticks > _placeKnown) _placeKnown = ticks;
            HereInstance = InstOf(n);
            if (first) return;
            Seen(n);
        }

        /// <summary>Which copy /location says you're in: "tier12" (Tou-Tou's tier 11+ copies, out in the world), "v2" (a
        /// dungeon's own version - the same rooms reused as another dungeon, with its own name, doors and monsters), or "".</summary>
        public static string InstOf(int n)
        {
            if (n >= 11 && ServerMode.Ilt) return "tier" + n;   // (tier copies are Infinite Leaftide's)
            uint c = Cell();
            if (n > 0 && (c & 0xFFFF) >= 0x100) return "v" + n;
            return "";
        }

        private static void Seen(int n)
        {
            TravelData.InstanceSeen(HereInstance.Length > 0 ? HereInstance : "-");
            uint c = Cell();
            if ((c & 0xFFFF) >= 0x100) { int lb = (int)(c >> 16); _dunInst[lb] = HereInstance; TravelData.VariantSeen(lb, HereInstance); }
        }

        // the version of each dungeon you were last in (its map shows that one after you've left)
        private static readonly Dictionary<int, string> _dunInst = new Dictionary<int, string>();

        /// <summary>The version ("" or "v2") of a dungeon: the one you're in, else the one you were last in there.</summary>
        public static string DungeonInst(int lb)
        {
            uint c = Cell();
            if ((c & 0xFFFF) >= 0x100 && (int)(c >> 16) == lb && PlaceKnown) return HereInstance.StartsWith("v") ? HereInstance : "";
            string v; return _dunInst.TryGetValue(lb, out v) && v.StartsWith("v") ? v : "";
        }

        /// <summary>What a dungeon's points are kept under: "d:0110", or "d:0110v2" for its version 2.</summary>
        public static string DungeonIn(int lb) { return DungeonIn(lb, DungeonInst(lb)); }
        public static string DungeonIn(int lb, string inst) { return "d:" + lb.ToString("X4") + (inst != null && inst.StartsWith("v") ? inst : ""); }
        public static string HereInstance = "";   // what /location last said (tier11 ...), cleared going through a portal
        /// <summary>The map you're on: "tier11+" in Tou-Tou's tier 11-15 copies, "" in the world.</summary>
        public static string HereGroup { get { return HereInstance.StartsWith("v") ? "" : TravelData.Group(HereInstance); } }   // a dungeon's version isn't a world map of its own
        /// <summary>The map the destination is on (set by the world map's tier copy view), "" = the world.</summary>
        public static string DestGroup = "";
        public static string NextDestGroup = "";   // for the next GoTo (the world map, picking a place on a tier copy's map)

        // ── recording a copy's boundary: run along it ──
        public static bool Recording { get { return _rec != null; } }
        public static int RecordCount { get { return _rec == null ? 0 : _rec.Count; } }
        public static List<Coords> RecordTrail { get { return _rec; } }
        public static string RecordGroup = "";
        private static List<Coords> _rec;
        public static string RecordMsg = "";

        public static void RecordStart()
        {
            string g = HereGroup;
            if (g.Length == 0) { RecordMsg = "You're not in a tier copy (/location shows no v:) - go into Tou-Tou tier 11+ first."; Util.WriteToChat("Travel: " + RecordMsg); return; }
            _rec = new List<Coords>(); RecordGroup = g;
            RecordMsg = "Recording the " + TravelData.GroupTitle(g) + " edge - run along its southern edge, then Stop (more runs add to it).";
            Util.WriteToChat("Travel: " + RecordMsg);
        }

        /// <summary>The tier area's east (or west) limit is where you stand: a north-south edge through here.</summary>
        public static void MarkSide(bool east)
        {
            string g = HereGroup;
            Coords h = Here();
            if (g.Length == 0 || !h.Valid) { RecordMsg = "You're not in a tier copy (/location shows no v:)."; Util.WriteToChat("Travel: " + RecordMsg); return; }
            // the bottom edge carries on to here: a line from here to its nearest end that way (run westward: north on the right)
            TravelData.Bound bd;
            Coords end = Coords.None;
            if (TravelData.Bounds.TryGetValue(g, out bd))
                foreach (List<Coords> r in bd.Runs)
                    foreach (Coords p in new[] { r[0], r[r.Count - 1] })
                        if (!end.Valid || (east ? p.EW > end.EW : p.EW < end.EW)) end = p;
            if (!end.Valid) { RecordMsg = "Record the bottom edge first (Record it), then mark where it ends."; Util.WriteToChat("Travel: " + RecordMsg); return; }
            if (east ? h.EW <= end.EW : h.EW >= end.EW) { RecordMsg = "The bottom edge already reaches past here."; Util.WriteToChat("Travel: " + RecordMsg); return; }
            TravelData.SetBound(g, east ? new List<Coords> { h, end } : new List<Coords> { end, h });
            RecordMsg = "The bottom edge now runs to the " + (east ? "east" : "west") + " limit at " + h + " (past it, the water is the edge).";
            Util.WriteToChat("Travel: " + RecordMsg);
        }

        public static void RecordStop(bool keep)
        {
            if (_rec == null) return;
            List<Coords> pts = Simplify(_rec, 0.004);
            _rec = null;
            if (!keep) { RecordMsg = "Boundary recording thrown away."; return; }
            if (pts.Count < 2) { RecordMsg = "Too short to mark the edge."; return; }
            TravelData.SetBound(RecordGroup, pts);
            RecordMsg = "Added to the " + TravelData.GroupTitle(RecordGroup) + " edge (" + pts.Count + " points) - everything north of it is the tier area.";
            Util.WriteToChat("Travel: " + RecordMsg);
        }

        private static void RecordTick()
        {
            if (_rec == null) return;
            if (HereGroup != RecordGroup) { Util.WriteToChat("Travel: left " + TravelData.GroupTitle(RecordGroup) + " - boundary recording stopped (kept what you ran)."); RecordStop(true); return; }
            Coords h = Here();
            if (!h.Valid || HereArea() >= 0) return;
            if (_rec.Count == 0 || _rec[_rec.Count - 1].DistanceTo(h) * 240 >= 2) _rec.Add(h);
        }

        // Douglas-Peucker: drop points within tol (map units, 0.004 ~ 1 m) of the line between their neighbours
        private static List<Coords> Simplify(List<Coords> p, double tol)
        {
            if (p.Count < 3) return new List<Coords>(p);
            bool[] keep = new bool[p.Count]; keep[0] = keep[p.Count - 1] = true;
            Stack<int[]> st = new Stack<int[]>(); st.Push(new[] { 0, p.Count - 1 });
            while (st.Count > 0)
            {
                int[] r = st.Pop(); int a = r[0], b = r[1]; double best = 0; int bi = -1;
                for (int i = a + 1; i < b; i++)
                {
                    double d = SegDist(p[i], p[a], p[b]);
                    if (d > best) { best = d; bi = i; }
                }
                if (bi >= 0 && best > tol) { keep[bi] = true; st.Push(new[] { a, bi }); st.Push(new[] { bi, b }); }
            }
            List<Coords> o = new List<Coords>();
            for (int i = 0; i < p.Count; i++) if (keep[i]) o.Add(p[i]);
            return o;
        }
        private static double SegDist(Coords c, Coords a, Coords b)
        {
            double dx = b.EW - a.EW, dy = b.NS - a.NS, l2 = dx * dx + dy * dy;
            double t = l2 <= 0 ? 0 : Math.Max(0, Math.Min(1, ((c.EW - a.EW) * dx + (c.NS - a.NS) * dy) / l2));
            double ex = a.EW + t * dx - c.EW, ey = a.NS + t * dy - c.NS;
            return Math.Sqrt(ex * ex + ey * ey);
        }

        public static void OnChat(ChatTextInterceptEventArgs e)
        {
            string t = (e.Text ?? "").Trim();
            if (t.IndexOf(" tells you, \"", StringComparison.Ordinal) > 0) PortalBots.OnChat(t);
            {
                // /location's answer ends ", v:12" in a copy of an area (Tou-Tou's tier 12 copy); /loc never shows it
                System.Text.RegularExpressions.Match im = LocTierRx.Match(t);
                if (im.Success)
                {
                    int vn = int.Parse(im.Groups[1].Value);
                    HereInstance = InstOf(vn);
                    _placeKnown = DateTime.UtcNow.Ticks;
                    Seen(vn);
                }
            }
            if (t == "You successfully link with the portal!")
            {
                string n = Spells.Name(_lastSpell) ?? "";
                _tieWanted = n.IndexOf("Secondary", StringComparison.OrdinalIgnoreCase) >= 0 ? "Secondary Portal Recall" : "Primary Portal Recall";
                _tieTarget = _lastTarget;
                WorldObject o = _tieTarget == 0 ? null : CoreManager.Current.WorldFilter[_tieTarget];
                if (o != null && o.HasIdData) ResolveTie(o);
                else if (o != null) try { CoreManager.Current.Actions.RequestId(o.Id); } catch { }
            }
            else if (t == "You successfully link with the lifestone!")
            {
                WorldObject o = _lastTarget == 0 ? null : CoreManager.Current.WorldFilter[_lastTarget];
                Coords at = o != null ? Pos(o) : Here();
                int area = o != null ? TravelData.AreaOfCell(CellOf(o)) : HereArea();
                TravelData.LearnStart("spell", "Lifestone Recall", at, area, true);
                Util.WriteToChat("Travel: Lifestone Recall now leads to " + at + ".");
            }
            else if (t.StartsWith("You have attuned your spirit to this Lifestone.", StringComparison.Ordinal))
            {
                TravelData.LearnStart("cmd", "/ls", Here(), HereArea(), true);
            }
            if (LinkChat && !e.Eat) LinkCoords(e);
        }

        private static void ResolveTie(WorldObject o)
        {
            string want = _tieWanted;
            _tieWanted = null;
            string dest = "";
            try { dest = o.Values((StringValueKey)38, ""); } catch { }
            Coords d;
            if (want == null || !Coords.TryParse(dest, out d)) return;
            TravelData.LearnStart("spell", want, d, TravelData.AreaOfCoords(d), true);
            Util.WriteToChat("Travel: " + want + " now leads to " + d + ".");
        }

        // ── coordinates in chat ──
        private static bool _linking;
        private static readonly Regex TellRx = new Regex(@"<Tell:[^>]*>.*?<\\Tell>", RegexOptions.Singleline);

        public static string Link(string coords) { return "<Tell:IIDString:" + LinkId + ":" + coords + ">" + coords + "<\\Tell>"; }

        private static void LinkCoords(ChatTextInterceptEventArgs e)
        {
#if ACGODOT
            // (ACGodot's chat makes coordinates links itself: put again as a link here, the line came back as a plugin's -
            // its own kind (a channel, a tell, a fellow) lost, and its colour with it)
            return;
#endif
            if (_linking) return;
            string text = e.Text ?? "";
            if (text.IndexOf("IIDString:" + LinkId, StringComparison.Ordinal) >= 0) return;   // already linked
            if (!Coords.Rx.IsMatch(text)) return;
            // not inside a link that's already there (a name, an item)
            List<KeyValuePair<int, int>> tells = new List<KeyValuePair<int, int>>();
            foreach (Match tm in TellRx.Matches(text)) tells.Add(new KeyValuePair<int, int>(tm.Index, tm.Index + tm.Length));
            bool any = false;
            string linked = Coords.Rx.Replace(text, m =>
            {
                foreach (KeyValuePair<int, int> r in tells) if (m.Index >= r.Key && m.Index < r.Value) return m.Value;
                Coords c;
                if (!Coords.FromMatch(m, out c)) return m.Value;
                any = true;
                return Link(m.Value);
            });
            if (!any) return;
            e.Eat = true;
            _linking = true;
            try { CoreManager.Current.Actions.AddChatText(linked.TrimEnd('\n', '\r'), e.Color, e.Target); }
            catch { }
            finally { _linking = false; }
        }

        private static void OnChatClick(object sender, ChatClickInterceptEventArgs e)
        {
            try
            {
                if (e.Id != LinkId) return;
                Coords c;
                if (!Coords.TryParse(e.Text, out c)) return;
                e.Eat = true;
                GoTo(c, TravelData.AreaOfCoords(c), c.ToString(), 0);
            }
            catch (Exception ex) { Util.LogError(ex); }
        }

        /// <summary>/ga dumpenv: the room shapes this dungeon uses, copied out of client_portal.dat to Travel\envdump (for
        /// drawing the real walls).</summary>
        private static void DumpEnv()
        {
            uint cell = Cell();
            if ((cell & 0xFFFF) < 0x100) { Util.WriteToChat("Go into a dungeon first."); return; }
            Dictionary<uint, DCell> d = WorldMap.Dungeon((int)(cell >> 16));
            if (d == null) { Util.WriteToChat("No cells for this dungeon."); return; }
            string dir = Util.FullPath(System.IO.Path.Combine("Travel", "envdump"));
            System.IO.Directory.CreateDirectory(dir);
            HashSet<ushort> envs = new HashSet<ushort>();
            foreach (DCell c in d.Values) envs.Add(c.Env);
            int n = 0;
            foreach (ushort e in envs)
            {
                byte[] b = WorldMap.PortalFile(0x0D000000u | e);
                if (b == null) continue;
                System.IO.File.WriteAllBytes(System.IO.Path.Combine(dir, "0D00" + e.ToString("X4") + ".bin"), b);
                n++;
            }
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            foreach (DCell c in d.Values) sb.AppendLine(c.Id.ToString("X8") + " " + c.Env.ToString("X4") + " " + c.Struct + " " + c.X + " " + c.Y + " " + c.Z + " " + c.QW + " " + c.QX + " " + c.QY + " " + c.QZ);
            System.IO.File.WriteAllText(System.IO.Path.Combine(dir, ((int)(cell >> 16)).ToString("X4") + "_cells.txt"), sb.ToString());
            Util.WriteToChat("Copied " + n + " room shapes to " + dir + ".");
        }

        // ── GoArrow's commands ──

        /// <summary>/goarrow (/ga) and /mqt travel: true when it was one of them.</summary>
        public static bool Command(string text)
        {
            string t = (text ?? "").Trim();
            Match m = Regex.Match(t, @"^[/@](goarrow|ga)(\s+|$)(.*)$", RegexOptions.IgnoreCase);
            if (!m.Success) return false;
            Run(m.Groups[3].Value.Trim());
            return true;
        }

        public static void Run(string args)
        {
            string a = (args ?? "").Trim();
            string sub = a.Split(' ')[0].ToLowerInvariant();
            string rest = a.Length > sub.Length ? a.Substring(sub.Length).Trim() : "";
            switch (sub)
            {
                case "":
                case "show":
                    if (Active) TravelHud.Show(); else Util.WriteToChat("No destination - /ga to <coordinates or place>, /ga help for more.");
                    return;
                case "help":
                    Util.WriteToChat("Travel (MelksQB) - GoArrow's commands:");
                    Util.WriteToChat("/ga to <coords or place> - go there (a route or just the arrow, as set on the Config tab)");
                    Util.WriteToChat("/ga route <coords or place> - the fastest route, whatever the setting");
                    Util.WriteToChat("/ga arrow <coords or place> - just point the arrow");
                    Util.WriteToChat("/ga find <name> - places by name");
                    Util.WriteToChat("/ga loc - where you are");
                    Util.WriteToChat("/ga auto [coords or place] - auto travel (MelkTank does the moving); /ga manual - stop it");
                    Util.WriteToChat("/ga world - the world map; /ga map - the dungeon map");
                    Util.WriteToChat("/ga next | reroute | stop | hide");
                    return;
                case "to": case "dest": case "target": case "goto": Go(rest, 0); return;
                case "route": Go(rest, 1); return;
                case "arrow": case "point": Go(rest, 2); return;
                case "find": case "search":
                    {
                        List<Loc> f = TravelData.Find(rest, 10);
                        if (f.Count == 0) { Util.WriteToChat("Nothing called \"" + rest + "\"."); return; }
                        foreach (Loc l in f) Util.WriteToChat(l.Name + " (" + l.Type + ") " + Link(l.At.ToString()));
                        return;
                    }
                case "loc": case "coords": case "where":
                    {
                        Coords h = Here();
                        int ar = HereArea();
                        Util.WriteToChat("You're at " + Link(h.ToString()) + (ar >= 0 ? " in " + TravelData.AreaName(ar) : "") + ".");
                        return;
                    }
                case "next": if (Route != null && Step < Route.Legs.Count) { Step++; AutoTravel.RouteChanged(true); } return;
                case "reroute": Reroute(true, true); return;
                case "stop": case "clear": case "off": Clear(); Util.WriteToChat("Travel stopped."); return;
                case "hide": TravelHud.Hide(); return;
                case "map": DungeonView.Show(); return;
                case "world": case "worldmap": WorldView.Toggle(); return;
                case "boundary":
                    {
                        string a2 = rest.ToLowerInvariant();
                        if (a2 == "start") RecordStart();
                        else if (a2 == "stop") RecordStop(true);
                        else if (a2 == "cancel") RecordStop(false);
                        else if (a2 == "east" || a2 == "west") MarkSide(a2 == "east");
                        else if (a2 == "clear") { TravelData.SetBound(HereGroup.Length > 0 ? HereGroup : "tier11+", null); Util.WriteToChat("Travel: boundary cleared."); }
                        else Util.WriteToChat("/ga boundary start | stop | cancel | east | west | clear  - run along the tier area's southern edge (north of it is the tier area); east / west: its limit is where you stand");
                        return;
                    }
                case "dumpenv": DumpEnv(); return;
                case "auto": case "go": if (rest.Length > 0) Go(rest, 1); AutoTravel.Start(); return;
                case "manual": AutoTravel.Stop(true); return;
            }
            Go(a, 0);   // "/ga 33.6N 56.8E" or "/ga Holtburg"
        }
    }

    /// <summary>The 3D arrow in the game (Decal's PointToCoords, as MelkTank's nav uses): floats by you and points at where to go next.</summary>
    internal static class Arrow3D
    {
        private static D3DObj _arrow;
        private static string _key = "";

        public static void Update()
        {
            string label;
            Coords t = Travel.ArrowTarget(out label);
#if ACGODOT
            TravelHud.SyncBar();
            MarkMap(Travel.Active && !Travel.Arrived && t.Valid, t, label);
#endif
            Leg l = Travel.Current;
            bool want = Travel.Active && !Travel.Arrived && Travel.ArrowStyle != 0 && t.Valid && !(!Travel.ArrowOnly && l != null && l.Opt != null)
                        && TravelData.SameArea(Travel.HereArea(), !Travel.ArrowOnly && l != null && l.Target.Valid ? l.TargetArea : Travel.DestArea);
            if (!want) { Clear(); return; }
            double z = MyZ();
            string key = t.Raw() + "|" + Math.Round(z / 5);   // made again when the target changes, or you go up / down a lot
            if (key == _key && _arrow != null) return;
            Clear();
            _key = key;
            try { _arrow = CoreManager.Current.D3DService.PointToCoords((float)t.NS, (float)t.EW, (float)z, unchecked((int)0xFF33FF66)); }
            catch (Exception ex) { Util.LogError(ex); _arrow = null; }
        }

        /// <summary>The map mark sent again (a reroute: shown afresh even where it was).</summary>
        public static void Remark()
        {
#if ACGODOT
            _markKey = "";
#endif
        }

        public static void ClearMark()
        {
#if ACGODOT
            MarkMap(false, default(Coords), "");
#endif
        }

#if ACGODOT
        private static string _markKey = "";
        /// <summary>Where the arrow points, marked on ACGodot's map (whichever arrow style is picked).</summary>
        private static void MarkMap(bool on, Coords t, string label)
        {
            var h = ACGodot.DecalShim.Bridge.Host;
            if (h == null) return;
            string key = on ? t.Raw() + "|" + label : "";
            if (key == _markKey) return;
            _markKey = key;
            if (on) h.MarkOnMap?.Invoke(t.NS, t.EW, string.IsNullOrEmpty(label) ? t.ToString() : label);
            else h.ClearMapMark?.Invoke();
        }
#endif

        private static double MyZ()
        {
            try { return CoreManager.Current.WorldFilter[CoreManager.Current.CharacterFilter.Id].RawCoordinates().Z; } catch { return 0; }
        }

        public static void Clear()
        {
            _key = "";
            D3DObj o = _arrow;
            _arrow = null;
            if (o == null) return;
            try { o.Visible = false; } catch { }
            try { o.Scale(0.0001f); } catch { }
            try { IDisposable d = o as IDisposable; if (d != null) d.Dispose(); } catch { }
        }
    }

    /// <summary>This character's portal gems: the list on MelkTank's Portals tab (MelkTank_Settings.xml, next door).
    /// null when MelkTank isn't there.</summary>
    internal static class MelkTankGems
    {
        private static readonly string[] Defaults =
        {
            "Vaulted Dungeons Recall Gem", "Mellas Court Recall Gem", "Halls of Introduction Gem", "Penthouse Penthouse Recall Gem",
            "Marketplace Recall Gem", "Thaelaryn Lassel Recall Gem", "Valley of Death Encampment Gem", "Igmo's Retreat Recall Gem",
            "Zerivax Recall Gem", "Camp Ruggan", "Abandoned Mines Portal Sending Gem", "Mhoire Castle Portal Sending Gem",
            "Tusker King Sending Gem", "Timaru Portal Sending Gem", "Eldrytch Web Stronghold Portal Gem", "Restored Portal Gem",
            "Wicked Wares Gem", "Infinite Town Network Portal Gem", "Gaerlan's Library Portal Sending Gem", "Enlightened Facility Hub Portal Gem",
            "Town Network Sending Gem", "Hoshino Tent Sending Gem", "Frozen Valley Everlasting Portal Gem", "Portal Recall Gem"
        };
        private static List<string> _list;
        private static DateTime _stamp = DateTime.MinValue, _checked = DateTime.MinValue;
        private static bool _missing;

        public static string Path
        {
            get { return System.IO.Path.GetFullPath(System.IO.Path.Combine(Util.BasePath, System.IO.Path.Combine("..", "MelksTank", "Settings", "MelkTank_Settings.xml"))); }
        }

        public static List<string> List()
        {
            if ((DateTime.Now - _checked).TotalSeconds < 5) return _missing ? null : _list;
            _checked = DateTime.Now;
            try
            {
                string p = Path;
                if (!System.IO.File.Exists(p)) { _missing = true; return null; }
                _missing = false;
                DateTime w = System.IO.File.GetLastWriteTimeUtc(p);
                if (w == _stamp && _list != null) return _list;
                _stamp = w;
                System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
                Util.LoadXml(doc, p);
                string key = TravelData.CharKey ?? "";
                System.Xml.XmlNode c = null;
                foreach (System.Xml.XmlNode n in doc.SelectNodes("/MelkTank/Character"))
                    if (n.Attributes != null && n.Attributes["key"] != null && string.Equals(n.Attributes["key"].Value, key, StringComparison.OrdinalIgnoreCase)) { c = n; break; }
                System.Xml.XmlNode g = c == null ? null : c.SelectSingleNode("PortalGems");
                List<string> l = new List<string>();
                foreach (string s in (g != null ? g.InnerText : string.Join("|", Defaults)).Split('|')) if (s.Trim().Length > 0) l.Add(s.Trim());
                _list = l;
            }
            catch (Exception ex) { Util.LogError(ex); if (_list == null) _list = new List<string>(Defaults); }
            return _list;
        }
    }

    /// <summary>Spell names and your spellbook, through Decal's spell table (found by reflection, as MelkTank does).</summary>
    internal static class Spells
    {
        private static object _table;
        private static System.Reflection.MethodInfo _getById;
        private static bool _tried;

        private static object Prop(object o, string name)
        {
            if (o == null) return null;
            try { System.Reflection.PropertyInfo p = o.GetType().GetProperty(name); return p == null ? null : p.GetValue(o, null); } catch { return null; }
        }

        public static string Name(int id)
        {
            if (id == 0) return null;
            try
            {
                if (!_tried)
                {
                    _tried = true;
                    object fs = Prop(CoreManager.Current, "FileService");
                    if (fs == null)
                        foreach (System.Reflection.Assembly a in AppDomain.CurrentDomain.GetAssemblies())
                        {
                            Type t = a.GetType("Decal.Filters.FileService");
                            if (t == null) continue;
                            System.Reflection.MethodInfo f = CoreManager.Current.GetType().GetMethod("Filter");
                            if (f != null) fs = f.MakeGenericMethod(t).Invoke(CoreManager.Current, null);
                            break;
                        }
                    _table = Prop(fs, "SpellTable");
                    if (_table != null) _getById = _table.GetType().GetMethod("GetById", new[] { typeof(int) });
                }
                if (_getById == null) return null;
                return Prop(_getById.Invoke(_table, new object[] { id }), "Name") as string;
            }
            catch { return null; }
        }

        public static List<int> Known()
        {
            List<int> l = new List<int>();
            try
            {
                System.Collections.IEnumerable book = Prop(CoreManager.Current.CharacterFilter, "SpellBook") as System.Collections.IEnumerable;
                if (book != null)
                    foreach (object o in book)
                    {
                        if (o is int) { l.Add((int)o); continue; }
                        object id = Prop(o, "Id") ?? Prop(o, "SpellId") ?? Prop(o, "Key");
                        if (id is int) l.Add((int)id);
                    }
            }
            catch { }
            return l;
        }
    }
}
