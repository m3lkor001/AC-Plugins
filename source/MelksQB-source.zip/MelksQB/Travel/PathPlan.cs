using System;
using System.Collections.Generic;

namespace MelksQuestTracker.Travel
{
    /// <summary>
    /// Walking paths over the game's map: outdoors around water and slopes too steep to climb (A* over the 24 m ground cells),
    /// indoors along a dungeon's rooms and corridors (its cells and the openings between them).
    /// </summary>
    internal static class PathPlan
    {
        public static string Last = "";   // what the last plan did (for the Travel tab)

        /// <summary>Points to walk through from a to b (b included; a not). Straight line when the map can't help.</summary>
        public static List<Pt> Walk(Coords a, int areaA, uint cellA, Coords b, int areaB, uint cellB)
        {
            List<Pt> l = null;
            try
            {
                if (areaA >= 0 && areaB >= 0 && TravelData.SameArea(areaA, areaB)) l = Indoors(a, areaA, cellA, b, cellB);
                else if (areaA < 0 && areaB < 0) l = Outdoors(a, b);
            }
            catch (Exception ex) { Util.LogError(ex); l = null; }
            if (l == null)
            {
                l = new List<Pt>();
                double z = areaB < 0 ? WorldMap.GroundZ(b) : double.NaN;
                l.Add(new Pt(b.NS, b.EW, double.IsNaN(z) ? 0 : z, cellB));
            }
            return l;
        }

        // ── outdoors ──
        private static void Cell(Coords c, out int gx, out int gy)
        {
            gx = (int)Math.Floor((c.EW + 101.95) * 10.0);   // 240 m a unit, 24 m a cell
            gy = (int)Math.Floor((c.NS + 101.95) * 10.0);
        }

        private static Coords Center(int gx, int gy) { return new Coords((gy + 0.5) / 10.0 - 101.95, (gx + 0.5) / 10.0 - 101.95); }

        private static bool NearestWalkable(ref int gx, ref int gy)
        {
            if (W(gx, gy)) return true;
            for (int r = 1; r <= 3; r++)
                for (int dx = -r; dx <= r; dx++)
                    for (int dy = -r; dy <= r; dy++)
                        if ((Math.Abs(dx) == r || Math.Abs(dy) == r) && W(gx + dx, gy + dy)) { gx += dx; gy += dy; return true; }
            return false;
        }

        // a tier copy's boundary, when planning from where you stand inside one: no way out of it on foot
        private static string _fence;
        private static readonly Dictionary<int, bool> _fenceIn = new Dictionary<int, bool>();
        private static bool W(int x, int y, bool fenceOnly)
        {
            if (_fence == null) return true;
            int k = x * 4096 + y;
            bool r;
            if (!_fenceIn.TryGetValue(k, out r)) { r = TravelData.InsideBound(_fence, Center(x, y)); _fenceIn[k] = r; }
            return r;
        }

        private static bool W(int x, int y)
        {
            if (!WorldMap.PartWalkable(x, y)) return false;
            if (_fence == null) return true;
            int k = x * 4096 + y;
            bool r;
            if (!_fenceIn.TryGetValue(k, out r)) { r = TravelData.InsideBound(_fence, Center(x, y)); _fenceIn[k] = r; }
            return r;
        }

        public static List<Pt> Outdoors(Coords a, Coords b)
        {
            if (!WorldMap.Open()) { Last = WorldMap.Error; return null; }
            _fence = null; _fenceIn.Clear();
            {
                string fg = Travel.HereGroup;
                if (fg.Length > 0 && TravelData.Bounds.ContainsKey(fg) && a.DistanceTo(Travel.Here()) < 0.05 && TravelData.InsideBound(fg, a)) _fence = fg;
            }
            // over the ground's own triangles (each 24 m cell is two): steep ones are walls, and you go from one to the
            // next across a shared edge - mountains where nearly every cell has a flat half no longer read as open
            double ax = WX(a), ay = WY(a), bx = WX(b), by = WY(b);
            int sgx, sgy, sk, tgx, tgy, tk;
            if (!NearestTri(ax, ay, out sgx, out sgy, out sk) || !NearestTri(bx, by, out tgx, out tgy, out tk)) { Last = "start or end isn't on walkable ground"; return null; }
            if (ClearW(ax, ay, bx, by)) { Last = "straight"; return MarkDrops(a, Around(a, new List<Pt> { EndPt(b) })); }

            int margin = 40;
            int minX = Math.Max(0, Math.Min(sgx, tgx) - margin), maxX = Math.Min(2039, Math.Max(sgx, tgx) + margin);
            int minY = Math.Max(0, Math.Min(sgy, tgy) - margin), maxY = Math.Min(2039, Math.Max(sgy, tgy) + margin);
            int w = maxX - minX + 1, h = maxY - minY + 1;
            if ((long)w * h > 1200000) { Last = "too far to plan on foot"; return null; }
            int N2 = w * h * 2;
            float[] g = new float[N2];
            int[] from = new int[N2];
            bool[] closed = new bool[N2];
            for (int i = 0; i < N2; i++) { g[i] = float.MaxValue; from[i] = -1; }
            Func<int, int, int, int> Id = (x, y, k) => ((x - minX) * h + (y - minY)) * 2 + k;
            Heap open = new Heap();
            int s = Id(sgx, sgy, sk), t = Id(tgx, tgy, tk);
            g[s] = 0;
            open.Push(s, (float)(Math.Sqrt((bx - ax) * (bx - ax) + (by - ay) * (by - ay)) / 24.0));
            int[] nb = new int[9];
            int expanded = 0;
            bool found = false;
            while (open.Count > 0)
            {
                int u = open.Pop();
                if (closed[u]) continue;
                closed[u] = true;
                if (u == t) { found = true; break; }
                if (++expanded > 250000) break;
                int uk = u & 1, uc = u >> 1, ux = uc / h + minX, uy = uc % h + minY;
                double ucx, ucy; WorldMap.TriCenter(ux, uy, uk, out ucx, out ucy);
                int m = WorldMap.TriNeighbours(ux, uy, uk, nb);
                for (int i = 0; i < m; i++)
                {
                    int vx = nb[i * 3], vy = nb[i * 3 + 1], vk = nb[i * 3 + 2];
                    if (vx < minX || vx > maxX || vy < minY || vy > maxY) continue;
                    int v = Id(vx, vy, vk);
                    if (closed[v]) continue;
                    if (!W(vx, vy, true)) continue;
                    double vcx, vcy; WorldMap.TriCenter(vx, vy, vk, out vcx, out vcy);
                    // a steep triangle: only down it (jumping off a drop), never up it
                    if (!WorldMap.TriWalkable(vx, vy, vk) && Zw(vcx, vcy) > Zw(ucx, ucy) - 0.5) continue;
                    float ng = g[u] + (float)(Math.Sqrt((vcx - ucx) * (vcx - ucx) + (vcy - ucy) * (vcy - ucy)) / 24.0);
                    if (ng >= g[v]) continue;
                    g[v] = ng; from[v] = u;
                    open.Push(v, ng + (float)(Math.Sqrt((bx - vcx) * (bx - vcx) + (by - vcy) * (by - vcy)) / 24.0));
                }
            }
            if (!found) { Last = "no way on foot found (" + expanded + " ground triangles looked at)"; return null; }
            List<double[]> tris = new List<double[]>();
            for (int v = t; v >= 0 && v != s; v = from[v])
            {
                int vk = v & 1, vc = v >> 1;
                double cx, cy; WorldMap.TriCenter(vc / h + minX, vc % h + minY, vk, out cx, out cy);
                tris.Add(new[] { cx, cy });
            }
            tris.Reverse();
            // fewer points: on past one when the straight line to the next stays on walkable triangles
            List<Pt> kept = new List<Pt>();
            double px = ax, py = ay;
            for (int i = 0; i < tris.Count; i++)
            {
                if (i + 1 < tris.Count && ClearW(px, py, tris[i + 1][0], tris[i + 1][1])) continue;
                if (i == tris.Count - 1) break;   // the last is the destination's own triangle
                if (WorldMap.SteepAt(tris[i][0], tris[i][1])) continue;   // never a point on a slope you can't stand on (you'd slide)
                Coords c = FromW(tris[i][0], tris[i][1]);
                double z = WorldMap.GroundZ(c);
                kept.Add(new Pt(c.NS, c.EW, double.IsNaN(z) ? 0 : z, 0));
                px = tris[i][0]; py = tris[i][1];
            }
            kept.Add(EndPt(b));
            Last = "over the ground (" + (kept.Count - 1) + " turns)";
            return MarkDrops(a, Around(a, kept));
        }

        /// <summary>Where the way goes over the edge of a drop (ground too steep to walk, going down): a point just before
        /// the edge marked to jump off it - you can't walk onto it, you have to jump.</summary>
        private static List<Pt> MarkDrops(Coords a, List<Pt> l)
        {
            if (l == null) return null;
            List<Pt> o = new List<Pt>();
            double px = WX(a), py = WY(a);
            foreach (Pt p in l)
            {
                double qx = (p.EW + 101.95) * 240.0, qy = (p.NS + 101.95) * 240.0;
                double d = Math.Sqrt((qx - px) * (qx - px) + (qy - py) * (qy - py));
                int n = Math.Max(1, (int)Math.Ceiling(d / 0.5));
                bool onSteep = WorldMap.SteepAt(px, py);
                for (int i = 1; i < n; i++)
                {
                    double f = (double)i / n, x = px + (qx - px) * f, y = py + (qy - py) * f;
                    bool st = WorldMap.SteepAt(x, y);
                    if (st && !onSteep)
                    {
                        // take off right at the edge (1 m short), facing along the way
                        double back = Math.Min(1.0, f * d) / Math.Max(0.01, d);
                        double ex = x - (qx - px) * back, ey = y - (qy - py) * back;
                        Coords ec = FromW(ex, ey);
                        double hd = (Math.Atan2(qx - px, qy - py) * 180.0 / Math.PI + 360) % 360;
                        Pt e = new Pt(ec.NS, ec.EW, Zw(ex, ey), 0);
                        e.Jump = hd + 1;
                        o.Add(e);
                        // the landing: past the bottom of the slope, well out on standable ground (the next point
                        // after the jump - aimed there, not back at the slope)
                        int j = i;
                        while (j < n && WorldMap.SteepAt(px + (qx - px) * j / n, py + (qy - py) * j / n)) j++;
                        // as far out as a full running jump carries you from that height (your Jump and Run), at least
                        // 4 m past the bottom - a point right at the foot of the drop turned you back into the slope
                        double drop = Math.Max(0, Zw(ex, ey) - Zw(px + (qx - px) * j / n, py + (qy - py) * j / n));
                        int byJump = (i - 2) + (int)(JumpRange(drop) / 0.5);
                        int land = Math.Min(n, Math.Max(j + 8, byJump));
                        while (land < n && WorldMap.SteepAt(px + (qx - px) * land / n, py + (qy - py) * land / n)) land++;
                        if (land < n)
                        {
                            double lx = px + (qx - px) * land / n, ly = py + (qy - py) * land / n;
                            if (!WorldMap.SteepAt(lx, ly))
                            {
                                Coords lc = FromW(lx, ly);
                                o.Add(new Pt(lc.NS, lc.EW, Zw(lx, ly), 0));
                            }
                        }
                        i = Math.Max(i, land - 1);
                        st = false;
                    }
                    onSteep = st;
                }
                o.Add(p);
                px = qx; py = qy;
            }
            return o;
        }

        /// <summary>How far (m, along the ground) a full running jump goes from a ledge this high: the game's jump
        /// height from your Jump skill, your run speed from Run - kept short of the most (70%, at most 15 m) to land
        /// on the ground past the drop, not beyond where the path turns.</summary>
        private static double JumpRange(double drop)
        {
            double js = 0, rs = 0;
            try
            {
                js = Decal.Adapter.CoreManager.Current.CharacterFilter.EffectiveSkill[Decal.Adapter.Wrappers.CharFilterSkillType.Jump];
                rs = Decal.Adapter.CoreManager.Current.CharacterFilter.EffectiveSkill[Decal.Adapter.Wrappers.CharFilterSkillType.Run];
            }
            catch { }
            if (js <= 0 && rs <= 0) return 4;
            const double g = 9.8;
            double h = js / (js + 1300.0) * 22.2 + 0.05;                     // the jump's height at full power
            double vz = Math.Sqrt(2 * g * Math.Max(0.35, h));
            double t = (vz + Math.Sqrt(vz * vz + 2 * g * drop)) / g;          // up, then down past the ledge's height
            double rate = rs >= 800 ? 4.5 : (rs / (rs + 200.0) * 11.0 + 4.0) / 4.0;
            double speed = 4.0 * rate;
            return Math.Max(4, Math.Min(15, speed * t * 0.7));
        }

        private static double Zw(double x, double y) { double z = WorldMap.GroundZ(FromW(x, y)); return double.IsNaN(z) ? 0 : z; }

        private static Pt EndPt(Coords b) { double z = WorldMap.GroundZ(b); return new Pt(b.NS, b.EW, double.IsNaN(z) ? 0 : z, 0); }

        /// <summary>The walkable triangle under a point, or the nearest one within 3 cells.</summary>
        private static bool NearestTri(double x, double y, out int gx, out int gy, out int k)
        {
            gx = (int)Math.Floor(x / 24.0); gy = (int)Math.Floor(y / 24.0); k = 0;
            if (gx >= 0 && gy >= 0 && gx < 2040 && gy < 2040 && !WorldMap.SteepAt(x, y))
            {
                double lx = x - gx * 24.0, ly = y - gy * 24.0;
                k = (WorldMap.SWtoNE(gx, gy) ? lx >= ly : lx + ly <= 24.0) ? 0 : 1;
                return true;
            }
            double best = double.MaxValue; int bgx = 0, bgy = 0, bk = 0; bool any = false;
            for (int dx = -3; dx <= 3; dx++)
                for (int dy = -3; dy <= 3; dy++)
                    for (int kk = 0; kk < 2; kk++)
                    {
                        int cx = gx + dx, cy = gy + dy;
                        if (cx < 0 || cy < 0 || cx >= 2040 || cy >= 2040 || !WorldMap.TriWalkable(cx, cy, kk)) continue;
                        double tx, ty; WorldMap.TriCenter(cx, cy, kk, out tx, out ty);
                        double d = (tx - x) * (tx - x) + (ty - y) * (ty - y);
                        if (d < best) { best = d; bgx = cx; bgy = cy; bk = kk; any = true; }
                    }
            gx = bgx; gy = bgy; k = bk;
            return any;
        }

        /// <summary>The straight line (world metres) stays on walkable triangles (every 3 m) and inside a tier copy's fence.</summary>
        private static bool ClearW(double x0, double y0, double x1, double y1)
        {
            double d = Math.Sqrt((x1 - x0) * (x1 - x0) + (y1 - y0) * (y1 - y0));
            int n = Math.Max(1, (int)Math.Ceiling(d / 3.0));
            for (int i = 1; i < n; i++)
            {
                double f = (double)i / n, x = x0 + (x1 - x0) * f, y = y0 + (y1 - y0) * f;
                if (WorldMap.SteepAt(x, y))
                {
                    double fp = (double)(i - 1) / n;
                    if (Zw(x, y) > Zw(x0 + (x1 - x0) * fp, y0 + (y1 - y0) * fp) - 0.5) return false;   // up a cliff (down one: a drop, fine)
                }
                if (_fence != null && !W((int)Math.Floor(x / 24.0), (int)Math.Floor(y / 24.0), true)) return false;
            }
            return true;
        }

        // ── outdoors, close up: around buildings, trees, rocks, fences (Obstacles: the game's own solid shapes, 0.5 m) ──
        public static bool AvoidThings = true;
        private static double WX(Coords c) { return (c.EW + 101.95) * 240.0; }
        private static double WY(Coords c) { return (c.NS + 101.95) * 240.0; }
        private static Coords FromW(double x, double y) { return new Coords(y / 240.0 - 101.95, x / 240.0 - 101.95); }

        /// <summary>The ground route, bent round whatever's standing in the way: each stretch (up to 120 m) straight when it's
        /// clear, else found on a 0.5 m grid and pulled tight.</summary>
        private static List<Pt> Around(Coords a, List<Pt> route)
        {
            if (!AvoidThings || route == null || route.Count == 0) return route;
            try
            {
                List<double[]> wp = new List<double[]>();
                double cx = WX(a), cy = WY(a);
                wp.Add(new[] { cx, cy });
                foreach (Pt p in route)
                {
                    double tx = (p.EW + 101.95) * 240.0, ty = (p.NS + 101.95) * 240.0;
                    double d = Math.Sqrt((tx - cx) * (tx - cx) + (ty - cy) * (ty - cy));
                    int parts = Math.Max(1, (int)Math.Ceiling(d / 120.0));
                    for (int k = 1; k <= parts; k++) wp.Add(new[] { cx + (tx - cx) * k / parts, cy + (ty - cy) * k / parts });
                    cx = tx; cy = ty;
                }
                List<double[]> outp = new List<double[]>();
                double[] cur = wp[0];
                int bent = 0, failed = 0;
                for (int i = 1; i < wp.Count; i++)
                {
                    double[] t = wp[i];
                    if (Seg(cur, t)) { outp.Add(t); cur = t; continue; }   // clear: straight (pulled tight below)
                    // a wider box when the way round isn't close by (out of a walled town by its gate, 80 m off the line)
                    List<double[]> leg = Grid(cur, t, 30);
                    if (leg == null) leg = Grid(cur, t, 90);
                    if (leg == null) leg = Grid(cur, t, 160);
                    if (leg == null)
                    {
                        failed++;
                        Coords fc = FromW(t[0], t[1]);
                        Util.WriteToChat("Travel: couldn't find a way round what's in the way before " + Math.Abs(fc.NS).ToString("0.00") + (fc.NS < 0 ? "S" : "N") + " " + Math.Abs(fc.EW).ToString("0.00") + (fc.EW < 0 ? "W" : "E") + " (" + _gridWhy + ") - straight on there.");
                    }
                    if (leg != null) { bent++; outp.AddRange(leg); }
                    else outp.Add(t);
                    cur = outp[outp.Count - 1];
                }
                // pull tight: drop a point when the line past it is clear
                List<double[]> tight = new List<double[]>();
                double[] from = wp[0];
                for (int i = 0; i < outp.Count; i++)
                {
                    if (i + 1 < outp.Count && Seg(from, outp[i + 1])) continue;
                    if (i + 1 < outp.Count && WorldMap.SteepAt(outp[i][0], outp[i][1])) continue;   // not a point on steep ground (you'd slide off it)
                    tight.Add(outp[i]); from = outp[i];
                }
                List<Pt> l = new List<Pt>();
                for (int i = 0; i < tight.Count; i++)
                {
                    Coords c = i == tight.Count - 1 ? FromW(tight[i][0], tight[i][1]) : FromW(tight[i][0], tight[i][1]);
                    double z = WorldMap.GroundZ(c);
                    l.Add(new Pt(c.NS, c.EW, double.IsNaN(z) ? 0 : z, 0));
                }
                // the very end: exactly where it was asked for
                Pt last = route[route.Count - 1];
                if (l.Count > 0) l[l.Count - 1] = last; else l.Add(last);
                if (bent > 0 || failed > 0) Last += "; round " + bent + " thing" + (bent == 1 ? "" : "s") + " in the way" + (failed > 0 ? " (" + failed + " not)" : "");
                return l;
            }
            catch (Exception ex) { Util.LogError(ex); return route; }
        }

        /// <summary>Nothing solid on the straight line (every 0.25 m).</summary>
        private static bool Seg(double[] p, double[] q)
        {
            double d = Math.Sqrt((q[0] - p[0]) * (q[0] - p[0]) + (q[1] - p[1]) * (q[1] - p[1]));
            int n = Math.Max(1, (int)Math.Ceiling(d / 0.25));
            double pz = double.NaN;
            for (int i = 1; i < n; i++)   // (not the ends: you / a portal can be standing in something's reach)
            {
                double f = (double)i / n;
                double sx = p[0] + (q[0] - p[0]) * f, sy = p[1] + (q[1] - p[1]) * f;
                if (Obstacles.Blocked(sx, sy)) return false;
                if (WorldMap.SteepAt(sx, sy))
                {
                    // a slope too steep to walk: fine going down it (you drop), not up it
                    double z = Zw(sx, sy);
                    if (double.IsNaN(pz)) { double f0 = (double)(i - 1) / n; pz = Zw(p[0] + (q[0] - p[0]) * f0, p[1] + (q[1] - p[1]) * f0); }
                    if (z > pz - 0.01) return false;
                    pz = z;
                }
                else pz = double.NaN;
            }
            return true;
        }

        /// <summary>A* on the 0.5 m grid from p to q (a box round both, 30 m wider). Points after p, ending at q; null = none found.</summary>
        private static string _gridWhy = "";
        private static List<double[]> Grid(double[] p, double[] q, double pad)
        {
            const double R = Obstacles.Res;
            double x0 = Math.Min(p[0], q[0]) - pad, y0 = Math.Min(p[1], q[1]) - pad;
            int w = (int)Math.Ceiling((Math.Abs(q[0] - p[0]) + 2 * pad) / R) + 1, h = (int)Math.Ceiling((Math.Abs(q[1] - p[1]) + 2 * pad) / R) + 1;
            if ((long)w * h > 1600000) return null;
            bool[] block = new bool[w * h], steep = new bool[w * h], either = new bool[w * h];
            for (int i = 0; i < w; i++)
                for (int j = 0; j < h; j++)
                {
                    double wx = x0 + (i + 0.5) * R, wy = y0 + (j + 0.5) * R;
                    block[i * h + j] = Obstacles.Blocked(wx, wy);
                    steep[i * h + j] = WorldMap.SteepAt(wx, wy);
                    either[i * h + j] = block[i * h + j] || steep[i * h + j];
                }
            // doors and gates (a keep's portcullis): a way through, open or shut - the game's own shapes keep the gatehouse
            // round it, and with room kept from anything solid the way past a closed gate was walled up: out of a walled town
            // there was "no way round", and the route ran into the wall
            foreach (double[] d in Doors(x0, y0, x0 + w * R, y0 + h * R))
            {
                int ci = (int)((d[0] - x0) / R), cj = (int)((d[1] - y0) / R), r = (int)Math.Ceiling(2.0 / R);
                for (int di = -r; di <= r; di++)
                    for (int dj = -r; dj <= r; dj++)
                    {
                        int i = ci + di, j = cj + dj;
                        if (i < 0 || j < 0 || i >= w || j >= h || (di * di + dj * dj) * R * R > 4.0) continue;
                        block[i * h + j] = false;
                        either[i * h + j] = steep[i * h + j];
                    }
            }
            // steep ground: down it (a drop you jump off) but never up it - the ground's height, square by square, as needed
            float[] zc = new float[w * h];
            for (int i = 0; i < zc.Length; i++) zc[i] = float.NaN;
            Func<int, float> Z = c => { if (float.IsNaN(zc[c])) zc[c] = (float)Zw(x0 + (c / h + 0.5) * R, y0 + (c % h + 0.5) * R); return zc[c]; };
            Func<double[], int> At = c => { int i = (int)((c[0] - x0) / R), j = (int)((c[1] - y0) / R); return Math.Max(0, Math.Min(w - 1, i)) * h + Math.Max(0, Math.Min(h - 1, j)); };
            int s = Free(either, w, h, At(p)), t = Free(either, w, h, At(q));
            if (s < 0 || t < 0) { _gridWhy = s < 0 ? "the start is boxed in" : "the end is boxed in"; return null; }
            _gridWhy = "no way within " + pad + " m of the line";
            float[] g = new float[w * h]; int[] from = new int[w * h]; bool[] closed = new bool[w * h];
            for (int i = 0; i < g.Length; i++) { g[i] = float.MaxValue; from[i] = -1; }
            int tx = t / h, ty = t % h;
            Heap open = new Heap();
            g[s] = 0; open.Push(s, H(s / h, s % h, tx, ty));
            int[] DX = { 1, -1, 0, 0, 1, 1, -1, -1 }, DY = { 0, 0, 1, -1, 1, -1, 1, -1 };
            int expanded = 0; bool found = false;
            while (open.Count > 0)
            {
                int u = open.Pop();
                if (closed[u]) continue;
                closed[u] = true;
                if (u == t) { found = true; break; }
                if (++expanded > 1500000) break;
                int ux = u / h, uy = u % h;
                for (int k = 0; k < 8; k++)
                {
                    int vx = ux + DX[k], vy = uy + DY[k];
                    if (vx < 0 || vy < 0 || vx >= w || vy >= h) continue;
                    int v = vx * h + vy;
                    if (closed[v] || block[v]) continue;
                    if (k >= 4 && (block[(ux + DX[k]) * h + uy] || block[ux * h + uy + DY[k]])) continue;
                    if (steep[v] && Z(v) > Z(u) - 0.05f) continue;   // up (or along) a slope too steep to climb
                    float ng = g[u] + (k >= 4 ? 1.4142f : 1f);
                    if (ng >= g[v]) continue;
                    g[v] = ng; from[v] = u;
                    open.Push(v, ng + H(vx, vy, tx, ty));
                }
            }
            if (!found) return null;
            List<double[]> l = new List<double[]>();
            for (int v = t; v >= 0 && v != s; v = from[v]) l.Add(new[] { x0 + (v / h + 0.5) * R, y0 + (v % h + 0.5) * R });
            l.Reverse();
            if (l.Count == 0) l.Add(q); else l[l.Count - 1] = q;
            return l;
        }

        /// <summary>The doors and gates the game shows in the box (world metres).</summary>
        private static List<double[]> Doors(double xa, double ya, double xb, double yb)
        {
            List<double[]> l = new List<double[]>();
            try
            {
                foreach (Decal.Adapter.Wrappers.WorldObject o in Decal.Adapter.CoreManager.Current.WorldFilter.GetLandscape())
                {
                    if (o.ObjectClass != Decal.Adapter.Wrappers.ObjectClass.Door) continue;
                    Decal.Adapter.Wrappers.CoordsObject c = o.Coordinates();
                    double x = (c.EastWest + 101.95) * 240.0, y = (c.NorthSouth + 101.95) * 240.0;
                    if (x >= xa && x <= xb && y >= ya && y <= yb) l.Add(new[] { x, y });
                }
            }
            catch { }
            return l;
        }

        /// <summary>The square, or the nearest open one within 20 m (you or the goal standing close to something), or -1.</summary>
        private static int Free(bool[] block, int w, int h, int c)
        {
            if (!block[c]) return c;
            int cx = c / h, cy = c % h;
            for (int r = 1; r <= 40; r++)   // (20 m: a goal inside a building's outline - its door's out at the edge)
                for (int dx = -r; dx <= r; dx++)
                    for (int dy = -r; dy <= r; dy++)
                    {
                        if (Math.Abs(dx) != r && Math.Abs(dy) != r) continue;
                        int x = cx + dx, y = cy + dy;
                        if (x >= 0 && y >= 0 && x < w && y < h && !block[x * h + y]) return x * h + y;
                    }
            return -1;
        }

        private static List<Pt> Finish(List<int[]> cells, Coords b)
        {
            List<Pt> l = new List<Pt>();
            foreach (int[] c in cells)
            {
                if (cells.Count > 0 && c == cells[cells.Count - 1]) break;   // the last one is the destination itself
                Coords p = Center(c[0], c[1]);
                double z = WorldMap.GroundZ(p);
                l.Add(new Pt(p.NS, p.EW, double.IsNaN(z) ? 0 : z, 0));
            }
            double bz = WorldMap.GroundZ(b);
            l.Add(new Pt(b.NS, b.EW, double.IsNaN(bz) ? 0 : bz, 0));
            return l;
        }

        private static float H(int x, int y, int tx, int ty)
        {
            int dx = Math.Abs(x - tx), dy = Math.Abs(y - ty);
            return (dx + dy) + (1.4142f - 2) * Math.Min(dx, dy);
        }

        /// <summary>Every ground cell on the straight line between two cells is walkable.</summary>
        private static bool Clear(int x0, int y0, int x1, int y1)
        {
            int n = Math.Max(Math.Abs(x1 - x0), Math.Abs(y1 - y0)) * 3;
            if (n == 0) return true;
            for (int i = 0; i <= n; i++)
            {
                double f = (double)i / n;
                int x = (int)Math.Floor(x0 + 0.5 + (x1 - x0) * f), y = (int)Math.Floor(y0 + 0.5 + (y1 - y0) * f);
                if (!W(x, y)) return false;
            }
            return true;
        }

        private class Heap
        {
            private readonly List<KeyValuePair<float, int>> _h = new List<KeyValuePair<float, int>>();
            public int Count { get { return _h.Count; } }
            public void Push(int v, float p)
            {
                _h.Add(new KeyValuePair<float, int>(p, v));
                int i = _h.Count - 1;
                while (i > 0) { int pa = (i - 1) / 2; if (_h[pa].Key <= _h[i].Key) break; KeyValuePair<float, int> t = _h[pa]; _h[pa] = _h[i]; _h[i] = t; i = pa; }
            }
            public int Pop()
            {
                int top = _h[0].Value;
                _h[0] = _h[_h.Count - 1]; _h.RemoveAt(_h.Count - 1);
                int i = 0;
                while (true)
                {
                    int l = i * 2 + 1, r = l + 1, m = i;
                    if (l < _h.Count && _h[l].Key < _h[m].Key) m = l;
                    if (r < _h.Count && _h[r].Key < _h[m].Key) m = r;
                    if (m == i) break;
                    KeyValuePair<float, int> t = _h[m]; _h[m] = _h[i]; _h[i] = t; i = m;
                }
                return top;
            }
        }

        // ── indoors ──
        private static uint NearestCell(Dictionary<uint, DCell> d, Coords c)
        {
            uint best = 0; double bd = double.MaxValue;
            foreach (DCell x in d.Values)
            {
                double dd = WorldMap.CellCoords(x.Id, x.X, x.Y).DistanceTo(c);
                if (dd < bd) { bd = dd; best = x.Id; }
            }
            return best;
        }

        private const double Clearance = 2.4;   // metres from anything placed in a room

        private static double ClearanceAt(DCell c, double x, double y)
        {
            double best = double.MaxValue;
            foreach (float[] st in c.Statics)
            {
                if (Math.Abs(st[2] - c.Z) > 4) continue;   // up in the air (lamps, banners) or below the floor
                double dx = st[0] - x, dy = st[1] - y, dd = Math.Sqrt(dx * dx + dy * dy);
                if (dd < best) best = dd;
            }
            return best;
        }

        /// <summary>The room's middle, or the clearest spot near it when something stands there (a fountain, a tree).</summary>
        private static double[] ClearSpot(DCell c)
        {
            if (ClearanceAt(c, c.X, c.Y) >= Clearance) return new[] { c.X, c.Y };
            double bx = c.X, by = c.Y, bc = -1;
            for (int dx = -4; dx <= 4; dx++)
                for (int dy = -4; dy <= 4; dy++)
                {
                    double cl = Math.Min(ClearanceAt(c, c.X + dx, c.Y + dy), 6) - Math.Sqrt(dx * dx + dy * dy) * 0.05;
                    if (cl > bc) { bc = cl; bx = c.X + dx; by = c.Y + dy; }
                }
            return new[] { bx, by };
        }

        /// <summary>A straight walk from p to q (landblock metres) stays inside the rooms on the way (each about a 10 m square)
        /// and keeps clear of what's placed in them.</summary>
        // the portals in the dungeon / hub being walked (not the one being walked to): x, y (landblock metres), z (NaN: not known)
        private static List<double[]> _portals = new List<double[]>();
        // how far from a portal's middle walking takes it: the swirl is bigger than it looks, and Nav drifts a metre or so
        private const double PortalLineM = 4.6, PortalPointM = 5.2, PortalHardM = 3.8;   // (a way round: never nearer than Hard, kept out to Line where the room allows)
        /// <summary>The point (x, y) on the line p→q is in a portal's reach - but a portal the line starts (or ends) inside
        /// only counts while the line is heading into it (walking away from the one behind you is fine).</summary>
        private static bool PortalOnLine(double x, double y, double z, double[] p, double[] q, double r)
        {
            foreach (double[] o in _portals)
            {
                if (!double.IsNaN(o[2]) && Math.Abs(o[2] - z) > 3) continue;
                double d = Math.Sqrt((o[0] - x) * (o[0] - x) + (o[1] - y) * (o[1] - y));
                if (d >= r) continue;
                double dp = Math.Sqrt((o[0] - p[0]) * (o[0] - p[0]) + (o[1] - p[1]) * (o[1] - p[1]));
                double dq = Math.Sqrt((o[0] - q[0]) * (o[0] - q[0]) + (o[1] - q[1]) * (o[1] - q[1]));
                if (dp < r && d > dp - 0.5) continue;   // starting by it, and not getting closer
                if (dq < r && d > dq - 0.5) continue;   // ending by it (the point was put as far off as the room allows)
                return true;
            }
            return false;
        }
        private static bool NearPortal(double x, double y, double z, double r)
        {
            foreach (double[] q in _portals)
            {
                if (!double.IsNaN(q[2]) && Math.Abs(q[2] - z) > 3) continue;
                double dx = q[0] - x, dy = q[1] - y;
                if (dx * dx + dy * dy < r * r) return true;
            }
            return false;
        }

        // keep-out spots on this dungeon's map (points of type "Keep out"): x, y, z (NaN: any level)
        private static List<double[]> _keep = new List<double[]>();
        private const double KeepCellM = 6, KeepLineM = 4;
        private static bool NearKeep(double x, double y, double z, double r)
        {
            foreach (double[] q in _keep)
            {
                if (!double.IsNaN(q[2]) && !double.IsNaN(z) && Math.Abs(q[2] - z) > 3) continue;
                double dx = q[0] - x, dy = q[1] - y;
                if (dx * dx + dy * dy < r * r) return true;
            }
            return false;
        }

        private static bool Sight(double[] p, double[] q, List<uint> cells, Dictionary<uint, DCell> d)
        {
            double len = Math.Sqrt((q[0] - p[0]) * (q[0] - p[0]) + (q[1] - p[1]) * (q[1] - p[1]));
            if (Math.Abs(q[2] - p[2]) > 1.5) return false;   // stairs: point by point
            // a wall on the way (the rooms' real walls, at this height): not straight through it - a hallway running through
            // a big room's space (above / beside it) has walls the room's outline doesn't show
            double z = (p[2] + q[2]) / 2;
            double bx0 = Math.Min(p[0], q[0]) - 12, bx1 = Math.Max(p[0], q[0]) + 12, by0 = Math.Min(p[1], q[1]) - 12, by1 = Math.Max(p[1], q[1]) + 12;
            List<DCell> band = new List<DCell>();   // the rooms near the line (checked many times over below)
            foreach (DCell c in d.Values)
            {
                if (c.X < bx0 || c.X > bx1 || c.Y < by0 || c.Y > by1) continue;
                if (Math.Abs(c.Z - p[2]) <= 2) band.Add(c);
                if (Math.Abs(c.Z - z) > 2.5) continue;
                List<float[]> fl = CellShapes.Floor(c);
                if (fl == null) continue;
                foreach (float[] pg in fl)
                    if (pg[0] == 2 && pg.Length >= 5 && Crosses(p[0], p[1], q[0], q[1], pg[1], pg[2], pg[3], pg[4])) return false;
            }
            int n = Math.Max(1, (int)Math.Ceiling(len / 0.5));
            for (int i = 0; i <= n; i++)
            {
                double f = (double)i / n, x = p[0] + (q[0] - p[0]) * f, y = p[1] + (q[1] - p[1]) * f;
                bool inside = false;
                // any room at this height (a big hall is several of the game's rooms side by side, not only the ones the
                // room-to-room path went through - the walls are checked above)
                foreach (DCell c in band)
                {
                    if (Math.Abs(c.Z - p[2]) > 2 || Math.Abs(x - c.X) > 12 || Math.Abs(y - c.Y) > 12) continue;
                    if (!OnFloor(c, x, y)) continue;   // the room's real floor (not just the square round its middle)
                    inside = true;
                    if (ClearanceAt(c, x, y) < Clearance) return false;
                }
                if (!inside) return false;
                // (the first 2.5 m: where you're standing - next to the portal you came in by, say - isn't the way's fault)
                if (PortalOnLine(x, y, p[2], p, q, PortalLineM)) return false;   // walking over a portal takes it
                if (f * len > 2.5 && NearKeep(x, y, p[2], KeepLineM)) return false;
            }
            return true;
        }

        /// <summary>What the last dungeon plan saw (Maps\Shapes\plan_XXXX.txt, overwritten each time): every room's floor
        /// (with heights), walls, links and which links count as walkable, and the rooms the path went through - to work out
        /// a wrong route afterwards.</summary>
        private static void DumpPlan(int lb, uint s, uint t, List<uint> path, Dictionary<uint, DCell> d, Coords a, Coords b, List<double[]> pts, List<double[]> keep)
        {
            System.Globalization.CultureInfo ci = System.Globalization.CultureInfo.InvariantCulture;
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append("plan ").Append(lb.ToString("X4")).Append(" from ").Append(s.ToString("X8")).Append(" ").Append(a).Append(" to ").Append(t.ToString("X8")).Append(" ").Append(b).Append(" at ").Append(DateTime.Now.ToString("HH:mm:ss")).Append('\n');
            sb.Append("path");
            foreach (uint id in path) sb.Append(' ').Append(id.ToString("X8"));
            sb.Append('\n');
            foreach (double[] q in pts) sb.Append("pt ").Append(q[0].ToString("0.##", ci)).Append(' ').Append(q[1].ToString("0.##", ci)).Append(' ').Append(q[2].ToString("0.##", ci)).Append(' ').Append(((uint)q[3]).ToString("X8")).Append('\n');
            foreach (double[] q in keep) sb.Append("keep ").Append(q[0].ToString("0.##", ci)).Append(' ').Append(q[1].ToString("0.##", ci)).Append(' ').Append(q[2].ToString("0.##", ci)).Append(' ').Append(((uint)q[3]).ToString("X8")).Append('\n');
            foreach (double[] q in _portals) sb.Append("portal ").Append(q[0].ToString("0.##", ci)).Append(' ').Append(q[1].ToString("0.##", ci)).Append(' ').Append(q[2].ToString("0.##", ci)).Append('\n');
            foreach (DCell c in d.Values)
            {
                sb.Append("cell ").Append(c.Id.ToString("X8")).Append(' ').Append(c.X.ToString("0.##", ci)).Append(' ').Append(c.Y.ToString("0.##", ci)).Append(' ').Append(c.Z.ToString("0.##", ci)).Append('\n');
                sb.Append(" next");
                foreach (uint v in c.Next)
                {
                    DCell cv; bool ok = d.TryGetValue(v, out cv) && Doorway(c, cv);
                    sb.Append(' ').Append(v.ToString("X8")).Append(ok ? "+" : "-");
                }
                sb.Append('\n');
                List<float[]> f3 = CellShapes.Floor3(c), f2 = CellShapes.Floor(c);
                if (f3 != null) foreach (float[] pg in f3) { sb.Append(" f").Append(pg[0].ToString("0", ci)); for (int k = 1; k < pg.Length; k++) sb.Append(' ').Append(pg[k].ToString("0.##", ci)); sb.Append('\n'); }
                if (f2 != null) foreach (float[] pg in f2) if (pg[0] == 2) { sb.Append(" w"); for (int k = 1; k < pg.Length; k++) sb.Append(' ').Append(pg[k].ToString("0.##", ci)); sb.Append('\n'); }
            }
            string dir = Util.FullPath(System.IO.Path.Combine("Maps", "Shapes"));
            System.IO.Directory.CreateDirectory(dir);
            System.IO.File.WriteAllText(System.IO.Path.Combine(dir, "plan_" + lb.ToString("X4") + ".txt"), sb.ToString());
        }

        // ── can you walk from one room into the next? ──
        private static readonly Dictionary<ulong, bool> _door = new Dictionary<ulong, bool>();
        [ThreadStatic] private static bool _anyLink;

        /// <summary>The game links rooms by every opening between them - including ones you can't walk through (the gap over
        /// a low wall looking down into the room below, a hallway passing over a bigger room). Walkable: somewhere along the
        /// first room's floor edge the next room's floor carries on, with no wall along it, for at least 0.8 m.</summary>
        private static bool Doorway(DCell a, DCell b)
        {
            ulong key = a.Id < b.Id ? ((ulong)a.Id << 32) | b.Id : ((ulong)b.Id << 32) | a.Id;
            bool r;
            if (_door.TryGetValue(key, out r)) return r;
            int known = ByOpening(a, b);
            r = known >= 0 ? known == 1 : (DoorwayCalc(a, b) || DoorwayCalc(b, a));
            if (_door.Count > 20000) _door.Clear();
            _door[key] = r;
            return r;
        }

        /// <summary>By the opening itself (the game's polygon between the two rooms): walkable when its bottom edge is at the
        /// floor on one side (a doorway, an arch, the top of a stair) - a window's starts at its sill, above both floors.
        /// 1 walkable, 0 not, -1 not known (no opening polygon read).</summary>
        private static int ByOpening(DCell a, DCell b)
        {
            double[] o = null;
            int k = a.Next.IndexOf(b.Id);
            if (k >= 0 && k < a.NextPoly.Count) o = CellShapes.OpeningCenter(a, a.NextPoly[k]);
            if (o == null) { k = b.Next.IndexOf(a.Id); if (k >= 0 && k < b.NextPoly.Count) o = CellShapes.OpeningCenter(b, b.NextPoly[k]); }
            if (o == null || o.Length < 4) return -1;
            double low = o[3];
            double fa = FloorNear(a, o[0], o[1], low), fb = FloorNear(b, o[0], o[1], low);
            // a flat opening between floors metres apart: the edge of a walkway over a room (a drop), not a way through
            if (o.Length > 4 && o[4] - o[3] < 0.5 && Math.Abs(a.Z - b.Z) > 1.5 && Math.Abs(fa - fb) > 1.5) return 0;
            // a wall standing along the opening (a walkway's railing - the opening goes right down to the floor, the low wall
            // is in front of it): not a way through
            if (o.Length > 8 && WallAlong(a, b, o[5], o[6], o[7], o[8])) return 0;
            return Math.Min(Math.Abs(low - fa), Math.Abs(low - fb)) <= 0.7 ? 1 : 0;
        }

        /// <summary>A wall line of either room lying along most of the opening's width (within 0.6 m of it).</summary>
        private static bool WallAlong(DCell a, DCell b, double x1, double y1, double x2, double y2)
        {
            double len = Math.Sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
            if (len < 0.8) return false;
            int n = Math.Max(2, (int)Math.Ceiling(len / 0.4)), covered = 0;
            List<float[]> walls = new List<float[]>();
            foreach (DCell c in new[] { a, b })
            {
                List<float[]> f = CellShapes.Floor(c);
                if (f != null) foreach (float[] pg in f) if (pg[0] == 2 && pg.Length >= 5) walls.Add(pg);
            }
            if (walls.Count == 0) return false;
            for (int k = 0; k <= n; k++)
            {
                double t = (double)k / n, x = x1 + (x2 - x1) * t, y = y1 + (y2 - y1) * t;
                foreach (float[] w in walls) if (SegDist(x, y, w[1], w[2], w[3], w[4]) < 0.6) { covered++; break; }
            }
            return covered > (n + 1) * 0.6;   // most of it walled: a gap you can walk through is wider than what's left
        }

        /// <summary>The floor height in a room near a spot (the floor polygon there, or nearest - closest to height z); the
        /// room's own height when its shape isn't read.</summary>
        private static double FloorNear(DCell c, double x, double y, double z)
        {
            List<float[]> f3 = CellShapes.Floor3(c);
            double best = c.Z, bd = double.MaxValue;
            if (f3 == null) return best;
            foreach (float[] pg in f3)
            {
                if (pg[0] != 0 && pg[0] != 1) continue;
                if (!InPoly3(pg, x, y, 1.5)) continue;
                double h = HeightIn(pg, x, y);
                if (Math.Abs(h - z) < bd) { bd = Math.Abs(h - z); best = h; }
            }
            return best;
        }

        private static bool DoorwayCalc(DCell a, DCell b)
        {
            List<float[]> fa = CellShapes.Floor(a), fb = CellShapes.Floor(b);
            List<float[]> ha = CellShapes.Floor3(a), hb = CellShapes.Floor3(b);
            if (fa == null || fb == null) return true;   // a shape not read: trust the game's link
            bool anyA = false, anyB = false;
            foreach (float[] pg in fa) if (pg[0] == 0) anyA = true;
            foreach (float[] pg in fb) if (pg[0] == 0) anyB = true;
            if (!anyA || !anyB) return true;
            if (Math.Abs(a.Z - b.Z) > 4.5) return false;   // a floor too far above / below to step to
            List<float[]> walls = new List<float[]>();
            foreach (float[] pg in fa) if (pg[0] == 2 && pg.Length >= 5) walls.Add(pg);
            foreach (float[] pg in fb) if (pg[0] == 2 && pg.Length >= 5) walls.Add(pg);
            int run = 0;
            if (ha == null || hb == null) return false;
            foreach (float[] pg in ha)
            {
                if (pg[0] != 0) continue;
                int nv = (pg.Length - 1) / 3;
                for (int i = 0; i < nv; i++)
                {
                    int j = (i + 1) % nv;
                    double x1 = pg[1 + 3 * i], y1 = pg[2 + 3 * i], z1 = pg[3 + 3 * i], x2 = pg[1 + 3 * j], y2 = pg[2 + 3 * j], z2 = pg[3 + 3 * j];
                    double len = Math.Sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
                    int n = Math.Max(1, (int)Math.Ceiling(len / 0.4));
                    run = 0;
                    for (int k = 0; k <= n; k++)
                    {
                        double f = (double)k / n, x = x1 + (x2 - x1) * f, y = y1 + (y2 - y1) * f, z = z1 + (z2 - z1) * f;
                        bool open = false;
                        // the next room's floor carries on here, at the same height (within a step) - not a floor a
                        // couple of metres below a window, or above a hallway
                        foreach (float[] q in hb) if (q[0] == 0 && InPoly3(q, x, y, 0.5) && Math.Abs(HeightIn(q, x, y) - z) < 0.8) { open = true; break; }
                        if (open)
                            foreach (float[] w in walls)
                                if (SegDist(x, y, w[1], w[2], w[3], w[4]) < 0.3) { open = false; break; }
                        run = open ? run + 1 : 0;
                        if (run >= 3) return true;   // 0.8 m of open edge
                    }
                }
            }
            return false;
        }

        /// <summary>InPoly for a polygon with heights ([flag, x, y, z, ...]).</summary>
        private static bool InPoly3(float[] pg, double x, double y, double m)
        {
            int nv = (pg.Length - 1) / 3;
            float[] flat = new float[1 + nv * 2];
            for (int i = 0; i < nv; i++) { flat[1 + 2 * i] = pg[1 + 3 * i]; flat[2 + 2 * i] = pg[2 + 3 * i]; }
            return InPoly(flat, x, y, m);
        }

        /// <summary>The height of a floor polygon ([flag, x, y, z, ...]) at x, y (its plane).</summary>
        private static double HeightIn(float[] pg, double x, double y)
        {
            int nv = (pg.Length - 1) / 3;
            double nx = 0, ny = 0, nz = 0, cx = 0, cy = 0, cz = 0;
            for (int i = 0; i < nv; i++)
            {
                int j = (i + 1) % nv;
                double x1 = pg[1 + 3 * i], y1 = pg[2 + 3 * i], z1 = pg[3 + 3 * i], x2 = pg[1 + 3 * j], y2 = pg[2 + 3 * j], z2 = pg[3 + 3 * j];
                nx += (y1 - y2) * (z1 + z2); ny += (z1 - z2) * (x1 + x2); nz += (x1 - x2) * (y1 + y2);
                cx += x1; cy += y1; cz += z1;
            }
            cx /= nv; cy /= nv; cz /= nv;
            if (Math.Abs(nz) < 1e-6) return cz;
            return cz - (nx * (x - cx) + ny * (y - cy)) / nz;
        }

        private static double SegDist(double x, double y, double x1, double y1, double x2, double y2)
        {
            double ex = x2 - x1, ey = y2 - y1, l2 = ex * ex + ey * ey;
            double t = l2 > 0 ? Math.Max(0, Math.Min(1, ((x - x1) * ex + (y - y1) * ey) / l2)) : 0;
            double dx = x1 + t * ex - x, dy = y1 + t * ey - y;
            return Math.Sqrt(dx * dx + dy * dy);
        }

        /// <summary>A point to the side of the line p-q (3 to 7 m either side of its middle) from which both p and q are in a
        /// clear line - or null.</summary>
        /// <summary>A way across one level (a hub's hall with portals all round its walls) on a 0.5 m grid: on the floor, 0.7 m
        /// off the walls, out of every portal's reach - then pulled straight where Sight allows. Null: none found.</summary>
        private static List<double[]> Detour(double[] p, double[] q, List<uint> cells, Dictionary<uint, DCell> d)
        {
            if (Math.Abs(q[2] - p[2]) > 1.5) return null;
            const double G = 0.5, Pad = 12, WallM = 0.7;
            double z = p[2];
            double x0 = Math.Min(p[0], q[0]) - Pad, y0 = Math.Min(p[1], q[1]) - Pad;
            int w = (int)Math.Ceiling((Math.Max(p[0], q[0]) + Pad - x0) / G) + 1, h = (int)Math.Ceiling((Math.Max(p[1], q[1]) + Pad - y0) / G) + 1;
            if (w * h > 40000) return null;
            // the rooms and walls at this height, round here
            List<DCell> near = new List<DCell>();
            List<double[]> walls = new List<double[]>();
            foreach (DCell c in d.Values)
            {
                if (Math.Abs(c.Z - z) > 2 || c.X < x0 - 12 || c.X > x0 + w * G + 12 || c.Y < y0 - 12 || c.Y > y0 + h * G + 12) continue;
                near.Add(c);
                List<float[]> fl = CellShapes.Floor(c);
                if (fl == null) continue;
                foreach (float[] pg in fl)
                    if (pg[0] == 2 && pg.Length >= 5) walls.Add(new double[] { pg[1], pg[2], pg[3], pg[4] });
            }
            if (near.Count == 0) return null;
            // portals: their reach, but one you start / end next to only as far in as you already are
            List<double[]> por = new List<double[]>();
            foreach (double[] o in _portals)
            {
                if (!double.IsNaN(o[2]) && Math.Abs(o[2] - z) > 3) continue;
                double r = PortalHardM, rs = PortalLineM + 1;
                double dp = Math.Sqrt((o[0] - p[0]) * (o[0] - p[0]) + (o[1] - p[1]) * (o[1] - p[1]));
                double dq = Math.Sqrt((o[0] - q[0]) * (o[0] - q[0]) + (o[1] - q[1]) * (o[1] - q[1]));
                r = Math.Min(r, Math.Min(dp, dq) - 0.3);
                rs = Math.Min(rs, Math.Min(dp, dq) - 0.3);
                if (rs > 0) por.Add(new[] { o[0], o[1], r, rs });
            }
            string ck = Math.Round(p[0], 1) + "," + Math.Round(p[1], 1) + "," + Math.Round(z) + ">" + Math.Round(q[0], 1) + "," + Math.Round(q[1], 1) + "/" + d.Count + "/" + _portals.Count + "/" + _keep.Count;
            List<double[]> cached;
            if (_detourCache.TryGetValue(ck, out cached)) return cached == null ? null : new List<double[]>(cached);
            List<double[]> res = DetourGrid(p, q, z, x0, y0, w, h, G, WallM, near, walls, por);
            if (_detourCache.Count > 64) _detourCache.Clear();
            _detourCache[ck] = res;
            return res == null ? null : new List<double[]>(res);
        }
        private static readonly Dictionary<string, List<double[]>> _detourCache = new Dictionary<string, List<double[]>>();

        private static List<double[]> DetourGrid(double[] p, double[] q, double z, double x0, double y0, int w, int h, double G, double WallM,
                                                 List<DCell> near, List<double[]> walls, List<double[]> por)
        {
            // (stamped shape by shape onto the grid - testing every grid point against every room and wall froze the game)
            bool[] ok = new bool[w * h];
            float[] cost = new float[w * h];   // 0 clear .. 1 at a portal's hard edge
            foreach (DCell c in near)
            {
                List<float[]> fl = CellShapes.Floor(c);
                bool any = false;
                if (fl != null)
                    foreach (float[] pg in fl)
                    {
                        if (pg[0] != 0) continue;
                        any = true;
                        int nv = (pg.Length - 1) / 2;
                        double ax = double.MaxValue, ay = double.MaxValue, bx = double.MinValue, by = double.MinValue;
                        for (int i = 0; i < nv; i++) { ax = Math.Min(ax, pg[1 + 2 * i]); bx = Math.Max(bx, pg[1 + 2 * i]); ay = Math.Min(ay, pg[2 + 2 * i]); by = Math.Max(by, pg[2 + 2 * i]); }
                        int gx0 = Math.Max(0, (int)Math.Floor((ax - x0) / G)), gx1 = Math.Min(w - 1, (int)Math.Ceiling((bx - x0) / G));
                        int gy0 = Math.Max(0, (int)Math.Floor((ay - y0) / G)), gy1 = Math.Min(h - 1, (int)Math.Ceiling((by - y0) / G));
                        for (int gy = gy0; gy <= gy1; gy++)
                            for (int gx = gx0; gx <= gx1; gx++)
                                if (!ok[gy * w + gx] && InPoly(pg, x0 + gx * G, y0 + gy * G, 0)) ok[gy * w + gx] = true;
                    }
                if (!any)
                {
                    int gx0 = Math.Max(0, (int)Math.Ceiling((c.X - 4.8 - x0) / G)), gx1 = Math.Min(w - 1, (int)Math.Floor((c.X + 4.8 - x0) / G));
                    int gy0 = Math.Max(0, (int)Math.Ceiling((c.Y - 4.8 - y0) / G)), gy1 = Math.Min(h - 1, (int)Math.Floor((c.Y + 4.8 - y0) / G));
                    for (int gy = gy0; gy <= gy1; gy++) for (int gx = gx0; gx <= gx1; gx++) ok[gy * w + gx] = true;
                }
            }
            foreach (double[] wl in walls)
            {
                int gx0 = Math.Max(0, (int)Math.Floor((Math.Min(wl[0], wl[2]) - WallM - x0) / G)), gx1 = Math.Min(w - 1, (int)Math.Ceiling((Math.Max(wl[0], wl[2]) + WallM - x0) / G));
                int gy0 = Math.Max(0, (int)Math.Floor((Math.Min(wl[1], wl[3]) - WallM - y0) / G)), gy1 = Math.Min(h - 1, (int)Math.Ceiling((Math.Max(wl[1], wl[3]) + WallM - y0) / G));
                for (int gy = gy0; gy <= gy1; gy++)
                    for (int gx = gx0; gx <= gx1; gx++)
                        if (ok[gy * w + gx] && SegDist(x0 + gx * G, y0 + gy * G, wl[0], wl[1], wl[2], wl[3]) < WallM) ok[gy * w + gx] = false;
            }
            foreach (double[] o in por)
            {
                double R = o[3];
                int gx0 = Math.Max(0, (int)Math.Floor((o[0] - R - x0) / G)), gx1 = Math.Min(w - 1, (int)Math.Ceiling((o[0] + R - x0) / G));
                int gy0 = Math.Max(0, (int)Math.Floor((o[1] - R - y0) / G)), gy1 = Math.Min(h - 1, (int)Math.Ceiling((o[1] + R - y0) / G));
                for (int gy = gy0; gy <= gy1; gy++)
                    for (int gx = gx0; gx <= gx1; gx++)
                    {
                        int v = gy * w + gx;
                        if (!ok[v]) continue;
                        double x = x0 + gx * G, y = y0 + gy * G, dd = Math.Sqrt((o[0] - x) * (o[0] - x) + (o[1] - y) * (o[1] - y));
                        if (dd < o[2]) { ok[v] = false; continue; }
                        if (dd < o[3]) cost[v] = Math.Max(cost[v], (float)((o[3] - dd) / Math.Max(0.1, o[3] - Math.Max(0, o[2]))));
                    }
            }
            if (_keep.Count > 0)
                for (int v = 0; v < ok.Length; v++)
                    if (ok[v] && NearKeep(x0 + (v % w) * G, y0 + (v / w) * G, z, KeepLineM)) ok[v] = false;
            int sx = (int)Math.Round((p[0] - x0) / G), sy = (int)Math.Round((p[1] - y0) / G);
            int tx = (int)Math.Round((q[0] - x0) / G), ty = (int)Math.Round((q[1] - y0) / G);
            int s = NearOk(ok, w, h, sx, sy), t = NearOk(ok, w, h, tx, ty);
            if (s < 0 || t < 0) return null;
            // A*
            float[] g = new float[w * h]; int[] from = new int[w * h];
            for (int i = 0; i < g.Length; i++) { g[i] = float.MaxValue; from[i] = -1; }
            Heap open = new Heap(); g[s] = 0; open.Push(s, 0);
            bool[] closed = new bool[w * h];
            int ttx = t % w, tty = t / w;
            while (open.Count > 0)
            {
                int u = open.Pop();
                if (closed[u]) continue;
                closed[u] = true;
                if (u == t) break;
                int ux = u % w, uy = u / w;
                for (int ddx = -1; ddx <= 1; ddx++)
                    for (int ddy = -1; ddy <= 1; ddy++)
                    {
                        if (ddx == 0 && ddy == 0) continue;
                        int vx = ux + ddx, vy = uy + ddy;
                        if (vx < 0 || vy < 0 || vx >= w || vy >= h) continue;
                        int v = vy * w + vx;
                        if (!ok[v] || closed[v]) continue;
                        if (ddx != 0 && ddy != 0 && (!ok[uy * w + vx] || !ok[vy * w + ux])) continue;
                        float nd = g[u] + (ddx != 0 && ddy != 0 ? 1.414f : 1f) * (1 + 8 * cost[v]);
                        if (nd < g[v])
                        {
                            g[v] = nd; from[v] = u;
                            float hh = (float)Math.Sqrt((vx - ttx) * (vx - ttx) + (vy - tty) * (vy - tty));
                            open.Push(v, nd + hh);
                        }
                    }
            }
            if (from[t] < 0 && t != s) return null;
            List<double[]> raw = new List<double[]>();
            for (int v = t; v != s; v = from[v]) raw.Add(new[] { x0 + (v % w) * G, y0 + (v / w) * G, z, q[3] });
            raw.Reverse();
            // pulled straight: from each point, the furthest one along still in a clear line on the grid
            List<double[]> outp = new List<double[]>();
            double[] at = p;
            int k = 0;
            while (k < raw.Count)
            {
                int far = k;
                // (a straight cut no nearer the portals than the way it replaces)
                float mc = 0;
                for (int j = k; j < raw.Count; j++) mc = Math.Max(mc, CostAt(cost, w, h, x0, y0, G, raw[j]));
                for (int j = raw.Count - 1; j > k; j--)
                {
                    float mj = 0; for (int i = k; i <= j; i++) mj = Math.Max(mj, CostAt(cost, w, h, x0, y0, G, raw[i]));
                    if (GridLine(ok, cost, mj + 0.05f, w, h, x0, y0, G, at, raw[j])) { far = j; break; }
                }
                if (far == raw.Count - 1 && GridLine(ok, cost, mc + 0.05f, w, h, x0, y0, G, at, q)) break;
                outp.Add(raw[far]);
                at = raw[far];
                k = far + 1;
            }
            return outp;
        }

        private static bool OnFloorIn(DCell c, double x, double y)
        {
            List<float[]> fl = CellShapes.Floor(c);
            bool any = false;
            if (fl != null)
                foreach (float[] pg in fl)
                {
                    if (pg[0] != 0) continue;
                    any = true;
                    if (InPoly(pg, x, y, 0)) return true;
                }
            if (any) return false;
            return Math.Abs(x - c.X) <= 4.8 && Math.Abs(y - c.Y) <= 4.8;
        }

        private static int NearOk(bool[] ok, int w, int h, int x, int y)
        {
            for (int r = 0; r <= 8; r++)
            {
                int best = -1; double bd = double.MaxValue;
                for (int dx = -r; dx <= r; dx++)
                    for (int dy = -r; dy <= r; dy++)
                    {
                        if (Math.Max(Math.Abs(dx), Math.Abs(dy)) != r) continue;
                        int vx = x + dx, vy = y + dy;
                        if (vx < 0 || vy < 0 || vx >= w || vy >= h || !ok[vy * w + vx]) continue;
                        double dd = dx * dx + dy * dy;
                        if (dd < bd) { bd = dd; best = vy * w + vx; }
                    }
                if (best >= 0) return best;
            }
            return -1;
        }

        private static float CostAt(float[] cost, int w, int h, double x0, double y0, double G, double[] a)
        {
            int gx = (int)Math.Round((a[0] - x0) / G), gy = (int)Math.Round((a[1] - y0) / G);
            return gx < 0 || gy < 0 || gx >= w || gy >= h ? 0 : cost[gy * w + gx];
        }

        private static bool GridLine(bool[] ok, float[] cost, float maxc, int w, int h, double x0, double y0, double G, double[] a, double[] b)
        {
            double len = Math.Sqrt((b[0] - a[0]) * (b[0] - a[0]) + (b[1] - a[1]) * (b[1] - a[1]));
            int n = Math.Max(1, (int)Math.Ceiling(len / (G / 2)));
            int first = -1;
            for (int i = 0; i <= n; i++)
            {
                double f = (double)i / n;
                int gx = (int)Math.Round((a[0] + (b[0] - a[0]) * f - x0) / G), gy = (int)Math.Round((a[1] + (b[1] - a[1]) * f - y0) / G);
                if (gx < 0 || gy < 0 || gx >= w || gy >= h) return false;
                int c = gy * w + gx;
                if (i == 0) first = c;
                if (c != first && (!ok[c] || cost[c] > maxc)) return false;   // (where you stand may be in a portal's edge / by a wall)
            }
            return true;
        }

        private static double[] SideStep(double[] p, double[] q, List<uint> cells, Dictionary<uint, DCell> d)
        {
            double dx = q[0] - p[0], dy = q[1] - p[1], len = Math.Sqrt(dx * dx + dy * dy);
            if (len < 1 || Math.Abs(q[2] - p[2]) > 1.5) return null;
            double nx = -dy / len, ny = dx / len;
            foreach (double frac in new[] { 0.5, 0.35, 0.65 })
                foreach (double off in new[] { 3.0, -3.0, 5.0, -5.0, 7.0, -7.0 })
                {
                    double[] m = { p[0] + dx * frac + nx * off, p[1] + dy * frac + ny * off, (p[2] + q[2]) / 2, q[3] };
                    if (Sight(p, m, cells, d) && Sight(m, q, cells, d)) return m;
                }
            return null;
        }

        /// <summary>Moves (x, y) onto the room's floor at height z (the polygon there at about that height), 0.5 m in from its
        /// edge, when it isn't on it already.</summary>
        private static void SnapToFloor(DCell c, ref double x, ref double y, double z)
        {
            List<float[]> f3 = CellShapes.Floor3(c);
            if (f3 == null) return;
            double bx = x, by = y, bd = double.MaxValue;
            foreach (float[] pg in f3)
            {
                if (pg[0] != 0 && pg[0] != 1) continue;
                if (InPoly3(pg, x, y, 0) && Math.Abs(HeightIn(pg, x, y) - z) < 1.2) return;   // on it already
            }
            foreach (float[] pg in f3)
            {
                if (pg[0] != 0 && pg[0] != 1) continue;
                int nv = (pg.Length - 1) / 3;
                double cx = 0, cy = 0; for (int i = 0; i < nv; i++) { cx += pg[1 + 3 * i]; cy += pg[2 + 3 * i]; } cx /= nv; cy /= nv;
                if (Math.Abs(HeightIn(pg, cx, cy) - z) > 1.2) continue;   // another level's floor
                for (int i = 0; i < nv; i++)
                {
                    int j = (i + 1) % nv;
                    double x1 = pg[1 + 3 * i], y1 = pg[2 + 3 * i], x2 = pg[1 + 3 * j], y2 = pg[2 + 3 * j];
                    double ex = x2 - x1, ey = y2 - y1, l2 = ex * ex + ey * ey;
                    double t = l2 > 0 ? Math.Max(0, Math.Min(1, ((x - x1) * ex + (y - y1) * ey) / l2)) : 0;
                    double px = x1 + t * ex, py = y1 + t * ey, dd = (px - x) * (px - x) + (py - y) * (py - y);
                    if (dd < bd)
                    {
                        double ix = cx - px, iy = cy - py, il = Math.Sqrt(ix * ix + iy * iy);
                        double step = Math.Min(0.5, il / 2);
                        bd = dd; bx = il > 0 ? px + ix / il * step : px; by = il > 0 ? py + iy / il * step : py;
                    }
                }
            }
            if (bd < 64) { x = bx; y = by; }   // (not further than 8 m)
        }

        /// <summary>On one of the room's floor shapes (a room without its shape read: the 9.6 m square round its middle).</summary>
        private static bool OnFloor(DCell c, double x, double y)
        {
            List<float[]> fl = CellShapes.Floor(c);
            bool any = false;
            if (fl != null)
                foreach (float[] pg in fl)
                {
                    if (pg[0] != 0) continue;
                    any = true;
                    if (InPoly(pg, x, y, 0.4)) return true;
                }
            if (any) return false;
            return Math.Abs(x - c.X) <= 4.8 && Math.Abs(y - c.Y) <= 4.8;
        }

        /// <summary>Inside a floor polygon ([flag, x, y, ...]), or within m of its edge.</summary>
        private static bool InPoly(float[] pg, double x, double y, double m)
        {
            int nv = (pg.Length - 1) / 2;
            bool inside = false;
            for (int i = 0, j = nv - 1; i < nv; j = i++)
            {
                double xi = pg[1 + 2 * i], yi = pg[2 + 2 * i], xj = pg[1 + 2 * j], yj = pg[2 + 2 * j];
                if (((yi > y) != (yj > y)) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) inside = !inside;
            }
            if (inside) return true;
            for (int i = 0, j = nv - 1; i < nv; j = i++)
            {
                double xi = pg[1 + 2 * i], yi = pg[2 + 2 * i], xj = pg[1 + 2 * j], yj = pg[2 + 2 * j];
                double ex = xj - xi, ey = yj - yi, l2 = ex * ex + ey * ey;
                double t = l2 > 0 ? Math.Max(0, Math.Min(1, ((x - xi) * ex + (y - yi) * ey) / l2)) : 0;
                double dx = xi + t * ex - x, dy = yi + t * ey - y;
                if (dx * dx + dy * dy <= m * m) return true;
            }
            return false;
        }

        /// <summary>Do segments a-b and c-d cross (not just touch at an end)?</summary>
        private static bool Crosses(double ax, double ay, double bx, double by, double cx, double cy, double dx, double dy)
        {
            double d1 = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax), d2 = (bx - ax) * (dy - ay) - (by - ay) * (dx - ax);
            double d3 = (dx - cx) * (ay - cy) - (dy - cy) * (ax - cx), d4 = (dx - cx) * (by - cy) - (dy - cy) * (bx - cx);
            return ((d1 > 1e-6 && d2 < -1e-6) || (d1 < -1e-6 && d2 > 1e-6)) && ((d3 > 1e-6 && d4 < -1e-6) || (d3 < -1e-6 && d4 > 1e-6));
        }

        public static List<Pt> Indoors(Coords a, int area, uint cellA, Coords b, uint cellB)
        {
            int lb = cellA != 0 ? (int)(cellA >> 16) : area;
            Dictionary<uint, DCell> d = WorldMap.Dungeon(lb);
            if (d == null)
            {
                // the area may be a landblock next door (the list's coordinates)
                for (int dx = -1; dx <= 1 && d == null; dx++)
                    for (int dy = -1; dy <= 1 && d == null; dy++)
                    {
                        int l2 = ((((lb >> 8) + dx) & 0xFF) << 8) | (((lb & 0xFF) + dy) & 0xFF);
                        d = WorldMap.Dungeon(l2);
                        if (d != null) lb = l2;
                    }
            }
            if (d == null || d.Count == 0) { Last = "no cells for dungeon " + lb.ToString("X4"); return null; }
            uint s = cellA != 0 && d.ContainsKey(cellA) ? cellA : NearestCell(d, a);
            uint t = cellB != 0 && d.ContainsKey(cellB) ? cellB : NearestCell(d, b);
            if (s == 0 || t == 0) return null;
            {
                // the portals in here, other than the one you're going to: kept away from (walking over one takes it)
                int bx = (int)(s >> 24), by = (int)((s >> 16) & 0xFF);
                double tx = (b.EW + 101.95) * 240.0 - bx * 192.0, ty = (b.NS + 101.95) * 240.0 - by * 192.0;
                List<double[]> pl = new List<double[]>();
                // this version of the dungeon (a landblock reused as another dungeon has other portals at other spots): the
                // portals on its own map, when it has them - not the other version's
                string dinP = Travel.DungeonIn(lb);
                string instP = dinP.Length > 6 ? dinP.Substring(6) : "";
                bool ownMap = false;
                foreach (TravelData.Point pp in TravelData.Points.Values)
                {
                    if (pp.In != dinP || !TravelData.IsPortalType(pp.Type) || !pp.At.Valid) continue;
                    ownMap = true;
                    double px = (pp.At.EW + 101.95) * 240.0 - bx * 192.0, py = (pp.At.NS + 101.95) * 240.0 - by * 192.0;
                    if ((px - tx) * (px - tx) + (py - ty) * (py - ty) < 2.5 * 2.5) continue;   // the one you're going to
                    pl.Add(new[] { px, py, pp.Z });
                }
                foreach (Loc pv in TravelData.Locs)
                {
                    if (!(pv.HasExit || TravelData.IsPortalType(pv.Type)) || !pv.At.Valid || pv.Area < 0 || !TravelData.SameArea(pv.Area, lb)) continue;
                    string li = pv.In ?? "";
                    if (ownMap ? li != instP : (instP.Length > 0 ? li.Length > 0 && li != instP : li.StartsWith("v"))) continue;
                    double px = (pv.At.EW + 101.95) * 240.0 - bx * 192.0, py = (pv.At.NS + 101.95) * 240.0 - by * 192.0;
                    if ((px - tx) * (px - tx) + (py - ty) * (py - ty) < 2.5 * 2.5) continue;   // the one you're going to
                    DCell pc;
                    double pz = pv.Cell != 0 && d.TryGetValue(pv.Cell, out pc) ? pc.Z : double.NaN;
                    pl.Add(new[] { px, py, pz });
                }
                // a portal bot's spot: the portals it opens come and go there (not when it's the one you're going to)
                foreach (PortalBot pb in PortalBots.All.Values)
                {
                    if (!pb.At.Valid || pb.Area < 0 || !TravelData.SameArea(pb.Area, lb)) continue;
                    double px = (pb.At.EW + 101.95) * 240.0 - bx * 192.0, py = (pb.At.NS + 101.95) * 240.0 - by * 192.0;
                    if ((px - tx) * (px - tx) + (py - ty) * (py - ty) < 4 * 4) continue;
                    pl.Add(new[] { px, py, pb.Z });
                }
                _portals = pl;
                List<double[]> kl = new List<double[]>();
                string din = Travel.DungeonIn(lb);
                foreach (TravelData.Point kp in TravelData.Points.Values)
                {
                    if (kp.In != din || kp.Type != "Keep out" || !kp.At.Valid) continue;
                    kl.Add(new[] { (kp.At.EW + 101.95) * 240.0 - bx * 192.0, (kp.At.NS + 101.95) * 240.0 - by * 192.0, kp.Z });
                }
                _keep = kl;
            }
            // Dijkstra over the cells (a few hundred), nearest first
            Dictionary<uint, double> dist = new Dictionary<uint, double>();
            Dictionary<uint, uint> prev = new Dictionary<uint, uint>();
            HashSet<uint> done = new HashSet<uint>();
            Heap open = new Heap();
            dist[s] = 0;
            open.Push((int)(s & 0xFFFF), 0);
            uint hi = s & 0xFFFF0000;
            int guard = 0;
            while (open.Count > 0 && ++guard < 200000)
            {
                uint u = hi | (uint)open.Pop();
                if (!done.Add(u)) continue;
                if (u == t) break;
                DCell cu;
                if (!d.TryGetValue(u, out cu)) continue;
                double best = dist[u];
                foreach (uint v in cu.Next)
                {
                    DCell cv;
                    if ((v & 0xFFFF0000) != hi || !d.TryGetValue(v, out cv) || done.Contains(v)) continue;
                    double dx = cv.X - cu.X, dy = cv.Y - cu.Y, dz = cv.Z - cu.Z;
                    double nd = best + Math.Sqrt(dx * dx + dy * dy + dz * dz);
                    // linked, but it looks like no way across (a drop off a walkway, over a low wall): only if there's no
                    // other way - some of these are the ramps the shapes don't show, and the only way on
                    // (well above what the rooms-with-portals / something-in-the-way costs below can add up to over a
                    // whole hub's hall: 200 had a jump off a walkway cheaper than walking round past the portals)
                    if (!_anyLink && !Doorway(cu, cv)) nd += 5000;
                    if (v != t && NearKeep(cv.X, cv.Y, cv.Z, KeepCellM)) continue;   // marked keep out
                    if (v != t && NearPortal(cv.X, cv.Y, cv.Z, 4.5)) nd += 60;   // a room with a portal in it: round it if there's another way
                    // something standing in the middle of the room (the bar in the middle of each of the Town Network's halls,
                    // shelves, tables): its size isn't known, only where it stands - round it through the rooms beside it
                    if (v != t && ClearanceAt(cv, cv.X, cv.Y) < 3.0) nd += 25;
                    double old;
                    if (!dist.TryGetValue(v, out old) || nd < old) { dist[v] = nd; prev[v] = u; open.Push((int)(v & 0xFFFF), (float)nd); }
                }
            }
            if ((!dist.ContainsKey(t) || !done.Contains(t)) && !_anyLink)
            {
                // nothing that way by the floors' edges: the game's own links (a doorway the shapes didn't show)
                _anyLink = true;
                try { List<Pt> again = Indoors(a, area, cellA, b, cellB); if (again != null) Last += " (by the game's room links)"; return again; }
                finally { _anyLink = false; }
            }
            if (!dist.ContainsKey(t)) { Last = "no way through the dungeon's cells"; return null; }
            if (!done.Contains(t)) { Last = "no way through the dungeon's cells"; return null; }
            List<uint> path = new List<uint>();
            for (uint v = t; v != s; v = prev[v]) { path.Add(v); if (path.Count > d.Count + 2) { Last = "the dungeon's cells go round in a circle"; return null; } }
            path.Reverse();
            // points to walk through, in the landblock's own metres: you, a clear spot in each room on the way, the target
            int lbx = (int)(s >> 24), lby = (int)((s >> 16) & 0xFF);
            List<uint> cells = new List<uint> { s };
            cells.AddRange(path);
            List<double[]> pts = new List<double[]>();
            pts.Add(new[] { (a.EW + 101.95) * 240.0 - lbx * 192.0, (a.NS + 101.95) * 240.0 - lby * 192.0, d[s].Z, s });
            uint prevId = s;
            foreach (uint id in path)
            {
                // into a room at another height (down from a walkway, up a stair): through the opening between them - the
                // room's middle can be right under / over the one you're in (straight there is through a railing)
                // every step from room to room goes through the doorway between them (the game's opening) - a room's middle can
                // be behind you, or by a portal (the entrance you came in by)
                DCell pc0 = d[prevId], c0 = d[id];
                {
                    double[] o = null;
                    int k = pc0.Next.IndexOf(id);
                    if (k >= 0 && k < pc0.NextPoly.Count) o = CellShapes.OpeningCenter(pc0, pc0.NextPoly[k]);
                    if (o == null) { k = c0.Next.IndexOf(prevId); if (k >= 0 && k < c0.NextPoly.Count) o = CellShapes.OpeningCenter(c0, c0.NextPoly[k]); }
                    if (o != null && !Doorway(pc0, c0)) o = null;
                    // only a doorway steers you: a wide opening (one big hall split into two of the game's rooms) doesn't
                    if (o != null && o.Length > 8 && Math.Sqrt((o[7] - o[5]) * (o[7] - o[5]) + (o[8] - o[6]) * (o[8] - o[6])) > 4.5) o = null;
                    if (o != null)
                    {
                        double low = o.Length > 3 ? o[3] : o[2];
                        double fz = Math.Abs(FloorNear(pc0, o[0], o[1], low) - low) < Math.Abs(FloorNear(c0, o[0], o[1], low) - low) ? FloorNear(pc0, o[0], o[1], low) : FloorNear(c0, o[0], o[1], low);
                        if (!NearPortal(o[0], o[1], fz, PortalPointM)) pts.Add(new[] { o[0], o[1], fz, id });
                    }
                }
                prevId = id;
                if (id == t) break;
                DCell c = d[id];
                double[] spot = ClearSpot(c);
                if (NearPortal(spot[0], spot[1], c.Z, PortalLineM))
                {
                    // the room's clear spot is by a portal: the side of the room away from it
                    double bestD = -1; double[] alt = spot;
                    for (int ox = -1; ox <= 1; ox++)
                        for (int oy = -1; oy <= 1; oy++)
                        {
                            double x = c.X + ox * 3.2, y = c.Y + oy * 3.2;
                            if (ClearanceAt(c, x, y) < Clearance) continue;
                            double m = double.MaxValue;
                            foreach (double[] q in _portals) { if (!double.IsNaN(q[2]) && Math.Abs(q[2] - c.Z) > 3) continue; m = Math.Min(m, (q[0] - x) * (q[0] - x) + (q[1] - y) * (q[1] - y)); }
                            if (m > bestD) { bestD = m; alt = new[] { x, y }; }
                        }
                    spot = alt;
                }
                pts.Add(new[] { spot[0], spot[1], c.Z, id });
            }
            pts.Add(new[] { (b.EW + 101.95) * 240.0 - lbx * 192.0, (b.NS + 101.95) * 240.0 - lby * 192.0, d[t].Z, t });
            // every point on its room's real floor at its height (a narrow walkway over a bigger room: a room's middle or an
            // opening's middle can be off the walkway, over the drop)
            for (int i = 1; i < pts.Count - 1; i++)
            {
                DCell pc; if (!d.TryGetValue((uint)pts[i][3], out pc)) continue;
                double[] q = pts[i];
                SnapToFloor(pc, ref q[0], ref q[1], q[2]);
            }
            // fewer points: straight on past a point when the line to a later one stays inside the rooms on the way and clear
            // of the things in them (a point right on a fountain or a tree had you running past it and back)
            List<double[]> keep = new List<double[]>();
            int at = 0;
            while (at < pts.Count - 1)
            {
                int far = at + 1;
                for (int j = pts.Count - 1; j > at + 1; j--)
                    if (Sight(pts[at], pts[j], cells, d)) { far = j; break; }
                // the furthest point along still on this level: when it isn't in a clear line, a way there on the floor
                // itself (round the portals, off the walls) - the rooms' middles in a hub's hall can be against a wall,
                // right by a portal
                int jmax = at;
                while (jmax + 1 < pts.Count && Math.Abs(pts[jmax + 1][2] - pts[at][2]) < 1.5) jmax++;
                bool blocked = far == at + 1 && !Sight(pts[at], pts[far], cells, d);
                if (jmax > far || (blocked && jmax > at))
                {
                    List<double[]> det = null; int dj = -1, tries = 0;
                    for (int j = jmax; j > at && det == null && tries++ < 4; j--)
                    {
                        if (j <= far && !blocked) break;   // a clear line already reaches this far
                        try { det = Detour(pts[at], pts[j], cells, d); } catch { det = null; }
                        if (det != null) dj = j;
                    }
                    if (det != null)
                    {
                        keep.AddRange(det);
                        keep.Add(pts[dj]);
                        at = dj;
                        continue;
                    }
                }
                if (blocked)
                {
                    // the next point isn't in a clear line (a portal standing in the way, across a hub's hall): a point to one
                    // side, where both halves are clear
                    double[] side = SideStep(pts[at], pts[far], cells, d);
                    if (side != null) keep.Add(side);
                }
                keep.Add(pts[far]);
                at = far;
            }
            // a spur: out to a point and nearly straight back (a room's spot moved away from a portal, a side step) - straight
            // past it when that's clear, or round on the floor
            {
                List<double[]> full = new List<double[]> { pts[0] };
                full.AddRange(keep);
                int spurs = 0;
                for (int i = 1; i + 1 < full.Count && spurs < 20; i++)
                {
                    double[] A = full[i - 1], B = full[i], C = full[i + 1];
                    if (Math.Abs(A[2] - B[2]) > 1.5 || Math.Abs(C[2] - B[2]) > 1.5) continue;
                    double ax = B[0] - A[0], ay = B[1] - A[1], cx = C[0] - B[0], cy = C[1] - B[1];
                    double la = Math.Sqrt(ax * ax + ay * ay), lc = Math.Sqrt(cx * cx + cy * cy);
                    if (la < 0.5 || lc < 0.5) continue;
                    double turn = Math.Acos(Math.Max(-1, Math.Min(1, (ax * cx + ay * cy) / (la * lc)))) * 180 / Math.PI;
                    if (turn < 120) continue;
                    List<double[]> via = null;
                    if (Sight(A, C, cells, d)) via = new List<double[]>();
                    else { try { via = Detour(A, C, cells, d); } catch { via = null; } }
                    if (via == null) continue;
                    full.RemoveAt(i);
                    full.InsertRange(i, via);
                    spurs++;
                    i = Math.Max(0, i - 2);
                }
                full.RemoveAt(0);
                keep = full;
            }
            // a first point a step or two from where you stand (the middle of the little room you're in, behind you): not
            // worth turning round for - straight on to the next
            if (keep.Count > 1)
            {
                double dx = keep[0][0] - pts[0][0], dy = keep[0][1] - pts[0][1];
                if (dx * dx + dy * dy < 9 && Math.Abs(keep[0][2] - pts[0][2]) < 1.5) keep.RemoveAt(0);
            }
            try { DumpPlan(lb, s, t, path, d, a, b, pts, keep); } catch { }
            List<Pt> l = new List<Pt>();
            foreach (double[] p in keep)
            {
                Coords cc = WorldMap.CellCoords(s, p[0], p[1]);
                l.Add(new Pt(cc.NS, cc.EW, p[2], (uint)p[3]));
            }
            Last = "through " + path.Count + " cells, " + l.Count + " points";
            return l;
        }
    }
}
