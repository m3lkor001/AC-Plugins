using System;
using System.Globalization;
using System.Text.RegularExpressions;

namespace MelksQuestTracker.Travel
{
    /// <summary>Map coordinates: NS (north +, south -) and EW (east +, west -), in the game's map units.</summary>
    internal struct Coords
    {
        public double NS, EW;
        public static readonly Coords None = new Coords(double.NaN, double.NaN);

        public Coords(double ns, double ew) { NS = ns; EW = ew; }

        public bool Valid { get { return !double.IsNaN(NS) && !double.IsNaN(EW); } }

        public double DistanceTo(Coords o)
        {
            double a = NS - o.NS, b = EW - o.EW;
            return Math.Sqrt(a * a + b * b);
        }

        /// <summary>Compass bearing to the other point: 0 = north, 90 = east.</summary>
        public double BearingTo(Coords o)
        {
            double deg = Math.Atan2(o.EW - EW, o.NS - NS) * 180.0 / Math.PI;
            return deg < 0 ? deg + 360 : deg;
        }

        public override string ToString()
        {
            if (!Valid) return "-";
            return Math.Abs(NS).ToString("0.0", CultureInfo.InvariantCulture) + (NS < 0 ? "S" : "N") + ", " +
                   Math.Abs(EW).ToString("0.0", CultureInfo.InvariantCulture) + (EW < 0 ? "W" : "E");
        }

        /// <summary>For the data file: "-33.12345,56.8".</summary>
        public string Raw()
        {
            return NS.ToString("0.#####", CultureInfo.InvariantCulture) + "," + EW.ToString("0.#####", CultureInfo.InvariantCulture);
        }

        public static Coords FromRaw(string s)
        {
            if (string.IsNullOrEmpty(s)) return None;
            string[] p = s.Split(',');
            double a, b;
            if (p.Length == 2 && double.TryParse(p[0], NumberStyles.Float, CultureInfo.InvariantCulture, out a) &&
                double.TryParse(p[1], NumberStyles.Float, CultureInfo.InvariantCulture, out b)) return new Coords(a, b);
            return None;
        }

        // 33.6N, 56.8E / 33.6n 56.8e / 0.3N/92.2W / 21.7S - 47.7E
        public static readonly Regex Rx = new Regex(@"(?<!\w)(?<ns>\d{1,3}(?:\.\d+)?)\s*(?<n>[NSns])\s*[,/\-]?\s*(?<ew>\d{1,3}(?:\.\d+)?)\s*(?<e>[EWew])(?!\w)");

        public static bool TryParse(string s, out Coords c)
        {
            c = None;
            if (string.IsNullOrEmpty(s)) return false;
            Match m = Rx.Match(s);
            if (!m.Success) return false;
            return FromMatch(m, out c);
        }

        public static bool FromMatch(Match m, out Coords c)
        {
            c = None;
            double ns, ew;
            if (!double.TryParse(m.Groups["ns"].Value, NumberStyles.Float, CultureInfo.InvariantCulture, out ns)) return false;
            if (!double.TryParse(m.Groups["ew"].Value, NumberStyles.Float, CultureInfo.InvariantCulture, out ew)) return false;
            if (ns > 102 || ew > 102) return false;
            if (char.ToUpperInvariant(m.Groups["n"].Value[0]) == 'S') ns = -ns;
            if (char.ToUpperInvariant(m.Groups["e"].Value[0]) == 'W') ew = -ew;
            c = new Coords(ns, ew);
            return true;
        }
    }
}
