using System;
using System.Collections.Generic;

namespace MelksQuestTracker.Travel
{
    /// <summary>One step of a route.</summary>
    internal class Leg
    {
        public string Kind = "";        // run (to the destination), portal (run to it, go through), spell, gem, cmd
        public string Name = "";        // portal / spell / gem name, the command, or the destination's name
        public Coords Target = Coords.None;   // where to go (the portal, the destination) - the arrow points here
        public int TargetArea = -1;
        public Coords Exit = Coords.None;     // where it should put you (portals, spells, gems, commands)
        public int ExitArea = -1;
        public double Run;              // map units to run first
        public double Secs;             // this step's time, running included
        public string PortalKey = "";   // for "don't use this portal"
        public StartOpt Opt;            // spell / gem / command steps
        public string Bot = "", Say = "";   // a portal bot's portal: tell Bot Say first, then go through what it opens
    }

    internal class Route
    {
        public readonly List<Leg> Legs = new List<Leg>();
        public double Secs;
        public string Dest = "";
        public Coords DestAt = Coords.None;
        public int DestArea = -1;
    }

    /// <summary>
    /// The fastest way from here to there (Dijkstra): run (outdoors, or inside the same hub / dungeon), go through portals,
    /// or start with a recall spell, a portal gem or a command (/ls). Times are rough seconds - only how they compare matters.
    /// </summary>
    internal static class Router
    {
        public static double RunSecsPerUnit = 15;   // one map unit (240 m) at a good run speed
        public static double MaxRunOutdoors = 30;   // longer runs than this aren't considered
        public static double PortalSecs = 8;        // portal space and loading
        public static double SpellSecs = 12, GemSecs = 9, CmdSecs = 14;

        public static double OptSecs(StartOpt o)
        {
            double s = o.Kind == "gem" ? GemSecs : o.Kind == "cmd" ? CmdSecs : SpellSecs;
            if (o.OpensPortal) s += 12;   // waiting for the portal, going through it - a sending gem does the same quicker
            if (o.Kind == "cmd" && (o.Name == "/ls" || o.Name == "/lifestone")) s += 10;   // the long lifestone animation
            return s;
        }

        public static Route Find(Coords from, int fromArea, Coords to, int toArea, string toName, List<StartOpt> opts, int level)
        {
            List<Loc> portals = new List<Loc>();
            foreach (Loc l in TravelData.Locs)
            {
                if (!l.HasExit) continue;
                if (TravelData.Avoid.Contains(l.Key) || TravelData.Random.Contains(l.Key)) continue;
                if (TravelData.Moves(l.Name) && !TravelData.MovesFresh(l)) continue;   // moves around: only just after it was seen there
                if (level > 0 && ((l.MinLevel > 0 && level < l.MinLevel) || (l.MaxLevel > 0 && level > l.MaxLevel))) continue;
                if (l.At.DistanceTo(l.Exit) < 0.01 && TravelData.SameArea(l.Area, l.ExitArea)) continue;   // goes nowhere
                portals.Add(l);
            }
            foreach (Loc l in PortalBots.RouteLocs())
                if (!TravelData.Avoid.Contains(l.Key) && !(l.At.DistanceTo(l.Exit) < 0.01 && TravelData.SameArea(l.Area, l.ExitArea))) portals.Add(l);
            int np = portals.Count, no = opts == null ? 0 : opts.Count;
            // nodes: 0 start, 1 destination, 2.. portal entrances, then portal exits, then where each start option lands
            int entr0 = 2, exit0 = 2 + np, opt0 = 2 + 2 * np, n = 2 + 2 * np + no;
            Coords[] at = new Coords[n];
            int[] area = new int[n];
            at[0] = from; area[0] = fromArea;
            at[1] = to; area[1] = toArea;
            for (int i = 0; i < np; i++)
            {
                at[entr0 + i] = portals[i].At; area[entr0 + i] = portals[i].Area;
                at[exit0 + i] = portals[i].Exit; area[exit0 + i] = portals[i].ExitArea;
            }
            for (int k = 0; k < no; k++) { at[opt0 + k] = opts[k].Exit; area[opt0 + k] = opts[k].ExitArea; }

            int[] region = new int[n];   // area on foot (outdoors): runs only between places in the same one
            for (int i = 0; i < n; i++)
            {
                region[i] = area[i] < 0 ? WorldMap.Region(at[i]) : 0;
                // a small one (a town or fort up on a rise, whose way in is a gatehouse's or bridge's floor, not the ground):
                // not known to be sealed off - the ground alone had Candeth Keep cut off from everything round it
                if (region[i] != 0 && WorldMap.RegionSize(region[i]) < 400) region[i] = 0;
            }
            _region = region;
            // walled-in areas (marked on the Travel tab): runs only within the same one, or between two places in none
            int[] wall = new int[n];
            List<TravelData.Wall> walls = new List<TravelData.Wall>(TravelData.Walls.Values);
            for (int i = 0; i < n; i++)
            {
                wall[i] = -1;
                if (area[i] >= 0 || !at[i].Valid) continue;
                for (int k = 0; k < walls.Count; k++) if (walls[k].At.DistanceTo(at[i]) <= walls[k].R) { wall[i] = k; break; }
            }
            _wall = wall;
            // which map each place is on: the world (""), or a tier copy ("tier11+") - runs only between places on the same one
            string[] grp = new string[n];
            for (int i = 0; i < n; i++) grp[i] = "";
            grp[0] = fromArea < 0 ? Travel.HereGroup : (Travel.HereInstance.StartsWith("v") ? Travel.HereInstance : "");   // in a dungeon's version: only its own portals
            grp[1] = toArea < 0 ? Travel.DestGroup : ((Travel.DestGroup ?? "").StartsWith("v") ? Travel.DestGroup : "");   // a dungeon's version: in that version
            for (int i = 0; i < np; i++) { grp[entr0 + i] = portals[i].In; grp[exit0 + i] = TravelData.Group(TravelData.Inst(portals[i])); }
            for (int k = 0; k < no; k++) grp[opt0 + k] = TravelData.Group(TravelData.Inst(opts[k]));
            _grp = grp;

            double[] dist = new double[n];
            int[] prev = new int[n];
            bool[] done = new bool[n];
            for (int i = 0; i < n; i++) { dist[i] = double.MaxValue; prev[i] = -1; }
            dist[0] = 0;
            while (true)
            {
                int u = -1; double best = double.MaxValue;
                for (int i = 0; i < n; i++) if (!done[i] && dist[i] < best) { best = dist[i]; u = i; }
                if (u < 0 || u == 1) break;
                done[u] = true;
                if (u >= entr0 && u < exit0)
                {
                    // through the portal
                    int x = exit0 + (u - entr0);
                    Relax(dist, prev, done, u, x, best + PortalSecs + (portals[u - entr0].BotName.Length > 0 ? PortalBots.SummonSecs : 0));
                    continue;
                }
                // a place you stand at (start, a portal's exit, where a recall lands): run to a portal or the destination
                RunFrom(u, at, area, dist, prev, done, best, 1);
                for (int j = 0; j < np; j++) RunFrom(u, at, area, dist, prev, done, best, entr0 + j);
                if (u == 0)
                    for (int k = 0; k < no; k++) Relax(dist, prev, done, 0, opt0 + k, OptSecs(opts[k]));
            }
            if (dist[1] == double.MaxValue) return null;

            // walk back from the destination
            List<int> path = new List<int>();
            for (int v = 1; v >= 0; v = prev[v]) path.Add(v);
            path.Reverse();
            Route r = new Route { Secs = dist[1], Dest = toName ?? to.ToString(), DestAt = to, DestArea = toArea };
            for (int i = 1; i < path.Count; i++)
            {
                int a = path[i - 1], b = path[i];
                if (b >= opt0)
                {
                    StartOpt o = opts[b - opt0];
                    r.Legs.Add(new Leg { Kind = o.Kind, Name = o.Name, Exit = o.Exit, ExitArea = o.ExitArea, Secs = OptSecs(o), Opt = o });
                }
                else if (b >= exit0)
                {
                    // the portal: merged with the run to it (the leg before)
                    Loc p = portals[b - exit0];
                    Leg prevLeg = r.Legs.Count > 0 ? r.Legs[r.Legs.Count - 1] : null;
                    if (prevLeg != null && prevLeg.Kind == "portal" && !prevLeg.Exit.Valid)
                    {
                        prevLeg.Name = p.Name; prevLeg.Exit = p.Exit; prevLeg.ExitArea = p.ExitArea; prevLeg.Secs += PortalSecs; prevLeg.PortalKey = p.Key;
                        if (p.BotName.Length > 0) { prevLeg.Bot = p.BotName; prevLeg.Say = p.BotWord; prevLeg.Name = p.Notes; prevLeg.Secs += PortalBots.SummonSecs; }
                    }
                }
                else if (b >= entr0)
                {
                    double d = at[a].DistanceTo(at[b]);
                    r.Legs.Add(new Leg { Kind = "portal", Target = at[b], TargetArea = area[b], Run = d, Secs = d * RunSecsPerUnit });
                }
                else if (b == 1)
                {
                    double d = at[a].DistanceTo(at[b]);
                    r.Legs.Add(new Leg { Kind = "run", Name = r.Dest, Target = to, TargetArea = toArea, Run = d, Secs = d * RunSecsPerUnit });
                }
            }
            return r;
        }

        private static int[] _region, _wall;

        private static string[] _grp;

        private static void RunFrom(int u, Coords[] at, int[] area, double[] dist, int[] prev, bool[] done, double here, int v)
        {
            if (done[v] || !TravelData.SameArea(area[u], area[v])) return;
            double d = at[u].DistanceTo(at[v]);
            if (area[u] < 0 && d > MaxRunOutdoors) return;
            if (area[u] < 0 && _wall != null && _wall[u] != _wall[v]) return;
            if (_grp != null && _grp[u] != _grp[v]) return;   // the world and a tier copy: only by portal / recall
            if (area[u] < 0 && _grp != null && _grp[u].Length > 0 && !TravelData.InsideBound(_grp[u], at[v])) return;   // out past the copy's boundary   // into / out of a walled-in area: only by portal
            if (area[u] < 0 && _region != null && _region[u] != 0 && _region[v] != 0 && _region[u] != _region[v]) return;   // sealed off from each other
            double cost = here + d * RunSecsPerUnit;
            if (cost >= dist[v]) return;
            // a run that would cross deep sea (the ocean, the inland sea): at best a long way round - counted as 4 times as far
            if (area[u] < 0 && d > 0.3 && WorldMap.SeaBetween(at[u], at[v])) cost = here + d * RunSecsPerUnit * 4;
            Relax(dist, prev, done, u, v, cost);
        }

        private static void Relax(double[] dist, int[] prev, bool[] done, int u, int v, double cost)
        {
            if (done[v] || cost >= dist[v]) return;
            dist[v] = cost; prev[v] = u;
        }
    }
}
