using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace MelksQuestTracker.Travel
{
    /// <summary>
    /// The real floor of a dungeon room, from client_portal.dat: each cell's environment (0x0D00xxxx) holds its room
    /// shapes (CellStruct: vertices and polygons); the polygons facing up near the bottom are the floor, turned and moved
    /// to where the cell sits. Gives the map pillars, alcoves, corridor widths and ramps instead of 10 m squares.
    /// Read once per shape, cached; anything that can't be read leaves the cell drawn as a square.
    /// </summary>
    internal static class CellShapes
    {
        // per environment + struct: the floor polygons in the shape's own space (x, y, z per point)
        private static readonly Dictionary<uint, List<float[]>> _local = new Dictionary<uint, List<float[]>>();
        // per cell: the floor polygons in the landblock's metres (x, y pairs), and their height
        private static readonly Dictionary<uint, List<float[]>> _cell = new Dictionary<uint, List<float[]>>();

        /// <summary>The cell's floor polygons (x0, y0, x1, y1 ... in landblock metres), or null (draw a square).</summary>
        public static List<float[]> Floor(DCell c)
        {
            List<float[]> l;
            if (_cell.TryGetValue(c.Id, out l)) return l;
            l = null;
            try
            {
                List<float[]> loc = Local(c.Env, c.Struct);
                if (loc != null && loc.Count > 0)
                {
                    l = new List<float[]>();
                    foreach (float[] p in loc)
                    {
                        // [flag, x, y, z, ...] -> [flag, x, y, ...]   flag 0 = floor, 1 = raised (a block / wall top: can't walk there)
                        float[] q = new float[1 + (p.Length - 1) / 3 * 2];
                        q[0] = p[0];
                        for (int i = 1, k = 1; i + 2 < p.Length; i += 3, k += 2)
                        {
                            double x, y, z;
                            Rotate(c.QW, c.QX, c.QY, c.QZ, p[i], p[i + 1], p[i + 2], out x, out y, out z);
                            q[k] = (float)(x + c.X); q[k + 1] = (float)(y + c.Y);
                        }
                        l.Add(q);
                    }
                }
            }
            catch { l = null; }
            _cell[c.Id] = l;
            return l;
        }

        private static readonly Dictionary<uint, List<float[]>> _cell3 = new Dictionary<uint, List<float[]>>();

        /// <summary>The cell's floor polygons with their heights: [flag, x, y, z, ...] in landblock metres (z: the game's height).</summary>
        public static List<float[]> Floor3(DCell c)
        {
            List<float[]> l;
            if (_cell3.TryGetValue(c.Id, out l)) return l;
            l = null;
            try
            {
                List<float[]> loc = Local(c.Env, c.Struct);
                if (loc != null && loc.Count > 0)
                {
                    l = new List<float[]>();
                    foreach (float[] p in loc)
                    {
                        if (p[0] == 2) continue;   // walls: Floor has them
                        float[] q = new float[p.Length];
                        q[0] = p[0];
                        for (int i = 1; i + 2 < p.Length; i += 3)
                        {
                            double x, y, z;
                            Rotate(c.QW, c.QX, c.QY, c.QZ, p[i], p[i + 1], p[i + 2], out x, out y, out z);
                            q[i] = (float)(x + c.X); q[i + 1] = (float)(y + c.Y); q[i + 2] = (float)(z + c.Z);
                        }
                        l.Add(q);
                    }
                }
            }
            catch { l = null; }
            _cell3[c.Id] = l;
            return l;
        }

        private static void Rotate(float w, float qx, float qy, float qz, double vx, double vy, double vz, out double x, out double y, out double z)
        {
            // v' = q v q*
            double tx = 2 * (qy * vz - qz * vy), ty = 2 * (qz * vx - qx * vz), tz = 2 * (qx * vy - qy * vx);
            x = vx + w * tx + (qy * tz - qz * ty);
            y = vy + w * ty + (qz * tx - qx * tz);
            z = vz + w * tz + (qx * ty - qy * tx);
        }

        public static string LastError = "";
        private static int _dumped;

        // ── saved per dungeon (Maps\Shapes\XXXX.bin) so a dungeon's shapes are read from the game's files only once ──
        private const int FileVersion = 6;
        private static readonly HashSet<int> _lbReady = new HashSet<int>();

        private static string LbPath(int lb) { return Util.FullPath(Path.Combine(Path.Combine("Maps", "Shapes"), lb.ToString("X4") + ".bin")); }

        /// <summary>Before drawing a dungeon: its shapes from the saved file, or worked out now and saved.</summary>
        public static void EnsureDungeon(int lb, Dictionary<uint, DCell> d)
        {
            if (d == null || !_lbReady.Add(lb)) return;
            try
            {
                string path = LbPath(lb);
                if (File.Exists(path) && Load(path, d)) return;
                foreach (DCell c in d.Values) Floor(c);
                int shaped = 0; foreach (DCell c in d.Values) { List<float[]> f; if (_cell.TryGetValue(c.Id, out f) && f != null && f.Count > 0) shaped++; }
                if (shaped > 0) Save(path, d);   // nothing read: not saved (tried again next time)
            }
            catch (Exception ex) { LastError = "dungeon " + lb.ToString("X4") + ": " + ex.Message; }
        }

        private static bool Load(string path, Dictionary<uint, DCell> d)
        {
            using (BinaryReader r = new BinaryReader(File.OpenRead(path)))
            {
                if (r.ReadInt32() != FileVersion) return false;
                int cells = r.ReadInt32();
                if (cells != d.Count) return false;   // the dungeon's cells changed (a patch): read again
                Dictionary<uint, List<float[]>> got = new Dictionary<uint, List<float[]>>();
                for (int i = 0; i < cells; i++)
                {
                    uint id = r.ReadUInt32();
                    int np = r.ReadInt32();
                    if (np < 0) { got[id] = null; continue; }
                    List<float[]> l = new List<float[]>(np);
                    for (int k = 0; k < np; k++)
                    {
                        int n = r.ReadInt32();
                        if (n < 0 || n > 4096) return false;
                        float[] pg = new float[n];
                        for (int j = 0; j < n; j++) pg[j] = r.ReadSingle();
                        l.Add(pg);
                    }
                    got[id] = l;
                }
                foreach (KeyValuePair<uint, List<float[]>> kv in got) _cell[kv.Key] = kv.Value;
                return true;
            }
        }

        private static void Save(string path, Dictionary<uint, DCell> d)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            string tmp = path + ".tmp";
            using (BinaryWriter w = new BinaryWriter(File.Create(tmp)))
            {
                w.Write(FileVersion);
                w.Write(d.Count);
                foreach (DCell c in d.Values)
                {
                    w.Write(c.Id);
                    List<float[]> l; _cell.TryGetValue(c.Id, out l);
                    if (l == null) { w.Write(-1); continue; }
                    w.Write(l.Count);
                    foreach (float[] pg in l) { w.Write(pg.Length); foreach (float f in pg) w.Write(f); }
                }
            }
            if (File.Exists(path)) File.Delete(path);
            File.Move(tmp, path);
        }

        private static List<float[]> Local(ushort env, ushort st)
        {
            uint key = ((uint)env << 16) | st;
            List<float[]> l;
            if (_local.TryGetValue(key, out l)) return l;
            l = null;
            try
            {
                byte[] f = WorldMap.PortalFile(0x0D000000u | env);
                if (f != null) l = ReadStruct(f, st);
                // couldn't read it: the raw file kept (a few) so the reading can be put right
                if (f != null && l == null && _dumped < 6)
                {
                    _dumped++;
                    try
                    {
                        string dp = Util.FullPath(Path.Combine(Path.Combine("Maps", "Shapes"), "unread_0D00" + env.ToString("X4") + ".bin"));
                        Directory.CreateDirectory(Path.GetDirectoryName(dp));
                        if (!File.Exists(dp)) File.WriteAllBytes(dp, f);
                    }
                    catch { }
                }
            }
            catch (Exception ex) { l = null; LastError = "env " + env.ToString("X4") + "/" + st + ": " + ex.Message; }
            _local[key] = l;
            return l;
        }

        // ── client_portal.dat: Environment -> CellStruct ──
        private static List<float[]> ReadStruct(byte[] f, ushort want)
        {
            using (BinaryReader r = new BinaryReader(new MemoryStream(f)))
            {
                r.ReadUInt32();   // id
                uint n = r.ReadUInt32();
                if (n > 512) return null;
                for (uint i = 0; i < n; i++)
                {
                    uint k = r.ReadUInt32();
                    List<float[]> floor = null;
                    long at = r.BaseStream.Position;
                    // which polygons carry a second set of texture indices isn't certain: whichever reading lands on a
                    // real BSP tree after the polygons is the right one
                    bool ok = false;
                    foreach (int negSides in NegSidesOrder())
                    {
                        foreach (bool align in new[] { _align, !_align })
                        {
                            r.BaseStream.Position = at;
                            try { ok = ReadCellStruct(r, k == want, negSides, align, out floor); } catch { ok = false; }
                            if (ok) { _negSides = negSides; _align = align; break; }
                        }
                        if (ok) break;
                    }
                    if (!ok) { LastError = "shape " + k + " didn't line up (struct " + i + " of " + n + ")"; return null; }
                    if (k == want) return floor;
                }
                return null;
            }
        }

        private class Poly { public byte N; public short[] V; }

        private static bool _wantCenters;
        private static Dictionary<int, float[]> _lastCenters;
        private static readonly Dictionary<uint, Dictionary<int, float[]>> _centers = new Dictionary<uint, Dictionary<int, float[]>>();

        /// <summary>The middle of an opening between two rooms (a room's link polygon, from WorldMap's NextPoly), in landblock
        /// metres with its height - or null.</summary>
        public static double[] OpeningCenter(DCell c, ushort poly)
        {
            uint key = ((uint)c.Env << 16) | c.Struct;
            Dictionary<int, float[]> cen;
            if (!_centers.TryGetValue(key, out cen))
            {
                cen = null;
                try
                {
                    byte[] f = WorldMap.PortalFile(0x0D000000u | c.Env);
                    if (f != null)
                    {
                        _wantCenters = true; _lastCenters = null;
                        try { ReadStruct(f, c.Struct); } finally { _wantCenters = false; }
                        cen = _lastCenters;
                    }
                }
                catch { cen = null; }
                _centers[key] = cen;
            }
            float[] v;
            if (cen == null || !cen.TryGetValue(poly, out v)) return null;
            double x, y, z;
            Rotate(c.QW, c.QX, c.QY, c.QZ, v[0], v[1], v[2], out x, out y, out z);
            double lowZ = v.Length > 3 ? z - v[2] + v[3] : z;   // its bottom edge (rooms only turn round, not tip)
            double highZ = v.Length > 4 ? z - v[2] + v[4] : z;   // its top edge
            if (v.Length > 8)
            {
                double x1, y1, z1, x2, y2, z2;
                Rotate(c.QW, c.QX, c.QY, c.QZ, v[5], v[6], v[2], out x1, out y1, out z1);
                Rotate(c.QW, c.QX, c.QY, c.QZ, v[7], v[8], v[2], out x2, out y2, out z2);
                return new[] { x + c.X, y + c.Y, z + c.Z, lowZ + c.Z, highZ + c.Z, x1 + c.X, y1 + c.Y, x2 + c.X, y2 + c.Y };
            }
            return new[] { x + c.X, y + c.Y, z + c.Z, lowZ + c.Z, highZ + c.Z };
        }

        private static int _negSides = 2;
        private static bool _align = true;
        private static IEnumerable<int> NegSidesOrder() { yield return _negSides; yield return _negSides == 2 ? 1 : 2; }

        private static readonly HashSet<string> BspTypes = new HashSet<string> { "LEAF", "PORT", "BPnn", "BPIn", "BpIN", "BpnN", "BPIN", "BPnN", "BpIn", "Bpnn", "BPFL", "BPOL" };

        private static string PeekType(BinaryReader r)
        {
            long at = r.BaseStream.Position;
            if (at + 4 > r.BaseStream.Length) return "";
            byte[] t = r.ReadBytes(4);
            r.BaseStream.Position = at;
            return new string(new[] { (char)t[3], (char)t[2], (char)t[1], (char)t[0] });
        }

        private static bool ReadCellStruct(BinaryReader r, bool keep, int negSides, bool align, out List<float[]> floor)
        {
            floor = null;
            uint nPoly = r.ReadUInt32(), nPhys = r.ReadUInt32(), nPortal = r.ReadUInt32();
            if (nPoly > 20000 || nPhys > 20000 || nPortal > 1000) return false;
            // vertices
            int vtype = r.ReadInt32();
            uint nv = r.ReadUInt32();
            if (nv > 65535) return false;
            Dictionary<int, float[]> verts = new Dictionary<int, float[]>();
            if (vtype == 1)
                for (uint i = 0; i < nv; i++)
                {
                    int id = r.ReadUInt16();
                    int nuv = r.ReadUInt16();
                    float x = r.ReadSingle(), y = r.ReadSingle(), z = r.ReadSingle();
                    r.ReadSingle(); r.ReadSingle(); r.ReadSingle();   // normal
                    for (int u = 0; u < nuv; u++) { r.ReadSingle(); r.ReadSingle(); }
                    verts[id] = new[] { x, y, z };
                }
            else if (nv > 0) return false;
            // polygons
            List<Poly> polys = new List<Poly>();
            List<int> polyKeys = new List<int>();
            for (uint i = 0; i < nPoly; i++) { polyKeys.Add(r.ReadUInt16()); polys.Add(ReadPoly(r, negSides)); }
            if (keep && _wantCenters)
            {
                // each polygon's middle (the openings between rooms are polygons too: where to walk through)
                Dictionary<int, float[]> cen = new Dictionary<int, float[]>();
                for (int pi = 0; pi < polys.Count; pi++)
                {
                    Poly pc = polys[pi]; double sx = 0, sy = 0, sz = 0, mz = double.MaxValue, xz = double.MinValue; int n = 0;
                    if (pc.V == null) continue;
                    foreach (short vi in pc.V) { float[] v; if (verts.TryGetValue(vi, out v)) { sx += v[0]; sy += v[1]; sz += v[2]; n++; if (v[2] < mz) mz = v[2]; if (v[2] > xz) xz = v[2]; } }
                    // its width on the floor: the two corners furthest apart (seen from above)
                    float ax = 0, ay = 0, bx = 0, by = 0; double far = -1;
                    for (int i1 = 0; i1 < pc.V.Length; i1++)
                        for (int i2 = i1 + 1; i2 < pc.V.Length; i2++)
                        {
                            float[] v1, v2;
                            if (!verts.TryGetValue(pc.V[i1], out v1) || !verts.TryGetValue(pc.V[i2], out v2)) continue;
                            double dd = (v1[0] - v2[0]) * (v1[0] - v2[0]) + (v1[1] - v2[1]) * (v1[1] - v2[1]);
                            if (dd > far) { far = dd; ax = v1[0]; ay = v1[1]; bx = v2[0]; by = v2[1]; }
                        }
                    if (n > 0) cen[polyKeys[pi]] = new[] { (float)(sx / n), (float)(sy / n), (float)(sz / n), (float)mz, (float)xz, ax, ay, bx, by };
                }
                _lastCenters = cen;
            }
            for (uint i = 0; i < nPortal; i++) r.ReadUInt16();
            if (align) Align(r);
            bool lined = BspTypes.Contains(PeekType(r));
            if (!lined)
            {
                // what follows the polygons didn't look right - but the shape wanted only needs its vertices and
                // polygons: if every polygon is sane and points at real vertices, that's enough to draw it
                if (!keep) return false;
                foreach (Poly pc in polys)
                {
                    if (pc.N < 3 || pc.N > 64) return false;
                    foreach (short vi in pc.V) if (!verts.ContainsKey(vi)) return false;
                }
            }
            if (!keep)
            {
                SkipBsp(r, 1);                                     // cell BSP
                for (uint i = 0; i < nPhys; i++) { r.ReadUInt16(); ReadPoly(r, negSides); }
                SkipBsp(r, 2);                                     // physics BSP
                uint hasDraw = r.ReadUInt32();
                if (hasDraw != 0) SkipBsp(r, 0);                   // drawing BSP
                Align(r);
                return true;
            }

            // what you bump into: the physics polygons (after the cell's BSP) - the walls are drawn from these when they can be read
            List<Poly> phys = null;
            if (lined)
            {
                try
                {
                    SkipBsp(r, 1);
                    phys = new List<Poly>();
                    for (uint i = 0; i < nPhys; i++) { r.ReadUInt16(); phys.Add(ReadPoly(r, negSides)); }
                    foreach (Poly pc in phys) foreach (short vi in pc.V) if (!verts.ContainsKey(vi)) { phys = null; break; }
                }
                catch { phys = null; }
            }

            // the floor: polygons facing up at the bottom of the room; ones facing up higher (the top of a wall or block
            // standing in the room) are kept as "raised" - drawn as something in the way
            List<float[]> up = new List<float[]>();
            List<float> avgZ = new List<float>(), lowZ = new List<float>();
            List<float[]> walls = new List<float[]>(); List<float> wallLow = new List<float>();
            float minZ = float.MaxValue;
            List<Poly> all = new List<Poly>(polys);
            int visualCount = polys.Count;
            if (phys != null) all.AddRange(phys);
            for (int pi = 0; pi < all.Count; pi++)
            {
                Poly p = all[pi];
                bool isPhys = pi >= visualCount;
                if (p.N < 3) continue;
                float[] pts = new float[p.N * 3];
                bool okp = true;
                for (int i = 0; i < p.N; i++)
                {
                    float[] v; if (!verts.TryGetValue(p.V[i], out v)) { okp = false; break; }
                    pts[i * 3] = v[0]; pts[i * 3 + 1] = v[1]; pts[i * 3 + 2] = v[2];
                }
                if (!okp) continue;
                // normal (Newell)
                double nx = 0, ny = 0, nz = 0, sz = 0, mz = double.MaxValue;
                for (int i = 0; i < p.N; i++)
                {
                    int j = (i + 1) % p.N;
                    double x1 = pts[i * 3], y1 = pts[i * 3 + 1], z1 = pts[i * 3 + 2], x2 = pts[j * 3], y2 = pts[j * 3 + 1], z2 = pts[j * 3 + 2];
                    nx += (y1 - y2) * (z1 + z2); ny += (z1 - z2) * (x1 + x2); nz += (x1 - x2) * (y1 + y2);
                    sz += z1; if (z1 < mz) mz = z1;
                }
                double len = Math.Sqrt(nx * nx + ny * ny + nz * nz);
                if (len < 1e-6) continue;
                if (Math.Abs(nz / len) < 0.3)
                {
                    // a wall: its line on the floor, below - from what you bump into when that's known, else what's drawn
                    if (isPhys || phys == null || phys.Count == 0) { walls.Add(pts); wallLow.Add((float)mz); }
                    continue;
                }
                if (isPhys) continue;   // floors come from what's drawn
                if (nz / len < 0.7) continue;   // not facing up (a ceiling faces down)
                float az = (float)(sz / p.N);
                up.Add(pts); avgZ.Add(az); lowZ.Add((float)mz);
                if (nz > 0 && az < minZ) minZ = az;
            }
            if (up.Count == 0) return true;
            if (minZ == float.MaxValue) foreach (float z in avgZ) minZ = Math.Min(minZ, z);
            List<float[]> wallLines = new List<float[]>();
            for (int i = 0; i < walls.Count; i++)
            {
                if (wallLow[i] > minZ + 1.5f) continue;   // high up (a ledge, the top of an arch)
                // the wall seen from above is a line: its two points furthest apart
                float[] w = walls[i]; int n = w.Length / 3, a = 0, b = 0; double best = -1;
                for (int x = 0; x < n; x++)
                    for (int y = x + 1; y < n; y++)
                    {
                        double dx = w[x * 3] - w[y * 3], dy = w[x * 3 + 1] - w[y * 3 + 1], dd = dx * dx + dy * dy;
                        if (dd > best) { best = dd; a = x; b = y; }
                    }
                if (best < 0.04) continue;   // end-on (a pillar's face is drawn by its others)
                wallLines.Add(new[] { 2f, w[a * 3], w[a * 3 + 1], w[a * 3 + 2], w[b * 3], w[b * 3 + 1], w[b * 3 + 2] });
            }
            floor = new List<float[]>();
            for (int i = 0; i < up.Count; i++)
            {
                if (avgZ[i] > minZ + 3.0f) continue;                       // the ceiling
                bool raised = lowZ[i] > minZ + 0.5f;                       // starts above the floor: a block's top (a ramp starts at the floor)
                float[] f = new float[1 + up[i].Length];
                f[0] = raised ? 1 : 0;
                Array.Copy(up[i], 0, f, 1, up[i].Length);
                floor.Add(f);
            }
            floor.AddRange(wallLines);   // flag 2: a wall's line
            return true;
        }

        private static Poly ReadPoly(BinaryReader r, int negSides)
        {
            Poly p = new Poly();
            p.N = r.ReadByte();
            byte stip = r.ReadByte();
            int sides = r.ReadInt32();
            r.ReadInt16(); r.ReadInt16();   // surfaces
            p.V = new short[p.N];
            for (int i = 0; i < p.N; i++) p.V[i] = r.ReadInt16();
            if ((stip & 4) == 0) r.ReadBytes(p.N);                     // positive side UVs
            if (sides == negSides && (stip & 8) == 0) r.ReadBytes(p.N);       // negative side UVs
            return p;
        }

        private static void Align(BinaryReader r)
        {
            long pos = r.BaseStream.Position;
            if ((pos & 3) != 0) r.BaseStream.Position = pos + (4 - (pos & 3));
        }

        // tree: 0 drawing, 1 cell, 2 physics (ACE's BSPNode / BSPLeaf / BSPPortal)
        private static void SkipBsp(BinaryReader r, int tree, int depth = 0)
        {
            if (depth > 200) throw new InvalidDataException("bsp too deep");
            byte[] t = r.ReadBytes(4);
            string type = new string(new[] { (char)t[3], (char)t[2], (char)t[1], (char)t[0] });
            if (type == "LEAF")
            {
                r.ReadInt32();   // leaf index
                if (tree == 2)
                {
                    r.ReadInt32();   // solid
                    r.ReadBytes(16); // sphere
                    uint np = r.ReadUInt32();
                    if (np > 20000) throw new InvalidDataException("bsp");
                    r.ReadBytes((int)np * 2);
                }
                return;
            }
            if (type == "PORT")
            {
                r.ReadBytes(16);   // plane
                SkipBsp(r, tree, depth + 1); SkipBsp(r, tree, depth + 1);
                if (tree == 0)
                {
                    r.ReadBytes(16);   // sphere
                    uint np = r.ReadUInt32(), npt = r.ReadUInt32();
                    if (np > 20000 || npt > 20000) throw new InvalidDataException("bsp");
                    r.ReadBytes((int)np * 2);
                    r.ReadBytes((int)npt * 4);
                }
                return;
            }
            r.ReadBytes(16);   // splitting plane
            switch (type)
            {
                case "BPnn": case "BPIn": SkipBsp(r, tree, depth + 1); break;
                case "BpIN": case "BpnN": SkipBsp(r, tree, depth + 1); break;
                case "BPIN": case "BPnN": SkipBsp(r, tree, depth + 1); SkipBsp(r, tree, depth + 1); break;
                case "BpIn": case "Bpnn": case "BPFL": case "BPOL": break;   // no child nodes
                default: throw new InvalidDataException("bsp type " + type);
            }
            if (tree == 1) return;
            r.ReadBytes(16);   // sphere
            if (tree == 2) return;
            uint n2 = r.ReadUInt32();
            if (n2 > 20000) throw new InvalidDataException("bsp");
            r.ReadBytes((int)n2 * 2);
        }

        // ── boundary edges of a level (the walls' line on the map) ──
        private static readonly Dictionary<string, List<float[]>> _edges = new Dictionary<string, List<float[]>>();

        /// <summary>The edges of the floor that no other floor polygon shares (x1, y1, x2, y2) - the outline.</summary>
        public static List<float[]> Outline(int lb, int level, IEnumerable<DCell> cells)
        {
            string k = lb + "|" + level;
            List<float[]> l;
            if (_edges.TryGetValue(k, out l)) return l;
            Dictionary<string, int> count = new Dictionary<string, int>();
            Dictionary<string, float[]> seg = new Dictionary<string, float[]>();
            foreach (DCell c in cells)
            {
                List<float[]> fl = Floor(c);
                if (fl == null) continue;
                foreach (float[] p in fl)
                {
                    if (p[0] != 0) continue;   // raised: not floor
                    int n = (p.Length - 1) / 2;
                    for (int i = 0; i < n; i++)
                    {
                        int j = (i + 1) % n;
                        float x1 = p[1 + i * 2], y1 = p[2 + i * 2], x2 = p[1 + j * 2], y2 = p[2 + j * 2];
                        string a = Math.Round(x1 * 10) + "," + Math.Round(y1 * 10), b = Math.Round(x2 * 10) + "," + Math.Round(y2 * 10);
                        if (a == b) continue;
                        string key = string.CompareOrdinal(a, b) < 0 ? a + "|" + b : b + "|" + a;
                        int cnt; count.TryGetValue(key, out cnt); count[key] = cnt + 1;
                        seg[key] = new[] { x1, y1, x2, y2 };
                    }
                }
            }
            l = new List<float[]>();
            foreach (KeyValuePair<string, int> kv in count) if (kv.Value == 1) l.Add(seg[kv.Key]);
            _edges[k] = l;
            return l;
        }
    }
}
