using System;
using Decal.Adapter;
using ImGuiNET;
using Vec2 = System.Numerics.Vector2;
using Vec4 = System.Numerics.Vector4;

namespace MelksQuestTracker.Travel
{
    /// <summary>The travel window: an arrow at where to go next, the distance, the step you're on (with a button for a recall /
    /// gem / command step), and the whole route underneath when opened. Its own UtilityBelt window; drag it anywhere.</summary>
    internal static class TravelHud
    {
        private static UtilityBelt.Service.Views.Hud _hud;
        private static bool _showSteps = true;
        private static int _restoredFor;
        private const string Name = "MelksQB Travel";

        public static readonly Vec4 Green = new Vec4(0.45f, 0.9f, 0.45f, 1f);
        public static readonly Vec4 Yellow = new Vec4(0.95f, 0.85f, 0.35f, 1f);
        public static readonly Vec4 Grey = new Vec4(0.6f, 0.6f, 0.6f, 1f);
        public static readonly Vec4 Orange = new Vec4(1f, 0.65f, 0.3f, 1f);
        public static readonly Vec4 Cyan = new Vec4(0.35f, 0.85f, 0.95f, 1f);

        private static bool Ensure()
        {
            if (_hud != null) return true;
            try
            {
                if (UtilityBelt.Service.UBService.Huds == null) return false;
                _hud = UtilityBelt.Service.UBService.Huds.CreateHud(Name, MyClasses.MetaViewWrappers.UBHudControls.BarIcon.Make("Go"));
                _hud.ShowInBar = false;
#if ACGODOT
                _hud.InBar = Travel.Active;   // on ACGodot's plugin bar while travelling: shows / hides this window
#endif
                _hud.WindowSettings = ImGuiWindowFlags.NoTitleBar | ImGuiWindowFlags.AlwaysAutoResize | ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoCollapse;
                _hud.OnPreRender += (s, e) =>
                {
                    if (MyClasses.MetaViewWrappers.UBHudControls.WindowMemory.Restore(ref _restoredFor))
                    {
                        float[] r;
                        if (MyClasses.MetaViewWrappers.UBHudControls.WindowMemory.TryGet(Name, out r)) ImGui.SetNextWindowPos(new Vec2(r[0], r[1]), ImGuiCond.Always);
                        else ImGui.SetNextWindowPos(new Vec2(300, 120), ImGuiCond.FirstUseEver);
                    }
                    ImGui.SetNextWindowBgAlpha(0.8f);
                };
                _hud.OnRender += (s, e) =>
                {
                    try { MyClasses.MetaViewWrappers.UBHudControls.WindowMemory.Track(Name); } catch { }
                    try { Content(); } catch (Exception ex) { Util.LogError(ex); }
                };
                return true;
            }
            catch (Exception ex) { Util.LogError(ex); _hud = null; return false; }
        }

        public static void Show() { if (Ensure()) _hud.Visible = true; }
        public static void Hide() { if (_hud != null) _hud.Visible = false; }
        /// <summary>ACGodot: the window's button on the plugin bar only while travelling.</summary>
        public static void SyncBar()
        {
#if ACGODOT
            if (_hud != null) _hud.InBar = Travel.Active;
#endif
        }
        public static bool Visible { get { return _hud != null && _hud.Visible; } }

        public static void Dispose()
        {
            try { if (_hud != null) _hud.Dispose(); } catch { }
            _hud = null; _restoredFor = 0;
        }

        private static void Content()
        {
            if (!Travel.Active) { Im.TextDisabled("No destination."); if (ImGui.SmallButton("Close##tvx")) Hide(); return; }
            string label;
            Coords target = Travel.ArrowTarget(out label);
            Coords here = Travel.Here();
            Leg leg = Travel.Current;
            bool actionStep = !Travel.ArrowOnly && leg != null && leg.Opt != null;
            bool sameArea = TravelData.SameArea(Travel.HereArea(), leg != null && !Travel.ArrowOnly && leg.Target.Valid ? leg.TargetArea : Travel.DestArea);

            // the arrow
            float size = 64f;
            Vec2 p0 = ImGui.GetCursorScreenPos();
            ImGui.Dummy(new Vec2(size, size));
            if (!actionStep && here.Valid && target.Valid)
            {
                double heading = 0;
                try { heading = CoreManager.Current.Actions.Heading; } catch { }
                double rel = (here.BearingTo(target) - heading) * Math.PI / 180.0;
                bool facing = Math.Abs(Math.IEEERemainder(here.BearingTo(target) - heading, 360)) < 15;
                Vec4 col = Travel.Arrived ? Grey : !sameArea ? Orange : facing ? Green : Yellow;
                DrawArrow(new Vec2(p0.X + size / 2, p0.Y + size / 2), size * 0.42f, (float)rel, ImGui.GetColorU32(col));
            }
            else if (actionStep)
            {
                ImDrawListPtr dl = ImGui.GetWindowDrawList();
                dl.AddCircle(new Vec2(p0.X + size / 2, p0.Y + size / 2), size * 0.38f, ImGui.GetColorU32(Cyan), 24, 3f);
            }
            ImGui.SameLine();
            ImGui.BeginGroup();
            ImGui.PushTextWrapPos(ImGui.GetCursorPosX() + 300);
            if (Travel.Arrived) Im.TextColored(Green, "Arrived at " + Travel.DestName);
            else if (actionStep) Im.TextColored(Cyan, StepText(leg, true));
            else
            {
                Im.TextColored(Yellow, label);
                if (here.Valid && target.Valid)
                {
                    double d = here.DistanceTo(target);
                    Im.Text(Dist(d) + "  (" + Travel.Time(d * Router.RunSecsPerUnit) + ")   " + target);
                }
                if (!sameArea) Im.TextColored(Orange, "Not reachable on foot from here");
                if (!Travel.ArrowOnly && leg != null && leg.Kind == "portal") Im.TextDisabled(StepText(leg, false));
            }
            if (!string.IsNullOrEmpty(Travel.Note)) Im.TextColored(Orange, Travel.Note);
            ImGui.PopTextWrapPos();
            if (actionStep && !Travel.Arrived)
            {
                string b = leg.Kind == "gem" ? "Use it" : leg.Kind == "cmd" ? "Type it" : "Cast it";
                if (ImGui.Button(b + "##tvdo")) Travel.DoStep(leg);
                ImGui.SameLine();
                if (leg.Kind == "gem" && leg.Opt.OpensPortal) { if (ImGui.Button("Go through##tvgp")) Travel.UseGemPortal(); ImGui.SameLine(); }
                if (ImGui.Button("Skip##tvskip")) { Travel.Step++; AutoTravel.RouteChanged(true); }
            }
            // two rows: Auto travel, Reroute, Stop on top; the route shown on the ground, Hide (and the steps list, a
            // portal bot's word) under them
            if (ImGui.SmallButton(AutoTravel.On ? "Auto: ON##tvauto" : "Auto travel##tvauto")) AutoTravel.Toggle();
            if (ImGui.IsItemHovered()) Im.SetTooltip(AutoTravel.On ? "MelkTank is walking the route. Click (or move yourself) to stop." : "MelkTank walks the route for you: around steep ground and water, through dungeon corridors, through the portals.\nMove yourself to stop it.");
            ImGui.SameLine();
            if (!Travel.ArrowOnly && ImGui.SmallButton("Reroute##tvrr")) Travel.Reroute(true, true);
            if (!Travel.ArrowOnly && ImGui.IsItemHovered()) Im.SetTooltip("Works out the fastest way from here again (portals and all).");
            if (!Travel.ArrowOnly) ImGui.SameLine();
            if (Travel.Direct) ImGui.PushStyleColor(ImGuiCol.Text, Green);
            if (ImGui.SmallButton(Travel.Direct ? "Direct: ON##tvdir" : "Direct##tvdir")) { if (Travel.Direct) Travel.Reroute(true, true); else Travel.GoDirect(true); }
            if (Travel.Direct) ImGui.PopStyleColor();
            if (ImGui.IsItemHovered()) Im.SetTooltip(Travel.Direct ? "Going straight there on foot, no portals. Click (or Reroute) for the fastest way again."
                                                                  : "Straight there on foot from here - no portals (around water and steep ground).\nAuto travel walks it. Reroute goes back to the fastest way.");
            ImGui.SameLine();
            bool stop = ImGui.SmallButton("Stop##tvstop");
            // second row: the steps list at the left, the route on the ground, a portal bot's word, Hide at the right
            if (!Travel.ArrowOnly && Travel.Route != null)
            {
                if (ImGui.SmallButton(_showSteps ? "Hide steps##tvst" : "Steps##tvst")) _showSteps = !_showSteps;
                ImGui.SameLine();
            }
            if (!Travel.ArrowOnly && !AutoTravel.On)
            {
                if (ImGui.SmallButton(AutoTravel.Showing ? "Hide route##tvshow" : "Show route##tvshow")) AutoTravel.ToggleShow();
                if (ImGui.IsItemHovered()) Im.SetTooltip(AutoTravel.Showing ? "Takes the route off the ground." : "Draws the way auto travel would walk on the ground (rings, step numbers, dots; portals it would use in yellow),\nwithout moving you. MelkTank draws it.");
                ImGui.SameLine();
            }
            if (!Travel.ArrowOnly && leg != null && leg.Bot.Length > 0 && !AutoTravel.On)
            {
                if (ImGui.SmallButton("Say " + leg.Say + "##tvbot")) Util.Command(leg.Say);
                if (ImGui.IsItemHovered()) Im.SetTooltip("Says \"" + leg.Say + "\" in local chat (stand next to " + leg.Bot + ") - it opens a portal to " + leg.Name + " by it.");
                ImGui.SameLine();
            }
            {
                // (Hide at the far right of the row)
                float hw = ImGui.CalcTextSize("Hide").X + ImGui.GetStyle().FramePadding.X * 2f;
                float right = ImGui.GetCursorPosX() + ImGui.GetContentRegionAvail().X - hw;
                if (right > ImGui.GetCursorPosX()) ImGui.SetCursorPosX(right);
            }
            if (ImGui.SmallButton("Hide##tvhide")) Hide();
            ImGui.EndGroup();   // (always closed - leaving a group open breaks the window)
            if (stop) { Travel.Clear(); return; }

            if (_showSteps && !Travel.ArrowOnly && Travel.Route != null)
            {
                ImGui.Separator();
                DrawSteps(360);
            }
        }

        /// <summary>The route, one line a step: done ones grey, the current one yellow. Right-click a portal: don't use it.</summary>
        public static void DrawSteps(float wrap)
        {
            Route r = Travel.Route;
            if (r == null) { Im.TextDisabled(Travel.ArrowOnly ? "Just the arrow - no route." : "No route."); return; }
            ImGui.PushTextWrapPos(ImGui.GetCursorPosX() + wrap);
            for (int i = 0; i < r.Legs.Count; i++)
            {
                Leg l = r.Legs[i];
                Vec4 col = i < Travel.Step ? Grey : i == Travel.Step && !Travel.Arrived ? Yellow : Vec4.One;
                Im.TextColored(col, (i + 1) + ". " + StepText(l, true));
                if (ImGui.IsItemHovered())
                {
                    string tip = (l.Exit.Valid ? "Lands at " + l.Exit + (l.ExitArea >= 0 ? " (" + TravelData.AreaName(l.ExitArea) + ")" : "") + "\n" : "") + "About " + Travel.Time(l.Secs);
                    if (l.Kind == "portal") tip += "\nRight-click: don't use this portal";
                    if (i != Travel.Step) tip += "\nClick: make this the current step";
                    Im.SetTooltip(tip);
                }
                if (ImGui.IsItemClicked(ImGuiMouseButton.Left) && Travel.Step != i) { Travel.Step = i; AutoTravel.RouteChanged(true); }
                if (l.Kind == "portal" && l.PortalKey.Length > 0 && ImGui.IsItemClicked(ImGuiMouseButton.Right))
                {
                    TravelData.SetAvoid(l.PortalKey, true);
                    Util.WriteToChat("Travel: won't use " + l.Name + " (Travel tab to undo).");
                    Travel.Reroute(true);
                    break;
                }
            }
            Im.TextDisabled("Total about " + Travel.Time(r.Secs));
            ImGui.PopTextWrapPos();
        }

        /// <summary>A route that isn't the one being followed (the Travel tab's preview): numbered steps, total time.</summary>
        public static void DrawRoute(Route r, string destName, Coords destAt, float wrap)
        {
            ImGui.PushTextWrapPos(ImGui.GetCursorPosX() + wrap);
            for (int i = 0; i < r.Legs.Count; i++)
            {
                Leg l = r.Legs[i];
                string t = l.Kind == "run" ? "Run " + Dist(l.Run) + " to " + destName + " (" + destAt + ")" : StepText(l, true);
                Im.Text((i + 1) + ". " + t);
                if (ImGui.IsItemHovered()) Im.SetTooltip((l.Exit.Valid ? "Lands at " + l.Exit + (l.ExitArea >= 0 ? " (" + TravelData.AreaName(l.ExitArea) + ")" : "") + "\n" : "") + "About " + Travel.Time(l.Secs));
            }
            Im.TextDisabled("Total about " + Travel.Time(r.Secs));
            ImGui.PopTextWrapPos();
        }

        public static string StepText(Leg l, bool full)
        {
            switch (l.Kind)
            {
                case "spell": return "Cast " + l.Name;
                case "gem": return "Use " + l.Name + (l.Opt != null && l.Opt.OpensPortal ? ", then go through the portal it opens" : "");
                case "cmd": return "Type " + l.Name;
                case "run": return "Run " + Dist(l.Run) + " to " + Travel.DestName + (full ? " (" + Travel.DestAt + ")" : "");
                case "portal":
                    if (l.Bot.Length > 0) return (l.TargetArea >= 0 ? "In " + TravelData.AreaName(l.TargetArea) + ": " : "") + "next to " + l.Bot + " say \"" + l.Say + "\", then take its portal to " + l.Name;
                    if (l.TargetArea >= 0)
                    {
                        // the dungeon's version the portal stands in (Enlightened Facility Hub, not Facility Hub)
                        string vin = "";
                        foreach (Loc pl in TravelData.Locs) if (pl.Key == l.PortalKey) { vin = pl.In ?? ""; break; }
                        return "In " + (vin.StartsWith("v") ? TravelData.AreaName(l.TargetArea, vin) : TravelData.AreaName(l.TargetArea)) + ": take " + l.Name;
                    }
                    return (l.Run > 0.02 ? "Run " + Dist(l.Run) + " to " : "Take ") + l.Name + (full ? " (" + l.Target + ")" : "") + (l.Run > 0.02 ? " and go through" : "");
            }
            return l.Name;
        }

        public static string Dist(double d)
        {
            if (d < 0.2) return ((int)Math.Round(d * 240)) + " m";
            return d.ToString(d < 10 ? "0.00" : "0.0", System.Globalization.CultureInfo.InvariantCulture);
        }

        private static void DrawArrow(Vec2 c, float r, float rad, uint col)
        {
            float cs = (float)Math.Cos(rad), sn = (float)Math.Sin(rad);
            Func<float, float, Vec2> P = (x, y) => new Vec2(c.X + x * cs - y * sn, c.Y + x * sn + y * cs);
            Vec2 tip = P(0, -r), left = P(-0.6f * r, 0.7f * r), notch = P(0, 0.3f * r), right = P(0.6f * r, 0.7f * r);
            ImDrawListPtr dl = ImGui.GetWindowDrawList();
            dl.AddTriangleFilled(tip, left, notch, col);
            dl.AddTriangleFilled(tip, notch, right, col);
            uint edge = ImGui.GetColorU32(new Vec4(0, 0, 0, 0.8f));
            dl.AddLine(tip, left, edge, 1.5f); dl.AddLine(left, notch, edge, 1.5f); dl.AddLine(notch, right, edge, 1.5f); dl.AddLine(right, tip, edge, 1.5f);
        }
    }
}
