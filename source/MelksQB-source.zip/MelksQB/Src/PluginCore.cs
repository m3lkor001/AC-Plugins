using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;

using Decal.Adapter;
using Decal.Adapter.Wrappers;
using MyClasses.MetaViewWrappers;


/*
 * MelksQuestTracker
 *
 * Companion to MelksLuminanceTracker, same author/patterns (WireUpBaseEvents, MVView,
 * try/catch around every event handler, XML settings files keyed by "Server-CharacterName").
 *
 * Notes:
 *   - The "Main" tab quest list uses a fixed set of 15 button+label row pairs with Prev/Next paging.
 *   - "Enabled" and text-color are set via reflection helpers (TrySetEnabled/TrySetColor) that
 *     silently no-op if a control doesn't expose that property; the text fallback (countdown text
 *     on the button, [100%]/[ 50%] prefix on rows) still shows the information either way.
 */

namespace MelksQuestTracker
{
#if HOTCORE
    // Built as MelksQuestTrackerCore.dll: the small MelksQuestTracker.dll loader (the plugin Decal knows) loads this from
    // bytes and can swap in a new build without restarting the game - HotStart / HotStop below (as MelkTank does).
    [MVView("MelksQuestTracker.mainView.xml")]
    [MVWireUpControlEvents]
    public class PluginCore
    {
        protected PluginHost Host { get; private set; }
        protected CoreManager Core { get; private set; }
        private static PluginCore _hot;
        private const string VisibleKey = "MelksQB.WindowOpen";

        /// <summary>The loader starts this build (host, core = Decal's; dir = the plugin folder).</summary>
        public static void HotStart(PluginHost host, CoreManager core, string dir)
        {
            Util.BasePath = dir;
            MyClasses.MetaViewWrappers.UBHudControls.WindowMemory.BaseDir = dir;
            PluginCore p = new PluginCore { Host = host, Core = core };
            _hot = p;
            p.Startup();
            core.CharacterFilter.LoginComplete += p.CharacterFilter_LoginComplete;
            core.CharacterFilter.Logoff += p.CharacterFilter_Logoff;
            core.ChatBoxMessage += p.Current_ChatBoxMessage;
            core.CommandLineText += p.Core_CommandLineText;
            // swapped in while in the world: the login already happened - do what it does, and reopen the window if it was open
            try
            {
                if (core.CharacterFilter.LoginStatus == 3)
                {
                    p.CharacterFilter_LoginComplete(null, EventArgs.Empty);
                    object was = AppDomain.CurrentDomain.GetData(VisibleKey);
                    MyClasses.MetaViewWrappers.IView v = MVWireupHelper.GetDefaultView(p);
                    if (v != null && was is bool && (bool)was) v.Visible = true;
                }
            }
            catch (Exception ex) { Util.LogError(ex); }
        }

        /// <summary>The loader stops this build: reload = a new build is about to start.</summary>
        public static void HotStop(bool reload)
        {
            PluginCore p = _hot;
            _hot = null;
            if (p == null) return;
            try
            {
                MyClasses.MetaViewWrappers.IView v = MVWireupHelper.GetDefaultView(p);
                AppDomain.CurrentDomain.SetData(VisibleKey, reload && v != null && v.Visible);
            }
            catch { }
            try
            {
                p.Core.CharacterFilter.LoginComplete -= p.CharacterFilter_LoginComplete;
                p.Core.CharacterFilter.Logoff -= p.CharacterFilter_Logoff;
                p.Core.ChatBoxMessage -= p.Current_ChatBoxMessage;
                p.Core.CommandLineText -= p.Core_CommandLineText;
            }
            catch { }
            try { MyClasses.MetaViewWrappers.UBHudControls.WindowMemory.Flush(); } catch { }
            p.Shutdown();
        }
#else
    [WireUpBaseEvents]
    [MVView("MelksQuestTracker.mainView.xml")]
    [MVWireUpControlEvents]
    [FriendlyName("MelksQuestTracker")]
    public class PluginCore : PluginBase
    {
#endif
        public static PluginCore Instance;
        internal static Decal.Adapter.Wrappers.PluginHost MyHost;

        private const int DETAIL_NOTES_LINES = 3;
        private const int DETAIL_NOTES_WIDTH = 52; // approx. characters that fit across the detail panel
        // Plain hyphens rather than a box-drawing character - safer bet for whatever font
        // the game client's chat/UI renderer is using. Sized to roughly match the row width.
        private const double version = 1.0;

        // ---- config (persisted) ----
        private int cooldownSeconds = 60;
        private int debounceMs = 2500;
        private int myQuestsIdleMs = 5000;   // /myquests: done once no line has come for this long
        private bool enbDebug = false;

        // ---- runtime state ----
        private bool isinitialized = false;
        private string characterKey = "";
        private string configPath = "";
        private string progressPath = "";
        private string questDbPath = "";

        private bool capturing = false;
        private bool sawIncompleteMarker = false;
        private Dictionary<string, FlagState> sessionCaptured =
            new Dictionary<string, FlagState>(StringComparer.OrdinalIgnoreCase);
        private DateTime lastCollectTime = DateTime.MinValue;
        // Both run off the game's frame (Frame_Render), not System.Timers - those fire on a background
        // thread, and changing the window from there can crash the client.
        private DateTime captureDeadline = DateTime.MaxValue;   // when the /qb list capture is considered done
        private DateTime nextUiTick = DateTime.MinValue;        // once-a-second UI refresh

        // ---- Main tab state ----
        private List<QuestDefinition> filteredQuests = new List<QuestDefinition>();
        private string mainSearchText = "";
        private int sortMode = 4; // 0 = % asc, 1 = % desc, 2 = name, 3 = remaining desc, 4 = cooldown (the default)
        // the Main page's sorts in the order the Sort button steps through them (the first ticked one is shown at login),
        // and the ones turned off - set on the Config page
        private List<int> sortList = new List<int> { 4, 0, 1, 2, 3 };
        private readonly HashSet<int> sortOff = new HashSet<int>();
        [MVControlReference("lstSortOrder")] private IList lstSortOrder = null;

        private static string SortName(int m)
        {
            switch (m)
            {
                case 0: return "% complete, lowest first";
                case 1: return "% complete, highest first";
                case 2: return "Name";
                case 3: return "Most QB left first";
                case 4: return "Cooldown (CD)";
                default: return "?";
            }
        }

        private int FirstSort()
        {
            foreach (int m in sortList) if (!sortOff.Contains(m)) return m;
            return sortMode;
        }

        private int NextSort()
        {
            List<int> on = sortList.FindAll(m => !sortOff.Contains(m));
            if (on.Count == 0) return sortMode;
            int i = on.IndexOf(sortMode);
            return on[(i + 1) % on.Count];
        }

        private void RenderSortOrder()
        {
            if (lstSortOrder == null) return;
            try
            {
                lstSortOrder.Clear();
                int first = FirstSort();
                foreach (int m in sortList)
                {
                    IListRow row = lstSortOrder.AddRow();
                    bool on = !sortOff.Contains(m);
                    row[0][0] = on;
                    row[1][0] = SortName(m) + (on && m == first ? "  (first)" : "");
                    row[1][1] = on ? (m == first ? System.Drawing.Color.Gold : System.Drawing.Color.White) : System.Drawing.Color.Gray;
                    row[2][0] = "Up";
                    row[3][0] = "Down";
                    row[2][1] = row[3][1] = System.Drawing.Color.SkyBlue;
                }
            }
            catch (Exception ex) { Util.LogError(ex); }
        }

        private void SortOrderClicked(int row, int col)
        {
            if (row < 0 || row >= sortList.Count) return;
            int m = sortList[row];
            if (col == 0)
            {
                if (sortOff.Contains(m)) sortOff.Remove(m);
                else if (sortList.Count - sortOff.Count > 1) sortOff.Add(m);   // (one stays on)
            }
            else if (col == 2 && row > 0) { sortList.RemoveAt(row); sortList.Insert(row - 1, m); }
            else if (col == 3 && row < sortList.Count - 1) { sortList.RemoveAt(row); sortList.Insert(row + 1, m); }
            else return;
            // (the one showing now turned off: the first one on instead)
            if (sortOff.Contains(sortMode)) { sortMode = FirstSort(); sortBtn.Text = "Sort: " + SortModeLabel(); ApplyMainFilterSort(); }
            RenderSortOrder();
            SaveSettings();
        }
        // MyQuests tab
        [MVControlReference("mqSearch")] private ITextBox mqSearch = null;
        [MVControlReference("mqClearBtn")] private IButton mqClearBtn = null;
        [MVControlReference("mqSortBtn")] private IButton mqSortBtn = null;
        [MVControlReference("mqAllBtn")] private IButton mqAllBtn = null;
        private bool mqAllChars;                                         // MyQuests: every character's repeat timers
        private List<ServerTimer> mqShownT = new List<ServerTimer>();   // the timer behind each shown row
        [MVControlReference("mqRefreshBtn")] private IButton mqRefreshBtn = null;
        [MVControlReference("mqInfoLbl")] private IStaticText mqInfoLbl = null;
        [MVControlReference("lstMyQuests")] private IList lstMyQuests = null;
        private List<string> mqShown = new List<string>();
        private bool mqSortByName, mqSearchDirty;
        private string mqNeedle = "";
        private DateTime mqTimersAt = DateTime.MinValue;

        // ---- Quest detail panel (right side of Main tab) ----
        private QuestDefinition selectedQuest = null;
        private List<string> detailFlags = new List<string>();

        // ---- Current QB tab state ----
        private class FlagRowData
        {
            public string Flag;
            public FlagState? State;
            public string QuestName;
        }
        private List<FlagRowData> filteredFlagRows = new List<FlagRowData>();
        private string flagFilterText = "";
        private int flagFilterMode = 0; // 0=All 1=Completed 2=InProgress 3=NotStarted

        // ---- controls: Main tab ----
        [MVControlReference("searchInput")] private ITextBox searchInput = null;
        [MVControlReference("searchBtn")] private IButton searchBtn = null;
        [MVControlReference("sortBtn")] private IButton sortBtn = null;
        [MVControlReference("clearFilterBtn")] private IButton clearFilterBtn = null;
        [MVControlReference("pageInfoLabel")] private IStaticText pageInfoLabel = null;
        [MVControlReference("legendLabel")] private IStaticText legendLabel = null;
        [MVControlReference("lstQuests")] private IList lstQuests = null;
        [MVControlReference("lstFlags")] private IList lstFlags = null;
        [MVControlReference("lstDetailFlags")] private IList lstDetailFlags = null;
        [MVControlReference("detailBadgesLabel")] private IStaticText detailBadgesLabel = null;

        // lstQuests columns
        private const int QCOL_PCT = 0, QCOL_QB = 1, QCOL_NAME = 2, QCOL_WIKI = 3;





        // ---- controls: Current QB tab ----
        [MVControlReference("collectBtn")] private IButton collectBtn = null;
        [MVControlReference("copyClipboardBtn")] private IButton copyClipboardBtn = null;
        [MVControlReference("lastCollectedLabel")] private IStaticText lastCollectedLabel = null;
        [MVControlReference("summaryLabel")] private IStaticText summaryLabel = null;
        [MVControlReference("flagFilterInput")] private ITextBox flagFilterInput = null;
        [MVControlReference("flagFilterBtn")] private IButton flagFilterBtn = null;
        [MVControlReference("flagFilterModeBtn")] private IButton flagFilterModeBtn = null;
        [MVControlReference("flagFilterClearBtn")] private IButton flagFilterClearBtn = null;
        [MVControlReference("flagPageInfoLabel")] private IStaticText flagPageInfoLabel = null;


        // ---- controls: Main tab quest-detail panel (right side) ----
        [MVControlReference("detailHeaderLabel")] private IStaticText detailHeaderLabel = null;
        [MVControlReference("detailProgressLabel")] private IStaticText detailProgressLabel = null;
        [MVControlReference("detailGiverLabel")] private IStaticText detailGiverLabel = null;
        [MVControlReference("detailNotesLabel0")] private IStaticText detailNotesLabel0 = null;
        [MVControlReference("detailNotesLabel1")] private IStaticText detailNotesLabel1 = null;
        [MVControlReference("detailNotesLabel2")] private IStaticText detailNotesLabel2 = null;
        private IStaticText[] detailNotesLabels;
        [MVControlReference("detailPageInfoLabel")] private IStaticText detailPageInfoLabel = null;
        [MVControlReference("detailClearBtn")] private IButton detailClearBtn = null;


        // ---- Main tab: "Can do now" filter, quest timers ----
        [MVControlReference("canDoBtn")] private IButton canDoBtn = null;
        [MVControlReference("detailTimerBtn")] private IButton detailTimerBtn = null;
        [MVControlReference("detailWikiBtn")] private IButton detailWikiBtn = null;
        [MVControlReference("detailQuestBtn")] private IButton detailQuestBtn = null;
        [MVControlReference("questFindInput")] private ITextBox questFindInput = null;
        [MVControlReference("questFindBtn")] private IButton questFindBtn = null;
        [MVControlReference("questFindClearBtn")] private IButton questFindClearBtn = null;
        [MVControlReference("questUseSelBtn")] private IButton questUseSelBtn = null;
        [MVControlReference("lstQuestFind")] private IList lstQuestFind = null;
        [MVControlReference("editWikiBtn")] private IButton editWikiBtn = null;
        private List<QuestDefinition> questFindResults = new List<QuestDefinition>();
        [MVControlReference("detailMainTimerBtn")] private IButton detailMainTimerBtn = null;
        private string selectedDetailFlag = null;
        private bool canDoOnly = false;
        private readonly HashSet<string> timerAnnounced = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private DateTime nextTimerRefresh = DateTime.MinValue;

        // ---- controls: Review tab ----
        /* not in the view any more */ private IList lstReview = null;
        /* not in the view any more */ private IStaticText reviewBucketLabel = null;
        /* not in the view any more */ private IList lstReviewFlags = null;
        /* not in the view any more */ private ITextBox reviewFindInput = null;
        /* not in the view any more */ private IButton reviewFindBtn = null;
        /* not in the view any more */ private IList lstReviewTargets = null;
        /* not in the view any more */ private IStaticText reviewTargetLabel = null;
        /* not in the view any more */ private IButton reviewMoveBtn = null;
        /* not in the view any more */ private IStaticText reviewStatusLabel = null;
        private List<QuestDefinition> reviewBuckets = new List<QuestDefinition>();
        private List<QuestDefinition> reviewTargets = new List<QuestDefinition>();
        private QuestDefinition reviewBucket = null, reviewTarget = null;
        [MVControlReference("nbMain")] private INotebook nbMain = null;
        /* not in the view any more */ private IButton reviewNewQuestBtn = null;
        private const int EDIT_TAB = 2;   // Main, Quest, Edit Quest, Search, Current QB, MyQuests, Tracking, Config
        private const int QUEST_TAB = 1;
        // Set when the editor was filled from a [REVIEW] group: on Save of the new quest these flags leave that group.
        private string editFromReviewGroup = null;
        private List<string> editFromReviewFlags = null;
        private bool questDbBackedUp = false;

        // ---- controls: Edit Quest tab (and the Repeatable filter) ----
        [MVControlReference("editFindInput")] private ITextBox editFindInput = null;
        [MVControlReference("editName")] private ITextBox editName = null;
        [MVControlReference("editLink")] private ITextBox editLink = null;
        [MVControlReference("editTown")] private ITextBox editTown = null;
        [MVControlReference("editGiver")] private ITextBox editGiver = null;
        [MVControlReference("editQb")] private ITextBox editQb = null;
        [MVControlReference("editMinLvl")] private ITextBox editMinLvl = null;
        [MVControlReference("editRecLvl")] private ITextBox editRecLvl = null;
        [MVControlReference("editTime")] private ITextBox editTime = null;
        [MVControlReference("editRepeatNote")] private ITextBox editRepeatNote = null;
        [MVControlReference("editCooldown")] private ITextBox editCooldown = null;
        [MVControlReference("editNotes")] private ITextBox editNotes = null;
        [MVControlReference("editFindClearBtn")] private IButton editFindClearBtn = null;
        [MVControlReference("editKtMobs")] private ITextBox editKtMobs = null;
        [MVControlReference("editCollect")] private ITextBox editCollect = null;
        [MVControlReference("editTurnIn")] private ITextBox editTurnIn = null;
        [MVControlReference("editFlagInput")] private ITextBox editFlagInput = null;
        [MVControlReference("editRepeatable")] private ICheckBox editRepeatable = null;
        [MVControlReference("editLockpick")] private ICheckBox editLockpick = null;
        [MVControlReference("editFellow")] private ICheckBox editFellow = null;
        [MVControlReference("editAce")] private ICheckBox editAce = null;
        [MVControlReference("editOptional")] private ICheckBox editOptional = null;
        /* not in the view any more */ private ICheckBox editReview = null;
        [MVControlReference("editFindBtn")] private IButton editFindBtn = null;
        [MVControlReference("editNewBtn")] private IButton editNewBtn = null;
        [MVControlReference("editUseSelBtn")] private IButton editUseSelBtn = null;
        [MVControlReference("editOpenBtn")] private IButton editOpenBtn = null;
        [MVControlReference("editTownHereBtn")] private IButton editTownHereBtn = null;
        [MVControlReference("editGiverSelBtn")] private IButton editGiverSelBtn = null;
        [MVControlReference("editKtSelBtn")] private IButton editKtSelBtn = null;
        [MVControlReference("editCollectSelBtn")] private IButton editCollectSelBtn = null;
        [MVControlReference("editFlagAddBtn")] private IButton editFlagAddBtn = null;
        [MVControlReference("editFlagRemoveBtn")] private IButton editFlagRemoveBtn = null;
        [MVControlReference("editSaveBtn")] private IButton editSaveBtn = null;
        [MVControlReference("editDeleteBtn")] private IButton editDeleteBtn = null;
        [MVControlReference("repeatBtn")] private IButton repeatBtn = null;
        [MVControlReference("editHeaderLbl")] private IStaticText editHeaderLbl = null;
        [MVControlReference("editStatusLabel")] private IStaticText editStatusLabel = null;
        [MVControlReference("lstEditFind")] private IList lstEditFind = null;
        [MVControlReference("lstEditFlags")] private IList lstEditFlags = null;
        [MVControlReference("newFlagsLbl")] private IStaticText newFlagsLbl = null;
        [MVControlReference("lstNewFlags")] private IList lstNewFlags = null;
        [MVControlReference("newFlagsAddBtn")] private IButton newFlagsAddBtn = null;
        [MVControlReference("newFlagsForgetBtn")] private IButton newFlagsForgetBtn = null;
        private List<string> newFlagsShown = new List<string>();
        private bool newFlagsKtOnly;
        private DateTime newFlagsTimersAt = DateTime.MinValue;
        [MVControlReference("newFlagsKtChk")] private ICheckBox newFlagsKtChk = null;
        [MVControlReference("newFlagsSearch")] private ITextBox newFlagsSearch = null;
        [MVControlReference("newFlagsSearchClear")] private IButton newFlagsSearchClear = null;
        private string newFlagsNeedle = "";
        private bool newFlagsSearchDirty;
        [MVControlReference("editFlagMoveBtn")] private IButton editFlagMoveBtn = null;
        private HashSet<string> newFlagsJustMoved = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        // /myquests (the server's quest timers - what UtilityBelt reads): asked quietly after each QB collect.
        private DateTime myQuestsUntil = DateTime.MinValue;
        private bool myQuestsQuiet, myQuestsDirty;
        private int myQuestsRead;
        private DateTime myQuestsLastLine = DateTime.MinValue;
        private bool myQuestsSelf;
        private DateTime myQuestsSelfAt = DateTime.MinValue;

        /// <summary>The debug log switch (Options > Plugins > Debug in ACGodot): saved like the Config tab's box.</summary>
        public bool DebugOn
        {
            get => enbDebug;
            set { enbDebug = value; try { if (debugModeBtn != null) debugModeBtn.Checked = value; } catch { } SaveSettings(); }
        }

        /// <summary>Debug Logging: to MQT_Debug.txt (not chat).</summary>
        private void DebugLog(string s)
        {
            if (!enbDebug) return;
            try { System.IO.File.AppendAllText(Util.FullPath("MQT_Debug.txt"), DateTime.Now.ToString("HH:mm:ss.fff") + "  " + s + "\r\n"); } catch { }
        }
        private static readonly System.Text.RegularExpressions.Regex MyQuestRx = new System.Text.RegularExpressions.Regex(
            @"^(?<key>\S+) - (?<solves>\d+) solves \((?<completed>\d{0,11})\)""?(?:(?<desc>.*)"" (?<max>-?\d+) (?<repeat>-?\d+))?");

        // /qb list's lines all come in one chat colour (green). Learned from the known flags; -1 = not known yet.
        private int qbFlagColor = -1;
        private Dictionary<int, int> captureColors = new Dictionary<int, int>();
        private List<KeyValuePair<string, KeyValuePair<FlagState, int>>> captureUnknown = new List<KeyValuePair<string, KeyValuePair<FlagState, int>>>();

        private bool repeatOnly = false;
        private List<QuestDefinition> editFindResults = new List<QuestDefinition>();
        private string editOrigName = null;          // the quest being edited (null = a new one)
        private List<string> editFlags = new List<string>();
        private DateTime editDeleteArmedUntil = DateTime.MinValue;

        // ---- controls: Bounty tab ----
        private bool bountyShowKts = true;   // off: no kill tasks on the pop-up, whatever the KTs tab has ticked

        // ---- Bounty (was the MelksBounty plugin) ----
        private BountyTracker bountyTracker;
        private BountyHud bountyHud;
        private bool bountyHudOn = true;
        private int bountyMinutes = 1;
        private int bountyShownVersion = -1;
        private DateTime bountyStatusAt = DateTime.MinValue;

        // ---- controls: Config tab ----
        [MVControlReference("cooldownInput")] private ITextBox cooldownInput = null;
        [MVControlReference("debounceInput")] private ITextBox debounceInput = null;
        [MVControlReference("mqTimeInput")] private ITextBox mqTimeInput = null;
        [MVControlReference("applyConfigBtn")] private IButton applyConfigBtn = null;
        [MVControlReference("debugModeBtn")] private ICheckBox debugModeBtn = null;
        [MVControlReference("travelRouteChk")] private ICheckBox travelRouteChk = null;
        [MVControlReference("travelLinksChk")] private ICheckBox travelLinksChk = null;
        [MVControlReference("travelArrowCombo")] private ICombo travelArrowCombo = null;
        [MVControlReference("travelFightChk")] private ICheckBox travelFightChk = null;
        private bool travelFight = true;
        [MVControlReference("dungeonMapChk")] private ICheckBox dungeonMapChk = null;
        [MVControlReference("serverCombo")] private ICombo serverCombo = null;
        [MVControlReference("myQuestsChk")] private ICheckBox myQuestsChk = null;
        private bool dungeonMaps = true;
        private bool travelRoute = true, travelLinks = true;
        private int travelArrow = 0;
        [MVControlReference("dbPathLabel")] private IStaticText dbPathLabel = null;
        [MVControlReference("buildLabel")] private IStaticText buildLabel = null;
        [MVControlReference("reloadDbBtn")] private IButton reloadDbBtn = null;
        [MVControlReference("resetProgressBtn")] private IButton resetProgressBtn = null;

#if HOTCORE
        protected void Startup()
#else
        protected override void Startup()
#endif
        {
            try
            {
                MyHost = Host;
                Globals.Init("MelksQuestTracker", Host, Core);
                MVWireupHelper.WireupStart(this, Host);
                Instance = this;

                detailNotesLabels = new IStaticText[] { detailNotesLabel0, detailNotesLabel1, detailNotesLabel2 };

                // Scrolling lists: click a quest to see its flags, click "wiki" to open its page.
                lstQuests.Click += (sender, row, col) => OnQuestListClick(row, col);

                detailClearBtn.Click += (s, e) => { selectedQuest = null; RenderDetailPanel(); };

                searchBtn.Click += (s, e) => { mainSearchText = SafeText(searchInput); ApplyMainFilterSort(); };
                searchInput.End += (s, e) => { mainSearchText = SafeText(searchInput); ApplyMainFilterSort(); };
                clearFilterBtn.Click += (s, e) => { mainSearchText = ""; searchInput.Text = ""; ApplyMainFilterSort(); };
                sortBtn.Click += (s, e) => { sortMode = NextSort(); sortBtn.Text = "Sort: " + SortModeLabel(); ApplyMainFilterSort(); };
                if (lstSortOrder != null) lstSortOrder.Click += (s, row, col) => SortOrderClicked(row, col);

                collectBtn.Click += (s, e) => TryCollect();
                copyClipboardBtn.Click += (s, e) => DoCopyToClipboard();
                flagFilterBtn.Click += (s, e) => { flagFilterText = SafeText(flagFilterInput); ApplyFlagFilter(); };
                flagFilterInput.End += (s, e) => { flagFilterText = SafeText(flagFilterInput); ApplyFlagFilter(); };
                flagFilterModeBtn.Click += (s, e) => { flagFilterMode = (flagFilterMode + 1) % 4; flagFilterModeBtn.Text = "Show: " + FlagFilterLabel(); ApplyFlagFilter(); };
                flagFilterClearBtn.Click += (s, e) => { flagFilterText = ""; flagFilterInput.Text = ""; ApplyFlagFilter(); };
                // a row's quest (when the flag belongs to one): opened on the Quest tab
                lstFlags.Click += (s, row, col) =>
                {
                    try
                    {
                        if (row < 0 || row >= filteredFlagRows.Count) return;
                        List<QuestDefinition> owners;
                        if (!QuestDatabase.FlagToQuests.TryGetValue(filteredFlagRows[row].Flag, out owners) || owners.Count == 0) return;
                        OpenQuestTab(owners[0]);
                    }
                    catch (Exception ex) { Util.LogError(ex); }
                };

                applyConfigBtn.Click += (s, e) => ApplyConfigFromUI(true);
                reloadDbBtn.Click += (s, e) => { QuestDatabase.Load(questDbPath); QuestDatabase.RecalculateProgress(); selectedQuest = null; reviewBucket = null; reviewTarget = null; RenderReviewList(); ApplyMainFilterSort(); ApplyFlagFilter(); RenderDetailPanel(); };
                resetProgressBtn.Click += (s, e) => DoResetProgress();

                canDoBtn.Click += (s, e) =>
                {
                    canDoOnly = !canDoOnly;
                    canDoBtn.Text = canDoOnly ? "Can do now: ON" : "Can do now: off";
                    if (canDoOnly) { sortMode = 3; sortBtn.Text = "Sort: " + SortModeLabel(); }   // most QB left first
                    ApplyMainFilterSort();
                };
                detailTimerBtn.Click += (s, e) => ToggleQuestTimer();
                lstDetailFlags.Click += (s, row, col) =>
                {
                    if (row < 0 || row >= detailFlags.Count) return;
                    selectedDetailFlag = detailFlags[row];
                    RenderDetailPanel();
                };
                detailMainTimerBtn.Click += (s, e) => SetMainTimerFlag();

                // Quest tab: the quest's info and walkthrough, like the wiki
                CustomDraw.Areas["questView"] = QuestPage.Draw;
                CustomDraw.Areas["editWikiArea"] = WikiEditor.Draw;
                QuestPage.Edit = q => { LoadEditor(q.Name); nbMain.ActiveTab = EDIT_TAB; };
                CustomDraw.Areas["searchView"] = QuestSearch.Draw;
                CustomDraw.Areas["travelView"] = Travel.TravelPage.Draw;
                if (travelRouteChk != null) travelRouteChk.Change += (s, e) => { travelRoute = travelRouteChk.Checked; Travel.Travel.RouteMode = travelRoute; SaveSettings(); };
                if (travelLinksChk != null) travelLinksChk.Change += (s, e) => { travelLinks = travelLinksChk.Checked; Travel.Travel.LinkChat = travelLinks; SaveSettings(); };
                if (dungeonMapChk != null) dungeonMapChk.Change += (s, e) => { dungeonMaps = dungeonMapChk.Checked; Travel.DungeonView.AutoOpen = dungeonMaps; SaveSettings(); };
                if (travelFightChk != null) travelFightChk.Change += (s, e) => { travelFight = travelFightChk.Checked; Travel.AutoTravel.FightOnTheWay = travelFight; SaveSettings(); };
                if (serverCombo != null)
                {
                    serverCombo.Add("Auto (by the server's name)");
                    serverCombo.Add("Infinite Leaftide");
                    serverCombo.Add("Standard (other servers)");
                    serverCombo.Selected = 0;
                    serverCombo.Change += (s, e) => { ServerMode.Kind = Math.Max(0, serverCombo.Selected); SaveSettings(); RenderDetailPanel(); };
                }
                if (myQuestsChk != null) myQuestsChk.Change += (s, e) => { ServerMode.MyQuests = myQuestsChk.Checked; SaveSettings(); };
                MyClasses.MetaViewWrappers.UBHudControls.Notebook.HidePage = label => (label == "Current QB" && !ServerMode.Ilt) || (label == "MyQuests" && !ServerMode.MyQuests);
                CustomDraw.Areas["detailInfoView"] = (w, h) => { if (!ServerMode.Ilt) QuestPage.Header(selectedQuest, w, h); };
                if (travelArrowCombo != null)
                {
                    travelArrowCombo.Add("On screen - the travel window (drag it anywhere)");
                    travelArrowCombo.Add("3D arrow in the game (the window only for steps to do)");
                    travelArrowCombo.Add("Both");
                    travelArrowCombo.Selected = 0;
                    travelArrowCombo.Change += (s, e) =>
                    {
                        travelArrow = Math.Max(0, travelArrowCombo.Selected);
                        Travel.Travel.ArrowStyle = travelArrow;
                        if (Travel.Travel.Active && travelArrow != 1) Travel.TravelHud.Show();
                        if (Travel.Travel.Active && travelArrow == 1) Travel.TravelHud.Hide();
                        SaveSettings();
                    };
                }
                QuestSearch.Open = q => OpenQuestTab(q);
                QuestSearch.Edit = q => QuestPage.Edit(q);
                QuestPage.CopyWiki = q =>
                {
                    if (string.IsNullOrEmpty(q.WikiLink)) { Util.WriteToChat("No wiki link for this quest."); return; }
                    Util.WriteToChat(Util.SetClipboardText(q.WikiLink) ? "Copied: " + q.WikiLink : "Couldn't copy to the clipboard.");
                };
                WikiView.OpenQuest = q => OpenQuestTab(q);
                WikiView.QuestFor = QuestForLink;
                detailQuestBtn.Click += (s, e) =>
                {
                    if (selectedQuest == null) { Util.WriteToChat("Click a quest first."); return; }
                    OpenQuestTab(selectedQuest);
                };
                questFindBtn.Click += (s, e) => RunQuestFind();
                questFindInput.End += (s, e) => RunQuestFind();
                questFindClearBtn.Click += (s, e) => { questFindInput.Text = ""; RunQuestFind(); };
                lstQuestFind.Click += (s, row, col) => { if (row >= 0 && row < questFindResults.Count) { QuestPage.Navigate(questFindResults[row]); RunQuestFind(); } };
                questUseSelBtn.Click += (s, e) =>
                {
                    if (selectedQuest == null) { Util.WriteToChat("Click a quest on the Main tab first."); return; }
                    OpenQuestTab(selectedQuest);
                };
                editWikiBtn.Click += (s, e) => { WikiEditor.QuestName = SafeText(editName).Trim(); WikiEditor.Open = true; };
                // the walkthrough window's Auto-fill: the template from what the editor has now (filling in, never removing)
                WikiEditor.AutoFill = text => WikiEditor.ToEdit(AutoWiki(WikiEditor.ToStored(text ?? "").Trim(), EditorValues(), editFlags, true));
                RunQuestFind();
                detailWikiBtn.Click += (s, e) =>
                {
                    if (selectedQuest == null || string.IsNullOrEmpty(selectedQuest.WikiLink)) { Util.WriteToChat("No wiki link for this quest."); return; }
                    Util.WriteToChat(Util.SetClipboardText(selectedQuest.WikiLink) ? "Copied: " + selectedQuest.WikiLink : "Couldn't copy to the clipboard.");
                };

                repeatBtn.Click += (s, e) =>
                {
                    repeatOnly = !repeatOnly;
                    repeatBtn.Text = repeatOnly ? "Repeatable: ON" : "Repeatable: off";
                    ApplyMainFilterSort();
                };

                editFindBtn.Click += (s, e) => RunEditFind();
                editFindInput.End += (s, e) => RunEditFind();
                lstEditFind.Click += (s, row, col) => { if (row >= 0 && row < editFindResults.Count) LoadEditor(editFindResults[row].Name); };
                editNewBtn.Click += (s, e) => LoadEditor(null);
                editFindClearBtn.Click += (s, e) => { editFindInput.Text = ""; RunEditFind(); };
                editUseSelBtn.Click += (s, e) =>
                {
                    if (selectedQuest == null) { editStatusLabel.Text = "Click a quest on the Main tab first."; return; }
                    if (selectedQuest.Unregistered) { LoadEditorFromKillTask(selectedQuest); return; }
                    LoadEditor(selectedQuest.Name);
                };
                // the quest being edited, on the Quest tab
                if (editOpenBtn != null) editOpenBtn.Click += (s, e) =>
                {
                    string n = SafeText(editName).Trim();
                    QuestDefinition q = QuestDatabase.Quests.Find(x => string.Equals(x.Name, n, StringComparison.OrdinalIgnoreCase));
                    if (q == null) { editStatusLabel.Text = n.Length == 0 ? "No quest loaded." : "\"" + n + "\" isn't saved yet - save it first."; return; }
                    OpenQuestTab(q);
                };
                // the NPC you have selected as the quest giver; where you are as the start town
                if (editGiverSelBtn != null) editGiverSelBtn.Click += (s, e) => { string n = SelectedName(false); if (n != null) editGiver.Text = n; };
                if (editTownHereBtn != null) editTownHereBtn.Click += (s, e) => { string t = HereName(); if (t.Length > 0) editTown.Text = t; else editStatusLabel.Text = "Couldn't tell where you are."; };
                // the selected monster / item added to the KT mobs / items (comma separated, once each)
                if (editKtSelBtn != null) editKtSelBtn.Click += (s, e) => { string n = SelectedName(false); if (n != null) editKtMobs.Text = AddToList(SafeText(editKtMobs), n); };
                if (editCollectSelBtn != null) editCollectSelBtn.Click += (s, e) => { string n = SelectedName(true); if (n != null) editCollect.Text = AddToList(SafeText(editCollect), n); };
                editFlagAddBtn.Click += (s, e) => AddEditFlags();
                editFlagInput.End += (s, e) => AddEditFlags();
                editFlagRemoveBtn.Click += (s, e) => RemoveTickedEditFlags();
                editFlagMoveBtn.Click += (s, e) => MoveTickedToNewFlags();
                editSaveBtn.Click += (s, e) => SaveEditor();
                newFlagsAddBtn.Click += (s, e) => AddTickedNewFlags();
                newFlagsForgetBtn.Click += (s, e) => ForgetTickedNewFlags();
                newFlagsKtChk.Change += (s, e) => { newFlagsKtOnly = newFlagsKtChk.Checked; RenderNewFlags(); };
                // Filters as you type (the list is rebuilt on the next frame, not inside the text box's own drawing).
                newFlagsSearch.Change += (s, e) => newFlagsSearchDirty = true;
                newFlagsSearch.End += (s, e) => newFlagsSearchDirty = true;
                newFlagsSearchClear.Click += (s, e) => { newFlagsSearch.Text = ""; newFlagsSearchDirty = true; };
                editDeleteBtn.Click += (s, e) => DeleteEditorQuest();

                // the Review tab is gone (Nov 8) - its controls aren't in the view any more
                if (lstReview != null)
                {
                    lstReview.Click += (s, row, col) => OnReviewBucketClick(row);
                    lstReviewTargets.Click += (s, row, col) => OnReviewTargetClick(row);
                    reviewFindBtn.Click += (s, e) => RunReviewFind();
                    reviewFindInput.End += (s, e) => RunReviewFind();
                    reviewMoveBtn.Click += (s, e) => MoveReviewFlags();
                    reviewNewQuestBtn.Click += (s, e) => NewQuestFromReview();
                }
                lstKtSession.Click += (s, row, col) => OnKtSessionClick(row, col);
                lstKtRepeat.Click += (s, row, col) => OnKtRepeatClick(row, col);

                mqSearch.Change += (s, e) => mqSearchDirty = true;
                mqSearch.End += (s, e) => mqSearchDirty = true;
                mqClearBtn.Click += (s, e) => { mqSearch.Text = ""; mqSearchDirty = true; };
                mqSortBtn.Click += (s, e) => { mqSortByName = !mqSortByName; mqSortBtn.Text = mqSortByName ? "Sort: Name" : "Sort: Cooldown"; RenderMyQuests(); };
                if (mqAllBtn != null) mqAllBtn.Click += (s, e) => { mqAllChars = !mqAllChars; mqAllBtn.Text = mqAllChars ? "All characters" : "This character"; RenderMyQuests(); };
                mqRefreshBtn.Click += (s, e) => { AskMyQuests(); mqInfoLbl.Text = "Reading /myquests..."; };

            }
            catch (Exception ex) { Util.WriteToChat($"Startup Error: {ex}"); }
        }

#if HOTCORE
        protected void Shutdown()
#else
        protected override void Shutdown()
#endif
        {
            try
            {
                StopBounty();
                try { Travel.Travel.Stop(); } catch { }
                try { MapView.Dispose(); } catch { }
                MVWireupHelper.WireupEnd(this);
                Instance = null;
            }
            catch (Exception ex) { Util.WriteToChat($"Shutdown Error: {ex}"); }
        }

        [BaseEvent("LoginComplete", "CharacterFilter")]
        private void CharacterFilter_LoginComplete(object sender, EventArgs e)
        {
            try
            {
                Util.WriteToChat($"Melks Quest Tracker {BuildInfo.Label} Started - type /mqt help for commands");
                characterKey = $"{CoreManager.Current.CharacterFilter.Server}-{CoreManager.Current.CharacterFilter.Name}";
                configPath = Util.FullPath("MQT_Settings.xml");
                progressPath = Util.FullPath("MQT_Progress.xml");
                questDbPath = Util.FullPath("QuestDatabase.xml");

                LoadSettings();
                QuestPage.PinsChanged = () => { SaveSettings(); RunQuestFind(); };
                QuestDatabase.Load(questDbPath);
                ProgressStore.Load(progressPath, characterKey);
                NewFlagStore.Load(Util.FullPath("MQT_NewFlags.xml"));
                QuestDatabase.RecalculateProgress();

                dbPathLabel.Text = $"Quest database file:\n{questDbPath}";
                if (buildLabel != null) buildLabel.Text = "Build: " + BuildInfo.Label;
                sortMode = FirstSort();
                RenderSortOrder();
                sortBtn.Text = "Sort: " + SortModeLabel();
                flagFilterModeBtn.Text = "Show: " + FlagFilterLabel();
                cooldownInput.Text = cooldownSeconds.ToString();
                debounceInput.Text = debounceMs.ToString();
                if (mqTimeInput != null) mqTimeInput.Text = myQuestsIdleMs.ToString();
                debugModeBtn.Checked = enbDebug;
                if (travelRouteChk != null) travelRouteChk.Checked = travelRoute;
                if (travelLinksChk != null) travelLinksChk.Checked = travelLinks;
                Travel.Travel.RouteMode = travelRoute;
                Travel.Travel.LinkChat = travelLinks;
                Travel.Travel.ArrowStyle = travelArrow;
                if (travelArrowCombo != null) travelArrowCombo.Selected = travelArrow;
                if (serverCombo != null) serverCombo.Selected = ServerMode.Kind;
                if (myQuestsChk != null) myQuestsChk.Checked = ServerMode.MyQuests;
                Travel.AutoTravel.FightOnTheWay = travelFight;
                if (travelFightChk != null) travelFightChk.Checked = travelFight;
                Travel.DungeonView.AutoOpen = dungeonMaps;
                if (dungeonMapChk != null) dungeonMapChk.Checked = dungeonMaps;
                try { Travel.Travel.Start(characterKey); } catch (Exception tex) { Util.LogError(tex); }


                // Bounties moved to MelkTank (Session > Bounties); its pop-up shows the kill tasks from PopupKtLines.
                CoreManager.Current.RenderFrame += Frame_Render;

                isinitialized = true;
                RenderReviewList();
                RenderMyQuests();
                RenderKillTasks();
                LoadEditor(null);
                ApplyMainFilterSort();
                ApplyFlagFilter();
                RenderDetailPanel();
                UpdateSummaryLabels();
            }
            catch (Exception ex) { Util.WriteToChat($"CharacterFilter_LoginComplete Error: {ex}"); }
        }

        [BaseEvent("Logoff", "CharacterFilter")]
        private void CharacterFilter_Logoff(object sender, Decal.Adapter.Wrappers.LogoffEventArgs e)
        {
            try
            {
                captureDeadline = DateTime.MaxValue;
                StopBounty();
                try { Travel.TravelData.Flush(); } catch { }
            }
            catch (Exception ex) { Util.WriteToChat($"CharacterFilter_Logoff Error: {ex}"); }
        }

        // ===================== Settings =====================

        // ===================== KTs tab =====================

        [MVControlReference("lstKtSession")] private IList lstKtSession = null;
        [MVControlReference("lstKtRepeat")] private IList lstKtRepeat = null;
        [MVControlReference("ktSessionLbl")] private IStaticText ktSessionLbl = null;
        private readonly List<KillTask> ktSession = new List<KillTask>();   // seen in chat this session, newest first
        private readonly List<KillTask> ktRepeat = new List<KillTask>();    // the ones you're repeating (saved)
        private readonly Dictionary<string, string> ktQuestCache = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        private bool ktDirty;
        private DateTime ktAgesAt = DateTime.MinValue;

        private static KillTask FindKt(List<KillTask> l, string name)
        {
            foreach (KillTask k in l) if (string.Equals(k.Name, name, StringComparison.OrdinalIgnoreCase)) return k;
            return null;
        }

        /// <summary>"You have killed 10 Snow Tusker Warriors! You must kill 20 ..." (yours or a fellow's kill): update the counts.</summary>
        private static readonly System.Text.RegularExpressions.Regex GivesYouRx =
            new System.Text.RegularExpressions.Regex(@"^(?<npc>.+?) gives you (?<item>.+?)\.?$");
        private DateTime myQuestsAskAt = DateTime.MaxValue;

        /// <summary>
        /// "Watch Warden Hama gives you Prestige Coin." - a reward from the giver of one of your kill task quests
        /// (its Quest giver on the Edit Quest tab) means that task was just turned in: its count goes back to 0 and it
        /// drops off the bounty pop-up until your next kill. (/myquests isn't asked - its timer comes with the next read.)
        /// </summary>
        private void OnKillTaskTurnIn(string text)
        {
            OnTurnInText(text);
            System.Text.RegularExpressions.Match m = GivesYouRx.Match((text ?? "").Trim());
            if (!m.Success) return;
            string npc = m.Groups["npc"].Value.Trim();
            if (npc.Length == 0 || npc.StartsWith("You", StringComparison.OrdinalIgnoreCase)) return;
            bool any = false;
            List<KillTask> all = new List<KillTask>(ktRepeat);
            all.AddRange(ktSession);
            foreach (KillTask k in all)
            {
                QuestDefinition q = KtQuestDef(k);
                if (q == null || string.IsNullOrEmpty(q.QuestGiver)) continue;
                bool giver = false;
                foreach (string g in q.QuestGiver.Split(new[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries))
                    if (string.Equals(g.Trim(), npc, StringComparison.OrdinalIgnoreCase)) giver = true;
                if (!giver) continue;
                if (k.Have == 0 && !k.Complete) continue;   // already reset
                foreach (KillTask o in KtSameTask(k)) { o.Have = 0; o.Complete = false; o.LastSeen = DateTime.Now; }
                any = true;
                Util.WriteToChat("Kill task turned in: " + k.Name + " (" + npc + ").");
            }
            if (!any) return;
            ktDirty = true;
            ktHudAt = DateTime.MinValue;
            SaveSettings();
        }

        /// <summary>A quest's own turn-in text (Edit Quest tab, "Turn-in text") seen in chat: its kill task starts again.</summary>
        private void OnTurnInText(string text)
        {
            if (string.IsNullOrEmpty(text)) return;
            bool any = false;
            List<KillTask> all = new List<KillTask>(ktRepeat);
            all.AddRange(ktSession);
            foreach (KillTask k in all)
            {
                QuestDefinition q = KtQuestDef(k);
                if (q == null || q.TurnInText.Count == 0) continue;
                bool hit = false;
                foreach (string t in q.TurnInText)
                    if (text.IndexOf(t, StringComparison.OrdinalIgnoreCase) >= 0) hit = true;
                if (!hit) continue;
                if (k.Have == 0 && !k.Complete) continue;   // already reset
                foreach (KillTask o in KtSameTask(k)) { o.Have = 0; o.Complete = false; o.LastSeen = DateTime.Now; }
                any = true;
                Util.WriteToChat("Kill task turned in: " + k.Name + ".");
            }
            if (!any) return;
            ktDirty = true;
            ktHudAt = DateTime.MinValue;
            SaveSettings();
        }

        private void OnKillTaskChat(string text)
        {
            OnKillTaskTurnIn(text);
            OnItemGiven(text);
            string mob; int have, need; bool done;
            if (!KillTaskParser.TryRead(text, out mob, out have, out need, out done)) return;
            // A monster listed in a quest's "KT mobs" counts towards that quest's one task (the server keeps one
            // count for all of them, and names whichever monster you just killed): track it under the quest.
            int part;
            QuestDefinition grp = KtListedQuest(mob, need, out part);
            string gname = grp != null ? Words(grp.Name) : "";
            // A tiered task (the database's "T11 ...") killed at another tier: the same monsters, its own task - so its
            // own rows, named for the tier you're at (the bounty's /location tier: "T12 Chitticks KT").
            int tier = bountyTracker != null ? bountyTracker.Tier : -1;
            System.Text.RegularExpressions.Match tm = System.Text.RegularExpressions.Regex.Match(gname, @"^T(\d+)\s");
            bool otherTier = grp != null && tm.Success && tier > 0 && int.Parse(tm.Groups[1].Value) != tier;
            if (otherTier) gname = "T" + tier + gname.Substring(1 + tm.Groups[1].Length);
            string name = grp != null ? gname + (part > 0 ? " x" + part : "") : mob;   // a part of the quest: its own row
            KillTask k = FindKt(ktSession, name);
            if (k == null) { k = new KillTask { Name = name }; ktSession.Insert(0, k); }
            else if (ktSession.IndexOf(k) > 0) { ktSession.Remove(k); ktSession.Insert(0, k); }   // most recent on top
            k.Group = grp != null;
            k.Quest = grp != null ? (otherTier ? gname : grp.Name) : k.Quest;
            k.LastMob = mob;
            k.Have = have; k.Need = need; k.Complete = done; k.LastSeen = DateTime.Now;
            KillTask r = FindKt(ktRepeat, name);
            if (r == null && grp != null && part == 0)
            {
                // ticked before the quest had its KT mobs: move that row over to the quest
                r = FindKt(ktRepeat, mob);
                if (r != null) { r.Name = name; MergeKts(ktRepeat); r = FindKt(ktRepeat, name); SaveSettings(); }
            }
            if (r == null)
            {
                // a kill task you've started: ticked to show on the pop-up straight away (untick it on the KTs tab)
                r = new KillTask { Name = name, OnHud = true, Group = grp != null, Quest = grp != null ? (otherTier ? gname : grp.Name) : KtQuest(name) };
                ktRepeat.Add(r);
                Util.WriteToChat("Kill task added to the pop-up: " + (grp != null ? (otherTier ? gname : grp.Name) : name) + ".");
                SaveSettings();
            }
            if (r != null)
            {
                r.Group = grp != null;
                r.LastMob = mob;
                bool wasDone = r.Complete;
                r.Have = have; r.Need = need; r.Complete = done; r.LastSeen = DateTime.Now;
                if (done && !wasDone) SaveSettings();
            }
            ktDirty = true;
        }

        /// <summary>The quest a kill task belongs to: a database quest (or an unregistered kill task) whose name has
        /// the monster in it - "Snow Tusker Warriors" finds "... Snow Tusker Warrior ...". "Kill" ones are preferred.</summary>
        private string KtQuest(string name)
        {
            string cached;
            if (ktQuestCache.TryGetValue(name, out cached)) return cached;
            string one = KillTaskParser.Singular(name);
            // A quest that lists this monster in its "KT mobs" (Edit Quest tab) wins.
            QuestDefinition listed = KtListedQuest(name);
            if (listed != null) { ktQuestCache[name] = listed.Name; return listed.Name; }
            string best = "";
            int bestScore = 0;
            List<QuestDefinition> all = new List<QuestDefinition>(QuestDatabase.Quests);
            all.AddRange(UnregisteredKillTasks());
            foreach (QuestDefinition q in all)
            {
                string qn = Words(q.Name);
                int score = 0;
                if (qn.IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0) score = 3;
                else if (qn.IndexOf(one, StringComparison.OrdinalIgnoreCase) >= 0) score = 2;
                if (score == 0) continue;
                if (qn.IndexOf("kill", StringComparison.OrdinalIgnoreCase) >= 0) score += 2;
                if (score > bestScore) { bestScore = score; best = q.Name + (q.Unregistered ? " (not in db)" : ""); }
            }
            if (best.Length == 0)
            {
                // An affixed monster ("Infernal Sovereign Battlemages"): try its name with the last words dropped, so
                // the base name's quest ("Infernal Sovereign ...") is found. Two words at least, so it stays specific.
                List<string> words = new List<string>(one.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries));
                while (words.Count > 2 && best.Length == 0)
                {
                    words.RemoveAt(words.Count - 1);
                    string part = string.Join(" ", words.ToArray());
                    foreach (QuestDefinition q in all)
                    {
                        string qn = Words(q.Name);
                        if (!WordsIn(qn, part) && !string.Equals(qn, part, StringComparison.OrdinalIgnoreCase)) continue;
                        int score = 1 + (qn.IndexOf("kill", StringComparison.OrdinalIgnoreCase) >= 0 ? 2 : 0);
                        if (score > bestScore) { bestScore = score; best = q.Name + (q.Unregistered ? " (not in db)" : ""); }
                    }
                }
            }
            ktQuestCache[name] = best;
            return best;
        }

        /// <summary>A quest with KT mobs whose name is this row's name (a group row saved before the quest was kept with it).</summary>
        private static QuestDefinition KtGroupQuestNamed(string name)
        {
            foreach (QuestDefinition q in QuestDatabase.Quests)
                if (q.KtMobs.Count > 0 && string.Equals(Words(q.Name), (name ?? "").Trim(), StringComparison.OrdinalIgnoreCase)) return q;
            return null;
        }

        // "Hiveborn Grenadier x1" in KT mobs: that monster's line counts for this quest only when the task's total is 1
        // (one monster counting for two parts of a quest: "8 of 15 ..." and "1 of 1 ..." - each part gets its own row).
        private static readonly System.Text.RegularExpressions.Regex KtPartRx = new System.Text.RegularExpressions.Regex(@"^(?<m>.+?)\s+[x\u00d7*]\s*(?<n>\d+)$", System.Text.RegularExpressions.RegexOptions.IgnoreCase);

        /// <summary>A KT mobs entry split into the monster and its part's total (0 = any total).</summary>
        private static string KtMobName(string entry, out int part)
        {
            part = 0;
            System.Text.RegularExpressions.Match m = KtPartRx.Match((entry ?? "").Trim());
            if (!m.Success) return (entry ?? "").Trim();
            int.TryParse(m.Groups["n"].Value, out part);
            return m.Groups["m"].Value.Trim();
        }

        // The pop-up asks for every kill-task row every second and each scan goes through all 1000+ quests (with a regex
        // per KT mob) - long enough to freeze the game for a moment. Remembered until the quest database is loaded again.
        private static readonly Dictionary<string, QuestDefinition> ktListedCache = new Dictionary<string, QuestDefinition>(StringComparer.OrdinalIgnoreCase);
        private static readonly Dictionary<string, int> ktListedPart = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        private static int ktListedVer = -1;

        private static void KtListedFresh()
        {
            if (ktListedVer == QuestDatabase.LoadCount) return;
            ktListedVer = QuestDatabase.LoadCount;
            ktListedCache.Clear();
            ktListedPart.Clear();
        }

        private static QuestDefinition KtListedQuest(string name)
        {
            KtListedFresh();
            string key = name ?? "";
            QuestDefinition q;
            if (ktListedCache.TryGetValue(key, out q)) return q;
            q = KtListedQuestScan(key);
            ktListedCache[key] = q;
            return q;
        }

        private static QuestDefinition KtListedQuest(string name, int need, out int part)
        {
            KtListedFresh();
            string key = (name ?? "") + "\u0001" + need;
            QuestDefinition q;
            if (ktListedCache.TryGetValue(key, out q)) { ktListedPart.TryGetValue(key, out part); return q; }
            q = KtListedQuestScan(name ?? "", need, out part);
            ktListedCache[key] = q;
            ktListedPart[key] = part;
            return q;
        }

        /// <summary>For a kill line: the quest (and its part's total, 0 = none) whose KT mobs list this monster for this total.</summary>
        private static QuestDefinition KtListedQuestScan(string name, int need, out int part)
        {
            part = 0;
            string one = KillTaskParser.Singular(name);
            // a part entry for exactly this total first
            foreach (QuestDefinition q in QuestDatabase.Quests)
                foreach (string e in q.KtMobs)
                {
                    int n; string m = KtMobName(e, out n);
                    if (n <= 0 || n != need) continue;
                    if (string.Equals(m, name, StringComparison.OrdinalIgnoreCase) || string.Equals(m, one, StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(KillTaskParser.Singular(m), one, StringComparison.OrdinalIgnoreCase) || WordsIn(name, m) || WordsIn(one, m) || WordsIn(one, KillTaskParser.Singular(m)))
                    { part = n; return q; }
                }
            return KtListedQuest(name);
        }

        /// <summary>The quest whose ktMobs names this kill task line's monster (singular or plural), or null.
        /// Part entries ("... x1") only count through the overload above, for a line with that total.</summary>
        private static QuestDefinition KtListedQuestScan(string name)
        {
            string one = KillTaskParser.Singular(name);
            foreach (QuestDefinition q in QuestDatabase.Quests)
                foreach (string m in q.KtMobs)
                    if (KtPartRx.IsMatch(m.Trim())) continue;
                    else if (string.Equals(m, name, StringComparison.OrdinalIgnoreCase) || string.Equals(m, one, StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(KillTaskParser.Singular(m), one, StringComparison.OrdinalIgnoreCase))
                        return q;
            // Partial names: monsters now come with affixes ("Infernal Sovereign Battlemage", "... Sorcerer"), so a KT mob
            // whose name is part of the monster's (as whole words) counts too. The longest such KT mob wins.
            QuestDefinition best = null; int bestLen = 0;
            foreach (QuestDefinition q in QuestDatabase.Quests)
                foreach (string m in q.KtMobs)
                {
                    if (KtPartRx.IsMatch(m.Trim())) continue;
                    string m1 = KillTaskParser.Singular(m);
                    if ((WordsIn(name, m) || WordsIn(one, m) || WordsIn(one, m1)) && m.Length > bestLen) { best = q; bestLen = m.Length; }
                }
            return best;
        }

        /// <summary>"Infernal Sovereign" appears in "Infernal Sovereign Battlemages" as whole words.</summary>
        private static bool WordsIn(string longer, string part)
        {
            if (string.IsNullOrEmpty(longer) || string.IsNullOrEmpty(part) || part.Length >= longer.Length) return false;
            return System.Text.RegularExpressions.Regex.IsMatch(longer,
                @"(?<![A-Za-z'])" + System.Text.RegularExpressions.Regex.Escape(part.Trim()) + @"(?![A-Za-z'])",
                System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        }

        private static string Ago(DateTime t)
        {
            if (t == DateTime.MinValue) return "";
            TimeSpan a = DateTime.Now - t;
            if (a.TotalMinutes < 1) return "now";
            if (a.TotalHours < 1) return (int)a.TotalMinutes + "m ago";
            if (a.TotalDays < 1) return (int)a.TotalHours + "h ago";
            return (int)a.TotalDays + "d ago";
        }

        private static string GroupText(KillTask k)
        {
            QuestDefinition q = QuestDatabase.Quests.Find(x => string.Equals(x.Name, k.Quest, StringComparison.OrdinalIgnoreCase));
            string mobs = q != null ? string.Join(", ", q.KtMobs.ToArray()) : "";
            return (k.Quest.Length > 0 ? k.Quest : k.Name) + (mobs.Length > 0 ? "  - counts: " + mobs : "") + (k.LastMob.Length > 0 ? "  (last: " + k.LastMob + ")" : "");
        }

        /// <summary>Rows for monsters that now belong to a quest's KT mobs are folded into one row for that quest (latest count).</summary>
        private bool MergeKts(List<KillTask> list)
        {
            bool changed = false;
            foreach (KillTask k in list)
            {
                if (k.Group || k.Item) continue;
                QuestDefinition q = KtListedQuest(k.Name) ?? KtGroupQuestNamed(k.Name);
                if (q == null) continue;
                k.LastMob = k.Name; k.Name = Words(q.Name); k.Group = true; k.Quest = q.Name;
                changed = true;
            }
            for (int i = 0; i < list.Count; i++)
                for (int j = list.Count - 1; j > i; j--)
                {
                    if (!string.Equals(list[i].Name, list[j].Name, StringComparison.OrdinalIgnoreCase)) continue;
                    KillTask a = list[i], b = list[j];
                    if (b.LastSeen > a.LastSeen) { a.Have = b.Have; a.Need = b.Need; a.Complete = b.Complete; a.LastSeen = b.LastSeen; a.LastMob = b.LastMob; }
                    a.OnHud = a.OnHud || b.OnHud;
                    list.RemoveAt(j);
                    changed = true;
                }
            return changed;
        }

        // ── Quest items to collect (Edit Quest tab "Items:") ─────────────────────────
        // "Shallows Moarsman gives you Moarsman Ichor." - an item one of your quests collects: counted in your pack
        // (the pack is the truth: turn-ins, drops and stacks all show) and listed on the Tracking tab like a kill task.
        private DateTime itemCountAt = DateTime.MinValue;

        /// <summary>The quest that collects this item, and how many it wants (0 = not said), or null.</summary>
        private static QuestDefinition CollectQuest(string item, out int need)
        {
            need = 0;
            foreach (QuestDefinition q in QuestDatabase.Quests)
                foreach (KeyValuePair<string, int> c in q.CollectItems)
                    if (string.Equals(c.Key, (item ?? "").Trim(), StringComparison.OrdinalIgnoreCase)) { need = c.Value; return q; }
            return null;
        }

        private void OnItemGiven(string text)
        {
            System.Text.RegularExpressions.Match m = GivesYouRx.Match((text ?? "").Trim());
            if (!m.Success) return;
            string item = m.Groups["item"].Value.Trim();
            int need;
            QuestDefinition q = CollectQuest(item, out need);
            if (q == null) return;
            // The item lands in the pack a moment after the line: count now, and again shortly.
            ItemRow(ktSession, item, q, need, true);
            CountQuestItems();
            itemCountAt = DateTime.Now.AddMilliseconds(700);
        }

        /// <summary>The item's row in that list (made if asked and missing). The session list keeps the latest on top.</summary>
        private static KillTask ItemRow(List<KillTask> list, string item, QuestDefinition q, int need, bool make)
        {
            KillTask k = null;
            foreach (KillTask o in list) if (o.Item && string.Equals(o.Name, item, StringComparison.OrdinalIgnoreCase)) k = o;
            if (k == null && !make) return null;
            if (k == null) { k = new KillTask { Name = item, Item = true }; list.Insert(0, k); }
            else if (make && list.IndexOf(k) > 0) { list.Remove(k); list.Insert(0, k); }
            k.Quest = q != null ? q.Name : k.Quest;
            k.Need = need;
            return k;
        }

        /// <summary>How many of each quest item are in your pack (stacks added up). Rows on the Tracking tab follow.</summary>
        private void CountQuestItems()
        {
            try
            {
                Dictionary<string, int> want = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
                Dictionary<string, QuestDefinition> quest = new Dictionary<string, QuestDefinition>(StringComparer.OrdinalIgnoreCase);
                foreach (QuestDefinition q in QuestDatabase.Quests)
                    foreach (KeyValuePair<string, int> c in q.CollectItems)
                        if (!want.ContainsKey(c.Key)) { want[c.Key] = c.Value; quest[c.Key] = q; }
                if (want.Count == 0) return;
                Dictionary<string, int> have = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
                foreach (WorldObject o in CoreManager.Current.WorldFilter.GetInventory())
                {
                    string n = o.Name ?? "";
                    if (!want.ContainsKey(n)) continue;
                    int s = 1;
                    try { s = o.Values(LongValueKey.StackCount); } catch { }
                    if (s < 1) s = 1;
                    int cur; have.TryGetValue(n, out cur);
                    have[n] = cur + s;
                }
                bool changed = false, save = false;
                foreach (KeyValuePair<string, int> w in want)
                {
                    int n; have.TryGetValue(w.Key, out n);
                    // Rows: any already listed, plus a session row as soon as you hold one.
                    KillTask s = ItemRow(ktSession, w.Key, quest[w.Key], w.Value, false);
                    if (s == null && n > 0) s = ItemRow(ktSession, w.Key, quest[w.Key], w.Value, true);
                    KillTask r = ItemRow(ktRepeat, w.Key, quest[w.Key], w.Value, false);
                    foreach (KillTask k in new[] { s, r })
                    {
                        if (k == null) continue;
                        bool done = w.Value > 0 && n >= w.Value;
                        if (k.Have == n && k.Complete == done && k.LastSeen != DateTime.MinValue) continue;
                        if (k == r && done != k.Complete) save = true;
                        k.Have = n; k.Need = w.Value; k.Complete = done; k.LastSeen = DateTime.Now;
                        changed = true;
                    }
                }
                if (changed) { ktDirty = true; ktHudAt = DateTime.MinValue; }
                if (save) ktSaveWanted = true;
            }
            catch (Exception ex) { Util.LogError(ex); }
        }

        private static string ItemText(KillTask k)
        {
            return (k.Quest.Length > 0 ? k.Quest : "(no quest)") + "  - collect" + (k.Need > 0 ? " " + k.Need : "") + " (in your pack)";
        }

        private void RenderKillTasks()
        {
            try
            {
                ktQuestCache.Clear();
                MergeKts(ktSession);
                if (MergeKts(ktRepeat)) SaveSettings();
                if (lstKtSession == null || lstKtRepeat == null) return;
                ktQuestCache.Clear();   // the database may have changed
                lstKtSession.Clear();
                foreach (KillTask k in ktSession)
                {
                    IListRow row = lstKtSession.AddRow();
                    row[0][0] = FindKt(ktRepeat, k.Name) != null;
                    row[1][0] = k.Name;
                    string q = k.Item ? ItemText(k) : k.Group ? GroupText(k) : KtQuest(k.Name);
                    row[2][0] = q.Length > 0 ? q : "(no matching quest)";
                    row[2][1] = q.Length > 0 ? System.Drawing.Color.White : System.Drawing.Color.Gray;
                    TimeSpan sw = KtTurnedIn(k);
                    if (sw != TimeSpan.MinValue && sw > TimeSpan.Zero && !k.Complete && k.Have == 0)
                    { row[3][0] = "ready in " + Span(sw); row[3][1] = System.Drawing.Color.Orange; }
                    else
                    {
                        row[3][0] = k.CountText;
                        row[3][1] = k.Complete ? System.Drawing.Color.Gold : System.Drawing.Color.LimeGreen;
                    }
                    row[4][0] = Ago(k.LastSeen);
                    row[4][1] = System.Drawing.Color.Gray;
                }
                ktSessionLbl.Text = ktSession.Count == 0 ? "Kill tasks and quest items seen this session - none yet (they show up on your next kill)"
                                                         : "Kill tasks and quest items seen this session (" + ktSession.Count + ") - tick one to put it on the repeat list below";
                lstKtRepeat.Clear();
                foreach (KillTask k in ktRepeat)
                {
                    IListRow row = lstKtRepeat.AddRow();
                    row[0][0] = k.OnHud;
                    row[1][0] = k.Name;
                    string q = k.Item ? ItemText(k) : k.Group ? GroupText(k) : KtQuest(k.Name);
                    row[2][0] = q.Length > 0 ? q : "(no matching quest)";
                    row[2][1] = q.Length > 0 ? System.Drawing.Color.White : System.Drawing.Color.Gray;
                    TimeSpan wait = KtTurnedIn(k);
                    if (wait != TimeSpan.MinValue && wait > TimeSpan.Zero && !k.Complete && k.Have == 0)
                    { row[3][0] = "ready in " + Span(wait); row[3][1] = System.Drawing.Color.Orange; }
                    else
                    {
                        row[3][0] = k.LastSeen == DateTime.MinValue ? "-" : k.CountText;
                        row[3][1] = k.Complete ? System.Drawing.Color.Gold : System.Drawing.Color.LimeGreen;
                    }
                    row[4][0] = Ago(k.LastSeen);
                    row[4][1] = System.Drawing.Color.Gray;
                    row[5][0] = "x";
                    row[5][1] = System.Drawing.Color.Red;
                }
            }
            catch (Exception ex) { Util.LogError(ex); }
        }

        private void OnKtSessionClick(int row, int col)
        {
            if (row < 0 || row >= ktSession.Count || col != 0) return;
            KillTask k = ktSession[row];
            KillTask r = FindKt(ktRepeat, k.Name);
            if (r != null) ktRepeat.Remove(r);
            else ktRepeat.Add(new KillTask { Name = k.Name, Have = k.Have, Need = k.Need, Complete = k.Complete, LastSeen = k.LastSeen, OnHud = true, Group = k.Group, Quest = k.Quest, LastMob = k.LastMob, Item = k.Item });
            SaveSettings();
            RenderKillTasks();
        }

        private void OnKtRepeatClick(int row, int col)
        {
            if (row < 0 || row >= ktRepeat.Count) return;
            if (col == 0) ktRepeat[row].OnHud = !ktRepeat[row].OnHud;
            else if (col == 5) ktRepeat.RemoveAt(row);
            else return;
            SaveSettings();
            RenderKillTasks();
        }

        /// <summary>The quest a kill task row belongs to (database or an unregistered kill task), or null.</summary>
        private QuestDefinition KtQuestDef(KillTask k)
        {
            string qn = k.Group || k.Item ? k.Quest : null;
            if (string.IsNullOrEmpty(qn))
            {
                QuestDefinition exact = QuestDatabase.Quests.Find(x => string.Equals(Words(x.Name), k.Name, StringComparison.OrdinalIgnoreCase));
                if (exact != null) return exact;
                qn = KtQuest(k.Name);
            }
            if (string.IsNullOrEmpty(qn)) return null;
            qn = qn.Replace(" (not in db)", "");
            QuestDefinition q = QuestDatabase.Quests.Find(x => string.Equals(x.Name, qn, StringComparison.OrdinalIgnoreCase));
            if (q != null) return q;
            foreach (QuestDefinition u in UnregisteredKillTasks()) if (string.Equals(u.Name, qn, StringComparison.OrdinalIgnoreCase)) return u;
            return null;
        }

        /// <summary>When the quest was last done, from /myquests (its main timer flag, else the latest of its timed flags).</summary>
        private static DateTime QuestLastDone(QuestDefinition q)
        {
            DateTime last = DateTime.MinValue;
            ServerTimer st;
            if (!string.IsNullOrEmpty(q.TimerFlag) && ProgressStore.ServerTimers.TryGetValue(q.TimerFlag, out st)) return st.Completed;
            foreach (string f in q.QbFlags)
                if (ProgressStore.ServerTimers.TryGetValue(f, out st) && st.RepeatSeconds > 0 && st.Completed > last) last = st.Completed;
            DateTime manual;
            if (ProgressStore.QuestDone.TryGetValue(q.Name, out manual) && manual > last) last = manual;
            return last;
        }

        /// <summary>
        /// Turned in? If /myquests says the quest was done after the last kill count was seen, that count is
        /// finished with: it goes back to 0 (waiting for the next kill line). Returns the time left on the quest's
        /// repeat timer (TimeSpan.MinValue = no timer), so a turned-in task can be hidden until it's ready again.
        /// </summary>
        private bool ktSaveWanted;

        /// <summary>This task's rows in both the session and repeat lists (same name, or same quest).</summary>
        private List<KillTask> KtSameTask(KillTask k)
        {
            List<KillTask> r = new List<KillTask>();
            QuestDefinition q = KtQuestDef(k);
            List<KillTask> all = new List<KillTask>(ktSession);
            all.AddRange(ktRepeat);
            foreach (KillTask o in all)
                if (o == k || string.Equals(o.Name, k.Name, StringComparison.OrdinalIgnoreCase) || (q != null && KtQuestDef(o) == q)) r.Add(o);
            return r;
        }

        private TimeSpan KtTurnedIn(KillTask k)
        {
            QuestDefinition q = KtQuestDef(k);
            if (q == null) return TimeSpan.MinValue;
            DateTime done = QuestLastDone(q);
            if (done != DateTime.MinValue && done > k.LastSeen && (k.Complete || k.Have > 0))
            {
                foreach (KillTask o in KtSameTask(k))
                {
                    o.Complete = false;
                    o.Have = 0;
                    o.LastSeen = done;   // so it isn't reset again
                }
                ktDirty = true;
                ktSaveWanted = true;
            }
            return TimerLeft(q);
        }

        /// <summary>For the bounty pop-up: "10 of 20 Snow Tusker Warriors" for each ticked kill task on the repeat list.</summary>
        private List<KeyValuePair<string, bool>> ktHudCache = new List<KeyValuePair<string, bool>>();
        private DateTime ktHudAt = DateTime.MinValue;

        /// <summary>For MelkTank's bounty pop-up (read by reflection): "K|10 of 20 Snow Tusker Warriors" for each kill task
        /// ticked on the KTs tab's repeat list, "D|done: ..." for a finished one.</summary>
        public static List<string> PopupKtLines()
        {
            List<string> o = new List<string>();
            try
            {
                PluginCore p = Instance;
                if (p == null || !p.isinitialized) return o;
                foreach (KeyValuePair<string, bool> l in p.KtHudLines()) o.Add((l.Value ? "D|" : "K|") + l.Key);
            }
            catch (Exception ex) { Util.LogError(ex); }
            return o;
        }

        private List<KeyValuePair<string, bool>> KtHudLines()
        {
            // The pop-up asks every frame; work it out once a second.
            if ((DateTime.Now - ktHudAt).TotalSeconds < 1) return ktHudCache;
            ktHudAt = DateTime.Now;
            ktHudCache = BuildKtHudLines();
            return ktHudCache;
        }

        private List<KeyValuePair<string, bool>> BuildKtHudLines()
        {
            // Monsters listed under one quest's "KT mobs" count towards the same task: one line, named after
            // the quest, with the latest count seen for any of them.
            List<KeyValuePair<string, bool>> l = new List<KeyValuePair<string, bool>>();
            List<string> order = new List<string>();
            Dictionary<string, KillTask> latest = new Dictionary<string, KillTask>(StringComparer.OrdinalIgnoreCase);
            foreach (KillTask k in ktRepeat)
            {
                if (!k.OnHud) continue;
                // Turned in (or never counted yet): left off until the first kill line comes in.
                KtTurnedIn(k);
                if (!k.Complete && k.Have == 0) continue;
                QuestDefinition q = k.Item ? null : KtListedQuest(k.Name);
                string label = q != null ? Words(q.Name) : k.Name;
                KillTask cur;
                if (!latest.TryGetValue(label, out cur)) { order.Add(label); latest[label] = k; }
                else if (k.LastSeen > cur.LastSeen) latest[label] = k;
            }
            foreach (string label in order)
            {
                KillTask k = latest[label];
                string count = k.LastSeen == DateTime.MinValue ? "?" : k.Complete ? "done:" : k.Item && k.Need <= 0 ? k.Have.ToString() : k.Have + " of " + (k.Need > 0 ? k.Need.ToString() : "?");
                l.Add(new KeyValuePair<string, bool>(count + " " + label, k.Complete));
            }
            return l;
        }

        private void LoadSettings()
        {
            try
            {
                QuestPage.Pinned.Clear();
                if (!File.Exists(configPath)) return;
                XmlDocument doc = new XmlDocument();
                Util.LoadXml(doc, configPath);
                XmlNode charNode = doc.SelectSingleNode($"/MQT_Settings/Character[@key='{characterKey}']");
                if (charNode == null) return;
                foreach (XmlNode pn in charNode.SelectNodes("pinned")) if (pn.InnerText.Length > 0) QuestPage.Pinned.Add(pn.InnerText);
                XmlNode nSo = charNode.SelectSingleNode("sortOrder");
                if (nSo != null)
                {
                    List<int> got = new List<int>();
                    foreach (string part in nSo.InnerText.Split(','))
                    { int m; if (int.TryParse(part.Trim(), out m) && m >= 0 && m <= 4 && !got.Contains(m)) got.Add(m); }
                    for (int m = 0; m <= 4; m++) if (!got.Contains(m)) got.Add(m);
                    sortList = got;
                }
                sortOff.Clear();
                XmlNode nSf = charNode.SelectSingleNode("sortOff");
                if (nSf != null)
                    foreach (string part in nSf.InnerText.Split(','))
                    { int m; if (int.TryParse(part.Trim(), out m) && m >= 0 && m <= 4) sortOff.Add(m); }
                if (sortOff.Count >= 5) sortOff.Clear();

                XmlNode n1 = charNode.SelectSingleNode("cooldownSeconds");
                if (n1 != null) int.TryParse(n1.InnerText, out cooldownSeconds);
                XmlNode n2 = charNode.SelectSingleNode("debounceMs");
                if (n2 != null) int.TryParse(n2.InnerText, out debounceMs);
                XmlNode nMq = charNode.SelectSingleNode("myQuestsIdleMs");
                if (nMq != null) int.TryParse(nMq.InnerText, out myQuestsIdleMs);
                XmlNode nTr = charNode.SelectSingleNode("travelRoute");
                if (nTr != null) bool.TryParse(nTr.InnerText, out travelRoute);
                XmlNode nDm = charNode.SelectSingleNode("dungeonMaps");
                if (nDm != null) bool.TryParse(nDm.InnerText, out dungeonMaps);
                XmlNode nTf = charNode.SelectSingleNode("travelFight");
                if (nTf != null) bool.TryParse(nTf.InnerText, out travelFight);
                XmlNode nSk = charNode.SelectSingleNode("serverKind");
                int sk; if (nSk != null && int.TryParse(nSk.InnerText, out sk) && sk >= 0 && sk <= 2) ServerMode.Kind = sk;
                XmlNode nMqOn = charNode.SelectSingleNode("myQuestsOn");
                bool mqOn; if (nMqOn != null && bool.TryParse(nMqOn.InnerText, out mqOn)) ServerMode.MyQuests = mqOn;
                XmlNode nTa = charNode.SelectSingleNode("travelArrow");
                if (nTa != null) { int.TryParse(nTa.InnerText, out travelArrow); if (travelArrow < 0 || travelArrow > 2) travelArrow = 0; }
                XmlNode nTl = charNode.SelectSingleNode("travelLinks");
                if (nTl != null) bool.TryParse(nTl.InnerText, out travelLinks);
                XmlNode n3 = charNode.SelectSingleNode("debug");
                if (n3 != null) bool.TryParse(n3.InnerText, out enbDebug);
                XmlNode n6 = charNode.SelectSingleNode("qbFlagColor");
                if (n6 != null) int.TryParse(n6.InnerText, out qbFlagColor);
                XmlNode n4 = charNode.SelectSingleNode("bountyHud");
                if (n4 != null) bool.TryParse(n4.InnerText, out bountyHudOn);
                XmlNode n5 = charNode.SelectSingleNode("bountyMinutes");
                if (n5 != null) int.TryParse(n5.InnerText, out bountyMinutes);
                if (bountyMinutes < 1) bountyMinutes = 1;
                XmlNode nk = charNode.SelectSingleNode("bountyShowKts");
                if (nk != null) bool.TryParse(nk.InnerText, out bountyShowKts);
                ktRepeat.Clear();
                foreach (XmlNode kn in charNode.SelectNodes("killTask"))
                {
                    XmlAttribute na = kn.Attributes["name"];
                    if (na == null || na.Value.Length == 0) continue;
                    KillTask k = new KillTask { Name = na.Value };
                    bool b; int i; DateTime d;
                    if (kn.Attributes["hud"] != null && bool.TryParse(kn.Attributes["hud"].Value, out b)) k.OnHud = b;
                    if (kn.Attributes["have"] != null && int.TryParse(kn.Attributes["have"].Value, out i)) k.Have = i;
                    if (kn.Attributes["need"] != null && int.TryParse(kn.Attributes["need"].Value, out i)) k.Need = i;
                    if (kn.Attributes["complete"] != null && bool.TryParse(kn.Attributes["complete"].Value, out b)) k.Complete = b;
                    if (kn.Attributes["seen"] != null && DateTime.TryParse(kn.Attributes["seen"].Value, null, System.Globalization.DateTimeStyles.RoundtripKind, out d)) k.LastSeen = d;
                    if (kn.Attributes["item"] != null && bool.TryParse(kn.Attributes["item"].Value, out b)) k.Item = b;
                    if (kn.Attributes["quest"] != null && kn.Attributes["quest"].Value.Length > 0) { k.Quest = kn.Attributes["quest"].Value; k.Group = !k.Item; }
                    ktRepeat.Add(k);
                }
            }
            catch (Exception ex) { Util.WriteToChat($"LoadSettings Error: {ex}"); }
        }

        private void SaveSettings()
        {
            // Before LoginComplete there's no character yet (configPath is still empty) - something touched a setting while
            // the game was starting up. Nothing to save then: the login loads this character's settings from the file.
            if (string.IsNullOrEmpty(configPath) || string.IsNullOrEmpty(characterKey))
            {
                DebugLog("SaveSettings skipped - not logged in yet: " + new System.Diagnostics.StackTrace(1, false).ToString().Replace("\n", " | "));
                return;
            }
            Util.Locked(configPath, () => SaveSettings_Locked());   // another client may be writing it too
        }

        private void SaveSettings_Locked()
        {
            try
            {
                XmlDocument doc = new XmlDocument();
                XmlElement root;
                if (File.Exists(configPath))
                {
                    Util.LoadXml(doc, configPath);
                    root = doc.DocumentElement;
                }
                else
                {
                    root = doc.CreateElement("MQT_Settings");
                    doc.AppendChild(root);
                }
                XmlNode existing = root.SelectSingleNode($"Character[@key='{characterKey}']");
                if (existing != null) root.RemoveChild(existing);

                XmlElement charNode = doc.CreateElement("Character");
                charNode.SetAttribute("key", characterKey);
                AddChild(doc, charNode, "cooldownSeconds", cooldownSeconds.ToString());
                AddChild(doc, charNode, "debounceMs", debounceMs.ToString());
                AddChild(doc, charNode, "myQuestsIdleMs", myQuestsIdleMs.ToString());
                AddChild(doc, charNode, "debug", enbDebug.ToString());
                AddChild(doc, charNode, "travelRoute", travelRoute.ToString());
                AddChild(doc, charNode, "travelLinks", travelLinks.ToString());
                AddChild(doc, charNode, "travelArrow", travelArrow.ToString());
                AddChild(doc, charNode, "serverKind", ServerMode.Kind.ToString());
                AddChild(doc, charNode, "myQuestsOn", ServerMode.MyQuests.ToString());
                AddChild(doc, charNode, "travelFight", travelFight.ToString());
                AddChild(doc, charNode, "dungeonMaps", dungeonMaps.ToString());
                AddChild(doc, charNode, "bountyHud", bountyHudOn.ToString());
                AddChild(doc, charNode, "qbFlagColor", qbFlagColor.ToString());
                AddChild(doc, charNode, "bountyMinutes", bountyMinutes.ToString());
                AddChild(doc, charNode, "bountyShowKts", bountyShowKts.ToString());
                foreach (string pin in QuestPage.Pinned) AddChild(doc, charNode, "pinned", pin);
                AddChild(doc, charNode, "sortOrder", string.Join(",", sortList.ConvertAll(m => m.ToString()).ToArray()));
                AddChild(doc, charNode, "sortOff", string.Join(",", new List<int>(sortOff).ConvertAll(m => m.ToString()).ToArray()));
                foreach (KillTask k in ktRepeat)
                {
                    XmlElement ke = doc.CreateElement("killTask");
                    ke.SetAttribute("name", k.Name);
                    ke.SetAttribute("hud", k.OnHud.ToString());
                    ke.SetAttribute("have", k.Have.ToString());
                    ke.SetAttribute("need", k.Need.ToString());
                    ke.SetAttribute("complete", k.Complete.ToString());
                    if ((k.Group || k.Item) && k.Quest.Length > 0) ke.SetAttribute("quest", k.Quest);
                    if (k.Item) ke.SetAttribute("item", "True");
                    if (k.LastSeen != DateTime.MinValue) ke.SetAttribute("seen", k.LastSeen.ToString("o"));
                    charNode.AppendChild(ke);
                }
                root.AppendChild(charNode);
                Util.SaveXml(doc, configPath);
            }
            catch (Exception ex)
            {
                // one short line (the full trace goes to the errors file): usually the file was busy for a moment
                Util.LogError(ex);
                Util.WriteToChat("Couldn't save settings (" + ex.GetType().Name + ": " + ex.Message + ") - details in MelksQuestTracker errors.txt.");
            }
        }

        private void AddChild(XmlDocument doc, XmlElement parent, string name, string value)
        {
            XmlElement e = doc.CreateElement(name);
            e.InnerText = value;
            parent.AppendChild(e);
        }

        private void ApplyConfigFromUI(bool announce)
        {
            try
            {
                int newCooldown;
                if (int.TryParse(SafeText(cooldownInput), out newCooldown) && newCooldown >= 5)
                    cooldownSeconds = newCooldown;
                else
                    cooldownInput.Text = cooldownSeconds.ToString();

                int newDebounce;
                if (int.TryParse(SafeText(debounceInput), out newDebounce) && newDebounce >= 500)
                    debounceMs = newDebounce;
                else
                    debounceInput.Text = debounceMs.ToString();

                int newMq;
                if (mqTimeInput != null)
                {
                    if (int.TryParse(SafeText(mqTimeInput), out newMq) && newMq >= 1000) myQuestsIdleMs = newMq;
                    else mqTimeInput.Text = myQuestsIdleMs.ToString();
                }

                enbDebug = debugModeBtn.Checked;
                SaveSettings();
                if (announce) Util.WriteToChat($"Config applied: cooldown={cooldownSeconds}s, QB idle timeout={debounceMs}ms, MyQuests idle timeout={myQuestsIdleMs}ms, debug={enbDebug}");
            }
            catch (Exception ex) { Util.WriteToChat($"ApplyConfigFromUI Error: {ex}"); }
        }

        // ===================== Collection / chat capture =====================

        private void TryCollect()
        {
            try
            {
                if (!isinitialized) return;
                if (!ServerMode.Ilt) { Util.WriteToChat("/qb list is Infinite Leaftide's - this server is set as Standard (Config > Server)."); return; }
                if (capturing) { Util.WriteToChat("Already collecting - please wait."); return; }

                double secsSince = (DateTime.Now - lastCollectTime).TotalSeconds;
                double remaining = cooldownSeconds - secsSince;
                if (lastCollectTime != DateTime.MinValue && remaining > 0)
                {
                    Util.WriteToChat($"Collect is on cooldown - {remaining:0}s remaining.");
                    return;
                }

                StartCapture("Collecting QB list...");
                Util.Command("/qb list");
            }
            catch (Exception ex) { Util.WriteToChat($"TryCollect Error: {ex}"); }
        }

        /// <summary>Starts listening for /qb list's lines (hiding them) - for Collect, /mqt collect, or /qb list typed in chat.</summary>
        private void StartCapture(string message)
        {
            try
            {
                lastCollectTime = DateTime.Now;
                capturing = true;
                sawIncompleteMarker = false;
                sessionCaptured.Clear();
                captureColors.Clear();
                captureUnknown.Clear();

                // Give the first line extra time to arrive in case of server lag, then fall
                // back to the configured idle timeout for gaps between subsequent lines.
                captureDeadline = DateTime.Now.AddMilliseconds(Math.Max(debounceMs, 5000));

                Util.WriteToChat(message);
            }
            catch (Exception ex) { Util.WriteToChat($"StartCapture Error: {ex}"); }
        }

        [BaseEvent("ChatBoxMessage")]
        private void Current_ChatBoxMessage(object sender, ChatTextInterceptEventArgs e)
        {
            Current_ChatBoxMessage_Inner(e);
            // travel: ties, the lifestone, and coordinates made into links (only lines nothing above has hidden)
            try { if (isinitialized) Travel.Travel.OnChat(e); } catch (Exception ex) { Util.LogError(ex); }
        }

        private void Current_ChatBoxMessage_Inner(ChatTextInterceptEventArgs e)
        {
            try
            {
                // Bounty lines (and our own quiet /bounty, /location replies, which are hidden).
                if (bountyTracker != null && bountyTracker.OnChat(e.Text)) { e.Eat = true; return; }
                // /myquests lines are read whenever they come (UtilityBelt asks for them too); hidden only during our own quiet read
                bool inWindow = DateTime.Now < myQuestsUntil;
                // "[MyQuests] This command may only be run once every 60 seconds." - something else asked just before
                // (and its answer may have been hidden from us): asked again once the minute's up
                if (myQuestsQuiet && inWindow && (e.Text ?? "").IndexOf("may only be run once every", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    myQuestsUntil = DateTime.MinValue;
                    myQuestsAskAt = DateTime.Now.AddSeconds(61);
                    e.Eat = true;
                    Util.WriteToChat("Quest timers: the server allows /myquests once a minute - asking again in a minute.");
                    DebugLog("myquests: refused (once a minute) - asking again at " + myQuestsAskAt.ToString("HH:mm:ss"));
                    return;
                }
                if (ReadMyQuests(e.Text))
                {
                    if (myQuestsQuiet && inWindow) e.Eat = true;
                    DebugLog("myquests line" + (e.Eat ? " (hidden)" : " (shown" + (myQuestsQuiet ? ", window closed" : ", typed") + ")") + ": " + e.Text.Trim());
                    return;
                }

                OnKillTaskChat(e.Text);

                if (!capturing) return;
                string text = (e.Text ?? "").Trim();
                if (text.Length == 0) return;

                string lower = text.ToLower();
                if (lower.Contains("incomplete quest bonus list"))
                {
                    sawIncompleteMarker = true;
                    e.Eat = true;
                    ResetIdleTimer();
                    return;
                }
                // Any other "...quest bonus list:" style header line - treat as a section
                // marker (ignore as data) rather than as a flag, but don't change state.
                if (lower.Contains("quest bonus list"))
                {
                    e.Eat = true;
                    ResetIdleTimer();
                    return;
                }

                if (QuestDatabase.AllKnownFlags.Contains(text))
                {
                    sessionCaptured[text] = sawIncompleteMarker ? FlagState.InProgress : FlagState.Completed;
                    int cc; captureColors.TryGetValue(e.Color, out cc); captureColors[e.Color] = cc + 1;
                    e.Eat = true;
                    ResetIdleTimer();
                    DebugLog($"qb captured: {text} ({(sawIncompleteMarker ? "in-progress" : "completed")})");
                }
                else if (LooksLikeFlag(text))
                {
                    // Not in the database: maybe a new quest's flag. Kept if it's in the /qb list colour
                    // (decided at the end, once the known flags have shown which colour that is).
                    captureUnknown.Add(new KeyValuePair<string, KeyValuePair<FlagState, int>>(text,
                        new KeyValuePair<FlagState, int>(sawIncompleteMarker ? FlagState.InProgress : FlagState.Completed, e.Color)));
                    int listColour = qbFlagColor >= 0 ? qbFlagColor : DominantCaptureColour();
                    if (listColour >= 0 && e.Color == listColour) { e.Eat = true; ResetIdleTimer(); }
                    DebugLog($"qb unknown line (colour {e.Color}): {text}");
                }
                // Anything that doesn't match a known flag and isn't a section header is left
                // alone (not eaten) - this is what lets normal chat/combat spam flow through
                // untouched during the capture window instead of needing a color check.
            }
            catch (Exception ex) { Util.WriteToChat($"Current_ChatBoxMessage Error: {ex}"); }
        }

        private void ResetIdleTimer()
        {
            try
            {
                captureDeadline = DateTime.Now.AddMilliseconds(debounceMs);
            }
            catch (Exception ex) { Util.WriteToChat($"ResetIdleTimer Error: {ex}"); }
        }

        private void FinalizeCapture()
        {
            try
            {
                capturing = false;
                captureDeadline = DateTime.MaxValue;

                if (sessionCaptured.Count == 0)
                {
                    Util.WriteToChat("QB Collect: no flags captured. If you have a lot of QBs, try raising the idle timeout on the Config tab.");
                    return;
                }

                // Treat this capture as the authoritative full state for this character -
                // /qb list dumps everything each time, so we replace rather than merge.
                // The /qb list colour: the one most of the known flags came in.
                int best = -1, bestN = 0;
                foreach (var kv in captureColors) if (kv.Value > bestN) { best = kv.Key; bestN = kv.Value; }
                if (best >= 0 && best != qbFlagColor) { qbFlagColor = best; SaveSettings(); }
                int newFound = 0;
                if (qbFlagColor >= 0)
                    foreach (var u in captureUnknown)
                    {
                        if (u.Value.Value != qbFlagColor) continue;
                        sessionCaptured[u.Key] = u.Value.Key;   // so it already counts as done once it's in a quest
                        if (!NewFlagStore.Flags.ContainsKey(u.Key)) { NewFlagStore.Flags[u.Key] = DateTime.Now; newFound++; }
                    }
                if (newFound > 0) NewFlagStore.Save();
                int pendingNew = NewFlagStore.Pending().Count;

                ProgressStore.SolvedAreDone(sessionCaptured);
                Dictionary<string, FlagState> before = ProgressStore.Flags;
                // A /qb list cut short (the game stalled longer than the idle wait part way through) isn't the whole
                // state: kept on top of the last one instead of replacing it - and no timers worked out from it.
                bool partial = before != null && before.Count > 200 && sessionCaptured.Count < before.Count * 0.8;
                if (partial)
                {
                    Util.WriteToChat("QB Collect: only " + sessionCaptured.Count + " of the " + before.Count + " flags last time came in (cut short?) - kept the others. Collect again to be sure.");
                    var merged = new Dictionary<string, FlagState>(before, StringComparer.OrdinalIgnoreCase);
                    foreach (var kv in sessionCaptured) merged[kv.Key] = kv.Value;
                    ProgressStore.Flags = merged;
                }
                else
                {
                    ProgressStore.Flags = new Dictionary<string, FlagState>(sessionCaptured, StringComparer.OrdinalIgnoreCase);
                    // (the last capture was the cut-short one: everything it missed would look "just done")
                    if (before != null && before.Count >= sessionCaptured.Count * 0.8) StartTimersForNewFlags(before);
                }
                ProgressStore.LastCollected = DateTime.Now;
                ProgressStore.Save(progressPath, characterKey);
                QuestDatabase.RecalculateProgress();

                int completedCount = 0, inProgressCount = 0;
                foreach (var kv in sessionCaptured)
                {
                    if (kv.Value == FlagState.Completed) completedCount++;
                    else inProgressCount++;
                }
                Util.WriteToChat($"QB Collect complete: {completedCount} completed, {inProgressCount} in progress (= {completedCount * 2 + inProgressCount:n0} QB: 2 each done, 1 each started)." +
                                 (pendingNew > 0 ? $" {pendingNew} flag{(pendingNew == 1 ? "" : "s")} not in the quest database yet - see the Edit Quest tab." : ""));
                RenderNewFlags();
                AskMyQuests();   // then the server's repeat timers

                ApplyMainFilterSort();
                ApplyFlagFilter();
                RenderDetailPanel();
                UpdateSummaryLabels();
            }
            catch (Exception ex) { Util.WriteToChat($"FinalizeCapture Error: {ex}"); }
        }

        // ===================== Clipboard =====================

        private void DoCopyToClipboard()
        {
            try
            {
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                int completed = 0, inProgress = 0;

                sb.AppendLine("=== Completed QB Flags ===");
                foreach (var kv in ProgressStore.Flags)
                {
                    if (kv.Value == FlagState.Completed) { sb.AppendLine(kv.Key); completed++; }
                }
                sb.AppendLine();
                sb.AppendLine("=== In-Progress QB Flags ===");
                foreach (var kv in ProgressStore.Flags)
                {
                    if (kv.Value == FlagState.InProgress) { sb.AppendLine(kv.Key); inProgress++; }
                }

                bool ok = Util.SetClipboardText(sb.ToString());
                if (ok)
                    Util.WriteToChat($"Copied to clipboard: {completed} completed, {inProgress} in progress.");
                else
                    Util.WriteToChat("Copy to clipboard failed - see error log.");
            }
            catch (Exception ex) { Util.WriteToChat($"DoCopyToClipboard Error: {ex}"); }
        }

        private void DoResetProgress()
        {
            try
            {
                ProgressStore.Flags.Clear();
                ProgressStore.LastCollected = DateTime.MinValue;
                ProgressStore.Save(progressPath, characterKey);
                QuestDatabase.RecalculateProgress();
                ApplyMainFilterSort();
                ApplyFlagFilter();
                RenderDetailPanel();
                UpdateSummaryLabels();
                Util.WriteToChat("Saved progress wiped for this character.");
            }
            catch (Exception ex) { Util.WriteToChat($"DoResetProgress Error: {ex}"); }
        }

        // ===================== UI tick =====================

        private void UiTick()
        {
            try
            {
                UpdateCollectButtonLabel();
                CheckQuestTimers();
                if ((DateTime.Now - newFlagsTimersAt).TotalSeconds >= 30) RefreshNewFlagTimers();
                if ((DateTime.Now - mqTimersAt).TotalSeconds >= 30) RefreshMyQuestTimers();
                if ((DateTime.Now - ktAgesAt).TotalSeconds >= 30) { ktAgesAt = DateTime.Now; if (ktSession.Count + ktRepeat.Count > 0) ktDirty = true; }   // "5m ago"
            }
            catch (Exception ex) { Util.WriteToChat($"UiTick Error: {ex}"); }
        }

        private void UpdateCollectButtonLabel()
        {
            if (capturing)
            {
                collectBtn.Text = "Collecting...";
                TrySetEnabled(collectBtn, false);
                return;
            }
            double secsSince = (DateTime.Now - lastCollectTime).TotalSeconds;
            double remaining = cooldownSeconds - secsSince;
            if (lastCollectTime != DateTime.MinValue && remaining > 0)
            {
                collectBtn.Text = $"Collect QB List ({remaining:0}s)";
                TrySetEnabled(collectBtn, false);
            }
            else
            {
                collectBtn.Text = "Collect QB List";
                TrySetEnabled(collectBtn, true);
            }
        }

        private void UpdateSummaryLabels()
        {
            int completed = 0, inProgress = 0;
            foreach (var kv in ProgressStore.Flags)
            {
                if (kv.Value == FlagState.Completed) completed++;
                else inProgress++;
            }
            summaryLabel.Text = $"Completed: {completed}   In-Progress: {inProgress}   Total QB: {completed * 2 + inProgress:n0}   Known Flags: {QuestDatabase.AllKnownFlags.Count}";
            lastCollectedLabel.Text = ProgressStore.LastCollected == DateTime.MinValue
                ? "Last collected: never"
                : $"Last collected: {ProgressStore.LastCollected:g}";
        }

        // ===================== Main tab (quest list) =====================

        private string SortModeLabel()
        {
            switch (sortMode)
            {
                case 0: return "% Asc";
                case 1: return "% Desc";
                case 2: return "Name";
                case 3: return "QB left";
                case 4: return "CD";
                default: return "Missing";
            }
        }

        private void ApplyMainFilterSort()
        {
            try
            {
                filteredQuests = new List<QuestDefinition>();
                string needle = (mainSearchText ?? "").ToLower();
                List<QuestDefinition> all = new List<QuestDefinition>(QuestDatabase.Quests);
                all.AddRange(UnregisteredKillTasks());
                foreach (QuestDefinition q in all)
                {
                    if (needle.Length > 0 && q.Name.ToLower().IndexOf(needle) < 0) continue;
                    if (canDoOnly && !CanDoNow(q)) continue;
                    if (repeatOnly && !q.Repeatable && q.CooldownHours <= 0 && !HasServerTimer(q)) continue;
                    filteredQuests.Add(q);
                }

                switch (sortMode)
                {
                    case 0:
                        filteredQuests.Sort((a, b) => a.PercentComplete.CompareTo(b.PercentComplete));
                        break;
                    case 1:
                        filteredQuests.Sort((a, b) => b.PercentComplete.CompareTo(a.PercentComplete));
                        break;
                    case 2:
                        filteredQuests.Sort((a, b) => string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase));
                        break;
                    case 3:
                        filteredQuests.Sort((a, b) => b.RemainingCount.CompareTo(a.RemainingCount));
                        break;
                    case 4:
                        {
                            Dictionary<QuestDefinition, TimeSpan> left = new Dictionary<QuestDefinition, TimeSpan>();
                            foreach (QuestDefinition q in filteredQuests) left[q] = TimerLeft(q);
                            // Counting down (soonest first), then ones you were seen doing that are ready again
                            // (most recently ready first), then other ready ones, then quests with no timer.
                            filteredQuests.Sort((a, b) =>
                            {
                                int ra = MainCdRank(a, left[a]), rb = MainCdRank(b, left[b]);
                                if (ra != rb) return ra.CompareTo(rb);
                                if (ra == 0) { int c = left[a].CompareTo(left[b]); if (c != 0) return c; }
                                if (ra == 1) { int c = left[b].CompareTo(left[a]); if (c != 0) return c; }
                                return string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase);
                            });
                        }
                        break;
                }
                RenderMainPage();
            }
            catch (Exception ex) { Util.WriteToChat($"ApplyMainFilterSort Error: {ex}"); }
        }

        private void RenderMainPage()
        {
            try
            {
                pageInfoLabel.Text = $"{filteredQuests.Count} quests" + (canDoOnly ? $" (lvl {MyLevel()})" : "");
                lstQuests.Clear();
                foreach (QuestDefinition q in filteredQuests)
                {
                    IListRow row = lstQuests.AddRow();
                    System.Drawing.Color c = ColorForPercent(q.PercentComplete);
                    row[QCOL_PCT][0] = $"{q.PercentComplete:0}%";
                    row[QCOL_PCT][1] = c;
                    row[QCOL_QB][0] = q.PossibleQb > 0 ? $"{q.CompletedCount}/{q.PossibleQb}" : "?";
                    row[QCOL_QB][1] = c;
                    string timer = TimerTag(q);
                    row[QCOL_NAME][0] = q.Name + (q.Unregistered ? " (not in db)" : "") + (q.NeedsReview ? " [REVIEW]" : "") + (q.InProgressCount > 0 ? " (*)" : "") + timer;
                    row[QCOL_NAME][1] = timer == " [ready]" ? System.Drawing.Color.Cyan : q.Unregistered ? System.Drawing.Color.LightSkyBlue : c;
                    row[QCOL_WIKI][0] = string.IsNullOrEmpty(q.WikiLink) ? "" : "wiki";
                    row[QCOL_WIKI][1] = System.Drawing.Color.SkyBlue;
                }
            }
            catch (Exception ex) { Util.WriteToChat($"RenderMainPage Error: {ex}"); }
        }

        private void OnQuestListClick(int row, int col)
        {
            try
            {
                if (row < 0 || row >= filteredQuests.Count) return;
                QuestDefinition q = filteredQuests[row];
                if (col == QCOL_WIKI)
                {
                    if (string.IsNullOrEmpty(q.WikiLink)) return;
                    string link = q.WikiLink;
                    System.Threading.ThreadPool.QueueUserWorkItem(_ => { string err = WikiView.OpenUrl(link); if (err != null) Util.WriteToChat($"Could not open link: {err}"); });
                    return;
                }
                selectedQuest = q;
                RenderDetailPanel();
            }
            catch (Exception ex) { Util.WriteToChat($"OnQuestListClick Error: {ex}"); }
        }

        private void RenderDetailPanel()
        {
            try { if (lstDetailFlags != null) lstDetailFlags.Visible = ServerMode.Ilt; } catch { }   // other servers: no /qb flags - the quest's info there instead
            try
            {
                if (selectedQuest == null)
                {
                    detailHeaderLabel.Text = "Click a quest to see its QB flags";
                    detailProgressLabel.Text = "";
                    detailGiverLabel.Text = "";
                    detailBadgesLabel.Text = "";
                    SetDetailNotes("");
                    detailPageInfoLabel.Text = "";
                    detailTimerBtn.Text = "Done now";
                    lstDetailFlags.Clear();
                    return;
                }

                detailHeaderLabel.Text = selectedQuest.Name;
                string reviewNote = selectedQuest.NeedsReview ? "  [REVIEW - not yet mapped to a real quest]" : "";
                detailProgressLabel.Text = $"{selectedQuest.CompletedCount}/{selectedQuest.PossibleQb} QB ({selectedQuest.PercentComplete:0}%){reviewNote}";
                string town = selectedQuest.StartTown ?? "";
                detailGiverLabel.Text = !string.IsNullOrEmpty(selectedQuest.QuestGiver) ? "Giver: " + selectedQuest.QuestGiver + (town.Length > 0 ? "  (" + town + ")" : "")
                                      : town.Length > 0 ? "Starts in: " + town : "";
                SetDetailNotes(selectedQuest.Notes);

                if (selectedDetailFlag != null && !selectedQuest.QbFlags.Exists(f => string.Equals(f, selectedDetailFlag, StringComparison.OrdinalIgnoreCase))) selectedDetailFlag = null;
                detailMainTimerBtn.Text = selectedDetailFlag != null && string.Equals(selectedDetailFlag, selectedQuest.TimerFlag, StringComparison.OrdinalIgnoreCase) ? "Unset main" : "Main timer";
                detailFlags = new List<string>(selectedQuest.QbFlags);
                detailFlags.Sort(StringComparer.OrdinalIgnoreCase);

                List<string> badges = new List<string>();

                if (selectedQuest.LockpickRequired) badges.Add("Lockpick");
                if (selectedQuest.FellowRequired) badges.Add("Fellow");
                if (selectedQuest.RecLevel > 0) badges.Add($"Lvl {selectedQuest.RecLevel:0}");
                if (selectedQuest.Repeatable) badges.Add("Repeatable");
                if (selectedQuest.InProgressCount > 0) badges.Add($"{selectedQuest.InProgressCount} in progress");
                if (selectedQuest.CooldownHours > 0 || HasServerTimer(selectedQuest)) badges.Add(TimerText(selectedQuest));
                DateTime doneAt;
                TimeSpan selLeft = TimerLeft(selectedQuest);
                detailTimerBtn.Text = ProgressStore.QuestDone.TryGetValue(selectedQuest.Name, out doneAt) && selLeft > TimeSpan.Zero ? "Clear timer"
                                    : selLeft != TimeSpan.MinValue && selLeft <= TimeSpan.Zero && ProgressStore.Watched.Contains(selectedQuest.Name) ? "Clear"
                                    : "Done now";
                detailBadgesLabel.Text = string.Join("  |  ", badges.ToArray());

                detailPageInfoLabel.Text = $"{detailFlags.Count} flags";
                lstDetailFlags.Clear();
                foreach (string flag in detailFlags)
                {
                    FlagState state;
                    bool known = ProgressStore.Flags.TryGetValue(flag, out state);
                    IListRow row = lstDetailFlags.AddRow();
                    row[0][0] = known ? (state == FlagState.Completed ? "done" : "...") : "-";
                    row[0][1] = known ? (state == FlagState.Completed ? System.Drawing.Color.LimeGreen : System.Drawing.Color.Gold) : System.Drawing.Color.Gray;
                    bool isMain = string.Equals(flag, selectedQuest.TimerFlag, StringComparison.OrdinalIgnoreCase);
                    row[1][0] = (isMain ? "[main] " : "") + flag;
                    if (string.Equals(flag, selectedDetailFlag, StringComparison.OrdinalIgnoreCase)) row[1][1] = System.Drawing.Color.Cyan;
                    else if (isMain) row[1][1] = System.Drawing.Color.Gold;
                    // This flag's own /myquests timer: "3d04h", "ready", or blank when it doesn't repeat.
                    ServerTimer ft;
                    TimeSpan fl = ProgressStore.ServerTimers.TryGetValue(flag, out ft) ? FlagLeft(ft) : TimeSpan.MinValue;
                    if (fl == TimeSpan.MinValue) row[2][0] = "";
                    else if (fl > TimeSpan.Zero) { row[2][0] = Span(fl); row[2][1] = System.Drawing.Color.Orange; }
                    else { row[2][0] = "ready"; row[2][1] = System.Drawing.Color.LimeGreen; }
                }
            }
            catch (Exception ex) { Util.WriteToChat($"RenderDetailPanel Error: {ex}"); }
        }

        // Fills the fixed notes lines under the quest header. StaticText controls don't wrap, so the
        // text is word-wrapped by hand to roughly the panel width. Anything past the last line is
        // cut off with "..." (the full note is always in QuestDatabase.xml).
        private void SetDetailNotes(string notes)
        {
            List<string> lines = WrapText(string.IsNullOrEmpty(notes) ? "" : "Notes: " + notes, DETAIL_NOTES_WIDTH, DETAIL_NOTES_LINES);
            for (int i = 0; i < detailNotesLabels.Length; i++)
                detailNotesLabels[i].Text = i < lines.Count ? lines[i] : "";
        }

        private static List<string> WrapText(string text, int maxChars, int maxLines)
        {
            List<string> lines = new List<string>();
            if (string.IsNullOrEmpty(text)) return lines;

            string[] words = text.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            string current = "";
            bool truncated = false;
            foreach (string word in words)
            {
                string candidate = current.Length == 0 ? word : current + " " + word;
                if (candidate.Length <= maxChars || current.Length == 0)
                {
                    current = candidate;
                    continue;
                }
                lines.Add(current);
                current = word;
                if (lines.Count == maxLines) { truncated = true; break; }
            }
            if (!truncated && current.Length > 0) lines.Add(current);

            if (lines.Count > maxLines) { lines.RemoveRange(maxLines, lines.Count - maxLines); truncated = true; }
            if (truncated && lines.Count > 0)
            {
                string last = lines[lines.Count - 1];
                if (last.Length > maxChars - 3) last = last.Substring(0, maxChars - 3);
                lines[lines.Count - 1] = last + "...";
            }
            return lines;
        }

        // ===================== "Can do now" =====================

        private int MyLevel()
        {
            try { return CoreManager.Current.CharacterFilter.Level; } catch { return 0; }
        }

        private bool HasLockpick()
        {
            try
            {
                TrainingType t = CoreManager.Current.CharacterFilter.Skills[CharFilterSkillType.Lockpick].Training;
                return t == TrainingType.Trained || t == TrainingType.Specialized;
            }
            catch { return true; }
        }

        /// <summary>Not finished, your level is high enough, doable solo, lockpick if you have it, not waiting on a timer.</summary>
        private bool CanDoNow(QuestDefinition q)
        {
            if (q.Unregistered) return TimerLeft(q) <= TimeSpan.Zero;     // a kill task not in the db yet: whenever its timer is up
            if (q.NeedsReview) return false;
            if (q.PossibleQb <= 0 || q.IsComplete) return false;
            if (q.FellowRequired) return false;
            if (q.LockpickRequired && !HasLockpick()) return false;
            int lvl = MyLevel();
            if (q.MinLevel > 0 && lvl > 0 && lvl < q.MinLevel) return false;
            if (TimerLeft(q) > TimeSpan.Zero) return false;
            return true;
        }

        // ===================== Quest timers (repeatable quests) =====================

        /// <summary>Time until the quest can be done again; zero or less = ready; TimeSpan.MinValue = no timer.</summary>
        private TimeSpan TimerLeft(QuestDefinition q)
        {
            // A chosen main timer flag: its /myquests timer is the quest's timer.
            if (!string.IsNullOrEmpty(q.TimerFlag))
            {
                ServerTimer mt;
                if (ProgressStore.ServerTimers.TryGetValue(q.TimerFlag, out mt) && mt.RepeatSeconds > 0) return mt.ReadyAt - DateTime.Now;
            }
            // The server's own timers (/myquests) when any of the quest's flags has one: ready when the last one is.
            DateTime ready = DateTime.MinValue;
            foreach (string f in q.QbFlags)
            {
                ServerTimer st;
                if (ProgressStore.ServerTimers.TryGetValue(f, out st) && st.RepeatSeconds > 0 && st.ReadyAt > ready) ready = st.ReadyAt;
            }
            if (ready != DateTime.MinValue) return ready - DateTime.Now;

            DateTime at;
            if (q.CooldownHours <= 0 || !ProgressStore.QuestDone.TryGetValue(q.Name, out at)) return TimeSpan.MinValue;
            return at.AddHours(q.CooldownHours) - DateTime.Now;
        }

        private static string Span(TimeSpan t)
        {
            if (t.TotalDays >= 1) return (int)t.TotalDays + "d" + t.Hours.ToString("00") + "h";
            if (t.TotalHours >= 1) return (int)t.TotalHours + "h" + t.Minutes.ToString("00") + "m";
            return Math.Max(1, (int)Math.Ceiling(t.TotalMinutes)) + "m";
        }

        /// <summary>For the quest list: " [3h12m]" while waiting, " [ready]" once it's done waiting, "" otherwise.</summary>
        private string TimerTag(QuestDefinition q)
        {
            TimeSpan left = TimerLeft(q);
            if (left == TimeSpan.MinValue) return "";
            return left > TimeSpan.Zero ? " [" + Span(left) + "]" : " [ready]";
        }

        private bool HasServerTimer(QuestDefinition q)
        {
            foreach (string f in q.QbFlags)
            {
                ServerTimer st;
                if (ProgressStore.ServerTimers.TryGetValue(f, out st) && st.RepeatSeconds > 0) return true;
            }
            return false;
        }

        private string TimerText(QuestDefinition q)
        {
            if (HasServerTimer(q))
            {
                TimeSpan l = TimerLeft(q);
                return l > TimeSpan.Zero ? "Ready again in " + Span(l) + " (server)" : "Ready again (server)";
            }
            string every = "Repeat " + (q.RepeatNote.Length > 0 ? q.RepeatNote : q.CooldownHours + "hr");
            TimeSpan left = TimerLeft(q);
            if (left == TimeSpan.MinValue) return every + ": no timer (Done now starts one)";
            return left > TimeSpan.Zero ? every + ": ready in " + Span(left) : every + ": ready";
        }

        /// <summary>The detail panel's Done now / Clear timer button.</summary>
        /// <summary>
        /// The flag clicked in the detail list becomes the quest's main timer (saved as timerFlag="..." in
        /// QuestDatabase.xml): the quest's countdown, [ready] tag and CD sort follow that flag alone.
        /// Pressing it on the main flag again goes back to "the latest of all its flags".
        /// </summary>
        private void SetMainTimerFlag()
        {
            Util.Locked(questDbPath, () => SetMainTimerFlag_Locked());   // another client may be writing it too
        }

        private void SetMainTimerFlag_Locked()
        {
            try
            {
                QuestDefinition q = selectedQuest;
                if (q == null) return;
                if (selectedDetailFlag == null)
                {
                    Util.WriteToChat("Click one of the quest's flags first, then Main timer" +
                                     (q.TimerFlag.Length > 0 ? " (now: " + q.TimerFlag + ")." : "."));
                    return;
                }
                string flag = string.Equals(selectedDetailFlag, q.TimerFlag, StringComparison.OrdinalIgnoreCase) ? "" : selectedDetailFlag;
                if (flag.Length > 0)
                {
                    ServerTimer st;
                    if (!ProgressStore.ServerTimers.TryGetValue(flag, out st) || st.RepeatSeconds <= 0)
                        Util.WriteToChat(flag + " has no /myquests repeat timer yet - it's set anyway and is used once it has one.");
                }

                XmlDocument doc = new XmlDocument();
                Util.LoadXml(doc, questDbPath);
                XmlNode n = FindQuestNode(doc, q.Name);
                if (n == null) { Util.WriteToChat("Couldn't find " + q.Name + " in QuestDatabase.xml - reload it."); return; }
                BackupQuestDb();
                XmlElement e = (XmlElement)n;
                if (flag.Length > 0) e.SetAttribute("timerFlag", flag); else e.RemoveAttribute("timerFlag");
                Util.SaveXml(doc, questDbPath);
                q.TimerFlag = flag;
                timerAnnounced.Remove(q.Name);
                Util.WriteToChat(flag.Length > 0 ? q.Name + ": main timer is now " + flag + "." : q.Name + ": main timer unset - using the latest of all its flags.");
                RenderDetailPanel();
                ApplyMainFilterSort();
            }
            catch (Exception ex) { Util.WriteToChat("Main timer error: " + ex.Message); Util.LogError(ex); }
        }

        private void ToggleQuestTimer()
        {
            try
            {
                QuestDefinition q = selectedQuest;
                if (q == null) return;
                // Ready again and kept near the top of Sort: CD because you did it - Clear drops it back with the rest.
                TimeSpan l0 = TimerLeft(q);
                if (l0 != TimeSpan.MinValue && l0 <= TimeSpan.Zero && ProgressStore.Watched.Contains(q.Name))
                {
                    ProgressStore.Watched.Remove(q.Name);
                    ProgressStore.QuestDone.Remove(q.Name);
                    ProgressStore.Save(progressPath, characterKey);
                    Util.WriteToChat("Cleared: " + q.Name + " (no longer kept under the running timers).");
                    RenderDetailPanel();
                    ApplyMainFilterSort();
                    return;
                }
                if (q.CooldownHours <= 0)
                {
                    Util.WriteToChat("No repeat time known for " + q.Name + " - give it one in QuestDatabase.xml, e.g. repeatNote=\"20hr\".");
                    return;
                }
                if (TimerLeft(q) > TimeSpan.Zero) { ProgressStore.QuestDone.Remove(q.Name); ProgressStore.Watched.Remove(q.Name); Util.WriteToChat("Timer cleared: " + q.Name); }
                else { ProgressStore.QuestDone[q.Name] = DateTime.Now; Util.WriteToChat(q.Name + ": ready again in " + Span(TimeSpan.FromHours(q.CooldownHours)) + "."); }
                timerAnnounced.Remove(q.Name);
                ProgressStore.Save(progressPath, characterKey);
                RenderDetailPanel();
                ApplyMainFilterSort();
            }
            catch (Exception ex) { Util.WriteToChat($"ToggleQuestTimer Error: {ex}"); }
        }

        /// <summary>After a /qb list: a repeatable quest that gained a completed flag since last time was just done - start its timer.</summary>
        private void StartTimersForNewFlags(Dictionary<string, FlagState> before)
        {
            if (before == null || before.Count == 0) return;   // first collect: nothing to compare with
            List<QuestDefinition> justDone = new List<QuestDefinition>();
            foreach (QuestDefinition q in QuestDatabase.Quests)
            {
                if (q.CooldownHours <= 0) continue;
                foreach (string f in q.QbFlags)
                {
                    FlagState now, then;
                    bool done = ProgressStore.Flags.TryGetValue(f, out now) && now == FlagState.Completed;
                    bool was = before.TryGetValue(f, out then) && then == FlagState.Completed;
                    if (done && !was)
                    {
                        ProgressStore.QuestDone[q.Name] = DateTime.Now;
                        timerAnnounced.Remove(q.Name);
                        justDone.Add(q);
                        break;
                    }
                }
            }
            // one line each for a few; more than that at once is one line
            if (justDone.Count <= 3)
                foreach (QuestDefinition q in justDone) Util.WriteToChat(q.Name + " done - ready again in " + Span(TimeSpan.FromHours(q.CooldownHours)) + ".");
            else
                Util.WriteToChat(justDone.Count + " quests done since the last /qb list - their timers are running (" +
                                 string.Join(", ", justDone.ConvertAll(q => Words(q.Name)).GetRange(0, Math.Min(5, justDone.Count)).ToArray()) + (justDone.Count > 5 ? ", ...)." : ")."));
        }

        /// <summary>Once a second: say when a timed quest is ready again; refresh the list's countdowns once a minute.</summary>
        private bool watchedDirty;
        private DateTime watchedSavedAt = DateTime.MinValue;

        private void CheckQuestTimers()
        {
            if (!isinitialized) return;
            if (watchedDirty && (DateTime.Now - watchedSavedAt).TotalSeconds > 30)
            {
                watchedDirty = false;
                watchedSavedAt = DateTime.Now;
                ProgressStore.Save(progressPath, characterKey);
            }
            bool anyRunning = false;
            foreach (QuestDefinition q in QuestDatabase.Quests)
            {
                TimeSpan left = TimerLeft(q);
                if (left == TimeSpan.MinValue) continue;
                if (left > TimeSpan.Zero)
                {
                    anyRunning = true;
                    if (ProgressStore.Watched.Add(q.Name)) watchedDirty = true;
                    continue;
                }
                // Chat only for quests with a repeat note or that you timed yourself (Done now) - hundreds of
                // quests have server timers, and a line for each would bury the chat.
                bool announce = q.CooldownHours > 0 || ProgressStore.QuestDone.ContainsKey(q.Name);
                if (timerAnnounced.Add(q.Name) && announce && left > TimeSpan.FromHours(-1))
                    Util.WriteToChat("Quest ready again: " + q.Name);
            }
            if (anyRunning && DateTime.Now >= nextTimerRefresh)
            {
                nextTimerRefresh = DateTime.Now.AddMinutes(1);
                if (sortMode == 4) ApplyMainFilterSort(); else RenderMainPage();   // CD order changes as timers run out
                if (selectedQuest != null && (selectedQuest.CooldownHours > 0 || HasServerTimer(selectedQuest))) RenderDetailPanel();
            }
        }

        // ===================== Edit Quest tab =====================
        // Reads and writes QuestDatabase.xml directly (attribute text as written, so "40+" stays "40+").

        private static readonly string[] EditAttrOrder =
        {
            "name", "link", "startTown", "questGiver", "repeatable", "repeatNote", "cooldownHours", "possibleQb",
            "lockpickRequired", "fellowRequired", "aceRequired", "hasOptionalQb", "minLevel", "recLevel", "timeMinutes", "notes", "ktMobs", "collectItems", "turnInText", "needsReview"
        };

        /// <summary>The name of what you have selected (null and a word in the status line if nothing is).</summary>
        private string SelectedName(bool item)
        {
            try
            {
                int id = CoreManager.Current.Actions.CurrentSelection;
                WorldObject o = id != 0 ? CoreManager.Current.WorldFilter[id] : null;
                if (o != null && !string.IsNullOrEmpty(o.Name)) return o.Name;
            }
            catch { }
            editStatusLabel.Text = item ? "Select the item first." : "Select it first.";
            return null;
        }

        private static string AddToList(string list, string name)
        {
            var parts = new List<string>();
            foreach (string p in (list ?? "").Split(',')) { string t = p.Trim(); if (t.Length > 0) parts.Add(t); }
            if (!parts.Exists(p => string.Equals(p, name, StringComparison.OrdinalIgnoreCase))) parts.Add(name);
            return string.Join(", ", parts.ToArray());
        }

        /// <summary>Where you are, as a quest's start town: the dungeon's name inside one, else the nearest town, village or outpost.</summary>
        private static string HereName()
        {
            try
            {
                uint lc = (uint)CoreManager.Current.Actions.Landcell;
                if ((lc & 0xFFFF) >= 0x100)
                {
                    string d = MelksQuestTracker.Travel.TravelData.AreaName((int)(lc >> 16), "");
                    if (!string.IsNullOrEmpty(d)) return d;
                }
                var here = MelksQuestTracker.Travel.Travel.Here();
                if (!here.Valid) return "";
                string best = ""; double bestD = 8.0;
                foreach (var l in MelksQuestTracker.Travel.TravelData.Locs)
                {
                    if (l.Area >= 0 || !l.At.Valid) continue;
                    string t = l.Type ?? "";
                    if (t.IndexOf("Town", StringComparison.OrdinalIgnoreCase) < 0 && t.IndexOf("Village", StringComparison.OrdinalIgnoreCase) < 0 && t.IndexOf("Outpost", StringComparison.OrdinalIgnoreCase) < 0) continue;
                    double dist = l.At.DistanceTo(here);
                    if (dist < bestD) { bestD = dist; best = l.Name; }
                }
                return best;
            }
            catch { return ""; }
        }

        /// <summary>Shows a quest on the Quest tab.</summary>
        private void OpenQuestTab(QuestDefinition q)
        {
            if (q == null) return;
            QuestPage.Navigate(q);
            RunQuestFind();
            nbMain.ActiveTab = QUEST_TAB;
        }

        private Dictionary<string, QuestDefinition> _linkQuests;
        private int _linkQuestsVer = -1;

        /// <summary>The quest a wiki link points at (its page, or its name), or null.</summary>
        private QuestDefinition QuestForLink(string target)
        {
            if (string.IsNullOrEmpty(target)) return null;
            // rebuilt after every load / save (the list is the same object, refilled)
            if (_linkQuests == null || _linkQuestsVer != QuestDatabase.LoadCount || _linkQuests.Count == 0)
            {
                _linkQuestsVer = QuestDatabase.LoadCount;
                _linkQuests = new Dictionary<string, QuestDefinition>(StringComparer.OrdinalIgnoreCase);
                foreach (QuestDefinition q in QuestDatabase.Quests)
                {
                    string wp = WikiView.Straight(q.WikiPage);
                    if (!string.IsNullOrEmpty(wp) && !_linkQuests.ContainsKey(wp)) _linkQuests[wp] = q;
                    string n = WikiView.Straight(Words(q.Name));
                    if (!_linkQuests.ContainsKey(n)) _linkQuests[n] = q;
                }
            }
            QuestDefinition r;
            return _linkQuests.TryGetValue(WikiView.Straight(target.Replace('_', ' ').Trim()), out r) ? r : null;   // ’ and ' the same
        }

        private void RunQuestFind()
        {
            try
            {
                string[] words = Words(SafeText(questFindInput)).ToLowerInvariant().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                questFindResults = new List<QuestDefinition>();
                foreach (QuestDefinition q in QuestDatabase.Quests)
                {
                    string n = Words(q.Name).ToLowerInvariant();
                    bool all = true;
                    foreach (string w in words) if (n.IndexOf(w, StringComparison.Ordinal) < 0) { all = false; break; }
                    if (all) questFindResults.Add(q);
                }
                questFindResults.Sort((a, b) => string.Compare(Words(a.Name), Words(b.Name), StringComparison.OrdinalIgnoreCase));
                if (questFindResults.Count > 400) questFindResults.RemoveRange(400, questFindResults.Count - 400);
                // the pinned ones at the top, whatever's searched for (in name order among themselves)
                List<QuestDefinition> pins = QuestDatabase.Quests.FindAll(q => QuestPage.Pinned.Contains(q.Name));
                pins.Sort((a, b) => string.Compare(Words(a.Name), Words(b.Name), StringComparison.OrdinalIgnoreCase));
                questFindResults.RemoveAll(q => QuestPage.Pinned.Contains(q.Name));
                questFindResults.InsertRange(0, pins);
                lstQuestFind.Clear();
                foreach (QuestDefinition q in questFindResults)
                {
                    IListRow row = lstQuestFind.AddRow();
                    bool pin = QuestPage.Pinned.Contains(q.Name);
                    row[0][0] = (pin ? "[pinned] " : "") + Words(q.Name);
                    row[1][0] = q.CompletedCount + " / " + q.QbFlags.Count;
                    row[2][0] = string.IsNullOrEmpty(q.Wiki) ? "no guide" : "guide";
                    System.Drawing.Color c = q == QuestPage.Current ? System.Drawing.Color.LimeGreen : q.QbFlags.Count > 0 && q.CompletedCount >= q.QbFlags.Count ? System.Drawing.Color.FromArgb(120, 200, 120) : System.Drawing.Color.Empty;
                    if (c.IsEmpty && pin) c = System.Drawing.Color.FromArgb(255, 205, 80);
                    if (!c.IsEmpty) row[0][1] = c;
                    if (string.IsNullOrEmpty(q.Wiki)) row[2][1] = System.Drawing.Color.Gray;
                }
            }
            catch (Exception ex) { Util.WriteToChat($"RunQuestFind Error: {ex}"); }
        }

        private void RunEditFind()
        {
            try
            {
                string[] words = Words(SafeText(editFindInput)).ToLowerInvariant().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                editFindResults = new List<QuestDefinition>();
                foreach (QuestDefinition q in QuestDatabase.Quests)
                {
                    string n = Words(q.Name).ToLowerInvariant();
                    bool all = true;
                    foreach (string w in words) if (n.IndexOf(w, StringComparison.Ordinal) < 0) { all = false; break; }
                    if (all) editFindResults.Add(q);
                    if (editFindResults.Count >= 300) break;
                }
                editFindResults.Sort((a, b) => string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase));
                lstEditFind.Clear();
                foreach (QuestDefinition q in editFindResults)
                {
                    IListRow row = lstEditFind.AddRow();
                    row[0][0] = q.Name;
                    row[1][0] = q.PossibleQb + " QB";
                    row[2][0] = q.QbFlags.Count + " flags";
                    if (q.Name == editOrigName) row[0][1] = System.Drawing.Color.LimeGreen;
                }
            }
            catch (Exception ex) { Util.WriteToChat($"RunEditFind Error: {ex}"); }
        }

        /// <summary>Fills the editor from the quest's entry in QuestDatabase.xml (null = a blank new quest).</summary>
        private void LoadEditor(string questName)
        {
            try
            {
                Dictionary<string, string> a = new Dictionary<string, string>();
                editFlags = new List<string>();
                editOrigName = null;
                editFromReviewGroup = null; editFromReviewFlags = null;
                if (questName != null)
                {
                    XmlDocument doc = new XmlDocument();
                    Util.LoadXml(doc, questDbPath);
                    XmlNode n = FindQuestNode(doc, questName);
                    if (n == null) { editStatusLabel.Text = "Not found in QuestDatabase.xml: " + questName; return; }
                    foreach (XmlAttribute at in n.Attributes) a[at.Name] = at.Value;
                    foreach (XmlNode f in n.SelectNodes("Flag")) { string t = (f.InnerText ?? "").Trim(); if (t.Length > 0) editFlags.Add(t); }
                    editOrigName = questName;
                }
                WikiEditor.Load(questName, questName == null ? null : QuestDatabase.Quests.Find(x => x.Name == questName));
                Func<string, string> A = k => a.ContainsKey(k) ? a[k] : "";
                Func<string, bool> AB = k => string.Equals(A(k), "true", StringComparison.OrdinalIgnoreCase);
                editName.Text = A("name"); editLink.Text = A("link"); editTown.Text = A("startTown"); editGiver.Text = A("questGiver");
                editQb.Text = A("possibleQb"); editMinLvl.Text = A("minLevel"); editRecLvl.Text = A("recLevel"); editTime.Text = A("timeMinutes");
                editRepeatNote.Text = A("repeatNote"); editCooldown.Text = A("cooldownHours"); editNotes.Text = A("notes"); editKtMobs.Text = A("ktMobs");
                if (editCollect != null) editCollect.Text = A("collectItems");
                if (editTurnIn != null) editTurnIn.Text = A("turnInText");
                editRepeatable.Checked = AB("repeatable"); editLockpick.Checked = AB("lockpickRequired"); editFellow.Checked = AB("fellowRequired");
                editAce.Checked = AB("aceRequired"); editOptional.Checked = AB("hasOptionalQb"); if (editReview != null) editReview.Checked = AB("needsReview");
                editFlagInput.Text = "";
                editHeaderLbl.Text = questName == null ? "New quest - fill it in and Save" : "Editing: " + questName;
                editStatusLabel.Text = "";
                editDeleteArmedUntil = DateTime.MinValue;
                RenderEditFlags();
                RenderNewFlags();
                RunEditFind();
            }
            catch (Exception ex) { editStatusLabel.Text = "Load failed: " + ex.Message; Util.LogError(ex); }
        }

        private void RenderEditFlags()
        {
            lstEditFlags.Clear();
            foreach (string f in editFlags)
            {
                FlagState st;
                bool known = ProgressStore.Flags.TryGetValue(f, out st);
                IListRow row = lstEditFlags.AddRow();
                row[0][0] = false;
                row[1][0] = f;
                row[2][0] = known ? (st == FlagState.Completed ? "done" : "in progress") : "-";
                row[2][1] = known ? (st == FlagState.Completed ? System.Drawing.Color.LimeGreen : System.Drawing.Color.Gold) : System.Drawing.Color.Gray;
            }
        }

        /// <summary>Adds the typed flag(s) - several at once separated by commas (some flag names have spaces in them).</summary>
        private void AddEditFlags()
        {
            string[] parts = SafeText(editFlagInput).Split(new[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries);
            int added = 0;
            foreach (string p0 in parts)
            {
                string f = p0.Trim();
                if (f.Length == 0 || editFlags.Exists(x => string.Equals(x, f, StringComparison.OrdinalIgnoreCase))) continue;
                editFlags.Add(f); added++;
                List<QuestDefinition> owners;
                if (QuestDatabase.FlagToQuests.TryGetValue(f, out owners))
                    foreach (QuestDefinition o in owners)
                        if (o.Name != editOrigName) editStatusLabel.Text = f + " is already in " + o.Name + " - saving puts it in both.";
            }
            editFlagInput.Text = "";
            RenderEditFlags();
            if (added > 0 && !editStatusLabel.Text.Contains("already in")) editStatusLabel.Text = "Added " + added + " flag" + (added == 1 ? "" : "s") + " (not saved yet).";
        }

        private void RemoveTickedEditFlags()
        {
            List<string> keep = new List<string>();
            int removed = 0;
            for (int i = 0; i < lstEditFlags.RowCount && i < editFlags.Count; i++)
            {
                object v = lstEditFlags[i][0][0];
                if (v is bool && (bool)v) removed++; else keep.Add(editFlags[i]);
            }
            editFlags = keep;
            RenderEditFlags();
            editStatusLabel.Text = removed == 0 ? "Tick the flags to remove first." : "Removed " + removed + " (not saved yet).";
        }

        private void BackupQuestDb()
        {
            if (!questDbBackedUp && File.Exists(questDbPath)) { File.Copy(questDbPath, questDbPath + ".bak", true); questDbBackedUp = true; }
        }

        /// <summary>Writes the editor into QuestDatabase.xml (replacing the quest, or adding a new one) and reloads everything.</summary>
        private void SaveEditor()
        {
            Util.Locked(questDbPath, () => SaveEditor_Locked());   // another client may be writing it too
        }

        private void SaveEditor_Locked()
        {
            try
            {
                string name = SafeText(editName).Trim();
                if (name.Length == 0) { editStatusLabel.Text = "A quest needs a name."; return; }

                XmlDocument doc = new XmlDocument();
                Util.LoadXml(doc, questDbPath);
                XmlNode root = doc.SelectSingleNode("/QuestDatabase");
                if (root == null) { editStatusLabel.Text = "QuestDatabase.xml has no <QuestDatabase> root."; return; }
                XmlNode node = editOrigName == null ? null : FindQuestNode(doc, editOrigName);
                XmlNode clash = FindQuestNode(doc, name);
                if (clash != null && clash != node && node == null && editFromReviewGroup != null && clash == FindQuestNode(doc, editFromReviewGroup))
                {
                    // Same name as the review group it came from: fine when every flag of the group is going into it - the group becomes the quest.
                    bool all = true;
                    foreach (XmlNode f in clash.SelectNodes("Flag"))
                        if (!editFlags.Exists(x => string.Equals(x, (f.InnerText ?? "").Trim(), StringComparison.OrdinalIgnoreCase))) all = false;
                    if (!all) { editStatusLabel.Text = "The review group is also called " + name + " - give the quest a different name (or take all its flags)."; return; }
                    node = clash;
                    editFromReviewGroup = null; editFromReviewFlags = null;
                }
                if (clash != null && clash != node) { editStatusLabel.Text = "There's already a quest called " + name + "."; return; }

                Dictionary<string, string> v = new Dictionary<string, string>
                {
                    { "name", name }, { "link", SafeText(editLink).Trim() }, { "startTown", SafeText(editTown).Trim() },
                    { "questGiver", SafeText(editGiver).Trim() }, { "repeatable", editRepeatable.Checked ? "true" : "false" },
                    { "repeatNote", SafeText(editRepeatNote).Trim() }, { "cooldownHours", SafeText(editCooldown).Trim() },
                    { "possibleQb", Num(SafeText(editQb), "0") }, { "lockpickRequired", editLockpick.Checked ? "true" : "false" },
                    { "fellowRequired", editFellow.Checked ? "true" : "false" }, { "aceRequired", editAce.Checked ? "true" : "false" },
                    { "hasOptionalQb", editOptional.Checked ? "true" : "false" }, { "minLevel", Num(SafeText(editMinLvl), "0.0") },
                    { "recLevel", Num(SafeText(editRecLvl), "0.0") }, { "timeMinutes", Num(SafeText(editTime), "0.0") },
                    { "notes", SafeText(editNotes).Trim() }, { "needsReview", editReview != null && editReview.Checked ? "true" : "false" },
                    { "ktMobs", SafeText(editKtMobs).Trim() },
                    { "collectItems", editCollect != null ? SafeText(editCollect).Trim() : "" },
                    { "turnInText", editTurnIn != null ? SafeText(editTurnIn).Trim() : "" },
                };

                // A fresh element with the attributes in the usual order (existing unknown attributes are kept at the end).
                XmlElement q = doc.CreateElement("Quest");
                foreach (string k in EditAttrOrder)
                    if ((k != "cooldownHours" && k != "ktMobs" && k != "collectItems" && k != "turnInText") || v[k].Length > 0) q.SetAttribute(k, v[k]);
                if (node != null)
                    foreach (XmlAttribute at in node.Attributes)
                        if (Array.IndexOf(EditAttrOrder, at.Name) < 0) q.SetAttribute(at.Name, at.Value);
                foreach (string f in editFlags) { XmlElement fe = doc.CreateElement("Flag"); fe.InnerText = f; q.AppendChild(fe); }
                // the walkthrough (edited in its window, or as it was)
                string wiki = WikiEditor.ToStored(WikiEditor.Text ?? "").Trim();
                // a new quest (no walkthrough yet), or one made that way: its header and stamps list filled in from the quest
                string auto = AutoWiki(wiki, v, editFlags);
                if (auto != wiki)
                {
                    wiki = auto;
                    WikiEditor.Text = WikiEditor.ToEdit(wiki);
                }
                if (wiki.Length > 0)
                {
                    XmlElement we = doc.CreateElement("Wiki");
                    string page = WikiEditor.Page;
                    if (string.IsNullOrEmpty(page) && node != null) { XmlNode ow = node.SelectSingleNode("Wiki"); if (ow != null && ow.Attributes["page"] != null) page = ow.Attributes["page"].Value; }
                    if (!string.IsNullOrEmpty(page)) we.SetAttribute("page", page);
                    we.InnerText = wiki;
                    q.AppendChild(we);
                }
                WikiEditor.Loaded = WikiEditor.Text;

                BackupQuestDb();
                if (node != null) root.ReplaceChild(q, node); else root.AppendChild(q);

                // Made from a [REVIEW] group: the saved flags leave that group (and an emptied group goes away).
                int fromReview = 0; bool groupDone = false; string groupName = editFromReviewGroup;
                if (node == null && editFromReviewGroup != null)
                {
                    XmlNode grp = FindQuestNode(doc, editFromReviewGroup);
                    if (grp != null && grp != q)
                    {
                        foreach (XmlNode f in new List<XmlNode>(EnumNodes(grp.SelectNodes("Flag"))))
                        {
                            string fn = (f.InnerText ?? "").Trim();
                            if (editFlags.Exists(x => string.Equals(x, fn, StringComparison.OrdinalIgnoreCase))) { grp.RemoveChild(f); fromReview++; }
                        }
                        if (grp.SelectNodes("Flag").Count == 0) { grp.ParentNode.RemoveChild(grp); groupDone = true; }
                    }
                    editFromReviewGroup = null; editFromReviewFlags = null;
                }
                Util.SaveXml(doc, questDbPath);

                // A renamed quest keeps its repeat timer.
                DateTime t;
                if (editOrigName != null && editOrigName != name && ProgressStore.QuestDone.TryGetValue(editOrigName, out t))
                {
                    ProgressStore.QuestDone.Remove(editOrigName);
                    ProgressStore.QuestDone[name] = t;
                    ProgressStore.Save(progressPath, characterKey);
                }

                bool wasNew = editOrigName == null;
                ReloadQuestDbEverywhere();
                editOrigName = name;
                editHeaderLbl.Text = "Editing: " + name;
                RunEditFind();
                editStatusLabel.Text = (wasNew ? "Added " : "Saved ") + name + " (" + editFlags.Count + " flags)." +
                    (fromReview > 0 ? " Took " + fromReview + " from review group " + Words(groupName) + (groupDone ? " (group done)." : ".") : "");
            }
            catch (Exception ex) { editStatusLabel.Text = "Save failed: " + ex.Message; Util.LogError(ex); }
        }

        private const string StampsHeading = "H2|QB Stamps";

        /// <summary>
        /// A walkthrough for a new quest: the header (I| lines) from the quest's details, the usual sections, and its flags as
        /// a stamps list at the bottom. On later saves (a walkthrough with the stamps list) only what's missing is added -
        /// a header line with nothing in it gets its value, a new flag joins the list - nothing written in it is changed.
        /// </summary>
        /// <summary>The editor's fields now, as the quest's attributes.</summary>
        private Dictionary<string, string> EditorValues()
        {
            return new Dictionary<string, string>
            {
                { "name", SafeText(editName).Trim() }, { "startTown", SafeText(editTown).Trim() }, { "questGiver", SafeText(editGiver).Trim() },
                { "repeatable", editRepeatable.Checked ? "true" : "false" }, { "repeatNote", SafeText(editRepeatNote).Trim() },
                { "cooldownHours", SafeText(editCooldown).Trim() }, { "possibleQb", SafeText(editQb).Trim() },
                { "fellowRequired", editFellow.Checked ? "true" : "false" }, { "minLevel", SafeText(editMinLvl).Trim() },
                { "recLevel", SafeText(editRecLvl).Trim() }, { "timeMinutes", SafeText(editTime).Trim() }, { "notes", SafeText(editNotes).Trim() },
                { "ktMobs", SafeText(editKtMobs).Trim() }, { "collectItems", editCollect != null ? SafeText(editCollect).Trim() : "" },
                { "turnInText", editTurnIn != null ? SafeText(editTurnIn).Trim() : "" },
            };
        }

        private static readonly string[] TemplateSections = { "H2|Overview", "H2|Walkthrough & Notes", "H2|Dungeons & Maps", "H2|Rewards", "H2|Dialog" };

        private static string AutoWiki(string wiki, Dictionary<string, string> v, List<string> flags, bool force = false)
        {
            try
            {
                bool fresh = wiki.Trim().Length == 0;
                if (!fresh && !force && wiki.IndexOf(StampsHeading, StringComparison.Ordinal) < 0) return wiki;
                Func<string, string> V = k => v.ContainsKey(k) ? (v[k] ?? "").Trim() : "";
                Func<string, double> D = k => { double d; return double.TryParse(V(k), System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d) ? d : 0; };
                Func<string, string> Link = t => t.Length == 0 || t.Contains("«") ? t : "«" + t + "»";
                var head = new List<KeyValuePair<string, string>>();
                head.Add(new KeyValuePair<string, string>("Level", D("minLevel") > 0 ? D("minLevel").ToString("0") : "Any"));
                if (D("recLevel") > 0) head.Add(new KeyValuePair<string, string>("Rec. Level", D("recLevel").ToString("0") + "+"));
                head.Add(new KeyValuePair<string, string>("Type", V("fellowRequired") == "true" ? "Fellowship" : "Solo"));
                head.Add(new KeyValuePair<string, string>("Starts With", Link(V("questGiver"))));
                head.Add(new KeyValuePair<string, string>("Starts At", Link(V("startTown"))));
                string rep = "";
                if (V("repeatable") == "true")
                {
                    if (D("cooldownHours") > 0) rep = D("cooldownHours").ToString("0.##") + " Hours";
                    else if (V("repeatNote").Length > 0) rep = System.Text.RegularExpressions.Regex.Replace(V("repeatNote"), "^(\\d+(?:\\.\\d+)?)\\s*h(?:r|rs|ours?)?$", "$1 Hours", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                    else rep = "Yes";
                }
                else rep = "No";
                head.Add(new KeyValuePair<string, string>("Repeat", rep));
                if (V("ktMobs").Length > 0) head.Add(new KeyValuePair<string, string>("Kill Task", "Yes"));
                if (D("possibleQb") > 0) head.Add(new KeyValuePair<string, string>("QB", D("possibleQb").ToString("0")));
                if (D("timeMinutes") > 0) head.Add(new KeyValuePair<string, string>("Time", D("timeMinutes").ToString("0") + " min"));

                if (fresh)
                {
                    var sb = new System.Text.StringBuilder();
                    foreach (var kv in head) if (kv.Value.Length > 0) sb.Append("I|").Append(kv.Key).Append('|').Append(kv.Value).Append('\n');
                    sb.Append("H2|Overview\n");
                    sb.Append("P|").Append(V("notes")).Append("\n\n");
                    sb.Append("H2|Walkthrough & Notes\n");
                    sb.Append("L|1|1.|").Append(V("questGiver").Length > 0 ? "Talk with " + Link(V("questGiver")) + "." : "").Append("\n");
                    if (V("ktMobs").Length > 0) sb.Append("L|1|2.|Kill ").Append(V("ktMobs")).Append(".\n");
                    if (V("collectItems").Length > 0) sb.Append("L|1|").Append(V("ktMobs").Length > 0 ? "3." : "2.").Append("|Collect ").Append(V("collectItems")).Append(".\n");
                    sb.Append("\nH2|Dungeons & Maps\nP|\n\nH2|Rewards\nR|\nRE\n\nH2|Dialog\nP|");
                    if (V("turnInText").Length > 0) sb.Append("⸨").Append(V("turnInText")).Append("⸩");
                    sb.Append("\n\n").Append(StampsHeading).Append('\n');
                    foreach (string f in flags) sb.Append("L|1|•|⟦").Append(f).Append("⟧\n");
                    return sb.ToString().TrimEnd();
                }

                // later saves: fill what's missing, change nothing written
                var lines = new List<string>(wiki.Replace("\r\n", "\n").Split('\n'));
                int lastInfo = -1;
                for (int i = 0; i < lines.Count && (lines[i].StartsWith("I|") || lines[i].Trim().Length == 0); i++) if (lines[i].StartsWith("I|")) lastInfo = i;
                foreach (var kv in head)
                {
                    if (kv.Value.Length == 0) continue;
                    int at = lines.FindIndex(l => l.StartsWith("I|" + kv.Key + "|"));
                    if (at >= 0)
                    {
                        if (lines[at].Substring(("I|" + kv.Key + "|").Length).Trim().Length == 0) lines[at] = "I|" + kv.Key + "|" + kv.Value;
                    }
                    else lines.Insert(++lastInfo, "I|" + kv.Key + "|" + kv.Value);
                }
                if (force)
                {
                    // (asked for: the template's sections that aren't there yet go on the end, and the stamps list)
                    foreach (string sec in TemplateSections)
                        if (!lines.Exists(l => l.Trim().Equals(sec, StringComparison.OrdinalIgnoreCase))) { lines.Add(""); lines.Add(sec); lines.Add(sec == "H2|Rewards" ? "R|" : "P|"); if (sec == "H2|Rewards") lines.Add("RE"); }
                    if (!lines.Exists(l => l.Trim() == StampsHeading)) { lines.Add(""); lines.Add(StampsHeading); }
                }
                int st = lines.FindIndex(l => l.Trim() == StampsHeading);
                if (st >= 0)
                {
                    int end = st + 1;
                    while (end < lines.Count && !lines[end].StartsWith("H2|")) end++;
                    int insertAt = end;
                    while (insertAt > st + 1 && lines[insertAt - 1].Trim().Length == 0) insertAt--;
                    string section = string.Join("\n", lines.GetRange(st, end - st).ToArray());
                    foreach (string f in flags)
                        if (section.IndexOf("⟦" + f + "⟧", StringComparison.OrdinalIgnoreCase) < 0) lines.Insert(insertAt++, "L|1|•|⟦" + f + "⟧");
                }
                return string.Join("\n", lines.ToArray()).TrimEnd();
            }
            catch (Exception ex) { Util.LogError(ex); return wiki; }
        }

        /// <summary>Delete needs two clicks within 5 seconds.</summary>
        private void DeleteEditorQuest()
        {
            Util.Locked(questDbPath, () => DeleteEditorQuest_Locked());   // another client may be writing it too
        }

        private void DeleteEditorQuest_Locked()
        {
            try
            {
                if (editOrigName == null) { editStatusLabel.Text = "Nothing to delete - this quest isn't saved yet."; return; }
                if (DateTime.Now > editDeleteArmedUntil)
                {
                    editDeleteArmedUntil = DateTime.Now.AddSeconds(5);
                    editStatusLabel.Text = "Click Delete quest again within 5s to delete " + editOrigName + ".";
                    return;
                }
                XmlDocument doc = new XmlDocument();
                Util.LoadXml(doc, questDbPath);
                XmlNode node = FindQuestNode(doc, editOrigName);
                if (node == null) { editStatusLabel.Text = "Already gone from QuestDatabase.xml."; return; }
                BackupQuestDb();
                node.ParentNode.RemoveChild(node);
                Util.SaveXml(doc, questDbPath);
                string gone = editOrigName;
                ReloadQuestDbEverywhere();
                LoadEditor(null);
                editStatusLabel.Text = "Deleted " + gone + ". (QuestDatabase.xml.bak has the version from before this session's first change.)";
            }
            catch (Exception ex) { editStatusLabel.Text = "Delete failed: " + ex.Message; Util.LogError(ex); }
        }

        /// <summary>"275" stays "275", "40+" stays "40+", blank becomes the default, junk is refused (kept as default).</summary>
        private static string Num(string s, string dflt)
        {
            s = (s ?? "").Trim();
            if (s.Length == 0) return dflt;
            return System.Text.RegularExpressions.Regex.IsMatch(s, @"^\d+(\.\d+)?\+?$") ? s : dflt;
        }

        private void ReloadQuestDbEverywhere()
        {
            QuestDatabase.Load(questDbPath);
            QuestDatabase.RecalculateProgress();
            string sel = selectedQuest != null ? selectedQuest.Name : null;
            selectedQuest = sel == null ? null : QuestDatabase.Quests.Find(x => x.Name == sel);
            reviewBucket = null; reviewTarget = null;
            RenderReviewList();
            RenderNewFlags();
            ktDirty = true;   // KT mobs may have changed
            ApplyMainFilterSort();
            ApplyFlagFilter();
            RenderDetailPanel();
        }

        // ---- new flags (seen in /qb list, not in the database) ----

        /// <summary>The colour most known flags have come in so far this collect, or -1.</summary>
        private int DominantCaptureColour()
        {
            int best = -1, n = 0;
            foreach (var kv in captureColors) if (kv.Value > n) { best = kv.Key; n = kv.Value; }
            return best;
        }

        /// <summary>Plausible flag text: one short line, not a chat line or a system sentence.</summary>
        private static bool LooksLikeFlag(string t)
        {
            if (t.Length < 3 || t.Length > 80) return false;
            if (t.IndexOf(" says", StringComparison.OrdinalIgnoreCase) >= 0 || t.IndexOf(" tells you", StringComparison.OrdinalIgnoreCase) >= 0 ||
                t.StartsWith("You ", StringComparison.Ordinal) || t.StartsWith("[", StringComparison.Ordinal) || t.StartsWith("<", StringComparison.Ordinal) ||
                t.IndexOf(": ", StringComparison.Ordinal) >= 0) return false;
            return true;
        }

        // ---- Kill tasks the server times (/myquests) that aren't in QuestDatabase.xml yet ----

        /// <summary>
        /// One Main-list entry per unregistered kill task: "XKillTask" and "XKillTaskStarted" together, named by the
        /// server's description ("Aluvian Beef Kill Task Main Flag" -> "Aluvian Beef Kill Task"). Repeatable, with the
        /// server timer. They drop off as soon as a quest in the database has the flag.
        /// </summary>
        private List<QuestDefinition> UnregisteredKillTasks()
        {
            Dictionary<string, QuestDefinition> byBase = new Dictionary<string, QuestDefinition>(StringComparer.OrdinalIgnoreCase);
            foreach (var kv in ProgressStore.ServerTimers)
            {
                if (!IsKillTaskFlag(kv.Key) || !kv.Value.Repeats || QuestDatabase.AllKnownFlags.Contains(kv.Key)) continue;
                string flag = ProperFlagCase(kv.Key);
                string baseKey = System.Text.RegularExpressions.Regex.Replace(kv.Key, "(started|wait|completed)$", "", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                QuestDefinition q;
                if (!byBase.TryGetValue(baseKey, out q))
                {
                    q = new QuestDefinition { Unregistered = true, Repeatable = true, Name = flag, CooldownHours = kv.Value.RepeatSeconds / 3600.0 };
                    byBase[baseKey] = q;
                }
                q.QbFlags.Add(flag);
                string d = KillTaskTitle(kv.Value.Description);
                bool started = kv.Key.EndsWith("started", StringComparison.OrdinalIgnoreCase);
                if (d.Length > 0 && (!started || q.Name == ProperFlagCase(q.QbFlags[0]))) q.Name = d;   // the main flag's description wins
                if (!started) q.CooldownHours = kv.Value.RepeatSeconds / 3600.0;
            }
            foreach (QuestDefinition q in byBase.Values)
            {
                q.QbFlags.Sort((a, b) => a.Length.CompareTo(b.Length));
                int done = 0, prog = 0;
                foreach (string f in q.QbFlags) { FlagState st; if (ProgressStore.Flags.TryGetValue(f, out st)) { if (st == FlagState.Completed) done++; else prog++; } }
                q.CompletedCount = done; q.InProgressCount = prog;
            }
            return new List<QuestDefinition>(byBase.Values);
        }

        private static string KillTaskTitle(string desc)
        {
            string d = (desc ?? "").Trim();
            d = System.Text.RegularExpressions.Regex.Replace(d, @"\s+(Main Flag|Started)$", "", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (d.IndexOf(' ') < 0) d = System.Text.RegularExpressions.Regex.Replace(d, "(?<=[a-z])(?=[A-Z])", " ");   // "BansheeKillTask" -> "Banshee Kill Task"
            return d;
        }

        /// <summary>/myquests keys are lower case; use the /qb list spelling when the new flags list has it.</summary>
        private static string ProperFlagCase(string key)
        {
            foreach (string k in NewFlagStore.Flags.Keys) if (string.Equals(k, key, StringComparison.OrdinalIgnoreCase)) return k;
            return key;
        }

        /// <summary>Edit Quest from an unregistered kill task: a new quest with its name, flags, repeatable and cooldown filled in.</summary>
        private void LoadEditorFromKillTask(QuestDefinition q)
        {
            LoadEditor(null);
            editName.Text = q.Name;
            editRepeatable.Checked = true;
            if (q.CooldownHours > 0) { editCooldown.Text = q.CooldownHours.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture); editRepeatNote.Text = (q.CooldownHours % 1 == 0 ? q.CooldownHours.ToString("0") + "hr" : Span(TimeSpan.FromHours(q.CooldownHours))); }
            editFlags = new List<string>(q.QbFlags);
            editHeaderLbl.Text = "New quest from kill task - check it and Save";
            RenderEditFlags();
            RenderNewFlags();
        }

        /// <summary>Search text against a flag: every word must appear (case and spaces ignored, so "beef kill" finds AluvianBeefCattleKillTask).</summary>
        private static bool FlagMatches(string flag, string needle)
        {
            string f = flag.Replace(" ", "").ToLowerInvariant();
            foreach (string w in needle.ToLowerInvariant().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries))
                if (f.IndexOf(w) < 0) return false;
            return true;
        }

        // ===================== MyQuests tab =====================

        /// <summary>For the cooldown sort: 0 = still waiting (shortest first), 1 = ready again, 2 = no timer / done for good.</summary>
        /// <summary>Main tab CD sort: 0 counting down, 1 seen counting down and now ready, 2 other ready, 3 no timer.</summary>
        private static int MainCdRank(QuestDefinition q, TimeSpan left)
        {
            if (left == TimeSpan.MinValue) return 3;
            if (left > TimeSpan.Zero) return 0;
            return ProgressStore.Watched.Contains(q.Name) ? 1 : 2;
        }

        private static int CooldownRank(TimeSpan left)
        {
            if (left == TimeSpan.MinValue) return 2;
            return left > TimeSpan.Zero ? 0 : 1;
        }

        private static TimeSpan FlagLeft(ServerTimer t)
        {
            if (t == null || !t.Repeats) return TimeSpan.MinValue;
            return t.ReadyAt - DateTime.Now;
        }

        /// <summary>Every flag /myquests lists. Cooldown sort: waiting shortest to longest, then ready, then done (no repeat).</summary>
        /// <summary>
        /// Every character's repeat timers (MQT_Progress.xml; this character's from memory, so they're current):
        /// ready ones first, then the soonest. Rows: "Character: flag", description, solves, repeat, ready in.
        /// </summary>
        private void RenderAllCharacterTimers()
        {
            List<KeyValuePair<string, KeyValuePair<string, ServerTimer>>> rows = new List<KeyValuePair<string, KeyValuePair<string, ServerTimer>>>();
            string me = CoreManager.Current.CharacterFilter.Name;
            foreach (var kv in ProgressStore.ServerTimers)
                if (kv.Value.Repeats) rows.Add(new KeyValuePair<string, KeyValuePair<string, ServerTimer>>(me, kv));
            try
            {
                if (System.IO.File.Exists(progressPath))
                {
                    System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
                    Util.LoadXml(doc, progressPath);
                    foreach (System.Xml.XmlNode c in doc.SelectNodes("/MQT_Progress/Character"))
                    {
                        string key = c.Attributes["key"] != null ? c.Attributes["key"].Value : "";
                        if (string.Equals(key, characterKey, StringComparison.OrdinalIgnoreCase)) continue;
                        int dash = key.IndexOf('-');
                        string who = dash >= 0 ? key.Substring(dash + 1) : key;
                        foreach (System.Xml.XmlNode t in c.SelectNodes("QFlag"))
                        {
                            try
                            {
                                ServerTimer st = new ServerTimer
                                {
                                    Completed = DateTime.Parse(t.Attributes["completed"].Value, null, System.Globalization.DateTimeStyles.RoundtripKind),
                                    RepeatSeconds = long.Parse(t.Attributes["repeat"].Value),
                                    Solves = int.Parse(t.Attributes["solves"].Value),
                                    MaxSolves = t.Attributes["max"] != null ? int.Parse(t.Attributes["max"].Value) : -1,
                                    Description = t.Attributes["desc"] != null ? t.Attributes["desc"].Value : ""
                                };
                                if (st.Repeats) rows.Add(new KeyValuePair<string, KeyValuePair<string, ServerTimer>>(who, new KeyValuePair<string, ServerTimer>(t.Attributes["name"].Value, st)));
                            }
                            catch { }
                        }
                    }
                }
            }
            catch (Exception ex) { Util.LogError(ex); }
            if (mqNeedle.Length > 0) rows.RemoveAll(r => !FlagMatches(r.Key + " " + r.Value.Key + " " + r.Value.Value.Description, mqNeedle));
            if (mqSortByName) rows.Sort((a, b) => { int c = string.Compare(a.Value.Key, b.Value.Key, StringComparison.OrdinalIgnoreCase); return c != 0 ? c : string.Compare(a.Key, b.Key, StringComparison.OrdinalIgnoreCase); });
            else rows.Sort((a, b) =>
            {
                TimeSpan la = FlagLeft(a.Value.Value), lb = FlagLeft(b.Value.Value);
                bool ra = la <= TimeSpan.Zero, rb = lb <= TimeSpan.Zero;
                if (ra != rb) return ra ? -1 : 1;                   // ready ones first
                int c = la.CompareTo(lb);                            // then the soonest
                return c != 0 ? c : string.Compare(a.Key, b.Key, StringComparison.OrdinalIgnoreCase);
            });
            lstMyQuests.Clear();
            mqShown = new List<string>();
            mqShownT = new List<ServerTimer>();
            int ready = 0, waiting = 0;
            foreach (var r in rows)
            {
                ServerTimer t = r.Value.Value;
                IListRow row = lstMyQuests.AddRow();
                row[0][0] = r.Key + ": " + r.Value.Key;
                row[1][0] = t.Description ?? "";
                row[1][1] = System.Drawing.Color.Silver;
                row[2][0] = t.MaxSolves > 0 ? t.Solves + "/" + t.MaxSolves : t.Solves.ToString();
                row[3][0] = Span(TimeSpan.FromSeconds(t.RepeatSeconds));
                SetMyQuestStatus(row, t);
                mqShown.Add(r.Value.Key);
                mqShownT.Add(t);
                if (FlagLeft(t) > TimeSpan.Zero) waiting++; else ready++;
            }
            mqInfoLbl.Text = ready + " ready  " + waiting + " waiting";
            mqTimersAt = DateTime.Now;
        }

        private void RenderMyQuests()
        {
            try
            {
                if (lstMyQuests == null) return;
                if (mqAllChars) { RenderAllCharacterTimers(); return; }
                List<string> keys = new List<string>();
                foreach (var kv in ProgressStore.ServerTimers)
                {
                    if (mqNeedle.Length > 0 && !FlagMatches(kv.Key + " " + kv.Value.Description, mqNeedle)) continue;
                    keys.Add(kv.Key);
                }
                if (mqSortByName) keys.Sort(StringComparer.OrdinalIgnoreCase);
                else
                {
                    Dictionary<string, TimeSpan> left = new Dictionary<string, TimeSpan>(StringComparer.OrdinalIgnoreCase);
                    foreach (string k in keys) left[k] = FlagLeft(ProgressStore.ServerTimers[k]);
                    keys.Sort((a, b) =>
                    {
                        int ra = CooldownRank(left[a]), rb = CooldownRank(left[b]);
                        if (ra != rb) return ra.CompareTo(rb);
                        if (ra == 0) { int c = left[a].CompareTo(left[b]); if (c != 0) return c; }
                        return string.Compare(a, b, StringComparison.OrdinalIgnoreCase);
                    });
                }
                mqShown = keys;
                mqShownT = keys.ConvertAll(k => ProgressStore.ServerTimers[k]);
                // /myquests keys are lower case: show the spelling the database or /qb list uses.
                Dictionary<string, string> spell = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                foreach (string f in NewFlagStore.Flags.Keys) spell[f] = f;
                foreach (QuestDefinition qd in QuestDatabase.Quests) foreach (string f in qd.QbFlags) spell[f] = f;
                lstMyQuests.Clear();
                int waiting = 0, ready = 0;
                foreach (string k in keys)
                {
                    ServerTimer t = ProgressStore.ServerTimers[k];
                    IListRow row = lstMyQuests.AddRow();
                    string shown;
                    row[0][0] = spell.TryGetValue(k, out shown) ? shown : k;
                    row[1][0] = t.Description ?? "";
                    row[1][1] = System.Drawing.Color.Silver;
                    row[2][0] = t.MaxSolves > 0 ? t.Solves + "/" + t.MaxSolves : t.Solves.ToString();
                    row[3][0] = t.RepeatSeconds > 0 ? Span(TimeSpan.FromSeconds(t.RepeatSeconds)) : "-";
                    SetMyQuestStatus(row, t);
                    TimeSpan l = FlagLeft(t);
                    if (l != TimeSpan.MinValue) { if (l > TimeSpan.Zero) waiting++; else ready++; }
                }
                mqInfoLbl.Text = keys.Count + " flags  " + waiting + " waiting  " + ready + " ready" +
                    (ProgressStore.ServerTimersRead != DateTime.MinValue ? "  (read " + ProgressStore.ServerTimersRead.ToString("h:mm tt") + ")" : "");
                mqTimersAt = DateTime.Now;
            }
            catch (Exception ex) { Util.LogError(ex); }
        }

        private void SetMyQuestStatus(IListRow row, ServerTimer t)
        {
            TimeSpan l = FlagLeft(t);
            if (l == TimeSpan.MinValue) { row[4][0] = "done"; row[4][1] = System.Drawing.Color.Gray; }
            else if (l > TimeSpan.Zero) { row[4][0] = Span(l); row[4][1] = System.Drawing.Color.Orange; }
            else { row[4][0] = "ready"; row[4][1] = System.Drawing.Color.LimeGreen; }
            row[0][1] = l != TimeSpan.MinValue && l <= TimeSpan.Zero ? System.Drawing.Color.LimeGreen : System.Drawing.Color.White;
        }

        /// <summary>Count down in place every 30s (no rebuild, so the scroll position stays).</summary>
        private void RefreshMyQuestTimers()
        {
            mqTimersAt = DateTime.Now;
            if (lstMyQuests == null) return;
            for (int i = 0; i < lstMyQuests.RowCount && i < mqShownT.Count; i++)
            {
                ServerTimer t = mqShownT[i];
                if (t != null && t.RepeatSeconds > 0) SetMyQuestStatus(lstMyQuests[i], t);
            }
        }

        private static bool IsKillTaskFlag(string f) { return f.IndexOf("killtask", StringComparison.OrdinalIgnoreCase) >= 0; }

        /// <summary>The server's repeat timer for a flag (from /myquests), or null when it doesn't repeat.</summary>
        private static ServerTimer RepeatTimer(string f)
        {
            ServerTimer t;
            return ProgressStore.ServerTimers.TryGetValue(f, out t) && t.Repeats ? t : null;
        }

        private static string FlagTimerText(ServerTimer t)
        {
            TimeSpan left = t.ReadyAt - DateTime.Now;
            return left <= TimeSpan.Zero ? "ready" : Span(left);
        }

        /// <summary>
        /// New flags: kill tasks with a server timer first (soonest ready on top), then the rest newest first.
        /// The last column is the /myquests timer ("ready" / "3h12m") when the flag repeats, else done / ...
        /// Kill-task flags are light blue.
        /// </summary>
        private void RenderNewFlags()
        {
            List<string> pending = NewFlagStore.Pending();
            List<string> moved = new List<string>(), kt = new List<string>(), rest = new List<string>();
            foreach (string f in pending)
            {
                if (newFlagsKtOnly && !IsKillTaskFlag(f)) continue;
                if (newFlagsNeedle.Length > 0 && !FlagMatches(f, newFlagsNeedle)) continue;
                if (newFlagsJustMoved.Contains(f)) moved.Add(f);                       // just moved out of a quest: keep on top
                else if (IsKillTaskFlag(f) && RepeatTimer(f) != null) kt.Add(f);
                else rest.Add(f);
            }
            kt.Sort((a, b) => RepeatTimer(a).ReadyAt.CompareTo(RepeatTimer(b).ReadyAt));
            newFlagsShown = new List<string>(moved);
            newFlagsShown.AddRange(kt);
            newFlagsShown.AddRange(rest);

            lstNewFlags.Clear();
            foreach (string f in newFlagsShown)
            {
                IListRow row = lstNewFlags.AddRow();
                row[0][0] = false;
                row[1][0] = f;
                SetNewFlagStatus(row, f);
                if (editFlags.Exists(x => string.Equals(x, f, StringComparison.OrdinalIgnoreCase))) row[1][1] = System.Drawing.Color.Gray;   // already added to this quest (not saved yet)
                else if (newFlagsJustMoved.Contains(f)) row[1][1] = System.Drawing.Color.Gold;                                       // just moved out of a quest
                else if (IsKillTaskFlag(f)) row[1][1] = System.Drawing.Color.LightSkyBlue;                                           // kill task
            }
            newFlagsLbl.Text = "New flags: " + newFlagsShown.Count + (newFlagsNeedle.Length > 0 ? " found" : "") + (kt.Count > 0 ? " (" + kt.Count + " KT timers)" : "") + (qbFlagColor < 0 ? "  (collect once)" : "");
            newFlagsTimersAt = DateTime.Now;
        }

        private void SetNewFlagStatus(IListRow row, string f)
        {
            ServerTimer t = RepeatTimer(f);
            if (t != null)
            {
                string txt = FlagTimerText(t);
                row[2][0] = txt;
                row[2][1] = txt == "ready" ? System.Drawing.Color.LimeGreen : System.Drawing.Color.Orange;
                return;
            }
            FlagState st;
            bool known = ProgressStore.Flags.TryGetValue(f, out st);
            row[2][0] = known ? (st == FlagState.Completed ? "done" : "...") : "";
            row[2][1] = known && st == FlagState.Completed ? System.Drawing.Color.LimeGreen : System.Drawing.Color.Gold;
        }

        /// <summary>Count the timers down in place (no rebuild, so the scroll position and ticks stay).</summary>
        private void RefreshNewFlagTimers()
        {
            newFlagsTimersAt = DateTime.Now;
            for (int i = 0; i < lstNewFlags.RowCount && i < newFlagsShown.Count; i++)
                if (RepeatTimer(newFlagsShown[i]) != null) SetNewFlagStatus(lstNewFlags[i], newFlagsShown[i]);
        }

        /// <summary>Kill-task flags from /myquests with a repeat timer that aren't in the database: add them to the
        /// new flags too (in case /qb list doesn't show them). Returns how many were added.</summary>
        private int AddKillTaskTimersToNewFlags()
        {
            int added = 0;
            foreach (var kv in ProgressStore.ServerTimers)
            {
                if (!IsKillTaskFlag(kv.Key) || !kv.Value.Repeats) continue;
                if (QuestDatabase.AllKnownFlags.Contains(kv.Key) || NewFlagStore.Flags.ContainsKey(kv.Key)) continue;
                NewFlagStore.Flags[kv.Key] = DateTime.Now;
                added++;
            }
            if (added > 0) NewFlagStore.Save();
            return added;
        }

        private List<string> TickedNewFlags()
        {
            List<string> l = new List<string>();
            for (int i = 0; i < lstNewFlags.RowCount && i < newFlagsShown.Count; i++)
            {
                object v = lstNewFlags[i][0][0];
                if (v is bool && (bool)v) l.Add(newFlagsShown[i]);
            }
            return l;
        }

        private void AddTickedNewFlags()
        {
            List<string> t = TickedNewFlags();
            if (t.Count == 0) { editStatusLabel.Text = "Tick the new flags to add first."; return; }
            int added = 0;
            foreach (string f in t)
                if (!editFlags.Exists(x => string.Equals(x, f, StringComparison.OrdinalIgnoreCase))) { editFlags.Add(f); added++; }
            RenderEditFlags();
            RenderNewFlags();
            editStatusLabel.Text = "Added " + added + " flag" + (added == 1 ? "" : "s") + " - Save quest to keep them.";
        }

        private void ForgetTickedNewFlags()
        {
            List<string> t = TickedNewFlags();
            if (t.Count == 0) { editStatusLabel.Text = "Tick the flags to forget first."; return; }
            foreach (string f in t) NewFlagStore.Flags.Remove(f);
            NewFlagStore.Save();
            RenderNewFlags();
            editStatusLabel.Text = "Forgot " + t.Count + " (they come back if /qb list shows them again).";
        }

        // ---- /myquests: the server's repeat timers ----

        private void AskMyQuests()
        {
            if (!ServerMode.MyQuests) return;   // Config: this server has no /myquests
            // read in the last minute (MelkTank asks at login; its answer comes here too): the server would refuse
            // another this soon - what was read is used
            if (ProgressStore.ServerTimersRead != DateTime.MinValue && (DateTime.Now - ProgressStore.ServerTimersRead).TotalSeconds < 65)
            {
                DebugLog("myquests: read " + (int)(DateTime.Now - ProgressStore.ServerTimersRead).TotalSeconds + "s ago - not asked again");
                return;
            }
            // asked only once the /qb list is finished and processed (FinalizeCapture); the first line can take a while
            myQuestsUntil = DateTime.Now.AddMilliseconds(Math.Max(15000, myQuestsIdleMs * 2));
            myQuestsQuiet = true;
            myQuestsSelf = true; myQuestsSelfAt = DateTime.Now;
            try { Util.Command("/myquests"); } finally { myQuestsSelf = false; }
            DebugLog("myquests: asked (quiet), listening until " + myQuestsUntil.ToString("HH:mm:ss.fff"));
        }

        /// <summary>Reads /myquests lines: "flag - 3 solves (1729300000)\"description\" -1 72000". True if any line was one.</summary>
        private bool ReadMyQuests(string text)
        {
            bool any = false;
            foreach (string raw in (text ?? "").Replace("\r", "").Split('\n'))
            {
                string line = raw.Trim();
                System.Text.RegularExpressions.Match m = MyQuestRx.Match(line);
                if (!m.Success) continue;
                any = true;
                long when; long rep = 0; int solves; int max = -1;
                if (m.Groups["max"].Success) int.TryParse(m.Groups["max"].Value, out max);
                long.TryParse(m.Groups["completed"].Value, out when);
                if (m.Groups["repeat"].Success) long.TryParse(m.Groups["repeat"].Value, out rep);
                int.TryParse(m.Groups["solves"].Value, out solves);
                if (when <= 0) continue;
                ProgressStore.ServerTimers[m.Groups["key"].Value] = new ServerTimer
                {
                    Completed = DateTimeOffset.FromUnixTimeSeconds(when).LocalDateTime,
                    RepeatSeconds = rep,
                    Solves = solves,
                    MaxSolves = max,
                    Description = m.Groups["desc"].Success ? m.Groups["desc"].Value.Trim(' ', '"') : ""
                };
                myQuestsRead++;
            }
            if (any) { myQuestsDirty = true; myQuestsUntil = DateTime.Now.AddMilliseconds(myQuestsIdleMs); myQuestsLastLine = DateTime.Now; }   // more lines may follow
            return any;
        }

        private void FinishMyQuests()
        {
            myQuestsDirty = false;
            DebugLog("myquests: done - " + myQuestsRead + " lines read so far");
            ProgressStore.ServerTimersRead = DateTime.Now;
            bool nowDone = ProgressStore.SolvedAreDone(ProgressStore.Flags) > 0;
            ProgressStore.Save(progressPath, characterKey);
            if (nowDone) QuestDatabase.RecalculateProgress();
            int timed = 0;
            foreach (QuestDefinition q in QuestDatabase.Quests) if (HasServerTimer(q)) timed++;
            if (myQuestsQuiet) Util.WriteToChat("Quest timers read: " + timed + " quests with a repeat timer.");
            myQuestsQuiet = false;   // later lines (UtilityBelt's own /myquests) are read but left in chat
            MarkRepeatableFromServer();
            RenderMyQuests();
            ktDirty = true;   // turned-in kill tasks drop off the bounty pop-up
            int ktAdded = AddKillTaskTimersToNewFlags();
            if (ktAdded > 0) Util.WriteToChat("Added " + ktAdded + " kill-task flag" + (ktAdded == 1 ? "" : "s") + " with timers to the new flags list.");
            RenderNewFlags();
            myQuestsRead = 0;
            timerAnnounced.Clear();
            foreach (QuestDefinition q in QuestDatabase.Quests) if (TimerLeft(q) != TimeSpan.MinValue && TimerLeft(q) <= TimeSpan.Zero) timerAnnounced.Add(q.Name);   // already ready - no chat spam
            ApplyMainFilterSort();
            RenderDetailPanel();
        }

        /// <summary>
        /// Kill tasks the server says can be done again (a flag with a wait time and no one-solve cap) but that
        /// QuestDatabase.xml doesn't mark repeatable: set repeatable="true" for them. Only kill tasks ("... Kill Task",
        /// "Kill: ...") - most quests have a server timer, and marking all of them made the Repeatable filter useless.
        /// </summary>
        private void MarkRepeatableFromServer()
        {
            Util.Locked(questDbPath, () => MarkRepeatableFromServer_Locked());   // another client may be writing it too
        }

        private void MarkRepeatableFromServer_Locked()
        {
            try
            {
                List<string> names = new List<string>();
                foreach (QuestDefinition q in QuestDatabase.Quests)
                {
                    if (q.Repeatable || q.NeedsReview || !IsKillTask(q)) continue;
                    foreach (string f in q.QbFlags)
                    {
                        ServerTimer st;
                        if (ProgressStore.ServerTimers.TryGetValue(f, out st) && st.Repeats) { names.Add(q.Name); break; }
                    }
                }
                if (names.Count == 0) return;

                XmlDocument doc = new XmlDocument();
                Util.LoadXml(doc, questDbPath);
                int changed = 0;
                foreach (string n in names)
                {
                    XmlElement node = FindQuestNode(doc, n) as XmlElement;
                    if (node == null) continue;
                    node.SetAttribute("repeatable", "true");
                    changed++;
                }
                if (changed == 0) return;
                BackupQuestDb();
                Util.SaveXml(doc, questDbPath);
                ReloadQuestDbEverywhere();
                Util.WriteToChat("Marked " + changed + " kill task" + (changed == 1 ? "" : "s") + " repeatable in QuestDatabase.xml (the server has repeat timers for them)" +
                                 (changed <= 5 ? ": " + string.Join(", ", names.ToArray()) : "") + ".");
            }
            catch (Exception ex) { Util.WriteToChat("Marking repeatable quests failed: " + ex.Message); Util.LogError(ex); }
        }

        private static bool IsKillTask(QuestDefinition q)
        {
            string n = Words(q.Name).ToLowerInvariant();
            return n.Contains("kill task") || n.StartsWith("kill:");
        }

        // ---- moving a misplaced flag out of a quest ----

        /// <summary>Takes the ticked flags out of the quest (saved right away) and puts them at the top of the new flags list.</summary>
        private void MoveTickedToNewFlags()
        {
            Util.Locked(questDbPath, () => MoveTickedToNewFlags_Locked());   // another client may be writing it too
        }

        private void MoveTickedToNewFlags_Locked()
        {
            try
            {
                if (editOrigName == null) { editStatusLabel.Text = "Open a saved quest first (this one isn't saved yet)."; return; }
                List<string> ticked = new List<string>();
                for (int i = 0; i < lstEditFlags.RowCount && i < editFlags.Count; i++)
                {
                    object v = lstEditFlags[i][0][0];
                    if (v is bool && (bool)v) ticked.Add(editFlags[i]);
                }
                if (ticked.Count == 0) { editStatusLabel.Text = "Tick the flags to move first."; return; }

                XmlDocument doc = new XmlDocument();
                Util.LoadXml(doc, questDbPath);
                XmlNode node = FindQuestNode(doc, editOrigName);
                if (node == null) { editStatusLabel.Text = "Couldn't find " + editOrigName + " in QuestDatabase.xml."; return; }
                foreach (XmlNode f in new List<XmlNode>(EnumNodes(node.SelectNodes("Flag"))))
                    if (ticked.Exists(x => string.Equals(x, (f.InnerText ?? "").Trim(), StringComparison.OrdinalIgnoreCase))) node.RemoveChild(f);
                BackupQuestDb();
                Util.SaveXml(doc, questDbPath);

                newFlagsJustMoved.Clear();
                foreach (string f in ticked)
                {
                    editFlags.RemoveAll(x => string.Equals(x, f, StringComparison.OrdinalIgnoreCase));
                    NewFlagStore.Flags[f] = DateTime.Now;   // newest first: they land at the top
                    newFlagsJustMoved.Add(f);
                }
                NewFlagStore.Save();

                string keep = editOrigName;
                ReloadQuestDbEverywhere();
                editOrigName = keep;
                RenderEditFlags();
                RenderNewFlags();
                lstNewFlags.ScrollPosition = 0;   // show them
                editStatusLabel.Text = "Moved " + ticked.Count + " flag" + (ticked.Count == 1 ? "" : "s") + " out of " + keep + " - they're at the top of New flags (gold).";
            }
            catch (Exception ex) { editStatusLabel.Text = "Move failed: " + ex.Message; Util.LogError(ex); }
        }

        // ===================== Review tab ([REVIEW] flag groups) =====================

        private static string Words(string s) { return (s ?? "").Replace("[REVIEW]", "").Replace('_', ' ').Trim(); }

        private void RenderReviewList()
        {
            if (lstReview == null) return;   // no Review tab
            try
            {
                reviewBuckets = QuestDatabase.Quests.FindAll(q => q.NeedsReview);
                reviewBuckets.Sort((a, b) => string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase));
                lstReview.Clear();
                foreach (QuestDefinition q in reviewBuckets)
                {
                    IListRow row = lstReview.AddRow();
                    row[0][0] = Words(q.Name);
                    row[1][0] = q.QbFlags.Count.ToString();
                    if (q == reviewBucket) { row[0][1] = System.Drawing.Color.Gold; row[1][1] = System.Drawing.Color.Gold; }
                }
                if (reviewBucket != null && !reviewBuckets.Contains(reviewBucket)) reviewBucket = null;
                RenderReviewFlags();
            }
            catch (Exception ex) { Util.WriteToChat($"RenderReviewList Error: {ex}"); }
        }

        private void RenderReviewFlags()
        {
            lstReviewFlags.Clear();
            if (reviewBucket == null) { reviewBucketLabel.Text = reviewBuckets.Count + " groups to sort out - click one"; return; }
            reviewBucketLabel.Text = Words(reviewBucket.Name) + ": " + reviewBucket.QbFlags.Count + " flags (tick some, or none = all)";
            foreach (string f in reviewBucket.QbFlags)
            {
                IListRow row = lstReviewFlags.AddRow();
                row[0][0] = false;
                row[1][0] = f;
            }
        }

        private void OnReviewBucketClick(int row)
        {
            if (row < 0 || row >= reviewBuckets.Count) return;
            reviewBucket = reviewBuckets[row];
            reviewTarget = null;
            reviewTargetLabel.Text = "Target: click a quest above";
            reviewStatusLabel.Text = "";
            RenderReviewList();
            reviewFindInput.Text = Words(reviewBucket.Name);   // a first guess: quests with a similar name
            RunReviewFind();
        }

        private void RunReviewFind()
        {
            try
            {
                string[] words = Words(SafeText(reviewFindInput)).ToLowerInvariant().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                reviewTargets = new List<QuestDefinition>();
                foreach (QuestDefinition q in QuestDatabase.Quests)
                {
                    if (q.NeedsReview) continue;
                    string n = Words(q.Name).ToLowerInvariant();
                    bool all = true;
                    foreach (string w in words) if (n.IndexOf(w, StringComparison.Ordinal) < 0) { all = false; break; }
                    if (all) reviewTargets.Add(q);
                    if (reviewTargets.Count >= 300) break;
                }
                // Nothing for the whole name? Try any one word.
                if (reviewTargets.Count == 0 && words.Length > 1)
                    foreach (QuestDefinition q in QuestDatabase.Quests)
                    {
                        if (q.NeedsReview) continue;
                        string n = Words(q.Name).ToLowerInvariant();
                        foreach (string w in words) if (w.Length >= 4 && n.IndexOf(w, StringComparison.Ordinal) >= 0) { reviewTargets.Add(q); break; }
                        if (reviewTargets.Count >= 300) break;
                    }
                reviewTargets.Sort((a, b) => string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase));
                lstReviewTargets.Clear();
                foreach (QuestDefinition q in reviewTargets)
                {
                    IListRow row = lstReviewTargets.AddRow();
                    row[0][0] = Words(q.Name);
                    row[1][0] = q.QbFlags.Count + " flags";
                    if (q == reviewTarget) row[0][1] = System.Drawing.Color.LimeGreen;
                }
                if (reviewTargets.Count == 0) reviewStatusLabel.Text = "No quest matches - try fewer words.";
            }
            catch (Exception ex) { Util.WriteToChat($"RunReviewFind Error: {ex}"); }
        }

        private void OnReviewTargetClick(int row)
        {
            if (row < 0 || row >= reviewTargets.Count) return;
            reviewTarget = reviewTargets[row];
            reviewTargetLabel.Text = "Target: " + Words(reviewTarget.Name);
            for (int i = 0; i < lstReviewTargets.RowCount && i < reviewTargets.Count; i++)
                lstReviewTargets[i][0][1] = reviewTargets[i] == reviewTarget ? System.Drawing.Color.LimeGreen : System.Drawing.Color.White;
        }

        /// <summary>Moves the ticked flags (or all) of the selected [REVIEW] group into the target quest, in QuestDatabase.xml.</summary>
        private void MoveReviewFlags()
        {
            Util.Locked(questDbPath, () => MoveReviewFlags_Locked());   // another client may be writing it too
        }

        private void MoveReviewFlags_Locked()
        {
            try
            {
                if (reviewBucket == null) { reviewStatusLabel.Text = "Pick a group on the left first."; return; }
                if (reviewTarget == null) { reviewStatusLabel.Text = "Pick the quest they belong to first."; return; }

                List<string> flags = new List<string>();
                for (int i = 0; i < lstReviewFlags.RowCount; i++)
                {
                    object v = lstReviewFlags[i][0][0];
                    if (v is bool && (bool)v) flags.Add(Convert.ToString(lstReviewFlags[i][1][0]));
                }
                if (flags.Count == 0) flags.AddRange(reviewBucket.QbFlags);

                XmlDocument doc = new XmlDocument();
                doc.PreserveWhitespace = false;
                Util.LoadXml(doc, questDbPath);
                XmlNode from = FindQuestNode(doc, reviewBucket.Name), to = FindQuestNode(doc, reviewTarget.Name);
                if (from == null || to == null) { reviewStatusLabel.Text = "Couldn't find those quests in QuestDatabase.xml (edited outside?) - Reload it."; return; }

                if (!questDbBackedUp) { File.Copy(questDbPath, questDbPath + ".bak", true); questDbBackedUp = true; }

                HashSet<string> already = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (XmlNode f in to.SelectNodes("Flag")) already.Add((f.InnerText ?? "").Trim());
                int moved = 0;
                foreach (XmlNode f in new List<XmlNode>(EnumNodes(from.SelectNodes("Flag"))))
                {
                    string name = (f.InnerText ?? "").Trim();
                    if (!flags.Exists(x => string.Equals(x, name, StringComparison.OrdinalIgnoreCase))) continue;
                    from.RemoveChild(f);
                    if (already.Add(name)) { XmlElement e = doc.CreateElement("Flag"); e.InnerText = name; to.AppendChild(e); }
                    moved++;
                }
                bool emptied = from.SelectNodes("Flag").Count == 0;
                if (emptied) from.ParentNode.RemoveChild(from);
                Util.SaveXml(doc, questDbPath);

                string targetName = reviewTarget.Name;
                QuestDatabase.Load(questDbPath);
                QuestDatabase.RecalculateProgress();
                selectedQuest = null;
                reviewBucket = emptied ? null : QuestDatabase.Quests.Find(q => q.Name == (from.Attributes["name"] != null ? from.Attributes["name"].Value : ""));
                reviewTarget = QuestDatabase.Quests.Find(q => q.Name == targetName);
                RenderReviewList();
                RunReviewFind();
                ApplyMainFilterSort();
                ApplyFlagFilter();
                RenderDetailPanel();
                reviewStatusLabel.Text = "Moved " + moved + " flag" + (moved == 1 ? "" : "s") + " to " + Words(targetName) + (emptied ? " - group done." : ".");
            }
            catch (Exception ex) { reviewStatusLabel.Text = "Move failed: " + ex.Message; Util.LogError(ex); }
        }

        /// <summary>
        /// Review tab: start a new quest in the editor from the selected group - its name (without [REVIEW]) and the
        /// ticked flags (none ticked = all). Saving it takes those flags out of the group.
        /// </summary>
        private void NewQuestFromReview()
        {
            try
            {
                if (reviewBucket == null) { reviewStatusLabel.Text = "Pick a group on the left first."; return; }
                List<string> flags = new List<string>();
                for (int i = 0; i < lstReviewFlags.RowCount; i++)
                {
                    object v = lstReviewFlags[i][0][0];
                    if (v is bool && (bool)v) flags.Add(Convert.ToString(lstReviewFlags[i][1][0]));
                }
                if (flags.Count == 0) flags.AddRange(reviewBucket.QbFlags);

                string group = reviewBucket.Name;
                LoadEditor(null);
                editName.Text = Words(group);
                editFlags = new List<string>(flags);
                editFromReviewGroup = group;
                editFromReviewFlags = flags;
                editHeaderLbl.Text = "New quest from review group " + Words(group) + " - fill it in and Save";
                editStatusLabel.Text = flags.Count + " flag" + (flags.Count == 1 ? "" : "s") + " from the review group. Saving takes them out of it.";
                RenderEditFlags();
                RenderNewFlags();
                nbMain.ActiveTab = EDIT_TAB;
            }
            catch (Exception ex) { reviewStatusLabel.Text = "Couldn't start the quest: " + ex.Message; Util.LogError(ex); }
        }

        private static XmlNode FindQuestNode(XmlDocument doc, string name)
        {
            foreach (XmlNode n in doc.SelectNodes("/QuestDatabase/Quest"))
                if (n.Attributes["name"] != null && n.Attributes["name"].Value == name) return n;
            return null;
        }

        private static IEnumerable<XmlNode> EnumNodes(XmlNodeList l) { foreach (XmlNode n in l) yield return n; }

        // ===================== Current QB tab =====================

        private string FlagFilterLabel()
        {
            switch (flagFilterMode)
            {
                case 0: return "All";
                case 1: return "Completed";
                case 2: return "In-Progress";
                default: return "Not Started";
            }
        }

        private void ApplyFlagFilter()
        {
            try
            {
                filteredFlagRows = new List<FlagRowData>();
                string needle = (flagFilterText ?? "").ToLower();

                List<string> allFlags = new List<string>(QuestDatabase.AllKnownFlags);
                allFlags.Sort(StringComparer.OrdinalIgnoreCase);

                foreach (string flag in allFlags)
                {
                    if (needle.Length > 0 && flag.ToLower().IndexOf(needle) < 0) continue;

                    FlagState? state = null;
                    FlagState s;
                    if (ProgressStore.Flags.TryGetValue(flag, out s)) state = s;

                    if (flagFilterMode == 1 && state != FlagState.Completed) continue;
                    if (flagFilterMode == 2 && state != FlagState.InProgress) continue;
                    if (flagFilterMode == 3 && state != null) continue;

                    string questName = "";
                    List<QuestDefinition> owners;
                    if (QuestDatabase.FlagToQuests.TryGetValue(flag, out owners) && owners.Count > 0)
                        questName = owners[0].Name;

                    filteredFlagRows.Add(new FlagRowData { Flag = flag, State = state, QuestName = questName });
                }
                RenderFlagPage();
            }
            catch (Exception ex) { Util.WriteToChat($"ApplyFlagFilter Error: {ex}"); }
        }

        private void RenderFlagPage()
        {
            try
            {
                flagPageInfoLabel.Text = $"{filteredFlagRows.Count} flags";
                lstFlags.Clear();
                foreach (FlagRowData r in filteredFlagRows)
                {
                    IListRow row = lstFlags.AddRow();
                    row[0][0] = r.State == FlagState.Completed ? "done" : r.State == FlagState.InProgress ? "..." : "-";
                    row[0][1] = r.State == FlagState.Completed ? System.Drawing.Color.LimeGreen : r.State == FlagState.InProgress ? System.Drawing.Color.Gold : System.Drawing.Color.Gray;
                    row[1][0] = r.Flag;
                    row[2][0] = r.QuestName;
                }
            }
            catch (Exception ex) { Util.WriteToChat($"RenderFlagPage Error: {ex}"); }
        }

        // ===================== Bounty =====================

        private void ApplyBountySettings()
        {
            if (bountyTracker == null) return;
            bountyTracker.IntervalSeconds = Math.Max(1, bountyMinutes) * 60;
            bountyTracker.Enabled = bountyHudOn;
            if (bountyHud != null) bountyHud.Visible = bountyHudOn;
        }

        private void StopBounty()
        {
            try
            {
                CoreManager.Current.RenderFrame -= Frame_Render;
                CoreManager.Current.CharacterFilter.ChangePortalMode -= Bounty_ChangePortalMode;
                if (bountyHud != null) bountyHud.Dispose();
                bountyHud = null;
                bountyTracker = null;
            }
            catch (Exception ex) { Util.LogError(ex); }
        }

        private void Bounty_ChangePortalMode(object sender, ChangePortalModeEventArgs e)
        {
            try { if (bountyTracker != null && e.Type == PortalEventType.ExitPortal) bountyTracker.AreaChanged(); }
            catch (Exception ex) { Util.LogError(ex); }
        }

        /// <summary>Every game frame: the /qb list capture deadline, the once-a-second UI tick, and the bounty polling.</summary>
        private void Frame_Render(object sender, EventArgs e)
        {
            try
            {
                if (Instance == null) return;   // shut down this frame (a reload): Decal still calls what it had queued
                DateTime now = DateTime.Now;
                TurnIn.Frame();
                if (isinitialized) Backups.Tick(Util.BasePath, Backups.PluginData);   // (the quest database, progress, settings - into Backup\)
                if (isinitialized) Travel.Travel.Tick();
                if (capturing && now >= captureDeadline) { captureDeadline = DateTime.MaxValue; FinalizeCapture(); }
                if (now >= nextUiTick) { nextUiTick = now.AddSeconds(1); UiTick(); }
                if (myQuestsDirty && now >= myQuestsUntil) FinishMyQuests();
                if (now >= itemCountAt) { itemCountAt = now.AddSeconds(3); CountQuestItems(); }
                if (ktDirty) { ktDirty = false; RenderKillTasks(); }
                if (ktSaveWanted) { ktSaveWanted = false; SaveSettings(); }
                if (now >= myQuestsAskAt) { myQuestsAskAt = DateTime.MaxValue; AskMyQuests(); }
                if (mqSearchDirty)
                {
                    mqSearchDirty = false;
                    string n = (SafeText(mqSearch) ?? "").Trim();
                    if (!string.Equals(n, mqNeedle, StringComparison.OrdinalIgnoreCase)) { mqNeedle = n; RenderMyQuests(); }
                }
                if (newFlagsSearchDirty)
                {
                    newFlagsSearchDirty = false;
                    string n = (SafeText(newFlagsSearch) ?? "").Trim();
                    if (!string.Equals(n, newFlagsNeedle, StringComparison.OrdinalIgnoreCase)) { newFlagsNeedle = n; RenderNewFlags(); }
                }
            }
            catch (Exception ex) { Util.LogError(ex); }
        }

        // ===================== Commands =====================

        [BaseEvent("CommandLineText")]
        void Core_CommandLineText(object sender, ChatParserInterceptEventArgs e)
        {
            try
            {
                string text = e.Text;
                if (string.IsNullOrEmpty(text)) return;
                if (bountyTracker != null) bountyTracker.Expect(text);   // /bounty typed: its answer is on the way
                // /qb list typed by hand: capture it like Collect does (and hide the flag lines), but let it go to the server.
                string t0 = text.Trim().ToLowerInvariant();
                if ((t0 == "/qb list" || t0 == "@qb list") && isinitialized && !capturing) StartCapture("Collecting QB list (typed)...");
                // typed by you: shown in chat. Our own quiet one comes through here too now (it's sent so other plugins see
                // it) - that one stays quiet
                if ((t0 == "/myquests" || t0 == "@myquests") && !myQuestsSelf && (DateTime.Now - myQuestsSelfAt).TotalSeconds > 2) { myQuestsUntil = DateTime.Now.AddMilliseconds(Math.Max(15000, myQuestsIdleMs * 2)); myQuestsQuiet = false; }
                Travel.Travel.OnTyped(text);
                if (Travel.Travel.Command(text)) { e.Eat = true; return; }   // GoArrow's /goarrow, /ga
                string[] tokens = text.Split(' ');
                string command = tokens[0].ToLower();
                if (command.StartsWith("@mqt") || command.StartsWith("/mqt") ||
                    command.StartsWith("@MelksQuestTracker") || command.StartsWith("/MelksQuestTracker"))
                {
                    e.Eat = true;
                    if (command.IndexOf("hotreload", StringComparison.OrdinalIgnoreCase) >= 0) return;   // the loader's
                    if (tokens.Length >= 2 && (tokens[1].ToLower() == "travel" || tokens[1].ToLower() == "go"))
                    {
                        Travel.Travel.Run(string.Join(" ", tokens, 2, tokens.Length - 2));
                        return;
                    }
                    ProcessCommand(tokens);
                }
            }
            catch (Exception ex) { Util.WriteToChat($"Command Line Text Error: {ex}"); }
        }

        private void ProcessCommand(string[] tokens)
        {
            try
            {
                if (tokens.Length < 2 || tokens[1].ToLower() == "help")
                {
                    Util.WriteToChat("Melk's Quest Tracker");
                    Util.WriteToChat("/mqt collect - send /qb list and capture the results (60s cooldown)");
                    Util.WriteToChat("/mqt copy - copy known completed/in-progress flags to clipboard");
                    Util.WriteToChat("/mqt reload - reload QuestDatabase.xml from disk");
                    Util.WriteToChat("/mqt reset confirm - wipe saved progress for this character");
                    Util.WriteToChat("/mqt debug [on/off] - toggle debug logging");
                    Util.WriteToChat("/mqt travel <coords or place> (or GoArrow's /ga, /goarrow) - travel; /ga help for more");
                    return;
                }
                string sub = tokens[1].ToLower();
                if (sub == "collect") { TryCollect(); return; }
                if (sub == "copy") { DoCopyToClipboard(); return; }
                if (sub == "reload")
                {
                    QuestDatabase.Load(questDbPath);
                    QuestDatabase.RecalculateProgress();
                    selectedQuest = null;
                    reviewBucket = null; reviewTarget = null;
                    RenderReviewList();
                    ApplyMainFilterSort();
                    ApplyFlagFilter();
                    RenderDetailPanel();
                    return;
                }
                if (sub == "reset")
                {
                    if (tokens.Length >= 3 && tokens[2].ToLower() == "confirm") DoResetProgress();
                    else Util.WriteToChat("This wipes saved QB progress for this character. Type /mqt reset confirm to proceed.");
                    return;
                }
                if (sub == "debug")
                {
                    if (tokens.Length < 3) { enbDebug = !enbDebug; }
                    else if (tokens[2].ToLower() == "on") enbDebug = true;
                    else if (tokens[2].ToLower() == "off") enbDebug = false;
                    debugModeBtn.Checked = enbDebug;
                    SaveSettings();
                    Util.WriteToChat($"Debugging {(enbDebug ? "Enabled" : "Disabled")}");
                    return;
                }
            }
            catch (Exception ex) { Util.WriteToChat($"ProcessCommand Error: {ex}"); }
        }

        // ===================== small helpers =====================

        private string SafeText(ITextBox tb)
        {
            return tb != null && tb.Text != null ? tb.Text : "";
        }

        // Best-effort: sets Enabled via reflection if the control interface exposes it.
        // No-ops (does nothing, throws nothing) if it doesn't - the countdown text on the
        // button label is the guaranteed-to-work fallback regardless.
        private void TrySetEnabled(object control, bool enabled)
        {
            try
            {
                if (control == null) return;
                System.Reflection.PropertyInfo prop = control.GetType().GetProperty("Enabled");
                if (prop != null && prop.CanWrite) prop.SetValue(control, enabled, null);
            }
            catch { /* not supported on this control - text fallback still applies */ }
        }

        // Best-effort text color via reflection - tries a couple of common property names/
        // types seen across the view wrappers' controls. No-ops if none match.
        private void TrySetColor(object control, System.Drawing.Color color)
        {
            try
            {
                if (control == null) return;
                Type t = control.GetType();
                string[] propNames = { "TextColor", "ForeColor", "Color" };
                foreach (string name in propNames)
                {
                    System.Reflection.PropertyInfo prop = t.GetProperty(name);
                    if (prop == null || !prop.CanWrite) continue;
                    if (prop.PropertyType == typeof(System.Drawing.Color))
                    {
                        prop.SetValue(control, color, null);
                        return;
                    }
                    if (prop.PropertyType == typeof(int))
                    {
                        prop.SetValue(control, color.ToArgb(), null);
                        return;
                    }
                }
            }
            catch { /* not supported on this control - [pct%] prefix in the text is the fallback */ }
        }

        private System.Drawing.Color ColorForPercent(double pct)
        {
            if (pct >= 100) return System.Drawing.Color.LimeGreen;
            if (pct >= 50) return System.Drawing.Color.Gold;
            if (pct > 0) return System.Drawing.Color.OrangeRed;
            return System.Drawing.Color.Gray;
        }
    }
}
