using System;
using System.Collections.Generic;
using ImGuiNET;
using Vec2 = System.Numerics.Vector2;
using Vec4 = System.Numerics.Vector4;

namespace MelksQuestTracker
{
    /// <summary>The Quest tab's page: the quest's info box at the top, its walkthrough below - laid out like the wiki.</summary>
    internal static class QuestPage
    {
        public static QuestDefinition Current;
        private static readonly List<QuestDefinition> _back = new List<QuestDefinition>(), _fwd = new List<QuestDefinition>();

        /// <summary>Shows a quest, remembering the one before it for the back arrow.</summary>
        public static void Navigate(QuestDefinition q)
        {
            if (q == null || q == Current) return;
            if (Current != null) { _back.Add(Current); if (_back.Count > 50) _back.RemoveAt(0); }
            _fwd.Clear();
            Current = q;
        }

        private static bool Arrow(string id, ImGuiDir dir, bool enabled, string tip)
        {
            if (!enabled) ImGui.PushStyleVar(ImGuiStyleVar.Alpha, 0.35f);
            bool hit = ImGui.ArrowButton(id, dir);
            if (!enabled) ImGui.PopStyleVar();
            if (enabled && ImGui.IsItemHovered()) Im.SetTooltip(tip);
            return hit && enabled;
        }
        /// <summary>The quests pinned (by name): kept at the top of the quest list until unpinned - saved per character.</summary>
        public static readonly HashSet<string> Pinned = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        /// <summary>A quest pinned or unpinned (the list re-sorted, the pins saved).</summary>
        public static Action PinsChanged;

        // a pin drawn on a square button: gold while pinned, grey when not
        private static bool PinButton(bool pinned)
        {
            float sz = ImGui.GetFrameHeight();
            Vec2 p = ImGui.GetCursorScreenPos();
            bool hit = ImGui.Button("##qpin", new Vec2(sz, sz));
            if (ImGui.IsItemHovered()) Im.SetTooltip(pinned ? "Unpin this quest" : "Pin this quest to the top of the quest list");
            ImDrawListPtr dl = ImGui.GetWindowDrawList();
            uint col = ImGui.GetColorU32(pinned ? new Vec4(1f, 0.8f, 0.3f, 1f) : new Vec4(0.62f, 0.62f, 0.62f, 1f));
            float cx = p.X + sz * 0.5f;
            dl.AddCircleFilled(new Vec2(cx, p.Y + sz * 0.32f), sz * 0.17f, col);                                 // its head
            dl.AddLine(new Vec2(cx - sz * 0.22f, p.Y + sz * 0.50f), new Vec2(cx + sz * 0.22f, p.Y + sz * 0.50f), col, 2f);   // its collar
            dl.AddLine(new Vec2(cx, p.Y + sz * 0.42f), new Vec2(cx, p.Y + sz * 0.86f), col, 1.5f);               // its point
            return hit;
        }

        public static Action<QuestDefinition> Edit;
        public static Action<QuestDefinition> CopyWiki;
        private static QuestDefinition _scrolledFor;

        private static string Words(string s) { return (s ?? "").Replace("[REVIEW]", "").Replace('_', ' ').Trim(); }

        public static void Draw(float w, float h)
        {
            // the outer box doesn't scroll: the title row stays put, the info and walkthrough below it scroll
            if (!ImGui.BeginChild("##questpage", new Vec2(w, h), true, ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoScrollWithMouse)) { ImGui.EndChild(); return; }
            try
            {
                QuestDefinition q = Current;
                if (q == null)
                {
                    Im.TextDisabled("Pick a quest above - or select one on the Main tab and press Open.");
                    return;
                }
                if (!QuestDatabase.Quests.Contains(q))
                {
                    // the database was reloaded (a save, Reload): the same quest's new entry
                    string nm = q.Name;
                    q = Current = QuestDatabase.Quests.Find(x => x.Name == nm);
                    if (q == null) { Im.TextDisabled("That quest isn't in the database any more."); return; }
                    _scrolledFor = q;
                }
                bool toTop = _scrolledFor != q;
                _scrolledFor = q;

                // title + buttons
                Im.TextColored(new Vec4(1f, 0.85f, 0.45f, 1f), Words(q.Name));
                ImGui.SameLine();
                float bx = ImGui.GetContentRegionAvail().X + ImGui.GetCursorPosX() - (q.CollectItems.Count > 0 ? 345 : 270) - ImGui.GetFrameHeight() - 8;
                if (bx > ImGui.GetCursorPosX()) ImGui.SetCursorPosX(bx);
                bool pinned = Pinned.Contains(q.Name);
                if (PinButton(pinned))
                {
                    if (pinned) Pinned.Remove(q.Name); else Pinned.Add(q.Name);
                    if (PinsChanged != null) PinsChanged();
                }
                ImGui.SameLine();
                if (Arrow("##qback", ImGuiDir.Left, _back.Count > 0, _back.Count > 0 ? "Back to " + Words(_back[_back.Count - 1].Name) : ""))
                {
                    _fwd.Insert(0, Current); Current = _back[_back.Count - 1]; _back.RemoveAt(_back.Count - 1);
                }
                ImGui.SameLine();
                if (Arrow("##qfwd", ImGuiDir.Right, _fwd.Count > 0, _fwd.Count > 0 ? "Forward to " + Words(_fwd[0].Name) : ""))
                {
                    _back.Add(Current); Current = _fwd[0]; _fwd.RemoveAt(0);
                }
                ImGui.SameLine();
                if (ImGui.Button("Edit quest") && Edit != null) Edit(q);
                ImGui.SameLine();
                if (ImGui.Button("Copy wiki link") && CopyWiki != null) CopyWiki(q);
                if (q.CollectItems.Count > 0)
                {
                    ImGui.SameLine();
                    if (ImGui.Button(TurnIn.Busy ? "Turning in...##qti" : "Turn in##qti") && !TurnIn.Busy) TurnIn.Start(q);
                    if (ImGui.IsItemHovered())
                    {
                        bool any;
                        List<string> plan = TurnIn.Plan(q, out any);
                        Im.SetTooltip("Gives this quest's items to " + (string.IsNullOrEmpty(q.QuestGiver) ? "the quest giver" : q.QuestGiver) +
                            " (the nearest one, else the NPC you have selected):\n" + string.Join("\n", plan.ToArray()));
                    }
                }
                ImGui.Separator();

                if (ImGui.BeginChild("##questbody", ImGui.GetContentRegionAvail(), false))
                {
                    if (toTop) ImGui.SetScrollY(0);
                    InfoBox(q);

                    if (string.IsNullOrEmpty(q.Wiki))
                    {
                        ImGui.Dummy(new Vec2(1, 8));
                        Im.TextDisabled("No walkthrough for this quest yet - add one with Edit quest > Walkthrough.");
                    }
                    else WikiView.Body(q.Wiki);
                    ImGui.Dummy(new Vec2(1, 10));
                }
                ImGui.EndChild();
            }
            catch (Exception ex) { Util.LogError(ex); }
            finally { ImGui.EndChild(); }
        }

        /// <summary>The quest's info box on its own (the Main tab's right side, on a server without /qb flags).</summary>
        public static void Header(QuestDefinition q, float w, float h)
        {
            if (!ImGui.BeginChild("##questhdr", new Vec2(w, h), true)) { ImGui.EndChild(); return; }
            try
            {
                if (q == null) { Im.TextDisabled("Click a quest for its details."); return; }
                InfoBox(q);
            }
            catch (Exception ex) { Util.LogError(ex); }
            finally { ImGui.EndChild(); }
        }

        private static void Row(string label, string value, Vec4? col = null)
        {
            if (string.IsNullOrEmpty(value)) return;
            ImGui.TableNextRow();
            ImGui.TableSetColumnIndex(0);
            Im.TextColored(WikiView.LabelCol, label);
            ImGui.TableSetColumnIndex(1);
            WikiView.Rich(value, ImGui.GetCursorPosX(), col ?? ImGui.GetStyle().Colors[(int)ImGuiCol.Text]);
        }

        private static void InfoBox(QuestDefinition q)
        {
            List<KeyValuePair<string, string>> info = WikiView.Info(q.Wiki);
            Func<string, bool> has = k => info.Exists(x => string.Equals(x.Key, k, StringComparison.OrdinalIgnoreCase));
            float w = Math.Min(560f, ImGui.GetContentRegionAvail().X);
            if (!ImGui.BeginTable("##info", 2, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit, new Vec2(w, 0))) return;
            ImGui.TableSetupColumn("k", ImGuiTableColumnFlags.WidthFixed, 110);
            ImGui.TableSetupColumn("v", ImGuiTableColumnFlags.WidthStretch);

            // your progress first
            int flags = q.QbFlags.Count, done = q.CompletedCount, prog = q.InProgressCount;
            string qb = done + " / " + flags + " stamps done" + (prog > 0 ? ", " + prog + " started" : "") + (q.PossibleQb > 0 && q.PossibleQb != flags ? "   (" + q.PossibleQb + " QB)" : "");
            if (ServerMode.Ilt) Row("Your QB", qb, flags > 0 && done >= flags ? WikiView.StampDone : done > 0 || prog > 0 ? WikiView.StampPart : (Vec4?)null);

            bool chain = false;
            foreach (KeyValuePair<string, string> kv in info)
            {
                int n;
                if (int.TryParse(kv.Key, out n)) { Row(chain ? "" : "", "   " + n + ". " + kv.Value); continue; }
                if (kv.Key == "Quest Chain") chain = true;
                Row(kv.Key, kv.Value);
            }
            // what the tracker knows that the wiki box doesn't show
            if (!has("Starts At") && !string.IsNullOrEmpty(q.StartTown)) Row("Start town", q.StartTown);
            if (!has("Starts With") && !string.IsNullOrEmpty(q.QuestGiver)) Row("Quest giver", q.QuestGiver);
            if (!has("Level") && q.MinLevel > 0) Row("Level", q.MinLevel.ToString("0"));
            if (!has("Rec. Level") && q.RecLevel > 0) Row("Rec. Level", q.RecLevel.ToString("0"));
            if (!has("Repeat") && (q.Repeatable || !string.IsNullOrEmpty(q.RepeatNote))) Row("Repeat", string.IsNullOrEmpty(q.RepeatNote) ? "Yes" : q.RepeatNote);
            if (!has("Time") && q.TimeMinutes > 0) Row("Time", q.TimeMinutes.ToString("0") + " min");
            List<string> need = new List<string>();
            if (q.LockpickRequired) need.Add("Lockpick");
            if (q.FellowRequired) need.Add("Fellowship");
            if (q.AceRequired) need.Add("Ace");
            if (need.Count > 0) Row("Needs", string.Join(", ", need.ToArray()));
            if (q.KtMobs.Count > 0) Row("KT mobs", string.Join(", ", q.KtMobs.ToArray()));
            if (q.CollectItems.Count > 0)
            {
                List<string> it = new List<string>();
                foreach (KeyValuePair<string, int> kv in q.CollectItems) it.Add(kv.Value > 1 ? kv.Key + " x" + kv.Value : kv.Key);
                Row("Collect", string.Join(", ", it.ToArray()));
            }
            Row("Notes", q.Notes);
            ImGui.EndTable();
        }
    }

    /// <summary>The walkthrough editor the Edit Quest tab opens (its own window). Saved with "Save quest".</summary>
    internal static class WikiEditor
    {
        public static string Text = "";
        public static string Loaded = "";
        public static string Page = "";
        public static string QuestName = "";
        public static bool Open;
        private static int _tab;
        /// <summary>Set by the editor: the walkthrough with the template filled in from the quest's fields (nothing written removed).</summary>
        public static Func<string, string> AutoFill;

        public static bool Changed { get { return (Text ?? "") != (Loaded ?? ""); } }

        public static void Load(string questName, QuestDefinition q)
        {
            QuestName = questName ?? "";
            Text = Loaded = q != null ? ToEdit(q.Wiki ?? "") : "";
            Page = q != null ? (q.WikiPage ?? "") : "";
        }

        private static readonly System.Text.RegularExpressions.Regex ListMk = new System.Text.RegularExpressions.Regex(@"^L\|(\d+)\|•\|", System.Text.RegularExpressions.RegexOptions.Multiline);
        private static readonly System.Text.RegularExpressions.Regex ListStar = new System.Text.RegularExpressions.Regex(@"^L\|(\d+)\|\*\|", System.Text.RegularExpressions.RegexOptions.Multiline);
        private static readonly System.Text.RegularExpressions.Regex StampE = new System.Text.RegularExpressions.Regex(@"⟦([^⟧\n]*)⟧");
        private static readonly System.Text.RegularExpressions.Regex TellE = new System.Text.RegularExpressions.Regex(@"⸨([^⸩\n]*)⸩");

        /// <summary>The game font has no ⟦ ⟧ ⸨ ⸩ • (they show as "?"), so the editor shows them as plain text:
        /// {{stamped|Flag}}, {{tell|text}} and L|n|*|. Saving turns them back.</summary>
        public static string ToEdit(string s)
        {
            // saved files have \r\n line ends; ImGui doesn't show the \r, so joining two lines left it behind (and saving split them again)
            s = (s ?? "").Replace("\r\n", "\n").Replace("\r", "");
            s = StampE.Replace(s, m => "{{stamped|" + m.Groups[1].Value + "}}");
            s = TellE.Replace(s, m => "{{tell|" + m.Groups[1].Value + "}}");
            return ListMk.Replace(s, m => "L|" + m.Groups[1].Value + "|*|");
        }

        public static string ToStored(string s)
        {
            s = WikiView.Normalize((s ?? "").Replace("\r\n", "\n").Replace("\r", ""));
            return ListStar.Replace(s, m => "L|" + m.Groups[1].Value + "|•|");
        }

        public static void Draw(float w, float h)
        {
            if (!Open) return;
            ImGui.SetNextWindowSize(new Vec2(720, 640), ImGuiCond.FirstUseEver);
            bool open = true;
            if (ImGui.Begin("Walkthrough - " + (QuestName.Length > 0 ? QuestName.Replace('_', ' ') : "new quest") + "###mqtwikiedit", ref open))
            {
                if (ImGui.Button(_tab == 0 ? "[Edit]" : "Edit")) _tab = 0;
                ImGui.SameLine();
                if (ImGui.Button(_tab == 1 ? "[Preview]" : "Preview")) _tab = 1;
                ImGui.SameLine();
                if (ImGui.Button("Revert")) Text = Loaded;
                ImGui.SameLine();
                if (ImGui.Button("Auto-fill") && AutoFill != null)
                {
                    try { Text = AutoFill(Text); } catch (Exception ex) { Util.LogError(ex); }
                }
                if (ImGui.IsItemHovered()) ImGui.SetTooltip("Fills in the template from the quest's details: the header, the usual sections and the stamps list.\nOn a walkthrough already written, only what's missing is added - nothing is changed or removed.");
                ImGui.SameLine();
                if (ImGui.Button("Done")) open = false;
                ImGui.SameLine();
                Im.TextColored(Changed ? new Vec4(1f, 0.8f, 0.3f, 1f) : new Vec4(0.6f, 0.6f, 0.6f, 1f), Changed ? "changed - Save quest to keep it" : "no changes");
                if (_tab == 0)
                {
                    Im.TextDisabled("Lines: I|label|value (info box)  H2|heading  H3|sub-heading  P|text  * or # list item  L|depth|1.|text");
                    Im.TextDisabled("TH|a<tab>b / TR|a<tab>b / TE (table)   R|title  RK|Luminance|800,000  RI|item  RE (rewards box)");
                    Im.TextDisabled("In text: [[Page]] or [[Page|text]] link   {{stamped|Flag}} stamp   {{tell|text}} NPC line   **bold**   {OPT} {WARN} {TIP}");
                    string t = Text ?? "";
                    ImGui.InputTextMultiline("##wikitext", ref t, 1024 * 256, ImGui.GetContentRegionAvail());
                    Text = t;
                }
                else
                {
                    if (ImGui.BeginChild("##wikiprev", ImGui.GetContentRegionAvail(), true))
                    {
                        List<KeyValuePair<string, string>> info = WikiView.Info(Text);
                        if (info.Count > 0 && ImGui.BeginTable("##pinfo", 2, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit, new Vec2(Math.Min(560f, ImGui.GetContentRegionAvail().X), 0)))
                        {
                            ImGui.TableSetupColumn("k", ImGuiTableColumnFlags.WidthFixed, 110);
                            ImGui.TableSetupColumn("v", ImGuiTableColumnFlags.WidthStretch);
                            foreach (KeyValuePair<string, string> kv in info)
                            {
                                ImGui.TableNextRow();
                                ImGui.TableSetColumnIndex(0); Im.TextColored(WikiView.LabelCol, kv.Key);
                                ImGui.TableSetColumnIndex(1); WikiView.Rich(kv.Value, ImGui.GetCursorPosX(), ImGui.GetStyle().Colors[(int)ImGuiCol.Text]);
                            }
                            ImGui.EndTable();
                        }
                        WikiView.Body(Text);
                    }
                    ImGui.EndChild();
                }
            }
            ImGui.End();
            if (!open) Open = false;
        }
    }
}
