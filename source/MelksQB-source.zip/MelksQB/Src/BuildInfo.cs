namespace MelksQuestTracker;

public static class BuildInfo
{
	public const int Number = 2;

	public const string Time = "Nov 25 08:07";

	public static string Label => "b" + Number + " (" + Time + ")";
}
