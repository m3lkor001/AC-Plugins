namespace MelksQuestTracker;

public static class BuildInfo
{
	public const int Number = 8;

	public const string Time = "Nov 27 21:57";

	public static string Label => "b" + Number + " (" + Time + ")";
}
