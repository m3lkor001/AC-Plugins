namespace MelksQuestTracker;

public static class BuildInfo
{
	public const int Number = 4;

	public const string Time = "Nov 26 14:45";

	public static string Label => "b" + Number + " (" + Time + ")";
}
