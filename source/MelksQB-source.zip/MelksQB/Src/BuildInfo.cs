namespace MelksQuestTracker;

public static class BuildInfo
{
	public const int Number = 7;

	public const string Time = "Nov 26 16:11";

	public static string Label => "b" + Number + " (" + Time + ")";
}
