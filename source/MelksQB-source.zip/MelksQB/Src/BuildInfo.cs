namespace MelksQuestTracker;

public static class BuildInfo
{
	public const int Number = 9;

	public const string Time = "Nov 27 22:04";

	public static string Label => "b" + Number + " (" + Time + ")";
}
