namespace MelksQuestTracker;

public static class BuildInfo
{
	public const int Number = 1;

	public const string Time = "Nov 25 07:28";

	public static string Label => "b" + Number + " (" + Time + ")";
}
