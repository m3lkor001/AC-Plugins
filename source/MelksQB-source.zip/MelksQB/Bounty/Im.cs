using System.Numerics;
using ImGuiNET;

namespace MelksQuestTracker
{
    /// <summary>
    /// Safe text: ImGui's Text / TextColored / TextWrapped / SetTooltip treat the string as a printf
    /// format, so a "%" in it (a heal %, "+20% crit") makes the game read garbage and crash.
    /// These draw the text as-is instead.
    /// </summary>
    internal static class Im
    {
        public static void Text(string s) { ImGui.TextUnformatted(s ?? ""); }

        [System.Runtime.InteropServices.DllImport("cimgui")] private static extern System.IntPtr igGetCurrentWindow();
        [System.Runtime.InteropServices.DllImport("cimgui")] private static extern void igErrorCheckEndWindowRecover(System.IntPtr log, System.IntPtr data);

        /// <summary>The window being drawn into now (to come back to with <see cref="BackTo"/>).</summary>
        public static System.IntPtr Window() { try { return igGetCurrentWindow(); } catch { return System.IntPtr.Zero; } }

        /// <summary>
        /// After drawing failed part way: closes what it left open (child windows, tables, pushed colours ...) back to
        /// <paramref name="w"/>, so the rest of the window (the tabs after it) still draws.
        /// </summary>
        public static void BackTo(System.IntPtr w)
        {
            if (w == System.IntPtr.Zero) return;
            try
            {
                for (int i = 0; i < 16 && igGetCurrentWindow() != w; i++) { igErrorCheckEndWindowRecover(System.IntPtr.Zero, System.IntPtr.Zero); ImGui.EndChild(); }
            }
            catch { }
        }

        /// <summary>ImGui.CalcTextSize, but "" (or null) is fine - ACGodot's ImGui.NET throws on an empty string.</summary>
        public static Vector2 Size(string s) { return string.IsNullOrEmpty(s) ? new Vector2(0, ImGui.GetTextLineHeight()) : ImGui.CalcTextSize(s); }

        public static void TextColored(Vector4 col, string s)
        {
            ImGui.PushStyleColor(ImGuiCol.Text, col);
            ImGui.TextUnformatted(s ?? "");
            ImGui.PopStyleColor();
        }

        public static void TextDisabled(string s) { TextColored(new Vector4(0.5f, 0.5f, 0.5f, 1f), s); }

        public static void TextWrapped(string s)
        {
            ImGui.PushTextWrapPos(0f);
            ImGui.TextUnformatted(s ?? "");
            ImGui.PopTextWrapPos();
        }

        public static void SetTooltip(string s)
        {
            ImGui.BeginTooltip();
            ImGui.PushTextWrapPos(ImGui.GetFontSize() * 35f);
            ImGui.TextUnformatted(s ?? "");
            ImGui.PopTextWrapPos();
            ImGui.EndTooltip();
        }
    }
}
