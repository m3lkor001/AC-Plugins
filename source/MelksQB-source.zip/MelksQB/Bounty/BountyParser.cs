using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;

namespace MelksQuestTracker
{
    /// <summary>One bounty: where, what it pays, how far along you are.</summary>
    public class Bounty
    {
        public string Zone = "";
        public string Reward = "";
        public int Have, Need;
        public string Limit = "";      // "at most every 1 hr" (from /bounty list), or ""
        /// <summary>Waiting after a payout ("unlocks in 54 min 27 sec"): kills don't count until then. MinValue = not locked.</summary>
        public DateTime UnlocksAt = DateTime.MinValue;
        public bool Locked { get { return UnlocksAt > DateTime.Now; } }
        public TimeSpan UnlocksIn { get { return UnlocksAt - DateTime.Now; } }
    }

    /// <summary>
    /// Reads the server's bounty chat lines.
    ///   /bounty       ->  Bounty (all zones): 2 Thaelaryn Token of Luminance - 88 of 300 kills.
    ///                     Bounty: 5 Shadowy Essence - 464 of 13,500 kills.      (this area's own: no zone named)
    ///   /bounty list  ->  Bounties:
    ///                       Wailing Cells: 5 Shadowy Essence every 13,500 kills - you: 434 of 13,500 kills.
    ///                       All zones: 2 Thaelaryn Token of Luminance every 300 kills (at most every 1 hr) - you: 88 of 300 kills.
    ///                     Bounty: type /bounty to see the bounties where you stand.
    /// </summary>
    public static class BountyParser
    {
        public enum Kind { None, Here, ListHeader, ListItem, ListFooter, OtherBounty }

        private static readonly Regex HereRx = new Regex(
            @"^Bounty(?: \((?<zone>[^)]*)\))?:\s*(?<reward>.+?)\s+-\s+(?<have>[\d,]+) of (?<need>[\d,]+) kills\.?$", RegexOptions.IgnoreCase);
        //   Bounty (all zones): 2 Thaelaryn Token of Luminance - unlocks in 54 min 27 sec, then 300 kills required.
        private static readonly Regex LockedRx = new Regex(
            @"^Bounty(?: \((?<zone>[^)]*)\))?:\s*(?<reward>.+?)\s+-\s+unlocks in (?<time>.+?),\s*then (?<need>[\d,]+) kills required\.?$", RegexOptions.IgnoreCase);
        // A /bounty list line that isn't "you: H of N kills" (e.g. waiting to unlock): zone, reward, kills, limit, and the rest.
        private static readonly Regex ListAnyRx = new Regex(
            @"^(?<zone>[^:]+):\s*(?<reward>.+?)\s+every\s+(?<need>[\d,]+)\s+kills(?:\s*\((?<limit>[^)]*)\))?\s+-\s+(?<rest>.+)$", RegexOptions.IgnoreCase);
        private static readonly Regex UnlockTimeRx = new Regex(@"unlocks in (?<time>[^,.]+)", RegexOptions.IgnoreCase);
        private static readonly Regex PartRx = new Regex(@"(?<n>\d+)\s*(?<u>days?|d|hours?|hrs?|h|minutes?|mins?|m|seconds?|secs?|s)\b", RegexOptions.IgnoreCase);

        /// <summary>"54 min 27 sec", "1 hr 3 min", "27 sec", "2 days 4 hrs" -> a time span (zero if nothing readable).</summary>
        public static TimeSpan ParseSpan(string s)
        {
            TimeSpan t = TimeSpan.Zero;
            foreach (Match m in PartRx.Matches(s ?? ""))
            {
                int n = int.Parse(m.Groups["n"].Value, CultureInfo.InvariantCulture);
                char u = char.ToLowerInvariant(m.Groups["u"].Value[0]);
                if (u == 'd') t += TimeSpan.FromDays(n);
                else if (u == 'h') t += TimeSpan.FromHours(n);
                else if (u == 'm') t += TimeSpan.FromMinutes(n);
                else t += TimeSpan.FromSeconds(n);
            }
            return t;
        }

        private static readonly Regex ListRx = new Regex(
            @"^(?<zone>[^:]+):\s*(?<reward>.+?)\s+every\s+[\d,]+\s+kills(?:\s*\((?<limit>[^)]*)\))?\s+-\s+you:\s*(?<have>[\d,]+) of (?<need>[\d,]+) kills\.?$", RegexOptions.IgnoreCase);

        private static int Num(string s)
        {
            int v;
            return int.TryParse(s.Replace(",", ""), NumberStyles.Integer, CultureInfo.InvariantCulture, out v) ? v : 0;
        }

        public static string Clean(string text)
        {
            return (text ?? "").Replace("\r", "").TrimEnd('\n', ' ');
        }

        /// <summary>What kind of bounty line this is, and the bounty in it when there is one.</summary>
        public static Kind Read(string rawLine, bool inList, out Bounty b)
        {
            b = null;
            string line = Clean(rawLine);
            string t = line.Trim();
            if (t.Length == 0) return Kind.None;

            Match m = HereRx.Match(t);
            if (m.Success)
            {
                b = new Bounty { Zone = m.Groups["zone"].Value.Trim(), Reward = m.Groups["reward"].Value.Trim(), Have = Num(m.Groups["have"].Value), Need = Num(m.Groups["need"].Value) };
                return Kind.Here;
            }
            m = LockedRx.Match(t);
            if (m.Success)
            {
                b = new Bounty { Zone = m.Groups["zone"].Value.Trim(), Reward = m.Groups["reward"].Value.Trim(), Have = 0, Need = Num(m.Groups["need"].Value) };
                b.UnlocksAt = DateTime.Now + ParseSpan(m.Groups["time"].Value);
                return Kind.Here;
            }
            if (t == "Bounties:") return Kind.ListHeader;
            if (t.StartsWith("Bounty: type /bounty", StringComparison.OrdinalIgnoreCase)) return Kind.ListFooter;
            if (inList || line.StartsWith("  "))
            {
                m = ListRx.Match(t);
                if (m.Success)
                {
                    b = new Bounty
                    {
                        Zone = m.Groups["zone"].Value.Trim(), Reward = m.Groups["reward"].Value.Trim(),
                        Have = Num(m.Groups["have"].Value), Need = Num(m.Groups["need"].Value), Limit = m.Groups["limit"].Value.Trim()
                    };
                    return Kind.ListItem;
                }
                m = ListAnyRx.Match(t);
                if (m.Success)
                {
                    b = new Bounty
                    {
                        Zone = m.Groups["zone"].Value.Trim(), Reward = m.Groups["reward"].Value.Trim(),
                        Need = Num(m.Groups["need"].Value), Limit = m.Groups["limit"].Value.Trim()
                    };
                    Match u = UnlockTimeRx.Match(m.Groups["rest"].Value);
                    if (u.Success) b.UnlocksAt = DateTime.Now + ParseSpan(u.Groups["time"].Value);
                    return Kind.ListItem;
                }
            }
            if (t.StartsWith("Bounty", StringComparison.OrdinalIgnoreCase)) return Kind.OtherBounty;   // e.g. no bounties here
            return Kind.None;
        }
    }
}
