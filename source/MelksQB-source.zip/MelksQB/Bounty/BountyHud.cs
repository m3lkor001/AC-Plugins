using System;
using System.Collections.Generic;
using System.Globalization;
using System.Numerics;
using ImGuiNET;
using UtilityBelt.Service;
using MyClasses.MetaViewWrappers.UBHudControls;

namespace MelksQuestTracker
{
    /// <summary>
    /// The small bounty window: one bar per bounty where you stand (kills / kills needed), the reward
    /// on hover, and buttons for /bounty and /bounty list. Drag it anywhere; its place is remembered.
    /// </summary>
    public class BountyHud : IDisposable
    {
        private readonly UtilityBelt.Service.Views.Hud _hud;
        private readonly BountyTracker _t;
        private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

        private static readonly Vector4 Cyan = new Vector4(0.35f, 0.85f, 0.95f, 1f);
        private static readonly Vector4 Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f);
        private static readonly Vector4 Gold = new Vector4(0.95f, 0.8f, 0.3f, 1f);
        private static readonly Vector4 BarColor = new Vector4(0.2f, 0.55f, 0.3f, 1f);
        private static readonly Vector4 BarAll = new Vector4(0.3f, 0.4f, 0.65f, 1f);

        /// <summary>Lines under the tier status: text, and true when that one is done.</summary>
        public Func<List<KeyValuePair<string, bool>>> ExtraLines;

        private static BountyHud _current;

        /// <summary>
        /// What the pop-up shows, as text lines for MelkTank's phone app (read by reflection):
        /// "B|zone|count text|reward" for a bounty, "E|text" for the latest bounty message, "K|text" for a kill task,
        /// "D|text" for a finished one. Empty when the pop-up isn't running.
        /// </summary>
        public static List<string> PhoneLines()
        {
            List<string> o = new List<string>();
            BountyHud h = _current;
            if (h == null) return o;
            try
            {
                BountyTracker t = h._t;
                foreach (Bounty b in t.Here)
                {
                    bool all = BountyTracker.IsAllZones(b);
                    bool off = all && !t.AllZonesCount;
                    bool waiting = b.UnlocksAt != DateTime.MinValue;
                    string eta = off || waiting ? "" : t.TimeToGo(b);
                    string count = waiting ? "unlocks in " + BountyTracker.Countdown(b.UnlocksIn)
                                           : b.Have.ToString("N0", Inv) + " / " + b.Need.ToString("N0", Inv) + (eta.Length > 0 && eta != "--" ? "  (" + eta + " to go)" : "");
                    if (off) count += "  - not counting here";
                    o.Add("B|" + (off ? "All zones" : t.ZoneName(b)) + "|" + count + "|" + (b.Reward ?? ""));
                }
                if (t.LastEvent.Length > 0 && (DateTime.Now - t.LastEventAt).TotalMinutes < 10) o.Add("E|" + t.LastEvent);
                if (h.ExtraLines != null)
                    foreach (KeyValuePair<string, bool> l in h.ExtraLines()) o.Add((l.Value ? "D|" : "K|") + l.Key);
            }
            catch (Exception ex) { Util.LogError(ex); }
            return o;
        }

        public BountyHud(BountyTracker t)
        {
            _current = this;
            _t = t;
            _hud = UBService.Huds.CreateHud("MQT Bounty", BarIcon.Make("Bnty"));
            _hud.ShowInBar = true;
            _hud.WindowSettings = ImGuiWindowFlags.NoTitleBar | ImGuiWindowFlags.AlwaysAutoResize |
                                  ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoCollapse;
            _hud.OnPreRender += OnPreRender;
            _hud.OnRender += OnRender;
            _hud.Visible = true;
        }

        /// <summary>Shown or hidden (the Bounty tab's checkbox).</summary>
        public bool Visible { get { return _hud.Visible; } set { _hud.Visible = value; } }

        public void Dispose()
        {
            if (_current == this) _current = null;
            try { _hud.OnPreRender -= OnPreRender; _hud.OnRender -= OnRender; _hud.Dispose(); } catch { }
        }

        // ── Position memory ───────────────────────────────────────
        private int _restoredFor;
        private float[] _lastPos;
        private DateTime _dirtySince = DateTime.MinValue;
        private static string PosFile { get { return Util.FullPath("MQT_BountyPos.txt"); } }

        private void OnPreRender(object sender, EventArgs e)
        {
            if (!MyClasses.MetaViewWrappers.UBHudControls.WindowMemory.Restore(ref _restoredFor)) return;   // per character: once it's known, and again for the next one
            try
            {
                float[] r;
                if (MyClasses.MetaViewWrappers.UBHudControls.WindowMemory.TryGet("MelksQB Bounty", out r)) { ImGui.SetNextWindowPos(new Vector2(r[0], r[1]), ImGuiCond.Always); return; }
                if (!System.IO.File.Exists(PosFile)) return;
                string[] p = System.IO.File.ReadAllText(PosFile).Trim().Split('|');
                float x, y;
                if (p.Length == 2 && float.TryParse(p[0], NumberStyles.Float, Inv, out x) && float.TryParse(p[1], NumberStyles.Float, Inv, out y))
                    ImGui.SetNextWindowPos(new Vector2(x, y), ImGuiCond.Always);
            }
            catch { }
        }

        private void TrackPos()
        {
            try { MyClasses.MetaViewWrappers.UBHudControls.WindowMemory.Track("MelksQB Bounty"); } catch { }
            Vector2 pos = ImGui.GetWindowPos();
            if (_lastPos == null || Math.Abs(pos.X - _lastPos[0]) > 0.5f || Math.Abs(pos.Y - _lastPos[1]) > 0.5f)
            {
                _lastPos = new[] { pos.X, pos.Y };
                _dirtySince = DateTime.Now;
            }
            if (_dirtySince != DateTime.MinValue && (DateTime.Now - _dirtySince).TotalSeconds > 1.5)
            {
                _dirtySince = DateTime.MinValue;
                try { System.IO.File.WriteAllText(PosFile, _lastPos[0].ToString(Inv) + "|" + _lastPos[1].ToString(Inv)); } catch { }
            }
        }

        // ── Drawing ───────────────────────────────────────────────
        private void OnRender(object sender, EventArgs e)
        {
            try
            {
                TrackPos();
                Im.TextColored(Cyan, "Bounties");

                if (_t.Here.Count == 0)
                    Im.TextColored(Grey, _t.UpdatedAt == DateTime.MinValue ? "Checking..." : (_t.Note.Length > 0 ? _t.Note : "No bounties here."));

                foreach (Bounty b in _t.Here)
                {
                    bool all = BountyTracker.IsAllZones(b);
                    bool off = all && !_t.AllZonesCount;     // all zones: tier 11+ areas only
                    if (off) Im.TextColored(Grey, "All zones (not here - tier 11+ only)");
                    else ImGui.TextUnformatted(_t.ZoneName(b));
                    bool waiting = b.UnlocksAt != DateTime.MinValue;   // waiting after a payout (counts down here, rechecked on unlock)
                    float frac = waiting ? 0f : b.Need > 0 ? Math.Min(1f, (float)b.Have / b.Need) : 0f;
                    ImGui.PushStyleColor(ImGuiCol.PlotHistogram, off || waiting ? new Vector4(0.35f, 0.35f, 0.35f, 1f) : all ? BarAll : BarColor);
                    string eta = off ? "" : _t.TimeToGo(b);
                    ImGui.ProgressBar(frac, new Vector2(240, 0), waiting ? "unlocks in " + BountyTracker.Countdown(b.UnlocksIn)
                                                                         : b.Have.ToString("N0", Inv) + " / " + b.Need.ToString("N0", Inv) + (eta.Length > 0 ? "   " + eta : ""));
                    ImGui.PopStyleColor();
                    if (ImGui.IsItemHovered())
                    {
                        string limit = _t.LimitFor(b);
                        int left = Math.Max(0, b.Need - b.Have);
                        ImGui.BeginTooltip();
                        Im.TextColored(Gold, "Reward: " + b.Reward);
                        ImGui.TextUnformatted("Every " + b.Need.ToString("N0", Inv) + " kills" + (limit.Length > 0 ? " (" + limit + ")" : ""));
                        if (waiting) Im.TextColored(Gold, "Paid out - kills count again in " + BountyTracker.Countdown(b.UnlocksIn) + " (at " + b.UnlocksAt.ToString("h:mm tt") + ")");
                        else ImGui.TextUnformatted(left.ToString("N0", Inv) + " kills to go");
                        double rate = _t.KillsPerMinute(b);
                        if (!waiting && !off)
                            ImGui.TextUnformatted(rate < 0 ? "Time to go: needs another update to measure your kill rate"
                                                           : (_t.RateFromMelkTank ? "(MT) " : "(MQ) ") + (rate * 60).ToString("N0", Inv) + " kills/hr - " +
                                                             (eta == "--" ? "no estimate" : "done in " + eta));
                        if (off) Im.TextColored(Grey, "Kills here don't count - this area is tier " + _t.Tier + ".");
                        ImGui.EndTooltip();
                    }
                }

                // The last bounty message that wasn't a count - e.g. a reward - for 10 minutes.
                if (_t.LastEvent.Length > 0 && (DateTime.Now - _t.LastEventAt).TotalMinutes < 10)
                {
                    ImGui.PushTextWrapPos(ImGui.GetCursorPosX() + 240);
                    Im.TextColored(Gold, _t.LastEvent);
                    ImGui.PopTextWrapPos();
                    if (ImGui.IsItemHovered()) Im.SetTooltip(_t.LastEventAt.ToString("h:mm tt"));
                }

                ImGui.Spacing();
                if (ImGui.Button("/bounty")) _t.SendManual("/bounty");
                if (ImGui.IsItemHovered()) Im.SetTooltip("The bounties where you stand, in chat.");
                ImGui.SameLine();
                if (ImGui.Button("/bounty list")) _t.SendManual("/bounty list");
                if (ImGui.IsItemHovered()) Im.SetTooltip("Every bounty, in chat.");

                string tier = "Tier " + (_t.Tier >= 0 ? _t.Tier.ToString() : "?");
                string st;
                if (_t.UpdatedAt == DateTime.MinValue) st = "";
                else if (_t.Paused) st = tier + " - no bounties count here, waiting for a portal";
                else
                {
                    int ago = (int)(DateTime.Now - _t.UpdatedAt).TotalSeconds;
                    st = tier + " - updated " + (ago < 60 ? ago + "s" : ago / 60 + "m") + " ago";
                }
                if (st.Length > 0) Im.TextColored(Grey, st);

                // Kill tasks from the KTs tab's repeat list (ticked to show here).
                if (ExtraLines != null)
                    foreach (KeyValuePair<string, bool> l in ExtraLines())
                        Im.TextColored(l.Value ? Gold : Cyan, l.Key);
            }
            catch (Exception ex) { Util.LogError(ex); }
        }
    }
}
