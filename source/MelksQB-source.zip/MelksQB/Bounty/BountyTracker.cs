// Recovered from MelksQB.dll: the source file kept on the PC was older than the DLL, so this one has no comments.
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text.RegularExpressions;

namespace MelksQuestTracker;

public class BountyTracker
{
	public int IntervalSeconds = 60;

	public bool Enabled = true;

	public int Version;

	public List<Bounty> Here = new List<Bounty>();

	public List<Bounty> All = new List<Bounty>();

	public DateTime UpdatedAt = DateTime.MinValue;

	public string Note = "";

	public int Tier = -1;

	public const int AllZonesTier = 11;

	private bool _wantLocation = true;

	private DateTime _lastLocation = DateTime.MinValue;

	private DateTime _quietLocUntil = DateTime.MinValue;

	private DateTime _due = DateTime.Now.AddSeconds(3.0);

	private DateTime _lastSent = DateTime.MinValue;

	private DateTime _quietUntil = DateTime.MinValue;

	private DateTime _lastHereAt = DateTime.MinValue;

	private DateTime _nextCheck = DateTime.MinValue;

	private bool _wantList = true;

	private bool _inList;

	private List<Bounty> _listBuilding;

	public string LastEvent = "";

	public DateTime LastEventAt = DateTime.MinValue;

	private DateTime _awaitFrom = DateTime.MinValue;

	private DateTime _awaitUntil = DateTime.MinValue;

	private bool _staleHere;

	private readonly Dictionary<string, List<KeyValuePair<DateTime, int>>> _samples = new Dictionary<string, List<KeyValuePair<DateTime, int>>>();

	private static PropertyInfo _mtRate;

	private static DateTime _mtLookedAt = DateTime.MinValue;

	public bool Paused { get; private set; }

	public bool AllZonesCount => Tier < 0 || Tier >= 11;

	public bool RateFromMelkTank { get; private set; }

	public bool AnyLocked
	{
		get
		{
			foreach (Bounty item in Here)
			{
				if (item.Locked)
				{
					return true;
				}
			}
			foreach (Bounty item2 in All)
			{
				if (item2.Locked)
				{
					return true;
				}
			}
			return false;
		}
	}

	public void Tick()
	{
		DateTime now = DateTime.Now;
		if (now < _nextCheck)
		{
			return;
		}
		_nextCheck = now.AddSeconds(1.0);
		if (!Enabled)
		{
			if (_wantList && now >= _due)
			{
				_wantList = false;
				SendQuiet("/bounty list");
			}
		}
		else if (_wantLocation && (now - _lastLocation).TotalSeconds >= 10.0)
		{
			_wantLocation = false;
			_lastLocation = now;
			_quietLocUntil = now.AddSeconds(6.0);
			Util.Command("/location");
			if (_due < now.AddSeconds(2.0))
			{
				_due = now.AddSeconds(2.0);
			}
		}
		else if (!Paused && !(now < _due))
		{
			if (_wantList)
			{
				_wantList = false;
				SendQuiet("/bounty list");
				_due = now.AddSeconds(3.0);
			}
			else
			{
				SendQuiet("/bounty");
			}
		}
	}

	public void AreaChanged()
	{
		_staleHere = true;
		_wantLocation = true;
		LastEvent = "";
		LastEventAt = DateTime.MinValue;
		Tier = -1;
		if (Paused)
		{
			Paused = false;
			DateTime dateTime = _lastSent.AddSeconds(IntervalSeconds);
			_due = ((dateTime > DateTime.Now.AddSeconds(2.0)) ? dateTime : DateTime.Now.AddSeconds(2.0));
		}
	}

	public void Expect(string cmd)
	{
		string text = (cmd ?? "").Trim().ToLowerInvariant();
		if (!(text != "/bounty") || !(text != "@bounty"))
		{
			_awaitFrom = DateTime.Now;
			_awaitUntil = DateTime.Now.AddSeconds(6.0);
		}
	}

	private void SendQuiet(string cmd)
	{
		Expect(cmd);
		_quietUntil = DateTime.Now.AddSeconds(6.0);
		_lastSent = DateTime.Now;
		_due = DateTime.Now.AddSeconds(IntervalSeconds);
		Util.Command(cmd);
	}

	public void RequestList()
	{
		_quietUntil = DateTime.Now.AddSeconds(6.0);
		Util.Command("/bounty list");
	}

	public void SendManual(string cmd)
	{
		_quietUntil = DateTime.MinValue;
		Expect(cmd);
		Util.Command(cmd);
	}

	public Bounty ListEntryFor(Bounty b)
	{
		foreach (Bounty item in All)
		{
			if (!string.Equals(item.Reward, b.Reward, StringComparison.OrdinalIgnoreCase))
			{
				continue;
			}
			if (b.Zone.Length > 0)
			{
				if (string.Equals(item.Zone, b.Zone, StringComparison.OrdinalIgnoreCase))
				{
					return item;
				}
			}
			else if (item.Need == b.Need && !IsAllZones(item))
			{
				return item;
			}
		}
		return null;
	}

	public string LimitFor(Bounty b)
	{
		Bounty bounty = ListEntryFor(b);
		return (bounty == null) ? "" : bounty.Limit;
	}

	public string ZoneName(Bounty b)
	{
		if (IsAllZones(b))
		{
			return "All zones";
		}
		if (b.Zone.Length > 0)
		{
			return b.Zone;
		}
		Bounty bounty = ListEntryFor(b);
		return (bounty != null) ? bounty.Zone : "This area";
	}

	public static bool IsAllZones(Bounty b)
	{
		return string.Equals(b.Zone, "all zones", StringComparison.OrdinalIgnoreCase);
	}

	public bool OnChat(string text)
	{
		if (string.IsNullOrEmpty(text))
		{
			return false;
		}
		string text2 = BountyParser.Clean(text).Trim();
		if (text2.StartsWith("Your location is:", StringComparison.OrdinalIgnoreCase))
		{
			Match match = Regex.Match(text2, "\\bv:\\s*(\\d+)");
			if (match.Success)
			{
				Tier = int.Parse(match.Groups[1].Value);
				if (UpdatedAt != DateTime.MinValue && !_staleHere)
				{
					UpdatePaused();
				}
			}
			return DateTime.Now < _quietLocUntil;
		}
		bool flag = DateTime.Now < _quietUntil;
		bool flag2 = false;
		bool flag3 = false;
		string[] array = text.Replace("\r", "").Split('\n');
		foreach (string text3 in array)
		{
			if (text3.Trim().Length == 0)
			{
				continue;
			}
			BountyParser.Kind kind = BountyParser.Read(text3, _inList, out var b);
			switch (kind)
			{
			case BountyParser.Kind.Here:
				AddHere(b);
				break;
			case BountyParser.Kind.ListHeader:
				_inList = true;
				_listBuilding = new List<Bounty>();
				break;
			case BountyParser.Kind.ListItem:
				if (_listBuilding == null)
				{
					_listBuilding = new List<Bounty>();
				}
				_listBuilding.Add(b);
				break;
			case BountyParser.Kind.ListFooter:
				_inList = false;
				if (_listBuilding != null)
				{
					All = _listBuilding;
					Version++;
				}
				_listBuilding = null;
				break;
			case BountyParser.Kind.OtherBounty:
				if (!_inList)
				{
					if (DateTime.Now < _awaitUntil && _lastHereAt < _awaitFrom)
					{
						StartHereBatch();
						Note = BountyParser.Clean(text3).Trim();
						UpdatedAt = DateTime.Now;
						UpdatePaused();
					}
					else
					{
						LastEvent = BountyParser.Clean(text3).Trim();
						LastEventAt = DateTime.Now;
						Paused = false;
						DateTime dateTime = DateTime.Now.AddSeconds(3.0);
						DateTime dateTime2 = _lastSent.AddSeconds(IntervalSeconds);
						_due = ((dateTime2 > dateTime) ? dateTime2 : dateTime);
					}
				}
				break;
			default:
				flag3 = true;
				break;
			}
			if (kind != BountyParser.Kind.None)
			{
				flag2 = true;
			}
		}
		return (flag & flag2) && !flag3;
	}

	private void StartHereBatch()
	{
		if ((DateTime.Now - _lastHereAt).TotalSeconds > 1.5)
		{
			Here = new List<Bounty>();
			Note = "";
		}
		_lastHereAt = DateTime.Now;
		_staleHere = false;
	}

	private string Key(Bounty b)
	{
		return ZoneName(b) + "|" + b.Reward;
	}

	private void Sample(Bounty b)
	{
		if (!b.Locked && b.Need > 0)
		{
			string key = Key(b);
			if (!_samples.TryGetValue(key, out var value))
			{
				value = (_samples[key] = new List<KeyValuePair<DateTime, int>>());
			}
			if (value.Count > 0 && b.Have < value[value.Count - 1].Value)
			{
				value.Clear();
			}
			value.Add(new KeyValuePair<DateTime, int>(DateTime.Now, b.Have));
			value.RemoveAll((KeyValuePair<DateTime, int> s) => (DateTime.Now - s.Key).TotalMinutes > 15.0);
		}
	}

	public static double MelkTankKillsPerHour()
	{
		try
		{
			if (_mtRate == null && (DateTime.Now - _mtLookedAt).TotalSeconds > 30.0)
			{
				_mtLookedAt = DateTime.Now;
				Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
				foreach (Assembly assembly in assemblies)
				{
					if (assembly.FullName.StartsWith("MelkTank,") || assembly.FullName.StartsWith("MelksTank,") || assembly.FullName.StartsWith("MelkTankCore,"))
					{
						Type type = assembly.GetType("MelkTank.Session");
						_mtRate = ((type == null) ? null : type.GetProperty("KillsPerHourRecent"));
						break;
					}
				}
			}
			if (_mtRate == null)
			{
				return -1.0;
			}
			return Convert.ToDouble(_mtRate.GetValue(null, null));
		}
		catch
		{
			_mtRate = null;
			return -1.0;
		}
	}

	public double KillsPerMinute(Bounty b)
	{
		double num = MelkTankKillsPerHour();
		RateFromMelkTank = num >= 0.0;
		if (num >= 0.0)
		{
			return num / 60.0;
		}
		if (!_samples.TryGetValue(Key(b), out var value) || value.Count < 2)
		{
			return -1.0;
		}
		KeyValuePair<DateTime, int> keyValuePair = value[value.Count - 1];
		KeyValuePair<DateTime, int> keyValuePair2 = new KeyValuePair<DateTime, int>(DateTime.MinValue, 0);
		double num2 = double.MaxValue;
		for (int i = 0; i < value.Count - 1; i++)
		{
			double totalSeconds = (keyValuePair.Key - value[i].Key).TotalSeconds;
			if (!(totalSeconds < 30.0))
			{
				double num3 = Math.Abs(totalSeconds - 60.0);
				if (num3 < num2)
				{
					num2 = num3;
					keyValuePair2 = value[i];
				}
			}
		}
		if (keyValuePair2.Key == DateTime.MinValue)
		{
			return -1.0;
		}
		double totalMinutes = (keyValuePair.Key - keyValuePair2.Key).TotalMinutes;
		return (totalMinutes <= 0.0) ? (-1.0) : ((double)(keyValuePair.Value - keyValuePair2.Value) / totalMinutes);
	}

	public string TimeToGo(Bounty b)
	{
		if (b.Locked || b.Need <= 0)
		{
			return "";
		}
		double num = KillsPerMinute(b);
		if (num < 0.0)
		{
			return "";
		}
		int num2 = Math.Max(0, b.Need - b.Have);
		if (num2 == 0)
		{
			return "0:00";
		}
		if (num <= 0.0)
		{
			return "--";
		}
		int num3 = (int)Math.Ceiling((double)num2 / num);
		return num3 / 60 + ":" + (num3 % 60).ToString("00");
	}

	private void AddHere(Bounty b)
	{
		StartHereBatch();
		Here.Add(b);
		Sample(b);
		Bounty bounty = ListEntryFor(b);
		if (bounty != null)
		{
			bounty.Have = b.Have;
			bounty.Need = b.Need;
			bounty.UnlocksAt = b.UnlocksAt;
		}
		Version++;
		UpdatedAt = DateTime.Now;
		_due = DateTime.Now.AddSeconds(IntervalSeconds);
		foreach (Bounty item in Here)
		{
			if (item.Locked && item.UnlocksAt.AddSeconds(3.0) < _due)
			{
				_due = item.UnlocksAt.AddSeconds(3.0);
			}
		}
		UpdatePaused();
	}

	public static string Countdown(TimeSpan t)
	{
		if (t <= TimeSpan.Zero)
		{
			return "unlocking...";
		}
		if (t.TotalHours >= 1.0)
		{
			return (int)t.TotalHours + ":" + t.Minutes.ToString("00") + ":" + t.Seconds.ToString("00");
		}
		return t.Minutes + ":" + t.Seconds.ToString("00");
	}

	private void UpdatePaused()
	{
		bool flag = false;
		foreach (Bounty item in Here)
		{
			if (!IsAllZones(item) || AllZonesCount)
			{
				flag = true;
			}
		}
		bool paused = Paused;
		Paused = !flag;
		if (paused && !Paused && _due < DateTime.Now)
		{
			_due = DateTime.Now.AddSeconds(IntervalSeconds);
		}
	}
}
