///////////////////////////////////////////////////////////////////////////////
// Wrapper_ImGui.cs - a UtilityBelt (ImGui) back end for the MetaViewWrappers.
//
// Draws the same mainView.xml (Notebook / FixedLayout / StaticText / PushButton /
// Checkbox / Edit / List) as an ImGui window in UtilityBelt's HUD bar, behind the same
// IView / IButton / ICheckBox / ITextBox / IStaticText / IList interfaces the plugin
// code already uses, so nothing else in the plugin has to change.
//
// ViewSystemSelector picks this whenever UtilityBelt.Service is running and falls back to
// Virindi View Service / Decal otherwise.
///////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Xml;
using ImGuiNET;
using UtilityBelt.Service;
using Vec2 = System.Numerics.Vector2;
using Vec4 = System.Numerics.Vector4;

#if METAVIEW_PUBLIC_NS
namespace MetaViewWrappers.UBHudControls
#else
namespace MyClasses.MetaViewWrappers.UBHudControls
#endif
{
    internal static class UBAvailable
    {
        /// <summary>True when UtilityBelt.Service is loaded and its HUD manager is up.</summary>
        public static bool Check()
        {
            try { return Probe(); } catch { return false; }
        }

        // Just checks UtilityBelt.Service is installed; its HUD manager may only come up a
        // little later (the view waits for it).
        [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
        private static bool Probe() { return typeof(UBService) != null; }
    }

    // ── Bar icon ───────────────────────────────────────────────────────────

    /// <summary>
    /// UtilityBelt's bar shows a window's icon, or just the first letter of its name when it
    /// has none. This draws a small badge with a short label ("Buff", "Pet", "Lum", "QB") so
    /// the windows can be told apart on the bar.
    /// </summary>
    internal static class BarIcon
    {
        public static string LabelFor(string title)
        {
            string t = title ?? "";
            switch (t)
            {
                case "MelkTank": return "Tank";
                case "MelksBuffer": return "Buff";
                case "MelksPetSummoner": return "Pet";
                case "MelksLuminanceTracker": return "Lum";
                case "MelksQuestTracker": return "QB";
                case "MLT Kills": return "Kill";
                case "MLT XP": return "XP";
            }
            if (t.StartsWith("Melks")) t = t.Substring(5);
            t = t.Replace(" ", "");
            return t.Length > 4 ? t.Substring(0, 4) : t;
        }

        // (ACGodot: the plugin bar shows the label itself)
        public static object Make(string label) { return label; }
    }

    // ── Window position / size memory ──────────────────────────────────────

    /// <summary>
    /// Remembers where each window was and how big it was, per character, in UBWindows_&lt;character&gt;.txt next to the
    /// plugin DLL (one "name|x|y|w|h" line per window), and puts it back after a restart. A character without its own
    /// file yet starts from the shared UBWindows.txt.
    /// </summary>
    internal static class WindowMemory
    {
        private static Dictionary<string, float[]> _saved;
        private static DateTime _dirtySince = DateTime.MinValue;

        private static string _char;

        /// <summary>The character is known (logged in): positions are kept per character, so nothing is read or written before.</summary>
        /// Another character logged in (the plugin stays loaded across logins): the last one's positions are saved and
        /// this one's put back - Generation goes up, and each window puts itself back once per generation (Restore).
        public static bool Ready
        {
            get
            {
                string n = "";
                try { n = Decal.Adapter.CoreManager.Current.CharacterFilter.Name ?? ""; } catch { }
                if (n.Length == 0) return _char != null;   // (between characters: the last one's, until the next is in)
                if (n != _lastName)
                {
                    _lastName = n;
                    foreach (char c in System.IO.Path.GetInvalidFileNameChars()) n = n.Replace(c, '_');
                    n = n.Replace(' ', '_');
                    if (n != _char)
                    {
                        if (_char != null) { Flush(); _saved = null; }
                        _char = n;
                        Generation++;
                    }
                }
                return true;
            }
        }

        private static string _lastName;

        /// <summary>Goes up each time a (different) character is in.</summary>
        public static int Generation;

        /// <summary>True once per character for a window (its own counter in gen): time to put it where this character had it.</summary>
        public static bool Restore(ref int gen)
        {
            if (!Ready || gen == Generation) return false;
            gen = Generation;
            return true;
        }

        /// <summary>The plugin folder, when the plugin is loaded from memory by a loader (it has no file location then).</summary>
        public static string BaseDir;
        private static string Dir { get { return !string.IsNullOrEmpty(BaseDir) ? BaseDir : System.IO.Path.GetDirectoryName(typeof(WindowMemory).Assembly.Location); } }
        private static string SharedPath { get { return System.IO.Path.Combine(Dir, "UBWindows.txt"); } }
        private static string FilePath { get { return System.IO.Path.Combine(Dir, "UBWindows_" + _char + ".txt"); } }

        private static void Load()
        {
            if (!Ready || _saved != null) return;
            _saved = new Dictionary<string, float[]>(StringComparer.Ordinal);
            try
            {
                string f = System.IO.File.Exists(FilePath) ? FilePath : SharedPath;   // first time for this character: the shared one
                if (!System.IO.File.Exists(f)) return;
                foreach (string line in System.IO.File.ReadAllLines(f))
                {
                    string[] p = line.Split('|');
                    if (p.Length != 5) continue;
                    float[] v = new float[4];
                    bool ok = true;
                    for (int i = 0; i < 4; i++)
                        ok &= float.TryParse(p[i + 1], System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out v[i]);
                    if (ok) _saved[p[0]] = v;
                }
            }
            catch { }
        }

        public static bool TryGet(string name, out float[] rect)
        {
            rect = null;
            Load();
            return _saved != null && _saved.TryGetValue(name, out rect);
        }

        /// <summary>Call every frame from inside the window; writes the file a moment after it stops moving.</summary>
        public static void Track(string name)
        {
            Load();
            if (_saved == null) return;   // not logged in yet
            Vec2 pos = ImGui.GetWindowPos(), size = ImGui.GetWindowSize();
            float[] cur = { pos.X, pos.Y, size.X, size.Y };
            float[] old;
            if (!_saved.TryGetValue(name, out old) || Math.Abs(old[0] - cur[0]) > 0.5f || Math.Abs(old[1] - cur[1]) > 0.5f ||
                Math.Abs(old[2] - cur[2]) > 0.5f || Math.Abs(old[3] - cur[3]) > 0.5f)
            {
                _saved[name] = cur;
                _dirtySince = DateTime.Now;
            }
            if (_dirtySince != DateTime.MinValue && (DateTime.Now - _dirtySince).TotalSeconds > 1.5) Save();
        }

        /// <summary>Writes a pending change now (the window is closing / the plugin shutting down).</summary>
        public static void Flush() { if (_dirtySince != DateTime.MinValue && _saved != null) Save(); }

        private static void Save()
        {
            _dirtySince = DateTime.MinValue;
            try
            {
                List<string> lines = new List<string>();
                foreach (KeyValuePair<string, float[]> kv in _saved)
                    lines.Add(kv.Key + "|" + string.Join("|", Array.ConvertAll(kv.Value, f => f.ToString(System.Globalization.CultureInfo.InvariantCulture))));
                System.IO.File.WriteAllLines(FilePath, lines.ToArray());
            }
            catch { }
        }
    }

    // ── View ───────────────────────────────────────────────────────────────

#if VVS_WRAPPERS_PUBLIC
    public
#else
    internal
#endif
    class View : IView
    {
        private static int _nextId = 1;
        internal static int NextId() { return _nextId++; }
        private static readonly HashSet<string> _hudNames = new HashSet<string>();

        private UtilityBelt.Service.Views.Hud _hud;
        private readonly Dictionary<string, Control> _byName = new Dictionary<string, Control>(StringComparer.Ordinal);
        private Control _root;
        private string _title = "";
        private int _width = 300, _height = 200;
        private System.Drawing.Point _location;
        private bool _locationPending;
        private readonly List<Action> _deferred = new List<Action>();
        private string _hudName;
        private bool _wantVisible;
        private bool _waitingForHuds;

        // ── IView: create ──
        public void Initialize(Decal.Adapter.Wrappers.PluginHost p, string pXML) { InitializeRawXML(p, LoadResource(pXML)); }
        public void Initialize(Decal.Adapter.Wrappers.PluginHost p, string pXML, string pWindowKey) { Initialize(p, pXML); }
        public void InitializeRawXML(Decal.Adapter.Wrappers.PluginHost p, string pXML, string pWindowKey) { InitializeRawXML(p, pXML); }

        public void InitializeRawXML(Decal.Adapter.Wrappers.PluginHost p, string pXML)
        {
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(pXML);
            XmlElement v = doc.DocumentElement;
            _title = v.GetAttribute("title");
            int.TryParse(v.GetAttribute("width"), out _width);
            int.TryParse(v.GetAttribute("height"), out _height);
            if (_width <= 0) _width = 300;
            if (_height <= 0) _height = 200;

            foreach (XmlNode n in v.ChildNodes)
            {
                XmlElement e = n as XmlElement;
                if (e != null && e.Name == "control") { _root = Build(e); break; }
            }

            // Hud names have to be unique.
            string name = string.IsNullOrEmpty(_title) ? "View" : _title;
            string unique = name; int k = 2;
            while (_hudNames.Contains(unique)) unique = name + " " + k++;
            _hudNames.Add(unique);
            _hudName = unique;

            if (!TryCreateHud())
            {
                // Plugins can start before UtilityBelt's HUD manager is ready - try each frame.
                _waitingForHuds = true;
                Decal.Adapter.CoreManager.Current.RenderFrame += OnFrameWaitForHuds;
            }
        }

        private bool TryCreateHud()
        {
            if (_hud != null) return true;
            if (UBService.Huds == null) return false;
            _hud = UBService.Huds.CreateHud(_hudName, BarIcon.Make(BarIcon.LabelFor(_title)));
            _hud.Title = string.IsNullOrEmpty(_title) ? _hudName : _title;
            _hud.ShowInBar = true;
            _hud.OnPreRender += OnPreRender;
            _hud.OnRender += OnRender;
            if (_wantVisible) _hud.Visible = true;
            return true;
        }

        private void OnFrameWaitForHuds(object sender, EventArgs e)
        {
            try
            {
                if (!TryCreateHud()) return;
            }
            catch (Exception ex) { Report(ex); }
            StopWaiting();
        }

        private void StopWaiting()
        {
            if (!_waitingForHuds) return;
            _waitingForHuds = false;
            try { Decal.Adapter.CoreManager.Current.RenderFrame -= OnFrameWaitForHuds; } catch { }
        }

        private static string LoadResource(string name)
        {
            System.Reflection.Assembly asm = typeof(View).Assembly;
            System.IO.Stream s = asm.GetManifestResourceStream(name);
            if (s == null)
            {
                // Tolerate a different default namespace prefix.
                foreach (string r in asm.GetManifestResourceNames())
                    if (r.EndsWith("." + name, StringComparison.OrdinalIgnoreCase) || r.EndsWith(name, StringComparison.OrdinalIgnoreCase)) { s = asm.GetManifestResourceStream(r); break; }
            }
            if (s == null) throw new Exception("View resource not found: " + name);
            using (System.IO.StreamReader rd = new System.IO.StreamReader(s)) return rd.ReadToEnd();
        }

        private Control Build(XmlElement e)
        {
            string prog = e.GetAttribute("progid");
            Control c;
            switch (prog)
            {
                case "DecalControls.Notebook": c = new Notebook(); break;
                case "DecalControls.FixedLayout": c = new FixedLayout(); break;
                case "DecalControls.PushButton": c = new Button(); break;
                case "DecalControls.Checkbox": c = new CheckBox(); break;
                case "DecalControls.Edit": c = new TextBox(); break;
                case "DecalControls.List": c = new List(); break;
                case "DecalControls.Choice": c = new Combo(); break;
                case "DecalControls.Slider": c = new Slider(); break;
                case "DecalControls.Progress": c = new ProgressBar(); break;
                case "MelksQB.Custom": c = new CustomArea(); break;
                default: c = new StaticText(); break;
            }
            c.Owner = this;
            c.Load(e);

            if (c is Notebook)
            {
                Notebook nb = (Notebook)c;
                foreach (XmlNode n in e.ChildNodes)
                {
                    XmlElement page = n as XmlElement;
                    if (page == null || page.Name != "page") continue;
                    Control content = null;
                    foreach (XmlNode m in page.ChildNodes)
                    {
                        XmlElement ce = m as XmlElement;
                        if (ce != null && ce.Name == "control") { content = Build(ce); break; }
                    }
                    nb.Pages.Add(new KeyValuePair<string, Control>(page.GetAttribute("label"), content));
                }
            }
            else if (c is FixedLayout)
            {
                foreach (XmlNode n in e.ChildNodes)
                {
                    XmlElement ce = n as XmlElement;
                    if (ce != null && ce.Name == "control") ((FixedLayout)c).Children.Add(Build(ce));
                }
            }

            if (!string.IsNullOrEmpty(c.Name)) _byName[c.Name] = c;
            return c;
        }

        // ── Drawing ──
        internal void Defer(Action a) { if (a != null) _deferred.Add(a); }

        private int _restoredFor;
        internal float ViewWidth { get { return _width; } }
        internal float ViewHeight { get { return _height; } }

        private void OnPreRender(object sender, EventArgs e)
        {
            if (WindowMemory.Restore(ref _restoredFor))   // (per character: once it's known, and again for the next one)
            {
                float[] r;
                if (WindowMemory.TryGet(_hudName, out r))
                {
                    ImGui.SetNextWindowPos(new Vec2(r[0], r[1]), ImGuiCond.Always);
                    ImGui.SetNextWindowSize(new Vec2(r[2], r[3]), ImGuiCond.Always);
                    return;
                }
            }
            ImGui.SetNextWindowSize(new Vec2(_width + 18, _height + 42), ImGuiCond.FirstUseEver);
            if (_locationPending)
            {
                ImGui.SetNextWindowPos(new Vec2(_location.X, _location.Y), ImGuiCond.Always);
                _locationPending = false;
            }
        }

        private void OnRender(object sender, EventArgs e)
        {
            try { WindowMemory.Track(_hudName); } catch { }
            try
            {
                if (_root != null) _root.DrawAt(ImGui.GetCursorPos());
            }
            catch (Exception ex) { Report(ex); }

            // Fire control events after drawing, so handlers can rebuild lists safely.
            if (_deferred.Count > 0)
            {
                Action[] run = _deferred.ToArray();
                _deferred.Clear();
                foreach (Action a in run)
                {
                    try { a(); }
                    catch (Exception ex) { Report(ex); }
                }
            }
            try { global::MelksQuestTracker.CustomDraw.Overlays(); } catch (Exception ex) { Report(ex); }
            string clip = global::MelksQuestTracker.Util.PendingClipboard;
            if (clip != null)
            {
                global::MelksQuestTracker.Util.PendingClipboard = null;
                try { ImGui.SetClipboardText(clip); } catch (Exception ex) { Report(ex); }
            }
        }

        private static DateTime _lastReport = DateTime.MinValue;
        internal static void Report(Exception ex)
        {
            Exception inner = ex is System.Reflection.TargetInvocationException && ex.InnerException != null ? ex.InnerException : ex;
            if ((DateTime.Now - _lastReport).TotalSeconds < 5) return;
            _lastReport = DateTime.Now;
            try { Decal.Adapter.CoreManager.Current.Actions.AddChatText("[UI] " + inner.GetType().Name + ": " + inner.Message, 5); } catch { }
        }

        // ── IView: properties ──
        public void SetIcon(int icon, int iconlibrary) { }
        public void SetIcon(int portalicon) { }

        public string Title
        {
            get { return _title; }
            set { _title = value ?? ""; if (_hud != null) _hud.Title = _title; }
        }

        public bool Visible
        {
            get { return _hud != null ? _hud.Visible : _wantVisible; }
            set { _wantVisible = value; if (_hud != null) _hud.Visible = value; }
        }

#if !VVS_WRAPPERS_PUBLIC
        public ViewSystemSelector.eViewSystem ViewType { get { return ViewSystemSelector.eViewSystem.UtilityBelt; } }
#endif

        public System.Drawing.Point Location
        {
            get { return _location; }
            set { _location = value; _locationPending = true; }
        }

        public System.Drawing.Rectangle Position
        {
            get { return new System.Drawing.Rectangle(_location, new System.Drawing.Size(_width, _height)); }
            set { Location = value.Location; _width = value.Width; _height = value.Height; }
        }

        public System.Drawing.Size Size { get { return new System.Drawing.Size(_width, _height); } }

        public IControl this[string id]
        {
            get
            {
                Control c;
                return _byName.TryGetValue(id, out c) ? c : null;
            }
        }

        public void Activate() { Visible = true; }
        public void Deactivate() { }
        public bool Activated { get { return Visible; } set { if (value) Visible = true; } }

        public void Dispose()
        {
            StopWaiting();
            if (_hudName != null) _hudNames.Remove(_hudName);
            try
            {
                if (_hud != null)
                {
                    _hud.OnPreRender -= OnPreRender;
                    _hud.OnRender -= OnRender;
                    _hud.Dispose();
                }
            }
            catch { }
            _hud = null;
        }
    }

    // ── Controls ───────────────────────────────────────────────────────────

    internal abstract class Control : IControl
    {
        internal View Owner;
        protected readonly int _id = UBHudControls.View.NextId();
        protected string _name = "";
        protected bool _visible = true;
        protected System.Drawing.Rectangle _pos;
        protected string _tooltip = "";

        internal virtual void Load(XmlElement e)
        {
            _name = e.GetAttribute("name");
            int l, t, w, h;
            int.TryParse(e.GetAttribute("left"), out l);
            int.TryParse(e.GetAttribute("top"), out t);
            int.TryParse(e.GetAttribute("width"), out w);
            int.TryParse(e.GetAttribute("height"), out h);
            _pos = new System.Drawing.Rectangle(l, t, w, h);
        }

        /// <summary>Draws the control with its top-left at origin + its own left/top.</summary>
        internal void DrawAt(Vec2 origin)
        {
            if (!_visible) return;
            ImGui.SetCursorPos(new Vec2(origin.X + _pos.X, origin.Y + _pos.Y));
            ImGui.PushID(_id);
            try { Draw(); }
            finally { ImGui.PopID(); }
            if (_tooltip.Length > 0 && ImGui.IsItemHovered()) global::MelksQuestTracker.Im.SetTooltip(_tooltip);   // not ImGui.SetTooltip: a "%" in it would crash
        }

        protected abstract void Draw();

        protected float W { get { return _pos.Width > 0 ? _pos.Width : 100; } }
        protected float H { get { return _pos.Height > 0 ? _pos.Height : 20; } }

        protected static Vec4 ToVec(System.Drawing.Color c)
        {
            return new Vec4(c.R / 255f, c.G / 255f, c.B / 255f, c.A / 255f);
        }

        // VVS layouts use 16-20px tall buttons/boxes; ImGui's default padding needs more than that,
        // which cut the text off. Shrink the vertical padding so the text fits the box instead.
        protected void PushFitPadding()
        {
            Vec2 pad = ImGui.GetStyle().FramePadding;
            float textH = ImGui.GetFontSize();
            float padY = Math.Max(0f, Math.Min(pad.Y, (H - textH) / 2f));
            ImGui.PushStyleVar(ImGuiStyleVar.FramePadding, new Vec2(Math.Min(pad.X, 4f), padY));
        }

        // Height to use for a frame control: the layout's height, but never less than the text.
        protected float FrameH { get { return Math.Max(H, ImGui.GetFontSize() + 2f); } }

        // Clips drawing to this control's box so long text doesn't spill over neighbours.
        protected void PushClip()
        {
            Vec2 p = ImGui.GetCursorScreenPos();
            ImGui.PushClipRect(p, new Vec2(p.X + W, p.Y + H), true);
        }

        public string Name { get { return _name; } }
        public bool Visible { get { return _visible; } set { _visible = value; } }
        public string TooltipText { get { return _tooltip; } set { _tooltip = value ?? ""; } }
        public int Id { get { return _id; } }
        public System.Drawing.Rectangle LayoutPosition { get { return _pos; } set { _pos = value; } }
        public virtual void Dispose() { }
    }

    internal class FixedLayout : Control
    {
        internal readonly List<Control> Children = new List<Control>();

        protected override void Draw()
        {
            Vec2 origin = ImGui.GetCursorPos();
            float maxX = 0, maxY = 0;
            foreach (Control c in Children)
            {
                c.DrawAt(origin);
                System.Drawing.Rectangle r = c.LayoutPosition;
                if (c.Visible)
                {
                    maxX = Math.Max(maxX, r.Right);
                    maxY = Math.Max(maxY, r.Bottom);
                }
            }
            // Reserve the area so the window can scroll to everything.
            ImGui.SetCursorPos(new Vec2(origin.X, origin.Y));
            ImGui.Dummy(new Vec2(Math.Max(1, maxX), Math.Max(1, maxY)));
        }
    }

    /// <summary>An area the plugin draws itself (CustomDraw.Areas[name]); grows with the window like a list.</summary>
    internal class CustomArea : Control
    {
        protected override void Draw()
        {
            Vec2 avail = ImGui.GetContentRegionAvail();
            float w = W, h = H;
            if (_pos.Right >= Owner.ViewWidth - 24 && avail.X > w) w = avail.X;
            if (_pos.Bottom >= Owner.ViewHeight - 24 && avail.Y > h) h = avail.Y;
            global::MelksQuestTracker.CustomDraw.Draw(_name, w, h);
        }
    }

    internal class Notebook : Control, INotebook
    {
        internal readonly List<KeyValuePair<string, Control>> Pages = new List<KeyValuePair<string, Control>>();
        private int _active;
        private int _requested = -1;

        public event EventHandler<MVIndexChangeEventArgs> Change;
        /// <summary>Pages not shown (by their label) - the plugin decides (a server without /qb has no Current QB tab).</summary>
        public static Func<string, bool> HidePage;

        protected override void Draw()
        {
            if (!ImGui.BeginTabBar("##nb")) return;
            int req = _requested;   // a switch asked for while a page draws (e.g. a button on it) waits for the next frame
            for (int i = 0; i < Pages.Count; i++)
            {
                Func<string, bool> hide = HidePage;
                bool hidden = false;
                if (hide != null) try { hidden = hide(Pages[i].Key ?? ""); } catch { }
                if (hidden) continue;
                string label = (string.IsNullOrEmpty(Pages[i].Key) ? "Page " + (i + 1) : Pages[i].Key) + "##p" + i;
                bool open = true;
                bool shown = req == i
                    ? ImGui.BeginTabItem(label, ref open, ImGuiTabItemFlags.SetSelected)   // switch tab from code
                    : ImGui.BeginTabItem(label);
                if (shown)
                {
                    if (_active != i && req < 0)
                    {
                        _active = i;
                        int idx = i;
                        EventHandler<MVIndexChangeEventArgs> h = Change;
                        if (h != null) Owner.Defer(() => h(this, new MVIndexChangeEventArgs(_id, idx)));
                    }
                    IntPtr win = global::MelksQuestTracker.Im.Window();
                    try { if (Pages[i].Value != null) Pages[i].Value.DrawAt(ImGui.GetCursorPos()); }
                    catch (Exception ex) { global::MelksQuestTracker.Im.BackTo(win); global::MelksQuestTracker.Util.LogError(ex); }   // the tabs after it still show
                    ImGui.EndTabItem();
                }
            }
            if (_requested == req) _requested = -1;
            ImGui.EndTabBar();
        }

        public int ActiveTab
        {
            get { return _active; }
            set { _active = value; _requested = value; }
        }
    }

    internal class StaticText : Control, IStaticText
    {
        private string _text = "";
        private System.Drawing.Color _color = System.Drawing.Color.Empty;

        public event EventHandler<MVControlEventArgs> Click;

        internal override void Load(XmlElement e) { base.Load(e); _text = e.GetAttribute("text"); }

        protected override void Draw()
        {
            Vec2 start = ImGui.GetCursorPos();
            PushClip();
            if (_color.IsEmpty) ImGui.TextUnformatted(_text);
            else global::MelksQuestTracker.Im.TextColored(ToVec(_color), _text);   // not ImGui.TextColored: a "%" in it would crash
            ImGui.PopClipRect();
            if (Click != null)
            {
                ImGui.SetCursorPos(start);
                if (ImGui.InvisibleButton("##st", new Vec2(W, H)))
                {
                    EventHandler<MVControlEventArgs> h = Click;
                    Owner.Defer(() => h(this, new MVControlEventArgs(_id)));
                }
            }
        }

        public string Text { get { return _text; } set { _text = value ?? ""; } }
        // Set by plugins through reflection for coloured status lines.
        public System.Drawing.Color TextColor { get { return _color; } set { _color = value; } }
    }

    internal class Button : Control, IButton
    {
        private string _text = "";
        private System.Drawing.Color _color = System.Drawing.Color.Empty;
        private bool _enabled = true;

        public event EventHandler Hit;
        public event EventHandler<MVControlEventArgs> Click;

        internal override void Load(XmlElement e) { base.Load(e); _text = e.GetAttribute("text"); }

        protected override void Draw()
        {
            if (!_enabled) ImGui.BeginDisabled();
            if (!_color.IsEmpty) ImGui.PushStyleColor(ImGuiCol.Text, ToVec(_color));
            PushFitPadding();
            bool pressed = ImGui.Button(_text + "##b", new Vec2(W, FrameH));
            ImGui.PopStyleVar();
            if (!_color.IsEmpty) ImGui.PopStyleColor();
            if (!_enabled) ImGui.EndDisabled();
            if (pressed)
            {
                EventHandler hit = Hit;
                EventHandler<MVControlEventArgs> click = Click;
                Owner.Defer(() =>
                {
                    if (hit != null) hit(this, EventArgs.Empty);
                    if (click != null) click(this, new MVControlEventArgs(_id));
                });
            }
        }

        public string Text { get { return _text; } set { _text = value ?? ""; } }
        public System.Drawing.Color TextColor { get { return _color; } set { _color = value; } }
        public bool Enabled { get { return _enabled; } set { _enabled = value; } }
    }

    internal class CheckBox : Control, ICheckBox
    {
        private string _text = "";
        private bool _checked;

        public event EventHandler<MVCheckBoxChangeEventArgs> Change;
        public event EventHandler Change_Old;

        internal override void Load(XmlElement e)
        {
            base.Load(e);
            _text = e.GetAttribute("text");
            string c = e.GetAttribute("checked");
            _checked = c == "true" || c == "True" || c == "1";
        }

        protected override void Draw()
        {
            bool v = _checked;
            PushFitPadding();
            bool changed = ImGui.Checkbox(_text + "##c", ref v);
            ImGui.PopStyleVar();
            if (changed)
            {
                _checked = v;
                EventHandler<MVCheckBoxChangeEventArgs> h = Change;
                EventHandler h2 = Change_Old;
                Owner.Defer(() =>
                {
                    if (h != null) h(this, new MVCheckBoxChangeEventArgs(_id, v));
                    if (h2 != null) h2(this, EventArgs.Empty);
                });
            }
        }

        public string Text { get { return _text; } set { _text = value ?? ""; } }
        public bool Checked { get { return _checked; } set { _checked = value; } }
    }

    internal class TextBox : Control, ITextBox
    {
        private string _text = "";
        private bool _dirty;

        public event EventHandler<MVTextBoxChangeEventArgs> Change;
        public event EventHandler Change_Old;
        public event EventHandler<MVTextBoxEndEventArgs> End;

        internal override void Load(XmlElement e) { base.Load(e); _text = e.GetAttribute("text"); }

        protected override void Draw()
        {
            ImGui.SetNextItemWidth(W);
            string v = _text;
            PushFitPadding();
            bool enter = ImGui.InputText("##t", ref v, 1024, ImGuiInputTextFlags.EnterReturnsTrue);
            ImGui.PopStyleVar();
            if (v != _text)
            {
                _text = v;
                _dirty = true;
                string now = v;
                EventHandler<MVTextBoxChangeEventArgs> h = Change;
                EventHandler h2 = Change_Old;
                Owner.Defer(() =>
                {
                    if (h != null) h(this, new MVTextBoxChangeEventArgs(_id, now));
                    if (h2 != null) h2(this, EventArgs.Empty);
                });
            }
            if (enter || (_dirty && ImGui.IsItemDeactivated()))
            {
                _dirty = false;
                EventHandler<MVTextBoxEndEventArgs> h = End;
                bool ok = enter;
                if (h != null) Owner.Defer(() => h(this, new MVTextBoxEndEventArgs(_id, ok)));
            }
        }

        public string Text { get { return _text; } set { _text = value ?? ""; } }
        public int Caret { get { return _text.Length; } set { } }
    }

    internal class List : Control, IList
    {
        // choices="A|B|C" on a text column turns its cells into dropdowns (UtilityBelt only;
        // VVS ignores the attribute). Picking one puts the choice text in row[col][0], sets
        // row[col][2] = "picked" and raises Click for that cell.
        private class Col { public bool Check; public int Width; public string[] Choices; }
        private readonly List<Col> _cols = new List<Col>();
        private readonly List<Row> _rows = new List<Row>();
        private float _scroll;
        private bool _scrollPending;

        public event EventHandler<MVListSelectEventArgs> Selected;
        public event dClickedList Click;

        internal override void Load(XmlElement e)
        {
            base.Load(e);
            foreach (XmlNode n in e.ChildNodes)
            {
                XmlElement c = n as XmlElement;
                if (c == null || c.Name != "column") continue;
                int w; int.TryParse(c.GetAttribute("width"), out w);
                string ch = c.GetAttribute("choices");
                _cols.Add(new Col
                {
                    Check = c.GetAttribute("progid") == "DecalControls.Checkbox",
                    Width = w,
                    Choices = string.IsNullOrEmpty(ch) ? null : ch.Split('|')
                });
            }
            if (_cols.Count == 0) _cols.Add(new Col { Width = 0 });
        }

        protected override void Draw()
        {
            ImGuiTableFlags flags = ImGuiTableFlags.RowBg | ImGuiTableFlags.ScrollY | ImGuiTableFlags.SizingStretchProp | ImGuiTableFlags.BordersOuter;
            // A list that reaches the right/bottom of the original layout grows with the window.
            Vec2 avail = ImGui.GetContentRegionAvail();
            float lw = W, lh = H;
            if (_pos.Right >= Owner.ViewWidth - 24 && avail.X > lw) lw = avail.X;
            if (_pos.Bottom >= Owner.ViewHeight - 24 && avail.Y > lh) lh = avail.Y;
            if (!ImGui.BeginTable("##l", _cols.Count, flags, new Vec2(lw, lh))) return;
            // Checkbox columns are fixed; text columns share the rest in the XML's proportions,
            // so the list always fits its box (no last column pushed off the edge).
            bool anyCheck = false;
            for (int c = 0; c < _cols.Count; c++) if (_cols[c].Choices != null) anyCheck = true;   // dropdown rows are frame height too
            for (int c = 0; c < _cols.Count; c++)
            {
                if (_cols[c].Check) { anyCheck = true; ImGui.TableSetupColumn("##c" + c, ImGuiTableColumnFlags.WidthFixed, ImGui.GetFrameHeight()); }
                else ImGui.TableSetupColumn("##c" + c, ImGuiTableColumnFlags.WidthStretch, Math.Max(10, _cols[c].Width));
            }

            if (_scrollPending) { ImGui.SetScrollY(_scroll); _scrollPending = false; }

            // Only draw the rows that are on screen (lists can have thousands of rows).
            float cellPad = ImGui.GetStyle().CellPadding.Y;
            float rowH = (anyCheck ? ImGui.GetFrameHeight() : ImGui.GetTextLineHeight()) + 2f * cellPad;
            float scrollY = ImGui.GetScrollY();
            int first = Math.Max(0, (int)(scrollY / rowH) - 1);
            int last = Math.Min(_rows.Count, (int)((scrollY + lh) / rowH) + 2);
            if (first > 0) ImGui.TableNextRow(ImGuiTableRowFlags.None, first * rowH);

            for (int r = first; r < last; r++)
            {
                ImGui.TableNextRow(ImGuiTableRowFlags.None, rowH);
                Row row = _rows[r];
                for (int c = 0; c < _cols.Count; c++)
                {
                    ImGui.TableSetColumnIndex(c);
                    Cell cell = row.Cell(c);
                    bool clicked;
                    ImGui.PushID(r * 64 + c);
                    if (_cols[c].Check)
                    {
                        bool v = cell.Value[0] is bool && (bool)cell.Value[0];
                        ImGui.PushStyleVar(ImGuiStyleVar.FramePadding, new Vec2(2f, Math.Max(0f, (ImGui.GetFrameHeight() - ImGui.GetFontSize()) / 2f)));
                        clicked = ImGui.Checkbox("##k", ref v);
                        ImGui.PopStyleVar();
                        if (clicked) cell.Value[0] = v;   // toggled like VVS does before raising Click
                    }
                    else if (_cols[c].Choices != null)
                    {
                        string text = cell.Value[0] == null ? "" : cell.Value[0].ToString();
                        clicked = false;
                        ImGui.SetNextItemWidth(-1);
                        ImGui.PushStyleVar(ImGuiStyleVar.FramePadding, new Vec2(3f, Math.Max(0f, (ImGui.GetFrameHeight() - ImGui.GetFontSize()) / 2f)));
                        if (ImGui.BeginCombo("##dd", text, ImGuiComboFlags.HeightLarge))
                        {
                            string[] choices = _cols[c].Choices;
                            for (int k = 0; k < choices.Length; k++)
                            {
                                bool sel = string.Equals(choices[k], text, StringComparison.OrdinalIgnoreCase);
                                if (ImGui.Selectable(choices[k] + "##o" + k, sel))
                                {
                                    cell.Value[0] = choices[k];
                                    cell.Value[2] = "picked";   // tells the plugin this came from the dropdown
                                    clicked = true;
                                }
                            }
                            ImGui.EndCombo();
                        }
                        ImGui.PopStyleVar();
                    }
                    else
                    {
                        string text = cell.Value[0] == null ? "" : cell.Value[0].ToString();
                        System.Drawing.Color col = cell.Value[1] is System.Drawing.Color ? (System.Drawing.Color)cell.Value[1] : cell.Color;
                        bool colored = !col.IsEmpty;
                        if (colored) ImGui.PushStyleColor(ImGuiCol.Text, ToVec(col));
                        clicked = ImGui.Selectable(text + "##s", false);
                        if (colored) ImGui.PopStyleColor();
                    }
                    ImGui.PopID();
                    if (clicked)
                    {
                        int rr = r, cc = c;
                        dClickedList h = Click;
                        EventHandler<MVListSelectEventArgs> h2 = Selected;
                        Owner.Defer(() =>
                        {
                            if (h != null) h(this, rr, cc);
                            if (h2 != null) h2(this, new MVListSelectEventArgs(_id, rr, cc));
                        });
                    }
                }
            }
            if (last < _rows.Count) ImGui.TableNextRow(ImGuiTableRowFlags.None, (_rows.Count - last) * rowH);
            _scroll = ImGui.GetScrollY();
            ImGui.EndTable();
        }

        public void Clear() { _rows.Clear(); }
        public IListRow this[int row] { get { return _rows[row]; } }
        public IListRow AddRow() { Row r = new Row(_cols.Count); _rows.Add(r); return r; }
        public IListRow Add() { return AddRow(); }
        public IListRow InsertRow(int pos) { Row r = new Row(_cols.Count); _rows.Insert(Math.Max(0, Math.Min(pos, _rows.Count)), r); return r; }
        public IListRow Insert(int pos) { return InsertRow(pos); }
        public int RowCount { get { return _rows.Count; } }
        public void RemoveRow(int index) { if (index >= 0 && index < _rows.Count) _rows.RemoveAt(index); }
        public void Delete(int index) { RemoveRow(index); }
        public int ColCount { get { return _cols.Count; } }
        public int ScrollPosition { get { return (int)_scroll; } set { _scroll = value; _scrollPending = true; } }

        internal class Row : IListRow
        {
            private readonly Cell[] _cells;
            public Row(int cols) { _cells = new Cell[Math.Max(1, cols)]; for (int i = 0; i < _cells.Length; i++) _cells[i] = new Cell(); }
            internal Cell Cell(int col) { return _cells[col]; }
            public IListCell this[int col] { get { return _cells[col]; } }
        }

        internal class Cell : IListCell
        {
            // [0] = text or checkbox state, [1] = text colour, [2] = icon (ignored)
            internal readonly object[] Value = new object[3];
            private System.Drawing.Color _color = System.Drawing.Color.Empty;
            private int _width;

            public System.Drawing.Color Color { get { return _color; } set { _color = value; Value[1] = value; } }
            public int Width { get { return _width; } set { _width = value; } }
            public object this[int subval]
            {
                get { return subval >= 0 && subval < Value.Length ? Value[subval] : null; }
                set { if (subval >= 0 && subval < Value.Length) Value[subval] = value; }
            }
            public void ResetColor() { _color = System.Drawing.Color.Empty; Value[1] = null; }
        }
    }

    internal class Combo : Control, ICombo
    {
        private readonly List<string> _text = new List<string>();
        private readonly List<object> _data = new List<object>();
        private int _sel = -1;

        public event EventHandler<MVIndexChangeEventArgs> Change;
        public event EventHandler Change_Old;

        protected override void Draw()
        {
            ImGui.SetNextItemWidth(W);
            string preview = _sel >= 0 && _sel < _text.Count ? _text[_sel] : "";
            if (ImGui.BeginCombo("##cb", preview))
            {
                for (int i = 0; i < _text.Count; i++)
                {
                    if (ImGui.Selectable(_text[i] + "##" + i, i == _sel) && i != _sel)
                    {
                        _sel = i;
                        int idx = i;
                        EventHandler<MVIndexChangeEventArgs> h = Change;
                        EventHandler h2 = Change_Old;
                        Owner.Defer(() =>
                        {
                            if (h != null) h(this, new MVIndexChangeEventArgs(_id, idx));
                            if (h2 != null) h2(this, EventArgs.Empty);
                        });
                    }
                }
                ImGui.EndCombo();
            }
        }

        private class TextIdx : IComboIndexer { public Combo C; public string this[int i] { get { return C._text[i]; } set { C._text[i] = value; } } }
        private class DataIdx : IComboDataIndexer { public Combo C; public object this[int i] { get { return C._data[i]; } set { C._data[i] = value; } } }

        public IComboIndexer Text { get { return new TextIdx { C = this }; } }
        public IComboDataIndexer Data { get { return new DataIdx { C = this }; } }
        public int Count { get { return _text.Count; } }
        public int Selected { get { return _sel; } set { _sel = value; } }
        public void Add(string text) { Add(text, null); }
        public void Add(string text, object obj) { _text.Add(text); _data.Add(obj); }
        public void Insert(int index, string text) { _text.Insert(index, text); _data.Insert(index, null); }
        public void RemoveAt(int index) { _text.RemoveAt(index); _data.RemoveAt(index); }
        public void Remove(int index) { RemoveAt(index); }
        public void Clear() { _text.Clear(); _data.Clear(); _sel = -1; }
    }

    internal class Slider : Control, ISlider
    {
        private int _value, _min, _max = 100;
        public event EventHandler<MVIndexChangeEventArgs> Change;
        public event EventHandler Change_Old;

        protected override void Draw()
        {
            ImGui.SetNextItemWidth(W);
            int v = _value;
            if (ImGui.SliderInt("##sl", ref v, _min, _max) && v != _value)
            {
                _value = v;
                EventHandler<MVIndexChangeEventArgs> h = Change;
                EventHandler h2 = Change_Old;
                Owner.Defer(() =>
                {
                    if (h != null) h(this, new MVIndexChangeEventArgs(_id, v));
                    if (h2 != null) h2(this, EventArgs.Empty);
                });
            }
        }

        public int Position { get { return _value; } set { _value = value; } }
        public int Maximum { get { return _max; } set { _max = value; } }
        public int Minimum { get { return _min; } set { _min = value; } }
    }

    internal class ProgressBar : Control, IProgressBar
    {
        private int _value, _max = 100;
        private string _pre = "";

        protected override void Draw()
        {
            float f = _max > 0 ? (float)_value / _max : 0f;
            ImGui.ProgressBar(f, new Vec2(W, H), _pre + _value);
        }

        public int Position { get { return _value; } set { _value = value; } }
        public int Value { get { return _value; } set { _value = value; } }
        public string PreText { get { return _pre; } set { _pre = value ?? ""; } }
        public int MaxValue { get { return _max; } set { _max = value; } }
    }
}
