///////////////////////////////////////////////////////////////////////////////
//File: ViewSystemSelector.cs
//
//Description: Picks the view system for the plugin's windows: UtilityBelt's ImGui view (the
//  only one now - the plain Decal fallback could crash the client, see CreateUB).
//  (The Virindi View Service support was removed 2026-10-27 - not used any more.)
//
//References required:
//  Decal.Adapter
//  Decal.Interop.Core
//
//Based on the VirindiPlugins MetaViewWrappers, Copyright (c) 2009 VirindiPlugins (MIT licence:
//  the above copyright notice and this permission notice shall be included in all copies or
//  substantial portions of the Software. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.)
///////////////////////////////////////////////////////////////////////////////

using System;

#if METAVIEW_PUBLIC_NS
namespace MetaViewWrappers
#else
namespace MyClasses.MetaViewWrappers
#endif
{
    internal static class ViewSystemSelector
    {
        public enum eViewSystem
        {
            DecalInject,
            UtilityBelt,
        }

        public static bool IsPresent(Decal.Adapter.Wrappers.PluginHost pHost, eViewSystem VSystem)
        {
            switch (VSystem)
            {
                case eViewSystem.UtilityBelt: return UBHudControls.UBAvailable.Check();
                case eViewSystem.DecalInject: return true;
                default: return false;
            }
        }

        ///////////////////////////////CreateViewResource///////////////////////////////

        public static IView CreateViewResource(Decal.Adapter.Wrappers.PluginHost pHost, string pXMLResource)
        {
            return CreateUB(pHost, pXMLResource, false);
        }

        public static IView CreateViewResource(Decal.Adapter.Wrappers.PluginHost pHost, string pXMLResource, eViewSystem VSystem)
        {
            return VSystem == eViewSystem.UtilityBelt ? CreateUB(pHost, pXMLResource, false) : null;   // Decal views are no longer made
        }

        ///////////////////////////////CreateViewXML///////////////////////////////

        public static IView CreateViewXML(Decal.Adapter.Wrappers.PluginHost pHost, string pXML)
        {
            return CreateUB(pHost, pXML, true);
        }

        /// <summary>
        /// The window is always a UtilityBelt one. The old fallback to a plain Decal view is gone: when UB's view
        /// failed, Decal's LoadView could crash the whole client (an access violation .NET can't catch). Now a
        /// failure is written to &lt;plugin&gt;_ui_errors.txt and thrown, so the plugin's Startup catches it and the
        /// client keeps running (just without this plugin's window).
        /// </summary>
        static IView CreateUB(Decal.Adapter.Wrappers.PluginHost pHost, string xmlOrResource, bool raw)
        {
            if (!IsPresent(pHost, eViewSystem.UtilityBelt))
            {
                Exception none = new InvalidOperationException("UtilityBelt.Service isn't loaded - this plugin's window needs it.");
                LogUiError(none);
                throw none;
            }
            try { return CreateUBView(pHost, xmlOrResource, raw); }
            catch (Exception ex)
            {
                LogUiError(ex);
                try { UBHudControls.View.Report(ex); } catch { }
                throw;
            }
        }

        static void LogUiError(Exception ex)
        {
            try
            {
                System.Reflection.Assembly a = System.Reflection.Assembly.GetExecutingAssembly();
                string dir = !string.IsNullOrEmpty(MyClasses.MetaViewWrappers.UBHudControls.WindowMemory.BaseDir) ? MyClasses.MetaViewWrappers.UBHudControls.WindowMemory.BaseDir : System.IO.Path.GetDirectoryName(a.Location);
                string file = System.IO.Path.Combine(dir, a.GetName().Name + "_ui_errors.txt");
                System.IO.File.AppendAllText(file, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + ex + "\r\n\r\n");
            }
            catch { }
        }

        public static IView CreateViewXML(Decal.Adapter.Wrappers.PluginHost pHost, string pXML, eViewSystem VSystem)
        {
            return VSystem == eViewSystem.UtilityBelt ? CreateUB(pHost, pXML, true) : null;   // Decal views are no longer made
        }

        [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
        static IView CreateUBView(Decal.Adapter.Wrappers.PluginHost pHost, string xmlOrResource, bool raw)
        {
            IView ret = new UBHudControls.View();
            if (raw) ret.InitializeRawXML(pHost, xmlOrResource);
            else ret.Initialize(pHost, xmlOrResource);
            return ret;
        }

        ///////////////////////////////HasChatOpen///////////////////////////////

        public static bool AnySystemHasChatOpen(Decal.Adapter.Wrappers.PluginHost pHost)
        {
            return pHost.Actions.ChatState;
        }
    }
}
