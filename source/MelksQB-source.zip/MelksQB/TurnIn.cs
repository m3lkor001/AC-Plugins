using System;
using System.Collections.Generic;
using Decal.Adapter;
using Decal.Adapter.Wrappers;

namespace MelksQuestTracker
{
    /// <summary>
    /// "Turn in" on the Quest page: hands the quest's items (its Items list, up to the count each) to the quest giver -
    /// the nearest NPC with that name, else the NPC you have selected - with the game's own give
    /// (CM_Inventory::Event_GiveObjectRequest, which can give part of a stack). One give every 1.5 s, so each lands.
    /// </summary>
    internal static class TurnIn
    {
        private class Give { public int Item; public int Amount; public string Name; }
        private static readonly Queue<Give> _queue = new Queue<Give>();
        private static int _npc;
        private static string _npcName = "";
        private static DateTime _next = DateTime.MinValue;
        private static int _given;

        public static bool Busy { get { return _queue.Count > 0; } }

        /// <summary>The NPC to give to: the nearest one named like the quest giver, else the selected NPC (0 = none).</summary>
        private static WorldObject FindNpc(QuestDefinition q)
        {
            CoreManager core = CoreManager.Current;
            string giver = (q.QuestGiver ?? "").Trim();
            WorldObject best = null;
            double bd = double.MaxValue;
            if (giver.Length > 0)
            {
                foreach (WorldObject o in core.WorldFilter.GetLandscape())
                {
                    if (o.ObjectClass != ObjectClass.Npc && o.ObjectClass != ObjectClass.Vendor) continue;
                    if ((o.Name ?? "").IndexOf(giver, StringComparison.OrdinalIgnoreCase) < 0 && giver.IndexOf(o.Name ?? "~", StringComparison.OrdinalIgnoreCase) < 0) continue;
                    double d = 0;
                    try { d = core.WorldFilter.Distance(core.CharacterFilter.Id, o.Id); } catch { }
                    if (d < bd) { bd = d; best = o; }
                }
            }
            if (best == null)
            {
                try
                {
                    WorldObject sel = core.WorldFilter[core.Actions.CurrentSelection];
                    if (sel != null && (sel.ObjectClass == ObjectClass.Npc || sel.ObjectClass == ObjectClass.Vendor)) best = sel;
                }
                catch { }
            }
            return best;
        }

        /// <summary>What the button would hand over: "3 of 3 Orc Ears" lines, and whether there's anything at all.</summary>
        public static List<string> Plan(QuestDefinition q, out bool any)
        {
            any = false;
            List<string> l = new List<string>();
            foreach (KeyValuePair<string, int> it in q.CollectItems)
            {
                int have = 0;
                foreach (WorldObject o in CoreManager.Current.WorldFilter.GetInventory())
                    if (string.Equals(o.Name, it.Key, StringComparison.OrdinalIgnoreCase)) have += Math.Max(1, o.Values(LongValueKey.StackCount, 1));
                int give = it.Value > 0 ? Math.Min(have, it.Value) : have;
                if (give > 0) any = true;
                l.Add(give + (it.Value > 0 ? " of " + it.Value : "") + " " + it.Key + (have == 0 ? " (none carried)" : ""));
            }
            return l;
        }

        public static void Start(QuestDefinition q)
        {
            if (Busy) { Util.WriteToChat("Turn in: still handing over the last one."); return; }
            WorldObject npc = FindNpc(q);
            if (npc == null) { Util.WriteToChat("Turn in: no " + (string.IsNullOrEmpty(q.QuestGiver) ? "quest giver" : q.QuestGiver) + " nearby - select the NPC and press it again."); return; }
            _npc = npc.Id; _npcName = npc.Name; _given = 0;
            foreach (KeyValuePair<string, int> it in q.CollectItems)
            {
                int left = it.Value > 0 ? it.Value : int.MaxValue;
                foreach (WorldObject o in CoreManager.Current.WorldFilter.GetInventory())
                {
                    if (left <= 0) break;
                    if (!string.Equals(o.Name, it.Key, StringComparison.OrdinalIgnoreCase)) continue;
                    if (o.Values(LongValueKey.EquippedSlots, 0) != 0) continue;
                    int n = Math.Max(1, o.Values(LongValueKey.StackCount, 1)), amount = Math.Min(n, left);
                    _queue.Enqueue(new Give { Item = o.Id, Amount = amount, Name = it.Key });
                    left -= amount;
                }
            }
            if (_queue.Count == 0) { Util.WriteToChat("Turn in: you don't carry any of this quest's items."); return; }
            Util.WriteToChat("Turn in: giving " + _queue.Count + " stack" + (_queue.Count == 1 ? "" : "s") + " to " + _npcName + ".");
            _next = DateTime.MinValue;
        }

        /// <summary>Every frame.</summary>
        public static void Frame()
        {
            if (_queue.Count == 0 || DateTime.Now < _next) return;
            Give g = _queue.Dequeue();
            _next = DateTime.Now.AddSeconds(1.5);
            try
            {
                AcClient.CM_Inventory.Event_GiveObjectRequest((uint)_npc, (uint)g.Item, (uint)g.Amount);
                _given++;
            }
            catch (Exception ex) { Util.WriteToChat("Turn in: couldn't give " + g.Name + " - " + ex.Message); _queue.Clear(); return; }
            if (_queue.Count == 0) Util.WriteToChat("Turn in: done (" + _given + " given to " + _npcName + ").");
        }
    }
}
