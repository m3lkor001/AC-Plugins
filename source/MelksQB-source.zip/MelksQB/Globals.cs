using System;

using Decal.Adapter;
using Decal.Adapter.Wrappers;

namespace MelksQuestTracker
{
	public static class Globals
	{
		public static void Init(string pluginName, PluginHost host, CoreManager core)
		{
			PluginName = pluginName;

			Host = host;

			Core = core;
		}

		public static string PluginName { get; private set; }

		public static PluginHost Host { get; private set; }

		public static CoreManager Core { get; private set; }
	}

    /// <summary>
    /// Which server this is (Config > Server): Infinite Leaftide has /qb (quest bonus stamps - the Current QB tab, the
    /// flags on the Main tab) and tier 11+ copies of places; other servers have neither. /myquests is its own switch.
    /// </summary>
    internal static class ServerMode
    {
        public static int Kind = 0;          // 0 auto (by the server's name), 1 Infinite Leaftide, 2 standard
        public static bool MyQuests = true;  // the server answers /myquests

        public static bool Ilt
        {
            get
            {
                if (Kind == 1) return true;
                if (Kind == 2) return false;
                string srv = "";
                try { srv = Decal.Adapter.CoreManager.Current.CharacterFilter.Server ?? ""; } catch { }
                return srv.Length == 0 || srv.IndexOf("Leaftide", System.StringComparison.OrdinalIgnoreCase) >= 0;
            }
        }
    }
}
