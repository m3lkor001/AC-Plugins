using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;

namespace MelksQuestTracker
{
    /// <summary>One kill task, as the chat counts it.</summary>
    public class KillTask
    {
        public string Name = "";          // what the chat line counts, e.g. "Snow Tusker Warriors"
        public int Have, Need;
        public bool Complete;
        public DateTime LastSeen = DateTime.MinValue;
        public bool OnHud = true;         // repeat list only: shown on the bounty pop-up
        public string Quest = "";         // matched quest name (filled in when shown)
        public bool Group;                // Name is a quest whose "KT mobs" all count towards one task
        public string LastMob = "";       // the monster named in the latest line (for a group)
        public bool Item;                 // an item to collect (Name = the item, Quest = its quest): Have = how many are in your pack

        public string CountText
        {
            get
            {
                if (Complete) return Have + " - done";
                return Need > 0 ? Have + " / " + Need : Have.ToString();
            }
        }
    }

    /// <summary>
    /// Reads the kill task lines that follow a kill (yours or a fellow's):
    ///   You have killed 10 Snow Tusker Warriors! You must kill 20 to complete your task.
    ///   You have killed 4 Frozen Crystals! Your task is complete!
    ///   You have killed 6 of 15 Broodguard Grenadiers!          (the newer tasks, e.g. T11)
    ///   You have killed 3.75 of 15 Hiveborn Grenadiers!         (a fellowship's share of a kill)
    ///   Lifestone recorded. 2 of 100 lifestones remember you.   (a counted task that isn't kills: KT mobs "Lifestone")
    /// </summary>
    public static class KillTaskParser
    {
        private static readonly Regex Rx = new Regex(
            @"^You have killed (?<n>[\d,]+(?:\.\d+)?) (?<name>.+?)! (?:You must kill (?<total>[\d,]+) to complete your task\.?|(?<done>Your task is complete!?))",
            RegexOptions.IgnoreCase);

        private static readonly Regex RxOf = new Regex(
            @"^You have killed (?<n>[\d,]+(?:\.\d+)?) of (?<total>[\d,]+) (?<name>.+?)!(?:\s*(?<done>Your task is complete!?))?\s*$",
            RegexOptions.IgnoreCase);

        // other counted tasks, read the same way: "Lifestone recorded. 2 of 100 lifestones remember you."
        private static readonly Regex RxRemember = new Regex(
            @"^(?:.+?\.\s+)?(?<n>[\d,]+) of (?<total>[\d,]+) (?<name>[A-Za-z' -]+?) remember you\.?\s*$",
            RegexOptions.IgnoreCase);

        // (a share of a kill counts now: "You have killed 3.75 of 15 Hiveborn Grenadiers!" - whole kills are kept)
        private static int Num(string s)
        {
            double v;
            return double.TryParse((s ?? "").Replace(",", ""), NumberStyles.Float, CultureInfo.InvariantCulture, out v) ? (int)Math.Floor(v + 1e-9) : 0;
        }

        public static bool TryRead(string text, out string name, out int have, out int need, out bool complete)
        {
            name = ""; have = need = 0; complete = false;
            string t = (text ?? "").Trim();
            Match m = RxRemember.Match(t);
            if (m.Success)
            {
                string nm = m.Groups["name"].Value.Trim();
                name = nm.Length > 0 ? char.ToUpperInvariant(nm[0]) + nm.Substring(1) : nm;
                have = Num(m.Groups["n"].Value);
                need = Num(m.Groups["total"].Value);
                complete = need > 0 && have >= need;
                return name.Length > 0;
            }
            m = RxOf.Match(t);
            if (m.Success)
            {
                name = m.Groups["name"].Value.Trim();
                have = Num(m.Groups["n"].Value);
                need = Num(m.Groups["total"].Value);
                complete = m.Groups["done"].Success || (need > 0 && have >= need);
                return name.Length > 0;
            }
            m = Rx.Match(t);
            if (!m.Success) return false;
            name = m.Groups["name"].Value.Trim();
            have = Num(m.Groups["n"].Value);
            complete = m.Groups["done"].Success;
            need = complete ? have : Num(m.Groups["total"].Value);
            return name.Length > 0;
        }

        /// <summary>"Snow Tusker Warriors" -> "Snow Tusker Warrior" (for finding the quest).</summary>
        public static string Singular(string name)
        {
            string n = (name ?? "").Trim();
            if (n.EndsWith("ies", StringComparison.OrdinalIgnoreCase) && n.Length > 4) return n.Substring(0, n.Length - 3) + "y";
            if (n.EndsWith("es", StringComparison.OrdinalIgnoreCase) && (n.EndsWith("sses", StringComparison.OrdinalIgnoreCase) || n.EndsWith("ches", StringComparison.OrdinalIgnoreCase))) return n.Substring(0, n.Length - 2);
            if (n.EndsWith("s", StringComparison.OrdinalIgnoreCase) && !n.EndsWith("ss", StringComparison.OrdinalIgnoreCase)) return n.Substring(0, n.Length - 1);
            return n;
        }
    }
}
