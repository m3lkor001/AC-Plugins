using System;
using System.Collections.Generic;
using System.IO;
using ImGuiNET;
using Vec2 = System.Numerics.Vector2;
using Vec4 = System.Numerics.Vector4;

namespace MelksQuestTracker
{
    /// <summary>
    /// Shows a dungeon map (the "ACmaps" / "Wiki Map" links on a walkthrough) from the local maps folder:
    /// MelksQB\Maps by default, or the folder named in MelksQB\MapsFolder.txt. A map is found by its file
    /// name, with or without the extension, or by the id in it ("Accursed Halls (01F9).gif" is 01F9), in the folder or below it.
    /// </summary>
    internal static class MapView
    {
        private static string _id, _file, _err;
        private static bool _open;
        private static UtilityBelt.Service.Views.ManagedTexture _tex;
        private static Vec2 _size;
        private static float _zoom;          // 0 = fit the window
        private static Dictionary<string, string> _index;
        private static DateTime _indexedAt = DateTime.MinValue;

        public static string Folder
        {
            get
            {
                try
                {
                    string cfg = Util.FullPath("MapsFolder.txt");
                    if (File.Exists(cfg))
                    {
                        string p = File.ReadAllText(cfg).Trim().Trim('"');
                        if (p.Length > 0) return p;
                    }
                }
                catch { }
                return Util.FullPath("Maps");
            }
        }

        private static string Find(string id)
        {
            if ((DateTime.Now - _indexedAt).TotalSeconds > 30 || _index == null)
            {
                _indexedAt = DateTime.Now;
                _index = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                try
                {
                    string dir = Folder;
                    if (Directory.Exists(dir))
                        foreach (string f in Directory.GetFiles(dir, "*", SearchOption.AllDirectories))
                        {
                            string ext = Path.GetExtension(f).ToLowerInvariant();
                            if (ext != ".png" && ext != ".gif" && ext != ".jpg" && ext != ".jpeg" && ext != ".bmp") continue;
                            string name = Path.GetFileName(f), bare = Path.GetFileNameWithoutExtension(f);
                            if (!_index.ContainsKey(name)) _index[name] = f;
                            if (!_index.ContainsKey(bare)) _index[bare] = f;
                            // the maps are named "Dungeon Name (01F9).gif": also found by the id and by the dungeon's name
                            System.Text.RegularExpressions.Match m = System.Text.RegularExpressions.Regex.Match(bare, @"^(.*?)\s*\(([0-9A-Fa-f]{4})\)\s*$");
                            if (m.Success)
                            {
                                if (!_index.ContainsKey(m.Groups[2].Value)) _index[m.Groups[2].Value] = f;
                                if (!_index.ContainsKey(m.Groups[1].Value)) _index[m.Groups[1].Value] = f;
                            }
                        }
                }
                catch (Exception ex) { Util.LogError(ex); }
            }
            string r;
            if (_index.TryGetValue(id, out r)) return r;
            if (_index.TryGetValue(Path.GetFileNameWithoutExtension(id), out r)) return r;
            return null;
        }

        /// <summary>There's a map with this name / id in the maps folder.</summary>
        public static bool Has(string id) { return !string.IsNullOrEmpty(id) && Find(id) != null; }
        public static string Showing { get { return _open ? _id : null; } }
        /// <summary>The picture's file for a dungeon id, or null.</summary>
        public static string PathOf(string id) { return string.IsNullOrEmpty(id) ? null : Find(id); }

        /// <param name="expand">Opened by a click: open out even if left collapsed (false when it opens by itself on going into a dungeon).</param>
        public static void Show(string id, bool expand = true)
        {
            Free();
            _id = (id ?? "").Trim();
            _file = Find(_id);
            _err = _file == null ? "No map named " + _id + " in " + Folder : null;
            _zoom = 0;
            _open = true;
            _shown = false;
            _expand = expand;   // opened by a click: open out, even if it was left collapsed
            try { Draw(); } catch (Exception ex) { Util.LogError(ex); }   // open its window now (not when the tracker next draws - it may be collapsed)
        }

        /// <summary>Closes the map window.</summary>
        public static void Hide()
        {
            try { if (_hud != null) _hud.Visible = false; } catch { }
            _open = false; _shown = false; Free();
        }

        private static void Free()
        {
            try { if (_tex != null) ((IDisposable)_tex).Dispose(); } catch { }
            _tex = null;
        }

        // ── its own window (a UtilityBelt HUD of its own): collapsing or hiding the tracker leaves the map alone ──
        private static UtilityBelt.Service.Views.Hud _hud;
        private static bool _expand;
        private static float _alpha = -1f;   // the map window's opacity (0.15-1), remembered in MapOpacity.txt

        private static float Alpha
        {
            get
            {
                if (_alpha < 0)
                {
                    _alpha = 1f;
                    try { string f = Util.FullPath("MapOpacity.txt"); float a; if (File.Exists(f) && float.TryParse(File.ReadAllText(f).Trim(), System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out a)) _alpha = Math.Max(0.15f, Math.Min(1f, a)); } catch { }
                }
                return _alpha;
            }
            set
            {
                _alpha = Math.Max(0.15f, Math.Min(1f, value));
                try { File.WriteAllText(Util.FullPath("MapOpacity.txt"), _alpha.ToString("0.00", System.Globalization.CultureInfo.InvariantCulture)); } catch { }
            }
        }

        private static bool EnsureHud()
        {
            if (_hud != null) return true;
            try
            {
                if (UtilityBelt.Service.UBService.Huds == null) return false;
                _hud = UtilityBelt.Service.UBService.Huds.CreateHud("MelksQB Map", MyClasses.MetaViewWrappers.UBHudControls.BarIcon.Make("Map"));
                _hud.ShowInBar = false;
                _hud.OnPreRender += (s, e) =>
                {
                    float[] r;
                    if (MyClasses.MetaViewWrappers.UBHudControls.WindowMemory.Restore(ref _restoredFor))
                    {
                        // where this character had it (per-character window memory) - again when another logs in
                        if (MyClasses.MetaViewWrappers.UBHudControls.WindowMemory.TryGet("MelksQB Map", out r))
                        {
                            ImGui.SetNextWindowPos(new Vec2(r[0], r[1]), ImGuiCond.Always);
                            ImGui.SetNextWindowSize(new Vec2(r[2], r[3]), ImGuiCond.Always);
                        }
                    }
                    ImGui.SetNextWindowSize(new Vec2(720, 720), ImGuiCond.FirstUseEver);
                    ImGui.SetNextWindowBgAlpha(Alpha);
                    if (_expand) { _expand = false; ImGui.SetNextWindowCollapsed(false, ImGuiCond.Always); }
                };
                _hud.OnRender += (s, e) =>
                {
                    try { MyClasses.MetaViewWrappers.UBHudControls.WindowMemory.Track("MelksQB Map"); } catch { }
                    try { Content(); } catch (Exception ex) { Util.LogError(ex); }
                };
                return true;
            }
            catch (Exception ex) { Util.LogError(ex); _hud = null; return false; }
        }

        /// <summary>Called every frame from the tracker (and whenever): opens the map's window once there's one to show.</summary>
        public static void Draw()
        {
            if (!_open) return;
            if (!EnsureHud()) return;
            if (_shown) { if (!_hud.Visible) { _open = false; _shown = false; Free(); } return; }   // closed with its x
            _hud.Title = "Map " + _id;
            _hud.Visible = true;
            _shown = true;
        }

        private static bool _shown;
        private static int _restoredFor;

        public static void Dispose()
        {
            try { if (_hud != null) _hud.Dispose(); } catch { }
            _hud = null; _open = false; _shown = false; Free();
        }

        private static void Content()
        {
            if (_tex == null && _file != null && _err == null)
            {
                try
                {
                    // (ACGodot: the Decal stand-in reads the picture - GIF included)
                    _tex = new UtilityBelt.Service.Views.ManagedTexture(_file);
                    _size = _tex.Size;
                    if (_size.X <= 0) { _err = "Couldn't read " + _file; Free(); }
                }
                catch (Exception ex) { _err = "Couldn't load " + _file + ": " + ex.Message; Free(); }
            }

            if (_err != null)
            {
                Im.TextWrapped(_err);
                Im.TextDisabled("Put the maps in that folder (any sub-folders are fine), or write another folder's path in MapsFolder.txt next to the plugin.");
                return;
            }
            if (_tex == null) return;
            DungeonButtons();
            if (ImGui.Button("Fit")) _zoom = 0;
            ImGui.SameLine(); if (ImGui.Button("-")) _zoom = Math.Max(0.1f, Cur() / 1.25f);
            ImGui.SameLine(); if (ImGui.Button("+")) _zoom = Math.Min(8f, Cur() * 1.25f);
            ImGui.SameLine(); if (ImGui.Button("100%")) _zoom = 1f;
            ImGui.SameLine(); Im.TextDisabled((int)(Cur() * 100) + "%");
            // opacity, top right (across from the size buttons): the window and the map itself
            float sw = 150f;
            float right = ImGui.GetWindowContentRegionMax().X;
            ImGui.SameLine(Math.Max(ImGui.GetCursorPosX() + 10, right - sw - 60));
            Im.TextDisabled("Opacity");
            ImGui.SameLine();
            ImGui.SetNextItemWidth(sw);
            float a = Alpha * 100f;
            if (ImGui.SliderFloat("##mapalpha", ref a, 15f, 100f, "%.0f%%")) Alpha = a / 100f;
            if (ImGui.IsItemHovered()) Im.SetTooltip(Path.GetFileName(_file) + "\nDrag to move the map, wheel to zoom.\nCtrl+click the slider to type a number.");
            Vec2 avail = ImGui.GetContentRegionAvail();
            _fit = Math.Min(avail.X / Math.Max(1, _size.X), avail.Y / Math.Max(1, _size.Y));
            ImGui.PushStyleColor(ImGuiCol.ChildBg, new Vec4(0, 0, 0, 0));
            if (ImGui.BeginChild("##map", avail, true, ImGuiWindowFlags.HorizontalScrollbar))
            {
                float z = Cur();
                Vec2 at = ImGui.GetCursorPos();
                Vec2 room = ImGui.GetContentRegionAvail();
                Vec2 sz = new Vec2(_size.X * z, _size.Y * z);
                ImGui.Image(_tex.TexturePtr, sz, new Vec2(0, 0), new Vec2(1, 1), new Vec4(1, 1, 1, Alpha));
                // an invisible button over the picture takes the mouse: dragging moves the map, not the window
                ImGui.SetCursorPos(at);
                ImGui.InvisibleButton("##mapdrag", new Vec2(Math.Max(1, Math.Max(sz.X, room.X)), Math.Max(1, Math.Max(sz.Y, room.Y))));
                bool dragging = ImGui.IsItemActive();
                if (ImGui.IsWindowHovered() || dragging)
                {
                    if (dragging && ImGui.IsMouseDragging(ImGuiMouseButton.Left))
                    {
                        Vec2 d = ImGui.GetIO().MouseDelta;
                        ImGui.SetScrollX(ImGui.GetScrollX() - d.X);
                        ImGui.SetScrollY(ImGui.GetScrollY() - d.Y);
                    }
                    float wheel = ImGui.GetIO().MouseWheel;
                    if (wheel != 0) _zoom = Math.Max(0.1f, Math.Min(8f, Cur() * (wheel > 0 ? 1.15f : 1 / 1.15f)));
                }
            }
            ImGui.EndChild();
            ImGui.PopStyleColor();
        }

        // ── ACGodot: the dungeon this picture is of - its layout on the in-game map, and its doors, levers ... onto it ──
        private static int Lb()
        {
            var m = System.Text.RegularExpressions.Regex.Match((_id ?? "") + " " + Path.GetFileNameWithoutExtension(_file ?? ""), @"\b([0-9A-Fa-f]{4})\b");
            int lb;
            return m.Success && int.TryParse(m.Groups[1].Value, System.Globalization.NumberStyles.HexNumber, null, out lb) ? lb : -1;
        }

        private static void DungeonButtons()
        {
            int lb = Lb();
            if (lb < 0) return;
            if (ImGui.Button("Open the in-game map here##mvig")) ACGodot.DecalShim.Bridge.Host?.ShowDungeonMap?.Invoke(lb);
            if (ImGui.IsItemHovered()) Im.SetTooltip("ACGodot's map (M), on this dungeon's layout.");
            System.Collections.Generic.Dictionary<uint, Travel.DCell> d = Travel.WorldMap.Dungeon(lb);
            if (d != null)
            {
                ImGui.SameLine();
                if (ImGui.Button("Copy points from ACMaps...##mvac")) Travel.AcMapsImport.Toggle(lb, Travel.Travel.DungeonInst(lb), _id, d);
                if (ImGui.IsItemHovered()) Im.SetTooltip("Finds the doors, gates, levers, chests ... on this picture and puts the ones you pick on the in-game map.");
                try { Travel.AcMapsImport.Window(Travel.Travel.DungeonIn(lb), d); } catch (Exception ex) { Util.LogError(ex); }
            }
        }

        private static float _fit = 1f;
        private static float Cur() { return _zoom > 0 ? _zoom : Math.Max(0.05f, _fit); }
    }
}
