using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using ImGuiNET;
using Vec2 = System.Numerics.Vector2;
using Vec4 = System.Numerics.Vector4;

namespace MelksQuestTracker
{
    /// <summary>The Search tab: finds text in every part of every quest (name, info, flags, walkthrough) and shows where.</summary>
    internal static class QuestSearch
    {
        public static Action<QuestDefinition> Open;
        public static Action<QuestDefinition> Edit;

        private class Part { public QuestDefinition Q; public string Field; public string Raw; public string Shown; }
        private class Hit { public Part P; public int At; public int Len; public float Room = -1; public string A, B, C; }
        private class Group { public QuestDefinition Q; public List<Hit> Hits = new List<Hit>(); public bool Name; }

        private static List<Part> _index;
        private static int _indexVer = -1;
        private static string _text = "", _ran = null;
        private static bool _whole, _ranWhole;
        private static DateTime _typedAt = DateTime.MinValue;
        private static List<Group> _groups = new List<Group>();
        private static int _hitCount;
        private const int MaxHits = 1000;

        private static readonly Regex Prefix = new Regex(@"^(?:I|RK)\|([^|]*)\|(.*)$|^L\|\d+\|[^|]*\|(.*)$|^(?:H\d|P|R|RI|TH|TR)\|(.*)$");
        private static readonly Regex Head = new Regex(@"^H2\|(.*)$");
        private static readonly Regex LinkRx = new Regex(@"«([^»¦]*)(?:¦([^»]*))?»");
        private static readonly Regex WikiLinkRx = new Regex(@"\[\[([^\]|]+)(?:\|([^\]]*))?\]\]");
        private static readonly Regex StampRx = new Regex(@"\{\{\s*[Ss]tamped\s*\|\s*([^}|]+?)\s*\}\}");

        private static string Words(string s) { return (s ?? "").Replace("[REVIEW]", "").Replace('_', ' ').Trim(); }

        /// <summary>The line as the page shows it: links as their text, stamps and NPC lines without their marks.</summary>
        private static string Shown(string s)
        {
            s = StampRx.Replace(s, "$1");
            s = WikiLinkRx.Replace(s, m => m.Groups[2].Success && m.Groups[2].Value.Length > 0 ? m.Groups[2].Value : m.Groups[1].Value);
            s = LinkRx.Replace(s, m => m.Groups[2].Success && m.Groups[2].Value.Length > 0 ? m.Groups[2].Value : m.Groups[1].Value);
            return s.Replace("⟦", "").Replace("⟧", "").Replace("⸨", "").Replace("⸩", "").Replace("**", "").Replace("{OPT}", "Optional:").Replace("{WARN}", "Warning:").Replace("{TIP}", "Tip:").Replace('\t', '|');
        }

        private static void Add(List<Part> l, QuestDefinition q, string field, string raw)
        {
            if (string.IsNullOrEmpty(raw)) return;
            l.Add(new Part { Q = q, Field = field, Raw = raw, Shown = Shown(raw) });
        }

        private static void BuildIndex()
        {
            List<Part> l = new List<Part>();
            foreach (QuestDefinition q in QuestDatabase.Quests)
            {
                Add(l, q, "Name", Words(q.Name));
                Add(l, q, "Start town", q.StartTown);
                Add(l, q, "Quest giver", q.QuestGiver);
                Add(l, q, "Repeat", q.RepeatNote);
                Add(l, q, "Notes", q.Notes);
                Add(l, q, "Wiki link", q.WikiLink);
                Add(l, q, "Timer flag", q.TimerFlag);
                if (q.KtMobs.Count > 0) Add(l, q, "KT mobs", string.Join(", ", q.KtMobs.ToArray()));
                if (q.CollectItems.Count > 0) Add(l, q, "Items", string.Join(", ", q.CollectItems.ConvertAll(x => x.Value > 0 ? x.Key + " x" + x.Value : x.Key).ToArray()));
                if (q.TurnInText.Count > 0) Add(l, q, "Turn-in text", string.Join(" | ", q.TurnInText.ToArray()));
                foreach (string f in q.QbFlags) Add(l, q, "QB flag", f);
                string section = "Walkthrough";
                foreach (string line in (q.Wiki ?? "").Split('\n'))
                {
                    string t = line.Trim();
                    if (t.Length == 0 || t == "TE" || t == "RE") continue;
                    Match h = Head.Match(t);
                    if (h.Success) { section = Shown(h.Groups[1].Value).Trim(); Add(l, q, "Heading", h.Groups[1].Value); continue; }
                    Match m = Prefix.Match(t);
                    string body = !m.Success ? t : m.Groups[1].Success ? m.Groups[1].Value + ": " + m.Groups[2].Value : m.Groups[3].Success ? m.Groups[3].Value : m.Groups[4].Value;
                    Add(l, q, section, body);
                }
            }
            _index = l;
            _indexVer = QuestDatabase.LoadCount;
        }

        private static void Run()
        {
            _ran = _text.Trim(); _ranWhole = _whole;
            _groups = new List<Group>(); _hitCount = 0;
            if (_ran.Length == 0) return;
            if (_index == null || _indexVer != QuestDatabase.LoadCount) BuildIndex();
            Regex rx = new Regex((_whole ? @"(?<![\w])" : "") + Regex.Escape(_ran) + (_whole ? @"(?![\w])" : ""), RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
            Dictionary<QuestDefinition, Group> by = new Dictionary<QuestDefinition, Group>();
            foreach (Part p in _index)
            {
                Match m = rx.Match(p.Shown);
                bool rawOnly = false;
                if (!m.Success) { if (!rx.IsMatch(p.Raw)) continue; rawOnly = true; }   // only in a link's target
                Group g;
                if (!by.TryGetValue(p.Q, out g)) { g = new Group { Q = p.Q }; by[p.Q] = g; _groups.Add(g); }
                if (p.Field == "Name") g.Name = true;
                if (_hitCount >= MaxHits) continue;
                g.Hits.Add(new Hit { P = p, At = rawOnly ? -1 : m.Index, Len = rawOnly ? 0 : m.Length });
                _hitCount++;
            }
            // quests whose name matches first, then the most hits
            _groups.Sort((a, b) => a.Name != b.Name ? (a.Name ? -1 : 1) : a.Hits.Count != b.Hits.Count ? b.Hits.Count - a.Hits.Count : string.Compare(a.Q.Name, b.Q.Name, StringComparison.OrdinalIgnoreCase));
        }

        private static readonly Vec4 FieldCol = new Vec4(0.75f, 0.75f, 0.75f, 1f);
        private static readonly Vec4 HitCol = new Vec4(1f, 0.85f, 0.25f, 1f);
        private static readonly Vec4 QuestCol = new Vec4(0.55f, 0.80f, 1.00f, 1f);

        public static void Draw(float w, float h)
        {
            ImGui.SetNextItemWidth(320);
            bool enter = ImGui.InputText("##qsearch", ref _text, 200, ImGuiInputTextFlags.EnterReturnsTrue);
            if (ImGui.IsItemEdited()) _typedAt = DateTime.Now;
            ImGui.SameLine();
            if (ImGui.Button("Search")) enter = true;
            ImGui.SameLine();
            if (ImGui.Button("Clear")) { _text = ""; enter = true; }
            ImGui.SameLine();
            ImGui.Checkbox("Whole word", ref _whole);
            if (ImGui.IsItemHovered()) Im.SetTooltip("Only match the text as a whole word (\"Ruggan\" won't find \"Ruggans\").");
            // searches as you type (a moment after you stop), on Enter, and again after the quest database reloads
            bool stale = _ran != null && _ran.Length > 0 && _indexVer != QuestDatabase.LoadCount;
            if (enter || stale || _whole != _ranWhole || (_text.Trim() != (_ran ?? "") && _text.Trim().Length >= 3 && (DateTime.Now - _typedAt).TotalMilliseconds > 400))
                Run();

            if (string.IsNullOrEmpty(_ran)) Im.TextDisabled("Searches every part of every quest: name, giver, town, notes, KT mobs, items, QB flags and the whole walkthrough.");
            else Im.TextDisabled(_groups.Count == 0 ? "Nothing found for \"" + _ran + "\"." :
                _hitCount + (_hitCount >= MaxHits ? "+" : "") + " place" + (_hitCount == 1 ? "" : "s") + " in " + _groups.Count + " quest" + (_groups.Count == 1 ? "" : "s") + (_hitCount >= MaxHits ? " (showing the first " + MaxHits + ")" : "") + ".");

            if (ImGui.BeginChild("##qsresults", ImGui.GetContentRegionAvail(), true))
            {
                float right = ImGui.GetContentRegionAvail().X;
                for (int gi = 0; gi < _groups.Count; gi++)
                {
                    Group g = _groups[gi];
                    ImGui.PushID(gi);
                    if (ImGui.SmallButton("Open")) { if (Open != null) Open(g.Q); }
                    if (ImGui.IsItemHovered()) Im.SetTooltip("Show it on the Quest tab");
                    ImGui.SameLine();
                    if (ImGui.SmallButton("Edit")) { if (Edit != null) Edit(g.Q); }
                    if (ImGui.IsItemHovered()) Im.SetTooltip("Open it on the Edit Quest tab");
                    ImGui.SameLine();
                    Im.TextColored(QuestCol, Words(g.Q.Name));
                    ImGui.SameLine();
                    Im.TextDisabled("(" + g.Hits.Count + ")");
                    foreach (Hit hit in g.Hits)
                    {
                        ImGui.SetCursorPosX(ImGui.GetCursorPosX() + 24);
                        Im.TextColored(FieldCol, hit.P.Field + ":");
                        ImGui.SameLine();
                        DrawLine(hit, right - ImGui.GetCursorPosX());
                    }
                    ImGui.Dummy(new Vec2(1, 4));
                    ImGui.PopID();
                }
            }
            ImGui.EndChild();
        }

        /// <summary>One line of a result, cut around the match, with the match highlighted.</summary>
        private static void DrawLine(Hit hit, float room)
        {
            if (Math.Abs(hit.Room - room) > 1f) Lay(hit, room);   // cut once per width, not every frame
            if (hit.At < 0) { Im.Text(hit.A); ImGui.SameLine(); Im.TextDisabled("(in a link)"); return; }
            if (hit.A.Length > 0) { Im.Text(hit.A); ImGui.SameLine(0, 0); }
            Im.TextColored(HitCol, hit.B);
            if (hit.C.Length > 0) { ImGui.SameLine(0, 0); Im.Text(hit.C); }
        }

        private static void Lay(Hit hit, float room)
        {
            hit.Room = room;
            string s = hit.P.Shown;
            if (hit.At < 0) { hit.A = Cut(s, room - 80); return; }
            string before = s.Substring(0, hit.At), match = s.Substring(hit.At, hit.Len), after = s.Substring(hit.At + hit.Len);
            float mw = Im.Size(match).X, left = (room - mw) * 0.35f;
            if (Im.Size(before).X > left)
            {
                while (before.Length > 0 && Im.Size("..." + before).X > left) before = before.Substring(Math.Min(before.Length, 4));
                before = "..." + before;
            }
            hit.A = before; hit.B = match;
            hit.C = Cut(after, room - Im.Size(before).X - mw);
        }

        private static string Cut(string s, float room)
        {
            if (Im.Size(s).X <= room) return s;
            int n = s.Length;
            while (n > 0 && Im.Size(s.Substring(0, n) + "...").X > room) n = Math.Max(0, n - Math.Max(1, n / 10));
            return s.Substring(0, n) + "...";
        }
    }
}
