using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using ImGuiNET;
using Vec2 = System.Numerics.Vector2;
using Vec4 = System.Numerics.Vector4;

namespace MelksQuestTracker
{
    /// <summary>
    /// Areas of the window the plugin draws itself (a "MelksQB.Custom" control in mainView.xml, by its name).
    /// </summary>
    internal static class CustomDraw
    {
        public static readonly Dictionary<string, Action<float, float>> Areas = new Dictionary<string, Action<float, float>>();

        /// <summary>Windows of their own (the map, the walkthrough editor), drawn every frame the main window is.</summary>
        public static void Overlays()
        {
            try { MapView.Draw(); } catch (Exception ex) { Util.LogError(ex); }
        }

        public static void Draw(string name, float w, float h)
        {
            Action<float, float> a;
            if (name == null || !Areas.TryGetValue(name, out a)) return;
            IntPtr win = Im.Window();
            try { a(w, h); }
            catch (Exception ex) { Im.BackTo(win); Util.LogError(ex); }
        }
    }

    /// <summary>
    /// Draws a quest's walkthrough (QuestDatabase.xml &lt;Wiki&gt;, made from the wiki page) the way the wiki shows it.
    ///
    /// One line per item:
    ///   I|label|value          a row of the info box (Level, Type, Starts With ...)
    ///   H2|text  H3|  H4|      headings
    ///   P|text                 a paragraph
    ///   L|depth|marker|text    a list item ("1." / "•"), depth 1 = top level
    ///   TH|a\tb  TR|a\tb  TE   a table: header row, rows, end
    ///   R|title  RK|label|value  RI|text  RE     a rewards box
    /// Lines without a prefix are paragraphs; "* x" / "# x" are list items (so it can be written like the wiki).
    /// In the text: «target¦text» or «text» or [[target|text]] = a link, ⟦Flag⟧ or {{stamped|Flag}} = a QB stamp,
    /// **bold**, ⸨text⸩ = NPC tell / emote, {OPT} {WARN} {TIP}.
    /// </summary>
    internal static class WikiView
    {
        // wiki colours
        public static readonly Vec4 LinkCol = new Vec4(0.42f, 0.62f, 1.00f, 1f);
        public static readonly Vec4 QuestLinkCol = new Vec4(0.55f, 0.80f, 1.00f, 1f);   // a quest in the tracker (click opens it here)
        public static readonly Vec4 PageLinkCol = new Vec4(0.80f, 0.66f, 1.00f, 1f);    // any other wiki page (right-click opens it in the browser)
        public static readonly Vec4 StampCol = new Vec4(0.20f, 0.85f, 1.00f, 1f);
        public static readonly Vec4 StampDone = new Vec4(0.35f, 0.95f, 0.35f, 1f);
        public static readonly Vec4 StampPart = new Vec4(1.00f, 0.80f, 0.25f, 1f);
        public static readonly Vec4 TellCol = new Vec4(1.00f, 0.95f, 0.45f, 1f);
        public static readonly Vec4 OptCol = new Vec4(0.30f, 0.80f, 0.30f, 1f);
        public static readonly Vec4 WarnCol = new Vec4(1.00f, 0.35f, 0.30f, 1f);
        public static readonly Vec4 HeadCol = new Vec4(0.95f, 0.88f, 0.70f, 1f);
        public static readonly Vec4 BoldCol = new Vec4(1f, 1f, 1f, 1f);
        public static readonly Vec4 LabelCol = new Vec4(0.75f, 0.75f, 0.75f, 1f);
        public static readonly Vec4 BoxHead = new Vec4(0.55f, 0.36f, 0.14f, 1f);

        /// <summary>A link was clicked: the quest it names (null = not a quest).</summary>
        public static Func<string, QuestDefinition> QuestFor;
        public static Action<QuestDefinition> OpenQuest;

        private class Seg { public string Text; public int Kind; public string Target; }   // 0 text 1 bold 2 link 3 stamp 4 tell 5 opt 6 warn 7 tip 8 coords

        public static readonly Vec4 CoordCol = new Vec4(0.45f, 0.95f, 0.45f, 1f);
        // 32.7N, 45.5E / 0.3N 92.2E / 24.0S 57.9W (what the game turns into a link in chat)
        private static readonly Regex CoordRx = new Regex(@"\b\d{1,3}(?:\.\d+)?\s*[NSns]\s*[,/-]?\s*\d{1,3}(?:\.\d+)?\s*[EWew]\b");

        /// <summary>Travels to the coordinates (as clicking them in chat does).</summary>
        public static void PointArrow(string coords)
        {
            string c = Regex.Replace(coords ?? "", @"\s+", " ").Trim();
            c = Regex.Replace(c, @"\s*[/-]\s*", ", ");   // "21.7S - 47.7E" -> "21.7S, 47.7E"
            Travel.Travel.Go(c, 0);   // MelksQB's own travel (a route or just the arrow, per the Config tab)
        }

        /// <summary>Opens a web address in the browser: the shell's own way (the game's client and Decal), else xdg-open
        /// (Linux, ACGodot - .NET there won't open an address without asking the shell to). Null when it worked, else why not.</summary>
        public static string OpenUrl(string url)
        {
            try { System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(url) { UseShellExecute = true }); return null; }
            catch (Exception ex)
            {
                try { System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("xdg-open", "\"" + url + "\"") { UseShellExecute = false }); return null; }
                catch { return ex.Message; }
            }
        }

        /// <summary>Opens a wiki page in the web browser (off the game thread - it can take a moment).</summary>
        public static void OpenPage(string target)
        {
            string url = "https://www.leaftidewiki.com/" + Uri.EscapeDataString((target ?? "").Trim().Replace(' ', '_')).Replace("%27", "'").Replace("%28", "(").Replace("%29", ")").Replace("%3A", ":");
            System.Threading.ThreadPool.QueueUserWorkItem(_ =>
            {
                string err = OpenUrl(url);
                if (err != null) Util.WriteToChat("Couldn't open " + url + " (" + err + ")");
            });
        }

        private static readonly Regex WikiLinkRx = new Regex(@"\[\[([^\]|]+)(?:\|([^\]]*))?\]\]");
        private static readonly Regex StampRx = new Regex(@"\{\{\s*[Ss]tamped\s*\|\s*([^}|]+?)\s*\}\}");
        private static readonly Regex TellRx = new Regex(@"\{\{\s*[Tt]ell\s*\|([^}]*)\}\}");

        public static string Normalize(string s)
        {
            if (string.IsNullOrEmpty(s) || (s.IndexOf("[[", StringComparison.Ordinal) < 0 && s.IndexOf("{{", StringComparison.Ordinal) < 0)) return s ?? "";
            s = StampRx.Replace(s, m => "⟦" + m.Groups[1].Value + "⟧");
            s = TellRx.Replace(s, m => "⸨" + m.Groups[1].Value + "⸩");
            s = WikiLinkRx.Replace(s, m => "«" + m.Groups[1].Value + (m.Groups[2].Success ? "¦" + m.Groups[2].Value : "") + "»");
            return s.Replace("{{Optional}}", "{OPT}").Replace("{{optional}}", "{OPT}");
        }

        private static readonly Dictionary<string, List<Seg>> _segCache = new Dictionary<string, List<Seg>>();

        public static string Straight(string s)
        {
            if (string.IsNullOrEmpty(s)) return s;
            return s.Replace('\u2019', '\'').Replace('\u2018', '\'').Replace('\u201C', '"').Replace('\u201D', '"').Replace('\u2013', '-').Replace('\u2014', '-');
        }

        private static List<Seg> Parse(string s)
        {
            List<Seg> l;
            if (_segCache.TryGetValue(s, out l)) return l;
            l = new List<Seg>();
            string t = Normalize(s);
            int i = 0; bool bold = false;
            System.Text.StringBuilder cur = new System.Text.StringBuilder();
            Action flush = () =>
            {
                if (cur.Length == 0) return;
                string txt = cur.ToString(); cur.Length = 0;
                int at = 0;
                foreach (Match m in CoordRx.Matches(txt))
                {
                    if (m.Index > at) l.Add(new Seg { Text = txt.Substring(at, m.Index - at), Kind = bold ? 1 : 0 });
                    l.Add(new Seg { Text = m.Value, Kind = 8 });
                    at = m.Index + m.Length;
                }
                if (at < txt.Length) l.Add(new Seg { Text = txt.Substring(at), Kind = bold ? 1 : 0 });
            };
            while (i < t.Length)
            {
                char c = t[i];
                if (c == '«')
                {
                    int e = t.IndexOf('»', i + 1);
                    if (e > i)
                    {
                        flush();
                        string inner = t.Substring(i + 1, e - i - 1);
                        int sep = inner.IndexOf('¦');
                        string target = sep >= 0 ? inner.Substring(0, sep) : inner, text = sep >= 0 ? inner.Substring(sep + 1) : inner;
                        if (text.Length == 0) text = target;
                        // coordinates inside a link's text ("40.5N, 78.2W - Tumerok Camp"): the coordinates point GoArrow,
                        // the rest stays the link
                        int at2 = 0;
                        foreach (Match cm in CoordRx.Matches(text))
                        {
                            if (cm.Index > at2) l.Add(new Seg { Text = text.Substring(at2, cm.Index - at2), Kind = 2, Target = target });
                            l.Add(new Seg { Text = cm.Value, Kind = 8 });
                            at2 = cm.Index + cm.Length;
                        }
                        if (at2 < text.Length) l.Add(new Seg { Text = text.Substring(at2), Kind = 2, Target = target });
                        i = e + 1; continue;
                    }
                }
                else if (c == '⟦' || c == '⸨')
                {
                    char end = c == '⟦' ? '⟧' : '⸩';
                    int e = t.IndexOf(end, i + 1);
                    if (e > i) { flush(); l.Add(new Seg { Text = t.Substring(i + 1, e - i - 1), Kind = c == '⟦' ? 3 : 4 }); i = e + 1; continue; }
                }
                else if (c == '*' && i + 1 < t.Length && t[i + 1] == '*') { flush(); bold = !bold; i += 2; continue; }
                else if (c == '{')
                {
                    int k = string.CompareOrdinal(t, i, "{OPT}", 0, 5) == 0 ? 5 : string.CompareOrdinal(t, i, "{WARN}", 0, 6) == 0 ? 6 : string.CompareOrdinal(t, i, "{TIP}", 0, 5) == 0 ? 7 : 0;
                    if (k != 0)
                    {
                        flush();
                        l.Add(new Seg { Text = k == 5 ? "Optional:" : k == 6 ? "Warning:" : "Tip:", Kind = k });
                        i += k == 6 ? 6 : 5; continue;
                    }
                }
                cur.Append(c); i++;
            }
            flush();
            if (_segCache.Count > 4000) _segCache.Clear();
            // the game font has no curly quotes (they show as "?"): straight ones on screen, links keep their wiki target
            foreach (Seg sg in l) if (sg.Text != null) sg.Text = Straight(sg.Text);
            _segCache[s] = l;
            return l;
        }

        /// <summary>Wrapped rich text starting at x0 (window-relative), up to the right edge of the current region.</summary>
        public static void Rich(string s, float x0, Vec4 baseCol)
        {
            List<Seg> segs = Parse(s ?? "");
            float right = ImGui.GetCursorPosX() + ImGui.GetContentRegionAvail().X;
            if (x0 > ImGui.GetCursorPosX()) ImGui.SetCursorPosX(x0);
            else x0 = ImGui.GetCursorPosX();
            float x = x0;
            bool first = true;
            float space = Im.Size(" ").X;
            for (int si = 0; si < segs.Count; si++)
            {
                Seg g = segs[si];
                if (g.Kind == 3) { Stamp(g.Text, ref x, x0, right, ref first); continue; }
                Vec4 col = g.Kind == 1 ? BoldCol : g.Kind == 2 ? LinkCol : g.Kind == 4 ? TellCol : g.Kind == 5 ? OptCol : g.Kind == 8 ? CoordCol : g.Kind >= 6 ? WarnCol : baseCol;
                QuestDefinition lq = g.Kind == 2 && QuestFor != null ? QuestFor(g.Target) : null;
                if (lq != null) col = QuestLinkCol;
                else if (g.Kind == 2 && !g.Target.StartsWith("map:", StringComparison.OrdinalIgnoreCase)) col = PageLinkCol;
                string[] words = g.Text.Split(' ');
                for (int wi = 0; wi < words.Length; wi++)
                {
                    string w = words[wi];
                    bool trailingSpace = wi < words.Length - 1;
                    if (w.Length == 0) { if (!first) x += space; continue; }
                    float ww = Im.Size(w).X;
                    if (!first && x + ww > right && x > x0) { x = x0; first = true; }
                    if (first) { ImGui.SetCursorPosX(x); }
                    else { ImGui.SameLine(0, 0); ImGui.SetCursorPosX(x); }
                    Im.TextColored(col, w);
                    if ((g.Kind == 2 || g.Kind == 8) && ImGui.IsItemHovered())
                    {
                        Vec2 mn = ImGui.GetItemRectMin(), mx = ImGui.GetItemRectMax();
                        ImGui.GetWindowDrawList().AddLine(new Vec2(mn.X, mx.Y), mx, ImGui.GetColorU32(col));
                        bool map = g.Kind == 2 && g.Target.StartsWith("map:", StringComparison.OrdinalIgnoreCase);
                        Im.SetTooltip(g.Kind == 8 ? "Go to " + g.Text : lq != null ? "Click: open " + Words(lq.Name) + " here\nRight-click: its wiki page" : map ? "Show the map " + g.Target.Substring(4) : "Click: copy \"" + g.Text.Trim() + "\"\nRight-click: open " + g.Target + " on the wiki");
                        if (ImGui.IsMouseClicked(ImGuiMouseButton.Left))
                        {
                            if (g.Kind == 8) PointArrow(g.Text);
                            else if (lq != null && OpenQuest != null) { QuestDefinition q2 = lq; OpenQuest(q2); }
                            else if (map) MapView.Show(g.Target.Substring(4));
                            else if (g.Kind == 2) { Util.PendingClipboard = g.Text.Trim(); Util.WriteToChat("Copied: " + g.Text.Trim()); }
                        }
                        else if (ImGui.IsMouseClicked(ImGuiMouseButton.Right) && g.Kind == 2 && !map) OpenPage(g.Target);
                    }
                    first = false;
                    x += ww + (trailingSpace ? space : 0);
                }
            }
            if (first) ImGui.NewLine();
        }

        private static void Stamp(string flag, ref float x, float x0, float right, ref bool first)
        {
            // (pages copied from the game's text have the "!" of "You've stamped X!" on the flag: "MaggotInfestedSkull!")
            flag = (flag ?? "").Trim().TrimEnd('!', '.', ' ');
            FlagState st;
            bool known = ProgressStore.Flags.TryGetValue(flag ?? "", out st);
            Vec4 col = !known ? StampCol : st == FlagState.Completed ? StampDone : StampPart;
            string text = "You've stamped " + flag + "!";
            Vec2 sz = Im.Size(text);
            float bw = sz.X + 10;
            if (!first && x + bw > right && x > x0) { x = x0; first = true; }
            if (first) ImGui.SetCursorPosX(x);
            else { ImGui.SameLine(0, 0); ImGui.SetCursorPosX(x); }
            Vec2 p = ImGui.GetCursorScreenPos();
            ImDrawListPtr dl = ImGui.GetWindowDrawList();
            dl.AddRectFilled(new Vec2(p.X, p.Y - 1), new Vec2(p.X + bw, p.Y + sz.Y + 1), ImGui.GetColorU32(new Vec4(0, 0, 0, 0.55f)), 2f);
            dl.AddRect(new Vec2(p.X, p.Y - 1), new Vec2(p.X + bw, p.Y + sz.Y + 1), ImGui.GetColorU32(new Vec4(0.35f, 0.35f, 0.35f, 1f)), 2f);
            ImGui.SetCursorPosX(x + 5);
            Im.TextColored(col, text);
            if (ImGui.IsItemHovered())
                Im.SetTooltip(flag + (!known ? "\nNot in your last /qb list" : st == FlagState.Completed ? "\nDone" : "\nStarted (in progress)") + "\nClick to copy the flag name");
            if (ImGui.IsItemClicked()) Util.SetClipboardText(flag);
            first = false;
            x += bw + 4;
        }

        private static string Words(string s) { return (s ?? "").Replace("[REVIEW]", "").Replace('_', ' ').Trim(); }

        // ── a whole page ─────────────────────────────────────────────

        private static readonly Dictionary<string, List<string[]>> _pages = new Dictionary<string, List<string[]>>();

        public static List<string[]> Lines(string wiki)
        {
            wiki = wiki ?? "";
            List<string[]> l;
            if (_pages.TryGetValue(wiki, out l)) return l;
            l = new List<string[]>();
            foreach (string raw in wiki.Replace("\r", "").Split('\n'))
            {
                string[] sl = SplitLine(raw);
                // a wiki box of stamp lists squashed into one header line ("Battered Weapon * ⟦a⟧ ⟦b⟧ * ⟦c⟧ ⟦d⟧ ..."):
                // a table again - the title, then a row per list item with each stamp in its own cell
                if (sl[0] == "TH" && sl.Length > 1 && sl[1].IndexOf('⟦') >= 0 && sl[1].IndexOf('*') >= 0)
                {
                    string[] parts = sl[1].Split('*');
                    List<List<string>> rows = new List<List<string>>();
                    int cols = 1;
                    for (int k = 1; k < parts.Length; k++)
                    {
                        List<string> cells = new List<string>();
                        foreach (Match sm in Regex.Matches(parts[k], "⟦[^⟧]*⟧")) cells.Add(sm.Value);
                        if (cells.Count == 0 && parts[k].Trim().Length > 0) cells.Add(parts[k].Trim());
                        if (cells.Count == 0) continue;
                        rows.Add(cells); cols = Math.Max(cols, cells.Count);
                    }
                    if (rows.Count > 0)
                    {
                        string head = parts[0].Trim();
                        for (int c = 1; c < cols; c++) head += "\t";
                        l.Add(new[] { "TH", head });
                        foreach (List<string> r in rows) l.Add(new[] { "TR", string.Join("\t", r.ToArray()) });
                        continue;
                    }
                }
                l.Add(sl);
            }
            if (_pages.Count > 12) _pages.Clear();
            _pages[wiki] = l;
            return l;
        }

        private static readonly Regex ListRx = new Regex(@"^([*#:;]+)\s*(.*)$");
        private static readonly Regex HeadRx = new Regex(@"^(={2,5})\s*(.*?)\s*=+\s*$");

        private static string[] SplitLine(string l)
        {
            if (l.Length == 0) return new[] { "" };
            int bar = l.IndexOf('|');
            string k = bar > 0 ? l.Substring(0, bar) : l;
            switch (k)
            {
                case "I": case "RK": { string[] p = l.Split(new[] { '|' }, 3); return p.Length == 3 ? p : new[] { k, p.Length > 1 ? p[1] : "", "" }; }
                case "L": { string[] p = l.Split(new[] { '|' }, 4); return p.Length == 4 ? p : new[] { "P", l }; }
                case "H2": case "H3": case "H4": case "H5": case "P": case "TH": case "TR": case "R": case "RI": return new[] { k, l.Substring(bar + 1) };
            }
            if (l == "TE" || l == "RE") return new[] { l };
            Match h = HeadRx.Match(l);
            if (h.Success) return new[] { "H" + h.Groups[1].Value.Length, h.Groups[2].Value };
            Match m = ListRx.Match(l);
            if (m.Success) return new[] { "L", m.Groups[1].Value.Length.ToString(), m.Groups[1].Value.EndsWith("#") ? "#" : m.Groups[1].Value.EndsWith("*") ? "•" : "", m.Groups[2].Value };
            return new[] { "P", l };
        }

        /// <summary>Info box rows (I|) of a page.</summary>
        public static List<KeyValuePair<string, string>> Info(string wiki)
        {
            List<KeyValuePair<string, string>> r = new List<KeyValuePair<string, string>>();
            foreach (string[] l in Lines(wiki)) if (l[0] == "I") r.Add(new KeyValuePair<string, string>(l[1], l[2]));
            return r;
        }

        /// <summary>Draws everything but the info box.</summary>
        public static void Body(string wiki)
        {
            List<string[]> lines = Lines(wiki);
            Vec4 text = ImGui.GetStyle().Colors[(int)ImGuiCol.Text];
            Dictionary<int, int> num = new Dictionary<int, int>();
            for (int i = 0; i < lines.Count; i++)
            {
                string[] l = lines[i];
                switch (l[0])
                {
                    case "I": break;
                    case "": ImGui.Dummy(new Vec2(1, 4)); num.Clear(); break;
                    case "H2": case "H3": case "H4": case "H5":
                        {
                            num.Clear();
                            ImGui.Dummy(new Vec2(1, l[0] == "H2" ? 8 : 4));
                            Vec4 hc = l[0] == "H2" ? HeadCol : new Vec4(0.90f, 0.82f, 0.62f, 1f);
                            // a heading with a link in it ("«Alnale Urzin»", "«Burnan al-Tasha» Turn Ins") stays clickable
                            bool hasLink = false;
                            foreach (Seg g in Parse(l[1])) if (g.Kind == 2 || g.Kind == 8) { hasLink = true; break; }
                            if (hasLink) Rich(l[1], ImGui.GetCursorPosX(), hc);
                            else Im.TextColored(hc, Parse(l[1]).Count == 1 ? Parse(l[1])[0].Text : Plain(l[1]));
                            if (l[0] == "H2") ImGui.Separator();
                            break;
                        }
                    case "P": num.Clear(); Rich(l[1], ImGui.GetCursorPosX(), text); break;
                    case "L":
                        {
                            int d; int.TryParse(l[1], out d); if (d < 1) d = 1;
                            string mk = l[2];
                            List<int> drop = new List<int>(); foreach (int k in num.Keys) if (k > d) drop.Add(k); foreach (int k in drop) num.Remove(k);
                            if (mk == "#" || (mk.Length > 0 && char.IsDigit(mk[0]))) { int n; num.TryGetValue(d, out n); n++; num[d] = n; mk = n + "."; }
                            if (mk == "*") mk = "•";
                            float baseX = ImGui.GetCursorPosX() + 6 + (d - 1) * 20f;
                            if (mk == "•") { ImGui.SetCursorPosX(baseX); Bullet(); ImGui.SameLine(0, 0); }
                            else if (mk.Length > 0) { ImGui.SetCursorPosX(baseX); Im.TextColored(LabelCol, mk); ImGui.SameLine(0, 0); }
                            Rich(l[3], baseX + 18, text);
                            break;
                        }
                    case "TH": case "TR":
                        {
                            int j = i; List<string[]> rows = new List<string[]>(); bool head = l[0] == "TH";
                            while (j < lines.Count && (lines[j][0] == "TH" || lines[j][0] == "TR" || lines[j][0] == "")) { if (lines[j][0] != "") rows.Add(lines[j]); j++; }
                            if (j < lines.Count && lines[j][0] == "TE") j++;
                            Table(rows, i);
                            i = j - 1;
                            break;
                        }
                    case "R":
                        {
                            int j = i + 1; List<string[]> rows = new List<string[]>();
                            while (j < lines.Count && (lines[j][0] == "RK" || lines[j][0] == "RI")) { rows.Add(lines[j]); j++; }
                            if (j < lines.Count && lines[j][0] == "RE") j++;
                            Reward(l[1], rows, i);
                            i = j - 1;
                            break;
                        }
                    case "TE": case "RE": break;
                    default: Rich(l.Length > 1 ? l[1] : l[0], ImGui.GetCursorPosX(), text); break;
                }
            }
        }

        /// <summary>A small round bullet (the game font has no • character).</summary>
        private static void Bullet()
        {
            Vec2 p = ImGui.GetCursorScreenPos();
            float h = ImGui.GetTextLineHeight();
            ImGui.GetWindowDrawList().AddCircleFilled(new Vec2(p.X + 4, p.Y + h / 2), 2.2f, ImGui.GetColorU32(LabelCol));
            ImGui.Dummy(new Vec2(10, h));
        }

        public static string Plain(string s)
        {
            System.Text.StringBuilder b = new System.Text.StringBuilder();
            foreach (Seg g in Parse(s)) b.Append(g.Kind == 3 ? "You've stamped " + (g.Text ?? "").Trim().TrimEnd('!', '.', ' ') + "!" : g.Text);
            return b.ToString();
        }

        private static void Table(List<string[]> rows, int id)
        {
            int cols = 1;
            foreach (string[] r in rows) cols = Math.Max(cols, r[1].Split('\t').Length);
            Vec4 text = ImGui.GetStyle().Colors[(int)ImGuiCol.Text];
            if (!ImGui.BeginTable("##t" + id, cols, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingStretchProp)) return;
            foreach (string[] r in rows)
            {
                ImGui.TableNextRow();
                string[] cells = r[1].Split('\t');
                if (r[0] == "TH") ImGui.TableSetBgColor(ImGuiTableBgTarget.RowBg0, ImGui.GetColorU32(new Vec4(0.25f, 0.25f, 0.30f, 1f)));
                for (int c = 0; c < cols; c++)
                {
                    ImGui.TableSetColumnIndex(c);
                    string v = c < cells.Length ? cells[c] : "";
                    if (r[0] == "TH") Im.TextColored(HeadCol, Plain(v)); else Rich(v, ImGui.GetCursorPosX(), text);
                }
            }
            ImGui.EndTable();
        }

        private static void Reward(string title, List<string[]> rows, int id)
        {
            Vec4 text = ImGui.GetStyle().Colors[(int)ImGuiCol.Text];
            float w = Math.Min(420f, ImGui.GetContentRegionAvail().X);
            ImGui.Dummy(new Vec2(1, 3));
            // the title bar (brown, like the wiki), then the rows
            string t = Plain(title) ?? "";   // (an empty title: ImGui's AddText throws on an empty string - every frame, and the tabs after the Quest tab went)
            float th = ImGui.GetTextLineHeight() + 6;
            Vec2 p = ImGui.GetCursorScreenPos();
            ImDrawListPtr dl = ImGui.GetWindowDrawList();
            dl.AddRectFilled(p, new Vec2(p.X + w, p.Y + th), ImGui.GetColorU32(BoxHead));
            float tw = Im.Size(t).X;
            if (t.Length > 0) dl.AddText(new Vec2(p.X + Math.Max(4, (w - tw) / 2), p.Y + 3), ImGui.GetColorU32(new Vec4(1f, 0.93f, 0.80f, 1f)), t);
            ImGui.Dummy(new Vec2(w, th));
            if (rows.Count == 0) return;
            if (!ImGui.BeginTable("##r" + id, 2, ImGuiTableFlags.BordersOuter | ImGuiTableFlags.SizingFixedFit, new Vec2(w, 0))) return;
            ImGui.TableSetupColumn("a", ImGuiTableColumnFlags.WidthFixed, 80);
            ImGui.TableSetupColumn("b", ImGuiTableColumnFlags.WidthStretch);
            foreach (string[] r in rows)
            {
                ImGui.TableNextRow();
                if (r[0] == "RK")
                {
                    ImGui.TableSetColumnIndex(0); Im.TextColored(LabelCol, r[1] + ":");
                    ImGui.TableSetColumnIndex(1); if (r[2].Length > 0) Rich(r[2], ImGui.GetCursorPosX(), text); else ImGui.Dummy(new Vec2(1, 1));
                }
                else
                {
                    ImGui.TableSetColumnIndex(1);
                    float bx = ImGui.GetCursorPosX();
                    Bullet(); ImGui.SameLine(0, 0);
                    Rich(r[1], bx + 14, text);
                }
            }
            ImGui.EndTable();
        }
    }
}
