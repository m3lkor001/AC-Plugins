// Recovered from MelksQB.dll: the source file kept on the PC was older than the DLL, so this one has no comments.
using System.IO;
using ACGodot.DecalShim;
using ACGodot.Map;
using ACGodot.Plugins;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using MelksQuestTracker.Travel;

namespace MelksQuestTracker;

public sealed class AcgPlugin : IPlugin, IReloadable, IDebugSwitches
{
	/// <summary>MelksQB's debug log (MQT_Debug.txt), for ACGodot's Options > Plugins > Debug.</summary>
	public System.Collections.Generic.IEnumerable<DebugSwitch> DebugSwitches()
	{
		if (PluginCore.Instance == null) yield break;
		yield return new DebugSwitch("Debug log", "MQT_Debug.txt: quest lines read, myquests asks", () => PluginCore.Instance?.DebugOn == true,
			v => { if (PluginCore.Instance != null) PluginCore.Instance.DebugOn = v; });
	}

	public string Name => "MelksQB";

	public void Start(ACGodot.Plugins.PluginHost host)
	{
		Bridge.Start(host);
		string text = Path.GetDirectoryName(typeof(AcgPlugin).Assembly.Location) ?? ".";
		Directory.CreateDirectory(text);
		PluginCore.HotStart(new Decal.Adapter.Wrappers.PluginHost(), CoreManager.Current, text);
		host.AddMapMenuItem("ACMaps picture of this dungeon (MelksQB)", (MapSpot s) =>
		{
			string text2 = DungeonView.MapIdFor(s.Dungeon, "");
			if (text2 != null)
			{
				MapView.Show(text2);
			}
		}, (MapSpot s) => s.Dungeon >= 0 && DungeonView.MapIdFor(s.Dungeon, "") != null);
	}

	/// <summary>A new copy of the DLL is taking over (ACGodot reloads it in place): stopped as for a hot reload - the session
	/// carried over, the other plugins not told the character logged off.</summary>
	public void StopForReload() => PluginCore.HotStop(reload: true);

	public void Stop()
	{
		try
		{
			CoreManager.Current.CharacterFilter.RaiseLogoff();
		}
		catch
		{
		}
		PluginCore.HotStop(reload: false);
	}
}
