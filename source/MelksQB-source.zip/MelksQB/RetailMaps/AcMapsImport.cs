// Retail (Decal) only - MelksQB's own map windows as the retail build had them (recovered from its last build, 14 Nov 2026).
// ACGodot leaves this folder out: its map is ACGodot's built-in one (Travel/MapBridge.cs).
using System;
using System.Collections.Generic;
using System.Numerics;
using System.Threading;
using ImGuiNET;

namespace MelksQuestTracker.Travel;

internal static class AcMapsImport
{
	public static readonly string[] Kinds = new string[8] { "Doors", "Metal gates", "Levers", "Chests", "Locks (lockpick)", "Exit portals", "Start (D)", "Monster spawns" };

	private static readonly string[] PType = new string[8] { "Door", "Door", "Lever / switch", "Chest", "Door", "Portal", "Custom", "Hunting spot" };

	private static readonly string[] PName = new string[8] { "Door", "Metal gate", "Lever", "Chest", "Locked", "Exit portal", "Start (ACMaps D)", "Monster spawn" };

	private static readonly bool[] Want = new bool[8] { true, true, true, true, true, true, false, false };

	public const string Tag = "from ACMaps";

	private static volatile bool _busy;

	private static volatile string _status = "";

	private static volatile List<AcMapsCore.Found> _found;

	private static int _lb = -1;

	private static string _din = "";

	private static string _title = "";

	private static bool _open;

	private static bool _preview = true;

	private static string _acId;

	private static int LevelOf(double z)
	{
		return (int)Math.Round(z / 6.0);
	}

	public static void Toggle(int lb, string inst, string acId, Dictionary<uint, DCell> d)
	{
		string text = Travel.DungeonIn(lb, inst);
		if (_open && _din == text)
		{
			_open = false;
			return;
		}
		_open = true;
		_title = TravelData.AreaName(lb, inst) + "  (" + TravelData.LbLabel(lb, inst) + ")";
		if (_din != text || (_found == null && !_busy))
		{
			_din = text;
			_acId = acId;
			Start(lb, d);
		}
	}

	private static void Start(int lb, Dictionary<uint, DCell> d)
	{
		if (_busy)
		{
			return;
		}
		_lb = lb;
		_found = null;
		string file = ((_acId != null) ? MapView.PathOf(_acId) : null);
		if (file == null)
		{
			_status = "No ACMaps picture for this dungeon.";
			_found = new List<AcMapsCore.Found>();
			return;
		}
		List<AcMapsCore.CellD> cells = new List<AcMapsCore.CellD>();
		foreach (DCell value in d.Values)
		{
			cells.Add(new AcMapsCore.CellD
			{
				X = value.X,
				Y = value.Y,
				Z = value.Z,
				Lv = LevelOf(value.Z),
				F = CellShapes.Floor(value)
			});
		}
		_busy = true;
		_status = "Lining the ACMaps picture up with the map...";
		Thread thread = new Thread(() =>
		{
			try
			{
				List<AcMapsCore.Found> found = AcMapsCore.Run(file, cells, out var status);
				_status = status;
				_found = found;
			}
			catch (Exception ex)
			{
				_status = "Couldn't read the picture: " + ex.Message;
				_found = new List<AcMapsCore.Found>();
			}
			finally
			{
				_busy = false;
			}
		});
		thread.IsBackground = true;
		thread.Priority = ThreadPriority.BelowNormal;
		thread.Start();
	}

	private static Coords At(int lb, double x, double y)
	{
		return new Coords(((double)(lb & 0xFF) * 192.0 + y) / 240.0 - 101.95, ((double)(lb >> 8) * 192.0 + x) / 240.0 - 101.95);
	}

	private static int Mine(string din)
	{
		int num = 0;
		foreach (TravelData.Point value in TravelData.Points.Values)
		{
			if (value.In == din && value.Notes == "from ACMaps")
			{
				num++;
			}
		}
		return num;
	}

	public static void Window(string din, Dictionary<uint, DCell> d)
	{
		if (!_open)
		{
			return;
		}
		if (din != _din)
		{
			_open = false;
			return;
		}
		int lb = _lb;
		ImGui.SetNextWindowSize(new Vector2(360f, 0f), (ImGuiCond)8);
		if (!ImGui.Begin("Copy from ACMaps##acmi", ref _open, (ImGuiWindowFlags)64))
		{
			ImGui.End();
			return;
		}
		try
		{
			Im.TextColored(TravelHud.Cyan, _title);
			ImGui.PushTextWrapPos(340f);
			Im.TextDisabled(_status);
			ImGui.PopTextWrapPos();
			List<AcMapsCore.Found> found = _found;
			if (_busy || found == null)
			{
				ImGui.End();
				return;
			}
			int[] array = new int[Kinds.Length];
			foreach (AcMapsCore.Found item in found)
			{
				array[item.Kind]++;
			}
			ImGui.Separator();
			Im.TextDisabled("Bring over:");
			for (int i = 0; i < Kinds.Length; i++)
			{
				if (array[i] != 0)
				{
					bool flag = Want[i];
					if (ImGui.Checkbox(Kinds[i] + " (" + array[i] + ")##acmk" + i, ref flag))
					{
						Want[i] = flag;
					}
				}
			}
			ImGui.Checkbox("Show them on the map first##acmpv", ref _preview);
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Hollow rings on the dungeon map where each ticked one would go.");
			}
			int num = 0;
			foreach (AcMapsCore.Found item2 in found)
			{
				if (Want[item2.Kind] && !Have(lb, item2))
				{
					num++;
				}
			}
			if (num > 0 && ImGui.Button("Add " + num + " point" + ((num != 1) ? "s" : "") + "##acmadd"))
			{
				AddAll(lb, found);
			}
			int num2 = Mine(din);
			if (num2 > 0)
			{
				if (num > 0)
				{
					ImGui.SameLine();
				}
				if (ImGui.Button("Remove all ACMaps points (" + num2 + ")##acmrm"))
				{
					RemoveAll(lb);
				}
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip("Takes off every point brought over from ACMaps in this dungeon.\nOne at a time: right-click it on the map, Delete.");
				}
			}
			ImGui.SameLine();
			if (ImGui.Button("Read again##acmre"))
			{
				Start(lb, d);
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		ImGui.End();
	}

	private static bool Have(int lb, AcMapsCore.Found x)
	{
		string din = _din;
		Coords o = At(lb, x.X, x.Y);
		foreach (TravelData.Point value in TravelData.Points.Values)
		{
			if (value.In == din && value.Type == PType[x.Kind] && value.Name == PName[x.Kind] && value.At.DistanceTo(o) * 240.0 < 2.5 && (double.IsNaN(value.Z) || Math.Abs(value.Z - x.Z) < 3.0))
			{
				return true;
			}
		}
		return false;
	}

	private static void AddAll(int lb, List<AcMapsCore.Found> f)
	{
		foreach (AcMapsCore.Found item in f)
		{
			if (Want[item.Kind] && !Have(lb, item))
			{
				TravelData.Point point = new TravelData.Point();
				point.Name = PName[item.Kind];
				point.Type = PType[item.Kind];
				point.Notes = "from ACMaps";
				point.At = At(lb, item.X, item.Y);
				point.Z = item.Z;
				point.In = _din;
				TravelData.AddPoint(point);
			}
		}
	}

	private static void RemoveAll(int lb)
	{
		string din = _din;
		List<TravelData.Point> list = new List<TravelData.Point>();
		foreach (TravelData.Point value in TravelData.Points.Values)
		{
			if (value.In == din && value.Notes == "from ACMaps")
			{
				list.Add(value);
			}
		}
		foreach (TravelData.Point item in list)
		{
			TravelData.RemovePoint(item);
		}
	}

	public static void DrawPreview(ImDrawListPtr dl, Func<double, double, Vector2> S, string din, int show)
	{
		if (!_open || !_preview || din != _din || _busy)
		{
			return;
		}
		int lb = _lb;
		List<AcMapsCore.Found> found = _found;
		if (found == null)
		{
			return;
		}
		uint colorU = ImGui.GetColorU32(new Vector4(1f, 0.85f, 0.2f, 1f));
		uint colorU2 = ImGui.GetColorU32(new Vector4(0f, 0f, 0f, 0.9f));
		foreach (AcMapsCore.Found item in found)
		{
			if (Want[item.Kind] && LevelOf(item.Z) == show && !Have(lb, item))
			{
				Vector2 vector = S(item.X, item.Y);
				dl.AddCircle(vector, 6f, colorU2, 16, 3f);
				dl.AddCircle(vector, 6f, colorU, 16, 1.5f);
				string text = PName[item.Kind].Substring(0, 1);
				dl.AddText(new Vector2(vector.X + 7f, vector.Y - 7f), colorU2, text);
				dl.AddText(new Vector2(vector.X + 6f, vector.Y - 8f), colorU, text);
			}
		}
	}
}
