// Retail (Decal) only - MelksQB's own map windows as the retail build had them (recovered from its last build, 14 Nov 2026).
// ACGodot leaves this folder out: its map is ACGodot's built-in one (Travel/MapBridge.cs).
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Numerics;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;

namespace MelksQuestTracker.Travel;

internal static class DungeonView
{
	public static bool AutoOpen = true;

	private static int _lb = -1;

	private static int _shownLb = -1;

	private static float _scale = 3f;

	private static Vector2 _pan;

	private static int _level = int.MinValue;

	private static List<Pt> _path;

	private static DateTime _pathAt = DateTime.MinValue;

	private static string _pathKey = "";

	private static int _viewLb = -1;

	private static string _viewInst = "";

	private static bool _autoShown;

	private static int _wantAcMap = -1;

	private static readonly Dictionary<string, HashSet<uint>> _visited = new Dictionary<string, HashSet<uint>>();

	private static string _visitDirty;

	private static DateTime _visitDirtyAt;

	private static TravelData.Point hotPt;

	private static TravelData.Point _menuPt;

	private static TravelData.Point _edit;

	private static Coords _menuAt = Coords.None;

	private static double _menuZ;

	private static int _menuLb = -1;

	private static string _menuVk = "";

	private static string _menuIn = "";

	private static string _menuInst = "";

	private static uint _menuCell;

	private static int _menuArea = -1;

	private static bool _labels = true;

	private static bool _editNew;

	private static bool _openEdit;

	private static string _eName = "";

	private static string _eNotes = "";

	private static int _eType;

	private static readonly string[] Types = new string[12]
	{
		"Custom", "Portal", "NPC", "Vendor", "Chest", "Lever / switch", "Boss", "Door", "Quest", "Hunting spot",
		"Keep out", "Portal bot"
	};

	public static bool Visible => WorldView.Visible && WorldView.InDungeonView;

	public static int CurrentLb => (_viewLb < 0) ? _lb : _viewLb;

	public static void Show()
	{
		WorldView.ShowDungeon();
	}

	public static void Hide()
	{
		WorldView.LeaveDungeonView();
	}

	public static void View(int lb, string inst)
	{
		_viewLb = lb;
		_viewInst = inst ?? "";
		_pan = new Vector2(0f, 0f);
		_level = int.MinValue;
	}

	public static bool HasCells(int lb)
	{
		return lb >= 0 && WorldMap.Dungeon(lb) != null;
	}

	public static string MapIdFor(int lb, string inst)
	{
		if (string.IsNullOrEmpty(inst) || !inst.StartsWith("v"))
		{
			string text = lb.ToString("X4");
			return (!MapView.Has(text)) ? null : text;
		}
		string value = TravelData.LocName(lb, inst);
		if (value == null)
		{
			TravelData.VarNames.TryGetValue(lb.ToString("X4") + inst, out value);
		}
		return (value == null || !MapView.Has(value)) ? null : value;
	}

	public static void DrawEmbedded()
	{
		Content();
	}

	public static void Dispose()
	{
	}

	public static void Tick()
	{
		AcMapTick();
		uint num = Travel.Cell();
		int num2 = (((num & 0xFFFF) < 256) ? (-1) : ((int)(num >> 16)));
		if (num2 >= 0 && (TravelData.AreaOfCell(num) < 0 || WorldMap.Dungeon(num2) == null))
		{
			num2 = -1;
		}
		if (num2 >= 0 && Travel.PlaceKnown)
		{
			Visit(num2, num);
		}
		if (num2 == _lb)
		{
			return;
		}
		SaveVisited();
		_lb = num2;
		if (num2 >= 0)
		{
			_viewLb = -1;
		}
		_pan = new Vector2(0f, 0f);
		_level = int.MinValue;
		_path = null;
		if (num2 < 0)
		{
			if (_shownLb >= 0 && _autoShown)
			{
				WorldView.Hide();
			}
			_shownLb = -1;
			_autoShown = false;
		}
		else if (AutoOpen)
		{
			_shownLb = num2;
			if (!WorldView.Visible)
			{
				_autoShown = true;
			}
			Show();
			_wantAcMap = num2;
		}
	}

	private static void AcMapTick()
	{
		if (_wantAcMap < 0 || !Travel.PlaceKnown)
		{
			return;
		}
		int wantAcMap = _wantAcMap;
		_wantAcMap = -1;
		if (wantAcMap == _lb)
		{
			string text = MapIdFor(wantAcMap, Travel.DungeonInst(wantAcMap));
			if (text != null && MapView.Showing != text)
			{
				MapView.Show(text);
			}
		}
	}

	private static int LevelOf(double z)
	{
		return (int)Math.Round(z / 6.0);
	}

	private static void Content()
	{
		//IL_08ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0857: Unknown result type (might be due to invalid IL or missing references)
		//IL_085c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0806: Unknown result type (might be due to invalid IL or missing references)
		//IL_080b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1297: Unknown result type (might be due to invalid IL or missing references)
		//IL_129c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ba3: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bb9: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bd0: Unknown result type (might be due to invalid IL or missing references)
		uint num = Travel.Cell();
		int lb;
		if (_viewLb >= 0)
		{
			lb = _viewLb;
		}
		else
		{
			lb = (((num & 0xFFFF) < 256) ? _lb : ((int)(num >> 16)));
		}
		string text = ((_viewLb < 0) ? Travel.DungeonInst(lb) : _viewInst);
		string text2 = ((lb < 0) ? "" : lb.ToString("X4")) + text;
		if (_viewLb >= 0 && num >> 16 == (uint)lb && (num & 0xFFFF) >= 256 && Travel.DungeonInst(lb) == _viewInst)
		{
			_viewLb = -1;
		}
		Dictionary<uint, DCell> dictionary = ((lb < 0) ? null : WorldMap.Dungeon(lb));
		if (dictionary == null)
		{
			Im.TextDisabled((lb >= 0) ? ("No map data for " + lb.ToString("X4") + ((WorldMap.Error.Length <= 0) ? "" : (" (" + WorldMap.Error + ")"))) : "Not in a dungeon.");
			return;
		}
		CellShapes.EnsureDungeon(lb, dictionary);
		double num2 = 0.0;
		double num3 = 0.0;
		double z = 0.0;
		double num4 = 0.0;
		bool flag = num >> 16 == (uint)lb;
		try
		{
			num2 = CoreManager.Current.Actions.LocationX;
			num3 = CoreManager.Current.Actions.LocationY;
			z = CoreManager.Current.Actions.LocationZ;
			num4 = CoreManager.Current.Actions.Heading;
		}
		catch
		{
			flag = false;
		}
		SortedSet<int> sortedSet = new SortedSet<int>();
		foreach (DCell value3 in dictionary.Values)
		{
			sortedSet.Add(LevelOf(value3.Z));
		}
		int num5 = ((flag && Travel.DungeonInst(lb) == text) ? LevelOf(z) : 0);
		if (!sortedSet.Contains(num5) && sortedSet.Count > 0)
		{
			int num6 = sortedSet.Min;
			foreach (int item in sortedSet)
			{
				if (Math.Abs(item - num5) < Math.Abs(num6 - num5))
				{
					num6 = item;
				}
			}
			num5 = num6;
		}
		int show = ((_level != int.MinValue) ? _level : num5);
		flag = flag && Travel.DungeonInst(lb) == text;
		Im.TextColored(TravelHud.Cyan, TravelData.AreaName(lb, text) + "  (" + TravelData.LbLabel(lb, text) + ")");
		if (text.Length > 0 && ImGui.IsItemHovered())
		{
			Im.SetTooltip("A version of dungeon " + lb.ToString("X4") + " (/location's v:" + text.Substring(1) + "): the same rooms, used as another dungeon.\nIts points, where you've been and its portals are kept apart from the other versions'.");
		}
		ImGui.SameLine();
		string text3 = MapIdFor(lb, text);
		if (text3 != null && ImGui.SmallButton("ACMaps map##dvac"))
		{
			MapView.Show(text3);
		}
		if (text3 != null)
		{
			ImGui.SameLine();
			if (ImGui.SmallButton("Copy from ACMaps...##dvacc"))
			{
				AcMapsImport.Toggle(lb, text, text3, dictionary);
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Finds the doors, gates, levers, chests ... on the ACMaps picture and puts the ones you pick on this map.");
			}
		}
		else if (text.Length > 0 && MapView.Has(lb.ToString("X4")))
		{
			ImGui.SameLine();
			Im.TextDisabled("(ACMaps is the original's)");
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("The ACMaps picture for " + lb.ToString("X4") + " is the original dungeon's - this version's doors and monsters differ, so it isn't shown or copied here.\nA picture in the maps folder named \"" + TravelData.AreaName(lb, text) + "\" would be.");
			}
		}
		if (_viewLb >= 0)
		{
			ImGui.SameLine();
			if (ImGui.SmallButton((_lb < 0) ? "Close##dvback" : "Back to where I am##dvback"))
			{
				_viewLb = -1;
				if (_lb < 0)
				{
					WorldView.LeaveDungeonView();
				}
			}
		}
		if (sortedSet.Count > 1)
		{
			Im.TextDisabled("Level:");
			ImGui.SameLine();
			if (ImGui.RadioButton("mine##dvlv", _level == int.MinValue))
			{
				_level = int.MinValue;
			}
			List<int> list = new List<int>(sortedSet);
			list.Reverse();
			int num7 = 0;
			foreach (int item2 in list)
			{
				ImGui.SameLine();
				string text4 = ((item2 != 0) ? (((item2 <= 0) ? "" : "+") + item2) : "0") + ((item2 != num5 || !flag) ? "" : "*") + "##dvl" + num7++;
				if (ImGui.RadioButton(text4, _level == item2))
				{
					_level = item2;
				}
			}
		}
		if (ImGui.SmallButton("Centre on me##dvc"))
		{
			_pan = new Vector2(0f, 0f);
		}
		ImGui.SameLine();
		if (ImGui.SmallButton("-##dvz"))
		{
			_scale = Math.Max(0.5f, _scale / 1.25f);
		}
		ImGui.SameLine();
		if (ImGui.SmallButton("+##dvz2"))
		{
			_scale = Math.Min(20f, _scale * 1.25f);
		}
		ImGui.SameLine();
		Im.TextDisabled("drag to move, wheel to zoom");
		int num8 = 0;
		foreach (DCell value4 in dictionary.Values)
		{
			List<float[]> list2 = CellShapes.Floor(value4);
			if (list2 != null && list2.Count > 0)
			{
				num8++;
			}
		}
		ImGui.SameLine();
		Im.TextDisabled("(room shapes " + num8 + "/" + dictionary.Count + ")");
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Rooms drawn with their real floor (from client_portal.dat) - the rest as 10 m squares." + ((CellShapes.LastError.Length <= 0) ? "" : ("\nLast problem reading a shape: " + CellShapes.LastError)));
		}
		Vector2 contentRegionAvail = ImGui.GetContentRegionAvail();
		if (contentRegionAvail.X < 50f || contentRegionAvail.Y < 50f)
		{
			return;
		}
		Vector2 cursorScreenPos = ImGui.GetCursorScreenPos();
		ImGui.InvisibleButton("##dvcanvas", contentRegionAvail);
		bool flag2 = ImGui.IsItemHovered();
		if (flag2 && ImGui.IsMouseDragging((ImGuiMouseButton)0))
		{
			ImGuiIOPtr iO = ImGui.GetIO();
			Vector2 mouseDelta = iO.MouseDelta;
			_pan = new Vector2(_pan.X - mouseDelta.X / _scale, _pan.Y + mouseDelta.Y / _scale);
		}
		if (flag2)
		{
			ImGuiIOPtr iO2 = ImGui.GetIO();
			float mouseWheel = iO2.MouseWheel;
			if (mouseWheel != 0f)
			{
				_scale = Math.Max(0.5f, Math.Min(20f, _scale * ((!(mouseWheel > 0f)) ? 0.86956525f : 1.15f)));
			}
		}
		ImDrawListPtr windowDrawList = ImGui.GetWindowDrawList();
		string text5 = null;
		windowDrawList.PushClipRect(cursorScreenPos, new Vector2(cursorScreenPos.X + contentRegionAvail.X, cursorScreenPos.Y + contentRegionAvail.Y), true);
		ImGui.PushStyleVar((ImGuiStyleVar)0, WorldView.Alpha);
		try
		{
			windowDrawList.AddRectFilled(cursorScreenPos, new Vector2(cursorScreenPos.X + contentRegionAvail.X, cursorScreenPos.Y + contentRegionAvail.Y), ImGui.GetColorU32(new Vector4(0.05f, 0.05f, 0.07f, 1f)));
			double cx = num2;
			double cy = num3;
			if (!flag)
			{
				double num9 = 0.0;
				double num10 = 0.0;
				foreach (DCell value5 in dictionary.Values)
				{
					num9 += value5.X;
					num10 += value5.Y;
				}
				cx = num9 / (double)dictionary.Count;
				cy = num10 / (double)dictionary.Count;
			}
			cx += _pan.X;
			cy += _pan.Y;
			Vector2 mid = new Vector2(cursorScreenPos.X + contentRegionAvail.X / 2f, cursorScreenPos.Y + contentRegionAvail.Y / 2f);
			Func<double, double, Vector2> S = (double x, double y) => new Vector2(mid.X + (float)((x - cx) * (double)_scale), mid.Y - (float)((y - cy) * (double)_scale));
			uint colorU = ImGui.GetColorU32(new Vector4(0.75f, 0.62f, 0.42f, 1f));
			uint colorU2 = ImGui.GetColorU32(new Vector4(0.35f, 0.25f, 0.12f, 1f));
			uint colorU3 = ImGui.GetColorU32(new Vector4(0.5f, 0.45f, 0.4f, 0.18f));
			uint colorU4 = ImGui.GetColorU32(new Vector4(0.55f, 0.45f, 0.3f, 1f));
			uint colorU5 = ImGui.GetColorU32(new Vector4(0.95f, 0.85f, 0.35f, 0.9f));
			uint colorU6 = ImGui.GetColorU32(new Vector4(0.28f, 0.2f, 0.12f, 1f));
			uint colorU7 = ImGui.GetColorU32(new Vector4(0.45f, 0.68f, 0.45f, 1f));
			uint colorU8 = ImGui.GetColorU32(new Vector4(0.12f, 0.08f, 0.04f, 1f));
			float num11 = 5f * _scale;
			foreach (DCell value6 in dictionary.Values)
			{
				if (LevelOf(value6.Z) == show)
				{
					continue;
				}
				Vector2 vector = S(value6.X, value6.Y);
				List<float[]> list3 = CellShapes.Floor(value6);
				bool flag3 = false;
				if (list3 != null)
				{
					foreach (float[] item3 in list3)
					{
						if (item3[0] == 0f)
						{
							for (int num12 = 1; num12 + 1 < item3.Length; num12 += 2)
							{
								windowDrawList.PathLineTo(S(item3[num12], item3[num12 + 1]));
							}
							windowDrawList.PathFillConvex(colorU3);
							flag3 = true;
						}
					}
				}
				if (!flag3)
				{
					windowDrawList.AddRectFilled(new Vector2(vector.X - num11, vector.Y - num11), new Vector2(vector.X + num11, vector.Y + num11), colorU3);
				}
			}
			List<DCell> list4 = new List<DCell>();
			bool flag4 = false;
			foreach (DCell value7 in dictionary.Values)
			{
				if (LevelOf(value7.Z) != show)
				{
					continue;
				}
				list4.Add(value7);
				Vector2 vector2 = S(value7.X, value7.Y);
				List<float[]> list5 = CellShapes.Floor(value7);
				if (list5 != null && list5.Count > 0)
				{
					flag4 = true;
					bool flag5 = Visited(text2, value7.Id);
					foreach (float[] item4 in list5)
					{
						if (item4[0] == 0f)
						{
							for (int num13 = 1; num13 + 1 < item4.Length; num13 += 2)
							{
								windowDrawList.PathLineTo(S(item4[num13], item4[num13 + 1]));
							}
							windowDrawList.PathFillConvex((!flag5) ? colorU : colorU7);
						}
					}
					foreach (float[] item5 in list5)
					{
						if (item5[0] == 1f)
						{
							for (int num14 = 1; num14 + 1 < item5.Length; num14 += 2)
							{
								windowDrawList.PathLineTo(S(item5[num14], item5[num14 + 1]));
							}
							windowDrawList.PathFillConvex(colorU6);
						}
					}
					foreach (float[] @static in value7.Statics)
					{
						if ((double)@static[2] - value7.Z > -2.0 && (double)@static[2] - value7.Z < 2.0)
						{
							windowDrawList.AddCircleFilled(S(@static[0], @static[1]), Math.Max(1.5f, (float)(0.6 * (double)_scale)), colorU6);
						}
					}
				}
				else
				{
					windowDrawList.AddRectFilled(new Vector2(vector2.X - num11, vector2.Y - num11), new Vector2(vector2.X + num11, vector2.Y + num11), (!Visited(text2, value7.Id)) ? colorU : colorU7);
				}
				foreach (uint item6 in value7.Next)
				{
					if (dictionary.TryGetValue(item6, out var value) && LevelOf(value.Z) != show)
					{
						windowDrawList.AddCircleFilled(vector2, Math.Max(2f, num11 * 0.35f), colorU5);
					}
				}
			}
			float num15 = Math.Max(1.2f, Math.Min(3f, _scale * 0.35f));
			foreach (DCell item7 in list4)
			{
				List<float[]> list6 = CellShapes.Floor(item7);
				if (list6 == null)
				{
					continue;
				}
				foreach (float[] item8 in list6)
				{
					if (item8[0] == 2f && item8.Length >= 5)
					{
						windowDrawList.AddLine(S(item8[1], item8[2]), S(item8[3], item8[4]), colorU8, num15);
					}
				}
			}
			if (flag4)
			{
				foreach (float[] item9 in CellShapes.Outline(lb, show, list4))
				{
					windowDrawList.AddLine(S(item9[0], item9[1]), S(item9[2], item9[3]), colorU2, Math.Max(1f, Math.Min(2.5f, _scale * 0.3f)));
				}
			}
			foreach (DCell item10 in list4)
			{
				if (!flag4 || CellShapes.Floor(item10) == null)
				{
					Vector2 vector3 = S(item10.X, item10.Y);
					windowDrawList.AddRect(new Vector2(vector3.X - num11, vector3.Y - num11), new Vector2(vector3.X + num11, vector3.Y + num11), colorU2);
				}
			}
			uint colorU9 = ImGui.GetColorU32(new Vector4(0.9f, 0.3f, 0.9f, 1f));
			ImGuiIOPtr iO3 = ImGui.GetIO();
			Vector2 mousePos = iO3.MousePos;
			foreach (Loc loc in TravelData.Locs)
			{
				if (!loc.HasExit || loc.Area < 0 || !TravelData.SameArea(loc.Area, lb) || (loc.In ?? "") != text || loc.Mine)
				{
					continue;
				}
				double arg = (loc.At.EW + 101.95) * 240.0 - (double)(lb >> 8) * 192.0;
				double arg2 = (loc.At.NS + 101.95) * 240.0 - (double)(lb & 0xFF) * 192.0;
				if (loc.Cell == 0 || !dictionary.TryGetValue(loc.Cell, out var value2) || LevelOf(value2.Z) == show)
				{
					Vector2 vector4 = S(arg, arg2);
					windowDrawList.AddCircleFilled(vector4, 4f, colorU9);
					if (flag2 && Math.Abs(mousePos.X - vector4.X) < 6f && Math.Abs(mousePos.Y - vector4.Y) < 6f)
					{
						text5 = loc.Name + ((!loc.HasExit) ? "" : ("\nleads to " + loc.Exit));
					}
				}
			}
			string text6 = Travel.DungeonIn(lb, text);
			hotPt = null;
			float num16 = 49f;
			foreach (TravelData.Point value8 in TravelData.Points.Values)
			{
				if (value8.In != text6 || (!double.IsNaN(value8.Z) && LevelOf(value8.Z) != show))
				{
					continue;
				}
				bool flag6 = value8.Type.IndexOf("Portal", StringComparison.OrdinalIgnoreCase) >= 0 && value8.Type != "Portal bot";
				if (flag6 && (PortalBots.IsBotName(value8.Name) || PortalBots.InZone(value8.At, lb)))
				{
					continue;
				}
				double arg3 = (value8.At.EW + 101.95) * 240.0 - (double)(lb >> 8) * 192.0;
				double arg4 = (value8.At.NS + 101.95) * 240.0 - (double)(lb & 0xFF) * 192.0;
				Vector2 vector5 = S(arg3, arg4);
				bool flag7 = flag6;
				bool flag8 = value8.Type == "Keep out";
				uint num17;
				if (flag7)
				{
					num17 = colorU9;
				}
				else if (flag8)
				{
					num17 = ImGui.GetColorU32(new Vector4(1f, 0.3f, 0.25f, 1f));
				}
				else
				{
					num17 = ((!(value8.Type == "Portal bot")) ? ImGui.GetColorU32((!value8.Auto) ? new Vector4(0.35f, 1f, 0.35f, 1f) : new Vector4(0.45f, 0.8f, 1f, 1f)) : ImGui.GetColorU32(new Vector4(1f, 0.6f, 0.95f, 1f)));
				}
				if (flag8)
				{
					float num18 = (float)(6.0 * (double)_scale);
					windowDrawList.AddCircle(vector5, num18, num17, 24, 2f);
					windowDrawList.AddLine(new Vector2(vector5.X - 5f, vector5.Y - 5f), new Vector2(vector5.X + 5f, vector5.Y + 5f), num17, 2f);
					windowDrawList.AddLine(new Vector2(vector5.X - 5f, vector5.Y + 5f), new Vector2(vector5.X + 5f, vector5.Y - 5f), num17, 2f);
				}
				else if (flag7)
				{
					windowDrawList.AddCircleFilled(vector5, 4f, num17);
				}
				else
				{
					windowDrawList.AddTriangleFilled(new Vector2(vector5.X, vector5.Y - 6f), new Vector2(vector5.X + 5f, vector5.Y + 4f), new Vector2(vector5.X - 5f, vector5.Y + 4f), num17);
				}
				windowDrawList.AddCircle(vector5, (!flag7) ? 0.1f : 4f, ImGui.GetColorU32(new Vector4(0f, 0f, 0f, 0.9f)));
				if (_labels && _scale >= 2.5f)
				{
					windowDrawList.AddText(new Vector2(vector5.X + 7f, vector5.Y - 7f), ImGui.GetColorU32(new Vector4(0f, 0f, 0f, 0.9f)), value8.Name);
					windowDrawList.AddText(new Vector2(vector5.X + 6f, vector5.Y - 8f), num17, value8.Name);
				}
				if (flag2)
				{
					float num19 = mousePos.X - vector5.X;
					float num20 = mousePos.Y - vector5.Y;
					float num21 = num19 * num19 + num20 * num20;
					if (num21 < num16)
					{
						num16 = num21;
						hotPt = value8;
					}
				}
			}
			if (hotPt != null)
			{
				text5 = hotPt.Name + "  (" + hotPt.Type + ((!hotPt.Auto) ? ", yours" : ", seen") + ")" + ((!string.IsNullOrEmpty(hotPt.Notes)) ? ("\n" + hotPt.Notes) : "") + "\nRight-click: change / delete";
			}
			if (flag2 && ImGui.IsMouseReleased((ImGuiMouseButton)1))
			{
				_menuPt = hotPt;
				double num22 = cx + (double)((mousePos.X - mid.X) / _scale);
				double num23 = cy - (double)((mousePos.Y - mid.Y) / _scale);
				_menuAt = new Coords(((double)(lb & 0xFF) * 192.0 + num23) / 240.0 - 101.95, ((double)(lb >> 8) * 192.0 + num22) / 240.0 - 101.95);
				_menuZ = (double)show * 6.0;
				_menuIn = text6;
				_menuInst = text;
				_menuArea = lb;
				_menuCell = 0u;
				double num24 = double.MaxValue;
				foreach (DCell value9 in dictionary.Values)
				{
					if (LevelOf(value9.Z) == show)
					{
						double num25 = (value9.X - num22) * (value9.X - num22) + (value9.Y - num23) * (value9.Y - num23);
						if (num25 < num24)
						{
							num24 = num25;
							_menuCell = value9.Id;
							_menuZ = value9.Z;
						}
					}
				}
				ImGui.OpenPopup("##dvmenu");
			}
			AcMapsImport.DrawPreview(windowDrawList, S, text6, show);
			DrawRoute(windowDrawList, S, lb, num, flag);
			MapRoute.Draw(windowDrawList, (double pn, double pe, double mz) =>
			{
				double num27 = (pe + 101.95) * 240.0 - (double)(lb >> 8) * 192.0;
				double num28 = (pn + 101.95) * 240.0 - (double)(lb & 0xFF) * 192.0;
				return (num27 < -20.0 || num28 < -20.0 || num27 > 212.0 || num28 > 212.0 || LevelOf(mz) != show) ? ((Vector2?)null) : new Vector2?(S(num27, num28));
			});
			_menuLb = lb;
			_menuVk = text2;
			if (flag && LevelOf(z) == show)
			{
				Vector2 a = S(num2, num3);
				double num26 = num4 * Math.PI / 180.0;
				float sn = (float)Math.Sin(num26);
				float cs = (float)Math.Cos(num26);
				Func<float, float, Vector2> func = (float x, float y) => new Vector2(a.X + x * cs - y * sn, a.Y + x * sn + y * cs);
				windowDrawList.AddTriangleFilled(func(0f, -9f), func(-6f, 6f), func(6f, 6f), ImGui.GetColorU32(new Vector4(0.3f, 1f, 0.4f, 1f)));
				windowDrawList.AddTriangle(func(0f, -9f), func(-6f, 6f), func(6f, 6f), ImGui.GetColorU32(new Vector4(0f, 0f, 0f, 1f)), 1.5f);
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		finally
		{
			ImGui.PopStyleVar();
			windowDrawList.PopClipRect();
		}
		if (text5 != null)
		{
			Im.SetTooltip(text5);
		}
		Menu();
		EditPopup();
		AcMapsImport.Window(Travel.DungeonIn(lb, text), dictionary);
	}

	private static string VKey(int lb)
	{
		return lb.ToString("X4") + Travel.DungeonInst(lb);
	}

	private static string VisitPath(string key)
	{
		string text = (((TravelData.CharKey ?? "").Length <= 0) ? "default" : TravelData.CharKey);
		char[] invalidFileNameChars = Path.GetInvalidFileNameChars();
		foreach (char oldChar in invalidFileNameChars)
		{
			text = text.Replace(oldChar, '_');
		}
		return Util.FullPath(Path.Combine(Path.Combine(Path.Combine("Maps", "Visited"), text), key + ".txt"));
	}

	private static HashSet<uint> VisitSet(string key)
	{
		if (_visited.TryGetValue(key, out var value))
		{
			return value;
		}
		value = new HashSet<uint>();
		try
		{
			string path = VisitPath(key);
			if (File.Exists(path))
			{
				string[] array = File.ReadAllLines(path);
				foreach (string text in array)
				{
					if (uint.TryParse(text.Trim(), NumberStyles.HexNumber, null, out var result))
					{
						value.Add(result);
					}
				}
			}
		}
		catch
		{
		}
		_visited[key] = value;
		return value;
	}

	private static bool Visited(string key, uint id)
	{
		return VisitSet(key).Contains(id);
	}

	private static void Visit(int lb, uint cell)
	{
		string text = VKey(lb);
		HashSet<uint> hashSet = VisitSet(text);
		if (hashSet.Add(cell))
		{
			_visitDirty = text;
			_visitDirtyAt = DateTime.Now;
		}
		try
		{
			Dictionary<uint, DCell> dictionary = WorldMap.Dungeon(lb);
			double locationX = CoreManager.Current.Actions.LocationX;
			double locationY = CoreManager.Current.Actions.LocationY;
			double locationZ = CoreManager.Current.Actions.LocationZ;
			if (dictionary != null)
			{
				foreach (DCell value in dictionary.Values)
				{
					if (Math.Abs(value.X - locationX) < 6.0 && Math.Abs(value.Y - locationY) < 6.0 && Math.Abs(value.Z - locationZ) < 3.0 && hashSet.Add(value.Id))
					{
						_visitDirty = text;
						_visitDirtyAt = DateTime.Now;
					}
				}
			}
		}
		catch
		{
		}
		if (_visitDirty != null && (DateTime.Now - _visitDirtyAt).TotalSeconds > 5.0)
		{
			SaveVisited();
		}
	}

	private static void SaveVisited()
	{
		string visitDirty = _visitDirty;
		_visitDirty = null;
		if (visitDirty == null)
		{
			return;
		}
		try
		{
			string path = VisitPath(visitDirty);
			Directory.CreateDirectory(Path.GetDirectoryName(path));
			List<string> list = new List<string>();
			foreach (uint item in VisitSet(visitDirty))
			{
				list.Add(item.ToString("X8"));
			}
			File.WriteAllLines(path, list.ToArray());
		}
		catch
		{
		}
	}

	private static void ClearVisited(string key)
	{
		VisitSet(key).Clear();
		try
		{
			string path = VisitPath(key);
			if (File.Exists(path))
			{
				File.Delete(path);
			}
		}
		catch
		{
		}
	}

	private static double FloorZ(int lb, Coords at, double levelZ)
	{
		Dictionary<uint, DCell> dictionary = ((lb < 0) ? null : WorldMap.Dungeon(lb));
		if (dictionary == null)
		{
			return levelZ;
		}
		double num = (at.EW + 101.95) * 240.0 - (double)(lb >> 8) * 192.0;
		double num2 = (at.NS + 101.95) * 240.0 - (double)(lb & 0xFF) * 192.0;
		int num3 = LevelOf(levelZ);
		double num4 = double.MaxValue;
		double result = levelZ;
		foreach (DCell value in dictionary.Values)
		{
			if (LevelOf(value.Z) == num3)
			{
				double num5 = (value.X - num) * (value.X - num) + (value.Y - num2) * (value.Y - num2);
				if (num5 < num4)
				{
					num4 = num5;
					result = value.Z;
				}
			}
		}
		return result;
	}

	private static void Menu()
	{
		if (!ImGui.BeginPopup("##dvmenu"))
		{
			return;
		}
		if (_menuPt != null)
		{
			Im.TextColored(TravelHud.Cyan, _menuPt.Name);
			ImGui.Separator();
			if (ImGui.MenuItem("Change..."))
			{
				StartEdit(_menuPt, isNew: false);
			}
			if (ImGui.MenuItem("Delete"))
			{
				TravelData.RemovePoint(_menuPt);
			}
		}
		else if (ImGui.MenuItem("Add a point here..."))
		{
			TravelData.Point point = new TravelData.Point();
			point.Name = "";
			point.Type = "Custom";
			point.At = _menuAt;
			point.Z = _menuZ;
			point.In = _menuIn;
			StartEdit(point, isNew: true);
		}
		ImGui.Separator();
		if (_menuArea >= 0 && _menuCell != 0)
		{
			string name = ((_menuPt == null) ? (TravelData.AreaName(_menuArea, _menuInst) + " (level " + LevelOf(_menuZ) + ")") : _menuPt.Name);
			if (ImGui.MenuItem("Auto travel here"))
			{
				Travel.NextDestGroup = _menuInst;
				Travel.GoTo(_menuAt, _menuArea, name, 1, _menuCell);
				AutoTravel.Start();
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Runs you there with Nav - through the dungeon's rooms (and portals, if it's somewhere else).");
			}
			if (ImGui.MenuItem("Go here (route)"))
			{
				Travel.NextDestGroup = _menuInst;
				Travel.GoTo(_menuAt, _menuArea, name, 1, _menuCell);
			}
			ImGui.Separator();
		}
		MapRoute.MenuItems(_menuAt, FloorZ(_menuLb, _menuAt, _menuZ));
		ImGui.Separator();
		ImGui.MenuItem("Show names", "", ref _labels);
		if (_menuLb >= 0 && ImGui.MenuItem("Clear where I've been (this dungeon)"))
		{
			ClearVisited(_menuVk);
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Rooms you've walked through are shown green; this starts that over for this dungeon.");
		}
		ImGui.EndPopup();
	}

	private static void StartEdit(TravelData.Point p, bool isNew)
	{
		_edit = p;
		_editNew = isNew;
		_openEdit = true;
		_eName = p.Name;
		_eNotes = p.Notes ?? "";
		_eType = Math.Max(0, Array.IndexOf(Types, p.Type));
	}

	private static void EditPopup()
	{
		if (_openEdit)
		{
			ImGui.OpenPopup("Dungeon point##dvedit");
			_openEdit = false;
		}
		ImGui.SetNextWindowSize(new Vector2(340f, 0f), (ImGuiCond)8);
		if (!ImGui.BeginPopup("Dungeon point##dvedit"))
		{
			return;
		}
		if (_edit == null)
		{
			ImGui.CloseCurrentPopup();
			ImGui.EndPopup();
			return;
		}
		Im.TextColored(TravelHud.Cyan, (!_editNew) ? "Change point" : "New point");
		ImGui.SetNextItemWidth(240f);
		ImGui.InputText("Name##dve", ref _eName, 120u);
		ImGui.SetNextItemWidth(240f);
		ImGui.Combo("Type##dve", ref _eType, Types, Types.Length);
		ImGui.InputTextMultiline("Notes##dve", ref _eNotes, 2000u, new Vector2(240f, 60f));
		if (ImGui.Button("Save##dve") && _eName.Trim().Length > 0)
		{
			TravelData.Point point = new TravelData.Point();
			point.Name = _eName.Trim();
			point.Type = Types[_eType];
			point.Notes = _eNotes.Trim();
			point.At = _edit.At;
			point.Z = _edit.Z;
			point.In = _edit.In;
			TravelData.Point p = point;
			if (!_editNew)
			{
				TravelData.RemovePoint(_edit);
			}
			TravelData.AddPoint(p);
			_edit = null;
			ImGui.CloseCurrentPopup();
		}
		ImGui.SameLine();
		if (ImGui.Button("Cancel##dve"))
		{
			_edit = null;
			ImGui.CloseCurrentPopup();
		}
		ImGui.EndPopup();
	}

	public static void SeePortals()
	{
		if (_lb < 0 || !Travel.PlaceKnown)
		{
			return;
		}
		string text = Travel.DungeonIn(_lb);
		foreach (WorldObject item in CoreManager.Current.WorldFilter.GetLandscape())
		{
			if (!Travel.IsPortal(item))
			{
				continue;
			}
			uint num = 0u;
			try
			{
				num = (uint)item.Values((LongValueKey)218103811);
			}
			catch
			{
			}
			if (num >> 16 != (uint)_lb)
			{
				continue;
			}
			CoordsObject val = item.Coordinates();
			Coords coords = new Coords(val.NorthSouth, val.EastWest);
			if (PortalBots.IsBotName(item.Name) || PortalBots.InZone(coords, _lb))
			{
				continue;
			}
			double z = double.NaN;
			try
			{
				z = item.RawCoordinates().Z;
			}
			catch
			{
			}
			bool flag = false;
			foreach (TravelData.Point value in TravelData.Points.Values)
			{
				if (value.In == text && string.Equals(value.Name, item.Name, StringComparison.OrdinalIgnoreCase) && value.At.DistanceTo(coords) * 240.0 < 2.0)
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				TravelData.Point point = new TravelData.Point();
				point.Name = item.Name;
				point.Type = "Portal";
				point.At = coords;
				point.Z = z;
				point.In = text;
				point.Auto = true;
				TravelData.AddPoint(point);
			}
		}
	}

	private static void DrawRoute(ImDrawListPtr dl, Func<double, double, Vector2> S, int lb, uint cell, bool here)
	{
		if (!here || !Travel.Active || Travel.ArrowOnly)
		{
			return;
		}
		Coords b = Travel.ArrowTarget(out var _);
		Leg current = Travel.Current;
		int a = ((current == null || !current.Target.Valid) ? Travel.DestArea : current.TargetArea);
		if (!b.Valid || !TravelData.SameArea(a, lb))
		{
			return;
		}
		string text = b.Raw() + "|" + (cell & 0xFFFF);
		if (text != _pathKey)
		{
			_pathKey = text;
			_pathAt = DateTime.Now;
			uint num = 0u;
			if (current != null && current.Kind == "portal")
			{
				foreach (Loc loc in TravelData.Locs)
				{
					if (loc.Key == current.PortalKey)
					{
						num = loc.Cell;
					}
				}
			}
			if (num == 0 && Travel.DestCell != 0 && Travel.DestCell >> 16 == (uint)lb && b.Raw() == Travel.DestAt.Raw())
			{
				num = Travel.DestCell;
			}
			_path = PathPlan.Indoors(Travel.Here(), lb, cell, b, num);
		}
		if (_path == null || _path.Count == 0)
		{
			return;
		}
		uint colorU = ImGui.GetColorU32(new Vector4(1f, 0.85f, 0.2f, 1f));
		double arg = 0.0;
		double arg2 = 0.0;
		try
		{
			arg = CoreManager.Current.Actions.LocationX;
			arg2 = CoreManager.Current.Actions.LocationY;
		}
		catch
		{
		}
		Vector2 vector = S(arg, arg2);
		foreach (Pt item in _path)
		{
			double arg3 = (item.EW + 101.95) * 240.0 - (double)(lb >> 8) * 192.0;
			double arg4 = (item.NS + 101.95) * 240.0 - (double)(lb & 0xFF) * 192.0;
			Vector2 vector2 = S(arg3, arg4);
			dl.AddLine(vector, vector2, colorU, 3f);
			vector = vector2;
		}
		dl.AddCircle(vector, 7f, colorU, 16, 2f);
	}
}
