// Retail (Decal) only - MelksQB's own map windows as the retail build had them (recovered from its last build, 14 Nov 2026).
// ACGodot leaves this folder out: its map is ACGodot's built-in one (Travel/MapBridge.cs).
using Hud = UtilityBelt.Service.Views.Hud;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Text;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MyClasses.MetaViewWrappers.UBHudControls;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelksQuestTracker.Travel;

internal static class WorldView
{
	private class Mark
	{
		public string Name;

		public string Type;

		public string Layer;

		public string Notes;

		public Coords At;

		public Loc Loc;

		public TravelData.Point Point;

		public bool Random;
	}

	private class Spot
	{
		public Vector2 P;

		public readonly List<Mark> Items = new List<Mark>();

		public Mark Top
		{
			get
			{
				Mark mark = Items[0];
				foreach (Mark item in Items)
				{
					if (Rank(item) > Rank(mark))
					{
						mark = item;
					}
				}
				return mark;
			}
		}
	}

	private const string Name = "MelksQB World Map";

	private static Hud _hud;

	private static bool _restored;

	private const int TilesA = 8;

	private const int TilePx = 255;

	private static ManagedTexture[] _tiles;

	private static int _tilesMade;

	private const float TileUv = 0.0019607844f;

	private static string _texErr;

	private static double _cNS;

	private static double _cEW;

	private static float _scale = 4f;

	private static bool _follow = true;

	private static bool _first = true;

	private static string _search = "";

	private static readonly string[] Layers = new string[10] { "Towns", "Housing", "Portals", "Dungeons", "NPCs", "Vendors", "Lifestones", "Landmarks", "My points", "Labels" };

	private static DateTime _barTry = DateTime.MinValue;

	private static Coords _flash = Coords.None;

	private static DateTime _flashAt;

	private static readonly Dictionary<int, KeyValuePair<double[], DateTime>> _firstSeen = new Dictionary<int, KeyValuePair<double[], DateTime>>();

	private static readonly HashSet<int> _moved = new HashSet<int>();

	private static List<Mark> _marks = new List<Mark>();

	private static int _marksVer = -1;

	private static int _marksPtVer = -1;

	private static int _marksRnd = -1;

	private static string _view = "";

	private static string _marksView = null;

	private static string _viewFor = null;

	private static bool _viewPicked;

	private static long _placeAskSeen;

	private static float _alpha = -1f;

	private static Vector2 _lastAvail = new Vector2(500f, 500f);

	private static bool _zoomTierPending;

	private static List<Mark> _menuItems;

	private static Coords _menuAt = Coords.None;

	private static TravelData.Point _edit;

	private static bool _editNew;

	private static bool _openEdit;

	private static string _eName = "";

	private static string _eNotes = "";

	private static string _eCoords = "";

	private static string _eErr = "";

	private static int _eType;

	private static readonly string[] Types = new string[13]
	{
		"Custom", "NPC", "Vendor", "Portal", "Random portal", "Dungeon", "Landmark", "Town", "Village", "Lifestone",
		"Outpost", "Hunting spot", "Quest"
	};

	private static string _importMsg = "";

	private static bool TexReady => _tiles != null && _tilesMade > 0;

	public static bool AutoAddNpcs => TravelData.Flags.Contains("wm-npcs");

	public static bool Visible => _hud != null && _hud.Visible;

	public static bool InDungeonView => _view == "dungeon";

	public static float Alpha
	{
		get
		{
			if (_alpha < 0f)
			{
				_alpha = 1f;
				try
				{
					string path = Util.FullPath("WorldMapOpacity.txt");
					if (File.Exists(path) && float.TryParse(File.ReadAllText(path).Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out var result))
					{
						_alpha = Math.Max(0.15f, Math.Min(1f, result));
					}
				}
				catch
				{
				}
			}
			return _alpha;
		}
		set
		{
			_alpha = Math.Max(0.15f, Math.Min(1f, value));
			try
			{
				File.WriteAllText(Util.FullPath("WorldMapOpacity.txt"), _alpha.ToString("0.00", CultureInfo.InvariantCulture));
			}
			catch
			{
			}
		}
	}

	public static bool SolidLayer => TravelData.Flags.Contains("wm-solid");

	private static bool LayerOn(string l)
	{
		return !TravelData.Flags.Contains("wm-off-" + l);
	}

	private static void SetLayer(string l, bool on)
	{
		string text = "wm-off-" + l;
		if (on)
		{
			TravelData.ClearFlag(text);
		}
		else
		{
			TravelData.SetFlag(text);
		}
	}

	private static bool Ensure()
	{
		if (_hud != null)
		{
			return true;
		}
		try
		{
			if (UBService.Huds == null)
			{
				return false;
			}
			_hud = UBService.Huds.CreateHud("MelksQB World Map", BarIcon.Make("World"));
			_hud.ShowInBar = true;
			_hud.OnPreRender += (object s, EventArgs e) =>
			{
				if (!_restored && WindowMemory.Ready)
				{
					_restored = true;
					if (WindowMemory.TryGet("MelksQB World Map", out var rect))
					{
						ImGui.SetNextWindowPos(new Vector2(rect[0], rect[1]), (ImGuiCond)1);
						ImGui.SetNextWindowSize(new Vector2(rect[2], rect[3]), (ImGuiCond)1);
					}
				}
				ImGui.SetNextWindowSize(new Vector2(620f, 640f), (ImGuiCond)4);
				ImGui.SetNextWindowBgAlpha(0.92f * Alpha);
			};
			_hud.OnRender += (object s, EventArgs e) =>
			{
				try
				{
					WindowMemory.Track("MelksQB World Map");
				}
				catch
				{
				}
				try
				{
					Content();
				}
				catch (Exception ex2)
				{
					Util.LogError(ex2);
				}
			};
			return true;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			_hud = null;
			return false;
		}
	}

	public static void EnsureBar()
	{
		if (_hud == null && DateTime.Now >= _barTry)
		{
			_barTry = DateTime.Now.AddSeconds(5.0);
			Ensure();
		}
	}

	public static void Show()
	{
		WorldMap.EnsureRegions();
		if (Ensure())
		{
			_hud.Visible = true;
		}
	}

	public static void Hide()
	{
		if (_hud != null)
		{
			_hud.Visible = false;
		}
	}

	public static void Toggle()
	{
		if (Visible)
		{
			Hide();
		}
		else
		{
			Show();
		}
	}

	public static void ShowAt(Coords c)
	{
		if (c.Valid)
		{
			_cNS = c.NS;
			_cEW = c.EW;
			_follow = false;
			_first = false;
			_scale = Math.Max(_scale, 40f);
			_flash = c;
			_flashAt = DateTime.Now;
			Show();
		}
	}

	public static void Dispose()
	{
		try
		{
			if (_hud != null)
			{
				_hud.Dispose();
			}
		}
		catch
		{
		}
		_hud = null;
		_restored = false;
		FreeTiles();
	}

	public static void ScanNpcs()
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Invalid comparison between Unknown and I4
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Invalid comparison between Unknown and I4
		if ((!AutoAddNpcs && Travel.HereGroup.Length == 0) || !Travel.PlaceKnown)
		{
			return;
		}
		foreach (WorldObject item in CoreManager.Current.WorldFilter.GetLandscape())
		{
			if ((int)item.ObjectClass == 37 || (int)item.ObjectClass == 25)
			{
				Seen(item);
			}
		}
	}

	public static void Seen(WorldObject o)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Invalid comparison between Unknown and I4
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Invalid comparison between Unknown and I4
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Invalid comparison between Unknown and I4
		try
		{
			if (!Travel.PlaceKnown)
			{
				return;
			}
			string hereGroup = Travel.HereGroup;
			if (o == null || (!AutoAddNpcs && hereGroup.Length == 0) || ((int)o.ObjectClass != 37 && (int)o.ObjectClass != 25) || !StaysPut(o))
			{
				return;
			}
			uint cell = Travel.Cell();
			int num = TravelData.AreaOfCell(cell);
			if (num >= 0)
			{
				SeenInDungeon(o, num);
				return;
			}
			Coords o2;
			try
			{
				CoordsObject val = o.Coordinates();
				o2 = new Coords(val.NorthSouth, val.EastWest);
			}
			catch
			{
				return;
			}
			if (!o2.Valid || o2.DistanceTo(Travel.Here()) > 2.0)
			{
				return;
			}
			string type = (((int)o.ObjectClass != 25) ? "NPC" : "Vendor");
			string text = TravelData.Plain(o.Name ?? "");
			if (text.Length == 0)
			{
				return;
			}
			if (hereGroup.Length == 0)
			{
				foreach (Loc loc in TravelData.Locs)
				{
					if ((loc.Type == "NPC" || loc.Type == "Vendor") && loc.At.DistanceTo(o2) < 0.3 && string.Equals(loc.Name, text, StringComparison.OrdinalIgnoreCase))
					{
						return;
					}
				}
			}
			foreach (TravelData.Point value in TravelData.Points.Values)
			{
				if (value.In == hereGroup && value.At.DistanceTo(o2) < 0.3 && string.Equals(value.Name, text, StringComparison.OrdinalIgnoreCase))
				{
					return;
				}
			}
			TravelData.Point point = new TravelData.Point();
			point.Name = text;
			point.Type = type;
			point.At = new Coords(Math.Round(o2.NS, 2), Math.Round(o2.EW, 2));
			point.Auto = true;
			point.In = hereGroup;
			TravelData.AddPoint(point);
		}
		catch
		{
		}
	}

	private static bool StaysPut(WorldObject o)
	{
		double[] array;
		try
		{
			CoordsObject val = o.Coordinates();
			double num = 0.0;
			try
			{
				num = o.RawCoordinates().Z;
			}
			catch
			{
			}
			array = new double[3] { val.NorthSouth, val.EastWest, num };
		}
		catch
		{
			return false;
		}
		if (_moved.Contains(o.Id))
		{
			return false;
		}
		if (!_firstSeen.TryGetValue(o.Id, out var value))
		{
			if (_firstSeen.Count > 2000)
			{
				_firstSeen.Clear();
			}
			_firstSeen[o.Id] = new KeyValuePair<double[], DateTime>(array, DateTime.Now);
			return false;
		}
		double num2 = Math.Sqrt((array[0] - value.Key[0]) * (array[0] - value.Key[0]) + (array[1] - value.Key[1]) * (array[1] - value.Key[1])) * 240.0;
		if (num2 > 1.5)
		{
			_moved.Add(o.Id);
			return false;
		}
		return (DateTime.Now - value.Value).TotalSeconds >= 8.0;
	}

	private static void SeenInDungeon(WorldObject o, int area)
	{
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Invalid comparison between Unknown and I4
		uint num = 0u;
		try
		{
			num = (uint)o.Values((LongValueKey)218103811);
		}
		catch
		{
		}
		if (num >> 16 != (uint)area && TravelData.AreaOfCell(num) != area)
		{
			return;
		}
		string text = TravelData.Plain(o.Name ?? "");
		if (text.Length == 0 || PortalBots.IsBotName(o.Name))
		{
			return;
		}
		Coords o2;
		try
		{
			CoordsObject val = o.Coordinates();
			o2 = new Coords(val.NorthSouth, val.EastWest);
		}
		catch
		{
			return;
		}
		if (!o2.Valid)
		{
			return;
		}
		double z = double.NaN;
		try
		{
			z = o.RawCoordinates().Z;
		}
		catch
		{
		}
		string text2 = Travel.DungeonIn(area);
		foreach (TravelData.Point value in TravelData.Points.Values)
		{
			if (value.In == text2 && string.Equals(value.Name, text, StringComparison.OrdinalIgnoreCase) && value.At.DistanceTo(o2) * 240.0 < 3.0)
			{
				return;
			}
		}
		string type = (((int)o.ObjectClass != 25) ? "NPC" : "Vendor");
		TravelData.Point point = new TravelData.Point();
		point.Name = text;
		point.Type = type;
		point.At = new Coords(Math.Round(o2.NS, 5), Math.Round(o2.EW, 5));
		point.Z = z;
		point.Auto = true;
		point.In = text2;
		TravelData.AddPoint(point);
	}

	private static bool IsHousing(string name, string notes)
	{
		string text = (name ?? "").ToLowerInvariant();
		if (text.Contains("cottage") || text.Contains("villa") || text.Contains("mansion") || text.Contains("apartment"))
		{
			return true;
		}
		string text2 = (notes ?? "").ToLowerInvariant();
		return text2.Contains("provide housing") || text2.Contains("provides housing");
	}

	private static string LayerOf(string type, bool hasExit, string name, string notes)
	{
		if (type == "Village" && IsHousing(name, notes))
		{
			return "Housing";
		}
		switch (type)
		{
		case "Town":
		case "Village":
		case "AllegianceHall":
			return "Towns";
		case "Dungeon":
			return "Dungeons";
		case "NPC":
			return "NPCs";
		case "Vendor":
			return "Vendors";
		case "Lifestone":
		case "Bindstone":
			return "Lifestones";
		case "Landmark":
		case "Outpost":
			return "Landmarks";
		default:
			if (hasExit || TravelData.IsPortalType(type) || type.IndexOf("Portal", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				return "Portals";
			}
			return "Landmarks";
		}
	}

	private static void DropStrays()
	{
		List<TravelData.Point> list = new List<TravelData.Point>();
		foreach (TravelData.Point value in TravelData.Points.Values)
		{
			if (!value.Auto || value.In.Length > 0)
			{
				continue;
			}
			foreach (TravelData.Point value2 in TravelData.Points.Values)
			{
				if (value2.In.Length > 0 && value2.Auto && string.Equals(value2.Name, value.Name, StringComparison.OrdinalIgnoreCase) && value2.At.DistanceTo(value.At) < 0.05)
				{
					list.Add(value);
					break;
				}
			}
		}
		List<TravelData.Point> list2 = new List<TravelData.Point>(TravelData.Points.Values);
		for (int i = 0; i < list2.Count; i++)
		{
			TravelData.Point point = list2[i];
			if (list.Contains(point))
			{
				continue;
			}
			for (int j = i + 1; j < list2.Count; j++)
			{
				TravelData.Point point2 = list2[j];
				if (!list.Contains(point2) && !(point.In != point2.In) && string.Equals(point.Type, point2.Type, StringComparison.OrdinalIgnoreCase) && string.Equals(point.Name.Trim(), point2.Name.Trim(), StringComparison.OrdinalIgnoreCase) && !(point.At.DistanceTo(point2.At) * 240.0 > 2.5))
				{
					if (point.Auto && !point2.Auto)
					{
						list.Add(point);
						break;
					}
					list.Add(point2);
				}
			}
		}
		foreach (TravelData.Point item in list)
		{
			TravelData.RemovePoint(item);
		}
		if (!TravelData.Bounds.ContainsKey("tier11+"))
		{
			return;
		}
		List<TravelData.Point> list3 = new List<TravelData.Point>();
		foreach (TravelData.Point value3 in TravelData.Points.Values)
		{
			if (value3.In == "tier11+" && !TravelData.InsideBound("tier11+", value3.At))
			{
				list3.Add(value3);
			}
		}
		foreach (TravelData.Point item2 in list3)
		{
			TravelData.RemovePoint(item2);
			TravelData.Point point3 = new TravelData.Point();
			point3.Name = item2.Name;
			point3.Type = item2.Type;
			point3.Notes = item2.Notes;
			point3.At = item2.At;
			point3.Auto = item2.Auto;
			point3.In = "";
			TravelData.AddPoint(point3);
		}
	}

	private static string ViewTitle(string v)
	{
		if (v == "dungeon")
		{
			return "Dungeon" + ((DungeonView.CurrentLb < 0) ? "" : (": " + TravelData.AreaName(DungeonView.CurrentLb)));
		}
		return TravelData.GroupTitle(v);
	}

	public static void ShowDungeon()
	{
		Show();
		if (DungeonView.CurrentLb >= 0)
		{
			_view = "dungeon";
			_viewPicked = false;
			_viewFor = "dungeon";
		}
	}

	public static void ShowDungeonOf(int lb, string inst)
	{
		DungeonView.View(lb, inst);
		Show();
		_view = "dungeon";
		_viewPicked = true;
		_viewFor = "dungeon";
	}

	public static void PlaceRequestTick()
	{
		string text = null;
		try
		{
			text = AppDomain.CurrentDomain.GetData("MelkTank.ShowPlace") as string;
		}
		catch
		{
		}
		if (string.IsNullOrEmpty(text))
		{
			return;
		}
		string[] array = text.Split(new char[1] { '|' });
		if (array.Length < 3 || !long.TryParse(array[2], out var result) || result <= _placeAskSeen)
		{
			return;
		}
		bool flag = _placeAskSeen == 0;
		_placeAskSeen = result;
		if ((flag && DateTime.UtcNow.Ticks - result > 100000000) || !int.TryParse(array[0], NumberStyles.HexNumber, null, out var result2))
		{
			return;
		}
		string text2 = array[1];
		if (DungeonView.HasCells(result2))
		{
			ShowDungeonOf(result2, text2);
			return;
		}
		Loc loc = null;
		foreach (Loc loc2 in TravelData.Locs)
		{
			if (loc2.HasExit && loc2.ExitArea >= 0 && TravelData.SameArea(loc2.ExitArea, result2) && loc2.At.Valid && TravelData.Inst(loc2) == ((!text2.StartsWith("v")) ? "" : text2) && (loc == null || loc2.Area < loc.Area))
			{
				loc = loc2;
			}
		}
		if (loc != null && loc.Area < 0)
		{
			ShowAt(loc.At);
			Util.WriteToChat("Map: " + TravelData.AreaName(result2, text2) + " - its way in (" + loc.Name + ") is shown.");
		}
		else
		{
			Util.WriteToChat("Map: nothing to show for " + TravelData.LbLabel(result2, text2) + " yet - no map data, and no portal there is known.");
		}
	}

	public static void LeaveDungeonView()
	{
		if (_view == "dungeon")
		{
			_view = Travel.HereGroup;
			_viewPicked = true;
		}
	}

	private static void ZoomTier()
	{
		double num = double.MaxValue;
		double val = double.MinValue;
		double num2 = double.MaxValue;
		double val2 = double.MinValue;
		if (TravelData.Bounds.TryGetValue("tier11+", out var value))
		{
			foreach (List<Coords> run in value.Runs)
			{
				foreach (Coords item in run)
				{
					num = Math.Min(num, item.NS);
					val = Math.Max(val, item.NS);
					num2 = Math.Min(num2, item.EW);
					val2 = Math.Max(val2, item.EW);
				}
			}
		}
		foreach (TravelData.Point value2 in TravelData.Points.Values)
		{
			if (value2.In == "tier11+" && TravelData.InsideBound("tier11+", value2.At))
			{
				num = Math.Min(num, value2.At.NS);
				val = Math.Max(val, value2.At.NS);
				num2 = Math.Min(num2, value2.At.EW);
				val2 = Math.Max(val2, value2.At.EW);
			}
		}
		if (num == double.MaxValue)
		{
			_cNS = -30.4;
			_cEW = 94.7;
			_scale = 60f;
		}
		else
		{
			val = Math.Max(val, num + 1.0);
			val2 = Math.Max(val2, num2 + 1.0);
			val += 3.0;
			_cNS = (num + val) / 2.0;
			_cEW = (num2 + val2) / 2.0;
			_scale = (float)Math.Min((double)_lastAvail.X / ((val2 - num2) * 1.15), (double)_lastAvail.Y / ((val - num) * 1.15));
		}
		_follow = false;
		_first = false;
	}

	private static void Rebuild()
	{
		if (_marksVer == TravelData.Version && _marksPtVer == TravelData.PointsVersion && _marksRnd == TravelData.Random.Count && _marksView == _view)
		{
			return;
		}
		DropStrays();
		_marksVer = TravelData.Version;
		_marksPtVer = TravelData.PointsVersion;
		_marksRnd = TravelData.Random.Count;
		_marksView = _view;
		List<Mark> list = new List<Mark>();
		List<Loc> list2 = new List<Loc>();
		foreach (Loc loc in TravelData.Locs)
		{
			if (loc.Type == "Dungeon" && loc.Area < 0 && loc.At.Valid)
			{
				list2.Add(loc);
			}
		}
		foreach (Loc loc2 in TravelData.Locs)
		{
			if (loc2.Mine || loc2.Area >= 0 || !loc2.At.Valid)
			{
				continue;
			}
			if (loc2.Learned && loc2.Type != "Dungeon" && (loc2.HasExit || TravelData.IsPortalType(loc2.Type)))
			{
				bool flag = false;
				foreach (Loc item in list2)
				{
					if (item.At.DistanceTo(loc2.At) < 0.06 && (string.Equals(item.Name, loc2.Name, StringComparison.OrdinalIgnoreCase) || loc2.Name.StartsWith(item.Name, StringComparison.OrdinalIgnoreCase) || item.Name.StartsWith(loc2.Name, StringComparison.OrdinalIgnoreCase)))
					{
						flag = true;
						break;
					}
				}
				if (flag)
				{
					continue;
				}
			}
			if (!((_view.Length <= 0) ? (loc2.In.Length > 0) : (loc2.In != _view)))
			{
				list.Add(new Mark
				{
					Name = loc2.Name,
					Type = loc2.Type,
					Notes = loc2.Notes,
					At = loc2.At,
					Loc = loc2,
					Layer = LayerOf(loc2.Type, loc2.HasExit, loc2.Name, loc2.Notes),
					Random = TravelData.Random.Contains(loc2.Key)
				});
			}
		}
		foreach (TravelData.Point value in TravelData.Points.Values)
		{
			if (value.In == _view)
			{
				list.Add(new Mark
				{
					Name = value.Name,
					Type = value.Type,
					Notes = value.Notes,
					At = value.At,
					Point = value,
					Layer = ((!value.Auto) ? "My points" : LayerOf(value.Type, hasExit: false, value.Name, value.Notes)),
					Random = (value.Type == "Random portal")
				});
			}
		}
		list.Sort((Mark a, Mark b) => Rank(a).CompareTo(Rank(b)));
		_marks = list;
	}

	private static int Rank(Mark m)
	{
		switch (m.Layer)
		{
		case "NPCs":
		case "Vendors":
			return 0;
		case "Housing":
			return 1;
		case "Landmarks":
			return 1;
		case "Portals":
			return 2;
		case "Dungeons":
			return 3;
		case "Lifestones":
			return 4;
		case "My points":
			return 5;
		default:
			return 6;
		}
	}

	private static Vector4 ColorOf(Mark m)
	{
		if (m.Random)
		{
			return new Vector4(0.6f, 0.6f, 0.6f, 1f);
		}
		return m.Layer switch
		{
			"Towns" => new Vector4(1f, 0.85f, 0.2f, 1f), 
			"Housing" => new Vector4(0.8f, 0.6f, 0.35f, 1f), 
			"Portals" => new Vector4(0.85f, 0.35f, 1f, 1f), 
			"Dungeons" => new Vector4(0.95f, 0.25f, 0.2f, 1f), 
			"NPCs" => new Vector4(0.45f, 0.8f, 1f, 1f), 
			"Vendors" => new Vector4(0.3f, 1f, 0.75f, 1f), 
			"Lifestones" => new Vector4(0.3f, 0.95f, 1f, 1f), 
			"My points" => new Vector4(0.35f, 1f, 0.35f, 1f), 
			_ => new Vector4(0.95f, 0.95f, 0.95f, 1f), 
		};
	}

	private static float MinScale(Mark m)
	{
		switch (m.Layer)
		{
		case "Towns":
			return (!(m.Type == "Town")) ? 3f : 0f;
		case "Housing":
			return 8f;
		case "My points":
			return 0f;
		case "Lifestones":
		case "Dungeons":
			return 5f;
		case "Portals":
			return 5f;
		case "Landmarks":
			return 8f;
		default:
			return 20f;
		}
	}

	private static void MakeTiles()
	{
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Expected Obj, but got Unknown
		if (_texErr != null || (_tiles != null && _tilesMade >= _tiles.Length))
		{
			return;
		}
		Bitmap worldImage = WorldMap.WorldImage;
		if (worldImage == null)
		{
			return;
		}
		if (_tiles == null)
		{
			_tiles = new ManagedTexture[64];
			_tilesMade = 0;
		}
		Stopwatch stopwatch = Stopwatch.StartNew();
		try
		{
			while (_tilesMade < _tiles.Length && (_tilesMade == 0 || stopwatch.ElapsedMilliseconds < 6))
			{
				int num = _tilesMade % 8;
				int num2 = _tilesMade / 8;
				Bitmap val = worldImage.Clone(new Rectangle(num * 255, num2 * 255, 255, 255), (PixelFormat)2498570);
				try
				{
					_tiles[_tilesMade] = (ManagedTexture)Activator.CreateInstance(typeof(ManagedTexture), val);
				}
				finally
				{
					((IDisposable)val)?.Dispose();
				}
				_tilesMade++;
			}
		}
		catch (Exception ex)
		{
			_texErr = ex.Message;
			FreeTiles();
		}
	}

	private static void FreeTiles()
	{
		if (_tiles != null)
		{
			ManagedTexture[] tiles = _tiles;
			foreach (ManagedTexture val in tiles)
			{
				try
				{
					if (val != null)
					{
						val.Dispose();
					}
				}
				catch
				{
				}
			}
		}
		_tiles = null;
		_tilesMade = 0;
	}

	private static void Content()
	{
		//IL_07ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a47: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a4c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0898: Unknown result type (might be due to invalid IL or missing references)
		//IL_089d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0849: Unknown result type (might be due to invalid IL or missing references)
		//IL_084e: Unknown result type (might be due to invalid IL or missing references)
		//IL_17a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_17b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_178f: Unknown result type (might be due to invalid IL or missing references)
		MakeTiles();
		string text = ((DungeonView.CurrentLb < 0) ? Travel.HereGroup : "dungeon");
		if (_viewFor != text)
		{
			_viewFor = text;
			_viewPicked = false;
		}
		if (!_viewPicked)
		{
			_view = text;
		}
		if (_view == "dungeon" && DungeonView.CurrentLb < 0)
		{
			_view = Travel.HereGroup;
			_viewPicked = false;
		}
		if (_view != "dungeon")
		{
			Rebuild();
		}
		Coords coords = Travel.Here();
		bool flag = coords.Valid && Travel.HereArea() < 0;
		if (_first && flag)
		{
			_first = false;
			_cNS = coords.NS;
			_cEW = coords.EW;
			_scale = 12f;
		}
		if (_follow && flag)
		{
			_cNS = coords.NS;
			_cEW = coords.EW;
		}
		ImGui.SetNextItemWidth(170f);
		ImGui.InputTextWithHint("##wmsearch", "find a place...", ref _search, 80u);
		ImGui.SameLine();
		if (ImGui.Checkbox("Follow me##wmf", ref _follow) && _follow && flag)
		{
			_cNS = coords.NS;
			_cEW = coords.EW;
		}
		ImGui.SameLine();
		if (ImGui.SmallButton("-##wmz"))
		{
			_scale = Math.Max(1.2f, _scale / 1.4f);
		}
		ImGui.SameLine();
		if (ImGui.SmallButton("+##wmz2"))
		{
			_scale = Math.Min(4000f, _scale * 1.4f);
		}
		ImGui.SameLine();
		if (ImGui.SmallButton("World##wmall"))
		{
			_follow = false;
			_cNS = 0.0;
			_cEW = 0.0;
			_scale = 0f;
		}
		ImGui.SameLine();
		if (ImGui.SmallButton("Layers##wml"))
		{
			ImGui.OpenPopup("##wmlayers");
		}
		ImGui.SameLine();
		if (ImGui.SmallButton("Options##wmo"))
		{
			ImGui.OpenPopup("##wmopts");
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(150f);
		if (ImGui.BeginCombo("##wmview", ViewTitle(_view)))
		{
			List<string> list = new List<string>();
			list.Add("");
			list.Add("tier11+");
			List<string> list2 = list;
			if (DungeonView.CurrentLb >= 0)
			{
				list2.Add("dungeon");
			}
			foreach (string item2 in list2)
			{
				if (ImGui.Selectable(ViewTitle(item2) + "##wmv" + item2, item2 == _view))
				{
					_view = item2;
					_viewPicked = true;
					if (item2 == "tier11+")
					{
						ZoomTier();
					}
				}
			}
			ImGui.EndCombo();
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Which map: the world, Tou-Tou's tier 11+ copies (walled off, with their own NPCs and portals),\nor the dungeon you're in. It follows where you are until you pick one.");
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(80f);
		float num = Alpha * 100f;
		if (ImGui.SliderFloat("##wmalpha", ref num, 15f, 100f, "%.0f%%"))
		{
			Alpha = num / 100f;
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Opacity: the window and the map in it. Ctrl+click to type a number.");
		}
		if (ImGui.BeginPopup("##wmlayers"))
		{
			string[] layers = Layers;
			foreach (string text2 in layers)
			{
				bool flag2 = LayerOn(text2);
				if (ImGui.Checkbox(text2 + "##wmly" + text2, ref flag2))
				{
					SetLayer(text2, flag2);
				}
			}
			bool solidLayer = SolidLayer;
			if (ImGui.Checkbox("What auto travel steers round (zoomed in)##wmsol", ref solidLayer))
			{
				if (solidLayer)
				{
					TravelData.SetFlag("wm-solid");
				}
				else
				{
					TravelData.ClearFlag("wm-solid");
				}
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Close up, outdoors: the buildings, trees, rocks and fences auto travel goes round (red), from the game's files.\nZoom right in to see it.");
			}
			ImGui.EndPopup();
		}
		if (ImGui.BeginPopup("##wmopts"))
		{
			bool autoAddNpcs = AutoAddNpcs;
			if (ImGui.Checkbox("Add NPCs and vendors I see to the map##wmnpc", ref autoAddNpcs))
			{
				if (autoAddNpcs)
				{
					TravelData.SetFlag("wm-npcs");
				}
				else
				{
					TravelData.ClearFlag("wm-npcs");
				}
			}
			if (ImGui.Button("Import GoArrow's custom points##wmimp"))
			{
				try
				{
					string text3 = GoArrowFile();
					if (text3 == null)
					{
						_importMsg = "Couldn't find GoArrow's locations.xml (looked in ..\\..\\VirindiPlugins\\GoArrowVVSEdition and C:\\Games\\VirindiPlugins\\GoArrowVVSEdition).";
					}
					else
					{
						int num2 = TravelData.ImportGoArrow(text3) + TravelData.ImportGoArrow(null);
						_importMsg = num2 + " new point" + ((num2 != 1) ? "s" : "") + " from " + text3;
					}
				}
				catch (Exception ex)
				{
					_importMsg = "Couldn't read it: " + ex.Message;
				}
			}
			if (_importMsg.Length > 0)
			{
				Im.TextDisabled(_importMsg);
			}
			int num3 = 0;
			int num4 = 0;
			foreach (TravelData.Point value5 in TravelData.Points.Values)
			{
				if (value5.Auto)
				{
					num4++;
				}
				else
				{
					num3++;
				}
			}
			Im.TextDisabled(num3 + " of your points, " + num4 + " NPCs / vendors seen");
			ImGui.EndPopup();
		}
		if (_view == "dungeon")
		{
			ImGui.Separator();
			DungeonView.DrawEmbedded();
			return;
		}
		if (_search.Trim().Length >= 2)
		{
			string value = _search.Trim();
			int num5 = 0;
			ImGui.BeginChild("##wmres", new Vector2(0f, 90f), true);
			foreach (Mark mark in _marks)
			{
				if (mark.Name.IndexOf(value, StringComparison.OrdinalIgnoreCase) >= 0)
				{
					if (ImGui.Selectable(string.Concat(new object[7] { mark.Name, "  (", mark.Type, ")  ", mark.At, "##wmr", num5 })))
					{
						ShowAt(mark.At);
						_search = "";
					}
					if (++num5 >= 40)
					{
						break;
					}
				}
			}
			if (num5 == 0)
			{
				Im.TextDisabled("Nothing on the map called that.");
			}
			ImGui.EndChild();
		}
		Vector2 contentRegionAvail = ImGui.GetContentRegionAvail();
		contentRegionAvail.Y -= ImGui.GetTextLineHeightWithSpacing();
		if (contentRegionAvail.X < 60f || contentRegionAvail.Y < 60f)
		{
			return;
		}
		Vector2 cursorScreenPos = ImGui.GetCursorScreenPos();
		float num6 = Math.Min(contentRegionAvail.X, contentRegionAvail.Y) / 204f;
		if (_scale < num6)
		{
			_scale = num6;
		}
		_lastAvail = contentRegionAvail;
		if (_zoomTierPending)
		{
			_zoomTierPending = false;
			ZoomTier();
		}
		ImGui.InvisibleButton("##wmcanvas", contentRegionAvail);
		bool flag3 = ImGui.IsItemHovered();
		ImGuiIOPtr iO = ImGui.GetIO();
		Vector2 mousePos = iO.MousePos;
		Vector2 mid = new Vector2(cursorScreenPos.X + contentRegionAvail.X / 2f, cursorScreenPos.Y + contentRegionAvail.Y / 2f);
		if (flag3 && ImGui.IsMouseDragging((ImGuiMouseButton)0, 3f))
		{
			ImGuiIOPtr iO2 = ImGui.GetIO();
			Vector2 mouseDelta = iO2.MouseDelta;
			_cEW -= mouseDelta.X / _scale;
			_cNS += mouseDelta.Y / _scale;
			_follow = false;
		}
		if (flag3)
		{
			ImGuiIOPtr iO3 = ImGui.GetIO();
			float mouseWheel = iO3.MouseWheel;
			if (mouseWheel != 0f)
			{
				double num7 = _cEW + (double)((mousePos.X - mid.X) / _scale);
				double num8 = _cNS - (double)((mousePos.Y - mid.Y) / _scale);
				_scale = Math.Max(num6, Math.Min(4000f, _scale * ((!(mouseWheel > 0f)) ? 0.8f : 1.25f)));
				if (!_follow)
				{
					_cEW = num7 - (double)((mousePos.X - mid.X) / _scale);
					_cNS = num8 + (double)((mousePos.Y - mid.Y) / _scale);
				}
			}
		}
		_cEW = Math.Max(-102.0, Math.Min(102.0, _cEW));
		_cNS = Math.Max(-102.0, Math.Min(102.0, _cNS));
		double cEW = _cEW;
		double cNS = _cNS;
		float sc = _scale;
		Func<double, double, Vector2> S = (double ns, double ew) => new Vector2(mid.X + (float)((ew - cEW) * (double)sc), mid.Y - (float)((ns - cNS) * (double)sc));
		Coords coords2 = new Coords(cNS - (double)((mousePos.Y - mid.Y) / sc), cEW + (double)((mousePos.X - mid.X) / sc));
		ImDrawListPtr windowDrawList = ImGui.GetWindowDrawList();
		Spot spot = null;
		windowDrawList.PushClipRect(cursorScreenPos, new Vector2(cursorScreenPos.X + contentRegionAvail.X, cursorScreenPos.Y + contentRegionAvail.Y), true);
		ImGui.PushStyleVar((ImGuiStyleVar)0, Alpha);
		try
		{
			windowDrawList.AddRectFilled(cursorScreenPos, new Vector2(cursorScreenPos.X + contentRegionAvail.X, cursorScreenPos.Y + contentRegionAvail.Y), ImGui.GetColorU32(new Vector4(0.1f, 0.18f, 0.37f, 1f)));
			if (TexReady)
			{
				for (int num9 = 0; num9 < _tilesMade && num9 < _tiles.Length; num9++)
				{
					if (_tiles[num9] != null)
					{
						int num10 = num9 % 8;
						int num11 = num9 / 8;
						double arg = (double)(num10 * 255) / 10.0 - 101.95;
						double arg2 = (double)((num10 + 1) * 255) / 10.0 - 101.95;
						double arg3 = (double)(2040 - num11 * 255) / 10.0 - 101.95;
						double arg4 = (double)(2040 - (num11 + 1) * 255) / 10.0 - 101.95;
						windowDrawList.AddImage(_tiles[num9].TexturePtr, S(arg3, arg), S(arg4, arg2), new Vector2(0.0019607844f, 0.0019607844f), new Vector2(0.9980392f, 0.9980392f));
					}
				}
			}
			else
			{
				string text4;
				if (_texErr != null)
				{
					text4 = "Couldn't make the map's picture: " + _texErr;
				}
				else if (WorldMap.Error.Length > 0)
				{
					text4 = "Can't read the game's map: " + WorldMap.Error;
				}
				else if (WorldMap.RegionError.Length > 0)
				{
					text4 = "Can't read the game's map: " + WorldMap.RegionError;
				}
				else
				{
					text4 = ((WorldMap.WorldImageError.Length <= 0) ? "Drawing the map from the game's files (a few seconds)..." : ("Couldn't make the map's picture: " + WorldMap.WorldImageError));
				}
				windowDrawList.AddText(new Vector2(cursorScreenPos.X + 10f, cursorScreenPos.Y + 10f), ImGui.GetColorU32(new Vector4(1f, 1f, 1f, 1f)), text4);
			}
			bool flag4 = LayerOn("Labels");
			uint colorU = ImGui.GetColorU32(new Vector4(0f, 0f, 0f, 0.9f));
			List<Spot> list3 = new List<Spot>();
			Dictionary<long, List<Spot>> dictionary = new Dictionary<long, List<Spot>>();
			foreach (Mark mark2 in _marks)
			{
				if (!LayerOn(mark2.Layer) || sc < MinScale(mark2))
				{
					continue;
				}
				Vector2 p = S(mark2.At.NS, mark2.At.EW);
				if (p.X < cursorScreenPos.X - 20f || p.Y < cursorScreenPos.Y - 20f || p.X > cursorScreenPos.X + contentRegionAvail.X + 20f || p.Y > cursorScreenPos.Y + contentRegionAvail.Y + 20f)
				{
					continue;
				}
				int num12 = (int)Math.Floor(p.X / 9f);
				int num13 = (int)Math.Floor(p.Y / 9f);
				Spot spot2 = null;
				for (int num14 = -1; num14 <= 1; num14++)
				{
					if (spot2 != null)
					{
						break;
					}
					for (int num15 = -1; num15 <= 1; num15++)
					{
						if (spot2 != null)
						{
							break;
						}
						if (!dictionary.TryGetValue(((long)(num12 + num14) << 32) ^ (uint)(num13 + num15), out var value2))
						{
							continue;
						}
						foreach (Spot item3 in value2)
						{
							if (Math.Abs(item3.P.X - p.X) < 7f && Math.Abs(item3.P.Y - p.Y) < 7f)
							{
								spot2 = item3;
								break;
							}
						}
					}
				}
				if (spot2 != null)
				{
					spot2.Items.Add(mark2);
					continue;
				}
				Spot spot3 = new Spot();
				spot3.P = p;
				Spot spot4 = spot3;
				spot4.Items.Add(mark2);
				list3.Add(spot4);
				long key = ((long)num12 << 32) ^ (uint)num13;
				if (!dictionary.TryGetValue(key, out var value3))
				{
					value3 = (dictionary[key] = new List<Spot>());
				}
				value3.Add(spot4);
			}
			float num16 = 81f;
			foreach (Spot item4 in list3)
			{
				Mark top = item4.Top;
				Vector2 p2 = item4.P;
				uint colorU2 = ImGui.GetColorU32(ColorOf(top));
				float num17;
				if (top.Layer == "Towns")
				{
					num17 = 5f;
				}
				else if (top.Layer == "Housing")
				{
					num17 = 3f;
				}
				else
				{
					num17 = ((!(top.Layer == "NPCs") && !(top.Layer == "Vendors")) ? 3.5f : 2.5f);
				}
				switch (top.Layer)
				{
				case "Towns":
				case "Housing":
					windowDrawList.AddRectFilled(new Vector2(p2.X - num17, p2.Y - num17), new Vector2(p2.X + num17, p2.Y + num17), colorU2);
					windowDrawList.AddRect(new Vector2(p2.X - num17, p2.Y - num17), new Vector2(p2.X + num17, p2.Y + num17), colorU);
					break;
				case "Dungeons":
					windowDrawList.AddQuadFilled(new Vector2(p2.X, p2.Y - num17 - 1f), new Vector2(p2.X + num17 + 1f, p2.Y), new Vector2(p2.X, p2.Y + num17 + 1f), new Vector2(p2.X - num17 - 1f, p2.Y), colorU2);
					windowDrawList.AddQuad(new Vector2(p2.X, p2.Y - num17 - 1f), new Vector2(p2.X + num17 + 1f, p2.Y), new Vector2(p2.X, p2.Y + num17 + 1f), new Vector2(p2.X - num17 - 1f, p2.Y), colorU);
					break;
				case "My points":
					windowDrawList.AddTriangleFilled(new Vector2(p2.X, p2.Y - num17 - 2f), new Vector2(p2.X + num17 + 1f, p2.Y + num17), new Vector2(p2.X - num17 - 1f, p2.Y + num17), colorU2);
					windowDrawList.AddTriangle(new Vector2(p2.X, p2.Y - num17 - 2f), new Vector2(p2.X + num17 + 1f, p2.Y + num17), new Vector2(p2.X - num17 - 1f, p2.Y + num17), colorU);
					break;
				default:
					windowDrawList.AddCircleFilled(p2, num17, colorU2);
					windowDrawList.AddCircle(p2, num17, colorU);
					break;
				}
				if (item4.Items.Count > 1)
				{
					string text5 = item4.Items.Count.ToString();
					Vector2 vector = new Vector2(p2.X + num17 - 1f, p2.Y + num17 - 3f);
					Vector2 vector2 = ImGui.CalcTextSize(text5);
					windowDrawList.AddRectFilled(new Vector2(vector.X - 1f, vector.Y), new Vector2(vector.X + vector2.X + 1f, vector.Y + vector2.Y - 2f), ImGui.GetColorU32(new Vector4(0f, 0f, 0f, 0.75f)), 3f);
					windowDrawList.AddText(new Vector2(vector.X, vector.Y - 1f), ImGui.GetColorU32(new Vector4(1f, 1f, 1f, 1f)), text5);
				}
				else if (top.Random)
				{
					windowDrawList.AddText(new Vector2(p2.X + num17, p2.Y - num17 - 10f), colorU2, "?");
				}
				if (flag3)
				{
					float num18 = mousePos.X - p2.X;
					float num19 = mousePos.Y - p2.Y;
					float num20 = num18 * num18 + num19 * num19;
					if (num20 < num16)
					{
						num16 = num20;
						spot = item4;
					}
				}
			}
			if (flag4)
			{
				List<Spot> list5 = new List<Spot>(list3);
				list5.Sort((Spot x, Spot y) => Rank(y.Top).CompareTo(Rank(x.Top)));
				List<Vector4> list6 = new List<Vector4>();
				foreach (Spot item5 in list5)
				{
					Mark top2 = item5.Top;
					if (!((top2.Type == "Town") ? (sc >= 3f) : ((top2.Layer == "Towns") ? (sc >= 10f) : ((!(top2.Layer == "Housing")) ? (sc >= 60f) : (sc >= 40f)))))
					{
						continue;
					}
					string text6 = top2.Name + ((item5.Items.Count <= 1) ? "" : (" +" + (item5.Items.Count - 1)));
					Vector2 vector3 = ImGui.CalcTextSize(text6);
					Vector2 vector4 = new Vector2(item5.P.X + 8f, item5.P.Y - 7f);
					Vector4 item = new Vector4(vector4.X - 1f, vector4.Y, vector4.X + vector3.X + 1f, vector4.Y + vector3.Y);
					bool flag5 = false;
					foreach (Vector4 item6 in list6)
					{
						if (item.X < item6.Z && item.Z > item6.X && item.Y < item6.W && item.W > item6.Y)
						{
							flag5 = true;
							break;
						}
					}
					if (!flag5)
					{
						list6.Add(item);
						uint colorU3 = ImGui.GetColorU32(ColorOf(top2));
						windowDrawList.AddText(new Vector2(vector4.X + 1f, vector4.Y + 1f), colorU, text6);
						windowDrawList.AddText(vector4, colorU3, text6);
					}
				}
			}
			if (SolidLayer && flag)
			{
				DrawSolid(windowDrawList, S, mid, contentRegionAvail);
			}
			DrawRoute(windowDrawList, S, coords, flag);
			MapRoute.Draw(windowDrawList, (double pn, double pe, double pz) => S(pn, pe));
			if (_view.Length > 0 && TravelData.Bounds.TryGetValue(_view, out var value4) && value4.Runs.Count > 0)
			{
				uint colorU4 = ImGui.GetColorU32(new Vector4(1f, 0.45f, 0.1f, 0.95f));
				uint colorU5 = ImGui.GetColorU32(new Vector4(1f, 0.45f, 0.1f, 0.45f));
				foreach (List<Coords> run in value4.Runs)
				{
					for (int num21 = 1; num21 < run.Count; num21++)
					{
						windowDrawList.AddLine(S(run[num21 - 1].NS, run[num21 - 1].EW), S(run[num21].NS, run[num21].EW), colorU4, 3f);
					}
				}
			}
			List<Coords> recordTrail = Travel.RecordTrail;
			if (recordTrail != null && recordTrail.Count > 1)
			{
				uint colorU6 = ImGui.GetColorU32(new Vector4(1f, 1f, 0.2f, 1f));
				for (int num22 = 1; num22 < recordTrail.Count; num22++)
				{
					windowDrawList.AddLine(S(recordTrail[num22 - 1].NS, recordTrail[num22 - 1].EW), S(recordTrail[num22].NS, recordTrail[num22].EW), colorU6, 2f);
				}
			}
			if (_flash.Valid && (DateTime.Now - _flashAt).TotalSeconds < 6.0)
			{
				float num23 = (float)((DateTime.Now - _flashAt).TotalSeconds % 1.0);
				windowDrawList.AddCircle(S(_flash.NS, _flash.EW), 8f + num23 * 14f, ImGui.GetColorU32(new Vector4(1f, 1f, 0.3f, 1f - num23)), 24, 2.5f);
			}
			if (flag && Travel.HereGroup == _view)
			{
				Vector2 a = S(coords.NS, coords.EW);
				double num24 = 0.0;
				try
				{
					num24 = CoreManager.Current.Actions.Heading;
				}
				catch
				{
				}
				double num25 = num24 * Math.PI / 180.0;
				float sn = (float)Math.Sin(num25);
				float cs = (float)Math.Cos(num25);
				Func<float, float, Vector2> func = (float x, float y) => new Vector2(a.X + x * cs - y * sn, a.Y + x * sn + y * cs);
				windowDrawList.AddTriangleFilled(func(0f, -10f), func(-6f, 7f), func(6f, 7f), ImGui.GetColorU32(new Vector4(1f, 0.25f, 0.25f, 1f)));
				windowDrawList.AddTriangle(func(0f, -10f), func(-6f, 7f), func(6f, 7f), ImGui.GetColorU32(new Vector4(1f, 1f, 1f, 1f)), 1.5f);
			}
		}
		catch (Exception ex2)
		{
			Util.LogError(ex2);
		}
		finally
		{
			ImGui.PopStyleVar();
			windowDrawList.PopClipRect();
		}
		if (flag3 && spot != null && !ImGui.IsMouseDragging((ImGuiMouseButton)0))
		{
			if (spot.Items.Count == 1)
			{
				Im.SetTooltip(Tip(spot.Items[0]));
			}
			else
			{
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(spot.Items.Count + " places here (right-click to pick one):");
				List<Mark> list7 = new List<Mark>(spot.Items);
				list7.Sort((Mark x, Mark y) => Rank(y).CompareTo(Rank(x)));
				int num26 = 0;
				foreach (Mark item7 in list7)
				{
					if (++num26 > 15)
					{
						stringBuilder.Append("\n... and " + (list7.Count - 15) + " more");
						break;
					}
					stringBuilder.Append("\n  " + item7.Name + "  (" + item7.Type + ((!item7.Random) ? "" : ", random") + ")");
				}
				Im.SetTooltip(stringBuilder.ToString());
			}
		}
		if (flag3 && ImGui.IsMouseReleased((ImGuiMouseButton)1))
		{
			_menuItems = ((spot == null) ? new List<Mark>() : new List<Mark>(spot.Items));
			_menuItems.Sort((Mark x, Mark y) => Rank(y).CompareTo(Rank(x)));
			_menuAt = spot?.Top.At ?? new Coords(Math.Round(coords2.NS, 2), Math.Round(coords2.EW, 2));
			ImGui.OpenPopup("##wmmenu");
		}
		if (flag3 && spot != null && spot.Items.Count == 1 && ImGui.IsMouseDoubleClicked((ImGuiMouseButton)0))
		{
			Go(spot.Top.At, spot.Top.Name, 0);
		}
		Menu();
		EditPopup();
		string text7 = ((_view.Length <= 0) ? "" : (" (" + TravelData.GroupTitle(_view) + ")"));
		string text8 = ((Travel.HereInstance.Length <= 0) ? "" : (" (" + Travel.HereInstance + ")"));
		string? text9;
		if (flag3)
		{
			text9 = string.Concat(coords2, text7, (_view.Length <= 0 || TravelData.InsideBound(_view, coords2)) ? "" : " - outside the tier area");
		}
		else
		{
			text9 = ((!flag) ? "" : string.Concat("You: ", coords, text8));
		}
		Im.TextDisabled(text9 + "    drag to move, wheel to zoom, right-click for more");
	}

	private static void Go(Coords c, string name, int mode)
	{
		Travel.NextDestGroup = _view;
		Travel.GoTo(c, -1, name, mode);
	}

	private static string Tip(Mark m)
	{
		string text = m.Name + "  (" + m.Type + ((m.Point == null) ? "" : ((!m.Point.Auto) ? ", yours" : ", seen")) + ")\n" + m.At;
		if (m.Loc != null && !m.Loc.HasExit && m.Loc.Learned && m.Layer == "Portals")
		{
			text += "\ninto a dungeon - where it goes is learned the first time you use it";
		}
		if (m.Loc != null && m.Loc.HasExit)
		{
			string text2 = text;
			text = string.Concat(new object[5]
			{
				text2,
				"\nleads to ",
				m.Loc.Exit,
				TravelData.InstLabel(TravelData.Inst(m.Loc)),
				(m.Loc.ExitArea < 0) ? "" : (" (" + TravelData.AreaName(m.Loc.ExitArea) + ")")
			});
		}
		if (m.Random)
		{
			text += "\ngoes somewhere different each time";
		}
		if (m.Loc != null && TravelData.Moves(m.Loc.Name))
		{
			DateTime dateTime = TravelData.LastSeen(m.Loc);
			double num = ((!(dateTime == DateTime.MinValue)) ? (DateTime.UtcNow - dateTime).TotalMinutes : (-1.0));
			text = text + "\nturns up in different places - " + ((!(num < 0.0)) ? ("seen here " + ((!(num < 60.0)) ? ((num / 60.0).ToString("0.#") + " h") : ((int)num + " min")) + " ago") : "not seen yet") + ((!TravelData.MovesFresh(m.Loc)) ? " (routes don't use it)" : " (routes can use it)");
		}
		List<string> list = ((m.Loc == null) ? null : TravelData.ExitsOf(m.Loc.Key));
		if (list != null)
		{
			text += "\nplaces it has put you:";
			foreach (string item in list)
			{
				if (TravelData.ParseExit(item, out var c, out var area))
				{
					string text2 = text;
					text = string.Concat(new object[4]
					{
						text2,
						"\n   ",
						c,
						(area < 0) ? "" : (" (" + TravelData.AreaName(area) + ")")
					});
				}
			}
		}
		if (m.Loc != null && TravelData.Avoid.Contains(m.Loc.Key))
		{
			text += "\n(not used for routes)";
		}
		if (!string.IsNullOrEmpty(m.Notes))
		{
			text = text + "\n" + ((m.Notes.Length <= 300) ? m.Notes : (m.Notes.Substring(0, 300) + "..."));
		}
		return text;
	}

	private static void Menu()
	{
		if (!ImGui.BeginPopup("##wmmenu"))
		{
			return;
		}
		List<Mark> list = _menuItems ?? new List<Mark>();
		if (list.Count == 0)
		{
			Coords menuAt = _menuAt;
			Im.TextColored(TravelHud.Cyan, menuAt.ToString());
			ImGui.Separator();
			GoItems(menuAt, menuAt.ToString());
			ImGui.Separator();
			if (ImGui.MenuItem("Add a point here..."))
			{
				TravelData.Point point = new TravelData.Point();
				point.Name = "";
				point.Type = "Custom";
				point.At = menuAt;
				StartEdit(point, isNew: true);
			}
		}
		else if (list.Count == 1)
		{
			MarkItems(list[0]);
		}
		else
		{
			Im.TextColored(TravelHud.Cyan, list.Count + " places here");
			ImGui.Separator();
			for (int i = 0; i < list.Count && i < 40; i++)
			{
				Mark mark = list[i];
				ImGui.PushStyleColor((ImGuiCol)0, ColorOf(mark));
				bool flag = ImGui.BeginMenu(mark.Name + "  (" + mark.Type + ")##wmm" + i);
				ImGui.PopStyleColor();
				if (ImGui.IsItemHovered() && !flag)
				{
					Im.SetTooltip(Tip(mark));
				}
				if (flag)
				{
					MarkItems(mark);
					ImGui.EndMenu();
				}
			}
			ImGui.Separator();
			if (ImGui.MenuItem("Add a point here..."))
			{
				TravelData.Point point = new TravelData.Point();
				point.Name = "";
				point.Type = "Custom";
				point.At = _menuAt;
				StartEdit(point, isNew: true);
			}
		}
		ImGui.EndPopup();
	}

	private static void GoItems(Coords at, string name)
	{
		if (ImGui.MenuItem("Go here (route)"))
		{
			Go(at, name, 1);
		}
		if (ImGui.MenuItem("Just point the arrow here"))
		{
			Go(at, name, 2);
		}
		if (ImGui.MenuItem("Auto travel here"))
		{
			Go(at, name, 1);
			AutoTravel.Start();
		}
		if (ImGui.MenuItem("Put the coordinates in chat"))
		{
			Util.WriteToChat(name + ": " + Travel.Link(at.ToString()));
		}
		ImGui.Separator();
		double z = double.NaN;
		try
		{
			z = WorldMap.GroundZ(at);
		}
		catch
		{
		}
		MapRoute.MenuItems(at, z);
	}

	private static void MarkItems(Mark m)
	{
		Im.TextColored(ColorOf(m), m.Name);
		Im.TextDisabled(m.Type + "  " + m.At);
		ImGui.Separator();
		GoItems(m.At, m.Name);
		ImGui.Separator();
		if (m.Point != null)
		{
			if (ImGui.MenuItem("Change..."))
			{
				StartEdit(m.Point, isNew: false);
			}
			if (ImGui.MenuItem("Delete"))
			{
				TravelData.RemovePoint(m.Point);
			}
		}
		else if (ImGui.MenuItem("Copy to my points (to change it)..."))
		{
			TravelData.Point point = new TravelData.Point();
			point.Name = m.Name;
			point.Type = ((Array.IndexOf(Types, m.Type) < 0) ? "Custom" : m.Type);
			point.Notes = m.Notes ?? "";
			point.At = m.At;
			StartEdit(point, isNew: true);
		}
		if (m.Loc == null || !(m.Layer == "Portals"))
		{
			return;
		}
		bool flag = TravelData.Random.Contains(m.Loc.Key);
		if (ImGui.MenuItem("Random destination", "", flag))
		{
			TravelData.SetRandom(m.Loc.Key, !flag);
			if (Travel.Active)
			{
				Travel.Reroute(say: false);
			}
		}
		bool flag2 = !TravelData.Avoid.Contains(m.Loc.Key);
		if (ImGui.MenuItem("Use it for routes", "", flag2))
		{
			TravelData.SetAvoid(m.Loc.Key, flag2);
			if (Travel.Active)
			{
				Travel.Reroute(say: false);
			}
		}
	}

	private static void StartEdit(TravelData.Point p, bool isNew)
	{
		_edit = p;
		_editNew = isNew;
		_openEdit = true;
		_eName = p.Name;
		_eNotes = p.Notes ?? "";
		_eCoords = p.At.ToString();
		_eErr = "";
		_eType = Math.Max(0, Array.IndexOf(Types, p.Type));
		if (Array.IndexOf(Types, p.Type) < 0 && p.Type.Length > 0)
		{
			_eType = 0;
		}
	}

	private static void EditPopup()
	{
		if (_openEdit)
		{
			ImGui.OpenPopup("Map point##wmedit");
			_openEdit = false;
		}
		ImGui.SetNextWindowSize(new Vector2(360f, 0f), (ImGuiCond)8);
		if (!ImGui.BeginPopup("Map point##wmedit"))
		{
			return;
		}
		if (_edit == null)
		{
			ImGui.CloseCurrentPopup();
			ImGui.EndPopup();
			return;
		}
		Im.TextColored(TravelHud.Cyan, (!_editNew) ? "Change point" : "New point");
		ImGui.SetNextItemWidth(260f);
		ImGui.InputText("Name##wme", ref _eName, 120u);
		ImGui.SetNextItemWidth(260f);
		ImGui.Combo("Type##wme", ref _eType, Types, Types.Length);
		ImGui.SetNextItemWidth(260f);
		ImGui.InputText("Where##wme", ref _eCoords, 60u);
		ImGui.SameLine();
		if (ImGui.SmallButton("Here##wmeh"))
		{
			Coords coords = Travel.Here();
			if (coords.Valid)
			{
				_eCoords = coords.ToString();
			}
		}
		ImGui.InputTextMultiline("Notes##wme", ref _eNotes, 2000u, new Vector2(260f, 60f));
		if (_eErr.Length > 0)
		{
			Im.TextColored(TravelHud.Orange, _eErr);
		}
		if (ImGui.Button("Save##wme"))
		{
			Coords c;
			if (_eName.Trim().Length == 0)
			{
				_eErr = "It needs a name.";
			}
			else if (!Coords.TryParse(_eCoords, out c))
			{
				_eErr = "Coordinates like 12.3N, 45.6E";
			}
			else
			{
				if (!_editNew)
				{
					TravelData.RemovePoint(_edit);
				}
				TravelData.Point point = new TravelData.Point();
				point.Name = _eName.Trim();
				point.Type = Types[_eType];
				point.Notes = _eNotes.Trim();
				point.At = c;
				point.In = ((!_editNew) ? _edit.In : _view);
				TravelData.AddPoint(point);
				if (!LayerOn("My points"))
				{
					SetLayer("My points", on: true);
				}
				_edit = null;
				ImGui.CloseCurrentPopup();
			}
		}
		ImGui.SameLine();
		if (ImGui.Button("Cancel##wme"))
		{
			_edit = null;
			ImGui.CloseCurrentPopup();
		}
		ImGui.EndPopup();
	}

	private static string GoArrowFile()
	{
		List<string> list = new List<string>();
		try
		{
			list.Add(Path.GetFullPath(Path.Combine(Util.FullPath(""), "..\\..\\VirindiPlugins\\GoArrowVVSEdition\\locations.xml")));
		}
		catch
		{
		}
		list.Add("C:\\Games\\VirindiPlugins\\GoArrowVVSEdition\\locations.xml");
		list.Add("C:\\Games\\VirindiPlugins\\GoArrow\\locations.xml");
		foreach (string item in list)
		{
			if (File.Exists(item))
			{
				return item;
			}
		}
		return null;
	}

	private static void DrawSolid(ImDrawListPtr dl, Func<double, double, Vector2> S, Vector2 mid, Vector2 avail)
	{
		double num = (double)_scale / 240.0;
		if (num < 1.5)
		{
			return;
		}
		double num2 = 0.5;
		double num3 = Math.Min(80.0, (double)(avail.X / 2f) / num + 2.0);
		double num4 = Math.Min(80.0, (double)(avail.Y / 2f) / num + 2.0);
		double num5 = (_cEW + 101.95) * 240.0;
		double num6 = (_cNS + 101.95) * 240.0;
		uint colorU = ImGui.GetColorU32(new Vector4(1f, 0.15f, 0.1f, 0.45f));
		double num7 = Math.Floor((num5 - num3) / num2) * num2;
		double num8 = num5 + num3;
		double num9 = Math.Floor((num6 - num4) / num2) * num2;
		double num10 = num6 + num4;
		for (double num11 = num9; num11 < num10; num11 += num2)
		{
			double num12 = double.NaN;
			for (double num13 = num7; num13 <= num8 + num2; num13 += num2)
			{
				bool flag = num13 <= num8 && Obstacles.Blocked(num13 + num2 / 2.0, num11 + num2 / 2.0);
				if (flag && double.IsNaN(num12))
				{
					num12 = num13;
				}
				else if (!flag && !double.IsNaN(num12))
				{
					Vector2 vector = S((num11 + num2) / 240.0 - 101.95, num12 / 240.0 - 101.95);
					Vector2 vector2 = S(num11 / 240.0 - 101.95, num13 / 240.0 - 101.95);
					dl.AddRectFilled(new Vector2(Math.Min(vector.X, vector2.X), Math.Min(vector.Y, vector2.Y)), new Vector2(Math.Max(vector.X, vector2.X), Math.Max(vector.Y, vector2.Y)), colorU);
					num12 = double.NaN;
				}
			}
		}
		if (Obstacles.Error.Length > 0)
		{
			dl.AddText(new Vector2(mid.X - avail.X / 2f + 6f, mid.Y + avail.Y / 2f - 20f), ImGui.GetColorU32(new Vector4(1f, 0.5f, 0.4f, 1f)), "Things in the way: " + Obstacles.Error);
		}
	}

	private static void DrawRoute(ImDrawListPtr dl, Func<double, double, Vector2> S, Coords here, bool outside)
	{
		if (!Travel.Active)
		{
			return;
		}
		uint colorU = ImGui.GetColorU32(new Vector4(1f, 0.85f, 0.2f, 1f));
		uint colorU2 = ImGui.GetColorU32(new Vector4(0.85f, 0.45f, 1f, 1f));
		Route route = Travel.Route;
		if (Travel.ArrowOnly || route == null)
		{
			if (outside && Travel.DestAt.Valid)
			{
				dl.AddLine(S(here.NS, here.EW), S(Travel.DestAt.NS, Travel.DestAt.EW), colorU, 2f);
			}
		}
		else
		{
			Coords coords = ((!outside) ? Coords.None : here);
			for (int i = Math.Max(0, Travel.Step); i < route.Legs.Count; i++)
			{
				Leg leg = route.Legs[i];
				if (leg.Target.Valid && leg.TargetArea < 0)
				{
					if (coords.Valid)
					{
						dl.AddLine(S(coords.NS, coords.EW), S(leg.Target.NS, leg.Target.EW), colorU, 3f);
					}
					coords = leg.Target;
				}
				if (leg.Exit.Valid)
				{
					if (leg.ExitArea < 0)
					{
						dl.AddCircle(S(leg.Exit.NS, leg.Exit.EW), 6f, colorU2, 16, 2f);
						coords = leg.Exit;
					}
					else
					{
						coords = Coords.None;
					}
				}
			}
		}
		if (Travel.DestAt.Valid && Travel.DestArea < 0)
		{
			Vector2 vector = S(Travel.DestAt.NS, Travel.DestAt.EW);
			dl.AddCircle(vector, 8f, colorU, 20, 2.5f);
			dl.AddLine(new Vector2(vector.X - 11f, vector.Y), new Vector2(vector.X + 11f, vector.Y), colorU, 1.5f);
			dl.AddLine(new Vector2(vector.X, vector.Y - 11f), new Vector2(vector.X, vector.Y + 11f), colorU, 1.5f);
		}
	}
}
