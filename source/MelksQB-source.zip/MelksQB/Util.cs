﻿using Decal.Adapter;
using System;
using System.IO;
using System.Threading;
using System.Xml;

namespace MelksQuestTracker
{
	public static class Util
	{
        private static string mBasePath = null;

		public static void LogError(Exception ex)
		{
			try
			{
				using (StreamWriter writer = new StreamWriter(System.IO.Path.Combine(BasePath, Globals.PluginName + " errors.txt"), true))
				{
					writer.WriteLine("============================================================================");
					writer.WriteLine(DateTime.Now.ToString());
					writer.WriteLine("Error: " + ex.Message);
					writer.WriteLine("Source: " + ex.Source);
					writer.WriteLine("Stack: " + ex.StackTrace);
					if (ex.InnerException != null)
					{
						writer.WriteLine("Inner: " + ex.InnerException.Message);
						writer.WriteLine("Inner Stack: " + ex.InnerException.StackTrace);
					}
					writer.WriteLine("============================================================================");
					writer.WriteLine("");
					writer.Close();
				}
			}
			catch
			{
			}
		}

		public static void WriteToChat(string message)
		{
			try
			{
				Globals.Host.Actions.AddChatText("<{" + Globals.PluginName + "}>: " + message, 5);
			}
			catch (Exception ex) { LogError(ex); }
			ToPhone("<{" + Globals.PluginName + "}>: " + message, 5);
		}

		/// <summary>The line also goes to MelkTank (the phone's Chat page): the game never reports a plugin's own lines,
		/// so they're left in a queue in the AppDomain ("Melk.PluginChat") that MelkTank empties.</summary>
		public static void ToPhone(string text, int color)
		{
			try
			{
				System.Collections.Queue q;
				lock (AppDomain.CurrentDomain)
				{
					q = AppDomain.CurrentDomain.GetData("Melk.PluginChat") as System.Collections.Queue;
					if (q == null) { q = new System.Collections.Queue(); AppDomain.CurrentDomain.SetData("Melk.PluginChat", q); }
				}
				lock (q.SyncRoot) { q.Enqueue(new object[] { text, color }); while (q.Count > 300) q.Dequeue(); }
			}
			catch { }
		}

        public static string FullPath(string fileName)
		{
			return System.IO.Path.Combine(BasePath, fileName);
		}
        // ── Files shared by several game clients ──
        // A named mutex per file name (seen by every client in the same Wine prefix / Windows session): reading,
        // read-change-write and writing all hold it, so two clients never write over each other and nobody reads a
        // half-written file. Writes go to "name.tmp" first and are then copied over the file.
        public static void Locked(string path, Action a)
        {
            System.Threading.Mutex m = null;
            bool got = false;
            try
            {
                try
                {
                    m = new System.Threading.Mutex(false, "MelksPlugins_" + System.IO.Path.GetFileName(path));
                    try { got = m.WaitOne(5000); } catch (System.Threading.AbandonedMutexException) { got = true; }
                }
                catch { }
                a();
            }
            finally
            {
                if (got) { try { m.ReleaseMutex(); } catch { } }
                if (m != null) m.Close();
            }
        }

        public static T Locked<T>(string path, Func<T> f) { T r = default(T); Locked(path, () => { r = f(); }); return r; }

        public static void WriteShared(string path, string text)
        {
            Locked(path, () =>
            {
                string tmp = path + "." + System.Diagnostics.Process.GetCurrentProcess().Id + ".tmp";   // per client: two never share one
                System.IO.File.WriteAllText(tmp, text);
                for (int i = 0; ; i++)
                {
                    try { System.IO.File.Copy(tmp, path, true); break; }
                    catch (System.IO.IOException) { if (i >= 10) throw; System.Threading.Thread.Sleep(50); }
                }
                try { System.IO.File.Delete(tmp); } catch { }
            });
        }

        public static void AppendShared(string path, string text)
        {
            Locked(path, () =>
            {
                for (int i = 0; ; i++)
                {
                    try { System.IO.File.AppendAllText(path, text); break; }
                    catch (System.IO.IOException) { if (i >= 5) throw; System.Threading.Thread.Sleep(20); }
                }
            });
        }

        public static void LoadXml(XmlDocument doc, string path) { Locked(path, () => doc.Load(path)); }

        private class Utf8StringWriter : System.IO.StringWriter
        {
            public Utf8StringWriter(System.Text.StringBuilder sb) : base(sb) { }
            public override System.Text.Encoding Encoding { get { return new System.Text.UTF8Encoding(false); } }
        }

        public static void SaveXml(XmlDocument doc, string filePath)
        {
            XmlWriterSettings writerSettings = new XmlWriterSettings();
            writerSettings.Indent = true;
            writerSettings.IndentChars = "    ";
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            using (Utf8StringWriter sw = new Utf8StringWriter(sb))
            using (XmlWriter writer = XmlWriter.Create(sw, writerSettings)) doc.Save(writer);
            WriteShared(filePath, sb.ToString());
        }


        public static string BasePath
		{
			get
			{
				if (mBasePath == null)
				{
					mBasePath = System.Reflection.Assembly.GetExecutingAssembly().Location.ToString();
					mBasePath = System.IO.Path.GetDirectoryName(mBasePath) ?? "";
				}
				return mBasePath;
			}
			set
			{
				mBasePath = (value ?? "").TrimEnd('\\', '/');   // (ACGodot: Path.Combine adds the separator)
			}
		}

        internal static void Command(string command)
		{
			try
			{
				if (DispatchToPlugins(command)) return;   // a plugin took it (/goarrow ..., /ub ..., /vt ...)
				CoreManager.Current.Actions.InvokeChatParser(command);
			}
			catch (Exception ex) { WriteToChat($"Util Command Error: {ex}"); }
		}

        // Decal's own command dispatch - the way UtilityBelt sends a typed command to every plugin's CommandLineText
        // handler. InvokeChatParser alone skips them and goes straight to the game ("Unknown command: goarrow").
        [System.Runtime.InteropServices.DllImport("Decal.dll")]
        private static extern int DispatchOnChatCommand(ref IntPtr str, [System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.U4)] int target);
        private static bool _noDispatch;

        /// <summary>Offers a command to the loaded plugins as if typed. True when one of them took it.</summary>
        internal static bool DispatchToPlugins(string command)
        {
#if ACGODOT
            return !string.IsNullOrEmpty(command) && Decal.Adapter.CoreManager.Current.RaiseCommand(command);
#endif
            if (_noDispatch || string.IsNullOrEmpty(command)) return false;
            IntPtr bstr = System.Runtime.InteropServices.Marshal.StringToBSTR(command);
            try { return (DispatchOnChatCommand(ref bstr, 1) & 1) > 0; }
            catch (Exception ex) { _noDispatch = true; LogError(ex); return false; }
            finally { System.Runtime.InteropServices.Marshal.FreeBSTR(bstr); }
        }

        // System.Windows.Forms.Clipboard requires an STA thread. Decal's host process is not
        // guaranteed to be STA, so we spin up a short-lived STA thread just for the clipboard
        // call rather than assuming Clipboard.SetText will work from wherever we're called.
        /// <summary>Text waiting to go on the clipboard: set by the window on its next frame (ImGui's clipboard).
        /// The old Windows Forms way froze the game for 2 s under Wine and often failed.</summary>
        public static string PendingClipboard;

        public static bool SetClipboardText(string text)
        {
            PendingClipboard = text ?? "";
            return true;
        }

	}
    
}
