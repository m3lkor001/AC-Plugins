#!/bin/sh
# MelkTank Loot Editor: with the launcher's Python (it has PySide6) when it's there, else the system's
here="$(cd "$(dirname "$0")" && pwd)"
for py in "$here/../.venv/bin/python3" "$here/.venv/bin/python3" python3; do
  if command -v "$py" >/dev/null 2>&1; then exec "$py" "$here/loot_editor.py" "$@"; fi
done
echo "Python 3 not found" >&2; exit 1
