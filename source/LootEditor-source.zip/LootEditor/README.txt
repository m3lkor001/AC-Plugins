MelkTank Loot Editor
====================

MelkTank's in-game loot editor, out of the game: edits the .utl loot profiles MelkTank uses (same folder, same
fields, same file format). Save writes the file; Push saves and tells every running MelkTank to read it again (a
character that's hunting uses the changes straight away); Sync reads the file again from disk.

With accounts playing in both Asheron's Call (Decal) and ACGodot, a box at the top picks whose MelkTank's profiles
to edit - each has its own loot folder.

It reads the MelkTank launcher's settings (accounts, game folders) - set those up in the launcher first.


LINUX
-----
  Needs Python 3 with PySide6 (the launcher's .venv has it):  ./loot_editor.sh
  (or: python3 loot_editor.py)

WINDOWS
-------
  Needs Python 3.10 or newer (https://www.python.org/downloads/windows/ - tick "Add python.exe to PATH").
  Double-click "Loot Editor.bat": the first time it makes a .venv here with PySide6, psutil and Pillow, then starts
  the editor. (MelkTank Remote for Windows has it too: Start menu > MelkTank > MelkTank Loot Editor.)
