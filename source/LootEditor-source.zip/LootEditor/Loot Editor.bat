@echo off
rem MelkTank Loot Editor: a private Python here the first time (PySide6, psutil, Pillow), then the editor
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
  echo Setting up the Loot Editor (once, a few minutes)...
  py -3 -m venv .venv 2>nul || python -m venv .venv
  if not exist ".venv\Scripts\python.exe" (
    echo Python 3.10 or newer wasn't found: https://www.python.org/downloads/windows/ ^(tick "Add python.exe to PATH"^)
    pause
    exit /b 1
  )
  ".venv\Scripts\python.exe" -m pip install --quiet --upgrade pip
  ".venv\Scripts\python.exe" -m pip install --quiet PySide6 psutil pillow
)
start "" ".venv\Scripts\pythonw.exe" "%~dp0loot_editor.py"
