using System;
using System.Collections.Generic;
using AcDream.Core.Terrain;
using AcDream.Core.Textures;
using DatReaderWriter.DBObjs;
using DatReaderWriter.Enums;
using DatReaderWriter.Types;
using Godot;

namespace ACGodot.Terrain;

/// <summary>
/// The landscape's textures from the Region (0x13000000): one texture-array layer per terrain type, the alpha maps that
/// blend them (corner, side and road maps) as a second array, and how often each layer repeats across a 24 m cell.
/// Ported from OpenAC's TerrainAtlas (MIT) - the decoding rules are the same, the GPU side is Godot's.
/// </summary>
public sealed class TerrainTextures
{
    public const int MaxLayers = 36;

    public Texture2DArray Terrain { get; }
    public Texture2DArray Alpha { get; }
    public float[] Tiling { get; }
    public TerrainBlendingContext Blending { get; }
    public float[] HeightTable { get; }
    /// <summary>Each terrain type's average colour (its texture's mean, sRGB), for the distant landscape. Index: terrain type 0..31.</summary>
    public Color[] TypeColors { get; } = new Color[32];
    /// <summary>For each texture layer: 1 if it's water (terrain types 16-20), 0.5 for the deep sea (20), else 0 - for the water shading.</summary>
    public float[] WaterLayers { get; } = new float[MaxLayers];

    private TerrainTextures(Texture2DArray terrain, Texture2DArray alpha, float[] tiling, TerrainBlendingContext blending, float[] heights)
    {
        Terrain = terrain; Alpha = alpha; Tiling = tiling; Blending = blending; HeightTable = heights;
    }

    public static TerrainTextures Build(Dats dats)
    {
        Region region = dats.Portal<Region>(0x13000000u) ?? throw new InvalidOperationException("Region 0x13000000 is missing");
        float[] heights = region.LandDefs.LandHeightTable;
        TexMerge? texMerge = region.TerrainInfo?.LandSurfaces?.TexMerge;
        if (texMerge == null) throw new InvalidOperationException("the Region has no terrain textures");

        // ── terrain layers: one per terrain type ──
        var typeToLayer = new Dictionary<uint, byte>();
        var typeColors = new Color[32];
        var images = new List<Image>();
        var tiling = new float[MaxLayers];
        for (int i = 0; i < MaxLayers; i++) tiling[i] = 1f;
        int maxW = 1, maxH = 1;
        foreach (TMTerrainDesc desc in texMerge.TerrainDesc)
        {
            uint type = (uint)desc.TerrainType;
            if (typeToLayer.ContainsKey(type) || images.Count >= MaxLayers) continue;
            Image img = DecodeColour(dats, (uint)desc.TerrainTex.TextureId);
            typeToLayer[type] = (byte)images.Count;
            if (type < 32) typeColors[type] = Mean(img);
            tiling[images.Count] = desc.TerrainTex.TexTiling;
            images.Add(img);
            maxW = Math.Max(maxW, img.GetWidth());
            maxH = Math.Max(maxH, img.GetHeight());
        }
        foreach (Image img in images)
        {
            if (img.GetWidth() != maxW || img.GetHeight() != maxH) img.Resize(maxW, maxH, Image.Interpolation.Bilinear);
            img.GenerateMipmaps();
        }
        var terrain = new Texture2DArray();
        terrain.CreateFromImages(new Godot.Collections.Array<Image>(images));

        // ── alpha maps: corner, side and road ──
        var alphaImages = new List<Image>();
        var corner = new List<byte>(); var side = new List<byte>(); var road = new List<byte>();
        var cornerT = new List<uint>(); var sideT = new List<uint>(); var roadR = new List<uint>();
        foreach (TerrainAlphaMap e in texMerge.CornerTerrainMaps)
            if (DecodeAlpha(dats, (uint)e.TextureId) is { } a) { corner.Add((byte)alphaImages.Count); cornerT.Add(e.TCode); alphaImages.Add(a); }
        foreach (TerrainAlphaMap e in texMerge.SideTerrainMaps)
            if (DecodeAlpha(dats, (uint)e.TextureId) is { } a) { side.Add((byte)alphaImages.Count); sideT.Add(e.TCode); alphaImages.Add(a); }
        foreach (RoadAlphaMap e in texMerge.RoadMaps)
            if (DecodeAlpha(dats, (uint)e.TextureId) is { } a) { road.Add((byte)alphaImages.Count); roadR.Add(e.RCode); alphaImages.Add(a); }
        if (alphaImages.Count == 0) alphaImages.Add(Image.CreateFromData(1, 1, false, Image.Format.L8, new byte[] { 255 }));
        int aw = 1, ah = 1;
        foreach (Image a in alphaImages) { aw = Math.Max(aw, a.GetWidth()); ah = Math.Max(ah, a.GetHeight()); }
        foreach (Image a in alphaImages) if (a.GetWidth() != aw || a.GetHeight() != ah) a.Resize(aw, ah, Image.Interpolation.Nearest);
        var alpha = new Texture2DArray();
        alpha.CreateFromImages(new Godot.Collections.Array<Image>(alphaImages));

        const uint RoadType = 0x20;
        var blending = new TerrainBlendingContext(
            TerrainTypeToLayer: typeToLayer,
            RoadLayer: typeToLayer.TryGetValue(RoadType, out byte rl) ? rl : SurfaceInfo.None,
            CornerAlphaLayers: corner, SideAlphaLayers: side, RoadAlphaLayers: road,
            CornerAlphaTCodes: cornerT, SideAlphaTCodes: sideT, RoadAlphaRCodes: roadR);

        GD.Print($"Terrain: {images.Count} layers at {maxW}x{maxH}, {alphaImages.Count} alpha maps at {aw}x{ah} " +
                 $"(corners {corner.Count}, sides {side.Count}, roads {road.Count})");
        var made = new TerrainTextures(terrain, alpha, tiling, blending, heights);
        Color fallback = new(0.35f, 0.42f, 0.25f);
        for (int i = 0; i < 32; i++) made.TypeColors[i] = typeColors[i].A > 0f ? typeColors[i] : fallback;
        foreach (var kv in typeToLayer)
            if (kv.Key >= 16 && kv.Key <= 20 && kv.Value < MaxLayers) made.WaterLayers[kv.Value] = kv.Key == 20 ? 0.5f : 1f;
        return made;
    }

    /// <summary>An image's average colour (sRGB, as stored).</summary>
    private static Color Mean(Image img)
    {
        byte[] d = img.GetData();
        if (img.GetFormat() != Image.Format.Rgba8 || d.Length < 4) return new Color(0, 0, 0, 0);
        double r = 0, g = 0, b = 0; long n = 0;
        for (int i = 0; i + 3 < d.Length; i += 16) { r += d[i]; g += d[i + 1]; b += d[i + 2]; n++; }
        return n == 0 ? new Color(0, 0, 0, 0) : new Color((float)(r / n / 255.0), (float)(g / n / 255.0), (float)(b / n / 255.0), 1f);
    }

    /// <summary>A SurfaceTexture's first RenderSurface as an RGBA image (magenta when it can't be read).</summary>
    private static Image DecodeColour(Dats dats, uint surfaceTextureId)
    {
        DecodedTexture d = DecodedTexture.Magenta;
        SurfaceTexture? st = dats.Portal<SurfaceTexture>(surfaceTextureId);
        if (st != null && st.Textures.Count > 0)
        {
            RenderSurface? rs = dats.Portal<RenderSurface>((uint)st.Textures[0]);
            if (rs != null)
            {
                Palette? pal = rs.DefaultPaletteId != 0 ? dats.Portal<Palette>(rs.DefaultPaletteId) : null;
                d = SurfaceDecoder.DecodeRenderSurface(rs, pal);
            }
        }
        if (ReferenceEquals(d, DecodedTexture.Magenta)) GD.PushWarning($"terrain texture 0x{surfaceTextureId:X8} couldn't be decoded");
        return Image.CreateFromData(d.Width, d.Height, false, Image.Format.Rgba8, d.Rgba8);
    }

    /// <summary>An alpha (blend weight) map: one byte per texel.</summary>
    private static Image? DecodeAlpha(Dats dats, uint surfaceTextureId)
    {
        SurfaceTexture? st = dats.Portal<SurfaceTexture>(surfaceTextureId);
        if (st == null || st.Textures.Count == 0) return null;
        RenderSurface? rs = dats.Portal<RenderSurface>((uint)st.Textures[0]);
        if (rs == null || rs.Width <= 0 || rs.Height <= 0) return null;
        int n = rs.Width * rs.Height;
        byte[] w;
        if ((rs.Format == PixelFormat.PFID_A8 || rs.Format == PixelFormat.PFID_CUSTOM_LSCAPE_ALPHA) && rs.SourceData != null && rs.SourceData.Length >= n)
        {
            w = new byte[n];
            Array.Copy(rs.SourceData, w, n);
        }
        else
        {
            DecodedTexture d = SurfaceDecoder.DecodeRenderSurface(rs, palette: null, isClipMap: false, isAdditive: true);
            if (ReferenceEquals(d, DecodedTexture.Magenta)) return null;
            w = new byte[d.Width * d.Height];
            for (int i = 0; i < w.Length; i++) w[i] = d.Rgba8[i * 4 + 3];
            return Image.CreateFromData(d.Width, d.Height, false, Image.Format.L8, w);
        }
        return Image.CreateFromData(rs.Width, rs.Height, false, Image.Format.L8, w);
    }
}
