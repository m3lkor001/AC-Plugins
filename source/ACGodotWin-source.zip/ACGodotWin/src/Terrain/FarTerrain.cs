using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading.Tasks;
using ACGodot.UI;
using DatReaderWriter.DBObjs;
using Godot;

namespace ACGodot.Terrain;

/// <summary>
/// The distant landscape (Options > Video: lighting and effects): past the detailed landscape, out to FarLand landblocks,
/// a simple version of the land - every other height point (48 m apart), each coloured by its terrain type's average
/// colour and lit by the sun - so hills and coasts show on the horizon instead of nothing. Past the world's edge, sea.
/// Built in 8 x 8-landblock pieces on worker threads; a piece is made again when what it should hold changes (you've
/// moved and the detailed landscape now covers more or less of it).
/// </summary>
public partial class FarTerrain : Node3D
{
    private const int Chunk = 8;          // landblocks a piece is wide
    private const int Step = 2;           // every other height point
    private const int OceanType = 20;     // WaterDeepSea

    private Dats _dats = null!;
    private TerrainTextures _tex = null!;
    private StandardMaterial3D _mat = null!;
    private readonly Dictionary<(int, int), (MeshInstance3D? mi, ulong sig)> _chunks = new();
    private readonly ConcurrentDictionary<(int, int), ulong> _inFlight = new();
    private readonly ConcurrentQueue<((int, int) key, ulong sig, Godot.Collections.Array? arrays)> _ready = new();
    private (int, int) _center = (int.MinValue, 0);
    private int _near = -1, _far = -1;
    private bool _ocean;

    /// <summary>The detailed landscape's radius (landblocks each way): the distant land starts past it.</summary>
    public int Near { get; set; } = 5;

    public void Setup(Dats dats, TerrainTextures tex)
    {
        _dats = dats; _tex = tex;
        _mat = new StandardMaterial3D
        {
            VertexColorUseAsAlbedo = true, VertexColorIsSrgb = true, Roughness = 1f, Metallic = 0f, MetallicSpecular = 0f,
            CullMode = BaseMaterial3D.CullModeEnum.Disabled,
        };
    }

    private int FarRadius => Math.Max(Video.FarLand, 0);
    private int OceanRadius => Video.Ocean ? Math.Max(FarRadius, Near + 3) : 0;

    /// <summary>Call each frame with the camera's position.</summary>
    public void Follow(Vector3 godotPos)
    {
        if (_dats == null) return;
        var c = World.LandblockAt(godotPos);
        if (c != _center || Near != _near || Video.FarLand != _far || Video.Ocean != _ocean)
        {
            _center = c; _near = Near; _far = Video.FarLand; _ocean = Video.Ocean;
            Refresh();
        }
        for (int i = 0; i < 4 && _ready.TryDequeue(out var r); i++)
        {
            if (_inFlight.TryGetValue(r.key, out ulong want) && want == r.sig) _inFlight.TryRemove(r.key, out _);
            if (!_chunks.TryGetValue(r.key, out var have) || have.sig != r.sig) continue;   // wanted something else since
            have.mi?.QueueFree();
            MeshInstance3D? mi = null;
            if (r.arrays != null)
            {
                var mesh = new ArrayMesh();
                mesh.AddSurfaceFromArrays(Mesh.PrimitiveType.Triangles, r.arrays);
                mesh.SurfaceSetMaterial(0, _mat);
                mi = new MeshInstance3D { Mesh = mesh, CastShadow = GeometryInstance3D.ShadowCastingSetting.Off, Name = $"Far_{r.key.Item1}_{r.key.Item2}" };
                AddChild(mi);
            }
            _chunks[r.key] = (mi, r.sig);
        }
    }

    /// <summary>Whether a landblock is drawn here: land past the detailed landscape, sea past the world's edge.</summary>
    private bool Wanted(int x, int y)
    {
        int d = Math.Max(Math.Abs(x - _center.Item1), Math.Abs(y - _center.Item2));
        bool inWorld = x >= 0 && y >= 0 && x <= 254 && y <= 254;
        if (!inWorld) return d <= OceanRadius;
        return d > Near && d <= FarRadius;
    }

    private void Refresh()
    {
        int reach = Math.Max(FarRadius, OceanRadius);
        var want = new Dictionary<(int, int), ulong>();
        if (reach > 0)
        {
            int c0x = FloorDiv(_center.Item1 - reach, Chunk), c1x = FloorDiv(_center.Item1 + reach, Chunk);
            int c0y = FloorDiv(_center.Item2 - reach, Chunk), c1y = FloorDiv(_center.Item2 + reach, Chunk);
            for (int cx = c0x; cx <= c1x; cx++)
                for (int cy = c0y; cy <= c1y; cy++)
                {
                    ulong sig = 0;
                    for (int i = 0; i < Chunk * Chunk; i++)
                        if (Wanted(cx * Chunk + i % Chunk, cy * Chunk + i / Chunk)) sig |= 1UL << i;
                    if (sig != 0) want[(cx, cy)] = sig;
                }
        }
        // gone: pieces with nothing left to show
        var drop = new List<(int, int)>();
        foreach (var kv in _chunks) if (!want.ContainsKey(kv.Key)) drop.Add(kv.Key);
        foreach (var k in drop) { _chunks[k].mi?.QueueFree(); _chunks.Remove(k); _inFlight.TryRemove(k, out _); }
        // new or changed: made again (the old piece stays until the new one is ready)
        foreach (var kv in want)
        {
            if (_chunks.TryGetValue(kv.Key, out var have) && have.sig == kv.Value) continue;
            _chunks[kv.Key] = (have.mi, kv.Value);
            _inFlight[kv.Key] = kv.Value;
            var key = kv.Key; ulong sig = kv.Value;
            Task.Run(() =>
            {
                Godot.Collections.Array? arrays = null;
                try { arrays = Build(key, sig); }
                catch (Exception ex) { GD.PushWarning($"distant landscape {key}: {ex.Message}"); }
                _ready.Enqueue((key, sig, arrays));
            });
        }
    }

    private static int FloorDiv(int a, int b) => (int)Math.Floor(a / (double)b);

    /// <summary>One piece's triangles (any thread): each landblock it holds, as a 5 x 5 grid of points.</summary>
    private Godot.Collections.Array? Build((int, int) key, ulong sig)
    {
        var pos = new List<Vector3>();
        var nrm = new List<Vector3>();
        var col = new List<Color>();
        var idx = new List<int>();
        const int N = 8 / Step + 1;   // points a side
        var h = new float[N, N];
        var t = new int[N, N];
        for (int i = 0; i < Chunk * Chunk; i++)
        {
            if ((sig & (1UL << i)) == 0) continue;
            int lx = key.Item1 * Chunk + i % Chunk, ly = key.Item2 * Chunk + i / Chunk;
            bool inWorld = lx >= 0 && ly >= 0 && lx <= 254 && ly <= 254;
            LandBlock? block = inWorld ? _dats.Cell<LandBlock>(((uint)lx << 24) | ((uint)ly << 16) | 0xFFFFu) : null;
            for (int gx = 0; gx < N; gx++)
                for (int gy = 0; gy < N; gy++)
                {
                    if (block == null) { h[gx, gy] = 0f; t[gx, gy] = OceanType; continue; }
                    int k = gx * Step * 9 + gy * Step;
                    h[gx, gy] = _tex.HeightTable[block.Height[k]];
                    t[gx, gy] = ((ushort)block.Terrain[k] >> 2) & 0x1F;
                }
            int baseIndex = pos.Count;
            float cell = 24f * Step;
            for (int gx = 0; gx < N; gx++)
                for (int gy = 0; gy < N; gy++)
                {
                    float ax = lx * 192f + gx * cell, ay = ly * 192f + gy * cell;
                    pos.Add(World.ToGodot(ax, ay, h[gx, gy]));
                    // the slope from the neighbours (one-sided at the edges)
                    float dzx = (h[Math.Min(gx + 1, N - 1), gy] - h[Math.Max(gx - 1, 0), gy]) / (cell * (Math.Min(gx + 1, N - 1) - Math.Max(gx - 1, 0)));
                    float dzy = (h[gx, Math.Min(gy + 1, N - 1)] - h[gx, Math.Max(gy - 1, 0)]) / (cell * (Math.Min(gy + 1, N - 1) - Math.Max(gy - 1, 0)));
                    var n = new System.Numerics.Vector3(-dzx, -dzy, 1f);
                    nrm.Add(World.ToGodot(System.Numerics.Vector3.Normalize(n)));
                    col.Add(_tex.TypeColors[t[gx, gy]]);
                }
            for (int gx = 0; gx < N - 1; gx++)
                for (int gy = 0; gy < N - 1; gy++)
                {
                    int a = baseIndex + gx * N + gy, b = a + N, c = b + 1, d = a + 1;
                    // (AC's ground winds counter-clockwise seen from above; Godot's front faces are clockwise)
                    idx.Add(a); idx.Add(c); idx.Add(b);
                    idx.Add(a); idx.Add(d); idx.Add(c);
                }
        }
        if (idx.Count == 0) return null;
        var arrays = new Godot.Collections.Array();
        arrays.Resize((int)Mesh.ArrayType.Max);
        arrays[(int)Mesh.ArrayType.Vertex] = pos.ToArray();
        arrays[(int)Mesh.ArrayType.Normal] = nrm.ToArray();
        arrays[(int)Mesh.ArrayType.Color] = col.ToArray();
        arrays[(int)Mesh.ArrayType.Index] = idx.ToArray();
        return arrays;
    }
}
