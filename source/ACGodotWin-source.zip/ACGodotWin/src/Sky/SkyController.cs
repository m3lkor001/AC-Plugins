using System;
using System.Collections.Generic;
using System.Linq;
using ACGodot.Objects;
using AcDream.Core.Meshing;
using AcDream.Core.World;
using DatReaderWriter.DBObjs;
using Godot;

namespace ACGodot.Sky;

/// <summary>
/// Dereth's day and night, from the region's sky description (OpenAC's SkyDescLoader reads it): the time of day
/// picks a lighting keyframe - the sun's direction and colour, the ambient light, the fog - and the sky objects
/// (dome, sun, moons, clouds, stars) that are up, each turned along its arc. The sky objects are drawn around the
/// camera, far out, behind everything else.
///
/// The clock: a Dereth day is 7620 seconds. With no server to ask, the time comes from the computer's clock,
/// lined up with the game (a reading of "day in 11 minutes" on InfiniteLeaftide). [ and ] move it an hour.
/// </summary>
public partial class SkyController : Node3D
{
    // When a Dereth day began (Dawnsong, a quarter through the day), as Unix time - seen on InfiniteLeaftide.
    private const double RefUnix = 1794702748.0;
    private const double RefFraction = 0.25;
    private const float SkyRadius = 3000f;   // inside the camera's far plane (4000), beyond any landscape drawn
    // AC lights in its own (display) colour space; Godot's lighting comes out a little darker - lifted to match
    private const float LightScale = 1.25f;

    private Dats _dats = null!;
    private ObjectAssets _assets = null!;
    private DirectionalLight3D _sun = null!;
    private Godot.Environment _env = null!;
    private LoadedSkyDesc? _desc;
    private DayGroupData? _group;
    private SkyStateProvider? _provider;
    private double _shiftSeconds;
    private float _scale = 1f;
    private readonly Shader _mix = GD.Load<Shader>("res://shaders/sky_mix.gdshader");
    private readonly Shader _add = GD.Load<Shader>("res://shaders/sky_add.gdshader");
    private readonly Shader _mixClamp = GD.Load<Shader>("res://shaders/sky_mix_clamp.gdshader");
    private readonly Shader _addClamp = GD.Load<Shader>("res://shaders/sky_add_clamp.gdshader");
    // weather (rain, snow, mist) as retail draws it: after the world and over it (no depth test), only the sides of
    // its shell that face the camera - not both sides overlapping, which showed as moving planes and lines
    private readonly Dictionary<Shader, Shader> _weatherShaders = new();
    private Shader WeatherShader(Shader sky)
    {
        if (_weatherShaders.TryGetValue(sky, out var w)) return w;
        string code = sky.Code.Replace("cull_disabled", "cull_back").Replace("depth_draw_never", "depth_draw_never, depth_test_disabled");
        // ...but not over the inside of a building: where what's behind it (the depth drawn there) is in one of the
        // rooms near the camera, it isn't drawn - from inside you see it out of the door, from outside not in it
        code = code.Replace("varying vec3 tint;", RoomMaskUniforms + "varying vec3 tint;");
        int f = code.IndexOf("void fragment() {", StringComparison.Ordinal);
        code = code.Insert(f + "void fragment() {".Length, RoomMaskCode);
        return _weatherShaders[sky] = new Shader { Code = code };
    }
    public const int MaxRooms = 24;
    private const string RoomMaskUniforms = @"
uniform sampler2D depth_tex : hint_depth_texture, filter_nearest;
uniform int room_count = 0;
uniform vec3 room_min[24];
uniform vec3 room_max[24];
";
    private const string RoomMaskCode = @"
	if (room_count > 0) {
		float dz = texture(depth_tex, SCREEN_UV).r;
		if (dz < 0.99999) {
			vec4 v = INV_PROJECTION_MATRIX * vec4(vec3(SCREEN_UV, dz) * 2.0 - 1.0, 1.0);
			vec3 wp = (INV_VIEW_MATRIX * vec4(v.xyz / v.w, 1.0)).xyz;
			for (int i = 0; i < room_count; i++)
				if (all(greaterThan(wp, room_min[i])) && all(lessThan(wp, room_max[i]))) discard;
		}
	}
";

    /// <summary>The rooms near the camera (buildings' insides, slightly grown so their walls count): no weather over them.</summary>
    public void SetRooms(IReadOnlyList<Aabb> rooms)
    {
        int n = Math.Min(rooms.Count, MaxRooms);
        var mins = new Vector3[MaxRooms]; var maxs = new Vector3[MaxRooms];
        for (int i = 0; i < n; i++) { mins[i] = rooms[i].Position - new Vector3(0.1f, 0.1f, 0.1f); maxs[i] = rooms[i].End + new Vector3(0.1f, 0.1f, 0.1f); }
        foreach (var l in _layers)
        {
            if (!Weather(l.Obj)) continue;
            foreach (var m in l.Models.Values)
                foreach (var (mat, _, _) in m.mats)
                {
                    mat.SetShaderParameter("room_count", n);
                    mat.SetShaderParameter("room_min", mins);
                    mat.SetShaderParameter("room_max", maxs);
                }
        }
    }

    private readonly System.Diagnostics.Stopwatch _clock = System.Diagnostics.Stopwatch.StartNew();

    /// <summary>One sky object's drawn models: its own and any a keyframe swaps in, each with its materials.</summary>
    private sealed class Layer
    {
        public SkyObjectData Obj = null!;
        public readonly Dictionary<uint, (MeshInstance3D node, List<(ShaderMaterial mat, float lum, float diffuse)> mats)> Models = new();
    }
    private readonly List<Layer> _layers = new();
    private int _hidden = -1;   // a layer hidden to see which it is (L), or -1

    /// <summary>Hides the next sky layer that's up (L); after the last, none. Says which it is.</summary>
    public string StepHidden()
    {
        float t = _lastT;
        for (int i = _hidden + 1; i < _layers.Count; i++)
        {
            var o = _layers[i].Obj;
            if (!o.IsVisible(t)) continue;
            _hidden = i;
            return $"sky layer {i} of {_layers.Count} hidden (L: next): model 0x{o.GfxObjId:X8}, properties 0x{o.Properties:X}" +
                   (o.PesObjectId != 0 ? $", effects 0x{o.PesObjectId:X8}" : "") + (Weather(o) ? ", weather" : "") +
                   $", time {o.BeginTime:0.00}-{o.EndTime:0.00}, angle {o.BeginAngle:0}-{o.EndAngle:0}";
        }
        _hidden = -1;
        return "all sky layers shown (L)";
    }
    private float _lastT;

    public string Text { get; private set; } = "";

    /// <summary>Where sky layers' particle scripts (rain, snow) run, around the camera.</summary>
    public ACGodot.Effects.ParticleWorld? Particles { get; set; }
    private readonly Dictionary<int, uint> _pes = new();   // layer index -> its effects' id

    public void Setup(Dats dats, ObjectAssets assets, DirectionalLight3D sun, Godot.Environment env)
    {
        _dats = dats; _assets = assets; _sun = sun; _env = env;
        try { _desc = SkyDescLoader.LoadFromDat(dats); }
        catch (Exception ex) { GD.PushWarning("sky: " + ex.Message); }
        if (_desc == null) GD.PushWarning("sky: the region has no sky description - a fixed light is used");
        _env.BackgroundMode = Godot.Environment.BGMode.Color;
        _env.AmbientLightSource = Godot.Environment.AmbientSource.Color;
        _env.FogMode = Godot.Environment.FogModeEnum.Depth;
        _env.FogDensity = 1f;
        _env.FogDepthCurve = 1f;
        _env.FogSkyAffect = 0f;
        _env.TonemapMode = Godot.Environment.ToneMapper.Linear;
    }

    /// <summary>Moves the clock by whole Dereth hours ([ and ]).</summary>
    public void ShiftHours(int hours) => _shiftSeconds += hours * DerethDateTime.HourTicks;

    private double Ticks()
    {
        double now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() / 1000.0 + _shiftSeconds;
        // ticks whose day fraction matches the reference: DayFraction(t) = (t + origin) mod day / day
        double baseTicks = RefFraction * DerethDateTime.DayTicks - DerethDateTime.OriginOffsetTicks + 4000 * DerethDateTime.DayTicks;
        return baseTicks + (now - RefUnix);
    }

    /// <summary>Each frame: the light, fog and sky for now, around the camera. Underground there's no sky.</summary>
    /// <summary>The camera inside a building: the weather's falling particles stop (its sheets are kept off the rooms by SetRooms).</summary>
    public bool Indoors;
    /// <summary>The character option "Disable Most Weather Effects": no rain, snow or mist (their particles or sheets).</summary>
    public bool NoWeather;
    /// <summary>The sun's brightness now (0 night .. 1 full day), for the lamps (Effects.Lamps).</summary>
    public float Daylight { get; private set; } = 1f;

    public void Update(Vector3 cam, bool underground)
    {
        Position = cam;
        Visible = !underground;
        double ticks = Ticks();
        float t = (float)DerethDateTime.DayFraction(ticks);
        var hour = DerethDateTime.CurrentHour(ticks);

        if (_desc != null)
        {
            var group = _desc.ActiveDayGroup(ticks) ?? _desc.DefaultDayGroup;
            if (group != _group) UseGroup(group);
        }
        SkyKeyframe kf = (_provider ?? SkyStateProvider.Default()).Interpolate(t);

        // the sun: AC's light vector (x east, y north, z up) - Godot's light shines along its -Z
        var sv = SkyStateProvider.SunDirectionFromKeyframe(kf);
        Vector3 toSun = new Vector3(sv.X, sv.Z, -sv.Y).Normalized();
        Vector3 up = Math.Abs(toSun.Y) > 0.99f ? Vector3.Forward : Vector3.Up;
        _sun.Basis = Basis.LookingAt(-toSun, up);
        _sun.LightColor = C(kf.DirColor);
        _sun.LightEnergy = kf.DirBright * LightScale;
        Daylight = Math.Clamp(kf.DirBright, 0f, 1f);
        Color amb = C(kf.AmbientColor * LightScale);
        Color fog = C(kf.FogColor);

        if (!underground)
        {
            _env.BackgroundColor = fog;
            _env.AmbientLightColor = amb;
            _env.AmbientLightEnergy = 1f;
            _env.FogEnabled = kf.FogMode != FogMode.Off;
            _env.FogLightColor = fog;
            _env.FogDepthBegin = kf.FogStart;
            _env.FogDepthEnd = Math.Max(kf.FogEnd, kf.FogStart + 1f);
        }

        // the sky objects that are up now, along their arcs; a keyframe can swap a model, turn it or fade it
        _lastT = t;
        var replaces = Replaces(t);
        float secs = (float)_clock.Elapsed.TotalSeconds;
        Vector3 sunColor = new(kf.SunColor.X, kf.SunColor.Y, kf.SunColor.Z);
        Vector3 ambient = new(kf.AmbientColor.X, kf.AmbientColor.Y, kf.AmbientColor.Z);
        for (int i = 0; i < _layers.Count; i++)
        {
            Layer l = _layers[i];
            SkyObjectData o = l.Obj;
            uint gfx = o.GfxObjId;
            float heading = 0f, transparent = 0f, lum = float.NaN, maxBright = float.NaN;
            if (replaces.TryGetValue((uint)i, out var rep))
            {
                if (rep.GfxObjId != 0) gfx = rep.GfxObjId;
                if (rep.Rotate != 0f) heading = rep.Rotate;
                transparent = Math.Clamp(rep.Transparent, 0f, 1f);
                if (rep.Luminosity > 0f) lum = rep.Luminosity;
                if (rep.MaxBright > 0f) maxBright = rep.MaxBright;
            }
            bool weather = Weather(o);
            bool up2 = o.IsVisible(t) && !(weather && NoWeather);
            // a layer's particles (rain, snow...) run around the camera while it's up
            // left out: 0x330007DB, a sky effect of big faint sheets that only showed as planes and lines across the sky
            if (Particles != null && o.PesObjectId != 0 && o.PesObjectId != 0x330007DBu)
            {
                var (ax, ay, az) = World.ToAc(cam);
                var at = System.Numerics.Matrix4x4.CreateTranslation(ax, ay, az);
                bool want = up2 && !underground && !(Indoors && weather) && i != _hidden;
                if (want && !_pes.ContainsKey(i)) _pes[i] = Particles.Add(at, null, null, o.PesObjectId);
                else if (want) Particles.Move(_pes[i], at);
                else if (_pes.Remove(i, out uint gone)) Particles.Remove(gone);
            }
            foreach (var kv in l.Models)
            {
                bool show = up2 && kv.Key == gfx && i != _hidden;
                kv.Value.node.Visible = show;
                if (!show) continue;
                float hr = heading * MathF.PI / 180f, rr = o.CurrentAngle(t) * MathF.PI / 180f;
                var model = System.Numerics.Matrix4x4.CreateScale(weather ? 1f : _scale)
                          * System.Numerics.Matrix4x4.CreateRotationZ(-hr)
                          * System.Numerics.Matrix4x4.CreateRotationY(-rr);
                // weather hangs around the camera at its own size; most of it sits 120 m lower (retail's offset)
                if (weather && (o.Properties & 0x08u) == 0u) model *= System.Numerics.Matrix4x4.CreateTranslation(0f, 0f, -120f);
                kv.Value.node.Transform = ObjectAssets.Xf(model);
                var scroll = new Vector2((o.TexVelocityX * secs) % 1f, (o.TexVelocityY * secs) % 1f);
                foreach (var (mat, sLum, sDiffuse) in kv.Value.mats)
                {
                    mat.SetShaderParameter("ambient", ambient);
                    mat.SetShaderParameter("sun_color", sunColor);
                    mat.SetShaderParameter("sun_dir", toSun);
                    mat.SetShaderParameter("emissive", float.IsNaN(lum) ? sLum : lum);
                    mat.SetShaderParameter("diffuse", float.IsNaN(maxBright) ? sDiffuse : maxBright);
                    mat.SetShaderParameter("transparency", transparent);
                    mat.SetShaderParameter("uv_scroll", scroll);
                }
            }
        }

        Text = $"Dereth time: {DerethDateTime.HourText(hour)}" + (_group?.Name is { Length: > 0 } n ? $" ({n})" : "") +
               (_shiftSeconds != 0 ? $"  [moved {_shiftSeconds / DerethDateTime.HourTicks:+0;-0} h]" : "") + "   shift+[ ] change the hour";
    }

    /// <summary>
    /// Whether a layer's texture repeats: it scrolls, or its UVs run past the texture's edges. One that doesn't is
    /// clamped - wrapped, the texels at a polygon's edge blend with the far side of the texture and the sky shows
    /// thin lines along the dome's seams.
    /// </summary>
    private static bool Wraps(SkyObjectData o, Vector2[] uv)
    {
        if (o.TexVelocityX != 0f || o.TexVelocityY != 0f) return true;
        foreach (var t in uv) if (t.X < -0.01f || t.X > 1.01f || t.Y < -0.01f || t.Y > 1.01f) return true;
        return false;
    }

    /// <summary>A weather layer (rain, snow, mist...), drawn after the world near the camera, not out on the sky.</summary>
    private static bool Weather(SkyObjectData o) => o.IsWeather || o.IsPostScene;

    private static Color C(System.Numerics.Vector3 v) => new(v.X, v.Y, v.Z);

    private readonly Dictionary<uint, SkyObjectReplaceData> _replaces = new();

    /// <summary>The swaps of the keyframe now in force (the last one begun).</summary>
    private Dictionary<uint, SkyObjectReplaceData> Replaces(float t)
    {
        _replaces.Clear();
        if (_group == null || _group.SkyTimes.Count == 0) return _replaces;
        DatSkyKeyframeData k1 = _group.SkyTimes[^1];
        foreach (var k in _group.SkyTimes) { if (k.Keyframe.Begin <= t) k1 = k; else break; }
        foreach (var r in k1.Replaces) _replaces[r.ObjectIndex] = r;
        return _replaces;
    }

    /// <summary>A new day's sky: its keyframes and its objects' models.</summary>
    private void UseGroup(DayGroupData? group)
    {
        _group = group;
        foreach (var l in _layers) foreach (var m in l.Models.Values) m.node.QueueFree();
        if (Particles != null) foreach (uint id in _pes.Values) Particles.Remove(id);
        _pes.Clear();
        _layers.Clear();
        _provider = group != null && group.SkyTimes.Count > 0
            ? new SkyStateProvider(group.SkyTimes.Select(s => s.Keyframe).ToList())
            : null;
        if (group == null) return;

        // every model the day can show, and how far out the biggest reaches (all are scaled to the sky's radius)
        var ids = new HashSet<uint>();
        // (weather - rain, snow, mist - is near the camera at its own size, so it doesn't count)
        for (int i = 0; i < group.SkyObjects.Count; i++)
        {
            var o = group.SkyObjects[i];
            if (Weather(o)) continue;
            if (o.GfxObjId != 0) ids.Add(o.GfxObjId);
            foreach (var k in group.SkyTimes) foreach (var r in k.Replaces) if (r.ObjectIndex == i && r.GfxObjId != 0) ids.Add(r.GfxObjId);
        }
        float reach = 1f;
        foreach (uint id in ids)
        {
            if ((id & 0xFF000000u) != 0x01000000u) continue;   // sky Setups aren't drawn yet
            _assets.Prepare(id);
            if (_assets.GetPrepared(id) is { } p)
                foreach (var sub in p.Subs) foreach (var v in sub.pos) reach = Math.Max(reach, v.Length());
        }
        _scale = SkyRadius / reach;

        for (int i = 0; i < group.SkyObjects.Count; i++)
        {
            var o = group.SkyObjects[i];
            var layer = new Layer { Obj = o };
            var mine = new HashSet<uint> { o.GfxObjId };
            bool fades = group.SkyTimes.Any(k => k.Replaces.Any(r => r.ObjectIndex == i && r.Transparent > 0f));
            foreach (var k in group.SkyTimes) foreach (var r in k.Replaces) if (r.ObjectIndex == i && r.GfxObjId != 0) mine.Add(r.GfxObjId);
            foreach (uint id in mine)
            {
                if (id != 0 && (id & 0xFF000000u) == 0x01000000u) _assets.Prepare(id);
                if (id == 0 || (id & 0xFF000000u) != 0x01000000u || _assets.GetPrepared(id) is not { } p || p.Subs.Count == 0) continue;
                var mesh = new ArrayMesh();
                var mats = new List<(ShaderMaterial, float, float)>();
                foreach (var sub in p.Subs)
                {
                    var arrays = new Godot.Collections.Array();
                    arrays.Resize((int)Mesh.ArrayType.Max);
                    if (!fades && _assets.SurfaceOpaque(sub.surfaceId))
                    {
                        // a solid layer (the dome) has hairline cracks between some of its polygons in the data, where
                        // the background showed through as lines: each triangle is grown a touch so they overlap. Not
                        // on a layer the time of day fades - half see-through, the overlaps would show as lines
                        int n = sub.idx.Length;
                        var pos = new Vector3[n]; var nrm = new Vector3[n]; var uv = new Vector2[n]; var idx = new int[n];
                        for (int t = 0; t + 2 < n; t += 3)
                        {
                            Vector3 c = (sub.pos[sub.idx[t]] + sub.pos[sub.idx[t + 1]] + sub.pos[sub.idx[t + 2]]) / 3f;
                            for (int k = 0; k < 3; k++)
                            {
                                int v = sub.idx[t + k];
                                pos[t + k] = c + (sub.pos[v] - c) * 1.01f;
                                nrm[t + k] = sub.nrm[v]; uv[t + k] = sub.uv[v]; idx[t + k] = t + k;
                            }
                        }
                        arrays[(int)Mesh.ArrayType.Vertex] = pos;
                        arrays[(int)Mesh.ArrayType.Normal] = nrm;
                        arrays[(int)Mesh.ArrayType.TexUV] = uv;
                        arrays[(int)Mesh.ArrayType.Index] = idx;
                    }
                    else
                    {
                        arrays[(int)Mesh.ArrayType.Vertex] = sub.pos;
                        arrays[(int)Mesh.ArrayType.Normal] = sub.nrm;
                        arrays[(int)Mesh.ArrayType.TexUV] = sub.uv;
                        arrays[(int)Mesh.ArrayType.Index] = sub.idx;
                    }
                    mesh.AddSurfaceFromArrays(Mesh.PrimitiveType.Triangles, arrays);
                    Shader shader = Wraps(o, sub.uv)
                        ? (sub.kind == TranslucencyKind.Additive ? _add : _mix)
                        : (sub.kind == TranslucencyKind.Additive ? _addClamp : _mixClamp);
                    bool clamped = shader == _mixClamp || shader == _addClamp;
                    var mat = new ShaderMaterial
                    {
                        Shader = Weather(o) ? WeatherShader(shader) : shader,
                        // the sky in its own order, before anything else see-through; weather after the world, as retail
                        RenderPriority = Weather(o) ? Math.Clamp(40 + i, 0, 127) : Math.Clamp(-120 + i, -128, 0),
                    };
                    // the compatibility renderer keeps wrap/clamp on the texture itself, so a clamped layer gets its own copy
                    var tex = _assets.SurfaceTexture(sub.surfaceId);
                    mat.SetShaderParameter("tex", clamped ? ImageTexture.CreateFromImage(tex.GetImage()) : tex);
                    float diffuse = _dats.Get<Surface>(sub.surfaceId)?.Diffuse ?? 1f;
                    mesh.SurfaceSetMaterial(mesh.GetSurfaceCount() - 1, mat);
                    mats.Add((mat, sub.luminosity, diffuse <= 0f ? 1f : diffuse));
                }
                var node = new MeshInstance3D
                {
                    Mesh = mesh, Name = $"Sky{i}_{id:X8}", Visible = false,
                    CastShadow = GeometryInstance3D.ShadowCastingSetting.Off,
                    ExtraCullMargin = 16384f,
                };
                AddChild(node);
                layer.Models[id] = (node, mats);
            }
            _layers.Add(layer);
        }
    }
}
