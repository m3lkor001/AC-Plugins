using System;
using System.Collections.Generic;
using System.Linq;
using ACGodot.Combat;
using DatReaderWriter.DBObjs;
using DatReaderWriter.Enums;
using Godot;

namespace ACGodot.Magic;

/// <summary>One of the game's spells, from its spell table, with what ACGodot makes of it.</summary>
public sealed class Spell
{
    public int Id;
    public string Name = "", Description = "";
    public MagicSchool School;
    public SpellCategory Category;
    public SpellType Type;
    public SpellIndex Flags;
    public uint Icon;
    public int Mana, Power, Level;
    public double Duration;
    public float RangeConstant, RangeMod;
    /// <summary>Cast at no one (a ring, a wall): the server is asked for it without a target.</summary>
    public bool NoTarget;

    /// <summary>What it does here: a war bolt, restoring a vital, or raising an attribute / skill / vital's top.</summary>
    public enum Kind { None, Bolt, Restore, RaiseAttribute, RaiseSkill, RaiseVital }
    public Kind Does;
    public int Target;       // the attribute (0-5), skill id or vital (0-2) it acts on
    /// <summary>What it's made of (its formula's components, by name), for its description.</summary>
    public List<string> Components = new();
    public uint Windup, Gesture;           // its formula's motions: the hands raised (the first component's), then the cast (the last's)
    public PlayScript CasterEffect, TargetEffect, FizzleEffect;   // its particles: on the caster, on who it lands on, a fizzle
    public int DamageType;   // a bolt's element

    public int SkillId => School switch
    {
        MagicSchool.WarMagic => Rules.WarMagic, MagicSchool.LifeMagic => Rules.LifeMagic,
        MagicSchool.CreatureEnchantment => Rules.CreatureEnchantment, MagicSchool.ItemEnchantment => Rules.ItemEnchantment, MagicSchool.VoidMagic => 43, _ => Rules.WarMagic,
    };
}

/// <summary>
/// Magic, as far as the world on its own needs it: the spells you know (by your trained magic schools, a level
/// more for every 50 points of skill), cast from the spellbook (B) or the shortcut bar. Casting takes mana and a skill
/// roll against the spell's power (a fizzle wastes some); war bolts fly at the selected creature, life spells restore
/// health, stamina or mana, creature spells raise an attribute or skill (or a vital's top) for a while. Magic items
/// carry spells that work while they're worn.
/// </summary>
public partial class MagicSystem : Node3D
{
    public const uint SpellTableId = 0x0E00000E;
    public CombatSystem Combat = null!;
    public Character Me => Combat.Me;
    public Func<Vector3>? CasterAt;            // the caster's chest, for a bolt to fly from
    public Action<string, Color>? Say;

    private readonly Dictionary<int, Spell> _spells = new();
    private readonly Dictionary<string, int> _skillByName = new(StringComparer.OrdinalIgnoreCase);
    private double _now, _nextCast, _regen;
    private readonly List<Bolt> _bolts = new();
    // what's on you now: each by its category (a stronger one replaces a weaker), with when it ends
    private readonly Dictionary<SpellCategory, (Spell spell, double until, int amount)> _on = new();
    // spells from worn magic items (by the item)
    private readonly Dictionary<Item, List<(Spell spell, int amount)>> _itemSpells = new();

    private sealed class Bolt { public MeshInstance3D Node = null!; public Fighter Target = null!; public Spell Spell = null!; public int Damage, Skill; }

    public static readonly Color MagicColor = new(0.6f, 0.75f, 1f);

    public IReadOnlyDictionary<int, Spell> All => _spells;
    /// <summary>Each item set's spells by tier (the set's id, then the level they start at).</summary>
    public static readonly Dictionary<uint, SortedDictionary<uint, List<int>>> SetTiers = new();
    /// <summary>The spells an item set gives at a level (the highest tier at or below it; none below the first).</summary>
    public static List<int> SetSpellsAt(int set, int level)
    {
        if (!SetTiers.TryGetValue((uint)set, out var tiers)) return new List<int>();
        List<int>? got = null;
        foreach (var kv in tiers) { if (kv.Key <= (uint)Math.Max(0, level)) got = kv.Value; else break; }
        return got ?? new List<int>();
    }

    public void Load(Dats dats)
    {
        try
        {
            _dats = dats;
            var table = dats.Get<SpellTable>(SpellTableId);
            if (table == null) return;
            SpellComponentTable? comps = null;
            try { comps = dats.Get<SpellComponentTable>(0x0E00000Fu); } catch { }
            foreach (var kv in table.Spells)
            {
                var b = kv.Value;
                var s = new Spell
                {
                    Id = (int)kv.Key, Name = b.Name?.Value ?? "", Description = b.Description?.Value ?? "", School = b.School,
                    Category = b.Category, Type = b.MetaSpellType, Flags = b.Bitfield, Icon = b.Icon, Mana = (int)b.BaseMana, Power = (int)b.Power,
                    Duration = b.Duration, RangeConstant = b.BaseRangeConstant, RangeMod = b.BaseRangeMod,
                };
                s.NoTarget = (uint)b.NonComponentTargetType == 0 && (b.Bitfield & SpellIndex.SelfTargeted) == 0;
                s.Level = Math.Clamp(1 + s.Power / 50, 1, 8);
                s.CasterEffect = b.CasterEffect; s.TargetEffect = b.TargetEffect; s.FizzleEffect = b.FizzleEffect;
                if (comps != null && b.Components.Count > 0)
                {
                    if (comps.Components.TryGetValue(b.Components[0], out var c0)) s.Windup = c0.Gesture;
                    if (comps.Components.TryGetValue(b.Components[^1], out var c1)) s.Gesture = c1.Gesture;
                    // (every gesture a cast is made of - the ones the server may have us make)
                    foreach (var cid in b.Components) if (comps.Components.TryGetValue(cid, out var cc) && (uint)cc.Gesture != 0) _castMotions.Add((uint)cc.Gesture);
                    if (s.Gesture != 0) _castEnds.Add(s.Gesture);
                    foreach (var cid in b.Components)
                        if (comps.Components.TryGetValue(cid, out var cc) && cc.Name?.Value is { Length: > 0 } cn) s.Components.Add(cn);
                }
                Classify(s);
                _spells[s.Id] = s;
            }
            // item sets' spells, tier by tier (an aetheria's built-in buff: its set's spells at its level)
            try
            {
                foreach (var kv in table.SpellsSets)
                {
                    var tiers = new SortedDictionary<uint, List<int>>();
                    foreach (var t in kv.Value.SpellSetTiers)
                    {
                        var ids = new List<int>();
                        foreach (var sid in t.Value.Spells) ids.Add((int)Convert.ToUInt32(sid));
                        tiers[Convert.ToUInt32(t.Key)] = ids;
                    }
                    SetTiers[Convert.ToUInt32(kv.Key)] = tiers;
                }
            }
            catch (Exception ex) { GD.PushWarning("spell sets: " + ex.Message); }
        }
        catch (Exception ex) { GD.PushWarning("spells: " + ex.Message); }
        foreach (var (id, name) in Me.AllSkills()) _skillByName[name.Replace(" ", "")] = id;
        // a character made before there was magic: given the starter's schools, so there's something to cast
        if (Me.TrainingOf(Rules.WarMagic) == Character.Training.Untrained && Me.TrainingOf(Rules.LifeMagic) == Character.Training.Untrained
            && Me.TrainingOf(Rules.CreatureEnchantment) == Character.Training.Untrained)
            foreach (int id in new[] { Rules.WarMagic, Rules.LifeMagic, Rules.CreatureEnchantment })
                Me.Skills[id] = new Character.SkillState { Training = Character.Training.Trained };
        // with the skill table read, the raising spells can find their skills
        foreach (var s in _spells.Values) if (s.Does == Spell.Kind.None) Classify(s);
        LoadBuffs();
    }

    // ── the spells you cast on yourself kept between runs (with the time they had left, as the game counts it: only
    // while you're in the world) in user://buffs.cfg ──
    private const string BuffsPath = "user://buffs.cfg";
    private double _saveIn = 10;

    private void LoadBuffs()
    {
        var cfg = new ConfigFile();
        if (global::ACGodot.SafeConfig.Load(cfg, BuffsPath) != Error.Ok || !cfg.HasSection("on")) return;
        foreach (var key in cfg.GetSectionKeys("on"))
        {
            var v = ((string)cfg.GetValue("on", key)).Split('|');
            if (v.Length < 3 || !int.TryParse(v[0], out int id) || !double.TryParse(v[1], System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double left)
                || !int.TryParse(v[2], out int amount) || !_spells.TryGetValue(id, out var sp) || left <= 0) continue;
            _on[sp.Category] = (sp, _now + left, amount);
        }
        Recalc();
    }

    /// <summary>On a server: asks it to cast (the spell; whether it's one cast on yourself). True if it was asked.</summary>
    public Func<Spell, bool, ACGodot.Objects.ObjectStreamer.Selectable?, bool?>? NetCast;   // (true: asked of the server; false: not on one; null: not cast at all - said why)
    /// <summary>On a server: cast at this object id instead (set by a plugin's cast for the next Cast) - an item in a pack
    /// (a bane on your shield) isn't a thing in the world to select, and selecting it would go off with a look through packs.</summary>
    public uint CastAtGuid;
    private bool _serverBuffs;
    /// <summary>The server says what was asked of it (a cast) is done: the next can be asked.</summary>
    private int _castAsk, _castRefused;
    private bool _saidBusy;
    /// <summary>The server wouldn't cast what was last asked: no gesture for it.</summary>
    public void NetCastRefused() { _castRefused = _castAsk; _holdUntil = 0; _cutUntil = 0; _castEnd = 0; _stepUntil = 0; }
    /// <summary>A spell's name by its number (null: not one the game's data has).</summary>
    public string? NameOf(int spellId) => _spells.TryGetValue(spellId, out var sp) ? sp.Name : null;
    private int _gestureSeen;
    // a cast under way on a server: the feet held until halfway through its last gesture; a step after that cuts the gesture
    private double _holdUntil, _cutUntil, _castEnd;
    /// <summary>A cast is under way (on a server): from asking for it to the end of its last gesture. Sidestepping then slides you along as you cast.</summary>
    public bool Casting => _serverBuffs && _now < _castEnd;
    private uint _castGesture;
    // (the one step of fast casting: once taken - a moment's going - forward and back are held again till the cast is done)
    private double _stepUntil;
    private const double StepTime = 0.34;   // (three quarters of the 0.45 it began as)
    public bool HoldsMovement => _serverBuffs && (_now < _holdUntil || _stepUntil > 0 && _now >= _stepUntil && _now < _castEnd);
    public bool TakeCut()
    {
        if (_serverBuffs && _now < _castEnd && _stepUntil == 0) _stepUntil = _now + StepTime;
        if (_now >= _cutUntil) return false;
        _cutUntil = 0; return true;
    }
    private readonly HashSet<uint> _castMotions = new(), _castEnds = new();
    /// <summary>One of a cast's gestures, as the server has us make it (anything else it has us do is left alone).</summary>
    public void NetGesture(uint motion, float speed)
    {
        // (a casting gesture: one the game's files have a spell made of - or, while a cast is under way, any wind-up
        // (0x1000....) or cast (0x4000....) motion the server sends: a server that has changed a spell's gestures sends
        // ones the files don't list for it, and those were dropped - the old gesture was played here instead)
        bool known = _castMotions.Contains(motion);
        bool castNow = _serverBuffs && _now < _castEnd && ((motion & 0xF0000000u) == 0x10000000u || (motion & 0xF0000000u) == 0x40000000u);
        if (Player == null || Assets == null || !(known || castNow)) return;
        float len = Assets.ActionLength(Player.LookKey, Player.Stance, motion);
        if (len <= 0f) return;
        _gestureSeen++;
        float sp = speed > 0.05f ? speed : 1f;
        // (cut short by a step - fast casting: the rest of its gestures aren't made, only timed)
        if (_stepUntil == 0) Player.PlayAction(motion, sp);
        // stepping forward or back is held till the hands first reach their height (halfway through the first gesture);
        // a step from then on cuts the gestures short - the game's fast casting
        if (_gestureSeen == 1) _holdUntil = _now + len / sp * 0.5;
        _cutUntil = _now + len / sp + 1.0; _castEnd = Math.Max(_castEnd, _now + len / sp + 1.0);
        // (the last of them: back to standing as it ends - one that holds its end, a bane's crouch, would stay down)
        // (the last of this cast's gestures: its own, where we know which spell it is)
        // (the server sends the hands raised as 0x1000.... motions and the cast itself as a 0x4000.... one)
        if (motion == _castGesture || (motion & 0x40000000u) != 0)
        {
            if (_stepUntil == 0) { var pl = Player; Later(len / sp, () => pl.EndGesture()); }
            _cutUntil = _now + len / sp; _castEnd = _now + len / sp;
        }
    }
    public void NetCastDone() { if (_serverBuffs) { _nextCast = Math.Min(_nextCast, _now + 0.2); _holdUntil = 0; _cutUntil = 0; _castEnd = 0; _stepUntil = 0; } }

    /// <summary>On a server: what's on you is what it says - what was on you playing alone is set aside.</summary>
    public void ServerBuffs()
    {
        _serverBuffs = true;
        _on.Clear();
        Recalc();
    }

    /// <summary>A spell the server says is on you now (for how long; a time below zero: until it's taken off), or no longer.</summary>
    public void ServerEnchant(int spellId, double duration, bool on)
    {
        if (!_spells.TryGetValue(spellId, out var sp)) return;
        if (!on) { if (_on.TryGetValue(sp.Category, out var had) && had.spell.Id == spellId) _on.Remove(sp.Category); }
        else _on[sp.Category] = (sp, duration > 0 ? _now + duration : double.PositiveInfinity, RaiseAmount[Math.Clamp(sp.Level - 1, 0, RaiseAmount.Length - 1)]);
        Recalc();
    }

    public void SaveBuffs()
    {
        if (_serverBuffs) return;   // (the server keeps its own)
        var cfg = new ConfigFile();
        int n = 0;
        foreach (var (sp, until, amount) in _on.Values)
            if (until > _now && !double.IsInfinity(until)) cfg.SetValue("on", $"s{n++}", $"{sp.Id}|{(until - _now).ToString(System.Globalization.CultureInfo.InvariantCulture)}|{amount}");
        global::ACGodot.SafeConfig.Save(cfg, BuffsPath);
    }

    public override void _Notification(int what)
    {
        if (what == NotificationWMCloseRequest || what == NotificationExitTree) SaveBuffs();
    }

    private static readonly string[] AttributeWords = { "Strength", "Endurance", "Quickness", "Coordination", "Focus", "Self" };

    private void Classify(Spell s)
    {
        string cat = s.Category.ToString();
        bool numbered = System.Text.RegularExpressions.Regex.IsMatch(s.Name, @" (I|II|III|IV|V|VI|VII|VIII)$");
        if (!numbered) return;
        if (s.Type == SpellType.Projectile && s.School == MagicSchool.WarMagic && (cat.EndsWith("Missile") || cat.EndsWith("Streak")))
        {
            s.Does = Spell.Kind.Bolt;
            s.DamageType = cat.StartsWith("Acid") ? Rules.Acid : cat.StartsWith("Bludgeon") ? Rules.Bludgeon : cat.StartsWith("Cold") ? Rules.Cold
                         : cat.StartsWith("Electric") ? Rules.Electric : cat.StartsWith("Fire") ? Rules.Fire : cat.StartsWith("Pierc") ? Rules.Pierce : Rules.Slash;
            return;
        }
        bool self = (s.Flags & SpellIndex.SelfTargeted) != 0;
        if (!self) return;
        if (s.Type == SpellType.Boost && cat.EndsWith("Restoring"))
        {
            s.Does = Spell.Kind.Restore;
            s.Target = cat.StartsWith("Health") ? 0 : cat.StartsWith("Stamina") ? 1 : 2;
            return;
        }
        if (s.Type != SpellType.Enchantment || !cat.EndsWith("Raising")) return;
        string what = cat[..^"Raising".Length];
        int attr = Array.IndexOf(AttributeWords, what);
        if (attr >= 0) { s.Does = Spell.Kind.RaiseAttribute; s.Target = attr; return; }
        if (what is "Health" or "Stamina" or "Mana") { s.Does = Spell.Kind.RaiseVital; s.Target = what == "Health" ? 0 : what == "Stamina" ? 1 : 2; return; }
        if (_skillByName.TryGetValue(what, out int skill)) { s.Does = Spell.Kind.RaiseSkill; s.Target = skill; }
    }

    /// <summary>The highest level of spell a school lets you cast (0: not trained).</summary>
    public int MaxLevel(int skillId)
    {
        if (Me.TrainingOf(skillId) == Character.Training.Untrained) return 0;
        return Math.Clamp(1 + Me.Skill(skillId) / 50, 1, 8);
    }

    /// <summary>The spells you can cast now, by school and level.</summary>
    /// <summary>On a server: the spells the character knows there (the spellbook is these; null: worked out from skill, offline).</summary>
    public HashSet<int>? ServerSpells;

    public IEnumerable<Spell> Known() => _spells.Values
        .Where(s => ServerSpells != null ? ServerSpells.Contains(s.Id) : s.Does != Spell.Kind.None && s.Level <= MaxLevel(s.SkillId))
        .OrderBy(s => s.School).ThenBy(s => s.Category.ToString()).ThenBy(s => s.Level);

    private static readonly int[] RaiseAmount = { 10, 15, 20, 25, 30, 35, 40, 45 };
    private static readonly (int lo, int hi)[] BoltDamage = { (8, 16), (11, 22), (15, 30), (19, 38), (26, 52), (33, 66), (48, 96), (60, 120) };

    /// <summary>Casts a spell. Quiet (a plugin's cast, tried again several times a second): nothing said when you're still busy with the last.</summary>
    /// <param name="at">On a server: who it's cast at, whatever is selected (null: at what's selected) - a plugin's cast needn't change the selection.</param>
    public void Cast(int spellId, bool quiet = false, ACGodot.Objects.ObjectStreamer.Selectable? at = null)
    {
        if (!_spells.TryGetValue(spellId, out var s)) { Say?.Invoke("You don't know that spell.", Colors.White); return; }
        if (Combat.Health <= 0) return;
        // (said once for each cast, not for every try while it's under way: a plugin tries again several times a second)
        // (still recovering from the last cast: the press is let go quietly - casting over and over, a "still recovering"
        // line for each was only noise)
        if (_now < _nextCast) { _saidBusy = true; return; }
        _saidBusy = false;
        // on a server the cast is asked of it: whether it works, what it costs and what it does are the server's to say
        // (here only the gesture, so you see yourself cast)
        bool? asked = NetCast?.Invoke(s, (s.Flags & SpellIndex.SelfTargeted) != 0, at);
        if (NetCast != null && asked == null) return;
        if (asked == true)
        {
            // (the next once the server says this one's done - it takes longer there than the gesture here - or after
            // a while if it never says)
            // (the gesture a moment after asking, once the server has had the chance to say no - too little mana, no
            // components: refused, there's no gesture and no wait)
            // (the gestures are the server's, played as it sends them - the spell goes off as they end. Only if it
            // sends none is the gesture played here)
            int ask = ++_castAsk;
            _gestureSeen = 0;
            _holdUntil = _now + 6.0; _cutUntil = 0; _castEnd = _now + 6.0; _stepUntil = 0;   // (till the last gesture says when; never longer than this)
            _castGesture = s.Gesture;
            Later(1.2f, () => { if (_castRefused != ask && _castAsk == ask && _gestureSeen == 0) { float gt = Animate(s, null, false, quiet: true); _holdUntil = _now + gt * 0.5; _cutUntil = _now + gt; _castEnd = _now + gt; } });
            _nextCast = _now + 8.0;
            return;
        }
        if (s.Level > MaxLevel(s.SkillId)) { Say?.Invoke($"Your {s.School} skill is too low to cast {s.Name}.", Colors.White); return; }
        int mana = Math.Max(1, s.Mana);
        if (Me.Mana < mana) { Say?.Invoke($"You don't have enough mana to cast {s.Name}.", Colors.White); return; }
        Fighter? target = null;
        if (s.Does == Spell.Kind.Bolt)
        {
            target = Combat.SelectedFighter;
            if (target == null) { Say?.Invoke("You need a creature selected to cast that.", Colors.White); return; }
            float range = Math.Clamp(s.RangeConstant + s.RangeMod * Me.Skill(s.SkillId), 10f, 60f);
            if (CasterAt != null && CasterAt().DistanceTo(target.Sel.Center) > range) { Say?.Invoke($"{target.Sel.Name} is out of range.", Colors.White); return; }
        }
        _nextCast = _now + 1.2;
        int skill = Me.Skill(s.SkillId);
        // the roll against the spell's power (the game's skill curve)
        if (Rules.Rng.NextDouble() > Rules.SkillChance(skill, Math.Max(1, s.Power)))
        {
            Me.Mana -= Math.Max(1, mana / 2);
            Say?.Invoke("Your spell fizzled.", MagicColor);
            Animate(s, null, true);
            return;
        }
        float castTime = Animate(s, target, false);
        _nextCast = Math.Max(_nextCast, _now + castTime);
        Me.Mana -= mana;
        Say?.Invoke($"You cast {s.Name}.", MagicColor);
        switch (s.Does)
        {
            case Spell.Kind.Bolt:
                var (lo, hi) = BoltDamage[s.Level - 1];
                Launch(s, target!, Rules.Rng.Next(lo, hi + 1), skill);
                break;
            case Spell.Kind.Restore:
                int amount = Rules.Rng.Next(s.Level * 8, s.Level * 15 + 1);
                Restore(s.Target, amount, s.Name);
                break;
            default:
                Enchant(s, RaiseAmount[s.Level - 1]);
                break;
        }
    }

    private void Restore(int vital, int amount, string name)
    {
        int before;
        switch (vital)
        {
            case 0: before = Combat.Health; Combat.Health = Math.Min(Me.MaxHealth, Combat.Health + amount); amount = Combat.Health - before; break;
            case 1: before = Me.Stamina; Me.Stamina = Math.Min(Me.MaxStamina, Me.Stamina + amount); amount = Me.Stamina - before; break;
            default: before = Me.Mana; Me.Mana = Math.Min(Me.MaxMana, Me.Mana + amount); amount = Me.Mana - before; break;
        }
        Say?.Invoke($"You restore {amount} point{(amount == 1 ? "" : "s")} of {Character.VitalNames[vital].ToLowerInvariant()}.", MagicColor);
    }

    private void Enchant(Spell s, int amount)
    {
        if (_on.TryGetValue(s.Category, out var had) && had.amount > amount && had.until > _now)
        {
            Say?.Invoke($"A stronger {s.Category} spell is already on you.", MagicColor);
            return;
        }
        if (_on.ContainsKey(s.Category)) Apply(_on[s.Category].spell, -_on[s.Category].amount);
        double dur = s.Duration > 0 ? s.Duration : 1800;
        _on[s.Category] = (s, _now + dur, amount);
        Apply(s, amount);
        SaveBuffs();
        Say?.Invoke($"{s.Name} raises your {What(s)} by {amount} for {Minutes(dur)}.", MagicColor);
    }

    private string What(Spell s) => s.Does switch
    {
        Spell.Kind.RaiseAttribute => Character.AttributeNames[s.Target],
        Spell.Kind.RaiseVital => "maximum " + Character.VitalNames[s.Target].ToLowerInvariant(),
        Spell.Kind.RaiseSkill => Me.AllSkills().FirstOrDefault(k => k.id == s.Target).name ?? "skill",
        _ => "",
    };

    private static string Minutes(double secs) => secs >= 120 ? $"{secs / 60:0} minutes" : $"{secs:0} seconds";

    // (what's on you changed: the buffs worked out again from it)
    private void Apply(Spell s, int amount) => Recalc();

    /// <summary>
    /// The buffs from what's on you, as the game counts them: of the spells on the same attribute, skill or vital (or
    /// of the same family), only the strongest counts - the highest level, or of the same level the longest lasting.
    /// </summary>
    /// <summary>On a server: the enchantments on us as it keeps them (what each changes, by how much).</summary>
    public Func<IEnumerable<ACGodot.Net.NetGame.EnchantMod>>? ServerMods;

    private void Recalc()
    {
        Array.Clear(Me.AttributeBuff);
        Array.Clear(Me.VitalBuff);
        Me.SkillBuff.Clear();
        Me.VitalMult[0] = Me.VitalMult[1] = Me.VitalMult[2] = 1f;
        if (_serverBuffs && ServerMods != null)
        {
            // the server's own numbers: of each family the strongest counts; what adds is added (attributes, the
            // vitals' tops, skills). What multiplies (vitae) isn't worked in.
            foreach (var m in ServerMods().GroupBy(m => m.Category).Select(g => g.OrderByDescending(m => m.Power).First()))
            {
                // (what multiplies a vital's top: taken of the whole. Other multipliers - vitae, on skills - aren't worked in)
                if ((m.Type & 0x4000) != 0 && (m.Type & 0x2) != 0 && (m.Type & 0x800000) == 0 && m.Value > 0f)
                {
                    int mi = m.Key == 1 ? 0 : m.Key == 3 ? 1 : m.Key == 5 ? 2 : -1;
                    if (mi >= 0) Me.VitalMult[mi] *= m.Value;
                    continue;
                }
                if ((m.Type & 0x4000) != 0 || (m.Type & 0x800000) != 0) continue;
                int v = (int)MathF.Round(m.Value);
                if ((m.Type & 0x1) != 0)
                {
                    if (m.Key >= 1 && m.Key <= 6) Me.AttributeBuff[m.Key - 1] += v;
                    else if ((m.Type & 0x2000) != 0) for (int i = 0; i < 6; i++) Me.AttributeBuff[i] += v;
                }
                else if ((m.Type & 0x2) != 0)
                {
                    int vi = m.Key == 1 ? 0 : m.Key == 3 ? 1 : m.Key == 5 ? 2 : -1;
                    if (vi >= 0) Me.VitalBuff[vi] += v;
                }
                else if ((m.Type & 0x10) != 0 && m.Key != 0)
                    Me.SkillBuff[(int)m.Key] = (Me.SkillBuff.TryGetValue((int)m.Key, out int had) ? had : 0) + v;
            }
            return;
        }
        foreach (var (s, _, amount) in Active())
            switch (s.Does)
            {
                case Spell.Kind.RaiseAttribute: Me.AttributeBuff[s.Target] += amount; break;
                case Spell.Kind.RaiseVital: Me.VitalBuff[s.Target] += amount; break;
                case Spell.Kind.RaiseSkill: Me.SkillBuff[s.Target] = (Me.SkillBuff.TryGetValue(s.Target, out int v) ? v : 0) + amount; break;
            }
    }

    // what a spell acts on: the attribute, skill or vital it raises, else its family
    private static (int, int) Key(Spell s) => s.Does is Spell.Kind.RaiseAttribute or Spell.Kind.RaiseSkill or Spell.Kind.RaiseVital
        ? ((int)s.Does, s.Target) : (-1, (int)s.Category);

    /// <summary>What's on you that counts, and for how long more (-1: from an item, while it's worn): one spell for each
    /// attribute, skill, vital or family - the highest level, or of the same level the longest lasting.</summary>
    public IEnumerable<(Spell spell, double left, int amount)> Active()
    {
        var all = new List<(Spell spell, double left, int amount)>();
        // (no end - a deed's, a worn thing's: shown with no time, just on)
        foreach (var kv in _on) if (kv.Value.until > _now) all.Add((kv.Value.spell, double.IsPositiveInfinity(kv.Value.until) ? -1 : Math.Max(0, kv.Value.until - _now), kv.Value.amount));
        foreach (var kv in _itemSpells) foreach (var (sp, amt) in kv.Value) all.Add((sp, -1, amt));
        return all.GroupBy(a => Key(a.spell))
                  .Select(g => g.OrderByDescending(a => a.spell.Level).ThenByDescending(a => a.left < 0 ? double.MaxValue : a.left).First());
    }

    // ── magic items ──

    /// <summary>Spells for a magic item that's just been made (loot): one to three raising spells of its tier's level.</summary>
    public void Enchant(Item item)
    {
        if (!item.Magical || item.Spells.Count > 0) return;
        var pool = _spells.Values.Where(s => s.Does is Spell.Kind.RaiseAttribute or Spell.Kind.RaiseSkill or Spell.Kind.RaiseVital
                                             && s.Level == Math.Clamp(item.Tier, 1, 6)).ToList();
        if (pool.Count == 0) return;
        int n = 1 + (Rules.Rng.NextDouble() < 0.3 ? 1 : 0) + (Rules.Rng.NextDouble() < 0.1 ? 1 : 0);
        for (int i = 0; i < n; i++)
        {
            var s = pool[Rules.Rng.Next(pool.Count)];
            if (!item.Spells.Contains(s.Id)) item.Spells.Add(s.Id);
        }
    }

    /// <summary>The worn items' spells put on (and taken items' off).</summary>
    public void GearChanged(IEnumerable<Item> worn)
    {
        var now = worn.Where(i => i.Spells.Count > 0).ToHashSet();
        foreach (var gone in _itemSpells.Keys.Where(i => !now.Contains(i)).ToList())
        {
            foreach (var (sp, amt) in _itemSpells[gone]) Apply(sp, -amt);
            _itemSpells.Remove(gone);
        }
        // (what you had on when the game started: no messages; nor on a server - it says so itself, once, as a thing is
        // put on: ours came again whenever the pack was told of afresh)
        bool quiet = !_gearSeen || ServerSpells != null;
        _gearSeen = true;
        foreach (var item in now)
        {
            if (_itemSpells.ContainsKey(item)) continue;
            var list = new List<(Spell, int)>();
            foreach (int id in item.Spells)
                if (_spells.TryGetValue(id, out var sp) && sp.Does != Spell.Kind.None && sp.Does != Spell.Kind.Bolt)
                {
                    // the game's words: what it casts on you, and whether it beats what's there or what's there beats it
                    if (!quiet)
                    {
                        var had = Active().Where(a => Key(a.spell) == Key(sp)).Select(a => a.spell).FirstOrDefault();
                        string msg = $"The {item.Name} casts {sp.Name} on you";
                        if (had == null) msg += ".";
                        else if (had.Level > sp.Level) msg += $", but it is surpassed by {had.Name}.";
                        else if (had.Level == sp.Level && had.Id == sp.Id) msg += $", refreshing {had.Name}.";
                        else msg += $", surpassing {had.Name}.";
                        Say?.Invoke(msg, MagicColor);
                    }
                    int amt = RaiseAmount[sp.Level - 1];
                    list.Add((sp, amt));
                    _itemSpells[item] = list;   // (in as each goes on, so the next of its spells is weighed against it)
                }
            _itemSpells[item] = list;
        }
        Recalc();
    }

    private bool _gearSeen;

    public string SpellNames(Item item) => string.Join(", ", item.Spells.Select(id => _spells.TryGetValue(id, out var s) ? s.Name : $"#{id}"));

    // ── each frame: bolts in flight, spells wearing off, mana coming back ──

    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("Bolt");
        float dt = (float)delta;
        // (the clock on the wall, not the frames added up: a window in the background runs few frames and the engine caps
        // how long each may count for, so buffs there wore off slower than on the server)
        _now = Time.GetTicksMsec() / 1000.0;
        StepVisuals();
        for (int i = _bolts.Count - 1; i >= 0; i--)
        {
            var b = _bolts[i];
            Vector3 to = b.Target.Sel.Center;
            Vector3 d = to - b.Node.Position;
            float step = 18f * dt;
            if (d.Length() <= step || b.Target.St == Fighter.State.Dead)
            {
                if (b.Target.St != Fighter.State.Dead) Combat.SpellHit(b.Target, b.Damage, b.Spell.DamageType, b.Spell.Name, b.Skill);
                b.Node.QueueFree();
                _bolts.RemoveAt(i);
                continue;
            }
            b.Node.Position += d.Normalized() * step;
        }
        foreach (var cat in _on.Keys.ToList())
        {
            var (sp, until, amt) = _on[cat];
            if (until > _now) continue;
            _on.Remove(cat);
            Recalc();
            Say?.Invoke($"{sp.Name} wears off.", MagicColor);
        }
        if ((_saveIn -= delta) <= 0) { _saveIn = 10; SaveBuffs(); }
        // mana back: a sixtieth of the most a second (more with Mana Conversion... not yet)
        _regen += delta;
        if (_regen >= 1.0 && _serverBuffs) _regen -= 1.0;   // (on a server: what comes back is the server's to say)
        else if (_regen >= 1.0)
        {
            _regen -= 1.0;
            if (Combat.Health > 0 && Me.Mana < Me.MaxMana) Me.Mana = Math.Min(Me.MaxMana, Me.Mana + Math.Max(1, Me.MaxMana / 60));
            if (Combat.Health > 0 && Me.Stamina < Me.MaxStamina) Me.Stamina = Math.Min(Me.MaxStamina, Me.Stamina + Math.Max(1, Me.MaxStamina / 40));
        }
    }

    // ── what you see: the hands raised and the cast (its formula's gestures, in the magic stance), then its particles ──

    public ACGodot.Creatures.Player? Player;
    public ACGodot.Creatures.CreatureAssets? Assets;
    public ACGodot.Effects.ParticleWorld? Particles;
    private Dats? _dats;
    private const uint MagicStance = 0x80000049;
    private const float CastSpeed = 2f;
    private readonly List<(double at, Action act)> _later = new();
    private readonly List<(uint id, double until, Fighter? on)> _effects = new();
    private uint _restoreStance;
    private double _restoreAt = -1;

    /// <summary>Plays a cast: returns how long it takes (the spell lands at the end of it).</summary>
    private float Animate(Spell s, Fighter? target, bool fizzled, bool quiet = false)
    {
        if (Player == null || Assets == null) return 0f;
        var key = Player.LookKey;
        uint stance = Player.Stance;
        uint cast = s.Gesture != 0 ? s.Gesture : s.Windup;
        // the gestures are the magic stance's: from any other, into it for the cast and back after (as the game's
        // casting brings the hands up)
        if (cast != 0 && Assets.ActionLength(key, stance, cast) <= 0f && Assets.HasStance(key, MagicStance))
        {
            if (_restoreAt < 0) _restoreStance = stance;
            Player.SetStance(MagicStance);
            stance = MagicStance;
        }
        // the cast: the hands (and wand) up and straight back down - no long wind-up before it
        float t = 0f;
        float cl = cast != 0 ? Assets.ActionLength(key, stance, cast) : 0f;
        // (at twice the motion's own speed, as the game plays a caster's gestures: at its own speed a crouching cast
        // sat at the bottom before standing again)
        float up = 0f;
        if (cl > 0f)
        {
            Player.PlayAction(cast, CastSpeed); t += cl / CastSpeed;
            // a gesture that holds its end (a bane's crouch): straight back up once it's down, at its own speed - the
            // game sends the caster back to standing as the spell goes off
            up = Assets.LinkLength(key, stance, cast, 0x41000003u);
            var pl = Player;
            Later(t, () => pl.EndGesture());
        }
        // its particles as it goes off: a fizzle's puff, or the caster's glow and what lands on the target (on you, for a spell on yourself)
        if (!quiet) Later(Math.Max(0f, t - 0.2f), () =>
        {
            if (fizzled) { Effect(s.FizzleEffect != 0 ? s.FizzleEffect : PlayScript.Fizzle, null, s.Level); return; }
            if (s.CasterEffect != 0) Effect(s.CasterEffect, null, s.Level);
            if (s.TargetEffect != 0 && s.Does != Spell.Kind.Bolt) Effect(s.TargetEffect, target, s.Level);
        });
        if (stance == MagicStance && _restoreStance != MagicStance) _restoreAt = _now + t + up;
        return t;
    }

    private void Later(float secs, Action a) => _later.Add((_now + secs, a));

    /// <summary>A spell's particles (a PlayScript, picked by the spell's level from the body's script table) on you or a creature.</summary>
    private void Effect(PlayScript ps, Fighter? on, int level)
    {
        if (Particles == null || _dats == null || ps == 0) return;
        try
        {
            // the body's own script table (a creature's setup may name one; a player's doesn't - the server gives
            // players theirs), else the first of the game's tables that has this effect
            var setup = on != null ? _dats.Get<Setup>(on.W.Setup) : null;
            var table = setup != null && (uint)setup.DefaultScriptTable != 0 ? _dats.Get<PhysicsScriptTable>((uint)setup.DefaultScriptTable) : null;
            if (table == null || !table.ScriptTable.ContainsKey(ps)) table = TableWith(ps);
            if (table == null || !table.ScriptTable.TryGetValue(ps, out var data) || data.Scripts.Count == 0) return;
            // the strongest version the spell's level reaches (they're listed by strength, 0 to 1)
            float want = Math.Clamp(level / 8f, 0f, 1f);
            uint script = (uint)data.Scripts[0].ScriptId;
            foreach (var sm in data.Scripts) if (sm.Mod <= want + 1e-4f) script = (uint)sm.ScriptId;
            uint id = Particles.Add(Root(on), null, null, script);
            _effects.Add((id, _now + 8.0, on));
        }
        catch (Exception ex) { GD.PushWarning("spell effect: " + ex.Message); }
    }

    // ── effects the server plays (on you, a creature, a portal...): the same particles, where the thing is ──
    private readonly List<(uint id, double until, Func<(Vector3 at, float yaw)?> where)> _serverFx = new();
    // what each of those is playing, and on whom: the same one again on the same thing starts it over
    private readonly Dictionary<uint, (object owner, uint script)> _serverFxWhat = new();

    /// <summary>
    /// An effect the server says to play: one of a thing's named effects (from its own effects table, else the first of
    /// the game's that has it) at a strength, or (direct) a script by its number - where the thing is, following it.
    /// </summary>
    public void ServerEffect(uint table, uint effect, float mod, bool direct, uint setupId, Func<(Vector3 at, float yaw)?> where, uint soundTable = 0, object? owner = null)
    {
        if (Particles == null || _dats == null || (effect == 0 && !direct) || where() is not { } w) return;
        try
        {
            // (a thing with no effects table of its own: its setup came in the table's place (0x02......) - the table
            // that setup names, and nothing borrowed from another's if it has no such effect. Borrowed, a force
            // bolt's burst came out as the humans' table has it: fire)
            bool own = (table >> 24) == 0x02;
            // (direct, with no script named: the one its setup starts with - a spell's bolt as it flies)
            if (direct && effect == 0) effect = own && _dats.Get<Setup>(table) is Setup ds ? (uint)ds.DefaultScript : 0;
            if (own) table = _dats.Get<Setup>(table) is Setup st ? (uint)st.DefaultScriptTable : 0;
            uint script = direct ? effect : table == 0 && own ? 0 : Particles.ScriptFrom(table, effect, mod);
            // (a projectile's launch is never borrowed: one whose own table hasn't it flies plain - borrowed, every arrow
            // and thrown axe flew with a fire trail, the first table's "launch")
            if (script == 0 && !direct && !own && (PlayScript)effect != PlayScript.Launch && TableWith((PlayScript)effect) is { } tb && tb.ScriptTable.TryGetValue((PlayScript)effect, out var data) && data.Scripts.Count > 0)
            {
                script = (uint)data.Scripts[0].ScriptId;
                foreach (var sm in data.Scripts) if (sm.Mod <= mod + 1e-4f) script = (uint)sm.ScriptId;
            }
            if (script == 0) return;
            // (on its parts, where the effect puts them - around the chest, the hands - not all at its feet)
            Setup? body = null;
            try { if (setupId != 0) body = _dats.Get<Setup>(setupId); } catch { }
            // (played again on the same thing while it's still showing - a debuff's mark over a monster's head, each
            // Unbalancing Assault or bleed: started over, not one more stacked over the others)
            if (owner != null)
                for (int i = _serverFx.Count - 1; i >= 0; i--)
                {
                    uint old = _serverFx[i].id;
                    if (_serverFxWhat.TryGetValue(old, out var ow) && ow.script == script && ReferenceEquals(ow.owner, owner))
                    { Particles.Remove(old); _serverFx.RemoveAt(i); _serverFxWhat.Remove(old); }
                }
            uint id = Particles.Add(RootAt(w.at, w.yaw), body, null, script, soundTable: soundTable);
            _serverFx.Add((id, _now + 8.0, where));
            if (owner != null) _serverFxWhat[id] = (owner, script);
            if (_serverFx.Count > 80) { Particles.Remove(_serverFx[0].id); _serverFxWhat.Remove(_serverFx[0].id); _serverFx.RemoveAt(0); }
        }
        catch (Exception ex) { GD.PushWarning("server effect: " + ex.Message); }
    }

    private static System.Numerics.Matrix4x4 RootAt(Vector3 at, float yaw)
    {
        var (x, y, z) = World.ToAc(at);
        return System.Numerics.Matrix4x4.CreateRotationZ(yaw) * System.Numerics.Matrix4x4.CreateTranslation(x, y, z);
    }

    // the game's script tables (0x34xxxxxx), the humans' (0x34000004) first: the one to use for an effect
    private readonly Dictionary<PlayScript, PhysicsScriptTable?> _tableFor = new();
    private PhysicsScriptTable? TableWith(PlayScript ps)
    {
        if (_dats == null) return null;
        if (_tableFor.TryGetValue(ps, out var t)) return t;
        t = null;
        foreach (uint id in new[] { 0x34000004u }.Concat(Enumerable.Range(1, 0x200).Select(i => 0x34000000u + (uint)i)))
        {
            PhysicsScriptTable? tb = null;
            try { tb = _dats.Get<PhysicsScriptTable>(id); } catch { }
            if (tb != null && tb.ScriptTable.ContainsKey(ps)) { t = tb; break; }
        }
        _tableFor[ps] = t;
        return t;
    }

    // where an effect sits: your feet, or the creature's (AC world)
    private System.Numerics.Matrix4x4 Root(Fighter? on)
    {
        var at = on != null ? on.Sel.Feet : Player?.Position ?? Vector3.Zero;
        var (x, y, z) = World.ToAc(at);
        float yaw = on != null ? on.Yaw : Player?.Heading ?? 0f;
        return System.Numerics.Matrix4x4.CreateRotationZ(yaw) * System.Numerics.Matrix4x4.CreateTranslation(x, y, z);
    }

    // (each frame: what's due, the effects following who they're on, ended ones gone, the stance put back)
    private void StepVisuals()
    {
        for (int i = 0; i < _later.Count; i++)
            if (_now >= _later[i].at) { var a = _later[i].act; _later.RemoveAt(i--); try { a(); } catch (Exception ex) { GD.PushWarning("cast: " + ex.Message); } }
        for (int i = _effects.Count - 1; i >= 0; i--)
        {
            var (id, until, on) = _effects[i];
            if (_now >= until) { Particles?.Remove(id); _effects.RemoveAt(i); continue; }
            Particles?.Move(id, Root(on));
        }
        for (int i = _serverFx.Count - 1; i >= 0; i--)
        {
            var (id, until, where) = _serverFx[i];
            if (_now >= until || where() is not { } w) { Particles?.Remove(id); _serverFx.RemoveAt(i); _serverFxWhat.Remove(id); continue; }
            Particles?.Move(id, RootAt(w.at, w.yaw));
        }
        if (_restoreAt >= 0 && _now >= _restoreAt && _later.Count == 0)
        {
            _restoreAt = -1;
            if (Player != null && Player.Stance == MagicStance && _restoreStance != MagicStance && !Combat.CombatMode) Player.SetStance(_restoreStance);
        }
    }

    private void Launch(Spell s, Fighter target, int damage, int skill)
    {
        var color = s.DamageType switch
        {
            Rules.Fire => new Color(1f, 0.45f, 0.1f), Rules.Cold => new Color(0.55f, 0.85f, 1f), Rules.Acid => new Color(0.4f, 1f, 0.3f),
            Rules.Electric => new Color(0.75f, 0.6f, 1f), Rules.Pierce => new Color(0.9f, 0.9f, 0.7f), Rules.Bludgeon => new Color(0.8f, 0.8f, 0.9f),
            _ => new Color(0.95f, 0.95f, 0.95f),
        };
        var node = new MeshInstance3D
        {
            Mesh = new SphereMesh { Radius = 0.18f, Height = 0.36f, RadialSegments = 12, Rings = 6 },
            MaterialOverride = new StandardMaterial3D { ShadingMode = BaseMaterial3D.ShadingModeEnum.Unshaded, AlbedoColor = color,
                                                       EmissionEnabled = true, Emission = color, EmissionEnergyMultiplier = 2f },
            Position = CasterAt?.Invoke() ?? Vector3.Zero,
        };
        var light = new OmniLight3D { LightColor = color, LightEnergy = 1.5f, OmniRange = 4f };
        node.AddChild(light);
        AddChild(node);
        _bolts.Add(new Bolt { Node = node, Target = target, Spell = s, Damage = damage, Skill = skill });
    }
}
