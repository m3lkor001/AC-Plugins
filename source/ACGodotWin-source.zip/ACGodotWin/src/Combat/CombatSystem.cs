using System;
using System.Collections.Generic;
using System.Linq;
using ACGodot.Creatures;
using ACGodot.Objects;
using DatReaderWriter.DBObjs;
using DatReaderWriter.Types;
using Godot;
using DRWSound = DatReaderWriter.Enums.Sound;

namespace ACGodot.Combat;

/// <summary>A creature's fighting state: its health, what it's doing, and where it came from.</summary>
public sealed class Fighter
{
    public enum State { Idle, Chase, Return, Dead }
    public ObjectStreamer.Selectable Sel = null!;
    public SpawnData.Weenie W = null!;
    public State St;
    public int Health, MaxHealth, Attack, Defense;
    /// <summary>The server's creature (on a server): it isn't run here - it fights as the server says.</summary>
    public bool Remote;
    public float RunRate = 1f, Yaw, HomeYaw;
    public Vector3 HomeFeet;
    public uint Cell, HomeCell, Stance;
    public bool Hostile;
    public double NextTick, NextAttack, SwingAt, CorpseUntil, RespawnAt;
    public uint SwingMotion;       // the attack under way (0: none) - it lands on the animation's attack hook
    public int SwingHeight;        // 0 high, 1 medium, 2 low
    public uint Motion, Style;     // the cycle it's in (ready, running) and its stance
    public string LastStep = "";   // how its last step went (for the P capture: why one doesn't move)
    public double Moving;          // how long it's been moving without getting closer (to give up on a stuck chase)
    public List<Item>? Loot;       // its corpse's contents
}

/// <summary>
/// Fighting, as the game does it (ACE's rules): creatures that see you within their awareness come at you, swing at
/// you with their attack moves when close enough, and go home if you get away; you go into combat (`), pick a target
/// (Tab: the nearest enemy, then the next) and attack high, medium or low (Page Down, End, Delete) at the power the
/// slider is set to (Insert / Page Up). Hits and misses are rolled from attack and defense skills; damage from the
/// attacker's strength and the defender's armor; a creature that runs out of health dies (its death sound and
/// animation), lies there a while and comes back later; you die and come back at the start.
/// </summary>
public partial class CombatSystem : Node
{
    public const float PunchDamage = 2f, PunchVariance = 0.75f;   // bare hands (ACE: a player with no weapon or gloves)

    // you: your character (attributes, skills, experience) and what you carry
    public Character Me = null!;
    public Inventory Inv = null!;
    public Loot? Loot;
    public LootWindow? LootUi;
    public Func<uint, Texture2D?> Icon = _ => null;
    public bool AutoTarget = true, KeepInView;
    private ObjectStreamer.Selectable? _openCorpse;   // the corpse whose contents are showing
    private int PStrength => Me.Attribute(0);
    private int PMaxHealth => Me.MaxHealth;
    private int PDefense => Me.Skill(Rules.MeleeDefense);
    /// <summary>Your attack skill: the wielded weapon's (the old weapon skills count as your best melee skill), or your best melee skill bare-handed.</summary>
    private int PAttack
    {
        get
        {
            var w = Inv.Weapon;
            if (w != null && w.WeaponSkill is 41 or 44 or 45 or 46) return Me.Skill(w.WeaponSkill);
            return Me.MeleeAttack;
        }
    }

    private bool _offHandTurn;
    private const int DualWieldSkill = 49;
    private const float MaxMeleeRange = 0.75f;   // how far apart (between their surfaces) a melee attack reaches
    private const float MaxChaseRange = 96f;     // a creature gives up a chase this far away
    private const float DefaultAwareness = 18f;  // how far a creature sees you unless it says otherwise
    private const float CorpseTime = 180f, RespawnTime = 30f;   // a corpse lasts three minutes; its creature is back a while after
    private const uint Ready = 0x41000003, RunForward = 0x44000007, Dead = 0x40000011;
    private const uint HandCombat = 0x8000003C, NonCombat = 0x8000003D, SwordCombat = 0x8000003E, SwordShield = 0x80000040,
                       TwoHanded = 0x80000044, BowCombat = 0x8000003F, CrossbowCombat = 0x80000041, ThrownCombat = 0x80000047,
                       DualWield = 0x80000046;
    private const int MissileWeapons = 47;
    private const float MissileRange = 40f;

    private ObjectStreamer _objects = null!;
    private Player _player = null!;
    private CreatureAssets _creatures = null!;
    private Dats _dats = null!;
    private Physics.WorldPhysics? _physics;
    private Func<Vector3, float?> _ground = null!;
    public Audio.WorldAudio? Audio;
    public CombatHud Hud = null!;
    /// <summary>The character died and is to come back at the start.</summary>
    public Action? Respawn;

    private readonly Dictionary<uint, CombatTable?> _tables = new();
    private readonly List<Fighter> _active = new();
    private double _now;
    /// <summary>The fighting clock (seconds): a corpse's decay is on it.</summary>
    public double Now => _now;

    // you
    public int Health { get => Me.Health; set => Me.Health = value; }
    public bool CombatMode { get; private set; }
    public float Power = 0.5f;                    // the slider: 0 speed .. 1 power
    public bool RepeatAttacks = true;
    private int _queuedHeight = -1;               // the attack asked for (-1: none)
    private double _nextSwing, _swingAt, _regenAt, _deadUntil, _swingStarted;
    private double _chargeFrom = -1;       // when the power bar began charging for the next blow (-1: not charging)
    private const double ChargeTime = 2.0; // seconds for the bar to fill to full power
    private const double ChargeGrace = 1.0; // charged, still running at it this long before it's called off
    private uint _swing;                          // your attack under way
    private int _swingHeight;
    private Fighter? _swingTarget;
    private bool _dead;

    public void Setup(ObjectStreamer objects, Player player, CreatureAssets creatures, Dats dats, Physics.WorldPhysics? physics,
                      Func<Vector3, float?> ground)
    {
        _objects = objects; _player = player; _creatures = creatures; _dats = dats; _physics = physics; _ground = ground;
        _objects.CreatureHooks = OnCreatureHooks;
        _player.HooksFired = OnPlayerHooks;
        if (Me.Health <= 0) Me.Health = Me.MaxHealth;
        _player.Wield(Inv.Weapon?.ShownAs ?? 0, BowHand);
        _player.WieldOffHand(Inv.OffHand?.ShownAs ?? Shield?.ShownAs ?? 0, Inv.OffHand != null);
    }

    /// <summary>A bow or crossbow wielded: held in the left hand (as the server has it - thrown weapons stay in the right).</summary>
    private bool BowHand => Inv.Weapon is { IsMissileWeapon: true } w && w.MissileKind != "Thrown";

    /// <summary>The shield worn on the left arm, if any.</summary>
    private Item? Shield => Inv.Worn.FirstOrDefault(i => (i.WornAt & Item.SlotShield) != 0 && !i.IsMeleeWeapon);

    /// <summary>In combat with a wand, staff or orb wielded: magic, cast from the spell bar.</summary>
    public bool MagicMode => CombatMode && Inv.Weapon is { } cw && (cw.ItemType & Item.TypeCaster) != 0;

    /// <summary>0 peace, 1 melee, 2 missile, 3 magic (the control bar's combat button).</summary>
    public int ModeNumber => !CombatMode ? 0 : MagicMode ? 3 : Inv.Weapon is { IsMissileWeapon: true } ? 2 : 1;

    private const uint MagicCombat = 0x80000049;

    /// <summary>The stance you fight in: fists, a one-handed weapon, or a two-handed one.</summary>
    private uint MyStance
    {
        get
        {
            var w = Inv.Weapon;
            if (w != null && (w.ItemType & Item.TypeCaster) != 0) return _creatures.HasStance(_player.LookKey, MagicCombat) ? MagicCombat : HandCombat;
            if (w != null && w.IsMissileWeapon)
            {
                // a bow, crossbow or something thrown: its own stance (if the body has it)
                string n = w.Name.ToLowerInvariant();
                string kind = w.MissileKind;
                uint st = kind == "Crossbow" ? CrossbowCombat
                        : kind == "Thrown" || n.Contains("atlatl") || n.Contains("dart") || n.Contains("javelin") || n.Contains("throwing") || n.Contains("shuriken") || n.Contains("djarid") ? ThrownCombat
                        : BowCombat;
                return _creatures.HasStance(_player.LookKey, st) ? st : HandCombat;
            }
            if (w == null || !w.IsMeleeWeapon) return HandCombat;
            if (w.WeaponSkill == 41 || (w.WornAt & Item.SlotTwoHanded) != 0) return TwoHanded;
            // a weapon in each hand: dual wielding; a one-handed weapon with a shield: the sword-and-shield stance (the
            // shield comes round in front)
            if (Inv.OffHand != null && _creatures.HasStance(_player.LookKey, DualWield)) return DualWield;
            return Shield != null && _creatures.HasStance(_player.LookKey, SwordShield) ? SwordShield : SwordCombat;
        }
    }

    /// <summary>Something wielded or taken off: the weapon in hand, and the stance if fighting.</summary>
    /// <summary>Armor and clothing worn show on the character (weapons are held, not worn).</summary>
    public void ShowWorn()
    {
        // the starting outfit becomes your own worn items the first time (then it comes off like anything else)
        if (!Me.OutfitGiven && _creatures.Data.Get(_player.LookKey.Wcid) is { } body)
        {
            Inv.GiveOutfit(body.Worn);
            Me.OutfitGiven = true;
            Me.Save(Inv);
        }
        _player.SetWorn(Inv.Worn.Where(i => (i.WornAt & (Item.SlotMelee | Item.SlotTwoHanded | Item.SlotMissile | Item.SlotHeld | Item.SlotShield)) == 0 && (i.ItemType & (Item.TypeArmor | Item.TypeClothing)) != 0)
                                 .Select(i => $"{i.Wcid}:{i.PaletteTemplate}:{i.Shade.ToString(System.Globalization.CultureInfo.InvariantCulture)}"));
    }

    /// <summary>Told after gear changes (magic items' spells go on or off).</summary>
    public Action? GearUpdated;

    public void GearChanged()
    {
        GearUpdated?.Invoke();
        _player.Wield(Inv.Weapon?.ShownAs ?? 0, BowHand);
        _player.WieldOffHand(Inv.OffHand?.ShownAs ?? Shield?.ShownAs ?? 0, Inv.OffHand != null);
        ShowWorn();
        if (CombatMode) _player.SetStance(MyStance);
        Me.Save(Inv);
    }

    private CombatTable? Table(uint id)
    {
        if (id == 0) return null;
        if (_tables.TryGetValue(id, out var t)) return t;
        try { t = _dats.Get<CombatTable>(id); } catch { t = null; }
        return _tables[id] = t;
    }

    // ── who fights ──

    /// <summary>A creature's fighting state, made the first time it's needed; null for what doesn't fight.</summary>
    // (what can fight or be fought: creatures, and cows - a kind of their own to the server, but hit like any other)
    private static bool Creature(ObjectStreamer.Selectable s) => s.Type is 10 or 15;
    // (what picking a target by itself may land on: never another player - attacking one is only ever asked for by selecting them)
    /// <summary>A summoned pet (yours or anyone's): never a target for Tab / closest monster / auto target.</summary>
    public Func<ObjectStreamer.Selectable, bool>? IsPet;
    private bool Pickable(ObjectStreamer.Selectable s) => Creature(s) && s.Kind < 3 && IsEnemy(s) && IsPet?.Invoke(s) != true;

    public Fighter? Of(ObjectStreamer.Selectable s)
    {
        if (s.Fight is Fighter f) return f;
        if (!Creature(s) || s.Node == null || s.Anim?.Seq == null) return null;
        var w = _creatures.Data.Get(s.Wcid);
        if (w == null || !w.Attackable || (w.CombatTable == 0 && !s.Remote)) return null;
        var basis = s.Node.Transform.Basis;
        Vector3 fwd = basis.Column1;   // the model's +Y (its front) in Godot's axes
        f = new Fighter
        {
            Sel = s, W = w,
            MaxHealth = Math.Max(w.Health, 1), Attack = Rules.CreatureAttack(w), Defense = Rules.CreatureSkill(w, Rules.MeleeDefense),
            RunRate = Rules.RunRate(Rules.CreatureSkill(w, Rules.Run)),
            HomeFeet = s.Feet, HomeYaw = MathF.Atan2(-fwd.X, -fwd.Z), HomeCell = s.Cell, Cell = s.Cell,
            // who it goes for on sight: not those that never attack, wait to be looked at or attacked, or only fight monsters
            Hostile = !s.Remote && (w.Tolerance & (1 | 2 | 8 | 64 | 128)) == 0,
            Remote = s.Remote,
        };
        f.Health = f.MaxHealth;
        f.Yaw = f.HomeYaw;
        if (!f.Remote) f.Stance = PickStance(f);
        s.Fight = f;
        return f;
    }

    private uint PickStance(Fighter f)
    {
        var table = Table(f.W.CombatTable);
        var styles = table?.CombatManeuvers.Select(m => (uint)m.Style).Distinct().ToList() ?? new List<uint>();
        // a weapon in hand: the stance for it
        uint want = HandCombat;
        foreach (var (wcid, _, _) in f.W.Worn)
        {
            var it = _creatures.Data.Get(wcid);
            if (it == null || it.Damage <= 0) continue;
            want = (it.CombatStyle & 8) != 0 ? TwoHanded : (it.CombatStyle & 4) != 0 ? SwordShield : SwordCombat;
            break;
        }
        foreach (uint s in new[] { want, SwordCombat, HandCombat }.Concat(styles))
            if (styles.Contains(s) && _creatures.HasStance(f.Sel.Key, s)) return s;
        return styles.FirstOrDefault(s => _creatures.HasStance(f.Sel.Key, s));
    }

    public bool IsEnemy(ObjectStreamer.Selectable? s) => s != null && !s.Gone && Of(s) is { St: not Fighter.State.Dead };

    // ── each frame ──

    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("CombatSystem");
        _now += delta;
        if (_player == null || !_player.Active) { Hud.Visible = false; return; }
        Hud.Visible = true;
        float dt = (float)Math.Min(delta, 0.1);
        UpdatePlayer(dt);
        // the creatures near you that are fighting, or might start
        if ((int)(_now * 2) != (int)((_now - delta) * 2))
        {
            Gather();
            // (what's in your hands, again: a weapon put on before the server had told us how it looks, or one the body
            // was made again without, is drawn once it can be - nothing happens if it's already there)
            _player.Wield(Inv.Weapon?.ShownAs ?? 0, BowHand);
            _player.WieldOffHand(Inv.OffHand?.ShownAs ?? Shield?.ShownAs ?? 0, Inv.OffHand != null);
        }
        foreach (var f in _active.ToArray()) UpdateFighter(f, dt);
        _objects.FollowSelected();
        // walk away from a corpse (or it decays) and its window closes
        if (_openCorpse != null && LootUi != null)
        {
            if (!LootUi.Visible) _openCorpse = null;
            else if (_openCorpse.Gone || _openCorpse.Node is { Visible: false } || _openCorpse.Feet.DistanceTo(_player.Position) > 5f)
            {
                LootUi.Visible = false;
                _openCorpse = null;
            }
        }
        var sel = _objects.Selected;
        var tf = sel != null && !sel.Gone ? sel.Fight as Fighter : null;
        Hud.Show(Health, PMaxHealth, CombatMode, Power, RepeatAttacks, sel?.Name, tf?.Health ?? -1, tf?.MaxHealth ?? 0,
                 Me.Stamina, Me.MaxStamina, Me.Mana, Me.MaxMana, AutoTarget, KeepInView, _queuedHeight,
                 // (no attack going: the meter's empty - left full, it looked like one was still on)
                 _queuedHeight < 0 && _chargeFrom < 0 ? 0f
                 : _chargeFrom >= 0 ? (float)Math.Clamp((_now - _chargeFrom) / Math.Max(0.05, Power * ChargeTime), 0, 1)
                 : _nextSwing > _swingStarted ? (float)Math.Clamp((_now - _swingStarted) / (_nextSwing - _swingStarted), 0, 1) : 1f);
        _player.KeepInView = KeepInView && CombatMode && tf != null && tf.St != Fighter.State.Dead ? tf.Sel.Center : null;
    }

    private void Gather()
    {
        var at = _player.Position;
        _active.RemoveAll(f => f.Sel.Gone || f.St == Fighter.State.Idle && f.Sel.Feet.DistanceTo(at) > 70f);
        foreach (var s in _objects.AllSelectables)
        {
            if (!Creature(s) || s.Feet.DistanceTo(at) > 60f) continue;
            if (Of(s) is { } f && !_active.Contains(f)) _active.Add(f);
        }
    }

    private float PlayerRadius => AcDream.Core.Physics.DefaultPlayerBody.Radius;

    /// <summary>How far apart a creature and you are, between your surfaces (as the game measures melee reach).</summary>
    private float Gap(Fighter f)
    {
        var a = f.Sel.Feet; var b = _player.Position;
        float h = new Vector2(a.X - b.X, a.Z - b.Z).Length();
        float v = MathF.Abs(a.Y - b.Y);
        if (v > 2.5f) h += v - 2.5f;   // one above the other (a floor apart) isn't close
        return h - f.Sel.Radius - PlayerRadius;
    }

    // ── creatures ──

    private void UpdateFighter(Fighter f, float dt)
    {
        var seq = f.Sel.Anim?.Seq;
        if (seq == null || f.Sel.Gone || f.Remote) return;
        switch (f.St)
        {
            case Fighter.State.Dead:
                if (_now >= f.CorpseUntil && f.Sel.Node!.Visible) f.Sel.Node.Visible = false;
                if (_now >= f.RespawnAt) Revive(f);
                return;
            case Fighter.State.Idle:
                if (!f.Hostile || _dead || _now < f.NextTick) return;
                f.NextTick = _now + 0.2;
                float aware = f.W.Awareness > 0f ? f.W.Awareness : DefaultAwareness;
                if (f.Sel.Feet.DistanceTo(_player.Position) <= aware) Aggro(f);
                return;
            case Fighter.State.Return:
            {
                var to = f.HomeFeet - f.Sel.Feet;
                to.Y = 0;
                if (to.Length() < 0.6f || f.W.Immobile)
                {
                    Place(f, f.HomeFeet, f.HomeYaw, f.HomeCell);
                    SetCycle(f, NonCombat, Ready, 1f);
                    f.Health = f.MaxHealth;
                    f.St = Fighter.State.Idle;
                    f.NextTick = _now + 2.0;
                    return;
                }
                TurnToward(f, to, dt);
                SetCycle(f, f.Stance, RunForward, f.RunRate);
                Step(f, dt);
                return;
            }
            case Fighter.State.Chase:
                Chase(f, dt);
                return;
        }
    }

    private void Aggro(Fighter f)
    {
        f.St = Fighter.State.Chase;
        f.NextAttack = _now + 0.5 + Rules.Rng.NextDouble() * 0.5;
        SetCycle(f, f.Stance, Ready, 1f);
    }

    private void Chase(Fighter f, float dt)
    {
        // you're gone (dead, or out of reach): back home
        if (_dead || f.Sel.Feet.DistanceTo(_player.Position) > MaxChaseRange || f.Sel.Feet.DistanceTo(f.HomeFeet) > MaxChaseRange * 1.5f)
        {
            f.St = Fighter.State.Return; f.SwingMotion = 0;
            return;
        }
        var to = _player.Position - f.Sel.Feet;
        to.Y = 0;
        float gap = Gap(f);
        bool facing = TurnToward(f, to, dt);
        if (f.SwingMotion != 0)
        {
            // swinging: the blow lands on its attack hook (or, without one, partway through)
            if (_now >= f.SwingAt + 1.2) LandCreatureBlow(f);
            return;
        }
        if (gap > MaxMeleeRange && !f.W.Immobile)
        {
            // held up (a shut door, a wall between): it stands and waits rather than running on the spot, still
            // trying the way each frame so it comes on as soon as the way opens
            var was = f.Sel.Feet;
            Step(f, dt);
            float moved = new Vector2(f.Sel.Feet.X - was.X, f.Sel.Feet.Z - was.Z).Length();
            if (moved < 0.2f * dt) f.Moving += dt; else f.Moving = 0;
            SetCycle(f, f.Stance, f.Moving > 0.3 ? Ready : RunForward, f.Moving > 0.3 ? 1f : f.RunRate);
            return;
        }
        SetCycle(f, f.Stance, Ready, 1f);
        if (gap <= MaxMeleeRange && facing && _now >= f.NextAttack) CreatureSwing(f);
    }

    /// <summary>Turns a creature toward a direction; true once it's facing it (near enough to strike).</summary>
    private static bool TurnToward(Fighter f, Vector3 dir, float dt)
    {
        if (dir.LengthSquared() < 1e-4f) return true;
        float want = MathF.Atan2(-dir.X, -dir.Z);
        float diff = Mathf.Wrap(want - f.Yaw, -MathF.PI, MathF.PI);
        float step = 4f * dt;
        f.Yaw += Math.Clamp(diff, -step, step);
        Pose(f);
        return MathF.Abs(diff) < 0.35f;
    }

    /// <summary>Moves a creature on by its animation's velocity, through the collision.</summary>
    private void Step(Fighter f, float dt)
    {
        var seq = f.Sel.Anim!.Seq!;
        float speed = MathF.Abs(seq.CurrentVelocity.Y);
        if (speed < 0.1f) speed = 4f * f.RunRate / 1.5f;
        var fwd = new Vector3(-MathF.Sin(f.Yaw), 0, -MathF.Cos(f.Yaw));
        Vector3 want = f.Sel.Feet + fwd * speed * dt;
        Vector3 got = want;
        uint cell = f.Cell;
        if (_physics != null && f.Sel.Lb.x >= 0)
        {
            var (fx, fy, fz) = World.ToAc(f.Sel.Feet);
            var (tx, ty, tz) = World.ToAc(want);
            float h = Math.Max(f.Sel.Top - f.Sel.Feet.Y, 0.5f);
            if (f.Cell == 0 && f.HomeCell != 0) f.Cell = f.HomeCell;
            var r = _physics.MoveCreature(f.Sel.Lb.x, f.Sel.Lb.y, f.Sel.Index, new(fx, fy, fz + 0.05f), new(tx, ty, tz + 0.05f), f.Cell,
                                          f.Sel.Radius * Physics.WorldPhysics.CreatureBody, h * Physics.WorldPhysics.CreatureBody, AcRotation(f.Yaw));
            if (r is { } m) { got = World.ToGodot(m.acWorld); cell = m.cell; }
            else if (f.Cell != 0) got = f.Sel.Feet;
            f.LastStep = r == null ? "no collision (not loaded / failed)" : $"moved {new Vector2(got.X - f.Sel.Feet.X, got.Z - f.Sel.Feet.Z).Length():0.000} of {speed * dt:0.000} cell {cell:X8} {_physics.LastCreatureHit}";
            // underground (or indoors) it stays in the rooms: a move that loses the room (into the landscape over
            // the dungeon) or lifts it more than a step is refused - it would float up to the landscape
            bool indoors = f.Cell != 0 || f.HomeCell != 0;
            if (r != null && indoors && (cell == 0 || got.Y - f.Sel.Feet.Y > 0.6f))
            { f.LastStep += $" - refused ({(cell == 0 ? "lost the room" : "rose " + (got.Y - f.Sel.Feet.Y).ToString("0.00"))})"; got = f.Sel.Feet; cell = f.Cell != 0 ? f.Cell : f.HomeCell; }   // indoors with no collision loaded: it waits (it would fall to the landscape)
            else if (r != null && indoors)
            {
                // back down onto the floor: each step starts a little above it (so it doesn't catch on the floor) and the
                // sweep keeps that height - step after step it rose, and floated off up through the ceiling
                var (gx, gy, gz) = World.ToAc(got);
                var down = _physics.DropCreature(f.Sel.Lb.x, f.Sel.Lb.y, f.Sel.Index, new(gx, gy, gz + 0.1f), cell,
                                                 f.Sel.Radius * Physics.WorldPhysics.CreatureBody, h * Physics.WorldPhysics.CreatureBody);
                if (down is { } dm && (dm.cell & 0xFFFF) >= 0x100) { got = World.ToGodot(dm.acWorld); cell = dm.cell; }
            }
            // (indoors the collision's height stands - the landscape's ground is far over a dungeon: put there, every next
            // step was "too high" and refused, and it ran on the spot)
            else if (!indoors && _ground(want) is float g) got.Y = g;
        }
        else if (_ground(want) is float g) got.Y = g;
        f.Cell = cell;
        MoveTo(f, got);
    }

    private static System.Numerics.Quaternion AcRotation(float yaw) => System.Numerics.Quaternion.CreateFromAxisAngle(System.Numerics.Vector3.UnitZ, yaw);

    private static void MoveTo(Fighter f, Vector3 feet)
    {
        var s = f.Sel;
        Vector3 d = feet - s.Feet;
        s.Feet = feet; s.Center += d; s.Top += d.Y;
        Pose(f);
    }

    /// <summary>Puts the creature's model where it stands, facing its way.</summary>
    private static void Pose(Fighter f)
    {
        var s = f.Sel;
        if (s.Node == null) return;
        var ac = System.Numerics.Matrix4x4.CreateScale(s.Scale) * System.Numerics.Matrix4x4.CreateRotationZ(f.Yaw);
        s.Node.Transform = new Transform3D(ObjectAssets.Xf(ac).Basis, s.Feet);
    }

    private void Place(Fighter f, Vector3 feet, float yaw, uint cell)
    {
        f.Yaw = yaw; f.Cell = cell;
        MoveTo(f, feet);
        if (_physics != null && f.Sel.Lb.x >= 0)
        {
            var (x, y, z) = World.ToAc(feet);
            _physics.PlaceCreature(f.Sel.Lb.x, f.Sel.Lb.y, f.Sel.Index, new(x, y, z), AcRotation(yaw), cell);
        }
    }

    private static void SetCycle(Fighter f, uint style, uint motion, float speed)
    {
        var seq = f.Sel.Anim?.Seq;
        if (seq == null || style == 0) return;
        if (f.Motion == motion && f.Style == style) return;
        try
        {
            // standing, into another stance: only the stance change, so its animation plays (asking for Ready again
            // as well cut it short)
            if (motion == Ready && (f.Motion == Ready || f.Motion == 0) && f.Style != style)
                seq.Manager.PerformMovement(AcDream.Core.Physics.Motion.MotionTableMovement.Interpreted(style, 1f));
            else seq.SetCycle(style, motion, speed);
        }
        catch (Exception ex) { GD.PushWarning($"{f.Sel.Name} motion: {ex.Message}"); }
        f.Motion = motion; f.Style = style;
    }

    /// <summary>One of the creature's attack moves for its stance, at a random height (as ACE picks them).</summary>
    private (uint motion, int height) PickManeuver(CreatureAssets.Key key, uint table, uint stance, bool armed)
    {
        var t = Table(table);
        if (t == null) return (0, 0);
        var moves = t.CombatManeuvers.Where(m => (uint)m.Style == stance && _creatures.HasAction(key, stance, (uint)m.Motion)).ToList();
        if (moves.Count == 0) return (0, 0);
        var heights = moves.Select(m => (int)m.AttackHeight - 1).Distinct().ToList();   // 0 high, 1 medium, 2 low
        int h = heights[Rules.Rng.Next(heights.Count)];
        var at = moves.Where(m => (int)m.AttackHeight - 1 == h).ToList();
        if (!armed)
        {
            // bare-handed: punches high and middling, kicks low
            var want = h == 2 ? DatReaderWriter.Enums.AttackType.Kick : DatReaderWriter.Enums.AttackType.Punch;
            var typed = at.Where(m => m.AttackType == want).ToList();
            if (typed.Count > 0) at = typed;
        }
        var pick = at[Rules.Rng.Next(at.Count)];
        return ((uint)pick.Motion, h);
    }

    private void CreatureSwing(Fighter f)
    {
        bool armed = f.Stance != HandCombat;
        var (motion, height) = PickManeuver(f.Sel.Key, f.W.CombatTable, f.Stance, armed);
        if (motion == 0) { f.NextAttack = _now + 2.0; return; }
        try { f.Sel.Anim!.Seq!.PlayAction(motion, 1f); }
        catch (Exception ex) { GD.PushWarning($"{f.Sel.Name} attack: {ex.Message}"); return; }
        f.SwingMotion = motion; f.SwingHeight = height; f.SwingAt = _now;
        float len = _creatures.ActionLength(f.Sel.Key, f.Stance, motion);
        if (len <= 0f) len = 1.2f;
        f.NextAttack = _now + len + Rules.Rng.NextDouble() * Math.Max(f.W.PowerupTime, 0f);
    }

    private void OnCreatureHooks(ObjectStreamer.Selectable s, IReadOnlyList<AnimationHook> hooks)
    {
        if (s.Fight is not Fighter f || f.SwingMotion == 0) return;
        foreach (var h in hooks) if (h is AttackHook) { LandCreatureBlow(f); break; }
    }

    /// <summary>A creature's blow lands (or you evade it): rolled from its attack against your defense.</summary>
    private void LandCreatureBlow(Fighter f)
    {
        f.SwingMotion = 0;
        if (_dead || f.St != Fighter.State.Chase || Gap(f) > MaxMeleeRange + 1.0f) return;
        _regenAt = _now + 10;
        if (Rules.Rng.NextDouble() > Rules.SkillChance(f.Attack, PDefense))
        {
            Hud.Log($"You evaded {f.Sel.Name}!", CombatHud.Plain);
            return;
        }
        // its weapon's damage, else the body part it strikes with (a claw, a foot...)
        float max, variance; int type;
        var weapon = f.W.Worn.Select(x => _creatures.Data.Get(x.wcid)).FirstOrDefault(it => it != null && it.Damage > 0);
        if (weapon != null) { max = weapon.Damage; variance = weapon.DamageVariance; type = Rules.FirstType(weapon.DamageType); }
        else
        {
            var parts = f.W.BodyParts.Where(p => p.Damage > 0).ToList();
            if (parts.Count == 0) { max = 1; variance = 0.5f; type = Rules.Bludgeon; }
            else { var p = parts[Rules.Rng.Next(parts.Count)]; max = p.Damage; variance = p.Variance; type = Rules.FirstType(p.DamageType); }
        }
        string part = Rules.PlayerPart(f.SwingHeight);
        int dmg = Math.Max(1, (int)MathF.Round(Rules.RollDamage(max, variance) * Rules.AttributeMod(f.W.Attributes[0]) * Rules.ArmorMod(Inv.ArmorAt(part))));
        PlayWoundSound(_creatures.SoundTableOf(_player.LookKey), _player.Position + new Vector3(0, 1f, 0));
        var (_, plural) = Rules.AttackVerb(type, dmg / (float)PMaxHealth);
        Health -= dmg;
        Hud.Log($"{f.Sel.Name} {plural} your {part} for {dmg} point{(dmg == 1 ? "" : "s")} of {Rules.TypeShort(type)} damage!", CombatHud.Hurt);
        if (Health <= 0) PlayerDies(f, type);
    }

    private void CreatureDies(Fighter f, int type)
    {
        f.St = Fighter.State.Dead;
        f.SwingMotion = 0;
        f.Health = 0;
        SetCycle(f, f.Stance != 0 ? f.Stance : NonCombat, Dead, 1f);
        PlayDeathSound(_creatures.SoundTableOf(f.Sel.Key), f.Sel.Center);
        f.CorpseUntil = _now + CorpseTime;
        f.RespawnAt = f.CorpseUntil + RespawnTime;
        if (_physics != null) _physics.SetCreatureSolid(f.Sel.Lb.x, f.Sel.Lb.y, f.Sel.Index, false);
        Hud.Log(Rules.DeathByYou(type, f.Sel.Name), CombatHud.Kill);
        // its corpse: what it carried (its weapon) and its death treasure
        f.Loot = new List<Item>();
        foreach (var (wcid, _, _) in f.W.Worn)
            if (_creatures.Data.Get(wcid) is { Damage: > 0 } && Item.Make(_creatures.Data, wcid) is { } carried) f.Loot.Add(carried);
        if (Loot != null) f.Loot.AddRange(Loot.Roll(f.W));
        f.Sel.Name = "Corpse of " + f.Sel.BaseName;
        Killed?.Invoke(f.Sel.BaseName, f.Sel.Wcid, f.W.Xp, f.Sel);
        // experience
        if (f.W.Xp > 0)
        {
            Hud.Log($"You've earned {f.W.Xp:N0} experience.", CombatHud.Plain);
            float vitaeWas = Me.Vitae;
            int levels = Me.AddXp(f.W.Xp);
            // experience winning vitae back: said each time (as the game does), with what's left of the penalty
            if (Me.Vitae > vitaeWas + 0.001f)
                Hud.Log(Me.Vitae >= 0.999f ? "Your experience has removed your vitae penalty!"
                                           : $"Your experience has reduced your vitae penalty! It is now {(1f - Me.Vitae) * 100:0}%.", CombatHud.Plain);
            if (levels > 0)
            {
                Hud.Log($"You are now level {Me.Level}!", CombatHud.Kill);
                Hud.Log($"You have {Me.SkillCredits} skill credit{(Me.SkillCredits == 1 ? "" : "s")} to spend.", CombatHud.Plain);
            }
            Me.Save(Inv);
            XpChanged?.Invoke();
        }
        if (_swingTarget == f) _swingTarget = null;
        if (_objects.Selected == f.Sel)
        {
            _objects.Select(null);
            // the attacking stops (it doesn't go on to another by itself); Auto Target only picks the nearest enemy
            _queuedHeight = -1; StopApproach();
            if (AutoTarget && CombatMode) SelectNearestEnemy();
        }
    }

    private void Revive(Fighter f)
    {
        f.St = Fighter.State.Idle;
        f.Health = f.MaxHealth;
        f.Motion = Dead; f.Style = 0;   // (from lying dead: the full change back to standing)
        f.Loot = null;
        f.Sel.Name = f.Sel.BaseName;
        f.Sel.Node!.Visible = true;
        Place(f, f.HomeFeet, f.HomeYaw, f.HomeCell);
        SetCycle(f, NonCombat, Ready, 1f);
        if (_physics != null) _physics.SetCreatureSolid(f.Sel.Lb.x, f.Sel.Lb.y, f.Sel.Index, true);
        f.NextTick = _now + 3.0;
    }

    private void PlayDeathSound(uint table, Vector3 at)
    {
        if (Audio == null) return;
        var have = Audio.SoundsIn(table).Where(s => s is DRWSound.Death1 or DRWSound.Death2 or DRWSound.Death3).ToList();
        if (have.Count > 0) Audio.PlayAny(table, have[Rules.Rng.Next(have.Count)], at);
    }

    private void PlayWoundSound(uint table, Vector3 at)
    {
        if (Audio == null) return;
        var have = Audio.SoundsIn(table).Where(s => s is DRWSound.Wound1 or DRWSound.Wound2 or DRWSound.Wound3).ToList();
        if (have.Count > 0) Audio.PlayFromTable(table, have[Rules.Rng.Next(have.Count)], at);
    }

    /// <summary>Experience earned (the character window shows it).</summary>
    public Action? XpChanged;
    /// <summary>A creature you killed: its name, wcid, the experience it gave, and its (now) corpse.</summary>
    public Action<string, int, long, ObjectStreamer.Selectable>? Killed;
    /// <summary>Whether you're set on attacking something (a height queued).</summary>
    public bool Attacking => _queuedHeight >= 0 || _swing != 0;
    /// <summary>In the attack itself: the wind-up and swing of a melee blow, or an arrow being shot (on a server: from
    /// the attack going to it until it says the attack is done).</summary>
    public bool InAttack => _swing != 0 || _netAttacking;
    /// <summary>A corpse's contents (null if it isn't one).</summary>
    public List<Item>? CorpseContents(ObjectStreamer.Selectable sel) => sel.Fight is Fighter { St: Fighter.State.Dead } f ? f.Loot : null;

    /// <summary>The corpse whose loot window is open (null: none).</summary>
    public ObjectStreamer.Selectable? OpenedCorpse => LootUi is { Visible: true } ? _openCorpse : null;

    /// <summary>R on a corpse: its contents in the loot window. Returns what happened (null: not a corpse).</summary>
    public string? OpenCorpse(ObjectStreamer.Selectable sel)
    {
        if (sel.Fight is not Fighter { St: Fighter.State.Dead } f || f.Loot == null) return null;
        // using the open corpse again shuts it (R, a double-click, the hand, a plugin's use)
        if (_openCorpse == sel && LootUi is { Visible: true }) { LootUi.Visible = false; _openCorpse = null; return $"closed {sel.Name}"; }
        if (sel.Feet.DistanceTo(_player.Position) > 5f) return $"{sel.Name} is too far away";
        LootUi?.Show(sel.Name, f.Loot, Icon);
        _openCorpse = sel;
        return $"looking at {sel.Name}";
    }

    /// <summary>F: picks up the selected item off the ground. Returns what happened.</summary>
    public string PickUp(ObjectStreamer.Selectable? sel)
    {
        if (sel?.Item is not Item item) return "nothing to pick up (select an item on the ground first)";
        if (sel.Feet.DistanceTo(_player.Position) > 3f) return $"the {item.Name} is too far away";
        if (!Inv.Add(item)) return "your pack is full";
        _player.Crouch();
        _objects.RemoveGroundItem(sel);
        Me.Save(Inv);
        return item.IsCoins ? $"You pick up {item.Stack:N0} pyreals." : $"You pick up the {item.Name}.";
    }

    /// <summary>Drops an item from your pack at your feet.</summary>
    public void Drop(Item item)
    {
        _player.Crouch();
        // on a server: asked of it (the thing appears on the ground when it says so)
        if (item.Guid != 0 && Inv.NetDrop != null)
        {
            // (fewer than the whole stack chosen: that many split off onto the ground)
            int part = item.Stack > 1 && ItemSlot.Splitting?.Invoke(item) is int n && n > 0 && n < item.Stack ? n : 0;
            if (part > 0 && Inv.NetSplit != null) Inv.NetSplit(item, uint.MaxValue, 0, part); else Inv.NetDrop(item);
            return;
        }
        var fwd = new Vector3(-MathF.Sin(_player.Heading), 0, -MathF.Cos(_player.Heading));
        var at = _player.Position + fwd * 0.8f;
        if (_ground(at) is float g && MathF.Abs(g - _player.Position.Y) < 1.5f) at.Y = g;
        else at.Y = _player.Position.Y;
        if (_objects.AddGroundItem(item, item.Wcid, item.IsCoins ? $"{item.Stack:N0} Pyreals" : item.Name, at, (float)(Rules.Rng.NextDouble() * Math.Tau)) == null)
            Hud.Log($"The {item.Name} has no model to lay down; it's gone.", CombatHud.Plain);
        else Hud.Log($"You drop the {item.Name}.", CombatHud.Plain);
        GearChanged();
    }

    /// <summary>
    /// Things nearby that aren't creatures or people, nearest first: items on the ground, corpses, chests, doors and
    /// other objects.
    /// </summary>
    private List<ObjectStreamer.Selectable> ItemsNearby()
    {
        var at = _player.Position;
        return _objects.AllSelectables.Where(s => !s.Gone && s.Feet.DistanceTo(at) < 30f && s.Node is not { Visible: false }
                                                  && s != _objects.Self
                                                  // (not NPCs, monsters or players - a server's are told by their kind - but their corpses, yes)
                                                  && (s.Corpse || s.Fight is Fighter { St: Fighter.State.Dead } || s.Kind == 0 && (s.Item != null || s.Type is not (10 or 12)))
                                                  // a server's: one that can be picked up, or is used (a door, chest, portal, lifestone, book ...) -
                                                  // not the scenery it puts out (a bonfire, a tent, a bridge's end, a swarm)
                                                  && !s.Scenery && !s.Unselectable)
                                      .OrderBy(s => s.Feet.DistanceTo(at)).ToList();
    }

    /// <summary>\ : the nearest item or corpse.</summary>
    public string NearestItem()
    {
        var items = ItemsNearby();
        if (items.Count == 0) return "no items nearby";
        _objects.Select(items[0]);
        return $"selected: {items[0].Name}";
    }

    /// <summary>] / [ : the next or previous item or corpse, by distance.</summary>
    public string CycleItem(int step)
    {
        var items = ItemsNearby();
        if (items.Count == 0) return "no items nearby";
        int i = _objects.Selected != null ? items.IndexOf(_objects.Selected) : -1;
        i = i < 0 ? (step > 0 ? 0 : items.Count - 1) : ((i + step) % items.Count + items.Count) % items.Count;
        _objects.Select(items[i]);
        return $"selected: {items[i].Name}";
    }

    /// <summary>' : the nearest enemy, always.</summary>
    public string NearestTarget()
    {
        var at = _player.Position;
        var next = _objects.AllSelectables.Where(s => s.Feet.DistanceTo(at) < 60f && Pickable(s))
                                          .OrderBy(s => s.Feet.DistanceTo(at)).FirstOrDefault();
        if (next == null) return "no enemies nearby";
        _objects.Select(next);
        return $"selected: {next.Name}";
    }

    // ── you ──

    /// <summary>` : into combat (your fists up) or out of it.</summary>
    public string ToggleCombat()
    {
        if (_dead) return "you're dead";
        // (on a server, just arrived: it wouldn't take the stance, and we'd stand ready alone - asked again in a moment)
        if (!CombatMode && NetSettling?.Invoke() == true) return "not yet - still arriving";
        CombatMode = !CombatMode;
        _ownToggleAt = _now;
        _player.StopMoving();   // (going into or out of combat on the run stops you)
        _player.SetStance(CombatMode ? MyStance : NonCombat);
        NetCombatMode?.Invoke(!CombatMode ? 1 : MagicMode ? 8 : Inv.Weapon is { IsMissileWeapon: true } ? 4 : 2);
        if (!CombatMode) { _queuedHeight = -1; _player.ApproachTo = null; }
        // into combat with Auto Target: the nearest enemy picked (nothing more - no attack)
        else if (AutoTarget && (_objects.Selected is not { } cur || !IsEnemy(cur))) SelectNearestEnemy();
        return CombatMode ? "combat mode" : "peace mode";
    }

    private double _ownToggleAt = -10;

    /// <summary>The server put us in peace mode itself (wearing a piece of armor does): out of the fighting stance here too,
    /// so it doesn't look like we're ready to fight while the server has us standing there unable to.</summary>
    public void ServerPeace()
    {
        if (!CombatMode || _dead || _now - _ownToggleAt < 1.5) return;   // (our own change of stance still on its way)
        CombatMode = false;
        _player.SetStance(NonCombat);
        _queuedHeight = -1; _player.ApproachTo = null;
        Hud.Log("You're in peace mode (the server put you there).", CombatHud.Plain);
    }

    private void SelectNearestEnemy()
    {
        var next = _objects.AllSelectables.Where(x => x.Feet.DistanceTo(_player.Position) < 20f && Pickable(x))
                                          .OrderBy(x => x.Feet.DistanceTo(_player.Position)).FirstOrDefault();
        if (next != null) _objects.Select(next);
    }

    /// <summary>Tab: selects the nearest enemy, then the next nearest each press.</summary>
    public string NextTarget(Vector3? from = null)
    {
        var at = from ?? _player.Position;   // (flying the camera about: round the camera)
        var enemies = _objects.AllSelectables.Where(s => s.Feet.DistanceTo(at) < 60f && Pickable(s))
                                             .OrderBy(s => s.Feet.DistanceTo(at)).ToList();
        if (enemies.Count == 0) return "no enemies nearby";
        int i = _objects.Selected != null ? enemies.IndexOf(_objects.Selected) : -1;
        var next = enemies[(i + 1) % enemies.Count];
        _objects.Select(next);
        return $"selected: {next.Name}";
    }

    /// <summary>An attack key: high (0), medium (1) or low (2), at the selected enemy (the nearest if none is).</summary>
    public string AttackKey(int height)
    {
        if (_dead) return "you're dead";
        if (!CombatMode) return "not in combat mode (` to enter it)";
        if (MagicMode) return "casting: use the spell bar (1-9, 0, or Cast)";
        if (!IsEnemy(_objects.Selected))
        {
            var r = NextTarget();
            if (!IsEnemy(_objects.Selected)) return r;
        }
        _queuedHeight = height;
        _attackOn = _objects.Selected;   // (attacking what's picked now)
        _player.AutoRun = false;   // (auto-running: it stops, and the run up to the target takes over - it counted as steering, and called the attack off)
        return $"attacking {_objects.Selected!.Name}";
    }

    /// <summary>Calls off the attack asked for (and the run up to it); a swing already going finishes.</summary>
    public void CancelAttack() { _queuedHeight = -1; _player.ApproachTo = null; _chargeFrom = -1; }

    public string ChangePower(float by)
    {
        Power = Math.Clamp(MathF.Round((Power + by) * 20f) / 20f, 0f, 1f);
        return $"power {Power * 100:0}%";
    }

    private void UpdatePlayer(float dt)
    {
        if (_dead)
        {
            if (_now >= _deadUntil)
            {
                _dead = false;
                Health = PMaxHealth;
                CombatMode = false;
                _player.Revive();
                Respawn?.Invoke();
                Hud.Log("You have returned to life.", CombatHud.Plain);
            }
            return;
        }
        // health comes back out of combat
        if (!Me.OnServer && _now >= _regenAt && Health < PMaxHealth && (int)(_now * 2) != (int)((_now - dt) * 2)) Health = Math.Min(PMaxHealth, Health + Math.Max(1, PMaxHealth / 60));
        // moving yourself calls off the attack
        UpdateArrows(dt);
        if (_player.MovedByKeys) { _queuedHeight = -1; _player.ApproachTo = null; _chargeFrom = -1; }
        if (_swing != 0)
        {
            if (_now >= _swingAt + 1.0) LandPlayerBlow();
            return;
        }
        // (an attack asked of the server and since called off: it's told)
        if (_netAttacking && (_queuedHeight < 0 || !CombatMode)) { _netAttacking = false; NetCancelAttack?.Invoke(); }
        // another target picked mid-attack: the attack is called off (as the retail client does - it tells the server
        // so), not carried over to the new one
        if (_attackOn != null && _objects.Selected != _attackOn && _queuedHeight >= 0)
        {
            if (_netAttacking) { _netAttacking = false; NetCancelAttack?.Invoke(); }
            _queuedHeight = -1; StopApproach(); _chargeFrom = -1; _attackOn = null;
            return;
        }
        if (_queuedHeight < 0) _attackOn = null;
        if (_queuedHeight < 0 || !CombatMode) { StopApproach(); _chargeFrom = -1; return; }
        var sel = _objects.Selected;
        if (sel == null || !IsEnemy(sel)) { _queuedHeight = -1; StopApproach(); _chargeFrom = -1; return; }
        _attackOn ??= sel;
        var f = (Fighter)sel.Fight!;
        float gap = Gap(f);
        if (f.Remote) { AttackRemote(f, gap, dt); return; }
        if (Inv.Weapon is { IsMissileWeapon: true } bow) { UpdateShooting(f, bow, gap, dt); return; }
        // the power bar charges from the moment the attack starts (while running up too), up to the power set - it
        // goes no further, and the blow comes once it's there and you're close enough
        if (_chargeFrom < 0 && _now >= _nextSwing) _chargeFrom = _now;
        if (gap > MaxMeleeRange * 0.9f)
        {
            // charged all the way to the power set (and a second's more running) and still not there: you stop, and
            // the attack is called off
            // (press the attack again - or a plugin does - to carry on)
            if (_chargeFrom >= 0 && _now - _chargeFrom >= Math.Max(0.25, Power * ChargeTime) + ChargeGrace)
            {
                StopApproach(); _queuedHeight = -1; _chargeFrom = -1;
                return;
            }
            { _player.ApproachTo = sel.Feet; _player.Charging = true; _approaching = true; };   // run up to it
            return;
        }
        StopApproach();
        if (!_player.FaceToward(sel.Feet, dt) || _now < _nextSwing) return;
        if (_chargeFrom < 0 || _now - _chargeFrom < Power * ChargeTime) return;
        _chargeFrom = -1;
        // swing: a punch (high, medium) or kick (low) from your combat moves, faster the less power
        var weapon = Inv.Weapon;
        if (weapon != null && !weapon.IsMeleeWeapon && !weapon.IsMissileWeapon) { Hud.Log($"You can't fight with the {weapon.Name}.", CombatHud.Plain); _queuedHeight = -1; return; }
        uint stance = MyStance;
        var (motion, attackType) = PickManeuverAt(stance, _queuedHeight);
        if (motion == 0) { Hud.Log("You can't attack that way.", CombatHud.Plain); _queuedHeight = -1; return; }
        float speed = 1.5f - Power * 0.5f;
        _player.PlayAction(motion, speed);
        _swing = motion; _swingHeight = _queuedHeight; _swingAt = _now; _swingTarget = f; _swingType = attackType; _swingStarted = _now;
        float len = _creatures.ActionLength(_player.LookKey, stance, motion);
        if (len <= 0f) len = 1.0f;
        _nextSwing = _now + len / speed + Power * 0.8;
        _regenAt = _now + 10;
        // the creature notices
        if (f.St == Fighter.State.Idle) Aggro(f);
        if (!RepeatAttacks) _queuedHeight = -1;
    }

    private DatReaderWriter.Enums.AttackType _swingType;

    // ── on a server: the attack is asked of it (it works out the blows and says how they went) ──

    /// <summary>Asks the server to attack: the target, the height (0 high, 1 middle, 2 low), the power, whether with a missile weapon.</summary>
    public Action<ObjectStreamer.Selectable, int, float, bool>? NetAttack;
    public Action? NetCancelAttack;
    /// <summary>Tells the server the stance: 1 peace, 2 melee, 4 missile, 8 magic.</summary>
    public Action<int>? NetCombatMode;
    /// <summary>The server's own "Automatically Repeat Attacks" option (null till the options are read), and setting it:
    /// the server repeats a missile attack by itself while it's on, so Repeat Attacks off has to turn it off there too.</summary>
    public Func<bool?>? NetRepeatIs;
    public Action<bool>? NetRepeat;
    public Func<bool>? NetSettling;
    private bool _netAttacking;
    private double _netAttackAt;
    private ObjectStreamer.Selectable? _attackOn;   // (what the attack under way is at)

    private bool _cancelOnDone;     // (a single attack asked with Repeat Attacks off: the server's own repeat called off once it's done)
    private bool _repeatSynced;     // (the server's repeat option set to match at least once this login)

    /// <summary>The server says the attack it was asked for is over (the next can be asked).</summary>
    public void NetAttackDone()
    {
        _netAttacking = false;
        // Repeat Attacks off: the server may still repeat by itself (its own option on - not read yet, or set on elsewhere):
        // a swing went on and on, through a weapon change, till you left combat mode. Told it's over, as the game does
        // when you let go of the attack
        if (_cancelOnDone && !RepeatAttacks && _queuedHeight < 0)
        {
            _cancelOnDone = false;
            Godot.GD.Print("[attack] done - Repeat Attacks off: telling the server to stop");
            NetCancelAttack?.Invoke();
        }
        else Godot.GD.Print("[attack] done");
    }

    /// <summary>The server has you fall dead, or up again (at the lifestone).</summary>
    public void NetDied(bool dead)
    {
        if (dead)
        {
            _dead = true; _queuedHeight = -1; _swing = 0; _netAttacking = false;
            _deadUntil = double.MaxValue;   // (the server says when you're back)
            _player.Die();
            PlayDeathSound(_creatures.SoundTableOf(_player.LookKey), _player.Position);
        }
        else
        {
            _dead = false; CombatMode = false;
            _player.Revive();
        }
    }

    /// <summary>A creature of the server's fell dead: no more swinging at it, nothing more from it.</summary>
    public void NetCreatureDied(ObjectStreamer.Selectable sel)
    {
        if (Of(sel) is not { } f) return;
        f.St = Fighter.State.Dead; f.Health = 0; f.CorpseUntil = f.RespawnAt = double.MaxValue;
        if (_objects.Selected == sel) { _queuedHeight = -1; _netAttacking = false; }
    }

    /// <summary>A creature of the server's, how hurt it is (0-1).</summary>
    public void NetHealth(ObjectStreamer.Selectable sel, float part)
    {
        if (Of(sel) is not { } f) return;
        f.Health = (int)MathF.Round(Math.Clamp(part, 0f, 1f) * f.MaxHealth);
        // dead: no more swinging at it
        if (part <= 0f) { f.St = Fighter.State.Dead; f.CorpseUntil = f.RespawnAt = double.MaxValue; if (_objects.Selected == sel) { _queuedHeight = -1; _netAttacking = false; } }
    }

    /// <summary>A server's creature looked at closely: its health in the server's own numbers (till then only the part
    /// of it left is known, and it was shown as 1 of 1).</summary>
    public void NetHealthTold(ObjectStreamer.Selectable sel, int health, int max)
    {
        if (Of(sel) is not { } f || max <= 0) return;
        f.MaxHealth = max; f.Health = Math.Clamp(health, 0, max);
    }

    private void AttackRemote(Fighter f, float gap, float dt)
    {
        bool missile = Inv.Weapon is { IsMissileWeapon: true };
        if (!missile && gap > MaxMeleeRange * 0.9f)
        {
            _player.ApproachTo = f.Sel.Feet; _player.Charging = true; _approaching = true;   // run up to it
            return;
        }
        StopApproach();
        if (!_player.FaceToward(f.Sel.Feet, dt)) return;
        // (asked once; again when the server says that one's done - or it's been long enough that it must be)
        // (and never sooner than a swing takes: told "done" at once - the thing's dead, or out of reach - asking again
        // every frame kept the arm swinging without end)
        if (_netAttacking && _now - _netAttackAt < 6.0 || _now < _nextSwing) return;
        bool? srvRepeat = NetRepeatIs?.Invoke();
        if ((srvRepeat is bool sr && sr != RepeatAttacks) || (srvRepeat == null && !_repeatSynced))
        {
            NetRepeat?.Invoke(RepeatAttacks);
            Godot.GD.Print($"[attack] server repeat option {(srvRepeat == null ? "unknown" : srvRepeat.Value ? "on" : "off")} - set {(RepeatAttacks ? "on" : "off")}");
        }
        _repeatSynced = true;
        _netAttacking = true; _netAttackAt = _now;
        _cancelOnDone = !RepeatAttacks;
        Godot.GD.Print($"[attack] asked at {f.Sel.Name} ({(missile ? "missile" : "melee")}, repeat {(RepeatAttacks ? "on" : "off")})");
        NetAttack?.Invoke(f.Sel, _queuedHeight, Power, missile);
        float took = 1.2f;
        // the swing, so you see yourself attack (what it does is the server's to say)
        if (!missile)
        {
            var (motion, _) = PickManeuverAt(MyStance, _queuedHeight);
            float speed = 1.5f - Power * 0.5f;
            if (motion != 0)
            {
                _player.PlayAction(motion, speed);
                float len = _creatures.ActionLength(_player.LookKey, MyStance, motion);
                if (len > 0f) took = len / speed;
            }
        }
        _nextSwing = _now + took + Power * 0.8;
        if (!RepeatAttacks) { _queuedHeight = -1; _netAttacking = false; }
    }

    // running up to the target: only called off if combat started it (a plugin's route keeps its own)
    private bool _approaching;
    private void StopApproach() { if (_approaching) { _player.ApproachTo = null; _player.Charging = false; _approaching = false; } }

    // ── missile combat: shooting at the target from range, the arrow (or bolt, or dart) flying to it ──

    private sealed class Arrow { public MeshInstance3D Node = null!; public Fighter Target = null!; public Item Weapon = null!; public float PowerAt; }
    private readonly List<Arrow> _arrows = new();
    private double _releaseAt = -1;
    private Fighter? _shotAt;

    private void UpdateShooting(Fighter f, Item bow, float gap, float dt)
    {
        if (gap > MissileRange) { { _player.ApproachTo = f.Sel.Feet; _player.Charging = false; _approaching = true; }; return; }   // in range first
        StopApproach();
        if (!_player.FaceToward(f.Sel.Feet, dt) || _now < _nextSwing) return;
        uint stance = MyStance;
        var (motion, _) = PickManeuverAt(stance, _queuedHeight);
        if (motion == 0) (motion, _) = PickManeuverAt(stance, 1);
        // no shot in the maneuver table: the body's own shooting motion (draw, loose), as the game plays it
        if (motion == 0 || _creatures.ActionLength(_player.LookKey, stance, motion) <= 0f)
            foreach (var m in new[] { (uint)DatReaderWriter.Enums.MotionCommand.Shoot, (uint)DatReaderWriter.Enums.MotionCommand.MissileAttack1 })
                if (_creatures.ActionLength(_player.LookKey, stance, m) > 0f) { motion = m; break; }
        float speed = 1.5f - Power * 0.5f;
        if (motion != 0) _player.PlayAction(motion, speed);
        float len = motion != 0 ? _creatures.ActionLength(_player.LookKey, stance, motion) : 1f;
        if (len <= 0f) len = 1f;
        _releaseAt = _now + Math.Min(len / speed * 0.6f, 0.9f);   // the shot leaves partway through the draw
        _shotAt = f;
        _nextSwing = _now + len / speed + Power * 0.8;
        _regenAt = _now + 10;
        if (f.St == Fighter.State.Idle) Aggro(f);
        if (!RepeatAttacks) _queuedHeight = -1;
    }

    /// <summary>Arrows loosed and in flight (called every frame).</summary>
    private void UpdateArrows(float dt)
    {
        if (_releaseAt >= 0 && _now >= _releaseAt && _shotAt != null && Inv.Weapon is { IsMissileWeapon: true } bow)
        {
            _releaseAt = -1;
            var node = new MeshInstance3D
            {
                Mesh = new CylinderMesh { TopRadius = 0.015f, BottomRadius = 0.015f, Height = 0.8f, RadialSegments = 6 },
                MaterialOverride = new StandardMaterial3D { AlbedoColor = new Color(0.55f, 0.4f, 0.25f) },
                Position = _player.Position + new Vector3(0, 1.4f, 0),
            };
            AddChild(node);
            _arrows.Add(new Arrow { Node = node, Target = _shotAt, Weapon = bow, PowerAt = Power });
            _shotAt = null;
        }
        for (int i = _arrows.Count - 1; i >= 0; i--)
        {
            var a = _arrows[i];
            Vector3 to = a.Target.Sel.Center, d = to - a.Node.Position;
            float step = 30f * dt;
            if (d.Length() <= step || a.Target.St == Fighter.State.Dead || a.Target.Sel.Gone)
            {
                if (a.Target.St != Fighter.State.Dead && !a.Target.Sel.Gone) LandArrow(a);
                a.Node.QueueFree();
                _arrows.RemoveAt(i);
                continue;
            }
            a.Node.Position += d.Normalized() * step;
            // pointing along its flight (the cylinder's length is its Y)
            var dir = d.Normalized();
            var up = Math.Abs(dir.Y) > 0.99f ? Vector3.Right : Vector3.Up;
            a.Node.LookAt(a.Node.Position + dir, up);
            a.Node.RotateObjectLocal(Vector3.Right, MathF.PI / 2f);
        }
    }

    private void LandArrow(Arrow a)
    {
        var f = a.Target;
        if (f.St == Fighter.State.Idle || f.St == Fighter.State.Return) Aggro(f);
        int defense = Rules.CreatureSkill(f.W, Rules.MissileDefense);
        if (Rules.Rng.NextDouble() > Rules.SkillChance(Me.Skill(MissileWeapons), Math.Max(1, defense)))
        {
            Hud.Log($"{f.Sel.Name} evaded your attack.", CombatHud.Plain);
            return;
        }
        // (no ammunition yet: the weapon's own damage, or a fair amount for its tier, with coordination's bonus)
        int type = a.Weapon.DamageType != 0 ? Rules.FirstType(a.Weapon.DamageType) : Rules.Pierce;
        float max = a.Weapon.Damage > 0 ? a.Weapon.Damage : 8 + 4 * Math.Max(1, a.Weapon.Tier);
        var parts = f.W.BodyParts;
        float armor = parts.Count > 0 ? parts[Rules.Rng.Next(parts.Count)].Armor[Rules.ArmorIndex(type)] : 0f;
        float raw = Rules.RollDamage(max, a.Weapon.Variance > 0 ? a.Weapon.Variance : 0.4f) * Rules.AttributeMod(Me.Attribute(3)) * (a.PowerAt + 0.5f) * Rules.ArmorMod(armor);
        int dmg = Math.Max(1, (int)MathF.Round(raw));
        f.Health -= dmg;
        if (f.Health <= 0) { CreatureDies(f, type); return; }
        var (single, _) = Rules.AttackVerb(type, dmg / (float)f.MaxHealth);
        Hud.Log($"You {single} {f.Sel.Name} for {dmg} point{(dmg == 1 ? "" : "s")} of {Rules.TypeName(type)} damage!", CombatHud.Hit);
        PlayWoundSound(_creatures.SoundTableOf(f.Sel.Key), f.Sel.Center);
    }

    /// <summary>One of your attack moves for a stance and height (bare-handed: punches high and middling, kicks low).</summary>
    private (uint motion, DatReaderWriter.Enums.AttackType type) PickManeuverAt(uint stance, int height)
    {
        var t = Table(0x30000000u);
        if (t == null) return (0, 0);
        var moves = t.CombatManeuvers.Where(m => (uint)m.Style == stance && (int)m.AttackHeight - 1 == height
                                                 && _creatures.HasAction(_player.LookKey, stance, (uint)m.Motion)).ToList();
        if (stance == HandCombat)
        {
            var want = height == 2 ? DatReaderWriter.Enums.AttackType.Kick : DatReaderWriter.Enums.AttackType.Punch;
            var typed = moves.Where(m => m.AttackType == want).ToList();
            if (typed.Count > 0) moves = typed;
        }
        else
        {
            // single strikes only for now (double and triple strikes need the weapon's own attack types)
            var single = moves.Where(m => m.AttackType is DatReaderWriter.Enums.AttackType.Slash or DatReaderWriter.Enums.AttackType.Thrust).ToList();
            if (single.Count > 0) moves = single;
        }
        if (moves.Count == 0) return (0, 0);
        var pick = moves[Rules.Rng.Next(moves.Count)];
        return ((uint)pick.Motion, pick.AttackType);
    }

    private void OnPlayerHooks(IReadOnlyList<AnimationHook> hooks)
    {
        if (_swing == 0) return;
        foreach (var h in hooks) if (h is AttackHook) { LandPlayerBlow(); break; }
    }

    /// <summary>Your blow lands (or it's evaded): your attack against its defense; damage from your strength and power, less its armor.</summary>
    private void LandPlayerBlow()
    {
        _swing = 0;
        var f = _swingTarget;
        _swingTarget = null;
        if (f == null || f.St == Fighter.State.Dead || f.Sel.Gone || Gap(f) > MaxMeleeRange + 1.0f) return;
        if (f.St == Fighter.State.Idle || f.St == Fighter.State.Return) Aggro(f);
        if (Rules.Rng.NextDouble() > Rules.SkillChance(PAttack, f.Defense))
        {
            Hud.Log($"{f.Sel.Name} evaded your attack.", CombatHud.Plain);
            return;
        }
        // the body part struck: by the attack's height
        var parts = f.W.BodyParts;
        SpawnData.BodyPart? part = null;
        float total = parts.Sum(p => HeightWeight(p, _swingHeight));
        if (total > 0f)
        {
            float r = (float)Rules.Rng.NextDouble() * total;
            foreach (var p in parts) { r -= HeightWeight(p, _swingHeight); if (r <= 0f) { part = p; break; } }
            part ??= parts[^1];
        }
        // the weapon's damage (its type by the blow: a thrust pierces, a slash slashes), or your fists'; dual
        // wielding, the blows come from each hand in turn
        var weapon = Inv.Weapon;
        bool dual = Inv.OffHand != null && weapon != null && weapon.IsMeleeWeapon;
        if (dual) { _offHandTurn = !_offHandTurn; if (_offHandTurn) weapon = Inv.OffHand; }
        int type = Rules.Bludgeon;
        float max = PunchDamage, variance = PunchVariance;
        if (weapon != null && weapon.IsMeleeWeapon)
        {
            max = weapon.Damage; variance = weapon.Variance;
            int types = weapon.DamageType;
            type = _swingType == DatReaderWriter.Enums.AttackType.Thrust && (types & Rules.Pierce) != 0 ? Rules.Pierce
                 : _swingType == DatReaderWriter.Enums.AttackType.Slash && (types & Rules.Slash) != 0 ? Rules.Slash
                 : Rules.FirstType(types);
        }
        float armor = part != null ? part.Armor[Rules.ArmorIndex(type)] : 0f;
        float raw = Rules.RollDamage(max, variance) * Rules.AttributeMod(PStrength) * (Power + 0.5f) * Rules.ArmorMod(armor);
        // the Dual Wield skill: more damage while fighting with a weapon in each hand
        if (dual) raw *= 1f + Math.Min(0.5f, Me.Skill(DualWieldSkill) / 1000f);
        int dmg = Math.Max(1, (int)MathF.Round(raw));
        var (single, _) = Rules.AttackVerb(type, dmg / (float)f.MaxHealth);
        f.Health -= dmg;
        if (f.Health <= 0) { CreatureDies(f, type); return; }
        Hud.Log($"You {single} {f.Sel.Name} for {dmg} point{(dmg == 1 ? "" : "s")} of {Rules.TypeName(type)} damage!", CombatHud.Hit);
        PlayWoundSound(_creatures.SoundTableOf(f.Sel.Key), f.Sel.Center);
    }

    /// <summary>
    /// A spell striking a creature (a war bolt): resisted by its magic defense against your skill, then the damage
    /// (its armor doesn't count, as for spells); it fights back if it wasn't already.
    /// </summary>
    public void SpellHit(Fighter f, int damage, int type, string spell, int casterSkill)
    {
        if (f.St == Fighter.State.Dead || f.Sel.Gone) return;
        if (f.St == Fighter.State.Idle || f.St == Fighter.State.Return) Aggro(f);
        int resist = Rules.CreatureSkill(f.W, Rules.MagicDefense);
        if (resist > 0 && Rules.Rng.NextDouble() > Rules.SkillChance(casterSkill, resist))
        {
            Hud.Log($"{f.Sel.Name} resists your {spell}.", CombatHud.Plain);
            return;
        }
        f.Health -= damage;
        if (f.Health <= 0) { CreatureDies(f, type); return; }
        var (single, _) = Rules.AttackVerb(type, damage / (float)f.MaxHealth);
        Hud.Log($"You {single} {f.Sel.Name} for {damage} point{(damage == 1 ? "" : "s")} of {Rules.TypeName(type)} damage with {spell}!", CombatHud.Hit);
        PlayWoundSound(_creatures.SoundTableOf(f.Sel.Key), f.Sel.Center);
    }

    /// <summary>The selected creature's fighting state, if it fights and is alive.</summary>
    public Fighter? SelectedFighter => _objects.Selected is { } s && Of(s) is { } f && f.St != Fighter.State.Dead ? f : null;

    private static float HeightWeight(SpawnData.BodyPart p, int height) => height switch { 0 => p.High, 1 => p.Mid, _ => p.Low };

    private void PlayerDies(Fighter killer, int type)
    {
        Health = 0;
        _dead = true;
        _queuedHeight = -1; _swing = 0;
        _deadUntil = _now + 6.0;
        _player.Die();
        PlayDeathSound(_creatures.SoundTableOf(_player.LookKey), _player.Position);
        Hud.Log(Rules.DeathOfYou(type, killer.Sel.Name), CombatHud.Hurt);
        float vitae = Me.LoseVitae();
        Hud.Log($"You've lost some of your vitality. Your vitae penalty is now {(1f - vitae) * 100:0}%.", CombatHud.Hurt);
        Me.Save(Inv);
        foreach (var f in _active) if (f.St == Fighter.State.Chase) { f.St = Fighter.State.Return; f.SwingMotion = 0; }
    }
}
