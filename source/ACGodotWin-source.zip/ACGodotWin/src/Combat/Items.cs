using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using ACGodot.Creatures;
using Godot;

namespace ACGodot.Combat;

/// <summary>A thing you can carry: one made from a weenie (as it comes, or as death treasure made it).</summary>
public sealed class Item
{
    public int Wcid;
    public string Name = "";
    /// <summary>What it's made of (the server's material number; 0: nothing told).</summary>
    public int Material;
    public const int TypeSalvage = 0x40000000;
    /// <summary>Its name as the game shows it: what it's made of first ("Copper Salvage (100)", "Ivory Sceptre").</summary>
    public string Shown => Material != 0 && ACGodot.Net.NetGame.Materials.TryGetValue(Material, out var m) && !Name.StartsWith(m) ? $"{m} {Name}" : Name;
    public uint Icon, Setup;
    /// <summary>Pictures the server lays under and over the icon (a coloured backing; a mark in the corner); 0: none.</summary>
    public uint IconUnder, IconOver;
    /// <summary>A missile weapon's or its ammunition's kind, as the server gives it (1 bow and arrows, 2 crossbow and quarrels, 4 atlatl and darts; 0: neither).</summary>
    public int AmmoType;
    private static readonly Dictionary<(uint under, uint icon, uint over), Texture2D?> _layered = new();

    /// <summary>The game's backing picture for a kind of item (0: a kind we don't know - no backing).</summary>
    public static uint BackingFor(int itemType)
    {
        uint t = (uint)itemType;
        if (t == 0) return 0;
        if ((t & 0x8000) != 0) return 0x060011CA;        // a wand, staff or orb: bright blue
        if ((t & 0x1) != 0) return 0x060011CB;           // a melee weapon: red
        if ((t & 0x100) != 0) return 0x060011D2;         // a missile weapon or its ammunition: red, banded
        if ((t & 0x2) != 0) return 0x060011CF;           // armor: blue
        if ((t & 0x4) != 0) return 0x060011F3;           // clothing: light blue
        if ((t & 0x8) != 0) return 0x060011D5;           // jewelry: purple
        if ((t & 0x20) != 0) return 0x060011CC;          // food: its plate
        if ((t & (0x40 | 0x40000)) != 0) return 0x060011F4;   // money, trade notes: dark green
        if ((t & 0x200) != 0) return 0x060011CE;         // a pack: green
        if ((t & (0x800 | 0x80000)) != 0) return 0x060011D3;  // a gem, a mana stone: dark blue
        if ((t & 0x1000) != 0) return 0x060011CD;        // spell components: steel
        if ((t & 0x2000) != 0) return 0x060011D4;        // something written: brown
        if ((t & 0x10) != 0) return 0x060011D1;          // a creature
        return 0x060011D0;                               // anything else: dark grey
    }
    /// <summary>Its icon as the game shows it: the backing, the icon, the mark over it - one picture (kept once made).</summary>
    public Texture2D? Picture(Func<uint, Texture2D?> icon)
    {
        // (the backing the game puts behind every item's icon: the server's own for it, else the one for its kind)
        uint under = IconUnder != 0 ? IconUnder : BackingFor(ItemType);
        if (under == 0 && IconOver == 0) return icon(Icon);
        var key = (under, Icon, IconOver);
        if (_layered.TryGetValue(key, out var made)) return made;
        Texture2D? result = icon(Icon);
        try
        {
            Image? all = null;
            foreach (uint id in new[] { under, Icon, IconOver })
            {
                if (id == 0 || icon(id)?.GetImage() is not { } layer) continue;
                if (layer.IsCompressed()) layer.Decompress();
                layer.Convert(Image.Format.Rgba8);
                // (a mark over it that's solid all over - Top's green "N" tile, one of the backing squares - would hide the
                // item: the game doesn't draw it, and neither do we)
                if (id == IconOver && id != under && layer.DetectAlpha() == Image.AlphaMode.None) continue;
                if (all == null) { all = Image.CreateEmpty(layer.GetWidth(), layer.GetHeight(), false, Image.Format.Rgba8); }
                if (layer.GetWidth() != all.GetWidth() || layer.GetHeight() != all.GetHeight()) layer.Resize(all.GetWidth(), all.GetHeight(), Image.Interpolation.Nearest);
                all.BlendRect(layer, new Rect2I(0, 0, all.GetWidth(), all.GetHeight()), Vector2I.Zero);
            }
            if (all != null) result = ImageTexture.CreateFromImage(all);
        }
        catch (Exception ex) { GD.PushWarning("icon layers: " + ex.Message); }
        return _layered[key] = result;
    }
    public int Value, Burden, Stack = 1, ItemType, Locations, ArmorLevel, Coverage;
    /// <summary>The cooldown it shares with its like (0: none), and how long that runs once it's used.</summary>
    public int CooldownId;
    public double CooldownTime;
    /// <summary>The cooldowns running, as the server tells them: when each ends (the clock's seconds) and how long it was.</summary>
    public static readonly Dictionary<int, (double ends, double total)> Cooldowns = new();
    /// <summary>Seconds until it can be used again (0: ready).</summary>
    public double CoolSeconds => CooldownId != 0 && Cooldowns.TryGetValue(CooldownId, out var c) ? Math.Max(0, c.ends - Time.GetTicksMsec() / 1000.0) : 0;
    /// <summary>What hovering over it says: its name, how many, its uses left, and how long until it's ready again.</summary>
    public string HoverText(int count = 0)
    {
        string s = Shown;
        if (count > 1 || Stack > 1) s += $"\nCount: {Math.Max(count, Stack)}";
        if (MaxUses > 0 && (ItemType & TypeSalvage) == 0) s += $"\nUses left: {Uses} of {MaxUses}";
        if (MaxMana > 0) s += $"\nMana: {Mana} of {MaxMana}";
        if (BuiltIn.Length > 0) s += "\n" + BuiltIn;
        if (ProcSpell.Length > 0) s += "\nCast on Strike: " + ProcSpell;
        double cs = CoolSeconds;
        if (cs > 0) s += $"\nReady in {Math.Ceiling(cs):0} s";
        else if (CooldownId != 0 && CooldownTime > 0) s += $"\nCooldown: {CooldownTime:0.#} s";
        return s;
    }
    /// <summary>How much of its cooldown is still to run (0: ready to use, 1: just used).</summary>
    public float Cooling
    {
        get
        {
            if (CooldownId == 0 || !Cooldowns.TryGetValue(CooldownId, out var c)) return 0;
            double left = c.ends - Time.GetTicksMsec() / 1000.0;
            return left <= 0 ? 0 : (float)Math.Clamp(left / Math.Max(1, c.total), 0.02, 1);
        }
    }
    public int Damage, DamageType, WeaponSkill, WeaponTime, CombatStyle, MaxStack;
    /// <summary>Uses left of a healing kit or lockpick (shown like a stack's count), and its most.</summary>
    public int Uses, MaxUses;
    /// <summary>The mana in a mana stone (or charge) and the most it holds (shown as a blue bar).</summary>
    public int Mana, MaxMana;
    /// <summary>Its colours (clothing: the palette template and shade it's dyed with; 0 its own).</summary>
    public int PaletteTemplate;
    public float Shade;
    public float Variance;
    public int Tier;
    public bool Magical;
    /// <summary>A magic item's spells (by id): they work while it's worn.</summary>
    public List<int> Spells = new();
    /// <summary>Names the spells (the magic system, once there).</summary>
    public static Func<Item, string>? SpellNames;
    public int WornAt;          // where it's worn or wielded (the slots it fills), 0 in the pack
    /// <summary>
    /// Its own number, kept with it (saved with your character): plugins know an item by its id, and MelkTank keeps
    /// those ids in its settings - numbered afresh each run, the shield on its list came back as the Flamberge.
    /// </summary>
    public int Uid;
    public static int NextUid = 1;
    /// <summary>On a server: the server's id for it (0 playing alone). What's done with it is asked of the server.</summary>
    public uint Guid;
    /// <summary>What the server says of it when appraised (how it's used, its description).</summary>
    public string Notes = "";
    /// <summary>"Properties: ..." as the panel shows it (imbues, slayer, rends, cleave, attuned...), from appraising it.</summary>
    public string Properties = "";
    /// <summary>A set item's built-in buff (an aetheria's: its set's spells at its level) and its ratings, as lines; the spell it casts on strike.</summary>
    public string BuiltIn = "", ProcSpell = "";
    /// <summary>"This item has been tinkered N times.", "Imbued by ...", "Last tinkered by ..." - from appraising it.</summary>
    public string TinkerNotes = "";
    /// <summary>What using it asks of you and its cooldown, as the server told when it was looked at.</summary>
    public string UseNotes = "", TopNotes = "";
    /// <summary>The side pack it's in (that pack's server id), 0 in the main pack.</summary>
    public uint Holder;
    /// <summary>A pack: how many things it holds (0: not a pack, or not said).</summary>
    public int Capacity;
    /// <summary>How it's used, as the server says (0: not said). Its upper half names what it's used on: a thing with one needs a target.</summary>
    public int Useable;
    public bool NeedsTarget => (Useable >> 16) != 0;
    /// <summary>What of a weapon spells have raised or lowered, as the server marks it (speed 4, damage 8...): shown green or red.</summary>
    public int Raised, Lowered;
    /// <summary>How it looks as a server describes it (a look number: its own model and colours; 0: as its kind looks in the
    /// game's files), and the number to draw it by.</summary>
    public int Look;
    public int ShownAs => Look != 0 ? Look : Wcid;
    /// <summary>All the server told of it when it was last looked at closely (null: not yet): its numbers, decimals, words
    /// and yes/no's by the game's own property numbers - what plugins read an item's details from.</summary>
    public Dictionary<int, int>? PropInts;
    public Dictionary<int, double>? PropFloats;
    public Dictionary<int, string>? PropStrings;
    public Dictionary<int, bool>? PropBools;
    /// <summary>Its big numbers (the server's own among them), as last told.</summary>
    public Dictionary<int, long>? PropInt64s;
    /// <summary>Armor's protection against each kind of damage, as told (slash, pierce, bludgeon, cold, fire, acid, nether, lightning).</summary>
    public float[]? Prots;
    /// <summary>A weapon's, as told: its damage modifier (a bow's), attack bonus, and a missile's speed.</summary>
    public double DamageMod, WeaponOffense, MaxVelocity;
    private string Marked(string text, int bit) => (Raised & bit) != 0 ? Green + text + "[/color]" : (Lowered & bit) != 0 ? "[color=#ff5a5a]" + text + "[/color]" : text;

    // item types (ACE ItemType) and where things go (EquipMask)
    public const int TypeMeleeWeapon = 1, TypeArmor = 2, TypeClothing = 4, TypeJewelry = 8, TypeMoney = 64, TypeGem = 0x800,
                     TypeMissileWeapon = 0x100, TypeCaster = 0x8000;
    public const int SlotMelee = 0x100000, SlotShield = 0x200000, SlotMissile = 0x400000, SlotAmmo = 0x800000, SlotHeld = 0x1000000, SlotTwoHanded = 0x2000000;

    public bool IsCoins => Wcid == 273 || (ItemType & TypeMoney) != 0;
    public bool IsMeleeWeapon => Damage > 0 && (Locations & (SlotMelee | SlotTwoHanded)) != 0;
    public bool IsMissileWeapon => (Locations & SlotMissile) != 0;
    /// <summary>Boots only ever cover the feet (whatever else their places say) - a robe down to the feet covers the legs too.</summary>
    /// <summary>
    /// The places a thing shows in when worn: for the server's things, by what the server says they cover - boots list
    /// the lower leg as a place and cover the feet alone, so they show on the feet alone; a robe that covers the lower
    /// legs keeps them. (The game's own data, with no word on what's covered: the rule of thumb below.)
    /// </summary>
    public static int Feet(Item it, int loc) =>
        it.Coverage == 0 ? Feet(loc) : (it.Coverage & (0x200 | 0x4)) == 0 ? loc & ~(0x80 | 0x4000) : loc;
    public static int Feet(int loc) => (loc & 0x100) != 0 && (loc & (0x2000 | 0x40 | 0x200 | 0x2 | 0x400 | 0x4)) == 0 ? loc & ~(0x80 | 0x4000) : loc;
    /// <summary>A missile weapon's kind, by its combat style (bow 0x10, crossbow 0x20, sling/thrown/atlatl 0x40/0x80/0x400), else its name.</summary>
    // a bow by any sign of one - the arrows it takes, its style, its name (a bow's style can say thrown: Crowfoot);
    // likewise a crossbow; thrown only when nothing says bow or crossbow
    public string MissileKind
    {
        get
        {
            int ammo = PropInts != null && PropInts.TryGetValue(50, out int a) ? a : 0;
            if ((ammo & (2 | 16 | 128)) != 0 || (CombatStyle & 0x20) != 0 || Name.Contains("Crossbow", StringComparison.OrdinalIgnoreCase)) return "Crossbow";
            if ((ammo & (1 | 8 | 64)) != 0 || (CombatStyle & 0x10) != 0 || Name.Contains("Bow", StringComparison.OrdinalIgnoreCase)) return "Bow";
            // thrown only on a sign of it (atlatl darts, a sling, a throwing weapon): a launcher that says nothing of
            // itself - Crowfoot, Vihaya - is a bow
            string n = Name.ToLowerInvariant();
            if ((ammo & (4 | 32 | 256)) != 0 || (CombatStyle & (0x40 | 0x80 | 0x400 | 0x800)) != 0
                || n.Contains("atlatl") || n.Contains("dart") || n.Contains("javelin") || n.Contains("throwing") || n.Contains("shuriken")
                || n.Contains("djarid") || n.Contains("sling") || n.Contains("star") || n.Contains("axe") || n.Contains("club")) return "Thrown";
            return "Bow";
        }
    }
    public bool Wearable => Locations != 0;

    /// <summary>Another of the same (a stack split off).</summary>
    public Item Copy() { var c = (Item)MemberwiseClone(); c.Spells = new List<int>(Spells); c.WornAt = 0; c.Uid = NextUid++; c.Guid = 0; return c; }

    public static Item? Make(SpawnData data, int wcid)
    {
        var w = data.Get(wcid);
        if (w == null) return null;
        return new Item
        {
            Uid = NextUid++,
            Wcid = wcid, Name = w.Name, Icon = w.Icon, Setup = w.Setup, Value = w.Value, Burden = w.Burden, ItemType = w.ItemType,
            Locations = w.ValidLocations, ArmorLevel = w.ArmorLevel, Coverage = w.ClothingPriority,
            Damage = w.Damage, DamageType = w.DamageType, WeaponSkill = w.WeaponSkill, WeaponTime = w.WeaponTime, Variance = w.DamageVariance, CombatStyle = w.CombatStyle, MaxStack = w.MaxStack,
            Uses = w.MaxUses > 0 ? (w.Uses > 0 ? w.Uses : w.MaxUses) : 0, MaxUses = w.MaxUses, Mana = w.Mana, MaxMana = w.MaxMana,
        };
    }

    /// <summary>A skill's name by its id, and a spell's name and description (set once the character and magic are there).</summary>
    public static Func<int, string?>? SkillNameOf;
    public static Func<int, (string name, string description)?>? SpellInfo;

    private const string Green = "[color=#7CFF7C]";

    /// <summary>
    /// What identifying it shows (the examine panel), laid out as the game's: value, burden; a weapon's skill,
    /// damage, speed and bonuses, or armor's coverage, armor level and protections (lit green); its spells, and
    /// what each does. BBCode colours.
    /// </summary>
    public string Appraisal()
    {
        var l = new List<string>();
        if (IsCoins) { l.Add($"Value: {Stack:N0}"); return string.Join("\n", l); }
        l.Add($"Value: {Value:N0}");
        l.Add($"Burden: {Burden:N0}");
        if (Stack > 1) l.Add($"Stack: {Stack:N0}");
        if (MaxUses > 0 && UseNotes.Length == 0 && (ItemType & TypeSalvage) == 0) l.Add($"Number of uses remaining: {Uses}");
        if (TopNotes.Length > 0) l.Add(TopNotes);
        if (MaxMana > 0) l.Add($"Mana: {Mana:N0} / {MaxMana:N0}");
        // (tinkering: below the mana, above the weapon's damage - where the game's panel has it)
        if (TinkerNotes.Length > 0) { l.Add(""); l.Add(TinkerNotes); }
        if (Damage > 0 || IsMissileWeapon)
        {
            l.Add("");
            string skill = WeaponSkillName;
            string kind = IsMissileWeapon ? (MissileKind == "Thrown" ? "Thrown Weapon" : MissileKind) : "";
            if (skill.Length > 0) l.Add($"Skill: {skill}" + (kind.Length > 0 ? $" ({kind})" : ""));
            if (IsMissileWeapon)
            {
                l.Add("Damage Bonus: 0");
                if (Damage > 0) l.Add($"Damage Modifier: +{Damage}%.");
            }
            else l.Add(Marked($"Damage: {Math.Round(Damage * (1 - Variance))} - {Damage}, {Rules.TypeName(Rules.FirstType(DamageType))}", 8));
            if (WeaponTime > 0) l.Add(Marked($"Speed: {SpeedName(WeaponTime)} ({WeaponTime})", 4));
            if (IsMissileWeapon) { l.Add("Range: 80 yds."); l.Add(kind == "Crossbow" ? "Uses quarrels as ammunition." : kind == "Bow" ? "Uses arrows as ammunition." : ""); }
        }
        // a weapon's or caster's bonuses, as the game lists them above the spells: elemental damage vs monsters (a
        // caster's), attack, the defenses, mana conversion. These are the server's numbers as told - a power-reduced
        // item (out of its zone) is told its reduced ones, so those show. (Infinite Leaftide's T11+ casters say theirs in
        // their own description: not said twice)
        if (PropFloats is { } pf && !Notes.Contains("vs. Monsters", StringComparison.OrdinalIgnoreCase))
        {
            var bonus = new List<string>();
            static string P(double m) => (m >= 1 ? "+" : "") + ((m - 1) * 100).ToString(Math.Abs(m - 1) * 100 >= 100 ? "N0" : "0.#") + "%";
            if (pf.TryGetValue(152, out double elem) && elem > 1.0)
            {
                int dt = PropInts != null && PropInts.TryGetValue(45, out int t45) ? t45 : DamageType;
                string el = dt != 0 ? Rules.TypeName(Rules.FirstType(dt)) : "elemental";
                bonus.Add($"Damage bonus for {char.ToUpper(el[0]) + el[1..]} spells:");
                bonus.Add($"   vs. Monsters: {P(elem)}.");
                bonus.Add($"   vs. Players: {P(1 + (elem - 1) * 0.25)}.");
            }
            if (pf.TryGetValue(62, out double off) && off > 1.0) bonus.Add($"Bonus to Attack Skill: {P(off)}.");
            if (pf.TryGetValue(29, out double md) && md > 1.0) bonus.Add($"Bonus to Melee Defense: {P(md)}.");
            if (pf.TryGetValue(149, out double msd) && msd > 1.0) bonus.Add($"Bonus to Missile Defense: {P(msd)}.");
            if (pf.TryGetValue(150, out double mgd) && mgd > 1.0) bonus.Add($"Bonus to Magic Defense: {P(mgd)}.");
            if (pf.TryGetValue(144, out double mc) && mc > 1.0) bonus.Add($"Bonus to Mana Conversion: {P(mc)}.");
            if (bonus.Count > 0) { l.Add(""); l.AddRange(bonus); }
        }
        if ((ItemType & (TypeArmor | TypeClothing)) != 0 && Covers() is { Length: > 0 } cov && ArmorLevel <= 0) { l.Add(""); l.Add($"Covers {cov}"); }
        if (ArmorLevel > 0)
        {
            l.Add("");
            string covers = Covers();
            if (covers.Length > 0) { l.Add($"Covers {covers}"); l.Add(""); }
            // green only while spells are raising it (worn, with its spells on); otherwise plain white
            bool lit = WornAt != 0 && Spells.Any(id => SpellInfo?.Invoke(id)?.name is string n
                                                      && (n.StartsWith("Impenetrability") || n.Contains("Bane") || n.StartsWith("Brogard")));
            string on = lit ? Green : "", off = lit ? "[/color]" : "";
            l.Add($"{on}Armor Level: {ArmorLevel:N0}{off}");
            foreach (var t in new[] { "Slashing", "Piercing", "Bludgeoning", "Fire", "Cold", "Acid", "Electric", "Nether" })
                l.Add($"{on}{t}: {Protection(1.0)}  ({ArmorLevel:N0}){off}");
        }
        if (BuiltIn.Length > 0) { l.Add(""); l.Add(BuiltIn); }
        if (Properties.Length > 0) { l.Add(""); l.Add(Properties); }
        if (Spells.Count > 0)
        {
            l.Add("");
            var names = Spells.Select(id => SpellInfo?.Invoke(id)?.name ?? $"#{id}");
            l.Add("Spells: " + string.Join(", ", names));
            l.Add("");
            l.Add("Spell Descriptions:");
            foreach (var id in Spells)
                if (SpellInfo?.Invoke(id) is { } sp) l.Add($"~ {sp.name}: {sp.description}");
        }
        else if (Magical) { l.Add(""); l.Add("This item is magical."); }
        if (Notes.Length > 0) { l.Add(""); l.Add(Notes); }
        if (UseNotes.Length > 0) { l.Add(""); l.Add(UseNotes); if (MaxUses > 0 && (ItemType & TypeSalvage) == 0) l.Add($"Number of uses remaining: {Uses}"); }
        return string.Join("\n", l).TrimEnd('\n').Replace("\n\n\n", "\n\n");
    }

    /// <summary>The level an item that levels up is at (an aetheria's): from its experience, as the game works it out (0: doesn't level).</summary>
    public static int ItemLevelOf(Dictionary<int, int> ints, Dictionary<int, long>? longs)
    {
        if (longs == null || !longs.TryGetValue(5, out long bx) || bx <= 0 || !ints.TryGetValue(319, out int max) || max <= 0 || !ints.TryGetValue(320, out int style) || style <= 0) return 0;
        ulong got = longs.TryGetValue(4, out long tx) && tx > 0 ? (ulong)tx : 0, b = (ulong)bx;
        int level = 0;
        switch (style)
        {
            case 1: level = (int)(got / b); break;
            case 2: { ulong need = b, left = got; while (left >= need) { level++; left -= need; need *= 2; } break; }
            case 3: level = got >= b && got < b * 3 ? 1 : got >= b ? (int)((got - b) / b) : 0; break;
        }
        return Math.Min(level, max);
    }

    static readonly string[] SetNames = { "Defense", "Destruction", "Fury", "Growth", "Vigor" };

    /// <summary>A set item's built-in buff (its set's spells at its level - an aetheria's sigil) and below it its
    /// ratings (damage, damage resist, crit, crit damage...), as lines for the ID panel and the hover.</summary>
    public static string BuiltInLines(Dictionary<int, int> ints, Dictionary<int, long>? longs, bool ratings = true)
    {
        var l = new List<string>();
        if (ints.TryGetValue(265, out int set) && set > 0)
        {
            int level = ItemLevelOf(ints, longs);
            var ids = ACGodot.Magic.MagicSystem.SetSpellsAt(set, level > 0 ? level : 1);
            // an aetheria: "Sigil: Sigil of ..." and under it what its built-in buff gives at its level (the set spell's own
            // words - its damage / damage resist / crit / crit damage); another set item: the set's spells
            if (set is >= 35 and <= 39)
            {
                l.Add("Sigil: Sigil of " + SetNames[set - 35]);
                foreach (int id in ids) if (SpellInfo?.Invoke(id) is { } sp) l.Add(sp.description.Length > 0 ? sp.description : sp.name);
            }
            else if (ids.Count > 0) l.Add("Set: " + string.Join(", ", ids.Select(id => SpellInfo?.Invoke(id)?.name ?? $"#{id}")));
        }
        // (its ratings - a T11+ Infinite Leaftide item says its own in its description: not said twice)
        void R(int key, string name) { if (ratings && ints.TryGetValue(key, out int v) && v != 0) l.Add($"{name}: {(v > 0 ? "+" : "")}{v}"); }
        R(370, "Damage Rating"); R(371, "Damage Resist Rating"); R(372, "Crit Rating"); R(374, "Crit Damage Rating"); R(373, "Crit Resist Rating"); R(375, "Crit Damage Resist Rating");
        R(376, "Heal Boost Rating"); R(379, "Vitality Rating"); R(377, "Nether Resist Rating"); R(378, "Life Resist Rating");
        R(388, "Overpower Rating"); R(389, "Overpower Resist Rating"); R(383, "PK Damage Rating"); R(384, "PK Damage Resist Rating");
        return string.Join("\n", l);
    }

    // ACE's creature types, for a slayer's name
    private static readonly string[] CreatureTypes = { "", "Olthoi", "Banderling", "Drudge", "Mosswart", "Lugian", "Tumerok", "Mite", "Tusker",
        "Phyntos Wasp", "Rat", "Auroch", "Cow", "Golem", "Undead", "Gromnie", "Reedshark", "Armoredillo", "Fae", "Virindi", "Wisp", "Knathtead",
        "Shadow", "Mattekar", "Mumiyah", "Rabbit", "Sclavus", "Shallows Shark", "Monouga", "Zefir", "Skeleton", "Human", "Shreth", "Chittick",
        "Moarsman", "Olthoi Larvae", "Slithis", "Deru", "Fire Elemental", "Snowman", "Unknown", "Bunny", "Lightning Elemental", "Rockslide",
        "Grievver", "Niffis", "Ursuin", "Crystal", "Hollow Minion", "Scarecrow", "Idol", "Empyrean", "Hopeslayer", "Doll", "Marionette", "Carenzi",
        "Siraluun", "Aun Tumerok", "Hea Tumerok", "Simulacrum", "Acid Elemental", "Frost Elemental", "Elemental", "Statue", "Wall", "Altered Human",
        "Device", "Harbinger", "Dark Sarcophagus", "Chicken", "Gotrok Lugian", "Margul", "Bleached Rabbit", "Nasty Rabbit", "Grimacing Rabbit",
        "Burun", "Target", "Ghost", "Fiun", "Eater", "Penguin", "Ruschk", "Thrungus", "Viamontian Knight", "Remoran", "Swarm", "Moar",
        "Enchanted Arms", "Sleech", "Mukkir", "Merwart", "Food", "Paradox Olthoi", "Harvest", "Energy", "Apparition", "Aerbax", "Touched",
        "Blighted Moarsman", "Gear Knight", "Gurog", "Anekshay" };
    public static string CreatureTypeName(int t) => t > 0 && t < CreatureTypes.Length ? CreatureTypes[t] : $"type {t}";

    /// <summary>A weapon's (or a shield's, a necklace's) properties as the game's panel lists them: imbues, slayer, rends,
    /// cleave, multi-strike, magic absorb, cast on strike - names, comma separated (Cleave with its count).</summary>
    public static List<string> PropertyNames(Dictionary<int, int> ints, Dictionary<int, double> floats, Dictionary<int, uint> dids, bool caster)
    {
        var p = new List<string>();
        int imbue = 0;
        foreach (int k in new[] { 179, 303, 304, 305, 306 }) if (ints.TryGetValue(k, out int v)) imbue |= v;
        if ((imbue & 0x1) != 0) p.Add("Critical Strike");
        if ((imbue & 0x2) != 0) p.Add("Crippling Blow");
        if (floats.TryGetValue(147, out double cf) && cf > 0) p.Add("Biting Strike");
        if (floats.TryGetValue(136, out double cm) && cm > 1) p.Add("Crushing Blow");
        if ((imbue & 0x4) != 0) p.Add("Armor Rending");
        if (ints.TryGetValue(166, out int slay) && slay > 0) p.Add(CreatureTypeName(slay) + " Slayer");
        foreach (var (bit, name) in new[] { (0x8, "Slash"), (0x10, "Pierce"), (0x20, "Bludgeon"), (0x40, "Acid"), (0x80, "Cold"), (0x100, "Lightning"), (0x200, "Fire"), (0x4000, "Nether") })
            if ((imbue & bit) != 0) p.Add(name + " Rending");
        // resistance cleaving (a weapon that lowers one element's resistance)
        if (ints.TryGetValue(263, out int rct) && rct != 0 && floats.TryGetValue(157, out double rcm) && rcm > 0)
            p.Add("Resistance Cleaving: " + char.ToUpper(Rules.TypeName(Rules.FirstType(rct))[0]) + Rules.TypeName(Rules.FirstType(rct))[1..]);
        if (floats.TryGetValue(155, out double ia) && ia > 0 && ia < 1) p.Add("Armor Cleaving");
        if (floats.TryGetValue(151, out double ish) && ish > 0) p.Add("Shield Cleaving");
        if ((imbue & 0x400) != 0) p.Add("Melee Defense");
        if ((imbue & 0x800) != 0) p.Add("Missile Defense");
        if ((imbue & 0x1000) != 0) p.Add("Magic Defense");
        if (ints.TryGetValue(292, out int cleave) && cleave > 1) p.Add($"Cleave +{cleave - 1}");
        if (!caster && ints.TryGetValue(47, out int attack) && (attack & 0x79E0) != 0) p.Add("Multi-Strike");
        if (floats.TryGetValue(159, out double absorb) && absorb > 0) p.Add("Magic Absorb");
        if (floats.TryGetValue(156, out double proc) && proc > 0)
            p.Add(dids.TryGetValue(55, out uint ps) && ps != 0 && SpellInfo?.Invoke((int)ps) is { } sp ? "Cast on Strike: " + sp.name : "Cast on Strike");
        return p;
    }

    /// <summary>The skill a weapon is used with, as the game names it now (old skills map to their new ones).</summary>
    public string WeaponSkillName
    {
        get
        {
            if (IsMissileWeapon) return "Missile Weapons";
            if ((Locations & SlotTwoHanded) != 0 || WeaponSkill == 41) return "Two Handed Combat";
            int s = WeaponSkill switch { 4 or 10 or 13 => 46, 1 or 5 or 9 or 11 => 44, 2 or 3 or 8 or 12 => 47, _ => WeaponSkill };
            return s switch { 44 => "Heavy Weapons", 45 => "Light Weapons", 46 => "Finesse Weapons", 47 => "Missile Weapons", 41 => "Two Handed Combat",
                              _ => SkillNameOf?.Invoke(s) ?? "Heavy Weapons" };
        }
    }

    /// <summary>A weapon that takes both hands' worth (two-handed, a bow or thrown weapon, a wand or staff): no shield with it.</summary>
    public bool NoShield => (Locations & SlotTwoHanded) != 0 || WeaponSkill == 41 || IsMissileWeapon || (ItemType & TypeCaster) != 0;

    // the game's words for how well armor protects against a kind of damage (its share of the armor level)
    private static string Protection(double mod) => mod >= 2.0 ? "Unparalleled" : mod >= 1.6 ? "Excellent" : mod >= 1.2 ? "Above Average" : mod >= 0.8 ? "Average" : mod >= 0.4 ? "Below Average" : "Poor";

    // the body parts armor covers (from where it can be worn)
    private string Covers()
    {
        var parts = new List<string>();
        // what it covers, as the item itself says (its coverage: under- and outerwear, part by part) - where it doesn't
        // say, worked out from the places it's worn
        if (Coverage != 0)
        {
            void C(int mask, string name) { if ((Coverage & mask) != 0) parts.Add(name); }
            C(0x4000, "Head"); C(0x400 | 0x8, "Chest"); C(0x800 | 0x10, "Abdomen"); C(0x1000 | 0x20, "Upper Arms"); C(0x2000 | 0x40, "Lower Arms");
            C(0x8000, "Hands"); C(0x100 | 0x2, "Upper Legs"); C(0x200 | 0x4, "Lower Legs"); C(0x10000, "Feet");
            if ((Locations & 0x200000) != 0) parts.Add("Shield");
            if (parts.Count > 0) return parts.Count == 1 ? parts[0] : string.Join(", ", parts.Take(parts.Count - 1)) + " and " + parts[^1];
        }
        int loc = Feet(Locations);
        void P(int mask, string name) { if ((loc & mask) != 0) parts.Add(name); }
        P(0x1, "Head"); P(0x200 | 0x2, "Chest"); P(0x400 | 0x4, "Abdomen"); P(0x800 | 0x8, "Upper Arms"); P(0x1000 | 0x10, "Lower Arms");
        P(0x20, "Hands"); P(0x2000 | 0x40, "Upper Legs"); P(0x4000 | 0x80, "Lower Legs"); P(0x100, "Feet"); P(0x200000, "Shield");
        return parts.Count <= 1 ? string.Join("", parts) : string.Join(", ", parts.Take(parts.Count - 1)) + " and " + parts[^1];
    }

    private static string SpeedName(int t) => t <= 10 ? "Very Fast" : t <= 30 ? "Fast" : t <= 49 ? "Average" : t <= 79 ? "Slow" : "Very Slow";

    /// <summary>A line or two about it, for the pack and loot windows.</summary>
    public string Describe()
    {
        var parts = new List<string>();
        if (IsCoins) return $"{Stack:N0} pyreals";
        if (Damage > 0) parts.Add($"damage {Math.Round(Damage * (1 - Variance))}-{Damage} {Rules.TypeName(Rules.FirstType(DamageType))}");
        if (ArmorLevel > 0) parts.Add($"armor level {ArmorLevel}");
        parts.Add($"value {Value:N0}");
        parts.Add($"burden {Burden}");
        if (Magical && Spells.Count > 0) parts.Add("spells: " + (SpellNames?.Invoke(this) ?? $"{Spells.Count}"));
        else if (Magical) parts.Add("magical");
        return string.Join(", ", parts);
    }
}

/// <summary>What you carry: the main pack (102 places, as the game's), what you wear and wield, and your pyreals.</summary>
public sealed class Inventory
{
    public const int PackSize = 102;
    /// <summary>How many things are in the main pack itself (Pack lists the side packs' things too).</summary>
    public int MainCount { get { int n = 0; foreach (var i in Pack) if (i.Holder == 0) n++; return n; } }
    public readonly List<Item> Pack = new();
    public readonly List<Item> Worn = new();
    /// <summary>The packs carried beside the main one (bags, foci), shown in the pack column.</summary>
    public readonly List<Item> SidePacks = new();
    /// <summary>The pack being looked at in the inventory: a side pack's id, 0 the main pack.</summary>
    public uint Viewing;
    public long Pyreals;
    public Action? Changed;
    /// <summary>
    /// On a server, wearing, taking off and dropping are asked of it (and the pack changes when it says so): wield at
    /// these places, back to the pack, onto the ground.
    /// </summary>
    public Action<Item, int>? NetWield;
    public Action<Item>? NetToPack, NetDrop;
    /// <summary>...and moving a thing to a place in a pack (the pack's id, 0 the main one; the place in it), part of a stack split off there (how many), one stack put onto another.</summary>
    public Action<Item, uint, int>? NetMove;
    public Action<Item, uint, int, int>? NetSplit;
    public Action<Item, Item>? NetMerge;

    public sealed class SavedItem
    {
        public int Wcid { get; set; }
        public int Stack { get; set; }
        public int Damage { get; set; }
        public int ArmorLevel { get; set; }
        public int Value { get; set; }
        public int WornAt { get; set; }
        public bool Magical { get; set; }
        public List<int>? Spells { get; set; }
        public string Name { get; set; } = "";
        public int PaletteTemplate { get; set; }
        public float Shade { get; set; }
        public int Uses { get; set; } = -1;
        public int Mana { get; set; } = -1;
        public int Uid { get; set; }
    }

    private SpawnData? _data;
    /// <summary>The game's things (to look one up: a pack's picture).</summary>
    public SpawnData? Data => _data;
    private List<SavedItem>? _pendingPack, _pendingWorn;

    public void Attach(SpawnData data)
    {
        _data = data;
        // items saved before the game data was there
        foreach (var s in _pendingPack ?? new()) if (FromSaved(s) is { } i) Pack.Add(i);
        foreach (var s in _pendingWorn ?? new()) if (FromSaved(s) is { } i) Worn.Add(i);
        _pendingPack = _pendingWorn = null;
    }

    private Item? FromSaved(SavedItem s)
    {
        if (_data == null || Item.Make(_data, s.Wcid) is not { } i) return null;
        i.Stack = Math.Max(1, s.Stack); i.Damage = s.Damage; i.ArmorLevel = s.ArmorLevel; i.Value = s.Value; i.WornAt = s.WornAt; i.Magical = s.Magical; i.Spells = s.Spells ?? new();
        if (s.Name.Length > 0) i.Name = s.Name;
        i.PaletteTemplate = s.PaletteTemplate; i.Shade = s.Shade;
        if (s.Uses >= 0 && i.MaxUses > 0) i.Uses = s.Uses;
        if (s.Mana >= 0 && i.MaxMana > 0) i.Mana = s.Mana;
        if (s.Uid > 0) { i.Uid = s.Uid; Item.NextUid = Math.Max(Item.NextUid, s.Uid + 1); }
        return i;
    }

    private static SavedItem ToSaved(Item i) => new()
    {
        Wcid = i.Wcid, Stack = i.Stack, Damage = i.Damage, ArmorLevel = i.ArmorLevel, Value = i.Value, WornAt = i.WornAt, Magical = i.Magical, Name = i.Name, Spells = i.Spells.Count > 0 ? i.Spells.ToList() : null,
        PaletteTemplate = i.PaletteTemplate, Shade = i.Shade, Uses = i.MaxUses > 0 ? i.Uses : -1, Mana = i.MaxMana > 0 ? i.Mana : -1, Uid = i.Uid,
    };

    public void Restore(List<SavedItem>? pack, List<SavedItem>? worn, long pyreals)
    {
        Pyreals = pyreals;
        if (_data == null) { _pendingPack = pack; _pendingWorn = worn; return; }
        foreach (var s in pack ?? new()) if (FromSaved(s) is { } i) Pack.Add(i);
        foreach (var s in worn ?? new()) if (FromSaved(s) is { } i) Worn.Add(i);
    }

    public List<SavedItem> SavePack() => Pack.Select(ToSaved).ToList();
    public List<SavedItem> SaveWorn() => Worn.Select(ToSaved).ToList();

    public int TotalBurden => Pack.Where(i => !i.IsCoins).Sum(i => i.Burden * Math.Max(i.Stack, 1)) + Worn.Sum(i => i.Burden) + (int)(Pyreals / 100);

    /// <summary>Puts something in the pack (coins go to your pyreals); false if the pack is full.</summary>
    public bool Add(Item item)
    {
        if (item.IsCoins) { Pyreals += item.Stack; Changed?.Invoke(); return true; }
        if (MainCount >= PackSize) return false;
        item.WornAt = 0;
        Pack.Insert(0, item);   // as the game: what comes into the pack goes in at the top
        Changed?.Invoke();
        return true;
    }

    public void Remove(Item item) { Pack.Remove(item); Worn.Remove(item); item.WornAt = 0; Changed?.Invoke(); }

    public Item? Weapon => Worn.FirstOrDefault(i => (i.WornAt & (Item.SlotMelee | Item.SlotTwoHanded | Item.SlotMissile | Item.SlotHeld)) != 0);
    /// <summary>A second one-handed weapon in the off hand (dual wielding), if any.</summary>
    public Item? OffHand => Worn.FirstOrDefault(i => (i.WornAt & Item.SlotShield) != 0 && i.IsMeleeWeapon);

    /// <summary>Whether a weapon can go in the off hand: a one-handed melee weapon, with nothing two-handed (or a bow, or a wand) in the main hand.</summary>
    public bool CanOffHand(Item it) => it.IsMeleeWeapon && !it.NoShield && (Weapon == null || !Weapon.NoShield);

    /// <summary>A second weapon into the off hand (what was there - a shield, another weapon - goes back in the pack).</summary>
    public string EquipOffHand(Item item)
    {
        if (!CanOffHand(item)) return $"You can't hold the {item.Name} in your off hand.";
        if (item.Guid != 0 && NetWield != null)
        {
            foreach (var old in Worn.Where(w => (w.WornAt & Item.SlotShield) != 0)) NetToPack?.Invoke(old);
            NetWield(item, Item.SlotShield);
            return "";
        }
        foreach (var old in Worn.Where(w => (w.WornAt & Item.SlotShield) != 0).ToList())
        {
            Worn.Remove(old); old.WornAt = 0; Pack.Insert(0, old);
        }
        Pack.Remove(item);
        item.WornAt = Item.SlotShield;
        Worn.Add(item);
        Changed?.Invoke();
        return $"You wield the {item.Name} in your off hand.";
    }

    /// <summary>
    /// Wears or wields something from the pack: it takes the places it can go (armor often covers several), and
    /// whatever was there goes back in the pack. Returns what happened.
    /// </summary>
    public string Equip(Item item)
    {
        if (!item.Wearable) return $"You can't wear or wield the {item.Name}.";
        int slots = item.Guid != 0 ? item.Locations : Item.Feet(item.Locations);   // (the server's: worn where it says)
        // a weapon (or a ring, a bracelet) goes in one of the places it can, not all of them
        if ((slots & (Item.SlotMelee | Item.SlotTwoHanded | Item.SlotMissile | Item.SlotHeld)) != 0)
            slots &= Item.SlotMelee | Item.SlotTwoHanded | Item.SlotMissile | Item.SlotHeld;
        else if ((slots & 0x30000) == 0x30000 || (slots & 0xC0000) == 0xC0000)
        {
            int pair = (slots & 0x30000) == 0x30000 ? 0x30000 : 0xC0000;
            int first = pair & -pair, second = pair & ~first;
            slots = Worn.Any(w => (w.WornAt & first) != 0) ? second : first;
        }
        // anything wielded blocks every other weapon
        int blocks = (slots & (Item.SlotMelee | Item.SlotTwoHanded | Item.SlotMissile | Item.SlotHeld)) != 0
            ? Item.SlotMelee | Item.SlotTwoHanded | Item.SlotMissile | Item.SlotHeld : slots;
        // armor takes off the armor already on the same parts of the body (bracers come off under a full coat)
        // and anything worn over the same parts of the body comes off: the robe under a breastplate, bracers under a
        // full coat (a shirt or trousers - the under layer - stays under armor)
        int outer = Outer(item, slots);
        // a shield won't go with a two-handed weapon, a bow or a wand (and the other way round)
        bool shield = (slots & Item.SlotShield) != 0, noShield = item.NoShield && (slots & (Item.SlotMelee | Item.SlotTwoHanded | Item.SlotMissile | Item.SlotHeld)) != 0;
        // (clothes and armor that say what they cover - the server's do - clash only where they cover the same part on
        // the same layer: a shirt and trousers both list the abdomen as a place, and go on together all the same)
        bool byCover = item.Coverage != 0 && (slots & 0x7FFF) != 0;
        var off = Worn.Where(w => byCover && w.Coverage != 0 && (w.WornAt & 0x7FFF) != 0 ? (w.Coverage & item.Coverage) != 0
                                             : (w.WornAt & blocks) != 0
                                             || (outer != 0 && (Outer(w, w.WornAt) & outer) != 0)
                                             || (shield && w.NoShield && (w.WornAt & (Item.SlotMelee | Item.SlotTwoHanded | Item.SlotMissile | Item.SlotHeld)) != 0)
                                             || (noShield && (w.WornAt & Item.SlotShield) != 0)).ToList();
        if (item.Guid != 0 && NetWield != null)
        {
            foreach (var old in off) NetToPack?.Invoke(old);
            NetWield(item, slots);
            return "";
        }
        foreach (var old in off)
        {
            Worn.Remove(old);
            old.WornAt = 0;
            Pack.Insert(0, old);
        }
        Pack.Remove(item);
        item.WornAt = slots;
        Worn.Add(item);
        Changed?.Invoke();
        return (slots & (Item.SlotMelee | Item.SlotTwoHanded | Item.SlotMissile | Item.SlotHeld)) != 0 ? $"You wield the {item.Name}." : $"You put on the {item.Name}.";
    }

    /// <summary>
    /// Splits some off a stack in the pack: a new stack of that many, just left of it (the smaller on the left, as the
    /// game puts them). Null if it can't (not that many, or no room in the pack).
    /// </summary>
    public Item? Split(Item stack, int n)
    {
        // (on a server a stack is split by the server, when part of it is given or put somewhere - not here)
        if (stack.Guid != 0) return null;
        if (n <= 0 || n >= stack.Stack || !Pack.Contains(stack) || MainCount >= PackSize) return null;
        var part = stack.Copy();
        part.Stack = n;
        stack.Stack -= n;
        Pack.Insert(Pack.IndexOf(stack), part);
        Changed?.Invoke();
        return part;
    }

    /// <summary>Puts a pack item at a place in the pack (the others move along).</summary>
    public void Place(Item item, int index)
    {
        if (!Pack.Remove(item)) return;
        Pack.Insert(Math.Clamp(index, 0, Pack.Count), item);
        if (item.Guid != 0 && NetMove != null)
        {
            // its place among the things of the pack it's in, told to the server - or, with fewer than the whole stack
            // chosen, that many split off there
            int at = Pack.Take(Pack.IndexOf(item)).Count(i => i.Holder == item.Holder);
            int part = item.Stack > 1 && ItemSlot.Splitting?.Invoke(item) is int n && n > 0 && n < item.Stack ? n : 0;
            if (part > 0 && NetSplit != null) NetSplit(item, item.Holder, at, part); else NetMove(item, item.Holder, at);
        }
        Changed?.Invoke();
    }

    // the kinds of thing that come in stacks (food, gems, spell components, potions and the like, ammunition)
    private const int StackTypes = 0x20 | 0x80 | 0x800 | 0x1000 | 0x4000 | 0x40000 | 0x80000;
    public const int MaxStack = 100;

    /// <summary>Whether one thing stacks onto another (the same kind of stackable thing).</summary>
    public static bool Stackable(Item a, Item b) =>
        a != b && a.Wcid == b.Wcid && (!a.IsCoins || a.Guid != 0) && a.MaxUses == 0 && a.MaxMana == 0 && (a.MaxStack > 1 || (a.Locations & Item.SlotAmmo) != 0);

    /// <summary>
    /// Stacks one thing onto another in the pack: the stack fills (up to its most), what's left over sits just to its
    /// left (the smaller amount on the left, as the game puts it).
    /// </summary>
    public void StackOnto(Item moving, Item onto)
    {
        if (moving.Guid != 0 && onto.Guid != 0 && NetMerge != null) { NetMerge(moving, onto); return; }
        int total = moving.Stack + onto.Stack;
        int most = onto.MaxStack > 1 ? onto.MaxStack : MaxStack;
        int main = Math.Min(total, most), left = total - main;
        onto.Stack = main;
        Pack.Remove(moving); Worn.Remove(moving); moving.WornAt = 0;
        if (left > 0)
        {
            moving.Stack = left;
            int at = Pack.IndexOf(onto);
            Pack.Insert(Math.Max(0, at), moving);
        }
        Changed?.Invoke();
    }

    /// <summary>The body parts something covers on the outer layer (armor, or a robe or coat that covers armor's places).</summary>
    public static int Outer(Item it, int at)
    {
        at = Item.Feet(it, at);
        if ((it.ItemType & (Item.TypeArmor | Item.TypeClothing)) == 0) return 0;
        int armorBits = at & 0x7E00, single = at & (0x1 | 0x20 | 0x100);
        // armor: every part it's on; clothing only counts where it reaches the armor layer (a robe), not as a shirt
        if ((it.ItemType & Item.TypeArmor) != 0) return Creatures.CreatureAssets.BodyParts(at);
        // (gloves, a hat, shoes sit on the armor layer too - only a shirt or trousers are underneath)
        return (armorBits | single) != 0 ? Creatures.CreatureAssets.BodyParts(armorBits | single) : 0;
    }

    /// <summary>The body's starting outfit (a robe, its shoes...) as worn items of yours, once.</summary>
    public void GiveOutfit(IEnumerable<(int wcid, int paletteTemplate, float shade)> outfit)
    {
        if (_data == null) return;
        foreach (var (wcid, pal, shade) in outfit)
            if (Item.Make(_data, wcid) is { } it && it.Wearable)
            {
                it.PaletteTemplate = pal; it.Shade = shade;
                it.WornAt = Item.Feet(it.Locations);
                Worn.Add(it);
            }
        Changed?.Invoke();
    }

    public string Unequip(Item item)
    {
        // (a server's: it says whether there's room - what it's told of counts every side pack's things too)
        if (item.Guid != 0 && NetToPack != null) { NetToPack(item); return ""; }
        if (MainCount >= PackSize) return "Your pack is full.";
        Worn.Remove(item);
        item.WornAt = 0;
        Pack.Insert(0, item);
        Changed?.Invoke();
        return $"You take off the {item.Name}.";
    }

    // coverage (ACE CoverageMask, outerwear) of your body parts struck: armor worn there counts against a blow
    private static int PartCoverage(string part) => part switch
    {
        "head" => 0x4000, "chest" => 0x400, "abdomen" => 0x800, "upperarm" => 0x1000, "lowerarm" => 0x2000, "hand" => 0x8000,
        "upperleg" => 0x100, "lowerleg" => 0x200, "foot" => 0x10000, _ => 0,
    };

    /// <summary>The armor level worn over one of your body parts (by the game's part names).</summary>
    public int ArmorAt(string part)
    {
        int c = PartCoverage(part);
        return Worn.Where(w => (w.Coverage & c) != 0).Sum(w => w.ArmorLevel);
    }
}

/// <summary>
/// Death treasure: a creature's treasure profile (ACE's treasure_death, data/treasure.json) rolled with ACE's loot
/// tables (vendor/ACELoot), then the items made - coins by tier as ACE does, weapons and armor a little better the
/// higher the tier. (ACE's full mutation - materials, workmanship, spells - comes later.)
/// </summary>
public sealed class Loot
{
    private readonly Dictionary<uint, ACE.Database.Models.World.TreasureDeath> _profiles = new();
    private readonly SpawnData _data;
    private static readonly (int min, int max)[] CoinRanges = { (5, 50), (10, 200), (10, 500), (25, 1000), (50, 5000), (250, 5000), (250, 5000), (250, 5000) };

    public Loot(SpawnData data, string dataDir)
    {
        _data = data;
        try
        {
            var path = Path.Combine(dataDir, "treasure.json");
            if (!File.Exists(path)) return;
            using var doc = JsonDocument.Parse(File.ReadAllText(path));
            foreach (var p in doc.RootElement.EnumerateObject())
            {
                var v = p.Value.EnumerateArray().Select(x => x.ValueKind == JsonValueKind.Null ? 0f : x.GetSingle()).ToArray();
                if (v.Length < 15) continue;
                _profiles[uint.Parse(p.Name)] = new ACE.Database.Models.World.TreasureDeath
                {
                    TreasureType = uint.Parse(p.Name), Tier = Math.Clamp((int)v[0], 1, 8), LootQualityMod = v[1], UnknownChances = (int)v[2],
                    ItemChance = (int)v[3], ItemMinAmount = (int)v[4], ItemMaxAmount = (int)v[5], ItemTreasureTypeSelectionChances = (int)v[6],
                    MagicItemChance = (int)v[7], MagicItemMinAmount = (int)v[8], MagicItemMaxAmount = (int)v[9], MagicItemTreasureTypeSelectionChances = (int)v[10],
                    MundaneItemChance = (int)v[11], MundaneItemMinAmount = (int)v[12], MundaneItemMaxAmount = (int)v[13], MundaneItemTypeSelectionChances = (int)v[14],
                };
            }
        }
        catch (Exception ex) { GD.PushWarning("treasure: " + ex.Message); }
    }

    /// <summary>Told of each item rolled (the magic system gives magic ones their spells).</summary>
    public Action<Item>? Made;

    /// <summary>What a creature leaves on its corpse: its death treasure.</summary>
    public List<Item> Roll(SpawnData.Weenie creature)
    {
        var items = new List<Item>();
        if (creature.DeathTreasure == 0 || !_profiles.TryGetValue(creature.DeathTreasure, out var p)) return items;
        List<ACE.Server.Factories.LootPick> picks;
        try { picks = ACE.Server.Factories.LootRoller.Roll(p); }
        catch (Exception ex) { GD.PushWarning("loot roll: " + ex.Message); return items; }
        foreach (var pick in picks)
        {
            if (Item.Make(_data, pick.Wcid) is not { } item) continue;
            item.Tier = p.Tier;
            item.Magical = pick.Magical && (item.Damage > 0 || item.ArmorLevel > 0 || (item.ItemType & (Item.TypeJewelry | Item.TypeCaster)) != 0);
            float tierMod = 1f + 0.12f * (p.Tier - 1);
            switch (pick.Kind)
            {
                case ACE.Server.Factories.Enum.TreasureItemType.Pyreal:
                    var (min, max) = CoinRanges[p.Tier - 1];
                    item.Stack = Rules.Rng.Next(min, max + 1);
                    item.Name = "Pyreals";
                    break;
                case ACE.Server.Factories.Enum.TreasureItemType.Weapon:
                    if (item.Damage > 0) item.Damage = Math.Max(1, (int)MathF.Round(item.Damage * tierMod * (0.9f + 0.2f * (float)Rules.Rng.NextDouble())));
                    item.Value = (int)(item.Value * tierMod * tierMod);
                    break;
                case ACE.Server.Factories.Enum.TreasureItemType.Armor:
                    if (item.ArmorLevel > 0) item.ArmorLevel = (int)MathF.Round(item.ArmorLevel * tierMod + Rules.Rng.Next(0, 10 * p.Tier));
                    item.Value = (int)(item.Value * tierMod * tierMod);
                    break;
                default:
                    item.Value = (int)(item.Value * tierMod);
                    break;
            }
            Made?.Invoke(item);
            items.Add(item);
        }
        return items;
    }
}
