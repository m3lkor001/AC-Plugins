using System;
using System.Collections.Generic;
using System.Linq;
using Godot;

namespace ACGodot.Combat;

/// <summary>A game window in the game's look: its translucent panel and gold frame, a title strip with an X, in its font.</summary>
public partial class GameWindow : PanelContainer
{
    protected VBoxContainer Body = null!;
    private Label _title = null!;
    public Action? Closed;
    protected readonly ScrollContainer Scroll;

    public GameWindow(string title, Vector2 size)
    {
        CustomMinimumSize = size;
        MouseFilter = MouseFilterEnum.Stop;
        if (ACGodot.UI.RetailTheme.Current is { } th) Theme = th;
        else AddThemeStyleboxOverride("panel", new StyleBoxFlat
        {
            BgColor = new Color(0.1f, 0.075f, 0.05f, 0.94f), BorderColor = new Color(0.62f, 0.47f, 0.22f),
            BorderWidthTop = 2, BorderWidthBottom = 2, BorderWidthLeft = 2, BorderWidthRight = 2,
            ContentMarginLeft = 8, ContentMarginRight = 8, ContentMarginTop = 6, ContentMarginBottom = 8,
        });
        var outer = new VBoxContainer();
        outer.AddThemeConstantOverride("separation", 4);
        AddChild(outer);
        // the title strip: dark, the name in the middle, an X at the right
        var strip = new PanelContainer { MouseFilter = MouseFilterEnum.Stop };
        strip.AddThemeStyleboxOverride("panel", new StyleBoxFlat
        {
            BgColor = new Color(0.08f, 0.06f, 0.03f, 0.95f), BorderColor = new Color(0.62f, 0.47f, 0.22f),
            BorderWidthLeft = 1, BorderWidthRight = 1, BorderWidthTop = 1, BorderWidthBottom = 1, ContentMarginLeft = 4, ContentMarginRight = 2,
        });
        var bar = new HBoxContainer();
        strip.AddChild(bar);
        _title = new Label { Text = title, SizeFlagsHorizontal = SizeFlags.ExpandFill, HorizontalAlignment = HorizontalAlignment.Center, MouseFilter = MouseFilterEnum.Stop };
        _title.AddThemeColorOverride("font_color", ACGodot.UI.RetailTheme.Gold);
        bar.AddChild(_title);
        var close = new Button { Text = "X", FocusMode = FocusModeEnum.None, Flat = true };
        close.AddThemeColorOverride("font_color", new Color(1f, 0.8f, 0.5f));
        close.AddThemeStyleboxOverride("normal", new StyleBoxEmpty());
        close.AddThemeStyleboxOverride("hover", new StyleBoxEmpty());
        close.AddThemeStyleboxOverride("pressed", new StyleBoxEmpty());
        close.Pressed += () => { Visible = false; Closed?.Invoke(); };
        bar.AddChild(close);
        outer.AddChild(strip);
        // with the interface unlocked (the radar's lock), the title strip drags the window about
        bool down = false;
        Vector2 grab = Vector2.Zero;
        _title.GuiInput += e =>
        {
            if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb)
            {
                if (!mb.Pressed && down && _moved) SavePlace();
                down = mb.Pressed; grab = GetGlobalMousePosition() - Position; _moved = false;
            }
            else if (e is InputEventMouseMotion && down && !ACGodot.UI.UiLock.Locked) { Position = GetGlobalMousePosition() - grab; _moved = true; }
        };
        _key = title;
        Scroll = new ScrollContainer { SizeFlagsVertical = SizeFlags.ExpandFill, HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled };
        Scroll.CustomMinimumSize = new Vector2(size.X - 16, size.Y - 40);
        Body = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        Scroll.AddChild(Body);
        outer.AddChild(Scroll);
    }

    // where it was left is kept (user://ui.cfg, by its kind and title)
    private string _key = "";
    private bool _moved;
    private string Key => "win_" + GetType().Name + (this is ACGodot.Plugins.PluginWindow ? "_" + _key : "");

    public override void _Ready()
    {
        var c = new ConfigFile();
        if (global::ACGodot.SafeConfig.Load(c, "user://ui.cfg") == Error.Ok && c.HasSectionKey("windows", Key)) { Position = (Vector2)c.GetValue("windows", Key); Placed = true; }
    }

    /// <summary>It has a place of its own (moved there by you, kept): don't put it anywhere else.</summary>
    public bool Placed { get; private set; }

    private void SavePlace()
    {
        Placed = true;
        var c = new ConfigFile(); global::ACGodot.SafeConfig.Load(c, "user://ui.cfg"); c.SetValue("windows", Key, Position); global::ACGodot.SafeConfig.Save(c, "user://ui.cfg");
    }

    // the game's look once its interface data is open (windows made before that pick it up then)
    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("GameWindow");
        if (Theme == null && ACGodot.UI.RetailTheme.Current is { } th) { RemoveThemeStyleboxOverride("panel"); Theme = th; }
    }

    public string Title { set => _title.Text = value; }

    protected void Clear() { foreach (var c in Body.GetChildren()) { Body.RemoveChild(c); c.QueueFree(); } }

    protected static Label Text(string s, int size = 13, Color? color = null)
    {
        var l = new Label { Text = s, AutowrapMode = TextServer.AutowrapMode.WordSmart };
        if (ACGodot.UI.RetailTheme.TextFont == null) l.AddThemeFontSizeOverride("font_size", ACGodot.UI.RetailTheme.Px(size));
        l.AddThemeColorOverride("font_color", color ?? ACGodot.UI.RetailTheme.Ink);
        return l;
    }

    protected static Label Heading(string s) => Text(s, 15, ACGodot.UI.RetailTheme.Gold);

    protected static Button Small(string s, Action onPress, bool enabled = true)
    {
        var b = new Button { Text = s, FocusMode = FocusModeEnum.None, Disabled = !enabled };
        if (ACGodot.UI.RetailTheme.TextFont == null) b.AddThemeFontSizeOverride("font_size", ACGodot.UI.RetailTheme.Px(12));
        b.Pressed += onPress;
        return b;
    }
}

/// <summary>The character window (C): level, experience, attributes, vitals and skills, with + to raise them.</summary>
public partial class CharacterWindow : GameWindow
{
    public Action? Changed;
    private Character _c = null!;

    private int _tab = -1;
    public CharacterWindow() : base("Character", new Vector2(370, 600)) { }

    public void Show(Character c) { _c = c; Refresh(); }

    public void Refresh()
    {
        if (_c == null || !Visible) return;
        Clear();
        var c = _c;
        // as the game's side panel: Attributes (with vitals) and Skills, on tabs
        var tabs = new TabContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, CustomMinimumSize = new Vector2(340, 540), CurrentTab = 0 };
        var attrPage = new ScrollContainer { Name = "Attributes", HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled };
        var attr = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        attrPage.AddChild(attr);
        var skillPage = new ScrollContainer { Name = "Skills", HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled };
        var skills = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        skillPage.AddChild(skills);
        tabs.AddChild(attrPage); tabs.AddChild(skillPage);
        if (_tab >= 0) tabs.CurrentTab = _tab;
        tabs.TabChanged += t => _tab = (int)t;
        Body.AddChild(tabs);
        attr.AddChild(Heading($"{c.Name} - level {c.Level} {c.Heritage}"));
        long next = c.NextLevelXp;
        attr.AddChild(Text($"Total experience: {c.TotalXp:N0}" + (next > 0 ? $"   (level {c.Level + 1} at {next:N0})" : "")));
        attr.AddChild(Text($"Unassigned experience: {c.UnassignedXp:N0}"));
        attr.AddChild(Text($"Skill credits: {c.SkillCredits}"));
        attr.AddChild(Heading("Attributes"));
        for (int i = 0; i < 6; i++)
        {
            int a = i;
            long cost = c.AttributeCost(a);
            attr.AddChild(Row($"{Character.AttributeNames[a]}", c.Attribute(a).ToString(), cost, () => c.RaiseAttribute(a)));
        }
        attr.AddChild(Heading("Vitals"));
        for (int v = 0; v < 3; v++)
        {
            int vi = v;
            long cost = c.VitalCost(vi);
            attr.AddChild(Row(Character.VitalNames[vi], c.MaxVital(vi).ToString(), cost, () => c.RaiseVital(vi)));
        }
        skills.AddChild(Text($"Skill credits: {c.SkillCredits}"));
        foreach (var (label, training) in new[] { ("Specialized skills", Character.Training.Specialized), ("Trained skills", Character.Training.Trained), ("Untrained skills", Character.Training.Untrained) })
        {
            skills.AddChild(Heading(label));
            foreach (var (id, name) in c.AllSkills().Where(s => c.TrainingOf(s.id) == training))
            {
                int sid = id;
                if (training == Character.Training.Untrained)
                {
                    int tc = c.TrainCost(sid);
                    var row = new HBoxContainer();
                    row.AddChild(new Label { Text = name, SizeFlagsHorizontal = SizeFlags.ExpandFill });
                    row.AddChild(new Label { Text = c.Skill(sid).ToString(), CustomMinimumSize = new Vector2(40, 0) });
                    row.AddChild(Small(tc >= 0 ? $"train ({tc})" : "-", () => { if (c.TrainSkill(sid)) Done(); }, tc >= 0 && tc <= c.SkillCredits));
                    skills.AddChild(row);
                }
                else skills.AddChild(Row(name, c.Skill(sid).ToString(), c.SkillCost(sid), () => c.RaiseSkill(sid)));
            }
        }
    }

    private void Done() { Changed?.Invoke(); Refresh(); }

    private HBoxContainer Row(string name, string value, long cost, Func<bool> raise)
    {
        var row = new HBoxContainer();
        var n = new Label { Text = name, SizeFlagsHorizontal = SizeFlags.ExpandFill };
        n.AddThemeFontSizeOverride("font_size", ACGodot.UI.RetailTheme.Px(13));
        row.AddChild(n);
        var v = new Label { Text = value, CustomMinimumSize = new Vector2(40, 0), HorizontalAlignment = HorizontalAlignment.Right };
        v.AddThemeFontSizeOverride("font_size", ACGodot.UI.RetailTheme.Px(13));
        row.AddChild(v);
        // + raises one rank; shift-click ten
        var b = Small(cost >= 0 ? $"+ ({cost:N0})" : "max", () =>
        {
            int times = Input.IsKeyPressed(Key.Shift) ? 10 : 1;
            bool any = false;
            for (int i = 0; i < times && raise(); i++) any = true;
            if (any) Done();
        }, cost >= 0 && cost <= _c.UnassignedXp);
        b.CustomMinimumSize = new Vector2(110, 0);
        row.AddChild(b);
        return row;
    }
}

/// <summary>Item squares to click (the pack, a corpse's contents): dark squares with the item's icon, stacks numbered.</summary>
public partial class ItemGrid : GridContainer
{
    public int Slot = 34;
    public ItemGrid(int columns = 6) { Columns = columns; AddThemeConstantOverride("h_separation", 2); AddThemeConstantOverride("v_separation", 2); }

    private static StyleBoxFlat Square(Color border, Color fill) => new()
    {
        BgColor = fill, BorderColor = border, BorderWidthLeft = 1, BorderWidthRight = 1, BorderWidthTop = 1, BorderWidthBottom = 1,
        ContentMarginLeft = 1, ContentMarginRight = 1, ContentMarginTop = 1, ContentMarginBottom = 1,
    };

    /// <summary>Whether something dragged can be dropped here (on an item square, or the empty room after).</summary>
    public virtual bool CanTake(Item? onto) => false;
    /// <summary>Something dropped here: at this place (the square's), onto this item (or none).</summary>
    public virtual void TakeDrop(int index, Item? onto) { }

    public override bool _CanDropData(Vector2 at, Variant data) =>
        data.VariantType == Variant.Type.String && (string)data == "acgodot-item" && ItemSlot.Dragging != null && CanTake(null);
    public override void _DropData(Vector2 at, Variant data) { TakeDrop(int.MaxValue, null); }

    /// <summary>A right click on an item: identify it (the examine panel).</summary>
    public static Action<Item>? Identify;
    /// <summary>Where the items come from, for dragging out (the pack, a corpse...).</summary>
    public string Source = "pack";
    public Action<Item>? DoubleClicked;
    /// <summary>The number shown on a square in place of the stack's (a vendor's lists: how many are asked for).</summary>
    public Func<Item, int>? Count;

    // what the grid last showed: the same things in the same places again (a stack gone down by one, a refresh with
    // nothing changed) has its numbers put right where they stand - made over, every square blinked and the hover went
    private List<Item>? _shownItems; private Item? _shownSelected; private int _shownEmpty = -1;

    public void Fill(IEnumerable<Item> items, Func<uint, Texture2D?> icon, Action<Item> clicked, Item? selected = null, int emptySlots = 0)
    {
        var list = items as List<Item> ?? items.ToList();
        items = list;
        if (_shownItems != null && _shownSelected == selected && _shownEmpty == emptySlots && _shownItems.Count == list.Count
            && GetChildCount() == list.Count + emptySlots && _shownItems.SequenceEqual(list))
        {
            for (int i = 0; i < list.Count; i++)
            {
                if (GetChild(i) is not ItemSlot slot) continue;
                var item = list[i];
                var pic = item.Picture(icon);
                if (slot.Icon != pic) slot.Icon = pic;
                if (slot.TooltipText != item.Shown) slot.TooltipText = item.Shown;
                int shownNow = Count?.Invoke(item) ?? item.Stack;
                var count = slot.GetNodeOrNull<Label>("count");
                if (count != null) { string t = shownNow > 1 ? shownNow.ToString() : ""; if (count.Text != t) count.Text = t; }
                else if (shownNow > 1) { _shownItems = null; break; }   // (a number where there was none: made over)
                if (slot.GetNodeOrNull<ColorRect>("mana") is { } bar && item.MaxMana > 0)
                    bar.Size = new Vector2((Slot - 4) * Math.Clamp(item.Mana / (float)item.MaxMana, 0f, 1f), 3);
                slot.QueueRedraw();
            }
            if (_shownItems != null) return;
        }
        _shownItems = new List<Item>(list); _shownSelected = selected; _shownEmpty = emptySlots;
        foreach (var c in GetChildren()) { RemoveChild(c); c.QueueFree(); }
        var normal = Square(new Color(0.35f, 0.28f, 0.15f), new Color(0f, 0f, 0f, 0.55f));
        var hover = Square(new Color(0.8f, 0.65f, 0.3f), new Color(0.1f, 0.08f, 0.03f, 0.7f));
        var chosen = Square(new Color(1f, 1f, 1f), new Color(0.22f, 0.22f, 0.22f, 0.7f));   // the picked one: white, as the game marks it
        int n = 0;
        foreach (var it in items)
        {
            var item = it;
            var b = new ItemSlot { CustomMinimumSize = new Vector2(Slot, Slot), FocusMode = FocusModeEnum.None, TooltipText = item.Shown,
                                   Icon = item.Picture(icon), ExpandIcon = true, IconAlignment = HorizontalAlignment.Center,
                                   VerticalIconAlignment = VerticalAlignment.Center, Item = item, Source = Source, Grid = this, Index = n };
            var look = item == selected ? chosen : normal;
            b.AddThemeStyleboxOverride("normal", look); b.AddThemeStyleboxOverride("pressed", chosen); b.AddThemeStyleboxOverride("hover", hover);
            b.AddThemeStyleboxOverride("focus", new StyleBoxEmpty());
            b.AddThemeColorOverride("font_color", ACGodot.UI.RetailTheme.Ink);
            b.AddThemeConstantOverride("outline_size", 0);
            if (b.Icon == null) { b.Text = item.Name.Length > 5 ? item.Name[..5] : item.Name; b.ClipText = true; }
            if (item.MaxMana > 0 && item.Mana > 0)
            {
                // a mana stone's mana: a blue bar along the bottom, filled as far as it's charged
                var bar = new ColorRect { Name = "mana", Color = new Color(0.25f, 0.45f, 1f, 0.9f), MouseFilter = MouseFilterEnum.Ignore,
                                          Position = new Vector2(2, Slot - 5), Size = new Vector2((Slot - 4) * Math.Clamp(item.Mana / (float)item.MaxMana, 0f, 1f), 3) };
                b.AddChild(bar);
            }
            // uses left (an essence, a kit): a bar up the right edge - red and running down, with a clock, while it cools down
            if (Count == null && (item.MaxUses > 0 || item.CooldownId != 0)) b.AddChild(new UseBar(() => item, Slot));
            int shown = Count?.Invoke(item) ?? item.Stack;
            if (shown > 1)
            {
                // the stack's size (or a kit's or lockpick's uses left) in the corner, over the icon
                var count = new Label { Name = "count", Text = shown.ToString(), MouseFilter = MouseFilterEnum.Ignore };
                count.AddThemeColorOverride("font_color", Colors.White);
                count.SetAnchorsPreset(LayoutPreset.BottomRight);
                count.GrowHorizontal = GrowDirection.Begin; count.GrowVertical = GrowDirection.Begin;
                b.AddChild(count);
            }
            b.Pressed += () => clicked(item);
            b.GuiInput += e =>
            {
                if (e is InputEventMouseButton { ButtonIndex: MouseButton.Right, Pressed: true }) { Identify?.Invoke(item); b.AcceptEvent(); }
                else if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, DoubleClick: true } && DoubleClicked != null) { DoubleClicked(item); b.AcceptEvent(); }
            };
            AddChild(b);
            n++;
        }
        // the empty squares after (a pack's room)
        for (int i = 0; i < emptySlots; i++)
        {
            var p = new Panel { CustomMinimumSize = new Vector2(Slot, Slot), MouseFilter = MouseFilterEnum.Ignore };
            p.AddThemeStyleboxOverride("panel", normal);
            AddChild(p);
        }
    }
}

/// <summary>
/// On an item's square: how many uses it has left as a green bar up the right edge; while it cools down after a use
/// (as the server times it) the bar is red and runs down, and a clock shows it can't be used yet.
/// </summary>
public partial class UseBar : Control
{
    private readonly Func<Item?> _of;
    private Item? _item;
    private readonly int _slot;
    private float _was = -1;
    private int _uses = -1;
    /// <summary>For the item given as asked (a shortcut's is whichever of its kind is carried just then).</summary>
    public UseBar(Func<Item?> of, int slot) { _of = of; _slot = slot; MouseFilter = MouseFilterEnum.Ignore; Size = new Vector2(slot, slot); }

    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("UseBar");
        var it = _of();
        float c = it?.Cooling ?? 0; int u = it == null ? -2 : it.Uses;
        if (c != _was || u != _uses || it != _item) { _was = c; _uses = u; _item = it; QueueRedraw(); }
    }

    public override void _Draw() { long __fw = ACGodot.FrameWatch.DrawStart(); try { DrawBody(); } finally { ACGodot.FrameWatch.Drew("UseBar", __fw); } }
    private void DrawBody()
    {
        if (_item == null) return;
        float cool = _item.Cooling, h = _slot - 4;
        bool uses = _item.MaxUses > 0;
        if (uses || cool > 0)
        {
            var back = new Rect2(_slot - 6, 2, 4, h);
            DrawRect(back, new Color(0, 0, 0, 0.9f));
            float f = cool > 0 ? cool : Math.Clamp(_item.Uses / (float)_item.MaxUses, 0f, 1f);
            DrawRect(new Rect2(back.Position.X, 2 + h * (1 - f), 4, h * f), cool > 0 ? new Color(0.9f, 0.1f, 0.1f) : new Color(0.15f, 0.85f, 0.15f));
        }
        if (cool > 0)
        {
            // the clock: a white face, two hands
            var at = new Vector2(_slot - 13, _slot - 9); float rad = 6;
            DrawCircle(at, rad + 1, Colors.Black);
            DrawCircle(at, rad, new Color(0.95f, 0.95f, 0.95f));
            DrawLine(at, at + new Vector2(0, -rad + 1.5f), Colors.Black, 1.5f);
            DrawLine(at, at + new Vector2(rad - 2.5f, 0), Colors.Black, 1.5f);
        }
    }
}

/// <summary>The pack window (I): what you wear and wield, the pack's contents, pyreals and burden.</summary>
public partial class PackWindow : GameWindow
{
    public Action<string>? Said;
    public Action<Item>? Dropped;
    /// <summary>"Shortcut": the item put on the shortcut bar.</summary>
    public Action<Item>? Shortcut;
    public Action? Equipped;
    private Inventory _inv = null!;
    private Func<uint, Texture2D?> _icon = _ => null;
    private Item? _sel;

    public PackWindow() : base("Inventory", new Vector2(320, 560)) { }

    public void Show(Inventory inv, Func<uint, Texture2D?> icon) { _inv = inv; _icon = icon; Refresh(); }

    public void Refresh()
    {
        if (_inv == null || !Visible) return;
        Clear();
        if (_sel != null && !_inv.Pack.Contains(_sel) && !_inv.Worn.Contains(_sel)) _sel = null;
        Body.AddChild(Text($"Pyreals: {_inv.Pyreals:N0}    Burden: {_inv.TotalBurden:N0}    {_inv.Pack.Count}/{Inventory.PackSize}"));
        Body.AddChild(Heading("Worn and wielded"));
        var worn = new ItemGrid(8);
        worn.DoubleClicked = Use;
        worn.Fill(_inv.Worn, _icon, Pick, _sel);
        Body.AddChild(worn);
        Body.AddChild(Heading("Pack"));
        var pack = new ItemGrid(8);
        pack.DoubleClicked = Use;
        pack.Fill(_inv.Pack, _icon, Pick, _sel, Math.Max(0, Math.Min(Inventory.PackSize, 48) - _inv.Pack.Count));
        Body.AddChild(pack);
    }

    /// <summary>Double-click: wear or wield it, or take it off (as the game's).</summary>
    private void Use(Item s)
    {
        if (_inv.Worn.Contains(s)) Said?.Invoke(_inv.Unequip(s));
        else if (s.Wearable) Said?.Invoke(_inv.Equip(s));
        else return;
        Equipped?.Invoke();
        Refresh();
    }

    /// <summary>Dropped on the ground (dragged out into the world).</summary>
    public void Drop(Item s)
    {
        if (!_inv.Pack.Contains(s)) return;
        _inv.Remove(s); if (_sel == s) _sel = null; Dropped?.Invoke(s); Refresh();
    }

    private void Pick(Item i) { _sel = i == _sel ? null : i; Refresh(); }
}

/// <summary>
/// A corpse's or chest's contents (R on it), laid out as the game's: what it is on the left, its contents in rows of
/// squares beside it; click one to take it (or Take All).
/// </summary>
public partial class LootWindow : GameWindow
{
    public Func<Item, bool>? Take;
    /// <summary>What's in the part being looked at (the container itself, or one of its packs).</summary>
    public List<Item>? Contents;
    /// <summary>The item clicked (highlighted; its name in the control bar): F or a double-click takes it.</summary>
    public Item? Selected;
    public Action<Item?>? Picked;
    /// <summary>A thing of yours dropped in: put into this (the container, or the pack of it being looked at) - the server
    /// says if it can go there (a pack only into a pack's place; a hook takes what it can show).</summary>
    public Action<Item, uint>? PutIn;
    /// <summary>How many things it holds (0: not known - rows of ten); a hook holds one.</summary>
    public int Slots;
    /// <summary>How many packs it takes (the bag slots shown: retail shows only those - an apartment's storage has
    /// one); -1 not said (ten shown).</summary>
    public int PackSlots = -1;
    /// <summary>The container (its server number), and what's in a pack of it (by number).</summary>
    public uint Box;
    public Func<uint, List<Item>>? ContentsOf;
    /// <summary>One of its packs clicked: asked of the server (its contents come back).</summary>
    public Action<Item>? OpenPack;
    /// <summary>The picture for the big square (the container's own icon; a corpse, the skull), and the main pack's.</summary>
    public uint BoxIcon;
    public Func<Texture2D?>? MainPackIcon;

    private const uint MainMark = 0xFFFFFFF0u;   // (the main pack's square: its own picture)
    private readonly Item _main = new() { Name = "Main pack", Icon = MainMark };
    private Item? _viewing;   // (one of its packs; null: the container itself)
    private List<Item> _all = new();

    /// <summary>Takes an item into your pack.</summary>
    public void TakeIt(Item i)
    {
        if (Contents == null || Take?.Invoke(i) != true) return;
        Contents.Remove(i);
        _all.Remove(i);
        if (Selected == i) { Selected = null; Picked?.Invoke(null); }
        Refresh();
    }
    private Func<uint, Texture2D?> _icon = _ => null;
    private string _name = "";

    private static readonly Vector2 Least = new(470, 150);
    private int _across = 10;

    public LootWindow() : base("Corpse", Least)
    {
        Scroll.HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled;
        // (the window itself doesn't scroll: the packs' row scrolls across and what's in the part looked at scrolls
        // down, each on its own - a chest with dozens of pack slots pushed its contents below the bottom)
        Scroll.VerticalScrollMode = ScrollContainer.ScrollMode.Disabled;
        Body.SizeFlagsVertical = SizeFlags.ExpandFill;
        // a grip in the bottom-right corner sizes it (with the interface unlocked): more squares across in a wider
        // window, more rows seen without scrolling in a taller one - kept, as the vendor's is
        var grip = new Control { CustomMinimumSize = new Vector2(14, 14), MouseDefaultCursorShape = CursorShape.Fdiagsize, MouseFilter = MouseFilterEnum.Stop,
                                 SizeFlagsHorizontal = SizeFlags.ShrinkEnd, SizeFlagsVertical = SizeFlags.ShrinkEnd };
        grip.Draw += () =>
        {
            var c = new Color(0.8f, 0.65f, 0.3f, ACGodot.UI.UiLock.Locked ? 0.35f : 0.9f);
            for (int i = 0; i < 3; i++) grip.DrawLine(new Vector2(13, 3 + i * 4), new Vector2(3 + i * 4, 13), c, 1f);
        };
        bool down = false; Vector2 from = Vector2.Zero, start = Vector2.Zero;
        grip.GuiInput += e =>
        {
            if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left } mb)
            {
                down = mb.Pressed && !ACGodot.UI.UiLock.Locked; from = GetGlobalMousePosition(); start = Size;
                if (!mb.Pressed) { var c = new ConfigFile(); global::ACGodot.SafeConfig.Load(c, "user://ui.cfg"); c.SetValue("windows", "size_LootWindow", Size); global::ACGodot.SafeConfig.Save(c, "user://ui.cfg"); }
                grip.AcceptEvent();
            }
            else if (e is InputEventMouseMotion && down)
            {
                var screen = GetViewportRect().Size;
                var want = start + GetGlobalMousePosition() - from;
                Size = new Vector2(Math.Clamp(want.X, Least.X, Math.Max(Least.X, screen.X - Position.X)), Math.Clamp(want.Y, Least.Y, Math.Max(Least.Y, screen.Y - Position.Y)));
                grip.AcceptEvent();
            }
            else if (e is InputEventMouseMotion) grip.QueueRedraw();
        };
        AddChild(grip);
        Resized += () => { if (Fit() != _across && Visible) Refresh(); };
    }

    public override void _Ready()
    {
        base._Ready();
        var c = new ConfigFile();
        if (global::ACGodot.SafeConfig.Load(c, "user://ui.cfg") == Error.Ok && c.HasSectionKey("windows", "size_LootWindow")) Size = ((Vector2)c.GetValue("windows", "size_LootWindow")).Max(Least);
    }

    // how many squares go across the window as wide as it is (10 at the least; the picture's column at the left)
    private int Fit() => Math.Max(10, (int)((Size.X - 16 - 68 - 14) / 36f));

    public void Show(string title, List<Item> contents, Func<uint, Texture2D?> icon)
    {
        if (title != _name) _viewing = null;
        _name = title; Title = title; _all = contents; _icon = id => id == MainMark ? MainPackIcon?.Invoke() : icon(id); Visible = true; Refresh();
    }

    private static bool IsPack(Item i) => (i.ItemType & 0x200) != 0 && i.Capacity > 0;
    private bool Corpse => _name.StartsWith("Corpse");

    public void Refresh()
    {
        if (!Visible) return;
        Clear();
        var packs = _all.Where(IsPack).ToList();
        if (_viewing != null && !packs.Contains(_viewing)) _viewing = null;
        Contents = _viewing != null ? (ContentsOf?.Invoke(_viewing.Guid) ?? new List<Item>()) : _all.Where(i => !IsPack(i)).ToList();
        uint into = _viewing?.Guid ?? Box;
        var row = new HBoxContainer { SizeFlagsVertical = SizeFlags.ExpandFill };
        row.AddThemeConstantOverride("separation", 8);
        // what it is: a big square - its picture (a corpse, the skull) - with its name under it
        var side = new VBoxContainer { CustomMinimumSize = new Vector2(60, 0) };
        var big = new Panel { CustomMinimumSize = new Vector2(48, 48), SizeFlagsHorizontal = SizeFlags.ShrinkCenter };
        big.AddThemeStyleboxOverride("panel", new StyleBoxFlat { BgColor = new Color(0f, 0f, 0f, 0.55f), BorderColor = new Color(0.62f, 0.47f, 0.22f),
                                                                  BorderWidthLeft = 1, BorderWidthRight = 1, BorderWidthTop = 1, BorderWidthBottom = 1 });
        if ((Corpse ? _icon(0x06001070) : BoxIcon != 0 ? _icon(BoxIcon) : null) is { } pic)
            big.AddChild(new TextureRect { Texture = pic, ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize, StretchMode = TextureRect.StretchModeEnum.KeepAspectCentered,
                                           Size = new Vector2(48, 48), MouseFilter = Control.MouseFilterEnum.Ignore });
        var mark = new Label { Text = Corpse ? "Corpse" : _name.Length > 0 && _name.Length <= 14 ? _name : "Chest", HorizontalAlignment = HorizontalAlignment.Center };
        mark.AddThemeColorOverride("font_color", ACGodot.UI.RetailTheme.Dim);
        side.AddChild(big);
        side.AddChild(mark);
        side.AddChild(new Label { Text = $"{Contents.Count} item{(Contents.Count == 1 ? "" : "s")}", HorizontalAlignment = HorizontalAlignment.Center });
        row.AddChild(side);
        var right = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill };
        // its packs (a chest's, a corpse's): the main pack first, then each of its packs - click one to
        // see what's in it below. Not for what holds only a few (a hook)
        if ((Slots == 0 || Slots > 10) && (PackSlots != 0 || packs.Count > 0 || Corpse))
        {
            var shown = new List<Item> { _main };
            shown.AddRange(packs);   // (a corpse's too: some monsters carry a pack)
            int bagSlots = PackSlots > 0 ? PackSlots : PackSlots == 0 ? packs.Count : 9;
            int emptyBags = Math.Max(0, 1 + bagSlots - shown.Count);
            // one row, scrolling across when there are more than fit
            var bags = new PutGrid(Math.Max(1, shown.Count + emptyBags)) { Source = "corpse", Win = this, Into = () => Box };
            bags.Fill(shown, _icon, b => { _viewing = b == _main ? null : b; Selected = null; if (_viewing != null) OpenPack?.Invoke(_viewing); Refresh(); },
                      _viewing ?? _main, emptyBags);
            var bagScroll = new ScrollContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, VerticalScrollMode = ScrollContainer.ScrollMode.Disabled,
                                                  HorizontalScrollMode = ScrollContainer.ScrollMode.Auto, CustomMinimumSize = new Vector2(0, 46) };
            bagScroll.AddChild(bags);
            right.AddChild(bagScroll);
        }
        // what's in the part looked at: as many squares as it holds (a hook, one), or rows of ten; a thing of yours dropped on them goes in
        int holds = _viewing != null ? _viewing.Capacity : Slots;
        _across = Fit();
        int across = holds > 0 && holds < 10 ? holds : _across;
        var grid = new PutGrid(across) { Source = "corpse", Win = this, Into = () => _viewing?.Guid ?? Box };
        grid.DoubleClicked = i => TakeIt(i);
        if (Selected != null && !Contents.Contains(Selected)) Selected = null;
        int empty = holds > 0 && holds <= 10 ? Math.Max(0, holds - Contents.Count) : Math.Max(0, across - Contents.Count % across) % across + (Contents.Count == 0 ? across : 0);
        grid.Fill(Contents, _icon, i => { Selected = i; Picked?.Invoke(i); Refresh(); }, Selected, empty);
        var gridScroll = new ScrollContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill,
                                               HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled, CustomMinimumSize = new Vector2(0, 72) };
        gridScroll.AddChild(grid);
        right.AddChild(gridScroll);
        if (Contents.Count == 0) right.AddChild(Text(PutIn != null && !Corpse ? "It's empty - drop a thing of yours here to put it in." : "It's empty.", 12, ACGodot.UI.RetailTheme.Dim));
        row.AddChild(right);
        Body.AddChild(row);
    }

    public override bool _CanDropData(Vector2 at, Variant data) =>
        PutIn != null && data.VariantType == Variant.Type.String && (string)data == "acgodot-item" && ItemSlot.Dragging is { Guid: not 0 } && ItemSlot.DraggingFrom == "pack";
    public override void _DropData(Vector2 at, Variant data) { if (ItemSlot.Dragging is { } it) PutIn?.Invoke(ItemSlot.SplitFrom ?? it, _viewing?.Guid ?? Box); ItemSlot.Dragging = null; }

    // its squares: take a thing of yours dropped on them, into the part they show
    private sealed partial class PutGrid : ItemGrid
    {
        public LootWindow Win = null!;
        public Func<uint> Into = () => 0;
        public PutGrid(int columns) : base(columns) { }
        public override bool CanTake(Item? onto) => Win.PutIn != null && ItemSlot.Dragging is { Guid: not 0 } && ItemSlot.DraggingFrom == "pack";
        public override void TakeDrop(int index, Item? onto)
        {
            if (ItemSlot.Dragging is { } it) Win.PutIn?.Invoke(ItemSlot.SplitFrom ?? it, Into());
            ItemSlot.Dragging = null;
        }
    }
}

/// <summary>An item's square: dragged, it carries the item (onto the shortcut bar, another pack, or into the world to drop it).</summary>
public partial class ItemSlot : Button
{
    // (hovering: its name, count, uses left and cooldown, as they are just then)
    public override string _GetTooltip(Vector2 at) => Item?.HoverText() ?? TooltipText;

    public Item? Item;
    public string Source = "pack";
    public ItemGrid? Grid;
    public int Index;

    /// <summary>The number key an item is on in the shortcut bar (1-9, 0), or -1 when it isn't on a numbered slot; and
    /// told when what's on the bar changes. An item that is has a small white square with its number in its top left corner.</summary>
    public static Func<Item, int>? QuickNumber;
    public static event Action? QuickChanged;
    public static void QuickRedraw() => QuickChanged?.Invoke();
    public override void _EnterTree() { QuickChanged += QueueRedraw; }
    public override void _ExitTree() { QuickChanged -= QueueRedraw; }
    public override void _Draw() { long __fw = ACGodot.FrameWatch.DrawStart(); try { DrawBody(); } finally { ACGodot.FrameWatch.Drew("ItemSlot", __fw); } }
    private void DrawBody()
    {
        if (Item == null || QuickNumber == null) return;
        int n;
        try { n = QuickNumber(Item); } catch { return; }
        if (n < 0) return;
        var box = new Rect2(1, 1, 10, 11);
        DrawRect(box, Colors.White);
        DrawRect(box, new Color(0, 0, 0, 0.8f), false, 1f);
        var font = ThemeDB.FallbackFont;
        DrawString(font, new Vector2(1, 10), n.ToString(), HorizontalAlignment.Center, 10, 9, Colors.Black);
    }

    // dropped on: its grid decides (a pack takes it at this square, or stacks it onto this item)
    public override bool _CanDropData(Vector2 at, Variant data) =>
        Grid != null && data.VariantType == Variant.Type.String && (string)data == "acgodot-item" && Dragging != null && Grid.CanTake(Item);
    public override void _DropData(Vector2 at, Variant data) => Grid?.TakeDrop(Index, Item);

    /// <summary>The item under the mouse in a pack, a corpse or on you (null: none) - plugins' item hover reads it.</summary>
    public static Item? Hovered => _hovered is { } h && IsInstanceValid(h) && h.IsVisibleInTree() && h.GetGlobalRect().HasPoint(h.GetGlobalMousePosition()) ? h.Item : null;
    private static ItemSlot? _hovered;
    public override void _Notification(int what)
    {
        if (what == NotificationMouseEnter) _hovered = this;
        else if (what == NotificationMouseExit && _hovered == this) _hovered = null;
    }

    /// <summary>What's being dragged (Godot carries only a marker; the item is here).</summary>
    public static Item? Dragging;
    public static string DraggingFrom = "";
    /// <summary>How many of a stack are chosen to take (the control bar's box), and splitting them off (Main sets these).</summary>
    public static Func<Item, int>? Splitting;
    public static Func<Item, int, Item?>? SplitOff;
    /// <summary>The stack the dragged one was split from (null: not split).</summary>
    public static Item? SplitFrom;

    public override Variant _GetDragData(Vector2 atPosition)
    {
        if (Item == null) return default;
        Dragging = Item; DraggingFrom = Source; SplitFrom = null;
        // a stack in the pack with fewer chosen in the control bar's box: that many split off and dragged (put back if
        // the drag goes nowhere)
        if (Source == "pack" && Item.Stack > 1 && Splitting?.Invoke(Item) is int n && n > 0 && n < Item.Stack && SplitOff?.Invoke(Item, n) is { } part)
        {
            SplitFrom = Item;
            Dragging = part;
        }
        var pic = new TextureRect { Texture = Icon, Size = new Vector2(32, 32), ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize, StretchMode = TextureRect.StretchModeEnum.KeepAspectCentered, Modulate = new Color(1, 1, 1, 0.85f) };
        var holder = new Control();
        holder.AddChild(pic);
        pic.Position = new Vector2(-16, -16);
        holder.ZIndex = 1000; holder.ZAsRelative = false;   // (over everything: some squares sit a layer up)
        SetDragPreview(holder);
        return "acgodot-item";
    }
}
