using System.Collections.Generic;
using System;
using System.IO;
using DatReaderWriter;
using DatReaderWriter.DBObjs;
using DatReaderWriter.Options;
using DatReaderWriter.Lib.IO;
using DatReaderWriter.Enums;

namespace ACGodot;

/// <summary>
/// The game's data files (client_portal.dat, client_cell_1.dat, client_local_English.dat, client_highres.dat), opened
/// read-only through DatReaderWriter. Reads are serialised with one lock, so background threads can load landblocks.
/// </summary>
public sealed class Dats : IDisposable, AcDream.Core.Content.IDatObjectSource
{
    public string Folder { get; }
    private readonly DatCollection _dats;
    private readonly object _lock = new();

    private Dats(string folder, DatCollection dats)
    {
        Folder = folder; _dats = dats;
        foreach (var db in new DatDatabase?[] { dats.Cell, dats.Portal, dats.Local, dats.HighRes }) Guard(db);
    }

    // The library reads a file from the data by following its chain of blocks until the buffer it borrowed is full - and
    // the buffer is nearly always bigger than the file, so it reads on past the file's last block, wherever that
    // block's "next" points. Usually that's nothing (0); for some files it's a leftover pointer (a freed block's, its top
    // bit set), which sent the read far outside the mapped file: depending on what the memory there happened to be, the
    // game died with an access violation as it entered the world, now and then. This stands in front of the library's
    // reader and stops at the end of the chain, at a pointer that isn't one, and at the end of the file.
    private static void Guard(DatDatabase? db)
    {
        if (db == null) return;
        try
        {
            var inner = db.BlockAllocator;
            if (inner == null || inner is SafeReads) return;
            long length = 0;
            try { length = new FileInfo(db.Options.FilePath).Length; } catch { }
            var safe = new SafeReads(inner, length, db.Options.FilePath);
            const System.Reflection.BindingFlags any = System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic;
            var own = typeof(DatDatabase).GetField("BlockAllocator", any);
            var tree = db.Tree?.GetType().GetField("<BlockAllocator>k__BackingField", any);
            if (own == null || tree == null || db.Tree == null) { Godot.GD.PushWarning("data files: couldn't guard their reads (the library has changed)"); return; }
            own.SetValue(db, safe);
            tree.SetValue(db.Tree, safe);
        }
        catch (Exception ex) { Godot.GD.PushWarning("data files: couldn't guard their reads: " + ex.Message); }
    }

    private sealed class SafeReads : DatReaderWriter.Lib.IO.BlockAllocators.IDatBlockAllocator
    {
        private readonly DatReaderWriter.Lib.IO.BlockAllocators.IDatBlockAllocator _in;
        private readonly long _length;
        [ThreadStatic] private static byte[]? _four;
        // (the file read with ordinary reads of our own, not through the library's mapped memory: a read that can't be
        //  done - past the end, a file changed underneath - is then a short read that's noted, not the game dying)
        private readonly Microsoft.Win32.SafeHandles.SafeFileHandle? _file;
        private readonly string _path;
        private int _noted;
        public SafeReads(DatReaderWriter.Lib.IO.BlockAllocators.IDatBlockAllocator inner, long length, string path)
        {
            _in = inner; _length = length; _path = path;
            try { _file = File.OpenHandle(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete); } catch { _file = null; }
        }

        private void Note(string what)
        {
            if (System.Threading.Interlocked.Increment(ref _noted) > 5) return;
            Godot.GD.PrintErr($"[dats] {Path.GetFileName(_path)}: {what} (file {_length} bytes)");
        }

        /// <summary>So many bytes from a place in the file; false when they aren't all there.</summary>
        private bool Read(byte[] buffer, int at, long from, int n)
        {
            if (from < 0 || n <= 0 || at < 0 || at + n > buffer.Length) { Note($"a read of {n} at {from} that can't be"); return false; }
            if (_file == null)
            {
                if (_length > 0 && from + n > _length) { Note($"a read of {n} at {from}, past the end"); return false; }
                _in.ReadBytes(buffer, at, (int)from, n);
                return true;
            }
            try
            {
                int got = 0;
                while (got < n)
                {
                    int k = RandomAccess.Read(_file, new Span<byte>(buffer, at + got, n - got), from + got);
                    if (k <= 0) { Note($"a read of {n} at {from} got only {got}"); return false; }
                    got += k;
                }
                return true;
            }
            catch (Exception ex) { Note($"a read of {n} at {from} failed: {ex.Message}"); return false; }
        }

        public void ReadBlock(byte[] buffer, int startingBlock)
        {
            int want = buffer.Length, done = 0, per = _in.Header.BlockSize - 4;
            if (per <= 0) return;
            var four = _four ??= new byte[4];
            int hops = 0;
            while (startingBlock > 0 && done < want && hops++ < 1_000_000)
            {
                int n = Math.Min(per, want - done);
                // (the last block of the file may be cut short: what there is of it)
                if (_length > 0 && (long)startingBlock + 4 + n > _length) n = (int)Math.Max(0, _length - ((long)startingBlock + 4));
                if (n <= 0 || !Read(buffer, done, (long)startingBlock + 4, n)) return;
                done += n;
                if (done >= want) return;
                if (!Read(four, 0, startingBlock, 4)) return;
                startingBlock = BitConverter.ToInt32(four, 0);   // (0: the chain's end; below 0: a freed block's mark, not a place)
            }
        }
        public System.Threading.Tasks.ValueTask ReadBlockAsync(byte[] buffer, int startingBlock, System.Threading.CancellationToken ct = default)
        { ReadBlock(buffer, startingBlock); return System.Threading.Tasks.ValueTask.CompletedTask; }
        public void ReadBytes(byte[] buffer, int bufferOffset, int datOffset, int numBytes)
        {
            // (asked for outright - the file's index: only what's in the file)
            if (datOffset < 0 || numBytes <= 0 || (_length > 0 && (long)datOffset + numBytes > _length)) return;
            Read(buffer, bufferOffset, datOffset, numBytes);
        }

        public bool CanWrite => _in.CanWrite;
        public bool HasHeaderData => _in.HasHeaderData;
        public DatHeader Header => _in.Header;
        public void InitNew(DatFileType type, uint subset, int blockSize = 1024, int numBlocksToAllocate = 1024) => _in.InitNew(type, subset, blockSize, numBlocksToAllocate);
        public void SetVersion(string version, int engineVersion, int gameVersion, Guid majorVersion, uint minorVersion) => _in.SetVersion(version, engineVersion, gameVersion, majorVersion, minorVersion);
        public void WriteBytes(byte[] buffer, int byteOffset, int numBytes) => _in.WriteBytes(buffer, byteOffset, numBytes);
        public int WriteBlock(byte[] buffer, int numBytes, int startingBlock = 0) => _in.WriteBlock(buffer, numBytes, startingBlock);
        public System.Threading.Tasks.ValueTask<int> WriteBlockAsync(byte[] buffer, int numBytes, int startingBlock = 0, System.Threading.CancellationToken ct = default) => _in.WriteBlockAsync(buffer, numBytes, startingBlock, ct);
        public bool TryGetBlockOffsets(int startingBlock, out List<int> fileBlocks) => _in.TryGetBlockOffsets(startingBlock, out fileBlocks);
        public void AllocateEmptyBlocks(int numBlocksToAllocate) => _in.AllocateEmptyBlocks(numBlocksToAllocate);
        public int ReserveBlock() => _in.ReserveBlock();
        public void SetRootBlock(int offset) => _in.SetRootBlock(offset);
        public void Dispose() { try { _file?.Dispose(); } catch { } _in.Dispose(); }
    }

    /// <summary>Opens the data files in <paramref name="folder"/>; null and a reason when they can't be opened.</summary>
    public static Dats? Open(string folder, out string error)
    {
        error = "";
        foreach (string need in new[] { "client_portal.dat", "client_cell_1.dat" })
        {
            if (!File.Exists(Path.Combine(folder, need)))
            {
                error = need + " isn't in " + folder;
                return null;
            }
        }
        try
        {
            return new Dats(folder, new DatCollection(folder, DatAccessType.Read));
        }
        catch (Exception ex)
        {
            error = "couldn't open the data files: " + ex.Message;
            return null;
        }
    }

    /// <summary>An object from the portal (or high-res) file.</summary>
    public T? Portal<T>(uint id) where T : class, IDBObj
    {
        lock (_lock)
        {
            if (_dats.Portal.TryGet<T>(id, out var v)) return v;
            if (_dats.HighRes != null && _dats.HighRes.TryGet<T>(id, out var h)) return h;
            return null;
        }
    }

    /// <summary>The ids of every object of a type (the file that holds the type).</summary>
    public List<uint> AllIds<T>() where T : IDBObj
    {
        lock (_lock) return new List<uint>(_dats.GetAllIdsOfType<T>());
    }

    /// <summary>An object from the cell file (landblocks, their info, dungeon cells).</summary>
    public T? Cell<T>(uint id) where T : class, IDBObj
    {
        lock (_lock) return _dats.Cell.TryGet<T>(id, out var v) ? v : null;
    }

    // ── for OpenAC's code: any object, from whichever file holds its type ──
    [return: System.Diagnostics.CodeAnalysis.MaybeNull]
    public T Get<T>(uint fileId) where T : IDBObj => TryGet<T>(fileId, out var v) ? v : default!;

    public bool TryGet<T>(uint fileId, [System.Diagnostics.CodeAnalysis.MaybeNullWhen(false)] out T value) where T : IDBObj
    {
        lock (_lock)
        {
            switch (_dats.TypeToDatFileType<T>())
            {
                case DatFileType.Cell: return _dats.Cell.TryGet(fileId, out value);
                case DatFileType.Portal:
                    if (_dats.Portal.TryGet(fileId, out value)) return true;
                    if (_dats.HighRes != null && _dats.HighRes.TryGet(fileId, out value)) return true;
                    return false;
                case DatFileType.Local: return _dats.Local.TryGet(fileId, out value);
                default: value = default!; return false;
            }
        }
    }

    /// <summary>
    /// An object's bytes as stored (decompressed), and which file they came from (0 cell, 1 portal, 2 high-res,
    /// 3 local) - for saving the objects something used (see Physics.RecordingDats).
    /// </summary>
    public bool TryRaw<T>(uint fileId, out byte[] bytes, out int file) where T : IDBObj
    {
        lock (_lock)
        {
            bytes = Array.Empty<byte>(); file = -1;
            switch (_dats.TypeToDatFileType<T>())
            {
                case DatFileType.Cell: file = 0; return _dats.Cell.TryGetFileBytes(fileId, out bytes!, true);
                case DatFileType.Portal:
                    if (_dats.Portal.TryGetFileBytes(fileId, out bytes!, true)) { file = 1; return true; }
                    if (_dats.HighRes != null && _dats.HighRes.TryGetFileBytes(fileId, out bytes!, true)) { file = 2; return true; }
                    return false;
                case DatFileType.Local: file = 3; return _dats.Local.TryGetFileBytes(fileId, out bytes!, true);
                default: return false;
            }
        }
    }

    public void Dispose()
    {
        lock (_lock) _dats.Dispose();
    }
}
