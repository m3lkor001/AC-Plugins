namespace ACGodot.Net;

/// <summary>A character to be made on a server: what the game's creation message carries (see NetGame.CreateCharacter).</summary>
public sealed class NewCharacter
{
    public string Name = "";
    public uint Heritage, Gender, StartArea;
    public int Template;
    /// <summary>Strength, endurance, coordination, quickness, focus, self.</summary>
    public uint[] Attributes = new uint[6];
    /// <summary>One for each skill number 0..54: 0 not in the game, 1 untrained, 2 trained, 3 specialized.</summary>
    public uint[] Skills = new uint[55];
    // looks: places in the heritage's lists (the clothes' colours are the lists' own values)
    public uint Eyes, Nose, Mouth, HairColor, EyeColor, HairStyle, Shirt, ShirtColor, Pants, PantsColor, Shoes, ShoesColor;
    public double SkinHue, HairHue, ShirtHue, PantsHue, ShoesHue;
}
