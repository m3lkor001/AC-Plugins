using System;
using System.Collections.Generic;
using System.Linq;
using DatReaderWriter.DBObjs;
using DatReaderWriter.Enums;
using DatReaderWriter.Types;
using Godot;
using DrwFont = DatReaderWriter.DBObjs.Font;

namespace ACGodot.UI;

/// <summary>
/// The game's own interface, from its data: the layouts (LayoutDesc 0x21...: every window and panel as elements
/// with places, sizes, images for each state, and properties), the images they use and the game's fonts. An element
/// can take its look from another layout's element (its base): that's followed, so what's drawn is what the game
/// draws.
/// </summary>
public sealed class RetailUi
{
    private readonly Dats _dats;
    private readonly Objects.ObjectAssets _assets;
    private readonly Dictionary<uint, LayoutDesc?> _layouts = new();
    private readonly Dictionary<uint, RetailFont?> _fonts = new();

    public RetailUi(Dats dats, Objects.ObjectAssets assets) { _dats = dats; _assets = assets; Current = this; }

    /// <summary>The game's interface data, once open.</summary>
    public static RetailUi? Current { get; private set; }

    public LayoutDesc? Layout(uint id)
    {
        if (_layouts.TryGetValue(id, out var l)) return l;
        try { l = _dats.Get<LayoutDesc>(id); } catch (Exception ex) { GD.PushWarning($"layout {id:X8}: {ex.Message}"); l = null; }
        return _layouts[id] = l;
    }

    /// <summary>An element of a layout, wherever it is in it.</summary>
    public ElementDesc? Find(uint layoutId, uint elementId)
    {
        var l = Layout(layoutId);
        if (l == null) return null;
        foreach (var e in l.Elements.Values) if (Find(e, elementId) is { } f) return f;
        return null;
    }

    private static ElementDesc? Find(ElementDesc e, uint id)
    {
        if (e.ElementId == id) return e;
        foreach (var c in e.Children.Values) if (Find(c, id) is { } f) return f;
        return null;
    }

    public Texture2D? Image(uint id) => id == 0 ? null : _assets.Icon(id);

    private readonly Dictionary<uint, StringTable?> _tables = new();

    /// <summary>A string from the game's string tables (labels, titles), or null.</summary>
    public string? String(StringInfo? info)
    {
        if (info == null || info.StringId == 0) return null;
        uint table = info.TableId.DataId;
        if (table == 0) return null;
        if (!_tables.TryGetValue(table, out var t))
        {
            try { t = _dats.Get<StringTable>(table); } catch { t = null; }
            _tables[table] = t;
        }
        if (t == null || !t.Strings.TryGetValue(info.StringId, out var s) || s.Strings.Count == 0) return null;
        return string.Concat(s.Strings).Replace("\\n", "\n");
    }

    public RetailFont? Font(uint id)
    {
        if (id == 0) return null;
        if (_fonts.TryGetValue(id, out var f)) return f;
        f = null;
        try
        {
            var font = _dats.Get<DrwFont>(id);
            if (font != null) f = new RetailFont(font, Image(font.ForegroundSurfaceDataId), Image(font.BackgroundSurfaceDataId));
        }
        catch (Exception ex) { GD.PushWarning($"font {id:X8}: {ex.Message}"); }
        return _fonts[id] = f;
    }

    /// <summary>The look of an element with its base's (and its base's base's) filled in.</summary>
    public Resolved Resolve(ElementDesc e, int depth = 0)
    {
        var r = new Resolved { E = e };
        if (depth < 8 && e.BaseLayoutId != 0 && e.BaseElement != 0 && Find(e.BaseLayoutId, e.BaseElement) is { } b)
        {
            var rb = Resolve(b, depth + 1);
            r.Media.AddRange(rb.Media);
            foreach (var kv in rb.Props) r.Props[kv.Key] = kv.Value;
            foreach (var kv in rb.States) r.States[kv.Key] = kv.Value;
            r.Children.AddRange(rb.Children);
            r.Width = rb.Width; r.Height = rb.Height; r.Type = rb.Type;
            r.BaseWidth = rb.Width; r.BaseHeight = rb.Height;
            r.DefaultState = rb.DefaultState;
        }
        if (e.StateDesc != null)
        {
            if (e.StateDesc.Media.Count > 0) { r.Media.Clear(); r.Media.AddRange(e.StateDesc.Media); }
            foreach (var kv in e.StateDesc.Properties) r.Props[kv.Key] = kv.Value;
        }
        foreach (var kv in e.States) r.States[kv.Key] = kv.Value;
        foreach (var c in e.Children.Values)
        {
            r.Children.RemoveAll(x => x.ElementId == c.ElementId);
            r.Children.Add(c);
        }
        if (e.DefaultState != UIStateId.Undef) r.DefaultState = e.DefaultState;
        if (e.Width > 0) r.Width = e.Width;
        if (e.Height > 0) r.Height = e.Height;
        if (e.Type != 0) r.Type = e.Type;
        return r;
    }

    public sealed class Resolved
    {
        public ElementDesc E = null!;
        public uint Type, Width, Height;
        /// <summary>The size its base was laid out at (its children taken from the base sit for that size).</summary>
        public uint BaseWidth, BaseHeight;
        public readonly List<MediaDesc> Media = new();
        public readonly Dictionary<uint, BaseProperty> Props = new();
        public readonly Dictionary<UIStateId, StateDesc> States = new();
        public readonly List<ElementDesc> Children = new();
        public UIStateId DefaultState = UIStateId.Undef;
    }

    /// <summary>Builds a layout's element (its first top-level one if no id is given) as a Godot control tree.</summary>
    public UiNode? Build(uint layoutId, uint elementId = 0)
    {
        var l = Layout(layoutId);
        if (l == null) return null;
        var e = elementId != 0 ? Find(layoutId, elementId) : l.Elements.Values.OrderBy(x => x.ReadOrder).FirstOrDefault();
        return e == null ? null : new UiNode(this, e);
    }
}

/// <summary>
/// One of the game's interface elements: drawn with its current state's image (tiled across it, as the game draws a
/// small image over a bigger element), with its children on top. A meter (type 7) shows its filled part up to a
/// fraction; an element with a font style shows text in the game's font.
/// </summary>
public partial class UiNode : Control
{
    private readonly RetailUi _ui;
    public readonly RetailUi.Resolved R;
    public uint Id => R.E.ElementId;
    private Texture2D? _image;
    private UIStateId _state;
    private string? _text;
    private float _fraction = 1f;
    private RetailFont? _font;
    private Color _textColor = Colors.White;
    private int _halign = 1, _valign = 1;
    private UiNode? _fill;   // a meter's filled part
    private Vector2 _design;  // the size its children were laid out for

    public UiNode(RetailUi ui, ElementDesc e)
    {
        _ui = ui;
        R = ui.Resolve(e);
        Position = new Vector2(e.X, e.Y);
        Size = new Vector2(R.Width, R.Height);
        CustomMinimumSize = Size;
        MouseFilter = MouseFilterEnum.Ignore;
        ClipContents = false;
        // the font style: font (0x1A), colour (0x1B), alignment (0x14 across: 1 left, 2 middle, 3 right; 0x15 up and down)
        if (R.Props.TryGetValue(0x1A, out var fp) && First(fp) is DataIdBaseProperty fid) _font = ui.Font(fid.Value);
        if (R.Props.TryGetValue(0x1B, out var cp) && First(cp) is ColorBaseProperty col)
            _textColor = new Color(col.Value.Red / 255f, col.Value.Green / 255f, col.Value.Blue / 255f, 1f);
        if (R.Props.TryGetValue(0x14, out var ha) && ha is EnumBaseProperty h) _halign = (int)h.Value;
        if (R.Props.TryGetValue(0x15, out var va) && va is EnumBaseProperty v) _valign = (int)v.Value;
        _image = ImageOf(R.Media);
        // its label (property 0x17: a string from the game's tables - a tab's or button's words)
        if (R.Props.TryGetValue(0x17, out var lp) && lp is StringInfoBaseProperty si) _text = ui.String(si.Value);
        // children from its base sit for the base's size: laid out again for its own below
        _design = e.Children.Count == 0 && R.BaseWidth > 0 ? new Vector2(R.BaseWidth, R.BaseHeight) : new Vector2(R.Width, R.Height);
        foreach (var c in R.Children.OrderBy(c => c.ZLevel).ThenBy(c => c.ReadOrder))
        {
            var n = new UiNode(ui, c);
            AddChild(n);
        }
        // a meter: the part that fills is its element 2 (the empty background is the other image set)
        if (R.Type == 7)
        {
            foreach (var c in GetChildren()) if (c is UiNode n && n.Id == 2) _fill = n;
            if (_fill != null)
            {
                _fill.ClipContents = true;
                MoveChild(_fill, GetChildCount() - 1);
                // its text (a font-style element) over the fill
                foreach (var c in GetChildren()) if (c is UiNode n && n.FontStyle != null) MoveChild(n, GetChildCount() - 1);
            }
        }
        if (_design != DesignSize && _design.X > 0 && _design.Y > 0) { var own = DesignSize; Resize(own); }
        if (R.DefaultState != UIStateId.Undef) SetState(R.DefaultState);   // its own, or its base's (the "more below" arrow: hidden)
        // no state of its own to start in, but its base has a Normal look (the chat's Send button): start in that
        else if (R.States.TryGetValue(UIStateId.Normal, out var ns) && ns.Media.Count > 0) SetState(UIStateId.Normal);
    }

    private static BaseProperty? First(BaseProperty p) => p is ArrayBaseProperty a ? a.Value.FirstOrDefault() : p;

    private Texture2D? ImageOf(IEnumerable<MediaDesc> media)
    {
        foreach (var m in media)
        {
            if (m is MediaDescImage im) return im.File == 0 ? null : _ui.Image(im.File);
            if (m is MediaDescAnimation an && an.Frames.Count > 0) return _ui.Image(an.Frames[0]);
        }
        return null;
    }

    /// <summary>Its place and size as the layout has them.</summary>
    public Vector2 DesignPos => new(R.E.X, R.E.Y);
    public Vector2 DesignSize => new(R.Width, R.Height);

    /// <summary>
    /// Resizes it, its children following their edges as the game's do: tied to both sides they stretch, tied to
    /// the right or bottom they move with it, centred ones stay centred, the rest stay put.
    /// </summary>
    public void Resize(Vector2 size)
    {
        // its least size first: set after, the old (bigger) one would hold the size up when shrinking
        CustomMinimumSize = size;
        Size = size;
        Vector2 design = _design, grow = size - design;
        foreach (var c in GetChildren())
        {
            if (c is not UiNode n || n.Pinned) continue;
            var e = n.R.E;
            Vector2 p = n.DesignPos, sz = n.DesignSize;
            (p.X, sz.X) = Fit(p.X, sz.X, e.LeftEdge, e.RightEdge, design.X, size.X, grow.X);
            (p.Y, sz.Y) = Fit(p.Y, sz.Y, e.TopEdge, e.BottomEdge, design.Y, size.Y, grow.Y);
            n.Position = p + n.DesignShift;
            if (n == _fill) { n.Resize(new Vector2(sz.X, sz.Y)); n.CustomMinimumSize = Vector2.Zero; n.Size = new Vector2(sz.X * _fraction, sz.Y); }   // (no least size: it shrinks with the meter)
            else n.Resize(sz);
        }
        QueueRedraw();
    }

    private static (float pos, float size) Fit(float pos, float size, uint near, uint far, float design, float now, float grow)
    {
        if (near == 1 && far == 1) return (pos, Math.Max(0, size + grow));      // both sides: stretch
        // the far side: move with it, keeping its gap to that side (a piece the layout has beyond its parent's edge -
        // the chat line's right-hand highlight - goes to the edge)
        if (near == 2 && far == 1) return (now - size - Math.Max(0f, design - pos - size), size);
        if (near == 3 || far == 3) return (design > 0 ? (pos + size * 0.5f) * now / design - size * 0.5f : pos, size);   // centred
        return (pos, size);
    }

    /// <summary>The element under this one with an id, anywhere below.</summary>
    public UiNode? Find(uint id)
    {
        if (Id == id) return this;
        foreach (var c in GetChildren()) if (c is UiNode n && n.Find(id) is { } f) return f;
        return null;
    }

    /// <summary>Its picture in a state (whatever state it's in now): a button's closed look, say.</summary>
    public Texture2D? ImageFor(UIStateId state) => R.States.TryGetValue(state, out var sd) && sd.Media.Count > 0 ? ImageOf(sd.Media) : ImageOf(R.Media);

    /// <summary>Into a state (its image, and its children's, for that state): e.g. ShowDetail, Ghosted.</summary>
    public void SetState(UIStateId state)
    {
        _state = state;
        if (R.States.TryGetValue(state, out var sd) && sd.Media.Count > 0) _image = ImageOf(sd.Media);
        else _image = ImageOf(R.Media);
        // a state that hides it (property 0x3B: the chat's "more below" arrow is hidden until there's something below)
        if (sd != null && sd.Properties.TryGetValue(0x3B, out var hp) && hp is BoolBaseProperty hidden) Visible = !hidden.Value;
        foreach (var c in GetChildren()) if (c is UiNode n) n.SetState(state);
        QueueRedraw();
    }

    public string? Text { get => _text; set { if (_text != value) { _text = value; QueueRedraw(); _textLayer?.QueueRedraw(); } } }

    /// <summary>Its text in the middle (across and up and down).</summary>
    public void CenterText() { _halign = 2; _valign = 2; QueueRedraw(); }
    /// <summary>Its words across the middle, at the top (the selection's name over its health bar or stack box).</summary>
    public void TopText() { _halign = 2; _valign = 5; QueueRedraw(); }

    /// <summary>A meter's fill (0..1).</summary>
    public float Fraction
    {
        get => _fraction;
        set
        {
            _fraction = Math.Clamp(value, 0f, 1f);
            if (_fill != null) { _fill.CustomMinimumSize = Vector2.Zero; _fill.Size = new Vector2(Size.X * _fraction, _fill.Size.Y); }
        }
    }

    /// <summary>Placed by hand: its parent's resizing leaves it alone.</summary>
    public bool Pinned;
    /// <summary>Added to where the layout puts it on every resize (a copy of a layout piece set beside the original).</summary>
    public Vector2 DesignShift;

    /// <summary>Text in a font and colour of its own (an element with no text style, e.g. a button's number).</summary>
    public void SetTextStyle(RetailFont? font, Color color) { _font = font; _textColor = color; QueueRedraw(); }

    /// <summary>Drawn without its picture (its text and children only).</summary>
    public bool NoImage { get => _noImage; set { _noImage = value; QueueRedraw(); } }
    private bool _noImage;

    /// <summary>Wider than its picture, the picture's ends stay and its middle stretches (instead of the picture repeating).</summary>
    public bool Slice;
    private const float SliceEnd = 14f;
    /// <summary>A frame's picture: these margins (left, top, right, bottom) keep their size as it's resized, the rest stretches.</summary>
    public (float l, float t, float r, float b)? Patch;
    public override void _Draw() { long __fw = ACGodot.FrameWatch.DrawStart(); try { DrawBody(); } finally { ACGodot.FrameWatch.Drew("UiNode", __fw); } }
    private void DrawBody()
    {
        if (_image != null && !_noImage)
        {
            Vector2 ts = _image.GetSize();
            Vector2 full = Size;
            if (Patch is { } pm && (full.X != ts.X || full.Y != ts.Y) && ts.X > pm.l + pm.r && ts.Y > pm.t + pm.b && full.X >= pm.l + pm.r && full.Y >= pm.t + pm.b)
            {
                // a frame's picture on a bigger (or smaller) frame: its corners as they are, its sides and middle drawn out
                float[] sx = { 0, pm.l, ts.X - pm.r, ts.X }, sy = { 0, pm.t, ts.Y - pm.b, ts.Y };
                float[] dx = { 0, pm.l, full.X - pm.r, full.X }, dy = { 0, pm.t, full.Y - pm.b, full.Y };
                for (int iy = 0; iy < 3; iy++)
                    for (int ix = 0; ix < 3; ix++)
                    {
                        var dst = new Rect2(dx[ix], dy[iy], dx[ix + 1] - dx[ix], dy[iy + 1] - dy[iy]);
                        var src = new Rect2(sx[ix], sy[iy], sx[ix + 1] - sx[ix], sy[iy + 1] - sy[iy]);
                        if (dst.Size.X > 0 && dst.Size.Y > 0 && src.Size.X > 0 && src.Size.Y > 0) DrawTextureRectRegion(_image, dst, src);
                    }
            }
            else if (Slice && full.X > ts.X && ts.X > 2 * SliceEnd)
            {
                // a tab's picture on a wider tab: its two ends as they are, its middle drawn out between them
                float e = SliceEnd;
                DrawTextureRectRegion(_image, new Rect2(0, 0, e, full.Y), new Rect2(0, 0, e, Math.Min(ts.Y, full.Y)));
                DrawTextureRectRegion(_image, new Rect2(e, 0, full.X - 2 * e, full.Y), new Rect2(e, 0, ts.X - 2 * e, Math.Min(ts.Y, full.Y)));
                DrawTextureRectRegion(_image, new Rect2(full.X - e, 0, e, full.Y), new Rect2(ts.X - e, 0, e, Math.Min(ts.Y, full.Y)));
            }
            else if (ts.X >= full.X && ts.Y >= full.Y) DrawTextureRectRegion(_image, new Rect2(Vector2.Zero, full), new Rect2(Vector2.Zero, full));
            else DrawTextureRect(_image, new Rect2(Vector2.Zero, full), tile: true);
        }
        // its words are drawn by a layer of their own over its children and the pieces drawn after it (a tab's or
        // a box's pictures would cover them otherwise)
        if (!string.IsNullOrEmpty(_text) && (_font ?? RetailTheme.Text) != null)
        {
            if (_textLayer == null)
            {
                _textLayer = new Control { MouseFilter = MouseFilterEnum.Ignore, ZIndex = 1 };
                _textLayer.SetAnchorsPreset(LayoutPreset.FullRect);
                _textLayer.Draw += DrawText;
                AddChild(_textLayer);
            }
            _textLayer.QueueRedraw();
        }
        else _textLayer?.QueueRedraw();
    }

    private Control? _textLayer;

    private void DrawText()
    {
        // no text style of its own (the selection's name box): the game's usual font
        var font = _font ?? RetailTheme.Text;
        if (_textLayer == null || string.IsNullOrEmpty(_text) || font == null) return;
        Vector2 sz = font.Measure(_text);
        Vector2 size = _textLayer.Size;
        float x = _halign == 2 ? (size.X - sz.X) * 0.5f : _halign == 3 ? size.X - sz.X : 0f;
        float y = _valign == 5 ? -3f * RetailFont.Scale : _valign == 2 ? (size.Y - sz.Y) * 0.5f : _valign == 3 ? size.Y - sz.Y : (size.Y - sz.Y) * 0.5f;
        font.Draw(_textLayer, _text, new Vector2(MathF.Round(x), MathF.Round(y)), _textColor);
    }

    /// <summary>Clicks and drags on it (it takes the mouse once something listens).</summary>
    public Action<InputEvent>? OnInput
    {
        get => _onInput;
        set { _onInput = value; MouseFilter = value != null ? MouseFilterEnum.Stop : MouseFilterEnum.Ignore; }
    }
    private Action<InputEvent>? _onInput;
    public override void _GuiInput(InputEvent e) => _onInput?.Invoke(e);

    /// <summary>Its text style's font and colour, for drawing text over it from outside.</summary>
    public RetailFont? FontStyle => _font;
    public Color TextColor => _textColor;
}

/// <summary>One of the game's fonts: its letters cut from the font's image (and an outline image behind them).</summary>
public sealed class RetailFont
{
    private readonly Dictionary<char, FontCharDesc> _chars = new();
    private readonly Texture2D? _fore, _back;
    public readonly int Height, Baseline;

    public RetailFont(DrwFont f, Texture2D? fore, Texture2D? back)
    {
        foreach (var c in f.CharDescs) _chars[(char)c.Unicode] = c;
        _fore = fore; _back = back;
        Height = (int)f.MaxCharHeight;
        Baseline = (int)f.BaselineOffset;
    }

    /// <summary>How much bigger the game's text is drawn (Options > Character > Text size).</summary>
    public static float Scale = 1f;

    /// <summary>A font chosen in the options (Options > Character > Font) that every one of the game's fonts is drawn in
    /// instead of its own letters - each at a size going with its own; null: the game's own letters.</summary>
    public static Godot.Font? Override;
    /// <summary>The chosen font's size for this one of the game's fonts (its own height, a little bigger: the game's letters fill their height).</summary>
    private int OvSize(float scale) => Math.Max(8, (int)MathF.Round(Height * 1.15f * scale));

    /// <summary>A line's height as drawn (scaled).</summary>
    public int LineHeight => LineHeightAt(Scale);

    public Vector2 Measure(string s) => Measure(s, Scale);
    /// <summary>At a scale of its own (a chat window's text size).</summary>
    public Vector2 Measure(string s, float scale)
    {
        if (Override != null)
        {
            int fs = OvSize(scale);
            return new Vector2(s.Length == 0 ? 0f : Override.GetStringSize(s, HorizontalAlignment.Left, -1, fs).X, LineHeightAt(scale));
        }
        float w = 0;
        foreach (char ch in s) if (_chars.TryGetValue(ch, out var c)) w += c.HorizontalOffsetBefore + c.Width + c.HorizontalOffsetAfter;
        return new Vector2(w * scale, Height * scale);
    }
    public int LineHeightAt(float scale) => Override != null ? (int)MathF.Ceiling(Override.GetHeight(OvSize(scale))) : (int)MathF.Ceiling(Height * scale);

    /// <summary>
    /// The font as a Godot font, so Godot's labels, buttons and text boxes write in it: each letter's picture (white,
    /// with the game's black outline round it, so a colour tints the letter and leaves the outline) at its place.
    /// </summary>
    public FontFile? ToGodotFont()
    {
        var fi = _fore?.GetImage();
        if (fi == null) return null;
        if (fi.IsCompressed()) fi.Decompress();
        fi.Convert(Image.Format.Rgba8);
        var bi = _back?.GetImage();
        if (bi != null) { if (bi.IsCompressed()) bi.Decompress(); bi.Convert(Image.Format.Rgba8); }
        int w = fi.GetWidth(), h = fi.GetHeight();
        var img = Image.CreateEmpty(w, h, false, Image.Format.Rgba8);
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
            {
                float fa = fi.GetPixel(x, y).A;
                float ba = bi != null && x < bi.GetWidth() && y < bi.GetHeight() ? bi.GetPixel(x, y).A : 0f;
                float a = Math.Max(fa, ba);
                float v = a > 0f ? fa / a : 0f;   // white where the letter is, black where only its outline is
                img.SetPixel(x, y, new Color(v, v, v, a));
            }
        var ff = new FontFile { FixedSize = Height, FixedSizeScaleMode = TextServer.FixedSizeScaleMode.Enabled, Antialiasing = TextServer.FontAntialiasing.None };
        var size = new Vector2I(Height, 0);
        ff.SetTextureImage(0, size, 0, img);
        ff.SetCacheAscent(0, Height, Baseline);
        ff.SetCacheDescent(0, Height, Math.Max(0, Height - Baseline));
        foreach (var (ch, c) in _chars)
        {
            int g = ch;
            ff.SetGlyphAdvance(0, Height, g, new Vector2(c.HorizontalOffsetBefore + c.Width + c.HorizontalOffsetAfter, 0));
            ff.SetGlyphOffset(0, size, g, new Vector2(c.HorizontalOffsetBefore, c.VerticalOffsetBefore - Baseline));
            ff.SetGlyphSize(0, size, g, new Vector2(c.Width, c.Height));
            ff.SetGlyphUVRect(0, size, g, new Rect2(c.OffsetX, c.OffsetY, c.Width, c.Height));
            ff.SetGlyphTextureIdx(0, size, g, 0);
        }
        return ff;
    }

    public void Draw(CanvasItem on, string s, Vector2 at, Color color) => Draw(on, s, at, color, Scale);
    public void Draw(CanvasItem on, string s, Vector2 at, Color color, float scale)
    {
        if (Override != null)
        {
            // (with a dark outline, as the game's letters have)
            int fs = OvSize(scale);
            var pos = new Vector2(at.X, at.Y + Override.GetAscent(fs));
            on.DrawStringOutline(Override, pos, s, HorizontalAlignment.Left, -1, fs, Math.Max(2, fs / 6), new Color(0, 0, 0, color.A * 0.85f));
            on.DrawString(Override, pos, s, HorizontalAlignment.Left, -1, fs, color);
            return;
        }
        if (_fore == null) return;
        float x = at.X, k = scale;
        foreach (char ch in s)
        {
            if (!_chars.TryGetValue(ch, out var c)) continue;
            x += c.HorizontalOffsetBefore * k;
            var src = new Rect2(c.OffsetX, c.OffsetY, c.Width, c.Height);
            var dst = new Rect2(x, at.Y + c.VerticalOffsetBefore * k, c.Width * k, c.Height * k);
            if (_back != null) on.DrawTextureRectRegion(_back, dst, src, Colors.Black);
            on.DrawTextureRectRegion(_fore, dst, src, color);
            x += (c.Width + c.HorizontalOffsetAfter) * k;
        }
    }
}
