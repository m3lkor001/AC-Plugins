using System;
using System.Collections.Generic;
using Godot;

namespace ACGodot.UI;

/// <summary>
/// The game's examine panel (layout 0x2100006B): what identifying something shows. An item: its name as the title and
/// everything about it in the scrolling text, the inscription box under it. A creature or NPC: its name, its picture,
/// level and health, and what's known about it. Right-click something (or the magnifying glass) to open it.
/// </summary>
public partial class ExaminePanel : RetailWindow
{
    public const uint Layout = 0x2100006B;

    /// <summary>The ID panel shuts when something else is chosen (else it identifies the new thing). Kept in user://ui.cfg.</summary>
    public static bool CloseOnSelect
    {
        get { var c = new ConfigFile(); return global::ACGodot.SafeConfig.Load(c, "user://ui.cfg") == Error.Ok && (bool)c.GetValue("examine", "close_on_select", false); }
        set { var c = new ConfigFile(); global::ACGodot.SafeConfig.Load(c, "user://ui.cfg"); c.SetValue("examine", "close_on_select", value); global::ACGodot.SafeConfig.Save(c, "user://ui.cfg"); }
    }
    private UiNode? _title, _itemView, _creatureView, _playerView;
    private RichTextLabel? _itemText, _creatureText, _inscription;
    private TextEdit? _inscribe;          // (the box to write in, over the inscription, when the item can take one)
    private Combat.Item? _inscribing;     // (the item it's for)
    private string _inscribeWas = "";
    /// <summary>Told when you write on an item (the item, and what's written; empty wipes it).</summary>
    public Action<Combat.Item, string>? Inscribe;
    private UiNode? _cName, _cLine1, _cLine2, _cLine3, _cFoot;
    private TextureRect? _cIcon;
    public Func<uint, Texture2D?>? Icon;
    /// <summary>The fighting clock (a corpse's decay), who's killing things (you), and your vitals now.</summary>
    public Func<double>? Now;
    public string Killer = "you";
    public Func<(int health, int stamina, int mana)>? SelfVitals;

    public bool Setup()
    {
        if (!BuildFrom(Layout, 0x100005F2, "examine")) return false;
        var r = Root!;
        _title = r.Find(0x1000012D);
        TitleFrom(_title);
        CloseFrom(r.Find(0x100005F3));
        _itemView = r.Find(0x1000012E);
        _creatureView = r.Find(0x10000153);
        _playerView = r.Find(0x10000140);
        if (r.Find(0x1000013C) is { } it) _itemText = TextOver(it, new Color(1f, 1f, 1f));
        if (r.Find(0x1000013E) is { } ins)
        {
            _inscription = TextOver(ins, RetailTheme.Dim);
            // an item of yours that takes an inscription: written here, kept when you click away or press Ctrl+Enter
            _inscribe = new TextEdit { Visible = false, WrapMode = TextEdit.LineWrappingMode.Boundary, PlaceholderText = "<Inscribe here>", ContextMenuEnabled = true,
                                       TooltipText = "Write on it - kept when you click away (or press Ctrl+Enter). Esc puts it back as it was." };
            _inscribe.SetAnchorsPreset(LayoutPreset.FullRect);
            if (RetailTheme.TextFont != null) { _inscribe.AddThemeFontOverride("font", RetailTheme.TextFont); _inscribe.AddThemeFontSizeOverride("font_size", RetailTheme.Px(RetailTheme.TextSize)); }
            _inscribe.AddThemeColorOverride("font_color", RetailTheme.Ink);
            var clear = new StyleBoxFlat { BgColor = new Color(0, 0, 0, 0) };
            _inscribe.AddThemeStyleboxOverride("normal", clear);
            _inscribe.AddThemeStyleboxOverride("focus", new StyleBoxFlat { BgColor = new Color(0, 0, 0, 0.35f) });
            _inscribe.FocusExited += KeepInscription;
            _inscribe.GuiInput += e =>
            {
                if (e is not InputEventKey { Pressed: true } k) return;
                if (k.Keycode == Key.Enter && k.CtrlPressed) { _inscribe.ReleaseFocus(); _inscribe.AcceptEvent(); }
                else if (k.Keycode == Key.Escape) { _inscribe.Text = _inscribeWas; _inscribe.ReleaseFocus(); _inscribe.AcceptEvent(); }
            };
            ins.AddChild(_inscribe);
        }
        if (r.Find(0x10000163) is { } ct) _creatureText = TextOver(ct);
        _cName = r.Find(0x1000015E); _cLine1 = r.Find(0x10000160); _cLine2 = r.Find(0x10000161); _cLine3 = r.Find(0x10000162); _cFoot = r.Find(0x10000165);
        if (r.Find(0x1000015F) is { } ic) { _cIcon = new TextureRect { ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize, StretchMode = TextureRect.StretchModeEnum.KeepAspectCentered, MouseFilter = MouseFilterEnum.Ignore }; _cIcon.SetAnchorsPreset(LayoutPreset.FullRect); ic.AddChild(_cIcon); }
        if (_cName != null) _cName.CenterText();
        SetupPlayerView();
        Visible = false;
        LoadPlace();
        if (Position == Vector2.Zero) Position = new Vector2(GetViewportRect().Size.X - Size.X - 20, 120);
        return true;
    }

    private void ShowView(UiNode? v)
    {
        foreach (var x in new[] { _itemView, _creatureView, _playerView }) if (x != null) x.Visible = x == v;
    }

    /// <summary>A spell identified (right-click it in the spellbook or on a bar).</summary>
    public void ShowSpell(Magic.Spell sp)
    {
        ShownItem = null; ShowingSelf = false;
        _live = null;
        if (_title != null) _title.Text = sp.Name;
        ShowView(_itemView);
        string school = sp.School switch
        {
            DatReaderWriter.Enums.MagicSchool.WarMagic => "War Magic", DatReaderWriter.Enums.MagicSchool.LifeMagic => "Life Magic",
            DatReaderWriter.Enums.MagicSchool.CreatureEnchantment => "Creature Enchantment", DatReaderWriter.Enums.MagicSchool.ItemEnchantment => "Item Enchantment", DatReaderWriter.Enums.MagicSchool.VoidMagic => "Void Magic",
            _ => sp.School.ToString(),
        };
        var t = $"School: {school}\nLevel: {sp.Level}\nMana: {sp.Mana}";
        if (sp.RangeConstant > 0) t += $"\nRange: {sp.RangeConstant + sp.RangeMod:0.0} yds";
        if (sp.Duration > 0) t += $"\nDuration: {(int)sp.Duration / 60}:{(int)sp.Duration % 60:00}";
        if (sp.Components.Count > 0) t += "\nComponents: " + string.Join(", ", sp.Components);
        t += "\n\n" + sp.Description;
        if (_itemText != null) { _itemText.Text = t; _itemText.ScrollToLine(0); }
        if (_inscription != null) _inscription.Text = ""; if (_inscribe != null) { KeepInscription(); _inscribe.Visible = false; _inscribing = null; }
        Visible = true;
        MoveToFront();
    }

    /// <summary>An item identified.</summary>
    /// <summary>The item it's showing (null: something else).</summary>
    public Combat.Item? ShownItem;
    /// <summary>Whether an item is no more (on a server: destroyed, used up).</summary>
    public Func<Combat.Item, bool>? ItemGone;
    /// <summary>Shut because what it showed died or went away.</summary>
    public void Close() { Visible = false; ShownThing = null; ShownItem = null; _live = null; }
    /// <summary>A creature has died: if it's the one shown, the panel shuts.</summary>
    public void Died(Objects.ObjectStreamer.Selectable sel) { if (Visible && ShownThing == sel) Close(); }

    /// <summary>Told when an item is put up to be looked at (on a server: to ask it for the item's details).</summary>
    public Action<Combat.Item>? ItemShown;
    /// <summary>The thing in the world it's showing (null: an item, a spell, yourself).</summary>
    public Objects.ObjectStreamer.Selectable? ShownThing;

    /// <summary>A thing in the world as the server tells of it: a creature or person (level, attributes, health), or what a thing is.</summary>
    public void ShowAppraised(Objects.ObjectStreamer.Selectable sel, bool creature, int level, List<(string name, string value)> rows, string text, string line1 = "", string line2 = "", string? line3 = null)
    {
        ShownItem = null; ShownThing = sel; _live = null; ShowingSelf = false;
        if (_title != null) _title.Text = sel.Name;
        if (!creature)
        {
            ShowView(_itemView);
            if (_itemText != null) { _itemText.Text = text; _itemText.ScrollToLine(0); }
            if (_inscription != null) _inscription.Text = ""; if (_inscribe != null) { KeepInscription(); _inscribe.Visible = false; _inscribing = null; }
            Visible = true; MoveToFront();
            return;
        }
        ShowView(_playerView);
        if (_pLine1 != null) _pLine1.Text = line1;
        if (_pLine2 != null) _pLine2.Text = line2;
        if (_pLine3 != null) _pLine3.Text = line3 ?? (sel.Kind == 1 ? "Non-Player Killer" : "");
        if (_pLevel != null) _pLevel.Text = level > 0 ? level.ToString("N0") : "";
        var shown = new List<(string, string, bool)>();
        foreach (var (n, v) in rows) shown.Add((n, v, false));
        Rows(shown);
        _figHeight = Math.Max(0.5f, sel.Top - sel.Feet.Y);
        ShowFigure(sel.Node, sel.Remote ? () => sel.Yaw : null);
        Visible = true; MoveToFront();
    }

    // what's written on it, and who wrote it (an inscription's two strings: 7 the text, 8 the scribe)
    private void ShowInscription(Combat.Item? item)
    {
        string text = "", scribe = "";
        item?.PropStrings?.TryGetValue(7, out text!);
        item?.PropStrings?.TryGetValue(8, out scribe!);
        text ??= ""; scribe ??= "";
        // (takes one: the server says so - Inscribable; and someone else's writing is theirs to change)
        bool can = item != null && item.Guid != 0 && Inscribe != null && item.PropBools != null && item.PropBools.TryGetValue(22, out bool ib) && ib
                   && (scribe.Length == 0 || Killer == null || scribe.Equals(Killer, StringComparison.OrdinalIgnoreCase));
        if (_inscribe != null)
        {
            if (_inscribing != item || !_inscribe.HasFocus()) { _inscribe.Text = text; _inscribeWas = text; }
            _inscribing = item;
            _inscribe.Visible = can;
        }
        if (_inscription != null)
            _inscription.Text = can ? "" : (text.Length > 0 ? text + (scribe.Length > 0 ? $"\n[i]- {scribe}[/i]" : "") : "");
    }

    private void KeepInscription()
    {
        if (_inscribe == null || _inscribing == null) return;
        string now = _inscribe.Text.TrimEnd();
        if (now == _inscribeWas.TrimEnd()) return;
        _inscribeWas = now;
        Inscribe?.Invoke(_inscribing, now);
    }

    public void ShowItem(Combat.Item item, bool ask = true)
    {
        ShownThing = null; ShowingSelf = false;
        if (ask) ItemShown?.Invoke(item);
        ShownItem = item;
        _live = null;
        if (_title != null) _title.Text = item.Stack > 1 ? $"{item.Stack:N0} {item.Shown}" : item.Shown;
        ShowView(_itemView);
        if (_itemText != null) { _itemText.Text = item.Appraisal(); _itemText.ScrollToLine(0); }
        ShowInscription(item);
        Visible = true;
        MoveToFront();
    }

    // ── the character view (0x10000140): a creature, NPC or you, as the game shows them ──
    private UiNode? _pLine1, _pLine2, _pLine3, _pLevel, _pLevelHead1, _pLevelHead2, _pList, _pFigure, _pFoot;
    private VBoxContainer? _pRows;
    private SubViewport? _figView;
    private Camera3D? _figCam;
    private Node3D? _figTarget;
    private const uint FigureLayer = 1u << 18;

    private void SetupPlayerView()
    {
        var r = Root!;
        _pLine1 = r.Find(0x10000150); _pLine2 = r.Find(0x10000151); _pLine3 = r.Find(0x10000152);
        foreach (var n in new[] { _pLine1, _pLine2, _pLine3 }) n?.CenterText();
        _pLevelHead1 = r.Find(0x1000014A); _pLevelHead2 = r.Find(0x1000014B); _pLevel = r.Find(0x1000014C);
        foreach (var n in new[] { _pLevelHead1, _pLevelHead2, _pLevel }) n?.CenterText();
        if (_pLevelHead1 != null && string.IsNullOrEmpty(_pLevelHead1.Text)) _pLevelHead1.Text = "Character";
        if (_pLevelHead2 != null && string.IsNullOrEmpty(_pLevelHead2.Text)) _pLevelHead2.Text = "Level";
        _pList = r.Find(0x10000149);
        _pFigure = r.Find(0x10000148);
        _pFoot = r.Find(0x1000053A);
        // the live figure behind the list: a camera in front of them, drawing only them
        if (_pFigure != null)
        {
            var container = new SubViewportContainer { Stretch = true, MouseFilter = MouseFilterEnum.Ignore, ZIndex = 1 };   // over the layout's backdrop
            container.SetAnchorsPreset(LayoutPreset.FullRect);
            _figView = new SubViewport { TransparentBg = true, RenderTargetUpdateMode = SubViewport.UpdateMode.WhenVisible, Size = new Vector2I(300, 265) };
            _figCam = new Camera3D { Fov = 32f, CullMask = FigureLayer, Current = true,
                                     Environment = new Godot.Environment { BackgroundMode = Godot.Environment.BGMode.ClearColor, AmbientLightSource = Godot.Environment.AmbientSource.Color,
                                                                           AmbientLightColor = new Color(0.85f, 0.85f, 0.8f), AmbientLightEnergy = 1f } };
            _figView.AddChild(_figCam);
            container.AddChild(_figView);
            _pFigure.AddChild(container);
        }
        if (_pList != null)
        {
            foreach (var c in _pList.GetChildren()) if (c is UiNode n) n.Visible = false;
            var scroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled, MouseFilter = MouseFilterEnum.Pass, Theme = RetailTheme.Current, ZIndex = 2 };
            scroll.SetAnchorsPreset(LayoutPreset.FullRect);
            scroll.OffsetLeft = 4; scroll.OffsetRight = -6; scroll.OffsetTop = 6;
            _pRows = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
            _pRows.AddThemeConstantOverride("separation", 0);
            scroll.AddChild(_pRows);
            _pList.AddChild(scroll);
        }
    }

    private static readonly Color Green = new(0.5f, 1f, 0.5f);

    private void Rows(IEnumerable<(string name, string value, bool green)> rows)
    {
        if (_pRows == null) return;
        foreach (var c in _pRows.GetChildren()) { _pRows.RemoveChild(c); c.QueueFree(); }
        foreach (var (name, value, green) in rows)
        {
            var row = new HBoxContainer();
            var a = new Label { Text = name, SizeFlagsHorizontal = SizeFlags.ExpandFill };
            a.AddThemeColorOverride("font_color", Colors.White);
            var b = new Label { Text = value, HorizontalAlignment = HorizontalAlignment.Right };
            b.AddThemeColorOverride("font_color", green ? Green : Colors.White);
            row.AddChild(a); row.AddChild(b);
            _pRows.AddChild(row);
        }
    }

    // (which way it faces, where its node doesn't say: your own body turns inside its node; a thing hung on a wall is tipped over)
    private Func<float>? _figYaw;
    private void ShowFigure(Node3D? who, Func<float>? yaw = null)
    {
        _figYaw = yaw;
        if (_figTarget != null && IsInstanceValid(_figTarget)) Tag(_figTarget, false);
        _figTarget = who;
        if (who != null) { Tag(who, true); if (_figView != null) _figView.World3D = who.GetViewport().World3D; }
    }

    private static void Tag(Node n, bool on)
    {
        foreach (var c in n.GetChildren())
        {
            if (c is VisualInstance3D v) v.Layers = on ? v.Layers | FigureLayer : v.Layers & ~FigureLayer;
            Tag(c, on);
        }
    }

    private Action? _live;
    private double _liveIn;

    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("ExaminePanel");
        // what's shown about a creature (or you) is kept up to date while the panel is open
        // what it shows has gone (a creature dead and its body taken away, an item used up or picked up by someone): shut,
        // and it stays shut until something is identified again
        if (Visible && (ShownThing is { Gone: true } || ShownItem != null && ItemGone?.Invoke(ShownItem) == true)) { Close(); return; }
        if (Visible && _live != null && (_liveIn -= delta) <= 0) { _liveIn = 0.4; _live(); }
        // (the world not drawn - the screen black, Options > Display: the figure isn't drawn either)
        bool no3d = GetViewport().Disable3D;
        if (_figView != null)
        {
            var mode = no3d ? SubViewport.UpdateMode.Disabled : SubViewport.UpdateMode.WhenVisible;
            if (_figView.RenderTargetUpdateMode != mode) _figView.RenderTargetUpdateMode = mode;
            if (_figView.GetParent() is Control fc && fc.Visible == no3d) fc.Visible = !no3d;
        }
        if (!Visible || no3d || _figCam == null || _figTarget == null || !IsInstanceValid(_figTarget) || !_figTarget.IsInsideTree() || _playerView == null || !_playerView.Visible)
        {
            Effects.ParticleWorld.FigureAt = null;
            return;
        }
        Tag(_figTarget, true);
        Effects.ParticleWorld.FigureAt = _figTarget.GlobalPosition;   // (its effects in the picture too)
        // in front of them, a little to the side, looking at their middle
        var b = _figTarget.GlobalTransform.Basis;
        var fwd = -b.Z.Normalized(); fwd.Y = 0;
        if (_figYaw != null) { float fy = _figYaw(); fwd = new Vector3(-MathF.Sin(fy), 0, -MathF.Cos(fy)); }
        if (fwd.LengthSquared() < 0.01f) fwd = Vector3.Forward;
        float h = Math.Max(_figHeight, 0.5f);
        var at = _figTarget.GlobalPosition + new Vector3(0, h * 0.5f, 0);
        _figCam.GlobalPosition = at + fwd.Normalized() * (h * 2.6f + 0.8f) + new Vector3(0, h * 0.1f, 0);
        _figCam.LookAt(at, Vector3.Up);
    }

    private float _figHeight = 1.8f;

    /// <summary>A creature, NPC or thing in the world identified.</summary>
    public void ShowThing(Objects.ObjectStreamer.Selectable sel, Combat.Fighter? f, Combat.Item? item)
    {
        ShownItem = null; ShownThing = sel; ShowingSelf = false;
        _live = null;
        if (item != null) { ShowItem(item); return; }
        if (_title != null) _title.Text = sel.Name;
        if (f != null && f.St == Combat.Fighter.State.Dead)
        {
            // a corpse: what it weighs, who killed it, how long till it decays
            ShowView(_itemView);
            void Corpse()
            {
                int burden = 0;
                if (f.Loot != null) foreach (var it in f.Loot) burden += it.Burden * Math.Max(1, it.Stack);
                double left = Math.Max(0, f.CorpseUntil - (Now?.Invoke() ?? 0));
                if (_itemText != null) _itemText.Text = $"Burden: {burden:N0}\n\nKilled by {Killer}.\n\nThis corpse will decay in {(int)left / 60} minutes, {(int)left % 60} seconds.";
            }
            Corpse();
            _live = Corpse;
            if (_inscription != null) _inscription.Text = ""; if (_inscribe != null) { KeepInscription(); _inscribe.Visible = false; _inscribing = null; }
            Visible = true; MoveToFront();
            return;
        }
        if (f == null && sel.Kind == 0)
        {
            // a door, a chest, a lifestone...: its name, and what it is
            ShowView(_itemView);
            if (_itemText != null) _itemText.Text = sel.Type == 19 ? (sel.Open ? "It's open." : "It's shut.") : "";
            if (_inscription != null) _inscription.Text = ""; if (_inscribe != null) { KeepInscription(); _inscribe.Visible = false; _inscribing = null; }
            Visible = true; MoveToFront();
            return;
        }
        ShowView(_playerView);
        if (_pLine1 != null) _pLine1.Text = sel.Kind == 2 ? "" : "";
        if (_pLine2 != null) _pLine2.Text = f != null && !f.Hostile ? "" : "";
        if (_pLine3 != null) _pLine3.Text = sel.Kind == 1 ? "Non-Player Killer" : "";
        if (_pLevel != null) _pLevel.Text = f != null && f.W.Level > 0 ? f.W.Level.ToString("N0") : "";
        var rows = new List<(string, string, bool)>();
        string[] attr = { "Strength", "Endurance", "Coordination", "Quickness", "Focus", "Self" };
        int[] order = { 0, 1, 3, 2, 4, 5 };   // the game lists coordination before quickness
        void Fill()
        {
            rows.Clear();
            if (f == null) { Rows(rows); return; }
            for (int k = 0; k < 6; k++) { int i = order[k]; if (i < f.W.Attributes.Length && f.W.Attributes[i] > 0) rows.Add((attr[k], f.W.Attributes[i].ToString("N0"), false)); }
            int hp = Math.Max(0, f.Health);
            rows.Add(("Health", $"{hp:N0}/{f.MaxHealth:N0} ({(f.MaxHealth > 0 ? (long)hp * 100 / f.MaxHealth : 0)} %)", false));
            Rows(rows);
        }
        Fill();
        if (f != null) _live = () => { if (f.St == Combat.Fighter.State.Dead) ShowThing(sel, f, null); else Fill(); };
        _figHeight = Math.Max(0.5f, sel.Top - sel.Feet.Y);
        ShowFigure(sel.Node, sel.Remote ? () => sel.Yaw : null);
        Visible = true;
        MoveToFront();
    }

    /// <summary>Yourself identified (right-click your character, or the magnifying glass with nothing selected).</summary>
    public void ShowSelf(Combat.Character me, Creatures.Player player, int health, int stamina, int mana)
    {
        ShownItem = null; ShownThing = null; ShowingSelf = true; _selfMore.Clear();
        if (_title != null) _title.Text = me.Name;
        ShowView(_playerView);
        if (_pLine1 != null) _pLine1.Text = me.Heritage;
        if (_pLine2 != null) _pLine2.Text = "Adventurer";
        if (_pLine3 != null) _pLine3.Text = "Non-Player Killer";
        if (_pLevel != null) _pLevel.Text = me.Level.ToString("N0");
        SelfRows(me, health, stamina, mana);
        _live = () => { if (SelfVitals?.Invoke() is { } v) SelfRows(me, v.health, v.stamina, v.mana); };
        _figHeight = 1.8f;
        ShowFigure(player, () => player.Heading);
        Visible = true;
        MoveToFront();
    }

    /// <summary>Whether it's yourself that's shown.</summary>
    public bool ShowingSelf { get; private set; }
    private readonly List<(string, string)> _selfMore = new();
    /// <summary>The rest of yourself, as the server tells it (your allegiance, armor, ratings...): shown under the vitals.</summary>
    public void SelfMore(string line1, string line2, string line3, List<(string, string)> rows)
    {
        if (!ShowingSelf) return;
        if (_pLine1 != null && line1.Length > 0) _pLine1.Text = line1;
        if (_pLine2 != null && line2.Length > 0) _pLine2.Text = line2;
        if (_pLine3 != null) _pLine3.Text = line3;
        _selfMore.Clear(); _selfMore.AddRange(rows);
        _live?.Invoke();
    }

    private void SelfRows(Combat.Character me, int health, int stamina, int mana)
    {
        var rows = new List<(string, string, bool)>();
        string[] attr = { "Strength", "Endurance", "Coordination", "Quickness", "Focus", "Self" };
        int[] order = { 0, 1, 3, 2, 4, 5 };
        for (int k = 0; k < 6; k++) rows.Add((attr[k], me.Attribute(order[k]).ToString("N0"), true));
        int mh = me.MaxVital(0), ms = me.MaxVital(1), mm = me.MaxVital(2);
        rows.Add(("Health", $"{health:N0}/{mh:N0} ({(mh > 0 ? (long)health * 100 / mh : 0)} %)", true));
        rows.Add(("Stamina", $"{stamina:N0}/{ms:N0}", true));
        rows.Add(("Mana", $"{mana:N0}/{mm:N0}", true));
        foreach (var (n, v) in _selfMore) rows.Add((n, v, false));
        Rows(rows);
    }
}
