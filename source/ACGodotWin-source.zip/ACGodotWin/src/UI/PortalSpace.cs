using System;
using Godot;

namespace ACGodot.UI;

/// <summary>
/// Portal space: going through a portal, the screen fills with the swirling purple tunnel, you're moved while it's
/// up, and it clears where you come out. <see cref="Go"/> runs the whole trip.
/// </summary>
public partial class PortalSpace : CanvasLayer
{
    private ColorRect? _rect;
    private ShaderMaterial? _mat;
    private double _t = -1, _total;
    private Action? _midway;
    private bool _moved;

    /// <summary>Through the tunnel: <paramref name="midway"/> runs (the move) once the screen is covered.</summary>
    public bool Busy => _t >= 0;

    private const double FadeIn = 0.45, FadeOut = 0.7;

    public override void _Ready()
    {
        Layer = 80;   // over the game and its windows, under plugins' ImGui windows
        _mat = new ShaderMaterial { Shader = new Shader { Code = Code } };
        _rect = new ColorRect { Material = _mat, MouseFilter = Control.MouseFilterEnum.Ignore, Visible = false };
        _rect.SetAnchorsPreset(Control.LayoutPreset.FullRect);
        AddChild(_rect);
    }

    public void Go(Action midway, double seconds = 3.2)
    {
        if (_rect == null || Busy) { midway(); return; }
        _midway = midway; _moved = false; _total = Math.Max(seconds, FadeIn + FadeOut + 0.3); _t = 0;
        _rect.Visible = true;
    }

    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("PortalSpace");
        if (_t < 0 || _rect == null || _mat == null) return;
        _t += Math.Min(delta, 0.1);
        float fade = _t < FadeIn ? (float)(_t / FadeIn) : _t > _total - FadeOut ? (float)Math.Max(0, (_total - _t) / FadeOut) : 1f;
        _mat.SetShaderParameter("t", (float)_t);
        _mat.SetShaderParameter("fade", fade);
        var size = _rect.Size;
        _mat.SetShaderParameter("aspect", size.Y > 0 ? size.X / size.Y : 1.6f);
        if (!_moved && _t >= FadeIn + 0.05) { _moved = true; try { _midway?.Invoke(); } catch (Exception ex) { GD.PushWarning("portal: " + ex.Message); } }
        // (the world not drawn - the screen black, Options > Display: no tunnel over it either; the trip goes on)
        _rect.Visible = !GetViewport().Disable3D;
        if (_t >= _total) { _t = -1; _rect.Visible = false; }
    }

    // the tunnel: streaks rushing past round a bright middle, turning as they go
    private const string Code = @"
shader_type canvas_item;
uniform float t = 0.0;
uniform float fade = 0.0;
uniform float aspect = 1.6;

float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float noise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x), mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x), u.y);
}

void fragment() {
    vec2 p = (UV - 0.5) * vec2(aspect, 1.0);
    float r = max(length(p), 0.001);
    float a = atan(p.y, p.x) / 6.2831853 + 0.5;
    float depth = 0.35 / r + t * 1.6;            // further down the tunnel towards the middle, rushing at you
    float twist = 0.25 / r + t * 0.12;           // the walls twist
    // (all the way round without a seam: the pattern at the angle and one turn back, blended)
    float n0 = noise(vec2((a + twist) * 18.0, depth * 2.0)) * 0.6 + noise(vec2((a + twist) * 42.0, depth * 5.0)) * 0.4;
    float n1 = noise(vec2((a - 1.0 + twist) * 18.0, depth * 2.0)) * 0.6 + noise(vec2((a - 1.0 + twist) * 42.0, depth * 5.0)) * 0.4;
    float n = mix(n0, n1, a);
    float streaks = smoothstep(0.45, 0.95, n);
    vec3 deep = vec3(0.10, 0.02, 0.22), purple = vec3(0.55, 0.18, 0.95), light = vec3(0.85, 0.75, 1.0);
    vec3 col = mix(deep, purple, smoothstep(0.2, 0.8, n));
    col += light * streaks * 0.8;
    col += vec3(0.9, 0.8, 1.0) * smoothstep(0.25, 0.0, r) * 1.2;   // the bright far end
    col *= smoothstep(1.3, 0.2, r) * 0.8 + 0.2;                     // dark round the edges
    COLOR = vec4(col, fade);
}
";
}
