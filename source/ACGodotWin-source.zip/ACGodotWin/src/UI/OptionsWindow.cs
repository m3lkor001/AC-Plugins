using System;
using System.Collections.Generic;
using System.Linq;
using Godot;

namespace ACGodot.UI;

/// <summary>
/// The options panel (Ctrl+O or /options), with the game's tabs: Gameplay (combat helpers), Character (how the
/// health/stamina/mana bars sit, the debug text), Chat (what each chat window shows, as the game's Chat tab) and
/// Network (connecting to a server - off until it's switched on).
/// </summary>
public partial class OptionsWindow : Combat.GameWindow
{
    /// <summary>What the options act on (set by Main).</summary>
    public Func<IReadOnlyList<ChatWindow>>? Chats;
    public RetailHud? Hud;
    public Combat.CombatSystem? Combat;
    public Func<bool>? DebugShown;
    /// <summary>The plugins running (for their test switches in Plugins > Debug).</summary>
    public Func<Plugins.PluginHost?>? Host;
    public Action<bool>? SetDebugShown;
    public Func<bool>? RestWorld, RestSound, SoundOn, HighRes, JumpArc;
    public Action<bool>? SetRestWorld, SetRestSound, SetSoundOn, SetHighRes, SetJumpArc;

    private static readonly (ChatKind kind, string name, string tip)[] Kinds =
    {
        (ChatKind.Gameplay, "Gameplay", "Messages about the game: commands' answers, levels, what you pick up."),
        (ChatKind.Combat, "Combat", "Hits, misses, evades and deaths."),
        (ChatKind.Magic, "Magic", "Spells cast, on you and by you."),
        (ChatKind.AreaChat, "Area Chat", "What's said near you."),
        (ChatKind.Tells, "Tells", "Tells to and from you."),
        (ChatKind.Allegiance, "Allegiance", "The allegiance channel, and monarch, patron and vassal messages."),
        (ChatKind.Fellowship, "Fellowship", "Your fellowship's channel."),
        (ChatKind.General, "General Channel", "The General chat channel."),
        (ChatKind.Trade, "Trade Channel", "The Trade chat channel."),
        (ChatKind.LFG, "LFG Channel", "The Looking-for-group channel."),
        (ChatKind.Roleplay, "Roleplay Channel", "The Roleplay channel."),
        (ChatKind.Society, "Society Channel", "Your society's channel."),
        (ChatKind.Errors, "Errors", "Error messages."),
        (ChatKind.Plugin, "Plugins", "Text from plugins (ACGodot's built-in ones and any loaded)."),
    };

    private static readonly string[] WindowTitles = { "Main Chat Window", "Chat Window 1", "Chat Window 2", "Chat Window 3", "Chat Window 4", "Chat Window 5" };

    public OptionsWindow() : base("Options", new Vector2(330, 520)) { }

    public void Open()
    {
        Visible = true;
        Refresh();
    }

    /// <summary>Its pages are shown elsewhere (the options side panel): told when something changed them, to build them again.</summary>
    public Action? Rebuild;

    /// <summary>
    /// One of its pages' contents on their own (0 gameplay, 1 character, 2 chat, 4 plugins), for the options
    /// side panel's tabs - built here (this window holds what they change) and shown there.
    /// </summary>
    public Control PageContent(int which)
    {
        Control page = which switch { 0 => Gameplay(), 1 => Character(), 2 => ChatTab(), _ => PluginsTab() };
        if (page.GetChildCount() > 0 && page.GetChild(0) is Control inner)
        {
            page.RemoveChild(inner);
            page.QueueFree();
            return inner;
        }
        return page;
    }

    public void Refresh()
    {
        if (!Visible) { Rebuild?.Invoke(); return; }
        Clear();
        var tabs = new TabContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill, CustomMinimumSize = new Vector2(300, 460) };
        tabs.AddChild(Gameplay());
        tabs.AddChild(Character());
        tabs.AddChild(ChatTab());
        tabs.AddChild(PluginsTab());
        Body.AddChild(tabs);
        // leaving the game: here (Esc opens this window), so it isn't one stray key press away
        if (Quit != null)
        {
            var row = new HBoxContainer { SizeFlagsHorizontal = SizeFlags.ShrinkCenter };
            row.AddThemeConstantOverride("separation", 12);
            // on a server, in the world: back to the character screen
            if (LogOut != null && CanLogOut?.Invoke() == true)
            {
                var logout = new Button { Text = "Log out", FocusMode = FocusModeEnum.None,
                                          TooltipText = "Leaves the world for the character screen, to come back in as another character." };
                logout.Pressed += () => LogOut?.Invoke();
                row.AddChild(logout);
            }
            var exit = new Button { Text = "Exit the game", FocusMode = FocusModeEnum.None,
                                    TooltipText = "Leaves the game (logging off the server first, when playing on one)." };
            exit.Pressed += () => Quit?.Invoke();
            row.AddChild(exit);
            Body.AddChild(row);
        }
    }

    /// <summary>Options > Display: the window fills the screen each time the game starts.</summary>
    public static bool StartMaximized
    {
        get { var c = new ConfigFile(); return global::ACGodot.SafeConfig.Load(c, UiCfg) == Error.Ok && (bool)c.GetValue("display", "maximized", false); }
        set { var c = new ConfigFile(); global::ACGodot.SafeConfig.Load(c, UiCfg); c.SetValue("display", "maximized", value); global::ACGodot.SafeConfig.Save(c, UiCfg); }
    }

    /// <summary>Back to the character screen (the Log out button, shown while in a server's world).</summary>
    public Action? LogOut;
    public Func<bool>? CanLogOut;

    /// <summary>Leaves the game (the Exit button).</summary>
    public Action? Quit;

    /// <summary>Opens the keyboard's settings (which keys do what).</summary>
    public Action? ConfigureKeyboard;
    /// <summary>Keeps the camera's view as it is now as this character's default.</summary>
    public Action? KeepCamera;
    /// <summary>One of the character's options as the server has it (by its name; null: not on a server, or not told yet), and a way to change it.</summary>
    public Func<string, bool?>? ServerOption;
    public Action<string, bool>? SetServerOption;

    private static CheckBox Check(string text, bool on, Action<bool> set, string tip = "")
    {
        // (long labels wrap onto a second line instead of running off the window's edge)
        var c = new CheckBox { Text = text, ButtonPressed = on, FocusMode = FocusModeEnum.None, TooltipText = tip,
                               AutowrapMode = TextServer.AutowrapMode.WordSmart, SizeFlagsHorizontal = SizeFlags.ExpandFill };
        c.Toggled += v => set(v);
        return c;
    }

    /// <summary>A setting with a slider, laid out to fit however narrow the window is: its name with the value at the
    /// right on one line (the name cut short with … if need be - hover it for the whole name and its help), the slider
    /// the full width under it.</summary>
    private static void SliderRow(VBoxContainer into, string label, string tip, int min, int max, int step, int now,
                                  Func<int, string> shown, Action<int> set, bool saveWhileDragging)
    {
        string full = string.IsNullOrEmpty(tip) ? label : label + "\n" + tip;
        var line = new HBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        var name = new Label { Text = label, TooltipText = full, MouseFilter = MouseFilterEnum.Stop, SizeFlagsHorizontal = SizeFlags.ExpandFill,
                               ClipText = true, TextOverrunBehavior = TextServer.OverrunBehavior.TrimEllipsis, CustomMinimumSize = new Vector2(40, 0) };
        var val = new Label { Text = shown(now), HorizontalAlignment = HorizontalAlignment.Right };
        val.AddThemeColorOverride("font_color", RetailTheme.Gold);
        line.AddChild(name); line.AddChild(val);
        var s = new HSlider { MinValue = min, MaxValue = max, Step = step, Value = now, SizeFlagsHorizontal = SizeFlags.ExpandFill,
                              CustomMinimumSize = new Vector2(60, 0), FocusMode = FocusModeEnum.None, TooltipText = full };
        s.ValueChanged += v => { val.Text = shown((int)v); set((int)v); if (saveWhileDragging) Video.Changed(); };
        if (!saveWhileDragging) s.DragEnded += _ => Video.Changed();
        into.AddChild(line);
        into.AddChild(s);
    }

    /// <summary>A setting with a list to choose from: its name on one line, the list the full width under it (so a narrow
    /// window cuts nothing off).</summary>
    private static void PickRow(VBoxContainer into, string label, string tip, (string name, int value)[] choices, int now, Action<int> set)
    {
        string full = string.IsNullOrEmpty(tip) ? label : label + "\n" + tip;
        into.AddChild(new Label { Text = label, TooltipText = full, MouseFilter = MouseFilterEnum.Stop, SizeFlagsHorizontal = SizeFlags.ExpandFill,
                                  ClipText = true, TextOverrunBehavior = TextServer.OverrunBehavior.TrimEllipsis, CustomMinimumSize = new Vector2(40, 0) });
        var pick = new OptionButton { FocusMode = FocusModeEnum.None, SizeFlagsHorizontal = SizeFlags.ExpandFill, CustomMinimumSize = new Vector2(60, 0),
                                      ClipText = true, TooltipText = full, TextOverrunBehavior = TextServer.OverrunBehavior.TrimEllipsis };
        for (int i = 0; i < choices.Length; i++) { pick.AddItem(choices[i].name); if (choices[i].value == now) pick.Selected = i; }
        pick.ItemSelected += i => { set(choices[(int)i].value); Video.Changed(); };
        into.AddChild(pick);
    }

    private Control Page(string name)
    {
        var scroll = new ScrollContainer { Name = name, HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled };
        var box = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        scroll.AddChild(box);
        return scroll;
    }

    private static VBoxContainer BoxOf(Control page) => (VBoxContainer)page.GetChild(0);

    // ── a section that opens and shuts (its title as a gold header with ▼ / ▶; remembered in user://ui.cfg) ──
    private const string UiCfg = "user://ui.cfg";

    private static bool SectionOpen(string key)
    {
        var cfg = new ConfigFile();
        return global::ACGodot.SafeConfig.Load(cfg, UiCfg) != Error.Ok || (bool)cfg.GetValue("options_open", key, true);
    }

    private static void SetSectionOpen(string key, bool open)
    {
        var cfg = new ConfigFile();
        global::ACGodot.SafeConfig.Load(cfg, UiCfg);
        cfg.SetValue("options_open", key, open);
        global::ACGodot.SafeConfig.Save(cfg, UiCfg);
    }

    /// <summary>A section in a page: its header (click to open / shut) and the box its contents go in.</summary>
    private static VBoxContainer Section(VBoxContainer page, string title, string? key = null)
    {
        key ??= title.Replace(' ', '_');
        bool open = SectionOpen(key);
        var head = new Button { Text = (open ? "▼ " : "▶ ") + title, Flat = true, FocusMode = FocusModeEnum.None, Alignment = HorizontalAlignment.Left };
        head.AddThemeColorOverride("font_color", RetailTheme.Gold);
        head.AddThemeFontSizeOverride("font_size", RetailTheme.Px(15));
        var body = new VBoxContainer { Visible = open };
        head.Pressed += () => { body.Visible = !body.Visible; head.Text = (body.Visible ? "▼ " : "▶ ") + title; SetSectionOpen(key, body.Visible); };
        page.AddChild(head);
        page.AddChild(body);
        return body;
    }

    private Control Gameplay()
    {
        var page = Page("Gameplay");
        var b = BoxOf(page);
        if (ConfigureKeyboard != null) b.AddChild(Small("Configure Keyboard", () => ConfigureKeyboard()));
        var combat = Section(b, "Combat");
        if (Combat != null)
        {
            combat.AddChild(Check("Repeat Attacks", Combat.RepeatAttacks, v => Combat.RepeatAttacks = v, "Keep attacking the target until it dies."));
            combat.AddChild(Check("Auto Target", Combat.AutoTarget, v => Combat.AutoTarget = v, "Selects the nearest enemy when you go into combat and when your target dies (it doesn't attack it)."));
            combat.AddChild(Check("Keep in View", Combat.KeepInView, v => Combat.KeepInView = v, "Swing the camera round to keep your target in front."));
        }
        var iface = Section(b, "Interface");
        iface.AddChild(Check("M collapses / expands the map", Map.MapWindow.MKeyCollapses, v => Map.MapWindow.MKeyCollapses = v,
                             "On: once the map is on the screen, M shrinks it to its title bar and opens it again (M still opens it when it's closed).\nOff: M opens and closes it (a collapsed map opens up first)."));
        iface.AddChild(Check("Lock the interface", UiLock.Locked, v => UiLock.Set(v), "Unlocked, windows can be dragged and resized (the radar's lock does the same)."));
        iface.AddChild(Check("Close the ID panel on a new selection", ExaminePanel.CloseOnSelect, v => ExaminePanel.CloseOnSelect = v,
                         "Off: choosing something else while the ID panel is open identifies it. On: the panel shuts instead."));
        if (KeepCamera != null)
        {
            var keep = Small("Set the current camera view as the default", () => KeepCamera());
            keep.TooltipText = "Keeps the camera's distance and angle as they are now, for this character: the view it starts in, and the one the default-view key goes back to.";
            iface.AddChild(keep);
        }
        // the lines at the top of the screen (what you're doing, why you can't): all of them, or kind by kind
        var status = Section(b, "Status messages", "status");
        var kinds = new List<CheckBox>();
        status.AddChild(Check("Show status messages at the top of the screen", StatusLine.Shows("all"),
            v => { StatusLine.SetShows("all", v); foreach (var k in kinds) k.Disabled = !v; }, "Off: none of them show."));
        foreach (var (key, name) in StatusLine.Kinds)
        {
            var c = Check(name, StatusLine.Shows(key), v => StatusLine.SetShows(key, v));
            c.Disabled = !StatusLine.Shows("all");
            kinds.Add(c); status.AddChild(c);
        }
        b.AddChild(NameTagSection());
        return page;
    }

    // Name tags: a section of its own that opens and shuts
    private Control NameTagSection()
    {
        var box = new VBoxContainer();
        var body = Section(box, "Name tags");
        body.AddChild(Check("Show name tags", NameTags.Enabled, v => { NameTags.Enabled = v; NameTags.Save(); },
                            "Names over players (level, <allegiance>), pets, portals (<where they go>), NPCs, vendors and monsters (level)."));
        body.AddChild(Check("The radar uses these colours too", NameTags.RadarColors, v => { NameTags.RadarColors = v; NameTags.Save(); },
                            "The radar's dots in the name tag colours below (as the world map's are). Player killers stay red and lifestones blue.\nOff: the game's radar colours."));
        var rangeRow = new HBoxContainer();
        var rangeLbl = new Label { Text = $"Max range {NameTags.MaxRange:0} m", CustomMinimumSize = new Vector2(110, 0) };
        var range = new HSlider { MinValue = 5, MaxValue = 150, Step = 1, Value = NameTags.MaxRange, SizeFlagsHorizontal = SizeFlags.ExpandFill, FocusMode = FocusModeEnum.None };
        range.ValueChanged += v => { NameTags.MaxRange = (float)v; rangeLbl.Text = $"Max range {v:0} m"; };
        range.DragEnded += _ => NameTags.Save();
        rangeRow.AddChild(rangeLbl); rangeRow.AddChild(range);
        body.AddChild(rangeRow);
        var grid = new GridContainer { Columns = 6 };
        foreach (var h in new[] { "Show", "Kind", "Name", "Size", "Line 2", "Size" }) grid.AddChild(Text(h, 11, RetailTheme.Dim));
        for (int i = 0; i < NameTags.Kinds.Length; i++)
        {
            var st = NameTags.StyleFor(NameTags.Kinds[i]);
            grid.AddChild(Check("", st.On, v => { st.On = v; NameTags.Save(); }));
            grid.AddChild(new Label { Text = NameTags.Labels[i], SizeFlagsHorizontal = SizeFlags.ExpandFill });
            ColorPickerButton Pick(Color c, Action<Color> set)
            {
                var p = new ColorPickerButton { Color = c, CustomMinimumSize = new Vector2(26, 18), FocusMode = FocusModeEnum.None };
                p.PopupClosed += () => { set(p.Color); NameTags.Save(); };
                return p;
            }
            SpinBox Size(float v, Action<float> set)
            {
                var sb = new SpinBox { MinValue = 0.05, MaxValue = 1, Step = 0.01, Value = v, CustomMinimumSize = new Vector2(60, 0) };
                sb.ValueChanged += x => { set((float)x); NameTags.Save(); };
                return sb;
            }
            grid.AddChild(Pick(st.TagColor, c => st.TagColor = c));
            grid.AddChild(Size(st.TagSize, x => st.TagSize = x));
            grid.AddChild(Pick(st.TickerColor, c => st.TickerColor = c));
            grid.AddChild(Size(st.TickerSize, x => st.TickerSize = x));
        }
        body.AddChild(grid);
        body.AddChild(Text("Line 2: <allegiance> over players, <destination> over portals.", 11, RetailTheme.Dim));
        body.AddChild(Small("Default colors", () => { NameTags.Defaults(); Refresh(); }));
        return box;
    }

    private Control Character()
    {
        var page = Page("Character");
        var b = BoxOf(page);
        // the character's own options, kept by the server (the game's Character page): shown once the server has told them
        if (ServerOption != null && ServerOption("AutoRepeatAttacks") != null)
        {
            void Group(string title, string key, params (string name, string label)[] opts)
            {
                var sec = Section(b, title, key);
                foreach (var (name, label) in opts)
                {
                    string n = name;
                    sec.AddChild(Check(label, ServerOption(n) == true, v => SetServerOption?.Invoke(n, v)));
                }
            }
            Group("User Interface Behavior", "srv-behavior",
                ("KeepCombatTargetsInView", "Keep Combat Targets in View"), ("SalvageMultipleMaterialsAtOnce", "Salvage Multiple Materials at Once"),
                ("UseMainPackAsDefaultForPickingUpItems", "Use Main Pack as Default for Picking Up Items"));
            Group("User Interface Display", "srv-display",
                ("VividTargetingIndicator", "Vivid Targeting Indicator"), ("Display3dTooltips", "Display 3D Tooltips"), ("ShowCoordinatesByTheRadar", "Show Coordinates By the Radar"),
                ("SideBySideVitals", "Side By Side Vitals"), ("DisplaySpellDurations", "Display Spell Durations"), ("DisableMostWeatherEffects", "Disable Most Weather Effects"),
                ("DisableDistanceFog", "Disable Distance Fog"), ("AlwaysDaylightOutdoors", "Always Daylight Outdoors"), ("DisableHouseRestrictionEffects", "Disable House Restriction Effects"),
                ("UseCraftingChanceOfSuccessDialog", "Use Crafting Chance of Success Dialog"), ("ConfirmUseOfRareGems", "Confirm Use of Rare Gems"), ("DisplayTimestamps", "Display Timestamps"),
                ("FilterLanguage", "Filter Language"), ("ShowYourHelmOrHeadGear", "Show Your Helm or Head Gear"), ("ShowYourCloak", "Show Your Cloak"));
            Group("Grouping", "srv-grouping",
                ("IgnoreAllegianceRequests", "Ignore Allegiance Requests"), ("IgnoreFellowshipRequests", "Ignore Fellowship Requests"), ("ShowAllegianceLogons", "Show Allegiance Logons"),
                ("ShareFellowshipExpAndLuminance", "Share Fellowship Experience and Luminance"), ("ShareFellowshipLoot", "Share Fellowship Loot"),
                ("AutomaticallyAcceptFellowshipRequests", "Automatically Accept Fellowship Requests"));
            Group("Other Players", "srv-others",
                ("AcceptCorpseLootingPermissions", "Accept Corpse Looting Permissions"), ("AttemptToDeceiveOtherPlayers", "Attempt to Deceive Other Players"),
                ("LetOtherPlayersGiveYouItems", "Let Other Players Give You Items"), ("IgnoreAllTradeRequests", "Ignore All Trade Requests"), ("DragItemToPlayerOpensTrade", "Drag Item to Player Opens Trade"),
                ("AllowOthersToSeeYourDateOfBirth", "Allow Others to See Your Date of Birth"), ("AllowOthersToSeeYourAge", "Allow Others to See Your Age"),
                ("AllowOthersToSeeYourChessRank", "Allow Others to See Your Chess Rank"), ("AllowOthersToSeeYourFishingSkill", "Allow Others to See Your Fishing Skill"),
                ("AllowOthersToSeeYourNumberOfDeaths", "Allow Others to See Your Number of Deaths"), ("AllowOthersToSeeYourNumberOfTitles", "Allow Others to See Your Number of Titles"));
            Group("Character Behavior", "srv-character",
                ("RunAsDefaultMovement", "Run as Default Movement"), ("AdvancedCombatInterface", "Advanced Combat Interface"), ("AutoTarget", "Auto Target"),
                ("AutoRepeatAttacks", "Automatically Repeat Attacks"), ("UseChargeAttack", "Use Charge Attack"), ("LeadMissileTargets", "Lead Missile Targets"), ("UseFastMissiles", "Use Fast Missiles"));
            Group("Chat", "srv-chat",
                ("StayInChatModeAfterSendingMessage", "Stay in Chat Mode After Sending a Message"), ("ListenToAllegianceChat", "Listen to Allegiance Chat"), ("ListenToGeneralChat", "Listen to General Chat"),
                ("ListenToTradeChat", "Listen to Trade Chat"), ("ListenToLFGChat", "Listen to LFG Chat"), ("ListenToRoleplayChat", "Listen to Roleplay Chat"),
                ("ListenToSocietyChat", "Listen to Society Chat"), ("ListenToPKDeathMessages", "Listen to PK death messages"), ("AppearOffline", "Appear Offline"));
        }
        bool serverVitals = ServerOption != null && ServerOption("SideBySideVitals") != null;
        var vitals = serverVitals ? new VBoxContainer() : Section(b, "Vitals");
        var stacked = new CheckBox { Text = "Stacked (one above the other)", ButtonPressed = RetailHud.VitalsStackedChoice, FocusMode = FocusModeEnum.None };
        var row = new CheckBox { Text = "In a row (side by side)", ButtonPressed = !RetailHud.VitalsStackedChoice, FocusMode = FocusModeEnum.None };
        var group = new ButtonGroup();
        stacked.ButtonGroup = group; row.ButtonGroup = group;
        stacked.Toggled += v => { if (v) Hud?.SetVitalsStacked(true); };
        row.Toggled += v => { if (v) Hud?.SetVitalsStacked(false); };
        vitals.AddChild(stacked);
        vitals.AddChild(row);
        if (serverVitals) vitals.QueueFree();   // (set by the game's own Side By Side Vitals below)
        var display = Section(b, "Display");
        // the size of all text: the game's windows, ours, chat, the map
        var sizeRow = new HBoxContainer();
        var sizeLbl = new Label { Text = $"Text size {RetailTheme.Scale * 100:0}%", CustomMinimumSize = new Vector2(120, 0) };
        var size = new HSlider { MinValue = 75, MaxValue = 200, Step = 5, Value = RetailTheme.Scale * 100, SizeFlagsHorizontal = SizeFlags.ExpandFill,
                                 FocusMode = FocusModeEnum.None, TooltipText = "Makes text bigger everywhere: the game's windows, chat, the map and ACGodot's own windows." };
        size.ValueChanged += v => { sizeLbl.Text = $"Text size {v:0}%"; RetailTheme.SetScale((float)v / 100f, GetTree()); };
        sizeRow.AddChild(sizeLbl); sizeRow.AddChild(size);
        display.AddChild(sizeRow);
        // the font everything's written in (Noto Sans - the plugins' windows' and the travel arrow's - unless the game's own is chosen)
        var fontRow = new HBoxContainer();
        fontRow.AddChild(new Label { Text = "Font", CustomMinimumSize = new Vector2(120, 0) });
        var fontPick = new OptionButton { SizeFlagsHorizontal = SizeFlags.ExpandFill, FocusMode = FocusModeEnum.None,
                                          TooltipText = "The font the game's windows, chat, names and ACGodot's own windows are written in.\nNoto Sans is the plugins' windows' font (and the travel arrow's); \"The game's own\" is the original letters." };
        var fonts = RetailTheme.FontChoices();
        for (int i = 0; i < fonts.Count; i++) { fontPick.AddItem(fonts[i].label, i); if (fonts[i].key == RetailTheme.FontChoice) fontPick.Select(i); }
        fontPick.ItemSelected += i => RetailTheme.SetFont(fonts[(int)i].key, GetTree());
        fontRow.AddChild(fontPick);
        display.AddChild(fontRow);
        var chatRow = new HBoxContainer();
        chatRow.AddChild(new Label { Text = "Chat font", CustomMinimumSize = new Vector2(120, 0) });
        var chatPick = new OptionButton { SizeFlagsHorizontal = SizeFlags.ExpandFill, FocusMode = FocusModeEnum.None,
                                          TooltipText = "The chat windows' font, if not the one above (the game's own letters suit the windows but can look odd in a long chat)." };
        var chatFonts = new List<(string key, string label)> { ("same", "The same as above") };
        chatFonts.AddRange(fonts);
        for (int i = 0; i < chatFonts.Count; i++) { chatPick.AddItem(chatFonts[i].label, i); if (chatFonts[i].key == RetailTheme.ChatFontChoice) chatPick.Select(i); }
        chatPick.ItemSelected += i => RetailTheme.SetChatFont(chatFonts[(int)i].key, GetTree());
        chatRow.AddChild(chatPick);
        display.AddChild(chatRow);
        // the clock under the radar's coordinates
        var clockRow = new HBoxContainer();
        var clockOn = new CheckBox { Text = "Radar clock", ButtonPressed = RetailHud.ClockOn, FocusMode = FocusModeEnum.None, CustomMinimumSize = new Vector2(120, 0),
                                     TooltipText = "The time of day under the radar's coordinates." };
        clockOn.Toggled += v => RetailHud.ClockOn = v;
        clockRow.AddChild(clockOn);
        var clockPick = new OptionButton { SizeFlagsHorizontal = SizeFlags.ExpandFill, FocusMode = FocusModeEnum.None, TooltipText = "The clock's font." };
        var clockFonts = new List<(string key, string label)> { ("same", "The game's text font") };
        clockFonts.AddRange(fonts);
        for (int i = 0; i < clockFonts.Count; i++) { clockPick.AddItem(clockFonts[i].label, i); if (clockFonts[i].key == RetailHud.ClockFont) clockPick.Select(i); }
        clockPick.ItemSelected += i => RetailHud.ClockFont = clockFonts[(int)i].key;
        clockRow.AddChild(clockPick);
        var clockSize = new SpinBox { MinValue = 0, MaxValue = 40, Step = 1, Value = RetailHud.ClockSize, Suffix = "px", FocusMode = FocusModeEnum.None,
                                      TooltipText = "The clock's text size (0: the same as the game's text)." };
        clockSize.ValueChanged += v => RetailHud.ClockSize = (int)v;
        clockRow.AddChild(clockSize);
        display.AddChild(clockRow);
        display.AddChild(Text("Some windows take a new size the next time they open.", 11, RetailTheme.Dim));
        // (Show the debug text: in Plugins > Debug now, with the rest of the test switches)
        display.AddChild(Check("Start with the window maximized", StartMaximized, v => { StartMaximized = v; if (v) GetWindow().Mode = Window.ModeEnum.Maximized; },
            "The game's window fills the screen (under its title bar) each time it starts."));
        if (RestWorld != null && SetRestWorld != null)
            display.AddChild(Check("Don't draw the 3D world while the window isn't the active one", RestWorld(), v => SetRestWorld(v),
                "Clicked away to another window, the world isn't drawn (the graphics card rests) - the windows, chat, maps and plugins carry on, and so does the game. /3d tries it by hand."));
        if (HighRes != null && SetHighRes != null)
            display.AddChild(Check("High-resolution textures", HighRes(), v => SetHighRes(v),
                "Textures from client_highres.dat (the sharper copies), where it has them. Takes effect the next time the game starts. Models are the same either way - that file only holds textures."));
        if (JumpArc != null && SetJumpArc != null)
            display.AddChild(Check("Show the jump's arc while it charges", JumpArc(), v => SetJumpArc(v),
                "Holding Space, a line shows where the jump would go and a ring where it would land, if let go now.\nThe precise jump's key (Ctrl+Space unless changed in Configure Keyboard > Movement) starts a precise jump (always with the arc): let go of both, W / S set the power a percent at a time, A / D aim, Shift held for the short jump, Space jumps, Esc calls it off."));
        if (SoundOn != null && SetSoundOn != null)
            display.AddChild(Check("Sound", SoundOn(), v => SetSoundOn(v),
                "The game's sounds, on or off (all of them, whichever window's the active one)."));
        if (RestSound != null && SetRestSound != null)
            display.AddChild(Check("No sound while the window isn't the active one", RestSound(), v => SetRestSound(v),
                "Clicked away to another window, the game goes quiet; back, its sound returns."));
        return page;
    }

    private void VideoSection(VBoxContainer b)
    {
        var video = Section(b, "Video", "video");
        void Pick(string label, string tip, (string name, int value)[] choices, int now, Action<int> set) => PickRow(video, label, tip, choices, now, set);
        void Slide(string label, string tip, int min, int max, int step, int now, Func<int, string> shown, Action<int> set) =>
            SliderRow(video, label, tip, min, max, step, now, shown, set, false);
        video.AddChild(Check("Full screen", Video.Fullscreen, v => { Video.Fullscreen = v; Video.Changed(); }, "The game covers the whole screen, with no title bar."));
        video.AddChild(Check("Keep time with the screen (VSync)", Video.VSync, v => { Video.VSync = v; Video.Changed(); },
            "Frames are drawn in step with the screen's refresh: no tearing. Off, as many as the limit below allows."));
        Pick("Most frames a second", "A limit on how many frames are drawn each second (less work for the graphics card).",
            new[] { ("No limit", 0), ("30", 30), ("45", 45), ("60", 60), ("75", 75), ("90", 90), ("120", 120), ("144", 144), ("165", 165), ("240", 240) }, Video.FrameCap, v => Video.FrameCap = v);
        Pick("Smooth edges (MSAA)", "Smooths the jagged edges of the world's shapes. More costs more.",
            new[] { ("Off", 0), ("2x", 1), ("4x", 2), ("8x", 3) }, Video.Msaa, v => Video.Msaa = v);
        video.AddChild(Check("Smooth edges, the cheap way (FXAA)", Video.Fxaa, v => { Video.Fxaa = v; Video.Changed(); },
            "A quick smoothing of the whole picture: nearly free, a little soft. Can be used with or instead of MSAA."));
        Pick("Sharp textures at a slant", "How sharp the ground and walls stay when seen at a shallow angle (anisotropic filtering).",
            new[] { ("Off", 0), ("2x", 1), ("4x", 2), ("8x", 3), ("16x", 4) }, Video.Aniso, v => Video.Aniso = v);
        Slide("3D detail", "The world is drawn at this much of the window's size and stretched to fit: lower is faster and blurrier. The windows and text stay sharp.",
            50, 100, 5, Video.Scale, v => v + "%", v => Video.Scale = v);
        Slide("Landscape", "How far the land is drawn, each way from you.", 2, 8, 1, Video.Land, v => $"{v * 192} m", v => Video.Land = v);
        video.AddChild(Check("Tint ground too steep to walk up", Video.Steep, v => { Video.Steep = v; Video.Changed(); },
            "Hillsides you can't run up (steeper than the game lets you walk) are tinted dark red."));
        video.AddChild(Check("Unload graphics nothing is using", Video.Unload, v => { Video.Unload = v; Video.Changed(); },
            "Models, textures and creature looks nothing on screen has used for 3 minutes are let go of (and their graphics-card\ncopies) - memory stays near what's around you instead of growing with every place you've been. Coming back to a\nplace you left a while ago loads its graphics again (a moment's hitch). Off: everything stays loaded."));
        Slide("Buildings, trees", "How far buildings, trees and other scenery are drawn, each way from you. This one costs the most.", 1, 5, 1, Video.Things, v => $"{v * 192} m", v => Video.Things = v);
        Slide("Field of view", "How wide the view is.", 50, 100, 5, Video.Fov, v => v + "°", v => Video.Fov = v);
    }

    /// <summary>Video, advanced: the lighting and effects (shadows, ambient occlusion, colour grading, the game's lamps,
    /// the distant landscape, moving textures, the sea past the world's edge) - each with its switch.</summary>
    private void EffectsSection(VBoxContainer b)
    {
        var sec = Section(b, "Video: lighting and effects (advanced)", "video_fx");
        void Note(string text)
        {
            // a sub-heading: gold, a little larger, with a gap above
            var l = new Label { Text = text };
            l.AddThemeColorOverride("font_color", RetailTheme.Gold);
            l.AddThemeFontSizeOverride("font_size", RetailTheme.Px(14));
            sec.AddChild(new Control { CustomMinimumSize = new Vector2(0, 6) });
            sec.AddChild(l);
        }
        void Pick(string label, string tip, (string name, int value)[] choices, int now, Action<int> set) => PickRow(sec, label, tip, choices, now, set);
        void Slide(string label, string tip, int min, int max, int step, int now, Func<int, string> shown, Action<int> set) =>
            SliderRow(sec, label, tip, min, max, step, now, shown, set, false);
        Note("Shadows");
        Pick("Sun shadows", "Shadows from the sun. Characters and creatures: only those cast them (the cheapest, and the game's rooms aren't darkened).\nEverything: buildings, trees and hills too - rooms under a roof go darker.",
            new[] { ("Off", 0), ("Characters and creatures", 1), ("Everything", 2) }, Video.Shadows, v => Video.Shadows = v);
        Slide("Shadow distance", "How far from the camera shadows are drawn. Further is softer and costs a little more.", 20, 300, 10, Video.ShadowReach, v => $"{v} m", v => Video.ShadowReach = v);
        Note("Light");
        sec.AddChild(Check("Lamps light their surroundings", Video.Lamps, v => { Video.Lamps = v; Video.Changed(); },
            "Lamp posts, torches, braziers, candles and glowing things light what's around them, as their models say (colour and reach).\nOut on the landscape they fade in bright day, as in the game."));
        Slide("Lamp brightness", "How strong the lamps are (100% is the tuned default).", 25, 300, 5, Video.LampBright, v => $"{v}%", v => Video.LampBright = v);
        sec.AddChild(Check("Light around your character", Video.ViewerLight, v => { Video.ViewerLight = v; Video.Changed(); },
            "The game's light that goes with you: in dungeons and buildings, and outside at night, so what's close by isn't pitch dark."));
        sec.AddChild(Check("Ambient occlusion", Video.Ao, v => { Video.Ao = v; Video.Changed(); },
            "Darkens corners, creases and the ground under things a little, so shapes stand out. Costs some graphics-card time."));
        Slide("AO strength", "How dark the corners go.", 25, 300, 5, Video.AoStrength, v => $"{v}%", v => Video.AoStrength = v);
        Note("Colour");
        sec.AddChild(Check("Colour grading", Video.Grade, v => { Video.Grade = v; Video.Changed(); },
            "A gentle curve (deeper darks, a little more life in the middle), a touch of warmth and colour. Off: the picture as the game makes it."));
        Slide("Brightness", "", 50, 150, 5, Video.Brightness, v => $"{v}%", v => Video.Brightness = v);
        Slide("Contrast", "", 50, 150, 5, Video.Contrast, v => $"{v}%", v => Video.Contrast = v);
        Slide("Saturation", "", 0, 200, 5, Video.Saturation, v => $"{v}%", v => Video.Saturation = v);
        Slide("Warmth", "Warmer (more red, less blue) or cooler.", -20, 20, 1, Video.Warmth, v => v > 0 ? $"+{v}" : v.ToString(), v => Video.Warmth = v);
        Pick("Tone mapping", "How bright light is squeezed into what the screen shows. Linear is the game's own look; the others soften the brightest parts.",
            new[] { ("Linear (the game's)", 0), ("Filmic", 1), ("ACES", 2), ("AgX", 3) }, Video.Tonemap, v => Video.Tonemap = v);
        sec.AddChild(Check("Glow", Video.Glow, v => { Video.Glow = v; Video.Changed(); },
            "Portals, spell bolts, lamps, glowing runes and other luminous things get a soft halo."));
        Slide("Glow strength", "", 25, 300, 5, Video.GlowStrength, v => $"{v}%", v => Video.GlowStrength = v);
        sec.AddChild(Check("Volumetric fog", Video.VolFog, v => { Video.VolFog = v; Video.Changed(); },
            "The day's fog as real haze in the air: light shafts through trees, misty dungeons, beams round lamps at night.\nOne of the costlier effects."));
        Slide("Fog density", "How thick the haze is.", 10, 400, 10, Video.VolFogDensity, v => $"{v}%", v => Video.VolFogDensity = v);
        Note("Smoothness and scaling");
        Pick("3D scaling", "How the 3D world is scaled up to the window when \"3D detail\" (above) is under 100%.\nFSR 2 gives a near-full picture from 67-77% and smooths edges and shimmer itself (MSAA goes off with it).\nFSR 1 is sharper than plain scaling and cheap.",
            new[] { ("Plain", 0), ("FSR 1 (sharpened)", 1), ("FSR 2 (best, with its own TAA)", 2) }, Video.Upscale, v => Video.Upscale = v);
        sec.AddChild(Check("Temporal anti-aliasing", Video.Taa, v => { Video.Taa = v; Video.Changed(); },
            "Smooths shimmer on fences, leaves and thin far-off edges that MSAA misses; a little soft when moving. (FSR 2 has its own.)"));
        Note("Distance and the world");
        Slide("Distant land", "A simple version of the land past the detailed landscape, so hills and coasts show on the horizon (0: none).\nOnly what's past the Landscape distance above is drawn this way.", 0, 15, 1, Video.FarLand, v => v == 0 ? "off" : $"{v * 192} m", v => Video.FarLand = v);
        Slide("Distant trees", "Trees, bushes and rocks past the \"Buildings, trees\" distance, drawn with their simplest models so forests\ndon't stop in a line. Never past the Landscape distance (they stand on it). 0: none.", 0, 8, 1, Video.FarTrees, v => v == 0 ? "off" : $"{v * 192} m", v => Video.FarTrees = v);
        Note("Ground detail");
        sec.AddChild(Check("Bumpy ground up close", Video.Bump, v => { Video.Bump = v; Video.Changed(); },
            "Grass, rock and dirt get a little depth, made from their own textures' light and dark, so the ground near you\nisn't flat. Fades out with distance; not on water."));
        Slide("Bumpiness", "", 25, 300, 5, Video.BumpStrength, v => $"{v}%", v => Video.BumpStrength = v);
        sec.AddChild(Check("Unstretched cliffs", Video.Triplanar, v => { Video.Triplanar = v; Video.Changed(); },
            "The game lays every patch of ground's texture from straight above, so on steep slopes it stretches into streaks.\nThis textures steep ground from the side as well, keeping its size. A little more graphics-card work on slopes."));
        sec.AddChild(Check("Water: ripples, glint, foam", Video.Water, v => { Video.Water = v; Video.Changed(); },
            "Ripples, the sun's glint, darker deep water and foam where it meets the shore."));
        sec.AddChild(Check("Sea past the world's edge", Video.Ocean, v => { Video.Ocean = v; Video.Changed(); },
            "Open sea beyond the map's edge instead of nothing."));
        sec.AddChild(Check("Moving textures", Video.Scroll, v => { Video.Scroll = v; Video.Changed(); },
            "Textures the game makes flow: waterfalls, lava, some glowing runes and portals."));
    }

    private Control ChatTab()
    {
        var page = Page("Chat");
        var b = BoxOf(page);
        var chats = Chats?.Invoke() ?? Array.Empty<ChatWindow>();
        foreach (var w in chats.OrderBy(c => c.Index))
        {
            var sec = Section(b, WindowTitles[Math.Clamp(w.Index, 0, WindowTitles.Length - 1)], "chat" + w.Index);
            var grid = new GridContainer { Columns = 2 };
            foreach (var (kind, name, tip) in Kinds)
            {
                var k = kind; var win = w;
                grid.AddChild(Check(name, w.Filters.Contains(k), v => { if (v) win.Filters.Add(k); else win.Filters.Remove(k); win.SaveSettings(); }, tip));
            }
            sec.AddChild(grid);
            // how solid the window is: its frame and background (the words stay solid)
            var orow = new HBoxContainer();
            const string otip = "How solid this chat window's frame and background are - lower lets the world show through. The text stays as it is.";
            var olbl = new Label { Text = $"Window opacity {(int)Math.Round(w.Opacity * 100)}%", CustomMinimumSize = new Vector2(150, 0), TooltipText = otip, MouseFilter = MouseFilterEnum.Stop };
            var osl = new HSlider { MinValue = 10, MaxValue = 100, Step = 5, Value = Math.Round(w.Opacity * 100), SizeFlagsHorizontal = SizeFlags.ExpandFill, FocusMode = FocusModeEnum.None, TooltipText = otip };
            var ow = w;
            osl.ValueChanged += v => { olbl.Text = $"Window opacity {(int)v}%"; ow.Opacity = (float)v / 100f; ow.ApplyOpacity(); };
            osl.DragEnded += _ => ow.SaveSettings();
            orow.AddChild(olbl); orow.AddChild(osl);
            sec.AddChild(orow);
            // how big its text is (times the game's text size)
            var frow = new HBoxContainer();
            const string ftip = "How big this chat window's text is - on top of the game's text size (Character > Text size).";
            var flbl = new Label { Text = $"Text size {(int)Math.Round(w.TextScale * 100)}%", CustomMinimumSize = new Vector2(150, 0), TooltipText = ftip, MouseFilter = MouseFilterEnum.Stop };
            var fsl = new HSlider { MinValue = 60, MaxValue = 250, Step = 10, Value = Math.Round(w.TextScale * 100), SizeFlagsHorizontal = SizeFlags.ExpandFill, FocusMode = FocusModeEnum.None, TooltipText = ftip };
            fsl.ValueChanged += v => { flbl.Text = $"Text size {(int)v}%"; ow.TextScale = (float)v / 100f; ow.ApplyTextScale(); };
            fsl.DragEnded += _ => ow.SaveSettings();
            frow.AddChild(flbl); frow.AddChild(fsl);
            sec.AddChild(frow);
        }
        MessageColorSection(b);
        var buttons = new HBoxContainer();
        buttons.AddChild(Small("Defaults", () =>
        {
            foreach (var w in chats) { w.Filters = ChatWindow.DefaultFilters(w.Index); w.SaveSettings(); }
            Refresh();
        }));
        // (the same chat on every character: export the whole page from one, import it on the others)
        var note = new Label { Text = "" };
        note.AddThemeColorOverride("font_color", RetailTheme.Dim);
        var exp = Small("Export chat settings", () =>
        {
            var cfg = new ConfigFile();
            foreach (var w in chats) w.ExportTo(cfg);
            cfg.SetValue("colors", "data", ChatColors.ExportText());
            global::ACGodot.SafeConfig.Save(cfg, ChatShareFile);
            note.Text = "  exported - Import on your other characters";
        });
        exp.TooltipText = "Saves this whole page - every chat window's filters, opacity, text size, place and size, and the message colours - to a file all your characters share";
        var imp = Small("Import chat settings", () =>
        {
            var cfg = new ConfigFile();
            if (global::ACGodot.SafeConfig.Load(cfg, ChatShareFile) != Error.Ok) { note.Text = "  nothing exported yet"; return; }
            foreach (var w in chats) w.ImportFrom(cfg);
            if (cfg.HasSectionKey("colors", "data")) ChatColors.ImportText((string)cfg.GetValue("colors", "data"));
            Refresh();
        });
        imp.TooltipText = "Takes the chat settings last exported (from any character): windows, filters and colours";
        buttons.AddChild(exp); buttons.AddChild(imp); buttons.AddChild(note);
        b.AddChild(buttons);
        return page;
    }

    private const string ChatShareFile = "user://chat_settings_shared.cfg";

    // every kind of message the chat has shown: an example, and a colour of your own for it (as the name tags' colours)
    private VBoxContainer? _colorSec;
    private bool _colorsStale, _colorsHooked, _pickerOpen;

    private void MessageColorSection(VBoxContainer b)
    {
        _colorSec = Section(b, "Message colors", "chat_colors");
        if (!_colorsHooked)
        {
            _colorsHooked = true;
            // (new kinds turning up while it's open, or since it was made: listed when next seen)
            ChatColors.Added += () => _colorsStale = true;
            VisibilityChanged += () => { if (Visible && _colorsStale) FillColors(); };
        }
        FillColors();
    }

    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("OptionsWindow");
        base._Process(delta);
        // (the colour list can be shown inside the game's own options panel, not this window: whether it's on screen
        // is the list's own - the window itself may be hidden. Refreshed when a new kind is first seen - not while a colour is being picked)
        if (_colorSec != null && GodotObject.IsInstanceValid(_colorSec) && _colorsStale && !_pickerOpen && _colorSec.IsVisibleInTree() && (_colorTick += delta) > 1.0) { _colorTick = 0; FillColors(); }
    }
    private double _colorTick;

    private void FillColors()
    {
        _colorsStale = false;
        if (_colorSec == null || !GodotObject.IsInstanceValid(_colorSec)) return;
        foreach (var c in _colorSec.GetChildren()) { _colorSec.RemoveChild(c); c.QueueFree(); }
        var sec = _colorSec;
        var kinds = ChatColors.All;
        sec.AddChild(Text("Each kind of message, with its latest example. Pick a colour to use it for all of that kind in every chat window. Messages that fit no kind are listed once each under Other messages - give them a colour, or ignore them.", 11, RetailTheme.Dim));
        var grid = new GridContainer { Columns = 4 };
        string? last = null;
        foreach (var k in kinds)
        {
            if (last != k.Section)
            {
                last = k.Section;
                grid.AddChild(Text(k.Section, 12, RetailTheme.Gold)); grid.AddChild(new Control()); grid.AddChild(new Control()); grid.AddChild(new Control());
            }
            var kk = k;
            bool seen = k.HasDefault;
            Color shown = k.Mine ?? (seen ? k.Default : RetailTheme.Dim);
            string label = k.Other ? k.Example : (k.Name + (seen ? "  -  " + k.Example : "  (not seen yet)"));
            var ex = new Label { Text = label, TooltipText = k.Other ? $"{k.Chat}: {k.Example}" : (seen ? k.Example : "No message of this kind yet - you can still pick its colour."),
                                 MouseFilter = MouseFilterEnum.Stop, SizeFlagsHorizontal = SizeFlags.ExpandFill,
                                 ClipText = true, CustomMinimumSize = new Vector2(190, 0), TextOverrunBehavior = TextServer.OverrunBehavior.TrimEllipsis };
            ex.AddThemeColorOverride("font_color", shown);
            var pick = new ColorPickerButton { Color = k.Mine ?? (seen ? k.Default : Colors.White), CustomMinimumSize = new Vector2(26, 18), FocusMode = FocusModeEnum.None, TooltipText = "This kind's colour" };
            pick.Pressed += () => _pickerOpen = true;
            pick.PopupClosed += () => { _pickerOpen = false; ChatColors.Set(kk, kk.HasDefault && pick.Color == kk.Default ? null : pick.Color); ex.AddThemeColorOverride("font_color", pick.Color); };
            var back = Small("game's", () => { ChatColors.Set(kk, null); pick.Color = kk.HasDefault ? kk.Default : Colors.White; ex.AddThemeColorOverride("font_color", kk.HasDefault ? kk.Default : RetailTheme.Dim); });
            back.TooltipText = "Back to the game's colour for this kind";
            grid.AddChild(ex); grid.AddChild(pick); grid.AddChild(back);
            if (k.Other)
            {
                var ign = Small("ignore", () => { ChatColors.Ignore(kk); FillColors(); });
                ign.TooltipText = "Take it off this list (its messages keep the game's colour)";
                grid.AddChild(ign);
            }
            else grid.AddChild(new Control());
        }
        sec.AddChild(grid);
        if (ChatColors.IgnoredCount > 0) sec.AddChild(Small($"Show the {ChatColors.IgnoredCount} ignored again", () => { ChatColors.UnignoreAll(); FillColors(); }));
        sec.AddChild(Small("All back to the game's colours", () => { ChatColors.ResetAll(); Refresh(); }));
    }

    // Debug: every test and logging switch in one place - the game's own and each running plugin's
    private void DebugSection(VBoxContainer page)
    {
        var sec = Section(page, "Debug", "debug");
        var all = new List<(Func<bool> get, Action<bool> set)>();
        if (DebugShown != null && SetDebugShown != null) all.Add((DebugShown, SetDebugShown));
        foreach (var (tag, _) in ACGodot.DebugLogs.Kinds) { string t = tag; all.Add((() => ACGodot.DebugLogs.On(t), v => ACGodot.DebugLogs.Set(t, v))); }
        var plugins = Host?.Invoke()?.Plugins.OfType<Plugins.IDebugSwitches>().ToList() ?? new List<Plugins.IDebugSwitches>();
        var switches = new List<(string plugin, Plugins.DebugSwitch sw)>();
        foreach (var p in plugins)
        {
            try { foreach (var sw in p.DebugSwitches()) { switches.Add((((Plugins.IPlugin)p).Name, sw)); all.Add((sw.Get, sw.Set)); } }
            catch (Exception ex) { GD.PushWarning("debug switches: " + ex.Message); }
        }

        var buttons = new HBoxContainer();
        buttons.AddThemeConstantOverride("separation", 8);
        buttons.AddChild(Small("All on", () => { foreach (var a in all) { try { a.set(true); } catch { } } Refresh(); }));
        buttons.AddChild(Small("All off", () => { foreach (var a in all) { try { a.set(false); } catch { } } Refresh(); }));
        sec.AddChild(buttons);

        sec.AddChild(Text("ACGodot", 12, RetailTheme.Gold));
        if (DebugShown != null && SetDebugShown != null)
            sec.AddChild(Check("Show the debug text", DebugShown(), v => SetDebugShown(v), "The information in the top left (Ctrl+D or /debug)."));
        foreach (var (tag, what) in ACGodot.DebugLogs.Kinds)
        {
            string t = tag;
            sec.AddChild(Check($"Log [{tag}]", ACGodot.DebugLogs.On(t), v => ACGodot.DebugLogs.Set(t, v), what + " - to the console / godot.log."));
        }
        string? last = null;
        foreach (var (plugin, sw) in switches)
        {
            if (plugin != last) { sec.AddChild(Text(plugin, 12, RetailTheme.Gold)); last = plugin; }
            var s2 = sw;
            bool on = false;
            try { on = s2.Get(); } catch { }
            sec.AddChild(Check(s2.Name, on, v => { try { s2.Set(v); } catch (Exception ex) { GD.PushWarning("debug switch: " + ex.Message); } }, s2.Tip));
        }
        if (plugins.Count == 0) sec.AddChild(Text("No running plugin has test switches.", 11, RetailTheme.Dim));
    }

    // Plugins: which start with the game (plugins/plugins.json - the MelkTank Launcher shows the same switches)
    private Control PluginsTab()
    {
        var page = Page("Plugins");
        VideoSection(BoxOf(page));
        EffectsSection(BoxOf(page));
        var sec = Section(BoxOf(page), "Plugins that start with the game", "plugins");
        var off = Plugins.PluginHost.Disabled();
        foreach (var name in Plugins.PluginHost.Known)
        {
            string n = name;
            sec.AddChild(Check(n, !off.Contains(n), v => Plugins.PluginHost.Switch(n, v)));
        }
        if (Plugins.PluginHost.Known.Count == 0) sec.AddChild(Text("No plugins found.", 12, RetailTheme.Dim));
        sec.AddChild(Text("A change applies the next time the game starts. Plugins live in a folder each: plugins/Name/Name.dll, with their files beside it.", 11, RetailTheme.Dim));
        DebugSection(BoxOf(page));
        // which build this is (to tell clients apart)
        var build = new Label { Text = "ACGodot " + global::ACGodot.BuildInfo.Label, HorizontalAlignment = HorizontalAlignment.Center };
        build.AddThemeColorOverride("font_color", new Color(0.65f, 0.6f, 0.5f));
        BoxOf(page).AddChild(new HSeparator());
        BoxOf(page).AddChild(build);
        return page;
    }
}
