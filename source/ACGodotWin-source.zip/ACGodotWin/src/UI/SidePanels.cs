using System;
using System.Collections.Generic;
using System.Linq;
using ACGodot.Combat;
using Godot;

namespace ACGodot.UI;

/// <summary>
/// A side panel from the game's layouts (inventory, character, spellbook, social, quests...): its title strip, X,
/// tabs and art as the game draws them, sized from its corner; only one shows at a time, where the last was left.
/// Our own content is laid over each page in the game's font.
/// </summary>
public partial class SidePanel : RetailWindow
{
    /// <summary>The panel ids the control bar's buttons open (the game's own numbering).</summary>
    public const int Inventory = 7, Options = 10, CharacterInfo = 11, Social = 12, Spellbook = 13, MapPanel = 16, Quests = 25;
    public int PanelId;
    public static readonly List<SidePanel> All = new();
    public Action<SidePanel, bool>? Shown;

    protected bool BuildPanel(int id, uint layout, uint element)
    {
        PanelId = id;
        if (!BuildFrom(layout, element, "sidepanel")) return false;
        // the game's side panel is 300 x 362 (a tabbed panel's layout is taller: its pages are cut to fit)
        var start = new Vector2(Root!.Size.X, Math.Min(Root.Size.Y, 362));
        SetLimits(start, new Vector2(1600, 1400));
        ClipContents = true;
        AddGrip();
        SetSize2(start);
        All.Add(this);
        Visible = false;
        return true;
    }

    /// <summary>Opens it (shutting whichever side panel was open, and taking its place).</summary>
    public virtual void Open()
    {
        foreach (var p in All) if (p != this && p.Visible) { Position = p.Position; p.Visible = false; p.Shown?.Invoke(p, false); }
        LoadPlace();
        var screen = GetViewportRect().Size;
        if (Position.X <= 0 && Position.Y <= 0) Position = new Vector2(screen.X - Size.X - 10, Math.Max(10, screen.Y - Size.Y - 200));
        Position = new Vector2(Math.Clamp(Position.X, 0, Math.Max(0, screen.X - 60)), Math.Clamp(Position.Y, 0, Math.Max(0, screen.Y - 40)));
        Visible = true;
        MoveToFront();
        Refresh();
        Shown?.Invoke(this, true);
    }

    public void Toggle() { if (Visible) { Visible = false; Shown?.Invoke(this, false); } else Open(); }

    public virtual void Refresh() { }

    /// <summary>A tabbed panel's pages: sized to the panel under its tabs.</summary>
    protected List<UiNode> Pages = new();
    /// <summary>A tabbed panel's tabs: they share the strip left of the X as it widens.</summary>
    protected List<UiNode> TabNodes = new();

    protected override void Resized2()
    {
        foreach (var p in Pages) p.Resize(new Vector2(Size.X, Math.Max(40, Size.Y - p.Position.Y)));
        if (Root != null && TabNodes.Count > 0)
        {
            float f = Math.Max(0.5f, (Size.X - 24f) / Math.Max(1f, Root.DesignSize.X - 24f));
            foreach (var t in TabNodes) { t.Resize(new Vector2(t.DesignSize.X * f, t.DesignSize.Y)); t.Position = new Vector2(t.DesignPos.X * f, t.DesignPos.Y); }
        }
        // the X stays at the right
        foreach (var c in Root?.GetChildren() ?? new Godot.Collections.Array<Node>())
            if (c is UiNode n && (n == CloseNode || n.DesignPos.Y < 25 && n.DesignSize.X <= 24 && n.DesignPos.X >= 270))
            {
                // (the layout ties it to both sides - stretched, its picture would show twice)
                n.Resize(n.DesignSize);
                n.Position = new Vector2(Size.X - n.DesignSize.X, n.DesignPos.Y);
            }
        if (CloseNode != null && CloseNode.GetParent() != Root)
        {
            float w = (CloseNode.GetParent() as Control)?.Size.X ?? Size.X;
            CloseNode.Resize(CloseNode.DesignSize);
            CloseNode.Position = new Vector2(w - CloseNode.DesignSize.X, CloseNode.DesignPos.Y);
        }
    }

    /// <summary>The usual title strip and X (elements 0x100000FD / 0x100000FC, or given ones).</summary>
    protected UiNode? Frame(uint title, uint close)
    {
        var t = Root!.Find(title);
        TitleFrom(t);
        CloseFrom(Root.Find(close));
        Closed = () => Shown?.Invoke(this, false);
        return t;
    }

    /// <summary>A page's own pieces put away and a scrolling list of our own laid over it.</summary>
    protected static VBoxContainer ContentOver(UiNode page, float inset = 6f)
    {
        foreach (var c in page.GetChildren()) if (c is UiNode n) n.Visible = false;
        // the page's dark backing (its own pieces are put away)
        var back = new Panel { MouseFilter = MouseFilterEnum.Ignore, ZIndex = 1 };
        back.SetAnchorsPreset(LayoutPreset.FullRect);
        back.AddThemeStyleboxOverride("panel", new StyleBoxFlat { BgColor = new Color(0.04f, 0.035f, 0.03f, 0.88f), BorderColor = new Color(0.35f, 0.28f, 0.14f),
                                                                 BorderWidthLeft = 1, BorderWidthRight = 1, BorderWidthBottom = 1 });
        page.AddChild(back);
        var scroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled, MouseFilter = MouseFilterEnum.Pass };
        scroll.SetAnchorsPreset(LayoutPreset.FullRect);
        scroll.ZIndex = 2;
        scroll.OffsetLeft = inset; scroll.OffsetTop = inset; scroll.OffsetRight = -inset; scroll.OffsetBottom = -inset;
        if (RetailTheme.Current != null) scroll.Theme = RetailTheme.Current;
        var box = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        box.AddThemeConstantOverride("separation", 1);
        scroll.AddChild(box);
        page.AddChild(scroll);
        return box;
    }

    /// <summary>A list row as the game frames them (a spell in the spellbook, a spell on you): dark, lined in gold, an icon's height.</summary>
    protected static PanelContainer RowBox(bool picked = false)
    {
        var p = new PanelContainer { MouseFilter = MouseFilterEnum.Stop, CustomMinimumSize = new Vector2(0, 32) };
        p.AddThemeStyleboxOverride("panel", new StyleBoxFlat { BgColor = new Color(0f, 0f, 0f, picked ? 0.8f : 0.55f), BorderColor = picked ? RetailTheme.Gold : new Color(0.45f, 0.36f, 0.16f),
                                                               BorderWidthLeft = 1, BorderWidthRight = 1, BorderWidthTop = 1, BorderWidthBottom = 1 });
        return p;
    }

    /// <summary>A spell's row: its icon (the game's 32 x 32), its name, and what's left of it at the right (blank: no timer).</summary>
    protected static (PanelContainer row, HBoxContainer inside) SpellRow(Control icon, string name, string time, bool picked)
    {
        var row = RowBox(picked);
        var inside = new HBoxContainer { MouseFilter = MouseFilterEnum.Ignore };
        inside.AddThemeConstantOverride("separation", 6);
        icon.CustomMinimumSize = new Vector2(32, 32);
        inside.AddChild(icon);
        var n = Line(name, picked ? RetailTheme.Gold : null);
        n.MouseFilter = MouseFilterEnum.Ignore; n.AutowrapMode = TextServer.AutowrapMode.Off; n.ClipText = true;
        n.VerticalAlignment = VerticalAlignment.Center; n.SizeFlagsVertical = SizeFlags.ExpandFill;
        inside.AddChild(n);
        if (time.Length > 0)
        {
            var t = Line(time, null, HorizontalAlignment.Right);
            t.SizeFlagsHorizontal = SizeFlags.ShrinkEnd; t.AutowrapMode = TextServer.AutowrapMode.Off; t.MouseFilter = MouseFilterEnum.Ignore;
            t.VerticalAlignment = VerticalAlignment.Center; t.SizeFlagsVertical = SizeFlags.ExpandFill;
            inside.AddChild(t);
            inside.AddChild(new Control { CustomMinimumSize = new Vector2(4, 0), MouseFilter = MouseFilterEnum.Ignore });
        }
        row.AddChild(inside);
        return (row, inside);
    }

    /// <summary>A page's list with the game's box under it (what's chosen: its description, or what raising it costs).</summary>
    protected static (VBoxContainer list, VBoxContainer foot) ContentWithFootBox(UiNode page, float footHeight = 84f)
    {
        var list = ContentOver(page, 2f);
        list.AddThemeConstantOverride("separation", 0);
        if (list.GetParent() is ScrollContainer scroll) scroll.OffsetBottom = -(footHeight + 4f);
        var box = new PanelContainer { MouseFilter = MouseFilterEnum.Pass, ZIndex = 2, AnchorLeft = 0, AnchorRight = 1, AnchorTop = 1, AnchorBottom = 1,
                                       OffsetLeft = 2, OffsetRight = -2, OffsetTop = -(footHeight + 2f), OffsetBottom = -2, ClipContents = true };
        box.AddThemeStyleboxOverride("panel", new StyleBoxFlat { BgColor = new Color(0f, 0f, 0f, 0.6f), BorderColor = new Color(0.45f, 0.36f, 0.16f),
                                                                 BorderWidthLeft = 1, BorderWidthRight = 1, BorderWidthTop = 1, BorderWidthBottom = 1,
                                                                 ContentMarginLeft = 6, ContentMarginRight = 6, ContentMarginTop = 3, ContentMarginBottom = 3 });
        if (RetailTheme.Current != null) box.Theme = RetailTheme.Current;
        var foot = new VBoxContainer();
        foot.AddThemeConstantOverride("separation", 0);
        box.AddChild(foot);
        page.AddChild(box);
        return (list, foot);
    }

    /// <summary>The same, the box holding one text ("Select a spell", or the chosen spell's description).</summary>
    protected static (VBoxContainer list, Label foot) ContentWithFoot(UiNode page, float footHeight = 84f)
    {
        var (list, box) = ContentWithFootBox(page, footHeight);
        var foot = Line("", null, HorizontalAlignment.Center);
        foot.VerticalAlignment = VerticalAlignment.Center; foot.SizeFlagsVertical = SizeFlags.ExpandFill;
        foot.MouseFilter = MouseFilterEnum.Ignore;
        box.AddChild(foot);
        return (list, foot);
    }

    protected static string TimeLeft(double left) =>
        left < 0 ? "" : left >= 3600 ? $"{(int)left / 3600}:{(int)left % 3600 / 60:00}:{(int)left % 60:00}" : $"{(int)left / 60}:{(int)left % 60:00}";

    public static void Clear(Container box) { foreach (var c in box.GetChildren()) { box.RemoveChild(c); c.QueueFree(); } }

    public static Label Line(string text, Color? color = null, HorizontalAlignment align = HorizontalAlignment.Left)
    {
        var l = new Label { Text = text, HorizontalAlignment = align, AutowrapMode = TextServer.AutowrapMode.WordSmart, SizeFlagsHorizontal = SizeFlags.ExpandFill };
        l.AddThemeColorOverride("font_color", color ?? RetailTheme.Ink);
        return l;
    }

    public static Label Head(string text) => Line(text, new Color(0.55f, 0.75f, 1f));

    public static Button Btn(string text, Action press, bool enabled = true)
    {
        var b = new Button { Text = text, FocusMode = FocusModeEnum.None, Disabled = !enabled };
        b.Pressed += press;
        return b;
    }
}

/// <summary>
/// The game's inventory panel (layout 0x21000023): your character in the middle of the paperdoll with the slots for
/// what's worn round it (a box shows the armor slots over the character), the pack column at the right (the main
/// pack, the side packs, the burden meter) and the pack's contents under it. Drag items onto the slots to wear them,
/// back into the pack to take them off, into the world to drop them, onto the shortcut bar; right-click identifies,
/// double-click wears or uses.
/// </summary>
public partial class InventoryPanel : SidePanel
{
    public const uint Layout = 0x21000023;
    public Combat.Inventory Inv = null!;
    public Func<Character?>? Me;
    public Func<uint, Texture2D?> Icon = _ => null;
    public Action<string>? Said;
    public Action? Equipped;
    public Action<Item>? Dropped, Identify;
    public Creatures.Player? Player;

    private UiNode? _title, _doll, _packs, _items, _burdenMeter, _burdenText, _burdenText2, _gridNode, _itemsTitle, _figure;
    private ScrollContainer? _scroll;
    private ItemGrid? _grid;
    private readonly List<(UiNode node, int mask, bool armor)> _slots = new();
    private CheckBox? _showSlots;
    private SubViewport? _view;
    private Camera3D? _cam;
    private Item? _sel;

    // what each paperdoll slot holds (the game's EquipMask), by where it sits on the doll
    private static readonly Dictionary<uint, (int mask, bool armor)> SlotMasks = new()
    {
        [0x100001DA] = (0x8000, false),      // necklace (top left)
        [0x1000058E] = (0x4000000, false),   // trinket
        [0x100001DD] = (0x10000, false),     // left bracelet
        [0x100001DE] = (0x40000, false),     // left ring
        [0x100001E1] = (0x200000, false),    // off hand: shield (bottom left)
        [0x10000595] = (0x10000000, false),  // aetheria (blue) - the three along the top
        [0x10000596] = (0x20000000, false),  // aetheria (yellow)
        [0x10000597] = (0x40000000, false),  // aetheria (red)
        [0x100005E9] = (0x8000000, false),   // cloak (right column, top)
        [0x100001E2] = (0x2 | 0x8 | 0x10, false),   // shirt
        [0x100001E3] = (0x40 | 0x80, false),  // trousers (by the legs: a shirt's places take in the abdomen too)
        [0x100001DB] = (0x20000, false),     // right bracelet
        [0x100001DC] = (0x80000, false),     // right ring
        [0x100001DF] = (0x100000 | 0x400000 | 0x1000000 | 0x2000000, false),   // main hand: weapon, wand, bow (right of the boots)
        [0x100001E0] = (0x800000, false),    // ammunition
        // the armor slots, over the character
        [0x100005AB] = (0x1, true),          // head
        [0x100005AC] = (0x200, true),        // chest
        [0x100005AD] = (0x400, true),        // abdomen
        [0x100005AE] = (0x800, true),        // upper arms
        [0x100005AF] = (0x1000, true),       // lower arms
        [0x100005B0] = (0x20, true),         // hands
        [0x100005B1] = (0x2000, true),       // upper legs
        [0x100005B2] = (0x4000, true),       // lower legs
        [0x100005B3] = (0x100, true),        // feet
    };

    // what each slot is called (shown faintly while it's empty, and as its tip)
    internal static string SlotName(int mask) => mask switch
    {
        0x8000 => "Neck", 0x4000000 => "Trinket", 0x10000 or 0x20000 => "Wrist", 0x40000 or 0x80000 => "Ring", 0x200000 => "Shield",
        0x10000000 or 0x20000000 or 0x40000000 => "Aeth", 0x8000000 => "Cloak", 0x1A => "Shirt", 0xC4 => "Pants", 0x800000 => "Ammo",
        0x1 => "Head", 0x200 => "Chest", 0x400 => "Abdo", 0x800 => "U.Arm", 0x1000 => "L.Arm", 0x20 => "Hands", 0x2000 => "U.Leg", 0x4000 => "L.Leg", 0x100 => "Feet",
        _ => "Weapon",
    };

    public bool Setup()
    {
        if (!BuildPanel(Inventory, Layout, 0x100001CC)) return false;
        var r = Root!;
        _title = Frame(0x100001D3, 0x100001D2);
        if (_title != null) _title.Slice = true;
        _title?.CenterText();
        // the frame laid over the whole panel has the close button's box drawn into its top right corner: kept in the
        // corner as the panel widens (it stayed where a 300-wide panel has it - an empty box in the title strip)
        if (r.Find(0x100001D0) is { } frame)
        {
            frame.Patch = (4, 26, 26, 4);
            // (the box is the button's backing: the button is drawn on it)
            if (CloseNode != null && CloseNode.GetParent() == frame.GetParent()) frame.GetParent().MoveChild(CloseNode, -1);
        }
        _doll = r.Find(0x100001CD); _packs = r.Find(0x100001CE); _items = r.Find(0x100001CF);
        foreach (var n in new[] { _doll, _packs, _items }) if (n != null) n.Pinned = true;
        _burdenMeter = r.Find(0x100001D9); _burdenText = r.Find(0x100001D7); _burdenText2 = r.Find(0x100001D8);
        _gridNode = r.Find(0x100001C6); _itemsTitle = r.Find(0x100001C5);
        _figure = r.Find(0x100001D6);
        // the paperdoll's slots
        if (_doll != null)
            foreach (var (id, (mask, armor)) in SlotMasks)
                if (_doll.Find(id) is { } sn)
                {
                    var slot = new DollSlot { Panel = this, Mask = mask, CustomMinimumSize = sn.Size, FocusMode = FocusModeEnum.None, ExpandIcon = true,
                                              IconAlignment = HorizontalAlignment.Center, VerticalIconAlignment = VerticalAlignment.Center };
                    slot.SetAnchorsPreset(LayoutPreset.FullRect);
                    slot.ZIndex = 2;
                    sn.AddChild(slot);
                    sn.MouseFilter = MouseFilterEnum.Pass;
                    _slots.Add((sn, mask, armor));
                }
        // your character, drawn live in the middle of the doll
        if (_figure != null)
        {
            _figure.Visible = true;
            foreach (var c in _figure.GetChildren()) if (c is UiNode n) n.Visible = false;
            _figure.NoImage = true;
            var container = new SubViewportContainer { Stretch = true, MouseFilter = MouseFilterEnum.Ignore, ZIndex = 1 };   // over the layout's backdrop
            container.SetAnchorsPreset(LayoutPreset.FullRect);
            _view = new SubViewport { TransparentBg = true, RenderTargetUpdateMode = SubViewport.UpdateMode.WhenVisible, Size = new Vector2I(100, 214) };
            _cam = new Camera3D { Fov = 30f, CullMask = 1u << 19, Current = true,
                                  Environment = new Godot.Environment { BackgroundMode = Godot.Environment.BGMode.ClearColor, AmbientLightSource = Godot.Environment.AmbientSource.Color,
                                                                        AmbientLightColor = new Color(0.9f, 0.88f, 0.8f), AmbientLightEnergy = 1.0f } };
            _view.AddChild(_cam);
            container.AddChild(_view);
            _figure.AddChild(container);
            _figure.MoveChild(container, 0);
        }
        // the box that shows the armor slots over the character
        if (_doll != null)
        {
            _showSlots = new CheckBox { Text = "Slots", FocusMode = FocusModeEnum.None, Position = new Vector2(40, 186), Theme = RetailTheme.Current, ZIndex = 2 };
            _showSlots.AddThemeColorOverride("font_color", RetailTheme.Ink);
            _showSlots.Toggled += on => { ShowArmor(on); SaveFlag(on); };
            _doll.AddChild(_showSlots);
            if (_doll.Find(0x100005BE) is { } lbl) lbl.Visible = false;
            _showSlots.ButtonPressed = LoadFlag();
            ShowArmor(_showSlots.ButtonPressed);
        }
        // the pack's contents: our item squares over the game's grid
        if (_gridNode != null)
        {
            foreach (var c in _gridNode.GetChildren()) if (c is UiNode n) n.Visible = false;
            if (_items?.Find(0x100001C7) is { } bar) bar.Visible = false;
            _scroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled, MouseFilter = MouseFilterEnum.Pass, Theme = RetailTheme.Current, ZIndex = 2 };
            _grid = new PackGrid { Panel = this, Source = "pack", Slot = 32 };
            _grid.DoubleClicked = Use;
            _scroll.AddChild(_grid);
            _items!.AddChild(_scroll);
        }
        // the pack column's squares: the main pack, and the side packs' places under it
        static Panel Square(Vector2 at, Vector2 size, bool open)
        {
            var p = new Panel { Position = at, Size = size, MouseFilter = MouseFilterEnum.Ignore, ZIndex = 1 };
            p.AddThemeStyleboxOverride("panel", new StyleBoxFlat { BgColor = new Color(0f, 0f, 0f, 0.5f), BorderColor = open ? new Color(1f, 0.85f, 0.4f) : new Color(0.45f, 0.36f, 0.18f, 0.9f),
                                                                  BorderWidthLeft = 1, BorderWidthRight = 1, BorderWidthTop = 1, BorderWidthBottom = 1 });
            return p;
        }
        if (_packs?.Find(0x100001C9) is { } mp) { mp.Visible = true; mp.AddChild(Square(Vector2.Zero, mp.Size, true)); }
        if (_packs?.Find(0x100001CA) is { } side)
        {
            side.Visible = true;
            // (seven places in the game; a server may allow more side packs - one more place, under the others, so the last can be reached)
            side.ClipContents = false;
            for (int i = 0; i < 8; i++)
            {
                side.AddChild(Square(new Vector2(0, i * 36), new Vector2(36, 34), false));
                // (a side pack's picture, when there's one in that place)
                var sp = new TextureRect { Position = new Vector2(2, i * 36 + 1), Size = new Vector2(32, 32), ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize,
                                           StretchMode = TextureRect.StretchModeEnum.KeepAspectCentered, MouseFilter = MouseFilterEnum.Stop, ZIndex = 2 };
                // a click opens that pack: its things in the grid (the main pack's square goes back to the main pack)
                int slot = i;
                sp.GuiInput += e =>
                {
                    // (a right click looks at the pack itself)
                    if (e is InputEventMouseButton { ButtonIndex: MouseButton.Right, Pressed: true } && Inv != null && slot < Inv.SidePacks.Count) { Identify?.Invoke(Inv.SidePacks[slot]); return; }
                    if (e is not InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true } || Inv == null || slot >= Inv.SidePacks.Count) return;
                    // the pack itself is chosen too (its name in the control bar; it can be used, looked at, handed over) -
                    // a focus as well: it holds nothing, so what opens is empty
                    PickWorn(Inv.SidePacks[slot]);
                    uint g = Inv.SidePacks[slot].Guid;
                    Inv.Viewing = Inv.Viewing == g ? 0 : g;
                    Refresh();
                };
                // dragged: the pack or focus itself, as a thing from the pack is (onto someone to give it, onto the ground)
                sp.SetDragForwarding(Callable.From((Vector2 at) =>
                {
                    if (Inv == null || slot >= Inv.SidePacks.Count) return default(Variant);
                    ItemSlot.Dragging = Inv.SidePacks[slot]; ItemSlot.DraggingFrom = "pack"; ItemSlot.SplitFrom = null;
                    var pic = new TextureRect { Texture = sp.Texture, Size = new Vector2(32, 32), ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize,
                                                StretchMode = TextureRect.StretchModeEnum.KeepAspectCentered, Modulate = new Color(1, 1, 1, 0.85f) };
                    var holder = new Control();
                    holder.AddChild(pic);
                    pic.Position = new Vector2(-16, -16);
                    holder.ZIndex = 1000; holder.ZAsRelative = false;   // (over everything: some squares sit a layer up)
                    sp.SetDragPreview(holder);
                    return (Variant)"acgodot-item";
                }), default, default);
                side.AddChild(sp);
                _sidePics.Add(sp);
                var full = new FullBar { Size = new Vector2(32, 32) };
                sp.AddChild(full);
                _sideFull.Add(full);
            }
        }
        // the main pack (it's the one open) in the pack column
        if (_packs?.Find(0x100001C9) is { } main)
        {
            var pic = new TextureRect { ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize, StretchMode = TextureRect.StretchModeEnum.KeepAspectCentered, MouseFilter = MouseFilterEnum.Stop };
            pic.GuiInput += e => { if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true } && Inv != null && Inv.Viewing != 0) { Inv.Viewing = 0; Refresh(); } };
            pic.SetAnchorsPreset(LayoutPreset.FullRect);
            pic.OffsetLeft = 2; pic.OffsetTop = 2; pic.OffsetRight = -2; pic.OffsetBottom = -2;
            pic.ZIndex = 2;
            main.AddChild(pic);
            _mainPackPic = pic;
            _mainFull = new FullBar();
            _mainFull.SetAnchorsPreset(LayoutPreset.FullRect);
            pic.AddChild(_mainFull);
        }
        LoadPlace();
        Lay();
        return true;
    }

    /// <summary>The pack whose square in the pack column a control is (0 the main pack), or null if it isn't one - for a thing dragged onto a pack.</summary>
    public uint? PackUnder(Control? c)
    {
        if (c == null || Inv == null) return null;
        if (c == _mainPackPic) return 0;
        int i = _sidePics.IndexOf(c as TextureRect ?? _mainPackPic!);
        return i >= 0 && i < Inv.SidePacks.Count && Inv.SidePacks[i].Capacity > 0 ? Inv.SidePacks[i].Guid : null;
    }

    /// <summary>The place in the side packs' column a control is (0 the first under the main pack), or -1 - for a pack dragged to another place.</summary>
    public int SideSlotUnder(Control? c) => c is TextureRect t ? _sidePics.IndexOf(t) : -1;

    // something being dragged over a pack's square: the square it would go to is outlined
    private Panel? _dropMark;
    private void MarkDropPack()
    {
        Control? over = null;
        if (Visible && Combat.ItemSlot.Dragging != null && GetViewport().GuiIsDragging())
        {
            var h = GetViewport().GuiGetHoveredControl();
            if (h != null && (h == _mainPackPic || (h is TextureRect t && _sidePics.Contains(t)))) over = h;
        }
        if (over == null) { if (_dropMark != null) _dropMark.Visible = false; return; }
        if (_dropMark == null)
        {
            _dropMark = new Panel { MouseFilter = MouseFilterEnum.Ignore, ZIndex = 3 };
            _dropMark.AddThemeStyleboxOverride("panel", new StyleBoxFlat { BgColor = new Color(1f, 0.9f, 0.4f, 0.12f), BorderColor = new Color(1f, 0.92f, 0.45f),
                                                                           BorderWidthLeft = 2, BorderWidthRight = 2, BorderWidthTop = 2, BorderWidthBottom = 2 });
        }
        if (_dropMark.GetParent() != over) { _dropMark.GetParent()?.RemoveChild(_dropMark); over.AddChild(_dropMark); }
        _dropMark.Position = new Vector2(-2, -2);
        _dropMark.Size = over.Size + new Vector2(4, 4);
        _dropMark.Visible = true;
    }

    // how full each pack is: a thin bar down the right of its square, filling from the bottom (as the game shows it)
    private sealed partial class FullBar : Control
    {
        public float Fraction = -1f;   // (below 0: no bar - an empty place, a focus)
        public FullBar() { MouseFilter = MouseFilterEnum.Ignore; ZIndex = 3; }
        public override void _Draw() { long __fw = ACGodot.FrameWatch.DrawStart(); try { DrawBody(); } finally { ACGodot.FrameWatch.Drew("FullBar", __fw); } }
        private void DrawBody()
        {
            if (Fraction < 0f) return;
            float w = 5f, x = Size.X - w - 1f, h = Size.Y - 2f;
            DrawRect(new Rect2(x, 1f, w, h), new Color(0.05f, 0.05f, 0.03f));
            float fill = MathF.Round((h - 2f) * Math.Clamp(Fraction, 0f, 1f));
            if (fill > 0f) DrawRect(new Rect2(x + 1f, 1f + (h - 1f) - fill, w - 2f, fill), new Color(0.85f, 0.78f, 0.1f));
            DrawRect(new Rect2(x, 1f, w, h), new Color(0.55f, 0.5f, 0.1f), false, 1f);
        }
    }
    private FullBar? _mainFull;
    private readonly List<FullBar> _sideFull = new();
    /// <summary>The control bar's bag picture (shut), for the main pack's square.</summary>
    public Func<Texture2D?>? MainPackIcon;
    private bool _mainFromBar;
    // a picture less its empty edges (clear or near-black round the thing drawn): the bag fills its square
    private static Texture2D Trimmed(Texture2D t)
    {
        try
        {
            var img = t.GetImage();
            if (img == null) return t;
            if (img.IsCompressed()) img.Decompress();
            int w = img.GetWidth(), h = img.GetHeight(), x0 = w, y0 = h, x1 = -1, y1 = -1;
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++)
                {
                    var c = img.GetPixel(x, y);
                    if (c.A < 0.3f || MathF.Max(c.R, MathF.Max(c.G, c.B)) < 0.2f) continue;
                    if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
                }
            if (x1 - x0 < 8 || y1 - y0 < 8 || (x0 == 0 && y0 == 0 && x1 == w - 1 && y1 == h - 1)) return t;
            return new AtlasTexture { Atlas = t, Region = new Rect2(x0, y0, x1 - x0 + 1, y1 - y0 + 1) };
        }
        catch { return t; }
    }

    private Control? _openArrow;
    private TextureRect? _mainPackPic;
    private readonly List<TextureRect> _sidePics = new();

    // the armor slots over the doll, or your character there (not both)
    private void ShowArmor(bool on)
    {
        foreach (var (n, _, armor) in _slots) if (armor) n.Visible = on;
        if (_figure != null) foreach (var c in _figure.GetChildren()) if (c is SubViewportContainer v) v.Visible = !on;
    }

    private static bool LoadFlag() { var c = new ConfigFile(); return global::ACGodot.SafeConfig.Load(c, "user://ui.cfg") == Error.Ok && (bool)c.GetValue("inventory", "armor_slots", false); }
    private static void SaveFlag(bool on) { var c = new ConfigFile(); global::ACGodot.SafeConfig.Load(c, "user://ui.cfg"); c.SetValue("inventory", "armor_slots", on); global::ACGodot.SafeConfig.Save(c, "user://ui.cfg"); }

    protected override void Resized2() { base.Resized2(); Lay(); }

    // laid out by hand as it grows: the doll stays top left, the pack column on the right edge, the contents fill the rest
    private void Lay()
    {
        if (Root == null) return;
        Vector2 s = Size;
        // the title tab: the whole top, up to the minimize (collapse) button, its words in the middle
        if (_title != null && _title.GetParent() == Root)
        {
            float right = s.X;
            foreach (var c in Root.GetChildren())
                if (c is UiNode n && n != _title && n.Visible && n.Position.Y < 20 && n.Size.X <= 30 && n.Position.X > s.X * 0.5f) right = Math.Min(right, n.Position.X);
            _title.Position = new Vector2(0, _title.Position.Y);
            _title.Resize(new Vector2(Math.Max(60, right - 2), _title.Size.Y));
            _title.CenterText();
        }
        if (_doll != null) _doll.Position = new Vector2(0, 23);
        if (_packs != null) { _packs.Position = new Vector2(s.X - 61, 23); _packs.Resize(new Vector2(61, Math.Max(339, s.Y - 23))); }
        if (_items != null)
        {
            _items.Position = new Vector2(0, 237);
            var size = new Vector2(Math.Max(234, s.X - 66), Math.Max(120, s.Y - 237 - 5));
            _items.Resize(size);
            if (_scroll != null && _gridNode != null)
            {
                _scroll.Position = new Vector2(_gridNode.Position.X, _gridNode.Position.Y);
                _scroll.Size = new Vector2(size.X - _gridNode.Position.X - 4, size.Y - _gridNode.Position.Y - 4);
                if (_grid != null) _grid.Columns = Math.Max(1, (int)((_scroll.Size.X - 12) / 34));
            }
        }
    }

    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("FullBar");
        MarkDropPack();
        if (!Visible || _cam == null || Player == null || !Player.Active) return;
        // the camera in front of you, looking at you (only your layer: the world isn't drawn)
        TagPlayer(Player);
        if (_view != null && _view.World3D != Player.GetViewport().World3D) _view.World3D = Player.GetViewport().World3D;
        // the body faces its own way (the camera can be anywhere): in front of it
        Node3D body = Player.GetNodeOrNull<Node3D>("Body") ?? Player;
        var fwd = -body.GlobalTransform.Basis.Z; fwd.Y = 0;
        if (fwd.LengthSquared() < 0.01f) fwd = Vector3.Forward;
        var at = Player.GlobalPosition + new Vector3(0, 0.95f, 0);
        _cam.GlobalPosition = at + fwd.Normalized() * 4.4f + new Vector3(0, 0.15f, 0);
        _cam.LookAt(at, Vector3.Up);
    }

    private static void TagPlayer(Node n)
    {
        foreach (var c in n.GetChildren())
        {
            if (c is VisualInstance3D v) v.Layers |= 1u << 19;
            TagPlayer(c);
        }
    }

    public override void Refresh()
    {
        if (!Visible || Inv == null) return;
        if (_view != null && Player != null) _view.World3D = Player.GetViewport().World3D;
        var me = Me?.Invoke();
        if (_title != null) _title.Text = $"Inventory of {me?.Name ?? "you"}";
        if (_sel != null && !Inv.Pack.Contains(_sel) && !Inv.Worn.Contains(_sel)) _sel = null;
        // what's worn, in its slots
        foreach (var (node, mask, _) in _slots)
        {
            var slot = node.GetChildren().OfType<DollSlot>().FirstOrDefault();
            if (slot == null) continue;
            bool armorSlot = _slots.Any(x => x.node == node && x.armor);
            // an armor slot shows what's on that part on the outer layer (armor, or a robe); the shirt and trousers
            // slots the under layer (clothing that doesn't reach the armor layer)
            var it = armorSlot
                ? Inv.Worn.FirstOrDefault(i => (Combat.Inventory.Outer(i, i.WornAt) & Creatures.CreatureAssets.BodyParts(mask)) != 0)
                : Inv.Worn.FirstOrDefault(i => (Item.Feet(i, i.WornAt) & mask) != 0 && ((mask & 0xFFFF) == 0 || (mask & 0x1E0000) != 0 || Combat.Inventory.Outer(i, i.WornAt) == 0));
            slot.Item = it;
            slot.Icon = it?.Picture(Icon);
            slot.TooltipText = it?.Name ?? SlotName(mask);
        }
        // the pack that's open: the main one, or a side pack clicked in the column (gone: back to the main one)
        var open = Inv.Viewing != 0 ? Inv.SidePacks.FirstOrDefault(p => p.Guid == Inv.Viewing) : null;
        if (open == null) Inv.Viewing = 0;
        var shown = Inv.Pack.Where(i => i.Holder == Inv.Viewing).ToList();
        int holds = open == null ? Combat.Inventory.PackSize : open.Capacity;
        _grid?.Fill(shown, Icon, Pick, _sel, Math.Max(0, holds - shown.Count));
        if (_itemsTitle != null) _itemsTitle.Text = $"{open?.Name ?? "Main Pack"}  {shown.Count}/{holds}";
        for (int i = 0; i < _sidePics.Count; i++) _sidePics[i].Modulate = i < Inv.SidePacks.Count && Inv.SidePacks[i].Guid == Inv.Viewing && open != null ? new Color(1f, 0.9f, 0.5f) : Colors.White;
        // the game's yellow arrow on the pack that's open (the main one, or the side pack)
        Control? openPic = open == null ? _mainPackPic : _sidePics.ElementAtOrDefault(Inv.SidePacks.IndexOf(open));
        if (openPic != null)
        {
            if (_openArrow == null)
            {
                _openArrow = new Control { MouseFilter = MouseFilterEnum.Ignore, ZIndex = 4, Size = new Vector2(13, 22) };
                var arrow = _openArrow;
                arrow.Draw += () =>
                {
                    var pts = new[] { new Vector2(0, 0), new Vector2(13, 11), new Vector2(0, 22) };
                    arrow.DrawColoredPolygon(pts, new Color(1f, 0.78f, 0.1f));
                    arrow.DrawPolyline(new[] { pts[0], pts[1], pts[2], pts[0] }, new Color(0.45f, 0.3f, 0f), 1f);
                };
            }
            if (_openArrow.GetParent() != openPic) { _openArrow.GetParent()?.RemoveChild(_openArrow); openPic.AddChild(_openArrow); }
            _openArrow.Position = new Vector2(-3, (openPic.Size.Y - 22) * 0.5f);
        }
        if (_mainFull != null) { _mainFull.Fraction = Inv.Pack.Count(i => i.Holder == 0) / (float)Math.Max(1, Combat.Inventory.PackSize); _mainFull.QueueRedraw(); }
        for (int i = 0; i < _sideFull.Count; i++)
        {
            var sp = i < Inv.SidePacks.Count ? Inv.SidePacks[i] : null;
            _sideFull[i].Fraction = sp != null && sp.Capacity > 0 ? Inv.Pack.Count(x => x.Holder == sp.Guid) / (float)sp.Capacity : -1f;
            _sideFull[i].QueueRedraw();
        }
        // burden: how full you are (150 per point of strength)
        int cap = Math.Max(1, (me?.Attribute(0) ?? 100) * 150);
        float frac = Inv.TotalBurden / (float)cap;
        if (_burdenMeter != null) _burdenMeter.Fraction = Math.Min(1f, frac / 3f);
        if (_burdenText != null) _burdenText.Text = $"{(int)(frac * 100)}%";
        if (_burdenText2 != null) _burdenText2.Text = "";
        // the main pack's picture: the game's backpack (the Pack thing's own icon)
        // the main pack's picture: the control bar's bag, shut (the game's own); till that's there, a pack's icon
        if (_mainPackPic != null && !_mainFromBar)
        {
            if (MainPackIcon?.Invoke() is { } bag) { _mainPackPic.Texture = Trimmed(bag); _mainFromBar = true; }
            else if (_mainPackPic.Texture == null)
                _mainPackPic.Texture = Icon(Inv.Data?.Get(136) is { Icon: > 0 } pack ? pack.Icon : Inv.SidePacks.FirstOrDefault(p => p.Name == "Pack" && p.Icon != 0)?.Icon ?? 0x06001BAFu);
        }
        for (int i = 0; i < _sidePics.Count; i++)
        {
            var sp = i < Inv.SidePacks.Count ? Inv.SidePacks[i] : null;
            _sidePics[i].Texture = sp != null && sp.Icon != 0 ? Icon(sp.Icon) : null;
            _sidePics[i].TooltipText = sp?.Name ?? "";
        }
    }

    // (a click on the item already chosen leaves it chosen - it used to let go of it)
    internal void Pick(Item i) { _sel = i; Picked?.Invoke(_sel); Refresh(); }
    /// <summary>What's selected, as the game has it (something chosen elsewhere: this one's highlight goes).</summary>
    public void ShowPicked(Item? it) { if (_sel != it) { _sel = it; if (Visible) Refresh(); } }

    internal void PickWorn(Item i) { if (_sel != i) { _sel = i; Picked?.Invoke(i); } }

    /// <summary>An item clicked in the pack (its name goes in the control bar), or none.</summary>
    public Action<Item?>? Picked;

    /// <summary>Double-click: wear or wield it, or take it off.</summary>
    /// <summary>A double click on something that isn't worn or wielded: it's used.</summary>
    public Action<Item>? UseItem;
    public void Use(Item s)
    {
        if (Inv.Worn.Contains(s)) Said?.Invoke(Inv.Unequip(s));
        else if (s.Wearable) Said?.Invoke(Inv.Equip(s));
        else { UseItem?.Invoke(s); return; }   // (not something worn: used - eaten, read, or used on something)
        Equipped?.Invoke();
        Refresh();
    }

    /// <summary>A one-handed weapon dropped on the off hand: dual wielding.</summary>
    internal void OffHandDropped(Item it)
    {
        if (Inv.Worn.Contains(it)) { Inv.Unequip(it); }
        Said?.Invoke(Inv.EquipOffHand(it));
        Equipped?.Invoke();
        Refresh();
    }

    /// <summary>Dropped on a slot of the doll: worn there.</summary>
    internal void WearDropped(Item it)
    {
        if (Inv.Worn.Contains(it) || !it.Wearable) return;
        Said?.Invoke(Inv.Equip(it));
        Equipped?.Invoke();
        Refresh();
    }

    /// <summary>Takes an item out of a corpse or chest into the pack (Main: the loot window's take). True if taken.</summary>
    public Func<Item, uint, int, bool>? TakeFromCorpse;
    /// <summary>A thing from a corpse or chest dropped on a stack of the same thing in the pack: put onto that stack.</summary>
    public Action<Item, Item>? MergeFromCorpse;

    /// <summary>
    /// Something dropped in the pack: it goes where it was dropped (the others move along), or onto a stack of the
    /// same thing (the stack fills, the rest sits just left of it).
    /// </summary>
    internal void DroppedInPack(Item it, string from, int index, Item? onto)
    {
        if (from == "worn" && Inv.Worn.Contains(it)) { Said?.Invoke(Inv.Unequip(it)); Equipped?.Invoke(); }
        else if (from == "corpse" && !Inv.Pack.Contains(it))
        {
            // (into the pack that's open, at the square it was dropped on - the server's place in that pack)
            int count = Inv.Pack.Count(i => i.Holder == Inv.Viewing);
            // (dropped on a stack of the same thing: put onto it)
            if (onto != null && onto.Guid != 0 && Combat.Inventory.Stackable(it, onto) && MergeFromCorpse != null) { MergeFromCorpse(it, onto); return; }
            int place = onto != null ? Math.Max(0, Inv.Pack.Where(i => i.Holder == Inv.Viewing).ToList().IndexOf(onto)) : Math.Clamp(index, 0, count);
            if (TakeFromCorpse?.Invoke(it, Inv.Viewing, place) != true) return;
        }
        if (!Inv.Pack.Contains(it)) return;
        if (onto != null && onto != it && Combat.Inventory.Stackable(it, onto) && Inv.Pack.Contains(onto)) Inv.StackOnto(it, onto);
        else
        {
            // (the place dropped on is a place in the pack that's open: the same place among everything carried)
            var open = Inv.Pack.Where(i => i.Holder == Inv.Viewing && i != it).ToList();
            int at = onto != null && Inv.Pack.Contains(onto) ? Inv.Pack.IndexOf(onto)
                   : index >= 0 && index < open.Count ? Inv.Pack.IndexOf(open[index]) : Inv.Pack.Count;
            Inv.Place(it, at);
        }
        Refresh();
    }

    /// <summary>Dropped in the pack: taken off (if worn).</summary>
    internal void PackDropped(Item it)
    {
        if (!Inv.Worn.Contains(it)) return;
        Said?.Invoke(Inv.Unequip(it));
        Equipped?.Invoke();
        Refresh();
    }

    /// <summary>A slot on the paperdoll: shows what's worn there; takes items dropped on it; dragged, takes it off.</summary>
    public partial class DollSlot : ItemSlot
    {
        public InventoryPanel Panel = null!;
        public int Mask;

        public DollSlot()
        {
            Source = "worn";
            // every slot shows, empty or not: a dark square with a thin frame
            var sq = new StyleBoxFlat { BgColor = new Color(0f, 0f, 0f, 0.5f), BorderColor = new Color(0.45f, 0.36f, 0.18f, 0.9f),
                                        BorderWidthLeft = 1, BorderWidthRight = 1, BorderWidthTop = 1, BorderWidthBottom = 1 };
            var hi = (StyleBoxFlat)sq.Duplicate(); hi.BorderColor = new Color(1f, 0.85f, 0.4f);
            // an empty slot's name, small and faint
            AddThemeColorOverride("font_color", new Color(0.6f, 0.55f, 0.45f, 0.75f));
            AddThemeColorOverride("font_hover_color", new Color(0.8f, 0.75f, 0.6f));
            AddThemeFontSizeOverride("font_size", RetailTheme.Px(9));
            ClipText = true;
            AddThemeStyleboxOverride("normal", sq);
            AddThemeStyleboxOverride("hover", hi);
            AddThemeStyleboxOverride("pressed", sq);
            AddThemeStyleboxOverride("focus", new StyleBoxEmpty());
        }

        public override void _GuiInput(InputEvent e)
        {
            if (Item == null) return;
            if (e is InputEventMouseButton { ButtonIndex: MouseButton.Right, Pressed: true }) { Panel.Identify?.Invoke(Item); AcceptEvent(); }
            else if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, DoubleClick: true }) { Panel.Use(Item); AcceptEvent(); }
            // a click on something worn or wielded selects it, as one on a thing in the pack does
            else if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true }) Panel.PickWorn(Item);
        }

        // takes what can be worn here - and the off hand (the shield's place) takes a second one-handed weapon too
        public override bool _CanDropData(Vector2 at, Variant data) =>
            data.VariantType == Variant.Type.String && (string)data == "acgodot-item" && ItemSlot.Dragging is { } it
            && ((it.Locations & Mask) != 0 || (Mask == Item.SlotShield && Panel.Inv.CanOffHand(it)));

        public override void _DropData(Vector2 at, Variant data)
        {
            if (ItemSlot.Dragging is { } it)
            {
                if (Mask == Item.SlotShield && it.IsMeleeWeapon) Panel.OffHandDropped(it);
                else Panel.WearDropped(it);
            }
            ItemSlot.Dragging = null;
        }
    }

    /// <summary>The pack's squares: worn items dropped here come off.</summary>
    public partial class PackGrid : ItemGrid
    {
        public InventoryPanel Panel = null!;
        public PackGrid() : base(6) { }
        // anything dragged in: from the pack (moved), what's worn (taken off), a corpse or chest (taken)
        public override bool CanTake(Item? onto) => ItemSlot.Dragging != null;
        public override void TakeDrop(int index, Item? onto) { if (ItemSlot.Dragging is { } it) Panel.DroppedInPack(it, ItemSlot.DraggingFrom, index, onto); ItemSlot.Dragging = null; }
    }
}

/// <summary>
/// The game's character panel (layout 0x2100002E): Attributes, Skills and Titles tabs, laid out as the game has them -
/// who you are and your level at the top, the list (a click chooses a row), and at the bottom what's chosen, what
/// raising it costs and the buttons to raise it.
/// </summary>
public partial class CharacterPanel : SidePanel
{
    public const uint Layout = 0x2100002E;
    public Func<Character?>? Me;
    public Action? Changed;
    public Func<uint, Texture2D?> Icon = _ => null;
    private VBoxContainer? _attr, _skills, _titles, _attrFoot, _skillFoot;
    /// <summary>On a server: the titles earned (their numbers) and the one shown; a title's name; showing one.</summary>
    public Func<(uint shown, IReadOnlyList<uint> all)?>? Titles;
    public Func<uint, string>? TitleName;
    public Action<uint>? UseTitle;
    private uint _pickedTitle;
    private string _titlesShown = "";
    private Button? _useTitle;
    private List<UiNode> _pages = new();
    private int _pickedAttr = -1, _pickedSkill = -1;   // attributes 0-5, vitals 6-8

    public bool Setup()
    {
        if (!BuildPanel(CharacterInfo, Layout, 0x10000227)) return false;
        var r = Root!;
        CloseFrom(r.Find(0x1000022A));
        Closed = () => Shown?.Invoke(this, false);
        var (tabs, pages, _) = TabsFrom(r);
        _pages = pages; Pages = pages; TabNodes = tabs;
        if (tabs.Count > 0) TitleFrom(null);
        // the tab strip drags it (the tabs choose)
        if (pages.Count > 0) (_attr, _attrFoot) = ContentWithFootBox(pages[0], 62f);
        if (pages.Count > 1) (_skills, _skillFoot) = ContentWithFootBox(pages[1], 62f);
        if (pages.Count > 2)
        {
            _titles = ContentOver(pages[2]);
            _titles.AddThemeConstantOverride("separation", 0);
            // (the list scrolls; under it, the button that shows the title chosen)
            if (_titles.GetParent() is ScrollContainer ts) ts.OffsetBottom = -34f;
            _useTitle = new Button { Text = "Use Selected", FocusMode = FocusModeEnum.None, ZIndex = 2, Disabled = true,
                                     AnchorLeft = 0, AnchorRight = 1, AnchorTop = 1, AnchorBottom = 1, OffsetLeft = 6, OffsetRight = -6, OffsetTop = -30, OffsetBottom = -4,
                                     TooltipText = "Shows the title chosen in the list under your name." };
            if (RetailTheme.Current != null) _useTitle.Theme = RetailTheme.Current;
            _useTitle.Pressed += () => { if (_pickedTitle != 0) { UseTitle?.Invoke(_pickedTitle); _titlesShown = ""; Refresh(); } };
            pages[2].AddChild(_useTitle);
        }
        DragAnywhere = true;
        LoadPlace();
        Resized2();
        return true;
    }

    // who you are, and your level in its box at the right
    private Control Header(Character c)
    {
        var row = new HBoxContainer();
        var left = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        left.AddThemeConstantOverride("separation", 0);
        left.AddChild(Line(c.Name, RetailTheme.Gold, HorizontalAlignment.Center));
        left.AddChild(Line(c.Heritage, null, HorizontalAlignment.Center));
        left.AddChild(Pair("Total Experience (XP):", Xp(c.TotalXp)));
        long next = c.NextLevelXp;
        left.AddChild(Pair("XP for next level:", next > 0 ? Xp(Math.Max(0, next - c.TotalXp)) : "-"));
        row.AddChild(left);
        var box = new PanelContainer { CustomMinimumSize = new Vector2(64, 0) };
        box.AddThemeStyleboxOverride("panel", new StyleBoxFlat { BgColor = new Color(0f, 0f, 0f, 0.5f), BorderColor = new Color(0.45f, 0.36f, 0.16f),
                                                                 BorderWidthLeft = 1, BorderWidthRight = 1, BorderWidthTop = 1, BorderWidthBottom = 1 });
        var lv = new VBoxContainer();
        lv.AddThemeConstantOverride("separation", 0);
        var cl = Line("Character\nLevel", null, HorizontalAlignment.Center);
        cl.AutowrapMode = TextServer.AutowrapMode.Off;
        lv.AddChild(cl);
        var big = Line(c.Level.ToString(), RetailTheme.Gold, HorizontalAlignment.Center);
        big.AddThemeFontSizeOverride("font_size", RetailTheme.Px(22));
        lv.AddChild(big);
        box.AddChild(lv);
        row.AddChild(box);
        return row;
    }

    /// <summary>Experience as shown: in full up to a billion, then shortened (4.3T, 1.2Qa... on to sextillions).</summary>
    public static string Xp(double xp)
    {
        if (xp < 1e9) return xp.ToString("N0");
        string[] units = { "B", "T", "Qa", "Qi", "Sx", "Sp" };
        int u = 0; xp /= 1e9;
        while (xp >= 1000 && u < units.Length - 1) { xp /= 1000; u++; }
        return (xp >= 100 ? xp.ToString("0") : xp >= 10 ? xp.ToString("0.#") : xp.ToString("0.##")) + units[u];
    }

    private static HBoxContainer Pair(string label, string value, Color? valueColor = null)
    {
        var row = new HBoxContainer();
        var l = Line(label); l.AutowrapMode = TextServer.AutowrapMode.Off;
        row.AddChild(l);
        var v = Line(value, valueColor, HorizontalAlignment.Right); v.AutowrapMode = TextServer.AutowrapMode.Off; v.SizeFlagsHorizontal = SizeFlags.ShrinkEnd;
        row.AddChild(v);
        return row;
    }

    // a row of the list: its icon (skills have one), its name, its value in green at the right; a click chooses it
    private Control StatRow(uint icon, string name, string value, bool picked, Action pick, string tip)
    {
        var row = new HBoxContainer { MouseFilter = MouseFilterEnum.Stop, TooltipText = tip, CustomMinimumSize = new Vector2(0, 18) };
        row.AddThemeConstantOverride("separation", 4);
        row.AddChild(new TextureRect { Texture = icon != 0 ? Icon(icon) : null, CustomMinimumSize = new Vector2(16, 16), ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize,
                                       StretchMode = TextureRect.StretchModeEnum.KeepAspectCentered, MouseFilter = MouseFilterEnum.Ignore });
        var n = Line(name, picked ? RetailTheme.Gold : null); n.MouseFilter = MouseFilterEnum.Ignore; n.AutowrapMode = TextServer.AutowrapMode.Off; n.ClipText = true;
        row.AddChild(n);
        var v = Line(value, new Color(0.3f, 1f, 0.3f), HorizontalAlignment.Right);
        v.MouseFilter = MouseFilterEnum.Ignore; v.AutowrapMode = TextServer.AutowrapMode.Off; v.SizeFlagsHorizontal = SizeFlags.ShrinkEnd;
        row.AddChild(v);
        row.AddChild(new Control { CustomMinimumSize = new Vector2(4, 0), MouseFilter = MouseFilterEnum.Ignore });
        row.GuiInput += e => { if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true }) pick(); };
        return row;
    }

    private static Label Bar(string text)
    {
        var l = Head(text);
        var bg = new StyleBoxFlat { BgColor = new Color(0.1f, 0.12f, 0.3f, 0.75f) };
        l.AddThemeStyleboxOverride("normal", bg);
        return l;
    }

    // the bottom box: what's chosen and what raising it costs, with the buttons; nothing chosen, what to do
    private void Foot(VBoxContainer? foot, Character c, string what, string? chosen, string value, int ranks, long cost, Func<bool>? raise, string? trainLabel = null, Func<bool>? train = null)
    {
        if (foot == null) return;
        Clear(foot);
        if (chosen == null)
        {
            foot.AddChild(Line($"Select {what} to Improve", null, HorizontalAlignment.Center));
            if (what.Contains("Skill")) foot.AddChild(Pair("Skill Credits Available:", c.SkillCredits.ToString()));
            foot.AddChild(Pair("Unassigned Experience:", Xp(c.UnassignedXp)));
            return;
        }
        var top = new HBoxContainer();
        var t = Line($"{chosen}: {value}" + (ranks > 0 ? $" (+{ranks})" : ""), RetailTheme.Gold, HorizontalAlignment.Center);
        t.AutowrapMode = TextServer.AutowrapMode.Off;
        top.AddChild(t);
        if (train != null)
        {
            var tb = Btn(trainLabel ?? "Train", () => { if (train()) Done(); }, true);
            top.AddChild(tb);
        }
        else if (raise != null)
        {
            bool can = cost >= 0 && cost <= c.UnassignedXp;
            var one = Btn("+1", () => { if (raise()) Done(); }, can); one.TooltipText = "Raise it once";
            var ten = Btn("+10", () => { bool any = false; for (int i = 0; i < 10 && raise(); i++) any = true; if (any) Done(); }, can); ten.TooltipText = "Raise it ten times";
            top.AddChild(one); top.AddChild(ten);
        }
        foot.AddChild(top);
        foot.AddChild(Pair("Experience To Raise:", train != null ? "-" : cost >= 0 ? Xp(cost) : "Infinity!"));
        foot.AddChild(Pair("Unassigned Experience:", Xp(c.UnassignedXp)));
    }

    public override void Refresh()
    {
        var c = Me?.Invoke();
        if (!Visible || c == null) return;
        if (_attr != null)
        {
            Clear(_attr);
            _attr.AddChild(Header(c));
            _attr.AddChild(new HSeparator());
            for (int i = 0; i < 6; i++)
            {
                int a = i;
                _attr.AddChild(StatRow(0, Character.AttributeNames[a], c.Attribute(a).ToString(), _pickedAttr == a, () => { _pickedAttr = a; Refresh(); }, Character.AttributeNames[a]));
            }
            int[] now = { c.Health, c.Stamina, c.Mana };
            for (int v = 0; v < 3; v++)
            {
                int vi = v;
                _attr.AddChild(StatRow(0, Character.VitalNames[vi], $"{now[vi]}/{c.MaxVital(vi)}", _pickedAttr == 6 + vi, () => { _pickedAttr = 6 + vi; Refresh(); }, Character.VitalNames[vi]));
            }
            if (_pickedAttr >= 0 && _pickedAttr < 6)
            {
                int a = _pickedAttr;
                Foot(_attrFoot, c, "an Attribute", Character.AttributeNames[a], c.Attribute(a).ToString(), c.AttributeRanks[a], c.AttributeCost(a), () => c.RaiseAttribute(a));
            }
            else if (_pickedAttr >= 6)
            {
                int v = _pickedAttr - 6;
                Foot(_attrFoot, c, "an Attribute", Character.VitalNames[v], c.MaxVital(v).ToString(), c.VitalRanks[v], c.VitalCost(v), () => c.RaiseVital(v));
            }
            else Foot(_attrFoot, c, "an Attribute", null, "", 0, -1, null);
        }
        if (_skills != null)
        {
            Clear(_skills);
            _skills.AddChild(Header(c));
            bool found = false;
            foreach (var (label, training) in new[] { ("Specialized Skills", Character.Training.Specialized), ("Trained Skills", Character.Training.Trained), ("Untrained Skills", Character.Training.Untrained) })
            {
                var list = c.AllSkills().Where(s => c.TrainingOf(s.id) == training).ToList();
                if (list.Count == 0) continue;
                _skills.AddChild(Bar(label));
                foreach (var (id, name) in list)
                {
                    int sid = id;
                    // its tooltip: how it's worked out (which attributes to raise to help it)
                    _skills.AddChild(StatRow(c.SkillIcon(sid), name, c.Skill(sid).ToString(), _pickedSkill == sid, () => { _pickedSkill = sid; Refresh(); }, name + "\n" + c.SkillBreakdown(sid)));
                    if (sid != _pickedSkill) continue;
                    found = true;
                    int ranks = c.Skills.TryGetValue(sid, out var st) ? st.Ranks : 0;
                    if (training == Character.Training.Untrained)
                    {
                        int tc = c.TrainCost(sid);
                        Foot(_skillFoot, c, "a Skill", name, c.Skill(sid).ToString(), 0, -1, null, tc >= 0 ? $"Train ({tc})" : "Can't train", tc >= 0 && tc <= c.SkillCredits ? () => c.TrainSkill(sid) : null);
                    }
                    else Foot(_skillFoot, c, "a Skill", name, c.Skill(sid).ToString(), ranks, c.SkillCost(sid), () => c.RaiseSkill(sid));
                }
            }
            if (!found) Foot(_skillFoot, c, "a Skill", null, "", 0, -1, null);
        }
        if (_titles != null)
        {
            var have = Titles?.Invoke();
            uint shown = have?.shown ?? 1;
            var all = have?.all ?? new List<uint> { 1 };
            string Name(uint t) => TitleName?.Invoke(t) is { Length: > 0 } n ? n : t == 1 ? "Adventurer" : $"Title {t}";
            // (built again only when what it shows has changed: it keeps its place in the list)
            string sig = $"{shown}|{_pickedTitle}|{all.Count}|{(all.Count > 0 ? all[^1] : 0)}";
            if (sig != _titlesShown)
            {
                _titlesShown = sig;
                Clear(_titles);
                _titles.AddChild(Line("Current Display Title:"));
                _titles.AddChild(Line(Name(shown), RetailTheme.Gold, HorizontalAlignment.Center));
                _titles.AddChild(Line(""));
                _titles.AddChild(Line($"All Available Titles ({all.Count}):"));
                foreach (uint t in all.Distinct().OrderBy(Name, StringComparer.OrdinalIgnoreCase))
                {
                    uint id = t;
                    var row = new Button { Text = Name(t), Flat = true, Alignment = HorizontalAlignment.Left, FocusMode = FocusModeEnum.None,
                                           SizeFlagsHorizontal = SizeFlags.ExpandFill, ClipText = true };
                    row.AddThemeColorOverride("font_color", id == _pickedTitle ? Colors.White : id == shown ? RetailTheme.Gold : RetailTheme.Ink);
                    if (id == _pickedTitle) row.AddThemeStyleboxOverride("normal", new StyleBoxFlat { BgColor = new Color(0.25f, 0.2f, 0.08f, 0.9f) });
                    row.Pressed += () => { _pickedTitle = id; Refresh(); };
                    _titles.AddChild(row);
                }
                if (_useTitle != null) _useTitle.Disabled = _pickedTitle == 0 || _pickedTitle == shown || UseTitle == null;
            }
        }
    }

    private void Done() { Changed?.Invoke(); Refresh(); }
}

/// <summary>The game's spellbook panel (layout 0x21000034): Spellbook and Components tabs. Spells are filtered by school; drag one onto the spell bar or shortcut bar, double-click to cast.</summary>
public partial class SpellbookPanel : SidePanel
{
    public const uint Layout = 0x21000034;
    public Magic.MagicSystem? Magic;
    public Func<uint, Texture2D?> Icon = _ => null;
    public Action<Magic.Spell>? Identify;
    private VBoxContainer? _book, _comps;
    private DatReaderWriter.Enums.MagicSchool? _school;
    private int _level;   // the spell level shown (0: all)
    private double _refreshIn;
    private Action<int> _chooseTab = _ => { };
    /// <summary>The Components tab: opened on it, or (open already) shut.</summary>
    public void ToggleComponents() { if (Visible) Toggle(); else { Open(); _chooseTab(1); } }

    public bool Setup()
    {
        if (!BuildPanel(Spellbook, Layout, 0x100002A8)) return false;
        var r = Root!;
        CloseFrom(r.Find(0x100002AB));
        Closed = () => Shown?.Invoke(this, false);
        var (tabs, pages, chooseTab) = TabsFrom(r);
        _chooseTab = chooseTab;
        Pages = pages; TabNodes = tabs;
        if (pages.Count > 0) (_book, _bookFoot) = ContentWithFoot(pages[0]);
        if (pages.Count > 0 && _book != null)
        {
            // the choices of school and level: fixed over the list (they don't scroll away with it)
            _bookHead = new VBoxContainer { ZIndex = 2, AnchorLeft = 0, AnchorRight = 1, AnchorTop = 0, AnchorBottom = 0, OffsetLeft = 4, OffsetRight = -4, OffsetTop = 2, MouseFilter = MouseFilterEnum.Pass };
            _bookHead.AddThemeConstantOverride("separation", 0);
            if (RetailTheme.Current != null) _bookHead.Theme = RetailTheme.Current;
            pages[0].AddChild(_bookHead);
        }
        if (pages.Count > 1) _comps = ContentOver(pages[1]);
        DragAnywhere = true;
        LoadPlace();
        Resized2();
        return true;
    }

    private Label? _bookFoot;
    private VBoxContainer? _bookHead;
    private string _headShown = "";
    private Magic.Spell? _pickedSpell;
    private string _bookShown = "";

    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("SpellbookPanel");
        if (Visible && (_refreshIn -= delta) <= 0) { _refreshIn = 2; Refresh(); }
        if (Visible && _bookHead != null && _book?.GetParent() is ScrollContainer sc)
        {
            float top = _bookHead.OffsetTop + Math.Max(_bookHead.Size.Y, _bookHead.GetCombinedMinimumSize().Y) + 4f;
            if (MathF.Abs(sc.OffsetTop - top) > 0.5f) sc.OffsetTop = top;
        }
    }

    public override void Refresh()
    {
        if (!Visible || Magic == null || _book == null) return;
        var known = Magic.Known().Where(s => (_school == null || s.School == _school) && (_level == 0 || s.Level == _level)).OrderBy(s => s.Name).ToList();
        if (_bookFoot != null) _bookFoot.Text = _pickedSpell != null ? _pickedSpell.Description : "SELECT A SPELL";
        // (only rebuilt when the list or the choice changes: a row being dragged from isn't pulled away)
        string shown = $"{_school}|{_level}|{_pickedSpell?.Id}|" + string.Join(",", known.Select(k => k.Id));
        if (shown == _bookShown && _book.GetChildCount() > 0) { FillComponents(); return; }
        _bookShown = shown;
        Clear(_book);
        FillBookHead();
        foreach (var sp in known)
        {
            var spell = sp;
            // the icon drags onto the spell bar or shortcut bar; the row: a click chooses it (its description below),
            // a double click casts it, a right click identifies it
            var icon = new Magic.SpellIcon { Texture = Icon(sp.Icon), ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize,
                                             StretchMode = TextureRect.StretchModeEnum.KeepAspectCentered, Entry = new ShortcutBar.Entry("spell", sp.Id, sp.Name, sp.Icon),
                                             MouseFilter = MouseFilterEnum.Stop, MouseDefaultCursorShape = CursorShape.Drag, TooltipText = "Drag onto the spell bar" };
            icon.GuiInput += e =>
            {
                if (e is InputEventMouseButton { ButtonIndex: MouseButton.Right, Pressed: true }) Identify?.Invoke(spell);
                // (picked as the button comes up: a press may be the start of dragging it to the spell bar)
                else if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: false } && _pickedSpell != spell) { _pickedSpell = spell; Refresh(); }
            };
            var (row, inside) = SpellRow(icon, sp.Name, "", sp == _pickedSpell);
            inside.MouseFilter = MouseFilterEnum.Pass;
            row.GuiInput += e =>
            {
                if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, DoubleClick: true }) Magic.Cast(spell.Id);
                else if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true }) { _pickedSpell = spell; Refresh(); }
                else if (e is InputEventMouseButton { ButtonIndex: MouseButton.Right, Pressed: true }) Identify?.Invoke(spell);
            };
            _book.AddChild(row);
        }
        if (known.Count == 0)
            _book.AddChild(Line(_school == null && _level == 0 ? "You don't know any spells." : "You don't know any spells of this kind.", RetailTheme.Dim, HorizontalAlignment.Center));
        FillComponents();
    }

    // one of the choices: its name in a small box - gold and lit when it's the one chosen (a click chooses it)
    private static Control Choice(string text, bool on, Action pick)
    {
        var box = new PanelContainer { MouseFilter = MouseFilterEnum.Stop, MouseDefaultCursorShape = CursorShape.PointingHand };
        box.AddThemeStyleboxOverride("panel", new StyleBoxFlat
        {
            BgColor = on ? new Color(0.28f, 0.2f, 0.06f, 0.9f) : new Color(0f, 0f, 0f, 0.45f), BorderColor = on ? RetailTheme.Gold : new Color(0.4f, 0.32f, 0.15f),
            BorderWidthLeft = 1, BorderWidthRight = 1, BorderWidthTop = 1, BorderWidthBottom = 1, ContentMarginLeft = 6, ContentMarginRight = 6, ContentMarginTop = 1, ContentMarginBottom = 1,
        });
        var l = new Label { Text = text, MouseFilter = MouseFilterEnum.Ignore, HorizontalAlignment = HorizontalAlignment.Center, AutowrapMode = TextServer.AutowrapMode.Off };
        l.AddThemeColorOverride("font_color", on ? RetailTheme.Gold : RetailTheme.Ink);
        box.AddChild(l);
        box.GuiInput += e => { if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true }) { box.AcceptEvent(); pick(); } };
        return box;
    }

    // the spellbook's choices: the schools (wrapped to the panel's width), then the levels in two rows
    private void FillBookHead()
    {
        var head = _bookHead ?? _book;
        if (head == null) return;
        if (head == _bookHead)
        {
            string want = $"{_school}|{_level}";
            if (want == _headShown && head.GetChildCount() > 0) return;
            _headShown = want;
            Clear(head);
        }
        var schools = new HFlowContainer();
        schools.AddThemeConstantOverride("h_separation", 4); schools.AddThemeConstantOverride("v_separation", 0);
        foreach (var (sc, name) in new (DatReaderWriter.Enums.MagicSchool?, string)[] { (null, "All"), (DatReaderWriter.Enums.MagicSchool.CreatureEnchantment, "Creature"), (DatReaderWriter.Enums.MagicSchool.ItemEnchantment, "Item"),
                                                                                       (DatReaderWriter.Enums.MagicSchool.LifeMagic, "Life"), (DatReaderWriter.Enums.MagicSchool.WarMagic, "War"), (DatReaderWriter.Enums.MagicSchool.VoidMagic, "Void") })
        {
            var s = sc;
            schools.AddChild(Choice(name, _school == s, () => { _school = s; Refresh(); }));
        }
        head.AddChild(schools);
        string[] roman = { "All", "I", "II", "III", "IV", "V", "VI", "VII", "VIII" };
        foreach (var (from, to) in new[] { (0, 4), (5, 8) })
        {
            var levels = new HBoxContainer();
            levels.AddThemeConstantOverride("separation", 4);
            for (int lv = from; lv <= to; lv++)
            {
                int l = lv;
                levels.AddChild(Choice(roman[lv], _level == l, () => { _level = l; Refresh(); }));
            }
            head.AddChild(levels);
        }
    }

    // ── Components: the spell components in your packs - how many you have, and how many you want to keep (what
    //    /fillcomps works from) ──
    public Combat.Inventory? Inv;
    private string _compsShown = "";

    /// <summary>How many of each component (by its kind's number) you want to keep on you.</summary>
    public static Dictionary<int, int> Wanted()
    {
        var want = new Dictionary<int, int>();
        var c = new ConfigFile();
        if (global::ACGodot.SafeConfig.Load(c, "user://ui.cfg") != Error.Ok || !c.HasSection("fillcomps")) return want;
        foreach (string k in c.GetSectionKeys("fillcomps")) if (int.TryParse(k, out int id)) want[id] = (int)c.GetValue("fillcomps", k, 0);
        return want;
    }

    public static void SetWanted(int wcid, int count)
    {
        var c = new ConfigFile();
        global::ACGodot.SafeConfig.Load(c, "user://ui.cfg");
        c.SetValue("fillcomps", wcid.ToString(), count);
        global::ACGodot.SafeConfig.Save(c, "user://ui.cfg");
    }

    /// <summary>The components in your packs: each kind's number, name, icon and how many.</summary>
    public static List<(int wcid, string name, uint icon, int have)> ComponentsHeld(Combat.Inventory? inv)
    {
        var list = new List<(int, string, uint, int)>();
        if (inv == null) return list;
        foreach (var g in inv.Pack.Where(i => (i.ItemType & 0x1000) != 0).GroupBy(i => i.Wcid))
            list.Add((g.Key, g.First().Name, g.First().Icon, g.Sum(i => Math.Max(1, i.Stack))));
        return list.OrderBy(e => e.Item2).ToList();
    }

    private static readonly string[] ComponentGroups = { "SCARABS", "HERBS", "POWDERED GEMS", "ALCHEMICAL SUBSTANCES", "TALISMANS", "TAPERS", "PEAS", "OTHER" };
    private static readonly HashSet<string> Herbs = new(StringComparer.OrdinalIgnoreCase)
        { "Amaranth", "Bistort", "Comfrey", "Damiana", "Dragonsblood", "Eyebright", "Frankincense", "Ginseng", "Hawthorn", "Henbane", "Hyssop", "Mandrake", "Mugwort", "Myrrh", "Saffron", "Vervain", "Wormwood", "Yarrow" };
    private static readonly HashSet<string> Substances = new(StringComparer.OrdinalIgnoreCase)
        { "Brimstone", "Cadmia", "Cinnabar", "Cobalt", "Colcothar", "Gypsum", "Quicksilver", "Realgar", "Stibnite", "Turpeth", "Verdigris", "Vitriol" };

    // the heading a component goes under, as the game sorts them
    private static string ComponentGroup(string name) =>
        name.EndsWith("Scarab", StringComparison.OrdinalIgnoreCase) ? "SCARABS" :
        Herbs.Contains(name) ? "HERBS" :
        name.StartsWith("Powdered", StringComparison.OrdinalIgnoreCase) ? "POWDERED GEMS" :
        Substances.Contains(name) ? "ALCHEMICAL SUBSTANCES" :
        name.EndsWith("Talisman", StringComparison.OrdinalIgnoreCase) ? "TALISMANS" :
        name.EndsWith("Taper", StringComparison.OrdinalIgnoreCase) ? "TAPERS" :
        name.EndsWith("Pea", StringComparison.OrdinalIgnoreCase) ? "PEAS" : "OTHER";

    private void FillComponents()
    {
        if (_comps == null) return;
        var held = ComponentsHeld(Inv);
        var want = Wanted();
        // (only rebuilt when what you hold changes: the boxes being typed in stay)
        string sig = string.Join(",", held.Select(h => $"{h.wcid}:{h.have}"));
        if (sig == _compsShown && _comps.GetChildCount() > 0) return;
        _compsShown = sig;
        Clear(_comps);
        if (held.Count == 0)
        {
            _comps.AddChild(Line("You have no spell components.", RetailTheme.Dim, HorizontalAlignment.Center));
            return;
        }
        foreach (var group in held.GroupBy(h => ComponentGroup(h.name)).OrderBy(g => Array.IndexOf(ComponentGroups, g.Key)))
        {
            var title = Line(group.Key, RetailTheme.Gold, HorizontalAlignment.Center);
            title.AddThemeStyleboxOverride("normal", new StyleBoxFlat { BgColor = new Color(0.16f, 0.12f, 0.05f, 0.8f) });
            _comps.AddChild(title);
            foreach (var (wcid, name, icon, have) in group)
            {
                int id = wcid;
                var pic = new TextureRect { Texture = Icon(icon), ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize, StretchMode = TextureRect.StretchModeEnum.KeepAspectCentered, MouseFilter = MouseFilterEnum.Ignore };
                // (how many you have, and under it how many you want to keep - what /fillcomps buys up to)
                var (row, inside) = SpellRow(pic, name, have.ToString(), false);
                var w = new SpinBox { MinValue = 0, MaxValue = 5000, Step = 1, Value = want.TryGetValue(id, out int wv) ? wv : 0, CustomMinimumSize = new Vector2(64, 0),
                                      TooltipText = "How many to keep on you: /fillcomps at a spell component vendor buys up to this many." };
                w.ValueChanged += v => SetWanted(id, (int)v);
                inside.MouseFilter = MouseFilterEnum.Pass;
                inside.AddChild(w);
                _comps.AddChild(row);
            }
        }
        _comps.AddChild(Line("\n/fillcomps lists what's short of the numbers you want.", RetailTheme.Dim, HorizontalAlignment.Center));
    }
}

/// <summary>
/// One of the game's tabbed side panels as the game lays it out (Social: Allegiance / Fellowship / Friends / Squelch;
/// Quests; Map / House; the options), its tabs and frame the game's own, each tab's page filled by whoever made it.
/// </summary>
public partial class TabbedPanel : SidePanel
{
    /// <summary>Fills a tab's page: the tab (0 on, left to right), its name as the game has it, and the list to add to.</summary>
    public Action<int, string, VBoxContainer>? Fill;
    /// <summary>Seconds between refills while it's open (0: only when opened, a tab chosen, or asked).</summary>
    public double RefreshEvery;
    private readonly List<VBoxContainer> _boxes = new();
    private int _tab;
    private double _refreshIn;
    private Action<int> _choose = _ => { };

    public bool Setup(int id, uint layout, uint root, uint close)
    {
        if (!BuildPanel(id, layout, root)) return false;
        var r = Root!;
        CloseFrom(r.Find(close));
        Closed = () => Shown?.Invoke(this, false);
        var (tabs, pages, choose) = TabsFrom(r, i => { _tab = i; Refresh(); });
        _choose = choose;
        Pages = pages; TabNodes = tabs;
        foreach (var page in pages) _boxes.Add(ContentOver(page));
        for (int i = 0; i < pages.Count; i++) if (pages[i].Visible) _tab = i;
        DragAnywhere = true;
        LoadPlace();
        Resized2();
        return true;
    }

    public int Tab => _tab;
    public int TabCount => _boxes.Count;

    private Theme? _tabFontTheme;
    private bool _tabFontLooked;
    /// <summary>A theme with the font its tabs' names are drawn in (the game's larger, clearer one), for a page's own text; null if there's none.</summary>
    public Theme? TabFontTheme
    {
        get
        {
            if (_tabFontLooked) return _tabFontTheme;
            _tabFontLooked = true;
            try
            {
                var rf = TabNodes.Select(t => t.FontStyle).FirstOrDefault(f => f != null);
                if (rf?.ToGodotFont() is { } font) _tabFontTheme = new Theme { DefaultFont = font, DefaultFontSize = (int)MathF.Round(Math.Max(rf.Height, 8) * RetailTheme.Scale) };
            }
            catch (Exception ex) { GD.PushWarning("tab font: " + ex.Message); }
            return _tabFontTheme;
        }
    }
    /// <summary>Opens it on a tab.</summary>
    public void Show(int tab) { if (!Visible) Open(); if (tab >= 0 && tab < _boxes.Count) _choose(tab); }

    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("TabbedPanel");
        if (Visible && RefreshEvery > 0 && (_refreshIn -= delta) <= 0) { _refreshIn = RefreshEvery; Refresh(); }
    }

    public override void Refresh()
    {
        if (!Visible || _tab < 0 || _tab >= _boxes.Count) return;
        Clear(_boxes[_tab]);
        try { Fill?.Invoke(_tab, _tab < TabNodes.Count ? TabNodes[_tab].Text ?? "" : "", _boxes[_tab]); }
        catch (Exception ex) { GD.PushWarning($"panel {Name}: {ex.Message}"); }
    }
}

/// <summary>A titled text panel in the game's look (layout 0x21000020): Character Information, and other read-only pages.</summary>
public partial class TextPanel : SidePanel
{
    private RichTextLabel? _text;
    private UiNode? _title;
    public Func<string>? Content;

    public bool Setup(int id, string title)
    {
        if (!BuildPanel(id, 0x21000020, 0x100001C1)) return false;
        Frame(0x100000FD, 0x100000FC);
        _title = Root!.Find(0x100000FE);
        if (_title != null) { _title.Text = title; _title.CenterText(); _title.MouseFilter = MouseFilterEnum.Ignore; }
        if (Root!.Find(0x100001C2) is { } page)
        {
            foreach (var c in page.GetChildren()) if (c is UiNode n) n.Visible = false;
            _text = TextOver(page);
            _text.OffsetLeft = 8; _text.OffsetRight = -8; _text.OffsetTop = 6; _text.OffsetBottom = -6;
            _text.HorizontalAlignment = HorizontalAlignment.Center;
            Pages = new List<UiNode> { page };
        }
        LoadPlace();
        return true;
    }

    public override void Refresh() { if (_text != null && Content != null) _text.Text = Content(); }
}

/// <summary>
/// The spells on you (the status icons' wand and red wand): Buffs and Debuffs as two tabs, as the spellbook has
/// Spellbook and Components (its layout, 0x21000034, retitled) - each spell's icon, name and time left; a click shows
/// what it does, a right click identifies it.
/// </summary>
public partial class SpellsInEffectPanel : SidePanel
{
    public const int Id = 4;
    public Magic.MagicSystem? Magic;
    public Func<uint, Texture2D?> Icon = _ => null;
    public Action<Magic.Spell>? Identify;
    private VBoxContainer? _good, _bad;
    private Action<int> _choose = _ => { };
    private double _refreshIn;
    private Magic.Spell? _picked;
    private Label? _goodFoot, _badFoot;

    public bool Setup()
    {
        if (!BuildPanel(Id, 0x21000034, 0x100002A8)) return false;
        var r = Root!;
        CloseFrom(r.Find(0x100002AB));
        Closed = () => Shown?.Invoke(this, false);
        var (tabs, pages, choose) = TabsFrom(r, _ => Refresh());
        _choose = choose;
        Pages = pages; TabNodes = tabs;
        if (tabs.Count > 0) tabs[0].Text = "Buffs";
        if (tabs.Count > 1) tabs[1].Text = "Debuffs";
        if (pages.Count > 0) (_good, _goodFoot) = ContentWithFoot(pages[0]);
        if (pages.Count > 1) (_bad, _badFoot) = ContentWithFoot(pages[1]);
        DragAnywhere = true;
        LoadPlace();
        Resized2();
        return true;
    }

    /// <summary>Opens it on a tab (0 buffs, 1 debuffs); open on that tab already, it shuts.</summary>
    public void Show(int tab)
    {
        bool onIt = Visible && Pages.Count > tab && Pages[tab].Visible;
        if (onIt) { Toggle(); return; }
        if (!Visible) Open();
        _choose(tab);
        Refresh();
    }

    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("SpellsInEffectPanel");
        if (Visible && (_refreshIn -= delta) <= 0) { _refreshIn = 1; Refresh(); }
    }

    public override void Refresh()
    {
        if (!Visible || Magic == null || _good == null) return;
        Clear(_good);
        var on = Magic.Active().OrderBy(a => a.spell.Name).ToList();
        if (on.Count == 0) _good.AddChild(Line("No beneficial spells are affecting you.", RetailTheme.Dim, HorizontalAlignment.Center));
        foreach (var (spell, left, amount) in on)
        {
            var sp = spell;
            var icon = new TextureRect { Texture = Icon(sp.Icon), ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize, StretchMode = TextureRect.StretchModeEnum.KeepAspectCentered, MouseFilter = MouseFilterEnum.Ignore };
            // (what's left of it at the right; nothing there when it has no timer - worn items' spells and the like)
            var (row, _) = SpellRow(icon, sp.Name, TimeLeft(left), sp == _picked);
            row.GuiInput += e =>
            {
                if (e is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true }) { _picked = sp == _picked ? null : sp; Refresh(); }
                else if (e is InputEventMouseButton { ButtonIndex: MouseButton.Right, Pressed: true }) Identify?.Invoke(sp);
            };
            _good.AddChild(row);
        }
        // what the chosen one does (the game's "select a spell" box)
        if (_goodFoot != null) _goodFoot.Text = _picked != null && on.Any(a => a.spell == _picked) ? $"{_picked.Name}\n\n{_picked.Description}" : "SELECT A SPELL";
        if (_badFoot != null) _badFoot.Text = "SELECT A SPELL";
        if (_bad != null)
        {
            Clear(_bad);
            _bad.AddChild(Line("No harmful spells are affecting you.", RetailTheme.Dim, HorizontalAlignment.Center));
        }
    }
}
