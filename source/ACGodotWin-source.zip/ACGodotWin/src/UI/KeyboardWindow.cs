using System;
using System.Collections.Generic;
using System.Linq;
using Godot;

namespace ACGodot.UI;

/// <summary>
/// Configure Keyboard, as the game sets it out: tabs of commands, three keys to each. Click a key's square and press the
/// key (with Shift, Ctrl or Alt held, if wanted) to set it; right-click a square to clear it; Esc leaves it as it was.
/// Load File and Save As read and write the game's own .keymap files.
/// </summary>
public partial class KeyboardWindow : Combat.GameWindow
{
    // a tab's rows: a heading (no command), or a command's words and its name in the keymap ("Section.Action")
    private static readonly (string tab, (string label, string? command)[] rows)[] Tabs =
    {
        ("Movement", new (string, string?)[]
        {
            ("Movement", null),
            ("Move Forward", "MovementCommands.MovementForward"), ("Toggle Run/Walk", "MovementCommands.MovementWalkMode"), ("Move Backward", "MovementCommands.MovementBackup"),
            ("Stop Moving", "MovementCommands.MovementStop"), ("Strafe Right", "MovementCommands.MovementStrafeRight"), ("Strafe Left", "MovementCommands.MovementStrafeLeft"),
            ("Turn Right", "MovementCommands.MovementTurnRight"), ("Turn Left", "MovementCommands.MovementTurnLeft"), ("Autorun", "MovementCommands.MovementRunLock"),
            ("Jump", "MovementCommands.MovementJump"), ("Precise Jump", "ACGodot.PreciseJump"), ("Ready", "MovementCommands.Ready"), ("Crouch", "MovementCommands.Crouch"), ("Sit", "MovementCommands.Sitting"),
            ("Lay Down", "MovementCommands.Sleeping"),
        }),
        ("Camera", new (string, string?)[]
        {
            ("Camera", null),
            ("Zoom Camera In", "CameraControls.CameraMoveToward"), ("Zoom Camera Out", "CameraControls.CameraMoveAway"), ("Rotate Camera Left", "CameraControls.CameraRotateLeft"),
            ("Rotate Camera Right", "CameraControls.CameraRotateRight"), ("Rotate Camera Up", "CameraControls.CameraRotateUp"), ("Rotate Camera Down", "CameraControls.CameraRotateDown"),
            ("Move Camera to Default", "CameraControls.CameraViewDefault"), ("First Person Camera", "CameraControls.CameraViewFirstPerson"), ("Overhead View", "CameraControls.CameraViewLookDown"),
            ("Map View", "CameraControls.CameraViewMapMode"), ("Toggle Mouselook", "CameraControls.CameraInstantMouseLook"), ("Toggle Alternate Camera Mode", "CameraControls.CameraActivateAlternateMode"),
            ("Alternate Camera Mode", null),
            ("Zoom Camera In", "CameraAlternateControls.CameraMoveToward"), ("Zoom Camera Out", "CameraAlternateControls.CameraMoveAway"), ("Rotate Camera Left", "CameraAlternateControls.CameraRotateLeft"),
            ("Rotate Camera Right", "CameraAlternateControls.CameraRotateRight"), ("Rotate Camera Up", "CameraAlternateControls.CameraRotateUp"), ("Rotate Camera Down", "CameraAlternateControls.CameraRotateDown"),
            ("Move Camera to Default", "CameraAlternateControls.CameraViewDefault"), ("First Person Camera", "CameraAlternateControls.CameraViewFirstPerson"),
            ("Overhead View", "CameraAlternateControls.CameraViewLookDown"), ("Map View", "CameraAlternateControls.CameraViewMapMode"),
        }),
        ("Combat", new (string, string?)[]
        {
            ("Combat", null),
            ("Toggle Combat Mode", "Combat.CombatToggleCombat"),
            ("Melee Combat", null),
            ("Decrease Power", "MeleeCombat.CombatDecreaseAttackPower"), ("Increase Power", "MeleeCombat.CombatIncreaseAttackPower"), ("Low Attack", "MeleeCombat.CombatLowAttack"),
            ("Medium Attack", "MeleeCombat.CombatMediumAttack"), ("High Attack", "MeleeCombat.CombatHighAttack"),
            ("Missile Combat", null),
            ("Decrease Accuracy", "MissileCombat.CombatDecreaseMissileAccuracy"), ("Increase Accuracy", "MissileCombat.CombatIncreaseMissileAccuracy"), ("Low Attack", "MissileCombat.CombatAimLow"),
            ("Medium Attack", "MissileCombat.CombatAimMedium"), ("High Attack", "MissileCombat.CombatAimHigh"),
            ("Magic Combat", null),
            ("Cast Spell", "MagicCombat.CombatCastCurrentSpell"), ("Previous Spell", "MagicCombat.CombatPrevSpell"), ("Next Spell", "MagicCombat.CombatNextSpell"),
            ("Previous Spell Tab", "MagicCombat.CombatPrevSpellTab"), ("Next Spell Tab", "MagicCombat.CombatNextSpellTab"), ("First Spell", "MagicCombat.CombatFirstSpell"),
            ("Last Spell", "MagicCombat.CombatLastSpell"), ("First Spell Tab", "MagicCombat.CombatFirstSpellTab"), ("Last Spell Tab", "MagicCombat.CombatLastSpellTab"),
            ("Use Spell Slot 1", "MagicCombat.UseSpellSlot_1"), ("Use Spell Slot 2", "MagicCombat.UseSpellSlot_2"), ("Use Spell Slot 3", "MagicCombat.UseSpellSlot_3"),
            ("Use Spell Slot 4", "MagicCombat.UseSpellSlot_4"), ("Use Spell Slot 5", "MagicCombat.UseSpellSlot_5"), ("Use Spell Slot 6", "MagicCombat.UseSpellSlot_6"),
            ("Use Spell Slot 7", "MagicCombat.UseSpellSlot_7"), ("Use Spell Slot 8", "MagicCombat.UseSpellSlot_8"), ("Use Spell Slot 9", "MagicCombat.UseSpellSlot_9"),
        }),
        ("UI", new (string, string?)[]
        {
            ("Selection", null),
            ("Use Selected Item", "UICommands.USE"), ("Pick Up Selected Item", "ItemSelectionCommands.SelectionPickUp"), ("Split Stack", "ItemSelectionCommands.SelectionSplitStack"),
            ("Previous Selection", "ItemSelectionCommands.SelectionPreviousSelection"),
            ("Closest Monster", "ItemSelectionCommands.SelectionClosestMonster"), ("Previous Monster", "ItemSelectionCommands.SelectionPreviousMonster"), ("Next Monster", "ItemSelectionCommands.SelectionNextMonster"),
            ("Last Attacker", "ItemSelectionCommands.SelectionLastAttacker"),
            ("Closest Item", "ItemSelectionCommands.SelectionClosestItem"), ("Previous Item", "ItemSelectionCommands.SelectionPreviousItem"), ("Next Item", "ItemSelectionCommands.SelectionNextItem"),
            ("Closest Compass Item", "ItemSelectionCommands.SelectionClosestCompassItem"), ("Previous Compass Item", "ItemSelectionCommands.SelectionPreviousCompassItem"),
            ("Next Compass Item", "ItemSelectionCommands.SelectionNextCompassItem"),
            ("Closest Player", "ItemSelectionCommands.SelectionClosestPlayer"), ("Previous Player", "ItemSelectionCommands.SelectionPreviousPlayer"), ("Next Player", "ItemSelectionCommands.SelectionNextPlayer"),
            ("Previous Fellow", "ItemSelectionCommands.SelectionPreviousFellow"), ("Next Fellow", "ItemSelectionCommands.SelectionNextFellow"),
            ("Panels", null),
            ("Allegiance Panel", "UICommands.ToggleAllegiancePanel"), ("Fellowship Panel", "UICommands.ToggleFellowshipPanel"), ("Spellbook Panel", "UICommands.ToggleSpellbookPanel"),
            ("Spell Components Panel", "UICommands.ToggleSpellComponentsPanel"), ("Attributes Panel", "UICommands.ToggleAttributesPanel"), ("Skills Panel", "UICommands.ToggleSkillsPanel"),
            ("World Panel (the map)", "UICommands.ToggleWorldPanel"), ("Options Panel", "UICommands.ToggleOptionsPanel"), ("Inventory Panel", "UICommands.ToggleInventoryPanel"),
            ("Help", "UICommands.ToggleHelp"), ("Plugin Manager", "UICommands.TogglePluginManager"),
            ("Floating Chat Window 1", "UICommands.ToggleFloatingChatWindow1"), ("Floating Chat Window 2", "UICommands.ToggleFloatingChatWindow2"),
            ("Floating Chat Window 3", "UICommands.ToggleFloatingChatWindow3"), ("Floating Chat Window 4", "UICommands.ToggleFloatingChatWindow4"),
            ("Other", null),
            ("Enter Chat Mode", "ChatCommands.EnterChatMode"), ("Capture Screenshot", "UICommands.CaptureScreenshot"), ("Escape", "UICommands.EscapeKey"), ("Log Out", "UICommands.LOGOUT"),
        }),
        ("CharacterSettings", Enumerable.Repeat(("Quick Slots", (string?)null), 1)
            .Concat(Enumerable.Range(1, 18).Select(n => ($"Use Quick Slot {n}", (string?)$"QuickslotCommands.UseQuickSlot_{n}")))
            .Append(("Create Shortcut", "QuickslotCommands.CreateShortcut")).ToArray()),
        ("Emotes", Enumerable.Repeat(("Emotes", (string?)null), 1)
            .Concat(KeyMap.Motions.Where(m => m.name.StartsWith("Emotes.")).Select(m => (m.label, (string?)m.name))).ToArray()),
        ("ACGodot", new (string, string?)[]
        {
            ("ACGodot's own", null),
            ("Start a /command", "ACGodot.ChatSlash"), ("Options Panel", "ACGodot.OptionsPanel"), ("Free camera / back to playing", "ACGodot.FreeCamera"), ("Debug text", "ACGodot.DebugText"),
            ("Hour of the day back", "ACGodot.HourBack"), ("Hour of the day on", "ACGodot.HourOn"),
            ("For looking into problems", null),
            ("Go to Holtburg", "ACGodot.GoHoltburg"), ("Go to Yaraq", "ACGodot.GoYaraq"), ("Go to Shoushi", "ACGodot.GoShoushi"), ("Go to Arwic", "ACGodot.GoArwic"),
            ("Camera down to the ground", "ACGodot.CameraToGround"), ("Culling", "ACGodot.Culling"), ("Beacons", "ACGodot.Beacons"), ("Showcase", "ACGodot.Showcase"),
            ("Hide buildings", "ACGodot.HideBuildings"), ("Sky layers", "ACGodot.SkyLayers"), ("Openings", "ACGodot.Openings"), ("Save a capture", "ACGodot.Capture"),
            ("Write out the interface", "ACGodot.ExportInterface"),
        }),
    };

    private int _tab;
    private (string command, int slot, Button button)? _setting;
    private Label? _file;
    private FileDialog? _dialog;

    public KeyboardWindow() : base("Configure Keyboard", new Vector2(520, 470))
    {
        Closed = Cancel;
        Body.SizeFlagsVertical = SizeFlags.ExpandFill;
    }

    public void Open()
    {
        Build();
        Visible = true;
        MoveToFront();
        if (!Placed) Position = (GetViewportRect().Size - CustomMinimumSize) * 0.5f;
    }

    private void Build()
    {
        _setting = null;
        Clear();
        var tabs = new HBoxContainer();
        for (int i = 0; i < Tabs.Length; i++)
        {
            int n = i;
            var t = new Button { Text = Tabs[i].tab, ToggleMode = true, ButtonPressed = i == _tab, FocusMode = FocusModeEnum.None, SizeFlagsHorizontal = SizeFlags.ExpandFill };
            t.AddThemeFontSizeOverride("font_size", RetailTheme.Px(11));
            t.Pressed += () => { _tab = n; Build(); };
            tabs.AddChild(t);
        }
        Body.AddChild(tabs);
        var head = new HBoxContainer();
        head.AddChild(new Label { Text = "Command", SizeFlagsHorizontal = SizeFlags.ExpandFill, HorizontalAlignment = HorizontalAlignment.Center });
        foreach (string m in new[] { "Mapping 1", "Mapping 2", "Mapping 3" }) head.AddChild(new Label { Text = m, CustomMinimumSize = new Vector2(92, 0), HorizontalAlignment = HorizontalAlignment.Center });
        head.AddChild(new Control { CustomMinimumSize = new Vector2(12, 0) });
        Body.AddChild(head);
        var scroll = new ScrollContainer { SizeFlagsVertical = SizeFlags.ExpandFill, HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled, CustomMinimumSize = new Vector2(0, 260) };
        var rows = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        scroll.AddChild(rows);
        foreach (var (label, command) in Tabs[_tab].rows)
        {
            if (command == null) { rows.AddChild(Heading(label)); continue; }
            var row = new HBoxContainer();
            row.AddChild(new Label { Text = label, SizeFlagsHorizontal = SizeFlags.ExpandFill, ClipText = true });
            var keys = KeyMap.Of(command);
            for (int slot = 0; slot < 3; slot++)
            {
                int s = slot; string c = command;
                var b = new Button { Text = slot < keys.Count ? keys[slot].ToString() : "", CustomMinimumSize = new Vector2(92, 24), FocusMode = FocusModeEnum.None, ClipText = true,
                                     TooltipText = "Click, then press the key (with Shift, Ctrl or Alt held if wanted). Right-click clears it." };
                b.AddThemeFontSizeOverride("font_size", RetailTheme.Px(11));
                b.GuiInput += e =>
                {
                    if (e is not InputEventMouseButton { Pressed: true } mb) return;
                    if (mb.ButtonIndex == MouseButton.Right) { _setting = null; KeyMap.Set(c, s, default); Build(); b.AcceptEvent(); }
                    else if (mb.ButtonIndex == MouseButton.Left) { if (_setting is { } was && IsInstanceValid(was.button)) Build(); else { _setting = (c, s, b); b.Text = "press a key..."; } b.AcceptEvent(); }
                };
                row.AddChild(b);
            }
            rows.AddChild(row);
        }
        Body.AddChild(scroll);
        var files = new HBoxContainer { Alignment = BoxContainer.AlignmentMode.Center };
        files.AddThemeConstantOverride("separation", 14);
        files.AddChild(Small("Load File...", () => Pick(false)));
        _file = new Label { Text = KeyMap.FileName, CustomMinimumSize = new Vector2(180, 0), HorizontalAlignment = HorizontalAlignment.Center, ClipText = true, TooltipText = KeyMap.File };
        files.AddChild(_file);
        files.AddChild(Small("Save As...", () => Pick(true)));
        Body.AddChild(files);
        var foot = new HBoxContainer();
        foot.AddChild(Small("Defaults", () => { KeyMap.LoadDefaults(); KeyMap.OwnToDefaults(); Build(); }));
        foot.AddChild(Small("Revert", () => { KeyMap.Load(KeyMap.File, remember: false); Build(); }));
        foot.AddChild(new Control { SizeFlagsHorizontal = SizeFlags.ExpandFill });
        foot.AddChild(Small("OK", () => { KeyMap.Save(); _setting = null; Visible = false; }));
        foot.AddChild(Small("Cancel", () => { Cancel(); Visible = false; }));
        Body.AddChild(foot);
    }

    // shut without OK: the keys as the file has them
    private void Cancel() { _setting = null; if (KeyMap.File.Length > 0) KeyMap.Load(KeyMap.File, remember: false); }

    private void Pick(bool save)
    {
        _dialog?.QueueFree();
        _dialog = new FileDialog
        {
            Access = FileDialog.AccessEnum.Filesystem, FileMode = save ? FileDialog.FileModeEnum.SaveFile : FileDialog.FileModeEnum.OpenFile,
            Title = save ? "Save the keymap as" : "Load a keymap", Filters = new[] { "*.keymap ; Asheron's Call keymaps" }, UseNativeDialog = true,
        };
        try { if (KeyMap.File.Length > 0) { _dialog.CurrentDir = System.IO.Path.GetDirectoryName(KeyMap.File); if (save) _dialog.CurrentFile = KeyMap.FileName; } } catch { }
        _dialog.FileSelected += path =>
        {
            if (save) { if (!path.EndsWith(".keymap", StringComparison.OrdinalIgnoreCase)) path += ".keymap"; KeyMap.Save(path); }
            else if (!KeyMap.Load(path)) { if (_file != null) _file.Text = "couldn't read that file"; return; }
            Build();
        };
        AddChild(_dialog);
        _dialog.PopupCentered(new Vector2I(700, 480));
    }

    // a square waiting for its key: the next key pressed is it (Esc: left as it was); a modifier on its own counts when let go
    public override void _Input(InputEvent e)
    {
        if (!Visible || _setting is not { } s) return;
        if (e is InputEventKey { Echo: false } k)
        {
            string? name = KeyMap.NameOf(k.Keycode);
            bool modifier = k.Keycode is Key.Shift or Key.Ctrl or Key.Alt or Key.Meta;
            if (k.Pressed && k.Keycode == Key.Escape) { _setting = null; Build(); }
            else if (k.Pressed && !modifier && KeyMap.FromEvent(k) is { } b) { _setting = null; KeyMap.Set(s.command, s.slot, b); Build(); }
            else if (!k.Pressed && modifier && name != null) { _setting = null; KeyMap.Set(s.command, s.slot, new KeyMap.Bind(name, 0)); Build(); }
            GetViewport().SetInputAsHandled();
        }
        else if (e is InputEventMouseButton { Pressed: true } mb && KeyMap.NameOf(mb.ButtonIndex) is string button)
        {
            _setting = null; KeyMap.Set(s.command, s.slot, new KeyMap.Bind(button, 0)); Build();
            GetViewport().SetInputAsHandled();
        }
    }
}
