using System;
using Godot;

namespace ACGodot.UI;

/// <summary>
/// The video settings (Options > Video): kept in user://ui.cfg, put in force when the game starts and whenever one is
/// changed. What draws the landscape and what stands on it are found as they come to be (the world is made after the
/// game starts), so this is a node that keeps their distances as set.
/// </summary>
public partial class Video : Node
{
    private const string Cfg = "user://ui.cfg";

    public static bool Fullscreen, VSync = true, Fxaa;
    public static int FrameCap;            // 0: no limit
    public static int Msaa = 2;            // 0 off, 1 2x, 2 4x, 3 8x
    public static int Aniso = 4;           // 0 off, 1 2x, 2 4x, 3 8x, 4 16x
    public static int Scale = 100;         // the 3D world drawn at so much of the window's size (%)
    public static int Land = 5;            // landblocks of landscape each way
    public static int Things = 3;          // landblocks of buildings, trees and the rest each way
    public static int Fov = 70;
    public static bool Steep;
    public static bool Unload = true;      // models, textures and looks nothing on screen uses: unloaded after a few minutes              // ground too steep to walk up tinted dark red

    // ── lighting and effects (Options > Video: lighting and effects) ──
    public static int Shadows = 1;         // the sun's shadows: 0 none, 1 characters and creatures, 2 everything
    public static int ShadowReach = 80;    // metres from the camera that shadows are drawn
    public static bool Ao = true;          // ambient occlusion: soft darkening in corners and under things
    public static int AoStrength = 100;    // %
    public static bool Grade = true;       // colour grading (the curves and warmth below)
    public static int Brightness = 100, Contrast = 100, Saturation = 110;   // %
    public static int Warmth = 3;          // -20 cool .. +20 warm
    public static int Tonemap = 0;         // 0 linear (as the game), 1 filmic, 2 ACES, 3 AgX
    public static bool Lamps = true;       // lamps, torches and fires light what's around them
    public static int LampBright = 100;    // %
    public static bool ViewerLight = true; // a soft light around your character (as the game's), in dark places
    public static int FarLand = 10;        // landblocks of distant, simplified landscape each way (0: none)
    public static bool Scroll = true;      // moving textures (waterfalls, lava, glowing runes)
    public static bool Ocean = true;       // sea past the world's edge
    public static bool Glow = true;        // glow / bloom around bright and glowing things
    public static int GlowStrength = 100;  // %
    public static int Upscale = 0;         // how the 3D picture is scaled to the window: 0 plain, 1 FSR 1, 2 FSR 2 (with its own TAA)
    public static bool Taa = false;        // temporal anti-aliasing (with plain or FSR 1 scaling; FSR 2 has its own)
    public static bool VolFog = true;      // volumetric fog: haze with depth, light shafts, misty glow round lamps
    public static int VolFogDensity = 100; // %
    public static bool Water = true;       // moving, shining water with foam along the shore
    public static bool Bump = true;        // bumpiness on the ground made from its textures (near the camera)
    public static int BumpStrength = 100;  // %
    public static bool Triplanar = true;   // cliffs and steep slopes textured from the side (not smeared)
    public static int FarTrees = 8;        // landblocks out to which trees and scenery are drawn simply, past the full ones (capped at the landscape's)

    /// <summary>Set by the game each frame: the camera is underground (a dungeon or deep cellar) - no sun shadows there.</summary>
    public static bool Underground;
    /// <summary>The visual layer that characters, creatures and what they hold are also on: the sun's shadows can be
    /// limited to them (Shadows = 1).</summary>
    public const uint ActorLayer = 2;

    public Func<Terrain.TerrainStreamer?>? TerrainOf;
    public Func<Objects.ObjectStreamer?>? ObjectsOf;
    public Func<Camera3D?>? CamOf;
    public Func<DirectionalLight3D?>? SunOf;
    public Func<Godot.Environment?>? EnvOf;
    private static Video? _one;

    public static void Load()
    {
        var c = new ConfigFile();
        if (global::ACGodot.SafeConfig.Load(c, Cfg) != Error.Ok) return;
        Fullscreen = (bool)c.GetValue("video", "fullscreen", Fullscreen);
        VSync = (bool)c.GetValue("video", "vsync", VSync);
        Fxaa = (bool)c.GetValue("video", "fxaa", Fxaa);
        FrameCap = Math.Clamp((int)c.GetValue("video", "cap", FrameCap), 0, 500);
        Msaa = Math.Clamp((int)c.GetValue("video", "msaa", Msaa), 0, 3);
        Aniso = Math.Clamp((int)c.GetValue("video", "aniso", Aniso), 0, 4);
        Scale = Math.Clamp((int)c.GetValue("video", "scale", Scale), 50, 100);
        Land = Math.Clamp((int)c.GetValue("video", "land", Land), 2, 8);
        Things = Math.Clamp((int)c.GetValue("video", "things", Things), 1, 5);
        Fov = Math.Clamp((int)c.GetValue("video", "fov", Fov), 50, 100);
        Steep = (bool)c.GetValue("video", "steep", Steep);
        Unload = (bool)c.GetValue("video", "unload", Unload);
        Shadows = Math.Clamp((int)c.GetValue("video", "shadows", Shadows), 0, 2);
        ShadowReach = Math.Clamp((int)c.GetValue("video", "shadow_reach", ShadowReach), 20, 300);
        Ao = (bool)c.GetValue("video", "ao", Ao);
        AoStrength = Math.Clamp((int)c.GetValue("video", "ao_strength", AoStrength), 25, 300);
        Grade = (bool)c.GetValue("video", "grade", Grade);
        Brightness = Math.Clamp((int)c.GetValue("video", "brightness", Brightness), 50, 150);
        Contrast = Math.Clamp((int)c.GetValue("video", "contrast", Contrast), 50, 150);
        Saturation = Math.Clamp((int)c.GetValue("video", "saturation", Saturation), 0, 200);
        Warmth = Math.Clamp((int)c.GetValue("video", "warmth", Warmth), -20, 20);
        Tonemap = Math.Clamp((int)c.GetValue("video", "tonemap", Tonemap), 0, 3);
        Lamps = (bool)c.GetValue("video", "lamps", Lamps);
        LampBright = Math.Clamp((int)c.GetValue("video", "lamp_bright", LampBright), 25, 300);
        ViewerLight = (bool)c.GetValue("video", "viewer_light", ViewerLight);
        FarLand = Math.Clamp((int)c.GetValue("video", "far_land", FarLand), 0, 15);
        Scroll = (bool)c.GetValue("video", "scroll", Scroll);
        Ocean = (bool)c.GetValue("video", "ocean", Ocean);
        Glow = (bool)c.GetValue("video", "glow", Glow);
        GlowStrength = Math.Clamp((int)c.GetValue("video", "glow_strength", GlowStrength), 25, 300);
        Upscale = Math.Clamp((int)c.GetValue("video", "upscale", Upscale), 0, 2);
        Taa = (bool)c.GetValue("video", "taa", Taa);
        VolFog = (bool)c.GetValue("video", "vol_fog", VolFog);
        VolFogDensity = Math.Clamp((int)c.GetValue("video", "vol_fog_density", VolFogDensity), 10, 400);
        Water = (bool)c.GetValue("video", "water", Water);
        FarTrees = Math.Clamp((int)c.GetValue("video", "far_trees", FarTrees), 0, 8);
        Bump = (bool)c.GetValue("video", "bump", Bump);
        BumpStrength = Math.Clamp((int)c.GetValue("video", "bump_strength", BumpStrength), 25, 300);
        Triplanar = (bool)c.GetValue("video", "triplanar", Triplanar);
    }

    public static void Save()
    {
        var c = new ConfigFile();
        global::ACGodot.SafeConfig.Load(c, Cfg);
        c.SetValue("video", "fullscreen", Fullscreen); c.SetValue("video", "vsync", VSync); c.SetValue("video", "fxaa", Fxaa);
        c.SetValue("video", "cap", FrameCap); c.SetValue("video", "msaa", Msaa); c.SetValue("video", "aniso", Aniso);
        c.SetValue("video", "scale", Scale); c.SetValue("video", "land", Land); c.SetValue("video", "things", Things); c.SetValue("video", "fov", Fov); c.SetValue("video", "steep", Steep); c.SetValue("video", "unload", Unload);
        c.SetValue("video", "shadows", Shadows); c.SetValue("video", "shadow_reach", ShadowReach); c.SetValue("video", "ao", Ao); c.SetValue("video", "ao_strength", AoStrength);
        c.SetValue("video", "grade", Grade); c.SetValue("video", "brightness", Brightness); c.SetValue("video", "contrast", Contrast); c.SetValue("video", "saturation", Saturation);
        c.SetValue("video", "warmth", Warmth); c.SetValue("video", "tonemap", Tonemap); c.SetValue("video", "lamps", Lamps); c.SetValue("video", "lamp_bright", LampBright);
        c.SetValue("video", "viewer_light", ViewerLight); c.SetValue("video", "far_land", FarLand); c.SetValue("video", "scroll", Scroll); c.SetValue("video", "ocean", Ocean);
        c.SetValue("video", "glow", Glow); c.SetValue("video", "glow_strength", GlowStrength); c.SetValue("video", "upscale", Upscale); c.SetValue("video", "taa", Taa);
        c.SetValue("video", "vol_fog", VolFog); c.SetValue("video", "vol_fog_density", VolFogDensity); c.SetValue("video", "water", Water); c.SetValue("video", "far_trees", FarTrees);
        c.SetValue("video", "bump", Bump); c.SetValue("video", "bump_strength", BumpStrength); c.SetValue("video", "triplanar", Triplanar);
        global::ACGodot.SafeConfig.Save(c, Cfg);
    }

    public override void _Ready()
    {
        _one = this; Load(); Apply();
        // characters, creatures (anything with a skeleton) and what they hold go on the actor layer too, so the sun's
        // shadows can be cast by them alone
        GetTree().NodeAdded += n =>
        {
            if (n is MeshInstance3D mi && (mi.Skin != null || n.GetParent() is BoneAttachment3D || n.GetParent()?.GetParent() is BoneAttachment3D))
                mi.Layers |= ActorLayer;
        };
    }

    private static int _lookVersion = 1;
    private int _lookApplied;

    /// <summary>A setting was changed: kept, and put in force.</summary>
    public static void Changed() { Save(); _lookVersion++; _one?.Apply(); }

    /// <summary>Keeping time with the screen, and the most frames a second (also put back after a stall, see TestBridge).</summary>
    public static void ApplyFrames()
    {
        DisplayServer.WindowSetVsyncMode(VSync ? DisplayServer.VSyncMode.Enabled : DisplayServer.VSyncMode.Disabled);
        Engine.MaxFps = FrameCap;
    }

    private void Apply()
    {
        ApplyFrames();
        var win = GetWindow();
        if (win != null)
        {
            bool full = win.Mode is Window.ModeEnum.Fullscreen or Window.ModeEnum.ExclusiveFullscreen;
            if (Fullscreen && !full) win.Mode = Window.ModeEnum.Fullscreen;
            else if (!Fullscreen && full) win.Mode = OptionsWindow.StartMaximized ? Window.ModeEnum.Maximized : Window.ModeEnum.Windowed;
        }
        var vp = GetViewport();
        if (vp != null)
        {
            vp.Msaa3D = Msaa switch { 0 => Viewport.Msaa.Disabled, 1 => Viewport.Msaa.Msaa2X, 3 => Viewport.Msaa.Msaa8X, _ => Viewport.Msaa.Msaa4X };
            vp.ScreenSpaceAA = Fxaa ? Viewport.ScreenSpaceAAEnum.Fxaa : Viewport.ScreenSpaceAAEnum.Disabled;
            vp.Scaling3DScale = Scale / 100f;
            vp.Scaling3DMode = Upscale switch { 1 => Viewport.Scaling3DModeEnum.Fsr, 2 => Viewport.Scaling3DModeEnum.Fsr2, _ => Viewport.Scaling3DModeEnum.Bilinear };
            vp.UseTaa = Taa && Upscale != 2;
            if (Upscale == 2) vp.Msaa3D = Viewport.Msaa.Disabled;   // (FSR 2 does its own smoothing, and can't with MSAA)
            try { vp.AnisotropicFilteringLevel = (Viewport.AnisotropicFiltering)Aniso; } catch { }
        }
    }

    // (the distances and the view's width: on what's there now - made after the game starts, and made again)
    public override void _Process(double delta)
    {
        ACGodot.FrameWatch.Enter("Video");
        if (TerrainOf?.Invoke() is { } t) { if (t.Radius != Land) t.Radius = Land; t.SteepTint = Steep; t.WaterFx = Water;
            t.SetParam("detail_bump", Bump); t.SetParam("bump_strength", BumpStrength / 100f); t.SetParam("triplanar", Triplanar); }
        if (ObjectsOf?.Invoke() is { } o) { if (o.Radius != Things) o.Radius = Things; if (Unload) o.TrimAssets(); }
        if (CamOf?.Invoke() is { } c && Math.Abs(c.Fov - Fov) > 0.01f) c.Fov = Fov;
        if (SunOf?.Invoke() is { } sun)
        {
            bool on = Shadows > 0 && !Underground;
            if (sun.ShadowEnabled != on) sun.ShadowEnabled = on;
            if (_lookApplied != _lookVersion) ApplySun(sun);
        }
        if (EnvOf?.Invoke() is { } env)
        {
            // (the sky's setup puts its own tone mapping: put ours back over it, every time it's changed)
            var tm = Tonemap switch { 1 => Godot.Environment.ToneMapper.Filmic, 2 => Godot.Environment.ToneMapper.Aces, 3 => Godot.Environment.ToneMapper.Agx, _ => Godot.Environment.ToneMapper.Linear };
            if (env.TonemapMode != tm || _lookApplied != _lookVersion) ApplyLook(env);
            if (VolFog)
            {
                // the haze takes the day's fog colour (grey underground, where there's no outside fog)
                Color fc = Underground ? new Color(0.25f, 0.25f, 0.27f) : env.FogLightColor;
                if (!env.VolumetricFogAlbedo.IsEqualApprox(fc)) env.VolumetricFogAlbedo = fc;
            }
        }
        _lookApplied = _lookVersion;
    }

    private static void ApplySun(DirectionalLight3D sun)
    {
        sun.DirectionalShadowMode = DirectionalLight3D.ShadowMode.Parallel2Splits;
        sun.DirectionalShadowMaxDistance = ShadowReach;
        sun.ShadowBlur = 1.5f;
        sun.ShadowNormalBias = 1.5f;
        sun.ShadowBias = 0.05f;
        sun.ShadowOpacity = 0.75f;
        sun.ShadowCasterMask = Shadows == 2 ? 0xFFFFFFFFu : ActorLayer;
    }

    private static void ApplyLook(Godot.Environment env)
    {
        env.TonemapMode = Tonemap switch { 1 => Godot.Environment.ToneMapper.Filmic, 2 => Godot.Environment.ToneMapper.Aces, 3 => Godot.Environment.ToneMapper.Agx, _ => Godot.Environment.ToneMapper.Linear };
        env.SsaoEnabled = Ao;
        env.SsaoRadius = 2f;
        env.SsaoIntensity = 1.5f * AoStrength / 100f;
        env.SsaoPower = 1.5f;
        env.SsaoDetail = 0.5f;
        env.SsaoHorizon = 0.06f;
        env.SsaoSharpness = 0.98f;
        env.SsaoLightAffect = 0f;
        env.SsaoAOChannelAffect = 0f;
        env.GlowEnabled = Glow;
        env.GlowIntensity = 0.8f * GlowStrength / 100f;
        env.GlowStrength = 1f;
        env.GlowBloom = 0.03f * GlowStrength / 100f;
        env.GlowHdrThreshold = 0.95f;
        env.GlowHdrScale = 2f;
        env.GlowBlendMode = Godot.Environment.GlowBlendModeEnum.Softlight;
        env.VolumetricFogEnabled = VolFog;
        env.VolumetricFogDensity = 0.0035f * VolFogDensity / 100f;
        env.VolumetricFogLength = 160f;
        env.VolumetricFogDetailSpread = 2f;
        env.VolumetricFogGIInject = 0f;
        env.VolumetricFogSkyAffect = 0f;
        env.VolumetricFogAnisotropy = 0.5f;
        env.AdjustmentEnabled = Grade;
        env.AdjustmentBrightness = Brightness / 100f;
        env.AdjustmentContrast = Contrast / 100f;
        env.AdjustmentSaturation = Saturation / 100f;
        env.AdjustmentColorCorrection = Grade ? GradeCurve(Warmth) : null;
    }

    /// <summary>
    /// The grade's curve as a 1D lookup (each channel through it): a gentle S - the darkest a touch deeper, the middle and
    /// highlights a little lifted - and warmth (red up, blue down, or the other way).
    /// </summary>
    private static ImageTexture GradeCurve(int warmth)
    {
        // master curve: monotone through these points (x in, y out)
        float[] xs = { 0f, 0.0437f, 0.1517f, 0.7589f, 1f }, ys = { 0f, 0.0186f, 0.1648f, 0.8046f, 1f };
        float Master(float x)
        {
            for (int i = 0; i < xs.Length - 1; i++)
                if (x <= xs[i + 1])
                {
                    float t = (x - xs[i]) / (xs[i + 1] - xs[i]);
                    float smooth = t * t * (3 - 2 * t);
                    return ys[i] + (ys[i + 1] - ys[i]) * (0.5f * t + 0.5f * smooth);   // (half straight, half eased: no kinks, no overshoot)
                }
            return 1f;
        }
        float w = warmth / 100f;
        var data = new byte[256 * 4];
        for (int i = 0; i < 256; i++)
        {
            float m = Math.Clamp(Master(i / 255f), 0f, 1f);
            data[i * 4] = (byte)Math.Clamp(MathF.Round(m * (1f + w) * 255f), 0, 255);
            data[i * 4 + 1] = (byte)Math.Clamp(MathF.Round(m * 255f), 0, 255);
            data[i * 4 + 2] = (byte)Math.Clamp(MathF.Round(m * (1f - w) * 255f), 0, 255);
            data[i * 4 + 3] = 255;
        }
        return ImageTexture.CreateFromImage(Image.CreateFromData(256, 1, false, Image.Format.Rgba8, data));
    }
}
