using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Godot;

namespace ACGodot;

/// <summary>
/// Which keys do what, kept in the game's own keymap format (the .keymap files of Asheron's Call: sections of
/// "Action [ "" [ device KEY ] modifiers ]" lines), so a keymap from the game loads here and one saved here loads there.
/// Everything that reads the keyboard asks this by a command's name ("MovementCommands.MovementForward").
/// The file in use is kept in user://ui.cfg; with none chosen it is user://acgodot.keymap, made from data/default.keymap.
/// </summary>
public static class KeyMap
{
    /// <summary>One key (or mouse button) with the modifier keys held with it: 1 Shift, 2 Ctrl, 4 Alt, 8 the Windows key.</summary>
    public readonly record struct Bind(string KeyName, int Mask)
    {
        public bool None => string.IsNullOrEmpty(KeyName);
        /// <summary>As the game's own keyboard screen words it: "Alt+A", "KP_Add", "Button 3".</summary>
        public override string ToString()
        {
            if (None) return "";
            string k = Shown.TryGetValue(KeyName, out var s) ? s : KeyName.StartsWith("DIK_") ? Title(KeyName[4..]) : KeyName.StartsWith("DIMOFS_BUTTON") ? "Button " + KeyName[13..] : KeyName;
            return ((Mask & 2) != 0 ? "Ctrl+" : "") + ((Mask & 4) != 0 ? "Alt+" : "") + ((Mask & 1) != 0 ? "Shift+" : "") + ((Mask & 8) != 0 ? "Win+" : "") + k;
        }
        private static string Title(string s) => s.Length <= 1 ? s : s[..1] + s[1..].ToLowerInvariant();
    }

    private sealed class Line
    {
        public string Action = "", Device = "0", Key = "", Sub = "", Activation = "";
        public int Mask; public bool HasMask;
    }

    // the file as read: its sections in order, each with its lines in order (what isn't a key or button - the mouse's axes,
    // the wheel - is kept as it came and written back)
    private static readonly List<(string section, List<Line> lines)> _sections = new();
    private static readonly Dictionary<string, List<Bind>> _binds = new();
    private static readonly Dictionary<string, List<string>> _byKey = new();
    private static string _header = "";
    public static string File { get; private set; } = "";
    public static string FileName => File.Length > 0 ? Path.GetFileName(File) : "";
    /// <summary>Told when the keys change (a file loaded, a key set).</summary>
    public static Action? Changed;

    private const string UiCfg = "user://ui.cfg";
    private static string DefaultFile => ProjectSettings.GlobalizePath("res://data/default.keymap");
    private static string OwnFile => ProjectSettings.GlobalizePath("user://acgodot.keymap");

    // ── the game's key names, and Godot's keys ──

    private static readonly Dictionary<string, Key> Keys = Build();
    private static readonly Dictionary<Key, string> Names = new();
    private static readonly Dictionary<string, string> Shown = new()
    {
        ["DIK_UPARROW"] = "Up", ["DIK_DOWNARROW"] = "Down", ["DIK_LEFT"] = "Left", ["DIK_RIGHTARROW"] = "Right", ["DIK_CAPSLOCK"] = "Caps_Lock",
        ["DIK_LSHIFT"] = "Shift", ["DIK_RSHIFT"] = "Shift_R", ["DIK_LCONTROL"] = "Ctrl", ["DIK_RCONTROL"] = "Ctrl_R", ["DIK_LMENU"] = "Alt", ["DIK_RALT"] = "Alt_R",
        ["DIK_SPACE"] = "space", ["DIK_RETURN"] = "Return", ["DIK_ESCAPE"] = "Escape", ["DIK_BACK"] = "BackSpace", ["DIK_GRAVE"] = "`", ["DIK_MINUS"] = "-", ["DIK_EQUALS"] = "=",
        ["DIK_LBRACKET"] = "[", ["DIK_RBRACKET"] = "]", ["DIK_BACKSLASH"] = "\\", ["DIK_SEMICOLON"] = ";", ["DIK_APOSTROPHE"] = "'", ["DIK_COMMA"] = ",", ["DIK_PERIOD"] = ".", ["DIK_SLASH"] = "/",
        ["DIK_PGUP"] = "Prior", ["DIK_PGDN"] = "Next", ["DIK_NUMPADSTAR"] = "KP_Multiply", ["DIK_NUMPADMINUS"] = "KP_Subtract", ["DIK_NUMPADPLUS"] = "KP_Add", ["DIK_NUMPADENTER"] = "KP_Enter",
        ["DIK_NUMPADSLASH"] = "KP_Divide", ["DIK_DECIMAL"] = "KP_Delete", ["DIK_NUMPAD0"] = "KP_Insert", ["DIK_NUMPAD1"] = "KP_End", ["DIK_NUMPAD2"] = "KP_Down", ["DIK_NUMPAD3"] = "KP_Next",
        ["DIK_NUMPAD4"] = "KP_Left", ["DIK_NUMPAD5"] = "KP_Begin", ["DIK_NUMPAD6"] = "KP_Right", ["DIK_NUMPAD7"] = "KP_Home", ["DIK_NUMPAD8"] = "KP_Up", ["DIK_NUMPAD9"] = "KP_Prior",
    };

    private static Dictionary<string, Key> Build()
    {
        var d = new Dictionary<string, Key>(StringComparer.OrdinalIgnoreCase);
        for (char c = 'A'; c <= 'Z'; c++) d["DIK_" + c] = Key.A + (c - 'A');
        for (int i = 0; i <= 9; i++) { d["DIK_" + i] = Key.Key0 + i; d["DIK_NUMPAD" + i] = Key.Kp0 + i; }
        for (int i = 1; i <= 12; i++) d["DIK_F" + i] = Key.F1 + (i - 1);
        void A(Key k, params string[] names) { foreach (var n in names) d[n] = k; }
        A(Key.Up, "DIK_UPARROW", "DIK_UP"); A(Key.Down, "DIK_DOWNARROW", "DIK_DOWN"); A(Key.Left, "DIK_LEFT", "DIK_LEFTARROW"); A(Key.Right, "DIK_RIGHTARROW", "DIK_RIGHT");
        A(Key.Space, "DIK_SPACE"); A(Key.Enter, "DIK_RETURN"); A(Key.Escape, "DIK_ESCAPE"); A(Key.Tab, "DIK_TAB"); A(Key.Backspace, "DIK_BACK", "DIK_BACKSPACE");
        A(Key.Capslock, "DIK_CAPSLOCK", "DIK_CAPITAL"); A(Key.Shift, "DIK_LSHIFT", "DIK_RSHIFT"); A(Key.Ctrl, "DIK_LCONTROL", "DIK_RCONTROL"); A(Key.Alt, "DIK_LMENU", "DIK_RALT", "DIK_RMENU");
        A(Key.Meta, "DIK_LWIN", "DIK_RWIN");
        A(Key.Quoteleft, "DIK_GRAVE"); A(Key.Minus, "DIK_MINUS"); A(Key.Equal, "DIK_EQUALS"); A(Key.Bracketleft, "DIK_LBRACKET"); A(Key.Bracketright, "DIK_RBRACKET");
        A(Key.Backslash, "DIK_BACKSLASH"); A(Key.Semicolon, "DIK_SEMICOLON"); A(Key.Apostrophe, "DIK_APOSTROPHE"); A(Key.Comma, "DIK_COMMA"); A(Key.Period, "DIK_PERIOD"); A(Key.Slash, "DIK_SLASH");
        A(Key.Insert, "DIK_INSERT"); A(Key.Delete, "DIK_DELETE"); A(Key.Home, "DIK_HOME"); A(Key.End, "DIK_END"); A(Key.Pageup, "DIK_PGUP", "DIK_PRIOR"); A(Key.Pagedown, "DIK_PGDN", "DIK_NEXT");
        A(Key.KpMultiply, "DIK_NUMPADSTAR", "DIK_MULTIPLY"); A(Key.KpSubtract, "DIK_NUMPADMINUS", "DIK_SUBTRACT"); A(Key.KpAdd, "DIK_NUMPADPLUS", "DIK_ADD");
        A(Key.KpEnter, "DIK_NUMPADENTER"); A(Key.KpDivide, "DIK_NUMPADSLASH", "DIK_DIVIDE"); A(Key.KpPeriod, "DIK_DECIMAL", "DIK_NUMPADPERIOD");
        A(Key.Pause, "DIK_PAUSE"); A(Key.Scrolllock, "DIK_SCROLL"); A(Key.Numlock, "DIK_NUMLOCK"); A(Key.Print, "DIK_SYSRQ");
        return d;
    }

    /// <summary>The game's name for a key pressed (null: one it has no name for).</summary>
    public static string? NameOf(Key k)
    {
        if (Names.Count == 0) foreach (var kv in Keys) Names.TryAdd(kv.Value, kv.Key);   // (the first name given is the one written)
        return Names.TryGetValue(k, out var n) ? n : null;
    }

    private static MouseButton ButtonOf(string name) => name switch
    {
        "DIMOFS_BUTTON0" => MouseButton.Left, "DIMOFS_BUTTON1" => MouseButton.Right, "DIMOFS_BUTTON2" => MouseButton.Middle,
        "DIMOFS_BUTTON3" => MouseButton.Xbutton1, "DIMOFS_BUTTON4" => MouseButton.Xbutton2, _ => MouseButton.None,
    };
    /// <summary>The game's name for a mouse button that can be given a command (the two at the side), else null.</summary>
    public static string? NameOf(MouseButton b) => b == MouseButton.Xbutton1 ? "DIMOFS_BUTTON3" : b == MouseButton.Xbutton2 ? "DIMOFS_BUTTON4" : null;

    private static bool IsModifier(string keyName) => keyName is "DIK_LSHIFT" or "DIK_RSHIFT" or "DIK_LCONTROL" or "DIK_RCONTROL" or "DIK_LMENU" or "DIK_RALT" or "DIK_RMENU" or "DIK_LWIN" or "DIK_RWIN";

    // ACGodot's own commands (the game has none of them): kept apart from the keymap file, in user://ui.cfg, so a file saved
    // here still holds only what the game knows
    public const string Own = "ACGodot";
    private static readonly (string action, string key, int mask)[] OwnDefaults =
    {
        ("ChatSlash", "DIK_SLASH", 0), ("OptionsPanel", "DIK_O", 2), ("FreeCamera", "DIK_SEMICOLON", 6), ("DebugText", "DIK_D", 2),
        ("HourBack", "DIK_LBRACKET", 1), ("HourOn", "DIK_RBRACKET", 1), ("PreciseJump", "DIK_SPACE", 2),
        ("GoHoltburg", "DIK_F1", 6), ("GoYaraq", "DIK_F2", 6), ("GoShoushi", "DIK_F3", 6), ("GoArwic", "DIK_F4", 6), ("CameraToGround", "DIK_F5", 6),
        ("Culling", "DIK_F6", 6), ("Beacons", "DIK_F7", 6), ("Showcase", "DIK_K", 6), ("HideBuildings", "DIK_B", 6), ("SkyLayers", "DIK_L", 6),
        ("Openings", "DIK_O", 6), ("Capture", "DIK_P", 6), ("ExportInterface", "DIK_U", 2),
    };
    private static void AddOwn()
    {
        _sections.RemoveAll(x => x.section == Own);
        var lines = new List<Line>();
        var cfg = new ConfigFile();
        bool kept = global::ACGodot.SafeConfig.Load(cfg, UiCfg) == Error.Ok && cfg.HasSection("keys-own");
        if (kept)
        {
            foreach (string key in cfg.GetSectionKeys("keys-own"))
            {
                var p = ((string)cfg.GetValue("keys-own", key)).Split('|');
                if (p.Length == 3 && int.TryParse(p[2], out int mask)) lines.Add(new Line { Action = p[0], Key = p[1], Mask = mask, HasMask = mask != 0, Device = p[1].StartsWith("DIMOFS") ? "1" : "0" });
            }
            // (a command added since they were kept: its usual key)
            foreach (var (action, key, mask) in OwnDefaults)
                if (!cfg.HasSectionKey("keys-own-seen", action)) lines.Add(new Line { Action = action, Key = key, Mask = mask, HasMask = mask != 0 });
        }
        else foreach (var (action, key, mask) in OwnDefaults) lines.Add(new Line { Action = action, Key = key, Mask = mask, HasMask = mask != 0 });
        _sections.Add((Own, lines));
    }
    private static void SaveOwn()
    {
        var cfg = new ConfigFile(); global::ACGodot.SafeConfig.Load(cfg, UiCfg);
        if (cfg.HasSection("keys-own")) cfg.EraseSection("keys-own");
        int n = 0;
        foreach (var (section, lines) in _sections)
            if (section == Own) foreach (var l in lines) cfg.SetValue("keys-own", "k" + n++, $"{l.Action}|{l.Key}|{l.Mask}");
        if (n == 0) cfg.SetValue("keys-own", "none", "");
        foreach (var (action, _, _) in OwnDefaults) cfg.SetValue("keys-own-seen", action, true);
        global::ACGodot.SafeConfig.Save(cfg, UiCfg);
    }
    /// <summary>ACGodot's own commands back on their usual keys.</summary>
    public static void OwnToDefaults()
    {
        var cfg = new ConfigFile(); global::ACGodot.SafeConfig.Load(cfg, UiCfg);
        if (cfg.HasSection("keys-own")) cfg.EraseSection("keys-own");
        if (cfg.HasSection("keys-own-seen")) cfg.EraseSection("keys-own-seen");
        global::ACGodot.SafeConfig.Save(cfg, UiCfg);
        AddOwn(); Index(); Changed?.Invoke();
    }

    /// <summary>Gestures (done once) and poses (held): the keymap's name for each, what it's called, and the game's number for it.</summary>
    public static readonly (string name, string label, uint command)[] Motions =
    {
        ("MovementCommands.Ready", "Ready", 0x41000003), ("MovementCommands.Crouch", "Crouch", 0x41000012), ("MovementCommands.Sitting", "Sit", 0x41000013),
        ("MovementCommands.Sleeping", "Lay Down", 0x41000014),
        // (the gestures and poses the server shows to others: its own list)
        ("Emotes.AFKState", "Away (held)", 0x4300011B),
        ("Emotes.AkimboState", "Akimbo (held)", 0x430000F2),
        ("Emotes.AtEaseState", "At Ease (held)", 0x43000149),
        ("Emotes.ATOYOT", "ATOYOT (held)", 0x420000F9),
        ("Emotes.Beckon", "Beckon", 0x1300007A),
        ("Emotes.BeSeeingYou", "Be Seeing You", 0x1300007B),
        ("Emotes.BlowKiss", "Blow Kiss", 0x1300007C),
        ("Emotes.BowDeep", "Bow (held)", 0x430000EC),
        ("Emotes.Cheer", "Cheer", 0x1300004C),
        ("Emotes.ClapHands", "Clap", 0x1300007E),
        ("Emotes.ClapHandsState", "Clapping (held)", 0x430000ED),
        ("Emotes.Cringe", "Cringe", 0x13000091),
        ("Emotes.CrossArmsState", "Cross Arms (held)", 0x430000EE),
        ("Emotes.Cry", "Cry", 0x1300007F),
        ("Emotes.CurtseyState", "Curtsey (held)", 0x4300011A),
        ("Emotes.DrudgeDance", "Dance Step", 0x13000151),
        ("Emotes.DrudgeDanceState", "Drudge Dance (held)", 0x43000144),
        ("Emotes.HaveASeat", "Musical Chair", 0x13000152),
        ("Emotes.HaveASeatState", "Have a Seat (held)", 0x43000148),
        ("Emotes.HeartyLaugh", "Hearty Laugh", 0x13000089),
        ("Emotes.Helper", "Helper", 0x13000135),
        ("Emotes.Kneel", "Kneel (held)", 0x430000F7),
        ("Emotes.Knock", "Knock", 0x1300014F),
        ("Emotes.Laugh", "Laugh", 0x13000080),
        ("Emotes.LeanState", "Lean (held)", 0x430000F6),
        ("Emotes.MeditateState", "Meditate (held)", 0x4300011C),
        ("Emotes.MimeDrink", "Mime Drinking", 0x13000082),
        ("Emotes.MimeEat", "Mime Eating", 0x13000081),
        ("Emotes.Mock", "Mock", 0x130000CB),
        ("Emotes.Nod", "Nod", 0x13000083),
        ("Emotes.NudgeLeft", "Nudge Left", 0x1300014A),
        ("Emotes.NudgeRight", "Nudge Right", 0x1300014B),
        ("Emotes.Plead", "Plead (held)", 0x430000F8),
        ("Emotes.PointDown", "Point Down", 0x1300014E),
        ("Emotes.PointDownState", "Pointing Down (held)", 0x43000143),
        ("Emotes.PointLeft", "Point Left", 0x1300014C),
        ("Emotes.PointLeftState", "Pointing Left (held)", 0x43000140),
        ("Emotes.PointRight", "Point Right", 0x1300014D),
        ("Emotes.PointRightState", "Pointing Right (held)", 0x43000141),
        ("Emotes.Point", "Point (held)", 0x430000F0),
        ("Emotes.PossumState", "Play Possum (held)", 0x43000145),
        ("Emotes.PrayState", "Pray (held)", 0x430000EB),
        ("Emotes.ReadState", "Read (held)", 0x43000146),
        ("Emotes.Salute", "Salute (held)", 0x430000F3),
        ("Emotes.ScanHorizon", "Scan the Horizon", 0x13000150),
        ("Emotes.ScratchHead", "Scratch Head", 0x1300008B),
        ("Emotes.ScratchHeadState", "Scratching Head (held)", 0x430000F4),
        ("Emotes.ShakeFist", "Shake Fist", 0x13000079),
        ("Emotes.ShakeFistState", "Shaking Fist (held)", 0x430000EA),
        ("Emotes.ShakeHead", "Shake Head", 0x13000085),
        ("Emotes.Shiver", "Shiver", 0x13000094),
        ("Emotes.Shoo", "Shoo", 0x13000095),
        ("Emotes.Shrug", "Shrug", 0x13000086),
        ("Emotes.SitBackState", "Sit Back (held)", 0x4300013F),
        ("Emotes.SitCrossleggedState", "Sit Cross-legged (held)", 0x4300013E),
        ("Emotes.SitState", "Sit Down (held)", 0x4300013D),
        ("Emotes.Slouch", "Slouch (held)", 0x430000FA),
        ("Emotes.SmackHead", "Smack Head", 0x1300008C),
        ("Emotes.SnowAngelState", "Snow Angel (held)", 0x43000118),
        ("Emotes.Spit", "Spit", 0x13000097),
        ("Emotes.Surrender", "Surrender (held)", 0x430000FB),
        ("Emotes.TalktotheHandState", "Talk to the Hand (held)", 0x43000142),
        ("Emotes.TapFootState", "Tap Foot (held)", 0x430000F5),
        ("Emotes.Teapot", "Teapot", 0x130000CC),
        ("Emotes.ThinkerState", "Think (held)", 0x43000147),
        ("Emotes.WarmHands", "Warm Hands", 0x13000119),
        ("Emotes.Wave", "Wave", 0x13000087),
        ("Emotes.WaveHigh", "Wave High", 0x1300008E),
        ("Emotes.WaveLow", "Wave Low", 0x1300008F),
        ("Emotes.WaveState", "Waving (held)", 0x430000F1),
        ("Emotes.Winded", "Winded (held)", 0x430000FD),
        ("Emotes.Woah", "Whoa (held)", 0x430000FC),
        ("Emotes.YawnStretch", "Yawn", 0x13000090),
        ("Emotes.YMCA", "YMCA", 0x1200009B),
    };

    // ── reading and writing ──

    /// <summary>Reads the keys in use (once, when the game starts): the file chosen, else our own, else the one that came with the game.</summary>
    /// <summary>The game's commands on a key with these modifiers (1 Shift, 2 Ctrl, 4 Alt) - for a plugin's hotkeys to
    /// say when the game uses the key too (MelkTank's Settings > Commands > Hotkeys).</summary>
    public static string[] UsedBy(string keyName, int mask)
    {
        var l = new List<string>();
        foreach (var kv in _binds)
            foreach (var b in kv.Value)
                if (string.Equals(b.KeyName, keyName, StringComparison.OrdinalIgnoreCase) && (b.Mask & 7) == (mask & 7))
                {
                    int dot = kv.Key.IndexOf('.');
                    l.Add(dot >= 0 ? kv.Key[(dot + 1)..] : kv.Key);
                    break;
                }
        return l.ToArray();
    }

    public static void Start()
    {
        try { AppDomain.CurrentDomain.SetData("ACGodot.KeyUsedBy", new Func<string, int, string[]>(UsedBy)); } catch { }
        var cfg = new ConfigFile();
        string chosen = global::ACGodot.SafeConfig.Load(cfg, UiCfg) == Error.Ok ? (string)cfg.GetValue("keys", "file", "") : "";
        if (chosen.Length > 0 && Load(chosen, remember: false)) return;
        if (System.IO.File.Exists(OwnFile) && Load(OwnFile, remember: false)) return;
        if (Load(DefaultFile, remember: false)) { File = OwnFile; Save(); }
    }

    /// <summary>Loads a keymap file; false (and nothing changed) if it can't be read as one.</summary>
    public static bool Load(string path, bool remember = true)
    {
        try
        {
            if (!Parse(System.IO.File.ReadAllText(path))) return false;
            File = path;
            if (remember) Remember();
            AddOwn();
            Index();
            Changed?.Invoke();
            return true;
        }
        catch (Exception ex) { GD.PushWarning("keymap: " + ex.Message); return false; }
    }

    /// <summary>The keys as they came with the game.</summary>
    public static bool LoadDefaults()
    {
        string was = File;
        if (!Load(DefaultFile, remember: false)) return false;
        File = was.Length > 0 ? was : OwnFile;
        return true;
    }

    private static void Remember()
    {
        var cfg = new ConfigFile(); global::ACGodot.SafeConfig.Load(cfg, UiCfg);
        cfg.SetValue("keys", "file", File == OwnFile ? "" : File);
        global::ACGodot.SafeConfig.Save(cfg, UiCfg);
    }

    private static readonly Regex LineRx = new(@"^\s*(\w+)\s*\[\s*""[^""]*""\s*\[\s*(\d+)\s+(\w+)(?:\s+(\w+))?\s*\]\s*(0x[0-9A-Fa-f]+)?\s*(\w+)?\s*\]\s*$");

    private static bool Parse(string text)
    {
        var lines = text.Replace("\r", "").Split('\n');
        int at = Array.FindIndex(lines, l => l.Trim() == "Bindings");
        if (at < 0) return false;
        var sections = new List<(string, List<Line>)>();
        List<Line>? cur = null;
        for (int i = at + 2; i < lines.Length; i++)
        {
            string l = lines[i].Trim();
            if (l.Length == 0 || l == "[") continue;
            if (l == "]") { cur = null; continue; }
            var m = LineRx.Match(l);
            if (m.Success && cur != null)
            {
                cur.Add(new Line
                {
                    Action = m.Groups[1].Value, Device = m.Groups[2].Value, Key = m.Groups[3].Value, Sub = m.Groups[4].Value,
                    HasMask = m.Groups[5].Success, Mask = m.Groups[5].Success ? int.Parse(m.Groups[5].Value[2..], NumberStyles.HexNumber) : 0, Activation = m.Groups[6].Value,
                });
                continue;
            }
            if (Regex.IsMatch(l, @"^\w+$")) { cur = new List<Line>(); sections.Add((l, cur)); }
        }
        if (sections.Count == 0) return false;
        sections.RemoveAll(x => x.Item1 == Own);
        _header = string.Join("\r\n", lines.Take(at)).TrimEnd() + "\r\n";
        _sections.Clear(); _sections.AddRange(sections);
        return true;
    }

    // a line that is a key or a side button with a command of its own (the mouse's own lines are kept, not offered)
    private static bool Usable(Line l) => l.Sub.Length == 0 && l.Activation.Length == 0 && (l.Device == "0" ? Keys.ContainsKey(l.Key) : l.Device == "1" && ButtonOf(l.Key) is MouseButton.Middle or MouseButton.Xbutton1 or MouseButton.Xbutton2);

    private static void Index()
    {
        _binds.Clear(); _byKey.Clear();
        foreach (var (section, lines) in _sections)
            foreach (var l in lines)
            {
                if (!Usable(l)) continue;
                string name = section + "." + l.Action;
                if (!_binds.TryGetValue(name, out var list)) _binds[name] = list = new List<Bind>();
                list.Add(new Bind(l.Key, l.Mask));
                if (!_byKey.TryGetValue(l.Key, out var names)) _byKey[l.Key] = names = new List<string>();
                names.Add(name);
            }
    }

    /// <summary>Writes the keys to the file in use (or another, which becomes the one in use).</summary>
    public static bool Save(string? path = null)
    {
        try
        {
            var sb = new StringBuilder(_header.Length > 0 ? _header : "\"User Defined Keymap\" [ 00000000-0000-0000-0000-000000000000 ]\r\n");
            sb.Append("\r\nBindings\r\n[\r\n");
            foreach (var (section, lines) in _sections)
            {
                if (section == Own) continue;   // (ours: kept in our own settings, below)
                if (lines.Count == 0) { sb.Append($"  {section}\r\n\r\n"); continue; }
                sb.Append($"  {section}\r\n  [\r\n");
                foreach (var l in lines)
                    sb.Append($"    {l.Action} [ \"\" [ {l.Device} {l.Key}{(l.Sub.Length > 0 ? " " + l.Sub : "")} ]{(l.HasMask || l.Mask != 0 || l.Activation.Length > 0 ? $" 0x{l.Mask:X8}" : "")}{(l.Activation.Length > 0 ? " " + l.Activation : "")} ]\r\n");
                sb.Append("  ]\r\n\r\n");
            }
            sb.Length -= 2;
            sb.Append("]\r\n");
            string to = path ?? (File.Length > 0 ? File : OwnFile);
            System.IO.File.WriteAllText(to, sb.ToString());
            SaveOwn();
            if (path != null) { File = path; Remember(); }
            return true;
        }
        catch (Exception ex) { GD.PushWarning("keymap: " + ex.Message); return false; }
    }

    // ── the keys of a command, and setting them ──

    /// <summary>A command's keys (up to three are shown and set; "Section.Action").</summary>
    public static IReadOnlyList<Bind> Of(string name) => _binds.TryGetValue(name, out var l) ? l : Array.Empty<Bind>();

    /// <summary>Gives a command's nth key (0..2), or takes it away (an empty one). The same key on another command in the same section is taken off that one.</summary>
    public static void Set(string name, int n, Bind b)
    {
        int dot = name.IndexOf('.');
        if (dot < 0) return;
        string section = name[..dot], action = name[(dot + 1)..];
        int si = _sections.FindIndex(s => s.section == section);
        if (si < 0) { _sections.Add((section, new List<Line>())); si = _sections.Count - 1; }
        var lines = _sections[si].lines;
        if (!b.None) lines.RemoveAll(l => Usable(l) && l.Key == b.KeyName && l.Mask == b.Mask);   // (one command to a key)
        var mine = lines.Where(l => l.Action == action && Usable(l)).ToList();
        var fresh = b.None ? null : new Line { Action = action, Device = b.KeyName.StartsWith("DIMOFS") ? "1" : "0", Key = b.KeyName, Mask = b.Mask, HasMask = b.Mask != 0 };
        if (n < mine.Count)
        {
            int at = lines.IndexOf(mine[n]);
            lines.RemoveAt(at);
            if (fresh != null) lines.Insert(at, fresh);
        }
        else if (fresh != null)
        {
            int after = mine.Count > 0 ? lines.IndexOf(mine[^1]) + 1 : lines.Count;
            lines.Insert(after, fresh);
        }
        Index();
        Changed?.Invoke();
    }

    // ── asking: is this command's key down, was it the one pressed ──

    private static int MaskNow() => (Input.IsKeyPressed(Key.Shift) ? 1 : 0) | (Input.IsKeyPressed(Key.Ctrl) ? 2 : 0) | (Input.IsKeyPressed(Key.Alt) ? 4 : 0) | (Input.IsKeyPressed(Key.Meta) ? 8 : 0);

    // a key with modifiers held goes to the command set on exactly that; with none set on that, to the key's plain command
    // (so W still runs you forward with Shift - walk - held, and Alt+A strafes where A alone turns)
    private static bool Wins(string name, Bind b, int mask)
    {
        if (IsModifier(b.KeyName)) return true;
        if (b.Mask == mask) return true;
        if (b.Mask != 0) return false;
        if (_byKey.TryGetValue(b.KeyName, out var others))
            foreach (var o in others)
                foreach (var ob in _binds[o]) if (ob.KeyName == b.KeyName && ob.Mask == mask) return false;
        // (Ctrl, Alt or the Windows key held with a plain key isn't that key's plain command - Ctrl+D isn't "turn right")
        return (mask & ~1) == 0;
    }

    /// <summary>Whether one of a command's keys is held down now (for what goes on while a key is held: moving, turning the camera).</summary>
    public static bool Held(string name)
    {
        if (!_binds.TryGetValue(name, out var list)) return false;
        int mask = MaskNow();
        foreach (var b in list)
        {
            bool down = b.KeyName.StartsWith("DIMOFS") ? Input.IsMouseButtonPressed(ButtonOf(b.KeyName)) : Keys.TryGetValue(b.KeyName, out var k) && Input.IsKeyPressed(k);
            if (down && Wins(name, b, mask)) return true;
        }
        return false;
    }

    /// <summary>Whether a key just pressed is one of a command's keys.</summary>
    public static bool Is(InputEvent e, string name)
    {
        if (!_binds.TryGetValue(name, out var list)) return false;
        string? pressed = e is InputEventKey k ? NameOfAny(k.Keycode) : e is InputEventMouseButton mb ? NameOf(mb.ButtonIndex) : null;
        if (pressed == null) return false;
        int mask = e is InputEventWithModifiers m ? (m.ShiftPressed ? 1 : 0) | (m.CtrlPressed ? 2 : 0) | (m.AltPressed ? 4 : 0) | (m.MetaPressed ? 8 : 0) : 0;
        foreach (var b in list)
            if (Keys.TryGetValue(b.KeyName, out var bk) && e is InputEventKey ek ? bk == ek.Keycode && Wins(name, b, mask) : b.KeyName == pressed && Wins(name, b, mask)) return true;
        return false;
    }
    private static string? NameOfAny(Key k) => NameOf(k);

    /// <summary>A key press as a key to give a command (with the modifiers held); null for a modifier key on its own being held with others, or a key the game has no name for.</summary>
    public static Bind? FromEvent(InputEvent e)
    {
        if (e is InputEventKey { Pressed: true } k)
        {
            string? n = NameOf(k.Keycode);
            if (n == null) return null;
            bool mod = IsModifier(n);
            return new Bind(n, mod ? 0 : (k.ShiftPressed ? 1 : 0) | (k.CtrlPressed ? 2 : 0) | (k.AltPressed ? 4 : 0) | (k.MetaPressed ? 8 : 0));
        }
        if (e is InputEventMouseButton { Pressed: true } mb && NameOf(mb.ButtonIndex) is string bn) return new Bind(bn, 0);
        return null;
    }
}
