using System;
using System.Linq;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using DatReaderWriter.DBObjs;
using Godot;

namespace ACGodot.Objects;

/// <summary>
/// Keeps the buildings, objects and scenery around a point loaded. A landblock's parts are worked out on a worker
/// thread; on the main thread each model it uses becomes one MultiMesh (every copy of that model on the landblock
/// in one draw), one landblock per frame.
/// </summary>
public partial class ObjectStreamer : Node3D
{
    // (changed - Options > Video: what's loaded is gone over again straight away, not when you next cross into another landblock)
    private int _radius = 3;
    public int Radius { get => _radius; set { if (value == _radius) return; _radius = value; _center = (-1, -1); } }   // landblocks each way (7 x 7 around you)
    public int Loaded => _blocks.Count;
    public int Pending => _inFlight.Count;
    public int Instances { get; private set; }

    private Dats _dats = null!;
    private ObjectAssets _assets = null!;
    private Region _region = null!;
    private float[] _heights = null!;
    private readonly Dictionary<(int, int), Node3D?> _blocks = new();
    private readonly Dictionary<(int, int), int> _counts = new();
    private readonly Dictionary<(int, int), int> _spawnCounts = new();
    private readonly ConcurrentDictionary<(int, int), byte> _inFlight = new();
    private readonly ConcurrentQueue<((int, int) key, LandblockObjects.Result? r)> _ready = new();
    private readonly SemaphoreSlim _workers = new(Math.Max(1, System.Environment.ProcessorCount / 2));
    private (int, int) _center = (-1, -1);
    /// <summary>The cell the player is in (0 while not placed): a room's landblock is kept loaded with it.</summary>
    public uint KeepCell { get; set; }
    private (int, int)? _keep, _keptNow;
    private BaseMaterial3D.CullModeEnum _cull = BaseMaterial3D.CullModeEnum.Back;

    public ObjectAssets Assets => _assets;
    private ACGodot.Effects.ParticleWorld? _particles;
    private readonly Dictionary<(int, int), List<uint>> _effects = new();

    /// <summary>Where the particle effects of what's placed go.</summary>
    public void UseParticles(ACGodot.Effects.ParticleWorld particles) => _particles = particles;

    private uint AddEffects((int, int) lb, System.Numerics.Matrix4x4 world, Setup? setup, DatReaderWriter.Types.AnimationFrame? pose, bool always,
                            bool indoors = false)
    {
        if (_particles == null || setup == null || (!always && !ACGodot.Effects.ParticleWorld.HasScript(setup))) return 0;
        uint id = _particles.Add(world, setup, pose, indoors: indoors);
        if (!_effects.TryGetValue(lb, out var l)) _effects[lb] = l = new List<uint>();
        l.Add(id);
        return id;
    }
    private ACGodot.Creatures.CreatureAssets? _creatures;
    public int Creatures { get; private set; }

    /// <summary>A creature playing its idle cycle.</summary>
    internal sealed class Animated
    {
        public ACGodot.Creatures.CreatureAssets.Key Key;
        public Skeleton3D Skeleton = null!;
        public Node3D Node = null!;
        public double Phase;
        public AcDream.Core.Physics.AnimationSequencer? Seq;
        public double Last;   // when its sequencer was last moved on
        public uint Fx;       // its particle effects' id (0: none)
        public Selectable? Sel;   // what it is, to the rest of the game
    }
    private readonly List<Animated> _animated = new();
    private readonly Random _phase = new(1234);
    private const float AnimateRange = 90f;   // beyond this they hold still (and are small on screen anyway)

    private void Animate(Vector3 cam)
    {
        StepTurns();
        if (_creatures == null || _animated.Count == 0) return;
        double now = Time.GetTicksMsec() / 1000.0;
        float r2 = AnimateRange * AnimateRange;
        _animated.RemoveAll(a => !IsInstanceValid(a.Node));
        foreach (var a in _animated)
        {
            if (a.Node.GlobalPosition.DistanceSquaredTo(cam) >= r2) continue;
            if (a.Seq != null)
            {
                TestTrace.Last = $"animating {a.Sel?.Name ?? a.Key.Wcid.ToString()}";
                float dt = (float)Math.Min(now - a.Last, 0.25);   // after a spell out of range it just carries on
                a.Last = now;
                if (dt > 0f)
                {
                    var posed = a.Seq.Advance(dt);
                    _creatures.Pose(a.Key, a.Skeleton, posed);
                    if (a.Fx != 0) _particles?.SetParts(a.Fx, posed);
                    var hooks = a.Seq.ConsumePendingHooks();   // particles its motion makes (an aura, breath...), and sounds
                    ACGodot.Physics.Animations.Finish(a.Seq, hooks);
                    // (one the server moves about: its effects go with it)
                    if (a.Fx != 0 && a.Sel is { Remote: true }) _particles?.Move(a.Fx, ToAcWorld(a.Node.Transform));
                    if (a.Fx != 0) _particles?.Hooks(a.Fx, hooks);
                    if (Audio != null && hooks.Count > 0) Audio.Hooks(_creatures.SoundTableOf(a.Key), a.Node.GlobalPosition, hooks);
                    if (hooks.Count > 0 && a.Sel != null) CreatureHooks?.Invoke(a.Sel, hooks);
                    Drift(a, dt);
                }
            }
            else _creatures.Pose(a.Key, a.Skeleton, now + a.Phase);
        }
    }

    /// <summary>
    /// The motion's own movement, as the game moves things by the cycle they're playing (its velocity and turn): the
    /// birds and bats about the place fly their circles by it - the server never moves them, so they hung in the air
    /// flapping. Not for what the server is moving itself (a creature walking or chasing, a jump: those follow it).
    /// </summary>
    private void Drift(Animated a, float dt)
    {
        var vel = a.Seq!.CurrentVelocity;
        var om = a.Seq.CurrentOmega;
        if (vel.LengthSquared() < 1e-4f && MathF.Abs(om.Z) < 1e-3f) return;
        if (a.Sel != null && (a.Sel == Self || _movers.ContainsKey(a.Sel) || _jumps.ContainsKey(a.Sel) || a.Sel.Kind >= 3)) return;
        float scale = a.Sel?.Scale ?? 1f;
        if (a.Sel != null)
        {
            float yaw = a.Sel.Yaw + om.Z * dt;
            var fwd = new Vector3(-MathF.Sin(yaw), 0, -MathF.Cos(yaw));
            var right = new Vector3(MathF.Cos(yaw), 0, -MathF.Sin(yaw));
            var feet = a.Sel.Feet + (right * vel.X + fwd * vel.Y + Vector3.Up * vel.Z) * dt * scale;
            Place(a.Sel, feet, yaw);
        }
        else
        {
            a.Node.RotateY(om.Z * dt);
            var b = a.Node.Basis;
            a.Node.Position += (b.X.Normalized() * vel.X - b.Z.Normalized() * vel.Y + Vector3.Up * vel.Z) * dt;
        }
    }

    /// <summary>
    /// Something a creature of the server's holds (a monster's bow, a pet's mace): the item's model at the creature's
    /// holding place for it, in the item's placement there - as the player's own weapon is held. Null when it can't be
    /// (the creature not rigged, no such holding place, the item's model not to hand).
    /// </summary>
    public Node3D? Hold(Selectable holder, int look, uint where, uint placement)
    {
        if (_creatures == null || holder.Anim is not { } a || a.Skeleton == null || !IsInstanceValid(a.Skeleton)) return null;
        var (setup, _) = _creatures.EffectSource(a.Key);
        if (setup == null || !setup.HoldingLocations.TryGetValue((DatReaderWriter.Enums.ParentLocation)where, out var hold)) return null;
        var key = new ACGodot.Creatures.CreatureAssets.Key(look, 0, 0f);
        if (!_creatures.Prepare(key) || _creatures.Mesh(key) is not ArrayMesh mesh) return null;
        var (itemSetup, itemMadeIn) = _creatures.EffectSource(key);
        System.Numerics.Matrix4x4 adjust = System.Numerics.Matrix4x4.Identity;
        if (itemSetup != null && itemSetup.Parts.Count > 0)
        {
            // (from the pose its mesh was made in, as for one set down - see SetPlacement)
            var lying = AcDream.Core.Meshing.SetupMesh.Flatten(itemSetup, itemMadeIn);
            DatReaderWriter.Types.AnimationFrame? held = null;
            if (!itemSetup.PlacementFrames.TryGetValue((DatReaderWriter.Enums.Placement)placement, out held))
                itemSetup.PlacementFrames.TryGetValue(DatReaderWriter.Enums.Placement.Default, out held);
            if (held != null && lying.Count > 0 && System.Numerics.Matrix4x4.Invert(lying[0].PartTransform, out var inv))
                adjust = inv * AcDream.Core.Meshing.SetupMesh.Flatten(itemSetup, held)[0].PartTransform;
        }
        var f = hold.Frame;
        float sc = _creatures.ScaleOf(key);
        var holdM = System.Numerics.Matrix4x4.CreateFromQuaternion(f.Orientation) * System.Numerics.Matrix4x4.CreateTranslation(f.Origin);
        var m = System.Numerics.Matrix4x4.CreateScale(sc) * adjust * holdM;
        var xf = new Transform3D(new Basis(new Vector3(m.M11, m.M12, m.M13), new Vector3(m.M21, m.M22, m.M23), new Vector3(m.M31, m.M32, m.M33)),
                                 new Vector3(m.M41, m.M42, m.M43));
        var bone = new BoneAttachment3D { BoneIdx = hold.PartId, Name = "Held" };
        a.Skeleton.AddChild(bone);
        bone.AddChild(new MeshInstance3D { Mesh = mesh, Transform = xf });
        return bone;
    }

    // ── selecting (left click) and using (R) what ACE's world database placed ──

    /// <summary>Something placed from ACE's world database that can be selected: where it is and how big.</summary>
    public sealed class Selectable
    {
        public int Wcid, Type, Index;
        public string Name = "";
        public (int x, int y) Lb;
        public Vector3 Feet, Center;   // where it stands, and the middle of it (Godot)
        public float Radius, Top;  // roughly how big; the height of its top (Godot Y)
        internal Animated? Anim;
        public ACGodot.Creatures.CreatureAssets.Key Key;
        public bool Open;          // a door: open
        public int NextSound;      // the next of its sounds R plays
        public uint Cell;          // the cell it was placed in (a dungeon's or building's room, or 0 outdoors)
        public Node3D? Node;       // what's drawn (an animated one's holder: moving it moves the creature)
        public float Scale = 1f;
        public object? Fight;      // its fighting state (Combat.Fighter), once it has one
        public bool Gone;          // its landblock was unloaded
        /// <summary>What a server told of it when it was last looked at closely (null: not yet): its numbers, decimals and
        /// words by the game's property numbers - what plugins read a creature's or a person's details from.</summary>
        public Dictionary<int, int>? PropInts;
        public Dictionary<int, double>? PropFloats;
        public Dictionary<int, string>? PropStrings;
        /// <summary>Set any way up by the server (a board hung flat on a wall, a thing laid on its side): its whole turn, not just which way it faces.</summary>
        public System.Numerics.Quaternion? Tilt;
        /// <summary>Never selected, by a click or a key (a spell's bolt in flight, a ring's blades).</summary>
        public bool Unselectable;
        /// <summary>The server's description flags for it (stuck, door, portal, openable ...); 0: not a server's or not told.</summary>
        public uint Desc;
        /// <summary>A server's scenery (a mound, a bonfire, a tent): fixed in place, nothing to do with it - not selected or identified.</summary>
        public bool Scenery;
        public bool Corpse;        // a server's corpse (a thing of its own there, apart from the creature that died)
        public object? Item;       // an item lying on the ground (Combat.Item)
        public string BaseName = "";
        /// <summary>What it is, for the selection marks' colour: 0 an item or thing, 1 an NPC, 2 a monster.</summary>
        public int Kind;
        internal bool Boxed;       // a door's box measured from its drawn model
        /// <summary>The server's own (on a server): what it does and what's done to it are the server's to say.</summary>
        public bool Remote;
        /// <summary>Which way it faces (a server's thing: kept as it's placed and turned).</summary>
        public float Yaw;
        /// <summary>The server's number for it (0: not a server's).</summary>
        public uint Guid;
    }

    private static void DoorBox(Selectable sel, Aabb local, Transform3D xf) => BoxFromModel(sel, local, xf, 1.2f);

    /// <summary>
    /// Its box from its model's (a door; something lying on the ground - a staff lies along the ground from one end):
    /// the middle of what's drawn, as wide as it is, so a click anywhere on it selects it.
    /// </summary>
    private static void BoxFromModel(Selectable sel, Aabb local, Transform3D xf, float minHeight)
    {
        // the model's box as Godot has it, or (an animated one's mesh is in the game's frame, Z up) turned to Godot's
        foreach (bool acFrame in new[] { false, true })
        {
            Aabb b = local;
            if (acFrame)
            {
                Vector3 p = local.Position, e = local.End;
                var c1 = new Vector3(p.X, p.Z, -p.Y); var c2 = new Vector3(e.X, e.Z, -e.Y);
                b = new Aabb(c1.Min(c2), (c1 - c2).Abs());
            }
            var w = xf * b;
            if (w.Size.Y < minHeight || w.Size.Y > 6f || w.Size.Length() < 0.01f) continue;
            var c = w.GetCenter();
            if (new Vector2(c.X - xf.Origin.X, c.Z - xf.Origin.Z).Length() > 2.5f) continue;
            sel.Feet = new Vector3(c.X, w.Position.Y, c.Z);
            sel.Center = c;
            sel.Top = w.End.Y;
            sel.Radius = Math.Max(0.4f, Math.Max(w.Size.X, w.Size.Z) * 0.5f);
            sel.Boxed = true;
            return;
        }
    }

    /// <summary>
    /// A door's box from its drawn model (its own size is unknown and its place is its hinge, off to one side of the
    /// doorway): measured once it's drawn, so a click on the door itself selects it.
    /// </summary>
    /// <summary>
    /// An animated door's box from its parts as they stand shut (each part's model where its frame puts it): the drawn
    /// mesh of an animated thing has its parts piled at their own origins (its bones move them), so measured that way a
    /// portcullis came out a small box low down.
    /// </summary>
    private void BoxDoorFromParts(Selectable sel, ACGodot.Creatures.CreatureAssets.Key key, Transform3D holder)
    {
        if (_creatures == null) return;
        try
        {
            var (setup, pose) = _creatures.EffectSource(key);
            if (setup == null) return;
            var min = new System.Numerics.Vector3(float.MaxValue); var max = new System.Numerics.Vector3(float.MinValue);
            foreach (var part in AcDream.Core.Meshing.SetupMesh.Flatten(setup, pose))
            {
                if (_dats.Get<GfxObj>(part.GfxObjId) is not { } g || g.VertexArray?.Vertices == null) continue;
                foreach (var v in g.VertexArray.Vertices.Values)
                {
                    var w = System.Numerics.Vector3.Transform(new System.Numerics.Vector3(v.Origin.X, v.Origin.Y, v.Origin.Z), part.PartTransform);
                    min = System.Numerics.Vector3.Min(min, w); max = System.Numerics.Vector3.Max(max, w);
                }
            }
            if (min.X > max.X) return;
            // its corners (in the game's frame, Z up) into the world through its holder (whose axes are the game's)
            Aabb? box = null;
            for (int i = 0; i < 8; i++)
            {
                var c = holder * new Vector3((i & 1) == 0 ? min.X : max.X, (i & 2) == 0 ? min.Y : max.Y, (i & 4) == 0 ? min.Z : max.Z);
                box = box is { } b ? b.Expand(c) : new Aabb(c, Vector3.Zero);
            }
            if (box is not { } bx || bx.Size.Y < 0.5f || bx.Size.Y > 12f) return;
            var c0 = bx.GetCenter();
            sel.Feet = new Vector3(c0.X, bx.Position.Y, c0.Z);
            sel.Center = c0;
            sel.Top = bx.End.Y;
            sel.Radius = Math.Max(0.4f, Math.Max(bx.Size.X, bx.Size.Z) * 0.5f);
            sel.Boxed = true;   // (not measured again from its drawn mesh)
        }
        catch { }
    }

    private static void BoxDoor(Selectable sel)
    {
        if (sel.Boxed || sel.Type != 19 || sel.Node == null || !sel.Node.IsInsideTree()) return;
        // its drawn parts' box two ways: as Godot has them, and turned from the game's frame (Z up) - an animated door's
        // mesh is in the game's frame, where a leaf measured as it lies comes out a few cm tall. The taller is the door.
        Aabb? raw = null, turned = null;
        void Walk(Node n)
        {
            foreach (var c in n.GetChildren())
            {
                if (c is VisualInstance3D v)
                {
                    Aabb local = v.GetAabb();
                    var b1 = v.GlobalTransform * local;
                    Vector3 p = local.Position, e = local.End;
                    var c1 = new Vector3(p.X, p.Z, -p.Y); var c2 = new Vector3(e.X, e.Z, -e.Y);
                    var b2 = v.GlobalTransform * new Aabb(c1.Min(c2), (c1 - c2).Abs());
                    raw = raw is { } a ? a.Merge(b1) : b1;
                    turned = turned is { } t ? t.Merge(b2) : b2;
                }
                Walk(c);
            }
        }
        Walk(sel.Node);
        sel.Boxed = true;
        Aabb? box = null;
        foreach (var cand in new[] { raw, turned })
            if (cand is { } k && k.Size.Y >= 0.5f && k.Size.Y <= 8f && (box == null || k.Size.Y > box.Value.Size.Y)) box = k;
        if (box is not { } bx) return;
        var c0 = bx.GetCenter();
        if (new Vector2(c0.X - sel.Feet.X, c0.Z - sel.Feet.Z).Length() > 3f) return;   // not where it stands: leave it
        float h = Math.Max(bx.Size.Y, 2.2f);   // (never shorter than a doorway)
        sel.Feet = new Vector3(c0.X, bx.Position.Y, c0.Z);
        sel.Top = bx.Position.Y + h;
        sel.Center = new Vector3(c0.X, bx.Position.Y + h * 0.5f, c0.Z);
        sel.Radius = Math.Max(0.4f, Math.Max(bx.Size.X, bx.Size.Z) * 0.5f);
    }

    /// <summary>The room (a dungeon's or building's cell) a point is in, or 0 (near enough: the collision settles the exact one).</summary>
    public uint RoomCellAt(Vector3 godotPos)
    {
        var (x, y, z) = World.ToAc(godotPos);
        return LandblockObjects.RoomAt(_dats, new System.Numerics.Vector3(x, y, z));
    }

    /// <summary>The game's data on each kind of thing (looks from a server are added to it).</summary>
    public ACGodot.Creatures.SpawnData? SpawnInfo => _creatures?.Data;

    private readonly List<Selectable> _ground = new();
    private Node3D? _groundNode;

    /// <summary>Lays an item on the ground (its model, selectable; F picks it up). Returns it, or null if it has no model.</summary>
    public Selectable? AddGroundItem(object item, int wcid, string name, Vector3 feet, float yaw, bool alive = false)
    {
        Animated? live = null;
        if (_creatures == null) return null;
        var key = new ACGodot.Creatures.CreatureAssets.Key(wcid, 0, 0f);
        if (!_creatures.Prepare(key) || _creatures.Mesh(key) is not ArrayMesh mesh) return null;
        if (_groundNode == null) { _groundNode = new Node3D { Name = "Ground" }; AddChild(_groundNode); }
        float sc = _creatures.ScaleOf(key);
        var ac = System.Numerics.Matrix4x4.CreateScale(sc) * System.Numerics.Matrix4x4.CreateRotationZ(yaw);
        var holder = new Node3D { Transform = new Transform3D(ObjectAssets.Xf(ac).Basis, feet), Name = $"Item{wcid}" };
        if (_creatures.IsAnimated(key))
        {
            var (sk, skin) = _creatures.Rig(key);
            holder.AddChild(sk);
            var mi = new MeshInstance3D { Mesh = mesh, Skin = skin };
            sk.AddChild(mi);
            mi.Skeleton = mi.GetPathTo(sk);
            _creatures.Pose(key, sk, 0.0);
            if (alive)
            {
                // a thing of the server's that moves (a person, a creature, a door): its own motions, played like the world's
                live = new Animated { Key = key, Skeleton = sk, Node = holder, Phase = _phase.NextDouble() * 10.0,
                                      Seq = _creatures.Sequencer(key), Last = Time.GetTicksMsec() / 1000.0 };
                _animated.Add(live);
                // its effects, as the world's own creatures have theirs: what its model always shows (a portal's swirl is
                // particles) and what its motions make
                try { var (fxs, fxp) = _creatures.EffectSource(key); live.Fx = AddEffects((-3, -3), ToAcWorld(holder.Transform), fxs, fxp, true); }
                catch (Exception ex) { GD.PushWarning("effects: " + ex.Message); }
                if (live.Seq != null && _creatures.Data.Get(wcid)?.Type == 19)
                {
                    // (a door starts shut, so opening swings it from there)
                    try { live.Seq.SetCycle(0, DoorShut, 1f); for (int t = 0; t < 40; t++) live.Seq.Advance(0.1f); _creatures.Pose(key, sk, live.Seq.SampleCurrentPose()); }
                    catch (Exception ex) { GD.PushWarning("door: " + ex.Message); }
                }
            }
        }
        else holder.AddChild(new MeshInstance3D { Mesh = mesh });
        _groundNode.AddChild(holder);
        var sel = MakeSelectable(key, (-2, -2), -1, holder.Transform, mesh, live);
        sel.Node = holder; sel.Item = item; sel.Name = name; sel.Remote = alive; sel.Yaw = yaw;
        // its box from what's drawn (a long thing lying down reaches out from where it was put)
        // (not something that stands and moves - a person, a creature: its mesh is laid out part by part, and its size
        // is its model's own, as for the world's creatures)
        if (!_creatures.IsAnimated(key)) BoxFromModel(sel, mesh.GetAabb(), holder.Transform, 0f);
        // (a door the server placed: its box from its drawn model too, as the world's own doors)
        // (a door the server placed: its parts where they stand - the drawn mesh has them piled at its foot)
        if (sel.Type == 19) BoxDoorFromParts(sel, key, holder.Transform);
        // small things: a little bigger to click
        if (sel.Top - sel.Feet.Y < 0.3f) { sel.Top = sel.Feet.Y + 0.3f; sel.Center = sel.Feet + new Vector3(0, 0.15f, 0); }
        sel.Radius = Math.Max(sel.Radius, 0.3f);
        _ground.Add(sel);
        _selectables[(-2, -2)] = _ground;
        return sel;
    }

    /// <summary>
    /// A thing set down in one of its own poses (the server's placement: on a house's hook a weapon hangs flat, handle down;
    /// on a wall, a shield faces out) - its model turned from how it lies to that pose, as one held in a hand is.
    /// </summary>
    /// <summary>
    /// A thing the server lets fall (gravity) drawn resting on the ground, not sunk into it: the game's physics sets such
    /// a thing down on its own shape, so a Boundary Marker - a cube the server has on its side, its middle at its feet -
    /// sits up on the grass rather than half in it. Only the drawing is lifted; where the server has it stays.
    /// </summary>
    /// <summary>How a thing's look was made (for the test bridge): animated or still, the pose its parts were laid in.</summary>
    public string LookNote(Selectable sel)
    {
        if (_creatures == null) return "";
        var (su, pose) = _creatures.EffectSource(sel.Key);
        var w = _creatures.Data.Get(sel.Key.Wcid);
        string p0 = pose != null && pose.Frames.Count > 0 ? $"part 0 at {pose.Frames[0].Origin.X:0.###},{pose.Frames[0].Origin.Y:0.###},{pose.Frames[0].Origin.Z:0.###} turn {pose.Frames[0].Orientation.W:0.##},{pose.Frames[0].Orientation.X:0.##},{pose.Frames[0].Orientation.Y:0.##},{pose.Frames[0].Orientation.Z:0.##}" : "no pose (resting by default)";
        return $"look {sel.Key.Wcid}: animated {_creatures.IsAnimated(sel.Key)}, weenie placement {w?.Placement}, motion table {w?.MotionTable:X}, setup default motion table {(uint)(su?.DefaultMotionTable ?? 0):X}, scale {w?.Scale}, {p0}";
    }

    public void RestOnGround(Selectable sel)
    {
        if (sel.Node is not { } holder || !IsInstanceValid(holder) || Ground?.Invoke(sel.Feet) is not float g) return;
        float lo = float.MaxValue;
        void Walk(Node n)
        {
            if (n is MeshInstance3D mi && mi.Mesh != null) lo = Math.Min(lo, (mi.GlobalTransform * mi.GetAabb()).Position.Y);
            foreach (var c in n.GetChildren()) Walk(c);
        }
        Walk(holder);
        if (lo == float.MaxValue || lo >= g - 0.02f || g - lo > 3f) return;
        float up = g - lo;
        holder.Position += new Vector3(0, up, 0);
        sel.Center += new Vector3(0, up, 0); sel.Top += up;
    }

    public void SetPlacement(Selectable sel, uint placement)
    {
        if (_creatures == null || sel.Node is not { } holder || !IsInstanceValid(holder) || _creatures.IsAnimated(sel.Key)) return;
        var (itemSetup, madeIn) = _creatures.EffectSource(sel.Key);
        if (itemSetup == null || itemSetup.Parts.Count == 0) return;
        if (!itemSetup.PlacementFrames.TryGetValue((DatReaderWriter.Enums.Placement)placement, out var posed)) return;
        // (the pose the mesh was made in - its idle frame, which for a thing with no motions is its Default frame, not
        // its Resting one: a Boundary Marker told "resting" was left in its default, half in the ground)
        var lying = AcDream.Core.Meshing.SetupMesh.Flatten(itemSetup, madeIn);
        if (lying.Count == 0 || !System.Numerics.Matrix4x4.Invert(lying[0].PartTransform, out var inv)) return;
        // (the mesh was made lying - the setup's resting frame - and scaled by the object's scale: the posed frame in
        // place of the lying one, in that scale - a Boundary Marker, 2.5 times its size, stood its lantern up only
        // part of the way otherwise)
        float osc = _creatures.Data.Get(sel.Key.Wcid)?.Scale is float f0 && f0 > 0f ? f0 : 1f;
        var S = System.Numerics.Matrix4x4.CreateScale(osc);
        var adjust = System.Numerics.Matrix4x4.CreateScale(1f / osc) * inv * AcDream.Core.Meshing.SetupMesh.Flatten(itemSetup, posed)[0].PartTransform * S;
        var xf = new Transform3D(new Basis(new Vector3(adjust.M11, adjust.M12, adjust.M13), new Vector3(adjust.M21, adjust.M22, adjust.M23), new Vector3(adjust.M31, adjust.M32, adjust.M33)),
                                 new Vector3(adjust.M41, adjust.M42, adjust.M43));
        // (in the model's own frame - the holder turns that into the world's: Xf here turned it a second time, laying
        // everything set down this way on its side - a Boundary Marker's upright box lay flat)
        foreach (var c in holder.GetChildren()) if (c is MeshInstance3D mi) mi.Transform = xf;
    }

    /// <summary>A door the server says is open or shut: it swings (one with no motions of its own goes out of the way), with its sound.</summary>
    public void SetServerDoor(Selectable sel, bool open)
    {
        if (sel.Type != 19 || sel.Open == open) return;
        sel.Open = open;
        if (sel.Guid != 0) Physics?.SetServerThingSolid(sel.Guid, !open);
        if (sel.Anim?.Seq != null)
        {
            try { sel.Anim.Seq.SetCycle(0, open ? DoorOpen : DoorShut, 1f); }
            catch (Exception ex) { GD.PushWarning("door swing: " + ex.Message); }
        }
        else if (sel.Node != null) sel.Node.Visible = !open;
        uint table = _creatures?.SoundTableOf(sel.Key) ?? 0;
        bool played = Audio?.PlayFromTable(table, open ? DatReaderWriter.Enums.Sound.Open : DatReaderWriter.Enums.Sound.Close, sel.Center) == true;
        LastDoorSound = $"{sel.Name} {(open ? "opened" : "shut")}: sound table {table:X8}, {(Audio == null ? "no audio" : played ? "played" : "nothing played")}";
    }
    /// <summary>How the last server door's sound went (for /net).</summary>
    public string LastDoorSound = "";

    /// <summary>A sound the server says a thing makes (by the game's sound number), from the thing's own sounds.</summary>
    public void PlayThingSound(Selectable? sel, Vector3 at, uint sound, float volume)
    {
        if (_creatures == null || Audio == null) return;
        uint table = sel != null ? _creatures.SoundTableOf(sel.Key) : 0;
        if (table != 0) Audio.PlayFromTable(table, (DatReaderWriter.Enums.Sound)sound, at, volume);
    }

    /// <summary>A corpse the server put down: lying as its creature fell (it comes described standing).</summary>
    public void LayDead(Selectable sel)
    {
        if (sel.Anim?.Seq is not { } seq || _creatures == null) return;
        try { seq.SetCycle(0, 0x40000011, 1f); for (int t = 0; t < 60; t++) seq.Advance(0.1f); _creatures.Pose(sel.Anim.Key, sel.Anim.Skeleton, seq.SampleCurrentPose()); }
        catch (Exception ex) { GD.PushWarning("corpse: " + ex.Message); }
        // (lying down: its marks low, round where it lies)
        sel.Top = sel.Feet.Y + 0.6f; sel.Center = sel.Feet + new Vector3(0, 0.3f, 0); sel.Radius = Math.Max(sel.Radius, 0.8f);
    }

    /// <summary>Yourself, as something that can be selected (a click on your character): kept where you stand.</summary>
    public readonly Selectable Self = new() { Lb = (-3, -3), Index = -1, Kind = 1, Name = "you" };
    public void PlaceSelf(Vector3 feet, string name)
    {
        Self.Feet = feet; Self.Center = feet + new Vector3(0, 0.9f, 0); Self.Top = feet.Y + 1.8f; Self.Radius = 0.45f; Self.Name = name; Self.BaseName = name;
    }

    /// <summary>A thing of the server's moved or turned: where it stands now and which way it faces.</summary>
    public void MoveThing(Selectable sel, Vector3 feet, float yaw)
    {
        if (sel.Node == null) return;
        // (turning to face something it was told to - a monster about to shoot or cast at you: the server's places
        // during the turn carry the heading it had, and taking it called the turn off, so it shot facing away. Kept
        // turning till the server's own heading has come round to it)
        if (_turning.TryGetValue(sel, out var turningTo))
        {
            if (MathF.Abs(Mathf.Wrap(yaw - turningTo, -MathF.PI, MathF.PI)) < 0.25f) _turning.Remove(sel);
            else yaw = sel.Yaw;
        }
        if (_jumps.TryGetValue(sel, out var j))
        {
            if (j.v.Y < 0f && feet.Y <= sel.Feet.Y + 0.3f) { sel.Yaw = yaw; Land(sel, feet); return; }
            _jumps[sel] = (j.v, Math.Min(j.fromY, feet.Y), j.left);
            if (feet.DistanceTo(sel.Feet) > 4f) Place(sel, feet, yaw);
            return;
        }
        // on the move of itself (a player running): a little off where it's been carried to is made up as it goes, not in a
        // jump; far off (a teleport, a long gap), or standing, it's put there
        if (_movers.TryGetValue(sel, out var m) && m.Toward != null)
        {
            // chasing: its speed as the server has it going - a creature's run is its own pace (4 m/s a person's), and
            // run faster here it got ahead and was pulled back with every place the server sent
            double now = Time.GetTicksMsec() / 1000.0;
            if (m.SrvAt is Vector3 was)
            {
                double gap = now - m.SrvTime;
                float went = new Vector2(feet.X - was.X, feet.Z - was.Z).Length();
                if (gap > 0.15 && gap < 2.0 && went > 0.05f)
                    m.Speed = Math.Clamp(m.Speed * 0.4f + (float)(went / gap) * 0.6f, 0.5f, 15f);
                if (gap > 0.05 && gap < 3.0) m.SrvGap = m.SrvGap * 0.7 + gap * 0.3;
            }
            m.SrvAt = feet; m.SrvTime = now;
        }
        if (m != null && feet.DistanceTo(sel.Feet) < 3f)
        {
            m.Fix = feet - sel.Feet;
            // (chasing: it steers itself toward what it's after - the server's heading for it is a moment old)
            if (m.Turn == 0f && m.Toward == null) Place(sel, sel.Feet, yaw);
            return;
        }
        Place(sel, feet, yaw);
    }

    /// <summary>A thing of the server's turns to face a way: round to it at a person's pace, not all at once.</summary>
    public void TurnThing(Selectable sel, float yaw) { if (sel.Node != null) _turning[sel] = yaw; }

    /// <summary>A thing the server has turning round of itself (its omega: a spinning gem, a turning sign) - radians a
    /// second about the up axis; 0 stops it.</summary>
    public void SpinThing(Selectable sel, float perSecond) { if (MathF.Abs(perSecond) < 1e-3f || !float.IsFinite(perSecond)) _spinners.Remove(sel); else _spinners[sel] = perSecond; }
    private readonly Dictionary<Selectable, float> _spinners = new();

    /// <summary>How see-through the server says a thing is (0 solid, 1 not seen): a ghost, a wisp, a cloaked admin.</summary>
    public void SeeThrough(Selectable sel, float translucency)
    {
        if (sel.Node is not { } n || !IsInstanceValid(n) || !float.IsFinite(translucency)) return;
        // (the game's own translucent things are drawn by it more faintly than this would: half as see-through, and
        // never past 60% - banshees at the server's own 0.9 were all but gone)
        float t = Math.Clamp(translucency * 0.5f, 0f, 0.6f);
        void Walk(Node x) { if (x is GeometryInstance3D g) g.Transparency = t; foreach (var c in x.GetChildren()) Walk(c); }
        Walk(n);
    }
    private readonly Dictionary<Selectable, float> _turning = new();
    private double _turnedAt;

    // ── the server's creatures and people moving: what they're doing (stance, walking or running, an attack, lying
    // dead), and going after someone or to a spot - carried on here between the places the server gives ──

    private sealed class Mover
    {
        public float Speed;                  // metres a second, the way it faces (0: not going anywhere of itself)
        public float Side;                   // metres a second to its right (stepping sideways)
        public float Turn;                   // radians a second, to its right (turning on the spot, or as it goes)
        public Vector3 Fix;                  // how far off the server's last place it is: made up over a moment, not in a jump
        public Func<Vector3?>? Toward;       // going after this (a creature chasing; a spot walked to)
        public float StopWithin;
        public uint Style;
        public float RunRate;
        public Vector3? SrvAt;               // (chasing: the server's last place for it and when - how fast it really goes)
        public double SrvTime;
        public double SrvGap = 0.5;          // (how often the server's places come for it, seconds)
    }
    private readonly Dictionary<Selectable, Mover> _movers = new();
    private const uint MoRun = 0x44000007, MoWalk = 0x45000005, MoWalkBack = 0x45000006, MoReady = 0x41000003;
    private const uint MoDead = 0x40000011;
    /// <summary>A server's creature fell dead (its motion said so).</summary>
    public Action<Selectable>? ThingDied;
    /// <summary>The world's collision (on a server: its things are put into it as they come).</summary>
    public ACGodot.Physics.WorldPhysics? Physics;
    /// <summary>The land's height at a spot (outdoors; null where there's none): what a creature running across it stands on.</summary>
    public Func<Vector3, float?>? Ground;
    /// <summary>The last things the server's creatures were told to do (the test bridge's "motions").</summary>
    public readonly List<string> MotionLog = new();
    public void Note(string s) { MotionLog.Add($"{Time.GetTicksMsec() / 1000.0:0.00} {s}"); if (MotionLog.Count > 60) MotionLog.RemoveAt(0); }

    // ── things in flight (an arrow, a spell's bolt): the server says where they start and how fast; they fly on here ──
    private readonly Dictionary<Selectable, (Vector3 v, bool gravity)> _fliers = new();
    /// <summary>A thing of the server's in flight at this velocity (metres a second, Godot), falling if it's one that does.</summary>
    public void Fly(Selectable sel, Vector3 velocity, bool gravity) { _fliers[sel] = (velocity, gravity); Note($"{sel.Name}: in flight at {velocity.Length():0.#} m/s"); }

    /// <summary>A thing in flight has hit something (the server says it bursts): it stops there - flown on, a streak went through its target.</summary>
    public void Land(Selectable sel) { _fliers.Remove(sel); }

    /// <summary>A thing in flight with no model to draw (a spell's bolt is all particles): a glowing ball in its place.</summary>
    public Selectable AddGlow(string name, Vector3 at, Color color)
    {
        if (_groundNode == null) { _groundNode = new Node3D { Name = "Ground" }; AddChild(_groundNode); }
        var node = new MeshInstance3D
        {
            Mesh = new SphereMesh { Radius = 0.18f, Height = 0.36f, RadialSegments = 12, Rings = 6 },
            MaterialOverride = new StandardMaterial3D { ShadingMode = BaseMaterial3D.ShadingModeEnum.Unshaded, AlbedoColor = color, EmissionEnabled = true, Emission = color, EmissionEnergyMultiplier = 2f },
            Position = at, Name = "Missile",
        };
        node.AddChild(new OmniLight3D { LightColor = color, LightEnergy = 1.5f, OmniRange = 4f });
        _groundNode.AddChild(node);
        return new Selectable { Node = node, Feet = at, Center = at, Top = at.Y + 0.2f, Radius = 0.2f, Name = name, BaseName = name, Remote = true, Lb = (-2, -2), Index = -1 };
    }

    private void StepFliers(float dt)
    {
        foreach (var kv in new List<KeyValuePair<Selectable, (Vector3 v, bool gravity)>>(_fliers))
        {
            var sel = kv.Key; var (v, gravity) = kv.Value;
            if (sel.Gone || sel.Node == null || !IsInstanceValid(sel.Node)) { _fliers.Remove(sel); continue; }
            if (gravity) { v.Y -= 9.8f * dt; _fliers[sel] = (v, true); }
            Place(sel, sel.Feet + v * dt, sel.Yaw);
        }
    }

    /// <summary>What a thing of the server's is doing now: its stance (0: as it was), its motion at a speed, and things done once (a blow, a wave).</summary>
    public void SetThingMotion(Selectable sel, uint style, uint forward, float speed, IReadOnlyList<(uint motion, float speed)> once, float side = 0f, float turn = 0f)
    {
        if (sel.Anim?.Seq is not { } seq) return;
        // (a speed that isn't a sensible number - a message misread - would have the animation run without end)
        static float Sane(float v) => float.IsFinite(v) && v > 0.05f ? Math.Min(v, 4f) : 1f;
        // (a player backing up comes as walking forward at a speed below zero)
        bool backing = forward == MoWalk && float.IsFinite(speed) && speed < -0.05f;
        float backSpeed = backing ? Math.Max(speed, -4f) : 0f;
        if (backing) forward = MoWalkBack;
        speed = backing ? 1f : Sane(speed);
        TestTrace.Last = $"motion of {sel.Name}: style {style:X8} forward {forward:X8} speed {speed} +{once.Count}";
        Note($"{sel.Name}: style {style:X8} forward {forward:X8} speed {speed:0.##}" + (once.Count > 0 ? " once " + string.Join(",", once.Select(o => o.motion.ToString("X8"))) : ""));
        if (forward == MoDead)
        {
            // falling dead: from the stance it's in (the server gives the time that fall takes before the corpse takes
            // its place - putting its weapon away first would leave it standing till then), and walked over from now
            style = 0; speed = 1f;
            try { seq.RemoveAllLinkAnimations(); } catch { }
            _turning.Remove(sel);
            if (sel.Guid != 0) Physics?.SetServerThingSolid(sel.Guid, false);
            ThingDied?.Invoke(sel);
        }
        try
        {
            _cycles[sel] = (style, forward, speed);
            if (!_jumps.ContainsKey(sel)) seq.SetCycle(style, forward != 0 ? forward : MoReady, speed);
            foreach (var (m, s) in once) seq.PlayAction(m, Sane(s));
        }
        catch (Exception ex) { GD.PushWarning("thing motion: " + ex.Message); }
        // walking or running: it goes the way it faces until told otherwise (the server's places put it right)
        float go = forward == MoRun ? 4.0f * speed : forward == MoWalk ? 3.12f * speed : backing ? 3.12f * backSpeed : forward == MoWalkBack ? -3.12f * 0.65f * speed : 0f;
        // (a player's side-step and turn come with it: carried on the same way until the next word of them)
        float sideGo = float.IsFinite(side) ? Math.Clamp(side, -3f, 3f) * 1.25f : 0f;
        float turnGo = float.IsFinite(turn) ? Math.Clamp(turn, -1.5f, 1.5f) * 1.6f : 0f;
        if (go != 0f || sideGo != 0f || turnGo != 0f)
        {
            _turning.Remove(sel);
            _movers[sel] = new Mover { Speed = go * sel.Scale, Side = sideGo * sel.Scale, Turn = turnGo, Style = style, Fix = _movers.TryGetValue(sel, out var was) && was.Toward == null ? was.Fix : Vector3.Zero };
            if (go == 0f && sideGo != 0f && forward == 0) try { seq.SetCycle(style, sideGo > 0 ? 0x6500000Fu : 0x65000010u, Math.Abs(side)); _modded.Add(sel); } catch { }
            else if (go == 0f && sideGo == 0f && forward == 0) try { seq.SetCycle(style, turnGo > 0 ? 0x6500000Du : 0x6500000Eu, 1f); _modded.Add(sel); } catch { }
        }
        else _movers.Remove(sel);
        // (a side-step or turn is laid over the stance by the motion table, not a cycle of its own: the stand that came
        // after it left it playing - a player stood still, side-stepping on the spot. Taken off when it's no longer told)
        if (_modded.Contains(sel) && !(go == 0f && forward == 0 && (sideGo != 0f || turnGo != 0f)))
            UnStep(sel, seq, style, forward != 0 ? forward : MoReady, speed);
    }

    // the side-step / turn laid over a stance taken off - all four ways (left ones too: only the right ones were, and a
    // player who'd stepped or turned left went on doing it standing still)
    private void UnStep(Selectable sel, AcDream.Core.Physics.AnimationSequencer seq, uint style, uint cycle, float speed)
    {
        _modded.Remove(sel);
        try
        {
            foreach (uint m in new[] { 0x6500000Fu, 0x65000010u, 0x6500000Du, 0x6500000Eu })
                seq.PerformMovement(AcDream.Core.Physics.Motion.MotionTableMovement.StopInterpreted(m, 1f));
            if (!_jumps.ContainsKey(sel)) seq.SetCycle(style, cycle, speed);
        }
        catch { }
    }

    /// <summary>Whatever side-step or turn it was told last is over (the server now walks or turns it itself).</summary>
    public void StopStepping(Selectable sel)
    {
        if (!_modded.Contains(sel) || sel.Anim?.Seq is not { } seq) { _modded.Remove(sel); return; }
        var c = _cycles.TryGetValue(sel, out var cy) ? cy : (style: 0x8000003Du, forward: MoReady, speed: 1f);
        UnStep(sel, seq, c.style, c.forward != 0 ? c.forward : MoReady, c.speed);
    }

    /// <summary>A thing of the server's goes after something (or to a spot) at a run, stopping so far short.</summary>
    public void SendThingToward(Selectable sel, Func<Vector3?> toward, float stopWithin, float runRate, uint style)
    {
        if (sel.Anim?.Seq is not { } seq) return;
        runRate = float.IsFinite(runRate) && runRate > 0.05f ? Math.Min(runRate, 4f) : 1f;
        if (!float.IsFinite(stopWithin)) stopWithin = 0.6f;
        float speed = 4.0f * runRate * sel.Scale;
        // (already running after it - the server says so again and again as it goes: carried on, its run not started over)
        if (_movers.TryGetValue(sel, out var was) && was.Toward != null && was.Style == style && MathF.Abs(was.RunRate - runRate) < 0.01f)
        {
            was.Toward = toward; was.StopWithin = Math.Max(0.3f, stopWithin);
            return;
        }
        Note($"{sel.Name}: going after something, style {style:X8} rate {runRate:0.##}");
        try { seq.SetCycle(style, MoRun, runRate); } catch (Exception ex) { GD.PushWarning("thing motion: " + ex.Message); }
        _movers[sel] = new Mover { Speed = was?.Toward != null && was.SrvAt != null ? was.Speed : speed, RunRate = runRate, Toward = toward, StopWithin = Math.Max(0.3f, stopWithin), Style = style, Fix = was?.Fix ?? Vector3.Zero, SrvAt = was?.SrvAt, SrvTime = was?.SrvTime ?? 0 };
    }

    // ── someone else's jump: up and over as the server threw them, down again under their own weight ──
    private readonly Dictionary<Selectable, (Vector3 v, float fromY, float left)> _jumps = new();
    private readonly Dictionary<Selectable, (uint style, uint forward, float speed)> _cycles = new();
    private readonly HashSet<Selectable> _modded = new();   // (a side-step or turn laid over its stance)
    private const uint MoFalling = 0x40000015;

    /// <summary>A creature or player of the server's leaves the ground at this velocity (metres a second, Godot).</summary>
    public void JumpThing(Selectable sel, Vector3 velocity)
    {
        if (sel.Node == null || !float.IsFinite(velocity.LengthSquared()) || velocity.Length() > 40f) return;
        _jumps[sel] = (velocity, sel.Feet.Y, 6f);
        Note($"{sel.Name}: jumps at {velocity.Length():0.#} m/s");
        try { sel.Anim?.Seq?.SetCycle(_cycles.TryGetValue(sel, out var c) ? c.style : 0, MoFalling, 1f); } catch { }
    }

    private void StepJumps(float dt)
    {
        foreach (var kv in new List<KeyValuePair<Selectable, (Vector3 v, float fromY, float left)>>(_jumps))
        {
            var sel = kv.Key; var (v, fromY, left) = kv.Value;
            if (sel.Gone || sel.Node == null || !IsInstanceValid(sel.Node)) { _jumps.Remove(sel); continue; }
            v.Y -= 9.8f * dt; left -= dt;
            var feet = sel.Feet + v * dt;
            // down again: at the height they left from (the server's next place puts them right on a slope), or after a while
            if ((v.Y < 0f && feet.Y <= fromY) || left <= 0f) { Land(sel, new Vector3(feet.X, Math.Max(feet.Y, fromY), feet.Z)); continue; }
            _jumps[sel] = (v, fromY, left);
            Place(sel, feet, sel.Yaw);
        }
    }

    private void Land(Selectable sel, Vector3 feet)
    {
        _jumps.Remove(sel);
        Place(sel, feet, sel.Yaw);
        if (_cycles.TryGetValue(sel, out var c)) try { sel.Anim?.Seq?.SetCycle(c.style, c.forward != 0 ? c.forward : MoReady, c.speed); } catch { }
    }

    private void StepMovers(float dt)
    {
        foreach (var kv in new List<KeyValuePair<Selectable, Mover>>(_movers))
        {
            var sel = kv.Key; var m = kv.Value;
            if (sel.Gone || sel.Node == null || !IsInstanceValid(sel.Node)) { _movers.Remove(sel); continue; }
            if (_jumps.ContainsKey(sel)) continue;   // (in the air: carried by the jump)
            if (m.Toward == null)
            {
                float yawNow = sel.Yaw - m.Turn * dt;   // (to the right is the lesser heading)
                var fwd = new Vector3(-MathF.Sin(yawNow), 0, -MathF.Cos(yawNow));
                var right = new Vector3(MathF.Cos(yawNow), 0, -MathF.Sin(yawNow));
                var fix = m.Fix * Math.Min(1f, 8f * dt);
                m.Fix -= fix;
                Place(sel, sel.Feet + fwd * m.Speed * dt + right * m.Side * dt + fix, yawNow);
                continue;
            }
            if (m.Toward() is not Vector3 at) { _movers.Remove(sel); continue; }
            var d = at - sel.Feet;
            float flat = new Vector2(d.X, d.Z).Length();
            if (flat <= m.StopWithin + sel.Radius)
            {
                // there: standing ready (what it does next the server says)
                try { sel.Anim?.Seq?.SetCycle(m.Style, MoReady, 1f); } catch { }
                _movers.Remove(sel);
                continue;
            }
            float want = MathF.Atan2(-d.X, -d.Z);
            float diff = Mathf.Wrap(want - sel.Yaw, -MathF.PI, MathF.PI);
            float yaw = sel.Yaw + Math.Clamp(diff, -6f * dt, 6f * dt);
            float step = Math.Min(m.Speed * dt, flat - m.StopWithin - sel.Radius);
            // (only so far ahead of where the server last had it: a creature against a wall isn't moved by the server -
            // no new places come - and carried on here it ran into the wall, then was pulled back out. It goes on for a
            // little longer than the server's places usually take to come, and never more than 1.5 m past the last one)
            if (m.SrvAt is Vector3 srv)
            {
                double since = Time.GetTicksMsec() / 1000.0 - m.SrvTime;
                float lead = new Vector2(sel.Feet.X - srv.X, sel.Feet.Z - srv.Z).Length();
                if (since > Math.Clamp(m.SrvGap * 1.6, 0.4, 2.0) || lead > 1.5f) step = 0f;
            }
            var dir = new Vector3(d.X, 0, d.Z) / flat;
            // (its height eased toward what it's going to: up and down slopes with it)
            float y = sel.Feet.Y + Math.Clamp(d.Y, -3f * dt, 3f * dt);
            // (and how far off the server's last place it is, made up over a moment - snapped there each time, a chaser
            // jerked back with every position the server sent)
            var cfix = m.Fix * Math.Min(1f, 4f * dt);
            m.Fix -= cfix;
            var next = new Vector3(sel.Feet.X + dir.X * step + cfix.X, y + cfix.Y, sel.Feet.Z + dir.Z * step + cfix.Z);
            // outdoors: on the land under it (eased toward what it's after, it sank into a slope going down to you and
            // floated going up) - unless the land is well away from it (on a bridge, a roof, a ledge: left as it was)
            if (sel.Cell == 0 && Ground?.Invoke(next) is float gy && MathF.Abs(gy - sel.Feet.Y) < 1.5f) { next.Y = gy; m.Fix.Y = 0; }
            Place(sel, next, yaw);
        }
    }

    private void StepTurns()
    {
        TestTrace.Last = "turns and movers";
        double now = Time.GetTicksMsec() / 1000.0;
        float dt = (float)Math.Min(now - _turnedAt, 0.1);
        _turnedAt = now;
        if (dt > 0f && _jumps.Count > 0) StepJumps(dt);
        if (dt > 0f && _movers.Count > 0) StepMovers(dt);
        if (dt > 0f && _fliers.Count > 0) StepFliers(dt);
        if (dt > 0f && _spinners.Count > 0)
            foreach (var (ss, w) in new List<KeyValuePair<Selectable, float>>(_spinners))
            {
                if (ss.Gone || ss.Node == null || !IsInstanceValid(ss.Node)) { _spinners.Remove(ss); continue; }
                if (!_turning.ContainsKey(ss) && !_movers.ContainsKey(ss)) Place(ss, ss.Feet, ss.Yaw + w * dt);
            }
        if (_turning.Count == 0 || dt <= 0f) return;
        foreach (var kv in new List<KeyValuePair<Selectable, float>>(_turning))
        {
            var sel = kv.Key; float want = kv.Value;
            if (sel.Gone || sel.Node == null || !IsInstanceValid(sel.Node)) { _turning.Remove(sel); continue; }
            float diff = Mathf.Wrap(want - sel.Yaw, -MathF.PI, MathF.PI);
            float step = 3.5f * dt;
            if (MathF.Abs(diff) <= step) { Place(sel, sel.Feet, want); _turning.Remove(sel); }
            else Place(sel, sel.Feet, sel.Yaw + MathF.Sign(diff) * step);
        }
    }

    /// <summary>Stands a thing as the server has it turned (not upright: hung on a wall, laid over).</summary>
    public void TiltThing(Selectable sel, System.Numerics.Quaternion turn) { sel.Tilt = turn; Place(sel, sel.Feet, sel.Yaw); }

    private void Place(Selectable sel, Vector3 feet, float yaw)
    {
        if (sel.Node == null) return;
        sel.Yaw = yaw;
        var ac = System.Numerics.Matrix4x4.CreateScale(sel.Scale) * (sel.Tilt is { } tilt ? System.Numerics.Matrix4x4.CreateFromQuaternion(tilt) : System.Numerics.Matrix4x4.CreateRotationZ(yaw));
        sel.Node.Transform = new Transform3D(ObjectAssets.Xf(ac).Basis, feet);
        var shift = feet - sel.Feet;
        sel.Feet = feet; sel.Center += shift; sel.Top += shift.Y;
        if (sel.Guid != 0 && Physics != null && !_fliers.ContainsKey(sel))
        {
            var (ax, ay, az) = World.ToAc(feet);
            Physics.MoveServerThing(sel.Guid, new System.Numerics.Vector3(ax, ay, az), System.Numerics.Quaternion.CreateFromAxisAngle(System.Numerics.Vector3.UnitZ, yaw), sel.Cell, sel.Cell == 0);
        }
    }

    /// <summary>Takes an item off the ground (picked up).</summary>
    public void RemoveGroundItem(Selectable sel)
    {
        _ground.Remove(sel);
        _fliers.Remove(sel); _movers.Remove(sel); _turning.Remove(sel); _spinners.Remove(sel); _jumps.Remove(sel); _cycles.Remove(sel); _modded.Remove(sel);
        if (sel.Guid != 0) Physics?.RemoveServerThing(sel.Guid);
        if (sel.Anim is { Fx: not 0 } an) { _particles?.Remove(an.Fx); if (_effects.TryGetValue((-3, -3), out var fxl)) fxl.Remove(an.Fx); an.Fx = 0; }
        sel.Gone = true;
        sel.Node?.QueueFree();
        if (Selected == sel) Select(null);
    }

    /// <summary>The animation hooks a creature's motion fired this frame (attacks land on its AttackHooks).</summary>
    public Action<Selectable, IReadOnlyList<DatReaderWriter.Types.AnimationHook>>? CreatureHooks;

    /// <summary>Everything selectable that's loaded.</summary>
    public IEnumerable<Selectable> AllSelectables
    {
        get { foreach (var kv in _selectables) if (Here(kv.Key)) foreach (var s in kv.Value) yield return s; }
    }

    // ── in a dungeon: only its own landblock is there (the dungeons next to it in the landblock grid are other places,
    //    reached by other portals - their rooms and creatures aren't shown, picked or fought) ──
    private (int x, int y)? _only;
    /// <summary>The dungeon landblock you're in (null: outdoors - everything loaded is there).</summary>
    public (int x, int y)? OnlyLandblock
    {
        get => _only;
        set
        {
            if (_only == value) return;
            _only = value;
            foreach (var kv in _blocks) if (kv.Value != null) kv.Value.Visible = Here(kv.Key);
            if (Selected is { } s && !Here(s.Lb)) Select(null);
            OnlyChanged?.Invoke(value);
        }
    }
    private readonly Dictionary<(int, int), HashSet<uint>> _deep = new();
    /// <summary>Whether a room is one the outside can't be seen from (deep in a cave, a cellar).</summary>
    public bool IsDeepCell(uint cell) =>
        (cell & 0xFFFF) >= 0x0100 && (cell & 0xFFFF) < 0xFFFE && _deep.TryGetValue(((int)(cell >> 24), (int)((cell >> 16) & 0xFF)), out var d) && d.Contains(cell);
    private bool _outsideHidden;
    /// <summary>Underground in a cave or cellar: what stands on the landscape (buildings' outsides, trees, rocks) isn't drawn.</summary>
    public bool OutsideHidden
    {
        get => _outsideHidden;
        set
        {
            if (_outsideHidden == value) return;
            _outsideHidden = value;
            foreach (var n in GetTree().GetNodesInGroup("acg_outdoor"))
                if (n is Node3D n3) n3.Visible = !value && !(_hide == 1 && n3.IsInGroup("acg_shells"));
        }
    }
    /// <summary>Told when the dungeon you're in changes (null: outdoors).</summary>
    public Action<(int x, int y)?>? OnlyChanged;
    private bool Here((int x, int y) lb) => _only is not { } o || lb.x < 0 || lb == o;
    /// <summary>Whether it's in the place you are (in a dungeon: in that dungeon).</summary>
    public bool IsHere(Selectable s) => Here(s.Lb);

    /// <summary>Moves the selection's name over it (after it moved).</summary>
    public void FollowSelected()
    {
        if (Selected is { } sel && _selectLabel != null)
            _selectLabel.Position = new Vector3(sel.Center.X, sel.Top + 0.35f, sel.Center.Z);
    }
    private readonly Dictionary<(int, int), List<Selectable>> _selectables = new();
    public Audio.WorldAudio? Audio { get; set; }
    public Selectable? Selected { get; private set; }
    private Label3D? _selectLabel;

    /// <summary>A door opened or shut (its landblock, its place in the landblock's spawn list, open).</summary>
    public Action<(int x, int y), int, bool>? DoorChanged;

    private Selectable MakeSelectable(ACGodot.Creatures.CreatureAssets.Key key, (int, int) lb, int index, Transform3D xf, Mesh mesh, Animated? anim)
    {
        var w = _creatures!.Data.Get(key.Wcid);
        // how big it stands: its model's height and radius (the mesh's own box is in the wrong frame for animated ones,
        // which put the middle at their feet)
        var (h, r) = _creatures.SizeOf(key);
        Vector3 feet = xf.Origin;
        // a door's model gives no size: a doorway's height, and wide enough to cover it open as well as shut
        if ((w?.Type ?? 0) == 19 && h <= 0.05f) { h = 2.6f; r = 1.0f; }
        if (h <= 0.05f)
        {
            var box = mesh.GetAabb();
            float scale = xf.Basis.Scale.X;
            h = Math.Max(box.Size.Y * scale, 0.5f);
            r = Math.Max(Math.Max(box.Size.X, box.Size.Z) * 0.5f * scale, 0.3f);
        }
        var sel = new Selectable
        {
            Wcid = key.Wcid, Type = w?.Type ?? 0, Name = w?.Name is { Length: > 0 } n ? n : $"#{key.Wcid}", Index = index, Lb = lb,
            Feet = feet, Center = feet + new Vector3(0, h * 0.5f, 0), Radius = Math.Max(r, 0.3f), Top = feet.Y + h, Anim = anim, Key = key,
            Node = anim?.Node, Scale = _creatures.ScaleOf(key),
        };
        if (anim != null) anim.Sel = sel;
        sel.BaseName = sel.Name;
        // a door: its box from its model (the place it's put is its hinge, at one side of the doorway), so a click
        // anywhere on it selects it and the marks frame it
        if (sel.Type == 19) DoorBox(sel, mesh.GetAabb(), xf);
        // (a monster: it can be attacked and fights - a server's creature it says can be attacked, though we know nothing else of it)
        if (w != null && w.Attackable && (w.CombatTable != 0 || w.Exact && w.Type is 10 or 15)) sel.Kind = 2;
        else if (w != null && (w.Type == 10 || w.Type == 12) && anim != null) sel.Kind = 1;
        return sel;
    }

    /// <summary>What's under a point on the screen: the nearest selectable thing whose outline holds it.</summary>
    public Selectable? Pick(Camera3D cam, Vector2 screen)
    {
        Selectable? best = null;
        float bestDist = float.MaxValue, bestScore = float.MaxValue;
        Vector3 eye = cam.GlobalPosition;
        foreach (var kv in _selectables)
            if (Here(kv.Key))
            foreach (var sel in kv.Value)
            {
                if (sel.Node != null && !sel.Node.Visible) continue;   // gone (a corpse that's faded)
                if (sel.Unselectable || sel.Scenery) continue;
                BoxDoor(sel);
                float d = eye.DistanceTo(sel.Center);
                // (anything drawn can be clicked, however far: only past the camera's far plane is it out)
                if (d > cam.Far || cam.IsPositionBehind(sel.Center)) continue;
                // its outline on screen: a column from its feet to its top, as wide as it is
                var top = new Vector3(sel.Feet.X, sel.Top, sel.Feet.Z);
                if (cam.IsPositionBehind(sel.Feet) || cam.IsPositionBehind(top)) continue;
                Vector2 a = cam.UnprojectPosition(sel.Feet), b = cam.UnprojectPosition(top);
                Vector2 c = cam.UnprojectPosition(sel.Center), edge = cam.UnprojectPosition(sel.Center + cam.GlobalTransform.Basis.X * sel.Radius);
                float r = Math.Max(c.DistanceTo(edge), 8f);
                Vector2 ab = b - a;
                float t = ab.LengthSquared() > 1e-4f ? Math.Clamp((screen - a).Dot(ab) / ab.LengthSquared(), 0f, 1f) : 0f;
                float off = (a + ab * t).DistanceTo(screen);
                if (off > r) continue;
                // things heaped together (a pile on the ground): the one the mouse is most squarely on wins, the
                // nearer one only when that's about even
                float score = off / r + d * 0.01f;
                if (score >= bestScore) continue;
                best = sel; bestScore = score;
            }
        return best;
    }

    /// <summary>Selects something (or nothing): its name floats over it.</summary>
    public void Select(Selectable? sel)
    {
        if (sel != null && !Here(sel.Lb)) sel = null;   // (another dungeon's, next to this one in the grid: not here)
        if (sel is { Unselectable: true } or { Scenery: true }) return;       // (a spell in flight, scenery: whatever asked, what's selected stays)
        Selected = sel;
        if (sel == null) { if (_selectLabel != null) _selectLabel.Visible = false; return; }
        if (_selectLabel == null)
        {
            _selectLabel = new Label3D { Billboard = BaseMaterial3D.BillboardModeEnum.Enabled, FontSize = 40, PixelSize = 0.004f,
                                         Modulate = new Color(1f, 0.95f, 0.6f), OutlineSize = 10, NoDepthTest = true, Name = "Selected" };
            AddChild(_selectLabel);
        }
        _selectLabel.Text = sel.Name;
        _selectLabel.Position = new Vector3(sel.Center.X, sel.Top + 0.35f, sel.Center.Z);
        _selectLabel.Visible = false;   // the game shows no name over it: the four selection marks instead
    }

    // AC motion commands a door swings with
    private const uint DoorOpen = 0x4000000B, DoorShut = 0x4000000C;   // On, Off

    /// <summary>Uses the selected thing (R), from where the user stands. Returns what happened.</summary>
    public string Use(Vector3 from)
    {
        var sel = Selected;
        if (sel == null) return "nothing selected (left-click something to select it)";
        float d = from.DistanceTo(sel.Center);
        if (sel.Type == 19)
        {
            if (d > 4f) return $"{sel.Name} is too far away ({d:0} m)";
            sel.Open = !sel.Open;
            try { sel.Anim?.Seq?.SetCycle(0, sel.Open ? DoorOpen : DoorShut, 1f); }
            catch (Exception ex) { GD.PushWarning("door swing: " + ex.Message); }
            DoorChanged?.Invoke(sel.Lb, sel.Index, sel.Open);
            Audio?.PlayFromTable(_creatures!.SoundTableOf(sel.Key), sel.Open ? DatReaderWriter.Enums.Sound.Open : DatReaderWriter.Enums.Sound.Close, sel.Center);
            return sel.Open ? $"{sel.Name} opened" : $"{sel.Name} shut";
        }
        // a creature or NPC (for now): one of its sounds, the next each time, to hear what it has
        if (Audio != null && _creatures != null)
        {
            uint table = _creatures.SoundTableOf(sel.Key);
            var sounds = Audio.SoundsIn(table);
            if (sounds.Count == 0) return $"{sel.Name} has no sounds" + (table != 0 ? $" (table 0x{table:X8})" : "");
            sel.NextSound %= sounds.Count;
            var sound = sounds[sel.NextSound++];
            bool played = Audio.PlayAny(table, sound, sel.Center);
            return $"{sel.Name}: {sound} ({sel.NextSound} of {sounds.Count})" + (played ? "" : " - couldn't play it");
        }
        return $"{sel.Name}: nothing to do with that yet";
    }

    // K: a row of different creatures in front of the camera, to look them over (each press, the next lot)
    private List<int>? _variety;
    private int _varietyNext;
    private Node3D? _showcase;

    public string Showcase(Vector3 at, float yaw, Func<Vector3, float?> ground)
    {
        if (_creatures == null) return "no creature data";
        _variety ??= _creatures.Data.CreatureVariety();
        if (_variety.Count == 0) return "no creatures";
        if (_selectables.TryGetValue((-1, -1), out var oldShow)) foreach (var o in oldShow) o.Gone = true;
        _showcase?.QueueFree();
        if (_effects.Remove((-1, -1), out var oldFx) && _particles != null) foreach (uint id in oldFx) _particles.Remove(id);
        _showcase = new Node3D { Name = "Showcase" };
        var showSel = new List<Selectable>();
        _selectables[(-1, -1)] = showSel;
        if (Selected?.Lb == (-1, -1)) Select(null);
        AddChild(_showcase);
        var fwd = new Vector3(-MathF.Sin(yaw), 0, -MathF.Cos(yaw));
        var right = new Vector3(MathF.Cos(yaw), 0, -MathF.Sin(yaw));
        int first = _varietyNext, shown = 0;
        var names = new List<string>();
        for (int n = 0; n < 20 && shown < 20; n++)
        {
            int wcid = _variety[_varietyNext];
            _varietyNext = (_varietyNext + 1) % _variety.Count;
            var key = new ACGodot.Creatures.CreatureAssets.Key(wcid, 0, 0f);
            if (!_creatures.Prepare(key) || _creatures.Mesh(key) is not ArrayMesh mesh) continue;
            // two rows of ten, 7 m apart, starting 12 m ahead, facing the camera
            Vector3 p = at + fwd * (12f + 9f * (shown / 10)) + right * (7f * (shown % 10 - 4.5f));
            if (ground(p) is float g) p.Y = g;
            var ac = System.Numerics.Matrix4x4.CreateRotationZ(yaw + MathF.PI);
            var holder = new Node3D { Transform = new Transform3D(ObjectAssets.Xf(ac).Basis, p), Name = $"W{wcid}" };
            float sc = _creatures.ScaleOf(key);
            if (_creatures.IsAnimated(key))
            {
                holder.Scale = new Vector3(sc, sc, sc);
                var (sk, skin) = _creatures.Rig(key);
                holder.AddChild(sk);
                var mi = new MeshInstance3D { Mesh = mesh, Skin = skin };
                sk.AddChild(mi);
                mi.Skeleton = mi.GetPathTo(sk);
                var a = new Animated { Key = key, Skeleton = sk, Node = holder, Phase = _phase.NextDouble() * 10.0,
                                       Seq = _creatures.Sequencer(key), Last = Time.GetTicksMsec() / 1000.0 };
                _animated.Add(a);
                var (fs, fp) = _creatures.EffectSource(key);
                a.Fx = AddEffects((-1, -1), ToAcWorld(holder.Transform), fs, fp, true);
            }
            else
            {
                holder.AddChild(new MeshInstance3D { Mesh = mesh });
                var (fs, fp) = _creatures.EffectSource(key);
                AddEffects((-1, -1), ToAcWorld(holder.Transform), fs, fp, false);
            }
            _showcase.AddChild(holder);
            Animated? sa = _animated.Count > 0 && _animated[^1].Node == holder ? _animated[^1] : null;
            if (_creatures.Mesh(key) is { } smesh) showSel.Add(MakeSelectable(key, (-1, -1), -1, holder.Transform, smesh, sa));
            names.Add(_creatures.Data.Get(wcid)?.Name ?? wcid.ToString());
            shown++;
        }
        return $"creatures {first + 1}-{first + shown} of {_variety.Count} kinds (K: next lot): " + string.Join(", ", names);
    }

    // B: hide the buildings' outer models, then their rooms - to tell which of them draws something
    private int _hide;   // 0 all shown, 1 shells hidden, 2 rooms hidden

    public string CycleHide()
    {
        _hide = (_hide + 1) % 3;
        foreach (var n in GetTree().GetNodesInGroup("acg_shells"))
            if (n is Node3D n3) n3.Visible = _hide != 1 && !(_outsideHidden && n3.IsInGroup("acg_outdoor"));
        GetTree().CallGroup("acg_rooms", Node3D.MethodName.SetVisible, _hide != 2);
        return _hide switch { 1 => "building outsides hidden (B)", 2 => "building rooms hidden (B)", _ => "buildings shown (B)" };
    }

    // O: the buildings' (and caves') doorway openings drawn in see-through red, to check where they are
    private MeshInstance3D? _openingsView;

    public string ToggleOpenings()
    {
        if (_openingsView != null) { _openingsView.QueueFree(); _openingsView = null; return "openings hidden (O)"; }
        var verts = new List<Vector3>();
        foreach (var list in _portals.Values) foreach (var g in list) verts.AddRange(g.Tris);
        if (verts.Count == 0) return "no openings loaded (O)";
        var arrays = new Godot.Collections.Array();
        arrays.Resize((int)Mesh.ArrayType.Max);
        arrays[(int)Mesh.ArrayType.Vertex] = verts.ToArray();
        var mesh = new ArrayMesh();
        mesh.AddSurfaceFromArrays(Mesh.PrimitiveType.Triangles, arrays);
        mesh.SurfaceSetMaterial(0, new StandardMaterial3D
        {
            ShadingMode = BaseMaterial3D.ShadingModeEnum.Unshaded, AlbedoColor = new Color(1f, 0.1f, 0.1f, 0.45f),
            Transparency = BaseMaterial3D.TransparencyEnum.Alpha, CullMode = BaseMaterial3D.CullModeEnum.Disabled,
            NoDepthTest = true, DisableFog = true,
        });
        _openingsView = new MeshInstance3D { Mesh = mesh, Name = "OpeningsView" };
        AddChild(_openingsView);
        return $"{verts.Count / 3} opening triangles shown (O; press again to hide)";
    }

    // F7: a column of light over every creature and NPC loaded, to find them
    private bool _beacons;
    private readonly List<Node3D> _beaconNodes = new();
    private Mesh? _beaconMesh;
    private readonly Dictionary<int, StandardMaterial3D> _beaconMats = new();

    /// <summary>Shows or hides the columns of light over creatures (yellow) and vendors (green).</summary>
    public string ToggleBeacons()
    {
        _beacons = !_beacons;
        foreach (var n in _beaconNodes) if (IsInstanceValid(n)) n.Visible = _beacons;
        return _beacons ? "creature beacons on (F7)" : "creature beacons off (F7)";
    }

    private Node3D? Beacons(List<(ACGodot.Creatures.CreatureAssets.Key key, System.Numerics.Matrix4x4 world, bool indoors, int index, uint cell)> spawns)
    {
        if (_creatures == null) return null;
        _beaconMesh ??= new CylinderMesh { TopRadius = 0.25f, BottomRadius = 0.25f, Height = 80f, RadialSegments = 6, Rings = 1 };
        var byType = new Dictionary<int, List<Transform3D>>();
        foreach (var (k, w, _, _, _) in spawns)
        {
            int type = _creatures.Data.Get(k.Wcid)?.Type ?? 0;
            if (type != 10 && type != 12) continue;
            if (!byType.TryGetValue(type, out var l)) byType[type] = l = new List<Transform3D>();
            Vector3 at = ObjectAssets.Xf(w).Origin;
            l.Add(new Transform3D(Basis.Identity, at + new Vector3(0, 41f, 0)));
        }
        if (byType.Count == 0) return null;
        var node = new Node3D { Name = "Beacons", Visible = _beacons };
        foreach (var kv in byType)
        {
            if (!_beaconMats.TryGetValue(kv.Key, out var mat))
                _beaconMats[kv.Key] = mat = new StandardMaterial3D
                {
                    ShadingMode = BaseMaterial3D.ShadingModeEnum.Unshaded,
                    AlbedoColor = kv.Key == 12 ? new Color(0.3f, 1f, 0.4f, 0.55f) : new Color(1f, 0.85f, 0.2f, 0.55f),
                    Transparency = BaseMaterial3D.TransparencyEnum.Alpha,
                    BlendMode = BaseMaterial3D.BlendModeEnum.Add,
                    DisableFog = true,
                    CullMode = BaseMaterial3D.CullModeEnum.Disabled,
                    NoDepthTest = false,
                };
            var mm = new MultiMesh { TransformFormat = MultiMesh.TransformFormatEnum.Transform3D, Mesh = _beaconMesh, InstanceCount = kv.Value.Count };
            for (int i = 0; i < kv.Value.Count; i++) mm.SetInstanceTransform(i, kv.Value[i]);
            node.AddChild(new MultiMeshInstance3D { Multimesh = mm, MaterialOverride = mat, CastShadow = GeometryInstance3D.ShadowCastingSetting.Off });
        }
        _beaconNodes.RemoveAll(n => !IsInstanceValid(n));
        _beaconNodes.Add(node);
        return node;
    }

    /// <summary>Creatures and NPCs (from ACE's world database) to place as landblocks load.</summary>
    public void UseSpawns(ACGodot.Creatures.CreatureAssets creatures) => _creatures = creatures;

    /// <summary>Playing on a server: the world database's creatures, doors and chests aren't placed (the server sends what's there).</summary>
    public bool NoSpawns;
    /// <summary>A building's openings to the outside: the box around all its rooms, and the openings as triangles.</summary>
    private sealed record PortalGroup(Aabb Box, List<Vector3> Tris);
    private readonly Dictionary<(int, int), List<PortalGroup>> _portals = new();
    private bool _portalsDirty;
    private Vector3 _portalsAt = new(float.MaxValue, 0, 0);
    public const int MaxPortalBuildings = 64, MaxPortalTris = 1024;
    private const float PortalRange = 150f;

    /// <summary>
    /// Told when the doorway and window openings near the camera change: an RGBAF image and the number of buildings
    /// in it. Row 0 holds the buildings (3 texels each: box min + first triangle, box max + triangle count), row 1
    /// the triangles (3 texels each). The terrain shader drops ground that's seen through one of a building's
    /// openings and lies inside that building, so the rooms show through doors and windows without cutting holes
    /// in the ground anywhere else.
    /// </summary>
    public Action<ImageTexture, int, int>? PortalsChanged;
    private PortalGroup? _inside;
    /// <summary>For the on-screen text: whether the camera counts as inside a building, and how many openings it has.</summary>
    /// <summary>Whether the camera is in a building's rooms (as last worked out).</summary>
    public bool CameraInBuilding => _inside != null;
    public string InsideText => _inside == null ? "outside" : $"inside a building ({_inside.Tris.Count / 3} opening triangles)";
    private Vector3 _lastCam = new(float.MaxValue, 0, 0);

    private static bool SegmentCrosses(Vector3 a, Vector3 b, Vector3 v0, Vector3 v1, Vector3 v2)
    {
        Vector3 d = b - a, e1 = v1 - v0, e2 = v2 - v0;
        Vector3 q = d.Cross(e2);
        float det = e1.Dot(q);
        if (Math.Abs(det) < 1e-9f) return false;
        float inv = 1f / det;
        Vector3 sv = a - v0;
        float u = sv.Dot(q) * inv;
        if (u < 0f || u > 1f) return false;
        Vector3 r = sv.Cross(e1);
        float v = d.Dot(r) * inv;
        if (v < 0f || u + v > 1f) return false;
        float t = e2.Dot(r) * inv;
        return t > 0f && t <= 1f;
    }
    private ImageTexture? _portalTex;
    private Image? _portalImg;

    private void UpdatePortals(Vector3 cam)
    {
        // the building the camera is in, if any: then only ground seen out through its openings is drawn. Away from
        // the openings it's the room the camera is in (by the rooms' shapes). Right at an opening that can't be
        // told reliably, so there it follows the camera passing through the opening - the same test the ground's
        // shader uses, so the two agree at a doorway.
        PortalGroup? inside = _inside;
        bool jumped = _lastCam.DistanceSquaredTo(cam) > 25f;
        bool atOpening = false;
        foreach (var list in _portals.Values)
            foreach (var g in list)
            {
                if (!g.Box.Grow(1f).HasPoint(cam) && !g.Box.Grow(1f).HasPoint(_lastCam)) continue;
                int n = 0;
                for (int i = 0; i + 2 < g.Tris.Count; i += 3)
                {
                    Vector3 a = g.Tris[i], b = g.Tris[i + 1], c = g.Tris[i + 2];
                    var tb = new Aabb(a, Vector3.Zero).Expand(b).Expand(c).Grow(0.6f);
                    if (tb.HasPoint(cam)) atOpening = true;
                    if (!jumped && SegmentCrosses(_lastCam, cam, a, b, c)) n++;
                }
                if ((n & 1) == 1) inside = inside == g ? null : g;
            }
        if (jumped || !atOpening)
        {
            inside = null;
            if (RoomAt(cam) is { } room && _portals.TryGetValue(room.lb, out var here))
                foreach (var g in here) if (g.Box.Grow(0.01f).Encloses(room.box)) { inside = g; break; }
        }
        _lastCam = cam;
        if (inside != _inside) { _inside = inside; _portalsDirty = true; }
        if (!_portalsDirty && cam.DistanceSquaredTo(_portalsAt) < 4f) return;
        _portalsDirty = false;
        _portalsAt = cam;
        var near = new List<(float d, PortalGroup g)>();
        foreach (var list in _portals.Values)
            foreach (var g in list)
            {
                Vector3 c = cam.Clamp(g.Box.Position, g.Box.End);   // the nearest point of the building
                float d = c.DistanceTo(cam);
                if (d < PortalRange) near.Add((d, g));
            }
        near.Sort((x, y) => x.d.CompareTo(y.d));
        int width = Math.Max(MaxPortalBuildings, MaxPortalTris) * 3;
        _portalImg ??= Image.CreateEmpty(width, 2, false, Image.Format.Rgbaf);
        int nb = 0, nt = 0, insideIndex = -1;
        foreach (var (_, g) in near)
        {
            if (g == inside) insideIndex = nb;
            int tris = g.Tris.Count / 3;
            if (nb >= MaxPortalBuildings || nt + tris > MaxPortalTris) break;
            Vector3 lo = g.Box.Position, hi = g.Box.End;
            _portalImg.SetPixel(nb * 3 + 0, 0, new Color(lo.X, lo.Y, lo.Z, nt));
            _portalImg.SetPixel(nb * 3 + 1, 0, new Color(hi.X, hi.Y, hi.Z, tris));
            for (int i = 0; i < g.Tris.Count; i++)
            {
                Vector3 v = g.Tris[i];
                _portalImg.SetPixel(nt * 3 + i, 1, new Color(v.X, v.Y, v.Z, 1));
            }
            nt += tris;
            nb++;
        }
        if (_portalTex == null) _portalTex = ImageTexture.CreateFromImage(_portalImg);
        else _portalTex.Update(_portalImg);
        PortalsChanged?.Invoke(_portalTex, nb, insideIndex);
    }

    private readonly Dictionary<(int, int), (List<Aabb> boxes, List<Vector3[]> shapes)> _buildings = new();

    /// <summary>The building rooms (their boxes) nearest a point, within a distance, nearest first.</summary>
    public List<Aabb> RoomsNear(Vector3 p, float within, int most)
    {
        var found = new List<(float d, Aabb box)>();
        foreach (var b in _buildings.Values)
            foreach (var box in b.boxes)
            {
                Vector3 c = p.Clamp(box.Position, box.End);
                float d = c.DistanceTo(p);
                if (d <= within) found.Add((d, box));
            }
        found.Sort((a, b) => a.d.CompareTo(b.d));
        var list = new List<Aabb>(Math.Min(found.Count, most));
        for (int i = 0; i < found.Count && i < most; i++) list.Add(found[i].box);
        return list;
    }

    /// <summary>The landblock whose building the point is inside one of the rooms of, if any.</summary>
    public (int, int)? InBuilding(Vector3 p) => RoomAt(p)?.lb;

    /// <summary>The building room the point is inside, if any: its landblock and box.</summary>
    private ((int, int) lb, Aabb box)? RoomAt(Vector3 p)
    {
        var lb = World.LandblockAt(p);
        if (!_buildings.TryGetValue(lb, out var b)) return null;
        for (int i = 0; i < b.boxes.Count; i++)
            if (b.boxes[i].Grow(0.1f).HasPoint(p) && Inside(p, b.shapes[i])) return (lb, b.boxes[i]);
        return null;
    }

    /// <summary>
    /// Whether a point is inside a closed shape: a ray from it crosses the surface an odd number of times. (A box
    /// test alone isn't enough - a room's box reaches outside its walls wherever the room isn't square.)
    /// </summary>
    private static readonly Vector3[] RayDirs =
    {
        new Vector3(0.0123f, 1f, 0.0371f).Normalized(), new Vector3(0.0291f, -1f, 0.0173f).Normalized(),
        new Vector3(1f, 0.0213f, 0.0457f).Normalized(), new Vector3(-0.0331f, 0.0119f, 1f).Normalized(),
        new Vector3(0.577f, 0.571f, -0.583f).Normalized(),
    };

    private static bool Inside(Vector3 p, Vector3[] tris)
    {
        // rooms aren't always closed shapes in the data (a cave's rock has gaps): a ray can slip out through a gap
        // and count wrong, so five rays vote
        if (tris.Length < 3) return true;
        int votes = 0;
        foreach (var d in RayDirs)
        {
            int hits = 0;
            for (int i = 0; i + 2 < tris.Length; i += 3)
            {
                Vector3 e1 = tris[i + 1] - tris[i], e2 = tris[i + 2] - tris[i];
                Vector3 q = d.Cross(e2);
                float det = e1.Dot(q);
                if (Math.Abs(det) < 1e-9f) continue;
                float inv = 1f / det;
                Vector3 sv = p - tris[i];
                float u = sv.Dot(q) * inv;
                if (u < 0f || u > 1f) continue;
                Vector3 r = sv.Cross(e1);
                float v = d.Dot(r) * inv;
                if (v < 0f || u + v > 1f) continue;
                if (e2.Dot(r) * inv > 0f) hits++;
            }
            if ((hits & 1) == 1) votes++;
        }
        return votes >= 3;
    }

    private readonly Dictionary<(int, int), List<Aabb>> _dungeons = new();
    private readonly Dictionary<(int, int), List<(Vector2 a, Vector2 b, float y)>> _mapLines = new();

    /// <summary>The rooms' walls (buildings and dungeons) near a point, for the radar: from, to (x, z) and floor height.</summary>
    public IEnumerable<(Vector2 a, Vector2 b, float y)> MapLinesNear(Vector3 p, float reach)
    {
        var (lx, ly) = World.LandblockAt(p);
        for (int dx = -1; dx <= 1; dx++)
            for (int dy = -1; dy <= 1; dy++)
                if (_mapLines.TryGetValue((lx + dx, ly + dy), out var list))
                    foreach (var l in list)
                        if (MathF.Abs(l.a.X - p.X) < reach + 30 && MathF.Abs(l.a.Y - p.Z) < reach + 30) yield return l;
    }

    /// <summary>Whether a point is inside one of the loaded dungeons' rooms.</summary>
    public bool InDungeon(Vector3 p)
    {
        // any dungeon's rooms (a dungeon's rooms reach beyond its own landblock's square)
        foreach (var boxes in _dungeons.Values)
            foreach (Aabb b in boxes) if (b.Grow(0.5f).HasPoint(p)) return true;
        return false;
    }

    /// <summary>Whether a cell is one of a dungeon's rooms (not a building's).</summary>
    public bool IsDungeonCell(uint cell) =>
        (cell & 0xFFFF) >= 0x0100 && (cell & 0xFFFF) < 0xFFFE && _dungeons.ContainsKey(((int)(cell >> 24), (int)((cell >> 16) & 0xFF)));

    /// <summary>Told when a landblock's building-floor mask is ready (or gone: null).</summary>
    public Action<(int, int), byte[]?, int>? FloorMaskChanged;

    public void Setup(Dats dats, float[] heightTable)
    {
        _dats = dats;
        _heights = heightTable;
        _region = dats.Portal<Region>(0x13000000u) ?? throw new InvalidOperationException("Region 0x13000000 is missing");
        _assets = new ObjectAssets(dats);
    }

    private double _trimAt;
    /// <summary>Unloads models, textures and creature looks nothing on screen has used for a few minutes (Options > Video).</summary>
    public void TrimAssets(double maxAge = 180)
    {
        double now = Time.GetTicksMsec() / 1000.0;
        if (now < _trimAt) return;
        _trimAt = now + 30;
        try
        {
            var (m, mat, p) = _assets.Trim(maxAge);
            var (cm, cmat) = _creatures?.Trim(maxAge) ?? (0, 0);
            if (m + mat + p + cm + cmat > 0) global::ACGodot.DebugLogs.Print($"[assets] unloaded {m} models, {mat} materials, {p} read models, {cm} creature looks, {cmat} creature materials nothing was using");
        }
        catch (Exception ex) { GD.PushWarning("unloading graphics: " + ex.Message); }
    }

    public void Follow(Vector3 godotPos)
    {
        var c = World.LandblockAt(godotPos);
        // the landblock of the room the player is in, kept wherever the camera is: a dungeon's rooms can lie landblocks
        // from where they stand in the world, and its far end showed no walls or floor at all (running on air)
        (int, int)? keep = (KeepCell & 0xFFFF) >= 0x0100 && (KeepCell & 0xFFFF) < 0xFFFE ? ((int)(KeepCell >> 24), (int)((KeepCell >> 16) & 0xFF)) : null;
        if (keep != null) _keep = keep;   // (kept through a moment with no cell - placing again)
        else if (KeepCell != 0) _keep = null;
        if (c != _center || _keep != _keptNow) { _center = c; _keptNow = _keep; Refresh(); }
        UpdatePortals(godotPos);
        Animate(godotPos);
        if (!_ready.TryDequeue(out var item)) return;
        _inFlight.TryRemove(item.key, out _);
        if (!_blocks.ContainsKey(item.key) || item.r == null || (item.r.Parts.Count == 0 && item.r.Rooms == null && item.r.Spawns.Count == 0)) return;
        if (item.r.FloorMask != null) FloorMaskChanged?.Invoke(item.key, item.r.FloorMask, LandblockObjects.MaskSize);

        var node = new Node3D { Name = $"Objects_{item.key.Item1:X2}{item.key.Item2:X2}" };
        var byModel = new Dictionary<(ulong key, bool indoor), List<Transform3D>>();
        for (int pi = 0; pi < item.r.Parts.Count; pi++)
        {
            var p = item.r.Parts[pi];
            var mk = (p.Key, pi >= item.r.IndoorFrom && pi < item.r.IndoorTo);
            if (!byModel.TryGetValue(mk, out var list)) byModel[mk] = list = new List<Transform3D>();
            list.Add(ObjectAssets.Xf(p.World));
        }
        if (item.r.DeepCells.Count > 0) _deep[item.key] = item.r.DeepCells; else _deep.Remove(item.key);
        int count = 0;
        if (item.r.PortalTris is { Count: >= 3 } tris && item.r.PortalRooms != null)
        {
            var groups = new Dictionary<Aabb, PortalGroup>();
            for (int i = 0, t = 0; i + 2 < tris.Count && t < item.r.PortalRooms.Count; i += 3, t++)
            {
                Aabb box = item.r.PortalRooms[t];
                if (!groups.TryGetValue(box, out var g)) groups[box] = g = new PortalGroup(box, new List<Vector3>());
                g.Tris.Add(tris[i]); g.Tris.Add(tris[i + 1]); g.Tris.Add(tris[i + 2]);
            }
            _portals[item.key] = new List<PortalGroup>(groups.Values);
            if (item.key == World.LandblockAt(_lastCam)) _lastCam = new Vector3(float.MaxValue, 0, 0);   // look again where the camera is
            _portalsDirty = true;
        }
        if (item.r.BuildingBoxes != null && item.r.BuildingShapes != null) _buildings[item.key] = (item.r.BuildingBoxes, item.r.BuildingShapes);
        if (item.r.Rooms != null && _assets.MeshOf(item.r.Rooms, false) is ArrayMesh rooms)
        {
            var roomsMi = new MeshInstance3D { Mesh = rooms, Name = "Rooms", Visible = _hide != 2 };
            roomsMi.AddToGroup("acg_rooms");
            node.AddChild(roomsMi);
            count += item.r.Cells;
        }
        if (item.r.DungeonBoxes != null) _dungeons[item.key] = item.r.DungeonBoxes;
        if (item.r.MapLines.Count > 0) _mapLines[item.key] = item.r.MapLines;
        foreach (var kv in byModel)
        {
            ArrayMesh? mesh = _assets.Mesh(kv.Key.key);
            if (mesh == null) continue;
            var mm = new MultiMesh { TransformFormat = MultiMesh.TransformFormatEnum.Transform3D, Mesh = mesh, InstanceCount = kv.Value.Count };
            for (int i = 0; i < kv.Value.Count; i++) mm.SetInstanceTransform(i, kv.Value[i]);
            var mmi = new MultiMeshInstance3D { Multimesh = mm };
            bool isShell = (kv.Key.key >> 32) == 2;
            if (isShell) mmi.AddToGroup("acg_shells");
            if (!kv.Key.indoor) mmi.AddToGroup("acg_outdoor");
            mmi.Visible = !(isShell && _hide == 1) && !(_outsideHidden && !kv.Key.indoor);
            node.AddChild(mmi);
            count += kv.Value.Count;
        }
        if (_creatures != null && !NoSpawns && item.r.Spawns.Count > 0)
        {
            var byLook = new Dictionary<ACGodot.Creatures.CreatureAssets.Key, List<Transform3D>>();
            var indoorsOf = new Dictionary<ACGodot.Creatures.CreatureAssets.Key, List<bool>>();
            var indexOf = new Dictionary<ACGodot.Creatures.CreatureAssets.Key, List<int>>();
            var cellOf = new Dictionary<ACGodot.Creatures.CreatureAssets.Key, List<uint>>();
            foreach (var (k, w, inside, index, cell) in item.r.Spawns)
            {
                if (!byLook.TryGetValue(k, out var l)) { byLook[k] = l = new List<Transform3D>(); indoorsOf[k] = new List<bool>(); indexOf[k] = new List<int>(); cellOf[k] = new List<uint>(); }
                l.Add(ObjectAssets.Xf(w));
                indoorsOf[k].Add(inside);
                indexOf[k].Add(index);
                cellOf[k].Add((cell & 0xFFFFu) >= 0x100u ? cell : 0u);
            }
            var selectables = new List<Selectable>();
            _selectables[item.key] = selectables;
            int spawned = 0;
            foreach (var kv in byLook)
            {
                ArrayMesh? mesh = _creatures.Mesh(kv.Key);
                if (mesh == null) continue;
                if (_creatures.IsAnimated(kv.Key))
                {
                    // each one gets its own skeleton, posed every frame through its idle cycle (from its own point in it)
                    float sc = _creatures.ScaleOf(kv.Key);
                    for (int si = 0; si < kv.Value.Count; si++)
                    {
                        var xf = kv.Value[si];
                        var holder = new Node3D { Transform = xf.ScaledLocal(new Vector3(sc, sc, sc)), Name = $"W{kv.Key.Wcid}" };
                        var (sk, skin) = _creatures.Rig(kv.Key);
                        holder.AddChild(sk);
                        var mi = new MeshInstance3D { Mesh = mesh, Skin = skin };
                        sk.AddChild(mi);
                        mi.Skeleton = mi.GetPathTo(sk);
                        node.AddChild(holder);
                        var a = new Animated { Key = kv.Key, Skeleton = sk, Node = holder, Phase = _phase.NextDouble() * 10.0,
                                               Seq = _creatures.Sequencer(kv.Key), Last = Time.GetTicksMsec() / 1000.0 };
                        _animated.Add(a);
                        // a door starts shut (its "Off" state), so opening swings it from there rather than jumping open
                        if (a.Seq != null && _creatures.Data.Get(kv.Key.Wcid)?.Type == 19)
                        {
                            try { a.Seq.SetCycle(0, DoorShut, 1f); for (int t = 0; t < 40; t++) a.Seq.Advance(0.1f); _creatures.Pose(a.Key, a.Skeleton, a.Seq.SampleCurrentPose()); }
                            catch (Exception ex) { GD.PushWarning("door: " + ex.Message); }
                        }
                        var made = MakeSelectable(kv.Key, item.key, indexOf[kv.Key][si], holder.Transform, mesh, a);
                        made.Cell = cellOf[kv.Key][si];
                        if (made.Type == 19) BoxDoorFromParts(made, kv.Key, holder.Transform);
                        selectables.Add(made);
                        var (fxSetup, fxPose) = _creatures.EffectSource(kv.Key);
                        a.Fx = AddEffects(item.key, ToAcWorld(holder.Transform), fxSetup, fxPose, true);
                        if (a.Seq != null)
                        {
                            // each from its own point in the cycle
                            for (double t = a.Phase; t > 0; t -= 0.1) a.Seq.Advance(0.1f);
                            _creatures.Pose(a.Key, a.Skeleton, a.Seq.SampleCurrentPose());
                        }
                        else _creatures.Pose(a.Key, a.Skeleton, a.Phase);
                    }
                    spawned += kv.Value.Count;
                    continue;
                }
                var mm = new MultiMesh { TransformFormat = MultiMesh.TransformFormatEnum.Transform3D, Mesh = mesh, InstanceCount = kv.Value.Count };
                for (int i = 0; i < kv.Value.Count; i++)
                {
                    mm.SetInstanceTransform(i, kv.Value[i]);
                    var ms = MakeSelectable(kv.Key, item.key, indexOf[kv.Key][i], kv.Value[i], mesh, null);
                    if (ms.Type == 19) BoxDoorFromParts(ms, kv.Key, kv.Value[i]);
                    selectables.Add(ms);
                }
                node.AddChild(new MultiMeshInstance3D { Multimesh = mm, Name = $"W{kv.Key.Wcid}" });
                var (sSetup, sPose) = _creatures.EffectSource(kv.Key);
                if (ACGodot.Effects.ParticleWorld.HasScript(sSetup))
                    for (int i = 0; i < kv.Value.Count; i++) AddEffects(item.key, ToAcWorld(kv.Value[i]), sSetup, sPose, false, indoorsOf[kv.Key][i]);
                spawned += kv.Value.Count;
            }
            count += spawned;
            _spawnCounts[item.key] = spawned;
            if (Beacons(item.r.Spawns) is Node3D beacons) node.AddChild(beacons);
            Creatures += spawned;
        }
        foreach (var (setupId, world, inside) in item.r.Effects)
            AddEffects(item.key, world, _dats.Get<Setup>(setupId), null, false, inside);
        AddChild(node);
        _blocks[item.key] = node;
        if (node != null) node.Visible = Here(item.key);
        _counts[item.key] = count;
        Instances += count;
    }

    private void Refresh()
    {
        var want = new HashSet<(int, int)>();
        var (cx, cy) = _center;
        for (int dx = -Radius; dx <= Radius; dx++)
        for (int dy = -Radius; dy <= Radius; dy++)
        {
            int x = cx + dx, y = cy + dy;
            if (x >= 0 && y >= 0 && x <= 254 && y <= 254) want.Add((x, y));
        }
        if (_keep is { } kp && kp.Item1 >= 0 && kp.Item2 >= 0 && kp.Item1 <= 255 && kp.Item2 <= 255) want.Add(kp);
        var drop = new List<(int, int)>();
        foreach (var kv in _blocks) if (!want.Contains(kv.Key)) drop.Add(kv.Key);
        foreach (var k in drop)
        {
            _blocks[k]?.QueueFree();
            _blocks.Remove(k);
            if (_counts.Remove(k, out int n)) Instances -= n;
            if (_spawnCounts.Remove(k, out int sc)) Creatures -= sc;
            if (_selectables.Remove(k, out var goneSel))
            {
                foreach (var g in goneSel) g.Gone = true;
                if (Selected != null && Selected.Lb == k) Select(null);
            }
            FloorMaskChanged?.Invoke(k, null, 0);
            _dungeons.Remove(k);
            _deep.Remove(k);
            _mapLines.Remove(k);
            _buildings.Remove(k);
            if (_effects.Remove(k, out var fx) && _particles != null) foreach (uint id in fx) _particles.Remove(id);
            if (_portals.Remove(k, out var gone)) { _portalsDirty = true; if (_inside != null && gone.Contains(_inside)) _inside = null; }
        }
        var add = new List<(int, int)>();
        foreach (var k in want) if (!_blocks.ContainsKey(k)) add.Add(k);
        add.Sort((a, b) => (Math.Abs(a.Item1 - cx) + Math.Abs(a.Item2 - cy)).CompareTo(Math.Abs(b.Item1 - cx) + Math.Abs(b.Item2 - cy)));
        foreach (var k in add)
        {
            _blocks[k] = null;
            if (!_inFlight.TryAdd(k, 0)) continue;
            var key = k;
            Task.Run(async () =>
            {
                await _workers.WaitAsync();
                try { _ready.Enqueue((key, LandblockObjects.Build(_dats, _assets, _region, _heights, key.Item1, key.Item2, _creatures))); }
                catch (Exception ex) { GD.PushError($"objects {key.Item1:X2}{key.Item2:X2}: {ex.Message}"); _ready.Enqueue((key, null)); }
                finally { _workers.Release(); }
            });
        }
    }

    /// <summary>A Godot transform (Godot world) as an AC world matrix (row vectors, Z up), for effects.</summary>
    private static System.Numerics.Matrix4x4 ToAcWorld(Transform3D t)
    {
        // the transforms here come from ObjectAssets.Xf: their basis columns are AC's X, Y, Z axes in Godot's
        // coordinates, the origin a Godot point; AC (x, y, z) = Godot (x, -z, y)
        static System.Numerics.Vector3 A(Vector3 g) => new(g.X, -g.Z, g.Y);
        var ax = A(t.Basis.Column0); var ay = A(t.Basis.Column1); var az = A(t.Basis.Column2);
        var o = A(t.Origin);
        return new System.Numerics.Matrix4x4(ax.X, ax.Y, ax.Z, 0, ay.X, ay.Y, ay.Z, 0, az.X, az.Y, az.Z, 0, o.X, o.Y, o.Z, 1);
    }

    /// <summary>F6: which faces are hidden on models (back, front, none) - to check the winding.</summary>
    public string CycleCulling()
    {
        _cull = _cull switch
        {
            BaseMaterial3D.CullModeEnum.Back => BaseMaterial3D.CullModeEnum.Front,
            BaseMaterial3D.CullModeEnum.Front => BaseMaterial3D.CullModeEnum.Disabled,
            _ => BaseMaterial3D.CullModeEnum.Back,
        };
        _assets.SetCulling(_cull);
        return "model faces culled: " + _cull;
    }
}
