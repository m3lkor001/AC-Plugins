using System;
using System.Collections.Generic;
using System.Numerics;
using AcDream.Core.Meshing;
using AcDream.Core.Physics;
using AcDream.Core.World;
using DatReaderWriter.DBObjs;
using DatReaderWriter.Types;

namespace ACGodot.Objects;

/// <summary>
/// What stands on a landblock: its placed objects and buildings (LandBlockInfo) and the procedural scenery (trees,
/// rocks, bushes) the Region places from each cell's terrain type. The rules are OpenAC's (LandblockLoader,
/// SceneryGenerator, SetupMesh); the result is a list of model parts with their AC world transforms.
/// </summary>
public static class LandblockObjects
{
    public readonly record struct Part(ulong Key, Matrix4x4 World);   // a model id, or ObjectAssets.CellKey for a room

    public sealed class Result
    {
        public readonly List<Part> Parts = new();
        public int Buildings, Objects, Scenery, Cells;
        /// <summary>The parts from IndoorFrom up to IndoorTo stand in rooms; the rest are out on the landscape.</summary>
        public int IndoorFrom, IndoorTo;
        /// <summary>Rooms the outside can't be seen from (deep in a cave, a cellar): there the landscape isn't drawn.</summary>
        public readonly HashSet<uint> DeepCells = new();
        /// <summary>Where building floors lie on the ground (0.25 m squares, 768 x 768, row = north): the terrain isn't
        /// drawn there, so it can't poke through floors. Null when the landblock has no ground-level rooms.</summary>
        public byte[]? FloorMask;
        /// <summary>All the landblock's rooms joined into one mesh (Godot world space).</summary>
        public ObjectAssets.Prepared? Rooms;
        /// <summary>A dungeon landblock (rooms but no buildings): the rooms' boxes (Godot world space), to tell when
        /// the camera is inside - the landscape isn't drawn there.</summary>
        public List<Godot.Aabb>? DungeonBoxes;
        /// <summary>Buildings' rooms: their boxes (Godot world space) - while the camera is in one, the ground is cut
        /// under the floors (the floor mask) - and the doorway and window openings to the outside, as triangles in
        /// Godot world space, that "open" the walls so the rooms show through them.</summary>
        public List<Godot.Aabb>? BuildingBoxes;
        /// <summary>Each building room's whole surface as triangles (Godot world space, openings included), in the
        /// same order as BuildingBoxes: a closed shape, to tell whether a point is really inside the room.</summary>
        public List<Godot.Vector3[]>? BuildingShapes;
        /// <summary>The rooms' walls where they meet their floors, for the radar's map: from, to (Godot x, z) and the floor's height.</summary>
        public readonly List<(Godot.Vector2 a, Godot.Vector2 b, float y)> MapLines = new();
        public List<Godot.Vector3>? PortalTris;
        /// <summary>For each opening triangle, the box of the room it opens into (Godot world space).</summary>
        public List<Godot.Aabb>? PortalRooms;
        /// <summary>Creatures, NPCs and placed objects from ACE's world database: each look and where it stands.</summary>
        public readonly List<(ACGodot.Creatures.CreatureAssets.Key key, Matrix4x4 world, bool indoors, int index, uint cell)> Spawns = new();   // index: its place in SpawnData.ForLandblock's list (the collision's id for it)
        /// <summary>Placed things whose Setup has effects of its own (fires, fountains, glows): the Setup and where.</summary>
        public readonly List<(uint setup, Matrix4x4 world, bool indoors)> Effects = new();   // indoors: in a cell (a room)
        /// <summary>The lights placed things carry (lamps, torches, braziers): AC world position, colour, intensity, reach.</summary>
        public readonly List<(Vector3 at, DatReaderWriter.Types.ColorARGB color, float intensity, float falloff, bool indoors)> Lights = new();
        /// <summary>Models whose texture moves (a waterfall, lava): the model and its speed (texture widths a second).</summary>
        public readonly Dictionary<uint, System.Numerics.Vector2> Scrolls = new();
    }

    /// <summary>Builds the part list (any thread). Models are prepared in <paramref name="assets"/> as it goes.</summary>
    public static Result Build(Dats dats, ObjectAssets assets, Region region, float[] heightTable, int lbX, int lbY,
                               ACGodot.Creatures.CreatureAssets? creatures = null)
    {
        var r = new Result();
        uint lbId = ((uint)lbX << 24) | ((uint)lbY << 16) | 0xFFFFu;
        LoadedLandblock? lb = LandblockLoader.Load(dats, lbId);
        if (lb == null) return r;
        var offset = new Vector3(lbX * 192f, lbY * 192f, 0f);

        // placed objects and buildings
        foreach (WorldEntity e in lb.Entities)
        {
            Matrix4x4 root = Matrix4x4.CreateFromQuaternion(e.Rotation) * Matrix4x4.CreateTranslation(e.Position + offset);
            int before = r.Parts.Count;
            AddModel(dats, assets, r, e.SourceGfxObjOrSetupId, Matrix4x4.Identity, root, shell: e.IsBuildingShell);
            NoteEffects(dats, r, e.SourceGfxObjOrSetupId, root, false);
            if (r.Parts.Count > before) { if (e.IsBuildingShell) r.Buildings++; else r.Objects++; }
        }

        LandBlockInfo? info = dats.Get<LandBlockInfo>((lbId & 0xFFFF0000u) | 0xFFFEu);

        // rooms: building interiors and dungeons (EnvCells 0xXXYY0100 on), with the objects placed in them
        if (info != null)
        {
            uint first = (lbId & 0xFFFF0000u) | 0x0100u;
            var rooms = new List<(ulong, Matrix4x4)>();
            var cellsById = new Dictionary<uint, (EnvCell cell, Matrix4x4 at)>();
            var portalCell = new List<uint>();                  // the room each opening triangle belongs to
            var boxes = new Dictionary<uint, Godot.Aabb>();
            // a dungeon has no way out to the landscape; a cave with a mouth onto the landscape is handled like a
            // building (its openings show it from outside, and the ground is cut away inside), buildings or not
            bool dungeon = info.Buildings.Count == 0;
            if (dungeon)
                for (uint i = 0; i < info.NumCells && dungeon; i++)
                    if (dats.Get<EnvCell>(first + i) is EnvCell c)
                        foreach (var portal in c.CellPortals) if (portal.OtherCellId == 0xFFFF) { dungeon = false; break; }
            if (dungeon && info.NumCells > 0) r.DungeonBoxes = new List<Godot.Aabb>();
            if (!dungeon && info.NumCells > 0) { r.BuildingBoxes = new List<Godot.Aabb>(); r.BuildingShapes = new List<Godot.Vector3[]>(); r.PortalTris = new List<Godot.Vector3>(); r.PortalRooms = new List<Godot.Aabb>(); }
            r.IndoorFrom = r.Parts.Count;
            var leftOver = LeftOverCells(id => dats.Get<EnvCell>(id), info, first);
            for (uint i = 0; i < info.NumCells; i++)
            {
                uint cellId = first + i;
                if (leftOver.Contains(cellId)) continue;
                EnvCell? cell = dats.Get<EnvCell>(cellId);
                if (cell == null) continue;
                if (!cell.Flags.HasFlag(DatReaderWriter.Enums.EnvCellFlags.SeenOutside)) r.DeepCells.Add(cellId);
                assets.PrepareCell(cell, cellId);
                Matrix4x4 at = Matrix4x4.CreateFromQuaternion(cell.Position.Orientation) * Matrix4x4.CreateTranslation(cell.Position.Origin + offset);
                rooms.Add((ObjectAssets.CellKey(cellId), at));
                r.Cells++;
                if (r.DungeonBoxes != null && CellBox(dats, cell, at) is Godot.Aabb box) r.DungeonBoxes.Add(box);
                if (r.BuildingBoxes != null)
                {
                    if (CellBox(dats, cell, at) is Godot.Aabb bbox)
                    {
                        r.BuildingBoxes.Add(bbox);
                        r.BuildingShapes!.Add(CellShape(dats, cell, at));
                        int n = r.PortalTris!.Count;
                        AddOutsidePortals(dats, cell, at, r.PortalTris!);
                        for (int t = n; t < r.PortalTris.Count; t += 3) portalCell.Add(cellId);
                        boxes[cellId] = bbox;
                    }
                }
                cellsById[cellId] = (cell, at);
                AddMapLines(dats, cell, at, r.MapLines);
                foreach (Stab stab in cell.StaticObjects)
                {
                    Matrix4x4 root = Matrix4x4.CreateFromQuaternion(stab.Frame.Orientation) * Matrix4x4.CreateTranslation(stab.Frame.Origin + offset);
                    AddModel(dats, assets, r, stab.Id, Matrix4x4.Identity, root, skipMarkers: true);
                    NoteEffects(dats, r, stab.Id, root, true);
                }
            }
            r.IndoorTo = r.Parts.Count;
            if (rooms.Count > 0) r.Rooms = assets.Merge(rooms);
            if (r.PortalRooms != null) foreach (uint c in portalCell) r.PortalRooms.Add(BuildingBox(c, cellsById, boxes));
            foreach (BuildingInfo b in info.Buildings)
                MarkBuilding(dats, b, lbId, cellsById, offset, lb.Heightmap.Height, heightTable, lbX, lbY, ref r.FloorMask);
        }

        // scenery: not in cells that hold a building
        HashSet<int>? buildingCells = null;
        if (info != null)
        {
            buildingCells = new HashSet<int>();
            foreach (BuildingInfo b in info.Buildings)
                buildingCells.Add(Math.Clamp((int)(b.Frame.Origin.X / 24f), 0, 8) * 9 + Math.Clamp((int)(b.Frame.Origin.Y / 24f), 0, 8));
        }
        foreach (SceneryGenerator.ScenerySpawn s in SceneryGenerator.Generate(dats, region, lb.Heightmap, lbId, buildingCells))
        {
            float ground = TerrainSurface.SampleZFromHeightmap(lb.Heightmap.Height, heightTable, (uint)lbX, (uint)lbY, s.LocalPosition.X, s.LocalPosition.Y);
            var pos = new Vector3(s.LocalPosition.X, s.LocalPosition.Y, ground + s.LocalPosition.Z) + offset;
            Matrix4x4 root = Matrix4x4.CreateFromQuaternion(s.Rotation) * Matrix4x4.CreateTranslation(pos);
            int before = r.Parts.Count;
            AddModel(dats, assets, r, s.ObjectId, Matrix4x4.CreateScale(s.Scale), root);
            if (r.Parts.Count > before) r.Scenery++;
        }
        // creatures, NPCs, doors, chests... (what the server would place when the world starts)
        if (creatures != null)
        {
            var heights = lb.Heightmap.Height;
            int spawnIndex = 0;
            foreach (var p in creatures.Data.ForLandblock(lbX, lbY,
                         (x, y) => TerrainSurface.SampleZFromHeightmap(heights, heightTable, (uint)lbX, (uint)lbY, x, y)))
            {
                int index = spawnIndex++;
                var key = new ACGodot.Creatures.CreatureAssets.Key(p.Wcid, p.PaletteTemplate, p.Shade);
                if (!creatures.Prepare(key)) continue;
                r.Spawns.Add((key, Matrix4x4.CreateFromQuaternion(p.Rotation) * Matrix4x4.CreateTranslation(p.Position + offset), (p.Cell & 0xFFFF) >= 0x100, index, p.Cell));
            }
        }
        return r;
    }

    /// <summary>
    /// Rooms left in the files that nothing leads into: no other room has an opening onto them, no building, and they
    /// have none to the outside (a passage's old dead end, standing where the passage now carries on). The game never
    /// reaches them through an opening, so never draws them; drawn, they wall the passage off.
    /// </summary>
    public static HashSet<uint> LeftOverCells(Func<uint, EnvCell?> get, LandBlockInfo info, uint first)
    {
        var left = new HashSet<uint>();
        try
        {
            uint hi = first & 0xFFFF0000u;
            var into = new HashSet<uint>();
            var cells = new Dictionary<uint, EnvCell>();
            for (uint i = 0; i < info.NumCells; i++)
            {
                if (get(first + i) is not EnvCell c) continue;
                cells[first + i] = c;
                foreach (var portal in c.CellPortals) if (portal.OtherCellId != 0xFFFF) into.Add(hi | portal.OtherCellId);
            }
            foreach (BuildingInfo b in info.Buildings) foreach (var bp in b.Portals) into.Add(hi | bp.OtherCellId);
            foreach (var (id, c) in cells)
            {
                if (into.Contains(id) || c.CellPortals.Count == 0) continue;
                bool outside = false;
                foreach (var portal in c.CellPortals) if (portal.OtherCellId == 0xFFFF) outside = true;
                if (!outside) left.Add(id);
            }
        }
        catch { left.Clear(); }
        return left;
    }

    private static void NoteEffects(Dats dats, Result r, uint id, Matrix4x4 root, bool indoors)
    {
        if ((id >> 24) != 0x02) return;
        try
        {
            if (dats.Get<Setup>(id) is not Setup s) return;
            if ((uint)s.DefaultScript != 0)
            {
                r.Effects.Add((id, root, indoors));
                NoteScrolls(dats, r, s);
            }
            NoteLights(r, s, root, indoors);
        }
        catch { }
    }

    /// <summary>A Setup's lights, placed (the light's frame is in the Setup's own space).</summary>
    public static void NoteLights(Result r, Setup s, Matrix4x4 root, bool indoors)
    {
        if (s.Lights == null || s.Lights.Count == 0) return;
        foreach (var light in s.Lights.Values)
        {
            if (light == null || light.Falloff <= 0f || light.Intensity <= 0f) continue;
            r.Lights.Add((Vector3.Transform(light.ViewSpaceLocation.Origin, root), light.Color, light.Intensity, light.Falloff, indoors));
        }
    }

    /// <summary>The texture-velocity hooks in a Setup's default script: those parts' textures move.</summary>
    private static void NoteScrolls(Dats dats, Result r, Setup s)
    {
        if (dats.Get<DatReaderWriter.DBObjs.PhysicsScript>((uint)s.DefaultScript) is not DatReaderWriter.DBObjs.PhysicsScript ps) return;
        foreach (var d in ps.ScriptData)
        {
            switch (d.Hook)
            {
                case DatReaderWriter.Types.TextureVelocityHook tv when tv.USpeed != 0f || tv.VSpeed != 0f:
                    foreach (var part in s.Parts) r.Scrolls[(uint)part] = new System.Numerics.Vector2(tv.USpeed, tv.VSpeed);
                    break;
                case DatReaderWriter.Types.TextureVelocityPartHook tp when (tp.USpeed != 0f || tp.VSpeed != 0f) && tp.PartIndex < s.Parts.Count:
                    r.Scrolls[(uint)s.Parts[(int)tp.PartIndex]] = new System.Numerics.Vector2(tp.USpeed, tp.VSpeed);
                    break;
            }
        }
    }

    public const int MaskSize = 768;   // 0.25 m squares

    /// <summary>A room's openings to the outside (portals to cell 0xFFFF): their polygons as Godot-space triangles.</summary>
    private static void AddOutsidePortals(Dats dats, EnvCell cell, Matrix4x4 at, List<Godot.Vector3> tris)
    {
        var env = dats.Get<DatReaderWriter.DBObjs.Environment>(0x0D000000u | cell.EnvironmentId);
        if (env == null || !env.Cells.TryGetValue(cell.CellStructure, out var cs)) return;
        Godot.Transform3D xf = ObjectAssets.Xf(at);
        foreach (var portal in cell.CellPortals)
        {
            if (portal.OtherCellId != 0xFFFF) continue;
            if (!cs.Polygons.TryGetValue((ushort)portal.PolygonId, out var poly) || poly.VertexIds.Count < 3) continue;
            var pts = new List<Godot.Vector3>();
            foreach (var vid in poly.VertexIds)
                if (cs.VertexArray.Vertices.TryGetValue((ushort)vid, out var sw)) pts.Add(xf * new Godot.Vector3(sw.Origin.X, sw.Origin.Y, sw.Origin.Z));
            for (int i = 1; i + 1 < pts.Count; i++) { tris.Add(pts[0]); tris.Add(pts[i]); tris.Add(pts[i + 1]); }
        }
    }

    /// <summary>
    /// The box around all the rooms joined to this one (the whole building it's in): ground seen through one of
    /// the building's openings is dropped anywhere inside, so a stairwell in the next room shows the cellar.
    /// </summary>
    private static Godot.Aabb BuildingBox(uint start, Dictionary<uint, (EnvCell cell, Matrix4x4 at)> cells, Dictionary<uint, Godot.Aabb> boxes)
    {
        var seen = new HashSet<uint> { start };
        var todo = new Stack<uint>();
        todo.Push(start);
        Godot.Aabb box = boxes[start];
        uint hi = start & 0xFFFF0000u;
        while (todo.Count > 0)
        {
            uint id = todo.Pop();
            if (!cells.TryGetValue(id, out var c)) continue;
            foreach (var portal in c.cell.CellPortals)
            {
                if (portal.OtherCellId == 0xFFFF) continue;
                uint other = hi | portal.OtherCellId;
                if (!seen.Add(other)) continue;
                if (boxes.TryGetValue(other, out var b)) box = box.Merge(b);
                todo.Push(other);
            }
        }
        return box;
    }

    /// <summary>All of a room's polygons (walls, floors, openings) as Godot-space triangles.</summary>
    /// <summary>A room's walls where they meet the floor: each wall's bottom edge, seen from above.</summary>
    private static void AddMapLines(Dats dats, EnvCell cell, Matrix4x4 at, List<(Godot.Vector2 a, Godot.Vector2 b, float y)> lines)
    {
        var env = dats.Get<DatReaderWriter.DBObjs.Environment>(0x0D000000u | cell.EnvironmentId);
        if (env == null || !env.Cells.TryGetValue(cell.CellStructure, out var cs)) return;
        Godot.Transform3D xf = ObjectAssets.Xf(at);
        var pts = new List<Godot.Vector3>();
        foreach (var poly in cs.Polygons.Values)
        {
            pts.Clear();
            foreach (var vid in poly.VertexIds)
                if (cs.VertexArray.Vertices.TryGetValue((ushort)vid, out var sw)) pts.Add(xf * new Godot.Vector3(sw.Origin.X, sw.Origin.Y, sw.Origin.Z));
            if (pts.Count < 3) continue;
            var n = (pts[1] - pts[0]).Cross(pts[2] - pts[0]);
            if (n.LengthSquared() < 1e-8f || MathF.Abs(n.Normalized().Y) > 0.35f) continue;   // floors, ceilings, ramps
            float low = float.MaxValue;
            foreach (var p in pts) low = MathF.Min(low, p.Y);
            for (int i = 0; i < pts.Count; i++)
            {
                var a = pts[i]; var b = pts[(i + 1) % pts.Count];
                if (a.Y - low > 0.15f || b.Y - low > 0.15f) continue;
                if (new Godot.Vector2(a.X - b.X, a.Z - b.Z).LengthSquared() < 0.01f) continue;
                lines.Add((new Godot.Vector2(a.X, a.Z), new Godot.Vector2(b.X, b.Z), low));
            }
        }
    }

    private static Godot.Vector3[] CellShape(Dats dats, EnvCell cell, Matrix4x4 at)
    {
        var env = dats.Get<DatReaderWriter.DBObjs.Environment>(0x0D000000u | cell.EnvironmentId);
        if (env == null || !env.Cells.TryGetValue(cell.CellStructure, out var cs)) return Array.Empty<Godot.Vector3>();
        Godot.Transform3D xf = ObjectAssets.Xf(at);
        var tris = new List<Godot.Vector3>();
        foreach (var poly in cs.Polygons.Values)
        {
            var pts = new List<Godot.Vector3>();
            foreach (var vid in poly.VertexIds)
                if (cs.VertexArray.Vertices.TryGetValue((ushort)vid, out var sw)) pts.Add(xf * new Godot.Vector3(sw.Origin.X, sw.Origin.Y, sw.Origin.Z));
            for (int i = 1; i + 1 < pts.Count; i++) { tris.Add(pts[0]); tris.Add(pts[i]); tris.Add(pts[i + 1]); }
        }
        return tris.ToArray();
    }

    /// <summary>
    /// The room (a dungeon's or a building's cell) a point of the world is in, or 0: by the rooms' boxes, the smallest
    /// that holds it - near enough to start from (the collision finds the exact one from there). A dungeon's rooms can
    /// lie blocks away from its own square on the map, so the landblocks around are looked through too.
    /// </summary>
    public static uint RoomAt(Dats dats, Vector3 acWorld)
    {
        int bx = (int)MathF.Floor(acWorld.X / 192f), by = (int)MathF.Floor(acWorld.Y / 192f);
        var at = new Godot.Vector3(acWorld.X, acWorld.Z, -acWorld.Y);
        uint best = 0; float bestSize = float.MaxValue;
        for (int lx = bx - 2; lx <= bx + 2; lx++)
            for (int ly = by - 2; ly <= by + 2; ly++)
            {
                if (lx < 0 || ly < 0 || lx > 254 || ly > 254) continue;
                uint hi = ((uint)lx << 24) | ((uint)ly << 16);
                LandBlockInfo? info;
                try { info = dats.Get<LandBlockInfo>(hi | 0xFFFEu); } catch { info = null; }
                if (info == null || info.NumCells == 0) continue;
                var offset = new Vector3(lx * 192f, ly * 192f, 0f);
                for (uint i = 0; i < info.NumCells; i++)
                {
                    try
                    {
                        if (dats.Get<EnvCell>(hi | (0x100u + i)) is not EnvCell cell) continue;
                        // (quick: far from this room's own middle)
                        var o = cell.Position.Origin + offset;
                        if (MathF.Abs(o.X - acWorld.X) > 40f || MathF.Abs(o.Y - acWorld.Y) > 40f || MathF.Abs(o.Z - acWorld.Z) > 30f) continue;
                        Matrix4x4 m = Matrix4x4.CreateFromQuaternion(cell.Position.Orientation) * Matrix4x4.CreateTranslation(o);
                        if (CellBox(dats, cell, m) is not Godot.Aabb box || !box.Grow(0.05f).HasPoint(at)) continue;
                        float size = box.Size.X * box.Size.Y * box.Size.Z;
                        if (size < bestSize) { bestSize = size; best = hi | (0x100u + i); }
                    }
                    catch { }
                }
            }
        return best;
    }

    /// <summary>A room's box in Godot world space.</summary>
    private static Godot.Aabb? CellBox(Dats dats, EnvCell cell, Matrix4x4 at)
    {
        var env = dats.Get<DatReaderWriter.DBObjs.Environment>(0x0D000000u | cell.EnvironmentId);
        if (env == null || !env.Cells.TryGetValue(cell.CellStructure, out var cs) || cs.VertexArray.Vertices.Count == 0) return null;
        Godot.Aabb? box = null;
        Godot.Transform3D xf = ObjectAssets.Xf(at);
        foreach (var v in cs.VertexArray.Vertices.Values)
        {
            Godot.Vector3 p = xf * new Godot.Vector3(v.Origin.X, v.Origin.Y, v.Origin.Z);
            box = box == null ? new Godot.Aabb(p, Godot.Vector3.Zero) : box.Value.Expand(p);
        }
        return box;
    }

    /// <summary>
    /// Where the ground mustn't be drawn for one building: inside the outline of its outer walls (the lower part of
    /// the building's own model, so roof eaves don't count), wherever one of the landblock's rooms has a floor,
    /// stair or ramp below the upper storeys. A cellar reaching out under the yard is outside the walls and keeps
    /// its grass; a porch or deck with no room under it keeps its ground too.
    /// </summary>
    private static void MarkBuilding(Dats dats, BuildingInfo b, uint lbId, Dictionary<uint, (EnvCell cell, Matrix4x4 at)> cells,
                                     Vector3 offset, byte[] heights, float[] heightTable, int lbX, int lbY, ref byte[]? mask)
    {
        float Ground(float x, float y) => TerrainSurface.SampleZFromHeightmap(heights, heightTable, (uint)lbX, (uint)lbY, Math.Clamp(x, 0, 191.99f), Math.Clamp(y, 0, 191.99f));

        // the outline: the building model's vertices up to 3 m above the ground
        Matrix4x4 root = Matrix4x4.CreateFromQuaternion(b.Frame.Orientation) * Matrix4x4.CreateTranslation(b.Frame.Origin);
        var parts = new List<(uint id, Matrix4x4 xf)>();
        uint mid = b.ModelId;
        if ((mid & 0xFF000000u) == 0x01000000u) parts.Add((mid, root));
        else if ((mid & 0xFF000000u) == 0x02000000u && dats.Get<Setup>(mid) is Setup setup)
            foreach (MeshRef mr in SetupMesh.Flatten(setup)) parts.Add((mr.GfxObjId, mr.PartTransform * root));
        var outline = new List<Vector2>();
        foreach (var (id, xf) in parts)
        {
            GfxObj? g = dats.Get<GfxObj>(id);
            if (g?.VertexArray?.Vertices == null) continue;
            foreach (var v in g.VertexArray.Vertices.Values)
            {
                Vector3 p = Vector3.Transform(v.Origin, xf);
                if (p.Z <= Ground(p.X, p.Y) + 3f) outline.Add(new Vector2(p.X, p.Y));
            }
        }
        if (outline.Count < 3) return;
        Vector2[] hull = Hull(outline);
        if (hull.Length < 3) return;
        float hx0 = float.MaxValue, hy0 = float.MaxValue, hx1 = float.MinValue, hy1 = float.MinValue;
        foreach (var h in hull) { hx0 = Math.Min(hx0, h.X); hy0 = Math.Min(hy0, h.Y); hx1 = Math.Max(hx1, h.X); hy1 = Math.Max(hy1, h.Y); }

        // what's under the building's roof: the model's roof surfaces (level-ish, above the ground floor) seen from
        // above. A basement reaching out under the yard isn't under the roof, so its ground stays.
        var roof = new byte[MaskSize * MaskSize];
        bool hasRoof = false;
        foreach (var (id, xf) in parts)
        {
            GfxObj? g = dats.Get<GfxObj>(id);
            if (g?.Polygons == null || g.VertexArray?.Vertices == null) continue;
            foreach (var poly in g.Polygons.Values)
            {
                int n = poly.VertexIds.Count;
                if (n < 3) continue;
                var pts = new Vector3[n];
                bool ok = true;
                Vector3 ctr = Vector3.Zero;
                for (int i = 0; i < n && ok; i++)
                {
                    if (!g.VertexArray.Vertices.TryGetValue((ushort)poly.VertexIds[i], out var sw)) { ok = false; break; }
                    pts[i] = Vector3.Transform(sw.Origin, xf);
                    ctr += pts[i];
                }
                if (!ok) continue;
                ctr /= n;
                Vector3 nrm = Vector3.Cross(pts[1] - pts[0], pts[2] - pts[0]);
                if (nrm.LengthSquared() < 1e-6f || Math.Abs(Vector3.Normalize(nrm).Z) < 0.3f) continue;
                if (ctr.Z < Ground(ctr.X, ctr.Y) + 1.5f) continue;
                for (int i = 1; i + 1 < n; i++) FillTriangle(roof, pts[0], pts[i], pts[i + 1], (x, y) => true);
                hasRoof = true;
            }
        }
        // the roof less its eaves (three squares, 0.75 m, in from its edge): roughly inside the walls
        var core = new byte[MaskSize * MaskSize];
        if (hasRoof)
            for (int y = 0; y < MaskSize; y++)
            for (int x = 0; x < MaskSize; x++)
            {
                if (roof[y * MaskSize + x] == 0) continue;
                bool keep = true;
                for (int dy = -3; dy <= 3 && keep; dy++)
                for (int dx = -3; dx <= 3 && keep; dx++)
                {
                    int xx = x + dx, yy = y + dy;
                    if (xx < 0 || yy < 0 || xx >= MaskSize || yy >= MaskSize || roof[yy * MaskSize + xx] == 0) keep = false;
                }
                if (keep) core[y * MaskSize + x] = 255;
            }
        // floors at ground level: anywhere inside the outline; anything lower (stairwells, ramps, cellars): only well
        // inside the walls, so a basement running out under the eaves or the yard keeps its ground
        bool AllowedLevel(float x, float y) => InHull(hull, x, y);
        bool AllowedRamp(float x, float y)
        {
            if (!InHull(hull, x, y)) return false;
            if (!hasRoof) return true;
            int ix = Math.Clamp((int)(x / (192f / MaskSize)), 0, MaskSize - 1), iy = Math.Clamp((int)(y / (192f / MaskSize)), 0, MaskSize - 1);
            return roof[iy * MaskSize + ix] != 0;
        }
        bool AllowedBelow(float x, float y)
        {
            if (!InHull(hull, x, y)) return false;
            if (!hasRoof) return true;
            int ix = Math.Clamp((int)(x / (192f / MaskSize)), 0, MaskSize - 1), iy = Math.Clamp((int)(y / (192f / MaskSize)), 0, MaskSize - 1);
            return core[iy * MaskSize + ix] != 0;
        }

        // the rooms' level-ish surfaces (floors, stairs, ramps, cellar ceilings) below the upper storeys
        var own = new byte[MaskSize * MaskSize];
        bool any = false;
        foreach (var c in cells.Values)
        {
            var env = dats.Get<DatReaderWriter.DBObjs.Environment>(0x0D000000u | c.cell.EnvironmentId);
            if (env == null || !env.Cells.TryGetValue(c.cell.CellStructure, out var cs)) continue;
            foreach (var poly in cs.Polygons.Values)
            {
                int n = poly.VertexIds.Count;
                if (n < 3) continue;
                var pts = new Vector3[n];
                bool ok = true, near = false;
                Vector3 ctr = Vector3.Zero;
                for (int i = 0; i < n && ok; i++)
                {
                    if (!cs.VertexArray.Vertices.TryGetValue((ushort)poly.VertexIds[i], out var sw)) { ok = false; break; }
                    pts[i] = Vector3.Transform(sw.Origin, c.at) - offset;
                    ctr += pts[i];
                    if (pts[i].X >= hx0 && pts[i].X <= hx1 && pts[i].Y >= hy0 && pts[i].Y <= hy1) near = true;
                }
                if (!ok || !near) continue;
                ctr /= n;
                Vector3 nrm = Vector3.Cross(pts[1] - pts[0], pts[2] - pts[0]);
                if (nrm.LengthSquared() < 1e-6f || Math.Abs(Vector3.Normalize(nrm).Z) < 0.3f) continue;   // a wall
                float gz = Ground(ctr.X, ctr.Y);
                if (ctr.Z > gz + 1.5f) continue;   // an upper storey
                // a floor at ground level: anywhere inside the outline. A ramp or stair reaching up to the ground:
                // under the roof (stairs down outside the walls keep their grass). Lower still: well inside the walls.
                int kind = ctr.Z >= gz - 0.6f ? 1 : 3;
                if (kind == 3) foreach (var p in pts) if (p.Z >= Ground(p.X, p.Y) - 0.6f) { kind = 2; break; }
                Func<float, float, bool> allowed = kind == 1 ? AllowedLevel : kind == 2 ? AllowedRamp : AllowedBelow;
                for (int i = 1; i + 1 < n; i++) FillTriangle(own, pts[0], pts[i], pts[i + 1], allowed, (byte)kind);
                any = true;
            }
        }
        if (!any) return;
        // grown by one square (a quarter metre) inside the walls, so no grass is left along floor edges and seams;
        // the walls hide the extra, and nothing grows past the outline
        const float S = 192f / MaskSize;
        int x0 = Math.Max(0, (int)(hx0 / S) - 1), x1 = Math.Min(MaskSize - 1, (int)(hx1 / S) + 1);
        int y0 = Math.Max(0, (int)(hy0 / S) - 1), y1 = Math.Min(MaskSize - 1, (int)(hy1 / S) + 1);
        mask ??= new byte[MaskSize * MaskSize];
        for (int y = y0; y <= y1; y++)
        for (int x = x0; x <= x1; x++)
        {
            bool set = own[y * MaskSize + x] != 0;
            for (int dy = -1; dy <= 1 && !set; dy++)
            for (int dx = -1; dx <= 1 && !set; dx++)
            {
                int xx = x + dx, yy = y + dy;
                if (xx >= 0 && yy >= 0 && xx < MaskSize && yy < MaskSize && own[yy * MaskSize + xx] != 0) set = own[yy * MaskSize + xx] switch { 1 => AllowedLevel((x + 0.5f) * S, (y + 0.5f) * S), 2 => AllowedRamp((x + 0.5f) * S, (y + 0.5f) * S), _ => AllowedBelow((x + 0.5f) * S, (y + 0.5f) * S) };
            }
            if (set) mask[y * MaskSize + x] = 255;
        }
    }

    /// <summary>Convex hull (counter-clockwise), Andrew's monotone chain.</summary>
    private static Vector2[] Hull(List<Vector2> pts)
    {
        pts.Sort((a, b) => a.X != b.X ? a.X.CompareTo(b.X) : a.Y.CompareTo(b.Y));
        var h = new Vector2[pts.Count * 2];
        int k = 0;
        static float Cross(Vector2 o, Vector2 a, Vector2 b) => (a.X - o.X) * (b.Y - o.Y) - (a.Y - o.Y) * (b.X - o.X);
        for (int i = 0; i < pts.Count; i++)
        {
            while (k >= 2 && Cross(h[k - 2], h[k - 1], pts[i]) <= 0) k--;
            h[k++] = pts[i];
        }
        for (int i = pts.Count - 2, t = k + 1; i >= 0; i--)
        {
            while (k >= t && Cross(h[k - 2], h[k - 1], pts[i]) <= 0) k--;
            h[k++] = pts[i];
        }
        Array.Resize(ref h, Math.Max(0, k - 1));
        return h;
    }

    private static bool InHull(Vector2[] hull, float x, float y)
    {
        for (int i = 0; i < hull.Length; i++)
        {
            Vector2 a = hull[i], b = hull[(i + 1) % hull.Length];
            if ((b.X - a.X) * (y - a.Y) - (b.Y - a.Y) * (x - a.X) < -0.02f) return false;
        }
        return true;
    }

    private static void FillTriangle(byte[] mask, Vector3 a, Vector3 b, Vector3 c, Func<float, float, bool> allowed, byte value = 255)
    {
        const float S = 192f / MaskSize;
        int x0 = Math.Max(0, (int)(Math.Min(a.X, Math.Min(b.X, c.X)) / S)), x1 = Math.Min(MaskSize - 1, (int)(Math.Max(a.X, Math.Max(b.X, c.X)) / S));
        int y0 = Math.Max(0, (int)(Math.Min(a.Y, Math.Min(b.Y, c.Y)) / S)), y1 = Math.Min(MaskSize - 1, (int)(Math.Max(a.Y, Math.Max(b.Y, c.Y)) / S));
        float Edge(Vector3 p, Vector3 q, float x, float y) => (q.X - p.X) * (y - p.Y) - (q.Y - p.Y) * (x - p.X);
        float area = Edge(a, b, c.X, c.Y);
        if (Math.Abs(area) < 1e-6f) return;
        for (int y = y0; y <= y1; y++)
        for (int x = x0; x <= x1; x++)
        {
            float px = (x + 0.5f) * S, py = (y + 0.5f) * S;
            float w0 = Edge(b, c, px, py), w1 = Edge(c, a, px, py), w2 = Edge(a, b, px, py);
            if ((area > 0 ? (w0 >= 0 && w1 >= 0 && w2 >= 0) : (w0 <= 0 && w1 <= 0 && w2 <= 0)) && allowed(px, py) && (mask[y * MaskSize + x] == 0 || value < mask[y * MaskSize + x])) mask[y * MaskSize + x] = value;
        }
    }

    /// <summary>A GfxObj (one part) or a Setup (several parts in their resting placement).</summary>
    private static void AddModel(Dats dats, ObjectAssets assets, Result r, uint id, Matrix4x4 scale, Matrix4x4 root, bool skipMarkers = false, bool shell = false, bool interior = false)
    {
        uint type = id & 0xFF000000u;
        if (type == 0x01000000u)
        {
            if (skipMarkers && GfxObjDegradeResolver.IsRuntimeHiddenMarker(dats, id)) return;
            assets.Prepare(id);
            r.Parts.Add(new Part(shell ? ObjectAssets.ShellKey(id) : interior ? ObjectAssets.InteriorKey(id) : id, scale * root));
        }
        else if (type == 0x02000000u)
        {
            Setup? setup = dats.Get<Setup>(id);
            if (setup == null) return;
            foreach (MeshRef mr in SetupMesh.Flatten(setup))
            {
                if (skipMarkers && GfxObjDegradeResolver.IsRuntimeHiddenMarker(dats, mr.GfxObjId)) continue;
                assets.Prepare(mr.GfxObjId);
                r.Parts.Add(new Part(shell ? ObjectAssets.ShellKey(mr.GfxObjId) : interior ? ObjectAssets.InteriorKey(mr.GfxObjId) : mr.GfxObjId, mr.PartTransform * scale * root));
            }
        }
    }
}
