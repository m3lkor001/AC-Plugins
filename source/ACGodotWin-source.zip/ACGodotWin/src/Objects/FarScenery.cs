using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Numerics;
using System.Threading.Tasks;
using AcDream.Core.Meshing;
using AcDream.Core.Physics;
using AcDream.Core.World;
using ACGodot.UI;
using DatReaderWriter.DBObjs;
using DatReaderWriter.Types;
using Godot;

namespace ACGodot.Objects;

/// <summary>
/// Trees, bushes and rocks past the "Buildings, trees" distance (Options > Video: lighting and effects): the same scenery
/// the game places there, drawn with each model's simplest version (its last degrade in the game files) and nothing else
/// - no buildings, no collision, no effects - so forests and hillsides don't stop in a line. Out to FarTrees landblocks
/// (never past the detailed landscape, which they stand on). Built in 4 x 4-landblock pieces on worker threads.
/// </summary>
public partial class FarScenery : Node3D
{
    private const int Chunk = 4;

    private Dats _dats = null!;
    private ObjectAssets _assets = null!;
    private Region _region = null!;
    private float[] _heights = null!;
    private readonly Dictionary<(int, int), (Node3D? node, int sig)> _chunks = new();
    private readonly ConcurrentQueue<((int, int) key, int sig, Dictionary<uint, List<Matrix4x4>>? parts)> _ready = new();
    private readonly ConcurrentDictionary<uint, uint> _simplest = new();
    private (int, int) _center = (int.MinValue, 0);
    private int _near = -1, _far = -1;

    /// <summary>The full objects' radius (landblocks each way): these start past it.</summary>
    public int Near { get; set; } = 3;
    /// <summary>The detailed landscape's radius: these never go past it.</summary>
    public int Land { get; set; } = 5;

    public void Setup(Dats dats, ObjectAssets assets, float[] heightTable)
    {
        _dats = dats; _assets = assets; _heights = heightTable;
        _region = dats.Portal<Region>(0x13000000u) ?? throw new InvalidOperationException("Region 0x13000000 is missing");
    }

    private int Reach => Math.Min(Video.FarTrees, Land);

    /// <summary>Call each frame with the camera's position.</summary>
    public void Follow(Godot.Vector3 godotPos)
    {
        if (_dats == null) return;
        var c = World.LandblockAt(godotPos);
        if (c != _center || Near != _near || Reach != _far)
        {
            _center = c; _near = Near; _far = Reach;
            Refresh();
        }
        for (int i = 0; i < 2 && _ready.TryDequeue(out var r); i++)
        {
            if (!_chunks.TryGetValue(r.key, out var have) || have.sig != r.sig) continue;   // wanted something else since
            have.node?.QueueFree();
            Node3D? node = null;
            if (r.parts != null && r.parts.Count > 0)
            {
                node = new Node3D { Name = $"FarScenery_{r.key.Item1}_{r.key.Item2}" };
                foreach (var kv in r.parts)
                {
                    ArrayMesh? mesh = _assets.Mesh(kv.Key);
                    if (mesh == null) continue;
                    var mm = new MultiMesh { TransformFormat = MultiMesh.TransformFormatEnum.Transform3D, Mesh = mesh, InstanceCount = kv.Value.Count };
                    for (int j = 0; j < kv.Value.Count; j++) mm.SetInstanceTransform(j, ObjectAssets.Xf(kv.Value[j]));
                    node.AddChild(new MultiMeshInstance3D { Multimesh = mm, CastShadow = GeometryInstance3D.ShadowCastingSetting.Off });
                }
                AddChild(node);
            }
            _chunks[r.key] = (node, r.sig);
        }
    }

    private bool Wanted(int x, int y)
    {
        if (x < 0 || y < 0 || x > 254 || y > 254) return false;
        int d = Math.Max(Math.Abs(x - _center.Item1), Math.Abs(y - _center.Item2));
        return d > Near && d <= Reach;
    }

    private static int FloorDiv(int a, int b) => (int)Math.Floor(a / (double)b);

    private void Refresh()
    {
        var want = new Dictionary<(int, int), int>();
        if (Reach > Near)
        {
            int c0x = FloorDiv(_center.Item1 - Reach, Chunk), c1x = FloorDiv(_center.Item1 + Reach, Chunk);
            int c0y = FloorDiv(_center.Item2 - Reach, Chunk), c1y = FloorDiv(_center.Item2 + Reach, Chunk);
            for (int cx = c0x; cx <= c1x; cx++)
                for (int cy = c0y; cy <= c1y; cy++)
                {
                    int sig = 0;
                    for (int i = 0; i < Chunk * Chunk; i++)
                        if (Wanted(cx * Chunk + i % Chunk, cy * Chunk + i / Chunk)) sig |= 1 << i;
                    if (sig != 0) want[(cx, cy)] = sig;
                }
        }
        var drop = new List<(int, int)>();
        foreach (var kv in _chunks) if (!want.ContainsKey(kv.Key)) drop.Add(kv.Key);
        foreach (var k in drop) { _chunks[k].node?.QueueFree(); _chunks.Remove(k); }
        foreach (var kv in want)
        {
            if (_chunks.TryGetValue(kv.Key, out var have) && have.sig == kv.Value) continue;
            _chunks[kv.Key] = (have.node, kv.Value);
            var key = kv.Key; int sig = kv.Value;
            Task.Run(() =>
            {
                Dictionary<uint, List<Matrix4x4>>? parts = null;
                try { parts = Build(key, sig); }
                catch (Exception ex) { GD.PushWarning($"distant scenery {key}: {ex.Message}"); }
                _ready.Enqueue((key, sig, parts));
            });
        }
    }

    /// <summary>A model's simplest version: the last of its degrades (the one the game shows furthest off).</summary>
    private uint Simplest(uint gfxObjId) => _simplest.GetOrAdd(gfxObjId, id =>
    {
        try
        {
            if (_dats.Get<GfxObj>(id) is GfxObj g && g.DIDDegrade != 0 && _dats.Get<GfxObjDegradeInfo>(g.DIDDegrade) is GfxObjDegradeInfo info)
                for (int i = info.Degrades.Count - 1; i >= 0; i--)
                {
                    uint d = (uint)info.Degrades[i].Id;
                    if (d != 0 && _dats.Get<GfxObj>(d) != null) return d;
                }
        }
        catch { }
        return id;
    });

    /// <summary>One piece's scenery (any thread): each model's simplest version and where each one stands (AC world).</summary>
    private Dictionary<uint, List<Matrix4x4>> Build((int, int) key, int sig)
    {
        var parts = new Dictionary<uint, List<Matrix4x4>>();
        for (int i = 0; i < Chunk * Chunk; i++)
        {
            if ((sig & (1 << i)) == 0) continue;
            int lbX = key.Item1 * Chunk + i % Chunk, lbY = key.Item2 * Chunk + i / Chunk;
            uint lbId = ((uint)lbX << 24) | ((uint)lbY << 16) | 0xFFFFu;
            LoadedLandblock? lb = LandblockLoader.Load(_dats, lbId);
            if (lb == null) continue;
            var offset = new System.Numerics.Vector3(lbX * 192f, lbY * 192f, 0f);
            HashSet<int>? buildingCells = null;
            if (_dats.Get<LandBlockInfo>((lbId & 0xFFFF0000u) | 0xFFFEu) is LandBlockInfo info)
            {
                buildingCells = new HashSet<int>();
                foreach (BuildingInfo b in info.Buildings)
                    buildingCells.Add(Math.Clamp((int)(b.Frame.Origin.X / 24f), 0, 8) * 9 + Math.Clamp((int)(b.Frame.Origin.Y / 24f), 0, 8));
            }
            foreach (SceneryGenerator.ScenerySpawn s in SceneryGenerator.Generate(_dats, _region, lb.Heightmap, lbId, buildingCells))
            {
                float ground = TerrainSurface.SampleZFromHeightmap(lb.Heightmap.Height, _heights, (uint)lbX, (uint)lbY, s.LocalPosition.X, s.LocalPosition.Y);
                var pos = new System.Numerics.Vector3(s.LocalPosition.X, s.LocalPosition.Y, ground + s.LocalPosition.Z) + offset;
                Matrix4x4 root = Matrix4x4.CreateScale(s.Scale) * Matrix4x4.CreateFromQuaternion(s.Rotation) * Matrix4x4.CreateTranslation(pos);
                uint id = s.ObjectId;
                if ((id & 0xFF000000u) == 0x01000000u) Add(parts, id, root);
                else if ((id & 0xFF000000u) == 0x02000000u && _dats.Get<Setup>(id) is Setup setup)
                    foreach (MeshRef mr in SetupMesh.Flatten(setup)) Add(parts, mr.GfxObjId, mr.PartTransform * root);
            }
        }
        return parts;
    }

    private void Add(Dictionary<uint, List<Matrix4x4>> parts, uint gfxObjId, Matrix4x4 world)
    {
        if (GfxObjDegradeResolver.IsRuntimeHiddenMarker(_dats, gfxObjId)) return;
        uint low = Simplest(gfxObjId);
        _assets.Prepare(low);
        if (!parts.TryGetValue(low, out var list)) parts[low] = list = new List<Matrix4x4>();
        list.Add(world);
    }
}
