using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using Godot;

namespace ACGodot;

/// <summary>
/// Frames that took too long (a hitch you'd see as a skip), kept in the character's logs folder - logs/&lt;Character&gt;/hitches.txt:
/// how long the frame was, how much of it our code took (and which parts), how much the engine's own drawing and
/// physics took, and whether the .NET garbage collector stopped everything in it. Two of these run: one first in every
/// frame, one last; each node's _Process marks where it starts (<see cref="Enter"/>), so the time between is theirs.
/// </summary>
public partial class FrameWatch : Node
{
    public bool IsLast;
    /// <summary>Where the log goes (the character's logs folder).</summary>
    public static Func<string>? Dir;
    /// <summary>A few words about what's going on (particles, what's loading) added to each line.</summary>
    public static Func<string>? Extra;
    /// <summary>Frames longer than this are written down (ms).</summary>
    public const double SlowMs = 50;

    private static readonly Stopwatch Sw = Stopwatch.StartNew();
    private static readonly Dictionary<string, double> Laps = new();
    private static string _cur = "";
    private static double _mark, _frameStart, _procEnd;
    private static int _g0, _g1, _g2;
    private static TimeSpan _pause;
    private static long _alloc;
    private static double _startedAt = -1;
    private static Rid _vp;
    private static double _preDraw, _postDraw;
    private static readonly Dictionary<string, double> Draws = new();
    private static int _added, _removed;
    /// <summary>A control drawing itself (its _Draw): timed, by its kind.</summary>
    public static long DrawStart() => Sw.ElapsedTicks;
    public static void Drew(string name, long start)
    {
        double ms = (Sw.ElapsedTicks - start) * 1000.0 / Stopwatch.Frequency;
        Draws.TryGetValue(name, out double was); Draws[name] = was + ms;
    }

    // ── a frame that never ends (the game frozen): a watcher on its own thread writes down, after a few seconds, which part
    //    of our code the frame was in and the last things it was doing (Doing), so the next freeze says where it was ──
    /// <summary>What's being done right now (a server message being read, a plugin being told something) - kept short.</summary>
    public static volatile string Doing = "";
    private static readonly string[] _doneLast = new string[24];
    private static int _doneN;
    /// <summary>Notes what's being done (and keeps the last few).</summary>
    public static void Note(string what) { Doing = what; _doneLast[_doneN++ % _doneLast.Length] = $"{DateTime.Now:HH:mm:ss.fff} {what}"; }
    private static volatile string _dirNow = "";
    private static double _frameStartSeen;
    private static System.Threading.Thread? _watcher;

    private static void Watch()
    {
        double reported = -1;
        while (true)
        {
            System.Threading.Thread.Sleep(500);
            try
            {
                double start = _frameStart, now = Sw.Elapsed.TotalMilliseconds;
                if (start <= 0 || now - start < 4000 || reported == start) continue;
                reported = start;
                var last = new List<string>();
                for (int i = 0; i < _doneLast.Length; i++) { string? d = _doneLast[(_doneN + i) % _doneLast.Length]; if (d != null) last.Add(d); }
                string line = $"{DateTime.Now:HH:mm:ss.fff} FROZEN: this frame has run {(now - start) / 1000:0.0} s, in {_cur} - doing: {Doing}\n   last done:\n      " + string.Join("\n      ", last);
                string dir = _dirNow.Length > 0 ? _dirNow : Path.GetTempPath();
                File.AppendAllText(Path.Combine(dir, "hitches.txt"), line + "\n");
                GD.Print("[frozen] " + line);
            }
            catch { }
        }
    }

    public override void _Ready()
    {
        if (!IsLast && _watcher == null) { _watcher = new System.Threading.Thread(Watch) { IsBackground = true, Name = "FrameWatch freeze watcher" }; _watcher.Start(); }
        ProcessPriority = IsLast ? int.MaxValue : int.MinValue;
        ProcessMode = ProcessModeEnum.Always;
        // (how long the graphics card itself takes to draw each frame, measured by the engine)
        if (!IsLast) try { _vp = GetViewport().GetViewportRid(); RenderingServer.ViewportSetMeasureRenderTime(_vp, true); } catch { }
        // (where the rest of a frame goes: the engine's deferred work - laying out the interface, its controls drawing
        // themselves - up to the start of drawing; the drawing itself on our side; then the wait till the next frame)
        if (!IsLast)
        {
            RenderingServer.FramePreDraw += () => _preDraw = Sw.Elapsed.TotalMilliseconds;
            RenderingServer.FramePostDraw += () => _postDraw = Sw.Elapsed.TotalMilliseconds;
            // (nodes made and freed each frame: an interface rebuilding itself over and over shows here)
            GetTree().NodeAdded += _ => _added++;
            GetTree().NodeRemoved += _ => _removed++;
        }
    }

    public override void _Process(double delta)
    {
        double now = Sw.Elapsed.TotalMilliseconds;
        if (IsLast) { Enter(""); _procEnd = now; return; }
        if (_startedAt < 0) _startedAt = now;
        // (the first half minute is loading: every frame then is slow)
        if (delta * 1000 > SlowMs && _frameStart > 0 && now - _startedAt > 30000) Report(delta * 1000, now);
        Laps.Clear();
        Draws.Clear(); _added = 0; _removed = 0;
        _frameStart = now; _mark = now; _cur = "(before our code)";
        try { if (_dirNow.Length == 0 || (int)now % 5000 < 20) _dirNow = Dir?.Invoke() ?? ""; } catch { }
        _g0 = GC.CollectionCount(0); _g1 = GC.CollectionCount(1); _g2 = GC.CollectionCount(2);
        _pause = GC.GetTotalPauseDuration();
        _alloc = GC.GetTotalAllocatedBytes(false);
    }

    /// <summary>A node's _Process starting: the time since the last mark was the one before's.</summary>
    public static void Enter(string name)
    {
        double now = Sw.Elapsed.TotalMilliseconds;
        if (_cur.Length > 0) { Laps.TryGetValue(_cur, out double was); Laps[_cur] = was + now - _mark; }
        _cur = name; _mark = now;
    }

    private static void Report(double frameMs, double now)
    {
        try
        {
            double ours = Math.Max(0, _procEnd - _frameStart);
            double after = Math.Max(0, now - _procEnd);   // the engine drawing that frame, physics, and the wait for the screen
            string split = _preDraw > _procEnd && _postDraw >= _preDraw && _postDraw <= now
                ? $" = deferred/layout {_preDraw - _procEnd:0} + drawing {_postDraw - _preDraw:0} + till next frame {now - _postDraw:0}" : "";
            int d0 = GC.CollectionCount(0) - _g0, d1 = GC.CollectionCount(1) - _g1, d2 = GC.CollectionCount(2) - _g2;
            double gcMs = (GC.GetTotalPauseDuration() - _pause).TotalMilliseconds;
            double mb = (GC.GetTotalAllocatedBytes(false) - _alloc) / 1048576.0;
            var drew = Draws.Where(kv => kv.Value >= 1).OrderByDescending(kv => kv.Value).Select(kv => $"{kv.Key} {kv.Value:0}");
            string draws = $"   nodes made {_added} freed {_removed}" + (Draws.Count > 0 ? $"   controls drawing {Draws.Values.Sum():0} ms" + (drew.Any() ? $" ({string.Join(", ", drew)})" : "") : "");
            var parts = Laps.Where(kv => kv.Value >= 2).OrderByDescending(kv => kv.Value).Select(kv => $"{kv.Key} {kv.Value:0}");
            string gc = d0 + d1 + d2 > 0 ? $"   GC {gcMs:0} ms (gen0 {d0} gen1 {d1} gen2 {d2})" : "";
            double phys = Performance.GetMonitor(Performance.Monitor.TimePhysicsProcess) * 1000;
            string gpu = "";
            try
            {
                var vpn = (Engine.GetMainLoop() as SceneTree)?.Root;
                gpu = $"   card draws {RenderingServer.ViewportGetMeasuredRenderTimeGpu(_vp):0.0} ms (cpu side {RenderingServer.ViewportGetMeasuredRenderTimeCpu(_vp) + RenderingServer.GetFrameSetupTimeCpu():0.0}), vsync {DisplayServer.WindowGetVsyncMode()}, " +
                      $"{(vpn != null ? $"msaa {vpn.Msaa3D}, scale {vpn.Scaling3DScale:0.##}, {vpn.Size.X}x{vpn.Size.Y}, 3D {(vpn.Disable3D ? "off" : "on")}" : "")}";
            }
            catch { }
            string scene = $"nodes {Performance.GetMonitor(Performance.Monitor.ObjectNodeCount):0}, drawn {Performance.GetMonitor(Performance.Monitor.RenderTotalObjectsInFrame):0} things in {Performance.GetMonitor(Performance.Monitor.RenderTotalDrawCallsInFrame):0} draw calls, video mem {Performance.GetMonitor(Performance.Monitor.RenderVideoMemUsed) / 1048576:0} MB, fps cap {Engine.MaxFps}";
            string line = $"{DateTime.Now:HH:mm:ss.fff} {frameMs,5:0} ms   our code {ours:0}   engine after {after:0}{split} (physics {phys:0}){gc}   made {mb:0.0} MB" +
                          $"   {Extra?.Invoke() ?? ""}   {scene}{gpu}{draws}   | {string.Join(" | ", parts)}";
            string dir = Dir?.Invoke() ?? Path.GetTempPath();
            Directory.CreateDirectory(dir);
            string path = Path.Combine(dir, "hitches.txt");
            var fi = new FileInfo(path);
            if (fi.Exists && fi.Length > 2_000_000) File.Move(path, Path.Combine(dir, "hitches.prev.txt"), true);
            File.AppendAllText(path, line + "\n");
        }
        catch { }
    }
}
