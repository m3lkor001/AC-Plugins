using System;
using System.Collections.Generic;
using Godot;

using ACGodot.UI;

namespace ACGodot.Effects;

/// <summary>
/// The game's own lights: the lamps, torches, braziers and glows that models carry (a Setup's Lights), and the soft light
/// the game hangs around your character. Also the textures that move (waterfalls, lava, runes: a script's texture-velocity
/// hooks). Options > Video: lighting and effects switches them; this keeps them as set, each frame.
///
/// How bright: the game authors a light's reach (falloff, metres) and intensity (nearly always 100). A light reaches
/// falloff x 1.5 (the game's hardware-light rule); its strength here is a tuned share of that. Out on the landscape in
/// full daylight a lamp barely shows (as in the game), so outdoor lamps fade towards 15% as the sun gets bright.
/// </summary>
public static class Lamps
{
    private sealed class Lamp
    {
        public OmniLight3D Light = null!;
        public float Energy;
        public bool Indoors;
    }

    private static readonly List<Lamp> _all = new();
    private static readonly List<(StandardMaterial3D mat, Vector2 speed)> _scrolling = new();
    private static readonly double _start = Time.GetTicksMsec() / 1000.0;
    private static OmniLight3D? _viewer;

    /// <summary>How strong a light with the game's usual intensity (100) is, in Godot's light energy.</summary>
    private const float EnergyPer100 = 1.1f;

    /// <summary>A light from a model (Godot position, the game's colour, intensity and falloff), put under <paramref name="parent"/>.</summary>
    public static OmniLight3D Add(Node3D parent, Vector3 at, Color color, float intensity, float falloff, bool indoors)
    {
        float energy = EnergyPer100 * Math.Clamp(intensity / 100f, 0.15f, 2.5f);
        var l = new OmniLight3D
        {
            Position = at, LightColor = color, OmniRange = Math.Max(1f, falloff * 1.5f), OmniAttenuation = 1.2f,
            ShadowEnabled = false, LightSpecular = 0.2f, Name = "Lamp",
            DistanceFadeEnabled = true, DistanceFadeBegin = 70f, DistanceFadeLength = 20f,
            LightVolumetricFogEnergy = 2f,   // (a misty glow round it in volumetric fog)
            Visible = Video.Lamps,
        };
        parent.AddChild(l);
        _all.Add(new Lamp { Light = l, Energy = energy, Indoors = indoors });
        return l;
    }

    /// <summary>A material whose texture moves at this speed (texture widths a second), while moving textures are on.</summary>
    public static void AddScrolling(StandardMaterial3D mat, Vector2 speed) => _scrolling.Add((mat, speed));

    /// <summary>
    /// Each frame. <paramref name="daylight"/>: the sun's brightness now (0 night .. 1 noon); <paramref name="dark"/>: the
    /// camera is underground or indoors; <paramref name="viewer"/>: where the character (or camera) is, for the viewer light.
    /// </summary>
    public static void Update(float daylight, bool dark, Node3D? holder, Vector3 viewer)
    {
        // outdoor lamps: full at night, down to 15% in bright day (the game's lamps hardly show at noon)
        float day = Math.Clamp((daylight - 0.3f) / 0.5f, 0f, 1f);
        float outdoor = 1f - 0.85f * day;
        float scale = Video.LampBright / 100f;
        for (int i = _all.Count - 1; i >= 0; i--)
        {
            var l = _all[i];
            if (!GodotObject.IsInstanceValid(l.Light) || l.Light.IsQueuedForDeletion()) { _all.RemoveAt(i); continue; }
            if (l.Light.Visible != Video.Lamps) l.Light.Visible = Video.Lamps;
            if (!Video.Lamps) continue;
            float e = l.Energy * scale * (l.Indoors || dark ? 1f : outdoor);
            if (Math.Abs(l.Light.LightEnergy - e) > 0.01f) l.Light.LightEnergy = e;
        }

        // the viewer light: the game's soft light around the one you play (reach 10 x 1.5 m, carried 2 m up)
        if (holder != null)
        {
            if (_viewer == null || !GodotObject.IsInstanceValid(_viewer))
            {
                _viewer = new OmniLight3D { Name = "ViewerLight", LightColor = Colors.White, OmniRange = 15f, OmniAttenuation = 1.5f, ShadowEnabled = false, LightSpecular = 0f };
                holder.AddChild(_viewer);
            }
            _viewer.GlobalPosition = viewer + new Vector3(0, 2f, 0);
            // strongest where it's dark: underground and indoors always, outside as the day goes
            float want = Video.ViewerLight ? (dark ? 0.55f : 0.45f * (1f - day)) : 0f;
            _viewer.Visible = want > 0.01f;
            _viewer.LightEnergy = want;
        }

        // moving textures
        if (_scrolling.Count > 0)
        {
            double t = Time.GetTicksMsec() / 1000.0 - _start;
            for (int i = _scrolling.Count - 1; i >= 0; i--)
            {
                var (m, sp) = _scrolling[i];
                if (!GodotObject.IsInstanceValid(m)) { _scrolling.RemoveAt(i); continue; }
                var off = Video.Scroll ? new Vector3((float)((sp.X * t) % 1.0), (float)((sp.Y * t) % 1.0), 0) : Vector3.Zero;
                m.Uv1Offset = off;
            }
        }
    }
}
