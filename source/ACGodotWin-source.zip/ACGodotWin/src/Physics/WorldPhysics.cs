using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using AcDream.Core.Physics;
using AcDream.Core.World;
using DatReaderWriter.DBObjs;

namespace ACGodot.Physics;

/// <summary>
/// The client's own collision (OpenAC's port of it) for the landblocks around the player: the landscape, buildings
/// and their rooms, dungeon cells, and the static objects and scenery placed in them. Landblocks are read on a
/// background thread and handed to the physics engine on the main thread, a few around the player at a time.
///
/// Positions here are in a physics frame: AC world metres less a frame origin (a landblock's corner near where the
/// player started), so the numbers stay small and the collision maths keeps its precision. <see cref="ToFrame"/> and
/// <see cref="FromFrame"/> convert.
/// </summary>
public sealed class WorldPhysics
{
    private const int Radius = 1;        // landblocks loaded around the player's (3 x 3)
    private const int DropRadius = 2;    // and dropped beyond this
    private const int Recentre = 6;      // a new frame when the player is this many landblocks from its origin

    private readonly AcDream.Core.Content.IDatObjectSource _dats;
    private readonly float[] _heights;
    private int _ox = -1, _oy = -1;
    private readonly Dictionary<(int x, int y), Task<Built?>?> _loading = new();
    private readonly HashSet<(int x, int y)> _ready = new();

    public PhysicsEngine Engine { get; private set; } = null!;
    public PhysicsDataCache Cache { get; private set; } = null!;

    private sealed record Built(LoadedLandblock Landblock, LandblockCollisionBuild Collisions, TerrainSurface Terrain, Vector3 Origin);

    private readonly ACGodot.Creatures.SpawnData? _spawns;
    public const float CreatureBody = 0.5f;

    public WorldPhysics(AcDream.Core.Content.IDatObjectSource dats, ACGodot.Creatures.SpawnData? spawns = null)
    {
        _dats = dats;
        _spawns = spawns;
        _heights = dats.Get<Region>(0x13000000u)?.LandDefs.LandHeightTable ?? new float[256];
        NewEngine();
        // the standard human body the client moves a player with (Setup 0x02000001): its spheres and step heights
        var human = dats.Get<Setup>(0x02000001u);
        if (human != null)
        {
            var flat = FlatCollisionAssetBuilder.FlattenSetup(human);
            HumanSpheres = flat.Spheres;
            StepUp = flat.StepUpHeight > 0f ? flat.StepUpHeight : 0.6f;
            StepDown = flat.StepDownHeight > 0f ? flat.StepDownHeight : 0.6f;
        }
        if (HumanSpheres.IsDefaultOrEmpty)
            HumanSpheres = [new FlatCollisionSphere(new Vector3(0, 0, 0.48f), 0.48f), new FlatCollisionSphere(new Vector3(0, 0, 1.35f), 0.48f)];
    }

    public ImmutableArray<FlatCollisionSphere> HumanSpheres { get; }
    public float StepUp { get; } = 0.6f;
    public float StepDown { get; } = 0.6f;

    private void NewEngine()
    {
        Cache = PhysicsDataCache.CreateProduction();
        Engine = new PhysicsEngine { DataCache = Cache };
        _loading.Clear();
        _ready.Clear();
        _published.Clear();
        foreach (var t in _server.Values) t.In = false;
    }

    public int ReadyCount => _ready.Count;
    public (int x, int y) FrameOrigin => (_ox, _oy);
    public AcDream.Core.Content.IDatObjectSource Dats => _dats;
    public System.Collections.Generic.IEnumerable<(int x, int y)> Loaded => _ready;
    /// <summary>The landblock of this cell has been handed to the collision (its rooms are there to stand in).</summary>
    public bool CellReady(uint cell) => System.Linq.Enumerable.Contains(_ready, ((int)(cell >> 24), (int)((cell >> 16) & 0xFF)));

    public Vector3 ToFrame(Vector3 acWorld) => acWorld - new Vector3(_ox * 192f, _oy * 192f, 0f);
    public Vector3 FromFrame(Vector3 frame) => frame + new Vector3(_ox * 192f, _oy * 192f, 0f);

    public static uint LandblockId(int x, int y) => ((uint)x << 24) | ((uint)y << 16) | 0xFFFFu;

    /// <summary>Whether a landblock's collision is in.</summary>
    // (a landblock off the map - where a room's position puts someone standing in it: Mellas Court's rooms are 40 m
    // south of landblock 7400, in "landblock 74,-1" - never loads, so there's nothing to wait for; waited for, the body
    // was never placed, and the cell sent for them was made up from no cell at all)
    public bool IsReady(int x, int y) => _ox >= 0 && (x < 0 || y < 0 || x > 255 || y > 255 || _ready.Contains((x, y)));

    /// <summary>
    /// Keeps the landblocks around (lx, ly) loaded: starts reading missing ones, hands at most one finished one to
    /// the engine, drops far ones. Returns true when the frame was moved (everything reloads: positions in the old
    /// frame are no longer valid).
    /// </summary>
    public bool Update(int lx, int ly, uint keepCell = 0)
    {
        bool moved = false;
        // the landblock of the room they're in, kept loaded wherever they stand: a dungeon's rooms can lie landblocks away
        // from where they stand in the world, and walking on into its far end dropped the rooms' own landblock - every
        // wall and floor went with it, they stuck on nothing at an entrance, and a jump fell through the dark for good
        (int x, int y)? keep = (keepCell & 0xFFFF) >= 0x0100 && (keepCell & 0xFFFF) < 0xFFFE
            ? ((int)(keepCell >> 24), (int)((keepCell >> 16) & 0xFF)) : null;
        if (_ox < 0 || Math.Abs(lx - _ox) > Recentre || Math.Abs(ly - _oy) > Recentre)
        {
            if (_ox >= 0) NewEngine();
            _ox = lx; _oy = ly;
            moved = true;
        }
        for (int dx = -Radius; dx <= Radius; dx++)
            for (int dy = -Radius; dy <= Radius; dy++)
            {
                int x = lx + dx, y = ly + dy;
                // (to 255: the FF row and column have no landscape, but rooms - the apartment halls are there, 74FF and the like;
                // left out, the body had no room to stand in there, and was put "outdoors" on no map at all)
                if (x < 0 || y < 0 || x > 255 || y > 255 || _loading.ContainsKey((x, y))) continue;
                Vector3 origin = new((x - _ox) * 192f, (y - _oy) * 192f, 0f);
                _loading[(x, y)] = Task.Run(() => Build(x, y, origin));
            }
        if (keep is { } kp && !_loading.ContainsKey(kp))
        {
            Vector3 origin = new((kp.x - _ox) * 192f, (kp.y - _oy) * 192f, 0f);
            _loading[kp] = Task.Run(() => Build(kp.x, kp.y, origin));
        }
        // what was left out because you stood in it: put in once you're clear
        if (_waiting.Count > 0 && ++_waitTick % 15 == 0)
            foreach (var w in _waiting.ToList())
                if (!_server.ContainsValue(w)) _waiting.Remove(w);
                else if (!w.In && !OnPlayer(w.Ac)) PutIn(w);
        // hand one finished landblock to the engine per frame
        foreach (var kv in _loading)
        {
            if (kv.Value == null || !kv.Value.IsCompleted) continue;
            var key = kv.Key;
            Built? b = kv.Value.IsCompletedSuccessfully ? kv.Value.Result : null;
            _loading[key] = null;
            if (b != null) { try { Publish(b); } catch (Exception ex) { Godot.GD.PushWarning($"collision 0x{LandblockId(key.x, key.y):X8}: {ex.Message}"); } }
            _ready.Add(key);
            break;
        }
        // far ones out
        var drop = new List<(int x, int y)>();
        foreach (var key in _loading.Keys)
            if ((Math.Abs(key.x - lx) > DropRadius || Math.Abs(key.y - ly) > DropRadius) && key != keep) drop.Add(key);
        foreach (var key in drop)
        {
            if (_loading[key] is { IsCompleted: false }) continue;   // still reading: wait for it
            _loading.Remove(key);
            if (_ready.Remove(key)) { try { Engine.RemoveLandblock(LandblockId(key.x, key.y)); } catch { } }
            if (_published.Remove(key))
                foreach (var t in _server.Values)
                    if (LbOf(t) == key) t.In = false;
        }
        return moved;
    }

    private Built? Build(int x, int y, Vector3 origin)
    {
        try
        {
            if (!LandblockCollision.TryLoadCollisionLandblock(_dats, _heights, LandblockId(x, y), origin,
                    out LoadedLandblock landblock, out LandblockCollisionBuild collisions, hm => Spawned(x, y, hm, origin)))
                return null;
            return new Built(landblock, collisions, LandblockCollision.BuildTerrainSurface(landblock, _heights), origin);
        }
        catch (Exception ex)
        {
            Godot.GD.PushWarning($"collision 0x{LandblockId(x, y):X8}: {ex.Message}");
            return null;
        }
    }

    /// <summary>
    /// The things from ACE's world database that a body bumps into: doors, chests, creatures, NPCs and vendors (as
    /// they stand when the world starts; portals and the like are walked through, as in the game). Each collides with
    /// its parts' own shapes or its model's cylinders, scaled.
    /// </summary>
    private IReadOnlyList<WorldEntity> Spawned(int x, int y, LandBlock heights, Vector3 origin)
    {
        var list = new List<WorldEntity>();
        if (_spawns == null) return list;
        int index = -1;
        foreach (var p in _spawns.ForLandblock(x, y, (lx, ly) =>
                     TerrainSurface.SampleZFromHeightmap(heights.Height, _heights, (uint)x, (uint)y, lx, ly)))
        {
            index++;   // its place in the list: the same for the drawn object (ObjectStreamer), so a door can be opened by it
            var w = _spawns.Get(p.Wcid);
            // creatures, vendors, doors (shut; R opens one) and chests
            if (w == null || w.Setup == 0 || w.Type is not (10 or 12 or 19 or 20) || index > 0xFFF) continue;
            if (_dats.Get<Setup>(w.Setup) is not { } setup) continue;
            float scale = w.Scale > 0f ? w.Scale : 1f;
            // creatures' bodies a little smaller than their models' cylinders, so you can stand about as close to
            // someone as in the game
            if (w.Type is 10 or 12) scale *= CreatureBody;
            // a door or chest as it's drawn: in its motion table's resting pose (shut), not its setup's own placement
            // (a double door's is half open, which leaves a gap where the two leaves meet)
            DatReaderWriter.Types.AnimationFrame? pose = null;
            if (w.Type is 19 or 20 && w.MotionTable != 0)
                try { pose = AcDream.Core.Meshing.MotionResolver.GetIdleFrame(setup, _dats, _animLoader, w.MotionTable); } catch { pose = null; }
            var parts = new List<MeshRef>();
            foreach (MeshRef mr in AcDream.Core.Meshing.SetupMesh.Flatten(setup, pose))
                parts.Add(new MeshRef(mr.GfxObjId, mr.PartTransform * Matrix4x4.CreateScale(scale)));
            if (parts.Count == 0) continue;
            lock (_spawnIds) { if (!_spawnIds.TryGetValue((x, y), out var ids)) _spawnIds[(x, y)] = ids = new HashSet<uint>(); ids.Add(SpawnId(x, y, index)); }
            list.Add(new WorldEntity
            {
                Id = SpawnId(x, y, index),
                SourceGfxObjOrSetupId = w.Setup,
                Position = p.Position + origin,
                Rotation = p.Rotation,
                MeshRefs = parts,
                Scale = scale,
                ParentCellId = (p.Cell & 0xFFFFu) >= 0x100u ? p.Cell : null,
            });
        }
        return list;
    }

    private sealed class AnimLoader : IAnimationLoader
    {
        private readonly AcDream.Core.Content.IDatObjectSource _d;
        public AnimLoader(AcDream.Core.Content.IDatObjectSource d) { _d = d; }
        public DatReaderWriter.DBObjs.Animation? LoadAnimation(uint id) => _d.Get<DatReaderWriter.DBObjs.Animation>(id);
    }
    private AnimLoader? _animLoaderField;
    private AnimLoader _animLoader => _animLoaderField ??= new AnimLoader(_dats);

    private static uint SpawnId(int x, int y, int index) => 0x70000000u | ((uint)x << 20) | ((uint)y << 12) | (uint)index;

    private readonly HashSet<uint> _open = new();
    // an open door: ethereal and not static (a static thing blocks even when ethereal), and ignored outright
    private const PhysicsStateFlags OpenDoor = PhysicsStateFlags.Ethereal | PhysicsStateFlags.IgnoreCollisions;

    /// <summary>A door opened (walked through: ethereal, as the client makes an open door) or shut again.</summary>
    public void SetDoorOpen(int x, int y, int index, bool open)
    {
        uint id = SpawnId(x, y, index);
        if (open) _open.Add(id); else _open.Remove(id);
        try
        {
            Engine.ShadowObjects.UpdatePhysicsState(id, (uint)(open ? OpenDoor : PhysicsStateFlags.Static));
        }
        catch (Exception ex) { Godot.GD.PushWarning("door: " + ex.Message); }
    }

    private void Publish(Built b)
    {
        var surfaces = new List<CellSurface>();
        var portals = new List<PortalPlane>();
        LandblockCollision.PublishPreparedCells(Cache, b.Landblock, b.Collisions, b.Origin, surfaces, portals);
        LandblockCollision.CacheBuildings(Cache, b.Landblock, b.Terrain, b.Origin);
        LandblockCollision.CachePreparedObjects(Cache, b.Collisions);
        Engine.AddLandblock(b.Landblock.LandblockId, b.Terrain, surfaces, portals, b.Origin.X, b.Origin.Y);
        LandblockCollision.PublishStaticCollision(Engine, Cache, b.Landblock, b.Collisions, b.Origin);
        // doors left open stay open when their landblock's collision comes back (and another dungeon's things aren't here)
        int bx = (int)((b.Landblock.LandblockId >> 24) & 0xFF), by = (int)((b.Landblock.LandblockId >> 16) & 0xFF);
        foreach (uint id in _open)
            if (((id >> 20) & 0xFF) == bx && ((id >> 12) & 0xFF) == by)
                Engine.ShadowObjects.UpdatePhysicsState(id, (uint)OpenDoor);
        if (_only is { } o && o != (bx, by)) ApplySolid((bx, by));
        // the server's things standing in it: their collision goes in with it
        _published[(bx, by)] = (b.Landblock, b.Origin);
        foreach (var t in _server.Values)
            if (LbOf(t) == (bx, by)) { t.In = false; PutIn(t); }
    }

    // ── in a dungeon: the dungeons next to it in the landblock grid share its space (their rooms are other cells, but
    //    their creatures, doors and chests stood about in it - a drudge from next door blocked the rats here). Only the
    //    one you're in has solid things; the others' are walked through. ──
    private readonly Dictionary<(int x, int y), HashSet<uint>> _spawnIds = new();
    private readonly HashSet<uint> _soft = new();   // creatures lying dead (walked over)
    private (int x, int y)? _only;

    /// <summary>The dungeon landblock you're in (null: outdoors - everything is solid).</summary>
    public void SetOnlyLandblock((int x, int y)? lb)
    {
        if (_only == lb) return;
        _only = lb;
        List<(int, int)> keys; lock (_spawnIds) keys = _spawnIds.Keys.ToList();
        foreach (var k in keys) if (_ready.Contains(k)) ApplySolid(k);
    }

    private void ApplySolid((int x, int y) lb)
    {
        uint[] ids; lock (_spawnIds) { if (!_spawnIds.TryGetValue(lb, out var set)) return; ids = set.ToArray(); }
        bool away = _only is { } o && o != lb;
        foreach (uint id in ids)
        {
            bool walkThrough = away || _open.Contains(id) || _soft.Contains(id);
            try { Engine.ShadowObjects.UpdatePhysicsState(id, (uint)(walkThrough ? OpenDoor : PhysicsStateFlags.Static)); } catch { }
        }
    }

    /// <summary>
    /// Moves a creature placed from the world database (its landblock and place in the landblock's list) from one
    /// point to another (AC world), through the collision as the client moves a monster: along the ground, up steps,
    /// sliding along walls, and not into other things. Its collision goes with it. Returns where it got to and its
    /// cell, or null if its part of the world's collision isn't loaded (then it moves without).
    /// </summary>
    /// <summary>What the last creature move bumped into (for the P capture).</summary>
    public string LastCreatureHit = "";

    public (Vector3 acWorld, uint cell)? MoveCreature(int lbx, int lby, int index, Vector3 fromAc, Vector3 toAc, uint cell,
                                                     float radius, float height, Quaternion rotation)
    {
        int fx = (int)MathF.Floor(fromAc.X / 192f), fy = (int)MathF.Floor(fromAc.Y / 192f);
        if (!IsReady(fx, fy)) return null;
        Vector3 from = ToFrame(fromAc), to = ToFrame(toAc);
        if (cell == 0) cell = OutdoorCell(from);
        height = BodyHeight(radius, height);
        uint id = SpawnId(lbx, lby, index);
        try
        {
            // a small body steps down no further than it's tall: with a person's step down (1.5 m) a rat's every step
            // failed - it stayed put (ok, nothing hit) and ran on the spot
            float down = Math.Min(StepDown, Math.Max(0.6f, height));
            var r = Engine.ResolveWithTransition(from, to, cell, radius, height, Math.Min(StepUp, Math.Max(0.3f, height)), down, isOnGround: true, body: null,
                moverFlags: ObjectInfoState.EdgeSlide, movingEntityId: id);
            Vector3 got = r.Ok ? r.Position : from;
            uint nc = r.Ok && r.CellId != 0 ? r.CellId : cell;
            uint hit = r.LastCollidedObjectId;
            LastCreatureHit = $"me {id:X8} ok={r.Ok}" + (hit != 0 ? $" hit {hit:X8}" + ((hit >> 28) == 7 ? $" (lb {(hit >> 20) & 0xFF:X2}{(hit >> 12) & 0xFF:X2} #{hit & 0xFFF})" : "") : "")
                              + (r.CollidedWithEnvironment ? " walls" : "");
            if (got != from && lbx >= 0)
            {
                Vector3 w = FromFrame(got);
                int lx = (int)MathF.Floor(w.X / 192f), ly = (int)MathF.Floor(w.Y / 192f);
                Engine.ShadowObjects.UpdatePosition(id, got, rotation, (lx - _ox) * 192f, (ly - _oy) * 192f, LandblockId(lx, ly),
                    (nc & 0xFFFFu) >= 0x100u ? nc : 0u);
            }
            return (FromFrame(got), (nc & 0xFFFFu) >= 0x100u ? nc : 0u);
        }
        catch (Exception ex)
        {
            Godot.GD.PushWarning("creature move: " + ex.Message);
            return null;
        }
    }

    /// <summary>
    /// Where a creature lands straight below a point (AC world): a sweep down through the collision (not walking - nothing
    /// steps it up), up to <paramref name="most"/> metres. Null when nothing is under it that far, or the collision isn't loaded.
    /// </summary>
    public (Vector3 acWorld, uint cell)? DropCreature(int lbx, int lby, int index, Vector3 fromAc, uint cell, float radius, float height, float most = 3f)
    {
        int fx = (int)MathF.Floor(fromAc.X / 192f), fy = (int)MathF.Floor(fromAc.Y / 192f);
        if (!IsReady(fx, fy) || cell == 0) return null;
        Vector3 from = ToFrame(fromAc), to = from - new Vector3(0, 0, most);
        height = BodyHeight(radius, height);
        try
        {
            var r = Engine.ResolveWithTransition(from, to, cell, radius, height, 0f, 0f, isOnGround: false, body: null,
                moverFlags: ObjectInfoState.EdgeSlide, movingEntityId: SpawnId(lbx, lby, index));
            if (!r.Ok || r.Position.Z <= to.Z + 0.01f) return null;   // fell the whole way: no floor under it
            return (FromFrame(r.Position), r.CellId != 0 ? r.CellId : cell);
        }
        catch { return null; }
    }

    /// <summary>
    /// A body's height for the collision's two spheres (one at the radius, one at the height less the radius): never less
    /// than its width - shorter, the second sphere sat below the first, under the floor, and the creature was stuck in it
    /// (it ran on the spot, or the step up lifted it bit by bit into the air).
    /// </summary>
    private static float BodyHeight(float radius, float height) => height <= 0f ? 0f : Math.Max(height, radius * 2f + 0.01f);

    /// <summary>A creature's collision moved back to a point (AC world): where it stands again after going home or respawning.</summary>
    public void PlaceCreature(int lbx, int lby, int index, Vector3 acWorld, Quaternion rotation, uint cell)
    {
        int lx = (int)MathF.Floor(acWorld.X / 192f), ly = (int)MathF.Floor(acWorld.Y / 192f);
        if (lbx < 0 || !IsReady(lx, ly)) return;
        try
        {
            Engine.ShadowObjects.UpdatePosition(SpawnId(lbx, lby, index), ToFrame(acWorld), rotation, (lx - _ox) * 192f, (ly - _oy) * 192f,
                LandblockId(lx, ly), (cell & 0xFFFFu) >= 0x100u ? cell : 0u);
        }
        catch (Exception ex) { Godot.GD.PushWarning("creature place: " + ex.Message); }
    }

    /// <summary>A creature's collision switched off (dead: you walk over its corpse) or on again.</summary>
    /// <summary>For testing: a person-sized body walked from one point to another (AC world) - where it stops, and what stopped
    /// it (a server's thing by name, or the id of the world's own object, or walls).</summary>
    private readonly System.Collections.Generic.HashSet<uint> _probed = new();
    public void ProbeReset() => _probed.Clear();

    public string Probe(Vector3 fromAc, uint cell, Vector3 toAc)
    {
        int fx = (int)MathF.Floor(fromAc.X / 192f), fy = (int)MathF.Floor(fromAc.Y / 192f);
        if (!IsReady(fx, fy)) return "not loaded";
        try
        {
            Vector3 from = ToFrame(fromAc), to = ToFrame(toAc);
            if (cell == 0) cell = OutdoorCell(from);
            var r = Engine.ResolveWithTransition(from, to, cell, 0.48f, 1.8f, StepUp, StepDown, isOnGround: true, body: null,
                moverFlags: ObjectInfoState.EdgeSlide, movingEntityId: 0x000F4245u);
            Vector3 got = r.Ok ? r.Position : from;
            float went = new Vector2(got.X - from.X, got.Y - from.Y).Length(), of = new Vector2(to.X - from.X, to.Y - from.Y).Length();
            uint hit = r.LastCollidedObjectId;
            string what = "";
            if (hit != 0)
            {
                foreach (var kv in _server) if (kv.Value.Id == hit) { what = $"{kv.Key:X8} {kv.Value.Note} ({kv.Value.Kind}, setup {kv.Value.Setup:X8} scale {kv.Value.Scale:0.##})"; break; }
                if (what.Length == 0) what = $"world object {hit:X8}" + ((hit >> 28) == 7 ? $" (lb {(hit >> 20) & 0xFF:X2}{(hit >> 12) & 0xFF:X2} #{hit & 0xFFF})" : "");
            }
            // (and its collision pieces: where each is against you, metres east / north / up, its size and turn)
            if (hit != 0 && !_probed.Contains(hit))
            {
                _probed.Add(hit);
                var parts = new System.Collections.Generic.List<ShadowEntry>();
                try { Engine.ShadowObjects.CaptureEntries(hit, parts); } catch { }
                foreach (var pe in parts)
                {
                    Vector3 d = pe.Position - from;
                    var g = Cache.GetGfxObj(pe.GfxObjId);
                    float yaw = 2f * MathF.Atan2(pe.Rotation.Z, pe.Rotation.W) * 180f / MathF.PI;
                    what += $"\n      piece {pe.GfxObjId:X8} {pe.CollisionType} at {d.X:0.00},{d.Y:0.00},{d.Z:0.00} radius {pe.Radius:0.00} scale {pe.Scale:0.##} yaw {yaw:0} (turn w {pe.Rotation.W:0.##} x {pe.Rotation.X:0.##} y {pe.Rotation.Y:0.##} z {pe.Rotation.Z:0.##}) local {pe.LocalPosition.X:0.00},{pe.LocalPosition.Y:0.00},{pe.LocalPosition.Z:0.00}" +
                            (g?.BoundingSphere is { } bs ? $" its sphere at {bs.Origin.X:0.0},{bs.Origin.Y:0.0},{bs.Origin.Z:0.0} r {bs.Radius:0.0}" : "");
                }
            }
            return $"{went:0.00} of {of:0.00} m{(r.Ok ? "" : " (failed)")}" + (what.Length > 0 ? " - hit " + what : "") + (r.CollidedWithEnvironment ? " - walls" : "");
        }
        catch (Exception ex) { return "error: " + ex.Message; }
    }

    public void SetCreatureSolid(int lbx, int lby, int index, bool solid)
    {
        if (lbx < 0) return;
        uint sid = SpawnId(lbx, lby, index);
        if (solid) _soft.Remove(sid); else _soft.Add(sid);
        if (solid && _only is { } o && o != (lbx, lby)) solid = false;   // (another dungeon's: walked through)
        try { Engine.ShadowObjects.UpdatePhysicsState(sid, (uint)(solid ? PhysicsStateFlags.Static : OpenDoor)); }
        catch (Exception ex) { Godot.GD.PushWarning("creature solid: " + ex.Message); }
    }

    // ── a server's things (people, creatures, doors, chests, forges...): their collision put in where the server puts
    //    them, moved as they move, switched off (an open door, a creature dead) and taken out when they go ──
    private sealed class ServerThing
    {
        public uint Id, Setup, Cell;
        public List<MeshRef> Parts = new();
        public float Scale = 1f;
        public Vector3 Ac, At;      // where it is (AC world), and where its collision was last put
        public Quaternion Rot = Quaternion.Identity;
        public bool Solid = true, In, Creature;
        public string Kind = "", Note = "";
    }
    private readonly Dictionary<uint, ServerThing> _server = new();
    private readonly Dictionary<(int x, int y), (LoadedLandblock lb, Vector3 origin)> _published = new();
    private uint _nextServerId = 0x2F000000u;
    /// <summary>Where the player stands (AC world): a thing's collision isn't moved onto them.</summary>
    public Func<Vector3>? PlayerAc;
    public int ServerThings => _server.Count;
    public string LastServerError = "";
    public int ServerAdds, ServerRemoves;
    public int ServerThingsIn => _server.Values.Count(t => t.In);

    /// <summary>The server's things near a point (AC world), and how their collision stands (the test bridge's "motions").</summary>
    public IEnumerable<string> ServerReport(Vector3 ac, float within = 12f)
    {
        foreach (var (guid, t) in _server)
            if ((t.Ac - ac).Length() <= within)
                yield return $"{guid:X8} {t.Note}: {(t.In ? "in" : "out")} {t.Kind} {(t.Solid ? "solid" : "walked through")} setup {t.Setup:X8} parts {t.Parts.Count} scale {t.Scale:0.##} cell {t.Cell:X8} lb {LbOf(t)} {(t.Ac - ac).Length():0.0} m";
    }

    /// <summary>A thing the server placed: kind 0 a creature or person (a body narrower than its model), 1 anything else.</summary>
    public void AddServerThing(uint guid, uint setupId, uint motionTable, int kind, float scale, Vector3 acWorld, Quaternion rot, uint cell, bool solid, string note = "",
                               System.Collections.Generic.IReadOnlyList<(int index, uint gfx)>? swaps = null)
    {
        RemoveServerThing(guid);
        ServerAdds++;
        try
        {
            if (setupId == 0 || _dats.Get<Setup>(setupId) is not { } setup) return;
            scale = scale > 0f ? scale : 1f;
            if (kind == 0) scale *= CreatureBody;
            DatReaderWriter.Types.AnimationFrame? pose = null;
            if (kind != 0 && motionTable != 0)
                try { pose = AcDream.Core.Meshing.MotionResolver.GetIdleFrame(setup, _dats, _animLoader, motionTable); } catch { pose = null; }
            var t = new ServerThing { Id = _nextServerId++, Setup = setupId, Scale = scale, Ac = acWorld, Rot = rot, Cell = (cell & 0xFFFFu) >= 0x100u ? cell : 0u, Solid = solid, Note = note, Creature = kind == 0 };
            // (its parts as the server has them: a part it swapped for another - a house of the server's own built on
            // a setup's frame - is that other one here too, as it's drawn; with the setup's own part the collision stood
            // somewhere the house isn't - you were stopped in the open by a vendor and walked through the real wall)
            int pi = 0;
            foreach (MeshRef mr in AcDream.Core.Meshing.SetupMesh.Flatten(setup, pose))
            {
                uint gfx = mr.GfxObjId;
                if (swaps != null)
                    foreach (var (index, sg) in swaps)
                        if (index == pi && (sg >> 24) == 0x01 && _dats.Get<GfxObj>(sg) != null) gfx = sg;
                t.Parts.Add(new MeshRef(gfx, mr.PartTransform * Matrix4x4.CreateScale(scale)));
                pi++;
            }
            if (t.Parts.Count == 0) return;
            _server[guid] = t;
            PutIn(t);
        }
        catch (Exception ex) { LastServerError = "add: " + ex; Godot.GD.PushWarning("server thing: " + ex.Message); }
    }

    // the landblock a server's thing is in: its room's (a dungeon's rooms lie off their own square of the map), else where it stands
    private static (int x, int y) LbOf(ServerThing t) =>
        t.Cell != 0 ? ((int)(t.Cell >> 24), (int)((t.Cell >> 16) & 0xFF)) : ((int)MathF.Floor(t.Ac.X / 192f), (int)MathF.Floor(t.Ac.Y / 192f));

    private bool OnPlayer(Vector3 ac)
    {
        if (PlayerAc == null) return false;
        Vector3 me = PlayerAc();
        return MathF.Abs(me.Z - ac.Z) < 2.5f && new Vector2(me.X - ac.X, me.Y - ac.Y).Length() < 1.1f;
    }

    private readonly HashSet<ServerThing> _waiting = new();
    private int _waitTick;

    private void PutIn(ServerThing t)
    {
        var (lx, ly) = LbOf(t);
        if (t.In) { try { Engine.ShadowObjects.Deregister(t.Id); } catch { } t.In = false; }
        if (!_published.TryGetValue((lx, ly), out var pub)) return;
        // (standing in it - put down in the middle of a lifestone: left out till you've stepped clear, then put in;
        // left out for good, the stone had no collision till you logged in again)
        if (OnPlayer(t.Ac)) { _waiting.Add(t); return; }
        _waiting.Remove(t);
        try
        {
            // its shapes, in the collision's store as it is now (a new one is started when you're sent far off)
            foreach (var mr in t.Parts)
                if (Cache.GetFlatGfxObj(mr.GfxObjId) == null && _dats.Get<GfxObj>(mr.GfxObjId) is { } g)
                    try { Cache.CacheGfxObj(mr.GfxObjId, FlatCollisionAssetBuilder.FlattenGfxObj(g)); } catch (Exception ex) { LastServerError = "shape: " + ex.Message; }
            if (Cache.GetFlatSetup(t.Setup) == null && _dats.Get<Setup>(t.Setup) is { } su)
                try { Cache.CacheSetup(t.Setup, FlatCollisionAssetBuilder.FlattenSetup(su)); } catch (Exception ex) { LastServerError = "setup: " + ex.Message; }
            var e = new WorldEntity
            {
                Id = t.Id, SourceGfxObjOrSetupId = t.Setup, Position = ToFrame(t.Ac), Rotation = t.Rot, MeshRefs = t.Parts, Scale = t.Scale,
                ParentCellId = t.Cell != 0 ? t.Cell : null,
            };
            t.Kind = LandblockCollision.PublishStaticEntity(Engine, Cache, pub.lb, pub.origin, e).ToString();
            try { Engine.ShadowObjects.RefloodOwnerForLandblock(t.Id, pub.lb.LandblockId); } catch { }   // (filed into the cells it reaches)
            t.In = true; t.At = t.Ac;
            if (!t.Solid) Engine.ShadowObjects.UpdatePhysicsState(t.Id, (uint)OpenDoor);
        }
        catch (Exception ex) { LastServerError = "in: " + ex; Godot.GD.PushWarning("server thing in: " + ex.Message); }
    }

    /// <summary>A server's thing moved or turned (its cell: 0 to keep the one it had, when it's still indoors).</summary>
    public void MoveServerThing(uint guid, Vector3 acWorld, Quaternion rot, uint cell = 0, bool outdoors = false)
    {
        if (!_server.TryGetValue(guid, out var t)) return;
        t.Ac = acWorld; t.Rot = rot;
        if ((cell & 0xFFFFu) >= 0x100u) t.Cell = cell; else if (outdoors) t.Cell = 0;
        // (not for every small step, and not onto you: something running at you stops where it last stood clear)
        if (t.In && (t.At - acWorld).LengthSquared() < 0.09f) return;
        if (OnPlayer(acWorld)) return;
        PutIn(t);
    }

    /// <summary>A server's thing made solid, or walked through (an open door, a creature dead).</summary>
    public void SetServerThingSolid(uint guid, bool solid)
    {
        if (!_server.TryGetValue(guid, out var t) || t.Solid == solid) return;
        t.Solid = solid;
        if (!t.In) return;
        try { Engine.ShadowObjects.UpdatePhysicsState(t.Id, (uint)(solid ? PhysicsStateFlags.Static : OpenDoor)); }
        catch (Exception ex) { Godot.GD.PushWarning("server thing solid: " + ex.Message); }
    }

    public void RemoveServerThing(uint guid)
    {
        if (!_server.Remove(guid, out var t)) return;
        ServerRemoves++;
        if (!t.In) return;
        try { Engine.ShadowObjects.Deregister(t.Id); } catch { }
    }

    /// <summary>Where a thing of the server's stands (AC world), if its collision is known here.</summary>
    public Vector3? ServerThingAc(uint guid) => _server.TryGetValue(guid, out var t) ? t.Ac : null;

    /// <summary>
    /// Whether a straight line between two points (AC world) is clear of the world: walls, floors, ceilings, doors that are
    /// shut, and things that stand about (tables, chests, statues). Creatures and people - pets, monsters, other players -
    /// don't count: they're taken out of the way for the check, so only what's really in front of or behind them does.
    /// A small ball is swept along it, the way the camera is kept out of the walls. Null when the collision isn't loaded
    /// there; otherwise (clear, what was in the way).
    /// </summary>
    public (bool clear, string what)? ClearLine(Vector3 fromAc, uint fromCell, Vector3 toAc, float stopShort = 0.7f, uint skipGuid = 0)
    {
        int fx = (int)MathF.Floor(fromAc.X / 192f), fy = (int)MathF.Floor(fromAc.Y / 192f);
        if (!IsReady(fx, fy) || fromCell == 0) return null;
        Vector3 d = toAc - fromAc;
        float len = d.Length();
        if (len <= stopShort + 0.5f) return (true, "");
        Vector3 end = fromAc + d * ((len - stopShort) / len);
        const float R = 0.1f;
        _server.TryGetValue(skipGuid, out var skip);   // (the thing aimed at: not in its own way)
        var off = new List<uint>();
        foreach (var t in _server.Values)
            if ((t.Creature || t == skip) && t.In && t.Solid)
                try { Engine.ShadowObjects.UpdatePhysicsState(t.Id, (uint)OpenDoor); off.Add(t.Id); } catch { }
        try
        {
            Vector3 f = ToFrame(fromAc), e = ToFrame(end);
            var r = Engine.ResolveWithTransition(f, e, fromCell, R, 0f, 0f, 0f, isOnGround: false, body: null,
                moverFlags: ObjectInfoState.IsViewer | ObjectInfoState.PathClipped | ObjectInfoState.FreeRotate | ObjectInfoState.PerfectClip,
                movingEntityId: 0x000F4243u);
            if (!r.Ok) return null;
            if ((r.Position - e).Length() < 0.3f) return (true, "");
            uint hit = r.LastCollidedObjectId;
            string what = r.CollidedWithEnvironment ? "a wall" : hit == 0 ? "something"
                        : _server.Values.FirstOrDefault(t => t.Id == hit) is { } st ? (st.Note.Length > 0 ? st.Note : "a thing")
                        : (hit >> 28) == 7 ? "an object" : "an object";
            return (false, $"{what} {(r.Position - f).Length():0.0} m along (height {r.Position.Z - f.Z:+0.0;-0.0} on the way to {e.Z - f.Z:+0.0;-0.0})");
        }
        catch { return null; }
        finally
        {
            foreach (uint id in off)
                try { Engine.ShadowObjects.UpdatePhysicsState(id, (uint)PhysicsStateFlags.Static); } catch { }
        }
    }

    /// <summary>
    /// A ball swept from one point to another (AC world) through the world's collision - the ground, floors, walls, things
    /// that stand about - for the jump's arc. Null when the collision isn't loaded there; otherwise where the ball got
    /// to, the cell it's in, and whether something stopped it short.
    /// </summary>
    public (Vector3 acWorld, uint cell, bool stopped)? SweepBall(Vector3 fromAc, uint fromCell, Vector3 toAc, float radius)
    {
        int fx = (int)MathF.Floor(fromAc.X / 192f), fy = (int)MathF.Floor(fromAc.Y / 192f);
        if (!IsReady(fx, fy)) return null;
        try
        {
            Vector3 f = ToFrame(fromAc), e = ToFrame(toAc);
            if (fromCell == 0) fromCell = OutdoorCell(f);
            var r = Engine.ResolveWithTransition(f, e, fromCell, radius, 0f, 0f, 0f, isOnGround: false, body: null,
                moverFlags: ObjectInfoState.PathClipped | ObjectInfoState.FreeRotate | ObjectInfoState.PerfectClip,
                movingEntityId: 0x000F4244u);
            if (!r.Ok) return (fromAc, fromCell, true);
            bool stopped = (r.Position - e).Length() > 0.02f;
            return (FromFrame(r.Position), r.CellId != 0 ? r.CellId : fromCell, stopped);
        }
        catch { return null; }
    }

    /// <summary>The cell a point (physics frame) is in, outdoors: the landscape cell under it.</summary>
    public uint OutdoorCell(Vector3 frame)
    {
        Vector3 w = FromFrame(frame);
        int lx = (int)MathF.Floor(w.X / 192f), ly = (int)MathF.Floor(w.Y / 192f);
        uint low = TerrainSurface.ComputeOutdoorCellId(LandblockId(lx, ly), w.X - lx * 192f, w.Y - ly * 192f);
        return (LandblockId(lx, ly) & 0xFFFF0000u) | (low & 0xFFFFu);
    }

    /// <summary>
    /// Places a body at a point (physics frame), as the client places a character: in the cell that holds it (a
    /// building's room, a dungeon cell or the landscape), moved clear if something is in the way. Null if it can't.
    /// </summary>
    public (Vector3 position, uint cell, bool onWalkable, Plane contact)? Place(Vector3 frame, Quaternion orientation,
        ImmutableArray<FlatCollisionSphere> spheres, float stepUp, float stepDown, uint seedCell)
    {
        uint cell = seedCell != 0 ? seedCell : OutdoorCell(frame);
        Vector3 w = FromFrame(frame);
        int lx = (int)MathF.Floor(w.X / 192f), ly = (int)MathF.Floor(w.Y / 192f);
        Vector3 local = new(w.X - lx * 192f, w.Y - ly * 192f, w.Z);
        try
        {
            var r = Engine.SetPosition(new PhysicsSetPositionRequest(frame, orientation, cell, local, spheres,
                Scale: 1f, StepUpHeight: stepUp, StepDownHeight: stepDown,
                MoverPhysicsState: PhysicsStateFlags.Gravity | PhysicsStateFlags.EdgeSlide,
                MoverFlags: ObjectInfoState.IsPlayer | ObjectInfoState.EdgeSlide | ObjectInfoState.CanBypassMoveRestrictions,   // (house rooms: see Player.HouseRooms)
                MovingEntityId: 0x000F4243u,
                Flags: PhysicsSetPositionFlags.Placement | PhysicsSetPositionFlags.Slide | PhysicsSetPositionFlags.DoNotCreateCells));
            if (!r.IsCommitted) return null;
            return (r.Position, r.CellId, r.OnWalkable, r.ContactPlane);
        }
        catch (Exception ex)
        {
            Godot.GD.PushWarning("place: " + ex.Message);
            return null;
        }
    }
}
