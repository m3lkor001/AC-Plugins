/*
 * mtlaunch.exe - starts acclient.exe with Decal loaded, for the MelkTank Linux launcher.
 * Runs inside Wine. Loads Decal the way ThwargLauncher's injector.dll does (the client is started suspended, Decal's
 * Inject.dll is loaded into it, its DecalStartup is run, then the client carries on) - done here, so ThwargLauncher
 * isn't needed. Its injector.dll can still be used instead (give its path in place of "builtin").
 *
 *   mtlaunch.exe builtin <acclient.exe> [client arguments...]
 *   mtlaunch.exe <injector.dll> <acclient.exe> [client arguments...]
 *   mtlaunch.exe --enter <pid>     clicks the character screen's Enter button in that client's window
 *                                  (ThwargFilter selects the character and clicks Enter at once; under Wine the
 *                                  Enter click can land before the selection has gone through, so the launcher
 *                                  clicks it again a few times until MelkTank reports the character in the world)
 *
 * Prints "PID <n>" on success, "ERROR <text>" otherwise. Built without the C runtime to stay tiny:
 *   i686-w64-mingw32-gcc -Os -s -nostdlib -e _start@0 -o mtlaunch.exe mtlaunch.c -lkernel32 -ladvapi32 -lshell32 -luser32
 */
#include <windows.h>
#include <shellapi.h>

typedef int (__cdecl *LaunchInjected_t)(const wchar_t *command_line, const wchar_t *working_directory,
                                        const wchar_t *inject_dll_path, const char *initialize_function);

static void out(const char *s)
{
    DWORD n;
    WriteFile(GetStdHandle(STD_OUTPUT_HANDLE), s, lstrlenA(s), &n, NULL);
}

static void fail(const char *msg, DWORD code)
{
    char buf[400];
    wsprintfA(buf, "ERROR %s (code %lu)\r\n", msg, (unsigned long)code);
    out(buf);
    ExitProcess(1);
}

static HWND found;
static DWORD foundArea;

static BOOL CALLBACK FindMain(HWND w, LPARAM pid)
{
    DWORD p = 0;
    GetWindowThreadProcessId(w, &p);
    if (p != (DWORD)pid || !IsWindowVisible(w) || GetWindow(w, GW_OWNER)) return TRUE;
    RECT r;
    if (!GetClientRect(w, &r)) return TRUE;
    DWORD area = (DWORD)((r.right - r.left) * (r.bottom - r.top));
    if (area >= foundArea) { found = w; foundArea = area; }
    return TRUE;
}

/* The same clicks ThwargFilter sends (PostMsgs.SendMouseClick): move, left down, left up at x,y in the window. */
static void Click(HWND w, int x, int y)
{
    LPARAM loc = (LPARAM)((y << 16) | (x & 0xffff));
    PostMessageW(w, WM_MOUSEMOVE, 0, loc);
    PostMessageW(w, WM_LBUTTONDOWN, 1, loc);
    PostMessageW(w, WM_LBUTTONUP, 0, loc);
}

/* Runs fn(arg) in the other process and waits for it; the thread's exit code comes back (0 on failure). */
static DWORD RemoteCall(HANDLE proc, LPTHREAD_START_ROUTINE fn, LPVOID arg, const char **why)
{
    HANDLE t = CreateRemoteThread(proc, NULL, 0, fn, arg, 0, NULL);
    if (!t) { *why = "CreateRemoteThread failed"; return 0; }
    DWORD code = 0;
    if (WaitForSingleObject(t, 60000) != WAIT_OBJECT_0) { *why = "the remote call didn't finish"; CloseHandle(t); return 0; }
    GetExitCodeThread(t, &code);
    CloseHandle(t);
    return code;
}

/* What injector.dll's LaunchInjected does: start the client suspended, LoadLibraryW(Inject.dll) in it, call its
   DecalStartup (at the same offset from the DLL's base as in a copy loaded here without running it), resume. */
static int LaunchBuiltin(wchar_t *command_line, const wchar_t *dir, const wchar_t *dll, const char *init)
{
    STARTUPINFOW si; PROCESS_INFORMATION pi;
    const char *why = "";
    char buf[300];
    ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
    ZeroMemory(&pi, sizeof(pi));
    if (!CreateProcessW(NULL, command_line, NULL, NULL, FALSE, CREATE_SUSPENDED, NULL, dir, &si, &pi))
        fail("couldn't start acclient.exe", GetLastError());

    SIZE_T bytes = (SIZE_T)(lstrlenW(dll) + 1) * sizeof(wchar_t);
    LPVOID mem = VirtualAllocEx(pi.hProcess, NULL, bytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!mem || !WriteProcessMemory(pi.hProcess, mem, dll, bytes, NULL))
    { TerminateProcess(pi.hProcess, 1); fail("couldn't write into the client", GetLastError()); }

    LPTHREAD_START_ROUTINE loadLib = (LPTHREAD_START_ROUTINE)GetProcAddress(GetModuleHandleW(L"kernel32.dll"), "LoadLibraryW");
    DWORD remoteBase = RemoteCall(pi.hProcess, loadLib, mem, &why);
    VirtualFreeEx(pi.hProcess, mem, 0, MEM_RELEASE);
    if (!remoteBase) { TerminateProcess(pi.hProcess, 1); wsprintfA(buf, "Decal's Inject.dll didn't load in the client (%s)", why); fail(buf, GetLastError()); }

    HMODULE local = LoadLibraryExW(dll, NULL, DONT_RESOLVE_DLL_REFERENCES);
    if (!local) { TerminateProcess(pi.hProcess, 1); fail("can't read Decal's Inject.dll", GetLastError()); }
    FARPROC fn = GetProcAddress(local, init);
    if (!fn) { TerminateProcess(pi.hProcess, 1); fail("Inject.dll has no DecalStartup", GetLastError()); }
    DWORD offset = (DWORD)((char *)fn - (char *)local);
    FreeLibrary(local);

    why = "";
    RemoteCall(pi.hProcess, (LPTHREAD_START_ROUTINE)(ULONG_PTR)(remoteBase + offset), NULL, &why);
    if (*why) { TerminateProcess(pi.hProcess, 1); wsprintfA(buf, "DecalStartup didn't run (%s)", why); fail(buf, GetLastError()); }

    ResumeThread(pi.hThread);
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    return (int)pi.dwProcessId;
}

static wchar_t cmd[8192], workdir[MAX_PATH * 2], agent[MAX_PATH], inject[MAX_PATH * 2];

void __stdcall start(void)
{
    int argc = 0;
    wchar_t **argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    if (!argv || argc < 3) fail("usage: mtlaunch.exe <injector.dll> <acclient.exe> [args...]", 0);

    if (lstrcmpiW(argv[1], L"--enter") == 0)
    {
        DWORD pid = 0;
        for (const wchar_t *c = argv[2]; *c >= L'0' && *c <= L'9'; c++) pid = pid * 10 + (DWORD)(*c - L'0');
        EnumWindows(FindMain, (LPARAM)pid);
        if (!found) fail("no window for that client", pid);
        Click(found, 0x015C, 0x0185);   /* the Enter button (ThwargFilter's numbers) */
        out("OK\r\n");
        ExitProcess(0);
    }
    const wchar_t *injector = argv[1], *client = argv[2];

    /* Decal's Inject.dll: HKLM\SOFTWARE\Decal\Agent  AgentPath */
    DWORD size = sizeof(agent);
    LONG r = RegGetValueW(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Decal\\Agent", L"AgentPath", RRF_RT_REG_SZ, NULL, agent, &size);
    if (r != ERROR_SUCCESS) fail("Decal isn't installed in this Wine prefix (no AgentPath)", (DWORD)r);
    lstrcpyW(inject, agent);
    int len = lstrlenW(inject);
    if (len > 0 && inject[len - 1] != L'\\') lstrcatW(inject, L"\\");
    lstrcatW(inject, L"Inject.dll");
    if (GetFileAttributesW(inject) == INVALID_FILE_ATTRIBUTES) fail("Decal's Inject.dll not found", GetLastError());

    /* working directory = the client's folder */
    lstrcpynW(workdir, client, MAX_PATH * 2);
    for (int i = lstrlenW(workdir) - 1; i >= 0; i--) if (workdir[i] == L'\\') { workdir[i] = 0; break; }

    /* command line exactly as ThwargLauncher builds it: "<exe> <args>" */
    lstrcpynW(cmd, client, 8000);
    for (int i = 3; i < argc; i++)
    {
        if (lstrlenW(cmd) + lstrlenW(argv[i]) + 2 >= 8192) break;
        lstrcatW(cmd, L" ");
        lstrcatW(cmd, argv[i]);
    }

    if (lstrcmpiW(injector, L"builtin") == 0)
    {
        int bpid = LaunchBuiltin(cmd, workdir, inject, "DecalStartup");
        char bbuf[64];
        wsprintfA(bbuf, "PID %d\r\n", bpid);
        out(bbuf);
        ExitProcess(0);
    }

    HMODULE h = LoadLibraryW(injector);
    if (!h) fail("can't load injector.dll", GetLastError());
    LaunchInjected_t launch = (LaunchInjected_t)GetProcAddress(h, "LaunchInjected");
    if (!launch) fail("injector.dll has no LaunchInjected", GetLastError());

    int pid = launch(cmd, workdir, inject, "DecalStartup");
    if (pid <= 0) fail("LaunchInjected failed", (DWORD)pid);
    char buf[64];
    wsprintfA(buf, "PID %d\r\n", pid);
    out(buf);
    ExitProcess(0);
}
