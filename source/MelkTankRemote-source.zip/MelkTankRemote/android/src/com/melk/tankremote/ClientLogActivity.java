package com.melk.tankremote;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The client history the PC keeps: when each game client was launched, got into the game, stopped answering,
 * disconnected, crashed, was closed and restarted - with how long each run lasted, and a summary of the last
 * 24 hours per account (time in game, longest run, restarts, crashes, freezes).
 */
public class ClientLogActivity extends Activity {
    private static final int CYAN = Color.rgb(90, 214, 242), ORANGE = Color.rgb(232, 163, 58), PURPLE = Color.rgb(182, 133, 242);
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private Prefs prefs;
    private Spinner who;
    private TextView status;
    private LinearLayout summary, list;
    private final List<String> accounts = new ArrayList<>();
    private boolean filling;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        setTitle("Client log");
        if (getActionBar() != null) getActionBar().setDisplayHomeAsUpEnabled(true);

        LinearLayout root = Ui.vbox(this);
        int p = Ui.dp(this, 10);
        root.setPadding(p, p, p, p);

        LinearLayout bar = Ui.hbox(this);
        Button back = new Button(this);
        back.setText("‹ Back");
        back.setOnClickListener(v -> finish());
        bar.addView(back);
        who = new Spinner(this);
        bar.addView(who, Ui.weight(1));
        Button refresh = new Button(this);
        refresh.setText("Refresh");
        refresh.setOnClickListener(v -> load());
        bar.addView(refresh);
        root.addView(bar);

        status = Ui.text(this, "Loading...", 13, false);
        status.setTextColor(Ui.muted(this));
        root.addView(status);

        ScrollView sv = new ScrollView(this);
        LinearLayout inner = Ui.vbox(this);
        summary = Ui.vbox(this);
        list = Ui.vbox(this);
        inner.addView(summary);
        inner.addView(list);
        sv.addView(inner);
        root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(PullRefresh.wrap(this, root, this::pullRefresh));

        accounts.add("");
        setSpinner(new String[]{"All accounts"});
        who.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { if (!filling) load(); }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        load();
    }

    private void setSpinner(String[] items) {
        boolean dark = Ui.dark(this);
        int fg = dark ? Color.WHITE : Color.BLACK, bg = dark ? Color.rgb(48, 52, 58) : Color.rgb(236, 238, 241);
        int pad = Ui.dp(this, 10);
        who.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            private View style(View v) {
                TextView t = (TextView) v;
                t.setTextColor(fg);
                t.setBackgroundColor(bg);
                t.setPadding(pad, pad, pad, pad);
                return t;
            }
            @Override public View getView(int i, View c, ViewGroup g) { return style(super.getView(i, c, g)); }
            @Override public View getDropDownView(int i, View c, ViewGroup g) { return style(super.getDropDownView(i, c, g)); }
        });
    }

    private String selected() {
        int i = who.getSelectedItemPosition();
        return i >= 0 && i < accounts.size() ? accounts.get(i) : "";
    }

    /** Pull down: load the page again. */
    private void pullRefresh(PullRefresh pr) {
        load();
        main.postDelayed(pr::done, 1500);
    }

    private void load() {
        String acct = selected();
        status.setText("Loading...");
        io.execute(() -> {
            try {
                JSONObject r = Api.events(prefs, acct);
                main.post(() -> show(r));
            } catch (Exception e) {
                main.post(() -> status.setText(e.getMessage()));
            }
        });
    }

    private void show(JSONObject r) {
        JSONObject sum = r.optJSONObject("summary");
        long now = r.optLong("now", System.currentTimeMillis() / 1000);
        // the account list (first time)
        if (accounts.size() == 1 && sum != null && sum.length() > 0) {
            List<String> names = new ArrayList<>();
            names.add("All accounts");
            for (Iterator<String> it = sum.keys(); it.hasNext(); ) { String k = it.next(); accounts.add(k); names.add(k); }
            filling = true;
            setSpinner(names.toArray(new String[0]));
            filling = false;
        }
        String acct = selected();

        summary.removeAllViews();
        if (sum != null)
            for (Iterator<String> it = sum.keys(); it.hasNext(); ) {
                String name = it.next();
                if (!acct.isEmpty() && !acct.equalsIgnoreCase(name)) continue;
                JSONObject s = sum.optJSONObject(name);
                LinearLayout card = Ui.card(this);
                TextView head = Ui.text(this, name, 16, true);
                card.addView(head);
                long since = s.optLong("inGameSince", 0);
                TextView state = Ui.text(this, since > 0
                        ? "In game " + Fmt.duration((now - since) * 1000) + (s.isNull("char") ? "" : " as " + s.optString("char"))
                        : "Not in game", 14, false);
                state.setTextColor(since > 0 ? Ui.GREEN : Ui.GREY);
                card.addView(state);
                long last = s.optLong("lastLogin", 0);   // (the last time it got into the game, however long ago)
                TextView login = Ui.text(this, "Last login: " + (last > 0
                        ? java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.MEDIUM, java.text.DateFormat.SHORT).format(new java.util.Date(last * 1000))
                          + (s.isNull("lastLoginChar") || s.optString("lastLoginChar").isEmpty() ? "" : " as " + s.optString("lastLoginChar"))
                        : "none recorded"), 13, false);
                card.addView(login);
                List<String> bits = new ArrayList<>();
                bits.add(Fmt.duration(s.optLong("uptime") * 1000) + " in game");
                bits.add("longest run " + Fmt.duration(s.optLong("longest") * 1000));
                add(bits, s.optInt("restarts"), "restart", "restarts");
                add(bits, s.optInt("crashes"), "crash", "crashes");
                add(bits, s.optInt("unresponsive"), "freeze", "freezes");
                add(bits, s.optInt("disconnects"), "disconnect", "disconnects");
                add(bits, s.optInt("stuck"), "stuck login", "stuck logins");
                TextView day = Ui.text(this, "Last 24 h: " + android.text.TextUtils.join(", ", bits), 13, false);
                day.setTextColor(Ui.muted(this));
                card.addView(day);
                summary.addView(card);
            }

        list.removeAllViews();
        JSONArray evs = r.optJSONArray("events");
        int n = evs == null ? 0 : evs.length();
        status.setText(n == 0 ? "Nothing recorded yet." : n + " events, newest first");
        SimpleDateFormat today = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        SimpleDateFormat older = new SimpleDateFormat("MMM d HH:mm", Locale.getDefault());
        String todayKey = new SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(new Date());
        SimpleDateFormat dayKey = new SimpleDateFormat("yyyyMMdd", Locale.getDefault());
        for (int i = 0; i < n; i++) {
            JSONObject e = evs.optJSONObject(i);
            Date d = new Date(e.optLong("t") * 1000);
            String when = todayKey.equals(dayKey.format(d)) ? today.format(d) : older.format(d);
            String kind = e.optString("kind");

            LinearLayout row = Ui.vbox(this);
            row.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
            LinearLayout top = Ui.hbox(this);
            TextView t = Ui.text(this, when, 13, false);
            t.setTextColor(Ui.muted(this));
            t.setMinWidth(Ui.dp(this, 92));
            top.addView(t);
            TextView k = Ui.text(this, e.optString("kindName", kind), 14, true);
            k.setTextColor(colour(kind));
            top.addView(k, Ui.weight(1));
            if (!e.isNull("ran") && e.has("ran")) {
                TextView ran = Ui.text(this, "ran " + Fmt.duration(e.optLong("ran") * 1000), 13, false);
                ran.setTextColor(Ui.muted(this));
                top.addView(ran);
            }
            row.addView(top);
            String who = acct.isEmpty() ? e.optString("account") + (e.isNull("char") || !e.has("char") ? "" : " (" + e.optString("char") + ")") + " - " : "";
            TextView text = Ui.text(this, who + e.optString("text"), 13, false);
            text.setPadding(Ui.dp(this, 92), 0, 0, 0);
            row.addView(text);
            View line = new View(this);
            line.setBackgroundColor(Ui.lineColor(this));
            row.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
            list.addView(row);
        }
    }

    private static void add(List<String> bits, int n, String one, String many) {
        if (n > 0) bits.add(n + " " + (n == 1 ? one : many));
    }

    private int colour(String kind) {
        switch (kind) {
            case "in_game": case "server_up": return Ui.GREEN;
            case "launch": case "restart": return CYAN;
            case "unresponsive": case "disconnected": case "killed": case "server_down": return ORANGE;
            case "crashed": case "stuck": case "launch_failed": case "gave_up": return Ui.RED;
            case "reset": return PURPLE;
            default: return Ui.GREY;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) { finish(); return true; }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        io.shutdownNow();
    }
}
