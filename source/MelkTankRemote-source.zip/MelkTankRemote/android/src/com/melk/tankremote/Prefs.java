package com.melk.tankremote;

import android.content.Context;
import android.content.SharedPreferences;

/** The app's settings: where the PC is, the app key, and the alert options. */
final class Prefs {
    private final SharedPreferences sp;

    Prefs(Context c) { sp = c.getSharedPreferences("melktank", Context.MODE_PRIVATE); }

    String host() { return sp.getString("host", "").trim(); }
    int port() { return sp.getInt("port", 8765); }
    String key() { return sp.getString("key", "").trim(); }
    boolean alerts() { return sp.getBoolean("alerts", true); }
    int pollSeconds() { return Math.max(30, sp.getInt("poll", 60)); }
    int idleMinutes() { return Math.max(1, sp.getInt("idle", 5)); }
    boolean configured() { return host().length() > 0 && key().length() > 0; }

    void save(String host, int port, String key, boolean alerts, int poll, int idle) {
        sp.edit().putString("host", host.trim()).putInt("port", port).putString("key", key.trim())
                .putBoolean("alerts", alerts).putInt("poll", poll).putInt("idle", idle).apply();
    }

    /** One kind of notification on or off: "pc", "offline", "death", "idle", "stuck", "enl". All on unless switched off. */
    boolean alertOn(String kind) { return sp.getBoolean("alert_" + kind, !kind.equals("tell")); }   // all on to start with, but tells
    void alertOn(String kind, boolean on) { sp.edit().putBoolean("alert_" + kind, on).apply(); }

    /** The small always-on "watching" notification (the alerts work either way). */
    boolean showWatching() { return sp.getBoolean("showWatching", true); }
    void showWatching(boolean on) { sp.edit().putBoolean("showWatching", on).apply(); }

    /** The character an account's bank transfer buttons send to (last picked). */
    String transferTo(String account) { return sp.getString("xferTo_" + account.toLowerCase(), ""); }
    void transferTo(String account, String name) { sp.edit().putString("xferTo_" + account.toLowerCase(), name).apply(); }

    /** Chat page filters. */
    boolean chatHide(String kind) { return sp.getBoolean("chatHide_" + kind, false); }
    void chatHide(String kind, boolean on) { sp.edit().putBoolean("chatHide_" + kind, on).apply(); }

    /** The Live switch: on only while the app is running (not saved), so it never stays on by itself. */
    static boolean live;

    /** What the alert checker remembered from last time (JSON text). */
    String alertState() { return sp.getString("alertState", "{}"); }
    void alertState(String json) { sp.edit().putString("alertState", json).apply(); }
}
