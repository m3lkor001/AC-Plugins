package com.melk.tankremote;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.DateFormat;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The PC's screen, to see what a stuck client is showing. Pinch to zoom, drag to look around, double-tap to zoom
 * in or back out, tap once to click there on the PC (asks first: left, right, drag - then tap where to drop - or click and type). Refresh takes a new one.
 */
public class ScreenshotActivity extends Activity {
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private Prefs prefs;
    private TextView status;
    private ZoomImageView image;
    private float[] dragFrom;   // a drag begun: where it's picked up (null: none)

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        if (getActionBar() != null) getActionBar().setDisplayHomeAsUpEnabled(true);   // back arrow in the title
        LinearLayout root = Ui.vbox(this);
        int p = Ui.dp(this, 10);
        root.setPadding(p, p, p, p);

        LinearLayout bar = Ui.hbox(this);
        Button back = new Button(this);
        back.setText("‹ Back");
        back.setOnClickListener(v -> finish());
        bar.addView(back);
        status = Ui.text(this, "", 14, false);
        status.setPadding(Ui.dp(this, 10), 0, Ui.dp(this, 10), 0);
        bar.addView(status, Ui.weight(1));
        Button refresh = new Button(this);
        refresh.setText("Refresh");
        refresh.setOnClickListener(v -> load());
        bar.addView(refresh);
        root.addView(bar);

        image = new ZoomImageView(this);
        // tap: click there on the PC (after a yes) - e.g. an Allow / Deny button waiting on the screen
        image.onTap = (px, py) -> {
            // (a drag begun: this tap is where it's let go)
            if (dragFrom != null) { float[] from = dragFrom; dragFrom = null; drag(from[0], from[1], px, py); return; }
            final String[] ways = { "Left click", "Double click", "Right click", "Drag (then tap where to drop it)", "Click and type" };
            new android.app.AlertDialog.Builder(this)
                .setTitle("Click here on the PC? (" + (int) px + ", " + (int) py + ")")
                .setItems(ways, (d, w) -> {
                    if (w == 0) click(px, py, false);
                    else if (w == 1) doubleClick(px, py);
                    else if (w == 2) click(px, py, true);
                    else if (w == 3) { dragFrom = new float[] { px, py }; status.setText("Drag from " + (int) px + ", " + (int) py + ": tap where to drop it (Refresh cancels)"); }
                    else askText(px, py);
                })
                .setNegativeButton("Cancel", null).show();
        };
        root.addView(image, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(PullRefresh.wrap(this, root, this::pullRefresh));
        load();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) { finish(); return true; }
        return super.onOptionsItemSelected(item);
    }

    /** Pull down: load the page again. */
    private void pullRefresh(PullRefresh pr) {
        load();
        main.postDelayed(pr::done, 1500);
    }

    private void click(float px, float py, boolean right) {
        status.setText("Clicking...");
        io.execute(() -> {
            String msg;
            try { msg = Api.clickScreen(prefs, px, py, right).optString("message", "Clicked."); }
            catch (Exception e) { msg = e.getMessage(); }
            String m = msg;
            main.post(() -> { status.setText(m); main.postDelayed(this::load, 1200); });
        });
    }

    /** Click and type: what to type there, then a left click at the spot and the text typed on the PC. */
    private void askText(float px, float py) {
        LinearLayout box = Ui.vbox(this);
        int pad = Ui.dp(this, 16);
        box.setPadding(pad, pad / 2, pad, 0);
        android.widget.EditText input = new android.widget.EditText(this);
        input.setHint("What to type");
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        box.addView(input);
        android.widget.CheckBox enter = new android.widget.CheckBox(this);
        enter.setText("Press Enter after");
        box.addView(enter);
        android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(this)
                .setTitle("Click and type")
                .setView(box)
                .setPositiveButton("Done", (d, w) -> typeAt(px, py, input.getText().toString(), enter.isChecked()))
                .setNegativeButton("Cancel", null).create();
        if (dlg.getWindow() != null) dlg.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        dlg.show();
        input.requestFocus();
    }

    private void typeAt(float px, float py, String text, boolean enter) {
        status.setText("Clicking and typing...");
        io.execute(() -> {
            String msg;
            try { msg = Api.clickAndType(prefs, px, py, text, enter).optString("message", "Typed."); }
            catch (Exception e) { msg = e.getMessage(); }
            String m = msg;
            main.post(() -> { status.setText(m); main.postDelayed(this::load, 1200); });
        });
    }

    private void doubleClick(float px, float py) {
        status.setText("Double-clicking...");
        io.execute(() -> {
            String msg;
            try { msg = Api.doubleClickScreen(prefs, px, py).optString("message", "Double-clicked."); }
            catch (Exception e) { msg = e.getMessage(); }
            String m = msg;
            main.post(() -> { status.setText(m); main.postDelayed(this::load, 1200); });
        });
    }

    private void drag(float px, float py, float toX, float toY) {
        status.setText("Dragging...");
        io.execute(() -> {
            String msg;
            try { msg = Api.dragScreen(prefs, px, py, toX, toY).optString("message", "Dragged."); }
            catch (Exception e) { msg = e.getMessage(); }
            String m = msg;
            main.post(() -> { status.setText(m); main.postDelayed(this::load, 1200); });
        });
    }

    private void load() {
        dragFrom = null;
        status.setText("Taking a screenshot of the PC...");
        io.execute(() -> {
            try {
                byte[] data = Api.screenshot(prefs);
                Bitmap bmp = BitmapFactory.decodeByteArray(data, 0, data.length);
                if (bmp == null) throw new Exception("The PC sent something that isn't a picture.");
                main.post(() -> {
                    image.setPicture(bmp);
                    status.setText(DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date()) + " · pinch to zoom, tap to click");
                });
            } catch (Exception e) {
                main.post(() -> status.setText(e.getMessage()));
            }
        });
    }
}
