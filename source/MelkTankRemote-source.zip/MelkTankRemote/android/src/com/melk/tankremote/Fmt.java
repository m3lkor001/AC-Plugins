package com.melk.tankremote;

import java.text.NumberFormat;
import java.time.Instant;

/** Small text helpers. */
final class Fmt {
    private Fmt() {}

    /** ISO time from the PC (MelkTank writes 7 decimal places, Python none) -> epoch ms, or -1. */
    static long time(String iso) {
        if (iso == null || iso.trim().isEmpty()) return -1;
        try { return Instant.parse(iso.trim()).toEpochMilli(); } catch (Exception e) { return -1; }
    }

    static String ago(String iso) {
        long t = time(iso);
        if (t < 0) return "-";
        return duration(System.currentTimeMillis() - t) + " ago";
    }

    static String since(String iso) {
        long t = time(iso);
        if (t < 0) return "-";
        return duration(System.currentTimeMillis() - t);
    }

    static String duration(long ms) {
        long s = Math.max(0, ms / 1000);
        if (s < 60) return s + "s";
        if (s < 3600) return (s / 60) + "m";
        if (s < 86400) return (s / 3600) + "h " + ((s % 3600) / 60) + "m";
        return (s / 86400) + "d " + ((s % 86400) / 3600) + "h";
    }

    /** 1,234 / 12.3K / 4.56M / 1.23B / 1.23T / 1.23Q */
    static String big(long n) {
        double a = Math.abs((double) n);
        if (a >= 1e15) return String.format(java.util.Locale.US, "%.2fQ", n / 1e15);
        if (a >= 1e12) return String.format(java.util.Locale.US, "%.2fT", n / 1e12);
        if (a >= 1e9) return String.format(java.util.Locale.US, "%.2fB", n / 1e9);
        if (a >= 1e6) return String.format(java.util.Locale.US, "%.2fM", n / 1e6);
        if (a >= 1e4) return String.format(java.util.Locale.US, "%.1fK", n / 1e3);
        return NumberFormat.getIntegerInstance().format(n);
    }

    static String num(long n) {
        if (n < 0) return "-";
        return NumberFormat.getIntegerInstance().format(n);
    }
}
