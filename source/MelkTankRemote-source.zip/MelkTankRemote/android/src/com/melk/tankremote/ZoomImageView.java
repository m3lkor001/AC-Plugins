package com.melk.tankremote;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.ImageView;

/** A picture you can pinch to zoom (up to 30x), drag around when zoomed, and double-tap to zoom in / back out. */
class ZoomImageView extends ImageView {
    private final Matrix m = new Matrix();
    private final ScaleGestureDetector scaler;
    private final GestureDetector gestures;
    private float fit = 1f;          // the scale that fits the whole picture in the view
    private Bitmap bmp;
    /** A single tap on the picture: where, in the picture's own pixels (null = no tap handling). */
    interface OnPictureTap { void tap(float px, float py); }
    OnPictureTap onTap;

    ZoomImageView(Context c) {
        super(c);
        setScaleType(ScaleType.MATRIX);
        scaler = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                float now = scale();
                float f = d.getScaleFactor();
                float target = Math.max(fit, Math.min(fit * 30f, now * f));
                f = target / now;
                m.postScale(f, f, d.getFocusX(), d.getFocusY());
                keepInside();
                return true;
            }
        });
        gestures = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                m.postTranslate(-dx, -dy);
                keepInside();
                return true;
            }
            @Override public boolean onSingleTapConfirmed(MotionEvent e) {
                if (onTap == null || bmp == null) return false;
                Matrix inv = new Matrix();
                if (!m.invert(inv)) return false;
                float[] pt = { e.getX(), e.getY() };
                inv.mapPoints(pt);
                if (pt[0] < 0 || pt[1] < 0 || pt[0] > bmp.getWidth() || pt[1] > bmp.getHeight()) return false;
                onTap.tap(pt[0], pt[1]);
                return true;
            }
            @Override public boolean onDoubleTap(MotionEvent e) {
                if (scale() > fit * 1.05f) fitToView();
                else { m.postScale(4f, 4f, e.getX(), e.getY()); keepInside(); }
                return true;
            }
        });
    }

    void setPicture(Bitmap b) {
        boolean first = bmp == null || bmp.getWidth() != b.getWidth() || bmp.getHeight() != b.getHeight();
        bmp = b;
        setImageBitmap(b);
        if (first) post(this::fitToView); else setImageMatrix(m);
    }

    /** Zoomed in, a drag pans the picture: pull to refresh only works at the fitted size. */
    @Override public boolean canScrollVertically(int direction) { return scale() > fit * 1.05f || super.canScrollVertically(direction); }

    private float scale() { float[] v = new float[9]; m.getValues(v); return v[Matrix.MSCALE_X]; }

    private void fitToView() {
        if (bmp == null || getWidth() == 0) return;
        fit = Math.min((float) getWidth() / bmp.getWidth(), (float) getHeight() / bmp.getHeight());
        m.reset();
        m.postScale(fit, fit);
        m.postTranslate((getWidth() - bmp.getWidth() * fit) / 2f, (getHeight() - bmp.getHeight() * fit) / 2f);
        setImageMatrix(m);
    }

    /** No dragging the picture off the screen: centred when smaller than the view, edges kept at the edges when bigger. */
    private void keepInside() {
        if (bmp == null) return;
        RectF r = new RectF(0, 0, bmp.getWidth(), bmp.getHeight());
        m.mapRect(r);
        float dx = 0, dy = 0, w = getWidth(), h = getHeight();
        if (r.width() <= w) dx = (w - r.width()) / 2f - r.left;
        else if (r.left > 0) dx = -r.left;
        else if (r.right < w) dx = w - r.right;
        if (r.height() <= h) dy = (h - r.height()) / 2f - r.top;
        else if (r.top > 0) dy = -r.top;
        else if (r.bottom < h) dy = h - r.bottom;
        m.postTranslate(dx, dy);
        setImageMatrix(m);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        // zoomed in on something: it stays (the line above the picture growing or shrinking by a row as its words
        // change resized this view, and every refresh went back to the whole screen)
        if (bmp != null && ow > 0 && oh > 0 && w > 0 && h > 0 && scale() > fit * 1.05f) {
            fit = Math.min((float) w / bmp.getWidth(), (float) h / bmp.getHeight());
            keepInside();
            return;
        }
        fitToView();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        scaler.onTouchEvent(e);
        gestures.onTouchEvent(e);
        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
        return true;
    }
}
