package com.melk.tankremote;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * One character's current session (swipe a card to the left): the Session tab's numbers, kills grouped by
 * species, and every item the looter kept with its full ID line. Long-press an item to copy its ID.
 */
public class SessionActivity extends Activity {
    private static final String[] CATS = {"All items", "Armor", "Clothing", "Jewelry", "Weapons", "Misc"};

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private Prefs prefs;
    private String account;
    private TextView status;
    private LinearLayout body;
    private JSONObject data;
    private JSONObject acct;                       // this account's entry in the status (the main page's card)
    private String routePick, spotPick, metaPick;            // what you picked in the drop-downs (kept across refreshes)
    private static final String[] FEATURES = {"master", "combat", "nav", "loot", "summon", "buff", "meta"};
    private static final String[] LABELS = {"MelkTank (all)", "Combat", "Nav", "Looting", "Summons", "Buffs", "Meta"};
    private int cat;
    private static final String[] KILL_SORTS = {"Most kills", "Fewest kills", "Species A-Z"};
    private boolean killsOpen = true;
    private int killSort;
    private final java.util.Set<String> openGroups = new java.util.HashSet<>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        account = getIntent().getStringExtra("account");
        String title = getIntent().getStringExtra("title");
        setTitle(title == null || title.isEmpty() ? account : title);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = Ui.vbox(this);
        int p = Ui.dp(this, 14);
        root.setPadding(p, p, p, p);
        scroll.addView(root);

        if (getActionBar() != null) getActionBar().setDisplayHomeAsUpEnabled(true);   // the back arrow at the top

        LinearLayout bar = Ui.hbox(this);
        Button back = new Button(this);
        back.setText("\u2039 Back");
        back.setOnClickListener(v -> finish());
        bar.addView(back);
        status = Ui.text(this, "Loading...", 14, false);
        status.setPadding(Ui.dp(this, 8), 0, Ui.dp(this, 8), 0);
        status.setTextColor(Ui.muted(this));
        bar.addView(status, Ui.weight(1));
        Button refresh = new Button(this);
        refresh.setText("Refresh");
        refresh.setOnClickListener(v -> load());
        bar.addView(refresh);
        root.addView(bar);

        body = Ui.vbox(this);
        root.addView(body);
        setContentView(PullRefresh.wrap(this, scroll, this::pullRefresh));
        load();
    }

    // swipe right anywhere on the page: back to the main page (the way you came in, a swipe left on the card)
    private float swipeX, swipeY;
    private boolean swipeOk;

    @Override
    public boolean dispatchTouchEvent(android.view.MotionEvent e) {
        switch (e.getActionMasked()) {
            case android.view.MotionEvent.ACTION_DOWN:
                swipeX = e.getRawX(); swipeY = e.getRawY(); swipeOk = true;
                break;
            case android.view.MotionEvent.ACTION_POINTER_DOWN:
                swipeOk = false;   // two fingers: not a swipe
                break;
            case android.view.MotionEvent.ACTION_UP: {
                float dx = e.getRawX() - swipeX, dy = e.getRawY() - swipeY;
                if (swipeOk && dx > Ui.dp(this, 110) && Math.abs(dx) > Math.abs(dy) * 2) {
                    finish();
                    overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
                    return true;
                }
                if (swipeOk && dx < -Ui.dp(this, 110) && Math.abs(dx) > Math.abs(dy) * 2) {
                    // swipe left: on to the inventory page
                    android.content.Intent i = new android.content.Intent(this, InventoryActivity.class);
                    i.putExtra("account", account);
                    i.putExtra("title", getIntent().getStringExtra("title"));
                    if (getIntent().getStringArrayListExtra("others") != null) i.putStringArrayListExtra("others", getIntent().getStringArrayListExtra("others"));
                    startActivity(i);
                    overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.fade_out);
                    return true;
                }
                break;
            }
        }
        return super.dispatchTouchEvent(e);
    }

    @Override
    public boolean onCreateOptionsMenu(android.view.Menu m) {
        AccountMenu.build(m, "session");   // the character card's ⋮ menu, in the title bar
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(android.view.Menu m) {
        AccountMenu.prepare(m, account);
        return super.onPrepareOptionsMenu(m);
    }

    @Override
    public boolean onOptionsItemSelected(android.view.MenuItem item) {
        if (AccountMenu.handle(this, item, account, getTitle().toString(), this::load)) return true;
        if (item.getItemId() == android.R.id.home) { finish(); return true; }
        return super.onOptionsItemSelected(item);
    }

    // Live switch on: refresh every 3 s while this page is on screen (MelkTank then writes the session file every 2 s)
    private boolean shown;

    @Override
    protected void onResume() { super.onResume(); shown = true; if (Prefs.live) main.postDelayed(this::liveTick, 3000); }

    @Override
    protected void onPause() { shown = false; main.removeCallbacksAndMessages(null); super.onPause(); }

    private void liveTick() {
        if (!shown || !Prefs.live) return;
        load();
        main.postDelayed(this::liveTick, 3000);
    }

    /** Pull down: MelkTank writes its status right away, then the page loads again. */
    private void pullRefresh(PullRefresh pr) {
        io.execute(() -> {
            try { if (account != null) Api.refresh(prefs, account); } catch (Exception ignored) { }
            main.postDelayed(() -> { load(); main.postDelayed(pr::done, 800); }, 2500);
        });
    }

    /** Leaves a monster out of (or back in) the packs / tuning numbers, then reloads. */
    private void tuneOut(String name, boolean on) {
        io.execute(() -> {
            String msg;
            try { Api.sendChat(prefs, account, "/mtank tuneout " + name + (on ? " on" : " off"), false); msg = name + (on ? " left out of tuning" : " counts in tuning again"); }
            catch (Exception e) { msg = e.getMessage(); }
            String m2 = msg;
            main.post(() -> { Toast.makeText(this, m2, Toast.LENGTH_SHORT).show(); main.postDelayed(this::load, 2500); });
        });
    }

    /** "/bounty list" then "/bounty" to the character (MelkTank reads both answers), then reloads. */
    private void updateBounties() {
        io.execute(() -> {
            String msg;
            try {
                Api.sendChat(prefs, account, "/bounty list", false);
                Thread.sleep(1500);
                Api.sendChat(prefs, account, "/bounty", false);
                msg = "Asked for the bounty list";
            } catch (Exception e) { msg = e.getMessage(); }
            String m2 = msg;
            main.post(() -> { Toast.makeText(this, m2, Toast.LENGTH_SHORT).show(); main.postDelayed(this::load, 4000); });
        });
    }

    /** /mtank enl ... to the character, then reloads. */
    private void enlCommand(String what, String said) {
        io.execute(() -> {
            String msg;
            try { Api.sendChat(prefs, account, "/mtank enl " + what, false); msg = said; }
            catch (Exception e) { msg = e.getMessage(); }
            String m2 = msg;
            main.post(() -> { Toast.makeText(this, m2, Toast.LENGTH_SHORT).show(); main.postDelayed(this::load, 2500); });
        });
    }

    private void load() {
        if (data == null) status.setText("Loading...");
        io.execute(() -> {
            try {
                if (Prefs.live) { try { Api.live(prefs, true, true); } catch (Exception ignored) { } }
                JSONObject j = Api.session(prefs, account);
                JSONObject a = null;
                try {
                    JSONArray accs = Api.status(prefs).optJSONArray("accounts");
                    for (int i = 0; accs != null && i < accs.length(); i++) {
                        JSONObject o = accs.optJSONObject(i);
                        if (o != null && o.optString("account").equalsIgnoreCase(account)) a = o;
                    }
                } catch (Exception ignored) { }
                JSONObject a2 = a;
                main.post(() -> { data = j; if (a2 != null) acct = a2; render(); });
            } catch (Exception e) {
                main.post(() -> status.setText(e.getMessage()));
            }
        });
    }

    // ── Controls: the main page's switches, route / spot pickers and readings for this account ──
    private LinearLayout controlsCard() {
        LinearLayout c = Ui.card(this);
        TextView h = heading("Controls");
        c.addView(h);
        JSONObject a = acct;
        boolean online = a != null && "online".equals(a.optString("state"));
        if (!online) {
            TextView t = Ui.text(this, a == null ? "Loading..." : "Not in game.", 14, false);
            t.setTextColor(Ui.muted(this));
            c.addView(t);
            fold(c, "controls", h);
            return c;
        }
        // what it's doing, and nav
        String es = a.optString("engineStatus", "");
        // coloured like the main page: the status by what it's doing, nav in blue, the meta in purple
        CharSequence act = MainActivity.colourAction(es);
        if (a.optBoolean("paused")) act = android.text.TextUtils.concat("Paused by " + a.optString("pausedBy") + (es.isEmpty() ? "" : " \u00b7 "), act);
        if (act.length() > 0) { TextView e = Ui.text(this, "", 15, false); e.setText(act); e.setPadding(0, Ui.dp(this, 2), 0, 0); c.addView(e); }
        String ns = a.optString("navStatus", "");
        if (!ns.isEmpty()) { TextView n = Ui.text(this, "", 13, false); n.setText(MainActivity.twoTone("Nav:", " " + ns, MainActivity.NAV, MainActivity.NAV_TEXT)); c.addView(n); }
        if (a.optBoolean("meta", false) && !a.optString("metaName").isEmpty()) {
            TextView mt = Ui.text(this, "", 13, false);
            mt.setText(MainActivity.metaLine(a));
            c.addView(mt);
        }

        // the switches, two to a row, with the counts (monsters in range, corpses to loot)
        boolean master = a.optBoolean("master", true);
        LinearLayout row = null;
        for (int i = 0; i < FEATURES.length; i++) {
            if (i % 2 == 0) { row = Ui.hbox(this); c.addView(row); }
            android.widget.Switch sw = new android.widget.Switch(this);
            String f = FEATURES[i];
            String countKey = f.equals("combat") ? "mobs" : f.equals("loot") ? "corpses" : null;
            sw.setText(LABELS[i] + (countKey != null && a.has(countKey) ? " (" + a.optInt(countKey) + ")" : ""));
            sw.setTextSize(15);
            sw.setPadding(0, Ui.dp(this, 6), Ui.dp(this, 16), Ui.dp(this, 6));
            sw.setChecked(a.optBoolean(f, false));
            if (i > 0 && !master) sw.setAlpha(0.5f);
            sw.setOnCheckedChangeListener((b, on) -> {
                b.setEnabled(false);
                io.execute(() -> {
                    String m;
                    try { Api.set(prefs, account, f, on); m = labelOf(f) + (on ? " on" : " off") + " - sent"; } catch (Exception ex) { m = ex.getMessage(); }
                    String m2 = m;
                    main.post(() -> Toast.makeText(this, m2, Toast.LENGTH_SHORT).show());
                    main.postDelayed(this::load, 3500);
                });
            });
            row.addView(sw, Ui.weight(1));
        }

        // route and spot
        int navMode = a.optInt("navMode", 0);
        boolean navOn = a.optBoolean("nav", false) && master;
        c.addView(pickerRow("Route ", a.optJSONArray("navRoutes"), navMode == 1 ? a.optString("navRoute", "") : "", navMode == 1 && navOn, 0));
        c.addView(pickerRow("Spot ", a.optJSONArray("navSpots"), navMode == 0 ? a.optString("navSpot", "") : "", navMode == 0 && navOn, 1));
        c.addView(pickerRow("Meta ", a.optJSONArray("metas"), a.optString("metaName", ""), a.optBoolean("meta", false), 2));

        fold(c, "controls", h);
        return c;
    }

    /** The main page's readings for this account (location, logged in, memory, rates, bank...), or null. */
    private TextView readings() {
        JSONObject a = acct;
        if (a == null || !"online".equals(a.optString("state"))) return null;
        StringBuilder sb = new StringBuilder();
        String loc = a.optString("location", "");
        sb.append("Location: ").append(loc.isEmpty() ? "-" : loc).append('\n');
        sb.append("Logged in: ").append(Fmt.since(a.optString("loginTime"))).append('\n');
        long mem = a.optLong("memInUse", -1), relogMB = a.optLong("relogMB", 0);
        if (mem > 0) {
            sb.append("Memory: ").append(String.format(java.util.Locale.US, "%.2f GB", mem / 1073741824.0));
            if (a.optBoolean("relogPending")) sb.append(" - relogging when calm");
            else if (relogMB > 0) sb.append(String.format(java.util.Locale.US, " (relogs at %.2f)", relogMB / 1024.0));
            sb.append('\n');
        }
        if (a.has("lumPerHour")) sb.append("Lum / hour (effective): ").append(Fmt.big(a.optLong("lumPerHour"))).append('\n');
        String la = a.optString("lastAttack", "");
        sb.append("Last attack: ").append(la.isEmpty() ? "none yet" : Fmt.ago(la)).append('\n');
        long lumBank = a.optLong("lumBank", -1);
        sb.append("Luminance: ").append(lumBank >= 0 ? Fmt.num(lumBank) + " (bank)" : "not seen yet").append('\n');
        long coins = a.optLong("coins", -1), coinsBank = a.optLong("coinsBank", -1);
        sb.append("Enlightened Coins: ").append(Fmt.num(Math.max(0, coins))).append(" in pack");
        if (coinsBank >= 0) sb.append(" · ").append(Fmt.num(coinsBank)).append(" in bank");
        int deaths = a.optInt("deaths", 0);
        if (deaths > 0) sb.append("\nDeaths this session: ").append(deaths).append(" (last ").append(Fmt.ago(a.optString("lastDeath"))).append(')');
        TextView info = Ui.text(this, sb.toString(), 14, false);
        info.setPadding(0, Ui.dp(this, 6), 0, 0);
        info.setLineSpacing(0, 1.15f);
        return info;
    }

    /** A route / spot drop-down with Use; the one in use is picked (unless you picked another). */
    private LinearLayout pickerRow(String label, JSONArray arr, String active, boolean running, int kind) {   // kind: 0 route, 1 spot, 2 meta
        LinearLayout r = Ui.hbox(this);
        r.setPadding(0, Ui.dp(this, 4), 0, 0);
        List<String> names = new ArrayList<>();
        for (int i = 0; arr != null && i < arr.length(); i++) names.add(arr.optString(i));
        if (names.isEmpty()) { r.setVisibility(View.GONE); return r; }
        r.addView(Ui.text(this, label, 15, false));
        Spinner sp = new Spinner(this);
        final int activeIdx = names.indexOf(active);
        // like the main page: the one in use is green and bold while Nav is running it
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, names) {
            private android.content.res.ColorStateList normal;
            private View paint(int pos, View v) {
                if (v instanceof TextView) {
                    TextView tv = (TextView) v;
                    if (normal == null) normal = tv.getTextColors();
                    if (pos == activeIdx && running) { tv.setTextColor(Ui.GREEN); tv.setTypeface(Typeface.DEFAULT_BOLD); }
                    else { tv.setTextColor(normal); tv.setTypeface(Typeface.DEFAULT); }
                }
                return v;
            }
            @Override public View getView(int pos, View cv, android.view.ViewGroup parent) { return paint(pos, super.getView(pos, cv, parent)); }
            @Override public View getDropDownView(int pos, View cv, android.view.ViewGroup parent) { return paint(pos, super.getDropDownView(pos, cv, parent)); }
        };
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(ad);
        String want = kind == 0 ? routePick : kind == 1 ? spotPick : metaPick;
        int idx = names.indexOf(want != null ? want : active);
        if (idx < 0) idx = names.indexOf(active);
        if (idx >= 0) sp.setSelection(idx);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            boolean first = true;
            public void onItemSelected(AdapterView<?> p, View v, int i, long id) { if (first) { first = false; return; } if (kind == 0) routePick = names.get(i); else if (kind == 1) spotPick = names.get(i); else metaPick = names.get(i); }
            public void onNothingSelected(AdapterView<?> p) { }
        });
        r.addView(sp, Ui.weight(1));
        Button use = new Button(this);
        use.setText("Use");
        use.setOnClickListener(v -> {
            Object sel = sp.getSelectedItem();
            if (sel == null) return;
            String name = sel.toString();
            if (kind == 0) routePick = null; else if (kind == 1) spotPick = null; else metaPick = null;
            io.execute(() -> {
                String m;
                try {
                    if (kind == 0) Api.navRoute(prefs, account, name); else if (kind == 1) Api.navSpot(prefs, account, name); else Api.metaLoad(prefs, account, name);
                    m = kind == 2 ? "Meta " + name + " - sent." + (acct != null && acct.optBoolean("meta") ? "" : " Turn Meta on to run it.")
                                  : (kind == 0 ? "Route " : "Spot ") + name + " - sent." + (acct != null && acct.optBoolean("nav") ? "" : " Turn Nav on to use it.");
                } catch (Exception ex) { m = ex.getMessage(); }
                String m2 = m;
                main.post(() -> Toast.makeText(this, m2, Toast.LENGTH_SHORT).show());
                main.postDelayed(this::load, 3500);
            });
        });
        r.addView(use);
        return r;
    }

    private static String labelOf(String f) {
        for (int i = 0; i < FEATURES.length; i++) if (FEATURES[i].equals(f)) return LABELS[i];
        return f;
    }

    // ── drawing ──

    private void render() {
        body.removeAllViews();
        JSONObject d = data;
        if (d == null) return;
        String ch = d.optString("character", "");
        if (!ch.isEmpty()) setTitle(ch);
        status.setText("Updated " + Fmt.ago(d.optString("updated")) + " · session started " + clock(d.optString("started")));

        // numbers (the Session tab's Main page)
        LinearLayout card = Ui.card(this);
        TextView sh = heading("Session");
        card.addView(sh);
        // health / stamina / mana, like the game's bars
        VitalBars vb = new VitalBars(this);
        LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        vlp.bottomMargin = Ui.dp(this, 6);
        card.addView(vb, vlp);
        vb.set(acct != null && "online".equals(acct.optString("state")) ? acct : null);
        TextView readingsView = readings();
        if (readingsView != null) { readingsView.setPadding(0, 0, 0, Ui.dp(this, 6)); card.addView(readingsView); }
        long secs = d.optLong("playedSecs", 0);
        int corpses = d.optInt("corpses"), kept = d.optInt("corpsesKept"), items = d.optInt("lootItems");
        row(card, "Time played", Fmt.duration(secs * 1000));
        row(card, "Kills", Fmt.num(d.optLong("kills")));
        row(card, "Kills / hour (session)", Fmt.num(d.optLong("killsPerHour")));
        if (d.has("killsPerHourTuned")) row(card, "Kills / hour (tuned)", Fmt.num(d.optLong("killsPerHourTuned")));
        long kr = d.optLong("killsPerHourRecent", -1);
        row(card, "Kills / hour (last 60 min)", kr >= 0 ? Fmt.num(kr) : "after 1 minute");
        row(card, "Deaths", Fmt.num(d.optLong("deaths")));
        if (d.has("packs")) {
            int packs = d.optInt("packs");
            row(card, "Packs (3+ kills)", packs == 0 ? "none yet" : Fmt.num(packs) + "  ·  " + d.optString("packKills") + " kills each");
            if (packs > 0) {
                row(card, "    pack time avg / last", secsText(d.optDouble("packAvg")) + " / " + secsText(d.optDouble("packLast")));
                row(card, "    fastest / slowest", secsText(d.optDouble("packFastest")) + " / " + secsText(d.optDouble("packSlowest")));
            }
        }
        if (d.has("lumEarned")) {
            row(card, "Luminance earned", Fmt.big(d.optLong("lumEarned")));
            row(card, "    per hour (session / 60 min)", Fmt.big(d.optLong("lumPerHour")) + " / " + Fmt.big(d.optLong("lumPerHourRecent")));
            row(card, "XP earned", Fmt.big(d.optLong("xpEarned")));
            row(card, "    per hour (session / 60 min)", Fmt.big(d.optLong("xpPerHour")) + " / " + Fmt.big(d.optLong("xpPerHourRecent")));
        }
        row(card, "Corpses looted", Fmt.num(corpses) + (corpses > 0 ? "  (" + Math.round(100.0 * kept / corpses) + "% had something)" : ""));
        row(card, "Loot kept", Fmt.num(items) + (corpses > 0 ? "  (" + String.format(java.util.Locale.US, "%.2f", (double) items / corpses) + " per corpse)" : ""));
        row(card, "    Armor", Fmt.num(d.optLong("lootArmor")));
        row(card, "    Clothing", Fmt.num(d.optLong("lootClothing")));
        row(card, "    Jewelry", Fmt.num(d.optLong("lootJewelry")));
        row(card, "    Weapons", Fmt.num(d.optLong("lootWeapons")));
        row(card, "    Misc", Fmt.num(d.optLong("lootMisc")));
        // start the session over (the Session tab's "Reset session")
        Button clr = new Button(this);
        clr.setText("Reset session");
        clr.setOnClickListener(v -> resetSession());
        LinearLayout cb = Ui.hbox(this);
        cb.setPadding(0, Ui.dp(this, 6), 0, 0);
        cb.addView(clr, Ui.weight(1));
        card.addView(cb);
        fold(card, "stats", sh);
        body.addView(card);

        body.addView(controlsCard());

        // luminance and coins (MelkTank's Session > Lum tab)
        JSONObject lt = d.optJSONObject("lumTab");
        if (lt != null) body.addView(lumCard(lt));

        // bounties and kill tasks (what MelksQB's pop-up shows)
        JSONArray pop = d.optJSONArray("popup");
        if (pop != null && pop.length() > 0) {
            LinearLayout bc = Ui.card(this);
            TextView bh = heading("Bounties / kill tasks");
            bc.addView(bh);
            boolean ktHead = false;
            for (int i = 0; i < pop.length(); i++) {
                String l = pop.optString(i, "");
                if (l.length() < 2 || l.charAt(1) != '|') continue;
                char k = l.charAt(0);
                String[] p = l.substring(2).split("\\|", -1);
                if (k == 'B') {
                    LinearLayout r = Ui.hbox(this);
                    r.setPadding(0, Ui.dp(this, 4), 0, 0);
                    TextView z = Ui.text(this, p[0], 15, false);
                    r.addView(z, Ui.weight(1));
                    TextView c = Ui.text(this, p.length > 1 ? p[1] : "", 15, true);
                    c.setGravity(Gravity.END);
                    r.addView(c);
                    bc.addView(r);
                    if (p.length > 2 && !p[2].isEmpty()) {
                        String have = p.length > 3 && !p[3].isEmpty() ? "   ·   you have " + p[3] : "";
                        TextView rw = Ui.text(this, "Reward: " + p[2] + have, 12, false);
                        rw.setTextColor(Ui.muted(this));
                        bc.addView(rw);
                    }
                } else if (k == 'E') {
                    TextView e = Ui.text(this, p[0], 13, false);
                    e.setTextColor(Ui.AMBER);
                    e.setPadding(0, Ui.dp(this, 4), 0, 0);
                    bc.addView(e);
                } else if (k == 'K' || k == 'D') {
                    if (!ktHead) {
                        TextView h = Ui.text(this, "Kill tasks", 14, true);
                        h.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 2));
                        bc.addView(h);
                        ktHead = true;
                    }
                    TextView t = Ui.text(this, (k == 'D' ? "\u2713 " : "") + p[0], 14, false);
                    if (k == 'D') t.setTextColor(Ui.GREEN);
                    t.setPadding(Ui.dp(this, 8), 0, 0, Ui.dp(this, 2));
                    bc.addView(t);
                }
            }
            // ask the game again: /bounty list (every zone and its timer) then /bounty (where you stand)
            Button upd = new Button(this);
            upd.setText("Update bounties");
            upd.setAllCaps(false);
            upd.setOnClickListener(v -> updateBounties());
            bc.addView(upd);
            fold(bc, "bounties", bh);
            body.addView(bc);
        }

        // rebuffing: time until each rebuff (Creature Enchantment Mastery = the full rebuff, then each spell gem), and
        // buttons to force a rebuff now or cancel one that's running
        JSONObject bf = d.optJSONObject("buffs");
        if (bf != null && bf.has("rows")) {
            LinearLayout rc = Ui.card(this);
            TextView rh = heading("Rebuffing");
            rc.addView(rh);
            String st = bf.optString("status");
            boolean busy = bf.optBoolean("busy") || bf.optBoolean("paused");
            TextView stv = Ui.text(this, (bf.optBoolean("enabled") ? "" : "Buffing is off · ") + (st.isEmpty() ? "Idle" : st), 13, false);
            stv.setTextColor(busy ? Ui.AMBER : Ui.muted(this));
            rc.addView(stv);
            TextView note = Ui.text(this, "Rebuffs with under " + bf.optInt("rebuffMin") + " min left", 12, false);
            note.setTextColor(Ui.muted(this));
            note.setPadding(0, 0, 0, Ui.dp(this, 4));
            rc.addView(note);
            JSONArray rows = bf.optJSONArray("rows");
            for (int i = 0; rows != null && i < rows.length(); i++) {
                JSONObject r = rows.optJSONObject(i);
                if (r == null) continue;
                LinearLayout line = Ui.hbox(this);
                line.setPadding(0, Ui.dp(this, 3), 0, Ui.dp(this, 3));
                LinearLayout names = Ui.vbox(this);
                TextView n = Ui.text(this, r.optString("n"), 14, false);
                TextView k = Ui.text(this, r.optString("k") + (r.optBoolean("off") ? " · not used" : "") +
                        (r.optLong("left") > 0 ? " · " + Fmt.duration(r.optLong("left") * 1000) + " left" : " · not on"), 12, false);
                k.setTextColor(Ui.muted(this));
                names.addView(n);
                names.addView(k);
                line.addView(names, Ui.weight(1));
                long in = r.optLong("rebuffIn");
                boolean learned = !r.optString("k").contains("not learned");
                TextView when = Ui.text(this, r.optBoolean("off") || !learned ? "-" : in <= 0 ? "due" : "in " + Fmt.duration(in * 1000), 14, true);
                when.setTextColor(r.optBoolean("off") || !learned ? Ui.muted(this) : in <= 0 ? Ui.RED : in < 600 ? Ui.AMBER : Ui.GREEN);
                when.setGravity(Gravity.END);
                line.addView(when);
                rc.addView(line);
            }
            LinearLayout btns = Ui.hbox(this);
            btns.setPadding(0, Ui.dp(this, 6), 0, 0);
            Button go = new Button(this);
            go.setText("Rebuff now");
            go.setOnClickListener(v -> rebuff(false));
            btns.addView(go, Ui.weight(1));
            Button stop = new Button(this);
            stop.setText("Cancel rebuff");
            stop.setOnClickListener(v -> rebuff(true));
            btns.addView(stop, Ui.weight(1));
            rc.addView(btns);
            fold(rc, "rebuff", rh);
            body.addView(rc);
        }

        // the Session tab's Bank and Augs pages (same order), each with a button to ask the game again
        listCard(d.optJSONObject("bank"), "Bank", "bank", "Check bank", "/bank", "Nothing yet - tap Check bank.", true);
        listCard(d.optJSONObject("augs"), "Augs", "augs", "Check augs", "/aug", "Nothing yet - tap Check augs.", false);
        charmsCard(d.optJSONObject("charms"));

        // kills, grouped by species: tap "Kills" to fold the list, tap a species to open it; sort by the drop-down
        JSONArray mobs = d.optJSONArray("mobs");
        LinearLayout kc = Ui.card(this);
        int killTotal = 0;
        for (int i = 0; mobs != null && i < mobs.length(); i++) killTotal += mobs.optJSONObject(i) == null ? 0 : mobs.optJSONObject(i).optInt("kills");
        LinearLayout kh = Ui.hbox(this);
        TextView kt = heading((killsOpen ? "\u25BE " : "\u25B8 ") + "Kills (" + Fmt.num(killTotal) + ")");
        kt.setOnClickListener(v -> { killsOpen = !killsOpen; render(); });
        kh.addView(kt, Ui.weight(1));
        if (killsOpen && mobs != null && mobs.length() > 0) {
            Spinner sort = new Spinner(this);
            ArrayAdapter<String> sa = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, KILL_SORTS);
            sa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            sort.setAdapter(sa);
            sort.setSelection(killSort);
            sort.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (position != killSort) { killSort = position; render(); }
                }
                @Override public void onNothingSelected(AdapterView<?> parent) { }
            });
            kh.addView(sort);
        }
        kc.addView(kh);
        if (!killsOpen) { }
        else if (mobs == null || mobs.length() == 0) kc.addView(muted("No kills yet this session."));
        else {
            Map<String, List<JSONObject>> groups = new LinkedHashMap<>();
            for (int i = 0; i < mobs.length(); i++) {
                JSONObject m = mobs.optJSONObject(i);
                if (m == null) continue;
                String sp = m.optString("species", "");
                if (sp.isEmpty()) sp = "Other";
                groups.computeIfAbsent(sp, k -> new ArrayList<>()).add(m);
            }
            List<Map.Entry<String, List<JSONObject>>> sorted = new ArrayList<>(groups.entrySet());
            if (killSort == 2) sorted.sort((x, y) -> x.getKey().compareToIgnoreCase(y.getKey()));
            else if (killSort == 1) sorted.sort((x, y) -> Integer.compare(total(x.getValue()), total(y.getValue())));
            else sorted.sort((x, y) -> Integer.compare(total(y.getValue()), total(x.getValue())));
            for (Map.Entry<String, List<JSONObject>> g : sorted) {
                String key = g.getKey();
                boolean open = openGroups.contains(key);
                LinearLayout gh = Ui.hbox(this);
                gh.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 4));
                TextView gt = Ui.text(this, (open ? "\u25BE " : "\u25B8 ") + key, 15, true);
                gh.addView(gt, Ui.weight(1));
                TextView gn = Ui.text(this, Fmt.num(total(g.getValue())), 15, true);
                gh.addView(gn);
                gh.setOnClickListener(v -> { if (!openGroups.remove(key)) openGroups.add(key); render(); });
                kc.addView(gh);
                if (!open) continue;
                List<JSONObject> ms = new ArrayList<>(g.getValue());
                if (killSort == 2) ms.sort((x, y) -> x.optString("name").compareToIgnoreCase(y.optString("name")));
                else if (killSort == 1) ms.sort((x, y) -> Integer.compare(x.optInt("kills"), y.optInt("kills")));
                else ms.sort((x, y) -> Integer.compare(y.optInt("kills"), x.optInt("kills")));
                for (JSONObject m : ms) {
                    boolean out = m.optBoolean("out");
                    LinearLayout mr = Ui.hbox(this);
                    TextView t = Ui.text(this, m.optString("name") + (out ? "  (left out)" : "") + "   " + Fmt.num(m.optLong("kills")) +
                            "   avg " + secsText(m.optDouble("avg")) + " · fastest " + secsText(m.optDouble("fastest")) +
                            " · slowest " + secsText(m.optDouble("slowest")), 14, false);
                    if (out) t.setTextColor(Ui.muted(this));
                    t.setPadding(Ui.dp(this, 16), 0, 0, Ui.dp(this, 3));
                    mr.addView(t, Ui.weight(1));
                    // "Out": left out of the packs / tuning numbers (kills and kills / hour still count)
                    android.widget.CheckBox ocb = new android.widget.CheckBox(this);
                    ocb.setText("Out");
                    ocb.setChecked(out);
                    String nm = m.optString("name");
                    ocb.setOnCheckedChangeListener((b2, on) -> tuneOut(nm, on));
                    mr.addView(ocb);
                    kc.addView(mr);
                }
            }
        }
        body.addView(kc);

        // other players who came near: the closest ones around now, then the most recently seen (10 in all)
        JSONArray pl = d.optJSONArray("players");
        LinearLayout pc = Ui.card(this);
        int nearNow = 0, crossed = 0;
        for (int i = 0; pl != null && i < pl.length(); i++) {
            JSONObject p = pl.optJSONObject(i);
            if (p == null) continue;
            if (p.optBoolean("near")) nearNow++;
            if (p.optBoolean("route")) crossed++;
        }
        int range = d.optInt("playersRange", 60), routeM = d.optInt("playersRouteM", 10);
        TextView ph = heading("Players nearby (" + nearNow + " now" + (crossed > 0 ? " · " + crossed + " on route" : "") + ")");
        pc.addView(ph);
        if (pl == null || pl.length() == 0) pc.addView(muted("Nobody within " + range + " m yet."));
        else {
            for (int i = 0; i < pl.length(); i++) {
                JSONObject p = pl.optJSONObject(i);
                if (p == null) continue;
                boolean near = p.optBoolean("near"), route = p.optBoolean("route");
                LinearLayout r = Ui.hbox(this);
                r.setPadding(0, Ui.dp(this, 6), 0, 0);
                TextView n = Ui.text(this, p.optString("name"), 15, true);
                if (!near) n.setTextColor(Ui.muted(this));
                r.addView(n, Ui.weight(1));
                TextView w = Ui.text(this, near ? p.optInt("dist") + " m now" : agoText(p.optLong("agoSecs")) + " ago", 14, near);
                if (near) w.setTextColor(0xFF66CC66);
                r.addView(w);
                pc.addView(r);
                long rd = p.optLong("routeDist", -1);
                String info = "closest " + p.optInt("closest") + " m · first seen " + agoText(p.optLong("firstAgoSecs")) + " ago" +
                        (route ? " · CROSSED YOUR ROUTE" + (p.optString("routeSteps", "").isEmpty() ? "" : " at step " + p.optString("routeSteps")) +
                                (rd >= 0 ? " (" + rd + " m)" : "") : rd >= 0 ? " · " + rd + " m from route" +
                                (p.optString("routeSteps", "").isEmpty() ? "" : " (near step " + p.optString("routeSteps") + ")") : "");
                TextView t = Ui.text(this, info, 12, false);
                t.setTextColor(route ? 0xFFFF9944 : Ui.muted(this));
                t.setPadding(Ui.dp(this, 12), 0, 0, 0);
                pc.addView(t);
            }
            pc.addView(muted("Within " + range + " m of you; \"crossed your route\" = came within " + routeM + " m of the selected route's path."));
        }
        fold(pc, "players", ph);
        body.addView(pc);

        // packs, where the time goes, kills by stretch of route, damage by source, slow kills (MelkTank's Packs tab)
        JSONArray pk = d.optJSONArray("packList");
        if (pk != null) {
            LinearLayout tc = Ui.card(this);
            TextView th = heading("Packs & tuning");
            tc.addView(th);
            if (pk.length() == 0) tc.addView(muted("No packs yet this session."));
            else {
                double f = 0, l = 0; int k = 0, db = 0, st = 0, rg = 0, ar = 0, ml = 0, rl = 0, dr = 0;
                for (int i = 0; i < pk.length(); i++) {
                    JSONObject o = pk.optJSONObject(i);
                    if (o == null) continue;
                    f += o.optDouble("fight"); l += o.optDouble("loot"); k += o.optInt("kills"); db += o.optInt("debuffs"); st += o.optInt("streaks");
                    rg += o.optInt("rings"); ar += o.optInt("arcs"); ml += o.optInt("melee"); rl += o.optInt("releases"); dr += o.optInt("drops");
                }
                int n = pk.length();
                TextView avg = Ui.text(this, String.format(java.util.Locale.US, "Last %d packs: fight %.1fs · loot %.1fs · %.1f kills · %.1f debuffs · %.1f streaks%s%s%s · %.1f NF · %d drops",
                        n, f / n, l / n, (double) k / n, (double) db / n, (double) st / n,
                        rg > 0 ? String.format(java.util.Locale.US, " · %.1f rings", (double) rg / n) : "",
                        ar > 0 ? String.format(java.util.Locale.US, " · %.1f arcs", (double) ar / n) : "",
                        ml > 0 ? String.format(java.util.Locale.US, " · %.1f swings", (double) ml / n) : "",
                        (double) rl / n, dr), 14, true);
                avg.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 4));
                tc.addView(avg);
                for (int i = 0; i < pk.length(); i++) {
                    JSONObject o = pk.optJSONObject(i);
                    if (o == null) continue;
                    String atk = o.optInt("streaks") + " S" + (o.optInt("rings") > 0 ? " · " + o.optInt("rings") + " R" : "") + (o.optInt("arcs") > 0 ? " · " + o.optInt("arcs") + " A" : "") + (o.optInt("melee") > 0 ? " · " + o.optInt("melee") + " swings" : "");
                    TextView t = Ui.text(this, "#" + o.optInt("n") + " " + o.optString("at") + (o.optInt("step") > 0 ? " step " + o.optInt("step") : "") + "  ·  " +
                            o.optDouble("fight") + "s + loot " + o.optDouble("loot") + "s  ·  " + o.optInt("kills") + " kills  ·  " + o.optInt("debuffs") + " debuffs · " + atk +
                            " · " + o.optInt("releases") + " NF" + (o.optInt("drops") > 0 ? " · " + o.optInt("drops") + " dropped" : ""), 12, false);
                    if (o.optInt("drops") > 0) t.setTextColor(0xFFFF9944);
                    t.setPadding(Ui.dp(this, 8), 0, 0, Ui.dp(this, 2));
                    tc.addView(t);
                }
            }
            JSONArray ts = d.optJSONArray("timeShare");
            if (ts != null && ts.length() > 0) {
                double tot = 0;
                for (int i = 0; i < ts.length(); i++) tot += ts.optJSONObject(i).optDouble("s");
                tc.addView(subhead("Where the time goes"));
                for (int i = 0; i < ts.length(); i++) {
                    JSONObject o = ts.optJSONObject(i);
                    double sv = o.optDouble("s");
                    if (tot <= 0 || sv < 1) continue;
                    tc.addView(line(String.format(java.util.Locale.US, "%3.0f%%  %s  (%s)", 100 * sv / tot, o.optString("k"), agoText((long) sv))));
                }
            }
            JSONArray sg = d.optJSONArray("segments");
            if (sg != null && sg.length() > 0) {
                tc.addView(subhead("Kills by stretch of route"));
                for (int i = 0; i < sg.length(); i++) {
                    JSONObject o = sg.optJSONObject(i);
                    double segS = o.optDouble("secs");
                    String kpm = segS > 30 ? String.format(java.util.Locale.US, "%.1f/min", o.optInt("kills") / (segS / 60)) : "-";
                    TextView t = line(o.optString("route") + " steps " + o.optInt("from") + "-" + o.optInt("to") + ":  " + o.optInt("kills") + " kills in " + agoText((long) segS) + "  (" + kpm + ")");
                    if (segS > 60 && o.optInt("kills") / (segS / 60) < 1) t.setTextColor(0xFFFF9944);
                    tc.addView(t);
                }
            }
            JSONArray dm = d.optJSONArray("damage");
            if (dm != null && dm.length() > 0) {
                double tot = 0;
                for (int i = 0; i < dm.length(); i++) tot += dm.optJSONObject(i).optDouble("n");
                tc.addView(subhead("Damage by source"));
                for (int i = 0; i < dm.length(); i++) {
                    JSONObject o = dm.optJSONObject(i);
                    tc.addView(line(String.format(java.util.Locale.US, "%3.0f%%  %s  %s", tot > 0 ? 100 * o.optDouble("n") / tot : 0, o.optString("k"), Fmt.big(o.optLong("n")))));
                }
            }
            JSONArray ds = d.optJSONArray("dotShare");
            if (ds != null && ds.length() > 0) {
                tc.addView(subhead("DoT share  (all: " + d.optInt("dotPct") + "% of damage)"));
                tc.addView(line("per kill: your hits / Fracture burst / DoTs"));
                for (int i = 0; i < ds.length(); i++) {
                    JSONObject o = ds.optJSONObject(i);
                    tc.addView(line(String.format(java.util.Locale.US, "%3d%%  %s (%d)  %s / %s / %s", o.optInt("pct"), o.optString("k"), o.optInt("kills"),
                            Fmt.big(o.optLong("hits")), Fmt.big(o.optLong("burst")), Fmt.big(o.optLong("dot")))));
                }
            }
            JSONArray sw = d.optJSONArray("slow");
            tc.addView(subhead("Slow kills (" + d.optInt("slowCount") + ")"));
            if (sw == null || sw.length() == 0) tc.addView(line("None."));
            else for (int i = 0; i < sw.length(); i++) { TextView t = line(sw.optString(i)); t.setTextColor(0xFFFF9944); tc.addView(t); }
            fold(tc, "packs", th);
            body.addView(tc);
        }

        // looted items, with their full ID lines
        JSONArray loot = d.optJSONArray("loot");
        LinearLayout lc = Ui.card(this);
        LinearLayout lh = Ui.hbox(this);
        TextView lth = heading("Looted items" + (loot != null ? " (" + loot.length() + ")" : ""));
        lh.addView(lth, Ui.weight(1));
        Spinner pick = new Spinner(this);
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, CATS);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        pick.setAdapter(ad);
        pick.setSelection(cat);
        pick.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != cat) { cat = position; render(); }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        lh.addView(pick);
        lc.addView(lh);
        int shown = 0;
        if (loot != null) {
            for (int i = 0; i < loot.length(); i++) {
                JSONObject it = loot.optJSONObject(i);
                if (it == null) continue;
                if (cat > 0 && !CATS[cat].equalsIgnoreCase(it.optString("cat"))) continue;
                lc.addView(item(it));
                shown++;
            }
        }
        if (shown == 0) lc.addView(muted(cat > 0 ? "Nothing in " + CATS[cat] + " yet." : "Nothing looted yet this session."));
        else lc.addView(muted("Long-press an item to copy its ID."));
        fold(lc, "loot", lth);
        body.addView(lc);
        enlCard(body);
    }

    private boolean enlOpen = false;

    /** Auto enlighten (collapsed to start with; at the bottom of the page). */
    private void enlCard(LinearLayout body) {
        // auto enlighten: status, start / stop, target (MelkTank's Session > Enl > Auto enlighten)
        if (acct != null && "online".equals(acct.optString("state")) && acct.has("enlStatus")) {
            LinearLayout ec = Ui.card(this);
            boolean on = acct.optBoolean("enlOn");
            TextView eh0 = heading((enlOpen ? "\u25BE " : "\u25B8 ") + "Auto enlighten" + (on ? " - running" : ""));
            eh0.setOnClickListener(v -> { enlOpen = !enlOpen; render(); });
            ec.addView(eh0);
            if (!enlOpen) { body.addView(ec); return; }
            int now = acct.optInt("enlNow", -1), target = acct.optInt("enlTarget", 0);
            TextView es = Ui.text(this, (on ? "Running - " : "Not running - ") + acct.optString("enlStatus", "idle")
                    + (target > 0 ? "\nTarget: " + target : "\nNo target - until out of luminance / mats"), 13, false);
            es.setTextColor(on ? 0xFF7BD88F : Ui.muted(this));
            ec.addView(es);
            // your enlightenment, what the next one needs / is missing, the target's totals (or how far you can go)
            org.json.JSONArray el = acct.optJSONArray("enlLines");
            if (el == null) {
                TextView e0 = Ui.text(this, "Enlightenment " + (now < 0 ? "?" : String.valueOf(now)), 14, true);
                ec.addView(e0);
            }
            for (int i = 0; el != null && i < el.length(); i++) {
                String ln = el.optString(i);
                String k = ln.length() > 1 && ln.charAt(1) == '|' ? ln.substring(0, 1) : "n";
                String tx = ln.length() > 1 && ln.charAt(1) == '|' ? ln.substring(2) : ln;
                TextView lv = Ui.text(this, tx, k.equals("h") ? 14 : 13, k.equals("h"));
                if (k.equals("g")) lv.setTextColor(0xFF7BD88F);
                else if (k.equals("r")) lv.setTextColor(0xFFFF8A80);
                if (k.equals("h") && i > 0) lv.setPadding(0, Ui.dp(this, 6), 0, 0);
                ec.addView(lv);
            }
            LinearLayout er = Ui.hbox(this);
            er.setGravity(Gravity.CENTER_VERTICAL);
            Button eb = new Button(this);
            eb.setAllCaps(false);
            eb.setText(on ? "Stop" : "Start");
            eb.setOnClickListener(v -> enlCommand(on ? "stop" : "start", on ? "Stopping auto enlighten" : "Starting auto enlighten"));
            er.addView(eb);
            Button tb = new Button(this);
            tb.setAllCaps(false);
            tb.setText("Target...");
            tb.setOnClickListener(v -> {
                android.widget.EditText in = new android.widget.EditText(this);
                in.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
                in.setText(String.valueOf(target));
                android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(this).setTitle("Stop at enlightenment (0 = keep going)")
                        .setView(in)
                        .setPositiveButton("Set", (d2, w) -> { String t = in.getText().toString().trim(); if (t.matches("\\d+")) enlCommand("target " + t, "Target set to " + t); })
                        .setNegativeButton("Cancel", null).create();
                dlg.show();
                if (dlg.getWindow() != null) {
                    dlg.getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
                    dlg.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
                }
                in.requestFocus();
            });
            er.addView(tb);
            ec.addView(er);
            // enlightenment tokens: buy what the next one needs, buy all the coins allow, or take the bank's out
            LinearLayout tr = Ui.hbox(this);
            tr.setGravity(Gravity.CENTER_VERTICAL);
            String[][] tokens = { {"Buy needed", "buy need", "Buying the tokens needed"}, {"Buy max", "buy max", "Buying all the coins allow"},
                    {"Withdraw", "withdraw all", "Withdrawing the bank's tokens"} };
            for (int i = 0; i < 3; i++) {
                String[] t = tokens[i];
                Button b = new Button(this);
                b.setAllCaps(false);
                b.setText(t[0]);
                b.setOnClickListener(v -> new android.app.AlertDialog.Builder(this).setTitle(t[0] + " tokens?")
                        .setMessage(t[0].startsWith("Buy") ? "Spends Enlightened Coins (20 per token)." : "Takes every Enlightenment Token out of the bank.")
                        .setPositiveButton(t[0], (d2, w) -> enlCommand(t[1], t[2]))
                        .setNegativeButton("Cancel", null).show());
                tr.addView(b);
            }
            ec.addView(tr);
            TextView eh = Ui.text(this, "The way outside and the skills to retrain are set in the game (Session > Enl).", 12, false);
            eh.setTextColor(Ui.muted(this));
            ec.addView(eh);
            body.addView(ec);
        }
    }


    private View item(JSONObject it) {
        LinearLayout box = Ui.vbox(this);
        box.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 8));
        String rule = it.optString("rule", "");
        LinearLayout top = Ui.hbox(this);
        TextView when = Ui.text(this, clock(it.optString("time")) + "  ·  " + it.optString("cat"), 12, false);
        when.setTextColor(Ui.muted(this));
        top.addView(when, Ui.weight(1));
        if (!rule.isEmpty()) {
            TextView r = Ui.text(this, rule, 12, true);
            r.setTextColor(Ui.GREEN);
            r.setGravity(Gravity.END);
            top.addView(r);
        }
        box.addView(top);
        String id = it.optString("id", "");
        TextView t = Ui.text(this, id, 14, false);
        t.setTextIsSelectable(false);
        box.addView(t);
        String vs = it.optString("vs", "");
        if (!vs.isEmpty()) {
            // the compare line from the ID
            int vc = it.optInt("vsColor", 7);
            TextView c = Ui.text(this, vs, 13, false);
            // the game's chat colours: 10 yellow better, 18 orange better overall / on a slayer, 15 red worse, 8 blue mixed
            c.setTextColor(vc == 10 ? android.graphics.Color.rgb(242, 217, 77) : vc == 18 ? android.graphics.Color.rgb(255, 153, 51)
                         : vc == 15 ? Ui.RED : vc == 8 ? android.graphics.Color.rgb(115, 204, 242) : Ui.muted(this));
            c.setPadding(Ui.dp(this, 12), Ui.dp(this, 2), 0, 0);
            box.addView(c);
        }
        box.setOnLongClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("item", vs.isEmpty() ? id : id + "\n" + vs));
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show();
            return true;
        });
        View line = new View(this);
        line.setBackgroundColor(Ui.lineColor(this));
        LinearLayout wrap = Ui.vbox(this);
        wrap.addView(line, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 1)));
        wrap.addView(box);
        return wrap;
    }

    private void row(LinearLayout parent, String label, String value) {
        LinearLayout r = Ui.hbox(this);
        r.setPadding(0, Ui.dp(this, 3), 0, Ui.dp(this, 3));
        TextView l = Ui.text(this, label, 15, false);
        l.setTextColor(Ui.muted(this));
        r.addView(l, Ui.weight(1));
        TextView v = Ui.text(this, value, 15, true);
        v.setGravity(Gravity.END);
        v.setMaxWidth((int) (getResources().getDisplayMetrics().widthPixels * 0.5));
        v.setPadding(Ui.dp(this, 8), 0, 0, 0);
        r.addView(v);
        parent.addView(r);
    }

    /** A name / value list card (Bank, Augs) with its "as of" time and a button that sends the game command. */
    // ── MelkTank's Items > Charms: level, ON / OFF, coins and what each does; the Prestige Coins in the bank ──
    private void charmsCard(JSONObject o) {
        LinearLayout c = Ui.card(this);
        TextView h = heading("Charms");
        c.addView(h);
        long pc = o == null ? -1 : o.optLong("prestigeCoins", -1);
        row(c, "Prestige Coins (bank)", pc >= 0 ? Fmt.big(pc) : "? - check the bank");
        JSONArray rows = o == null ? null : o.optJSONArray("rows");
        if (rows == null || rows.length() == 0) c.addView(muted("No charms - add them in MelkTank, Items > Charms."));
        for (int i = 0; rows != null && i < rows.length(); i++) {
            JSONArray r = rows.optJSONArray(i);
            if (r == null) continue;
            String name = r.optString(0), lvl = r.optString(1), st = r.optString(2), coins = r.optString(3), what = r.optString(4);
            TextView n = Ui.text(this, name, 15, true);
            n.setPadding(0, Ui.dp(this, i == 0 ? 6 : 10), 0, 0);
            c.addView(n);
            LinearLayout line = Ui.hbox(this);
            if (!lvl.isEmpty()) {
                TextView lt = Ui.text(this, lvl + "   ", 13, false);
                lt.setTextColor(android.graphics.Color.rgb(90, 200, 230));
                line.addView(lt);
            }
            TextView stt = Ui.text(this, st, 13, true);
            stt.setTextColor("ON".equals(st) || "Always".equals(st) ? Ui.GREEN : Ui.GREY);
            line.addView(stt);
            if (!coins.isEmpty()) {
                TextView ct = Ui.text(this, "   " + coins + " coins", 13, false);
                ct.setTextColor(Ui.muted(this));
                line.addView(ct);
            }
            c.addView(line);
            if (!what.isEmpty()) {
                TextView w = Ui.text(this, what, 13, false);
                w.setPadding(0, Ui.dp(this, 2), 0, 0);
                c.addView(w);
            }
        }
        android.content.SharedPreferences ui = getSharedPreferences("session_ui", MODE_PRIVATE);
        if (!ui.contains("open_charms")) ui.edit().putBoolean("open_charms", false).apply();   // starts folded
        fold(c, "charms", h);
        body.addView(c);
    }

    private void listCard(JSONObject o, String title, String key, String button, String command, String empty, boolean bank) {
        LinearLayout c = Ui.card(this);
        TextView h = heading(title);
        c.addView(h);
        String at = o == null ? "" : o.optString("at");
        JSONArray rows = o == null ? null : o.optJSONArray("rows");
        if (!at.isEmpty()) {
            TextView t = Ui.text(this, "As of " + Fmt.ago(at), 12, false);
            t.setTextColor(Ui.muted(this));
            c.addView(t);
        }
        if (rows == null || rows.length() == 0) c.addView(muted(empty));
        for (int i = 0; rows != null && i < rows.length(); i++) {
            JSONArray r = rows.optJSONArray(i);
            if (r == null) continue;
            // "79 (bound to you - deposit / withdraw only)": the number on the row, the note in small text under it
            String v = r.optString(1), note = "";
            int paren = v.indexOf(" (");
            if (paren > 0) { note = v.substring(paren + 1).trim(); v = v.substring(0, paren); }
            row(c, r.optString(0), v);
            if (!note.isEmpty()) {
                TextView n = Ui.text(this, note, 12, false);
                n.setTextColor(Ui.muted(this));
                n.setGravity(Gravity.END);
                n.setPadding(0, 0, 0, Ui.dp(this, 3));
                c.addView(n);
            }
        }
        if (bank) bankButtons(c);
        Button b = new Button(this);
        b.setText(button);
        b.setOnClickListener(v -> io.execute(() -> {
            String msg;
            try { Api.sendChat(prefs, account, command, false); msg = "Asked the game (" + command + ")."; } catch (Exception e) { msg = e.getMessage(); }
            String m = msg;
            main.post(() -> {
                Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
                main.postDelayed(this::load, 4500);   // MelkTank writes the session again ~2.5 s after the answer
            });
        }));
        c.addView(b);
        fold(c, key, h);
        body.addView(c);
    }

    // ── the Chat page's bank buttons, here too: deposit the pack (when idle), all but 1 lum / coins to another character ──
    private void bankButtons(LinearLayout c) {
        LinearLayout row = Ui.hbox(this);
        row.setPadding(0, Ui.dp(this, 6), 0, 0);
        Button dep = new Button(this);
        dep.setText("Deposit");
        dep.setOnClickListener(v -> io.execute(() -> {
            String msg;
            try { msg = Api.sendChat(prefs, account, "/b d", true).optString("message", "Sent."); } catch (Exception e) { msg = e.getMessage(); }
            String m = msg;
            main.post(() -> Toast.makeText(this, m, Toast.LENGTH_SHORT).show());
        }));
        row.addView(dep, Ui.weight(1));
        c.addView(row);

        // what to send: everything the bank can transfer (not Enlightenment Tokens or Prestige Coins)
        LinearLayout sendRow = Ui.hbox(this);
        sendRow.setPadding(0, Ui.dp(this, 4), 0, 0);
        TextView sl = Ui.text(this, "Send: ", 13, false);
        sl.setTextColor(Ui.muted(this));
        sendRow.addView(sl);
        Spinner what = new Spinner(this);
        ArrayAdapter<String> wa = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, BANK_NAMES);
        wa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        what.setAdapter(wa);
        int wPre = java.util.Arrays.asList(BANK_KINDS).indexOf(getSharedPreferences("session_ui", MODE_PRIVATE).getString("sendKind", "l"));
        if (wPre >= 0) what.setSelection(wPre);
        what.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                getSharedPreferences("session_ui", MODE_PRIVATE).edit().putString("sendKind", BANK_KINDS[position]).apply();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        sendRow.addView(what, Ui.weight(1));
        Button send = new Button(this);
        send.setText("Send \u2192");
        send.setOnClickListener(v -> {
            int pos = what.getSelectedItemPosition();
            if (pos >= 0 && pos < BANK_KINDS.length) transfer(BANK_KINDS[pos]);
        });
        sendRow.addView(send);

        java.util.ArrayList<String> others = getIntent().getStringArrayListExtra("others");
        if (others == null) others = new java.util.ArrayList<>();
        final java.util.ArrayList<String> list = others;
        LinearLayout toRow = Ui.hbox(this);
        TextView toL = Ui.text(this, "To: ", 13, false);
        toL.setTextColor(Ui.muted(this));
        toRow.addView(toL);
        Spinner pick = new Spinner(this);
        ArrayAdapter<String> ta = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,
                list.isEmpty() ? new String[]{"(no other character known)"} : list.toArray(new String[0]));
        ta.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        pick.setAdapter(ta);
        int pre = list.indexOf(prefs.transferTo(account));
        if (pre >= 0) pick.setSelection(pre);
        pick.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position < list.size()) prefs.transferTo(account, list.get(position));
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        toRow.addView(pick, Ui.weight(1));
        c.addView(toRow);
        c.addView(sendRow);   // what, under who it goes to
        transferTargets = list;
    }

    private java.util.ArrayList<String> transferTargets = new java.util.ArrayList<>();
    // what the bank can send (/b t <code>): the codes and their names, in the drop-down's order
    private static final String[] BANK_KINDS = { "l", "e", "we", "p", "k", "mk" };
    private static final String[] BANK_NAMES = { "Luminance", "Enlightened Coins", "Weakly Enlightened Coins", "Pyreals", "Legendary Keys", "Mythical Keys" };

    private void transfer(String kind) {
        if (transferTargets.isEmpty()) { Toast.makeText(this, "No other character known yet.", Toast.LENGTH_SHORT).show(); return; }
        String to = prefs.transferTo(account);
        if (to == null || !transferTargets.contains(to)) to = transferTargets.get(0);
        String target = to;
        int ki = java.util.Arrays.asList(BANK_KINDS).indexOf(kind);
        String what = ki >= 0 ? BANK_NAMES[ki].toLowerCase(java.util.Locale.US) : kind;
        new android.app.AlertDialog.Builder(this)
                .setTitle("Transfer " + what)
                .setMessage("Send all of the bank's " + what + " except 1 to " + target + "?\n\n(The amount is read from /bank right before sending.)")
                .setPositiveButton("Send", (d, w) -> io.execute(() -> {
                    String msg;
                    try { msg = Api.bankTransfer(prefs, account, kind, target).optString("message", "Sent."); } catch (Exception e) { msg = e.getMessage(); }
                    String m = msg;
                    main.post(() -> { Toast.makeText(this, m, Toast.LENGTH_LONG).show(); main.postDelayed(this::load, 9000); });
                }))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void resetSession() {
        new android.app.AlertDialog.Builder(this)
                .setTitle("Reset session?")
                .setMessage("Clears this character's session numbers (kills, loot, luminance / XP per hour...) and starts counting from now.")
                .setPositiveButton("Reset", (dlg, w) -> io.execute(() -> {
                    String msg;
                    try { msg = Api.resetSession(prefs, account).optString("message", "Sent."); } catch (Exception e) { msg = e.getMessage(); }
                    String m = msg;
                    main.post(() -> { android.widget.Toast.makeText(this, m, android.widget.Toast.LENGTH_SHORT).show(); main.postDelayed(this::load, 3000); });
                }))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void rebuff(boolean cancel) {
        Runnable send = () -> io.execute(() -> {
            String msg;
            try { msg = Api.rebuff(prefs, account, cancel).optString("message", "Sent."); } catch (Exception e) { msg = e.getMessage(); }
            String m = msg;
            main.post(() -> { android.widget.Toast.makeText(this, m, android.widget.Toast.LENGTH_SHORT).show(); main.postDelayed(this::load, 3000); });
        });
        if (cancel) { send.run(); return; }
        new android.app.AlertDialog.Builder(this)
                .setTitle("Rebuff now?")
                .setMessage("Starts a full rebuff on this character right away.")
                .setPositiveButton("Rebuff", (dlg, w) -> send.run())
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * Makes a card fold up like the Kills card: tap its heading to hide / show everything under the first row.
     * Remembered (per card, for every character).
     */
    private static String coins(double v) {
        return v >= 100 ? String.format(java.util.Locale.US, "%,.0f", v) : String.format(java.util.Locale.US, "%.1f", v);
    }

    /** MelkTank's Lum tab: what's banked, the rates (by the bank: yours and fellow / passup), the turn-ins counted, /b d and /clap all. */
    private LinearLayout lumCard(JSONObject lt) {
        LinearLayout c = Ui.card(this);
        TextView h = heading("Lum");
        c.addView(h);
        long bl = lt.optLong("bankedLum", -1), bc = lt.optLong("bankedCoins", -1);
        row(c, "Banked luminance", bl >= 0 ? Fmt.big(bl) : "not read yet");
        row(c, "Banked coins", bc >= 0 ? Fmt.num(bc) : "not read yet");
        row(c, "Lum / hour", Fmt.big((long) lt.optDouble("lumPh")));
        if (lt.optBoolean("byBank")) {
            row(c, "    earned", Fmt.big((long) lt.optDouble("ownPh")) + " / hr");
            row(c, "    fellow / passup", Fmt.big((long) lt.optDouble("sharedPh")) + " / hr");
        }
        row(c, "Coins / hour", coins(lt.optDouble("coinsPh")));
        row(c, "Lum-coins / hour", coins(lt.optDouble("lumCoinsPh")));
        row(c, "Coins-lum / hour", Fmt.big((long) lt.optDouble("coinsLumPh")));
        row(c, "Effective coins / hour", coins(lt.optDouble("effCoinsPh")));
        row(c, "Effective lum / hour", Fmt.big((long) lt.optDouble("effLumPh")));
        String note = lt.optBoolean("byBank") ? "Lum/hr by the bank since it was read at login or the last reset - fellowship shares and passup included." : "Lum/hr from your own banked lines until the bank's been read.";
        note += "  " + coins(lt.optDouble("sellM")) + "M / " + coins(lt.optDouble("buyM")) + "M lum a coin.";
        TextView n = muted(note);
        n.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 4));
        c.addView(n);
        JSONArray ti = lt.optJSONArray("turnIns");
        if (ti != null && ti.length() > 0) {
            TextView th = Ui.text(this, "Turn-ins counted", 15, true);
            th.setPadding(0, Ui.dp(this, 6), 0, 0);
            c.addView(th);
            for (int i = 0; i < ti.length(); i++) {
                JSONObject t = ti.optJSONObject(i);
                if (t == null) continue;
                String val = Fmt.num(t.optLong("have")) + (t.optInt("per", 1) > 1 ? " (" + t.optInt("per") + " a turn-in)" : "");
                if (t.optDouble("coins") > 0) val += "  ·  " + coins(t.optDouble("coins")) + " coins";
                if (t.optDouble("lum") > 0) val += "  ·  " + Fmt.big((long) t.optDouble("lum")) + " lum";
                row(c, "    " + t.optString("name"), val);
            }
        }
        LinearLayout b = Ui.hbox(this);
        b.setPadding(0, Ui.dp(this, 6), 0, 0);
        for (String[] cmd : new String[][] { { "/b d", "/b d" }, { "/clap all", "/clap all" }, { "/b", "/b" } }) {
            Button x = new Button(this);
            x.setText(cmd[0]);
            String command = cmd[1];
            x.setOnClickListener(v -> io.execute(() -> {
                String msg;
                try { Api.sendChat(prefs, account, command, false); msg = "Asked the game (" + command + ")."; } catch (Exception e) { msg = e.getMessage(); }
                String m = msg;
                main.post(() -> { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); main.postDelayed(this::load, 4500); });
            }));
            b.addView(x, Ui.weight(1));
        }
        c.addView(b);
        fold(c, "lum", h);
        return c;
    }

    private void fold(LinearLayout card, String key, TextView head) {
        android.content.SharedPreferences ui = getSharedPreferences("session_ui", MODE_PRIVATE);
        String base = head.getText().toString();
        Runnable apply = () -> {
            boolean open = ui.getBoolean("open_" + key, true);
            head.setText((open ? "\u25BE " : "\u25B8 ") + base);
            for (int i = 1; i < card.getChildCount(); i++) card.getChildAt(i).setVisibility(open ? View.VISIBLE : View.GONE);
        };
        head.setOnClickListener(v -> { ui.edit().putBoolean("open_" + key, !ui.getBoolean("open_" + key, true)).apply(); apply.run(); });
        apply.run();
    }

    private TextView heading(String s) {
        TextView t = Ui.text(this, s, 17, true);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView muted(String s) {
        TextView t = Ui.text(this, s, 13, false);
        t.setTextColor(Ui.muted(this));
        t.setPadding(0, Ui.dp(this, 6), 0, 0);
        return t;
    }

    private static int total(List<JSONObject> l) {
        int n = 0;
        for (JSONObject m : l) n += m.optInt("kills");
        return n;
    }

    private TextView subhead(String s) {
        TextView t = Ui.text(this, s, 14, true);
        t.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 2));
        return t;
    }

    private TextView line(String s) {
        TextView t = Ui.text(this, s, 13, false);
        t.setPadding(Ui.dp(this, 8), 0, 0, Ui.dp(this, 2));
        return t;
    }

    /** 45s, 12m, 3h 05m */
    private static String agoText(long s) {
        if (s < 60) return s + "s";
        if (s < 3600) return (s / 60) + "m";
        return (s / 3600) + "h " + String.format(java.util.Locale.US, "%02d", (s % 3600) / 60) + "m";
    }

    private static String secsText(double s) {
        if (s <= 0) return "-";
        if (s < 60) return String.format(java.util.Locale.US, "%.1fs", s);
        return ((int) (s / 60)) + ":" + String.format(java.util.Locale.US, "%02d", (int) s % 60);
    }

    private static String clock(String iso) {
        long t = Fmt.time(iso);
        return t < 0 ? "-" : DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date(t));
    }
}
