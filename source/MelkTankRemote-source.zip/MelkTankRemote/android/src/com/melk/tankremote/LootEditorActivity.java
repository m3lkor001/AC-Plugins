package com.melk.tankremote;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The loot editor on the phone: the same .utl profiles as the in-game editor and the PC's Loot Editor.
 * Sync = read the profile again from the PC; Save = write it; Push = save and have every running MelkTank read it
 * again, so a hunting character uses the changes straight away. Requirements are edited one at a time (tap one);
 * the PC turns each edit into the file's text, so it's exactly what the in-game editor would save. T11+ requirements
 * show but can only be changed in game.
 */
public class LootEditorActivity extends Activity {
    private static final String[] ACT_IDS = {"1", "2", "3", "10", "0", "5", "6"};
    private static final String[] ACT_NAMES = {"Keep", "Salvage", "Sell", "Keep up to", "No loot", "Chunk (hammer)", "Reveal (aetheria)"};
    private static final int CYAN = Color.rgb(90, 214, 242), ORANGE = Color.rgb(232, 163, 58), PURPLE = Color.rgb(182, 133, 242);

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private Prefs prefs;
    private JSONObject spec;
    private JSONArray fields;
    private JSONObject profile;          // as the PC sent it, edited in place
    private String file;
    private long mtime;
    private boolean dirty;
    private int sel = -1;                // the rule being edited (-1 = the list)
    private final List<Integer> shown = new ArrayList<>();
    private String filterText = "";

    private Spinner pick;
    private TextView status;
    private Button saveBtn;
    private LinearLayout body;
    private ListView ruleList;
    private RuleAdapter adapter;
    private boolean picking;
    private String opening;              // the profile being read right now

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        setTitle("Loot editor");
        if (getActionBar() != null) getActionBar().setDisplayHomeAsUpEnabled(true);

        LinearLayout root = Ui.vbox(this);
        int p = Ui.dp(this, 10);
        root.setPadding(p, p, p, p);

        LinearLayout bar = Ui.hbox(this);
        Button back = new Button(this);
        back.setText("‹ Back");
        back.setOnClickListener(v -> onBackPressed());
        bar.addView(back);
        pick = new Spinner(this);
        bar.addView(pick, Ui.weight(1));
        root.addView(bar);

        LinearLayout bar2 = Ui.hbox(this);
        Button sync = new Button(this);
        sync.setText("Sync");
        sync.setOnClickListener(v -> sync());
        saveBtn = new Button(this);
        saveBtn.setText("Save");
        saveBtn.setOnClickListener(v -> save(false, false));
        Button push = new Button(this);
        push.setText("Push");
        push.setOnClickListener(v -> save(true, false));
        bar2.addView(sync, Ui.weight(1));
        bar2.addView(saveBtn, Ui.weight(1));
        bar2.addView(push, Ui.weight(1));
        root.addView(bar2);

        status = Ui.text(this, "Loading...", 13, false);
        status.setTextColor(Ui.muted(this));
        root.addView(status);

        body = Ui.vbox(this);
        root.addView(body, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(root);

        pick.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (picking) return;
                String name = (String) parent.getItemAtPosition(position);
                if (name.equals(file) || name.equals(opening)) return;
                if (dirty) {
                    new AlertDialog.Builder(LootEditorActivity.this).setTitle("Unsaved changes")
                            .setMessage("Drop the unsaved changes to " + file + "?")
                            .setPositiveButton("Drop them", (d, w) -> { dirty = false; open(name); })
                            .setNegativeButton("Cancel", (d, w) -> selectInSpinner(file)).show();
                } else open(name);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        start();
    }

    // ── loading ──
    private void start() {
        io.execute(() -> {
            try {
                JSONObject s = Api.lootSpec(prefs);
                JSONObject list = Api.lootList(prefs);
                main.post(() -> {
                    spec = s;
                    fields = s.optJSONArray("fields");
                    fillProfiles(list, null);
                });
            } catch (Exception e) {
                main.post(() -> status.setText(e.getMessage()));
            }
        });
    }

    private void fillProfiles(JSONObject list, String select) {
        JSONArray a = list.optJSONArray("profiles");
        List<String> names = new ArrayList<>();
        for (int i = 0; a != null && i < a.length(); i++) names.add(a.optJSONObject(i).optString("name"));
        picking = true;
        pick.setAdapter(adapter(names.toArray(new String[0])));
        picking = false;
        if (names.isEmpty()) { status.setText("No .utl profiles in " + list.optString("dir")); return; }
        String want = select != null ? select : getSharedPreferences("loot", MODE_PRIVATE).getString("last", names.get(0));
        if (!names.contains(want)) want = names.get(0);
        selectInSpinner(want);
        open(want);
    }

    private void selectInSpinner(String name) {
        for (int i = 0; i < pick.getCount(); i++)
            if (name != null && name.equals(pick.getItemAtPosition(i))) { picking = true; pick.setSelection(i); picking = false; }
    }

    private void open(String name) {
        opening = name;
        status.setText("Reading " + name + "...");
        io.execute(() -> {
            try {
                JSONObject pr = Api.lootProfile(prefs, name);
                main.post(() -> {
                    profile = pr;
                    file = name;
                    mtime = pr.optLong("mtime");
                    setDirty(false);
                    getSharedPreferences("loot", MODE_PRIVATE).edit().putString("last", name).apply();
                    if (sel >= rules().length()) sel = -1;
                    status.setText(counts());
                    show();
                });
            } catch (Exception e) {
                main.post(() -> status.setText(e.getMessage()));
            }
        });
    }

    private void sync() {
        if (file == null) { start(); return; }
        if (dirty) {
            new AlertDialog.Builder(this).setTitle("Sync").setMessage("Drop the unsaved changes and read " + file + " again from the PC?")
                    .setPositiveButton("Sync", (d, w) -> { dirty = false; open(file); })
                    .setNegativeButton("Cancel", null).show();
        } else open(file);
    }

    private void save(boolean push, boolean force) {
        if (profile == null) return;
        if (!dirty && !force) {
            if (!push) { toast("Nothing changed."); return; }
            io.execute(() -> {
                try {
                    JSONObject r = Api.lootPush(prefs, file);
                    main.post(() -> toast(r.optString("message")));
                } catch (Exception e) { main.post(() -> toast(e.getMessage())); }
            });
            return;
        }
        status.setText(push ? "Saving and pushing..." : "Saving...");
        JSONObject send = profile;
        io.execute(() -> {
            try {
                JSONObject r = Api.lootSave(prefs, file, mtime, send, push, force);
                main.post(() -> {
                    if (!r.optBoolean("ok")) {
                        status.setText(counts());
                        new AlertDialog.Builder(this).setTitle("Changed on the PC")
                                .setMessage(r.optString("error", "The profile was changed on the PC since you opened it."))
                                .setPositiveButton("Save anyway", (d, w) -> save(push, true))
                                .setNeutralButton("Sync (drop mine)", (d, w) -> { dirty = false; open(file); })
                                .setNegativeButton("Cancel", null).show();
                        return;
                    }
                    profile = r.optJSONObject("profile");
                    mtime = profile.optLong("mtime");
                    setDirty(false);
                    status.setText(counts());
                    toast(r.optString("message", "Saved."));
                    show();
                });
            } catch (Exception e) {
                main.post(() -> { status.setText(counts()); toast(e.getMessage()); });
            }
        });
    }

    private JSONArray rules() { return profile == null ? new JSONArray() : profile.optJSONArray("rules"); }

    private String counts() {
        JSONArray rs = rules();
        int on = 0;
        for (int i = 0; i < rs.length(); i++) {
            JSONObject r = rs.optJSONObject(i);
            if (!r.optBoolean("off") && !isSection(r)) on++;
        }
        return file + "   " + rs.length() + " rules, " + on + " on - first match wins";
    }

    private void setDirty(boolean d) {
        dirty = d;
        saveBtn.setText(d ? "Save *" : "Save");
        saveBtn.setTextColor(d ? Ui.AMBER : (Ui.dark(this) ? Color.WHITE : Color.BLACK));
    }

    private void changed() { setDirty(true); }

    private static boolean isSection(JSONObject r) { return r.optString("name").trim().startsWith("*"); }
    private static boolean isSpacer(JSONObject r) { return r.optString("name").trim().isEmpty() && r.optBoolean("off"); }

    // ── the two views: the rule list, one rule ──
    private void show() {
        body.removeAllViews();
        if (profile == null) return;
        if (sel >= 0 && sel < rules().length()) showRule(); else { sel = -1; showList(); }
    }

    @Override
    public void onBackPressed() {
        if (sel >= 0) { sel = -1; show(); return; }
        if (dirty) {
            new AlertDialog.Builder(this).setTitle("Unsaved changes").setMessage("Leave without saving " + file + "?")
                    .setPositiveButton("Leave", (d, w) -> finish()).setNegativeButton("Stay", null).show();
            return;
        }
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) { onBackPressed(); return true; }
        return super.onOptionsItemSelected(item);
    }

    private void showList() {
        LinearLayout tools = Ui.hbox(this);
        EditText filter = new EditText(this);
        filter.setHint("filter rules");
        filter.setSingleLine(true);
        filter.setText(filterText);
        tools.addView(filter, Ui.weight(1));
        Button addRule = new Button(this);
        addRule.setText("+ Rule");
        addRule.setOnClickListener(v -> addRule(false));
        Button addSec = new Button(this);
        addSec.setText("+ Section");
        addSec.setOnClickListener(v -> addRule(true));
        tools.addView(addRule);
        tools.addView(addSec);
        body.addView(tools);
        TextView hint = Ui.text(this, "Tap a rule to edit it, tick = rule on. New rules go at the top (move them in the rule).", 12, false);
        hint.setTextColor(Ui.muted(this));
        body.addView(hint);

        ruleList = new ListView(this);
        adapter = new RuleAdapter();
        ruleList.setAdapter(adapter);
        body.addView(ruleList, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        refilter();
        filter.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { filterText = s.toString(); refilter(); }
        });
    }

    private void refilter() {
        shown.clear();
        String f = filterText.trim().toLowerCase();
        JSONArray rs = rules();
        for (int i = 0; i < rs.length(); i++)
            if (f.isEmpty() || rs.optJSONObject(i).optString("name").toLowerCase().contains(f)) shown.add(i);
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private class RuleAdapter extends BaseAdapter {
        @Override public int getCount() { return shown.size(); }
        @Override public Object getItem(int i) { return shown.get(i); }
        @Override public long getItemId(int i) { return shown.get(i); }

        @Override
        public View getView(int pos, View convert, ViewGroup parent) {
            LinearLayout row;
            CheckBox on;
            TextView name, act;
            if (convert == null) {
                row = Ui.hbox(LootEditorActivity.this);
                row.setPadding(0, Ui.dp(LootEditorActivity.this, 2), 0, Ui.dp(LootEditorActivity.this, 2));
                on = new CheckBox(LootEditorActivity.this);
                name = Ui.text(LootEditorActivity.this, "", 14, false);
                act = Ui.text(LootEditorActivity.this, "", 13, false);
                act.setPadding(Ui.dp(LootEditorActivity.this, 6), 0, Ui.dp(LootEditorActivity.this, 4), 0);
                row.addView(on);
                row.addView(name, Ui.weight(1));
                row.addView(act);
            } else {
                row = (LinearLayout) convert;
                on = (CheckBox) row.getChildAt(0);
                name = (TextView) row.getChildAt(1);
                act = (TextView) row.getChildAt(2);
            }
            int idx = shown.get(pos);
            JSONObject r = rules().optJSONObject(idx);
            boolean heading = isSection(r) || isSpacer(r);
            on.setOnCheckedChangeListener(null);
            on.setVisibility(heading ? View.INVISIBLE : View.VISIBLE);
            on.setChecked(!r.optBoolean("off"));
            on.setOnCheckedChangeListener((v, checked) -> { setOff(r, !checked); notifyDataSetChanged(); });
            String n = r.optString("name").trim();
            name.setText(isSpacer(r) ? "------" : n.isEmpty() ? "(no name)" : n);
            name.setTypeface(null, isSection(r) ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            int col = isSection(r) ? Ui.RED : r.optBoolean("off") ? Ui.GREY : actColour(r.optString("act"));
            name.setTextColor(col);
            act.setTextColor(col);
            act.setText(heading ? "" : actText(r));
            row.setOnClickListener(v -> { sel = idx; show(); });
            return row;
        }
    }

    private int actColour(String a) {
        switch (a) {
            case "1": case "10": return Ui.GREEN;
            case "2": return ORANGE;
            case "3": return PURPLE;
            case "5": case "6": return CYAN;
            default: return Ui.GREY;
        }
    }

    private static String actText(JSONObject r) {
        String a = r.optString("act");
        if ("10".equals(a)) return "Keep " + (r.optString("keepn", "1").isEmpty() || r.isNull("keepn") ? "1" : r.optString("keepn"));
        for (int i = 0; i < ACT_IDS.length; i++) if (ACT_IDS[i].equals(a)) return ACT_NAMES[i];
        return r.optString("actName", "Action " + a);
    }

    private void setOff(JSONObject r, boolean off) {
        try {
            r.put("off", off);
            r.put("setOff", off);
        } catch (Exception ignored) { }
        changed();
        status.setText(counts());
    }

    private void addRule(boolean section) {
        try {
            JSONObject r = new JSONObject().put("name", section ? "***** New section *****" : "New rule").put("expr", "")
                    .put("pri", "0").put("act", "1").put("off", section).put("reqs", new JSONArray());
            if (section) {
                r.getJSONArray("reqs").put(new JSONObject().put("type", "1").put("vals", new JSONArray().put("do not edit").put("1")).put("dirty", true));
                r.put("setOff", true);
            }
            insertRule(0, r);
        } catch (Exception ignored) { }
    }

    private void insertRule(int at, JSONObject r) throws Exception {
        JSONArray old = rules(), now = new JSONArray();
        for (int i = 0; i <= old.length(); i++) {
            if (i == at) now.put(r);
            if (i < old.length()) now.put(old.get(i));
        }
        profile.put("rules", now);
        sel = at;
        changed();
        status.setText(counts());
        show();
    }

    // ── one rule ──
    private void showRule() {
        JSONObject r = rules().optJSONObject(sel);
        ScrollView sv = new ScrollView(this);
        LinearLayout v = Ui.vbox(this);
        sv.addView(v);
        body.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        LinearLayout nav = Ui.hbox(this);
        Button list = new Button(this);
        list.setText("‹ Rules");
        list.setOnClickListener(x -> { sel = -1; show(); });
        nav.addView(list);
        TextView where = Ui.text(this, "Rule " + (sel + 1) + " of " + rules().length(), 13, false);
        where.setTextColor(Ui.muted(this));
        where.setPadding(Ui.dp(this, 8), 0, 0, 0);
        nav.addView(where, Ui.weight(1));
        Button up = new Button(this);
        up.setText("▲");
        up.setOnClickListener(x -> move(-1));
        up.setOnLongClickListener(x -> { moveTo(0); return true; });   // long press: to the top
        Button down = new Button(this);
        down.setText("▼");
        down.setOnClickListener(x -> move(1));
        down.setOnLongClickListener(x -> { moveTo(rules().length() - 1); return true; });   // long press: to the bottom
        nav.addView(up);
        nav.addView(down);
        v.addView(nav);

        EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setText(r.optString("name"));
        name.setHint("Rule name");
        name.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) {
                if (!s.toString().equals(r.optString("name"))) { try { r.put("name", s.toString()); } catch (Exception ignored) { } changed(); }
            }
        });
        v.addView(name);

        boolean heading = isSection(r) || isSpacer(r);
        if (!heading) {
            LinearLayout actRow = Ui.hbox(this);
            CheckBox on = new CheckBox(this);
            on.setText("On");
            on.setChecked(!r.optBoolean("off"));
            on.setOnCheckedChangeListener((cb, checked) -> setOff(r, !checked));
            actRow.addView(on);
            Spinner act = new Spinner(this);
            act.setAdapter(adapter(ACT_NAMES));
            int ai = indexOf(ACT_IDS, r.optString("act"));
            if (ai >= 0) act.setSelection(ai);
            actRow.addView(act, Ui.weight(1));
            TextView upTo = Ui.text(this, "up to", 14, false);
            EditText keep = new EditText(this);
            keep.setInputType(InputType.TYPE_CLASS_NUMBER);
            keep.setText(r.isNull("keepn") ? "1" : r.optString("keepn", "1"));
            keep.setMinWidth(Ui.dp(this, 56));
            boolean k10 = "10".equals(r.optString("act"));
            upTo.setVisibility(k10 ? View.VISIBLE : View.GONE);
            keep.setVisibility(k10 ? View.VISIBLE : View.GONE);
            actRow.addView(upTo);
            actRow.addView(keep);
            act.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    String a = ACT_IDS[position];
                    if (a.equals(r.optString("act"))) return;
                    try {
                        r.put("act", a);
                        if ("10".equals(a) && (r.isNull("keepn") || r.optString("keepn").isEmpty())) r.put("keepn", "1");
                    } catch (Exception ignored) { }
                    upTo.setVisibility("10".equals(a) ? View.VISIBLE : View.GONE);
                    keep.setVisibility("10".equals(a) ? View.VISIBLE : View.GONE);
                    changed();
                }
                @Override public void onNothingSelected(AdapterView<?> parent) { }
            });
            keep.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
                @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
                @Override public void afterTextChanged(Editable s) {
                    if (!s.toString().equals(r.optString("keepn"))) { try { r.put("keepn", s.toString()); } catch (Exception ignored) { } changed(); }
                }
            });
            v.addView(actRow);
            TextView actTip = Ui.text(this, "Chunk / Reveal: looted like Keep, then hammered / revealed when it's calm (Settings > Items in game).", 12, false);
            actTip.setTextColor(Ui.muted(this));
            v.addView(actTip);

            TextView head = Ui.text(this, "Requirements - all must match", 15, true);
            head.setTextColor(CYAN);
            head.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 4));
            v.addView(head);
            JSONArray reqs = r.optJSONArray("reqs");
            int count = 0;
            for (int i = 0; reqs != null && i < reqs.length(); i++) {
                JSONObject q = reqs.optJSONObject(i);
                if ("9999".equals(q.optString("type"))) continue;
                count++;
                v.addView(reqRow(r, i, q));
            }
            if (count == 0) {
                TextView none = Ui.text(this, "No requirements: this rule matches every item.", 13, false);
                none.setTextColor(Ui.muted(this));
                v.addView(none);
            }
            Button add = new Button(this);
            add.setText("+ Add requirement");
            add.setOnClickListener(x -> pickField(f -> addReq(r, f)));
            v.addView(add);
        } else {
            TextView h = Ui.text(this, "A heading in the list - VTank never matches it.", 13, false);
            h.setTextColor(Ui.muted(this));
            v.addView(h);
        }

        LinearLayout bottom = Ui.hbox(this);
        bottom.setPadding(0, Ui.dp(this, 16), 0, 0);
        Button copy = new Button(this);
        copy.setText("Copy rule");
        copy.setOnClickListener(x -> {
            try {
                JSONObject c = new JSONObject(r.toString());
                c.put("name", r.optString("name") + " copy");
                insertRule(sel + 1, c);
            } catch (Exception ignored) { }
        });
        Button del = new Button(this);
        del.setText("Delete rule");
        del.setTextColor(Ui.RED);
        del.setOnClickListener(x -> new AlertDialog.Builder(this).setTitle("Delete rule")
                .setMessage("Delete \"" + r.optString("name") + "\"?")
                .setPositiveButton("Delete", (d, w) -> {
                    rules().remove(sel);
                    sel = -1;
                    changed();
                    status.setText(counts());
                    show();
                }).setNegativeButton("Cancel", null).show());
        bottom.addView(copy, Ui.weight(1));
        bottom.addView(del, Ui.weight(1));
        v.addView(bottom);
    }

    private View reqRow(JSONObject rule, int index, JSONObject q) {
        LinearLayout row = Ui.hbox(this);
        row.setPadding(0, Ui.dp(this, 3), 0, Ui.dp(this, 3));
        Button x = new Button(this);
        x.setText("X");
        x.setTextColor(Color.WHITE);
        x.setBackgroundColor(Color.rgb(138, 42, 42));
        x.setMinWidth(0);
        x.setMinimumWidth(0);
        x.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40)));
        x.setOnClickListener(v -> { rule.optJSONArray("reqs").remove(index); changed(); show(); });
        row.addView(x);
        JSONObject r = q.optJSONObject("row");
        boolean ro = r == null || r.optBoolean("ro");
        TextView say = Ui.text(this, q.optString("say") + (ro ? "   (change it in game)" : ""), 14, false);
        say.setPadding(Ui.dp(this, 10), 0, 0, 0);
        if (ro) say.setTextColor(Ui.muted(this));
        row.addView(say, Ui.weight(1));
        if (!ro) {
            View.OnClickListener edit = v -> editReq(rule, index, q);
            say.setOnClickListener(edit);
            TextView pen = Ui.text(this, "✎", 18, false);
            pen.setPadding(Ui.dp(this, 8), 0, Ui.dp(this, 4), 0);
            pen.setOnClickListener(edit);
            row.addView(pen);
        }
        return row;
    }

    /** Long press on an arrow: the rule goes all the way to that end of the list. */
    private void moveTo(int to) {
        JSONArray rs = rules();
        if (sel < 0 || sel >= rs.length() || to == sel) return;
        java.util.List<Object> l = new java.util.ArrayList<>();
        for (int i = 0; i < rs.length(); i++) l.add(rs.opt(i));
        Object x = l.remove(sel);
        l.add(to, x);
        try { for (int i = 0; i < l.size(); i++) rs.put(i, l.get(i)); } catch (Exception ignored) { }
        sel = to;
        changed();
        show();
    }

    private void move(int d) {
        JSONArray rs = rules();
        int to = sel + d;
        if (to < 0 || to >= rs.length()) return;
        try {
            Object a = rs.get(sel);
            rs.put(sel, rs.get(to));
            rs.put(to, a);
        } catch (Exception ignored) { }
        sel = to;
        changed();
        show();
    }

    // ── requirements ──
    interface IntCb { void on(int f); }

    /** What should the item have? - the field list with a search box, like the in-game picker. */
    private void pickField(IntCb cb) {
        LinearLayout v = Ui.vbox(this);
        int p = Ui.dp(this, 12);
        v.setPadding(p, p, p, 0);
        EditText search = new EditText(this);
        search.setHint("armor level, biting, ring, aetheria...");
        search.setSingleLine(true);
        v.addView(search);
        ListView lv = new ListView(this);
        v.addView(lv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 420)));
        List<Integer> idx = new ArrayList<>();
        List<String> text = new ArrayList<>();
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, text);
        lv.setAdapter(ad);
        Runnable fill = () -> {
            idx.clear();
            text.clear();
            String q = search.getText().toString().trim().toLowerCase();
            for (int i = 0; i < fields.length(); i++) {
                JSONObject f = fields.optJSONObject(i);
                String hint = f.isNull("hint") ? "" : f.optString("hint");
                String t = f.optString("label") + (hint.isEmpty() ? "" : "  -  " + hint);
                if (!q.isEmpty() && !t.toLowerCase().contains(q) && !f.optString("group").toLowerCase().contains(q)) continue;
                idx.add(i);
                text.add(f.optString("group") + ": " + t);
            }
            ad.notifyDataSetChanged();
        };
        fill.run();
        AlertDialog dlg = new AlertDialog.Builder(this).setTitle("Add requirement").setView(v).setNegativeButton("Cancel", null).create();
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { fill.run(); }
        });
        lv.setOnItemClickListener((parent, view, pos, id) -> { dlg.dismiss(); cb.on(idx.get(pos)); });
        dlg.show();
    }

    private void addReq(JSONObject rule, int f) {
        io.execute(() -> {
            try {
                JSONObject q = Api.lootRow(prefs, f, null);
                main.post(() -> {
                    try {
                        JSONArray reqs = rule.optJSONArray("reqs");
                        if (reqs == null) { reqs = new JSONArray(); rule.put("reqs", reqs); }
                        int off = -1;
                        for (int i = 0; i < reqs.length(); i++) if ("9999".equals(reqs.optJSONObject(i).optString("type"))) off = i;
                        if (off >= 0) {   // keep the off switch last
                            Object sw = reqs.get(off);
                            reqs.put(off, q);
                            reqs.put(sw);
                        } else reqs.put(q);
                    } catch (Exception ignored) { }
                    changed();
                    show();
                    int at = rule.optJSONArray("reqs").length() - 1;
                    for (int i = 0; i < rule.optJSONArray("reqs").length(); i++) if (rule.optJSONArray("reqs").optJSONObject(i) == q) at = i;
                    editReq(rule, at, q);
                });
            } catch (Exception e) { main.post(() -> toast(e.getMessage())); }
        });
    }

    /** The requirement's controls, by kind (the same choices as the in-game editor). */
    private void editReq(JSONObject rule, int index, JSONObject q) {
        JSONObject row;
        try { row = new JSONObject(q.optJSONObject("row").toString()); } catch (Exception e) { return; }
        int fi = row.optInt("f", -1);
        JSONObject f = fi >= 0 ? fields.optJSONObject(fi) : null;
        String kind = f == null ? "raw" : f.optString("kind");
        JSONArray v = row.optJSONArray("v");
        if (v == null) { v = new JSONArray(); try { row.put("v", v); } catch (Exception ignored) { } }
        final JSONArray vals = v;

        LinearLayout box = Ui.vbox(this);
        int p = Ui.dp(this, 16);
        box.setPadding(p, p, p, 0);
        String tip = f == null || f.isNull("tip") ? "" : f.optString("tip");
        if (!tip.isEmpty()) {
            TextView t = Ui.text(this, tip, 12, false);
            t.setTextColor(Ui.muted(this));
            t.setPadding(0, 0, 0, Ui.dp(this, 8));
            box.addView(t);
        }
        List<Runnable> apply = new ArrayList<>();

        switch (kind) {
            case "int": case "dbl": {
                if (f.optBoolean("any")) {
                    EditText key = number(box, "Property number", row.isNull("key") ? "" : row.optString("key"));
                    apply.add(() -> { try { row.put("key", Integer.parseInt(key.getText().toString().trim())); } catch (Exception ignored) { } });
                }
                List<String> ops = new ArrayList<>();
                JSONArray fo = f.optJSONArray("ops");
                if (fo != null) for (int i = 0; i < fo.length(); i++) ops.add(fo.optString(i));
                else { ops.add(">="); ops.add("<="); if ("int".equals(kind)) { ops.add("="); ops.add("!="); } }
                opSpinner(box, row, ops, apply);
                String vk = f.isNull("vk") ? null : f.optString("vk");
                if (vk != null && spec.optJSONObject("maps").has(vk)) mapSpinner(box, vk, vals, 0, apply);
                else numberAt(box, "Value", vals, 0, apply);
                break;
            }
            case "str":
                textAt(box, "matches (regex, | = or)", vals, 0, apply);
                break;
            case "aethrating": {
                JSONArray names = spec.optJSONArray("ratingNames"), codes = spec.optJSONArray("ratingCodes"), keys = spec.optJSONArray("ratingKeys");
                String[] items = new String[names.length()];
                int cur = 0;
                for (int i = 0; i < items.length; i++) {
                    items[i] = names.optString(i) + " (" + codes.optString(i) + ")";
                    if (keys.optInt(i) == row.optInt("key")) cur = i;
                }
                Spinner s = spinner(box, items, cur);
                apply.add(() -> { try { row.put("key", keys.optInt(s.getSelectedItemPosition())); } catch (Exception ignored) { } });
                numberAt(box, "at least", vals, 0, apply);
                break;
            }
            case "oclass": {
                JSONArray oc = spec.optJSONArray("objectClasses");
                Spinner s = spinner(box, strings(oc), clamp(toInt(vals.optString(0)), oc.length()));
                apply.add(() -> put(vals, 0, String.valueOf(s.getSelectedItemPosition())));
                break;
            }
            case "spellname":
                textAt(box, "Spell name (| = or)", vals, 0, apply);
                break;
            case "cloakspell": {
                JSONArray ck = spec.optJSONArray("cloakKinds"), ce = spec.optJSONArray("cloakElements");
                Spinner k = spinner(box, strings(ck), clamp(toInt(vals.optString(0)), ck.length()));
                TextView elLab = label(box, "Element (Ring Spell)");
                Spinner e = spinner(box, strings(ce), clamp(toInt(vals.optString(1)), ce.length()));
                Runnable vis = () -> { int s = k.getSelectedItemPosition() == 6 ? View.VISIBLE : View.GONE; elLab.setVisibility(s); e.setVisibility(s); };
                vis.run();
                k.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override public void onItemSelected(AdapterView<?> a, View vw, int pos, long id) { vis.run(); }
                    @Override public void onNothingSelected(AdapterView<?> a) { }
                });
                apply.add(() -> { put(vals, 0, String.valueOf(k.getSelectedItemPosition())); put(vals, 1, String.valueOf(e.getSelectedItemPosition())); });
                break;
            }
            case "spells":
                numberAt(box, "At least this many spells", vals, 2, apply);
                textAt(box, "like (regex)", vals, 0, apply);
                textAt(box, "but not (optional)", vals, 1, apply);
                break;
            case "charlvl": {
                List<String> ops = new ArrayList<>();
                ops.add(">=");
                ops.add("<=");
                opSpinner(box, row, ops, apply);
                numberAt(box, "Level", vals, 0, apply);
                break;
            }
            case "charskill":
                mapSpinner(box, "skill", vals, 1, apply);
                numberAt(box, "at least", vals, 0, apply);
                break;
            case "charbase":
                mapSpinner(box, "skill", vals, 0, apply);
                numberAt(box, "from", vals, 1, apply);
                numberAt(box, "to", vals, 2, apply);
                break;
            case "spellcount": case "packslots": case "calc":
                numberAt(box, "at least", vals, 0, apply);
                break;
            case "t11":
                t11Controls(box, f, row, apply);
                break;
            default: {   // raw: one box per value, named by the requirement type
                String rt = f != null && !f.isNull("type") ? f.optString("type") : row.optString("rawtype");
                JSONArray rts = spec.optJSONArray("reqtypes");
                JSONArray names = null;
                for (int i = 0; rts != null && i < rts.length(); i++)
                    if (rt.equals(rts.optJSONObject(i).optString("id"))) names = rts.optJSONObject(i).optJSONArray("fields");
                for (int i = 0; i < vals.length(); i++)
                    textAt(box, names != null && i < names.length() ? names.optJSONArray(i).optString(0) : "Value " + (i + 1), vals, i, apply);
            }
        }

        String title = q.optString("label");
        new AlertDialog.Builder(this).setTitle(title.isEmpty() ? "Requirement" : title)
                .setView(wrapScroll(box))
                .setPositiveButton("OK", (d, w) -> {
                    for (Runnable r : apply) r.run();
                    io.execute(() -> {
                        try {
                            JSONObject nq = Api.lootRow(prefs, -1, row);
                            main.post(() -> {
                                try { rule.optJSONArray("reqs").put(index, nq); } catch (Exception ignored) { }
                                changed();
                                show();
                            });
                        } catch (Exception e) { main.post(() -> toast(e.getMessage())); }
                    });
                })
                .setNegativeButton("Cancel", null).show();
    }

    /** ILT text lines (rends, slayers, mods ...): the same choices as the in-game editor. */
    private void t11Controls(LinearLayout box, JSONObject f, JSONObject row, List<Runnable> apply) {
        String tid = f.optString("t11");
        JSONObject d = spec.optJSONObject("t11").optJSONObject(tid);
        JSONArray p = row.optJSONArray("p");
        if (p == null) { p = new JSONArray(); try { row.put("p", p); } catch (Exception ignored) { } }
        final JSONArray ps = p;
        JSONObject mod = null;
        if ("mod".equals(tid)) {
            int k = (int) Math.floor(num(pGet(ps, "k")));
            JSONArray mods = spec.optJSONArray("mods");
            for (int i = 0; i < mods.length(); i++) if (mods.optJSONObject(i).optInt("key") == k) mod = mods.optJSONObject(i);
            if (mod == null) mod = mods.optJSONObject(0);
        }
        boolean hasValue = mod != null ? !mod.isNull("fmt") && !mod.optString("fmt").isEmpty() : !d.optBoolean("novalue");
        if (hasValue) {
            String unit = mod != null ? ((mod.isNull("unit") ? "" : mod.optString("unit")) + "  (range " + mod.optString("band") + ")").trim()
                                      : (d.isNull("unit") ? "" : d.optString("unit"));
            EditText e = number(box, "at least" + (unit.isEmpty() ? "" : "   " + unit), pGet(ps, "v"));
            apply.add(() -> pSet(ps, "v", e.getText().toString().trim()));
        } else if (mod != null) label(box, "On or off - it has no number");
        String opt = d.isNull("opt") ? "" : d.optString("opt");
        if ("el".equals(opt)) {
            List<String> keys = new ArrayList<>(), text = new ArrayList<>();
            keys.add(""); text.add("any element");
            JSONArray r = spec.optJSONArray("rends");
            for (int i = 0; i < r.length(); i++) { keys.add(r.optString(i)); text.add(r.optString(i)); }
            choice(box, "Element", ps, "el", keys, text, apply);
        } else if ("sp".equals(opt)) {
            List<String> keys = new ArrayList<>(), text = new ArrayList<>();
            keys.add(""); text.add("any species");
            JSONArray t11 = spec.optJSONArray("slayerT11"), all = spec.optJSONArray("slayerAll");
            List<String> seen = new ArrayList<>();
            for (int i = 0; i < t11.length(); i++) { keys.add(t11.optString(i)); text.add(t11.optString(i) + "  (T11)"); seen.add(t11.optString(i)); }
            for (int i = 0; i < all.length(); i++) if (!seen.contains(all.optString(i))) { keys.add(all.optString(i)); text.add(all.optString(i)); }
            choice(box, "Slayer of", ps, "sp", keys, text, apply);
        } else if ("grade".equals(opt)) {
            String g = pGet(ps, "g");
            g = g.isEmpty() ? "C" : g.substring(0, 1).toUpperCase();   // an older "C+" setting = C
            List<String> keys = new ArrayList<>();
            JSONArray gr = spec.optJSONArray("gearGrades");
            for (int i = gr.length() - 1; i >= 0; i--) keys.add(gr.optString(i));
            JSONArray tmp = new JSONArray().put(new JSONArray().put("g").put(g));
            Spinner s = choice(box, "Gear grade at least  (F worst ... S best; B takes B-, B, B+)", tmp, "g", keys, keys, null);
            String orig = pGet(ps, "g");
            apply.add(() -> { String nv = keys.get(s.getSelectedItemPosition()); if (!nv.equals(orig.isEmpty() ? "" : orig)) pSet(ps, "g", nv); });
        } else if ("name".equals(opt)) {
            label(box, "Spell contains (empty = any)");
            EditText e = new EditText(this);
            e.setSingleLine(true);
            e.setHint("any - or Nether Arc");
            e.setText(pGet(ps, "name"));
            box.addView(e);
            apply.add(() -> pSet(ps, "name", e.getText().toString().trim()));
        }
        if ("mod".equals(tid) || "modcount".equals(tid)) {
            String w = row.isNull("where") || row.optString("where").isEmpty() ? d.optString("where") : row.optString("where");
            List<String> keys = new ArrayList<>(), text = new ArrayList<>();
            keys.add("14"); text.add("Armor, jewelry, shields");
            keys.add("16"); text.add("Weapons");
            label(box, "On");
            Spinner s = spinner(box, text.toArray(new String[0]), "16".equals(w) ? 1 : 0);
            apply.add(() -> { try { row.put("where", keys.get(s.getSelectedItemPosition())); } catch (Exception ignored) { } });
        }
    }

    /** A drop-down for one T11 setting (keys = what's saved, text = what's shown); null apply = the caller saves it. */
    private Spinner choice(LinearLayout box, String lab, JSONArray ps, String key, List<String> keys, List<String> text, List<Runnable> apply) {
        label(box, lab);
        String cur = pGet(ps, key);
        int sel = keys.indexOf(cur);
        List<String> k2 = new ArrayList<>(keys), t2 = new ArrayList<>(text);
        if (sel < 0) { k2.add(cur); t2.add(cur); sel = k2.size() - 1; }
        Spinner s = spinner(box, t2.toArray(new String[0]), sel);
        if (apply != null) apply.add(() -> pSet(ps, key, k2.get(s.getSelectedItemPosition())));
        return s;
    }

    /**
     * Drop-down contents drawn with explicit colours (the box and the open list), so the picked value is always
     * readable - the stock spinner rows took the dialog's theme and came out invisible on some phones.
     */
    private ArrayAdapter<String> adapter(String[] items) {
        boolean dark = Ui.dark(this);
        int fg = dark ? Color.WHITE : Color.BLACK;
        int bg = dark ? Color.rgb(48, 52, 58) : Color.rgb(236, 238, 241);
        int pad = Ui.dp(this, 10);
        return new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            private TextView style(View v, boolean drop) {
                TextView t = (TextView) v;
                t.setTextColor(fg);
                t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 15);
                t.setPadding(pad, drop ? pad : Ui.dp(LootEditorActivity.this, 8), pad, drop ? pad : Ui.dp(LootEditorActivity.this, 8));
                t.setBackgroundColor(bg);
                t.setSingleLine(!drop);
                return t;
            }
            @Override public View getView(int position, View convert, ViewGroup parent) {
                return style(super.getView(position, convert, parent), false);
            }
            @Override public View getDropDownView(int position, View convert, ViewGroup parent) {
                View v = style(super.getDropDownView(position, convert, parent), true);
                if (!isEnabled(position)) ((TextView) v).setTextColor(Ui.GREY);
                return v;
            }
        };
    }

    private static String pGet(JSONArray p, String k) {
        for (int i = 0; p != null && i < p.length(); i++) {
            JSONArray kv = p.optJSONArray(i);
            if (kv != null && k.equals(kv.optString(0))) return kv.optString(1, "");
        }
        return "";
    }

    /** Replaces the setting in place (keeps the order) or adds it - like the in-game editor. */
    private static void pSet(JSONArray p, String k, String v) {
        try {
            for (int i = 0; i < p.length(); i++) {
                JSONArray kv = p.optJSONArray(i);
                if (kv != null && k.equals(kv.optString(0))) { p.put(i, new JSONArray().put(k).put(v)); return; }
            }
            p.put(new JSONArray().put(k).put(v));
        } catch (Exception ignored) { }
    }

    private static double num(String s) { try { return Double.parseDouble(s.trim()); } catch (Exception e) { return 0; } }

    // ── small helpers for the requirement dialog ──
    private View wrapScroll(View v) {
        ScrollView s = new ScrollView(this);
        s.addView(v);
        return s;
    }

    private TextView label(LinearLayout box, String s) {
        TextView t = Ui.text(this, s, 13, false);
        t.setTextColor(Ui.muted(this));
        t.setPadding(0, Ui.dp(this, 6), 0, 0);
        box.addView(t);
        return t;
    }

    private EditText number(LinearLayout box, String lab, String val) {
        label(box, lab);
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        e.setText(val);
        box.addView(e);
        return e;
    }

    private void numberAt(LinearLayout box, String lab, JSONArray vals, int i, List<Runnable> apply) {
        EditText e = number(box, lab, vals.optString(i, ""));
        apply.add(() -> put(vals, i, e.getText().toString().trim()));
    }

    private void textAt(LinearLayout box, String lab, JSONArray vals, int i, List<Runnable> apply) {
        label(box, lab);
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setText(vals.optString(i, ""));
        box.addView(e);
        apply.add(() -> put(vals, i, e.getText().toString()));
    }

    private Spinner spinner(LinearLayout box, String[] items, int sel) {
        Spinner s = new Spinner(this);
        s.setAdapter(adapter(items));
        if (sel >= 0 && sel < items.length) s.setSelection(sel);
        box.addView(s);
        return s;
    }

    private void opSpinner(LinearLayout box, JSONObject row, List<String> ops, List<Runnable> apply) {
        JSONObject names = spec.optJSONObject("opNames");
        String[] items = new String[ops.size()];
        for (int i = 0; i < items.length; i++) items[i] = names.optString(ops.get(i), ops.get(i));
        int cur = Math.max(0, ops.indexOf(row.optString("op")));
        Spinner s = spinner(box, items, cur);
        apply.add(() -> { try { row.put("op", ops.get(s.getSelectedItemPosition())); } catch (Exception ignored) { } });
    }

    private void mapSpinner(LinearLayout box, String vk, JSONArray vals, int i, List<Runnable> apply) {
        JSONArray m = spec.optJSONObject("maps").optJSONArray(vk);
        String cur = vals.optString(i, "");
        List<String> keys = new ArrayList<>(), text = new ArrayList<>();
        int sel = -1;
        for (int j = 0; j < m.length(); j++) {
            JSONArray e = m.optJSONArray(j);
            keys.add(e.optString(0));
            text.add(e.optString(1));
            if (e.optString(0).equals(cur)) sel = j;
        }
        if (sel < 0) { keys.add(cur); text.add(cur); sel = keys.size() - 1; }
        Spinner s = spinner(box, text.toArray(new String[0]), sel);
        apply.add(() -> put(vals, i, keys.get(s.getSelectedItemPosition())));
    }

    private static void put(JSONArray a, int i, String s) {
        try {
            while (a.length() <= i) a.put("");
            a.put(i, s);
        } catch (Exception ignored) { }
    }

    private static String[] strings(JSONArray a) {
        String[] s = new String[a.length()];
        for (int i = 0; i < s.length; i++) s[i] = a.optString(i);
        return s;
    }

    private static int toInt(String s) { try { return Integer.parseInt(s.trim()); } catch (Exception e) { return 0; } }
    private static int clamp(int v, int n) { return Math.max(0, Math.min(v, n - 1)); }

    private static int indexOf(String[] a, String s) {
        for (int i = 0; i < a.length; i++) if (a[i].equals(s)) return i;
        return -1;
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        io.shutdownNow();
    }
}
