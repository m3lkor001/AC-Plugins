package com.melk.tankremote;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Where the PC is, the app key, how often things update, and the alert options. */
public class SettingsActivity extends Activity {
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private Prefs prefs;
    private EditText host, port, key, poll, idle, interval;
    private Switch alerts;
    private TextView result, buildInfo;
    private Button rollback;
    private int loadedInterval = -1;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        if (getActionBar() != null) getActionBar().setDisplayHomeAsUpEnabled(true);   // back arrow in the title
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = Ui.vbox(this);
        int p = Ui.dp(this, 16);
        root.setPadding(p, p, p, p);

        // which app build this is
        String ver = "?";
        try {
            android.content.pm.PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            ver = pi.versionName + "  (build " + pi.getLongVersionCode() + ")";
        } catch (Exception ignored) { }
        android.widget.TextView vt = Ui.text(this, "MelkTank Remote " + ver, 14, true);
        vt.setTextColor(Ui.muted(this));
        vt.setPadding(0, 0, 0, Ui.dp(this, 8));
        root.addView(vt);

        host = field(root, "PC address (its Tailscale IP, e.g. 100.x.y.z, or name)", prefs.host(), InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        port = field(root, "Port", String.valueOf(prefs.port()), InputType.TYPE_CLASS_NUMBER);
        key = field(root, "App key (shown by setup.sh and in the launcher's Settings)", prefs.key(), InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        interval = field(root, "MelkTank writes an update every ... seconds (15-600)", "", InputType.TYPE_CLASS_NUMBER);
        interval.setHint("loading from the PC...");

        alerts = new Switch(this);
        alerts.setText("Alerts while the app is closed (offline, died, idle)");
        alerts.setChecked(prefs.alerts());
        alerts.setTextSize(15);
        alerts.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 4));
        root.addView(alerts);
        poll = field(root, "Check the PC every ... seconds (30 or more)", String.valueOf(prefs.pollSeconds()), InputType.TYPE_CLASS_NUMBER);
        idle = field(root, "Idle alert after ... minutes with no attack", String.valueOf(prefs.idleMinutes()), InputType.TYPE_CLASS_NUMBER);

        TextView nh = Ui.text(this, "Notifications", 16, true);
        nh.setPadding(0, Ui.dp(this, 18), 0, Ui.dp(this, 2));
        root.addView(nh);
        alertSwitch(root, "pc", "PC can't be reached / reachable again");
        alertSwitch(root, "offline", "A character went offline");
        alertSwitch(root, "death", "A character died");
        alertSwitch(root, "idle", "A character is idle (no attacks)");
        alertSwitch(root, "tell", "A player sends a tell (shows the message)");
        alertSwitch(root, "note", "The PC needs you (e.g. an approval waiting on its screen)");
        alertSwitch(root, "enl", "Auto enlighten finished or stopped");
        alertSwitch(root, "stuck", "A login got stuck at the character screen");
        Switch watch = new Switch(this);
        watch.setText("Always-on \"watching\" notification");
        watch.setChecked(prefs.showWatching());
        watch.setTextSize(15);
        watch.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 2));
        watch.setOnCheckedChangeListener((b2, on) -> {
            prefs.showWatching(on);
            MonitorService.stop(this);
            MonitorService.start(this);
        });
        root.addView(watch);
        TextView wh = Ui.text(this, "Off: only the notifications above show up, when they happen. The checking still runs "
                + "in the background (Android lists it under active apps).", 12, false);
        wh.setTextColor(Ui.muted(this));
        root.addView(wh);

        Button save = new Button(this);
        save.setText("Save and test");
        save.setOnClickListener(v -> save());
        root.addView(save);

        Button battery = new Button(this);
        battery.setText("Let alerts run in the background");
        battery.setOnClickListener(v -> askBattery());
        root.addView(battery);

        result = Ui.text(this, "", 14, false);
        result.setPadding(0, Ui.dp(this, 10), 0, 0);
        root.addView(result);

        TextView mh = Ui.text(this, "MelkTank build", 16, true);
        mh.setPadding(0, Ui.dp(this, 18), 0, Ui.dp(this, 2));
        root.addView(mh);
        buildInfo = Ui.text(this, "loading from the PC...", 14, false);
        buildInfo.setTextColor(Ui.muted(this));
        root.addView(buildInfo);
        rollback = new Button(this);
        rollback.setText("Roll back to the previous build");
        rollback.setEnabled(false);
        rollback.setOnClickListener(v -> askRollback());
        root.addView(rollback);
        TextView rh = Ui.text(this, "Swaps the running MelkTank build with the previous one. The game picks it up in a few "
                + "seconds on every character - no relog. Tap again to undo.", 12, false);
        rh.setTextColor(Ui.muted(this));
        root.addView(rh);

        TextView help = Ui.text(this,
                "Needs Tailscale on this phone and on the PC, signed in to the same account. "
                        + "Samsung phones can stop background apps: tap the button above and allow it, "
                        + "and in the phone's battery settings set MelkTank Remote to Unrestricted.", 13, false);
        help.setTextColor(Ui.muted(this));
        help.setPadding(0, Ui.dp(this, 12), 0, 0);
        root.addView(help);

        scroll.addView(root);
        setContentView(PullRefresh.wrap(this, scroll, this::pullRefresh));
        if (prefs.configured()) { loadInterval(); loadBuilds(); }
    }

    @Override
    public boolean onOptionsItemSelected(android.view.MenuItem item) {
        if (item.getItemId() == android.R.id.home) { finish(); return true; }
        return super.onOptionsItemSelected(item);
    }

    private void alertSwitch(LinearLayout root, String kind, String label) {
        Switch sw = new Switch(this);
        sw.setText(label);
        sw.setChecked(prefs.alertOn(kind));
        sw.setTextSize(15);
        sw.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 2));
        sw.setOnCheckedChangeListener((b2, on) -> prefs.alertOn(kind, on));
        root.addView(sw);
    }

    private EditText field(LinearLayout root, String label, String value, int type) {
        TextView l = Ui.text(this, label, 13, false);
        l.setTextColor(Ui.muted(this));
        l.setPadding(0, Ui.dp(this, 10), 0, 0);
        root.addView(l);
        EditText e = new EditText(this);
        e.setText(value);
        e.setInputType(type);
        e.setSingleLine(true);
        root.addView(e);
        return e;
    }

    private static int num(EditText e, int def, int min, int max) {
        try { return Math.max(min, Math.min(max, Integer.parseInt(e.getText().toString().trim()))); } catch (Exception ex) { return def; }
    }

    /** Pull down: load the page again. */
    private void pullRefresh(PullRefresh pr) {
        loadInterval(); loadBuilds();
        main.postDelayed(pr::done, 1500);
    }

    private void loadInterval() {
        io.execute(() -> {
            try {
                JSONObject st = Api.status(prefs);
                int iv = st.optInt("interval", 45);
                main.post(() -> { loadedInterval = iv; interval.setText(String.valueOf(iv)); });
            } catch (Exception e) {
                main.post(() -> interval.setHint("couldn't reach the PC"));
            }
        });
    }

    private void loadBuilds() {
        io.execute(() -> {
            try { JSONObject r = Api.builds(prefs); main.post(() -> showBuilds(r)); }
            catch (Exception e) { main.post(() -> buildInfo.setText(e.getMessage())); }
        });
    }

    private void showBuilds(JSONObject r) {
        JSONObject cur = r.optJSONObject("current"), prev = r.optJSONObject("previous");
        if (cur == null && prev == null) {
            buildInfo.setText("No MelkTankCore.dll on the PC (an old one-file MelkTank?) - nothing to roll back.");
            rollback.setEnabled(false);
            return;
        }
        buildInfo.setText("Running: build of " + (cur != null ? cur.optString("time") : "-")
                + "\nPrevious: " + (prev != null ? "build of " + prev.optString("time") : "none yet"));
        rollback.setEnabled(prev != null);
    }

    private void askRollback() {
        new android.app.AlertDialog.Builder(this)
                .setTitle("Roll back MelkTank?")
                .setMessage("Both characters switch to the previous build in a few seconds (session stats start over, like a relog).")
                .setPositiveButton("Roll back", (d, w) -> {
                    rollback.setEnabled(false);
                    buildInfo.setText("Rolling back...");
                    io.execute(() -> {
                        try {
                            JSONObject r = Api.rollback(prefs);
                            main.post(() -> {
                                Toast.makeText(this, r.optString("message", "Done."), Toast.LENGTH_LONG).show();
                                JSONObject b2 = r.optJSONObject("builds");
                                if (b2 != null) showBuilds(b2); else loadBuilds();
                            });
                        } catch (Exception e) {
                            main.post(() -> { Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show(); loadBuilds(); });
                        }
                    });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void save() {
        prefs.save(host.getText().toString(), num(port, 8765, 1, 65535), key.getText().toString(),
                alerts.isChecked(), num(poll, 60, 30, 3600), num(idle, 5, 1, 240));
        int iv = num(interval, -1, 15, 600);
        result.setText("Testing...");
        io.execute(() -> {
            String msg;
            try {
                JSONObject st = Api.status(prefs);
                msg = "Connected. " + MonitorService.summary(st) + ".";
                if (iv > 0 && iv != loadedInterval) {
                    JSONObject r = Api.interval(prefs, iv);
                    loadedInterval = r.optInt("interval", iv);
                    msg += "\nMelkTank will update every " + loadedInterval + "s (from its next update).";
                }
            } catch (Exception e) {
                msg = e.getMessage();
            }
            String m = msg;
            main.post(() -> {
                result.setText(m);
                MonitorService.stop(this);
                MonitorService.start(this);
                Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
            });
        });
    }

    @SuppressLint("BatteryLife")
    private void askBattery() {
        PowerManager pm = getSystemService(PowerManager.class);
        if (pm.isIgnoringBatteryOptimizations(getPackageName())) {
            Toast.makeText(this, "Already allowed.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        }
    }
}
