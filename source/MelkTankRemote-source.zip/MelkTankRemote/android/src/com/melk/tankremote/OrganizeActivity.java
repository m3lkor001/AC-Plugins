package com.melk.tankremote;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * A remote for MelkTank's Items > Organize tab: the "organize automatically" switch, Run now, and the rule list
 * (on/off, move up / down, delete, add) with the same kinds, packs, positions and sort choices. Every change is sent
 * straight away; the page reloads from what MelkTank writes (organize_[account].json).
 */
public class OrganizeActivity extends Activity {
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private Prefs prefs;
    private String account, title;
    private LinearLayout rulesBox, form;
    private TextView status;
    private Switch auto, merge;
    private boolean loading;
    private JSONObject data;
    private final List<JSONObject> rules = new ArrayList<>();
    private final List<JSONObject> subs = new ArrayList<>();
    private int editRule = -1, editSub = -1;          // the rule / sub-group being edited (-1: adding a new one)
    private Button addBtn, cancelBtn, subAddBtn, subCancelBtn;
    private LinearLayout subsCard, subsBox;
    private Spinner subType;
    private EditText subText, subName;

    // the add form
    private Spinner kind, type, pack, pos, sort, then, orderType;
    private EditText name, order;
    private View nameRow, typeRow, posRow, sortRow, thenRow, orderRow;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        account = getIntent().getStringExtra("account");
        title = getIntent().getStringExtra("title");
        if (title == null) title = account;
        setTitle("Organize packs - " + title);
        if (getActionBar() != null) getActionBar().setDisplayHomeAsUpEnabled(true);   // back arrow

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = Ui.vbox(this);
        int p = Ui.dp(this, 14);
        root.setPadding(p, p, p, p);

        LinearLayout top = Ui.card(this);
        LinearLayout row = Ui.hbox(this);
        auto = new Switch(this);
        auto.setText("Organize automatically");
        auto.setOnCheckedChangeListener((v, on) -> { if (!loading) send(on ? "on" : "off", null); });
        row.addView(auto, Ui.weight(1));
        Button run = new Button(this);
        run.setText("Run now");
        run.setOnClickListener(v -> send("run", null));
        row.addView(run);
        top.addView(row);
        merge = new Switch(this);
        merge.setText("Merge partial stacks");
        merge.setOnCheckedChangeListener((v, on) -> { if (!loading) send(on ? "mergeon" : "mergeoff", null); });
        top.addView(merge);
        status = Ui.text(this, "Loading...", 13, false);
        status.setTextColor(Ui.muted(this));
        top.addView(status);
        TextView hint = Ui.text(this, "Moves happen one at a time, only when nothing else is going on. The top of the list wins "
                + "when an item matches more than one rule. Packs are found by their name.", 12, false);
        hint.setTextColor(Ui.muted(this));
        top.addView(hint);
        root.addView(top);

        LinearLayout rc = Ui.card(this);
        rc.addView(Ui.text(this, "Rules", 16, true));
        rulesBox = Ui.vbox(this);
        rc.addView(rulesBox);
        root.addView(rc, spaced());

        form = Ui.card(this);
        form.addView(Ui.text(this, "Add a rule", 16, true));
        root.addView(form, spaced());

        subsCard = Ui.card(this);
        subsCard.addView(Ui.text(this, "Your sub-groups", 16, true));
        TextView sh = Ui.text(this, "Items of that type with that text in the name sort together under your name for them, "
                + "and the name shows in the type lists for type orders and move rules. Yours win over the built-in ones.", 12, false);
        sh.setTextColor(Ui.muted(this));
        subsCard.addView(sh);
        subsBox = Ui.vbox(this);
        subsCard.addView(subsBox);
        root.addView(subsCard, spaced());

        scroll.addView(root);
        setContentView(PullRefresh.wrap(this, scroll, this::pullRefresh));
        load();
    }

    private LinearLayout.LayoutParams spaced() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 12);
        return lp;
    }

    @Override
    public boolean onOptionsItemSelected(android.view.MenuItem item) {
        if (item.getItemId() == android.R.id.home) { finish(); return true; }
        return super.onOptionsItemSelected(item);
    }

    private void pullRefresh(PullRefresh pr) {
        io.execute(() -> {
            try { if (account != null) Api.refresh(prefs, account); } catch (Exception ignored) { }
            main.postDelayed(() -> { load(); main.postDelayed(pr::done, 600); }, 1500);
        });
    }

    private void load() {
        io.execute(() -> {
            try {
                JSONObject r = Api.organize(prefs, account);
                main.post(() -> show(r));
            } catch (Exception e) {
                String m = e.getMessage();
                main.post(() -> status.setText(m));
            }
        });
    }

    private void show(JSONObject r) {
        boolean first = data == null;
        data = r;
        loading = true;
        auto.setChecked(r.optBoolean("auto"));
        merge.setChecked(r.optBoolean("merge", true));
        loading = false;
        String st = r.optString("status", "");
        status.setText((r.optBoolean("running") ? "Running now - " : "") + (st.isEmpty() ? (r.optBoolean("auto") ? "on" : "off") : st));
        rules.clear();
        JSONArray a = r.optJSONArray("rules");
        for (int i = 0; a != null && i < a.length(); i++) rules.add(a.optJSONObject(i));
        drawRules();
        subs.clear();
        JSONArray sa = r.optJSONArray("subs");
        for (int i = 0; sa != null && i < sa.length(); i++) subs.add(sa.optJSONObject(i));
        drawSubs();
        if (first) { buildForm(); buildSubForm(); } else { refreshPacks(); refreshTypes(); }
    }

    private void refreshTypes() {
        if (type == null) return;
        for (Spinner sp : new Spinner[] { type, orderType }) {
            Object sel = sp.getSelectedItem();
            List<String> t = list("types");
            sp.setAdapter(adapter(t));
            int i = sel == null ? -1 : t.indexOf(sel.toString());
            if (i >= 0) sp.setSelection(i);
        }
    }

    // ── your sub-groups ──
    private void drawSubs() {
        subsBox.removeAllViews();
        if (subs.isEmpty()) { TextView t = Ui.text(this, "None yet.", 14, false); t.setTextColor(Ui.muted(this)); subsBox.addView(t); return; }
        for (int i = 0; i < subs.size(); i++) {
            JSONObject x = subs.get(i);
            final int idx = i;
            LinearLayout row = Ui.hbox(this);
            row.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 4));
            row.addView(Ui.text(this, x.optString("name") + " (" + x.optString("type") + ") - name has \"" + x.optString("text") + "\"", 14, false), Ui.weight(1));
            row.addView(small("✎", true, v -> editSub(idx)));
            Button su = small("▲", i > 0, v -> { JSONObject t = subs.get(idx); subs.set(idx, subs.get(idx - 1)); subs.set(idx - 1, t);
                if (editSub == idx) editSub = idx - 1; else if (editSub == idx - 1) editSub = idx; drawSubs(); sendSubs(); });
            su.setOnLongClickListener(v -> {   // long press: to the top
                JSONObject es = editSub >= 0 && editSub < subs.size() ? subs.get(editSub) : null;
                subs.add(0, subs.remove(idx));
                if (es != null) editSub = subs.indexOf(es);
                drawSubs(); sendSubs(); return true; });
            row.addView(su);
            row.addView(small("✕", true, v -> { subs.remove(idx); if (editSub == idx) endEditSub(); else if (editSub > idx) editSub--; drawSubs(); sendSubs(); }));
            subsBox.addView(row);
        }
    }

    private void buildSubForm() {
        TextView h = Ui.text(this, "Add a sub-group", 14, true);
        h.setPadding(0, Ui.dp(this, 10), 0, 0);
        subsCard.addView(h);
        List<String> st = list("subTypes");
        subType = spinner(st);
        int mi = st.indexOf("Misc");
        if (mi >= 0) subType.setSelection(mi);
        subsCard.addView(labeled("Item type", subType));
        subText = new EditText(this);
        subText.setHint("part of the name, e.g. Bag of");
        subText.setSingleLine(true);
        subsCard.addView(labeled("Name has", subText));
        subName = new EditText(this);
        subName.setHint("sub-group name, e.g. Bags");
        subName.setSingleLine(true);
        subsCard.addView(labeled("Call it", subName));
        LinearLayout btns = Ui.hbox(this);
        subAddBtn = new Button(this);
        subAddBtn.setText("Add sub-group");
        subAddBtn.setOnClickListener(v -> {
            String t = subText.getText().toString().trim(), n = subName.getText().toString().trim();
            if (t.isEmpty() || n.isEmpty()) { toast("Fill in the name part and what to call it."); return; }
            JSONObject x = new JSONObject();
            put(x, "type", String.valueOf(subType.getSelectedItem()));
            put(x, "text", t);
            put(x, "name", n);
            if (editSub >= 0 && editSub < subs.size()) { subs.set(editSub, x); endEditSub(); }
            else subs.add(x);
            drawSubs();
            subText.setText(""); subName.setText("");
            sendSubs();
        });
        btns.addView(subAddBtn, Ui.weight(1));
        subCancelBtn = new Button(this);
        subCancelBtn.setText("Cancel");
        subCancelBtn.setVisibility(View.GONE);
        subCancelBtn.setOnClickListener(v -> { endEditSub(); subText.setText(""); subName.setText(""); drawSubs(); });
        btns.addView(subCancelBtn);
        subsCard.addView(btns);
    }

    /** ✎ on a sub-group: into the form, and Add becomes Update. */
    private void editSub(int idx) {
        if (idx < 0 || idx >= subs.size() || subType == null) return;
        JSONObject x = subs.get(idx);
        editSub = idx;
        int ti = indexIgnoreCase(list("subTypes"), x.optString("type"));
        if (ti >= 0) subType.setSelection(ti);
        subText.setText(x.optString("text"));
        subName.setText(x.optString("name"));
        subAddBtn.setText("Update sub-group");
        subCancelBtn.setVisibility(View.VISIBLE);
        drawSubs();
        subsCard.post(() -> subsCard.requestRectangleOnScreen(new android.graphics.Rect(0, 0, subsCard.getWidth(), subsCard.getHeight()), false));
    }

    private void endEditSub() {
        editSub = -1;
        if (subAddBtn != null) subAddBtn.setText("Add sub-group");
        if (subCancelBtn != null) subCancelBtn.setVisibility(View.GONE);
    }

    private void sendSubs() {
        StringBuilder sb = new StringBuilder();
        for (JSONObject x : subs) {
            if (sb.length() > 0) sb.append(';');
            sb.append(esc(x.optString("type"))).append('|').append(esc(x.optString("text"))).append('|').append(esc(x.optString("name")));
        }
        send("subs", sb.toString());
    }

    private void drawRules() {
        rulesBox.removeAllViews();
        if (rules.isEmpty()) { TextView t = Ui.text(this, "No rules yet.", 14, false); t.setTextColor(Ui.muted(this)); rulesBox.addView(t); return; }
        List<String> packs = list("packs");
        for (int i = 0; i < rules.size(); i++) {
            JSONObject r = rules.get(i);
            final int idx = i;
            LinearLayout row = Ui.hbox(this);
            row.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 4));
            CheckBox on = new CheckBox(this);
            on.setChecked(r.optBoolean("on", true));
            on.setOnCheckedChangeListener((v, c) -> { put(rules.get(idx), "on", c); sendRules(); });
            row.addView(on);
            boolean missing = !containsIgnoreCase(packs, r.optString("pack"));
            TextView t = Ui.text(this, (i + 1) + ". " + r.optString("desc") + (missing ? "  (no pack by that name now)" : ""), 14, false);
            if (!r.optBoolean("on", true)) t.setTextColor(Ui.muted(this));
            else if (missing) t.setTextColor(Ui.AMBER);
            row.addView(t, Ui.weight(1));
            if (idx == editRule) t.setTextColor(0xFF8FE08F);
            row.addView(small("✎", true, v -> editRule(idx)));
            Button ru = small("▲", i > 0, v -> { swap(idx, idx - 1); });
            ru.setOnLongClickListener(v -> { moveRuleTo(idx, 0); return true; });   // long press: to the top
            row.addView(ru);
            Button rd = small("▼", i < rules.size() - 1, v -> { swap(idx, idx + 1); });
            rd.setOnLongClickListener(v -> { moveRuleTo(idx, rules.size() - 1); return true; });   // ... to the bottom
            row.addView(rd);
            row.addView(small("✕", true, v -> { rules.remove(idx); if (editRule == idx) endEditRule(); else if (editRule > idx) editRule--; drawRules(); sendRules(); }));
            rulesBox.addView(row);
        }
    }

    private Button small(String s, boolean enabled, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(Ui.dp(this, 10), 0, Ui.dp(this, 10), 0);
        b.setEnabled(enabled);
        b.setOnClickListener(l);
        return b;
    }

    private void moveRuleTo(int from, int to) {
        if (from == to || from < 0 || from >= rules.size()) return;
        JSONObject er = editRule >= 0 && editRule < rules.size() ? rules.get(editRule) : null;
        rules.add(to, rules.remove(from));
        if (er != null) editRule = rules.indexOf(er);
        drawRules();
        sendRules();
    }

    private void swap(int a, int b) {
        JSONObject t = rules.get(a); rules.set(a, rules.get(b)); rules.set(b, t);
        if (editRule == a) editRule = b; else if (editRule == b) editRule = a;
        drawRules();
        sendRules();
    }

    // ── the add form ──
    private void buildForm() {
        kind = spinner(list("kinds"));
        form.addView(labeled("Kind", kind));
        name = new EditText(this);
        name.setHint("name text");
        name.setSingleLine(true);
        nameRow = labeled("Name", name);
        form.addView(nameRow);
        type = spinner(list("types"));
        typeRow = labeled("Item type", type);
        form.addView(typeRow);
        pack = spinner(list("packs"));
        form.addView(labeled("Pack", pack));
        pos = spinner(list("positions"));
        posRow = labeled("Where", pos);
        form.addView(posRow);
        sort = spinner(list("sortLabels"));
        sortRow = labeled("Sort by", sort);
        form.addView(sortRow);
        then = spinner(list("thenLabels"));
        thenRow = labeled("Then by", then);
        form.addView(thenRow);
        LinearLayout ob = Ui.vbox(this);
        order = new EditText(this);
        order.setHint("type order, e.g. WandStaffOrb, Armor, Jewelry, Misc");
        ob.addView(order);
        LinearLayout or = Ui.hbox(this);
        orderType = spinner(list("types"));
        or.addView(orderType, Ui.weight(1));
        Button addT = new Button(this);
        addT.setText("Add to order");
        addT.setOnClickListener(v -> {
            String cur = order.getText().toString().trim();
            while (cur.endsWith(",")) cur = cur.substring(0, cur.length() - 1).trim();
            order.setText((cur.isEmpty() ? "" : cur + ", ") + orderType.getSelectedItem());
        });
        or.addView(addT);
        ob.addView(or);
        TextView oh = Ui.text(this, "Item types, groups and sub-groups - anything not named comes after, or wherever you put \"Everything else\".", 12, false);
        oh.setTextColor(Ui.muted(this));
        ob.addView(oh);
        orderRow = ob;
        form.addView(orderRow);
        LinearLayout btns = Ui.hbox(this);
        addBtn = new Button(this);
        addBtn.setText("Add (at the bottom of the list)");
        addBtn.setOnClickListener(v -> addRule());
        btns.addView(addBtn, Ui.weight(1));
        cancelBtn = new Button(this);
        cancelBtn.setText("Cancel");
        cancelBtn.setVisibility(View.GONE);
        cancelBtn.setOnClickListener(v -> { endEditRule(); drawRules(); });
        btns.addView(cancelBtn);
        form.addView(btns);
        AdapterView.OnItemSelectedListener vis = new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> p, View v, int i, long id) { formVisibility(); }
            public void onNothingSelected(AdapterView<?> p) { }
        };
        kind.setOnItemSelectedListener(vis);
        sort.setOnItemSelectedListener(vis);
        formVisibility();
    }

    private void refreshPacks() {
        if (pack == null) return;
        Object sel = pack.getSelectedItem();
        List<String> packs = list("packs");
        pack.setAdapter(adapter(packs));
        int i = sel == null ? -1 : packs.indexOf(sel.toString());
        if (i >= 0) pack.setSelection(i);
    }

    private void formVisibility() {
        int k = kind.getSelectedItemPosition();
        nameRow.setVisibility(k == 0 || k == 1 ? View.VISIBLE : View.GONE);
        typeRow.setVisibility(k == 2 ? View.VISIBLE : View.GONE);
        posRow.setVisibility(k == 4 ? View.GONE : View.VISIBLE);
        sortRow.setVisibility(k == 4 ? View.VISIBLE : View.GONE);
        boolean ord = k == 4 && "order".equals(item("sortModes", sort.getSelectedItemPosition()));
        orderRow.setVisibility(ord ? View.VISIBLE : View.GONE);
        boolean th = k == 4 && !"name".equals(item("sortModes", sort.getSelectedItemPosition())) && !list("thenModes").isEmpty();
        thenRow.setVisibility(th ? View.VISIBLE : View.GONE);
    }

    private void addRule() {
        int k = kind.getSelectedItemPosition();
        String text = "";
        if (k == 0 || k == 1) {
            text = name.getText().toString().trim();
            if (text.isEmpty()) { toast("Type the name text first."); return; }
        } else if (k == 2) text = String.valueOf(type.getSelectedItem());
        else if (k == 4) {
            String m = item("sortModes", sort.getSelectedItemPosition());
            text = "order".equals(m) ? "order:" + order.getText().toString().trim() : m;
            String t = item("thenModes", then.getSelectedItemPosition());
            if (!"name".equals(m) && t != null && !t.isEmpty() && !"name".equals(t)) text += ";then=" + t;
        }
        JSONObject r = new JSONObject();
        put(r, "on", true);
        put(r, "kind", k);
        put(r, "text", text);
        put(r, "pack", String.valueOf(pack.getSelectedItem()));
        put(r, "pos", k == 4 ? 0 : pos.getSelectedItemPosition());
        if (editRule >= 0 && editRule < rules.size()) {
            put(r, "on", rules.get(editRule).optBoolean("on", true));
            put(r, "desc", "(updating...)");
            rules.set(editRule, r);
            endEditRule();
        } else {
            put(r, "desc", "(adding...)");
            rules.add(r);
        }
        drawRules();
        name.setText("");
        sendRules();
    }

    /** ✎ on a rule: its settings go into the form, and Add becomes Update. */
    private void editRule(int idx) {
        if (idx < 0 || idx >= rules.size()) return;
        JSONObject r = rules.get(idx);
        editRule = idx;
        int k = r.optInt("kind");
        String text = r.optString("text");
        kind.setSelection(k);
        name.setText(k == 0 || k == 1 ? text : "");
        if (k == 2) { int ti = indexIgnoreCase(list("types"), text); if (ti >= 0) type.setSelection(ti); }
        int pi = indexIgnoreCase(list("packs"), r.optString("pack"));
        if (pi >= 0) pack.setSelection(pi);
        if (k != 4) pos.setSelection(Math.max(0, r.optInt("pos")));
        else {
            String base = text, th = "name";
            int ti = text.toLowerCase().indexOf(";then=");
            if (ti >= 0) { base = text.substring(0, ti); th = text.substring(ti + 6).trim(); }
            if (base.toLowerCase().startsWith("order:")) {
                int si = list("sortModes").indexOf("order"); if (si >= 0) sort.setSelection(si);
                order.setText(base.substring(6).trim());
            } else {
                int si = list("sortModes").indexOf(base.trim().toLowerCase()); if (si >= 0) sort.setSelection(si);
            }
            int hi = list("thenModes").indexOf(th.toLowerCase()); then.setSelection(Math.max(0, hi));
        }
        addBtn.setText("Update rule " + (idx + 1));
        cancelBtn.setVisibility(View.VISIBLE);
        drawRules();
        form.post(() -> form.requestRectangleOnScreen(new android.graphics.Rect(0, 0, form.getWidth(), form.getHeight()), false));
        formVisibility();
    }

    private void endEditRule() {
        editRule = -1;
        if (addBtn != null) addBtn.setText("Add (at the bottom of the list)");
        if (cancelBtn != null) cancelBtn.setVisibility(View.GONE);
    }

    private static int indexIgnoreCase(List<String> l, String s) { for (int i = 0; i < l.size(); i++) if (l.get(i).equalsIgnoreCase(s)) return i; return -1; }

    // ── sending ──
    private void sendRules() {
        StringBuilder sb = new StringBuilder();
        for (JSONObject r : rules) {
            if (sb.length() > 0) sb.append(';');
            sb.append(r.optBoolean("on", true) ? "1" : "0").append('|').append(r.optInt("kind")).append('|')
              .append(esc(r.optString("text"))).append('|').append(esc(r.optString("pack"))).append('|').append(r.optInt("pos"));
        }
        send("rules", sb.toString());
    }

    private void send(String what, String rulesText) {
        io.execute(() -> {
            String m;
            try { m = Api.organizeCmd(prefs, account, what, rulesText).optString("message", "Sent"); } catch (Exception e) { m = e.getMessage(); }
            String m2 = m;
            main.post(() -> toast(m2));
            main.postDelayed(this::load, 3000);
        });
    }

    private static String esc(String s) {
        try { return java.net.URLEncoder.encode(s == null ? "" : s, "UTF-8").replace("+", "%20"); } catch (Exception e) { return ""; }
    }

    // ── helpers ──
    private List<String> list(String key) {
        List<String> l = new ArrayList<>();
        JSONArray a = data == null ? null : data.optJSONArray(key);
        for (int i = 0; a != null && i < a.length(); i++) l.add(a.optString(i));
        return l;
    }

    private String item(String key, int i) { List<String> l = list(key); return i >= 0 && i < l.size() ? l.get(i) : ""; }

    private static boolean containsIgnoreCase(List<String> l, String s) { for (String x : l) if (x.equalsIgnoreCase(s)) return true; return false; }

    private ArrayAdapter<String> adapter(List<String> items) {
        ArrayAdapter<String> a = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return a;
    }

    private Spinner spinner(List<String> items) { Spinner s = new Spinner(this); s.setAdapter(adapter(items)); return s; }

    private View labeled(String label, View v) {
        LinearLayout row = Ui.hbox(this);
        TextView t = Ui.text(this, label, 14, false);
        t.setMinWidth(Ui.dp(this, 80));
        row.addView(t);
        row.addView(v, Ui.weight(1));
        return row;
    }

    private static void put(JSONObject o, String k, Object v) { try { o.put(k, v); } catch (Exception ignored) { } }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
