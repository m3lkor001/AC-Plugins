package com.melk.tankremote;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** One card per account: what the character is doing, MelkTank's switches, nav route, and Launch when it's offline. */
public class MainActivity extends Activity {
    private static final String[] FEATURES = {"master", "combat", "nav", "loot", "summon", "buff", "meta"};
    private static final String[] LABELS = {"MelkTank (all)", "Combat", "Nav", "Looting", "Summons", "Buffs", "Meta"};
    private static final int SCREEN_REFRESH_MS = 15000;

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private Prefs prefs;
    private LinearLayout cards;
    private TextView serverLine, message, decalLine;
    private Button decalBtn;
    private boolean decalRunning;
    private LinearLayout aceCard;
    private TextView aceLine;
    private boolean aceRunning;
    private final Map<String, Card> cardMap = new HashMap<>();
    private boolean visible;
    private JSONObject last;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        Alerts.channels(this);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = Ui.vbox(this);
        int p = Ui.dp(this, 14);
        root.setPadding(p, p, p, p);
        serverLine = Ui.text(this, "", 15, true);
        message = Ui.text(this, "", 14, false);
        message.setTextColor(Ui.RED);
        message.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 8));
        cards = Ui.vbox(this);
        LinearLayout liveRow = Ui.hbox(this);
        TextView liveHint = Ui.text(this, "", 13, false);
        liveHint.setTextColor(Ui.muted(this));
        liveRow.addView(liveHint, Ui.weight(1));
        Switch liveSw = new Switch(this);
        liveSw.setText("Live data ");
        liveSw.setTextSize(15);
        liveSw.setChecked(Prefs.live);
        liveHint.setText(Prefs.live ? "updating every 2 s" : "");
        liveSw.setOnCheckedChangeListener((b2, on) -> {
            Prefs.live = on;
            liveHint.setText(on ? "updating every 2 s" : "");
            if (!on) io.execute(() -> { try { Api.live(prefs, false, false); } catch (Exception ignored) { } });
            load();
        });
        liveRow.addView(liveSw);
        root.addView(liveRow);
        root.addView(serverLine);
        root.addView(message);
        root.addView(cards);
        // Decal's agent: its own card under the characters
        LinearLayout decalCard = Ui.card(this);
        LinearLayout decalRow = Ui.hbox(this);
        LinearLayout decalText = Ui.vbox(this);
        decalText.addView(Ui.text(this, "Decal", 20, true));
        decalLine = Ui.text(this, "...", 14, false);
        decalText.addView(decalLine);
        decalRow.addView(decalText, Ui.weight(1));
        decalBtn = new Button(this);   // not shown: the card's ⋮ menu starts / stops it
        TextView decalMore = Ui.text(this, "\u22EE", 24, true);
        int dmp = Ui.dp(this, 10);
        decalMore.setPadding(dmp, 0, dmp / 2, 0);
        decalMore.setOnClickListener(v -> {
            android.widget.PopupMenu pm = new android.widget.PopupMenu(this, decalMore);
            pm.getMenu().add(0, 1, 0, decalRunning ? "Stop Decal's agent" : "Start Decal's agent");
            pm.getMenu().add(0, 2, 1, "Show Decal on the PC");
            pm.getMenu().add(0, 3, 2, "Decal plugins");
            pm.setOnMenuItemClickListener(it -> {
                if (it.getItemId() == 2) showDecal();
                else if (it.getItemId() == 3) startActivity(new Intent(this, PluginsActivity.class));
                else toggleDecal();
                return true;
            });
            pm.show();
        });
        decalRow.addView(decalMore);
        decalCard.addView(decalRow);
        root.addView(decalCard);

        // the local ACE test server (ACGodot's): its own card, shown when the PC has it
        aceCard = Ui.card(this);
        ((SwipeLayout) aceCard).onSwipeLeft = () -> startActivity(new Intent(this, ServerActivity.class));   // its console
        LinearLayout aceRow = Ui.hbox(this);
        LinearLayout aceText = Ui.vbox(this);
        aceText.addView(Ui.text(this, "ACE server", 20, true));
        aceLine = Ui.text(this, "...", 14, false);
        aceText.addView(aceLine);
        aceRow.addView(aceText, Ui.weight(1));
        TextView aceMore = Ui.text(this, "\u22EE", 24, true);
        aceMore.setPadding(dmp, 0, dmp / 2, 0);
        aceMore.setOnClickListener(v -> {
            android.widget.PopupMenu pm = new android.widget.PopupMenu(this, aceMore);
            pm.getMenu().add(0, 1, 0, aceRunning ? "Stop the server" : "Start the server");
            if (aceRunning) pm.getMenu().add(0, 2, 1, "Restart the server");
            pm.getMenu().add(0, 3, 2, "Status");
            pm.setOnMenuItemClickListener(it -> {
                if (it.getItemId() == 3) aceStatus();
                else if (it.getItemId() == 2) aceAsk("restart", "Restart the ACE server? Anyone on it is logged off; characters are saved first.");
                else if (aceRunning) aceAsk("stop", "Stop the ACE server? Anyone on it is logged off; characters are saved first.");
                else aceDo("start");
                return true;
            });
            pm.show();
        });
        aceRow.addView(aceMore);
        aceCard.addView(aceRow);
        aceCard.setVisibility(android.view.View.GONE);
        root.addView(aceCard);
        scroll.addView(root);
        setContentView(PullRefresh.wrap(this, scroll, pr -> updateNow(false)));

        if (android.os.Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);

        if (!prefs.configured()) startActivity(new Intent(this, SettingsActivity.class));
    }

    @Override
    protected void onResume() {
        super.onResume();
        visible = true;
        MonitorService.start(this);
        load();
    }

    @Override
    protected void onPause() {
        visible = false;
        main.removeCallbacksAndMessages(null);
        super.onPause();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu m) {
        // just the gear; "Update now" lives in each character's ⋮ menu
        m.add(0, 2, 0, "Settings").setIcon(R.drawable.ic_settings).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        m.add(0, 3, 1, "PC screenshot").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        m.add(0, 6, 2, "Loot editor").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        m.add(0, 8, 2, "Route editor").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        m.add(0, 9, 2, "Meta editor").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        m.add(0, 7, 2, "Client log").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        m.add(0, 5, 2, "Unfocus games (graphics off)").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        m.add(0, 4, 3, "Reset game...").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == 1) { updateNow(); return true; }
        if (item.getItemId() == 2) { startActivity(new Intent(this, SettingsActivity.class)); return true; }
        if (item.getItemId() == 3) { startActivity(new Intent(this, ScreenshotActivity.class)); return true; }
        if (item.getItemId() == 4) { confirmReset(); return true; }
        if (item.getItemId() == 6) { startActivity(new Intent(this, LootEditorActivity.class)); return true; }
        if (item.getItemId() == 7) { startActivity(new Intent(this, ClientLogActivity.class)); return true; }
        if (item.getItemId() == 8) { startActivity(new Intent(this, NavEditorActivity.class)); return true; }
        if (item.getItemId() == 9) { startActivity(new Intent(this, MetaEditorActivity.class)); return true; }
        if (item.getItemId() == 5) {
            io.execute(() -> {
                String msg;
                try { msg = Api.unfocus(prefs).optString("message", "Done."); } catch (Exception e) { msg = e.getMessage(); }
                String m2 = msg;
                main.post(() -> toast(m2));
            });
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // ── loading ──

    private void load() {
        main.removeCallbacksAndMessages(null);
        if (!prefs.configured()) {
            serverLine.setText("Not set up yet");
            message.setText("Open Settings and enter your PC's Tailscale address and the app key from the launcher.");
            return;
        }
        io.execute(() -> {
            try {
                if (Prefs.live) { try { Api.live(prefs, true, false); } catch (Exception ignored) { } }
                JSONObject st = Api.status(prefs);
                main.post(() -> show(st, null));
            } catch (Exception e) {
                main.post(() -> show(null, e.getMessage()));
            }
        });
    }

    private void scheduleNext() {
        main.removeCallbacksAndMessages(null);
        if (visible) main.postDelayed(this::load, Prefs.live ? 2000 : SCREEN_REFRESH_MS);
    }

    /** Asks MelkTank to write its status right away, then reloads. */
    private void updateNow() { updateNow(true); }

    private void updateNow(boolean say) {
        JSONObject st = last;
        io.execute(() -> {
            try {
                JSONArray a = st == null ? new JSONArray() : st.optJSONArray("accounts");
                for (int i = 0; a != null && i < a.length(); i++)
                    if (!"offline".equals(a.getJSONObject(i).optString("state")))
                        Api.refresh(prefs, a.getJSONObject(i).optString("account"));
            } catch (Exception ignored) { }
            main.postDelayed(this::load, 3500);
        });
        if (say) toast("Asking MelkTank for fresh numbers...");
    }

    private void show(JSONObject st, String error) {
        message.setText(error == null ? "" : error);
        message.setVisibility(error == null ? View.GONE : View.VISIBLE);
        if (st != null) {
            last = st;
            StringBuilder sb = new StringBuilder();
            JSONArray servers = st.optJSONArray("servers");
            for (int i = 0; servers != null && i < servers.length(); i++) {
                JSONObject s = servers.optJSONObject(i);
                Object up = s.opt("up");
                if (sb.length() > 0) sb.append("   ");
                sb.append(s.optString("name")).append(up == Boolean.TRUE ? " ✓ up" : up == Boolean.FALSE ? " ✗ down" : " …");
            }
            JSONObject dc = st.optJSONObject("decal");
            if (dc != null) {
                decalRunning = dc.optBoolean("running");
                boolean keep = dc.optBoolean("enabled", true);
                decalLine.setText(decalRunning ? "Running" : keep ? "Not running - the PC is starting it" : "Stopped (stays off until you start it)");
                decalLine.setTextColor(decalRunning ? Ui.GREEN : keep ? Ui.AMBER : Ui.GREY);
                decalBtn.setText(decalRunning ? "Stop" : "Start");
            }
            JSONObject ace = st.optJSONObject("ace");
            boolean aceThere = ace != null && ace.optBoolean("installed");
            aceCard.setVisibility(aceThere ? android.view.View.VISIBLE : android.view.View.GONE);
            if (aceThere) {
                aceRunning = ace.optBoolean("running");
                aceLine.setText(aceRunning ? "Running" : "Stopped");
                aceLine.setTextColor(aceRunning ? Ui.GREEN : Ui.GREY);
            }
            sb.append("\nMelkTank updates every ").append(st.optInt("interval", 45)).append("s · ")
                    .append(st.optInt("clients", 0)).append(" client(s) running");
            serverLine.setText(sb.toString());

            JSONArray accounts = st.optJSONArray("accounts");
            List<String> seen = new ArrayList<>();
            for (int i = 0; accounts != null && i < accounts.length(); i++) {
                JSONObject a = accounts.optJSONObject(i);
                String acct = a.optString("account");
                seen.add(acct);
                Card c = cardMap.get(acct);
                if (c == null) { c = new Card(acct); cardMap.put(acct, c); cards.addView(c.root); }
                c.update(a);
            }
            for (String k : new ArrayList<>(cardMap.keySet()))
                if (!seen.contains(k)) { cards.removeView(cardMap.get(k).root); cardMap.remove(k); }
        }
        scheduleNext();
    }

    // the current action's colours: Nav light blue (its text lighter), Looting yellow (its text gold), combat light red
    static final int NAV = android.graphics.Color.rgb(90, 165, 255), NAV_TEXT = android.graphics.Color.rgb(165, 210, 255);
    static final int META = android.graphics.Color.rgb(190, 140, 255), META_TEXT = android.graphics.Color.rgb(220, 195, 255);

    /** "Meta: name · state" in the meta colours (main page and the Controls card). */
    static CharSequence metaLine(JSONObject a) {
        String st = a.optString("metaState");
        return twoTone("Meta:", " " + a.optString("metaName") + (st.isEmpty() ? "" : " \u00b7 " + st), META, META_TEXT);
    }
    private static final int LOOT = android.graphics.Color.rgb(245, 215, 60), LOOT_TEXT = android.graphics.Color.rgb(212, 175, 55);
    private static final int COMBAT = android.graphics.Color.rgb(255, 125, 125);

    static CharSequence twoTone(String head, String rest, int c1, int c2) {
        android.text.SpannableString sp = new android.text.SpannableString(head + rest);
        sp.setSpan(new android.text.style.ForegroundColorSpan(c1), 0, head.length(), 0);
        sp.setSpan(new android.text.style.ForegroundColorSpan(c2), head.length(), sp.length(), 0);
        return sp;
    }

    /** MelkTank's status line coloured by what it's doing. */
    static CharSequence colourAction(String es) {
        if (es == null || es.isEmpty()) return "";
        if (es.startsWith("Nav")) return twoTone("Nav", es.substring(3), NAV, NAV_TEXT);
        if (es.startsWith("Looting")) return twoTone("Looting", es.substring(7), LOOT, LOOT_TEXT);
        String[] combat = { "Attacking", "Casting", "Waiting - DoTs", "Equipping", "Switching to", "Attack request" };
        for (String c : combat)
            if (es.startsWith(c)) {
                android.text.SpannableString sp = new android.text.SpannableString(es);
                sp.setSpan(new android.text.style.ForegroundColorSpan(COMBAT), 0, es.length(), 0);
                return sp;
            }
        return es;
    }

    private android.content.SharedPreferences uiPrefs() { return getSharedPreferences("main_ui", MODE_PRIVATE); }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    /** Reset game: every client closed and Wine stopped on the PC - for clients stuck after a crash. */
    private void aceAsk(String action, String question) {
        new AlertDialog.Builder(this).setMessage(question)
                .setPositiveButton(action.equals("stop") ? "Stop" : "Restart", (d, w) -> aceDo(action))
                .setNegativeButton("Cancel", null).show();
    }

    /** Starts, stops or restarts the PC's local ACE server (stopping waits for it to save: up to most of a minute). */
    private void aceDo(String action) {
        aceLine.setText(action.equals("start") ? "Starting..." : action.equals("stop") ? "Stopping (saving first)..." : "Restarting...");
        aceLine.setTextColor(Ui.AMBER);
        io.execute(() -> {
            String msg;
            try { msg = Api.ace(prefs, action).optString("message", "Done."); }
            catch (Exception e) { msg = e.getMessage(); }
            String m = msg;
            main.post(() -> { toast(m); load(); });
        });
    }

    /** The ACE server looked at closely: running, answering logins, since when, its database, anything to do. */
    private void aceStatus() {
        io.execute(() -> {
            String msg;
            try {
                JSONObject a = Api.aceStatus(prefs);
                StringBuilder b = new StringBuilder();
                String state = a.optString("state");
                b.append(state.equals("running") ? "Running and answering logins" : state.equals("starting") ? "Started, not answering logins yet"
                        : state.equals("stopped") ? "Stopped" : "Not on this PC");
                if (a.optString("since").length() > 0) b.append("\nSince ").append(a.optString("since"));
                if (a.optBoolean("running")) b.append(a.optBoolean("ours") ? "\nStarted by the launcher (can be stopped from here)" : "\nStarted in a terminal");
                Object db = a.opt("database");
                b.append("\nDatabase (MariaDB): ").append(db == Boolean.TRUE ? "running" : db == Boolean.FALSE ? "not running" : "unknown");
                if (a.optString("note").length() > 0) b.append("\n\n").append(a.optString("note"));
                msg = b.toString();
            } catch (Exception e) { msg = e.getMessage(); }
            String m = msg;
            main.post(() -> new AlertDialog.Builder(this).setTitle("ACE server").setMessage(m).setPositiveButton("OK", null).show());
        });
    }

    private void toggleDecal() {
        boolean stop = decalRunning;
        decalBtn.setEnabled(false);
        io.execute(() -> {
            String msg;
            try {
                JSONObject r = Api.decal(prefs, stop ? "stop" : "start");
                msg = r.optString("message", "Done.");
            } catch (Exception e) { msg = e.getMessage(); }
            String m = msg;
            main.post(() -> { toast(m); decalBtn.setEnabled(true); load(); });
        });
    }

    /** Brings Decal's window up on the PC, then opens the PC screen page to look at it (tap to click there). */
    private void showDecal() {
        toast("Opening Decal on the PC...");
        io.execute(() -> {
            String msg;
            try { msg = Api.showDecal(prefs).optString("message", "Done."); }
            catch (Exception e) { msg = e.getMessage(); }
            String m = msg;
            main.post(() -> {
                toast(m);
                main.postDelayed(() -> startActivity(new Intent(this, ScreenshotActivity.class)), 1200);
            });
        });
    }

    private void confirmReset() {
        int pad = Ui.dp(this, 20);
        LinearLayout box = Ui.vbox(this);
        box.setPadding(pad, pad / 2, pad, 0);
        box.addView(Ui.text(this, "Closes every game client on the PC at once and stops Wine, clearing anything left stuck "
                + "after a crash. Characters in the game are dropped as if the game crashed.", 15, false));
        android.widget.CheckBox again = new android.widget.CheckBox(this);
        again.setText("Start the ticked accounts again afterwards");
        again.setChecked(true);
        again.setPadding(0, pad / 2, 0, 0);
        box.addView(again);
        new AlertDialog.Builder(this)
                .setTitle("Reset game?")
                .setView(box)
                .setPositiveButton("Reset", (d, w) -> io.execute(() -> {
                    try {
                        JSONObject r = Api.reset(prefs, again.isChecked());
                        main.post(() -> toast(r.optString("message", "Reset")));
                    } catch (Exception e) {
                        main.post(() -> toast(e.getMessage()));
                    }
                    main.postDelayed(this::load, 4000);
                }))
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ── one account ──

    private class Card {
        final String account;
        final LinearLayout root;
        final TextView title, chip, sub, info, engine, navLine, mini;
        final VitalBars vitals;
        boolean miniOnline;
        String lastNav = "";
        final Switch[] switches = new Switch[FEATURES.length];
        final LinearLayout navRow, spotRow, metaRow;
        final Spinner routes, spots, metas;
        final Button useRoute, useSpot, useMeta, launch;
        final TextView more, arrow;
        final LinearLayout details;
        boolean open;
        JSONObject lastA;
        boolean clientOpen;
        boolean updating;
        String currentRoute = "";
        // when you last picked something in a drop-down yourself: it's left alone for a minute (not reset by the refresh)
        final long[] routePickedAt = {0}, spotPickedAt = {0}, metaPickedAt = {0};

        Card(String account) {
            this.account = account;
            root = Ui.card(MainActivity.this);
            ((SwipeLayout) root).onSwipeLeft = this::openSession;

            // on the card: the name, in game / offline, and what it's doing; tap the card for the details.
            // Everything else (switches, routes, spots, launch, close...) is in the ⋮ menu; swipe left for the session.
            LinearLayout head = Ui.hbox(MainActivity.this);
            arrow = Ui.text(MainActivity.this, "\u25B8", 16, true);
            arrow.setTextColor(Ui.muted(MainActivity.this));
            arrow.setPadding(0, 0, Ui.dp(MainActivity.this, 6), 0);
            head.addView(arrow);
            title = Ui.text(MainActivity.this, account, 20, true);
            head.addView(title, Ui.weight(1));
            chip = Ui.chip(MainActivity.this);
            head.addView(chip);
            more = Ui.text(MainActivity.this, "\u22EE", 24, true);   // vertical ellipsis
            int mp = Ui.dp(MainActivity.this, 10);
            more.setPadding(mp, 0, mp / 2, 0);
            more.setContentDescription("More options");
            more.setOnClickListener(this::showMenu);
            head.addView(more);
            root.addView(head);
            // health / stamina / mana, like the game's bars (just below the name)
            vitals = new VitalBars(MainActivity.this);
            LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            vlp.topMargin = Ui.dp(MainActivity.this, 4);
            root.addView(vitals, vlp);

            engine = Ui.text(MainActivity.this, "", 14, false);
            engine.setPadding(0, Ui.dp(MainActivity.this, 4), 0, 0);
            root.addView(engine);
            navLine = Ui.text(MainActivity.this, "", 13, false);
            navLine.setTextColor(Ui.muted(MainActivity.this));
            navLine.setVisibility(View.GONE);
            root.addView(navLine);
            // folded up: just "Combat (8)   Looting (3)", blue when on, grey when off
            mini = Ui.text(MainActivity.this, "", 14, true);
            mini.setPadding(0, Ui.dp(MainActivity.this, 4), 0, 0);
            mini.setVisibility(View.GONE);
            root.addView(mini);

            details = Ui.vbox(MainActivity.this);
            sub = Ui.text(MainActivity.this, "", 13, false);
            sub.setTextColor(Ui.muted(MainActivity.this));
            sub.setPadding(0, Ui.dp(MainActivity.this, 6), 0, 0);
            details.addView(sub);
            info = Ui.text(MainActivity.this, "", 15, false);
            info.setPadding(0, Ui.dp(MainActivity.this, 6), 0, Ui.dp(MainActivity.this, 2));
            info.setLineSpacing(0, 1.2f);
            details.addView(info);
            root.addView(details);
            open = uiPrefs().getBoolean("card_open_" + account, false);
            applyOpen();
            root.setOnClickListener(v -> { open = !open; uiPrefs().edit().putBoolean("card_open_" + account, open).apply(); applyOpen(); });
            root.setOnLongClickListener(v -> { showMenu(more); return true; });

            // the switches and the route / spot pickers: in the part that folds out
            LinearLayout hidden = details;
            LinearLayout row = null;
            for (int i = 0; i < FEATURES.length; i++) {
                if (i % 2 == 0) { row = Ui.hbox(MainActivity.this); hidden.addView(row); }
                Switch s = new Switch(MainActivity.this);
                s.setText(LABELS[i]);
                s.setTextSize(15);
                s.setPadding(0, Ui.dp(MainActivity.this, 6), Ui.dp(MainActivity.this, 16), Ui.dp(MainActivity.this, 6));
                final String feature = FEATURES[i];
                s.setOnCheckedChangeListener((CompoundButton b, boolean on) -> { if (!updating) toggle(b, feature, on); });
                switches[i] = s;
                row.addView(s, Ui.weight(1));
            }

            navRow = Ui.hbox(MainActivity.this);
            navRow.setPadding(0, Ui.dp(MainActivity.this, 8), 0, 0);
            TextView nl = Ui.text(MainActivity.this, "Route ", 15, false);
            navRow.addView(nl);
            routes = new Spinner(MainActivity.this);
            navRow.addView(routes, Ui.weight(1));
            routes.setOnTouchListener((v, ev) -> { routePickedAt[0] = System.currentTimeMillis(); return false; });
            useRoute = new Button(MainActivity.this);
            useRoute.setText("Use");
            useRoute.setOnClickListener(v -> pickRoute());
            navRow.addView(useRoute);
            hidden.addView(navRow);

            spotRow = Ui.hbox(MainActivity.this);
            TextView sl = Ui.text(MainActivity.this, "Spot ", 15, false);
            spotRow.addView(sl);
            spots = new Spinner(MainActivity.this);
            spotRow.addView(spots, Ui.weight(1));
            spots.setOnTouchListener((v, ev) -> { spotPickedAt[0] = System.currentTimeMillis(); return false; });
            useSpot = new Button(MainActivity.this);
            useSpot.setText("Use");
            useSpot.setOnClickListener(v -> pickSpot());
            spotRow.addView(useSpot);
            hidden.addView(spotRow);

            metaRow = Ui.hbox(MainActivity.this);
            metaRow.addView(Ui.text(MainActivity.this, "Meta ", 15, false));
            metas = new Spinner(MainActivity.this);
            metaRow.addView(metas, Ui.weight(1));
            metas.setOnTouchListener((v, ev) -> { metaPickedAt[0] = System.currentTimeMillis(); return false; });
            useMeta = new Button(MainActivity.this);
            useMeta.setText("Use");
            useMeta.setOnClickListener(v -> pickMeta());
            metaRow.addView(useMeta);
            hidden.addView(metaRow);

            launch = new Button(MainActivity.this);
            launch.setText("Launch this account");
            launch.setOnClickListener(v -> confirmLaunch());   // not shown: "Launch this account..." is in the ⋮ menu
        }

        void applyOpen() {
            details.setVisibility(open ? View.VISIBLE : View.GONE);
            mini.setVisibility(!open && miniOnline && mini.getText().length() > 0 ? View.VISIBLE : View.GONE);
            arrow.setText(open ? "\u25BE" : "\u25B8");
        }

        /** The other accounts' characters: where the bank transfer buttons can send to. */
        ArrayList<String> otherCharacters() {
            ArrayList<String> others = new ArrayList<>();
            JSONArray accs = last == null ? null : last.optJSONArray("accounts");
            for (int k = 0; accs != null && k < accs.length(); k++) {
                JSONObject o = accs.optJSONObject(k);
                if (o == null || o.optString("account").equalsIgnoreCase(account)) continue;
                String nm = o.optString("character", "");
                if (nm.isEmpty()) nm = o.optString("configuredCharacter", "");
                if (!nm.isEmpty() && !others.contains(nm)) others.add(nm);
            }
            return others;
        }

        void openSession() {
            Intent i = new Intent(MainActivity.this, SessionActivity.class);
            i.putStringArrayListExtra("others", otherCharacters());
            i.putExtra("account", account);
            i.putExtra("title", title.getText().toString());
            startActivity(i);
        }

        void showMenu(View anchor) {
            android.widget.PopupMenu pm = new android.widget.PopupMenu(MainActivity.this, anchor);
            JSONObject a = lastA == null ? new JSONObject() : lastA;
            boolean online = "online".equals(a.optString("state"));
            if (launch.getVisibility() == View.VISIBLE) pm.getMenu().add(0, 30, 0, "Launch this account...");
            pm.getMenu().add(3, 1, 30, "Close client...").setEnabled(clientOpen);
            pm.getMenu().add(3, 2, 31, "Update now");
            pm.getMenu().add(3, 3, 32, "Session details  (or swipe left)");
            pm.getMenu().add(3, 6, 33, "Chat...");
            pm.getMenu().add(3, 4, 34, "Focus game window").setEnabled(clientOpen);
            pm.getMenu().add(3, 5, 35, "Move game window to top-left").setEnabled(clientOpen);
            pm.getMenu().add(3, 7, 36, "PC screenshot");
            pm.getMenu().add(3, 8, 37, "Focus game window, then screenshot").setEnabled(clientOpen);
            // MelkTank's debug log (MelkTank_debug.txt): ticked = on
            pm.getMenu().add(4, 42, 38, "MelkTank settings & snapshots...").setEnabled(online);
            pm.getMenu().add(4, 43, 38, "Organize packs...").setEnabled(online);
            pm.getMenu().add(4, 41, 39, "Add a note to the logs...").setEnabled(online);
            pm.getMenu().add(4, 40, 40, "Debug log").setCheckable(true).setChecked(a.optBoolean("debug", false)).setEnabled(online);
            pm.setOnMenuItemClickListener(item -> {
                int id = item.getItemId();
                if (id >= 100 && id < 100 + FEATURES.length) { setFeature(FEATURES[id - 100], !item.isChecked()); return true; }
                if (id == 40) { setFeature("debug", !item.isChecked()); return true; }
                if (id == 42) { AccountMenu.openMtSettings(MainActivity.this, account, a.optString("character", account)); return true; }
                if (id == 43) { AccountMenu.openOrganize(MainActivity.this, account, a.optString("character", account)); return true; }
                if (id == 41) { AccountMenu.askNote(MainActivity.this, prefs, account, a.optString("character", account)); return true; }
                if (id == 7) { startActivity(new Intent(MainActivity.this, ScreenshotActivity.class)); return true; }
                if (id == 8) { AccountMenu.focusThenShot(MainActivity.this, prefs, account); return true; }
                if (id == 30) { confirmLaunch(); return true; }
                if (id == 20 || id == 21) { choose(id == 20); return true; }
                if (item.getItemId() == 1) confirmClose();
                else if (item.getItemId() == 3) openSession();
                else if (item.getItemId() == 6) {
                    Intent ci = new Intent(MainActivity.this, ChatActivity.class);
                    ci.putExtra("account", account);
                    // the other accounts' characters: where the bank transfer buttons can send to
                    ArrayList<String> others = new ArrayList<>();
                    JSONArray accs = last == null ? null : last.optJSONArray("accounts");
                    for (int k = 0; accs != null && k < accs.length(); k++) {
                        JSONObject o = accs.optJSONObject(k);
                        if (o == null || o.optString("account").equalsIgnoreCase(account)) continue;
                        String nm = o.optString("character", "");
                        if (nm.isEmpty()) nm = o.optString("configuredCharacter", "");
                        if (!nm.isEmpty() && !others.contains(nm)) others.add(nm);
                    }
                    ci.putStringArrayListExtra("others", others);
                    ci.putExtra("title", title.getText().toString());
                    startActivity(ci);
                }
                else if (item.getItemId() == 4 || item.getItemId() == 5) {
                    boolean move = item.getItemId() == 5;
                    io.execute(() -> {
                        String msg;
                        try { msg = (move ? Api.moveWindow(prefs, account) : Api.focus(prefs, account)).optString("message", "Done."); } catch (Exception e) { msg = e.getMessage(); }
                        String m = msg;
                        main.post(() -> toast(m));
                    });
                }
                else if (item.getItemId() == 2) {
                    io.execute(() -> {
                        try { Api.refresh(prefs, account); } catch (Exception ignored) { }
                        main.postDelayed(MainActivity.this::load, 3500);
                    });
                    toast("Asking MelkTank for fresh numbers...");
                }
                return true;
            });
            pm.show();
        }

        /** A switch from the menu: MelkTank (all), Combat, Nav, Looting, Summons, Buffs. */
        void setFeature(String feature, boolean on) {
            io.execute(() -> {
                String m;
                try { Api.set(prefs, account, feature, on); m = labelOf(feature) + (on ? " on" : " off") + " - sent"; }
                catch (Exception e) { m = e.getMessage(); }
                String m2 = m;
                main.post(() -> toast(m2));
                main.postDelayed(MainActivity.this::load, 3500);
            });
        }

        /** Nav route / spot: a list to pick from, the one in use ticked. */
        void choose(boolean route) {
            JSONObject a = lastA == null ? new JSONObject() : lastA;
            JSONArray r = a.optJSONArray(route ? "navRoutes" : "navSpots");
            List<String> names = new ArrayList<>();
            for (int i = 0; r != null && i < r.length(); i++) names.add(r.optString(i));
            if (names.isEmpty()) return;
            boolean thisMode = a.optInt("navMode", 0) == (route ? 1 : 0);
            int cur = thisMode ? names.indexOf(a.optString(route ? "navRoute" : "navSpot", "")) : -1;
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle(route ? "Nav route" : "Nav spot")
                    .setSingleChoiceItems(names.toArray(new String[0]), cur, (d, w) -> {
                        d.dismiss();
                        String name = names.get(w);
                        io.execute(() -> {
                            String m;
                            try {
                                if (route) Api.navRoute(prefs, account, name); else Api.navSpot(prefs, account, name);
                                m = (route ? "Route " : "Spot ") + name + " - sent." + (a.optBoolean("nav") ? "" : " Turn Nav on to use it.");
                            } catch (Exception e) { m = e.getMessage(); }
                            String m2 = m;
                            main.post(() -> toast(m2));
                            main.postDelayed(MainActivity.this::load, 3500);
                        });
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        }

        void update(JSONObject a) {
            lastA = a;
            AccountMenu.noteDebug(account, a.optBoolean("debug", false));
            updating = true;
            try {
                String state = a.optString("state", "offline");
                String launching = a.optString("launching", "");
                String character = a.optString("character", "");
                boolean online = state.equals("online");
                // the name: the character in game, else the one the launcher logs in (the account only when none is picked)
                String configured = a.optString("configuredCharacter", "");
                title.setText(online && !character.isEmpty() ? character : !configured.isEmpty() ? configured : account);
                vitals.set(online ? a : null);
                if (!launching.isEmpty()) { chip.setText("Starting"); Ui.chipColor(MainActivity.this, chip, Ui.AMBER); }
                else if (online) { chip.setText("In game"); Ui.chipColor(MainActivity.this, chip, Ui.GREEN); }
                else if (state.equals("charselect")) { chip.setText("Character screen"); Ui.chipColor(MainActivity.this, chip, Ui.AMBER); }
                else { chip.setText("Offline"); Ui.chipColor(MainActivity.this, chip, Ui.GREY); }

                String note = a.optString("loginNote", "");
                // which client it runs in (Retail / ACGodot) rather than the account's name
                String client = a.optString("client", "");
                String subText = (client.isEmpty() ? account : client) + (a.optString("server").isEmpty() ? "" : " · " + a.optString("server"));
                if (!online && !note.isEmpty()) subText += "\n" + note;
                if (!launching.isEmpty() && !launching.equals("starting")) subText += "\n" + launching;
                if (online) subText += "\nUpdated " + Fmt.ago(a.optString("updated"));
                if (online && !a.optString("build").isEmpty()) subText += " · MelkTank " + a.optString("build");
                sub.setText(subText);

                if (online) {
                    StringBuilder sb = new StringBuilder();
                    // where: the bounty area's name (Chamber of Idols, Wailing Cells), else the tier (T11)
                    String loc = a.optString("location", "");
                    sb.append("Location: ").append(loc.isEmpty() ? "-" : loc).append('\n');
                    sb.append("Logged in: ").append(Fmt.since(a.optString("loginTime"))).append('\n');
                    // memory: the game climbs as items are seen and hangs at about 1.6-1.7 GB; MelkTank relogs at its limit
                    long mem = a.optLong("memInUse", -1), relogMB = a.optLong("relogMB", 0);
                    if (mem > 0) {
                        sb.append("Memory: ").append(String.format(java.util.Locale.US, "%.2f GB", mem / 1073741824.0));
                        if (a.optBoolean("relogPending")) sb.append(" - relogging when calm");
                        else if (relogMB > 0) sb.append(String.format(java.util.Locale.US, " (relogs at %.2f)", relogMB / 1024.0));
                        sb.append('\n');
                    }
                    long kph = a.optLong("killsPerHour", -1);
                    sb.append("Kills / hour (last 60 min): ").append(kph >= 0 ? Fmt.num(kph) : "after 1 minute").append('\n');
                    if (a.has("packAvg")) { long pa = a.optLong("packAvg"); sb.append("Pack time (avg): ").append(pa / 60).append(':').append(String.format(java.util.Locale.US, "%02d", pa % 60)).append('\n'); }
                    if (a.has("lumPerHour")) sb.append("Lum / hour (effective): ").append(Fmt.big(a.optLong("lumPerHour"))).append('\n');
                    if (a.has("xpPerHour")) sb.append("XP / hour: ").append(Fmt.big(a.optLong("xpPerHour"))).append('\n');
                    String la = a.optString("lastAttack", "");
                    sb.append("Last attack: ").append(la.isEmpty() ? "none yet" : Fmt.ago(la)).append('\n');
                    long lumBank = a.optLong("lumBank", -1), lum = a.optLong("lum", -1);
                    // luminance is a bank-only currency here: just the bank
                    sb.append("Luminance: ");
                    if (lumBank >= 0) sb.append(Fmt.num(lumBank)).append(" (bank)");
                    else sb.append("not seen yet");
                    sb.append('\n');
                    long coins = a.optLong("coins", -1), coinsBank = a.optLong("coinsBank", -1);
                    sb.append("Enlightened Coins: ").append(Fmt.num(Math.max(0, coins))).append(" in pack");
                    if (coinsBank >= 0) sb.append(" · ").append(Fmt.num(coinsBank)).append(" in bank");
                    int deaths = a.optInt("deaths", 0);
                    if (deaths > 0) sb.append("\nDeaths this session: ").append(deaths).append(" (last ").append(Fmt.ago(a.optString("lastDeath"))).append(')');
                    info.setText(sb.toString());
                    String es = a.optString("engineStatus", "");
                    CharSequence act = colourAction(es);
                    if (a.optBoolean("paused")) {
                        android.text.SpannableStringBuilder pb = new android.text.SpannableStringBuilder("Paused by " + a.optString("pausedBy") + (es.isEmpty() ? "" : " · "));
                        pb.append(act);
                        act = pb;
                    }
                    engine.setText(act);
                } else {
                    info.setText(state.equals("charselect") ? "On the character screen." : "Not running.");
                    engine.setText("");
                }
                info.setVisibility(View.VISIBLE);
                if (!online) engine.setText(state.equals("charselect") ? "On the character screen" : "");
                engine.setVisibility(engine.getText().length() > 0 ? View.VISIBLE : View.GONE);
                // nav: the route's step and what it's doing (a spot: in position or not); the last one stays shown
                String ns = online ? a.optString("navStatus", "") : "";
                if (!ns.isEmpty()) lastNav = ns;
                navLine.setText(twoTone("Nav:", " " + lastNav, NAV, NAV_TEXT));
                navLine.setVisibility(online && !lastNav.isEmpty() ? View.VISIBLE : View.GONE);

                for (int i = 0; i < FEATURES.length; i++) {
                    switches[i].setChecked(a.optBoolean(FEATURES[i], false));
                    // counts beside the switch: monsters in attack range, corpses not looted yet
                    String countKey = FEATURES[i].equals("combat") ? "mobs" : FEATURES[i].equals("loot") ? "corpses" : null;
                    switches[i].setText(LABELS[i] + (countKey != null && a.has(countKey) ? " (" + a.optInt(countKey) + ")" : ""));
                    switches[i].setEnabled(online);
                    switches[i].setVisibility(online ? View.VISIBLE : View.GONE);
                }
                boolean master = a.optBoolean("master", true);
                for (int i = 1; i < FEATURES.length; i++) switches[i].setAlpha(master ? 1f : 0.5f);
                // the folded card's combat / loot line
                android.text.SpannableStringBuilder mb = new android.text.SpannableStringBuilder();
                for (String f : new String[]{"combat", "loot"}) {
                    String countKey = f.equals("combat") ? "mobs" : "corpses";
                    String t = labelOf(f) + (a.has(countKey) ? " (" + a.optInt(countKey) + ")" : "");
                    boolean on = master && a.optBoolean(f, false);
                    if (mb.length() > 0) mb.append("     ");
                    int st = mb.length();
                    mb.append(t);
                    mb.setSpan(new android.text.style.ForegroundColorSpan(on ? MINI_ON : Ui.GREY), st, mb.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
                mini.setText(mb);
                miniOnline = online;
                mini.setVisibility(!open && online ? View.VISIBLE : View.GONE);

                JSONArray r = a.optJSONArray("navRoutes");
                List<String> names = new ArrayList<>();
                for (int i = 0; r != null && i < r.length(); i++) names.add(r.optString(i));
                navRow.setVisibility(online && !names.isEmpty() ? View.VISIBLE : View.GONE);
                currentRoute = a.optString("navRoute", "");
                int navMode = a.optInt("navMode", 0);
                boolean navOn = online && a.optBoolean("nav", false) && a.optBoolean("master", true);
                fillPicker(routes, names, navMode == 1 ? currentRoute : "", navMode == 1 && navOn, routePickedAt);
                useRoute.setText(a.optInt("navMode", 0) == 1 ? "Use" : "Use route");

                JSONArray sp = a.optJSONArray("navSpots");
                List<String> spotNames = new ArrayList<>();
                for (int i = 0; sp != null && i < sp.length(); i++) spotNames.add(sp.optString(i));
                spotRow.setVisibility(online && !spotNames.isEmpty() ? View.VISIBLE : View.GONE);
                String curSpot = a.optString("navSpot", "");
                fillPicker(spots, spotNames, navMode == 0 ? curSpot : "", navMode == 0 && navOn, spotPickedAt);
                useSpot.setText(a.optInt("navMode", 0) == 0 ? "Use" : "Use spot");

                JSONArray ma = a.optJSONArray("metas");
                List<String> metaNames = new ArrayList<>();
                for (int i = 0; ma != null && i < ma.length(); i++) metaNames.add(ma.optString(i));
                metaRow.setVisibility(online && !metaNames.isEmpty() ? View.VISIBLE : View.GONE);
                fillPicker(metas, metaNames, a.optString("metaName", ""), online && a.optBoolean("meta", false), metaPickedAt);
                // the meta's line under nav: which one and its state while it runs
                if (online && a.optBoolean("meta", false) && !a.optString("metaName").isEmpty()) {
                    CharSequence ml = metaLine(a);
                    navLine.setText(lastNav.isEmpty() ? ml : android.text.TextUtils.concat(navLine.getText(), "\n", ml));
                    navLine.setVisibility(View.VISIBLE);
                }

                clientOpen = a.optBoolean("clientOpen", !state.equals("offline"));
                launch.setVisibility(state.equals("offline") && !clientOpen && launching.isEmpty() ? View.VISIBLE : View.GONE);
                if (clientOpen && state.equals("offline")) {
                    // the game is still open but MelkTank stopped reporting: probably frozen
                    chip.setText("Not answering");
                    Ui.chipColor(MainActivity.this, chip, Ui.RED);
                }
            } finally {
                updating = false;
            }
        }

        void toggle(CompoundButton b, String feature, boolean on) {
            b.setEnabled(false);
            io.execute(() -> {
                try {
                    Api.set(prefs, account, feature, on);
                    main.post(() -> toast(labelOf(feature) + (on ? " on" : " off") + " - sent"));
                    main.postDelayed(MainActivity.this::load, 3500);
                } catch (Exception e) {
                    main.post(() -> {
                        updating = true;
                        b.setChecked(!on);
                        updating = false;
                        b.setEnabled(true);
                        toast(e.getMessage());
                    });
                }
            });
        }

        void pickRoute() {
            Object sel = routes.getSelectedItem();
            if (sel == null) return;
            routePickedAt[0] = 0;   // sent: show what MelkTank uses again
            String route = sel.toString();
            io.execute(() -> {
                try {
                    Api.navRoute(prefs, account, route);
                    main.post(() -> toast("Route " + route + " - sent. Turn Nav on to run it."));
                    main.postDelayed(MainActivity.this::load, 3500);
                } catch (Exception e) {
                    main.post(() -> toast(e.getMessage()));
                }
            });
        }

        /**
         * Fills a route / spot drop-down. The one MelkTank is using is shown (unless you picked another in the last
         * minute), and its text is green while Nav is running it.
         */
        void fillPicker(Spinner sp, List<String> names, String active, boolean running, long[] pickedAt) {
            if (names.isEmpty() || sp.isPressed()) return;
            Object old = sp.getAdapter() == null ? null : sp.getSelectedItem();
            boolean userPicked = System.currentTimeMillis() - pickedAt[0] < 60_000;
            final int activeIdx = names.indexOf(active);
            ArrayAdapter<String> ad = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_spinner_item, names) {
                private android.content.res.ColorStateList normal;
                private android.view.View paint(int pos, android.view.View v) {
                    if (v instanceof TextView) {
                        TextView tv = (TextView) v;
                        if (normal == null) normal = tv.getTextColors();   // the theme's colour (first view is a fresh one)
                        if (pos == activeIdx && running) { tv.setTextColor(Ui.GREEN); tv.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); }
                        else { tv.setTextColor(normal); tv.setTypeface(android.graphics.Typeface.DEFAULT); }
                    }
                    return v;
                }
                @Override public android.view.View getView(int pos, android.view.View cv, android.view.ViewGroup parent) {
                    return paint(pos, super.getView(pos, cv, parent));
                }
                @Override public android.view.View getDropDownView(int pos, android.view.View cv, android.view.ViewGroup parent) {
                    return paint(pos, super.getDropDownView(pos, cv, parent));
                }
            };
            ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            sp.setAdapter(ad);
            int sel = userPicked && old != null ? names.indexOf(old.toString()) : activeIdx;
            if (sel < 0) sel = old != null ? names.indexOf(old.toString()) : -1;
            sp.setSelection(Math.max(0, sel));
        }

        void pickMeta() {
            Object sel = metas.getSelectedItem();
            if (sel == null) return;
            metaPickedAt[0] = 0;
            String meta = sel.toString();
            io.execute(() -> {
                try {
                    Api.metaLoad(prefs, account, meta);
                    main.post(() -> toast("Meta " + meta + " - sent." + (lastA != null && lastA.optBoolean("meta") ? "" : " Turn Meta on to run it.")));
                    main.postDelayed(MainActivity.this::load, 3500);
                } catch (Exception e) {
                    main.post(() -> toast(e.getMessage()));
                }
            });
        }

        void pickSpot() {
            Object sel = spots.getSelectedItem();
            if (sel == null) return;
            spotPickedAt[0] = 0;
            String spot = sel.toString();
            io.execute(() -> {
                try {
                    Api.navSpot(prefs, account, spot);
                    main.post(() -> toast("Spot " + spot + " - sent. Turn Nav on to go there."));
                    main.postDelayed(MainActivity.this::load, 3500);
                } catch (Exception e) {
                    main.post(() -> toast(e.getMessage()));
                }
            });
        }

        void confirmClose() {
            // (the same three choices as the character pages' menu)
            AccountMenu.confirmClose(MainActivity.this, prefs, account, String.valueOf(title.getText()));
            main.postDelayed(MainActivity.this::load, 8000);
        }

        void sendClose(String mode, boolean relaunch) {
            io.execute(() -> {
                try {
                    JSONObject r = Api.close(prefs, account, mode, relaunch);
                    main.post(() -> toast(r.optString("message", "Sent")));
                    main.postDelayed(MainActivity.this::load, 4000);
                } catch (Exception e) {
                    main.post(() -> toast(e.getMessage()));
                }
            });
        }

        void confirmLaunch() {
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Launch " + account + "?")
                    .setMessage("Starts a game client for this account on your PC (and logs in its character, if one is picked in the launcher).")
                    .setPositiveButton("Launch", (d, w) -> io.execute(() -> {
                        try {
                            JSONObject r = Api.launch(prefs, account);
                            main.post(() -> toast(r.optString("message", "Starting...")));
                            main.postDelayed(MainActivity.this::load, 3000);
                        } catch (Exception e) {
                            main.post(() -> toast(e.getMessage()));
                        }
                    }))
                    .setNegativeButton("Cancel", null)
                    .show();
        }
    }

    private static final int MINI_ON = android.graphics.Color.rgb(77, 148, 255);   // the switches' blue

    private static String labelOf(String feature) {
        if ("debug".equals(feature)) return "Debug log";
        for (int i = 0; i < FEATURES.length; i++) if (FEATURES[i].equals(feature)) return LABELS[i];
        return feature;
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        MonitorService.start(this);
    }
}
