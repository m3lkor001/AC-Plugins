package com.melk.tankremote;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Compares each status poll with the last one and notifies about:
 *  - a character going offline (client closed / disconnected / froze)
 *  - a death
 *  - no attacks for the idle time while combat is on
 *  - the PC not answering for a few polls in a row
 */
final class Alerts {
    static final String CH_ALERTS = "alerts";
    static final String CH_MONITOR = "monitor";
    static final String CH_MONITOR_HIDDEN = "monitor_hidden";   // the same, but never shown (Settings: watching notification off)

    private Alerts() {}

    static void channels(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        NotificationChannel a = new NotificationChannel(CH_ALERTS, "Character alerts", NotificationManager.IMPORTANCE_HIGH);
        a.setDescription("Offline, died, or idle too long");
        nm.createNotificationChannel(a);
        NotificationChannel m = new NotificationChannel(CH_MONITOR, "Watching (always on)", NotificationManager.IMPORTANCE_MIN);
        m.setDescription("The small notification that keeps the watcher running");
        m.setShowBadge(false);
        nm.createNotificationChannel(m);
        NotificationChannel h = new NotificationChannel(CH_MONITOR_HIDDEN, "Watching (hidden)", NotificationManager.IMPORTANCE_NONE);
        h.setDescription("Used instead when the watching notification is switched off in the app's Settings");
        h.setShowBadge(false);
        nm.createNotificationChannel(h);
    }

    /** One poll's result. status = null when the PC couldn't be reached. */
    static void check(Context c, Prefs p, JSONObject status) {
        try {
            JSONObject mem = new JSONObject(p.alertState());
            long now = System.currentTimeMillis();

            if (status == null) {
                int fails = mem.optInt("_fails", 0) + 1;
                mem.put("_fails", fails);
                if (fails == 3 && p.alertOn("pc")) notify(c, "pc", "Can't reach your PC", "No answer for " + fails + " checks in a row - Tailscale, the PC or the service may be down.");
                p.alertState(mem.toString());
                return;
            }
            if (mem.optInt("_fails", 0) >= 3 && p.alertOn("pc")) notify(c, "pc", "PC reachable again", "MelkTank Remote can see your PC again.");
            mem.put("_fails", 0);

            // a note from the PC (e.g. "an approval is waiting on the PC screen") - opens the PC screen page
            JSONObject note = status.optJSONObject("pcNote");
            if (note != null && note.optString("at").length() > 0 && !note.optString("at").equals(mem.optString("_note")) && p.alertOn("note")) {
                if (mem.has("_note")) notify(c, "pcnote", "Your PC needs you", note.optString("text"), ScreenshotActivity.class);
                mem.put("_note", note.optString("at"));
            }

            JSONArray accounts = status.optJSONArray("accounts");
            if (accounts == null) accounts = new JSONArray();
            for (int i = 0; i < accounts.length(); i++) {
                JSONObject a = accounts.getJSONObject(i);
                String acct = a.optString("account");
                JSONObject prev = mem.optJSONObject(acct);
                if (prev == null) prev = new JSONObject();
                JSONObject next = new JSONObject();

                String state = a.optString("state", "offline");
                String name = a.optString("character", "");
                if (name.isEmpty()) name = prev.optString("name", acct);
                String prevState = prev.optString("state", "");

                // offline
                if (state.equals("offline") && (prevState.equals("online") || prevState.equals("charselect")) && p.alertOn("offline"))
                    notify(c, acct + "-off", name + " went offline", "The game client for " + acct + " stopped answering.");

                // stuck at the character screen after a launch (the PC gave up clicking Enter)
                long stuck = a.optLong("loginStuck", 0);
                if (stuck > 0 && stuck != prev.optLong("stuck", 0) && prev.has("state") && p.alertOn("stuck"))
                    notify(c, acct + "-stuck", name + " didn't get into the world",
                            "Stuck at the character screen after launching. Open PC screenshot to see why, or Reset game.");

                // death
                int deaths = a.optInt("deaths", 0);
                String lastDeath = a.optString("lastDeath", "");
                if (state.equals("online") && prev.has("deaths") && p.alertOn("death") &&
                        (deaths > prev.optInt("deaths", 0) || (!lastDeath.isEmpty() && !lastDeath.equals(prev.optString("lastDeath")))))
                    notify(c, acct + "-death", name + " died", "MelkTank switched off what your \"On death\" settings say.");

                // auto enlighten: it was running and now it isn't (finished, out of luminance / mats, or stuck)
                boolean enlOn = state.equals("online") && a.optBoolean("enlOn", false);
                if (prev.optBoolean("enlOn", false) && !enlOn && state.equals("online") && p.alertOn("enl"))
                    notify(c, acct + "-enl", name + ": auto enlighten stopped", a.optString("enlStatus", "") + (a.optInt("enlNow", -1) >= 0 ? " (enlightenment " + a.optInt("enlNow") + ")" : ""));

                // a tell from a player (MelkTank counts them this session; the last one's text goes in the notification)
                int tellSeq = a.optInt("tellSeq", 0);
                if (state.equals("online") && prev.has("tellSeq") && tellSeq > prev.optInt("tellSeq", 0) && p.alertOn("tell")) {
                    int more = tellSeq - prev.optInt("tellSeq", 0) - 1;
                    String last = a.optString("tellLast", "");
                    int colon = last.indexOf(": ");
                    String from = colon > 0 ? last.substring(0, colon) : "a player";
                    String msg = colon > 0 ? last.substring(colon + 2) : last;
                    notify(c, acct + "-tell", name + ": tell from " + from, msg + (more > 0 ? "  (+" + more + " more)" : ""));
                }

                // idle: combat on, MelkTank on, not paused, no attack for the idle time
                boolean idleNotified = prev.optBoolean("idle", false);
                boolean watching = state.equals("online") && a.optBoolean("master", true) && a.optBoolean("combat", false) && !a.optBoolean("paused", false);
                if (watching) {
                    long last = Fmt.time(a.optString("lastAttack", ""));
                    if (last < 0) last = Fmt.time(a.optString("loginTime", ""));
                    long idleMs = p.idleMinutes() * 60_000L;
                    if (last > 0 && now - last > idleMs) {
                        if (!idleNotified && p.alertOn("idle")) notify(c, acct + "-idle", name + " is idle", "No attacks for " + Fmt.duration(now - last) + ".");
                        idleNotified = true;
                    } else idleNotified = false;
                } else idleNotified = false;

                next.put("state", state);
                next.put("name", name);
                if (state.equals("online")) { next.put("deaths", deaths); next.put("lastDeath", lastDeath); }
                next.put("idle", idleNotified);
                next.put("enlOn", enlOn);
                next.put("stuck", stuck);
                if (state.equals("online")) next.put("tellSeq", tellSeq); else if (prev.has("tellSeq")) next.put("tellSeq", prev.optInt("tellSeq", 0));
                mem.put(acct, next);
            }
            p.alertState(mem.toString());
        } catch (Exception ignored) { }
    }

    static void notify(Context c, String tag, String title, String text) { notify(c, tag, title, text, MainActivity.class); }

    static void notify(Context c, String tag, String title, String text, Class<?> page) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (!nm.areNotificationsEnabled()) return;
        PendingIntent open = PendingIntent.getActivity(c, page == MainActivity.class ? 0 : 1, new Intent(c, page),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(c, CH_ALERTS)
                .setSmallIcon(R.drawable.ic_notify)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(open)
                .setAutoCancel(true)
                .build();
        nm.notify(tag, 1, n);
    }
}
