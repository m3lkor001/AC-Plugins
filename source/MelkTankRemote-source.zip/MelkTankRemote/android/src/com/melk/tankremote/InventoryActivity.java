package com.melk.tankremote;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * One character's inventory (swipe left on the session page): what's equipped and what's in the main pack. Tap an
 * item to identify it in game; its ID shows in the panel at the bottom. Swipe right goes back to the session page.
 * Loaded when the page opens and again after an ID (MelkTank also rewrites the file with the session file).
 */
public class InventoryActivity extends Activity {
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private Prefs prefs;
    private String account;
    private TextView status, detail, detailName, detailRule;
    private static final int GOLD = Color.rgb(212, 175, 55);
    private android.content.SharedPreferences ui;
    private static final String[] SORTS = {"Pack order", "Type", "Name"};
    private LinearLayout list, bags;
    private long openPack;          // the bag shown on the left: 0 = the main pack (the default each time the page opens)
    private boolean packAsked;      // asked MelkTank for that bag's contents (it only sends the bag you pick)
    private ScrollView detailScroll;
    private JSONObject data;
    private long selected;
    private TextView selectedRow;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        ui = getSharedPreferences("inventory", MODE_PRIVATE);
        account = getIntent().getStringExtra("account");
        String title = getIntent().getStringExtra("title");
        setTitle("Inventory - " + (title == null || title.isEmpty() ? account : title));
        if (getActionBar() != null) getActionBar().setDisplayHomeAsUpEnabled(true);

        LinearLayout root = Ui.vbox(this);
        int p = Ui.dp(this, 10);
        root.setPadding(p, p, p, p);

        LinearLayout bar = Ui.hbox(this);
        Button back = new Button(this);
        back.setText("‹ Back");
        back.setOnClickListener(v -> goBack());
        bar.addView(back);
        status = Ui.text(this, "Loading...", 13, false);
        status.setTextColor(Ui.muted(this));
        status.setPadding(Ui.dp(this, 8), 0, Ui.dp(this, 8), 0);
        bar.addView(status, Ui.weight(1));
        Button refresh = new Button(this);
        refresh.setText("Refresh");
        refresh.setOnClickListener(v -> load());
        bar.addView(refresh);
        root.addView(bar);

        // items on the left, the bags down the right (like the game's pack column: main pack first)
        LinearLayout middle = Ui.hbox(this);
        ScrollView scroll = new ScrollView(this);
        list = Ui.vbox(this);
        scroll.addView(list);
        middle.addView(scroll, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));
        ScrollView bagScroll = new ScrollView(this);
        bags = Ui.vbox(this);
        bags.setPadding(Ui.dp(this, 6), 0, 0, 0);
        bagScroll.addView(bags);
        middle.addView(bagScroll, new LinearLayout.LayoutParams(Ui.dp(this, 100), ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(middle, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 3));

        // the selected item's info, at the bottom
        LinearLayout panel = Ui.card(this);
        detailName = Ui.text(this, "Tap an item to identify it", 15, true);
        panel.addView(detailName);
        detailRule = Ui.text(this, "", 14, true);
        detailRule.setTextColor(Ui.GREEN);
        detailRule.setVisibility(android.view.View.GONE);
        panel.addView(detailRule);
        detailScroll = new ScrollView(this);
        detail = Ui.text(this, "", 13, false);
        detail.setTextIsSelectable(true);
        detailScroll.addView(detail);
        panel.addView(detailScroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(panel, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 2));

        setContentView(PullRefresh.wrap(this, root, this::pullRefresh));
        load();
    }

    private void goBack() {
        finish();
        overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
    }

    @Override
    public boolean onCreateOptionsMenu(android.view.Menu m) {
        AccountMenu.build(m, "inventory");   // the character card's ⋮ menu, in the title bar
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(android.view.Menu m) {
        AccountMenu.prepare(m, account);
        return super.onPrepareOptionsMenu(m);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (AccountMenu.handle(this, item, account, getIntent().getStringExtra("title") == null ? account : getIntent().getStringExtra("title"), this::load)) return true;
        if (item.getItemId() == android.R.id.home) { goBack(); return true; }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() { main.removeCallbacksAndMessages(null); super.onDestroy(); }

    // swipe right anywhere: back to the session page
    private float swipeX, swipeY;
    private boolean swipeOk;

    @Override
    public boolean dispatchTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: swipeX = e.getRawX(); swipeY = e.getRawY(); swipeOk = true; break;
            case MotionEvent.ACTION_POINTER_DOWN: swipeOk = false; break;
            case MotionEvent.ACTION_UP: {
                float dx = e.getRawX() - swipeX, dy = e.getRawY() - swipeY;
                if (swipeOk && dx > Ui.dp(this, 110) && Math.abs(dx) > Math.abs(dy) * 2) { goBack(); return true; }
                break;
            }
        }
        return super.dispatchTouchEvent(e);
    }

    /** Pull down: MelkTank writes its status right away, then the page loads again. */
    private void pullRefresh(PullRefresh pr) {
        io.execute(() -> {
            try { if (account != null) Api.refresh(prefs, account); } catch (Exception ignored) { }
            main.postDelayed(() -> { load(); main.postDelayed(pr::done, 800); }, 2500);
        });
    }

    private void load() {
        io.execute(() -> {
            try {
                JSONObject j = Api.inventory(prefs, account);
                // MelkTank is still sending a bag from last time but this page starts on the main pack: tell it to stop
                if (!packAsked && openPack == 0 && j.optLong("openPack") != 0) { packAsked = true; Api.showPack(prefs, account, 0); }
                main.post(() -> { data = j; render(); });
            } catch (Exception e) {
                main.post(() -> status.setText(e.getMessage()));
            }
        });
    }

    private void render() {
        list.removeAllViews();
        selectedRow = null;
        if (data == null) return;
        status.setText("Updated " + Fmt.ago(data.optString("updated")));
        JSONArray a = data.optJSONArray("items");
        java.util.List<JSONObject> worn = new java.util.ArrayList<>(), packed = new java.util.ArrayList<>();
        for (int i = 0; a != null && i < a.length(); i++) {
            JSONObject it = a.optJSONObject(i);
            if (it == null) continue;
            boolean isWorn = !it.optString("eq").isEmpty();
            if (isWorn) { remember(it); worn.add(it); }
            else if (it.optLong("pk") == openPack) { recall(it); packed.add(it); }
            else continue;
            if (it.optLong("id") == selected) showDetail(it);
        }
        renderBags();
        String bagName = "Main pack";
        boolean bagLoaded = openPack == 0 || data.optLong("openPack") == openPack;
        JSONArray pk = data.optJSONArray("packs");
        for (int i = 0; pk != null && i < pk.length(); i++)
            if (pk.optJSONObject(i).optLong("id") == openPack) bagName = pk.optJSONObject(i).optString("n");
        // main pack sort: as it sits in the pack (the file's order), by type then name, or by name
        int sort = ui.getInt("sort", 0);
        if (sort == 1) java.util.Collections.sort(packed, (x, y) -> {
            int c = x.optString("c").compareToIgnoreCase(y.optString("c"));
            return c != 0 ? c : x.optString("n").compareToIgnoreCase(y.optString("n"));
        });
        else if (sort == 2) java.util.Collections.sort(packed, (x, y) -> x.optString("n").compareToIgnoreCase(y.optString("n")));

        LinearLayout eq = section("eq", "Equipped (" + worn.size() + ")", null);
        if (eq != null) {
            for (JSONObject it : worn) eq.addView(row(it, true));
            if (worn.isEmpty()) eq.addView(muted("Nothing equipped."));
        }
        TextView sortBtn = Ui.chip(this);
        sortBtn.setText("Sort: " + SORTS[sort] + " ▾");
        Ui.chipColor(this, sortBtn, Ui.GREY);
        sortBtn.setOnClickListener(v -> { ui.edit().putInt("sort", (ui.getInt("sort", 0) + 1) % SORTS.length).apply(); render(); });
        LinearLayout pack = section("pack", bagName + (bagLoaded ? " (" + packed.size() + ")" : ""), sortBtn);
        if (pack != null && !bagLoaded) pack.addView(muted("Loading..."));
        else if (pack != null) {
            String lastType = null;
            for (JSONObject it : packed) {
                if (sort == 1 && !it.optString("c").equals(lastType)) {
                    lastType = it.optString("c");
                    TextView h = Ui.text(this, lastType.isEmpty() ? "Other" : lastType, 13, true);
                    h.setTextColor(Ui.muted(this));
                    h.setPadding(0, Ui.dp(this, 8), 0, 0);
                    pack.addView(h);
                }
                pack.addView(row(it, false));
            }
            if (packed.isEmpty()) pack.addView(muted(openPack == 0 ? "The main pack is empty." : "This pack is empty."));
        }
    }

    /** The bag column: main pack, then each side pack in the game's order, with how full it is. */
    private void renderBags() {
        bags.removeAllViews();
        int mainCount = 0;
        JSONArray a = data.optJSONArray("items");
        for (int i = 0; a != null && i < a.length(); i++) {
            JSONObject it = a.optJSONObject(i);
            if (it != null && it.optString("eq").isEmpty() && it.optLong("pk") == 0) mainCount++;
        }
        bags.addView(bag(0, "Main pack", mainCount + ""));
        JSONArray pk = data.optJSONArray("packs");
        for (int i = 0; pk != null && i < pk.length(); i++) {
            JSONObject p = pk.optJSONObject(i);
            if (p == null) continue;
            int cap = p.optInt("cap");
            bags.addView(bag(p.optLong("id"), p.optString("n"), p.optInt("count") + (cap > 0 ? "/" + cap : "")));
        }
    }

    private android.view.View bag(long id, String name, String count) {
        LinearLayout b = Ui.vbox(this);
        int pad = Ui.dp(this, 6);
        b.setPadding(pad, pad, pad, pad);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setCornerRadius(Ui.dp(this, 6));
        bg.setColor(id == openPack ? Ui.lineColor(this) : Ui.cardColor(this));
        if (id == openPack) bg.setStroke(Ui.dp(this, 2), GOLD);
        b.setBackground(bg);
        TextView n = Ui.text(this, name, 12, id == openPack);
        b.addView(n);
        TextView c = Ui.text(this, count, 11, false);
        c.setTextColor(Ui.muted(this));
        b.addView(c);
        b.setOnClickListener(v -> openBag(id));
        // long-press: open it in the game's inventory window (and look at it with a PC screenshot); Main also closes it
        b.setOnLongClickListener(v -> {
            android.widget.PopupMenu m = new android.widget.PopupMenu(this, b);
            m.getMenu().add(0, 1, 0, id == 0 ? "Open inventory window in game" : "Open in game");
            m.getMenu().add(0, 2, 1, id == 0 ? "Open in game + PC screenshot" : "Open in game + PC screenshot");
            if (id == 0) m.getMenu().add(0, 3, 2, "Close inventory window in game");
            if (id == 0) m.getMenu().add(0, 4, 3, "Toggle window (if open / close got out of step)");
            m.setOnMenuItemClickListener(mi -> {
                if (mi.getItemId() == 4) { toggleWindow(); return true; }
                gameBag(id, mi.getItemId() == 3, mi.getItemId() == 2);
                return true;
            });
            m.show();
            return true;
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = Ui.dp(this, 6);
        b.setLayoutParams(lp);
        return b;
    }

    /** Clicks the game's backpack button once - for when the window was opened / closed by hand. */
    private void toggleWindow() {
        io.execute(() -> {
            String msg;
            try { msg = Api.toggleInventory(prefs, account).optString("message", "Sent."); } catch (Exception e) { msg = e.getMessage(); }
            String m = msg;
            main.post(() -> Toast.makeText(this, m, Toast.LENGTH_SHORT).show());
        });
    }

    /** In game: id = the bag to show in the inventory window (0 = main; game ids can be negative), close = close the
     *  window instead. shot = then a PC screenshot. */
    private void gameBag(long id, boolean close, boolean shot) {
        io.execute(() -> {
            String msg;
            try { msg = (close ? Api.closeInventory(prefs, account) : Api.openPackInGame(prefs, account, id)).optString("message", "Sent."); }
            catch (Exception e) { msg = e.getMessage(); }
            String m = msg;
            main.post(() -> {
                Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
                if (shot) main.postDelayed(() -> startActivity(new android.content.Intent(this, ScreenshotActivity.class)), 3000);
            });
        });
    }

    /** Shows a bag: the main pack is always in the file; a side pack is asked for (only when you pick it). */
    private void openBag(long id) {
        if (id == openPack) return;
        openPack = id;
        render();
        io.execute(() -> {
            try { Api.showPack(prefs, account, id); packAsked = true; }
            catch (Exception e) { String m = e.getMessage(); main.post(() -> Toast.makeText(this, m, Toast.LENGTH_SHORT).show()); return; }
            if (id != 0) { main.postDelayed(this::load, 1500); main.postDelayed(this::load, 4000); }
        });
    }

    /** A card with a tap-to-collapse header (remembered); returns the body to fill, or null while collapsed. */
    private LinearLayout section(String key, String title, android.view.View extra) {
        LinearLayout c = Ui.card(this);
        boolean open = ui.getBoolean("open_" + key, true);
        LinearLayout head = Ui.hbox(this);
        TextView t = Ui.text(this, (open ? "▾ " : "▸ ") + title, 16, true);
        head.addView(t, Ui.weight(1));
        if (extra != null && open) head.addView(extra);
        t.setOnClickListener(v -> { ui.edit().putBoolean("open_" + key, !open).apply(); render(); });
        c.addView(head);
        list.addView(c);
        if (!open) return null;
        LinearLayout body = Ui.vbox(this);
        c.addView(body);
        return body;
    }

    private TextView muted(String s) {
        TextView t = Ui.text(this, s, 13, false);
        t.setTextColor(Ui.muted(this));
        return t;
    }

    private TextView row(JSONObject it, boolean worn) {
        int q = it.optInt("q", 1);
        String label = (worn ? it.optString("eq") + ":  " : "") + it.optString("n") + (q > 1 ? "  ×" + Fmt.big(q) : "");
        TextView t = Ui.text(this, label, 14, false);
        int pad = Ui.dp(this, 6);
        t.setPadding(pad, pad, pad, pad);
        if (it.optString("d").isEmpty()) t.setTextColor(Ui.muted(this));   // not identified yet
        long id = it.optLong("id");
        if (id == selected) mark(t);
        t.setOnClickListener(v -> {
            // equipped items: the first tap shows the saved ID, a second tap on the same item identifies it again
            boolean again = id == selected;
            selected = id;
            mark(t);
            showDetail(it);
            // any item: a saved / known ID shows straight away; tapping it again identifies it again
            if (again || it.optString("d").isEmpty()) identify(id);
        });
        // long-press: a menu to use the item in game (pack items) or identify it
        t.setOnLongClickListener(v -> {
            // copy the item (its ID line, or just the name if it isn't identified yet), then the menu
            String copy = it.optString("d").isEmpty() ? it.optString("n") : it.optString("d");
            android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null) { cm.setPrimaryClip(android.content.ClipData.newPlainText("item", copy)); Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show(); }
            android.widget.PopupMenu m = new android.widget.PopupMenu(this, t);
            if (!worn) m.getMenu().add(0, 1, 0, "Use");   // any bag
            m.getMenu().add(0, 2, 1, "Identify");
            m.setOnMenuItemClickListener(mi -> {
                if (mi.getItemId() == 1) confirmUse(it);
                else { selected = id; mark(t); showDetail(it); identify(id); }
                return true;
            });
            m.show();
            return true;
        });
        return t;
    }

    private void confirmUse(JSONObject it) {
        long id = it.optLong("id");
        new android.app.AlertDialog.Builder(this)
                .setTitle("Use " + it.optString("n") + "?")
                .setMessage("MelkTank pauses combat, nav and looting, waits until the character is idle, uses it, then carries on.")
                .setPositiveButton("Use", (d, w) -> io.execute(() -> {
                    String msg;
                    try { msg = Api.useItem(prefs, account, id).optString("message", "Sent."); } catch (Exception e) { msg = e.getMessage(); }
                    String m = msg;
                    main.post(() -> {
                        Toast.makeText(this, m, Toast.LENGTH_LONG).show();
                        main.postDelayed(this::load, 6000);   // the stack count / item gone
                    });
                }))
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * Equipped items keep their last ID, saved per character and slot (so a swapped item just replaces the old one):
     * a fresh ID from the PC is saved; with none, the saved one is used if it's the same item.
     */
    private void remember(JSONObject it) {
        String key = "eq_" + account + "_" + it.optString("eq");
        try {
            if (!it.optString("d").isEmpty()) {
                JSONObject keep = new JSONObject().put("id", it.optLong("id")).put("d", it.optString("d"))
                        .put("r", it.optString("r")).put("at", System.currentTimeMillis());
                ui.edit().putString(key, keep.toString()).apply();
            } else {
                String saved = ui.getString(key, null);
                if (saved == null) return;
                JSONObject k = new JSONObject(saved);
                if (k.optLong("id") != it.optLong("id")) { ui.edit().remove(key).apply(); return; }   // a different item now
                it.put("d", k.optString("d")).put("r", k.optString("r")).put("savedAt", k.optLong("at"));
            }
        } catch (Exception ignored) { }
    }

    /**
     * Pack items: every ID the phone has seen is kept on the phone, per character and item (an item keeps its id for good,
     * through relogs and crashes), so it shows straight away next time even when the game has forgotten it.
     * A fresh ID from the PC replaces the saved one. The newest 1500 are kept.
     */
    private android.content.SharedPreferences ids() { return getSharedPreferences("inv_ids_" + account, MODE_PRIVATE); }

    private void recall(JSONObject it) {
        String key = String.valueOf(it.optLong("id"));
        try {
            android.content.SharedPreferences sp = ids();
            if (!it.optString("d").isEmpty()) {
                String saved = sp.getString(key, null);
                // only written when it changed (or once a day, to keep its date fresh for the trimming)
                if (saved != null) {
                    JSONObject k = new JSONObject(saved);
                    if (k.optString("d").equals(it.optString("d")) && k.optString("r").equals(it.optString("r"))
                            && System.currentTimeMillis() - k.optLong("at") < 86400000L) return;
                }
                sp.edit().putString(key, new JSONObject().put("d", it.optString("d")).put("r", it.optString("r"))
                        .put("at", System.currentTimeMillis()).toString()).apply();
                trimIds(sp);
            } else {
                String saved = sp.getString(key, null);
                if (saved == null) return;
                JSONObject k = new JSONObject(saved);
                it.put("d", k.optString("d")).put("r", k.optString("r")).put("savedAt", k.optLong("at"));
            }
        } catch (Exception ignored) { }
    }

    private void trimIds(android.content.SharedPreferences sp) {
        java.util.Map<String, ?> all = sp.getAll();
        if (all.size() <= 1500) return;
        java.util.List<java.util.Map.Entry<String, Long>> ages = new java.util.ArrayList<>();
        for (java.util.Map.Entry<String, ?> e : all.entrySet()) {
            long at = 0;
            try { at = new JSONObject(String.valueOf(e.getValue())).optLong("at"); } catch (Exception ignored) { }
            ages.add(new java.util.AbstractMap.SimpleEntry<>(e.getKey(), at));
        }
        java.util.Collections.sort(ages, (x, y) -> Long.compare(x.getValue(), y.getValue()));
        android.content.SharedPreferences.Editor ed = sp.edit();
        for (int i = 0; i < ages.size() - 1400; i++) ed.remove(ages.get(i).getKey());   // the oldest go
        ed.apply();
    }

    private void mark(TextView t) {
        if (selectedRow != null) selectedRow.setBackgroundColor(Color.TRANSPARENT);
        selectedRow = t;
        t.setBackgroundColor(Ui.lineColor(this));
    }

    private void showDetail(JSONObject it) {
        detailName.setText(it.optString("n"));
        detailName.setTextColor(GOLD);
        String rule = it.optString("r");
        detailRule.setText(rule.isEmpty() ? "" : "Loot rule: " + rule);
        detailRule.setVisibility(rule.isEmpty() ? android.view.View.GONE : android.view.View.VISIBLE);
        String d = it.optString("d");
        if (it.has("savedAt") && !d.isEmpty())
            d = d + "\n\n(Saved " + android.text.format.DateUtils.getRelativeTimeSpanString(it.optLong("savedAt")) + " - tap again to identify it again.)";
        else if (!d.isEmpty() && it.optLong("id") == selected)
            d = d + "\n\n(Tap again to identify it again.)";
        StringBuilder sb = new StringBuilder();
        if (!it.optString("eq").isEmpty()) sb.append("Equipped: ").append(it.optString("eq")).append('\n');
        if (!it.optString("c").isEmpty()) sb.append(it.optString("c")).append('\n');
        if (it.optInt("q", 1) > 1) sb.append("Stack: ").append(Fmt.big(it.optInt("q", 1))).append('\n');
        sb.append('\n').append(d.isEmpty() ? "Identifying..." : d);
        String text = sb.toString();
        long id = it.optLong("id");
        if (id == shownId && text.equals(detail.getText().toString())) return;   // nothing new: leave it (and where you scrolled to)
        detail.setText(text);
        if (id != shownId) detailScroll.scrollTo(0, 0);   // only a different item starts at its top
        shownId = id;
    }

    private long shownId = Long.MIN_VALUE;

    private void identify(long id) {
        io.execute(() -> {
            try { Api.identify(prefs, account, id); }
            catch (Exception e) { String m = e.getMessage(); main.post(() -> Toast.makeText(this, m, Toast.LENGTH_SHORT).show()); return; }
            // MelkTank rewrites the inventory ~2.5 s after the ID request (and again at 6 s for a slow one)
            main.postDelayed(this::load, 3500);
            main.postDelayed(this::load, 7500);
        });
    }
}
