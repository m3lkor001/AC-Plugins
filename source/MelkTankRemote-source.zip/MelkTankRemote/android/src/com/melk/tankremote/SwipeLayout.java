package com.melk.tankremote;

import android.content.Context;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.widget.LinearLayout;

/**
 * A card that can be swiped to the left (it follows the finger, then springs back). Taps, switches,
 * buttons and the page's up/down scrolling still work: only a mostly-sideways drag is taken over.
 */
class SwipeLayout extends LinearLayout {
    Runnable onSwipeLeft;
    private final int slop;
    private float downX, downY;
    private boolean dragging;

    SwipeLayout(Context c) {
        super(c);
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getRawX(); downY = e.getRawY(); dragging = false;
                break;
            case MotionEvent.ACTION_MOVE:
                float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                if (onSwipeLeft != null && dx < -slop * 2 && Math.abs(dx) > Math.abs(dy) * 2) {
                    dragging = true;
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                    return true;   // from here on the drag is ours
                }
                break;
        }
        return false;
    }

    private boolean longFired;
    private final Runnable longPress = () -> { if (!dragging) { longFired = true; performLongClick(); } };

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getRawX(); downY = e.getRawY();
                longFired = false;
                if (isLongClickable()) postDelayed(longPress, 550);
                return onSwipeLeft != null || isClickable();
            case MotionEvent.ACTION_MOVE: {
                float dx = e.getRawX() - downX;
                if (Math.abs(dx) > slop || Math.abs(e.getRawY() - downY) > slop) removeCallbacks(longPress);
                if (!dragging && dx < -slop * 2) {
                    dragging = true;
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                }
                if (dragging) setTranslationX(Math.min(0, dx) * 0.6f);
                return true;
            }
            case MotionEvent.ACTION_UP: {
                float dx = e.getRawX() - downX;
                removeCallbacks(longPress);
                // a tap (no drag, no long-press): the card's click
                if (!dragging && !longFired && Math.abs(dx) < slop && Math.abs(e.getRawY() - downY) < slop && isClickable()) performClick();
                boolean go = dragging && dx < -getWidth() * 0.25f;
                dragging = false;
                animate().translationX(0).setDuration(150).start();
                if (go && onSwipeLeft != null) onSwipeLeft.run();
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                removeCallbacks(longPress);
                dragging = false;
                animate().translationX(0).setDuration(150).start();
                return true;
        }
        return super.onTouchEvent(e);
    }
}
