package com.melk.tankremote;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The PC's local ACE server (swipe left on its card): a command from the list of those its console takes, what follows
 * it, Run - and its console output, the last 100 lines. Asked for every 2 s, and only while this page is open.
 */
public class ServerActivity extends Activity {
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private Prefs prefs;
    private TextView status, help, out;
    private ScrollView scroll;
    private Spinner pick;
    private EditText args;
    private final List<JSONObject> cmds = new ArrayList<>();
    private boolean shown, atBottom = true;
    private String mark = null;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        setTitle("ACE server");
        if (getActionBar() != null) getActionBar().setDisplayHomeAsUpEnabled(true);

        LinearLayout root = Ui.vbox(this);
        int p = Ui.dp(this, 10);
        root.setPadding(p, p, p, p);

        LinearLayout bar = Ui.hbox(this);
        Button back = new Button(this);
        back.setText("‹ Back");
        back.setOnClickListener(v -> finish());
        bar.addView(back);
        status = Ui.text(this, "Loading...", 13, false);
        status.setTextColor(Ui.muted(this));
        status.setPadding(Ui.dp(this, 8), 0, 0, 0);
        bar.addView(status, Ui.weight(1));
        root.addView(bar);

        LinearLayout row = Ui.hbox(this);
        pick = new Spinner(this);
        pick.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, android.view.View view, int position, long id) { picked(); }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        row.addView(pick, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.1f));
        args = new EditText(this);
        args.setSingleLine(true);
        args.setTextSize(14);
        args.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        args.setImeOptions(EditorInfo.IME_ACTION_GO);
        args.setOnEditorActionListener((v, id, e) -> { if (id == EditorInfo.IME_ACTION_GO) { run(); return true; } return false; });
        row.addView(args, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button go = new Button(this);
        go.setText("Run");
        go.setOnClickListener(v -> run());
        row.addView(go);
        root.addView(row);

        help = Ui.text(this, "", 12, false);
        help.setTextColor(Ui.muted(this));
        help.setPadding(0, 0, 0, Ui.dp(this, 6));
        root.addView(help);

        scroll = new ScrollView(this);
        scroll.setBackgroundColor(0xFF000000);
        scroll.setFocusable(false);
        out = new TextView(this);
        out.setTypeface(Typeface.MONOSPACE);
        out.setTextSize(11);
        out.setTextColor(0xFFD8D8D8);
        out.setTextIsSelectable(true);
        int q = Ui.dp(this, 6);
        out.setPadding(q, q, q, q);
        scroll.addView(out);
        scroll.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_UP)
                main.postDelayed(() -> atBottom = !scroll.canScrollVertically(1), 300);
            return false;
        });
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        setContentView(root);
        loadCommands();
    }

    @Override
    protected void onResume() { super.onResume(); shown = true; tick(); }

    @Override
    protected void onPause() { shown = false; main.removeCallbacksAndMessages(null); super.onPause(); }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) { finish(); return true; }
        return super.onOptionsItemSelected(item);
    }

    // swipe right anywhere: back to the main page
    private float swipeX, swipeY;
    private boolean swipeOk;

    @Override
    public boolean dispatchTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: swipeX = e.getRawX(); swipeY = e.getRawY(); swipeOk = true; break;
            case MotionEvent.ACTION_POINTER_DOWN: swipeOk = false; break;
            case MotionEvent.ACTION_UP: {
                float dx = e.getRawX() - swipeX, dy = e.getRawY() - swipeY;
                if (swipeOk && dx > Ui.dp(this, 110) && Math.abs(dx) > Math.abs(dy) * 2) { finish(); return true; }
                break;
            }
        }
        return super.dispatchTouchEvent(e);
    }

    private void tick() {
        if (!shown) return;
        load();
        main.postDelayed(this::tick, 2000);
    }

    private void loadCommands() {
        io.execute(() -> {
            try {
                JSONArray a = Api.aceCommands(prefs).optJSONArray("commands");
                List<JSONObject> got = new ArrayList<>();
                List<String> names = new ArrayList<>();
                for (int i = 0; a != null && i < a.length(); i++) {
                    JSONObject c = a.optJSONObject(i);
                    if (c == null) continue;
                    got.add(c);
                    names.add(c.optString("name"));
                }
                main.post(() -> {
                    cmds.clear();
                    cmds.addAll(got);
                    ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, names);
                    ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    pick.setAdapter(ad);
                    int s = names.indexOf("serverstatus");
                    if (s >= 0) pick.setSelection(s);
                    picked();
                });
            } catch (Exception e) {
                main.post(() -> help.setText("Couldn't get the command list: " + e.getMessage()));
            }
        });
    }

    private JSONObject current() {
        int i = pick.getSelectedItemPosition();
        return i >= 0 && i < cmds.size() ? cmds.get(i) : null;
    }

    private void picked() {
        JSONObject c = current();
        if (c == null) return;
        String usage = c.optString("usage");
        args.setHint(!usage.isEmpty() ? usage : c.optInt("args") == 0 ? "(nothing more)" : "arguments");
        help.setText(c.optString("help") + (usage.isEmpty() ? "" : "\nUsage: " + c.optString("name") + " " + usage));
    }

    private void run() {
        JSONObject c = current();
        if (c == null) return;
        String name = c.optString("name"), a = args.getText().toString().trim();
        atBottom = true;
        io.execute(() -> {
            String msg; boolean ok;
            try { JSONObject r = Api.aceCommand(prefs, name, a); ok = r.optBoolean("ok", true); msg = r.optString("message", "Sent."); }
            catch (Exception e) { ok = false; msg = e.getMessage(); }
            String m = msg; boolean good = ok;
            main.post(() -> {
                if (good) args.setText("");
                Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
                main.postDelayed(this::load, 600);
            });
        });
    }

    private void load() {
        io.execute(() -> {
            try {
                JSONObject j = Api.aceConsole(prefs);
                main.post(() -> {
                    boolean running = j.optBoolean("running"), ours = j.optBoolean("ours");
                    status.setText(!running ? "The server isn't running." : ours ? "Running" : "Running - started in a terminal: commands can't be sent to it from here.");
                    String m = j.optString("mark");
                    if (m.equals(mark)) return;
                    mark = m;
                    JSONArray a = j.optJSONArray("lines");
                    StringBuilder sb = new StringBuilder();
                    int from = a == null ? 0 : Math.max(0, a.length() - 100);   // (only ever the last 100 lines)
                    for (int i = from; a != null && i < a.length(); i++) { if (sb.length() > 0) sb.append('\n'); sb.append(a.optString(i)); }
                    out.setText(sb.length() > 0 ? sb : "No output yet. It's kept from when the server is started from the phone or the launcher; one started in a terminal writes to that terminal instead.");
                    if (atBottom) scroll.post(() -> scroll.scrollTo(0, Math.max(0, out.getHeight() - scroll.getHeight())));
                });
            } catch (Exception e) {
                main.post(() -> status.setText(e.getMessage()));
            }
        });
    }
}
