package com.melk.tankremote;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Talks to the MelkTank phone service on the PC (blocking calls - run them off the main thread). */
final class Api {
    private Api() {}

    static JSONObject status(Prefs p) throws Exception { return call(p, "GET", "/api/status", null); }

    static JSONObject set(Prefs p, String account, String feature, boolean on) throws Exception {
        JSONObject b = new JSONObject().put("account", account).put("action", "set").put("feature", feature).put("value", on ? "on" : "off");
        return call(p, "POST", "/api/command", b);
    }

    static JSONObject navRoute(Prefs p, String account, String route) throws Exception {
        return call(p, "POST", "/api/command", new JSONObject().put("account", account).put("action", "navroute").put("name", route));
    }

    static JSONObject metaLoad(Prefs p, String account, String meta) throws Exception {
        return call(p, "POST", "/api/command", new JSONObject().put("account", account).put("action", "metaload").put("name", meta));
    }

    static JSONObject navSpot(Prefs p, String account, String spot) throws Exception {
        return call(p, "POST", "/api/command", new JSONObject().put("account", account).put("action", "navspot").put("name", spot));
    }

    static JSONObject refresh(Prefs p, String account) throws Exception {
        return call(p, "POST", "/api/command", new JSONObject().put("account", account).put("action", "refresh"));
    }

    static JSONObject interval(Prefs p, int seconds) throws Exception {
        return call(p, "POST", "/api/interval", new JSONObject().put("seconds", seconds));
    }

    /** mode "normal" = MelkTank logs out and exits the game; "force" = the client process is ended. */
    static JSONObject close(Prefs p, String account, String mode, boolean relaunch) throws Exception {
        return call(p, "POST", "/api/kill", new JSONObject().put("account", account).put("mode", mode).put("relaunch", relaunch));
    }

    /** Closes every game client and stops Wine on the PC; relaunch = start the ticked accounts again. */
    static JSONObject reset(Prefs p, boolean relaunch) throws Exception {
        return call(p, "POST", "/api/reset", new JSONObject().put("relaunch", relaunch));
    }

    /** Decal's plugins: {"plugins": [{id, name, enabled, assembly}]}. */
    static JSONObject plugins(Prefs p) throws Exception { return call(p, "GET", "/api/plugins", null); }

    /** Turns a Decal plugin on / off (from the next game start). */
    static JSONObject setPlugin(Prefs p, String id, boolean on) throws Exception {
        return call(p, "POST", "/api/plugins", new JSONObject().put("id", id).put("enabled", on));
    }

    /** A real left (or right) click on the PC's screen at (x, y) in screenshot pixels. */
    static JSONObject clickScreen(Prefs p, float x, float y, boolean right) throws Exception {
        return call(p, "POST", "/api/click", new JSONObject().put("x", x).put("y", y).put("button", right ? "right" : "left"));
    }

    /** Drags on the PC's screen: the left button pressed at the first spot, let go at the second (screenshot pixels). */
    static JSONObject dragScreen(Prefs p, float x, float y, float toX, float toY) throws Exception {
        return call(p, "POST", "/api/click", new JSONObject().put("x", x).put("y", y).put("to_x", toX).put("to_y", toY));
    }

    /** Double-clicks a spot on the PC's screen (left button). */
    static JSONObject doubleClickScreen(Prefs p, float x, float y) throws Exception {
        return call(p, "POST", "/api/click", new JSONObject().put("x", x).put("y", y).put("button", "left").put("double", true));
    }

    /** Left-clicks a spot on the PC's screen, then types text there (with Enter after, if asked). */
    static JSONObject clickAndType(Prefs p, float x, float y, String text, boolean enter) throws Exception {
        return call(p, "POST", "/api/click", new JSONObject().put("x", x).put("y", y).put("button", "left").put("text", text).put("enter", enter));
    }

    /** Brings Decal's agent window to the front on the PC (starts the agent first if it isn't running). */
    static JSONObject showDecal(Prefs p) throws Exception {
        return call(p, "POST", "/api/decal", new JSONObject().put("action", "show"));
    }

    /** The PC's screen (JPEG bytes). */
    static byte[] screenshot(Prefs p) throws Exception {
        if (!p.configured()) throw new Exception("Set the PC address and app key in Settings.");
        URL url = new URL("http://" + p.host() + ":" + p.port() + "/api/screenshot");
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        try {
            c.setConnectTimeout(6000);
            c.setReadTimeout(30000);
            c.setRequestProperty("X-Token", p.key());
            int code = c.getResponseCode();
            if (code == 401) throw new Exception("The PC refused the app key - check it in Settings.");
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while (in != null && (n = in.read(buf)) > 0) out.write(buf, 0, n);
            if (in != null) in.close();
            if (code >= 400) {
                String err;
                try { err = new JSONObject(out.toString("UTF-8")).optString("error", "PC answered " + code); } catch (Exception e) { err = "PC answered " + code; }
                throw new Exception(err);
            }
            return out.toByteArray();
        } catch (java.net.SocketTimeoutException | java.net.ConnectException e) {
            throw new Exception("Can't reach the PC at " + p.host() + ":" + p.port() + " - is Tailscale on and the PC awake?");
        } finally {
            c.disconnect();
        }
    }

    /** This session for one account: numbers, kills per monster, looted items with their full ID lines. */
    static JSONObject session(Prefs p, String account) throws Exception {
        return call(p, "GET", "/api/session?account=" + java.net.URLEncoder.encode(account, "UTF-8"), null);
    }

    /** Gives this account's game window the focus on the PC (the game only draws in the focused window). */
    static JSONObject focus(Prefs p, String account) throws Exception {
        return call(p, "POST", "/api/focus", new JSONObject().put("account", account));
    }

    /** "start" or "stop" Decal's agent on the PC (stop also keeps the service from starting it again). */
    /** The PC's local ACE test server: start, stop or restart it. */
    static JSONObject ace(Prefs p, String action) throws Exception {
        return call(p, "POST", "/api/ace", new JSONObject().put("action", action));
    }

    /** The ACE server's console output: the last 100 lines, and a mark that changes when there's more. */
    static JSONObject aceConsole(Prefs p) throws Exception { return call(p, "GET", "/api/ace/console", null); }

    /** The commands the ACE server's console takes: {commands: [{name, help, usage, args}]}. */
    static JSONObject aceCommands(Prefs p) throws Exception { return call(p, "GET", "/api/ace/commands", null); }

    /** A command (and what follows it) typed into the ACE server's console. */
    static JSONObject aceCommand(Prefs p, String command, String args) throws Exception {
        return call(p, "POST", "/api/ace/command", new JSONObject().put("command", command).put("args", args));
    }

    /** How the PC's local ACE test server stands (running, answering, its database). */
    static JSONObject aceStatus(Prefs p) throws Exception { return call(p, "GET", "/api/ace", null); }

    static JSONObject decal(Prefs p, String action) throws Exception {
        return call(p, "POST", "/api/decal", new JSONObject().put("action", action));
    }

    /** Moves this account's game window to the top-left corner of the PC's screen (and focuses it). */
    static JSONObject moveWindow(Prefs p, String account) throws Exception {
        return call(p, "POST", "/api/movewindow", new JSONObject().put("account", account).put("x", 0).put("y", 0));
    }

    /** Takes the focus off the game windows on the PC (to the launcher or the desktop): their 3D drawing pauses. */
    static JSONObject unfocus(Prefs p) throws Exception {
        return call(p, "POST", "/api/unfocus", new JSONObject());
    }

    /** Live data on the PC: MelkTank writes every 2 s for the next 12 s (renewed with each refresh). */
    static void live(Prefs p, boolean on, boolean session) throws Exception { live(p, on, session, false); }

    static void live(Prefs p, boolean on, boolean session, boolean chat) throws Exception {
        call(p, "POST", "/api/live", new JSONObject().put("on", on).put("session", session).put("chat", chat));
    }

    /** The character's last 200 chat lines (each with a kind: tell, combat, pet, other). */
    static JSONObject inventory(Prefs p, String account) throws Exception {
        return call(p, "GET", "/api/inventory?account=" + java.net.URLEncoder.encode(account, "UTF-8"), null);
    }

    /** Identifies an item in game (the inventory page); MelkTank rewrites the inventory once the ID is in. */
    static JSONObject identify(Prefs p, String account, long id) throws Exception {
        return call(p, "POST", "/api/command", new JSONObject().put("account", account).put("action", "identify").put("id", id));
    }

    /** Starts a full rebuff now, or cancels one that's running. */
    /** Clears the character's session numbers in MelkTank (like the Session tab's Reset session). */
    static JSONObject resetSession(Prefs p, String account) throws Exception {
        return call(p, "POST", "/api/command", new JSONObject().put("account", account).put("action", "resetsession"));
    }

    static JSONObject rebuff(Prefs p, String account, boolean cancel) throws Exception {
        return call(p, "POST", "/api/command", new JSONObject().put("account", account).put("action", "rebuff").put("value", cancel ? "cancel" : "start"));
    }

    /** Uses an item in game: MelkTank pauses, uses it once the character is idle, then resumes. */
    static JSONObject useItem(Prefs p, String account, long id) throws Exception {
        return call(p, "POST", "/api/command", new JSONObject().put("account", account).put("action", "useitem").put("id", id));
    }

    /** Asks MelkTank for one side pack's contents (0 = just the main pack). */
    static JSONObject showPack(Prefs p, String account, long id) throws Exception {
        return call(p, "POST", "/api/command", new JSONObject().put("account", account).put("action", "showpack").put("id", id));
    }

    /** Shows a bag in the game's inventory window (opening the window if needed). */
    static JSONObject openPackInGame(Prefs p, String account, long id) throws Exception {
        return call(p, "POST", "/api/command", new JSONObject().put("account", account).put("action", "openpack").put("id", id));
    }

    static JSONObject toggleInventory(Prefs p, String account) throws Exception {
        return call(p, "POST", "/api/command", new JSONObject().put("account", account).put("action", "openpack").put("value", "toggle"));
    }

    static JSONObject closeInventory(Prefs p, String account) throws Exception {
        return call(p, "POST", "/api/command", new JSONObject().put("account", account).put("action", "openpack").put("value", "close"));
    }

    static JSONObject chat(Prefs p, String account) throws Exception {
        return call(p, "GET", "/api/chat?account=" + java.net.URLEncoder.encode(account, "UTF-8"), null);
    }

    /** Sends all but 1 of the bank's luminance (kind "l") or enlightened coins ("e") to another character. */
    static JSONObject bankTransfer(Prefs p, String account, String kind, String target) throws Exception {
        return call(p, "POST", "/api/command", new JSONObject().put("account", account).put("action", "banktransfer").put("kind", kind).put("target", target));
    }

    /** Sends a chat line or command in game; wait = only once the character isn't busy. */
    /** One character's MelkTank settings, tuning and snapshots. */
    static JSONObject mtSettings(Prefs p, String account) throws Exception {
        return call(p, "GET", "/api/settings?account=" + java.net.URLEncoder.encode(account, "UTF-8"), null);
    }

    /** MelkTank's Settings > Commands: the whole list back (every character's), with the mtime it was read at. */
    static JSONObject saveLoginCmds(Prefs p, String account, JSONArray commands, double mtime) throws Exception {
        // (the account says which MelkTank's list: an ACGodot one keeps its own)
        return call(p, "POST", "/api/logincmds", new JSONObject().put("account", account).put("commands", commands).put("mtime", mtime));
    }

    static JSONObject mtSettingsApply(Prefs p, String account, JSONObject changes) throws Exception {
        return call(p, "POST", "/api/settings", new JSONObject().put("account", account).put("changes", changes));
    }

    /** Items > Organize: the switch, status, rules, packs and the lists to pick from. */
    static JSONObject organize(Prefs p, String account) throws Exception {
        return call(p, "GET", "/api/organize?account=" + java.net.URLEncoder.encode(account, "UTF-8"), null);
    }

    /** what = run / on / off / rules (rules = the whole list, MelkTank's format). */
    static JSONObject organizeCmd(Prefs p, String account, String what, String rules) throws Exception {
        JSONObject b = new JSONObject().put("account", account).put("action", "organize").put("value", what);
        if (rules != null) b.put("rules", rules);
        return call(p, "POST", "/api/command", b);
    }

    static JSONObject snapshot(Prefs p, String account, String action, String name) throws Exception {
        return call(p, "POST", "/api/snapshot", new JSONObject().put("account", account).put("action", action).put("name", name));
    }

    /** /mtank note: a marked line in the character's logs. */
    static JSONObject note(Prefs p, String account, String text) throws Exception {
        return call(p, "POST", "/api/command", new JSONObject().put("account", account).put("action", "note").put("text", text));
    }

    static JSONObject sendChat(Prefs p, String account, String text, boolean wait) throws Exception {
        return call(p, "POST", "/api/command", new JSONObject().put("account", account).put("action", "chat").put("text", text).put("wait", wait));
    }

    // ── loot editor (the .utl profiles on the PC) ──
    /** MelkTank's running build and the previous one (MelkTankCore.dll / .old.dll). */
    static JSONObject builds(Prefs p) throws Exception { return call(p, "GET", "/api/builds", null); }

    /** Swaps the running MelkTank build with the previous one (again = undo); the game reloads it by itself. */
    static JSONObject rollback(Prefs p) throws Exception { return call(p, "POST", "/api/rollback", new JSONObject()); }

    static JSONObject lootSpec(Prefs p) throws Exception { return call(p, "GET", "/api/loot/spec", null); }
    static JSONObject lootList(Prefs p) throws Exception { return call(p, "GET", "/api/loot/list", null); }
    static JSONObject lootProfile(Prefs p, String name) throws Exception {
        return call(p, "GET", "/api/loot/profile?name=" + java.net.URLEncoder.encode(name, "UTF-8"), null);
    }
    /** Saves (push = running characters read it again). A 409 answer (changed on the PC) comes back with "error" and no "ok". */
    static JSONObject lootSave(Prefs p, String name, long mtime, JSONObject profile, boolean push, boolean force) throws Exception {
        return call(p, "POST", "/api/loot/profile", new JSONObject().put("name", name).put("mtime", mtime).put("profile", profile)
                .put("push", push).put("force", force));
    }
    static JSONObject lootPush(Prefs p, String name) throws Exception {
        return call(p, "POST", "/api/loot/push", new JSONObject().put("name", name));
    }
    /** A new requirement for field f (row == null), or an edited row, as the file will have it. */
    static JSONObject lootRow(Prefs p, int f, JSONObject row) throws Exception {
        JSONObject b = new JSONObject();
        if (row != null) b.put("row", row); else b.put("f", f);
        return call(p, "POST", "/api/loot/row", b);
    }

    /** The client history (newest first) and a summary of the last 24 hours per account. account "" = all. */
    static JSONObject events(Prefs p, String account) throws Exception {
        return call(p, "GET", "/api/events?limit=400" + (account == null || account.isEmpty() ? "" : "&account=" + java.net.URLEncoder.encode(account, "UTF-8")), null);
    }

    // the route and meta editors (files in MelkTank's Profiles\Navs and Profiles\Metas)
    private static String q(String s) throws Exception { return java.net.URLEncoder.encode(s == null ? "" : s, "UTF-8"); }
    static JSONObject navs(Prefs p) throws Exception { return call(p, "GET", "/api/navs", null); }
    static JSONObject nav(Prefs p, String file) throws Exception { return call(p, "GET", "/api/nav?file=" + q(file), null); }
    static JSONObject navSave(Prefs p, String file, long mtime, JSONObject data, boolean force) throws Exception {
        return call(p, "POST", "/api/nav/save", new JSONObject().put("file", file).put("mtime", mtime).put("data", data).put("force", force));
    }
    static JSONObject navNew(Prefs p, String name, String copyOf) throws Exception {
        JSONObject b = new JSONObject().put("name", name);
        if (copyOf != null) b.put("copy", copyOf);
        return call(p, "POST", "/api/nav/new", b);
    }
    static JSONObject navDelete(Prefs p, String file) throws Exception { return call(p, "POST", "/api/nav/delete", new JSONObject().put("file", file)); }
    static JSONObject preset(Prefs p, String name) throws Exception { return call(p, "GET", "/api/preset?name=" + q(name), null); }
    static JSONObject presetSave(Prefs p, String old, long mtime, JSONObject data, boolean force) throws Exception {
        return call(p, "POST", "/api/preset/save", new JSONObject().put("old", old).put("mtime", mtime).put("data", data).put("force", force));
    }
    static JSONObject presetNew(Prefs p, String name, String copyOf) throws Exception {
        JSONObject b = new JSONObject().put("name", name);
        if (copyOf != null) b.put("copy", copyOf);
        return call(p, "POST", "/api/preset/new", b);
    }
    static JSONObject presetDelete(Prefs p, String name) throws Exception { return call(p, "POST", "/api/preset/delete", new JSONObject().put("name", name)); }
    static JSONObject metas(Prefs p) throws Exception { return call(p, "GET", "/api/metas", null); }
    static JSONObject meta(Prefs p, String file) throws Exception { return call(p, "GET", "/api/meta?file=" + q(file), null); }
    static JSONObject metaSave(Prefs p, String file, long mtime, JSONObject data, boolean force) throws Exception {
        return call(p, "POST", "/api/meta/save", new JSONObject().put("file", file).put("mtime", mtime).put("data", data).put("force", force));
    }
    static JSONObject metaNew(Prefs p, String name, String copyOf) throws Exception {
        JSONObject b = new JSONObject().put("name", name);
        if (copyOf != null) b.put("copy", copyOf);
        return call(p, "POST", "/api/meta/new", b);
    }
    static JSONObject metaDelete(Prefs p, String file) throws Exception { return call(p, "POST", "/api/meta/delete", new JSONObject().put("file", file)); }

    static JSONObject launch(Prefs p, String account) throws Exception {
        return call(p, "POST", "/api/launch", new JSONObject().put("account", account));
    }

    private static JSONObject call(Prefs p, String method, String path, JSONObject body) throws Exception {
        if (!p.configured()) throw new Exception("Set the PC address and app key in Settings.");
        URL url = new URL("http://" + p.host() + ":" + p.port() + path);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        try {
            c.setConnectTimeout(6000);
            c.setReadTimeout(10000);
            c.setRequestMethod(method);
            c.setRequestProperty("X-Token", p.key());
            c.setRequestProperty("Accept", "application/json");
            if (body != null) {
                byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                c.setFixedLengthStreamingMode(data.length);
                try (OutputStream os = c.getOutputStream()) { os.write(data); }
            }
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String text = in == null ? "{}" : read(in);
            JSONObject json;
            try { json = new JSONObject(text); } catch (Exception e) { json = new JSONObject(); }
            if (code == 401) throw new Exception("The PC refused the app key - check it in Settings.");
            if (code >= 400 && code != 409) throw new Exception(json.optString("error", "PC answered " + code));
            return json;
        } catch (java.net.SocketTimeoutException | java.net.ConnectException e) {
            throw new Exception("Can't reach the PC at " + p.host() + ":" + p.port() + " - is Tailscale on and the PC awake?");
        } finally {
            c.disconnect();
        }
    }

    private static String read(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return out.toString("UTF-8");
    }
}
