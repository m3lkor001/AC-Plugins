package com.melk.tankremote;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;

import org.json.JSONObject;

/**
 * Health / stamina / mana as the game draws them: three stacked bars in a dark bevelled frame - red, yellow, blue -
 * each lit at the top and darker below, with "now/max" in small white text with a dark outline in the middle.
 * Fed from the status (hp/hpMax, st/stMax, mp/mpMax). Hidden until MelkTank sends them.
 */
public class VitalBars extends View {
    private int hp, hpMax, st, stMax, mp, mpMax;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), frame = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG), outline = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final float d;

    // the game's colours: fill top / fill bottom / empty part
    private static final int[][] COLORS = {
            {Color.rgb(255, 70, 60), Color.rgb(150, 8, 8), Color.rgb(48, 6, 6)},       // health
            {Color.rgb(255, 228, 90), Color.rgb(176, 120, 0), Color.rgb(52, 38, 4)},   // stamina
            {Color.rgb(90, 150, 255), Color.rgb(10, 40, 160), Color.rgb(6, 14, 50)},   // mana
    };

    public VitalBars(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        Typeface tf = Typeface.create(Typeface.SERIF, Typeface.BOLD);   // the game's labels are a small serif
        text.setTypeface(tf);
        text.setColor(Color.WHITE);
        text.setTextAlign(Paint.Align.CENTER);
        text.setTextSize(10.5f * d);
        outline.setTypeface(tf);
        outline.setColor(Color.BLACK);
        outline.setTextAlign(Paint.Align.CENTER);
        outline.setTextSize(10.5f * d);
        outline.setStyle(Paint.Style.STROKE);
        outline.setStrokeWidth(2.2f * d);
        setVisibility(GONE);
    }

    /** Takes the values from a status entry; hides itself when there are none. */
    public void set(JSONObject a) {
        if (a == null || !a.has("hpMax") || a.optInt("hpMax") <= 0) { setVisibility(GONE); return; }
        hp = a.optInt("hp"); hpMax = a.optInt("hpMax");
        st = a.optInt("st"); stMax = a.optInt("stMax");
        mp = a.optInt("mp"); mpMax = a.optInt("mpMax");
        setVisibility(VISIBLE);
        invalidate();
    }

    @Override
    protected void onMeasure(int w, int h) {
        int width = MeasureSpec.getSize(w);
        setMeasuredDimension(width, Math.round((3 * 15 + 2 * 2 + 6) * d));
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), pad = 3 * d, barH = 15 * d, gap = 2 * d;
        // the panel: near-black with a lighter bevel, like the game's vitals box
        frame.setStyle(Paint.Style.FILL);
        frame.setColor(Color.rgb(14, 12, 10));
        r.set(0, 0, w, getHeight());
        c.drawRoundRect(r, 3 * d, 3 * d, frame);
        frame.setStyle(Paint.Style.STROKE);
        frame.setStrokeWidth(1 * d);
        frame.setColor(Color.rgb(96, 84, 64));
        r.inset(0.5f * d, 0.5f * d);
        c.drawRoundRect(r, 3 * d, 3 * d, frame);

        int[] cur = {hp, st, mp}, max = {hpMax, stMax, mpMax};
        for (int i = 0; i < 3; i++) {
            float top = pad + i * (barH + gap), left = pad, right = w - pad, bottom = top + barH;
            int[] col = COLORS[i];
            // empty part
            fill.setShader(null);
            fill.setColor(col[2]);
            c.drawRect(left, top, right, bottom, fill);
            // filled part: lit at the top, darker at the bottom
            float f = max[i] > 0 ? Math.max(0f, Math.min(1f, cur[i] / (float) max[i])) : 0f;
            if (f > 0) {
                fill.setShader(new LinearGradient(0, top, 0, bottom, new int[]{col[0], col[1], col[1]}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
                c.drawRect(left, top, left + (right - left) * f, bottom, fill);
                fill.setShader(null);
                // the shine along the top
                fill.setColor(Color.argb(70, 255, 255, 255));
                c.drawRect(left, top, left + (right - left) * f, top + barH * 0.22f, fill);
            }
            // each bar's thin dark edge
            frame.setStyle(Paint.Style.STROKE);
            frame.setStrokeWidth(1 * d);
            frame.setColor(Color.rgb(0, 0, 0));
            c.drawRect(left, top, right, bottom, frame);
            // "now/max" in the middle
            String s = String.format(java.util.Locale.US, "%,d/%,d", cur[i], max[i]);
            float ty = top + barH / 2 - (text.descent() + text.ascent()) / 2;
            c.drawText(s, w / 2, ty, outline);
            c.drawText(s, w / 2, ty, text);
        }
    }
}
