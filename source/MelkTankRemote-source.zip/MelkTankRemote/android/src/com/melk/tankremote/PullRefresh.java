package com.melk.tankremote;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

/**
 * Pull down to refresh, on any page: drag down while what's under your finger is at its top, and a round refresh
 * icon comes down with you; let go past the line and it spins while the page asks for fresh data (onRefresh).
 * It stops by itself after a few seconds (or when done() is called). Sideways drags (card swipes) and scrolling
 * a list that isn't at its top are left alone.
 */
class PullRefresh extends FrameLayout {
    interface OnRefresh { void run(PullRefresh pr); }

    private final OnRefresh onRefresh;
    private final FrameLayout bubble;
    private final TextView arrow;
    private final ProgressBar spinner;
    private final int slop, trigger, maxPull, size;
    private float downX, downY;
    private boolean pulling, busy;
    private final Runnable autoDone = this::done;

    /** Wraps a page's content: setContentView(PullRefresh.wrap(this, root, pr -> ...)). */
    static PullRefresh wrap(Activity a, View content, OnRefresh onRefresh) {
        PullRefresh pr = new PullRefresh(a, onRefresh);
        pr.addView(content, 0, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return pr;
    }

    private PullRefresh(Activity a, OnRefresh onRefresh) {
        super(a);
        this.onRefresh = onRefresh;
        slop = ViewConfiguration.get(a).getScaledTouchSlop();
        size = Ui.dp(a, 42);
        trigger = Ui.dp(a, 80);
        maxPull = Ui.dp(a, 130);

        bubble = new FrameLayout(a);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Ui.dark(a) ? Color.rgb(60, 64, 70) : Color.WHITE);
        bg.setStroke(Ui.dp(a, 1), Ui.lineColor(a));
        bubble.setBackground(bg);
        bubble.setElevation(Ui.dp(a, 6));
        arrow = new TextView(a);
        arrow.setText("↻");
        arrow.setTextSize(22);
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(Ui.GREEN);
        bubble.addView(arrow, new LayoutParams(size, size));
        spinner = new ProgressBar(a);
        int pad = Ui.dp(a, 8);
        spinner.setPadding(pad, pad, pad, pad);
        spinner.setVisibility(GONE);
        bubble.addView(spinner, new LayoutParams(size, size));
        LayoutParams lp = new LayoutParams(size, size, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        addView(bubble, lp);
        bubble.setTranslationY(-size * 1.5f);
        bubble.setAlpha(0f);
    }

    /** The spinning is over (it also stops by itself after a few seconds). */
    void done() {
        removeCallbacks(autoDone);
        busy = false;
        bubble.animate().translationY(-size * 1.5f).alpha(0f).setDuration(200).withEndAction(() -> {
            spinner.setVisibility(GONE);
            arrow.setVisibility(VISIBLE);
        }).start();
    }

    // Watched in dispatchTouchEvent (not onInterceptTouchEvent): a ScrollView asks its parents not to intercept as soon
    // as it starts a drag - even at its top - so an intercept never saw the pull.
    private boolean armed;

    @Override
    public boolean dispatchTouchEvent(MotionEvent e) {
        if (busy) return super.dispatchTouchEvent(e);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX(); downY = e.getY(); pulling = false;
                armed = !canScrollUpAt(getChildAt(0), downX, downY);
                return super.dispatchTouchEvent(e);
            case MotionEvent.ACTION_MOVE: {
                if (pulling) { drag(e.getY() - downY); return true; }
                float dx = e.getX() - downX, dy = e.getY() - downY;
                if (armed && dy > slop && dy > Math.abs(dx) * 1.5f && !canScrollUpAt(getChildAt(0), downX, downY)) {
                    pulling = true;
                    MotionEvent c = MotionEvent.obtain(e);
                    c.setAction(MotionEvent.ACTION_CANCEL);
                    super.dispatchTouchEvent(c);   // the page lets go of this touch (no tap, no scroll)
                    c.recycle();
                    downY = e.getY() - slop;
                    drag(e.getY() - downY);
                    return true;
                }
                if (dy < -slop || Math.abs(dx) > slop * 2) armed = false;
                return super.dispatchTouchEvent(e);
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (pulling) {
                    pulling = false;
                    float d = Math.min(maxPull, Math.max(0, e.getY() - downY) * 0.55f);
                    if (e.getActionMasked() == MotionEvent.ACTION_UP && d >= trigger) start(); else done();
                    return true;
                }
                return super.dispatchTouchEvent(e);
        }
        return super.dispatchTouchEvent(e);
    }

    private void drag(float dy) {
        float d = Math.min(maxPull, Math.max(0, dy) * 0.55f);
        bubble.animate().cancel();
        bubble.setAlpha(Math.min(1f, d / trigger));
        bubble.setTranslationY(d - size);
        arrow.setRotation(d * 2.5f);
        arrow.setTextColor(d >= trigger ? Ui.GREEN : Ui.muted(getContext()));
    }

    private void start() {
        busy = true;
        arrow.setVisibility(GONE);
        spinner.setVisibility(VISIBLE);
        bubble.setAlpha(1f);
        bubble.animate().translationY(trigger * 0.6f).setDuration(150).start();
        postDelayed(autoDone, 5000);
        try { onRefresh.run(this); } catch (Exception ignored) { done(); }
    }

    /** Is something under (x, y) - a list, a scrolled page - not at its top (so a drag down should scroll it)? */
    private static boolean canScrollUpAt(View v, float x, float y) {
        if (v == null || v.getVisibility() != VISIBLE) return false;
        if (v.canScrollVertically(-1)) return true;
        if (!(v instanceof ViewGroup)) return false;
        ViewGroup g = (ViewGroup) v;
        float sx = x + g.getScrollX(), sy = y + g.getScrollY();
        for (int i = g.getChildCount() - 1; i >= 0; i--) {
            View c = g.getChildAt(i);
            float cx = sx - c.getLeft() - c.getTranslationX(), cy = sy - c.getTop() - c.getTranslationY();
            if (cx >= 0 && cy >= 0 && cx < c.getWidth() && cy < c.getHeight() && canScrollUpAt(c, cx, cy)) return true;
        }
        return false;
    }
}
