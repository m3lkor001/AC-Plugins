package com.melk.tankremote;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DateFormat;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * One character's chat: the last 200 lines (refreshed every 3 s while this page is open), filters for kills /
 * damage and pet lines, and a box to send a line or command in game - optionally only once the character isn't busy.
 */
public class ChatActivity extends Activity {
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private Prefs prefs;
    private String account;
    private TextView status, doing;
    private LinearLayout lines;
    private ScrollView scroll;
    private EditText input;
    private CheckBox waitBox;
    private JSONObject data;
    private boolean shown, atBottom = true;
    private String lastUpdated = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        account = getIntent().getStringExtra("account");
        String title = getIntent().getStringExtra("title");
        setTitle("Chat - " + (title == null || title.isEmpty() ? account : title));
        if (getActionBar() != null) getActionBar().setDisplayHomeAsUpEnabled(true);

        LinearLayout root = Ui.vbox(this);
        int p = Ui.dp(this, 10);
        root.setPadding(p, p, p, p);

        LinearLayout bar = Ui.hbox(this);
        Button back = new Button(this);
        back.setText("‹ Back");
        back.setOnClickListener(v -> finish());
        bar.addView(back);
        status = Ui.text(this, "Loading...", 13, false);
        status.setTextColor(Ui.muted(this));
        status.setPadding(Ui.dp(this, 8), 0, 0, 0);
        bar.addView(status, Ui.weight(1));
        root.addView(bar);

        doing = Ui.text(this, "", 15, true);   // what MelkTank is doing right now
        doing.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 4));
        doing.setTextColor(0xFF8FE08F);
        root.addView(doing);

        LinearLayout filters = Ui.hbox(this);
        filters.addView(filter("combat", "Hide kills / damage"));
        filters.addView(filter("pet", "Hide pet"));
        filters.addView(filter("plugin", "Hide plugins"));
        root.addView(filters);
        LinearLayout only = Ui.hbox(this);
        only.addView(filter("other", "Tells only"));
        only.addView(filter("chanonly", "Channels only"));
        root.addView(only);

        scroll = new ScrollView(this);
        scroll.setFocusable(false);
        lines = Ui.vbox(this);
        // the chat lines never take the focus: the typing box keeps it while the list refreshes
        lines.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        scroll.addView(lines);
        scroll.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_UP)
                main.postDelayed(() -> atBottom = !scroll.canScrollVertically(1), 300);
            return false;
        });
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        LinearLayout send = Ui.hbox(this);
        input = new EditText(this);
        input.setHint("Say something, or /command");
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setOnEditorActionListener((v, id, e) -> { if (id == EditorInfo.IME_ACTION_SEND) { sendNow(); return true; } return false; });
        send.addView(input, Ui.weight(1));
        Button go = new Button(this);
        go.setText("Send");
        go.setOnClickListener(v -> sendNow());
        send.addView(go);
        root.addView(send);
        waitBox = new CheckBox(this);
        waitBox.setText("Wait until not busy (cleared after sending)");
        root.addView(waitBox);

        // bank buttons: deposit the pack (when idle), and all but 1 lum / enlightened coins to another character
        LinearLayout bank = Ui.hbox(this);
        Button dep = new Button(this);
        dep.setText("Deposit");
        dep.setOnClickListener(v -> send("/b d", true));
        bank.addView(dep, Ui.weight(1));
        Button lum = new Button(this);
        lum.setText("Lum \u2192");
        lum.setOnClickListener(v -> transfer("l"));
        bank.addView(lum, Ui.weight(1));
        Button coins = new Button(this);
        coins.setText("Coins \u2192");
        coins.setOnClickListener(v -> transfer("e"));
        bank.addView(coins, Ui.weight(1));
        root.addView(bank);
        LinearLayout toRow = Ui.hbox(this);
        TextView toL = Ui.text(this, "Transfers go to: ", 13, false);
        toL.setTextColor(Ui.muted(this));
        toRow.addView(toL);
        others = getIntent().getStringArrayListExtra("others");
        if (others == null) others = new java.util.ArrayList<>();
        toPick = new android.widget.Spinner(this);
        android.widget.ArrayAdapter<String> ta = new android.widget.ArrayAdapter<>(this, android.R.layout.simple_spinner_item,
                others.isEmpty() ? new String[]{"(no other character known)"} : others.toArray(new String[0]));
        ta.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        toPick.setAdapter(ta);
        int pre = others.indexOf(prefs.transferTo(account));
        if (pre >= 0) toPick.setSelection(pre);
        toPick.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int position, long id) {
                if (position < others.size()) prefs.transferTo(account, others.get(position));
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });
        toRow.addView(toPick, Ui.weight(1));
        root.addView(toRow);

        setContentView(PullRefresh.wrap(this, root, this::pullRefresh));
    }

    private CheckBox filter(String kind, String label) {
        CheckBox c = new CheckBox(this);
        c.setText(label);
        c.setTextSize(13);
        c.setChecked(prefs.chatHide(kind));
        c.setOnCheckedChangeListener((b2, on) -> { prefs.chatHide(kind, on); render(); });
        return c;
    }

    @Override
    protected void onResume() { super.onResume(); shown = true; tick(); }

    @Override
    protected void onPause() { shown = false; main.removeCallbacksAndMessages(null); super.onPause(); }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) { finish(); return true; }
        return super.onOptionsItemSelected(item);
    }

    private void tick() {
        if (!shown) return;
        load();
        main.postDelayed(this::tick, 3000);
    }

    /** Pull down: MelkTank writes its status right away, then the page loads again. */
    private void pullRefresh(PullRefresh pr) {
        io.execute(() -> {
            try { if (account != null) Api.refresh(prefs, account); } catch (Exception ignored) { }
            main.postDelayed(() -> { load(); main.postDelayed(pr::done, 800); }, 2500);
        });
    }

    private void load() {
        io.execute(() -> {
            try {
                try { Api.live(prefs, true, false, true); } catch (Exception ignored) { }   // MelkTank writes the chat every 2 s
                JSONObject j = Api.chat(prefs, account);
                main.post(() -> {
                    data = j;
                    String up = j.optString("updated");
                    if (!up.equals(lastUpdated)) { lastUpdated = up; render(); }
                    JSONArray w = j.optJSONArray("waiting");
                    String d = j.optString("doing");
                    doing.setText(d.isEmpty() ? "" : d);
                    doing.setVisibility(d.isEmpty() ? android.view.View.GONE : android.view.View.VISIBLE);
                    status.setText("Updated " + Fmt.ago(up) + (w != null && w.length() > 0 ? " · " + w.length() + " waiting to send" : ""));
                });
            } catch (Exception e) {
                main.post(() -> status.setText(e.getMessage()));
            }
        });
    }

    private void render() {
        lines.removeAllViews();
        if (data == null) return;
        JSONArray a = data.optJSONArray("lines");
        boolean hideCombat = prefs.chatHide("combat"), hidePet = prefs.chatHide("pet"), hidePlugin = prefs.chatHide("plugin"), tellsOnly = prefs.chatHide("other"), chanOnly = prefs.chatHide("chanonly");
        // tells only: every tell MelkTank kept (this session, or earlier ones too), not just those in the last 200 lines
        if (tellsOnly && !chanOnly && data.optJSONArray("tells") != null) a = data.optJSONArray("tells");
        int n = 0;
        for (int i = 0; a != null && i < a.length(); i++) {
            JSONObject l = a.optJSONObject(i);
            if (l == null) continue;
            String k = l.optString("k");
            if ((tellsOnly || chanOnly) && !((tellsOnly && k.equals("tell")) || (chanOnly && k.equals("channel")))) continue;   // both ticked: tells and channels
            if (hideCombat && k.equals("combat")) continue;
            if (hidePet && k.equals("pet")) continue;
            if (hidePlugin && (k.equals("plugin") || k.equals("melktank"))) continue;   // plugins' own lines (MelkTank's too)
            long t = Fmt.time(l.optString("t"));
            TextView tv = Ui.text(this, (t > 0 ? DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date(t)) + "  " : "") + l.optString("x"), 14, false);
            if (k.equals("tell")) tv.setTextColor(Ui.AMBER);
            else if (k.equals("channel")) tv.setTextColor(0xFF7FC8FF);
            else if (k.equals("combat") || k.equals("pet")) tv.setTextColor(Ui.muted(this));
            tv.setPadding(0, Ui.dp(this, 2), 0, Ui.dp(this, 2));
            String copy = l.optString("x");
            tv.setOnLongClickListener(v -> {
                android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("chat", copy));
                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show();
                return true;
            });
            lines.addView(tv);
            n++;
        }
        if (n == 0) lines.addView(Ui.text(this, "Nothing to show yet.", 13, false));
        // scrollTo, not fullScroll: fullScroll moves the focus too (away from the typing box)
        if (atBottom) scroll.post(() -> scroll.scrollTo(0, Math.max(0, lines.getHeight() - scroll.getHeight())));
    }

    private java.util.ArrayList<String> others;
    private android.widget.Spinner toPick;

    private void transfer(String kind) {
        if (others.isEmpty()) { Toast.makeText(this, "No other character known yet.", Toast.LENGTH_SHORT).show(); return; }
        String to = others.get(Math.max(0, Math.min(others.size() - 1, toPick.getSelectedItemPosition())));
        String what = kind.equals("l") ? "luminance" : "enlightened coins";
        new android.app.AlertDialog.Builder(this)
                .setTitle("Transfer " + what)
                .setMessage("Send all of the bank's " + what + " except 1 to " + to + "?\n\n(The amount is read from /bank right before sending.)")
                .setPositiveButton("Send", (d, w) -> io.execute(() -> {
                    String msg;
                    try { msg = Api.bankTransfer(prefs, account, kind, to).optString("message", "Sent."); } catch (Exception e) { msg = e.getMessage(); }
                    String m = msg;
                    main.post(() -> { Toast.makeText(this, m, Toast.LENGTH_LONG).show(); main.postDelayed(this::load, 3000); });
                }))
                .setNegativeButton("Cancel", null)
                .show();
    }

    /** A fixed command (the Deposit button): sent like a typed line, the wait box doesn't apply. */
    private void send(String text, boolean wait) {
        io.execute(() -> {
            String msg;
            try { msg = Api.sendChat(prefs, account, text, wait).optString("message", "Sent."); } catch (Exception e) { msg = e.getMessage(); }
            String m = msg;
            main.post(() -> { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); main.postDelayed(this::load, 1500); });
        });
    }

    private void sendNow() {
        String text = input.getText().toString().trim();
        if (text.isEmpty()) return;
        boolean wait = waitBox.isChecked();
        input.setText("");
        waitBox.setChecked(false);   // one line at a time: cleared after each send
        atBottom = true;
        io.execute(() -> {
            String msg;
            try { msg = Api.sendChat(prefs, account, text, wait).optString("message", "Sent."); } catch (Exception e) { msg = e.getMessage(); }
            String m = msg;
            main.post(() -> { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); main.postDelayed(this::load, 1500); });
        });
    }
}
