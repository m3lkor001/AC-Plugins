package com.melk.tankremote;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The character card's ⋮ menu, for the session and inventory pages' title bars: close the client, update now,
 * session / inventory / chat, focus or move the game window.
 */
final class AccountMenu {
    private static final int CLOSE = 901, UPDATE = 902, SESSION = 903, INVENTORY = 904, CHAT = 905, FOCUS = 906, MOVE = 907, DEBUG = 908, SHOT = 909, FOCUS_SHOT = 910, NOTE = 911, MTSET = 912, ORGANIZE = 913;
    /** account -> MelkTank's debug log is on (from the last status the app saw) */
    private static final java.util.Map<String, Boolean> debugOn = new java.util.concurrent.ConcurrentHashMap<>();

    static void noteDebug(String account, boolean on) { if (account != null) debugOn.put(account.toLowerCase(), on); }

    /** Before the menu shows: tick Debug log the way it is now. */
    static void prepare(Menu m, String account) {
        MenuItem it = m.findItem(DEBUG);
        Boolean on = account == null ? null : debugOn.get(account.toLowerCase());
        if (it != null) it.setChecked(on != null && on);
    }
    private static final ExecutorService io = Executors.newSingleThreadExecutor();
    private static final Handler main = new Handler(Looper.getMainLooper());

    private AccountMenu() {}

    /** here = "session" or "inventory": that page isn't offered (you're on it). */
    static void build(Menu m, String here) {
        m.add(0, CLOSE, 10, "Close client...").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        m.add(0, UPDATE, 11, "Update now").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        if (!"session".equals(here)) m.add(0, SESSION, 12, "Session details").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        if (!"inventory".equals(here)) m.add(0, INVENTORY, 13, "Inventory").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        m.add(0, CHAT, 14, "Chat...").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        m.add(0, FOCUS, 15, "Focus game window").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        m.add(0, MOVE, 16, "Move game window to top-left").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        m.add(0, SHOT, 17, "PC screenshot").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        m.add(0, FOCUS_SHOT, 18, "Focus game window, then screenshot").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        m.add(1, MTSET, 18, "MelkTank settings & snapshots...").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        m.add(1, ORGANIZE, 18, "Organize packs...").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        m.add(1, NOTE, 19, "Add a note to the logs...").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        m.add(1, DEBUG, 20, "Debug log").setCheckable(true).setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);   // MelkTank_debug.txt
    }

    /** True when the item was one of ours. after = run when something changed (reload the page). */
    static boolean handle(Activity a, MenuItem item, String account, String title, Runnable after) {
        Prefs prefs = new Prefs(a);
        int id = item.getItemId();
        ArrayList<String> others = a.getIntent().getStringArrayListExtra("others");
        switch (id) {
            case CLOSE: confirmClose(a, prefs, account, title); return true;
            case UPDATE:
                io.execute(() -> { try { Api.refresh(prefs, account); } catch (Exception ignored) { } main.postDelayed(after, 3500); });
                toast(a, "Asking MelkTank for fresh numbers...");
                return true;
            case SESSION: case INVENTORY: case CHAT: {
                Class<?> c = id == SESSION ? SessionActivity.class : id == INVENTORY ? InventoryActivity.class : ChatActivity.class;
                Intent i = new Intent(a, c);
                i.putExtra("account", account);
                i.putExtra("title", title);
                if (others != null) i.putStringArrayListExtra("others", others);
                a.startActivity(i);
                return true;
            }
            case SHOT: a.startActivity(new Intent(a, ScreenshotActivity.class)); return true;
            case FOCUS_SHOT: focusThenShot(a, prefs, account); return true;
            case NOTE: askNote(a, prefs, account, title); return true;
            case MTSET: openMtSettings(a, account, title); return true;
            case ORGANIZE: openOrganize(a, account, title); return true;
            case DEBUG:
                io.execute(() -> {
                    String msg;
                    try {
                        // what it is right now (not the possibly old tick), then the other way
                        boolean cur = item.isChecked();
                        org.json.JSONArray accs = Api.status(prefs).optJSONArray("accounts");
                        for (int k = 0; accs != null && k < accs.length(); k++) {
                            org.json.JSONObject o = accs.optJSONObject(k);
                            if (o != null && o.optString("account").equalsIgnoreCase(account)) cur = o.optBoolean("debug", cur);
                        }
                        boolean on = !cur;
                        Api.set(prefs, account, "debug", on);
                        noteDebug(account, on);
                        msg = "Debug log " + (on ? "on" : "off") + " - sent";
                    } catch (Exception e) { msg = e.getMessage(); }
                    String m = msg;
                    main.post(() -> toast(a, m));
                });
                return true;
            case FOCUS: case MOVE:
                io.execute(() -> {
                    String msg;
                    try { msg = (id == MOVE ? Api.moveWindow(prefs, account) : Api.focus(prefs, account)).optString("message", "Done."); }
                    catch (Exception e) { msg = e.getMessage(); }
                    String m = msg;
                    main.post(() -> toast(a, m));
                });
                return true;
        }
        return false;
    }

    static void openOrganize(Activity a, String account, String title) {
        Intent i = new Intent(a, OrganizeActivity.class);
        i.putExtra("account", account);
        i.putExtra("title", title);
        a.startActivity(i);
    }

    static void openMtSettings(Activity a, String account, String title) {
        Intent i = new Intent(a, MtSettingsActivity.class);
        i.putExtra("account", account);
        i.putExtra("title", title);
        a.startActivity(i);
    }

    /** A marked line in the character's debug + packs logs and MelkTank_Notes.txt ("tried 950 ms recovery" ...). */
    static void askNote(Activity a, Prefs prefs, String account, String title) {
        android.widget.EditText e = new android.widget.EditText(a);
        e.setHint("what changed / what to look at (blank = just a mark)");
        e.setSingleLine(false);
        int p = Ui.dp(a, 20);
        LinearLayout box = new LinearLayout(a);
        box.setPadding(p, Ui.dp(a, 8), p, 0);
        box.addView(e, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        new AlertDialog.Builder(a)
                .setTitle("Note in " + title + "'s logs")
                .setView(box)
                .setPositiveButton("Add", (d, w) -> {
                    String text = e.getText().toString().trim();
                    io.execute(() -> {
                        String msg;
                        try { msg = Api.note(prefs, account, text).optString("message", "Note added."); }
                        catch (Exception ex) { msg = ex.getMessage(); }
                        String m = msg;
                        main.post(() -> toast(a, m));
                    });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /** Brings the character's game window to the front, then (once it's had a moment to draw) the PC screenshot. */
    static void focusThenShot(Activity a, Prefs prefs, String account) {
        toast(a, "Focusing the game window...");
        io.execute(() -> {
            String err = null;
            try { Api.focus(prefs, account); } catch (Exception e) { err = e.getMessage(); }
            String e2 = err;
            main.postDelayed(() -> {
                if (e2 != null) toast(a, e2);
                if (!a.isFinishing()) a.startActivity(new Intent(a, ScreenshotActivity.class));
            }, 1500);
        });
    }

    private static void toast(Activity a, String s) { Toast.makeText(a, s, Toast.LENGTH_SHORT).show(); }

    static void confirmClose(Activity a, Prefs prefs, String account, String title) {
        int pad = Ui.dp(a, 20);
        LinearLayout box = Ui.vbox(a);
        box.setPadding(pad, pad / 2, pad, pad / 2);
        TextView msg = Ui.text(a,
                "Log out & close: logs the character out properly (the server saves it), then closes the game at the character screen.\n\n"
                        + "Close now: closes the game straight away, without logging out first.\n\n"
                        + "Kill process: ends the game client outright - for a frozen client.", 15, false);
        box.addView(msg);
        CheckBox again = new CheckBox(a);
        again.setText("Start it again afterwards");
        again.setPadding(0, pad / 2, 0, pad / 2);
        box.addView(again);
        AlertDialog dlg = new AlertDialog.Builder(a).setTitle("Close " + title + "?").setView(box).create();
        LinearLayout.LayoutParams full = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        Button logout = new Button(a);
        logout.setText("Log out & close");
        logout.setOnClickListener(v -> { dlg.dismiss(); sendClose(a, prefs, account, "normal", again.isChecked()); });
        box.addView(logout, full);
        LinearLayout row = Ui.hbox(a);
        Button now = new Button(a);
        now.setText("Close now");
        now.setOnClickListener(v -> { dlg.dismiss(); sendClose(a, prefs, account, "close", again.isChecked()); });
        Button kill = new Button(a);
        kill.setText("Kill process");
        kill.setTextColor(Ui.RED);
        kill.setOnClickListener(v -> { dlg.dismiss(); sendClose(a, prefs, account, "force", again.isChecked()); });
        row.addView(now, Ui.weight(1));
        row.addView(kill, Ui.weight(1));
        box.addView(row);
        Button cancel = new Button(a);
        cancel.setText("Cancel");
        cancel.setOnClickListener(v -> dlg.dismiss());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(a, 6);
        box.addView(cancel, lp);
        dlg.show();
    }

    private static void sendClose(Activity a, Prefs prefs, String account, String mode, boolean relaunch) {
        io.execute(() -> {
            String m;
            try { m = Api.close(prefs, account, mode, relaunch).optString("message", "Sent"); } catch (Exception e) { m = e.getMessage(); }
            String m2 = m;
            main.post(() -> toast(a, m2));
        });
    }
}
