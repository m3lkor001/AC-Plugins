package com.melk.tankremote;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Decal's plugins with an on/off switch each (Virindi Tank, UtilityBelt, ...). Decal reads them when a game client
 * starts, so a change takes effect at the next start (Reset game / relaunch, or MelkTank's memory relog).
 */
public class PluginsActivity extends Activity {
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private Prefs prefs;
    private LinearLayout list;
    private TextView status;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        if (getActionBar() != null) getActionBar().setDisplayHomeAsUpEnabled(true);
        LinearLayout root = Ui.vbox(this);
        int p = Ui.dp(this, 12);
        root.setPadding(p, p, p, p);
        LinearLayout bar = Ui.hbox(this);
        Button back = new Button(this);
        back.setText("‹ Back");
        back.setOnClickListener(v -> finish());
        bar.addView(back);
        status = Ui.text(this, "", 13, false);
        status.setPadding(Ui.dp(this, 10), 0, 0, 0);
        bar.addView(status, Ui.weight(1));
        root.addView(bar);
        TextView hint = Ui.text(this, "Decal reads these when a game client starts: a change applies at the next start (Reset game, relaunch, or MelkTank's memory relog), not in a client that's running now.", 12, false);
        hint.setTextColor(Ui.muted(this));
        hint.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        root.addView(hint);
        list = Ui.vbox(this);
        ScrollView sv = new ScrollView(this);
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(PullRefresh.wrap(this, root, pr -> { load(); main.postDelayed(pr::done, 1500); }));
        load();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) { finish(); return true; }
        return super.onOptionsItemSelected(item);
    }

    private void load() {
        status.setText("Reading Decal's plugins...");
        io.execute(() -> {
            try {
                JSONObject j = Api.plugins(prefs);
                main.post(() -> show(j.optJSONArray("plugins")));
            } catch (Exception e) {
                main.post(() -> status.setText(e.getMessage()));
            }
        });
    }

    private void show(JSONArray a) {
        list.removeAllViews();
        int on = 0;
        for (int i = 0; a != null && i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            String id = o.optString("id"), name = o.optString("name");
            boolean en = o.optBoolean("enabled");
            if (en) on++;
            Switch sw = new Switch(this);
            sw.setText(name + (o.optString("assembly").isEmpty() ? "" : "\n" + o.optString("assembly")));
            sw.setTextSize(15);
            sw.setChecked(en);
            sw.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 8));
            sw.setOnCheckedChangeListener((b2, c) -> set(id, c, sw));
            list.addView(sw);
        }
        status.setText((a == null ? 0 : a.length()) + " plugins, " + on + " on");
    }

    private void set(String id, boolean on, Switch sw) {
        sw.setEnabled(false);
        io.execute(() -> {
            String msg;
            boolean ok;
            try { JSONObject r = Api.setPlugin(prefs, id, on); ok = r.optBoolean("ok", true); msg = r.optString("message", "Done."); }
            catch (Exception e) { ok = false; msg = e.getMessage(); }
            String m = msg; boolean good = ok;
            main.post(() -> {
                sw.setEnabled(true);
                Toast.makeText(this, m, Toast.LENGTH_LONG).show();
                if (!good) load();
            });
        });
    }
}
