package com.melk.tankremote;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The phone's route editor (MelkTank's Profiles\Navs\*.mtnav, through MelkTank Remote). Without a "file" extra it
 * lists the routes (new / copy / delete); with one it edits that route: its settings and steps (edit, add, move,
 * delete). Save writes the file and the running games read it again.
 */
public class NavEditorActivity extends Activity {
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private Prefs prefs;
    private String file;                    // null: the route list
    private String preset;                  // a preset being edited (instead of a route file)
    private List<JSONObject> presetList = new ArrayList<>();
    private JSONObject route;               // {file, mtime, attrs, steps}
    private final List<JSONObject> steps = new ArrayList<>();
    private List<String> presets = new ArrayList<>(), routeNames = new ArrayList<>();
    private boolean dirty;
    private LinearLayout root, stepsBox, formBox;
    private TextView status;
    private int editIdx = -1;               // the step in the form (-1: a new one)
    private int insertAt = -1;              // where a new step goes (-1: at the end)

    static final String[] KINDS = { "Point", "Command", "Use", "Wait", "Toggle", "LoopStart", "LoopEnd", "ChatWait", "ItemCheck",
            "GoRoute", "UseItem", "Preset", "PlayerSkip", "Cast" };
    static final String[] KIND_LABELS = { "Point (walk to)", "Chat command", "Use object / NPC / portal", "Wait", "Switch",
            "Loop start", "Loop end", "Wait for chat line", "Item check", "Go to route", "Use item", "Preset", "Player skip", "Cast spell" };
    // what a preset can hold (MelkTank's NavPresets.Allowed: nothing tied to a place, no loops, no presets in presets)
    static final List<String> PRESET_KINDS = Arrays.asList("Command", "Wait", "Toggle", "Cast", "ChatWait", "ItemCheck", "UseItem", "GoRoute", "PlayerSkip");
    static final String[] TOGGLES = { "combat on", "combat off", "looting on", "looting off", "summoning on", "summoning off",
            "reset session", "doors on", "doors off", "reset kills/hr" };
    static final String[] MODES = { "Once", "Back and forth", "Round and round" };
    static final String[] ITEM_OPS = { "=", "!=", "<", ">", "<=", ">=" };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        file = getIntent().getStringExtra("file");
        preset = getIntent().getStringExtra("preset");
        setTitle(preset != null ? "Preset" : file == null ? "Routes" : "Route");
        if (getActionBar() != null) getActionBar().setDisplayHomeAsUpEnabled(true);
        ScrollView scroll = new ScrollView(this);
        root = Ui.vbox(this);
        int p = Ui.dp(this, 14);
        root.setPadding(p, p, p, p);
        scroll.addView(root);
        setContentView(scroll);
        load();
    }

    @Override
    public boolean onOptionsItemSelected(android.view.MenuItem item) {
        if (item.getItemId() == android.R.id.home) { onBackPressed(); return true; }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (dirty) {
            new AlertDialog.Builder(this).setTitle("Unsaved changes").setMessage("Save the route before leaving?")
                    .setPositiveButton("Save", (d, w) -> save(false, true))
                    .setNegativeButton("Discard", (d, w) -> finish())
                    .setNeutralButton("Cancel", null).show();
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (file == null && preset == null && route == null) load();
    }

    private boolean editing() { return file != null || preset != null; }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    // ── loading ──────────────────────────────────────────────────────────

    private void load() {
        io.execute(() -> {
            try {
                JSONObject list = Api.navs(prefs);
                JSONObject r = preset != null ? Api.preset(prefs, preset) : file == null ? null : Api.nav(prefs, file);
                main.post(() -> {
                    presets = strings(list.optJSONArray("presets"));
                    routeNames = new ArrayList<>();
                    JSONArray rs = list.optJSONArray("routes");
                    if (rs != null) for (int i = 0; i < rs.length(); i++) routeNames.add(rs.optJSONObject(i).optString("name"));
                    presetList = new ArrayList<>();
                    JSONArray pl = list.optJSONArray("presetList");
                    if (pl != null) for (int i = 0; i < pl.length(); i++) presetList.add(pl.optJSONObject(i));
                    if (!editing()) showList(rs); else { route = r; readSteps(); showRoute(); }
                });
            } catch (Exception e) {
                main.post(() -> { root.removeAllViews(); root.addView(Ui.text(this, e.getMessage(), 15, false)); });
            }
        });
    }

    private static List<String> strings(JSONArray a) {
        List<String> l = new ArrayList<>();
        if (a != null) for (int i = 0; i < a.length(); i++) l.add(a.optString(i));
        return l;
    }

    // ── the list ─────────────────────────────────────────────────────────

    private void showList(JSONArray rs) {
        root.removeAllViews();
        LinearLayout nc = Ui.card(this);
        nc.addView(Ui.text(this, "New route", 16, true));
        LinearLayout row = Ui.hbox(this);
        EditText name = new EditText(this);
        name.setHint("Name");
        name.setSingleLine(true);
        row.addView(name, Ui.weight(1));
        Button create = new Button(this);
        create.setText("Create");
        create.setOnClickListener(v -> newRoute(name.getText().toString().trim(), null));
        row.addView(create);
        nc.addView(row);
        root.addView(nc);

        LinearLayout lc = Ui.card(this);
        lc.addView(Ui.text(this, "Routes (" + (rs == null ? 0 : rs.length()) + ")", 16, true));
        if (rs != null) for (int i = 0; i < rs.length(); i++) {
            JSONObject r = rs.optJSONObject(i);
            LinearLayout line = Ui.hbox(this);
            TextView t = Ui.text(this, r.optString("name") + "\n" + r.optInt("steps") + " steps · " + r.optString("file"), 15, false);
            t.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 8));
            t.setOnClickListener(v -> open(r.optString("file")));
            line.addView(t, Ui.weight(1));
            Button copy = small("Copy");
            copy.setOnClickListener(v -> ask("Copy " + r.optString("name") + " as", r.optString("name") + " copy", n -> newRoute(n, r.optString("file"))));
            line.addView(copy);
            Button del = small("✕");
            del.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Delete " + r.optString("name") + "?")
                    .setMessage("The file goes to MelkTank's _to_delete folder.")
                    .setPositiveButton("Delete", (d, w) -> io.execute(() -> {
                        try { Api.navDelete(prefs, r.optString("file")); main.post(this::load); }
                        catch (Exception e) { main.post(() -> toast(e.getMessage())); }
                    })).setNegativeButton("Cancel", null).show());
            line.addView(del);
            lc.addView(line);
        }
        root.addView(lc);

        LinearLayout pc = Ui.card(this);
        LinearLayout ph = Ui.hbox(this);
        ph.addView(Ui.text(this, "Presets (" + presetList.size() + ")", 16, true), Ui.weight(1));
        Button pnew = small("+ New");
        pnew.setOnClickListener(v -> ask("New preset", "", n -> newPreset(n, null)));
        ph.addView(pnew);
        pc.addView(ph);
        TextView ph2 = Ui.text(this, "Groups of steps a route runs with one Preset step (shared by every route).", 13, false);
        ph2.setTextColor(Ui.muted(this));
        pc.addView(ph2);
        for (JSONObject pr : presetList) {
            LinearLayout line = Ui.hbox(this);
            String pn = pr.optString("name");
            TextView t = Ui.text(this, pn + "\n" + pr.optInt("steps") + " steps", 15, false);
            t.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 8));
            t.setOnClickListener(v -> openPreset(pn));
            line.addView(t, Ui.weight(1));
            Button copy = small("Copy");
            copy.setOnClickListener(v -> ask("Copy " + pn + " as", pn + " copy", n -> newPreset(n, pn)));
            line.addView(copy);
            Button del = small("✕");
            del.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Delete preset " + pn + "?")
                    .setMessage("Routes that use it will skip that step.")
                    .setPositiveButton("Delete", (d, w) -> io.execute(() -> {
                        try { Api.presetDelete(prefs, pn); main.post(this::load); }
                        catch (Exception e) { main.post(() -> toast(e.getMessage())); }
                    })).setNegativeButton("Cancel", null).show());
            line.addView(del);
            pc.addView(line);
        }
        root.addView(pc);
    }

    private void openPreset(String name) {
        Intent i = new Intent(this, NavEditorActivity.class);
        i.putExtra("preset", name);
        startActivity(i);
    }

    private void newPreset(String name, String copyOf) {
        if (name.isEmpty()) { toast("Give it a name."); return; }
        io.execute(() -> {
            try {
                JSONObject r = Api.presetNew(prefs, name, copyOf);
                if (r.has("error")) { main.post(() -> toast(r.optString("error"))); return; }
                main.post(() -> { load(); openPreset(name); });
            } catch (Exception e) { main.post(() -> toast(e.getMessage())); }
        });
    }

    private void open(String f) {
        Intent i = new Intent(this, NavEditorActivity.class);
        i.putExtra("file", f);
        startActivity(i);
    }

    private void newRoute(String name, String copyOf) {
        if (name.isEmpty()) { toast("Give it a name."); return; }
        io.execute(() -> {
            try {
                JSONObject r = Api.navNew(prefs, name, copyOf);
                if (r.has("error")) { main.post(() -> toast(r.optString("error"))); return; }
                String f = r.optJSONObject("route").optString("file");
                main.post(() -> { load(); open(f); });
            } catch (Exception e) { main.post(() -> toast(e.getMessage())); }
        });
    }

    interface Got { void got(String s); }

    private void ask(String title, String start, Got then) {
        EditText e = new EditText(this);
        e.setText(start);
        e.setSingleLine(true);
        new AlertDialog.Builder(this).setTitle(title).setView(e)
                .setPositiveButton("OK", (d, w) -> then.got(e.getText().toString().trim()))
                .setNegativeButton("Cancel", null).show();
    }

    private Button small(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setMinWidth(0);
        b.setMinimumWidth(Ui.dp(this, 44));
        b.setPadding(Ui.dp(this, 6), 0, Ui.dp(this, 6), 0);
        return b;
    }

    // ── one route ────────────────────────────────────────────────────────

    private void readSteps() {
        steps.clear();
        JSONArray a = route.optJSONArray("steps");
        if (a != null) for (int i = 0; i < a.length(); i++) steps.add(a.optJSONObject(i));
        dirty = false;
    }

    private JSONObject attrs() {
        JSONObject a = route.optJSONObject("attrs");
        if (a == null) { a = new JSONObject(); try { route.put("attrs", a); } catch (Exception ignored) { } }
        return a;
    }

    private void showRoute() {
        root.removeAllViews();
        JSONObject a = attrs();
        setTitle((preset != null ? "Preset - " : "Route - ") + a.optString("name"));

        // top: save
        LinearLayout top = Ui.hbox(this);
        status = Ui.text(this, "", 14, false);
        status.setTextColor(Ui.muted(this));
        top.addView(status, Ui.weight(1));
        Button save = new Button(this);
        save.setText("Save");
        save.setOnClickListener(v -> save(false, false));
        top.addView(save);
        root.addView(top);
        markDirty(dirty);

        // settings
        LinearLayout sc = Ui.card(this);
        sc.addView(Ui.text(this, "Settings", 16, true));
        sc.addView(field("Name", a.optString("name"), false, s -> put(a, "name", s)));
        if (preset != null) {
            TextView pnote = Ui.text(this, "Renaming a preset also renames it in the routes that use it.", 13, false);
            pnote.setTextColor(Ui.muted(this));
            sc.addView(pnote);
        }
        if (preset == null) {
        Spinner mode = spinner(MODES, a.optInt("mode", 0));
        mode.setOnItemSelectedListener(new Sel(i -> { if (i != a.optInt("mode", 0)) { put(a, "mode", String.valueOf(i)); markDirty(true); } }));
        sc.addView(labelled("Repeat", mode));
        sc.addView(field("Arrive within (m)", a.optString("arrive", "2.5"), true, s -> put(a, "arrive", s)));
        sc.addView(check("Restart if stuck", "1".equals(a.optString("restartstuck")), on -> put(a, "restartstuck", on ? "1" : "")));
        sc.addView(field("  ... stuck for (min)", a.optString("restartstuckm", "3"), true, s -> put(a, "restartstuckm", s)));
        sc.addView(check("Restart if far from the route", "1".equals(a.optString("restartfar")), on -> put(a, "restartfar", on ? "1" : "")));
        sc.addView(field("  ... farther than (m)", a.optString("restartfarm", "100"), true, s -> put(a, "restartfarm", s)));
        Spinner stuck = spinner(new String[] { "Keep trying", "Turn combat on", "Back up and try again", "Start the route over", "Skip that point" }, a.optInt("stuck", 0));
        stuck.setOnItemSelectedListener(new Sel(i -> {
            if (i == a.optInt("stuck", 0)) return;
            put(a, "stuck", i == 0 ? "" : String.valueOf(i));
            if (i != 0 && a.optString("stuckback").isEmpty()) put(a, "stuckback", "2");
            if (i != 0 && a.optString("stuckafter").isEmpty()) put(a, "stuckafter", "2");
        }));
        sc.addView(labelled("When stuck", stuck));
        sc.addView(field("  ... stuck after (s)", a.optString("stuckafter", "2"), true, s -> put(a, "stuckafter", s)));
        }
        root.addView(sc);

        // steps
        LinearLayout stc = Ui.card(this);
        LinearLayout h = Ui.hbox(this);
        h.addView(Ui.text(this, "Steps (" + steps.size() + ")", 16, true), Ui.weight(1));
        Button add = small("+ Add");
        add.setOnClickListener(v -> { editIdx = -1; insertAt = -1; showForm(new JSONObject()); });
        h.addView(add);
        stc.addView(h);
        stepsBox = Ui.vbox(this);
        stc.addView(stepsBox);
        root.addView(stc);
        drawSteps();

        formBox = Ui.vbox(this);
        root.addView(formBox);
    }

    private void markDirty(boolean d) {
        dirty = d;
        if (status != null) {
            status.setText(d ? "Not saved" : "Saved copy (" + steps.size() + " steps)");
            status.setTextColor(d ? Ui.AMBER : Ui.muted(this));
        }
    }

    private void put(JSONObject o, String k, String v) {
        try {
            if (v == null || v.isEmpty()) o.remove(k); else o.put(k, v);
        } catch (Exception ignored) { }
        markDirty(true);
    }

    private void drawSteps() {
        stepsBox.removeAllViews();
        for (int i = 0; i < steps.size(); i++) {
            final int idx = i;
            JSONObject st = steps.get(i);
            LinearLayout line = Ui.hbox(this);
            int depth = loopDepth(i);
            TextView t = Ui.text(this, (i + 1) + ". " + describe(st), 14, false);
            t.setPadding(Ui.dp(this, 4 + depth * 14), Ui.dp(this, 6), 0, Ui.dp(this, 6));
            if (i == editIdx) t.setTextColor(Ui.GREEN);
            t.setOnClickListener(v -> { editIdx = idx; showForm(copy(st)); });
            line.addView(t, Ui.weight(1));
            Button up = small("▲"), dn = small("▼"), ins = small("+"), del = small("✕");
            up.setOnClickListener(v -> move(idx, idx - 1));
            up.setOnLongClickListener(v -> { move(idx, 0); return true; });
            dn.setOnClickListener(v -> move(idx, idx + 1));
            dn.setOnLongClickListener(v -> { move(idx, steps.size() - 1); return true; });
            ins.setOnClickListener(v -> { editIdx = -1; insertAt = idx + 1; showForm(new JSONObject()); });
            del.setOnClickListener(v -> { steps.remove(idx); if (editIdx == idx) { editIdx = -1; formBox.removeAllViews(); } markDirty(true); drawSteps(); });
            line.addView(up); line.addView(dn); line.addView(ins); line.addView(del);
            stepsBox.addView(line);
        }
        if (steps.isEmpty()) stepsBox.addView(Ui.text(this, "No steps yet - + Add.", 14, false));
    }

    private int loopDepth(int i) {
        int d = 0;
        for (int j = 0; j < i; j++) {
            String k = steps.get(j).optString("kind");
            if (k.equals("LoopStart")) d++;
            else if (k.equals("LoopEnd")) d = Math.max(0, d - 1);
        }
        if (steps.get(i).optString("kind").equals("LoopEnd")) d = Math.max(0, d - 1);
        return d;
    }

    private void move(int from, int to) {
        if (to < 0 || to >= steps.size() || from == to) return;
        JSONObject s = steps.remove(from);
        steps.add(to, s);
        editIdx = -1;
        formBox.removeAllViews();
        markDirty(true);
        drawSteps();
    }

    private static JSONObject copy(JSONObject o) {
        try { return new JSONObject(o.toString()); } catch (Exception e) { return new JSONObject(); }
    }

    static String secs(String ms) {
        try {
            double s = Integer.parseInt(ms) / 1000.0;
            return s == Math.floor(s) ? String.valueOf((long) s) : String.format(Locale.US, "%.1f", s);
        } catch (Exception e) { return ms; }
    }

    static String coords(String ns, String ew) {
        try {
            double n = Double.parseDouble(ns), e = Double.parseDouble(ew);
            return String.format(Locale.US, "%.2f%s %.2f%s", Math.abs(n), n >= 0 ? "N" : "S", Math.abs(e), e >= 0 ? "E" : "W");
        } catch (Exception x) { return ns + ", " + ew; }
    }

    static String describe(JSONObject st) {
        String k = st.optString("kind"), t = st.optString("text");
        switch (k) {
            case "Point": return "Point " + coords(st.optString("ns"), st.optString("ew"));
            case "Command": return "Command: " + t + (st.optString("wait").isEmpty() ? "" : " (then " + secs(st.optString("wait")) + " s)");
            case "Use": return "Use " + t + " at " + coords(st.optString("ns"), st.optString("ew"));
            case "Wait": return "Wait " + secs(st.optString("wait", "0")) + " s";
            case "Toggle": return "Switch: " + t;
            case "LoopStart": return "Loop start";
            case "LoopEnd": {
                JSONArray c = st.optJSONArray("conds");
                return "Loop end" + (c == null || c.length() == 0 ? " (loops forever)" : " - leave when " + c.length() + " condition" + (c.length() == 1 ? "" : "s") + " true");
            }
            case "ChatWait": return "Wait for chat " + (st.optString("op").isEmpty() ? "contains" : st.optString("op")) + " \"" + t + "\"";
            case "ItemCheck": return "Item check: " + t + " " + st.optString("op", "=") + " " + st.optString("count", "0");
            case "GoRoute": return "Go to route " + t + " (" + (st.optString("op").isEmpty() ? "start" : st.optString("op")) + ")";
            case "UseItem": return "Use item " + t;
            case "Preset": return "Preset: " + t;
            case "PlayerSkip": return "Player within " + (t.isEmpty() ? "20" : t) + " m: skip next " + st.optString("count", "1");
            case "Cast": return "Cast " + t;
        }
        return k + " " + t;
    }

    // ── the step form ────────────────────────────────────────────────────

    private void showForm(JSONObject st) {
        formBox.removeAllViews();
        drawSteps();
        LinearLayout c = Ui.card(this);
        c.addView(Ui.text(this, editIdx >= 0 ? "Edit step " + (editIdx + 1) : "New step" + (insertAt >= 0 ? " (goes at " + (insertAt + 1) + ")" : " (at the end)"), 16, true));
        String kind = st.optString("kind", "Command");
        try { if (!st.has("kind")) st.put("kind", kind); } catch (Exception ignored) { }
        List<String> kinds = new ArrayList<>(), labels = new ArrayList<>();
        for (int i = 0; i < KINDS.length; i++)
            if (preset == null || PRESET_KINDS.contains(KINDS[i])) { kinds.add(KINDS[i]); labels.add(KIND_LABELS[i]); }
        int ki = kinds.indexOf(kind);
        Spinner ks = spinner(labels.toArray(new String[0]), Math.max(0, ki));
        LinearLayout fields = Ui.vbox(this);
        ks.setOnItemSelectedListener(new Sel(i -> {
            if (!kinds.get(i).equals(st.optString("kind"))) {
                try { st.put("kind", kinds.get(i)); } catch (Exception ignored) { }
            }
            kindFields(fields, st);
        }));
        c.addView(labelled("Kind", ks));
        c.addView(fields);
        kindFields(fields, st);

        LinearLayout btns = Ui.hbox(this);
        Button ok = new Button(this);
        ok.setText(editIdx >= 0 ? "Update" : "Add");
        ok.setOnClickListener(v -> {
            clean(st);
            if (editIdx >= 0) steps.set(editIdx, st);
            else if (insertAt >= 0 && insertAt <= steps.size()) steps.add(insertAt, st);
            else steps.add(st);
            editIdx = -1; insertAt = -1;
            formBox.removeAllViews();
            markDirty(true);
            drawSteps();
        });
        Button cancel = new Button(this);
        cancel.setText("Cancel");
        cancel.setOnClickListener(v -> { editIdx = -1; insertAt = -1; formBox.removeAllViews(); drawSteps(); });
        btns.addView(ok, Ui.weight(1));
        btns.addView(cancel, Ui.weight(1));
        c.addView(btns);
        formBox.addView(c);
        formBox.post(() -> ((ScrollView) root.getParent()).smoothScrollTo(0, formBox.getTop()));
    }

    /** Fills in what a kind needs, so the file always has the attributes MelkTank reads. */
    private static void clean(JSONObject st) {
        try {
            for (String k : new String[] { "ns", "ew", "z" }) if (st.optString(k).isEmpty()) st.put(k, "0");
            if (!st.has("text")) st.put("text", "");
            if (st.optString("wait").isEmpty()) st.put("wait", "1000");
            if (!"LoopEnd".equals(st.optString("kind"))) st.remove("conds");
        } catch (Exception ignored) { }
    }

    private void kindFields(LinearLayout f, JSONObject st) {
        f.removeAllViews();
        String k = st.optString("kind");
        switch (k) {
            case "Point":
                f.addView(field("N/S (+ north)", st.optString("ns"), true, s -> set(st, "ns", s)));
                f.addView(field("E/W (+ east)", st.optString("ew"), true, s -> set(st, "ew", s)));
                f.addView(field("Height (z)", st.optString("z"), true, s -> set(st, "z", s)));
                f.addView(hint("A new point is easiest to add in the game (Nav > Routes > Add point here)."));
                break;
            case "Command":
                f.addView(field("Command", st.optString("text"), false, s -> set(st, "text", s)));
                f.addView(secField("Then wait (s)", st, "wait"));
                break;
            case "Use":
                f.addView(field("Object / NPC / portal name", st.optString("text"), false, s -> set(st, "text", s)));
                f.addView(field("Where: N/S", st.optString("ns"), true, s -> set(st, "ns", s)));
                f.addView(field("Where: E/W", st.optString("ew"), true, s -> set(st, "ew", s)));
                f.addView(secField("Then wait (s)", st, "wait"));
                break;
            case "Wait":
                f.addView(secField("Seconds", st, "wait"));
                break;
            case "Toggle": {
                int i = Math.max(0, Arrays.asList(TOGGLES).indexOf(st.optString("text").toLowerCase(Locale.US)));
                set(st, "text", TOGGLES[i]);
                Spinner sp = spinner(TOGGLES, i);
                sp.setOnItemSelectedListener(new Sel(x -> set(st, "text", TOGGLES[x])));
                f.addView(labelled("Switch", sp));
                break;
            }
            case "LoopStart":
                f.addView(hint("The loop part starts here (a route repeats from here, not from the top)."));
                break;
            case "LoopEnd":
                loopConds(f, st);
                break;
            case "ChatWait": {
                f.addView(field("Chat text", st.optString("text"), false, s -> set(st, "text", s)));
                String[] ops = { "contains", "=" };
                int i = Math.max(0, Arrays.asList(ops).indexOf(st.optString("op", "contains")));
                Spinner sp = spinner(ops, i);
                sp.setOnItemSelectedListener(new Sel(x -> set(st, "op", ops[x])));
                f.addView(labelled("Match", sp));
                f.addView(secField("Give up after (s)", st, "wait"));
                break;
            }
            case "ItemCheck": {
                f.addView(field("Item", st.optString("text"), false, s -> set(st, "text", s)));
                int i = Math.max(0, Arrays.asList(ITEM_OPS).indexOf(st.optString("op", "=")));
                Spinner sp = spinner(ITEM_OPS, i);
                sp.setOnItemSelectedListener(new Sel(x -> set(st, "op", ITEM_OPS[x])));
                f.addView(labelled("Count is", sp));
                f.addView(field("Number", st.optString("count", "0"), true, s -> set(st, "count", s)));
                f.addView(hint("When it's not true, the route stops here."));
                break;
            }
            case "GoRoute": {
                List<String> names = new ArrayList<>(routeNames);
                if (!st.optString("text").isEmpty() && !names.contains(st.optString("text"))) names.add(0, st.optString("text"));
                if (names.isEmpty()) names.add("");
                int i = Math.max(0, names.indexOf(st.optString("text")));
                set(st, "text", names.get(i));
                Spinner sp = spinner(names.toArray(new String[0]), i);
                sp.setOnItemSelectedListener(new Sel(x -> set(st, "text", names.get(x))));
                f.addView(labelled("Route", sp));
                String[] ops = { "start", "nearest" };
                Spinner so = spinner(new String[] { "From its start", "From its nearest point" }, "nearest".equals(st.optString("op")) ? 1 : 0);
                so.setOnItemSelectedListener(new Sel(x -> set(st, "op", ops[x])));
                f.addView(labelled("Begin", so));
                break;
            }
            case "UseItem":
                f.addView(field("Item name", st.optString("text"), false, s -> set(st, "text", s)));
                f.addView(secField("Then wait (s)", st, "wait"));
                break;
            case "Preset": {
                List<String> names = new ArrayList<>(presets);
                if (!st.optString("text").isEmpty() && !names.contains(st.optString("text"))) names.add(0, st.optString("text"));
                if (names.isEmpty()) names.add("");
                int i = Math.max(0, names.indexOf(st.optString("text")));
                set(st, "text", names.get(i));
                Spinner sp = spinner(names.toArray(new String[0]), i);
                sp.setOnItemSelectedListener(new Sel(x -> set(st, "text", names.get(x))));
                f.addView(labelled("Preset", sp));
                break;
            }
            case "PlayerSkip":
                if (st.optString("text").isEmpty()) set(st, "text", "20");
                if (st.optString("count").isEmpty()) set(st, "count", "3");
                f.addView(field("Another player within (m)", st.optString("text"), true, s -> set(st, "text", s)));
                f.addView(field("Skip this many next steps", st.optString("count"), true, s -> set(st, "count", s)));
                break;
            case "Cast":
                f.addView(field("Spell", st.optString("text"), false, s -> set(st, "text", s)));
                break;
        }
    }

    private void loopConds(LinearLayout f, JSONObject st) {
        JSONArray cs = st.optJSONArray("conds");
        if (cs == null) { cs = new JSONArray(); try { st.put("conds", cs); } catch (Exception ignored) { } }
        final JSONArray conds = cs;
        f.addView(hint("Leave the loop when every line below is true (none: loop forever)."));
        for (int i = 0; i < conds.length(); i++) {
            final int idx = i;
            JSONObject c = conds.optJSONObject(i);
            boolean chat = "1".equals(c.optString("chat"));
            LinearLayout box = Ui.vbox(this);
            box.setPadding(Ui.dp(this, 10), Ui.dp(this, 4), 0, Ui.dp(this, 4));
            LinearLayout head = Ui.hbox(this);
            Spinner type = spinner(new String[] { "Item count", "Chat line seen" }, chat ? 1 : 0);
            type.setOnItemSelectedListener(new Sel(x -> { set(c, "chat", x == 1 ? "1" : ""); }));
            head.addView(type, Ui.weight(1));
            Button del = small("✕");
            del.setOnClickListener(v -> { conds.remove(idx); kindFields((LinearLayout) f, st); });
            head.addView(del);
            box.addView(head);
            box.addView(field(chat ? "Chat text (contains)" : "Item", c.optString("text"), false, s -> set(c, "text", s)));
            if (!chat) {
                int oi = Math.max(0, Arrays.asList(ITEM_OPS).indexOf(c.optString("op", ">=")));
                Spinner op = spinner(ITEM_OPS, oi);
                op.setOnItemSelectedListener(new Sel(x -> set(c, "op", ITEM_OPS[x])));
                box.addView(labelled("Count is", op));
                box.addView(field("Number", c.optString("count", "0"), true, s -> set(c, "count", s)));
            }
            f.addView(box);
        }
        Button add = small("+ Condition");
        add.setOnClickListener(v -> {
            try { conds.put(new JSONObject().put("chat", "").put("text", "").put("op", ">=").put("count", "0")); } catch (Exception ignored) { }
            kindFields(f, st);
        });
        f.addView(add);
    }

    private static void set(JSONObject o, String k, String v) {
        try { o.put(k, v == null ? "" : v); } catch (Exception ignored) { }
    }

    private View secField(String label, JSONObject st, String key) {
        return field(label, secs(st.optString(key, "1000")), true, s -> {
            try { set(st, key, String.valueOf(Math.round(Double.parseDouble(s) * 1000))); } catch (Exception ignored) { }
        });
    }

    // ── saving ───────────────────────────────────────────────────────────

    private void save(boolean force, boolean thenFinish) {
        try {
            JSONArray a = new JSONArray();
            for (JSONObject s : steps) a.put(s);
            JSONObject data = new JSONObject().put("attrs", attrs()).put("steps", a);
            String f = route.optString("file");
            long mt = route.optLong("mtime");
            io.execute(() -> {
                try {
                    JSONObject r = preset != null ? Api.presetSave(prefs, preset, mt, data, force) : Api.navSave(prefs, f, mt, data, force);
                    main.post(() -> {
                        if (r.has("error") && !r.has("route")) {
                            new AlertDialog.Builder(this).setTitle("Not saved").setMessage(r.optString("error"))
                                    .setPositiveButton("Save anyway", (d, w) -> save(true, thenFinish))
                                    .setNegativeButton("Cancel", null).show();
                            return;
                        }
                        route = r.optJSONObject("route");
                        if (preset != null) preset = route.optString("preset", preset); else file = route.optString("file");
                        readSteps();
                        JSONArray sent = r.optJSONArray("sent");
                        JSONArray ren = r.optJSONArray("renamedIn");
                        toast(preset != null ? "Saved - MelkTank picks it up within a few seconds" + (ren != null && ren.length() > 0 ? " (renamed in " + ren.length() + " route" + (ren.length() == 1 ? "" : "s") + ")" : "")
                                : "Saved" + (sent != null && sent.length() > 0 ? " - the running games read it again" : ""));
                        if (thenFinish) finish(); else showRoute();
                    });
                } catch (Exception e) { main.post(() -> toast(e.getMessage())); }
            });
        } catch (Exception e) { toast(e.getMessage()); }
    }

    // ── small form helpers ───────────────────────────────────────────────

    interface Changed { void changed(String s); }
    interface Toggled { void toggled(boolean on); }
    interface Picked { void picked(int i); }

    static class Sel implements android.widget.AdapterView.OnItemSelectedListener {
        private final Picked p; private boolean first = true;
        Sel(Picked p) { this.p = p; }
        @Override public void onItemSelected(android.widget.AdapterView<?> a, View v, int i, long id) {
            if (first) { first = false; return; }   // the spinner's own first call
            p.picked(i);
        }
        @Override public void onNothingSelected(android.widget.AdapterView<?> a) { }
    }

    private Spinner spinner(String[] items, int sel) {
        Spinner s = new Spinner(this);
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(ad);
        s.setSelection(Math.max(0, Math.min(sel, items.length - 1)));
        return s;
    }

    private View labelled(String label, View v) {
        LinearLayout row = Ui.hbox(this);
        TextView t = Ui.text(this, label, 14, false);
        t.setTextColor(Ui.muted(this));
        row.addView(t, new LinearLayout.LayoutParams(Ui.dp(this, 120), LinearLayout.LayoutParams.WRAP_CONTENT));
        row.addView(v, Ui.weight(1));
        return row;
    }

    private View field(String label, String value, boolean number, Changed ch) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setSingleLine(true);
        if (number) e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        e.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(android.text.Editable s) { ch.changed(s.toString().trim()); }
        });
        return labelled(label, e);
    }

    private View check(String label, boolean on, Toggled t) {
        CheckBox cb = new CheckBox(this);
        cb.setText(label);
        cb.setChecked(on);
        cb.setOnCheckedChangeListener((v, x) -> t.toggled(x));
        return cb;
    }

    private TextView hint(String s) {
        TextView t = Ui.text(this, s, 13, false);
        t.setTextColor(Ui.muted(this));
        return t;
    }
}
