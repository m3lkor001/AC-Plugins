package com.melk.tankremote;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.util.Base64;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The phone's meta editor (MelkTank's Profiles\Metas - .mtmet and VTank .met, through MelkTank Remote). Without a
 * "file" extra it lists the metas (new / copy / delete); with one it edits that meta: its states and their rules
 * (condition -> action), with every VTank / MelkTank condition and action and their settings. Save writes the file
 * and a game that has it loaded reads it again (staying in its state).
 */
public class MetaEditorActivity extends Activity {
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private Prefs prefs;
    private String file;
    private JSONObject meta;                      // {file, name, mtime, rules}
    private final List<JSONObject> rules = new ArrayList<>();
    private JSONArray condTypes = new JSONArray(), actTypes = new JSONArray();
    private List<String> routeNames = new ArrayList<>();
    private boolean dirty;
    private LinearLayout root;
    private TextView status;
    private String metaName = "";

    private static final String[] MT_OPTIONS = { "enablecombat", "enablelooting", "enablenav", "enablebuffing", "enablesummoning", "enablemeta", "enabledoors" };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        file = getIntent().getStringExtra("file");
        setTitle(file == null ? "Metas" : "Meta");
        if (getActionBar() != null) getActionBar().setDisplayHomeAsUpEnabled(true);
        ScrollView scroll = new ScrollView(this);
        root = Ui.vbox(this);
        int p = Ui.dp(this, 14);
        root.setPadding(p, p, p, p);
        scroll.addView(root);
        setContentView(scroll);
        load();
    }

    @Override
    public boolean onOptionsItemSelected(android.view.MenuItem item) {
        if (item.getItemId() == android.R.id.home) { onBackPressed(); return true; }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (dirty) {
            new AlertDialog.Builder(this).setTitle("Unsaved changes").setMessage("Save the meta before leaving?")
                    .setPositiveButton("Save", (d, w) -> save(false, true))
                    .setNegativeButton("Discard", (d, w) -> finish())
                    .setNeutralButton("Cancel", null).show();
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (file == null && meta == null) load();
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private void load() {
        io.execute(() -> {
            try {
                JSONObject list = Api.metas(prefs);
                JSONObject m = file == null ? null : Api.meta(prefs, file);
                main.post(() -> {
                    JSONObject types = list.optJSONObject("types");
                    if (types != null) { condTypes = types.optJSONArray("conds"); actTypes = types.optJSONArray("acts"); }
                    routeNames = new ArrayList<>();
                    JSONArray rn = list.optJSONArray("routes");
                    if (rn != null) for (int i = 0; i < rn.length(); i++) routeNames.add(rn.optString(i));
                    if (file == null) showList(list.optJSONArray("metas"));
                    else { meta = m; readRules(); showMeta(); }
                });
            } catch (Exception e) {
                main.post(() -> { root.removeAllViews(); root.addView(Ui.text(this, e.getMessage(), 15, false)); });
            }
        });
    }

    // ── the list ─────────────────────────────────────────────────────────

    private void showList(JSONArray ms) {
        root.removeAllViews();
        LinearLayout nc = Ui.card(this);
        nc.addView(Ui.text(this, "New meta", 16, true));
        LinearLayout row = Ui.hbox(this);
        EditText name = new EditText(this);
        name.setHint("Name");
        name.setSingleLine(true);
        row.addView(name, Ui.weight(1));
        Button create = new Button(this);
        create.setText("Create");
        create.setOnClickListener(v -> newMeta(name.getText().toString().trim(), null));
        row.addView(create);
        nc.addView(row);
        root.addView(nc);

        LinearLayout lc = Ui.card(this);
        lc.addView(Ui.text(this, "Metas (" + (ms == null ? 0 : ms.length()) + ")", 16, true));
        if (ms != null) for (int i = 0; i < ms.length(); i++) {
            JSONObject m = ms.optJSONObject(i);
            LinearLayout line = Ui.hbox(this);
            TextView t = Ui.text(this, m.optString("name") + "\n" + m.optString("file"), 15, false);
            t.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 8));
            t.setOnClickListener(v -> open(m.optString("file")));
            line.addView(t, Ui.weight(1));
            Button copy = small("Copy");
            copy.setOnClickListener(v -> ask("Copy " + m.optString("name") + " as", m.optString("name") + " copy", n -> newMeta(n, m.optString("file"))));
            line.addView(copy);
            Button del = small("✕");
            del.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Delete " + m.optString("name") + "?")
                    .setMessage("The file goes to MelkTank's _to_delete folder.")
                    .setPositiveButton("Delete", (d, w) -> io.execute(() -> {
                        try { Api.metaDelete(prefs, m.optString("file")); main.post(this::load); }
                        catch (Exception e) { main.post(() -> toast(e.getMessage())); }
                    })).setNegativeButton("Cancel", null).show());
            line.addView(del);
            lc.addView(line);
        }
        root.addView(lc);
    }

    private void open(String f) {
        Intent i = new Intent(this, MetaEditorActivity.class);
        i.putExtra("file", f);
        startActivity(i);
    }

    private void newMeta(String name, String copyOf) {
        if (name.isEmpty()) { toast("Give it a name."); return; }
        io.execute(() -> {
            try {
                JSONObject r = Api.metaNew(prefs, name, copyOf);
                if (r.has("error")) { main.post(() -> toast(r.optString("error"))); return; }
                String f = r.optJSONObject("meta").optString("file");
                main.post(() -> { load(); open(f); });
            } catch (Exception e) { main.post(() -> toast(e.getMessage())); }
        });
    }

    interface Got { void got(String s); }

    private void ask(String title, String start, Got then) {
        EditText e = new EditText(this);
        e.setText(start);
        e.setSingleLine(true);
        new AlertDialog.Builder(this).setTitle(title).setView(e)
                .setPositiveButton("OK", (d, w) -> then.got(e.getText().toString().trim()))
                .setNegativeButton("Cancel", null).show();
    }

    private Button small(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setMinWidth(0);
        b.setMinimumWidth(Ui.dp(this, 44));
        b.setPadding(Ui.dp(this, 6), 0, Ui.dp(this, 6), 0);
        return b;
    }

    // ── one meta ─────────────────────────────────────────────────────────

    private void readRules() {
        rules.clear();
        JSONArray a = meta.optJSONArray("rules");
        if (a != null) for (int i = 0; i < a.length(); i++) rules.add(a.optJSONObject(i));
        metaName = meta.optString("name");
        dirty = false;
    }

    private List<String> states() {
        List<String> l = new ArrayList<>();
        for (JSONObject r : rules) { String s = r.optString("state", "Default"); if (!l.contains(s)) l.add(s); }
        int d = l.indexOf("Default");
        if (d > 0) { l.remove(d); l.add(0, "Default"); }
        if (l.isEmpty()) l.add("Default");
        return l;
    }

    private void markDirty(boolean d) {
        dirty = d;
        if (status != null) {
            status.setText(d ? "Not saved" : rules.size() + " rules in " + states().size() + " states");
            status.setTextColor(d ? Ui.AMBER : Ui.muted(this));
        }
    }

    private void showMeta() {
        root.removeAllViews();
        setTitle("Meta - " + metaName);
        LinearLayout top = Ui.hbox(this);
        status = Ui.text(this, "", 14, false);
        top.addView(status, Ui.weight(1));
        Button save = new Button(this);
        save.setText("Save");
        save.setOnClickListener(v -> save(false, false));
        top.addView(save);
        root.addView(top);
        markDirty(dirty);

        LinearLayout nc = Ui.card(this);
        EditText name = new EditText(this);
        name.setText(metaName);
        name.setSingleLine(true);
        name.addTextChangedListener(new Watch(s -> { metaName = s; markDirty(true); }));
        nc.addView(labelled("Name", name));
        Button addState = small("+ State");
        addState.setOnClickListener(v -> ask("New state", "", s -> {
            if (s.isEmpty() || states().contains(s)) { toast(s.isEmpty() ? "Give it a name." : "There's already a state " + s + "."); return; }
            JSONObject r = newRule(s);
            rules.add(r);
            markDirty(true);
            showMeta();
            editRule(r);
        }));
        nc.addView(addState);
        root.addView(nc);

        for (String st : states()) {
            LinearLayout c = Ui.card(this);
            LinearLayout h = Ui.hbox(this);
            TextView t = Ui.text(this, "State: " + st, 16, true);
            h.addView(t, Ui.weight(1));
            Button ren = small("Rename"), add = small("+ Rule"), del = small("✕");
            ren.setOnClickListener(v -> ask("Rename state " + st, st, n -> renameState(st, n)));
            add.setOnClickListener(v -> { JSONObject r = newRule(st); rules.add(lastIndexOf(st) + 1, r); markDirty(true); showMeta(); editRule(r); });
            del.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Delete state " + st + "?")
                    .setMessage("Its rules go too.")
                    .setPositiveButton("Delete", (d, w) -> { rules.removeIf(r -> r.optString("state", "Default").equals(st)); markDirty(true); showMeta(); })
                    .setNegativeButton("Cancel", null).show());
            h.addView(ren); h.addView(add); h.addView(del);
            c.addView(h);
            int n = 0;
            for (int i = 0; i < rules.size(); i++) {
                JSONObject r = rules.get(i);
                if (!r.optString("state", "Default").equals(st)) continue;
                n++;
                final int idx = i;
                LinearLayout line = Ui.hbox(this);
                TextView rt = Ui.text(this, n + ". If " + descCond(r.optJSONObject("cond")) + "\n    → " + descAct(r.optJSONObject("act")), 14, false);
                rt.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
                rt.setOnClickListener(v -> editRule(r));
                line.addView(rt, Ui.weight(1));
                Button up = small("▲"), dn = small("▼"), rd = small("✕");
                up.setOnClickListener(v -> moveInState(idx, -1, false));
                up.setOnLongClickListener(v -> { moveInState(idx, -1, true); return true; });
                dn.setOnClickListener(v -> moveInState(idx, 1, false));
                dn.setOnLongClickListener(v -> { moveInState(idx, 1, true); return true; });
                rd.setOnClickListener(v -> { rules.remove(idx); markDirty(true); showMeta(); });
                LinearLayout col = Ui.vbox(this);
                LinearLayout r1 = Ui.hbox(this); r1.addView(up); r1.addView(dn);
                col.addView(r1);
                col.addView(rd);
                line.addView(col);
                c.addView(line);
            }
            if (n == 0) c.addView(Ui.text(this, "No rules.", 14, false));
            root.addView(c);
        }
    }

    private int lastIndexOf(String st) {
        int last = rules.size() - 1;
        for (int i = 0; i < rules.size(); i++) if (rules.get(i).optString("state", "Default").equals(st)) last = i;
        return last;
    }

    private void moveInState(int idx, int dir, boolean toEnd) {
        String st = rules.get(idx).optString("state", "Default");
        int j = idx;
        while (true) {
            int k = j + dir;
            while (k >= 0 && k < rules.size() && !rules.get(k).optString("state", "Default").equals(st)) k += dir;
            if (k < 0 || k >= rules.size()) break;
            j = k;
            if (!toEnd) break;
        }
        if (j == idx) return;
        JSONObject r = rules.remove(idx);
        rules.add(j, r);
        markDirty(true);
        showMeta();
    }

    private JSONObject newRule(String state) {
        try {
            return new JSONObject().put("state", state).put("cond", newNode(true, 1)).put("act", newNode(false, 0));
        } catch (Exception e) { return new JSONObject(); }
    }

    private void renameState(String from, String to) {
        if (to.isEmpty() || to.equals(from)) return;
        if (states().contains(to)) { toast("There's already a state " + to + "."); return; }
        for (JSONObject r : rules) {
            try {
                if (r.optString("state", "Default").equals(from)) r.put("state", to);
                renameIn(r.optJSONObject("act"), from, to);
            } catch (Exception ignored) { }
        }
        markDirty(true);
        showMeta();
    }

    /** "Go to state", "Call state" and watchdog states that named the old name now name the new one. */
    private void renameIn(JSONObject a, String from, String to) throws Exception {
        if (a == null) return;
        JSONArray kids = a.optJSONArray("kids");
        if (kids != null) { for (int i = 0; i < kids.length(); i++) renameIn(kids.optJSONObject(i), from, to); return; }
        int t = a.optInt("type");
        JSONObject d = a.optJSONObject("data");
        if (d == null) return;
        if (t == 1 && from.equals(d.optString("s"))) d.put("s", to);
        if (t == 5 || t == 9) {
            JSONArray rows = d.optJSONArray("rows");
            if (rows != null) for (int i = 0; i < rows.length(); i++) {
                JSONArray row = rows.optJSONArray(i);
                String k = row.optJSONObject(0).optString("s");
                if ((k.equals("st") || k.equals("ret") || k.equals("s")) && from.equals(row.optJSONObject(1).optString("s"))) row.optJSONObject(1).put("s", to);
            }
        }
    }

    // ── types ────────────────────────────────────────────────────────────

    private JSONObject typeDef(boolean cond, int id) {
        JSONArray a = cond ? condTypes : actTypes;
        for (int i = 0; a != null && i < a.length(); i++) if (a.optJSONObject(i).optInt("id") == id) return a.optJSONObject(i);
        return null;
    }

    private String typeName(boolean cond, int id) {
        JSONObject t = typeDef(cond, id);
        return t != null ? t.optString("name") : (cond ? "condition " : "action ") + id;
    }

    private static JSONObject val(String t, String s) {
        try { return new JSONObject().put("t", t).put("s", s); } catch (Exception e) { return new JSONObject(); }
    }

    /** A fresh condition / action of a type, with empty settings of the right kinds. */
    private JSONObject newNode(boolean cond, int id) {
        JSONObject n = new JSONObject();
        try {
            n.put("type", id);
            JSONObject t = typeDef(cond, id);
            String data = t == null ? "" : t.optString("data");
            switch (data) {
                case "kids": n.put("kids", new JSONArray()); break;
                case "s": n.put("data", val("s", "")); break;
                case "kv": {
                    JSONObject tb = new JSONObject().put("t", "TABLE").put("cols", new JSONArray().put("k").put("v")).put("flags", new JSONArray().put("n").put("n"));
                    JSONArray rows = new JSONArray();
                    JSONArray keys = t.optJSONArray("keys");
                    for (int i = 0; keys != null && i < keys.length(); i++) {
                        JSONArray k = keys.optJSONArray(i);
                        String kind = k.optString(1);
                        JSONObject v = kind.equals("ba") ? new JSONObject().put("t", "ba").put("b64", "") : val(kind, kind.equals("s") ? "" : "0");
                        rows.put(new JSONArray().put(val("s", k.optString(0))).put(v));
                    }
                    tb.put("rows", rows);
                    n.put("data", tb);
                    break;
                }
                default: n.put("data", val("i", "0"));
            }
        } catch (Exception ignored) { }
        return n;
    }

    // ── descriptions ─────────────────────────────────────────────────────

    private static String hex(String s) {
        try { return Integer.toHexString((int) Long.parseLong(s)).toUpperCase(Locale.US); } catch (Exception e) { return s; }
    }

    private String dataText(JSONObject def, JSONObject data) {
        if (data == null) return "";
        String kind = def == null ? "" : def.optString("data");
        String t = data.optString("t");
        if (t.equals("TABLE")) {
            JSONArray rows = data.optJSONArray("rows");
            StringBuilder b = new StringBuilder();
            for (int i = 0; rows != null && i < rows.length(); i++) {
                JSONArray row = rows.optJSONArray(i);
                String k = row.optJSONObject(0).optString("s");
                JSONObject v = row.optJSONObject(1);
                String vs = v.optString("t").equals("ba") ? "(" + Base64.decode(v.optString("b64"), 0).length + " bytes)" : v.optString("s");
                if (b.length() > 0) b.append(", ");
                b.append(label(def, k)).append(' ').append(vs);
            }
            return b.toString();
        }
        if (t.equals("ba")) return "(" + Base64.decode(data.optString("b64"), 0).length + " bytes)";
        if (kind.isEmpty()) return "";
        return kind.equals("hex") ? hex(data.optString("s")) : data.optString("s");
    }

    private static String label(JSONObject def, String key) {
        JSONArray keys = def == null ? null : def.optJSONArray("keys");
        for (int i = 0; keys != null && i < keys.length(); i++) if (keys.optJSONArray(i).optString(0).equals(key)) return keys.optJSONArray(i).optString(2);
        return key;
    }

    private String descCond(JSONObject c) {
        if (c == null) return "?";
        int t = c.optInt("type");
        JSONArray kids = c.optJSONArray("kids");
        if (kids != null) {
            List<String> l = new ArrayList<>();
            for (int i = 0; i < kids.length(); i++) l.add(descCond(kids.optJSONObject(i)));
            if (t == 21) return "not (" + String.join(" and ", l) + ")";
            return "(" + String.join(t == 3 ? " or " : " and ", l) + ")";
        }
        String d = dataText(typeDef(true, t), c.optJSONObject("data"));
        return typeName(true, t) + (d.isEmpty() ? "" : " " + d);
    }

    private String descAct(JSONObject a) {
        if (a == null) return "?";
        int t = a.optInt("type");
        JSONArray kids = a.optJSONArray("kids");
        if (kids != null) {
            List<String> l = new ArrayList<>();
            for (int i = 0; i < kids.length(); i++) l.add(descAct(kids.optJSONObject(i)));
            return String.join("; ", l);
        }
        String d = dataText(typeDef(false, t), a.optJSONObject("data"));
        return typeName(false, t) + (d.isEmpty() ? "" : " " + d);
    }

    // ── the rule editor ──────────────────────────────────────────────────

    private void editRule(JSONObject rule) {
        JSONObject work;
        try { work = new JSONObject(rule.toString()); } catch (Exception e) { return; }
        ScrollView sv = new ScrollView(this);
        LinearLayout box = Ui.vbox(this);
        int p = Ui.dp(this, 12);
        box.setPadding(p, p, p, p);
        sv.addView(box);
        TextView ch = Ui.text(this, "When (condition)", 15, true);
        box.addView(ch);
        LinearLayout cbox = Ui.vbox(this);
        box.addView(cbox);
        nodeEditor(cbox, work, "cond", true, 0, null);
        TextView ah = Ui.text(this, "Then (action)", 15, true);
        ah.setPadding(0, Ui.dp(this, 14), 0, 0);
        box.addView(ah);
        LinearLayout abox = Ui.vbox(this);
        box.addView(abox);
        nodeEditor(abox, work, "act", false, 0, null);
        AlertDialog dlg = new AlertDialog.Builder(this).setTitle("Rule in " + rule.optString("state", "Default")).setView(sv)
                .setPositiveButton("OK", (d, w) -> {
                    try {
                        rule.put("cond", work.getJSONObject("cond"));
                        rule.put("act", work.getJSONObject("act"));
                    } catch (Exception ignored) { }
                    markDirty(true);
                    showMeta();
                })
                .setNegativeButton("Cancel", null).show();
        // A dialog only lets the keyboard in for text boxes it had when it opened - boxes that appear after picking a
        // condition or action got no keyboard. Let it in for all of them (and keep it hidden until one is tapped).
        if (dlg.getWindow() != null) {
            dlg.getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | android.view.WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
            dlg.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN | android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
    }

    /** Draws the node at holder[key] (a condition or an action) into box; kids get their own boxes, indented. */
    private void nodeEditor(LinearLayout box, Object holder, Object key, boolean cond, int depth, Runnable parentRedraw) {
        Runnable redraw = () -> nodeEditor(box, holder, key, cond, depth, parentRedraw);
        box.removeAllViews();
        JSONObject node = get(holder, key);
        if (node == null) return;
        box.setPadding(Ui.dp(this, depth == 0 ? 0 : 12), Ui.dp(this, 2), 0, Ui.dp(this, 2));
        JSONArray types = cond ? condTypes : actTypes;
        String[] names = new String[types.length()];
        int sel = 0;
        for (int i = 0; i < types.length(); i++) {
            names[i] = types.optJSONObject(i).optString("name");
            if (types.optJSONObject(i).optInt("id") == node.optInt("type")) sel = i;
        }
        LinearLayout head = Ui.hbox(this);
        Spinner sp = spinner(names, sel);
        final int selected = sel;
        sp.setOnItemSelectedListener(new NavEditorActivity.Sel(i -> {
            if (i == selected) return;
            JSONObject fresh = newNode(cond, types.optJSONObject(i).optInt("id"));
            // keep the kids when switching between All / Any / Not
            if (fresh.has("kids") && node.has("kids")) { try { fresh.put("kids", node.optJSONArray("kids")); } catch (Exception ignored) { } }
            set(holder, key, fresh);
            redraw.run();
        }));
        head.addView(sp, Ui.weight(1));
        if (holder instanceof JSONArray && parentRedraw != null) {
            JSONArray arr = (JSONArray) holder;
            int idx = (Integer) key;
            Button up = small("▲"), del = small("✕");
            up.setOnClickListener(v -> {
                if (idx == 0) return;
                try { Object a = arr.get(idx - 1); arr.put(idx - 1, arr.get(idx)); arr.put(idx, a); } catch (Exception ignored) { }
                parentRedraw.run();
            });
            del.setOnClickListener(v -> { arr.remove(idx); parentRedraw.run(); });
            head.addView(up); head.addView(del);
        }
        box.addView(head);
        JSONObject def = typeDef(cond, node.optInt("type"));
        if (def != null && !def.optString("help").isEmpty()) {
            TextView h = Ui.text(this, def.optString("help"), 12, false);
            h.setTextColor(Ui.muted(this));
            box.addView(h);
        }
        String kind = def == null ? "" : def.optString("data");
        JSONObject data = node.optJSONObject("data");
        if (node.has("kids")) {
            JSONArray kids = node.optJSONArray("kids");
            LinearLayout kb = Ui.vbox(this);
            for (int i = 0; i < kids.length(); i++) {
                LinearLayout one = Ui.vbox(this);
                kb.addView(one);
                nodeEditor(one, kids, i, cond, depth + 1, redraw);
            }
            box.addView(kb);
            Button add = small(cond ? "+ Condition" : "+ Action");
            add.setOnClickListener(v -> {
                kids.put(newNode(cond, cond ? 1 : 2));
                redraw.run();
            });
            box.addView(add);
        } else if (data != null) {
            if (data.optString("t").equals("TABLE")) {
                JSONArray rows = data.optJSONArray("rows");
                for (int i = 0; rows != null && i < rows.length(); i++) {
                    JSONArray row = rows.optJSONArray(i);
                    String k = row.optJSONObject(0).optString("s");
                    JSONObject v = row.optJSONObject(1);
                    box.addView(valueField(label(def, k), v, cond, node.optInt("type"), k));
                }
            } else if (data.optString("t").equals("ba")) {
                box.addView(hintText("Embedded data (" + Base64.decode(data.optString("b64"), 0).length + " bytes) - kept as it is."));
            } else if (!kind.isEmpty()) {
                box.addView(valueField(kind.equals("hex") ? "Value (hex)" : "Value", data, cond, node.optInt("type"), kind.equals("hex") ? "#hex" : ""));
            }
        }
    }

    private static JSONObject get(Object holder, Object key) {
        if (holder instanceof JSONArray) return ((JSONArray) holder).optJSONObject((Integer) key);
        return ((JSONObject) holder).optJSONObject((String) key);
    }

    private static void set(Object holder, Object key, JSONObject v) {
        try {
            if (holder instanceof JSONArray) ((JSONArray) holder).put((Integer) key, v);
            else {
                ((JSONObject) holder).put((String) key, v);
            }
        } catch (Exception ignored) { }
    }

    /** One editable value: text / number / hex, a state picker for state names, a big box for expressions and bytes. */
    private View valueField(String label, JSONObject v, boolean cond, int type, String key) {
        String t = v.optString("t");
        boolean stateName = !cond && ((type == 1) || (type == 5 && (key.equals("st") || key.equals("ret"))) || (type == 9 && key.equals("s")));
        boolean routeName = !cond && type == 2;
        // Fixed choices are pickers (no keyboard): states, MelkTank switches, on / off, routes.
        if (stateName) return labelled(label.equals("Value") ? "State" : label, picker(states(), v, null));
        if (!cond && (type == 11 || type == 12) && key.equals("o")) return labelled(label, picker(Arrays.asList(MT_OPTIONS), v, null));
        if (!cond && type == 12 && key.equals("v")) {
            String cur = v.optString("s").trim().toLowerCase(Locale.US);
            if (cur.equals("0") || cur.equals("off")) put(v, "s", "false");
            else if (cur.equals("1") || cur.equals("on")) put(v, "s", "true");
            return labelled(label, picker(Arrays.asList("true", "false"), v, "true"));
        }
        if (!cond && type == 104 && key.equals("n")) return labelled(label, picker(routeNames, v, null));
        if (t.equals("ba")) {
            EditText e = new EditText(this);
            e.setText(new String(Base64.decode(v.optString("b64"), 0), StandardCharsets.ISO_8859_1));
            e.setMinLines(3);
            e.addTextChangedListener(new Watch(s -> put(v, "b64", Base64.encodeToString(s.getBytes(StandardCharsets.ISO_8859_1), Base64.NO_WRAP))));
            return labelled(label, e);
        }
        EditText e = new EditText(this);
        boolean hex = key.equals("#hex");
        e.setText(hex ? hex(v.optString("s")) : v.optString("s"));
        boolean longText = label.equalsIgnoreCase("expression") || label.equalsIgnoreCase("pattern") || routeName;
        if (longText) e.setMinLines(2); else e.setSingleLine(true);
        if (t.equals("i") && !hex) e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        if (t.equals("d")) e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        e.addTextChangedListener(new Watch(s -> {
            if (hex) { try { put(v, "s", String.valueOf((int) Long.parseLong(s.trim(), 16))); } catch (Exception ignored) { } }
            else put(v, "s", s);
        }));
        View row = labelled(label, e);
        if (hex && cond && (type == 17 || type == 18)) {
            // Landblock / Landcell: read it from one of your characters in game
            LinearLayout col = Ui.vbox(this);
            col.addView(row);
            Button pick = small("From a character...");
            pick.setOnClickListener(x -> fromCharacter(type == 17, e));
            col.addView(pick);
            return col;
        }
        if (routeName && !routeNames.isEmpty()) {
            LinearLayout col = Ui.vbox(this);
            col.addView(row);
            Button pick = small("Load a route...");
            pick.setOnClickListener(x -> new AlertDialog.Builder(this).setTitle("Route").setItems(routeNames.toArray(new String[0]),
                    (d, w) -> e.setText("/mtank nav load " + routeNames.get(w))).show());
            col.addView(pick);
            return col;
        }
        return row;
    }

    /** Lists the characters in game with where they stand, and fills in that landblock (or the whole landcell). */
    private void fromCharacter(boolean block, EditText target) {
        io.execute(() -> {
            List<String> names = new ArrayList<>();
            List<Long> cells = new ArrayList<>();
            String err = null;
            try {
                JSONArray accs = Api.status(prefs).optJSONArray("accounts");
                for (int i = 0; accs != null && i < accs.length(); i++) {
                    JSONObject a = accs.optJSONObject(i);
                    if (a == null || !"online".equals(a.optString("state")) || !a.has("landcell")) continue;
                    long cell = a.optLong("landcell") & 0xFFFFFFFFL;
                    String ch = a.optString("character", a.optString("account"));
                    String loc = a.optString("location", "");
                    names.add(ch + "  -  " + String.format(Locale.US, "%08X", cell) + (loc.isEmpty() ? "" : "  (" + loc + ")"));
                    cells.add(cell);
                }
            } catch (Exception ex) { err = ex.getMessage(); }
            String e2 = err;
            main.post(() -> {
                if (e2 != null) { toast(e2); return; }
                if (names.isEmpty()) { toast("No character in game has sent where it is yet."); return; }
                new AlertDialog.Builder(this).setTitle(block ? "Landblock of..." : "Landcell of...")
                        .setItems(names.toArray(new String[0]), (d, w) -> {
                            long c = cells.get(w);
                            if (block) c &= 0xFFFF0000L;   // a landblock compares the top half only
                            target.setText(String.format(Locale.US, "%08X", c));
                        }).show();
            });
        });
    }

    private static void put(JSONObject o, String k, String v) {
        try { o.put(k, v); } catch (Exception ignored) { }
    }

    // ── saving ───────────────────────────────────────────────────────────

    private void save(boolean force, boolean thenFinish) {
        try {
            JSONArray a = new JSONArray();
            for (JSONObject r : rules) a.put(r);
            JSONObject data = new JSONObject().put("name", metaName).put("rules", a);
            String f = meta.optString("file");
            long mt = meta.optLong("mtime");
            io.execute(() -> {
                try {
                    JSONObject r = Api.metaSave(prefs, f, mt, data, force);
                    main.post(() -> {
                        if (r.has("error") && !r.has("meta")) {
                            new AlertDialog.Builder(this).setTitle("Not saved").setMessage(r.optString("error"))
                                    .setPositiveButton("Save anyway", (d, w) -> save(true, thenFinish))
                                    .setNegativeButton("Cancel", null).show();
                            return;
                        }
                        meta = r.optJSONObject("meta");
                        file = meta.optString("file");
                        readRules();
                        toast("Saved" + (r.optJSONArray("sent") != null && r.optJSONArray("sent").length() > 0 ? " - a game running it reads it again" : ""));
                        if (thenFinish) finish(); else showMeta();
                    });
                } catch (Exception e) { main.post(() -> toast(e.getMessage())); }
            });
        } catch (Exception e) { toast(e.getMessage()); }
    }

    // ── helpers ──────────────────────────────────────────────────────────

    static class Watch implements android.text.TextWatcher {
        private final Got g;
        Watch(Got g) { this.g = g; }
        @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
        @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
        @Override public void afterTextChanged(android.text.Editable s) { g.got(s.toString()); }
    }

    /**
     * A drop-down of fixed choices writing into v's "s". A value that isn't in the list (a state that's gone, a $variable,
     * a route that was renamed) is kept and shown first, so nothing changes until you pick something else.
     * def: what an empty value becomes (null: the first choice).
     */
    private Spinner picker(List<String> choices, JSONObject v, String def) {
        List<String> items = new ArrayList<>(choices);
        String cur = v.optString("s");
        if (cur.isEmpty()) { cur = def != null ? def : (items.isEmpty() ? "" : items.get(0)); put(v, "s", cur); }
        if (!items.contains(cur)) items.add(0, cur);
        Spinner sp = spinner(items.toArray(new String[0]), Math.max(0, items.indexOf(cur)));
        sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> p, View vw, int pos, long id) { put(v, "s", items.get(pos)); }
            @Override public void onNothingSelected(android.widget.AdapterView<?> p) { }
        });
        return sp;
    }

    private Spinner spinner(String[] items, int sel) {
        Spinner s = new Spinner(this);
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(ad);
        s.setSelection(Math.max(0, Math.min(sel, items.length - 1)));
        return s;
    }

    private View labelled(String label, View v) {
        LinearLayout row = Ui.hbox(this);
        TextView t = Ui.text(this, label, 14, false);
        t.setTextColor(Ui.muted(this));
        row.addView(t, new LinearLayout.LayoutParams(Ui.dp(this, 96), LinearLayout.LayoutParams.WRAP_CONTENT));
        row.addView(v, Ui.weight(1));
        return row;
    }

    private TextView hintText(String s) {
        TextView t = Ui.text(this, s, 13, false);
        t.setTextColor(Ui.muted(this));
        return t;
    }
}
