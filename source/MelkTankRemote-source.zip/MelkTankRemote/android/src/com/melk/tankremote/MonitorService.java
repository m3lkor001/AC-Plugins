package com.melk.tankremote;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Runs in the background (with a small always-on notification, which Android requires) and checks the PC every
 * "check every" seconds, so the alerts arrive while the app is closed.
 */
public class MonitorService extends Service {
    private HandlerThread thread;
    private Handler handler;
    private volatile boolean running;

    static void start(Context c) {
        if (!new Prefs(c).alerts() || !new Prefs(c).configured()) { stop(c); return; }
        c.startForegroundService(new Intent(c, MonitorService.class));
    }

    static void stop(Context c) { c.stopService(new Intent(c, MonitorService.class)); }

    @Override
    public void onCreate() {
        super.onCreate();
        Alerts.channels(this);
        thread = new HandlerThread("melktank-monitor");
        thread.start();
        handler = new Handler(thread.getLooper());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (android.os.Build.VERSION.SDK_INT >= 34)
            startForeground(1, watching("Starting..."), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else
            startForeground(1, watching("Starting..."));
        if (!running) {
            running = true;
            handler.post(this::poll);
        }
        return START_STICKY;
    }

    private Notification watching(String text) {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, new Prefs(this).showWatching() ? Alerts.CH_MONITOR : Alerts.CH_MONITOR_HIDDEN)
                .setSmallIcon(R.drawable.ic_notify)
                .setContentTitle("MelkTank Remote")
                .setContentText(text)
                .setContentIntent(open)
                .setOngoing(true)
                .build();
    }

    private void poll() {
        if (!running) return;
        Prefs p = new Prefs(this);
        String line;
        try {
            JSONObject st = Api.status(p);
            Alerts.check(this, p, st);
            line = summary(st);
        } catch (Exception e) {
            Alerts.check(this, p, null);
            line = "Can't reach the PC right now";
        }
        try { getSystemService(android.app.NotificationManager.class).notify(1, watching(line)); } catch (Exception ignored) { }
        handler.postDelayed(this::poll, p.pollSeconds() * 1000L);
    }

    static String summary(JSONObject st) {
        JSONArray a = st.optJSONArray("accounts");
        int online = 0, total = a == null ? 0 : a.length();
        for (int i = 0; i < total; i++) if ("online".equals(a.optJSONObject(i).optString("state"))) online++;
        return online + " of " + total + " in game";
    }

    @Override
    public void onDestroy() {
        running = false;
        if (thread != null) thread.quitSafely();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
