package com.melk.tankremote;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Layout helpers - the app builds its screens in code. */
final class Ui {
    private Ui() {}

    static int dp(Context c, float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics());
    }

    static boolean dark(Context c) {
        return (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    static int cardColor(Context c) { return dark(c) ? Color.rgb(38, 41, 46) : Color.rgb(246, 247, 249); }
    static int lineColor(Context c) { return dark(c) ? Color.rgb(60, 64, 70) : Color.rgb(222, 225, 230); }
    static int muted(Context c) { return dark(c) ? Color.rgb(160, 165, 172) : Color.rgb(100, 106, 115); }

    static final int GREEN = Color.rgb(46, 157, 79);
    static final int AMBER = Color.rgb(215, 155, 0);
    static final int GREY = Color.rgb(140, 140, 140);
    static final int RED = Color.rgb(200, 60, 60);

    static LinearLayout vbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout hbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    static LinearLayout card(Context c) {
        LinearLayout l = new SwipeLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(cardColor(c));
        bg.setCornerRadius(dp(c, 14));
        bg.setStroke(dp(c, 1), lineColor(c));
        l.setBackground(bg);
        int p = dp(c, 14);
        l.setPadding(p, p, p, p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(c, 12));
        l.setLayoutParams(lp);
        return l;
    }

    static TextView text(Context c, String s, float sp, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    /** A rounded coloured label (state chip). */
    static TextView chip(Context c) {
        TextView t = text(c, "", 13, true);
        t.setTextColor(Color.WHITE);
        int h = dp(c, 10), v = dp(c, 3);
        t.setPadding(h, v, h, v);
        return t;
    }

    static void chipColor(Context c, TextView t, int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(c, 20));
        t.setBackground(bg);
    }

    static LinearLayout.LayoutParams weight(float w) {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, w);
    }
}
