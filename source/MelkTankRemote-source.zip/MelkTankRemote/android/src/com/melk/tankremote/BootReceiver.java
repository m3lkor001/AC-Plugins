package com.melk.tankremote;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Starts the watcher again after the phone restarts (when alerts are on). */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())) {
            try { MonitorService.start(c); } catch (Exception ignored) { }
        }
    }
}
