package com.melk.tankremote;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * One character's MelkTank settings: every single-value setting and Tuning value, changed here and sent with
 * "Apply" (MelkTank uses them straight away, no relog), plus settings snapshots (save / restore / delete).
 */
public class MtSettingsActivity extends Activity {
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private Prefs prefs;
    private String account, title;
    private LinearLayout list, snaps;
    private EditText search;
    private Button apply;
    private TextView status;
    private JSONObject data;
    private final Map<String, String> changes = new LinkedHashMap<>();
    private final Map<String, String> current = new LinkedHashMap<>();
    private static final int CHANGED = Color.rgb(215, 155, 0);

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        account = getIntent().getStringExtra("account");
        title = getIntent().getStringExtra("title");
        if (title == null) title = account;
        setTitle("MelkTank settings - " + title);
        if (getActionBar() != null) getActionBar().setDisplayHomeAsUpEnabled(true);   // back arrow

        FrameLayout frame = new FrameLayout(this);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = Ui.vbox(this);
        int p = Ui.dp(this, 14);
        root.setPadding(p, p, p, Ui.dp(this, 80));

        status = Ui.text(this, "Loading...", 13, false);
        status.setTextColor(Ui.muted(this));
        root.addView(status);

        // snapshots
        LinearLayout sc = Ui.card(this);
        sc.addView(Ui.text(this, "Snapshots", 16, true));
        TextView sh = Ui.text(this, "All of this character's settings (monsters, routes, tuning ...) saved under a name. "
                + "Restoring one keeps the settings it replaces as \"before-restore\".", 12, false);
        sh.setTextColor(Ui.muted(this));
        sc.addView(sh);
        snaps = Ui.vbox(this);
        sc.addView(snaps);
        LinearLayout saveRow = Ui.hbox(this);
        EditText snapName = new EditText(this);
        snapName.setHint("name (blank = date)");
        snapName.setSingleLine(true);
        saveRow.addView(snapName, Ui.weight(1));
        Button save = new Button(this);
        save.setText("Save snapshot");
        save.setOnClickListener(v -> snapshot("save", snapName.getText().toString().trim()));
        saveRow.addView(save);
        sc.addView(saveRow);
        root.addView(sc);

        search = new EditText(this);
        search.setHint("Search settings (e.g. fracture, recovery, loot)");
        search.setSingleLine(true);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int c, int d) { }
            public void onTextChanged(CharSequence s, int a, int c, int d) { }
            public void afterTextChanged(Editable s) { draw(); }
        });
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        sp.topMargin = Ui.dp(this, 12);
        root.addView(search, sp);

        list = Ui.vbox(this);
        root.addView(list);
        scroll.addView(root);
        frame.addView(scroll);

        apply = new Button(this);
        apply.setText("Apply");
        apply.setVisibility(View.GONE);
        apply.setOnClickListener(v -> applyChanges());
        FrameLayout.LayoutParams ap = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        ap.setMargins(p, 0, p, p);
        frame.addView(apply, ap);
        setContentView(PullRefresh.wrap(this, frame, this::pullRefresh));
        load();
    }

    @Override
    public boolean onOptionsItemSelected(android.view.MenuItem item) {
        if (item.getItemId() == android.R.id.home) { finish(); return true; }
        return super.onOptionsItemSelected(item);
    }

    /** Pull down: MelkTank writes its status right away, then the page loads again. */
    private void pullRefresh(PullRefresh pr) {
        io.execute(() -> {
            try { if (account != null) Api.refresh(prefs, account); } catch (Exception ignored) { }
            main.postDelayed(() -> { load(); main.postDelayed(pr::done, 800); }, 2500);
        });
    }

    private void load() {
        io.execute(() -> {
            try {
                JSONObject r = Api.mtSettings(prefs, account);
                main.post(() -> { data = r; changes.clear(); cmdsFrom(r.optJSONObject("logincmds")); status.setText(r.optString("character") + " - change values, then Apply. They take effect straight away."); drawSnaps(); draw(); });
            } catch (Exception e) {
                main.post(() -> status.setText(e.getMessage()));
            }
        });
    }

    private void drawSnaps() {
        snaps.removeAllViews();
        JSONArray a = data.optJSONArray("snapshots");
        if (a == null || a.length() == 0) {
            TextView t = Ui.text(this, "None yet.", 14, false);
            t.setPadding(0, Ui.dp(this, 6), 0, 0);
            snaps.addView(t);
            return;
        }
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            String n = o.optString("name");
            LinearLayout row = Ui.hbox(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView t = Ui.text(this, n, 15, true);
            TextView when = Ui.text(this, "  " + o.optString("time"), 12, false);
            when.setTextColor(Ui.muted(this));
            LinearLayout col = Ui.vbox(this);
            col.addView(t);
            col.addView(when);
            row.addView(col, Ui.weight(1));
            Button r = new Button(this);
            r.setText("Restore");
            r.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setTitle("Restore " + n + "?")
                    .setMessage("All of " + title + "'s settings go back to this snapshot (" + o.optString("time") + "), switches included. "
                            + "The current ones are saved as before-restore first.")
                    .setPositiveButton("Restore", (d, w) -> snapshot("restore", n))
                    .setNegativeButton("Cancel", null).show());
            row.addView(r);
            Button del = new Button(this);
            del.setText("Delete");
            del.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setTitle("Delete snapshot " + n + "?")
                    .setPositiveButton("Delete", (d, w) -> snapshot("delete", n))
                    .setNegativeButton("Cancel", null).show());
            row.addView(del);
            snaps.addView(row);
        }
    }

    private void snapshot(String action, String name) {
        io.execute(() -> {
            String msg;
            try { msg = Api.snapshot(prefs, account, action, name).optString("message", "Sent."); }
            catch (Exception e) { msg = e.getMessage(); }
            String m = msg;
            main.post(() -> { Toast.makeText(this, m, Toast.LENGTH_LONG).show(); main.postDelayed(this::load, 3500); });
        });
    }

    private static class Row { String key, label, value, kind, unit, tip, category, section = ""; double min, max, def; boolean tuning; }

    private List<Row> rows() {
        List<Row> r = new ArrayList<>();
        if (data == null) return r;
        JSONArray t = data.optJSONArray("tuning");
        for (int i = 0; t != null && i < t.length(); i++) {
            JSONObject o = t.optJSONObject(i);
            Row x = new Row();
            x.tuning = true; x.key = o.optString("key"); x.label = o.optString("label"); x.unit = o.optString("unit");
            x.tip = o.optString("tip"); x.category = "Settings - Advanced - " + o.optString("category");
            x.min = o.optDouble("min"); x.max = o.optDouble("max"); x.def = o.optDouble("default");
            x.value = num(o.optDouble("value")); x.kind = "number";
            r.add(x);
        }
        JSONArray s = data.optJSONArray("settings");
        for (int i = 0; s != null && i < s.length(); i++) {
            JSONObject o = s.optJSONObject(i);
            Row x = new Row();
            // the item tracking list's parts (shown with the list; an empty one comes through as a blank setting)
            String nm = o.optString("name");
            if (nm.equals("TrackProfile") || nm.equals("TrackProfiles") || nm.equals("TrackLive") || nm.equals("TrackList") || nm.equals("ChatFilter")) continue;
            x.key = o.optString("name"); x.value = o.optString("value"); x.kind = o.optString("kind");
            x.section = o.optString("section", "");
            // the label from MelkTank's Settings window when it sent one, else the phone's own, else the name
            String pcLabel = o.optString("label", "");
            x.label = (pcLabel.length() > 0 ? pcLabel : LABELS.containsKey(x.key) ? LABELS.get(x.key) : x.key) + (pcLabel.length() > 0 || LABELS.containsKey(x.key) ? "  (" + x.key + ")" : "");
            x.category = "Settings"; x.unit = ""; x.tip = "";
            r.add(x);
        }
        // MelkTank's Settings > Commands (login / periodic commands) - edited and saved straight away, not with Apply
        if (cmdServer != null) {
            Row x = new Row();
            x.key = "LoginCommands"; x.label = "Commands at login / every N minutes"; x.value = ""; x.kind = "cmds";
            x.category = "Settings"; x.section = "Settings - Commands"; x.unit = ""; x.tip = "";
            r.add(x);
        }
        // lists: one entry each (an entry can hold commas) - the item tracking list
        JSONObject lists = data.optJSONObject("lists");
        JSONArray ti = lists != null ? lists.optJSONArray("TrackItems") : null;
        if (ti != null) {
            Row x = new Row();
            List<String> items = new ArrayList<>();
            for (int i = 0; i < ti.length(); i++) items.add(ti.optString(i));
            x.key = "TrackItems"; x.label = "Items to track"; x.value = String.join(SEP, items); x.kind = "list"; x.section = "Items - Tracking";
            x.category = "Settings"; x.unit = ""; x.tip = "";
            if (!changes.containsKey(x.key)) trackEdit = null;
            r.add(x);
        }
        // the chat filter: lines containing any of these are hidden from the game's chat (one list for every character)
        JSONArray cf = lists != null ? lists.optJSONArray("ChatFilter") : null;
        if (cf != null) {
            Row x = new Row();
            List<String> items = new ArrayList<>();
            for (int i = 0; i < cf.length(); i++) items.add(cf.optString(i));
            x.key = "ChatFilter"; x.label = "Hide chat lines containing"; x.value = String.join(SEP, items); x.kind = "flist"; x.section = "Settings - Chat";
            x.category = "Settings"; x.unit = ""; x.tip = "";
            if (!changes.containsKey(x.key)) filterEdit = null;
            r.add(x);
        }
        return r;
    }

    private List<String> filterEdit;   // the chat filter being edited (null = as saved)

    /** The chat filter: a row per entry with a remove button, and an Add line. */
    private View filterView(Row r) {
        LinearLayout box = Ui.vbox(this);
        box.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        if (filterEdit == null) {
            filterEdit = new ArrayList<>();
            for (String it : r.value.split(SEP, -1)) if (it.trim().length() > 0) filterEdit.add(it.trim());
        }
        TextView l = Ui.text(this, r.label + "  (" + filterEdit.size() + ")", 14, false);
        if (changes.containsKey(r.key)) l.setTextColor(CHANGED);
        box.addView(l);
        for (int i = 0; i < filterEdit.size(); i++) {
            final int idx = i;
            LinearLayout line = Ui.hbox(this);
            line.setGravity(Gravity.CENTER_VERTICAL);
            EditText e = new EditText(this);
            e.setSingleLine(true);
            e.setText(filterEdit.get(i));
            line.addView(e, Ui.weight(1));
            Button del = new Button(this);
            del.setText("\u2715");
            del.setOnClickListener(v -> { filterEdit.remove(idx); filterChanged(r); draw(); });
            line.addView(del);
            e.addTextChangedListener(new TextWatcher() {
                public void beforeTextChanged(CharSequence s2, int a, int b, int c) { }
                public void onTextChanged(CharSequence s2, int a, int b, int c) { }
                public void afterTextChanged(Editable s2) { filterEdit.set(idx, s2.toString().trim()); filterChanged(r); }
            });
            box.addView(line);
        }
        LinearLayout add = Ui.hbox(this);
        add.setGravity(Gravity.CENTER_VERTICAL);
        EditText ne = new EditText(this);
        ne.setSingleLine(true);
        ne.setHint("part of a chat line, e.g. [BANK] Enlightenment Tokens:");
        add.addView(ne, Ui.weight(1));
        Button ab = new Button(this);
        ab.setText("Add");
        ab.setOnClickListener(v -> {
            String t = ne.getText().toString().trim();
            if (t.length() == 0) return;
            filterEdit.add(t); filterChanged(r); draw();
        });
        add.addView(ab);
        box.addView(add);
        TextView tip = Ui.text(this, "Not case sensitive. Hidden lines don't show in the game's chat window (or here on the phone). One list for every character.", 12, false);
        tip.setTextColor(Ui.muted(this));
        box.addView(tip);
        return box;
    }

    private void filterChanged(Row r) {
        List<String> clean = new ArrayList<>();
        for (String t : filterEdit) if (t.trim().length() > 0) clean.add(t.trim());
        String v = String.join(SEP, clean);
        if (v.equals(r.value)) changes.remove(r.key); else changes.put(r.key, v);
        updateApply();
    }

    private static final String SEP = "\u0001";   // between list entries when sent
    private List<String> trackEdit;                 // the item tracking list being edited (null = as saved)

    /** The item tracking list: a row per entry (tick = watched for), a remove button each, and an Add line. */
    private View listView(Row r) {
        LinearLayout box = Ui.vbox(this);
        box.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        if (trackEdit == null) {
            trackEdit = new ArrayList<>();
            for (String it : r.value.split(SEP, -1)) if (it.trim().length() > 0) trackEdit.add(it.trim());
        }
        // item profile: pick, save the list as one, delete the one in use
        JSONObject lists = data.optJSONObject("lists");
        String prof = lists != null ? lists.optString("TrackProfile", "") : "";
        LinearLayout pl = Ui.hbox(this);
        pl.setGravity(Gravity.CENTER_VERTICAL);
        Button pick = new Button(this);
        pick.setAllCaps(false);
        pick.setText("Profile: " + (prof.isEmpty() ? "character's own list" : prof) + "  \u25BE");
        pick.setOnClickListener(v -> {
            List<String> names = new ArrayList<>();
            names.add("(this character's own list)");
            JSONArray ps = lists != null ? lists.optJSONArray("TrackProfiles") : null;
            for (int i = 0; ps != null && i < ps.length(); i++) names.add(ps.optString(i));
            new AlertDialog.Builder(this).setTitle("Item profile")
                    .setItems(names.toArray(new String[0]), (d, w) -> {
                        String name = w == 0 ? "" : names.get(w);
                        if (name.equalsIgnoreCase(prof)) return;
                        sendNow("TrackProfile", name);
                    }).setNegativeButton("Cancel", null).show();
        });
        pl.addView(pick, Ui.weight(1));
        Button save = new Button(this);
        save.setAllCaps(false);
        save.setText("Save as");
        save.setOnClickListener(v -> {
            EditText ne = new EditText(this);
            ne.setSingleLine(true);
            ne.setText(prof);
            ne.setHint("profile name");
            AlertDialog dlg = new AlertDialog.Builder(this).setTitle("Save this list as an item profile")
                    .setView(ne)
                    .setPositiveButton("Save", (d, w) -> { String n = ne.getText().toString().trim(); if (n.length() > 0) sendNow("TrackSaveAs", n); })
                    .setNegativeButton("Cancel", null).create();
            dlg.show();
            if (dlg.getWindow() != null) {
                dlg.getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
                dlg.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
            }
            ne.requestFocus();
        });
        pl.addView(save);
        if (!prof.isEmpty()) {
            Button del = new Button(this);
            del.setAllCaps(false);
            del.setText("Delete");
            del.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Delete item profile " + prof + "?")
                    .setMessage("The profile file is deleted and this character goes back to its own list.")
                    .setPositiveButton("Delete", (d, w) -> sendNow("TrackDeleteProfile", "1"))
                    .setNegativeButton("Cancel", null).show());
            pl.addView(del);
        }
        box.addView(pl);
        TextView l = Ui.text(this, r.label + "  (" + trackEdit.size() + ")", 14, false);
        if (changes.containsKey(r.key)) l.setTextColor(CHANGED);
        box.addView(l);
        // all of them at a glance, comma separated
        List<String> on = new ArrayList<>();
        for (String it : trackEdit) on.add(it.startsWith("~") ? "(off) " + it.substring(1) : it);
        TextView sum = Ui.text(this, on.isEmpty() ? "Nothing tracked yet." : String.join(", ", on), 12, false);
        sum.setTextColor(Ui.muted(this));
        box.addView(sum);
        for (int i = 0; i < trackEdit.size(); i++) {
            final int idx = i;
            String it = trackEdit.get(i);
            boolean off = it.startsWith("~");
            LinearLayout line = Ui.hbox(this);
            line.setGravity(Gravity.CENTER_VERTICAL);
            android.widget.CheckBox cb = new android.widget.CheckBox(this);
            cb.setChecked(!off);
            line.addView(cb);
            EditText e = new EditText(this);
            e.setSingleLine(true);
            e.setText(off ? it.substring(1) : it);
            line.addView(e, Ui.weight(1));
            Button del = new Button(this);
            del.setText("\u2715");
            del.setOnClickListener(v -> { trackEdit.remove(idx); trackChanged(r); draw(); });
            line.addView(del);
            cb.setOnCheckedChangeListener((b2, c) -> {
                String t = trackEdit.get(idx); if (t.startsWith("~")) t = t.substring(1);
                trackEdit.set(idx, c ? t : "~" + t); trackChanged(r); l.setTextColor(changes.containsKey(r.key) ? CHANGED : sum.getCurrentTextColor());
            });
            e.addTextChangedListener(new TextWatcher() {
                public void beforeTextChanged(CharSequence s2, int a, int b, int c) { }
                public void onTextChanged(CharSequence s2, int a, int b, int c) { }
                public void afterTextChanged(Editable s2) {
                    String t = s2.toString().trim();
                    trackEdit.set(idx, (trackEdit.get(idx).startsWith("~") ? "~" : "") + t);
                    trackChanged(r);
                }
            });
            box.addView(line);
        }
        LinearLayout add = Ui.hbox(this);
        add.setGravity(Gravity.CENTER_VERTICAL);
        EditText ne = new EditText(this);
        ne.setSingleLine(true);
        ne.setHint("name, or name#regex (commas are fine)");
        add.addView(ne, Ui.weight(1));
        Button ab = new Button(this);
        ab.setText("Add");
        ab.setOnClickListener(v -> {
            String t = ne.getText().toString().trim();
            if (t.length() == 0) return;
            trackEdit.add(t); trackChanged(r); draw();
        });
        add.addView(ab);
        box.addView(add);
        TextView tip = Ui.text(this, "A plain name is that exact name; name#... is part of a name or a regular expression. Unticked ones are kept but not watched for.", 12, false);
        tip.setTextColor(Ui.muted(this));
        box.addView(tip);
        return box;
    }

    /** An item profile action, sent straight away - with the list's unsaved edits first, so they're kept where they belong. */
    private void sendNow(String key, String value) {
        JSONObject ch = new JSONObject();
        try {
            if (changes.containsKey("TrackItems")) ch.put("TrackItems", changes.get("TrackItems"));
            ch.put(key, value);
        } catch (Exception ignored) { }
        io.execute(() -> {
            String msg;
            try { msg = Api.mtSettingsApply(prefs, account, ch).optString("message", "Sent."); }
            catch (Exception e) { msg = e.getMessage(); }
            String m = msg;
            main.post(() -> {
                changes.remove("TrackItems");
                trackEdit = null;
                updateApply();
                Toast.makeText(this, m, Toast.LENGTH_LONG).show();
                main.postDelayed(this::load, 3500);
            });
        });
    }

    private void trackChanged(Row r) {
        List<String> clean = new ArrayList<>();
        for (String t : trackEdit) if (t.replace("~", "").trim().length() > 0) clean.add(t.trim());
        String v = String.join(SEP, clean);
        if (v.equals(r.value)) changes.remove(r.key); else changes.put(r.key, v);
        updateApply();
    }

    private static String num(double d) {
        if (d == Math.rint(d)) return String.valueOf((long) d);
        return String.format(Locale.US, "%s", d);
    }

    private final java.util.Set<String> openGroups = new java.util.HashSet<>();   // groups folded out (all start folded)

    /** Plain names for the settings that would otherwise only show their key. */
    private static final java.util.Map<String, String> LABELS = new java.util.HashMap<>();
    static {
        LABELS.put("DexCatch", "Catch monsters I haven't caught (master switch)");
        LABELS.put("PerfLog", "Perf log: timing table + one line a minute, written to Logs");
        LABELS.put("DexGiveUpSecs", "Give up and fight normally when its health hasn't dropped for (s, 0 = never)");
        LABELS.put("DexLensFirst", "Try the lens first");
        LABELS.put("DexAsheron", "Use Asheron's Lens");
        LABELS.put("DexAsheronShiny", "Asheron's Lens only on shinies");
        LABELS.put("DexResonant", "Use the Resonant Lens");
        LABELS.put("DexResonantShiny", "Resonant Lens only on shinies");
        LABELS.put("DexCorruption", "Use Corruption I on big monsters");
        LABELS.put("DexCorruptionAbove", "Corruption I when its health is above");
        LABELS.put("DexResonator", "Use the Essence Resonator on hollows");
        LABELS.put("DexLens", "Lens to use");
        LABELS.put("DexSkip", "Never catch (names, comma separated)");
        LABELS.put("DexPetT11", "T11+: try even if a pet is out");
        LABELS.put("DexHoldPct", "T11+: stop everything under this health %");
        LABELS.put("DexLensTries", "Lens tries");
        LABELS.put("DexLensGapMs", "Lens: ms between tries");
        LABELS.put("DexLensWaitMs", "Lens: ms to wait for an answer");
                LABELS.put("TrackMaxRange", "Tracking: list every monster in view (unticked: attack range)");
        LABELS.put("TrackPopOut", "Tracking pop-out window open");
        LABELS.put("TuneOut", "Monsters left out of tuning");
        LABELS.put("TellLog", "Log tells (all of them for the phone's Tells only)");
        LABELS.put("TellKeep", "Keep the tells between sessions");
        LABELS.put("VtStandIn", "Give UtilityBelt VTank's library (uTank2) - next login");
        LABELS.put("VtStandInVirindi", "Give UtilityBelt the other Virindi libraries (VirindiHUDs, Views, Chat) - next login");
        LABELS.put("VtCommands", "Run /vt commands from metas and routes");
        LABELS.put("VtLiveUb", "Use the running UtilityBelt when it's loaded more than once");
        LABELS.put("IdAnnounce", "Say identified items in chat");
        LABELS.put("IdChatWindow", "Where those lines go (0 = main chat, 1-4 = floating chat window)");
    }

    private static final String[] TABS = { "Main", "Monsters", "Buffs", "Items", "Pets", "Nav", "Loot", "Tracking", "Session", "Bounties", "Settings", "Other" };

    /** Where a group's tab comes in MelkTank's window ("Nav - Meta" -> Nav). */
    private static int tabRank(String g) {
        String t = g.contains(" - ") ? g.substring(0, g.indexOf(" - ")) : g;
        for (int i = 0; i < TABS.length; i++) if (TABS[i].equals(t)) return i;
        return TABS.length;
    }

    /** Settings split by what they're about (one list of ~200 is hard to find things in). */
    private static String group(String key) {
        String k = key;
        if (k.startsWith("Dex")) return "Settings - Catching (Monster-Dex)";
        if (k.equals("TrackItems")) return "Settings - Item tracking";
        if (k.startsWith("Vt")) return "Settings - VTank replacement";
        if (k.startsWith("Tell") || k.equals("ChatFilter") || k.equals("IdChatWindow") || k.equals("IdAnnounce")) return "Settings - Chat";
        if (k.startsWith("Track")) return "Settings - Monster tracking & pop-out";
        if (k.equals("TuneOut")) return "Settings - Combat & other";
        if (k.startsWith("Nav") || k.startsWith("Follow") || k.startsWith("Close") || k.equals("PortalGems")) return "Settings - Nav";
        if (k.startsWith("Loot") || k.startsWith("Id") || k.startsWith("Shiny") || k.startsWith("Chunk") || k.startsWith("Salvage")
                || k.contains("Aetheria") || k.equals("AutoSalvage") || k.equals("AutoStack") || k.startsWith("Cmp")) return "Settings - Loot & items";
        if (k.startsWith("Fellow") || k.startsWith("Fm")) return "Settings - Fellowship";
        if (k.startsWith("Hover")) return "Settings - Hover info";
        if (k.startsWith("Pet") || k.startsWith("Buffer") || k.startsWith("Melks")) return "Settings - Buffs & pets";
        if (k.startsWith("Heal") || k.startsWith("Mana") || k.startsWith("Stamina") || k.startsWith("DeathStop") || k.startsWith("Dispel")
                || k.contains("Health")) return "Settings - Healing & vitals";
        if (k.startsWith("Meta")) return "Settings - Metas";
        if (k.startsWith("Area")) return "Settings - Areas";
        return "Settings - Combat & other";
    }

    private void draw() {
        list.removeAllViews();
        if (data == null) return;
        String q = search.getText().toString().trim().toLowerCase(Locale.US);
        // group the rows (keeping the order: Tuning categories first, then the settings groups)
        LinkedHashMap<String, List<Row>> groups = new LinkedHashMap<>();
        List<String> settingGroups = new ArrayList<>();
        for (Row r : rows()) {
            current.put(r.key, r.value);
            if (q.length() > 0 && !r.key.toLowerCase(Locale.US).contains(q) && !r.label.toLowerCase(Locale.US).contains(q)
                    && !r.tip.toLowerCase(Locale.US).contains(q)) continue;
            String g = r.tuning ? r.category : r.section.length() > 0 ? r.section : "Other - " + group(r.key).replace("Settings - ", "");
            if (!groups.containsKey(g)) { groups.put(g, new ArrayList<>()); settingGroups.add(g); }
            groups.get(g).add(r);
        }
        // in the order of MelkTank's tabs (Main, Monsters ... Settings), then anything the window doesn't show
        java.util.Collections.sort(settingGroups, (a, b) -> {
            int ta = tabRank(a), tb = tabRank(b);
            if (ta != tb) return Integer.compare(ta, tb);
            boolean aa = a.startsWith("Settings - Advanced - ") && !a.equals("Settings - Advanced - VTank replacement");
            boolean bb = b.startsWith("Settings - Advanced - ") && !b.equals("Settings - Advanced - VTank replacement");
            if (aa != bb) return aa ? 1 : -1;   // Settings: the switches first, the timers and distances after
            return a.compareToIgnoreCase(b);
        });
        List<String> order = new ArrayList<>(settingGroups);
        if (order.isEmpty()) list.addView(Ui.text(this, "Nothing matches.", 14, false));
        boolean searching = q.length() > 0;
        for (String g : order) {
            List<Row> rs = groups.get(g);
            int changed = 0;
            for (Row r : rs) if (changes.containsKey(r.key)) changed++;
            boolean open = searching || openGroups.contains(g);
            TextView h = Ui.text(this, (open ? "\u25BE  " : "\u25B8  ") + g + "  (" + rs.size() + ")" + (changed > 0 ? "  - " + changed + " changed" : ""), 16, true);
            if (changed > 0) h.setTextColor(CHANGED);
            h.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 6));
            h.setOnClickListener(v -> {
                if (searching) return;   // everything matching is shown while searching
                if (!openGroups.remove(g)) openGroups.add(g);
                draw();
            });
            list.addView(h);
            if (open) for (Row r : rs) list.addView(rowView(r));
        }
        updateApply();
    }

    // ── Settings > Commands ──
    private List<JSONObject> cmdList = new ArrayList<>();
    private String cmdServer, cmdChar;
    private double cmdMtime;

    private void cmdsFrom(JSONObject o) {
        cmdList.clear();
        cmdServer = null;
        if (o == null) return;
        cmdServer = o.optString("server", ""); cmdChar = o.optString("character", ""); cmdMtime = o.optDouble("mtime", 0);
        JSONArray a = o.optJSONArray("commands");
        for (int i = 0; a != null && i < a.length(); i++) if (a.optJSONObject(i) != null) cmdList.add(a.optJSONObject(i));
    }

    private String charScope() { return "char:" + cmdServer + "/" + cmdChar; }
    private String serverScope() { return "server:" + cmdServer; }
    private boolean mine(JSONObject c) { String sc = c.optString("scope"); return sc.equals(charScope()) || sc.equals(serverScope()); }

    private static String whenText(JSONObject c) {
        String w = c.optString("when"); int a = c.optInt("a"), b = c.optInt("b");
        if (w.equals("delay")) return a + " s after login";
        if (w.equals("every")) return "every " + Math.max(1, a) + " min" + (b > 0 ? ", first at " + b + " min" : "");
        return "at login";
    }

    private View cmdsView() {
        LinearLayout box = Ui.vbox(this);
        box.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        TextView hint = Ui.text(this, "Run for " + cmdChar + " or every character on " + (cmdServer.isEmpty() ? "the server" : cmdServer)
                + ". Saved straight away (no Apply needed); MelkTank picks them up in a few seconds. Tap one to change it.", 12, false);
        hint.setTextColor(Ui.muted(this));
        box.addView(hint);
        int shown = 0;
        for (JSONObject c : cmdList) {
            if (!mine(c)) continue;
            shown++;
            LinearLayout row = Ui.hbox(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
            LinearLayout txt = Ui.vbox(this);
            txt.addView(Ui.text(this, c.optString("text"), 15, true));
            TextView sub = Ui.text(this, (c.optString("scope").startsWith("server:") ? "every character" : cmdChar) + " - " + whenText(c), 12, false);
            sub.setTextColor(Ui.muted(this));
            txt.addView(sub);
            txt.setOnClickListener(v -> cmdDialog(c));
            row.addView(txt, Ui.weight(1));
            Button del = new Button(this);
            del.setText("\u2715");
            del.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Remove this command?").setMessage(c.optString("text"))
                    .setPositiveButton("Remove", (d, w) -> { cmdList.remove(c); saveCmds(); }).setNegativeButton("Cancel", null).show());
            row.addView(del);
            box.addView(row);
        }
        if (shown == 0) box.addView(Ui.text(this, "None yet.", 14, false));
        Button add = new Button(this);
        add.setText("Add command");
        add.setOnClickListener(v -> cmdDialog(null));
        box.addView(add);
        return box;
    }

    /** Add (c == null) or change a command. */
    private void cmdDialog(JSONObject c) {
        int pad = Ui.dp(this, 16);
        LinearLayout f = Ui.vbox(this);
        f.setPadding(pad, pad / 2, pad, 0);
        Spinner scope = new Spinner(this);
        scope.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[] { "This character (" + cmdChar + ")", "Every character on this server" }));
        Spinner when = new Spinner(this);
        when.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[] { "At login", "Seconds after login", "Every N minutes" }));
        EditText a = new EditText(this); a.setInputType(InputType.TYPE_CLASS_NUMBER);
        EditText b = new EditText(this); b.setInputType(InputType.TYPE_CLASS_NUMBER); b.setHint("first run, minutes after login (0 = straight away)");
        EditText text = new EditText(this); text.setHint("/command to run"); text.setSingleLine(true);
        if (c != null) {
            scope.setSelection(c.optString("scope").startsWith("server:") ? 1 : 0);
            String w = c.optString("when");
            when.setSelection(w.equals("delay") ? 1 : w.equals("every") ? 2 : 0);
            a.setText(String.valueOf(c.optInt("a"))); b.setText(String.valueOf(c.optInt("b"))); text.setText(c.optString("text"));
        } else { a.setText("30"); b.setText("0"); }
        f.addView(Ui.text(this, "For", 13, false)); f.addView(scope);
        f.addView(Ui.text(this, "When", 13, false)); f.addView(when);
        f.addView(a); f.addView(b);
        f.addView(Ui.text(this, "Command", 13, false)); f.addView(text);
        Runnable vis = () -> {
            int w = when.getSelectedItemPosition();
            a.setVisibility(w == 0 ? View.GONE : View.VISIBLE);
            a.setHint(w == 1 ? "seconds after login" : "every this many minutes");
            b.setVisibility(w == 2 ? View.VISIBLE : View.GONE);
        };
        when.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) { vis.run(); }
            @Override public void onNothingSelected(android.widget.AdapterView<?> p) { }
        });
        vis.run();
        new AlertDialog.Builder(this).setTitle(c == null ? "Add command" : "Change command").setView(f)
                .setPositiveButton("Save", (d, w) -> {
                    String t = text.getText().toString().trim();
                    if (t.isEmpty()) { Toast.makeText(this, "No command entered.", Toast.LENGTH_SHORT).show(); return; }
                    int wi = when.getSelectedItemPosition();
                    int av = 0, bv = 0;
                    try { av = Integer.parseInt(a.getText().toString().trim()); } catch (Exception ignored) { }
                    try { bv = Integer.parseInt(b.getText().toString().trim()); } catch (Exception ignored) { }
                    try {
                        JSONObject n = c != null ? c : new JSONObject();
                        n.put("scope", scope.getSelectedItemPosition() == 1 ? serverScope() : charScope());
                        n.put("when", wi == 1 ? "delay" : wi == 2 ? "every" : "login");
                        n.put("a", wi == 0 ? 0 : Math.max(wi == 2 ? 1 : 0, av));
                        n.put("b", wi == 2 ? Math.max(0, bv) : 0);
                        n.put("text", t);
                        if (c == null) cmdList.add(n);
                    } catch (Exception ignored) { }
                    saveCmds();
                }).setNegativeButton("Cancel", null).show();
    }

    private void saveCmds() {
        JSONArray all = new JSONArray();
        for (JSONObject c : cmdList) all.put(c);
        status.setText("Saving the commands...");
        io.execute(() -> {
            String msg;
            try {
                JSONObject r = Api.saveLoginCmds(prefs, account, all, cmdMtime);
                cmdMtime = r.optDouble("mtime", cmdMtime);
                msg = r.optString("message", "Saved.");
            } catch (Exception e) { msg = e.getMessage(); }
            String m = msg;
            main.post(() -> { status.setText(m); Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); draw(); });
        });
    }

    private View rowView(Row r) {
        if (r.kind.equals("list")) return listView(r);
        if (r.kind.equals("flist")) return filterView(r);
        if (r.kind.equals("cmds")) return cmdsView();
        LinearLayout row = Ui.vbox(this);
        row.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        String pending = changes.get(r.key);
        if (r.kind.equals("bool")) {
            Switch sw = new Switch(this);
            sw.setText(r.label);
            sw.setTextSize(15);
            sw.setChecked("True".equals(pending != null ? pending : r.value));
            int normal = sw.getCurrentTextColor();
            if (pending != null) sw.setTextColor(CHANGED);
            sw.setOnCheckedChangeListener((b2, on) -> {
                String v = on ? "True" : "False";
                if (v.equals(r.value)) changes.remove(r.key); else changes.put(r.key, v);
                sw.setTextColor(changes.containsKey(r.key) ? CHANGED : normal);
                updateApply();
            });
            row.addView(sw);
        } else {
            TextView l = Ui.text(this, r.tuning ? r.label + "  (" + r.key + ")" : r.label, 14, false);
            if (pending != null) l.setTextColor(CHANGED);
            row.addView(l);
            LinearLayout line = Ui.hbox(this);
            line.setGravity(Gravity.CENTER_VERTICAL);
            EditText e = new EditText(this);
            e.setSingleLine(true);
            e.setText(pending != null ? pending : r.value);
            if (r.kind.equals("number")) e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
            int normal = l.getCurrentTextColor();
            e.addTextChangedListener(new TextWatcher() {
                public void beforeTextChanged(CharSequence s, int a, int c, int d) { }
                public void onTextChanged(CharSequence s, int a, int c, int d) { }
                public void afterTextChanged(Editable s) {
                    String v = s.toString().trim();
                    if (v.equals(r.value)) changes.remove(r.key); else changes.put(r.key, v);
                    l.setTextColor(changes.containsKey(r.key) ? CHANGED : normal);
                    updateApply();
                }
            });
            line.addView(e, Ui.weight(1));
            if (r.tuning) {
                TextView u = Ui.text(this, " " + r.unit + "   default " + num(r.def) + ", " + num(r.min) + "-" + num(r.max), 12, false);
                u.setTextColor(Ui.muted(this));
                line.addView(u);
            }
            row.addView(line);
            if (r.tip.length() > 0) {
                TextView tip = Ui.text(this, r.tip, 12, false);
                tip.setTextColor(Ui.muted(this));
                row.addView(tip);
            }
        }
        return row;
    }

    private void updateApply() {
        int n = changes.size();
        apply.setVisibility(n > 0 ? View.VISIBLE : View.GONE);
        apply.setText("Apply " + n + " change" + (n == 1 ? "" : "s"));
    }

    private void applyChanges() {
        if (changes.isEmpty()) return;
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : changes.entrySet())
            if (e.getKey().equals("TrackItems")) sb.append("Items to track: ").append(e.getValue().replace(SEP, ", ")).append("\n");
            else if (e.getKey().equals("ChatFilter")) sb.append("Hide chat lines containing: ").append(e.getValue().replace(SEP, ", ")).append("\n");
            else sb.append(e.getKey()).append(": ").append(current.get(e.getKey())).append(" -> ").append(e.getValue()).append("\n");
        new AlertDialog.Builder(this)
                .setTitle("Apply to " + title + "?")
                .setMessage(sb.toString().trim())
                .setPositiveButton("Apply", (d, w) -> {
                    JSONObject ch = new JSONObject();
                    try { for (Map.Entry<String, String> e : changes.entrySet()) ch.put(e.getKey(), e.getValue()); } catch (Exception ignored) { }
                    apply.setEnabled(false);
                    io.execute(() -> {
                        String msg;
                        try { msg = Api.mtSettingsApply(prefs, account, ch).optString("message", "Sent."); }
                        catch (Exception e) { msg = e.getMessage(); }
                        String m = msg;
                        main.post(() -> {
                            apply.setEnabled(true);
                            Toast.makeText(this, m, Toast.LENGTH_LONG).show();
                            main.postDelayed(this::load, 3500);
                        });
                    });
                })
                .setNegativeButton("Cancel", null).show();
    }
}
