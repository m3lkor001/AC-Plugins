#!/bin/bash
# Builds the MelkTank Remote phone app from this folder and signs it with the release key.
#
#   ./build-apk.sh            -> MelkTankRemote-<version>.apk here
#   ./build-apk.sh out.apk    -> that file
#
# Needs the Android SDK (build-tools: aapt2, d8, zipalign, apksigner; platform android-34 or newer) and a JDK.
# The SDK is looked for in $ANDROID_HOME, $ANDROID_SDK_ROOT, ~/Android/Sdk, then ~/Games/Packages/android-sdk.
# The key: ~/Games/Packages/melktank-release.keystore with its melktank-release.properties (kept off GitHub).
set -e
cd "$(dirname "$0")"
# (the SDK: $ANDROID_HOME / $ANDROID_SDK_ROOT, ~/Android/Sdk, or the few build tools kept in ~/Games/Packages/android-sdk)
SDK=""
for c in "$ANDROID_HOME" "$ANDROID_SDK_ROOT" "$HOME/Android/Sdk" "$HOME/Games/Packages/android-sdk"; do
  if [ -n "$c" ] && [ -d "$c/build-tools" ] && [ -d "$c/platforms" ]; then SDK="$c"; break; fi
done
[ -n "$SDK" ] || { echo "No Android SDK found (set ANDROID_HOME, or keep ~/Games/Packages/android-sdk)"; exit 1; }
BT="$(ls -d "$SDK"/build-tools/*/ | sort -V | tail -1)"
BT="${BT%/}"
chmod +x "$BT/aapt2" "$BT/zipalign" "$BT/d8" "$BT/apksigner" 2>/dev/null || true
command -v javac >/dev/null || { echo "No javac - install a JDK (17 or newer), e.g. sudo pacman -S jdk-openjdk"; exit 1; }
PLAT="$(ls -d "$SDK"/platforms/android-*/ | sort -V | tail -1)"; PLAT="${PLAT%/}"
JAR="$PLAT/android.jar"
[ -f "$JAR" ] || { echo "No android.jar in $PLAT - install a platform (android-34 or newer)"; exit 1; }
KEYDIR="$HOME/Games/Packages"
PROPS="$KEYDIR/melktank-release.properties"
[ -f "$PROPS" ] || { echo "No $PROPS"; exit 1; }
prop() { grep -E "^$1=" "$PROPS" | head -1 | cut -d= -f2-; }
KS="$KEYDIR/$(prop keystore)"; ALIAS="$(prop key_alias)"; SP="$(prop store_password)"; KP="$(prop key_password)"
MIN="$(prop min_sdk)"; MIN="${MIN:-29}"
VER="$(grep -o 'android:versionName="[^"]*"' AndroidManifest.xml | cut -d'"' -f2)"
OUT="${1:-MelkTankRemote-$VER.apk}"
echo "Building $VER with $(basename "$BT") build-tools and $(basename "$PLAT")"
rm -rf build && mkdir -p build/classes build/dex
"$BT/aapt2" compile --dir res -o build/res.zip
"$BT/aapt2" link -o build/unsigned.apk -I "$JAR" --manifest AndroidManifest.xml --java build/gen build/res.zip --auto-add-overlay
javac -source 11 -target 11 -Xlint:-options -encoding UTF-8 -cp "$JAR" -d build/classes $(find src build/gen -name '*.java') 2>&1 | grep -v "^Note:" || true
"$BT/d8" --min-api "$MIN" --lib "$JAR" --output build/dex $(find build/classes -name '*.class')
cp build/unsigned.apk build/with-dex.apk
(cd build/dex && zip -q ../with-dex.apk classes.dex)
"$BT/zipalign" -f -p 4 build/with-dex.apk build/aligned.apk
"$BT/apksigner" sign --ks "$KS" --ks-key-alias "$ALIAS" --ks-pass "pass:$SP" --key-pass "pass:$KP" --out "$OUT" build/aligned.apk
"$BT/apksigner" verify "$OUT"
rm -f "$OUT.idsig"
echo "Built $OUT ($(stat -c%s "$OUT") bytes). Copy it over ~/MelkTankRemote/MelkTankRemote.apk (old one renamed first) for the phone to update."
