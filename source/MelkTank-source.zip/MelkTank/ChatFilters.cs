using System;
using System.Collections.Generic;
using System.Numerics;
using System.Text.RegularExpressions;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;

namespace MelkTank;

public static class ChatFilters
{
	private class Rule
	{
		public string Key;

		public string Group;

		public string Label;

		public string Tip;

		public bool Status;

		public bool AllowChat;

		public Func<string, bool> Test;
	}

	public static int Hidden;

	private static readonly List<Rule> Rules;

	private static HashSet<string> _on;

	private static string _onFrom;

	private static readonly Regex YouSay;

	private static readonly Regex PlayerSaysLocal;

	private static readonly Regex NpcSays;

	private static readonly Regex PlayerSaysChannel;

	private static readonly Regex YouTell;

	private static readonly Regex PlayerTellsYou;

	private static readonly Regex NpcTellsYou;

	private const string Words = "(Zojak|Malar|Puish|Cruath|Volae|Quavosh|Shurov|Boquar|Helkas|Equin|Roiga|Jevak|Tugak|Slavu|Drostu|Traku|Yanoi|Drosta|Feazh)";

	private static readonly Regex YouSayWords;

	private static readonly Regex OthersSayWords;

	private static readonly Regex DamageOnTarget;

	private static readonly HashSet<string> DamageVerbs;

	private static readonly Regex DamageMeleeOnYou;

	private static readonly Regex DamageSpellOnYou;

	private static readonly Regex PeriodicDamage;

	private static readonly Regex OthersCastOnYou;

	private static readonly Regex HealSelf;

	private static readonly Regex GiveAndTake;

	private static readonly Regex HealedByOther;

	private static readonly Regex Consumable;

	private static readonly Regex PeriodicHeal0;

	private static readonly Regex PeriodicHealing;

	private static readonly Regex Salvaged;

	private static readonly Regex BankedLum;

	private static readonly Regex[] KilledByMe;

	private static void Add(string group, string key, string label, string tip, Func<string, bool> test, bool allowChat = false)
	{
		Rules.Add(new Rule
		{
			Group = group,
			Key = key,
			Label = label,
			Tip = tip,
			Test = test,
			AllowChat = allowChat
		});
	}

	private static void AddStatus(string key, string label, string tip, Func<string, bool> test)
	{
		Rules.Add(new Rule
		{
			Group = "Top of the screen",
			Key = key,
			Label = label,
			Tip = tip,
			Test = test,
			Status = true
		});
	}

	static ChatFilters()
	{
		Rules = new List<Rule>();
		_on = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		YouSay = new Regex("^You say, \"(?<msg>.*)\"$");
		PlayerSaysLocal = new Regex("^<Tell:IIDString:[0-9]+:(?<name>[\\w\\s'-]+)>[\\w\\s'-]+<\\\\Tell> says, \"(?<msg>.*)\"$");
		NpcSays = new Regex("^(?<name>[\\w\\s'-]+) says, \"(?<msg>.*)\"$");
		PlayerSaysChannel = new Regex("^\\[(?<channel>.+)]+ <Tell:IIDString:[0-9]+:(?<name>[\\w\\s'-]+)>[\\w\\s'-]+<\\\\Tell> says, \"(?<msg>.*)\"$");
		YouTell = new Regex("^You tell .+, \"(?<msg>.*)\"$");
		PlayerTellsYou = new Regex("^<Tell:IIDString:[0-9]+:(?<name>[\\w\\s'-]+)>[\\w\\s'-]+<\\\\Tell> tells you, \"(?<msg>.*)\"$");
		NpcTellsYou = new Regex("^(?<name>[\\w\\s'-]+) tells you, \"(?<msg>.*)\"$");
		YouSayWords = new Regex("^You say, \"(Zojak|Malar|Puish|Cruath|Volae|Quavosh|Shurov|Boquar|Helkas|Equin|Roiga|Jevak|Tugak|Slavu|Drostu|Traku|Yanoi|Drosta|Feazh) .*\"$");
		OthersSayWords = new Regex("^(<Tell:IIDString:[0-9]+:[\\w\\s'-]+>[\\w\\s'-]+<\\\\Tell>|[\\w\\s'-]+) says, \"(Zojak|Malar|Puish|Cruath|Volae|Quavosh|Shurov|Boquar|Helkas|Equin|Roiga|Jevak|Tugak|Slavu|Drostu|Traku|Yanoi|Drosta|Feazh) .*\"$");
		DamageOnTarget = new Regex("^((Sneak Attack!|Recklessness!|Critical (H|h)it!|Overpower!|\\s+)+)?You (?<verb>\\S+) (?<target>[\\S\\s]+?) for (?<dmg>[\\d,]+) points? (with|of) (?<what>.*)(\\.|\\!)$");
		DamageVerbs = new HashSet<string>(new string[37]
		{
			"hit", "mangle", "slash", "cut", "scratch", "gore", "impale", "stab", "nick", "crush",
			"smash", "bash", "graze", "incinerate", "burn", "scorch", "singe", "freeze", "frost", "chill",
			"numb", "dissolve", "corrode", "sear", "blister", "blast", "jolt", "shock", "spark", "eradicate",
			"wither", "twist", "scar", "deplete", "siphon", "exhaust", "drain"
		});
		DamageMeleeOnYou = new Regex("^(?!You ).* your (?<loc>.*) for (?<dmg>[\\d,]+) points? of ?(?<type>.*) damage\\!.*$");
		DamageSpellOnYou = new Regex("^(?!You ).* you for (?<dmg>[\\d,]+) points? with (?<spell>.*)\\.$");
		PeriodicDamage = new Regex("^You receive [\\d,]+ points of periodic.*damage.*$");
		OthersCastOnYou = new Regex("^(?!You ).*casts? .* (on )?you.*$");
		HealSelf = new Regex("^You cast .* and restore [\\d,]+ points of your .*\\.$");
		GiveAndTake = new Regex("^You cast .* on yourself and lose [\\d,]+ points of .* and also gain [\\d,]+ points of .*$");
		HealedByOther = new Regex("^.* casts .* and restores [\\d,]+ points of your .*\\.$");
		Consumable = new Regex("^The .* restores [\\d,]+ points of your .*\\.$");
		PeriodicHeal0 = new Regex("You receive 0 points of periodic healing\\.$");
		PeriodicHealing = new Regex("You receive [\\d,]+ points of periodic healing\\.$");
		Salvaged = new Regex("^You obtain .* using your knowledge of .*$");
		BankedLum = new Regex("^You've banked [\\d,]+ Luminance\\.$");
		KilledByMe = new Regex[36]
		{
			new Regex("^You flatten .+'s body with the force of your assault!$"),
			new Regex("^You bring .+ to a fiery end!$"),
			new Regex("^You beat .+ to a lifeless pulp!$"),
			new Regex("^You smite .+ mightily!$"),
			new Regex("^You obliterate .+!$"),
			new Regex("^You run .+ through!$"),
			new Regex("^You reduce .+ to a sizzling, oozing mass!$"),
			new Regex("^You knock .+ into next Morningthaw!$"),
			new Regex("^You split .+ apart!$"),
			new Regex("^You cleave .+ in twain!$"),
			new Regex("^You slay .+ viciously enough to impart death several times over!$"),
			new Regex("^You reduce .+ to a drained, twisted corpse!$"),
			new Regex("^Your killing blow nearly turns .+ inside-out!$"),
			new Regex("^Your attack stops .+ cold!$"),
			new Regex("^Your lightning coruscates over .+'s mortal remains!$"),
			new Regex("^Your assault sends .+ to an icy death!$"),
			new Regex("^You killed .+!$"),
			new Regex("^The thunder of crushing .+ is followed by the deafening silence of death!$"),
			new Regex("^The deadly force of your attack is so strong that .+'s ancestors feel it!$"),
			new Regex("^.+'s seared corpse smolders before you!$"),
			new Regex("^.+ is reduced to cinders!$"),
			new Regex("^.+ is shattered by your assault!$"),
			new Regex("^.+ catches your attack, with dire consequences!$"),
			new Regex("^.+ is utterly destroyed by your attack!$"),
			new Regex("^.+ suffers a frozen fate!$"),
			new Regex("^.+'s perforated corpse falls before you!$"),
			new Regex("^.+ is fatally punctured!$"),
			new Regex("^.+'s death is preceded by a sharp, stabbing pain!$"),
			new Regex("^.+ is torn to ribbons by your assault!$"),
			new Regex("^.+ is liquified by your attack!$"),
			new Regex("^.+'s last strength dissolves before you!$"),
			new Regex("^Electricity tears .+ apart!$"),
			new Regex("^Blistered by lightning, .+ falls!$"),
			new Regex("^.+'s last strength withers before you!$"),
			new Regex("^.+ is dessicated by your attack!$"),
			new Regex("^.+ is incinerated by your assault!$")
		};
		Add("Combat", "evadeout", "Your attacks evaded", "\"X evaded your attack.\"", (string t) => t.Contains(" evaded your attack."));
		Add("Combat", "evadein", "You evade", "\"You evaded X!\"", (string t) => t.StartsWith("You evaded "));
		Add("Combat", "resistout", "Your spells resisted", "\"X resists your spell\"", (string t) => t.Contains(" resists your spell"));
		Add("Combat", "resistin", "You resist / bad targets", "\"You resist the spell cast by X\", no appropriate target, invalid target, too far away", (string t) => t.StartsWith("You resist the spell cast by ") || (t.StartsWith("You have no appropriate target") && t.Contains("spell")) || t.StartsWith("You are an invalid target for the spell") || t.Contains("tried to cast a spell on you, but was too far away!"));
		Add("Combat", "dmgout", "Your damage", "\"You blast X for 1,234 points with ...\" - your melee, missile and spell hits", (string t) =>
		{
			Match match = DamageOnTarget.Match(t);
			return match.Success && DamageVerbs.Contains(match.Groups["verb"].Value);
		});
		Add("Combat", "dmgin", "Melee / missile damage on you", "\"X hits your chest for 123 points of slashing damage!\"", (string t) => DamageMeleeOnYou.IsMatch(t));
		Add("Combat", "dmgspellin", "Spell damage on you", "\"X blasts you for 123 points with ...\"", (string t) => DamageSpellOnYou.IsMatch(t));
		Add("Combat", "periodicin", "Periodic damage on you", "\"You receive 123 points of periodic ... damage\"", (string t) => PeriodicDamage.IsMatch(t));
		Add("Combat", "deaths", "Kill messages", "\"You smite X mightily!\" and the rest (kills are still counted)", (string t) =>
		{
			Regex[] killedByMe = KilledByMe;
			foreach (Regex regex in killedByMe)
			{
				if (regex.IsMatch(t))
				{
					return true;
				}
			}
			return false;
		});
		Add("Combat", "dirty", "Dirty Fighting", "\"Dirty Fighting! You deliver a ... to X!\"", (string t) => t.StartsWith("Dirty Fighting! ") && t.Contains(" delivers a "));
		Add("Combat", "aetheria", "Aetheria surges", "\"Aetheria surges on ...\"", (string t) => t.StartsWith("Aetheria surges on"));
		Add("Combat", "cloak", "Cloak procs", "\"The cloak of ...\"", (string t) => t.StartsWith("The cloak of"));
		Add("Combat", "missileenv", "Missiles hitting the ground", "\"Your missile attack hit the environment.\"", (string t) => t.StartsWith("Your missile attack hit the environment"));
		Add("Combat", "npk", "Non-PK fails", "\"You fail to affect X because you are not a player killer!\" (and the other way round)", (string t) => (t.StartsWith("You fail to affect ") && t.Contains(" you are not a player killer!")) || (t.Contains("fails to affect you") && t.Contains(" is not a player killer!")));
		Add("Combat", "petlines", "Pet status and damage", "Every line starting with [Pet] - your pet's hits, what it takes, its status (pet summoning still reads them)", (string t) => t.TrimStart().StartsWith("[Pet]", StringComparison.OrdinalIgnoreCase));
		Add("Combat", "failedassess", "Failed assesses on you", "\"X tried and failed to assess you!\"", (string t) => t.Trim().EndsWith("tried and failed to assess you!"));
		Add("Spells", "yousay", "Your spell words", "You say, \"Zojak ...\"", (string t) => YouSayWords.IsMatch(t), allowChat: true);
		Add("Spells", "otherssay", "Others' spell words", "Players, NPCs and monsters saying spell words", (string t) => OthersSayWords.IsMatch(t), allowChat: true);
		Add("Spells", "youcast", "You cast ...", "\"You cast X on Y\" - your buffs, debuffs and other casts (not the healing ones)", (string t) => t.StartsWith("You cast") && !HealSelf.IsMatch(t) && !GiveAndTake.IsMatch(t));
		Add("Spells", "givetake", "Life-for-mana casts", "\"You cast X on yourself and lose ... and also gain ...\"", (string t) => GiveAndTake.IsMatch(t));
		Add("Spells", "otherscast", "Others' spells on you", "\"X casts Y on you\"", (string t) => OthersCastOnYou.IsMatch(t) && !HealedByOther.IsMatch(t));
		Add("Spells", "fizzle", "Fizzles", "\"Your spell fizzled.\"", (string t) => t.StartsWith("Your spell fizzled."));
		Add("Spells", "youfail", "You fail to affect", "\"You failed to affect X\"", (string t) => t.StartsWith("You failed to affect") || (t.StartsWith("You fail to affect ") && !t.Contains("player killer")));
		Add("Spells", "failsyou", "... fails to affect you", "\"X fails to affect you\"", (string t) => t.Contains(" fails to affect you") && !t.Contains("player killer"));
		Add("Spells", "comps", "Components used", "\"The spell consumed the following components: ...\"", (string t) => t.StartsWith("The spell consumed the following components"));
		Add("Spells", "expired", "Spells expiring", "\"X has expired.\" (not Brilliance / Prodigal / Spectral)", (string t) => !t.Contains("Brilliance") && !t.Contains("Prodigal") && !t.Contains("Spectral") && (t.Contains("has expired.") || t.Contains("have expired.")));
		Add("Healing, items & crafting", "kitok", "Healing kit success", "\"You heal yourself for 123 Health points ...\"", (string t) => t.StartsWith("You ") && t.Contains(" heal yourself for "));
		Add("Healing, items & crafting", "kitfail", "Healing kit fail", "\"You fail to heal yourself. ...\"", (string t) => t.StartsWith("You fail to heal yourself. "));
		Add("Healing, items & crafting", "healself", "Your healing spells", "\"You cast X and restore 123 points of your Health.\"", (string t) => HealSelf.IsMatch(t));
		Add("Healing, items & crafting", "healedby", "Healed by others", "\"X casts Y and restores 123 points of your Health.\"", (string t) => HealedByOther.IsMatch(t));
		Add("Healing, items & crafting", "periodicheal", "Periodic healing", "\"You receive 123 points of periodic healing.\"", (string t) => PeriodicHealing.IsMatch(t));
		Add("Healing, items & crafting", "periodicheal0", "Periodic healing of 0", "Only \"You receive 0 points of periodic healing.\" (at full health) - the real heals still show", (string t) => PeriodicHeal0.IsMatch(t));
		Add("Healing, items & crafting", "consumable", "Food / potions", "\"The X restores 123 points of your Stamina.\"", (string t) => Consumable.IsMatch(t));
		Add("Healing, items & crafting", "manastone", "Mana stones", "\"The Mana Stone gives ...\", \"You need ... more mana ...\", \"The ... is destroyed.\"", (string t) => t.StartsWith("The Mana Stone gives ") || (t.StartsWith("You need ") && t.Trim().EndsWith(" more mana to fully charge your items.")) || t.StartsWith("The Mana Stone drains ") || (t.StartsWith("The ") && t.Trim().EndsWith(" is destroyed.")));
		Add("Healing, items & crafting", "salvage", "Salvage results", "\"You obtain 50 Granite (ws 9.00) using your knowledge of Salvaging.\"", (string t) => Salvaged.IsMatch(t));
		Add("Healing, items & crafting", "salvagefail", "Salvage fails", "\"Salvaging Failed!\", \"The following were not suitable for salvaging: ...\"", (string t) => t.StartsWith("Salvaging Failed!") || t.Contains("The following were not suitable for salvaging: "));
		Add("Healing, items & crafting", "craftman", "Aura of the Craftman", "\"Your Aura of the Craftman augmentation increased your skill by 5!\"", (string t) => t.StartsWith("Your Aura of the Craftman augmentation"));
		Add("Healing, items & crafting", "bankedlum", "Banked luminance", "\"You've banked 196 Luminance.\" (the lum tracker still counts it)", (string t) => BankedLum.IsMatch(t));
		Add("NPCs & messages", "npcsay", "NPC chatter", "NPCs talking out loud (\"X says, ...\" from an NPC)", (string t) => SaidBy(t, NpcSays, ObjectClass.Npc), allowChat: true);
		Add("NPCs & messages", "npctell", "NPC tells", "NPCs telling you things (quest givers ...)", (string t) => SaidBy(t, NpcTellsYou, ObjectClass.Npc), allowChat: true);
		Add("NPCs & messages", "vendortell", "Vendor tells", "Vendors telling you things", (string t) => SaidBy(t, NpcTellsYou, ObjectClass.Vendor), allowChat: true);
		Add("NPCs & messages", "monstertell", "Monster tells", "Monsters telling you things", (string t) => SaidBy(t, NpcTellsYou, ObjectClass.Monster), allowChat: true);
		Add("NPCs & messages", "killtask", "Kill task complete", "\"You have killed 50 X! Your task is complete!\"", (string t) => t.StartsWith("You have killed ") && t.Trim().EndsWith("Your task is complete!"));
		Add("NPCs & messages", "tradebot", "Trade / buff bot spam", "Lines ending in -t- or -b-", (string t) => (PlayerSaysLocal.IsMatch(t) && (t.Trim().EndsWith("-t-\"") || t.Trim().EndsWith("-b-\""))) || (!IsChat(t) && (t.Trim().EndsWith("-t-") || t.Trim().EndsWith("-b-"))), allowChat: true);
		Add("NPCs & messages", "arbitrator", "Master Arbitrator spam", "Its repeating arena lines", (string t) => Source(t) == "Master Arbitrator" && ((NpcTellsYou.IsMatch(t) && (t.Contains("\"You shall be known") || t.Contains("\"Take this knowledge") || t.Contains("\"Use the the key"))) || (PlayerSaysChannel.IsMatch(t) && (t.Contains("\"Your fellowship") || t.Contains("\"Use one of the") || t.Contains("\"Don't forget")))), allowChat: true);
		Add("NPCs & messages", "arbitratorall", "All Master Arbitrator chat", "Everything it says (and the fellowship-locked line)", (string t) => Source(t) == "Master Arbitrator" || (t.StartsWith("Your fellowship is now locked.") && t.Contains("you have 15 minutes to be recruited")), allowChat: true);
		AddStatus("stbusy", "\"You're too busy!\"", "The message at the top of the screen", (string t) => t == "You're too busy!");
		AddStatus("stcasting", "\"Casting ...\"", "The spell name at the top of the screen while casting", (string t) => t.StartsWith("Casting "));
		AddStatus("stall", "All of them", "Every message at the top of the screen", (string t) => true);
	}

	private static bool IsChat(string t)
	{
		return YouSay.IsMatch(t) || PlayerSaysLocal.IsMatch(t) || PlayerSaysChannel.IsMatch(t) || YouTell.IsMatch(t) || PlayerTellsYou.IsMatch(t) || NpcSays.IsMatch(t) || NpcTellsYou.IsMatch(t);
	}

	private static string Source(string t)
	{
		Match match = PlayerSaysChannel.Match(t);
		if (match.Success)
		{
			return match.Groups["name"].Value;
		}
		match = NpcTellsYou.Match(t);
		if (match.Success)
		{
			return match.Groups["name"].Value;
		}
		match = NpcSays.Match(t);
		if (match.Success)
		{
			return match.Groups["name"].Value;
		}
		return "";
	}

	private static bool SaidBy(string t, Regex shape, ObjectClass oc)
	{
		Match match = shape.Match(t);
		if (!match.Success)
		{
			return false;
		}
		try
		{
			WorldObjectCollection byName = CoreManager.Current.WorldFilter.GetByName(match.Groups["name"].Value);
			return byName.Count >= 1 && byName.First.ObjectClass == oc;
		}
		catch
		{
			return false;
		}
	}

	private static void Sync(Settings s)
	{
		string text = ((s != null) ? (s.ChatFilterOn ?? "") : "");
		if (!(text == _onFrom))
		{
			_onFrom = text;
			_on = new HashSet<string>(text.Split(new char[1] { ',' }, StringSplitOptions.RemoveEmptyEntries), StringComparer.OrdinalIgnoreCase);
		}
	}

	public static bool Matches(Settings s, string text)
	{
		if (string.IsNullOrEmpty(text))
		{
			return false;
		}
		Sync(s);
		if (_on.Count == 0)
		{
			return false;
		}
		bool flag = IsChat(text);
		foreach (Rule rule in Rules)
		{
			if (rule.Status || !_on.Contains(rule.Key) || (flag && !rule.AllowChat))
			{
				continue;
			}
			try
			{
				if (rule.Test(text))
				{
					Hidden++;
					return true;
				}
			}
			catch
			{
			}
		}
		return false;
	}

	public static bool MatchesStatus(Settings s, string text)
	{
		if (text == null)
		{
			return false;
		}
		Sync(s);
		if (_on.Count == 0)
		{
			return false;
		}
		foreach (Rule rule in Rules)
		{
			if (!rule.Status || !_on.Contains(rule.Key))
			{
				continue;
			}
			try
			{
				if (rule.Test(text))
				{
					return true;
				}
			}
			catch
			{
			}
		}
		return false;
	}

	public static bool Draw(Settings s)
	{
		Sync(s);
		bool flag = false;
		Im.TextColored(new Vector4(0.6f, 0.6f, 0.6f, 1f), "Hide these from the chat window (Mag-Tools' and UtilityBelt's filters). MelkTank still reads them.");
		List<string> list = new List<string>();
		foreach (Rule rule in Rules)
		{
			if (!list.Contains(rule.Group))
			{
				list.Add(rule.Group);
			}
		}
		foreach (string item in list)
		{
			int num = 0;
			int num2 = 0;
			foreach (Rule rule2 in Rules)
			{
				if (rule2.Group == item)
				{
					num++;
					if (_on.Contains(rule2.Key))
					{
						num2++;
					}
				}
			}
			ImGui.SetNextItemAllowOverlap();
			bool flag2 = ImGui.TreeNodeEx(item + " (" + num2 + " of " + num + ")###cfg" + item, ImGuiTreeNodeFlags.AllowOverlap | ImGuiTreeNodeFlags.SpanAvailWidth);
			ImGui.SameLine(330f);
			if (ImGui.SmallButton("all##cfa" + item))
			{
				foreach (Rule rule3 in Rules)
				{
					if (rule3.Group == item)
					{
						_on.Add(rule3.Key);
					}
				}
				flag = true;
			}
			ImGui.SameLine();
			if (ImGui.SmallButton("none##cfn" + item))
			{
				foreach (Rule rule4 in Rules)
				{
					if (rule4.Group == item)
					{
						_on.Remove(rule4.Key);
					}
				}
				flag = true;
			}
			if (!flag2)
			{
				continue;
			}
			int num3 = 0;
			float cursorPosX = ImGui.GetCursorPosX();
			foreach (Rule rule5 in Rules)
			{
				if (rule5.Group != item)
				{
					continue;
				}
				if (num3 % 3 != 0)
				{
					ImGui.SameLine(cursorPosX + (float)(num3 % 3 * 250));
				}
				bool v = _on.Contains(rule5.Key);
				if (ImGui.Checkbox(rule5.Label + "##cf" + rule5.Key, ref v))
				{
					if (v)
					{
						_on.Add(rule5.Key);
					}
					else
					{
						_on.Remove(rule5.Key);
					}
					flag = true;
				}
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip(rule5.Tip);
				}
				num3++;
			}
			ImGui.TreePop();
		}
		if (flag)
		{
			List<string> list2 = new List<string>();
			foreach (Rule rule6 in Rules)
			{
				if (_on.Contains(rule6.Key))
				{
					list2.Add(rule6.Key);
				}
			}
			s.ChatFilterOn = string.Join(",", list2.ToArray());
			_onFrom = s.ChatFilterOn;
		}
		if (Hidden > 0)
		{
			Im.TextDisabled(Hidden + " line" + ((Hidden == 1) ? "" : "s") + " hidden by these since you logged in.");
		}
		ImGui.Spacing();
		Im.TextColored(new Vector4(0.4f, 0.8f, 1f, 1f), "Your own filters (any line containing the text)");
		return flag;
	}
}
