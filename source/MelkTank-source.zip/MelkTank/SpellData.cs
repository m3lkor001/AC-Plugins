using System.Collections.Generic;

namespace MelkTank;

public static class SpellData
{
	public static readonly Dictionary<string, SpellFamily> Families;

	private static void Add(string key, string baseName, SpellLevel[] levels)
	{
		Families[key] = new SpellFamily(key, baseName, levels);
	}

	static SpellData()
	{
		Families = new Dictionary<string, SpellFamily>();
		Add("Fester", "Fester Other", new SpellLevel[8]
		{
			new SpellLevel(171, "Fester Other I", 60),
			new SpellLevel(172, "Fester Other II", 90),
			new SpellLevel(173, "Fester Other III", 120),
			new SpellLevel(174, "Fester Other IV", 150),
			new SpellLevel(175, "Fester Other V", 180),
			new SpellLevel(176, "Fester Other VI", 210),
			null,
			new SpellLevel(4489, "Incantation of Fester Other", 300)
		});
		Add("Broadside", "Defenselessness Other", new SpellLevel[8]
		{
			new SpellLevel(262, "Defenselessness Other I", 60),
			new SpellLevel(263, "Defenselessness Other II", 90),
			new SpellLevel(264, "Defenselessness Other III", 120),
			new SpellLevel(265, "Defenselessness Other IV", 150),
			new SpellLevel(266, "Defenselessness Other V", 180),
			new SpellLevel(267, "Defenselessness Other VI", 210),
			null,
			new SpellLevel(4543, "Incantation of Defenselessness Other", 300)
		});
		Add("Gravity", "Vulnerability Other", new SpellLevel[8]
		{
			new SpellLevel(15, "Vulnerability Other I", 60),
			new SpellLevel(230, "Vulnerability Other II", 90),
			new SpellLevel(231, "Vulnerability Other III", 120),
			new SpellLevel(232, "Vulnerability Other IV", 150),
			new SpellLevel(233, "Vulnerability Other V", 180),
			new SpellLevel(234, "Vulnerability Other VI", 210),
			null,
			new SpellLevel(4633, "Incantation of Vulnerability Other", 300)
		});
		Add("Imperil", "Imperil Other", new SpellLevel[8]
		{
			new SpellLevel(25, "Imperil Other I", 60),
			new SpellLevel(1323, "Imperil Other II", 90),
			new SpellLevel(1324, "Imperil Other III", 120),
			new SpellLevel(1325, "Imperil Other IV", 150),
			new SpellLevel(1326, "Imperil Other V", 180),
			new SpellLevel(1327, "Imperil Other VI", 210),
			null,
			new SpellLevel(4312, "Incantation of Imperil Other", 300)
		});
		Add("Yield", "Magic Yield Other", new SpellLevel[8]
		{
			new SpellLevel(280, "Magic Yield Other I", 60),
			new SpellLevel(281, "Magic Yield Other II", 90),
			new SpellLevel(282, "Magic Yield Other III", 120),
			new SpellLevel(283, "Magic Yield Other IV", 150),
			new SpellLevel(284, "Magic Yield Other V", 180),
			new SpellLevel(285, "Magic Yield Other VI", 210),
			null,
			new SpellLevel(4597, "Incantation of Magic Yield Other", 300)
		});
		Add("VulnAcid", "Acid Vulnerability Other", new SpellLevel[8]
		{
			new SpellLevel(521, "Acid Vulnerability Other I", 60),
			new SpellLevel(522, "Acid Vulnerability Other II", 90),
			new SpellLevel(523, "Acid Vulnerability Other III", 120),
			new SpellLevel(524, "Acid Vulnerability Other IV", 150),
			new SpellLevel(525, "Acid Vulnerability Other V", 180),
			new SpellLevel(526, "Acid Vulnerability Other VI", 210),
			null,
			new SpellLevel(4473, "Incantation of Acid Vulnerability Other", 300)
		});
		Add("VulnBlade", "Blade Vulnerability Other", new SpellLevel[8]
		{
			new SpellLevel(1127, "Blade Vulnerability Other I", 60),
			new SpellLevel(1128, "Blade Vulnerability Other II", 90),
			new SpellLevel(1129, "Blade Vulnerability Other III", 120),
			new SpellLevel(1130, "Blade Vulnerability Other IV", 150),
			new SpellLevel(1131, "Blade Vulnerability Other V", 180),
			new SpellLevel(1132, "Blade Vulnerability Other VI", 210),
			null,
			new SpellLevel(4475, "Incantation of Blade Vulnerability Other", 300)
		});
		Add("VulnBludgeon", "Bludgeoning Vulnerability Other", new SpellLevel[8]
		{
			new SpellLevel(1048, "Bludgeoning Vulnerability Other I", 60),
			new SpellLevel(1049, "Bludgeoning Vulnerability Other II", 90),
			new SpellLevel(1050, "Bludgeoning Vulnerability Other III", 120),
			new SpellLevel(1051, "Bludgeoning Vulnerability Other IV", 150),
			new SpellLevel(1052, "Bludgeoning Vulnerability Other V", 180),
			new SpellLevel(1053, "Bludgeoning Vulnerability Other VI", 210),
			null,
			new SpellLevel(4477, "Incantation of Bludgeoning Vulnerability Other", 300)
		});
		Add("VulnCold", "Cold Vulnerability Other", new SpellLevel[8]
		{
			new SpellLevel(1060, "Cold Vulnerability Other I", 60),
			new SpellLevel(1061, "Cold Vulnerability Other II", 90),
			new SpellLevel(1062, "Cold Vulnerability Other III", 120),
			new SpellLevel(1063, "Cold Vulnerability Other IV", 150),
			new SpellLevel(1064, "Cold Vulnerability Other V", 180),
			new SpellLevel(1065, "Cold Vulnerability Other VI", 210),
			null,
			new SpellLevel(4479, "Incantation of Cold Vulnerability Other", 300)
		});
		Add("VulnFire", "Fire Vulnerability Other", new SpellLevel[8]
		{
			new SpellLevel(21, "Fire Vulnerability Other I", 60),
			new SpellLevel(1104, "Fire Vulnerability Other II", 90),
			new SpellLevel(1105, "Fire Vulnerability Other III", 120),
			new SpellLevel(1106, "Fire Vulnerability Other IV", 150),
			new SpellLevel(1107, "Fire Vulnerability Other V", 180),
			new SpellLevel(1108, "Fire Vulnerability Other VI", 210),
			null,
			new SpellLevel(4481, "Incantation of Fire Vulnerability Other", 300)
		});
		Add("VulnLightning", "Lightning Vulnerability Other", new SpellLevel[8]
		{
			new SpellLevel(1084, "Lightning Vulnerability Other I", 60),
			new SpellLevel(1085, "Lightning Vulnerability Other II", 90),
			new SpellLevel(1086, "Lightning Vulnerability Other III", 120),
			new SpellLevel(1087, "Lightning Vulnerability Other IV", 150),
			new SpellLevel(1088, "Lightning Vulnerability Other V", 180),
			new SpellLevel(1089, "Lightning Vulnerability Other VI", 210),
			null,
			new SpellLevel(4483, "Incantation of Lightning Vulnerability Other", 300)
		});
		Add("VulnPierce", "Piercing Vulnerability Other", new SpellLevel[8]
		{
			new SpellLevel(1151, "Piercing Vulnerability Other I", 60),
			new SpellLevel(1152, "Piercing Vulnerability Other II", 90),
			new SpellLevel(1153, "Piercing Vulnerability Other III", 120),
			new SpellLevel(1154, "Piercing Vulnerability Other IV", 150),
			new SpellLevel(1155, "Piercing Vulnerability Other V", 180),
			new SpellLevel(1156, "Piercing Vulnerability Other VI", 210),
			null,
			new SpellLevel(4485, "Incantation of Piercing Vulnerability Other", 300)
		});
		Add("WeakeningCurse", "Weakening Curse", new SpellLevel[8]
		{
			new SpellLevel(5379, "Weakening Curse I", 15),
			new SpellLevel(5380, "Weakening Curse II", 15),
			new SpellLevel(5381, "Weakening Curse III", 15),
			new SpellLevel(5382, "Weakening Curse IV", 15),
			new SpellLevel(5383, "Weakening Curse V", 15),
			new SpellLevel(5384, "Weakening Curse VI", 15),
			new SpellLevel(5385, "Weakening Curse VII", 15),
			new SpellLevel(5386, "Incantation of Weakening Curse", 15)
		});
		Add("FesteringCurse", "Festering Curse", new SpellLevel[8]
		{
			new SpellLevel(5371, "Festering Curse I", 30),
			new SpellLevel(5372, "Festering Curse II", 30),
			new SpellLevel(5373, "Festering Curse III", 30),
			new SpellLevel(5374, "Festering Curse IV", 30),
			new SpellLevel(5375, "Festering Curse V", 30),
			new SpellLevel(5376, "Festering Curse VI", 30),
			new SpellLevel(5377, "Festering Curse VII", 30),
			new SpellLevel(5378, "Incantation of Festering Curse", 30)
		});
		Add("Corruption", "Corruption", new SpellLevel[8]
		{
			new SpellLevel(5395, "Corruption I", 31),
			new SpellLevel(5396, "Corruption II", 31),
			new SpellLevel(5397, "Corruption III", 31),
			new SpellLevel(5398, "Corruption IV", 31),
			new SpellLevel(5399, "Corruption V", 31),
			new SpellLevel(5400, "Corruption VI", 31),
			new SpellLevel(5401, "Corruption VII", 31),
			new SpellLevel(5402, "Incantation of Corruption", 31)
		});
		Add("DestructiveCurse", "Destructive Curse", new SpellLevel[8]
		{
			new SpellLevel(5339, "Destructive Curse I", 31),
			new SpellLevel(5340, "Destructive Curse II", 31),
			new SpellLevel(5341, "Destructive Curse III", 31),
			new SpellLevel(5342, "Destructive Curse IV", 31),
			new SpellLevel(5343, "Destructive Curse V", 31),
			new SpellLevel(5344, "Destructive Curse VI", 31),
			new SpellLevel(5337, "Destructive Curse VII", 31),
			new SpellLevel(5338, "Incantation of Destructive Curse", 31)
		});
		Add("Corrosion", "Corrosion", new SpellLevel[8]
		{
			new SpellLevel(5387, "Corrosion I", 16),
			new SpellLevel(5388, "Corrosion II", 16),
			new SpellLevel(5389, "Corrosion III", 16),
			new SpellLevel(5390, "Corrosion IV", 16),
			new SpellLevel(5391, "Corrosion V", 16),
			new SpellLevel(5392, "Corrosion VI", 16),
			new SpellLevel(5393, "Corrosion VII", 16),
			new SpellLevel(5394, "Incantation of Corrosion", 16)
		});
		Add("BoltAcid", "Acid Stream", new SpellLevel[8]
		{
			new SpellLevel(58, "Acid Stream I", -1),
			new SpellLevel(59, "Acid Stream II", -1),
			new SpellLevel(60, "Acid Stream III", -1),
			new SpellLevel(61, "Acid Stream IV", -1),
			new SpellLevel(62, "Acid Stream V", -1),
			new SpellLevel(63, "Acid Stream VI", -1),
			null,
			new SpellLevel(4433, "Incantation of Acid Stream", -1)
		});
		Add("ArcAcid", "Acid Arc", new SpellLevel[8]
		{
			new SpellLevel(2711, "Acid Arc I", -1),
			new SpellLevel(2712, "Acid Arc II", -1),
			new SpellLevel(2713, "Acid Arc III", -1),
			new SpellLevel(2714, "Acid Arc IV", -1),
			new SpellLevel(2715, "Acid Arc V", -1),
			new SpellLevel(2716, "Acid Arc VI", -1),
			new SpellLevel(2717, "Acid Arc VII", -1),
			new SpellLevel(4421, "Incantation of Acid Arc", -1)
		});
		Add("StreakAcid", "Acid Streak", new SpellLevel[8]
		{
			new SpellLevel(1790, "Acid Streak I", -1),
			new SpellLevel(1791, "Acid Streak II", -1),
			new SpellLevel(1792, "Acid Streak III", -1),
			new SpellLevel(1793, "Acid Streak IV", -1),
			new SpellLevel(1794, "Acid Streak V", -1),
			new SpellLevel(1795, "Acid Streak VI", -1),
			null,
			new SpellLevel(4432, "Incantation of Acid Streak", -1)
		});
		Add("RingAcid", "Searing Disc", new SpellLevel[8]
		{
			null,
			null,
			null,
			null,
			null,
			new SpellLevel(1783, "Searing Disc", -1),
			new SpellLevel(6189, "Searing Disc II", -1),
			null
		});
		Add("BoltBlade", "Whirling Blade", new SpellLevel[8]
		{
			new SpellLevel(92, "Whirling Blade I", -1),
			new SpellLevel(93, "Whirling Blade II", -1),
			new SpellLevel(94, "Whirling Blade III", -1),
			new SpellLevel(95, "Whirling Blade IV", -1),
			new SpellLevel(96, "Whirling Blade V", -1),
			new SpellLevel(97, "Whirling Blade VI", -1),
			null,
			new SpellLevel(4457, "Incantation of Whirling Blade", -1)
		});
		Add("ArcBlade", "Blade Arc", new SpellLevel[8]
		{
			new SpellLevel(2753, "Blade Arc I", -1),
			new SpellLevel(2754, "Blade Arc II", -1),
			new SpellLevel(2755, "Blade Arc III", -1),
			new SpellLevel(2756, "Blade Arc IV", -1),
			new SpellLevel(2757, "Blade Arc V", -1),
			new SpellLevel(2758, "Blade Arc VI", -1),
			new SpellLevel(2759, "Blade Arc VII", -1),
			new SpellLevel(4422, "Incantation of Blade Arc", -1)
		});
		Add("StreakBlade", "Whirling Blade Streak", new SpellLevel[8]
		{
			new SpellLevel(1826, "Whirling Blade Streak I", -1),
			new SpellLevel(1827, "Whirling Blade Streak II", -1),
			new SpellLevel(1828, "Whirling Blade Streak III", -1),
			new SpellLevel(1829, "Whirling Blade Streak IV", -1),
			new SpellLevel(1830, "Whirling Blade Streak V", -1),
			new SpellLevel(1831, "Whirling Blade Streak VI", -1),
			null,
			new SpellLevel(4458, "Incantation of Whirling Blade Streak", -1)
		});
		Add("RingBlade", "Horizon's Blades", new SpellLevel[8]
		{
			null,
			null,
			null,
			null,
			null,
			new SpellLevel(1784, "Horizon's Blades", -1),
			new SpellLevel(6190, "Horizon's Blades II", -1),
			null
		});
		Add("BoltBludgeon", "Shock Wave", new SpellLevel[8]
		{
			new SpellLevel(64, "Shock Wave I", -1),
			new SpellLevel(65, "Shock Wave II", -1),
			new SpellLevel(66, "Shock Wave III", -1),
			new SpellLevel(67, "Shock Wave IV", -1),
			new SpellLevel(68, "Shock Wave V", -1),
			new SpellLevel(69, "Shock Wave VI", -1),
			null,
			new SpellLevel(4455, "Incantation of Shock Wave", -1)
		});
		Add("ArcBludgeon", "Shock Arc", new SpellLevel[8]
		{
			new SpellLevel(2746, "Shock Arc I", -1),
			new SpellLevel(2747, "Shock Arc II", -1),
			new SpellLevel(2748, "Shock Arc III", -1),
			new SpellLevel(2749, "Shock Arc IV", -1),
			new SpellLevel(2750, "Shock Arc V", -1),
			new SpellLevel(2751, "Shock Arc VI", -1),
			new SpellLevel(2752, "Shock Arc VII", -1),
			new SpellLevel(4427, "Incantation of Shock Arc", -1)
		});
		Add("StreakBludgeon", "Shock Wave Streak", new SpellLevel[8]
		{
			new SpellLevel(1820, "Shock Wave Streak I", -1),
			new SpellLevel(1821, "Shock Wave Streak II", -1),
			new SpellLevel(1822, "Shock Wave Streak III", -1),
			new SpellLevel(1823, "Shock Wave Streak IV", -1),
			new SpellLevel(1824, "Shock Wave Streak V", -1),
			new SpellLevel(1825, "Shock Wave Streak VI", -1),
			null,
			new SpellLevel(4456, "Incantation of Shock Wave Streak", -1)
		});
		Add("RingBludgeon", "Tectonic Rifts", new SpellLevel[8]
		{
			null,
			null,
			null,
			null,
			null,
			new SpellLevel(1789, "Tectonic Rifts", -1),
			new SpellLevel(6196, "Tectonic Rifts II", -1),
			null
		});
		Add("BoltCold", "Frost Bolt", new SpellLevel[8]
		{
			new SpellLevel(28, "Frost Bolt I", -1),
			new SpellLevel(70, "Frost Bolt II", -1),
			new SpellLevel(71, "Frost Bolt III", -1),
			new SpellLevel(72, "Frost Bolt IV", -1),
			new SpellLevel(73, "Frost Bolt V", -1),
			new SpellLevel(74, "Frost Bolt VI", -1),
			null,
			new SpellLevel(4447, "Incantation of Frost Bolt", -1)
		});
		Add("ArcCold", "Frost Arc", new SpellLevel[8]
		{
			new SpellLevel(2725, "Frost Arc I", -1),
			new SpellLevel(2726, "Frost Arc II", -1),
			new SpellLevel(2727, "Frost Arc III", -1),
			new SpellLevel(2728, "Frost Arc IV", -1),
			new SpellLevel(2729, "Frost Arc V", -1),
			new SpellLevel(2730, "Frost Arc VI", -1),
			new SpellLevel(2731, "Frost Arc VII", -1),
			new SpellLevel(4425, "Incantation of Frost Arc", -1)
		});
		Add("StreakCold", "Frost Streak", new SpellLevel[8]
		{
			new SpellLevel(1808, "Frost Streak I", -1),
			new SpellLevel(1809, "Frost Streak II", -1),
			new SpellLevel(1810, "Frost Streak III", -1),
			new SpellLevel(1811, "Frost Streak IV", -1),
			new SpellLevel(1812, "Frost Streak V", -1),
			new SpellLevel(1813, "Frost Streak VI", -1),
			null,
			new SpellLevel(4448, "Incantation of Frost Streak", -1)
		});
		Add("RingCold", "Halo of Frost", new SpellLevel[8]
		{
			null,
			null,
			null,
			null,
			null,
			new SpellLevel(1787, "Halo of Frost", -1),
			new SpellLevel(6193, "Halo of Frost II", -1),
			null
		});
		Add("BoltFire", "Flame Bolt", new SpellLevel[8]
		{
			new SpellLevel(27, "Flame Bolt I", -1),
			new SpellLevel(81, "Flame Bolt II", -1),
			new SpellLevel(82, "Flame Bolt III", -1),
			new SpellLevel(83, "Flame Bolt IV", -1),
			new SpellLevel(84, "Flame Bolt V", -1),
			new SpellLevel(85, "Flame Bolt VI", -1),
			null,
			new SpellLevel(4439, "Incantation of Flame Bolt", -1)
		});
		Add("ArcFire", "Flame Arc", new SpellLevel[8]
		{
			new SpellLevel(2739, "Flame Arc I", -1),
			new SpellLevel(2740, "Flame Arc II", -1),
			new SpellLevel(2741, "Flame Arc III", -1),
			new SpellLevel(2742, "Flame Arc IV", -1),
			new SpellLevel(2743, "Flame Arc V", -1),
			new SpellLevel(2744, "Flame Arc VI", -1),
			new SpellLevel(2745, "Flame Arc VII", -1),
			new SpellLevel(4423, "Incantation of Flame Arc", -1)
		});
		Add("StreakFire", "Flame Streak", new SpellLevel[8]
		{
			new SpellLevel(1796, "Flame Streak I", -1),
			new SpellLevel(1797, "Flame Streak II", -1),
			new SpellLevel(1798, "Flame Streak III", -1),
			new SpellLevel(1799, "Flame Streak IV", -1),
			new SpellLevel(1800, "Flame Streak V", -1),
			new SpellLevel(1801, "Flame Streak VI", -1),
			null,
			new SpellLevel(4440, "Incantation of Flame Streak", -1)
		});
		Add("RingFire", "Cassius' Ring of Fire", new SpellLevel[8]
		{
			null,
			null,
			null,
			null,
			null,
			new SpellLevel(1785, "Cassius' Ring of Fire", -1),
			new SpellLevel(6191, "Cassius' Ring of Fire II", -1),
			null
		});
		Add("BoltLightning", "Lightning Bolt", new SpellLevel[8]
		{
			new SpellLevel(75, "Lightning Bolt I", -1),
			new SpellLevel(76, "Lightning Bolt II", -1),
			new SpellLevel(77, "Lightning Bolt III", -1),
			new SpellLevel(78, "Lightning Bolt IV", -1),
			new SpellLevel(79, "Lightning Bolt V", -1),
			new SpellLevel(80, "Lightning Bolt VI", -1),
			null,
			new SpellLevel(4451, "Incantation of Lightning Bolt", -1)
		});
		Add("ArcLightning", "Lightning Arc", new SpellLevel[8]
		{
			new SpellLevel(2732, "Lightning Arc I", -1),
			new SpellLevel(2733, "Lightning Arc II", -1),
			new SpellLevel(2734, "Lightning Arc III", -1),
			new SpellLevel(2735, "Lightning Arc IV", -1),
			new SpellLevel(2736, "Lightning Arc V", -1),
			new SpellLevel(2737, "Lightning Arc VI", -1),
			new SpellLevel(2738, "Lightning Arc VII", -1),
			new SpellLevel(4426, "Incantation of Lightning Arc", -1)
		});
		Add("StreakLightning", "Lightning Streak", new SpellLevel[8]
		{
			new SpellLevel(1814, "Lightning Streak I", -1),
			new SpellLevel(1815, "Lightning Streak II", -1),
			new SpellLevel(1816, "Lightning Streak III", -1),
			new SpellLevel(1817, "Lightning Streak IV", -1),
			new SpellLevel(1818, "Lightning Streak V", -1),
			new SpellLevel(1819, "Lightning Streak VI", -1),
			null,
			new SpellLevel(4452, "Incantation of Lightning Streak", -1)
		});
		Add("RingLightning", "Eye of the Storm", new SpellLevel[8]
		{
			null,
			null,
			null,
			null,
			null,
			new SpellLevel(1788, "Eye of the Storm", -1),
			new SpellLevel(6194, "Eye of the Storm II", -1),
			null
		});
		Add("BoltPierce", "Force Bolt", new SpellLevel[8]
		{
			new SpellLevel(86, "Force Bolt I", -1),
			new SpellLevel(87, "Force Bolt II", -1),
			new SpellLevel(88, "Force Bolt III", -1),
			new SpellLevel(89, "Force Bolt IV", -1),
			new SpellLevel(90, "Force Bolt V", -1),
			new SpellLevel(91, "Force Bolt VI", -1),
			null,
			new SpellLevel(4443, "Incantation of Force Bolt", -1)
		});
		Add("ArcPierce", "Force Arc", new SpellLevel[8]
		{
			new SpellLevel(2718, "Force Arc I", -1),
			new SpellLevel(2719, "Force Arc II", -1),
			new SpellLevel(2720, "Force Arc III", -1),
			new SpellLevel(2721, "Force Arc IV", -1),
			new SpellLevel(2722, "Force Arc V", -1),
			new SpellLevel(2723, "Force Arc VI", -1),
			new SpellLevel(2724, "Force Arc VII", -1),
			new SpellLevel(4424, "Incantation of Force Arc", -1)
		});
		Add("StreakPierce", "Force Streak", new SpellLevel[8]
		{
			new SpellLevel(1802, "Force Streak I", -1),
			new SpellLevel(1803, "Force Streak II", -1),
			new SpellLevel(1804, "Force Streak III", -1),
			new SpellLevel(1805, "Force Streak IV", -1),
			new SpellLevel(1806, "Force Streak V", -1),
			new SpellLevel(1807, "Force Streak VI", -1),
			null,
			new SpellLevel(4444, "Incantation of Force Streak", -1)
		});
		Add("RingPierce", "Nuhmudira's Spines", new SpellLevel[8]
		{
			null,
			null,
			null,
			null,
			null,
			new SpellLevel(1786, "Nuhmudira's Spines", -1),
			new SpellLevel(6192, "Nuhmudira's Spines II", -1),
			null
		});
		Add("BoltVoid", "Nether Bolt", new SpellLevel[8]
		{
			new SpellLevel(5349, "Nether Bolt I", -1),
			new SpellLevel(5350, "Nether Bolt II", -1),
			new SpellLevel(5351, "Nether Bolt III", -1),
			new SpellLevel(5352, "Nether Bolt IV", -1),
			new SpellLevel(5353, "Nether Bolt V", -1),
			new SpellLevel(5354, "Nether Bolt VI", -1),
			new SpellLevel(5355, "Nether Bolt VII", -1),
			new SpellLevel(5356, "Incantation of Nether Bolt", -1)
		});
		Add("ArcVoid", "Nether Arc", new SpellLevel[8]
		{
			new SpellLevel(5369, "Nether Arc I", -1),
			new SpellLevel(5362, "Nether Arc II", -1),
			new SpellLevel(5363, "Nether Arc III", -1),
			new SpellLevel(5364, "Nether Arc IV", -1),
			new SpellLevel(5365, "Nether Arc V", -1),
			new SpellLevel(5366, "Nether Arc VI", -1),
			new SpellLevel(5367, "Nether Arc VII", -1),
			new SpellLevel(5368, "Incantation of Nether Arc", -1)
		});
		Add("StreakVoid", "Nether Streak", new SpellLevel[8]
		{
			new SpellLevel(5357, "Nether Streak I", -1),
			new SpellLevel(5358, "Nether Streak II", -1),
			new SpellLevel(5359, "Nether Streak III", -1),
			new SpellLevel(5360, "Nether Streak IV", -1),
			new SpellLevel(5345, "Nether Streak V", -1),
			new SpellLevel(5346, "Nether Streak VI", -1),
			new SpellLevel(5347, "Nether Streak VII", -1),
			new SpellLevel(5348, "Incantation of Nether Streak", -1)
		});
		Add("RingVoid", "Clouded Soul", new SpellLevel[8]
		{
			null,
			null,
			null,
			null,
			null,
			new SpellLevel(5361, "Clouded Soul", -1),
			new SpellLevel(6195, "Clouded Soul II", -1),
			null
		});
	}
}
