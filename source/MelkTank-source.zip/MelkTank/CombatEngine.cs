using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
#if !RETAIL
using AcClient;
#endif
using Decal.Adapter.Wrappers;
using MelkTank.Buffs;
using MelkTank.Loot;
using MelkTank.Pets;

namespace MelkTank;

public class CombatEngine
{
	private class PendingCast
	{
		public int TargetId;

		public string TargetName;

		public Slot? Slot;

		public SpellLevel Spell;

		public DateTime At;

		public bool Said;

		public TimeSpan Timeout = TimeSpan.FromSeconds(5L);

		public double X;

		public double Y;

		public bool HasPos;

		public bool Streak;
	}

	private class Hp
	{
		public double Pct;

		public DateTime At;
	}

	private class WandLead
	{
		public int LeadId;

		public DateTime DeadAt = DateTime.MinValue;

		public DateTime AskedAt = DateTime.MinValue;

		public bool Done;
	}

	private class SpreadCheck
	{
		public List<int> Ids;

		public int N;

		public int SrcId;

		public DateTime At;

		public DateTime Due;

		public DateTime AskedAt = DateTime.MinValue;

		public string SrcName;

		public readonly Dictionary<int, double> Base = new Dictionary<int, double>();
	}

	private class AttackWatch
	{
		public int Id;

		public string Name;

		public double X;

		public double Y;

		public bool HasPos;

		public DateTime Deadline;
	}

	private struct Mob
	{
		public int Id;

		public double D;

		public WorldObject Get()
		{
			return Globals.Core.WorldFilter[Id];
		}
	}

	private readonly Settings _s;

	public readonly Dictionary<int, TrackedMonster> Tracked = new Dictionary<int, TrackedMonster>();

	private readonly HashSet<int> _alerted = new HashSet<int>();

	private DateTime _nextAlertScan = DateTime.MinValue;

	private DateTime _nextTick = DateTime.MinValue;

	private long _stampNo;

	private int _stampFrame = -1;

	private DateTime _stampAt;

	private DateTime _stampFor;

	private PendingCast _pending;

	private int _lastCastOn;

	private DateTime _lastCastAt = DateTime.MinValue;

	private DateTime _idleSince = DateTime.MinValue;

	private DateTime _peaceSentAt = DateTime.MinValue;

	private PendingCast _lastMissed;

	private bool _sawIncantation;

	private string _lastLoggedStatus;

	public readonly List<string> DebugLines = new List<string>();

	public const int DebugKeep = 100;

	public bool LiveDebug;

	public int DebugSeq;

	private bool _debugPreloaded;

	private int _debugWrites;

	private DateTime _nextCastAt = DateTime.MinValue;

	private DateTime _lastCastSentAt = DateTime.MinValue;

	private DateTime _equipWaitUntil = DateTime.MinValue;

	private DateTime _modeWaitUntil = DateTime.MinValue;

	private int _physTargetId;

	private DateTime _physSentAt = DateTime.MinValue;

	private DateTime _lastPhysActivity = DateTime.MinValue;

	private bool _physAttacking;

	public readonly Healer Healer;

	public readonly TierWatch Tier;

	public readonly Looter Looter;

	public readonly MelkTank.Buffs.Buffer Buffer;

	public readonly Vitals Vitals;

	private bool _manaBusy;

	private bool _acgFighting;

	private List<KeyValuePair<int, string>> _untouched;

	private readonly HashSet<string> _loggedUnknown = new HashSet<string>();

	private DateTime _fractureAt = DateTime.MinValue;

	private const double FractureRadius = 5.0;

	private readonly HashSet<int> _wandReleased = new HashSet<int>();

	private static readonly Dictionary<int, Hp> _hp = new Dictionary<int, Hp>();

	private readonly Dictionary<int, WandLead> _wandLead = new Dictionary<int, WandLead>();

	private readonly Dictionary<int, int> _forcedLead = new Dictionary<int, int>();

	private long _maTick = -1L;

	private readonly Dictionary<KeyValuePair<int, double>, int> _maMemo = new Dictionary<KeyValuePair<int, double>, int>();

	private const double FractureConfirmS = 4.0;

	private static readonly Regex StreakHitRx = new Regex("(?:^|! )You \\w+ (?<who>.+?) for [\\d,]+ points? with .*Nether Streak", RegexOptions.IgnoreCase);

	private int _lastLandId;

	private string _lastLandSpell = "";

	private DateTime _lastLandAt = DateTime.MinValue;

	private static readonly Regex SpreadRx = new Regex("^Your void magic spreads to (?<n>\\d+) more creatures?", RegexOptions.IgnoreCase);

	private static readonly Regex DotLineRx = new Regex("^Your (?:Incantation of )?(?<s>.+?) deals [\\d,]+ points? of periodic \\w+ damage to (?<t>.+?) \\(\\d+ ticks?", RegexOptions.IgnoreCase);

	private DateTime _dotLineAt = DateTime.MinValue;

	private readonly List<double> _dotGaps = new List<double>();

	private readonly Dictionary<long, DateTime> _dotLast = new Dictionary<long, DateTime>();

	private readonly HashSet<string> _dotAmbiguousSaid = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

	private SpreadCheck _sc;

	private readonly List<AttackWatch> _attackWatch = new List<AttackWatch>();

	private static readonly Regex PetHitRx = new Regex("^\\[Pet\\]\\s+(?<pet>.+?)\\s+(?:\\w+\\s+)?hit\\s+(?<mob>.+?)\\s+for\\s+[\\d,]+", RegexOptions.IgnoreCase);

	public DateTime LastAttackAt = DateTime.MinValue;

	private int _dmgForId;

	private readonly Dictionary<int, DmgType> _autoDmgSaid = new Dictionary<int, DmgType>();

	private MethodInfo _petWanted;

	private DateTime _petWantedLookAt = DateTime.MinValue;

	private MethodInfo _petBusy;

	private DateTime _petBusyLookAt = DateTime.MinValue;

	private long _wiTick = -1L;

	private WeaponItem _wiItem;

	private bool _wiHas;

	private long _cwTick = -1L;

	private readonly Dictionary<KeyValuePair<MonsterRule, int>, WeaponItem> _cwMemo = new Dictionary<KeyValuePair<MonsterRule, int>, WeaponItem>();

	private readonly HashSet<string> _bestForLogged = new HashSet<string>();

	private static readonly Regex SlayerTextRx = new Regex("(?:^|\\n)- (?<sp>.+?) Slayer:\\s*(?<x>[\\d.]+)x", RegexOptions.Compiled);

	private static readonly Regex SlayerLabelRx = new Regex("\\((?<sp>[^()]+?) Slayer\\)", RegexOptions.Compiled);

	private int _ammoEquippedId;

	private const int MainHandSlot = 1048576;

	private const int OffHandSlot = 2097152;

	private const int TwoHandSlot = 33554432;

	private int _offTries;

	private int _offTriesFor;

	private DateTime _offGiveUpUntil = DateTime.MinValue;

	private DateTime _mainSwapStart = DateTime.MinValue;

	private DateTime _mainSwapGiveUpUntil = DateTime.MinValue;

	private bool _equipWaitPeace;

	private int _equipWaitItem;

	private DateTime _equipSentAt = DateTime.MinValue;

	private DateTime _equipOkAt = DateTime.MinValue;

	private DateTime _modeSentAt = DateTime.MinValue;

	private DateTime _modeOkAt = DateTime.MinValue;

	private CombatState _modeWant;

	private int _preEquipLogged;

	private string _physTargetName = "";

	private WeaponKind _physKind;

	private bool _physHasPos;

	private double _physX;

	private double _physY;

	private DateTime _nextNavLock = DateTime.MinValue;

	private int _lastScanCount;

	private DateTime _lastScanAt = DateTime.MinValue;

	private static Type _vtHelper;

	private DateTime _busySince = DateTime.MaxValue;

	private bool _busyIgnored;

	private long _cmTick = -1L;

	private float _cmRange = -1f;

	private int _cmCount;

	private long _hostTick = -1L;

	private List<Mob> _host;

	private DateTime _mobCountAt = DateTime.MinValue;

	private int _mobCount;

	private long _mirTick = -1L;

	private float _mirRange;

	private int _mirFocus;

	private int _mirTest;

	private List<WorldObject> _mirList;

	private readonly List<int> _mirIds = new List<int>();

	private readonly Dictionary<int, DateTime> _idAsked = new Dictionary<int, DateTime>();

	private DateTime _nextIdAsk = DateTime.MinValue;

	private DateTime _rulesScanAt = DateTime.MinValue;

	private bool _rulesNeedId;

	private DateTime _waitSince = DateTime.MinValue;

	private DateTime _waitDiagAt = DateTime.MinValue;

	private int _waitKills;

	private static int _meFrame = -1;

	private static int _meLb;

	private static bool _meOk;

	private static double _meX;

	private static double _meY;

	private static double _meZ;

	private static double _meNS;

	private static double _meEW;

	public int CurrentTargetId { get; private set; }

	public int FocusId { get; private set; }

	public string Status { get; private set; }

	private long TickStamp
	{
		get
		{
			DateTime now = DateTime.Now;
			if (_stampFor != _nextTick || _stampFrame != Perf.FrameNo || (now - _stampAt).TotalMilliseconds > 200.0)
			{
				_stampFor = _nextTick;
				_stampFrame = Perf.FrameNo;
				_stampAt = now;
				_stampNo++;
			}
			return _stampNo;
		}
	}

	private static TimeSpan TickInterval => Tuning.Ms("TickMs");

	public int CastingOnId
	{
		get
		{
			if (_pending != null)
			{
				return _pending.TargetId;
			}
			return ((DateTime.Now - _lastCastAt).TotalSeconds < 2.5) ? _lastCastOn : 0;
		}
	}

	private static TimeSpan LateConfirmWindow => Tuning.Sec("LateConfirmS");

	private static TimeSpan MinCastTime => Tuning.Ms("MinCastMs");

	private static TimeSpan NoStartWait => Tuning.Ms("NoStartWaitMs");

	private static TimeSpan DebuffConfirmTimeout => Tuning.Sec("DebuffConfirmS");

	private static TimeSpan AttackCastGap => Tuning.Ms("AttackCastGapMs");

	private static TimeSpan FailBackoff => Tuning.Sec("FailBackoffS");

	public static string DebugPath
	{
		get
		{
			string text = "";
			try
			{
				text = Globals.Core.CharacterFilter.Name ?? "";
			}
			catch
			{
			}
			StringBuilder stringBuilder = new StringBuilder();
			string text2 = text;
			foreach (char c in text2)
			{
				stringBuilder.Append(char.IsLetterOrDigit(c) ? c : '_');
			}
			return Util.FullPath((stringBuilder.Length == 0) ? "MelkTank_debug.txt" : ("MelkTank_debug_" + stringBuilder?.ToString() + ".txt"));
		}
	}

	public DotTimer Dots { get; private set; }

	public WeaponCompare Compare { get; private set; }

	public ManaTopUp Mana { get; private set; }

	public Salvager Salvage { get; private set; }

	public VendorRun Vendor { get; private set; }

	public AetheriaChunker Aetheria { get; private set; }

	public Areas Areas { get; private set; }

	public Stacker Stacker { get; private set; }

	public Nav Nav { get; private set; }

	public WindowsAtLogin Windows { get; private set; }

	private static double FractureCooldownS => Tuning.V("FractureCooldownS");

	private double DotLineInterval
	{
		get
		{
			if (_dotGaps.Count < 3)
			{
				return 10.0;
			}
			List<double> list = new List<double>(_dotGaps);
			list.Sort();
			return Math.Max(1.0, Math.Min(10.0, list[list.Count / 2]));
		}
	}

	private double DotLineQuietS => DotLineInterval * 2.0 + 1.5;

	private WorldObject _dmgFor
	{
		get
		{
			return (_dmgForId == 0) ? null : Globals.Core.WorldFilter[_dmgForId];
		}
		set
		{
			_dmgForId = value?.Id ?? 0;
		}
	}

	public bool HoldWeapon => Compare != null && Compare.Running && _s.CmpHoldWeapon;

	public bool ActionInProgress => _pending != null || IsBusy();

	private int TestTarget => (Compare != null) ? Compare.TargetId : 0;

	public bool InCombat { get; private set; }

	public bool FightingNow { get; private set; }

	public bool CalmNow { get; private set; }

	public bool NavHeld { get; private set; }

	private static TimeSpan NavLockLength => Tuning.Sec("VTankNavLockS");

	public bool LootMode { get; private set; }

	public float AttackRangeNow => LootMode ? Math.Min(_s.LootModeRange, _s.AttackRange) : _s.AttackRange;

	public void SetFocus(int id)
	{
		if (id == 0 || id == FocusId)
		{
			if (FocusId != 0)
			{
				Util.WriteToChat("Focus cleared.");
			}
			FocusId = 0;
			return;
		}
		WorldObject worldObject = Globals.Core.WorldFilter[id];
		if (worldObject != null)
		{
			FocusId = id;
			double num = Distance(worldObject);
			Util.WriteToChat("Focus: " + worldObject.Name + " - debuffed and attacked first until it dies" + ((num > (double)AttackRangeNow) ? (" (it's " + num.ToString("0") + "m away, outside your " + AttackRangeNow.ToString("0") + "m attack range).") : "."));
		}
	}

	private void ScanAlerts()
	{
		if (DateTime.Now < _nextAlertScan)
		{
			return;
		}
		_nextAlertScan = DateTime.Now.AddSeconds(1.0);
		bool flag = false;
		foreach (MonsterRule item in _s.AllRules())
		{
			if (item.Alert && !item.IsDefault)
			{
				flag = true;
				break;
			}
		}
		if (!flag)
		{
			return;
		}
		foreach (WorldObject item2 in Globals.Core.WorldFilter.GetLandscape())
		{
			if (!IsHostileMonster(item2) || (Tracked.TryGetValue(item2.Id, out var value) && value.DeadAt != DateTime.MinValue && (DateTime.Now - value.DeadAt).TotalSeconds < 8.0))
			{
				continue;
			}
			MonsterRule monsterRule = _s.FindRule(item2);
			if (!monsterRule.IsDefault && monsterRule.Alert)
			{
				TrackedMonster tracked = GetTracked(item2);
				tracked.Alert = true;
				if (_alerted.Add(item2.Id))
				{
					double num = Distance(item2);
					Util.WriteToChat("ALERT: " + item2.Name + " is nearby" + ((num >= 0.0) ? (" (" + num.ToString("0") + "m)") : "") + " - see the Tracking tab.", 18);
				}
			}
		}
	}

	private void Dbg(string line)
	{
		try
		{
			PackStats.OnEvent(line);
		}
		catch
		{
		}
		if (!_s.DebugLog && !LiveDebug)
		{
			return;
		}
		string text = DateTime.Now.ToString("HH:mm:ss.fff") + "  " + line;
		lock (DebugLines)
		{
			DebugLines.Add(text);
			DebugSeq++;
			if (DebugLines.Count > 100)
			{
				DebugLines.RemoveRange(0, DebugLines.Count - 100);
			}
		}
		if (!_s.DebugLog)
		{
			return;
		}
		try
		{
			string debugPath = DebugPath;
			Util.AppendShared(debugPath, text + Environment.NewLine);
			if (++_debugWrites % 500 == 0)
			{
				TrimDebug(debugPath);
			}
		}
		catch
		{
		}
	}

	public void NoteLine(string line)
	{
		Dbg(line);
	}

	private static void TrimDebug(string path)
	{
		long max = (long)(Tuning.V("DebugMaxMB") * 1024.0 * 1024.0);
		FileInfo fileInfo = new FileInfo(path);
		if (!fileInfo.Exists || fileInfo.Length <= max)
		{
			return;
		}
		Util.Locked(path, () =>
		{
			byte[] array = File.ReadAllBytes(path);
			int i;
			for (i = (int)Math.Max(0L, array.Length - max / 2); i < array.Length && array[i - ((i > 0) ? 1 : 0)] != 10; i++)
			{
			}
			byte[] array2 = new byte[array.Length - i];
			Array.Copy(array, i, array2, 0, array2.Length);
			File.WriteAllBytes(path, array2);
		});
	}

	public void PreloadDebug()
	{
		if (_debugPreloaded)
		{
			return;
		}
		_debugPreloaded = true;
		try
		{
			string debugPath = DebugPath;
			if (!File.Exists(debugPath))
			{
				return;
			}
			List<string> list = new List<string>();
			using (FileStream fileStream = new FileStream(debugPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
			{
				long num = Math.Max(0L, fileStream.Length - 65536);
				fileStream.Seek(num, SeekOrigin.Begin);
				using StreamReader streamReader = new StreamReader(fileStream);
				if (num > 0)
				{
					streamReader.ReadLine();
				}
				string text;
				while ((text = streamReader.ReadLine()) != null)
				{
					if (text.Length > 0)
					{
						list.Add(text);
					}
				}
			}
			if (list.Count > 100)
			{
				list.RemoveRange(0, list.Count - 100);
			}
			lock (DebugLines)
			{
				DebugLines.InsertRange(0, list);
				if (DebugLines.Count > 100)
				{
					DebugLines.RemoveRange(0, DebugLines.Count - 100);
				}
			}
		}
		catch
		{
		}
	}

	public CombatEngine(Settings settings)
	{
		_s = settings;
		Healer = new Healer(settings);
		Stacker = new Stacker(settings, Dbg);
		Mana = new ManaTopUp(settings, Dbg);
		Salvage = new Salvager(settings, Dbg);
		Vendor = new VendorRun(settings, () => Looter.ProfileDir, Dbg);
		Aetheria = new AetheriaChunker(settings, Dbg);
		Tier = new TierWatch(settings, Healer);
		Looter = new Looter(settings);
		Looter.DebugOut = Dbg;
		Buffer = new MelkTank.Buffs.Buffer(Healer, settings);
		Vitals = new Vitals(settings);
		Vitals.ReadyToCast = () => EnsureCaster(_s.DefaultRule, Slot.Vuln) && EnsureCombatMode(CombatState.Magic);
		Buffer.ExtraHold = () => Vitals.Busy;
		Compare = new WeaponCompare(settings, this);
		Dots = new DotTimer(settings, this, Dbg);
		Nav = new Nav(settings);
		Areas = new Areas(settings, Looter);
		Nav.FileDir = () => Looter.ProfileDir;
		ItemCompare.CompareIds = () =>
		{
			List<int> list = new List<int>();
			foreach (WeaponItem item in _s.Items)
			{
				if (item.CompareTo && !item.IsShield)
				{
					list.Add(item.Id);
				}
			}
			return list;
		};
		ItemCompare.ListedIds = () =>
		{
			List<int> list = new List<int>();
			foreach (WeaponItem item2 in _s.Items)
			{
				list.Add(item2.Id);
			}
			return list;
		};
		ArmorCompare.ListedShields = () =>
		{
			List<int> list = new List<int>();
			foreach (WeaponItem item3 in _s.Items)
			{
				if (item3.IsShield && item3.CompareTo)
				{
					list.Add(item3.Id);
				}
			}
			foreach (WeaponItem item4 in _s.Items)
			{
				if (item4.IsShield && !item4.CompareTo)
				{
					list.Add(item4.Id);
				}
			}
			return list;
		};
		Nav.Log = Dbg;
		Looter.MonstersNear = () => _s.CombatEnabled && _s.MasterEnabled && MonstersInRange().Exists((WorldObject m) => !PluginCore.IsPetOnly(m.Name));
		Windows = new WindowsAtLogin(settings);
		Status = "Idle";
	}

	private void TimedTick()
	{
		long t = Perf.Begin();
		try
		{
			Tick();
		}
		finally
		{
			Perf.Lap("  engine: fight (target / cast / attack)", t);
		}
	}

	private static T Timed<T>(string name, Func<T> f)
	{
		long t = Perf.Begin();
		try
		{
			return f();
		}
		finally
		{
			Perf.Lap(name, t);
		}
	}

	private bool LootTick()
	{
		long t = Perf.Begin();
		try
		{
			return Looter.Tick();
		}
		finally
		{
			Perf.Lap("  engine: looter", t);
		}
	}

	private bool TimedNav()
	{
		long t = Perf.Begin();
		try
		{
			return PreEquipThenNav();
		}
		finally
		{
			Perf.Lap("  engine: nav", t);
		}
	}

	public void OnRenderFrame()
	{
		bool flag = _s.MasterEnabled && _s.CombatEnabled && !PluginCore.IsPaused;
		if (_acgFighting && !flag)
		{
			try
			{
				CM_Combat.Event_CancelAttack();
			}
			catch
			{
			}
		}
		_acgFighting = flag;
		long t = Perf.Begin();
		try
		{
			Compare.Tick();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		try
		{
			Dots.Tick();
		}
		catch (Exception ex2)
		{
			Util.LogError(ex2);
		}
		t = Perf.Lap("  engine: compare / dots", t);
		try
		{
			Nav.UpdateMarkers();
		}
		catch (Exception ex3)
		{
			Util.LogError(ex3);
		}
		t = Perf.Lap("  engine: nav markers", t);
		try
		{
			Windows.Tick();
		}
		catch (Exception ex4)
		{
			Util.LogError(ex4);
		}
		try
		{
			LoginCommands.Tick();
		}
		catch (Exception ex5)
		{
			Util.LogError(ex5);
		}
		t = Perf.Lap("  engine: windows / login commands", t);
		if (DateTime.Now < _nextTick)
		{
			return;
		}
		_nextTick = DateTime.Now + TickInterval;
		try
		{
			try
			{
				ConfirmWaits();
			}
			catch (Exception ex6)
			{
				Util.LogError(ex6);
			}
			t = Perf.Lap("  engine: confirm waits", t);
			try
			{
				Vendor.Watch();
				InvStore.Tick();
			}
			catch (Exception exV)
			{
				Util.LogError(exV);
			}
			PruneTracked();
			AppraiseForRules();
			ArmorCompare.RequestWorn();
			ScanAlerts();
			ExpireAttackWatches();
			t = Perf.Lap("  engine: tracking / alerts / IDs", t);
			try
			{
				bool flag2 = _s.MasterEnabled && _pending == null && !Healer.Active && !Buffer.Busy && !Looter.Busy && !PluginCore.IsPaused && DateTime.Now - _lastCastSentAt > Tuning.Sec("QuietAfterCastS") && !Salvage.Busy;
				long t2 = Perf.Begin();
				try
				{
					Areas.Tick();
				}
				catch (Exception ex7)
				{
					Util.LogError(ex7);
				}
				t2 = Perf.Lap("    chores: areas", t2);
				bool flag3 = Mana.Tick(flag2 && !Nav.Running);
				t2 = Perf.Lap("    chores: mana top-up", t2);
				_manaBusy = flag3;
				bool flag4 = flag2 && !flag3 && CountMonsters(AttackRangeNow) == 0 && !Looter.HoldsNav;
				t2 = Perf.Lap("    chores: calm check (monsters in range)", t2);
				if (Salvage.Busy | flag4)
				{
					Salvage.Tick(flag4 || Salvage.Busy);
				}
				t2 = Perf.Lap("    chores: salvage", t2);
				bool flag5 = flag4 && !Salvage.Busy && Looter.UnlootedInRange() == 0;
				bool flag6 = flag2 && !flag3 && !Salvage.Busy;
				t2 = Perf.Lap("    chores: unlooted corpses check", t2);
				Aetheria.Tick(flag5 || Aetheria.Busy, flag6 || Aetheria.Busy);
				t2 = Perf.Lap("    chores: aetheria", t2);
				CalmNow = flag4 && !Looter.Busy && Looter.UnlootedInRange() == 0 && !Salvage.Busy && !Aetheria.Busy;
				t2 = Perf.Lap("    chores: calm-now", t2);
				if (!flag3 && !Salvage.Busy && !Aetheria.Busy)
				{
					Stacker.Tick(flag2);
				}
				t2 = Perf.Lap("    chores: stacker", t2);
				bool flag7 = flag4 && _s.CombatEnabled && !Salvage.Busy && !Aetheria.Busy && Looter.UnlootedInRange() == 0;
				if (_s.PeaceRightAway && (!_s.PeaceOnlyNav || _s.NavEnabled) && _s.MasterEnabled && _s.CombatEnabled && _pending == null && !Healer.Active && !Buffer.Busy && !Looter.Opening && !PluginCore.IsPaused && !flag3 && !Salvage.Busy && !Aetheria.Busy && CountMonsters(AttackRangeNow) == 0 && Globals.Core.Actions.CombatMode != CombatState.Peace && DateTime.Now - _peaceSentAt > TimeSpan.FromSeconds(1.5))
				{
					_peaceSentAt = DateTime.Now;
					Globals.Core.Actions.SetCombatMode(CombatState.Peace);
					Dbg("PEACE nothing in range - peace mode");
				}
				if (!_s.PeaceWhenIdle || !flag7 || (_s.PeaceOnlyNav && !_s.NavEnabled))
				{
					_idleSince = DateTime.MinValue;
				}
				else
				{
					if (_idleSince == DateTime.MinValue)
					{
						_idleSince = DateTime.Now;
					}
					if ((DateTime.Now - _idleSince).TotalSeconds >= (double)_s.PeaceIdleS && Globals.Core.Actions.CombatMode != CombatState.Peace && DateTime.Now - _peaceSentAt > TimeSpan.FromSeconds(3L))
					{
						_peaceSentAt = DateTime.Now;
						Globals.Core.Actions.SetCombatMode(CombatState.Peace);
						Status = "Idle - peace mode";
					}
				}
			}
			catch (Exception ex8)
			{
				Util.LogError(ex8);
			}
			if (!_s.MasterEnabled)
			{
				ShelvePending();
				CancelPhysicalAttack();
				// (a chest you open yourself still gets its line with "Say when a chest has nothing")
				if (_s.ChestSummary && Looter.UserChestOpen())
				{
					Looter.TickUserChestOnly();
					ReleaseNav();
					Nav.Stop();
					Status = "MelkTank OFF - " + Looter.Status;
					return;
				}
				// (a visit started by hand - the Vendor tab, /mt vendor - runs with MelkTank off too)
				if (Vendor.Busy)
				{
					Looter.Abort("MelkTank off");
					Vendor.Tick();
					Status = "MelkTank OFF - vendor - " + Vendor.Status;
					return;
				}
				Looter.Abort("MelkTank off");
				ReleaseNav();
				Nav.Stop();
				Status = "MelkTank OFF";
				return;
			}
			UpdateVTankNavLock();
			if (Vendor.Busy)
			{
				ShelvePending();
				CancelPhysicalAttack();
				Looter.Abort("vendoring");
				Nav.Stop();
				Vendor.Tick();
				Status = "Vendor - " + Vendor.Status;
				return;
			}
			if (Aetheria.Busy)
			{
				ShelvePending();
				CancelPhysicalAttack();
				Nav.Stop();
				Status = "Aetheria - " + Aetheria.Status;
				return;
			}
			if (PluginCore.IsPaused)
			{
				ShelvePending();
				CancelPhysicalAttack();
				Looter.Abort("paused");
				Nav.Stop();
				Status = (_s.CombatEnabled ? ("Paused by " + PluginCore.PausedByText) : "Disabled");
				return;
			}
			t = Perf.Lap("  engine: idle chores (mana / salvage / stacker / peace)", t);
			bool healing = Healer.Tick();
			t = Perf.Lap("  engine: healer", t);
			if (healing)
			{
				ShelvePending();
				CancelPhysicalAttack();
				Looter.Abort("healing");
				Nav.Stop();
				Status = "Healing - " + Healer.HealthPercent().ToString("0") + "% (try " + Healer.Tries + ")" + (Buffer.WaitingForHeal ? " - buffing waits" : "");
				return;
			}
			bool restoring = Vitals.Tick();
			t = Perf.Lap("  engine: vitals", t);
			if (restoring)
			{
				ShelvePending();
				CancelPhysicalAttack();
				Nav.Stop();
				Status = "Restoring - " + Vitals.LastAction;
				return;
			}
			if (Buffer.Busy)
			{
				ShelvePending();
				CancelPhysicalAttack();
				Looter.Abort("buffing");
				Nav.Stop();
				Status = "Buffing - " + Buffer.Status;
				return;
			}
			if (Salvage.Busy || _manaBusy)
			{
				ShelvePending();
				CancelPhysicalAttack();
				Nav.Stop();
				Status = (Salvage.Busy ? ("Salvaging - " + Salvage.Status) : ("Mana - " + Mana.Status));
				return;
			}
			bool flag8 = PetSummoner.DeviceWanted || PetCall(ref _petWanted, "DeviceWanted");
			if (flag8 || PetSummoner.DeviceBusy || PetDeviceBusy())
			{
				// (an essence is used on the move - summoning and dismissing are instant in the game - so the route carries on;
				// only casting and attacking wait the moment it takes, so the game isn't asked for two things at once)
				bool flag9 = Nav.Running && Nav.IdleTick();
				Status = (flag8 ? "Waiting - pet summoner's turn" : "Waiting - pet summoner using a device") + (flag9 ? " (still walking)" : "");
				return;
			}
			bool flag10 = false;
			t = Perf.Lap("  engine: healer / vitals / buffing checks", t);
			try
			{
				flag10 = Dex.Tick(this);
			}
			catch (Exception ex9)
			{
				Util.LogError(ex9);
			}
			t = Perf.Lap("  engine: dex", t);
			if (flag10)
			{
				ShelvePending();
				Looter.Abort("dex");
				Nav.Stop();
				Status = "Dex - " + (Dex.TurnIn.Busy ? Dex.TurnIn.Status : Dex.Status);
				return;
			}
			if (Nav.PriorityTick())
			{
				ShelvePending();
				CancelPhysicalAttack();
				Looter.Abort("returning to spot");
				Status = "Nav - " + Nav.Status;
				return;
			}
			UpdateLootMode();
			t = Perf.Lap("  engine: nav priority / loot mode", t);
			List<WorldObject> list = (_s.CombatEnabled ? MonstersInRange() : new List<WorldObject>());
			_lastScanCount = list.Count;
			_lastScanAt = DateTime.Now;
			t = Perf.Lap("  engine: monster scan", t);
			try
			{
				Session.NoteFight(list.Count);
			}
			catch
			{
			}
			_untouched = new List<KeyValuePair<int, string>>();
			foreach (WorldObject item in list)
			{
				if (Tracked.TryGetValue(item.Id, out var value) && value.EngagedAt == DateTime.MinValue && value.Debuffs.Count == 0 && value.DeadAt == DateTime.MinValue)
				{
					_untouched.Add(new KeyValuePair<int, string>(item.Id, item.Name));
				}
			}
			TrackAround();
			t = Perf.Lap("  engine: track around / untouched", t);
			bool flag11 = (FightingNow = _s.CombatEnabled && (_pending != null || list.Count > 0));
			if (_s.NavBoost && _s.NavEnabled && TimedNav())
			{
				CancelPhysicalAttack();
				Looter.Abort("nav priority boost");
				Status = "Nav (boost) - " + Nav.Status;
			}
			else if (_s.LootBoost && Looter.On && LootTick())
			{
				CancelPhysicalAttack();
				Nav.Stop();
				Status = "Looting (boost) - " + Looter.Status;
			}
			else if (_s.LootBoost && Looter.On && Looter.HoldsNav)
			{
				CancelPhysicalAttack();
				Nav.Stop();
				Status = "Looting (boost) - next corpse";
			}
			else if (flag11 && Timed("  engine: combat has work?", () => CombatHasWork(list)))
			{
				Looter.Abort("monsters");
				Nav.Stop();
				TimedTick();
			}
			else if (Timed("  engine: main weapon for loot?", MainWeaponForLoot))
			{
				Nav.Stop();
			}
			else if (LootTick())
			{
				Nav.Stop();
				Status = "Looting - " + Looter.Status;
			}
			else if (Looter.HoldsNav)
			{
				Nav.Stop();
				Status = "Looting - next corpse";
			}
			else if (list.Count == 0 && _pending == null && Timed("  engine: approach target?", ApproachTarget) is WorldObject approach && Nav.ApproachTick(approach, Math.Max(1.0, (double)AttackRangeNow - 1.0)))
			{
				Status = "Approaching " + approach.Name + " (" + Distance(approach).ToString("0") + " m)";
			}
			else if (flag11 && _s.NavEnabled && _s.NavMode == 1 && list.Count > 0 && FirstReachable(list) != null)
			{
				Nav.Stop();
				Status = "Waiting - DoTs ticking on " + list.Count + " monster" + ((list.Count == 1) ? "" : "s");
				if ((DateTime.Now - _waitDiagAt).TotalSeconds > 20.0 && (_s.DebugLog || LiveDebug))
				{
					_waitDiagAt = DateTime.Now;
					foreach (WorldObject item2 in list)
					{
						TrackedMonster tracked = GetTracked(item2);
						MonsterRule monsterRule = _s.FindRule(item2);
						string text = "";
						foreach (KeyValuePair<Slot, DateTime> item3 in tracked.RetryAfter)
						{
							if (item3.Value > DateTime.Now)
							{
								text = text + item3.Key.ToString() + " ";
							}
						}
						string text2 = "";
						foreach (KeyValuePair<Slot, ActiveDebuff> debuff in tracked.Debuffs)
						{
							text2 = text2 + debuff.Key.ToString() + (debuff.Value.FromSpread ? "(s)" : "") + (debuff.Value.LineOnly ? "(l)" : "") + " ";
						}
						Dbg("WAIT? " + item2.Name + " [" + item2.Id + "] " + Distance(item2).ToString("0.0") + "m row '" + ((monsterRule == null) ? "-" : monsterRule.Name) + "' wand " + WandIdFor(item2) + (tracked.Blocked ? " BLOCKED" : "") + (tracked.Deferred ? " deferred" : "") + " lead=" + PrimeLeadOfItsWand(item2) + " nf=" + FractureWanted(item2, monsterRule) + " released=" + _wandReleased.Contains(WandIdFor(item2)) + " debuffs[" + text2.Trim() + "] retry[" + text.Trim() + "] done=" + tracked.FractureDone);
					}
				}
				if (_waitSince == DateTime.MinValue || Session.KillCount != _waitKills)
				{
					_waitSince = DateTime.Now;
					_waitKills = Session.KillCount;
				}
				else
				{
					if (!((DateTime.Now - _waitSince).TotalSeconds > Tuning.V("StuckWaitS")))
					{
						return;
					}
					Dbg("STUCK waiting " + (int)(DateTime.Now - _waitSince).TotalSeconds + "s with no kill on " + list.Count + " monster(s) - picking primes again, blocked ones tried again");
					_wandReleased.Clear();
					_wandLead.Clear();
					_forcedLead.Clear();
					foreach (WorldObject item4 in list)
					{
						TrackedMonster tracked2 = GetTracked(item4);
						tracked2.Blocked = false;
						tracked2.Misses = 0;
						tracked2.RetryAfter.Clear();
						tracked2.FractureDone = false;
					}
					_waitSince = DateTime.Now;
				}
			}
			else if (TimedNav())
			{
				Status = "Nav - " + Nav.Status;
			}
			else if (!_s.CombatEnabled)
			{
				Status = "Disabled";
			}
			else
			{
				TimedTick();
			}
		}
		catch (Exception ex10)
		{
			Util.LogError(ex10);
			Status = "Error: " + ex10.Message;
		}
		finally
		{
			if (Status != _lastLoggedStatus)
			{
				_lastLoggedStatus = Status;
				Dbg("STATUS " + Status);
			}
			long t3 = Perf.Begin();
			try
			{
				PackStats.Tick(Status, _untouched, Session.KillCount);
			}
			catch
			{
			}
			Perf.Lap("  engine: pack stats", t3);
		}
	}

	private int _lastCastSpell;

	public void OnChat(string text)
	{
		if (string.IsNullOrEmpty(text))
		{
			return;
		}
		text = text.Trim();
		// The server won't cast it for want of components: that spell is left alone for 10 minutes (the next level down, another
		// shape or the weapon is used) instead of being tried over and over.
		if (_lastCastSpell != 0 && (DateTime.Now - _lastCastSentAt).TotalSeconds < 10.0 && text.IndexOf("don't have all the components", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			if (!SpellLevels.IsRefused(_lastCastSpell))
			{
				Util.WriteToChat("Combat: no components for " + SpellLevels.Name(_lastCastSpell) + " - not casting it for 10 minutes.");
			}
			SpellLevels.Refused(_lastCastSpell);
			_lastCastSpell = 0;
		}
		try
		{
			PackStats.OnChat(text);
		}
		catch
		{
		}
		NotePrimeLine(text);
		NoteFractureLine(text);
		NoteSpreadLine(text);
		NoteDotLine(text);
		Healer.OnChat(text);
		Looter.OnChat(text);
		Nav.OnChat(text);
		try
		{
			Compare.OnChat(text);
		}
		catch
		{
		}
		try
		{
			Dots.OnChat(text);
		}
		catch
		{
		}
		if (Healer.IsHealLine(text))
		{
			Dbg("HEAL  " + text);
			return;
		}
		CheckAttackLanded(text);
		if (_s.TimerOnPetHit)
		{
			CheckPetHit(text);
		}
		if (_physAttacking && _physKind == WeaponKind.Missile && _physTargetId != 0 && text.IndexOf("environment", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			Dbg("MISS  missile hit the environment -> [" + _physTargetId + "]");
			NoteMissileMiss(_physTargetId, _physTargetName);
			if (IsBlocked(_physTargetId))
			{
				CancelPhysicalAttack();
			}
		}
		if (_physAttacking && (text.IndexOf("evaded your attack", StringComparison.OrdinalIgnoreCase) >= 0 || (text.IndexOf(" for ", StringComparison.Ordinal) > 0 && text.IndexOf(" point", StringComparison.Ordinal) > 0 && (text.StartsWith("You ") || text.StartsWith("Critical hit! You ")) && text.IndexOf(" with ", StringComparison.Ordinal) < 0)))
		{
			_lastPhysActivity = DateTime.Now;
			if (text.IndexOf(" point", StringComparison.Ordinal) > 0)
			{
				LandedOn(_physTargetId);
			}
		}
		if (text.StartsWith("You say, \"", StringComparison.Ordinal) && _pending != null && !_pending.Said && DateTime.Now - _pending.At < NoStartWait + NoStartWait)
		{
			_pending.Said = true;
			_sawIncantation = true;
		}
		int num = text.IndexOf("no line of sight to ", StringComparison.OrdinalIgnoreCase);
		if (num >= 0 && text.IndexOf("does not reach", StringComparison.OrdinalIgnoreCase) > 0)
		{
			Dbg("CHAT  " + text);
			int num2 = num + "no line of sight to ".Length;
			int num3 = text.IndexOf(" - ", num2, StringComparison.Ordinal);
			string text2 = ((num3 > num2) ? text.Substring(num2, num3 - num2).Trim() : "");
			int num4 = 0;
			if (_pending != null && (text2.Length == 0 || string.Equals(_pending.TargetName, text2, StringComparison.OrdinalIgnoreCase)))
			{
				num4 = _pending.TargetId;
			}
			else if (_physTargetId != 0 && string.Equals(_physTargetName, text2, StringComparison.OrdinalIgnoreCase))
			{
				num4 = _physTargetId;
			}
			if (num4 != 0 && Tracked.TryGetValue(num4, out var value))
			{
				WorldObject worldObject = Globals.Core.WorldFilter[num4];
				value.Blocked = true;
				value.BlockedAt = DateTime.Now;
				value.Misses = 0;
				if (worldObject != null)
				{
					Pos(worldObject, out value.BlockX, out value.BlockY);
				}
				Dbg("BLOCK " + value.Name + " [" + num4 + "] - no line of sight");
			}
			if (_pending != null && _pending.TargetId == num4)
			{
				_pending = null;
				_nextCastAt = DateTime.Now;
			}
			if (_physAttacking && _physTargetId == num4 && num4 != 0)
			{
				CancelPhysicalAttack();
			}
			return;
		}
		bool flag = text.StartsWith("You cast ", StringComparison.OrdinalIgnoreCase);
		bool flag2 = text.IndexOf("resists your spell", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("Your spell fizzled", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("You fail to", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("out of range", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("don't have enough Mana", StringComparison.OrdinalIgnoreCase) >= 0;
		if (flag | flag2)
		{
			Dbg("CHAT  " + text);
		}
		else if (DateTime.Now - _lastCastSentAt < TimeSpan.FromSeconds(2L))
		{
			Dbg("CHAT? " + text);
		}
		if (flag)
		{
			bool flag3 = _pending != null && _pending.Slot.HasValue && LineMatches(text, _pending);
			if (_lastMissed != null && DateTime.Now - _lastMissed.At < LateWindow(_lastMissed) && LineMatches(text, _lastMissed) && (!flag3 || DateTime.Now - _pending.At < MinCastTime))
			{
				PendingCast lastMissed = _lastMissed;
				_lastMissed = null;
				Dbg("      ^ late landing for earlier cast on [" + lastMissed.TargetId + "]");
				ApplyLanded(lastMissed);
			}
			else if (flag3)
			{
				PendingCast pending = _pending;
				_pending = null;
				if (_lastMissed != null && _lastMissed.TargetId == pending.TargetId)
				{
					_lastMissed = null;
				}
				ApplyLanded(pending);
				_nextCastAt = DateTime.Now + TimeSpan.FromMilliseconds(_s.CastRecoveryMs);
			}
			else if (_pending != null && _pending.Slot.HasValue)
			{
				Dbg("      ^ not ours (waiting on " + _pending.Spell.Name + " -> " + _pending.TargetName + ")");
			}
		}
		else if (flag2 && _pending != null && _pending.Slot.HasValue)
		{
			FailPending(timedOut: false);
		}
	}

	private static TimeSpan LateWindow(PendingCast p)
	{
		TimeSpan timeSpan = p.Timeout + TimeSpan.FromSeconds(2L);
		return (timeSpan < LateConfirmWindow) ? LateConfirmWindow : timeSpan;
	}

	private static bool Pos(WorldObject o, out double x, out double y)
	{
		x = (y = 0.0);
		try
		{
			CoordsObject coordsObject = o.Coordinates();
			if (coordsObject == null)
			{
				return false;
			}
			x = coordsObject.EastWest * 240.0;
			y = coordsObject.NorthSouth * 240.0;
			return true;
		}
		catch
		{
			return false;
		}
	}

	private bool SameNameUnconfirmed(WorldObject mob, SpellLevel spell)
	{
		PendingCast lastMissed = _lastMissed;
		if (lastMissed == null || spell == null || lastMissed.Spell == null)
		{
			return false;
		}
		if (DateTime.Now - lastMissed.At >= LateWindow(lastMissed))
		{
			return false;
		}
		if (lastMissed.TargetId == mob.Id)
		{
			return false;
		}
		return string.Equals(lastMissed.TargetName, mob.Name, StringComparison.OrdinalIgnoreCase) && string.Equals(lastMissed.Spell.Name, spell.Name, StringComparison.OrdinalIgnoreCase);
	}

	private static bool LineMatches(string text, PendingCast p)
	{
		if (p == null || p.Spell == null)
		{
			return false;
		}
		string text2 = "You cast " + p.Spell.Name + " on ";
		return text.StartsWith(text2, StringComparison.OrdinalIgnoreCase) && text.IndexOf(p.TargetName, text2.Length, StringComparison.OrdinalIgnoreCase) >= 0;
	}

	public void OnObjectReleased(int id)
	{
		try
		{
			if (Tracked.TryGetValue(id, out var value))
			{
				PackStats.Gone(id, value.Name);
			}
		}
		catch
		{
		}
		try
		{
			Compare.OnReleased(id);
		}
		catch
		{
		}
		try
		{
			Dots.OnReleased(id);
		}
		catch
		{
		}
		Tracked.Remove(id);
		_alerted.Remove(id);
		if (FocusId == id)
		{
			FocusId = 0;
		}
		Looter.OnObjectReleased(id);
		if (_pending != null && _pending.TargetId == id)
		{
			DateTime dateTime = _pending.At + Tuning.Ms("CastBusyMs");
			if (dateTime > _nextCastAt)
			{
				_nextCastAt = dateTime;
			}
			_pending = null;
		}
		if (CurrentTargetId == id)
		{
			CurrentTargetId = 0;
		}
	}

	public void NoteKillText(string text)
	{
		if (string.IsNullOrEmpty(text) || text.StartsWith("[Pet]", StringComparison.OrdinalIgnoreCase) || Regex.IsMatch(text, " hits? .+ for [\\d,]+\\b") || text.IndexOf(" points", StringComparison.OrdinalIgnoreCase) >= 0 || text.StartsWith("You have killed", StringComparison.OrdinalIgnoreCase) || text.IndexOf(" gives you ", StringComparison.OrdinalIgnoreCase) >= 0 || text.StartsWith("Aetheria", StringComparison.OrdinalIgnoreCase) || text.StartsWith("You say", StringComparison.OrdinalIgnoreCase) || text.IndexOf(" with ", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			return;
		}
		string text2 = null;
		foreach (TrackedMonster value in Tracked.Values)
		{
			if (!string.IsNullOrEmpty(value.Name) && text.IndexOf(value.Name, StringComparison.OrdinalIgnoreCase) >= 0 && (text2 == null || value.Name.Length > text2.Length))
			{
				text2 = value.Name;
			}
		}
		if (text2 == null)
		{
			return;
		}
		TrackedMonster trackedMonster = null;
		int num = 0;
		foreach (TrackedMonster value2 in Tracked.Values)
		{
			if (string.Equals(value2.Name, text2, StringComparison.OrdinalIgnoreCase) && value2.DeadAt == DateTime.MinValue)
			{
				trackedMonster = value2;
				num++;
			}
		}
		if (num == 1)
		{
			trackedMonster.DeadAt = DateTime.Now;
			Dbg("DEAD  " + trackedMonster.Name + " [" + trackedMonster.Id + "] (kill line) - not a target");
		}
	}

	private void Tick()
	{
		if (_pending != null)
		{
			TimeSpan timeSpan = DateTime.Now - _pending.At;
			if (_pending.Slot.HasValue)
			{
				if (_sawIncantation && !_pending.Said && timeSpan > NoStartWait && !IsBusy())
				{
					bool flag = Session.KillLineSince(_pending.TargetName, _pending.At);
					Dbg("NOSTART no incantation in " + NoStartWait.TotalSeconds.ToString("0.0") + "s: " + _pending.Spell.Name + " -> " + _pending.TargetName + " [" + _pending.TargetId + "], " + (flag ? "it died meanwhile - not again" : "sending again"));
					if (flag && Tracked.TryGetValue(_pending.TargetId, out var value))
					{
						value.DeadAt = DateTime.Now;
					}
					_pending = null;
					return;
				}
				if (timeSpan < _pending.Timeout)
				{
					Status = "Casting " + _pending.Spell.Name + " on " + _pending.TargetName;
					return;
				}
				FailPending(timedOut: true);
			}
			else
			{
				if (timeSpan < (_pending.Streak ? Tuning.Sec("FractureHoldS") : AttackCastGap))
				{
					if (_pending.Streak)
					{
						Status = "Nether Fracture: waiting for " + _pending.Spell.Name + " to land on " + _pending.TargetName;
					}
					return;
				}
				_pending = null;
			}
		}
		if (DateTime.Now < _equipWaitUntil || DateTime.Now < _modeWaitUntil)
		{
			Status = ((DateTime.Now < _equipWaitUntil) ? "Waiting - equipping" : "Waiting - changing combat mode");
			return;
		}
		if (DateTime.Now < _nextCastAt)
		{
			Status = "Waiting - cast recovery";
			return;
		}
		if (IsBusy())
		{
			Status = "Waiting - the game says busy (" + (int)(DateTime.Now - _busySince).TotalSeconds + "s)";
			return;
		}
		List<WorldObject> list = MonstersInRange();
		if (list.Count == 0)
		{
			CurrentTargetId = 0;
			_wandReleased.Clear();
			_wandLead.Clear();
			_forcedLead.Clear();
			Status = "No monsters in range";
			return;
		}
		try
		{
			RePrimeTick(list);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		try
		{
			VerifySpread(list);
		}
		catch (Exception ex2)
		{
			Util.LogError(ex2);
		}
		try
		{
			SpreadHealthTick();
		}
		catch (Exception ex3)
		{
			Util.LogError(ex3);
		}
		WorldObject worldObject = FirstReachable(list);
		if (worldObject == null)
		{
			CurrentTargetId = 0;
			Status = "Only blocked monsters in range (something's in the way)";
			return;
		}
		CurrentTargetId = worldObject.Id;
		if (FractureRelease(list))
		{
			return;
		}
		foreach (WorldObject item in list)
		{
			TrackedMonster tracked = GetTracked(item);
			if (!tracked.SpreadMissed || tracked.DeadAt != DateTime.MinValue)
			{
				continue;
			}
			UpdateBlocked(item, tracked);
			if (tracked.Blocked)
			{
				continue;
			}
			MonsterRule rule = _s.FindRule(item);
			if (!FindNeededDebuff(item, rule, out var slot, out var spell) || SameNameUnconfirmed(item, spell))
			{
				continue;
			}
			if (EnsureCaster(rule, slot))
			{
				CastDebuff(item, slot, spell);
			}
			return;
		}
		bool flag2 = FocusId != 0 && worldObject.Id == FocusId && HasAttack(_s.FindRule(worldObject));
		bool flag3 = TestTarget != 0 && worldObject.Id == TestTarget;
		List<WorldObject> list2;
		if (flag3)
		{
			list2 = new List<WorldObject> { worldObject };
		}
		else if (_s.PrimeEveryNF && ServerMode.Ilt && !flag2)
		{
			list2 = PrimeOrder(list);
		}
		else
		{
			list2 = ((_s.DebuffAllFirst && !flag2) ? DebuffOrder(list) : new List<WorldObject> { worldObject });
		}
		for (int i = ((!_s.FewerWeaponSwaps || flag3) ? 1 : 0); i < 2; i++)
		{
			foreach (WorldObject item2 in list2)
			{
				TrackedMonster tracked2 = GetTracked(item2);
				UpdateBlocked(item2, tracked2);
				if (tracked2.Blocked && !flag3)
				{
					continue;
				}
				MonsterRule rule2 = _s.FindRule(item2);
				if (!FindNeededDebuff(item2, rule2, out var slot2, out var spell2) || (!flag3 && SameNameUnconfirmed(item2, spell2)) || (i == 0 && !CastableInHand(rule2, slot2)))
				{
					continue;
				}
				if (EnsureCaster(rule2, slot2))
				{
					CastDebuff(item2, slot2, spell2);
				}
				return;
			}
		}
		if ((_s.StreakPrimed || _s.StreakDotted) && !StreakablePrimed(worldObject) && !HasAttack(_s.FindRule(worldObject)))
		{
			WorldObject worldObject2 = list.Find(StreakablePrimed);
			if (worldObject2 != null)
			{
				worldObject = worldObject2;
			}
		}
		if (DexNoHit(worldObject))
		{
			WorldObject worldObject3 = null;
			foreach (WorldObject item3 in list)
			{
				if (!DexNoHit(item3))
				{
					TrackedMonster tracked3 = GetTracked(item3);
					if (!tracked3.Blocked && !(tracked3.DeadAt != DateTime.MinValue) && (HasAttack(_s.FindRule(item3)) || StreakablePrimed(item3)))
					{
						worldObject3 = item3;
						break;
					}
				}
			}
			if (worldObject3 == null)
			{
				Status = "Dex - letting the DoTs work (" + worldObject.Name + (Dex.Held(worldObject) ? "" : " is primed") + ")";
				return;
			}
			worldObject = worldObject3;
		}
		Attack(worldObject);
	}

	private bool CombatHasWork(List<WorldObject> mobs)
	{
		if (_pending != null)
		{
			return true;
		}
		if (mobs.Count == 0)
		{
			return false;
		}
		if (FractureReady(mobs) != null)
		{
			return true;
		}
		bool flag = FocusId != 0 && mobs[0].Id == FocusId && HasAttack(_s.FindRule(mobs[0]));
		bool flag2 = TestTarget != 0 && mobs[0].Id == TestTarget;
		List<WorldObject> list = ((_s.DebuffAllFirst && !flag && !flag2) ? mobs : new List<WorldObject> { mobs[0] });
		foreach (WorldObject item in list)
		{
			TrackedMonster tracked = GetTracked(item);
			UpdateBlocked(item, tracked);
			if (tracked.Blocked || !FindNeededDebuff(item, _s.FindRule(item), out var _, out var _))
			{
				continue;
			}
			return true;
		}
		WorldObject worldObject = FirstReachable(mobs);
		if ((_s.StreakPrimed || _s.StreakDotted) && mobs.Exists(StreakablePrimed))
		{
			return true;
		}
		if (worldObject != null && DexNoHit(worldObject))
		{
			return mobs.Exists((WorldObject m) => !DexNoHit(m) && !GetTracked(m).Blocked && HasAttack(_s.FindRule(m)));
		}
		return worldObject != null && HasAttack(_s.FindRule(worldObject));
	}

	private WorldObject FirstReachable(List<WorldObject> mobs)
	{
		foreach (WorldObject mob in mobs)
		{
			if (mob.Id == TestTarget || mob.Id == FocusId)
			{
				return mob;
			}
			TrackedMonster tracked = GetTracked(mob);
			UpdateBlocked(mob, tracked);
			if (!tracked.Blocked)
			{
				return mob;
			}
		}
		return null;
	}

	private bool IsBlocked(int id)
	{
		TrackedMonster value;
		return Tracked.TryGetValue(id, out value) && value.Blocked;
	}

	private List<WorldObject> DebuffOrder(List<WorldObject> mobs)
	{
		List<WorldObject> list = new List<WorldObject>();
		List<WorldObject> list2 = new List<WorldObject>();
		foreach (WorldObject mob in mobs)
		{
			(GetTracked(mob).Deferred ? list2 : list).Add(mob);
		}
		list.AddRange(list2);
		return list;
	}

	private bool StreakablePrimed(WorldObject mob)
	{
		if (!ServerMode.Ilt)
		{
			return false;
		}
		if ((!_s.StreakPrimed && !_s.StreakDotted) || mob == null)
		{
			return false;
		}
		if (WeaponRow(_s.FindRule(mob)))
		{
			return false;
		}
		if (DexNoHit(mob))
		{
			return false;
		}
		if (Tracked.TryGetValue(mob.Id, out var value) && value.SpreadMissed && !value.EverPrimed && value.GamePrimedAt == DateTime.MinValue)
		{
			return false;
		}
		if (!Tracked.TryGetValue(mob.Id, out var value2) || value2.Blocked || value2.DeadAt != DateTime.MinValue)
		{
			return false;
		}
		if (value2.FractureCastAt != DateTime.MinValue)
		{
			return false;
		}
		DateTime dateTime = PrimedSince(value2);
		if (dateTime != DateTime.MinValue)
		{
			MonsterRule rule = _s.FindRule(mob);
			if ((ForcedPrime(mob) || HasNF(rule)) && (DateTime.Now - value2.ReleasedAt).TotalSeconds < FractureCooldownS)
			{
				return false;
			}
			return _s.StreakPrimed && (DateTime.Now - dateTime).TotalSeconds >= (double)_s.FractureDelayS;
		}
		if (value2.EverPrimed)
		{
			return _s.StreakPrimed;
		}
		if (_s.PrimeOnePerWand && _wandReleased.Count > 0 && HasNF(_s.FindRule(mob)) && _wandReleased.Contains(WandIdFor(mob)) && !NoDots(value2))
		{
			return true;
		}
		if (!_s.StreakDotted)
		{
			return false;
		}
		bool result = true;
		Slot[] array = new Slot[3]
		{
			Slot.Corruption,
			Slot.DestructiveCurse,
			Slot.Corrosion
		};
		foreach (Slot key in array)
		{
			if (!value2.Debuffs.ContainsKey(key))
			{
				result = false;
				break;
			}
		}
		return result;
	}

	private bool HasAttack(MonsterRule rule)
	{
		WeaponKind weaponKind = ChooseWeapon(rule)?.Kind ?? _s.DefaultAttack;
		if (!rule.Allows(weaponKind))
		{
			return false;
		}
		if (weaponKind != WeaponKind.Caster)
		{
			// A (Attack): in magic it's arcs / bolts; with a melee weapon or bow it's what allows attacking at all
			return rule.Slots[(int)Slot.Arc];
		}
		return rule.Has(Slot.Arc) || rule.Has(Slot.Ring) || rule.Has(Slot.Streak);
	}

	private bool FindNeededDebuff(WorldObject mob, MonsterRule rule, out Slot slot, out SpellLevel spell)
	{
		_dmgFor = mob;
		slot = Slot.Fester;
		spell = null;
		TrackedMonster tracked = GetTracked(mob);
		DmgType element = ((rule.ExVuln != DmgType.Auto) ? rule.ExVuln : ResolveDmg(rule));
		bool flag = FocusPrimeWanted(mob, tracked);
		bool flag2 = flag || FractureWanted(mob, rule) || Dex.Held(mob);
		Slot[] all = Slots.All;
		for (int i = 0; i < all.Length; i++)
		{
			Slot slot2 = all[i];
			if (Slots.IsWarShape(slot2) || slot2 == Slot.Fracture || (!rule.Has(slot2) && (!flag2 || !Slots.IsPrime(slot2))) || (tracked.RetryAfter.TryGetValue(slot2, out var value) && DateTime.Now < value))
			{
				continue;
			}
			bool flag3 = Slots.IsDot(slot2);
			bool flag4 = flag || (flag2 && OwnPrimeWanted(tracked));
			if (!tracked.Debuffs.TryGetValue(slot2, out var value2) || (flag4 && value2.FromSpread && Slots.IsPrime(slot2)) || (!value2.LineOnly && (flag3 ? _s.RefreshDots : _s.RefreshVulns) && !(value2.ExpiresAt - DateTime.Now > TimeSpan.FromSeconds(_s.RefreshLeadSeconds))))
			{
				string text = (flag3 ? Slots.FamilyKeyForDot(slot2) : Slots.FamilyKeyForVuln(slot2, element));
				SpellLevel spellLevel = SpellBook.Resolve(text, flag3 ? _s.Level1Dot : _s.Level1Vuln);
				if (spellLevel != null)
				{
					slot = slot2;
					spell = spellLevel;
					return true;
				}
				if (_loggedUnknown.Add(text ?? slot2.ToString()))
				{
					Dbg("SKIP  no known spell for " + Slots.Labels[(int)slot2] + " (" + (text ?? ("none for " + element)) + ")");
				}
			}
		}
		return false;
	}

	private bool NFTicked(MonsterRule rule)
	{
		if (rule != null && !rule.Magic)
		{
			return false;
		}
		return _s.FractureAll || (rule?.Has(Slot.Fracture) ?? false);
	}

	private bool HasNF(MonsterRule rule)
	{
		return NFTicked(rule) && !WeaponRow(rule);
	}

	private bool WeaponRow(MonsterRule rule)
	{
		if (rule == null)
		{
			return false;
		}
		string weapon = rule.Weapon;
		WeaponKind weaponKind;
		if (string.IsNullOrEmpty(weapon) || weapon == "<AUTO>")
		{
			if (!rule.IsDefault && _s.DefaultRule.Weapon != "<AUTO>")
			{
				return WeaponRow(_s.DefaultRule);
			}
			weaponKind = ((!WantsVoid(rule)) ? _s.DefaultAttack : WeaponKind.Caster);
		}
		else if (weapon == "<ANY WAND>")
		{
			weaponKind = WeaponKind.Caster;
		}
		else if (weapon == "<ANY MELEE>")
		{
			weaponKind = WeaponKind.Melee;
		}
		else if (weapon == "<ANY MISSILE>")
		{
			weaponKind = WeaponKind.Missile;
		}
		else
		{
			weaponKind = _s.DefaultAttack;
			foreach (WeaponItem item in _s.Items)
			{
				if (!item.IsShield && !ItemInfo.IsSupply(item.Kind) && !IsAmmoItem(item) && NameIs(item, weapon))
				{
					weaponKind = item.Kind;
					break;
				}
			}
		}
		if (!rule.Magic)
		{
			return true;
		}
		return weaponKind == WeaponKind.Melee || weaponKind == WeaponKind.Missile;
	}

	private bool ForcedPrime(WorldObject mob)
	{
		if (mob == null)
		{
			return false;
		}
		if (WeaponRow(_s.FindRule(mob)))
		{
			return false;
		}
		if (_s.PrimeFocus && FocusId != 0 && mob.Id == FocusId)
		{
			return true;
		}
		if (Tracked.TryGetValue(mob.Id, out var value) && value.SpreadMissed)
		{
			return true;
		}
		if (_s.PrimeHigh)
		{
			MonsterRule monsterRule = _s.FindRule(mob);
			if (monsterRule != null && monsterRule.Priority >= Math.Max(1, _s.PrimeHighMin))
			{
				return true;
			}
		}
		return false;
	}

	private bool OwnPrimeWanted(TrackedMonster tm)
	{
		return _s.PrimeEveryNF && ServerMode.Ilt && tm != null && tm.GamePrimedAt == DateTime.MinValue && !tm.EverPrimed && !tm.FractureDone && tm.FractureCastAt == DateTime.MinValue;
	}

	private List<WorldObject> PrimeOrder(List<WorldObject> mobs)
	{
		WorldObject worldObject = null;
		int num = int.MinValue;
		DateTime dateTime = DateTime.MaxValue;
		double num2 = double.MaxValue;
		foreach (WorldObject mob in mobs)
		{
			TrackedMonster tracked = GetTracked(mob);
			if (!(tracked.DeadAt != DateTime.MinValue))
			{
				int priority = _s.FindRule(mob).Priority;
				DateTime dateTime2;
				if (tracked.GamePrimedAt != DateTime.MinValue)
				{
					dateTime2 = tracked.GamePrimedAt;
				}
				else
				{
					dateTime2 = (tracked.EverPrimed ? DateTime.MinValue.AddDays(1.0) : DateTime.MaxValue);
				}
				double num3 = Distance(mob);
				if (priority > num || (priority == num && (dateTime2 < dateTime || (dateTime2 == dateTime && num3 < num2))))
				{
					worldObject = mob;
					num = priority;
					dateTime = dateTime2;
					num2 = num3;
				}
			}
		}
		double x = 0.0;
		double y = 0.0;
		bool flag = worldObject != null && Pos(worldObject, out x, out y);
		List<KeyValuePair<WorldObject, double>> list = new List<KeyValuePair<WorldObject, double>>();
		List<WorldObject> list2 = new List<WorldObject>();
		foreach (WorldObject item in DebuffOrder(mobs))
		{
			TrackedMonster tracked2 = GetTracked(item);
			MonsterRule rule = _s.FindRule(item);
			if (OwnPrimeWanted(tracked2) && !tracked2.Deferred && FractureWanted(item, rule))
			{
				double value = ((!flag || !Pos(item, out var x2, out var y2)) ? Distance(item) : Math.Sqrt((x2 - x) * (x2 - x) + (y2 - y) * (y2 - y)));
				list.Add(new KeyValuePair<WorldObject, double>(item, value));
			}
			else
			{
				list2.Add(item);
			}
		}
		list.Sort((KeyValuePair<WorldObject, double> keyValuePair, KeyValuePair<WorldObject, double> keyValuePair2) =>
		{
			int priority2 = _s.FindRule(keyValuePair.Key).Priority;
			int priority3 = _s.FindRule(keyValuePair2.Key).Priority;
			if (priority2 != priority3)
			{
				return priority3.CompareTo(priority2);
			}
			bool flag2 = StartedPriming(GetTracked(keyValuePair.Key));
			bool flag3 = StartedPriming(GetTracked(keyValuePair2.Key));
			return (flag2 != flag3) ? ((!flag2) ? 1 : (-1)) : keyValuePair2.Value.CompareTo(keyValuePair.Value);
		});
		List<WorldObject> list3 = new List<WorldObject>();
		foreach (KeyValuePair<WorldObject, double> item2 in list)
		{
			list3.Add(item2.Key);
		}
		list3.AddRange(list2);
		return list3;
	}

	private bool FocusPrimeWanted(WorldObject mob, TrackedMonster tm)
	{
		if (!ForcedPrime(mob))
		{
			return false;
		}
		if (tm.GamePrimedAt != DateTime.MinValue || tm.FractureCastAt != DateTime.MinValue)
		{
			return false;
		}
		return _s.FractureReprime || !tm.FractureDone;
	}

	private static bool NoDots(TrackedMonster tm)
	{
		if (tm == null)
		{
			return true;
		}
		return !tm.Debuffs.ContainsKey(Slot.Corruption) && !tm.Debuffs.ContainsKey(Slot.DestructiveCurse) && !tm.Debuffs.ContainsKey(Slot.Corrosion);
	}

	private bool FractureWanted(WorldObject mob, MonsterRule rule)
	{
		if (!HasNF(rule))
		{
			return false;
		}
		TrackedMonster value = null;
		if (!_s.FractureReprime && Tracked.TryGetValue(mob.Id, out value) && value.FractureDone)
		{
			return false;
		}
		if (value == null)
		{
			Tracked.TryGetValue(mob.Id, out value);
		}
		if (NoDots(value) && (MonstersAround(mob, (_s.TrustSpreadM > 0f) ? _s.TrustSpreadM : 10f) == 0 || (_s.PrimeOnePerWand && _wandReleased.Contains(WandIdFor(mob)))))
		{
			TrackedMonster tracked = GetTracked(mob);
			if (!tracked.SpreadMissed)
			{
				tracked.SpreadMissed = true;
				Dbg("PRIME+ " + mob.Name + " [" + mob.Id + "]: no void DoT on it (on its own / the spread missed it) - all three DoTs and its own Nether Fracture");
			}
			return true;
		}
		if (_s.PrimeOnePerWand && !PrimeLeadOfItsWand(mob))
		{
			return false;
		}
		if (_forcedLead.ContainsValue(mob.Id))
		{
			return true;
		}
		if (!_s.FractureMinOn || MonstersAround(mob, 5.0) >= Math.Max(1, _s.FractureMin))
		{
			return true;
		}
		if (HasAttack(rule))
		{
			return false;
		}
		bool flag = value != null;
		Slot[] array = new Slot[3]
		{
			Slot.Corruption,
			Slot.DestructiveCurse,
			Slot.Corrosion
		};
		foreach (Slot slot in array)
		{
			if (rule.Has(slot))
			{
				return false;
			}
			if (value == null || !value.Debuffs.ContainsKey(slot))
			{
				flag = false;
			}
		}
		return !flag || !_s.StreakDotted;
	}

	public static void NoteHealth(int id, int cur, int max)
	{
		if (id == 0 || max <= 0 || cur < 0)
		{
			return;
		}
		lock (_hp)
		{
			_hp[id] = new Hp
			{
				Pct = 100.0 * (double)cur / (double)max,
				At = DateTime.Now
			};
		}
	}

	private void RePrimeTick(List<WorldObject> mobs)
	{
		if (!_s.PrimeOnePerWand || !_s.RePrimeFresh || _wandLead.Count == 0)
		{
			return;
		}
		DateTime now = DateTime.Now;
		foreach (KeyValuePair<int, WandLead> item in new List<KeyValuePair<int, WandLead>>(_wandLead))
		{
			WandLead value = item.Value;
			if (value.Done)
			{
				continue;
			}
			if (value.DeadAt == DateTime.MinValue)
			{
				if (Tracked.TryGetValue(value.LeadId, out var value2) && !(value2.DeadAt != DateTime.MinValue) && Globals.Core.WorldFilter[value.LeadId] != null)
				{
					continue;
				}
				value.DeadAt = now;
			}
			List<WorldObject> list = new List<WorldObject>();
			foreach (WorldObject mob in mobs)
			{
				if (mob.Id != value.LeadId && (!Tracked.TryGetValue(mob.Id, out var value3) || !(value3.DeadAt != DateTime.MinValue)) && HasNF(_s.FindRule(mob)) && WandIdFor(mob) == item.Key)
				{
					list.Add(mob);
				}
			}
			if (list.Count == 0)
			{
				value.Done = true;
				continue;
			}
			if (value.AskedAt == DateTime.MinValue)
			{
				value.AskedAt = now;
				foreach (WorldObject item2 in list)
				{
					try
					{
						Util.RequestId(item2.Id);
					}
					catch
					{
					}
				}
				continue;
			}
			bool flag = true;
			lock (_hp)
			{
				foreach (WorldObject item3 in list)
				{
					if (!_hp.TryGetValue(item3.Id, out var value4) || value4.At < value.AskedAt)
					{
						flag = false;
						break;
					}
				}
			}
			if (!flag && (now - value.AskedAt).TotalSeconds < 2.5)
			{
				continue;
			}
			value.Done = true;
			double num = Tuning.V("RePrimeUntouchedPct");
			double num2 = Tuning.V("RePrimePickPct");
			bool flag2 = false;
			WorldObject worldObject = null;
			double num3 = double.MaxValue;
			StringBuilder stringBuilder = new StringBuilder();
			lock (_hp)
			{
				foreach (WorldObject item4 in list)
				{
					if (_hp.TryGetValue(item4.Id, out var value5) && !(value5.At < value.AskedAt))
					{
						stringBuilder.Append((stringBuilder.Length > 0) ? ", " : "").Append(item4.Name).Append(' ')
							.Append(value5.Pct.ToString("0"))
							.Append('%');
						if (value5.Pct > num)
						{
							flag2 = true;
						}
						double num4 = Distance(item4);
						if (value5.Pct > num2 && num4 >= 0.0 && num4 < num3)
						{
							num3 = num4;
							worldObject = item4;
						}
					}
				}
			}
			if (!flag2 || worldObject == null)
			{
				Dbg("REPRIME no - prime died, its pack: " + ((stringBuilder.Length > 0) ? stringBuilder.ToString() : "health not known"));
				continue;
			}
			TrackedMonster tracked = GetTracked(worldObject);
			Slot[] array = new Slot[3]
			{
				Slot.Corruption,
				Slot.DestructiveCurse,
				Slot.Corrosion
			};
			foreach (Slot key in array)
			{
				tracked.Debuffs.Remove(key);
			}
			tracked.PrimedAt = DateTime.MinValue;
			tracked.FractureDone = false;
			_wandReleased.Remove(item.Key);
			_forcedLead[item.Key] = worldObject.Id;
			Dbg("REPRIME " + worldObject.Name + " [" + worldObject.Id + "] " + num3.ToString("0.0") + "m is the new prime - its pack: " + stringBuilder?.ToString() + " (DoTs on it cast again)");
		}
	}

	private int WandIdFor(WorldObject mob)
	{
		WorldObject dmgFor = _dmgFor;
		try
		{
			_dmgFor = mob;
			return WandFor(_s.FindRule(mob))?.Id ?? 0;
		}
		catch
		{
			return 0;
		}
		finally
		{
			_dmgFor = dmgFor;
		}
	}

	private static bool StartedPriming(TrackedMonster tm)
	{
		if (tm == null)
		{
			return false;
		}
		if (tm.GamePrimedAt != DateTime.MinValue || tm.FractureCastAt != DateTime.MinValue)
		{
			return true;
		}
		Slot[] array = new Slot[3]
		{
			Slot.Corruption,
			Slot.DestructiveCurse,
			Slot.Corrosion
		};
		foreach (Slot key in array)
		{
			if (tm.Debuffs.TryGetValue(key, out var value) && !value.FromSpread)
			{
				return true;
			}
		}
		return false;
	}

	private bool PrimeLeadOfItsWand(WorldObject mob)
	{
		int num = WandIdFor(mob);
		if (_wandReleased.Contains(num))
		{
			return false;
		}
		if (_forcedLead.TryGetValue(num, out var value))
		{
			if (Globals.Core.WorldFilter[value] != null && (!Tracked.TryGetValue(value, out var value2) || !(value2.DeadAt != DateTime.MinValue)))
			{
				return mob.Id == value;
			}
			_forcedLead.Remove(num);
		}
		WorldObject worldObject = null;
		int num2 = int.MinValue;
		double num3 = double.MaxValue;
		double num4 = AttackRangeNow;
		foreach (Mob item in HostilesNow())
		{
			double d = item.D;
			if (d < 0.0 || d > num4)
			{
				continue;
			}
			WorldObject worldObject2 = item.Get();
			if (worldObject2 == null)
			{
				continue;
			}
			Tracked.TryGetValue(worldObject2.Id, out var value3);
			if (value3 != null)
			{
				UpdateBlocked(worldObject2, value3);
			}
			else if (_s.SkipBehindWalls)
			{
				// (not tracked yet: its own entry on the first look, so the wall check - once a second - goes by it)
				value3 = GetTracked(worldObject2);
				UpdateBlocked(worldObject2, value3);
			}
			if ((value3 != null && value3.DeadAt != DateTime.MinValue) || (value3 != null && value3.Blocked && worldObject2.Id != FocusId))
			{
				continue;
			}
			MonsterRule monsterRule = _s.FindRule(worldObject2);
			if (monsterRule == null || monsterRule.Priority < 0)
			{
				continue;
			}
			bool flag = ForcedPrime(worldObject2);
			if ((HasNF(monsterRule) || flag) && WandIdFor(worldObject2) == num)
			{
				int num5 = (StartedPriming(value3) ? 1000000 : 0) + (flag ? 10000 : 0) + monsterRule.Priority;
				if (num5 > num2 || (num5 == num2 && d < num3))
				{
					num2 = num5;
					num3 = d;
					worldObject = worldObject2;
				}
			}
		}
		return worldObject == null || worldObject.Id == mob.Id;
	}

	private int MonstersAround(WorldObject mob, double r)
	{
		long tickStamp = TickStamp;
		if (_maTick != tickStamp)
		{
			_maMemo.Clear();
			_maTick = tickStamp;
		}
		KeyValuePair<int, double> key = new KeyValuePair<int, double>(mob.Id, r);
		if (_maMemo.TryGetValue(key, out var value))
		{
			return value;
		}
		value = MonstersAroundNow(mob, r);
		_maMemo[key] = value;
		return value;
	}

	private int MonstersAroundNow(WorldObject mob, double r)
	{
		if (!Pos(mob, out var x, out var y))
		{
			return 1;
		}
		int num = 0;
		foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
		{
			if (IsHostileMonster(item) && (item.Id == mob.Id || (Pos(item, out var x2, out var y2) && !(Math.Sqrt((x2 - x) * (x2 - x) + (y2 - y) * (y2 - y)) > r))))
			{
				num++;
			}
		}
		return num;
	}

	private void NotePrimeLine(string text)
	{
		if (!text.StartsWith("Your void enchantments prime ", StringComparison.OrdinalIgnoreCase))
		{
			return;
		}
		string text2 = text.Substring("Your void enchantments prime ".Length);
		int num = text2.IndexOf(". ", StringComparison.Ordinal);
		string text3 = ((num > 0) ? text2.Substring(0, num) : text2.TrimEnd('.')).Trim();
		TrackedMonster trackedMonster = null;
		if (Tracked.TryGetValue(_lastCastOn, out var value) && string.Equals(value.Name, text3, StringComparison.OrdinalIgnoreCase))
		{
			trackedMonster = value;
		}
		else
		{
			double num2 = double.MaxValue;
			foreach (TrackedMonster value2 in Tracked.Values)
			{
				if (string.Equals(value2.Name, text3, StringComparison.OrdinalIgnoreCase))
				{
					WorldObject worldObject = Globals.Core.WorldFilter[value2.Id];
					double num3 = ((worldObject != null) ? Distance(worldObject) : double.MaxValue);
					if (num3 < num2)
					{
						num2 = num3;
						trackedMonster = value2;
					}
				}
			}
		}
		if (trackedMonster != null)
		{
			trackedMonster.GamePrimedAt = DateTime.Now;
			trackedMonster.EverPrimed = true;
			Dbg("PRIME " + text3 + " [" + trackedMonster.Id + "] (the game says primed)");
		}
	}

	private bool OtherHeldNear(WorldObject mob, List<WorldObject> mobs)
	{
		if (!Pos(mob, out var x, out var y))
		{
			return true;
		}
		foreach (WorldObject mob2 in mobs)
		{
			if (mob2.Id != mob.Id && Dex.Held(mob2))
			{
				if (!Pos(mob2, out var x2, out var y2))
				{
					return true;
				}
				if (Math.Sqrt((x2 - x) * (x2 - x) + (y2 - y) * (y2 - y)) <= 7.0)
				{
					return true;
				}
			}
		}
		return false;
	}

	private bool DexNoHit(WorldObject m)
	{
		if (m == null)
		{
			return false;
		}
		if (Dex.Held(m) || PluginCore.IsPetOnly(m.Name))   // (pet-only monsters: only a pet can hurt them)
		{
			return true;
		}
		if (!Dex.HoldFracture)
		{
			return false;
		}
		TrackedMonster value;
		return Tracked.TryGetValue(m.Id, out value) && PrimedSince(value) != DateTime.MinValue;
	}

	private DateTime PrimedSince(TrackedMonster tm)
	{
		if (tm.GamePrimedAt == DateTime.MinValue)
		{
			tm.PrimedAt = DateTime.MinValue;
			return DateTime.MinValue;
		}
		return tm.GamePrimedAt;
	}

	private DateTime PrimedSinceOld(TrackedMonster tm)
	{
		DateTime dateTime = DateTime.MinValue;
		Slot[] array = new Slot[3]
		{
			Slot.Corruption,
			Slot.DestructiveCurse,
			Slot.Corrosion
		};
		foreach (Slot key in array)
		{
			if (!tm.Debuffs.TryGetValue(key, out var value) || value.ExpiresAt <= DateTime.Now)
			{
				tm.PrimedAt = DateTime.MinValue;
				return DateTime.MinValue;
			}
			if (value.AppliedAt > dateTime)
			{
				dateTime = value.AppliedAt;
			}
		}
		if (tm.PrimedAt == DateTime.MinValue)
		{
			tm.PrimedAt = dateTime;
		}
		return tm.PrimedAt;
	}

	public bool FractureState(TrackedMonster tm, out string text, out bool ready)
	{
		text = null;
		ready = false;
		try
		{
			WorldObject worldObject = Globals.Core.WorldFilter[tm.Id];
			if (worldObject == null || !HasNF(_s.FindRule(worldObject)))
			{
				return false;
			}
			if (tm.FractureDone && !_s.FractureReprime)
			{
				text = "NF done";
				return true;
			}
			if (tm.FractureCastAt != DateTime.MinValue)
			{
				text = "NF streaking";
				ready = true;
				return true;
			}
			DateTime dateTime = PrimedSince(tm);
			if (_s.FractureMinOn && MonstersAround(worldObject, 5.0) < Math.Max(1, _s.FractureMin))
			{
				text = "NF alone";
				return true;
			}
			if (dateTime == DateTime.MinValue)
			{
				return false;
			}
			double num = Math.Max((double)_s.FractureDelayS - (DateTime.Now - dateTime).TotalSeconds, FractureCooldownS - (DateTime.Now - tm.ReleasedAt).TotalSeconds);
			ready = num <= 0.0;
			text = (ready ? "NF ready" : ("NF " + Math.Ceiling(num).ToString("0") + "s"));
			return true;
		}
		catch
		{
			return false;
		}
	}

	private void FractureConfirmed(TrackedMonster tm)
	{
		tm.FractureCastAt = DateTime.MinValue;
		tm.GamePrimedAt = DateTime.MinValue;
		if (_pending != null && _pending.Streak && _pending.TargetId == tm.Id)
		{
			_pending = null;
			_nextCastAt = DateTime.Now + TimeSpan.FromMilliseconds(_s.CastRecoveryMs);
		}
		if (_s.FractureReprime)
		{
			tm.Debuffs.Remove(Slot.Corruption);
			tm.Debuffs.Remove(Slot.DestructiveCurse);
			tm.Debuffs.Remove(Slot.Corrosion);
			tm.PrimedAt = DateTime.MinValue;
		}
		else
		{
			tm.FractureDone = true;
		}
		try
		{
			WorldObject worldObject = Globals.Core.WorldFilter[tm.Id];
			if (worldObject != null)
			{
				int num = WandIdFor(worldObject);
				_wandReleased.Add(num);
				_wandLead[num] = new WandLead
				{
					LeadId = tm.Id
				};
				_forcedLead.Remove(num);
			}
		}
		catch
		{
		}
		Dbg("FRACT released on " + tm.Name + " [" + tm.Id + "]");
	}

	private void NoteFractureLine(string text)
	{
		Match match = StreakHitRx.Match(text);
		if (!match.Success)
		{
			return;
		}
		string b = match.Groups["who"].Value.Trim();
		TrackedMonster trackedMonster = null;
		foreach (TrackedMonster value in Tracked.Values)
		{
			if (value.FractureCastAt != DateTime.MinValue && (DateTime.Now - value.FractureCastAt).TotalSeconds <= 5.0 && string.Equals(value.Name, b, StringComparison.OrdinalIgnoreCase) && (trackedMonster == null || value.FractureCastAt > trackedMonster.FractureCastAt))
			{
				trackedMonster = value;
			}
		}
		if (trackedMonster != null)
		{
			FractureConfirmed(trackedMonster);
		}
	}

	private WorldObject FractureReady(List<WorldObject> mobs)
	{
		if (!ServerMode.Ilt)
		{
			return null;
		}
		foreach (TrackedMonster value in Tracked.Values)
		{
			if (value.FractureCastAt != DateTime.MinValue && (DateTime.Now - value.FractureCastAt).TotalSeconds > 4.0)
			{
				value.FractureCastAt = DateTime.MinValue;
				value.ReleasedAt = DateTime.MinValue;
				Dbg("FRACT the streak didn't hit " + value.Name + " [" + value.Id + "] - trying again");
			}
		}
		bool holdFracture = Dex.HoldFracture;
		foreach (WorldObject mob in mobs)
		{
			if (holdFracture && (!Dex.Held(mob) || OtherHeldNear(mob, mobs)))
			{
				continue;
			}
			MonsterRule rule = _s.FindRule(mob);
			bool flag = ForcedPrime(mob) || _forcedLead.ContainsValue(mob.Id);
			if (!HasNF(rule) && !flag)
			{
				continue;
			}
			TrackedMonster tracked = GetTracked(mob);
			if (!tracked.Blocked && (!tracked.FractureDone || _s.FractureReprime) && !(tracked.FractureCastAt != DateTime.MinValue) && !((DateTime.Now - tracked.ReleasedAt).TotalSeconds < FractureCooldownS))
			{
				DateTime dateTime = PrimedSince(tracked);
				if (!(dateTime == DateTime.MinValue) && !((DateTime.Now - dateTime).TotalSeconds < (double)_s.FractureDelayS) && (flag || !_s.FractureMinOn || MonstersAround(mob, 5.0) >= Math.Max(1, _s.FractureMin) || !HasAttack(rule)))
				{
					return mob;
				}
			}
		}
		return null;
	}

	private bool FractureRelease(List<WorldObject> mobs)
	{
		if (!ServerMode.Ilt)
		{
			return false;
		}
		WorldObject worldObject = FractureReady(mobs);
		using (List<WorldObject>.Enumerator enumerator = ((worldObject != null) ? new List<WorldObject> { worldObject } : new List<WorldObject>()).GetEnumerator())
		{
			if (enumerator.MoveNext())
			{
				WorldObject current = enumerator.Current;
				MonsterRule rule = _s.FindRule(current);
				TrackedMonster tracked = GetTracked(current);
				DateTime dateTime = PrimedSince(tracked);
				SpellLevel spellLevel = SpellBook.Resolve("StreakVoid", _s.Level1Void);
				if (spellLevel == null)
				{
					if (_loggedUnknown.Add("StreakVoid"))
					{
						Dbg("SKIP  Nether Fracture: no Nether Streak known");
					}
					return false;
				}
				_dmgFor = current;
				if (!EnsureCaster(rule, Slot.Corrosion))
				{
					return true;
				}
				if (!EnsureCombatMode(CombatState.Magic))
				{
					return true;
				}
				try
				{
					_lastCastSpell = spellLevel.Id;
Globals.Core.Actions.CastSpell(spellLevel.Id, current.Id);
					_lastCastSentAt = DateTime.Now;
					LastAttackAt = DateTime.Now;
					_fractureAt = DateTime.Now;
					tracked.ReleasedAt = DateTime.Now;
					Session.NoteFractureStreak();
					tracked.FractureCastAt = DateTime.Now;
					_pending = new PendingCast
					{
						TargetId = current.Id,
						TargetName = current.Name,
						Slot = null,
						Spell = spellLevel,
						At = DateTime.Now,
						Streak = true
					};
					WatchAttack(current);
					Status = "Nether Fracture: " + spellLevel.Name + " -> " + current.Name;
					Dbg("FRACT " + spellLevel.Name + " -> " + current.Name + " [" + current.Id + "] primed " + (DateTime.Now - dateTime).TotalSeconds.ToString("0.0") + "s, " + MonstersAround(current, 5.0) + " within 5 m");
				}
				catch (Exception ex)
				{
					Util.WriteToChat("Cast error: " + ex.Message);
				}
				return true;
			}
		}
		return false;
	}

	private void CastDebuff(WorldObject mob, Slot slot, SpellLevel spell)
	{
		if (!EnsureCombatMode(CombatState.Magic))
		{
			return;
		}
		try
		{
			_lastCastSpell = spell.Id;
Globals.Core.Actions.CastSpell(spell.Id, mob.Id);
			_lastCastSentAt = DateTime.Now;
			LastAttackAt = DateTime.Now;
			if (_lastMissed != null && _lastMissed.TargetId == mob.Id)
			{
				_lastMissed = null;
			}
			double num = Distance(mob);
			_pending = new PendingCast
			{
				TargetId = mob.Id,
				TargetName = mob.Name,
				Slot = slot,
				Spell = spell,
				At = DateTime.Now,
				Timeout = Tuning.Sec("CastTimeoutS")
			};
			_pending.HasPos = Pos(mob, out _pending.X, out _pending.Y);
			_lastCastOn = mob.Id;
			_lastCastAt = DateTime.Now;
			Status = "Casting " + spell.Name + " on " + mob.Name;
			Dbg("CAST  " + spell.Name + " (" + spell.Id + ") -> " + mob.Name + " [" + mob.Id + "] " + Distance(mob).ToString("0.0") + "m");
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Cast error: " + ex.Message);
		}
	}

	private static Slot? DotSlot(string spell)
	{
		if (spell.StartsWith("Corruption", StringComparison.OrdinalIgnoreCase))
		{
			return Slot.Corruption;
		}
		if (spell.StartsWith("Destructive Curse", StringComparison.OrdinalIgnoreCase))
		{
			return Slot.DestructiveCurse;
		}
		if (spell.StartsWith("Corrosion", StringComparison.OrdinalIgnoreCase))
		{
			return Slot.Corrosion;
		}
		return null;
	}

	private void NoteDotLine(string text)
	{
		if (!text.StartsWith("Your ", StringComparison.Ordinal))
		{
			return;
		}
		Match match = DotLineRx.Match(text);
		if (!match.Success)
		{
			return;
		}
		_dotLineAt = DateTime.Now;
		if (!_s.UseDotLines)
		{
			return;
		}
		Slot? slot = DotSlot(match.Groups["s"].Value.Trim());
		if (!slot.HasValue)
		{
			return;
		}
		string text2 = match.Groups["t"].Value.Trim();
		WorldObject worldObject = null;
		int num = 0;
		WorldObject worldObject2 = null;
		int num2 = 0;
		foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
		{
			if (string.Equals(item.Name, text2, StringComparison.OrdinalIgnoreCase) && IsHostileMonster(item))
			{
				worldObject = item;
				num++;
				if (Tracked.TryGetValue(item.Id, out var value) && value.Debuffs.ContainsKey(slot.Value))
				{
					worldObject2 = item;
					num2++;
				}
			}
		}
		WorldObject worldObject3;
		if (num == 1)
		{
			worldObject3 = worldObject;
		}
		else
		{
			worldObject3 = ((num2 == 1) ? worldObject2 : null);
		}
		if (worldObject3 == null)
		{
			if (num > 1 && _dotAmbiguousSaid.Add(text2))
			{
				Dbg("DOTLINE " + text2 + ": " + num + " of them around - can't tell which (left to the timers)");
			}
			return;
		}
		long key = ((long)worldObject3.Id << 8) | (long)slot.Value;
		if (_dotLast.TryGetValue(key, out var value2))
		{
			double totalSeconds = (DateTime.Now - value2).TotalSeconds;
			if (totalSeconds >= 0.8 && totalSeconds <= 12.0)
			{
				_dotGaps.Add(totalSeconds);
				if (_dotGaps.Count > 40)
				{
					_dotGaps.RemoveAt(0);
				}
			}
		}
		_dotLast[key] = DateTime.Now;
		if (_dotLast.Count > 400)
		{
			_dotLast.Clear();
		}
		TrackedMonster tracked = GetTracked(worldObject3);
		if (tracked.DeadAt != DateTime.MinValue)
		{
			return;
		}
		if (tracked.Debuffs.TryGetValue(slot.Value, out var value3))
		{
			value3.LineAt = DateTime.Now;
			if (value3.LineOnly)
			{
				value3.ExpiresAt = DateTime.Now.AddSeconds(DotLineQuietS + 1.0);
			}
		}
		else if (_s.TrustSpread)
		{
			tracked.Debuffs[slot.Value] = new ActiveDebuff
			{
				Slot = slot.Value,
				SpellName = match.Groups["s"].Value.Trim(),
				AppliedAt = DateTime.Now,
				ExpiresAt = DateTime.Now.AddSeconds(DotLineQuietS + 1.0),
				FromSpread = true,
				LineOnly = true,
				LineAt = DateTime.Now
			};
			if (tracked.EngagedAt == DateTime.MinValue && _s.TimerOnSpread)
			{
				tracked.EngagedAt = DateTime.Now;
			}
			Dbg("DOTLINE " + match.Groups["s"].Value.Trim() + " ticking on " + worldObject3.Name + " [" + worldObject3.Id + "] (spread) - counted as on");
		}
	}

	private void VerifySpread(List<WorldObject> mobs)
	{
		if (!_s.UseDotLines || (DateTime.Now - _dotLineAt).TotalSeconds > 10.0)
		{
			return;
		}
		foreach (WorldObject mob in mobs)
		{
			TrackedMonster tracked = GetTracked(mob);
			if (tracked.SpreadMissed || tracked.DeadAt != DateTime.MinValue || tracked.EverPrimed)
			{
				continue;
			}
			DateTime dateTime = DateTime.MaxValue;
			bool flag = false;
			bool flag2 = false;
			bool flag3 = false;
			Slot[] array = new Slot[3]
			{
				Slot.Corruption,
				Slot.DestructiveCurse,
				Slot.Corrosion
			};
			foreach (Slot key in array)
			{
				if (tracked.Debuffs.TryGetValue(key, out var value))
				{
					flag3 = true;
					if (!value.FromSpread)
					{
						flag = true;
					}
					if (value.LineAt != DateTime.MinValue || value.LineOnly)
					{
						flag2 = true;
					}
					if (value.AppliedAt < dateTime)
					{
						dateTime = value.AppliedAt;
					}
				}
			}
			if ((!flag3 | flag | flag2) || (DateTime.Now - dateTime).TotalSeconds < 5.0)
			{
				continue;
			}
			int num = 0;
			foreach (WorldObject mob2 in mobs)
			{
				if (string.Equals(mob2.Name, mob.Name, StringComparison.OrdinalIgnoreCase))
				{
					num++;
				}
			}
			if (num <= 1)
			{
				tracked.SpreadMissed = true;
				Slot[] array2 = new Slot[3]
				{
					Slot.Corruption,
					Slot.DestructiveCurse,
					Slot.Corrosion
				};
				foreach (Slot key2 in array2)
				{
					tracked.Debuffs.Remove(key2);
				}
				Dbg("SPREAD- " + mob.Name + " [" + mob.Id + "] " + Distance(mob).ToString("0.0") + "m: counted as reached, but no DoT of it ever ticked - priming it for its own Nether Fracture");
			}
		}
	}

	private void NoteSpreadLine(string text)
	{
		Match match = SpreadRx.Match(text);
		if (!match.Success)
		{
			return;
		}
		WorldObject worldObject = ((_lastLandId != 0 && (DateTime.Now - _lastLandAt).TotalSeconds < 3.0) ? Globals.Core.WorldFilter[_lastLandId] : null);
		if (worldObject == null)
		{
			Dbg("SPREAD " + match.Groups["n"].Value + " - didn't see which cast");
			return;
		}
		if (_s.TimerOnSpread)
		{
			SpreadTimers(worldObject);
		}
		List<int> list = TrustSpread(worldObject);
		int.TryParse(match.Groups["n"].Value, out var result);
		if (list != null && list.Count > 0)
		{
			SpreadCheck sc = _sc;
			if (sc != null && sc.SrcId == worldObject.Id)
			{
				sc.Due = DateTime.Now.AddSeconds(3.0);
				foreach (int item in list)
				{
					if (!sc.Ids.Contains(item))
					{
						sc.Ids.Add(item);
					}
				}
			}
			else
			{
				_sc = new SpreadCheck
				{
					Ids = list,
					N = result,
					At = DateTime.Now,
					Due = DateTime.Now.AddSeconds(3.0),
					SrcName = worldObject.Name,
					SrcId = worldObject.Id
				};
			}
			foreach (int item2 in list)
			{
				try
				{
					Util.RequestId(item2);
				}
				catch
				{
				}
			}
		}
		if (!_s.DebugLog && !LiveDebug)
		{
			return;
		}
		List<KeyValuePair<double, string>> list2 = new List<KeyValuePair<double, string>>();
		foreach (WorldObject item3 in Globals.Core.WorldFilter.GetLandscape())
		{
			if (item3.Id != worldObject.Id && IsHostileMonster(item3))
			{
				double num = DistanceBetween(worldObject, item3);
				if (num >= 0.0 && num <= 30.0)
				{
					list2.Add(new KeyValuePair<double, string>(num, item3.Name + " [" + item3.Id + "] " + num.ToString("0.0") + "m"));
				}
			}
		}
		list2.Sort((KeyValuePair<double, string> a, KeyValuePair<double, string> b) => a.Key.CompareTo(b.Key));
		Dbg("SPREAD " + match.Groups["n"].Value + " from " + _lastLandSpell + " on " + worldObject.Name + " [" + worldObject.Id + "]; around it: " + string.Join(", ", list2.ConvertAll((KeyValuePair<double, string> kv) => kv.Value).ToArray()));
	}

	private List<int> TrustSpread(WorldObject src)
	{
		double num = (_s.TrustSpread ? _s.TrustSpreadM : 0f);
		if (num <= 0.0 || !Tracked.TryGetValue(src.Id, out var value))
		{
			return null;
		}
		List<string> list = new List<string>();
		List<int> list2 = new List<int>();
		List<KeyValuePair<double, WorldObject>> list3 = new List<KeyValuePair<double, WorldObject>>();
		foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
		{
			if (item.Id != src.Id && IsHostileMonster(item))
			{
				double num2 = DistanceBetween(src, item);
				if (!(num2 < 0.0) && !(num2 > num))
				{
					list3.Add(new KeyValuePair<double, WorldObject>(num2, item));
				}
			}
		}
		list3.Sort((KeyValuePair<double, WorldObject> a, KeyValuePair<double, WorldObject> b) => a.Key.CompareTo(b.Key));
		if (_s.TrustSpreadMax > 0 && list3.Count > _s.TrustSpreadMax)
		{
			list3.RemoveRange(_s.TrustSpreadMax, list3.Count - _s.TrustSpreadMax);
		}
		foreach (KeyValuePair<double, WorldObject> item2 in list3)
		{
			WorldObject value2 = item2.Value;
			double key = item2.Key;
			list2.Add(value2.Id);
			TrackedMonster tracked = GetTracked(value2);
			bool flag = false;
			Slot[] array = new Slot[3]
			{
				Slot.Corruption,
				Slot.DestructiveCurse,
				Slot.Corrosion
			};
			foreach (Slot slot in array)
			{
				if (value.Debuffs.TryGetValue(slot, out var value3) && (!tracked.Debuffs.TryGetValue(slot, out var value4) || !(value4.ExpiresAt > DateTime.Now + TimeSpan.FromSeconds(30L))))
				{
					TimeSpan timeSpan = value3.ExpiresAt - value3.AppliedAt;
					tracked.Debuffs[slot] = new ActiveDebuff
					{
						Slot = slot,
						SpellName = value3.SpellName,
						AppliedAt = DateTime.Now,
						ExpiresAt = DateTime.Now + timeSpan,
						FromSpread = true
					};
					flag = true;
				}
			}
			if (flag)
			{
				list.Add(value2.Name + " [" + value2.Id + "] " + key.ToString("0.0") + "m");
			}
		}
		if (list.Count > 0)
		{
			Dbg("SPREAD+ counted its void DoTs as on: " + string.Join(", ", list.ToArray()));
		}
		return list2;
	}

	private void SpreadHealthTick()
	{
		SpreadCheck sc = _sc;
		if (sc == null)
		{
			return;
		}
		DateTime now = DateTime.Now;
		double totalSeconds = (now - sc.At).TotalSeconds;
		lock (_hp)
		{
			foreach (int id in sc.Ids)
			{
				if (!sc.Base.ContainsKey(id) && _hp.TryGetValue(id, out var value) && value.At > sc.At)
				{
					sc.Base[id] = value.Pct;
				}
			}
		}
		if (totalSeconds > 25.0)
		{
			_sc = null;
		}
		else
		{
			if (sc.AskedAt == DateTime.MinValue)
			{
				if (now < sc.Due)
				{
					return;
				}
				sc.AskedAt = now;
				{
					foreach (int id2 in sc.Ids)
					{
						try
						{
							Util.RequestId(id2);
						}
						catch
						{
						}
					}
					return;
				}
			}
			if ((now - sc.AskedAt).TotalSeconds < 1.2)
			{
				return;
			}
			_sc = null;
			List<KeyValuePair<double, int>> list = new List<KeyValuePair<double, int>>();
			List<string> list2 = new List<string>();
			foreach (int id3 in sc.Ids)
			{
				bool flag;
				Hp value2;
				lock (_hp)
				{
					flag = _hp.TryGetValue(id3, out value2) && value2.At > sc.AskedAt;
				}
				if (sc.Base.TryGetValue(id3, out var value3) && flag)
				{
					WorldObject worldObject = Globals.Core.WorldFilter[id3];
					if (worldObject != null)
					{
						list.Add(new KeyValuePair<double, int>(value3 - value2.Pct, id3));
						list2.Add(worldObject.Name + " " + value3.ToString("0.#") + "->" + value2.Pct.ToString("0.#") + "%");
					}
				}
			}
			Dbg("SPREAD? health around " + sc.SrcName + ": " + string.Join(", ", list2.ToArray()));
			list.Sort((KeyValuePair<double, int> a, KeyValuePair<double, int> b) => a.Key.CompareTo(b.Key));
			foreach (KeyValuePair<double, int> item in list)
			{
				if (item.Key > 0.5)
				{
					break;
				}
				WorldObject worldObject2 = Globals.Core.WorldFilter[item.Value];
				TrackedMonster tracked = GetTracked(worldObject2);
				if (tracked.SpreadMissed || tracked.EverPrimed)
				{
					continue;
				}
				tracked.SpreadMissed = true;
				Slot[] array = new Slot[3]
				{
					Slot.Corruption,
					Slot.DestructiveCurse,
					Slot.Corrosion
				};
				foreach (Slot key in array)
				{
					if (tracked.Debuffs.TryGetValue(key, out var value4) && value4.FromSpread)
					{
						tracked.Debuffs.Remove(key);
					}
				}
				Dbg("SPREAD- " + worldObject2.Name + " [" + worldObject2.Id + "]: its health didn't move - the spread missed it; DoTing it now");
			}
		}
	}

	private void SpreadTimers(WorldObject src)
	{
		double num = ((_s.TrustSpreadM > 0f) ? _s.TrustSpreadM : 10f);
		foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
		{
			if (item.Id == src.Id || !IsHostileMonster(item))
			{
				continue;
			}
			double num2 = DistanceBetween(src, item);
			if (!(num2 < 0.0) && !(num2 > num))
			{
				TrackedMonster tracked = GetTracked(item);
				if (tracked.EngagedAt == DateTime.MinValue)
				{
					tracked.EngagedAt = DateTime.Now;
				}
			}
		}
	}

	private static double DistanceBetween(WorldObject a, WorldObject b)
	{
		try
		{
			CoordsObject coordsObject = a.Coordinates();
			CoordsObject coordsObject2 = b.Coordinates();
			if (coordsObject == null || coordsObject2 == null)
			{
				return -1.0;
			}
			double num = (coordsObject.NorthSouth - coordsObject2.NorthSouth) * 240.0;
			double num2 = (coordsObject.EastWest - coordsObject2.EastWest) * 240.0;
			return Math.Sqrt(num * num + num2 * num2);
		}
		catch
		{
			return -1.0;
		}
	}

	private void ApplyLanded(PendingCast p)
	{
		if (p == null || !p.Slot.HasValue)
		{
			return;
		}
		_lastLandId = p.TargetId;
		_lastLandSpell = ((p.Spell != null) ? p.Spell.Name : "");
		_lastLandAt = DateTime.Now;
		if (Tracked.TryGetValue(p.TargetId, out var value))
		{
			TimeSpan timeSpan = SpellBook.Duration(p.Spell, _s);
			Dbg("LAND  " + p.Spell.Name + " -> " + p.TargetName + " [" + p.TargetId + "] after " + (DateTime.Now - p.At).TotalSeconds.ToString("0.00") + "s, tracking " + timeSpan.TotalSeconds.ToString("0") + "s");
			if (value.EngagedAt == DateTime.MinValue)
			{
				value.EngagedAt = DateTime.Now;
			}
			WorldObject worldObject = Globals.Core.WorldFilter[p.TargetId];
			if (worldObject != null && Pos(worldObject, out var x, out var y))
			{
				value.HasLand = true;
				value.LandX = x;
				value.LandY = y;
				value.LandDist = Distance(worldObject);
			}
			value.Debuffs[p.Slot.Value] = new ActiveDebuff
			{
				Slot = p.Slot.Value,
				SpellName = p.Spell.Name,
				AppliedAt = DateTime.Now,
				ExpiresAt = DateTime.Now + timeSpan
			};
			value.RetryAfter.Remove(p.Slot.Value);
			value.Misses = 0;
			value.Blocked = false;
			value.DeferUntil = DateTime.MinValue;
		}
	}

	private void ShelvePending()
	{
		if (_pending != null)
		{
			if (_pending.Slot.HasValue)
			{
				Dbg("SHELVE " + _pending.Spell.Name + " -> " + _pending.TargetName + " [" + _pending.TargetId + "] (heal/pause)");
				_lastMissed = _pending;
			}
			_pending = null;
		}
	}

	private void FailPending(bool timedOut)
	{
		PendingCast pending = _pending;
		_pending = null;
		if (pending != null && pending.Slot.HasValue)
		{
			Dbg((timedOut ? ("MISS  no 'You cast' in " + pending.Timeout.TotalSeconds.ToString("0.0") + "s: ") : "FAIL  ") + pending.Spell.Name + " -> " + pending.TargetName + " [" + pending.TargetId + "]");
			TrackedMonster value;
			if (timedOut)
			{
				_lastMissed = pending;
				NoteMiss(pending);
			}
			else if (Tracked.TryGetValue(pending.TargetId, out value))
			{
				value.RetryAfter[pending.Slot.Value] = DateTime.Now + FailBackoff;
			}
		}
	}

	private void NoteMiss(PendingCast p)
	{
		NoteMiss(p.TargetId, p.TargetName, p.HasPos, p.X, p.Y, "casts");
	}

	private void NoteMiss(int id, string name, bool hasPos, double px, double py, string what)
	{
		if (!Tracked.TryGetValue(id, out var value))
		{
			return;
		}
		value.Misses++;
		if (value.Misses >= 2)
		{
			value.Misses = 0;
			WorldObject worldObject = Globals.Core.WorldFilter[id];
			if (((worldObject != null) & hasPos) && Pos(worldObject, out var x, out var y) && Math.Sqrt((x - px) * (x - px) + (y - py) * (y - py)) < 2.0)
			{
				value.Blocked = true;
				value.BlockedAt = DateTime.Now;
				Pos(worldObject, out value.BlockX, out value.BlockY);
				Dbg("BLOCK " + name + " [" + id + "] - two " + what + " never reached it, not moving");
			}
			else
			{
				value.DeferUntil = DateTime.Now + Tuning.Sec("MovingDeferS");
				Dbg("DEFER " + name + " [" + id + "] - two " + what + " never reached it, moving");
			}
		}
	}

	private void NoteMissileMiss(int id, string name)
	{
		WorldObject worldObject = Globals.Core.WorldFilter[id];
		if (Tracked.TryGetValue(id, out var value) && worldObject != null && Pos(worldObject, out var x, out var y))
		{
			bool flag = value.MissileMisses > 0 && Math.Sqrt((x - value.MissileX) * (x - value.MissileX) + (y - value.MissileY) * (y - value.MissileY)) >= 1.5;
			if ((value.MissileMisses == 0) | flag)
			{
				value.MissileMisses = 0;
				value.MissileX = x;
				value.MissileY = y;
			}
			value.MissileMisses++;
			if (value.MissileMisses >= 3)
			{
				value.MissileMisses = 0;
				value.Blocked = true;
				value.BlockedAt = DateTime.Now;
				value.BlockX = x;
				value.BlockY = y;
				Dbg("BLOCK " + name + " [" + id + "] - three missiles hit the environment, not moving");
			}
		}
	}

	public void ResetMonster(int id)
	{
		if (Tracked.TryGetValue(id, out var value))
		{
			value.Debuffs.Clear();
			value.RetryAfter.Clear();
			value.EngagedAt = DateTime.MinValue;
			value.Misses = 0;
			value.MissileMisses = 0;
			value.Blocked = false;
			value.DeferUntil = DateTime.MinValue;
			_attackWatch.RemoveAll((AttackWatch w) => w.Id == id);
			if (_lastMissed != null && _lastMissed.TargetId == id)
			{
				_lastMissed = null;
			}
			Dbg("RESET " + value.Name + " [" + id + "] from the Tracking tab");
		}
	}

	public void ForgetDebuff(int id, Slot slot)
	{
		if (Tracked.TryGetValue(id, out var value))
		{
			value.Debuffs.Remove(slot);
			value.RetryAfter.Remove(slot);
		}
	}

	private void LandedOn(int id)
	{
		if (Tracked.TryGetValue(id, out var value))
		{
			if (value.EngagedAt == DateTime.MinValue)
			{
				value.EngagedAt = DateTime.Now;
			}
			value.Misses = 0;
			value.MissileMisses = 0;
			value.Blocked = false;
			value.DeferUntil = ((DateTime.Now < value.DeferUntil) ? DateTime.MinValue : value.DeferUntil);
		}
	}

	private void WatchAttack(WorldObject target)
	{
		foreach (AttackWatch item in _attackWatch)
		{
			if (item.Id == target.Id)
			{
				return;
			}
		}
		double num = Distance(target);
		double num2 = ((_pending != null && _pending.Spell != null && _pending.Spell.Name.IndexOf("Bolt", StringComparison.OrdinalIgnoreCase) >= 0) ? (1.0 / 12.0) : 0.05);
		AttackWatch attackWatch = new AttackWatch
		{
			Id = target.Id,
			Name = target.Name,
			Deadline = DateTime.Now + TimeSpan.FromSeconds(2.0 + ((num > 0.0) ? (num * num2) : 0.0))
		};
		attackWatch.HasPos = Pos(target, out attackWatch.X, out attackWatch.Y);
		_attackWatch.Add(attackWatch);
		if (_attackWatch.Count > 20)
		{
			_attackWatch.RemoveAt(0);
		}
	}

	private void ExpireAttackWatches()
	{
		for (int i = 0; i < _attackWatch.Count; i++)
		{
			AttackWatch attackWatch = _attackWatch[i];
			if (!(DateTime.Now < attackWatch.Deadline))
			{
				_attackWatch.RemoveAt(i--);
				if (Globals.Core.WorldFilter[attackWatch.Id] != null)
				{
					NoteMiss(attackWatch.Id, attackWatch.Name, attackWatch.HasPos, attackWatch.X, attackWatch.Y, "attack spells");
				}
			}
		}
	}

	private void CheckAttackLanded(string text)
	{
		if (_attackWatch.Count == 0 || (text.IndexOf(" point", StringComparison.OrdinalIgnoreCase) < 0 && text.IndexOf("resists your spell", StringComparison.OrdinalIgnoreCase) < 0 && text.IndexOf("evade", StringComparison.OrdinalIgnoreCase) < 0 && text.IndexOf("You killed", StringComparison.OrdinalIgnoreCase) < 0))
		{
			return;
		}
		for (int i = 0; i < _attackWatch.Count; i++)
		{
			if (text.IndexOf(_attackWatch[i].Name, StringComparison.OrdinalIgnoreCase) >= 0)
			{
				LandedOn(_attackWatch[i].Id);
				_attackWatch.RemoveAt(i);
				break;
			}
		}
	}

	private void CheckPetHit(string text)
	{
		Match match = PetHitRx.Match(text);
		if (!match.Success)
		{
			return;
		}
		string text2 = "";
		try
		{
			text2 = Globals.Core.CharacterFilter.Name ?? "";
		}
		catch
		{
		}
		string text3 = match.Groups["pet"].Value.Trim();
		if (text2.Length == 0 || !text3.StartsWith(text2 + "'s ", StringComparison.OrdinalIgnoreCase))
		{
			return;
		}
		string b = match.Groups["mob"].Value.Trim();
		WorldObject worldObject = null;
		try
		{
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				if (item.ObjectClass == ObjectClass.Monster && string.Equals(item.Name, text3, StringComparison.OrdinalIgnoreCase))
				{
					worldObject = item;
					break;
				}
			}
		}
		catch
		{
		}
		double x = 0.0;
		double y = 0.0;
		bool flag = worldObject != null && Pos(worldObject, out x, out y);
		TrackedMonster trackedMonster = null;
		double num = double.MaxValue;
		foreach (TrackedMonster value in Tracked.Values)
		{
			if (!string.Equals(value.Name, b, StringComparison.OrdinalIgnoreCase))
			{
				continue;
			}
			WorldObject worldObject2 = Globals.Core.WorldFilter[value.Id];
			if (worldObject2 != null)
			{
				double num2 = ((!flag || !Pos(worldObject2, out var x2, out var y2)) ? Distance(worldObject2) : Math.Sqrt((x2 - x) * (x2 - x) + (y2 - y) * (y2 - y)));
				if (num2 >= 0.0 && num2 < num)
				{
					num = num2;
					trackedMonster = value;
				}
			}
		}
		if (trackedMonster != null && trackedMonster.EngagedAt == DateTime.MinValue)
		{
			trackedMonster.EngagedAt = DateTime.Now;
		}
	}

	private static bool _wallCheckGone;

	private static bool _attackerGone;
	private static readonly Dictionary<uint, DateTime> _attackedBy = new Dictionary<uint, DateTime>();
	private static string _lastAttackers = "";

	// the monsters (of these) the server has named as attacking us in the last few seconds - empty: none, or a game
	// without that news. (With several hitting us the server's "attacker" flips between them each hit: all of them
	// count, and among them the usual order - distance, turning - decides, so the target doesn't flip with it.)
	private HashSet<int> AttackersAmong(List<KeyValuePair<double, WorldObject>> list)
	{
		HashSet<int> hashSet = new HashSet<int>();
		if (_attackerGone || !_s.PreferAttacker || list.Count < 2)
		{
			return hashSet;
		}
		try
		{
			DateTime now = DateTime.Now;
			uint g = AttackerGuidNow();
			if (g != 0)
			{
				_attackedBy[g] = now;
			}
			if (_attackedBy.Count == 0)
			{
				return hashSet;
			}
			List<uint> old = new List<uint>();
			foreach (KeyValuePair<uint, DateTime> item in _attackedBy)
			{
				if ((now - item.Value).TotalSeconds > 6.0)
				{
					old.Add(item.Key);
				}
			}
			foreach (uint key in old)
			{
				_attackedBy.Remove(key);
			}
			string names = "";
			foreach (KeyValuePair<double, WorldObject> item2 in list)
			{
#if RETAIL
				if (_attackedBy.ContainsKey(unchecked((uint)item2.Value.Id)))
#else
				if (_attackedBy.ContainsKey(ACGodot.DecalShim.Bridge.GuidOf(item2.Value.Id)))
#endif
				{
					hashSet.Add(item2.Value.Id);
					names = names + " " + item2.Value.Name + " [" + item2.Value.Id + "]";
				}
			}
			if (hashSet.Count == list.Count)
			{
				hashSet.Clear();   // (all of them on us: nothing to prefer)
				names = "";
			}
			if (names != _lastAttackers)
			{
				_lastAttackers = names;
				if (names.Length > 0)
				{
					Dbg("ATTACKERS" + names + " (the server says) - first among the same priority");
				}
			}
		}
		catch (MissingMemberException)
		{
			_attackerGone = true;   // (a game older than this build)
		}
		catch
		{
		}
		return hashSet;
	}

	private static uint AttackerGuidNow()
	{
#if RETAIL
		return 0u;   // (the retail client doesn't say who's attacking)
#else
		var net = ACGodot.DecalShim.Bridge.Host?.Net;
		return net == null ? 0u : net.CurrentAttacker;
#endif
	}

	// a straight line from us to it, through the world's walls and things (creatures - pets too - don't count): true
	// blocked, false clear, null can't tell (offline, the collision not loaded, a game without the check)
	private static bool? WallBetween(WorldObject mob, out string what)
	{
		what = "";
		if (_wallCheckGone)
		{
			return null;
		}
		try
		{
			return WallBetweenNow(mob, out what);
		}
		catch (MissingMemberException)
		{
			_wallCheckGone = true;   // (a game older than this build: no check to ask)
			return null;
		}
		catch
		{
			return null;
		}
	}

	private static bool? WallBetweenNow(WorldObject mob, out string what)
	{
		what = "";
#if RETAIL
		return null;   // (no line-of-sight check in the retail client)
#else
		var host = ACGodot.DecalShim.Bridge.Host;
		if (host?.ClearShot == null)
		{
			return null;
		}
		uint guid = ACGodot.DecalShim.Bridge.GuidOf(mob.Id);
		if (guid == 0)
		{
			return null;
		}
		var r = host.ClearShot(guid);
		if (r == null)
		{
			return null;
		}
		what = r.Value.what;
		return !r.Value.clear;
#endif
	}

	private void UpdateBlocked(WorldObject mob, TrackedMonster tm)
	{
		// behind a wall (checked about once a second): left alone till the line is clear - not fired at to find out
		if (_s.SkipBehindWalls && DateTime.Now >= tm.WallCheckAt)
		{
			tm.WallCheckAt = DateTime.Now.AddSeconds(1.0);
			bool? wall = WallBetween(mob, out var what);
			if (wall == true && !tm.WallBlocked)
			{
				tm.WallBlocked = true;
				tm.Blocked = true;
				tm.BlockedAt = DateTime.Now;
				Dbg("WALL  " + mob.Name + " [" + mob.Id + "] " + Distance(mob).ToString("0.0") + "m - " + what + ", skipped till it's clear");
			}
			else if (wall == false && tm.WallBlocked)
			{
				tm.WallBlocked = false;
				tm.Blocked = false;
				tm.Misses = 0;
				tm.MissileMisses = 0;
				Dbg("WALL  " + mob.Name + " [" + mob.Id + "] clear now");
			}
		}
		if (tm.WallBlocked)
		{
			return;
		}
		if (tm.Blocked && ((Pos(mob, out var x, out var y) && Math.Sqrt((x - tm.BlockX) * (x - tm.BlockX) + (y - tm.BlockY) * (y - tm.BlockY)) >= 2.0) || DateTime.Now - tm.BlockedAt > Tuning.Sec("BlockedForS")))
		{
			tm.Blocked = false;
			tm.Misses = 0;
		}
	}

	private void Attack(WorldObject target)
	{
		LastAttackAt = DateTime.Now;
		_dmgFor = target;
		MonsterRule monsterRule = _s.FindRule(target);
		WeaponItem weaponItem = ChooseWeapon(monsterRule);
		WeaponKind weaponKind = weaponItem?.Kind ?? _s.DefaultAttack;
		if (!monsterRule.Allows(weaponKind) && !HoldWeapon)
		{
			return;   // (nothing you carry can hurt it - its Attack on the Monsters tab)
		}
		if (weaponKind != WeaponKind.Caster && !monsterRule.Slots[(int)Slot.Arc])
		{
			return;   // (A unticked: no melee / missile attacks on it)
		}
		if (weaponItem != null && !IsWielded(weaponItem.Id))
		{
			Equip(weaponItem);
		}
		else
		{
			if (!EquipOffhand(monsterRule, weaponItem))
			{
				return;
			}
			switch (weaponKind)
			{
			case WeaponKind.Caster:
			{
				if (!EnsureCombatMode(CombatState.Magic))
				{
					return;
				}
				DmgType dmgType = ResolveDmg(monsterRule);
				if (dmgType == DmgType.Auto && weaponItem != null)
				{
					dmgType = weaponItem.Element;
				}
				if (dmgType == DmgType.Auto)
				{
					dmgType = DmgType.Void;
				}
				bool wantLevel = ((dmgType == DmgType.Void) ? _s.Level1Void : _s.Level1War);
				SpellLevel spellLevel = null;
				int num = (monsterRule.Has(Slot.Ring) ? CountMonstersNear(_s.RingRadius) : 0);
				bool flag = !monsterRule.Has(Slot.Arc) && !monsterRule.Has(Slot.Streak);
				if (monsterRule.Has(Slot.Ring) && (flag || num >= _s.RingMinMonsters))
				{
					spellLevel = SpellBook.ResolveRing(Slots.AttackFamilyKey("Ring", dmgType), _s.RingLevel1);
				}
				if (spellLevel == null && monsterRule.Has(Slot.Arc))
				{
					spellLevel = SpellBook.Resolve(Slots.AttackFamilyKey(_s.UseBolts ? "Bolt" : "Arc", dmgType), wantLevel);
				}
				if (spellLevel == null && monsterRule.Has(Slot.Streak))
				{
					spellLevel = SpellBook.Resolve(Slots.AttackFamilyKey("Streak", dmgType), wantLevel);
				}
				if (spellLevel == null && StreakablePrimed(target))
				{
					spellLevel = SpellBook.Resolve(Slots.AttackFamilyKey("Streak", DmgType.Void), _s.Level1Void);
				}
				if (spellLevel == null)
				{
					Status = ((monsterRule.Has(Slot.Arc) || monsterRule.Has(Slot.Ring) || monsterRule.Has(Slot.Streak)) ? ("No known " + dmgType.ToString() + " spell for the checked A/R/S") : ("Debuffs up on " + target.Name + " - A/R/S unchecked, not attacking"));
					return;
				}
				try
				{
					_lastCastSpell = spellLevel.Id;
Globals.Core.Actions.CastSpell(spellLevel.Id, target.Id);
					_lastCastSentAt = DateTime.Now;
					Dbg("ATK   " + spellLevel.Name + " -> " + target.Name + " [" + target.Id + "]");
					_pending = new PendingCast
					{
						TargetId = target.Id,
						TargetName = target.Name,
						Slot = null,
						Spell = spellLevel,
						At = DateTime.Now
					};
					WatchAttack(target);
					Status = "Attacking " + target.Name + " with " + spellLevel.Name;
					return;
				}
				catch (Exception ex)
				{
					Util.WriteToChat("Cast error: " + ex.Message);
					return;
				}
			}
			case WeaponKind.Missile:
				if (weaponItem != null && !EnsureAmmo(weaponItem))
				{
					return;
				}
				break;
			}
			if (!EnsureCombatMode((weaponKind == WeaponKind.Melee) ? CombatState.Melee : CombatState.Missile))
			{
				return;
			}
			try
			{
				if (Globals.Core.Actions.CurrentSelection != target.Id)
				{
					Globals.Core.Actions.SelectItem(target.Id);
				}
			}
			catch
			{
			}
			DateTime dateTime = ((_lastPhysActivity > _physSentAt) ? _lastPhysActivity : _physSentAt);
			if (_physTargetId != target.Id || DateTime.Now - dateTime > Tuning.Sec("PhysStaleS"))
			{
				SendPhysicalAttack(target, weaponKind);
			}
			Status = "Attacking " + target.Name + " (" + weaponKind.ToString() + ")";
		}
	}

	private DmgType ResolveDmg(MonsterRule rule)
	{
		if (rule.Dmg != DmgType.Auto)
		{
			return rule.Dmg;
		}
		// (the default row's element is for your default attack: a monster that attack can't hurt - magic-immune, with
		// a wand default - gets the species' best element among the weapons it can be hit with instead)
		bool forcedOff = !rule.IsDefault && !rule.Allows(_s.DefaultAttack);
		if (_s.DefaultRule.Dmg != DmgType.Auto && !(forcedOff && _s.AutoElementBySpecies && _dmgFor != null && GameInfo.Ranking(_dmgFor).Count > 0))
		{
			return _s.DefaultRule.Dmg;
		}
		if (!_s.AutoElementBySpecies || _dmgFor == null)
		{
			return DmgType.Auto;
		}
		if (AutoPick(rule, out _, out DmgType picked))
		{
			DmgType item = picked;
			{
				if (!_autoDmgSaid.TryGetValue(_dmgFor.Id, out var value) || value != item)
				{
					_autoDmgSaid[_dmgFor.Id] = item;
					if (_autoDmgSaid.Count > 300)
					{
						_autoDmgSaid.Clear();
					}
					Dbg("ELEM  " + _dmgFor.Name + " [" + _dmgFor.Id + "] species " + GameInfo.Species(_dmgFor) + " -> " + item);
				}
				return item;
			}
		}
		return DmgType.Auto;
	}

	// the kinds an <AUTO> weapon may be: your default attack first, then - for melee and missile - the other of the two
	// (when the monster's rule allows it), so a monster resisting your melee weapon's element gets a bow of one it doesn't
	private List<WeaponKind> AutoKinds(MonsterRule rule)
	{
		WeaponKind k = PlainKind(rule);
		List<WeaponKind> list = new List<WeaponKind> { k };
		string w = rule.Weapon;
		if ((string.IsNullOrEmpty(w) || w == "<AUTO>") && (rule.IsDefault || _s.DefaultRule.Weapon == "<AUTO>") && _s.AutoSwitchMeleeMissile)
		{
			WeaponKind other = k == WeaponKind.Melee ? WeaponKind.Missile : k == WeaponKind.Missile ? WeaponKind.Melee : k;
			if (other != k && rule.Allows(other))
			{
				list.Add(other);
			}
		}
		return list;
	}

	/// <summary>Auto damage: the best element in the species' ranking that a weapon you carry does, and that weapon's kind.</summary>
	private bool AutoPick(MonsterRule rule, out WeaponKind kind, out DmgType dmg)
	{
		kind = PlainKind(rule);
		dmg = DmgType.Auto;
		if (_dmgFor == null)
		{
			return false;
		}
		List<WeaponKind> kinds = AutoKinds(rule);
		foreach (DmgType item in GameInfo.Ranking(_dmgFor))
		{
			foreach (WeaponKind k in kinds)
			{
				foreach (WeaponItem item2 in _s.Items)
				{
					if (item2.IsShield || item2.Kind != k || item2.Element != item || IsAmmoItem(item2) || !InInventory(item2.Id))
					{
						continue;
					}
					kind = k;
					dmg = item;
					return true;
				}
			}
		}
		return false;
	}

	private bool PetCall(ref MethodInfo mi, string name)
	{
		try
		{
			if (mi == null)
			{
				if ((DateTime.Now - _petWantedLookAt).TotalSeconds < 30.0)
				{
					return false;
				}
				_petWantedLookAt = DateTime.Now;
				Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
				foreach (Assembly assembly in assemblies)
				{
					Type type = assembly.GetType("MelksPetSummoner.PluginCore");
					if (!(type == null))
					{
						mi = type.GetMethod(name, BindingFlags.Static | BindingFlags.Public);
						break;
					}
				}
				if (mi == null)
				{
					return false;
				}
			}
			object obj = mi.Invoke(null, null);
			return obj is bool && (bool)obj;
		}
		catch
		{
			return false;
		}
	}

	private bool PetDeviceBusy()
	{
		try
		{
			if (_petBusy == null)
			{
				if ((DateTime.Now - _petBusyLookAt).TotalSeconds < 30.0)
				{
					return false;
				}
				_petBusyLookAt = DateTime.Now;
				Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
				foreach (Assembly assembly in assemblies)
				{
					Type type = assembly.GetType("MelksPetSummoner.PluginCore");
					if (!(type == null))
					{
						_petBusy = type.GetMethod("DeviceBusy", BindingFlags.Static | BindingFlags.Public);
						break;
					}
				}
				if (_petBusy == null)
				{
					return false;
				}
			}
			object obj = _petBusy.Invoke(null, null);
			return obj is bool && (bool)obj;
		}
		catch
		{
			return false;
		}
	}

	private WeaponItem WieldedItem()
	{
		long tickStamp = TickStamp;
		if (_wiHas && _wiTick == tickStamp)
		{
			return _wiItem;
		}
		WeaponItem weaponItem = WieldedItemNow();
		_wiTick = tickStamp;
		_wiItem = weaponItem;
		_wiHas = true;
		return weaponItem;
	}

	private WeaponItem WieldedItemNow()
	{
		foreach (WeaponItem item in _s.Items)
		{
			if (!item.IsShield && !ItemInfo.IsSupply(item.Kind) && !IsAmmoItem(item) && IsWielded(item.Id))
			{
				return item;
			}
		}
		try
		{
			foreach (WorldObject item2 in InvCache.All())
			{
				if ((item2.ObjectClass != ObjectClass.MeleeWeapon && item2.ObjectClass != ObjectClass.MissileWeapon && item2.ObjectClass != ObjectClass.WandStaffOrb) || ItemInfo.IsAmmo(item2) || !IsWielded(item2.Id))
				{
					continue;
				}
				WeaponKind kind = ((item2.ObjectClass != ObjectClass.WandStaffOrb) ? ((item2.ObjectClass != ObjectClass.MissileWeapon) ? WeaponKind.Melee : WeaponKind.Missile) : WeaponKind.Caster);
				return new WeaponItem
				{
					Id = item2.Id,
					Name = ItemReport.FullName(item2),
					Kind = kind
				};
			}
		}
		catch
		{
		}
		return null;
	}

	private readonly HashSet<int> _immuneSaid = new HashSet<int>();

	private WeaponItem ChooseWeapon(MonsterRule rule)
	{
		long tickStamp = TickStamp;
		if (_cwTick != tickStamp)
		{
			_cwMemo.Clear();
			_cwTick = tickStamp;
		}
		KeyValuePair<MonsterRule, int> key = new KeyValuePair<MonsterRule, int>(rule, _dmgForId);
		if (_cwMemo.TryGetValue(key, out var value))
		{
			return value;
		}
		value = AllowedWeapon(rule, ChooseWeaponNow(rule));
		_cwMemo[key] = value;
		return value;
	}

	// the kind a rule's weapon setting asks for (<AUTO>: your default attack), moved to one it allows when it doesn't
	private WeaponKind PlainKind(MonsterRule rule)
	{
		string w = rule.Weapon;
		if ((string.IsNullOrEmpty(w) || w == "<AUTO>") && !rule.IsDefault && _s.DefaultRule.Weapon != "<AUTO>")
		{
			w = _s.DefaultRule.Weapon;
		}
		WeaponKind k = w == "<ANY WAND>" ? WeaponKind.Caster : w == "<ANY MELEE>" ? WeaponKind.Melee : w == "<ANY MISSILE>" ? WeaponKind.Missile : _s.DefaultAttack;
		if (rule.Allows(k))
		{
			return k;
		}
		foreach (WeaponKind k2 in new[] { WeaponKind.Melee, WeaponKind.Missile, WeaponKind.Caster })
		{
			if (rule.Allows(k2) && CarriesKind(k2))
			{
				return k2;
			}
		}
		return k;
	}

	private bool CarriesKind(WeaponKind k)
	{
		foreach (WeaponItem item in _s.Items)
		{
			if (!item.IsShield && item.Kind == k && !IsAmmoItem(item) && InInventory(item.Id))
			{
				return true;
			}
		}
		return false;
	}

	/// <summary>Something you carry can hurt it (its rule's Attack: magic / melee / missile).</summary>
	private bool CanHurt(MonsterRule rule)
	{
		if (rule == null || rule.AllAttacks)
		{
			return true;
		}
		return (rule.Magic && CarriesKind(WeaponKind.Caster)) || (rule.Melee && CarriesKind(WeaponKind.Melee)) || (rule.Missile && CarriesKind(WeaponKind.Missile));
	}

	// the weapon chosen, or - when the monster can't be hurt by its kind - the best one of a kind that can
	private WeaponItem AllowedWeapon(MonsterRule rule, WeaponItem w)
	{
		if (rule == null || rule.AllAttacks || HoldWeapon)
		{
			return w;
		}
		WeaponKind have = w?.Kind ?? _s.DefaultAttack;
		if (rule.Allows(have))
		{
			return w;
		}
		DmgType dmg = ResolveDmg(rule);
		foreach (WeaponKind k in new[] { _s.DefaultAttack, WeaponKind.Melee, WeaponKind.Missile, WeaponKind.Caster })
		{
			if (!rule.Allows(k))
			{
				continue;
			}
			WeaponItem other = BestFor(k, dmg, _dmgFor) ?? BestFor(k, DmgType.Auto, _dmgFor);
			if (other != null)
			{
				return other;
			}
		}
		return null;
	}

	private WeaponItem ChooseWeaponNow(MonsterRule rule)
	{
		if (HoldWeapon)
		{
			WeaponItem weaponItem = WieldedItem();
			if (weaponItem != null)
			{
				return weaponItem;
			}
		}
		string weapon = rule.Weapon;
		if (string.IsNullOrEmpty(weapon) || weapon == "<AUTO>")
		{
			if (!rule.IsDefault && _s.DefaultRule.Weapon != "<AUTO>")
			{
				return ChooseWeapon(_s.DefaultRule);
			}
			if (WantsVoid(rule))
			{
				return BestFor(WeaponKind.Caster, DmgType.Void, _dmgFor) ?? BestFor(_s.DefaultAttack, ResolveDmg(rule), _dmgFor);
			}
			// (auto damage: the weapon - melee or bow - of the best element for it you carry)
			if (rule.Dmg == DmgType.Auto && (_s.DefaultRule.Dmg == DmgType.Auto || !rule.Allows(_s.DefaultAttack)) && _s.AutoElementBySpecies && AutoPick(rule, out WeaponKind ak, out DmgType ad))
			{
				return BestFor(ak, ad, _dmgFor) ?? BestFor(_s.DefaultAttack, ad, _dmgFor);
			}
			return BestFor(_s.DefaultAttack, ResolveDmg(rule), _dmgFor);
		}
		if (weapon == "<ANY WAND>")
		{
			return BestFor(WeaponKind.Caster, WantsVoid(rule) ? DmgType.Void : ResolveDmg(rule), _dmgFor);
		}
		if (weapon == "<ANY MELEE>" || weapon == "<ANY MISSILE>")
		{
			WeaponKind k = weapon == "<ANY MELEE>" ? WeaponKind.Melee : WeaponKind.Missile;
			return BestFor(k, ResolveDmg(rule), _dmgFor) ?? BestFor(k, DmgType.Auto, _dmgFor);
		}
		foreach (WeaponItem item in _s.Items)
		{
			if (!item.IsShield && !ItemInfo.IsSupply(item.Kind) && !IsAmmoItem(item) && NameIs(item, weapon) && InInventory(item.Id))
			{
				return item;
			}
		}
		return BestItem(_s.DefaultAttack, ResolveDmg(rule));
	}

	private static bool NameIs(WeaponItem i, string name)
	{
		if (string.Equals(i.Name, name, StringComparison.OrdinalIgnoreCase))
		{
			return true;
		}
		WorldObject worldObject = Globals.Core.WorldFilter[i.Id];
		return worldObject != null && string.Equals(worldObject.Name, name, StringComparison.OrdinalIgnoreCase);
	}

	private bool WantsVoid(MonsterRule rule)
	{
		return rule != null && (rule.Has(Slot.Corruption) || rule.Has(Slot.DestructiveCurse) || rule.Has(Slot.Corrosion) || NFTicked(rule));
	}

	private WeaponItem BestFor(WeaponKind kind, DmgType dmg, WorldObject mob)
	{
		int num = 0;
		try
		{
			if (mob != null)
			{
				num = GameInfo.Species(mob);
			}
		}
		catch
		{
		}
		WeaponItem weaponItem = null;
		WeaponItem weaponItem2 = null;
		WeaponItem weaponItem3 = null;
		double num2 = double.MinValue;
		double num3 = double.MinValue;
		WeaponItem weaponItem4 = WieldedItem();
		StringBuilder stringBuilder = new StringBuilder();
		foreach (WeaponItem item2 in _s.Items)
		{
			if (item2.IsShield || item2.Kind != kind || !InInventory(item2.Id) || IsAmmoItem(item2))
			{
				continue;
			}
			WorldObject worldObject = Globals.Core.WorldFilter[item2.Id];
			bool flag = dmg == DmgType.Auto || item2.Element == dmg || item2.Element == DmgType.Auto;
			double num4 = (flag ? 1000000.0 : 0.0);
			if (item2.CompareTo & flag)
			{
				weaponItem3 = item2;
			}
			double num5 = 1.0;
			double mult = 1.0;
			bool flag2 = ((num > 0) & flag) && SlaysSpecies(item2, worldObject, num, out mult);
			if (flag2)
			{
				num5 *= mult;
			}
			double num6 = ((worldObject != null) ? LootMatcher.Dbl(worldObject, 152) : 0.0);
			if (num6 > 0.0)
			{
				num5 *= num6;
			}
			num4 += num5 * 1000.0;
			if (weaponItem4 != null && weaponItem4.Id == item2.Id)
			{
				num4 += 0.5;
			}
			if (flag2)
			{
				if (num4 > num2)
				{
					num2 = num4;
					weaponItem = item2;
				}
			}
			else if (num4 > num3)
			{
				num3 = num4;
				weaponItem2 = item2;
			}
			if (flag && (flag2 || item2.CompareTo))
			{
				stringBuilder.Append((stringBuilder.Length > 0) ? ", " : "").Append(item2.Name).Append(flag2 ? (" slayer x" + mult.ToString("0.##")) : "")
					.Append((num6 > 0.0) ? (" vs x" + num6.ToString("0.##")) : "");
			}
		}
		WeaponItem weaponItem5 = weaponItem ?? weaponItem3 ?? weaponItem2;
		string item = num + "|" + (weaponItem5?.Id ?? 0);
		if (mob != null && _bestForLogged.Add(item))
		{
			Dbg("WAND  " + mob.Name + " (species " + num + " " + MonsterMatch.SpeciesName(num) + "): " + ((weaponItem5 != null) ? weaponItem5.Name : "none") + "  [" + stringBuilder?.ToString() + "]");
		}
		return weaponItem5;
	}

	private static bool SlaysSpecies(WeaponItem i, WorldObject o, int species, out double mult)
	{
		mult = 1.0;
		try
		{
			string text = ((o != null) ? (LootMatcher.Str(o, 16) ?? "").Replace("\r", "") : "");
			Match match = SlayerTextRx.Match(text);
			if (o != null && LootMatcher.Long(o, 166) == species)
			{
				double num = LootMatcher.Dbl(o, 138);
				if (num <= 1.0 && match.Success && double.TryParse(match.Groups["x"].Value, NumberStyles.Float, CultureInfo.InvariantCulture, out var result))
				{
					num = result;
				}
				mult = ((num > 1.0) ? num : 1.5);
				return true;
			}
			if (match.Success)
			{
				if (MonsterMatch.SpeciesId(match.Groups["sp"].Value) != species)
				{
					return false;
				}
				mult = ((double.TryParse(match.Groups["x"].Value, NumberStyles.Float, CultureInfo.InvariantCulture, out var result2) && result2 > 1.0) ? result2 : 1.2);
				return true;
			}
			Match match2 = SlayerLabelRx.Match(i.Name ?? "");
			if (text.Length == 0 && match2.Success && MonsterMatch.SpeciesId(match2.Groups["sp"].Value) == species)
			{
				mult = 1.2;
				return true;
			}
		}
		catch
		{
		}
		return false;
	}

	private WeaponItem BestItem(WeaponKind kind, DmgType dmg)
	{
		WeaponItem weaponItem = null;
		foreach (WeaponItem item in _s.Items)
		{
			if (!item.IsShield && item.Kind == kind && InInventory(item.Id) && !IsAmmoItem(item))
			{
				if (dmg != DmgType.Auto && item.Element == dmg)
				{
					return item;
				}
				if (weaponItem == null)
				{
					weaponItem = item;
				}
			}
		}
		return weaponItem;
	}

	private WeaponItem WandFor(MonsterRule rule)
	{
		WeaponItem weaponItem = ChooseWeapon(rule);
		if (weaponItem != null && weaponItem.Kind == WeaponKind.Caster)
		{
			return weaponItem;
		}
		return BestFor(WeaponKind.Caster, WantsVoid(rule) ? DmgType.Void : ResolveDmg(rule), _dmgFor);
	}

	private bool CastableInHand(MonsterRule rule, Slot slot)
	{
		WeaponItem weaponItem = WieldedItem();
		if (weaponItem == null || weaponItem.Kind != WeaponKind.Caster)
		{
			return false;
		}
		if (!Slots.IsDot(slot))
		{
			return true;
		}
		WeaponItem weaponItem2 = WandFor(rule);
		return weaponItem2 == null || weaponItem2.Id == weaponItem.Id;
	}

	private bool EnsureCaster(MonsterRule rule, Slot slot)
	{
		if (HoldWeapon)
		{
			return true;
		}
		if (_s.FewerWeaponSwaps && CastableInHand(rule, slot))
		{
			return true;
		}
		WeaponItem weaponItem = WandFor(rule);
		if (weaponItem == null)
		{
			return true;
		}
		if (!IsWielded(weaponItem.Id))
		{
			Equip(weaponItem);
			return false;
		}
		return true;
	}

	private bool EnsureAmmo(WeaponItem weapon)
	{
		int num = ItemInfo.MissileType(weapon.Id);
		if (num == 0)
		{
			return true;
		}
		// the arrows (bolts, darts) for this weapon - of its own element first (a void bow shot fire arrows, the first listed)
		WeaponItem weaponItem = null;
		WeaponItem inHand = null;
		foreach (WeaponItem item in _s.Items)
		{
			if (IsAmmoItem(item) && InInventory(item.Id) && ItemInfo.MissileType(item.Id) == num)
			{
				if (IsWielded(item.Id) || item.Id == _ammoEquippedId)
				{
					inHand = item;
				}
				if (weaponItem == null || (weaponItem.Element != weapon.Element && item.Element == weapon.Element))
				{
					weaponItem = item;
				}
			}
		}
		// (what's in hand will do: it's the weapon's element, or nothing listed is)
		if (inHand != null && (inHand.Element == weapon.Element || weaponItem == null || weaponItem.Element != weapon.Element))
		{
			return true;
		}
		if (weaponItem == null)
		{
			return true;
		}
		if (inHand != null)
		{
			Dbg("AMMO " + inHand.Name + " (" + inHand.Element + ") in hand for " + weapon.Name + " (" + weapon.Element + ") - swapping to " + weaponItem.Name);
		}
		if (Equip(weaponItem))
		{
			_ammoEquippedId = weaponItem.Id;
		}
		return false;
	}

	private static bool IsAmmoItem(WeaponItem i)
	{
		if (i.Kind == WeaponKind.Ammo)
		{
			return true;
		}
		if (i.Kind != WeaponKind.Missile)
		{
			return false;
		}
		try
		{
			return ItemInfo.IsAmmo(Globals.Core.WorldFilter[i.Id]);
		}
		catch
		{
			return false;
		}
	}

	private static int SlotVal(int id, LongValueKey k)
	{
		try
		{
			return Globals.Core.WorldFilter[id]?.Values(k, 0) ?? 0;
		}
		catch
		{
			return 0;
		}
	}

	public static bool IsTwoHanded(int id)
	{
		int num = SlotVal(id, LongValueKey.EquipableSlots);
		return (num & 0x2000000) != 0 && (num & 0x100000) == 0;
	}

	private static int InOffHand()
	{
		try
		{
			int id = Globals.Core.CharacterFilter.Id;
			foreach (WorldObject item in InvCache.All())
			{
				if (item.Values(LongValueKey.Wielder, 0) == id && (item.Values(LongValueKey.EquippedSlots, 0) & 0x200000) != 0)
				{
					return item.Id;
				}
			}
		}
		catch
		{
		}
		return 0;
	}

	private WeaponItem OffhandWeapon(string o, WeaponItem main)
	{
		if (main == null || main.Kind != WeaponKind.Melee || IsTwoHanded(main.Id))
		{
			return null;
		}
		WeaponItem weaponItem = null;
		foreach (WeaponItem item in _s.Items)
		{
			if (item.IsShield || item.Kind != WeaponKind.Melee || item.Id == main.Id || !InInventory(item.Id) || IsTwoHanded(item.Id))
			{
				continue;
			}
			if (o == "<AUTO OFFHAND>")
			{
				if (weaponItem == null || (item.Element == main.Element && weaponItem.Element != main.Element))
				{
					weaponItem = item;
				}
			}
			else if (NameIs(item, o))
			{
				return item;
			}
		}
		return weaponItem;
	}

	private bool EquipOffhand(MonsterRule rule, WeaponItem weapon)
	{
		string offhand = rule.Offhand;
		if (string.IsNullOrEmpty(offhand) || offhand == "<AUTO>" || offhand == "<NONE>")
		{
			return true;
		}
		if (weapon != null && weapon.Kind == WeaponKind.Missile)
		{
			return true;
		}
		WeaponItem weaponItem = null;
		foreach (WeaponItem item in _s.Items)
		{
			if (!item.IsShield || !InInventory(item.Id) || (!(offhand == "<AUTO SHIELD>") && !NameIs(item, offhand)))
			{
				continue;
			}
			weaponItem = item;
			break;
		}
		if (weaponItem == null)
		{
			WeaponItem weaponItem2 = OffhandWeapon(offhand, weapon);
			return weaponItem2 == null || EquipOff(weaponItem2);
		}
		if (IsWielded(weaponItem.Id))
		{
			return true;
		}
		Equip(weaponItem);
		return false;
	}

	private bool EquipOff(WeaponItem off)
	{
		if ((SlotVal(off.Id, LongValueKey.EquippedSlots) & 0x200000) != 0 && IsWielded(off.Id))
		{
			_offTries = 0;
			return true;
		}
		if (DateTime.Now < _offGiveUpUntil)
		{
			return true;
		}
		if (DateTime.Now < _equipWaitUntil || DateTime.Now < _modeWaitUntil)
		{
			return false;
		}
		try
		{
			if (Globals.Core.Actions.CombatMode != CombatState.Peace)
			{
				Status = "Equipping " + off.Name + " (off hand) - entering peace mode";
				Globals.Core.Actions.SetCombatMode(CombatState.Peace);
				_equipWaitUntil = DateTime.Now + Tuning.Ms("EquipWaitMs");
				return false;
			}
			int num = InOffHand();
			if (num != 0 && num != off.Id)
			{
				Status = "Clearing the off hand for " + off.Name;
				Globals.Core.Actions.MoveItem(num, Globals.Core.CharacterFilter.Id, 0, stack: false);
				_equipWaitUntil = DateTime.Now + Tuning.Ms("EquipWaitMs");
				return false;
			}
			if (_offTriesFor != off.Id)
			{
				_offTriesFor = off.Id;
				_offTries = 0;
			}
			if (++_offTries > 3)
			{
				_offTries = 0;
				_offGiveUpUntil = DateTime.Now.AddSeconds(60.0);
				Util.WriteToChat("Dual wield: " + off.Name + " won't go in the off hand (Dual Wield trained? a one-handed weapon?) - fighting with one for a minute.");
				return true;
			}
			Status = "Equipping " + off.Name + " (off hand)";
			CM_Inventory.Event_GetAndWieldItem((uint)off.Id, 2097152u);
			_equipWaitUntil = DateTime.Now + Tuning.Ms("EquipWaitMs");
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			_offGiveUpUntil = DateTime.Now.AddSeconds(60.0);
			return true;
		}
		return false;
	}

	private bool MainWeaponForLoot()
	{
		if (!_s.LootMainWeapon || !_s.CombatEnabled || !_s.LootEnabled || HoldWeapon || Looter.Busy || _pending != null)
		{
			return false;
		}
		foreach (WeaponItem item in _s.Items)
		{
			if (item.CompareTo && !item.IsShield)
			{
				return false;
			}
		}
		if (DateTime.Now < _mainSwapGiveUpUntil || Looter.UnlootedInRange() == 0)
		{
			_mainSwapStart = DateTime.MinValue;
			return false;
		}
		WeaponItem weaponItem = ChooseWeapon(_s.DefaultRule);
		if (weaponItem == null || IsWielded(weaponItem.Id) || !InInventory(weaponItem.Id))
		{
			_mainSwapStart = DateTime.MinValue;
			return false;
		}
		WeaponItem weaponItem2 = WieldedItem();
		if (weaponItem2 == null || weaponItem2.Kind != weaponItem.Kind)
		{
			return false;
		}
		if (_mainSwapStart == DateTime.MinValue)
		{
			_mainSwapStart = DateTime.Now;
		}
		else if (DateTime.Now - _mainSwapStart > TimeSpan.FromSeconds(8L))
		{
			_mainSwapStart = DateTime.MinValue;
			_mainSwapGiveUpUntil = DateTime.Now.AddSeconds(60.0);
			return false;
		}
		if (DateTime.Now >= _equipWaitUntil && DateTime.Now >= _modeWaitUntil)
		{
			Equip(weaponItem);
		}
		Status = "Equipping " + weaponItem.Name + " (main weapon) before looting";
		return true;
	}

	private void ConfirmWaits()
	{
		if (!_s.ConfirmSwaps)
		{
			return;
		}
		DateTime now = DateTime.Now;
		CombatState combatMode;
		try
		{
			combatMode = Globals.Core.Actions.CombatMode;
		}
		catch
		{
			return;
		}
		if (now < _equipWaitUntil && _equipOkAt == DateTime.MinValue && _equipSentAt != DateTime.MinValue)
		{
			bool num;
			if (!_equipWaitPeace)
			{
				if (_equipWaitItem == 0)
				{
					goto IL_0189;
				}
				num = IsWielded(_equipWaitItem);
			}
			else
			{
				num = combatMode == CombatState.Peace;
			}
			if (num)
			{
				_equipOkAt = now;
				DateTime dateTime = Max(now + Tuning.Ms("EquipSettleMs"), _equipSentAt + Tuning.Ms("EquipMinMs"));
				if (dateTime < _equipWaitUntil)
				{
					_equipWaitUntil = dateTime;
				}
				Dbg("SWAP  " + (_equipWaitPeace ? "peace mode" : "wielded") + " shown after " + (int)(now - _equipSentAt).TotalMilliseconds + " ms - going on in " + Math.Max(0, (int)(_equipWaitUntil - now).TotalMilliseconds) + " ms");
			}
		}
		goto IL_0189;
		IL_0189:
		if (now < _modeWaitUntil && _modeOkAt == DateTime.MinValue && _modeSentAt != DateTime.MinValue && combatMode == _modeWant)
		{
			_modeOkAt = now;
			DateTime dateTime2 = Max(now + Tuning.Ms("ModeSettleMs"), _modeSentAt + Tuning.Ms("ModeMinMs"));
			if (dateTime2 < _modeWaitUntil)
			{
				_modeWaitUntil = dateTime2;
			}
			Dbg("SWAP  " + _modeWant.ToString() + " mode shown after " + (int)(now - _modeSentAt).TotalMilliseconds + " ms - going on in " + Math.Max(0, (int)(_modeWaitUntil - now).TotalMilliseconds) + " ms");
		}
	}

	private static DateTime Max(DateTime a, DateTime b)
	{
		return (a > b) ? a : b;
	}

	private void PreEquipTick()
	{
		if (!_s.PreEquipOnApproach || HoldWeapon || !_s.NavEnabled || _s.NavMode != 1 || _pending != null || Nav == null || !Nav.RouteWalking || Nav.Travelling)
		{
			return;
		}
		DateTime now = DateTime.Now;
		if (now < _equipWaitUntil || now < _modeWaitUntil || IsBusy())
		{
			return;
		}
		double num = Tuning.V("PreEquipM");
		Dictionary<int, int> dictionary = new Dictionary<int, int>();
		Dictionary<int, double> dictionary2 = new Dictionary<int, double>();
		Dictionary<int, WeaponItem> dictionary3 = new Dictionary<int, WeaponItem>();
		WorldObject dmgFor = _dmgFor;
		try
		{
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				if (!IsHostileMonster(item))
				{
					continue;
				}
				double num2 = Distance(item);
				if (num2 < 0.0 || num2 > num || (Tracked.TryGetValue(item.Id, out var value) && value.DeadAt != DateTime.MinValue))
				{
					continue;
				}
				MonsterRule monsterRule = _s.FindRule(item);
				if (monsterRule.Priority < 0)
				{
					continue;
				}
				_dmgFor = item;
				WeaponItem weaponItem = (HasDebuffs(monsterRule) ? WandFor(monsterRule) : ChooseWeapon(monsterRule));
				if (weaponItem != null && InInventory(weaponItem.Id))
				{
					dictionary.TryGetValue(weaponItem.Id, out var value2);
					dictionary[weaponItem.Id] = value2 + 1;
					if (!dictionary2.TryGetValue(weaponItem.Id, out var value3) || num2 < value3)
					{
						dictionary2[weaponItem.Id] = num2;
					}
					dictionary3[weaponItem.Id] = weaponItem;
				}
			}
		}
		finally
		{
			_dmgFor = dmgFor;
		}
		if (dictionary.Count == 0)
		{
			return;
		}
		int num3 = 0;
		foreach (KeyValuePair<int, int> item2 in dictionary)
		{
			if (num3 == 0 || item2.Value > dictionary[num3] || (item2.Value == dictionary[num3] && dictionary2[item2.Key] < dictionary2[num3]))
			{
				num3 = item2.Key;
			}
		}
		WeaponItem weaponItem2 = dictionary3[num3];
		if (!IsWielded(weaponItem2.Id))
		{
			if (_preEquipLogged != weaponItem2.Id || _equipSentAt < now.AddSeconds(-10.0))
			{
				_preEquipLogged = weaponItem2.Id;
				Dbg("PRE   equipping " + weaponItem2.Name + " on the way: " + dictionary[num3] + " monster" + ((dictionary[num3] == 1) ? "" : "s") + " within " + num.ToString("0") + " m want it (nearest " + dictionary2[num3].ToString("0") + " m)");
			}
			Equip(weaponItem2);
		}
	}

	private bool PreEquipThenNav()
	{
		try
		{
			PreEquipTick();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		return Nav.IdleTick();
	}

	private static bool HasDebuffs(MonsterRule rule)
	{
		foreach (Slot value in Enum.GetValues(typeof(Slot)))
		{
			if (value != Slot.Arc && value != Slot.Ring && value != Slot.Streak && rule.Has(value))
			{
				return true;
			}
		}
		return false;
	}

	private bool Equip(WeaponItem item)
	{
		if (IsWielded(item.Id))
		{
			return false;
		}
		bool result = false;
		try
		{
			if (Globals.Core.Actions.CombatMode != CombatState.Peace)
			{
				Status = "Equipping " + item.Name + " - entering peace mode";
				Globals.Core.Actions.SetCombatMode(CombatState.Peace);
				_equipWaitPeace = true;
				_equipWaitItem = 0;
			}
			else
			{
				Status = "Equipping " + item.Name;
				Session.Wield(item.Id);
				result = true;
				_equipWaitPeace = false;
				_equipWaitItem = item.Id;
			}
		}
		catch
		{
		}
		_equipSentAt = DateTime.Now;
		_equipOkAt = DateTime.MinValue;
		_equipWaitUntil = DateTime.Now + Tuning.Ms("EquipWaitMs");
		return result;
	}

	private bool EnsureCombatMode(CombatState mode)
	{
		try
		{
			if (Globals.Core.Actions.CombatMode == mode)
			{
				return true;
			}
			Globals.Core.Actions.SetCombatMode(mode);
		}
		catch
		{
		}
		_modeWant = mode;
		_modeSentAt = DateTime.Now;
		_modeOkAt = DateTime.MinValue;
		_modeWaitUntil = DateTime.Now + Tuning.Ms("ModeWaitMs");
		Status = "Switching to " + mode;
		return false;
	}

	private void SendPhysicalAttack(WorldObject target, WeaponKind kind)
	{
		try
		{
			float num = Math.Max(0.05f, Math.Min(1f, _s.AttackPower / 100f));
			ATTACK_HEIGHT height = ((_s.AttackHeight == 0) ? ATTACK_HEIGHT.HIGH_ATTACK_HEIGHT : ((_s.AttackHeight == 2) ? ATTACK_HEIGHT.LOW_ATTACK_HEIGHT : ATTACK_HEIGHT.MEDIUM_ATTACK_HEIGHT));
			if (kind == WeaponKind.Missile)
			{
				CM_Combat.Event_TargetedMissileAttack((uint)target.Id, height, num);
			}
			else
			{
				CM_Combat.Event_TargetedMeleeAttack((uint)target.Id, height, num);
			}
			_physTargetId = target.Id;
			_physTargetName = target.Name;
			_physKind = kind;
			_physHasPos = Pos(target, out _physX, out _physY);
			_physSentAt = DateTime.Now;
			_physAttacking = true;
			Dbg("ATK   " + kind.ToString() + " -> " + target.Name + " [" + target.Id + "] power " + (int)(num * 100f) + "%");
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			Status = "Attack request failed: " + ex.Message;
			_physSentAt = DateTime.Now;
		}
	}

	private void CancelPhysicalAttack()
	{
		if (!_physAttacking)
		{
			return;
		}
		_physAttacking = false;
		_physTargetId = 0;
		try
		{
			CM_Combat.Event_CancelAttack();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static nint GameWindow()
	{
		try
		{
			return Globals.Core.Decal.Hwnd;
		}
		catch
		{
			return Process.GetCurrentProcess().MainWindowHandle;
		}
	}

	private void UpdateVTankNavLock()
	{
		bool flag = false;
		if (_s.CombatEnabled)
		{
			int num = (((DateTime.Now - _lastScanAt).TotalSeconds < 1.0) ? _lastScanCount : MonstersInRange().Count);
			if (num > 0)
			{
				flag = true;
			}
			else
			{
				foreach (TrackedMonster value in Tracked.Values)
				{
					foreach (Slot key in value.Debuffs.Keys)
					{
						if (Slots.IsDot(key))
						{
							flag = true;
							break;
						}
					}
					if (flag)
					{
						break;
					}
				}
			}
		}
		if (Healer.Active)
		{
			flag = true;
		}
		if (Buffer.Busy)
		{
			flag = true;
		}
		if (Looter.Busy)
		{
			flag = true;
		}
		InCombat = flag;
		if (_s.HoldVTankNav & flag)
		{
			if (DateTime.Now >= _nextNavLock)
			{
				if (VTankNav(hold: true))
				{
					_nextNavLock = DateTime.Now + TimeSpan.FromSeconds(1L);
				}
				else
				{
					_nextNavLock = DateTime.Now + TimeSpan.FromSeconds(10L);
				}
			}
		}
		else if (NavHeld)
		{
			VTankNav(hold: false);
		}
	}

#if RETAIL
	private bool VTankNav(bool hold)
	{
		if (VTankStandIn.VTankOff)
		{
			NavHeld = false;
			return false;
		}
		try
		{
			Type type = FindVTankHelper();
			if (type == null)
			{
				return false;
			}
			MethodInfo method = type.GetMethod((!hold) ? "Decision_UnLock" : "Decision_Lock");
			if (method == null)
			{
				return false;
			}
			Type parameterType = method.GetParameters()[0].ParameterType;
			object obj = Enum.Parse(parameterType, "Navigation");
			if (hold)
			{
				method.Invoke(null, new object[2] { obj, NavLockLength });
			}
			else
			{
				method.Invoke(null, new object[1] { obj });
			}
			NavHeld = hold;
			return true;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			NavHeld = false;
			return false;
		}
	}
#else
	private bool VTankNav(bool hold)
	{
		bool flag = true;
		NavHeld = false;
		return false;
	}
#endif

	private static Type FindVTankHelper()
	{
		if (_vtHelper != null)
		{
			return _vtHelper;
		}
		Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
		foreach (Assembly assembly in assemblies)
		{
			if (assembly.FullName.StartsWith("UtilityBelt.Helper", StringComparison.Ordinal))
			{
				_vtHelper = assembly.GetType("UBHelper.vTank");
				if (_vtHelper != null)
				{
					break;
				}
			}
		}
		return _vtHelper;
	}

	public void ReleaseNav()
	{
		if (NavHeld)
		{
			VTankNav(hold: false);
		}
	}

	private bool IsBusy()
	{
		int num = 0;
		try
		{
			num = Globals.Core.Actions.BusyState;
		}
		catch
		{
			return false;
		}
		if (num == 0)
		{
			_busySince = DateTime.MaxValue;
			_busyIgnored = false;
			return false;
		}
		if (_busySince == DateTime.MaxValue)
		{
			_busySince = DateTime.Now;
		}
		if ((DateTime.Now - _busySince).TotalSeconds < Math.Max(3.0, Tuning.V("BusyStuckS")))
		{
			return true;
		}
		if (!_busyIgnored)
		{
			_busyIgnored = true;
			Dbg("BUSY  stuck at " + num + " for " + (DateTime.Now - _busySince).TotalSeconds.ToString("0") + "s - carrying on anyway");
			Util.WriteToChat("MelkTank: the game has said 'busy' for " + (DateTime.Now - _busySince).TotalSeconds.ToString("0") + " s - carrying on anyway.");
		}
		return false;
	}

	private void UpdateLootMode()
	{
		if (!_s.LootModeEnabled || !_s.LootEnabled || !_s.CombatEnabled)
		{
			LootMode = false;
			return;
		}
		int num = Looter.UnlootedInRange();
		if (!LootMode)
		{
			if (num > _s.LootModeCorpses && _pending == null && CountMonsters(_s.AttackRange) <= 0)
			{
				LootMode = true;
			}
		}
		else if (num == 0 && !Nav.Away)
		{
			LootMode = false;
		}
	}

	private int CountMonsters(float range)
	{
		long tickStamp = TickStamp;
		if (_cmTick == tickStamp && _cmRange == range)
		{
			return _cmCount;
		}
		int num = CountMonstersNow(range);
		_cmTick = tickStamp;
		_cmRange = range;
		_cmCount = num;
		return num;
	}

	private List<Mob> HostilesNow()
	{
		long tickStamp = TickStamp;
		if (_host != null && _hostTick == tickStamp)
		{
			return _host;
		}
		List<Mob> list = new List<Mob>();
		foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
		{
			if (IsHostileMonster(item))
			{
				list.Add(new Mob
				{
					Id = item.Id,
					D = Distance(item)
				});
			}
		}
		_host = list;
		_hostTick = tickStamp;
		return list;
	}

	private int CountMonstersNow(float range)
	{
		int num = 0;
		foreach (Mob item in HostilesNow())
		{
			if (item.D < 0.0 || item.D > (double)range)
			{
				continue;
			}
			WorldObject worldObject = item.Get();
			if (worldObject != null)
			{
				MonsterRule monsterRule = _s.FindRule(worldObject);
				if (monsterRule.Priority >= 0 || item.Id == FocusId)
				{
					num++;
				}
			}
		}
		return num;
	}

	public int MobsInRangeCount()
	{
		if (DateTime.UtcNow >= _mobCountAt)
		{
			_mobCountAt = DateTime.UtcNow.AddSeconds(1.0);
			try
			{
				_mobCount = (((DateTime.Now - _lastScanAt).TotalSeconds < 1.0) ? _lastScanCount : MonstersInRange().Count);
			}
			catch
			{
				_mobCount = 0;
			}
		}
		return _mobCount;
	}

	private void TrackAround()
	{
		foreach (Mob item in HostilesNow())
		{
			double d = item.D;
			if (!(d < 0.0) && (_s.TrackMaxRange || !(d > (double)AttackRangeNow)))
			{
				WorldObject worldObject = item.Get();
				if (worldObject != null && (!Tracked.TryGetValue(worldObject.Id, out var value) || !(value.DeadAt != DateTime.MinValue)))
				{
					GetTracked(worldObject);
				}
			}
		}
	}

	public List<WorldObject> MonstersInRange()
	{
		long tickStamp = TickStamp;
		if (_mirList != null && _mirTick == tickStamp && _mirRange == AttackRangeNow && _mirFocus == FocusId && _mirTest == TestTarget)
		{
			List<WorldObject> list = new List<WorldObject>(_mirList.Count);
			foreach (int mirId in _mirIds)
			{
				WorldObject worldObject = Globals.Core.WorldFilter[mirId];
				if (worldObject != null)
				{
					list.Add(worldObject);
				}
			}
			return list;
		}
		List<WorldObject> list2 = ScanMonstersInRange();
		_mirTick = tickStamp;
		_mirRange = AttackRangeNow;
		_mirFocus = FocusId;
		_mirTest = TestTarget;
		_mirList = list2;
		_mirIds.Clear();
		foreach (WorldObject item in list2)
		{
			_mirIds.Add(item.Id);
		}
		return new List<WorldObject>(list2);
	}

	// the nearest monster past the attack range but inside the approach range, worth running to (null: none, or off)
	private WorldObject ApproachTarget()
	{
		float reach = _s.ApproachRange;
		if (!_s.CombatEnabled || reach <= AttackRangeNow || LootMode)
		{
			return null;
		}
		WorldObject best = null;
		double bestD = double.MaxValue;
		foreach (Mob item in HostilesNow())
		{
			double d = item.D;
			if (d < 0.0 || d <= (double)AttackRangeNow || d > (double)reach || d >= bestD)
			{
				continue;
			}
			WorldObject o = item.Get();
			if (o == null || PluginCore.IsPetOnly(o.Name) || Dex.Protected(o) || _s.FindRule(o).Priority < 0)
			{
				continue;
			}
			TrackedMonster tm = GetTracked(o);
			if (tm.Blocked)
			{
				continue;
			}
			best = o;
			bestD = d;
		}
		return best;
	}

	private List<WorldObject> ScanMonstersInRange()
	{
		List<KeyValuePair<double, WorldObject>> list = new List<KeyValuePair<double, WorldObject>>();
		foreach (Mob item in HostilesNow())
		{
			double d = item.D;
			bool flag = TestTarget != 0 && item.Id == TestTarget;
			if (d < 0.0 || (d > (double)AttackRangeNow && !flag))
			{
				continue;
			}
			WorldObject worldObject = item.Get();
			if (worldObject == null)
			{
				continue;
			}
			MonsterRule monsterRule = _s.FindRule(worldObject);
			if (monsterRule.Priority < 0 && worldObject.Id != FocusId)
			{
				continue;
			}
			if (!CanHurt(monsterRule))
			{
				// (immune to everything you carry: left alone)
				if (_immuneSaid.Add(worldObject.Id))
				{
					Util.WriteToChat("MelkTank: " + worldObject.Name + " can only be hurt by " + monsterRule.AttackText.ToLower().Replace("+", " / ") + " - you carry nothing that can, so it's left alone.");
				}
				continue;
			}
			bool flag2 = TestTarget != 0 && worldObject.Id == TestTarget;
			if (!(d < 0.0) && (!(d > (double)AttackRangeNow) || flag2))
			{
				GetTracked(worldObject);
				if (flag2 || worldObject.Id == FocusId || !Dex.Protected(worldObject))
				{
					list.Add(new KeyValuePair<double, WorldObject>(d, worldObject));
				}
			}
		}
		Dictionary<int, double> turn = new Dictionary<int, double>();
		bool turnSort = _s.CloseTurnLeast;
		double num = (turnSort ? MyHeading() : (-1.0));
		if (num < 0.0)
		{
			turnSort = false;
		}
		if (turnSort)
		{
			foreach (KeyValuePair<double, WorldObject> item2 in list)
			{
				if (item2.Key <= (double)_s.CloseTurnRange)
				{
					turn[item2.Value.Id] = TurnTo(item2.Value, num);
				}
			}
		}
		HashSet<int> held = new HashSet<int>();
		if (_s.FewerWeaponSwaps && list.Count > 1 && !HoldWeapon)
		{
			WeaponItem weaponItem = WieldedItem();
			if (weaponItem != null)
			{
				foreach (KeyValuePair<double, WorldObject> item3 in list)
				{
					_dmgFor = item3.Value;
					WeaponItem weaponItem2 = ChooseWeapon(_s.FindRule(item3.Value));
					if (weaponItem2 != null && weaponItem2.Id == weaponItem.Id)
					{
						held.Add(item3.Value.Id);
					}
				}
			}
			if (held.Count == list.Count)
			{
				held.Clear();
			}
		}
		HashSet<int> attackers = AttackersAmong(list);
		list.Sort((KeyValuePair<double, WorldObject> a, KeyValuePair<double, WorldObject> b) =>
		{
			int testTarget = TestTarget;
			if (testTarget != 0 && (a.Value.Id == testTarget || b.Value.Id == testTarget))
			{
				return (a.Value.Id != testTarget) ? 1 : ((b.Value.Id != testTarget) ? (-1) : 0);
			}
			if (a.Value.Id == FocusId || b.Value.Id == FocusId)
			{
				return (a.Value.Id != FocusId) ? 1 : ((b.Value.Id != FocusId) ? (-1) : 0);
			}
			bool flag3 = IsBlocked(a.Value.Id);
			bool flag4 = IsBlocked(b.Value.Id);
			if (flag3 != flag4)
			{
				return flag3 ? 1 : (-1);
			}
			bool flag5 = held.Contains(a.Value.Id);
			bool flag6 = held.Contains(b.Value.Id);
			if (flag5 != flag6)
			{
				return (!flag5) ? 1 : (-1);
			}
			int priority = _s.FindRule(a.Value).Priority;
			int priority2 = _s.FindRule(b.Value).Priority;
			if (priority != priority2)
			{
				return priority2.CompareTo(priority);
			}
			// (the same priority: the ones the server says are hitting us first)
			if (attackers.Count > 0)
			{
				bool flag7 = attackers.Contains(a.Value.Id);
				bool flag8 = attackers.Contains(b.Value.Id);
				if (flag7 != flag8)
				{
					return flag7 ? (-1) : 1;
				}
			}
			double value;
			double value2;
			return (turnSort && turn.TryGetValue(a.Value.Id, out value) && turn.TryGetValue(b.Value.Id, out value2) && Math.Abs(value - value2) > 1.0) ? value.CompareTo(value2) : a.Key.CompareTo(b.Key);
		});
		List<WorldObject> list2 = new List<WorldObject>(list.Count);
		foreach (KeyValuePair<double, WorldObject> item4 in list)
		{
			list2.Add(item4.Value);
		}
		return list2;
	}

	public int MonstersNear(float metres)
	{
		try
		{
			return CountMonstersNear(metres);
		}
		catch
		{
			return 0;
		}
	}

	private int CountMonstersNear(float metres)
	{
		int num = 0;
		foreach (Mob item in HostilesNow())
		{
			if (!(item.D < 0.0) && !(item.D > (double)metres))
			{
				WorldObject worldObject = item.Get();
				if (worldObject != null && _s.FindRule(worldObject).Priority >= 0)
				{
					num++;
				}
			}
		}
		return num;
	}

	public bool IsHostileMonster(WorldObject obj)
	{
		if (obj == null || obj.ObjectClass != ObjectClass.Monster)
		{
			return false;
		}
		if (obj.Name.IndexOf("'s ", StringComparison.Ordinal) > 0)
		{
			return false;
		}
		try
		{
			if (obj.Values(LongValueKey.CreateFlags2) != 0)
			{
				return false;
			}
		}
		catch
		{
		}
		return true;
	}

	private TrackedMonster GetTracked(WorldObject obj)
	{
		if (!Tracked.TryGetValue(obj.Id, out var value))
		{
			value = new TrackedMonster
			{
				Id = obj.Id,
				Name = obj.Name
			};
			Tracked[obj.Id] = value;
		}
		return value;
	}

	private void AppraiseForRules()
	{
		DateTime now = DateTime.Now;
		if (now >= _rulesScanAt)
		{
			_rulesScanAt = now.AddSeconds(2.0);
			_rulesNeedId = false;
			foreach (MonsterRule item in _s.AllRules())
			{
				if (!item.IsDefault && MonsterMatch.NeedsId(item.Name))
				{
					_rulesNeedId = true;
					break;
				}
			}
		}
		bool flag = _s.AutoElementBySpecies && _s.DefaultRule.Dmg == DmgType.Auto;
		if ((!_rulesNeedId && !flag) || now < _nextIdAsk || _pending != null)
		{
			return;
		}
		double num = Math.Max(AttackRangeNow, 20f) + 10f;
		foreach (WorldObject item2 in Globals.Core.WorldFilter.GetLandscape())
		{
			if (!IsHostileMonster(item2) || MonsterMatch.MaxHealth.ContainsKey(item2.Id) || (GameInfo.Species(item2) > 0 && (!_rulesNeedId || GameInfo.MaxHealth(item2.Name) > 0)) || (_idAsked.TryGetValue(item2.Id, out var value) && (now - value).TotalSeconds < Tuning.V("RuleIdRepeatS")))
			{
				continue;
			}
			double num2 = Distance(item2);
			if (num2 < 0.0 || num2 > num)
			{
				continue;
			}
			_idAsked[item2.Id] = now;
			if (_idAsked.Count > 300)
			{
				_idAsked.Clear();
			}
			try
			{
				Util.RequestId(item2.Id);
			}
			catch
			{
			}
			_nextIdAsk = now.AddMilliseconds(Tuning.V("RuleIdSpacingMs"));
			break;
		}
	}

	private void PruneTracked()
	{
		List<int> list = null;
		foreach (KeyValuePair<int, TrackedMonster> item in Tracked)
		{
			WorldObject worldObject = Globals.Core.WorldFilter[item.Key];
			bool flag = worldObject == null;
			if (!flag)
			{
				List<Slot> list2 = null;
				bool flag2 = _s.UseDotLines && _dotLineAt != DateTime.MinValue && (DateTime.Now - _dotLineAt).TotalSeconds <= DotLineQuietS;
				foreach (KeyValuePair<Slot, ActiveDebuff> debuff in item.Value.Debuffs)
				{
					if (debuff.Value.ExpiresAt <= DateTime.Now)
					{
						(list2 ?? (list2 = new List<Slot>())).Add(debuff.Key);
					}
					else if (flag2 && debuff.Value.LineAt != DateTime.MinValue && (DateTime.Now - debuff.Value.LineAt).TotalSeconds > DotLineQuietS)
					{
						(list2 ?? (list2 = new List<Slot>())).Add(debuff.Key);
						Dbg("DOTEND " + debuff.Value.SpellName + " on " + item.Value.Name + " [" + item.Key + "]: no DoT line for " + (DateTime.Now - debuff.Value.LineAt).TotalSeconds.ToString("0") + "s (" + (debuff.Value.ExpiresAt - DateTime.Now).TotalSeconds.ToString("0") + "s left on its timer)");
					}
				}
				if (list2 != null)
				{
					foreach (Slot item2 in list2)
					{
						item.Value.Debuffs.Remove(item2);
					}
				}
				TrackedMonster value = item.Value;
				if (value.Debuffs.Count > 0 && value.HasLand && Pos(worldObject, out var x, out var y))
				{
					double num = Math.Sqrt((x - value.LandX) * (x - value.LandX) + (y - value.LandY) * (y - value.LandY));
					double num2 = Distance(worldObject);
					if (num >= Tuning.V("HomeMovedM") && num2 >= 0.0 && value.LandDist >= 0.0 && num2 >= value.LandDist + Tuning.V("HomeFurtherM"))
					{
						Dbg("HOME  " + value.Name + " [" + value.Id + "] ran off " + num.ToString("0") + " m (now " + num2.ToString("0") + " m away, was " + value.LandDist.ToString("0") + ") - its debuffs are gone, casting them again");
						value.Debuffs.Clear();
						value.RetryAfter.Clear();
						value.HasLand = false;
						value.EngagedAt = DateTime.MinValue;
						value.DeferUntil = DateTime.Now.AddSeconds(Tuning.V("HomeDeferS"));
					}
				}
				double num3 = Distance(worldObject);
				if (item.Value.Debuffs.Count == 0 && !item.Value.Alert && item.Key != FocusId && (num3 < 0.0 || num3 > (double)(_s.AttackRange * 3f)))
				{
					flag = true;
				}
			}
			if (flag)
			{
				(list ?? (list = new List<int>())).Add(item.Key);
			}
		}
		if (list == null)
		{
			return;
		}
		foreach (int item3 in list)
		{
			Tracked.Remove(item3);
		}
	}

	private static bool InInventory(int id)
	{
		try
		{
			return Globals.Core.WorldFilter[id] != null;
		}
		catch
		{
			return false;
		}
	}

	public static bool IsWielded(int id)
	{
		try
		{
			WorldObject worldObject = Globals.Core.WorldFilter[id];
			if (worldObject == null)
			{
				return false;
			}
			if (worldObject.Values(LongValueKey.Wielder) == Globals.Core.CharacterFilter.Id)
			{
				return true;
			}
			if (worldObject.Values(LongValueKey.Wielder) == Globals.Core.CharacterFilter.Id)
			{
				return true;
			}
			return ItemInfo.IsAmmo(worldObject) && worldObject.Values(LongValueKey.EquippedSlots) == 8388608;
		}
		catch
		{
			return false;
		}
	}

	private static int LandblockKey(WorldObject obj)
	{
		try
		{
			return (obj.Values(LongValueKey.Landblock) >>> 16) & 0xFFFF;
		}
		catch
		{
			return -1;
		}
	}

	public static double MyHeading()
	{
		try
		{
			double heading = Globals.Core.Actions.Heading;
			if (!double.IsNaN(heading))
			{
				return (heading % 360.0 + 360.0) % 360.0;
			}
		}
		catch
		{
		}
		try
		{
			WorldObject worldObject = Globals.Core.WorldFilter[Globals.Core.CharacterFilter.Id];
			double num = worldObject.Values(DoubleValueKey.Heading);
			return (num % 360.0 + 360.0) % 360.0;
		}
		catch
		{
			return -1.0;
		}
	}

	public static double TurnTo(WorldObject obj, double facing)
	{
		try
		{
			WorldObject worldObject = Globals.Core.WorldFilter[Globals.Core.CharacterFilter.Id];
			if (worldObject == null)
			{
				return 180.0;
			}
			double y;
			double x;
			if (LandblockKey(obj) == LandblockKey(worldObject))
			{
				y = obj.RawCoordinates().X - worldObject.RawCoordinates().X;
				x = obj.RawCoordinates().Y - worldObject.RawCoordinates().Y;
			}
			else
			{
				CoordsObject coordsObject = obj.Coordinates();
				CoordsObject coordsObject2 = worldObject.Coordinates();
				y = (coordsObject.EastWest - coordsObject2.EastWest) * 240.0;
				x = (coordsObject.NorthSouth - coordsObject2.NorthSouth) * 240.0;
			}
			double num = Math.Atan2(y, x) * 180.0 / Math.PI;
			return Math.Abs(((num - facing) % 360.0 + 540.0) % 360.0 - 180.0);
		}
		catch
		{
			return 180.0;
		}
	}

	public static double Distance(WorldObject obj)
	{
		try
		{
			if (obj == null)
			{
				return -1.0;
			}
			if (_meFrame != Perf.FrameNo || !_meOk)
			{
				_meOk = false;
				WorldObject worldObject = Globals.Core.WorldFilter[Globals.Core.CharacterFilter.Id];
				if (worldObject == null)
				{
					return -1.0;
				}
				Vector3Object vector3Object = worldObject.RawCoordinates();
				_meX = vector3Object.X;
				_meY = vector3Object.Y;
				_meZ = vector3Object.Z;
				_meLb = LandblockKey(worldObject);
				CoordsObject coordsObject = worldObject.Coordinates();
				if (coordsObject == null)
				{
					return -1.0;
				}
				_meNS = coordsObject.NorthSouth;
				_meEW = coordsObject.EastWest;
				_meFrame = Perf.FrameNo;
				_meOk = true;
			}
			if (LandblockKey(obj) == _meLb)
			{
				Vector3Object vector3Object2 = obj.RawCoordinates();
				double num = vector3Object2.X - _meX;
				double num2 = vector3Object2.Y - _meY;
				double num3 = vector3Object2.Z - _meZ;
				return Math.Sqrt(num * num + num2 * num2 + num3 * num3);
			}
			CoordsObject coordsObject2 = obj.Coordinates();
			if (coordsObject2 == null)
			{
				return -1.0;
			}
			double num4 = (coordsObject2.NorthSouth - _meNS) * 240.0;
			double num5 = (coordsObject2.EastWest - _meEW) * 240.0;
			return Math.Sqrt(num4 * num4 + num5 * num5);
		}
		catch
		{
			return -1.0;
		}
	}
}
