using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;
using Decal.Adapter.Wrappers;

namespace MelkTank;

public static class MonsterMatch
{
	public class Ctx
	{
		public string Name;

		public WorldObject Obj;

		public bool ShinySame;

		private double? _range;

		private int? _species;

		private bool? _shield;

		public double Range
		{
			get
			{
				if (!_range.HasValue)
				{
					_range = ((Obj != null) ? CombatEngine.Distance(Obj) : (-1.0));
				}
				return _range.Value;
			}
		}

		public int Species
		{
			get
			{
				if (!_species.HasValue)
				{
					int value = 0;
					try
					{
						if (Obj != null)
						{
							value = GameInfo.Species(Obj);
						}
					}
					catch
					{
					}
					_species = value;
				}
				return _species.Value;
			}
		}

		public bool HasShield
		{
			get
			{
				if (!_shield.HasValue)
				{
					_shield = Obj != null && HoldsShield(Obj.Id);
				}
				return _shield.Value;
			}
		}

		public int MaxHp
		{
			get
			{
				int value;
				return (Obj != null && MaxHealth.TryGetValue(Obj.Id, out value)) ? value : GameInfo.MaxHealth(Name);
			}
		}

		public Ctx(string name, WorldObject o, bool shinySame)
		{
			Name = name ?? "";
			Obj = o;
			ShinySame = shinySame;
		}
	}

	private class Term
	{
		public string Field;

		public string Op;

		public string Value;

		public Regex Rx;

		public double Num;

		public bool NumOk;

		public int SpeciesId = -1;
	}

	private class Expr
	{
		public List<List<Term>> Ors = new List<List<Term>>();

		public string Error;

		public bool NeedsId;
	}

	public static readonly string[][] Examples = new string[12][]
	{
		new string[2] { "One exact creature", "Tusker Guard" },
		new string[2] { "Every creature with a word in its name", "name#golem" },
		new string[2] { "Names that start with a word", "name#^Olthoi" },
		new string[2] { "A whole species", "species==virindi" },
		new string[2] { "A species, minus one member", "species==drudge && name!=Drudge Slinker" },
		new string[2] { "Either of two names in one row", "name#Slaver || name#Handler" },
		new string[2] { "A creature only when it is close", "range<20 && name==Empyrean Handler" },
		new string[2] { "The same creature when it is far (a second row)", "range>=20 && name==Empyrean Handler" },
		new string[2] { "Close members of a species", "species==tumerok && range<20" },
		new string[2] { "Shield users (for example, to switch damage type)", "hasshield==true" },
		new string[2] { "Big health pools", "maxhp>=20000" },
		new string[2] { "Everything far away, ignored (priority -1, just above <DEFAULT>)", "range>30" }
	};

	public static readonly Dictionary<int, int> MaxHealth = new Dictionary<int, int>();

	private static readonly Dictionary<string, Expr> _cache = new Dictionary<string, Expr>(StringComparer.Ordinal);

	private static readonly Regex TermRx = new Regex("^\\s*(?<f>[A-Za-z]+)\\s*(?<op>==|!=|>=|<=|!#|#|>|<|=)\\s*(?<v>.*?)\\s*$");

	private static readonly string[] Fields = new string[5] { "name", "species", "range", "hasshield", "maxhp" };

	private static readonly string[] SpeciesNames = new string[102]
	{
		"", "Olthoi", "Banderling", "Drudge", "Mosswart", "Lugian", "Tumerok", "Mite", "Tusker", "PhyntosWasp",
		"Rat", "Auroch", "Cow", "Golem", "Undead", "Gromnie", "Reedshark", "Armoredillo", "Fae", "Virindi",
		"Wisp", "Knathtead", "Shadow", "Mattekar", "Mumiyah", "Rabbit", "Sclavus", "ShallowsShark", "Monouga", "Zefir",
		"Skeleton", "Human", "Shreth", "Chittick", "Moarsman", "OlthoiLarvae", "Slithis", "Deru", "FireElemental", "Snowman",
		"Unknown", "Bunny", "LightningElemental", "Rockslide", "Grievver", "Niffis", "Ursuin", "Crystal", "HollowMinion", "Scarecrow",
		"Idol", "Empyrean", "Hopeslayer", "Doll", "Marionette", "Carenzi", "Siraluun", "AunTumerok", "HeaTumerok", "Simulacrum",
		"AcidElemental", "FrostElemental", "Elemental", "Statue", "Wall", "AlteredHuman", "Device", "Harbinger", "DarkSarcophagus", "Chicken",
		"GotrokLugian", "Margul", "BleachedRabbit", "NastyRabbit", "GrimacingRabbit", "Burun", "Target", "Ghost", "Fiun", "Eater",
		"Penguin", "Ruschk", "Thrungus", "ViamontianKnight", "Remoran", "Swarm", "Moar", "EnchantedArms", "Sleech", "Mukkir",
		"Merwart", "Food", "ParadoxOlthoi", "Harvest", "Energy", "Apparition", "Aerbax", "Touched", "BlightedMoarsman", "GearKnight",
		"Gurog", "Anekshay"
	};

	public static int SpeciesCount => SpeciesNames.Length;

	private static bool HoldsShield(int mobId)
	{
		try
		{
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				int num = 0;
				try
				{
					num = item.Values(LongValueKey.Wielder);
				}
				catch
				{
				}
				if (num == mobId)
				{
					int num2 = 0;
					try
					{
						num2 = item.Values(LongValueKey.EquipableSlots);
					}
					catch
					{
					}
					if ((num2 & 0x200000) != 0 || (item.Name ?? "").IndexOf("Shield", StringComparison.OrdinalIgnoreCase) >= 0)
					{
						return true;
					}
				}
			}
		}
		catch
		{
		}
		return false;
	}

	public static bool IsExpression(string rowName)
	{
		string text = rowName ?? "";
		if (text.IndexOf("&&", StringComparison.Ordinal) >= 0 || text.IndexOf("||", StringComparison.Ordinal) >= 0)
		{
			return true;
		}
		return TermRx.IsMatch(text);
	}

	public static string Problem(string rowName)
	{
		return Get(rowName)?.Error;
	}

	public static bool NeedsId(string rowName)
	{
		return Get(rowName)?.NeedsId ?? false;
	}

	private static Expr Get(string rowName)
	{
		if (!IsExpression(rowName))
		{
			return null;
		}
		if (_cache.TryGetValue(rowName, out var value))
		{
			return value;
		}
		value = new Expr();
		foreach (string item in Split(rowName, "||"))
		{
			List<Term> list = new List<Term>();
			foreach (string item2 in Split(item, "&&"))
			{
				Match match = TermRx.Match(item2);
				if (!match.Success)
				{
					value.Error = "can't read \"" + item2.Trim() + "\"";
					continue;
				}
				Term term = new Term
				{
					Field = match.Groups["f"].Value.ToLowerInvariant(),
					Op = match.Groups["op"].Value,
					Value = match.Groups["v"].Value
				};
				if (term.Op == "=")
				{
					term.Op = "==";
				}
				if (Array.IndexOf(Fields, term.Field) < 0)
				{
					value.Error = "unknown \"" + term.Field + "\" (name, species, range, hasshield, maxhp)";
					continue;
				}
				term.NumOk = double.TryParse(term.Value, NumberStyles.Float, CultureInfo.InvariantCulture, out term.Num);
				if (term.Op == "#" || term.Op == "!#")
				{
					try
					{
						term.Rx = new Regex(term.Value, RegexOptions.IgnoreCase);
					}
					catch (Exception ex)
					{
						value.Error = "bad pattern \"" + term.Value + "\": " + ex.Message;
					}
				}
				if ((term.Field == "range" || term.Field == "maxhp") && !term.NumOk)
				{
					value.Error = term.Field + " needs a number";
				}
				if (term.Field == "species")
				{
					if (int.TryParse(term.Value, out var result))
					{
						term.SpeciesId = result;
					}
					else
					{
						term.SpeciesId = SpeciesId(term.Value);
						if (term.SpeciesId < 0)
						{
							value.Error = "unknown species \"" + term.Value + "\"";
						}
					}
				}
				if (term.Field == "species" || term.Field == "maxhp")
				{
					value.NeedsId = true;
				}
				list.Add(term);
			}
			if (list.Count > 0)
			{
				value.Ors.Add(list);
			}
		}
		if (value.Ors.Count == 0 && value.Error == null)
		{
			value.Error = "empty";
		}
		_cache[rowName] = value;
		return value;
	}

	private static IEnumerable<string> Split(string s, string sep)
	{
		int i = 0;
		while (true)
		{
			int j = s.IndexOf(sep, i, StringComparison.Ordinal);
			if (j < 0)
			{
				break;
			}
			yield return s.Substring(i, j - i);
			i = j + sep.Length;
		}
		yield return s.Substring(i);
	}

	public static bool Matches(string rowName, Ctx c)
	{
		Expr expr = Get(rowName);
		if (expr == null)
		{
			if (string.Equals(rowName, c.Name, StringComparison.OrdinalIgnoreCase))
			{
				return true;
			}
			return c.ShinySame && string.Equals(rowName, Settings.BaseMonsterName(c.Name), StringComparison.OrdinalIgnoreCase);
		}
		if (expr.Error != null)
		{
			return false;
		}
		foreach (List<Term> or in expr.Ors)
		{
			bool flag = true;
			foreach (Term item in or)
			{
				if (!Eval(item, c))
				{
					flag = false;
					break;
				}
			}
			if (flag)
			{
				return true;
			}
		}
		return false;
	}

	private static bool Eval(Term t, Ctx c)
	{
		switch (t.Field)
		{
		case "name":
		{
			string name = c.Name;
			string text = (c.ShinySame ? Settings.BaseMonsterName(c.Name) : c.Name);
			if (t.Op == "#")
			{
				return t.Rx != null && (t.Rx.IsMatch(name) || t.Rx.IsMatch(text));
			}
			if (t.Op == "!#")
			{
				return t.Rx != null && !t.Rx.IsMatch(name);
			}
			bool flag3 = string.Equals(name, t.Value, StringComparison.OrdinalIgnoreCase) || string.Equals(text, t.Value, StringComparison.OrdinalIgnoreCase);
			return (t.Op == "==") ? flag3 : (t.Op == "!=" && !flag3);
		}
		case "species":
		{
			if (c.Obj == null)
			{
				return false;
			}
			int species = c.Species;
			if (species <= 0)
			{
				return false;
			}
			return (t.Op == "==") ? (species == t.SpeciesId) : (t.Op == "!=" && species != t.SpeciesId);
		}
		case "range":
			return c.Obj != null && c.Range >= 0.0 && Cmp(c.Range, t);
		case "maxhp":
		{
			int maxHp = c.MaxHp;
			return maxHp > 0 && Cmp(maxHp, t);
		}
		case "hasshield":
		{
			bool flag = !string.Equals(t.Value, "false", StringComparison.OrdinalIgnoreCase) && t.Value != "0";
			bool flag2 = c.Obj != null && c.HasShield;
			return (t.Op == "!=") ? (flag2 != flag) : (flag2 == flag);
		}
		default:
			return false;
		}
	}

	private static bool Cmp(double v, Term t)
	{
		return t.Op switch
		{
			"==" => Math.Abs(v - t.Num) < 0.5, 
			"!=" => Math.Abs(v - t.Num) >= 0.5, 
			"<" => v < t.Num, 
			"<=" => v <= t.Num, 
			">" => v > t.Num, 
			">=" => v >= t.Num, 
			_ => false, 
		};
	}

	public static string SpeciesName(int id)
	{
		string result;
		if (id > 0 && id < SpeciesNames.Length)
		{
			result = SpeciesNames[id];
		}
		else
		{
			result = ((id > 0) ? ("#" + id) : "");
		}
		return result;
	}

	public static int SpeciesId(string name)
	{
		string b = (name ?? "").Replace(" ", "").Replace("-", "").Trim();
		for (int i = 1; i < SpeciesNames.Length; i++)
		{
			if (string.Equals(SpeciesNames[i], b, StringComparison.OrdinalIgnoreCase))
			{
				return i;
			}
		}
		return -1;
	}
}
