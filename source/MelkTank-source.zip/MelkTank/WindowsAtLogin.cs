using System;
using System.Collections.Generic;
using System.Numerics;
using ImGuiNET;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public class WindowsAtLogin
{
	public const int Leave = 0;

	public const int Open = 1;

	public const int Collapsed = 2;

	public const int Closed = 3;

	private static readonly string[] Modes = new string[4] { "Leave as is", "Closed", "Open", "Open, collapsed" };

	private static readonly int[] ModeOf = new int[4] { 0, 3, 1, 2 };

	private static readonly Vector4 Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f);

	private readonly Settings _s;

	public Action SaveAll;

	private DateTime _loginAt = DateTime.MinValue;

	private readonly HashSet<string> _done = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

	public WindowsAtLogin(Settings s)
	{
		_s = s;
	}

	public void LoggedIn()
	{
		_loginAt = DateTime.Now;
		_done.Clear();
	}

	private Dictionary<string, int> Config()
	{
		Dictionary<string, int> dictionary = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
		string[] array = (_s.LoginWindows ?? "").Split('|');
		foreach (string text in array)
		{
			int num = text.LastIndexOf('=');
			if (num > 0 && int.TryParse(text.Substring(num + 1), out var result))
			{
				dictionary[text.Substring(0, num)] = result;
			}
		}
		return dictionary;
	}

	private void SaveConfig(Dictionary<string, int> d)
	{
		List<string> list = new List<string>();
		foreach (KeyValuePair<string, int> item in d)
		{
			if (item.Value != 0)
			{
				list.Add(item.Key + "=" + item.Value);
			}
		}
		_s.LoginWindows = string.Join("|", list.ToArray());
		if (SaveAll != null)
		{
			SaveAll();
		}
	}

	private static List<Hud> AllHuds()
	{
		List<Hud> list = new List<Hud>();
		try
		{
			foreach (Hud hud in UBService.Huds.Huds)
			{
				if (hud != null && !string.IsNullOrEmpty(hud.Name))
				{
					list.Add(hud);
				}
			}
		}
		catch
		{
		}
		return list;
	}

	public void Tick()
	{
		if (_loginAt == DateTime.MinValue)
		{
			return;
		}
		double totalSeconds = (DateTime.Now - _loginAt).TotalSeconds;
		if (totalSeconds > 20.0)
		{
			_loginAt = DateTime.MinValue;
		}
		else
		{
			if (totalSeconds < 2.0)
			{
				return;
			}
			Dictionary<string, int> dictionary = Config();
			if (dictionary.Count != 0)
			{
				foreach (Hud item in AllHuds())
				{
					if (dictionary.TryGetValue(item.Name, out var value) && value != 0 && !_done.Contains(item.Name))
					{
						_done.Add(item.Name);
						try
						{
							switch (value)
							{
							case 3:
								item.Visible = false;
								goto end_IL_00f5;
							case 2:
								Collapse(item, collapsed: true);
								break;
							default:
								Collapse(item, collapsed: false);
								break;
							}
							item.Visible = true;
							end_IL_00f5:;
						}
						catch (Exception ex)
						{
							Util.LogError(ex);
						}
					}
				}
				return;
			}
			_loginAt = DateTime.MinValue;
		}
	}

	private static void Collapse(Hud h, bool collapsed)
	{
		EventHandler handler = null;
		handler = (object? o, EventArgs e) =>
		{
			try
			{
				ImGui.SetNextWindowCollapsed(collapsed, ImGuiCond.Always);
			}
			catch
			{
			}
			try
			{
				h.OnPreRender -= handler;
			}
			catch
			{
			}
		};
		h.OnPreRender += handler;
	}

	private static bool IsUtilityBelt(string name)
	{
		string text = (name ?? "").ToLowerInvariant();
		return text.Contains("ubloader") || text.Contains("toaster") || text.Contains("utilitybelt") || text.Contains("utility belt") || text.Contains("settings editor") || text.Contains("script") || text.StartsWith("ub ") || text == "ub";
	}

	public bool Draw()
	{
		Dictionary<string, int> dictionary = Config();
		List<string> list = new List<string>();
		foreach (Hud item in AllHuds())
		{
			if (!list.Contains(item.Name) && !IsUtilityBelt(item.Name))
			{
				list.Add(item.Name);
			}
		}
		foreach (string key in dictionary.Keys)
		{
			if (!list.Contains(key))
			{
				list.Add(key);
			}
		}
		list.Sort(StringComparer.OrdinalIgnoreCase);
		Im.TextColored(Grey, "After you log in, these windows are opened or closed for you (each plugin's own window).");
		bool flag = false;
		if (ImGui.BeginTable("loginwins", 2, ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("Window", ImGuiTableColumnFlags.WidthFixed, 220f);
			ImGui.TableSetupColumn("At login", ImGuiTableColumnFlags.WidthFixed, 160f);
			foreach (string item2 in list)
			{
				dictionary.TryGetValue(item2, out var value);
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				ImGui.TextUnformatted(item2);
				ImGui.TableSetColumnIndex(1);
				ImGui.SetNextItemWidth(-1f);
				int current_item = Array.IndexOf(ModeOf, value);
				if (current_item < 0)
				{
					current_item = 0;
				}
				if (ImGui.Combo("##lw" + item2, ref current_item, Modes, Modes.Length))
				{
					dictionary[item2] = ModeOf[current_item];
					flag = true;
				}
			}
			ImGui.EndTable();
		}
		if (ImGui.SmallButton("Try it now"))
		{
			LoggedIn();
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Opens them the way they'd open at login.");
		}
		if (flag)
		{
			SaveConfig(dictionary);
		}
		return flag;
	}
}
