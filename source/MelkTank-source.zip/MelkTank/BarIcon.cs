namespace MelkTank;

internal static class BarIcon
{
	public static string LabelFor(string title)
	{
		string text = title ?? "";
		switch (text)
		{
		case "MelkTank":
			return "Tank";
		case "MelksBuffer":
			return "Buff";
		case "MelksPetSummoner":
			return "Pet";
		case "MelksLuminanceTracker":
			return "Lum";
		case "MelksQuestTracker":
			return "QB";
		case "MLT Kills":
			return "Kill";
		case "MLT XP":
			return "XP";
		default:
			if (text.StartsWith("Melks"))
			{
				text = text.Substring(5);
			}
			text = text.Replace(" ", "");
			return (text.Length > 4) ? text.Substring(0, 4) : text;
		}
	}

	public static object Make(string label)
	{
		return label;
	}
}
