using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Xml;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;

namespace MelkTank;

public static class Locations
{
	public class Entry
	{
		public int Lb;

		public string Default = "";

		public string Name = "";

		public DateTime LastSeen = DateTime.MinValue;

		public long Updated;

		public string Shown
		{
			get
			{
				string result;
				if (Name.Length > 0)
				{
					result = Name;
				}
				else
				{
					result = ((Default.Length > 0) ? Default : "Unknown");
				}
				return result;
			}
		}
	}

	private static readonly string[] Builtin = new string[350]
	{
		"0001|Remote Empyrean Vault", "0002|Viamontian Garrison", "0018|Copper Legion Keep", "0019|Gold Legion Keep", "001A|Platinum Legion Keep", "001B|Silver Legion Keep", "001C|Lugian Ice Tunnels", "001D|Ruschk Icehold", "001E|Viamontian Royal Prison", "001F|Eater Pit",
		"0020|Heart of Madness", "0021|Hall of Karlun", "0022|Cannibal Caverns", "0029|Thrungus Hole", "002A|Path of the Blind", "002B|Egg Orchard", "002C|Forgotten Chasm", "002D|Dark Design", "002E|Feeding Tubes", "0030|Renegade Incursion",
		"0031|Creepy Canyons", "0032|Tunnel of Love", "0033|Icy Hideout", "0034|The Fazenda Caves", "0035|Lost Coastal Archive", "0036|Lost Desert Archive", "0037|Frozen Cenotaph", "0038|Crypt of Adhorix", "0039|Hagra's Holdfast", "003C|Abandoned Mines",
		"003E|Breached Hive", "0040|Master Alizari's Dig", "0041|Mistress Halmera's Dig", "0042|Mistress Gabille's Dig", "0043|Master Vaserio's Dig", "0044|Collegium Occultus", "0045|Temple East Wing", "0046|Yanshi Upper Undermine", "0047|Repository", "0048|Dardante's Keep",
		"0049|Camp Entemarre", "004A|Creepy Chambers", "004B|Path of the Blind West", "004C|Mukkir Nest", "004D|Western Temple Catacombs", "004E|Vault of Eternal Slumber", "004F|Temple of the Black Spear", "0050|Realaidain Western Vault", "0051|Eastern Pedestal Dungeon", "0052|Silyun Chapterhouse",
		"0053|Shade Iron Mine", "0054|Deep Mukkir Nest", "0055|Back Tunnels", "0056|Augmentation Realm Main Level", "0057|Tanada House of Metal", "0058|Viamont Staging Area", "0059|Viamont Staging Area", "005A|Viamont Staging Area", "005B|Bookcase", "005D|Harbinger's Lair",
		"005F|Tanada House of Pancakes", "0060|Harraag's Lair", "0061|Western Pedestal Dungeon", "0063|Northern Pedestal Dungeon", "0064|Egg Orchard East", "0065|Thrungal Den", "0066|PK Arena", "0067|PKL Arena", "0068|Viamontian Laboratory", "006C|Lower Catacomb",
		"006D|Augmentation Realm Upper Level", "006E|Empyrean Workshop", "0071|Dericost Vault", "0072|Falatacot Vault", "0073|Black Ferah's Vault", "0074|Grael's Chamber", "0075|Grael's Chamber", "0076|Grael's Chamber", "0077|Muggy Guruk Caverns", "0078|Humid Guruk Caverns",
		"0079|Steamy Guruk Caverns", "007A|Deep Guruk Caverns", "007B|Tanada House of Wind", "007C|Soul Hunter's Lair", "007D|Augmentation Realm Lower Level", "007E|Black Spear Temple Upper Levels", "007F|Binding Realm", "0080|Rossu Morta Chapterhouse", "0081|Whispering Blade Chapterhouse", "0082|Assassins' Hideout",
		"0083|Pheraion's Sanctum", "0084|Black Spear Summoning Chamber", "0085|Altar Nest", "0086|Strange Swamp Temple", "0087|Ikzisik Tika Ri Zikma", "0088|Deeper Catacombs", "0089|Cells of the Black Book", "008A|Dark Monolith Caverns", "008B|Ancient Masonry", "008C|Essence Chambers",
		"0095|Lord Cynreft's Tomb", "0096|Insatiable Vault", "0097|Son of Pooky's Den", "0099|Black Totem Temple", "009A|White Totem Temple", "009B|Crypt of Crimson Night", "009C|Kor-Gursha", "009D|Swamp Cavern", "009E|Tanada House of Water", "009F|Trial of the Arm",
		"00A0|Laboratory", "00A1|Laboratory", "00A2|Laboratory", "00A3|The Path to More Recent Times", "00A4|Hidden Laboratory", "00A5|Lonely Fortress", "00A6|Tanada Battle Burrows", "00A7|Shade of Dule", "00A8|Roots of the Deru Tree", "00A9|Trial of the Deep",
		"00AA|Olthoi Sanctuary", "00AF|Statue", "00B5|Mosswart Worship Cavern", "00B6|Azaxis", "00B7|Stronghold", "00B8|Stronghold", "00B9|Stronghold", "00BA|Corrupted Catacombs", "00C0|South Gate", "00C1|Blighted Rank Moarsman Tunnels",
		"00C2|Blighted Disgusting Moarsman Tunnels", "00C3|Blighted Putrid Moarsman Tunnels", "00C4|Blighted Desolation Moarsman Tunnels", "00C5|Blighted Grimy Moarsman Tunnels", "00C6|Blighted Verdant Moarsman Tunnels", "00C8|Egg Orchard West", "00C9|Chamber of Air", "00CB|Entrance to the pyramid", "00CC|Renegade Fortress", "00CD|Tanada Temple of Black Water",
		"00CF|The Dark Spiral", "00D1|Deeper Caves", "00D2|Northern Catacombs", "00D3|Eastern Catacombs", "00D4|Bur Catacombs", "00D6|Quiddity Seed", "00D9|Blightfinger's Warrens", "00DC|Moarsmen Priory", "00DD|Acolyte's Chamber", "00DE|Temple Door",
		"00DF|Temple of Tthuun", "00E0|Rogue Delvings", "00E1|Path of the Blind East", "00E2|Ruschk Burial Mound", "00E3|Sclavus Umbral Forge", "00E4|Ritual Chambers", "00E5|Temple of the Three", "00E6|Prodigal Shadow Child's Lair", "00E7|Gardens of Menilesh", "00EA|Forges",
		"00EB|Ancient Cloister", "00ED|Artifex Collegium", "00EE|Cave", "00EF|Temple Entrance", "00F0|Temple of Xik Minru", "0110|Nexus", "0114|Sultry Hovel", "0117|Serac Vault", "0118|Drudge Hovel", "0119|Amperehelion Vault",
		"011A|Incunabula Vault", "011B|Jahannan Vault", "011C|Mountain Fortress", "0136|Empyrean Foundry", "0139|Mage Academy", "013B|Folthid Cellar", "013E|Burial Temple", "0155|Musansayn's Vaults", "0159|Abandoned Shops", "015D|Mountain Cavern",
		"015F|Dericost Ruin", "0160|Derethian Combat Arena", "0164|Lost Distillery", "0165|Old Warehouse", "0166|Deserted Ruin", "0168|Water Temple", "016C|The Marketplace of Dereth", "018E|Abayar's Laboratory", "0193|K'nath Lair", "0194|Ruined Empyrean Vault",
		"0197|Marauder's Lair", "0199|Abayar's Study", "01A8|Unstable", "01CB|Penguin Cave Hatchery", "01CF|Eastham Sewer", "01E4|North Glenden Prison", "01EB|Lola's Den", "01FE|Small Empyrean Vault", "02A1|Panopticon", "02A4|South Tumerok Vanguard Outpost",
		"02A5|North Tumerok Vanguard Outpost", "02B7|Catacombs of Ithaenc", "02B9|Moist Hovel", "02CB|The Floating City", "02CC|The Floating City", "02CD|The Floating City", "02CE|The Floating City", "02CF|The Floating City", "02D0|The Floating City", "02D1|The Floating City",
		"02D4|Abhorrent Vault", "02D5|Waterfall Cave", "02D6|Hidden City", "02DB|Fenmalain Vestibule", "02DC|Caulnalain Vestibule", "02DD|Penguin Den", "02DE|Ruschk Iceberg", "02E0|Shendolain Vestibule", "02E1|Golem Sanctum", "02E4|Humid Hovel",
		"02EB|Viamontian Torture Chamber", "02ED|Aerlinthe Lower Reservoir", "02EE|Aerlinthe Reservoir", "02F3|Halls of Metos", "02F4|Halls of Metos", "02F5|Halls of Metos", "02F6|Sclavus Cathedral", "02FE|Frozen Library", "039B|Steaming Hovel", "039D|Ravenous Vault",
		"03A5|Undead Temple", "03FE|Mossy Cave", "0B0C|Spire's Head", "1936|Archive", "24C0|Roots of Skuld, Urd and Verdandi", "2842|Apostate Citadel Mines", "2D6B|Facility Entrance", "3960|Apostate Excavation", "3FB1|Arrival Chamber", "4198|Castle Pietrus",
		"472D|Massilor's Crypt", "482D|Graveyard", "482E|Graveyard", "536D|Bookcase", "5645|Abandoned Armory", "5646|An Archive", "5647|Tower Base Dungeon", "5649|Dark Tree Crystal Mine", "5652|Hidden Treasury", "5655|Virindi Research Facility",
		"5754|Catacombs", "5756|Temple", "5760|Sand Caves", "5765|Lost Ruins", "5766|Nanjou Shou-jen Academy", "5768|Sclavus Santa's House", "5769|Firey Refuge", "576A|Charged Refuge", "576C|Acidic Refuge", "576D|Cavernous Refuge",
		"576E|Shadowy Refuge", "576F|Twisted Refuge", "5770|Frozen Refuge", "5771|Venerable Mausoleum", "584D|Frigid Grotto", "584E|Serpent Burial Grounds", "5850|Prismatic Guardian Lair", "5851|Prismatic Ziggurat", "5852|Proving Grounds Uber", "5853|Prismatic Devastation",
		"5854|Gaerlan's Inner Sanctum", "5856|Foundry of Izexi", "585E|Falatacot Depot", "5860|Colton Reeyan's Sanctuary", "5861|Crystal Core", "5862|Count Phainor's Tomb", "5863|Desert Dwelling", "5864|Samurai Hausu", "5865|Fiery Alcove", "5866|Sanctuary of the Recluse",
		"5867|Virindi Edifice", "5868|Chiming", "5869|West Fork Dam Hive", "586A|Grub Quarters", "586B|Queen's Quarters", "586C|Masked Preface", "586D|Hive Eviscerator Burrow", "586E|Hive Warrior Mound", "586F|Tusker Den", "5870|Curator of Torment's Study",
		"5871|Seed of Hatred", "5872|Seed of Misery", "5873|Seed of Anger", "5874|Large Portal Tile", "5875|Rynthid Genesis", "5876|Rynthid Foundry", "5877|Fear Factory", "5878|Spirited Halls", "5879|Path of Rage", "587A|White",
		"594E|Deep Caves", "594F|Laboratory", "5951|Presk's Bunker", "5952|Swirling", "5953|Blue", "5954|Inner Sanctum", "595E|Frozen Recess", "596A|Fowl Basement", "596B|Temple of the Font", "5A43|Lightning Guardian Lair",
		"5A44|Proving Grounds Extreme", "5A45|Electric Destruction", "5A46|Frost Ziggurat", "5E47|Asheron's Sanctum", "5F47|Elemental Caverns", "6145|Matron Hive West", "6146|Matron Hive East", "6346|Matron Hive South", "6347|Matron Hive North", "654C|Enchanted Mnemosyne Portal 2",
		"654D|Private Chambers", "6651|Hoshino Tower", "665E|Great Hall", "6757|Tanada Toresen Temple", "77E7|Frozen Tomb", "7E02|The Shadows", "7E03|Surface", "8004|Outer Courtyard", "8703|Outer Courtyard", "8802|Roost Floor Trap",
		"8903|Portalspace Rift", "8904|Empyrean Facility Upper Level", "8A02|Facility Hub", "8A04|Disco Inferno", "8A63|Temple of Mornings", "8B02|Forgotten Tunnels", "8B03|Mysterious", "8B04|Frozen Wight Lair", "8C04|Outer Courtyard", "9302|Geraine's Study",
		"934B|Bookcase", "9EE5|Northwatch Castle", "C7B7|Paradox Queen's Lair", "C7EA|Olthoi Tunnel", "CD41|End of the Story", "D599|Asheron's Tower", "EA6C|Whispering Caverns", "F81E|Blessed Cave", "F92F|Freebooter Keep", "F93B|Sparkling"
	};

	private static Dictionary<int, string> _builtin;

	private static readonly Dictionary<int, Entry> _list = new Dictionary<int, Entry>();

	private static readonly HashSet<int> _removed = new HashSet<int>();

	private static bool _loaded;

	private static bool _dirty;

	private static DateTime _savedAt = DateTime.MinValue;

	private static DateTime _checkedAt = DateTime.MinValue;

	private static DateTime _fileTime = DateTime.MinValue;

	private static string _portalName = "";

	private static DateTime _portalAt = DateTime.MinValue;

	private static DateTime _exitDue = DateTime.MaxValue;

	private static int _lastLb = -1;

	public const string Unknown = "Unknown";

	private static bool _publish = true;

	private static DateTime _exitAt = DateTime.MinValue;

	private static int _pendLb = -1;

	private static DateTime _pendSince;

	private static DateTime _pendAt;

	private static bool _pendPortal;

	private static string _pendName = "";

	private static int _hereKey = -1;

	private static readonly string[] Generic = new string[5] { "portal", "exit", "gateway", "town portal", "return portal" };

	private static readonly Vector4 Green = new Vector4(0.45f, 0.9f, 0.45f, 1f);

	private static readonly Vector4 Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f);

	private static readonly Vector4 Cyan = new Vector4(0.35f, 0.85f, 0.95f, 1f);

	private static readonly Vector4 Yellow = new Vector4(0.95f, 0.85f, 0.35f, 1f);

	private static string _filter = "";

	private static bool _showBuiltin;

	private static readonly Dictionary<int, string> _edit = new Dictionary<int, string>();

	private static string FilePath => Util.FullPath("MelkTank_Locations.xml");

	private static string OldTxt => Util.FullPath("MelkTank_Locations.txt");

	public static int Key(int lb, int v)
	{
		return (lb & 0xFFFF) | (v << 16);
	}

	public static string Label(int key)
	{
		int num = key >> 16;
		return (key & 0xFFFF).ToString("X4") + ((num > 0) ? (" v:" + num) : "");
	}

	private static string BuiltinName(int key)
	{
		string value;
		return (key >> 16 == 0 && _builtin.TryGetValue(key, out value)) ? value : "";
	}

	private static void Load()
	{
		if (_loaded)
		{
			return;
		}
		_loaded = true;
		_builtin = new Dictionary<int, string>();
		string[] builtin = Builtin;
		foreach (string text in builtin)
		{
			int num = text.IndexOf('|');
			if (num > 0 && int.TryParse(text.Substring(0, num), NumberStyles.HexNumber, null, out var result))
			{
				_builtin[result] = text.Substring(num + 1);
			}
		}
		Util.Locked(FilePath, () =>
		{
			ReadFile(_list);
		});
		try
		{
			if (File.Exists(FilePath))
			{
				_fileTime = File.GetLastWriteTimeUtc(FilePath);
			}
		}
		catch
		{
		}
		try
		{
			if (!File.Exists(OldTxt))
			{
				return;
			}
			string[] array = File.ReadAllLines(OldTxt);
			foreach (string text2 in array)
			{
				string[] array2 = text2.Split('\t');
				if (array2.Length >= 2 && int.TryParse(array2[0], NumberStyles.HexNumber, null, out var result2) && !_list.ContainsKey(result2))
				{
					_list[result2] = new Entry
					{
						Lb = result2,
						Default = array2[1].Trim(),
						Updated = DateTime.Now.Ticks
					};
				}
			}
			File.Move(OldTxt, OldTxt + ".imported");
			_dirty = true;
		}
		catch
		{
		}
	}

	private static void ReadFile(Dictionary<int, Entry> into)
	{
		try
		{
			if (!File.Exists(FilePath))
			{
				return;
			}
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.Load(FilePath);
			foreach (XmlElement item in xmlDocument.SelectNodes("/Locations/L"))
			{
				if (int.TryParse(item.GetAttribute("lb"), NumberStyles.HexNumber, null, out var result))
				{
					if (int.TryParse(item.GetAttribute("v"), out var result2) && result2 > 0)
					{
						result = Key(result, result2);
					}
					Entry entry = new Entry
					{
						Lb = result,
						Default = item.GetAttribute("default"),
						Name = item.GetAttribute("name")
					};
					if (long.TryParse(item.GetAttribute("seen"), out var result3) && result3 > 0)
					{
						entry.LastSeen = new DateTime(result3);
					}
					long.TryParse(item.GetAttribute("updated"), out entry.Updated);
					into[result] = entry;
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void Save()
	{
		Util.Locked(FilePath, () =>
		{
			try
			{
				Dictionary<int, Entry> dictionary = new Dictionary<int, Entry>();
				ReadFile(dictionary);
				foreach (KeyValuePair<int, Entry> item in dictionary)
				{
					if (!_removed.Contains(item.Key) && (!_list.TryGetValue(item.Key, out var value) || item.Value.Updated > value.Updated))
					{
						_list[item.Key] = item.Value;
					}
				}
				_removed.Clear();
				XmlDocument xmlDocument = new XmlDocument();
				XmlElement xmlElement = xmlDocument.CreateElement("Locations");
				xmlElement.SetAttribute("note", "MelkTank dungeon names (Nav tab > Locations). name = yours, default = learned / built in.");
				xmlDocument.AppendChild(xmlElement);
				List<int> list = new List<int>(_list.Keys);
				list.Sort();
				foreach (int item2 in list)
				{
					Entry entry = _list[item2];
					XmlElement xmlElement2 = xmlDocument.CreateElement("L");
					xmlElement2.SetAttribute("lb", (item2 & 0xFFFF).ToString("X4"));
					if (item2 >> 16 > 0)
					{
						xmlElement2.SetAttribute("v", (item2 >> 16).ToString());
					}
					xmlElement2.SetAttribute("default", entry.Default ?? "");
					if (entry.Name.Length > 0)
					{
						xmlElement2.SetAttribute("name", entry.Name);
					}
					if (entry.LastSeen != DateTime.MinValue)
					{
						xmlElement2.SetAttribute("seen", entry.LastSeen.Ticks.ToString());
					}
					xmlElement2.SetAttribute("updated", entry.Updated.ToString());
					xmlElement.AppendChild(xmlElement2);
				}
				Util.SaveXml(xmlDocument, FilePath);
				try
				{
					_fileTime = File.GetLastWriteTimeUtc(FilePath);
				}
				catch
				{
				}
				_dirty = false;
				_savedAt = DateTime.Now;
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
		});
	}

	private static void PickUpOthers()
	{
		if ((DateTime.Now - _checkedAt).TotalSeconds < 30.0)
		{
			return;
		}
		_checkedAt = DateTime.Now;
		try
		{
			DateTime dateTime = (File.Exists(FilePath) ? File.GetLastWriteTimeUtc(FilePath) : DateTime.MinValue);
			if (dateTime <= _fileTime)
			{
				return;
			}
			_fileTime = dateTime;
			Dictionary<int, Entry> disk = new Dictionary<int, Entry>();
			Util.Locked(FilePath, () =>
			{
				ReadFile(disk);
			});
			foreach (KeyValuePair<int, Entry> item in disk)
			{
				if (!_removed.Contains(item.Key) && (!_list.TryGetValue(item.Key, out var value) || item.Value.Updated > value.Updated))
				{
					_list[item.Key] = item.Value;
					_publish = true;
				}
			}
		}
		catch
		{
		}
	}

	private static void Changed(Entry e)
	{
		if (e != null)
		{
			e.Updated = DateTime.Now.Ticks;
		}
		_dirty = true;
		_publish = true;
	}

	private static void Publish()
	{
		if (!_publish)
		{
			return;
		}
		_publish = false;
		try
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
			foreach (Entry value in _list.Values)
			{
				string shown = value.Shown;
				if (!(shown == "Unknown") && shown.Length != 0)
				{
					dictionary[(value.Lb & 0xFFFF).ToString("X4") + ((value.Lb >> 16 > 0) ? ("v" + (value.Lb >> 16)) : "")] = shown;
				}
			}
			AppDomain.CurrentDomain.SetData("MelkTank.LocNames", dictionary);
		}
		catch
		{
		}
	}

	public static void OnClientMessage(Message m)
	{
		try
		{
			if (m == null || m.Type != 63409 || m.Value<int>("action") != 54)
			{
				return;
			}
			int num = 0;
			try
			{
				num = m.Value<int>("object");
			}
			catch
			{
			}
			if (num == 0)
			{
				try
				{
					num = m.Value<int>(m.Count - 1);
				}
				catch
				{
				}
			}
			WorldObject worldObject = ((num == 0) ? null : CoreManager.Current.WorldFilter[num]);
			if (worldObject != null && worldObject.ObjectClass == ObjectClass.Portal && !string.IsNullOrEmpty(worldObject.Name))
			{
				_portalName = worldObject.Name;
				_portalAt = DateTime.Now;
			}
		}
		catch
		{
		}
	}

	public static void OnPortalExit()
	{
		_exitDue = DateTime.Now.AddSeconds(2.0);
		_exitAt = DateTime.UtcNow;
	}

	private static int VariationSince(DateTime since)
	{
		try
		{
			string text = AppDomain.CurrentDomain.GetData("MelkTank.Variation") as string;
			if (string.IsNullOrEmpty(text))
			{
				return -1;
			}
			string[] array = text.Split('|');
			if (array.Length < 2 || !long.TryParse(array[1], out var result) || !int.TryParse(array[0], out var result2))
			{
				return -1;
			}
			return (result >= since.Ticks) ? result2 : (-1);
		}
		catch
		{
			return -1;
		}
	}

	public static void Tick()
	{
		try
		{
			Load();
			PickUpOthers();
			bool flag = DateTime.Now >= _exitDue;
			if (flag)
			{
				_exitDue = DateTime.MaxValue;
			}
			uint landcell = (uint)CoreManager.Current.Actions.Landcell;
			int num = (int)(landcell >> 16);
			bool flag2 = landcell != 0 && (landcell & 0xFFFF) >= 256;
			if (!flag2)
			{
				_hereKey = -1;
			}
			if (flag2 && (flag || num != _lastLb))
			{
				_pendLb = num;
				_pendAt = DateTime.UtcNow;
				_pendPortal = flag;
				_pendSince = (flag ? _exitAt : DateTime.UtcNow);
				_pendName = ((flag && _portalName.Length > 0 && (DateTime.Now - _portalAt).TotalSeconds < 60.0) ? _portalName : "");
			}
			if (flag)
			{
				_portalName = "";
			}
			if (_pendLb >= 0)
			{
				if (!flag2 || num != _pendLb)
				{
					_pendLb = -1;
				}
				else
				{
					int num2 = VariationSince(_pendSince);
					if (num2 < 0 && (DateTime.UtcNow - _pendAt).TotalSeconds > 20.0)
					{
						num2 = 0;
					}
					if (num2 >= 0)
					{
						int num3 = (_hereKey = Key(num, num2));
						_pendLb = -1;
						if (!_list.TryGetValue(num3, out var value))
						{
							string text = BuiltinName(num3);
							value = new Entry
							{
								Lb = num3,
								Default = ((text.Length > 0) ? text : "Unknown")
							};
							_list[num3] = value;
							_removed.Remove(num3);
							if (text.Length == 0 && _pendName.Length == 0)
							{
								Util.WriteToChat("New dungeon " + Label(num3) + " added to Nav > Locations as Unknown.");
							}
						}
						if (_pendName.Length > 0)
						{
							string text2 = Clean(_pendName);
							if (text2.Length > 0 && (value.Default.Length == 0 || value.Default == "Unknown"))
							{
								value.Default = text2;
							}
						}
						value.LastSeen = DateTime.Now;
						Changed(value);
					}
				}
			}
			if (landcell != 0)
			{
				_lastLb = num;
			}
			if (_dirty && (DateTime.Now - _savedAt).TotalSeconds > 5.0)
			{
				Save();
			}
			Publish();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void Flush()
	{
		if (_dirty)
		{
			Save();
		}
	}

	private static string Clean(string n)
	{
		n = (n ?? "").Trim();
		string[] generic = Generic;
		foreach (string b in generic)
		{
			if (string.Equals(n, b, StringComparison.OrdinalIgnoreCase))
			{
				return "";
			}
		}
		if (n.StartsWith("Portal to ", StringComparison.OrdinalIgnoreCase))
		{
			n = n.Substring(10);
		}
		if (n.StartsWith("Gateway to ", StringComparison.OrdinalIgnoreCase))
		{
			n = n.Substring(11);
		}
		if (n.EndsWith(" Portal", StringComparison.OrdinalIgnoreCase))
		{
			n = n.Substring(0, n.Length - 7);
		}
		return n.Trim();
	}

	public static string Here(string areaName)
	{
		try
		{
			Load();
			uint landcell = (uint)CoreManager.Current.Actions.Landcell;
			if (landcell == 0)
			{
				return "";
			}
			int num = (int)(landcell >> 16);
			if ((landcell & 0xFFFF) >= 256)
			{
				int key = ((_hereKey >= 0 && (_hereKey & 0xFFFF) == num) ? _hereKey : num);
				if (_list.TryGetValue(key, out var value) && value.Shown != "Unknown")
				{
					return value.Shown;
				}
				string text = BuiltinName(num);
				if (text.Length > 0)
				{
					return text;
				}
				if (!string.IsNullOrEmpty(areaName))
				{
					return areaName;
				}
				return "Unknown dungeon " + num.ToString("X4");
			}
			if (!string.IsNullOrEmpty(areaName))
			{
				return areaName;
			}
			return Coords();
		}
		catch
		{
			return "";
		}
	}

	public static string Coords()
	{
		try
		{
			CoordsObject coordsObject = CoreManager.Current.WorldFilter[CoreManager.Current.CharacterFilter.Id]?.Coordinates();
			if (coordsObject == null)
			{
				return "";
			}
			return Math.Abs(coordsObject.NorthSouth).ToString("0.0") + ((coordsObject.NorthSouth >= 0.0) ? "N" : "S") + ", " + Math.Abs(coordsObject.EastWest).ToString("0.0") + ((coordsObject.EastWest >= 0.0) ? "E" : "W");
		}
		catch
		{
			return "";
		}
	}

	public static void DrawTab()
	{
		Load();
		int here = -1;
		try
		{
			uint landcell = (uint)CoreManager.Current.Actions.Landcell;
			if ((landcell & 0xFFFF) >= 256)
			{
				here = (int)(landcell >> 16);
			}
		}
		catch
		{
		}
		if (here >= 0 && _hereKey >= 0 && (_hereKey & 0xFFFF) == here)
		{
			here = _hereKey;
		}
		if (here >= 0 && _list.TryGetValue(here, out var value))
		{
			Im.TextColored(Green, "You're in " + Label(here) + ": " + value.Shown);
		}
		else if (here >= 0)
		{
			Im.TextColored(Green, "You're in dungeon " + Label(here));
		}
		else
		{
			Im.TextColored(Grey, "You're outside (the phone shows your coordinates or Area there).");
		}
		ImGui.SetNextItemWidth(200f);
		ImGui.InputTextWithHint("##locfilter", "filter by name or landblock", ref _filter, 64u);
		ImGui.SameLine();
		ImGui.Checkbox("Also show the built-in list", ref _showBuiltin);
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("The ~350 dungeons MelkTank knows by name from ACE's portals.\nOff: only the places you've been (or named).");
		}
		int num = 0;
		foreach (Entry value4 in _list.Values)
		{
			if (value4.Name.Length == 0 && value4.Default == "Unknown")
			{
				num++;
			}
		}
		if (num > 0)
		{
			ImGui.SameLine();
			Im.TextColored(Yellow, num + " unknown");
		}
		List<Entry> list = new List<Entry>(_list.Values);
		if (_showBuiltin)
		{
			foreach (KeyValuePair<int, string> item in _builtin)
			{
				if (!_list.ContainsKey(item.Key))
				{
					list.Add(new Entry
					{
						Lb = item.Key,
						Default = item.Value
					});
				}
			}
		}
		string f = _filter.Trim();
		if (f.Length > 0)
		{
			list.RemoveAll((Entry e) => e.Shown.IndexOf(f, StringComparison.OrdinalIgnoreCase) < 0 && Label(e.Lb).IndexOf(f, StringComparison.OrdinalIgnoreCase) < 0);
		}
		list.Sort((Entry a, Entry b) =>
		{
			if (a.Lb == here)
			{
				return -1;
			}
			if (b.Lb == here)
			{
				return 1;
			}
			int num3 = b.LastSeen.CompareTo(a.LastSeen);
			return (num3 != 0) ? num3 : string.Compare(a.Shown, b.Shown, StringComparison.OrdinalIgnoreCase);
		});
		ImGuiTableFlags flags = ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY;
		if (!ImGui.BeginTable("loctable", 5, flags, new Vector2(0f, 0f)))
		{
			return;
		}
		ImGui.TableSetupColumn("Landblock", ImGuiTableColumnFlags.WidthFixed, 80f);
		ImGui.TableSetupColumn("Name (yours)", ImGuiTableColumnFlags.WidthStretch);
		ImGui.TableSetupColumn("Default", ImGuiTableColumnFlags.WidthFixed, 170f);
		ImGui.TableSetupColumn("Last here", ImGuiTableColumnFlags.WidthFixed, 90f);
		ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 80f);
		ImGui.TableSetupScrollFreeze(0, 1);
		ImGui.TableHeadersRow();
		int num2 = -1;
		foreach (Entry item2 in list)
		{
			bool flag = item2.Lb == here;
			bool flag2 = _list.ContainsKey(item2.Lb);
			ImGui.TableNextRow();
			if (flag)
			{
				ImGui.TableSetBgColor(ImGuiTableBgTarget.RowBg0, ImGui.GetColorU32(new Vector4(0.2f, 0.45f, 0.2f, 0.6f)));
			}
			ImGui.PushID(item2.Lb);
			ImGui.TableSetColumnIndex(0);
			ImGui.PushStyleColor(ImGuiCol.Text, flag ? Green : Cyan);
			if (ImGui.Selectable(Label(item2.Lb) + "##lb", selected: false))
			{
				try
				{
					AppDomain.CurrentDomain.SetData("MelkTank.ShowPlace", (item2.Lb & 0xFFFF).ToString("X4") + "|" + ((item2.Lb >> 16 > 0) ? ("v" + (item2.Lb >> 16)) : "") + "|" + DateTime.UtcNow.Ticks);
				}
				catch
				{
				}
			}
			ImGui.PopStyleColor();
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Click: show it on MelksQB's map (the dungeon's own map, or where its way in is)." + ((item2.Lb >> 16 > 0) ? ("\nv:" + (item2.Lb >> 16) + " = a version of dungeon " + (item2.Lb & 0xFFFF).ToString("X4") + " (the same rooms, used as another dungeon).") : ""));
			}
			ImGui.TableSetColumnIndex(1);
			if (!_edit.TryGetValue(item2.Lb, out var value2))
			{
				value2 = item2.Name;
			}
			ImGui.SetNextItemWidth(-1f);
			if (ImGui.InputTextWithHint("##n", (item2.Default == "Unknown") ? "Unknown - type a name" : item2.Default, ref value2, 80u))
			{
				_edit[item2.Lb] = value2;
			}
			if (ImGui.IsItemDeactivatedAfterEdit())
			{
				if (!_list.TryGetValue(item2.Lb, out var value3))
				{
					value3 = new Entry
					{
						Lb = item2.Lb,
						Default = item2.Default
					};
					_list[item2.Lb] = value3;
					_removed.Remove(item2.Lb);
				}
				value3.Name = ((value2.Trim() == value3.Default) ? "" : value2.Trim());
				_edit.Remove(item2.Lb);
				Changed(value3);
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Type a name and press Enter (or click away). Empty = the default.");
			}
			ImGui.TableSetColumnIndex(2);
			Im.TextColored((item2.Default == "Unknown") ? Yellow : Grey, item2.Default);
			ImGui.TableSetColumnIndex(3);
			Im.TextColored(Grey, (item2.LastSeen == DateTime.MinValue) ? "-" : Ago(item2.LastSeen));
			ImGui.TableSetColumnIndex(4);
			if (flag2 && item2.Name.Length > 0)
			{
				if (ImGui.SmallButton("Default"))
				{
					item2.Name = "";
					_edit.Remove(item2.Lb);
					Changed(item2);
				}
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip("Back to the default name: " + item2.Default);
				}
				ImGui.SameLine();
			}
			if (flag2 && ImGui.SmallButton("x"))
			{
				num2 = item2.Lb;
			}
			if (flag2 && ImGui.IsItemHovered())
			{
				Im.SetTooltip("Remove from the list (it's added again next time you're there).");
			}
			ImGui.PopID();
		}
		ImGui.EndTable();
		if (num2 >= 0)
		{
			_list.Remove(num2);
			_removed.Add(num2);
			_dirty = true;
			_publish = true;
		}
	}

	private static string Ago(DateTime t)
	{
		TimeSpan timeSpan = DateTime.Now - t;
		if (timeSpan.TotalMinutes < 1.0)
		{
			return "now";
		}
		if (timeSpan.TotalHours < 1.0)
		{
			return (int)timeSpan.TotalMinutes + "m ago";
		}
		if (timeSpan.TotalDays < 1.0)
		{
			return (int)timeSpan.TotalHours + "h ago";
		}
		return (int)timeSpan.TotalDays + "d ago";
	}
}
