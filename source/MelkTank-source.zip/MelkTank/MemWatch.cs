using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;

namespace MelkTank;

public static class MemWatch
{
	private static DateTime _next = DateTime.MinValue;

	private static DateTime _nextLog = DateTime.MinValue;

	private static bool _toldNoLauncher;

	public static long InUse { get; private set; }

	public static DateTime PendingSince { get; private set; } = DateTime.MinValue;

	public static bool Relogging { get; private set; }

	public static double GB => (double)InUse / 1073741824.0;

	private static void LogLine(CombatEngine e)
	{
		string text = "";
		try
		{
			text = Globals.Core.CharacterFilter.Name ?? "";
		}
		catch
		{
		}
		StringBuilder stringBuilder = new StringBuilder();
		string text2 = text;
		foreach (char c in text2)
		{
			stringBuilder.Append(char.IsLetterOrDigit(c) ? c : '_');
		}
		if (stringBuilder.Length == 0)
		{
			return;
		}
		string path = Util.FullPath("MelkTank_MemLog_" + stringBuilder?.ToString() + ".csv");
		long num = 0L;
		long num2 = 0L;
		try
		{
			Process currentProcess = Process.GetCurrentProcess();
			currentProcess.Refresh();
			num = currentProcess.PrivateMemorySize64;
			num2 = currentProcess.WorkingSet64;
		}
		catch
		{
		}
		if (num <= 0)
		{
			num = HotCleanup.PrivateBytes();
		}
		long used = 0L;
		HotCleanup.AddressSpace(out used, out var _);
		long totalMemory = GC.GetTotalMemory(forceFullCollection: false);
		int num3 = 0;
		int num4 = 0;
		Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
		foreach (Assembly assembly in assemblies)
		{
			num4++;
			if (assembly.FullName.StartsWith("MelkTankCore,", StringComparison.Ordinal))
			{
				num3++;
			}
		}
		int num5 = -1;
		int num6 = -1;
		try
		{
			num5 = Globals.Core.WorldFilter.GetAll().Count;
		}
		catch
		{
		}
		try
		{
			num6 = Globals.Core.WorldFilter.GetInventory().Count;
		}
		catch
		{
		}
		long num7 = 0L;
		try
		{
			num7 = Session.Kills;
		}
		catch
		{
		}
		bool flag = !File.Exists(path);
		string text3 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "," + (num >> 20) + "," + (num2 >> 20) + "," + (used >> 20) + "," + (totalMemory >> 20) + "," + Math.Max(0L, num - totalMemory >> 20) + "," + num3 + "," + num4 + "," + num5 + "," + num6 + "," + num7 + "," + GC.CollectionCount(2);
		Util.AppendShared(path, (flag ? ("time,private MB,in use MB,address space MB,.NET heap MB,rest (client + native) MB,MelkTank builds loaded,assemblies,objects known,inventory,kills,gen2 GCs" + Environment.NewLine) : "") + text3 + Environment.NewLine);
	}

	// ── ACGodot: where its memory goes, a line a minute (Advanced > ACGodot memory; off = nothing is measured or written) ──

	private const string GodotHeader = "time,resident MB,private MB,.NET heap MB,gen2 GCs,Godot static MB,video MB,texture MB,Godot objects,nodes,orphan nodes,resources,fps,things known,inventory,kills,assemblies";

	private static bool _headerChecked;

	private static DateTime _nextSize;

	public static void Tick(Settings s, CombatEngine e)
	{
		if (s == null || e == null)
		{
			return;
		}
		DateTime now = DateTime.Now;
		// how much the game has in use now (shown beside the relog size, and what that goes by): measured every few
		// seconds whether the log is on or not
		if (now >= _nextSize)
		{
			_nextSize = now.AddSeconds(5.0);
			try
			{
				Process p = Process.GetCurrentProcess();
				p.Refresh();
				InUse = p.WorkingSet64;
			}
			catch
			{
			}
		}
		if (!s.MemLog)
		{
			return;
		}
		if (now < _nextLog)
		{
			return;
		}
		_nextLog = now.AddSeconds(60.0);
		try
		{
			LogGodot();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static double Mon(Godot.Performance.Monitor m)
	{
		try
		{
			return Godot.Performance.GetMonitor(m);
		}
		catch
		{
			return -1.0;
		}
	}

	private static void LogGodot()
	{
		string name = "";
		try
		{
			name = Globals.Core.CharacterFilter.Name ?? "";
		}
		catch
		{
		}
		StringBuilder sb = new StringBuilder();
		foreach (char c in name)
		{
			sb.Append(char.IsLetterOrDigit(c) ? c : '_');
		}
		if (sb.Length == 0)
		{
			return;   // not in the world yet
		}
		string path = Util.FullPath("MelkTank_MemLog_" + sb + ".csv");
		long priv = 0L, res = 0L;
		try
		{
			Process p = Process.GetCurrentProcess();
			p.Refresh();
			priv = p.PrivateMemorySize64;
			res = p.WorkingSet64;
		}
		catch
		{
		}
		InUse = res;
		long heap = GC.GetTotalMemory(forceFullCollection: false);
		int known = -1, inv = -1;
		try { known = Globals.Core.WorldFilter.GetAll().Count; } catch { }
		try { inv = Globals.Core.WorldFilter.GetInventory().Count; } catch { }
		long kills = 0L;
		try { kills = Session.Kills; } catch { }
		string line = string.Join(",", new string[]
		{
			DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
			(res >> 20).ToString(), (priv >> 20).ToString(), (heap >> 20).ToString(), GC.CollectionCount(2).ToString(),
			((long)Mon(Godot.Performance.Monitor.MemoryStatic) >> 20).ToString(),
			((long)Mon(Godot.Performance.Monitor.RenderVideoMemUsed) >> 20).ToString(),
			((long)Mon(Godot.Performance.Monitor.RenderTextureMemUsed) >> 20).ToString(),
			((long)Mon(Godot.Performance.Monitor.ObjectCount)).ToString(),
			((long)Mon(Godot.Performance.Monitor.ObjectNodeCount)).ToString(),
			((long)Mon(Godot.Performance.Monitor.ObjectOrphanNodeCount)).ToString(),
			((long)Mon(Godot.Performance.Monitor.ObjectResourceCount)).ToString(),
			((long)Mon(Godot.Performance.Monitor.TimeFps)).ToString(),
			known.ToString(), inv.ToString(), kills.ToString(), AppDomain.CurrentDomain.GetAssemblies().Length.ToString()
		});
		// (a file from an older build has other columns: it's set aside, and this one starts clean)
		if (!_headerChecked)
		{
			_headerChecked = true;
			try
			{
				if (File.Exists(path))
				{
					string first;
					using (StreamReader r = new StreamReader(path))
					{
						first = r.ReadLine() ?? "";
					}
					if (first != GodotHeader)
					{
						string aside = Path.ChangeExtension(path, null) + ".old-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + ".csv";
						File.Move(path, aside);
					}
				}
			}
			catch
			{
			}
		}
		bool fresh = !File.Exists(path);
		Util.AppendShared(path, (fresh ? (GodotHeader + Environment.NewLine) : "") + line + Environment.NewLine);
	}
}
