using System.Collections.Generic;

namespace MelkTank;

public class NavRoute
{
	public string Name = "";

	public int Mode = 2;

	public float Arrive = 2.5f;

	public List<RouteStep> Steps = new List<RouteStep>();

	public string File = "";

	public int StuckAction;

	public int StuckBack = 2;

	public int StuckAfter = 1;

	public bool RestartIfFar;

	public float RestartFarM = 100f;

	public bool RestartIfStuck;

	public float RestartStuckMin = 4f;
}
