namespace MelkTank;

public class NavSpot
{
	public string Name = "";

	public double NS;

	public double EW;

	public double Z;

	public double Heading = -1.0;

	public bool FaceHeading = true;

	public string File = "";
}
