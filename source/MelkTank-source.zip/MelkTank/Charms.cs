using System;
using System.Collections.Generic;
using System.Numerics;
using System.Text.RegularExpressions;
#if !RETAIL
using AcClient;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Loot;

namespace MelkTank;

public static class Charms
{
	private class Row
	{
		public int Id;

		public string Name;

		public string St = "";
	}

	private class Gem
	{
		public int Id;

		public long Size;
	}

	private static readonly Vector4 Green = new Vector4(0.45f, 0.9f, 0.45f, 1f);

	private static readonly Vector4 Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f);

	private static readonly Vector4 Yellow = new Vector4(0.95f, 0.85f, 0.35f, 1f);

	private static readonly Vector4 Cyan = new Vector4(0.35f, 0.85f, 0.95f, 1f);

	private static readonly Regex StatusRx = new Regex("Status:\\s*(ON|OFF)", RegexOptions.IgnoreCase);

	private static readonly Regex LevelRx = new Regex("Level\\s+(\\d+)(?:\\s*\\((\\d+)%\\s*to\\s*(\\d+)\\))?", RegexOptions.IgnoreCase);

	private static readonly Regex TierRx = new Regex("Tier\\s+(\\d+)\\s*/\\s*(\\d+)", RegexOptions.IgnoreCase);

	private static readonly Regex CoinsRx = new Regex("Prestige Coins put in:\\s*([\\d,]+)(?:\\s*-\\s*next level in\\s*([\\d,]+))?", RegexOptions.IgnoreCase);

	private static readonly Dictionary<int, DateTime> _askedAt = new Dictionary<int, DateTime>();

	private static readonly Dictionary<int, DateTime> _toggledAt = new Dictionary<int, DateTime>();

	private static Settings _s;

	private static readonly Regex ChatRx = new Regex("^(.+?) (activated|deactivated)\\b", RegexOptions.IgnoreCase);

	private static readonly Regex Boiler = new Regex("^(Charm\\s*\\[|Prestige Coins|Status:|Double[ -]click to toggle|A charm for |Charm: Holding)", RegexOptions.IgnoreCase);

	private static readonly Regex LeadActivate = new Regex("^Double[ -]click to activate(?:\\s*\\([^)]*\\))?\\.\\s*", RegexOptions.IgnoreCase);

	private static readonly Regex GemSizeRx = new Regex("Charm Infusion Gems?\\s*\\(([\\d,]+)\\)", RegexOptions.IgnoreCase);

	private static string _status = "";

	private static int _vendorSeen;

	private static DateTime _buyAskedAt = DateTime.MinValue;

	private static bool _buyByHand;

	private static readonly Queue<int> _useQueue = new Queue<int>();

	private static int _useOn;

	private static string _useName = "";

	private static DateTime _useNext = DateTime.MinValue;

	public static void Init(Settings s)
	{
		_s = s;
		GearSnap.CharmIds = () =>
		{
			List<int> list = new List<int>();
			if (_s != null)
			{
				foreach (Row item in Parse(_s.Charms))
				{
					list.Add(item.Id);
				}
			}
			return list;
		};
	}

	public static void OnChat(string text)
	{
		if (_s == null || string.IsNullOrEmpty(_s.Charms))
		{
			return;
		}
		Match match = ChatRx.Match((text ?? "").Trim());
		if (!match.Success)
		{
			return;
		}
		List<Row> list = Parse(_s.Charms);
		bool flag = false;
		foreach (Row item in list)
		{
			if (string.Equals(item.Name, match.Groups[1].Value.Trim(), StringComparison.OrdinalIgnoreCase))
			{
				item.St = (match.Groups[2].Value.Equals("activated", StringComparison.OrdinalIgnoreCase) ? "1" : "0");
				_toggledAt.Remove(item.Id);
				flag = true;
			}
		}
		if (flag)
		{
			_s.Charms = Join(list);
		}
	}

	private static List<Row> Parse(string s)
	{
		List<Row> list = new List<Row>();
		string[] array = (s ?? "").Split(new char[1] { '|' }, StringSplitOptions.RemoveEmptyEntries);
		foreach (string text in array)
		{
			string[] array2 = text.Split(':');
			if (int.TryParse(array2[0], out var result))
			{
				list.Add(new Row
				{
					Id = result,
					Name = ((array2.Length > 1) ? array2[1] : ""),
					St = ((array2.Length > 2) ? array2[2] : "")
				});
			}
		}
		return list;
	}

	private static string Join(List<Row> l)
	{
		List<string> list = new List<string>();
		foreach (Row item in l)
		{
			list.Add(item.Id + ":" + (item.Name ?? "").Replace("|", "").Replace(":", "") + ":" + item.St);
		}
		return string.Join("|", list.ToArray());
	}

	public static string Text(WorldObject o)
	{
		if (o == null)
		{
			return "";
		}
		string text = "";
		string text2 = "";
		text = LootMatcher.Str(o, 14);
		text2 = LootMatcher.Str(o, 16);
		return (text2.Length > 0 && text.IndexOf(text2, StringComparison.Ordinal) < 0) ? (((text.Length > 0) ? (text + "\n\n") : "") + text2) : text;
	}

	public static string Basics(WorldObject o)
	{
		if (o == null)
		{
			return "";
		}
		string text = LootMatcher.Str(o, 16) ?? "";
		string text2 = ((text.Trim().Length > 0) ? text : (LootMatcher.Str(o, 14) ?? ""));
		List<string> list = new List<string>();
		string[] array = text2.Replace("\r", "").Split('\n');
		foreach (string text3 in array)
		{
			string text4 = text3.Trim();
			if (text4.Length != 0 && !Boiler.IsMatch(text4))
			{
				text4 = LeadActivate.Replace(text4, "");
				text4 = Regex.Replace(text4, "\\s*Its power grows with its level\\.?", "");
				if (text4.Equals("Works only in T11+ zones.", StringComparison.OrdinalIgnoreCase))
				{
					text4 = "(T11+ zones only)";
				}
				if (text4.Length > 0)
				{
					list.Add(text4);
				}
			}
		}
		if (list.Count == 0)
		{
			List<string> list2 = SpellNames.Of(o);
			if (list2.Count > 0)
			{
				return "Grants " + string.Join(", ", list2.ToArray()) + " while you carry it.";
			}
		}
		return string.Join(" ", list.ToArray());
	}

	/// <summary>For the mouse-over: a charm's status, and a tier charm's level (effective [its own]) and the coins to its next.
	/// Empty when it isn't a charm.</summary>
	public static List<string> HoverLines(WorldObject o, out bool? on)
	{
		on = null;
		List<string> l = new List<string>();
		if (o == null)
		{
			return l;
		}
		string text = Text(o);
		int lvl = LootMatcher.Long(o, 50005), active = LootMatcher.Long(o, 50016);
		bool charm = lvl > 0 || active > 0 || StatusRx.IsMatch(text) || o.Name.IndexOf("Charm", StringComparison.OrdinalIgnoreCase) >= 0;
		if (!charm)
		{
			return l;
		}
		if (text.IndexOf("Holding this item grants", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			on = true;
			l.Add("Status: Always on");
		}
		else
		{
			on = Status(o);
			if (on.HasValue)
			{
				l.Add("Status: " + (on.Value ? "On" : "Off"));
			}
		}
		if (lvl <= 0)
		{
			Match m = LevelRx.Match(text);
			if (m.Success)
			{
				int.TryParse(m.Groups[1].Value, out lvl);
			}
		}
		if (lvl > 0)
		{
			// (the level working where you are - capped by the zone's tier - then its own in brackets)
			int eff = (active > 0) ? active : lvl;
			l.Add("Charm Level: " + eff + ((eff != lvl) ? (" [" + lvl + "]") : ""));
			Match c = CoinsRx.Match(text);
			if (c.Success && c.Groups[2].Success)
			{
				l.Add("Prestige Coins to Level " + (lvl + 1) + ": " + c.Groups[2].Value);
			}
		}
		return l;
	}

	public static bool? Status(WorldObject o)
	{
		Match match = StatusRx.Match(Text(o));
		if (match.Success)
		{
			return match.Groups[1].Value.Equals("ON", StringComparison.OrdinalIgnoreCase);
		}
		return null;
	}

	private static void Ask(int id, double everyS)
	{
		if (_askedAt.TryGetValue(id, out var value) && (DateTime.Now - value).TotalSeconds < everyS)
		{
			return;
		}
		_askedAt[id] = DateTime.Now;
		try
		{
			Util.RequestId(id);
		}
		catch
		{
		}
	}

	public static bool Draw(Settings s)
	{
		bool result = false;
		List<Row> list = Parse(s.Charms);
		long num = Session.PrestigeCoins(out var bankAt);
		Im.TextColored(new Vector4(0.95f, 0.85f, 0.35f, 1f), "Prestige Coins: " + ((num >= 0) ? num.ToString("N0") : "?"));
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip((num >= 0) ? ("In your bank: the last /bank (" + bankAt.ToString("MMM d HH:mm") + ") plus the coins added since.") : "Not known yet - click /bank.");
		}
		ImGui.SameLine();
		if (ImGui.SmallButton("/bank##charmbank"))
		{
			try
			{
				Session.QuietNext("/bank");
				Util.Command("/bank");
			}
			catch
			{
			}
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Reads your bank again (the lines stay out of chat).");
		}
		if (ImGui.Button("Add selected##charmadd"))
		{
			int num2 = 0;
			try
			{
				num2 = Globals.Core.Actions.CurrentSelection;
			}
			catch
			{
			}
			WorldObject o = ((num2 != 0) ? Globals.Core.WorldFilter[num2] : null);
			if (o == null)
			{
				Util.WriteToChat("Charms: select a charm first.");
			}
			else if (list.Exists((Row r) => r.Id == o.Id))
			{
				Util.WriteToChat("Charms: " + o.Name + " is already on the list.");
			}
			else
			{
				list.Add(new Row
				{
					Id = o.Id,
					Name = o.Name
				});
				s.Charms = Join(list);
				result = true;
				Ask(o.Id, 0.0);
				if (o.Name.IndexOf("Charm", StringComparison.OrdinalIgnoreCase) < 0 && Text(o).IndexOf("Charm", StringComparison.OrdinalIgnoreCase) < 0)
				{
					Util.WriteToChat("Charms: added " + o.Name + " - it doesn't look like a charm, but it's on the list.");
				}
			}
		}
		Tip("Select a charm in your pack, then click to add it here.");
		ImGui.SameLine();
		if (ImGui.Button("Refresh##charmref"))
		{
			foreach (Row item in list)
			{
				Ask(item.Id, 0.0);
			}
		}
		Tip("Asks the game for each charm's ID again (its status, level and coins).");
		ImGui.SameLine();
		Im.TextColored(Grey, "Toggle = double-clicking it. Hover a name for its full text.");
		if (ImGui.Checkbox("Auto-buy infusion gems##cgab", ref s.CharmGemAutoBuy))
		{
			result = true;
		}
		Tip("When the vendor selling Charm Infusion Gems is opened: checks /bank, then spends all your Prestige Coins\non them - the biggest gems first, then smaller ones for what's left.\n/mt set CharmGemAutoBuy on|off");
		Dictionary<int, WorldObject> dictionary = VendorGems();
		if (dictionary.Count > 0)
		{
			ImGui.SameLine();
			if (ImGui.SmallButton("Buy gems now##cgbuy"))
			{
				StartBuy(byHand: true);
			}
			Tip("Checks /bank, then buys as many Charm Infusion Gems as your Prestige Coins pay for (biggest first).");
		}
		ImGui.SameLine();
		List<Gem> list2 = PackGems();
		long num3 = 0L;
		foreach (Gem item2 in list2)
		{
			num3 += item2.Size;
		}
		Im.TextColored(Grey, "Gems in your pack: " + list2.Count + ((list2.Count > 0) ? (" (" + num3.ToString("N0") + " coins)") : "") + ((_status.Length > 0) ? ("   " + _status) : ""));
		if (list.Count == 0)
		{
			Im.TextColored(Grey, "No charms yet - select one and click Add selected.");
			return result;
		}
		int num4 = -1;
		int num5 = -1;
		if (ImGui.BeginTable("##charms", 8, ImGuiTableFlags.RowBg | ImGuiTableFlags.BordersInnerH | ImGuiTableFlags.SizingFixedFit, new Vector2(ImGui.GetContentRegionAvail().X - 4f, 0f)))
		{
			ImGui.TableSetupColumn("Charm", ImGuiTableColumnFlags.WidthFixed, 210f);
			ImGui.TableSetupColumn("Level", ImGuiTableColumnFlags.WidthFixed, 120f);
			ImGui.TableSetupColumn("Status", ImGuiTableColumnFlags.WidthFixed, 50f);
			ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 56f);
			ImGui.TableSetupColumn("Prestige Coins", ImGuiTableColumnFlags.WidthFixed, 140f);
			ImGui.TableSetupColumn("Gems", ImGuiTableColumnFlags.WidthFixed, 82f);
			ImGui.TableSetupColumn("What it does", ImGuiTableColumnFlags.WidthStretch);
			ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 56f);
			ImGui.TableHeadersRow();
			for (int num6 = 0; num6 < list.Count; num6++)
			{
				Row row = list[num6];
				WorldObject worldObject = Globals.Core.WorldFilter[row.Id];
				ImGui.PushID("charm" + row.Id);
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				string text;
				if (worldObject != null)
				{
					text = worldObject.Name;
				}
				else
				{
					text = ((row.Name.Length > 0) ? row.Name : ("#" + row.Id));
				}
				if (worldObject != null && worldObject.Name != row.Name)
				{
					row.Name = worldObject.Name;
					s.Charms = Join(list);
					result = true;
				}
				Im.TextColored((worldObject != null) ? Vector4.One : Grey, text);
				string text2 = Text(worldObject);
				if (ImGui.IsItemHovered())
				{
					string tooltip;
					if (worldObject == null)
					{
						tooltip = "Not in your pack right now.";
					}
					else
					{
						tooltip = ((text2.Length > 0) ? text2 : "Not identified yet - asking.");
					}
					Im.SetTooltip(tooltip);
				}
				if (worldObject != null && ((!worldObject.HasIdData && !GearSnap.Has(row.Id)) || text2.Length == 0))
				{
					Ask(row.Id, 10.0);
				}
				bool flag = text2.IndexOf("Holding this item grants", StringComparison.OrdinalIgnoreCase) >= 0;
				ImGui.TableSetColumnIndex(1);
				Match match = LevelRx.Match(text2);
				Match match2 = TierRx.Match(text2);
				if (match.Success)
				{
					Im.TextColored(Cyan, "Lvl " + match.Groups[1].Value + (match.Groups[2].Success ? ("  (" + match.Groups[2].Value + "% to " + match.Groups[3].Value + ")") : ""));
				}
				else if (match2.Success)
				{
					Im.TextColored(Cyan, "Tier " + match2.Groups[1].Value + "/" + match2.Groups[2].Value);
				}
				else
				{
					Im.TextColored(Grey, "-");
				}
				ImGui.TableSetColumnIndex(2);
				bool? flag2 = ((worldObject != null) ? Status(worldObject) : ((bool?)null));
				if (!flag2.HasValue && row.St.Length > 0)
				{
					flag2 = row.St == "1";
				}
				bool flag3 = _toggledAt.TryGetValue(row.Id, out var value) && (DateTime.Now - value).TotalSeconds < 6.0;
				if (flag3 && (DateTime.Now - value).TotalSeconds > 1.2)
				{
					Ask(row.Id, 1.5);
				}
				if (flag)
				{
					Im.TextColored(Green, "Always");
					if (ImGui.IsItemHovered())
					{
						Im.SetTooltip("Works while you carry it - it can't be switched off.");
					}
				}
				else if (!flag2.HasValue)
				{
					Im.TextColored(Grey, "?");
					if (ImGui.IsItemHovered())
					{
						Im.SetTooltip("Not known yet - Toggle it once (the game says activated / deactivated in chat).");
					}
				}
				else
				{
					Im.TextColored(flag2.Value ? Green : Grey, flag2.Value ? "ON" : "OFF");
				}
				if (flag3)
				{
					ImGui.SameLine(0f, 2f);
					Im.TextColored(Yellow, "*");
				}
				ImGui.TableSetColumnIndex(3);
				bool flag4 = (worldObject == null) | flag;
				if (flag4)
				{
					ImGui.BeginDisabled();
				}
				if (ImGui.SmallButton("Toggle"))
				{
					try
					{
						Globals.Core.Actions.UseItem(row.Id, 0);
						_toggledAt[row.Id] = DateTime.Now;
						_askedAt.Remove(row.Id);
					}
					catch (Exception ex)
					{
						Util.WriteToChat("Charms: couldn't use " + text + ": " + ex.Message);
					}
				}
				if (flag4)
				{
					ImGui.EndDisabled();
				}
				Tip("Uses the charm (like double-clicking it) - turns it on or off.");
				ImGui.TableSetColumnIndex(4);
				Match match3 = CoinsRx.Match(text2);
				if (match3.Success)
				{
					ImGui.TextUnformatted(match3.Groups[1].Value + " in" + (match3.Groups[2].Success ? (" | " + match3.Groups[2].Value + " to next") : ""));
					if (ImGui.IsItemHovered())
					{
						Im.SetTooltip("Prestige Coins put into it, and how many more for its next level.");
					}
				}
				ImGui.TableSetColumnIndex(5);
				if (match3.Success && worldObject != null)
				{
					long result2 = 0L;
					if (match3.Groups[2].Success)
					{
						long.TryParse(match3.Groups[2].Value.Replace(",", ""), out result2);
					}
					bool flag5 = list2.Count == 0 || _useQueue.Count > 0;
					if (flag5)
					{
						ImGui.BeginDisabled();
					}
					if (ImGui.SmallButton("All##cgall"))
					{
						QueueUse(row.Id, text, list2, -1L);
					}
					Tip("Uses every Charm Infusion Gem in your pack on " + text + " (" + num3.ToString("N0") + " coins).");
					ImGui.SameLine(0f, 4f);
					if (result2 <= 0)
					{
						ImGui.BeginDisabled();
					}
					if (ImGui.SmallButton("Next##cgnext"))
					{
						QueueUse(row.Id, text, list2, result2);
					}
					if (result2 <= 0)
					{
						ImGui.EndDisabled();
					}
					Tip("Uses just enough gems on " + text + " for its next level (" + result2.ToString("N0") + " coins) - the extra carries over.");
					if (flag5)
					{
						ImGui.EndDisabled();
					}
				}
				ImGui.TableSetColumnIndex(6);
				string text3 = ((worldObject != null) ? Basics(worldObject) : "");
				if (text3.Length > 0)
				{
					ImGui.PushTextWrapPos(0f);
					ImGui.TextUnformatted(text3);
					ImGui.PopTextWrapPos();
				}
				else
				{
					Im.TextColored(Grey, (worldObject == null) ? "not in your pack" : "not identified yet");
				}
				ImGui.TableSetColumnIndex(7);
				if (num6 > 0 && Im.UpButton("##cup"))
				{
					num5 = num6;
				}
				if (num6 > 0)
				{
					ImGui.SameLine();
				}
				if (ImGui.SmallButton("x"))
				{
					num4 = num6;
				}
				ImGui.PopID();
			}
			ImGui.EndTable();
		}
		if (num5 > 0)
		{
			Im.Move(list, num5, up: true);
			s.Charms = Join(list);
			result = true;
		}
		if (num4 >= 0)
		{
			list.RemoveAt(num4);
			s.Charms = Join(list);
			result = true;
		}
		return result;
	}

	private static long GemSize(string name)
	{
		Match match = GemSizeRx.Match(name ?? "");
		long result;
		return (match.Success && long.TryParse(match.Groups[1].Value.Replace(",", ""), out result)) ? result : 0;
	}

	private static Dictionary<int, WorldObject> VendorGems()
	{
		Dictionary<int, WorldObject> dictionary = new Dictionary<int, WorldObject>();
		try
		{
			Vendor openVendor = CoreManager.Current.WorldFilter.OpenVendor;
			if (openVendor == null || openVendor.MerchantId == 0)
			{
				return dictionary;
			}
			foreach (WorldObject item in openVendor)
			{
				long num = GemSize(item.Name);
				if (num > 0 && num <= int.MaxValue && !dictionary.ContainsKey((int)num))
				{
					dictionary[(int)num] = item;
				}
			}
		}
		catch
		{
		}
		return dictionary;
	}

	private static List<Gem> PackGems()
	{
		List<Gem> list = new List<Gem>();
		foreach (WorldObject item in InvCache.All())
		{
			long num = GemSize(item.Name);
			if (num > 0)
			{
				int num2 = 1;
				try
				{
					num2 = Math.Max(1, item.Values(LongValueKey.StackCount, 1));
				}
				catch
				{
				}
				for (int i = 0; i < num2; i++)
				{
					list.Add(new Gem
					{
						Id = item.Id,
						Size = num
					});
				}
			}
		}
		return list;
	}

	private static void StartBuy(bool byHand)
	{
		_buyByHand = byHand;
		_buyAskedAt = DateTime.Now;
		_status = "checking /bank...";
		try
		{
			Session.QuietNext("/bank");
			Util.Command("/bank");
		}
		catch
		{
		}
	}

	private static void Buy()
	{
		long num = Session.PrestigeCoins(out var _);
		Dictionary<int, WorldObject> dictionary = VendorGems();
		if (dictionary.Count == 0)
		{
			_status = "the vendor closed";
			return;
		}
		List<int> list = new List<int>(dictionary.Keys);
		list.Sort((int x, int y) => y.CompareTo(x));
		long num2 = num;
		List<string> list2 = new List<string>();
		try
		{
			HooksWrapper actions = CoreManager.Current.Actions;
			actions.VendorClearBuyList();
			foreach (int item in list)
			{
				long num3 = num2 / item;
				if (num3 > 0)
				{
					actions.VendorAddBuyList(dictionary[item].Id, (int)Math.Min(num3, 1000L));
					list2.Add(num3 + " x " + item.ToString("N0"));
					num2 -= num3 * item;
				}
			}
			if (list2.Count > 0)
			{
				actions.VendorBuyAll();
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		_status = ((list2.Count > 0) ? ("bought " + string.Join(", ", list2.ToArray())) : ("not enough Prestige Coins (" + Math.Max(0L, num) + ")"));
		if (list2.Count > 0 || _buyByHand)
		{
			Util.WriteToChat("Charms: " + _status + " Charm Infusion Gems" + ((list2.Count > 0) ? (" (" + (num - num2).ToString("N0") + " Prestige Coins).") : "."));
		}
	}

	private static void QueueUse(int charmId, string name, List<Gem> have, long need)
	{
		List<Gem> list = new List<Gem>();
		if (need < 0)
		{
			list.AddRange(have);
		}
		else
		{
			List<Gem> list2 = new List<Gem>(have);
			list2.Sort((Gem x, Gem y) => y.Size.CompareTo(x.Size));
			long left;
			Gem gem;
			for (left = need; left > 0; left -= gem.Size)
			{
				if (list2.Count <= 0)
				{
					break;
				}
				gem = list2.Find((Gem x) => x.Size <= left);
				if (gem == null)
				{
					gem = list2[list2.Count - 1];
					for (int num = list2.Count - 1; num >= 0; num--)
					{
						if (list2[num].Size >= left)
						{
							gem = list2[num];
							break;
						}
					}
				}
				list.Add(gem);
				list2.Remove(gem);
			}
		}
		if (list.Count == 0)
		{
			return;
		}
		_useQueue.Clear();
		long num2 = 0L;
		foreach (Gem item in list)
		{
			_useQueue.Enqueue(item.Id);
			num2 += item.Size;
		}
		_useOn = charmId;
		_useName = name;
		_useNext = DateTime.Now;
		Util.WriteToChat("Charms: using " + list.Count + " infusion gem" + ((list.Count == 1) ? "" : "s") + " (" + num2.ToString("N0") + " coins) on " + name + "...");
	}

	public static void Tick()
	{
		if (_s == null)
		{
			return;
		}
		int num = 0;
		try
		{
			num = CoreManager.Current.WorldFilter.OpenVendor?.MerchantId ?? 0;
		}
		catch
		{
		}
		if (num == 0)
		{
			_vendorSeen = 0;
		}
		else if (num != _vendorSeen && _buyAskedAt == DateTime.MinValue)
		{
			_vendorSeen = num;
			if (_s.CharmGemAutoBuy && VendorGems().Count > 0)
			{
				StartBuy(byHand: false);
			}
		}
		if (_buyAskedAt != DateTime.MinValue)
		{
			Session.PrestigeCoins(out var bankAt);
			if (bankAt > _buyAskedAt)
			{
				_buyAskedAt = DateTime.MinValue;
				Buy();
			}
			else if ((DateTime.Now - _buyAskedAt).TotalSeconds > 8.0)
			{
				_buyAskedAt = DateTime.MinValue;
				_status = "no answer from /bank";
			}
		}
		if (_useQueue.Count <= 0 || !(DateTime.Now >= _useNext))
		{
			return;
		}
		int num2 = _useQueue.Dequeue();
		WorldObject worldObject = Globals.Core.WorldFilter[num2];
		if (worldObject != null)
		{
			try
			{
				Remote.ExpectYes(4.0, "Prestige Coin");
				CM_Inventory.Event_UseWithTargetEvent((uint)num2, (uint)_useOn);
			}
			catch (Exception ex)
			{
				Util.WriteToChat("Charms: " + ex.Message);
				_useQueue.Clear();
			}
		}
		_useNext = DateTime.Now.AddMilliseconds(2000.0);
		if (_useQueue.Count == 0)
		{
			_askedAt.Remove(_useOn);
			Ask(_useOn, 0.0);
			_status = "used gems on " + _useName;
		}
	}

	public static List<string[]> Summary()
	{
		List<string[]> list = new List<string[]>();
		if (_s == null)
		{
			return list;
		}
		foreach (Row item in Parse(_s.Charms))
		{
			WorldObject worldObject = Globals.Core.WorldFilter[item.Id];
			string text = Text(worldObject);
			string text2;
			if (worldObject != null)
			{
				text2 = worldObject.Name;
			}
			else
			{
				text2 = ((item.Name.Length > 0) ? item.Name : ("#" + item.Id));
			}
			Match match = LevelRx.Match(text);
			Match match2 = TierRx.Match(text);
			Match match3 = CoinsRx.Match(text);
			string text3;
			if (match.Success)
			{
				text3 = "Lvl " + match.Groups[1].Value + (match.Groups[2].Success ? (" (" + match.Groups[2].Value + "% to " + match.Groups[3].Value + ")") : "");
			}
			else
			{
				text3 = (match2.Success ? ("Tier " + match2.Groups[1].Value + "/" + match2.Groups[2].Value) : "");
			}
			bool flag = text.IndexOf("Holding this item grants", StringComparison.OrdinalIgnoreCase) >= 0;
			bool? flag2 = ((worldObject != null) ? Status(worldObject) : ((bool?)null));
			if (!flag2.HasValue && item.St.Length > 0)
			{
				flag2 = item.St == "1";
			}
			string text4;
			if (flag)
			{
				text4 = "Always";
			}
			else if (flag2.HasValue)
			{
				text4 = (flag2.Value ? "ON" : "OFF");
			}
			else
			{
				text4 = "?";
			}
			string text5 = (match3.Success ? (match3.Groups[1].Value + " in" + (match3.Groups[2].Success ? (", " + match3.Groups[2].Value + " to next") : "")) : "");
			string text6 = ((worldObject == null) ? "Not in your pack right now." : Basics(worldObject));
			list.Add(new string[5] { text2, text3, text4, text5, text6 });
		}
		return list;
	}

	private static void Tip(string t)
	{
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip(t);
		}
	}
}
