using System;
using Decal.Adapter.Wrappers;

namespace MelkTank;

public static class ItemNames
{
	private static readonly string[] Materials = new string[78]
	{
		"", "Ceramic", "Porcelain", "Cloth", "Linen", "Satin", "Silk", "Velvet", "Wool", "Gem",
		"Agate", "Amber", "Amethyst", "Aquamarine", "Azurite", "Black Garnet", "Black Opal", "Bloodstone", "Carnelian", "Citrine",
		"Diamond", "Emerald", "Fire Opal", "Green Garnet", "Green Jade", "Hematite", "Imperial Topaz", "Jet", "Lapis Lazuli", "Lavender Jade",
		"Malachite", "Moonstone", "Onyx", "Opal", "Peridot", "Red Garnet", "Red Jade", "Rose Quartz", "Ruby", "Sapphire",
		"Smoky Quartz", "Sunstone", "Tiger Eye", "Tourmaline", "Turquoise", "White Jade", "White Quartz", "White Sapphire", "Yellow Garnet", "Yellow Topaz",
		"Zircon", "Ivory", "Leather", "Armoredillo Hide", "Gromnie Hide", "Reed Shark Hide", "Metal", "Brass", "Bronze", "Copper",
		"Gold", "Iron", "Pyreal", "Silver", "Steel", "Stone", "Alabaster", "Granite", "Marble", "Obsidian",
		"Sandstone", "Serpentine", "Wood", "Ebony", "Mahogany", "Oak", "Pine", "Teak"
	};

	public static string Material(int m)
	{
		return (m > 0 && m < Materials.Length) ? Materials[m] : "";
	}

	public static bool IsSalvage(WorldObject o)
	{
		if (o == null)
		{
			return false;
		}
		return o.ObjectClass == ObjectClass.Salvage || (o.Name ?? "").StartsWith("Salvage", StringComparison.OrdinalIgnoreCase);
	}

	public static string Of(WorldObject o)
	{
		if (o == null)
		{
			return "";
		}
		string text = o.Name ?? "";
		if (!IsSalvage(o))
		{
			return text;
		}
		string text2 = "";
		try
		{
			text2 = Material(o.Values(LongValueKey.Material, 0));
		}
		catch
		{
		}
		return (text2.Length > 0) ? (text2 + " Salvage") : text;
	}

	public static bool Is(WorldObject o, string name)
	{
		if (o == null || string.IsNullOrEmpty(name))
		{
			return false;
		}
		name = name.Trim();
		if (string.Equals(o.Name, name, StringComparison.OrdinalIgnoreCase))
		{
			return true;
		}
		if (!IsSalvage(o))
		{
			return false;
		}
		string text = "";
		try
		{
			text = Material(o.Values(LongValueKey.Material, 0));
		}
		catch
		{
		}
		if (text.Length == 0)
		{
			return false;
		}
		return name.Equals(text + " Salvage", StringComparison.OrdinalIgnoreCase) || name.Equals("Salvaged " + text, StringComparison.OrdinalIgnoreCase) || name.Equals(text, StringComparison.OrdinalIgnoreCase) || name.Equals("Salvage (" + text + ")", StringComparison.OrdinalIgnoreCase);
	}

	public static bool Contains(WorldObject o, string text)
	{
		if (o == null || string.IsNullOrEmpty(text))
		{
			return false;
		}
		if ((o.Name ?? "").IndexOf(text, StringComparison.OrdinalIgnoreCase) >= 0)
		{
			return true;
		}
		if (!IsSalvage(o))
		{
			return false;
		}
		string text2 = Of(o);
		if (text2.IndexOf(text, StringComparison.OrdinalIgnoreCase) >= 0)
		{
			return true;
		}
		string text3 = (text2.EndsWith(" Salvage") ? text2.Substring(0, text2.Length - 8) : "");
		return text3.Length > 0 && ("Salvaged " + text3).IndexOf(text, StringComparison.OrdinalIgnoreCase) >= 0;
	}
}
