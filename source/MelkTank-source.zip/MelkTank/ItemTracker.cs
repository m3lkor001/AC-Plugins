using System;
using System.Collections.Generic;
using System.Numerics;
using System.Text.RegularExpressions;
using Decal.Adapter.Wrappers;
using ImGuiNET;

namespace MelkTank;

public static class ItemTracker
{
	public class Found
	{
		public int Id;

		public string Name;

		public string Pattern;

		public DateTime Seen;

		public string Chest;
	}

	public static readonly Dictionary<int, Found> List = new Dictionary<int, Found>();

	private static DateTime _scanAt = DateTime.MinValue;

	private static readonly Dictionary<string, Regex> _rx = new Dictionary<string, Regex>();

	public const string Off = "~";

	public const string Pick = "+";

	public const string Detour = "!";

	private static readonly Dictionary<int, int> _pickTries = new Dictionary<int, int>();

	private static readonly Dictionary<int, DateTime> _pickAt = new Dictionary<int, DateTime>();

	private const double FarAway = 1000.0;

	private static Settings _settings;

	private static string _profName = "";

	private static string _profMsg = "";

	private static string _add = "";

	private static int _sort = 1;

	private static bool _desc;

	private static int _selPat = -1;

	private static readonly Vector4 Cyan = new Vector4(0.4f, 0.9f, 1f, 1f);

	private static readonly Vector4 Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f);

	private static int _editPat = -1;

	private static string _editText = "";

	private static bool _editFocus;

	public static void SetChest(WorldObject o, string note)
	{
		if (o == null)
		{
			return;
		}
		Found value;
		if (note == null)
		{
			if (List.TryGetValue(o.Id, out value) && value.Chest != null)
			{
				List.Remove(o.Id);
			}
			return;
		}
		if (List.TryGetValue(o.Id, out value))
		{
			if (value.Chest != null)
			{
				value.Chest = note;
			}
			return;
		}
		List[o.Id] = new Found
		{
			Id = o.Id,
			Name = o.Name,
			Pattern = "",
			Seen = DateTime.Now,
			Chest = note
		};
	}

	public static List<string> Patterns(Settings s)
	{
		List<string> list = new List<string>();
		string[] array = (s.TrackItems ?? "").Split('\n');
		foreach (string text in array)
		{
			if (text.Trim().Length > 0)
			{
				list.Add(text.Trim());
			}
		}
		return list;
	}

	public static string Bare(string p)
	{
		string text = (p ?? "").Trim();
		if (text.StartsWith("~", StringComparison.Ordinal))
		{
			text = text.Substring("~".Length);
		}
		if (text.StartsWith("+", StringComparison.Ordinal) || text.StartsWith("!", StringComparison.Ordinal))
		{
			text = text.Substring(1);
		}
		return text.Trim();
	}

	private static string Marks(string p)
	{
		string text = (p ?? "").Trim();
		if (text.StartsWith("~", StringComparison.Ordinal))
		{
			text = text.Substring("~".Length);
		}
		return text;
	}

	public static bool IsPick(string p)
	{
		string text = Marks(p);
		return text.StartsWith("+", StringComparison.Ordinal) || text.StartsWith("!", StringComparison.Ordinal);
	}

	public static bool IsDetour(string p)
	{
		return Marks(p).StartsWith("!", StringComparison.Ordinal);
	}

	private static string Make(string bare, bool on, bool pick, bool detour)
	{
		string text = (on ? "" : "~");
		string text2;
		if (detour)
		{
			text2 = "!";
		}
		else
		{
			text2 = (pick ? "+" : "");
		}
		return text + text2 + bare;
	}

	public static WorldObject PickupCandidate(Settings s, double range)
	{
		if (s == null || !s.TrackPickup || List.Count == 0)
		{
			return null;
		}
		HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		HashSet<string> hashSet2 = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		foreach (string item in Patterns(s))
		{
			if (!item.StartsWith("~", StringComparison.Ordinal) && IsPick(item))
			{
				hashSet.Add(Bare(item));
				if (IsDetour(item))
				{
					hashSet2.Add(Bare(item));
				}
			}
		}
		if (hashSet.Count == 0)
		{
			return null;
		}
		WorldObject result = null;
		double num = double.MaxValue;
		foreach (Found value3 in List.Values)
		{
			if (value3.Chest != null || !hashSet.Contains(value3.Pattern ?? ""))
			{
				continue;
			}
			WorldObject worldObject = Globals.Core.WorldFilter[value3.Id];
			if (worldObject == null || worldObject.Container != 0)
			{
				continue;
			}
			ObjectClass objectClass = worldObject.ObjectClass;
			if (objectClass == ObjectClass.Portal || objectClass == ObjectClass.Monster || objectClass == ObjectClass.Player || objectClass == ObjectClass.Container || objectClass == ObjectClass.Corpse || IsNpc(worldObject))
			{
				continue;
			}
			_pickTries.TryGetValue(worldObject.Id, out var value);
			if (value < 3 && (!_pickAt.TryGetValue(worldObject.Id, out var value2) || !((DateTime.Now - value2).TotalSeconds < 4.0)))
			{
				double num2 = CombatEngine.Distance(worldObject);
				if (!(num2 < 0.0) && !(num2 > (hashSet2.Contains(value3.Pattern ?? "") ? 1000.0 : range)) && !(num2 >= num))
				{
					result = worldObject;
					num = num2;
				}
			}
		}
		return result;
	}

	public static void PickupUntried(int id)
	{
		if (_pickTries.TryGetValue(id, out var value) && value > 0)
		{
			_pickTries[id] = value - 1;
		}
		_pickAt.Remove(id);
	}

	public static void PickupTried(int id)
	{
		_pickTries.TryGetValue(id, out var value);
		_pickTries[id] = value + 1;
		_pickAt[id] = DateTime.Now;
		if (_pickTries.Count > 200)
		{
			_pickTries.Clear();
			_pickAt.Clear();
		}
	}

	private static void SetPatterns(Settings s, List<string> l)
	{
		s.TrackItems = string.Join("\n", l.ToArray());
	}

	public static int AddPatterns(Settings s, IEnumerable<string> add)
	{
		List<string> list = Patterns(s);
		HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		foreach (string item in list)
		{
			hashSet.Add(Bare(item));
		}
		int num = 0;
		foreach (string item2 in add)
		{
			string text = (item2 ?? "").Trim();
			if (text.Length != 0 && hashSet.Add(text))
			{
				list.Add(text);
				num++;
			}
		}
		if (num > 0)
		{
			SetPatterns(s, list);
			_scanAt = DateTime.MinValue;
		}
		return num;
	}

	public static bool Matches(string pattern, string name)
	{
		if (string.IsNullOrEmpty(pattern) || string.IsNullOrEmpty(name))
		{
			return false;
		}
		string text = pattern.Trim();
		if (!text.StartsWith("name#", StringComparison.OrdinalIgnoreCase))
		{
			return string.Equals(text, name.Trim(), StringComparison.OrdinalIgnoreCase);
		}
		string text2 = text.Substring(5).Trim();
		if (text2.Length == 0)
		{
			return false;
		}
		if (!_rx.TryGetValue(text2, out var value))
		{
			try
			{
				value = new Regex(text2, RegexOptions.IgnoreCase);
			}
			catch
			{
				value = null;
			}
			_rx[text2] = value;
		}
		return value?.IsMatch(name) ?? (name.IndexOf(text2, StringComparison.OrdinalIgnoreCase) >= 0);
	}

	private static bool IsNpc(WorldObject o)
	{
		if (o.ObjectClass != ObjectClass.Npc && o.ObjectClass != ObjectClass.Vendor)
		{
			return false;
		}
		try
		{
			if (o.Values(LongValueKey.Value, 0) > 0 || o.Values(LongValueKey.Burden, 0) > 0)
			{
				return false;
			}
		}
		catch
		{
		}
		return true;
	}

	// (corpses count: the name decides - "name#Mire-Witch" finds "Corpse of Mosswart Mire-Witch", the exact
	// "Mosswart Mire-Witch" only the monster)
	private static bool IsGroundItem(WorldObject o)
	{
		if (o == null || o.Container != 0)
		{
			return false;
		}
		switch (o.ObjectClass)
		{
		case ObjectClass.Unknown:
		case ObjectClass.Player:
		case ObjectClass.Door:
		case ObjectClass.Lifestone:
		case ObjectClass.Housing:
			return false;
		default:
			return true;
		}
	}

	public static void Tick(Settings s)
	{
		if (s == null || DateTime.Now < _scanAt)
		{
			return;
		}
		_scanAt = DateTime.Now.AddSeconds(1.0);
		List<int> list = null;
		foreach (KeyValuePair<int, Found> item in List)
		{
			WorldObject worldObject = Globals.Core.WorldFilter[item.Key];
			double num = ((worldObject == null) ? (-1.0) : CombatEngine.Distance(worldObject));
			if (worldObject == null || worldObject.Container != 0 || num > 1000.0)
			{
				(list ?? (list = new List<int>())).Add(item.Key);
			}
		}
		if (list != null)
		{
			foreach (int item2 in list)
			{
				List.Remove(item2);
			}
		}
		_settings = s;
		List<string> list2 = new List<string>();
		foreach (string item3 in Patterns(s))
		{
			if (!item3.StartsWith("~", StringComparison.Ordinal))
			{
				list2.Add(Bare(item3));
			}
		}
		if (list2.Count == 0)
		{
			return;
		}
		try
		{
			foreach (WorldObject item4 in Globals.Core.WorldFilter.GetLandscape())
			{
				if (List.ContainsKey(item4.Id) || !IsGroundItem(item4) || CombatEngine.Distance(item4) > 1000.0)
				{
					continue;
				}
				string text = null;
				foreach (string item5 in list2)
				{
					if (Matches(item5, item4.Name))
					{
						text = item5;
						break;
					}
				}
				if (text != null)
				{
					List[item4.Id] = new Found
					{
						Id = item4.Id,
						Name = item4.Name,
						Pattern = text,
						Seen = DateTime.Now
					};
					double num2 = CombatEngine.Distance(item4);
					string text2;
					if (item4.ObjectClass == ObjectClass.Portal)
					{
						text2 = "PORTAL";
					}
					else if (IsNpc(item4))
					{
						text2 = "NPC";
					}
					else
					{
						text2 = ((item4.ObjectClass == ObjectClass.Monster) ? "MONSTER" : "ITEM");
					}
					Util.WriteToChat(text2 + ": " + item4.Name + " spotted" + ((num2 >= 0.0) ? (" (" + num2.ToString("0") + "m)") : "") + " - see the Tracking tab.", 18);
				}
			}
		}
		catch
		{
		}
	}

	private static void HelpBox()
	{
		ImGui.PushStyleVar(ImGuiStyleVar.FrameBorderSize, 1f);
		ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(0f, 0f, 0f, 0f));
		ImGui.PushStyleColor(ImGuiCol.Border, Cyan);
		ImGui.SmallButton(" ? ##trkhelp");
		ImGui.PopStyleColor(2);
		ImGui.PopStyleVar();
		if (!ImGui.IsItemHovered())
		{
			return;
		}
		ImGui.BeginTooltip();
		Im.TextColored(Cyan, "Items on the ground, portals and NPCs to watch for - found ones show on the main Tracking tab.");
		if (ImGui.BeginTable("trkhelptbl", 2, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("Goal", ImGuiTableColumnFlags.WidthFixed, 300f);
			ImGui.TableSetupColumn("Write", ImGuiTableColumnFlags.WidthFixed, 220f);
			ImGui.TableHeadersRow();
			string[][] array = new string[7][]
			{
				new string[2] { "That exact name (any case)", "Black Pearl" },
				new string[2] { "A word anywhere in the name", "name#pearl" },
				new string[2] { "Names starting with a word", "name#^Black" },
				new string[2] { "Names ending with a word", "name#Portal$" },
				new string[2] { "Either of two words", "name#pearl|ichor" },
				new string[2] { "A portal by name", "name#Rift" },
				new string[2] { "An NPC by name", "Prof. Ruggan" }
			};
			string[][] array2 = array;
			foreach (string[] array3 in array2)
			{
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				ImGui.TextUnformatted(array3[0]);
				ImGui.TableSetColumnIndex(1);
				Im.TextColored(new Vector4(0.75f, 0.6f, 1f, 1f), array3[1]);
			}
			ImGui.EndTable();
		}
		Im.TextColored(Grey, "name# is a regular expression, any case: ^ = starts with, $ = ends with, | = or.\nThe On box turns one off without removing it. Click a found one on the Tracking tab to select it,\ndouble-click to pick it up / go through the portal / talk to the NPC.");
		ImGui.EndTooltip();
	}

	public static void ListChanged()
	{
		_scanAt = DateTime.MinValue;
		_selPat = -1;
		Settings settings = _settings;
		if (settings == null)
		{
			return;
		}
		List<string> list = Patterns(settings);
		List<int> list2 = new List<int>();
		HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		foreach (string item in list)
		{
			if (!item.StartsWith("~", StringComparison.Ordinal))
			{
				hashSet.Add(Bare(item));
			}
		}
		foreach (KeyValuePair<int, Found> item2 in List)
		{
			if (item2.Value.Chest == null && !hashSet.Contains(item2.Value.Pattern))
			{
				list2.Add(item2.Key);
			}
		}
		foreach (int item3 in list2)
		{
			List.Remove(item3);
		}
	}

	private static bool DrawProfiles(Settings s)
	{
		bool result = false;
		Im.Text("Item profile:");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(200f);
		string text = ((s.TrackProfile.Length == 0) ? "(this character's own list)" : s.TrackProfile);
		if (ImGui.BeginCombo("##trkprof", text))
		{
			if (ImGui.Selectable("(this character's own list)", s.TrackProfile.Length == 0))
			{
				_profMsg = s.SwitchTrackProfile("") ?? "";
				ListChanged();
				result = true;
			}
			foreach (string item in Settings.ListTrackProfiles())
			{
				if (ImGui.Selectable(item + "##tp_" + item, string.Equals(item, s.TrackProfile, StringComparison.OrdinalIgnoreCase)))
				{
					_profMsg = s.SwitchTrackProfile(item) ?? "";
					ListChanged();
					result = true;
				}
			}
			ImGui.EndCombo();
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Item lists saved in Profiles\\Items - any character can use them.\nSwitching saves the current list where it came from first.");
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(140f);
		ImGui.InputTextWithHint("##trkprofname", "new profile name", ref _profName, 80u);
		ImGui.SameLine();
		if (ImGui.Button("Save as##trkprofsave"))
		{
			string text2 = s.SaveTrackProfileAs((_profName.Trim().Length > 0) ? _profName : s.TrackProfile);
			_profMsg = text2 ?? ("Saved as " + s.TrackProfile + ".");
			if (text2 == null)
			{
				_profName = "";
			}
			result = true;
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Saves this list as an item profile (the name typed, or the one in use) and uses it.");
		}
		if (s.TrackProfile.Length > 0)
		{
			ImGui.SameLine();
			if (ImGui.Button("Delete##trkprofdel"))
			{
				_profMsg = s.DeleteTrackProfile() ?? "Deleted - back to this character's own list.";
				ListChanged();
				result = true;
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Deletes the profile file " + s.TrackProfile + " and goes back to this character's own list.");
			}
		}
		if (_profMsg.Length > 0)
		{
			Im.TextColored(Grey, _profMsg);
		}
		return result;
	}

	private static bool SavePatEdit(List<string> pats, int i, bool on)
	{
		string text = Bare(_editText);
		bool pick = IsPick(pats[i]);
		bool detour = IsDetour(pats[i]);
		if (text.Length == 0)
		{
			Util.WriteToChat("Tracking: the entry can't be empty (x removes it).");
			return false;
		}
		for (int j = 0; j < pats.Count; j++)
		{
			if (j != i)
			{
				string a = Bare(pats[j]);
				if (string.Equals(a, text, StringComparison.OrdinalIgnoreCase))
				{
					Util.WriteToChat("Tracking: " + text + " is already on the list.");
					return false;
				}
			}
		}
		_editPat = -1;
		string text2 = Make(text, on, pick, detour);
		if (pats[i] == text2)
		{
			return false;
		}
		pats[i] = text2;
		_rx.Clear();
		return true;
	}

	public static bool Draw(Settings s)
	{
		_settings = s;
		bool flag = DrawProfiles(s);
		List<string> list = Patterns(s);
		ImGui.SetNextItemWidth(260f);
		bool flag2 = ImGui.InputTextWithHint("##trkitem", "name, or name#part", ref _add, 200u, ImGuiInputTextFlags.EnterReturnsTrue);
		ImGui.SameLine();
		if ((ImGui.Button("Add##trkadd") | flag2) && _add.Trim().Length > 0 && !list.Exists((string x) => string.Equals(Bare(x), _add.Trim(), StringComparison.OrdinalIgnoreCase)))
		{
			list.Add(_add.Trim());
			_add = "";
			SetPatterns(s, list);
			flag = true;
			_scanAt = DateTime.MinValue;
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Like the Monsters tab: a plain name is that exact item (any case);\nname#part matches a part of the name (\"name#pearl\" finds Black Pearl) - a regular expression, so name#^Black works too.");
		}
		ImGui.SameLine();
		if (ImGui.Button("selected##trksel"))
		{
			try
			{
				WorldObject worldObject = Globals.Core.WorldFilter[Globals.Core.Actions.CurrentSelection];
				if (worldObject != null)
				{
					_add = worldObject.Name;
				}
			}
			catch
			{
			}
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("The name of the item you have selected.");
		}
		ImGui.SameLine();
		HelpBox();
		if (list.Count > 0 && ImGui.BeginTable("trkpats", 5, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit, new Vector2(590f, 0f)))
		{
			ImGui.TableSetupColumn("On", ImGuiTableColumnFlags.WidthFixed, 26f);
			ImGui.TableSetupColumn("Pick up", ImGuiTableColumnFlags.WidthFixed, 46f);
			ImGui.TableSetupColumn("Detour", ImGuiTableColumnFlags.WidthFixed, 44f);
			ImGui.TableSetupColumn("Watching for (items, portals, NPCs)", ImGuiTableColumnFlags.WidthStretch);
			ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 120f);
			ImGui.TableHeadersRow();
			int num = -1;
			int num2 = -1;
			int num3 = -1;
			for (int num4 = 0; num4 < list.Count; num4++)
			{
				ImGui.PushID("tp" + num4);
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				bool v = !list[num4].StartsWith("~", StringComparison.Ordinal);
				bool v2 = IsPick(list[num4]);
				bool v3 = IsDetour(list[num4]);
				string text = Bare(list[num4]);
				if (ImGui.Checkbox("##on", ref v))
				{
					list[num4] = Make(text, v, v2, v3);
					flag = true;
					_scanAt = DateTime.MinValue;
				}
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip("Untick to stop watching for it without removing it.");
				}
				ImGui.TableSetColumnIndex(1);
				if (ImGui.Checkbox("##pk", ref v2))
				{
					if (!v2)
					{
						v3 = false;
					}
					list[num4] = Make(text, v, v2, v3);
					flag = true;
				}
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip("Pick it up when it's found within loot range (Settings > Items > Pick up tracked items must be on).");
				}
				ImGui.TableSetColumnIndex(2);
				if (ImGui.Checkbox("##dt", ref v3))
				{
					if (v3)
					{
						v2 = true;
					}
					list[num4] = Make(text, v, v2, v3);
					flag = true;
				}
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip("Go and pick it up wherever it's seen - a detour, whatever the loot range\n(Settings > Items > Pick up tracked items must be on).");
				}
				ImGui.TableSetColumnIndex(3);
				if (_editPat == num4)
				{
					ImGui.SetNextItemWidth(-1f);
					if (_editFocus)
					{
						ImGui.SetKeyboardFocusHere();
						_editFocus = false;
					}
					bool flag3 = ImGui.InputText("##edpat", ref _editText, 200u, ImGuiInputTextFlags.EnterReturnsTrue);
					if (ImGui.IsItemHovered())
					{
						Im.SetTooltip("A plain name is that exact item; name#part matches a part of the name. Enter or Save to keep it.");
					}
					if (flag3 && SavePatEdit(list, num4, v))
					{
						flag = true;
						_scanAt = DateTime.MinValue;
					}
				}
				else if (ImGui.Selectable(v ? text : (text + "  (off)"), _selPat == num4))
				{
					_selPat = ((_selPat == num4) ? (-1) : num4);
				}
				ImGui.TableSetColumnIndex(4);
				if (_editPat == num4)
				{
					if (ImGui.SmallButton("Save") && SavePatEdit(list, num4, v))
					{
						flag = true;
						_scanAt = DateTime.MinValue;
					}
					ImGui.SameLine();
					if (ImGui.SmallButton("Cancel"))
					{
						_editPat = -1;
					}
					ImGui.PopID();
					continue;
				}
				if (num4 > 0)
				{
					if (Im.UpButton("##u"))
					{
						num = num4;
					}
					ImGui.SameLine();
				}
				if (num4 < list.Count - 1)
				{
					if (Im.DownButton("##d"))
					{
						num2 = num4;
					}
					ImGui.SameLine();
				}
				if (ImGui.SmallButton("Edit"))
				{
					_editPat = num4;
					_editText = text;
					_editFocus = true;
				}
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip("Change this entry");
				}
				ImGui.SameLine();
				if (ImGui.SmallButton("x"))
				{
					num3 = num4;
				}
				ImGui.PopID();
			}
			ImGui.EndTable();
			if (num > 0)
			{
				Im.Move(list, num, up: true);
				flag = true;
			}
			if (num2 >= 0)
			{
				Im.Move(list, num2, up: false);
				flag = true;
			}
			if (num > 0 || num2 >= 0 || num3 >= 0)
			{
				_editPat = -1;
			}
			if (num3 >= 0)
			{
				list.RemoveAt(num3);
				flag = true;
				_selPat = -1;
			}
			if (flag)
			{
				SetPatterns(s, list);
			}
			if (flag)
			{
				HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
				foreach (string item in list)
				{
					if (!item.StartsWith("~", StringComparison.Ordinal))
					{
						hashSet.Add(Bare(item));
					}
				}
				List<int> list2 = new List<int>();
				foreach (KeyValuePair<int, Found> item2 in List)
				{
					if (item2.Value.Chest == null && !hashSet.Contains(item2.Value.Pattern))
					{
						list2.Add(item2.Key);
					}
				}
				foreach (int item3 in list2)
				{
					List.Remove(item3);
				}
			}
		}
		ImGui.Spacing();
		Im.TextColored(Grey, "What's seen (items on the ground, portals, NPCs) shows on the main Tracking tab (" + List.Count + " now).");
		return flag;
	}

	public static void DrawRows(int sortCol, bool desc)
	{
		if (List.Count == 0)
		{
			return;
		}
		List<Found> list = new List<Found>(List.Values);
		Dictionary<int, double> dist = new Dictionary<int, double>();
		foreach (Found item in list)
		{
			WorldObject worldObject = Globals.Core.WorldFilter[item.Id];
			double num = ((worldObject == null) ? (-1.0) : CombatEngine.Distance(worldObject));
			dist[item.Id] = ((num < 0.0) ? double.MaxValue : num);
		}
		list.Sort((Found a, Found b) =>
		{
			int num4 = dist[a.Id].CompareTo(dist[b.Id]);
			return ((sortCol == 2) & desc) ? (-num4) : num4;
		});
		int num2 = 0;
		try
		{
			num2 = Globals.Core.Actions.CurrentSelection;
		}
		catch
		{
		}
		Vector4 col = new Vector4(1f, 0.85f, 0.4f, 1f);
		foreach (Found item2 in list)
		{
			WorldObject worldObject2 = Globals.Core.WorldFilter[item2.Id];
			if (worldObject2 == null)
			{
				continue;
			}
			bool flag = worldObject2.ObjectClass == ObjectClass.Portal;
			bool flag2 = IsNpc(worldObject2);
			bool flag3 = worldObject2.ObjectClass == ObjectClass.Monster;
			ImGui.TableNextRow();
			ImGui.TableSetColumnIndex(0);
			ImGui.PushStyleColor(ImGuiCol.Text, col);
			bool flag4 = item2.Chest != null;
			if (ImGui.Selectable((flag4 ? "[CHEST] " : (flag ? "[PORTAL] " : (flag2 ? "[NPC] " : (flag3 ? "[MONSTER] " : "[ITEM] ")))) + item2.Name + ((flag4 && item2.Chest.Length > 0) ? (" - " + item2.Chest) : "") + "##it" + item2.Id, num2 == item2.Id, ImGuiSelectableFlags.AllowDoubleClick))
			{
				try
				{
					Globals.Core.Actions.SelectItem(item2.Id);
					if (ImGui.IsMouseDoubleClicked(ImGuiMouseButton.Left))
					{
						if (flag | flag2 | flag4)
						{
							Globals.Core.Actions.UseItem(item2.Id, 0);
						}
						else if (!flag3)
						{
							Globals.Core.Actions.MoveItem(item2.Id, Globals.Core.CharacterFilter.Id, 0, stack: true);
						}
					}
				}
				catch (Exception ex)
				{
					Util.LogError(ex);
				}
			}
			ImGui.PopStyleColor();
			if (ImGui.IsItemHovered() & flag4)
			{
				Im.SetTooltip("A chest you checked (Settings > Basic > Items > Check chests).\nClick to select, double-click to open it.");
			}
			else if (ImGui.IsItemHovered())
			{
				string pattern = item2.Pattern;
				string text;
				if (flag)
				{
					text = "go through it.";
				}
				else if (flag2)
				{
					text = "talk to them.";
				}
				else
				{
					text = (flag3 ? "select it." : "pick it up.");
				}
				Im.SetTooltip("Watched for on Tracking > List (" + pattern + ").\nClick to select, double-click to " + text);
			}
			ImGui.TableSetColumnIndex(1);
			Vector4 grey = Grey;
			string s;
			if (flag)
			{
				s = "portal";
			}
			else if (flag2)
			{
				s = "npc";
			}
			else
			{
				s = (flag3 ? "monster" : "item");
			}
			Im.TextColored(grey, s);
			ImGui.TableSetColumnIndex(2);
			double num3 = dist[item2.Id];
			Im.Text((num3 == double.MaxValue) ? "?" : num3.ToString("0"));
		}
	}
}
