using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using MelkTank.Loot;

namespace MelkTank;

/// <summary>
/// T11+: the attack school gems hunting drops (Gem of War / Void / Melee / Missile Augmentation - double click for +1 to
/// that augmentation, only you can use yours) used as they come, once the looting's done: one every couple of seconds,
/// never while a corpse is being looted or the character is busy.
/// </summary>
public static class AttackGems
{
	/// <summary>The setting (Settings > Areas > T11+), read live so /mt set takes at once.</summary>
	public static Func<bool> IsOn;
	private static bool On => IsOn != null && IsOn();

	private static readonly Regex GemRx = new Regex("^(?:\\d+x?\\s+)?Gem of (?<s>War|Void|Melee|Missile)(?: Magic)? Augmentation$", RegexOptions.IgnoreCase);

	private static DateTime _next = DateTime.MinValue;
	private static int _lastId;
	private static int _lastCount;
	private static int _tries;
	private static DateTime _usedAt = DateTime.MinValue;
	/// <summary>Gems that wouldn't go (an old one "no longer used", someone else's): not tried again this session.</summary>
	private static readonly HashSet<int> _skip = new HashSet<int>();
	public static int Used;

	public static void Tick()
	{
		if (!On || DateTime.Now < _next) return;
		_next = DateTime.Now.AddSeconds(2.0);
		var core = CoreManager.Current;
		if (core?.Actions == null) return;
		// (after the looting: not while a corpse is open or the looter is at one, not mid-action)
		Looter looter = Looter.Current;
		if (looter != null && looter.Busy) return;
		try
		{
			int open = core.Actions.OpenedContainer;
			if (open != 0 && open != core.CharacterFilter.Id)
			{
				WorldObject c = core.WorldFilter[open];
				if (c == null || c.Container != core.CharacterFilter.Id) return;
			}
			if (core.Actions.BusyState != 0) return;
		}
		catch { return; }
		WorldObject gem = null;
		foreach (WorldObject o in InvCache.All())
		{
			if (o != null && !_skip.Contains(o.Id) && GemRx.IsMatch(o.Name ?? "")) { gem = o; break; }
		}
		if (gem == null) return;
		int count = Math.Max(1, gem.Values(LongValueKey.StackCount, 1));
		if (gem.Id == _lastId && count == _lastCount)
		{
			// (used and nothing changed: three goes, then left alone)
			if (++_tries >= 3) { _skip.Add(gem.Id); Util.WriteToChat("Gems: " + gem.Name + " won't use - leaving it."); return; }
		}
		else
		{
			if (gem.Id == _lastId && count < _lastCount) Used += _lastCount - count;
			_tries = 0;
		}
		_lastId = gem.Id;
		_lastCount = count;
		_usedAt = DateTime.Now;
		core.Actions.UseItem(gem.Id, 0);
	}

	/// <summary>A gem the server turned down (an old one, someone else's): skipped from now on.</summary>
	public static void OnChat(string text)
	{
		if (!On || _lastId == 0 || (DateTime.Now - _usedAt).TotalSeconds > 4) return;
		if (text.IndexOf("no longer used", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("only the owner", StringComparison.OrdinalIgnoreCase) >= 0 ||
		    text.IndexOf("cannot use", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("can't use", StringComparison.OrdinalIgnoreCase) >= 0 ||
		    text.IndexOf("not your", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			_skip.Add(_lastId);
			_lastId = 0;
		}
	}
}
