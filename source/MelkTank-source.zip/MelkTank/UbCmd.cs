using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
#if !RETAIL
using ACGodot.DecalShim;
using ACGodot.Plugins;
#endif
#if !RETAIL
using AcClient;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
#if !RETAIL
using Godot;
#endif
using MelkTank.Metas;

namespace MelkTank;

public static class UbCmd
{
	private enum Where
	{
		All,
		Inventory,
		Landscape
	}

	private class GiveStep
	{
		public int Item;

		public int Amount;
	}

	private struct WRECT
	{
		public int L;

		public int T;

		public int R;

		public int B;
	}

	[UnmanagedFunctionPointer(CallingConvention.ThisCall)]
	private delegate void ThisVoid(int self);

	[UnmanagedFunctionPointer(CallingConvention.ThisCall)]
	private delegate float ThisFloat(int self);

	[UnmanagedFunctionPointer(CallingConvention.ThisCall)]
	private delegate void ThisVoidInt(int self, int a);

	[UnmanagedFunctionPointer(CallingConvention.ThisCall)]
	private delegate double ThisDouble(int self);

	[UnmanagedFunctionPointer(CallingConvention.ThisCall)]
	private delegate bool ThisHeading(int self, float deg, int send);

	private enum JState
	{
		Idle,
		Turning,
		Charging,
		Checking
	}

	private static readonly Regex Head = new Regex("^[/@]ub\\s+(?<verb>[a-z]+)\\s*(?<rest>.*)$", RegexOptions.IgnoreCase);

	private static readonly Regex UseRx = new Regex("^(?<one>.+?)(?=\\son|$)( on (?<two>.+))?$");

	private static readonly Regex GiveRx = new Regex("^((?<n>\\d+)? ?(?<item>.+?) to (?<to>.+)|(?<stop>stop|cancel|quit|abort))$");

	private static readonly Queue<GiveStep> _give = new Queue<GiveStep>();

	private static int _giveTarget;

	private static int _giveWaitItem;

	private static int _giveDelayMs;

	private static int _giveDone;

	private static int _giveTotal;

	private static DateTime _giveSent = DateTime.MinValue;

	private static DateTime _acgCommence = DateTime.MinValue;

	private static JState _j = JState.Idle;

	private static float _jHeading;

	private static float _jPower;

	private static bool _jShift;

	private static bool _jW;

	private static bool _jX;

	private static bool _jZ;

	private static bool _jC;

	private static DateTime _jAt;

	private static DateTime _jCharge;

	private static DateTime _jTurnAsk;

	private static DateTime _jReleased;

	private static int _jTries;

	private static bool _jAir;

	private static double _jX0;

	private static double _jY0;

	private static double _jZ0;

	private static bool _frameHooked;

	private static readonly Regex JumpRx = new Regex("^((?<h>[\\.\\d]+)\\s+)?(?<ms>\\d+)?$");

	private static float _jStartP;

	private static bool _jRising;

	private static DateTime _jChargeStart;

	public static bool Giving => _giveTarget != 0;

	public static string GiveProgress => (_giveTarget == 0) ? "" : (_giveDone + " of " + _giveTotal + " stacks handed over");

	public static bool Jumping => _j != JState.Idle;

	private static int CombatSystem
	{
		get
		{
			ACGodot.Plugins.PluginHost host = Bridge.Host;
			return (host != null && host.Player?.Active == true) ? 1 : 0;
		}
	}

	public static bool Try(string command)
	{
		return Try(command, ours: false);
	}

	public static bool Try(string command, bool ours)
	{
		Settings currentSettings = PluginCore.CurrentSettings;
		if (currentSettings != null)
		{
			if (currentSettings.UbNative || !ours)
			{
			}
			if (!string.IsNullOrEmpty(command))
			{
				Match match = Head.Match(command.Trim());
				if (!match.Success)
				{
					return false;
				}
				string value = match.Groups["verb"].Value;
				string text = match.Groups["rest"].Value.Trim();
				string text2 = value.ToLowerInvariant();
				try
				{
					if (text2.StartsWith("use"))
					{
						return Use(value.Substring(3), text);
					}
					if (text2.StartsWith("select"))
					{
						return Select(value.Substring(6), text);
					}
					if (text2.StartsWith("give"))
					{
						return Give(value.Substring(4), text);
					}
					if (text2 == "face")
					{
						return Face(text);
					}
					if (text2.StartsWith("jump"))
					{
						return Jump(text2.Substring(4), text);
					}
					switch (text2)
					{
					case "vendor":
						return VendorCmd(text);
					case "combatstate":
						return CombatStateCmd(text);
					case "fellow":
						return Fellow(text);
					case "resolution":
						return Resolution(text);
					case "mexec":
						if (UbExpr.Own)
						{
							object v = Expr.Eval(text, out var error);
							Util.WriteToChat((error != null) ? ("mexec error: " + error) : ("Result: [" + Expr.TypeName(v) + "] " + Expr.Str(v)));
							return true;
						}
						break;
					}
				}
				catch (Exception ex)
				{
					Util.LogError(ex);
					Util.WriteToChat("/ub " + value + ": " + ex.Message);
					return true;
				}
				return false;
			}
		}
		return false;
	}

	private static WorldObject Special(string name)
	{
		WorldFilter worldFilter = CoreManager.Current.WorldFilter;
		if (int.TryParse(name, out var result) && worldFilter[result] != null)
		{
			return worldFilter[result];
		}
		try
		{
			result = Convert.ToInt32(name, 16);
			if (worldFilter[result] != null)
			{
				return worldFilter[result];
			}
		}
		catch
		{
		}
		if (name == "selected")
		{
			int currentSelection = CoreManager.Current.Actions.CurrentSelection;
			if (currentSelection != 0 && worldFilter[currentSelection] != null)
			{
				return worldFilter[currentSelection];
			}
		}
		return null;
	}

	private static bool NameIs(WorldObject o, string name, bool partial)
	{
		return partial ? ItemNames.Contains(o, name) : ItemNames.Is(o, name);
	}

	private static WorldObject Find(string name, Where where, bool partial, WorldObject exclude = null)
	{
		WorldObject worldObject = Special(name);
		if (worldObject != null)
		{
			return worldObject;
		}
		WorldFilter worldFilter = CoreManager.Current.WorldFilter;
		if (where != Where.Landscape)
		{
			foreach (WorldObject item in worldFilter.GetInventory())
			{
				if (item != null && (exclude == null || item.Id != exclude.Id) && NameIs(item, name, partial))
				{
					return item;
				}
			}
			if (where == Where.All && CoreManager.Current.Actions.OpenedContainer != 0)
			{
				foreach (WorldObject item2 in worldFilter.GetByContainer(CoreManager.Current.Actions.OpenedContainer))
				{
					if (item2 != null && (exclude == null || item2.Id != exclude.Id) && NameIs(item2, name, partial))
					{
						return item2;
					}
				}
			}
			if (where == Where.Inventory)
			{
				return null;
			}
		}
		WorldObject result = null;
		double num = double.MaxValue;
		foreach (WorldObject item3 in worldFilter.GetLandscape())
		{
			if (item3 != null && (exclude == null || item3.Id != exclude.Id) && NameIs(item3, name, partial))
			{
				double num2 = CombatEngine.Distance(item3);
				if (num2 < num)
				{
					num = num2;
					result = item3;
				}
			}
		}
		return result;
	}

	private static WorldObject FindPerson(string name, bool partial, params ObjectClass[] oc)
	{
		WorldObject worldObject = (string.IsNullOrEmpty(name) ? null : Special(name));
		if (worldObject != null)
		{
			return worldObject;
		}
		int id = CoreManager.Current.CharacterFilter.Id;
		WorldObject result = null;
		double num = double.MaxValue;
		foreach (WorldObject item in CoreManager.Current.WorldFilter.GetLandscape())
		{
			if (item != null && item.Id != id && Array.IndexOf(oc, item.ObjectClass) >= 0 && (string.IsNullOrEmpty(name) || (partial ? ItemNames.Contains(item, name) : ItemNames.Is(item, name))))
			{
				double num2 = CombatEngine.Distance(item);
				if (num2 < num)
				{
					num = num2;
					result = item;
				}
			}
		}
		return result;
	}

	private static bool Flags(string f, out Where where, out bool partial)
	{
		f = f.ToLowerInvariant();
		partial = f.Contains("p");
		where = (f.Contains("i") ? Where.Inventory : (f.Contains("l") ? Where.Landscape : Where.All));
		if (f.Contains("i") && f.Contains("l"))
		{
			Util.WriteToChat("l and i cannot be used in the same command");
			return false;
		}
		return true;
	}

	private static bool Use(string f, string rest)
	{
		if (!Flags(f, out var where, out var partial) || rest.Length == 0)
		{
			return true;
		}
		Match match = UseRx.Match(rest);
		string value = match.Groups["one"].Value;
		string value2 = match.Groups["two"].Value;
		WorldObject worldObject = Find(value, where, partial);
		if (worldObject == null)
		{
			Util.WriteToChat("Could not find object: " + value);
			return true;
		}
		if (string.IsNullOrEmpty(value2))
		{
			Util.WriteToChat("using " + worldObject.Name);
			CoreManager.Current.Actions.UseItem(worldObject.Id, 0);
			return true;
		}
		WorldObject worldObject2 = Find(value2, Where.All, partial, worldObject);
		if (worldObject2 == null)
		{
			Util.WriteToChat(value2 + " is null");
			return true;
		}
		Util.WriteToChat("using " + worldObject.Name + " on " + worldObject2.Name);
		if (worldObject.ObjectClass == ObjectClass.WandStaffOrb && CoreManager.Current.Actions.CombatMode == CombatState.Magic)
		{
			CoreManager.Current.Actions.SelectItem(worldObject2.Id);
			CoreManager.Current.Actions.UseItem(worldObject.Id, 1, worldObject2.Id);
		}
		else
		{
			CoreManager.Current.Actions.ApplyItem(worldObject.Id, worldObject2.Id);
		}
		return true;
	}

	// the nearest thing about with this name, whatever kind it is (not you, not what you carry)
	private static WorldObject FindNamedHere(string name, bool partial)
	{
		if (string.IsNullOrEmpty(name))
		{
			return null;
		}
		int id = CoreManager.Current.CharacterFilter.Id;
		WorldObject result = null;
		double num = double.MaxValue;
		foreach (WorldObject item in CoreManager.Current.WorldFilter.GetLandscape())
		{
			if (item != null && item.Id != id && (partial ? ItemNames.Contains(item, name) : ItemNames.Is(item, name)))
			{
				double num2 = CombatEngine.Distance(item);
				if (num2 >= 0.0 && num2 < num)
				{
					num = num2;
					result = item;
				}
			}
		}
		return result;
	}

	// /ub vendor open[p] <name> | addbuy[p] [count] <ware> | buyall | clearbuy | addsell[p] <item> | sellall | clearsell
	private static readonly Regex VendorCountRx = new Regex("^(?<n>\\d+)\\s+(?<name>.+)$");

	private static bool VendorCmd(string rest)
	{
		string[] array = rest.Split(new char[1] { ' ' }, 2, StringSplitOptions.RemoveEmptyEntries);
		if (array.Length == 0)
		{
			Util.WriteToChat("Usage: /ub vendor open[p] <name> | addbuy[p] [count] <item> | buyall | clearbuy | addsell[p] <item> | sellall | clearsell");
			return true;
		}
		string text = array[0].ToLowerInvariant();
		string text2 = ((array.Length > 1) ? array[1].Trim() : "");
		bool partial = text.EndsWith("p") && text != "open" && !text.StartsWith("opencancel");
		string text3 = (partial ? text.Substring(0, text.Length - 1) : text);
		var actions = CoreManager.Current.Actions;
		switch (text3)
		{
		case "open":
		{
			WorldObject worldObject = FindPerson(text2, partial, ObjectClass.Vendor, ObjectClass.Npc) ?? FindNamedHere(text2, partial);
			if (worldObject == null)
			{
				Util.WriteToChat("vendor: " + text2 + " not found");
				return true;
			}
			actions.SelectItem(worldObject.Id);
			actions.UseItem(worldObject.Id, 0);
			return true;
		}
		case "opencancel":
			return true;
		case "clearbuy":
			actions.VendorClearBuyList();
			return true;
		case "clearsell":
			actions.VendorClearSellList();
			return true;
		case "buyall":
			if (CoreManager.Current.WorldFilter.OpenVendor == null)
			{
				Util.WriteToChat("vendor: no vendor open");
				return true;
			}
			actions.VendorBuyAll();
			return true;
		case "sellall":
			if (CoreManager.Current.WorldFilter.OpenVendor == null)
			{
				Util.WriteToChat("vendor: no vendor open");
				return true;
			}
			actions.VendorSellAll();
			return true;
		case "addbuy":
		{
			Vendor openVendor = CoreManager.Current.WorldFilter.OpenVendor;
			if (openVendor == null)
			{
				Util.WriteToChat("vendor: no vendor open");
				return true;
			}
			int result = 1;
			string text4 = text2;
			Match match = VendorCountRx.Match(text2);
			if (match.Success)
			{
				int.TryParse(match.Groups["n"].Value, out result);
				text4 = match.Groups["name"].Value.Trim();
			}
			WorldObject worldObject2 = null;
			foreach (WorldObject item in openVendor)
			{
				if (item != null && (partial ? (item.Name ?? "").IndexOf(text4, StringComparison.OrdinalIgnoreCase) >= 0 : string.Equals(item.Name, text4, StringComparison.OrdinalIgnoreCase)))
				{
					worldObject2 = item;
					break;
				}
			}
			if (worldObject2 == null)
			{
				Util.WriteToChat("vendor: " + text4 + " isn't for sale here");
				return true;
			}
			actions.VendorAddBuyList(worldObject2.Id, Math.Max(1, result));
			return true;
		}
		case "addsell":
		{
			WorldObject worldObject3 = Find(text2, Where.Inventory, partial);
			if (worldObject3 == null)
			{
				Util.WriteToChat("vendor: " + text2 + " not in your inventory");
				return true;
			}
			actions.VendorAddSellList(worldObject3.Id);
			return true;
		}
		default:
			Util.WriteToChat("vendor: unknown command " + text);
			return true;
		}
	}

	private static bool Select(string f, string rest)
	{
		if (!Flags(f, out var where, out var partial) || rest.Length == 0)
		{
			return true;
		}
		WorldObject worldObject = Find(rest, where, partial);
		if (worldObject != null)
		{
			CoreManager.Current.Actions.SelectItem(worldObject.Id);
		}
		return true;
	}

	private static bool Give(string f, string rest)
	{
		Match match = GiveRx.Match(rest);
		if (!match.Success)
		{
			Util.WriteToChat("Usage: /ub give[p][P][r] [count] <item> to <target>");
			return true;
		}
		if (match.Groups["stop"].Success && match.Groups["stop"].Value.Length > 0)
		{
			_give.Clear();
			_giveTarget = 0;
			Util.WriteToChat("give: stopped.");
			return true;
		}
		bool partial = f.Contains("P");
		bool flag = f.Contains("p");
		bool flag2 = f.Contains("r");
		int result = 0;
		if (match.Groups["n"].Success)
		{
			int.TryParse(match.Groups["n"].Value, out result);
		}
		if (result < 1)
		{
			result = int.MaxValue;
		}
		string value = match.Groups["item"].Value;
		string value2 = match.Groups["to"].Value;
		// (whatever is named - a person, an NPC, a statue, a chest: the server says whether it takes it)
		WorldObject worldObject = FindPerson(value2, partial, ObjectClass.Player, ObjectClass.Npc, ObjectClass.Vendor) ?? FindNamedHere(value2, partial);
		if (worldObject == null)
		{
			Util.WriteToChat("give: " + value2 + " not found");
			return true;
		}
		if (_give.Count > 0)
		{
			Util.WriteToChat("give: already giving - wait, or /ub give stop");
			return true;
		}
		Regex regex = (flag2 ? new Regex(value) : null);
		long num = result;
		foreach (WorldObject item in CoreManager.Current.WorldFilter.GetInventory())
		{
			if (num <= 0)
			{
				break;
			}
			if (item != null)
			{
				string text = item.Name ?? "";
				bool flag3;
				if (flag2)
				{
					flag3 = regex.IsMatch(text);
				}
				else
				{
					flag3 = (flag ? (text.IndexOf(value, StringComparison.OrdinalIgnoreCase) >= 0) : text.Equals(value, StringComparison.OrdinalIgnoreCase));
				}
				if (flag3)
				{
					int num2 = Math.Max(1, item.Values(LongValueKey.StackCount, 1));
					int num3 = (int)Math.Min(num2, num);
					_give.Enqueue(new GiveStep
					{
						Item = item.Id,
						Amount = num3
					});
					num -= num3;
				}
			}
		}
		if (_give.Count == 0)
		{
			Util.WriteToChat("give: no " + value + " in your pack");
			return true;
		}
		_giveTarget = worldObject.Id;
		_giveWaitItem = 0;
		_giveDelayMs = 0;
		_giveDone = 0;
		_giveTotal = _give.Count;
		return true;
	}

	public static string StartGive(int targetId, string itemName, long count, int delayMs)
	{
		if (_give.Count > 0 || _giveTarget != 0)
		{
			return "Already giving - Stop first.";
		}
		WorldObject worldObject = CoreManager.Current.WorldFilter[targetId];
		if (worldObject == null)
		{
			return "The target isn't around any more.";
		}
		long num = ((count > 0) ? count : long.MaxValue);
		foreach (WorldObject item in CoreManager.Current.WorldFilter.GetInventory())
		{
			if (num <= 0)
			{
				break;
			}
			if (item != null && ItemNames.Is(item, itemName) && item.Values(LongValueKey.EquippedSlots, 0) == 0)
			{
				int num2 = Math.Max(1, item.Values(LongValueKey.StackCount, 1));
				int num3 = (int)Math.Min(num2, num);
				_give.Enqueue(new GiveStep
				{
					Item = item.Id,
					Amount = num3
				});
				num -= num3;
			}
		}
		if (_give.Count == 0)
		{
			return "No " + itemName + " in your pack.";
		}
		_giveTarget = targetId;
		_giveWaitItem = 0;
		_giveDelayMs = Math.Max(0, delayMs);
		_giveDone = 0;
		_giveTotal = _give.Count;
		return "Giving " + itemName + " to " + worldObject.Name + " (" + _giveTotal + " stack" + ((_giveTotal == 1) ? "" : "s") + ").";
	}

	public static void StopGive()
	{
		_give.Clear();
		_giveTarget = 0;
		_giveWaitItem = 0;
	}

	private static void GiveTick()
	{
		if (_giveTarget == 0)
		{
			return;
		}
		if (_giveWaitItem != 0)
		{
			WorldObject worldObject = CoreManager.Current.WorldFilter[_giveWaitItem];
			bool flag = worldObject == null || (worldObject.Container != CoreManager.Current.CharacterFilter.Id && !InPack(worldObject));
			if (!flag && (DateTime.Now - _giveSent).TotalSeconds < 3.0)
			{
				return;
			}
			if (flag)
			{
				_giveDone++;
			}
			_giveWaitItem = 0;
		}
		if (_giveDelayMs > 0 && (DateTime.Now - _giveSent).TotalMilliseconds < (double)_giveDelayMs)
		{
			return;
		}
		if (_give.Count == 0)
		{
			_giveTarget = 0;
			return;
		}
		GiveStep giveStep = _give.Dequeue();
		if (CoreManager.Current.WorldFilter[giveStep.Item] != null)
		{
			CM_Inventory.Event_GiveObjectRequest((uint)_giveTarget, (uint)giveStep.Item, (uint)giveStep.Amount);
			_giveWaitItem = giveStep.Item;
			_giveSent = DateTime.Now;
		}
	}

	private static bool InPack(WorldObject o)
	{
		try
		{
			foreach (WorldObject item in CoreManager.Current.WorldFilter.GetInventory())
			{
				if (item.Id == o.Id)
				{
					return true;
				}
			}
		}
		catch
		{
		}
		return false;
	}

	private static bool Face(string rest)
	{
		if (!double.TryParse(rest, NumberStyles.Float, CultureInfo.InvariantCulture, out var result))
		{
			Util.WriteToChat("Invalid heading: " + rest);
			return true;
		}
		CoreManager.Current.Actions.FaceHeading(result, true);
		return true;
	}

	private static bool CombatStateCmd(string rest)
	{
		CombatState combatMode;
		switch (rest.Trim().ToLowerInvariant())
		{
		case "peace":
			combatMode = CombatState.Peace;
			break;
		case "melee":
			combatMode = CombatState.Melee;
			break;
		case "missile":
			combatMode = CombatState.Missile;
			break;
		case "magic":
			combatMode = CombatState.Magic;
			break;
		default:
			Util.WriteToChat("Usage: /ub combatstate (peace|melee|missile|magic)");
			return true;
		}
		CoreManager.Current.Actions.SetCombatMode(combatMode);
		return true;
	}

	private static bool Fellow(string rest)
	{
		string text = rest.ToLowerInvariant();
		switch (text)
		{
		case "quit":
			CM_Fellowship.Event_Quit(0);
			return true;
		case "disband":
			CM_Fellowship.Event_Quit(1);
			return true;
		default:
			if (!(text == "close"))
			{
				Match match = Regex.Match(rest, "^(?<v>recruit|dismiss|leader)(?<p>p)?(?: (?<n>.+))?$", RegexOptions.IgnoreCase);
				if (!match.Success)
				{
					return false;
				}
				string text2 = match.Groups["v"].Value.ToLowerInvariant();
				string text3 = match.Groups["n"].Value.Trim();
				WorldObject worldObject = FindPerson(text3, match.Groups["p"].Success && match.Groups["p"].Value.Length > 0, ObjectClass.Player);
				if (worldObject == null)
				{
					Util.WriteToChat("fellow " + text2 + ": no player " + ((text3.Length > 0) ? text3 : "nearby"));
					return true;
				}
				if (text2 == "recruit")
				{
					CM_Fellowship.Event_Recruit((uint)worldObject.Id);
				}
				else if (text2 == "dismiss")
				{
					CM_Fellowship.Event_Dismiss((uint)worldObject.Id);
				}
				else
				{
					CM_Fellowship.Event_AssignNewLeader((uint)worldObject.Id);
				}
				return true;
			}
			goto case "open";
		case "open":
			CM_Fellowship.Event_ChangeFellowOpeness((text == "open") ? 1 : 0);
			return true;
		}
	}

	[DllImport("user32.dll")]
	private static extern bool SystemParametersInfo(int action, int param, ref WRECT r, int winIni);

	[DllImport("user32.dll")]
	private static extern bool AdjustWindowRectEx(ref WRECT r, int style, bool menu, int exStyle);

	[DllImport("user32.dll")]
	private static extern int GetWindowLong(nint h, int idx);

	[DllImport("user32.dll")]
	private static extern bool SetWindowPos(nint h, nint after, int x, int y, int w, int hgt, int flags);

	private static bool Resolution(string rest)
	{
		string text = (rest ?? "").Trim();
		if (text.StartsWith("max", StringComparison.OrdinalIgnoreCase))
		{
			DisplayServer.WindowSetMode(DisplayServer.WindowMode.Maximized);
			Util.WriteToChat("Setting Resolution: maximized");
			return true;
		}
		Match match = Regex.Match(text, "^(\\d+)[x ](\\d+)$");
		if (!match.Success || !int.TryParse(match.Groups[1].Value, out var result) || !int.TryParse(match.Groups[2].Value, out var result2) || result < 100 || result2 < 100 || result > 10000 || result2 > 10000)
		{
			Util.WriteToChat("Requested resolution was not valid (" + rest + ")");
			return true;
		}
		Util.WriteToChat("Setting Resolution " + result + "x" + result2);
		DisplayServer.WindowSetMode(DisplayServer.WindowMode.Windowed);
		DisplayServer.WindowSetSize(new Vector2I(result, result2));
		return true;
	}

	private static void CommenceJump(int cs)
	{
		_acgCommence = DateTime.Now;
	}

	private static float JumpPower(int cs)
	{
		return (_acgCommence == DateTime.MinValue) ? 0f : ((float)Math.Min(1.0, (DateTime.Now - _acgCommence).TotalSeconds));
	}

	private static bool Jump(string f, string rest)
	{
		if (_j != JState.Idle)
		{
			Util.WriteToChat("You are already jumping. try again later.");
			return true;
		}
		Match match = JumpRx.Match(rest);
		if (!match.Success)
		{
			Util.WriteToChat("Usage: /ub jump[swzxc] [heading] [holdtime]");
			return true;
		}
		int result = 0;
		if (match.Groups["ms"].Success && match.Groups["ms"].Value.Length > 0 && (!int.TryParse(match.Groups["ms"].Value, out result) || result < 0 || result > 1000))
		{
			Util.WriteToChat("holdtime should be a number between 0 and 1000");
			return true;
		}
		double result2 = CoreManager.Current.Actions.Heading;
		bool flag = false;
		if (match.Groups["h"].Success && match.Groups["h"].Value.Length > 0)
		{
			if (!double.TryParse(match.Groups["h"].Value, NumberStyles.Float, CultureInfo.InvariantCulture, out result2))
			{
				Util.WriteToChat("direction should be a number between 0 and 359");
				return true;
			}
			// (past a full turn - a meta's "/vt jump 700 ..." - round again, as VTank takes it: 700 is 340)
			result2 %= 360.0;
			if (result2 < 0.0)
			{
				result2 += 360.0;
			}
			flag = true;
		}
		_jHeading = (float)result2;
		_jPower = Math.Min(1f, (float)result / 1000f);
		_jShift = f.Contains("s");
		_jW = f.Contains("w");
		_jX = f.Contains("x");
		_jZ = f.Contains("z");
		_jC = f.Contains("c");
		_jAt = DateTime.Now;
		_jTries = 0;
		if (flag)
		{
			CoreManager.Current.Actions.FaceHeading(result2, true);
			_jTurnAsk = DateTime.Now;
			_j = JState.Turning;
		}
		else
		{
			StartCharge();
		}
		if (!_frameHooked)
		{
			CoreManager.Current.RenderFrame += OnFrame;
			_frameHooked = true;
		}
		return true;
	}

	private static void StartCharge()
	{
		_j = JState.Charging;
		_jCharge = DateTime.Now;
		_jChargeStart = DateTime.Now;
		int combatSystem = CombatSystem;
		_jStartP = 0f;
		_jRising = false;
		try
		{
			if (combatSystem != 0)
			{
				_jStartP = JumpPower(combatSystem);
			}
		}
		catch
		{
		}
		CommenceJump(combatSystem);
	}

	private static void JumpDone()
	{
		_j = JState.Idle;
		if (_frameHooked)
		{
			try
			{
				CoreManager.Current.RenderFrame -= OnFrame;
			}
			catch
			{
			}
			_frameHooked = false;
		}
	}

	private static void OnFrame(object sender, EventArgs e)
	{
		try
		{
			if ((DateTime.Now - _jAt).TotalSeconds > 20.0)
			{
				Util.WriteToChat("Jump: gave up (took too long).");
				JumpDone();
				return;
			}
			if (_j == JState.Turning)
			{
				double num = Math.Abs(CoreManager.Current.Actions.Heading - (double)_jHeading) % 360.0;
				if (num > 180.0)
				{
					num = 360.0 - num;
				}
				if (num < 1.5)
				{
					StartCharge();
				}
				else if ((DateTime.Now - _jAt).TotalSeconds > 5.0)
				{
					Util.WriteToChat("Jump: turning failed.");
					JumpDone();
				}
				else if ((DateTime.Now - _jTurnAsk).TotalSeconds > 0.5)
				{
					_jTurnAsk = DateTime.Now;
					CoreManager.Current.Actions.FaceHeading(_jHeading, true);
				}
				return;
			}
			if (_j == JState.Checking)
			{
				double x;
				double y;
				double z;
				if (Airborne())
				{
					_jAir = true;
				}
				else if (_jAir)
				{
					JumpDone();
				}
				else if (MyPos(out x, out y, out z) && (z - _jZ0 > 0.15 || Math.Abs(x - _jX0) + Math.Abs(y - _jY0) > 0.3))
				{
					JumpDone();
				}
				else if (!((DateTime.Now - _jReleased).TotalSeconds < 1.5))
				{
					if (++_jTries >= 3)
					{
						Util.WriteToChat("Jump: failed to jump 3 times.");
						JumpDone();
					}
					else
					{
						StartCharge();
					}
				}
				return;
			}
			if (_j != JState.Charging)
			{
				JumpDone();
				return;
			}
			int combatSystem = CombatSystem;
			if (combatSystem == 0)
			{
				JumpDone();
				return;
			}
			float num2 = JumpPower(combatSystem);
			if (!_jRising)
			{
				if (!(num2 < _jStartP - 0.001f) && !(num2 < _jPower) && !((DateTime.Now - _jChargeStart).TotalSeconds > 0.25))
				{
					return;
				}
				_jRising = true;
			}
			if (num2 < _jPower)
			{
				if ((DateTime.Now - _jCharge).TotalSeconds > 1.25)
				{
					_jCharge = DateTime.Now;
					CommenceJump(combatSystem);
				}
			}
			else
			{
				MyPos(out _jX0, out _jY0, out _jZ0);
				Release();
				_jReleased = DateTime.Now;
				_jAir = false;
				_j = JState.Checking;
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			JumpDone();
		}
	}

	private static bool MyPos(out double x, out double y, out double z)
	{
		x = (y = (z = 0.0));
		ACGodot.Plugins.PluginHost host = Bridge.Host;
		if (host?.Player == null || !host.Player.Active)
		{
			return false;
		}
		(uint, double, double, double) tuple = Bridge.Place(host.Player.Position, host.Player.Cell);
		x = tuple.Item2;
		y = tuple.Item3;
		z = tuple.Item4;
		return true;
	}

	private static bool Airborne()
	{
		ACGodot.Plugins.PluginHost host = Bridge.Host;
		return host?.Player != null && host.Player.Airborne;
	}

	private static void Release()
	{
		ACGodot.Plugins.PluginHost host = Bridge.Host;
		if (host?.Player != null)
		{
			int keys = (_jW ? 1 : 0) | (_jX ? 2 : 0) | (_jZ ? 16 : 0) | (_jC ? 32 : 0);
			host.Player.PluginJump(_jPower, keys, _jShift);
		}
	}

	public static void Tick()
	{
		try
		{
			GiveTick();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			_give.Clear();
			_giveTarget = 0;
		}
	}

	public static void Dispose()
	{
		JumpDone();
		_give.Clear();
		_giveTarget = 0;
	}
}
