using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;

namespace MelkTank;

public static class NavPresets
{
	public static readonly List<NavRoute> All = new List<NavRoute>();

	private static DateTime _fileTime = DateTime.MinValue;

	private static DateTime _checkAt = DateTime.MinValue;

	private static bool _loaded;

	private static string Path => Util.FullPath("MelkTank_NavPresets.xml");

	public static bool Allowed(StepKind k)
	{
		return k == StepKind.Command || k == StepKind.Wait || k == StepKind.Toggle || k == StepKind.Cast || k == StepKind.ChatWait || k == StepKind.ItemCheck || k == StepKind.UseItem || k == StepKind.GoRoute || k == StepKind.PlayerSkip;
	}

	public static NavRoute Find(string name)
	{
		Load();
		if (string.IsNullOrEmpty(name))
		{
			return null;
		}
		foreach (NavRoute item in All)
		{
			if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
			{
				return item;
			}
		}
		return null;
	}

	public static List<string> Names()
	{
		Load();
		List<string> list = new List<string>();
		foreach (NavRoute item in All)
		{
			list.Add(item.Name);
		}
		return list;
	}

	public static void Load()
	{
		if (_loaded)
		{
			if (DateTime.Now >= _checkAt)
			{
				Reload(first: false);
			}
		}
		else
		{
			_loaded = true;
			Reload(first: true);
		}
	}

	private static void Reload(bool first)
	{
		_checkAt = DateTime.Now.AddSeconds(5.0);
		try
		{
			string path = Path;
			if (!File.Exists(path))
			{
				if (first && All.Count == 0)
				{
					NavRoute navRoute = new NavRoute
					{
						Name = "Mob Pack",
						Mode = 0
					};
					navRoute.Steps.Add(new RouteStep
					{
						Kind = StepKind.Toggle,
						Text = "combat on"
					});
					navRoute.Steps.Add(new RouteStep
					{
						Kind = StepKind.Wait,
						WaitMs = 1000
					});
					navRoute.Steps.Add(new RouteStep
					{
						Kind = StepKind.Toggle,
						Text = "combat off"
					});
					All.Add(navRoute);
					Save();
				}
				return;
			}
			DateTime lastWriteTimeUtc = File.GetLastWriteTimeUtc(path);
			if (!first && lastWriteTimeUtc == _fileTime)
			{
				return;
			}
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.Load(path);
			List<NavRoute> list = new List<NavRoute>();
			foreach (XmlNode item in xmlDocument.SelectNodes("/NavPresets/Preset"))
			{
				NavRoute navRoute2 = Settings.ReadRoute(item as XmlElement);
				if (navRoute2 != null && navRoute2.Name.Length != 0)
				{
					navRoute2.Steps.RemoveAll((RouteStep s) => !Allowed(s.Kind));
					list.Add(navRoute2);
				}
			}
			List<NavRoute> list2 = new List<NavRoute>();
			foreach (NavRoute p in list)
			{
				NavRoute navRoute3 = All.Find((NavRoute x) => string.Equals(x.Name, p.Name, StringComparison.Ordinal));
				if (navRoute3 != null)
				{
					navRoute3.Steps.Clear();
					navRoute3.Steps.AddRange(p.Steps);
					list2.Add(navRoute3);
				}
				else
				{
					list2.Add(p);
				}
			}
			All.Clear();
			All.AddRange(list2);
			_fileTime = lastWriteTimeUtc;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void Save()
	{
		try
		{
			XmlDocument xmlDocument = new XmlDocument();
			XmlElement xmlElement = xmlDocument.CreateElement("NavPresets");
			xmlDocument.AppendChild(xmlElement);
			foreach (NavRoute item in All)
			{
				XmlElement xmlElement2 = xmlDocument.CreateElement("Preset");
				Settings.WriteRoute(xmlDocument, xmlElement2, item);
				xmlElement.AppendChild(xmlElement2);
			}
			string path = Path;
			xmlDocument.Save(path);
			_fileTime = File.GetLastWriteTimeUtc(path);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static NavRoute Expanded(NavRoute r)
	{
		if (r == null || !r.Steps.Exists((RouteStep s) => s.Kind == StepKind.Preset))
		{
			return r;
		}
		NavRoute navRoute = new NavRoute
		{
			Name = r.Name,
			Mode = r.Mode,
			Arrive = r.Arrive,
			File = r.File,
			StuckAction = r.StuckAction,
			StuckBack = r.StuckBack,
			StuckAfter = r.StuckAfter,
			RestartIfFar = r.RestartIfFar,
			RestartFarM = r.RestartFarM,
			RestartIfStuck = r.RestartIfStuck,
			RestartStuckMin = r.RestartStuckMin
		};
		foreach (RouteStep step in r.Steps)
		{
			if (step.Kind != StepKind.Preset)
			{
				navRoute.Steps.Add(step);
				continue;
			}
			NavRoute navRoute2 = Find(step.Text);
			if (navRoute2 == null)
			{
				continue;
			}
			foreach (RouteStep step2 in navRoute2.Steps)
			{
				navRoute.Steps.Add(Copy(step2));
			}
		}
		return navRoute;
	}

	public static RouteStep Copy(RouteStep s)
	{
		RouteStep routeStep = new RouteStep
		{
			Kind = s.Kind,
			NS = s.NS,
			EW = s.EW,
			Z = s.Z,
			Text = s.Text,
			WaitMs = s.WaitMs,
			Op = s.Op,
			Count = s.Count,
			Profile = s.Profile
		};
		foreach (LoopCond cond in s.Conds)
		{
			routeStep.Conds.Add(new LoopCond
			{
				Chat = cond.Chat,
				Text = cond.Text,
				Op = cond.Op,
				Count = cond.Count
			});
		}
		return routeStep;
	}
}
