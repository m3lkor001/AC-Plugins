namespace MelkTank;

public enum Slot
{
	Fester,
	Broadside,
	Gravity,
	Imperil,
	Yield,
	Vuln,
	Arc,
	Ring,
	Streak,
	WeakeningCurse,
	FesteringCurse,
	Corruption,
	DestructiveCurse,
	Corrosion,
	Fracture
}
