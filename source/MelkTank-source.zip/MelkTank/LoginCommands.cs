using System;
using System.Collections.Generic;
using System.IO;
using System.Numerics;
using System.Xml;
using ImGuiNET;

namespace MelkTank;

public static class LoginCommands
{
	public class Cmd
	{
		public string Scope = "";

		public string When = "login";

		public int A;

		public int B;

		public string Text = "";

		public DateTime NextAt = DateTime.MinValue;
	}

	public const string AtLogin = "login";

	public const string After = "delay";

	public const string Every = "every";

	private static readonly Vector4 Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f);

	private static List<Cmd> _all;

	private const string DoneKey = "MelkTank.LoginCommandsDone";

	private static string _server = "";

	private static string _char = "";

	private static DateTime _loginAt = DateTime.MinValue;

	private static HashSet<string> _done = new HashSet<string>();

	public static Action<string> Log = (string m) =>
	{
	};

	private static DateTime _fileTime = DateTime.MinValue;

	private static DateTime _nextCheck = DateTime.MinValue;

	private static DateTime _nextFileCheck = DateTime.MinValue;

	private static string _newText = "";

	private static int _newScope = 0;

	private static int _newWhen = 0;

	private static int _newA = 30;

	private static int _newB = 0;

	private static readonly string[] Scopes = new string[2] { "This character", "Every character on this server" };

	private static readonly string[] Whens = new string[3] { "At login", "Seconds after login", "Every N minutes" };

	private static string File_ => Util.FullPath("MelkTank_LoginCommands.txt");

	private static string ServerScope => "server:" + _server;

	private static string CharScope => "char:" + _server + "/" + _char;

	public static List<Cmd> All
	{
		get
		{
			if (_all == null)
			{
				Load();
			}
			return _all;
		}
	}

	public static void Load()
	{
		_all = new List<Cmd>();
		try
		{
			_fileTime = (File.Exists(File_) ? File.GetLastWriteTimeUtc(File_) : DateTime.MinValue);
		}
		catch
		{
		}
		try
		{
			if (!File.Exists(File_))
			{
				return;
			}
			string[] array = Util.Locked(File_, () => File.ReadAllLines(File_));
			foreach (string text in array)
			{
				string[] array2 = text.Split('\t');
				if (array2.Length >= 5 && !text.StartsWith("#"))
				{
					Cmd cmd = new Cmd
					{
						Scope = array2[0],
						When = array2[1],
						Text = array2[4]
					};
					int.TryParse(array2[2], out cmd.A);
					int.TryParse(array2[3], out cmd.B);
					_all.Add(cmd);
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void SkipOverdue()
	{
		if (_loginAt == DateTime.MinValue)
		{
			return;
		}
		double totalSeconds = (DateTime.Now - _loginAt).TotalSeconds;
		bool flag = false;
		foreach (Cmd item in All)
		{
			if (!(item.When == "every") && Mine(item))
			{
				double num = ((item.When == "delay") ? Math.Max(0, item.A) : 0);
				if (totalSeconds >= num && _done.Add(Id(item)))
				{
					flag = true;
				}
			}
		}
		if (flag)
		{
			Remember();
		}
	}

	private static string Id(Cmd c)
	{
		return c.Scope + "|" + c.When + "|" + c.A + "|" + c.Text;
	}

	public static void Save()
	{
		try
		{
			List<string> list = new List<string> { "# scope<TAB>when (login / delay / every)<TAB>seconds or interval minutes<TAB>first-run minutes<TAB>command" };
			foreach (Cmd item in All)
			{
				list.Add(item.Scope + "\t" + item.When + "\t" + item.A + "\t" + item.B + "\t" + item.Text.Replace("\t", " "));
			}
			Util.WriteShared(File_, string.Join(Environment.NewLine, list.ToArray()) + Environment.NewLine);
			try
			{
				_fileTime = File.GetLastWriteTimeUtc(File_);
			}
			catch
			{
			}
			SkipOverdue();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static bool Mine(Cmd c)
	{
		return c.Scope == ServerScope || c.Scope == CharScope;
	}

	public static void LoggedIn(string server, string character)
	{
		_server = server ?? "";
		_char = character ?? "";
		Load();
		string text = _server + "/" + _char;
		string text2 = null;
		try
		{
			text2 = AppDomain.CurrentDomain.GetData("MelkTank.LoginCommandsDone") as string;
		}
		catch
		{
		}
		string[] array = text2?.Split('|');
		if (array != null && array.Length >= 2 && array[0] == text && long.TryParse(array[1], out var result))
		{
			_loginAt = new DateTime(result);
			_done = new HashSet<string>((array.Length > 2) ? array[2].Split(new char[1] { ',' }, StringSplitOptions.RemoveEmptyEntries) : new string[0]);
		}
		else
		{
			_loginAt = DateTime.Now;
			_done = new HashSet<string>();
			Remember();
		}
		foreach (Cmd item in All)
		{
			item.NextAt = DateTime.MinValue;
		}
	}

	private static void Remember()
	{
		try
		{
			AppDomain.CurrentDomain.SetData("MelkTank.LoginCommandsDone", _server + "/" + _char + "|" + _loginAt.Ticks + "|" + string.Join(",", new List<string>(_done).ToArray()));
		}
		catch
		{
		}
	}

	public static void Tick()
	{
		if (_loginAt == DateTime.MinValue || DateTime.Now < _nextCheck)
		{
			return;
		}
		_nextCheck = DateTime.Now.AddSeconds(1.0);
		DateTime now = DateTime.Now;
		if (now >= _nextFileCheck)
		{
			_nextFileCheck = now.AddSeconds(3.0);
			DateTime dateTime = DateTime.MinValue;
			try
			{
				dateTime = (File.Exists(File_) ? File.GetLastWriteTimeUtc(File_) : DateTime.MinValue);
			}
			catch
			{
			}
			if (dateTime != _fileTime)
			{
				Load();
				SkipOverdue();
				Log("LOGINCMD list read again (changed)");
			}
		}
		double totalSeconds = (now - _loginAt).TotalSeconds;
		foreach (Cmd item2 in All)
		{
			if (!Mine(item2) || item2.Text.Trim().Length == 0)
			{
				continue;
			}
			string item = Id(item2);
			if (item2.When == "every")
			{
				int num = Math.Max(1, item2.A);
				if (item2.NextAt == DateTime.MinValue)
				{
					DateTime nextAt = _loginAt.AddMinutes(Math.Max(0, item2.B));
					item2.NextAt = nextAt;
					while (item2.NextAt < now.AddSeconds(-5.0))
					{
						item2.NextAt = item2.NextAt.AddMinutes(num);
					}
				}
				if (now >= item2.NextAt)
				{
					Run(item2);
					item2.NextAt = item2.NextAt.AddMinutes(num);
				}
			}
			else if (!_done.Contains(item))
			{
				double num2 = ((item2.When == "delay") ? Math.Max(0, item2.A) : 0);
				if (!(totalSeconds < num2))
				{
					_done.Add(item);
					Remember();
					Run(item2);
				}
			}
		}
	}

	private static void Run(Cmd c)
	{
		Log("LOGINCMD " + c.When + ": " + c.Text);
		Util.Command(c.Text.Trim());
	}

	public static int ImportMagTools()
	{
		string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), "Decal Plugins\\Mag-Tools\\Mag-Tools.xml");
		if (!File.Exists(text))
		{
			Util.WriteToChat("Commands at login: no Mag-Tools settings at " + text + ".");
			return 0;
		}
		XmlDocument xmlDocument = new XmlDocument();
		xmlDocument.Load(text);
		int num = 0;
		string text2 = XmlConvert.EncodeLocalName(_server);
		foreach (XmlNode childNode in xmlDocument.DocumentElement.ChildNodes)
		{
			if (!(childNode is XmlElement))
			{
				continue;
			}
			if (childNode.Name == "_" + text2)
			{
				num += ImportLists(childNode, ServerScope);
			}
			else
			{
				if (!childNode.Name.EndsWith("_" + text2) || !childNode.Name.StartsWith("_"))
				{
					continue;
				}
				foreach (XmlNode childNode2 in childNode.ChildNodes)
				{
					if (childNode2 is XmlElement && XmlConvert.DecodeName(childNode2.Name) == _char)
					{
						num += ImportLists(childNode2, CharScope);
					}
				}
			}
		}
		if (num > 0)
		{
			Save();
		}
		return num;
	}

	private static int ImportLists(XmlNode parent, string scope)
	{
		int num = 0;
		foreach (XmlNode childNode in parent.ChildNodes)
		{
			string when;
			if (childNode.Name == "PeriodicCommands")
			{
				when = "every";
			}
			else
			{
				when = ((childNode.Name == "OnLoginCommands" || childNode.Name == "OnLoginCompleteCommands") ? "login" : null);
			}
			if (when == null)
			{
				continue;
			}
			foreach (XmlNode childNode2 in childNode.ChildNodes)
			{
				if (!(childNode2 is XmlElement))
				{
					continue;
				}
				string text = (childNode2.InnerText ?? "").Trim();
				if (text.Length == 0)
				{
					continue;
				}
				int result = 0;
				int result2 = 0;
				if (when == "every")
				{
					XmlAttribute xmlAttribute = childNode2.Attributes["interval"] ?? childNode2.Attributes["Interval"];
					XmlAttribute xmlAttribute2 = childNode2.Attributes["offset"] ?? childNode2.Attributes["Offset"];
					if (xmlAttribute == null || !int.TryParse(xmlAttribute.Value, out result))
					{
						result = 1;
					}
					if (xmlAttribute2 != null)
					{
						int.TryParse(xmlAttribute2.Value, out result2);
					}
				}
				if (!All.Exists((Cmd x) => x.Scope == scope && x.Text == text && x.When == when))
				{
					All.Add(new Cmd
					{
						Scope = scope,
						When = when,
						A = result,
						B = result2,
						Text = text
					});
					num++;
				}
			}
		}
		return num;
	}

	public static void Draw()
	{
		if (_server.Length == 0)
		{
			Im.TextColored(Grey, "Log in first.");
			return;
		}
		if (ImGui.CollapsingHeader("Hotkeys##lchk"))
		{
			ImGui.Indent();
			Hotkeys.Draw();
			ImGui.Unindent();
		}
		Im.TextColored(Grey, "Chat commands run for you - like Mag-Tools' On Login / Periodic Command lists. A hot reload doesn't run them again.");
		bool flag = false;
		int num = -1;
		if (ImGui.BeginTable("logincmds", 4, ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("For", ImGuiTableColumnFlags.WidthFixed, 110f);
			ImGui.TableSetupColumn("When", ImGuiTableColumnFlags.WidthFixed, 170f);
			ImGui.TableSetupColumn("Command", ImGuiTableColumnFlags.WidthStretch);
			ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 24f);
			ImGui.TableHeadersRow();
			for (int i = 0; i < All.Count; i++)
			{
				Cmd cmd = All[i];
				if (Mine(cmd))
				{
					ImGui.PushID("lc" + i);
					ImGui.TableNextRow();
					ImGui.TableSetColumnIndex(0);
					ImGui.TextUnformatted((cmd.Scope == CharScope) ? _char : "Server (all)");
					ImGui.TableSetColumnIndex(1);
					string? text;
					if (cmd.When == "login")
					{
						text = "At login";
					}
					else
					{
						text = ((cmd.When == "delay") ? (cmd.A + " s after login") : ("Every " + Math.Max(1, cmd.A) + " min" + ((cmd.B > 0) ? (", first at " + cmd.B + " min") : "")));
					}
					ImGui.TextUnformatted(text);
					ImGui.TableSetColumnIndex(2);
					ImGui.SetNextItemWidth(-1f);
					string input = cmd.Text;
					if (ImGui.InputText("##t", ref input, 300u))
					{
						cmd.Text = input;
						flag = true;
					}
					ImGui.TableSetColumnIndex(3);
					if (ImGui.SmallButton("x"))
					{
						num = i;
					}
					if (ImGui.IsItemHovered())
					{
						Im.SetTooltip("Remove");
					}
					ImGui.PopID();
				}
			}
			ImGui.EndTable();
		}
		if (num >= 0)
		{
			All.RemoveAt(num);
			flag = true;
		}
		ImGui.SetNextItemWidth(170f);
		ImGui.Combo("##lcscope", ref _newScope, Scopes, Scopes.Length);
		ImGui.SameLine();
		ImGui.SetNextItemWidth(160f);
		ImGui.Combo("##lcwhen", ref _newWhen, Whens, Whens.Length);
		if (_newWhen == 1)
		{
			ImGui.SameLine();
			ImGui.SetNextItemWidth(90f);
			ImGui.InputInt("s##lca", ref _newA, 5, 30);
		}
		if (_newWhen == 2)
		{
			ImGui.SameLine();
			ImGui.SetNextItemWidth(90f);
			ImGui.InputInt("min##lcia", ref _newA, 1, 5);
			ImGui.SameLine();
			ImGui.SetNextItemWidth(90f);
			ImGui.InputInt("first at min##lcib", ref _newB, 1, 5);
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Minutes after login for the first run (0 = straight away).");
			}
		}
		ImGui.SetNextItemWidth(-60f);
		ImGui.InputTextWithHint("##lcnew", "/command to run", ref _newText, 300u);
		ImGui.SameLine();
		if (ImGui.Button("Add##lcadd") && _newText.Trim().Length > 0)
		{
			All.Add(new Cmd
			{
				Scope = ((_newScope == 0) ? CharScope : ServerScope),
				When = ((_newWhen == 0) ? "login" : ((_newWhen == 1) ? "delay" : "every")),
				A = ((_newWhen != 0) ? Math.Max((_newWhen == 2) ? 1 : 0, _newA) : 0),
				B = ((_newWhen == 2) ? Math.Max(0, _newB) : 0),
				Text = _newText.Trim()
			});
			_newText = "";
			flag = true;
		}
		if (ImGui.Button("Import from Mag-Tools##lcimp"))
		{
			int num2 = 0;
			try
			{
				num2 = ImportMagTools();
			}
			catch (Exception ex)
			{
				Util.WriteToChat("Commands at login: couldn't read Mag-Tools' settings (" + ex.Message + ").");
			}
			Util.WriteToChat("Commands at login: " + ((num2 > 0) ? (num2 + " command(s) brought over from Mag-Tools.") : "nothing new to bring over from Mag-Tools."));
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Copies Mag-Tools' On Login, On Login Complete and Periodic commands for this server and this character.\nRun them from here, then take them out of Mag-Tools (or switch it off) so they don't run twice.");
		}
		ImGui.SameLine();
		if (ImGui.Button("Run the login ones now##lcrun"))
		{
			foreach (Cmd item in All)
			{
				if (Mine(item) && item.When != "every" && item.Text.Trim().Length > 0)
				{
					Run(item);
				}
			}
		}
		if (flag)
		{
			Save();
		}
	}
}
