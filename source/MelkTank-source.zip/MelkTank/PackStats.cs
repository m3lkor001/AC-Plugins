using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Text;
using System.Text.RegularExpressions;
using ImGuiNET;

namespace MelkTank;

public static class PackStats
{
	public class Pack
	{
		public int N;

		public int Set;

		public double DotPct = -1.0;

		public DateTime Start;

		public DateTime End = DateTime.MinValue;

		public double FightS;

		public double LootS;

		public int Kills;

		public int Debuffs;

		public int Streaks;

		public int Rings;

		public int Arcs;

		public int Melee;

		public int Releases;

		public int Drops;

		public int Heals;

		public string Route = "";

		public int Step;

		public readonly List<string> Names = new List<string>();

		public readonly Dictionary<string, double> T = new Dictionary<string, double>();

		public double SegS;

		public string SegKey;

		public bool Out;
	}

	private class Seg
	{
		public string Route;

		public int From;

		public double Secs;

		public int Kills;

		public int Packs;
	}

	private class Slow
	{
		public DateTime At;

		public string Text;
	}

	private class Fam
	{
		public int Kills;

		public double Hp;

		public double Over;

		public double Streak;

		public double Burst;

		public double Other;

		public double Dot;
	}

	private class DotStat
	{
		public double Sum;

		public double Max;

		public int Casts;

		public int Ticks;

		public int Crits;
	}

	private class Avg
	{
		public double Sum;

		public int N;
	}

	public const int SegSteps = 20;

	public const double SlowStreakS = 15.0;

	private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

	private static readonly List<Pack> _packs = new List<Pack>();

	private static Pack _cur;

	private static Pack _last;

	private static int _packN;

	private static readonly Dictionary<string, double> _time = new Dictionary<string, double>();

	private static readonly Dictionary<string, Seg> _segs = new Dictionary<string, Seg>();

	private static readonly Dictionary<string, double> _dmg = new Dictionary<string, double>();

	private static readonly List<Slow> _slow = new List<Slow>();

	private static int _slowCount;

	private static DateTime _lastTick = DateTime.MinValue;

	private static DateTime _idleCheck = DateTime.MinValue;

	private static int _killsSeen = -1;

	private static int _outKills;

	private static double _outSecs;

	private static DateTime _outChainAt = DateTime.MinValue;

	private static string _lastSegKey;

	private static readonly Dictionary<int, KeyValuePair<DateTime, DateTime>> _streak = new Dictionary<int, KeyValuePair<DateTime, DateTime>>();

	private static readonly Dictionary<int, string> _streakName = new Dictionary<int, string>();

	private static readonly HashSet<int> _idleLogged = new HashSet<int>();

	private static readonly Dictionary<int, DateTime> _idleSince = new Dictionary<int, DateTime>();

	private static string _outRaw;

	private static HashSet<string> _out = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

	public static Func<int> RouteStep;

	public static Func<string> RouteName;

	private static readonly Regex TargetRx = new Regex("-> (?<n>.+?) \\[(?<id>-?\\d+)\\]", RegexOptions.Compiled);

	private static readonly Regex FractureRx = new Regex("^Your Nether Fracture strikes (?<t>.+?) for (?<n>[\\d,]+) points", RegexOptions.Compiled);

	private static readonly Regex SpellRx = new Regex("^(?:(?:Critical hit|Sneak Attack|Overpower)! )*You \\w+ (?<t>.+?) for (?<n>[\\d,]+) points? with (?:Incantation of )?(?<s>.+?)\\.?$", RegexOptions.Compiled);

	private static readonly Regex WeaponRx = new Regex("^(?:(?:Critical hit|Sneak Attack|Overpower)! )*You \\w+ (?<t>.+?) for (?<n>[\\d,]+) points? of \\w+ damage", RegexOptions.Compiled);

	private static readonly Regex PetRx = new Regex("^\\[Pet\\] .+? hit .+? for (?<n>[\\d,]+)", RegexOptions.Compiled);

	private static readonly Regex DotRx = new Regex("^Your (?:Incantation of )?(?<s>.+?) deals (?<n>[\\d,]+) points? of periodic (?<el>\\w+) damage to (?<t>.+?) \\((?<k>\\d+) ticks?(?:, (?<c>\\d+) critical)?\\)", RegexOptions.Compiled);

	private static readonly Dictionary<string, DotStat> _dots = new Dictionary<string, DotStat>();

	private static bool _dotSeen;

	private static readonly Dictionary<string, Fam> _fam = new Dictionary<string, Fam>();

	private static readonly Dictionary<string, Fam> _packFam = new Dictionary<string, Fam>();

	private static readonly Regex OverRx = new Regex("\\[Overkill: (?<n>[\\d,]+)\\]", RegexOptions.Compiled);

	private static readonly HashSet<string> _seenNames = new HashSet<string>(StringComparer.Ordinal);

	private static readonly string[] Roles = new string[8] { " Battlemage", " Bowyer", " Skirmisher", " Sorcerer", " Spellslinger", " Warmaster", " Grenadier", " Ravager" };

	private static readonly Dictionary<string, Avg> _avg = new Dictionary<string, Avg>();

	private static DateTime _lastHitAt = DateTime.MinValue;

	private static DateTime _lastAtkAt = DateTime.MinValue;

	private static string _lastHitSrc;

	private static string _lastAtkSrc;

	private static string _lastAtkFam;

	private static int _hitKills;

	private static int _dotKills;

	private static int _writes;

	private static readonly Vector4 Grey = new Vector4(0.62f, 0.62f, 0.62f, 1f);

	private static readonly Vector4 Cyan = new Vector4(0.35f, 0.85f, 0.95f, 1f);

	private static readonly Vector4 Orange = new Vector4(1f, 0.6f, 0.27f, 1f);

	private static readonly Vector4 Green = new Vector4(0.45f, 0.9f, 0.45f, 1f);

	public static double IdleS => Tuning.V("SlowIdleS");

	public static double OutSecs => _outSecs;

	private static string FilePath
	{
		get
		{
			string text = "";
			try
			{
				text = Globals.Core.CharacterFilter.Name ?? "";
			}
			catch
			{
			}
			StringBuilder stringBuilder = new StringBuilder();
			string text2 = text;
			foreach (char c in text2)
			{
				stringBuilder.Append(char.IsLetterOrDigit(c) ? c : '_');
			}
			return Util.FullPath("MelkTank_Packs_" + ((stringBuilder.Length > 0) ? stringBuilder.ToString() : "unknown") + ".txt");
		}
	}

	private static HashSet<string> OutSet()
	{
		string text = "";
		try
		{
			text = ((PluginCore.CurrentSettings != null) ? (PluginCore.CurrentSettings.TuneOut ?? "") : "");
		}
		catch
		{
		}
		if (text != _outRaw)
		{
			_outRaw = text;
			_out = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
			string[] array = text.Split('|');
			foreach (string text2 in array)
			{
				if (text2.Trim().Length > 0)
				{
					_out.Add(text2.Trim());
				}
			}
		}
		return _out;
	}

	public static bool IsOut(string name)
	{
		if (string.IsNullOrEmpty(name))
		{
			return false;
		}
		HashSet<string> hashSet = OutSet();
		if (hashSet.Count == 0)
		{
			return false;
		}
		string text = name.Trim();
		return hashSet.Contains(text) || hashSet.Contains(Family(text));
	}

	public static bool SetOut(string name, bool? want)
	{
		name = (name ?? "").Trim();
		if (name.Length == 0)
		{
			return false;
		}
		HashSet<string> hashSet = new HashSet<string>(OutSet(), StringComparer.OrdinalIgnoreCase);
		bool flag = want ?? (!hashSet.Contains(name));
		if (flag)
		{
			hashSet.Add(name);
		}
		else
		{
			hashSet.Remove(name);
		}
		List<string> list = new List<string>(hashSet);
		list.Sort(StringComparer.OrdinalIgnoreCase);
		string text = string.Join("|", list.ToArray());
		try
		{
			SettingsTools.Set("TuneOut", text, "");
		}
		catch
		{
		}
		try
		{
			if (PluginCore.CurrentSettings != null)
			{
				PluginCore.CurrentSettings.TuneOut = text;
			}
		}
		catch
		{
		}
		return flag;
	}

	public static void Reset()
	{
		_packs.Clear();
		_cur = null;
		_last = null;
		_packN = 0;
		_time.Clear();
		_segs.Clear();
		_dmg.Clear();
		_avg.Clear();
		_hitKills = (_dotKills = 0);
		_fam.Clear();
		_packFam.Clear();
		_dots.Clear();
		_dotSeen = false;
		_seenNames.Clear();
		_slow.Clear();
		_slowCount = 0;
		_killsSeen = -1;
		_outKills = 0;
		_outSecs = 0.0;
		_outChainAt = DateTime.MinValue;
		_streak.Clear();
		_streakName.Clear();
		_idleLogged.Clear();
		_idleSince.Clear();
	}

	public static void PackStart()
	{
		FlushLast();
		_cur = new Pack
		{
			N = ++_packN,
			Start = DateTime.Now
		};
		_packFam.Clear();
		try
		{
			_cur.Step = ((RouteStep != null) ? RouteStep() : 0);
			_cur.Route = ((RouteName != null) ? (RouteName() ?? "") : "");
		}
		catch
		{
		}
	}

	public static bool PackEnd(int kills, double secs)
	{
		if (_cur == null)
		{
			return false;
		}
		_cur.End = DateTime.Now;
		_cur.FightS = secs;
		_cur.Kills = kills;
		bool flag = _cur.Names.Count > 0;
		foreach (string name in _cur.Names)
		{
			if (!IsOut(name))
			{
				flag = false;
				break;
			}
		}
		if (flag)
		{
			DateTime dateTime = ((_outChainAt != DateTime.MinValue && _outChainAt < _cur.Start) ? _outChainAt : _cur.Start);
			_outSecs += Math.Max(0.0, (_cur.End - dateTime).TotalSeconds);
			_outChainAt = _cur.End;
		}
		else if (_cur.Names.Count > 0)
		{
			_outChainAt = DateTime.MinValue;
		}
		if (flag)
		{
			_cur.Out = true;
			foreach (KeyValuePair<string, double> item in _cur.T)
			{
				Add(_time, item.Key, 0.0 - item.Value);
			}
			if (_cur.SegKey != null && _segs.TryGetValue(_cur.SegKey, out var value))
			{
				value.Secs -= _cur.SegS;
			}
		}
		try
		{
			_cur.Set = PackSettings.Current(Write);
		}
		catch
		{
		}
		if (kills > 0)
		{
			_packs.Add(_cur);
			if (_packs.Count > 50)
			{
				_packs.RemoveAt(0);
			}
			if (!_cur.Out)
			{
				Seg seg = SegFor(_cur.Route, _cur.Step);
				if (seg != null)
				{
					seg.Packs++;
				}
			}
			_last = _cur;
		}
		_cur = null;
		return flag;
	}

	private static void FlushLast()
	{
		if (_last != null)
		{
			Pack last = _last;
			_last = null;
			try
			{
				last.DotPct = DotPct(_packFam);
			}
			catch
			{
			}
			Write(DateTime.Now.ToString("HH:mm:ss", Inv) + "  PACK " + last.N + (last.Out ? " (left out)" : "") + ((last.Set > 0) ? ("  set " + last.Set) : "") + "  " + ((last.Route.Length > 0) ? (last.Route + " step " + last.Step + "  ") : "") + "fight " + last.FightS.ToString("0.0", Inv) + "s  loot " + last.LootS.ToString("0.0", Inv) + "s  kills " + last.Kills + "  debuffs " + last.Debuffs + "  streaks " + last.Streaks + ((last.Rings > 0) ? ("  rings " + last.Rings) : "") + ((last.Arcs > 0) ? ("  arcs " + last.Arcs) : "") + ((last.Melee > 0) ? ("  swings " + last.Melee) : "") + "  releases " + last.Releases + "  drops " + last.Drops + ((last.DotPct >= 0.0) ? ("  dot " + last.DotPct.ToString("0", Inv) + "%") : "") + ((last.Heals > 0) ? ("  heals " + last.Heals) : "") + "  [" + string.Join(", ", last.Names.ToArray()) + "]");
		}
	}

	public static void OnEvent(string line)
	{
		int result = 0;
		string text = null;
		string text2 = null;
		if (line.StartsWith("ATK ", StringComparison.Ordinal))
		{
			string text3 = ((line.Length > 6) ? line.Substring(6) : "");
			int num = text3.IndexOf(" -> ", StringComparison.Ordinal);
			if (num > 0)
			{
				text3 = text3.Substring(0, num);
			}
			if (line.IndexOf("] power ", StringComparison.Ordinal) >= 0)
			{
				text2 = "melee";
			}
			else if (text3.IndexOf("Streak", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				text2 = "streak";
			}
			else
			{
				text2 = ((text3.IndexOf(" Arc", StringComparison.Ordinal) >= 0 || text3.IndexOf(" Bolt", StringComparison.Ordinal) >= 0 || text3.IndexOf(" Blast", StringComparison.Ordinal) >= 0) ? "arc" : "ring");
			}
			Match match = TargetRx.Match(line);
			if (match.Success)
			{
				int.TryParse(match.Groups["id"].Value, out result);
				text = match.Groups["n"].Value;
			}
			_lastAtkAt = DateTime.Now;
			_lastAtkSrc = ((text2 == "melee") ? "Weapon" : StripIncantation(text3.Trim()));
			_lastAtkFam = ((text != null) ? Family(text) : null);
		}
		Pack pack = _cur ?? _last;
		if (line.StartsWith("CAST ", StringComparison.Ordinal))
		{
			if (pack != null)
			{
				pack.Debuffs++;
			}
		}
		else if (line.StartsWith("ATK ", StringComparison.Ordinal))
		{
			if (pack != null)
			{
				switch (text2)
				{
				case "ring":
					pack.Rings++;
					break;
				case "arc":
					pack.Arcs++;
					break;
				case "melee":
					pack.Melee++;
					break;
				default:
					pack.Streaks++;
					break;
				}
			}
			if (result != 0 && text2 == "streak")
			{
				_streak[result] = (_streak.TryGetValue(result, out var value) ? new KeyValuePair<DateTime, DateTime>(value.Key, DateTime.Now) : new KeyValuePair<DateTime, DateTime>(DateTime.Now, DateTime.Now));
				_streakName[result] = text ?? "";
			}
		}
		else if (line.StartsWith("FRACT released", StringComparison.Ordinal))
		{
			if (pack != null)
			{
				pack.Releases++;
			}
		}
		else if (line.StartsWith("NOSTART", StringComparison.Ordinal) || line.StartsWith("MISS  no 'You cast'", StringComparison.Ordinal))
		{
			if (pack != null)
			{
				pack.Drops++;
			}
		}
		else if (line.StartsWith("HEAL ", StringComparison.Ordinal) && pack != null)
		{
			pack.Heals++;
		}
	}

	public static void Gone(int id, string name)
	{
		if (_streak.TryGetValue(id, out var value))
		{
			double totalSeconds = (value.Value - value.Key).TotalSeconds;
			if (totalSeconds > 15.0 && !IsOut(name))
			{
				AddSlow("streaked " + totalSeconds.ToString("0") + "s before it died: " + (name ?? "?") + " [" + id + "] (no DoTs on it?)");
			}
			_streak.Remove(id);
			_streakName.Remove(id);
		}
		_idleSince.Remove(id);
		_idleLogged.Remove(id);
		Pack pack = _cur ?? _last;
		if (pack != null && !string.IsNullOrEmpty(name) && pack.Names.Count < 12 && !pack.Names.Contains(name))
		{
			pack.Names.Add(name);
		}
	}

	private static void AddSlow(string text)
	{
		_slowCount++;
		_slow.Add(new Slow
		{
			At = DateTime.Now,
			Text = text
		});
		if (_slow.Count > 30)
		{
			_slow.RemoveAt(0);
		}
		Write(DateTime.Now.ToString("HH:mm:ss", Inv) + "  SLOW " + text);
	}

	public static void Tick(string status, List<KeyValuePair<int, string>> inRangeUntouched, int killsNow)
	{
		DateTime now = DateTime.Now;
		double num = ((_lastTick == DateTime.MinValue) ? 0.0 : Math.Min(1.0, (now - _lastTick).TotalSeconds));
		_lastTick = now;
		string text = Category(status ?? "");
		bool flag = text == "Looting" && _cur == null && _last != null && _last.Out;
		if (!flag)
		{
			Add(_time, text, num);
		}
		if (_cur != null)
		{
			Add(_cur.T, text, num);
		}
		if (text == "Looting")
		{
			Pack pack = _cur ?? _last;
			if (pack != null)
			{
				pack.LootS += num;
			}
		}
		if (_last != null && _cur == null && (now - _last.End).TotalSeconds > 120.0 && text != "Looting")
		{
			FlushLast();
		}
		int step = 0;
		string route = "";
		try
		{
			step = ((RouteStep != null) ? RouteStep() : 0);
			route = ((RouteName != null) ? (RouteName() ?? "") : "");
		}
		catch
		{
		}
		Seg seg = SegFor(route, step);
		if (seg != null && !flag)
		{
			seg.Secs += num;
		}
		if (seg != null && _cur != null)
		{
			_cur.SegS += num;
			_cur.SegKey = _lastSegKey;
		}
		if (_killsSeen < 0)
		{
			_killsSeen = killsNow;
		}
		if (killsNow > _killsSeen)
		{
			int num2 = killsNow - _killsSeen;
			int num3 = Math.Min(num2, _outKills);
			_outKills -= num3;
			if (seg != null)
			{
				seg.Kills += num2 - num3;
			}
			_killsSeen = killsNow;
		}
		else if (killsNow < _killsSeen)
		{
			_killsSeen = killsNow;
		}
		if (inRangeUntouched == null || !((now - _idleCheck).TotalSeconds >= 1.0))
		{
			return;
		}
		_idleCheck = now;
		HashSet<int> hashSet = new HashSet<int>();
		foreach (KeyValuePair<int, string> item in inRangeUntouched)
		{
			hashSet.Add(item.Key);
			if (!_idleSince.TryGetValue(item.Key, out var value))
			{
				_idleSince[item.Key] = now;
			}
			else if ((now - value).TotalSeconds > IdleS && !IsOut(item.Value) && _idleLogged.Add(item.Key))
			{
				AddSlow("left alone " + (now - value).TotalSeconds.ToString("0") + "s in range with nothing cast on it: " + item.Value + " [" + item.Key + "]");
			}
		}
		List<int> list = new List<int>();
		foreach (int key in _idleSince.Keys)
		{
			if (!hashSet.Contains(key))
			{
				list.Add(key);
			}
		}
		foreach (int item2 in list)
		{
			_idleSince.Remove(item2);
		}
	}

	private static Seg SegFor(string route, int step)
	{
		if (string.IsNullOrEmpty(route) || step <= 0)
		{
			return null;
		}
		int num = (step - 1) / 20 * 20 + 1;
		string text = route + "|" + num;
		if (!_segs.TryGetValue(text, out var value))
		{
			value = new Seg
			{
				Route = route,
				From = num
			};
			_segs[text] = value;
		}
		_lastSegKey = text;
		return value;
	}

	public static string Category(string st)
	{
		if (st.StartsWith("Looting"))
		{
			return "Looting";
		}
		if (st.StartsWith("Attacking"))
		{
			return "Streaking / attacking";
		}
		if (st.StartsWith("Casting"))
		{
			return "Casting debuffs";
		}
		if (st.StartsWith("Nether Fracture"))
		{
			return "Fracture release";
		}
		if (st.StartsWith("Waiting - DoTs"))
		{
			return "Waiting on DoTs";
		}
		if (st.StartsWith("Waiting - pet summoner"))
		{
			return "Waiting on pet summoner";
		}
		if (st.StartsWith("Waiting - cast recovery"))
		{
			return "Cast recovery";
		}
		if (st.StartsWith("Waiting - equipping") || st.StartsWith("Waiting - changing combat mode") || st.StartsWith("Equipping") || st.StartsWith("Switching"))
		{
			return "Weapon swaps";
		}
		if (st.StartsWith("Waiting"))
		{
			return "Other waits";
		}
		if (st.StartsWith("Nav"))
		{
			return "Running (nav)";
		}
		if (st.StartsWith("Healing") || st.StartsWith("Restoring"))
		{
			return "Healing / mana";
		}
		if (st.StartsWith("Buffing"))
		{
			return "Buffing";
		}
		if (st.StartsWith("Debuffs up"))
		{
			return "Nothing to cast";
		}
		if (st.StartsWith("No monsters") || st.StartsWith("Idle"))
		{
			return "Idle";
		}
		return "Other";
	}

	private static void Add(Dictionary<string, double> d, string k, double v)
	{
		d.TryGetValue(k, out var value);
		d[k] = value + v;
	}

	public static void OnChat(string text)
	{
		if (string.IsNullOrEmpty(text))
		{
			return;
		}
		if (text.IndexOf("[Overkill:", StringComparison.Ordinal) >= 0)
		{
			Overkill(text);
		}
		if (!text.StartsWith("Your ", StringComparison.Ordinal) || !DotLine(text))
		{
			Match m;
			if ((m = FractureRx.Match(text)).Success)
			{
				AddDmg("Nether Fracture burst", m);
			}
			else if ((m = SpellRx.Match(text)).Success)
			{
				AddDmg(m.Groups["s"].Value.Trim(), m);
			}
			else if ((m = WeaponRx.Match(text)).Success)
			{
				AddDmg("Weapon", m);
			}
			else if ((m = PetRx.Match(text)).Success)
			{
				AddDmg("Pet", m);
			}
		}
	}

	private static void AddDmg(string src, Match m)
	{
		if (double.TryParse(m.Groups["n"].Value.Replace(",", ""), NumberStyles.Float, Inv, out var result) && (!m.Groups["t"].Success || !IsOut(m.Groups["t"].Value.Trim())))
		{
			Add(_dmg, src, result);
			if (!_avg.TryGetValue(src, out var value))
			{
				value = new Avg();
				_avg[src] = value;
			}
			value.Sum += result;
			value.N++;
			_lastHitAt = DateTime.Now;
			_lastHitSrc = src;
			string text = (m.Groups["t"].Success ? m.Groups["t"].Value.Trim() : "");
			if (text.Length > 0)
			{
				Hit(text, result, (src.IndexOf("Fracture", StringComparison.Ordinal) >= 0) ? 1 : 0);
			}
		}
	}

	private static bool DotLine(string text)
	{
		Match match = DotRx.Match(text);
		if (!match.Success)
		{
			return false;
		}
		int result = 0;
		if (!double.TryParse(match.Groups["n"].Value.Replace(",", ""), NumberStyles.Float, Inv, out var result2))
		{
			return true;
		}
		int.TryParse(match.Groups["k"].Value, out var result3);
		if (match.Groups["c"].Success)
		{
			int.TryParse(match.Groups["c"].Value, out result);
		}
		string text2 = match.Groups["s"].Value.Trim();
		if (IsOut(match.Groups["t"].Value.Trim()))
		{
			return true;
		}
		_dotSeen = true;
		Add(_dmg, text2 + " (DoT)", result2);
		if (!_dots.TryGetValue(text2, out var value))
		{
			value = new DotStat();
			_dots[text2] = value;
		}
		value.Sum += result2;
		value.Casts++;
		value.Ticks += result3;
		value.Crits += result;
		if (result2 > value.Max)
		{
			value.Max = result2;
		}
		string text3 = match.Groups["t"].Value.Trim();
		_seenNames.Add(text3);
		string fam = Family(text3);
		Dictionary<string, Fam>[] array = new Dictionary<string, Fam>[2] { _fam, _packFam };
		foreach (Dictionary<string, Fam> d in array)
		{
			F(d, fam).Dot += result2;
		}
		return true;
	}

	private static double DotOf(Fam f)
	{
		return _dotSeen ? f.Dot : (f.Hp + f.Over - f.Streak - f.Burst);
	}

	public static string Family(string name)
	{
		string text = (name ?? "").Trim();
		string[] array = new string[2] { "Enraged ", "Shiny " };
		foreach (string text2 in array)
		{
			if (text.StartsWith(text2, StringComparison.Ordinal))
			{
				text = text.Substring(text2.Length);
			}
		}
		string[] roles = Roles;
		foreach (string text3 in roles)
		{
			if (text.EndsWith(text3, StringComparison.Ordinal) && text.Length > text3.Length + 2)
			{
				text = text.Substring(0, text.Length - text3.Length);
				break;
			}
		}
		return text;
	}

	private static Fam F(Dictionary<string, Fam> d, string fam)
	{
		if (!d.TryGetValue(fam, out var value))
		{
			value = (d[fam] = new Fam());
		}
		return value;
	}

	private static void Hit(string target, double n, int kind)
	{
		if (IsOut(target))
		{
			return;
		}
		_seenNames.Add(target);
		string fam = Family(target);
		Dictionary<string, Fam>[] array = new Dictionary<string, Fam>[2] { _fam, _packFam };
		foreach (Dictionary<string, Fam> d in array)
		{
			Fam fam2 = F(d, fam);
			switch (kind)
			{
			case 1:
				fam2.Burst += n;
				break;
			case 0:
				if (n > 0.0)
				{
					fam2.Streak += n;
				}
				break;
			}
		}
	}

	public static void Killed(string name)
	{
		if (IsOut(name))
		{
			_outKills++;
			return;
		}
		_seenNames.Add(name);
		int num = 0;
		try
		{
			num = GameInfo.MaxHealth(name);
		}
		catch
		{
		}
		if (num > 0)
		{
			string fam = Family(name);
			Dictionary<string, Fam>[] array = new Dictionary<string, Fam>[2] { _fam, _packFam };
			foreach (Dictionary<string, Fam> d in array)
			{
				Fam fam2 = F(d, fam);
				fam2.Kills++;
				fam2.Hp += num;
			}
		}
	}

	private static void Overkill(string text)
	{
		Match match = OverRx.Match(text);
		if (!match.Success || !double.TryParse(match.Groups["n"].Value.Replace(",", ""), NumberStyles.Float, Inv, out var result))
		{
			return;
		}
		string text2 = null;
		foreach (string seenName in _seenNames)
		{
			if (text.IndexOf(seenName, StringComparison.Ordinal) >= 0 && (text2 == null || seenName.Length > text2.Length))
			{
				text2 = seenName;
			}
		}
		if (text2 == null || IsOut(text2))
		{
			return;
		}
		string text3 = Family(text2);
		Dictionary<string, Fam>[] array = new Dictionary<string, Fam>[2] { _fam, _packFam };
		foreach (Dictionary<string, Fam> d in array)
		{
			F(d, text3).Over += result;
		}
		DateTime now = DateTime.Now;
		string text4 = null;
		if ((now - _lastHitAt).TotalSeconds <= 0.3)
		{
			text4 = _lastHitSrc;
		}
		else if ((now - _lastAtkAt).TotalSeconds <= 1.5 && (_lastAtkFam == null || _lastAtkFam == text3))
		{
			text4 = _lastAtkSrc;
		}
		if (text4 == null)
		{
			_dotKills++;
			return;
		}
		double num = ((_avg.TryGetValue(text4, out var value) && value.N > 0) ? Math.Max(value.Sum / (double)value.N, result) : result);
		Add(_dmg, text4, num);
		Dictionary<string, Fam>[] array2 = new Dictionary<string, Fam>[2] { _fam, _packFam };
		foreach (Dictionary<string, Fam> d2 in array2)
		{
			Fam fam = F(d2, text3);
			if (text4.IndexOf("Fracture", StringComparison.Ordinal) >= 0)
			{
				fam.Burst += num;
			}
			else
			{
				fam.Streak += num;
			}
		}
		_hitKills++;
	}

	private static string StripIncantation(string spell)
	{
		return spell.StartsWith("Incantation of ", StringComparison.Ordinal) ? spell.Substring(15) : spell;
	}

	private static double DotTotal()
	{
		double num = 0.0;
		foreach (Fam value in _fam.Values)
		{
			if (value.Kills > 0)
			{
				num += Math.Max(0.0, DotOf(value));
			}
		}
		return num;
	}

	private static List<KeyValuePair<string, double>> DmgWithDots()
	{
		List<KeyValuePair<string, double>> list = new List<KeyValuePair<string, double>>(_dmg);
		double num = (_dotSeen ? 0.0 : DotTotal());
		if (num > 0.0)
		{
			list.Add(new KeyValuePair<string, double>("DoTs (estimated)", num));
		}
		list.Sort((KeyValuePair<string, double> x, KeyValuePair<string, double> y) => y.Value.CompareTo(x.Value));
		return list;
	}

	private static double DotPct(Dictionary<string, Fam> d)
	{
		double num = 0.0;
		double num2 = 0.0;
		foreach (Fam value in d.Values)
		{
			if (value.Kills != 0)
			{
				double num3 = value.Hp + value.Over;
				num += num3;
				num2 += DotOf(value);
			}
		}
		return (num > 0.0) ? Math.Max(0.0, 100.0 * num2 / num) : (-1.0);
	}

	private static List<KeyValuePair<string, Fam>> FamSorted()
	{
		List<KeyValuePair<string, Fam>> list = new List<KeyValuePair<string, Fam>>();
		foreach (KeyValuePair<string, Fam> item in _fam)
		{
			if (item.Value.Kills > 0)
			{
				list.Add(item);
			}
		}
		list.Sort((KeyValuePair<string, Fam> x, KeyValuePair<string, Fam> y) => y.Value.Kills.CompareTo(x.Value.Kills));
		return list;
	}

	public static void NoteLine(string line)
	{
		Write(line);
	}

	private static void Write(string line)
	{
		try
		{
			string path = FilePath;
			Util.AppendShared(path, line + Environment.NewLine);
			if (++_writes % 50 != 0)
			{
				return;
			}
			FileInfo fileInfo = new FileInfo(path);
			long num = (long)(Tuning.V("DebugMaxMB") * 1024.0 * 1024.0);
			if (fileInfo.Exists && fileInfo.Length > num)
			{
				Util.Locked(path, () =>
				{
					string[] array = File.ReadAllLines(path);
					int num2 = array.Length / 2;
					string[] array2 = new string[num2];
					Array.Copy(array, array.Length - num2, array2, 0, num2);
					File.WriteAllLines(path, array2);
				});
			}
		}
		catch
		{
		}
	}

	public static void AppendJson(StringBuilder b, Func<string, string> q)
	{
		b.Append(",\n  \"packList\": [");
		List<Pack> list = Counted();
		int num = Math.Max(0, list.Count - 10);
		for (int num2 = list.Count - 1; num2 >= num; num2--)
		{
			Pack pack = list[num2];
			b.Append((num2 == list.Count - 1) ? "\n    {" : ",\n    {");
			b.Append("\"n\": ").Append(pack.N).Append(", \"at\": ")
				.Append(q(pack.Start.ToString("HH:mm", Inv)));
			b.Append(", \"fight\": ").Append(pack.FightS.ToString("0.0", Inv)).Append(", \"loot\": ")
				.Append(pack.LootS.ToString("0.0", Inv));
			b.Append(", \"kills\": ").Append(pack.Kills).Append(", \"debuffs\": ")
				.Append(pack.Debuffs)
				.Append(", \"streaks\": ")
				.Append(pack.Streaks);
			b.Append(", \"rings\": ").Append(pack.Rings).Append(", \"arcs\": ")
				.Append(pack.Arcs)
				.Append(", \"melee\": ")
				.Append(pack.Melee);
			b.Append(", \"releases\": ").Append(pack.Releases).Append(", \"drops\": ")
				.Append(pack.Drops);
			b.Append(", \"step\": ").Append(pack.Step).Append(", \"route\": ")
				.Append(q(pack.Route))
				.Append("}");
		}
		b.Append("\n  ]");
		b.Append(",\n  \"timeShare\": [");
		List<KeyValuePair<string, double>> list2 = new List<KeyValuePair<string, double>>(_time);
		list2.Sort((KeyValuePair<string, double> x, KeyValuePair<string, double> y) => y.Value.CompareTo(x.Value));
		for (int num3 = 0; num3 < list2.Count; num3++)
		{
			b.Append((num3 == 0) ? "" : ", ").Append("{\"k\": ").Append(q(list2[num3].Key))
				.Append(", \"s\": ")
				.Append(list2[num3].Value.ToString("0", Inv))
				.Append("}");
		}
		b.Append("]");
		b.Append(",\n  \"segments\": [");
		List<Seg> list3 = SegsSorted();
		for (int num4 = 0; num4 < list3.Count; num4++)
		{
			b.Append((num4 == 0) ? "" : ", ").Append("{\"route\": ").Append(q(list3[num4].Route))
				.Append(", \"from\": ")
				.Append(list3[num4].From)
				.Append(", \"to\": ")
				.Append(list3[num4].From + 20 - 1)
				.Append(", \"kills\": ")
				.Append(list3[num4].Kills)
				.Append(", \"packs\": ")
				.Append(list3[num4].Packs)
				.Append(", \"secs\": ")
				.Append(list3[num4].Secs.ToString("0", Inv))
				.Append("}");
		}
		b.Append("]");
		b.Append(",\n  \"damage\": [");
		List<KeyValuePair<string, double>> list4 = DmgWithDots();
		for (int num5 = 0; num5 < list4.Count && num5 < 10; num5++)
		{
			b.Append((num5 == 0) ? "" : ", ").Append("{\"k\": ").Append(q(list4[num5].Key))
				.Append(", \"n\": ")
				.Append(list4[num5].Value.ToString("0", Inv))
				.Append("}");
		}
		b.Append("]");
		b.Append(",\n  \"dotShare\": [");
		List<KeyValuePair<string, Fam>> list5 = FamSorted();
		for (int num6 = 0; num6 < list5.Count && num6 < 12; num6++)
		{
			Fam value = list5[num6].Value;
			double num7 = value.Hp + value.Over;
			double num8 = DotOf(value);
			b.Append((num6 == 0) ? "" : ", ").Append("{\"k\": ").Append(q(list5[num6].Key))
				.Append(", \"kills\": ")
				.Append(value.Kills)
				.Append(", \"hits\": ")
				.Append((value.Streak / (double)value.Kills).ToString("0", Inv))
				.Append(", \"burst\": ")
				.Append((value.Burst / (double)value.Kills).ToString("0", Inv))
				.Append(", \"dot\": ")
				.Append((num8 / (double)value.Kills).ToString("0", Inv))
				.Append(", \"pct\": ")
				.Append(((num7 > 0.0) ? (100.0 * num8 / num7) : 0.0).ToString("0", Inv))
				.Append("}");
		}
		b.Append("]");
		b.Append(",\n  \"dotPct\": ").Append(DotPct(_fam).ToString("0", Inv));
		b.Append(",\n  \"slowCount\": ").Append(_slowCount);
		b.Append(",\n  \"slow\": [");
		int num9 = _slow.Count - 1;
		int num10 = 0;
		while (num9 >= 0 && num10 < 10)
		{
			b.Append((num10 == 0) ? "" : ", ").Append(q(_slow[num9].At.ToString("HH:mm", Inv) + "  " + _slow[num9].Text));
			num9--;
			num10++;
		}
		b.Append("]");
	}

	private static List<Pack> Counted()
	{
		return _packs.FindAll((Pack p) => !p.Out);
	}

	private static List<Seg> SegsSorted()
	{
		List<Seg> list = new List<Seg>(_segs.Values);
		list.Sort((Seg x, Seg y) =>
		{
			int num = string.Compare(x.Route, y.Route, StringComparison.OrdinalIgnoreCase);
			return (num != 0) ? num : x.From.CompareTo(y.From);
		});
		return list;
	}

	public static void Draw()
	{
		Im.TextColored(Grey, "Since login / Reset session. Each pack and each slow kill also goes to MelkTank_Packs_[character].txt.");
		List<Pack> list = Counted();
		int num = list.Count - list.Count;
		if (OutSet().Count > 0)
		{
			Im.TextColored(Grey, "Left out of these numbers: " + string.Join(", ", new List<string>(OutSet()).ToArray()) + ((num > 0) ? (" (" + num + " pack" + ((num == 1) ? "" : "s") + " not counted)") : "") + " - the Out ticks on the Kills tab.");
		}
		if (ImGui.CollapsingHeader("Packs (newest first)###pkpacks", ImGuiTreeNodeFlags.DefaultOpen))
		{
			if (list.Count == 0)
			{
				Im.TextColored(Grey, "No packs yet.");
			}
			else if (ImGui.BeginTable("pkt", 10, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY, new Vector2(0f, 200f)))
			{
				string[] array = new string[10] { "#", "At", "Step", "Fight", "Loot", "Kills", "Debuffs", "Streaks", "Rings / arcs / swings", "NF / drops" };
				foreach (string text in array)
				{
					ImGui.TableSetupColumn(text);
				}
				ImGui.TableSetupScrollFreeze(0, 1);
				ImGui.TableHeadersRow();
				for (int num2 = list.Count - 1; num2 >= 0; num2--)
				{
					Pack pack = list[num2];
					ImGui.TableNextRow();
					ImGui.TableSetColumnIndex(0);
					ImGui.TextUnformatted(pack.N.ToString());
					ImGui.TableSetColumnIndex(1);
					ImGui.TextUnformatted(pack.Start.ToString("HH:mm", Inv));
					ImGui.TableSetColumnIndex(2);
					ImGui.TextUnformatted((pack.Step > 0) ? pack.Step.ToString() : "-");
					ImGui.TableSetColumnIndex(3);
					ImGui.TextUnformatted(pack.FightS.ToString("0.0") + "s");
					ImGui.TableSetColumnIndex(4);
					ImGui.TextUnformatted(pack.LootS.ToString("0.0") + "s");
					ImGui.TableSetColumnIndex(5);
					ImGui.TextUnformatted(pack.Kills.ToString());
					ImGui.TableSetColumnIndex(6);
					ImGui.TextUnformatted(pack.Debuffs.ToString());
					ImGui.TableSetColumnIndex(7);
					ImGui.TextUnformatted(pack.Streaks.ToString());
					ImGui.TableSetColumnIndex(8);
					ImGui.TextUnformatted(pack.Rings + " / " + pack.Arcs + " / " + pack.Melee);
					ImGui.TableSetColumnIndex(9);
					Im.TextColored((pack.Drops > 0) ? Orange : Vector4.One, pack.Releases + " / " + pack.Drops);
					if (ImGui.IsItemHovered() && pack.Names.Count > 0)
					{
						Im.SetTooltip(string.Join("\n", pack.Names.ToArray()));
					}
				}
				ImGui.EndTable();
			}
			if (list.Count > 0)
			{
				double num3 = 0.0;
				double num4 = 0.0;
				int num5 = 0;
				int num6 = 0;
				int num7 = 0;
				int num8 = 0;
				int num9 = 0;
				int num10 = 0;
				int num11 = 0;
				int num12 = 0;
				foreach (Pack item in list)
				{
					num3 += item.FightS;
					num4 += item.LootS;
					num5 += item.Kills;
					num6 += item.Debuffs;
					num7 += item.Streaks;
					num8 += item.Releases;
					num9 += item.Drops;
					num10 += item.Rings;
					num11 += item.Arcs;
					num12 += item.Melee;
				}
				int count = list.Count;
				Im.TextColored(Cyan, "Average of the last " + count + ": fight " + (num3 / (double)count).ToString("0.0") + "s, loot " + (num4 / (double)count).ToString("0.0") + "s, " + ((double)num5 / (double)count).ToString("0.0") + " kills, " + ((double)num6 / (double)count).ToString("0.0") + " debuffs, " + ((double)num7 / (double)count).ToString("0.0") + " streaks, " + ((num10 > 0) ? (((double)num10 / (double)count).ToString("0.0") + " rings, ") : "") + ((num11 > 0) ? (((double)num11 / (double)count).ToString("0.0") + " arcs, ") : "") + ((num12 > 0) ? (((double)num12 / (double)count).ToString("0.0") + " swings, ") : "") + ((double)num8 / (double)count).ToString("0.0") + " releases, " + num9 + " drops");
			}
		}
		if (ImGui.CollapsingHeader("Where the time goes###pktime", ImGuiTreeNodeFlags.DefaultOpen))
		{
			double num13 = 0.0;
			foreach (double value3 in _time.Values)
			{
				num13 += value3;
			}
			List<KeyValuePair<string, double>> list2 = new List<KeyValuePair<string, double>>(_time);
			list2.Sort((KeyValuePair<string, double> x, KeyValuePair<string, double> y) => y.Value.CompareTo(x.Value));
			foreach (KeyValuePair<string, double> item2 in list2)
			{
				if (!(item2.Value < 1.0))
				{
					ImGui.ProgressBar((num13 > 0.0) ? ((float)(item2.Value / num13)) : 0f, new Vector2(160f, 0f), ((num13 > 0.0) ? (100.0 * item2.Value / num13).ToString("0") : "0") + "%");
					ImGui.SameLine();
					ImGui.TextUnformatted(item2.Key + "  (" + Mins(item2.Value) + ")");
				}
			}
		}
		if (ImGui.CollapsingHeader("Kills by stretch of route###pkseg"))
		{
			List<Seg> list3 = SegsSorted();
			if (list3.Count == 0)
			{
				Im.TextColored(Grey, "Not following a route yet.");
			}
			else if (ImGui.BeginTable("pks", 5, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
			{
				string[] array2 = new string[5] { "Route", "Steps", "Kills", "Time there", "Kills / min" };
				foreach (string text2 in array2)
				{
					ImGui.TableSetupColumn(text2);
				}
				ImGui.TableHeadersRow();
				foreach (Seg item3 in list3)
				{
					ImGui.TableNextRow();
					ImGui.TableSetColumnIndex(0);
					ImGui.TextUnformatted(item3.Route);
					ImGui.TableSetColumnIndex(1);
					ImGui.TextUnformatted(item3.From + "-" + (item3.From + 20 - 1));
					ImGui.TableSetColumnIndex(2);
					ImGui.TextUnformatted(item3.Kills.ToString());
					ImGui.TableSetColumnIndex(3);
					ImGui.TextUnformatted(Mins(item3.Secs));
					ImGui.TableSetColumnIndex(4);
					double num15 = ((item3.Secs > 30.0) ? ((double)item3.Kills / (item3.Secs / 60.0)) : 0.0);
					Im.TextColored((item3.Secs > 60.0 && num15 < 1.0) ? Orange : Vector4.One, (item3.Secs > 30.0) ? num15.ToString("0.0") : "-");
				}
				ImGui.EndTable();
			}
		}
		if (ImGui.CollapsingHeader("Damage by source###pkdmg"))
		{
			List<KeyValuePair<string, double>> list4 = DmgWithDots();
			double num16 = 0.0;
			foreach (KeyValuePair<string, double> item4 in list4)
			{
				num16 += item4.Value;
			}
			if (list4.Count == 0)
			{
				Im.TextColored(Grey, "Nothing yet.");
			}
			foreach (KeyValuePair<string, double> item5 in list4)
			{
				ImGui.ProgressBar((num16 > 0.0) ? ((float)(item5.Value / num16)) : 0f, new Vector2(160f, 0f), ((num16 > 0.0) ? (100.0 * item5.Value / num16).ToString("0") : "0") + "%");
				ImGui.SameLine();
				ImGui.TextUnformatted(item5.Key + "  " + Big(item5.Value));
			}
			Im.TextColored(Grey, (_dotSeen ? "From your hit lines and the DoT lines (\"... deals N points of periodic damage\"). " : "From your hit lines. No DoT lines yet: \"DoTs (estimated)\" is the DoT share's estimate. ") + "A killing hit's own\nline is replaced by the kill message, so it's counted as that attack's usual size (" + _hitKills + " kills by hits, " + _dotKills + " by DoTs). Aetheria surges aren't in here.");
		}
		if (ImGui.CollapsingHeader("DoTs###pkdots"))
		{
			if (_dots.Count == 0)
			{
				Im.TextColored(Grey, "No DoT lines yet (\"Your Incantation of ... deals N points of periodic ... damage to X (5 ticks)\").");
			}
			else if (ImGui.BeginTable("dotspells", 6, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
			{
				string[] array3 = new string[6] { "DoT", "Total", "Share", "Ticks", "Per tick", "Crit ticks" };
				foreach (string text3 in array3)
				{
					ImGui.TableSetupColumn(text3);
				}
				ImGui.TableHeadersRow();
				List<KeyValuePair<string, DotStat>> list5 = new List<KeyValuePair<string, DotStat>>(_dots);
				list5.Sort((KeyValuePair<string, DotStat> x, KeyValuePair<string, DotStat> y) => y.Value.Sum.CompareTo(x.Value.Sum));
				double num18 = 0.0;
				foreach (KeyValuePair<string, DotStat> item6 in list5)
				{
					num18 += item6.Value.Sum;
				}
				foreach (KeyValuePair<string, DotStat> item7 in list5)
				{
					DotStat value = item7.Value;
					ImGui.TableNextRow();
					ImGui.TableSetColumnIndex(0);
					ImGui.TextUnformatted(item7.Key);
					ImGui.TableSetColumnIndex(1);
					ImGui.TextUnformatted(Big(value.Sum));
					ImGui.TableSetColumnIndex(2);
					ImGui.TextUnformatted((num18 > 0.0) ? ((100.0 * value.Sum / num18).ToString("0", Inv) + "%") : "-");
					ImGui.TableSetColumnIndex(3);
					ImGui.TextUnformatted(value.Ticks.ToString("N0", Inv));
					ImGui.TableSetColumnIndex(4);
					ImGui.TextUnformatted(Big((value.Ticks > 0) ? (value.Sum / (double)value.Ticks) : 0.0));
					ImGui.TableSetColumnIndex(5);
					ImGui.TextUnformatted((value.Ticks > 0) ? ((100.0 * (double)value.Crits / (double)value.Ticks).ToString("0", Inv) + "%") : "-");
				}
				ImGui.EndTable();
			}
			Im.TextColored(Grey, "The game reports each DoT's damage every few seconds (its own setting) - each line is the damage since the last one,\nso they add up. Share = of all DoT damage.");
		}
		if (ImGui.CollapsingHeader("DoT share###pkdot"))
		{
			List<KeyValuePair<string, Fam>> list6 = FamSorted();
			double num19 = DotPct(_fam);
			Im.TextColored(Grey, _dotSeen ? "DoT damage from the DoT lines, against what the kills took (max health x kills + overkill). Includes spread DoTs." : "No DoT lines yet, so DoT damage = (max health x kills + overkill) - your hits (streaks, rings, arcs, weapon) and Nether Fracture bursts.\nIncludes spread DoTs. Monsters still alive when it's counted make a pack's number rough; the session total evens out.");
			if (list6.Count == 0)
			{
				Im.TextColored(Grey, "No kills with a known max health yet.");
			}
			else
			{
				ImGui.TextUnformatted("All: DoTs did " + ((num19 >= 0.0) ? (num19.ToString("0") + "%") : "-") + " of the damage.");
				if (ImGui.BeginTable("dotshare", 6, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
				{
					string[] array4 = new string[6] { "Monsters", "Kills", "Hits / kill", "Fracture / kill", "DoT / kill", "DoT %" };
					foreach (string text4 in array4)
					{
						ImGui.TableSetupColumn(text4);
					}
					ImGui.TableHeadersRow();
					foreach (KeyValuePair<string, Fam> item8 in list6)
					{
						Fam value2 = item8.Value;
						double num21 = value2.Hp + value2.Over;
						double num22 = DotOf(value2);
						ImGui.TableNextRow();
						ImGui.TableSetColumnIndex(0);
						ImGui.TextUnformatted(item8.Key);
						ImGui.TableSetColumnIndex(1);
						ImGui.TextUnformatted(value2.Kills.ToString());
						ImGui.TableSetColumnIndex(2);
						ImGui.TextUnformatted(Big(value2.Streak / (double)value2.Kills));
						ImGui.TableSetColumnIndex(3);
						ImGui.TextUnformatted(Big(value2.Burst / (double)value2.Kills));
						ImGui.TableSetColumnIndex(4);
						ImGui.TextUnformatted(Big(num22 / (double)value2.Kills));
						ImGui.TableSetColumnIndex(5);
						Im.TextColored((num22 < 0.0) ? Orange : Cyan, (num21 > 0.0) ? ((100.0 * num22 / num21).ToString("0") + "%") : "-");
					}
					ImGui.EndTable();
				}
			}
		}
		if (ImGui.CollapsingHeader("Slow kills (" + _slowCount + ")###pkslow"))
		{
			if (_slow.Count == 0)
			{
				Im.TextColored(Green, "None.");
			}
			for (int num23 = _slow.Count - 1; num23 >= 0; num23--)
			{
				ImGui.TextUnformatted(_slow[num23].At.ToString("HH:mm:ss", Inv) + "  " + _slow[num23].Text);
			}
		}
	}

	private static string Mins(double s)
	{
		return (s >= 60.0) ? ((int)(s / 60.0) + "m " + ((int)s % 60).ToString("00") + "s") : ((int)s + "s");
	}

	private static string Big(double n)
	{
		string result;
		if (n >= 1000000000000000.0)
		{
			result = (n / 1000000000000000.0).ToString("0.0") + "Q";
		}
		else if (n >= 1000000000000.0)
		{
			result = (n / 1000000000000.0).ToString("0.0") + "T";
		}
		else if (n >= 1000000000.0)
		{
			result = (n / 1000000000.0).ToString("0.0") + "B";
		}
		else if (n >= 1000000.0)
		{
			result = (n / 1000000.0).ToString("0.0") + "M";
		}
		else
		{
			result = ((n >= 1000.0) ? ((n / 1000.0).ToString("0") + "k") : n.ToString("0"));
		}
		return result;
	}
}
