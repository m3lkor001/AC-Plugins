namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 620;

	public const string Time = "Nov 24 20:08";

	public static string Label => "b" + Number + " (" + Time + ")";
}
