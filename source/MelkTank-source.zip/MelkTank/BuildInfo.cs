namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 607;

	public const string Time = "Nov 23 17:55";

	public static string Label => "b" + Number + " (" + Time + ")";
}
