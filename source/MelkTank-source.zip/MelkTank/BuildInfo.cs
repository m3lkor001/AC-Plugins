namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 621;

	public const string Time = "Nov 25 04:10";

	public static string Label => "b" + Number + " (" + Time + ")";
}
