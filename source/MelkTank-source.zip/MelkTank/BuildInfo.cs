namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 616;

	public const string Time = "Nov 24 19:28";

	public static string Label => "b" + Number + " (" + Time + ")";
}
