namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 619;

	public const string Time = "Nov 24 19:59";

	public static string Label => "b" + Number + " (" + Time + ")";
}
