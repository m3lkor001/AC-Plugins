namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 610;

	public const string Time = "Nov 24 05:15";

	public static string Label => "b" + Number + " (" + Time + ")";
}
