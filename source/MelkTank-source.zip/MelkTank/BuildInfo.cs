namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 614;

	public const string Time = "Nov 24 12:28";

	public static string Label => "b" + Number + " (" + Time + ")";
}
