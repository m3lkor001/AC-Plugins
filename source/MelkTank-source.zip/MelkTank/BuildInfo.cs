namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 613;

	public const string Time = "Nov 24 09:25";

	public static string Label => "b" + Number + " (" + Time + ")";
}
