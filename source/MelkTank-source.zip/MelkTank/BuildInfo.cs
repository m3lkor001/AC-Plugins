namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 606;

	public const string Time = "Nov 23 15:40";

	public static string Label => "b" + Number + " (" + Time + ")";
}
