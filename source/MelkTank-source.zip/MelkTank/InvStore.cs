using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using MelkTank.Loot;

namespace MelkTank;

/// <summary>
/// Every character's packs, kept on this computer for looking through offline (Items > Inventory). Each character writes
/// only its own file (Inventory/&lt;server&gt;/&lt;character&gt;.txt) - on logout, and every so many minutes - so clients on other
/// accounts never write the same file; everyone reads all of them.
/// </summary>
public static class InvStore
{
	public class Item
	{
		public int Id;

		public int Icon;

		public string Name = "";

		public string Pack = "";

		public int Count = 1;

		public int Class;

		public string Stats = "";

		public string Char = "";

		public string Server = "";
	}

	public class CharInv
	{
		public string Server = "";

		public string Name = "";

		public DateTime SavedAt;

		/// <summary>A house's storage (its chests, all of them together), not the character's own packs.</summary>
		public bool Chest;

		public List<Item> Items = new List<Item>();
	}

	private static DateTime _nextSave = DateTime.MinValue;

	private static readonly Dictionary<int, string> _stats = new Dictionary<int, string>();

	private static string _statsFor = "";

	public static DateTime LastSaved = DateTime.MinValue;

	public static string LastSaveNote = "";

	private static Settings S => PluginCore.CurrentSettings;

	public static string Folder
	{
		get
		{
			string text = S?.InvFolder ?? "";
			return (text.Trim().Length > 0) ? text.Trim() : Util.FullPath("Inventory");
		}
	}

	private static string Safe(string s)
	{
		char[] invalidFileNameChars = Path.GetInvalidFileNameChars();
		foreach (char oldChar in invalidFileNameChars)
		{
			s = s.Replace(oldChar, '_');
		}
		return s;
	}

	private static string Clean(string s)
	{
		return (s ?? "").Replace('\t', ' ').Replace('\r', ' ').Replace('\n', ' ');
	}

	/// <summary>Saves on the schedule (every so many minutes; 0: only on logout).</summary>
	public static void Tick()
	{
		Settings s = S;
		if (s == null || !s.InvOn)
		{
			return;
		}
		try
		{
			WatchChest();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		int num = Math.Max(0, s.InvUpdateMin);
		if (num == 0)
		{
			return;
		}
		DateTime now = DateTime.Now;
		if (_nextSave == DateTime.MinValue)
		{
			// (the first save a couple of minutes after logging in: the packs have been told by then)
			_nextSave = now.AddMinutes(Math.Min(2, num));
		}
		else if (now >= _nextSave)
		{
			_nextSave = now.AddMinutes(num);
			Save("scheduled");
		}
	}

	public static void Reschedule()
	{
		_nextSave = DateTime.MinValue;
	}

	private static bool WantsStats(WorldObject o)
	{
		switch (o.ObjectClass)
		{
		case ObjectClass.MeleeWeapon:
		case ObjectClass.MissileWeapon:
		case ObjectClass.WandStaffOrb:
		case ObjectClass.Armor:
		case ObjectClass.Clothing:
		case ObjectClass.Jewelry:
			return true;
		default:
		{
			string text = o.Name ?? "";
			return text.IndexOf("Essence", StringComparison.OrdinalIgnoreCase) >= 0 || text.EndsWith(" Aetheria", StringComparison.OrdinalIgnoreCase);
		}
		}
	}

	private static bool WantsMaterial(WorldObject o)
	{
		ObjectClass objectClass = o.ObjectClass;
		return objectClass == ObjectClass.Salvage || objectClass == ObjectClass.MeleeWeapon || objectClass == ObjectClass.MissileWeapon || objectClass == ObjectClass.WandStaffOrb || objectClass == ObjectClass.Armor || objectClass == ObjectClass.Clothing || objectClass == ObjectClass.Jewelry;
	}

	// ── a house's storage chest: when one is open, what's in it is saved under its owner ("Owned by Melkoran" in its
	// ID) - a file per chest, so the owner's list shows it as one of their packs ──
	private static int _chest;

	private static DateTime _chestAt;

	private static int _chestCount = -1;

	private static DateTime _chestStableAt;

	private static bool _chestSaved;

	private static bool _chestAsked;

	private static void WatchChest()
	{
		CoreManager current = CoreManager.Current;
		int openedContainer = current.Actions.OpenedContainer;
		if (openedContainer != _chest)
		{
			_chest = openedContainer;
			_chestAt = DateTime.Now;
			_chestCount = -1;
			_chestSaved = false;
			_chestAsked = false;
		}
		if (_chest == 0 || _chestSaved)
		{
			return;
		}
		WorldObject worldObject = current.WorldFilter[_chest];
		if (worldObject == null || worldObject.ObjectClass == ObjectClass.Corpse)
		{
			return;
		}
		string text = Owner(worldObject);
		if (text == null)
		{
			if (!_chestAsked && !worldObject.HasIdData)
			{
				_chestAsked = true;
				Util.RequestId(_chest);
			}
			if ((DateTime.Now - _chestAt).TotalSeconds > 10.0)
			{
				_chestSaved = true;
			}
			return;
		}
		// (its contents in once they stop arriving: the count the same for a second and a half)
		int num = ChestContents(_chest, "").Count;
		if (num != _chestCount)
		{
			_chestCount = num;
			_chestStableAt = DateTime.Now;
			return;
		}
		if ((DateTime.Now - _chestStableAt).TotalSeconds < 1.5)
		{
			return;
		}
		_chestSaved = true;
		SaveChest(worldObject, text);
	}

	/// <summary>A house storage chest's owner, from its ID ("Owned by Melkoran"); null: not one, or not known yet.</summary>
	private static string Owner(WorldObject chest)
	{
		string text = "";
		try
		{
			text = chest.Values(StringValueKey.FullDescription, "") ?? "";
		}
		catch
		{
		}
		int num = text.IndexOf("Owned by ", StringComparison.OrdinalIgnoreCase);
		if (num < 0)
		{
			return null;
		}
		string text2 = text.Substring(num + 9);
		int num2 = text2.IndexOfAny(new char[2] { '\n', '\r' });
		text2 = ((num2 >= 0) ? text2.Substring(0, num2) : text2).Trim().TrimEnd('.');
		return (text2.Length > 0) ? text2 : null;
	}

	private static void SaveChest(WorldObject chest, string owner)
	{
		CoreManager current = CoreManager.Current;
		string text = current.CharacterFilter.Server ?? "";
		string text2 = chest.Name ?? "Chest";
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("#MelkTankInventory\t1\t").Append(Clean(text)).Append('\t')
			.Append(Clean(owner))
			.Append('\t')
			.Append(DateTime.Now.ToString("o", CultureInfo.InvariantCulture))
			.Append("\tchest\n");
		int num = 0;
		foreach (KeyValuePair<WorldObject, string> item in ChestContents(chest.Id, text2))
		{
			stringBuilder.Append(Line(item.Key, item.Value, WantsStats(item.Key) && item.Key.HasIdData ? SafeDescribe(item.Key) : ""));
			num++;
		}
		string text3 = Path.Combine(Path.Combine(Folder, Safe(text)), "chests");
		Directory.CreateDirectory(text3);
		Util.WriteShared(Path.Combine(text3, chest.Id.ToString("X8") + ".txt"), stringBuilder.ToString());
		LastSaved = DateTime.Now;
		LastSaveNote = num + " items in " + owner + "'s " + text2;
		Util.WriteToChat("Inventory: saved " + num + " items in " + owner + "'s house " + text2 + ".");
	}

	/// <summary>Everything in a chest and in the bags in it (the server sends the bags' contents with the chest's), each
	/// with where it is: the chest itself, or "chest - bag".</summary>
	private static List<KeyValuePair<WorldObject, string>> ChestContents(int chest, string label)
	{
		List<KeyValuePair<WorldObject, string>> list = new List<KeyValuePair<WorldObject, string>>();
		Dictionary<string, int> dictionary = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
		foreach (WorldObject item in CoreManager.Current.WorldFilter.GetByContainer(chest))
		{
			if (item.ObjectClass == ObjectClass.Container || item.ObjectClass == ObjectClass.Foci)
			{
				// (bags of the same name told apart by number: "Pack 2")
				string text = item.Name ?? "Bag";
				dictionary.TryGetValue(text, out var value);
				dictionary[text] = value + 1;
				string value2 = label + " - " + text + ((value > 0) ? (" " + (value + 1)) : "");
				foreach (WorldObject item2 in CoreManager.Current.WorldFilter.GetByContainer(item.Id))
				{
					list.Add(new KeyValuePair<WorldObject, string>(item2, value2));
				}
			}
			else
			{
				list.Add(new KeyValuePair<WorldObject, string>(item, label));
			}
		}
		return list;
	}

	private static string SafeDescribe(WorldObject o)
	{
		try
		{
			return ItemReport.Describe(o, null);
		}
		catch
		{
			return "";
		}
	}

	private static string ShownName(WorldObject o)
	{
		if (o.ObjectClass == ObjectClass.Salvage)
		{
			return ItemNames.Of(o);
		}
		return WantsMaterial(o) ? ItemReport.FullName(o) : (o.Name ?? "");
	}

	private static string Line(WorldObject o, string pack, string stats)
	{
		return o.Id + "\t" + o.Icon + "\t" + Clean(ShownName(o)) + "\t" + Clean(pack) + "\t" + Math.Max(1, o.Values(LongValueKey.StackCount, 1)) + "\t" + (int)o.ObjectClass + "\t" + Clean(stats ?? "") + "\n";
	}

	/// <summary>This character's packs, written to its own file.</summary>
	public static void Save(string why)
	{
		if (S != null && !S.InvOn && why != "by hand")
		{
			return;
		}
		try
		{
			CoreManager current = CoreManager.Current;
			string text = current.CharacterFilter.Name ?? "";
			string text2 = current.CharacterFilter.Server ?? "";
			if (text.Length == 0)
			{
				return;
			}
			int id = current.CharacterFilter.Id;
			string text3 = Path.Combine(Path.Combine(Folder, Safe(text2)), Safe(text) + ".txt");
			// (stats seen before stay with an item that isn't identified now - identifying everything each time would flood the server)
			string text4 = text2 + "/" + text;
			if (_statsFor != text4)
			{
				_stats.Clear();
				_statsFor = text4;
				CharInv charInv = Read(text3);
				if (charInv != null)
				{
					foreach (Item item in charInv.Items)
					{
						if (item.Stats.Length > 0)
						{
							_stats[item.Id] = item.Stats;
						}
					}
				}
			}
			Dictionary<int, string> dictionary = new Dictionary<int, string>();
			int num = 0;
			foreach (WorldObject item2 in InvCache.All())
			{
				if (item2.ObjectClass == ObjectClass.Container || item2.ObjectClass == ObjectClass.Foci)
				{
					dictionary[item2.Id] = item2.Name ?? "Pack";
				}
			}
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append("#MelkTankInventory\t1\t").Append(Clean(text2)).Append('\t')
				.Append(Clean(text))
				.Append('\t')
				.Append(DateTime.Now.ToString("o", CultureInfo.InvariantCulture))
				.Append('\n');
			int num2 = 0;
			int num3 = 0;
			foreach (WorldObject item3 in InvCache.All())
			{
				if (item3 == null)
				{
					continue;
				}
				string value;
				if (item3.Values(LongValueKey.EquippedSlots, 0) != 0 || item3.Values(LongValueKey.Wielder, 0) == id)
				{
					value = "Equipped";
				}
				else
				{
					int num4 = item3.Values(LongValueKey.Container, 0);
					value = ((num4 == id || num4 == 0) ? "Main pack" : (dictionary.TryGetValue(num4, out var value2) ? value2 : "Pack"));
				}
				string text5 = (WantsMaterial(item3) ? ItemReport.FullName(item3) : (item3.Name ?? ""));
				if (item3.ObjectClass == ObjectClass.Salvage)
				{
					text5 = ItemNames.Of(item3);
				}
				string value3 = "";
				if (WantsStats(item3))
				{
					if (item3.HasIdData)
					{
						try
						{
							value3 = ItemReport.Describe(item3, null);
							_stats[item3.Id] = value3;
						}
						catch
						{
						}
					}
					else
					{
						_stats.TryGetValue(item3.Id, out value3);
						if (num < 20 && why != "logout")
						{
							num++;
							Util.RequestId(item3.Id);
						}
						if (string.IsNullOrEmpty(value3))
						{
							num3++;
						}
					}
				}
				stringBuilder.Append(item3.Id).Append('\t').Append(item3.Icon)
					.Append('\t')
					.Append(Clean(text5))
					.Append('\t')
					.Append(Clean(value))
					.Append('\t')
					.Append(Math.Max(1, item3.Values(LongValueKey.StackCount, 1)))
					.Append('\t')
					.Append((int)item3.ObjectClass)
					.Append('\t')
					.Append(Clean(value3 ?? ""))
					.Append('\n');
				num2++;
			}
			Directory.CreateDirectory(Path.GetDirectoryName(text3));
			Util.WriteShared(text3, stringBuilder.ToString());
			LastSaved = DateTime.Now;
			LastSaveNote = num2 + " items (" + why + ")" + ((num3 > 0) ? (", " + num3 + " not identified yet - their stats come with a later save") : "");
		}
		catch (Exception ex)
		{
			LastSaveNote = "couldn't save: " + ex.Message;
			Util.LogError(ex);
		}
	}

	public static CharInv Read(string path)
	{
		try
		{
			if (!File.Exists(path))
			{
				return null;
			}
			string[] array = File.ReadAllLines(path);
			if (array.Length == 0 || !array[0].StartsWith("#MelkTankInventory"))
			{
				return null;
			}
			string[] array2 = array[0].Split('\t');
			CharInv charInv = new CharInv
			{
				Server = ((array2.Length > 2) ? array2[2] : ""),
				Name = ((array2.Length > 3) ? array2[3] : Path.GetFileNameWithoutExtension(path))
			};
			if (array2.Length > 4)
			{
				DateTime.TryParse(array2[4], CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out charInv.SavedAt);
			}
			charInv.Chest = array2.Length > 5 && array2[5] == "chest";
			for (int i = 1; i < array.Length; i++)
			{
				string[] array3 = array[i].Split('\t');
				if (array3.Length >= 6)
				{
					Item item = new Item
					{
						Name = array3[2],
						Pack = array3[3],
						Stats = ((array3.Length > 6) ? array3[6] : ""),
						Char = (charInv.Chest ? (charInv.Name + "'s house") : charInv.Name),
						Server = charInv.Server
					};
					int.TryParse(array3[0], out item.Id);
					int.TryParse(array3[1], out item.Icon);
					int.TryParse(array3[4], out item.Count);
					int.TryParse(array3[5], out item.Class);
					charInv.Items.Add(item);
				}
			}
			return charInv;
		}
		catch
		{
			return null;
		}
	}

	/// <summary>Every character's saved packs, all servers.</summary>
	public static List<CharInv> ReadAll()
	{
		List<CharInv> list = new List<CharInv>();
		try
		{
			if (!Directory.Exists(Folder))
			{
				return list;
			}
			string[] files = Directory.GetFiles(Folder, "*.txt", SearchOption.AllDirectories);
			foreach (string path in files)
			{
				CharInv charInv = Read(path);
				if (charInv != null)
				{
					list.Add(charInv);
				}
			}
		}
		catch
		{
		}
		// (one entry per character, and one for each character's house storage - all its chests together)
		List<CharInv> list2 = new List<CharInv>();
		foreach (CharInv item in list)
		{
			CharInv charInv2 = list2.Find((CharInv c) => c.Chest == item.Chest && string.Equals(c.Name, item.Name, StringComparison.OrdinalIgnoreCase) && string.Equals(c.Server, item.Server, StringComparison.OrdinalIgnoreCase));
			if (charInv2 == null)
			{
				list2.Add(item);
				continue;
			}
			charInv2.Items.AddRange(item.Items);
			if (item.SavedAt > charInv2.SavedAt)
			{
				charInv2.SavedAt = item.SavedAt;
			}
		}
		list = list2;
		list.Sort((CharInv a, CharInv b) => (string.Compare(a.Server, b.Server, StringComparison.OrdinalIgnoreCase) != 0) ? string.Compare(a.Server, b.Server, StringComparison.OrdinalIgnoreCase) : ((string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase) != 0) ? string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase) : a.Chest.CompareTo(b.Chest)));
		return list;
	}
}
