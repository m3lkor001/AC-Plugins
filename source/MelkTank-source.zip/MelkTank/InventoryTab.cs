using System;
using System.Collections.Generic;
using System.Numerics;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using UtilityBelt.Service.Views;

namespace MelkTank;

/// <summary>Items > Inventory: every character's packs as last saved (any account on this computer) - one character's
/// list, or a search across all of them for who has something and where.</summary>
public static class InventoryTab
{
	private static readonly Vector4 Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f);

	private static readonly Vector4 Gold = new Vector4(1f, 0.85f, 0.4f, 1f);

	private static readonly Vector4 Cyan = new Vector4(0.4f, 0.85f, 1f, 1f);

	private static List<InvStore.CharInv> _all;

	private static DateTime _readAt = DateTime.MinValue;

	private static int _pick = -1;

	private static string _search = "";

	private static readonly Dictionary<int, ManagedTexture> _tex = new Dictionary<int, ManagedTexture>();

	private const int MaxRows = 3000;

	private static void Tip(string s)
	{
		Im.SetTooltipIfHovered(s);
	}

	public static bool Draw(Settings s)
	{
		bool flag = false;
		flag |= ImGui.Checkbox("Save each character's packs##invon", ref s.InvOn);
		Tip("Writes this character's packs to a file of its own on this computer - on logout and every so many minutes -\nso they can be looked through here from any character, any account. Off: nothing is saved (what's saved stays).\n/mt set InvOn on|off");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		int invUpdateMin = s.InvUpdateMin;
		if (ImGui.InputInt("min between saves##invmin", ref invUpdateMin, 5, 30))
		{
			s.InvUpdateMin = Math.Max(0, Math.Min(1440, invUpdateMin));
			InvStore.Reschedule();
			flag = true;
		}
		Tip("How often this character's packs are saved while playing (0: only on logout).\n/mt set InvUpdateMin <number>");
		ImGui.SameLine();
		if (ImGui.Button("Save now##invsave"))
		{
			InvStore.Save("by hand");
			_all = null;
		}
		Tip("Saves this character's packs now.");
		ImGui.SameLine();
		if (ImGui.Button("Reload##invre"))
		{
			_all = null;
		}
		Tip("Reads every character's saved file again (another client may have saved since).");
		Im.TextColored(Grey, (InvStore.LastSaved == DateTime.MinValue) ? "Not saved yet this session" : ("Saved " + InvStore.LastSaved.ToString("HH:mm") + " - " + InvStore.LastSaveNote));
		if (ImGui.CollapsingHeader("Folder##invfold"))
		{
			ImGui.SetNextItemWidth(420f);
			if (ImGui.InputTextWithHint("##invfolder", InvStore.Folder, ref s.InvFolder, 400u))
			{
				_all = null;
				flag = true;
			}
			Tip("Where the files go (empty: Inventory in MelkTank's folder). Point the retail and ACGodot MelkTanks at the same\nfolder to see both sets of characters in either.");
			Im.TextColored(Grey, "Now: " + InvStore.Folder);
		}
		if (_all == null || (DateTime.Now - _readAt).TotalSeconds > 60.0)
		{
			_all = InvStore.ReadAll();
			_readAt = DateTime.Now;
		}
		if (_all.Count == 0)
		{
			Im.TextColored(Grey, "Nothing saved yet - click Save now, or log each character in once.");
			return flag;
		}
		string text = (_pick >= 0 && _pick < _all.Count) ? Label(_all[_pick]) : "All characters";
		ImGui.SetNextItemWidth(260f);
		if (ImGui.BeginCombo("##invchar", text, ImGuiComboFlags.HeightLarge))
		{
			if (ImGui.Selectable("All characters", _pick < 0))
			{
				_pick = -1;
			}
			for (int i = 0; i < _all.Count; i++)
			{
				if (ImGui.Selectable(Label(_all[i]) + "##ic" + i, i == _pick))
				{
					_pick = i;
				}
			}
			ImGui.EndCombo();
		}
		Tip("Whose packs to show (All characters: everyone's - with a search, who has it and where).");
		ImGui.SameLine();
		if (ImGui.SmallButton("<##invprev") && _all.Count > 0)
		{
			_pick = (_pick <= 0) ? (_all.Count - 1) : (_pick - 1);
		}
		ImGui.SameLine();
		if (ImGui.SmallButton(">##invnext") && _all.Count > 0)
		{
			_pick = (_pick >= _all.Count - 1) ? 0 : (_pick + 1);
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(260f);
		ImGui.InputTextWithHint("##invsearch", "search items...", ref _search, 100u);
		Tip("Finds items whose name has this in it - across everyone with All characters picked.");
		ImGui.SameLine();
		if (ImGui.SmallButton("Clear##invclear"))
		{
			_search = "";
		}
		Tip("Empties the search box.");
		if (_pick >= 0 && _pick < _all.Count)
		{
			ImGui.SameLine();
			Im.TextColored(Grey, "saved " + _all[_pick].SavedAt.ToLocalTime().ToString("MMM d HH:mm"));
		}
		List<InvStore.Item> list = new List<InvStore.Item>();
		string text2 = _search.Trim();
		for (int j = 0; j < _all.Count; j++)
		{
			if (_pick >= 0 && j != _pick)
			{
				continue;
			}
			foreach (InvStore.Item item in _all[j].Items)
			{
				if (text2.Length == 0 || item.Name.IndexOf(text2, StringComparison.OrdinalIgnoreCase) >= 0)
				{
					list.Add(item);
				}
			}
		}
		if (_pick < 0 && text2.Length == 0)
		{
			Im.TextColored(Grey, "Pick a character, or search to find who has something.");
			return flag;
		}
		list.Sort(delegate(InvStore.Item a, InvStore.Item b)
		{
			int num4 = string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase);
			if (num4 != 0 && text2.Length > 0)
			{
				return num4;
			}
			int num5 = string.Compare(a.Char, b.Char, StringComparison.OrdinalIgnoreCase);
			if (num5 != 0)
			{
				return num5;
			}
			int num6 = PackOrder(a.Pack) - PackOrder(b.Pack);
			if (num6 != 0)
			{
				return num6;
			}
			int num7 = string.Compare(a.Pack, b.Pack, StringComparison.OrdinalIgnoreCase);
			return (num7 != 0) ? num7 : num4;
		});
		int num = 0;
		foreach (InvStore.Item item2 in list)
		{
			num += item2.Count;
		}
		Im.TextColored(Cyan, list.Count + " stack" + ((list.Count == 1) ? "" : "s") + ((num != list.Count) ? (" (" + num.ToString("N0") + " items)") : "") + ((list.Count > MaxRows) ? (" - showing the first " + MaxRows) : ""));
		float frameHeight = ImGui.GetFrameHeight();
		if (ImGui.BeginTable("##invtable", 4, ImGuiTableFlags.RowBg | ImGuiTableFlags.Borders | ImGuiTableFlags.ScrollY | ImGuiTableFlags.Resizable | ImGuiTableFlags.SizingStretchProp))
		{
			ImGui.TableSetupScrollFreeze(0, 1);
			ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, frameHeight + 4f);
			ImGui.TableSetupColumn("Item", ImGuiTableColumnFlags.WidthStretch, 3f);
			ImGui.TableSetupColumn("Character", ImGuiTableColumnFlags.WidthStretch, 1.3f);
			ImGui.TableSetupColumn("Pack", ImGuiTableColumnFlags.WidthStretch, 1.3f);
			ImGui.TableHeadersRow();
			int num2 = 0;
			foreach (InvStore.Item item3 in list)
			{
				if (++num2 > MaxRows)
				{
					break;
				}
				ImGui.TableNextRow();
				ImGui.TableNextColumn();
				DrawIcon(item3.Icon, frameHeight);
				ImGui.TableNextColumn();
				string text3 = item3.Name + ((item3.Count > 1) ? (" x" + item3.Count.ToString("N0")) : "");
				ImGui.TextUnformatted(text3);
				if (item3.Stats.Length > 0 && ImGui.IsItemHovered())
				{
					ImGui.BeginTooltip();
					ImGui.PushTextWrapPos(430f);
					string[] array = item3.Stats.Split(new string[1] { ", " }, StringSplitOptions.None);
					Im.TextColored(Gold, (array.Length != 0) ? array[0] : item3.Name);
					for (int k = 1; k < array.Length; k++)
					{
						ImGui.TextUnformatted(array[k]);
					}
					Im.TextColored(Grey, item3.Char + " - " + item3.Pack);
					ImGui.PopTextWrapPos();
					ImGui.EndTooltip();
				}
				ImGui.TableNextColumn();
				ImGui.TextUnformatted(item3.Char);
				ImGui.TableNextColumn();
				ImGui.TextUnformatted(item3.Pack);
			}
			ImGui.EndTable();
		}
		return flag;
	}

	private static string Label(InvStore.CharInv c)
	{
		return c.Name + (c.Chest ? "'s house storage" : "") + ((c.Server.Length > 0) ? ("  (" + c.Server + ")") : "") + "  - " + c.Items.Count;
	}

	private static int PackOrder(string p)
	{
		if (p == "Equipped")
		{
			return 0;
		}
		return (p == "Main pack") ? 1 : 2;
	}

	private static void DrawIcon(int icon, float size)
	{
		ManagedTexture value = null;
		if (icon != 0)
		{
			if ((icon & 0xFF000000u) == 0)
			{
				icon |= 0x6000000;
			}
			if (!_tex.TryGetValue(icon, out value))
			{
				try
				{
					value = (ManagedTexture)Activator.CreateInstance(typeof(ManagedTexture), (uint)icon);
				}
				catch
				{
					value = null;
				}
				_tex[icon] = value;
			}
		}
		if (value != null)
		{
			try
			{
				ImGui.Image(value.TexturePtr, new Vector2(size, size));
				return;
			}
			catch
			{
			}
		}
		ImGui.Dummy(new Vector2(size, size));
	}
}
