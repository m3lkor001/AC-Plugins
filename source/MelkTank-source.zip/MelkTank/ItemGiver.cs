using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
#if !RETAIL
using AcClient;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using MelkTank.Loot;

namespace MelkTank;

/// <summary>
/// The loot-profile item giver (UtilityBelt's /ub ig, the same way): /mt ig &lt;profile&gt; to &lt;name&gt; gives every item in
/// your pack that a Keep rule of the .utl profile matches (a Keep # rule: up to that many) to the player or NPC; /mt igp
/// takes part of their name. Profiles come from MelkTank's Profiles\ItemGiver, then Profiles\Loot, then UtilityBelt's
/// Documents\Decal Plugins\UtilityBelt\itemgiver. Items that need identifying are identified first. Each hand-over
/// waits for the item to leave the pack (tried again if it doesn't - the server busy), with a short delay between, and
/// it ends with a count ("Gave 12 items to X"). Works from metas (their chat commands) as well, in Decal and ACGodot.
/// </summary>
public static class ItemGiver
{
	private enum Phase { Idle, Identifying, Giving }

	private class Step
	{
		public int Item;
		public int Amount;
		public string Name;
		public int Tries;
		public int StackBefore;
	}

	private static readonly Regex Args = new Regex("^(?<p>.+?)\\s+to\\s+(?<to>.+)$", RegexOptions.IgnoreCase);

	/// <summary>Wait between one hand-over and the next.</summary>
	public static int DelayMs = 300;
	private const double WaitS = 3.0, IdWaitS = 10.0;
	private const int MaxTries = 3;

	private static Phase _phase;
	private static UtlProfile _profile;
	private static string _profileName = "";
	private static int _target;
	private static string _targetName = "";
	private static readonly Queue<Step> _queue = new Queue<Step>();
	private static Step _waiting;
	private static DateTime _sent, _idStarted, _idAsked;
	private static readonly HashSet<int> _needId = new HashSet<int>();
	private static int _given, _failed;

	public static bool Busy => _phase != Phase.Idle;

	public static string Progress => _phase switch
	{
		Phase.Identifying => "identifying " + _needId.Count + " item" + (_needId.Count == 1 ? "" : "s"),
		Phase.Giving => "gave " + _given + ", " + (_queue.Count + (_waiting != null ? 1 : 0)) + " to go",
		_ => "",
	};

	/// <summary>/mt ig (partial false) or /mt igp (true): "&lt;profile&gt; to &lt;name&gt;", "stop", or nothing for the usage.</summary>
	public static void Command(string args, bool partial)
	{
		args = (args ?? "").Trim();
		string verb = partial ? "igp" : "ig";
		if (args.Length == 0)
		{
			Util.WriteToChat("Usage: /mt " + verb + " <profile[.utl]> to <" + (partial ? "part of a name" : "name") + ">   |   /mt ig stop");
			Util.WriteToChat("Gives every item a Keep rule of the profile matches (Keep #: up to that many). Profiles: " + string.Join(", ", Folders()));
			return;
		}
		if (Regex.IsMatch(args, "^(stop|cancel|quit|abort)$", RegexOptions.IgnoreCase))
		{
			Stop(Busy ? "stopped" : null);
			return;
		}
		if (Busy || UbCmd.Giving)
		{
			Util.WriteToChat("ig: already giving (" + (Busy ? Progress : UbCmd.GiveProgress) + ") - wait, or /mt ig stop");
			return;
		}
		Match m = Args.Match(args);
		if (!m.Success)
		{
			Util.WriteToChat("Usage: /mt " + verb + " <profile[.utl]> to <name>");
			return;
		}
		string file = FindProfile(m.Groups["p"].Value.Trim());
		if (file == null)
		{
			Util.WriteToChat("ig: no profile " + m.Groups["p"].Value.Trim() + " in " + string.Join(", ", Folders()));
			return;
		}
		UtlProfile profile;
		try { profile = UtlProfile.Load(file); }
		catch (Exception ex)
		{
			Util.WriteToChat("ig: couldn't read " + Path.GetFileName(file) + ": " + ex.Message);
			return;
		}
		WorldObject target = FindTarget(m.Groups["to"].Value.Trim(), partial);
		if (target == null)
		{
			Util.WriteToChat("ig: " + m.Groups["to"].Value.Trim() + " not found");
			return;
		}
		_profile = profile;
		_profileName = Path.GetFileNameWithoutExtension(file);
		_target = target.Id;
		_targetName = target.Name;
		_queue.Clear();
		_waiting = null;
		_given = _failed = 0;
		// items whose rules need identify data, and don't have it yet: asked for first
		_needId.Clear();
		foreach (WorldObject o in Candidates())
		{
			if (!o.HasIdData && !LootMatcher.DecideWithoutId(profile, o, out _))
			{
				_needId.Add(o.Id);
				Util.RequestId(o.Id);
			}
		}
		_idStarted = _idAsked = DateTime.Now;
		_phase = Phase.Identifying;
		Util.WriteToChat("ig: " + _profileName + " to " + _targetName + (_needId.Count > 0 ? " - identifying " + _needId.Count + " item" + (_needId.Count == 1 ? "" : "s") + " first" : ""));
	}

	public static void Stop(string why = null)
	{
		bool was = Busy;
		_queue.Clear();
		_waiting = null;
		_needId.Clear();
		_phase = Phase.Idle;
		if (was && why != null) Util.WriteToChat("ig: " + why + " - gave " + _given + " item" + (_given == 1 ? "" : "s") + " to " + _targetName);
	}

	public static void Tick()
	{
		try
		{
			if (_phase == Phase.Identifying) Identify();
			else if (_phase == Phase.Giving) Give();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			Stop("error (" + ex.Message + ")");
		}
	}

	private static void Identify()
	{
		WorldFilter wf = CoreManager.Current.WorldFilter;
		_needId.RemoveWhere(id => wf[id] == null || wf[id].HasIdData);
		double waited = (DateTime.Now - _idStarted).TotalSeconds;
		if (_needId.Count > 0 && waited < IdWaitS)
		{
			// (asked again now and then: a request can be dropped)
			if ((DateTime.Now - _idAsked).TotalSeconds > 3.0)
			{
				foreach (int id in _needId) Util.RequestId(id);
				_idAsked = DateTime.Now;
			}
			return;
		}
		if (_needId.Count > 0) Util.WriteToChat("ig: " + _needId.Count + " item" + (_needId.Count == 1 ? "" : "s") + " never came back identified - judged on what's known");
		_needId.Clear();
		Plan();
	}

	/// <summary>What goes: the first rule each item matches, if it's a Keep (all of it) or Keep # (up to its number, counted per rule - per name too if the rule keeps "each").</summary>
	private static void Plan()
	{
		var left = new Dictionary<string, int>();
		int items = 0;
		foreach (WorldObject o in Candidates())
		{
			UtlRule rule = LootMatcher.FirstMatch(_profile, o);
			if (rule == null || (rule.Act != "1" && rule.Act != "10")) continue;
			int stack = Math.Max(1, o.Values(LongValueKey.StackCount, 1));
			int amount = stack;
			if (rule.Act == "10")
			{
				string key = rule.Name + "\u0001" + (rule.KeepEach ? (o.Name ?? "").ToLowerInvariant() : "");
				if (!left.TryGetValue(key, out int n))
				{
					if (!int.TryParse(rule.KeepN, out n)) n = 1;
				}
				if (n <= 0) continue;
				amount = Math.Min(stack, n);
				left[key] = n - amount;
			}
			_queue.Enqueue(new Step { Item = o.Id, Amount = amount, Name = o.Name });
			items++;
		}
		if (_queue.Count == 0)
		{
			Util.WriteToChat("ig: nothing in your pack matches a Keep rule of " + _profileName);
			_phase = Phase.Idle;
			return;
		}
		Util.WriteToChat("ig: giving " + items + " item" + (items == 1 ? "" : "s") + " to " + _targetName);
		_phase = Phase.Giving;
		_sent = DateTime.MinValue;
	}

	private static void Give()
	{
		WorldFilter wf = CoreManager.Current.WorldFilter;
		if (wf[_target] == null)
		{
			Stop(_targetName + " isn't around any more");
			return;
		}
		if (_waiting != null)
		{
			WorldObject o = wf[_waiting.Item];
			bool gone = o == null || !InPack(o.Id) || (_waiting.Amount < _waiting.StackBefore && o.Values(LongValueKey.StackCount, 1) < _waiting.StackBefore);
			if (!gone && (DateTime.Now - _sent).TotalSeconds < WaitS) return;
			if (gone) _given++;
			else if (++_waiting.Tries < MaxTries) _queue.Enqueue(_waiting);   // (still here: the server was busy - again later)
			else { _failed++; Util.WriteToChat("ig: couldn't give " + _waiting.Name); }
			_waiting = null;
		}
		if ((DateTime.Now - _sent).TotalMilliseconds < DelayMs) return;
		if (_queue.Count == 0)
		{
			_phase = Phase.Idle;
			Util.WriteToChat("Gave " + _given + " item" + (_given == 1 ? "" : "s") + " to " + _targetName + (_failed > 0 ? " (" + _failed + " couldn't be given)" : ""));
			return;
		}
		Step s = _queue.Dequeue();
		WorldObject item = wf[s.Item];
		if (item == null || !InPack(s.Item)) { _sent = DateTime.Now; return; }   // (gone already - used, dropped)
		s.StackBefore = Math.Max(1, item.Values(LongValueKey.StackCount, 1));
		CM_Inventory.Event_GiveObjectRequest((uint)_target, (uint)s.Item, (uint)s.Amount);
		_waiting = s;
		_sent = DateTime.Now;
	}

	/// <summary>Your pack's items that could go: not worn or wielded, not the packs themselves.</summary>
	private static List<WorldObject> Candidates()
	{
		var list = new List<WorldObject>();
		foreach (WorldObject o in CoreManager.Current.WorldFilter.GetInventory())
		{
			if (o == null || o.ObjectClass == ObjectClass.Container) continue;
			if (o.Values(LongValueKey.EquippedSlots, 0) != 0) continue;
			list.Add(o);
		}
		return list;
	}

	private static bool InPack(int id)
	{
		foreach (WorldObject o in CoreManager.Current.WorldFilter.GetInventory()) if (o.Id == id) return true;
		return false;
	}

	private static WorldObject FindTarget(string name, bool partial)
	{
		WorldFilter wf = CoreManager.Current.WorldFilter;
		if (name.Equals("selected", StringComparison.OrdinalIgnoreCase))
		{
			int sel = CoreManager.Current.Actions.CurrentSelection;
			return sel != 0 ? wf[sel] : null;
		}
		int me = CoreManager.Current.CharacterFilter.Id;
		WorldObject best = null;
		double bestD = double.MaxValue;
		foreach (WorldObject o in wf.GetLandscape())
		{
			if (o == null || o.Id == me) continue;
			if (o.ObjectClass != ObjectClass.Player && o.ObjectClass != ObjectClass.Npc && o.ObjectClass != ObjectClass.Vendor) continue;
			string n = o.Name ?? "";
			bool hit = partial ? n.IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0 : n.Equals(name, StringComparison.OrdinalIgnoreCase);
			if (!hit) continue;
			double d = CombatEngine.Distance(o);
			if (d < bestD) { bestD = d; best = o; }
		}
		return best;
	}

	/// <summary>Where profiles are looked for, in order.</summary>
	public static List<string> Folders()
	{
		var list = new List<string>();
		try { list.Add(Util.ProfilesDir("ItemGiver", moveOld: false)); } catch { }
		try { list.Add(Util.ProfilesDir("Loot", moveOld: false)); } catch { }
		try
		{
			string docs = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
			if (!string.IsNullOrEmpty(docs)) list.Add(Path.Combine(docs, "Decal Plugins", "UtilityBelt", "itemgiver"));
		}
		catch { }
		return list;
	}

	private static string FindProfile(string name)
	{
		if (Path.IsPathRooted(name) && File.Exists(name)) return name;
		string want = name.EndsWith(".utl", StringComparison.OrdinalIgnoreCase) ? name : name + ".utl";
		foreach (string dir in Folders())
		{
			try
			{
				if (!Directory.Exists(dir)) continue;
				string exact = Path.Combine(dir, want);
				if (File.Exists(exact)) return exact;
				// (any case: Linux file names care)
				string hit = Directory.GetFiles(dir, "*.utl").FirstOrDefault(f => string.Equals(Path.GetFileName(f), want, StringComparison.OrdinalIgnoreCase));
				if (hit != null) return hit;
			}
			catch { }
		}
		return null;
	}
}
