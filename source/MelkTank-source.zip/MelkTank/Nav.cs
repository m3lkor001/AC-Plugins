using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
#if !RETAIL
using ACGodot.DecalShim;
using ACGodot.Plugins;
using ACGodot.UI;
#endif
#if !RETAIL
using AcClient;
#else
using SmartBox = AcClient.SmartBox;
using ACCmdInterp = AcClient.ACCmdInterp;
using CommandInterpreter = AcClient.CommandInterpreter;
using CommandListElement = AcClient.CommandListElement;
using CPhysicsObj = AcClient.CPhysicsObj;
using Position = AcClient.Position;
using CTransition = AcClient.CTransition;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
#if !RETAIL
using Godot;
#endif
using ImGuiNET;
using MelkTank.Loot;
using MelkTank.Metas;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public class Nav
{
	private class TreeDir
	{
		public string Path;

		public string Name;

		public List<TreeDir> Dirs = new List<TreeDir>();

		public List<string> Files = new List<string>();
	}

	public Func<bool> MetaNeedBuff;

	private string _mState = "Default";

	private DateTime _mStateAt = DateTime.Now;

	private DateTime _mStatePersistAt = DateTime.Now;

	private DateTime _mNextTick = DateTime.MinValue;

	private readonly HashSet<MRule> _mFired = new HashSet<MRule>();

	private readonly List<string> _mChat = new List<string>();

	private readonly Stack<string> _mCalls = new Stack<string>();

	private bool _mDied;

	private bool _mPortalIn;

	private bool _mPortalOut;

	private bool _mVendorSeen;

	private Meta _mMeta;

	private NavRoute _metaRoute;

	private MVal _metaRouteSrc;

	private string _wdState;

	private double _wdDist;

	private double _wdSecs;

	private DateTime _wdAt;

	private double _wdNS;

	private double _wdEW;

	private bool _wdOn;

	private readonly HashSet<string> _mWarned = new HashSet<string>();

	private readonly Dictionary<string, string> _mOpts = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

	private readonly Dictionary<string, Regex> _mRx = new Dictionary<string, Regex>();

	public readonly List<string> MetaLog = new List<string>();

	private bool _mWasWaiting;

	private bool _metaWasRunning;

	private bool _metaSeen;

	private static readonly Regex AddPtRx = new Regex("(-?\\d+(?:\\.\\d+)?)\\s*([NS])[\\s,]+(-?\\d+(?:\\.\\d+)?)\\s*([EW])(?:[\\s,]+(-?\\d+(?:\\.\\d+)?)\\s*Z?)?", RegexOptions.IgnoreCase);

	private List<string> _metaNames;

	private DateTime _metaNamesAt = DateTime.MinValue;

	private static readonly System.Numerics.Vector4 Cyan = new System.Numerics.Vector4(0.35f, 0.85f, 0.95f, 1f);

	private static readonly System.Numerics.Vector4 Green = new System.Numerics.Vector4(0.45f, 0.9f, 0.45f, 1f);

	private static readonly System.Numerics.Vector4 Grey = new System.Numerics.Vector4(0.6f, 0.6f, 0.6f, 1f);

	private static readonly System.Numerics.Vector4 Yellow = new System.Numerics.Vector4(0.95f, 0.85f, 0.35f, 1f);

	private static readonly System.Numerics.Vector4 Red = new System.Numerics.Vector4(0.95f, 0.35f, 0.35f, 1f);

	private readonly Settings _s;

	public Action SaveAll;

	private static bool _liveOk;

	private static bool _liveWarned;

	public static double LiveDiff;

	private bool _running;

	private DateTime _runStart;

	private DateTime _lastFace = DateTime.MinValue;

	private DateTime _lastProgressAt;

	private DateTime _pauseUntil = DateTime.MinValue;

	private DateTime _lastHeadingFix = DateTime.MinValue;

	private double _bestDist;

	private bool _pulsing;

	private DateTime _pulseOnUntil = DateTime.MinValue;

	private DateTime _pulseOffUntil = DateTime.MinValue;

	private string _tooFarNoted;

	public Action<string> Log;

	private DateTime _lastReturnTick = DateTime.MinValue;

	private double _mapLastNS;

	private double _mapLastEW;

	private double _mapLastD = double.MaxValue;

	public int StuckEvents;

	private bool _moving;

	private bool _warnedDir;

	private double _kickBest = double.MaxValue;

	private int _restartStage;

	private int _kicks;

	private DateTime _restartAt = DateTime.MinValue;

	private DateTime _kickAt = DateTime.MinValue;

	private DateTime _turnStart;

	private double _startNS;

	private double _startEW;

	private double _startZ;

	private double _startHeading;

	private D3DObj _ring;

	private D3DObj _label;

	private D3DObj _arrow;

	private DateTime _labelCheck = DateTime.MinValue;

	private string _drawnKey = "";

	private DateTime _markersAt = DateTime.MinValue;

	private D3DObj _test;

	private DateTime _testAt = DateTime.MinValue;

	private int _testStage;

	private static int _visFails;

	private static string _visFirst;

	private bool? _lastFocused;

	public const string LeftoversKey = "MelkTank.D3DLeftovers";

	private string _newName = "";

	public Action DrawPortals;

	private bool _retarget;

	private DateTime _lastDirectSteer = DateTime.MinValue;

	private static readonly Regex ChamberWord = new Regex("\\bchambers?\\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);

	private static readonly Regex NumberRx = new Regex("\\bchamber\\s*(?:#|no\\.?|number)?\\s*(\\d{1,2})\\b|\\b(\\d{1,2})(?:st|nd|rd|th)?\\s+chamber\\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);

	private static readonly Regex SpotNumberRx = new Regex("(?:C|chamber\\s*)0*(\\d+)$", RegexOptions.IgnoreCase | RegexOptions.Compiled);

	private static readonly string[][] DungeonAliases = new string[3][]
	{
		new string[2] { "wailing", "banshee" },
		new string[2] { "idol", "idol" },
		new string[2] { "quarry", "drudge" }
	};

	private int _chamber = -1;

	private string _chamberText = "";

	private DateTime _chamberDue = DateTime.MaxValue;

	private bool _navWasOn;

	private static string _earlyText;

	private static DateTime _earlyAt = DateTime.MinValue;

	private int _doorId;

	private DateTime _doorAt = DateTime.MinValue;

	private DateTime _doorPickAt = DateTime.MinValue;

	private bool _doorLocked;

	private readonly Dictionary<int, int> _doorTries = new Dictionary<int, int>();

	private readonly HashSet<int> _doorNoPick = new HashSet<int>();

	private const int ResistLockpick = 38;

	public Func<string> FileDir;

	private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

	private bool _showVtankDir;

	private string _pickFile;

	private string _pickFolder;

	private DateTime _treeAt = DateTime.MinValue;

	private TreeDir _tree;

	private DateTime _routeDirtyAt = DateTime.MinValue;

	private bool _filesChecked;

	private DateTime _spotDirtyAt = DateTime.MinValue;

	private bool _spotFilesChecked;

	private DateTime _fLastSeen = DateTime.MinValue;

	private DateTime _fPortalUsedAt = DateTime.MinValue;

	private DateTime _fLostSaid = DateTime.MinValue;

	private double _fLastNS;

	private double _fLastEW;

	private bool _fHasLast;

	private D3DObj _fRing;

	private D3DObj _fArrow;

	private int _fMarked;

	private string _fMarkKey = "";

	private DateTime _fVisCheck = DateTime.MinValue;

	private readonly List<NavSpot> _crumbs = new List<NavSpot>();

	private const string HotKey = "MelkTank.NavHotCarry";

	private bool _hotTried;

	private static readonly CultureInfo HCI = CultureInfo.InvariantCulture;

	public const string MapRouteName = "Map route";

	public const string MapRouteKey = "MelkTank.MapRoute";

	private static readonly CultureInfo MCI = CultureInfo.InvariantCulture;

	private string _mapPublished;

	private DateTime _mapPubAt = DateTime.MinValue;

	private Meta _meta;

	private string _metaState = "Default";

	private int _metaEdit = -1;

	private string _metaNewState = "";

	private string _metaRename = "";

	private bool _metaTriedLast;

	private List<string> _pickList = new List<string>();

	private DateTime _pickListAt = DateTime.MinValue;

	private bool _pickListVt;

	private static readonly Dictionary<uint, string> _newStateBuf = new Dictionary<uint, string>();

	private static readonly string[] _condNames = CondNames();

	private static readonly string[] _actNames = ActNames();

	public const string MtRouteTag = "<MelkTankRoute";

	private static readonly Regex VtGetRx = new Regex("^\\s*\\$(?<var>\\w+)\\s*=\\s*(?:tostring\\[\\s*)?vtgetsetting\\[\\s*`?(?<opt>\\w+)`?\\s*\\](?:\\s*\\])?\\s*$", RegexOptions.IgnoreCase);

	private static readonly Regex VtSetVarRx = new Regex("^\\s*vtsetsetting\\[\\s*`?(?<opt>\\w+)`?\\s*,\\s*(?<val>\\$\\w+)\\s*\\]\\s*$", RegexOptions.IgnoreCase);

	private static readonly Regex VtSetFixedRx = new Regex("^\\s*vtsetsetting\\[\\s*`?(?<opt>\\w+)`?\\s*,\\s*`?(?<val>\\w+)`?\\s*\\]\\s*$", RegexOptions.IgnoreCase);

	private static readonly Regex VtSetInnerRx = new Regex("vtsetsetting\\[\\s*(?<opt>\\w+)\\s*,\\s*(?<esc>\\\\*)`(?<val>[^`\\\\]*)\\k<esc>`\\s*\\]", RegexOptions.IgnoreCase);

	private int _vtCountCache = -1;

	private Meta _vtCountMeta;

	private DateTime _vtCountAt;

	private DateTime _metaTreeAt = DateTime.MinValue;

	private TreeDir _metaTree;

	private string _metaPick;

	private static readonly System.Numerics.Vector4 Purple = new System.Numerics.Vector4(0.78f, 0.6f, 0.98f, 1f);

	private int _rPresetPick;

	private readonly HashSet<RouteStep> _presetClosed = new HashSet<RouteStep>();

	private string _pName = "";

	private string _pNewName = "";

	private int _pSel = -1;

	private RouteStep _pEdit;

	public static readonly string[] RouteModes = new string[3] { "Once", "Back and forth (linear)", "Round and round (circular)" };

	public static readonly string[] StuckActions = new string[5] { "Keep trying", "Turn combat on", "Back up and try again", "Start the route over", "Skip that point" };

	private int _rLastCount = -1;

	private bool _rSkipNoMobs;

	private int _rStuckSeen;

	private int _rStuckIdx = -1;

	private int _rStuckN;

	private bool _rTempCombat;

	private readonly List<int> _rDetour = new List<int>();

	private bool _recording;

	private float _recEvery = 10f;

	private double _recNS;

	private double _recEW;

	private DateTime _recNext = DateTime.MinValue;

	private string _recRoute = "";

	private int _rIdx;

	private int _rDir = 1;

	private bool _rDone;

	private bool _rStarted;

	private DateTime _rFarRestartAt = DateTime.MinValue;

	private DateTime _rUntil = DateTime.MinValue;

	private DateTime _rUsedAt = DateTime.MinValue;

	private string _rName = "";

	private int _rLandblock;

	private int _rSel = -1;

	private string _rNewName = "";

	private string _rCmd = "";

	private int _rCmdWait = 1000;

	private int _rWaitSecs = 5;

	private int _rToggle;

	private static readonly string[] GoWhere = new string[2] { "from step 1", "at its nearest point" };

	private int _rGoPick;

	private int _rGoWhere;

	private int _rGemPick;

	private int _rGemWait = 10;

	private int _rRecallPick;

	private string _rGem = "";

	private string _rVendorNpc = "";

	private string _rVendorProfile = "";

	private List<KeyValuePair<int, string>> _recalls;

	private string _rcText = "";

	private string _rcChat = "";

	private int _rcOp = 4;

	private int _rcNum = 30;

	private int _rcChatOp;

	public static readonly string[] ChatOps = new string[2] { "contains", "=" };

	public static readonly string[] ItemOps = new string[6] { "=", "!=", "<", ">", ">=", "<=" };

	private string _rChat = "";

	private string _rItem = "";

	private int _rChatOp;

	private int _rItemOp = 4;

	private int _rItemNum = 1;

	private int _rSkipM = 20;

	private int _rSkipN = 3;

	private DateTime _rStepAt = DateTime.Now;

	private DateTime _rPrevStepAt = DateTime.Now;

	private DateTime _rItemCheckAt = DateTime.MinValue;

	private readonly List<KeyValuePair<DateTime, string>> _chat = new List<KeyValuePair<DateTime, string>>();

	public const double LoopPreferM = 10.0;

	private static readonly string[] ToggleNames = new string[9] { "Combat ON", "Combat OFF", "Looting ON", "Looting OFF", "Summoning ON", "Summoning OFF", "Reset session", "Doors ON", "Doors OFF" };

	private static readonly string[] ToggleTexts = new string[10] { "combat on", "combat off", "looting on", "looting off", "summoning on", "summoning off", "reset session", "doors on", "doors off", "reset kills/hr" };

	private double _rStuckAcc;

	private int _rStuckStep = -1;

	private string _rStuckRoute = "";

	private DateTime _rStuckLast = DateTime.MinValue;

	private bool _inPortal;

	private DateTime _portalExitAt = DateTime.MinValue;

	private DateTime _diedAt = DateTime.MinValue;

	private int _rUseIdx = -1;

	private int _rUseTries;

	private int _rUseHad;

	private DateTime _rUseRetryAt = DateTime.MinValue;

	private int _rSub;

	private int _rSubFor = -1;

	private readonly HashSet<string> _presetWarned = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

	private bool _farEndNoted;

	private bool _resumeNearest;

	private const double ResumeNearestM = 500.0;

	private DateTime _rTickAt = DateTime.MinValue;

	private readonly List<D3DObj> _routeObjs = new List<D3DObj>();

	private const int RouteWindow = 150;

	private const int MaxRouteObjs = 1500;

	private string _routeKey = "";

	private DateTime _routeVisCheck = DateTime.MinValue;

	private int _tUseIdx = -1;

	private int _tUseTries;

	private bool _rCastWield;

	private DateTime _rCastModeAt = DateTime.MinValue;

	private DateTime _useFaceUntil = DateTime.MinValue;

	private const float BtnW = 150f;

	private const float StepsTableW = 606f;

	private RouteStep _rEdit;

	private float _rAddH;

	private double _rEditNS;

	private double _rEditEW;

	private double _rEditZ;

	private string _rEditName = "";

	private const uint TurnRightMotion = 1694498829u;

	private const uint TurnLeftMotion = 1694498830u;

	private double _steerWant = -1.0;

	private DateTime _steerWantAt = DateTime.MinValue;

	private int _turning;

	private int _turnSign = 1;

	private double _turnStartDiff;

	private DateTime _turnStartAt;

	private bool _motionBroken;

	private int _steerLogs;

	private Hud _toolsHud;

	public const string TravelStateKey = "MelkTank.Travel";

	private NavRoute _travelRoute;

	private NavRoute _travelPreview;

	private bool _tWasEnabled;

	private bool _tWasMaster;

	private bool _tWasCombat;

	private bool _tCombatOff;

	private int _tWasMode;

	private string _tWasRoute = "";

	private DateTime _autorunOnAt = DateTime.MinValue;

	private DateTime _tStartedAt = DateTime.MinValue;

	private DateTime _doorUseAt = DateTime.MinValue;

	private bool _doorRerun;

	private int _tStep = -1;

	private int _tStuckBase;

	private int _tFlagOff;

	private double _tStepSecs;

	private DateTime _tTickAt = DateTime.MinValue;

	private DateTime _tLastTurn = DateTime.MinValue;

	private DateTime _tFlagAt = DateTime.MinValue;

	private bool _tFlagSeen;

	private DateTime _tKeyAt = DateTime.MinValue;

	private const uint WalkBackMotion = 1157627910u;

	private const uint SideRightMotion = 1694498831u;

	private const uint SideLeftMotion = 1694498832u;

	private NavSpot _tDetour;

	private DateTime _tProbeAt = DateTime.MinValue;

	private DateTime _tDetourAt = DateTime.MinValue;

	private int _tDetourFor = -1;

	private int _tSide;

	private static int _wallState;

	private static bool _wallProven;

	private readonly Dictionary<int, DateTime> _tDoorUsed = new Dictionary<int, DateTime>();

	private DateTime _tDoorWait = DateTime.MinValue;

	private readonly Dictionary<int, DateTime> _doorAsked = new Dictionary<int, DateTime>();

	private DateTime _useDoorWait = DateTime.MinValue;

	private int _tLastDoor;

	private DateTime _tLastDoorAt;

	private bool _tLastDoorAgain;

	private readonly List<double[]> _tHits = new List<double[]>();

	private double _tHitD;

	private double _tHeading;

	private double _tFollowM;

	private double _tTurned;

	private DateTime _tPushUntil = DateTime.MinValue;

	private DateTime _tFollowAt;

	private bool _tFlipped;

	private static double _pBearing;

	private static double _pSlope = double.NaN;

	public bool MetaRunning => _s.MetaRun && _meta != null;

	public string MetaCurState => _mState;

	public string MetaName => (_meta != null) ? (_meta.Name ?? "") : "";

	public bool InPortal => _inPortal;

	public string Status { get; private set; }

	public NavSpot Current
	{
		get
		{
			foreach (NavSpot navSpot in _s.NavSpots)
			{
				if (string.Equals(navSpot.Name, _s.NavSelected, StringComparison.OrdinalIgnoreCase))
				{
					return navSpot;
				}
			}
			return null;
		}
	}

	private static double PulseRange => Tuning.V("PulseRangeM");

	public bool Running => _running;

	public bool Away
	{
		get
		{
			NavSpot navSpot = ((_s.NavEnabled && _s.NavMode == 0) ? Current : null);
			if (navSpot == null || DateTime.Now < _pauseUntil)
			{
				return false;
			}
			double num = DistanceTo(navSpot);
			return num > (double)_s.NavDrift;
		}
	}

	private bool OpenDoorsNow => _s.NavOpenDoors || _travelRoute != null;

	public static string NavDir => Util.ProfilesDir("Navs");

	public static string VtankDir
	{
		get
		{
			string[] array = new string[3] { "C:\\Games\\VirindiPlugins\\VirindiTank", "C:\\Program Files\\VirindiPlugins\\VirindiTank", "C:\\Program Files (x86)\\VirindiPlugins\\VirindiTank" };
			foreach (string text in array)
			{
				if (Directory.Exists(text))
				{
					return text;
				}
			}
			return null;
		}
	}

	private string Dir => (_showVtankDir && VtankDir != null) ? VtankDir : NavDir;

	public static string SpotDir => Path.Combine(NavDir, "Spots");

	private static double CrumbStep => Tuning.V("CrumbStepM");

	private static double CrumbArrive => Tuning.V("CrumbArriveM");

	public Meta CurrentMeta => _meta;

	public static string MetaDir => Util.ProfilesDir("Metas");

	public bool Recording => _recording;

	public NavRoute CurrentRoute
	{
		get
		{
			if (_travelRoute != null && string.Equals(_travelRoute.Name, _s.NavRouteSelected, StringComparison.Ordinal))
			{
				return _travelRoute;
			}
			if (_metaRoute != null && string.Equals(_metaRoute.Name, _s.NavRouteSelected, StringComparison.Ordinal))
			{
				return _metaRoute;
			}
			foreach (NavRoute navRoute in _s.NavRoutes)
			{
				if (string.Equals(navRoute.Name, _s.NavRouteSelected, StringComparison.OrdinalIgnoreCase))
				{
					return navRoute;
				}
			}
			return null;
		}
	}

	public int RouteStepNow
	{
		get
		{
			try
			{
				return (_s.NavEnabled && _s.NavMode == 1 && CurrentRoute != null && !_rDone) ? (_rIdx + 1) : 0;
			}
			catch
			{
				return 0;
			}
		}
	}

	public bool RouteWalking
	{
		get
		{
			try
			{
				NavRoute currentRoute = CurrentRoute;
				if (RouteStepNow <= 0 || _rIdx >= currentRoute.Steps.Count || currentRoute.Steps[_rIdx].Kind != StepKind.Point)
				{
					return false;
				}
				int num = _rIdx + 1;
				if (num < currentRoute.Steps.Count && currentRoute.Steps[num].Kind == StepKind.Cast)
				{
					return false;
				}
				return true;
			}
			catch
			{
				return false;
			}
		}
	}

	public string RouteNameNow
	{
		get
		{
			try
			{
				NavRoute currentRoute = CurrentRoute;
				return (currentRoute != null) ? currentRoute.Name : "";
			}
			catch
			{
				return "";
			}
		}
	}

	private bool KeySteer => _s.NavSmoothSteer && !_motionBroken;

	public bool Travelling => _travelRoute != null;

	private static string WallPath => Util.FullPath("MelkTank_WallCheck.txt");

	public string ExprOptGet(string opt)
	{
		return OptGet(opt);
	}

	public void ExprOptSet(string opt, string val)
	{
		OptSet(opt, val);
	}

	public bool IsMetaRoute(NavRoute r)
	{
		return r != null && r == _metaRoute;
	}

	private void MLog(string s)
	{
		MetaLog.Add(DateTime.Now.ToString("HH:mm:ss") + "  " + s);
		if (MetaLog.Count > 60)
		{
			MetaLog.RemoveAt(0);
		}
		L("META  " + s);
	}

	private void MWarn(string key, string text)
	{
		if (_mWarned.Add(key))
		{
			Util.WriteToChat("Meta: " + text);
		}
	}

	public void MetaStart()
	{
		if (_meta == null)
		{
			Util.WriteToChat("Meta: no meta open (Nav > Meta).");
			return;
		}
		if (!_s.MetaRun)
		{
			_s.MetaRun = true;
			if (SaveAll != null)
			{
				SaveAll();
			}
		}
		_mMeta = _meta;
		List<string> list = _meta.States();
		_mCalls.Clear();
		MetaSetState(list.Contains("Default") ? "Default" : list[0], persistReset: true);
		Util.WriteToChat("Meta: " + _meta.Name + " running (state " + _mState + ").");
	}

	public void MetaStartAt(string state, MRule from)
	{
		if (_meta == null)
		{
			return;
		}
		if (!_s.MetaRun)
		{
			_s.MetaRun = true;
			if (SaveAll != null)
			{
				SaveAll();
			}
		}
		_mMeta = _meta;
		_mCalls.Clear();
		MetaSetState(state, persistReset: true);
		if (from != null)
		{
			foreach (MRule rule in _meta.Rules)
			{
				if (rule == from)
				{
					break;
				}
				if (rule.State == state)
				{
					_mFired.Add(rule);
				}
			}
		}
		Util.WriteToChat("Meta: " + _meta.Name + " running from " + state + ((from != null) ? (" (rule " + MetaText.Describe(from.C) + ")") : "") + ".");
	}

	public void MetaStop(bool quiet = false)
	{
		if (_s.MetaRun)
		{
			_s.MetaRun = false;
			if (SaveAll != null)
			{
				SaveAll();
			}
		}
		_wdOn = false;
		if (!quiet)
		{
			Util.WriteToChat("Meta: stopped.");
		}
		MLog("stopped");
	}

	private void GoState(string state)
	{
		if (state == _mState && !_s.MetaSameRestarts)
		{
			MLog("already in " + state + " - carrying on");
		}
		else
		{
			MetaSetState(state, persistReset: true);
		}
	}

	public void MetaSetState(string state, bool persistReset)
	{
		if (!string.IsNullOrEmpty(state))
		{
			if (_meta != null && !_meta.States().Contains(state))
			{
				MWarn("nostate:" + state, "there's no state called " + state + " - staying in it does nothing.");
			}
			if (state != _mState)
			{
				MLog("state " + _mState + " -> " + state);
			}
			else
			{
				MLog("state " + state + " again");
			}
			_mState = state;
			_mStateAt = DateTime.Now;
			if (persistReset)
			{
				_mStatePersistAt = DateTime.Now;
			}
			_mFired.Clear();
			_mChat.Clear();
			_mDied = (_mPortalIn = (_mPortalOut = false));
			_mVendorSeen = VendorOpen();
			_wdOn = false;
		}
	}

	public void MetaChat(string text)
	{
		if (MetaRunning && !string.IsNullOrEmpty(text))
		{
			_mChat.Add(text.TrimEnd(new char[2] { '\r', '\n' }));
			if (_mChat.Count > 200)
			{
				_mChat.RemoveAt(0);
			}
		}
	}

	public void MetaNoteDeath()
	{
		_mDied = true;
	}

	public void MetaNotePortal(bool enter)
	{
		if (enter)
		{
			_mPortalIn = true;
		}
		else
		{
			_mPortalOut = true;
		}
	}

	public void MetaTick()
	{
		RestoreHotState();
		bool metaRunning = MetaRunning;
		if (!_metaSeen)
		{
			_metaSeen = true;
			_metaWasRunning = metaRunning;
			if (!metaRunning)
			{
				_s.MetaTurnedNavOn = false;
			}
		}
		if (_metaWasRunning && !metaRunning && _s.MetaTurnedNavOn)
		{
			_s.MetaTurnedNavOn = false;
			if (_s.NavEnabled)
			{
				_s.NavEnabled = false;
				Stop();
				if (SaveAll != null)
				{
					SaveAll();
				}
				Util.WriteToChat("Meta stopped - Nav switched off (the meta had switched it on).");
			}
		}
		_metaWasRunning = metaRunning;
		if (!_metaTriedLast)
		{
			_metaTriedLast = true;
			if (_meta == null && _s.MetaOpenLast && !string.IsNullOrEmpty(_s.MetaLast) && File.Exists(_s.MetaLast))
			{
				OpenMeta(_s.MetaLast);
			}
		}
		if (!MetaRunning || DateTime.Now < _mNextTick)
		{
			return;
		}
		_mNextTick = DateTime.Now.AddMilliseconds(200.0);
		if (_mMeta != _meta)
		{
			_mMeta = _meta;
			_mCalls.Clear();
			List<string> list = _meta.States();
			MetaSetState(list.Contains("Default") ? "Default" : list[0], persistReset: true);
		}
		if (_inPortal || (DateTime.Now - _portalExitAt).TotalSeconds < 2.0 || (_diedAt > _portalExitAt && (DateTime.Now - _diedAt).TotalSeconds < 30.0))
		{
			if (!_mWasWaiting)
			{
				MLog("waiting - portal space");
			}
			_mWasWaiting = true;
			return;
		}
		_mWasWaiting = false;
		if (VendorOpen())
		{
			_mVendorSeen = true;
		}
		if (_wdOn && MyPos(out var ns, out var ew, out var _))
		{
			double num = Math.Sqrt(Math.Pow((ns - _wdNS) * 240.0, 2.0) + Math.Pow((ew - _wdEW) * 240.0, 2.0));
			if (num >= _wdDist)
			{
				_wdNS = ns;
				_wdEW = ew;
				_wdAt = DateTime.Now;
			}
			else if ((DateTime.Now - _wdAt).TotalSeconds >= _wdSecs)
			{
				MLog("watchdog: moved " + num.ToString("0.0") + " m in " + _wdSecs + " s -> " + _wdState);
				string wdState = _wdState;
				_wdOn = false;
				MetaSetState(wdState, persistReset: true);
				return;
			}
		}
		foreach (MRule rule in _meta.Rules)
		{
			if (rule.State != _mState || _mFired.Contains(rule))
			{
				continue;
			}
			bool flag;
			try
			{
				flag = Cond(rule.C);
			}
			catch (Exception ex)
			{
				MWarn("cerr:" + ex.Message, "a condition failed: " + ex.Message);
				flag = false;
			}
			if (!flag)
			{
				continue;
			}
			_mFired.Add(rule);
			try
			{
				Act(rule.A);
				break;
			}
			catch (Exception ex2)
			{
				MWarn("aerr:" + ex2.Message, "an action failed: " + ex2.Message);
				break;
			}
		}
	}

	private bool Cond(MCond c)
	{
		if (c == null)
		{
			return false;
		}
		MVal data = c.Data;
		switch (c.Type)
		{
		case 0:
			return false;
		case 1:
			return true;
		case 2:
			if (c.Kids == null)
			{
				return true;
			}
			foreach (MCond kid in c.Kids)
			{
				if (!Cond(kid))
				{
					return false;
				}
			}
			return true;
		case 3:
			if (c.Kids == null)
			{
				return false;
			}
			foreach (MCond kid2 in c.Kids)
			{
				if (Cond(kid2))
				{
					return true;
				}
			}
			return false;
		case 21:
			return c.Kids != null && c.Kids.Count > 0 && !Cond(c.Kids[0]);
		case 4:
		{
			Regex regex2 = Rx((data != null) ? data.S : "");
			if (regex2 == null)
			{
				return false;
			}
			foreach (string item in _mChat)
			{
				if (regex2.IsMatch(item))
				{
					return true;
				}
			}
			return false;
		}
		case 28:
		{
			Regex regex = Rx(data.GetS("p"));
			if (regex == null)
			{
				return false;
			}
			foreach (string item2 in _mChat)
			{
				Match match = regex.Match(item2);
				if (!match.Success)
				{
					continue;
				}
				string[] groupNames = regex.GetGroupNames();
				foreach (string text in groupNames)
				{
					if (!int.TryParse(text, out var _))
					{
						UbExpr.SetVar("capturegroup_" + text, match.Groups[text].Value);
					}
				}
				return true;
			}
			return false;
		}
		case 5:
			return Character.MainPackFreeSlots() <= (data?.AsInt ?? 0);
		case 6:
			return (DateTime.Now - _mStateAt).TotalSeconds >= (double)(data?.AsInt ?? 0);
		case 22:
			return (DateTime.Now - _mStatePersistAt).TotalSeconds >= (double)(data?.AsInt ?? 0);
		case 7:
			return RouteEmpty();
		case 8:
			return _mDied;
		case 100:
		{
			if (VendorRun.LastAt < _mStateAt || (VendorRun.I != null && VendorRun.I.Busy))
			{
				return false;
			}
			string text3 = (data.GetS("r") ?? "").Trim().ToLowerInvariant();
			return text3.Length == 0 || text3 == "any" || text3 == VendorRun.ResultWord(VendorRun.Last);
		}
		case 9:
			return VendorOpen();
		case 10:
			return _mVendorSeen && !VendorOpen();
		case 11:
			return ItemCount(data.GetS("n")) <= Int(data.GetS("c"));
		case 12:
			return ItemCount(data.GetS("n")) >= Int(data.GetS("c"));
		case 13:
			return MobsNear(Rx(data.GetS("n")), int.MinValue, Dbl(data.GetS("r"))) >= Int(data.GetS("c"));
		case 14:
			return MobsNear(null, Int(data.GetS("p")), Dbl(data.GetS("r"))) >= Int(data.GetS("c"));
		case 16:
			return MobsNear(null, int.MinValue, Dbl(data.GetS("r"))) == 0;
		case 15:
			return MetaNeedBuff != null && MetaNeedBuff();
		case 17:
			return (Globals.Core.Actions.Landcell & -65536) == ((data?.AsInt ?? 0) & -65536);
		case 18:
			return Globals.Core.Actions.Landcell == (data?.AsInt ?? 0);
		case 19:
			return _mPortalIn;
		case 20:
			return _mPortalOut;
		case 23:
		{
			int num2 = Int(data.GetS("sid"));
			double num3 = Dbl(data.GetS("sec"));
			foreach (EnchantmentWrapper enchantment in Globals.Core.CharacterFilter.Enchantments)
			{
				if (enchantment.SpellId == num2 && (enchantment.TimeRemaining < 0 || (double)enchantment.TimeRemaining >= num3))
				{
					return true;
				}
			}
			return false;
		}
		case 24:
			return BurdenPct() >= (double)(data?.AsInt ?? 0);
		case 25:
		{
			double num = NearestRoutePointM();
			return num < 0.0 || num >= (double)(data?.AsInt ?? 0);
		}
		case 26:
		{
			object v = UbExpr.Eval(data.GetS("e"), out var error);
			if (error != null)
			{
				MWarn("experr:" + data.GetS("e"), "expression error in " + _mState + ": " + error);
			}
			return UbExpr.Truthy(v);
		}
		case 27:
			MWarn("dialog", "'client dialog popup' conditions aren't supported yet - they count as false.");
			return false;
		default:
			MWarn("cond" + c.Type, "condition " + MetaText.CondName(c.Type) + " isn't supported - it counts as false.");
			return false;
		}
	}

	private Regex Rx(string p)
	{
		if (p == null)
		{
			return null;
		}
		if (_mRx.TryGetValue(p, out var value))
		{
			return value;
		}
		try
		{
			value = new Regex(p, RegexOptions.IgnoreCase);
		}
		catch (Exception ex)
		{
			MWarn("rx:" + p, "bad pattern \"" + p + "\": " + ex.Message);
			value = null;
		}
		_mRx[p] = value;
		return value;
	}

	private static int Int(string s)
	{
		if (int.TryParse(s, out var result))
		{
			return result;
		}
		double result2;
		return double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out result2) ? ((int)result2) : 0;
	}

	private static double Dbl(string s)
	{
		double result;
		return double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out result) ? result : 0.0;
	}

	private static bool VendorOpen()
	{
		try
		{
			return Globals.Core.Actions.VendorId != 0;
		}
		catch
		{
			return false;
		}
	}

	private static int ItemCount(string name)
	{
		int num = 0;
		if (string.IsNullOrEmpty(name))
		{
			return 0;
		}
		foreach (WorldObject item in InvCache.All())
		{
			if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
			{
				int num2 = 1;
				try
				{
					num2 = Math.Max(1, item.Values(LongValueKey.StackCount, 1));
				}
				catch
				{
				}
				num += num2;
			}
		}
		return num;
	}

	private int MobsNear(Regex name, int priority, double metres)
	{
		int num = 0;
		foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
		{
			if (item.ObjectClass != ObjectClass.Monster || item.Name.IndexOf("'s ", StringComparison.Ordinal) > 0)
			{
				continue;
			}
			try
			{
				if (item.Values(LongValueKey.CreateFlags2) != 0)
				{
					continue;
				}
			}
			catch
			{
			}
			if (name != null && !name.IsMatch(item.Name))
			{
				continue;
			}
			if (priority != int.MinValue)
			{
				try
				{
					if (_s.FindRule(item).Priority != priority)
					{
						continue;
					}
				}
				catch
				{
					continue;
				}
			}
			double num2 = CombatEngine.Distance(item);
			if (num2 >= 0.0 && num2 <= metres)
			{
				num++;
			}
		}
		return num;
	}

	private static double BurdenPct()
	{
		try
		{
			int num = Globals.Core.Actions.Attribute[AttributeType.CurrentStrength];
			int num2 = 0;
			WorldObject worldObject = Globals.Core.WorldFilter[Globals.Core.CharacterFilter.Id];
			try
			{
				if (worldObject != null)
				{
					num2 = worldObject.Values((LongValueKey)230, 0);
				}
			}
			catch
			{
			}
			double num3 = (double)num * (150.0 + 30.0 * (double)num2);
			if (num3 <= 0.0)
			{
				return 0.0;
			}
			long num4 = 0L;
			foreach (WorldObject item in InvCache.All())
			{
				try
				{
					num4 += item.Values(LongValueKey.Burden, 0);
				}
				catch
				{
				}
			}
			return (double)num4 * 100.0 / num3;
		}
		catch
		{
			return 0.0;
		}
	}

	public bool RouteEmpty()
	{
		NavRoute currentRoute = CurrentRoute;
		return currentRoute == null || currentRoute.Steps.Count == 0 || _rDone;
	}

	public double NearestRoutePointM()
	{
		NavRoute currentRoute = CurrentRoute;
		if (currentRoute == null || !MyPos(out var ns, out var ew, out var _))
		{
			return -1.0;
		}
		double num = -1.0;
		foreach (RouteStep step in currentRoute.Steps)
		{
			if (step.Kind == StepKind.Point || step.Kind == StepKind.Use)
			{
				double num2 = Math.Sqrt(Math.Pow((step.NS - ns) * 240.0, 2.0) + Math.Pow((step.EW - ew) * 240.0, 2.0));
				if (num < 0.0 || num2 < num)
				{
					num = num2;
				}
			}
		}
		return num;
	}

	private void Act(MAct a)
	{
		if (a == null)
		{
			return;
		}
		MVal data = a.Data;
		switch (a.Type)
		{
		case 0:
			break;
		case 1:
			GoState((data != null) ? data.S : "");
			break;
		case 2:
			MetaCommand((data != null) ? data.S : "");
			break;
		case 3:
			if (a.Kids == null)
			{
				break;
			}
			{
				foreach (MAct kid in a.Kids)
				{
					Act(kid);
				}
				break;
			}
		case 4:
			LoadEmbedded(data);
			break;
		case 5:
			_mCalls.Push(data.GetS("ret"));
			if (_mCalls.Count > 50)
			{
				MWarn("calldepth", "more than 50 calls without a return - the call list was cleared.");
				_mCalls.Clear();
			}
			MetaSetState(data.GetS("st"), persistReset: true);
			break;
		case 6:
			if (_mCalls.Count == 0)
			{
				MWarn("noreturn", "'return from call' with nothing to return to - ignored.");
			}
			else
			{
				MetaSetState(_mCalls.Pop(), persistReset: false);
			}
			break;
		case 7:
		{
			UbExpr.Eval(data.GetS("e"), out var error3);
			if (error3 != null)
			{
				MWarn("experr:" + data.GetS("e"), "expression error in " + _mState + ": " + error3);
			}
			break;
		}
		case 8:
		{
			object v2 = UbExpr.Eval(data.GetS("e"), out var error2);
			if (error2 != null)
			{
				MWarn("experr:" + data.GetS("e"), "expression error in " + _mState + ": " + error2);
			}
			else
			{
				MetaCommand(UbExpr.Text(v2));
			}
			break;
		}
		case 9:
		{
			_wdState = data.GetS("s");
			_wdDist = Dbl(data.GetS("r"));
			_wdSecs = Dbl(data.GetS("t"));
			if (MyPos(out var ns, out var ew, out var _))
			{
				_wdNS = ns;
				_wdEW = ew;
			}
			_wdAt = DateTime.Now;
			_wdOn = true;
			MLog("watchdog set: " + _wdDist + " m in " + _wdSecs + " s or go to " + _wdState);
			break;
		}
		case 10:
			_wdOn = false;
			break;
		case 11:
			UbExpr.SetVar(data.GetS("v"), (OptGet(data.GetS("o")) == "1") ? 1.0 : 0.0);
			break;
		case 12:
		{
			string text = data.GetS("v");
			if (text.StartsWith("$"))
			{
				object v = UbExpr.Eval(text, out var error);
				if (error != null)
				{
					MWarn("experr:" + text, "couldn't read " + text + ": " + error);
					break;
				}
				text = (UbExpr.Truthy(v) ? "1" : "0");
			}
			OptSet(data.GetS("o"), text);
			break;
		}
		case 100:
			UseByName(data.GetS("n"), 0);
			break;
		case 101:
			UseByName(data.GetS("n"), 1);
			break;
		case 102:
			UseByName(data.GetS("n"), 2);
			break;
		case 103:
			GiveTo(data.GetS("i"), data.GetS("n"));
			break;
		case 105:
			MLog("vendor at " + data.GetS("n") + ((data.GetS("p").Length > 0) ? (" with " + data.GetS("p")) : ""));
			VendorRun.I?.Start(data.GetS("n"), data.GetS("p"), dry: false);
			break;
		case 104:
			MLog("load route " + data.GetS("n"));
			VtCommand("/vt nav load " + data.GetS("n"));
			break;
		case 13:
		case 14:
		case 15:
			MWarn("views", "meta views (windows of buttons) aren't supported yet - those actions are skipped.");
			break;
		default:
			MWarn("act" + a.Type, "action " + MetaText.ActName(a.Type) + " isn't supported - skipped.");
			break;
		}
	}

	public void MetaCommand(string cmd)
	{
		cmd = (cmd ?? "").Trim();
		if (cmd.Length != 0)
		{
			MLog("send " + cmd);
			if (!MtCommand(cmd) && !VtCommand(cmd))
			{
				Util.Command(cmd);
			}
		}
	}

	public bool MtCommand(string cmd)
	{
		string text = (cmd ?? "").Trim();
		if (_s == null || (!_s.MtCommands && false))
		{
			return false;
		}
		if (!text.StartsWith("/mt ", StringComparison.OrdinalIgnoreCase) && !text.StartsWith("@mt ", StringComparison.OrdinalIgnoreCase))
		{
			return false;
		}
		string text2 = text.Substring(4).Trim();
		int num = text2.IndexOf(' ');
		string text3 = ((num < 0) ? text2 : text2.Substring(0, num)).ToLowerInvariant();
		string text4 = ((num < 0) ? "" : text2.Substring(num + 1).Trim());
		if (text3.StartsWith("use") || text3.StartsWith("give") || text3.StartsWith("select") || text3.StartsWith("jump") || text3 == "face" || text3 == "combatstate" || text3 == "fellow")
		{
			MLog("/mt -> /ub " + text2);
			Util.Command("/ub " + text2);
			return true;
		}
		if (text3.StartsWith("drop"))
		{
			bool flag = text3.Substring(4).Contains("p");
			WorldObject worldObject = null;
			foreach (WorldObject item in Globals.Core.WorldFilter.GetInventory())
			{
				string text5 = item.Name ?? "";
				if (flag ? (text5.IndexOf(text4, StringComparison.OrdinalIgnoreCase) >= 0) : string.Equals(text5, text4, StringComparison.OrdinalIgnoreCase))
				{
					worldObject = item;
					break;
				}
			}
			if (worldObject == null)
			{
				MLog("/mt " + text3 + ": no " + text4 + " in the pack");
				return true;
			}
			MLog("/mt " + text3 + ": dropping " + worldObject.Name);
			Globals.Core.Actions.DropItem(worldObject.Id);
			return true;
		}
		if (text3 == "click")
		{
			bool flag2 = !text4.StartsWith("n", StringComparison.OrdinalIgnoreCase);
			if ((DateTime.UtcNow - Remote.LastConfirmUtc).TotalSeconds < 15.0)
			{
				if (flag2)
				{
					Remote.ClickConfirmYes();
				}
				else
				{
					Remote.AnswerConfirm(yes: false);
				}
			}
			else if (flag2)
			{
				Remote.ExpectYes(10.0, null);
			}
			MLog("/mt click " + (flag2 ? "yes" : "no"));
			return true;
		}
		bool flag3 = true;
		return false;
	}

	public bool VtCommand(string cmd)
	{
		string text = cmd.Trim();
		if (!text.StartsWith("/vt ", StringComparison.OrdinalIgnoreCase) && !text.StartsWith("@vt ", StringComparison.OrdinalIgnoreCase))
		{
			return false;
		}
		string text2 = text.Substring(4).Trim();
		string text3 = text2.ToLowerInvariant();
		if (text3.StartsWith("jump"))
		{
			string[] array = text2.Split(new char[1] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
			string text4 = array[0].ToLowerInvariant();
			string text5 = "";
			string text6 = "";
			bool flag = text4.Substring(4).Contains("s");
			for (int i = 1; i < array.Length; i++)
			{
				string text7 = array[i].ToLowerInvariant();
				if (text7 == "true")
				{
					flag = true;
				}
				else if (!(text7 == "false"))
				{
					if (text5.Length == 0 && i == 1)
					{
						text5 = text7;
					}
					else
					{
						text6 = text7;
					}
				}
			}
			string text8 = text4.Substring(4).Replace("s", "");
			if (text8.IndexOfAny(new char[4] { 'w', 'x', 'z', 'c' }) < 0)
			{
				text8 = "w";
			}
			string text9 = "/ub jump" + (flag ? "s" : "") + text8 + ((text5.Length > 0) ? (" " + text5) : "") + ((text6.Length > 0) ? (" " + text6) : "");
			if (text5.Length > 0 && text6.Length == 0)
			{
				text9 += " 0";
			}
			if (UbCmd.Try(text9, ours: true))
			{
				return true;
			}
		}
		if (text3.StartsWith("setmetastate "))
		{
			GoState(text2.Substring(13).Trim());
			return true;
		}
		if (text3.StartsWith("opt set "))
		{
			string[] array2 = text2.Substring(8).Trim().Split(new char[1] { ' ' }, 2);
			OptSet(array2[0], (array2.Length > 1) ? array2[1] : "");
			return true;
		}
		if (text3.StartsWith("nav load "))
		{
			string n = text2.Substring(9).Trim();
			NavRoute navRoute = _s.NavRoutes.Find((NavRoute x) => string.Equals(x.Name, n, StringComparison.OrdinalIgnoreCase));
			if (navRoute == null)
			{
				Util.WriteToChat("Meta: no route called " + n + " (Nav > Routes).");
				return true;
			}
			if (_s.NavEnabled && _s.NavMode == 1 && string.Equals(_s.NavRouteSelected, navRoute.Name, StringComparison.OrdinalIgnoreCase) && _metaRoute == null)
			{
				MLog("route " + navRoute.Name + " already running - left as it is");
				return true;
			}
			_s.NavRouteSelected = navRoute.Name;
			_s.NavMode = 1;
			Stop();
			RouteReset();
			if (SaveAll != null)
			{
				SaveAll();
			}
			return true;
		}
		if (text3.StartsWith("nav spot "))
		{
			string n2 = text2.Substring(9).Trim();
			NavSpot navSpot = _s.NavSpots.Find((NavSpot x) => string.Equals(x.Name, n2, StringComparison.OrdinalIgnoreCase));
			if (navSpot == null)
			{
				Util.WriteToChat("Meta: no spot called " + n2 + " (Nav > Spots).");
				return true;
			}
			_metaRoute = null;
			_s.NavSelected = navSpot.Name;
			_s.NavMode = 0;
			Stop();
			if (SaveAll != null)
			{
				SaveAll();
			}
			MLog("spot " + navSpot.Name);
			return true;
		}
		if (text3.StartsWith("addnavpt"))
		{
			Match match = AddPtRx.Match(text2.Substring(8));
			if (!match.Success)
			{
				MWarn("addnavpt", "couldn't read the coordinates in: " + cmd);
				return true;
			}
			double nS = double.Parse(match.Groups[1].Value, CultureInfo.InvariantCulture) * (double)((!(match.Groups[2].Value.ToUpperInvariant() == "S")) ? 1 : (-1));
			double eW = double.Parse(match.Groups[3].Value, CultureInfo.InvariantCulture) * (double)((!(match.Groups[4].Value.ToUpperInvariant() == "W")) ? 1 : (-1));
			double result = 0.0;
			if (match.Groups[5].Success)
			{
				double.TryParse(match.Groups[5].Value, NumberStyles.Float, CultureInfo.InvariantCulture, out result);
			}
			if (_metaRoute == null || !string.Equals(_s.NavRouteSelected, _metaRoute.Name, StringComparison.Ordinal))
			{
				_metaRoute = new NavRoute
				{
					Name = "[meta] points",
					Mode = 2
				};
				_s.NavRouteSelected = _metaRoute.Name;
			}
			bool flag2 = RouteEmpty();
			_metaRoute.Steps.Add(new RouteStep
			{
				Kind = StepKind.Point,
				NS = nS,
				EW = eW,
				Z = 0.0
			});
			_s.NavMode = 1;
			if (flag2)
			{
				Stop();
				RouteReset();
			}
			MLog("point added " + nS.ToString("0.00") + ", " + eW.ToString("0.00") + " (" + _metaRoute.Steps.Count + " in the route)");
			return true;
		}
		if (text3.StartsWith("mexec "))
		{
			UbExpr.Eval(text2.Substring(6).Trim(), out var error);
			if (error != null)
			{
				MWarn("mexec:" + text2, "expression error in /vt mexec: " + error);
			}
			return true;
		}
		if (text3 == "nav clear")
		{
			_metaRoute = null;
			_s.NavRouteSelected = "";
			Stop();
			RouteReset();
			return true;
		}
		if (text3.StartsWith("meta load "))
		{
			string text10 = text2.Substring(10).Trim();
			string text11 = FindMetaFile(text10);
			if (text11 == null)
			{
				Util.WriteToChat("Meta: no meta called " + text10 + ".");
				return true;
			}
			if (OpenMeta(text11))
			{
				MetaStart();
			}
			return true;
		}
		return false;
	}

	public bool LoadMetaByName(string name)
	{
		string text = FindMetaFile(name);
		return text != null && OpenMeta(text);
	}

	public List<string> MetaNames()
	{
		if (_metaNames != null && (DateTime.Now - _metaNamesAt).TotalSeconds < 30.0)
		{
			return _metaNames;
		}
		_metaNamesAt = DateTime.Now;
		List<string> list = new List<string>();
		try
		{
			string[] files = Directory.GetFiles(MetaDir);
			foreach (string path in files)
			{
				string text = Path.GetExtension(path).ToLowerInvariant();
				if (!(text != ".mtmet") || !(text != ".met"))
				{
					string n = Path.GetFileNameWithoutExtension(path);
					if (!list.Exists((string x) => string.Equals(x, n, StringComparison.OrdinalIgnoreCase)))
					{
						list.Add(n);
					}
				}
			}
		}
		catch
		{
		}
		list.Sort(StringComparer.OrdinalIgnoreCase);
		return _metaNames = list;
	}

	private string FindMetaFile(string name)
	{
		string[] array = new string[2] { MetaDir, VtankDir };
		foreach (string text in array)
		{
			if (string.IsNullOrEmpty(text))
			{
				continue;
			}
			string[] array2 = new string[2] { ".mtmet", ".met" };
			foreach (string text2 in array2)
			{
				string text3 = Path.Combine(text, name + text2);
				if (File.Exists(text3))
				{
					return text3;
				}
			}
		}
		return null;
	}

	private static bool OptTrue(string v)
	{
		v = (v ?? "").Trim();
		return v == "1" || v.Equals("true", StringComparison.OrdinalIgnoreCase) || v.Equals("on", StringComparison.OrdinalIgnoreCase);
	}

	private void OptSet(string opt, string val)
	{
		bool flag = OptTrue(val);
		string text = (opt ?? "").Trim().ToLowerInvariant();
		MLog("option " + opt + " = " + val);
		switch (text)
		{
		case "enablecombat":
			_s.CombatEnabled = flag;
			break;
		case "enablelooting":
			_s.LootEnabled = flag;
			break;
		case "enablebuffing":
			PluginCore.SetBuffingFromUi(flag);
			break;
		case "enablenav":
			if (flag && !_s.NavEnabled && MetaRunning)
			{
				_s.MetaTurnedNavOn = true;
			}
			if (!flag)
			{
				_s.MetaTurnedNavOn = false;
			}
			_s.NavEnabled = flag;
			if (flag && CurrentRoute != null)
			{
				_s.NavMode = 1;
			}
			if (!flag)
			{
				Stop();
			}
			break;
		case "enablemeta":
			if (!flag)
			{
				MetaStop();
			}
			break;
		case "enablesummoning":
			PluginCore.SetSummoningFromNav(flag);
			break;
		case "enabledoors":
		case "opendoors":
			_s.NavOpenDoors = flag;
			break;
		default:
			if (VtOptSet(text, val))
			{
				break;
			}
			_mOpts[opt] = val;
			MWarn("opt:" + text, "option " + opt + " isn't one of MelkTank's switches - noted, not used.");
			return;
		}
		if (SaveAll != null)
		{
			SaveAll();
		}
	}

	private bool VtOptSet(string o, string val)
	{
		bool flag = double.TryParse((val ?? "").Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out var result);
		bool flag2 = OptTrue(val);
		switch (o)
		{
		case "idlepeacemode":
			_s.PeaceWhenIdle = flag2;
			return true;
		case "autostack":
			_s.AutoStack = flag2;
			return true;
		case "lootfellowcorpses":
			_s.LootFellowKills = flag2;
			return true;
		case "refillwornmana":
			_s.ManaTopUp = flag2;
			return true;
		case "summonpets":
			PluginCore.SetSummoningFromNav(flag2);
			return true;
		case "attackdistance":
			if (!flag)
			{
				return false;
			}
			_s.AttackRange = (float)(result * 240.0);
			return true;
		case "ringdistance":
			if (!flag)
			{
				return false;
			}
			_s.RingRadius = (float)(result * 240.0);
			return true;
		case "minimumringtargets":
			if (!flag)
			{
				return false;
			}
			_s.RingMinMonsters = (int)result;
			return true;
		case "debuffeachfirst":
			_s.DebuffAllFirst = (flag ? (result != 0.0) : flag2);
			return true;
		case "corpseapproachrange-min":
			if (!flag)
			{
				return false;
			}
			_s.LootRange = (float)(result * 240.0);
			return true;
		case "dooropenrange":
			if (!flag)
			{
				return false;
			}
			_s.NavDoorRange = (float)(result * 240.0);
			return true;
		case "navclosestoprange":
			if (!flag)
			{
				return false;
			}
			_s.NavCloseDist = (float)(result * 240.0);
			return true;
		case "petcustomrange":
			if (!flag)
			{
				return false;
			}
			_s.PetRange = (float)(result * 240.0);
			return true;
		case "petrangemode":
			_s.PetRangeOverride = (flag ? (result == 1.0) : flag2);
			return true;
		case "refillwornmana-item-manapercent":
			if (!flag)
			{
				return false;
			}
			_s.ManaTopUpPercent = (int)result;
			return true;
		default:
			return false;
		}
	}

	private static string VtNum(double v)
	{
		return v.ToString("0.#####", CultureInfo.InvariantCulture);
	}

	private string VtOptGet(string o)
	{
		return o switch
		{
			"idlepeacemode" => _s.PeaceWhenIdle ? "1" : "0", 
			"autostack" => _s.AutoStack ? "1" : "0", 
			"lootfellowcorpses" => _s.LootFellowKills ? "1" : "0", 
			"refillwornmana" => _s.ManaTopUp ? "1" : "0", 
			"summonpets" => _s.MelksPetEnabled ? "1" : "0", 
			"attackdistance" => VtNum((double)_s.AttackRange / 240.0), 
			"ringdistance" => VtNum((double)_s.RingRadius / 240.0), 
			"minimumringtargets" => _s.RingMinMonsters.ToString(), 
			"debuffeachfirst" => _s.DebuffAllFirst ? "1" : "0", 
			"corpseapproachrange-min" => VtNum((double)_s.LootRange / 240.0), 
			"dooropenrange" => VtNum((double)_s.NavDoorRange / 240.0), 
			"navclosestoprange" => VtNum((double)_s.NavCloseDist / 240.0), 
			"petcustomrange" => VtNum((double)_s.PetRange / 240.0), 
			"petrangemode" => _s.PetRangeOverride ? "1" : "0", 
			"refillwornmana-item-manapercent" => _s.ManaTopUpPercent.ToString(), 
			_ => null, 
		};
	}

	private string OptGet(string opt)
	{
		string text = (opt ?? "").Trim().ToLowerInvariant();
		switch (text)
		{
		case "enablecombat":
			return _s.CombatEnabled ? "1" : "0";
		case "enablelooting":
			return _s.LootEnabled ? "1" : "0";
		case "enablebuffing":
			return _s.MelksBufferEnabled ? "1" : "0";
		case "enablenav":
			return _s.NavEnabled ? "1" : "0";
		case "enablemeta":
			return MetaRunning ? "1" : "0";
		case "enablesummoning":
			return _s.MelksPetEnabled ? "1" : "0";
		case "enabledoors":
			return _s.NavOpenDoors ? "1" : "0";
		default:
		{
			string text2 = VtOptGet(text);
			if (text2 != null)
			{
				return text2;
			}
			string value;
			return _mOpts.TryGetValue(opt ?? "", out value) ? value : "0";
		}
		}
	}

	public void UpdateMetaRoute()
	{
		if (_metaRoute == null || _metaRouteSrc == null || _meta == null)
		{
			Util.WriteToChat("Meta: this route isn't from the open meta.");
			return;
		}
		string text = (_metaRoute.Name.StartsWith("[meta] ", StringComparison.Ordinal) ? _metaRoute.Name.Substring(7) : _metaRoute.Name);
		NavRoute navRoute = EmbeddedMtRoute(Meta.Enc.GetBytes("x\r\n0\r\n" + RouteXml(_metaRoute)));
		if (navRoute != null)
		{
			navRoute.Name = text;
			navRoute.File = "";
			_metaRouteSrc.T = "ba";
			_metaRouteSrc.B = Meta.Enc.GetBytes(SafeName(text) + ".mtnav\r\n" + navRoute.Steps.Count + "\r\n" + RouteXml(navRoute));
			MetaChanged();
			if (!string.IsNullOrEmpty(_meta.File) && _meta.File.EndsWith(".mtmet", StringComparison.OrdinalIgnoreCase))
			{
				SaveMeta(vtank: false);
			}
			Util.WriteToChat("Meta: route " + text + " updated in " + _meta.Name + " (" + navRoute.Steps.Count + " steps)" + (_meta.Dirty ? " - save the meta to keep it." : "."));
		}
	}

	public static WorldObject PackItem(string name)
	{
		if (string.IsNullOrEmpty(name))
		{
			return null;
		}
		WorldObject worldObject = null;
		foreach (WorldObject item in InvCache.All())
		{
			if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
			{
				return item;
			}
			if (worldObject == null && (item.Name ?? "").IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0)
			{
				worldObject = item;
			}
		}
		return worldObject;
	}

	public static WorldObject NearestNamed(string name, int kind)
	{
		if (string.IsNullOrEmpty(name))
		{
			return null;
		}
		WorldObject result = null;
		double num = double.MaxValue;
		bool flag = false;
		foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
		{
			if ((kind == 1 && item.ObjectClass != ObjectClass.Npc && item.ObjectClass != ObjectClass.Vendor) || (kind == 2 && item.ObjectClass != ObjectClass.Portal))
			{
				continue;
			}
			bool flag2 = string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase);
			if (flag2 || (item.Name ?? "").IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0)
			{
				double num2 = CombatEngine.Distance(item);
				if (num2 < 0.0)
				{
					num2 = 9999.0;
				}
				if ((flag2 && !flag) || (flag2 == flag && num2 < num))
				{
					result = item;
					num = num2;
					flag = flag2;
				}
			}
		}
		return result;
	}

	private void UseByName(string name, int kind)
	{
		WorldObject worldObject = ((kind == 0) ? PackItem(name) : NearestNamed(name, kind));
		string text = kind switch
		{
			1 => "NPC", 
			0 => "item", 
			_ => "portal", 
		};
		if (worldObject == null)
		{
			MLog("no " + text + " called " + name);
			Util.WriteToChat("Meta: no " + text + " called " + name + ((kind == 0) ? " in your pack." : " nearby."));
		}
		else
		{
			MLog(((kind == 1) ? "talk to " : "use ") + worldObject.Name);
			Globals.Core.Actions.UseItem(worldObject.Id, 0);
		}
	}

	private void GiveTo(string item, string npc)
	{
		WorldObject worldObject = PackItem(item);
		WorldObject worldObject2 = NearestNamed(npc, 1);
		if (worldObject == null)
		{
			MLog("no item called " + item);
			Util.WriteToChat("Meta: no item called " + item + " in your pack.");
		}
		else if (worldObject2 == null)
		{
			MLog("no NPC called " + npc);
			Util.WriteToChat("Meta: no NPC called " + npc + " nearby.");
		}
		else
		{
			MLog("give " + worldObject.Name + " to " + worldObject2.Name);
			Globals.Core.Actions.GiveItem(worldObject.Id, worldObject2.Id);
		}
	}

	private void LoadEmbedded(MVal src)
	{
		byte[] array = src?.B;
		NavRoute navRoute = null;
		MetaText.NavSummary(array, out var name, out var points);
		if (array == null || array.Length == 0 || points == 0)
		{
			_metaRoute = null;
			if (_s.NavRouteSelected.StartsWith("[meta] ", StringComparison.Ordinal))
			{
				_s.NavRouteSelected = "";
			}
			Stop();
			RouteReset();
			MLog("route cleared");
			return;
		}
		if (IsMtRoute(array))
		{
			navRoute = EmbeddedMtRoute(array);
		}
		else
		{
			try
			{
				string text = Meta.Enc.GetString(array);
				int startIndex = text.IndexOf("uTank2 NAV", StringComparison.OrdinalIgnoreCase);
				string path = Path.Combine(Path.GetTempPath(), "mt_metanav.nav");
				File.WriteAllText(path, text.Substring(startIndex), Meta.Enc);
				navRoute = ImportNav(path);
				try
				{
					File.Delete(path);
				}
				catch
				{
				}
			}
			catch (Exception ex)
			{
				Util.WriteToChat("Meta: couldn't load the embedded route: " + ex.Message);
			}
		}
		if (navRoute != null)
		{
			string text2;
			if (name.Length > 0)
			{
				text2 = Path.GetFileNameWithoutExtension(name);
			}
			else
			{
				text2 = ((navRoute.Name.Length > 0) ? navRoute.Name : "route");
			}
			navRoute.Name = "[meta] " + text2;
			navRoute.File = "";
			_metaRoute = navRoute;
			_metaRouteSrc = src;
			_s.NavRouteSelected = navRoute.Name;
			_s.NavMode = 1;
			Stop();
			RouteReset();
			MLog("route " + text2 + " loaded (" + navRoute.Steps.Count + " steps)");
		}
	}

	public Nav(Settings s)
	{
		_s = s;
		Status = "";
		_resumeNearest = s.NavEnabled && s.NavMode == 1;
	}

	private static bool MyPos(out double ns, out double ew, out double z)
	{
		ns = (ew = (z = 0.0));
		double num = 0.0;
		double num2 = 0.0;
		double num3 = 0.0;
		bool flag = false;
		try
		{
			WorldObject worldObject = Globals.Core.WorldFilter[Globals.Core.CharacterFilter.Id];
			CoordsObject coordsObject = worldObject?.Coordinates();
			if (coordsObject != null)
			{
				num = coordsObject.NorthSouth;
				num2 = coordsObject.EastWest;
				num3 = worldObject.RawCoordinates().Z;
				flag = true;
			}
		}
		catch
		{
		}
		try
		{
			uint landcell = (uint)Globals.Core.Actions.Landcell;
			double locationX = Globals.Core.Actions.LocationX;
			double locationY = Globals.Core.Actions.LocationY;
			double locationZ = Globals.Core.Actions.LocationZ;
			if (landcell != 0 && !double.IsNaN(locationX) && !double.IsNaN(locationY))
			{
				double num4 = ((double)((landcell >> 24) & 0xFF) * 192.0 + locationX - 24468.0) / 240.0;
				double num5 = ((double)((landcell >> 16) & 0xFF) * 192.0 + locationY - 24468.0) / 240.0;
				if (!flag || (Math.Abs(num4 - num2) * 240.0 < 40.0 && Math.Abs(num5 - num) * 240.0 < 40.0))
				{
					ns = num5;
					ew = num4;
					z = locationZ;
					_liveOk = true;
					if (flag)
					{
						LiveDiff = Math.Sqrt(Math.Pow((num5 - num) * 240.0, 2.0) + Math.Pow((num4 - num2) * 240.0, 2.0));
					}
					return true;
				}
				if (!_liveWarned & flag)
				{
					_liveWarned = true;
					Util.WriteToChat("Nav: the live position doesn't match (" + ((num5 - num) * 240.0).ToString("0") + " m, " + ((num4 - num2) * 240.0).ToString("0") + " m off) - using the slower server position.");
				}
			}
		}
		catch
		{
		}
		if (!flag)
		{
			return false;
		}
		ns = num;
		ew = num2;
		z = num3;
		return true;
	}

	public double DistanceTo(NavSpot p)
	{
		if (p == null || !MyPos(out var ns, out var ew, out var _))
		{
			return -1.0;
		}
		double num = (p.NS - ns) * 240.0;
		double num2 = (p.EW - ew) * 240.0;
		return Math.Sqrt(num * num + num2 * num2);
	}

	private double BearingTo(NavSpot p)
	{
		if (!MyPos(out var ns, out var ew, out var _))
		{
			return 0.0;
		}
		double num = Math.Atan2(p.EW - ew, p.NS - ns) * 180.0 / Math.PI;
		return (num + 360.0) % 360.0;
	}

	public void Stop()
	{
		ReleaseTurn();
		if (!_running)
		{
			return;
		}
		_running = false;
		_moving = false;
		_pulsing = false;
		_pulseOnUntil = (_pulseOffUntil = DateTime.MinValue);
		_restartStage = 0;
		_kicks = 0;
		try
		{
			Globals.Core.Actions.SetAutorun(on: false);
		}
		catch
		{
		}
	}

	private bool Active(out NavSpot p)
	{
		p = (_s.NavEnabled ? Current : null);
		return p != null && DateTime.Now >= _pauseUntil;
	}

	public bool PriorityTick()
	{
		if (_s.NavMode != 0)
		{
			return false;
		}
		if (!_s.NavPriority || !Active(out var p))
		{
			return false;
		}
		if (TooFar(p))
		{
			return false;
		}
		return ReturnTick(p);
	}

	public bool IdleTick()
	{
		RestoreHotState();
		if (_s.NavMode == 1)
		{
			return RouteTick();
		}
		if (_s.NavMode == 2)
		{
			return FollowTick();
		}
		if (!Active(out var p))
		{
			Stop();
			return false;
		}
		if (TooFar(p))
		{
			return false;
		}
		if (ReturnTick(p))
		{
			return true;
		}
		if (p.FaceHeading && p.Heading >= 0.0 && (DateTime.Now - _lastHeadingFix).TotalSeconds >= 2.0)
		{
			double num = CombatEngine.MyHeading();
			double num2 = ((num < 0.0) ? 0.0 : Math.Abs(((p.Heading - num) % 360.0 + 540.0) % 360.0 - 180.0));
			if (num2 > 5.0)
			{
				_lastHeadingFix = DateTime.Now;
				try
				{
					Globals.Core.Actions.FaceHeading(p.Heading, true);
				}
				catch
				{
				}
				Status = "Facing " + p.Heading.ToString("0") + " at " + p.Name;
				return true;
			}
		}
		return false;
	}

	private bool TooFar(NavSpot p)
	{
		double num = DistanceTo(p);
		if (num < 0.0 || num <= (double)Math.Max(100f, _s.NavMaxRunM))
		{
			_tooFarNoted = null;
			return false;
		}
		if (p.Name != null && p.Name.StartsWith("Map route #", StringComparison.OrdinalIgnoreCase))
		{
			_tooFarNoted = null;
			return false;
		}
		Stop();
		string text = ((num >= 1000.0) ? ((num / 1000.0).ToString("0.0") + " km") : (num.ToString("0") + " m"));
		Status = p.Name + " is " + text + " away - not here, waiting";
		if (_tooFarNoted != p.Name)
		{
			_tooFarNoted = p.Name;
			L("too far: " + p.Name + " is " + num.ToString("0") + " m away - not running there");
			Util.WriteToChat("Nav: " + p.Name + " is " + text + " away - you're not where it is, so Nav waits (it carries on once you're back within " + Math.Max(100f, _s.NavMaxRunM).ToString("0") + " m).");
		}
		return true;
	}

	private void L(string s)
	{
		if (Log != null)
		{
			Log("NAV   " + s);
		}
	}

	/// <summary>Runs toward a monster (combat's approach range) until it's within <paramref name="stopAt"/> metres: true
	/// while running there, false once close (stopped) or when it can't be read.</summary>
	public bool ApproachTick(WorldObject mob, double stopAt)
	{
		CoordsObject c = null;
		double z = 0.0;
		try
		{
			c = mob?.Coordinates();
			z = mob.RawCoordinates().Z;
		}
		catch
		{
		}
		if (c == null)
		{
			return false;
		}
		NavSpot spot = new NavSpot
		{
			Name = mob.Name,
			NS = c.NorthSouth,
			EW = c.EastWest,
			Z = z,
			Heading = -1.0,
			FaceHeading = false
		};
		if (_approachId != mob.Id)
		{
			_approachId = mob.Id;
			_retarget = true;
		}
		return ReturnTick(spot, stopAt, stopAt, precise: true);
	}

	private int _approachId;

	private bool ReturnTick(NavSpot p)
	{
		return ReturnTick(p, _s.NavDrift, Math.Min(0.7, (double)_s.NavDrift * 0.5), precise: true);
	}

	private bool ReturnTick(NavSpot p, double startDist, double arrive, bool precise)
	{
		double num = DistanceTo(p);
		if (num < 0.0)
		{
			Stop();
			return false;
		}
		if (_running && (DateTime.Now - _lastReturnTick).TotalSeconds > 1.0)
		{
			L("resumed after " + (DateTime.Now - _lastReturnTick).TotalSeconds.ToString("0.0") + "s away, " + num.ToString("0.0") + " m");
			_lastProgressAt = DateTime.Now;
			_bestDist = num;
			_kickBest = num;
			_kickAt = DateTime.Now;
		}
		_lastReturnTick = DateTime.Now;
		if (_retarget)
		{
			_retarget = false;
			_kickBest = num;
			_kickAt = DateTime.Now;
			_bestDist = num;
			_lastProgressAt = (_runStart = DateTime.Now);
			_lastFace = DateTime.MinValue;
		}
		if (!_running)
		{
			if (num <= startDist)
			{
				return false;
			}
			_running = true;
			_moving = false;
			_runStart = (_lastProgressAt = (_turnStart = DateTime.Now));
			_bestDist = num;
			_lastFace = DateTime.MinValue;
			_warnedDir = false;
			L("return to " + p.Name + " from " + num.ToString("0.0") + " m" + (_liveOk ? (" (live pos, " + LiveDiff.ToString("0.0") + " m from server pos)") : " (server pos)"));
		}
		if (num <= arrive)
		{
			L("arrived, " + num.ToString("0.0") + " m");
			if (precise)
			{
				Stop();
			}
			Status = "At " + p.Name;
			return false;
		}
		double num2 = BearingTo(p);
		double num3 = CombatEngine.MyHeading();
		double num4 = ((num3 < 0.0) ? 0.0 : AngleDiff(num2, num3));
		if (!_moving)
		{
			if ((DateTime.Now - _lastFace).TotalMilliseconds >= Tuning.V("FaceEveryMs"))
			{
				_lastFace = DateTime.Now;
				try
				{
					Globals.Core.Actions.FaceHeading(num2, true);
				}
				catch
				{
				}
			}
			if (num4 <= Tuning.V("FacingOkDeg") || (DateTime.Now - _turnStart).TotalSeconds > Tuning.V("TurnMaxS"))
			{
				_moving = true;
				_kickBest = num;
				_kickAt = DateTime.Now;
				_lastProgressAt = DateTime.Now;
				_bestDist = num;
				MyPos(out _startNS, out _startEW, out _startZ);
				_startHeading = num3;
				L("running, " + num.ToString("0.0") + " m, off by " + num4.ToString("0") + " deg");
				_restartStage = 0;
				_kicks = 0;
				if (num > PulseRange)
				{
					try
					{
						Globals.Core.Actions.SetAutorun(on: false);
					}
					catch
					{
					}
					AutorunOn();
				}
			}
			Status = "Turning to " + p.Name + " (" + num.ToString("0.0") + " m)";
			return true;
		}
		if (num4 > (double)(precise ? 30f : _s.NavTurnAngle))
		{
			L("off course by " + num4.ToString("0") + " deg at " + num.ToString("0.0") + " m - stop and turn");
			ReleaseTurn();
			_restartStage = 0;
			_kicks = 0;
			try
			{
				Globals.Core.Actions.SetAutorun(on: false);
			}
			catch
			{
			}
			_moving = false;
			_turnStart = DateTime.Now;
			Status = "Turning to " + p.Name + " (" + num.ToString("0.0") + " m)";
			return true;
		}
		DateTime now = DateTime.Now;
		bool flag = !_pulsing && (!precise || num > PulseRange);
		if (KeySteer & flag)
		{
			WantHeading(num2);
			_lastDirectSteer = now;
		}
		else if ((!KeySteer & flag) && num4 > Tuning.V("SteerDeg") && _restartStage == 0 && (now - _lastFace).TotalMilliseconds >= Tuning.V("SteerEveryMs"))
		{
			_lastFace = now;
			try
			{
				Globals.Core.Actions.FaceHeading(num2, true);
			}
			catch
			{
			}
			_restartStage = 1;
			_restartAt = now.AddMilliseconds(Tuning.V("TurnSettleMs"));
		}
		if (_restartStage == 1 && now >= _restartAt)
		{
			try
			{
				Globals.Core.Actions.SetAutorun(on: false);
			}
			catch
			{
			}
			_restartStage = 2;
			_restartAt = now.AddMilliseconds(Tuning.V("AutorunGapMs"));
		}
		else if (_restartStage == 2 && now >= _restartAt)
		{
			if (flag)
			{
				AutorunOn();
			}
			_restartStage = 0;
			_kickBest = num;
			_kickAt = now;
		}
		if (flag && _restartStage == 0)
		{
			if (num < _kickBest - 0.2)
			{
				_kickBest = num;
				_kickAt = now;
				_kicks = 0;
			}
			else if ((now - _kickAt).TotalMilliseconds > Tuning.V("NotMovingMs"))
			{
				_kicks++;
				if (_kicks > 3)
				{
					L("not moving at " + num.ToString("0.0") + " m - stop and turn");
					try
					{
						Globals.Core.Actions.SetAutorun(on: false);
					}
					catch
					{
					}
					_moving = false;
					_turnStart = now;
					_kicks = 0;
					Status = "Turning to " + p.Name + " (" + num.ToString("0.0") + " m)";
					return true;
				}
				L("not moving at " + num.ToString("0.0") + " m - restarting the run (" + _kicks + ")" + ((_s.NavSmoothSteer && (now - _lastDirectSteer).TotalSeconds < 2.0) ? " [right after a direct steer]" : ""));
				_restartStage = 1;
				_restartAt = now;
				_kickAt = now;
				_kickBest = num;
			}
		}
		if (precise && num <= PulseRange)
		{
			DateTime now2 = DateTime.Now;
			if (num < _bestDist - 0.1)
			{
				_bestDist = num;
				_lastProgressAt = now2;
			}
			if (!_pulsing)
			{
				_pulsing = true;
				try
				{
					Globals.Core.Actions.SetAutorun(on: false);
				}
				catch
				{
				}
				_pulseOnUntil = DateTime.MinValue;
				_pulseOffUntil = now2.AddMilliseconds(Tuning.V("PulseOffMs"));
			}
			else if (_pulseOnUntil != DateTime.MinValue)
			{
				if (now2 >= _pulseOnUntil)
				{
					try
					{
						Globals.Core.Actions.SetAutorun(on: false);
					}
					catch
					{
					}
					_pulseOnUntil = DateTime.MinValue;
					_pulseOffUntil = now2.AddMilliseconds(Tuning.V("PulseOffMs"));
				}
			}
			else if (now2 >= _pulseOffUntil && num4 <= 15.0)
			{
				AutorunOn();
				_pulseOnUntil = now2.AddMilliseconds(Tuning.V("PulseBaseMs") + Tuning.V("PulsePerMMs") * num);
			}
			Status = "Stepping to " + p.Name + " (" + num.ToString("0.0") + " m)";
			if (OpenDoorsNow && (now2 - _lastProgressAt).TotalSeconds > 1.5 && DoorInTheWay())
			{
				_lastProgressAt = now2;
				_pauseUntil = now2.AddSeconds(1.5);
				return true;
			}
			if ((now2 - _lastProgressAt).TotalSeconds > Tuning.V("StepStuckS"))
			{
				StuckEvents++;
				L("stuck stepping at " + num.ToString("0.0") + " m");
				Stop();
				_pauseUntil = now2.AddSeconds(Tuning.V("StuckPauseS"));
				Status = "Can't get closer to " + p.Name;
			}
			return true;
		}
		if (_pulsing)
		{
			_pulsing = false;
			_pulseOnUntil = DateTime.MinValue;
			AutorunOn();
		}
		if (!_warnedDir && MyPos(out var ns, out var ew, out var _))
		{
			double num5 = (ns - _startNS) * 240.0;
			double num6 = (ew - _startEW) * 240.0;
			if (Math.Sqrt(num5 * num5 + num6 * num6) >= 2.0)
			{
				double a = (Math.Atan2(num6, num5) * 180.0 / Math.PI + 360.0) % 360.0;
				if (AngleDiff(a, _startHeading) > 45.0)
				{
					Util.WriteToChat("Nav: facing " + _startHeading.ToString("0") + " but moving toward " + a.ToString("0") + " (spot is at " + num2.ToString("0") + ") - tell Claude these numbers.");
				}
				_warnedDir = true;
			}
		}
		if (num < _bestDist - 0.3)
		{
			_bestDist = num;
			_lastProgressAt = DateTime.Now;
		}
		bool flag2 = p.Name != null && p.Name.StartsWith("Map route #", StringComparison.OrdinalIgnoreCase);
		if (flag2 && MyPos(out var ns2, out var ew2, out var _))
		{
			double num7 = Math.Sqrt(Math.Pow((ns2 - _mapLastNS) * 240.0, 2.0) + Math.Pow((ew2 - _mapLastEW) * 240.0, 2.0));
			if (num7 >= 0.5)
			{
				if (num < _mapLastD + 0.2)
				{
					_lastProgressAt = DateTime.Now;
				}
				_mapLastNS = ns2;
				_mapLastEW = ew2;
				_mapLastD = num;
			}
		}
		if (OpenDoorsNow && (DateTime.Now - _lastProgressAt).TotalSeconds > 1.5 && DoorInTheWay())
		{
			Stop();
			_lastProgressAt = DateTime.Now;
			_pauseUntil = DateTime.Now.AddSeconds(1.5);
			return true;
		}
		if ((DateTime.Now - _lastProgressAt).TotalSeconds > Tuning.V("StuckS") || (!flag2 && (DateTime.Now - _runStart).TotalSeconds > Tuning.V("MaxRunS")))
		{
			StuckEvents++;
			Stop();
			_pauseUntil = DateTime.Now.AddSeconds(Tuning.V("StuckPauseS"));
			L("stuck: " + num.ToString("0.0") + " m, best " + _bestDist.ToString("0.0") + " m, no progress " + (DateTime.Now - _lastProgressAt).TotalSeconds.ToString("0.0") + "s, running " + (DateTime.Now - _runStart).TotalSeconds.ToString("0") + "s, moving " + _moving + ", pulsing " + _pulsing);
			Util.WriteToChat("Nav: can't get back to " + p.Name + " (" + num.ToString("0.0") + " m away) - trying again in 30 s.");
			Status = "Stuck - " + num.ToString("0.0") + " m from " + p.Name;
			return false;
		}
		Status = "Returning to " + p.Name + " (" + num.ToString("0.0") + " m)";
		return true;
	}

	private static double AngleDiff(double a, double b)
	{
		return Math.Abs(((a - b) % 360.0 + 540.0) % 360.0 - 180.0);
	}

	public void UpdateMarkers()
	{
		DateTime now = DateTime.Now;
		if ((now - _markersAt).TotalMilliseconds < 100.0)
		{
			return;
		}
		_markersAt = now;
		try
		{
			RemoveLeftovers();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		try
		{
			StuckRestartTick();
		}
		catch (Exception ex2)
		{
			Util.LogError(ex2);
		}
		try
		{
			TravelTick();
		}
		catch (Exception ex3)
		{
			Util.LogError(ex3);
		}
		try
		{
			UpdateRouteMarkers();
		}
		catch (Exception ex4)
		{
			Util.LogError(ex4);
		}
		try
		{
			PublishMapRoute(now: false);
		}
		catch
		{
		}
		try
		{
			MarkerTestTick();
		}
		catch (Exception ex5)
		{
			Util.LogError(ex5);
		}
		try
		{
			UpdateFollowMarkers();
		}
		catch (Exception ex6)
		{
			Util.LogError(ex6);
		}
		if (_s.NavMode == 2)
		{
			if (_drawnKey != "")
			{
				ClearMarkers();
				_drawnKey = "";
			}
			return;
		}
		bool flag = _s.NavMode == 1;
		NavSpot navSpot;
		if (flag)
		{
			navSpot = (_s.NavEnabled ? RouteTarget() : null);
		}
		else
		{
			navSpot = Current;
		}
		bool flag2 = (flag ? _s.NavRouteShowNext : _s.NavShowMarker);
		bool flag3 = (flag ? _s.NavRouteArrow : _s.NavArrow);
		string text = ((navSpot == null) ? "" : (navSpot.Name + "|" + navSpot.NS + "|" + navSpot.EW + "|" + navSpot.Z + "|" + _s.NavDrift + "|" + flag2 + "|" + flag3 + "|" + flag));
		if (text == _drawnKey)
		{
			if (navSpot != null && (DateTime.Now - _labelCheck).TotalMilliseconds >= 250.0)
			{
				_labelCheck = DateTime.Now;
				bool flag4 = !_s.NavHideUnfocused || GameFocused();
				SetVisible(_ring, flag4);
				SetVisible(_arrow, flag4);
				if (_label != null)
				{
					double num = DistanceTo(navSpot);
					SetVisible(_label, flag4 && (num < 0.0 || num > (double)_s.NavDrift));
				}
			}
			return;
		}
		_drawnKey = text;
		_labelCheck = DateTime.MinValue;
		ClearMarkers();
		if (navSpot == null)
		{
			return;
		}
		try
		{
			D3DService d3DService = Globals.Core.D3DService;
			if (flag2)
			{
				_ring = d3DService.MarkCoordsWithShape((float)navSpot.NS, (float)navSpot.EW, (float)navSpot.Z + 0.05f, D3DShape.Ring, -13382401);
				if (_ring != null)
				{
					D3DObj ring = _ring;
					double val;
					if (flag)
					{
						val = ((CurrentRoute != null) ? ((double)CurrentRoute.Arrive) : 2.5);
					}
					else
					{
						val = _s.NavDrift;
					}
					ring.Scale((float)Math.Max(0.5, val));
				}
				_label = d3DService.MarkCoordsWith3DText((float)navSpot.NS, (float)navSpot.EW, (float)navSpot.Z + 1.6f, navSpot.Name, "Arial", 0);
				if (_label != null)
				{
					_label.Color = -13382401;
					_label.Scale(0.4f);
					_label.OrientToCamera(true);
				}
			}
			if (flag3)
			{
				_arrow = d3DService.PointToCoords((float)navSpot.NS, (float)navSpot.EW, (float)navSpot.Z, -13261);
			}
		}
		catch (Exception ex7)
		{
			Util.LogError(ex7);
		}
	}

	public void MarkerTest()
	{
		if (!MyPos(out var _, out var _, out var _))
		{
			Util.WriteToChat("Marker test: position not known yet.");
			return;
		}
		try
		{
			_test = Globals.Core.D3DService.MarkObjectWithShape(Globals.Core.CharacterFilter.Id, D3DShape.Ring, -52225);
			if (_test != null)
			{
				_test.Scale(1.5f);
			}
			_testAt = DateTime.Now;
			_testStage = 1;
			Util.WriteToChat("Marker test: a pink ring on you for 60 s, then hidden for 60 s, then removed.");
			L("markertest: ring made (" + ((_test == null) ? "null!" : _test.GetType().FullName) + ")");
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Marker test: couldn't make one: " + ex.Message);
		}
	}

	private void MarkerTestTick()
	{
		if (_testStage == 0 || _test == null)
		{
			return;
		}
		double totalSeconds = (DateTime.Now - _testAt).TotalSeconds;
		if (_testStage == 1 && totalSeconds >= 60.0)
		{
			_testStage = 2;
			string text;
			try
			{
				_test.Visible = false;
				text = "hidden - Visible now reads " + _test.Visible;
			}
			catch (Exception ex)
			{
				text = "hide failed: " + ex.GetType().Name + " " + ex.Message;
			}
			L("markertest: " + text);
			Util.WriteToChat("Marker test: " + text + ". Is the pink ring gone?");
		}
		else if (_testStage == 2 && totalSeconds >= 120.0)
		{
			_testStage = 0;
			string text2;
			try
			{
				((IDisposable)_test)?.Dispose();
				text2 = "removed";
			}
			catch (Exception ex2)
			{
				text2 = "remove failed: " + ex2.GetType().Name + " " + ex2.Message;
			}
			_test = null;
			L("markertest: " + text2);
		}
	}

	private static void SetVisible(D3DObj o, bool show)
	{
		if (o == null)
		{
			return;
		}
		try
		{
			if (o.Visible != show)
			{
				o.Visible = show;
			}
		}
		catch (Exception ex)
		{
			_visFails++;
			if (_visFirst == null)
			{
				_visFirst = ex.GetType().Name + " " + ex.Message;
			}
		}
	}

	private void NoteFocus(bool focused, int objs)
	{
		if (_lastFocused == focused && _visFails == 0)
		{
			return;
		}
		if (_lastFocused != focused)
		{
			uint pid = 0u;
			try
			{
				GetWindowThreadProcessId(GetForegroundWindow(), out pid);
			}
			catch
			{
			}
			L("game window " + (focused ? "active" : "not active") + " (foreground pid " + pid + ", ours " + Process.GetCurrentProcess().Id + ") - " + (focused ? "showing " : "hiding ") + objs + " markers");
		}
		if (_visFails > 0)
		{
			L("marker show/hide failed " + _visFails + "x: " + _visFirst);
			_visFails = 0;
			_visFirst = null;
		}
		_lastFocused = focused;
	}

	[DllImport("user32.dll")]
	private static extern nint GetForegroundWindow();

	[DllImport("user32.dll")]
	private static extern uint GetWindowThreadProcessId(nint hWnd, out uint pid);

#if RETAIL
	private static bool GameFocused()
	{
		try
		{
			IntPtr foregroundWindow = GetForegroundWindow();
			if (foregroundWindow == IntPtr.Zero)
			{
				return false;
			}
			GetWindowThreadProcessId(foregroundWindow, out var pid);
			return pid == (uint)Process.GetCurrentProcess().Id;
		}
		catch
		{
			return true;
		}
	}
#else
	private static bool GameFocused()
	{
		try
		{
			return DisplayServer.WindowIsFocused();
		}
		catch
		{
			return true;
		}
	}
#endif

	public void ClearMarkers()
	{
		D3DObj[] array = new D3DObj[3] { _ring, _label, _arrow };
		foreach (D3DObj d3DObj in array)
		{
			if (d3DObj != null)
			{
				try
				{
					d3DObj.Visible = false;
				}
				catch (Exception ex)
				{
					L("marker hide failed: " + ex.GetType().Name + " " + ex.Message);
				}
				try
				{
					d3DObj.Scale(0.0001f);
				}
				catch
				{
				}
				try
				{
					((IDisposable)d3DObj)?.Dispose();
				}
				catch (Exception ex2)
				{
					L("marker dispose failed: " + ex2.GetType().Name + " " + ex2.Message);
				}
			}
		}
		_ring = (_label = (_arrow = null));
	}

	public void Dispose()
	{
		if (PluginCore.HotReloading)
		{
			SaveHotState();
		}
		try
		{
			TravelStop("MelkTank is closing", finished: false);
		}
		catch
		{
		}
		DisposeTools();
		try
		{
			SaveRouteFiles(now: true);
		}
		catch
		{
		}
		Stop();
		if (PluginCore.HotReloading)
		{
			List<object> list = new List<object>();
			D3DObj[] array = new D3DObj[6] { _ring, _label, _arrow, _fRing, _fArrow, _test };
			foreach (D3DObj d3DObj in array)
			{
				if (d3DObj != null)
				{
					list.Add(d3DObj);
				}
			}
			foreach (D3DObj routeObj in _routeObjs)
			{
				list.Add(routeObj);
			}
			try
			{
				List<object> list2 = AppDomain.CurrentDomain.GetData("MelkTank.D3DLeftovers") as List<object>;
				if (list2 == null)
				{
					list2 = new List<object>();
					AppDomain.CurrentDomain.SetData("MelkTank.D3DLeftovers", list2);
				}
				list2.AddRange(list);
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
			L("nav shutting down for a build swap: " + list.Count + " markers handed to the next build to remove");
			_ring = (_label = (_arrow = (_fRing = (_fArrow = (_test = null)))));
			_routeObjs.Clear();
			_testStage = 0;
		}
		else
		{
			L("nav shutting down (logout): clearing its markers");
			ClearMarkers();
			ClearRouteMarkers();
			ClearFollowMarkers();
		}
		_drawnKey = "";
		_routeKey = "";
		_fMarkKey = "";
	}

	private void RemoveLeftovers()
	{
		List<object> list;
		try
		{
			list = AppDomain.CurrentDomain.GetData("MelkTank.D3DLeftovers") as List<object>;
		}
		catch
		{
			return;
		}
		if (list == null || list.Count == 0)
		{
			return;
		}
		AppDomain.CurrentDomain.SetData("MelkTank.D3DLeftovers", null);
		int num = 0;
		int num2 = 0;
		string text = null;
		foreach (object item in list)
		{
			if (!(item is D3DObj d3DObj))
			{
				num2++;
				if (text == null)
				{
					text = "not a D3DObj: " + ((item == null) ? "null" : item.GetType().AssemblyQualifiedName);
				}
				continue;
			}
			try
			{
				d3DObj.Visible = false;
			}
			catch (Exception ex)
			{
				num2++;
				if (text == null)
				{
					text = ex.GetType().Name + " " + ex.Message;
				}
			}
			try
			{
				d3DObj.Scale(0.0001f);
			}
			catch
			{
			}
			try
			{
				d3DObj.Dispose();
			}
			catch
			{
			}
			num++;
		}
		L("removed " + num + " markers left by the previous build" + ((num2 > 0) ? (" - " + num2 + " failed (" + text + ")") : ""));
	}

	public void Draw()
	{
		SaveRouteFiles(now: false);
		if (ImGui.BeginTabBar("navtabs"))
		{
			if (ImGui.BeginTabItem("Routes"))
			{
				DrawRoutesTab();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Presets###navpresetstab"))
			{
				DrawPresetsTab();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Meta###navmetatab"))
			{
				DrawMetaTab();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Locations"))
			{
				Locations.DrawTab();
				ImGui.EndTabItem();
			}
			if (DrawPortals != null && ImGui.BeginTabItem("Portals"))
			{
				DrawPortals();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Settings###navsettingstab"))
			{
				DrawSettingsTab();
				ImGui.EndTabItem();
			}
			ImGui.EndTabBar();
		}
	}

	private void DrawSettingsTab()
	{
		bool flag = false;
		if (ImGui.CollapsingHeader("Shown in the world###navshown", ImGuiTreeNodeFlags.DefaultOpen))
		{
			flag |= ImGui.Checkbox("Route: show the whole route", ref _s.NavRouteShowAll);
			Tip("Every point (a ring and its number) and dotted lines between them, in the world.\n/mt set NavRouteShowAll on|off");
			ImGui.SameLine(0f, 20f);
			flag |= ImGui.Checkbox("Route: show the next step", ref _s.NavRouteShowNext);
			Tip("A ring and the step's name on the point (or portal / NPC) it's heading for.\n/mt set NavRouteShowNext on|off");
			ImGui.SameLine(0f, 20f);
			flag |= ImGui.Checkbox("Route: arrow to the next step", ref _s.NavRouteArrow);
			Im.SetTooltipIfHovered("/mt set NavRouteArrow on|off");
			flag |= ImGui.Checkbox("Spot: show it in the world", ref _s.NavShowMarker);
			Tip("A ring the size of the drift allowed, with the spot's name above it.\n/mt set NavShowMarker on|off");
			ImGui.SameLine(0f, 20f);
			flag |= ImGui.Checkbox("Spot: arrow pointing to it", ref _s.NavArrow);
			Im.SetTooltipIfHovered("/mt set NavArrow on|off");
			flag |= ImGui.Checkbox("Hide them while the game isn't the active window##navhide", ref _s.NavHideUnfocused);
			Tip("Like UtilityBelt's video patch: the rings, names and arrows aren't drawn while you're in another window\n(or another client), and come back when you switch to this one.\n/mt set NavHideUnfocused on|off");
		}
		if (ImGui.CollapsingHeader("Nav settings###navsettings", ImGuiTreeNodeFlags.DefaultOpen))
		{
			flag |= DrawNavSettings();
		}
		if (ImGui.CollapsingHeader("Meta settings###metasettings", ImGuiTreeNodeFlags.DefaultOpen))
		{
			flag |= DrawMetaSettings();
		}
		if (ImGui.CollapsingHeader("Route files###navfiles"))
		{
			flag |= DrawRouteFiles((_s.NavMode == 1) ? CurrentRoute : null);
		}
		if (ImGui.CollapsingHeader("Meta files###metafiles"))
		{
			flag |= DrawMetaFiles();
		}
		if (flag && SaveAll != null)
		{
			SaveAll();
		}
	}

	private void DrawRoutesTab()
	{
		bool flag = false;
		int current_item = _s.NavMode;
		ImGui.SetNextItemWidth(170f);
		if (ImGui.Combo("Nav mode##navmode", ref current_item, new string[3] { "Stay on a spot", "Follow a route", "Follow a player" }, 3))
		{
			_s.NavMode = current_item;
			Stop();
			RouteReset();
			flag = true;
		}
		Tip("Stay on a spot: run back to one saved spot.\nFollow a route: walk a list of points, commands, portals / NPCs, waits - once, back and forth, or round and round.");
		if (_s.NavMode == 2)
		{
			if ((flag | DrawFollow()) && SaveAll != null)
			{
				SaveAll();
			}
			return;
		}
		if (_s.NavMode == 1)
		{
			flag |= DrawRoute();
			if (flag)
			{
				RouteChanged();
			}
			if (flag && SaveAll != null)
			{
				SaveAll();
			}
			return;
		}
		NavSpot current = Current;
		List<string> list = new List<string>();
		foreach (NavSpot navSpot2 in _s.NavSpots)
		{
			list.Add(navSpot2.Name);
		}
		int num = list.FindIndex((string a) => string.Equals(a, _s.NavSelected, StringComparison.OrdinalIgnoreCase));
		string[] array = ((list.Count != 0) ? list.ToArray() : new string[1] { "(no spots yet)" });
		int current_item2 = ((num >= 0) ? num : 0);
		ImGui.SetNextItemWidth(220f);
		if (ImGui.Combo("Spot##navspot", ref current_item2, array, array.Length) && list.Count > 0)
		{
			_s.NavSelected = list[current_item2];
			flag = true;
			_lastHeadingFix = DateTime.MinValue;
		}
		ImGui.SameLine();
		if (current != null && ImGui.Button("Delete##navdel"))
		{
			_s.NavSpots.Remove(current);
			_s.NavSelected = ((_s.NavSpots.Count > 0) ? _s.NavSpots[0].Name : "");
			Stop();
			flag = true;
			current = Current;
		}
		ImGui.SetNextItemWidth(220f);
		ImGui.InputText("Name##navname", ref _newName, 64u);
		ImGui.SameLine();
		if (ImGui.Button("Save spot here"))
		{
			string n;
			if (_newName.Trim().Length > 0)
			{
				n = _newName.Trim();
			}
			else
			{
				n = ((current != null) ? current.Name : ("Spot " + (_s.NavSpots.Count + 1)));
			}
			if (!MyPos(out var ns, out var ew, out var z))
			{
				Util.WriteToChat("Nav: couldn't read your position.");
			}
			else
			{
				NavSpot navSpot = _s.NavSpots.Find((NavSpot x) => string.Equals(x.Name, n, StringComparison.OrdinalIgnoreCase));
				if (navSpot == null)
				{
					navSpot = new NavSpot
					{
						Name = n,
						FaceHeading = _s.NavFaceHeading
					};
					_s.NavSpots.Add(navSpot);
				}
				navSpot.NS = ns;
				navSpot.EW = ew;
				navSpot.Z = z;
				navSpot.Heading = CombatEngine.MyHeading();
				_s.NavSelected = n;
				_newName = "";
				flag = true;
				Util.WriteToChat("Nav: saved '" + n + "' here (" + Loc(navSpot) + ", facing " + navSpot.Heading.ToString("0") + ").");
			}
		}
		Tip("Saves where you're standing and the way you're facing. Type a name for a new spot;\nleave it empty to update the selected spot.");
		if (current != null)
		{
			ImGui.SameLine();
			if (ImGui.Button("Rename##navren") && _newName.Trim().Length > 0)
			{
				current.Name = _newName.Trim();
				_s.NavSelected = current.Name;
				_newName = "";
				flag = true;
			}
			ImGui.SameLine();
			if (ImGui.Button("Face now##navface") && current.Heading >= 0.0)
			{
				try
				{
					Globals.Core.Actions.FaceHeading(current.Heading, true);
				}
				catch
				{
				}
			}
			ImGui.SameLine();
			if (ImGui.Button("Update heading##navhd"))
			{
				current.Heading = CombatEngine.MyHeading();
				flag = true;
			}
			Tip("Saves the way you're facing now for this spot (position unchanged).");
		}
		ImGui.Separator();
		flag |= ImGui.Checkbox("Return to spot", ref _s.NavEnabled);
		Tip("When nothing needs fighting or looting and you're further than 'drift allowed' from the spot,\nface it and run back.\n/mt set NavEnabled on|off");
		ImGui.SameLine(0f, 20f);
		flag |= ImGui.Checkbox("Return first (before fighting / looting)", ref _s.NavPriority);
		Tip("Runs back as soon as you've drifted, even with monsters in range or corpses to loot.\n/mt set NavPriority on|off");
		flag |= ImGui.Checkbox("Pick the spot from the chamber message", ref _s.NavChamberSpots);
		Tip("Lum / coin dungeons say which chamber you're in when you portal or log in there.\nThe spot named for it is picked - one ending in C + the number (IdolC3, BansheeC7),\nthe nearest if several match. No spot for that chamber: Nav is turned off.\n/mt set NavChamberSpots on|off");
		ImGui.SetNextItemWidth(110f);
		flag |= ImGui.InputFloat("Drift allowed (m)", ref _s.NavDrift, 0.5f, 1f, "%.1f");
		Im.SetTooltipIfHovered("/mt set NavDrift <number>");
		if (_s.NavDrift < 0.5f)
		{
			_s.NavDrift = 0.5f;
		}
		if (current != null)
		{
			flag |= ImGui.Checkbox("Face the saved heading when back##face" + current.Name, ref current.FaceHeading);
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Saved with this spot (" + current.Name + ") - each spot has its own.");
			}
		}
		ImGui.Separator();
		if (current == null)
		{
			Im.TextColored(Grey, "No spot selected - stand where you want to be, type a name and click Save spot here.");
		}
		else
		{
			double num2 = DistanceTo(current);
			Im.TextColored(Cyan, current.Name + ":  " + Loc(current) + ((current.Heading >= 0.0) ? ("  facing " + current.Heading.ToString("0")) : ""));
			System.Numerics.Vector4 col;
			if (num2 < 0.0)
			{
				col = Grey;
			}
			else
			{
				col = ((num2 <= (double)_s.NavDrift) ? Green : Yellow);
			}
			Im.TextColored(col, (num2 < 0.0) ? "Distance: ?" : ("Distance: " + num2.ToString("0.0") + " m"));
			if (!string.IsNullOrEmpty(Status))
			{
				ImGui.SameLine(0f, 20f);
				Im.TextColored(_running ? Yellow : Grey, Status);
			}
		}
		if (flag)
		{
			SpotChanged();
		}
		if (flag && SaveAll != null)
		{
			SaveAll();
		}
	}

	private bool DrawNavSettings()
	{
		bool flag = false;
		ImGui.Indent(8f);
		ImGui.SetNextItemWidth(100f);
		flag |= ImGui.InputFloat("Stop and turn when the route bends this much or more (degrees)", ref _s.NavTurnAngle, 5f, 15f, "%.0f");
		Im.SetTooltipIfHovered("/mt set NavTurnAngle <number>");
		if (_s.NavTurnAngle < 10f)
		{
			_s.NavTurnAngle = 10f;
		}
		if (_s.NavTurnAngle > 180f)
		{
			_s.NavTurnAngle = 180f;
		}
		Tip("At a route point, if the next one is this far off the way you're running, stop and turn first.\nLess than this: keep running and steer onto it. Also: running off course by this much stops and turns.");
		ImGui.SetNextItemWidth(100f);
		flag |= ImGui.InputFloat("Don't run to a spot / point further than (m)", ref _s.NavMaxRunM, 100f, 500f, "%.0f");
		Im.SetTooltipIfHovered("/mt set NavMaxRunM <number>");
		if (_s.NavMaxRunM < 100f)
		{
			_s.NavMaxRunM = 100f;
		}
		Tip("Further than this, you're somewhere else (portalled away, logged in elsewhere): Nav doesn't try to run there -\nit says so once and waits, and carries on by itself once you're back within this distance.");
		flag |= DrawDoorSettings();
		flag |= ImGui.Checkbox("Steer while running", ref _s.NavSmoothSteer);
		Im.SetTooltipIfHovered("/mt set NavSteerWhileRunning on|off");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		flag |= ImGui.InputFloat("deg off before turning##navsteerdb", ref _s.NavSteerDeadband, 1f, 5f, "%.0f");
		Im.SetTooltipIfHovered("/mt set NavSteerDeadband <number>");
		if (_s.NavSteerDeadband < 1f)
		{
			_s.NavSteerDeadband = 1f;
		}
		if (_s.NavSteerDeadband > 45f)
		{
			_s.NavSteerDeadband = 45f;
		}
		Tip("Steering while running holds turn left / right (like A / D) until you face the next point, checked every frame.\nThis is how far off you can be before a turn starts; once turning, it carries on until you face the point.\nLower: tighter lines, more frequent turns. Higher: fewer, bigger turns and straighter runs.");
		Tip("While running, turn the way a player does - holding turn left / turn right (A / D) while still running -\ninstead of the game's turn-to-heading, which stops the run and has to restart it. Corners under the angle\nabove are taken without stopping. If the run stops anyway, it's restarted as before and the debug log says\n\"[right after a direct steer]\".");
		ImGui.SetNextItemWidth(100f);
		flag |= ImGui.InputFloat("Next point counts as close within (m)", ref _s.NavCloseDist, 0.5f, 2f, "%.1f");
		Im.SetTooltipIfHovered("/mt set NavCloseDist <number>");
		if (_s.NavCloseDist < 0f)
		{
			_s.NavCloseDist = 0f;
		}
		ImGui.SetNextItemWidth(100f);
		flag |= ImGui.InputFloat("...and then stop and turn from (degrees)", ref _s.NavCloseAngle, 5f, 15f, "%.0f");
		Im.SetTooltipIfHovered("/mt set NavCloseAngle <number>");
		if (_s.NavCloseAngle < 0f)
		{
			_s.NavCloseAngle = 0f;
		}
		if (_s.NavCloseAngle > 180f)
		{
			_s.NavCloseAngle = 180f;
		}
		Tip("A close next point is easy to run past while steering, so a smaller bend is enough to stop and turn.");
		ImGui.Unindent(8f);
		return flag;
	}

	private static string Loc(NavSpot p)
	{
		return Math.Abs(p.NS).ToString("0.000") + ((p.NS >= 0.0) ? "N" : "S") + ", " + Math.Abs(p.EW).ToString("0.000") + ((p.EW >= 0.0) ? "E" : "W");
	}

	private static void Tip(string text)
	{
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip(text);
		}
	}

	public void OnChamberChat(string text)
	{
		if (_s.NavChamberSpots && !string.IsNullOrEmpty(text) && !text.Contains(" says, ") && !text.Contains(" tells you") && !text.Contains("You say, ") && !text.Contains("You tell ") && !text.StartsWith("[") && !text.StartsWith("Nav:") && !text.StartsWith("<Tell:") && ChamberWord.IsMatch(text) && text.IndexOf(" kills", StringComparison.OrdinalIgnoreCase) < 0)
		{
			Match match = NumberRx.Match(text);
			int result;
			if (!match.Success)
			{
				Catcher.Note("chamber-nonumber", text);
			}
			else if (int.TryParse(match.Groups[1].Success ? match.Groups[1].Value : match.Groups[2].Value, out result))
			{
				_chamber = result;
				_chamberText = text;
				_chamberDue = DateTime.Now.AddSeconds(2.0);
			}
		}
	}

	public static void EarlyChat(string text)
	{
		if (!string.IsNullOrEmpty(text) && ChamberWord.IsMatch(text))
		{
			_earlyText = text;
			_earlyAt = DateTime.Now;
		}
	}

	public void ChamberTick()
	{
		if (_earlyText != null)
		{
			string earlyText = _earlyText;
			_earlyText = null;
			if ((DateTime.Now - _earlyAt).TotalSeconds < 90.0)
			{
				OnChamberChat(earlyText);
			}
		}
		bool navEnabled = _s.NavEnabled;
		if (navEnabled && !_navWasOn && _s.NavMode == 1)
		{
			NavRoute currentRoute = CurrentRoute;
			if (currentRoute != null && string.Equals(currentRoute.Name, "Map route", StringComparison.OrdinalIgnoreCase))
			{
				if (_rDone)
				{
					_rName = "";
				}
			}
			else
			{
				_resumeNearest = true;
			}
		}
		_navWasOn = navEnabled;
		if (DateTime.Now < _chamberDue)
		{
			return;
		}
		if (_s.NavEnabled && _s.NavMode == 1 && CurrentRoute != null && !_rDone)
		{
			_chamberDue = DateTime.Now.AddSeconds(2.0);
			return;
		}
		_chamberDue = DateTime.MaxValue;
		int chamber = _chamber;
		string text = (_chamberText ?? "").ToLowerInvariant();
		List<NavSpot> list = new List<NavSpot>();
		List<NavSpot> list2 = new List<NavSpot>();
		foreach (NavSpot navSpot2 in _s.NavSpots)
		{
			string text2 = (navSpot2.Name ?? "").Trim();
			Match match = SpotNumberRx.Match(text2);
			if (!match.Success || !int.TryParse(match.Groups[1].Value, out var result) || result != chamber)
			{
				continue;
			}
			list.Add(navSpot2);
			string text3 = text2.Substring(0, match.Index).Trim().ToLowerInvariant();
			if (text3.Length == 0)
			{
				continue;
			}
			bool flag = text.Contains(text3) || (text3.EndsWith("s") && text.Contains(text3.TrimEnd('s')));
			string[][] dungeonAliases = DungeonAliases;
			foreach (string[] array in dungeonAliases)
			{
				if (text.Contains(array[0]) && text3.StartsWith(array[1]))
				{
					flag = true;
				}
			}
			if (flag)
			{
				list2.Add(navSpot2);
			}
		}
		bool flag2 = false;
		string[][] dungeonAliases2 = DungeonAliases;
		foreach (string[] array2 in dungeonAliases2)
		{
			if (text.Contains(array2[0]))
			{
				flag2 = true;
			}
		}
		NavSpot navSpot = null;
		double num = double.MaxValue;
		List<NavSpot> list3;
		if (list2.Count > 0)
		{
			list3 = list2;
		}
		else
		{
			list3 = (flag2 ? list2 : list);
		}
		foreach (NavSpot item in list3)
		{
			double num2 = DistanceTo(item);
			if (num2 < 0.0)
			{
				num2 = 1000000.0;
			}
			if (num2 < num)
			{
				navSpot = item;
				num = num2;
			}
		}
		if (list2.Count == 0 && navSpot != null && num > 1500.0 && num < 1000000.0)
		{
			navSpot = null;
		}
		if (navSpot != null)
		{
			bool flag3 = string.Equals(_s.NavSelected, navSpot.Name, StringComparison.OrdinalIgnoreCase) && _s.NavMode == 0;
			_s.NavSelected = navSpot.Name;
			_s.NavMode = 0;
			_lastHeadingFix = DateTime.MinValue;
			if (!flag3)
			{
				Stop();
				SpotChanged();
				if (SaveAll != null)
				{
					SaveAll();
				}
			}
			Util.WriteToChat("Nav: chamber " + chamber + " - " + (flag3 ? "staying on" : "switched to") + " spot '" + navSpot.Name + "'" + (_s.NavEnabled ? "." : " (Nav is off)."));
			Catcher.Note("chamber-spot", navSpot.Name + " (" + ((num < 1000000.0) ? (num.ToString("0") + " m") : "distance unknown") + ") from: " + _chamberText);
		}
		else if (_s.NavEnabled)
		{
			_s.NavEnabled = false;
			Stop();
			if (SaveAll != null)
			{
				SaveAll();
			}
			Util.WriteToChat("Nav: chamber " + chamber + " has no saved spot (name one ending in C" + chamber + ") - Nav turned off.");
			Catcher.Note("chamber-navoff", _chamberText);
		}
		else
		{
			Util.WriteToChat("Nav: chamber " + chamber + " has no saved spot (name one ending in C" + chamber + ").");
		}
	}

	private bool DoorInTheWay()
	{
		if (!OpenDoorsNow)
		{
			return false;
		}
		if (_doorId != 0 && (DateTime.Now - _doorAt).TotalSeconds < 2.5)
		{
			return true;
		}
		bool flag = _doorId != 0 && (DateTime.Now - _doorAt).TotalSeconds < 10.0;
		WorldObject worldObject = null;
		double num = _s.NavDoorRange;
		try
		{
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				if (IsDoor(item))
				{
					double num2 = CombatEngine.Distance(item);
					if (num2 >= 0.0 && num2 <= num)
					{
						num = num2;
						worldObject = item;
					}
				}
			}
		}
		catch
		{
			return false;
		}
		if (worldObject == null)
		{
			return false;
		}
		if (flag && worldObject.Id == _doorId)
		{
			return false;
		}
		_doorTries.TryGetValue(worldObject.Id, out var value);
		if (value >= 6)
		{
			return false;
		}
		_doorTries[worldObject.Id] = value + 1;
		if (_doorId != worldObject.Id)
		{
			_doorId = worldObject.Id;
			_doorLocked = false;
		}
		bool? flag2 = DoorShut(worldObject.Id);
		if (!flag2.HasValue)
		{
			_doorTries[worldObject.Id] = value;
			Status = "Checking " + worldObject.Name;
			return true;
		}
		if (flag2 == false)
		{
			L("door: " + worldObject.Name + " is open already - not using it");
			_doorTries[worldObject.Id] = value;
			_doorAt = DateTime.Now.AddSeconds(-2.6);
			return false;
		}
		if (_doorLocked && _s.NavPickLocks && TryPick(worldObject))
		{
			return true;
		}
		try
		{
			Globals.Core.Actions.UseItem(worldObject.Id, 0);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			return false;
		}
		_doorAt = DateTime.Now;
		_doorUseAt = DateTime.Now;
		_doorRerun = false;
		L("door: using " + worldObject.Name + " (" + num.ToString("0.0") + " m)");
		Status = "Opening " + worldObject.Name;
		return true;
	}

	private bool TryPick(WorldObject door)
	{
		if (_doorNoPick.Contains(door.Id))
		{
			return false;
		}
		if (!door.HasIdData)
		{
			if ((DateTime.Now - _doorPickAt).TotalSeconds > 3.0)
			{
				_doorPickAt = DateTime.Now;
				try
				{
					Util.RequestId(door.Id);
				}
				catch
				{
				}
			}
			_doorAt = DateTime.Now;
			Status = "Checking the lock on " + door.Name;
			return true;
		}
		int num = LootMatcher.Long(door, 38);
		int num2 = Character.EffectiveSkill(23);
		if (num >= 9999 || num2 - num < _s.NavLockpickMargin)
		{
			_doorNoPick.Add(door.Id);
			Util.WriteToChat("Nav: " + door.Name + " is locked - " + ((num >= 9999) ? "it can't be picked" : ("lock " + num + ", your Lockpick is " + num2)) + ".");
			return false;
		}
		WeaponItem weaponItem = null;
		foreach (WeaponItem item in _s.Items)
		{
			if (item.Kind == WeaponKind.Lockpick && ItemInfo.CountInPack(item.Name) > 0)
			{
				weaponItem = item;
				break;
			}
		}
		if (weaponItem == null)
		{
			_doorNoPick.Add(door.Id);
			Util.WriteToChat("Nav: " + door.Name + " is locked and there's no lockpick on the Items tab (add one: select it, Add selected).");
			return false;
		}
		WorldObject worldObject = Globals.Core.WorldFilter[weaponItem.Id];
		int num3 = ((worldObject != null) ? weaponItem.Id : FindByName(weaponItem.Name));
		if (num3 == 0)
		{
			return false;
		}
		try
		{
			CM_Inventory.Event_UseWithTargetEvent((uint)num3, (uint)door.Id);
		}
		catch
		{
			try
			{
				Globals.Core.Actions.ApplyItem(num3, door.Id);
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
				return false;
			}
		}
		_doorAt = DateTime.Now;
		L("door: picking " + door.Name + " (lock " + num + ", skill " + num2 + ") with " + weaponItem.Name);
		Status = "Picking the lock on " + door.Name;
		return true;
	}

	private static int FindByName(string name)
	{
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
				{
					return item.Id;
				}
			}
		}
		catch
		{
		}
		return 0;
	}

	public void OnDoorChat(string text)
	{
		if (_s.NavOpenDoors && _doorId != 0 && !((DateTime.Now - _doorAt).TotalSeconds > 10.0))
		{
			if (text.IndexOf(" is locked", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				_doorLocked = true;
				_doorAt = DateTime.Now.AddSeconds(-2.0);
			}
			else if (text.IndexOf("unlock", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("picked the lock", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				_doorLocked = false;
				_doorAt = DateTime.Now.AddSeconds(-2.0);
			}
		}
	}

	private bool DrawDoorSettings()
	{
		bool flag = false;
		flag |= ImGui.Checkbox("Open doors in the way", ref _s.NavOpenDoors);
		Tip("When running stops getting closer and a door is within the range, it's used (opened).\nOnly then - doors aren't checked or ID'd otherwise.\n/mt set NavOpenDoors on|off");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		flag |= ImGui.InputFloat("m##doorrange", ref _s.NavDoorRange, 0.5f, 1f, "%.1f");
		Im.SetTooltipIfHovered("/mt set NavDoorRange <number>");
		if (_s.NavDoorRange < 1f)
		{
			_s.NavDoorRange = 1f;
		}
		ImGui.Indent(16f);
		if (!_s.NavOpenDoors)
		{
			ImGui.PushStyleVar(ImGuiStyleVar.Alpha, 0.5f);
		}
		flag |= ImGui.Checkbox("Pick locked doors", ref _s.NavPickLocks);
		Tip("A locked door is ID'd for its lock (9999 = can't be picked), and a lockpick from the Items tab is used on it\nwhen your Lockpick skill minus the lock is at least the number here (-50 = up to 50 below still tries).\n/mt set NavPickLocks on|off");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		flag |= ImGui.InputInt("skill over lock##lpmargin", ref _s.NavLockpickMargin, 10, 50);
		Im.SetTooltipIfHovered("/mt set NavLockpickMargin <number>");
		if (!_s.NavOpenDoors)
		{
			ImGui.PopStyleVar();
			Tip("Needs 'Open doors in the way' ticked.");
		}
		ImGui.Unindent(16f);
		return flag;
	}

	private static TreeDir Scan(string dir, int depth)
	{
		TreeDir treeDir = new TreeDir
		{
			Path = dir,
			Name = Path.GetFileName(dir)
		};
		if (depth > 6)
		{
			return treeDir;
		}
		try
		{
			List<string> list = new List<string>(Directory.GetDirectories(dir));
			list.Sort(StringComparer.OrdinalIgnoreCase);
			foreach (string item in list)
			{
				TreeDir treeDir2 = Scan(item, depth + 1);
				if (treeDir2.Files.Count > 0 || treeDir2.Dirs.Count > 0 || depth == 0)
				{
					treeDir.Dirs.Add(treeDir2);
				}
			}
			string[] files = Directory.GetFiles(dir);
			foreach (string text in files)
			{
				if (text.EndsWith(".nav", StringComparison.OrdinalIgnoreCase) || text.EndsWith(".mtnav", StringComparison.OrdinalIgnoreCase) || text.EndsWith(".met", StringComparison.OrdinalIgnoreCase))
				{
					treeDir.Files.Add(text);
				}
			}
			treeDir.Files.Sort(StringComparer.OrdinalIgnoreCase);
		}
		catch
		{
		}
		return treeDir;
	}

	public NavRoute ImportNav(string path)
	{
		string[] lines;
		try
		{
			lines = File.ReadAllLines(path);
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Nav: can't read " + path + ": " + ex.Message);
			return null;
		}
		int i = 0;
		Func<string> next = () => (i < lines.Length) ? lines[i++].Trim() : null;
		Func<double> func = () =>
		{
			string s = next();
			double result5;
			return double.TryParse(s, NumberStyles.Float, Inv, out result5) ? result5 : 0.0;
		};
		if (!(next() ?? "").StartsWith("uTank2 NAV", StringComparison.OrdinalIgnoreCase))
		{
			Util.WriteToChat("Nav: " + Path.GetFileName(path) + " isn't a VTank nav file.");
			return null;
		}
		int.TryParse(next(), out var result);
		NavRoute navRoute = new NavRoute
		{
			Name = Path.GetFileNameWithoutExtension(path)
		};
		navRoute.Mode = result switch
		{
			4 => 0, 
			2 => 1, 
			_ => 2, 
		};
		if (result == 3)
		{
			string text = next();
			Util.WriteToChat("Nav: " + Path.GetFileName(path) + " is a VTank follow nav for " + text + " - use Nav mode 'Follow a player' for that.");
			return null;
		}
		int.TryParse(next(), out var result2);
		List<string> list = new List<string>();
		for (int num = 0; num < result2; num++)
		{
			if (i >= lines.Length)
			{
				break;
			}
			if (!int.TryParse(next(), out var result3))
			{
				break;
			}
			double eW = func();
			double nS = func();
			double z = func() * 240.0;
			next();
			RouteStep item = new RouteStep
			{
				Kind = StepKind.Point,
				NS = nS,
				EW = eW,
				Z = z
			};
			switch (result3)
			{
			case 0:
			case 8:
				navRoute.Steps.Add(item);
				break;
			case 2:
			{
				int.TryParse(next(), out var result4);
				navRoute.Steps.Add(new RouteStep
				{
					Kind = StepKind.Cast,
					Text = result4.ToString(Inv)
				});
				break;
			}
			case 3:
			{
				double num4 = func();
				navRoute.Steps.Add(new RouteStep
				{
					Kind = StepKind.Wait,
					WaitMs = (int)num4
				});
				break;
			}
			case 4:
				navRoute.Steps.Add(new RouteStep
				{
					Kind = StepKind.Command,
					Text = (next() ?? ""),
					WaitMs = 1000
				});
				break;
			case 5:
			{
				next();
				string text2 = next() ?? "";
				navRoute.Steps.Add(new RouteStep
				{
					Kind = StepKind.Use,
					Text = text2,
					NS = nS,
					EW = eW,
					Z = z
				});
				break;
			}
			case 6:
			case 7:
			{
				string text3 = next() ?? "";
				next();
				next();
				double eW2 = func();
				double nS2 = func();
				double z2 = func() * 240.0;
				navRoute.Steps.Add(new RouteStep
				{
					Kind = StepKind.Use,
					Text = text3,
					NS = nS2,
					EW = eW2,
					Z = z2
				});
				break;
			}
			case 9:
			{
				double num2 = func();
				string a = next();
				double num3 = func();
				bool flag = string.Equals(a, "True", StringComparison.OrdinalIgnoreCase);
				navRoute.Steps.Add(new RouteStep
				{
					Kind = StepKind.Command,
					Text = "/ub jump" + (flag ? "s" : "") + "w " + num2.ToString("0", Inv) + " " + num3.ToString("0", Inv),
					WaitMs = 1500
				});
				break;
			}
			default:
				list.Add("type " + result3);
				navRoute.Steps.Add(item);
				break;
			}
		}
		Util.WriteToChat("Nav: imported " + Path.GetFileName(path) + " - " + navRoute.Steps.Count + " steps, " + RouteModes[navRoute.Mode] + "." + ((list.Count > 0) ? (" Unknown waypoints kept as points: " + string.Join(", ", list.ToArray()) + ".") : ""));
		return navRoute;
	}

	public bool ExportNav(NavRoute r, string path, bool quiet = false)
	{
		r = NavPresets.Expanded(r);
		StringBuilder stringBuilder = new StringBuilder();
		int num = 0;
		int num2 = 0;
		RouteStep routeStep = null;
		Func<RouteStep, string> func = (RouteStep s) => ((s == null) ? "0\n0\n0" : (s.EW.ToString("R", Inv) + "\n" + s.NS.ToString("R", Inv) + "\n" + (s.Z / 240.0).ToString("R", Inv))) + "\n0\n";
		foreach (RouteStep step in r.Steps)
		{
			switch (step.Kind)
			{
			case StepKind.Point:
				stringBuilder.Append("0\n").Append(func(step));
				routeStep = step;
				num++;
				break;
			case StepKind.Command:
				stringBuilder.Append("4\n").Append(func(routeStep)).Append(step.Text)
					.Append('\n');
				num++;
				break;
			case StepKind.Wait:
				stringBuilder.Append("3\n").Append(func(routeStep)).Append(step.WaitMs.ToString(Inv))
					.Append('\n');
				num++;
				break;
			case StepKind.Cast:
				stringBuilder.Append("2\n").Append(func(routeStep)).Append(step.Text)
					.Append('\n');
				num++;
				break;
			case StepKind.UseItem:
				stringBuilder.Append("4\n").Append(func(routeStep)).Append("/ub use " + step.Text)
					.Append('\n');
				num++;
				break;
			case StepKind.Use:
				stringBuilder.Append("6\n").Append(func(routeStep ?? step)).Append(step.Text)
					.Append("\n14\nTrue\n")
					.Append(step.EW.ToString("R", Inv))
					.Append('\n')
					.Append(step.NS.ToString("R", Inv))
					.Append('\n')
					.Append((step.Z / 240.0).ToString("R", Inv))
					.Append('\n');
				num++;
				break;
			default:
				num2++;
				break;
			}
		}
		int num3 = ((r.Mode == 0) ? 4 : ((r.Mode != 1) ? 1 : 2));
		try
		{
			File.WriteAllText(path, "uTank2 NAV 1.2\r\n" + num3 + "\r\n" + num + "\r\n" + stringBuilder.ToString().Replace("\n", "\r\n").Replace("\r\r\n", "\r\n"));
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Nav: couldn't write " + path + ": " + ex.Message);
			return false;
		}
		if (!quiet || num2 > 0)
		{
			Util.WriteToChat((quiet ? ("Nav: " + r.Name + ":") : ("Nav: exported " + r.Name + " as " + Path.GetFileName(path) + " (" + num + " waypoints).")) + ((num2 > 0) ? (" Left out " + num2 + " step(s) VTank's nav format can't hold (loop start / end, switches, chat waits, item checks, go to route).") : ""));
		}
		return true;
	}

	public bool SaveRouteFile(NavRoute r, string path)
	{
		return SaveRouteFile(r, path, quiet: false);
	}

	public bool SaveRouteFile(NavRoute r, string path, bool quiet)
	{
		try
		{
			XmlDocument xmlDocument = new XmlDocument();
			XmlElement xmlElement = xmlDocument.CreateElement("MelkTankRoute");
			xmlDocument.AppendChild(xmlElement);
			Settings.WriteRoute(xmlDocument, xmlElement, r);
			xmlDocument.Save(path);
			if (!quiet)
			{
				Util.WriteToChat("Nav: saved " + r.Name + " to " + Path.GetFileName(path) + ".");
			}
			return true;
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Nav: couldn't save " + path + ": " + ex.Message);
			return false;
		}
	}

	public NavRoute LoadRouteFile(string path)
	{
		try
		{
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.Load(path);
			NavRoute navRoute = Settings.ReadRoute(xmlDocument.DocumentElement);
			if (navRoute != null && navRoute.Name.Length == 0)
			{
				navRoute.Name = Path.GetFileNameWithoutExtension(path);
			}
			return navRoute;
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Nav: couldn't read " + path + ": " + ex.Message);
			return null;
		}
	}

	private static string SafeName(string n)
	{
		char[] invalidFileNameChars = Path.GetInvalidFileNameChars();
		foreach (char oldChar in invalidFileNameChars)
		{
			n = n.Replace(oldChar, '_');
		}
		return (n.Trim().Length == 0) ? "route" : n.Trim();
	}

	private bool DrawRouteFiles(NavRoute r)
	{
		bool result = false;
		ImGui.Indent(8f);
		string dir = Dir;
		if (ImGui.RadioButton("MelkTank Navs folder", !_showVtankDir))
		{
			_showVtankDir = false;
			_treeAt = DateTime.MinValue;
			_pickFile = (_pickFolder = null);
		}
		ImGui.SameLine();
		if (VtankDir != null)
		{
			if (ImGui.RadioButton("VTank folder", _showVtankDir))
			{
				_showVtankDir = true;
				_treeAt = DateTime.MinValue;
				_pickFile = (_pickFolder = null);
			}
		}
		else
		{
			Im.TextColored(Grey, "(no VTank folder found)");
		}
		ImGui.SameLine();
		if (ImGui.SmallButton("Refresh"))
		{
			_treeAt = DateTime.MinValue;
		}
		Im.TextColored(Grey, dir);
		if (_tree == null || _tree.Path != dir || (DateTime.Now - _treeAt).TotalSeconds > 5.0)
		{
			_tree = Scan(dir, 0);
			_treeAt = DateTime.Now;
		}
		if (_pickFolder == null || !_pickFolder.StartsWith(dir, StringComparison.OrdinalIgnoreCase))
		{
			_pickFolder = dir;
		}
		if (ImGui.BeginChild("##navtree", new System.Numerics.Vector2(0f, 180f), border: true))
		{
			if (_tree.Dirs.Count == 0 && _tree.Files.Count == 0)
			{
				Im.TextColored(Grey, "No .nav / .mtnav files here yet. Make sub folders (Dungeons, Quests...) to group them.");
			}
			DrawTreeDir(_tree, top: true);
		}
		ImGui.EndChild();
		bool flag = _pickFile != null && File.Exists(_pickFile);
		if (flag && _pickFile.EndsWith(".met", StringComparison.OrdinalIgnoreCase))
		{
			if (ImGui.Button("Deconstruct meta into navs"))
			{
				DeconstructMeta(_pickFile);
				_treeAt = DateTime.MinValue;
			}
			Tip("Saves every nav built into this VTank meta as its own .nav file: <meta>Nav1_<its name>.nav, Nav2... \nThey go in the same folder as the meta (or the MelkTank Navs folder when the meta is in VTank's folder).\nThe meta itself isn't changed.");
			ImGui.SameLine();
			Im.TextColored(Grey, Path.GetFileName(_pickFile));
			ImGui.Unindent(8f);
			return result;
		}
		if (!flag)
		{
			ImGui.BeginDisabled();
		}
		if (ImGui.Button("Load") & flag)
		{
			bool flag2 = _pickFile.EndsWith(".mtnav", StringComparison.OrdinalIgnoreCase);
			NavSpot sp = (flag2 ? LoadSpotFile(_pickFile) : null);
			NavRoute nr;
			if (sp != null)
			{
				nr = null;
			}
			else
			{
				nr = (flag2 ? LoadRouteFile(_pickFile) : ImportNav(_pickFile));
			}
			if (sp != null)
			{
				sp.File = (_pickFile.StartsWith(NavDir, StringComparison.OrdinalIgnoreCase) ? _pickFile : "");
				string name = sp.Name;
				int num = 2;
				while (_s.NavSpots.Exists((NavSpot x) => string.Equals(x.Name, sp.Name, StringComparison.OrdinalIgnoreCase)))
				{
					sp.Name = name + " (" + num++ + ")";
				}
				_s.NavSpots.Add(sp);
				_s.NavSelected = sp.Name;
				Stop();
				result = true;
				Util.WriteToChat("Nav: spot " + sp.Name + " loaded (Nav mode: Stay on a spot).");
			}
			if (nr != null)
			{
				nr.File = ((flag2 && _pickFile.StartsWith(NavDir, StringComparison.OrdinalIgnoreCase)) ? _pickFile : "");
				string name2 = nr.Name;
				int num2 = 2;
				while (_s.NavRoutes.Exists((NavRoute x) => string.Equals(x.Name, nr.Name, StringComparison.OrdinalIgnoreCase)))
				{
					nr.Name = name2 + " (" + num2++ + ")";
				}
				_s.NavRoutes.Add(nr);
				_s.NavRouteSelected = nr.Name;
				Stop();
				RouteReset();
				_rSel = -1;
				result = true;
			}
		}
		if (!flag)
		{
			ImGui.EndDisabled();
		}
		Tip("Click a file in the list first. A route file is added as a new route (a VTank .nav is converted);\na spot file (in Spots) as a new spot. The file itself isn't changed.");
		if (flag)
		{
			ImGui.SameLine();
			Im.TextColored(Grey, Path.GetFileName(_pickFile));
		}
		if (r != null)
		{
			string text = ((_pickFolder.Length > dir.Length) ? _pickFolder.Substring(dir.Length).TrimStart(new char[2] { '\\', '/' }) : "");
			Im.TextColored(Grey, "Saves go to: " + ((text.Length > 0) ? text : "(top folder)") + "   - click a folder to change");
			if (ImGui.Button("Save as MelkTank file (.mtnav)") && SaveRouteFile(r, Path.Combine(_pickFolder, SafeName(r.Name) + ".mtnav")))
			{
				_treeAt = DateTime.MinValue;
			}
			Tip("Everything in the route - for your other characters, or to keep a copy. Same name: replaced.");
			ImGui.SameLine();
			if (ImGui.Button("Export as VTank .nav") && ExportNav(r, Path.Combine(_pickFolder, SafeName(r.Name) + ".nav")))
			{
				_treeAt = DateTime.MinValue;
			}
			Tip("For VTank. Loop starts and combat / looting switches can't be written in VTank's format - they're left out.");
		}
		ImGui.Unindent(8f);
		return result;
	}

	public void RouteChanged()
	{
		_routeDirtyAt = DateTime.Now;
	}

	public void SaveRouteFiles(bool now)
	{
		try
		{
			SaveSpotFiles(now);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		if (!_filesChecked)
		{
			_filesChecked = true;
			foreach (NavRoute navRoute in _s.NavRoutes)
			{
				if (string.IsNullOrEmpty(navRoute.File) || !File.Exists(navRoute.File))
				{
					AutoSave(navRoute);
				}
			}
		}
		if (!(_routeDirtyAt == DateTime.MinValue) && (now || !((DateTime.Now - _routeDirtyAt).TotalSeconds < 1.5)))
		{
			_routeDirtyAt = DateTime.MinValue;
			NavRoute currentRoute = CurrentRoute;
			if (currentRoute != null && !IsMetaRoute(currentRoute))
			{
				AutoSave(currentRoute);
			}
		}
	}

	private void AutoSave(NavRoute r)
	{
		if (string.Equals(r.Name, "Map route", StringComparison.OrdinalIgnoreCase))
		{
			return;
		}
		try
		{
			string path = SafeName(r.Name) + ".mtnav";
			string text = ((!string.IsNullOrEmpty(r.File) && Directory.Exists(Path.GetDirectoryName(r.File))) ? Path.GetDirectoryName(r.File) : NavDir);
			string text2 = Path.Combine(text, path);
			Directory.CreateDirectory(text);
			if (!string.IsNullOrEmpty(r.File) && !string.Equals(r.File, text2, StringComparison.OrdinalIgnoreCase) && File.Exists(r.File))
			{
				try
				{
					File.Delete(r.File);
				}
				catch
				{
				}
			}
			bool flag = string.IsNullOrEmpty(r.File) || !File.Exists(text2);
			if (SaveRouteFile(r, text2, quiet: true))
			{
				bool flag2 = !string.Equals(r.File, text2, StringComparison.OrdinalIgnoreCase);
				r.File = text2;
				if (flag)
				{
					Util.WriteToChat("Nav: route " + r.Name + " is saved as " + text2.Substring(Math.Min(text2.Length, NavDir.Length)).TrimStart(new char[2] { '\\', '/' }) + " (kept up to date as you edit).");
				}
				_treeAt = DateTime.MinValue;
				if (flag2 && SaveAll != null)
				{
					SaveAll();
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public void SpotChanged()
	{
		_spotDirtyAt = DateTime.Now;
	}

	public bool SaveSpotFile(NavSpot p, string path)
	{
		try
		{
			XmlDocument xmlDocument = new XmlDocument();
			XmlElement xmlElement = xmlDocument.CreateElement("MelkTankSpot");
			xmlDocument.AppendChild(xmlElement);
			xmlElement.SetAttribute("name", p.Name);
			xmlElement.SetAttribute("ns", p.NS.ToString("R", CultureInfo.InvariantCulture));
			xmlElement.SetAttribute("ew", p.EW.ToString("R", CultureInfo.InvariantCulture));
			xmlElement.SetAttribute("z", p.Z.ToString("R", CultureInfo.InvariantCulture));
			xmlElement.SetAttribute("heading", p.Heading.ToString("R", CultureInfo.InvariantCulture));
			xmlElement.SetAttribute("face", p.FaceHeading.ToString());
			xmlDocument.Save(path);
			return true;
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Nav: couldn't save " + path + ": " + ex.Message);
			return false;
		}
	}

	public NavSpot LoadSpotFile(string path)
	{
		try
		{
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.Load(path);
			XmlElement documentElement = xmlDocument.DocumentElement;
			if (documentElement == null || documentElement.Name != "MelkTankSpot")
			{
				return null;
			}
			NavSpot navSpot = new NavSpot
			{
				Name = documentElement.GetAttribute("name")
			};
			if (navSpot.Name.Length == 0)
			{
				navSpot.Name = Path.GetFileNameWithoutExtension(path);
			}
			double.TryParse(documentElement.GetAttribute("ns"), NumberStyles.Float, CultureInfo.InvariantCulture, out navSpot.NS);
			double.TryParse(documentElement.GetAttribute("ew"), NumberStyles.Float, CultureInfo.InvariantCulture, out navSpot.EW);
			double.TryParse(documentElement.GetAttribute("z"), NumberStyles.Float, CultureInfo.InvariantCulture, out navSpot.Z);
			if (!double.TryParse(documentElement.GetAttribute("heading"), NumberStyles.Float, CultureInfo.InvariantCulture, out navSpot.Heading))
			{
				navSpot.Heading = -1.0;
			}
			navSpot.FaceHeading = !bool.TryParse(documentElement.GetAttribute("face"), out var result) | result;
			return navSpot;
		}
		catch
		{
			return null;
		}
	}

	private void SaveSpotFiles(bool now)
	{
		if (!_spotFilesChecked)
		{
			_spotFilesChecked = true;
			foreach (NavSpot navSpot in _s.NavSpots)
			{
				if (string.IsNullOrEmpty(navSpot.File) || !File.Exists(navSpot.File))
				{
					AutoSaveSpot(navSpot);
				}
			}
		}
		if (!(_spotDirtyAt == DateTime.MinValue) && (now || !((DateTime.Now - _spotDirtyAt).TotalSeconds < 1.5)))
		{
			_spotDirtyAt = DateTime.MinValue;
			NavSpot current2 = Current;
			if (current2 != null)
			{
				AutoSaveSpot(current2);
			}
		}
	}

	private void AutoSaveSpot(NavSpot p)
	{
		try
		{
			string text = ((!string.IsNullOrEmpty(p.File) && Directory.Exists(Path.GetDirectoryName(p.File))) ? Path.GetDirectoryName(p.File) : SpotDir);
			Directory.CreateDirectory(text);
			string text2 = Path.Combine(text, SafeName(p.Name) + ".mtnav");
			if (!string.IsNullOrEmpty(p.File) && !string.Equals(p.File, text2, StringComparison.OrdinalIgnoreCase) && File.Exists(p.File))
			{
				try
				{
					File.Delete(p.File);
				}
				catch
				{
				}
			}
			bool flag = string.IsNullOrEmpty(p.File) || !File.Exists(text2);
			if (SaveSpotFile(p, text2))
			{
				bool flag2 = !string.Equals(p.File, text2, StringComparison.OrdinalIgnoreCase);
				p.File = text2;
				if (flag)
				{
					Util.WriteToChat("Nav: spot " + p.Name + " is saved as " + text2.Substring(Math.Min(text2.Length, NavDir.Length)).TrimStart(new char[2] { '\\', '/' }) + ".");
				}
				_treeAt = DateTime.MinValue;
				if (flag2 && SaveAll != null)
				{
					SaveAll();
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public int DeconstructMeta(string metPath)
	{
		byte[] array;
		try
		{
			array = File.ReadAllBytes(metPath);
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Nav: can't read " + metPath + ": " + ex.Message);
			return 0;
		}
		string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(metPath);
		string text = Path.GetDirectoryName(metPath);
		if (!text.StartsWith(NavDir, StringComparison.OrdinalIgnoreCase))
		{
			text = NavDir;
		}
		int num = 0;
		int num2 = 0;
		List<string> list = new List<string>();
		while (num2 < array.Length)
		{
			int num3 = FindLine(array, num2, "ba");
			if (num3 < 0)
			{
				break;
			}
			int num4 = num3;
			int num5 = Array.IndexOf(array, (byte)10, num4);
			if (num5 < 0)
			{
				break;
			}
			if (!int.TryParse(Encoding.ASCII.GetString(array, num4, num5 - num4).Trim(), out var result) || result <= 0 || num5 + 1 + result > array.Length)
			{
				num2 = num5 + 1;
				continue;
			}
			int num6 = num5 + 1;
			string text2 = Encoding.Default.GetString(array, num6, result);
			num2 = num6 + result;
			int num7 = text2.IndexOf("uTank2 NAV", StringComparison.OrdinalIgnoreCase);
			if (num7 >= 0)
			{
				string text3 = text2.Substring(0, (text2.IndexOfAny(new char[2] { '\r', '\n' }) >= 0) ? text2.IndexOfAny(new char[2] { '\r', '\n' }) : 0).Trim();
				if (text3.EndsWith(".nav", StringComparison.OrdinalIgnoreCase))
				{
					text3 = text3.Substring(0, text3.Length - 4);
				}
				if (text3.StartsWith("uTank2", StringComparison.OrdinalIgnoreCase) || text3.Equals("[None]", StringComparison.OrdinalIgnoreCase))
				{
					text3 = "";
				}
				num++;
				string text4 = SafeName(fileNameWithoutExtension + "Nav" + num + ((text3.Length > 0) ? ("_" + text3) : "")) + ".nav";
				try
				{
					File.WriteAllText(Path.Combine(text, text4), text2.Substring(num7), Encoding.Default);
					list.Add(text4);
				}
				catch (Exception ex2)
				{
					Util.WriteToChat("Nav: couldn't write " + text4 + ": " + ex2.Message);
				}
			}
		}
		if (list.Count == 0)
		{
			Util.WriteToChat("Nav: no navs found inside " + Path.GetFileName(metPath) + ".");
		}
		else
		{
			Util.WriteToChat("Nav: " + Path.GetFileName(metPath) + " -> " + list.Count + " nav(s) in " + text + ": " + string.Join(", ", list.ToArray()));
		}
		return list.Count;
	}

	private static int FindLine(byte[] b, int from, string line)
	{
		byte[] bytes = Encoding.ASCII.GetBytes(line);
		for (int i = from; i + bytes.Length < b.Length; i++)
		{
			if (i > 0 && b[i - 1] != 10)
			{
				continue;
			}
			bool flag = true;
			for (int j = 0; (j < bytes.Length) & flag; j++)
			{
				flag = b[i + j] == bytes[j];
			}
			if (flag)
			{
				int num = i + bytes.Length;
				if (num < b.Length && b[num] == 13)
				{
					num++;
				}
				if (num < b.Length && b[num] == 10)
				{
					return num + 1;
				}
			}
		}
		return -1;
	}

	private void DrawTreeDir(TreeDir d, bool top)
	{
		foreach (TreeDir dir in d.Dirs)
		{
			ImGuiTreeNodeFlags imGuiTreeNodeFlags = ImGuiTreeNodeFlags.OpenOnDoubleClick | ImGuiTreeNodeFlags.OpenOnArrow | ImGuiTreeNodeFlags.SpanAvailWidth;
			if (string.Equals(_pickFolder, dir.Path, StringComparison.OrdinalIgnoreCase))
			{
				imGuiTreeNodeFlags |= ImGuiTreeNodeFlags.Selected;
			}
			bool flag = ImGui.TreeNodeEx(dir.Name + "###d" + dir.Path, imGuiTreeNodeFlags);
			if (ImGui.IsItemClicked() && !ImGui.IsItemToggledOpen())
			{
				_pickFolder = dir.Path;
			}
			if (flag)
			{
				DrawTreeDir(dir, top: false);
				ImGui.TreePop();
			}
		}
		foreach (string file in d.Files)
		{
			bool selected = string.Equals(_pickFile, file, StringComparison.OrdinalIgnoreCase);
			bool flag2 = file.EndsWith(".nav", StringComparison.OrdinalIgnoreCase);
			bool flag3 = file.EndsWith(".met", StringComparison.OrdinalIgnoreCase);
			System.Numerics.Vector4 col;
			if (flag3)
			{
				col = new System.Numerics.Vector4(0.8f, 0.65f, 1f, 1f);
			}
			else
			{
				col = (flag2 ? new System.Numerics.Vector4(0.85f, 0.85f, 0.6f, 1f) : new System.Numerics.Vector4(0.6f, 0.85f, 1f, 1f));
			}
			ImGui.PushStyleColor(ImGuiCol.Text, col);
			if (ImGui.Selectable("    " + Path.GetFileName(file) + "###f" + file, selected))
			{
				_pickFile = file;
				_pickFolder = Path.GetDirectoryName(file);
			}
			ImGui.PopStyleColor();
			if (ImGui.IsItemHovered() && ImGui.IsMouseDoubleClicked(ImGuiMouseButton.Left))
			{
				_pickFile = file;
			}
		}
	}

	private static double Flat(NavSpot a, NavSpot b)
	{
		double num = (a.NS - b.NS) * 240.0;
		double num2 = (a.EW - b.EW) * 240.0;
		return Math.Sqrt(num * num + num2 * num2);
	}

	private void RecordCrumb(WorldObject p)
	{
		if (!_s.FollowExactPath)
		{
			_crumbs.Clear();
			return;
		}
		CoordsObject coordsObject = null;
		try
		{
			coordsObject = p.Coordinates();
		}
		catch
		{
		}
		if (coordsObject == null)
		{
			return;
		}
		double z = 0.0;
		try
		{
			z = p.RawCoordinates().Z;
		}
		catch
		{
		}
		NavSpot navSpot = new NavSpot
		{
			Name = "trail",
			NS = coordsObject.NorthSouth,
			EW = coordsObject.EastWest,
			Z = z,
			Heading = -1.0
		};
		if (_crumbs.Count > 0)
		{
			double num = Flat(navSpot, _crumbs[_crumbs.Count - 1]);
			if (num < CrumbStep)
			{
				return;
			}
			if (num > Tuning.V("CrumbJumpM"))
			{
				_crumbs.Clear();
			}
		}
		_crumbs.Add(navSpot);
		if (_crumbs.Count > 2000)
		{
			_crumbs.RemoveRange(0, _crumbs.Count - 2000);
		}
	}

	private bool FollowTrail(NavSpot leader)
	{
		NavSpot navSpot = MeSpot();
		if (navSpot == null)
		{
			return false;
		}
		while (_crumbs.Count > 0 && Flat(navSpot, _crumbs[0]) <= CrumbArrive)
		{
			_crumbs.RemoveAt(0);
		}
		while (_crumbs.Count > 1 && Flat(navSpot, _crumbs[1]) < Flat(navSpot, _crumbs[0]) && Flat(navSpot, _crumbs[0]) < 3.0)
		{
			_crumbs.RemoveAt(0);
		}
		double num = 0.0;
		NavSpot a = navSpot;
		foreach (NavSpot crumb in _crumbs)
		{
			num += Flat(a, crumb);
			a = crumb;
		}
		num += Flat(a, leader);
		if (num <= (double)_s.FollowDist || _crumbs.Count == 0)
		{
			if (_crumbs.Count == 0 && Flat(navSpot, leader) > (double)_s.FollowDist + 0.5)
			{
				return false;
			}
			if (_running)
			{
				Stop();
			}
			Status = "Following " + _s.FollowName + " on their path (" + num.ToString("0.0") + " m)";
			return true;
		}
		NavSpot navSpot2 = _crumbs[0];
		double num2 = Flat(navSpot, navSpot2);
		if (_running && num2 <= CrumbArrive * 1.5 && _crumbs.Count > 1)
		{
			double num3 = CombatEngine.MyHeading();
			double num4 = ((num3 < 0.0) ? 0.0 : AngleDiff(BearingTo(_crumbs[1]), num3));
			if (num4 >= (double)_s.NavTurnAngle)
			{
				L("follow: their path turns " + num4.ToString("0") + " deg - stop and turn");
				Stop();
				_crumbs.RemoveAt(0);
				return true;
			}
		}
		_bestDist = num2;
		_lastProgressAt = DateTime.Now;
		ReturnTick(navSpot2, CrumbArrive, CrumbArrive, precise: false);
		Status = "Following " + _s.FollowName + " on their path (" + num.ToString("0.0") + " m behind)";
		return true;
	}

	private NavSpot MeSpot()
	{
		try
		{
			CoordsObject coordsObject = Globals.Core.WorldFilter[Globals.Core.CharacterFilter.Id]?.Coordinates();
			if (coordsObject == null)
			{
				return null;
			}
			return new NavSpot
			{
				NS = coordsObject.NorthSouth,
				EW = coordsObject.EastWest
			};
		}
		catch
		{
			return null;
		}
	}

	private static WorldObject FindPlayer(string name)
	{
		if (string.IsNullOrEmpty(name))
		{
			return null;
		}
		try
		{
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				if (item.ObjectClass == ObjectClass.Player && string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
				{
					return item;
				}
			}
		}
		catch
		{
		}
		return null;
	}

	private bool FollowTick()
	{
		if (!_s.NavEnabled || string.IsNullOrEmpty(_s.FollowName))
		{
			Stop();
			return false;
		}
		DateTime now = DateTime.Now;
		WorldObject worldObject = FindPlayer(_s.FollowName);
		if (worldObject == null)
		{
			Stop();
			if (_s.FollowPortals && _fHasLast && (now - _fLastSeen).TotalSeconds < 4.0 && (now - _fPortalUsedAt).TotalSeconds > 20.0)
			{
				WorldObject worldObject2 = null;
				double num = 6.0;
				try
				{
					foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
					{
						if (item.ObjectClass != ObjectClass.Portal)
						{
							continue;
						}
						CoordsObject coordsObject = item.Coordinates();
						if (coordsObject != null)
						{
							double num2 = (coordsObject.NorthSouth - _fLastNS) * 240.0;
							double num3 = (coordsObject.EastWest - _fLastEW) * 240.0;
							double num4 = Math.Sqrt(num2 * num2 + num3 * num3);
							if (num4 < num)
							{
								num = num4;
								worldObject2 = item;
							}
						}
					}
				}
				catch
				{
				}
				if (worldObject2 != null)
				{
					_fPortalUsedAt = now;
					try
					{
						Globals.Core.Actions.UseItem(worldObject2.Id, 0);
					}
					catch (Exception ex)
					{
						Util.LogError(ex);
					}
					Util.WriteToChat("Nav: " + _s.FollowName + " went through " + worldObject2.Name + " - following.");
					L("follow: using " + worldObject2.Name);
					Status = "Following " + _s.FollowName + " through " + worldObject2.Name;
					return true;
				}
			}
			if ((now - _fLostSaid).TotalSeconds > 60.0 && _fHasLast)
			{
				_fLostSaid = now;
				Util.WriteToChat("Nav: can't see " + _s.FollowName + " - waiting for them to show up.");
			}
			Status = "Waiting for " + _s.FollowName;
			return false;
		}
		_fLostSaid = DateTime.MinValue;
		try
		{
			CoordsObject coordsObject2 = worldObject.Coordinates();
			if (coordsObject2 != null)
			{
				_fLastNS = coordsObject2.NorthSouth;
				_fLastEW = coordsObject2.EastWest;
				_fHasLast = true;
				_fLastSeen = now;
			}
		}
		catch
		{
		}
		double z = 0.0;
		try
		{
			z = worldObject.RawCoordinates().Z;
		}
		catch
		{
		}
		NavSpot navSpot = new NavSpot
		{
			Name = _s.FollowName,
			NS = _fLastNS,
			EW = _fLastEW,
			Z = z,
			Heading = -1.0
		};
		if (_s.FollowExactPath && _crumbs.Count > 0 && FollowTrail(navSpot))
		{
			return _running;
		}
		double num5 = DistanceTo(navSpot);
		if (num5 >= 0.0 && num5 <= (double)_s.FollowDist)
		{
			if (_running)
			{
				Stop();
			}
			Status = "Following " + _s.FollowName + " (" + num5.ToString("0.0") + " m)";
			return false;
		}
		_bestDist = num5;
		_lastProgressAt = now;
		bool result = ReturnTick(navSpot, (double)_s.FollowDist + 0.5, _s.FollowDist, precise: false);
		Status = "Following " + _s.FollowName + " (" + num5.ToString("0.0") + " m)";
		return result;
	}

	private void UpdateFollowMarkers()
	{
		WorldObject worldObject = ((_s.NavMode == 2 && _s.NavEnabled) ? FindPlayer(_s.FollowName) : null);
		if (worldObject != null)
		{
			RecordCrumb(worldObject);
		}
		else if (_s.NavMode != 2 || !_s.NavEnabled)
		{
			_crumbs.Clear();
		}
		string text = ((worldObject == null) ? "" : (worldObject.Id + "|" + _s.FollowRing + "|" + _s.FollowArrow));
		if (text == _fMarkKey)
		{
			if (worldObject != null && (DateTime.Now - _fVisCheck).TotalMilliseconds >= 250.0)
			{
				_fVisCheck = DateTime.Now;
				bool show = !_s.NavHideUnfocused || GameFocused();
				SetVisible(_fRing, show);
				SetVisible(_fArrow, show);
			}
			return;
		}
		_fMarkKey = text;
		ClearFollowMarkers();
		if (worldObject == null)
		{
			return;
		}
		try
		{
			D3DService d3DService = Globals.Core.D3DService;
			if (_s.FollowRing)
			{
				_fRing = d3DService.MarkObjectWithShape(worldObject.Id, D3DShape.Ring, -11149995);
				if (_fRing != null)
				{
					_fRing.Scale(1f);
				}
			}
			if (_s.FollowArrow)
			{
				_fArrow = d3DService.PointToObject(worldObject.Id, -11149995);
			}
			_fMarked = worldObject.Id;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void ClearFollowMarkers()
	{
		D3DObj[] array = new D3DObj[2] { _fRing, _fArrow };
		foreach (D3DObj d3DObj in array)
		{
			if (d3DObj != null)
			{
				try
				{
					d3DObj.Visible = false;
				}
				catch
				{
				}
				try
				{
					((IDisposable)d3DObj)?.Dispose();
				}
				catch
				{
				}
			}
		}
		_fRing = (_fArrow = null);
		_fMarked = 0;
	}

	private bool DrawFollow()
	{
		bool flag = false;
		if (ImGui.Button("Follow selected"))
		{
			int num = 0;
			try
			{
				num = Globals.Core.Actions.CurrentSelection;
			}
			catch
			{
			}
			WorldObject worldObject = ((num != 0) ? Globals.Core.WorldFilter[num] : null);
			if (worldObject == null || worldObject.ObjectClass != ObjectClass.Player)
			{
				Util.WriteToChat("Nav: select a player first.");
			}
			else
			{
				_s.FollowName = worldObject.Name;
				_s.NavEnabled = true;
				Stop();
				_crumbs.Clear();
				flag = true;
				Util.WriteToChat("Nav: following " + worldObject.Name + ".");
			}
		}
		ImGui.SameLine();
		Im.TextColored((_s.FollowName.Length > 0) ? Cyan : Grey, (_s.FollowName.Length > 0) ? ("Player: " + _s.FollowName) : "No one picked - select a player and click Follow selected.");
		bool v = _s.NavEnabled;
		if (ImGui.Checkbox("Follow", ref v))
		{
			_s.NavEnabled = v;
			if (!v)
			{
				Stop();
			}
			flag = true;
		}
		Tip("Keeps you within the distance below of them whenever there's nothing to fight or loot.");
		ImGui.SameLine(0f, 20f);
		ImGui.SetNextItemWidth(100f);
		flag |= ImGui.InputFloat("stay within (m)##fdist", ref _s.FollowDist, 0.5f, 1f, "%.1f");
		Im.SetTooltipIfHovered("/mt set FollowDist <number>");
		if (_s.FollowDist < 1f)
		{
			_s.FollowDist = 1f;
		}
		if (ImGui.Checkbox("Follow their exact path", ref _s.FollowExactPath))
		{
			_crumbs.Clear();
			flag = true;
		}
		Tip("Walks where they walked, metre by metre - turns at the same corners (inside buildings, around monsters)\ninstead of cutting straight across. Sharp turns stop and turn (Nav settings: the bend angle).\nThe trail starts when you tick this or pick who to follow.\n/mt set FollowExactPath on|off");
		flag |= ImGui.Checkbox("Follow them through portals", ref _s.FollowPortals);
		Tip("When they disappear right next to a portal, that portal is used too.\n/mt set FollowPortals on|off");
		flag |= ImGui.Checkbox("Ring under them", ref _s.FollowRing);
		Im.SetTooltipIfHovered("/mt set FollowRing on|off");
		ImGui.SameLine(0f, 20f);
		flag |= ImGui.Checkbox("Arrow to them", ref _s.FollowArrow);
		Im.SetTooltipIfHovered("/mt set FollowArrow on|off");
		ImGui.SameLine(0f, 20f);
		flag |= ImGui.Checkbox("Hide them while the game isn't the active window##fhide", ref _s.NavHideUnfocused);
		Im.SetTooltipIfHovered("/mt set NavHideUnfocused on|off");
		if (_s.NavEnabled && Status.Length > 0)
		{
			Im.TextColored(_running ? Yellow : Grey, Status);
		}
		return flag;
	}

	private static string HotChar()
	{
		try
		{
			CharacterFilter characterFilter = CoreManager.Current.CharacterFilter;
			return characterFilter.Server + "/" + characterFilter.Name;
		}
		catch
		{
			return "";
		}
	}

	private void SaveHotState()
	{
		try
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["char"] = HotChar();
			dictionary["at"] = DateTime.UtcNow.Ticks.ToString(HCI);
			if (_meta != null && !string.IsNullOrEmpty(_meta.File))
			{
				dictionary["metaFile"] = _meta.File;
				dictionary["state"] = _mState ?? "";
				dictionary["stateAge"] = (DateTime.Now - _mStateAt).TotalSeconds.ToString("R", HCI);
				dictionary["persistAge"] = (DateTime.Now - _mStatePersistAt).TotalSeconds.ToString("R", HCI);
				List<string> list = new List<string>();
				for (int i = 0; i < _meta.Rules.Count; i++)
				{
					if (_mFired.Contains(_meta.Rules[i]))
					{
						list.Add(i.ToString(HCI));
					}
				}
				dictionary["fired"] = string.Join(",", list.ToArray());
				dictionary["calls"] = string.Join("\n", _mCalls.ToArray());
				List<string> list2 = new List<string>();
				foreach (KeyValuePair<string, string> mOpt in _mOpts)
				{
					list2.Add(Uri.EscapeDataString(mOpt.Key) + "=" + Uri.EscapeDataString(mOpt.Value ?? ""));
				}
				dictionary["opts"] = string.Join("&", list2.ToArray());
				if (_wdOn)
				{
					dictionary["wdState"] = _wdState ?? "";
					dictionary["wdDist"] = _wdDist.ToString("R", HCI);
					dictionary["wdSecs"] = _wdSecs.ToString("R", HCI);
				}
			}
			if (_metaRoute != null)
			{
				dictionary["metaRoute"] = RouteXml(_metaRoute);
				dictionary["metaRouteName"] = _metaRoute.Name ?? "";
				dictionary["metaRouteMode"] = _metaRoute.Mode.ToString(HCI);
			}
			dictionary["rName"] = _rName ?? "";
			dictionary["rIdx"] = _rIdx.ToString(HCI);
			dictionary["rDir"] = _rDir.ToString(HCI);
			dictionary["rDone"] = (_rDone ? "1" : "0");
			dictionary["rStarted"] = (_rStarted ? "1" : "0");
			dictionary["rSub"] = _rSub.ToString(HCI);
			dictionary["rSubFor"] = _rSubFor.ToString(HCI);
			AppDomain.CurrentDomain.SetData("MelkTank.NavHotCarry", dictionary);
			L("hot carry: meta " + (dictionary.ContainsKey("metaFile") ? (_meta.Name + " in " + _mState) : "-") + ", route " + _rName + " step " + (_rIdx + 1));
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void RestoreHotState()
	{
		if (_hotTried)
		{
			return;
		}
		Dictionary<string, string> dictionary;
		try
		{
			dictionary = AppDomain.CurrentDomain.GetData("MelkTank.NavHotCarry") as Dictionary<string, string>;
		}
		catch
		{
			_hotTried = true;
			return;
		}
		if (dictionary == null)
		{
			_hotTried = true;
			return;
		}
		string text = HotChar();
		if (text.Length < 2 || text == "/")
		{
			return;
		}
		_hotTried = true;
		AppDomain.CurrentDomain.SetData("MelkTank.NavHotCarry", null);
		try
		{
			if (!dictionary.TryGetValue("char", out var value) || value != text || !dictionary.TryGetValue("at", out value) || !long.TryParse(value, NumberStyles.Integer, HCI, out var result) || (DateTime.UtcNow - new DateTime(result, DateTimeKind.Utc)).TotalMinutes > 10.0)
			{
				return;
			}
			_metaTriedLast = true;
			List<string> list = new List<string>();
			if (dictionary.TryGetValue("metaFile", out var value2) && File.Exists(value2))
			{
				if (_meta == null || !string.Equals(_meta.File, value2, StringComparison.OrdinalIgnoreCase))
				{
					OpenMeta(value2);
				}
				if (_meta != null)
				{
					string text2 = (dictionary.ContainsKey("state") ? dictionary["state"] : "Default");
					_mMeta = _meta;
					_mState = text2;
					_mStateAt = DateTime.Now.AddSeconds(0.0 - Num(dictionary, "stateAge"));
					_mStatePersistAt = DateTime.Now.AddSeconds(0.0 - Num(dictionary, "persistAge"));
					_mFired.Clear();
					_mChat.Clear();
					if (dictionary.TryGetValue("fired", out value))
					{
						string[] array = value.Split(new char[1] { ',' }, StringSplitOptions.RemoveEmptyEntries);
						foreach (string s in array)
						{
							if (int.TryParse(s, NumberStyles.Integer, HCI, out var result2) && result2 >= 0 && result2 < _meta.Rules.Count)
							{
								_mFired.Add(_meta.Rules[result2]);
							}
						}
					}
					_mCalls.Clear();
					if (dictionary.TryGetValue("calls", out value) && value.Length > 0)
					{
						string[] array2 = value.Split('\n');
						for (int num = array2.Length - 1; num >= 0; num--)
						{
							_mCalls.Push(array2[num]);
						}
					}
					_mOpts.Clear();
					if (dictionary.TryGetValue("opts", out value))
					{
						string[] array3 = value.Split(new char[1] { '&' }, StringSplitOptions.RemoveEmptyEntries);
						foreach (string text3 in array3)
						{
							int num2 = text3.IndexOf('=');
							if (num2 > 0)
							{
								_mOpts[Uri.UnescapeDataString(text3.Substring(0, num2))] = Uri.UnescapeDataString(text3.Substring(num2 + 1));
							}
						}
					}
					_mDied = (_mPortalIn = (_mPortalOut = false));
					_mVendorSeen = VendorOpen();
					_wdOn = false;
					if (dictionary.TryGetValue("wdState", out value) && MyPos(out var ns, out var ew, out var _))
					{
						_wdState = value;
						_wdDist = Num(dictionary, "wdDist");
						_wdSecs = Num(dictionary, "wdSecs");
						_wdNS = ns;
						_wdEW = ew;
						_wdAt = DateTime.Now;
						_wdOn = true;
					}
					MLog("carried over from the last build: state " + text2);
					list.Add("meta " + _meta.Name + " in state " + text2);
				}
			}
			if (dictionary.TryGetValue("metaRoute", out value) && value.Length > 0)
			{
				NavRoute navRoute = EmbeddedMtRoute(Meta.Enc.GetBytes(value));
				if (navRoute != null)
				{
					navRoute.Name = (dictionary.ContainsKey("metaRouteName") ? dictionary["metaRouteName"] : "[meta] route");
					navRoute.File = "";
					if (dictionary.TryGetValue("metaRouteMode", out value) && int.TryParse(value, NumberStyles.Integer, HCI, out var result3))
					{
						navRoute.Mode = result3;
					}
					_metaRoute = navRoute;
					_metaRouteSrc = FindEmbeddedSrc(navRoute.Name);
				}
			}
			if (dictionary.TryGetValue("rName", out var value3) && value3.Length > 0 && CurrentRoute != null && string.Equals(CurrentRoute.Name, value3, StringComparison.Ordinal))
			{
				_rName = value3;
				RouteReset();
				_rIdx = (int)Num(dictionary, "rIdx");
				_rDir = (int)Num(dictionary, "rDir");
				if (_rDir == 0)
				{
					_rDir = 1;
				}
				_rDone = dictionary.ContainsKey("rDone") && dictionary["rDone"] == "1";
				_rStarted = dictionary.ContainsKey("rStarted") && dictionary["rStarted"] == "1";
				_rSub = (int)Num(dictionary, "rSub");
				_rSubFor = (int)Num(dictionary, "rSubFor");
				if (_rIdx < 0 || _rIdx >= CurrentRoute.Steps.Count)
				{
					_rIdx = 0;
				}
				_resumeNearest = false;
				list.Add("route " + value3 + " at step " + (_rIdx + 1));
			}
			if (list.Count > 0)
			{
				Util.WriteToChat("Nav: carried on after the reload - " + string.Join(", ", list.ToArray()) + ".");
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static double Num(Dictionary<string, string> d, string k)
	{
		string value;
		double result;
		return (d.TryGetValue(k, out value) && double.TryParse(value, NumberStyles.Float, HCI, out result)) ? result : 0.0;
	}

	private MVal FindEmbeddedSrc(string routeName)
	{
		if (_meta == null)
		{
			return null;
		}
		string bare = (routeName.StartsWith("[meta] ", StringComparison.Ordinal) ? routeName.Substring(7) : routeName);
		MVal found = null;
		Action<MAct> walk = null;
		walk = (MAct a) =>
		{
			if (a != null && found == null)
			{
				if (a.Type == 4 && a.Data != null && a.Data.B != null)
				{
					MetaText.NavSummary(a.Data.B, out var name, out var _);
					string a2 = ((name.Length > 0) ? Path.GetFileNameWithoutExtension(name) : "");
					if (string.Equals(a2, bare, StringComparison.OrdinalIgnoreCase))
					{
						found = a.Data;
					}
				}
				if (a.Kids != null)
				{
					foreach (MAct kid in a.Kids)
					{
						walk(kid);
					}
				}
			}
		};
		foreach (MRule rule in _meta.Rules)
		{
			walk(rule.A);
		}
		return found;
	}

	private NavRoute MapRoute()
	{
		return _s.NavRoutes.Find((NavRoute x) => string.Equals(x.Name, "Map route", StringComparison.OrdinalIgnoreCase));
	}

	public void MapRouteCommand(string rest)
	{
		string[] array = (rest ?? "").Trim().Split(new char[1] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
		if (array.Length == 0)
		{
			Util.WriteToChat("Map route: /mtank maproute add <ns> <ew> [z] | clear");
			return;
		}
		NavRoute navRoute = MapRoute();
		if (array[0].Equals("clear", StringComparison.OrdinalIgnoreCase))
		{
			if (navRoute != null)
			{
				bool flag = CurrentRoute == navRoute;
				navRoute.Steps.Clear();
				navRoute.Mode = 0;
				if (flag)
				{
					Stop();
					RouteReset();
				}
				RouteChanged();
				if (SaveAll != null)
				{
					SaveAll();
				}
			}
			PublishMapRoute(now: true);
			Util.WriteToChat("Map route cleared.");
			return;
		}
		double result = 0.0;
		if (!array[0].Equals("add", StringComparison.OrdinalIgnoreCase) || array.Length < 3 || !double.TryParse(array[1], NumberStyles.Float, MCI, out var result2) || !double.TryParse(array[2], NumberStyles.Float, MCI, out var result3))
		{
			Util.WriteToChat("Map route: /mtank maproute add <ns> <ew> [z] | clear");
			return;
		}
		if (array.Length > 3)
		{
			double.TryParse(array[3], NumberStyles.Float, MCI, out result);
		}
		if (_travelRoute != null)
		{
			Util.WriteToChat("Map route: auto travel is running - stop it first.");
			return;
		}
		bool flag2 = false;
		if (navRoute == null)
		{
			navRoute = new NavRoute
			{
				Name = "Map route",
				Mode = 0
			};
			_s.NavRoutes.Add(navRoute);
			flag2 = true;
		}
		else if (CurrentRoute != navRoute || _rDone || navRoute.Steps.Count == 0)
		{
			navRoute.Steps.Clear();
			navRoute.Mode = 0;
			flag2 = true;
		}
		navRoute.Steps.Add(new RouteStep
		{
			Kind = StepKind.Point,
			NS = result2,
			EW = result3,
			Z = result
		});
		bool flag3 = _s.NavMode == 1 && string.Equals(_s.NavRouteSelected, navRoute.Name, StringComparison.OrdinalIgnoreCase);
		_s.NavMode = 1;
		_s.NavRouteSelected = navRoute.Name;
		if (flag2 || !flag3)
		{
			Stop();
			RouteReset();
			_rSel = -1;
		}
		else if (_rDone)
		{
			_rDone = false;
		}
		RouteChanged();
		if (SaveAll != null)
		{
			SaveAll();
		}
		PublishMapRoute(now: true);
		int count = navRoute.Steps.Count;
		Util.WriteToChat("Map route: point " + count + " added" + ((count == 1) ? " (a new route)" : "") + (_s.NavEnabled ? "." : " - turn Nav on to run it."));
	}

	public void PublishMapRoute(bool now)
	{
		if (!now && (DateTime.Now - _mapPubAt).TotalSeconds < 1.0)
		{
			return;
		}
		_mapPubAt = DateTime.Now;
		string text = "";
		try
		{
			NavRoute navRoute = MapRoute();
			if (navRoute != null && CurrentRoute == navRoute && _s.NavMode == 1)
			{
				StringBuilder stringBuilder = new StringBuilder();
				foreach (RouteStep step in navRoute.Steps)
				{
					if (step.Kind == StepKind.Point)
					{
						stringBuilder.Append(step.NS.ToString("R", MCI)).Append(',').Append(step.EW.ToString("R", MCI))
							.Append(',')
							.Append(step.Z.ToString("0.##", MCI))
							.Append(';');
					}
				}
				text = stringBuilder.ToString();
			}
		}
		catch
		{
		}
		if (text == _mapPublished)
		{
			return;
		}
		_mapPublished = text;
		try
		{
			AppDomain.CurrentDomain.SetData("MelkTank.MapRoute", text);
		}
		catch
		{
		}
	}

	public bool OpenMeta(string path)
	{
		try
		{
			_meta = Meta.Load(path);
			_metaState = _meta.States()[0];
			_metaEdit = -1;
			_s.MetaLast = path;
			if (SaveAll != null)
			{
				SaveAll();
			}
			Util.WriteToChat("Meta: " + _meta.Name + " loaded - " + _meta.Rules.Count + " rules in " + _meta.States().Count + " states (Nav > Meta).");
			return true;
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Meta: can't read " + Path.GetFileName(path) + ": " + ex.Message);
			return false;
		}
	}

	private void DrawMetaPicker()
	{
		ImGui.SameLine();
		bool v = _s.MetaVtankDir;
		if (VtankDir == null)
		{
			ImGui.BeginDisabled();
		}
		if (ImGui.Checkbox("VTank folder##metapickvt", ref v))
		{
			_s.MetaVtankDir = v;
			_metaTreeAt = DateTime.MinValue;
			_pickListAt = DateTime.MinValue;
			if (SaveAll != null)
			{
				SaveAll();
			}
		}
		if (VtankDir == null)
		{
			ImGui.EndDisabled();
		}
		Tip((VtankDir == null) ? "VTank's folder wasn't found." : ("Ticked: the list shows VTank's metas (" + VtankDir + ").\nUnticked: MelkTank's Metas folder."));
		string dir = ((_s.MetaVtankDir && VtankDir != null) ? VtankDir : MetaDir);
		if (_pickListVt != _s.MetaVtankDir || (DateTime.Now - _pickListAt).TotalSeconds > 5.0)
		{
			_pickListVt = _s.MetaVtankDir;
			_pickListAt = DateTime.Now;
			_pickList = new List<string>();
			try
			{
				string[] files = Directory.GetFiles(dir, "*.*", SearchOption.AllDirectories);
				foreach (string text in files)
				{
					string text2 = Path.GetExtension(text).ToLowerInvariant();
					if (text2 == ".met" || text2 == ".mtmet")
					{
						_pickList.Add(text);
					}
				}
				_pickList.Sort((string a, string b) => string.Compare(a.Substring(dir.Length), b.Substring(dir.Length), StringComparison.OrdinalIgnoreCase));
			}
			catch
			{
			}
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(240f);
		string text3 = ((_meta != null && !string.IsNullOrEmpty(_meta.File) && _meta.File.StartsWith(dir, StringComparison.OrdinalIgnoreCase)) ? _meta.File.Substring(dir.Length).TrimStart(new char[2] { '\\', '/' }) : ("load a meta (" + _pickList.Count + ")..."));
		if (ImGui.BeginCombo("##metapick", text3))
		{
			if (_pickList.Count == 0)
			{
				Im.TextColored(Grey, "No metas in " + dir);
			}
			foreach (string pick in _pickList)
			{
				string text4 = pick.Substring(dir.Length).TrimStart(new char[2] { '\\', '/' });
				bool flag = _meta != null && string.Equals(_meta.File, pick, StringComparison.OrdinalIgnoreCase);
				if (ImGui.Selectable(text4 + "##mp" + text4, flag) && !flag)
				{
					if (_meta != null && _meta.Dirty)
					{
						Util.WriteToChat("Meta: " + _meta.Name + " had unsaved changes - they're gone.");
					}
					OpenMeta(pick);
				}
			}
			ImGui.EndCombo();
		}
		Tip("Opens a meta from " + (_s.MetaVtankDir ? "VTank's" : "MelkTank's Metas") + " folder (subfolders included). A running meta switches to it, from Default.");
	}

	private void MetaChanged()
	{
		if (_meta != null)
		{
			_meta.Dirty = true;
		}
	}

	public void DrawMeta()
	{
		try
		{
			DrawMetaTab();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void DrawMetaTab()
	{
		if (!_metaTriedLast)
		{
			_metaTriedLast = true;
			if (_meta == null && _s.MetaOpenLast && !string.IsNullOrEmpty(_s.MetaLast) && File.Exists(_s.MetaLast))
			{
				OpenMeta(_s.MetaLast);
			}
		}
		if (ImGui.Button("New meta"))
		{
			_meta = new Meta
			{
				Name = "New meta"
			};
			_meta.Rules.Add(new MRule());
			_metaState = "Default";
			_metaEdit = 0;
			_meta.Dirty = true;
		}
		Tip("Starts an empty meta (one 'always -> send' rule in Default to change).");
		DrawMetaPicker();
		if (_meta == null)
		{
			ImGui.SameLine();
			Im.TextColored(Grey, "No meta open - load one in Nav > Settings > Meta files, or start a new one.");
			return;
		}
		ImGui.SameLine();
		Im.TextColored(_meta.Dirty ? Yellow : Cyan, _meta.Name + (_meta.Dirty ? " *" : ""));
		if (_meta.File.Length > 0)
		{
			ImGui.SameLine();
			Im.TextColored(Grey, _meta.File);
		}
		string input = _meta.Name;
		ImGui.SetNextItemWidth(200f);
		if (ImGui.InputText("Name##metaname", ref input, 80u))
		{
			_meta.Name = input;
			MetaChanged();
		}
		ImGui.SameLine();
		if (ImGui.Button("Save (.mtmet)"))
		{
			SaveMeta(vtank: false);
		}
		Tip("MelkTank's meta file, in Metas (or the folder the meta came from). Same layout as VTank's.");
		ImGui.SameLine();
		if (ImGui.Button("Save as VTank .met"))
		{
			SaveMeta(vtank: true);
		}
		Tip("A .met VTank can load. Anything only MelkTank can do is listed in chat and left out.");
		int num = CountVtSettings();
		if (num > 0)
		{
			ImGui.SameLine();
			if (ImGui.Button("Convert VTank settings (" + num + ")##metavtconv"))
			{
				ConvertVtSettings();
			}
			Tip("This meta's expressions use vtsetsetting / vtgetsetting, which need VTank loaded.\nThis rewrites them for MelkTank:\n  $X = tostring[vtgetsetting[EnableCombat]]   ->  Get MT option combat into X\n  vtsetsetting[EnableCombat, $X]              ->  Set MT option combat from variable $X\n  vtsetsetting[EnableCombat, 0] (inside others) ->  chatbox[/vt opt set EnableCombat 0] (MelkTank does it)\nAnything else is left alone and listed in chat. Save as .mtmet afterwards.");
		}
		if (_meta.File.Length > 0)
		{
			ImGui.SameLine();
			if (ImGui.Button("Reload"))
			{
				OpenMeta(_meta.File);
			}
			Tip("Throws away unsaved changes and reads the file again.");
		}
		bool v = MetaRunning;
		if (ImGui.Checkbox("Run this meta##metarun", ref v))
		{
			if (v)
			{
				MetaStart();
			}
			else
			{
				MetaStop();
			}
		}
		Tip("/mt meta on|off  -  /mt meta load <name>  -  /mt meta state <name>");
		ImGui.SameLine();
		MRule mRule = ((_metaEdit >= 0 && _metaEdit < _meta.Rules.Count && _meta.Rules[_metaEdit].State == _metaState) ? _meta.Rules[_metaEdit] : null);
		if (ImGui.Button("Start meta here##metahere"))
		{
			MetaStartAt(_metaState, mRule);
			v = true;
		}
		Tip("Runs the meta from the state shown (" + _metaState + ")" + ((mRule != null) ? ", starting at the rule being edited (the ones above it are skipped this visit)." : ".") + "\nPick a rule (click it) to start part way down a state.");
		Tip("Runs the meta the VTank way: in its current state, the first rule whose condition is true does its action\n(each rule once per visit to the state). Edits take effect straight away. /mtank meta on | off works too.\nDon't run the same meta in VTank at the same time.");
		if (v)
		{
			ImGui.SameLine();
			Im.TextColored(Green, "in state " + _mState + "  (" + (int)(DateTime.Now - _mStateAt).TotalSeconds + " s)");
			if (_metaState != _mState)
			{
				ImGui.SameLine();
				if (ImGui.SmallButton("go to " + _metaState + "##metago"))
				{
					MetaSetState(_metaState, persistReset: true);
				}
				Tip("Switches the running meta to the state picked in the list.");
			}
			ImGui.SameLine();
			if (ImGui.SmallButton("show running state##metashow"))
			{
				_metaState = _mState;
				_metaEdit = -1;
			}
			if (!UbExpr.Ready)
			{
				ImGui.SameLine();
				Im.TextColored(Red, "UtilityBelt not found - expressions are false");
			}
		}
		if (MetaLog.Count > 0 && ImGui.CollapsingHeader("What the meta did##metalog"))
		{
			if (ImGui.BeginChild("##metalogc", new System.Numerics.Vector2(0f, 110f), border: true))
			{
				for (int num2 = MetaLog.Count - 1; num2 >= 0; num2--)
				{
					ImGui.TextUnformatted(MetaLog[num2]);
				}
			}
			ImGui.EndChild();
			if (ImGui.SmallButton("clear##metalogclr"))
			{
				MetaLog.Clear();
			}
		}
		List<string> list = _meta.States();
		if (!list.Contains(_metaState))
		{
			_metaState = list[0];
		}
		if (ImGui.BeginChild("##metastates", new System.Numerics.Vector2(210f, 0f), border: true))
		{
			Im.TextColored(Cyan, "States");
			foreach (string st in list)
			{
				int count = _meta.Rules.FindAll((MRule r) => r.State == st).Count;
				bool flag = v && st == _mState;
				if (flag)
				{
					ImGui.PushStyleColor(ImGuiCol.Text, Green);
				}
				if (ImGui.Selectable((flag ? "> " : "") + st + "  (" + count + ")##ms" + st, st == _metaState))
				{
					_metaState = st;
					_metaEdit = -1;
					_metaRename = st;
				}
				if (flag)
				{
					ImGui.PopStyleColor();
					Tip("The running meta is in this state.");
				}
			}
			ImGui.Separator();
			ImGui.SetNextItemWidth(-1f);
			ImGui.InputTextWithHint("##newstate", "new state name", ref _metaNewState, 64u);
			if (ImGui.SmallButton("Add state") && _metaNewState.Trim().Length > 0 && !list.Contains(_metaNewState.Trim()))
			{
				MRule mRule2 = new MRule
				{
					State = _metaNewState.Trim()
				};
				_meta.Rules.Add(mRule2);
				_metaState = mRule2.State;
				_metaEdit = _meta.Rules.Count - 1;
				_metaNewState = "";
				MetaChanged();
			}
			Tip("A state needs at least one rule - it's made with an 'always -> send' rule to change.");
			ImGui.SetNextItemWidth(-1f);
			if (_metaRename.Length == 0)
			{
				_metaRename = _metaState;
			}
			ImGui.InputText("##renamestate", ref _metaRename, 64u);
			if (ImGui.SmallButton("Rename state") && _metaRename.Trim().Length > 0 && _metaRename.Trim() != _metaState)
			{
				RenameState(_metaState, _metaRename.Trim());
				_metaState = _metaRename.Trim();
				MetaChanged();
			}
			Tip("Renames the state and every 'go to' / 'call' that points at it.");
		}
		ImGui.EndChild();
		ImGui.SameLine();
		if (ImGui.BeginChild("##metarules", new System.Numerics.Vector2(0f, 0f), border: true))
		{
			Im.TextColored(Cyan, "In " + _metaState + ":");
			ImGui.SameLine();
			Im.TextColored(Grey, "rules are checked top to bottom");
			int num3 = -1;
			int num4 = -1;
			int num5 = -1;
			int num6 = -1;
			List<int> list2 = new List<int>();
			for (int num7 = 0; num7 < _meta.Rules.Count; num7++)
			{
				if (_meta.Rules[num7].State == _metaState)
				{
					list2.Add(num7);
				}
			}
			if (ImGui.BeginTable("##metarulestbl", 4, ImGuiTableFlags.SizingStretchProp | ImGuiTableFlags.RowBg | ImGuiTableFlags.BordersInnerH, new System.Numerics.Vector2(ImGui.GetContentRegionAvail().X - 18f, 0f)))
			{
				ImGui.TableSetupColumn("When", ImGuiTableColumnFlags.WidthStretch, 1f);
				ImGui.TableSetupColumn("Do", ImGuiTableColumnFlags.WidthStretch, 1f);
				ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 52f);
				ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 96f);
				for (int num8 = 0; num8 < list2.Count; num8++)
				{
					int num9 = list2[num8];
					MRule mRule3 = _meta.Rules[num9];
					ImGui.TableNextRow();
					ImGui.PushID(num9);
					ImGui.TableSetColumnIndex(0);
					if (mRule3.C.Type == 0 || mRule3.C.Type == 1)
					{
						bool v2 = mRule3.C.Type == 1;
						if (ImGui.Checkbox("##onoff", ref v2))
						{
							mRule3.C.Type = (v2 ? 1 : 0);
							mRule3.C.Data = MVal.Int(0);
							mRule3.C.Kids = null;
							MetaChanged();
						}
						Tip("Ticked: always. Unticked: never (the rule is switched off).");
						ImGui.SameLine();
					}
					ImGui.PushTextWrapPos(0f);
					System.Numerics.Vector4 col;
					if (num9 == _metaEdit)
					{
						col = Yellow;
					}
					else
					{
						col = ((mRule3.C.Type == 0) ? Grey : System.Numerics.Vector4.One);
					}
					Im.TextColored(col, MetaText.Describe(mRule3.C));
					ImGui.PopTextWrapPos();
					if (ImGui.IsItemClicked())
					{
						_metaEdit = ((num9 == _metaEdit) ? (-1) : num9);
					}
					if (ImGui.IsItemHovered())
					{
						Im.SetTooltip("Click to edit this rule (again to close it).");
					}
					ImGui.TableSetColumnIndex(1);
					ImGui.PushTextWrapPos(0f);
					System.Numerics.Vector4 col2;
					if (num9 == _metaEdit)
					{
						col2 = Yellow;
					}
					else
					{
						col2 = ((mRule3.A.Type == 1 || mRule3.A.Type == 5) ? Green : Cyan);
					}
					Im.TextColored(col2, MetaText.Describe(mRule3.A));
					ImGui.PopTextWrapPos();
					if (ImGui.IsItemClicked())
					{
						_metaEdit = ((num9 == _metaEdit) ? (-1) : num9);
					}
					string text;
					if (mRule3.A.Type == 1 && mRule3.A.Data != null)
					{
						text = mRule3.A.Data.S;
					}
					else
					{
						text = ((mRule3.A.Type == 5 && mRule3.A.Data != null) ? mRule3.A.Data.GetS("st") : null);
					}
					if (ImGui.IsItemHovered())
					{
						Im.SetTooltip("Click to edit this rule." + ((text != null) ? ("\nRight-click to show state " + text + ".") : ""));
					}
					if (text != null && ImGui.IsItemClicked(ImGuiMouseButton.Right) && list.Contains(text))
					{
						_metaState = text;
						_metaEdit = -1;
						_metaRename = text;
					}
					ImGui.TableSetColumnIndex(2);
					if (num8 > 0)
					{
						if (Im.UpButton("##mup"))
						{
							num3 = num9;
						}
						ImGui.SameLine();
					}
					if (num8 < list2.Count - 1 && Im.DownButton("##mdn"))
					{
						num4 = num9;
					}
					ImGui.TableSetColumnIndex(3);
					if (ImGui.SmallButton((num9 == _metaEdit) ? "done" : "edit"))
					{
						_metaEdit = ((num9 == _metaEdit) ? (-1) : num9);
					}
					ImGui.SameLine();
					if (ImGui.SmallButton("+"))
					{
						num6 = num9;
					}
					Tip("Copy this rule (below it).");
					ImGui.SameLine();
					if (ImGui.SmallButton("x"))
					{
						num5 = num9;
					}
					ImGui.PopID();
				}
				ImGui.EndTable();
			}
			if (ImGui.Button("Add rule"))
			{
				int num10 = ((list2.Count > 0) ? (list2[list2.Count - 1] + 1) : _meta.Rules.Count);
				_meta.Rules.Insert(num10, new MRule
				{
					State = _metaState
				});
				_metaEdit = num10;
				MetaChanged();
			}
			bool far = Im.Far;
			Im.Far = false;
			if (num3 >= 0)
			{
				int num11 = PrevInState(num3);
				Swap(num3, num11);
				while (far && num11 != num3)
				{
					num3 = num11;
					num11 = PrevInState(num3);
					Swap(num3, num11);
				}
			}
			if (num4 >= 0)
			{
				int num12 = NextInState(num4);
				Swap(num4, num12);
				while (far && num12 != num4)
				{
					num4 = num12;
					num12 = NextInState(num4);
					Swap(num4, num12);
				}
			}
			if (num6 >= 0)
			{
				MRule mRule4 = _meta.Rules[num6];
				_meta.Rules.Insert(num6 + 1, new MRule
				{
					C = mRule4.C.Clone(),
					A = mRule4.A.Clone(),
					State = mRule4.State
				});
				_metaEdit = num6 + 1;
				MetaChanged();
			}
			if (num5 >= 0)
			{
				_meta.Rules.RemoveAt(num5);
				if (_metaEdit == num5)
				{
					_metaEdit = -1;
				}
				else if (_metaEdit > num5)
				{
					_metaEdit--;
				}
				MetaChanged();
			}
			if (_metaEdit >= 0 && _metaEdit < _meta.Rules.Count && _meta.Rules[_metaEdit].State == _metaState)
			{
				ImGui.Separator();
				MRule mRule5 = _meta.Rules[_metaEdit];
				bool flag2 = false;
				Im.TextColored(Yellow, "Editing the rule in state");
				ImGui.SameLine();
				string state = mRule5.State;
				ImGui.SetNextItemWidth(180f);
				if (ImGui.BeginCombo("##rstate", state))
				{
					foreach (string item in list)
					{
						if (ImGui.Selectable(item, item == state))
						{
							mRule5.State = item;
							_metaState = item;
							flag2 = true;
						}
					}
					ImGui.EndCombo();
				}
				Tip("Pick another state to move the rule there.");
				ImGui.SameLine();
				if (ImGui.SmallButton("done##editdone"))
				{
					_metaEdit = -1;
				}
				Im.TextColored(Cyan, "When");
				flag2 |= DrawCond(mRule5.C, "c", 0, list);
				Im.TextColored(Cyan, "Do");
				if (flag2 | DrawAct(mRule5.A, "a", 0, list))
				{
					MetaChanged();
				}
			}
		}
		ImGui.EndChild();
	}

	private int PrevInState(int i)
	{
		for (int num = i - 1; num >= 0; num--)
		{
			if (_meta.Rules[num].State == _meta.Rules[i].State)
			{
				return num;
			}
		}
		return i;
	}

	private int NextInState(int i)
	{
		for (int j = i + 1; j < _meta.Rules.Count; j++)
		{
			if (_meta.Rules[j].State == _meta.Rules[i].State)
			{
				return j;
			}
		}
		return i;
	}

	private void Swap(int a, int b)
	{
		if (a != b)
		{
			MRule value = _meta.Rules[a];
			_meta.Rules[a] = _meta.Rules[b];
			_meta.Rules[b] = value;
			if (_metaEdit == a)
			{
				_metaEdit = b;
			}
			else if (_metaEdit == b)
			{
				_metaEdit = a;
			}
			MetaChanged();
		}
	}

	private void RenameState(string from, string to)
	{
		foreach (MRule rule in _meta.Rules)
		{
			if (rule.State == from)
			{
				rule.State = to;
			}
			RenameIn(rule.A, from, to);
		}
	}

	private static void RenameIn(MAct a, string from, string to)
	{
		if (a.Kids != null)
		{
			foreach (MAct kid in a.Kids)
			{
				RenameIn(kid, from, to);
			}
			return;
		}
		if (a.Data == null)
		{
			return;
		}
		if (a.Type == 1 && a.Data.S == from)
		{
			a.Data.S = to;
		}
		if (a.Type != 5 && a.Type != 9)
		{
			return;
		}
		string[] array = new string[3] { "st", "ret", "s" };
		foreach (string key in array)
		{
			MVal mVal = a.Data.Get(key);
			if (mVal != null && mVal.S == from)
			{
				mVal.S = to;
			}
		}
	}

	private bool StatePicker(string label, ref string val, List<string> states)
	{
		bool result = false;
		ImGui.SetNextItemWidth(180f);
		if (ImGui.BeginCombo("##pick" + label, string.IsNullOrEmpty(val) ? "(pick a state)" : val))
		{
			foreach (string state in states)
			{
				if (ImGui.Selectable(state, state == val))
				{
					val = state;
					result = true;
				}
			}
			ImGui.EndCombo();
		}
		uint iD = ImGui.GetID(label);
		if (!_newStateBuf.TryGetValue(iD, out var value))
		{
			value = "";
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(140f);
		bool flag = ImGui.InputTextWithHint("##new" + label, "or a new state", ref value, 64u, ImGuiInputTextFlags.EnterReturnsTrue);
		ImGui.SameLine();
		if ((ImGui.SmallButton("use##use" + label) | flag) && value.Trim().Length > 0)
		{
			val = value.Trim();
			value = "";
			result = true;
			if (_meta != null && !states.Contains(val))
			{
				_meta.Rules.Add(new MRule
				{
					State = val
				});
				states.Add(val);
				MetaChanged();
				Util.WriteToChat("Meta: state " + val + " made - click it in the states list to give it its rules.");
			}
		}
		Tip("Uses the typed name. A state that doesn't exist yet is made, with one rule to change.");
		_newStateBuf[iD] = value;
		int num = label.IndexOf("##", StringComparison.Ordinal);
		string text = ((num >= 0) ? label.Substring(0, num) : label);
		if (text.Length > 0)
		{
			ImGui.SameLine();
			ImGui.TextUnformatted(text);
		}
		return result;
	}

	private static string SelectedName(bool monster)
	{
		return SelectedName(monster ? "monster" : "item");
	}

	private static string SelectedName(string kind)
	{
		try
		{
			WorldObject worldObject = Globals.Core.WorldFilter[Globals.Core.Actions.CurrentSelection];
			if (worldObject == null)
			{
				Util.WriteToChat("Meta: nothing selected.");
				return "";
			}
			bool num;
			switch (kind)
			{
			case "portal":
				num = worldObject.ObjectClass == ObjectClass.Portal;
				goto IL_0098;
			case "NPC":
				if (worldObject.ObjectClass == ObjectClass.Npc)
				{
					break;
				}
				num = worldObject.ObjectClass == ObjectClass.Vendor;
				goto IL_0098;
			case "monster":
				{
					num = worldObject.ObjectClass == ObjectClass.Monster;
					goto IL_0098;
				}
				IL_0098:
				if (!num)
				{
					Util.WriteToChat("Meta: select a " + kind + " first.");
					return "";
				}
				break;
			}
			return worldObject.Name ?? "";
		}
		catch
		{
			return "";
		}
	}

	private static List<KeyValuePair<int, string>> TimedSpells()
	{
		List<KeyValuePair<int, string>> list = new List<KeyValuePair<int, string>>();
		HashSet<int> hashSet = new HashSet<int>();
		try
		{
			foreach (EnchantmentWrapper enchantment in Globals.Core.CharacterFilter.Enchantments)
			{
				if (enchantment.TimeRemaining > 0 && hashSet.Add(enchantment.SpellId))
				{
					string text = SpellNames.Name(enchantment.SpellId);
					if (string.IsNullOrEmpty(text))
					{
						text = "spell " + enchantment.SpellId;
					}
					int num = enchantment.TimeRemaining / 60;
					list.Add(new KeyValuePair<int, string>(enchantment.SpellId, text + "  (" + ((num >= 60) ? (num / 60 + "h " + num % 60 + "m") : (num + "m " + enchantment.TimeRemaining % 60 + "s")) + " left)"));
				}
			}
		}
		catch
		{
		}
		list.Sort((KeyValuePair<int, string> a, KeyValuePair<int, string> b) => string.Compare(a.Value, b.Value, StringComparison.OrdinalIgnoreCase));
		return list;
	}

	private static string[] CondNames()
	{
		List<string> list = new List<string>();
		MetaText.TypeDef[] conds = MetaText.Conds;
		foreach (MetaText.TypeDef typeDef in conds)
		{
			list.Add(typeDef.Name);
		}
		return list.ToArray();
	}

	private static string[] ActNames()
	{
		List<string> list = new List<string>();
		MetaText.TypeDef[] acts = MetaText.Acts;
		foreach (MetaText.TypeDef typeDef in acts)
		{
			list.Add(typeDef.Name);
		}
		return list.ToArray();
	}

	private bool DrawCond(MCond c, string id, int depth, List<string> states)
	{
		bool flag = false;
		ImGui.PushID(id);
		int current_item = Array.FindIndex(MetaText.Conds, (MetaText.TypeDef t) => t.Id == c.Type);
		ImGui.SetNextItemWidth(230f);
		if (ImGui.Combo("##ct", ref current_item, _condNames, _condNames.Length))
		{
			MetaText.TypeDef typeDef = MetaText.Conds[current_item];
			c.Type = typeDef.Id;
			c.Data = MetaText.NewData(typeDef);
			c.Kids = ((typeDef.Data == "kids") ? new List<MCond>
			{
				new MCond
				{
					Type = 1
				}
			} : null);
			flag = true;
		}
		MetaText.TypeDef typeDef2 = MetaText.Cond(c.Type);
		if (typeDef2 != null)
		{
			Tip(typeDef2.Help);
		}
		if (c.Kids != null)
		{
			ImGui.Indent(18f);
			int num = -1;
			int num2 = -1;
			int num3 = -1;
			for (int num4 = 0; num4 < c.Kids.Count; num4++)
			{
				flag |= DrawCond(c.Kids[num4], id + "_" + num4, depth + 1, states);
				ImGui.SameLine();
				if (num4 > 0)
				{
					if (Im.UpButton("##cup" + num4))
					{
						num2 = num4;
					}
					ImGui.SameLine();
				}
				if (num4 < c.Kids.Count - 1)
				{
					if (Im.DownButton("##cdn" + num4))
					{
						num3 = num4;
					}
					ImGui.SameLine();
				}
				if (ImGui.SmallButton("x##cdel" + num4))
				{
					num = num4;
				}
			}
			if (num2 > 0)
			{
				Im.Move(c.Kids, num2, up: true);
				flag = true;
			}
			if (num3 >= 0)
			{
				Im.Move(c.Kids, num3, up: false);
				flag = true;
			}
			if (num >= 0)
			{
				c.Kids.RemoveAt(num);
				flag = true;
			}
			if ((c.Type != 21 || c.Kids.Count == 0) && ImGui.SmallButton("+ condition"))
			{
				c.Kids.Add(new MCond
				{
					Type = 1
				});
				flag = true;
			}
			ImGui.Unindent(18f);
		}
		else
		{
			flag |= DrawData(c.Data, typeDef2, act: false, states);
		}
		ImGui.PopID();
		return flag;
	}

	private bool DrawAct(MAct a, string id, int depth, List<string> states)
	{
		bool flag = false;
		ImGui.PushID(id);
		int current_item = Array.FindIndex(MetaText.Acts, (MetaText.TypeDef t) => t.Id == a.Type);
		ImGui.SetNextItemWidth(230f);
		if (ImGui.Combo("##at", ref current_item, _actNames, _actNames.Length))
		{
			MetaText.TypeDef typeDef = MetaText.Acts[current_item];
			a.Type = typeDef.Id;
			a.Data = MetaText.NewData(typeDef);
			a.Kids = ((typeDef.Data == "kids") ? new List<MAct>
			{
				new MAct
				{
					Type = 2,
					Data = MVal.Str("")
				}
			} : null);
			flag = true;
		}
		MetaText.TypeDef typeDef2 = MetaText.Act(a.Type);
		if (typeDef2 != null)
		{
			Tip(typeDef2.Help);
		}
		if (a.Kids != null)
		{
			ImGui.Indent(18f);
			int num = -1;
			int num2 = -1;
			int num3 = -1;
			for (int num4 = 0; num4 < a.Kids.Count; num4++)
			{
				flag |= DrawAct(a.Kids[num4], id + "_" + num4, depth + 1, states);
				ImGui.SameLine();
				if (num4 > 0)
				{
					if (Im.UpButton("##aup" + num4))
					{
						num2 = num4;
					}
					ImGui.SameLine();
				}
				if (num4 < a.Kids.Count - 1)
				{
					if (Im.DownButton("##adn" + num4))
					{
						num3 = num4;
					}
					ImGui.SameLine();
				}
				if (ImGui.SmallButton("x##adel" + num4))
				{
					num = num4;
				}
			}
			if (num2 > 0)
			{
				Im.Move(a.Kids, num2, up: true);
				flag = true;
			}
			if (num3 >= 0)
			{
				Im.Move(a.Kids, num3, up: false);
				flag = true;
			}
			if (num >= 0)
			{
				a.Kids.RemoveAt(num);
				flag = true;
			}
			if (ImGui.SmallButton("+ action"))
			{
				a.Kids.Add(new MAct
				{
					Type = 2,
					Data = MVal.Str("")
				});
				flag = true;
			}
			ImGui.Unindent(18f);
		}
		else
		{
			flag |= DrawData(a.Data, typeDef2, act: true, states);
		}
		ImGui.PopID();
		return flag;
	}

	private bool DrawData(MVal d, MetaText.TypeDef def, bool act, List<string> states)
	{
		if (d == null || def == null)
		{
			return false;
		}
		bool result = false;
		string data = def.Data;
		string text = data;
		if (text == null || text.Length != 0)
		{
			switch (text)
			{
			case "i":
			{
				ImGui.SameLine();
				int v3 = d.AsInt;
				ImGui.SetNextItemWidth(120f);
				if (ImGui.InputInt("##di", ref v3))
				{
					d.T = "i";
					d.S = v3.ToString();
					result = true;
				}
				return result;
			}
			case "hex":
			{
				ImGui.SameLine();
				string input6 = ((uint)d.AsInt).ToString("X8");
				ImGui.SetNextItemWidth(120f);
				if (ImGui.InputText("##dh", ref input6, 8u, ImGuiInputTextFlags.CharsHexadecimal) && uint.TryParse(input6, NumberStyles.HexNumber, null, out var result4))
				{
					d.T = "i";
					int num = (int)result4;
					d.S = num.ToString();
					result = true;
				}
				ImGui.SameLine();
				if (ImGui.SmallButton("here"))
				{
					try
					{
						uint num2 = (uint)Globals.Core.Actions.Landcell;
						if (def.Id == 17)
						{
							num2 &= 0xFFFF0000u;
						}
						d.T = "i";
						int num = (int)num2;
						d.S = num.ToString();
						result = true;
					}
					catch
					{
					}
				}
				Tip("Where you're standing now.");
				return result;
			}
			case "s":
			{
				ImGui.SameLine();
				string input7 = d.S ?? "";
				if (act && def.Id == 1)
				{
					if (StatePicker("##ds", ref input7, states))
					{
						d.S = input7;
						result = true;
					}
				}
				else
				{
					ImGui.SetNextItemWidth(Math.Max(200f, ImGui.GetContentRegionAvail().X - 90f));
					if (ImGui.InputText("##ds", ref input7, 1000u))
					{
						d.S = input7;
						result = true;
					}
				}
				return result;
			}
			case "ba":
			{
				MetaText.NavSummary(d.B, out var name, out var points);
				bool flag2 = false;
				ImGui.SameLine();
				NavRoute currentRoute = CurrentRoute;
				ImGui.SetNextItemWidth(200f);
				if (ImGui.BeginCombo("##embedpick", "embed a route..."))
				{
					foreach (NavRoute navRoute in _s.NavRoutes)
					{
						if (ImGui.Selectable(navRoute.Name + ((navRoute == currentRoute) ? "  (loaded)" : "") + "##er" + navRoute.Name))
						{
							flag2 |= EmbedRoute(d, navRoute);
						}
					}
					ImGui.EndCombo();
				}
				Tip("Puts a copy of one of your routes (Nav > Routes) into the meta.");
				ImGui.SameLine();
				if (ImGui.SmallButton("embed loaded route") && currentRoute != null)
				{
					flag2 |= EmbedRoute(d, currentRoute);
				}
				Tip("Puts a copy of the route loaded in Nav > Routes" + ((currentRoute != null) ? (" (" + currentRoute.Name + ")") : "") + " into the meta.");
				MetaText.NavSummary(d.B, out name, out points);
				Im.TextColored(Grey, "In the meta: " + ((points > 0) ? (((name.Length > 0) ? name : "(unnamed)") + ", " + points + (IsMtRoute(d.B) ? " steps (MelkTank route, nothing dropped)" : " points (VTank nav)")) : "no route yet"));
				if (points > 0)
				{
					ImGui.SameLine();
					if (ImGui.SmallButton("copy to my routes"))
					{
						ImportEmbedded(d.B, name);
					}
					Tip("Makes a MelkTank route from the embedded one (Nav > Routes).");
				}
				return flag2;
			}
			case "kv":
			{
				if (def.Keys == null)
				{
					return false;
				}
				string[][] keys = def.Keys;
				foreach (string[] array in keys)
				{
					MVal mVal = d.Get(array[0]);
					if (mVal == null)
					{
						if (array[1] == "i")
						{
							mVal = MVal.Int(0);
						}
						else if (array[1] == "d")
						{
							mVal = MVal.Dbl(0.0);
						}
						else
						{
							mVal = ((array[1] == "ba") ? MVal.Bytes(new byte[0]) : MVal.Str(""));
						}
						d.Set(array[0], mVal);
					}
					string text2 = array[2] + "##k" + array[0];
					if (array[1] == "ba")
					{
						string input = Meta.Enc.GetString(mVal.B ?? new byte[0]);
						if (ImGui.InputTextMultiline(text2, ref input, 65000u, new System.Numerics.Vector2(-1f, 120f)))
						{
							mVal.B = Meta.Enc.GetBytes(input);
							result = true;
						}
					}
					else if (array[0] == "e")
					{
						string input2 = mVal.S ?? "";
						if (ImGui.InputTextMultiline(text2, ref input2, 8000u, new System.Numerics.Vector2(-1f, Math.Min(140, 22 + 15 * (input2.Length / 70 + 1)))))
						{
							mVal.S = input2;
							result = true;
						}
					}
					else if (array[0] == "st" || array[0] == "ret" || ((array[0] == "s") & act))
					{
						string val = mVal.S ?? "";
						if (StatePicker(text2, ref val, states))
						{
							mVal.S = val;
							result = true;
						}
					}
					else if (act && (def.Id == 11 || def.Id == 12) && array[0] == "o")
					{
						string text3 = mVal.S ?? "";
						ImGui.SetNextItemWidth(160f);
						if (ImGui.BeginCombo("switch##optpick", (MetaText.OptLabel(text3).Length > 0) ? MetaText.OptLabel(text3) : "(pick)"))
						{
							string[][] options = MetaText.Options;
							foreach (string[] array2 in options)
							{
								if (ImGui.Selectable(array2[1] + "##op" + array2[0], string.Equals(array2[0], text3, StringComparison.OrdinalIgnoreCase)))
								{
									mVal.T = "s";
									mVal.S = array2[0];
									result = true;
								}
							}
							ImGui.EndCombo();
						}
						Tip("MelkTank's own switches - a .met from VTank using VTank's option names (EnableCombat...) uses these too.");
					}
					else if (act && def.Id == 11 && array[0] == "v")
					{
						string input3 = mVal.S ?? "";
						ImGui.SetNextItemWidth(200f);
						if (ImGui.InputText(text2, ref input3, 100u))
						{
							mVal.S = input3.Trim();
							result = true;
						}
						if (ImGui.IsItemHovered())
						{
							Im.SetTooltip("The name of a meta variable to put the switch in: 1 when it's on, 0 when it's off.\nAny name made of letters, numbers and _ - e.g. combatwas\n\nRead it back in an expression (When: Expression, or Do: Expression) with getvar[name]:\n  getvar[combatwas] == 1                  true when combat was on\n  testvar[combatwas]                      true once the variable has been set\n  ifthen[getvar[combatwas] == 1, chatbox[`/mtank on`], 0]\n                                          turns combat back on if it was on\n  echo[cstr[getvar[combatwas]], 1]         shows it in chat\n\nTypical use - a turn-in in the middle of hunting:\n  1. Get MT option combat into combatwas\n  2. Set MT option combat off, go and hand in\n  3. Do: Expression  ifthen[getvar[combatwas] == 1, chatbox[`/mtank on`], 0]\n\n$ variables (getvar / setvar) are forgotten when you log out; @ (pvars) and & (gvars) are saved.\nsetpvar / getpvar keep one per character across logins.");
						}
					}
					else if (act && def.Id == 12 && array[0] == "v")
					{
						if ((mVal.S ?? "").StartsWith("$"))
						{
							string input4 = mVal.S;
							ImGui.SetNextItemWidth(160f);
							if (ImGui.InputText("from variable##optvar", ref input4, 100u))
							{
								mVal.T = "s";
								mVal.S = input4.Trim();
								result = true;
							}
							Tip("On when the variable is 1 / true, off when it's 0 / false (e.g. $combatwas from a Get MT option).");
							ImGui.SameLine();
							if (ImGui.SmallButton("fixed##optfix"))
							{
								mVal.T = "s";
								mVal.S = "1";
								result = true;
							}
							Tip("Use a fixed on / off instead.");
						}
						else
						{
							bool v = MetaText.IsOn(mVal.S);
							if (ImGui.Checkbox("on##optval", ref v))
							{
								mVal.T = "s";
								mVal.S = (v ? "1" : "0");
								result = true;
							}
							ImGui.SameLine();
							if (ImGui.SmallButton("from a variable##optfromvar"))
							{
								mVal.T = "s";
								mVal.S = "$";
								result = true;
							}
							Tip("Set it from a variable instead (e.g. $combatwas, filled by Get MT option).");
						}
					}
					else if (!act && def.Id == 23 && array[0] == "sid")
					{
						int v2 = mVal.AsInt;
						string text4 = ((v2 > 0) ? SpellNames.Name(v2) : "");
						ImGui.SetNextItemWidth(260f);
						string label = "##spellpick";
						string? text5;
						if (v2 <= 0)
						{
							text5 = "(a spell on you)";
						}
						else
						{
							text5 = (string.IsNullOrEmpty(text4) ? ("spell " + v2) : text4);
						}
						if (ImGui.BeginCombo(label, text5))
						{
							List<KeyValuePair<int, string>> list = TimedSpells();
							if (list.Count == 0)
							{
								Im.TextColored(Grey, "No timed spells on you.");
							}
							foreach (KeyValuePair<int, string> item in list)
							{
								if (ImGui.Selectable(item.Value + "##sp" + item.Key, item.Key == v2))
								{
									mVal.T = "i";
									mVal.S = item.Key.ToString();
									result = true;
								}
							}
							ImGui.EndCombo();
						}
						Tip("Spells on you right now that have a timer.");
						ImGui.SameLine();
						ImGui.SetNextItemWidth(90f);
						if (ImGui.InputInt("spell id##k" + array[0], ref v2, 0))
						{
							mVal.T = "i";
							mVal.S = v2.ToString();
							result = true;
						}
						Tip("Or type a spell id.");
					}
					else if (act && def.Id == 104 && array[0] == "n")
					{
						string cur = mVal.S ?? "";
						ImGui.SetNextItemWidth(320f);
						if (ImGui.BeginCombo("route##loadroute", (cur.Length > 0) ? cur : "(pick a route)"))
						{
							foreach (NavRoute navRoute2 in _s.NavRoutes)
							{
								if (ImGui.Selectable(navRoute2.Name + "##lr" + navRoute2.Name, string.Equals(navRoute2.Name, cur, StringComparison.OrdinalIgnoreCase)))
								{
									mVal.T = "s";
									mVal.S = navRoute2.Name;
									result = true;
								}
							}
							ImGui.EndCombo();
						}
						if (cur.Length > 0 && !_s.NavRoutes.Exists((NavRoute x2) => string.Equals(x2.Name, cur, StringComparison.OrdinalIgnoreCase)))
						{
							ImGui.SameLine();
							Im.TextColored(new System.Numerics.Vector4(1f, 0.5f, 0.3f, 1f), "no route with that name");
						}
					}
					else
					{
						string input5 = mVal.S ?? "";
						ImGui.SetNextItemWidth((array[1] == "s") ? 320 : 120);
						if (ImGui.InputText(text2, ref input5, 1000u))
						{
							if (array[1] == "i")
							{
								if (int.TryParse(input5, out var _))
								{
									mVal.T = "i";
									mVal.S = input5;
									result = true;
								}
							}
							else if (array[1] == "d")
							{
								if (double.TryParse(input5, NumberStyles.Float, CultureInfo.InvariantCulture, out var _))
								{
									mVal.T = "d";
									mVal.S = input5;
									result = true;
								}
							}
							else
							{
								mVal.S = input5;
								result = true;
							}
						}
						if (act && def.Id >= 100 && def.Id <= 103)
						{
							string text6;
							if (array[0] == "i" || def.Id == 100)
							{
								text6 = "item";
							}
							else
							{
								text6 = ((def.Id == 102) ? "portal" : "NPC");
							}
							ImGui.SameLine();
							if (ImGui.SmallButton("selected " + text6 + "##sel" + array[0]))
							{
								string text7 = SelectedName(text6);
								if (text7.Length > 0)
								{
									mVal.S = text7;
									result = true;
								}
							}
							Tip("Uses the name of the " + text6 + " you have selected.");
						}
						if (!act && array[0] == "n" && (def.Id == 11 || def.Id == 12 || def.Id == 13))
						{
							ImGui.SameLine();
							bool flag = def.Id == 13;
							if (ImGui.SmallButton((flag ? "selected monster" : "selected item") + "##sel" + array[0]))
							{
								string text8 = SelectedName(flag);
								if (text8.Length > 0)
								{
									mVal.S = (flag ? ("^" + Regex.Escape(text8) + "$") : text8);
									result = true;
								}
							}
							Tip(flag ? "Uses the name of the monster you have selected (matched exactly)." : "Uses the name of the item you have selected.");
						}
					}
				}
				return result;
			}
			default:
				return false;
			}
		}
		return false;
	}

	public static bool IsMtRoute(byte[] b)
	{
		if (b == null)
		{
			return false;
		}
		string text = Meta.Enc.GetString(b, 0, Math.Min(b.Length, 400));
		return text.IndexOf("<MelkTankRoute", StringComparison.Ordinal) >= 0;
	}

	private static string RouteXml(NavRoute r)
	{
		XmlDocument xmlDocument = new XmlDocument();
		XmlElement xmlElement = xmlDocument.CreateElement("MelkTankRoute");
		xmlDocument.AppendChild(xmlElement);
		Settings.WriteRoute(xmlDocument, xmlElement, NavPresets.Expanded(r));
		return xmlDocument.OuterXml;
	}

	public static NavRoute EmbeddedMtRoute(byte[] b)
	{
		try
		{
			string text = Meta.Enc.GetString(b);
			int num = text.IndexOf("<MelkTankRoute", StringComparison.Ordinal);
			if (num < 0)
			{
				return null;
			}
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.LoadXml(text.Substring(num));
			return Settings.ReadRoute(xmlDocument.DocumentElement);
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Meta: couldn't read the embedded route: " + ex.Message);
			return null;
		}
	}

	private static IEnumerable<KeyValuePair<object, MVal>> Exprs(Meta m)
	{
		List<KeyValuePair<object, MVal>> l = new List<KeyValuePair<object, MVal>>();
		Action<MCond> c = null;
		Action<MAct> a = null;
		c = (MCond x) =>
		{
			if (x != null)
			{
				if (x.Type == 26 && x.Data != null)
				{
					l.Add(new KeyValuePair<object, MVal>(x, x.Data));
				}
				if (x.Kids != null)
				{
					foreach (MCond kid in x.Kids)
					{
						c(kid);
					}
				}
			}
		};
		a = (MAct x) =>
		{
			if (x != null)
			{
				if ((x.Type == 7 || x.Type == 8) && x.Data != null)
				{
					l.Add(new KeyValuePair<object, MVal>(x, x.Data));
				}
				if (x.Kids != null)
				{
					foreach (MAct kid2 in x.Kids)
					{
						a(kid2);
					}
				}
			}
		};
		foreach (MRule rule in m.Rules)
		{
			c(rule.C);
			a(rule.A);
		}
		return l;
	}

	private int CountVtSettings()
	{
		if (_meta == null)
		{
			return 0;
		}
		if (_vtCountMeta == _meta && (DateTime.Now - _vtCountAt).TotalSeconds < 2.0)
		{
			return _vtCountCache;
		}
		int num = 0;
		foreach (KeyValuePair<object, MVal> item in Exprs(_meta))
		{
			string s = item.Value.GetS("e");
			if (s.IndexOf("vtsetsetting", StringComparison.OrdinalIgnoreCase) >= 0 || s.IndexOf("vtgetsetting", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				num++;
			}
		}
		_vtCountMeta = _meta;
		_vtCountAt = DateTime.Now;
		_vtCountCache = num;
		return num;
	}

	private void ConvertVtSettings()
	{
		int num = 0;
		List<string> list = new List<string>();
		foreach (KeyValuePair<object, MVal> item in Exprs(_meta))
		{
			string s = item.Value.GetS("e");
			if (s.IndexOf("vtsetsetting", StringComparison.OrdinalIgnoreCase) < 0 && s.IndexOf("vtgetsetting", StringComparison.OrdinalIgnoreCase) < 0)
			{
				continue;
			}
			MAct mAct = item.Key as MAct;
			Match match;
			if (mAct != null && mAct.Type == 7 && (match = VtGetRx.Match(s)).Success)
			{
				mAct.Type = 11;
				mAct.Data = MVal.Dict();
				mAct.Data.Set("o", MVal.Str(match.Groups["opt"].Value));
				mAct.Data.Set("v", MVal.Str(match.Groups["var"].Value));
				num++;
				continue;
			}
			if (mAct != null && mAct.Type == 7 && (match = VtSetVarRx.Match(s)).Success)
			{
				mAct.Type = 12;
				mAct.Data = MVal.Dict();
				mAct.Data.Set("o", MVal.Str(match.Groups["opt"].Value));
				mAct.Data.Set("v", MVal.Str(match.Groups["val"].Value));
				num++;
				continue;
			}
			if (mAct != null && mAct.Type == 7 && (match = VtSetFixedRx.Match(s)).Success)
			{
				mAct.Type = 12;
				mAct.Data = MVal.Dict();
				mAct.Data.Set("o", MVal.Str(match.Groups["opt"].Value));
				mAct.Data.Set("v", MVal.Str(MetaText.IsOn(match.Groups["val"].Value) ? "1" : "0"));
				num++;
				continue;
			}
			string text = VtSetInnerRx.Replace(s, (Match x) => "chatbox[" + x.Groups["esc"].Value + "`/vt opt set " + x.Groups["opt"].Value + " " + x.Groups["val"].Value + x.Groups["esc"].Value + "`]");
			if (text != s)
			{
				item.Value.Set("e", MVal.Str(text));
				if (text.IndexOf("vtgetsetting", StringComparison.OrdinalIgnoreCase) < 0 && text.IndexOf("vtsetsetting", StringComparison.OrdinalIgnoreCase) < 0)
				{
					num++;
					continue;
				}
			}
			list.Add((text.Length > 60) ? (text.Substring(0, 60) + "...") : text);
		}
		_vtCountAt = DateTime.MinValue;
		if (num > 0)
		{
			MetaChanged();
		}
		Util.WriteToChat("Meta: converted " + num + " VTank setting expression" + ((num == 1) ? "" : "s") + " for MelkTank" + ((list.Count > 0) ? (" - " + list.Count + " left as they were: " + string.Join(" | ", list.ToArray())) : ".") + ((num > 0) ? " Save it as .mtmet to keep." : ""));
	}

	private bool EmbedRoute(MVal d, NavRoute r)
	{
		try
		{
			d.T = "ba";
			d.B = Meta.Enc.GetBytes(SafeName(r.Name) + ".mtnav\r\n" + r.Steps.Count + "\r\n" + RouteXml(r));
			Util.WriteToChat("Meta: route " + r.Name + " embedded (" + r.Steps.Count + " steps, all kept).");
			return true;
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Meta: couldn't embed the route: " + ex.Message);
			return false;
		}
	}

	private byte[] VtankEmbed(byte[] b)
	{
		NavRoute navRoute = EmbeddedMtRoute(b);
		if (navRoute == null)
		{
			return b;
		}
		string path = Path.Combine(Path.GetTempPath(), "mt_embed_" + SafeName(navRoute.Name) + ".nav");
		if (!ExportNav(navRoute, path, quiet: true))
		{
			return b;
		}
		string text = File.ReadAllText(path, Meta.Enc);
		try
		{
			File.Delete(path);
		}
		catch
		{
		}
		string[] array = text.Split(new string[2] { "\r\n", "\n" }, StringSplitOptions.None);
		int result = 0;
		if (array.Length > 2)
		{
			int.TryParse(array[2].Trim(), out result);
		}
		return Meta.Enc.GetBytes(SafeName(navRoute.Name) + ".nav\r\n" + result + "\r\n" + text);
	}

	private void ImportEmbedded(byte[] b, string name)
	{
		try
		{
			string text = Meta.Enc.GetString(b ?? new byte[0]);
			if (IsMtRoute(b))
			{
				NavRoute mr = EmbeddedMtRoute(b);
				if (mr != null)
				{
					if (mr.Name.Length == 0)
					{
						mr.Name = ((name.Length > 0) ? Path.GetFileNameWithoutExtension(name) : "Meta route");
					}
					string name2 = mr.Name;
					int num = 2;
					while (_s.NavRoutes.Exists((NavRoute x) => string.Equals(x.Name, mr.Name, StringComparison.OrdinalIgnoreCase)))
					{
						mr.Name = name2 + " (" + num++ + ")";
					}
					mr.File = "";
					_s.NavRoutes.Add(mr);
					if (SaveAll != null)
					{
						SaveAll();
					}
					Util.WriteToChat("Meta: route " + mr.Name + " added (" + mr.Steps.Count + " steps) - Nav > Routes.");
				}
				return;
			}
			int num2 = text.IndexOf("uTank2 NAV", StringComparison.OrdinalIgnoreCase);
			if (num2 < 0)
			{
				Util.WriteToChat("Meta: that embedded nav is empty.");
				return;
			}
			string path = Path.Combine(Path.GetTempPath(), SafeName(((_meta != null) ? (_meta.Name + " ") : "") + ((name.Length > 0) ? Path.GetFileNameWithoutExtension(name) : "nav")) + ".nav");
			File.WriteAllText(path, text.Substring(num2), Meta.Enc);
			NavRoute nr = ImportNav(path);
			try
			{
				File.Delete(path);
			}
			catch
			{
			}
			if (nr != null)
			{
				string name3 = nr.Name;
				int num3 = 2;
				while (_s.NavRoutes.Exists((NavRoute x) => string.Equals(x.Name, nr.Name, StringComparison.OrdinalIgnoreCase)))
				{
					nr.Name = name3 + " (" + num3++ + ")";
				}
				_s.NavRoutes.Add(nr);
				if (SaveAll != null)
				{
					SaveAll();
				}
				Util.WriteToChat("Meta: route " + nr.Name + " added (" + nr.Steps.Count + " steps) - Nav > Routes.");
			}
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Meta: couldn't make the route: " + ex.Message);
		}
	}

	private void SaveMeta(bool vtank)
	{
		if (_meta == null)
		{
			return;
		}
		string text = ((!string.IsNullOrEmpty(_meta.File)) ? Path.GetDirectoryName(_meta.File) : MetaDir);
		if (!vtank && VtankDir != null && text.StartsWith(VtankDir, StringComparison.OrdinalIgnoreCase))
		{
			text = MetaDir;
		}
		string text2 = Path.Combine(text, SafeName(_meta.Name) + (vtank ? ".met" : ".mtmet"));
		if (vtank)
		{
			List<string> list = _meta.NotForVtank();
			if (list.Count > 0)
			{
				Util.WriteToChat("Meta: VTank can't do these - they're left out of the .met: " + string.Join(", ", list.ToArray()));
			}
		}
		List<KeyValuePair<MVal, byte[]>> swapped = new List<KeyValuePair<MVal, byte[]>>();
		List<object[]> retyped = new List<object[]>();
		Action action = () =>
		{
			foreach (KeyValuePair<MVal, byte[]> item in swapped)
			{
				item.Key.B = item.Value;
			}
			foreach (object[] item2 in retyped)
			{
				MAct mAct = (MAct)item2[0];
				mAct.Type = (int)item2[1];
				mAct.Data = (MVal)item2[2];
			}
		};
		if (vtank)
		{
			Action<MAct> walk = null;
			walk = (MAct x) =>
			{
				if (x != null)
				{
					if (x.Type == 4 && x.Data != null && IsMtRoute(x.Data.B))
					{
						swapped.Add(new KeyValuePair<MVal, byte[]>(x.Data, x.Data.B));
						x.Data.B = VtankEmbed(x.Data.B);
					}
					if (x.Type == 104 && x.Data != null)
					{
						retyped.Add(new object[3] { x, x.Type, x.Data });
						x.Type = 2;
						x.Data = MVal.Str("/vt nav load " + x.Data.GetS("n"));
					}
					else if (x.Type >= 100 && x.Type <= 103 && x.Data != null)
					{
						string v = ((x.Type == 103) ? ("/ub give " + x.Data.GetS("i") + " to " + x.Data.GetS("n")) : ("/ub use " + x.Data.GetS("n")));
						retyped.Add(new object[3] { x, x.Type, x.Data });
						x.Type = 2;
						x.Data = MVal.Str(v);
					}
					if (x.Kids != null)
					{
						foreach (MAct kid in x.Kids)
						{
							walk(kid);
						}
					}
				}
			};
			foreach (MRule rule in _meta.Rules)
			{
				walk(rule.A);
			}
		}
		try
		{
			if (vtank)
			{
				string file = _meta.File;
				string name = _meta.Name;
				bool dirty = _meta.Dirty;
				File.WriteAllBytes(text2, _meta.ToBytes());
				_meta.File = file;
				_meta.Name = name;
				_meta.Dirty = dirty;
				action();
				_metaTreeAt = DateTime.MinValue;
				Util.WriteToChat("Meta: saved " + text2 + " (VTank copy)");
			}
			else
			{
				_meta.Save(text2);
				_s.MetaLast = text2;
				if (SaveAll != null)
				{
					SaveAll();
				}
				_metaTreeAt = DateTime.MinValue;
				Util.WriteToChat("Meta: saved " + text2);
			}
		}
		catch (Exception ex)
		{
			action();
			Util.WriteToChat("Meta: couldn't save " + text2 + ": " + ex.Message);
		}
	}

	private static TreeDir ScanMetas(string dir, int depth)
	{
		TreeDir treeDir = new TreeDir
		{
			Path = dir,
			Name = Path.GetFileName(dir)
		};
		if (depth > 6)
		{
			return treeDir;
		}
		try
		{
			List<string> list = new List<string>(Directory.GetDirectories(dir));
			list.Sort(StringComparer.OrdinalIgnoreCase);
			foreach (string item in list)
			{
				TreeDir treeDir2 = ScanMetas(item, depth + 1);
				if (treeDir2.Files.Count > 0 || treeDir2.Dirs.Count > 0)
				{
					treeDir.Dirs.Add(treeDir2);
				}
			}
			string[] files = Directory.GetFiles(dir);
			foreach (string text in files)
			{
				if (text.EndsWith(".met", StringComparison.OrdinalIgnoreCase) || text.EndsWith(".mtmet", StringComparison.OrdinalIgnoreCase))
				{
					treeDir.Files.Add(text);
				}
			}
			treeDir.Files.Sort(StringComparer.OrdinalIgnoreCase);
		}
		catch
		{
		}
		return treeDir;
	}

	private void DrawMetaTree(TreeDir d)
	{
		foreach (TreeDir dir in d.Dirs)
		{
			if (ImGui.TreeNodeEx(dir.Name + "###md" + dir.Path, ImGuiTreeNodeFlags.OpenOnArrow | ImGuiTreeNodeFlags.SpanAvailWidth))
			{
				DrawMetaTree(dir);
				ImGui.TreePop();
			}
		}
		foreach (string file in d.Files)
		{
			bool flag = file.EndsWith(".mtmet", StringComparison.OrdinalIgnoreCase);
			ImGui.PushStyleColor(ImGuiCol.Text, flag ? new System.Numerics.Vector4(0.6f, 0.85f, 1f, 1f) : new System.Numerics.Vector4(0.8f, 0.65f, 1f, 1f));
			if (ImGui.Selectable("    " + Path.GetFileName(file) + "###mf" + file, string.Equals(_metaPick, file, StringComparison.OrdinalIgnoreCase)))
			{
				_metaPick = file;
			}
			ImGui.PopStyleColor();
			if (ImGui.IsItemHovered() && ImGui.IsMouseDoubleClicked(ImGuiMouseButton.Left))
			{
				OpenMeta(file);
			}
		}
	}

	private bool DrawMetaFiles()
	{
		bool result = false;
		ImGui.Indent(8f);
		if (ImGui.RadioButton("MelkTank Metas folder##mdir", !_s.MetaVtankDir))
		{
			_s.MetaVtankDir = false;
			_metaTreeAt = DateTime.MinValue;
			result = true;
		}
		ImGui.SameLine();
		if (VtankDir != null)
		{
			if (ImGui.RadioButton("VTank folder##mdir2", _s.MetaVtankDir))
			{
				_s.MetaVtankDir = true;
				_metaTreeAt = DateTime.MinValue;
				result = true;
			}
		}
		else
		{
			Im.TextColored(Grey, "(no VTank folder found)");
		}
		ImGui.SameLine();
		if (ImGui.SmallButton("Refresh##mref"))
		{
			_metaTreeAt = DateTime.MinValue;
		}
		string text = ((_s.MetaVtankDir && VtankDir != null) ? VtankDir : MetaDir);
		Im.TextColored(Grey, text);
		if (_metaTree == null || _metaTree.Path != text || (DateTime.Now - _metaTreeAt).TotalSeconds > 5.0)
		{
			_metaTree = ScanMetas(text, 0);
			_metaTreeAt = DateTime.Now;
		}
		if (ImGui.BeginChild("##metatree", new System.Numerics.Vector2(0f, 180f), border: true))
		{
			if (_metaTree.Dirs.Count == 0 && _metaTree.Files.Count == 0)
			{
				Im.TextColored(Grey, "No .met / .mtmet files here yet.");
			}
			DrawMetaTree(_metaTree);
		}
		ImGui.EndChild();
		bool flag = _metaPick != null && File.Exists(_metaPick);
		if (!flag)
		{
			ImGui.BeginDisabled();
		}
		if (ImGui.Button("Open in Nav > Meta") & flag)
		{
			OpenMeta(_metaPick);
		}
		if (!flag)
		{
			ImGui.EndDisabled();
		}
		Tip("Click (or double-click) a meta in the list. VTank .met files (purple) open as they are - save them as .mtmet\nto keep MelkTank's copy, or back as .met for VTank.");
		if (flag)
		{
			ImGui.SameLine();
			Im.TextColored(Grey, Path.GetFileName(_metaPick));
		}
		ImGui.Unindent(8f);
		return result;
	}

	private bool DrawMetaSettings()
	{
		bool flag = false;
		flag |= ImGui.Checkbox("Open the last meta when you log in##metalast", ref _s.MetaOpenLast);
		Tip("Nav > Meta shows the meta you had open last time.\n/mt set MetaOpenLast on|off");
		flag |= ImGui.Checkbox("Going to the state you're already in starts it over##metasame", ref _s.MetaSameRestarts);
		Tip("Off (VTank's way): a rule that goes to the state you're in does nothing.\nOn: the state's rules start over (each can fire again, its timers restart).\n/mt set MetaSameRestarts on|off");
		return flag;
	}

	private bool DrawPresetRow(NavRoute r)
	{
		bool result = false;
		List<string> list = NavPresets.Names();
		if (list.Count == 0)
		{
			ImGui.BeginDisabled();
			AddButton("Add preset");
			ImGui.EndDisabled();
			ImGui.SameLine();
			Im.TextColored(Grey, "make one on the Presets tab first");
			return false;
		}
		if (_rPresetPick >= list.Count)
		{
			_rPresetPick = 0;
		}
		if (AddButton("Add preset"))
		{
			Insert(r, new RouteStep
			{
				Kind = StepKind.Preset,
				Text = list[_rPresetPick]
			});
			result = true;
		}
		Tip("A set of steps made on the Presets tab (e.g. Mob Pack: combat on, wait, combat off) - put it where it's needed.\nLinked: changing the preset changes it in every route that uses it.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(200f);
		ImGui.Combo("##rpreset", ref _rPresetPick, list.ToArray(), list.Count);
		if (_rSel >= 0 && _rSel < r.Steps.Count && r.Steps[_rSel].Kind == StepKind.Preset)
		{
			ImGui.SameLine();
			if (ImGui.SmallButton("make plain steps##rpflat"))
			{
				RouteStep routeStep = r.Steps[_rSel];
				NavRoute navRoute = NavPresets.Find(routeStep.Text);
				if (navRoute == null)
				{
					Util.WriteToChat("Nav: there's no preset called " + routeStep.Text + ".");
				}
				else
				{
					int rSel = _rSel;
					r.Steps.RemoveAt(rSel);
					for (int i = 0; i < navRoute.Steps.Count; i++)
					{
						r.Steps.Insert(rSel + i, NavPresets.Copy(navRoute.Steps[i]));
					}
					if (_rIdx > rSel)
					{
						_rIdx += navRoute.Steps.Count - 1;
					}
					_rSubFor = -1;
					Util.WriteToChat("Nav: " + routeStep.Text + " turned into " + navRoute.Steps.Count + " plain steps in this route (not linked any more).");
					result = true;
				}
			}
			Tip("Puts the preset's steps into this route as ordinary steps, so they can be changed here only.");
		}
		return result;
	}

	private void DrawPresetSubRows(RouteStep st, int i, bool here)
	{
		NavRoute navRoute = NavPresets.Find(st.Text);
		if (navRoute != null)
		{
			int num = (here ? SubNow() : (-1));
			for (int j = 0; j < navRoute.Steps.Count; j++)
			{
				RouteStep routeStep = navRoute.Steps[j];
				ImGui.TableNextRow();
				ImGui.PushID("ps" + i + "_" + j);
				System.Numerics.Vector4 col = ((num == j) ? Green : Grey);
				ImGui.TableSetColumnIndex(0);
				Im.TextColored(col, ((num == j) ? ">" : "") + (i + 1) + "." + (j + 1));
				ImGui.TableSetColumnIndex(1);
				Im.TextColored(col, "  " + KindName(routeStep.Kind));
				ImGui.TableSetColumnIndex(2);
				Im.TextColored(col, "    " + Describe(routeStep));
				ImGui.PopID();
			}
		}
	}

	private void DrawPresetsTab()
	{
		bool flag = false;
		bool flag2 = false;
		NavPresets.Load();
		List<string> list = NavPresets.Names();
		NavRoute navRoute = NavPresets.Find(_pName);
		if (navRoute == null && NavPresets.All.Count > 0)
		{
			navRoute = NavPresets.All[0];
			_pName = navRoute.Name;
			_pSel = -1;
			_pEdit = null;
		}
		Im.TextColored(Grey, "Sets of steps without locations (switches, waits, commands, use item ...) to drop into routes with \"Add preset\".\nLinked: a change here changes every route that uses the preset. Shared by all your characters.");
		ImGui.SetNextItemWidth(220f);
		if (ImGui.BeginCombo("Preset##pname", (navRoute != null) ? navRoute.Name : "(no presets yet)"))
		{
			for (int i = 0; i < list.Count; i++)
			{
				if (ImGui.Selectable(list[i] + "##pn" + i, navRoute != null && list[i] == navRoute.Name))
				{
					_pName = list[i];
					_pSel = -1;
					_pEdit = null;
				}
			}
			ImGui.EndCombo();
		}
		navRoute = NavPresets.Find(_pName);
		if (navRoute != null)
		{
			ImGui.SameLine();
			if (ImGui.Button("Copy##pcopy"))
			{
				NavRoute navRoute2 = new NavRoute
				{
					Name = UniqueName(navRoute.Name + " copy"),
					Mode = 0
				};
				foreach (RouteStep step in navRoute.Steps)
				{
					navRoute2.Steps.Add(NavPresets.Copy(step));
				}
				NavPresets.All.Add(navRoute2);
				_pName = navRoute2.Name;
				_pSel = -1;
				_pEdit = null;
				flag = true;
			}
			ImGui.SameLine();
			int num = Uses(navRoute.Name);
			if (ImGui.Button("Delete##pdel"))
			{
				NavPresets.All.Remove(navRoute);
				flag = true;
				if (num > 0)
				{
					Util.WriteToChat("Nav: preset " + navRoute.Name + " deleted - " + num + " route step" + ((num == 1) ? "" : "s") + " using it will be skipped.");
				}
				_pName = ((NavPresets.All.Count > 0) ? NavPresets.All[0].Name : "");
				_pSel = -1;
				_pEdit = null;
				navRoute = NavPresets.Find(_pName);
			}
			Tip("Routes that use it skip that step (say so in chat) until a preset with the same name is made again.");
			ImGui.SameLine();
			Im.TextColored(Grey, (num == 0) ? "not used in this character's routes" : ("used " + num + " time" + ((num == 1) ? "" : "s") + " in this character's routes"));
		}
		ImGui.SetNextItemWidth(220f);
		ImGui.InputText("Name##pnewname", ref _pNewName, 64u);
		ImGui.SameLine();
		string text = _pNewName.Trim();
		bool flag3 = text.Length > 0 && NavPresets.Find(text) != null;
		if (ImGui.Button("New preset##pnew") && text.Length > 0 && !flag3)
		{
			NavRoute navRoute3 = new NavRoute
			{
				Name = text,
				Mode = 0
			};
			NavPresets.All.Add(navRoute3);
			_pName = text;
			_pNewName = "";
			_pSel = -1;
			_pEdit = null;
			flag = true;
			navRoute = navRoute3;
		}
		if (navRoute != null)
		{
			ImGui.SameLine();
			if (ImGui.Button("Rename##pren") && text.Length > 0 && !flag3)
			{
				string name = navRoute.Name;
				navRoute.Name = text;
				_pName = text;
				_pNewName = "";
				foreach (NavRoute navRoute4 in _s.NavRoutes)
				{
					foreach (RouteStep step2 in navRoute4.Steps)
					{
						if (step2.Kind == StepKind.Preset && string.Equals(step2.Text, name, StringComparison.OrdinalIgnoreCase))
						{
							step2.Text = text;
							flag2 = true;
						}
					}
				}
				flag = true;
				Util.WriteToChat("Nav: preset " + name + " is now " + text + " (this character's routes changed to match; another character's routes still say " + name + ").");
			}
		}
		if (flag3)
		{
			ImGui.SameLine();
			Im.TextColored(Yellow, "there's already a preset called that");
		}
		if (navRoute == null)
		{
			Im.TextColored(Grey, "Type a name and click New preset.");
			if (flag)
			{
				NavPresets.Save();
			}
			return;
		}
		ImGui.Separator();
		if (_pEdit != null && !navRoute.Steps.Contains(_pEdit))
		{
			_pEdit = null;
		}
		int num2 = -1;
		int num3 = -1;
		int num4 = -1;
		if (ImGui.BeginTable("presetsteps", 5, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY, new System.Numerics.Vector2(606f, 300f)))
		{
			ImGui.TableSetupColumn("#", ImGuiTableColumnFlags.WidthFixed, 30f);
			ImGui.TableSetupColumn("Step", ImGuiTableColumnFlags.WidthFixed, 80f);
			ImGui.TableSetupColumn("Detail", ImGuiTableColumnFlags.WidthFixed, 330f);
			ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 60f);
			ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 26f);
			ImGui.TableSetupScrollFreeze(0, 1);
			ImGui.TableHeadersRow();
			for (int j = 0; j < navRoute.Steps.Count; j++)
			{
				RouteStep routeStep = navRoute.Steps[j];
				ImGui.TableNextRow();
				ImGui.PushID("p" + j);
				ImGui.TableSetColumnIndex(0);
				Im.TextColored(Grey, (j + 1).ToString());
				ImGui.TableSetColumnIndex(1);
				if (ImGui.Selectable(KindName(routeStep.Kind) + "##ps", _pSel == j, ImGuiSelectableFlags.SpanAllColumns | ImGuiSelectableFlags.AllowOverlap))
				{
					_pSel = ((_pSel == j) ? (-1) : j);
				}
				Tip("Click: select (new steps go after it; Edit step changes it).");
				ImGui.TableSetColumnIndex(2);
				Im.TextColored((routeStep == _pEdit) ? Yellow : System.Numerics.Vector4.One, ((routeStep == _pEdit) ? "(editing) " : "") + Describe(routeStep));
				ImGui.TableSetColumnIndex(3);
				if (j > 0)
				{
					if (Im.UpButton("##pup"))
					{
						num2 = j;
					}
					ImGui.SameLine();
				}
				if (j < navRoute.Steps.Count - 1 && Im.DownButton("##pdn"))
				{
					num3 = j;
				}
				ImGui.TableSetColumnIndex(4);
				if (ImGui.SmallButton("x"))
				{
					num4 = j;
				}
				ImGui.PopID();
			}
			ImGui.EndTable();
		}
		ImGui.SameLine();
		ImGui.BeginGroup();
		int rSel = _rSel;
		RouteStep rEdit = _rEdit;
		_rSel = _pSel;
		_rEdit = _pEdit;
		try
		{
			flag |= DrawAddRows(navRoute, preset: true);
		}
		finally
		{
			_pSel = _rSel;
			_pEdit = _rEdit;
			_rSel = rSel;
			_rEdit = rEdit;
		}
		ImGui.EndGroup();
		if (num2 > 0 || num3 >= 0)
		{
			RouteStep routeStep2 = ((_pSel >= 0 && _pSel < navRoute.Steps.Count) ? navRoute.Steps[_pSel] : null);
			Im.Move(navRoute.Steps, (num2 > 0) ? num2 : num3, num2 > 0);
			if (routeStep2 != null)
			{
				_pSel = navRoute.Steps.IndexOf(routeStep2);
			}
			flag = true;
		}
		if (num4 >= 0)
		{
			if (navRoute.Steps[num4] == _pEdit)
			{
				_pEdit = null;
			}
			navRoute.Steps.RemoveAt(num4);
			if (_pSel >= navRoute.Steps.Count)
			{
				_pSel = navRoute.Steps.Count - 1;
			}
			flag = true;
		}
		if (navRoute.Steps.Count == 0)
		{
			Im.TextColored(Grey, "No steps yet - add them with the buttons on the right.");
		}
		if (flag)
		{
			NavPresets.Save();
		}
		if (flag2 && SaveAll != null)
		{
			SaveAll();
		}
	}

	private static string UniqueName(string b)
	{
		string text = b;
		int num = 2;
		while (NavPresets.Find(text) != null)
		{
			text = b + " " + num++;
		}
		return text;
	}

	private int Uses(string name)
	{
		int num = 0;
		foreach (NavRoute navRoute in _s.NavRoutes)
		{
			foreach (RouteStep step in navRoute.Steps)
			{
				if (step.Kind == StepKind.Preset && string.Equals(step.Text, name, StringComparison.OrdinalIgnoreCase))
				{
					num++;
				}
			}
		}
		return num;
	}

	private static bool SkipNoMobs(RouteStep st)
	{
		return st != null && string.Equals(st.Op, "nomobs", StringComparison.OrdinalIgnoreCase);
	}

	private static bool MonsterInCombatRange()
	{
		CombatEngine currentEngine = PluginCore.CurrentEngine;
		if (currentEngine == null)
		{
			return true;
		}
		double num = currentEngine.AttackRangeNow;
		foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
		{
			if (item.ObjectClass == ObjectClass.Monster && currentEngine.IsHostileMonster(item))
			{
				double num2 = CombatEngine.Distance(item);
				if (num2 >= 0.0 && num2 <= num)
				{
					return true;
				}
			}
		}
		return false;
	}

	private void OnStuck(NavRoute r)
	{
		string text = "step " + (_rIdx + 1);
		switch (r.StuckAction)
		{
		case 1:
			if (!_s.CombatEnabled)
			{
				_s.CombatEnabled = true;
				_rTempCombat = true;
				if (SaveAll != null)
				{
					SaveAll();
				}
				Util.WriteToChat("Nav: blocked on the way to " + text + " - combat on until I get there.");
			}
			_pauseUntil = DateTime.Now;
			break;
		case 2:
		{
			List<int> list = new List<int>();
			int num = _rIdx - 1;
			while (num >= 0 && list.Count < Math.Max(1, r.StuckBack))
			{
				if (r.Steps[num].Kind == StepKind.Point)
				{
					list.Add(num);
				}
				else if (r.Steps[num].Kind == StepKind.Use || r.Steps[num].Kind == StepKind.Cast || r.Steps[num].Kind == StepKind.GoRoute)
				{
					break;
				}
				num--;
			}
			if (list.Count == 0)
			{
				Util.WriteToChat("Nav: blocked on the way to " + text + " - no points behind to back up to, trying again.");
				break;
			}
			_rDetour.Clear();
			_rDetour.AddRange(list);
			for (int num2 = list.Count - 2; num2 >= 0; num2--)
			{
				_rDetour.Add(list[num2]);
			}
			_pauseUntil = DateTime.Now;
			Util.WriteToChat("Nav: blocked on the way to " + text + " - backing up " + list.Count + " point" + ((list.Count == 1) ? "" : "s") + " and coming again.");
			break;
		}
		case 3:
			RouteReset();
			_pauseUntil = DateTime.Now;
			Util.WriteToChat("Nav: blocked on the way to " + text + " - starting " + r.Name + " over.");
			break;
		case 4:
			Advance(r);
			_pauseUntil = DateTime.Now;
			Util.WriteToChat("Nav: blocked on the way to " + text + " - skipping it.");
			break;
		}
		L("route " + r.Name + " " + text + ": stuck -> " + StuckActions[Math.Max(0, Math.Min(StuckActions.Length - 1, r.StuckAction))]);
	}

	public string PhoneStatus()
	{
		try
		{
			if (!_s.NavEnabled)
			{
				return "Off";
			}
			if (_s.NavMode == 1)
			{
				NavRoute currentRoute = CurrentRoute;
				if (currentRoute == null || currentRoute.Steps.Count == 0)
				{
					return "Route: none picked";
				}
				if (_rDone)
				{
					return currentRoute.Name + " · finished";
				}
				if (_resumeNearest)
				{
					return currentRoute.Name + " · picks up at the nearest point when it moves on";
				}
				int num = Math.Max(0, Math.Min(currentRoute.Steps.Count - 1, _rIdx));
				string text = Status ?? "";
				int num2 = text.IndexOf(" - ", StringComparison.Ordinal);
				if (text.StartsWith("Route ") && num2 > 0)
				{
					text = text.Substring(num2 + 3);
				}
				if (_rDetour.Count > 0)
				{
					text = "backing up - " + text;
				}
				string text2 = KindName(currentRoute.Steps[num].Kind);
				string text3 = (num + 1).ToString();
				if (currentRoute.Steps[num].Kind == StepKind.Preset)
				{
					NavRoute navRoute = NavPresets.Find(currentRoute.Steps[num].Text);
					int num3 = SubNow();
					text3 = text3 + "." + (num3 + 1);
					text2 = currentRoute.Steps[num].Text + ((navRoute != null && num3 < navRoute.Steps.Count) ? (" · " + KindName(navRoute.Steps[num3].Kind)) : "");
				}
				return currentRoute.Name + " · step " + text3 + "/" + currentRoute.Steps.Count + " " + text2 + ((text.Length > 0) ? (" · " + text) : "");
			}
			if (_s.NavMode == 2)
			{
				return "Following" + ((Status != null && Status.Length > 0) ? (" · " + Status) : "");
			}
			NavSpot current = Current;
			if (current == null)
			{
				return "Spot: none picked";
			}
			double num4 = DistanceTo(current);
			return current.Name + " · " + ((num4 >= 0.0 && num4 <= (double)_s.NavDrift) ? "in position" : "not in position");
		}
		catch
		{
			return "";
		}
	}

	private void StartRecording(NavRoute r)
	{
		RouteStep routeStep = NewPointHere(StepKind.Point);
		if (routeStep != null)
		{
			Insert(r, routeStep);
			_recNS = routeStep.NS;
			_recEW = routeStep.EW;
			_recording = true;
			_recRoute = r.Name;
			Util.WriteToChat("Nav: recording " + r.Name + " - a point every " + _recEvery.ToString("0") + " m as you move. Stop it on the Routes tab.");
		}
	}

	private void StopRecording()
	{
		if (_recording)
		{
			_recording = false;
			if (SaveAll != null)
			{
				SaveAll();
			}
			Util.WriteToChat("Nav: recording stopped.");
		}
	}

	public void RecordTick()
	{
		if (!_recording || DateTime.Now < _recNext)
		{
			return;
		}
		_recNext = DateTime.Now.AddMilliseconds(250.0);
		NavRoute currentRoute = CurrentRoute;
		double ns;
		double ew;
		double z;
		if (currentRoute == null || currentRoute.Name != _recRoute)
		{
			StopRecording();
		}
		else if (MyPos(out ns, out ew, out z))
		{
			double num = (ns - _recNS) * 240.0;
			double num2 = (ew - _recEW) * 240.0;
			if (!(Math.Sqrt(num * num + num2 * num2) < (double)Math.Max(2f, _recEvery)))
			{
				Insert(currentRoute, new RouteStep
				{
					Kind = StepKind.Point,
					NS = ns,
					EW = ew,
					Z = z
				});
				_recNS = ns;
				_recEW = ew;
			}
		}
	}

	private void EndTempCombat()
	{
		if (!_rTempCombat)
		{
			return;
		}
		_rTempCombat = false;
		if (_s.CombatEnabled)
		{
			_s.CombatEnabled = false;
			if (SaveAll != null)
			{
				SaveAll();
			}
			Util.WriteToChat("Nav: through - combat off again.");
		}
	}

	public void OnChat(string text)
	{
		if (string.IsNullOrEmpty(text))
		{
			return;
		}
		DateTime now = DateTime.Now;
		lock (_chat)
		{
			_chat.Add(new KeyValuePair<DateTime, string>(now, text.Trim()));
			while (_chat.Count > 0 && ((now - _chat[0].Key).TotalSeconds > Tuning.V("ChatKeepS") || _chat.Count > 200))
			{
				_chat.RemoveAt(0);
			}
		}
		try
		{
			NavRoute currentRoute = CurrentRoute;
			int num = ((currentRoute != null) ? LoopEndIdx(currentRoute) : (-1));
			if (num < 0)
			{
				return;
			}
			foreach (LoopCond cond in currentRoute.Steps[num].Conds)
			{
				if (cond.Chat && !cond.Seen && ChatMatch(text.Trim(), cond.Text, cond.Op))
				{
					cond.Seen = true;
					L("route " + currentRoute.Name + ": loop-end chat seen: " + cond.Text);
				}
			}
		}
		catch
		{
		}
	}

	private static bool ChatMatch(string line, string want, string op)
	{
		want = (want ?? "").Trim();
		if (want.Length == 0)
		{
			return true;
		}
		return (op == "=") ? string.Equals(line, want, StringComparison.OrdinalIgnoreCase) : (line.IndexOf(want, StringComparison.OrdinalIgnoreCase) >= 0);
	}

	private static void ResetConds(NavRoute r)
	{
		if (r == null)
		{
			return;
		}
		foreach (RouteStep step in r.Steps)
		{
			foreach (LoopCond cond in step.Conds)
			{
				cond.Seen = false;
			}
		}
	}

	private static string CondText(LoopCond c)
	{
		return c.Chat ? ("chat " + c.Op + " \"" + c.Text + "\"" + (c.Seen ? " (seen)" : "")) : (c.Text + " " + c.Op + " " + c.Count + " (have " + InventoryCount(c.Text) + ")");
	}

	private static bool CondsMet(RouteStep st)
	{
		if (st.Conds.Count == 0)
		{
			return false;
		}
		foreach (LoopCond cond in st.Conds)
		{
			if (cond.Chat ? (!cond.Seen) : (!Compare(InventoryCount(cond.Text), cond.Op, cond.Count)))
			{
				return false;
			}
		}
		return true;
	}

	private static int LoopEndIdx(NavRoute r)
	{
		int val = LoopStart(r) + 1;
		for (int i = Math.Max(0, val); i < r.Steps.Count; i++)
		{
			if (r.Steps[i].Kind == StepKind.LoopEnd)
			{
				return i;
			}
		}
		return -1;
	}

	public static int NearestPoint(NavRoute r, Nav nav, out double dist)
	{
		int num = -1;
		double num2 = double.MaxValue;
		for (int i = 0; i < r.Steps.Count; i++)
		{
			RouteStep routeStep = r.Steps[i];
			if (routeStep.Kind == StepKind.Point)
			{
				double num3 = nav.DistanceTo(new NavSpot
				{
					NS = routeStep.NS,
					EW = routeStep.EW,
					Z = routeStep.Z
				});
				if (num3 >= 0.0 && num3 < num2)
				{
					num2 = num3;
					num = i;
				}
			}
		}
		int num4 = LoopStart(r);
		if (num4 >= 0 && num >= 0)
		{
			int num5 = LoopEndIdx(r);
			if (num5 < 0)
			{
				num5 = r.Steps.Count;
			}
			if (num < num4 || num > num5)
			{
				int num6 = -1;
				double num7 = double.MaxValue;
				for (int j = num4 + 1; j < num5; j++)
				{
					RouteStep routeStep2 = r.Steps[j];
					if (routeStep2.Kind == StepKind.Point)
					{
						double num8 = nav.DistanceTo(new NavSpot
						{
							NS = routeStep2.NS,
							EW = routeStep2.EW,
							Z = routeStep2.Z
						});
						if (num8 >= 0.0 && num8 < num7)
						{
							num7 = num8;
							num6 = j;
						}
					}
				}
				if (num6 >= 0 && num7 <= num2 + 10.0)
				{
					num = num6;
					num2 = num7;
				}
			}
		}
		dist = num2;
		return num;
	}

	private bool ChatSeen(RouteStep st, DateTime since)
	{
		string text = (st.Text ?? "").Trim();
		if (text.Length == 0)
		{
			return true;
		}
		bool flag = st.Op == "=";
		lock (_chat)
		{
			foreach (KeyValuePair<DateTime, string> item in _chat)
			{
				if (item.Key < since || !(flag ? string.Equals(item.Value, text, StringComparison.OrdinalIgnoreCase) : (item.Value.IndexOf(text, StringComparison.OrdinalIgnoreCase) >= 0)))
				{
					continue;
				}
				return true;
			}
		}
		return false;
	}

	public static int InventoryCount(string name)
	{
		name = (name ?? "").Trim();
		if (name.Length == 0)
		{
			return 0;
		}
		int num = 0;
		int num2 = 0;
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				string text = item.Name ?? "";
				int num3 = 1;
				try
				{
					num3 = item.Values(LongValueKey.StackCount);
				}
				catch
				{
				}
				if (num3 < 1)
				{
					num3 = 1;
				}
				if (string.Equals(text, name, StringComparison.OrdinalIgnoreCase))
				{
					num += num3;
				}
				else if (text.IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0)
				{
					num2 += num3;
				}
			}
		}
		catch
		{
		}
		return (num > 0) ? num : num2;
	}

	public static bool Compare(int have, string op, int want)
	{
		return op switch
		{
			"=" => have == want, 
			"!=" => have != want, 
			"<" => have < want, 
			">" => have > want, 
			"<=" => have <= want, 
			_ => have >= want, 
		};
	}

	public void StuckRestartTick()
	{
		DateTime now = DateTime.Now;
		double num = ((_rStuckLast == DateTime.MinValue) ? 0.0 : Math.Min(1.0, (now - _rStuckLast).TotalSeconds));
		_rStuckLast = now;
		NavRoute navRoute = ((_s.NavEnabled && _s.NavMode == 1 && _s.MasterEnabled) ? CurrentRoute : null);
		if (navRoute == null || _rDone || navRoute.Steps.Count == 0)
		{
			_rStuckAcc = 0.0;
			_rStuckStep = -1;
		}
		else if (StepKey() != _rStuckStep || navRoute.Name != _rStuckRoute)
		{
			_rStuckStep = StepKey();
			_rStuckRoute = navRoute.Name;
			_rStuckAcc = 0.0;
		}
		else if (!_inPortal && !((now - _portalExitAt).TotalSeconds < 3.0) && (!(_diedAt > _portalExitAt) || !((now - _diedAt).TotalSeconds < 60.0)) && !PluginCore.IsPaused && !((now - _rTickAt).TotalSeconds > 1.5))
		{
			_rStuckAcc += num;
			if (navRoute.RestartIfStuck && !(_rStuckAcc < (double)(navRoute.RestartStuckMin * 60f)))
			{
				string text = "step " + (_rIdx + 1) + "/" + navRoute.Steps.Count;
				L("route " + navRoute.Name + " " + text + ": stuck for " + navRoute.RestartStuckMin.ToString("0") + " min - starting over from step 1");
				Util.WriteToChat("Nav: " + navRoute.Name + " was stuck on " + text + " for " + navRoute.RestartStuckMin.ToString("0") + " min - starting over from step 1.");
				Stop();
				RouteReset();
				_rStuckAcc = 0.0;
				_rStuckStep = 0;
			}
		}
	}

	public void RouteReset()
	{
		_rSubFor = -1;
		_rSub = 0;
		_rDetour.Clear();
		_rStuckN = 0;
		_rStuckIdx = -1;
		ResetConds(CurrentRoute);
		_rIdx = 0;
		_rDir = 1;
		_rDone = false;
		_rStarted = false;
		_rUntil = DateTime.MinValue;
		_rUsedAt = DateTime.MinValue;
	}

	public void NotePortalExit()
	{
		MetaNotePortal(enter: false);
		_inPortal = false;
		_portalExitAt = DateTime.Now;
		if (_rUsedAt != DateTime.MinValue)
		{
			_rUsedAt = DateTime.MinValue.AddTicks(1L);
		}
	}

	public void NotePortalEnter()
	{
		MetaNotePortal(enter: true);
		_inPortal = true;
	}

	public void NoteDeath()
	{
		MetaNoteDeath();
		_diedAt = DateTime.Now;
		TravelStop("you died", finished: false);
	}

	private static int LoopStart(NavRoute r)
	{
		for (int i = 0; i < r.Steps.Count; i++)
		{
			if (r.Steps[i].Kind == StepKind.LoopStart)
			{
				return i;
			}
		}
		return -1;
	}

	public NavSpot RouteTarget()
	{
		NavRoute currentRoute = CurrentRoute;
		if (currentRoute == null || _rIdx < 0 || _rIdx >= currentRoute.Steps.Count)
		{
			return null;
		}
		RouteStep routeStep = currentRoute.Steps[_rIdx];
		if (routeStep.Kind != StepKind.Point && routeStep.Kind != StepKind.Use)
		{
			return null;
		}
		return new NavSpot
		{
			Name = currentRoute.Name + " #" + (_rIdx + 1),
			NS = routeStep.NS,
			EW = routeStep.EW,
			Z = routeStep.Z,
			Heading = -1.0,
			FaceHeading = false
		};
	}

	private int SubNow()
	{
		return (_rSubFor == _rIdx) ? _rSub : 0;
	}

	private int StepKey()
	{
		return _rIdx * 1000 + ((_rSubFor == _rIdx) ? (_rSub + 1) : 0);
	}

	private static double SkipRange(RouteStep st)
	{
		double result;
		return (double.TryParse(st.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out result) && result > 0.0) ? result : 20.0;
	}

	private static string NearestPlayer(out double dist)
	{
		dist = double.MaxValue;
		string result = null;
		try
		{
			int id = Globals.Core.CharacterFilter.Id;
			CoordsObject coordsObject = Globals.Core.WorldFilter[id]?.Coordinates();
			if (coordsObject == null)
			{
				return null;
			}
			foreach (WorldObject item in Globals.Core.WorldFilter.GetByObjectClass(ObjectClass.Player))
			{
				if (item.Id == id)
				{
					continue;
				}
				CoordsObject coordsObject2 = item.Coordinates();
				if (coordsObject2 != null)
				{
					double num = (coordsObject2.NorthSouth - coordsObject.NorthSouth) * 240.0;
					double num2 = (coordsObject2.EastWest - coordsObject.EastWest) * 240.0;
					double num3 = Math.Sqrt(num * num + num2 * num2);
					if (num3 < dist)
					{
						dist = num3;
						result = item.Name;
					}
				}
			}
		}
		catch
		{
		}
		return result;
	}

	private RouteStep StepNow(NavRoute r)
	{
		if (_rIdx < 0 || _rIdx >= r.Steps.Count)
		{
			return null;
		}
		RouteStep routeStep = r.Steps[_rIdx];
		if (routeStep.Kind == StepKind.Preset)
		{
			NavRoute navRoute = NavPresets.Find(routeStep.Text);
			int num = SubNow();
			if (navRoute != null && num >= 0 && num < navRoute.Steps.Count)
			{
				return navRoute.Steps[num];
			}
		}
		return routeStep;
	}

	private string SkipSteps(NavRoute r, int n)
	{
		int num = -1;
		int num2 = -1;
		int num3 = -1;
		int num4 = -1;
		for (int i = 0; i < n; i++)
		{
			RouteStep routeStep = StepNow(r);
			if (routeStep != null && routeStep.Kind == StepKind.Toggle)
			{
				string text = (routeStep.Text ?? "").ToLowerInvariant();
				int num5 = (text.EndsWith(" on") ? 1 : ((!text.EndsWith(" off")) ? (-1) : 0));
				if (num5 >= 0)
				{
					if (text.StartsWith("combat"))
					{
						num = num5;
					}
					else if (text.StartsWith("loot"))
					{
						num2 = num5;
					}
					else if (text.StartsWith("summon"))
					{
						num3 = num5;
					}
					else if (text.StartsWith("doors"))
					{
						num4 = num5;
					}
				}
			}
			Advance(r);
		}
		List<string> list = new List<string>();
		bool flag = false;
		if (num >= 0)
		{
			_rTempCombat = false;
			if (_s.CombatEnabled != (num == 1))
			{
				_s.CombatEnabled = num == 1;
				flag = true;
			}
			list.Add("combat " + ((num == 1) ? "on" : "off"));
		}
		if (num2 >= 0)
		{
			if (_s.LootEnabled != (num2 == 1))
			{
				_s.LootEnabled = num2 == 1;
				flag = true;
			}
			list.Add("looting " + ((num2 == 1) ? "on" : "off"));
		}
		if (num3 >= 0)
		{
			PluginCore.SetSummoningFromNav(num3 == 1);
			list.Add("summoning " + ((num3 == 1) ? "on" : "off"));
		}
		if (num4 >= 0)
		{
			if (_s.NavOpenDoors != (num4 == 1))
			{
				_s.NavOpenDoors = num4 == 1;
				flag = true;
			}
			list.Add("doors " + ((num4 == 1) ? "on" : "off"));
		}
		if (flag && SaveAll != null)
		{
			SaveAll();
		}
		return (list.Count > 0) ? (" (their switches still applied: " + string.Join(", ", list.ToArray()) + ")") : "";
	}

	private void Advance(NavRoute r)
	{
		_rUntil = DateTime.MinValue;
		_rUsedAt = DateTime.MinValue;
		_rStarted = false;
		_rPrevStepAt = _rStepAt;
		_rStepAt = DateTime.Now;
		if (_rIdx >= 0 && _rIdx < r.Steps.Count && r.Steps[_rIdx].Kind == StepKind.Preset)
		{
			NavRoute navRoute = NavPresets.Find(r.Steps[_rIdx].Text);
			int num = SubNow();
			if (navRoute != null && num + 1 < navRoute.Steps.Count)
			{
				_rSub = num + 1;
				_rSubFor = _rIdx;
				return;
			}
		}
		_rSubFor = -1;
		_rSub = 0;
		int count = r.Steps.Count;
		int num2 = LoopStart(r);
		int num3 = ((num2 >= 0) ? (num2 + 1) : 0);
		int num4 = LoopEndIdx(r);
		if (num4 >= 0)
		{
			if (_rIdx >= num4 || r.Mode != 1)
			{
				_rIdx++;
				if (_rIdx >= count)
				{
					_rDone = true;
					_farEndNoted = false;
					_rIdx = count - 1;
					L("route " + r.Name + " finished");
				}
				return;
			}
			_rIdx += _rDir;
			if (_rIdx < num3)
			{
				_rDir = 1;
				_rIdx = Math.Min(num4 - 1, num3 + 1);
				if (_rIdx < num3)
				{
					_rIdx = num3;
				}
			}
		}
		else if (r.Mode == 0)
		{
			_rIdx++;
			if (_rIdx >= count)
			{
				_rDone = true;
				_farEndNoted = false;
				_rIdx = count - 1;
				L("route " + r.Name + " finished");
			}
		}
		else if (r.Mode == 2)
		{
			_rIdx++;
			if (_rIdx >= count)
			{
				_rIdx = num3;
			}
		}
		else
		{
			_rIdx += _rDir;
			if (_rIdx >= count)
			{
				_rDir = -1;
				_rIdx = Math.Max(num3, count - 2);
			}
			else if (_rIdx < num3)
			{
				_rDir = 1;
				_rIdx = Math.Min(count - 1, num3 + 1);
			}
		}
	}

	private bool RouteTick()
	{
		RestoreHotState();
		_rTickAt = DateTime.Now;
		NavRoute navRoute = (_s.NavEnabled ? CurrentRoute : null);
		if (navRoute == null || navRoute.Steps.Count == 0)
		{
			Stop();
			return false;
		}
		if (DateTime.Now < _pauseUntil)
		{
			return false;
		}
		if (_inPortal || (DateTime.Now - _portalExitAt).TotalSeconds < 3.0 || (_diedAt > _portalExitAt && (DateTime.Now - _diedAt).TotalSeconds < 30.0))
		{
			Stop();
			Status = "Route " + navRoute.Name + " - " + (_inPortal ? "in portal space" : ((_diedAt > _portalExitAt) ? "died - waiting to land" : "just landed")) + ", waiting";
			return true;
		}
		if (!string.Equals(_rName, navRoute.Name, StringComparison.Ordinal))
		{
			if (_resumeNearest && navRoute != _travelRoute && !string.Equals(navRoute.Name, "Map route", StringComparison.OrdinalIgnoreCase))
			{
				if (!MyPos(out var _, out var _, out var _))
				{
					return false;
				}
				_resumeNearest = false;
				_rName = navRoute.Name;
				RouteReset();
				int num = NearestPoint(navRoute, this, out var dist);
				if (num > 0 && dist <= 500.0)
				{
					_rIdx = num;
					Util.WriteToChat("Nav: carrying on with " + navRoute.Name + " at step " + (num + 1) + " (the nearest point, " + dist.ToString("0") + " m away).");
				}
				else if (num > 0)
				{
					Util.WriteToChat("Nav: " + navRoute.Name + " - its nearest point is " + dist.ToString("0") + " m away, starting from step 1.");
				}
			}
			else
			{
				_rName = navRoute.Name;
				RouteReset();
			}
		}
		_resumeNearest = false;
		if (_rIdx >= navRoute.Steps.Count)
		{
			_rIdx = 0;
		}
		while (_rDetour.Count > 0 && (_rDetour[0] >= navRoute.Steps.Count || navRoute.Steps[_rDetour[0]].Kind != StepKind.Point))
		{
			_rDetour.RemoveAt(0);
		}
		if (_rDetour.Count > 0)
		{
			RouteStep routeStep = navRoute.Steps[_rDetour[0]];
			NavSpot p = new NavSpot
			{
				Name = navRoute.Name + " #" + (_rDetour[0] + 1),
				NS = routeStep.NS,
				EW = routeStep.EW,
				Z = routeStep.Z,
				Heading = -1.0
			};
			if (TooFar(p))
			{
				_rDetour.Clear();
				return true;
			}
			int stuckEvents = StuckEvents;
			if (ReturnTick(p, navRoute.Arrive, navRoute.Arrive, precise: false))
			{
				Status = "Route " + navRoute.Name + " - backing up - " + Status;
				return true;
			}
			if (StuckEvents != stuckEvents)
			{
				_rDetour.Clear();
				_rStuckSeen = StuckEvents;
				return false;
			}
			_rDetour.RemoveAt(0);
			return true;
		}
		if (_rDone)
		{
			Stop();
			Status = "Route " + navRoute.Name + " done";
			return false;
		}
		RouteStep routeStep2 = navRoute.Steps[_rIdx];
		string text = "step " + (_rIdx + 1) + "/" + navRoute.Steps.Count;
		if (routeStep2.Kind == StepKind.Preset)
		{
			NavRoute navRoute2 = NavPresets.Find(routeStep2.Text);
			if (navRoute2 == null || navRoute2.Steps.Count == 0)
			{
				if (_presetWarned.Add(routeStep2.Text ?? ""))
				{
					Util.WriteToChat("Nav: " + ((navRoute2 == null) ? "there's no preset called " : "the preset has no steps: ") + routeStep2.Text + " - skipping it.");
				}
				_rSubFor = -1;
				Advance(navRoute);
				return true;
			}
			int num2 = (_rSub = Math.Min(SubNow(), navRoute2.Steps.Count - 1));
			_rSubFor = _rIdx;
			routeStep2 = navRoute2.Steps[num2];
			text = "step " + (_rIdx + 1) + "." + (num2 + 1) + "/" + navRoute.Steps.Count + " " + navRoute2.Name;
		}
		DateTime now = DateTime.Now;
		switch (routeStep2.Kind)
		{
		case StepKind.LoopStart:
			ResetConds(navRoute);
			Advance(navRoute);
			return true;
		case StepKind.LoopEnd:
		{
			int num5 = LoopStart(navRoute) + 1;
			if (_rIdx != LoopEndIdx(navRoute))
			{
				Advance(navRoute);
				return true;
			}
			if (CondsMet(routeStep2))
			{
				L("route " + navRoute.Name + " " + text + ": loop done (" + string.Join(", ", routeStep2.Conds.ConvertAll<string>(CondText).ToArray()) + ")");
				ResetConds(navRoute);
				_rDir = 1;
				Advance(navRoute);
				return true;
			}
			Status = "Route " + navRoute.Name + " - round again";
			_rUntil = DateTime.MinValue;
			_rUsedAt = DateTime.MinValue;
			_rStarted = false;
			_rPrevStepAt = _rStepAt;
			_rStepAt = now;
			if (navRoute.Mode == 1)
			{
				_rDir = -1;
				_rIdx = Math.Max(num5, _rIdx - 2);
			}
			else
			{
				_rIdx = num5;
			}
			if (_rIdx >= navRoute.Steps.Count || navRoute.Steps[_rIdx].Kind == StepKind.LoopEnd)
			{
				Status = "Route " + navRoute.Name + " - the loop has no steps";
				return false;
			}
			return true;
		}
		case StepKind.GoRoute:
		{
			NavRoute navRoute3 = null;
			foreach (NavRoute navRoute4 in _s.NavRoutes)
			{
				if (string.Equals(navRoute4.Name, routeStep2.Text, StringComparison.OrdinalIgnoreCase))
				{
					navRoute3 = navRoute4;
				}
			}
			if (navRoute3 == null)
			{
				Util.WriteToChat("Nav: no route called " + routeStep2.Text + " - going on.");
				Advance(navRoute);
				return true;
			}
			Stop();
			_s.NavRouteSelected = navRoute3.Name;
			_rName = navRoute3.Name;
			RouteReset();
			ResetConds(navRoute3);
			if (routeStep2.Op == "nearest")
			{
				int num6 = NearestPoint(navRoute3, this, out var _);
				if (num6 >= 0)
				{
					_rIdx = num6;
				}
			}
			L("route " + navRoute.Name + " " + text + ": on to route " + navRoute3.Name + " at step " + (_rIdx + 1));
			Util.WriteToChat("Nav: on to route " + navRoute3.Name + " (step " + (_rIdx + 1) + ").");
			if (SaveAll != null)
			{
				SaveAll();
			}
			return true;
		}
		case StepKind.Point:
		{
			NavSpot navSpot = new NavSpot
			{
				Name = navRoute.Name + " #" + (_rIdx + 1),
				NS = routeStep2.NS,
				EW = routeStep2.EW,
				Z = routeStep2.Z,
				Heading = -1.0
			};
			if (navRoute.RestartIfFar && _rIdx > 0 && _portalExitAt < _rFarRestartAt && DistanceTo(navSpot) > (double)Math.Max(10f, navRoute.RestartFarM) && (DateTime.Now - _rFarRestartAt).TotalSeconds <= 60.0)
			{
				Stop();
				Status = "Route " + navRoute.Name + " " + text + " is " + DistanceTo(navSpot).ToString("0") + " m away - starting over again in " + (60.0 - (DateTime.Now - _rFarRestartAt).TotalSeconds).ToString("0") + " s";
				return true;
			}
			if (navRoute.RestartIfFar && _rIdx > 0 && (DateTime.Now - _rFarRestartAt).TotalSeconds > 60.0)
			{
				double num8 = DistanceTo(navSpot);
				if (num8 > (double)Math.Max(10f, navRoute.RestartFarM))
				{
					_rFarRestartAt = DateTime.Now;
					Stop();
					_rName = navRoute.Name;
					RouteReset();
					L("route " + navRoute.Name + " " + text + ": " + num8.ToString("0") + " m away (over " + navRoute.RestartFarM.ToString("0") + ") - starting over from step 1");
					Util.WriteToChat("Nav: " + navRoute.Name + " " + text + " is " + num8.ToString("0") + " m away - starting over from step 1.");
					return true;
				}
			}
			if (navRoute == _travelRoute && !TravelPointOk(navSpot))
			{
				return false;
			}
			if (TooFar(navSpot))
			{
				return true;
			}
			NavSpot navSpot2 = navSpot;
			if (navRoute == _travelRoute)
			{
				navSpot = TravelDetour(navSpot);
			}
			bool flag5 = navRoute == _travelRoute && navSpot == navSpot2 && (NextUseCrowded(navRoute) || SharpTurnIndoors(navRoute, navSpot));
			if (ReturnTick(navSpot, flag5 ? Math.Min(navRoute.Arrive, 1.0) : ((double)navRoute.Arrive), flag5 ? Math.Min(navRoute.Arrive, 1.0) : ((double)navRoute.Arrive), flag5))
			{
				Status = "Route " + navRoute.Name + " " + text + " - " + Status + (flag5 ? " (portals close by: carefully)" : "");
				return true;
			}
			if (navSpot != navSpot2 && DateTime.Now >= _pauseUntil)
			{
				_tDetour = null;
				_retarget = true;
				return true;
			}
			if (DateTime.Now < _pauseUntil)
			{
				if (StuckEvents != _rStuckSeen)
				{
					_rStuckSeen = StuckEvents;
					if (_rStuckIdx != _rIdx)
					{
						_rStuckIdx = _rIdx;
						_rStuckN = 0;
					}
					if (++_rStuckN >= Math.Max(1, navRoute.StuckAfter))
					{
						_rStuckN = 0;
						OnStuck(navRoute);
					}
				}
				return false;
			}
			_rStuckN = 0;
			_rStuckIdx = -1;
			EndTempCombat();
			Advance(navRoute);
			RunOnOrStop(navRoute);
			return true;
		}
		case StepKind.Command:
			if (!_rStarted)
			{
				_rStarted = true;
				Stop();
				string text3 = routeStep2.Text;
				if (routeStep2.WaitMs == 1500 && Regex.IsMatch(text3 ?? "", "^/ub jumps? \\d+ \\d+$"))
				{
					text3 = text3.Replace("/ub jumps ", "/ub jumpsw ").Replace("/ub jump ", "/ub jumpw ");
				}
				if (!MtCommand(text3) && !VtCommand(text3))
				{
					Util.Command(text3);
				}
				L("route " + navRoute.Name + " " + text + ": command " + routeStep2.Text);
				_rUntil = now.AddMilliseconds(Math.Max(0, routeStep2.WaitMs));
			}
			Status = "Route " + navRoute.Name + " " + text + " - " + routeStep2.Text;
			if (now >= _rUntil && UbCmd.Jumping && now < _rUntil.AddSeconds(20.0))
			{
				Status += " (jumping)";
				return true;
			}
			if (now >= _rUntil)
			{
				Advance(navRoute);
			}
			return true;
		case StepKind.Toggle:
		{
			string text2 = (routeStep2.Text ?? "").ToLowerInvariant();
			bool flag3 = text2.EndsWith(" on");
			if (text2.StartsWith("combat"))
			{
				_rTempCombat = false;
			}
			if (text2.StartsWith("combat"))
			{
				if (_s.CombatEnabled != flag3)
				{
					_s.CombatEnabled = flag3;
					if (SaveAll != null)
					{
						SaveAll();
					}
				}
			}
			else if (text2.StartsWith("loot"))
			{
				if (_s.LootEnabled != flag3)
				{
					_s.LootEnabled = flag3;
					if (SaveAll != null)
					{
						SaveAll();
					}
				}
			}
			else if (text2.StartsWith("summon"))
			{
				PluginCore.SetSummoningFromNav(flag3);
			}
			else if (text2.StartsWith("doors"))
			{
				if (_s.NavOpenDoors != flag3)
				{
					_s.NavOpenDoors = flag3;
					if (SaveAll != null)
					{
						SaveAll();
					}
				}
			}
			else if (text2 == "reset kills/hr")
			{
				Session.ResetRecentRate();
				Util.WriteToChat("Nav: kills/hr (last 60 min) reset - timing from here.");
			}
			else if (text2 == "reset session")
			{
				Session.Reset();
				Util.WriteToChat("Nav: session reset - tracking from here.");
			}
			L("route " + navRoute.Name + " " + text + ": " + routeStep2.Text);
			Advance(navRoute);
			return true;
		}
		case StepKind.Cast:
			if (!_rStarted)
			{
				bool flag4 = true;
				try
				{
					flag4 = Globals.Core.Actions.CombatMode == CombatState.Magic;
				}
				catch
				{
				}
				if (!flag4)
				{
					if (_rUntil == DateTime.MinValue)
					{
						Stop();
						if (!Session.WandInHand())
						{
							int num7 = Session.AnyWand();
							if (num7 != 0)
							{
								Session.Wield(num7);
								_rCastWield = true;
								L("route " + navRoute.Name + " " + text + ": wielding a wand to cast");
							}
							else
							{
								Util.WriteToChat("Nav: no wand in your packs to cast with.");
							}
						}
						else
						{
							try
							{
								Globals.Core.Actions.SetCombatMode(CombatState.Magic);
							}
							catch
							{
							}
						}
						_rUntil = now.AddSeconds(6.0);
					}
					else if (_rCastWield && Session.WandInHand() && (now - _rCastModeAt).TotalSeconds > 1.5)
					{
						_rCastModeAt = now;
						try
						{
							Globals.Core.Actions.SetCombatMode(CombatState.Magic);
						}
						catch
						{
						}
					}
					if (now < _rUntil)
					{
						Status = "Route " + navRoute.Name + " " + text + " - getting ready to cast";
						return true;
					}
					_rCastWield = false;
				}
				_rStarted = true;
				Stop();
				int.TryParse(routeStep2.Text, out var result);
				_rLandblock = CurrentLb();
				try
				{
					Globals.Core.Actions.CastSpell(result, Globals.Core.CharacterFilter.Id);
				}
				catch (Exception ex2)
				{
					Util.LogError(ex2);
				}
				L("route " + navRoute.Name + " " + text + ": casting " + SpellNames.Name(result));
				_rUsedAt = now;
				_rUntil = now.AddSeconds(20.0);
			}
			Status = "Route " + navRoute.Name + " " + text + " - casting " + (SpellNames.Name(int.Parse("0" + routeStep2.Text)) ?? routeStep2.Text);
			if (_rUsedAt.Ticks == 1 || (CurrentLb() != _rLandblock && CurrentLb() > 0))
			{
				Advance(navRoute);
				_rUntil = DateTime.Now.AddSeconds(Tuning.V("AfterPortalS"));
				return true;
			}
			if (now >= _rUntil)
			{
				if (navRoute == _travelRoute)
				{
					if (_tUseIdx != _rIdx)
					{
						_tUseIdx = _rIdx;
						_tUseTries = 0;
					}
					if (++_tUseTries < 2)
					{
						L("route " + navRoute.Name + " " + text + ": the recall didn't happen - casting again");
						_rStarted = false;
						_rUntil = DateTime.MinValue;
						return true;
					}
					TravelStop("the recall (" + (SpellNames.Name(int.Parse("0" + routeStep2.Text)) ?? routeStep2.Text) + ") didn't take you anywhere", finished: false);
					return true;
				}
				Advance(navRoute);
			}
			return true;
		case StepKind.Vendor:
			// one whole vendor visit (Items > Vendor): the route waits while it runs, and goes on once it's done
			if (!_rStarted)
			{
				_rStarted = true;
				Stop();
				if (VendorRun.I == null || !VendorRun.I.Start(routeStep2.Text, routeStep2.Profile, dry: false))
				{
					Advance(navRoute);
				}
				return true;
			}
			if (VendorRun.I != null && VendorRun.I.Busy)
			{
				Status = "Route " + navRoute.Name + " " + text + " - vendor: " + VendorRun.I.Status;
				return true;
			}
			L("route " + navRoute.Name + " " + text + ": vendor visit " + VendorRun.ResultWord(VendorRun.Last));
			Advance(navRoute);
			return true;
		case StepKind.UseItem:
			if (!_rStarted && now < _rUseRetryAt)
			{
				Status = "Route " + navRoute.Name + " " + text + " - trying " + routeStep2.Text + " again";
				return true;
			}
			if (!_rStarted)
			{
				WorldObject worldObject3 = FindInPack(routeStep2.Text);
				if (worldObject3 == null)
				{
					Util.WriteToChat("Nav: no " + routeStep2.Text + " in your packs - going on to the next step.");
					Advance(navRoute);
					return true;
				}
				_rStarted = true;
				Stop();
				_rLandblock = CurrentLb();
				if (_rUseIdx != StepKey())
				{
					_rUseIdx = StepKey();
					_rUseTries = 0;
				}
				_rUseTries++;
				_rUseHad = InventoryCount(routeStep2.Text);
				try
				{
					Globals.Core.Actions.UseItem(worldObject3.Id, 0);
				}
				catch (Exception ex3)
				{
					Util.LogError(ex3);
				}
				L("route " + navRoute.Name + " " + text + ": using " + worldObject3.Name);
				_rUsedAt = now;
				_rUntil = now.AddMilliseconds(Math.Max(1000, routeStep2.WaitMs));
			}
			Status = "Route " + navRoute.Name + " " + text + " - using " + routeStep2.Text;
			if (_rUsedAt.Ticks == 1 || (CurrentLb() != _rLandblock && CurrentLb() > 0))
			{
				_rUseIdx = -1;
				Advance(navRoute);
				_rUntil = DateTime.Now.AddSeconds(Tuning.V("AfterPortalS"));
				return true;
			}
			if (now >= _rUntil)
			{
				if (InventoryCount(routeStep2.Text) >= _rUseHad && _rUseHad > 0 && _rUseTries < 3)
				{
					L("route " + navRoute.Name + " " + text + ": " + routeStep2.Text + " doesn't seem to have been used - trying again (" + (_rUseTries + 1) + "/3)");
					_rStarted = false;
					_rUsedAt = DateTime.MinValue;
					_rUseRetryAt = now.AddSeconds(2.0);
					return true;
				}
				_rUseIdx = -1;
				Advance(navRoute);
			}
			return true;
		case StepKind.ChatWait:
			if (!_rStarted)
			{
				_rStarted = true;
				Stop();
				L("route " + navRoute.Name + " " + text + ": waiting for chat " + routeStep2.Op + " \"" + routeStep2.Text + "\"");
			}
			Status = "Route " + navRoute.Name + " " + text + " - waiting for chat " + routeStep2.Op + " \"" + routeStep2.Text + "\"";
			if (ChatSeen(routeStep2, _rPrevStepAt))
			{
				L("route " + navRoute.Name + " " + text + ": chat matched");
				Advance(navRoute);
			}
			return true;
		case StepKind.ItemCheck:
		{
			if (!_rStarted)
			{
				_rStarted = true;
				Stop();
			}
			if ((now - _rItemCheckAt).TotalMilliseconds < Tuning.V("ItemCheckMs"))
			{
				return true;
			}
			_rItemCheckAt = now;
			int have = InventoryCount(routeStep2.Text);
			Status = "Route " + navRoute.Name + " " + text + " - waiting for " + routeStep2.Text + " " + routeStep2.Op + " " + routeStep2.Count + " (have " + have + ")";
			if (Compare(have, routeStep2.Op, routeStep2.Count))
			{
				L("route " + navRoute.Name + " " + text + ": " + routeStep2.Text + " " + have + " " + routeStep2.Op + " " + routeStep2.Count + " - go on");
				Advance(navRoute);
			}
			return true;
		}
		case StepKind.PlayerSkip:
		{
			double num9 = SkipRange(routeStep2);
			string text4 = NearestPlayer(out var dist3);
			int num10 = Math.Max(0, routeStep2.Count);
			Advance(navRoute);
			if (text4 != null && dist3 <= num9)
			{
				string text5 = SkipSteps(navRoute, num10);
				L("route " + navRoute.Name + " " + text + ": " + text4 + " is " + dist3.ToString("0") + " m away - skipping the next " + num10 + " step" + ((num10 == 1) ? "" : "s") + text5);
			}
			else if (SkipNoMobs(routeStep2) && !MonsterInCombatRange())
			{
				string text6 = SkipSteps(navRoute, num10);
				L("route " + navRoute.Name + " " + text + ": no monsters in combat range - skipping the next " + num10 + " step" + ((num10 == 1) ? "" : "s") + text6);
			}
			return true;
		}
		case StepKind.Wait:
			if (!_rStarted)
			{
				_rStarted = true;
				Stop();
				_rUntil = now.AddMilliseconds(Math.Max(0, routeStep2.WaitMs));
			}
			Status = "Route " + navRoute.Name + " " + text + " - waiting " + Math.Max(0.0, (_rUntil - now).TotalSeconds).ToString("0") + "s";
			if (now >= _rUntil)
			{
				Advance(navRoute);
			}
			return true;
		case StepKind.Use:
		{
			if (!_rStarted)
			{
				WorldObject worldObject = FindUse(routeStep2);
				if (worldObject == null)
				{
					if (_rUntil == DateTime.MinValue)
					{
						_rUntil = now.AddSeconds(Tuning.V("UseFindS"));
					}
					Status = "Route " + navRoute.Name + " " + text + " - looking for " + routeStep2.Text;
					if (now >= _rUntil)
					{
						if (navRoute == _travelRoute)
						{
							TravelStop("couldn't find the portal " + (string.IsNullOrEmpty(routeStep2.Text) ? "here" : routeStep2.Text), finished: false);
							return true;
						}
						Util.WriteToChat("Nav: couldn't find " + routeStep2.Text + " - going on to the next step.");
						Advance(navRoute);
					}
					return true;
				}
				if (navRoute == _travelRoute && Crowded(worldObject))
				{
					if (_useFaceUntil == DateTime.MinValue)
					{
						Stop();
						CoordsObject coordsObject = worldObject.Coordinates();
						try
						{
							Globals.Core.Actions.FaceHeading(BearingTo(new NavSpot
							{
								NS = coordsObject.NorthSouth,
								EW = coordsObject.EastWest
							}), true);
						}
						catch
						{
						}
						_useFaceUntil = now.AddMilliseconds(Tuning.V("UseFaceMs"));
					}
					if (now < _useFaceUntil)
					{
						Status = "Route " + navRoute.Name + " " + text + " - facing " + worldObject.Name;
						return true;
					}
				}
				if (now < _useDoorWait)
				{
					Status = "Route " + navRoute.Name + " " + text + " - opening the door to " + worldObject.Name;
					return true;
				}
				int num3 = DoorBetween(worldObject);
				if (num3 != 0)
				{
					bool? flag = DoorShut(num3);
					if (!flag.HasValue)
					{
						Status = "Route " + navRoute.Name + " " + text + " - checking the door to " + worldObject.Name;
						return true;
					}
					if (flag == true)
					{
						Stop();
						try
						{
							Globals.Core.Actions.UseItem(num3, 0);
						}
						catch
						{
						}
						_tDoorUsed[num3] = now;
						_doorUseAt = now;
						_doorRerun = true;
						_useDoorWait = now.AddSeconds(2.5);
						L("route " + navRoute.Name + " " + text + ": a door between you and " + worldObject.Name + " - opening it first");
						return true;
					}
				}
				_useFaceUntil = DateTime.MinValue;
				_rStarted = true;
				Stop();
				_rLandblock = CurrentLb();
				try
				{
					Globals.Core.Actions.UseItem(worldObject.Id, 0);
				}
				catch (Exception ex)
				{
					Util.LogError(ex);
				}
				L("route " + navRoute.Name + " " + text + ": using " + worldObject.Name);
				_rUsedAt = now;
				_rUntil = now.AddSeconds(PortalLike(worldObject) ? Tuning.V("UsePortalS") : Tuning.V("UseNpcS"));
			}
			bool flag2 = _rUsedAt.Ticks == 1 || (CurrentLb() != _rLandblock && CurrentLb() > 0);
			Status = "Route " + navRoute.Name + " " + text + " - using " + routeStep2.Text;
			if (flag2)
			{
				Advance(navRoute);
				_rUntil = DateTime.Now.AddSeconds(Tuning.V("AfterPortalS"));
				return true;
			}
			if (navRoute == _travelRoute && (now - _rUsedAt).TotalSeconds > 3.0 && now >= _useDoorWait)
			{
				WorldObject worldObject2 = FindUse(routeStep2);
				int num4 = ((worldObject2 != null) ? DoorBetween(worldObject2) : 0);
				if (num4 != 0 && DoorShut(num4) == true)
				{
					Stop();
					try
					{
						Globals.Core.Actions.UseItem(num4, 0);
					}
					catch
					{
					}
					_tDoorUsed[num4] = now;
					_doorUseAt = now;
					_doorRerun = true;
					_useDoorWait = now.AddSeconds(2.5);
					_rStarted = false;
					_rUntil = DateTime.MinValue;
					L("route " + navRoute.Name + " " + text + ": a shut door between you and " + routeStep2.Text + " - opening it, then using it again");
					return true;
				}
			}
			if (now >= _rUntil)
			{
				if (navRoute == _travelRoute)
				{
					if (_tUseIdx != _rIdx)
					{
						_tUseIdx = _rIdx;
						_tUseTries = 0;
					}
					if (++_tUseTries < 3)
					{
						L("route " + navRoute.Name + " " + text + ": didn't go through " + routeStep2.Text + " - trying again (" + _tUseTries + ")");
						_rStarted = false;
						_rUntil = DateTime.MinValue;
						return true;
					}
					TravelStop("used " + (string.IsNullOrEmpty(routeStep2.Text) ? "the portal" : routeStep2.Text) + " 3 times but didn't go through", finished: false);
					return true;
				}
				Advance(navRoute);
			}
			return true;
		}
		default:
			return false;
		}
	}

	private void RunOnOrStop(NavRoute r)
	{
		if (!_running)
		{
			return;
		}
		RouteStep routeStep = ((!_rDone && _rIdx >= 0 && _rIdx < r.Steps.Count) ? r.Steps[_rIdx] : null);
		if (routeStep == null || routeStep.Kind != StepKind.Point)
		{
			Stop();
			return;
		}
		NavSpot p = new NavSpot
		{
			NS = routeStep.NS,
			EW = routeStep.EW,
			Z = routeStep.Z
		};
		double num = DistanceTo(p);
		double num2 = CombatEngine.MyHeading();
		double num3 = ((num2 < 0.0) ? 180.0 : AngleDiff(BearingTo(p), num2));
		if (num3 >= (double)_s.NavTurnAngle || (num >= 0.0 && num < (double)_s.NavCloseDist && num3 >= (double)_s.NavCloseAngle))
		{
			L("point reached - next bends " + num3.ToString("0") + " deg at " + num.ToString("0.0") + " m: stop and turn");
			Stop();
		}
		else
		{
			L("point reached - running on (bend " + num3.ToString("0") + " deg, " + num.ToString("0.0") + " m)");
			_retarget = true;
		}
	}

	private void UpdateRouteMarkers()
	{
		NavRoute navRoute = _travelPreview ?? ((_s.NavMode == 1 && _s.NavRouteShowAll) ? CurrentRoute : null);
		bool flag = navRoute != null && navRoute == _travelPreview;
		string text = "";
		int num = 0;
		int num2 = int.MaxValue;
		if (navRoute != null && navRoute.Steps.Count > 150)
		{
			int num3 = ((!flag) ? Math.Max(0, Math.Min(_rIdx, navRoute.Steps.Count - 1)) : 0);
			num = Math.Max(0, num3 / 20 * 20 - 30);
			num2 = num + 150;
		}
		if (navRoute != null)
		{
			StringBuilder stringBuilder = new StringBuilder(navRoute.Name + "#" + num + "#sel" + _rSel);
			foreach (RouteStep step in navRoute.Steps)
			{
				stringBuilder.Append('|').Append((int)step.Kind).Append(step.NS.ToString("0.0000"))
					.Append(step.EW.ToString("0.0000"));
			}
			text = stringBuilder.ToString();
		}
		if (text == _routeKey)
		{
			if (_routeObjs.Count <= 0 || !((DateTime.Now - _routeVisCheck).TotalMilliseconds >= 250.0))
			{
				return;
			}
			_routeVisCheck = DateTime.Now;
			bool flag2 = !_s.NavHideUnfocused || GameFocused();
			foreach (D3DObj routeObj in _routeObjs)
			{
				SetVisible(routeObj, flag2);
			}
			NoteFocus(flag2, _routeObjs.Count);
			return;
		}
		_routeKey = text;
		ClearRouteMarkers();
		if (navRoute == null)
		{
			return;
		}
		try
		{
			D3DService d3DService = Globals.Core.D3DService;
			RouteStep routeStep = null;
			int num4 = 0;
			for (int i = num; i < navRoute.Steps.Count && i < num2; i++)
			{
				if (_routeObjs.Count >= 1500)
				{
					break;
				}
				RouteStep routeStep2 = navRoute.Steps[i];
				if (routeStep2.Kind == StepKind.Point || routeStep2.Kind == StepKind.Use)
				{
					num4++;
					bool flag3 = i == _rSel;
					D3DObj d3DObj = d3DService.MarkCoordsWithShape((float)routeStep2.NS, (float)routeStep2.EW, (float)routeStep2.Z + 0.05f, D3DShape.Ring, flag3 ? (-52429) : (-1436112129));
					if (d3DObj != null)
					{
						d3DObj.Scale(flag3 ? 0.9f : 0.6f);
						_routeObjs.Add(d3DObj);
					}
					bool flag4 = flag && routeStep2.Kind == StepKind.Use;
					string text2 = (flag4 ? (i + 1 + " " + (string.IsNullOrEmpty(routeStep2.Text) ? "portal" : routeStep2.Text)) : (i + 1).ToString());
					if (flag4 && d3DObj != null)
					{
						d3DObj.Color = -12256;
					}
					D3DObj d3DObj2 = d3DService.MarkCoordsWith3DText((float)routeStep2.NS, (float)routeStep2.EW, (float)routeStep2.Z + 1f, text2, "Arial", 0);
					if (d3DObj2 != null)
					{
						D3DObj d3DObj3 = d3DObj2;
						int color;
						if (flag3)
						{
							color = -52429;
						}
						else
						{
							color = (flag4 ? (-12256) : (-6697729));
						}
						d3DObj3.Color = color;
						d3DObj2.Scale(flag3 ? 0.4f : 0.3f);
						d3DObj2.OrientToCamera(true);
						_routeObjs.Add(d3DObj2);
					}
					if (routeStep != null && routeStep2.Kind == StepKind.Point && routeStep.Kind == StepKind.Point)
					{
						Dots(d3DService, routeStep, routeStep2);
					}
					routeStep = routeStep2;
				}
			}
			int num5 = LoopEndIdx(navRoute);
			if (num5 >= 0)
			{
				routeStep = null;
				for (int num6 = num5 - 1; num6 > LoopStart(navRoute); num6--)
				{
					if (navRoute.Steps[num6].Kind == StepKind.Point)
					{
						routeStep = navRoute.Steps[num6];
						break;
					}
				}
			}
			if (num2 == int.MaxValue && (navRoute.Mode == 2 || (num5 >= 0 && navRoute.Mode != 1)) && routeStep != null && routeStep.Kind == StepKind.Point)
			{
				int num7 = LoopStart(navRoute);
				for (int j = num7 + 1; j < navRoute.Steps.Count; j++)
				{
					if (navRoute.Steps[j].Kind == StepKind.Point)
					{
						if (navRoute.Steps[j] != routeStep)
						{
							Dots(d3DService, routeStep, navRoute.Steps[j]);
						}
						break;
					}
				}
			}
			_routeVisCheck = DateTime.MinValue;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void Dots(D3DService d3d, RouteStep a, RouteStep b)
	{
		double num = (b.NS - a.NS) * 240.0;
		double num2 = (b.EW - a.EW) * 240.0;
		double num3 = Math.Sqrt(num * num + num2 * num2);
		int num4 = Math.Min(60, (int)(num3 / 2.5));
		for (int i = 1; i < num4; i++)
		{
			if (_routeObjs.Count >= 1500)
			{
				break;
			}
			double num5 = (double)i / (double)num4;
			D3DObj d3DObj = d3d.MarkCoordsWithShape((float)(a.NS + (b.NS - a.NS) * num5), (float)(a.EW + (b.EW - a.EW) * num5), (float)(a.Z + (b.Z - a.Z) * num5) + 0.3f, D3DShape.Sphere, -2006537473);
			if (d3DObj != null)
			{
				d3DObj.Scale(0.12f);
				_routeObjs.Add(d3DObj);
			}
		}
	}

	private void ClearRouteMarkers()
	{
		int count = _routeObjs.Count;
		int num = 0;
		string text = null;
		foreach (D3DObj routeObj in _routeObjs)
		{
			try
			{
				routeObj.Visible = false;
			}
			catch (Exception ex)
			{
				num++;
				if (text == null)
				{
					text = "hide: " + ex.GetType().Name + " " + ex.Message;
				}
			}
			try
			{
				routeObj.Scale(0.0001f);
			}
			catch
			{
			}
			try
			{
				((IDisposable)routeObj)?.Dispose();
			}
			catch (Exception ex2)
			{
				num++;
				if (text == null)
				{
					text = "dispose: " + ex2.GetType().Name + " " + ex2.Message;
				}
			}
		}
		_routeObjs.Clear();
		if (count > 0)
		{
			L("route markers cleared: " + count + ((num > 0) ? (" - " + num + " failed (" + text + ")") : ""));
		}
	}

	private static int CurrentLb()
	{
		try
		{
			return Globals.Core.Actions.Landcell >>> 16;
		}
		catch
		{
			return 0;
		}
	}

	private static WorldObject FindInPack(string name)
	{
		if (string.IsNullOrEmpty(name))
		{
			return null;
		}
		WorldObject worldObject = null;
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
				{
					return item;
				}
				if (worldObject == null && item.Name != null && item.Name.IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0)
				{
					worldObject = item;
				}
			}
		}
		catch
		{
		}
		return worldObject;
	}

	private static List<string> PackGems()
	{
		List<string> list = new List<string>();
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (item.ObjectClass == ObjectClass.Gem && !string.IsNullOrEmpty(item.Name) && !list.Contains(item.Name))
				{
					list.Add(item.Name);
				}
			}
		}
		catch
		{
		}
		list.Sort(StringComparer.OrdinalIgnoreCase);
		return list;
	}

	private static List<KeyValuePair<int, string>> KnownRecalls()
	{
		List<KeyValuePair<int, string>> list = new List<KeyValuePair<int, string>>();
		try
		{
			foreach (int item in PortalSpellIds.All)
			{
				bool flag = false;
				try
				{
					flag = Globals.Core.CharacterFilter.IsSpellKnown(item);
				}
				catch
				{
				}
				if (flag)
				{
					list.Add(new KeyValuePair<int, string>(item, SpellNames.Name(item) ?? ("Spell " + item)));
				}
			}
		}
		catch
		{
		}
		list.Sort((KeyValuePair<int, string> a, KeyValuePair<int, string> b) => string.Compare(a.Value, b.Value, StringComparison.OrdinalIgnoreCase));
		return list;
	}

	private bool SharpTurnIndoors(NavRoute r, NavSpot to)
	{
		try
		{
			if ((Globals.Core.Actions.Landcell & 0xFFFF) < 256)
			{
				return false;
			}
			if (_rIdx + 1 >= r.Steps.Count)
			{
				return true;
			}
			RouteStep routeStep = r.Steps[_rIdx + 1];
			if (routeStep.Kind != StepKind.Point)
			{
				return false;
			}
			MyPos(out var ns, out var ew, out var _);
			double num = to.EW - ew;
			double num2 = to.NS - ns;
			double num3 = routeStep.EW - to.EW;
			double num4 = routeStep.NS - to.NS;
			double num5 = Math.Sqrt(num * num + num2 * num2);
			double num6 = Math.Sqrt(num3 * num3 + num4 * num4);
			if (num5 * 240.0 < 1.5 || num6 * 240.0 < 0.5)
			{
				return false;
			}
			double num7 = (num * num3 + num2 * num4) / (num5 * num6);
			return num7 < Math.Cos(Math.PI * 5.0 / 18.0);
		}
		catch
		{
			return false;
		}
	}

	private static bool Crowded(WorldObject o)
	{
		try
		{
			CoordsObject coordsObject = o.Coordinates();
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				if (item.Id != o.Id && PortalLike(item))
				{
					CoordsObject coordsObject2 = item.Coordinates();
					double num = (coordsObject2.NorthSouth - coordsObject.NorthSouth) * 240.0;
					double num2 = (coordsObject2.EastWest - coordsObject.EastWest) * 240.0;
					if (num * num + num2 * num2 < 100.0)
					{
						return true;
					}
				}
			}
		}
		catch
		{
		}
		return false;
	}

	private bool NextUseCrowded(NavRoute r)
	{
		try
		{
			if (_rIdx + 1 >= r.Steps.Count)
			{
				return false;
			}
			RouteStep routeStep = r.Steps[_rIdx + 1];
			if (routeStep.Kind != StepKind.Use)
			{
				return false;
			}
			int num = 0;
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				if (PortalLike(item))
				{
					CoordsObject coordsObject = item.Coordinates();
					double num2 = (coordsObject.NorthSouth - routeStep.NS) * 240.0;
					double num3 = (coordsObject.EastWest - routeStep.EW) * 240.0;
					if (num2 * num2 + num3 * num3 < 144.0 && ++num >= 2)
					{
						return true;
					}
				}
			}
		}
		catch
		{
		}
		return false;
	}

	private WorldObject FindUse(RouteStep st)
	{
		WorldObject worldObject = FindUseNamed(st);
		if (worldObject != null || _travelRoute == null || CurrentRoute != _travelRoute)
		{
			return worldObject;
		}
		string text = TravelNorm(st.Text);
		int num = text.LastIndexOf(" to ", StringComparison.Ordinal);
		string text2 = ((num >= 0) ? text.Substring(num + 4).Trim() : text);
		WorldObject worldObject2 = null;
		WorldObject worldObject3 = null;
		double num2 = double.MaxValue;
		double num3 = double.MaxValue;
		int num4 = 0;
		try
		{
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				if (!PortalLike(item))
				{
					continue;
				}
				CoordsObject coordsObject = item.Coordinates();
				double num5 = (coordsObject.NorthSouth - st.NS) * 240.0;
				double num6 = (coordsObject.EastWest - st.EW) * 240.0;
				double num7 = Math.Sqrt(num5 * num5 + num6 * num6);
				string text3 = TravelNorm(item.Name);
				string text4 = (text3.EndsWith(" portal", StringComparison.Ordinal) ? text3.Substring(0, text3.Length - 7).Trim() : text3);
				int num8 = 0;
				if (text2.Length > 0 && text4.Length > 0)
				{
					if (text4 == text2 || text3 == text || text4 == text)
					{
						num8 = 3;
					}
					else if (text4.StartsWith(text2, StringComparison.Ordinal) || text2.StartsWith(text4, StringComparison.Ordinal))
					{
						num8 = 2;
					}
					else if (text3.Contains(text2) || text2.Contains(text4))
					{
						num8 = 1;
					}
				}
				if (num8 > 0 && num7 <= 60.0 && (num8 > num4 || (num8 == num4 && num7 < num2)))
				{
					num4 = num8;
					num2 = num7;
					worldObject2 = item;
				}
				if (num7 < num3)
				{
					num3 = num7;
					worldObject3 = item;
				}
			}
		}
		catch
		{
		}
		if (worldObject2 != null && num2 <= 60.0)
		{
			return worldObject2;
		}
		return (worldObject3 != null && num3 <= 3.0) ? worldObject3 : null;
	}

	private static bool PortalLike(WorldObject o)
	{
		if (o.ObjectClass == ObjectClass.Portal)
		{
			return true;
		}
		ObjectClass objectClass = o.ObjectClass;
		return o.Container == 0 && (o.Name ?? "").EndsWith(" Portal", StringComparison.OrdinalIgnoreCase) && objectClass != ObjectClass.Npc && objectClass != ObjectClass.Vendor && objectClass != ObjectClass.Monster && objectClass != ObjectClass.Player && objectClass != ObjectClass.Corpse;
	}

	private static string TravelNorm(string s)
	{
		return (s ?? "").Replace('`', '\'').Replace('’', '\'').Replace('‘', '\'')
			.Trim()
			.ToLowerInvariant();
	}

	private static WorldObject FindUseNamed(RouteStep st)
	{
		WorldObject worldObject = null;
		double num = double.MaxValue;
		try
		{
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				if (string.Equals(item.Name, st.Text, StringComparison.OrdinalIgnoreCase))
				{
					double num4;
					try
					{
						CoordsObject coordsObject = item.Coordinates();
						double num2 = (coordsObject.NorthSouth - st.NS) * 240.0;
						double num3 = (coordsObject.EastWest - st.EW) * 240.0;
						num4 = Math.Sqrt(num2 * num2 + num3 * num3);
					}
					catch
					{
						num4 = 1000.0;
					}
					if (num4 < num)
					{
						num = num4;
						worldObject = item;
					}
				}
			}
		}
		catch
		{
		}
		if (worldObject != null && num <= Tuning.V("UseRangeM"))
		{
			return worldObject;
		}
		// (none by that name near where the step was made - a route made in another client, whose coordinates in a
		// dungeon don't line up with these: the nearest by that name near you, if there's one)
		WorldObject near = null;
		double best = double.MaxValue;
		try
		{
			foreach (WorldObject item2 in Globals.Core.WorldFilter.GetLandscape())
			{
				if (string.Equals(item2.Name, st.Text, StringComparison.OrdinalIgnoreCase))
				{
					double d = CombatEngine.Distance(item2);
					if (d >= 0.0 && d < best)
					{
						best = d;
						near = item2;
					}
				}
			}
		}
		catch
		{
		}
		return (near != null && best <= Tuning.V("UseRangeM")) ? near : null;
	}

	private RouteStep NewPointHere(StepKind k)
	{
		if (!MyPos(out var ns, out var ew, out var z))
		{
			Util.WriteToChat("Nav: couldn't read your position.");
			return null;
		}
		return new RouteStep
		{
			Kind = k,
			NS = ns,
			EW = ew,
			Z = z
		};
	}

	private void Insert(NavRoute r, RouteStep st)
	{
		if (st != null)
		{
			int num = ((_rSel >= 0 && _rSel < r.Steps.Count) ? (_rSel + 1) : r.Steps.Count);
			r.Steps.Insert(num, st);
			_rSel = num;
		}
	}

	private bool DrawLoopEnd(NavRoute r, RouteStep st)
	{
		bool result = false;
		ImGui.Separator();
		Im.TextColored(Cyan, "Loop end (step " + (r.Steps.IndexOf(st) + 1) + "): leave the loop when ALL of these are true");
		if (r.Steps.IndexOf(st) != LoopEndIdx(r))
		{
			Im.TextColored(Yellow, "This isn't the loop end that closes the loop (there's another one before it) - it's skipped.");
		}
		int num = -1;
		for (int i = 0; i < st.Conds.Count; i++)
		{
			ImGui.PushID("lc" + i);
			if (ImGui.SmallButton("x"))
			{
				num = i;
			}
			ImGui.SameLine();
			ImGui.TextUnformatted(((i > 0) ? "and " : "") + CondText(st.Conds[i]));
			ImGui.PopID();
		}
		if (num >= 0)
		{
			st.Conds.RemoveAt(num);
			result = true;
		}
		if (st.Conds.Count == 0)
		{
			Im.TextColored(Grey, "No conditions yet: it loops for ever.");
		}
		ImGui.SetNextItemWidth(220f);
		ImGui.InputText("##lcitem", ref _rcText, 200u);
		ImGui.SameLine();
		if (ImGui.SmallButton("sel##lcsel"))
		{
			try
			{
				WorldObject worldObject = Globals.Core.WorldFilter[Globals.Core.Actions.CurrentSelection];
				if (worldObject != null)
				{
					_rcText = worldObject.Name;
				}
			}
			catch
			{
			}
		}
		Tip("Use the name of the item you have selected.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(60f);
		ImGui.Combo("##lcop", ref _rcOp, ItemOps, ItemOps.Length);
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		ImGui.InputInt("##lcnum", ref _rcNum, 1, 10);
		if (_rcNum < 0)
		{
			_rcNum = 0;
		}
		ImGui.SameLine();
		if (ImGui.Button("Add item condition") && _rcText.Trim().Length > 0)
		{
			st.Conds.Add(new LoopCond
			{
				Text = _rcText.Trim(),
				Op = ItemOps[_rcOp],
				Count = _rcNum
			});
			_rcText = "";
			result = true;
		}
		Tip("Items in your packs (stacks counted; exact name first, else names containing it).");
		ImGui.SetNextItemWidth(220f);
		ImGui.InputText("##lcchat", ref _rcChat, 200u);
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		ImGui.Combo("##lcchatop", ref _rcChatOp, ChatOps, ChatOps.Length);
		ImGui.SameLine();
		if (ImGui.Button("Add chat condition") && _rcChat.Trim().Length > 0)
		{
			st.Conds.Add(new LoopCond
			{
				Chat = true,
				Text = _rcChat.Trim(),
				Op = ChatOps[_rcChatOp]
			});
			_rcChat = "";
			result = true;
		}
		Tip("True once a matching chat line has come in since the loop started (e.g. a quest's 'You have collected enough' message).");
		ImGui.Separator();
		return result;
	}

	private static string Describe(RouteStep st)
	{
		switch (st.Kind)
		{
		case StepKind.Point:
			return Math.Abs(st.NS).ToString("0.000") + ((st.NS >= 0.0) ? "N" : "S") + ", " + Math.Abs(st.EW).ToString("0.000") + ((st.EW >= 0.0) ? "E" : "W");
		case StepKind.Command:
			return st.Text + "   (then " + st.WaitMs + " ms)";
		case StepKind.Use:
			return st.Text;
		case StepKind.Vendor:
			return "Vendor at " + st.Text + "   (profile " + (string.IsNullOrEmpty(st.Profile) ? "named after the vendor" : st.Profile) + ")";
		case StepKind.UseItem:
			return "Use " + st.Text + "   (then up to " + ((double)st.WaitMs / 1000.0).ToString("0.#") + " s)";
		case StepKind.Wait:
			return ((double)st.WaitMs / 1000.0).ToString("0.#") + " s";
		case StepKind.PlayerSkip:
			return "a player within " + SkipRange(st).ToString("0") + " m" + (SkipNoMobs(st) ? " or no monsters in combat range" : "") + ": skip the next " + st.Count + " step" + ((st.Count == 1) ? "" : "s");
		case StepKind.LoopStart:
			return "---- the steps below repeat ----";
		case StepKind.LoopEnd:
			return (st.Conds.Count == 0) ? "---- back to the loop start (add conditions to leave it) ----" : ("---- round again until " + string.Join(" and ", st.Conds.ConvertAll<string>(CondText).ToArray()) + " ----");
		case StepKind.GoRoute:
			return "-> route " + st.Text + ((st.Op == "nearest") ? "  (at its nearest point)" : "  (from step 1)");
		case StepKind.ChatWait:
			return "until chat " + st.Op + " \"" + st.Text + "\"";
		case StepKind.ItemCheck:
			return "until " + st.Text + " " + st.Op + " " + st.Count + "   (have " + InventoryCount(st.Text) + ")";
		case StepKind.Cast:
		{
			int.TryParse(st.Text, out var result);
			return "Cast " + (SpellNames.Name(result) ?? ("spell " + st.Text));
		}
		case StepKind.Preset:
		{
			NavRoute navRoute = NavPresets.Find(st.Text);
			return st.Text + ((navRoute == null) ? "   (no preset by this name - skipped)" : ("   (" + navRoute.Steps.Count + " step" + ((navRoute.Steps.Count == 1) ? "" : "s") + ")"));
		}
		case StepKind.Toggle:
			return (st.Text ?? "").Replace("combat", "Combat").Replace("looting", "Looting").Replace("summoning", "Summoning")
				.Replace("reset session", "Reset session")
				.Replace("reset kills/hr", "Reset kills/hr")
				.Replace("doors", "Doors")
				.Replace(" on", " ON")
				.Replace(" off", " OFF");
		default:
			return "";
		}
	}

	private static bool AddButton(string label)
	{
		return ImGui.Button(label, new System.Numerics.Vector2(150f, 0f));
	}

	private List<string> OtherRoutes(NavRoute r)
	{
		List<string> list = new List<string>();
		foreach (NavRoute navRoute in _s.NavRoutes)
		{
			if (navRoute != r)
			{
				list.Add(navRoute.Name);
			}
		}
		return list;
	}

	private RouteStep UseStepFromSelection()
	{
		int num = 0;
		try
		{
			num = Globals.Core.Actions.CurrentSelection;
		}
		catch
		{
		}
		WorldObject worldObject = ((num != 0) ? Globals.Core.WorldFilter[num] : null);
		CoordsObject coordsObject = null;
		try
		{
			coordsObject = worldObject?.Coordinates();
		}
		catch
		{
		}
		if (worldObject == null || coordsObject == null)
		{
			Util.WriteToChat("Nav: select a portal or NPC in the world first.");
			return null;
		}
		double z = 0.0;
		try
		{
			z = worldObject.RawCoordinates().Z;
		}
		catch
		{
		}
		return new RouteStep
		{
			Kind = StepKind.Use,
			Text = worldObject.Name,
			NS = coordsObject.NorthSouth,
			EW = coordsObject.EastWest,
			Z = z
		};
	}

	private static string KindName(StepKind k)
	{
		return k switch
		{
			StepKind.Point => "Point", 
			StepKind.Command => "Command", 
			StepKind.Use => "Use", 
			StepKind.Wait => "Wait", 
			StepKind.Toggle => "Switch", 
			StepKind.Cast => "Cast", 
			StepKind.ChatWait => "Chat wait", 
			StepKind.ItemCheck => "Item check", 
			StepKind.LoopEnd => "Loop end", 
			StepKind.GoRoute => "Go to route", 
			StepKind.UseItem => "Use item", 
			StepKind.Preset => "Preset", 
			StepKind.PlayerSkip => "Player skip", 
			StepKind.Vendor => "Vendor", 
			_ => "Loop", 
		};
	}

	private bool DrawEditRow(NavRoute r)
	{
		bool result = false;
		if (_rEdit == null)
		{
			bool flag = _rSel >= 0 && _rSel < r.Steps.Count;
			if (AddButton("Edit step"))
			{
				if (!flag)
				{
					Util.WriteToChat("Nav: click a step in the list first, then Edit step.");
				}
				else
				{
					StartEdit(r, r.Steps[_rSel]);
				}
			}
			Tip("Puts the selected step's settings into the boxes below so you can change them, then Update.");
			ImGui.SameLine();
			Im.TextColored(Grey, flag ? ("step " + (_rSel + 1) + " (" + KindName(r.Steps[_rSel].Kind) + ") selected") : "click a step in the list to select it");
			return false;
		}
		RouteStep rEdit = _rEdit;
		int num = r.Steps.IndexOf(rEdit);
		if (AddButton("Update"))
		{
			ApplyEdit(r, rEdit);
			_rEdit = null;
			return true;
		}
		Tip("Saves the boxes into this step.");
		ImGui.SameLine();
		if (ImGui.Button("Cancel##redit", new System.Numerics.Vector2(80f, 0f)))
		{
			_rEdit = null;
			return false;
		}
		ImGui.SameLine();
		string text = ((rEdit.Kind == StepKind.Point || rEdit.Kind == StepKind.Use) ? "change it here" : ("change it in the " + KindName(rEdit.Kind) + " row below"));
		Im.TextColored(Yellow, "Editing step " + (num + 1) + " (" + KindName(rEdit.Kind) + ") - " + text + ", then Update");
		if (rEdit.Kind == StepKind.Point || rEdit.Kind == StepKind.Use)
		{
			ImGui.Dummy(new System.Numerics.Vector2(150f, 0f));
			ImGui.SameLine();
			if (rEdit.Kind == StepKind.Use)
			{
				ImGui.SetNextItemWidth(200f);
				ImGui.InputText("##reditname", ref _rEditName, 120u);
				Tip("The portal or NPC's name.");
				ImGui.SameLine();
			}
			ImGui.SetNextItemWidth(110f);
			ImGui.InputDouble("N/S##reditns", ref _rEditNS, 0.0, 0.0, "%.3f");
			Tip("North is +, south is - (29.048S = -29.048).");
			ImGui.SameLine();
			ImGui.SetNextItemWidth(110f);
			ImGui.InputDouble("E/W##reditew", ref _rEditEW, 0.0, 0.0, "%.3f");
			Tip("East is +, west is -.");
			ImGui.SameLine();
			if (rEdit.Kind == StepKind.Point && ImGui.Button("My position##reditpos") && MyPos(out var ns, out var ew, out var z))
			{
				_rEditNS = ns;
				_rEditEW = ew;
				_rEditZ = z;
			}
			if (rEdit.Kind == StepKind.Use && ImGui.Button("Selected##reditsel"))
			{
				RouteStep routeStep = UseStepFromSelection();
				if (routeStep != null)
				{
					_rEditName = routeStep.Text;
					_rEditNS = routeStep.NS;
					_rEditEW = routeStep.EW;
					_rEditZ = routeStep.Z;
				}
			}
			Tip((rEdit.Kind == StepKind.Point) ? "Where you're standing now." : "The portal or NPC you have selected now.");
		}
		return result;
	}

	private void StartEdit(NavRoute r, RouteStep st)
	{
		switch (st.Kind)
		{
		case StepKind.Point:
		case StepKind.Use:
			_rEditNS = st.NS;
			_rEditEW = st.EW;
			_rEditZ = st.Z;
			_rEditName = st.Text ?? "";
			break;
		case StepKind.Command:
			_rCmd = st.Text ?? "";
			_rCmdWait = st.WaitMs;
			break;
		case StepKind.Wait:
			_rWaitSecs = Math.Max(0, (st.WaitMs + 500) / 1000);
			break;
		case StepKind.PlayerSkip:
			_rSkipM = (int)SkipRange(st);
			_rSkipN = Math.Max(1, st.Count);
			_rSkipNoMobs = SkipNoMobs(st);
			break;
		case StepKind.Toggle:
			_rToggle = Math.Max(0, Array.IndexOf(ToggleTexts, (st.Text ?? "").ToLowerInvariant()));
			break;
		case StepKind.ChatWait:
			_rChat = st.Text ?? "";
			_rChatOp = Math.Max(0, Array.IndexOf(ChatOps, st.Op));
			break;
		case StepKind.ItemCheck:
			_rItem = st.Text ?? "";
			_rItemOp = Math.Max(0, Array.IndexOf(ItemOps, st.Op));
			_rItemNum = st.Count;
			break;
		case StepKind.Vendor:
			_rVendorNpc = st.Text ?? "";
			_rVendorProfile = st.Profile ?? "";
			break;
		case StepKind.UseItem:
			_rGem = st.Text ?? "";
			_rGemWait = Math.Max(1, (st.WaitMs + 500) / 1000);
			break;
		case StepKind.Cast:
		{
			if (_recalls == null)
			{
				_recalls = KnownRecalls();
			}
			int.TryParse(st.Text, out var sp);
			_rRecallPick = Math.Max(0, _recalls.FindIndex((KeyValuePair<int, string> kv) => kv.Key == sp));
			break;
		}
		case StepKind.GoRoute:
		{
			List<string> list2 = OtherRoutes(r);
			int num = list2.FindIndex((string n) => string.Equals(n, st.Text, StringComparison.OrdinalIgnoreCase));
			if (num < 0)
			{
				Util.WriteToChat("Nav: the route \"" + st.Text + "\" isn't there any more - pick another in the Go to route row.");
				num = 0;
			}
			_rGoPick = num;
			_rGoWhere = ((st.Op == "nearest") ? 1 : 0);
			break;
		}
		case StepKind.Preset:
		{
			List<string> list = NavPresets.Names();
			_rPresetPick = Math.Max(0, list.FindIndex((string n) => string.Equals(n, st.Text, StringComparison.OrdinalIgnoreCase)));
			break;
		}
		case StepKind.LoopEnd:
			Util.WriteToChat("Nav: a loop end's conditions are edited under the list when it's selected.");
			return;
		default:
			Util.WriteToChat("Nav: there's nothing to change on a " + KindName(st.Kind) + " step.");
			return;
		}
		_rEdit = st;
	}

	private void ApplyEdit(NavRoute r, RouteStep st)
	{
		switch (st.Kind)
		{
		case StepKind.Point:
			st.NS = _rEditNS;
			st.EW = _rEditEW;
			st.Z = _rEditZ;
			break;
		case StepKind.Use:
			st.NS = _rEditNS;
			st.EW = _rEditEW;
			st.Z = _rEditZ;
			if (_rEditName.Trim().Length > 0)
			{
				st.Text = _rEditName.Trim();
			}
			break;
		case StepKind.Command:
			if (_rCmd.Trim().Length > 0)
			{
				st.Text = _rCmd.Trim();
			}
			st.WaitMs = _rCmdWait;
			_rCmd = "";
			break;
		case StepKind.Wait:
			st.WaitMs = _rWaitSecs * 1000;
			break;
		case StepKind.PlayerSkip:
			st.Text = _rSkipM.ToString(CultureInfo.InvariantCulture);
			st.Count = _rSkipN;
			st.Op = (_rSkipNoMobs ? "nomobs" : "");
			break;
		case StepKind.Toggle:
			st.Text = ToggleTexts[_rToggle];
			break;
		case StepKind.ChatWait:
			if (_rChat.Trim().Length > 0)
			{
				st.Text = _rChat.Trim();
			}
			st.Op = ChatOps[_rChatOp];
			_rChat = "";
			break;
		case StepKind.ItemCheck:
			if (_rItem.Trim().Length > 0)
			{
				st.Text = _rItem.Trim();
			}
			st.Op = ItemOps[_rItemOp];
			st.Count = _rItemNum;
			break;
		case StepKind.Vendor:
			if (_rVendorNpc.Trim().Length > 0)
			{
				st.Text = _rVendorNpc.Trim();
			}
			st.Profile = _rVendorProfile.Trim();
			break;
		case StepKind.UseItem:
			if (_rGem.Trim().Length > 0)
			{
				st.Text = _rGem.Trim();
			}
			st.WaitMs = _rGemWait * 1000;
			break;
		case StepKind.Cast:
			if (_recalls != null && _rRecallPick >= 0 && _rRecallPick < _recalls.Count)
			{
				st.Text = _recalls[_rRecallPick].Key.ToString();
			}
			break;
		case StepKind.Preset:
		{
			List<string> list2 = NavPresets.Names();
			if (_rPresetPick >= 0 && _rPresetPick < list2.Count)
			{
				st.Text = list2[_rPresetPick];
			}
			break;
		}
		case StepKind.GoRoute:
		{
			List<string> list = OtherRoutes(r);
			if (_rGoPick >= 0 && _rGoPick < list.Count)
			{
				st.Text = list[_rGoPick];
			}
			st.Op = ((_rGoWhere == 1) ? "nearest" : "start");
			break;
		}
		case StepKind.LoopStart:
		case StepKind.LoopEnd:
			break;
		}
	}

	private bool DrawAddRows(NavRoute r, bool preset = false)
	{
		bool flag = false;
		flag |= DrawEditRow(r);
		if (!preset)
		{
			flag |= DrawPresetRow(r);
		}
		if (!preset)
		{
			if (AddButton("Add point here"))
			{
				RouteStep routeStep = NewPointHere(StepKind.Point);
				Insert(r, routeStep);
				if (_recording && routeStep != null)
				{
					_recNS = routeStep.NS;
					_recEW = routeStep.EW;
				}
				flag = true;
			}
			Tip("Where you're standing. New steps go after the selected step (click a row), or at the end.");
			ImGui.SameLine();
			if (!_recording)
			{
				if (ImGui.Button("Record##rrec", new System.Numerics.Vector2(80f, 0f)))
				{
					StartRecording(r);
					flag = true;
				}
				Tip("Walk the way yourself: a point is added every so many metres as you move\n(after the selected step, or at the end). Click Stop when you're there.");
			}
			else
			{
				ImGui.PushStyleColor(ImGuiCol.Button, new System.Numerics.Vector4(0.7f, 0.15f, 0.15f, 1f));
				if (ImGui.Button("Stop##rrec", new System.Numerics.Vector2(80f, 0f)))
				{
					StopRecording();
					flag = true;
				}
				ImGui.PopStyleColor();
			}
			ImGui.SameLine();
			ImGui.SetNextItemWidth(90f);
			ImGui.InputFloat("m apart##rrecm", ref _recEvery, 1f, 5f, "%.0f");
			if (_recEvery < 2f)
			{
				_recEvery = 2f;
			}
			if (_recEvery > 100f)
			{
				_recEvery = 100f;
			}
			if (_recording)
			{
				ImGui.SameLine();
				Im.TextColored(Yellow, "recording...");
			}
			if (AddButton("Add portal / NPC"))
			{
				RouteStep routeStep2 = UseStepFromSelection();
				if (routeStep2 != null)
				{
					Insert(r, routeStep2);
					flag = true;
				}
			}
			Tip("Select it in the world first. When the route gets here it's used (the game walks you to it);\nfor a portal the route carries on on the other side.");
			ImGui.SameLine();
			Im.TextColored(Grey, "the portal or NPC you have selected");
			if (AddButton("Add loop start"))
			{
				Insert(r, new RouteStep
				{
					Kind = StepKind.LoopStart
				});
				flag = true;
			}
			Tip("Steps above this are done once; the steps below it repeat (back and forth or round and round).");
			ImGui.SameLine();
			if (ImGui.Button("Add loop end", new System.Numerics.Vector2(150f, 0f)))
			{
				Insert(r, new RouteStep
				{
					Kind = StepKind.LoopEnd
				});
				flag = true;
			}
			Tip("Closes the loop. Select it to give it conditions - e.g. Invoking Stone >= 30 - and the route goes round\nuntil they're all true, then carries on with the steps after it (walk back, turn in, go to the next route).\nSteps after a loop end run once; the route then finishes unless it ends with a Go to route step.");
		}
		List<string> list = OtherRoutes(r);
		if (list.Count > 0)
		{
			if (_rGoPick >= list.Count)
			{
				_rGoPick = 0;
			}
			if (AddButton("Add go to route"))
			{
				Insert(r, new RouteStep
				{
					Kind = StepKind.GoRoute,
					Text = list[_rGoPick],
					Op = ((_rGoWhere == 1) ? "nearest" : "start")
				});
				flag = true;
			}
			Tip("Switches to that route when it gets here - e.g. the last step of Temple North: go to Temple SE.");
			ImGui.SameLine();
			ImGui.SetNextItemWidth(200f);
			ImGui.Combo("##rgoroute", ref _rGoPick, list.ToArray(), list.Count);
			ImGui.SameLine();
			ImGui.SetNextItemWidth(150f);
			ImGui.Combo("##rgowhere", ref _rGoWhere, GoWhere, GoWhere.Length);
		}
		if (AddButton("Add command") && _rCmd.Trim().Length > 0)
		{
			Insert(r, new RouteStep
			{
				Kind = StepKind.Command,
				Text = _rCmd.Trim(),
				WaitMs = _rCmdWait
			});
			_rCmd = "";
			flag = true;
		}
		Tip("Any chat command, e.g. /ub jumpsw 0 100 (shift-jump forward), sent as if you typed it - then the route waits this long.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(260f);
		ImGui.InputText("##rcmd", ref _rCmd, 200u);
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		ImGui.InputInt("ms##rcmdwait", ref _rCmdWait, 100, 500);
		if (_rCmdWait < 0)
		{
			_rCmdWait = 0;
		}
		if (AddButton("Add wait"))
		{
			Insert(r, new RouteStep
			{
				Kind = StepKind.Wait,
				WaitMs = _rWaitSecs * 1000
			});
			flag = true;
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		ImGui.InputInt("seconds##rwait", ref _rWaitSecs, 1, 5);
		if (_rWaitSecs < 0)
		{
			_rWaitSecs = 0;
		}
		if (AddButton("Add player skip"))
		{
			Insert(r, new RouteStep
			{
				Kind = StepKind.PlayerSkip,
				Text = _rSkipM.ToString(CultureInfo.InvariantCulture),
				Count = _rSkipN,
				Op = (_rSkipNoMobs ? "nomobs" : "")
			});
			flag = true;
		}
		Tip("When another player is within this many metres as the route gets here, the next steps are skipped -\ne.g. before a Combat ON / Wait / Combat OFF at a mob group: someone's there, so it goes straight on.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		ImGui.InputInt("m within, skip##rskipm", ref _rSkipM, 5, 10);
		if (_rSkipM < 1)
		{
			_rSkipM = 1;
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		ImGui.InputInt("steps##rskipn", ref _rSkipN, 1, 1);
		if (_rSkipN < 1)
		{
			_rSkipN = 1;
		}
		ImGui.SameLine();
		ImGui.Checkbox("or no monsters in combat range##rskipnomobs", ref _rSkipNoMobs);
		Tip("Also skip those steps when there isn't a monster within combat range as the route gets here\n(nothing to fight at that group - go straight on).");
		if (AddButton("Add switch"))
		{
			Insert(r, new RouteStep
			{
				Kind = StepKind.Toggle,
				Text = ToggleTexts[_rToggle]
			});
			flag = true;
		}
		Tip("Turns combat, looting or pet summoning on or off when the route gets here - e.g. combat and summoning off\nwhile travelling, all on at the hunting spot (put it just before the loop start).\nDoors: opening (and picking) doors in the way on or off - e.g. on for a dungeon, off outside.\nReset session: the session's numbers (kills, loot, XP / lum per hour) start over here - put it just before\nthe loop start, so the trip there isn't counted (inside the loop it would reset every lap).");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(150f);
		ImGui.Combo("##rtoggle", ref _rToggle, ToggleNames, ToggleNames.Length);
		if (AddButton("Add chat wait") && _rChat.Trim().Length > 0)
		{
			Insert(r, new RouteStep
			{
				Kind = StepKind.ChatWait,
				Text = _rChat.Trim(),
				Op = ChatOps[_rChatOp]
			});
			_rChat = "";
			flag = true;
		}
		Tip("The route stops here until a chat line matches (not case sensitive):\n  contains - the text is anywhere in the line\n  = - the whole line is exactly the text\nLines that came in during the step before count too, so a command's reply isn't missed.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(260f);
		ImGui.InputText("##rchat", ref _rChat, 200u);
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		ImGui.Combo("##rchatop", ref _rChatOp, ChatOps, ChatOps.Length);
		if (AddButton("Add item check") && _rItem.Trim().Length > 0)
		{
			Insert(r, new RouteStep
			{
				Kind = StepKind.ItemCheck,
				Text = _rItem.Trim(),
				Op = ItemOps[_rItemOp],
				Count = _rItemNum
			});
			flag = true;
		}
		Tip("The route stops here until the count of that item in your packs makes this true - e.g. Invoking Stone >= 30.\nStacks are counted. Exact name first; if you have none by that exact name, any item whose name contains it.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(220f);
		ImGui.InputText("##ritem", ref _rItem, 120u);
		ImGui.SameLine();
		if (ImGui.SmallButton("sel##ritemsel"))
		{
			try
			{
				WorldObject worldObject = Globals.Core.WorldFilter[Globals.Core.Actions.CurrentSelection];
				if (worldObject != null)
				{
					_rItem = worldObject.Name;
				}
			}
			catch
			{
			}
		}
		Tip("Use the name of the item you have selected.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(60f);
		ImGui.Combo("##ritemop", ref _rItemOp, ItemOps, ItemOps.Length);
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		ImGui.InputInt("##ritemnum", ref _rItemNum, 1, 10);
		if (_rItemNum < 0)
		{
			_rItemNum = 0;
		}
		List<string> list2 = PackGems();
		if (_rGem.Length > 0 && !list2.Contains(_rGem))
		{
			list2.Insert(0, _rGem);
		}
		if (AddButton("Add use item") && _rGem.Trim().Length > 0)
		{
			Insert(r, new RouteStep
			{
				Kind = StepKind.UseItem,
				Text = _rGem.Trim(),
				WaitMs = _rGemWait * 1000
			});
			flag = true;
		}
		Tip("Uses an item from your packs when the route gets here - a portal gem, a buff gem ... - like double-clicking it.\nThe route goes on as soon as you portal, or after the seconds set here. The list shows the gems you carry;\n\"sel\" takes the item you have selected instead.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(220f);
		if (ImGui.BeginCombo("##rgem", (_rGem.Length > 0) ? _rGem : "(pick a gem)"))
		{
			if (list2.Count == 0)
			{
				Im.TextColored(Grey, "No gems in your packs - select an item and click sel");
			}
			foreach (string item in list2)
			{
				if (ImGui.Selectable(item, item == _rGem))
				{
					_rGem = item;
				}
			}
			ImGui.EndCombo();
		}
		ImGui.SameLine();
		if (ImGui.SmallButton("sel##rgemsel"))
		{
			try
			{
				WorldObject worldObject2 = Globals.Core.WorldFilter[Globals.Core.Actions.CurrentSelection];
				if (worldObject2 != null)
				{
					_rGem = worldObject2.Name;
				}
			}
			catch
			{
			}
		}
		Tip("Use the item you have selected.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		ImGui.InputInt("s max##rgemwait", ref _rGemWait, 1, 5);
		if (_rGemWait < 1)
		{
			_rGemWait = 1;
		}
		if (AddButton("Add vendor") && _rVendorNpc.Trim().Length > 0)
		{
			Insert(r, new RouteStep
			{
				Kind = StepKind.Vendor,
				Text = _rVendorNpc.Trim(),
				Profile = _rVendorProfile.Trim()
			});
			flag = true;
		}
		Tip("A whole vendor visit (Items > Vendor): opens the NPC's shop, sells what the profile's Sell rules catch, makes the money up\n(trade notes off Infinite Leaftide), buys up to each Keep-up-to count, banks the change, and says how it went.\nThe route goes on once the visit is done. The NPC is found by its exact name, nearest first; \"sel\" takes your selection.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(220f);
		ImGui.InputText("##rvendnpc", ref _rVendorNpc, 120u);
		Tip("The vendor's exact name.");
		ImGui.SameLine();
		if (ImGui.SmallButton("sel##rvendsel"))
		{
			try
			{
				WorldObject worldObject3 = Globals.Core.WorldFilter[Globals.Core.Actions.CurrentSelection];
				if (worldObject3 != null)
				{
					_rVendorNpc = worldObject3.Name;
				}
			}
			catch
			{
			}
		}
		Tip("Use the NPC you have selected.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(180f);
		if (ImGui.BeginCombo("##rvendprof", (_rVendorProfile.Length > 0) ? _rVendorProfile : "(named after the vendor)"))
		{
			if (ImGui.Selectable("(named after the vendor)", _rVendorProfile.Length == 0))
			{
				_rVendorProfile = "";
			}
			foreach (string item3 in (VendorRun.I != null) ? VendorRun.I.ProfileNames() : new List<string>())
			{
				if (ImGui.Selectable(item3, item3 == _rVendorProfile))
				{
					_rVendorProfile = item3;
				}
			}
			ImGui.EndCombo();
		}
		Tip("The vendor profile to use (Items > Vendor makes them). Left as \"named after the vendor\", the one called after\nthe NPC is used - this character's first, then this server's, then everyone's.");
		if (_recalls == null)
		{
			_recalls = KnownRecalls();
		}
		if (AddButton("Add recall") && _recalls.Count > 0 && _rRecallPick >= 0 && _rRecallPick < _recalls.Count)
		{
			Insert(r, new RouteStep
			{
				Kind = StepKind.Cast,
				Text = _recalls[_rRecallPick].Key.ToString()
			});
			flag = true;
		}
		Tip("Casts a recall / portal spell when the route gets here (switching to magic mode first), and carries on\non the other side - or after 20 s if it didn't take you anywhere. The list is the ones this character knows.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(260f);
		string text = ((_recalls.Count == 0) ? "(none known)" : _recalls[Math.Min(_rRecallPick, _recalls.Count - 1)].Value);
		if (ImGui.BeginCombo("##rrecall", text, ImGuiComboFlags.HeightLarge))
		{
			for (int i = 0; i < _recalls.Count; i++)
			{
				if (ImGui.Selectable(_recalls[i].Value + "##rc" + i, i == _rRecallPick))
				{
					_rRecallPick = i;
				}
			}
			ImGui.EndCombo();
		}
		ImGui.SameLine();
		if (ImGui.SmallButton("refresh##rrecallre"))
		{
			_recalls = KnownRecalls();
		}
		Tip("Read the known spells again (after learning a new recall).");
		return flag;
	}

	private bool DrawRoute()
	{
		bool flag = false;
		NavRoute navRoute = CurrentRoute;
		List<string> list = new List<string>();
		foreach (NavRoute navRoute3 in _s.NavRoutes)
		{
			list.Add(navRoute3.Name);
		}
		int num = list.FindIndex((string n) => string.Equals(n, _s.NavRouteSelected, StringComparison.OrdinalIgnoreCase));
		string[] array = ((list.Count != 0) ? list.ToArray() : new string[1] { "(no routes yet)" });
		int current_item = ((num >= 0) ? num : 0);
		bool flag2 = IsMetaRoute(navRoute);
		ImGui.SetNextItemWidth(220f);
		if (flag2)
		{
			if (ImGui.BeginCombo("Route##navroute", navRoute.Name))
			{
				for (int num2 = 0; num2 < list.Count; num2++)
				{
					if (ImGui.Selectable(list[num2] + "##rn" + num2))
					{
						_s.NavRouteSelected = list[num2];
						Stop();
						RouteReset();
						_rSel = -1;
						flag = true;
					}
				}
				ImGui.EndCombo();
			}
			navRoute = CurrentRoute;
			flag2 = IsMetaRoute(navRoute);
		}
		else if (ImGui.Combo("Route##navroute", ref current_item, array, array.Length) && list.Count > 0)
		{
			_s.NavRouteSelected = list[current_item];
			Stop();
			RouteReset();
			_rSel = -1;
			flag = true;
			navRoute = CurrentRoute;
		}
		if (flag2)
		{
			ImGui.SameLine();
			Im.TextColored(Yellow, "loaded by meta " + ((_meta != null) ? _meta.Name : "?"));
			ImGui.SameLine();
			if (ImGui.SmallButton("Update the meta's route##rmetaupd"))
			{
				UpdateMetaRoute();
			}
			Tip("Puts this route, with your changes, back into the meta (saved straight away for a .mtmet).\nChanges here aren't kept anywhere else.");
			ImGui.SameLine();
			if (ImGui.SmallButton("Copy to my routes##rmetacopy"))
			{
				NavRoute c = EmbeddedMtRoute(Meta.Enc.GetBytes("x\r\n0\r\n" + RouteXml(navRoute)));
				if (c != null)
				{
					string text = (navRoute.Name.StartsWith("[meta] ", StringComparison.Ordinal) ? navRoute.Name.Substring(7) : navRoute.Name);
					c.Name = text;
					c.File = "";
					int num3 = 2;
					while (_s.NavRoutes.Exists((NavRoute x) => string.Equals(x.Name, c.Name, StringComparison.OrdinalIgnoreCase)))
					{
						c.Name = text + " (" + num3++ + ")";
					}
					_s.NavRoutes.Add(c);
					flag = true;
					Util.WriteToChat("Nav: " + c.Name + " added to your routes.");
				}
			}
		}
		ImGui.SameLine();
		if (navRoute != null && !flag2 && ImGui.Button("Delete##rdel"))
		{
			_s.NavRoutes.Remove(navRoute);
			_s.NavRouteSelected = ((_s.NavRoutes.Count > 0) ? _s.NavRoutes[0].Name : "");
			Stop();
			RouteReset();
			flag = true;
			navRoute = CurrentRoute;
		}
		ImGui.SetNextItemWidth(220f);
		ImGui.InputText("Name##rname", ref _rNewName, 64u);
		ImGui.SameLine();
		if (ImGui.Button("New route") && _rNewName.Trim().Length > 0)
		{
			NavRoute navRoute2 = new NavRoute
			{
				Name = _rNewName.Trim()
			};
			_s.NavRoutes.Add(navRoute2);
			_s.NavRouteSelected = navRoute2.Name;
			_rNewName = "";
			_rSel = -1;
			RouteReset();
			flag = true;
			navRoute = navRoute2;
		}
		if (navRoute != null)
		{
			ImGui.SameLine();
			if (ImGui.Button("Rename##rren") && _rNewName.Trim().Length > 0)
			{
				navRoute.Name = _rNewName.Trim();
				_s.NavRouteSelected = navRoute.Name;
				_rNewName = "";
				flag = true;
			}
		}
		if (navRoute == null)
		{
			Im.TextColored(Grey, "Type a name and click New route - or load a file on the Settings tab.");
			return flag;
		}
		ImGui.Separator();
		ImGui.SetNextItemWidth(220f);
		if (ImGui.Combo("Repeat##rmode", ref navRoute.Mode, RouteModes, RouteModes.Length))
		{
			flag = true;
		}
		Tip("Once: walk it once, then stop - nav does nothing more until another route is loaded or it is started again.\nBack and forth: to the end, then back to the start of the repeating part, and so on.\nRound and round: from the end straight back to the start of the repeating part.\n\nSteps above a 'Loop starts here' step are done only once - e.g. run from town and take a portal,\nthen circle the hunting area. With no loop step, the whole route repeats.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(100f);
		flag |= ImGui.InputFloat("point size (m)##rarr", ref navRoute.Arrive, 0.5f, 1f, "%.1f");
		if (navRoute.Arrive < 0.5f)
		{
			navRoute.Arrive = 0.5f;
		}
		Tip("How close counts as reaching a point (the ring drawn on the point is this size). This route only.\nSmall (0.5 - 1 m) for tight spots: doorways, ledges, standing on an exact spot. Bigger (3 - 5 m) for open hunting\nroutes - less stopping and turning.\nA meta's route: click 'Update the meta's route' to keep the change.");
		ImGui.SetNextItemWidth(220f);
		if (ImGui.Combo("When stuck##rstuck", ref navRoute.StuckAction, StuckActions, StuckActions.Length))
		{
			flag = true;
		}
		Tip("What to do when the way to a point is blocked (monsters in the way, a wall) - normally it waits 30 s and tries again:\n  Turn combat on - fight what's in the way; combat goes off again once the point is reached\n    (unless a Switch step turns it on or off first)\n  Back up and try again - walk back over the last few points, then come forward again\n  Start the route over - from step 1\n  Skip that point - on to the next step");
		if (navRoute.StuckAction == 2)
		{
			ImGui.SameLine();
			ImGui.SetNextItemWidth(90f);
			if (ImGui.InputInt("points##rstuckback", ref navRoute.StuckBack, 1, 1))
			{
				flag = true;
			}
			if (navRoute.StuckBack < 1)
			{
				navRoute.StuckBack = 1;
			}
			if (navRoute.StuckBack > 20)
			{
				navRoute.StuckBack = 20;
			}
		}
		if (navRoute.StuckAction != 0)
		{
			ImGui.SameLine();
			ImGui.SetNextItemWidth(90f);
			if (ImGui.InputInt("after tries##rstuckafter", ref navRoute.StuckAfter, 1, 1))
			{
				flag = true;
			}
			if (navRoute.StuckAfter < 1)
			{
				navRoute.StuckAfter = 1;
			}
			if (navRoute.StuckAfter > 10)
			{
				navRoute.StuckAfter = 10;
			}
			Tip("How many times in a row it can't get to the same point before doing this (each try is about 5 s of no progress + 30 s wait).");
		}
		if (ImGui.Checkbox("Start over from step 1 when stuck on a step for##rstuckmin", ref navRoute.RestartIfStuck))
		{
			flag = true;
		}
		Tip("When the route hasn't got past the step it's on for this many minutes (whatever held it - a wall, a monster it\ncan't reach, a door), it starts again from step 1. Time in portal space or dead doesn't count.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(100f);
		flag |= ImGui.InputFloat("min##rstuckm", ref navRoute.RestartStuckMin, 1f, 5f, "%.0f");
		if (navRoute.RestartStuckMin < 1f)
		{
			navRoute.RestartStuckMin = 1f;
		}
		if (_rStuckAcc > 30.0 && navRoute.RestartIfStuck)
		{
			ImGui.SameLine();
			Im.TextColored(Grey, "(on this step " + (int)(_rStuckAcc / 60.0) + "m" + ((int)_rStuckAcc % 60).ToString("00") + "s)");
		}
		float cursorPosX = ImGui.GetCursorPosX();
		if (ImGui.Checkbox("Start over from step 1 when further than##rfar", ref navRoute.RestartIfFar))
		{
			flag = true;
		}
		Tip("When the next point is further away than this (you portalled, recalled or died somewhere else),\nthe route starts again from step 1 - so put the gem / recall that gets you there first.\nAt most once a minute; if step 1's point is far too, it waits as usual.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(100f);
		flag |= ImGui.InputFloat("m##rfarm", ref navRoute.RestartFarM, 10f, 50f, "%.0f");
		if (navRoute.RestartFarM < 10f)
		{
			navRoute.RestartFarM = 10f;
		}
		ImGui.SameLine(cursorPosX + 606f + ImGui.GetStyle().ItemSpacing.X);
		if (AddButton("Pop-out tools##rtools"))
		{
			ToggleTools();
		}
		Tip("A small window with Add point here, Record, Add portal / NPC, Add wait and Add preset - to build the route while you\nwalk it (the main window can be closed). Steps go after the selected step, or at the end.");
		if (_rEdit != null && !navRoute.Steps.Contains(_rEdit))
		{
			_rEdit = null;
		}
		ImGui.Separator();
		int num4 = -1;
		int num5 = -1;
		int num6 = -1;
		if (ImGui.BeginTable("routesteps", 5, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY, new System.Numerics.Vector2(606f, Math.Max(300f, _rAddH))))
		{
			ImGui.TableSetupColumn("#", ImGuiTableColumnFlags.WidthFixed, 30f);
			ImGui.TableSetupColumn("Step", ImGuiTableColumnFlags.WidthFixed, 80f);
			ImGui.TableSetupColumn("Detail", ImGuiTableColumnFlags.WidthFixed, 330f);
			ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 60f);
			ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 26f);
			ImGui.TableSetupScrollFreeze(0, 1);
			ImGui.TableHeadersRow();
			bool flag3 = navRoute.Steps.Count != _rLastCount && _rLastCount >= 0;
			_rLastCount = navRoute.Steps.Count;
			int num7;
			if (flag3)
			{
				num7 = ((_rSel >= 0 && _rSel < navRoute.Steps.Count) ? Math.Min(_rSel + 1, navRoute.Steps.Count - 1) : (navRoute.Steps.Count - 1));
			}
			else
			{
				num7 = -1;
			}
			float frameHeight = ImGui.GetFrameHeight();
			for (int num8 = 0; num8 < navRoute.Steps.Count; num8++)
			{
				RouteStep routeStep = navRoute.Steps[num8];
				ImGui.TableNextRow(ImGuiTableRowFlags.None, frameHeight);
				ImGui.TableSetColumnIndex(0);
				if (num8 != num7 && !ImGui.IsRectVisible(new System.Numerics.Vector2(1f, frameHeight)) && (routeStep.Kind != StepKind.Preset || _presetClosed.Contains(routeStep)))
				{
					continue;
				}
				if (num8 == num7)
				{
					ImGui.SetScrollHereY(0.5f);
				}
				ImGui.PushID(num8);
				bool flag4 = _s.NavEnabled && num8 == _rIdx && !_rDone;
				ImGui.TableSetColumnIndex(0);
				Im.TextColored(flag4 ? Green : Grey, (flag4 ? ">" : "") + (num8 + 1));
				ImGui.TableSetColumnIndex(1);
				string text2;
				if (routeStep.Kind != StepKind.Point)
				{
					if (routeStep.Kind == StepKind.Command)
					{
						text2 = "Command";
					}
					else if (routeStep.Kind == StepKind.Use)
					{
						text2 = "Use";
					}
					else if (routeStep.Kind == StepKind.Wait)
					{
						text2 = "Wait";
					}
					else if (routeStep.Kind == StepKind.Toggle)
					{
						text2 = "Switch";
					}
					else if (routeStep.Kind == StepKind.Cast)
					{
						text2 = "Cast";
					}
					else if (routeStep.Kind == StepKind.ChatWait)
					{
						text2 = "Chat wait";
					}
					else if (routeStep.Kind == StepKind.ItemCheck)
					{
						text2 = "Item check";
					}
					else if (routeStep.Kind == StepKind.LoopEnd)
					{
						text2 = "Loop end";
					}
					else if (routeStep.Kind == StepKind.GoRoute)
					{
						text2 = "Go to route";
					}
					else if (routeStep.Kind == StepKind.UseItem)
					{
						text2 = "Use item";
					}
					else if (routeStep.Kind == StepKind.Preset)
					{
						text2 = "Preset";
					}
					else if (routeStep.Kind == StepKind.Vendor)
					{
						text2 = "Vendor";
					}
					else
					{
						text2 = ((routeStep.Kind == StepKind.PlayerSkip) ? "Player skip" : "Loop");
					}
				}
				else
				{
					text2 = "Point";
				}
				if (ImGui.Selectable(text2 + "##rs", _rSel == num8, ImGuiSelectableFlags.SpanAllColumns | ImGuiSelectableFlags.AllowOverlap))
				{
					_rSel = ((_rSel == num8) ? (-1) : num8);
				}
				if (ImGui.IsItemClicked(ImGuiMouseButton.Right))
				{
					_rIdx = num8;
					_rSubFor = -1;
					_rDone = false;
					_rStarted = false;
					_rUntil = DateTime.MinValue;
					Stop();
				}
				Tip("Left click: select (new steps go after it). Right click: go to this step now.");
				ImGui.TableSetColumnIndex(2);
				if (routeStep.Kind == StepKind.Preset)
				{
					bool flag5 = !_presetClosed.Contains(routeStep);
					if (ImGui.SmallButton((flag5 ? "-" : "+") + "##rpo"))
					{
						if (flag5)
						{
							_presetClosed.Add(routeStep);
						}
						else
						{
							_presetClosed.Remove(routeStep);
						}
					}
					Tip(flag5 ? "Hide the preset's steps" : "Show the preset's steps");
					ImGui.SameLine();
				}
				System.Numerics.Vector4 col;
				if (routeStep == _rEdit)
				{
					col = Yellow;
				}
				else if (routeStep.Kind == StepKind.LoopStart || routeStep.Kind == StepKind.LoopEnd)
				{
					col = Cyan;
				}
				else if (routeStep.Kind == StepKind.Preset)
				{
					col = Purple;
				}
				else
				{
					col = (flag4 ? Green : System.Numerics.Vector4.One);
				}
				Im.TextColored(col, ((routeStep == _rEdit) ? "(editing) " : "") + Describe(routeStep));
				ImGui.TableSetColumnIndex(3);
				if (num8 > 0)
				{
					if (Im.UpButton("##rup"))
					{
						num4 = num8;
					}
					ImGui.SameLine();
				}
				if (num8 < navRoute.Steps.Count - 1 && Im.DownButton("##rdn"))
				{
					num5 = num8;
				}
				ImGui.TableSetColumnIndex(4);
				if (ImGui.SmallButton("x"))
				{
					num6 = num8;
				}
				ImGui.PopID();
				if (routeStep.Kind == StepKind.Preset && !_presetClosed.Contains(routeStep))
				{
					DrawPresetSubRows(routeStep, num8, flag4);
				}
			}
			ImGui.EndTable();
		}
		ImGui.SameLine();
		ImGui.BeginGroup();
		flag |= DrawAddRows(navRoute);
		ImGui.EndGroup();
		_rAddH = ImGui.GetItemRectSize().Y;
		if (num4 > 0 || num5 >= 0)
		{
			RouteStep routeStep2 = ((_rSel >= 0 && _rSel < navRoute.Steps.Count) ? navRoute.Steps[_rSel] : null);
			Im.Move(navRoute.Steps, (num4 > 0) ? num4 : num5, num4 > 0);
			if (routeStep2 != null)
			{
				_rSel = navRoute.Steps.IndexOf(routeStep2);
			}
			flag = true;
		}
		if (num6 >= 0)
		{
			if (navRoute.Steps[num6] == _rEdit)
			{
				_rEdit = null;
			}
			navRoute.Steps.RemoveAt(num6);
			if (_rSel >= navRoute.Steps.Count)
			{
				_rSel = navRoute.Steps.Count - 1;
			}
			if (_rIdx >= navRoute.Steps.Count)
			{
				_rIdx = 0;
			}
			flag = true;
		}
		if (_rSel >= 0 && _rSel < navRoute.Steps.Count && navRoute.Steps[_rSel].Kind == StepKind.LoopEnd)
		{
			flag |= DrawLoopEnd(navRoute, navRoute.Steps[_rSel]);
		}
		ImGui.Separator();
		bool v = _s.NavEnabled;
		if (ImGui.Checkbox("Follow this route", ref v))
		{
			_s.NavEnabled = v;
			if (!v)
			{
				Stop();
			}
			flag = true;
		}
		Tip("Walks the route whenever there's nothing to fight or loot (fights and looting pause it; it carries on from the same step).");
		ImGui.SameLine();
		if (ImGui.Button("Start from step 1"))
		{
			Stop();
			RouteReset();
		}
		ImGui.SameLine();
		if (ImGui.Button("Start at the nearest point"))
		{
			int num9 = NearestPoint(navRoute, this, out var dist);
			if (num9 < 0)
			{
				Util.WriteToChat("Nav: this route has no points.");
			}
			else
			{
				Stop();
				RouteReset();
				_rIdx = num9;
				_rName = navRoute.Name;
				Util.WriteToChat("Nav: starting " + navRoute.Name + " at step " + (num9 + 1) + " (" + dist.ToString("0") + " m away).");
			}
		}
		Tip("Goes to the route's point closest to you and carries on from there.");
		ImGui.SameLine();
		if (_s.NavEnabled)
		{
			Im.TextColored(_rDone ? Grey : Yellow, _rDone ? "Finished" : ("Step " + (_rIdx + 1) + ((Status.Length > 0) ? (" - " + Status) : "")));
		}
		return flag;
	}

#if RETAIL
	private unsafe static bool Motion(uint motion, bool on)
	{
		try
		{
			SmartBox** smartbox = SmartBox.smartbox;
			if (smartbox == null)
			{
				return false;
			}
			SmartBox* ptr = *smartbox;
			if (ptr == null || ptr->cmdinterp == null)
			{
				return false;
			}
			((ACCmdInterp*)ptr->cmdinterp)->SetMotion(motion, on);
			return true;
		}
		catch
		{
			return false;
		}
	}
#else
	private static bool Motion(uint motion, bool on)
	{
		ACGodot.Plugins.PluginHost host = Bridge.Host;
		if (host?.Player == null)
		{
			return false;
		}
		int num = motion switch
		{
			1694498831u => 32, 
			1694498832u => 16, 
			1694498829u => 8, 
			1694498830u => 4, 
			1157627910u => 2, 
			1157627909u => 1, 
			_ => 0, 
		};
		if (num == 0)
		{
			return false;
		}
		host.NavKeys = (on ? (host.NavKeys | num) : (host.NavKeys & ~num));
		return true;
	}
#endif

	private void WantHeading(double want)
	{
		_steerWant = want;
		_steerWantAt = DateTime.Now;
	}

	private void ReleaseTurn()
	{
		if (_turning != 0)
		{
			Motion((_turning * _turnSign > 0) ? 1694498829u : 1694498830u, on: false);
			_turning = 0;
		}
	}

	private static readonly bool HeadingSteer = true;

	public void SteerFrame()
	{
		try
		{
			if (!KeySteer || !_running || !_moving || _steerWant < 0.0 || (DateTime.Now - _steerWantAt).TotalMilliseconds > 600.0)
			{
				ReleaseTurn();
				return;
			}
			double num = CombatEngine.MyHeading();
			if (num < 0.0)
			{
				ReleaseTurn();
				return;
			}
			double num2 = ((_steerWant - num) % 360.0 + 540.0) % 360.0 - 180.0;
			// ACGodot: steered by the heading wanted, which the client turns to at its own pace and stops on exactly -
			// held turn keys, let go only at the next tick, swung past it and back (the run to a point or a corpse
			// went left-right-left)
			if (HeadingSteer)
			{
				ReleaseTurn();
				if (Math.Abs(num2) > 1.0)
				{
					try
					{
						Globals.Core.Actions.FaceHeading(_steerWant, true);
					}
					catch
					{
					}
				}
				return;
			}
			double num3 = Math.Max(1f, _s.NavSteerDeadband);
			int num4 = ((_turning == 0) ? ((!(Math.Abs(num2) <= num3)) ? ((num2 > 0.0) ? 1 : (-1)) : 0) : (((_turning <= 0 || !(num2 < 0.0)) && (_turning >= 0 || !(num2 > 0.0)) && !(Math.Abs(num2) <= 1.0)) ? _turning : 0));
			if (num4 == _turning)
			{
				if (num4 != 0 && (DateTime.Now - _turnStartAt).TotalMilliseconds > 400.0 && Math.Abs(num2) > Math.Abs(_turnStartDiff) + 20.0)
				{
					ReleaseTurn();
					_turnSign = -_turnSign;
					L("steer: turning made it worse (" + _turnStartDiff.ToString("0") + " -> " + num2.ToString("0") + " deg) - left / right swapped");
				}
				return;
			}
			ReleaseTurn();
			if (num4 == 0)
			{
				return;
			}
			if (!Motion((num4 * _turnSign > 0) ? 1694498829u : 1694498830u, on: true))
			{
				_motionBroken = true;
				L("steer: the client turn call isn't available - using turn-to-heading as before");
				return;
			}
			_turning = num4;
			_turnStartDiff = num2;
			_turnStartAt = DateTime.Now;
			if (_steerLogs < 40 && Math.Abs(num2) > 10.0)
			{
				_steerLogs++;
				L("steer: holding " + ((num4 > 0) ? "right" : "left") + " for " + Math.Abs(num2).ToString("0") + " deg");
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			ReleaseTurn();
		}
	}

	public string SyncRouteFile(string rel, string op, string oldName)
	{
		string path = Path.Combine(NavDir, (rel ?? "").Replace('/', '\\').TrimStart('\\'));
		Func<NavRoute, bool> same = (NavRoute x) => (!string.IsNullOrEmpty(x.File) && string.Equals(Path.GetFullPath(x.File), Path.GetFullPath(path), StringComparison.OrdinalIgnoreCase)) || (!string.IsNullOrEmpty(oldName) && string.Equals(x.Name, oldName, StringComparison.OrdinalIgnoreCase));
		if (op == "deleted")
		{
			int num = _s.NavRoutes.RemoveAll((NavRoute x) => same(x));
			return (num > 0) ? ("route " + (oldName ?? rel) + " removed") : ("no route for " + rel);
		}
		NavRoute nr = LoadRouteFile(path);
		if (nr == null)
		{
			return "couldn't read " + rel;
		}
		nr.File = path;
		int num2 = _s.NavRoutes.FindIndex((NavRoute x) => same(x) || string.Equals(x.Name, nr.Name, StringComparison.OrdinalIgnoreCase));
		bool flag = num2 >= 0 && string.Equals(_s.NavRouteSelected, _s.NavRoutes[num2].Name, StringComparison.OrdinalIgnoreCase);
		if (num2 >= 0)
		{
			_s.NavRoutes[num2] = nr;
		}
		else
		{
			_s.NavRoutes.Add(nr);
		}
		if (flag)
		{
			_s.NavRouteSelected = nr.Name;
			if (_rIdx >= nr.Steps.Count)
			{
				RouteReset();
			}
			_rSubFor = -1;
			_rSub = 0;
		}
		_treeAt = DateTime.MinValue;
		return "route " + nr.Name + ((num2 >= 0) ? " updated" : " added") + " (" + nr.Steps.Count + " steps)";
	}

	public string SyncMetaFile(string name)
	{
		if (_meta == null || string.IsNullOrEmpty(_meta.File))
		{
			return "no meta loaded";
		}
		if (!string.Equals(Path.GetFileNameWithoutExtension(_meta.File), (name ?? "").Trim(), StringComparison.OrdinalIgnoreCase))
		{
			return "meta " + name + " isn't the one loaded";
		}
		try
		{
			string metaState = _metaState;
			Meta meta = (_meta = Meta.Load(_meta.File));
			_metaEdit = -1;
			_metaState = (meta.States().Contains(metaState) ? metaState : meta.States()[0]);
			Util.WriteToChat("Meta: " + meta.Name + " read again (changed on the phone) - " + meta.Rules.Count + " rules, state " + _metaState + ".");
			return "meta " + meta.Name + " reloaded";
		}
		catch (Exception ex)
		{
			return "couldn't read " + name + ": " + ex.Message;
		}
	}

	public void ToggleTools()
	{
		try
		{
			if (_toolsHud == null)
			{
				_toolsHud = UBService.Huds.CreateHud("MelkTank Route tools", BarIcon.Make("Rte"));
				_toolsHud.ShowInBar = false;
				_toolsHud.WindowSettings = ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoCollapse | ImGuiWindowFlags.AlwaysAutoResize;
				_toolsHud.OnRender += OnToolsRender;
				_toolsHud.Visible = true;
			}
			else
			{
				_toolsHud.Visible = !_toolsHud.Visible;
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public void DisposeTools()
	{
		try
		{
			if (_toolsHud != null)
			{
				_toolsHud.OnRender -= OnToolsRender;
				_toolsHud.Dispose();
			}
		}
		catch
		{
		}
		_toolsHud = null;
	}

	private void OnToolsRender(object sender, EventArgs e)
	{
		try
		{
			WinMem.Frame("Route tools", size: false);
			bool flag = false;
			NavRoute currentRoute = CurrentRoute;
			if (currentRoute == null || _s.NavMode != 1)
			{
				Im.TextColored(Grey, "Pick a route on Nav > Routes (Follow a route).");
				CloseButton();
				return;
			}
			Im.TextColored(Cyan, currentRoute.Name);
			ImGui.SameLine();
			Im.TextColored(Grey, (_rSel >= 0 && _rSel < currentRoute.Steps.Count) ? ("- adds after step " + (_rSel + 1)) : ("- adds at the end (" + currentRoute.Steps.Count + " steps)"));
			if (ImGui.Button("Add point here", new System.Numerics.Vector2(130f, 0f)))
			{
				RouteStep routeStep = NewPointHere(StepKind.Point);
				Insert(currentRoute, routeStep);
				if (_recording && routeStep != null)
				{
					_recNS = routeStep.NS;
					_recEW = routeStep.EW;
				}
				flag = true;
			}
			ImGui.SameLine();
			if (!_recording)
			{
				if (ImGui.Button("Record##trec", new System.Numerics.Vector2(70f, 0f)))
				{
					StartRecording(currentRoute);
					flag = true;
				}
			}
			else
			{
				ImGui.PushStyleColor(ImGuiCol.Button, new System.Numerics.Vector4(0.7f, 0.15f, 0.15f, 1f));
				if (ImGui.Button("Stop##trec", new System.Numerics.Vector2(70f, 0f)))
				{
					StopRecording();
					flag = true;
				}
				ImGui.PopStyleColor();
			}
			ImGui.SameLine();
			ImGui.SetNextItemWidth(80f);
			ImGui.InputFloat("m##trecm", ref _recEvery, 1f, 5f, "%.0f");
			if (_recEvery < 2f)
			{
				_recEvery = 2f;
			}
			if (_recEvery > 100f)
			{
				_recEvery = 100f;
			}
			if (_recording)
			{
				ImGui.SameLine();
				Im.TextColored(Yellow, "recording...");
			}
			if (ImGui.Button("Add portal / NPC", new System.Numerics.Vector2(130f, 0f)))
			{
				RouteStep routeStep2 = UseStepFromSelection();
				if (routeStep2 != null)
				{
					Insert(currentRoute, routeStep2);
					flag = true;
				}
			}
			ImGui.SameLine();
			Im.TextColored(Grey, "the one you have selected");
			if (ImGui.Button("Add wait", new System.Numerics.Vector2(130f, 0f)))
			{
				Insert(currentRoute, new RouteStep
				{
					Kind = StepKind.Wait,
					WaitMs = _rWaitSecs * 1000
				});
				flag = true;
			}
			ImGui.SameLine();
			ImGui.SetNextItemWidth(80f);
			ImGui.InputInt("s##twait", ref _rWaitSecs, 1, 5);
			if (_rWaitSecs < 0)
			{
				_rWaitSecs = 0;
			}
			List<string> list = NavPresets.Names();
			if (list.Count == 0)
			{
				ImGui.BeginDisabled();
				ImGui.Button("Add preset##tpre", new System.Numerics.Vector2(130f, 0f));
				ImGui.EndDisabled();
				ImGui.SameLine();
				Im.TextColored(Grey, "make one on the Presets tab");
			}
			else
			{
				if (_rPresetPick >= list.Count)
				{
					_rPresetPick = 0;
				}
				if (ImGui.Button("Add preset##tpre", new System.Numerics.Vector2(130f, 0f)))
				{
					Insert(currentRoute, new RouteStep
					{
						Kind = StepKind.Preset,
						Text = list[_rPresetPick]
					});
					flag = true;
				}
				ImGui.SameLine();
				ImGui.SetNextItemWidth(160f);
				ImGui.Combo("##tpreset", ref _rPresetPick, list.ToArray(), list.Count);
			}
			CloseButton();
			if (flag)
			{
				RouteChanged();
				if (SaveAll != null)
				{
					SaveAll();
				}
			}
			SaveRouteFiles(now: false);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void CloseButton()
	{
		if (ImGui.SmallButton("Close##tclose") && _toolsHud != null)
		{
			_toolsHud.Visible = false;
		}
	}

	private static void TravelState(string s)
	{
		try
		{
			AppDomain.CurrentDomain.SetData("MelkTank.Travel", s);
		}
		catch
		{
		}
	}

	private void AutorunOn()
	{
		_autorunOnAt = DateTime.Now;
		try
		{
			Globals.Core.Actions.SetAutorun(on: true);
		}
		catch
		{
		}
	}

	public void TravelCommand(string rest)
	{
		string text = (rest ?? "").Trim();
		if (text.Equals("stop", StringComparison.OrdinalIgnoreCase))
		{
			TravelStop("stopped from MelksQB", finished: false);
			return;
		}
		if (text.Equals("hide", StringComparison.OrdinalIgnoreCase))
		{
			_travelPreview = null;
			return;
		}
		if (text.StartsWith("show ", StringComparison.OrdinalIgnoreCase))
		{
			NavRoute navRoute = LoadRouteFile(text.Substring(5).Trim().Trim('"'));
			if (navRoute == null || navRoute.Steps.Count == 0)
			{
				Util.WriteToChat("Auto travel: couldn't read the route to show.");
				return;
			}
			navRoute.Name = "[travel preview] " + navRoute.Name;
			_travelPreview = navRoute;
			return;
		}
		if (text.StartsWith("walls", StringComparison.OrdinalIgnoreCase))
		{
			string text2 = text.Substring(5).Trim().ToLowerInvariant();
			if (text2 == "on")
			{
				WallFile("ok");
				_wallState = 1;
				_wallProven = false;
				Util.WriteToChat("Auto travel: the wall check is on.");
			}
			else if (text2 == "off")
			{
				WallFile("off (switched off by hand)");
				_wallState = 2;
				Util.WriteToChat("Auto travel: the wall check is off.");
			}
			else
			{
				Util.WriteToChat("Auto travel: the wall check is " + (WallCheckOn() ? "on" : "off") + ". /mtank travel walls on | off");
			}
			return;
		}
		bool flag = true;
		if (text.StartsWith("fight ", StringComparison.OrdinalIgnoreCase))
		{
			text = text.Substring(6).Trim();
		}
		else if (text.StartsWith("nofight ", StringComparison.OrdinalIgnoreCase))
		{
			flag = false;
			text = text.Substring(8).Trim();
		}
		if (MetaRunning)
		{
			TravelRefused("a meta is running - stop it first");
			return;
		}
		NavRoute navRoute2 = LoadRouteFile(text.Trim('"'));
		if (navRoute2 == null || navRoute2.Steps.Count == 0)
		{
			TravelRefused("couldn't read the route");
			return;
		}
		navRoute2.Name = "[travel] " + navRoute2.Name;
		navRoute2.Mode = 0;
		navRoute2.RestartIfFar = false;
		navRoute2.RestartIfStuck = false;
		bool flag2 = _travelRoute != null;
		if (!flag2)
		{
			_tWasEnabled = _s.NavEnabled;
			_tWasMode = _s.NavMode;
			_tWasRoute = _s.NavRouteSelected ?? "";
			_tWasMaster = _s.MasterEnabled;
			_tWasCombat = _s.CombatEnabled;
			_s.TravelKeep = true;
			_s.TKMaster = _tWasMaster;
			_s.TKCombat = _tWasCombat;
			_s.TKNav = _tWasEnabled;
			_s.TKNavMode = _tWasMode;
			_s.TKNavRoute = _tWasRoute;
			_tCombatOff = false;
		}
		_travelRoute = navRoute2;
		_travelPreview = null;
		if (!flag && !_tCombatOff)
		{
			_tCombatOff = true;
			_s.CombatEnabled = false;
		}
		_s.MasterEnabled = true;
		_s.NavEnabled = true;
		_s.NavMode = 1;
		_s.NavRouteSelected = navRoute2.Name;
		_tDetour = null;
		_tSide = 0;
		_tDetourFor = -1;
		_tStep = -1;
		_tStepSecs = 0.0;
		_tFlagSeen = false;
		_tFlagOff = 0;
		Stop();
		_rName = "";
		RouteReset();
		_tStartedAt = (_tLastTurn = DateTime.Now);
		TravelState("running|" + DateTime.UtcNow.Ticks);
		L("travel: " + navRoute2.Steps.Count + " steps, " + (flag ? "fighting on the way" : "combat off for the trip") + (flag2 ? " (route updated)" : ""));
		if (!flag2)
		{
			Util.WriteToChat("Auto travel: " + navRoute2.Steps.Count + " steps" + (flag ? " (stopping to fight)" : " (combat off for the trip)") + " - move yourself to stop it.");
		}
	}

	private void TravelRefused(string why)
	{
		if (_travelRoute != null)
		{
			TravelStop(why, finished: false);
			return;
		}
		TravelState("stopped|" + DateTime.UtcNow.Ticks + "|" + why);
		Util.WriteToChat("Auto travel stopped - " + why + ".");
	}

	public void TravelStop(string why, bool finished)
	{
		if (_travelRoute != null)
		{
			string name = _travelRoute.Name;
			_travelRoute = null;
			_tDetour = null;
			Stop();
			if (_s.NavEnabled && _s.NavMode == 1 && string.Equals(_s.NavRouteSelected, name, StringComparison.Ordinal))
			{
				_s.NavEnabled = _tWasEnabled;
				_s.NavMode = _tWasMode;
				_s.NavRouteSelected = _tWasRoute;
			}
			if (_s.MasterEnabled)
			{
				_s.MasterEnabled = _tWasMaster;
			}
			if (_tCombatOff && !_s.CombatEnabled)
			{
				_s.CombatEnabled = _tWasCombat;
			}
			_tCombatOff = false;
			_s.TravelKeep = false;
			_rName = "";
			RouteReset();
			TravelState((finished ? "finished|" : "stopped|") + DateTime.UtcNow.Ticks + (finished ? "" : ("|" + why)));
			L("travel: " + (finished ? "finished" : ("stopped - " + why)));
			Util.WriteToChat(finished ? "Auto travel finished." : ("Auto travel stopped - " + why + "."));
		}
	}

	private void TravelTick()
	{
		if (_travelRoute == null)
		{
			return;
		}
		DateTime now = DateTime.Now;
		double num = Math.Min(0.5, Math.Max(0.0, (now - _tTickAt).TotalSeconds));
		_tTickAt = now;
		if (!_s.MasterEnabled)
		{
			TravelStop("MelkTank was switched off", finished: false);
			return;
		}
		if (!string.Equals(_s.NavRouteSelected, _travelRoute.Name, StringComparison.Ordinal) || !_s.NavEnabled || _s.NavMode != 1)
		{
			L("travel: nav setting changed under it - NavEnabled " + _s.NavEnabled + ", NavMode " + _s.NavMode + ", route '" + _s.NavRouteSelected + "' (travel's '" + _travelRoute.Name + "'), meta " + MetaRunning);
			TravelStop("another route / nav setting was picked", finished: false);
			return;
		}
		if (_rDone && string.Equals(_rName, _travelRoute.Name, StringComparison.Ordinal))
		{
			TravelStop("", finished: true);
			return;
		}
		bool flag = (now - _rTickAt).TotalSeconds < 0.5;
		if (flag || _inPortal)
		{
			_tLastTurn = now;
		}
		if ((now - _tLastTurn).TotalMinutes > 5.0)
		{
			TravelStop("the route hasn't had a turn for 5 minutes (fighting / busy / paused)", finished: false);
			return;
		}
		int num2 = _rIdx * 1000 + _rSub;
		if (num2 != _tStep)
		{
			_tStep = num2;
			_tStepSecs = 0.0;
			_tStuckBase = StuckEvents;
		}
		else if (flag && !_inPortal)
		{
			_tStepSecs += num;
		}
		if (StuckEvents - _tStuckBase >= 3)
		{
			TravelStop("couldn't get past step " + (_rIdx + 1) + " (blocked 3 times)", finished: false);
			return;
		}
		if (_tStepSecs > (double)((_tSide != 0) ? 180 : 90))
		{
			TravelStop("step " + (_rIdx + 1) + " took over " + ((_tSide != 0) ? "3 minutes, going round a wall" : "90 s") + " (" + Status + ")", finished: false);
			return;
		}
		int num3 = ((_running && _moving && !_pulsing && _restartStage == 0 && (now - _lastReturnTick).TotalSeconds < 0.3) ? AutorunFlag() : (-1));
		if (num3 != 1 && (now - _doorUseAt).TotalSeconds < 4.0)
		{
			if (!_doorRerun && num3 == 0 && (now - _doorUseAt).TotalSeconds > 1.2)
			{
				_doorRerun = true;
				AutorunOn();
				L("travel: door used - running on");
			}
			num3 = -1;
			_tFlagOff = 0;
		}
		if (num3 == 1)
		{
			_tFlagSeen = true;
			_tFlagOff = 0;
		}
		else if (num3 == 0 && _tFlagSeen && (now - _autorunOnAt).TotalSeconds > 1.5 && (now - _tStartedAt).TotalSeconds > 3.0)
		{
			if (_tFlagOff == 0)
			{
				_tFlagOff = 1;
				_tFlagAt = now;
			}
			else if ((now - _tFlagAt).TotalSeconds > 0.25)
			{
				TravelStop("you moved", finished: false);
				return;
			}
		}
		else
		{
			_tFlagOff = 0;
		}
		if ((now - _tStartedAt).TotalSeconds > 2.0 && (now - _doorUseAt).TotalSeconds > 4.0 && PlayerKeyHeld(_turning != 0))
		{
			if (_tKeyAt == DateTime.MinValue)
			{
				_tKeyAt = now;
			}
			else if ((now - _tKeyAt).TotalSeconds > 0.2)
			{
				TravelStop("you moved", finished: false);
			}
		}
		else
		{
			_tKeyAt = DateTime.MinValue;
		}
	}

#if RETAIL
	private unsafe static bool PlayerKeyHeld(bool navTurning)
	{
		try
		{
			SmartBox** smartbox = SmartBox.smartbox;
			if (smartbox == null || *smartbox == null || (*smartbox)->cmdinterp == null)
			{
				return false;
			}
			CommandInterpreter* cmdinterp = (*smartbox)->cmdinterp;
			int num = 0;
			CommandListElement* ptr = (cmdinterp->SubstateList).head;
			while (ptr != null && num < 16)
			{
				if (ptr->command == 1157627910)
				{
					return true;
				}
				ptr = ptr->next;
				num++;
			}
			if ((cmdinterp->SidestepList).head != null)
			{
				return true;
			}
			if (!navTurning && (cmdinterp->TurnList).head != null)
			{
				return true;
			}
			return false;
		}
		catch
		{
			return false;
		}
	}
#else
	private static bool PlayerKeyHeld(bool navTurning)
	{
		try
		{
			if (ImGuiLayer.WantsKeyboard)
			{
				return false;
			}
			if (Input.IsKeyPressed(Key.S) || Input.IsKeyPressed(Key.Q) || Input.IsKeyPressed(Key.E))
			{
				return true;
			}
			return !navTurning && (Input.IsKeyPressed(Key.A) || Input.IsKeyPressed(Key.D));
		}
		catch
		{
			return false;
		}
	}
#endif

	private bool TravelPointOk(NavSpot to)
	{
		double num = DistanceTo(to);
		if (num < 0.0 || num <= 300.0)
		{
			return true;
		}
		TravelStop("the next point is " + num.ToString("0") + " m away - not where the route expected to be", finished: false);
		return false;
	}

#if RETAIL
	private unsafe static int AutorunFlag()
	{
		try
		{
			SmartBox** smartbox = SmartBox.smartbox;
			if (smartbox == null || *smartbox == null || (*smartbox)->cmdinterp == null)
			{
				return -1;
			}
			return ((*smartbox)->cmdinterp->auto_run != 0) ? 1 : 0;
		}
		catch
		{
			return -1;
		}
	}
#else
	private static int AutorunFlag()
	{
		ACGodot.Plugins.PluginHost host = Bridge.Host;
		return (host?.Player == null) ? (-1) : (host.AutoRun ? 1 : 0);
	}
#endif

	private static void WallFile(string s)
	{
		try
		{
			File.WriteAllText(WallPath, s);
		}
		catch
		{
		}
	}

	private static bool WallCheckOn()
	{
		if (_wallState == 0)
		{
			_wallState = 1;
			try
			{
				string text = (File.Exists(WallPath) ? File.ReadAllText(WallPath).Trim() : "");
				if (text.StartsWith("testing", StringComparison.OrdinalIgnoreCase))
				{
					_wallState = 2;
					WallFile("off (the game closed during a wall check, " + DateTime.Now.ToString("yyyy-MM-dd HH:mm") + ")");
					Util.WriteToChat("Auto travel: the game closed during a wall check last time - the wall check is off now (/mtank travel walls on to try it again).");
				}
				else if (text.StartsWith("off", StringComparison.OrdinalIgnoreCase))
				{
					_wallState = 2;
				}
			}
			catch
			{
			}
		}
		return _wallState == 1;
	}

	private NavSpot TravelDetour(NavSpot to)
	{
		DateTime now = DateTime.Now;
		double num = DistanceTo(to);
		if (_tDetourFor != _rIdx)
		{
			_tDetourFor = _rIdx;
			_tSide = 0;
			_tDetour = null;
			_tFlipped = false;
			_tHits.Clear();
		}
		if (_tDetour != null)
		{
			if (!((now - _tDetourAt).TotalSeconds > 5.0) && !(DistanceTo(_tDetour) < 1.5))
			{
				return _tDetour;
			}
			_tDetour = null;
		}
		if (!WallCheckOn())
		{
			return to;
		}
		if (_tSide == 0 && (now - _tProbeAt).TotalMilliseconds < 400.0)
		{
			return to;
		}
		_tProbeAt = now;
		if (!MyPos(out var ns, out var ew, out var z))
		{
			return to;
		}
		if (num < 3.0)
		{
			_tSide = 0;
			return to;
		}
		double num2 = Math.Min(12.0, num);
		double num3 = (_pBearing = BearingTo(to));
		_pSlope = ((to.Z != 0.0 && num > 1.0) ? Math.Max(-1.5, Math.Min(1.5, (to.Z - z) / num)) : double.NaN);
		if (now < _tPushUntil)
		{
			return to;
		}
		double num4 = SafeProbe(num3, num2);
		if (num4 < 0.0)
		{
			return to;
		}
		bool flag = num4 > 0.8 || num4 * num2 >= num - 1.0;
		if (_tSide != 0)
		{
			bool flag2 = _tHits.Count > 1;
			if (flag && (!flag2 || num < _tHitD - 1.0))
			{
				L("travel: past the wall (" + _tFollowM.ToString("0") + " m round it)");
				_tSide = 0;
				return to;
			}
			if (_tFollowM > 220.0 || (now - _tFollowAt).TotalSeconds > 75.0)
			{
				if (_tFlipped)
				{
					L("travel: no way round the wall found");
					_tSide = 0;
					return to;
				}
				_tFlipped = true;
				_tSide = -_tSide;
				_tFollowM = 0.0;
				_tFollowAt = now;
				_tHitD = num;
				_tHits.Clear();
				L("travel: no way round on that side - trying the other");
			}
		}
		else
		{
			if (flag)
			{
				return to;
			}
			if (now < _tDoorWait)
			{
				return to;
			}
			if (_tLastDoor != 0 && (now - _tLastDoorAt).TotalSeconds < 8.0)
			{
				if (DoorShut(_tLastDoor) != false)
				{
					if (!_tLastDoorAgain && (now - _tLastDoorAt).TotalSeconds > 4.0)
					{
						_tLastDoorAgain = true;
						try
						{
							Globals.Core.Actions.UseItem(_tLastDoor, 0);
						}
						catch
						{
						}
						_doorUseAt = now;
						_doorRerun = false;
						L("travel: the door's still shut - using it again");
					}
					Status = "Waiting for the door to open";
					_tDoorWait = now.AddMilliseconds(300.0);
					return to;
				}
				_tLastDoor = 0;
			}
			int num5 = DoorAhead(ns, ew, num3);
			bool? flag3 = ((num5 != 0) ? DoorShut(num5) : new bool?(false));
			if (num5 != 0 && !flag3.HasValue)
			{
				_tDoorWait = now.AddMilliseconds(250.0);
				return to;
			}
			if (num5 != 0 && flag3 == false)
			{
				_tDoorUsed[num5] = now;
				L("travel: the door ahead is open already - not using it");
				num5 = 0;
			}
			if (num5 != 0)
			{
				try
				{
					Globals.Core.Actions.UseItem(num5, 0);
				}
				catch
				{
				}
				_doorUseAt = now;
				_doorRerun = false;
				_tDoorUsed[num5] = now;
				_tDoorWait = now.AddSeconds(1.5);
				_tLastDoor = num5;
				_tLastDoorAt = now;
				_tLastDoorAgain = false;
				L("travel: a door in the way - opening it");
				return to;
			}
			int num6 = 0;
			for (int i = 1; i <= 12; i++)
			{
				if (num6 != 0)
				{
					break;
				}
				if (SafeProbe(num3 + (double)i * 15.0, 6.0) >= 0.6)
				{
					num6 = 1;
				}
				else if (SafeProbe(num3 - (double)i * 15.0, 6.0) >= 0.6)
				{
					num6 = -1;
				}
			}
			if (num6 == 0)
			{
				num6 = 1;
			}
			_tSide = num6;
			_tFollowM = 0.0;
			_tFollowAt = now;
			_tHitD = num;
			_tHeading = num3;
			_tTurned = 0.0;
			bool flag4 = false;
			foreach (double[] tHit in _tHits)
			{
				if (Math.Abs(tHit[0] - ns) * 240.0 < 4.0 && Math.Abs(tHit[1] - ew) * 240.0 < 4.0)
				{
					flag4 = true;
				}
			}
			_tHits.Add(new double[2] { ns, ew });
			L("travel: wall ahead (" + (num4 * 100.0).ToString("0") + "% clear) - following it on the " + ((num6 > 0) ? "right" : "left") + (flag4 ? " (met it here before)" : ""));
		}
		double num7 = double.NaN;
		double num8 = 0.0;
		for (int j = 0; j <= 24; j++)
		{
			double num9 = _tHeading - (double)(_tSide * 60) + (double)_tSide * 15.0 * (double)j;
			double num10 = SafeProbe(num9, 6.0);
			if (num10 < 0.0)
			{
				return to;
			}
			if (num10 >= 0.55)
			{
				num7 = num9;
				num8 = num10;
				break;
			}
		}
		if (double.IsNaN(num7))
		{
			L("travel: boxed in - nowhere clear to go");
			_tSide = 0;
			return to;
		}
		double num11 = ((num7 - _tHeading) % 360.0 + 540.0) % 360.0 - 180.0;
		_tTurned += num11;
		if (Math.Abs(_tTurned) >= 450.0 && num >= _tHitD - 2.0)
		{
			L("travel: going round in circles - straight on for a few seconds");
			_tSide = 0;
			_tTurned = 0.0;
			_tPushUntil = now.AddSeconds(4.0);
			return to;
		}
		_tHeading = num7;
		double num12 = Math.Max(2.0, Math.Min(4.0, num8 * 6.0 - 1.2));
		double num13 = num7 * Math.PI / 180.0;
		_tDetour = new NavSpot
		{
			Name = to.Name + " (round the wall)",
			NS = ns + Math.Cos(num13) * num12 / 240.0,
			EW = ew + Math.Sin(num13) * num12 / 240.0,
			Z = z,
			Heading = -1.0
		};
		_tDetourAt = now;
		_tFollowM += num12;
		_retarget = true;
		return _tDetour;
	}

#if RETAIL
	private unsafe bool? DoorShut(int id)
	{
		try
		{
			int physicsObjectPtr = Globals.Core.Actions.Underlying.GetPhysicsObjectPtr(id);
			if (physicsObjectPtr != 0)
			{
				return (((CPhysicsObj*)physicsObjectPtr)->state & 4) == 0;
			}
		}
		catch
		{
		}
		DateTime now = DateTime.Now;
		if (!_doorAsked.TryGetValue(id, out var value) || (now - value).TotalSeconds > 4.0)
		{
			_doorAsked[id] = now;
			try
			{
				Util.RequestId(id);
			}
			catch
			{
				return true;
			}
			return null;
		}
		if ((now - value).TotalSeconds < 0.8)
		{
			return null;
		}
		try
		{
			WorldObject worldObject = Globals.Core.WorldFilter[id];
			if (worldObject == null || !worldObject.HasIdData)
			{
				return true;
			}
			return !worldObject.Values(BoolValueKey.Open, defaultValue: false);
		}
		catch
		{
			return true;
		}
	}
#else
	private bool? DoorShut(int id)
	{
		try
		{
			int physicsObjectPtr = Globals.Core.Actions.Underlying.GetPhysicsObjectPtr(id);
		}
		catch
		{
		}
		DateTime now = DateTime.Now;
		if (!_doorAsked.TryGetValue(id, out var value) || (now - value).TotalSeconds > 4.0)
		{
			_doorAsked[id] = now;
			try
			{
				Util.RequestId(id);
			}
			catch
			{
				return true;
			}
			return null;
		}
		if ((now - value).TotalSeconds < 0.8)
		{
			return null;
		}
		try
		{
			WorldObject worldObject = Globals.Core.WorldFilter[id];
			if (worldObject == null || !worldObject.HasIdData)
			{
				return true;
			}
			return !worldObject.Values(BoolValueKey.Open, false);
		}
		catch
		{
			return true;
		}
	}
#endif

	private static bool IsDoor(WorldObject o)
	{
		if (o == null)
		{
			return false;
		}
		if (o.ObjectClass == ObjectClass.Door)
		{
			return true;
		}
		string text = o.Name ?? "";
		return text.IndexOf("Portcullis", StringComparison.OrdinalIgnoreCase) >= 0 || text.EndsWith(" Gate", StringComparison.OrdinalIgnoreCase) || text.Equals("Gate", StringComparison.OrdinalIgnoreCase);
	}

	private int DoorBetween(WorldObject target)
	{
		try
		{
			CoordsObject coordsObject = Globals.Core.WorldFilter[Globals.Core.CharacterFilter.Id].Coordinates();
			CoordsObject coordsObject2 = target.Coordinates();
			double num = (coordsObject2.EastWest - coordsObject.EastWest) * 240.0;
			double num2 = (coordsObject2.NorthSouth - coordsObject.NorthSouth) * 240.0;
			double num3 = num * num + num2 * num2;
			if (num3 < 0.01)
			{
				return 0;
			}
			int result = 0;
			double num4 = double.MaxValue;
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				if (!IsDoor(item) || (_tDoorUsed.TryGetValue(item.Id, out var value) && (DateTime.Now - value).TotalSeconds < 3.0))
				{
					continue;
				}
				CoordsObject coordsObject3 = item.Coordinates();
				double num5 = (coordsObject3.EastWest - coordsObject.EastWest) * 240.0;
				double num6 = (coordsObject3.NorthSouth - coordsObject.NorthSouth) * 240.0;
				double num7 = (num5 * num + num6 * num2) / num3;
				if (num7 < -0.05 || num7 > 0.95)
				{
					continue;
				}
				double num8 = num * num7 - num5;
				double num9 = num2 * num7 - num6;
				double num10 = Math.Sqrt(num8 * num8 + num9 * num9);
				if (!(num10 > 2.0))
				{
					double num11 = num5 * num5 + num6 * num6;
					if (num11 < num4)
					{
						num4 = num11;
						result = item.Id;
					}
				}
			}
			return result;
		}
		catch
		{
			return 0;
		}
	}

	private int DoorAhead(double ns, double ew, double bearing)
	{
		int result = 0;
		double num = 6.0;
		try
		{
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				if (!IsDoor(item) || (_tDoorUsed.TryGetValue(item.Id, out var value) && (DateTime.Now - value).TotalSeconds < 10.0))
				{
					continue;
				}
				CoordsObject coordsObject = item.Coordinates();
				double num2 = (coordsObject.NorthSouth - ns) * 240.0;
				double num3 = (coordsObject.EastWest - ew) * 240.0;
				double num4 = Math.Sqrt(num2 * num2 + num3 * num3);
				if (!(num4 >= num))
				{
					double num5 = (Math.Atan2(num3, num2) * 180.0 / Math.PI + 360.0) % 360.0;
					double num6 = Math.Abs(((num5 - bearing) % 360.0 + 540.0) % 360.0 - 180.0);
					if (!(num6 > 75.0) || !(num4 > 2.0))
					{
						num = num4;
						result = item.Id;
					}
				}
			}
		}
		catch
		{
		}
		return result;
	}

	private static double AngleOff(double a, double b)
	{
		return Math.Abs(((a - b) % 360.0 + 540.0) % 360.0 - 180.0);
	}

	private static double SafeProbe(double bearing, double metres)
	{
		if (!_wallProven)
		{
			WallFile("testing");
		}
		double result = Probe(bearing, metres);
		if (!_wallProven)
		{
			_wallProven = true;
			WallFile("ok");
		}
		return result;
	}

#if RETAIL
	private unsafe static double Probe(double bearing, double metres)
	{
		try
		{
			SmartBox** smartbox = SmartBox.smartbox;
			if (smartbox == null || *smartbox == null || (*smartbox)->cmdinterp == null)
			{
				return -1.0;
			}
			CPhysicsObj* player = (*smartbox)->cmdinterp->player;
			if (player == null || player->cell == null || player->part_array == null)
			{
				return -1.0;
			}
			Position position = player->m_position;
			uint objcell_id = position.objcell_id;
			if (objcell_id == 0 || (objcell_id & 0xFFFF) == 0)
			{
				return -1.0;
			}
			double num = bearing * Math.PI / 180.0;
			double num2 = Math.Sin(num) * metres;
			double num3 = Math.Cos(num) * metres;
			Position val = position;
			bool flag = (objcell_id & 0xFFFF) >= 256;
			if (flag)
			{
				val.frame.m_fOrigin.x = (float)((double)position.frame.m_fOrigin.x + num2);
				val.frame.m_fOrigin.y = (float)((double)position.frame.m_fOrigin.y + num3);
			}
			else
			{
				double num4 = (double)(objcell_id >> 24) * 192.0 + (double)position.frame.m_fOrigin.x + num2;
				double num5 = (double)((objcell_id >> 16) & 0xFF) * 192.0 + (double)position.frame.m_fOrigin.y + num3;
				if (num4 < 0.0 || num5 < 0.0 || num4 >= 48960.0 || num5 >= 48960.0)
				{
					return -1.0;
				}
				int num6 = (int)(num4 / 192.0);
				int num7 = (int)(num5 / 192.0);
				double num8 = num4 - (double)(num6 * 192);
				double num9 = num5 - (double)(num7 * 192);
				val.objcell_id = (uint)((num6 << 24) | (num7 << 16) | ((int)(num8 / 24.0) * 8 + (int)(num9 / 24.0) + 1));
				val.frame.m_fOrigin.x = (float)num8;
				val.frame.m_fOrigin.y = (float)num9;
				Func<double, double, double> func = null;
				try
				{
					func = AppDomain.CurrentDomain.GetData("MelksQB.GroundZ") as Func<double, double, double>;
				}
				catch
				{
				}
				double num10 = double.NaN;
				double num11 = double.NaN;
				if (func != null)
				{
					double num12 = (double)(objcell_id >> 24) * 192.0 + (double)position.frame.m_fOrigin.x;
					double num13 = (double)((objcell_id >> 16) & 0xFF) * 192.0 + (double)position.frame.m_fOrigin.y;
					try
					{
						num10 = func((num13 - 24468.0) / 240.0, (num12 - 24468.0) / 240.0);
						num11 = func((num5 - 24468.0) / 240.0, (num4 - 24468.0) / 240.0);
					}
					catch
					{
					}
				}
				if (!double.IsNaN(num10) && !double.IsNaN(num11))
				{
					val.frame.m_fOrigin.z = (float)((double)position.frame.m_fOrigin.z + (num11 - num10) + 0.3);
				}
				else if (!double.IsNaN(_pSlope) && AngleOff(bearing, _pBearing) < 25.0)
				{
					val.frame.m_fOrigin.z = (float)((double)position.frame.m_fOrigin.z + _pSlope * metres + 0.3);
				}
			}
			if (flag && !double.IsNaN(_pSlope) && AngleOff(bearing, _pBearing) < 25.0)
			{
				val.frame.m_fOrigin.z = (float)((double)position.frame.m_fOrigin.z + _pSlope * metres + 0.3);
			}
			CTransition* ptr = player->transition(&position, &val, 0);
			if (ptr == null)
			{
				return 0.0;
			}
			Position curr_pos = (ptr->sphere_path).curr_pos;
			double num14;
			double num15;
			if (flag)
			{
				num14 = curr_pos.frame.m_fOrigin.x - position.frame.m_fOrigin.x;
				num15 = curr_pos.frame.m_fOrigin.y - position.frame.m_fOrigin.y;
			}
			else
			{
				num14 = ((double)(curr_pos.objcell_id >> 24) - (double)(objcell_id >> 24)) * 192.0 + (double)curr_pos.frame.m_fOrigin.x - (double)position.frame.m_fOrigin.x;
				num15 = ((double)((curr_pos.objcell_id >> 16) & 0xFF) - (double)((objcell_id >> 16) & 0xFF)) * 192.0 + (double)curr_pos.frame.m_fOrigin.y - (double)position.frame.m_fOrigin.y;
			}
			double num16 = (num14 * num2 + num15 * num3) / metres;
			return Math.Max(0.0, Math.Min(1.0, num16 / metres));
		}
		catch
		{
			return -1.0;
		}
	}
#else
	private static double Probe(double bearing, double metres)
	{
		ACGodot.Plugins.PluginHost host = Bridge.Host;
		return (host?.Player == null) ? (-1.0) : host.Probe(bearing, metres);
	}
#endif
}
