using System;
using System.Collections.Generic;
using Decal.Adapter;
using Decal.Adapter.Wrappers;

namespace MelkTank;

public static class InvCache
{
	private static List<WorldObject> _all;

	private static HashSet<int> _ids = new HashSet<int>();

	private static DateTime _at = DateTime.MinValue;

	private static volatile bool _dirty = true;

	private static bool _hooked;

	public static int Rebuilds;

	public static int Uses;

	public static int Version;

	public static List<WorldObject> All()
	{
		Hook();
		Uses++;
		DateTime now = DateTime.Now;
		if (_all != null && !_dirty && (now - _at).TotalMilliseconds < 1000.0)
		{
			return _all;
		}
		long t = Perf.Begin();
		List<WorldObject> list = new List<WorldObject>((_all != null) ? (_all.Count + 8) : 256);
		HashSet<int> hashSet = new HashSet<int>();
		foreach (WorldObject item in CoreManager.Current.WorldFilter.GetInventory())
		{
			list.Add(item);
			hashSet.Add(item.Id);
		}
		_dirty = false;
		_at = now;
		_all = list;
		_ids = hashSet;
		Rebuilds++;
		Perf.Lap("  inventory list rebuilt", t);
		return list;
	}

	public static void Invalidate()
	{
		_dirty = true;
		Version++;
	}

	private static void Hook()
	{
		if (_hooked)
		{
			return;
		}
		try
		{
			WorldFilter worldFilter = CoreManager.Current.WorldFilter;
			worldFilter.CreateObject += OnCreate;
			worldFilter.ReleaseObject += OnRelease;
			worldFilter.ChangeObject += OnChange;
			_hooked = true;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void Unhook()
	{
		_all = null;
		_dirty = true;
		if (!_hooked)
		{
			return;
		}
		_hooked = false;
		try
		{
			WorldFilter worldFilter = CoreManager.Current.WorldFilter;
			worldFilter.CreateObject -= OnCreate;
			worldFilter.ReleaseObject -= OnRelease;
			worldFilter.ChangeObject -= OnChange;
		}
		catch
		{
		}
	}

	private static void OnCreate(object sender, CreateObjectEventArgs e)
	{
		try
		{
			if (e.New.Container == 0 && e.New.Values(LongValueKey.Wielder, 0) == 0)
			{
				return;
			}
		}
		catch
		{
		}
		_dirty = true;
		Version++;
		try
		{
			PackOrganizer.NewItemIn(e.New.Container);
		}
		catch
		{
		}
	}

	private static void OnRelease(object sender, ReleaseObjectEventArgs e)
	{
		try
		{
			if (!_ids.Contains(e.Released.Id))
			{
				return;
			}
		}
		catch
		{
		}
		_dirty = true;
		Version++;
	}

	private static void OnChange(object sender, ChangeObjectEventArgs e)
	{
		if (e.Change == WorldChangeType.StorageChange)
		{
			_dirty = true;
			Version++;
		}
		else if (e.Change == WorldChangeType.SizeChange)
		{
			Version++;
		}
	}
}
