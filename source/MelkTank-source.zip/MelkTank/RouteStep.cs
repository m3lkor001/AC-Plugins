using System.Collections.Generic;

namespace MelkTank;

public class RouteStep
{
	public StepKind Kind;

	public double NS;

	public double EW;

	public double Z;

	public string Text = "";

	public int WaitMs = 1000;

	public string Op = "";

	public int Count;

	/// <summary>A vendor step's profile (empty: the one named after the vendor).</summary>
	public string Profile = "";

	public List<LoopCond> Conds = new List<LoopCond>();
}
