namespace MelkTank;

public class SpellFamily
{
	public readonly string Key;

	public readonly string BaseName;

	public readonly SpellLevel[] Levels;

	public SpellFamily(string key, string baseName, SpellLevel[] levels)
	{
		Key = key;
		BaseName = baseName;
		Levels = levels;
	}
}
