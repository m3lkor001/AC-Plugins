using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using Decal.Adapter.Wrappers;
using MelkTank.Pets;

namespace MelkTank;

public static class BookReader
{
	public const string BookName = "Monster-Dex";

	private static int _bookId;

	private static DateTime _until = DateTime.MinValue;

	private static readonly HashSet<uint> Noise = new HashSet<uint> { 63304u, 63308u, 63310u, 63001u, 63004u, 63312u, 63307u, 63454u, 63317u };

	public static DateTime LastOpenAt = DateTime.MinValue;

	private static object _incoming;

	private static readonly List<KeyValuePair<EventInfo, Delegate>> _hooks = new List<KeyValuePair<EventInfo, Delegate>>();

	private static readonly SortedDictionary<int, string> _pages = new SortedDictionary<int, string>();

	private static string _header = "";

	private static string FilePath => Util.FullPath(Path.Combine("Logs", "Book_Monster-Dex.txt"));

	private static string PagesPath => Dex.PagesPath;   // (this character's own: its caught marks are its own)

	private static int BookId()
	{
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (string.Equals(item.Name, "Monster-Dex", StringComparison.OrdinalIgnoreCase))
				{
					return item.Id;
				}
			}
		}
		catch
		{
		}
		return _bookId;
	}

	private static bool Mentions(byte[] raw, int id)
	{
		if (id == 0 || raw == null)
		{
			return false;
		}
		byte b = (byte)id;
		byte b2 = (byte)(id >> 8);
		byte b3 = (byte)(id >> 16);
		byte b4 = (byte)(id >> 24);
		for (int i = 0; i + 3 < raw.Length; i++)
		{
			if (raw[i] == b && raw[i + 1] == b2 && raw[i + 2] == b3 && raw[i + 3] == b4)
			{
				return true;
			}
		}
		return false;
	}

	public static void OnClientMessage(byte[] raw)
	{
		int id = ((_bookId != 0) ? _bookId : (_bookId = BookId()));
		if (Mentions(raw, id))
		{
			HookUb();
			bool flag = DateTime.Now > _until;
			_until = DateTime.Now.AddMinutes(2.0);
			Write("OUT", raw);
			if (flag)
			{
				Util.WriteToChat("Book: saving what the server sends about the Monster-Dex for 2 minutes (Logs\\Book_Monster-Dex.txt) - turn through its pages.");
			}
		}
	}

	public static void OnServerMessage(uint type, byte[] raw)
	{
		if (raw == null)
		{
			return;
		}
		// (only while you're reading it - the capture starts when you open the book, not when the server mentions the
		// Monster-Dex: it does all the time while hunting - every catch - and each mention recorded two minutes of
		// everything; the file only grew)
		if (DateTime.Now > _until)
		{
			int id = ((_bookId != 0) ? _bookId : (_bookId = BookId()));
			if (Mentions(raw, id)) HookUb();
			return;
		}
		if (!Noise.Contains(type))
		{
			Write("IN", raw);
		}
	}

	private static void Write(string dir, byte[] raw)
	{
		uint num = ((raw.Length >= 4) ? BitConverter.ToUInt32(raw, 0) : 0u);
		int num2 = 0;
		string value = "";
		if (num == 63408 && raw.Length >= 16)
		{
			value = "  event 0x" + BitConverter.ToUInt32(raw, 12).ToString("X4");
			num2 = 16;
		}
		else if (num == 63409 && raw.Length >= 12)
		{
			value = "  action 0x" + BitConverter.ToUInt32(raw, 8).ToString("X4");
			num2 = 12;
		}
		else
		{
			num2 = 4;
		}
		List<string> list = Strings(raw, num2);
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("==== ").Append(DateTime.Now.ToString("HH:mm:ss.fff")).Append(' ')
			.Append(dir)
			.Append("  0x")
			.Append(num.ToString("X4"))
			.Append(value)
			.Append("  ")
			.Append(raw.Length)
			.Append(" bytes\r\n");
		for (int i = 0; i < list.Count; i++)
		{
			stringBuilder.Append("[").Append(i).Append("] ")
				.Append(list[i].Replace("\n", "\r\n    "))
				.Append("\r\n");
		}
		int num3 = Math.Min(raw.Length, 4096);
		for (int j = 0; j < num3; j += 32)
		{
			stringBuilder.Append(BitConverter.ToString(raw, j, Math.Min(32, num3 - j)).Replace("-", " ")).Append("\r\n");
		}
		stringBuilder.Append("\r\n");
		try
		{
			Directory.CreateDirectory(Path.GetDirectoryName(FilePath));
			// (kept small: past 2 MB it starts afresh - the one before kept as .old)
			FileInfo fi = new FileInfo(FilePath);
			if (fi.Exists && fi.Length > 2L * 1024 * 1024)
			{
				string old = Path.ChangeExtension(FilePath, ".old.txt");
				if (File.Exists(old)) File.Delete(old);
				File.Move(FilePath, old);
			}
			File.AppendAllText(FilePath, stringBuilder.ToString());
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static List<string> Strings(byte[] raw, int start)
	{
		List<string> list = new List<string>();
		int num = start;
		while (num + 2 <= raw.Length)
		{
			int num2 = BitConverter.ToUInt16(raw, num);
			if (num2 > 0 && num + 2 + num2 <= raw.Length && Printable(raw, num + 2, num2))
			{
				list.Add(Encoding.GetEncoding(1252).GetString(raw, num + 2, num2));
				int num3 = num + 2 + num2;
				num = start + ((num3 - start + 3) & -4);
			}
			else
			{
				num += 4;
			}
		}
		return list;
	}

	private static bool Printable(byte[] b, int at, int len)
	{
		for (int i = at; i < at + len; i++)
		{
			byte b2 = b[i];
			if (b2 != 9 && b2 != 10 && b2 != 13 && (b2 < 32 || b2 == 127))
			{
				return false;
			}
		}
		return true;
	}

	private static bool _acgHooked;

	// (ACGodot: the pages come from the game itself - it asks the server for every page of a book that's opened)
	public static void HookUb()
	{
		if (_acgHooked)
		{
			return;
		}
		_acgHooked = true;
		ACGodot.DecalShim.Bridge.BookPage += OnAcgPage;
	}

	private static int _acgTotal;

	private static void OnAcgPage(int id, int page, int pages, string text)
	{
		try
		{
			int num = BookId();
			if (num == 0 || id != num)
			{
				return;
			}
			_bookId = num;
			if (page < 0)
			{
				LastOpenAt = DateTime.Now;
				_pages.Clear();
				_acgTotal = pages;
				_header = "Pages: " + pages;
				Util.WriteToChat("Book: Monster-Dex opened - reading its " + pages + " page(s).");
				return;
			}
			_pages[page] = text ?? "";
			// (saved once they're all in, and as each comes when it isn't known how many there are)
			if (_acgTotal <= 0 || _pages.Count >= _acgTotal)
			{
				SavePages();
				if (_acgTotal > 0)
				{
					Util.WriteToChat("Book: Monster-Dex read - " + _pages.Count + " page(s) saved.");
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void Unhook()
	{
		try
		{
			foreach (KeyValuePair<EventInfo, Delegate> hook in _hooks)
			{
				hook.Key.RemoveEventHandler(_incoming, hook.Value);
			}
		}
		catch
		{
		}
		_hooks.Clear();
		_incoming = null;
	}

	private static object F(object o, string name)
	{
		if (o == null)
		{
			return null;
		}
		FieldInfo field = o.GetType().GetField(name);
		if (field != null)
		{
			return field.GetValue(o);
		}
		PropertyInfo property = o.GetType().GetProperty(name);
		return (property != null) ? property.GetValue(o, null) : null;
	}

	private static void OnUbEvent(object sender, object e)
	{
		try
		{
			object obj = F(e, "Data");
			if (obj == null)
			{
				return;
			}
			int num = ((_bookId != 0) ? _bookId : (_bookId = BookId()));
			uint num2 = Convert.ToUInt32(F(obj, "ObjectId"));
			if (num == 0 || num2 != (uint)num)
			{
				return;
			}
			if (e.GetType().Name.StartsWith("Writing_BookOpen"))
			{
				LastOpenAt = DateTime.Now;
				_pages.Clear();
				object o = F(obj, "PageData");
				_header = "Pages: " + F(obj, "MaxNumPages")?.ToString() + "   Inscription: " + F(obj, "Inscription")?.ToString() + "   Scribe: " + F(obj, "ScribeName");
				IEnumerable enumerable = F(o, "Pages") as IEnumerable;
				int num3 = 0;
				if (enumerable != null)
				{
					foreach (object item in enumerable)
					{
						_pages[num3++] = Convert.ToString(F(item, "PageText"));
					}
				}
				Util.WriteToChat("Book: Monster-Dex opened - " + num3 + " page(s) came with it; turn through the rest.");
			}
			else
			{
				int key = Convert.ToInt32(F(obj, "Page"));
				_pages[key] = Convert.ToString(F(F(obj, "PageData"), "PageText"));
			}
			SavePages();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void SavePages()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("Monster-Dex").Append("  (saved ").Append(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"))
			.Append(")\r\n")
			.Append(_header)
			.Append("\r\n\r\n");
		foreach (KeyValuePair<int, string> page in _pages)
		{
			stringBuilder.Append("---- Page ").Append(page.Key + 1).Append(" ----\r\n")
				.Append((page.Value ?? "").Replace("\r\n", "\n").Replace("\n", "\r\n"))
				.Append("\r\n\r\n");
		}
		try
		{
			Directory.CreateDirectory(Path.GetDirectoryName(PagesPath));
			File.WriteAllText(PagesPath, stringBuilder.ToString());
			Dex.LoadBook();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}
}
