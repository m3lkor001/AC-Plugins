using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;

namespace MelkTank;

public static class LiveSettings
{
	public const string Pending = "PENDING=1";

	public const string Clean = "PENDING=0";

	private static Settings _s;

	private static Action _saveAll;

	private static Dictionary<string, string> _last = new Dictionary<string, string>();

	private static DateTime _next = DateTime.MinValue;

	private static string _path;

	private static string Path
	{
		get
		{
			if (_path != null)
			{
				return _path;
			}
			string text = "";
			try
			{
				text = Globals.Core.CharacterFilter.Name ?? "";
			}
			catch
			{
			}
			if (text.Length == 0)
			{
				return null;
			}
			StringBuilder stringBuilder = new StringBuilder();
			string text2 = text;
			foreach (char c in text2)
			{
				stringBuilder.Append(char.IsLetterOrDigit(c) ? c : '_');
			}
			return _path = Util.FullPath("MelkTank_Live_" + stringBuilder?.ToString() + ".xml");
		}
	}

	public static void Init(Settings s, Action saveAll)
	{
		_s = s;
		_saveAll = saveAll;
		_path = null;
		_last.Clear();
	}

	public static void Mirror(Settings s, XmlElement c)
	{
		if (_s == null || s == _s)
		{
			string path = Path;
			if (path != null && !FirstLine(path).StartsWith("PENDING=1", StringComparison.Ordinal))
			{
				Write(path, c);
			}
		}
	}

	private static void Write(string path, XmlElement c)
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>();
		foreach (XmlNode childNode in c.ChildNodes)
		{
			if (childNode is XmlElement)
			{
				dictionary[childNode.Name] = childNode.OuterXml;
			}
		}
		StringBuilder sb = new StringBuilder();
		sb.Append("PENDING=0").Append("   (set to PENDING=1 after editing - MelkTank applies the settings that changed, then sets it back to 0)\r\n");
		XmlWriterSettings settings = new XmlWriterSettings
		{
			Indent = true,
			OmitXmlDeclaration = true,
			NewLineChars = "\r\n"
		};
		using (StringWriter output = new StringWriter(sb))
		{
			using XmlWriter w = XmlWriter.Create(output, settings);
			c.WriteTo(w);
		}
		Util.Locked(path, () =>
		{
			File.WriteAllText(path, sb.ToString());
		});
		_last = dictionary;
	}

	private static string FirstLine(string path)
	{
		try
		{
			if (!File.Exists(path))
			{
				return "";
			}
			using FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
			using StreamReader streamReader = new StreamReader(stream);
			return (streamReader.ReadLine() ?? "").Trim();
		}
		catch
		{
			return "";
		}
	}

	public static void Tick()
	{
		if (_s == null || DateTime.Now < _next)
		{
			return;
		}
		_next = DateTime.Now.AddSeconds(2.0);
		string path = Path;
		if (path == null)
		{
			return;
		}
		if (!File.Exists(path) || _last.Count == 0)
		{
			if (_saveAll != null && _last.Count == 0)
			{
				_saveAll();
			}
		}
		else
		{
			if (!FirstLine(path).StartsWith("PENDING=1", StringComparison.Ordinal))
			{
				return;
			}
			string text = null;
			try
			{
				Util.Locked(path, () => text = File.ReadAllText(path));
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
				return;
			}
			int num = text.IndexOf('\n');
			string body = ((num >= 0) ? text.Substring(num + 1) : "");
			XmlDocument xmlDocument = new XmlDocument();
			try
			{
				xmlDocument.LoadXml(body);
			}
			catch (Exception ex2)
			{
				Exception ex3 = ex2;
				Exception ex4 = ex3;
				try
				{
					Util.Locked(path, () =>
					{
						File.WriteAllText(path, "PENDING=ERROR " + ex4.Message.Replace("\r", " ").Replace("\n", " ") + "\r\n" + body);
					});
				}
				catch
				{
				}
				Util.WriteToChat("MelkTank live settings: couldn't read " + System.IO.Path.GetFileName(path) + " (" + ex4.Message + ") - nothing changed.");
				return;
			}
			XmlElement documentElement = xmlDocument.DocumentElement;
			List<XmlElement> list = new List<XmlElement>();
			foreach (XmlNode childNode in documentElement.ChildNodes)
			{
				if (childNode is XmlElement xmlElement && (!_last.TryGetValue(xmlElement.Name, out var value) || !SameXml(value, xmlElement.OuterXml)))
				{
					list.Add(xmlElement);
				}
			}
			List<string> list2 = list.ConvertAll((XmlElement e) => e.Name);
			if (list.Count > 0)
			{
				try
				{
					_s.ApplyLive(list);
				}
				catch (Exception ex5)
				{
					Util.LogError(ex5);
					Util.WriteToChat("MelkTank live settings: error applying (" + ex5.Message + ").");
				}
			}
			try
			{
				Util.Locked(path, () =>
				{
					File.WriteAllText(path, "PENDING=0\r\n" + body);
				});
			}
			catch
			{
			}
			if (_saveAll != null)
			{
				_saveAll();
			}
			Util.WriteToChat((list.Count == 0) ? "MelkTank live settings: nothing changed." : ("MelkTank live settings applied: " + string.Join(", ", list2.ToArray()) + "."));
		}
	}

	private static bool SameXml(string a, string b)
	{
		try
		{
			XmlDocument xmlDocument = new XmlDocument();
			XmlDocument xmlDocument2 = new XmlDocument();
			xmlDocument.LoadXml(a);
			xmlDocument2.LoadXml(b);
			return xmlDocument.DocumentElement.OuterXml == xmlDocument2.DocumentElement.OuterXml;
		}
		catch
		{
			return a == b;
		}
	}
}
