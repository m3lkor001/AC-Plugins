using System;
using System.Collections.Generic;
using System.Windows.Forms;
#if !RETAIL
using ACGodot.Combat;
using ACGodot.DecalShim;
using ACGodot.Objects;
using ACGodot.Plugins;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using MelkTank.Loot;
using MelkTank.Pets;

namespace MelkTank;

public static class IdInfo
{
	private static Settings _s;

	private static readonly Dictionary<int, int[]> _hp = new Dictionary<int, int[]>();

	private static readonly Dictionary<int, DateTime> _hpAt = new Dictionary<int, DateTime>();

	private static int _pending;

	private static DateTime _pendingAt;

	private static int _lastId;

	private static DateTime _lastAt = DateTime.MinValue;

	public static void Init(Settings s)
	{
		_s = s;
	}

	private static bool On(WorldObject o)
	{
		if (_s == null || o == null || !_s.IdAnnounce)
		{
			return false;
		}
		if (o.ObjectClass == ObjectClass.Monster)
		{
			return _s.IdMobs;
		}
		if (o.ObjectClass == ObjectClass.Player)
		{
			return _s.IdPlayers;
		}
		return false;
	}

	public static void OnServerMessage(Message msg)
	{
		try
		{
			if (WeaponCompare.ReadHealthAny(msg, out var obj, out var cur, out var max))
			{
				_hp[obj] = new int[2] { cur, max };
				_hpAt[obj] = DateTime.Now;
				if (_hp.Count > 200)
				{
					_hp.Clear();
					_hpAt.Clear();
					_hp[obj] = new int[2] { cur, max };
					_hpAt[obj] = DateTime.Now;
				}
				if (_pending == obj && (DateTime.Now - _pendingAt).TotalSeconds < 5.0)
				{
					Say(obj);
				}
			}
		}
		catch
		{
		}
	}

	public static void OnIdentified(int id)
	{
		try
		{
			WorldObject o = Globals.Core.WorldFilter[id];
			if (!On(o) || Globals.Core.Actions.CurrentSelection != id)
			{
				return;
			}
			if (_hpAt.TryGetValue(id, out var value) && (DateTime.Now - value).TotalSeconds < 3.0)
			{
				Say(id);
				return;
			}
			_pending = id;
			_pendingAt = DateTime.Now;
			Timer t = new Timer
			{
				Interval = 600
			};
			t.Tick += (object? a, EventArgs b) =>
			{
				t.Stop();
				t.Dispose();
				if (_pending == id)
				{
					Say(id);
				}
			};
			t.Start();
		}
		catch
		{
		}
	}

	private static void Say(int id)
	{
		_pending = 0;
		if (id == _lastId && (DateTime.Now - _lastAt).TotalSeconds < 3.0)
		{
			return;
		}
		WorldObject worldObject = Globals.Core.WorldFilter[id];
		if (!On(worldObject))
		{
			return;
		}
		_lastId = id;
		_lastAt = DateTime.Now;
		List<string> list = new List<string> { worldObject.Name };
		int num = 0;
		try
		{
			num = worldObject.Values(LongValueKey.CreatureLevel, 0);
		}
		catch
		{
		}
		if (num > 0)
		{
			list.Add("Level " + num.ToString("N0"));
		}
		int num2 = LootMatcher.Long(worldObject, 307);
		int num3 = LootMatcher.Long(worldObject, 308);
		int num4 = LootMatcher.Long(worldObject, 314);
		bool flag = _hp.TryGetValue(id, out var value) && value[1] > 0;
#if !RETAIL
		if (!flag)
		{
			ACGodot.Plugins.PluginHost host = Bridge.Host;
			if (Bridge.ThingOf(id) is ObjectStreamer.Selectable s)
			{
				Fighter fighter = host?.FighterOf(s);
				if (fighter != null && fighter.MaxHealth > 0)
				{
					value = new int[2] { fighter.Health, fighter.MaxHealth };
					flag = true;
				}
			}
		}
#endif
		if (worldObject.ObjectClass == ObjectClass.Monster)
		{
			string text = (flag ? (value[0].ToString("N0") + "/" + value[1].ToString("N0") + " Health") : "");
			if (num2 > 0)
			{
				text = text + ((text.Length > 0) ? " " : "") + "D: " + num2;
			}
			if (num3 > 0)
			{
				text = text + ((text.Length > 0) ? " " : "") + "DR: " + num3;
			}
			if (text.Length > 0)
			{
				list.Add(text);
			}
			try
			{
				string baseName = Dex.BaseName(worldObject.Name, out var shiny, out var _);
				list.Add(Dex.IsCaught(baseName, shiny) ? "Essence Caught" : "No Essence Caught");
				list.Add(Dex.GivesQb(worldObject) ? "QB for Catch" : "No QB");
			}
			catch
			{
			}
		}
		else
		{
			list.Add("Enl " + LootMatcher.Long(worldObject, 390));
			list.Add("D: " + num2 + " CD: " + num4 + " DR: " + num3);
		}
		Util.WriteToChat(string.Join(" - ", list.ToArray()), 5, _s.IdChatWindow);
	}
}
