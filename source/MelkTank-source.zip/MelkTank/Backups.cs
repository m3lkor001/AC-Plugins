using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;

namespace MelkTank;

/// <summary>
/// Copies of the settings and data files into a Backup folder: one dated folder per snapshot
/// (Backup\yyyy-MM-dd_HHmm), made when something has changed since the last one, at most once an hour (every client
/// sharing the folder counts - the first one makes it), the newest 5 kept. To put one back: copy its files over.
/// </summary>
public static class Backups
{
    public const int Keep = 5;
    private static DateTime _nextTry = DateTime.MinValue;
    private static int _running;

    /// <summary>Checks now and then (call it as often as you like): a snapshot when it's due.</summary>
    public static void Tick(string root, Func<string, bool> want, Action<string> log = null, string dest = null)
    {
        if (DateTime.Now < _nextTry) return;
        _nextTry = DateTime.Now.AddMinutes(30);
        Run(root, want, log, dest);
    }

    /// <summary>A snapshot if one's due, on a worker thread (the copying never holds up the game).</summary>
    public static void Run(string root, Func<string, bool> want, Action<string> log = null, string dest = null)
    {
        if (Interlocked.Exchange(ref _running, 1) == 1) return;
        ThreadPool.QueueUserWorkItem(_ =>
        {
            try { Snapshot(root, want, log, dest); }
            catch (Exception ex) { log?.Invoke("backup failed: " + ex.Message); }
            finally { Interlocked.Exchange(ref _running, 0); }
        });
    }

    private static DateTime? Stamp(string dir)
    {
        DateTime t;
        return DateTime.TryParseExact(Path.GetFileName(dir), "yyyy-MM-dd_HHmm", CultureInfo.InvariantCulture, DateTimeStyles.None, out t) ? t : (DateTime?)null;
    }

    private static void Snapshot(string root, Func<string, bool> want, Action<string> log, string dest)
    {
        if (string.IsNullOrEmpty(root) || !Directory.Exists(root)) return;
        dest = dest ?? Path.Combine(root, "Backup");
        Directory.CreateDirectory(dest);
        string lk = Path.Combine(dest, ".lock");
        try
        {
            // (another client backing up the same folder right now: it's doing it)
            if (File.Exists(lk) && (DateTime.Now - File.GetLastWriteTime(lk)).TotalMinutes > 10) File.Delete(lk);
            using (new FileStream(lk, FileMode.CreateNew)) { }
        }
        catch { return; }
        try
        {
            List<string> snaps = Directory.GetDirectories(dest).Where(d => Stamp(d) != null).OrderBy(d => Stamp(d).Value).ToList();
            string last = snaps.Count > 0 ? snaps[snaps.Count - 1] : null;
            if (last != null && (DateTime.Now - Stamp(last).Value).TotalMinutes < 60) return;

            List<string> files = new List<string>();
            foreach (string f in Directory.GetFiles(root, "*", SearchOption.AllDirectories))
            {
                string rel = f.Substring(root.Length).TrimStart('/', '\\');
                if (f.StartsWith(dest)) continue;
                try { if (new FileInfo(f).Length > 50L * 1024 * 1024) continue; } catch { continue; }
                if (want(rel)) files.Add(rel);
            }
            if (files.Count == 0) return;
            if (last != null && !files.Any(rel => Differs(Path.Combine(root, rel), Path.Combine(last, rel)))) return;   // nothing new

            string to = Path.Combine(dest, DateTime.Now.ToString("yyyy-MM-dd_HHmm", CultureInfo.InvariantCulture));
            if (Directory.Exists(to)) return;
            int n = 0;
            foreach (string rel in files)
            {
                try
                {
                    string target = Path.Combine(to, rel);
                    Directory.CreateDirectory(Path.GetDirectoryName(target));
                    File.Copy(Path.Combine(root, rel), target, true);
                    n++;
                }
                catch { }
            }
            snaps.Add(to);
            while (snaps.Count > Keep) { try { Directory.Delete(snaps[0], true); } catch { } snaps.RemoveAt(0); }
            log?.Invoke("backed up " + n + " file(s) to " + to);
        }
        finally { try { File.Delete(lk); } catch { } }
    }

    private static bool Differs(string a, string b)
    {
        try
        {
            if (!File.Exists(b)) return true;
            FileInfo fa = new FileInfo(a), fb = new FileInfo(b);
            if (fa.Length != fb.Length) return true;
            byte[] x = File.ReadAllBytes(a), y = File.ReadAllBytes(b);
            for (int i = 0; i < x.Length; i++) if (x[i] != y[i]) return true;
            return false;
        }
        catch { return true; }
    }

    /// <summary>The usual "is it data?" for a plugin folder: settings, profiles, lists - not code, builds or logs.</summary>
    public static bool PluginData(string rel)
    {
        string name = Path.GetFileName(rel);
        string ext = Path.GetExtension(rel).ToLowerInvariant();
        string low = rel.Replace('\\', '/').ToLowerInvariant();
        if (ext != ".xml" && ext != ".txt" && ext != ".json" && ext != ".cfg" && ext != ".ini" && ext != ".csv" && ext != ".nav" && ext != ".met" && ext != ".utl") return false;
        foreach (string d in new[] { "bin/", "obj/", "retailbuild/", "retail/", "properties/", "_to_delete/", "snapshots/", "virindiviews/" })
            if (low.StartsWith(d) || low.Contains("/" + d)) return false;
        // (the Logs folder is logs - all but the Monster-Dex's pages, which the pets use)
        if ((low.StartsWith("logs/") || low.Contains("/logs/")) && !low.EndsWith("_pages.txt")) return false;
        string n = name.ToLowerInvariant();
        foreach (string bad in new[] { "debug", "errors", "memlog", "perflog", "perf_", "_dump", "dispatchlog", "orgwhy", "gearchanges", "spellwords", "ubprobe", "_tells_", "mainview.xml", ".csproj", "corpses", "_notes" })
            if (n.Contains(bad)) return false;
        return true;
    }
}
