using System;
using System.Collections.Generic;
using System.Globalization;
using System.Xml;

namespace MelkTank;

public static class Tuning
{
	public class Entry
	{
		public string Key;

		public string Category;

		public string Label;

		public string Unit;

		public string Tip;

		public double Default;

		public double Min;

		public double Max;

		public double Value;

		public double Step;

		public bool Whole;
	}

	public static readonly List<Entry> All;

	private static readonly Dictionary<string, Entry> ByKey;

	public static readonly string[] Categories;

	private static Entry E(string cat, string key, string label, double def, string unit, double min, double max, string tip, bool whole = true)
	{
		Entry entry = new Entry
		{
			Category = cat,
			Key = key,
			Label = label,
			Default = def,
			Value = def,
			Unit = unit,
			Min = min,
			Max = max,
			Tip = tip,
			Whole = whole
		};
		int num;
		double step;
		switch (unit)
		{
		default:
			num = 1;
			goto IL_008f;
		case "min":
			num = 1;
			goto IL_008f;
		case "m":
			step = 0.5;
			break;
		case "s":
			step = 0.5;
			break;
		case "ms":
			{
				step = 50.0;
				break;
			}
			IL_008f:
			step = num;
			break;
		}
		entry.Step = step;
		All.Add(entry);
		ByKey[key] = entry;
		return entry;
	}

	public static double V(string key)
	{
		Entry value;
		return ByKey.TryGetValue(key, out value) ? value.Value : 0.0;
	}

	public static TimeSpan Ms(string key)
	{
		return TimeSpan.FromMilliseconds(V(key));
	}

	public static TimeSpan Sec(string key)
	{
		return TimeSpan.FromSeconds(V(key));
	}

	static Tuning()
	{
		All = new List<Entry>();
		ByKey = new Dictionary<string, Entry>();
		Categories = new string[10] { "Combat", "Casting", "Monsters", "Healing", "Buffing", "Looting", "Items", "Nav - running", "Nav - routes", "Nav - follow" };
		E("Combat", "DebugMaxMB", "Debug log size cap", 5.0, "MB", 1.0, 100.0, "When a character's MelkTank_debug_[name].txt gets bigger than this, the older half is dropped.", whole: false);
		E("Combat", "FreeOldBuild", "Free the old build's data on a reload", 0.0, "(0/1)", 0.0, 1.0, "1: 10 s after a hot reload, the replaced build's lists and tables are emptied so their memory can be reclaimed (about 4 MB a reload).\n0 (default): left as they are - off since a crash a few minutes after the first build that did it (Nov 3).");
		E("Combat", "SlowIdleS", "Slow kills: left alone over", 25.0, "s", 5.0, 120.0, "Session > Packs lists a monster as 'left alone' when it's been in attack range this long with nothing cast on it (not even a DoT). Only the list - nothing it does changes.");
		E("Combat", "TickMs", "Main loop every", 150.0, "ms", 50.0, 1000.0, "How often MelkTank decides what to do next (cast, attack, loot, run). Lower reacts faster, uses more CPU.");
		E("Combat", "AttackCastGapMs", "Gap between attack casts", 600.0, "ms", 0.0, 3000.0, "Minimum time between two attack spells.");
		E("Combat", "PhysStaleS", "Melee / missile attack restart after", 3.5, "s", 1.0, 15.0, "No hit or miss line from your melee / missile attack for this long: it's started again.", whole: false);
		E("Combat", "EquipWaitMs", "Wait after equipping", 1500.0, "ms", 200.0, 5000.0, "After wielding a weapon / wand: wait this long for it to arrive before the next action.");
		E("Combat", "ModeWaitMs", "Wait after changing combat mode", 1200.0, "ms", 200.0, 5000.0, "After switching peace / melee / missile / magic mode.");
		E("Combat", "QuietAfterCastS", "Quiet time after a cast", 1.5, "s", 0.0, 10.0, "Stacking, mana top-up and salvaging wait this long after the last cast was sent.", whole: false);
		E("Combat", "EquipMinMs", "Swap: shortest equip wait", 500.0, "ms", 100.0, 5000.0, "With \"Go on when the swap is done\": never less than this after equipping / peace mode, even when the game shows it done sooner.");
		E("Combat", "EquipSettleMs", "Swap: after the game shows it wielded", 250.0, "ms", 0.0, 3000.0, "With \"Go on when the swap is done\": wait this much more once the wand shows in your hands (or peace mode shows).");
		E("Combat", "ModeMinMs", "Swap: shortest combat mode wait", 600.0, "ms", 100.0, 5000.0, "With \"Go on when the swap is done\": never less than this after changing combat mode.");
		E("Combat", "ModeSettleMs", "Swap: after the game shows the mode", 300.0, "ms", 0.0, 3000.0, "With \"Go on when the swap is done\": wait this much more once the new combat mode shows.");
		E("Combat", "PreEquipM", "Equip on the way: monsters within", 40.0, "m", 10.0, 100.0, "Following a route with \"Equip the next pack's wand on the way\": monsters this close decide which wand goes in hand while you walk up.", whole: false);
		E("Combat", "PetLeadM", "Summon before the fight: look ahead", 25.0, "m", 0.0, 80.0, "With \"summon before the fight only\": the pet summoner sees monsters this much further out than its range, so the pet is out before the fight starts.", whole: false);
		E("Combat", "VTankNavLockS", "VTank nav lock length", 3.0, "s", 1.0, 30.0, "How long each VTank / UB nav lock lasts (renewed while MelkTank needs it).", whole: false);
		E("Casting", "CastBusyMs", "A cast keeps you busy for", 1800.0, "ms", 500.0, 4000.0, "When the monster being cast at dies mid-cast, the next spell waits until this long after the cast was sent (sent sooner, the game drops it).", whole: false);
		E("Casting", "FractureCooldownS", "Between Nether Fracture releases", 0.0, "s", 0.0, 15.0, "Wait this long after one monster's release before releasing another. 0 = none (each monster has its own one release).", whole: false);
		E("Casting", "FractureHoldS", "Wait for a Nether Streak to land", 2.0, "s", 0.6, 5.0, "After a Nether Fracture release, nothing else is cast until its Nether Streak hits (or this long) - a cast sent while it's still going is dropped by the game.", whole: false);
		E("Casting", "StuckWaitS", "Stuck: start the pack over after", 90.0, "s", 30.0, 600.0, "Following a route and waiting on monsters in range (\"DoTs ticking\") with no kill for this long: primes are picked again, wands may release again and blocked monsters are tried again.", whole: false);
		E("Casting", "RePrimeUntouchedPct", "New prime if a pack member is still above", 95.0, "%", 50.0, 100.0, "One prime per wand: when that wand's primed monster dies and one of its pack is still above this much health (the spread / burst barely reached it), the nearest above the next value is primed afresh.", whole: false);
		E("Casting", "RePrimePickPct", "... the new prime: nearest above", 90.0, "%", 10.0, 100.0, "The new prime is the nearest of that wand's monsters still above this much health.", whole: false);
		E("Casting", "BusyStuckS", "Busy longer than this is stuck", 10.0, "s", 3.0, 60.0, "The game saying busy for longer than this counts as stuck (Decal's busy count never cleared): casting and attacking carry on anyway.", whole: false);
		E("Casting", "CastTimeoutS", "Wait for 'You cast' line", 4.0, "s", 1.0, 15.0, "A debuff / DoT with no 'You cast ...' line in this long counts as missed and is cast again.", whole: false);
		E("Casting", "LateConfirmS", "Late 'You cast' still counts for", 6.0, "s", 1.0, 20.0, "A 'You cast' line this long after a cast that timed out is still credited to it (lag).", whole: false);
		E("Casting", "MinCastMs", "Shortest cast", 900.0, "ms", 200.0, 3000.0, "A 'You cast' line sooner than this after sending can't be the new cast - it's an earlier one's.");
		E("Casting", "NoStartWaitMs", "Cast never started after", 2500.0, "ms", 500.0, 10000.0, "No incantation ('You say, ...') this long after sending: the game dropped it - send again.");
		E("Casting", "DebuffConfirmS", "Debuff confirm timeout", 5.0, "s", 1.0, 20.0, "How long a vuln / debuff waits for its 'You cast' line.", whole: false);
		E("Casting", "FailBackoffS", "After a resist / fizzle, retry in", 1.0, "s", 0.0, 10.0, "The same spell isn't cast on that monster again for this long.", whole: false);
		E("Monsters", "MovingDeferS", "Moving monster, debuff later by", 15.0, "s", 0.0, 60.0, "Two casts that never reached a monster that's running about: it goes after the others for this long.");
		E("Monsters", "BlockedForS", "Blocked monster left alone for", 60.0, "s", 5.0, 600.0, "A monster nothing reaches (hill, tree, no line of sight) is skipped until it moves, or for this long.");
		E("Monsters", "HomeMovedM", "'Gone home' - moved at least", 20.0, "m", 5.0, 100.0, "A debuffed monster this far from where the debuff landed ...", whole: false);
		E("Monsters", "HomeFurtherM", "'Gone home' - and further from you by", 15.0, "m", 5.0, 100.0, "... and this much further from you than it was then, ran home: its debuffs are forgotten and cast again.", whole: false);
		E("Monsters", "HomeDeferS", "Gone-home monster waits", 5.0, "s", 0.0, 60.0, "Then it's debuffed after the others for this long (while it's still running).");
		E("Monsters", "RuleIdRepeatS", "Re-appraise a monster after", 20.0, "s", 5.0, 300.0, "Monster rules that need species / max health appraise each monster at most this often.");
		E("Monsters", "RuleIdSpacingMs", "Between monster appraisals", 400.0, "ms", 100.0, 3000.0, "One appraisal at a time, this far apart.");
		E("Healing", "HealRetryMs", "Kit retry every", 500.0, "ms", 200.0, 3000.0, "While healing: use the kit again this often until it lands.");
		E("Healing", "KitLandS", "Kit answer wait", 3.0, "s", 1.0, 10.0, "After using a kit, wait this long for its chat line (healed / failed / busy).", whole: false);
		E("Healing", "HealNextTryS", "After a failed heal, next try in", 3.0, "s", 0.0, 15.0, "", whole: false);
		E("Buffing", "GemDetectMs", "Gem detection window", 3000.0, "ms", 500.0, 10000.0, "After using a gem, how long its chat line is waited for (to learn which spell it gave).");
		E("Buffing", "EquipSettleS", "Wait after a wand / gear swap", 1.5, "s", 0.3, 5.0, "Before casting with the wand just equipped.", whole: false);
		E("Buffing", "GemAfterCastS", "Gem after the last cast", 2.0, "s", 0.0, 10.0, "Before using a gem, this long after the last buff cast.", whole: false);
		E("Buffing", "CastRetryS", "Buff cast retry after", 2.0, "s", 0.5, 10.0, "No sign the buff landed in this long: cast it again.", whole: false);
		E("Buffing", "RestoreWaitS", "Swap back after", 2.0, "s", 0.5, 10.0, "After the last buff, wait this long before re-equipping your weapon.", whole: false);
		E("Buffing", "GemSharedCdMin", "Shared-cooldown gems - skip others for", 10.0, "min", 0.0, 180.0, "Gems that share a cooldown (Asheron's Benediction and Lesser Benediction, the Medals of Vigor...): after one is used, the others in its group are skipped this long. Only one per group is used each time.");
		E("Buffing", "GemRecheckS", "Gem rebuff check every", 30.0, "s", 5.0, 300.0, "How often spell gems' remaining times are checked.");
		E("Looting", "LootStepMs", "Looter step", 150.0, "ms", 50.0, 1000.0, "How often the looter moves on to its next step.");
		E("Looting", "CorpseSettleMs", "Corpse open - wait for contents", 600.0, "ms", 100.0, 3000.0, "After a corpse opens, wait this long for its items to arrive.");
		E("Looting", "CorpseBusyRetryMs", "Corpse 'too busy' - try again in", 700.0, "ms", 100.0, 3000.0, "");
		E("Looting", "ItemWaitS", "Item move wait", 3.0, "s", 1.0, 10.0, "How long a move into your pack is waited for.", whole: false);
		E("Looting", "IdWaitS", "Item ID wait", 4.0, "s", 1.0, 10.0, "How long an item's ID is waited for before asking again. The server is slower to answer while you're casting or fighting.", whole: false);
		E("Looting", "IdTries", "Item ID tries", 3.0, "", 1.0, 5.0, "How many times an item's ID is asked for before it's judged on what's known without it.");
		E("Looting", "AfterCorpseS", "Between corpses", 1.0, "s", 0.0, 5.0, "After closing a corpse, before the next one.", whole: false);
		E("Looting", "PackFullPauseS", "Pack full - wait", 60.0, "s", 10.0, 600.0, "Looting stops this long when your pack is full.");
		E("Looting", "CorpseMemoryMin", "Remember looted corpses for", 10.0, "min", 1.0, 60.0, "");
		E("Looting", "RotDistM", "Corpse rotting away - within", 80.0, "m", 10.0, 300.0, "A corpse leaving the world closer than this (and not while portaling) rotted: it's forgotten.");
		E("Items", "ManaSweepS", "Gear mana check every", 30.0, "s", 5.0, 300.0, "Each worn item is appraised this often to read its mana.");
		E("Items", "ManaIdMs", "Between gear appraisals", 300.0, "ms", 100.0, 3000.0, "");
		E("Items", "ManaCooldownS", "After using a mana stone", 10.0, "s", 2.0, 60.0, "Nothing else for this long (the stone's animation), then the gear is read again.");
		E("Items", "StackLookMs", "Stacking - look every", 500.0, "ms", 100.0, 5000.0, "");
		E("Items", "StackMoveMs", "Stacking - after a move", 900.0, "ms", 100.0, 5000.0, "One move at a time, this far apart.");
		E("Items", "SalvOpenMs", "Salvage - ust open wait", 1200.0, "ms", 300.0, 5000.0, "");
		E("Items", "SalvAddMs", "Salvage - between items", 200.0, "ms", 50.0, 2000.0, "");
		E("Items", "SalvDoMs", "Salvage - salvaging wait", 2500.0, "ms", 500.0, 10000.0, "");
		E("Items", "SalvCloseMs", "Salvage - close wait", 800.0, "ms", 100.0, 5000.0, "");
		E("Items", "AreaCheckS", "Area auto-switch check every", 2.0, "s", 1.0, 30.0, "", whole: false);
		E("Nav - running", "PulseRangeM", "Step in bursts within", 2.0, "m", 0.0, 10.0, "Returning to a spot: inside this distance it walks in short bursts instead of running (no overshoot).", whole: false);
		E("Nav - running", "PulseOffMs", "Burst - pause between", 500.0, "ms", 100.0, 2000.0, "");
		E("Nav - running", "PulseBaseMs", "Burst - length", 150.0, "ms", 50.0, 1000.0, "A burst lasts this ...");
		E("Nav - running", "PulsePerMMs", "Burst - extra per metre", 150.0, "ms", 0.0, 1000.0, "... plus this for each metre still to go.");
		E("Nav - running", "FaceEveryMs", "Turn command every", 300.0, "ms", 50.0, 2000.0, "While turning to face the next spot.");
		E("Nav - running", "FacingOkDeg", "Facing it within", 8.0, "deg", 1.0, 45.0, "Start running once facing the spot to within this many degrees ...");
		E("Nav - running", "TurnMaxS", "... or after turning for", 2.0, "s", 0.5, 10.0, "", whole: false);
		E("Nav - running", "SteerDeg", "Steer when off by", 8.0, "deg", 1.0, 45.0, "While running: correct course when more than this many degrees off.");
		E("Nav - running", "SteerEveryMs", "Steer at most every", 1000.0, "ms", 200.0, 5000.0, "");
		E("Nav - running", "TurnSettleMs", "After a correction, restart run in", 300.0, "ms", 0.0, 2000.0, "A course correction stops the autorun; it's switched off and on again after this.");
		E("Nav - running", "AutorunGapMs", "Autorun off-on gap", 100.0, "ms", 0.0, 1000.0, "");
		E("Nav - running", "NotMovingMs", "Not moving for", 600.0, "ms", 200.0, 5000.0, "Running but getting no closer for this long: the run is restarted.");
		E("Nav - running", "StuckS", "Stuck after no progress for", 5.0, "s", 1.0, 30.0, "", whole: false);
		E("Nav - running", "StepStuckS", "Stuck while stepping after", 8.0, "s", 1.0, 30.0, "", whole: false);
		E("Nav - running", "MaxRunS", "Give up a run after", 40.0, "s", 5.0, 300.0, "");
		E("Nav - running", "StuckPauseS", "Stuck - try again in", 30.0, "s", 1.0, 300.0, "");
		E("Nav - routes", "UseRangeM", "Use step - look within", 50.0, "m", 5.0, 500.0, "A route's portal / NPC is found by name within this distance of where it was when added.");
		E("Nav - routes", "UseFindS", "Use step - look for it for", 10.0, "s", 1.0, 60.0, "");
		E("Nav - routes", "UseNpcS", "Use step - NPC / object wait", 4.0, "s", 1.0, 30.0, "", whole: false);
		E("Nav - routes", "UsePortalS", "Use step - portal wait", 20.0, "s", 3.0, 120.0, "");
		E("Nav - routes", "UseFaceMs", "Use step - face a portal among others first", 800.0, "ms", 0.0, 3000.0, "Auto travel: with other portals within 10 m, turn to face the one to use (standing still) this long before using it.");
		E("Items - vendor", "VendorOpenS", "Vendor - wait for the shop to open", 5.0, "s", 1.0, 30.0, "A vendor visit uses the NPC and waits this long for its shop to open before trying again (3 tries).", whole: false);
		E("Items - vendor", "VendorWaitS", "Vendor - wait for a sale / purchase", 6.0, "s", 1.0, 30.0, "Most a vendor visit waits for the server to finish a sale or purchase - it goes on as soon as the items arrive or leave.", whole: false);
		E("Nav - routes", "AfterPortalS", "After a portal", 3.0, "s", 0.0, 30.0, "Pause after arriving before the next step.", whole: false);
		E("Nav - routes", "ItemCheckMs", "Item check every", 500.0, "ms", 100.0, 5000.0, "");
		E("Nav - routes", "ChatKeepS", "Chat waits remember lines for", 60.0, "s", 5.0, 600.0, "");
		E("Nav - follow", "CrumbStepM", "Exact path - point every", 1.0, "m", 0.3, 5.0, "", whole: false);
		E("Nav - follow", "CrumbArriveM", "Exact path - point reached within", 1.2, "m", 0.3, 5.0, "", whole: false);
		E("Nav - follow", "CrumbJumpM", "Trail reset on a jump over", 30.0, "m", 5.0, 200.0, "The leader moved this far at once (portal / recall): the old trail is dropped.", whole: false);
	}

	public static void Load(XmlNode c)
	{
		foreach (Entry item in All)
		{
			item.Value = item.Default;
		}
		if (c == null)
		{
			return;
		}
		foreach (XmlNode item2 in c.SelectNodes("Tuning/T"))
		{
			if (item2 is XmlElement xmlElement && ByKey.TryGetValue(xmlElement.GetAttribute("k"), out var value) && double.TryParse(xmlElement.GetAttribute("v"), NumberStyles.Float, CultureInfo.InvariantCulture, out var result))
			{
				value.Value = Math.Max(value.Min, Math.Min(value.Max, result));
			}
		}
	}

	public static void Save(XmlDocument doc, XmlNode c)
	{
		XmlElement xmlElement = doc.CreateElement("Tuning");
		foreach (Entry item in All)
		{
			if (item.Value != item.Default)
			{
				XmlElement xmlElement2 = doc.CreateElement("T");
				xmlElement2.SetAttribute("k", item.Key);
				xmlElement2.SetAttribute("v", item.Value.ToString("R", CultureInfo.InvariantCulture));
				xmlElement.AppendChild(xmlElement2);
			}
		}
		c.AppendChild(xmlElement);
	}
}
