using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
#if !RETAIL
using ACGodot.DecalShim;
using ACGodot.Plugins;
using ACGodot.UI;
#endif
#if !RETAIL
using AcClient;
#else
using SmartBox = AcClient.SmartBox;
using ACCmdInterp = AcClient.ACCmdInterp;
using CommandInterpreter = AcClient.CommandInterpreter;
using CommandListElement = AcClient.CommandListElement;
using CPhysicsObj = AcClient.CPhysicsObj;
using Position = AcClient.Position;
using CTransition = AcClient.CTransition;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
#if !RETAIL
using Godot;
#endif
using ImGuiNET;
using MelkTank.Loot;
using MelkTank.Metas;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public partial class Nav
{
	private static void TravelState(string s)
	{
		try
		{
			AppDomain.CurrentDomain.SetData("MelkTank.Travel", s);
		}
		catch
		{
		}
	}

	private bool _autorunMine;

	private void AutorunOn()
	{
		_autorunOnAt = DateTime.Now;
		_autorunMine = true;
		try
		{
			Globals.Core.Actions.SetAutorun(on: true);
		}
		catch
		{
		}
	}

	public void TravelCommand(string rest)
	{
		string text = (rest ?? "").Trim();
		if (text.Equals("stop", StringComparison.OrdinalIgnoreCase))
		{
			TravelStop("stopped from MelksQB", finished: false);
			return;
		}
		if (text.Equals("hide", StringComparison.OrdinalIgnoreCase))
		{
			_travelPreview = null;
			return;
		}
		if (text.StartsWith("show ", StringComparison.OrdinalIgnoreCase))
		{
			NavRoute navRoute = LoadRouteFile(text.Substring(5).Trim().Trim('"'));
			if (navRoute == null || navRoute.Steps.Count == 0)
			{
				Util.WriteToChat("Auto travel: couldn't read the route to show.");
				return;
			}
			navRoute.Name = "[travel preview] " + navRoute.Name;
			_travelPreview = navRoute;
			return;
		}
		if (text.StartsWith("walls", StringComparison.OrdinalIgnoreCase))
		{
			string text2 = text.Substring(5).Trim().ToLowerInvariant();
			if (text2 == "on")
			{
				WallFile("ok");
				_wallState = 1;
				_wallProven = false;
				Util.WriteToChat("Auto travel: the wall check is on.");
			}
			else if (text2 == "off")
			{
				WallFile("off (switched off by hand)");
				_wallState = 2;
				Util.WriteToChat("Auto travel: the wall check is off.");
			}
			else
			{
				Util.WriteToChat("Auto travel: the wall check is " + (WallCheckOn() ? "on" : "off") + ". /mtank travel walls on | off");
			}
			return;
		}
		bool flag = true;
		if (text.StartsWith("fight ", StringComparison.OrdinalIgnoreCase))
		{
			text = text.Substring(6).Trim();
		}
		else if (text.StartsWith("nofight ", StringComparison.OrdinalIgnoreCase))
		{
			flag = false;
			text = text.Substring(8).Trim();
		}
		if (MetaRunning)
		{
			TravelRefused("a meta is running - stop it first");
			return;
		}
		NavRoute navRoute2 = LoadRouteFile(text.Trim('"'));
		if (navRoute2 == null || navRoute2.Steps.Count == 0)
		{
			TravelRefused("couldn't read the route");
			return;
		}
		navRoute2.Name = "[travel] " + navRoute2.Name;
		navRoute2.Mode = 0;
		navRoute2.RestartIfFar = false;
		navRoute2.RestartIfStuck = false;
		bool flag2 = _travelRoute != null;
		if (!flag2)
		{
			_tWasEnabled = _s.NavEnabled;
			_tWasMode = _s.NavMode;
			_tWasRoute = _s.NavRouteSelected ?? "";
			_tWasMaster = _s.MasterEnabled;
			_tWasCombat = _s.CombatEnabled;
			_s.TravelKeep = true;
			_s.TKMaster = _tWasMaster;
			_s.TKCombat = _tWasCombat;
			_s.TKNav = _tWasEnabled;
			_s.TKNavMode = _tWasMode;
			_s.TKNavRoute = _tWasRoute;
			_tCombatOff = false;
		}
		_travelRoute = navRoute2;
		_travelPreview = null;
		if (!flag && !_tCombatOff)
		{
			_tCombatOff = true;
			_s.CombatEnabled = false;
		}
		_s.MasterEnabled = true;
		_s.NavEnabled = true;
		_s.NavMode = 1;
		_s.NavRouteSelected = navRoute2.Name;
		_tDetour = null;
		_tSide = 0;
		_tDetourFor = -1;
		_tStep = -1;
		_tStepSecs = 0.0;
		_tFlagSeen = false;
		_tFlagOff = 0;
		Stop();
		_rName = "";
		RouteReset();
		_tStartedAt = (_tLastTurn = DateTime.Now);
		TravelState("running|" + DateTime.UtcNow.Ticks);
		L("travel: " + navRoute2.Steps.Count + " steps, " + (flag ? "fighting on the way" : "combat off for the trip") + (flag2 ? " (route updated)" : ""));
		if (!flag2)
		{
			Util.WriteToChat("Auto travel: " + navRoute2.Steps.Count + " steps" + (flag ? " (stopping to fight)" : " (combat off for the trip)") + " - move yourself to stop it.");
		}
	}

	private void TravelRefused(string why)
	{
		if (_travelRoute != null)
		{
			TravelStop(why, finished: false);
			return;
		}
		TravelState("stopped|" + DateTime.UtcNow.Ticks + "|" + why);
		Util.WriteToChat("Auto travel stopped - " + why + ".");
	}

	public void TravelStop(string why, bool finished)
	{
		if (_travelRoute != null)
		{
			string name = _travelRoute.Name;
			_travelRoute = null;
			_tDetour = null;
			Stop();
			if (_s.NavEnabled && _s.NavMode == 1 && string.Equals(_s.NavRouteSelected, name, StringComparison.Ordinal))
			{
				_s.NavEnabled = _tWasEnabled;
				_s.NavMode = _tWasMode;
				_s.NavRouteSelected = _tWasRoute;
			}
			if (_s.MasterEnabled)
			{
				_s.MasterEnabled = _tWasMaster;
			}
			if (_tCombatOff && !_s.CombatEnabled)
			{
				_s.CombatEnabled = _tWasCombat;
			}
			_tCombatOff = false;
			_s.TravelKeep = false;
			_rName = "";
			RouteReset();
			TravelState((finished ? "finished|" : "stopped|") + DateTime.UtcNow.Ticks + (finished ? "" : ("|" + why)));
			L("travel: " + (finished ? "finished" : ("stopped - " + why)));
			Util.WriteToChat(finished ? "Auto travel finished." : ("Auto travel stopped - " + why + "."));
		}
	}

	private void TravelTick()
	{
		if (_travelRoute == null)
		{
			return;
		}
		DateTime now = DateTime.Now;
		double num = Math.Min(0.5, Math.Max(0.0, (now - _tTickAt).TotalSeconds));
		_tTickAt = now;
		if (!_s.MasterEnabled)
		{
			TravelStop("MelkTank was switched off", finished: false);
			return;
		}
		if (!string.Equals(_s.NavRouteSelected, _travelRoute.Name, StringComparison.Ordinal) || !_s.NavEnabled || _s.NavMode != 1)
		{
			L("travel: nav setting changed under it - NavEnabled " + _s.NavEnabled + ", NavMode " + _s.NavMode + ", route '" + _s.NavRouteSelected + "' (travel's '" + _travelRoute.Name + "'), meta " + MetaRunning);
			TravelStop("another route / nav setting was picked", finished: false);
			return;
		}
		if (_rDone && string.Equals(_rName, _travelRoute.Name, StringComparison.Ordinal))
		{
			TravelStop("", finished: true);
			return;
		}
		bool flag = (now - _rTickAt).TotalSeconds < 0.5;
		if (flag || _inPortal)
		{
			_tLastTurn = now;
		}
		if ((now - _tLastTurn).TotalMinutes > 5.0)
		{
			TravelStop("the route hasn't had a turn for 5 minutes (fighting / busy / paused)", finished: false);
			return;
		}
		int num2 = _rIdx * 1000 + _rSub;
		if (num2 != _tStep)
		{
			_tStep = num2;
			_tStepSecs = 0.0;
			_tStuckBase = StuckEvents;
		}
		else if (flag && !_inPortal)
		{
			_tStepSecs += num;
		}
		if (StuckEvents - _tStuckBase >= 3)
		{
			TravelStop("couldn't get past step " + (_rIdx + 1) + " (blocked 3 times)", finished: false);
			return;
		}
		if (_tStepSecs > (double)((_tSide != 0) ? 180 : 90))
		{
			TravelStop("step " + (_rIdx + 1) + " took over " + ((_tSide != 0) ? "3 minutes, going round a wall" : "90 s") + " (" + Status + ")", finished: false);
			return;
		}
		int num3 = ((_running && _moving && !_pulsing && _restartStage == 0 && (now - _lastReturnTick).TotalSeconds < 0.3) ? AutorunFlag() : (-1));
		if (num3 != 1 && (now - _doorUseAt).TotalSeconds < 4.0)
		{
			if (!_doorRerun && num3 == 0 && (now - _doorUseAt).TotalSeconds > 1.2)
			{
				_doorRerun = true;
				AutorunOn();
				L("travel: door used - running on");
			}
			num3 = -1;
			_tFlagOff = 0;
		}
		if (num3 == 1)
		{
			_tFlagSeen = true;
			_tFlagOff = 0;
		}
		else if (num3 == 0 && _tFlagSeen && (now - _autorunOnAt).TotalSeconds > 1.5 && (now - _tStartedAt).TotalSeconds > 3.0)
		{
			if (_tFlagOff == 0)
			{
				_tFlagOff = 1;
				_tFlagAt = now;
			}
			else if ((now - _tFlagAt).TotalSeconds > 0.25)
			{
				TravelStop("you moved", finished: false);
				return;
			}
		}
		else
		{
			_tFlagOff = 0;
		}
		if ((now - _tStartedAt).TotalSeconds > 2.0 && (now - _doorUseAt).TotalSeconds > 4.0 && PlayerKeyHeld(_turning != 0))
		{
			if (_tKeyAt == DateTime.MinValue)
			{
				_tKeyAt = now;
			}
			else if ((now - _tKeyAt).TotalSeconds > 0.2)
			{
				TravelStop("you moved", finished: false);
			}
		}
		else
		{
			_tKeyAt = DateTime.MinValue;
		}
	}

#if RETAIL
	private unsafe static bool PlayerKeyHeld(bool navTurning)
	{
		try
		{
			SmartBox** smartbox = SmartBox.smartbox;
			if (smartbox == null || *smartbox == null || (*smartbox)->cmdinterp == null)
			{
				return false;
			}
			CommandInterpreter* cmdinterp = (*smartbox)->cmdinterp;
			int num = 0;
			CommandListElement* ptr = (cmdinterp->SubstateList).head;
			while (ptr != null && num < 16)
			{
				if (ptr->command == 1157627910)
				{
					return true;
				}
				ptr = ptr->next;
				num++;
			}
			if ((cmdinterp->SidestepList).head != null)
			{
				return true;
			}
			if (!navTurning && (cmdinterp->TurnList).head != null)
			{
				return true;
			}
			return false;
		}
		catch
		{
			return false;
		}
	}
#else
	private static bool PlayerKeyHeld(bool navTurning)
	{
		try
		{
			if (ImGuiLayer.WantsKeyboard)
			{
				return false;
			}
			if (Input.IsKeyPressed(Key.S) || Input.IsKeyPressed(Key.Q) || Input.IsKeyPressed(Key.E))
			{
				return true;
			}
			return !navTurning && (Input.IsKeyPressed(Key.A) || Input.IsKeyPressed(Key.D));
		}
		catch
		{
			return false;
		}
	}
#endif

	private bool TravelPointOk(NavSpot to)
	{
		double num = DistanceTo(to);
		if (num < 0.0 || num <= 300.0)
		{
			return true;
		}
		TravelStop("the next point is " + num.ToString("0") + " m away - not where the route expected to be", finished: false);
		return false;
	}

#if RETAIL
	private unsafe static int AutorunFlag()
	{
		try
		{
			SmartBox** smartbox = SmartBox.smartbox;
			if (smartbox == null || *smartbox == null || (*smartbox)->cmdinterp == null)
			{
				return -1;
			}
			return ((*smartbox)->cmdinterp->auto_run != 0) ? 1 : 0;
		}
		catch
		{
			return -1;
		}
	}
#else
	private static int AutorunFlag()
	{
		ACGodot.Plugins.PluginHost host = Bridge.Host;
		return (host?.Player == null) ? (-1) : (host.AutoRun ? 1 : 0);
	}
#endif

	private static void WallFile(string s)
	{
		try
		{
			File.WriteAllText(WallPath, s);
		}
		catch
		{
		}
	}

	private static bool WallCheckOn()
	{
		if (_wallState == 0)
		{
			_wallState = 1;
			try
			{
				string text = (File.Exists(WallPath) ? File.ReadAllText(WallPath).Trim() : "");
				if (text.StartsWith("testing", StringComparison.OrdinalIgnoreCase))
				{
					_wallState = 2;
					WallFile("off (the game closed during a wall check, " + DateTime.Now.ToString("yyyy-MM-dd HH:mm") + ")");
					Util.WriteToChat("Auto travel: the game closed during a wall check last time - the wall check is off now (/mtank travel walls on to try it again).");
				}
				else if (text.StartsWith("off", StringComparison.OrdinalIgnoreCase))
				{
					_wallState = 2;
				}
			}
			catch
			{
			}
		}
		return _wallState == 1;
	}

	private NavSpot TravelDetour(NavSpot to)
	{
		DateTime now = DateTime.Now;
		double num = DistanceTo(to);
		if (_tDetourFor != _rIdx)
		{
			_tDetourFor = _rIdx;
			_tSide = 0;
			_tDetour = null;
			_tFlipped = false;
			_tHits.Clear();
		}
		if (_tDetour != null)
		{
			if (!((now - _tDetourAt).TotalSeconds > 5.0) && !(DistanceTo(_tDetour) < 1.5))
			{
				return _tDetour;
			}
			_tDetour = null;
		}
		if (!WallCheckOn())
		{
			return to;
		}
		if (_tSide == 0 && (now - _tProbeAt).TotalMilliseconds < 400.0)
		{
			return to;
		}
		_tProbeAt = now;
		if (!MyPos(out var ns, out var ew, out var z))
		{
			return to;
		}
		if (num < 3.0)
		{
			_tSide = 0;
			return to;
		}
		double num2 = Math.Min(12.0, num);
		double num3 = (_pBearing = BearingTo(to));
		_pSlope = ((to.Z != 0.0 && num > 1.0) ? Math.Max(-1.5, Math.Min(1.5, (to.Z - z) / num)) : double.NaN);
		if (now < _tPushUntil)
		{
			return to;
		}
		double num4 = SafeProbe(num3, num2);
		if (num4 < 0.0)
		{
			return to;
		}
		bool flag = num4 > 0.8 || num4 * num2 >= num - 1.0;
		if (_tSide != 0)
		{
			bool flag2 = _tHits.Count > 1;
			if (flag && (!flag2 || num < _tHitD - 1.0))
			{
				L("travel: past the wall (" + _tFollowM.ToString("0") + " m round it)");
				_tSide = 0;
				return to;
			}
			if (_tFollowM > 220.0 || (now - _tFollowAt).TotalSeconds > 75.0)
			{
				if (_tFlipped)
				{
					L("travel: no way round the wall found");
					_tSide = 0;
					return to;
				}
				_tFlipped = true;
				_tSide = -_tSide;
				_tFollowM = 0.0;
				_tFollowAt = now;
				_tHitD = num;
				_tHits.Clear();
				L("travel: no way round on that side - trying the other");
			}
		}
		else
		{
			if (flag)
			{
				return to;
			}
			if (now < _tDoorWait)
			{
				return to;
			}
			if (_tLastDoor != 0 && (now - _tLastDoorAt).TotalSeconds < 8.0)
			{
				if (DoorShut(_tLastDoor) != false)
				{
					if (!_tLastDoorAgain && (now - _tLastDoorAt).TotalSeconds > 4.0)
					{
						_tLastDoorAgain = true;
						try
						{
							Globals.Core.Actions.UseItem(_tLastDoor, 0);
						}
						catch
						{
						}
						_doorUseAt = now;
						_doorRerun = false;
						L("travel: the door's still shut - using it again");
					}
					Status = "Waiting for the door to open";
					_tDoorWait = now.AddMilliseconds(300.0);
					return to;
				}
				_tLastDoor = 0;
			}
			int num5 = DoorAhead(ns, ew, num3);
			bool? flag3 = ((num5 != 0) ? DoorShut(num5) : new bool?(false));
			if (num5 != 0 && !flag3.HasValue)
			{
				_tDoorWait = now.AddMilliseconds(250.0);
				return to;
			}
			if (num5 != 0 && flag3 == false)
			{
				_tDoorUsed[num5] = now;
				L("travel: the door ahead is open already - not using it");
				num5 = 0;
			}
			if (num5 != 0)
			{
				try
				{
					Globals.Core.Actions.UseItem(num5, 0);
				}
				catch
				{
				}
				_doorUseAt = now;
				_doorRerun = false;
				_tDoorUsed[num5] = now;
				_tDoorWait = now.AddSeconds(1.5);
				_tLastDoor = num5;
				_tLastDoorAt = now;
				_tLastDoorAgain = false;
				L("travel: a door in the way - opening it");
				return to;
			}
			int num6 = 0;
			for (int i = 1; i <= 12; i++)
			{
				if (num6 != 0)
				{
					break;
				}
				if (SafeProbe(num3 + (double)i * 15.0, 6.0) >= 0.6)
				{
					num6 = 1;
				}
				else if (SafeProbe(num3 - (double)i * 15.0, 6.0) >= 0.6)
				{
					num6 = -1;
				}
			}
			if (num6 == 0)
			{
				num6 = 1;
			}
			_tSide = num6;
			_tFollowM = 0.0;
			_tFollowAt = now;
			_tHitD = num;
			_tHeading = num3;
			_tTurned = 0.0;
			bool flag4 = false;
			foreach (double[] tHit in _tHits)
			{
				if (Math.Abs(tHit[0] - ns) * 240.0 < 4.0 && Math.Abs(tHit[1] - ew) * 240.0 < 4.0)
				{
					flag4 = true;
				}
			}
			_tHits.Add(new double[2] { ns, ew });
			L("travel: wall ahead (" + (num4 * 100.0).ToString("0") + "% clear) - following it on the " + ((num6 > 0) ? "right" : "left") + (flag4 ? " (met it here before)" : ""));
		}
		double num7 = double.NaN;
		double num8 = 0.0;
		for (int j = 0; j <= 24; j++)
		{
			double num9 = _tHeading - (double)(_tSide * 60) + (double)_tSide * 15.0 * (double)j;
			double num10 = SafeProbe(num9, 6.0);
			if (num10 < 0.0)
			{
				return to;
			}
			if (num10 >= 0.55)
			{
				num7 = num9;
				num8 = num10;
				break;
			}
		}
		if (double.IsNaN(num7))
		{
			L("travel: boxed in - nowhere clear to go");
			_tSide = 0;
			return to;
		}
		double num11 = ((num7 - _tHeading) % 360.0 + 540.0) % 360.0 - 180.0;
		_tTurned += num11;
		if (Math.Abs(_tTurned) >= 450.0 && num >= _tHitD - 2.0)
		{
			L("travel: going round in circles - straight on for a few seconds");
			_tSide = 0;
			_tTurned = 0.0;
			_tPushUntil = now.AddSeconds(4.0);
			return to;
		}
		_tHeading = num7;
		double num12 = Math.Max(2.0, Math.Min(4.0, num8 * 6.0 - 1.2));
		double num13 = num7 * Math.PI / 180.0;
		_tDetour = new NavSpot
		{
			Name = to.Name + " (round the wall)",
			NS = ns + Math.Cos(num13) * num12 / 240.0,
			EW = ew + Math.Sin(num13) * num12 / 240.0,
			Z = z,
			Heading = -1.0
		};
		_tDetourAt = now;
		_tFollowM += num12;
		_retarget = true;
		return _tDetour;
	}

#if RETAIL
	private unsafe bool? DoorShut(int id)
	{
		try
		{
			int physicsObjectPtr = Globals.Core.Actions.Underlying.GetPhysicsObjectPtr(id);
			if (physicsObjectPtr != 0)
			{
				return (((CPhysicsObj*)physicsObjectPtr)->state & 4) == 0;
			}
		}
		catch
		{
		}
		DateTime now = DateTime.Now;
		if (!_doorAsked.TryGetValue(id, out var value) || (now - value).TotalSeconds > 4.0)
		{
			_doorAsked[id] = now;
			try
			{
				Util.RequestId(id);
			}
			catch
			{
				return true;
			}
			return null;
		}
		if ((now - value).TotalSeconds < 0.8)
		{
			return null;
		}
		try
		{
			WorldObject worldObject = Globals.Core.WorldFilter[id];
			if (worldObject == null || !worldObject.HasIdData)
			{
				return true;
			}
			return !worldObject.Values(BoolValueKey.Open, defaultValue: false);
		}
		catch
		{
			return true;
		}
	}
#else
	private bool? DoorShut(int id)
	{
		try
		{
			int physicsObjectPtr = Globals.Core.Actions.Underlying.GetPhysicsObjectPtr(id);
		}
		catch
		{
		}
		DateTime now = DateTime.Now;
		if (!_doorAsked.TryGetValue(id, out var value) || (now - value).TotalSeconds > 4.0)
		{
			_doorAsked[id] = now;
			try
			{
				Util.RequestId(id);
			}
			catch
			{
				return true;
			}
			return null;
		}
		if ((now - value).TotalSeconds < 0.8)
		{
			return null;
		}
		try
		{
			WorldObject worldObject = Globals.Core.WorldFilter[id];
			if (worldObject == null || !worldObject.HasIdData)
			{
				return true;
			}
			return !worldObject.Values(BoolValueKey.Open, false);
		}
		catch
		{
			return true;
		}
	}
#endif

	private static bool IsDoor(WorldObject o)
	{
		if (o == null)
		{
			return false;
		}
		if (o.ObjectClass == ObjectClass.Door)
		{
			return true;
		}
		string text = o.Name ?? "";
		return text.IndexOf("Portcullis", StringComparison.OrdinalIgnoreCase) >= 0 || text.EndsWith(" Gate", StringComparison.OrdinalIgnoreCase) || text.Equals("Gate", StringComparison.OrdinalIgnoreCase);
	}

	private int DoorBetween(WorldObject target)
	{
		try
		{
			CoordsObject coordsObject = Globals.Core.WorldFilter[Globals.Core.CharacterFilter.Id].Coordinates();
			CoordsObject coordsObject2 = target.Coordinates();
			double num = (coordsObject2.EastWest - coordsObject.EastWest) * 240.0;
			double num2 = (coordsObject2.NorthSouth - coordsObject.NorthSouth) * 240.0;
			double num3 = num * num + num2 * num2;
			if (num3 < 0.01)
			{
				return 0;
			}
			int result = 0;
			double num4 = double.MaxValue;
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				if (!IsDoor(item) || (_tDoorUsed.TryGetValue(item.Id, out var value) && (DateTime.Now - value).TotalSeconds < 3.0))
				{
					continue;
				}
				CoordsObject coordsObject3 = item.Coordinates();
				double num5 = (coordsObject3.EastWest - coordsObject.EastWest) * 240.0;
				double num6 = (coordsObject3.NorthSouth - coordsObject.NorthSouth) * 240.0;
				double num7 = (num5 * num + num6 * num2) / num3;
				if (num7 < -0.05 || num7 > 0.95)
				{
					continue;
				}
				double num8 = num * num7 - num5;
				double num9 = num2 * num7 - num6;
				double num10 = Math.Sqrt(num8 * num8 + num9 * num9);
				if (!(num10 > 2.0))
				{
					double num11 = num5 * num5 + num6 * num6;
					if (num11 < num4)
					{
						num4 = num11;
						result = item.Id;
					}
				}
			}
			return result;
		}
		catch
		{
			return 0;
		}
	}

	private int DoorAhead(double ns, double ew, double bearing)
	{
		int result = 0;
		double num = 6.0;
		try
		{
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				if (!IsDoor(item) || (_tDoorUsed.TryGetValue(item.Id, out var value) && (DateTime.Now - value).TotalSeconds < 10.0))
				{
					continue;
				}
				CoordsObject coordsObject = item.Coordinates();
				double num2 = (coordsObject.NorthSouth - ns) * 240.0;
				double num3 = (coordsObject.EastWest - ew) * 240.0;
				double num4 = Math.Sqrt(num2 * num2 + num3 * num3);
				if (!(num4 >= num))
				{
					double num5 = (Math.Atan2(num3, num2) * 180.0 / Math.PI + 360.0) % 360.0;
					double num6 = Math.Abs(((num5 - bearing) % 360.0 + 540.0) % 360.0 - 180.0);
					if (!(num6 > 75.0) || !(num4 > 2.0))
					{
						num = num4;
						result = item.Id;
					}
				}
			}
		}
		catch
		{
		}
		return result;
	}

	private static double AngleOff(double a, double b)
	{
		return Math.Abs(((a - b) % 360.0 + 540.0) % 360.0 - 180.0);
	}

	private static double SafeProbe(double bearing, double metres)
	{
		if (!_wallProven)
		{
			WallFile("testing");
		}
		double result = Probe(bearing, metres);
		if (!_wallProven)
		{
			_wallProven = true;
			WallFile("ok");
		}
		return result;
	}

#if RETAIL
	private unsafe static double Probe(double bearing, double metres)
	{
		try
		{
			SmartBox** smartbox = SmartBox.smartbox;
			if (smartbox == null || *smartbox == null || (*smartbox)->cmdinterp == null)
			{
				return -1.0;
			}
			CPhysicsObj* player = (*smartbox)->cmdinterp->player;
			if (player == null || player->cell == null || player->part_array == null)
			{
				return -1.0;
			}
			Position position = player->m_position;
			uint objcell_id = position.objcell_id;
			if (objcell_id == 0 || (objcell_id & 0xFFFF) == 0)
			{
				return -1.0;
			}
			double num = bearing * Math.PI / 180.0;
			double num2 = Math.Sin(num) * metres;
			double num3 = Math.Cos(num) * metres;
			Position val = position;
			bool flag = (objcell_id & 0xFFFF) >= 256;
			if (flag)
			{
				val.frame.m_fOrigin.x = (float)((double)position.frame.m_fOrigin.x + num2);
				val.frame.m_fOrigin.y = (float)((double)position.frame.m_fOrigin.y + num3);
			}
			else
			{
				double num4 = (double)(objcell_id >> 24) * 192.0 + (double)position.frame.m_fOrigin.x + num2;
				double num5 = (double)((objcell_id >> 16) & 0xFF) * 192.0 + (double)position.frame.m_fOrigin.y + num3;
				if (num4 < 0.0 || num5 < 0.0 || num4 >= 48960.0 || num5 >= 48960.0)
				{
					return -1.0;
				}
				int num6 = (int)(num4 / 192.0);
				int num7 = (int)(num5 / 192.0);
				double num8 = num4 - (double)(num6 * 192);
				double num9 = num5 - (double)(num7 * 192);
				val.objcell_id = (uint)((num6 << 24) | (num7 << 16) | ((int)(num8 / 24.0) * 8 + (int)(num9 / 24.0) + 1));
				val.frame.m_fOrigin.x = (float)num8;
				val.frame.m_fOrigin.y = (float)num9;
				Func<double, double, double> func = null;
				try
				{
					func = AppDomain.CurrentDomain.GetData("MelksQB.GroundZ") as Func<double, double, double>;
				}
				catch
				{
				}
				double num10 = double.NaN;
				double num11 = double.NaN;
				if (func != null)
				{
					double num12 = (double)(objcell_id >> 24) * 192.0 + (double)position.frame.m_fOrigin.x;
					double num13 = (double)((objcell_id >> 16) & 0xFF) * 192.0 + (double)position.frame.m_fOrigin.y;
					try
					{
						num10 = func((num13 - 24468.0) / 240.0, (num12 - 24468.0) / 240.0);
						num11 = func((num5 - 24468.0) / 240.0, (num4 - 24468.0) / 240.0);
					}
					catch
					{
					}
				}
				if (!double.IsNaN(num10) && !double.IsNaN(num11))
				{
					val.frame.m_fOrigin.z = (float)((double)position.frame.m_fOrigin.z + (num11 - num10) + 0.3);
				}
				else if (!double.IsNaN(_pSlope) && AngleOff(bearing, _pBearing) < 25.0)
				{
					val.frame.m_fOrigin.z = (float)((double)position.frame.m_fOrigin.z + _pSlope * metres + 0.3);
				}
			}
			if (flag && !double.IsNaN(_pSlope) && AngleOff(bearing, _pBearing) < 25.0)
			{
				val.frame.m_fOrigin.z = (float)((double)position.frame.m_fOrigin.z + _pSlope * metres + 0.3);
			}
			CTransition* ptr = player->transition(&position, &val, 0);
			if (ptr == null)
			{
				return 0.0;
			}
			Position curr_pos = (ptr->sphere_path).curr_pos;
			double num14;
			double num15;
			if (flag)
			{
				num14 = curr_pos.frame.m_fOrigin.x - position.frame.m_fOrigin.x;
				num15 = curr_pos.frame.m_fOrigin.y - position.frame.m_fOrigin.y;
			}
			else
			{
				num14 = ((double)(curr_pos.objcell_id >> 24) - (double)(objcell_id >> 24)) * 192.0 + (double)curr_pos.frame.m_fOrigin.x - (double)position.frame.m_fOrigin.x;
				num15 = ((double)((curr_pos.objcell_id >> 16) & 0xFF) - (double)((objcell_id >> 16) & 0xFF)) * 192.0 + (double)curr_pos.frame.m_fOrigin.y - (double)position.frame.m_fOrigin.y;
			}
			double num16 = (num14 * num2 + num15 * num3) / metres;
			return Math.Max(0.0, Math.Min(1.0, num16 / metres));
		}
		catch
		{
			return -1.0;
		}
	}
#else
	private static double Probe(double bearing, double metres)
	{
		ACGodot.Plugins.PluginHost host = Bridge.Host;
		return (host?.Player == null) ? (-1.0) : host.Probe(bearing, metres);
	}
#endif
}
