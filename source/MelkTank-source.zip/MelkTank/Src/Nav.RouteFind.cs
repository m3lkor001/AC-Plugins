using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
#if !RETAIL
using ACGodot.DecalShim;
using ACGodot.Plugins;
using ACGodot.UI;
#endif
#if !RETAIL
using AcClient;
#else
using SmartBox = AcClient.SmartBox;
using ACCmdInterp = AcClient.ACCmdInterp;
using CommandInterpreter = AcClient.CommandInterpreter;
using CommandListElement = AcClient.CommandListElement;
using CPhysicsObj = AcClient.CPhysicsObj;
using Position = AcClient.Position;
using CTransition = AcClient.CTransition;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
#if !RETAIL
using Godot;
#endif
using ImGuiNET;
using MelkTank.Loot;
using MelkTank.Metas;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public partial class Nav
{
	private void RunOnOrStop(NavRoute r)
	{
		if (!_running)
		{
			return;
		}
		RouteStep routeStep = ((!_rDone && _rIdx >= 0 && _rIdx < r.Steps.Count) ? r.Steps[_rIdx] : null);
		if (routeStep == null || routeStep.Kind != StepKind.Point)
		{
			Stop();
			return;
		}
		NavSpot p = new NavSpot
		{
			NS = routeStep.NS,
			EW = routeStep.EW,
			Z = routeStep.Z
		};
		double num = DistanceTo(p);
		double num2 = CombatEngine.MyHeading();
		double num3 = ((num2 < 0.0) ? 180.0 : AngleDiff(BearingTo(p), num2));
		if (num3 >= (double)_s.NavTurnAngle || (num >= 0.0 && num < (double)_s.NavCloseDist && num3 >= (double)_s.NavCloseAngle))
		{
			L("point reached - next bends " + num3.ToString("0") + " deg at " + num.ToString("0.0") + " m: stop and turn");
			Stop();
		}
		else
		{
			L("point reached - running on (bend " + num3.ToString("0") + " deg, " + num.ToString("0.0") + " m)");
			_retarget = true;
		}
	}

	private void UpdateRouteMarkers()
	{
		NavRoute navRoute = _travelPreview ?? ((_s.NavMode == 1 && _s.NavRouteShowAll) ? CurrentRoute : null);
		bool flag = navRoute != null && navRoute == _travelPreview;
		string text = "";
		int num = 0;
		int num2 = int.MaxValue;
		if (navRoute != null && navRoute.Steps.Count > 150)
		{
			int num3 = ((!flag) ? Math.Max(0, Math.Min(_rIdx, navRoute.Steps.Count - 1)) : 0);
			num = Math.Max(0, num3 / 20 * 20 - 30);
			num2 = num + 150;
		}
		if (navRoute != null)
		{
			StringBuilder stringBuilder = new StringBuilder(navRoute.Name + "#" + num + "#sel" + _rSel);
			foreach (RouteStep step in navRoute.Steps)
			{
				stringBuilder.Append('|').Append((int)step.Kind).Append(step.NS.ToString("0.0000"))
					.Append(step.EW.ToString("0.0000"));
			}
			text = stringBuilder.ToString();
		}
		if (text == _routeKey)
		{
			if (_routeObjs.Count <= 0 || !((DateTime.Now - _routeVisCheck).TotalMilliseconds >= 250.0))
			{
				return;
			}
			_routeVisCheck = DateTime.Now;
			bool flag2 = !_s.NavHideUnfocused || GameFocused();
			foreach (D3DObj routeObj in _routeObjs)
			{
				SetVisible(routeObj, flag2);
			}
			NoteFocus(flag2, _routeObjs.Count);
			return;
		}
		_routeKey = text;
		ClearRouteMarkers();
		if (navRoute == null)
		{
			return;
		}
		try
		{
			D3DService d3DService = Globals.Core.D3DService;
			RouteStep routeStep = null;
			int num4 = 0;
			for (int i = num; i < navRoute.Steps.Count && i < num2; i++)
			{
				if (_routeObjs.Count >= 1500)
				{
					break;
				}
				RouteStep routeStep2 = navRoute.Steps[i];
				if (routeStep2.Kind == StepKind.Point || routeStep2.Kind == StepKind.Use)
				{
					num4++;
					bool flag3 = i == _rSel;
					D3DObj d3DObj = d3DService.MarkCoordsWithShape((float)routeStep2.NS, (float)routeStep2.EW, (float)routeStep2.Z + 0.05f, D3DShape.Ring, flag3 ? (-52429) : (-1436112129));
					if (d3DObj != null)
					{
						d3DObj.Scale(flag3 ? 0.9f : 0.6f);
						_routeObjs.Add(d3DObj);
					}
					bool flag4 = flag && routeStep2.Kind == StepKind.Use;
					string text2 = (flag4 ? (i + 1 + " " + (string.IsNullOrEmpty(routeStep2.Text) ? "portal" : routeStep2.Text)) : (i + 1).ToString());
					if (flag4 && d3DObj != null)
					{
						d3DObj.Color = -12256;
					}
					D3DObj d3DObj2 = d3DService.MarkCoordsWith3DText((float)routeStep2.NS, (float)routeStep2.EW, (float)routeStep2.Z + 1f, text2, "Arial", 0);
					if (d3DObj2 != null)
					{
						D3DObj d3DObj3 = d3DObj2;
						int color;
						if (flag3)
						{
							color = -52429;
						}
						else
						{
							color = (flag4 ? (-12256) : (-6697729));
						}
						d3DObj3.Color = color;
						d3DObj2.Scale(flag3 ? 0.4f : 0.3f);
						d3DObj2.OrientToCamera(true);
						_routeObjs.Add(d3DObj2);
					}
					if (routeStep != null && routeStep2.Kind == StepKind.Point && routeStep.Kind == StepKind.Point)
					{
						Dots(d3DService, routeStep, routeStep2);
					}
					routeStep = routeStep2;
				}
			}
			int num5 = LoopEndIdx(navRoute);
			if (num5 >= 0)
			{
				routeStep = null;
				for (int num6 = num5 - 1; num6 > LoopStart(navRoute); num6--)
				{
					if (navRoute.Steps[num6].Kind == StepKind.Point)
					{
						routeStep = navRoute.Steps[num6];
						break;
					}
				}
			}
			if (num2 == int.MaxValue && (navRoute.Mode == 2 || (num5 >= 0 && navRoute.Mode != 1)) && routeStep != null && routeStep.Kind == StepKind.Point)
			{
				int num7 = LoopStart(navRoute);
				for (int j = num7 + 1; j < navRoute.Steps.Count; j++)
				{
					if (navRoute.Steps[j].Kind == StepKind.Point)
					{
						if (navRoute.Steps[j] != routeStep)
						{
							Dots(d3DService, routeStep, navRoute.Steps[j]);
						}
						break;
					}
				}
			}
			_routeVisCheck = DateTime.MinValue;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void Dots(D3DService d3d, RouteStep a, RouteStep b)
	{
		double num = (b.NS - a.NS) * 240.0;
		double num2 = (b.EW - a.EW) * 240.0;
		double num3 = Math.Sqrt(num * num + num2 * num2);
		int num4 = Math.Min(60, (int)(num3 / 2.5));
		for (int i = 1; i < num4; i++)
		{
			if (_routeObjs.Count >= 1500)
			{
				break;
			}
			double num5 = (double)i / (double)num4;
			D3DObj d3DObj = d3d.MarkCoordsWithShape((float)(a.NS + (b.NS - a.NS) * num5), (float)(a.EW + (b.EW - a.EW) * num5), (float)(a.Z + (b.Z - a.Z) * num5) + 0.3f, D3DShape.Sphere, -2006537473);
			if (d3DObj != null)
			{
				d3DObj.Scale(0.12f);
				_routeObjs.Add(d3DObj);
			}
		}
	}

	private void ClearRouteMarkers()
	{
		int count = _routeObjs.Count;
		int num = 0;
		string text = null;
		foreach (D3DObj routeObj in _routeObjs)
		{
			try
			{
				routeObj.Visible = false;
			}
			catch (Exception ex)
			{
				num++;
				if (text == null)
				{
					text = "hide: " + ex.GetType().Name + " " + ex.Message;
				}
			}
			try
			{
				routeObj.Scale(0.0001f);
			}
			catch
			{
			}
			try
			{
				((IDisposable)routeObj)?.Dispose();
			}
			catch (Exception ex2)
			{
				num++;
				if (text == null)
				{
					text = "dispose: " + ex2.GetType().Name + " " + ex2.Message;
				}
			}
		}
		_routeObjs.Clear();
		if (count > 0)
		{
			L("route markers cleared: " + count + ((num > 0) ? (" - " + num + " failed (" + text + ")") : ""));
		}
	}

	private static int CurrentLb()
	{
		try
		{
			return Globals.Core.Actions.Landcell >>> 16;
		}
		catch
		{
			return 0;
		}
	}

	private static WorldObject FindInPack(string name)
	{
		if (string.IsNullOrEmpty(name))
		{
			return null;
		}
		WorldObject worldObject = null;
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
				{
					return item;
				}
				if (worldObject == null && item.Name != null && item.Name.IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0)
				{
					worldObject = item;
				}
			}
		}
		catch
		{
		}
		return worldObject;
	}

	private static List<string> PackGems()
	{
		List<string> list = new List<string>();
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (item.ObjectClass == ObjectClass.Gem && !string.IsNullOrEmpty(item.Name) && !list.Contains(item.Name))
				{
					list.Add(item.Name);
				}
			}
		}
		catch
		{
		}
		list.Sort(StringComparer.OrdinalIgnoreCase);
		return list;
	}

	private static List<KeyValuePair<int, string>> KnownRecalls()
	{
		List<KeyValuePair<int, string>> list = new List<KeyValuePair<int, string>>();
		try
		{
			foreach (int item in PortalSpellIds.All)
			{
				bool flag = false;
				try
				{
					flag = Globals.Core.CharacterFilter.IsSpellKnown(item);
				}
				catch
				{
				}
				if (flag)
				{
					list.Add(new KeyValuePair<int, string>(item, SpellNames.Name(item) ?? ("Spell " + item)));
				}
			}
		}
		catch
		{
		}
		list.Sort((KeyValuePair<int, string> a, KeyValuePair<int, string> b) => string.Compare(a.Value, b.Value, StringComparison.OrdinalIgnoreCase));
		return list;
	}

	private bool SharpTurnIndoors(NavRoute r, NavSpot to)
	{
		try
		{
			if ((Globals.Core.Actions.Landcell & 0xFFFF) < 256)
			{
				return false;
			}
			if (_rIdx + 1 >= r.Steps.Count)
			{
				return true;
			}
			RouteStep routeStep = r.Steps[_rIdx + 1];
			if (routeStep.Kind != StepKind.Point)
			{
				return false;
			}
			MyPos(out var ns, out var ew, out var _);
			double num = to.EW - ew;
			double num2 = to.NS - ns;
			double num3 = routeStep.EW - to.EW;
			double num4 = routeStep.NS - to.NS;
			double num5 = Math.Sqrt(num * num + num2 * num2);
			double num6 = Math.Sqrt(num3 * num3 + num4 * num4);
			if (num5 * 240.0 < 1.5 || num6 * 240.0 < 0.5)
			{
				return false;
			}
			double num7 = (num * num3 + num2 * num4) / (num5 * num6);
			return num7 < Math.Cos(Math.PI * 5.0 / 18.0);
		}
		catch
		{
			return false;
		}
	}

	private static bool Crowded(WorldObject o)
	{
		try
		{
			CoordsObject coordsObject = o.Coordinates();
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				if (item.Id != o.Id && PortalLike(item))
				{
					CoordsObject coordsObject2 = item.Coordinates();
					double num = (coordsObject2.NorthSouth - coordsObject.NorthSouth) * 240.0;
					double num2 = (coordsObject2.EastWest - coordsObject.EastWest) * 240.0;
					if (num * num + num2 * num2 < 100.0)
					{
						return true;
					}
				}
			}
		}
		catch
		{
		}
		return false;
	}

	private bool NextUseCrowded(NavRoute r)
	{
		try
		{
			if (_rIdx + 1 >= r.Steps.Count)
			{
				return false;
			}
			RouteStep routeStep = r.Steps[_rIdx + 1];
			if (routeStep.Kind != StepKind.Use)
			{
				return false;
			}
			int num = 0;
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				if (PortalLike(item))
				{
					CoordsObject coordsObject = item.Coordinates();
					double num2 = (coordsObject.NorthSouth - routeStep.NS) * 240.0;
					double num3 = (coordsObject.EastWest - routeStep.EW) * 240.0;
					if (num2 * num2 + num3 * num3 < 144.0 && ++num >= 2)
					{
						return true;
					}
				}
			}
		}
		catch
		{
		}
		return false;
	}

	private WorldObject FindUse(RouteStep st)
	{
		WorldObject worldObject = FindUseNamed(st);
		if (worldObject != null || _travelRoute == null || CurrentRoute != _travelRoute)
		{
			return worldObject;
		}
		string text = TravelNorm(st.Text);
		int num = text.LastIndexOf(" to ", StringComparison.Ordinal);
		string text2 = ((num >= 0) ? text.Substring(num + 4).Trim() : text);
		WorldObject worldObject2 = null;
		WorldObject worldObject3 = null;
		double num2 = double.MaxValue;
		double num3 = double.MaxValue;
		int num4 = 0;
		try
		{
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				if (!PortalLike(item))
				{
					continue;
				}
				CoordsObject coordsObject = item.Coordinates();
				double num5 = (coordsObject.NorthSouth - st.NS) * 240.0;
				double num6 = (coordsObject.EastWest - st.EW) * 240.0;
				double num7 = Math.Sqrt(num5 * num5 + num6 * num6);
				string text3 = TravelNorm(item.Name);
				string text4 = (text3.EndsWith(" portal", StringComparison.Ordinal) ? text3.Substring(0, text3.Length - 7).Trim() : text3);
				int num8 = 0;
				if (text2.Length > 0 && text4.Length > 0)
				{
					if (text4 == text2 || text3 == text || text4 == text)
					{
						num8 = 3;
					}
					else if (text4.StartsWith(text2, StringComparison.Ordinal) || text2.StartsWith(text4, StringComparison.Ordinal))
					{
						num8 = 2;
					}
					else if (text3.Contains(text2) || text2.Contains(text4))
					{
						num8 = 1;
					}
				}
				if (num8 > 0 && num7 <= 60.0 && (num8 > num4 || (num8 == num4 && num7 < num2)))
				{
					num4 = num8;
					num2 = num7;
					worldObject2 = item;
				}
				if (num7 < num3)
				{
					num3 = num7;
					worldObject3 = item;
				}
			}
		}
		catch
		{
		}
		if (worldObject2 != null && num2 <= 60.0)
		{
			return worldObject2;
		}
		return (worldObject3 != null && num3 <= 3.0) ? worldObject3 : null;
	}

	private static bool PortalLike(WorldObject o)
	{
		if (o.ObjectClass == ObjectClass.Portal)
		{
			return true;
		}
		ObjectClass objectClass = o.ObjectClass;
		return o.Container == 0 && (o.Name ?? "").EndsWith(" Portal", StringComparison.OrdinalIgnoreCase) && objectClass != ObjectClass.Npc && objectClass != ObjectClass.Vendor && objectClass != ObjectClass.Monster && objectClass != ObjectClass.Player && objectClass != ObjectClass.Corpse;
	}

	private static string TravelNorm(string s)
	{
		return (s ?? "").Replace('`', '\'').Replace('’', '\'').Replace('‘', '\'')
			.Trim()
			.ToLowerInvariant();
	}

	private static WorldObject FindUseNamed(RouteStep st)
	{
		// (the very one picked when the step was added, if it's here and still goes by that name)
		if (st.Guid != 0)
		{
			try
			{
				WorldObject picked = Globals.Core.WorldFilter[st.Guid];
				if (picked != null && (string.IsNullOrEmpty(st.Text) || string.Equals(picked.Name, st.Text, StringComparison.OrdinalIgnoreCase)))
				{
					return picked;
				}
			}
			catch
			{
			}
		}
		WorldObject worldObject = null;
		double num = double.MaxValue;
		try
		{
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				if (string.Equals(item.Name, st.Text, StringComparison.OrdinalIgnoreCase))
				{
					double num4;
					try
					{
						CoordsObject coordsObject = item.Coordinates();
						double num2 = (coordsObject.NorthSouth - st.NS) * 240.0;
						double num3 = (coordsObject.EastWest - st.EW) * 240.0;
						// (and its height: the same name on the floor above or below isn't the one)
						double dz = 0.0;
						if (st.Z != 0.0)
						{
							try { dz = item.RawCoordinates().Z - st.Z; } catch { }
						}
						num4 = Math.Sqrt(num2 * num2 + num3 * num3 + dz * dz);
					}
					catch
					{
						num4 = 1000.0;
					}
					if (num4 < num)
					{
						num = num4;
						worldObject = item;
					}
				}
			}
		}
		catch
		{
		}
		if (worldObject != null && num <= Tuning.V("UseRangeM"))
		{
			return worldObject;
		}
		// (none by that name near where the step was made - a route made in another client, whose coordinates in a
		// dungeon don't line up with these: the nearest by that name near you, if there's one)
		WorldObject near = null;
		double best = double.MaxValue;
		try
		{
			foreach (WorldObject item2 in Globals.Core.WorldFilter.GetLandscape())
			{
				if (string.Equals(item2.Name, st.Text, StringComparison.OrdinalIgnoreCase))
				{
					double d = CombatEngine.Distance(item2);
					if (d >= 0.0 && d < best)
					{
						best = d;
						near = item2;
					}
				}
			}
		}
		catch
		{
		}
		return (near != null && best <= Tuning.V("UseRangeM")) ? near : null;
	}

	private RouteStep NewPointHere(StepKind k)
	{
		if (!MyPos(out var ns, out var ew, out var z))
		{
			Util.WriteToChat("Nav: couldn't read your position.");
			return null;
		}
		return new RouteStep
		{
			Kind = k,
			NS = ns,
			EW = ew,
			Z = z
		};
	}

	private void Insert(NavRoute r, RouteStep st)
	{
		if (st != null)
		{
			int num = ((_rSel >= 0 && _rSel < r.Steps.Count) ? (_rSel + 1) : r.Steps.Count);
			r.Steps.Insert(num, st);
			_rSel = num;
		}
	}
}
