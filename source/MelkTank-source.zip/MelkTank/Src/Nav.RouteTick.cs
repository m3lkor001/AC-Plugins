using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
#if !RETAIL
using ACGodot.DecalShim;
using ACGodot.Plugins;
using ACGodot.UI;
#endif
#if !RETAIL
using AcClient;
#else
using SmartBox = AcClient.SmartBox;
using ACCmdInterp = AcClient.ACCmdInterp;
using CommandInterpreter = AcClient.CommandInterpreter;
using CommandListElement = AcClient.CommandListElement;
using CPhysicsObj = AcClient.CPhysicsObj;
using Position = AcClient.Position;
using CTransition = AcClient.CTransition;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
#if !RETAIL
using Godot;
#endif
using ImGuiNET;
using MelkTank.Loot;
using MelkTank.Metas;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public partial class Nav
{
	private bool RouteTick()
	{
		RestoreHotState();
		_rTickAt = DateTime.Now;
		NavRoute navRoute = (_s.NavEnabled ? CurrentRoute : null);
		if (navRoute == null || navRoute.Steps.Count == 0)
		{
			Stop();
			return false;
		}
		if (DateTime.Now < _pauseUntil)
		{
			return false;
		}
		if (_inPortal || (DateTime.Now - _portalExitAt).TotalSeconds < 3.0 || (_diedAt > _portalExitAt && (DateTime.Now - _diedAt).TotalSeconds < 30.0))
		{
			Stop();
			Status = "Route " + navRoute.Name + " - " + (_inPortal ? "in portal space" : ((_diedAt > _portalExitAt) ? "died - waiting to land" : "just landed")) + ", waiting";
			return true;
		}
		if (!string.Equals(_rName, navRoute.Name, StringComparison.Ordinal))
		{
			if (_resumeNearest && navRoute != _travelRoute && !string.Equals(navRoute.Name, "Map route", StringComparison.OrdinalIgnoreCase))
			{
				if (!MyPos(out var _, out var _, out var _))
				{
					return false;
				}
				_resumeNearest = false;
				_rName = navRoute.Name;
				RouteReset();
				int num = NearestPoint(navRoute, this, out var dist);
				if (num > 0 && dist <= 500.0)
				{
					_rIdx = num;
					Util.WriteToChat("Nav: carrying on with " + navRoute.Name + " at step " + (num + 1) + " (the nearest point, " + dist.ToString("0") + " m away).");
				}
				else if (num > 0)
				{
					Util.WriteToChat("Nav: " + navRoute.Name + " - its nearest point is " + dist.ToString("0") + " m away, starting from step 1.");
				}
			}
			else
			{
				_rName = navRoute.Name;
				RouteReset();
			}
		}
		_resumeNearest = false;
		if (_rIdx >= navRoute.Steps.Count)
		{
			_rIdx = 0;
		}
		while (_rDetour.Count > 0 && (_rDetour[0] >= navRoute.Steps.Count || navRoute.Steps[_rDetour[0]].Kind != StepKind.Point))
		{
			_rDetour.RemoveAt(0);
		}
		if (_rDetour.Count > 0)
		{
			RouteStep routeStep = navRoute.Steps[_rDetour[0]];
			NavSpot p = new NavSpot
			{
				Name = navRoute.Name + " #" + (_rDetour[0] + 1),
				NS = routeStep.NS,
				EW = routeStep.EW,
				Z = routeStep.Z,
				Heading = -1.0
			};
			if (TooFar(p))
			{
				_rDetour.Clear();
				return true;
			}
			int stuckEvents = StuckEvents;
			if (ReturnTick(p, navRoute.Arrive, navRoute.Arrive, precise: false))
			{
				Status = "Route " + navRoute.Name + " - backing up - " + Status;
				return true;
			}
			if (StuckEvents != stuckEvents)
			{
				_rDetour.Clear();
				_rStuckSeen = StuckEvents;
				return false;
			}
			_rDetour.RemoveAt(0);
			return true;
		}
		if (_rDone)
		{
			Stop();
			Status = "Route " + navRoute.Name + " done";
			return false;
		}
		RouteStep routeStep2 = navRoute.Steps[_rIdx];
		string text = "step " + (_rIdx + 1) + "/" + navRoute.Steps.Count;
		if (routeStep2.Kind == StepKind.Preset)
		{
			NavRoute navRoute2 = NavPresets.Find(routeStep2.Text);
			if (navRoute2 == null || navRoute2.Steps.Count == 0)
			{
				if (_presetWarned.Add(routeStep2.Text ?? ""))
				{
					Util.WriteToChat("Nav: " + ((navRoute2 == null) ? "there's no preset called " : "the preset has no steps: ") + routeStep2.Text + " - skipping it.");
				}
				_rSubFor = -1;
				Advance(navRoute);
				return true;
			}
			int num2 = (_rSub = Math.Min(SubNow(), navRoute2.Steps.Count - 1));
			_rSubFor = _rIdx;
			routeStep2 = navRoute2.Steps[num2];
			text = "step " + (_rIdx + 1) + "." + (num2 + 1) + "/" + navRoute.Steps.Count + " " + navRoute2.Name;
		}
		DateTime now = DateTime.Now;
		switch (routeStep2.Kind)
		{
		case StepKind.LoopStart:
			ResetConds(navRoute);
			Advance(navRoute);
			return true;
		case StepKind.LoopEnd:
		{
			int num5 = LoopStart(navRoute) + 1;
			if (_rIdx != LoopEndIdx(navRoute))
			{
				Advance(navRoute);
				return true;
			}
			if (CondsMet(routeStep2))
			{
				L("route " + navRoute.Name + " " + text + ": loop done (" + string.Join(", ", routeStep2.Conds.ConvertAll<string>(CondText).ToArray()) + ")");
				ResetConds(navRoute);
				_rDir = 1;
				Advance(navRoute);
				return true;
			}
			Status = "Route " + navRoute.Name + " - round again";
			_rUntil = DateTime.MinValue;
			_rUsedAt = DateTime.MinValue;
			_rStarted = false;
			_rPrevStepAt = _rStepAt;
			_rStepAt = now;
			if (navRoute.Mode == 1)
			{
				_rDir = -1;
				_rIdx = Math.Max(num5, _rIdx - 2);
			}
			else
			{
				_rIdx = num5;
			}
			if (_rIdx >= navRoute.Steps.Count || navRoute.Steps[_rIdx].Kind == StepKind.LoopEnd)
			{
				Status = "Route " + navRoute.Name + " - the loop has no steps";
				return false;
			}
			return true;
		}
		case StepKind.GoRoute:
		{
			NavRoute navRoute3 = null;
			foreach (NavRoute navRoute4 in _s.NavRoutes)
			{
				if (string.Equals(navRoute4.Name, routeStep2.Text, StringComparison.OrdinalIgnoreCase))
				{
					navRoute3 = navRoute4;
				}
			}
			if (navRoute3 == null)
			{
				Util.WriteToChat("Nav: no route called " + routeStep2.Text + " - going on.");
				Advance(navRoute);
				return true;
			}
			Stop();
			_s.NavRouteSelected = navRoute3.Name;
			_rName = navRoute3.Name;
			RouteReset();
			ResetConds(navRoute3);
			if (routeStep2.Op == "nearest")
			{
				int num6 = NearestPoint(navRoute3, this, out var _);
				if (num6 >= 0)
				{
					_rIdx = num6;
				}
			}
			L("route " + navRoute.Name + " " + text + ": on to route " + navRoute3.Name + " at step " + (_rIdx + 1));
			Util.WriteToChat("Nav: on to route " + navRoute3.Name + " (step " + (_rIdx + 1) + ").");
			if (SaveAll != null)
			{
				SaveAll();
			}
			return true;
		}
		case StepKind.Point:
		{
			NavSpot navSpot = new NavSpot
			{
				Name = navRoute.Name + " #" + (_rIdx + 1),
				NS = routeStep2.NS,
				EW = routeStep2.EW,
				Z = routeStep2.Z,
				Heading = -1.0
			};
			if (navRoute.RestartIfFar && _rIdx > 0 && _portalExitAt < _rFarRestartAt && DistanceTo(navSpot) > (double)Math.Max(10f, navRoute.RestartFarM) && (DateTime.Now - _rFarRestartAt).TotalSeconds <= 60.0)
			{
				Stop();
				Status = "Route " + navRoute.Name + " " + text + " is " + DistanceTo(navSpot).ToString("0") + " m away - starting over again in " + (60.0 - (DateTime.Now - _rFarRestartAt).TotalSeconds).ToString("0") + " s";
				return true;
			}
			if (navRoute.RestartIfFar && _rIdx > 0 && (DateTime.Now - _rFarRestartAt).TotalSeconds > 60.0)
			{
				double num8 = DistanceTo(navSpot);
				if (num8 > (double)Math.Max(10f, navRoute.RestartFarM))
				{
					_rFarRestartAt = DateTime.Now;
					Stop();
					_rName = navRoute.Name;
					RouteReset();
					L("route " + navRoute.Name + " " + text + ": " + num8.ToString("0") + " m away (over " + navRoute.RestartFarM.ToString("0") + ") - starting over from step 1");
					Util.WriteToChat("Nav: " + navRoute.Name + " " + text + " is " + num8.ToString("0") + " m away - starting over from step 1.");
					return true;
				}
			}
			if (navRoute == _travelRoute && !TravelPointOk(navSpot))
			{
				return false;
			}
			if (TooFar(navSpot))
			{
				return true;
			}
			NavSpot navSpot2 = navSpot;
			if (navRoute == _travelRoute)
			{
				navSpot = TravelDetour(navSpot);
			}
			bool flag5 = navRoute == _travelRoute && navSpot == navSpot2 && (NextUseCrowded(navRoute) || SharpTurnIndoors(navRoute, navSpot));
			if (ReturnTick(navSpot, flag5 ? Math.Min(navRoute.Arrive, 1.0) : ((double)navRoute.Arrive), flag5 ? Math.Min(navRoute.Arrive, 1.0) : ((double)navRoute.Arrive), flag5))
			{
				Status = "Route " + navRoute.Name + " " + text + " - " + Status + (flag5 ? " (portals close by: carefully)" : "");
				return true;
			}
			if (navSpot != navSpot2 && DateTime.Now >= _pauseUntil)
			{
				_tDetour = null;
				_retarget = true;
				return true;
			}
			if (DateTime.Now < _pauseUntil)
			{
				if (StuckEvents != _rStuckSeen)
				{
					_rStuckSeen = StuckEvents;
					if (_rStuckIdx != _rIdx)
					{
						_rStuckIdx = _rIdx;
						_rStuckN = 0;
					}
					if (++_rStuckN >= Math.Max(1, navRoute.StuckAfter))
					{
						_rStuckN = 0;
						OnStuck(navRoute);
					}
				}
				return false;
			}
			_rStuckN = 0;
			_rStuckIdx = -1;
			EndTempCombat();
			Advance(navRoute);
			RunOnOrStop(navRoute);
			return true;
		}
		case StepKind.Command:
			if (!_rStarted)
			{
				_rStarted = true;
				Stop();
				string text3 = routeStep2.Text;
				if (routeStep2.WaitMs == 1500 && Regex.IsMatch(text3 ?? "", "^/ub jumps? \\d+ \\d+$"))
				{
					text3 = text3.Replace("/ub jumps ", "/ub jumpsw ").Replace("/ub jump ", "/ub jumpw ");
				}
				if (!MtCommand(text3) && !VtCommand(text3))
				{
					Util.Command(text3);
				}
				L("route " + navRoute.Name + " " + text + ": command " + routeStep2.Text);
				_rUntil = now.AddMilliseconds(Math.Max(0, routeStep2.WaitMs));
			}
			Status = "Route " + navRoute.Name + " " + text + " - " + routeStep2.Text;
			if (now >= _rUntil && UbCmd.Jumping && now < _rUntil.AddSeconds(20.0))
			{
				Status += " (jumping)";
				return true;
			}
			if (now >= _rUntil)
			{
				Advance(navRoute);
			}
			return true;
		case StepKind.Toggle:
		{
			string text2 = (routeStep2.Text ?? "").ToLowerInvariant();
			bool flag3 = text2.EndsWith(" on");
			if (text2.StartsWith("combat"))
			{
				_rTempCombat = false;
			}
			if (text2.StartsWith("combat"))
			{
				if (_s.CombatEnabled != flag3)
				{
					_s.CombatEnabled = flag3;
					if (SaveAll != null)
					{
						SaveAll();
					}
				}
			}
			else if (text2.StartsWith("loot"))
			{
				if (_s.LootEnabled != flag3)
				{
					_s.LootEnabled = flag3;
					if (SaveAll != null)
					{
						SaveAll();
					}
				}
			}
			else if (text2.StartsWith("summon"))
			{
				PluginCore.SetSummoningFromNav(flag3);
			}
			else if (text2.StartsWith("doors"))
			{
				if (_s.NavOpenDoors != flag3)
				{
					_s.NavOpenDoors = flag3;
					if (SaveAll != null)
					{
						SaveAll();
					}
				}
			}
			else if (text2 == "reset kills/hr")
			{
				Session.ResetRecentRate();
				Util.WriteToChat("Nav: kills/hr (last 60 min) reset - timing from here.");
			}
			else if (text2 == "reset session")
			{
				Session.Reset();
				Util.WriteToChat("Nav: session reset - tracking from here.");
			}
			L("route " + navRoute.Name + " " + text + ": " + routeStep2.Text);
			Advance(navRoute);
			return true;
		}
		case StepKind.Cast:
			if (!_rStarted)
			{
				bool flag4 = true;
				try
				{
					flag4 = Globals.Core.Actions.CombatMode == CombatState.Magic;
				}
				catch
				{
				}
				if (!flag4)
				{
					if (_rUntil == DateTime.MinValue)
					{
						Stop();
						if (!Session.WandInHand())
						{
							int num7 = Session.AnyWand();
							if (num7 != 0)
							{
								Session.Wield(num7);
								_rCastWield = true;
								L("route " + navRoute.Name + " " + text + ": wielding a wand to cast");
							}
							else
							{
								Util.WriteToChat("Nav: no wand in your packs to cast with.");
							}
						}
						else
						{
							try
							{
								Globals.Core.Actions.SetCombatMode(CombatState.Magic);
							}
							catch
							{
							}
						}
						_rUntil = now.AddSeconds(6.0);
					}
					else if (_rCastWield && Session.WandInHand() && (now - _rCastModeAt).TotalSeconds > 1.5)
					{
						_rCastModeAt = now;
						try
						{
							Globals.Core.Actions.SetCombatMode(CombatState.Magic);
						}
						catch
						{
						}
					}
					if (now < _rUntil)
					{
						Status = "Route " + navRoute.Name + " " + text + " - getting ready to cast";
						return true;
					}
					_rCastWield = false;
				}
				_rStarted = true;
				Stop();
				int.TryParse(routeStep2.Text, out var result);
				_rLandblock = CurrentLb();
				try
				{
					Globals.Core.Actions.CastSpell(result, Globals.Core.CharacterFilter.Id);
				}
				catch (Exception ex2)
				{
					Util.LogError(ex2);
				}
				L("route " + navRoute.Name + " " + text + ": casting " + SpellNames.Name(result));
				_rUsedAt = now;
				_rUntil = now.AddSeconds(20.0);
			}
			Status = "Route " + navRoute.Name + " " + text + " - casting " + (SpellNames.Name(int.Parse("0" + routeStep2.Text)) ?? routeStep2.Text);
			if (_rUsedAt.Ticks == 1 || (CurrentLb() != _rLandblock && CurrentLb() > 0))
			{
				Advance(navRoute);
				_rUntil = DateTime.Now.AddSeconds(Tuning.V("AfterPortalS"));
				return true;
			}
			if (now >= _rUntil)
			{
				if (navRoute == _travelRoute)
				{
					if (_tUseIdx != _rIdx)
					{
						_tUseIdx = _rIdx;
						_tUseTries = 0;
					}
					if (++_tUseTries < 2)
					{
						L("route " + navRoute.Name + " " + text + ": the recall didn't happen - casting again");
						_rStarted = false;
						_rUntil = DateTime.MinValue;
						return true;
					}
					TravelStop("the recall (" + (SpellNames.Name(int.Parse("0" + routeStep2.Text)) ?? routeStep2.Text) + ") didn't take you anywhere", finished: false);
					return true;
				}
				Advance(navRoute);
			}
			return true;
		case StepKind.Vendor:
			// one whole vendor visit (Items > Vendor): the route waits while it runs, and goes on once it's done
			if (!_rStarted)
			{
				_rStarted = true;
				Stop();
				if (VendorRun.I == null || !VendorRun.I.Start(routeStep2.Text, routeStep2.Profile, dry: false))
				{
					Advance(navRoute);
				}
				return true;
			}
			if (VendorRun.I != null && VendorRun.I.Busy)
			{
				Status = "Route " + navRoute.Name + " " + text + " - vendor: " + VendorRun.I.Status;
				return true;
			}
			L("route " + navRoute.Name + " " + text + ": vendor visit " + VendorRun.ResultWord(VendorRun.Last));
			Advance(navRoute);
			return true;
		case StepKind.UseItem:
			if (!_rStarted && now < _rUseRetryAt)
			{
				Status = "Route " + navRoute.Name + " " + text + " - trying " + routeStep2.Text + " again";
				return true;
			}
			if (!_rStarted)
			{
				WorldObject worldObject3 = FindInPack(routeStep2.Text);
				if (worldObject3 == null)
				{
					Util.WriteToChat("Nav: no " + routeStep2.Text + " in your packs - going on to the next step.");
					Advance(navRoute);
					return true;
				}
				_rStarted = true;
				Stop();
				_rLandblock = CurrentLb();
				if (_rUseIdx != StepKey())
				{
					_rUseIdx = StepKey();
					_rUseTries = 0;
				}
				_rUseTries++;
				_rUseHad = InventoryCount(routeStep2.Text);
				try
				{
					Globals.Core.Actions.UseItem(worldObject3.Id, 0);
				}
				catch (Exception ex3)
				{
					Util.LogError(ex3);
				}
				L("route " + navRoute.Name + " " + text + ": using " + worldObject3.Name);
				_rUsedAt = now;
				_rUntil = now.AddMilliseconds(Math.Max(1000, routeStep2.WaitMs));
			}
			Status = "Route " + navRoute.Name + " " + text + " - using " + routeStep2.Text;
			if (_rUsedAt.Ticks == 1 || (CurrentLb() != _rLandblock && CurrentLb() > 0))
			{
				_rUseIdx = -1;
				Advance(navRoute);
				_rUntil = DateTime.Now.AddSeconds(Tuning.V("AfterPortalS"));
				return true;
			}
			if (now >= _rUntil)
			{
				if (InventoryCount(routeStep2.Text) >= _rUseHad && _rUseHad > 0 && _rUseTries < 3)
				{
					L("route " + navRoute.Name + " " + text + ": " + routeStep2.Text + " doesn't seem to have been used - trying again (" + (_rUseTries + 1) + "/3)");
					_rStarted = false;
					_rUsedAt = DateTime.MinValue;
					_rUseRetryAt = now.AddSeconds(2.0);
					return true;
				}
				_rUseIdx = -1;
				Advance(navRoute);
			}
			return true;
		case StepKind.ChatWait:
			if (!_rStarted)
			{
				_rStarted = true;
				Stop();
				L("route " + navRoute.Name + " " + text + ": waiting for chat " + routeStep2.Op + " \"" + routeStep2.Text + "\"");
			}
			Status = "Route " + navRoute.Name + " " + text + " - waiting for chat " + routeStep2.Op + " \"" + routeStep2.Text + "\"";
			if (ChatSeen(routeStep2, _rPrevStepAt))
			{
				L("route " + navRoute.Name + " " + text + ": chat matched");
				Advance(navRoute);
			}
			return true;
		case StepKind.ItemCheck:
		{
			if (!_rStarted)
			{
				_rStarted = true;
				Stop();
			}
			if ((now - _rItemCheckAt).TotalMilliseconds < Tuning.V("ItemCheckMs"))
			{
				return true;
			}
			_rItemCheckAt = now;
			int have = InventoryCount(routeStep2.Text);
			Status = "Route " + navRoute.Name + " " + text + " - waiting for " + routeStep2.Text + " " + routeStep2.Op + " " + routeStep2.Count + " (have " + have + ")";
			if (Compare(have, routeStep2.Op, routeStep2.Count))
			{
				L("route " + navRoute.Name + " " + text + ": " + routeStep2.Text + " " + have + " " + routeStep2.Op + " " + routeStep2.Count + " - go on");
				Advance(navRoute);
			}
			return true;
		}
		case StepKind.PlayerSkip:
		{
			double num9 = SkipRange(routeStep2);
			string text4 = NearestPlayer(out var dist3);
			int num10 = Math.Max(0, routeStep2.Count);
			Advance(navRoute);
			if (text4 != null && dist3 <= num9)
			{
				string text5 = SkipSteps(navRoute, num10);
				L("route " + navRoute.Name + " " + text + ": " + text4 + " is " + dist3.ToString("0") + " m away - skipping the next " + num10 + " step" + ((num10 == 1) ? "" : "s") + text5);
			}
			else if (SkipNoMobs(routeStep2) && !MonsterInCombatRange())
			{
				string text6 = SkipSteps(navRoute, num10);
				L("route " + navRoute.Name + " " + text + ": no monsters in combat range - skipping the next " + num10 + " step" + ((num10 == 1) ? "" : "s") + text6);
			}
			return true;
		}
		case StepKind.Wait:
			if (!_rStarted)
			{
				_rStarted = true;
				Stop();
				_rUntil = now.AddMilliseconds(Math.Max(0, routeStep2.WaitMs));
			}
			Status = "Route " + navRoute.Name + " " + text + " - waiting " + Math.Max(0.0, (_rUntil - now).TotalSeconds).ToString("0") + "s";
			if (now >= _rUntil)
			{
				Advance(navRoute);
			}
			return true;
		case StepKind.Use:
		{
			if (!_rStarted)
			{
				WorldObject worldObject = FindUse(routeStep2);
				if (worldObject == null)
				{
					if (_rUntil == DateTime.MinValue)
					{
						_rUntil = now.AddSeconds(Tuning.V("UseFindS"));
					}
					Status = "Route " + navRoute.Name + " " + text + " - looking for " + routeStep2.Text;
					if (now >= _rUntil)
					{
						if (navRoute == _travelRoute)
						{
							TravelStop("couldn't find the portal " + (string.IsNullOrEmpty(routeStep2.Text) ? "here" : routeStep2.Text), finished: false);
							return true;
						}
						Util.WriteToChat("Nav: couldn't find " + routeStep2.Text + " - going on to the next step.");
						Advance(navRoute);
					}
					return true;
				}
				if (navRoute == _travelRoute && Crowded(worldObject))
				{
					if (_useFaceUntil == DateTime.MinValue)
					{
						Stop();
						CoordsObject coordsObject = worldObject.Coordinates();
						try
						{
							Globals.Core.Actions.FaceHeading(BearingTo(new NavSpot
							{
								NS = coordsObject.NorthSouth,
								EW = coordsObject.EastWest
							}), true);
						}
						catch
						{
						}
						_useFaceUntil = now.AddMilliseconds(Tuning.V("UseFaceMs"));
					}
					if (now < _useFaceUntil)
					{
						Status = "Route " + navRoute.Name + " " + text + " - facing " + worldObject.Name;
						return true;
					}
				}
				if (now < _useDoorWait)
				{
					Status = "Route " + navRoute.Name + " " + text + " - opening the door to " + worldObject.Name;
					return true;
				}
				int num3 = DoorBetween(worldObject);
				if (num3 != 0)
				{
					bool? flag = DoorShut(num3);
					if (!flag.HasValue)
					{
						Status = "Route " + navRoute.Name + " " + text + " - checking the door to " + worldObject.Name;
						return true;
					}
					if (flag == true)
					{
						Stop();
						try
						{
							Globals.Core.Actions.UseItem(num3, 0);
						}
						catch
						{
						}
						_tDoorUsed[num3] = now;
						_doorUseAt = now;
						_doorRerun = true;
						_useDoorWait = now.AddSeconds(2.5);
						L("route " + navRoute.Name + " " + text + ": a door between you and " + worldObject.Name + " - opening it first");
						return true;
					}
				}
				_useFaceUntil = DateTime.MinValue;
				_rStarted = true;
				Stop();
				_rLandblock = CurrentLb();
				try
				{
					Globals.Core.Actions.UseItem(worldObject.Id, 0);
				}
				catch (Exception ex)
				{
					Util.LogError(ex);
				}
				L("route " + navRoute.Name + " " + text + ": using " + worldObject.Name);
				_rUsedAt = now;
				_rUntil = now.AddSeconds(PortalLike(worldObject) ? Tuning.V("UsePortalS") : Tuning.V("UseNpcS"));
			}
			bool flag2 = _rUsedAt.Ticks == 1 || (CurrentLb() != _rLandblock && CurrentLb() > 0);
			Status = "Route " + navRoute.Name + " " + text + " - using " + routeStep2.Text;
			if (flag2)
			{
				Advance(navRoute);
				_rUntil = DateTime.Now.AddSeconds(Tuning.V("AfterPortalS"));
				return true;
			}
			if (navRoute == _travelRoute && (now - _rUsedAt).TotalSeconds > 3.0 && now >= _useDoorWait)
			{
				WorldObject worldObject2 = FindUse(routeStep2);
				int num4 = ((worldObject2 != null) ? DoorBetween(worldObject2) : 0);
				if (num4 != 0 && DoorShut(num4) == true)
				{
					Stop();
					try
					{
						Globals.Core.Actions.UseItem(num4, 0);
					}
					catch
					{
					}
					_tDoorUsed[num4] = now;
					_doorUseAt = now;
					_doorRerun = true;
					_useDoorWait = now.AddSeconds(2.5);
					_rStarted = false;
					_rUntil = DateTime.MinValue;
					L("route " + navRoute.Name + " " + text + ": a shut door between you and " + routeStep2.Text + " - opening it, then using it again");
					return true;
				}
			}
			if (now >= _rUntil)
			{
				if (navRoute == _travelRoute)
				{
					if (_tUseIdx != _rIdx)
					{
						_tUseIdx = _rIdx;
						_tUseTries = 0;
					}
					if (++_tUseTries < 3)
					{
						L("route " + navRoute.Name + " " + text + ": didn't go through " + routeStep2.Text + " - trying again (" + _tUseTries + ")");
						_rStarted = false;
						_rUntil = DateTime.MinValue;
						return true;
					}
					TravelStop("used " + (string.IsNullOrEmpty(routeStep2.Text) ? "the portal" : routeStep2.Text) + " 3 times but didn't go through", finished: false);
					return true;
				}
				Advance(navRoute);
			}
			return true;
		}
		default:
			return false;
		}
	}
}
