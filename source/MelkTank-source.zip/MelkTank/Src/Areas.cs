using System;
using System.Collections.Generic;
using System.Numerics;
using ImGuiNET;
using MelkTank.Loot;

namespace MelkTank;

public class Areas
{
	private static readonly Vector4 Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f);

	private static readonly Vector4 Green = new Vector4(0.45f, 0.9f, 0.45f, 1f);

	private static readonly Vector4 Cyan = new Vector4(0.35f, 0.85f, 0.95f, 1f);

	private readonly Settings _s;

	private readonly Looter _looter;

	public Action SaveAll;

	private DateTime _next = DateTime.MinValue;

	private int _lastLb = -1;

	private bool _arrived = true;

	private AreaLink _applied;

	// (logging in: when the world was last come into - an area's "Nav on" isn't switched on by a login, only by
	// arriving there in play; logging back in where a route ran had it off and portalling away with the meta/nav off)
	private bool _outOfWorld = true;

	private DateTime _loginAt = DateTime.MinValue;

	private string _newName = "";

	public Areas(Settings s, Looter looter)
	{
		_s = s;
		_looter = looter;
	}

	public static int CurrentLandblock()
	{
		try
		{
			return Globals.Core.Actions.Landcell >>> 16;
		}
		catch
		{
			return -1;
		}
	}

	public AreaLink Find(int lb)
	{
		foreach (AreaLink areaLink in _s.AreaLinks)
		{
			if (areaLink.Landblocks.Contains(lb))
			{
				return areaLink;
			}
		}
		return null;
	}

	public void Tick()
	{
		if (!_s.AreasEnabled || DateTime.Now < _next)
		{
			return;
		}
		_next = DateTime.Now.AddSeconds(Tuning.V("AreaCheckS"));
		int num = CurrentLandblock();
		if (num <= 0)
		{
			_outOfWorld = true;
			return;
		}
		if (_outOfWorld)
		{
			_outOfWorld = false;
			_loginAt = DateTime.Now;
		}
		if (_s.AreasOnArrival)
		{
			if (_arrived)
			{
				_arrived = false;
				_lastLb = num;
				AreaLink areaLink = Find(num);
				if (areaLink != null && areaLink != _applied)
				{
					Apply(areaLink);
				}
			}
		}
		else if (num != _lastLb)
		{
			_lastLb = num;
			AreaLink areaLink2 = Find(num);
			if (areaLink2 != null && areaLink2 != _applied)
			{
				Apply(areaLink2);
			}
		}
	}

	private static string NavText(AreaLink a)
	{
		if (!a.NavOn)
		{
			return "off";
		}
		if (a.NavMode == 1)
		{
			return "route " + ((a.NavRoute.Length > 0) ? a.NavRoute : "?");
		}
		return ((a.NavMode == 0) ? "spot " : "") + a.Nav;
	}

	public void Reset()
	{
		_lastLb = -1;
		_applied = null;
		_arrived = true;
	}

	public void Apply(AreaLink a)
	{
		_applied = a;
		List<string> list = new List<string>();
		if (!string.Equals(_s.ActiveProfile, a.Monster, StringComparison.OrdinalIgnoreCase) && _s.SwitchProfile(a.Monster))
		{
			list.Add("monsters: " + ((a.Monster.Length > 0) ? a.Monster : "(own list)"));
		}
		if (!string.Equals(_s.ExtraProfile[0], a.Extra1, StringComparison.OrdinalIgnoreCase))
		{
			_s.SetExtraProfile(0, a.Extra1);
			list.Add("list 2: " + ((a.Extra1.Length > 0) ? a.Extra1 : "off"));
		}
		if (!string.Equals(_s.ExtraProfile[1], a.Extra2, StringComparison.OrdinalIgnoreCase))
		{
			_s.SetExtraProfile(1, a.Extra2);
			list.Add("list 3: " + ((a.Extra2.Length > 0) ? a.Extra2 : "off"));
		}
		if (_s.AreaLoadNav)
		{
			bool flag = _s.NavSelected != a.Nav || _s.NavEnabled != a.NavOn;
			if (a.NavMode >= 0 && (_s.NavMode != a.NavMode || (a.NavMode == 1 && _s.NavRouteSelected != a.NavRoute)))
			{
				flag = true;
			}
			bool login = (DateTime.Now - _loginAt).TotalSeconds < 60.0;
			if (flag && login && a.NavOn && !_s.NavEnabled)
			{
				list.Add("Nav left off (just logged in)");
				flag = false;
			}
			if (flag)
			{
				_s.NavSelected = a.Nav;
				_s.NavEnabled = a.NavOn;
				if (a.NavMode >= 0)
				{
					_s.NavMode = a.NavMode;
					if (a.NavMode == 1 && a.NavRoute.Length > 0)
					{
						_s.NavRouteSelected = a.NavRoute;
					}
				}
				list.Add("Nav: " + NavText(a));
			}
		}
		if (_s.AreaLoadLoot)
		{
			bool flag2 = _s.LootUseGeneral != a.LootGeneral;
			_looter.SetSlotOn(0, a.LootGeneral);
			for (int i = 0; i < 5; i++)
			{
				if (_looter.SlotFile(i) != a.LootFiles[i])
				{
					_looter.SetSlotFile(i, a.LootFiles[i]);
					flag2 = true;
				}
				if (i > 0 && _looter.SlotOn(i) != a.LootOns[i])
				{
					_looter.SetSlotOn(i, a.LootOns[i]);
					flag2 = true;
				}
			}
			if (flag2)
			{
				list.Add("loot profiles");
			}
		}
		_s.RulesChanged();
		if (SaveAll != null)
		{
			SaveAll();
		}
		Util.WriteToChat("Area " + a.Name + ((list.Count > 0) ? (": loaded " + string.Join(", ", list.ToArray()) + ".") : ": already set up."));
	}

	private void Capture(AreaLink a, bool addHere)
	{
		a.Monster = _s.ActiveProfile ?? "";
		a.Extra1 = _s.ExtraProfile[0] ?? "";
		a.Extra2 = _s.ExtraProfile[1] ?? "";
		a.Nav = _s.NavSelected ?? "";
		a.NavOn = _s.NavEnabled;
		a.NavMode = _s.NavMode;
		a.NavRoute = _s.NavRouteSelected ?? "";
		a.LootGeneral = _looter.SlotOn(0);
		for (int i = 0; i < 5; i++)
		{
			a.LootFiles[i] = _looter.SlotFile(i);
			a.LootOns[i] = _looter.SlotOn(i);
		}
		int num = CurrentLandblock();
		if (addHere && num > 0)
		{
			foreach (AreaLink areaLink in _s.AreaLinks)
			{
				if (areaLink != a)
				{
					areaLink.Landblocks.Remove(num);
				}
			}
			if (!a.Landblocks.Contains(num))
			{
				a.Landblocks.Add(num);
			}
		}
		_applied = a;
	}

	private static string Lb(int lb)
	{
		return lb.ToString("X4");
	}

	public bool Draw()
	{
		bool flag = false;
		flag |= ImGui.Checkbox("Switch profiles by area", ref _s.AreasEnabled);
		Im.SetTooltipIfHovered("Arriving in a landblock you've linked below loads that area's monster lists.\n/mt set AreasEnabled on|off");
		ImGui.SameLine();
		flag |= ImGui.Checkbox("load its Nav (spot or route)", ref _s.AreaLoadNav);
		Im.SetTooltipIfHovered("/mt set AreaLoadNav on|off");
		ImGui.SameLine();
		flag |= ImGui.Checkbox("load its loot profiles", ref _s.AreaLoadLoot);
		Im.SetTooltipIfHovered("/mt set AreaLoadLoot on|off");
		flag |= ImGui.Checkbox("Only when I arrive (portal or login)", ref _s.AreasOnArrival);
		Im.SetTooltipIfHovered("On: an area is only loaded where you land - out of a portal, a gem, a recall / lifestone sending, or logging in.\nWalking from landblock to landblock never changes anything, so link just the landblocks you arrive in\n(e.g. where the T11 gem drops you and where the lifestone sending does - 'Add here' on the area's row in each).\nOff: any linked landblock you walk into loads its area.\n/mt set AreasOnArrival on|off");
		int num = CurrentLandblock();
		AreaLink areaLink = ((num > 0) ? Find(num) : null);
		Im.TextColored((areaLink != null) ? Green : Grey, "You're in landblock " + ((num > 0) ? Lb(num) : "?") + ((areaLink != null) ? (" - area " + areaLink.Name) : " - not linked"));
		ImGui.SetNextItemWidth(160f);
		ImGui.InputText("##areanew", ref _newName, 64u);
		ImGui.SameLine();
		if (ImGui.Button("New area here") && _newName.Trim().Length > 0)
		{
			AreaLink areaLink2 = new AreaLink
			{
				Name = _newName.Trim()
			};
			Capture(areaLink2, addHere: true);
			_s.AreaLinks.Add(areaLink2);
			_newName = "";
			flag = true;
			Util.WriteToChat("Area " + areaLink2.Name + ": linked landblock " + Lb(num) + " to your current monster lists, Nav (spot or route) and loot profiles.");
		}
		Im.SetTooltipIfHovered("Name it, then click: this landblock is linked to what you have set up right now -\nmonster lists, Nav (spot or route) and loot profiles. Walk into the area's other landblocks and click 'Add here' on its row.");
		AreaLink areaLink3 = null;
		if (_s.AreaLinks.Count > 0 && ImGui.BeginTable("areas", 6, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("Area", ImGuiTableColumnFlags.WidthFixed, 120f);
			ImGui.TableSetupColumn("Landblocks", ImGuiTableColumnFlags.WidthFixed, 75f);
			ImGui.TableSetupColumn("Monsters", ImGuiTableColumnFlags.WidthFixed, 120f);
			ImGui.TableSetupColumn("Nav", ImGuiTableColumnFlags.WidthFixed, 110f);
			ImGui.TableSetupColumn("Loot", ImGuiTableColumnFlags.WidthFixed, 130f);
			ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 190f);
			ImGui.TableHeadersRow();
			foreach (AreaLink areaLink4 in _s.AreaLinks)
			{
				ImGui.TableNextRow();
				ImGui.PushID(areaLink4.GetHashCode());
				ImGui.TableSetColumnIndex(0);
				Im.TextColored((areaLink4 == areaLink) ? Green : Vector4.One, areaLink4.Name);
				ImGui.TableSetColumnIndex(1);
				ImGui.TextUnformatted(areaLink4.Landblocks.Count + " block" + ((areaLink4.Landblocks.Count == 1) ? "" : "s"));
				List<string> list = new List<string>();
				foreach (int landblock in areaLink4.Landblocks)
				{
					list.Add(Lb(landblock));
				}
				Im.SetTooltipIfHovered(string.Join(", ", list.ToArray()));
				ImGui.TableSetColumnIndex(2);
				string text = ((areaLink4.Monster.Length > 0) ? areaLink4.Monster : "(own list)") + ((areaLink4.Extra1.Length > 0) ? (" + " + areaLink4.Extra1) : "") + ((areaLink4.Extra2.Length > 0) ? (" + " + areaLink4.Extra2) : "");
				ImGui.TextUnformatted(text);
				ImGui.TableSetColumnIndex(3);
				ImGui.TextUnformatted(NavText(areaLink4));
				ImGui.TableSetColumnIndex(4);
				List<string> list2 = new List<string>();
				if (areaLink4.LootGeneral)
				{
					if (areaLink4.LootFiles[0].Length > 0)
					{
						list2.Add(areaLink4.LootFiles[0]);
					}
				}
				else
				{
					for (int i = 1; i < 5; i++)
					{
						if (areaLink4.LootOns[i] && areaLink4.LootFiles[i].Length > 0)
						{
							list2.Add(areaLink4.LootFiles[i]);
						}
					}
				}
				string? text2;
				if (list2.Count != 0)
				{
					text2 = ((list2.Count == 1) ? list2[0] : (list2.Count + " profiles"));
				}
				else
				{
					text2 = "-";
				}
				ImGui.TextUnformatted(text2);
				Im.SetTooltipIfHovered(string.Join("\n", list2.ToArray()));
				ImGui.TableSetColumnIndex(5);
				if (num > 0 && !areaLink4.Landblocks.Contains(num))
				{
					if (ImGui.SmallButton("Add here"))
					{
						foreach (AreaLink areaLink5 in _s.AreaLinks)
						{
							areaLink5.Landblocks.Remove(num);
						}
						areaLink4.Landblocks.Add(num);
						flag = true;
					}
					Im.SetTooltipIfHovered("Add landblock " + Lb(num) + " to this area.");
					ImGui.SameLine();
				}
				if (ImGui.SmallButton("Update"))
				{
					Capture(areaLink4, addHere: false);
					flag = true;
					Util.WriteToChat("Area " + areaLink4.Name + ": updated to your current setup.");
				}
				Im.SetTooltipIfHovered("Save what you have set up right now (monster lists, Nav spot or route, loot profiles) as this area's.");
				ImGui.SameLine();
				if (ImGui.SmallButton("Load"))
				{
					Apply(areaLink4);
				}
				ImGui.SameLine();
				if (ImGui.SmallButton("x"))
				{
					areaLink3 = areaLink4;
				}
				ImGui.PopID();
			}
			ImGui.EndTable();
		}
		if (areaLink3 != null)
		{
			_s.AreaLinks.Remove(areaLink3);
			if (_applied == areaLink3)
			{
				_applied = null;
			}
			flag = true;
		}
		return flag;
	}
}
