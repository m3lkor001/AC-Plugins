using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using MelkTank.Metas;
using AcClient;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Bounties;
using MelkTank.Buffs;

namespace MelkTank;

public static partial class Session
{
	private static void NoteBank(string text)
	{
		Match match = BankRx.Match(text.Trim());
		if (match.Success)
		{
			string n = match.Groups["n"].Value.Trim();
			string value = match.Groups["v"].Value.Trim();
			BankLine bankLine = _bank.Find((BankLine x) => string.Equals(x.Name, n, StringComparison.OrdinalIgnoreCase));
			if (bankLine == null)
			{
				bankLine = new BankLine
				{
					Name = n
				};
				_bank.Add(bankLine);
			}
			bankLine.Value = value;
			bankLine.At = DateTime.Now;
			_bankDirtyAt = DateTime.Now;
			if (string.Equals(n, "Enlightened Coins", StringComparison.OrdinalIgnoreCase))
			{
				LumTrack.BankCoins(BankCount("Enlightened Coins"));
			}
			if (string.Equals(n, "Luminance", StringComparison.OrdinalIgnoreCase))
			{
				LumTrack.BankLum(BankLuminance());
			}
		}
	}

	private static int BankRank(string name)
	{
		string text = (name ?? "").ToLowerInvariant();
		if (text.Contains("weakly"))
		{
			return 2;
		}
		if (text.Contains("luminance"))
		{
			return 0;
		}
		if (text.Contains("enlightened coin"))
		{
			return 1;
		}
		if (text.Contains("pyreal"))
		{
			return 3;
		}
		if (text.Contains("enlightenment token"))
		{
			return 4;
		}
		if (text.Contains("prestige"))
		{
			return 5;
		}
		if (text.Contains("mythic"))
		{
			return 6;
		}
		if (text.Contains("legendary") || text.StartsWith("leg "))
		{
			return 7;
		}
		return 100;
	}

	private static List<BankLine> BankSorted()
	{
		List<BankLine> list = new List<BankLine>(_bank);
		List<KeyValuePair<int, BankLine>> list2 = new List<KeyValuePair<int, BankLine>>();
		for (int i = 0; i < list.Count; i++)
		{
			list2.Add(new KeyValuePair<int, BankLine>(i, list[i]));
		}
		list2.Sort((KeyValuePair<int, BankLine> a, KeyValuePair<int, BankLine> b) =>
		{
			int num = BankRank(a.Value.Name).CompareTo(BankRank(b.Value.Name));
			return (num != 0) ? num : a.Key.CompareTo(b.Key);
		});
		return list2.ConvertAll((KeyValuePair<int, BankLine> x) => x.Value);
	}

	private static void BankFileTick()
	{
		if (_bankDirtyAt == DateTime.MinValue || (DateTime.Now - _bankDirtyAt).TotalSeconds < 3.0 || _bankFile == null)
		{
			return;
		}
		_bankDirtyAt = DateTime.MinValue;
		try
		{
			StringBuilder stringBuilder = new StringBuilder("# MelkTank: the last /bank lines for this character (Session > Bank)\r\n");
			foreach (BankLine item in _bank)
			{
				stringBuilder.Append(item.Name.Replace("\t", " ")).Append('\t').Append(item.Value.Replace("\t", " "))
					.Append('\t')
					.Append(item.At.Ticks)
					.Append("\r\n");
			}
			Util.WriteShared(_bankFile, stringBuilder.ToString());
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void LoadBank()
	{
		_bank.Clear();
		if (_bankFile == null || !File.Exists(_bankFile))
		{
			return;
		}
		try
		{
			string[] array = Util.Locked(_bankFile, () => File.ReadAllLines(_bankFile));
			foreach (string text in array)
			{
				if (!text.StartsWith("#"))
				{
					string[] array2 = text.Split('\t');
					if (array2.Length >= 3 && long.TryParse(array2[2], out var result))
					{
						_bank.Add(new BankLine
						{
							Name = array2[0],
							Value = array2[1],
							At = new DateTime(result)
						});
					}
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void DrawBank()
	{
		if (ImGui.Button("Check /bank"))
		{
			QuietNext("/bank");
			Util.Command("/bank");
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Asks the server for your bank (the lines may be hidden in chat by the chat filter - they're still read here).");
		}
		// (polling the bank: Session > Lum > Settings now - one poller for the bank tab, lum/hr and coins/hr)
		Settings bs = PluginCore.CurrentSettings;
		DateTime dateTime = DateTime.MinValue;
		foreach (BankLine item in _bank)
		{
			if (item.At > dateTime)
			{
				dateTime = item.At;
			}
		}
		if (_bank.Count > 0)
		{
			ImGui.SameLine();
			Im.TextDisabled("as of " + ((dateTime.Date == DateTime.Today) ? dateTime.ToString("HH:mm") : dateTime.ToString("MM-dd HH:mm")));
		}
		ImGui.SameLine();
		if (ImGui.Button("/b d##bankdep"))
		{
			Util.Command("/b d");
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("/b d - puts what you carry that the bank takes (pyreals, luminance, coins, keys...) into the bank.");
		}
		ImGui.SameLine();
		if (ImGui.Button("/clap all##bankclap"))
		{
			Util.Command("/clap all");
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Sends /clap all.");
		}
		if (bs != null)
		{
			DrawTransfer(bs);
		}
		if (_bank.Count == 0)
		{
			Im.TextDisabled("Nothing yet - click Check /bank.");
			return;
		}
		if (!ImGui.BeginTable("banklist", 2, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY, new Vector2(0f, 0f)))
		{
			return;
		}
		ImGui.TableSetupColumn("Item", ImGuiTableColumnFlags.WidthFixed, 230f);
		ImGui.TableSetupColumn("In the bank", ImGuiTableColumnFlags.WidthStretch);
		ImGui.TableSetupScrollFreeze(0, 1);
		ImGui.TableHeadersRow();
		foreach (BankLine item2 in BankSorted())
		{
			if (true)
			{
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				Im.TextColored(Cyan, item2.Name);
				ImGui.TableSetColumnIndex(1);
				ImGui.TextUnformatted(item2.Value);
			}
		}
		ImGui.EndTable();
	}

	// ---------------------------------------------------------------- transfers (/b t)
	private static string _xferName = "";

	private static string _xferAmount = "";

	private static DateTime _xferConfirmUntil = DateTime.MinValue;

	private static string _xferConfirmWhat = "";

	/// <summary>"1100", "1,100", "1.1k", "2b", "3.5m", "1t" as a whole number (0: not one).</summary>
	public static long ParseAmount(string s)
	{
		s = (s ?? "").Trim().Replace(",", "").Replace("_", "").Replace(" ", "").ToLowerInvariant();
		if (s.Length == 0)
		{
			return 0L;
		}
		double mult = 1.0;
		char last = s[s.Length - 1];
		switch (last)
		{
		case 'k':
			mult = 1e3;
			break;
		case 'm':
			mult = 1e6;
			break;
		case 'b':
			mult = 1e9;
			break;
		case 't':
			mult = 1e12;
			break;
		}
		if (mult > 1.0)
		{
			s = s.Substring(0, s.Length - 1);
		}
		if (!double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out var v) || v <= 0.0 || double.IsInfinity(v))
		{
			return 0L;
		}
		double total = Math.Round(v * mult);
		return (total >= 9.2e18) ? 0L : (long)total;
	}

	private static List<string> XferNames(Settings s)
	{
		List<string> list = new List<string>();
		foreach (string part in (s.BankXferNames ?? "").Split('|'))
		{
			string n = part.Trim();
			if (n.Length > 0 && !list.Exists((string x) => x.Equals(n, StringComparison.OrdinalIgnoreCase)))
			{
				list.Add(n);
			}
		}
		return list;
	}

	private static void RememberXferName(Settings s, string name)
	{
		List<string> list = XferNames(s);
		list.RemoveAll((string x) => x.Equals(name, StringComparison.OrdinalIgnoreCase));
		list.Insert(0, name);
		if (list.Count > 8)
		{
			list.RemoveRange(8, list.Count - 8);
		}
		s.BankXferNames = string.Join("|", list);
		PluginCore.SaveAllNow();
	}

	/// <summary>The Lum pop-out's Tx tab: one character, and a button each for all the coins and all the luminance
	/// (the same names as the transfer above; each sends on a second click within 5 s).</summary>
	public static void DrawTransferAll(Settings s)
	{
		List<string> names = XferNames(s);
		if (_xferName.Length == 0 && names.Count > 0)
		{
			_xferName = names[0];
		}
		Im.TextColored(Cyan, "To");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(170f);
		ImGui.InputTextWithHint("##popxfername", "character", ref _xferName, 64u);
		ImGui.SameLine(0f, 2f);
		if (ImGui.BeginCombo("##popxferrecent", "", ImGuiComboFlags.NoPreview))
		{
			if (names.Count == 0)
			{
				Im.TextDisabled("no one yet");
			}
			foreach (string n in names)
			{
				if (ImGui.Selectable(n + "##popxfn", n.Equals(_xferName, StringComparison.OrdinalIgnoreCase)))
				{
					_xferName = n;
				}
			}
			ImGui.EndCombo();
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("The last few you've sent to.");
		}
		string name = _xferName.Trim().Trim('"');
		bool ok = name.Length > 0;
		foreach (var (kind, label) in new[] { ("e", "coins"), ("l", "lum") })
		{
			string what = "all " + kind + " " + name;
			bool armed = DateTime.Now < _xferConfirmUntil && _xferConfirmWhat == what;
			if (!ok)
			{
				ImGui.BeginDisabled();
			}
			if (ImGui.Button((armed ? "Send all " + label + "?" : "Transfer all " + label) + "##popxfer" + kind, new Vector2(150f, 0f)))
			{
				if (!armed)
				{
					_xferConfirmUntil = DateTime.Now.AddSeconds(5.0);
					_xferConfirmWhat = what;
				}
				else
				{
					_xferConfirmUntil = DateTime.MinValue;
					Remote.TransferAll(kind, name);
					RememberXferName(s, name);
				}
			}
			if (!ok)
			{
				ImGui.EndDisabled();
			}
			if (ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenDisabled))
			{
				Im.SetTooltip(ok ? ("All the " + (kind == "e" ? "Enlightened Coins" : "luminance") + " in the bank to " + name + " (it checks /bank first; the server keeps 1) - click again to send.") : "A name first.");
			}
			if (kind == "e") ImGui.SameLine();
		}
	}

	private static void DrawTransfer(Settings s)
	{
		Im.TextColored(Cyan, "Transfer");
		ImGui.SameLine();
		List<string> names = XferNames(s);
		if (_xferName.Length == 0 && names.Count > 0)
		{
			_xferName = names[0];
		}
		ImGui.SetNextItemWidth(160f);
		ImGui.InputTextWithHint("##xfername", "character", ref _xferName, 64u);
		ImGui.SameLine(0f, 2f);
		if (ImGui.BeginCombo("##xferrecent", "", ImGuiComboFlags.NoPreview))
		{
			if (names.Count == 0)
			{
				Im.TextDisabled("no one yet");
			}
			foreach (string n in names)
			{
				if (ImGui.Selectable(n + "##xfn", n.Equals(_xferName, StringComparison.OrdinalIgnoreCase)))
				{
					_xferName = n;
				}
			}
			ImGui.EndCombo();
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("The last few you've sent to.");
		}
		ImGui.SameLine();
		IReadOnlyDictionary<string, string> kinds = Remote.Transferable;
		if (!kinds.ContainsKey(s.BankXferKind ?? ""))
		{
			s.BankXferKind = "l";
		}
		ImGui.SetNextItemWidth(190f);
		if (ImGui.BeginCombo("##xferkind", kinds[s.BankXferKind]))
		{
			foreach (KeyValuePair<string, string> k in kinds)
			{
				if (ImGui.Selectable(k.Value + "##xfk", k.Key == s.BankXferKind))
				{
					s.BankXferKind = k.Key;
					PluginCore.SaveAllNow();
				}
			}
			ImGui.EndCombo();
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(110f);
		ImGui.InputTextWithHint("##xferamt", "how much", ref _xferAmount, 32u);
		long amount = ParseAmount(_xferAmount);
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("A whole number - 1100, 1,100, 1.1k, 2.5m, 2b, 1t." + ((amount > 0) ? ("\n= " + amount.ToString("N0")) : ""));
		}
		string name = _xferName.Trim().Trim('"');
		bool ok = name.Length > 0;
		ImGui.SameLine();
		// (a second click within 5 s sends it: nothing goes off on one stray click)
		string what = amount + " " + s.BankXferKind + " " + name;
		bool armed = DateTime.Now < _xferConfirmUntil && _xferConfirmWhat == what;
		if (!ok || amount <= 0)
		{
			ImGui.BeginDisabled();
		}
		if (ImGui.Button((armed ? "Send " + amount.ToString("N0") + "?" : "Transfer") + "##xfergo"))
		{
			if (!armed)
			{
				_xferConfirmUntil = DateTime.Now.AddSeconds(5.0);
				_xferConfirmWhat = what;
			}
			else
			{
				_xferConfirmUntil = DateTime.MinValue;
				Util.Command("/b t " + s.BankXferKind + " " + amount.ToString(CultureInfo.InvariantCulture) + " \"" + name + "\"");
				RememberXferName(s, name);
			}
		}
		if (!ok || amount <= 0)
		{
			ImGui.EndDisabled();
		}
		if (ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenDisabled))
		{
			Im.SetTooltip((ok && amount > 0) ? ("/b t " + s.BankXferKind + " " + amount + " \"" + name + "\" - click again to send.") : "A name and how much first.");
		}
		ImGui.SameLine();
		string whatAll = "all " + s.BankXferKind + " " + name;
		bool armedAll = DateTime.Now < _xferConfirmUntil && _xferConfirmWhat == whatAll;
		if (!ok)
		{
			ImGui.BeginDisabled();
		}
		if (ImGui.Button((armedAll ? "Send all?" : "All") + "##xferall"))
		{
			if (!armedAll)
			{
				_xferConfirmUntil = DateTime.Now.AddSeconds(5.0);
				_xferConfirmWhat = whatAll;
			}
			else
			{
				_xferConfirmUntil = DateTime.MinValue;
				Remote.TransferAll(s.BankXferKind, name);
				RememberXferName(s, name);
			}
		}
		if (!ok)
		{
			ImGui.EndDisabled();
		}
		if (ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenDisabled))
		{
			Im.SetTooltip("Everything of that kind in the bank (it checks /bank first; the server keeps 1) - click again to send.");
		}
	}
}
