using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
#if !RETAIL
using ACGodot.DecalShim;
using ACGodot.Plugins;
using ACGodot.UI;
#endif
#if !RETAIL
using AcClient;
#else
using SmartBox = AcClient.SmartBox;
using ACCmdInterp = AcClient.ACCmdInterp;
using CommandInterpreter = AcClient.CommandInterpreter;
using CommandListElement = AcClient.CommandListElement;
using CPhysicsObj = AcClient.CPhysicsObj;
using Position = AcClient.Position;
using CTransition = AcClient.CTransition;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
#if !RETAIL
using Godot;
#endif
using ImGuiNET;
using MelkTank.Loot;
using MelkTank.Metas;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public partial class Nav
{
	private void DrawRoutesTab()
	{
		bool flag = false;
		int current_item = _s.NavMode;
		ImGui.SetNextItemWidth(170f);
		if (ImGui.Combo("Nav mode##navmode", ref current_item, new string[3] { "Stay on a spot", "Follow a route", "Follow a player" }, 3))
		{
			_s.NavMode = current_item;
			Stop();
			RouteReset();
			flag = true;
		}
		Tip("Stay on a spot: run back to one saved spot.\nFollow a route: walk a list of points, commands, portals / NPCs, waits - once, back and forth, or round and round.");
		if (_s.NavMode == 2)
		{
			if ((flag | DrawFollow()) && SaveAll != null)
			{
				SaveAll();
			}
			return;
		}
		if (_s.NavMode == 1)
		{
			flag |= DrawRoute();
			if (flag)
			{
				RouteChanged();
			}
			if (flag && SaveAll != null)
			{
				SaveAll();
			}
			return;
		}
		NavSpot current = Current;
		List<string> list = new List<string>();
		foreach (NavSpot navSpot2 in _s.NavSpots)
		{
			list.Add(navSpot2.Name);
		}
		int num = list.FindIndex((string a) => string.Equals(a, _s.NavSelected, StringComparison.OrdinalIgnoreCase));
		string[] array = ((list.Count != 0) ? list.ToArray() : new string[1] { "(no spots yet)" });
		int current_item2 = ((num >= 0) ? num : 0);
		ImGui.SetNextItemWidth(220f);
		if (ImGui.Combo("Spot##navspot", ref current_item2, array, array.Length) && list.Count > 0)
		{
			_s.NavSelected = list[current_item2];
			flag = true;
			_lastHeadingFix = DateTime.MinValue;
		}
		ImGui.SameLine();
		if (current != null && ImGui.Button("Delete##navdel"))
		{
			_s.NavSpots.Remove(current);
			_s.NavSelected = ((_s.NavSpots.Count > 0) ? _s.NavSpots[0].Name : "");
			Stop();
			flag = true;
			current = Current;
		}
		ImGui.SetNextItemWidth(220f);
		ImGui.InputText("Name##navname", ref _newName, 64u);
		ImGui.SameLine();
		if (ImGui.Button("Save spot here"))
		{
			string n;
			if (_newName.Trim().Length > 0)
			{
				n = _newName.Trim();
			}
			else
			{
				n = ((current != null) ? current.Name : ("Spot " + (_s.NavSpots.Count + 1)));
			}
			if (!MyPos(out var ns, out var ew, out var z))
			{
				Util.WriteToChat("Nav: couldn't read your position.");
			}
			else
			{
				NavSpot navSpot = _s.NavSpots.Find((NavSpot x) => string.Equals(x.Name, n, StringComparison.OrdinalIgnoreCase));
				if (navSpot == null)
				{
					navSpot = new NavSpot
					{
						Name = n,
						FaceHeading = _s.NavFaceHeading
					};
					_s.NavSpots.Add(navSpot);
				}
				navSpot.NS = ns;
				navSpot.EW = ew;
				navSpot.Z = z;
				navSpot.Heading = CombatEngine.MyHeading();
				_s.NavSelected = n;
				_newName = "";
				flag = true;
				Util.WriteToChat("Nav: saved '" + n + "' here (" + Loc(navSpot) + ", facing " + navSpot.Heading.ToString("0") + ").");
			}
		}
		Tip("Saves where you're standing and the way you're facing. Type a name for a new spot;\nleave it empty to update the selected spot.");
		if (current != null)
		{
			ImGui.SameLine();
			if (ImGui.Button("Rename##navren") && _newName.Trim().Length > 0)
			{
				current.Name = _newName.Trim();
				_s.NavSelected = current.Name;
				_newName = "";
				flag = true;
			}
			ImGui.SameLine();
			if (ImGui.Button("Face now##navface") && current.Heading >= 0.0)
			{
				try
				{
					Globals.Core.Actions.FaceHeading(current.Heading, true);
				}
				catch
				{
				}
			}
			ImGui.SameLine();
			if (ImGui.Button("Update heading##navhd"))
			{
				current.Heading = CombatEngine.MyHeading();
				flag = true;
			}
			Tip("Saves the way you're facing now for this spot (position unchanged).");
		}
		ImGui.Separator();
		flag |= ImGui.Checkbox("Return to spot", ref _s.NavEnabled);
		Tip("When nothing needs fighting or looting and you're further than 'drift allowed' from the spot,\nface it and run back.\n/mt set NavEnabled on|off");
		ImGui.SameLine(0f, 20f);
		flag |= ImGui.Checkbox("Return first (before fighting / looting)", ref _s.NavPriority);
		Tip("Runs back as soon as you've drifted, even with monsters in range or corpses to loot.\n/mt set NavPriority on|off");
		flag |= ImGui.Checkbox("Pick the spot from the chamber message", ref _s.NavChamberSpots);
		Tip("Lum / coin dungeons say which chamber you're in when you portal or log in there.\nThe spot named for it is picked - one ending in C + the number (IdolC3, BansheeC7),\nthe nearest if several match. No spot for that chamber: Nav is turned off.\n/mt set NavChamberSpots on|off");
		ImGui.SetNextItemWidth(110f);
		flag |= ImGui.InputFloat("Drift allowed (m)", ref _s.NavDrift, 0.5f, 1f, "%.1f");
		Im.SetTooltipIfHovered("/mt set NavDrift <number>");
		if (_s.NavDrift < 0.5f)
		{
			_s.NavDrift = 0.5f;
		}
		if (current != null)
		{
			flag |= ImGui.Checkbox("Face the saved heading when back##face" + current.Name, ref current.FaceHeading);
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Saved with this spot (" + current.Name + ") - each spot has its own.");
			}
		}
		ImGui.Separator();
		if (current == null)
		{
			Im.TextColored(Grey, "No spot selected - stand where you want to be, type a name and click Save spot here.");
		}
		else
		{
			double num2 = DistanceTo(current);
			Im.TextColored(Cyan, current.Name + ":  " + Loc(current) + ((current.Heading >= 0.0) ? ("  facing " + current.Heading.ToString("0")) : ""));
			System.Numerics.Vector4 col;
			if (num2 < 0.0)
			{
				col = Grey;
			}
			else
			{
				col = ((num2 <= (double)_s.NavDrift) ? Green : Yellow);
			}
			Im.TextColored(col, (num2 < 0.0) ? "Distance: ?" : ("Distance: " + num2.ToString("0.0") + " m"));
			if (!string.IsNullOrEmpty(Status))
			{
				ImGui.SameLine(0f, 20f);
				Im.TextColored(_running ? Yellow : Grey, Status);
			}
		}
		if (flag)
		{
			SpotChanged();
		}
		if (flag && SaveAll != null)
		{
			SaveAll();
		}
	}

	private bool DrawNavSettings()
	{
		bool flag = false;
		ImGui.Indent(8f);
		ImGui.SetNextItemWidth(100f);
		flag |= ImGui.InputFloat("Stop and turn when the route bends this much or more (degrees)", ref _s.NavTurnAngle, 5f, 15f, "%.0f");
		Im.SetTooltipIfHovered("/mt set NavTurnAngle <number>");
		if (_s.NavTurnAngle < 10f)
		{
			_s.NavTurnAngle = 10f;
		}
		if (_s.NavTurnAngle > 180f)
		{
			_s.NavTurnAngle = 180f;
		}
		Tip("At a route point, if the next one is this far off the way you're running, stop and turn first.\nLess than this: keep running and steer onto it. Also: running off course by this much stops and turns.");
		ImGui.SetNextItemWidth(100f);
		flag |= ImGui.InputFloat("Don't run to a spot / point further than (m)", ref _s.NavMaxRunM, 100f, 500f, "%.0f");
		Im.SetTooltipIfHovered("/mt set NavMaxRunM <number>");
		if (_s.NavMaxRunM < 100f)
		{
			_s.NavMaxRunM = 100f;
		}
		Tip("Further than this, you're somewhere else (portalled away, logged in elsewhere): Nav doesn't try to run there -\nit says so once and waits, and carries on by itself once you're back within this distance.");
		flag |= DrawDoorSettings();
		flag |= ImGui.Checkbox("Steer while running", ref _s.NavSmoothSteer);
		Im.SetTooltipIfHovered("/mt set NavSteerWhileRunning on|off");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		flag |= ImGui.InputFloat("deg off before turning##navsteerdb", ref _s.NavSteerDeadband, 1f, 5f, "%.0f");
		Im.SetTooltipIfHovered("/mt set NavSteerDeadband <number>");
		if (_s.NavSteerDeadband < 1f)
		{
			_s.NavSteerDeadband = 1f;
		}
		if (_s.NavSteerDeadband > 45f)
		{
			_s.NavSteerDeadband = 45f;
		}
		Tip("Steering while running holds turn left / right (like A / D) until you face the next point, checked every frame.\nThis is how far off you can be before a turn starts; once turning, it carries on until you face the point.\nLower: tighter lines, more frequent turns. Higher: fewer, bigger turns and straighter runs.");
		Tip("While running, turn the way a player does - holding turn left / turn right (A / D) while still running -\ninstead of the game's turn-to-heading, which stops the run and has to restart it. Corners under the angle\nabove are taken without stopping. If the run stops anyway, it's restarted as before and the debug log says\n\"[right after a direct steer]\".");
		ImGui.SetNextItemWidth(100f);
		flag |= ImGui.InputFloat("Next point counts as close within (m)", ref _s.NavCloseDist, 0.5f, 2f, "%.1f");
		Im.SetTooltipIfHovered("/mt set NavCloseDist <number>");
		if (_s.NavCloseDist < 0f)
		{
			_s.NavCloseDist = 0f;
		}
		ImGui.SetNextItemWidth(100f);
		flag |= ImGui.InputFloat("...and then stop and turn from (degrees)", ref _s.NavCloseAngle, 5f, 15f, "%.0f");
		Im.SetTooltipIfHovered("/mt set NavCloseAngle <number>");
		if (_s.NavCloseAngle < 0f)
		{
			_s.NavCloseAngle = 0f;
		}
		if (_s.NavCloseAngle > 180f)
		{
			_s.NavCloseAngle = 180f;
		}
		Tip("A close next point is easy to run past while steering, so a smaller bend is enough to stop and turn.");
		ImGui.Unindent(8f);
		return flag;
	}

	private static string Loc(NavSpot p)
	{
		return Math.Abs(p.NS).ToString("0.000") + ((p.NS >= 0.0) ? "N" : "S") + ", " + Math.Abs(p.EW).ToString("0.000") + ((p.EW >= 0.0) ? "E" : "W");
	}

	private static void Tip(string text)
	{
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip(text);
		}
	}
}
