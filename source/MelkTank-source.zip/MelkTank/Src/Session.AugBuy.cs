using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using MelkTank.Metas;
using AcClient;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Bounties;
using MelkTank.Buffs;

namespace MelkTank;

public static partial class Session
{
	private static void AugsTick()
	{
		if (!(_augRecheckAt == DateTime.MinValue) && !(DateTime.Now < _augRecheckAt))
		{
			_augRecheckAt = DateTime.MinValue;
			QuietNext("/aug");
			Util.Command("/aug");
			QuietNext("/bank");
			Util.Command("/bank");
		}
	}

	private static long AugLevel(AugKind k)
	{
		foreach (KeyValuePair<string, string> aug in _augs)
		{
			if (string.Equals(aug.Key, k.Key, StringComparison.OrdinalIgnoreCase))
			{
				string text = aug.Value;
				int num = text.IndexOf(' ');
				if (num > 0)
				{
					text = text.Substring(0, num);
				}
				if (long.TryParse(text.Replace(",", ""), out var result))
				{
					return result;
				}
			}
		}
		return -1L;
	}

	public static int EligibleTier()
	{
		long num = -1L;
		long num2 = -1L;
		long num3 = -1L;
		AugKind[] augKinds = AugKinds;
		foreach (AugKind augKind in augKinds)
		{
			if (augKind.Key == "Creature")
			{
				num = AugLevel(augKind);
			}
			else if (augKind.Key == "Life")
			{
				num2 = AugLevel(augKind);
			}
			else if (augKind.Key == "Item")
			{
				num3 = AugLevel(augKind);
			}
		}
		if (num < 0 || num2 < 0 || num3 < 0)
		{
			return -1;
		}
		long num4 = Math.Min((num - 4000) / 500, Math.Min((num2 - 2000) / 500, (num3 - 2000) / 500));
		if (num < 4000 || num2 < 2000 || num3 < 2000)
		{
			return 0;
		}
		return (int)Math.Min(25L, 11 + num4);
	}

	/// <summary>Luminance in the bank as /bank last said (-1: not read yet).</summary>
	public static long BankedLum { get { long v = BankLuminance(); return (v > 0 || _bank.Exists(b => string.Equals(b.Name, "Luminance", StringComparison.OrdinalIgnoreCase))) ? v : -1; } }

	/// <summary>Enlightened Coins in the bank as /bank last said (-1: not read yet).</summary>
	public static long BankedCoins { get { long v = BankCount("Enlightened Coins"); return (v > 0 || _bank.Exists(b => string.Equals(b.Name, "Enlightened Coins", StringComparison.OrdinalIgnoreCase))) ? v : -1; } }

	private static long BankLuminance()
	{
		foreach (BankLine item in _bank)
		{
			if (string.Equals(item.Name, "Luminance", StringComparison.OrdinalIgnoreCase))
			{
				string text = item.Value;
				int num = text.IndexOf(' ');
				if (num > 0)
				{
					text = text.Substring(0, num);
				}
				if (long.TryParse(text.Replace(",", ""), out var result))
				{
					return result;
				}
			}
		}
		return -1L;
	}

	private static long AugMultiplier(AugKind k, long target)
	{
		if (k.Caps == null)
		{
			return 1L;
		}
		long[] array = new long[4] { 4L, 8L, 16L, 24L };
		long result = 1L;
		for (int i = 0; i < k.Caps.Length && i < array.Length; i++)
		{
			if (target > k.Caps[i])
			{
				result = array[i];
			}
		}
		return result;
	}

	private static long LevelBase(AugKind k, long target)
	{
		if (k.Tab == "Specialization")
		{
			return 9025000 * (target - 1);
		}
		return 1650000 * target - 650000;
	}

	private static long AugCost(AugKind k, long from, long levels)
	{
		double num = AugScale(k);
		return (long)Math.Round((double)AugCostRaw(k, from, levels) * num);
	}

	private static long AugCostRaw(AugKind k, long from, long levels)
	{
		long num = 0L;
		for (long num2 = 1L; num2 <= levels; num2++)
		{
			num += AugMultiplier(k, from + num2) * LevelBase(k, from + num2);
		}
		return num;
	}

	private static double AugScale(AugKind k)
	{
		if (!AugQuotes.TryGetValue(k.Key, out var value))
		{
			return 1.0;
		}
		long num = AugCostRaw(k, value.Level, value.Levels);
		return (num > 0) ? ((double)value.Lum / (double)num) : 1.0;
	}

	public static void NoteConfirmText(string text)
	{
		try
		{
			Match match = AugQuoteRx.Match(text ?? "");
			if (!match.Success)
			{
				return;
			}
			long lum = long.Parse(match.Groups[1].Value.Replace(",", ""));
			long num = long.Parse(match.Groups[2].Value.Replace(",", ""));
			string value = match.Groups[3].Value;
			AugKind augKind = null;
			AugKind[] augKinds = AugKinds;
			foreach (AugKind augKind2 in augKinds)
			{
				if (value.IndexOf(augKind2.Gem, StringComparison.OrdinalIgnoreCase) >= 0 || value.IndexOf(augKind2.Key, StringComparison.OrdinalIgnoreCase) >= 0)
				{
					augKind = augKind2;
					break;
				}
			}
			if (augKind == null)
			{
				return;
			}
			long num2 = AugLevel(augKind);
			if (num2 < 0 || num <= 0)
			{
				return;
			}
			AugQuotes[augKind.Key] = new AugQuote
			{
				Level = num2,
				Levels = num,
				Lum = lum
			};
			List<string> list = new List<string>();
			foreach (KeyValuePair<string, AugQuote> augQuote in AugQuotes)
			{
				list.Add(augQuote.Key + "|" + augQuote.Value.Level + "|" + augQuote.Value.Levels + "|" + augQuote.Value.Lum);
			}
			try
			{
				File.WriteAllLines(AugQuoteFile, list.ToArray());
			}
			catch
			{
			}
		}
		catch
		{
		}
	}

	private static List<WorldObject> Gems(AugKind k, int size)
	{
		List<WorldObject> list = new List<WorldObject>();
		string value = ((size == 1) ? "" : (size + "x "));
		foreach (WorldObject item in InvCache.All())
		{
			string text = item.Name ?? "";
			if (text.EndsWith("Augmentation Gem", StringComparison.OrdinalIgnoreCase) && !text.StartsWith("Boxed", StringComparison.OrdinalIgnoreCase) && text.IndexOf(k.Gem, StringComparison.OrdinalIgnoreCase) >= 0)
			{
				bool flag = Regex.IsMatch(text, "^\\d+x ");
				if (!((size == 1) ? flag : (!text.StartsWith(value, StringComparison.OrdinalIgnoreCase))))
				{
					list.Add(item);
				}
			}
		}
		return list;
	}

	private static Dictionary<int, WorldObject> VendorGems(AugKind k)
	{
		Dictionary<int, WorldObject> dictionary = new Dictionary<int, WorldObject>();
		try
		{
			Vendor openVendor = CoreManager.Current.WorldFilter.OpenVendor;
			if (openVendor == null || openVendor.MerchantId == 0)
			{
				return dictionary;
			}
			foreach (WorldObject item in openVendor)
			{
				string text = item.Name ?? "";
				if (text.EndsWith("Augmentation Gem", StringComparison.OrdinalIgnoreCase) && !text.StartsWith("Boxed", StringComparison.OrdinalIgnoreCase) && text.IndexOf(k.Gem, StringComparison.OrdinalIgnoreCase) >= 0)
				{
					int result = 1;
					Match match = Regex.Match(text, "^(\\d+)x ");
					if (match.Success)
					{
						int.TryParse(match.Groups[1].Value, out result);
					}
					if (result > 0 && !dictionary.ContainsKey(result))
					{
						dictionary[result] = item;
					}
				}
			}
		}
		catch
		{
		}
		return dictionary;
	}

	private static long HeldGemLevels(AugKind k)
	{
		long num = 0L;
		int[] gemSizes = GemSizes;
		foreach (int num2 in gemSizes)
		{
			foreach (WorldObject item in Gems(k, num2))
			{
				int num3 = 1;
				try
				{
					num3 = Math.Max(1, item.Values(LongValueKey.StackCount, 1));
				}
				catch
				{
				}
				num += (long)num2 * (long)num3;
			}
		}
		return num;
	}

	private static long LevelsFor(AugKind k, long level, long lum)
	{
		long num = 0L;
		long num2 = 0L;
		for (; num < 100000; num++)
		{
			long num3 = AugMultiplier(k, level + num + 1) * LevelBase(k, level + num + 1);
			if (num2 + num3 > lum)
			{
				break;
			}
			num2 += num3;
		}
		return num;
	}

	private static void DrawAugBuy(AugKind k, long level, long lum, long coinsHave)
	{
		Dictionary<int, WorldObject> dictionary = VendorGems(k);
		if (dictionary.Count == 0)
		{
			return;
		}
		long num = HeldGemLevels(k);
		Settings currentSettings = PluginCore.CurrentSettings;
		bool flag = k.Tab == "Specialization";
		if (!flag && currentSettings != null && currentSettings.AugNoSingles && dictionary.Count > 1)
		{
			dictionary.Remove(1);
		}
		Im.Text("Vendor:");
		ImGui.SameLine();
		if (lum < 0)
		{
			Im.TextDisabled("luminance not known - check /bank");
		}
		else
		{
			long num2 = LevelsFor(k, level, lum);
			long need = Math.Max(0L, num2 - num);
			AugBuyButton(k, dictionary, need, "lum", level + num, "As many levels as your bank luminance (" + Big(lum) + ") pays to use: " + num2.ToString("N0") + ((num > 0) ? (", less the " + num.ToString("N0") + " in gems you carry") : "") + ".", (num2 <= num) ? ("your luminance pays for " + num2.ToString("N0") + " levels" + ((num > 0) ? (" - you carry gems for " + num.ToString("N0")) : "")) : null);
		}
		ImGui.SameLine(0f, 24f);
		if (coinsHave < 0 || k.Coins <= 0)
		{
			Im.TextDisabled("coins not known - check /bank");
		}
		else
		{
			long num3 = coinsHave / k.Coins;
			AugBuyButton(k, dictionary, num3, "coins", level + num, "As many levels as your bank coins (" + coinsHave.ToString("N0") + ") buy, at " + k.Coins + " coins a level: " + num3.ToString("N0") + ".", (num3 <= 0) ? ("not enough coins for one level (" + k.Coins + ")") : null);
		}
		if (!flag && currentSettings != null)
		{
			ImGui.SameLine(0f, 24f);
			if (ImGui.Checkbox("No singles##augns", ref currentSettings.AugNoSingles))
			{
				PluginCore.SaveAllNow();
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Don't buy 1-level gems: only 10x and up (what's left under 10 isn't bought).\nEvery tab except Specialization, which always buys singles.");
			}
		}
	}

	private static void AugBuyButton(AugKind k, Dictionary<int, WorldObject> vg, long need, string tag, long fromLevel, string why, string nothing)
	{
		List<int> list = new List<int>(vg.Keys);
		list.Sort((int x, int y) => y.CompareTo(x));
		List<KeyValuePair<WorldObject, int>> list2 = new List<KeyValuePair<WorldObject, int>>();
		List<string> list3 = new List<string>();
		long num = need;
		foreach (int item in list)
		{
			long num2 = num / item;
			if (num2 > 0)
			{
				list2.Add(new KeyValuePair<WorldObject, int>(vg[item], (int)Math.Min(num2, 2147483647L)));
				list3.Add(num2.ToString("N0") + " x " + ((item == 1) ? "1" : (item + "x")));
				num -= num2 * item;
			}
		}
		long num3 = need - num;
		if (num3 <= 0)
		{
			Im.TextDisabled("(" + tag + ": " + (nothing ?? "nothing to buy") + ")");
			return;
		}
		if (ImGui.Button("Buy " + num3.ToString("N0") + " levels (" + tag + ")##augbuy" + tag + k.Tab))
		{
			try
			{
				HooksWrapper actions = CoreManager.Current.Actions;
				actions.VendorClearBuyList();
				foreach (KeyValuePair<WorldObject, int> item2 in list2)
				{
					actions.VendorAddBuyList(item2.Key.Id, item2.Value);
				}
				actions.VendorBuyAll();
				Util.WriteToChat("Augs: buying " + string.Join(", ", list3.ToArray()) + " " + k.Gem + " gems (" + num3.ToString("N0") + " levels).");
				_augRecheckAt = DateTime.Now.AddSeconds(2.5);
			}
			catch (Exception ex)
			{
				Util.WriteToChat("Augs: " + ex.Message);
			}
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip(why + "\nGems: " + string.Join(" + ", list3.ToArray()) + "\nUsing them costs " + Big(AugCost(k, fromLevel, num3)) + " luminance, buying them " + (num3 * k.Coins).ToString("N0") + " coins.");
		}
	}

	private static string Eta(double hours)
	{
		if (hours < 1.0)
		{
			return "~" + Math.Max(1, (int)Math.Round(hours * 60.0)) + "m";
		}
		if (hours < 24.0)
		{
			return "~" + Math.Round(hours, 1) + "h";
		}
		int num = (int)(hours / 24.0);
		return "~" + num + "d " + (int)Math.Round(hours - (double)num * 24.0) + "h";
	}

	// Session > Lum's conversion: the luminance a coin costs (buying one)
	private static double CoinLum()
	{
		return LumTrack.LumPerCoinBuy;
	}

	// Session > Lum's effective lum/hr (coins earned counted as luminance)
	private static double TrackerRate()
	{
		double r = LumTrack.EffectiveLumPerHour;
		return (r > 0.0) ? r : (-1.0);
	}

	// Session > Lum's lum/hr (with turn-ins that give luminance)
	private static double TrackerLumRate()
	{
		double r = LumTrack.LumPerHour;
		return (r > 0.0) ? r : (-1.0);
	}

	private static long BankCount(string name)
	{
		foreach (BankLine item in _bank)
		{
			if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
			{
				string text = item.Value;
				int num = text.IndexOf(' ');
				if (num > 0)
				{
					text = text.Substring(0, num);
				}
				if (long.TryParse(text.Replace(",", ""), out var result))
				{
					return result;
				}
			}
		}
		return -1L;
	}

	private static void WhenText(long lumCost, long coins, long lumHave, long coinsHave, double coinLum, double rate)
	{
		if (lumHave < 0)
		{
			Im.TextDisabled("Check /bank");
			return;
		}
		double num = ((coinsHave >= 0) ? Math.Max(0L, coins - coinsHave) : coins);
		double num2 = (double)lumCost + ((coinLum > 0.0) ? (num * coinLum) : 0.0);
		if (num > 0.0 && coinLum <= 0.0)
		{
			Im.TextDisabled("short " + num.ToString("N0") + " coins");
		}
		else if ((double)lumHave >= num2)
		{
			Im.TextColored(AugGreen, (num > 0.0) ? ("now (buying " + num.ToString("N0") + " coins)") : "now");
		}
		else if (rate <= 0.0)
		{
			Im.TextDisabled("short " + Big(num2 - (double)lumHave));
		}
		else
		{
			Im.TextColored(AugYellow, Eta((num2 - (double)lumHave) / rate) + "  (short " + Big(num2 - (double)lumHave) + ")");
		}
	}

	private static void LumWhen(long lumCost, long lumHave, double lumRate)
	{
		if (lumHave < 0)
		{
			Im.TextDisabled("Check /bank");
			return;
		}
		if (lumHave >= lumCost)
		{
			Im.TextColored(AugGreen, "now");
			return;
		}
		if (lumRate <= 0.0)
		{
			Im.TextDisabled("short " + Big(lumCost - lumHave));
			return;
		}
		Im.TextColored(AugYellow, Eta((double)(lumCost - lumHave) / lumRate));
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Short " + Big(lumCost - lumHave) + " luminance, at " + Big(lumRate) + " lum/hr (luminance only).");
		}
	}

	private static void DrawAugPage(AugKind k)
	{
		if (ImGui.Button("Check /aug + /bank##" + k.Tab))
		{
			QuietNext("/aug");
			Util.Command("/aug");
			QuietNext("/bank");
			Util.Command("/bank");
		}
		long num = AugLevel(k);
		long num2 = BankLuminance();
		long num3 = BankCount("Enlightened Coins");
		bool flag = PluginCore.CurrentSettings == null || PluginCore.CurrentSettings.AugRatesFromTracker;
		double num4 = CoinLum();
		double num5 = (flag ? TrackerRate() : (-1.0));
		double num6;
		if (num5 > 0.0)
		{
			num6 = num5;
		}
		else
		{
			num6 = ((LumPerHourRecent > 0.0) ? LumPerHourRecent : LumPerHour);
		}
		double num7 = (flag ? TrackerLumRate() : (-1.0));
		double lumRate;
		if (num7 > 0.0)
		{
			lumRate = num7;
		}
		else
		{
			lumRate = ((LumPerHourRecent > 0.0) ? LumPerHourRecent : LumPerHour);
		}
		ImGui.SameLine();
		Im.TextColored(Cyan, k.Tab + " level " + ((num >= 0) ? num.ToString("N0") : "?"));
		ImGui.SameLine();
		Im.Text("   Luminance " + ((num2 >= 0) ? Big(num2) : "?") + "   Coins " + ((num3 >= 0) ? num3.ToString("N0") : "?") + "   1 coin = " + ((num4 > 0.0) ? Big(num4) : "?") + " lum   " + ((num6 > 0.0) ? (Big(num6) + "/hr" + ((num5 > 0.0) ? " (tracker, effective)" : " (MelkTank)")) : ""));
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("1 coin: Session > Lum's buying rate (Settings there, shared by every character).\n/hr: " + (flag ? "Session > Lum's effective lum/hr (luminance + coins earned, as luminance); When (lum) uses its lum/hr." : "MelkTank's own lum/hr (Session: last 60 min, else the whole session) for both When columns.") + "\nSwitch it in Settings > Basic > Areas.");
		}
		if (num < 0)
		{
			Im.TextDisabled("Level not known yet - click Check.");
			return;
		}
		DrawAugBuy(k, num, num2, num3);
		if (ImGui.BeginTable("augcost" + k.Tab, 8, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("Gem", ImGuiTableColumnFlags.WidthFixed, 40f);
			ImGui.TableSetupColumn("Luminance", ImGuiTableColumnFlags.WidthFixed, 140f);
			ImGui.TableSetupColumn("When (lum)", ImGuiTableColumnFlags.WidthFixed, 180f);
			ImGui.TableSetupColumn("Coins", ImGuiTableColumnFlags.WidthFixed, 55f);
			ImGui.TableSetupColumn("Coin lum", ImGuiTableColumnFlags.WidthFixed, 140f);
			ImGui.TableSetupColumn("Total lum", ImGuiTableColumnFlags.WidthFixed, 140f);
			ImGui.TableSetupColumn("When (all)", ImGuiTableColumnFlags.WidthStretch);
			ImGui.TableSetupColumn("In your pack", ImGuiTableColumnFlags.WidthFixed, 80f);
			ImGui.TableHeadersRow();
			int[] gemSizes = GemSizes;
			for (int i = 0; i < gemSizes.Length; i++)
			{
				int num8 = gemSizes[i];
				long num9 = AugCost(k, num, num8);
				long num10 = (long)k.Coins * (long)num8;
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				ImGui.TextUnformatted(num8 + "x");
				ImGui.TableSetColumnIndex(1);
				ImGui.TextUnformatted(num9.ToString("N0"));
				ImGui.TableSetColumnIndex(2);
				LumWhen(num9, num2, lumRate);
				ImGui.TableSetColumnIndex(3);
				Im.TextColored((num3 >= num10) ? AugGreen : AugYellow, num10.ToString("N0"));
				ImGui.TableSetColumnIndex(4);
				ImGui.TextUnformatted((num4 > 0.0) ? ((double)num10 * num4).ToString("N0") : "?");
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip(num10.ToString("N0") + " coins x " + Big(num4) + " lum (Session > Lum's buying rate)");
				}
				ImGui.TableSetColumnIndex(5);
				ImGui.TextUnformatted((num4 > 0.0) ? ((double)num9 + (double)num10 * num4).ToString("N0") : "?");
				ImGui.TableSetColumnIndex(6);
				WhenText(num9, num10, num2, num3, num4, num6);
				ImGui.TableSetColumnIndex(7);
				List<WorldObject> list = Gems(k, num8);
				if (list.Count == 0)
				{
					Im.TextDisabled("none");
				}
				else if (ImGui.SmallButton("Use (" + list.Count + ")##use" + k.Tab + num8))
				{
					try
					{
						Remote.ExpectYes(10.0, "luminance");
						Globals.Core.Actions.UseItem(list[0].Id, 0);
						Util.WriteToChat("Augs: using " + list[0].Name + "...");
						_augRecheckAt = DateTime.Now.AddSeconds(2.5);
					}
					catch (Exception ex)
					{
						Util.WriteToChat("Augs: " + ex.Message);
					}
				}
				if (list.Count > 0 && ImGui.IsItemHovered())
				{
					Im.SetTooltip("Uses one " + list[0].Name + " (pays its luminance), then checks /aug and /bank again.");
				}
			}
			ImGui.EndTable();
		}
		if (!_augGoal.TryGetValue(k.Tab, out var value))
		{
			value = "";
		}
		Im.Text("Goal level");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(100f);
		if (ImGui.InputText("##goal" + k.Tab, ref value, 12u, ImGuiInputTextFlags.CharsDecimal))
		{
			_augGoal[k.Tab] = value;
		}
		if (long.TryParse(value.Replace(",", ""), out var result) && result > 0)
		{
			ImGui.SameLine();
			if (result <= num)
			{
				Im.TextDisabled("already there");
			}
			else
			{
				long num11 = result - num;
				long num12 = AugCost(k, num, num11);
				long num13 = k.Coins * num11;
				Im.Text("+" + num11.ToString("N0") + " levels: " + Big(num12) + " lum + " + num13.ToString("N0") + " coins = " + ((num4 > 0.0) ? Big((double)num12 + (double)num13 * num4) : "?") + " lum   ");
				ImGui.SameLine();
				WhenText(num12, num13, num2, num3, num4, num6);
				ImGui.SameLine();
				Im.TextDisabled("   lum only:");
				ImGui.SameLine();
				LumWhen(num12, num2, lumRate);
			}
		}
		if (k.Caps != null)
		{
			string text = "";
			for (int j = 0; j < k.Caps.Length; j++)
			{
				if (num < k.Caps[j])
				{
					text = "   Next soft cap: " + k.Caps[j].ToString("N0") + " (cost x" + (new int[4] { 4, 8, 16, 24 })[j] + ")";
					break;
				}
			}
			Im.TextDisabled("Soft caps " + string.Join(" / ", Array.ConvertAll(k.Caps, (int c) => c.ToString("N0"))) + text);
		}
		else
		{
			Im.TextDisabled("No soft caps known for this one.");
		}
	}
}
