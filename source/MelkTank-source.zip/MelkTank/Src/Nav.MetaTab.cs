using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
#if !RETAIL
using ACGodot.DecalShim;
using ACGodot.Plugins;
using ACGodot.UI;
#endif
#if !RETAIL
using AcClient;
#else
using SmartBox = AcClient.SmartBox;
using ACCmdInterp = AcClient.ACCmdInterp;
using CommandInterpreter = AcClient.CommandInterpreter;
using CommandListElement = AcClient.CommandListElement;
using CPhysicsObj = AcClient.CPhysicsObj;
using Position = AcClient.Position;
using CTransition = AcClient.CTransition;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
#if !RETAIL
using Godot;
#endif
using ImGuiNET;
using MelkTank.Loot;
using MelkTank.Metas;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public partial class Nav
{
	public bool OpenMeta(string path)
	{
		try
		{
			_meta = Meta.Load(path);
			_metaState = _meta.States()[0];
			_metaEdit = -1;
			_s.MetaLast = path;
			if (SaveAll != null)
			{
				SaveAll();
			}
			Util.WriteToChat("Meta: " + _meta.Name + " loaded - " + _meta.Rules.Count + " rules in " + _meta.States().Count + " states (Nav > Meta).");
			return true;
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Meta: can't read " + Path.GetFileName(path) + ": " + ex.Message);
			return false;
		}
	}

	private void DrawMetaPicker()
	{
		ImGui.SameLine();
		bool v = _s.MetaVtankDir;
		if (VtankDir == null)
		{
			ImGui.BeginDisabled();
		}
		if (ImGui.Checkbox("VTank folder##metapickvt", ref v))
		{
			_s.MetaVtankDir = v;
			_metaTreeAt = DateTime.MinValue;
			_pickListAt = DateTime.MinValue;
			if (SaveAll != null)
			{
				SaveAll();
			}
		}
		if (VtankDir == null)
		{
			ImGui.EndDisabled();
		}
		Tip((VtankDir == null) ? "VTank's folder wasn't found." : ("Ticked: the list shows VTank's metas (" + VtankDir + ").\nUnticked: MelkTank's Metas folder."));
		string dir = ((_s.MetaVtankDir && VtankDir != null) ? VtankDir : MetaDir);
		if (_pickListVt != _s.MetaVtankDir || (DateTime.Now - _pickListAt).TotalSeconds > 5.0)
		{
			_pickListVt = _s.MetaVtankDir;
			_pickListAt = DateTime.Now;
			_pickList = new List<string>();
			try
			{
				string[] files = Directory.GetFiles(dir, "*.*", SearchOption.AllDirectories);
				foreach (string text in files)
				{
					string text2 = Path.GetExtension(text).ToLowerInvariant();
					if (text2 == ".met" || text2 == ".mtmet")
					{
						_pickList.Add(text);
					}
				}
				_pickList.Sort((string a, string b) => string.Compare(a.Substring(dir.Length), b.Substring(dir.Length), StringComparison.OrdinalIgnoreCase));
			}
			catch
			{
			}
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(240f);
		string text3 = ((_meta != null && !string.IsNullOrEmpty(_meta.File) && _meta.File.StartsWith(dir, StringComparison.OrdinalIgnoreCase)) ? _meta.File.Substring(dir.Length).TrimStart(new char[2] { '\\', '/' }) : ("load a meta (" + _pickList.Count + ")..."));
		if (ImGui.BeginCombo("##metapick", text3))
		{
			if (_pickList.Count == 0)
			{
				Im.TextColored(Grey, "No metas in " + dir);
			}
			foreach (string pick in _pickList)
			{
				string text4 = pick.Substring(dir.Length).TrimStart(new char[2] { '\\', '/' });
				bool flag = _meta != null && string.Equals(_meta.File, pick, StringComparison.OrdinalIgnoreCase);
				if (ImGui.Selectable(text4 + "##mp" + text4, flag) && !flag)
				{
					if (_meta != null && _meta.Dirty)
					{
						Util.WriteToChat("Meta: " + _meta.Name + " had unsaved changes - they're gone.");
					}
					OpenMeta(pick);
				}
			}
			ImGui.EndCombo();
		}
		Tip("Opens a meta from " + (_s.MetaVtankDir ? "VTank's" : "MelkTank's Metas") + " folder (subfolders included). A running meta switches to it, from Default.");
	}

	private void MetaChanged()
	{
		if (_meta != null)
		{
			_meta.Dirty = true;
		}
	}

	public void DrawMeta()
	{
		try
		{
			DrawMetaTab();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void DrawMetaTab()
	{
		if (!_metaTriedLast)
		{
			_metaTriedLast = true;
			if (_meta == null && _s.MetaOpenLast && !string.IsNullOrEmpty(_s.MetaLast) && File.Exists(_s.MetaLast))
			{
				OpenMeta(_s.MetaLast);
			}
		}
		if (ImGui.Button("New meta"))
		{
			_meta = new Meta
			{
				Name = "New meta"
			};
			_meta.Rules.Add(new MRule());
			_metaState = "Default";
			_metaEdit = 0;
			_meta.Dirty = true;
		}
		Tip("Starts an empty meta (one 'always -> send' rule in Default to change).");
		DrawMetaPicker();
		if (_meta == null)
		{
			ImGui.SameLine();
			Im.TextColored(Grey, "No meta open - load one in Nav > Settings > Meta files, or start a new one.");
			return;
		}
		ImGui.SameLine();
		Im.TextColored(_meta.Dirty ? Yellow : Cyan, _meta.Name + (_meta.Dirty ? " *" : ""));
		if (_meta.File.Length > 0)
		{
			ImGui.SameLine();
			Im.TextColored(Grey, _meta.File);
		}
		string input = _meta.Name;
		ImGui.SetNextItemWidth(200f);
		if (ImGui.InputText("Name##metaname", ref input, 80u))
		{
			_meta.Name = input;
			MetaChanged();
		}
		ImGui.SameLine();
		if (ImGui.Button("Save (.mtmet)"))
		{
			SaveMeta(vtank: false);
		}
		Tip("MelkTank's meta file, in Metas (or the folder the meta came from). Same layout as VTank's.");
		ImGui.SameLine();
		if (ImGui.Button("Save as VTank .met"))
		{
			SaveMeta(vtank: true);
		}
		Tip("A .met VTank can load. Anything only MelkTank can do is listed in chat and left out.");
		int num = CountVtSettings();
		if (num > 0)
		{
			ImGui.SameLine();
			if (ImGui.Button("Convert VTank settings (" + num + ")##metavtconv"))
			{
				ConvertVtSettings();
			}
			Tip("This meta's expressions use vtsetsetting / vtgetsetting, which need VTank loaded.\nThis rewrites them for MelkTank:\n  $X = tostring[vtgetsetting[EnableCombat]]   ->  Get MT option combat into X\n  vtsetsetting[EnableCombat, $X]              ->  Set MT option combat from variable $X\n  vtsetsetting[EnableCombat, 0] (inside others) ->  chatbox[/vt opt set EnableCombat 0] (MelkTank does it)\nAnything else is left alone and listed in chat. Save as .mtmet afterwards.");
		}
		if (_meta.File.Length > 0)
		{
			ImGui.SameLine();
			if (ImGui.Button("Reload"))
			{
				OpenMeta(_meta.File);
			}
			Tip("Throws away unsaved changes and reads the file again.");
		}
		bool v = MetaRunning;
		if (ImGui.Checkbox("Run this meta##metarun", ref v))
		{
			if (v)
			{
				MetaStart();
			}
			else
			{
				MetaStop();
			}
		}
		Tip("/mt meta on|off  -  /mt meta load <name>  -  /mt meta state <name>");
		ImGui.SameLine();
		MRule mRule = ((_metaEdit >= 0 && _metaEdit < _meta.Rules.Count && _meta.Rules[_metaEdit].State == _metaState) ? _meta.Rules[_metaEdit] : null);
		if (ImGui.Button("Start meta here##metahere"))
		{
			MetaStartAt(_metaState, mRule);
			v = true;
		}
		Tip("Runs the meta from the state shown (" + _metaState + ")" + ((mRule != null) ? ", starting at the rule being edited (the ones above it are skipped this visit)." : ".") + "\nPick a rule (click it) to start part way down a state.");
		Tip("Runs the meta the VTank way: in its current state, the first rule whose condition is true does its action\n(each rule once per visit to the state). Edits take effect straight away. /mtank meta on | off works too.\nDon't run the same meta in VTank at the same time.");
		if (v)
		{
			ImGui.SameLine();
			Im.TextColored(Green, "in state " + _mState + "  (" + (int)(DateTime.Now - _mStateAt).TotalSeconds + " s)");
			if (_metaState != _mState)
			{
				ImGui.SameLine();
				if (ImGui.SmallButton("go to " + _metaState + "##metago"))
				{
					MetaSetState(_metaState, persistReset: true);
				}
				Tip("Switches the running meta to the state picked in the list.");
			}
			ImGui.SameLine();
			if (ImGui.SmallButton("show running state##metashow"))
			{
				_metaState = _mState;
				_metaEdit = -1;
			}
			if (!UbExpr.Ready)
			{
				ImGui.SameLine();
				Im.TextColored(Red, "UtilityBelt not found - expressions are false");
			}
		}
		if (MetaLog.Count > 0 && ImGui.CollapsingHeader("What the meta did##metalog"))
		{
			if (ImGui.BeginChild("##metalogc", new System.Numerics.Vector2(0f, 110f), border: true))
			{
				for (int num2 = MetaLog.Count - 1; num2 >= 0; num2--)
				{
					ImGui.TextUnformatted(MetaLog[num2]);
				}
			}
			ImGui.EndChild();
			if (ImGui.SmallButton("clear##metalogclr"))
			{
				MetaLog.Clear();
			}
		}
		List<string> list = _meta.States();
		if (!list.Contains(_metaState))
		{
			_metaState = list[0];
		}
		if (ImGui.BeginChild("##metastates", new System.Numerics.Vector2(210f, 0f), border: true))
		{
			Im.TextColored(Cyan, "States");
			foreach (string st in list)
			{
				int count = _meta.Rules.FindAll((MRule r) => r.State == st).Count;
				bool flag = v && st == _mState;
				if (flag)
				{
					ImGui.PushStyleColor(ImGuiCol.Text, Green);
				}
				if (ImGui.Selectable((flag ? "> " : "") + st + "  (" + count + ")##ms" + st, st == _metaState))
				{
					_metaState = st;
					_metaEdit = -1;
					_metaRename = st;
				}
				if (flag)
				{
					ImGui.PopStyleColor();
					Tip("The running meta is in this state.");
				}
			}
			ImGui.Separator();
			ImGui.SetNextItemWidth(-1f);
			ImGui.InputTextWithHint("##newstate", "new state name", ref _metaNewState, 64u);
			if (ImGui.SmallButton("Add state") && _metaNewState.Trim().Length > 0 && !list.Contains(_metaNewState.Trim()))
			{
				MRule mRule2 = new MRule
				{
					State = _metaNewState.Trim()
				};
				_meta.Rules.Add(mRule2);
				_metaState = mRule2.State;
				_metaEdit = _meta.Rules.Count - 1;
				_metaNewState = "";
				MetaChanged();
			}
			Tip("A state needs at least one rule - it's made with an 'always -> send' rule to change.");
			ImGui.SetNextItemWidth(-1f);
			if (_metaRename.Length == 0)
			{
				_metaRename = _metaState;
			}
			ImGui.InputText("##renamestate", ref _metaRename, 64u);
			if (ImGui.SmallButton("Rename state") && _metaRename.Trim().Length > 0 && _metaRename.Trim() != _metaState)
			{
				RenameState(_metaState, _metaRename.Trim());
				_metaState = _metaRename.Trim();
				MetaChanged();
			}
			Tip("Renames the state and every 'go to' / 'call' that points at it.");
		}
		ImGui.EndChild();
		ImGui.SameLine();
		if (ImGui.BeginChild("##metarules", new System.Numerics.Vector2(0f, 0f), border: true))
		{
			Im.TextColored(Cyan, "In " + _metaState + ":");
			ImGui.SameLine();
			Im.TextColored(Grey, "rules are checked top to bottom");
			int num3 = -1;
			int num4 = -1;
			int num5 = -1;
			int num6 = -1;
			List<int> list2 = new List<int>();
			for (int num7 = 0; num7 < _meta.Rules.Count; num7++)
			{
				if (_meta.Rules[num7].State == _metaState)
				{
					list2.Add(num7);
				}
			}
			if (ImGui.BeginTable("##metarulestbl", 4, ImGuiTableFlags.SizingStretchProp | ImGuiTableFlags.RowBg | ImGuiTableFlags.BordersInnerH, new System.Numerics.Vector2(ImGui.GetContentRegionAvail().X - 18f, 0f)))
			{
				ImGui.TableSetupColumn("When", ImGuiTableColumnFlags.WidthStretch, 1f);
				ImGui.TableSetupColumn("Do", ImGuiTableColumnFlags.WidthStretch, 1f);
				ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 52f);
				ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 96f);
				for (int num8 = 0; num8 < list2.Count; num8++)
				{
					int num9 = list2[num8];
					MRule mRule3 = _meta.Rules[num9];
					ImGui.TableNextRow();
					ImGui.PushID(num9);
					ImGui.TableSetColumnIndex(0);
					if (mRule3.C.Type == 0 || mRule3.C.Type == 1)
					{
						bool v2 = mRule3.C.Type == 1;
						if (ImGui.Checkbox("##onoff", ref v2))
						{
							mRule3.C.Type = (v2 ? 1 : 0);
							mRule3.C.Data = MVal.Int(0);
							mRule3.C.Kids = null;
							MetaChanged();
						}
						Tip("Ticked: always. Unticked: never (the rule is switched off).");
						ImGui.SameLine();
					}
					ImGui.PushTextWrapPos(0f);
					System.Numerics.Vector4 col;
					if (num9 == _metaEdit)
					{
						col = Yellow;
					}
					else
					{
						col = ((mRule3.C.Type == 0) ? Grey : System.Numerics.Vector4.One);
					}
					Im.TextColored(col, MetaText.Describe(mRule3.C));
					ImGui.PopTextWrapPos();
					if (ImGui.IsItemClicked())
					{
						_metaEdit = ((num9 == _metaEdit) ? (-1) : num9);
					}
					if (ImGui.IsItemHovered())
					{
						Im.SetTooltip("Click to edit this rule (again to close it).");
					}
					ImGui.TableSetColumnIndex(1);
					ImGui.PushTextWrapPos(0f);
					System.Numerics.Vector4 col2;
					if (num9 == _metaEdit)
					{
						col2 = Yellow;
					}
					else
					{
						col2 = ((mRule3.A.Type == 1 || mRule3.A.Type == 5) ? Green : Cyan);
					}
					Im.TextColored(col2, MetaText.Describe(mRule3.A));
					ImGui.PopTextWrapPos();
					if (ImGui.IsItemClicked())
					{
						_metaEdit = ((num9 == _metaEdit) ? (-1) : num9);
					}
					string text;
					if (mRule3.A.Type == 1 && mRule3.A.Data != null)
					{
						text = mRule3.A.Data.S;
					}
					else
					{
						text = ((mRule3.A.Type == 5 && mRule3.A.Data != null) ? mRule3.A.Data.GetS("st") : null);
					}
					if (ImGui.IsItemHovered())
					{
						Im.SetTooltip("Click to edit this rule." + ((text != null) ? ("\nRight-click to show state " + text + ".") : ""));
					}
					if (text != null && ImGui.IsItemClicked(ImGuiMouseButton.Right) && list.Contains(text))
					{
						_metaState = text;
						_metaEdit = -1;
						_metaRename = text;
					}
					ImGui.TableSetColumnIndex(2);
					if (num8 > 0)
					{
						if (Im.UpButton("##mup"))
						{
							num3 = num9;
						}
						ImGui.SameLine();
					}
					if (num8 < list2.Count - 1 && Im.DownButton("##mdn"))
					{
						num4 = num9;
					}
					ImGui.TableSetColumnIndex(3);
					if (ImGui.SmallButton((num9 == _metaEdit) ? "done" : "edit"))
					{
						_metaEdit = ((num9 == _metaEdit) ? (-1) : num9);
					}
					ImGui.SameLine();
					if (ImGui.SmallButton("+"))
					{
						num6 = num9;
					}
					Tip("Copy this rule (below it).");
					ImGui.SameLine();
					if (ImGui.SmallButton("x"))
					{
						num5 = num9;
					}
					ImGui.PopID();
				}
				ImGui.EndTable();
			}
			if (ImGui.Button("Add rule"))
			{
				int num10 = ((list2.Count > 0) ? (list2[list2.Count - 1] + 1) : _meta.Rules.Count);
				_meta.Rules.Insert(num10, new MRule
				{
					State = _metaState
				});
				_metaEdit = num10;
				MetaChanged();
			}
			bool far = Im.Far;
			Im.Far = false;
			if (num3 >= 0)
			{
				int num11 = PrevInState(num3);
				Swap(num3, num11);
				while (far && num11 != num3)
				{
					num3 = num11;
					num11 = PrevInState(num3);
					Swap(num3, num11);
				}
			}
			if (num4 >= 0)
			{
				int num12 = NextInState(num4);
				Swap(num4, num12);
				while (far && num12 != num4)
				{
					num4 = num12;
					num12 = NextInState(num4);
					Swap(num4, num12);
				}
			}
			if (num6 >= 0)
			{
				MRule mRule4 = _meta.Rules[num6];
				_meta.Rules.Insert(num6 + 1, new MRule
				{
					C = mRule4.C.Clone(),
					A = mRule4.A.Clone(),
					State = mRule4.State
				});
				_metaEdit = num6 + 1;
				MetaChanged();
			}
			if (num5 >= 0)
			{
				_meta.Rules.RemoveAt(num5);
				if (_metaEdit == num5)
				{
					_metaEdit = -1;
				}
				else if (_metaEdit > num5)
				{
					_metaEdit--;
				}
				MetaChanged();
			}
			if (_metaEdit >= 0 && _metaEdit < _meta.Rules.Count && _meta.Rules[_metaEdit].State == _metaState)
			{
				ImGui.Separator();
				MRule mRule5 = _meta.Rules[_metaEdit];
				bool flag2 = false;
				Im.TextColored(Yellow, "Editing the rule in state");
				ImGui.SameLine();
				string state = mRule5.State;
				ImGui.SetNextItemWidth(180f);
				if (ImGui.BeginCombo("##rstate", state))
				{
					foreach (string item in list)
					{
						if (ImGui.Selectable(item, item == state))
						{
							mRule5.State = item;
							_metaState = item;
							flag2 = true;
						}
					}
					ImGui.EndCombo();
				}
				Tip("Pick another state to move the rule there.");
				ImGui.SameLine();
				if (ImGui.SmallButton("done##editdone"))
				{
					_metaEdit = -1;
				}
				Im.TextColored(Cyan, "When");
				flag2 |= DrawCond(mRule5.C, "c", 0, list);
				Im.TextColored(Cyan, "Do");
				if (flag2 | DrawAct(mRule5.A, "a", 0, list))
				{
					MetaChanged();
				}
			}
		}
		ImGui.EndChild();
	}
}
