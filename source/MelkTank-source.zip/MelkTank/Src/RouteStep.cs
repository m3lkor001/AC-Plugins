using System.Collections.Generic;

namespace MelkTank;

public class RouteStep
{
	public StepKind Kind;

	public double NS;

	public double EW;

	public double Z;

	public string Text = "";

	public int WaitMs = 1000;

	public string Op = "";

	public int Count;

	/// <summary>A vendor step's profile (empty: the one named after the vendor).</summary>
	public string Profile = "";

	/// <summary>A portal or NPC step: the one picked when it was added (its object id) - found by that first, so of several
	/// with the same name the right one is used; by name (nearest where it was added) when it isn't there.</summary>
	public int Guid;

	public List<LoopCond> Conds = new List<LoopCond>();
}
