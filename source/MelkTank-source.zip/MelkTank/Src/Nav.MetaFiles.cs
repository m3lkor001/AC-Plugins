using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
#if !RETAIL
using ACGodot.DecalShim;
using ACGodot.Plugins;
using ACGodot.UI;
#endif
#if !RETAIL
using AcClient;
#else
using SmartBox = AcClient.SmartBox;
using ACCmdInterp = AcClient.ACCmdInterp;
using CommandInterpreter = AcClient.CommandInterpreter;
using CommandListElement = AcClient.CommandListElement;
using CPhysicsObj = AcClient.CPhysicsObj;
using Position = AcClient.Position;
using CTransition = AcClient.CTransition;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
#if !RETAIL
using Godot;
#endif
using ImGuiNET;
using MelkTank.Loot;
using MelkTank.Metas;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public partial class Nav
{
	public static bool IsMtRoute(byte[] b)
	{
		if (b == null)
		{
			return false;
		}
		string text = Meta.Enc.GetString(b, 0, Math.Min(b.Length, 400));
		return text.IndexOf("<MelkTankRoute", StringComparison.Ordinal) >= 0;
	}

	private static string RouteXml(NavRoute r)
	{
		XmlDocument xmlDocument = new XmlDocument();
		XmlElement xmlElement = xmlDocument.CreateElement("MelkTankRoute");
		xmlDocument.AppendChild(xmlElement);
		Settings.WriteRoute(xmlDocument, xmlElement, NavPresets.Expanded(r));
		return xmlDocument.OuterXml;
	}

	public static NavRoute EmbeddedMtRoute(byte[] b)
	{
		try
		{
			string text = Meta.Enc.GetString(b);
			int num = text.IndexOf("<MelkTankRoute", StringComparison.Ordinal);
			if (num < 0)
			{
				return null;
			}
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.LoadXml(text.Substring(num));
			return Settings.ReadRoute(xmlDocument.DocumentElement);
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Meta: couldn't read the embedded route: " + ex.Message);
			return null;
		}
	}

	private static IEnumerable<KeyValuePair<object, MVal>> Exprs(Meta m)
	{
		List<KeyValuePair<object, MVal>> l = new List<KeyValuePair<object, MVal>>();
		Action<MCond> c = null;
		Action<MAct> a = null;
		c = (MCond x) =>
		{
			if (x != null)
			{
				if (x.Type == 26 && x.Data != null)
				{
					l.Add(new KeyValuePair<object, MVal>(x, x.Data));
				}
				if (x.Kids != null)
				{
					foreach (MCond kid in x.Kids)
					{
						c(kid);
					}
				}
			}
		};
		a = (MAct x) =>
		{
			if (x != null)
			{
				if ((x.Type == 7 || x.Type == 8) && x.Data != null)
				{
					l.Add(new KeyValuePair<object, MVal>(x, x.Data));
				}
				if (x.Kids != null)
				{
					foreach (MAct kid2 in x.Kids)
					{
						a(kid2);
					}
				}
			}
		};
		foreach (MRule rule in m.Rules)
		{
			c(rule.C);
			a(rule.A);
		}
		return l;
	}

	private int CountVtSettings()
	{
		if (_meta == null)
		{
			return 0;
		}
		if (_vtCountMeta == _meta && (DateTime.Now - _vtCountAt).TotalSeconds < 2.0)
		{
			return _vtCountCache;
		}
		int num = 0;
		foreach (KeyValuePair<object, MVal> item in Exprs(_meta))
		{
			string s = item.Value.GetS("e");
			if (s.IndexOf("vtsetsetting", StringComparison.OrdinalIgnoreCase) >= 0 || s.IndexOf("vtgetsetting", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				num++;
			}
		}
		_vtCountMeta = _meta;
		_vtCountAt = DateTime.Now;
		_vtCountCache = num;
		return num;
	}

	private void ConvertVtSettings()
	{
		int num = 0;
		List<string> list = new List<string>();
		foreach (KeyValuePair<object, MVal> item in Exprs(_meta))
		{
			string s = item.Value.GetS("e");
			if (s.IndexOf("vtsetsetting", StringComparison.OrdinalIgnoreCase) < 0 && s.IndexOf("vtgetsetting", StringComparison.OrdinalIgnoreCase) < 0)
			{
				continue;
			}
			MAct mAct = item.Key as MAct;
			Match match;
			if (mAct != null && mAct.Type == 7 && (match = VtGetRx.Match(s)).Success)
			{
				mAct.Type = 11;
				mAct.Data = MVal.Dict();
				mAct.Data.Set("o", MVal.Str(match.Groups["opt"].Value));
				mAct.Data.Set("v", MVal.Str(match.Groups["var"].Value));
				num++;
				continue;
			}
			if (mAct != null && mAct.Type == 7 && (match = VtSetVarRx.Match(s)).Success)
			{
				mAct.Type = 12;
				mAct.Data = MVal.Dict();
				mAct.Data.Set("o", MVal.Str(match.Groups["opt"].Value));
				mAct.Data.Set("v", MVal.Str(match.Groups["val"].Value));
				num++;
				continue;
			}
			if (mAct != null && mAct.Type == 7 && (match = VtSetFixedRx.Match(s)).Success)
			{
				mAct.Type = 12;
				mAct.Data = MVal.Dict();
				mAct.Data.Set("o", MVal.Str(match.Groups["opt"].Value));
				mAct.Data.Set("v", MVal.Str(MetaText.IsOn(match.Groups["val"].Value) ? "1" : "0"));
				num++;
				continue;
			}
			string text = VtSetInnerRx.Replace(s, (Match x) => "chatbox[" + x.Groups["esc"].Value + "`/vt opt set " + x.Groups["opt"].Value + " " + x.Groups["val"].Value + x.Groups["esc"].Value + "`]");
			if (text != s)
			{
				item.Value.Set("e", MVal.Str(text));
				if (text.IndexOf("vtgetsetting", StringComparison.OrdinalIgnoreCase) < 0 && text.IndexOf("vtsetsetting", StringComparison.OrdinalIgnoreCase) < 0)
				{
					num++;
					continue;
				}
			}
			list.Add((text.Length > 60) ? (text.Substring(0, 60) + "...") : text);
		}
		_vtCountAt = DateTime.MinValue;
		if (num > 0)
		{
			MetaChanged();
		}
		Util.WriteToChat("Meta: converted " + num + " VTank setting expression" + ((num == 1) ? "" : "s") + " for MelkTank" + ((list.Count > 0) ? (" - " + list.Count + " left as they were: " + string.Join(" | ", list.ToArray())) : ".") + ((num > 0) ? " Save it as .mtmet to keep." : ""));
	}

	private bool EmbedRoute(MVal d, NavRoute r)
	{
		try
		{
			d.T = "ba";
			d.B = Meta.Enc.GetBytes(SafeName(r.Name) + ".mtnav\r\n" + r.Steps.Count + "\r\n" + RouteXml(r));
			Util.WriteToChat("Meta: route " + r.Name + " embedded (" + r.Steps.Count + " steps, all kept).");
			return true;
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Meta: couldn't embed the route: " + ex.Message);
			return false;
		}
	}

	private byte[] VtankEmbed(byte[] b)
	{
		NavRoute navRoute = EmbeddedMtRoute(b);
		if (navRoute == null)
		{
			return b;
		}
		string path = Path.Combine(Path.GetTempPath(), "mt_embed_" + SafeName(navRoute.Name) + ".nav");
		if (!ExportNav(navRoute, path, quiet: true))
		{
			return b;
		}
		string text = File.ReadAllText(path, Meta.Enc);
		try
		{
			File.Delete(path);
		}
		catch
		{
		}
		string[] array = text.Split(new string[2] { "\r\n", "\n" }, StringSplitOptions.None);
		int result = 0;
		if (array.Length > 2)
		{
			int.TryParse(array[2].Trim(), out result);
		}
		return Meta.Enc.GetBytes(SafeName(navRoute.Name) + ".nav\r\n" + result + "\r\n" + text);
	}

	private void ImportEmbedded(byte[] b, string name)
	{
		try
		{
			string text = Meta.Enc.GetString(b ?? new byte[0]);
			if (IsMtRoute(b))
			{
				NavRoute mr = EmbeddedMtRoute(b);
				if (mr != null)
				{
					if (mr.Name.Length == 0)
					{
						mr.Name = ((name.Length > 0) ? Path.GetFileNameWithoutExtension(name) : "Meta route");
					}
					string name2 = mr.Name;
					int num = 2;
					while (_s.NavRoutes.Exists((NavRoute x) => string.Equals(x.Name, mr.Name, StringComparison.OrdinalIgnoreCase)))
					{
						mr.Name = name2 + " (" + num++ + ")";
					}
					mr.File = "";
					_s.NavRoutes.Add(mr);
					if (SaveAll != null)
					{
						SaveAll();
					}
					Util.WriteToChat("Meta: route " + mr.Name + " added (" + mr.Steps.Count + " steps) - Nav > Routes.");
				}
				return;
			}
			int num2 = text.IndexOf("uTank2 NAV", StringComparison.OrdinalIgnoreCase);
			if (num2 < 0)
			{
				Util.WriteToChat("Meta: that embedded nav is empty.");
				return;
			}
			string path = Path.Combine(Path.GetTempPath(), SafeName(((_meta != null) ? (_meta.Name + " ") : "") + ((name.Length > 0) ? Path.GetFileNameWithoutExtension(name) : "nav")) + ".nav");
			File.WriteAllText(path, text.Substring(num2), Meta.Enc);
			NavRoute nr = ImportNav(path);
			try
			{
				File.Delete(path);
			}
			catch
			{
			}
			if (nr != null)
			{
				string name3 = nr.Name;
				int num3 = 2;
				while (_s.NavRoutes.Exists((NavRoute x) => string.Equals(x.Name, nr.Name, StringComparison.OrdinalIgnoreCase)))
				{
					nr.Name = name3 + " (" + num3++ + ")";
				}
				_s.NavRoutes.Add(nr);
				if (SaveAll != null)
				{
					SaveAll();
				}
				Util.WriteToChat("Meta: route " + nr.Name + " added (" + nr.Steps.Count + " steps) - Nav > Routes.");
			}
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Meta: couldn't make the route: " + ex.Message);
		}
	}

	private void SaveMeta(bool vtank)
	{
		if (_meta == null)
		{
			return;
		}
		string text = ((!string.IsNullOrEmpty(_meta.File)) ? Path.GetDirectoryName(_meta.File) : MetaDir);
		if (!vtank && VtankDir != null && text.StartsWith(VtankDir, StringComparison.OrdinalIgnoreCase))
		{
			text = MetaDir;
		}
		string text2 = Path.Combine(text, SafeName(_meta.Name) + (vtank ? ".met" : ".mtmet"));
		if (vtank)
		{
			List<string> list = _meta.NotForVtank();
			if (list.Count > 0)
			{
				Util.WriteToChat("Meta: VTank can't do these - they're left out of the .met: " + string.Join(", ", list.ToArray()));
			}
		}
		List<KeyValuePair<MVal, byte[]>> swapped = new List<KeyValuePair<MVal, byte[]>>();
		List<object[]> retyped = new List<object[]>();
		Action action = () =>
		{
			foreach (KeyValuePair<MVal, byte[]> item in swapped)
			{
				item.Key.B = item.Value;
			}
			foreach (object[] item2 in retyped)
			{
				MAct mAct = (MAct)item2[0];
				mAct.Type = (int)item2[1];
				mAct.Data = (MVal)item2[2];
			}
		};
		if (vtank)
		{
			Action<MAct> walk = null;
			walk = (MAct x) =>
			{
				if (x != null)
				{
					if (x.Type == 4 && x.Data != null && IsMtRoute(x.Data.B))
					{
						swapped.Add(new KeyValuePair<MVal, byte[]>(x.Data, x.Data.B));
						x.Data.B = VtankEmbed(x.Data.B);
					}
					if (x.Type == 104 && x.Data != null)
					{
						retyped.Add(new object[3] { x, x.Type, x.Data });
						x.Type = 2;
						x.Data = MVal.Str("/vt nav load " + x.Data.GetS("n"));
					}
					else if (x.Type >= 100 && x.Type <= 103 && x.Data != null)
					{
						string v = ((x.Type == 103) ? ("/ub give " + x.Data.GetS("i") + " to " + x.Data.GetS("n")) : ("/ub use " + x.Data.GetS("n")));
						retyped.Add(new object[3] { x, x.Type, x.Data });
						x.Type = 2;
						x.Data = MVal.Str(v);
					}
					if (x.Kids != null)
					{
						foreach (MAct kid in x.Kids)
						{
							walk(kid);
						}
					}
				}
			};
			foreach (MRule rule in _meta.Rules)
			{
				walk(rule.A);
			}
		}
		try
		{
			if (vtank)
			{
				string file = _meta.File;
				string name = _meta.Name;
				bool dirty = _meta.Dirty;
				File.WriteAllBytes(text2, _meta.ToBytes());
				_meta.File = file;
				_meta.Name = name;
				_meta.Dirty = dirty;
				action();
				_metaTreeAt = DateTime.MinValue;
				Util.WriteToChat("Meta: saved " + text2 + " (VTank copy)");
			}
			else
			{
				_meta.Save(text2);
				_s.MetaLast = text2;
				if (SaveAll != null)
				{
					SaveAll();
				}
				_metaTreeAt = DateTime.MinValue;
				Util.WriteToChat("Meta: saved " + text2);
			}
		}
		catch (Exception ex)
		{
			action();
			Util.WriteToChat("Meta: couldn't save " + text2 + ": " + ex.Message);
		}
	}

	private static TreeDir ScanMetas(string dir, int depth)
	{
		TreeDir treeDir = new TreeDir
		{
			Path = dir,
			Name = Path.GetFileName(dir)
		};
		if (depth > 6)
		{
			return treeDir;
		}
		try
		{
			List<string> list = new List<string>(Directory.GetDirectories(dir));
			list.Sort(StringComparer.OrdinalIgnoreCase);
			foreach (string item in list)
			{
				TreeDir treeDir2 = ScanMetas(item, depth + 1);
				if (treeDir2.Files.Count > 0 || treeDir2.Dirs.Count > 0)
				{
					treeDir.Dirs.Add(treeDir2);
				}
			}
			string[] files = Directory.GetFiles(dir);
			foreach (string text in files)
			{
				if (text.EndsWith(".met", StringComparison.OrdinalIgnoreCase) || text.EndsWith(".mtmet", StringComparison.OrdinalIgnoreCase))
				{
					treeDir.Files.Add(text);
				}
			}
			treeDir.Files.Sort(StringComparer.OrdinalIgnoreCase);
		}
		catch
		{
		}
		return treeDir;
	}

	private void DrawMetaTree(TreeDir d)
	{
		foreach (TreeDir dir in d.Dirs)
		{
			if (ImGui.TreeNodeEx(dir.Name + "###md" + dir.Path, ImGuiTreeNodeFlags.OpenOnArrow | ImGuiTreeNodeFlags.SpanAvailWidth))
			{
				DrawMetaTree(dir);
				ImGui.TreePop();
			}
		}
		foreach (string file in d.Files)
		{
			bool flag = file.EndsWith(".mtmet", StringComparison.OrdinalIgnoreCase);
			ImGui.PushStyleColor(ImGuiCol.Text, flag ? new System.Numerics.Vector4(0.6f, 0.85f, 1f, 1f) : new System.Numerics.Vector4(0.8f, 0.65f, 1f, 1f));
			if (ImGui.Selectable("    " + Path.GetFileName(file) + "###mf" + file, string.Equals(_metaPick, file, StringComparison.OrdinalIgnoreCase)))
			{
				_metaPick = file;
			}
			ImGui.PopStyleColor();
			if (ImGui.IsItemHovered() && ImGui.IsMouseDoubleClicked(ImGuiMouseButton.Left))
			{
				OpenMeta(file);
			}
		}
	}

	private bool DrawMetaFiles()
	{
		bool result = false;
		ImGui.Indent(8f);
		if (ImGui.RadioButton("MelkTank Metas folder##mdir", !_s.MetaVtankDir))
		{
			_s.MetaVtankDir = false;
			_metaTreeAt = DateTime.MinValue;
			result = true;
		}
		ImGui.SameLine();
		if (VtankDir != null)
		{
			if (ImGui.RadioButton("VTank folder##mdir2", _s.MetaVtankDir))
			{
				_s.MetaVtankDir = true;
				_metaTreeAt = DateTime.MinValue;
				result = true;
			}
		}
		else
		{
			Im.TextColored(Grey, "(no VTank folder found)");
		}
		ImGui.SameLine();
		if (ImGui.SmallButton("Refresh##mref"))
		{
			_metaTreeAt = DateTime.MinValue;
		}
		string text = ((_s.MetaVtankDir && VtankDir != null) ? VtankDir : MetaDir);
		Im.TextColored(Grey, text);
		if (_metaTree == null || _metaTree.Path != text || (DateTime.Now - _metaTreeAt).TotalSeconds > 5.0)
		{
			_metaTree = ScanMetas(text, 0);
			_metaTreeAt = DateTime.Now;
		}
		if (ImGui.BeginChild("##metatree", new System.Numerics.Vector2(0f, 180f), border: true))
		{
			if (_metaTree.Dirs.Count == 0 && _metaTree.Files.Count == 0)
			{
				Im.TextColored(Grey, "No .met / .mtmet files here yet.");
			}
			DrawMetaTree(_metaTree);
		}
		ImGui.EndChild();
		bool flag = _metaPick != null && File.Exists(_metaPick);
		if (!flag)
		{
			ImGui.BeginDisabled();
		}
		if (ImGui.Button("Open in Nav > Meta") & flag)
		{
			OpenMeta(_metaPick);
		}
		if (!flag)
		{
			ImGui.EndDisabled();
		}
		Tip("Click (or double-click) a meta in the list. VTank .met files (purple) open as they are - save them as .mtmet\nto keep MelkTank's copy, or back as .met for VTank.");
		if (flag)
		{
			ImGui.SameLine();
			Im.TextColored(Grey, Path.GetFileName(_metaPick));
		}
		ImGui.Unindent(8f);
		return result;
	}

	private bool DrawMetaSettings()
	{
		bool flag = false;
		flag |= ImGui.Checkbox("Open the last meta when you log in##metalast", ref _s.MetaOpenLast);
		Tip("Nav > Meta shows the meta you had open last time.\n/mt set MetaOpenLast on|off");
		flag |= ImGui.Checkbox("Going to the state you're already in starts it over##metasame", ref _s.MetaSameRestarts);
		Tip("Off (VTank's way): a rule that goes to the state you're in does nothing.\nOn: the state's rules start over (each can fire again, its timers restart).\n/mt set MetaSameRestarts on|off");
		return flag;
	}
}
