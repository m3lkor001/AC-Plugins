using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using MelkTank.Metas;
using AcClient;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Bounties;
using MelkTank.Buffs;

namespace MelkTank;

public static partial class Session
{
	private static void DrawBounties()
	{
		Settings currentSettings = PluginCore.CurrentSettings;
		BountyTracker current = BountyTracker.Current;
		if (currentSettings == null || current == null)
		{
			Im.TextColored(BGrey, "Not logged in yet.");
			return;
		}
		bool flag = false;
		if (ImGui.Checkbox("Bounty pop-up##bhud", ref currentSettings.BountyHudOn))
		{
			flag = true;
			current.Enabled = currentSettings.BountyHudOn;
			if (BountyHud.Current != null)
			{
				BountyHud.Current.Visible = currentSettings.BountyHudOn;
			}
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("The small bounty window. Off: it's hidden and /bounty isn't asked (the list below only updates on Refresh).");
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		int v = currentSettings.BountyMinutes;
		if (ImGui.InputInt("min between /bounty##bmin", ref v, 1, 5))
		{
			currentSettings.BountyMinutes = Math.Max(1, Math.Min(60, v));
			current.IntervalSeconds = currentSettings.BountyMinutes * 60;
			flag = true;
		}
		ImGui.SameLine();
		flag |= ImGui.Checkbox("Show kill tasks##bkts", ref currentSettings.BountyShowKts);
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("MelksQB's kill tasks (its KTs tab - the ones ticked to show on the pop-up) under the bounties.");
		}
		ImGui.SameLine();
		if (ImGui.Button("Refresh list##brefresh"))
		{
			current.RequestList();
		}
		string text = ((current.All.Count == 0) ? "Bounty list: loading after login..." : (current.All.Count + " bounties"));
		if (current.Tier >= 0)
		{
			text = text + "  -  this area: tier " + current.Tier;
		}
		if (!currentSettings.BountyHudOn)
		{
			text += "  -  pop-up off: the list only updates on Refresh";
		}
		else if (current.Paused && current.UpdatedAt != DateTime.MinValue)
		{
			text += "  -  no bounties count here, waiting for a portal";
		}
		else if (current.UpdatedAt != DateTime.MinValue)
		{
			text = text + "  -  updated " + (int)(DateTime.Now - current.UpdatedAt).TotalSeconds + "s ago";
		}
		Im.TextColored(BGrey, text + "   (green = counts here, gold = ready)");
		string text2 = CoinLine();
		if (text2.Length > 0)
		{
			Im.TextColored(BGold, text2);
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip(CoinTip());
			}
		}
		if (current.All.Count > 0 && ImGui.BeginTable("bountylist", 4, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("Zone", ImGuiTableColumnFlags.WidthFixed, 200f);
			ImGui.TableSetupColumn("Reward", ImGuiTableColumnFlags.WidthFixed, 260f);
			ImGui.TableSetupColumn("Kills", ImGuiTableColumnFlags.WidthFixed, 200f);
			ImGui.TableSetupColumn("Limit", ImGuiTableColumnFlags.WidthStretch);
			ImGui.TableHeadersRow();
			foreach (Bounty item in current.All)
			{
				bool flag2 = false;
				foreach (Bounty item2 in current.Here)
				{
					if (current.ListEntryFor(item2) == item)
					{
						flag2 = true;
					}
				}
				bool flag3 = BountyTracker.IsAllZones(item) && !current.AllZonesCount;
				Vector4 col;
				if (item.Need > 0 && item.Have >= item.Need)
				{
					col = BGold;
				}
				else
				{
					col = ((flag2 && !flag3) ? BGreen : Vector4.One);
				}
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				Im.TextColored(col, item.Zone);
				ImGui.TableSetColumnIndex(1);
				Im.TextColored(col, item.Reward);
				ImGui.TableSetColumnIndex(2);
				if (item.Locked)
				{
					Im.TextColored(BOrange, "unlocks in " + BountyTracker.Countdown(item.UnlocksIn));
				}
				else
				{
					string text3 = ((flag2 && !flag3) ? current.TimeToGo(item) : "");
					Im.TextColored(col, item.Have.ToString("N0", CultureInfo.InvariantCulture) + " / " + item.Need.ToString("N0", CultureInfo.InvariantCulture) + ((text3.Length > 0) ? ("  (" + text3 + ")") : ""));
				}
				ImGui.TableSetColumnIndex(3);
				Im.TextColored(BGrey, item.Limit);
			}
			ImGui.EndTable();
		}
		if (!flag)
		{
			return;
		}
		try
		{
			PluginCore.SaveAllNow();
		}
		catch
		{
		}
	}

	// luminance tokens earned as you go: each kill that counts toward a bounty paying Thaelaryn Tokens of Luminance is worth
	// its share of the reward (Wailing Cells: 1 token per 1,200 kills = 50 B / 1,200 a kill) - so an hour in Wailing Cells
	// waiting out the T12 bounty's cooldown shows in lum/hr, not only the moment a token arrives two hours later
	public static bool LumFromBountyProgress = true;
	private static double _lumProgress;
	private static readonly Regex TokRewardRx = new Regex("^(?:(?<n>[\\d,]+)\\s+)?Thaelaryn Tokens? of Luminance\\b", RegexOptions.IgnoreCase);

	/// <summary>What the luminance-token bounties you're on pay an hour at your kills/hr over the last 60 min, with a line per bounty.</summary>
	public static double TokenBountyPace(out string lines)
	{
		lines = "";
		double total = 0.0;
		// (what each kill adds to lum/hr, kill by kill, is spread the same way)
		BountyTracker t = BountyTracker.Current;
		double kph = KillsPerHourEstimate;
		if (t == null || kph <= 0.0 || LumTokenValue <= 0.0) return 0.0;
		NoteCooldowns(t);
		foreach (Bounty b in t.HereBounties())
		{
			Match m = TokRewardRx.Match((b.Reward ?? "").Trim());
			if (!m.Success) continue;
			int n = 1;
			if (m.Groups["n"].Success) int.TryParse(m.Groups["n"].Value.Replace(",", ""), out n);
			// (a reward, then its cooldown - an hour unless the bounty's limit says otherwise - when kills here don't count
			// toward it: the pace is the reward over the kills' time and the cooldown together)
			double killHrs = b.Need / kph;
			double cdHrs = BountyCooldown(b).TotalHours;
			double r = n * LumTokenValue / (killHrs + cdHrs);
			total += r;
			lines += "\n" + b.Zone + ": " + n + " token" + (n == 1 ? "" : "s") + " / " + b.Need.ToString("N0") + " kills at " + kph.ToString("N0") + " kills/hr = " + killHrs.ToString("0.0") + " hr" + (cdHrs > 0.0 ? (" + " + cdHrs.ToString("0.#") + " hr cooldown") : " (no cooldown)") + " = " + Big(r) + "/hr";
		}
		return total;
	}

	/// <summary>How long a bounty can't be worked on after it pays: from its limit in /bounty list ("1 hr", "per hour", "daily"),
	/// the longest wait seen this session, else an hour.</summary>
	private static readonly Dictionary<string, TimeSpan> _cdSeen = new Dictionary<string, TimeSpan>(StringComparer.OrdinalIgnoreCase);

	private static string CdKey(Bounty b) => (b.Zone ?? "") + "|" + (b.Reward ?? "");

	private static void NoteCooldowns(BountyTracker t)
	{
		try
		{
			foreach (Bounty b in t.All)
			{
				if (!b.Locked) continue;
				TimeSpan left = b.UnlocksIn;
				string k = CdKey(b);
				if (!_cdSeen.TryGetValue(k, out var was) || left > was) _cdSeen[k] = left;
			}
		}
		catch { }
	}

	private static TimeSpan BountyCooldown(Bounty b)
	{
		string lim = "";
		try { lim = BountyTracker.Current?.LimitFor(b) ?? ""; } catch { }
		if (string.IsNullOrWhiteSpace(lim)) lim = b.Limit ?? "";
		TimeSpan t = TimeSpan.Zero;
		try { t = BountyParser.ParseSpan(lim); } catch { }
		if (t > TimeSpan.Zero) return t;
		// (seen waiting out a cooldown longer than the usual hour this session: the longest wait seen - a shorter one may
		// only be what was left of it when it was first seen)
		if (_cdSeen.TryGetValue(CdKey(b), out var seen) && seen > TimeSpan.FromHours(1.0)) return seen;
		if (Regex.IsMatch(lim, "(per|an?|/|each)\\s*(hour|hr|h)\\b|hourly", RegexOptions.IgnoreCase)) return TimeSpan.FromHours(1.0);
		if (Regex.IsMatch(lim, "(per|a|/|each)\\s*day\\b|daily", RegexOptions.IgnoreCase)) return TimeSpan.FromDays(1.0);
		// (nothing said: the hour a bounty waits after it pays)
		return TimeSpan.FromHours(1.0);
	}

	/// <summary>Credits the kills a token bounty here already has (made before kill-by-kill counting was on). Once per session.</summary>
	public static bool _progressCredited;
	public static long CreditBountyProgress()
	{
		BountyTracker t = BountyTracker.Current;
		if (t == null || _progressCredited || LumTokenValue <= 0.0) return 0;
		double add = 0.0;
		foreach (Bounty b in t.HereBounties())
		{
			Match m = TokRewardRx.Match((b.Reward ?? "").Trim());
			if (!m.Success) continue;
			int n = 1;
			if (m.Groups["n"].Success) int.TryParse(m.Groups["n"].Value.Replace(",", ""), out n);
			add += n * LumTokenValue * Math.Min(b.Have, b.Need) / b.Need;
		}
		if (add >= 1.0)
		{
			_lumEarned += (long)add;
			LumFromBountyKills += (long)add;
			_progressCredited = true;
			_ratesAt = DateTime.MinValue;
			Util.WriteToChat("Session: +" + Big(add) + " luminance for the token-bounty kills you already had.");
		}
		return (long)add;
	}

	private static void BountyProgressKill()
	{
		if (!LumFromBountyProgress || !CountLumTokens || LumTokenValue <= 0.0) return;
		BountyTracker t = BountyTracker.Current;
		if (t == null) return;
		// (each kill gets an even share of the reward over the whole round - the kills that fill it and the cooldown after,
		// when kills don't count: kill on through the cooldown and it adds up to the reward; read kill by kill only while it
		// filled, lum/hr ran at double for the first hour and only came down once the cooldown was under way)
		double kph = KillsPerHourEstimate;
		NoteCooldowns(t);
		foreach (Bounty b in t.HereBounties(withLocked: true))
		{
			Match m = TokRewardRx.Match((b.Reward ?? "").Trim());
			if (!m.Success) continue;
			int n = 1;
			if (m.Groups["n"].Success) int.TryParse(m.Groups["n"].Value.Replace(",", ""), out n);
			double cdKills = kph > 0.0 ? BountyCooldown(b).TotalHours * kph : 0.0;
			_lumProgress += n * LumTokenValue / (b.Need + cdKills);
		}
		if (_lumProgress >= 1.0)
		{
			long whole = (long)_lumProgress;
			_lumEarned += whole;
			LumFromBountyKills += whole;
			_lumProgress -= whole;
		}
	}

	public static BountyTier Bounty(int tier)
	{
		LoadBountyTiers();
		if (!_bountyTiers.TryGetValue(tier, out var value))
		{
			value = new BountyTier();
			_bountyTiers[tier] = value;
		}
		return value;
	}

	private static void LoadBountyTiers()
	{
		if (_bountyLoaded)
		{
			return;
		}
		_bountyLoaded = true;
		try
		{
			string f = BountyFile;
			if (!File.Exists(f))
			{
				return;
			}
			string[] array = Util.Locked(f, () => File.ReadAllLines(f));
			foreach (string text in array)
			{
				if (!text.StartsWith("#"))
				{
					string[] array2 = text.Split('\t');
					if (array2.Length >= 4 && int.TryParse(array2[0], out var result) && double.TryParse(array2[1], NumberStyles.Float, CultureInfo.InvariantCulture, out var result2) && double.TryParse(array2[2], NumberStyles.Float, CultureInfo.InvariantCulture, out var result3) && int.TryParse(array2[3], out var result4))
					{
						_bountyTiers[result] = new BountyTier
						{
							RewardB = result2,
							CooldownMin = result3,
							Kills = result4,
							Set = true
						};
					}
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void SaveBountyTiers()
	{
		try
		{
			StringBuilder stringBuilder = new StringBuilder("# MelkTank: bounty reward per tier - tier, reward (billions of lum), cooldown (min), kills per reward\r\n");
			List<int> list = new List<int>(_bountyTiers.Keys);
			list.Sort();
			foreach (int item in list)
			{
				BountyTier bountyTier = _bountyTiers[item];
				if (bountyTier.Set)
				{
					stringBuilder.Append(item).Append('\t').Append(bountyTier.RewardB.ToString(CultureInfo.InvariantCulture))
						.Append('\t')
						.Append(bountyTier.CooldownMin.ToString(CultureInfo.InvariantCulture))
						.Append('\t')
						.Append(bountyTier.Kills)
						.Append("\r\n");
				}
			}
			Util.WriteShared(BountyFile, stringBuilder.ToString());
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static double BountyLumPerHour()
	{
		if (!BountyRateOn)
		{
			return -1.0;
		}
		int num = -1;
		try
		{
			num = CurrentTier();
		}
		catch
		{
		}
		if (num < 11 || num > 25)
		{
			return -1.0;
		}
		double killsPerHourRecent = KillsPerHourEstimate;
		if (killsPerHourRecent <= 0.0)
		{
			return -1.0;
		}
		BountyTier bountyTier = Bounty(num);
		double num2 = (double)bountyTier.Kills / killsPerHourRecent + bountyTier.CooldownMin / 60.0;
		return (num2 > 0.0) ? (bountyTier.RewardB * 1000000000.0 / num2) : (-1.0);
	}

	public static bool DrawBountySettings(Settings s)
	{
		bool result = false;
		if (Im.WithTip("/mt set BountyLumRate on|off", ImGui.Checkbox("T11+: lum/hr from the bounty reward##bountyrate", ref s.BountyLumRate)))
		{
			result = true;
			BountyRateOn = s.BountyLumRate;
			_ratesAt = DateTime.MinValue;
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("In T11-T25 all the luminance comes from the bounty: a reward every N kills, then a cooldown before kills count again.\nOn: once the session is 1 minute old, lum/hr = reward / (N kills at your kills/hr over the last 60 min + the cooldown).\nIt's used everywhere lum/hr shows (Session tab, the phone, Augs) while you're in T11-T25; anywhere else, the measured lum/hr.");
		}
		int num = -1;
		try
		{
			num = CurrentTier();
		}
		catch
		{
		}
		if (_bountyPick < 0)
		{
			_bountyPick = ((num >= 11 && num <= 25) ? num : 11);
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(80f);
		if (ImGui.BeginCombo("##bountytier", "T" + _bountyPick))
		{
			for (int i = 11; i <= 25; i++)
			{
				if (ImGui.Selectable("T" + i + ((i == num) ? "  (here)" : "") + (Bounty(i).Set ? "" : "  -"), i == _bountyPick))
				{
					_bountyPick = i;
				}
			}
			ImGui.EndCombo();
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Pick a tier to see / set its bounty. The tier you're in is used (it follows you); '-' = not set yet (default numbers).");
		}
		BountyTier bountyTier = Bounty(_bountyPick);
		bool flag = false;
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		float v = (float)bountyTier.RewardB;
		if (ImGui.InputFloat("B reward##bountyrew", ref v, 0f, 0f, "%.0f"))
		{
			bountyTier.RewardB = Math.Max(0f, v);
			flag = true;
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(70f);
		float v2 = (float)bountyTier.CooldownMin;
		if (ImGui.InputFloat("min cooldown##bountycd", ref v2, 0f, 0f, "%.0f"))
		{
			bountyTier.CooldownMin = Math.Max(0f, v2);
			flag = true;
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(70f);
		int v3 = bountyTier.Kills;
		if (ImGui.InputInt("kills##bountykills", ref v3, 0, 0))
		{
			bountyTier.Kills = Math.Max(1, v3);
			flag = true;
		}
		if (flag)
		{
			bountyTier.Set = true;
			SaveBountyTiers();
			_ratesAt = DateTime.MinValue;
		}
		if (!bountyTier.Set)
		{
			ImGui.SameLine();
			Im.TextDisabled("(default)");
		}
		double killsPerHourRecent = KillsPerHourEstimate;
		if (num < 11 || num > 25)
		{
			Im.TextDisabled("   You're not in T11-T25 (tier " + ((num < 0) ? "unknown" : num.ToString()) + ") - the measured lum/hr is used.");
		}
		else if (killsPerHourRecent <= 0.0)
		{
			Im.TextDisabled("   T" + num + ": after 1 minute of the session (needs kills/hr).");
		}
		else
		{
			BountyTier bountyTier2 = Bounty(num);
			double num2 = (double)bountyTier2.Kills / killsPerHourRecent * 60.0;
			double num3 = num2 + bountyTier2.CooldownMin;
			Im.TextDisabled("   T" + num + ": " + killsPerHourRecent.ToString("N0") + " kills/hr -> " + bountyTier2.Kills + " kills in " + num2.ToString("0.0") + " min + " + bountyTier2.CooldownMin.ToString("0") + " min cooldown = a reward every " + num3.ToString("0.0") + " min -> " + Big(bountyTier2.RewardB * 1000000000.0 * 60.0 / num3) + " lum/hr" + (s.BountyLumRate ? "" : "  (off)"));
		}
		return result;
	}
}
