using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
#if !RETAIL
using ACGodot.DecalShim;
using ACGodot.Plugins;
using ACGodot.UI;
#endif
#if !RETAIL
using AcClient;
#else
using SmartBox = AcClient.SmartBox;
using ACCmdInterp = AcClient.ACCmdInterp;
using CommandInterpreter = AcClient.CommandInterpreter;
using CommandListElement = AcClient.CommandListElement;
using CPhysicsObj = AcClient.CPhysicsObj;
using Position = AcClient.Position;
using CTransition = AcClient.CTransition;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
#if !RETAIL
using Godot;
#endif
using ImGuiNET;
using MelkTank.Loot;
using MelkTank.Metas;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public partial class Nav
{
	private class TreeDir
	{
		public string Path;

		public string Name;

		public List<TreeDir> Dirs = new List<TreeDir>();

		public List<string> Files = new List<string>();
	}

	public Func<bool> MetaNeedBuff;

	private string _mState = "Default";

	private DateTime _mStateAt = DateTime.Now;

	private DateTime _mStatePersistAt = DateTime.Now;

	private DateTime _mNextTick = DateTime.MinValue;

	private readonly HashSet<MRule> _mFired = new HashSet<MRule>();

	private readonly List<string> _mChat = new List<string>();

	private readonly Stack<string> _mCalls = new Stack<string>();

	private bool _mDied;

	private bool _mPortalIn;

	private bool _mPortalOut;

	private bool _mVendorSeen;

	private Meta _mMeta;

	private NavRoute _metaRoute;

	private MVal _metaRouteSrc;

	private string _wdState;

	private double _wdDist;

	private double _wdSecs;

	private DateTime _wdAt;

	private double _wdNS;

	private double _wdEW;

	private bool _wdOn;

	private readonly HashSet<string> _mWarned = new HashSet<string>();

	private readonly Dictionary<string, string> _mOpts = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

	private readonly Dictionary<string, Regex> _mRx = new Dictionary<string, Regex>();

	public readonly List<string> MetaLog = new List<string>();

	private bool _mWasWaiting;

	private bool _metaWasRunning;

	private bool _metaSeen;

	private static readonly Regex AddPtRx = new Regex("(-?\\d+(?:\\.\\d+)?)\\s*([NS])[\\s,]+(-?\\d+(?:\\.\\d+)?)\\s*([EW])(?:[\\s,]+(-?\\d+(?:\\.\\d+)?)\\s*Z?)?", RegexOptions.IgnoreCase);

	private List<string> _metaNames;

	private DateTime _metaNamesAt = DateTime.MinValue;

	private static readonly System.Numerics.Vector4 Cyan = new System.Numerics.Vector4(0.35f, 0.85f, 0.95f, 1f);

	private static readonly System.Numerics.Vector4 Green = new System.Numerics.Vector4(0.45f, 0.9f, 0.45f, 1f);

	private static readonly System.Numerics.Vector4 Grey = new System.Numerics.Vector4(0.6f, 0.6f, 0.6f, 1f);

	private static readonly System.Numerics.Vector4 Yellow = new System.Numerics.Vector4(0.95f, 0.85f, 0.35f, 1f);

	private static readonly System.Numerics.Vector4 Red = new System.Numerics.Vector4(0.95f, 0.35f, 0.35f, 1f);

	private readonly Settings _s;

	public Action SaveAll;

	private static bool _liveOk;

	private static bool _liveWarned;

	public static double LiveDiff;

	private bool _running;

	private DateTime _runStart;

	private DateTime _lastFace = DateTime.MinValue;

	private DateTime _lastProgressAt;

	private DateTime _pauseUntil = DateTime.MinValue;

	private DateTime _lastHeadingFix = DateTime.MinValue;

	private double _bestDist;

	private bool _pulsing;

	private DateTime _pulseOnUntil = DateTime.MinValue;

	private DateTime _pulseOffUntil = DateTime.MinValue;

	private string _tooFarNoted;

	public Action<string> Log;

	private DateTime _lastReturnTick = DateTime.MinValue;

	private double _mapLastNS;

	private double _mapLastEW;

	private double _mapLastD = double.MaxValue;

	public int StuckEvents;

	private bool _moving;

	private bool _warnedDir;

	private double _kickBest = double.MaxValue;

	private int _restartStage;

	private int _kicks;

	private DateTime _restartAt = DateTime.MinValue;

	private DateTime _kickAt = DateTime.MinValue;

	private DateTime _turnStart;

	private double _startNS;

	private double _startEW;

	private double _startZ;

	private double _startHeading;

	private D3DObj _ring;

	private D3DObj _label;

	private D3DObj _arrow;

	private DateTime _labelCheck = DateTime.MinValue;

	private string _drawnKey = "";

	private DateTime _markersAt = DateTime.MinValue;

	private D3DObj _test;

	private DateTime _testAt = DateTime.MinValue;

	private int _testStage;

	private static int _visFails;

	private static string _visFirst;

	private bool? _lastFocused;

	public const string LeftoversKey = "MelkTank.D3DLeftovers";

	private string _newName = "";

	public Action DrawPortals;

	private bool _retarget;

	private DateTime _lastDirectSteer = DateTime.MinValue;

	private static readonly Regex ChamberWord = new Regex("\\bchambers?\\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);

	private static readonly Regex NumberRx = new Regex("\\bchamber\\s*(?:#|no\\.?|number)?\\s*(\\d{1,2})\\b|\\b(\\d{1,2})(?:st|nd|rd|th)?\\s+chamber\\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);

	private static readonly Regex SpotNumberRx = new Regex("(?:C|chamber\\s*)0*(\\d+)$", RegexOptions.IgnoreCase | RegexOptions.Compiled);

	private static readonly string[][] DungeonAliases = new string[3][]
	{
		new string[2] { "wailing", "banshee" },
		new string[2] { "idol", "idol" },
		new string[2] { "quarry", "drudge" }
	};

	private int _chamber = -1;

	private string _chamberText = "";

	private DateTime _chamberDue = DateTime.MaxValue;

	private bool _navWasOn;

	private static string _earlyText;

	private static DateTime _earlyAt = DateTime.MinValue;

	private int _doorId;

	private DateTime _doorAt = DateTime.MinValue;

	private DateTime _doorPickAt = DateTime.MinValue;

	private bool _doorLocked;

	private readonly Dictionary<int, int> _doorTries = new Dictionary<int, int>();

	private readonly HashSet<int> _doorNoPick = new HashSet<int>();

	private const int ResistLockpick = 38;

	public Func<string> FileDir;

	private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

	private bool _showVtankDir;

	private string _pickFile;

	private string _pickFolder;

	private DateTime _treeAt = DateTime.MinValue;

	private TreeDir _tree;

	private DateTime _routeDirtyAt = DateTime.MinValue;

	private bool _filesChecked;

	private DateTime _spotDirtyAt = DateTime.MinValue;

	private bool _spotFilesChecked;

	private DateTime _fLastSeen = DateTime.MinValue;

	private DateTime _fPortalUsedAt = DateTime.MinValue;

	private DateTime _fLostSaid = DateTime.MinValue;

	private double _fLastNS;

	private double _fLastEW;

	private bool _fHasLast;

	private D3DObj _fRing;

	private D3DObj _fArrow;

	private int _fMarked;

	private string _fMarkKey = "";

	private DateTime _fVisCheck = DateTime.MinValue;

	private readonly List<NavSpot> _crumbs = new List<NavSpot>();

	private const string HotKey = "MelkTank.NavHotCarry";

	private bool _hotTried;

	private static readonly CultureInfo HCI = CultureInfo.InvariantCulture;

	public const string MapRouteName = "Map route";

	public const string MapRouteKey = "MelkTank.MapRoute";

	private static readonly CultureInfo MCI = CultureInfo.InvariantCulture;

	private string _mapPublished;

	private DateTime _mapPubAt = DateTime.MinValue;

	private Meta _meta;

	private string _metaState = "Default";

	private int _metaEdit = -1;

	private string _metaNewState = "";

	private string _metaRename = "";

	private bool _metaTriedLast;

	private List<string> _pickList = new List<string>();

	private DateTime _pickListAt = DateTime.MinValue;

	private bool _pickListVt;

	private static readonly Dictionary<uint, string> _newStateBuf = new Dictionary<uint, string>();

	private static readonly string[] _condNames = CondNames();

	private static readonly string[] _actNames = ActNames();

	public const string MtRouteTag = "<MelkTankRoute";

	private static readonly Regex VtGetRx = new Regex("^\\s*\\$(?<var>\\w+)\\s*=\\s*(?:tostring\\[\\s*)?vtgetsetting\\[\\s*`?(?<opt>\\w+)`?\\s*\\](?:\\s*\\])?\\s*$", RegexOptions.IgnoreCase);

	private static readonly Regex VtSetVarRx = new Regex("^\\s*vtsetsetting\\[\\s*`?(?<opt>\\w+)`?\\s*,\\s*(?<val>\\$\\w+)\\s*\\]\\s*$", RegexOptions.IgnoreCase);

	private static readonly Regex VtSetFixedRx = new Regex("^\\s*vtsetsetting\\[\\s*`?(?<opt>\\w+)`?\\s*,\\s*`?(?<val>\\w+)`?\\s*\\]\\s*$", RegexOptions.IgnoreCase);

	private static readonly Regex VtSetInnerRx = new Regex("vtsetsetting\\[\\s*(?<opt>\\w+)\\s*,\\s*(?<esc>\\\\*)`(?<val>[^`\\\\]*)\\k<esc>`\\s*\\]", RegexOptions.IgnoreCase);

	private int _vtCountCache = -1;

	private Meta _vtCountMeta;

	private DateTime _vtCountAt;

	private DateTime _metaTreeAt = DateTime.MinValue;

	private TreeDir _metaTree;

	private string _metaPick;

	private static readonly System.Numerics.Vector4 Purple = new System.Numerics.Vector4(0.78f, 0.6f, 0.98f, 1f);

	private int _rPresetPick;

	private readonly HashSet<RouteStep> _presetClosed = new HashSet<RouteStep>();

	private string _pName = "";

	private string _pNewName = "";

	private int _pSel = -1;

	private RouteStep _pEdit;

	public static readonly string[] RouteModes = new string[3] { "Once", "Back and forth (linear)", "Round and round (circular)" };

	public static readonly string[] StuckActions = new string[5] { "Keep trying", "Turn combat on", "Back up and try again", "Start the route over", "Skip that point" };

	private int _rLastCount = -1;

	private bool _rSkipNoMobs;

	private int _rStuckSeen;

	private int _rStuckIdx = -1;

	private int _rStuckN;

	private bool _rTempCombat;

	private readonly List<int> _rDetour = new List<int>();

	private bool _recording;

	private float _recEvery = 10f;

	private double _recNS;

	private double _recEW;

	private DateTime _recNext = DateTime.MinValue;

	private string _recRoute = "";

	private int _rIdx;

	private int _rDir = 1;

	private bool _rDone;

	private bool _rStarted;

	private DateTime _rFarRestartAt = DateTime.MinValue;

	private DateTime _rUntil = DateTime.MinValue;

	private DateTime _rUsedAt = DateTime.MinValue;

	private string _rName = "";

	private int _rLandblock;

	private int _rSel = -1;

	private string _rNewName = "";

	private string _rCmd = "";

	private int _rCmdWait = 1000;

	private int _rWaitSecs = 5;

	private int _rToggle;

	private static readonly string[] GoWhere = new string[2] { "from step 1", "at its nearest point" };

	private int _rGoPick;

	private int _rGoWhere;

	private int _rGemPick;

	private int _rGemWait = 10;

	private int _rRecallPick;

	private string _rGem = "";

	private string _rVendorNpc = "";

	private string _rVendorProfile = "";

	private List<KeyValuePair<int, string>> _recalls;

	private string _rcText = "";

	private string _rcChat = "";

	private int _rcOp = 4;

	private int _rcNum = 30;

	private int _rcChatOp;

	public static readonly string[] ChatOps = new string[2] { "contains", "=" };

	public static readonly string[] ItemOps = new string[6] { "=", "!=", "<", ">", ">=", "<=" };

	private string _rChat = "";

	private string _rItem = "";

	private int _rChatOp;

	private int _rItemOp = 4;

	private int _rItemNum = 1;

	private int _rSkipM = 20;

	private int _rSkipN = 3;

	private DateTime _rStepAt = DateTime.Now;

	private DateTime _rPrevStepAt = DateTime.Now;

	private DateTime _rItemCheckAt = DateTime.MinValue;

	private readonly List<KeyValuePair<DateTime, string>> _chat = new List<KeyValuePair<DateTime, string>>();

	public const double LoopPreferM = 10.0;

	private static readonly string[] ToggleNames = new string[9] { "Combat ON", "Combat OFF", "Looting ON", "Looting OFF", "Summoning ON", "Summoning OFF", "Reset session", "Doors ON", "Doors OFF" };

	private static readonly string[] ToggleTexts = new string[10] { "combat on", "combat off", "looting on", "looting off", "summoning on", "summoning off", "reset session", "doors on", "doors off", "reset kills/hr" };

	private double _rStuckAcc;

	private int _rStuckStep = -1;

	private string _rStuckRoute = "";

	private DateTime _rStuckLast = DateTime.MinValue;

	private bool _inPortal;

	private DateTime _portalExitAt = DateTime.MinValue;

	private DateTime _diedAt = DateTime.MinValue;

	private int _rUseIdx = -1;

	private int _rUseTries;

	private int _rUseHad;

	private DateTime _rUseRetryAt = DateTime.MinValue;

	private int _rSub;

	private int _rSubFor = -1;

	private readonly HashSet<string> _presetWarned = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

	private bool _farEndNoted;

	private bool _resumeNearest;

	private const double ResumeNearestM = 500.0;

	private DateTime _rTickAt = DateTime.MinValue;

	private readonly List<D3DObj> _routeObjs = new List<D3DObj>();

	private const int RouteWindow = 150;

	private const int MaxRouteObjs = 1500;

	private string _routeKey = "";

	private DateTime _routeVisCheck = DateTime.MinValue;

	private int _tUseIdx = -1;

	private int _tUseTries;

	private bool _rCastWield;

	private DateTime _rCastModeAt = DateTime.MinValue;

	private DateTime _useFaceUntil = DateTime.MinValue;

	private const float BtnW = 150f;

	private const float StepsTableW = 606f;

	private RouteStep _rEdit;

	private float _rAddH;

	private double _rEditNS;

	private double _rEditEW;

	private double _rEditZ;

	private string _rEditName = "";

	private const uint TurnRightMotion = 1694498829u;

	private const uint TurnLeftMotion = 1694498830u;

	private double _steerWant = -1.0;

	private DateTime _steerWantAt = DateTime.MinValue;

	private int _turning;

	private int _turnSign = 1;

	private double _turnStartDiff;

	private DateTime _turnStartAt;

	private bool _motionBroken;

	private int _steerLogs;

	private Hud _toolsHud;

	public const string TravelStateKey = "MelkTank.Travel";

	private NavRoute _travelRoute;

	private NavRoute _travelPreview;

	private bool _tWasEnabled;

	private bool _tWasMaster;

	private bool _tWasCombat;

	private bool _tCombatOff;

	private int _tWasMode;

	private string _tWasRoute = "";

	private DateTime _autorunOnAt = DateTime.MinValue;

	private DateTime _tStartedAt = DateTime.MinValue;

	private DateTime _doorUseAt = DateTime.MinValue;

	private bool _doorRerun;

	private int _tStep = -1;

	private int _tStuckBase;

	private int _tFlagOff;

	private double _tStepSecs;

	private DateTime _tTickAt = DateTime.MinValue;

	private DateTime _tLastTurn = DateTime.MinValue;

	private DateTime _tFlagAt = DateTime.MinValue;

	private bool _tFlagSeen;

	private DateTime _tKeyAt = DateTime.MinValue;

	private const uint WalkBackMotion = 1157627910u;

	private const uint SideRightMotion = 1694498831u;

	private const uint SideLeftMotion = 1694498832u;

	private NavSpot _tDetour;

	private DateTime _tProbeAt = DateTime.MinValue;

	private DateTime _tDetourAt = DateTime.MinValue;

	private int _tDetourFor = -1;

	private int _tSide;

	private static int _wallState;

	private static bool _wallProven;

	private readonly Dictionary<int, DateTime> _tDoorUsed = new Dictionary<int, DateTime>();

	private DateTime _tDoorWait = DateTime.MinValue;

	private readonly Dictionary<int, DateTime> _doorAsked = new Dictionary<int, DateTime>();

	private DateTime _useDoorWait = DateTime.MinValue;

	private int _tLastDoor;

	private DateTime _tLastDoorAt;

	private bool _tLastDoorAgain;

	private readonly List<double[]> _tHits = new List<double[]>();

	private double _tHitD;

	private double _tHeading;

	private double _tFollowM;

	private double _tTurned;

	private DateTime _tPushUntil = DateTime.MinValue;

	private DateTime _tFollowAt;

	private bool _tFlipped;

	private static double _pBearing;

	private static double _pSlope = double.NaN;

	public bool MetaRunning => _s.MetaRun && _meta != null;

	public string MetaCurState => _mState;

	public string MetaName => (_meta != null) ? (_meta.Name ?? "") : "";

	public bool InPortal => _inPortal;

	public string Status { get; private set; }

	public NavSpot Current
	{
		get
		{
			foreach (NavSpot navSpot in _s.NavSpots)
			{
				if (string.Equals(navSpot.Name, _s.NavSelected, StringComparison.OrdinalIgnoreCase))
				{
					return navSpot;
				}
			}
			return null;
		}
	}

	private static double PulseRange => Tuning.V("PulseRangeM");

	public bool Running => _running;

	public bool Away
	{
		get
		{
			NavSpot navSpot = ((_s.NavEnabled && _s.NavMode == 0) ? Current : null);
			if (navSpot == null || DateTime.Now < _pauseUntil)
			{
				return false;
			}
			double num = DistanceTo(navSpot);
			return num > (double)_s.NavDrift;
		}
	}

	private bool OpenDoorsNow => _s.NavOpenDoors || _travelRoute != null;

	public static string NavDir => Util.ProfilesDir("Navs");

	public static string VtankDir
	{
		get
		{
			string[] array = new string[3] { "C:\\Games\\VirindiPlugins\\VirindiTank", "C:\\Program Files\\VirindiPlugins\\VirindiTank", "C:\\Program Files (x86)\\VirindiPlugins\\VirindiTank" };
			foreach (string text in array)
			{
				if (Directory.Exists(text))
				{
					return text;
				}
			}
			return null;
		}
	}

	private string Dir => (_showVtankDir && VtankDir != null) ? VtankDir : NavDir;

	public static string SpotDir => Path.Combine(NavDir, "Spots");

	private static double CrumbStep => Tuning.V("CrumbStepM");

	private static double CrumbArrive => Tuning.V("CrumbArriveM");

	public Meta CurrentMeta => _meta;

	public static string MetaDir => Util.ProfilesDir("Metas");

	public bool Recording => _recording;

	public NavRoute CurrentRoute
	{
		get
		{
			if (_travelRoute != null && string.Equals(_travelRoute.Name, _s.NavRouteSelected, StringComparison.Ordinal))
			{
				return _travelRoute;
			}
			if (_metaRoute != null && string.Equals(_metaRoute.Name, _s.NavRouteSelected, StringComparison.Ordinal))
			{
				return _metaRoute;
			}
			foreach (NavRoute navRoute in _s.NavRoutes)
			{
				if (string.Equals(navRoute.Name, _s.NavRouteSelected, StringComparison.OrdinalIgnoreCase))
				{
					return navRoute;
				}
			}
			return null;
		}
	}

	public int RouteStepNow
	{
		get
		{
			try
			{
				return (_s.NavEnabled && _s.NavMode == 1 && CurrentRoute != null && !_rDone) ? (_rIdx + 1) : 0;
			}
			catch
			{
				return 0;
			}
		}
	}

	public bool RouteWalking
	{
		get
		{
			try
			{
				NavRoute currentRoute = CurrentRoute;
				if (RouteStepNow <= 0 || _rIdx >= currentRoute.Steps.Count || currentRoute.Steps[_rIdx].Kind != StepKind.Point)
				{
					return false;
				}
				int num = _rIdx + 1;
				if (num < currentRoute.Steps.Count && currentRoute.Steps[num].Kind == StepKind.Cast)
				{
					return false;
				}
				return true;
			}
			catch
			{
				return false;
			}
		}
	}

	public string RouteNameNow
	{
		get
		{
			try
			{
				NavRoute currentRoute = CurrentRoute;
				return (currentRoute != null) ? currentRoute.Name : "";
			}
			catch
			{
				return "";
			}
		}
	}

	private bool KeySteer => _s.NavSmoothSteer && !_motionBroken;

	public bool Travelling => _travelRoute != null;

	private static string WallPath => Util.FullPath("MelkTank_WallCheck.txt");

	public string ExprOptGet(string opt)
	{
		return OptGet(opt);
	}

	public void ExprOptSet(string opt, string val)
	{
		OptSet(opt, val);
	}

	public bool IsMetaRoute(NavRoute r)
	{
		return r != null && r == _metaRoute;
	}

	private void MLog(string s)
	{
		MetaLog.Add(DateTime.Now.ToString("HH:mm:ss") + "  " + s);
		if (MetaLog.Count > 60)
		{
			MetaLog.RemoveAt(0);
		}
		L("META  " + s);
	}

	private void MWarn(string key, string text)
	{
		if (_mWarned.Add(key))
		{
			Util.WriteToChat("Meta: " + text);
		}
	}

	public Nav(Settings s)
	{
		_s = s;
		Status = "";
		_resumeNearest = s.NavEnabled && s.NavMode == 1;
	}

	private static bool MyPos(out double ns, out double ew, out double z)
	{
		ns = (ew = (z = 0.0));
		double num = 0.0;
		double num2 = 0.0;
		double num3 = 0.0;
		bool flag = false;
		try
		{
			WorldObject worldObject = Globals.Core.WorldFilter[Globals.Core.CharacterFilter.Id];
			CoordsObject coordsObject = worldObject?.Coordinates();
			if (coordsObject != null)
			{
				num = coordsObject.NorthSouth;
				num2 = coordsObject.EastWest;
				num3 = worldObject.RawCoordinates().Z;
				flag = true;
			}
		}
		catch
		{
		}
		try
		{
			uint landcell = (uint)Globals.Core.Actions.Landcell;
			double locationX = Globals.Core.Actions.LocationX;
			double locationY = Globals.Core.Actions.LocationY;
			double locationZ = Globals.Core.Actions.LocationZ;
			if (landcell != 0 && !double.IsNaN(locationX) && !double.IsNaN(locationY))
			{
				double num4 = ((double)((landcell >> 24) & 0xFF) * 192.0 + locationX - 24468.0) / 240.0;
				double num5 = ((double)((landcell >> 16) & 0xFF) * 192.0 + locationY - 24468.0) / 240.0;
				if (!flag || (Math.Abs(num4 - num2) * 240.0 < 40.0 && Math.Abs(num5 - num) * 240.0 < 40.0))
				{
					ns = num5;
					ew = num4;
					z = locationZ;
					_liveOk = true;
					if (flag)
					{
						LiveDiff = Math.Sqrt(Math.Pow((num5 - num) * 240.0, 2.0) + Math.Pow((num4 - num2) * 240.0, 2.0));
					}
					return true;
				}
				if (!_liveWarned & flag)
				{
					_liveWarned = true;
					Util.WriteToChat("Nav: the live position doesn't match (" + ((num5 - num) * 240.0).ToString("0") + " m, " + ((num4 - num2) * 240.0).ToString("0") + " m off) - using the slower server position.");
				}
			}
		}
		catch
		{
		}
		if (!flag)
		{
			return false;
		}
		ns = num;
		ew = num2;
		z = num3;
		return true;
	}

	public double DistanceTo(NavSpot p)
	{
		if (p == null || !MyPos(out var ns, out var ew, out var _))
		{
			return -1.0;
		}
		double num = (p.NS - ns) * 240.0;
		double num2 = (p.EW - ew) * 240.0;
		return Math.Sqrt(num * num + num2 * num2);
	}

	private double BearingTo(NavSpot p)
	{
		if (!MyPos(out var ns, out var ew, out var _))
		{
			return 0.0;
		}
		double num = Math.Atan2(p.EW - ew, p.NS - ns) * 180.0 / Math.PI;
		return (num + 360.0) % 360.0;
	}

	public void Stop()
	{
		ReleaseTurn();
		if (!_running)
		{
			// (autorun nav switched on outside a run of its own - travel's door re-run, a pulse - is switched off too:
			// left on, it ran on with MelkTank off)
			if (_autorunMine)
			{
				_autorunMine = false;
				try
				{
					if (AutorunFlag() == 1)
					{
						Globals.Core.Actions.SetAutorun(on: false);
						L("stop: autorun nav had switched on was still on - off");
					}
				}
				catch
				{
				}
			}
			return;
		}
		_autorunMine = false;
		_running = false;
		_moving = false;
		_pulsing = false;
		_pulseOnUntil = (_pulseOffUntil = DateTime.MinValue);
		_restartStage = 0;
		_kicks = 0;
		try
		{
			Globals.Core.Actions.SetAutorun(on: false);
		}
		catch
		{
		}
	}

	private bool Active(out NavSpot p)
	{
		p = (_s.NavEnabled ? Current : null);
		return p != null && DateTime.Now >= _pauseUntil;
	}

	public bool PriorityTick()
	{
		if (_s.NavMode != 0)
		{
			return false;
		}
		if (!_s.NavPriority || !Active(out var p))
		{
			return false;
		}
		if (TooFar(p))
		{
			return false;
		}
		return ReturnTick(p);
	}

	public bool IdleTick()
	{
		RestoreHotState();
		if (_s.NavMode == 1)
		{
			return RouteTick();
		}
		if (_s.NavMode == 2)
		{
			return FollowTick();
		}
		if (!Active(out var p))
		{
			Stop();
			return false;
		}
		if (TooFar(p))
		{
			return false;
		}
		if (ReturnTick(p))
		{
			return true;
		}
		if (p.FaceHeading && p.Heading >= 0.0 && (DateTime.Now - _lastHeadingFix).TotalSeconds >= 2.0)
		{
			double num = CombatEngine.MyHeading();
			double num2 = ((num < 0.0) ? 0.0 : Math.Abs(((p.Heading - num) % 360.0 + 540.0) % 360.0 - 180.0));
			if (num2 > 5.0)
			{
				_lastHeadingFix = DateTime.Now;
				try
				{
					Globals.Core.Actions.FaceHeading(p.Heading, true);
				}
				catch
				{
				}
				Status = "Facing " + p.Heading.ToString("0") + " at " + p.Name;
				return true;
			}
		}
		return false;
	}

	private bool TooFar(NavSpot p)
	{
		double num = DistanceTo(p);
		if (num < 0.0 || num <= (double)Math.Max(100f, _s.NavMaxRunM))
		{
			_tooFarNoted = null;
			return false;
		}
		if (p.Name != null && p.Name.StartsWith("Map route #", StringComparison.OrdinalIgnoreCase))
		{
			_tooFarNoted = null;
			return false;
		}
		Stop();
		string text = ((num >= 1000.0) ? ((num / 1000.0).ToString("0.0") + " km") : (num.ToString("0") + " m"));
		Status = p.Name + " is " + text + " away - not here, waiting";
		if (_tooFarNoted != p.Name)
		{
			_tooFarNoted = p.Name;
			L("too far: " + p.Name + " is " + num.ToString("0") + " m away - not running there");
			Util.WriteToChat("Nav: " + p.Name + " is " + text + " away - you're not where it is, so Nav waits (it carries on once you're back within " + Math.Max(100f, _s.NavMaxRunM).ToString("0") + " m).");
		}
		return true;
	}

	private void L(string s)
	{
		if (Log != null)
		{
			Log("NAV   " + s);
		}
	}

	/// <summary>Runs toward a monster (combat's approach range) until it's within <paramref name="stopAt"/> metres: true
	/// while running there, false once close (stopped) or when it can't be read.</summary>
	public bool ApproachTick(WorldObject mob, double stopAt)
	{
		CoordsObject c = null;
		double z = 0.0;
		try
		{
			c = mob?.Coordinates();
			z = mob.RawCoordinates().Z;
		}
		catch
		{
		}
		if (c == null)
		{
			return false;
		}
		NavSpot spot = new NavSpot
		{
			Name = mob.Name,
			NS = c.NorthSouth,
			EW = c.EastWest,
			Z = z,
			Heading = -1.0,
			FaceHeading = false
		};
		if (_approachId != mob.Id)
		{
			_approachId = mob.Id;
			_retarget = true;
		}
		return ReturnTick(spot, stopAt, stopAt, precise: true);
	}

	private int _approachId;

	private bool ReturnTick(NavSpot p)
	{
		return ReturnTick(p, _s.NavDrift, Math.Min(0.7, (double)_s.NavDrift * 0.5), precise: true);
	}

	private bool ReturnTick(NavSpot p, double startDist, double arrive, bool precise)
	{
		double num = DistanceTo(p);
		if (num < 0.0)
		{
			Stop();
			return false;
		}
		if (_running && (DateTime.Now - _lastReturnTick).TotalSeconds > 1.0)
		{
			L("resumed after " + (DateTime.Now - _lastReturnTick).TotalSeconds.ToString("0.0") + "s away, " + num.ToString("0.0") + " m");
			_lastProgressAt = DateTime.Now;
			_bestDist = num;
			_kickBest = num;
			_kickAt = DateTime.Now;
		}
		_lastReturnTick = DateTime.Now;
		if (_retarget)
		{
			_retarget = false;
			_kickBest = num;
			_kickAt = DateTime.Now;
			_bestDist = num;
			_lastProgressAt = (_runStart = DateTime.Now);
			_lastFace = DateTime.MinValue;
		}
		if (!_running)
		{
			if (num <= startDist)
			{
				return false;
			}
			_running = true;
			_moving = false;
			_runStart = (_lastProgressAt = (_turnStart = DateTime.Now));
			_bestDist = num;
			_lastFace = DateTime.MinValue;
			_warnedDir = false;
			L("return to " + p.Name + " from " + num.ToString("0.0") + " m" + (_liveOk ? (" (live pos, " + LiveDiff.ToString("0.0") + " m from server pos)") : " (server pos)"));
		}
		if (num <= arrive)
		{
			L("arrived, " + num.ToString("0.0") + " m");
			if (precise)
			{
				Stop();
			}
			Status = "At " + p.Name;
			return false;
		}
		double num2 = BearingTo(p);
		double num3 = CombatEngine.MyHeading();
		double num4 = ((num3 < 0.0) ? 0.0 : AngleDiff(num2, num3));
		if (!_moving)
		{
			if ((DateTime.Now - _lastFace).TotalMilliseconds >= Tuning.V("FaceEveryMs"))
			{
				_lastFace = DateTime.Now;
				try
				{
					Globals.Core.Actions.FaceHeading(num2, true);
				}
				catch
				{
				}
			}
			if (num4 <= Tuning.V("FacingOkDeg") || (DateTime.Now - _turnStart).TotalSeconds > Tuning.V("TurnMaxS"))
			{
				_moving = true;
				_kickBest = num;
				_kickAt = DateTime.Now;
				_lastProgressAt = DateTime.Now;
				_bestDist = num;
				MyPos(out _startNS, out _startEW, out _startZ);
				_startHeading = num3;
				L("running, " + num.ToString("0.0") + " m, off by " + num4.ToString("0") + " deg");
				_restartStage = 0;
				_kicks = 0;
				if (num > PulseRange)
				{
					try
					{
						Globals.Core.Actions.SetAutorun(on: false);
					}
					catch
					{
					}
					AutorunOn();
				}
			}
			Status = "Turning to " + p.Name + " (" + num.ToString("0.0") + " m)";
			return true;
		}
		if (num4 > (double)(precise ? 30f : _s.NavTurnAngle))
		{
			L("off course by " + num4.ToString("0") + " deg at " + num.ToString("0.0") + " m - stop and turn");
			ReleaseTurn();
			_restartStage = 0;
			_kicks = 0;
			try
			{
				Globals.Core.Actions.SetAutorun(on: false);
			}
			catch
			{
			}
			_moving = false;
			_turnStart = DateTime.Now;
			Status = "Turning to " + p.Name + " (" + num.ToString("0.0") + " m)";
			return true;
		}
		DateTime now = DateTime.Now;
		bool flag = !_pulsing && (!precise || num > PulseRange);
		if (KeySteer & flag)
		{
			WantHeading(num2);
			_lastDirectSteer = now;
		}
		else if ((!KeySteer & flag) && num4 > Tuning.V("SteerDeg") && _restartStage == 0 && (now - _lastFace).TotalMilliseconds >= Tuning.V("SteerEveryMs"))
		{
			_lastFace = now;
			try
			{
				Globals.Core.Actions.FaceHeading(num2, true);
			}
			catch
			{
			}
			_restartStage = 1;
			_restartAt = now.AddMilliseconds(Tuning.V("TurnSettleMs"));
		}
		if (_restartStage == 1 && now >= _restartAt)
		{
			try
			{
				Globals.Core.Actions.SetAutorun(on: false);
			}
			catch
			{
			}
			_restartStage = 2;
			_restartAt = now.AddMilliseconds(Tuning.V("AutorunGapMs"));
		}
		else if (_restartStage == 2 && now >= _restartAt)
		{
			if (flag)
			{
				AutorunOn();
			}
			_restartStage = 0;
			_kickBest = num;
			_kickAt = now;
		}
		if (flag && _restartStage == 0)
		{
			if (num < _kickBest - 0.2)
			{
				_kickBest = num;
				_kickAt = now;
				_kicks = 0;
			}
			else if ((now - _kickAt).TotalMilliseconds > Tuning.V("NotMovingMs"))
			{
				_kicks++;
				if (_kicks > 3)
				{
					L("not moving at " + num.ToString("0.0") + " m - stop and turn");
					try
					{
						Globals.Core.Actions.SetAutorun(on: false);
					}
					catch
					{
					}
					_moving = false;
					_turnStart = now;
					_kicks = 0;
					Status = "Turning to " + p.Name + " (" + num.ToString("0.0") + " m)";
					return true;
				}
				L("not moving at " + num.ToString("0.0") + " m - restarting the run (" + _kicks + ")" + ((_s.NavSmoothSteer && (now - _lastDirectSteer).TotalSeconds < 2.0) ? " [right after a direct steer]" : ""));
				_restartStage = 1;
				_restartAt = now;
				_kickAt = now;
				_kickBest = num;
			}
		}
		if (precise && num <= PulseRange)
		{
			DateTime now2 = DateTime.Now;
			if (num < _bestDist - 0.1)
			{
				_bestDist = num;
				_lastProgressAt = now2;
			}
			if (!_pulsing)
			{
				_pulsing = true;
				try
				{
					Globals.Core.Actions.SetAutorun(on: false);
				}
				catch
				{
				}
				_pulseOnUntil = DateTime.MinValue;
				_pulseOffUntil = now2.AddMilliseconds(Tuning.V("PulseOffMs"));
			}
			else if (_pulseOnUntil != DateTime.MinValue)
			{
				if (now2 >= _pulseOnUntil)
				{
					try
					{
						Globals.Core.Actions.SetAutorun(on: false);
					}
					catch
					{
					}
					_pulseOnUntil = DateTime.MinValue;
					_pulseOffUntil = now2.AddMilliseconds(Tuning.V("PulseOffMs"));
				}
			}
			else if (now2 >= _pulseOffUntil && num4 <= 15.0)
			{
				AutorunOn();
				_pulseOnUntil = now2.AddMilliseconds(Tuning.V("PulseBaseMs") + Tuning.V("PulsePerMMs") * num);
			}
			Status = "Stepping to " + p.Name + " (" + num.ToString("0.0") + " m)";
			if (OpenDoorsNow && (now2 - _lastProgressAt).TotalSeconds > 1.5 && DoorInTheWay())
			{
				_lastProgressAt = now2;
				_pauseUntil = now2.AddSeconds(1.5);
				return true;
			}
			if ((now2 - _lastProgressAt).TotalSeconds > Tuning.V("StepStuckS"))
			{
				StuckEvents++;
				L("stuck stepping at " + num.ToString("0.0") + " m");
				Stop();
				_pauseUntil = now2.AddSeconds(Tuning.V("StuckPauseS"));
				Status = "Can't get closer to " + p.Name;
			}
			return true;
		}
		if (_pulsing)
		{
			_pulsing = false;
			_pulseOnUntil = DateTime.MinValue;
			AutorunOn();
		}
		if (!_warnedDir && MyPos(out var ns, out var ew, out var _))
		{
			double num5 = (ns - _startNS) * 240.0;
			double num6 = (ew - _startEW) * 240.0;
			if (Math.Sqrt(num5 * num5 + num6 * num6) >= 2.0)
			{
				double a = (Math.Atan2(num6, num5) * 180.0 / Math.PI + 360.0) % 360.0;
				if (AngleDiff(a, _startHeading) > 45.0)
				{
					Util.WriteToChat("Nav: facing " + _startHeading.ToString("0") + " but moving toward " + a.ToString("0") + " (spot is at " + num2.ToString("0") + ") - tell Claude these numbers.");
				}
				_warnedDir = true;
			}
		}
		if (num < _bestDist - 0.3)
		{
			_bestDist = num;
			_lastProgressAt = DateTime.Now;
		}
		bool flag2 = p.Name != null && p.Name.StartsWith("Map route #", StringComparison.OrdinalIgnoreCase);
		if (flag2 && MyPos(out var ns2, out var ew2, out var _))
		{
			double num7 = Math.Sqrt(Math.Pow((ns2 - _mapLastNS) * 240.0, 2.0) + Math.Pow((ew2 - _mapLastEW) * 240.0, 2.0));
			if (num7 >= 0.5)
			{
				if (num < _mapLastD + 0.2)
				{
					_lastProgressAt = DateTime.Now;
				}
				_mapLastNS = ns2;
				_mapLastEW = ew2;
				_mapLastD = num;
			}
		}
		if (OpenDoorsNow && (DateTime.Now - _lastProgressAt).TotalSeconds > 1.5 && DoorInTheWay())
		{
			Stop();
			_lastProgressAt = DateTime.Now;
			_pauseUntil = DateTime.Now.AddSeconds(1.5);
			return true;
		}
		if ((DateTime.Now - _lastProgressAt).TotalSeconds > Tuning.V("StuckS") || (!flag2 && (DateTime.Now - _runStart).TotalSeconds > Tuning.V("MaxRunS")))
		{
			StuckEvents++;
			Stop();
			_pauseUntil = DateTime.Now.AddSeconds(Tuning.V("StuckPauseS"));
			L("stuck: " + num.ToString("0.0") + " m, best " + _bestDist.ToString("0.0") + " m, no progress " + (DateTime.Now - _lastProgressAt).TotalSeconds.ToString("0.0") + "s, running " + (DateTime.Now - _runStart).TotalSeconds.ToString("0") + "s, moving " + _moving + ", pulsing " + _pulsing);
			Util.WriteToChat("Nav: can't get back to " + p.Name + " (" + num.ToString("0.0") + " m away) - trying again in 30 s.");
			Status = "Stuck - " + num.ToString("0.0") + " m from " + p.Name;
			return false;
		}
		Status = "Returning to " + p.Name + " (" + num.ToString("0.0") + " m)";
		return true;
	}

	private static double AngleDiff(double a, double b)
	{
		return Math.Abs(((a - b) % 360.0 + 540.0) % 360.0 - 180.0);
	}

	public void UpdateMarkers()
	{
		DateTime now = DateTime.Now;
		if ((now - _markersAt).TotalMilliseconds < 100.0)
		{
			return;
		}
		_markersAt = now;
		try
		{
			RemoveLeftovers();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		try
		{
			StuckRestartTick();
		}
		catch (Exception ex2)
		{
			Util.LogError(ex2);
		}
		try
		{
			TravelTick();
		}
		catch (Exception ex3)
		{
			Util.LogError(ex3);
		}
		try
		{
			UpdateRouteMarkers();
		}
		catch (Exception ex4)
		{
			Util.LogError(ex4);
		}
		try
		{
			PublishMapRoute(now: false);
		}
		catch
		{
		}
		try
		{
			MarkerTestTick();
		}
		catch (Exception ex5)
		{
			Util.LogError(ex5);
		}
		try
		{
			UpdateFollowMarkers();
		}
		catch (Exception ex6)
		{
			Util.LogError(ex6);
		}
		if (_s.NavMode == 2)
		{
			if (_drawnKey != "")
			{
				ClearMarkers();
				_drawnKey = "";
			}
			return;
		}
		bool flag = _s.NavMode == 1;
		NavSpot navSpot;
		if (flag)
		{
			navSpot = (_s.NavEnabled ? RouteTarget() : null);
		}
		else
		{
			navSpot = Current;
		}
		bool flag2 = (flag ? _s.NavRouteShowNext : _s.NavShowMarker);
		bool flag3 = (flag ? _s.NavRouteArrow : _s.NavArrow);
		string text = ((navSpot == null) ? "" : (navSpot.Name + "|" + navSpot.NS + "|" + navSpot.EW + "|" + navSpot.Z + "|" + _s.NavDrift + "|" + flag2 + "|" + flag3 + "|" + flag));
		if (text == _drawnKey)
		{
			if (navSpot != null && (DateTime.Now - _labelCheck).TotalMilliseconds >= 250.0)
			{
				_labelCheck = DateTime.Now;
				bool flag4 = !_s.NavHideUnfocused || GameFocused();
				SetVisible(_ring, flag4);
				SetVisible(_arrow, flag4);
				if (_label != null)
				{
					double num = DistanceTo(navSpot);
					SetVisible(_label, flag4 && (num < 0.0 || num > (double)_s.NavDrift));
				}
			}
			return;
		}
		_drawnKey = text;
		_labelCheck = DateTime.MinValue;
		ClearMarkers();
		if (navSpot == null)
		{
			return;
		}
		try
		{
			D3DService d3DService = Globals.Core.D3DService;
			if (flag2)
			{
				_ring = d3DService.MarkCoordsWithShape((float)navSpot.NS, (float)navSpot.EW, (float)navSpot.Z + 0.05f, D3DShape.Ring, -13382401);
				if (_ring != null)
				{
					D3DObj ring = _ring;
					double val;
					if (flag)
					{
						val = ((CurrentRoute != null) ? ((double)CurrentRoute.Arrive) : 2.5);
					}
					else
					{
						val = _s.NavDrift;
					}
					ring.Scale((float)Math.Max(0.5, val));
				}
				_label = d3DService.MarkCoordsWith3DText((float)navSpot.NS, (float)navSpot.EW, (float)navSpot.Z + 1.6f, navSpot.Name, "Arial", 0);
				if (_label != null)
				{
					_label.Color = -13382401;
					_label.Scale(0.4f);
					_label.OrientToCamera(true);
				}
			}
			if (flag3)
			{
				_arrow = d3DService.PointToCoords((float)navSpot.NS, (float)navSpot.EW, (float)navSpot.Z, -13261);
			}
		}
		catch (Exception ex7)
		{
			Util.LogError(ex7);
		}
	}

	public void MarkerTest()
	{
		if (!MyPos(out var _, out var _, out var _))
		{
			Util.WriteToChat("Marker test: position not known yet.");
			return;
		}
		try
		{
			_test = Globals.Core.D3DService.MarkObjectWithShape(Globals.Core.CharacterFilter.Id, D3DShape.Ring, -52225);
			if (_test != null)
			{
				_test.Scale(1.5f);
			}
			_testAt = DateTime.Now;
			_testStage = 1;
			Util.WriteToChat("Marker test: a pink ring on you for 60 s, then hidden for 60 s, then removed.");
			L("markertest: ring made (" + ((_test == null) ? "null!" : _test.GetType().FullName) + ")");
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Marker test: couldn't make one: " + ex.Message);
		}
	}

	private void MarkerTestTick()
	{
		if (_testStage == 0 || _test == null)
		{
			return;
		}
		double totalSeconds = (DateTime.Now - _testAt).TotalSeconds;
		if (_testStage == 1 && totalSeconds >= 60.0)
		{
			_testStage = 2;
			string text;
			try
			{
				_test.Visible = false;
				text = "hidden - Visible now reads " + _test.Visible;
			}
			catch (Exception ex)
			{
				text = "hide failed: " + ex.GetType().Name + " " + ex.Message;
			}
			L("markertest: " + text);
			Util.WriteToChat("Marker test: " + text + ". Is the pink ring gone?");
		}
		else if (_testStage == 2 && totalSeconds >= 120.0)
		{
			_testStage = 0;
			string text2;
			try
			{
				((IDisposable)_test)?.Dispose();
				text2 = "removed";
			}
			catch (Exception ex2)
			{
				text2 = "remove failed: " + ex2.GetType().Name + " " + ex2.Message;
			}
			_test = null;
			L("markertest: " + text2);
		}
	}

	private static void SetVisible(D3DObj o, bool show)
	{
		if (o == null)
		{
			return;
		}
		try
		{
			if (o.Visible != show)
			{
				o.Visible = show;
			}
		}
		catch (Exception ex)
		{
			_visFails++;
			if (_visFirst == null)
			{
				_visFirst = ex.GetType().Name + " " + ex.Message;
			}
		}
	}

	private void NoteFocus(bool focused, int objs)
	{
		if (_lastFocused == focused && _visFails == 0)
		{
			return;
		}
		if (_lastFocused != focused)
		{
			uint pid = 0u;
			try
			{
				GetWindowThreadProcessId(GetForegroundWindow(), out pid);
			}
			catch
			{
			}
			L("game window " + (focused ? "active" : "not active") + " (foreground pid " + pid + ", ours " + Process.GetCurrentProcess().Id + ") - " + (focused ? "showing " : "hiding ") + objs + " markers");
		}
		if (_visFails > 0)
		{
			L("marker show/hide failed " + _visFails + "x: " + _visFirst);
			_visFails = 0;
			_visFirst = null;
		}
		_lastFocused = focused;
	}

	[DllImport("user32.dll")]
	private static extern nint GetForegroundWindow();

	[DllImport("user32.dll")]
	private static extern uint GetWindowThreadProcessId(nint hWnd, out uint pid);

#if RETAIL
	private static bool GameFocused()
	{
		try
		{
			IntPtr foregroundWindow = GetForegroundWindow();
			if (foregroundWindow == IntPtr.Zero)
			{
				return false;
			}
			GetWindowThreadProcessId(foregroundWindow, out var pid);
			return pid == (uint)Process.GetCurrentProcess().Id;
		}
		catch
		{
			return true;
		}
	}
#else
	private static bool GameFocused()
	{
		try
		{
			return DisplayServer.WindowIsFocused();
		}
		catch
		{
			return true;
		}
	}
#endif

	public void ClearMarkers()
	{
		D3DObj[] array = new D3DObj[3] { _ring, _label, _arrow };
		foreach (D3DObj d3DObj in array)
		{
			if (d3DObj != null)
			{
				try
				{
					d3DObj.Visible = false;
				}
				catch (Exception ex)
				{
					L("marker hide failed: " + ex.GetType().Name + " " + ex.Message);
				}
				try
				{
					d3DObj.Scale(0.0001f);
				}
				catch
				{
				}
				try
				{
					((IDisposable)d3DObj)?.Dispose();
				}
				catch (Exception ex2)
				{
					L("marker dispose failed: " + ex2.GetType().Name + " " + ex2.Message);
				}
			}
		}
		_ring = (_label = (_arrow = null));
	}

	public void Dispose()
	{
		if (PluginCore.HotReloading)
		{
			SaveHotState();
		}
		try
		{
			TravelStop("MelkTank is closing", finished: false);
		}
		catch
		{
		}
		DisposeTools();
		try
		{
			SaveRouteFiles(now: true);
		}
		catch
		{
		}
		Stop();
		if (PluginCore.HotReloading)
		{
			List<object> list = new List<object>();
			D3DObj[] array = new D3DObj[6] { _ring, _label, _arrow, _fRing, _fArrow, _test };
			foreach (D3DObj d3DObj in array)
			{
				if (d3DObj != null)
				{
					list.Add(d3DObj);
				}
			}
			foreach (D3DObj routeObj in _routeObjs)
			{
				list.Add(routeObj);
			}
			try
			{
				List<object> list2 = AppDomain.CurrentDomain.GetData("MelkTank.D3DLeftovers") as List<object>;
				if (list2 == null)
				{
					list2 = new List<object>();
					AppDomain.CurrentDomain.SetData("MelkTank.D3DLeftovers", list2);
				}
				list2.AddRange(list);
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
			L("nav shutting down for a build swap: " + list.Count + " markers handed to the next build to remove");
			_ring = (_label = (_arrow = (_fRing = (_fArrow = (_test = null)))));
			_routeObjs.Clear();
			_testStage = 0;
		}
		else
		{
			L("nav shutting down (logout): clearing its markers");
			ClearMarkers();
			ClearRouteMarkers();
			ClearFollowMarkers();
		}
		_drawnKey = "";
		_routeKey = "";
		_fMarkKey = "";
	}

	private void RemoveLeftovers()
	{
		List<object> list;
		try
		{
			list = AppDomain.CurrentDomain.GetData("MelkTank.D3DLeftovers") as List<object>;
		}
		catch
		{
			return;
		}
		if (list == null || list.Count == 0)
		{
			return;
		}
		AppDomain.CurrentDomain.SetData("MelkTank.D3DLeftovers", null);
		int num = 0;
		int num2 = 0;
		string text = null;
		foreach (object item in list)
		{
			if (!(item is D3DObj d3DObj))
			{
				num2++;
				if (text == null)
				{
					text = "not a D3DObj: " + ((item == null) ? "null" : item.GetType().AssemblyQualifiedName);
				}
				continue;
			}
			try
			{
				d3DObj.Visible = false;
			}
			catch (Exception ex)
			{
				num2++;
				if (text == null)
				{
					text = ex.GetType().Name + " " + ex.Message;
				}
			}
			try
			{
				d3DObj.Scale(0.0001f);
			}
			catch
			{
			}
			try
			{
				d3DObj.Dispose();
			}
			catch
			{
			}
			num++;
		}
		L("removed " + num + " markers left by the previous build" + ((num2 > 0) ? (" - " + num2 + " failed (" + text + ")") : ""));
	}

	public void Draw()
	{
		SaveRouteFiles(now: false);
		if (ImGui.BeginTabBar("navtabs"))
		{
			if (ImGui.BeginTabItem("Routes"))
			{
				DrawRoutesTab();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Presets###navpresetstab"))
			{
				DrawPresetsTab();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Meta###navmetatab"))
			{
				DrawMetaTab();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Locations"))
			{
				Locations.DrawTab();
				ImGui.EndTabItem();
			}
			if (DrawPortals != null && ImGui.BeginTabItem("Portals"))
			{
				DrawPortals();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Settings###navsettingstab"))
			{
				DrawSettingsTab();
				ImGui.EndTabItem();
			}
			ImGui.EndTabBar();
		}
	}

	private void DrawSettingsTab()
	{
		bool flag = false;
		if (ImGui.CollapsingHeader("Shown in the world###navshown", ImGuiTreeNodeFlags.DefaultOpen))
		{
			flag |= ImGui.Checkbox("Route: show the whole route", ref _s.NavRouteShowAll);
			Tip("Every point (a ring and its number) and dotted lines between them, in the world.\n/mt set NavRouteShowAll on|off");
			ImGui.SameLine(0f, 20f);
			flag |= ImGui.Checkbox("Route: show the next step", ref _s.NavRouteShowNext);
			Tip("A ring and the step's name on the point (or portal / NPC) it's heading for.\n/mt set NavRouteShowNext on|off");
			ImGui.SameLine(0f, 20f);
			flag |= ImGui.Checkbox("Route: arrow to the next step", ref _s.NavRouteArrow);
			Im.SetTooltipIfHovered("/mt set NavRouteArrow on|off");
			flag |= ImGui.Checkbox("Spot: show it in the world", ref _s.NavShowMarker);
			Tip("A ring the size of the drift allowed, with the spot's name above it.\n/mt set NavShowMarker on|off");
			ImGui.SameLine(0f, 20f);
			flag |= ImGui.Checkbox("Spot: arrow pointing to it", ref _s.NavArrow);
			Im.SetTooltipIfHovered("/mt set NavArrow on|off");
			flag |= ImGui.Checkbox("Hide them while the game isn't the active window##navhide", ref _s.NavHideUnfocused);
			Tip("Like UtilityBelt's video patch: the rings, names and arrows aren't drawn while you're in another window\n(or another client), and come back when you switch to this one.\n/mt set NavHideUnfocused on|off");
		}
		if (ImGui.CollapsingHeader("Nav settings###navsettings", ImGuiTreeNodeFlags.DefaultOpen))
		{
			flag |= DrawNavSettings();
		}
		if (ImGui.CollapsingHeader("Meta settings###metasettings", ImGuiTreeNodeFlags.DefaultOpen))
		{
			flag |= DrawMetaSettings();
		}
		if (ImGui.CollapsingHeader("Route files###navfiles"))
		{
			flag |= DrawRouteFiles((_s.NavMode == 1) ? CurrentRoute : null);
		}
		if (ImGui.CollapsingHeader("Meta files###metafiles"))
		{
			flag |= DrawMetaFiles();
		}
		if (flag && SaveAll != null)
		{
			SaveAll();
		}
	}
}
