using System;
using System.Collections.Generic;
using System.IO;
using System.Numerics;
using System.Text;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;

namespace MelkTank;

/// <summary>
/// Items > Salvage: imbues, rends and tinkers put on a batch of items by profile - one profile picked for each kind of item
/// (armor, jewelry, casters, weapons), each a list of salvage in the order it goes on - and two recipes (ring spell scrolls,
/// the Bandit Hilt). Says Yes to the game's crafting question only (its type), only just after applying something.
/// (From the Salvage and Crafting plugin: the same materials, the same full-bags-only rule, the same success rates.)
/// </summary>
public static class Crafting
{
	private static readonly Vector4 Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f);
	private static readonly Vector4 Green = new Vector4(0.6f, 0.9f, 0.6f, 1f);
	private static readonly Vector4 Orange = new Vector4(1f, 0.75f, 0.4f, 1f);
	private static readonly Vector4 Red = new Vector4(1f, 0.4f, 0.4f, 1f);
	private static readonly Vector4 Yellow = new Vector4(1f, 0.85f, 0.3f, 1f);
	private static readonly Vector4 White = new Vector4(0.9f, 0.9f, 0.9f, 1f);

	// ---- materials: the game's numbers (bags of salvage); below zero, things found by name ----

	private enum Use { Imbue, Rend, Tinker }

	private sealed class Mat
	{
		public int Id; public string Name; public string Note; public Use Use; public string Fits;   // A armor, J jewelry, C casters, W weapons
		public string ByName;   // not a bag of salvage: the item's name
		public bool Foolproof;  // a rend that can't fail: goes last
		public bool Extra;      // picked on the Main tab for every item it fits (a hilt, a ring spell, a slayer), not in profiles
		public Mat(int id, string name, string note, Use use, string fits, string byName = null, bool foolproof = false, bool extra = false)
		{ Id = id; Name = name; Note = note; Use = use; Fits = fits; ByName = byName; Foolproof = foolproof; Extra = extra; }
	}

	private static readonly List<Mat> Mats = new List<Mat>
	{
		// imbues (they don't count as tinkers)
		new Mat(16, "Black Opal", "Critical Strike", Use.Imbue, "WC"),
		new Mat(22, "Fire Opal", "Crippling Blow", Use.Imbue, "WC"),
		new Mat(44, "Turquoise", "Crushing Blow", Use.Imbue, "WC"),
		new Mat(46, "White Quartz", "Cleaving", Use.Imbue, "W"),
		new Mat(48, "Yellow Garnet", "Biting Strike", Use.Imbue, "WC"),
		new Mat(-1, "Bag of Abyssal-Touched Gems", "Biting + Crushing + Cleave", Use.Imbue, "WC", "Abyssal-Touched Gems"),
		new Mat(59, "Copper", "+2 Damage Rating", Use.Imbue, "J"),
		new Mat(63, "Silver", "+2 Crit Damage Rating", Use.Imbue, "J"),
		new Mat(24, "Green Jade", "+2 Damage Resist Rating", Use.Imbue, "J"),
		new Mat(34, "Peridot", "+1 Melee Defense", Use.Imbue, "A"),
		new Mat(49, "Yellow Topaz", "+1 Missile Defense", Use.Imbue, "A"),
		new Mat(50, "Zircon", "+1 Magic Defense", Use.Imbue, "A"),
		new Mat(-10, "Shadow Armor Infusion", "", Use.Imbue, "A", "Shadow Armor Infusion"),
		new Mat(-15, "Imbued Bloodstone Shard", "", Use.Imbue, "WC", "Imbued Bloodstone Shard"),
		// the Main tab's extras: a hilt on melee weapons, a bowstring on bows, a ring spell on necklaces and bows, a slayer
		new Mat(HiltId, "Fine Bandit Blade Hilt", "melee weapons", Use.Imbue, "W", "Fine Bandit Blade Hilt", extra: true),
		new Mat(BowstringId, "Bandit Bowstring", "bows", Use.Imbue, "W", "Bandit Bowstring", extra: true),
		new Mat(RingId, "Ring spell", "", Use.Imbue, "JW", null, extra: true),
		new Mat(SlayerId, "Slayer", "", Use.Imbue, "WC", null, extra: true),
		// rends (they count as tinkers): before the tinkers - a foolproof one last
		new Mat(13, "Aquamarine", "Cold Rending", Use.Rend, "WC"),
		new Mat(15, "Black Garnet", "Pierce Rending", Use.Rend, "WC"),
		new Mat(21, "Emerald", "Acid Rending", Use.Rend, "WC"),
		new Mat(26, "Imperial Topaz", "Slash Rending", Use.Rend, "WC"),
		new Mat(27, "Jet", "Lightning Rending", Use.Rend, "WC"),
		new Mat(32, "Onyx", "Nether Rending", Use.Rend, "WC"),
		new Mat(35, "Red Garnet", "Fire Rending", Use.Rend, "WC"),
		new Mat(41, "Sunstone", "Armor Rending", Use.Rend, "WC"),
		new Mat(47, "White Sapphire", "Bludgeon Rending", Use.Rend, "WC"),
		// tinkers
		new Mat(66, "Alabaster", "+0.2 pierce", Use.Tinker, "A"),
		new Mat(53, "Armoredillo Hide", "+0.4 acid", Use.Tinker, "A"),
		new Mat(58, "Bronze", "+0.2 slash", Use.Tinker, "A"),
		new Mat(1, "Ceramic", "+0.4 fire", Use.Tinker, "A"),
		new Mat(68, "Marble", "+0.2 bludgeon", Use.Tinker, "A"),
		new Mat(55, "Reedshark Hide", "+0.4 lightning", Use.Tinker, "A"),
		new Mat(8, "Wool", "+0.4 cold", Use.Tinker, "A"),
		new Mat(64, "Steel", "+20 armor / jewelry +500 spellcraft", Use.Tinker, "AJ"),
		new Mat(-11, "Shadow Protection", "", Use.Tinker, "A", "Shadow Protection"),
		new Mat(-12, "Shadow Damage Infusion", "", Use.Tinker, "A", "Shadow Damage Infusion"),
		new Mat(-13, "Shadow Nether Infusion", "", Use.Tinker, "A", "Shadow Nether Infusion"),
		new Mat(-14, "Shadow Vitality Infusion", "", Use.Tinker, "A", "Shadow Vitality Infusion"),
		new Mat(12, "Amethyst", "+5 Heal Boost", Use.Tinker, "J"),
		new Mat(25, "Hematite", "+5 Vitality", Use.Tinker, "J"),
		new Mat(71, "Serpentine", "+0.5 Resist Cleaving (finish)", Use.Tinker, "J"),
		new Mat(57, "Brass", "+1% melee defense", Use.Tinker, "W"),
		new Mat(67, "Granite", "melee variance", Use.Tinker, "W"),
		new Mat(61, "Iron", "+1 max damage", Use.Tinker, "W"),
		new Mat(74, "Mahogany", "+4% missile damage", Use.Tinker, "W"),
		new Mat(75, "Oak", "speed -50", Use.Tinker, "W"),
		new Mat(7, "Velvet", "+1% attack", Use.Tinker, "W"),
		new Mat(42, "Tiger Eye", "+5% split-arrow damage", Use.Tinker, "W"),
		new Mat(23, "Green Garnet", "+1% wand damage", Use.Tinker, "C"),
		new Mat(33, "Opal", "+1% mana conversion", Use.Tinker, "C"),
		new Mat(31, "Moonstone", "+500 max mana", Use.Tinker, "ACW"),
		new Mat(60, "Gold", "value +25%", Use.Tinker, "ACWJ"),
		new Mat(4, "Linen", "burden -25%", Use.Tinker, "ACWJ"),
	};

	static Crafting()
	{
		// every rend also as its foolproof kind (it can't fail - it goes last, as the tenth tinker)
		foreach (Mat m in Mats.FindAll(x => x.Use == Use.Rend && !x.Foolproof))
			Mats.Add(new Mat(-100 - m.Id, "Foolproof " + m.Name, m.Note + " (foolproof)", Use.Rend, m.Fits, "Foolproof " + m.Name, foolproof: true));
	}

	private const int HiltId = -20, BowstringId = -21, RingId = -30, SlayerId = -40;
	private static Mat MatOf(int id) => Mats.Find(m => m.Id == id);
	private static string MatName(int id) => MatOf(id)?.Name ?? ("#" + id);
	private static bool CountsAsTinker(Mat m) => m != null && m.Use != Use.Imbue;
	public const int MaxTinkers = 10;

	// ---- item kinds ----

	private static readonly string[] KindNames = new string[] { "Armor", "Jewelry", "Casters", "Weapons" };
	private const string KindLetters = "AJCW";

	private static int KindOf(WorldObject w)
	{
		switch (w.ObjectClass)
		{
			case ObjectClass.Armor: return 0;
			case ObjectClass.Clothing: return w.Values(LongValueKey.ArmorLevel, 0) > 0 ? 0 : -1;
			case ObjectClass.Jewelry: return 1;
			case ObjectClass.WandStaffOrb: return 2;
			case ObjectClass.MeleeWeapon: case ObjectClass.MissileWeapon: return 3;
		}
		return -1;
	}

	private static bool Fits(Mat m, int kind) => kind >= 0 && m.Fits.IndexOf(KindLetters[kind]) >= 0;

	// ---- profiles: one kind of item, the salvage in the order it goes on ----

	private sealed class Profile { public string Name = ""; public int Kind; public List<int> Steps = new List<int>(); }

	private static readonly List<Profile> _profiles = new List<Profile>();
	private static readonly string[] _pick = new string[4] { "", "", "", "" };   // the profile picked for each kind (per character)

	private static Profile Picked(int kind) => kind < 0 ? null : _profiles.Find(p => p.Kind == kind && p.Name == _pick[kind]);

	// the Main tab's extras, on every item they fit (after its imbues, before its rends and tinkers)
	private static bool _hilt;
	private static string _ring = "", _slayer = "";

	private static void SetExtraNames()
	{
		MatOf(RingId).ByName = _ring.Length > 0 ? _ring : null;
		MatOf(RingId).Name = _ring.Length > 0 ? _ring : "Ring spell";
		MatOf(SlayerId).ByName = _slayer.Length > 0 ? _slayer : null;
		MatOf(SlayerId).Name = _slayer.Length > 0 ? _slayer : "Slayer";
	}

	private static bool IsNecklace(WorldObject w) => (w.Values(LongValueKey.EquipableSlots, 0) & 0x8000) != 0;

	/// <summary>What an item gets: its kind's profile, with the extras that fit it put in after the imbues.</summary>
	private static List<int> StepsFor(WorldObject w, int kind)
	{
		List<int> steps = new List<int>(Picked(kind)?.Steps ?? new List<int>());
		List<int> extra = new List<int>();
		if (w != null)
		{
			bool melee = w.ObjectClass == ObjectClass.MeleeWeapon, bow = w.ObjectClass == ObjectClass.MissileWeapon;
			if (_hilt && melee) extra.Add(HiltId);
			if (_hilt && bow) extra.Add(BowstringId);
			if (_ring.Length > 0 && (bow || kind == 1 && IsNecklace(w))) extra.Add(RingId);
			if (_slayer.Length > 0 && (kind == 2 || kind == 3) && w.Values((LongValueKey)166, 0) == 0) extra.Add(SlayerId);   // (none if it has one)
		}
		int at = 0;
		while (at < steps.Count && Rank(MatOf(steps[at])) == 0) at++;
		steps.InsertRange(at, extra);
		return steps;
	}

	/// <summary>Where a new step goes: imbues first, then rends, then tinkers, then a foolproof rend last.</summary>
	private static int Rank(Mat m) => m == null ? 2 : m.Use == Use.Imbue ? 0 : m.Use == Use.Rend ? (m.Foolproof ? 3 : 1) : 2;

	private static int TinkerCount(List<int> steps) { int n = 0; foreach (int s in steps) if (CountsAsTinker(MatOf(s))) n++; return n; }

	// ---- the list ----

	private sealed class Entry
	{
		public int Id; public string Name = ""; public int Kind; public string Profile = ""; public List<int> Steps = new List<int>();
		public string Status = "waiting"; public int Step; public int Good; public bool Done;
	}

	private static readonly List<Entry> _items = new List<Entry>();
	private static List<Entry> _lastRun = new List<Entry>();

	// ---- running ----

	private enum St { Idle, Next, Peace, Apply, Wait, Settle, Move }
	private static St _st = St.Idle;
	private static int _cur;
	private static int _bag, _tryMat;
	private static double _bagWork = -1, _chance = -1;
	private static DateTime _until = DateTime.MinValue, _deadline = DateTime.MinValue, _resultAt = DateTime.MinValue, _nextTick = DateTime.MinValue;
	private static DateTime _askedAt = DateTime.MinValue;
	private static bool _refused, _sawResult, _sawFail;
	private static string _status = "Stopped";
	private static bool _moveOn;
	private static int _movePack, _moveItem;
	private static bool _moveSent;
	private static readonly List<string> _log = new List<string>();
	private static int _logShown;
	private static bool _hooked;
	private static string _char;

	// success rates per salvage: tries, worked, failed (item kept), destroyed, sum of quoted chances, quotes
	private static readonly Dictionary<int, double[]> _stats = new Dictionary<int, double[]>();

	public static bool Running => _st != St.Idle || _rst != R.Idle;

	// ---- starting and stopping with the character ----

	public static void Start(string charName)
	{
		_char = charName ?? "";
		Load();
		LoadStats();
		if (_hooked) return;
		Globals.Core.ChatBoxMessage += OnChat;
		Globals.Core.RenderFrame += OnFrame;
		_hooked = true;
	}

	public static void Stop()
	{
		try { StopRun(null); RingStop(null); } catch { }
		if (!_hooked) return;
		try { Globals.Core.ChatBoxMessage -= OnChat; } catch { }
		try { Globals.Core.RenderFrame -= OnFrame; } catch { }
		_hooked = false;
	}

	// ---- salvage you carry ----

	private static Dictionary<int, int> _counts = new Dictionary<int, int>();
	private static DateTime _countsAt = DateTime.MinValue;

	private static bool Equipped(WorldObject w) => w.Values(LongValueKey.Wielder, 0) != 0 || w.Values(LongValueKey.EquippedSlots, 0) != 0;
	private static bool Full(WorldObject w) => w.Values(LongValueKey.UsesRemaining, 0) >= 100;

	private static int MatOfThing(WorldObject w)
	{
		string n = (w.Name ?? "").Trim();
		foreach (Mat m in Mats)
			if (m.ByName != null && (m.Id == -1 ? n.IndexOf(m.ByName, StringComparison.OrdinalIgnoreCase) >= 0 : string.Equals(n, m.ByName, StringComparison.OrdinalIgnoreCase)))
				return m.Id;
		if (w.ObjectClass == ObjectClass.Salvage && Full(w)) return w.Values(LongValueKey.Material, 0);
		return 0;
	}

	/// <summary>How many uses of a salvage you carry: full bags, or the named things (a stack counts each).</summary>
	private static int Have(int mat)
	{
		if ((DateTime.Now - _countsAt).TotalSeconds >= 1)
		{
			_countsAt = DateTime.Now;
			Dictionary<int, int> c = new Dictionary<int, int>();
			try
			{
				foreach (WorldObject w in InvCache.All())
				{
					if (Equipped(w)) continue;
					int m = MatOfThing(w);
					if (m == 0) continue;
					int n = m < 0 ? Math.Max(1, w.Values(LongValueKey.StackCount, 1)) : 1;
					c[m] = (c.TryGetValue(m, out int v) ? v : 0) + n;
				}
			}
			catch { }
			_counts = c;
		}
		return _counts.TryGetValue(mat, out int r) ? r : 0;
	}

	// the bag to use: the best workmanship (a named thing: any)
	private static int BestBag(int mat)
	{
		int best = 0; double bw = -1;
		foreach (WorldObject w in InvCache.All())
		{
			if (Equipped(w) || MatOfThing(w) != mat) continue;
			if (mat < 0) return w.Id;
			double wk = w.Values(DoubleValueKey.SalvageWorkmanship, 0.0);
			if (wk > bw) { bw = wk; best = w.Id; }
		}
		return best;
	}

	// ---- adding items ----

	private static bool IsMe(int id) => id != 0 && id == Globals.Core.CharacterFilter.Id;
	private static string PackName(int id) => IsMe(id) ? "Main pack" : (id != 0 ? Globals.Core.WorldFilter[id]?.Name : null);

	private static bool Add(WorldObject w)
	{
		if (w == null || Equipped(w)) return false;
		int k = KindOf(w);
		if (k < 0) return false;
		foreach (Entry e in _items) if (e.Id == w.Id) return false;
		_items.Add(new Entry { Id = w.Id, Name = FullName(w), Kind = k });
		return true;
	}

	private static readonly string[] Elements = { "Cold", "Fire", "Acid", "Lightning" };   // damage type bits 8, 16, 32, 64

	/// <summary>The item's name with its material in front, and its element after in parentheses when it has one.</summary>
	private static string FullName(WorldObject w)
	{
		string name = w.Name ?? "?";
		try
		{
			string mat = ItemNames.Material(w.Values(LongValueKey.Material, 0));
			if (mat.Length > 0 && !name.StartsWith(mat, StringComparison.OrdinalIgnoreCase)) name = mat + " " + name;
		}
		catch { }
		try
		{
			int dt = w.Values((LongValueKey)45, 0);   // damage type
			List<string> el = new List<string>();
			// a caster's damage type is the school its war spells get the bonus for, at every tier - the physical ones too
			if (w.ObjectClass == ObjectClass.WandStaffOrb)
			{
				if ((dt & 1) != 0) el.Add("Slash");
				if ((dt & 2) != 0) el.Add("Pierce");
				if ((dt & 4) != 0) el.Add("Bludgeon");
			}
			for (int b = 0; b < 4; b++) if ((dt & (8 << b)) != 0) el.Add(Elements[b]);
			if ((dt & 0x400) != 0) el.Add("Nether");
			if (el.Count > 0) name += " (" + string.Join("/", el) + ")";
		}
		catch { }
		return name;
	}

	private static void AddSelected()
	{
		int id = Globals.Core.Actions.CurrentSelection;
		WorldObject w = id != 0 ? Globals.Core.WorldFilter[id] : null;
		if (IsMe(id) || w != null && w.ObjectClass == ObjectClass.Container) { AddPack(id); return; }
		if (w == null) { Say("Select an item first."); return; }
		if (Equipped(w)) { Say(w.Name + " is equipped - take it off first."); return; }
		if (KindOf(w) < 0) { Say(w.Name + " isn't armor, jewelry, a caster or a weapon."); return; }
		if (Add(w)) Say("Added " + w.Name + ".");
	}

	private static void AddPack(int id)
	{
		WorldObject pack = id != 0 ? Globals.Core.WorldFilter[id] : null;
		if (!IsMe(id) && (pack == null || pack.ObjectClass != ObjectClass.Container)) { Say("Select a pack (a side pack, or your main pack) first."); return; }
		int n = 0;
		foreach (WorldObject w in Globals.Core.WorldFilter.GetByContainer(id))
			if (w.ObjectClass != ObjectClass.Salvage && w.ObjectClass != ObjectClass.Container && MatOfThing(w) == 0 && Add(w)) n++;
		Say("Added " + n + " item" + (n == 1 ? "" : "s") + " from " + PackName(id) + ".");
	}

	// ---- a run ----

	private static void StartRun()
	{
		if (_items.Count == 0) { Say("The list is empty: add items first."); return; }
		int ready = 0;
		foreach (Entry e in _items)
		{
			if (e.Done) continue;
			Profile p = Picked(e.Kind);
			e.Profile = p?.Name ?? "";
			e.Steps = StepsFor(Globals.Core.WorldFilter[e.Id], e.Kind);
			e.Step = 0; e.Good = 0;
			e.Status = e.Steps.Count == 0 ? "nothing to put on (no " + KindNames[e.Kind].ToLowerInvariant() + " profile)" : "waiting";
			if (e.Steps.Count > 0) ready++;
		}
		if (ready == 0) { Say("Nothing to do: pick a profile (with salvage in it) for the kinds of items in the list."); return; }
		_lastRun.Clear();
		_cur = 0;
		_st = St.Next;
		_status = "Working";
		Say("Starting on " + ready + " item" + (ready == 1 ? "" : "s") + ".");
	}

	private static void StopRun(string why)
	{
		if (_st == St.Idle) return;
		_st = St.Idle;
		_status = "Stopped";
		if (!string.IsNullOrEmpty(why)) Say(why);
	}

	private static void OnFrame(object sender, EventArgs e)
	{
		if (!Running) return;
		DateTime now = DateTime.Now;
		if (now < _nextTick) return;
		_nextTick = now.AddMilliseconds(100);
		try { if (_rst != R.Idle) RingTick(now); else Tick(now); }
		catch (Exception ex) { Util.LogError(ex); StopRun("Stopped after an error."); RingStop(null); }
	}

	/// <summary>The game's "are you sure?" for this apply: answered Yes only if it's the crafting question (type 5).</summary>
	private static void AskYes(DateTime now)
	{
		_askedAt = now;
		Remote.ExpectYes(10.0, "", 5);
	}

	// how many tinkers an item already has (a refused tinker is skipped once the item's full)
	private static int Tinks(WorldObject w) => w == null ? 0 : w.Values((LongValueKey)171, 0);

	private static void Finish(Entry en, string status)
	{
		en.Done = true;
		en.Status = status;
		Log(en.Name + ": " + status);
		_cur++;
	}

	private static string Summary(Entry en) => en.Good + " of " + en.Steps.Count + " on";

	private static void Tick(DateTime now)
	{
		if (now < _until) return;
		switch (_st)
		{
			case St.Next:
			{
				while (_cur < _items.Count && (_items[_cur].Done || _items[_cur].Steps.Count == 0)) { if (!_items[_cur].Done && _items[_cur].Steps.Count == 0) _items[_cur].Done = true; _cur++; }
				if (_cur >= _items.Count)
				{
					int full = 0, all = 0;
					foreach (Entry x in _items) { if (x.Steps.Count == 0) continue; all++; if (x.Good >= x.Steps.Count) full++; }
					_lastRun = new List<Entry>(_items);
					_items.Clear();
					StopRun("Done: " + full + " of " + all + " item" + (all == 1 ? "" : "s") + " got everything. List cleared.");
					return;
				}
				Entry en = _items[_cur];
				WorldObject w = Globals.Core.WorldFilter[en.Id];
				if (w == null) { Finish(en, en.Step > 0 ? "DESTROYED" : "gone"); return; }
				if (Equipped(w)) { Finish(en, "equipped - skipped"); return; }
				if (en.Step >= en.Steps.Count) { Finish(en, "done: " + Summary(en)); MaybeMove(en, now); return; }
				// (a tinker past ten would be refused: skipped)
				Mat m = MatOf(en.Steps[en.Step]);
				if (en.Steps[en.Step] == SlayerId && w.Values((LongValueKey)166, 0) != 0)
				{
					Log(en.Name + ": has a slayer already - skipped");
					en.Step++;
					return;
				}
				if (CountsAsTinker(m) && Tinks(w) >= MaxTinkers)
				{
					Log(en.Name + ": already has " + MaxTinkers + " tinkers - " + MatName(en.Steps[en.Step]) + " skipped");
					en.Step++;
					return;
				}
				_st = St.Peace;
				return;
			}
			case St.Peace:
				if (Globals.Core.Actions.CombatMode != CombatState.Peace) { Globals.Core.Actions.SetCombatMode(CombatState.Peace); _until = now.AddMilliseconds(1200); return; }
				if (Globals.Core.Actions.BusyState != 0) { _until = now.AddMilliseconds(300); return; }
				_st = St.Apply;
				return;
			case St.Apply:
			{
				Entry en = _items[_cur];
				int sm = en.Steps[en.Step];
				_bag = BestBag(sm);
				if (_bag == 0)
				{
					int left = 0;
					foreach (Entry x in _items) if (!x.Done && x.Steps.Count > 0) { left++; if (x == en) x.Status = "stopped at " + (x.Step + 1) + "/" + x.Steps.Count + " - out of " + MatName(sm); }
					StopRun("Out of " + MatName(sm) + " - " + left + " item" + (left == 1 ? "" : "s") + " left in the list.");
					return;
				}
				WorldObject bag = Globals.Core.WorldFilter[_bag];
				_refused = false; _sawResult = false; _sawFail = false; _resultAt = DateTime.MinValue; _chance = -1;
				_tryMat = sm; _bagWork = bag != null && sm > 0 ? bag.Values(DoubleValueKey.SalvageWorkmanship, 0.0) : -1;
				en.Status = "applying " + MatName(sm) + " (" + (en.Step + 1) + "/" + en.Steps.Count + ")";
				Log("Applying " + MatName(sm) + (_bagWork >= 0 ? " (work " + _bagWork.ToString("0.##") + ")" : "") + " to " + en.Name);
				AskYes(now);
				Globals.Core.Actions.ApplyItem(_bag, en.Id);
				_deadline = now.AddSeconds(20);
				_st = St.Wait;
				_until = now.AddMilliseconds(500);
				return;
			}
			case St.Wait:
			{
				Entry en = _items[_cur];
				bool bagGone = Globals.Core.WorldFilter[_bag] == null;
				bool itemGone = Globals.Core.WorldFilter[en.Id] == null;
				if (_chance < 0) TakeChance();
				if (_refused)
				{
					// (already has it, the item's full, the wrong kind of item...): on to the next one
					Log(en.Name + ": " + MatName(en.Steps[en.Step]) + " refused - going on");
					en.Step++;
					_st = St.Settle; _until = now.AddMilliseconds(800);
					return;
				}
				if (itemGone) { Record(en, 3); Finish(en, "DESTROYED"); _st = St.Settle; _until = now.AddMilliseconds(800); return; }
				if (bagGone || _sawResult)
				{
					if (_resultAt == DateTime.MinValue) { _resultAt = now; return; }   // (the item can go a moment after the bag)
					if ((now - _resultAt).TotalSeconds < 1.5) return;
					if (_sawFail) { Record(en, 2); Log(en.Name + ": " + MatName(_tryMat) + " failed (item kept)"); }
					else { Record(en, 1); en.Good++; }
					en.Step++;
					en.Status = Summary(en) + (en.Step < en.Steps.Count ? "..." : "");
					_st = St.Settle; _until = now.AddMilliseconds(800);
					return;
				}
				if (now > _deadline)
				{
					Finish(en, (en.Good > 0 ? Summary(en) + ", then " : "") + "no answer - skipped");
					_st = St.Settle; _until = now.AddMilliseconds(500);
					return;
				}
				return;
			}
			case St.Move:
			{
				Entry me = _items.Find(x => x.Id == _moveItem);
				WorldObject w = Globals.Core.WorldFilter[_moveItem];
				if (w == null || me == null) { _st = St.Next; return; }
				if (w.Container == _movePack) { me.Status += ", moved"; _st = St.Next; _until = now.AddMilliseconds(300); return; }
				if (now > _deadline) { me.Status += ", didn't move (pack full?)"; _st = St.Next; return; }
				if (!_moveSent)
				{
					if (Globals.Core.Actions.BusyState != 0) { _until = now.AddMilliseconds(300); return; }
					Globals.Core.Actions.MoveItem(_moveItem, _movePack, 0, true);
					_moveSent = true;
				}
				_until = now.AddMilliseconds(300);
				return;
			}
			case St.Settle:
				_st = St.Next;
				return;
		}
	}

	// the chance the game quoted in its question (once it's been asked)
	private static void TakeChance()
	{
		try
		{
			string t = Remote.LastConfirmText ?? "";
			if (t.Length == 0 || (DateTime.Now - _askedAt).TotalSeconds > 15) return;
			System.Text.RegularExpressions.Match pm = System.Text.RegularExpressions.Regex.Match(t, @"(\d+(?:\.\d+)?)\s*(%|percent)");
			if (pm.Success) _chance = double.Parse(pm.Groups[1].Value, System.Globalization.CultureInfo.InvariantCulture);
		}
		catch { }
	}

	private static void MaybeMove(Entry en, DateTime now)
	{
		if (!_moveOn) return;
		if (en.Good < en.Steps.Count) { Log(en.Name + ": not moved - only " + Summary(en)); return; }
		string pack = PackName(_movePack);
		WorldObject w = Globals.Core.WorldFilter[en.Id];
		if (pack == null) { en.Status += ", not moved (no pack)"; return; }
		if (w == null || w.Container == _movePack) return;
		_moveItem = en.Id; _moveSent = false; _deadline = now.AddSeconds(8); _st = St.Move; _until = now.AddMilliseconds(600);
	}

	private static void Record(Entry en, int outcome)
	{
		if (!_stats.TryGetValue(_tryMat, out double[] v)) { v = new double[6]; _stats[_tryMat] = v; }
		v[0]++; v[outcome]++;
		if (_chance >= 0) { v[4] += _chance; v[5]++; }
		string what = outcome == 1 ? "worked" : outcome == 2 ? "failed" : "DESTROYED";
		Log(MatName(_tryMat) + " on " + en.Name + ": " + what + (_chance >= 0 ? " (game said " + _chance.ToString("0.#") + "%)" : ""));
		SaveStats();
	}

	// ---- what the game says ----

	private static void OnChat(object sender, ChatTextInterceptEventArgs e)
	{
		try
		{
			string t = e.Text ?? "";
			string l = t.ToLowerInvariant();
			// (people talking: not the game)
			if (t.IndexOf('"') >= 0 || l.Contains(" says, ") || l.Contains(" tells you") || l.StartsWith("[") || l.StartsWith("you say")) return;
			bool no = l.StartsWith("you cannot") || l.StartsWith("you can't") || l.Contains("not able to") || l.Contains("unable to") || l.Contains("can't be used") || l.Contains("cannot be used");
			if (_rst == R.Wait) { if (no) _rRefused = true; return; }
			if (_st != St.Wait) return;
			if (l.Contains("successfully applies") || l.Contains("successfully apply")) _sawResult = true;
			if (l.Contains("fails to apply") || l.Contains("fail to apply") || (l.Contains("fail") && l.Contains("destroy"))) { _sawResult = true; _sawFail = true; }
			if (no || l.Contains("already been imbued") || l.Contains("already imbued") || l.Contains("can't be tinkered") || l.Contains("cannot be tinkered")) _refused = true;
		}
		catch { }
	}

	// ---- recipes ----

	private sealed class Step
	{
		public string Label; public Func<WorldObject, bool> Tool, Target;
		public Step(string label, Func<WorldObject, bool> tool, Func<WorldObject, bool> target) { Label = label; Tool = tool; Target = target; }
	}

	private static readonly string[] Crafts = new string[] { "Ring spell scroll", "Bandit Hilt" };
	private static readonly string[] Glyphs = new string[] { "Nether", "Acid", "Bludgeon", "Flame", "Frost", "Lightning", "Pierce" };
	private static readonly string[] GlyphNames = new string[] { "Nether", "Corrosion", "Bludgeon", "Flame", "Frost", "Lightning", "Piercing" };
	private const string Q1 = "Quill of Infliction", Q2 = "Enlightened Quill of Infliction", Q3 = "Enlightened Infliction Quill of Partition", InkName = "Ink of Partition";
	private const string EyeAsh = "Adolescent Ash Gromnie Eye", EyeRust = "Adolescent Rust Gromnie Eye", EyeIvory = "Adolescent Ivory Gromnie Eye", EyeAzure = "Adolescent Azure Gromnie Eye";
	private const string Bouquet = "Bouquet of Eyes", HiltU = "Unfinished Bandit Blade Hilt", HiltJ = "Unfinished Jeweled Bandit Hilt", LeatherStart = "Finely Cured Leather";

	private static int _craft, _rGlyph, _rWant = 1, _rMade;
	private static string _rTrophy = "";
	private enum R { Idle, Find, Peace, Apply, Wait }
	private static R _rst = R.Idle;
	private static int _rTool, _rTarget, _rStep, _rToolBefore;
	private static string _rToolName = "", _rTargetName = "", _rStatus = "";
	private static DateTime _rUntil = DateTime.MinValue, _rDeadline = DateTime.MinValue, _rCountAt = DateTime.MinValue;
	private static bool _rRefused;
	private static int _rCountKey = -1, _rCan;
	private static string[] _rCountLines = new string[0];

	private static bool NameIs(WorldObject w, string n) => string.Equals((w.Name ?? "").Trim(), n, StringComparison.OrdinalIgnoreCase);
	private static Func<WorldObject, bool> NameFn(string n) => w => NameIs(w, n);
	private static bool IsTrophy(WorldObject w) { string n = w.Name ?? ""; return _rTrophy.Length > 0 ? string.Equals(n.Trim(), _rTrophy, StringComparison.OrdinalIgnoreCase) : n.IndexOf("trophy", StringComparison.OrdinalIgnoreCase) >= 0; }
	private static bool IsGlyph(WorldObject w) => (w.Name ?? "").StartsWith("Glyph of " + GlyphNames[_rGlyph], StringComparison.OrdinalIgnoreCase);
	private static bool IsHalf(WorldObject w)
	{
		string n = (w.Name ?? "").Trim();
		return !n.StartsWith("Adolescent", StringComparison.OrdinalIgnoreCase) && !string.Equals(n, Bouquet, StringComparison.OrdinalIgnoreCase)
			&& (n.IndexOf("Eye", StringComparison.OrdinalIgnoreCase) >= 0 || n.IndexOf("Bouquet", StringComparison.OrdinalIgnoreCase) >= 0)
			&& w.ObjectClass != ObjectClass.Monster && w.ObjectClass != ObjectClass.Player;
	}

	private static Step[] Steps => _craft == 0
		? new Step[]
		{
			new Step(Q1 + " on a trophy", NameFn(Q1), IsTrophy),
			new Step(Q2 + " on " + InkName, NameFn(Q2), NameFn(InkName)),
			new Step(Q3 + " on Glyph of " + GlyphNames[_rGlyph], NameFn(Q3), IsGlyph),
		}
		: new Step[]
		{
			new Step("Ash eye on Rust eye", NameFn(EyeAsh), NameFn(EyeRust)),
			new Step("Ivory eye on Azure eye", NameFn(EyeIvory), NameFn(EyeAzure)),
			new Step("half on half", IsHalf, IsHalf),
			new Step(Bouquet + " on " + HiltU, NameFn(Bouquet), NameFn(HiltU)),
			new Step(HiltJ + " on " + LeatherStart, NameFn(HiltJ), w => (w.Name ?? "").StartsWith(LeatherStart, StringComparison.OrdinalIgnoreCase)),
		};

	private static string Product => _craft == 0 ? Glyphs[_rGlyph] + " ring scroll" : "Bandit Hilt";

	private static int CountWhere(Func<WorldObject, bool> f)
	{
		int n = 0;
		foreach (WorldObject w in InvCache.All()) if (!Equipped(w) && f(w)) n += Math.Max(1, w.Values(LongValueKey.StackCount, 1));
		return n;
	}

	private static int FirstWhere(Func<WorldObject, bool> f, int notId)
	{
		foreach (WorldObject w in InvCache.All()) if (w.Id != notId && !Equipped(w) && f(w)) return w.Id;
		return 0;
	}

	private static int Makeable(out string[] lines)
	{
		if (_craft == 0)
		{
			int q1 = CountWhere(NameFn(Q1)), tr = CountWhere(IsTrophy), ink = CountWhere(NameFn(InkName));
			int gl = CountWhere(IsGlyph), q2 = CountWhere(NameFn(Q2)), q3 = CountWhere(NameFn(Q3));
			lines = new string[]
			{
				"Quill of Infliction: " + q1 + "    Trophies: " + tr + "    Ink of Partition: " + ink,
				"Glyph of " + GlyphNames[_rGlyph] + ": " + gl + (q2 + q3 > 0 ? "    half-made quills: " + q2 + " + " + q3 : ""),
			};
			return Math.Min(gl, q3 + Math.Min(ink, q2 + Math.Min(q1, tr)));
		}
		int ash = CountWhere(NameFn(EyeAsh)), rust = CountWhere(NameFn(EyeRust)), ivo = CountWhere(NameFn(EyeIvory)), azu = CountWhere(NameFn(EyeAzure));
		int halves = CountWhere(IsHalf), bq = CountWhere(NameFn(Bouquet)), hu = CountWhere(NameFn(HiltU)), hj = CountWhere(NameFn(HiltJ));
		int lea = CountWhere(w => (w.Name ?? "").StartsWith(LeatherStart, StringComparison.OrdinalIgnoreCase));
		lines = new string[]
		{
			"Eyes - Ash: " + ash + "  Rust: " + rust + "  Ivory: " + ivo + "  Azure: " + azu + (halves > 0 ? "    halves: " + halves : ""),
			"Bouquet of Eyes: " + bq + "    Unfinished Hilt: " + hu + "    Jeweled Hilt: " + hj + "    Finely Cured Leather: " + lea,
		};
		int bouquets = bq + Math.Min(Math.Min(ash, rust), Math.Min(ivo, azu)) + halves / 2;
		return Math.Min(lea, hj + Math.Min(hu, bouquets));
	}

	private static void RingStart()
	{
		int can = Makeable(out _);
		if (can == 0) { Say("Can't make a " + Product + " - something's missing (see the counts)."); return; }
		_rMade = 0; _rst = R.Find; _rStatus = "Making " + Product + "s";
		int n = Math.Min(can, _rWant);
		Say("Making " + n + " " + Product + (n == 1 ? "" : "s") + (can < _rWant ? " (only enough for " + can + " of " + _rWant + ")" : "") + ".");
	}

	private static void RingStop(string why)
	{
		if (_rst == R.Idle) return;
		_rst = R.Idle;
		if (!string.IsNullOrEmpty(why)) Say(why);
	}

	private static void RingTick(DateTime now)
	{
		if (now < _rUntil) return;
		switch (_rst)
		{
			case R.Find:
			{
				if (_rMade >= _rWant) { RingStop("Done: made " + _rMade + " " + Product + (_rMade == 1 ? "" : "s") + "."); return; }
				Step[] steps = Steps;
				for (int i = steps.Length - 1; i >= 0; i--)   // (the furthest-along step there's a tool and a target for: half-made things first)
				{
					int a = FirstWhere(steps[i].Tool, 0);
					if (a == 0) continue;
					int b = FirstWhere(steps[i].Target, a);
					if (b == 0) continue;
					_rStep = i + 1; _rTool = a; _rTarget = b;
					_rToolName = Globals.Core.WorldFilter[a].Name; _rTargetName = Globals.Core.WorldFilter[b].Name;
					_rst = R.Peace;
					return;
				}
				RingStop("Nothing left to do - made " + _rMade + " " + Product + (_rMade == 1 ? "" : "s") + " (something ran out; see the counts).");
				return;
			}
			case R.Peace:
				if (Globals.Core.Actions.CombatMode != CombatState.Peace) { Globals.Core.Actions.SetCombatMode(CombatState.Peace); _rUntil = now.AddMilliseconds(1200); return; }
				if (Globals.Core.Actions.BusyState != 0) { _rUntil = now.AddMilliseconds(300); return; }
				_rst = R.Apply;
				return;
			case R.Apply:
			{
				string tn = _rToolName;
				_rToolBefore = CountWhere(w => NameIs(w, tn));
				_rRefused = false;
				_rStatus = Product + " " + (_rMade + 1) + " of " + _rWant + ": step " + _rStep + "/" + Steps.Length;
				Log("Step " + _rStep + "/" + Steps.Length + ": " + _rToolName + " on " + _rTargetName);
				AskYes(now);
				Globals.Core.Actions.ApplyItem(_rTool, _rTarget);
				_rDeadline = now.AddSeconds(20);
				_rst = R.Wait;
				_rUntil = now.AddMilliseconds(600);
				return;
			}
			case R.Wait:
			{
				if (_rRefused) { RingStop("The game refused step " + _rStep + " (" + _rToolName + " on " + _rTargetName + ") - see chat. Made " + _rMade + "."); return; }
				string tn = _rToolName;
				if (Globals.Core.WorldFilter[_rTool] == null || CountWhere(w => NameIs(w, tn)) < _rToolBefore)
				{
					if (_rStep == Steps.Length) { _rMade++; Log("Made " + Product + " " + _rMade + " of " + _rWant + "."); }
					_rst = R.Find;
					_rUntil = now.AddMilliseconds(1000);
					return;
				}
				if (now > _rDeadline) { RingStop("No answer from the game on step " + _rStep + " - stopped. Made " + _rMade + "."); return; }
				_rUntil = now.AddMilliseconds(300);
				return;
			}
		}
	}

	// ---- the tab ----

	private static int _editKind;
	private static int _editProfile = -1;   // index into _profiles being edited (-1: a new one)
	private static string _editName = "";
	private static readonly List<int> _editSteps = new List<int>();
	private static readonly int[] _useIdx = new int[3];
	private static readonly int[] _useCount = new int[3] { 1, 1, 1 };
	private static readonly string[] Counts = new string[] { "1", "2", "3", "4", "5", "6", "7", "8", "9" };

	public static void Draw()
	{
		if (!ImGui.BeginTabBar("##salvtabs")) return;
		if (ImGui.BeginTabItem("Main##salvmain")) { DrawMain(); ImGui.EndTabItem(); }
		if (ImGui.BeginTabItem("Profiles##salvprof")) { DrawProfiles(); ImGui.EndTabItem(); }
		if (ImGui.BeginTabItem("Crafting##salvcraft")) { DrawCrafting(); ImGui.EndTabItem(); }
		ImGui.EndTabBar();
	}

	private static void DrawMain()
	{
		bool busy = Running;
		// a profile for each kind of item on the left; the extras on the right
		if (busy) ImGui.BeginDisabled();
		for (int k = 0; k < 4; k++)
		{
			ImGui.TextUnformatted(KindNames[k]);
			ImGui.SameLine(90f);
			ImGui.SetNextItemWidth(200f);
			List<Profile> ps = _profiles.FindAll(p => p.Kind == k);
			string[] names = new string[ps.Count + 1];
			names[0] = "(none)";
			int at = 0;
			for (int i = 0; i < ps.Count; i++) { names[i + 1] = ps[i].Name; if (ps[i].Name == _pick[k]) at = i + 1; }
			if (ImGui.Combo("##salvpick" + k, ref at, names, names.Length)) { _pick[k] = at > 0 ? ps[at - 1].Name : ""; Save(); }
			Profile pk = Picked(k);
			if (pk != null) Im.SetTooltipIfHovered(Shortly(pk.Steps));
			if (k < 3)
			{
				ImGui.SameLine(320f);
				DrawExtra(k);
			}
		}
		if (busy) ImGui.EndDisabled();
		ImGui.Separator();
		Im.Text("Items (" + _items.Count + ")");
		if (!busy)
		{
			if (ImGui.Button("Add selected item")) AddSelected();
			ImGui.SameLine();
			if (ImGui.Button("Add selected pack")) AddPack(Globals.Core.Actions.CurrentSelection);
			ImGui.SameLine();
			if (ImGui.Button("Add main pack")) AddPack(Globals.Core.CharacterFilter.Id);
			ImGui.SameLine();
			if (ImGui.Button("Clear##salv")) _items.Clear();
		}
		string mpn = PackName(_movePack);
		bool mv = _moveOn;
		if (ImGui.Checkbox("Move to pack when done:", ref mv)) { _moveOn = mv; Save(); }
		Im.SetTooltipIfHovered("Moved there once everything in its profile went on.");
		ImGui.SameLine();
		Im.TextColored(mpn != null ? White : Orange, mpn ?? "(no pack set)");
		if (!busy)
		{
			ImGui.SameLine();
			if (ImGui.SmallButton("Set to selected pack"))
			{
				int sel = Globals.Core.Actions.CurrentSelection;
				WorldObject sp = sel != 0 ? Globals.Core.WorldFilter[sel] : null;
				if (!IsMe(sel) && (sp == null || sp.ObjectClass != ObjectClass.Container)) Say("Select one of your packs first.");
				else { _movePack = sel; _moveOn = true; Save(); }
			}
		}
		// the list, with what's short: the salvage the items still waiting need, against what you carry
		Dictionary<int, int> need = new Dictionary<int, int>();
		ImGui.BeginChild("##salvlist", new Vector2(0f, 190f), true);
		int remove = -1, moveFrom = -1;
		bool moveUp = false;
		for (int i = 0; i < _items.Count; i++)
		{
			Entry en = _items[i];
			if (!busy)
			{
				if (i > 0) { if (Im.UpButton("##salvlup" + i)) { moveFrom = i; moveUp = true; } }
				else ImGui.Dummy(new Vector2(ImGui.GetFrameHeight(), ImGui.GetFrameHeight()));
				ImGui.SameLine();
				if (i < _items.Count - 1) { if (Im.DownButton("##salvldn" + i)) { moveFrom = i; moveUp = false; } }
				else ImGui.Dummy(new Vector2(ImGui.GetFrameHeight(), ImGui.GetFrameHeight()));
				ImGui.SameLine();
				if (ImGui.Button("x##salvx" + i)) remove = i;
				ImGui.SameLine();
			}
			List<int> ps = busy || en.Done ? null : StepsFor(Globals.Core.WorldFilter[en.Id], en.Kind);
			string st = en.Status;
			Vector4 col = en.Done ? Green : (busy && i == _cur ? Yellow : White);
			if (!busy && !en.Done)
			{
				if (ps.Count == 0) { st = "no " + KindNames[en.Kind].ToLowerInvariant() + " profile"; col = Orange; }
				else
				{
					string shortOf = null;
					foreach (int s in ps)
					{
						need[s] = (need.TryGetValue(s, out int n) ? n : 0) + 1;
						if (shortOf == null && need[s] > Have(s)) shortOf = MatName(s);
					}
					Profile pp = Picked(en.Kind);
					st = shortOf != null ? "not enough " + shortOf : "ready - " + (pp != null ? pp.Name : "") + (ps.Count > (pp?.Steps.Count ?? 0) ? (pp != null ? " + extras" : "extras") : "");
					if (shortOf != null) col = Orange;
				}
			}
			Im.TextColored(Grey, (i + 1) + ".");
			ImGui.SameLine();
			Im.TextColored(col, en.Name);
			ImGui.SameLine(0f, 14f);
			Im.TextColored(st.StartsWith("DESTROYED") ? Red : Grey, st);
		}
		if (remove >= 0) _items.RemoveAt(remove);
		else if (moveFrom >= 0) Im.Move(_items, moveFrom, moveUp);
		if (_items.Count == 0 && _lastRun.Count > 0)
		{
			Im.TextColored(Grey, "Last run:");
			foreach (Entry en in _lastRun)
			{
				if (en.Steps.Count == 0) continue;
				Im.TextColored(en.Status.StartsWith("DESTROYED") ? Red : en.Good >= en.Steps.Count ? Green : Orange, en.Name);
				ImGui.SameLine(260f);
				Im.TextColored(Grey, en.Status);
			}
		}
		ImGui.EndChild();
		if (!busy) { if (ImGui.Button("Start##salv", new Vector2(100f, 0f))) StartRun(); }
		else if (ImGui.Button("Stop##salv", new Vector2(100f, 0f))) { StopRun("Stopped."); RingStop(null); }
		ImGui.SameLine();
		Im.Text(_rst != R.Idle ? _rStatus : _status);
		DrawRates();
		DrawLog();
	}

	private static void DrawExtra(int row)
	{
		if (row == 0)
		{
			// Slayer: the one selected (its name); every weapon and caster without a slayer gets one
			ImGui.TextUnformatted("Slayer");
			ImGui.SameLine(390f);
			Im.TextColored(_slayer.Length > 0 ? White : Grey, _slayer.Length > 0 ? _slayer + "  (" + Have(SlayerId) + ")" : "(none)");
			ImGui.SameLine();
			if (ImGui.SmallButton("Sel##salvslay"))
			{
				int sel = Globals.Core.Actions.CurrentSelection;
				WorldObject w = sel != 0 ? Globals.Core.WorldFilter[sel] : null;
				if (w == null) Say("Select the slayer first.");
				else { _slayer = (w.Name ?? "").Trim(); SetExtraNames(); _countsAt = DateTime.MinValue; Save(); }
			}
			Im.SetTooltipIfHovered("Select a slayer in your pack, then Sel: it goes on every weapon and caster in the list that hasn't got a slayer.");
			if (_slayer.Length > 0)
			{
				ImGui.SameLine();
				if (ImGui.SmallButton("x##salvslayx")) { _slayer = ""; SetExtraNames(); Save(); }
			}
		}
		else if (row == 1)
		{
			// Hilt: a Fine Bandit Blade Hilt on melee weapons, a Bandit Bowstring on bows
			ImGui.TextUnformatted("Hilt");
			ImGui.SameLine(390f);
			bool h = _hilt;
			if (ImGui.Checkbox("##salvhilt", ref h)) { _hilt = h; Save(); }
			ImGui.SameLine();
			Im.TextColored(Grey, "melee: blade hilt (" + Have(HiltId) + ")   bows: bowstring (" + Have(BowstringId) + ")");
		}
		else
		{
			// Ring spell: one of the inscriptions you carry, on necklaces and bows
			ImGui.TextUnformatted("Ring spell");
			ImGui.SameLine(390f);
			List<string> found = new List<string>();
			foreach (WorldObject w in InvCache.All())
			{
				string n = (w.Name ?? "").Trim();
				if (n.StartsWith("Inscription of ", StringComparison.OrdinalIgnoreCase) && !found.Contains(n)) found.Add(n);
			}
			if (_ring.Length > 0 && !found.Contains(_ring)) found.Add(_ring);
			found.Sort(StringComparer.OrdinalIgnoreCase);
			string[] names = new string[found.Count + 1];
			names[0] = "(none)";
			int at = 0;
			for (int i = 0; i < found.Count; i++) { names[i + 1] = found[i] + "  (" + CountWhere(NameFn(found[i])) + ")"; if (found[i] == _ring) at = i + 1; }
			ImGui.SetNextItemWidth(230f);
			if (ImGui.Combo("##salvring", ref at, names, names.Length)) { _ring = at > 0 ? found[at - 1] : ""; SetExtraNames(); _countsAt = DateTime.MinValue; Save(); }
			Im.SetTooltipIfHovered("The ring spell (an Inscription you carry - Clouded Soul is Nether) that goes on every necklace and bow in the list.");
		}
	}

	private static string Shortly(List<int> steps)
	{
		// "White Quartz, Yellow Garnet, Turquoise, Iron x9, Foolproof Imperial Topaz (10 tinkers)"
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < steps.Count;)
		{
			int j = i;
			while (j < steps.Count && steps[j] == steps[i]) j++;
			if (sb.Length > 0) sb.Append(", ");
			sb.Append(MatName(steps[i]));
			if (j - i > 1) sb.Append(" x").Append(j - i);
			i = j;
		}
		int t = TinkerCount(steps);
		return sb + (t > 0 ? "  (" + t + " tinker" + (t == 1 ? "" : "s") + ")" : "");
	}

	private static void DrawRates()
	{
		double it = 0, iw = 0;
		foreach (KeyValuePair<int, double[]> kv in _stats)
		{
			Mat m = MatOf(kv.Key);
			if (m != null && m.Use != Use.Tinker) { it += kv.Value[0]; iw += kv.Value[1]; }
		}
		string head = "Success rates" + (_char != null ? " (" + _char + ")" : "") + (it > 0 ? "  -  imbues and rends: " + (100 * iw / it).ToString("0") + "% (" + iw + " of " + it + ")" : "");
		if (!ImGui.CollapsingHeader(head + "###salvrates")) return;
		if (_stats.Count == 0) Im.TextColored(Grey, "Nothing tried yet.");
		List<int> ids = new List<int>(_stats.Keys);
		ids.Sort((a, b) => string.Compare(MatName(a), MatName(b), StringComparison.Ordinal));
		foreach (int id in ids)
		{
			double[] v = _stats[id];
			if (v[0] <= 0) continue;
			string line = MatName(id) + ": " + v[1] + " of " + v[0] + " worked (" + (100 * v[1] / v[0]).ToString("0") + "%)";
			if (v[2] > 0) line += ", " + v[2] + " failed";
			if (v[3] > 0) line += ", " + v[3] + " destroyed";
			if (v[5] > 0) line += "  - game said ~" + (v[4] / v[5]).ToString("0.#") + "%";
			Im.Text(line);
		}
		if (_stats.Count > 0 && ImGui.SmallButton("Reset rates")) { _stats.Clear(); SaveStats(); }
	}

	private static void DrawLog()
	{
		ImGui.BeginChild("##salvlog", new Vector2(0f, 110f), true);
		for (int i = 0; i < _log.Count; i++) Im.TextColored(Grey, _log[i]);
		if (_log.Count != _logShown) { ImGui.SetScrollHereY(1f); _logShown = _log.Count; }
		ImGui.EndChild();
	}

	private static void DrawProfiles()
	{
		// which kind of item, and a profile of it to change (or a new one)
		ImGui.TextUnformatted("Item");
		ImGui.SameLine(90f);
		ImGui.SetNextItemWidth(140f);
		int k = _editKind;
		if (ImGui.Combo("##salvekind", ref k, KindNames, KindNames.Length) && k != _editKind)
		{
			_editKind = k; _editProfile = -1; _editName = ""; _editSteps.Clear();
			for (int i = 0; i < 3; i++) _useIdx[i] = 0;
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(200f);
		List<int> mine = new List<int>();
		for (int i = 0; i < _profiles.Count; i++) if (_profiles[i].Kind == _editKind) mine.Add(i);
		string[] pn = new string[mine.Count + 1];
		pn[0] = "(new profile)";
		int sel = 0;
		for (int i = 0; i < mine.Count; i++) { pn[i + 1] = _profiles[mine[i]].Name; if (mine[i] == _editProfile) sel = i + 1; }
		if (ImGui.Combo("##salveprof", ref sel, pn, pn.Length))
		{
			_editSteps.Clear();
			if (sel == 0) { _editProfile = -1; _editName = ""; }
			else { _editProfile = mine[sel - 1]; _editName = _profiles[_editProfile].Name; _editSteps.AddRange(_profiles[_editProfile].Steps); }
		}
		ImGui.Separator();
		// Imbue / Rend / Tinker: a salvage, how many, Add
		string[] rows = new string[] { "Imbue", "Rend", "Tinker" };
		int tinks = TinkerCount(_editSteps);
		for (int r = 0; r < 3; r++)
		{
			List<Mat> ms = Mats.FindAll(m => (int)m.Use == r && !m.Extra && Fits(m, _editKind));
			ImGui.TextUnformatted(rows[r]);
			ImGui.SameLine(90f);
			if (ms.Count == 0) { Im.TextColored(Grey, "(none for " + KindNames[_editKind].ToLowerInvariant() + ")"); continue; }
			string[] names = new string[ms.Count];
			for (int i = 0; i < ms.Count; i++)
			{
				int have = Have(ms[i].Id);
				names[i] = ms[i].Name + (ms[i].Note.Length > 0 ? " (" + ms[i].Note + ")" : "") + (have > 0 ? "  - " + have : "");
			}
			if (_useIdx[r] >= ms.Count) _useIdx[r] = 0;
			ImGui.SetNextItemWidth(300f);
			ImGui.Combo("##salvmat" + r, ref _useIdx[r], names, names.Length);
			ImGui.SameLine();
			ImGui.SetNextItemWidth(45f);
			int c = _useCount[r] - 1;
			if (ImGui.Combo("##salvcnt" + r, ref c, Counts, Counts.Length)) _useCount[r] = c + 1;
			ImGui.SameLine();
			Mat pick = ms[_useIdx[r]];
			int n = _useCount[r];
			bool tink = CountsAsTinker(pick);
			bool full = tink && tinks + n > MaxTinkers;
			if (full) ImGui.BeginDisabled();
			if (ImGui.Button("Add##salvadd" + r)) { for (int i = 0; i < n; i++) Insert(pick); }
			if (full) ImGui.EndDisabled();
			if (full) Im.SetTooltipIfHovered("That would be more than " + MaxTinkers + " tinkers (" + tinks + " now). Imbues don't count; rends do.");
		}
		Im.TextColored(tinks > MaxTinkers ? Red : Grey, "Tinkers: " + tinks + " of " + MaxTinkers + "   (imbues don't count; rends do - a foolproof rend goes last, other rends before the tinkers)");
		// the steps, in the order they go on
		ImGui.BeginChild("##salvsteps", new Vector2(0f, 200f), true);
		int up = -1, down = -1, drop = -1;
		for (int i = 0; i < _editSteps.Count; i++)
		{
			Mat m = MatOf(_editSteps[i]);
			// (the arrows as everywhere else: green up, red down - only where it can go; held, all the way)
			float aw = ImGui.GetFrameHeight();
			if (i > 0) { if (Im.UpButton("##salvup" + i)) up = i; } else ImGui.Dummy(new Vector2(aw, aw));
			ImGui.SameLine();
			if (i < _editSteps.Count - 1) { if (Im.DownButton("##salvdn" + i)) down = i; } else ImGui.Dummy(new Vector2(aw, aw));
			ImGui.SameLine();
			if (ImGui.SmallButton("x##salvrm" + i)) drop = i;
			ImGui.SameLine();
			Im.TextColored(Grey, (i + 1) + ".");
			ImGui.SameLine();
			Im.TextColored(m == null ? Red : m.Use == Use.Imbue ? Yellow : m.Use == Use.Rend ? Orange : White, MatName(_editSteps[i]));
			ImGui.SameLine(300f);
			Im.TextColored(Grey, m == null ? "?" : m.Use == Use.Imbue ? "imbue" : m.Use == Use.Rend ? (m.Foolproof ? "foolproof rend" : "rend") : "tinker");
		}
		if (_editSteps.Count == 0) Im.TextColored(Grey, "Nothing yet: pick a salvage above, how many, then Add.");
		ImGui.EndChild();
		if (up > 0) Im.Move(_editSteps, up, up: true);
		else if (down >= 0) Im.Move(_editSteps, down, up: false);
		if (drop >= 0) _editSteps.RemoveAt(drop);
		// name, and save / update / delete
		ImGui.TextUnformatted("Name");
		ImGui.SameLine(90f);
		ImGui.SetNextItemWidth(220f);
		ImGui.InputText("##salvname", ref _editName, 60u);
		string name = (_editName ?? "").Trim();
		bool taken = _profiles.Exists(p => p.Kind == _editKind && string.Equals(p.Name, name, StringComparison.OrdinalIgnoreCase) && _profiles.IndexOf(p) != _editProfile);
		bool canSave = name.Length > 0 && _editSteps.Count > 0 && !taken;
		if (!canSave) ImGui.BeginDisabled();
		if (ImGui.Button("Save##salvsave"))
		{
			_profiles.Add(new Profile { Name = name, Kind = _editKind, Steps = new List<int>(_editSteps) });
			_editProfile = _profiles.Count - 1;
			Save();
			Say("Saved the " + KindNames[_editKind].ToLowerInvariant() + " profile " + name + ".");
		}
		if (!canSave) ImGui.EndDisabled();
		Im.SetTooltipIfHovered(taken ? "There's already a " + KindNames[_editKind].ToLowerInvariant() + " profile called that - Update it, or pick another name." : "Saves this as a new profile.");
		ImGui.SameLine();
		bool canUpdate = _editProfile >= 0 && name.Length > 0 && _editSteps.Count > 0 && !taken;
		if (!canUpdate) ImGui.BeginDisabled();
		if (ImGui.Button("Update##salvupd"))
		{
			Profile p = _profiles[_editProfile];
			for (int i = 0; i < 4; i++) if (_pick[i] == p.Name && p.Kind == i) _pick[i] = name;   // (still picked under its new name)
			p.Name = name;
			p.Steps = new List<int>(_editSteps);
			Save();
			Say("Updated " + name + ".");
		}
		if (!canUpdate) ImGui.EndDisabled();
		ImGui.SameLine();
		bool canDelete = _editProfile >= 0;
		if (!canDelete) ImGui.BeginDisabled();
		if (ImGui.Button("Delete##salvdel"))
		{
			Profile p = _profiles[_editProfile];
			if (_pick[p.Kind] == p.Name) _pick[p.Kind] = "";
			_profiles.RemoveAt(_editProfile);
			_editProfile = -1; _editName = ""; _editSteps.Clear();
			Save();
			Say("Deleted " + p.Name + ".");
		}
		if (!canDelete) ImGui.EndDisabled();
	}

	// a new step in its place: imbues first, then rends, then tinkers, then a foolproof rend
	private static void Insert(Mat m)
	{
		int rank = Rank(m);
		int at = _editSteps.Count;
		for (int i = 0; i < _editSteps.Count; i++) if (Rank(MatOf(_editSteps[i])) > rank) { at = i; break; }
		_editSteps.Insert(at, m.Id);
	}

	private static void DrawCrafting()
	{
		bool busy = Running;
		ImGui.TextUnformatted("Make");
		ImGui.SameLine(90f);
		ImGui.SetNextItemWidth(180f);
		int craft = _craft;
		if (busy) ImGui.BeginDisabled();
		if (ImGui.Combo("##salvcraftk", ref craft, Crafts, Crafts.Length) && craft != _craft) { _craft = craft; Save(); }
		if (_craft == 0)
		{
			ImGui.TextUnformatted("Ring");
			ImGui.SameLine(90f);
			ImGui.SetNextItemWidth(180f);
			int g = _rGlyph;
			if (ImGui.Combo("##salvglyph", ref g, Glyphs, Glyphs.Length) && g != _rGlyph) { _rGlyph = g; Save(); }
		}
		ImGui.TextUnformatted("How many");
		ImGui.SameLine(90f);
		ImGui.SetNextItemWidth(100f);
		int want = _rWant;
		if (ImGui.InputInt("##salvwant", ref want)) { _rWant = Math.Max(1, Math.Min(100, want)); Save(); }
		if (_craft == 0)
		{
			ImGui.TextUnformatted("Trophy");
			ImGui.SameLine(90f);
			Im.Text(_rTrophy.Length > 0 ? _rTrophy : "any item named ...Trophy...");
			ImGui.SameLine();
			if (ImGui.SmallButton("Use selected##salvtr"))
			{
				int sel = Globals.Core.Actions.CurrentSelection;
				WorldObject w = sel != 0 ? Globals.Core.WorldFilter[sel] : null;
				if (w == null) Say("Select a trophy first.");
				else { _rTrophy = (w.Name ?? "").Trim(); Save(); }
			}
			if (_rTrophy.Length > 0) { ImGui.SameLine(); if (ImGui.SmallButton("Any trophy##salvtr2")) { _rTrophy = ""; Save(); } }
		}
		if (busy) ImGui.EndDisabled();
		ImGui.Separator();
		int key = _craft * 100 + _rGlyph;
		if ((DateTime.Now - _rCountAt).TotalSeconds >= 1 || _rCountKey != key)
		{
			_rCountAt = DateTime.Now; _rCountKey = key;
			_rCan = Makeable(out _rCountLines);
		}
		foreach (string l in _rCountLines) Im.Text(l);
		Im.TextColored(_rCan > 0 ? Green : Orange, "You can make " + _rCan + " " + Product + (_rCan == 1 ? "" : "s") + ".");
		if (!busy) { if (ImGui.Button("Make##salv", new Vector2(100f, 0f))) RingStart(); }
		else if (ImGui.Button("Stop##salvr", new Vector2(100f, 0f))) { RingStop("Stopped."); StopRun(null); }
		ImGui.SameLine();
		Im.Text(_rst != R.Idle ? _rStatus : _status);
		DrawLog();
	}

	// ---- chat, the log, files ----

	private static void Say(string s) { Log(s); Util.WriteToChat("Salvage: " + s); }

	private static void Log(string s)
	{
		_log.Add(DateTime.Now.ToString("HH:mm:ss") + " " + s);
		if (_log.Count > 200) { _log.RemoveAt(0); _logShown = -1; }
	}

	private static string ProfilesFile => Util.FullPath("MelkTank_SalvageProfiles.txt");
	private static string StatsFile
	{
		get
		{
			string n = _char ?? "";
			foreach (char c in Path.GetInvalidFileNameChars()) n = n.Replace(c, '_');
			return Util.FullPath("MelkTank_SalvageRates_" + n + ".txt");
		}
	}

	// profiles: "profile=<kind>|<name>|<id,id,...>"; per character: "pick.<char>.<kind>=<name>", "move.<char>=<on>|<pack>";
	// and "craft=", "glyph=", "want=", "trophy="
	private static void Load()
	{
		_profiles.Clear();
		for (int i = 0; i < 4; i++) _pick[i] = "";
		_hilt = false; _ring = ""; _slayer = "";
		try
		{
			if (!File.Exists(ProfilesFile)) return;
			string me = (_char ?? "").Trim();
			foreach (string line in File.ReadAllLines(ProfilesFile))
			{
				int eq = line.IndexOf('=');
				if (eq <= 0) continue;
				string k = line.Substring(0, eq).Trim(), v = line.Substring(eq + 1);
				if (k == "profile")
				{
					string[] p = v.Split('|');
					if (p.Length < 3 || !int.TryParse(p[0], out int kind) || kind < 0 || kind > 3) continue;
					Profile pr = new Profile { Kind = kind, Name = p[1].Trim() };
					foreach (string s in p[2].Split(',')) if (int.TryParse(s.Trim(), out int id) && MatOf(id) != null) pr.Steps.Add(id);
					if (pr.Name.Length > 0) _profiles.Add(pr);
				}
				else if (k.StartsWith("pick." + me + ".", StringComparison.Ordinal))
				{
					if (int.TryParse(k.Substring(k.LastIndexOf('.') + 1), out int kind) && kind >= 0 && kind < 4) _pick[kind] = v.Trim();
				}
				else if (k == "move." + me)
				{
					string[] p = v.Split('|');
					_moveOn = p[0].Trim() == "1";
					if (p.Length > 1) int.TryParse(p[1].Trim(), out _movePack);
				}
				else if (k == "extras." + me)
				{
					string[] p = v.Split('|');
					_hilt = p[0].Trim() == "1";
					_ring = p.Length > 1 ? p[1].Trim() : "";
					_slayer = p.Length > 2 ? p[2].Trim() : "";
				}
				else if (k == "craft") { if (int.TryParse(v, out int c) && c >= 0 && c < Crafts.Length) _craft = c; }
				else if (k == "glyph") { if (int.TryParse(v, out int g) && g >= 0 && g < Glyphs.Length) _rGlyph = g; }
				else if (k == "want") { if (int.TryParse(v, out int w)) _rWant = Math.Max(1, Math.Min(100, w)); }
				else if (k == "trophy") _rTrophy = v.Trim();
			}
		}
		catch (Exception ex) { Util.LogError(ex); }
		finally { SetExtraNames(); }
	}

	private static void Save()
	{
		try
		{
			string me = (_char ?? "").Trim();
			// (other characters' picks are kept as they were)
			List<string> keep = new List<string>();
			if (File.Exists(ProfilesFile))
				foreach (string line in File.ReadAllLines(ProfilesFile))
					if ((line.StartsWith("pick.", StringComparison.Ordinal) && !line.StartsWith("pick." + me + ".", StringComparison.Ordinal)) ||
						(line.StartsWith("move.", StringComparison.Ordinal) && !line.StartsWith("move." + me + "=", StringComparison.Ordinal)) ||
						(line.StartsWith("extras.", StringComparison.Ordinal) && !line.StartsWith("extras." + me + "=", StringComparison.Ordinal)))
						keep.Add(line);
			StringBuilder sb = new StringBuilder("# MelkTank salvage profiles (Items > Salvage)\r\n");
			foreach (Profile p in _profiles) sb.Append("profile=").Append(p.Kind).Append('|').Append(p.Name.Replace("|", "/")).Append('|').Append(string.Join(",", p.Steps)).Append("\r\n");
			for (int i = 0; i < 4; i++) if (_pick[i].Length > 0) sb.Append("pick.").Append(me).Append('.').Append(i).Append('=').Append(_pick[i]).Append("\r\n");
			sb.Append("move.").Append(me).Append('=').Append(_moveOn ? 1 : 0).Append('|').Append(_movePack).Append("\r\n");
			sb.Append("extras.").Append(me).Append('=').Append(_hilt ? 1 : 0).Append('|').Append(_ring.Replace("|", "/")).Append('|').Append(_slayer.Replace("|", "/")).Append("\r\n");
			foreach (string l in keep) sb.Append(l).Append("\r\n");
			sb.Append("craft=").Append(_craft).Append("\r\nglyph=").Append(_rGlyph).Append("\r\nwant=").Append(_rWant).Append("\r\ntrophy=").Append(_rTrophy).Append("\r\n");
			File.WriteAllText(ProfilesFile, sb.ToString());
		}
		catch (Exception ex) { Util.LogError(ex); }
	}

	private static void LoadStats()
	{
		_stats.Clear();
		try
		{
			if (!File.Exists(StatsFile)) return;
			foreach (string line in File.ReadAllLines(StatsFile))
			{
				string[] p = line.Split('=');
				if (p.Length != 2 || !int.TryParse(p[0], out int id)) continue;
				string[] n = p[1].Split(',');
				if (n.Length != 6) continue;
				double[] v = new double[6];
				for (int i = 0; i < 6; i++) double.TryParse(n[i], System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out v[i]);
				_stats[id] = v;
			}
		}
		catch (Exception ex) { Util.LogError(ex); }
	}

	private static void SaveStats()
	{
		try
		{
			StringBuilder sb = new StringBuilder("# salvage id = tries, worked, failed, destroyed, sum of quoted chances, quotes\r\n");
			foreach (KeyValuePair<int, double[]> kv in _stats)
			{
				sb.Append(kv.Key).Append('=');
				for (int i = 0; i < 6; i++) { if (i > 0) sb.Append(','); sb.Append(kv.Value[i].ToString(System.Globalization.CultureInfo.InvariantCulture)); }
				sb.Append("\r\n");
			}
			File.WriteAllText(StatsFile, sb.ToString());
		}
		catch (Exception ex) { Util.LogError(ex); }
	}
}
