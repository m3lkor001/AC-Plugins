using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
#if !RETAIL
using ACGodot.DecalShim;
using ACGodot.Plugins;
using ACGodot.UI;
#endif
#if !RETAIL
using AcClient;
#else
using SmartBox = AcClient.SmartBox;
using ACCmdInterp = AcClient.ACCmdInterp;
using CommandInterpreter = AcClient.CommandInterpreter;
using CommandListElement = AcClient.CommandListElement;
using CPhysicsObj = AcClient.CPhysicsObj;
using Position = AcClient.Position;
using CTransition = AcClient.CTransition;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
#if !RETAIL
using Godot;
#endif
using ImGuiNET;
using MelkTank.Loot;
using MelkTank.Metas;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public partial class Nav
{
	private bool DrawLoopEnd(NavRoute r, RouteStep st)
	{
		bool result = false;
		ImGui.Separator();
		Im.TextColored(Cyan, "Loop end (step " + (r.Steps.IndexOf(st) + 1) + "): leave the loop when ALL of these are true");
		if (r.Steps.IndexOf(st) != LoopEndIdx(r))
		{
			Im.TextColored(Yellow, "This isn't the loop end that closes the loop (there's another one before it) - it's skipped.");
		}
		int num = -1;
		for (int i = 0; i < st.Conds.Count; i++)
		{
			ImGui.PushID("lc" + i);
			if (ImGui.SmallButton("x"))
			{
				num = i;
			}
			ImGui.SameLine();
			ImGui.TextUnformatted(((i > 0) ? "and " : "") + CondText(st.Conds[i]));
			ImGui.PopID();
		}
		if (num >= 0)
		{
			st.Conds.RemoveAt(num);
			result = true;
		}
		if (st.Conds.Count == 0)
		{
			Im.TextColored(Grey, "No conditions yet: it loops for ever.");
		}
		ImGui.SetNextItemWidth(220f);
		ImGui.InputText("##lcitem", ref _rcText, 200u);
		ImGui.SameLine();
		if (ImGui.SmallButton("sel##lcsel"))
		{
			try
			{
				WorldObject worldObject = Globals.Core.WorldFilter[Globals.Core.Actions.CurrentSelection];
				if (worldObject != null)
				{
					_rcText = worldObject.Name;
				}
			}
			catch
			{
			}
		}
		Tip("Use the name of the item you have selected.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(60f);
		ImGui.Combo("##lcop", ref _rcOp, ItemOps, ItemOps.Length);
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		ImGui.InputInt("##lcnum", ref _rcNum, 1, 10);
		if (_rcNum < 0)
		{
			_rcNum = 0;
		}
		ImGui.SameLine();
		if (ImGui.Button("Add item condition") && _rcText.Trim().Length > 0)
		{
			st.Conds.Add(new LoopCond
			{
				Text = _rcText.Trim(),
				Op = ItemOps[_rcOp],
				Count = _rcNum
			});
			_rcText = "";
			result = true;
		}
		Tip("Items in your packs (stacks counted; exact name first, else names containing it).");
		ImGui.SetNextItemWidth(220f);
		ImGui.InputText("##lcchat", ref _rcChat, 200u);
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		ImGui.Combo("##lcchatop", ref _rcChatOp, ChatOps, ChatOps.Length);
		ImGui.SameLine();
		if (ImGui.Button("Add chat condition") && _rcChat.Trim().Length > 0)
		{
			st.Conds.Add(new LoopCond
			{
				Chat = true,
				Text = _rcChat.Trim(),
				Op = ChatOps[_rcChatOp]
			});
			_rcChat = "";
			result = true;
		}
		Tip("True once a matching chat line has come in since the loop started (e.g. a quest's 'You have collected enough' message).");
		ImGui.Separator();
		return result;
	}

	private static string Describe(RouteStep st)
	{
		switch (st.Kind)
		{
		case StepKind.Point:
			return Math.Abs(st.NS).ToString("0.000") + ((st.NS >= 0.0) ? "N" : "S") + ", " + Math.Abs(st.EW).ToString("0.000") + ((st.EW >= 0.0) ? "E" : "W");
		case StepKind.Command:
			return st.Text + "   (then " + st.WaitMs + " ms)";
		case StepKind.Use:
			return st.Text;
		case StepKind.Vendor:
			return "Vendor at " + st.Text + "   (profile " + (string.IsNullOrEmpty(st.Profile) ? "named after the vendor" : st.Profile) + ")";
		case StepKind.UseItem:
			return "Use " + st.Text + "   (then up to " + ((double)st.WaitMs / 1000.0).ToString("0.#") + " s)";
		case StepKind.Wait:
			return ((double)st.WaitMs / 1000.0).ToString("0.#") + " s";
		case StepKind.PlayerSkip:
			return "a player within " + SkipRange(st).ToString("0") + " m" + (SkipNoMobs(st) ? " or no monsters in combat range" : "") + ": skip the next " + st.Count + " step" + ((st.Count == 1) ? "" : "s");
		case StepKind.LoopStart:
			return "---- the steps below repeat ----";
		case StepKind.LoopEnd:
			return (st.Conds.Count == 0) ? "---- back to the loop start (add conditions to leave it) ----" : ("---- round again until " + string.Join(" and ", st.Conds.ConvertAll<string>(CondText).ToArray()) + " ----");
		case StepKind.GoRoute:
			return "-> route " + st.Text + ((st.Op == "nearest") ? "  (at its nearest point)" : "  (from step 1)");
		case StepKind.ChatWait:
			return "until chat " + st.Op + " \"" + st.Text + "\"";
		case StepKind.ItemCheck:
			return "until " + st.Text + " " + st.Op + " " + st.Count + "   (have " + InventoryCount(st.Text) + ")";
		case StepKind.Cast:
		{
			int.TryParse(st.Text, out var result);
			return "Cast " + (SpellNames.Name(result) ?? ("spell " + st.Text));
		}
		case StepKind.Preset:
		{
			NavRoute navRoute = NavPresets.Find(st.Text);
			return st.Text + ((navRoute == null) ? "   (no preset by this name - skipped)" : ("   (" + navRoute.Steps.Count + " step" + ((navRoute.Steps.Count == 1) ? "" : "s") + ")"));
		}
		case StepKind.Toggle:
			return (st.Text ?? "").Replace("combat", "Combat").Replace("looting", "Looting").Replace("summoning", "Summoning")
				.Replace("reset session", "Reset session")
				.Replace("reset kills/hr", "Reset kills/hr")
				.Replace("doors", "Doors")
				.Replace(" on", " ON")
				.Replace(" off", " OFF");
		default:
			return "";
		}
	}

	private static bool AddButton(string label)
	{
		return ImGui.Button(label, new System.Numerics.Vector2(150f, 0f));
	}

	private List<string> OtherRoutes(NavRoute r)
	{
		List<string> list = new List<string>();
		foreach (NavRoute navRoute in _s.NavRoutes)
		{
			if (navRoute != r)
			{
				list.Add(navRoute.Name);
			}
		}
		return list;
	}

	private RouteStep UseStepFromSelection()
	{
		int num = 0;
		try
		{
			num = Globals.Core.Actions.CurrentSelection;
		}
		catch
		{
		}
		WorldObject worldObject = ((num != 0) ? Globals.Core.WorldFilter[num] : null);
		CoordsObject coordsObject = null;
		try
		{
			coordsObject = worldObject?.Coordinates();
		}
		catch
		{
		}
		if (worldObject == null || coordsObject == null)
		{
			Util.WriteToChat("Nav: select a portal or NPC in the world first.");
			return null;
		}
		double z = 0.0;
		try
		{
			z = worldObject.RawCoordinates().Z;
		}
		catch
		{
		}
		return new RouteStep
		{
			Kind = StepKind.Use,
			Text = worldObject.Name,
			NS = coordsObject.NorthSouth,
			EW = coordsObject.EastWest,
			Z = z
		};
	}

	private static string KindName(StepKind k)
	{
		return k switch
		{
			StepKind.Point => "Point", 
			StepKind.Command => "Command", 
			StepKind.Use => "Use", 
			StepKind.Wait => "Wait", 
			StepKind.Toggle => "Switch", 
			StepKind.Cast => "Cast", 
			StepKind.ChatWait => "Chat wait", 
			StepKind.ItemCheck => "Item check", 
			StepKind.LoopEnd => "Loop end", 
			StepKind.GoRoute => "Go to route", 
			StepKind.UseItem => "Use item", 
			StepKind.Preset => "Preset", 
			StepKind.PlayerSkip => "Player skip", 
			StepKind.Vendor => "Vendor", 
			_ => "Loop", 
		};
	}

	private bool DrawEditRow(NavRoute r)
	{
		bool result = false;
		if (_rEdit == null)
		{
			bool flag = _rSel >= 0 && _rSel < r.Steps.Count;
			if (AddButton("Edit step"))
			{
				if (!flag)
				{
					Util.WriteToChat("Nav: click a step in the list first, then Edit step.");
				}
				else
				{
					StartEdit(r, r.Steps[_rSel]);
				}
			}
			Tip("Puts the selected step's settings into the boxes below so you can change them, then Update.");
			ImGui.SameLine();
			Im.TextColored(Grey, flag ? ("step " + (_rSel + 1) + " (" + KindName(r.Steps[_rSel].Kind) + ") selected") : "click a step in the list to select it");
			return false;
		}
		RouteStep rEdit = _rEdit;
		int num = r.Steps.IndexOf(rEdit);
		if (AddButton("Update"))
		{
			ApplyEdit(r, rEdit);
			_rEdit = null;
			return true;
		}
		Tip("Saves the boxes into this step.");
		ImGui.SameLine();
		if (ImGui.Button("Cancel##redit", new System.Numerics.Vector2(80f, 0f)))
		{
			_rEdit = null;
			return false;
		}
		ImGui.SameLine();
		string text = ((rEdit.Kind == StepKind.Point || rEdit.Kind == StepKind.Use) ? "change it here" : ("change it in the " + KindName(rEdit.Kind) + " row below"));
		Im.TextColored(Yellow, "Editing step " + (num + 1) + " (" + KindName(rEdit.Kind) + ") - " + text + ", then Update");
		if (rEdit.Kind == StepKind.Point || rEdit.Kind == StepKind.Use)
		{
			ImGui.Dummy(new System.Numerics.Vector2(150f, 0f));
			ImGui.SameLine();
			if (rEdit.Kind == StepKind.Use)
			{
				ImGui.SetNextItemWidth(200f);
				ImGui.InputText("##reditname", ref _rEditName, 120u);
				Tip("The portal or NPC's name.");
				ImGui.SameLine();
			}
			ImGui.SetNextItemWidth(110f);
			ImGui.InputDouble("N/S##reditns", ref _rEditNS, 0.0, 0.0, "%.3f");
			Tip("North is +, south is - (29.048S = -29.048).");
			ImGui.SameLine();
			ImGui.SetNextItemWidth(110f);
			ImGui.InputDouble("E/W##reditew", ref _rEditEW, 0.0, 0.0, "%.3f");
			Tip("East is +, west is -.");
			ImGui.SameLine();
			if (rEdit.Kind == StepKind.Point && ImGui.Button("My position##reditpos") && MyPos(out var ns, out var ew, out var z))
			{
				_rEditNS = ns;
				_rEditEW = ew;
				_rEditZ = z;
			}
			if (rEdit.Kind == StepKind.Use && ImGui.Button("Selected##reditsel"))
			{
				RouteStep routeStep = UseStepFromSelection();
				if (routeStep != null)
				{
					_rEditName = routeStep.Text;
					_rEditNS = routeStep.NS;
					_rEditEW = routeStep.EW;
					_rEditZ = routeStep.Z;
				}
			}
			Tip((rEdit.Kind == StepKind.Point) ? "Where you're standing now." : "The portal or NPC you have selected now.");
		}
		return result;
	}

	private void StartEdit(NavRoute r, RouteStep st)
	{
		switch (st.Kind)
		{
		case StepKind.Point:
		case StepKind.Use:
			_rEditNS = st.NS;
			_rEditEW = st.EW;
			_rEditZ = st.Z;
			_rEditName = st.Text ?? "";
			break;
		case StepKind.Command:
			_rCmd = st.Text ?? "";
			_rCmdWait = st.WaitMs;
			break;
		case StepKind.Wait:
			_rWaitSecs = Math.Max(0, (st.WaitMs + 500) / 1000);
			break;
		case StepKind.PlayerSkip:
			_rSkipM = (int)SkipRange(st);
			_rSkipN = Math.Max(1, st.Count);
			_rSkipNoMobs = SkipNoMobs(st);
			break;
		case StepKind.Toggle:
			_rToggle = Math.Max(0, Array.IndexOf(ToggleTexts, (st.Text ?? "").ToLowerInvariant()));
			break;
		case StepKind.ChatWait:
			_rChat = st.Text ?? "";
			_rChatOp = Math.Max(0, Array.IndexOf(ChatOps, st.Op));
			break;
		case StepKind.ItemCheck:
			_rItem = st.Text ?? "";
			_rItemOp = Math.Max(0, Array.IndexOf(ItemOps, st.Op));
			_rItemNum = st.Count;
			break;
		case StepKind.Vendor:
			_rVendorNpc = st.Text ?? "";
			_rVendorProfile = st.Profile ?? "";
			break;
		case StepKind.UseItem:
			_rGem = st.Text ?? "";
			_rGemWait = Math.Max(1, (st.WaitMs + 500) / 1000);
			break;
		case StepKind.Cast:
		{
			if (_recalls == null)
			{
				_recalls = KnownRecalls();
			}
			int.TryParse(st.Text, out var sp);
			_rRecallPick = Math.Max(0, _recalls.FindIndex((KeyValuePair<int, string> kv) => kv.Key == sp));
			break;
		}
		case StepKind.GoRoute:
		{
			List<string> list2 = OtherRoutes(r);
			int num = list2.FindIndex((string n) => string.Equals(n, st.Text, StringComparison.OrdinalIgnoreCase));
			if (num < 0)
			{
				Util.WriteToChat("Nav: the route \"" + st.Text + "\" isn't there any more - pick another in the Go to route row.");
				num = 0;
			}
			_rGoPick = num;
			_rGoWhere = ((st.Op == "nearest") ? 1 : 0);
			break;
		}
		case StepKind.Preset:
		{
			List<string> list = NavPresets.Names();
			_rPresetPick = Math.Max(0, list.FindIndex((string n) => string.Equals(n, st.Text, StringComparison.OrdinalIgnoreCase)));
			break;
		}
		case StepKind.LoopEnd:
			Util.WriteToChat("Nav: a loop end's conditions are edited under the list when it's selected.");
			return;
		default:
			Util.WriteToChat("Nav: there's nothing to change on a " + KindName(st.Kind) + " step.");
			return;
		}
		_rEdit = st;
	}

	private void ApplyEdit(NavRoute r, RouteStep st)
	{
		switch (st.Kind)
		{
		case StepKind.Point:
			st.NS = _rEditNS;
			st.EW = _rEditEW;
			st.Z = _rEditZ;
			break;
		case StepKind.Use:
			st.NS = _rEditNS;
			st.EW = _rEditEW;
			st.Z = _rEditZ;
			if (_rEditName.Trim().Length > 0)
			{
				st.Text = _rEditName.Trim();
			}
			break;
		case StepKind.Command:
			if (_rCmd.Trim().Length > 0)
			{
				st.Text = _rCmd.Trim();
			}
			st.WaitMs = _rCmdWait;
			_rCmd = "";
			break;
		case StepKind.Wait:
			st.WaitMs = _rWaitSecs * 1000;
			break;
		case StepKind.PlayerSkip:
			st.Text = _rSkipM.ToString(CultureInfo.InvariantCulture);
			st.Count = _rSkipN;
			st.Op = (_rSkipNoMobs ? "nomobs" : "");
			break;
		case StepKind.Toggle:
			st.Text = ToggleTexts[_rToggle];
			break;
		case StepKind.ChatWait:
			if (_rChat.Trim().Length > 0)
			{
				st.Text = _rChat.Trim();
			}
			st.Op = ChatOps[_rChatOp];
			_rChat = "";
			break;
		case StepKind.ItemCheck:
			if (_rItem.Trim().Length > 0)
			{
				st.Text = _rItem.Trim();
			}
			st.Op = ItemOps[_rItemOp];
			st.Count = _rItemNum;
			break;
		case StepKind.Vendor:
			if (_rVendorNpc.Trim().Length > 0)
			{
				st.Text = _rVendorNpc.Trim();
			}
			st.Profile = _rVendorProfile.Trim();
			break;
		case StepKind.UseItem:
			if (_rGem.Trim().Length > 0)
			{
				st.Text = _rGem.Trim();
			}
			st.WaitMs = _rGemWait * 1000;
			break;
		case StepKind.Cast:
			if (_recalls != null && _rRecallPick >= 0 && _rRecallPick < _recalls.Count)
			{
				st.Text = _recalls[_rRecallPick].Key.ToString();
			}
			break;
		case StepKind.Preset:
		{
			List<string> list2 = NavPresets.Names();
			if (_rPresetPick >= 0 && _rPresetPick < list2.Count)
			{
				st.Text = list2[_rPresetPick];
			}
			break;
		}
		case StepKind.GoRoute:
		{
			List<string> list = OtherRoutes(r);
			if (_rGoPick >= 0 && _rGoPick < list.Count)
			{
				st.Text = list[_rGoPick];
			}
			st.Op = ((_rGoWhere == 1) ? "nearest" : "start");
			break;
		}
		case StepKind.LoopStart:
		case StepKind.LoopEnd:
			break;
		}
	}

	private bool DrawAddRows(NavRoute r, bool preset = false)
	{
		bool flag = false;
		flag |= DrawEditRow(r);
		if (!preset)
		{
			flag |= DrawPresetRow(r);
		}
		if (!preset)
		{
			if (AddButton("Add point here"))
			{
				RouteStep routeStep = NewPointHere(StepKind.Point);
				Insert(r, routeStep);
				if (_recording && routeStep != null)
				{
					_recNS = routeStep.NS;
					_recEW = routeStep.EW;
				}
				flag = true;
			}
			Tip("Where you're standing. New steps go after the selected step (click a row), or at the end.");
			ImGui.SameLine();
			if (!_recording)
			{
				if (ImGui.Button("Record##rrec", new System.Numerics.Vector2(80f, 0f)))
				{
					StartRecording(r);
					flag = true;
				}
				Tip("Walk the way yourself: a point is added every so many metres as you move\n(after the selected step, or at the end). Click Stop when you're there.");
			}
			else
			{
				ImGui.PushStyleColor(ImGuiCol.Button, new System.Numerics.Vector4(0.7f, 0.15f, 0.15f, 1f));
				if (ImGui.Button("Stop##rrec", new System.Numerics.Vector2(80f, 0f)))
				{
					StopRecording();
					flag = true;
				}
				ImGui.PopStyleColor();
			}
			ImGui.SameLine();
			ImGui.SetNextItemWidth(90f);
			ImGui.InputFloat("m apart##rrecm", ref _recEvery, 1f, 5f, "%.0f");
			if (_recEvery < 2f)
			{
				_recEvery = 2f;
			}
			if (_recEvery > 100f)
			{
				_recEvery = 100f;
			}
			if (_recording)
			{
				ImGui.SameLine();
				Im.TextColored(Yellow, "recording...");
			}
			if (AddButton("Add portal / NPC"))
			{
				RouteStep routeStep2 = UseStepFromSelection();
				if (routeStep2 != null)
				{
					Insert(r, routeStep2);
					flag = true;
				}
			}
			Tip("Select it in the world first. When the route gets here it's used (the game walks you to it);\nfor a portal the route carries on on the other side.");
			ImGui.SameLine();
			Im.TextColored(Grey, "the portal or NPC you have selected");
			if (AddButton("Add loop start"))
			{
				Insert(r, new RouteStep
				{
					Kind = StepKind.LoopStart
				});
				flag = true;
			}
			Tip("Steps above this are done once; the steps below it repeat (back and forth or round and round).");
			ImGui.SameLine();
			if (ImGui.Button("Add loop end", new System.Numerics.Vector2(150f, 0f)))
			{
				Insert(r, new RouteStep
				{
					Kind = StepKind.LoopEnd
				});
				flag = true;
			}
			Tip("Closes the loop. Select it to give it conditions - e.g. Invoking Stone >= 30 - and the route goes round\nuntil they're all true, then carries on with the steps after it (walk back, turn in, go to the next route).\nSteps after a loop end run once; the route then finishes unless it ends with a Go to route step.");
		}
		List<string> list = OtherRoutes(r);
		if (list.Count > 0)
		{
			if (_rGoPick >= list.Count)
			{
				_rGoPick = 0;
			}
			if (AddButton("Add go to route"))
			{
				Insert(r, new RouteStep
				{
					Kind = StepKind.GoRoute,
					Text = list[_rGoPick],
					Op = ((_rGoWhere == 1) ? "nearest" : "start")
				});
				flag = true;
			}
			Tip("Switches to that route when it gets here - e.g. the last step of Temple North: go to Temple SE.");
			ImGui.SameLine();
			ImGui.SetNextItemWidth(200f);
			ImGui.Combo("##rgoroute", ref _rGoPick, list.ToArray(), list.Count);
			ImGui.SameLine();
			ImGui.SetNextItemWidth(150f);
			ImGui.Combo("##rgowhere", ref _rGoWhere, GoWhere, GoWhere.Length);
		}
		if (AddButton("Add command") && _rCmd.Trim().Length > 0)
		{
			Insert(r, new RouteStep
			{
				Kind = StepKind.Command,
				Text = _rCmd.Trim(),
				WaitMs = _rCmdWait
			});
			_rCmd = "";
			flag = true;
		}
		Tip("Any chat command, e.g. /ub jumpsw 0 100 (shift-jump forward), sent as if you typed it - then the route waits this long.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(260f);
		ImGui.InputText("##rcmd", ref _rCmd, 200u);
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		ImGui.InputInt("ms##rcmdwait", ref _rCmdWait, 100, 500);
		if (_rCmdWait < 0)
		{
			_rCmdWait = 0;
		}
		if (AddButton("Add wait"))
		{
			Insert(r, new RouteStep
			{
				Kind = StepKind.Wait,
				WaitMs = _rWaitSecs * 1000
			});
			flag = true;
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		ImGui.InputInt("seconds##rwait", ref _rWaitSecs, 1, 5);
		if (_rWaitSecs < 0)
		{
			_rWaitSecs = 0;
		}
		if (AddButton("Add player skip"))
		{
			Insert(r, new RouteStep
			{
				Kind = StepKind.PlayerSkip,
				Text = _rSkipM.ToString(CultureInfo.InvariantCulture),
				Count = _rSkipN,
				Op = (_rSkipNoMobs ? "nomobs" : "")
			});
			flag = true;
		}
		Tip("When another player is within this many metres as the route gets here, the next steps are skipped -\ne.g. before a Combat ON / Wait / Combat OFF at a mob group: someone's there, so it goes straight on.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		ImGui.InputInt("m within, skip##rskipm", ref _rSkipM, 5, 10);
		if (_rSkipM < 1)
		{
			_rSkipM = 1;
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		ImGui.InputInt("steps##rskipn", ref _rSkipN, 1, 1);
		if (_rSkipN < 1)
		{
			_rSkipN = 1;
		}
		ImGui.SameLine();
		ImGui.Checkbox("or no monsters in combat range##rskipnomobs", ref _rSkipNoMobs);
		Tip("Also skip those steps when there isn't a monster within combat range as the route gets here\n(nothing to fight at that group - go straight on).");
		if (AddButton("Add switch"))
		{
			Insert(r, new RouteStep
			{
				Kind = StepKind.Toggle,
				Text = ToggleTexts[_rToggle]
			});
			flag = true;
		}
		Tip("Turns combat, looting or pet summoning on or off when the route gets here - e.g. combat and summoning off\nwhile travelling, all on at the hunting spot (put it just before the loop start).\nDoors: opening (and picking) doors in the way on or off - e.g. on for a dungeon, off outside.\nReset session: the session's numbers (kills, loot, XP / lum per hour) start over here - put it just before\nthe loop start, so the trip there isn't counted (inside the loop it would reset every lap).");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(150f);
		ImGui.Combo("##rtoggle", ref _rToggle, ToggleNames, ToggleNames.Length);
		if (AddButton("Add chat wait") && _rChat.Trim().Length > 0)
		{
			Insert(r, new RouteStep
			{
				Kind = StepKind.ChatWait,
				Text = _rChat.Trim(),
				Op = ChatOps[_rChatOp]
			});
			_rChat = "";
			flag = true;
		}
		Tip("The route stops here until a chat line matches (not case sensitive):\n  contains - the text is anywhere in the line\n  = - the whole line is exactly the text\nLines that came in during the step before count too, so a command's reply isn't missed.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(260f);
		ImGui.InputText("##rchat", ref _rChat, 200u);
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		ImGui.Combo("##rchatop", ref _rChatOp, ChatOps, ChatOps.Length);
		if (AddButton("Add item check") && _rItem.Trim().Length > 0)
		{
			Insert(r, new RouteStep
			{
				Kind = StepKind.ItemCheck,
				Text = _rItem.Trim(),
				Op = ItemOps[_rItemOp],
				Count = _rItemNum
			});
			flag = true;
		}
		Tip("The route stops here until the count of that item in your packs makes this true - e.g. Invoking Stone >= 30.\nStacks are counted. Exact name first; if you have none by that exact name, any item whose name contains it.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(220f);
		ImGui.InputText("##ritem", ref _rItem, 120u);
		ImGui.SameLine();
		if (ImGui.SmallButton("sel##ritemsel"))
		{
			try
			{
				WorldObject worldObject = Globals.Core.WorldFilter[Globals.Core.Actions.CurrentSelection];
				if (worldObject != null)
				{
					_rItem = worldObject.Name;
				}
			}
			catch
			{
			}
		}
		Tip("Use the name of the item you have selected.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(60f);
		ImGui.Combo("##ritemop", ref _rItemOp, ItemOps, ItemOps.Length);
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		ImGui.InputInt("##ritemnum", ref _rItemNum, 1, 10);
		if (_rItemNum < 0)
		{
			_rItemNum = 0;
		}
		List<string> list2 = PackGems();
		if (_rGem.Length > 0 && !list2.Contains(_rGem))
		{
			list2.Insert(0, _rGem);
		}
		if (AddButton("Add use item") && _rGem.Trim().Length > 0)
		{
			Insert(r, new RouteStep
			{
				Kind = StepKind.UseItem,
				Text = _rGem.Trim(),
				WaitMs = _rGemWait * 1000
			});
			flag = true;
		}
		Tip("Uses an item from your packs when the route gets here - a portal gem, a buff gem ... - like double-clicking it.\nThe route goes on as soon as you portal, or after the seconds set here. The list shows the gems you carry;\n\"sel\" takes the item you have selected instead.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(220f);
		if (ImGui.BeginCombo("##rgem", (_rGem.Length > 0) ? _rGem : "(pick a gem)"))
		{
			if (list2.Count == 0)
			{
				Im.TextColored(Grey, "No gems in your packs - select an item and click sel");
			}
			foreach (string item in list2)
			{
				if (ImGui.Selectable(item, item == _rGem))
				{
					_rGem = item;
				}
			}
			ImGui.EndCombo();
		}
		ImGui.SameLine();
		if (ImGui.SmallButton("sel##rgemsel"))
		{
			try
			{
				WorldObject worldObject2 = Globals.Core.WorldFilter[Globals.Core.Actions.CurrentSelection];
				if (worldObject2 != null)
				{
					_rGem = worldObject2.Name;
				}
			}
			catch
			{
			}
		}
		Tip("Use the item you have selected.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		ImGui.InputInt("s max##rgemwait", ref _rGemWait, 1, 5);
		if (_rGemWait < 1)
		{
			_rGemWait = 1;
		}
		if (AddButton("Add vendor") && _rVendorNpc.Trim().Length > 0)
		{
			Insert(r, new RouteStep
			{
				Kind = StepKind.Vendor,
				Text = _rVendorNpc.Trim(),
				Profile = _rVendorProfile.Trim()
			});
			flag = true;
		}
		Tip("A whole vendor visit (Items > Vendor): opens the NPC's shop, sells what the profile's Sell rules catch, makes the money up\n(trade notes off Infinite Leaftide), buys up to each Keep-up-to count, banks the change, and says how it went.\nThe route goes on once the visit is done. The NPC is found by its exact name, nearest first; \"sel\" takes your selection.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(220f);
		ImGui.InputText("##rvendnpc", ref _rVendorNpc, 120u);
		Tip("The vendor's exact name.");
		ImGui.SameLine();
		if (ImGui.SmallButton("sel##rvendsel"))
		{
			try
			{
				WorldObject worldObject3 = Globals.Core.WorldFilter[Globals.Core.Actions.CurrentSelection];
				if (worldObject3 != null)
				{
					_rVendorNpc = worldObject3.Name;
				}
			}
			catch
			{
			}
		}
		Tip("Use the NPC you have selected.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(180f);
		if (ImGui.BeginCombo("##rvendprof", (_rVendorProfile.Length > 0) ? _rVendorProfile : "(named after the vendor)"))
		{
			if (ImGui.Selectable("(named after the vendor)", _rVendorProfile.Length == 0))
			{
				_rVendorProfile = "";
			}
			foreach (string item3 in (VendorRun.I != null) ? VendorRun.I.ProfileNames() : new List<string>())
			{
				if (ImGui.Selectable(item3, item3 == _rVendorProfile))
				{
					_rVendorProfile = item3;
				}
			}
			ImGui.EndCombo();
		}
		Tip("The vendor profile to use (Items > Vendor makes them). Left as \"named after the vendor\", the one called after\nthe NPC is used - this character's first, then this server's, then everyone's.");
		if (_recalls == null)
		{
			_recalls = KnownRecalls();
		}
		if (AddButton("Add recall") && _recalls.Count > 0 && _rRecallPick >= 0 && _rRecallPick < _recalls.Count)
		{
			Insert(r, new RouteStep
			{
				Kind = StepKind.Cast,
				Text = _recalls[_rRecallPick].Key.ToString()
			});
			flag = true;
		}
		Tip("Casts a recall / portal spell when the route gets here (switching to magic mode first), and carries on\non the other side - or after 20 s if it didn't take you anywhere. The list is the ones this character knows.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(260f);
		string text = ((_recalls.Count == 0) ? "(none known)" : _recalls[Math.Min(_rRecallPick, _recalls.Count - 1)].Value);
		if (ImGui.BeginCombo("##rrecall", text, ImGuiComboFlags.HeightLarge))
		{
			for (int i = 0; i < _recalls.Count; i++)
			{
				if (ImGui.Selectable(_recalls[i].Value + "##rc" + i, i == _rRecallPick))
				{
					_rRecallPick = i;
				}
			}
			ImGui.EndCombo();
		}
		ImGui.SameLine();
		if (ImGui.SmallButton("refresh##rrecallre"))
		{
			_recalls = KnownRecalls();
		}
		Tip("Read the known spells again (after learning a new recall).");
		return flag;
	}
}
