using System;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Reflection;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Pets;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public class MiniHud : IDisposable
{
	private readonly Hud _hud;

	private readonly Settings _s;

	private readonly CombatEngine _engine;

	private readonly Action _saveAll;

	private readonly Action<bool> _onBufferToggled;

	private readonly Action<bool> _onPetToggled;

	private static readonly Vector4 Green = new Vector4(0.15f, 0.55f, 0.2f, 1f);

	private static readonly Vector4 Red = new Vector4(0.55f, 0.15f, 0.15f, 1f);

	private static readonly Vector4 Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f);

	private static readonly Vector4 Gold = new Vector4(0.95f, 0.8f, 0.3f, 1f);

	private bool _shown;

	private bool _resetPos;

	private bool _restored;



	private MethodInfo _petStatus;

	private DateTime _petLookAt = DateTime.MinValue;

	private static string PosFile => Util.FullPath("MelkTank_Mini.txt");

	public MiniHud(Settings s, CombatEngine engine, Action saveAll, Action<bool> onBufferToggled, Action<bool> onPetToggled)
	{
		_s = s;
		_engine = engine;
		_saveAll = saveAll;
		_onBufferToggled = onBufferToggled;
		_onPetToggled = onPetToggled;
		_hud = UBService.Huds.CreateHud("MelkTank Mini", BarIcon.Make("Mini"));
		_hud.ShowInBar = true;
		_hud.WindowSettings = ImGuiWindowFlags.NoTitleBar | ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoCollapse | ImGuiWindowFlags.AlwaysAutoResize;
		_hud.OnPreRender += OnPreRender;
		_hud.OnRender += OnRender;
		_hud.Visible = s.MiniShow;
		_shown = s.MiniShow;
	}

	public void Sync()
	{
		bool flag = false;
		try
		{
			flag = _hud.Visible;
		}
		catch
		{
			return;
		}
		if (_s.MiniShow != _shown)
		{
			_shown = _s.MiniShow;
			try
			{
				_hud.Visible = _shown;
				return;
			}
			catch
			{
				return;
			}
		}
		if (flag != _shown)
		{
			_shown = flag;
			_s.MiniShow = flag;
			if (_saveAll != null)
			{
				_saveAll();
			}
		}
	}

	public void ResetPosition()
	{
		_resetPos = true;
		_s.MiniShow = true;
		try
		{
			File.Delete(PosFile);
		}
		catch
		{
		}
	}

	public void Dispose()
	{
		try
		{
			_hud.OnPreRender -= OnPreRender;
			_hud.OnRender -= OnRender;
			_hud.Dispose();
		}
		catch
		{
		}
	}

	private void OnPreRender(object sender, EventArgs e)
	{
		if (_resetPos)
		{
			_resetPos = false;
			_restored = true;
			ImGui.SetNextWindowPos(new Vector2(120f, 120f), ImGuiCond.Always);
		}
		else
		{
			if (_restored)
			{
				return;
			}
			_restored = true;
			try
			{
				if (File.Exists(PosFile))
				{
					string[] array = File.ReadAllText(PosFile).Trim().Split('|');
					if (array.Length == 2 && float.TryParse(array[0], NumberStyles.Float, CultureInfo.InvariantCulture, out var result) && float.TryParse(array[1], NumberStyles.Float, CultureInfo.InvariantCulture, out var result2))
					{
						ImGui.SetNextWindowPos(new Vector2(result, result2), ImGuiCond.Always);
					}
				}
			}
			catch
			{
			}
		}
	}


	private void OnRender(object sender, EventArgs e)
	{
		long t = Perf.Begin();
		try
		{
			OnRenderInner(sender, e);
		}
		finally
		{
			Perf.Lap("Window: mini panel", t);
		}
	}

	private void OnRenderInner(object sender, EventArgs e)
	{
		try
		{
			WinMem.Frame("Mini", size: false);
			bool flag = false;
			float offset_from_start_x = ImGui.GetStyle().WindowPadding.X + ImGui.GetFrameHeight() + ImGui.GetStyle().ItemInnerSpacing.X + ImGui.CalcTextSize("Summon").X + 14f;
			bool v = _s.MasterEnabled;
			ImGui.PushStyleColor(ImGuiCol.Text, v ? new Vector4(0.45f, 0.9f, 0.45f, 1f) : new Vector4(1f, 0.45f, 0.45f, 1f));
			if (ImGui.Checkbox("MelkTank", ref v))
			{
				SetMaster(v);
				flag = true;
			}
			ImGui.PopStyleColor();
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Off stops everything: combat, healing, looting, and switches the buffer and pet summoner off.\nOn puts back whatever is ticked below.");
			}
			ImGui.SameLine(offset_from_start_x);
			bool flag2 = _engine.FocusId != 0;
			if (flag2)
			{
				ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(0.6f, 0.45f, 0.1f, 1f));
			}
			if (ImGui.Button(flag2 ? "Focused##mhfocus" : "Focus selected##mhfocus"))
			{
				int num = 0;
				try
				{
					num = Globals.Core.Actions.CurrentSelection;
				}
				catch
				{
				}
				WorldObject worldObject = null;
				try
				{
					worldObject = ((num != 0) ? Globals.Core.WorldFilter[num] : null);
				}
				catch
				{
				}
				if (worldObject != null && worldObject.ObjectClass == ObjectClass.Monster)
				{
					_engine.SetFocus(num);
				}
				else if (flag2)
				{
					_engine.SetFocus(0);
				}
				else
				{
					Util.WriteToChat("Focus: select a monster first.");
				}
			}
			if (flag2)
			{
				ImGui.PopStyleColor();
			}
			if (ImGui.IsItemHovered())
			{
				string text = "";
				try
				{
					WorldObject worldObject2 = (flag2 ? Globals.Core.WorldFilter[_engine.FocusId] : null);
					if (worldObject2 != null)
					{
						text = worldObject2.Name;
					}
				}
				catch
				{
				}
				Im.SetTooltip(flag2 ? ("Focus: " + text + " - debuffed and attacked first until it dies.\nClick again (with it or nothing selected) to clear it, or select another monster to switch.") : "Select a monster, then click: it's debuffed and attacked first until it dies.");
			}
			if (!_s.MasterEnabled)
			{
				ImGui.PushStyleVar(ImGuiStyleVar.Alpha, 0.5f);
			}
			bool v2 = _s.MelksBufferEnabled;
			if (ImGui.Checkbox("Buff", ref v2))
			{
				_s.MelksBufferEnabled = v2;
				if (_s.MasterEnabled)
				{
					_onBufferToggled(v2);
				}
				flag = true;
			}
			Im.SetTooltipIfHovered("/mt buff on|off  -  /mt rebuff rebuffs now");
			ImGui.SameLine(offset_from_start_x);
			flag |= ImGui.Checkbox("Combat", ref _s.CombatEnabled);
			Im.SetTooltipIfHovered("/mt set CombatEnabled on|off");
			if (!_s.CombatEnabled)
			{
				_engine.ReleaseNav();
			}
			int num2 = _engine.MobsInRangeCount();
			ImGui.SameLine(0f, 4f);
			Im.TextColored((num2 > 0) ? Gold : Grey, "(" + num2 + ")");
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip(num2 + " monster" + ((num2 == 1) ? "" : "s") + " in attack range.");
			}
			bool v3 = _s.MelksPetEnabled;
			if (ImGui.Checkbox("Summon", ref v3))
			{
				_s.MelksPetEnabled = v3;
				if (_s.MasterEnabled)
				{
					_onPetToggled(v3);
				}
				flag = true;
			}
			Im.SetTooltipIfHovered("/mt summon on|off");
			string text2 = PetStatus();
			if (text2.Length > 0)
			{
				ImGui.SameLine(offset_from_start_x);
				bool flag3 = text2.EndsWith(" IW");
				Vector4 col;
				if (text2 == "Off")
				{
					col = Grey;
				}
				else
				{
					col = (flag3 ? new Vector4(0.45f, 0.9f, 0.45f, 1f) : Gold);
				}
				Im.TextColored(col, text2);
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip("Pet summoner: the element it would summon for now (None = no monsters in its range,\nAny = no preference), and whether a pet is out - IW in world, Aw away.");
				}
			}
			flag |= ImGui.Checkbox("Nav", ref _s.NavEnabled);
			Im.SetTooltipIfHovered("/mt set NavEnabled on|off");
			if (ImGui.IsItemHovered())
			{
				if (_s.NavMode == 1)
				{
					NavRoute currentRoute = _engine.Nav.CurrentRoute;
					Im.SetTooltip((currentRoute != null) ? ("Follow the route " + currentRoute.Name + " (" + currentRoute.Steps.Count + " steps)" + (_engine.Nav.IsMetaRoute(currentRoute) ? " - loaded by the meta" : "") + ".") : "Follow a route - none selected (Nav > Routes).");
				}
				else
				{
					Im.SetTooltip("Return to the selected Nav spot" + ((_engine.Nav.Current != null) ? (" (" + _engine.Nav.Current.Name + ")") : " - none saved yet") + ".");
				}
			}
			if (!_s.NavEnabled)
			{
				_engine.Nav.Stop();
			}
			ImGui.SameLine(offset_from_start_x);
			bool v4 = _s.LootEnabled;
			if (ImGui.Checkbox("Loot", ref v4))
			{
				_s.LootEnabled = v4;
				if (!v4)
				{
					_engine.Looter.Abort("off");
				}
				flag = true;
			}
			Im.SetTooltipIfHovered("/mt loot on|off");
			int num3 = _engine.Looter.UnlootedInRange();
			ImGui.SameLine(0f, 4f);
			Im.TextColored((num3 > 0) ? Gold : Grey, "(" + num3 + ")");
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip(num3 + " corpse" + ((num3 == 1) ? "" : "s") + " in corpse range not looted yet.");
			}
			if (_engine.Looter.PacksFull)
			{
				ImGui.SameLine(0f, 4f);
				Im.TextColored(new Vector4(0.95f, 0.35f, 0.35f, 1f), "FULL");
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip("Your main pack and every side pack are full - nothing more can be looted.");
				}
			}
			bool v5 = _engine.Nav.MetaRunning;
			bool flag4 = _engine.Nav.CurrentMeta != null;
			if (ImGui.Checkbox("Meta", ref v5))
			{
				if (v5 & flag4)
				{
					_engine.Nav.MetaStart();
				}
				else if (!v5)
				{
					_engine.Nav.MetaStop();
				}
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip((flag4 ? ("Run the meta " + _engine.Nav.CurrentMeta.Name + " (Nav > Meta).") : "No meta open - load one in Nav > Settings > Meta files.") + "\n/mt meta on|off  -  /mt meta load <name>  -  /mt meta state <name>");
			}
			ImGui.SameLine(0f, 6f);
			string text3;
			if (flag4)
			{
				text3 = (v5 ? _engine.Nav.MetaCurState : _engine.Nav.CurrentMeta.Name);
			}
			else
			{
				text3 = "none open";
			}
			if (text3.Length > 22)
			{
				text3 = text3.Substring(0, 21) + "…";
			}
			Im.TextColored(v5 ? new Vector4(0.45f, 0.9f, 0.45f, 1f) : Grey, text3);
			if (ImGui.IsItemHovered() & flag4)
			{
				Im.SetTooltip(v5 ? (_engine.Nav.CurrentMeta.Name + " - in state " + _engine.Nav.MetaCurState) : (_engine.Nav.CurrentMeta.Name + " (not running)"));
			}
			if (!_s.MasterEnabled)
			{
				ImGui.PopStyleVar();
			}
			string text4 = _engine.Status ?? "";
			if (text4.Length > 26)
			{
				text4 = text4.Substring(0, 25) + "…";
			}
			Im.TextColored(Grey, text4);
			if (flag)
			{
				_saveAll();
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private string PetStatus()
	{
		if (!PetSummoner.ExternalLoaded)
		{
			return PetSummoner.TankStatus();
		}
		try
		{
			if (_petStatus == null)
			{
				if ((DateTime.Now - _petLookAt).TotalSeconds < 30.0)
				{
					return "";
				}
				_petLookAt = DateTime.Now;
				Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
				foreach (Assembly assembly in assemblies)
				{
					Type type = assembly.GetType("MelksPetSummoner.PluginCore");
					if (!(type == null))
					{
						_petStatus = type.GetMethod("TankStatus", BindingFlags.Static | BindingFlags.Public);
						break;
					}
				}
				if (_petStatus == null)
				{
					return "";
				}
			}
			return (_petStatus.Invoke(null, null) as string) ?? "";
		}
		catch
		{
			return "";
		}
	}

	public void SetMaster(bool on)
	{
		_s.MasterEnabled = on;
		if (!on)
		{
			_engine.ReleaseNav();
			_engine.Looter.Abort("MelkTank off");
			if (_s.MelksBufferEnabled)
			{
				_onBufferToggled(obj: false);
			}
			_engine.Buffer.StopIfRunning();
			if (_s.MelksPetEnabled)
			{
				_onPetToggled(obj: false);
			}
		}
		else
		{
			if (_s.MelksBufferEnabled)
			{
				_onBufferToggled(obj: true);
			}
			if (_s.MelksPetEnabled)
			{
				_onPetToggled(obj: true);
			}
		}
		Util.WriteToChat("MelkTank " + (on ? "ON." : "OFF - combat, healing, looting, buffing and summoning stopped."));
	}
}
