using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
#if !RETAIL
using ACGodot.DecalShim;
using ACGodot.Plugins;
using ACGodot.UI;
#endif
#if !RETAIL
using AcClient;
#else
using SmartBox = AcClient.SmartBox;
using ACCmdInterp = AcClient.ACCmdInterp;
using CommandInterpreter = AcClient.CommandInterpreter;
using CommandListElement = AcClient.CommandListElement;
using CPhysicsObj = AcClient.CPhysicsObj;
using Position = AcClient.Position;
using CTransition = AcClient.CTransition;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
#if !RETAIL
using Godot;
#endif
using ImGuiNET;
using MelkTank.Loot;
using MelkTank.Metas;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public partial class Nav
{
	private static bool SkipNoMobs(RouteStep st)
	{
		return st != null && string.Equals(st.Op, "nomobs", StringComparison.OrdinalIgnoreCase);
	}

	private static bool MonsterInCombatRange()
	{
		CombatEngine currentEngine = PluginCore.CurrentEngine;
		if (currentEngine == null)
		{
			return true;
		}
		double num = currentEngine.AttackRangeNow;
		foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
		{
			if (item.ObjectClass == ObjectClass.Monster && currentEngine.IsHostileMonster(item))
			{
				double num2 = CombatEngine.Distance(item);
				if (num2 >= 0.0 && num2 <= num)
				{
					return true;
				}
			}
		}
		return false;
	}

	private void OnStuck(NavRoute r)
	{
		string text = "step " + (_rIdx + 1);
		switch (r.StuckAction)
		{
		case 1:
			if (!_s.CombatEnabled)
			{
				_s.CombatEnabled = true;
				_rTempCombat = true;
				if (SaveAll != null)
				{
					SaveAll();
				}
				Util.WriteToChat("Nav: blocked on the way to " + text + " - combat on until I get there.");
			}
			_pauseUntil = DateTime.Now;
			break;
		case 2:
		{
			List<int> list = new List<int>();
			int num = _rIdx - 1;
			while (num >= 0 && list.Count < Math.Max(1, r.StuckBack))
			{
				if (r.Steps[num].Kind == StepKind.Point)
				{
					list.Add(num);
				}
				else if (r.Steps[num].Kind == StepKind.Use || r.Steps[num].Kind == StepKind.Cast || r.Steps[num].Kind == StepKind.GoRoute)
				{
					break;
				}
				num--;
			}
			if (list.Count == 0)
			{
				Util.WriteToChat("Nav: blocked on the way to " + text + " - no points behind to back up to, trying again.");
				break;
			}
			_rDetour.Clear();
			_rDetour.AddRange(list);
			for (int num2 = list.Count - 2; num2 >= 0; num2--)
			{
				_rDetour.Add(list[num2]);
			}
			_pauseUntil = DateTime.Now;
			Util.WriteToChat("Nav: blocked on the way to " + text + " - backing up " + list.Count + " point" + ((list.Count == 1) ? "" : "s") + " and coming again.");
			break;
		}
		case 3:
			RouteReset();
			_pauseUntil = DateTime.Now;
			Util.WriteToChat("Nav: blocked on the way to " + text + " - starting " + r.Name + " over.");
			break;
		case 4:
			Advance(r);
			_pauseUntil = DateTime.Now;
			Util.WriteToChat("Nav: blocked on the way to " + text + " - skipping it.");
			break;
		}
		L("route " + r.Name + " " + text + ": stuck -> " + StuckActions[Math.Max(0, Math.Min(StuckActions.Length - 1, r.StuckAction))]);
	}

	public string PhoneStatus()
	{
		try
		{
			if (!_s.NavEnabled)
			{
				return "Off";
			}
			if (_s.NavMode == 1)
			{
				NavRoute currentRoute = CurrentRoute;
				if (currentRoute == null || currentRoute.Steps.Count == 0)
				{
					return "Route: none picked";
				}
				if (_rDone)
				{
					return currentRoute.Name + " · finished";
				}
				if (_resumeNearest)
				{
					return currentRoute.Name + " · picks up at the nearest point when it moves on";
				}
				int num = Math.Max(0, Math.Min(currentRoute.Steps.Count - 1, _rIdx));
				string text = Status ?? "";
				int num2 = text.IndexOf(" - ", StringComparison.Ordinal);
				if (text.StartsWith("Route ") && num2 > 0)
				{
					text = text.Substring(num2 + 3);
				}
				if (_rDetour.Count > 0)
				{
					text = "backing up - " + text;
				}
				string text2 = KindName(currentRoute.Steps[num].Kind);
				string text3 = (num + 1).ToString();
				if (currentRoute.Steps[num].Kind == StepKind.Preset)
				{
					NavRoute navRoute = NavPresets.Find(currentRoute.Steps[num].Text);
					int num3 = SubNow();
					text3 = text3 + "." + (num3 + 1);
					text2 = currentRoute.Steps[num].Text + ((navRoute != null && num3 < navRoute.Steps.Count) ? (" · " + KindName(navRoute.Steps[num3].Kind)) : "");
				}
				return currentRoute.Name + " · step " + text3 + "/" + currentRoute.Steps.Count + " " + text2 + ((text.Length > 0) ? (" · " + text) : "");
			}
			if (_s.NavMode == 2)
			{
				return "Following" + ((Status != null && Status.Length > 0) ? (" · " + Status) : "");
			}
			NavSpot current = Current;
			if (current == null)
			{
				return "Spot: none picked";
			}
			double num4 = DistanceTo(current);
			return current.Name + " · " + ((num4 >= 0.0 && num4 <= (double)_s.NavDrift) ? "in position" : "not in position");
		}
		catch
		{
			return "";
		}
	}

	private void StartRecording(NavRoute r)
	{
		RouteStep routeStep = NewPointHere(StepKind.Point);
		if (routeStep != null)
		{
			Insert(r, routeStep);
			_recNS = routeStep.NS;
			_recEW = routeStep.EW;
			_recording = true;
			_recRoute = r.Name;
			Util.WriteToChat("Nav: recording " + r.Name + " - a point every " + _recEvery.ToString("0") + " m as you move. Stop it on the Routes tab.");
		}
	}

	private void StopRecording()
	{
		if (_recording)
		{
			_recording = false;
			if (SaveAll != null)
			{
				SaveAll();
			}
			Util.WriteToChat("Nav: recording stopped.");
		}
	}

	public void RecordTick()
	{
		if (!_recording || DateTime.Now < _recNext)
		{
			return;
		}
		_recNext = DateTime.Now.AddMilliseconds(250.0);
		NavRoute currentRoute = CurrentRoute;
		double ns;
		double ew;
		double z;
		if (currentRoute == null || currentRoute.Name != _recRoute)
		{
			StopRecording();
		}
		else if (MyPos(out ns, out ew, out z))
		{
			double num = (ns - _recNS) * 240.0;
			double num2 = (ew - _recEW) * 240.0;
			if (!(Math.Sqrt(num * num + num2 * num2) < (double)Math.Max(2f, _recEvery)))
			{
				Insert(currentRoute, new RouteStep
				{
					Kind = StepKind.Point,
					NS = ns,
					EW = ew,
					Z = z
				});
				_recNS = ns;
				_recEW = ew;
			}
		}
	}

	private void EndTempCombat()
	{
		if (!_rTempCombat)
		{
			return;
		}
		_rTempCombat = false;
		if (_s.CombatEnabled)
		{
			_s.CombatEnabled = false;
			if (SaveAll != null)
			{
				SaveAll();
			}
			Util.WriteToChat("Nav: through - combat off again.");
		}
	}

	public void OnChat(string text)
	{
		if (string.IsNullOrEmpty(text))
		{
			return;
		}
		DateTime now = DateTime.Now;
		lock (_chat)
		{
			_chat.Add(new KeyValuePair<DateTime, string>(now, text.Trim()));
			while (_chat.Count > 0 && ((now - _chat[0].Key).TotalSeconds > Tuning.V("ChatKeepS") || _chat.Count > 200))
			{
				_chat.RemoveAt(0);
			}
		}
		try
		{
			NavRoute currentRoute = CurrentRoute;
			int num = ((currentRoute != null) ? LoopEndIdx(currentRoute) : (-1));
			if (num < 0)
			{
				return;
			}
			foreach (LoopCond cond in currentRoute.Steps[num].Conds)
			{
				if (cond.Chat && !cond.Seen && ChatMatch(text.Trim(), cond.Text, cond.Op))
				{
					cond.Seen = true;
					L("route " + currentRoute.Name + ": loop-end chat seen: " + cond.Text);
				}
			}
		}
		catch
		{
		}
	}

	private static bool ChatMatch(string line, string want, string op)
	{
		want = (want ?? "").Trim();
		if (want.Length == 0)
		{
			return true;
		}
		return (op == "=") ? string.Equals(line, want, StringComparison.OrdinalIgnoreCase) : (line.IndexOf(want, StringComparison.OrdinalIgnoreCase) >= 0);
	}

	private static void ResetConds(NavRoute r)
	{
		if (r == null)
		{
			return;
		}
		foreach (RouteStep step in r.Steps)
		{
			foreach (LoopCond cond in step.Conds)
			{
				cond.Seen = false;
			}
		}
	}

	private static string CondText(LoopCond c)
	{
		return c.Chat ? ("chat " + c.Op + " \"" + c.Text + "\"" + (c.Seen ? " (seen)" : "")) : (c.Text + " " + c.Op + " " + c.Count + " (have " + InventoryCount(c.Text) + ")");
	}

	private static bool CondsMet(RouteStep st)
	{
		if (st.Conds.Count == 0)
		{
			return false;
		}
		foreach (LoopCond cond in st.Conds)
		{
			if (cond.Chat ? (!cond.Seen) : (!Compare(InventoryCount(cond.Text), cond.Op, cond.Count)))
			{
				return false;
			}
		}
		return true;
	}

	private static int LoopEndIdx(NavRoute r)
	{
		int val = LoopStart(r) + 1;
		for (int i = Math.Max(0, val); i < r.Steps.Count; i++)
		{
			if (r.Steps[i].Kind == StepKind.LoopEnd)
			{
				return i;
			}
		}
		return -1;
	}

	public static int NearestPoint(NavRoute r, Nav nav, out double dist)
	{
		int num = -1;
		double num2 = double.MaxValue;
		for (int i = 0; i < r.Steps.Count; i++)
		{
			RouteStep routeStep = r.Steps[i];
			if (routeStep.Kind == StepKind.Point)
			{
				double num3 = nav.DistanceTo(new NavSpot
				{
					NS = routeStep.NS,
					EW = routeStep.EW,
					Z = routeStep.Z
				});
				if (num3 >= 0.0 && num3 < num2)
				{
					num2 = num3;
					num = i;
				}
			}
		}
		int num4 = LoopStart(r);
		if (num4 >= 0 && num >= 0)
		{
			int num5 = LoopEndIdx(r);
			if (num5 < 0)
			{
				num5 = r.Steps.Count;
			}
			if (num < num4 || num > num5)
			{
				int num6 = -1;
				double num7 = double.MaxValue;
				for (int j = num4 + 1; j < num5; j++)
				{
					RouteStep routeStep2 = r.Steps[j];
					if (routeStep2.Kind == StepKind.Point)
					{
						double num8 = nav.DistanceTo(new NavSpot
						{
							NS = routeStep2.NS,
							EW = routeStep2.EW,
							Z = routeStep2.Z
						});
						if (num8 >= 0.0 && num8 < num7)
						{
							num7 = num8;
							num6 = j;
						}
					}
				}
				if (num6 >= 0 && num7 <= num2 + 10.0)
				{
					num = num6;
					num2 = num7;
				}
			}
		}
		dist = num2;
		return num;
	}

	private bool ChatSeen(RouteStep st, DateTime since)
	{
		string text = (st.Text ?? "").Trim();
		if (text.Length == 0)
		{
			return true;
		}
		bool flag = st.Op == "=";
		lock (_chat)
		{
			foreach (KeyValuePair<DateTime, string> item in _chat)
			{
				if (item.Key < since || !(flag ? string.Equals(item.Value, text, StringComparison.OrdinalIgnoreCase) : (item.Value.IndexOf(text, StringComparison.OrdinalIgnoreCase) >= 0)))
				{
					continue;
				}
				return true;
			}
		}
		return false;
	}

	public static int InventoryCount(string name)
	{
		name = (name ?? "").Trim();
		if (name.Length == 0)
		{
			return 0;
		}
		int num = 0;
		int num2 = 0;
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				string text = item.Name ?? "";
				int num3 = 1;
				try
				{
					num3 = item.Values(LongValueKey.StackCount);
				}
				catch
				{
				}
				if (num3 < 1)
				{
					num3 = 1;
				}
				if (string.Equals(text, name, StringComparison.OrdinalIgnoreCase))
				{
					num += num3;
				}
				else if (text.IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0)
				{
					num2 += num3;
				}
			}
		}
		catch
		{
		}
		return (num > 0) ? num : num2;
	}

	public static bool Compare(int have, string op, int want)
	{
		return op switch
		{
			"=" => have == want, 
			"!=" => have != want, 
			"<" => have < want, 
			">" => have > want, 
			"<=" => have <= want, 
			_ => have >= want, 
		};
	}

	public void StuckRestartTick()
	{
		DateTime now = DateTime.Now;
		double num = ((_rStuckLast == DateTime.MinValue) ? 0.0 : Math.Min(1.0, (now - _rStuckLast).TotalSeconds));
		_rStuckLast = now;
		NavRoute navRoute = ((_s.NavEnabled && _s.NavMode == 1 && _s.MasterEnabled) ? CurrentRoute : null);
		if (navRoute == null || _rDone || navRoute.Steps.Count == 0)
		{
			_rStuckAcc = 0.0;
			_rStuckStep = -1;
		}
		else if (StepKey() != _rStuckStep || navRoute.Name != _rStuckRoute)
		{
			_rStuckStep = StepKey();
			_rStuckRoute = navRoute.Name;
			_rStuckAcc = 0.0;
		}
		else if (!_inPortal && !((now - _portalExitAt).TotalSeconds < 3.0) && (!(_diedAt > _portalExitAt) || !((now - _diedAt).TotalSeconds < 60.0)) && !PluginCore.IsPaused && !((now - _rTickAt).TotalSeconds > 1.5))
		{
			_rStuckAcc += num;
			if (navRoute.RestartIfStuck && !(_rStuckAcc < (double)(navRoute.RestartStuckMin * 60f)))
			{
				string text = "step " + (_rIdx + 1) + "/" + navRoute.Steps.Count;
				L("route " + navRoute.Name + " " + text + ": stuck for " + navRoute.RestartStuckMin.ToString("0") + " min - starting over from step 1");
				Util.WriteToChat("Nav: " + navRoute.Name + " was stuck on " + text + " for " + navRoute.RestartStuckMin.ToString("0") + " min - starting over from step 1.");
				Stop();
				RouteReset();
				_rStuckAcc = 0.0;
				_rStuckStep = 0;
			}
		}
	}

	public void RouteReset()
	{
		_rSubFor = -1;
		_rSub = 0;
		_rDetour.Clear();
		_rStuckN = 0;
		_rStuckIdx = -1;
		ResetConds(CurrentRoute);
		_rIdx = 0;
		_rDir = 1;
		_rDone = false;
		_rStarted = false;
		_rUntil = DateTime.MinValue;
		_rUsedAt = DateTime.MinValue;
	}

	public void NotePortalExit()
	{
		MetaNotePortal(enter: false);
		_inPortal = false;
		_portalExitAt = DateTime.Now;
		if (_rUsedAt != DateTime.MinValue)
		{
			_rUsedAt = DateTime.MinValue.AddTicks(1L);
		}
	}

	public void NotePortalEnter()
	{
		MetaNotePortal(enter: true);
		_inPortal = true;
	}

	public void NoteDeath()
	{
		MetaNoteDeath();
		_diedAt = DateTime.Now;
		TravelStop("you died", finished: false);
	}

	private static int LoopStart(NavRoute r)
	{
		for (int i = 0; i < r.Steps.Count; i++)
		{
			if (r.Steps[i].Kind == StepKind.LoopStart)
			{
				return i;
			}
		}
		return -1;
	}

	public NavSpot RouteTarget()
	{
		NavRoute currentRoute = CurrentRoute;
		if (currentRoute == null || _rIdx < 0 || _rIdx >= currentRoute.Steps.Count)
		{
			return null;
		}
		RouteStep routeStep = currentRoute.Steps[_rIdx];
		if (routeStep.Kind != StepKind.Point && routeStep.Kind != StepKind.Use)
		{
			return null;
		}
		return new NavSpot
		{
			Name = currentRoute.Name + " #" + (_rIdx + 1),
			NS = routeStep.NS,
			EW = routeStep.EW,
			Z = routeStep.Z,
			Heading = -1.0,
			FaceHeading = false
		};
	}

	private int SubNow()
	{
		return (_rSubFor == _rIdx) ? _rSub : 0;
	}

	private int StepKey()
	{
		return _rIdx * 1000 + ((_rSubFor == _rIdx) ? (_rSub + 1) : 0);
	}

	private static double SkipRange(RouteStep st)
	{
		double result;
		return (double.TryParse(st.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out result) && result > 0.0) ? result : 20.0;
	}

	private static string NearestPlayer(out double dist)
	{
		dist = double.MaxValue;
		string result = null;
		try
		{
			int id = Globals.Core.CharacterFilter.Id;
			CoordsObject coordsObject = Globals.Core.WorldFilter[id]?.Coordinates();
			if (coordsObject == null)
			{
				return null;
			}
			foreach (WorldObject item in Globals.Core.WorldFilter.GetByObjectClass(ObjectClass.Player))
			{
				if (item.Id == id)
				{
					continue;
				}
				CoordsObject coordsObject2 = item.Coordinates();
				if (coordsObject2 != null)
				{
					double num = (coordsObject2.NorthSouth - coordsObject.NorthSouth) * 240.0;
					double num2 = (coordsObject2.EastWest - coordsObject.EastWest) * 240.0;
					double num3 = Math.Sqrt(num * num + num2 * num2);
					if (num3 < dist)
					{
						dist = num3;
						result = item.Name;
					}
				}
			}
		}
		catch
		{
		}
		return result;
	}

	private RouteStep StepNow(NavRoute r)
	{
		if (_rIdx < 0 || _rIdx >= r.Steps.Count)
		{
			return null;
		}
		RouteStep routeStep = r.Steps[_rIdx];
		if (routeStep.Kind == StepKind.Preset)
		{
			NavRoute navRoute = NavPresets.Find(routeStep.Text);
			int num = SubNow();
			if (navRoute != null && num >= 0 && num < navRoute.Steps.Count)
			{
				return navRoute.Steps[num];
			}
		}
		return routeStep;
	}

	private string SkipSteps(NavRoute r, int n)
	{
		int num = -1;
		int num2 = -1;
		int num3 = -1;
		int num4 = -1;
		for (int i = 0; i < n; i++)
		{
			RouteStep routeStep = StepNow(r);
			if (routeStep != null && routeStep.Kind == StepKind.Toggle)
			{
				string text = (routeStep.Text ?? "").ToLowerInvariant();
				int num5 = (text.EndsWith(" on") ? 1 : ((!text.EndsWith(" off")) ? (-1) : 0));
				if (num5 >= 0)
				{
					if (text.StartsWith("combat"))
					{
						num = num5;
					}
					else if (text.StartsWith("loot"))
					{
						num2 = num5;
					}
					else if (text.StartsWith("summon"))
					{
						num3 = num5;
					}
					else if (text.StartsWith("doors"))
					{
						num4 = num5;
					}
				}
			}
			Advance(r);
		}
		List<string> list = new List<string>();
		bool flag = false;
		if (num >= 0)
		{
			_rTempCombat = false;
			if (_s.CombatEnabled != (num == 1))
			{
				_s.CombatEnabled = num == 1;
				flag = true;
			}
			list.Add("combat " + ((num == 1) ? "on" : "off"));
		}
		if (num2 >= 0)
		{
			if (_s.LootEnabled != (num2 == 1))
			{
				_s.LootEnabled = num2 == 1;
				flag = true;
			}
			list.Add("looting " + ((num2 == 1) ? "on" : "off"));
		}
		if (num3 >= 0)
		{
			PluginCore.SetSummoningFromNav(num3 == 1);
			list.Add("summoning " + ((num3 == 1) ? "on" : "off"));
		}
		if (num4 >= 0)
		{
			if (_s.NavOpenDoors != (num4 == 1))
			{
				_s.NavOpenDoors = num4 == 1;
				flag = true;
			}
			list.Add("doors " + ((num4 == 1) ? "on" : "off"));
		}
		if (flag && SaveAll != null)
		{
			SaveAll();
		}
		return (list.Count > 0) ? (" (their switches still applied: " + string.Join(", ", list.ToArray()) + ")") : "";
	}

	private void Advance(NavRoute r)
	{
		_rUntil = DateTime.MinValue;
		_rUsedAt = DateTime.MinValue;
		_rStarted = false;
		_rPrevStepAt = _rStepAt;
		_rStepAt = DateTime.Now;
		if (_rIdx >= 0 && _rIdx < r.Steps.Count && r.Steps[_rIdx].Kind == StepKind.Preset)
		{
			NavRoute navRoute = NavPresets.Find(r.Steps[_rIdx].Text);
			int num = SubNow();
			if (navRoute != null && num + 1 < navRoute.Steps.Count)
			{
				_rSub = num + 1;
				_rSubFor = _rIdx;
				return;
			}
		}
		_rSubFor = -1;
		_rSub = 0;
		int count = r.Steps.Count;
		int num2 = LoopStart(r);
		int num3 = ((num2 >= 0) ? (num2 + 1) : 0);
		int num4 = LoopEndIdx(r);
		if (num4 >= 0)
		{
			if (_rIdx >= num4 || r.Mode != 1)
			{
				_rIdx++;
				if (_rIdx >= count)
				{
					_rDone = true;
					_farEndNoted = false;
					_rIdx = count - 1;
					L("route " + r.Name + " finished");
				}
				return;
			}
			_rIdx += _rDir;
			if (_rIdx < num3)
			{
				_rDir = 1;
				_rIdx = Math.Min(num4 - 1, num3 + 1);
				if (_rIdx < num3)
				{
					_rIdx = num3;
				}
			}
		}
		else if (r.Mode == 0)
		{
			_rIdx++;
			if (_rIdx >= count)
			{
				_rDone = true;
				_farEndNoted = false;
				_rIdx = count - 1;
				L("route " + r.Name + " finished");
			}
		}
		else if (r.Mode == 2)
		{
			_rIdx++;
			if (_rIdx >= count)
			{
				_rIdx = num3;
			}
		}
		else
		{
			_rIdx += _rDir;
			if (_rIdx >= count)
			{
				_rDir = -1;
				_rIdx = Math.Max(num3, count - 2);
			}
			else if (_rIdx < num3)
			{
				_rDir = 1;
				_rIdx = Math.Min(count - 1, num3 + 1);
			}
		}
	}
}
