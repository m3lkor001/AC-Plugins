using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using MelkTank.Metas;
using AcClient;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Bounties;
using MelkTank.Buffs;

namespace MelkTank;

public static partial class Session
{
	public static void Draw()
	{
		if (ImGui.BeginTabBar("sessiontabs"))
		{
			bool ilt = ServerMode.Ilt;
			if (ImGui.BeginTabItem("Main"))
			{
				DrawMain();
				ImGui.EndTabItem();
			}
			if (ilt && ImGui.BeginTabItem("Bounties"))
			{
				DrawBounties();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Kills"))
			{
				DrawKills(Cur, _curSort, "sesskills", "No kills yet this session.");
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("All Time"))
			{
				DrawAllTime();
				ImGui.EndTabItem();
			}
			if (ilt && ImGui.BeginTabItem("Lum"))
			{
				LumTrack.Draw();
				ImGui.EndTabItem();
			}
			if (ilt && ImGui.BeginTabItem("Bank"))
			{
				DrawBank();
				ImGui.EndTabItem();
			}
			if (ilt && ImGui.BeginTabItem("Augs"))
			{
				DrawAugsTabs();
				ImGui.EndTabItem();
			}
			if (ilt && ImGui.BeginTabItem("Attr"))
			{
				DrawAttr();
				ImGui.EndTabItem();
			}
			if (ilt && ImGui.BeginTabItem("Deeds"))
			{
				DrawDeeds();
				ImGui.EndTabItem();
			}
			if (ilt && ImGui.BeginTabItem("Enl"))
			{
				DrawEnl();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Players"))
			{
				NearbyPlayers.Draw();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Packs"))
			{
				PackStats.Draw();
				ImGui.EndTabItem();
			}
			ImGui.EndTabBar();
		}
	}

	private static string Span(double secs)
	{
		TimeSpan timeSpan = TimeSpan.FromSeconds(Math.Max(0.0, secs));
		return (int)timeSpan.TotalHours + ":" + timeSpan.Minutes.ToString("00") + ":" + timeSpan.Seconds.ToString("00");
	}

	private static string Secs(double s)
	{
		if (s <= 0.0 || s == double.MaxValue)
		{
			return "-";
		}
		return (s < 60.0) ? (s.ToString("0.0") + "s") : ((int)(s / 60.0) + ":" + ((int)s % 60).ToString("00"));
	}

	private static void Row(string label, string value, string tip = null)
	{
		ImGui.TableNextRow();
		ImGui.TableSetColumnIndex(0);
		Im.TextColored(Cyan, label);
		if (tip != null && ImGui.IsItemHovered())
		{
			Im.SetTooltip(tip);
		}
		ImGui.TableSetColumnIndex(1);
		ImGui.TextUnformatted(value);
	}

	private static void Row2(string l1, string v1, string l2, string v2)
	{
		ImGui.TableNextRow();
		ImGui.TableSetColumnIndex(0);
		Im.TextColored(Cyan, l1);
		ImGui.TableSetColumnIndex(1);
		ImGui.TextUnformatted(v1);
		ImGui.TableSetColumnIndex(2);
		if (l2 != null)
		{
			Im.TextColored(Cyan, l2);
		}
		ImGui.TableSetColumnIndex(3);
		if (v2 != null)
		{
			ImGui.TextUnformatted(v2);
		}
	}

	private static string CorpsesText(Stats s)
	{
		return s.Corpses.ToString("N0") + ((s.Corpses > 0) ? ("  (" + (100.0 * (double)s.CorpsesKept / (double)s.Corpses).ToString("0") + "% kept something)") : "");
	}

	private static string LootText(Stats s)
	{
		return s.LootItems.ToString("N0") + ((s.Corpses > 0) ? ("  (" + ((double)s.LootItems / (double)s.Corpses).ToString("0.##") + " per corpse)") : "");
	}

	private static void DrawMain()
	{
		Stats cur = Cur;
		double num = HoursOf(cur);
		if (ImGui.BeginTable("sessmain", 2, ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("a", ImGuiTableColumnFlags.WidthFixed, 140f);
			ImGui.TableSetupColumn("b", ImGuiTableColumnFlags.WidthStretch);
			Row("Time played", Span(PlayedSecs(cur)), "Since this character logged in (or since Reset).");
			Row("Kills", cur.Kills.ToString("N0"), "Monsters MelkTank was fighting that died close by.\nKill times per monster are on the Kills tab.");
			Row("Kills / hour", ((double)cur.Kills / num).ToString("N0"), "Over the whole session.");
			int num2 = OutKills(cur);
			if (num2 > 0)
			{
				double num3 = TunedHours(cur, num);
				Row("Kills / hour (tuned)", ((double)(cur.Kills - num2) / num3).ToString("N0"), "Without the monsters left out of tuning (" + num2.ToString("N0") + " kills) and their time: their fights and the waits\nfrom one of their fights to the next (" + Fmt((num - num3) * 3600.0) + " of the session's " + Fmt(num * 3600.0) + ").");
			}
			double killsPerHourRecent = KillsPerHourRecent;
			Row("   last 60 min", (killsPerHourRecent < 0.0) ? "after 1 minute" : killsPerHourRecent.ToString("N0"), "Kills per hour over the last 60 minutes - what you're doing now.\nMelksQB uses this for the bounty time to go.");
			string text = CoinLine();
			if (text.Length > 0)
			{
				Row("Prestige coins", text.Substring("Prestige Coin: ".Length) + "  kills toward the next", CoinTip());
			}
			Row("Deaths", cur.Deaths.ToString());
			Row("Packs", (Packs == 0) ? "none yet" : (Packs.ToString("N0") + "   avg " + Secs(PackAvg) + " · fastest " + Secs(PackFastest) + " · slowest " + Secs(PackSlowest) + " · last " + Secs(PackLast) + " · " + ((double)PackKills / (double)Packs).ToString("0.0") + " kills each"), "A pack = a fight with " + 3 + "+ kills: from the first monster in attack range until none is left.");
			Row("Luminance earned", Big(LumEarned) + (LumRateIsBounty ? ("   (" + Big(LumPerHour) + "/hr from the bounty reward - Settings > Areas)") : ("   (" + Big(LumPerHour) + "/hr, last " + LumTrack.WindowText + " " + Big(LumPerHourRecent) + "/hr)")), "From the \"You've banked ... Luminance\" lines" + (CountLumTokens ? (", plus " + LumTokenValue.ToString("0,,,") + " B for each Thaelaryn Token of Luminance you receive" + ((_tokGot > 0) ? (" (" + _tokGot + " so far)") : "") + ".\nTokens in your packs now: " + Math.Max(0L, _tokBase)) : "") + ".");
			DrawFractureRow();
			Row("XP earned", Big(XpEarned) + "   (" + Big(XpPerHour) + "/hr, last 60 min " + Big(XpPerHourRecent) + "/hr)");
			Row("Corpses looted", cur.Corpses.ToString("N0") + ((cur.Corpses > 0) ? ("   (" + cur.CorpsesKept.ToString("N0") + " had something to keep, " + (100.0 * (double)cur.CorpsesKept / (double)cur.Corpses).ToString("0") + "%)") : ""), "Corpses the looter opened and went through (skipped ones aren't counted).");
			Row("Loot kept", cur.LootItems.ToString("N0") + " item" + ((cur.LootItems == 1) ? "" : "s") + ((cur.Corpses > 0) ? ("   (" + ((double)cur.LootItems / (double)cur.Corpses).ToString("0.##") + " per corpse)") : ""), "Items the looter picked up.");
			Row("      Armor", cur.LootArmor.ToString("N0"));
			Row("      Clothing", cur.LootClothing.ToString("N0"));
			Row("      Jewelry", cur.LootJewelry.ToString("N0"));
			Row("      Weapons", cur.LootWeapons.ToString("N0"), "Melee, missile, and wands / staffs / orbs.");
			Row("      Misc", cur.LootMisc.ToString("N0"), "Everything else: gems, salvage, keys, trophies, scrolls...");
			ImGui.EndTable();
		}
		ImGui.Spacing();
		if (!_confirmReset)
		{
			if (ImGui.Button("Reset session"))
			{
				_confirmReset = true;
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Starts this session's numbers over (they also start over every time you log in).\nAll Time isn't touched.");
			}
			return;
		}
		Im.TextColored(Yellow, "Start the session over?");
		ImGui.SameLine();
		if (ImGui.Button("Yes##sessreset"))
		{
			Reset();
			_confirmReset = false;
		}
		ImGui.SameLine();
		if (ImGui.Button("No##sessreset"))
		{
			_confirmReset = false;
		}
	}

	private static void DrawAllTime()
	{
		Stats all = All;
		double num = HoursOf(all);
		Im.TextDisabled("This character, every session since " + all.Since.ToString("yyyy-MM-dd HH:mm"));
		string text = (_confirmResetAll ? "" : "Reset all time");
		float num2 = (_confirmResetAll ? 230f : (ImGui.CalcTextSize(text).X + 16f));
		ImGui.SameLine(Math.Max(ImGui.GetCursorPosX() + 10f, ImGui.GetWindowContentRegionMax().X - num2));
		if (!_confirmResetAll)
		{
			if (ImGui.Button(text))
			{
				_confirmResetAll = true;
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Clears every all-time number and kill for this character. This session's tabs aren't touched.");
			}
		}
		else
		{
			Im.TextColored(Yellow, "Clear all time?");
			ImGui.SameLine();
			if (ImGui.Button("Yes##allreset"))
			{
				ResetAll();
				_confirmResetAll = false;
			}
			ImGui.SameLine();
			if (ImGui.Button("No##allreset"))
			{
				_confirmResetAll = false;
			}
		}
		if (ImGui.BeginTable("allmain", 4, ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("a", ImGuiTableColumnFlags.WidthFixed, 110f);
			ImGui.TableSetupColumn("b", ImGuiTableColumnFlags.WidthStretch);
			ImGui.TableSetupColumn("c", ImGuiTableColumnFlags.WidthFixed, 90f);
			ImGui.TableSetupColumn("d", ImGuiTableColumnFlags.WidthStretch);
			Row2("Time played", Span(PlayedSecs(all)), "Deaths", all.Deaths.ToString("N0"));
			Row2("Kills", all.Kills.ToString("N0"), "Kills / hour", ((double)all.Kills / num).ToString("N0"));
			Row2("Corpses looted", CorpsesText(all), "Loot kept", LootText(all));
			Row2("Armor", all.LootArmor.ToString("N0"), "Clothing", all.LootClothing.ToString("N0"));
			Row2("Jewelry", all.LootJewelry.ToString("N0"), "Weapons", all.LootWeapons.ToString("N0"));
			Row2("Misc", all.LootMisc.ToString("N0"), null, null);
			ImGui.EndTable();
		}
		ImGui.Separator();
		DrawKills(all, _allSort, "allkills", "No kills saved for this character yet.");
	}

	private static int Compare(SortState st, int kills1, double avg1, double fast1, double slow1, double total1, string name1, int kills2, double avg2, double fast2, double slow2, double total2, string name2)
	{
		int num;
		switch (st.Col)
		{
		case 1:
		case 5:
			num = kills1.CompareTo(kills2);
			break;
		case 2:
			num = avg1.CompareTo(avg2);
			break;
		case 3:
			num = fast1.CompareTo(fast2);
			break;
		case 4:
			num = slow1.CompareTo(slow2);
			break;
		case 6:
			num = total1.CompareTo(total2);
			break;
		default:
			num = 0;
			break;
		}
		if (st.Desc)
		{
			num = -num;
		}
		return (num != 0) ? num : string.Compare(name1, name2, StringComparison.OrdinalIgnoreCase);
	}

	private static double TunedHours(Stats s, double h)
	{
		if (s != Cur)
		{
			return h;
		}
		double val = h - PackStats.OutSecs / 3600.0;
		return Math.Max(val, Math.Min(h, 1.0 / 60.0));
	}

	private static string Fmt(double secs)
	{
		TimeSpan timeSpan = TimeSpan.FromSeconds(Math.Max(0.0, secs));
		return (timeSpan.TotalHours >= 1.0) ? ((int)timeSpan.TotalHours + "h " + timeSpan.Minutes + "m") : (timeSpan.Minutes + "m " + timeSpan.Seconds + "s");
	}

	private static int OutKills(Stats s)
	{
		int num = 0;
		foreach (MobStat value in s.Mobs.Values)
		{
			if (PackStats.IsOut(value.Name))
			{
				num += value.Kills;
			}
		}
		return num;
	}

	private static void Cells(int kills, double avg, double fast, double slow, double total, double totalAll, double h)
	{
		ImGui.TableSetColumnIndex(1);
		ImGui.TextUnformatted(kills.ToString("N0"));
		ImGui.TableSetColumnIndex(2);
		ImGui.TextUnformatted(Secs(avg));
		ImGui.TableSetColumnIndex(3);
		ImGui.TextUnformatted(Secs(fast));
		ImGui.TableSetColumnIndex(4);
		ImGui.TextUnformatted(Secs(slow));
		ImGui.TableSetColumnIndex(5);
		ImGui.TextUnformatted(((double)kills / h).ToString("0"));
		ImGui.TableSetColumnIndex(6);
		ImGui.TextUnformatted((totalAll > 0.0) ? ((100.0 * total / totalAll).ToString("0") + "%") : "-");
	}

	private static void DrawKills(Stats s, SortState st, string id, string empty)
	{
		if (s.Mobs.Count == 0)
		{
			Im.TextDisabled(empty);
			Im.TextWrapped("Each monster's time runs from your first attack, debuff or pet hit that landed (the Tracking tab's timer) to when it dies.");
			return;
		}
		double num = 0.0;
		Dictionary<int, Group> dictionary = new Dictionary<int, Group>();
		foreach (MobStat value2 in s.Mobs.Values)
		{
			num += value2.TotalSecs;
			try
			{
				SpeciesNameOf(value2);
			}
			catch
			{
			}
			if (!dictionary.TryGetValue(value2.Species, out var value))
			{
				string text = SpeciesNameOf(value2);
				value = new Group
				{
					Species = value2.Species,
					Name = (string.IsNullOrEmpty(text) ? "Unknown species" : text)
				};
				dictionary[value2.Species] = value;
			}
			value.Mobs.Add(value2);
			value.Kills += value2.Kills;
			value.TotalSecs += value2.TotalSecs;
			if (value2.Fastest < value.Fastest)
			{
				value.Fastest = value2.Fastest;
			}
			if (value2.Slowest > value.Slowest)
			{
				value.Slowest = value2.Slowest;
			}
		}
		double h = HoursOf(s);
		if (ImGui.SmallButton("Expand all##" + id))
		{
			st.OpenAll = 1;
		}
		ImGui.SameLine();
		if (ImGui.SmallButton("Collapse all##" + id))
		{
			st.OpenAll = -1;
		}
		ImGui.SameLine();
		Im.TextDisabled(s.Mobs.Count + " monster" + ((s.Mobs.Count == 1) ? "" : "s") + " in " + dictionary.Count + " species");
		ImGuiTableFlags flags = ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY;
		if (!ImGui.BeginTable(id, 8, flags, new Vector2(0f, 0f)))
		{
			st.OpenAll = 0;
			return;
		}
		ImGui.TableSetupColumn("Monster", ImGuiTableColumnFlags.WidthStretch);
		ImGui.TableSetupColumn("Kills", ImGuiTableColumnFlags.WidthFixed, 52f);
		ImGui.TableSetupColumn("Avg", ImGuiTableColumnFlags.WidthFixed, 52f);
		ImGui.TableSetupColumn("Fastest", ImGuiTableColumnFlags.WidthFixed, 56f);
		ImGui.TableSetupColumn("Slowest", ImGuiTableColumnFlags.WidthFixed, 56f);
		ImGui.TableSetupColumn("/hr", ImGuiTableColumnFlags.WidthFixed, 48f);
		ImGui.TableSetupColumn("Time", ImGuiTableColumnFlags.WidthFixed, 50f);
		ImGui.TableSetupColumn("Out", ImGuiTableColumnFlags.WidthFixed, 34f);
		ImGui.TableSetupScrollFreeze(0, 1);
		string[] array = new string[8] { "Monster", "Kills", "Avg", "Fastest", "Slowest", "/hr", "Time", "Out" };
		string[] array2 = new string[8] { "Sort by name.", "How many died.", "Average kill time: first landed hit to death. Lower = quicker to kill.", "Quickest kill.", "Slowest kill.", "Kills per hour of play time.", "Share of all your fighting time spent on these.", "Ticked: left out of the Packs / Tuning numbers (packs of only these, their damage, slow kills, kills by stretch\nof route). Their kills and kills / hour still count here and for the bounty timers." };
		ImGui.TableNextRow(ImGuiTableRowFlags.Headers);
		for (int i = 0; i < array.Length; i++)
		{
			ImGui.TableSetColumnIndex(i);
			if (i == 7)
			{
				Im.TextColored(Cyan, array[i]);
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip(array2[i]);
				}
				continue;
			}
			string text2;
			if (st.Col != i)
			{
				text2 = "";
			}
			else
			{
				text2 = (st.Desc ? " v" : " ^");
			}
			ImGui.PushStyleColor(ImGuiCol.Text, Cyan);
			if (ImGui.Selectable(array[i] + text2 + "##" + id + i, st.Col == i))
			{
				if (st.Col == i)
				{
					st.Desc = !st.Desc;
				}
				else
				{
					st.Col = i;
					st.Desc = i != 0 && i != 2 && i != 3;
				}
			}
			ImGui.PopStyleColor();
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip(array2[i] + "\nSpecies are sorted by their totals, and the monsters inside each one too.\nClick to sort, again to reverse.");
			}
		}
		List<Group> list = new List<Group>(dictionary.Values);
		list.Sort((Group a, Group b) => Compare(st, a.Kills, a.Avg, a.Fastest, a.Slowest, a.TotalSecs, a.Name, b.Kills, b.Avg, b.Fastest, b.Slowest, b.TotalSecs, b.Name));
		foreach (Group item in list)
		{
			ImGui.TableNextRow();
			ImGui.TableSetColumnIndex(0);
			if (st.OpenAll != 0)
			{
				ImGui.SetNextItemOpen(st.OpenAll > 0);
			}
			ImGui.PushStyleColor(ImGuiCol.Text, Yellow);
			bool flag = ImGui.TreeNodeEx(item.Name + " (" + item.Mobs.Count + ")##" + id + "sp" + item.Species, ImGuiTreeNodeFlags.SpanFullWidth);
			ImGui.PopStyleColor();
			Cells(item.Kills, item.Avg, item.Fastest, item.Slowest, item.TotalSecs, num, h);
			ImGui.TableSetColumnIndex(7);
			bool flag2 = item.Mobs.Count > 0 && item.Mobs.TrueForAll((MobStat m) => PackStats.IsOut(m.Name));
			bool v = flag2;
			if (ImGui.Checkbox("##out" + id + "sp" + item.Species, ref v))
			{
				foreach (MobStat mob in item.Mobs)
				{
					PackStats.SetOut(mob.Name, v);
				}
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Leave every " + item.Name + " here out of the Packs / Tuning numbers.");
			}
			if (!flag)
			{
				continue;
			}
			item.Mobs.Sort((MobStat a, MobStat b) => Compare(st, a.Kills, a.Avg, a.Fastest, a.Slowest, a.TotalSecs, a.Name, b.Kills, b.Avg, b.Fastest, b.Slowest, b.TotalSecs, b.Name));
			foreach (MobStat mob2 in item.Mobs)
			{
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				ImGui.Indent();
				bool v2 = PackStats.IsOut(mob2.Name);
				if (v2)
				{
					Im.TextDisabled(mob2.Name + "  (left out)");
				}
				else
				{
					ImGui.TextUnformatted(mob2.Name);
				}
				ImGui.Unindent();
				Cells(mob2.Kills, mob2.Avg, mob2.Fastest, mob2.Slowest, mob2.TotalSecs, num, h);
				ImGui.TableSetColumnIndex(7);
				if (ImGui.Checkbox("##out" + id + mob2.Name, ref v2))
				{
					PackStats.SetOut(mob2.Name, v2);
				}
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip(array2[7]);
				}
			}
			ImGui.TreePop();
		}
		ImGui.EndTable();
		st.OpenAll = 0;
	}
}
