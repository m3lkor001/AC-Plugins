using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using MelkTank.Metas;
using AcClient;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Bounties;
using MelkTank.Buffs;

namespace MelkTank;

public static partial class Session
{
	public static void NoteFractureStreak()
	{
		if (_frWaiting)
		{
			_frNoDmg++;
		}
		_frStreakAt = DateTime.Now;
		_frWaiting = true;
	}

	private static void FractureTick()
	{
		if (_frWaiting && (DateTime.Now - _frStreakAt).TotalSeconds > 4.0)
		{
			_frWaiting = false;
			_frNoDmg++;
		}
	}

	private static void FractureReset()
	{
		_frPrimes = (_frBursts = (_frByStreak = (_frOnDeath = (_frHits = (_frNoDmg = 0)))));
		_frWaiting = false;
		_frDmg = (_frMax = (_frCur = 0L));
		_frLastHit = DateTime.MinValue;
	}

	private static void FractureChat(string text)
	{
		string input = text.Trim();
		if (FrPrimeRx.IsMatch(input))
		{
			_frPrimes++;
			return;
		}
		if (FrDeathRx.IsMatch(input))
		{
			_frDeathAt = DateTime.Now;
			return;
		}
		Match match = FrHitRx.Match(input);
		if (!match.Success || !long.TryParse(match.Groups["n"].Value.Replace(",", ""), out var result))
		{
			return;
		}
		if ((DateTime.Now - _frLastHit).TotalSeconds > 1.0)
		{
			_frBursts++;
			_frCur = 0L;
			if ((DateTime.Now - _frDeathAt).TotalSeconds <= 2.0)
			{
				_frOnDeath++;
			}
			else if (_frWaiting && (DateTime.Now - _frStreakAt).TotalSeconds <= 4.0)
			{
				_frByStreak++;
				_frWaiting = false;
			}
			else
			{
				_frOnDeath++;
			}
		}
		_frLastHit = DateTime.Now;
		_frHits++;
		_frDmg += result;
		_frCur += result;
		if (_frCur > _frMax)
		{
			_frMax = _frCur;
		}
	}

	private static void DrawFractureRow()
	{
		if (_frPrimes != 0 || _frBursts != 0 || _frNoDmg != 0)
		{
			string text = _frBursts.ToString("N0") + " burst" + ((_frBursts == 1) ? "" : "s") + " (" + _frByStreak + " by streak, " + _frOnDeath + " on death, " + _frNoDmg + " no damage)";
			if (_frBursts > 0)
			{
				text = text + "   avg " + Big((double)_frDmg / (double)_frBursts) + " · biggest " + Big(_frMax) + " · " + ((double)_frHits / (double)_frBursts).ToString("0.0") + " monsters each · total " + Big(_frDmg);
			}
			text = text + "   · " + _frPrimes + " primed";
			Row("Nether Fracture", text, "From chat: \"Your void enchantments prime ...\" (primed) and \"Your Nether Fracture strikes ...\" (each monster a burst hit).\nBy streak = within 4 s of MelkTank's Nether Streak release; on death = the prime burst when the monster died;\nno damage = a Nether Streak release with no Fracture line after it (4 s).\nAvg / biggest are per burst (all the monsters it hit together).");
		}
	}

	public static double PaceRoom()
	{
		return HourOn() ? Math.Max(0.0, HourFull - _hourKills) : -1.0;
	}

	private static bool HourOn()
	{
		return _hourStart != DateTime.MinValue && (DateTime.Now - _hourStart).TotalMinutes < 60.0;
	}

	// what a kill at this many kills into the hour pays: full to 375, then half for each 75 after
	private static double HourRate(double k)
	{
		if (k < HourFull) return 1.0;
		return Math.Pow(0.5, Math.Floor((k - HourFull) / HourStep) + 1.0);
	}

	private static double PaceKill()
	{
		double num = ((_paceCredit >= 0.0 && _paceZoneTier == SafeTier()) ? _paceCredit : 1.0);
		if (!HourOn())
		{
			_hourStart = DateTime.Now;
			_hourKills = 0.0;
		}
		double rate = HourRate(_hourKills);
		_hourKills += num;
		_paceSlowNow = rate < 1.0;
		return rate * num;
	}

	private static int SafeTier()
	{
		int result = -1;
		try
		{
			if (CurrentTier != null)
			{
				result = CurrentTier();
			}
		}
		catch
		{
		}
		return result;
	}

	private static void PaceChat(string text)
	{
		string text2 = (text ?? "").Trim();
		Match match;
		if ((match = PaceMyRx.Match(text2)).Success)
		{
			_paceMyTier = int.Parse(match.Groups[1].Value);
		}
		else if ((match = PaceZoneRx.Match(text2)).Success)
		{
			_paceZoneTier = int.Parse(match.Groups[1].Value);
		}
		else if ((match = PaceCreditRx.Match(text2)).Success)
		{
			_paceCredit = double.Parse(match.Groups[1].Value, CultureInfo.InvariantCulture) / 100.0;
		}
		else if (text2.IndexOf("coin hour", StringComparison.OrdinalIgnoreCase) >= 0 && (text2.IndexOf("first 375", StringComparison.OrdinalIgnoreCase) >= 0 || text2.IndexOf("per coin hour", StringComparison.OrdinalIgnoreCase) >= 0))
		{
			// "Prestige Coins from kills here, per coin hour: full for the first 375 kills, then 50 pct less every 75 kills" - the rule
		}
		else if (text2.IndexOf("starts a new coin hour", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			// "Your next coin kill starts a new coin hour (60 minutes)." - none running
			_hourStart = DateTime.MinValue;
			_hourKills = 0.0;
			_hourSynced = DateTime.Now;
			_paceChecked = DateTime.Now;
			_paceCheckedTier = SafeTier();
			_paceSlowNow = false;
		}
		else if (text2.IndexOf("coin hour", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			// the server's word on the coin hour (/tierdip, and its notice at each step): kills so far, minutes left
			Match k = HourKillsRx.Match(text2);
			string kv = k.Success ? (k.Groups[1].Success ? k.Groups[1].Value : k.Groups[2].Value) : null;
			if (kv != null && double.TryParse(kv.Replace(",", ""), NumberStyles.Float, CultureInfo.InvariantCulture, out var kills))
			{
				Match l = HourLeftRx.Match(text2);
				if (l.Success && int.TryParse(l.Groups[1].Value, out var left) && left <= 60)
				{
					_hourStart = DateTime.Now.AddMinutes(left - 60);
				}
				else if (!HourOn())
				{
					_hourStart = DateTime.Now;
				}
				// "Your coin hour so far counts as 12 kills here and ends in 58 minutes: your next kill here pays 100 pct of its
				// coins." - kills *here*: at this zone's credit (a half-credit zone's kill is half a kill of the hour)
				double here = (text2.IndexOf("kills here", StringComparison.OrdinalIgnoreCase) >= 0 && _paceCredit > 0.0) ? _paceCredit : 1.0;
				_hourKills = kills * here;
				_hourSynced = DateTime.Now;
				_paceChecked = DateTime.Now;
				_paceCheckedTier = SafeTier();
				_paceSlowNow = HourRate(_hourKills) < 1.0;
			}
			else if (text2.IndexOf("not started", StringComparison.OrdinalIgnoreCase) >= 0 || text2.IndexOf("no coin hour", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				_hourStart = DateTime.MinValue;
				_hourKills = 0.0;
				_hourSynced = DateTime.Now;
				_paceChecked = DateTime.Now;
				_paceCheckedTier = SafeTier();
			}
			else
			{
				Notes.Add("coin hour line not read: " + text2, "session", true);
			}
		}
		else
		{
			if (text2.IndexOf("Prestige Coin", StringComparison.OrdinalIgnoreCase) < 0 || text2.IndexOf("pace", StringComparison.OrdinalIgnoreCase) < 0)
			{
				return;
			}
			if (text2.IndexOf("full", StringComparison.OrdinalIgnoreCase) >= 0 && (text2.IndexOf("back", StringComparison.OrdinalIgnoreCase) >= 0 || text2.IndexOf("again", StringComparison.OrdinalIgnoreCase) >= 0))
			{
				_paceSlowNow = false;
				if (PaceRoom() < 1.0)
				{
					_paceRoom = 1.0;
					_paceAt = DateTime.Now;
				}
			}
			else if (text2.IndexOf("less", StringComparison.OrdinalIgnoreCase) >= 0 || text2.IndexOf("half", StringComparison.OrdinalIgnoreCase) >= 0 || text2.IndexOf("slow", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				_paceSlowNow = true;
				_paceRoom = 0.0;
				_paceAt = DateTime.Now;
			}
		}
	}

	private static bool QuietPace(string s)
	{
		if (DateTime.Now > _paceQuietUntil)
		{
			return false;
		}
		// "You are not in a T11+ zone: kills here give their normal rewards." - asked from a zone the tier reading took
		// for T11+ (it lags a portal): hidden, and not asked again here for 10 minutes
		if (s.IndexOf("not in a T11+ zone", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			_paceCheckedTier = SafeTier();
			_paceChecked = DateTime.Now;
			_paceQuietUntil = DateTime.MinValue;
			return true;
		}
		if (!PaceAnyRx.IsMatch(s.Trim()))
		{
			return false;
		}
		_paceQuietUntil = DateTime.Now.AddSeconds(2.0);
		return true;
	}

	private static void PaceTick()
	{
		int num = SafeTier();
		if (num < 11 || (DateTime.Now - _paceSent).TotalSeconds < 60.0 || (num == _paceCheckedTier && (DateTime.Now - _paceChecked).TotalMinutes < 10.0))
		{
			return;
		}
		try
		{
			if (Globals.Core.CharacterFilter.LoginStatus != 3)
			{
				return;
			}
		}
		catch
		{
			return;
		}
		_paceSent = DateTime.Now;
		_paceQuietUntil = DateTime.Now.AddSeconds(8.0);
		try
		{
			Globals.Core.Actions.InvokeChatParser("/tierdip");
		}
		catch
		{
		}
	}

	public static string PaceText()
	{
		if (!HourOn())
		{
			return "";
		}
		int left = Math.Max(0, (int)Math.Ceiling(60.0 - (DateTime.Now - _hourStart).TotalMinutes));
		double rate = HourRate(_hourKills);
		if (rate >= 1.0)
		{
			return " · coin hour: " + _hourKills.ToString("0", CultureInfo.InvariantCulture) + "/" + HourFull.ToString("0") + " full · " + left + "m left";
		}
		return " · coin hour: " + (rate * 100.0).ToString((rate < 0.1) ? "0.0" : "0", CultureInfo.InvariantCulture) + "% coins (" + _hourKills.ToString("0", CultureInfo.InvariantCulture) + " kills) · " + left + "m left";
	}

	private static string PaceTip()
	{
		string rule = "\nCoin hour: from your first Prestige Coin kill, 60 minutes. The first 375 kills pay full coins, then every 75 kills pay half the step before (50%, 25%, 12.5% ...).\nA kill below your tier uses its share of a kill. One count per character across every zone; relogging doesn't reset it.";
		if (!HourOn())
		{
			return rule + "\nNo coin hour running" + ((_hourStart != DateTime.MinValue) ? " - the last one ended; the next coin kill starts a new one." : " (or not known yet - MelkTank asks /tierdip in a T11+ zone).");
		}
		double next = (_hourKills < HourFull) ? (HourFull - _hourKills) : (HourStep - (_hourKills - HourFull) % HourStep);
		return rule + "\nThis hour: " + _hourKills.ToString("0.#", CultureInfo.InvariantCulture) + " kills, started " + _hourStart.ToString("h:mm tt") + ", ends " + _hourStart.AddMinutes(60.0).ToString("h:mm tt") + ". Now paying " + (HourRate(_hourKills) * 100.0).ToString("0.#", CultureInfo.InvariantCulture) + "%; " + next.ToString("0", CultureInfo.InvariantCulture) + " kills to the next step." + ((_paceMyTier > 0) ? ("\nYour reward tier T" + _paceMyTier + ((_paceZoneTier > 0) ? (", this zone T" + _paceZoneTier) : "") + ((_paceCredit >= 0.0) ? (" - a kill here counts " + (_paceCredit * 100.0).ToString("0") + "%.") : ".") + " (Your reward tier is capped by the best Tou Tou Endgame Portal Gem you carry.)") : "") + ((_hourSynced != DateTime.MinValue) ? ("\nRead from the server at " + _hourSynced.ToString("h:mm tt") + ", counted with MelkTank's kills since.") : "\nCounted with MelkTank's kills (not read from /tierdip yet).");
	}
}
