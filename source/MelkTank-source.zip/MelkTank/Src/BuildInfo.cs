namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 652;

	public const string Time = "Nov 26 23:01";

	public static string Label => "b" + Number + " (" + Time + ")";
}
