namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 634;

	public const string Time = "Nov 25 13:22";

	public static string Label => "b" + Number + " (" + Time + ")";
}
