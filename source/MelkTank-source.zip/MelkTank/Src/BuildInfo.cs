namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 641;

	public const string Time = "Nov 26 09:29";

	public static string Label => "b" + Number + " (" + Time + ")";
}
