namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 665;

	public const string Time = "Nov 27 19:19";

	public static string Label => "b" + Number + " (" + Time + ")";
}
