namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 664;

	public const string Time = "Nov 27 15:46";

	public static string Label => "b" + Number + " (" + Time + ")";
}
