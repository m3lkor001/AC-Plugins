namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 633;

	public const string Time = "Nov 25 10:43";

	public static string Label => "b" + Number + " (" + Time + ")";
}
