namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 639;

	public const string Time = "Nov 26 08:33";

	public static string Label => "b" + Number + " (" + Time + ")";
}
