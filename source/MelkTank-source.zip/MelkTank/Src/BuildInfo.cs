namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 647;

	public const string Time = "Nov 26 22:06";

	public static string Label => "b" + Number + " (" + Time + ")";
}
