namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 638;

	public const string Time = "Nov 26 08:26";

	public static string Label => "b" + Number + " (" + Time + ")";
}
