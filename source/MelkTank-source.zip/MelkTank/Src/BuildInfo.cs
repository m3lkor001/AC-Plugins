namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 632;

	public const string Time = "Nov 25 08:42";

	public static string Label => "b" + Number + " (" + Time + ")";
}
