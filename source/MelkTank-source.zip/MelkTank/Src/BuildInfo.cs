namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 663;

	public const string Time = "Nov 27 10:30";

	public static string Label => "b" + Number + " (" + Time + ")";
}
