namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 636;

	public const string Time = "Nov 25 21:37";

	public static string Label => "b" + Number + " (" + Time + ")";
}
