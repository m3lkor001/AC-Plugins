namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 628;

	public const string Time = "Nov 25 07:20";

	public static string Label => "b" + Number + " (" + Time + ")";
}
