namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 651;

	public const string Time = "Nov 26 22:46";

	public static string Label => "b" + Number + " (" + Time + ")";
}
