namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 642;

	public const string Time = "Nov 26 09:36";

	public static string Label => "b" + Number + " (" + Time + ")";
}
