namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 667;

	public const string Time = "Nov 27 22:17";

	public static string Label => "b" + Number + " (" + Time + ")";
}
