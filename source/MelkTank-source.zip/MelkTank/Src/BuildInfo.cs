namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 643;

	public const string Time = "Nov 26 13:38";

	public static string Label => "b" + Number + " (" + Time + ")";
}
