namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 666;

	public const string Time = "Nov 27 19:46";

	public static string Label => "b" + Number + " (" + Time + ")";
}
