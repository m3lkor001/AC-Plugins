namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 630;

	public const string Time = "Nov 25 08:17";

	public static string Label => "b" + Number + " (" + Time + ")";
}
