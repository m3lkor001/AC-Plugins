namespace MelkTank;

public static class BuildInfo
{
	public const int Number = 648;

	public const string Time = "Nov 26 22:23";

	public static string Label => "b" + Number + " (" + Time + ")";
}
