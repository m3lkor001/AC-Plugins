using System;
using System.Collections.Generic;
using System.Numerics;
using ImGuiNET;
using UtilityBelt.Service.Views;

namespace MelkTank;

internal static class Im
{
	private static readonly Vector4 UpCol = new Vector4(0.15f, 0.55f, 0.2f, 1f);

	private static readonly Vector4 UpHover = new Vector4(0.2f, 0.7f, 0.25f, 1f);

	private static readonly Vector4 UpActive = new Vector4(0.1f, 0.45f, 0.15f, 1f);

	private static readonly Vector4 DnCol = new Vector4(0.6f, 0.15f, 0.15f, 1f);

	private static readonly Vector4 DnHover = new Vector4(0.75f, 0.2f, 0.2f, 1f);

	private static readonly Vector4 DnActive = new Vector4(0.5f, 0.1f, 0.1f, 1f);

	public static bool Far;

	private static DateTime _holdStart = DateTime.MinValue;

	private static uint _holdId;

	private static bool _holdDown;

	// game icons (0x06... pictures) as ImGui textures - one kept set for every window that draws them (the item bar, the
	// portals tab and the inventory tab each kept their own)
	private static readonly Dictionary<int, ManagedTexture> _icons = new Dictionary<int, ManagedTexture>();

	/// <summary>A game icon, size x size (an empty space if it can't be had).</summary>
	public static void Icon(int icon, float size)
	{
		ManagedTexture tex = null;
		if (icon != 0)
		{
			if ((icon & 0xFF000000u) == 0) icon |= 0x6000000;
			if (!_icons.TryGetValue(icon, out tex))
			{
				try { tex = (ManagedTexture)Activator.CreateInstance(typeof(ManagedTexture), (uint)icon); }
				catch { tex = null; }
				_icons[icon] = tex;
			}
		}
		if (tex != null)
		{
			try { ImGui.Image(tex.TexturePtr, new Vector2(size, size)); return; }
			catch { }
		}
		ImGui.Dummy(new Vector2(size, size));
	}

	/// <summary>Lets the icons' textures go (closing): any still wanted are made again when next drawn.</summary>
	public static void DisposeIcons()
	{
		foreach (ManagedTexture t in _icons.Values)
		{
			try { t?.Dispose(); } catch { }
		}
		_icons.Clear();
	}

	public static void Text(string s)
	{
		ImGui.TextUnformatted(s ?? "");
	}

	public static void TextColored(Vector4 col, string s)
	{
		ImGui.PushStyleColor(ImGuiCol.Text, col);
		ImGui.TextUnformatted(s ?? "");
		ImGui.PopStyleColor();
	}

	public static void TextDisabled(string s)
	{
		TextColored(new Vector4(0.5f, 0.5f, 0.5f, 1f), s);
	}

	public static void TextWrapped(string s)
	{
		ImGui.PushTextWrapPos(0f);
		ImGui.TextUnformatted(s ?? "");
		ImGui.PopTextWrapPos();
	}

	private static void Push(Vector4 a, Vector4 b, Vector4 c)
	{
		ImGui.PushStyleColor(ImGuiCol.Button, a);
		ImGui.PushStyleColor(ImGuiCol.ButtonHovered, b);
		ImGui.PushStyleColor(ImGuiCol.ButtonActive, c);
	}

	public static bool UpButton(string id)
	{
		Push(UpCol, UpHover, UpActive);
		bool flag = ImGui.ArrowButton(id, ImGuiDir.Up);
		ImGui.PopStyleColor(3);
		NoteHold(flag);
		return flag;
	}

	private static void NoteHold(bool clicked)
	{
		if (ImGui.IsItemActive())
		{
			if (_holdStart == DateTime.MinValue)
			{
				_holdStart = DateTime.Now;
			}
			_holdId = ImGui.GetItemID();
		}
		if (clicked)
		{
			Far = _holdStart != DateTime.MinValue && (DateTime.Now - _holdStart).TotalSeconds >= 0.5;
			_holdStart = DateTime.MinValue;
		}
		else if (!ImGui.IsMouseDown(ImGuiMouseButton.Left) && ImGui.GetItemID() == _holdId && !ImGui.IsItemHovered())
		{
			_holdStart = DateTime.MinValue;
		}
		if (ImGui.IsItemHovered())
		{
			SetTooltip("Hold for half a second: all the way to the " + (_holdDown ? "bottom" : "top") + ".");
		}
	}

	public static int Move<T>(List<T> l, int from, bool up, int first = 0)
	{
		if (from < first || from >= l.Count)
		{
			return from;
		}
		int num;
		if (Far)
		{
			num = (up ? first : (l.Count - 1));
		}
		else
		{
			num = (up ? (from - 1) : (from + 1));
		}
		Far = false;
		if (num < first || num >= l.Count || num == from)
		{
			return from;
		}
		T item = l[from];
		l.RemoveAt(from);
		l.Insert(num, item);
		return num;
	}

	public static bool DownButton(string id)
	{
		Push(DnCol, DnHover, DnActive);
		bool flag = ImGui.ArrowButton(id, ImGuiDir.Down);
		ImGui.PopStyleColor(3);
		_holdDown = true;
		NoteHold(flag);
		_holdDown = false;
		return flag;
	}

	public static bool SmallUp(string label)
	{
		Push(UpCol, UpHover, UpActive);
		bool result = ImGui.SmallButton(label);
		ImGui.PopStyleColor(3);
		return result;
	}

	public static bool SmallDown(string label)
	{
		Push(DnCol, DnHover, DnActive);
		bool result = ImGui.SmallButton(label);
		ImGui.PopStyleColor(3);
		return result;
	}

	/// <summary>A widget's result passed through, with its command shown as a tooltip when it's hovered (for "if (ImGui.Checkbox(...))").</summary>
	public static bool WithTip(string tip, bool result)
	{
		SetTooltipIfHovered(tip);
		return result;
	}

	public static void SetTooltipIfHovered(string s)
	{
		if (!string.IsNullOrEmpty(s) && ImGui.IsItemHovered())
		{
			SetTooltip(s);
		}
	}

	public static void SetTooltip(string s)
	{
		ImGui.BeginTooltip();
		ImGui.PushTextWrapPos(ImGui.GetFontSize() * 35f);
		ImGui.TextUnformatted(s ?? "");
		ImGui.PopTextWrapPos();
		ImGui.EndTooltip();
	}
}
