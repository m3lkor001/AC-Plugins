using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Xml;
using Decal.Adapter;
using MelkTank.Pets;

namespace MelkTank;

public static class Util
{
	// green / red parts in a chat line (ACGodot's chat draws them; the retail client's can't - left plain there)
	private const char TintBetter = '\u0011', TintWorse = '\u0012', TintPlain = '\u0010';

	private static readonly Regex TintScore = new Regex("(damage |Best slayer |With Slayer |~)([+-][\\d.]+%)");

	private static readonly Regex TintParen = new Regex("\\(([+-][^()]*)\\)");

	/// <summary>A compare line with its better parts green and worse parts red: the overall and slayer percentages,
	/// and each "(+x)" / "(-x)" difference.</summary>
	public static string TintCompare(string s)
	{
#if RETAIL
		return s;
#else
		if (string.IsNullOrEmpty(s))
		{
			return s;
		}
		s = TintScore.Replace(s, (Match m) => m.Groups[1].Value + Tint(m.Groups[2].Value));
		return TintParen.Replace(s, (Match m) => "(" + Tint(m.Groups[1].Value) + ")");
#endif
	}

	private static string Tint(string v)
	{
		return (v.StartsWith("+") ? TintBetter : TintWorse) + v + TintPlain;
	}

	public static string NoTints(string s)
	{
		return (s == null || s.IndexOfAny(new char[3] { TintBetter, TintWorse, TintPlain }) < 0) ? s : s.Replace(TintBetter.ToString(), "").Replace(TintWorse.ToString(), "").Replace(TintPlain.ToString(), "");
	}

	private static readonly Dictionary<int, DateTime> _ourIds = new Dictionary<int, DateTime>();

	/// <summary>MelkTank asking the server to appraise something for itself: the answer isn't announced in chat
	/// (ItemInfo / monster info) - only appraisals the player asked for are.</summary>
	public static void RequestId(int id)
	{
		lock (_ourIds)
		{
			_ourIds[id] = DateTime.Now;
			if (_ourIds.Count > 300)
			{
				List<int> old = new List<int>();
				foreach (KeyValuePair<int, DateTime> kv in _ourIds)
				{
					if ((DateTime.Now - kv.Value).TotalSeconds > 30.0)
					{
						old.Add(kv.Key);
					}
				}
				foreach (int k in old)
				{
					_ourIds.Remove(k);
				}
			}
		}
		CoreManager.Current.Actions.RequestId(id);
	}

	/// <summary>True (once) when this appraisal answers one of MelkTank's own requests from the last 15 seconds.</summary>
	public static bool TakeOurId(int id)
	{
		lock (_ourIds)
		{
			if (_ourIds.TryGetValue(id, out var at))
			{
				_ourIds.Remove(id);
				return (DateTime.Now - at).TotalSeconds < 15.0;
			}
		}
		return false;
	}

	private class StringWriterUtf8 : StringWriter
	{
		public override Encoding Encoding => new UTF8Encoding(encoderShouldEmitUTF8Identifier: false);

		public StringWriterUtf8(StringBuilder sb)
			: base(sb)
		{
		}
	}

	private static string _basePath;

	public static string LastCommand = "";

	public static DateTime LastCommandAt = DateTime.MinValue;

	private static bool _noDispatch;

	private static readonly string[] CharKinds = new string[17]
	{
		"MelkTank_Augs_", "MelkTank_Bank_", "MelkTank_BaseStats_", "MelkTank_Corpses_", "MelkTank_Deeds_", "MelkTank_Gear_", "MelkTank_Live_", "MelkTank_PackSettings_", "MelkTank_Packs_", "MelkTank_Salvage_",
		"MelkTank_Stats_", "MelkTank_PVars_", "MelkTank_NavSet_", "MelkTank_debug_", "MelkTank_PerfLog_", "MelkTank_Perf_", "MelkTank_MemLog_"
	};

	private static readonly string[] LogNames = new string[11]
	{
		"MelkTank_debug.txt", "MelkTank_debug_LoginNotComplete.txt", "MelkTank_errors.txt", "MelkTank_ubprobe.txt", "MelkTank_MonsterProbe.txt", "MelkTank_DispatchLog.txt", "MelkTank_GearChanges.txt", "MelkTank_Caught.txt", "MelkTank_MonsterNames.csv", "MelkTank_Notes.txt",
		"MelkTank_Dump.txt"
	};

	private static readonly Dictionary<string, DateTime> _migrated = new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);

	public static string BasePath
	{
		get
		{
			if (_basePath == null)
			{
				try
				{
					string location = Assembly.GetExecutingAssembly().Location;
					_basePath = (string.IsNullOrEmpty(location) ? "." : Path.GetDirectoryName(location));
				}
				catch
				{
					_basePath = ".";
				}
			}
			return _basePath;
		}
	}

	public static void WriteToChat(string message)
	{
		try
		{
			Globals.Host.Actions.AddChatText("[MelkTank] " + message, 5);
		}
		catch (Exception ex)
		{
			LogError(ex);
		}
		try
		{
			Remote.PluginLine("[MelkTank] " + NoTints(message), 5);
		}
		catch
		{
		}
	}

	public static void WriteToChatColor(string message, int color)
	{
		try
		{
			Globals.Host.Actions.AddChatText(message, color);
		}
		catch (Exception ex)
		{
			LogError(ex);
		}
		try
		{
			Remote.PluginLine(NoTints(message), color);
		}
		catch
		{
		}
	}

	public static void WriteToChat(string message, int color)
	{
		try
		{
			Globals.Host.Actions.AddChatText("[MelkTank] " + message, color);
		}
		catch (Exception ex)
		{
			LogError(ex);
		}
	}

	public static void WriteToChat(string message, int color, int window)
	{
		try
		{
			Globals.Host.Actions.AddChatText("[MelkTank] " + message, color, Math.Max(0, Math.Min(4, window)));
		}
		catch (Exception ex)
		{
			LogError(ex);
		}
	}

	public static List<Assembly> PluginAssemblies(string name)
	{
		List<Assembly> list = new List<Assembly>();
		try
		{
			Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
			foreach (Assembly assembly in assemblies)
			{
				if (!assembly.FullName.StartsWith(name + ",", StringComparison.Ordinal))
				{
					continue;
				}
				Type type = assembly.GetType(name + ".PluginCore");
				PropertyInfo propertyInfo = ((type == null) ? null : type.GetProperty("CoreAssembly", BindingFlags.Static | BindingFlags.Public));
				if (propertyInfo == null)
				{
					list.Add(assembly);
					continue;
				}
				Assembly assembly2 = propertyInfo.GetValue(null, null) as Assembly;
				if (assembly2 != null)
				{
					list.Add(assembly2);
				}
			}
		}
		catch (Exception ex)
		{
			LogError(ex);
		}
		return list;
	}

	public static void Command(string command)
	{
		if (string.IsNullOrEmpty(command))
		{
			return;
		}
		LastCommand = command;
		LastCommandAt = DateTime.Now;
		try
		{
			if (!UbCmd.Try(command) && (!command.TrimStart().StartsWith("/vt jump", StringComparison.OrdinalIgnoreCase) || PluginCore.CurrentEngine == null || !PluginCore.CurrentEngine.Nav.VtCommand(command)) && !SendToPlugin(command) && !DispatchToPlugins(command))
			{
				CoreManager.Current.Actions.InvokeChatParser(command);
			}
		}
		catch (Exception ex)
		{
			WriteToChat("Command error: " + ex.Message);
		}
	}

	private static bool SendToPlugin(string command)
	{
		string text = command.Trim();
		string text2 = text.Split(new char[1] { ' ' })[0].ToLowerInvariant();
		if (text2 == "/mbuff" || text2 == "@mbuff")
		{
			PluginCore.BuffCommand(text);
			return true;
		}
		if (text2 == "/mpets" || text2 == "@mpets")
		{
			string text3 = "MelksPetSummoner";
			if (!PetSummoner.ExternalLoaded)
			{
				if (PetSummoner.Current != null)
				{
					PetSummoner.Current.Command(text);
				}
				else
				{
					WriteToChat("Pets: not logged in yet.");
				}
				return true;
			}
			Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
			foreach (Assembly assembly in assemblies)
			{
				if (assembly.FullName.StartsWith(text3 + ","))
				{
					Type type = assembly.GetType(text3 + ".PluginCore");
					MethodInfo methodInfo = ((type == null) ? null : type.GetMethod("ExternalCommand", BindingFlags.Static | BindingFlags.Public));
					if (methodInfo == null)
					{
						WriteToChat(text3 + " needs rebuilding with the MelkTank hook before this switch can control it.");
						return true;
					}
					methodInfo.Invoke(null, new object[1] { text });
					return true;
				}
			}
			WriteToChat(text3 + " isn't loaded.");
			return true;
		}
		return false;
	}

	[DllImport("Decal.dll")]
	private static extern int DispatchOnChatCommand(ref nint str, [MarshalAs(UnmanagedType.U4)] int target);

	public static bool DispatchToPlugins(string command)
	{
#if RETAIL
		if (_noDispatch || string.IsNullOrEmpty(command))
		{
			return false;
		}
		nint str = Marshal.StringToBSTR(command);
		try
		{
			return (DispatchOnChatCommand(ref str, 1) & 1) > 0;
		}
		catch (Exception ex)
		{
			_noDispatch = true;
			LogError(ex);
			return false;
		}
		finally
		{
			Marshal.FreeBSTR(str);
		}
#else
		return !string.IsNullOrEmpty(command) && CoreManager.Current.RaiseCommand(command);
#endif
	}

	public static void LogError(Exception ex)
	{
		try
		{
			File.AppendAllText(FullPath("MelkTank_errors.txt"), DateTime.Now.ToString() + "  " + ex?.ToString() + Environment.NewLine + Environment.NewLine);
		}
		catch
		{
		}
	}

	public static string Route(string fileName)
	{
		if (string.IsNullOrEmpty(fileName) || fileName.IndexOf('\\') >= 0 || fileName.IndexOf('/') >= 0)
		{
			return fileName;
		}
		if (fileName.StartsWith("MelkTankCore", StringComparison.OrdinalIgnoreCase) || fileName.EndsWith(".dll", StringComparison.OrdinalIgnoreCase))
		{
			return fileName;
		}
		if (fileName.Equals("Profiles", StringComparison.OrdinalIgnoreCase))
		{
			return Path.Combine("Profiles", "Monsters");
		}
		if (fileName.Equals("Snapshots", StringComparison.OrdinalIgnoreCase))
		{
			return Path.Combine("Settings", "Snapshots");
		}
		if (!fileName.StartsWith("MelkTank_", StringComparison.OrdinalIgnoreCase))
		{
			return fileName;
		}
		string[] logNames = LogNames;
		foreach (string value in logNames)
		{
			if (fileName.Equals(value, StringComparison.OrdinalIgnoreCase))
			{
				return Path.Combine("Logs", fileName);
			}
		}
		string[] charKinds = CharKinds;
		foreach (string text in charKinds)
		{
			if (fileName.StartsWith(text, StringComparison.OrdinalIgnoreCase))
			{
				string text2 = Path.GetFileNameWithoutExtension(fileName.Substring(text.Length));
				int num = text2.IndexOf('-');
				if (num > 0 && text2.Substring(0, num).IndexOf(' ') < 0 && text2.Substring(0, num).IndexOf('_') < 0)
				{
					text2 = text2.Substring(num + 1);
				}
				text2 = text2.Replace('_', ' ').Trim();
				char[] invalidFileNameChars = Path.GetInvalidFileNameChars();
				foreach (char c in invalidFileNameChars)
				{
					text2 = text2.Replace(c.ToString(), "");
				}
				if (text2.Length == 0)
				{
					break;
				}
				string path;
				switch (text)
				{
				default:
					path = "Settings";
					break;
				case "MelkTank_debug_":
				case "MelkTank_Perf_":
				case "MelkTank_PerfLog_":
				case "MelkTank_MemLog_":
					path = "Logs";
					break;
				}
				return Path.Combine(path, Path.Combine(text2, fileName));
			}
		}
		return Path.Combine("Settings", fileName);
	}

	/// <summary>The character's name for a file name: letters and digits kept, anything else an underscore.</summary>
	public static string CharFilePart()
	{
		string name = "";
		try { name = Globals.Core.CharacterFilter.Name ?? ""; } catch { }
		System.Text.StringBuilder sb = new System.Text.StringBuilder();
		foreach (char c in name) sb.Append(char.IsLetterOrDigit(c) ? c : '_');
		return sb.ToString();
	}

	/// <summary>A string as a JSON string, quotes and all (the phone's, the settings', the metas' JSON all use this one).</summary>
	public static string JsonQuote(string s)
	{
		System.Text.StringBuilder sb = new System.Text.StringBuilder("\"");
		foreach (char c in s ?? "")
		{
			switch (c)
			{
			case '"': sb.Append("\\\""); break;
			case '\\': sb.Append("\\\\"); break;
			case '\n': sb.Append("\\n"); break;
			case '\r': sb.Append("\\r"); break;
			case '\t': sb.Append("\\t"); break;
			default:
				if (c < ' ') sb.Append("\\u").Append(((int)c).ToString("x4"));
				else sb.Append(c);
				break;
			}
		}
		return sb.Append('"').ToString();
	}

	public static string FullPath(string fileName)
	{
		string text = Route(fileName);
		string text2 = Path.Combine(BasePath, text);
		if ((object)text != fileName && text != fileName)
		{
			Migrate(Path.Combine(BasePath, fileName), text2);
		}
		return text2;
	}

	public static void Migrate(string oldPath, string newPath)
	{
		lock (_migrated)
		{
			if (_migrated.TryGetValue(newPath, out var value) && (DateTime.Now - value).TotalSeconds < 60.0)
			{
				return;
			}
			_migrated[newPath] = DateTime.Now;
		}
		try
		{
			string directoryName = Path.GetDirectoryName(newPath);
			if (!Directory.Exists(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			if (File.Exists(oldPath))
			{
				Locked(newPath, () =>
				{
					if (File.Exists(oldPath) && !File.Exists(newPath))
					{
						File.Move(oldPath, newPath);
					}
					string[] array = new string[2] { ".bak", ".imported" };
					foreach (string text in array)
					{
						if (File.Exists(oldPath + text) && !File.Exists(newPath + text))
						{
							File.Move(oldPath + text, newPath + text);
						}
					}
				});
			}
			else if (Directory.Exists(oldPath))
			{
				MoveTree(oldPath, newPath);
			}
		}
		catch (Exception ex)
		{
			LogError(ex);
		}
	}

	public static void MoveTree(string from, string to)
	{
		try
		{
			if (!Directory.Exists(from))
			{
				return;
			}
			string text = Path.GetFullPath(from).TrimEnd(new char[2] { '\\', '/' });
			string text2 = Path.GetFullPath(to).TrimEnd(new char[2] { '\\', '/' });
			bool flag = text2.StartsWith(text + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase);
			if (!flag && !Directory.Exists(text2))
			{
				Directory.CreateDirectory(Path.GetDirectoryName(text2));
				Directory.Move(text, text2);
				return;
			}
			Directory.CreateDirectory(text2);
			string[] files = Directory.GetFiles(text);
			foreach (string text3 in files)
			{
				string text4 = Path.Combine(text2, Path.GetFileName(text3));
				if (!File.Exists(text4))
				{
					File.Move(text3, text4);
				}
			}
			if (flag)
			{
				return;
			}
			string[] directories = Directory.GetDirectories(text);
			foreach (string text5 in directories)
			{
				MoveTree(text5, Path.Combine(text2, Path.GetFileName(text5)));
			}
			try
			{
				if (Directory.GetFileSystemEntries(text).Length == 0)
				{
					Directory.Delete(text);
				}
			}
			catch
			{
			}
		}
		catch (Exception ex)
		{
			LogError(ex);
		}
	}

	public static string ProfilesDir(string name, bool moveOld = true)
	{
		string text = Path.Combine(Path.Combine(BasePath, "Profiles"), name);
		if (moveOld)
		{
			Migrate(Path.Combine(BasePath, name), text);
		}
		try
		{
			if (!Directory.Exists(text))
			{
				Directory.CreateDirectory(text);
			}
		}
		catch
		{
		}
		return text;
	}

	public static string FixOldPaths(string text)
	{
		if (string.IsNullOrEmpty(text))
		{
			return text;
		}
		string text2 = BasePath.TrimEnd(new char[2] { '\\', '/' });
		string[] array = new string[2] { "Navs", "Metas" };
		foreach (string text3 in array)
		{
			string text4 = text2 + "\\" + text3 + "\\";
			if (text.IndexOf(text4, StringComparison.OrdinalIgnoreCase) >= 0)
			{
				ProfilesDir(text3);
				text = Regex.Replace(text, Regex.Escape(text4), (text2 + "\\Profiles\\" + text3 + "\\").Replace("$", "$$"), RegexOptions.IgnoreCase);
			}
		}
		return text;
	}

	public static void SetBasePath(string dir)
	{
		if (!string.IsNullOrEmpty(dir))
		{
			_basePath = dir;
		}
	}

	public static void Locked(string path, Action a)
	{
		Mutex mutex = null;
		bool flag = false;
		try
		{
			try
			{
				mutex = new Mutex(initiallyOwned: false, "MelkTank_" + Path.GetFileName(path).Replace('\\', '_').Replace('/', '_'));
				try
				{
					flag = mutex.WaitOne(5000);
				}
				catch (AbandonedMutexException)
				{
					flag = true;
				}
			}
			catch
			{
			}
			a();
		}
		finally
		{
			if (flag)
			{
				try
				{
					mutex.ReleaseMutex();
				}
				catch
				{
				}
			}
			mutex?.Close();
		}
	}

	public static T Locked<T>(string path, Func<T> f)
	{
		T r = default;
		Locked(path, () =>
		{
			r = f();
		});
		return r;
	}

	public static void WriteShared(string path, string text)
	{
		Locked(path, () =>
		{
			string text2 = path + ".tmp";
			File.WriteAllText(text2, text);
			int num = 0;
			while (true)
			{
				try
				{
					File.Copy(text2, path, overwrite: true);
				}
				catch (IOException)
				{
					if (num >= 10)
					{
						throw;
					}
					Thread.Sleep(50);
					goto IL_0050;
				}
				break;
				IL_0050:
				num++;
			}
			try
			{
				File.Delete(text2);
			}
			catch
			{
			}
		});
	}

	public static void AppendShared(string path, string text)
	{
		Locked(path, () =>
		{
			int num = 0;
			while (true)
			{
				try
				{
					File.AppendAllText(path, text);
					break;
				}
				catch (IOException)
				{
					if (num >= 5)
					{
						throw;
					}
					Thread.Sleep(20);
				}
				num++;
			}
		});
	}

	public static void LoadXml(XmlDocument doc, string path)
	{
		Locked(path, () =>
		{
			doc.LoadXml(FixOldPaths(File.ReadAllText(path)));
		});
	}

	public static void SaveXml(XmlDocument doc, string path)
	{
		XmlWriterSettings xmlWriterSettings = new XmlWriterSettings();
		xmlWriterSettings.Indent = true;
		xmlWriterSettings.IndentChars = "  ";
		StringBuilder stringBuilder = new StringBuilder();
		using (StringWriter output = new StringWriterUtf8(stringBuilder))
		{
			using XmlWriter w = XmlWriter.Create(output, xmlWriterSettings);
			doc.Save(w);
		}
		WriteShared(path, stringBuilder.ToString());
	}

	public static object TryInvoke(object target, string method, params object[] args)
	{
		if (target == null)
		{
			return null;
		}
		try
		{
			Type[] array = new Type[args.Length];
			for (int i = 0; i < args.Length; i++)
			{
				array[i] = args[i].GetType();
			}
			MethodInfo method2 = target.GetType().GetMethod(method, array);
			if (method2 == null)
			{
				return null;
			}
			object obj = method2.Invoke(target, args);
			return obj ?? ((object)true);
		}
		catch
		{
			return null;
		}
	}

	public static object TryGetProperty(object target, string property)
	{
		if (target == null)
		{
			return null;
		}
		try
		{
			PropertyInfo property2 = target.GetType().GetProperty(property);
			return (property2 == null) ? null : property2.GetValue(target, null);
		}
		catch
		{
			return null;
		}
	}
}
