using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using MelkTank.Metas;
using AcClient;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Bounties;
using MelkTank.Buffs;

namespace MelkTank;

public static partial class Session
{
	private static bool AutoTrained(int id)
	{
		return Array.IndexOf(RtAuto, id) >= 0;
	}

	private static List<RtEntry> RtDefault()
	{
		List<RtEntry> list = new List<RtEntry>();
		int[] rtAll = RtAll;
		foreach (int skill in rtAll)
		{
			list.Add(new RtEntry
			{
				Skill = skill
			});
		}
		return list;
	}

	private static bool Ticked(RtEntry e)
	{
		return e.Train || e.Enl || (AutoTrained(e.Skill) && e.Spec);
	}

	private static string SkillName(int id)
	{
		string value;
		return RtNames.TryGetValue(id, out value) ? value : ("skill " + id);
	}

	private static string GemName(int id)
	{
		return SkillName(id) + " Gem of Enlightenment";
	}

	private static string RtSave()
	{
		List<string> list = new List<string> { (RtAfterEnl ? "1" : "0") + (RtSpecAtEnd ? "1" : "0") + (RtLevelSkills ? "1" : "0") };
		foreach (RtEntry item in Rt)
		{
			list.Add(item.Skill + ":" + (item.Train ? "1" : "0") + (item.Spec ? "1" : "0") + (item.Enl ? "1" : "0"));
		}
		return string.Join(",", list.ToArray());
	}

	private static void RtLoad(string s)
	{
		string[] array = s.Split(',');
		if (array.Length == 0 || array[0].Length < 2)
		{
			return;
		}
		RtSpecAtEnd = array[0][1] == '1';
		if (array[0].Length >= 3)
		{
			RtLevelSkills = array[0][2] == '1';
		}
		List<RtEntry> list = new List<RtEntry>();
		for (int i = 1; i < array.Length; i++)
		{
			string[] array2 = array[i].Split(':');
			if (array2.Length >= 2 && array2[1].Length >= 2 && int.TryParse(array2[0], out var id) && Array.IndexOf(RtAll, id) >= 0 && !list.Exists((RtEntry x) => x.Skill == id))
			{
				list.Add(new RtEntry
				{
					Skill = id,
					Train = (array2[1][0] == '1'),
					Spec = (array2[1][1] == '1'),
					Enl = (array2[1].Length >= 3 && array2[1][2] == '1')
				});
			}
		}
		int[] rtAll = RtAll;
		foreach (int id2 in rtAll)
		{
			if (!list.Exists((RtEntry x) => x.Skill == id2))
			{
				list.Add(new RtEntry
				{
					Skill = id2
				});
			}
		}
		Rt = list;
	}

	private static TrainingType Training(int skill)
	{
		try
		{
			return CoreManager.Current.CharacterFilter.Skills[(CharFilterSkillType)skill].Training;
		}
		catch
		{
			return TrainingType.Unusable;
		}
	}

	private static bool Untrained(int skill)
	{
		return Training(skill) == TrainingType.Untrained;
	}

#if RETAIL
	public unsafe static int SkillCost(int skill, bool spec)
	{
		DBObj* ptr = null;
		try
		{
			ptr = DBObj.GetByEnum(4, 2, 268435460u);
			if (ptr == null)
			{
				return -1;
			}
			GetSkillBaseDel getSkillBaseDel = (GetSkillBaseDel)Marshal.GetDelegateForFunctionPointer((IntPtr)4831408, typeof(GetSkillBaseDel));
			SkillBase* ptr2 = (SkillBase*)(void*)getSkillBaseDel((IntPtr)ptr, (uint)skill);
			if (ptr2 == null)
			{
				return -1;
			}
			return (int)((!spec) ? ptr2->_trained_cost : ptr2->_specialized_cost);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			return -1;
		}
		finally
		{
			try
			{
				if (ptr != null)
				{
					ptr->Release();
				}
			}
			catch
			{
			}
		}
	}
#else
	public static int SkillCost(int skill, bool spec)
	{
		return -1;
	}
#endif

	public static string TrainSkill(int skill)
	{
		if (!Untrained(skill))
		{
			return SkillName(skill) + " isn't untrained";
		}
		int num = SkillCost(skill, spec: false);
		if (num <= 0)
		{
			return "couldn't read what " + SkillName(skill) + " costs";
		}
		int num2 = 0;
		try
		{
			num2 = CoreManager.Current.CharacterFilter.SkillPoints;
		}
		catch
		{
		}
		if (num2 < num)
		{
			return "not enough skill credits for " + SkillName(skill) + " (" + num2 + " of " + num + ")";
		}
		CM_Train.Event_TrainSkillAdvancementClass((uint)skill, (uint)num);
		return null;
	}

	public static bool Wield(int id)
	{
		try
		{
			CoreManager current = CoreManager.Current;
			int num = current.WorldFilter[id]?.Values(LongValueKey.EquipableSlots, 0) ?? 0;
			bool flag = num != 0 && (num & (num - 1)) == 0;
			if (flag)
			{
				int num2 = (((num & 0x3700000) != 0) ? 57671680 : num);
				int id2 = current.CharacterFilter.Id;
				foreach (WorldObject item in InvCache.All())
				{
					if (item.Id != id && item.Values(LongValueKey.Wielder, 0) == id2 && (item.Values(LongValueKey.EquippedSlots, 0) & num2) != 0)
					{
						flag = false;
						break;
					}
				}
			}
			if (flag)
			{
				CM_Inventory.Event_GetAndWieldItem((uint)id, (uint)num);
				return true;
			}
			current.Actions.UseItem(id, 0);
			return true;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			return false;
		}
	}

	private static WorldObject VendorItem(string name)
	{
		try
		{
			Vendor openVendor = CoreManager.Current.WorldFilter.OpenVendor;
			if (openVendor == null || openVendor.MerchantId == 0)
			{
				return null;
			}
			foreach (WorldObject item in openVendor)
			{
				if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
				{
					return item;
				}
			}
		}
		catch
		{
		}
		return null;
	}

	private static bool BuyOne(WorldObject item)
	{
		try
		{
			HooksWrapper actions = CoreManager.Current.Actions;
			actions.VendorClearBuyList();
			actions.VendorAddBuyList(item.Id, 1);
			actions.VendorBuyAll();
			return true;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			return false;
		}
	}

	private static void BuyGems()
	{
		List<string> list = new List<string>();
		List<string> list2 = new List<string>();
		try
		{
			HooksWrapper actions = CoreManager.Current.Actions;
			actions.VendorClearBuyList();
			foreach (RtEntry item in Rt)
			{
				if (item.Spec && Training(item.Skill) != TrainingType.Specialized && FirstStack(GemName(item.Skill)) == 0)
				{
					WorldObject worldObject = VendorItem(GemName(item.Skill));
					if (worldObject == null)
					{
						list2.Add(SkillName(item.Skill));
						continue;
					}
					actions.VendorAddBuyList(worldObject.Id, 1);
					list.Add(SkillName(item.Skill));
				}
			}
			if (list.Count > 0)
			{
				actions.VendorBuyAll();
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		Util.WriteToChat("Buy gems: " + ((list.Count > 0) ? ("bought " + string.Join(", ", list.ToArray())) : "nothing needed") + ((list2.Count > 0) ? ("; this vendor doesn't sell " + string.Join(", ", list2.ToArray())) : "") + ".");
	}

	private static bool RtNeedsTraining()
	{
		foreach (RtEntry item in Rt)
		{
			if (item.Enl && Untrained(item.Skill))
			{
				return true;
			}
		}
		return false;
	}

	private static void RtStart(bool spec)
	{
		_rtOn = true;
		_rtSpec = spec;
		_rtIdx = 0;
		_rtPhase = 0;
		_rtWait = 0;
		_rtFailed = null;
		_rtMissing.Clear();
		_rtSkipped.Clear();
		_rtStatus = "starting";
	}

	private static void RtDone(string failed)
	{
		_rtOn = false;
		_rtFailed = failed;
		if (RtLevelSkills && failed != "stopped")
		{
			Util.Command("/ilt levelskills");
		}
		List<string> list = new List<string>();
		list.AddRange(_rtSkipped);
		list.AddRange(_rtMissing);
		_rtStatus = failed ?? ("done" + ((list.Count > 0) ? (" - " + string.Join("; ", list.ToArray())) : ""));
		Util.WriteToChat("Retrain: " + _rtStatus + ".");
	}

	private static int FreeCredits()
	{
		try
		{
			return CoreManager.Current.CharacterFilter.SkillPoints;
		}
		catch
		{
			return 0;
		}
	}

	private static void RtTick()
	{
		if (!_rtOn)
		{
			return;
		}
		try
		{
			if (_rtWait != 0)
			{
				TrainingType trainingType = ((_rtPhase == 0) ? TrainingType.Trained : TrainingType.Specialized);
				if (Training(_rtWait) >= trainingType)
				{
					_rtWait = 0;
				}
				else if (!((DateTime.Now - _rtAt).TotalSeconds < (double)((_rtPhase == 0) ? 3 : 6)))
				{
					_rtSkipped.Add("stopped at " + SkillName(_rtWait) + ((_rtPhase == 0) ? " - it didn't train" : " - it didn't specialize"));
					RtDone(null);
				}
				return;
			}
			while (_rtIdx < Rt.Count)
			{
				RtEntry rtEntry = Rt[_rtIdx];
				TrainingType trainingType2 = Training(rtEntry.Skill);
				bool flag = (_rtSpec ? rtEntry.Train : rtEntry.Enl);
				bool flag2 = _rtSpec && rtEntry.Spec;
				if (flag && trainingType2 == TrainingType.Untrained)
				{
					int num = SkillCost(rtEntry.Skill, spec: false);
					if (num <= 0)
					{
						_rtSkipped.Add("stopped at " + SkillName(rtEntry.Skill) + " - its cost couldn't be read");
						RtDone(null);
					}
					else if (FreeCredits() < num)
					{
						_rtSkipped.Add("stopped at " + SkillName(rtEntry.Skill) + " - needs " + num + " credits, have " + FreeCredits());
						RtDone(null);
					}
					else
					{
						CM_Train.Event_TrainSkillAdvancementClass((uint)rtEntry.Skill, (uint)num);
						_rtPhase = 0;
						_rtWait = rtEntry.Skill;
						_rtAt = DateTime.Now;
						_rtStatus = "training " + SkillName(rtEntry.Skill);
					}
					return;
				}
				if (flag2 && trainingType2 == TrainingType.Trained)
				{
					int num2 = SkillCost(rtEntry.Skill, spec: false);
					int num3 = SkillCost(rtEntry.Skill, spec: true);
					if (num2 > 0 && num3 > num2 && FreeCredits() < num3 - num2)
					{
						_rtSkipped.Add("stopped at " + SkillName(rtEntry.Skill) + " - specializing needs " + (num3 - num2) + " credits, have " + FreeCredits());
						RtDone(null);
						return;
					}
					int num4 = FirstStack(GemName(rtEntry.Skill));
					if (num4 == 0)
					{
						WorldObject worldObject = VendorItem(GemName(rtEntry.Skill));
						if (worldObject == null)
						{
							_rtMissing.Add("stopped at " + SkillName(rtEntry.Skill) + " - no " + GemName(rtEntry.Skill) + " (open the gem vendor and press Train / spec now)");
							RtDone(null);
						}
						else if (_rtStatus == "buying " + GemName(rtEntry.Skill))
						{
							if (!((DateTime.Now - _rtAt).TotalSeconds < 6.0))
							{
								_rtMissing.Add("stopped at " + SkillName(rtEntry.Skill) + " - the gem didn't arrive");
								RtDone(null);
							}
						}
						else
						{
							BuyOne(worldObject);
							_rtAt = DateTime.Now;
							_rtStatus = "buying " + GemName(rtEntry.Skill);
						}
					}
					else
					{
						CoreManager.Current.Actions.UseItem(num4, 0);
						_rtPhase = 1;
						_rtWait = rtEntry.Skill;
						_rtAt = DateTime.Now;
						_rtStatus = "specializing " + SkillName(rtEntry.Skill);
					}
					return;
				}
				_rtIdx++;
			}
			RtDone(null);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			RtDone("error: " + ex.Message);
		}
	}

	private static void DrawRetrain()
	{
		Vector4 vector = new Vector4(0.6f, 0.6f, 0.6f, 1f);
		Vector4 vector2 = new Vector4(0.45f, 0.9f, 0.45f, 1f);
		Im.TextColored(vector, "Enl column: trained after each enlighten (auto enlighten, no gems). Train / Spec: Train / spec now, and the end of a run.");
		if (ImGui.Checkbox("When the run finishes, train / spec (Train and Spec columns)##rtend", ref RtSpecAtEnd))
		{
			_deedsDirtyAt = DateTime.Now;
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Once auto enlighten reaches the target or runs out of luminance / tokens / medallions (an enlighten would undo it):\nthe same as pressing Train / spec now. Gems you don't carry are bought from the open vendor.");
		}
		if (ImGui.Checkbox("Then /ilt levelskills##rtlvl", ref RtLevelSkills))
		{
			_deedsDirtyAt = DateTime.Now;
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("At the end of every retrain, sends /ilt levelskills - the server raises every skill it can to the max.");
		}
		if (ImGui.Button(_rtOn ? "Stop##rtnow" : "Train / spec now##rtnow"))
		{
			if (_rtOn)
			{
				RtDone("stopped");
			}
			else
			{
				RtStart(spec: true);
			}
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Goes down the list in order: trains each ticked skill, then specializes it if \"Spec\" is ticked, before the next one.\nStops at the first one your skill credits don't cover (it's still trained if specializing is what it can't afford), or whose gem you don't carry with no gem vendor open.\nGems are bought from the open vendor (1p, from the bank). Then /ilt levelskills.");
		}
		ImGui.SameLine();
		bool flag = false;
		try
		{
			Vendor openVendor = CoreManager.Current.WorldFilter.OpenVendor;
			flag = openVendor != null && openVendor.MerchantId != 0;
		}
		catch
		{
		}
		if (!flag)
		{
			ImGui.BeginDisabled();
		}
		if (ImGui.Button("Buy gems now##rtbuy"))
		{
			BuyGems();
		}
		if (!flag)
		{
			ImGui.EndDisabled();
		}
		if (ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenDisabled))
		{
			Im.SetTooltip(flag ? "Buys one gem for each \"Spec\" skill that isn't specialized yet and you don't already carry (1p each, from the bank)." : "Open the gem vendor first.");
		}
		ImGui.SameLine();
		int num = 0;
		try
		{
			num = CoreManager.Current.CharacterFilter.SkillPoints;
		}
		catch
		{
		}
		Im.TextColored(vector, "Credits " + num + ((_rtStatus.Length > 0) ? (" | " + _rtStatus) : ""));
		if (!ImGui.BeginTable("##rt2", 7, ImGuiTableFlags.RowBg | ImGuiTableFlags.BordersInnerV | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY, new Vector2(0f, ImGui.GetContentRegionAvail().Y)))
		{
			return;
		}
		ImGui.TableSetupScrollFreeze(0, 1);
		ImGui.TableSetupColumn("Train", ImGuiTableColumnFlags.WidthFixed, 44f);
		ImGui.TableSetupColumn("Spec", ImGuiTableColumnFlags.WidthFixed, 40f);
		ImGui.TableSetupColumn("Enl", ImGuiTableColumnFlags.WidthFixed, 34f);
		ImGui.TableSetupColumn("Order", ImGuiTableColumnFlags.WidthFixed, 56f);
		ImGui.TableSetupColumn("Skill", ImGuiTableColumnFlags.WidthStretch);
		ImGui.TableSetupColumn("Now", ImGuiTableColumnFlags.WidthFixed, 84f);
		ImGui.TableSetupColumn("Cost", ImGuiTableColumnFlags.WidthFixed, 70f);
		ImGui.TableHeadersRow();
		int num2 = -1;
		int num3 = 0;
		bool flag2 = false;
		for (int i = 0; i < Rt.Count; i++)
		{
			RtEntry rtEntry = Rt[i];
			ImGui.PushID(rtEntry.Skill);
			ImGui.TableNextRow();
			ImGui.TableNextColumn();
			bool flag3 = AutoTrained(rtEntry.Skill);
			if (flag3)
			{
				rtEntry.Train = false;
				rtEntry.Enl = false;
				ImGui.BeginDisabled();
			}
			if (ImGui.Checkbox("##t", ref rtEntry.Train))
			{
				_deedsDirtyAt = DateTime.Now;
			}
			if (flag3)
			{
				ImGui.EndDisabled();
			}
			if (flag3 && ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenDisabled))
			{
				Im.SetTooltip("Comes trained - it can only be specialized");
			}
			ImGui.TableNextColumn();
			if (ImGui.Checkbox("##s", ref rtEntry.Spec))
			{
				if (rtEntry.Spec && !flag3)
				{
					rtEntry.Train = true;
				}
				_deedsDirtyAt = DateTime.Now;
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Specialize it with " + GemName(rtEntry.Skill));
			}
			ImGui.TableNextColumn();
			if (flag3)
			{
				ImGui.BeginDisabled();
			}
			if (ImGui.Checkbox("##e", ref rtEntry.Enl))
			{
				_deedsDirtyAt = DateTime.Now;
			}
			if (flag3)
			{
				ImGui.EndDisabled();
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Train it after each enlighten (auto enlighten) - no gems");
			}
			ImGui.TableNextColumn();
			if (Im.UpButton("##u"))
			{
				num2 = i;
				num3 = -1;
				flag2 = Im.Far;
				Im.Far = false;
			}
			ImGui.SameLine(0f, 2f);
			if (Im.DownButton("##d"))
			{
				num2 = i;
				num3 = 1;
				flag2 = Im.Far;
				Im.Far = false;
			}
			ImGui.TableNextColumn();
			if (rtEntry.Train || rtEntry.Enl || (flag3 && rtEntry.Spec))
			{
				Im.Text(SkillName(rtEntry.Skill));
			}
			else
			{
				Im.TextColored(vector, SkillName(rtEntry.Skill));
			}
			ImGui.TableNextColumn();
			TrainingType trainingType = Training(rtEntry.Skill);
			Im.TextColored((trainingType >= TrainingType.Trained) ? vector2 : vector, trainingType switch
			{
				TrainingType.Untrained => "untrained", 
				TrainingType.Trained => "trained", 
				TrainingType.Specialized => "specialized", 
				_ => "-", 
			});
			ImGui.TableNextColumn();
			Im.TextColored(vector, RtCostText(rtEntry.Skill));
			ImGui.PopID();
		}
		if (num2 >= 0)
		{
			int j;
			for (j = num2 + num3; j >= 0 && j < Rt.Count; j += num3)
			{
				if (!Ticked(Rt[num2]))
				{
					break;
				}
				if (Ticked(Rt[j]))
				{
					break;
				}
			}
			if (flag2)
			{
				if (num3 < 0)
				{
					j = 0;
				}
				else
				{
					j = Rt.Count - 1;
					if (Ticked(Rt[num2]))
					{
						int val = Rt.FindLastIndex((RtEntry x) => Ticked(x));
						j = Math.Max(num2, val);
					}
				}
			}
			if (j >= 0 && j < Rt.Count)
			{
				RtEntry item = Rt[num2];
				Rt.RemoveAt(num2);
				Rt.Insert(j, item);
				_deedsDirtyAt = DateTime.Now;
			}
		}
		ImGui.EndTable();
	}

	private static string RtCostText(int skill)
	{
		if (_rtCost.TryGetValue(skill, out var value))
		{
			return value;
		}
		int num = SkillCost(skill, spec: false);
		int num2 = SkillCost(skill, spec: true);
		value = ((num < 0) ? "?" : (num + ((num2 > 0) ? (" / " + num2) : "")));
		if (num >= 0)
		{
			_rtCost[skill] = value;
		}
		return value;
	}
}
