using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
#if !RETAIL
using ACGodot.DecalShim;
using ACGodot.Plugins;
using ACGodot.UI;
#endif
#if !RETAIL
using AcClient;
#else
using SmartBox = AcClient.SmartBox;
using ACCmdInterp = AcClient.ACCmdInterp;
using CommandInterpreter = AcClient.CommandInterpreter;
using CommandListElement = AcClient.CommandListElement;
using CPhysicsObj = AcClient.CPhysicsObj;
using Position = AcClient.Position;
using CTransition = AcClient.CTransition;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
#if !RETAIL
using Godot;
#endif
using ImGuiNET;
using MelkTank.Loot;
using MelkTank.Metas;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public partial class Nav
{
	public void MetaStart()
	{
		if (_meta == null)
		{
			Util.WriteToChat("Meta: no meta open (Nav > Meta).");
			return;
		}
		if (!_s.MetaRun)
		{
			_s.MetaRun = true;
			if (SaveAll != null)
			{
				SaveAll();
			}
		}
		_mMeta = _meta;
		List<string> list = _meta.States();
		_mCalls.Clear();
		MetaSetState(list.Contains("Default") ? "Default" : list[0], persistReset: true);
		Util.WriteToChat("Meta: " + _meta.Name + " running (state " + _mState + ").");
	}

	public void MetaStartAt(string state, MRule from)
	{
		if (_meta == null)
		{
			return;
		}
		if (!_s.MetaRun)
		{
			_s.MetaRun = true;
			if (SaveAll != null)
			{
				SaveAll();
			}
		}
		_mMeta = _meta;
		_mCalls.Clear();
		MetaSetState(state, persistReset: true);
		if (from != null)
		{
			foreach (MRule rule in _meta.Rules)
			{
				if (rule == from)
				{
					break;
				}
				if (rule.State == state)
				{
					_mFired.Add(rule);
				}
			}
		}
		Util.WriteToChat("Meta: " + _meta.Name + " running from " + state + ((from != null) ? (" (rule " + MetaText.Describe(from.C) + ")") : "") + ".");
	}

	public void MetaStop(bool quiet = false)
	{
		if (_s.MetaRun)
		{
			_s.MetaRun = false;
			if (SaveAll != null)
			{
				SaveAll();
			}
		}
		_wdOn = false;
		if (!quiet)
		{
			Util.WriteToChat("Meta: stopped.");
		}
		MLog("stopped");
	}

	private void GoState(string state)
	{
		if (state == _mState && !_s.MetaSameRestarts)
		{
			MLog("already in " + state + " - carrying on");
		}
		else
		{
			MetaSetState(state, persistReset: true);
		}
	}

	public void MetaSetState(string state, bool persistReset)
	{
		if (!string.IsNullOrEmpty(state))
		{
			if (_meta != null && !_meta.States().Contains(state))
			{
				MWarn("nostate:" + state, "there's no state called " + state + " - staying in it does nothing.");
			}
			if (state != _mState)
			{
				MLog("state " + _mState + " -> " + state);
			}
			else
			{
				MLog("state " + state + " again");
			}
			_mState = state;
			_mStateAt = DateTime.Now;
			if (persistReset)
			{
				_mStatePersistAt = DateTime.Now;
			}
			_mFired.Clear();
			_mChat.Clear();
			_mDied = (_mPortalIn = (_mPortalOut = false));
			_mVendorSeen = VendorOpen();
			_wdOn = false;
		}
	}

	public void MetaChat(string text)
	{
		if (MetaRunning && !string.IsNullOrEmpty(text))
		{
			_mChat.Add(text.TrimEnd(new char[2] { '\r', '\n' }));
			if (_mChat.Count > 200)
			{
				_mChat.RemoveAt(0);
			}
		}
	}

	public void MetaNoteDeath()
	{
		_mDied = true;
	}

	public void MetaNotePortal(bool enter)
	{
		if (enter)
		{
			_mPortalIn = true;
		}
		else
		{
			_mPortalOut = true;
		}
	}

	public void MetaTick()
	{
		RestoreHotState();
		bool metaRunning = MetaRunning;
		if (!_metaSeen)
		{
			_metaSeen = true;
			_metaWasRunning = metaRunning;
			if (!metaRunning)
			{
				_s.MetaTurnedNavOn = false;
			}
		}
		if (_metaWasRunning && !metaRunning && _s.MetaTurnedNavOn)
		{
			_s.MetaTurnedNavOn = false;
			if (_s.NavEnabled)
			{
				_s.NavEnabled = false;
				Stop();
				if (SaveAll != null)
				{
					SaveAll();
				}
				Util.WriteToChat("Meta stopped - Nav switched off (the meta had switched it on).");
			}
		}
		_metaWasRunning = metaRunning;
		if (!_metaTriedLast)
		{
			_metaTriedLast = true;
			if (_meta == null && _s.MetaOpenLast && !string.IsNullOrEmpty(_s.MetaLast) && File.Exists(_s.MetaLast))
			{
				OpenMeta(_s.MetaLast);
			}
		}
		if (!MetaRunning || DateTime.Now < _mNextTick)
		{
			return;
		}
		_mNextTick = DateTime.Now.AddMilliseconds(200.0);
		if (_mMeta != _meta)
		{
			_mMeta = _meta;
			_mCalls.Clear();
			List<string> list = _meta.States();
			MetaSetState(list.Contains("Default") ? "Default" : list[0], persistReset: true);
		}
		if (_inPortal || (DateTime.Now - _portalExitAt).TotalSeconds < 2.0 || (_diedAt > _portalExitAt && (DateTime.Now - _diedAt).TotalSeconds < 30.0))
		{
			if (!_mWasWaiting)
			{
				MLog("waiting - portal space");
			}
			_mWasWaiting = true;
			return;
		}
		_mWasWaiting = false;
		if (VendorOpen())
		{
			_mVendorSeen = true;
		}
		if (_wdOn && MyPos(out var ns, out var ew, out var _))
		{
			double num = Math.Sqrt(Math.Pow((ns - _wdNS) * 240.0, 2.0) + Math.Pow((ew - _wdEW) * 240.0, 2.0));
			if (num >= _wdDist)
			{
				_wdNS = ns;
				_wdEW = ew;
				_wdAt = DateTime.Now;
			}
			else if ((DateTime.Now - _wdAt).TotalSeconds >= _wdSecs)
			{
				MLog("watchdog: moved " + num.ToString("0.0") + " m in " + _wdSecs + " s -> " + _wdState);
				string wdState = _wdState;
				_wdOn = false;
				MetaSetState(wdState, persistReset: true);
				return;
			}
		}
		foreach (MRule rule in _meta.Rules)
		{
			if (rule.State != _mState || _mFired.Contains(rule))
			{
				continue;
			}
			bool flag;
			try
			{
				flag = Cond(rule.C);
			}
			catch (Exception ex)
			{
				MWarn("cerr:" + ex.Message, "a condition failed: " + ex.Message);
				flag = false;
			}
			if (!flag)
			{
				continue;
			}
			_mFired.Add(rule);
			try
			{
				Act(rule.A);
				break;
			}
			catch (Exception ex2)
			{
				MWarn("aerr:" + ex2.Message, "an action failed: " + ex2.Message);
				break;
			}
		}
	}

	private bool Cond(MCond c)
	{
		if (c == null)
		{
			return false;
		}
		MVal data = c.Data;
		switch (c.Type)
		{
		case 0:
			return false;
		case 1:
			return true;
		case 2:
			if (c.Kids == null)
			{
				return true;
			}
			foreach (MCond kid in c.Kids)
			{
				if (!Cond(kid))
				{
					return false;
				}
			}
			return true;
		case 3:
			if (c.Kids == null)
			{
				return false;
			}
			foreach (MCond kid2 in c.Kids)
			{
				if (Cond(kid2))
				{
					return true;
				}
			}
			return false;
		case 21:
			return c.Kids != null && c.Kids.Count > 0 && !Cond(c.Kids[0]);
		case 4:
		{
			Regex regex2 = Rx((data != null) ? data.S : "");
			if (regex2 == null)
			{
				return false;
			}
			foreach (string item in _mChat)
			{
				if (regex2.IsMatch(item))
				{
					return true;
				}
			}
			return false;
		}
		case 28:
		{
			Regex regex = Rx(data.GetS("p"));
			if (regex == null)
			{
				return false;
			}
			foreach (string item2 in _mChat)
			{
				Match match = regex.Match(item2);
				if (!match.Success)
				{
					continue;
				}
				string[] groupNames = regex.GetGroupNames();
				foreach (string text in groupNames)
				{
					if (!int.TryParse(text, out var _))
					{
						UbExpr.SetVar("capturegroup_" + text, match.Groups[text].Value);
					}
				}
				return true;
			}
			return false;
		}
		case 5:
			return Character.MainPackFreeSlots() <= (data?.AsInt ?? 0);
		case 6:
			return (DateTime.Now - _mStateAt).TotalSeconds >= (double)(data?.AsInt ?? 0);
		case 22:
			return (DateTime.Now - _mStatePersistAt).TotalSeconds >= (double)(data?.AsInt ?? 0);
		case 7:
			return RouteEmpty();
		case 8:
			return _mDied;
		case 100:
		{
			if (VendorRun.LastAt < _mStateAt || (VendorRun.I != null && VendorRun.I.Busy))
			{
				return false;
			}
			string text3 = (data.GetS("r") ?? "").Trim().ToLowerInvariant();
			return text3.Length == 0 || text3 == "any" || text3 == VendorRun.ResultWord(VendorRun.Last);
		}
		case 9:
			return VendorOpen();
		case 10:
			return _mVendorSeen && !VendorOpen();
		case 11:
			return ItemCount(data.GetS("n")) <= Int(data.GetS("c"));
		case 12:
			return ItemCount(data.GetS("n")) >= Int(data.GetS("c"));
		case 13:
			return MobsNear(Rx(data.GetS("n")), int.MinValue, Dbl(data.GetS("r"))) >= Int(data.GetS("c"));
		case 14:
			return MobsNear(null, Int(data.GetS("p")), Dbl(data.GetS("r"))) >= Int(data.GetS("c"));
		case 16:
			return MobsNear(null, int.MinValue, Dbl(data.GetS("r"))) == 0;
		case 15:
			return MetaNeedBuff != null && MetaNeedBuff();
		case 17:
			return (Globals.Core.Actions.Landcell & -65536) == ((data?.AsInt ?? 0) & -65536);
		case 18:
			return Globals.Core.Actions.Landcell == (data?.AsInt ?? 0);
		case 19:
			return _mPortalIn;
		case 20:
			return _mPortalOut;
		case 23:
		{
			int num2 = Int(data.GetS("sid"));
			double num3 = Dbl(data.GetS("sec"));
			foreach (EnchantmentWrapper enchantment in Globals.Core.CharacterFilter.Enchantments)
			{
				if (enchantment.SpellId == num2 && (enchantment.TimeRemaining < 0 || (double)enchantment.TimeRemaining >= num3))
				{
					return true;
				}
			}
			return false;
		}
		case 24:
			return BurdenPct() >= (double)(data?.AsInt ?? 0);
		case 25:
		{
			double num = NearestRoutePointM();
			return num < 0.0 || num >= (double)(data?.AsInt ?? 0);
		}
		case 26:
		{
			object v = UbExpr.Eval(data.GetS("e"), out var error);
			if (error != null)
			{
				MWarn("experr:" + data.GetS("e"), "expression error in " + _mState + ": " + error);
			}
			return UbExpr.Truthy(v);
		}
		case 27:
			MWarn("dialog", "'client dialog popup' conditions aren't supported yet - they count as false.");
			return false;
		default:
			MWarn("cond" + c.Type, "condition " + MetaText.CondName(c.Type) + " isn't supported - it counts as false.");
			return false;
		}
	}

	private Regex Rx(string p)
	{
		if (p == null)
		{
			return null;
		}
		if (_mRx.TryGetValue(p, out var value))
		{
			return value;
		}
		try
		{
			value = new Regex(p, RegexOptions.IgnoreCase);
		}
		catch (Exception ex)
		{
			MWarn("rx:" + p, "bad pattern \"" + p + "\": " + ex.Message);
			value = null;
		}
		_mRx[p] = value;
		return value;
	}

	private static int Int(string s)
	{
		if (int.TryParse(s, out var result))
		{
			return result;
		}
		double result2;
		return double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out result2) ? ((int)result2) : 0;
	}

	private static double Dbl(string s)
	{
		double result;
		return double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out result) ? result : 0.0;
	}

	private static bool VendorOpen()
	{
		try
		{
			return Globals.Core.Actions.VendorId != 0;
		}
		catch
		{
			return false;
		}
	}

	private static int ItemCount(string name)
	{
		int num = 0;
		if (string.IsNullOrEmpty(name))
		{
			return 0;
		}
		foreach (WorldObject item in InvCache.All())
		{
			if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
			{
				int num2 = 1;
				try
				{
					num2 = Math.Max(1, item.Values(LongValueKey.StackCount, 1));
				}
				catch
				{
				}
				num += num2;
			}
		}
		return num;
	}

	private int MobsNear(Regex name, int priority, double metres)
	{
		int num = 0;
		foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
		{
			if (item.ObjectClass != ObjectClass.Monster || item.Name.IndexOf("'s ", StringComparison.Ordinal) > 0)
			{
				continue;
			}
			try
			{
				if (item.Values(LongValueKey.CreateFlags2) != 0)
				{
					continue;
				}
			}
			catch
			{
			}
			if (name != null && !name.IsMatch(item.Name))
			{
				continue;
			}
			if (priority != int.MinValue)
			{
				try
				{
					if (_s.FindRule(item).Priority != priority)
					{
						continue;
					}
				}
				catch
				{
					continue;
				}
			}
			double num2 = CombatEngine.Distance(item);
			if (num2 >= 0.0 && num2 <= metres)
			{
				num++;
			}
		}
		return num;
	}

	private static double BurdenPct()
	{
		try
		{
			int num = Globals.Core.Actions.Attribute[AttributeType.CurrentStrength];
			int num2 = 0;
			WorldObject worldObject = Globals.Core.WorldFilter[Globals.Core.CharacterFilter.Id];
			try
			{
				if (worldObject != null)
				{
					num2 = worldObject.Values((LongValueKey)230, 0);
				}
			}
			catch
			{
			}
			double num3 = (double)num * (150.0 + 30.0 * (double)num2);
			if (num3 <= 0.0)
			{
				return 0.0;
			}
			long num4 = 0L;
			foreach (WorldObject item in InvCache.All())
			{
				try
				{
					num4 += item.Values(LongValueKey.Burden, 0);
				}
				catch
				{
				}
			}
			return (double)num4 * 100.0 / num3;
		}
		catch
		{
			return 0.0;
		}
	}

	public bool RouteEmpty()
	{
		NavRoute currentRoute = CurrentRoute;
		return currentRoute == null || currentRoute.Steps.Count == 0 || _rDone;
	}

	public double NearestRoutePointM()
	{
		NavRoute currentRoute = CurrentRoute;
		if (currentRoute == null || !MyPos(out var ns, out var ew, out var _))
		{
			return -1.0;
		}
		double num = -1.0;
		foreach (RouteStep step in currentRoute.Steps)
		{
			if (step.Kind == StepKind.Point || step.Kind == StepKind.Use)
			{
				double num2 = Math.Sqrt(Math.Pow((step.NS - ns) * 240.0, 2.0) + Math.Pow((step.EW - ew) * 240.0, 2.0));
				if (num < 0.0 || num2 < num)
				{
					num = num2;
				}
			}
		}
		return num;
	}

	private void Act(MAct a)
	{
		if (a == null)
		{
			return;
		}
		MVal data = a.Data;
		switch (a.Type)
		{
		case 0:
			break;
		case 1:
			GoState((data != null) ? data.S : "");
			break;
		case 2:
			MetaCommand((data != null) ? data.S : "");
			break;
		case 3:
			if (a.Kids == null)
			{
				break;
			}
			{
				foreach (MAct kid in a.Kids)
				{
					Act(kid);
				}
				break;
			}
		case 4:
			LoadEmbedded(data);
			break;
		case 5:
			_mCalls.Push(data.GetS("ret"));
			if (_mCalls.Count > 50)
			{
				MWarn("calldepth", "more than 50 calls without a return - the call list was cleared.");
				_mCalls.Clear();
			}
			MetaSetState(data.GetS("st"), persistReset: true);
			break;
		case 6:
			if (_mCalls.Count == 0)
			{
				MWarn("noreturn", "'return from call' with nothing to return to - ignored.");
			}
			else
			{
				MetaSetState(_mCalls.Pop(), persistReset: false);
			}
			break;
		case 7:
		{
			UbExpr.Eval(data.GetS("e"), out var error3);
			if (error3 != null)
			{
				MWarn("experr:" + data.GetS("e"), "expression error in " + _mState + ": " + error3);
			}
			break;
		}
		case 8:
		{
			object v2 = UbExpr.Eval(data.GetS("e"), out var error2);
			if (error2 != null)
			{
				MWarn("experr:" + data.GetS("e"), "expression error in " + _mState + ": " + error2);
			}
			else
			{
				MetaCommand(UbExpr.Text(v2));
			}
			break;
		}
		case 9:
		{
			_wdState = data.GetS("s");
			_wdDist = Dbl(data.GetS("r"));
			_wdSecs = Dbl(data.GetS("t"));
			if (MyPos(out var ns, out var ew, out var _))
			{
				_wdNS = ns;
				_wdEW = ew;
			}
			_wdAt = DateTime.Now;
			_wdOn = true;
			MLog("watchdog set: " + _wdDist + " m in " + _wdSecs + " s or go to " + _wdState);
			break;
		}
		case 10:
			_wdOn = false;
			break;
		case 11:
			UbExpr.SetVar(data.GetS("v"), (OptGet(data.GetS("o")) == "1") ? 1.0 : 0.0);
			break;
		case 12:
		{
			string text = data.GetS("v");
			if (text.StartsWith("$"))
			{
				object v = UbExpr.Eval(text, out var error);
				if (error != null)
				{
					MWarn("experr:" + text, "couldn't read " + text + ": " + error);
					break;
				}
				text = (UbExpr.Truthy(v) ? "1" : "0");
			}
			OptSet(data.GetS("o"), text);
			break;
		}
		case 100:
			UseByName(data.GetS("n"), 0);
			break;
		case 101:
			UseByName(data.GetS("n"), 1);
			break;
		case 102:
			UseByName(data.GetS("n"), 2);
			break;
		case 103:
			GiveTo(data.GetS("i"), data.GetS("n"));
			break;
		case 105:
			MLog("vendor at " + data.GetS("n") + ((data.GetS("p").Length > 0) ? (" with " + data.GetS("p")) : ""));
			VendorRun.I?.Start(data.GetS("n"), data.GetS("p"), dry: false);
			break;
		case 104:
			MLog("load route " + data.GetS("n"));
			VtCommand("/vt nav load " + data.GetS("n"));
			break;
		case 13:
		case 14:
		case 15:
			MWarn("views", "meta views (windows of buttons) aren't supported yet - those actions are skipped.");
			break;
		default:
			MWarn("act" + a.Type, "action " + MetaText.ActName(a.Type) + " isn't supported - skipped.");
			break;
		}
	}
}
