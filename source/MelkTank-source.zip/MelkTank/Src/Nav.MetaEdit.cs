using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
#if !RETAIL
using ACGodot.DecalShim;
using ACGodot.Plugins;
using ACGodot.UI;
#endif
#if !RETAIL
using AcClient;
#else
using SmartBox = AcClient.SmartBox;
using ACCmdInterp = AcClient.ACCmdInterp;
using CommandInterpreter = AcClient.CommandInterpreter;
using CommandListElement = AcClient.CommandListElement;
using CPhysicsObj = AcClient.CPhysicsObj;
using Position = AcClient.Position;
using CTransition = AcClient.CTransition;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
#if !RETAIL
using Godot;
#endif
using ImGuiNET;
using MelkTank.Loot;
using MelkTank.Metas;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public partial class Nav
{
	private int PrevInState(int i)
	{
		for (int num = i - 1; num >= 0; num--)
		{
			if (_meta.Rules[num].State == _meta.Rules[i].State)
			{
				return num;
			}
		}
		return i;
	}

	private int NextInState(int i)
	{
		for (int j = i + 1; j < _meta.Rules.Count; j++)
		{
			if (_meta.Rules[j].State == _meta.Rules[i].State)
			{
				return j;
			}
		}
		return i;
	}

	private void Swap(int a, int b)
	{
		if (a != b)
		{
			MRule value = _meta.Rules[a];
			_meta.Rules[a] = _meta.Rules[b];
			_meta.Rules[b] = value;
			if (_metaEdit == a)
			{
				_metaEdit = b;
			}
			else if (_metaEdit == b)
			{
				_metaEdit = a;
			}
			MetaChanged();
		}
	}

	private void RenameState(string from, string to)
	{
		foreach (MRule rule in _meta.Rules)
		{
			if (rule.State == from)
			{
				rule.State = to;
			}
			RenameIn(rule.A, from, to);
		}
	}

	private static void RenameIn(MAct a, string from, string to)
	{
		if (a.Kids != null)
		{
			foreach (MAct kid in a.Kids)
			{
				RenameIn(kid, from, to);
			}
			return;
		}
		if (a.Data == null)
		{
			return;
		}
		if (a.Type == 1 && a.Data.S == from)
		{
			a.Data.S = to;
		}
		if (a.Type != 5 && a.Type != 9)
		{
			return;
		}
		string[] array = new string[3] { "st", "ret", "s" };
		foreach (string key in array)
		{
			MVal mVal = a.Data.Get(key);
			if (mVal != null && mVal.S == from)
			{
				mVal.S = to;
			}
		}
	}

	private bool StatePicker(string label, ref string val, List<string> states)
	{
		bool result = false;
		ImGui.SetNextItemWidth(180f);
		if (ImGui.BeginCombo("##pick" + label, string.IsNullOrEmpty(val) ? "(pick a state)" : val))
		{
			foreach (string state in states)
			{
				if (ImGui.Selectable(state, state == val))
				{
					val = state;
					result = true;
				}
			}
			ImGui.EndCombo();
		}
		uint iD = ImGui.GetID(label);
		if (!_newStateBuf.TryGetValue(iD, out var value))
		{
			value = "";
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(140f);
		bool flag = ImGui.InputTextWithHint("##new" + label, "or a new state", ref value, 64u, ImGuiInputTextFlags.EnterReturnsTrue);
		ImGui.SameLine();
		if ((ImGui.SmallButton("use##use" + label) | flag) && value.Trim().Length > 0)
		{
			val = value.Trim();
			value = "";
			result = true;
			if (_meta != null && !states.Contains(val))
			{
				_meta.Rules.Add(new MRule
				{
					State = val
				});
				states.Add(val);
				MetaChanged();
				Util.WriteToChat("Meta: state " + val + " made - click it in the states list to give it its rules.");
			}
		}
		Tip("Uses the typed name. A state that doesn't exist yet is made, with one rule to change.");
		_newStateBuf[iD] = value;
		int num = label.IndexOf("##", StringComparison.Ordinal);
		string text = ((num >= 0) ? label.Substring(0, num) : label);
		if (text.Length > 0)
		{
			ImGui.SameLine();
			ImGui.TextUnformatted(text);
		}
		return result;
	}

	private static string SelectedName(bool monster)
	{
		return SelectedName(monster ? "monster" : "item");
	}

	private static string SelectedName(string kind)
	{
		try
		{
			WorldObject worldObject = Globals.Core.WorldFilter[Globals.Core.Actions.CurrentSelection];
			if (worldObject == null)
			{
				Util.WriteToChat("Meta: nothing selected.");
				return "";
			}
			bool num;
			switch (kind)
			{
			case "portal":
				num = worldObject.ObjectClass == ObjectClass.Portal;
				goto IL_0098;
			case "NPC":
				if (worldObject.ObjectClass == ObjectClass.Npc)
				{
					break;
				}
				num = worldObject.ObjectClass == ObjectClass.Vendor;
				goto IL_0098;
			case "monster":
				{
					num = worldObject.ObjectClass == ObjectClass.Monster;
					goto IL_0098;
				}
				IL_0098:
				if (!num)
				{
					Util.WriteToChat("Meta: select a " + kind + " first.");
					return "";
				}
				break;
			}
			return worldObject.Name ?? "";
		}
		catch
		{
			return "";
		}
	}

	private static List<KeyValuePair<int, string>> TimedSpells()
	{
		List<KeyValuePair<int, string>> list = new List<KeyValuePair<int, string>>();
		HashSet<int> hashSet = new HashSet<int>();
		try
		{
			foreach (EnchantmentWrapper enchantment in Globals.Core.CharacterFilter.Enchantments)
			{
				if (enchantment.TimeRemaining > 0 && hashSet.Add(enchantment.SpellId))
				{
					string text = SpellNames.Name(enchantment.SpellId);
					if (string.IsNullOrEmpty(text))
					{
						text = "spell " + enchantment.SpellId;
					}
					int num = enchantment.TimeRemaining / 60;
					list.Add(new KeyValuePair<int, string>(enchantment.SpellId, text + "  (" + ((num >= 60) ? (num / 60 + "h " + num % 60 + "m") : (num + "m " + enchantment.TimeRemaining % 60 + "s")) + " left)"));
				}
			}
		}
		catch
		{
		}
		list.Sort((KeyValuePair<int, string> a, KeyValuePair<int, string> b) => string.Compare(a.Value, b.Value, StringComparison.OrdinalIgnoreCase));
		return list;
	}

	private static string[] CondNames()
	{
		List<string> list = new List<string>();
		MetaText.TypeDef[] conds = MetaText.Conds;
		foreach (MetaText.TypeDef typeDef in conds)
		{
			list.Add(typeDef.Name);
		}
		return list.ToArray();
	}

	private static string[] ActNames()
	{
		List<string> list = new List<string>();
		MetaText.TypeDef[] acts = MetaText.Acts;
		foreach (MetaText.TypeDef typeDef in acts)
		{
			list.Add(typeDef.Name);
		}
		return list.ToArray();
	}

	private bool DrawCond(MCond c, string id, int depth, List<string> states)
	{
		bool flag = false;
		ImGui.PushID(id);
		int current_item = Array.FindIndex(MetaText.Conds, (MetaText.TypeDef t) => t.Id == c.Type);
		ImGui.SetNextItemWidth(230f);
		if (ImGui.Combo("##ct", ref current_item, _condNames, _condNames.Length))
		{
			MetaText.TypeDef typeDef = MetaText.Conds[current_item];
			c.Type = typeDef.Id;
			c.Data = MetaText.NewData(typeDef);
			c.Kids = ((typeDef.Data == "kids") ? new List<MCond>
			{
				new MCond
				{
					Type = 1
				}
			} : null);
			flag = true;
		}
		MetaText.TypeDef typeDef2 = MetaText.Cond(c.Type);
		if (typeDef2 != null)
		{
			Tip(typeDef2.Help);
		}
		if (c.Kids != null)
		{
			ImGui.Indent(18f);
			int num = -1;
			int num2 = -1;
			int num3 = -1;
			for (int num4 = 0; num4 < c.Kids.Count; num4++)
			{
				flag |= DrawCond(c.Kids[num4], id + "_" + num4, depth + 1, states);
				ImGui.SameLine();
				if (num4 > 0)
				{
					if (Im.UpButton("##cup" + num4))
					{
						num2 = num4;
					}
					ImGui.SameLine();
				}
				if (num4 < c.Kids.Count - 1)
				{
					if (Im.DownButton("##cdn" + num4))
					{
						num3 = num4;
					}
					ImGui.SameLine();
				}
				if (ImGui.SmallButton("x##cdel" + num4))
				{
					num = num4;
				}
			}
			if (num2 > 0)
			{
				Im.Move(c.Kids, num2, up: true);
				flag = true;
			}
			if (num3 >= 0)
			{
				Im.Move(c.Kids, num3, up: false);
				flag = true;
			}
			if (num >= 0)
			{
				c.Kids.RemoveAt(num);
				flag = true;
			}
			if ((c.Type != 21 || c.Kids.Count == 0) && ImGui.SmallButton("+ condition"))
			{
				c.Kids.Add(new MCond
				{
					Type = 1
				});
				flag = true;
			}
			ImGui.Unindent(18f);
		}
		else
		{
			flag |= DrawData(c.Data, typeDef2, act: false, states);
		}
		ImGui.PopID();
		return flag;
	}

	private bool DrawAct(MAct a, string id, int depth, List<string> states)
	{
		bool flag = false;
		ImGui.PushID(id);
		int current_item = Array.FindIndex(MetaText.Acts, (MetaText.TypeDef t) => t.Id == a.Type);
		ImGui.SetNextItemWidth(230f);
		if (ImGui.Combo("##at", ref current_item, _actNames, _actNames.Length))
		{
			MetaText.TypeDef typeDef = MetaText.Acts[current_item];
			a.Type = typeDef.Id;
			a.Data = MetaText.NewData(typeDef);
			a.Kids = ((typeDef.Data == "kids") ? new List<MAct>
			{
				new MAct
				{
					Type = 2,
					Data = MVal.Str("")
				}
			} : null);
			flag = true;
		}
		MetaText.TypeDef typeDef2 = MetaText.Act(a.Type);
		if (typeDef2 != null)
		{
			Tip(typeDef2.Help);
		}
		if (a.Kids != null)
		{
			ImGui.Indent(18f);
			int num = -1;
			int num2 = -1;
			int num3 = -1;
			for (int num4 = 0; num4 < a.Kids.Count; num4++)
			{
				flag |= DrawAct(a.Kids[num4], id + "_" + num4, depth + 1, states);
				ImGui.SameLine();
				if (num4 > 0)
				{
					if (Im.UpButton("##aup" + num4))
					{
						num2 = num4;
					}
					ImGui.SameLine();
				}
				if (num4 < a.Kids.Count - 1)
				{
					if (Im.DownButton("##adn" + num4))
					{
						num3 = num4;
					}
					ImGui.SameLine();
				}
				if (ImGui.SmallButton("x##adel" + num4))
				{
					num = num4;
				}
			}
			if (num2 > 0)
			{
				Im.Move(a.Kids, num2, up: true);
				flag = true;
			}
			if (num3 >= 0)
			{
				Im.Move(a.Kids, num3, up: false);
				flag = true;
			}
			if (num >= 0)
			{
				a.Kids.RemoveAt(num);
				flag = true;
			}
			if (ImGui.SmallButton("+ action"))
			{
				a.Kids.Add(new MAct
				{
					Type = 2,
					Data = MVal.Str("")
				});
				flag = true;
			}
			ImGui.Unindent(18f);
		}
		else
		{
			flag |= DrawData(a.Data, typeDef2, act: true, states);
		}
		ImGui.PopID();
		return flag;
	}

	private bool DrawData(MVal d, MetaText.TypeDef def, bool act, List<string> states)
	{
		if (d == null || def == null)
		{
			return false;
		}
		bool result = false;
		string data = def.Data;
		string text = data;
		if (text == null || text.Length != 0)
		{
			switch (text)
			{
			case "i":
			{
				ImGui.SameLine();
				int v3 = d.AsInt;
				ImGui.SetNextItemWidth(120f);
				if (ImGui.InputInt("##di", ref v3))
				{
					d.T = "i";
					d.S = v3.ToString();
					result = true;
				}
				return result;
			}
			case "hex":
			{
				ImGui.SameLine();
				string input6 = ((uint)d.AsInt).ToString("X8");
				ImGui.SetNextItemWidth(120f);
				if (ImGui.InputText("##dh", ref input6, 8u, ImGuiInputTextFlags.CharsHexadecimal) && uint.TryParse(input6, NumberStyles.HexNumber, null, out var result4))
				{
					d.T = "i";
					int num = (int)result4;
					d.S = num.ToString();
					result = true;
				}
				ImGui.SameLine();
				if (ImGui.SmallButton("here"))
				{
					try
					{
						uint num2 = (uint)Globals.Core.Actions.Landcell;
						if (def.Id == 17)
						{
							num2 &= 0xFFFF0000u;
						}
						d.T = "i";
						int num = (int)num2;
						d.S = num.ToString();
						result = true;
					}
					catch
					{
					}
				}
				Tip("Where you're standing now.");
				return result;
			}
			case "s":
			{
				ImGui.SameLine();
				string input7 = d.S ?? "";
				if (act && def.Id == 1)
				{
					if (StatePicker("##ds", ref input7, states))
					{
						d.S = input7;
						result = true;
					}
				}
				else
				{
					ImGui.SetNextItemWidth(Math.Max(200f, ImGui.GetContentRegionAvail().X - 90f));
					if (ImGui.InputText("##ds", ref input7, 1000u))
					{
						d.S = input7;
						result = true;
					}
				}
				return result;
			}
			case "ba":
			{
				MetaText.NavSummary(d.B, out var name, out var points);
				bool flag2 = false;
				ImGui.SameLine();
				NavRoute currentRoute = CurrentRoute;
				ImGui.SetNextItemWidth(200f);
				if (ImGui.BeginCombo("##embedpick", "embed a route..."))
				{
					foreach (NavRoute navRoute in _s.NavRoutes)
					{
						if (ImGui.Selectable(navRoute.Name + ((navRoute == currentRoute) ? "  (loaded)" : "") + "##er" + navRoute.Name))
						{
							flag2 |= EmbedRoute(d, navRoute);
						}
					}
					ImGui.EndCombo();
				}
				Tip("Puts a copy of one of your routes (Nav > Routes) into the meta.");
				ImGui.SameLine();
				if (ImGui.SmallButton("embed loaded route") && currentRoute != null)
				{
					flag2 |= EmbedRoute(d, currentRoute);
				}
				Tip("Puts a copy of the route loaded in Nav > Routes" + ((currentRoute != null) ? (" (" + currentRoute.Name + ")") : "") + " into the meta.");
				MetaText.NavSummary(d.B, out name, out points);
				Im.TextColored(Grey, "In the meta: " + ((points > 0) ? (((name.Length > 0) ? name : "(unnamed)") + ", " + points + (IsMtRoute(d.B) ? " steps (MelkTank route, nothing dropped)" : " points (VTank nav)")) : "no route yet"));
				if (points > 0)
				{
					ImGui.SameLine();
					if (ImGui.SmallButton("copy to my routes"))
					{
						ImportEmbedded(d.B, name);
					}
					Tip("Makes a MelkTank route from the embedded one (Nav > Routes).");
				}
				return flag2;
			}
			case "kv":
			{
				if (def.Keys == null)
				{
					return false;
				}
				string[][] keys = def.Keys;
				foreach (string[] array in keys)
				{
					MVal mVal = d.Get(array[0]);
					if (mVal == null)
					{
						if (array[1] == "i")
						{
							mVal = MVal.Int(0);
						}
						else if (array[1] == "d")
						{
							mVal = MVal.Dbl(0.0);
						}
						else
						{
							mVal = ((array[1] == "ba") ? MVal.Bytes(new byte[0]) : MVal.Str(""));
						}
						d.Set(array[0], mVal);
					}
					string text2 = array[2] + "##k" + array[0];
					if (array[1] == "ba")
					{
						string input = Meta.Enc.GetString(mVal.B ?? new byte[0]);
						if (ImGui.InputTextMultiline(text2, ref input, 65000u, new System.Numerics.Vector2(-1f, 120f)))
						{
							mVal.B = Meta.Enc.GetBytes(input);
							result = true;
						}
					}
					else if (array[0] == "e")
					{
						string input2 = mVal.S ?? "";
						if (ImGui.InputTextMultiline(text2, ref input2, 8000u, new System.Numerics.Vector2(-1f, Math.Min(140, 22 + 15 * (input2.Length / 70 + 1)))))
						{
							mVal.S = input2;
							result = true;
						}
					}
					else if (array[0] == "st" || array[0] == "ret" || ((array[0] == "s") & act))
					{
						string val = mVal.S ?? "";
						if (StatePicker(text2, ref val, states))
						{
							mVal.S = val;
							result = true;
						}
					}
					else if (act && (def.Id == 11 || def.Id == 12) && array[0] == "o")
					{
						string text3 = mVal.S ?? "";
						ImGui.SetNextItemWidth(160f);
						if (ImGui.BeginCombo("switch##optpick", (MetaText.OptLabel(text3).Length > 0) ? MetaText.OptLabel(text3) : "(pick)"))
						{
							string[][] options = MetaText.Options;
							foreach (string[] array2 in options)
							{
								if (ImGui.Selectable(array2[1] + "##op" + array2[0], string.Equals(array2[0], text3, StringComparison.OrdinalIgnoreCase)))
								{
									mVal.T = "s";
									mVal.S = array2[0];
									result = true;
								}
							}
							ImGui.EndCombo();
						}
						Tip("MelkTank's own switches - a .met from VTank using VTank's option names (EnableCombat...) uses these too.");
					}
					else if (act && def.Id == 11 && array[0] == "v")
					{
						string input3 = mVal.S ?? "";
						ImGui.SetNextItemWidth(200f);
						if (ImGui.InputText(text2, ref input3, 100u))
						{
							mVal.S = input3.Trim();
							result = true;
						}
						if (ImGui.IsItemHovered())
						{
							Im.SetTooltip("The name of a meta variable to put the switch in: 1 when it's on, 0 when it's off.\nAny name made of letters, numbers and _ - e.g. combatwas\n\nRead it back in an expression (When: Expression, or Do: Expression) with getvar[name]:\n  getvar[combatwas] == 1                  true when combat was on\n  testvar[combatwas]                      true once the variable has been set\n  ifthen[getvar[combatwas] == 1, chatbox[`/mtank on`], 0]\n                                          turns combat back on if it was on\n  echo[cstr[getvar[combatwas]], 1]         shows it in chat\n\nTypical use - a turn-in in the middle of hunting:\n  1. Get MT option combat into combatwas\n  2. Set MT option combat off, go and hand in\n  3. Do: Expression  ifthen[getvar[combatwas] == 1, chatbox[`/mtank on`], 0]\n\n$ variables (getvar / setvar) are forgotten when you log out; @ (pvars) and & (gvars) are saved.\nsetpvar / getpvar keep one per character across logins.");
						}
					}
					else if (act && def.Id == 12 && array[0] == "v")
					{
						if ((mVal.S ?? "").StartsWith("$"))
						{
							string input4 = mVal.S;
							ImGui.SetNextItemWidth(160f);
							if (ImGui.InputText("from variable##optvar", ref input4, 100u))
							{
								mVal.T = "s";
								mVal.S = input4.Trim();
								result = true;
							}
							Tip("On when the variable is 1 / true, off when it's 0 / false (e.g. $combatwas from a Get MT option).");
							ImGui.SameLine();
							if (ImGui.SmallButton("fixed##optfix"))
							{
								mVal.T = "s";
								mVal.S = "1";
								result = true;
							}
							Tip("Use a fixed on / off instead.");
						}
						else
						{
							bool v = MetaText.IsOn(mVal.S);
							if (ImGui.Checkbox("on##optval", ref v))
							{
								mVal.T = "s";
								mVal.S = (v ? "1" : "0");
								result = true;
							}
							ImGui.SameLine();
							if (ImGui.SmallButton("from a variable##optfromvar"))
							{
								mVal.T = "s";
								mVal.S = "$";
								result = true;
							}
							Tip("Set it from a variable instead (e.g. $combatwas, filled by Get MT option).");
						}
					}
					else if (!act && def.Id == 23 && array[0] == "sid")
					{
						int v2 = mVal.AsInt;
						string text4 = ((v2 > 0) ? SpellNames.Name(v2) : "");
						ImGui.SetNextItemWidth(260f);
						string label = "##spellpick";
						string? text5;
						if (v2 <= 0)
						{
							text5 = "(a spell on you)";
						}
						else
						{
							text5 = (string.IsNullOrEmpty(text4) ? ("spell " + v2) : text4);
						}
						if (ImGui.BeginCombo(label, text5))
						{
							List<KeyValuePair<int, string>> list = TimedSpells();
							if (list.Count == 0)
							{
								Im.TextColored(Grey, "No timed spells on you.");
							}
							foreach (KeyValuePair<int, string> item in list)
							{
								if (ImGui.Selectable(item.Value + "##sp" + item.Key, item.Key == v2))
								{
									mVal.T = "i";
									mVal.S = item.Key.ToString();
									result = true;
								}
							}
							ImGui.EndCombo();
						}
						Tip("Spells on you right now that have a timer.");
						ImGui.SameLine();
						ImGui.SetNextItemWidth(90f);
						if (ImGui.InputInt("spell id##k" + array[0], ref v2, 0))
						{
							mVal.T = "i";
							mVal.S = v2.ToString();
							result = true;
						}
						Tip("Or type a spell id.");
					}
					else if (act && def.Id == 104 && array[0] == "n")
					{
						string cur = mVal.S ?? "";
						ImGui.SetNextItemWidth(320f);
						if (ImGui.BeginCombo("route##loadroute", (cur.Length > 0) ? cur : "(pick a route)"))
						{
							foreach (NavRoute navRoute2 in _s.NavRoutes)
							{
								if (ImGui.Selectable(navRoute2.Name + "##lr" + navRoute2.Name, string.Equals(navRoute2.Name, cur, StringComparison.OrdinalIgnoreCase)))
								{
									mVal.T = "s";
									mVal.S = navRoute2.Name;
									result = true;
								}
							}
							ImGui.EndCombo();
						}
						if (cur.Length > 0 && !_s.NavRoutes.Exists((NavRoute x2) => string.Equals(x2.Name, cur, StringComparison.OrdinalIgnoreCase)))
						{
							ImGui.SameLine();
							Im.TextColored(new System.Numerics.Vector4(1f, 0.5f, 0.3f, 1f), "no route with that name");
						}
					}
					else
					{
						string input5 = mVal.S ?? "";
						ImGui.SetNextItemWidth((array[1] == "s") ? 320 : 120);
						if (ImGui.InputText(text2, ref input5, 1000u))
						{
							if (array[1] == "i")
							{
								if (int.TryParse(input5, out var _))
								{
									mVal.T = "i";
									mVal.S = input5;
									result = true;
								}
							}
							else if (array[1] == "d")
							{
								if (double.TryParse(input5, NumberStyles.Float, CultureInfo.InvariantCulture, out var _))
								{
									mVal.T = "d";
									mVal.S = input5;
									result = true;
								}
							}
							else
							{
								mVal.S = input5;
								result = true;
							}
						}
						if (act && def.Id >= 100 && def.Id <= 103)
						{
							string text6;
							if (array[0] == "i" || def.Id == 100)
							{
								text6 = "item";
							}
							else
							{
								text6 = ((def.Id == 102) ? "portal" : "NPC");
							}
							ImGui.SameLine();
							if (ImGui.SmallButton("selected " + text6 + "##sel" + array[0]))
							{
								string text7 = SelectedName(text6);
								if (text7.Length > 0)
								{
									mVal.S = text7;
									result = true;
								}
							}
							Tip("Uses the name of the " + text6 + " you have selected.");
						}
						if (!act && array[0] == "n" && (def.Id == 11 || def.Id == 12 || def.Id == 13))
						{
							ImGui.SameLine();
							bool flag = def.Id == 13;
							if (ImGui.SmallButton((flag ? "selected monster" : "selected item") + "##sel" + array[0]))
							{
								string text8 = SelectedName(flag);
								if (text8.Length > 0)
								{
									mVal.S = (flag ? ("^" + Regex.Escape(text8) + "$") : text8);
									result = true;
								}
							}
							Tip(flag ? "Uses the name of the monster you have selected (matched exactly)." : "Uses the name of the item you have selected.");
						}
					}
				}
				return result;
			}
			default:
				return false;
			}
		}
		return false;
	}
}
