using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using MelkTank.Metas;
using AcClient;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Bounties;
using MelkTank.Buffs;

namespace MelkTank;

public static partial class Session
{
	public static int EnlLevelNeeded(int n)
	{
		return 274 + n;
	}

	public static int EnlTokensNeeded(int n)
	{
		return (n >= 6) ? (n - 5) : 0;
	}

	public static bool EnlUsesMedallions(int n)
	{
		return n > 150;
	}

	public static long EnlLumNeeded(int n)
	{
		long result;
		if (n < 50)
		{
			result = 0L;
		}
		else
		{
			result = ((n > 150) ? ((long)n * 1000000000L) : ((long)n * 100000000L));
		}
		return result;
	}

	private static int EnlCount(out string source)
	{
		source = "";
		if (_enlManual > 0)
		{
			source = "typed in";
			return _enlManual;
		}
		try
		{
			int charProperty = CoreManager.Current.CharacterFilter.GetCharProperty(390);
			if (charProperty > 0)
			{
				source = "character";
				return charProperty;
			}
		}
		catch
		{
		}
		foreach (KeyValuePair<string, string> bonu in _bonus)
		{
			if (bonu.Key.IndexOf("Enlighten", StringComparison.OrdinalIgnoreCase) < 0 || !double.TryParse(bonu.Value.TrimStart(new char[2] { 'x', 'X' }).Replace(",", ""), NumberStyles.Float, EnlInv, out var result) || !(result >= 1.0))
			{
				continue;
			}
			source = "from /bonus (x" + result.ToString("0.00", EnlInv) + ")";
			return (int)Math.Round((result - 1.0) / 0.1);
		}
		return -1;
	}

	private static int Have(string name)
	{
		int value;
		return _enlHave.TryGetValue(name, out value) ? value : 0;
	}

	private static void CountEnlItems(bool now)
	{
		if (!now && (DateTime.Now - _enlCountAt).TotalSeconds < 2.0)
		{
			return;
		}
		_enlCountAt = DateTime.Now;
		_enlHave.Clear();
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				string name = item.Name;
				if (Array.IndexOf(EnlItems, name) >= 0)
				{
					int val = item.Values(LongValueKey.StackCount, 1);
					_enlHave[name] = Have(name) + Math.Max(1, val);
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static int FirstStack(string name)
	{
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
				{
					return item.Id;
				}
			}
		}
		catch
		{
		}
		return 0;
	}

	private static long BankNum(string name)
	{
		foreach (BankLine item in _bank)
		{
			if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
			{
				string s = item.Value.Split(' ')[0].Replace(",", "");
				if (long.TryParse(s, NumberStyles.Integer, EnlInv, out var result))
				{
					return result;
				}
			}
		}
		return -1L;
	}

	public static string Lum(long v)
	{
		if (v >= 1000000000000000L)
		{
			return ((double)v / 1000000000000000.0).ToString("0.###", EnlInv) + " Q";
		}
		if (v >= 1000000000000L)
		{
			return ((double)v / 1000000000000.0).ToString("0.###", EnlInv) + " T";
		}
		if (v >= 1000000000)
		{
			return ((double)v / 1000000000.0).ToString("0.###", EnlInv) + " B";
		}
		if (v >= 1000000)
		{
			return ((double)v / 1000000.0).ToString("0.#", EnlInv) + " M";
		}
		return v.ToString("N0", EnlInv);
	}

	private static void MkStart()
	{
		_mkOn = true;
		_mkWaiting = false;
		_mkMisses = 0;
		_mkMade = 0;
		_mkCounts.Clear();
		_mkPeaceAsked = DateTime.MinValue;
		_mkNextAt = DateTime.MinValue;
		_mkStatus = "starting";
		_mkWithdrawing = false;
		Check("/bank");
		_mkNextAt = DateTime.Now.AddSeconds(2.0);
		Util.WriteToChat("Medallion maker: started.");
	}

	private static void MkStop(string why)
	{
		if (!_mkOn)
		{
			return;
		}
		_mkOn = false;
		_mkWaiting = false;
		_mkStatus = why;
		List<string> list = new List<string>();
		foreach (KeyValuePair<string, int> mkCount in _mkCounts)
		{
			list.Add(mkCount.Value + " " + mkCount.Key);
		}
		Util.WriteToChat("Medallion maker: stopped - " + why + ((list.Count > 0) ? (" (made " + string.Join(", ", list.ToArray()) + ")") : "") + ".");
	}

	private static void MkChat(string text)
	{
		if (_mkOn && _mkWaiting && (text.IndexOf("link together effortlessly", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("combine the trophy with the powder", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("combine a part of a medallion with an enlightenment token", StringComparison.OrdinalIgnoreCase) >= 0))
		{
			_mkGot = true;
		}
	}

	private static void MkTick()
	{
		if (!_mkOn)
		{
			return;
		}
		try
		{
			HooksWrapper actions = CoreManager.Current.Actions;
			if (actions.CombatMode != CombatState.Peace)
			{
				if (_mkPeaceAsked == DateTime.MinValue)
				{
					_mkPeaceAsked = DateTime.Now;
					actions.SetCombatMode(CombatState.Peace);
					_mkStatus = "going to peace mode";
				}
				else if (!((DateTime.Now - _mkPeaceAsked).TotalSeconds < 4.0) || _mkMade != 0 || _mkWaiting)
				{
					MkStop("left peace mode");
				}
				return;
			}
			if (_mkPeaceAsked == DateTime.MinValue)
			{
				_mkPeaceAsked = DateTime.Now;
			}
			if (_mkWaiting && _mkStep == "Fiun")
			{
				CountEnlItems(now: true);
				int num = Have("Part of a Medallion");
				if (num < _mkPartsBefore)
				{
					_mkWaiting = false;
					_mkMisses = 0;
					int num2 = _mkPartsBefore - num;
					_mkMade += num2;
					_mkCounts.TryGetValue("medallions (Fiun)", out var value);
					_mkCounts["medallions (Fiun)"] = value + num2;
					_mkNextAt = DateTime.Now.AddSeconds(1.5);
				}
				else
				{
					if (!((DateTime.Now - _mkSentAt).TotalSeconds > 8.0))
					{
						return;
					}
					_mkWaiting = false;
					if (++_mkMisses >= 3)
					{
						MkStop("Fiun didn't take the parts 3 times");
						return;
					}
					_mkNextAt = DateTime.Now.AddSeconds(1.0);
				}
			}
			if (_mkWaiting)
			{
				if (_mkGot)
				{
					_mkWaiting = false;
					_mkMisses = 0;
					_mkMade++;
					_mkCounts.TryGetValue(_mkStep, out var value2);
					_mkCounts[_mkStep] = value2 + 1;
					_mkNextAt = DateTime.Now.AddMilliseconds(400.0);
				}
				else
				{
					if (!((DateTime.Now - _mkSentAt).TotalSeconds > 5.0))
					{
						return;
					}
					_mkWaiting = false;
					if (++_mkMisses >= 3)
					{
						MkStop("3 combines in a row did nothing");
						return;
					}
					_mkNextAt = DateTime.Now.AddSeconds(1.0);
				}
			}
			if (DateTime.Now < _mkNextAt)
			{
				return;
			}
			CountEnlItems(now: true);
			if (MkStopAt > 0 && Have("Enlightenment Medallion") >= MkStopAt)
			{
				MkStop("you have " + Have("Enlightenment Medallion") + " medallions");
			}
			else
			{
				if (MkBankStep())
				{
					return;
				}
				if (MkFiun)
				{
					int num3 = Math.Min(Have("Part of a Medallion"), Have("Enlightenment Token"));
					WorldObject worldObject = null;
					int mkFiunN = 0;
					if (num3 >= 100)
					{
						worldObject = NearNpc("Fiun of Great Enlightenment");
						mkFiunN = 100;
					}
					if (worldObject == null && num3 >= 10)
					{
						worldObject = NearNpc("Fiun of Enlightenment");
						mkFiunN = 10;
					}
					if (worldObject != null)
					{
						_mkStep = "Fiun";
						_mkWaiting = true;
						_mkSentAt = DateTime.Now;
						_mkPartsBefore = Have("Part of a Medallion");
						_mkFiunN = mkFiunN;
						_mkStatus = "handing " + mkFiunN + " parts to " + worldObject.Name;
						Util.Command("/ub give " + mkFiunN + " Part of a Medallion to " + worldObject.Name);
						return;
					}
				}
				string text = null;
				string text2 = null;
				string text3 = null;
				if (MkMedallions && Have("Part of a Medallion") > 0 && Have("Enlightenment Token") > 0)
				{
					text = "Part of a Medallion";
					text2 = "Enlightenment Token";
					text3 = "medallions";
				}
				else if (MkParts && Have("Trophy") > 0 && Have("Yellow Aetheria Powder") > 0)
				{
					text = "Trophy";
					text2 = "Yellow Aetheria Powder";
					text3 = "parts";
				}
				else if (MkPowder && Have("Aetheria Desiccant") > 0 && Have("Yellow Aetheria Chunk") > 0)
				{
					text = "Aetheria Desiccant";
					text2 = "Yellow Aetheria Chunk";
					text3 = "powder";
				}
				if (text == null)
				{
					MkStop("nothing left to combine");
					return;
				}
				int num4 = FirstStack(text);
				int num5 = FirstStack(text2);
				if (num4 == 0 || num5 == 0)
				{
					MkStop("couldn't find " + ((num4 == 0) ? text : text2));
					return;
				}
				_mkStep = text3;
				_mkGot = false;
				_mkWaiting = true;
				_mkSentAt = DateTime.Now;
				_mkStatus = "making " + text3 + " (" + text + " on " + text2 + ")";
				actions.ApplyItem(num4, num5);
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			MkStop("error: " + ex.Message);
		}
	}

	private static WorldObject NearNpc(string name)
	{
		try
		{
			foreach (WorldObject item in CoreManager.Current.WorldFilter.GetByName(name))
			{
				if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase) && CombatEngine.Distance(item) <= 12.0)
				{
					return item;
				}
			}
		}
		catch
		{
		}
		return null;
	}

	private static void DrawEnl()
	{
		if (!ImGui.BeginTabBar("##enltabs"))
		{
			return;
		}
		if (ImGui.BeginTabItem("Main##enlmain"))
		{
			DrawEnlMain();
			ImGui.EndTabItem();
		}
		if (ImGui.BeginTabItem((AeOn ? "Auto enlighten (running)" : "Auto enlighten") + "###enlauto"))
		{
			int num = EnlCount(out var _);
			if (num < 0)
			{
				Im.TextDisabled("Your enlightenment count isn't known - click Update on the Main tab or type it there.");
			}
			else
			{
				DrawAutoEnl(num);
			}
			ImGui.EndTabItem();
		}
		if (ImGui.BeginTabItem((_rtOn ? "Retrain (running)" : "Retrain") + "###enlrt"))
		{
			DrawRetrain();
			ImGui.EndTabItem();
		}
		ImGui.EndTabBar();
	}

	private static void DrawEnlMain()
	{
		Vector4 vector = new Vector4(0.45f, 0.9f, 0.45f, 1f);
		Vector4 vector2 = new Vector4(1f, 0.5f, 0.45f, 1f);
		Vector4 vector3 = new Vector4(0.6f, 0.6f, 0.6f, 1f);
		CountEnlItems(now: false);
		if (ImGui.Button("Update"))
		{
			Check("/bonus");
			Check("/bank");
			CountEnlItems(now: true);
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Sends /bonus (your enlightenment count) and /bank (luminance, tokens) quietly.");
		}
		int num = EnlCount(out var source);
		int num2 = 0;
		try
		{
			num2 = CoreManager.Current.CharacterFilter.Level;
		}
		catch
		{
		}
		ImGui.SameLine();
		Im.TextColored(Cyan, "Enlightenment");
		ImGui.SameLine();
		int v = ((num >= 0) ? num : 0);
		ImGui.SetNextItemWidth(100f);
		if (ImGui.InputInt("##enlcur", ref v, 1, 10))
		{
			_enlManual = Math.Max(0, v);
			_deedsDirtyAt = DateTime.Now;
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Your enlightenments. Worked out from the character (or /bonus) - if it's wrong, type the right number\n(set it to 0 to go back to working it out).");
		}
		ImGui.SameLine();
		Im.TextColored(vector3, (num < 0) ? "unknown - click Update or type it" : ("(" + source + ")"));
		if (num < 0)
		{
			return;
		}
		int num3 = num + 1;
		long num4 = BankNum("Luminance");
		long num5 = Math.Max(0L, BankNum("Enlightenment Tokens"));
		long num6 = Math.Max(0L, BankNum("Enlightened Coins"));
		bool flag = EnlUsesMedallions(num3);
		int num7 = EnlTokensNeeded(num3);
		int num8 = (flag ? Have("Enlightenment Medallion") : Have("Enlightenment Token"));
		ImGui.Separator();
		Im.TextColored(Cyan, "Enlightenment " + num3 + " needs:");
		if (ImGui.BeginTable("enlneed", 3, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 150f);
			ImGui.TableSetupColumn("Needed", ImGuiTableColumnFlags.WidthFixed, 110f);
			ImGui.TableSetupColumn("You have", ImGuiTableColumnFlags.WidthStretch);
			ImGui.TableHeadersRow();
			NeedRow("Level", EnlLevelNeeded(num3).ToString(), (num2 > 0) ? num2.ToString() : "?", num2 >= EnlLevelNeeded(num3), vector, vector2);
			if (num7 > 0)
			{
				string what = (flag ? "Medallions" : "Tokens");
				string need = num7.ToString("N0", EnlInv);
				string text = num8.ToString("N0", EnlInv);
				string? text2;
				if (flag)
				{
					text2 = "";
				}
				else
				{
					text2 = ((num5 > 0) ? (" (+" + num5 + " in the bank)") : "");
				}
				NeedRow(what, need, text + text2, num8 >= num7, vector, vector2);
			}
			long num9 = EnlLumNeeded(num3);
			if (num9 > 0)
			{
				NeedRow("Luminance", Lum(num9), (num4 >= 0) ? (Lum(num4) + " banked") : "? - click Update", num4 >= num9, vector, vector2);
			}
			ImGui.EndTable();
		}
		if (num3 >= 31)
		{
			Im.TextColored(vector3, "Also: Master rank in a society" + ((num3 > 150) ? ", and all 50 Paragon Weapon levels (ParagonEnlCompleted)." : "."));
		}
		Im.TextColored(vector3, "Enlighten with /enl - outside, standing still (portal somewhere outside, then a small jump).");
		if (flag && num8 < num7)
		{
			int num10 = num7 - num8;
			ImGui.Separator();
			Im.TextColored(Yellow, "To make the " + num10 + " missing medallion" + ((num10 == 1) ? "" : "s") + " (one each of):");
			int num11 = Have("Part of a Medallion");
			int num12 = Have("Enlightenment Token");
			int num13 = Have("Trophy");
			int num14 = Have("Yellow Aetheria Powder");
			int num15 = Have("Yellow Aetheria Chunk");
			int num16 = Have("Aetheria Desiccant");
			int num17 = Math.Max(0, num10 - num11);
			int num18 = Math.Max(0, num17 - num14);
			long num19 = Math.Max(0, num10 - num12);
			Have2("Enlightenment Tokens", num12, num10, vector, vector2, (num5 > 0) ? (num5 + " more in the bank") : null);
			if (num19 > num5)
			{
				long num20 = num19 - num5;
				Im.TextColored((num6 >= num20 * 20) ? vector : vector2, "      buy " + num20 + " more = " + (num20 * 20).ToString("N0", EnlInv) + " Enlightened Coins (banked: " + num6.ToString("N0", EnlInv) + ")");
			}
			Have2("Parts of a Medallion", num11, num10, vector, vector2, null);
			if (num17 > 0)
			{
				Have2("    Trophies", num13, num17, vector, vector2, "VoD drops");
				Have2("    Yellow Aetheria Powder", num14, num17, vector, vector2, null);
				if (num18 > 0)
				{
					Have2("        Yellow Aetheria Chunks", num15, num18, vector, vector2, null);
					Have2("        Aetheria Desiccant", num16, num18, vector, vector2, null);
				}
			}
		}
		ImGui.Separator();
		Im.TextColored(Cyan, "Up to enlightenment");
		ImGui.SameLine();
		if (_enlTarget <= num)
		{
			_enlTarget = num + 10;
		}
		ImGui.SetNextItemWidth(110f);
		ImGui.InputInt("##enltarget", ref _enlTarget, 1, 10);
		ImGui.SameLine();
		if (ImGui.Button("Calc"))
		{
			_calcFor = _enlTarget;
			_calcTokens = 0;
			_calcMedals = 0;
			_calcLum = 0L;
			for (int i = num + 1; i <= _enlTarget; i++)
			{
				if (EnlUsesMedallions(i))
				{
					_calcMedals += EnlTokensNeeded(i);
				}
				else
				{
					_calcTokens += EnlTokensNeeded(i);
				}
				_calcLum += EnlLumNeeded(i);
			}
			_calcLevel = EnlLevelNeeded(_enlTarget);
		}
		if (_calcFor > num)
		{
			int num21 = Have("Enlightenment Medallion");
			int num22 = Have("Enlightenment Token");
			Im.TextColored(vector3, "From " + (num + 1) + " to " + _calcFor + " (" + (_calcFor - num) + " enlightenments):");
			Im.TextColored((num2 >= _calcLevel) ? vector : Vector4.One, "  Level " + _calcLevel + " for the last one");
			if (_calcTokens > 0)
			{
				Im.TextColored((num22 + num5 >= _calcTokens) ? vector : Vector4.One, "  " + _calcTokens.ToString("N0", EnlInv) + " tokens (have " + (num22 + num5) + ")");
			}
			if (_calcMedals > 0)
			{
				Im.TextColored((num21 >= _calcMedals) ? vector : Vector4.One, "  " + _calcMedals.ToString("N0", EnlInv) + " medallions (have " + num21 + ", short " + Math.Max(0, _calcMedals - num21).ToString("N0", EnlInv) + ")");
			}
			if (_calcLum > 0)
			{
				Im.TextColored((num4 >= _calcLum) ? vector : Vector4.One, "  " + Lum(_calcLum) + " luminance (banked " + ((num4 >= 0) ? Lum(num4) : "?") + ")");
			}
		}
		ImGui.Separator();
		DrawEnlBank();
		if (!ImGui.CollapsingHeader("Medallion maker" + (_mkOn ? " - running###mkhdr" : "###mkhdr")))
		{
			return;
		}
		Im.TextColored(vector3, "(peace mode only - stops if you leave it)");
		ImGui.Checkbox("Powder##mkp", ref MkPowder);
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Aetheria Desiccant on Yellow Aetheria Chunk -> Yellow Aetheria Powder");
		}
		ImGui.SameLine();
		ImGui.Checkbox("Parts##mkt", ref MkParts);
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Trophy on Yellow Aetheria Powder -> Part of a Medallion");
		}
		ImGui.SameLine();
		ImGui.Checkbox("Medallions##mkm", ref MkMedallions);
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Part of a Medallion on Enlightenment Token -> Enlightenment Medallion");
		}
		ImGui.SameLine();
		ImGui.Checkbox("Hand to Fiun##mkf", ref MkFiun);
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Standing by Fiun in Arwic: hands Parts of a Medallion over 100 at a time (Fiun of Great Enlightenment)\nor 10 at a time (Fiun of Enlightenment) - he turns them into medallions with your tokens.\nNeeds as many tokens as parts; whatever's left under 10 is combined by hand (Medallions ticked).");
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		ImGui.InputInt("stop at##mkstop", ref MkStopAt, 10, 50);
		if (MkStopAt < 0)
		{
			MkStopAt = 0;
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Stop once you carry this many medallions (0 = keep going until something runs out).");
		}
		if (!_mkOn)
		{
			if (ImGui.Button("Start##mk"))
			{
				MkStart();
			}
		}
		else if (ImGui.Button("Stop##mk"))
		{
			MkStop("stopped");
		}
		ImGui.SameLine();
		Im.TextColored(_mkOn ? Yellow : vector3, (_mkStatus.Length > 0) ? _mkStatus : "idle");
		Im.TextColored(vector3, "Carrying: " + Have("Enlightenment Medallion") + " medallions, " + Have("Enlightenment Token") + " tokens, " + Have("Part of a Medallion") + " parts, " + Have("Trophy") + " trophies, " + Have("Yellow Aetheria Powder") + " powder, " + Have("Yellow Aetheria Chunk") + " chunks, " + Have("Aetheria Desiccant") + " desiccant");
	}
}
