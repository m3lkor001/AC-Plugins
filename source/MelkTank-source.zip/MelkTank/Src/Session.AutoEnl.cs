using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using MelkTank.Metas;
using AcClient;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Bounties;
using MelkTank.Buffs;

namespace MelkTank;

public static partial class Session
{
	private static int Landcell()
	{
		try
		{
			return CoreManager.Current.Actions.Landcell;
		}
		catch
		{
			return 0;
		}
	}

	private static bool Outdoors(int cell)
	{
		return cell != 0 && (cell & 0xFFFF) < 256;
	}

	private static int Level()
	{
		try
		{
			return CoreManager.Current.CharacterFilter.Level;
		}
		catch
		{
			return 0;
		}
	}

	private static void AeStart()
	{
		if (AeGo.Length == 0)
		{
			_aeStatus = "pick how to get outside first";
			return;
		}
		_ae = Ae.Start;
		_aeDone = 0;
		_aeRefused = 0;
		_aeTries = 0;
		_aeStepAt = DateTime.Now;
		_aeStatus = "starting";
		PluginCore.Pause("Auto enlighten");
		Check("/bank");
		Check("/bonus");
		Util.WriteToChat("Auto enlighten: started" + ((AeTarget > 0) ? (" - up to enlightenment " + AeTarget) : "") + ".");
	}

	private static void AeStop(string why)
	{
		if (_ae != Ae.Off)
		{
			_ae = Ae.Off;
			_aeStatus = why;
			PluginCore.Resume("Auto enlighten");
			if (RtSpecAtEnd && (why.StartsWith("reached", StringComparison.Ordinal) || why.StartsWith("out of", StringComparison.Ordinal)))
			{
				RtStart(spec: true);
			}
			Util.WriteToChat("Auto enlighten: stopped - " + why + ((_aeDone > 0) ? (" (" + _aeDone + " enlightenment" + ((_aeDone == 1) ? "" : "s") + " done)") : "") + ".");
		}
	}

	private static void AeChat(string text)
	{
		if (_ae == Ae.Sent || _ae == Ae.Jumped)
		{
			string text2 = text.ToLowerInvariant();
			if (text2.IndexOf("enlighten", StringComparison.Ordinal) >= 0 && (text2.IndexOf("cannot", StringComparison.Ordinal) >= 0 || text2.IndexOf("can't", StringComparison.Ordinal) >= 0 || text2.IndexOf("must", StringComparison.Ordinal) >= 0 || text2.IndexOf("unable", StringComparison.Ordinal) >= 0 || text2.IndexOf("not ", StringComparison.Ordinal) >= 0 || text2.IndexOf("need", StringComparison.Ordinal) >= 0))
			{
				_aeError = true;
				_aeLastError = text.Trim();
			}
		}
	}

	private static string AeShort(int next)
	{
		CountEnlItems(now: true);
		int num = EnlTokensNeeded(next);
		bool flag = EnlUsesMedallions(next);
		int num2 = (flag ? Have("Enlightenment Medallion") : Have("Enlightenment Token"));
		if (num > num2)
		{
			return "out of " + (flag ? "medallions" : "tokens") + " (" + num2 + " of " + num + ")";
		}
		long num3 = EnlLumNeeded(next);
		long num4 = BankNum("Luminance");
		if (num3 > 0 && num4 >= 0 && num4 < num3)
		{
			return "out of luminance (" + Lum(num4) + " of " + Lum(num3) + ")";
		}
		return null;
	}

	private static bool AeUse(string go, out string err)
	{
		err = null;
		HooksWrapper actions = CoreManager.Current.Actions;
		if (go.StartsWith("gem:", StringComparison.Ordinal))
		{
			int num = FirstStack(go.Substring(4));
			if (num == 0)
			{
				err = "out of " + go.Substring(4);
				return false;
			}
			if (actions.CombatMode != CombatState.Peace)
			{
				actions.SetCombatMode(CombatState.Peace);
				return false;
			}
			actions.UseItem(num, 0);
			return true;
		}
		if (go.StartsWith("spell:", StringComparison.Ordinal))
		{
			string[] array = go.Split(new char[1] { ':' }, 3);
			if (array.Length < 2 || !int.TryParse(array[1], out var result))
			{
				err = "that spell isn't known";
				return false;
			}
			if (actions.CombatMode != CombatState.Magic)
			{
				if (!_aeMagicAsked)
				{
					_aeMagicAsked = true;
					if (!WandInHand())
					{
						int num2 = AnyWand();
						if (num2 == 0)
						{
							err = "no wand to cast with";
							return false;
						}
						Wield(num2);
						return false;
					}
					actions.SetCombatMode(CombatState.Magic);
				}
				else if ((DateTime.Now - _aeStepAt).TotalSeconds > 3.0)
				{
					_aeMagicAsked = false;
					_aeStepAt = DateTime.Now;
				}
				return false;
			}
			actions.CastSpell(result, CoreManager.Current.CharacterFilter.Id);
			return true;
		}
		err = "pick how to get outside";
		return false;
	}

	internal static bool WandInHand()
	{
		try
		{
			int id = CoreManager.Current.CharacterFilter.Id;
			foreach (WorldObject item in InvCache.All())
			{
				if (item.ObjectClass == ObjectClass.WandStaffOrb && item.Values(LongValueKey.Wielder) == id)
				{
					return true;
				}
			}
		}
		catch
		{
		}
		return false;
	}

	internal static int AnyWand()
	{
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (item.ObjectClass == ObjectClass.WandStaffOrb)
				{
					return item.Id;
				}
			}
		}
		catch
		{
		}
		return 0;
	}

	private static string SubwayGo()
	{
		foreach (string item in PortalsTab.CarriedGems(PluginCore.CurrentSettings))
		{
			if (item.IndexOf("Subway", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				return "gem:" + item;
			}
		}
		foreach (KeyValuePair<int, string> item2 in PortalsTab.RecallSpells())
		{
			if (item2.Value.IndexOf("Subway", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				return "spell:" + item2.Key + ":" + item2.Value;
			}
		}
		return null;
	}

	private static void AeGoTo(Ae s, string status)
	{
		_ae = s;
		_aeStepAt = DateTime.Now;
		_aeStatus = status;
		_aeMagicAsked = false;
	}

	private static void AeTick()
	{
		if (_ae == Ae.Off)
		{
			return;
		}
		try
		{
			int num = EnlCount(out var _);
			double totalSeconds = (DateTime.Now - _aeStepAt).TotalSeconds;
			int num2 = Landcell();
			switch (_ae)
			{
			case Ae.Train:
				if (RtBusy)
				{
					_aeStatus = "retraining - " + _rtStatus;
					break;
				}
				if (_rtFailed != null)
				{
					AeStop("retrain: " + _rtFailed);
					break;
				}
				if (AeGo.StartsWith("spell:", StringComparison.Ordinal) && !WandInHand())
				{
					int num3 = AnyWand();
					if (num3 != 0)
					{
						Wield(num3);
					}
				}
				AeGoTo(Ae.Start, "retrained - starting");
				_aeStepAt = DateTime.Now.AddSeconds(-1.0);
				break;
			case Ae.Start:
			{
				if (RtAfterEnl && RtNeedsTraining())
				{
					RtStart(spec: false);
					AeGoTo(Ae.Train, "retraining");
					break;
				}
				if (totalSeconds < 2.0)
				{
					_aeStatus = "checking luminance and tokens";
					break;
				}
				if (num < 0)
				{
					AeStop("your enlightenment count isn't known - click Update or type it");
					break;
				}
				if (AeTarget > 0 && num >= AeTarget)
				{
					AeStop("reached enlightenment " + num);
					break;
				}
				string text = AeShort(num + 1);
				if (text != null)
				{
					AeStop(text);
					break;
				}
				_aeCell = num2;
				_aeTries++;
				if (_aeTries > 3)
				{
					AeStop("the way outside didn't take you anywhere 3 times");
					break;
				}
				AeGoTo(Ae.Going, "going outside (" + AeName(AeGo) + ")");
				goto case Ae.Going;
			}
			case Ae.Going:
			case Ae.Subway:
				if (_aeCellAt == DateTime.MinValue || _aeCellAt < _aeStepAt)
				{
					if (num2 != _aeCell && num2 != 0)
					{
						_aeCellAt = DateTime.Now;
						_aeCell = num2;
						break;
					}
					if (_aeAt < _aeStepAt)
					{
						if (AeUse((_ae == Ae.Subway) ? (SubwayGo() ?? "") : AeGo, out var err))
						{
							_aeAt = DateTime.Now;
						}
						else if (err != null)
						{
							AeStop(err);
							break;
						}
					}
					if (totalSeconds > 25.0)
					{
						AeGoTo((_ae == Ae.Subway) ? Ae.Subway : Ae.Start, "trying again");
						_aeAt = DateTime.MinValue;
					}
				}
				else if (!((DateTime.Now - _aeCellAt).TotalSeconds < 3.0))
				{
					_aeAt = DateTime.MinValue;
					if (_ae == Ae.Subway)
					{
						_aeTries = 0;
						AeGoTo(Ae.Start, "at the Subway - going outside again");
						_aeStepAt = DateTime.Now.AddSeconds(-2.0);
					}
					else if (!Outdoors(num2))
					{
						AeStop("the way outside left you indoors (" + num2.ToString("X8") + ")");
					}
					else
					{
						_aeTries = 0;
						_aeLvlAt = DateTime.MinValue;
						AeGoTo(Ae.Outside, "outside - waiting for level " + EnlLevelNeeded(num + 1));
					}
				}
				break;
			case Ae.Outside:
			{
				int num4 = EnlLevelNeeded(num + 1);
				int num5 = Level();
				if (num5 < num4)
				{
					_aeStatus = "outside - waiting for level " + num4 + " (now " + num5 + ")";
					_aeLvlAt = DateTime.MinValue;
				}
				else if (_aeLvlAt == DateTime.MinValue)
				{
					_aeLvlAt = DateTime.Now;
				}
				else if (!((DateTime.Now - _aeLvlAt).TotalSeconds < 1.0))
				{
					string text2 = AeShort(num + 1);
					if (text2 != null)
					{
						AeStop(text2);
						break;
					}
					if (CoreManager.Current.Actions.CombatMode != CombatState.Peace)
					{
						CoreManager.Current.Actions.SetCombatMode(CombatState.Peace);
						break;
					}
					Remote.SmallJump(150);
					_aeError = false;
					AeGoTo(Ae.Jumped, "jumped - /enl in 3 s");
				}
				break;
			}
			case Ae.Jumped:
				if (!(totalSeconds < 3.0))
				{
					_aeError = false;
					Remote.ExpectYes(12.0, null);
					Util.Command("/enl");
					AeGoTo(Ae.Sent, "sent /enl - waiting for the pop-up");
				}
				break;
			case Ae.Sent:
				if (Remote.LastConfirmUtc > _aeStepAt.ToUniversalTime() || Remote.HookAnsweredUtc > _aeStepAt.ToUniversalTime())
				{
					if (!((DateTime.UtcNow - Remote.LastConfirmUtc).TotalSeconds < 0.8))
					{
						Remote.ClickConfirmYes();
						_aeCell = num2;
						AeGoTo(Ae.Yes, "said Yes - waiting for the trip to the lifestone");
					}
				}
				else
				{
					if (!_aeError && !(totalSeconds > 10.0))
					{
						break;
					}
					string text3 = (_aeError ? _aeLastError : "no pop-up after /enl");
					Util.WriteToChat("Auto enlighten: /enl refused - " + text3);
					string text4 = AeShort(num + 1);
					if (text4 != null)
					{
						AeStop(text4);
						break;
					}
					if (++_aeRefused >= 3)
					{
						AeStop("/enl refused 3 times in a row (" + text3 + ")");
						break;
					}
					string text5 = SubwayGo();
					if (text5 == null)
					{
						AeStop("/enl refused and there's no Subway recall (gem or spell) to start over from");
						break;
					}
					_aeCell = num2;
					_aeAt = DateTime.MinValue;
					AeGoTo(Ae.Subway, "refused - Subway recall, then outside again");
				}
				break;
			case Ae.Yes:
				if (num2 != _aeCell && num2 != 0)
				{
					_aeDone++;
					_aeRefused = 0;
					_aeTries = 0;
					if (_enlManual > 0)
					{
						_enlManual++;
						_deedsDirtyAt = DateTime.Now;
					}
					Util.WriteToChat("Auto enlighten: enlightenment " + ((num < 0) ? "?" : ((_enlManual > 0) ? _enlManual : (num + 1)).ToString()) + " done.");
					Check("/bank");
					Check("/bonus");
					AeGoTo(Ae.Start, "enlightened - starting over");
				}
				else if (totalSeconds > 90.0)
				{
					AeStop("no trip to the lifestone 90 s after Yes");
				}
				break;
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			AeStop("error: " + ex.Message);
		}
	}

	public static string EnlCommand(string arg)
	{
		arg = (arg ?? "").Trim().ToLowerInvariant();
		string text = EnlBankCommand(arg);
		if (text != null)
		{
			return text;
		}
		if (arg == "start")
		{
			if (AeOn)
			{
				return "Auto enlighten is already running - " + _aeStatus;
			}
			AeStart();
			return "Auto enlighten: " + _aeStatus;
		}
		if (arg == "stop")
		{
			if (!AeOn)
			{
				return "Auto enlighten isn't running.";
			}
			AeStop("stopped");
			return "Auto enlighten stopped.";
		}
		if (arg.StartsWith("target"))
		{
			if (!int.TryParse(arg.Substring(6).Trim(), out var result) || result < 0)
			{
				return "Usage: /mtank enl target <number> (0 = keep going)";
			}
			AeTarget = result;
			_deedsDirtyAt = DateTime.Now;
			return "Auto enlighten: " + ((result > 0) ? ("up to enlightenment " + result) : "until out of luminance / mats") + ".";
		}
		return "Auto enlighten " + (AeOn ? "running" : "not running") + " - " + ((_aeStatus.Length > 0) ? _aeStatus : "idle") + ". /mtank enl start | stop | target <n> | buy need|max|<n> | withdraw [n|all]";
	}

	public static void EnlPhone(out bool on, out string status, out int target, out int now)
	{
		on = AeOn;
		status = ((_aeStatus.Length > 0) ? _aeStatus : "idle") + ((_aeDone > 0) ? (" - " + _aeDone + " done") : "");
		target = AeTarget;
		now = EnlCount(out var _);
	}

	private static string AeName(string go)
	{
		if (go.StartsWith("gem:", StringComparison.Ordinal))
		{
			return go.Substring(4);
		}
		if (go.StartsWith("spell:", StringComparison.Ordinal))
		{
			string[] array = go.Split(new char[1] { ':' }, 3);
			return (array.Length > 2) ? array[2] : "spell";
		}
		return "(none)";
	}

	private static void DrawAutoEnl(int cur)
	{
		Vector4 vector = new Vector4(0.6f, 0.6f, 0.6f, 1f);
		if (_aeOpts == null || (DateTime.Now - _aeOptsAt).TotalSeconds > 5.0)
		{
			_aeOptsAt = DateTime.Now;
			_aeOpts = new List<string>();
			foreach (string item in PortalsTab.CarriedGems(PluginCore.CurrentSettings))
			{
				_aeOpts.Add("gem:" + item);
			}
			foreach (KeyValuePair<int, string> item2 in PortalsTab.RecallSpells())
			{
				_aeOpts.Add("spell:" + item2.Key + ":" + item2.Value);
			}
		}
		Im.Text("Get outside with");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(260f);
		string text = ((AeGo.Length == 0) ? "(pick one)" : ((AeGo.StartsWith("spell:") ? "Spell: " : "Gem: ") + AeName(AeGo)));
		if (ImGui.BeginCombo("##aego", text))
		{
			foreach (string aeOpt in _aeOpts)
			{
				if (ImGui.Selectable((aeOpt.StartsWith("spell:") ? "Spell: " : "Gem: ") + AeName(aeOpt) + "##" + aeOpt, aeOpt == AeGo))
				{
					AeGo = aeOpt;
					_deedsDirtyAt = DateTime.Now;
				}
			}
			if (_aeOpts.Count == 0)
			{
				Im.TextDisabled("No portal gems or recall spells found.");
			}
			ImGui.EndCombo();
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("You have to be outside to enlighten. A portal gem you carry, or a recall spell you know\n(a spell needs a wand and the magic skill for it).");
		}
		ImGui.SameLine();
		Im.Text("up to");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(100f);
		if (ImGui.InputInt("##aetarget", ref AeTarget, 1, 10))
		{
			AeTarget = Math.Max(0, AeTarget);
			_deedsDirtyAt = DateTime.Now;
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Stop once you reach this enlightenment (0 = until the luminance, tokens or medallions run out).");
		}
		Im.TextColored(vector, RtAfterEnl ? "Trains the skills ticked Enl on the Retrain tab after each enlighten." : "No skills ticked Enl on the Retrain tab - none are trained between enlightens.");
		if (!AeOn)
		{
			if (ImGui.Button("Start##ae"))
			{
				AeStart();
			}
		}
		else if (ImGui.Button("Stop##ae"))
		{
			AeStop("stopped");
		}
		ImGui.SameLine();
		Im.TextColored(AeOn ? Yellow : vector, (_aeStatus.Length > 0) ? _aeStatus : "idle");
		Im.TextColored(vector, "Each time: outside, wait for the level, small jump, 3 s, /enl, Yes - then the lifestone and again.\nRefused with everything there: Subway recall (gem or spell), outside again, retry. MelkTank's fighting is paused meanwhile.");
	}
}
