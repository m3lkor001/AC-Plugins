using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using MelkTank.Metas;
using AcClient;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Bounties;
using MelkTank.Buffs;

namespace MelkTank;

public static partial class Session
{
	private static AttrRow AttrByKey(string k)
	{
		AttrRow[] attrRows = AttrRows;
		foreach (AttrRow attrRow in attrRows)
		{
			if (string.Equals(attrRow.Key, k, StringComparison.OrdinalIgnoreCase) || string.Equals(attrRow.Key, "Max" + k, StringComparison.OrdinalIgnoreCase))
			{
				return attrRow;
			}
		}
		return null;
	}

	private static List<AttrRow> AttrOrder(Settings s)
	{
		List<AttrRow> list = new List<AttrRow>();
		string[] array = ((s != null && s.AttrOrder != null) ? s.AttrOrder : "").Split(',');
		foreach (string text in array)
		{
			AttrRow attrRow = AttrByKey(text.Trim());
			if (attrRow != null && !list.Contains(attrRow))
			{
				list.Add(attrRow);
			}
		}
		AttrRow[] attrRows = AttrRows;
		foreach (AttrRow item in attrRows)
		{
			if (!list.Contains(item))
			{
				list.Add(item);
			}
		}
		return list;
	}

	private static bool AttrOn(Settings s, AttrRow r)
	{
		return s != null && ("," + s.AttrOn + ",").IndexOf("," + r.Key + ",", StringComparison.OrdinalIgnoreCase) >= 0;
	}

	private static void AttrSetOn(Settings s, AttrRow r, bool on)
	{
		List<string> list = new List<string>();
		AttrRow[] attrRows = AttrRows;
		foreach (AttrRow attrRow in attrRows)
		{
			if ((attrRow == r) ? on : AttrOn(s, attrRow))
			{
				list.Add(attrRow.Key);
			}
		}
		s.AttrOn = string.Join(",", list.ToArray());
	}

	private static long Unassigned()
	{
		try
		{
			return CoreManager.Current.CharacterFilter.UnassignedXP;
		}
		catch
		{
			return 0L;
		}
	}

	private static int AttrBase(AttrRow r)
	{
		try
		{
			CharacterFilter characterFilter = CoreManager.Current.CharacterFilter;
			switch (r.Abbr)
			{
			case "str":
				return characterFilter.Attributes[CharFilterAttributeType.Strength].Base;
			case "end":
				return characterFilter.Attributes[CharFilterAttributeType.Endurance].Base;
			case "coo":
				return characterFilter.Attributes[CharFilterAttributeType.Coordination].Base;
			case "qui":
				return characterFilter.Attributes[CharFilterAttributeType.Quickness].Base;
			case "foc":
				return characterFilter.Attributes[CharFilterAttributeType.Focus].Base;
			case "sel":
				return characterFilter.Attributes[CharFilterAttributeType.Self].Base;
			case "hea":
				return characterFilter.Vitals[CharFilterVitalType.Health].Base;
			case "sta":
				return characterFilter.Vitals[CharFilterVitalType.Stamina].Base;
			case "man":
				return characterFilter.Vitals[CharFilterVitalType.Mana].Base;
			}
		}
		catch
		{
		}
		return -1;
	}

	private static long AttrCost(AttrRow r, int n)
	{
		if (n == 10 && r.Cost10 > 0)
		{
			return r.Cost10;
		}
		if (r.Cost <= 0)
		{
			return -1L;
		}
		double num = AttrGrowthFor(r);
		double num2 = r.Cost;
		double num3 = 0.0;
		for (int i = 0; i < n; i++)
		{
			num3 += num2;
			num2 *= num;
		}
		return (num3 > 9.223372036854776E+18) ? long.MaxValue : ((long)num3);
	}

	private static double AttrGrowthFor(AttrRow r)
	{
		if (r.Cost <= 0 || r.Cost10 <= 0)
		{
			return 1.077;
		}
		double num = (double)r.Cost10 / (double)r.Cost;
		if (num <= 10.0)
		{
			return 1.0;
		}
		double num2 = 1.0;
		double num3 = 3.0;
		for (int i = 0; i < 60; i++)
		{
			double num4 = (num2 + num3) / 2.0;
			double num5 = 0.0;
			double num6 = 1.0;
			for (int j = 0; j < 10; j++)
			{
				num5 += num6;
				num6 *= num4;
			}
			if (num5 < num)
			{
				num2 = num4;
			}
			else
			{
				num3 = num4;
			}
		}
		return (num2 + num3) / 2.0;
	}

	private static void AttrQueue(string cmd)
	{
		if (!_attrQ.Contains(cmd))
		{
			_attrQ.Add(cmd);
		}
		_attrAskedAt = DateTime.Now;
	}

	private static void AttrQueueTick()
	{
		if (_attrQ.Count != 0)
		{
			string command = _attrQ[0];
			_attrQ.RemoveAt(0);
			_attrQuietUntil = DateTime.Now.AddSeconds(4.0);
			Util.Command(command);
		}
	}

	private static void AttrAskOne(AttrRow r)
	{
		AttrQueue("/xp " + r.Abbr + " 1");
		AttrQueue("/xp " + r.Abbr + " 10");
	}

	private static void AttrAsk()
	{
		AttrQueue("/xp all");
		AttrRow[] attrRows = AttrRows;
		foreach (AttrRow attrRow in attrRows)
		{
			AttrQueue("/xp " + attrRow.Abbr + " 10");
		}
	}

	private static void AttrRaise(AttrRow r, int n)
	{
		n = Math.Max(1, Math.Min(10, n));
		Util.Command("/attr " + r.Abbr + " " + n.ToString(CultureInfo.InvariantCulture));
		r.Cost = 0L;
		r.Cost10 = 0L;
		_attrSentAt = DateTime.Now;
	}

	private static void AttrChat(string text)
	{
		string input = text.Trim();
		Match match = AttrCostRx.Match(input);
		if (match.Success)
		{
			AttrRow attrRow = AttrByKey(match.Groups[2].Value);
			if (attrRow != null && int.TryParse(match.Groups[1].Value, out var result) && long.TryParse(match.Groups[3].Value.Replace(",", ""), NumberStyles.Integer, CultureInfo.InvariantCulture, out var result2))
			{
				switch (result)
				{
				case 1:
					attrRow.Cost = result2;
					break;
				case 10:
					attrRow.Cost10 = result2;
					break;
				}
				attrRow.CostAt = DateTime.Now;
			}
		}
		else if (AttrRaisedRx.IsMatch(input))
		{
			AttrRow attrRow2 = AttrByKey(AttrRaisedRx.Match(input).Groups[1].Value);
			if (_attrWaitRaise)
			{
				_attrWaitRaise = false;
				_attrNextStep = DateTime.Now.AddMilliseconds(400.0);
			}
			if (attrRow2 != null && (DateTime.Now - _attrSentAt).TotalSeconds < 8.0)
			{
				AttrAskOne(attrRow2);
			}
		}
	}

	private static bool AttrQuiet(string s)
	{
		if (DateTime.Now > _attrQuietUntil)
		{
			return false;
		}
		if (s.StartsWith("[XP]", StringComparison.OrdinalIgnoreCase))
		{
			_attrQuietUntil = DateTime.Now.AddSeconds(2.0);
			return true;
		}
		return false;
	}

	public static void AttrSpendNow()
	{
		if (!_attrSpending)
		{
			_attrSpending = true;
			_attrWaitRaise = false;
			_attrSpentLevels = 0;
			_attrSpentNote = "";
			_attrStatus = "reading the costs";
			AttrAsk();
			_attrNextStep = DateTime.Now.AddSeconds(2.5);
		}
	}

	private static void AttrStop(string why)
	{
		if (_attrSpending)
		{
			_attrSpending = false;
			_attrWaitRaise = false;
			_attrStatus = why + ((_attrSpentLevels > 0) ? (" - raised " + _attrSpentNote.TrimEnd(new char[2] { ',', ' ' })) : "");
			if (_attrSpentLevels > 0)
			{
				Util.WriteToChat("Attributes: raised " + _attrSpentNote.TrimEnd(new char[2] { ',', ' ' }) + ".");
			}
			AttrAsk();
		}
	}

	private static void AttrTick()
	{
		Settings currentSettings = PluginCore.CurrentSettings;
		if (currentSettings == null)
		{
			return;
		}
		AttrQueueTick();
		if (!_attrSpending)
		{
			if (currentSettings.AttrAuto && DateTime.Now >= _attrNextAuto)
			{
				_attrNextAuto = DateTime.Now.AddMinutes(Math.Max(1, currentSettings.AttrIntervalMin));
				AttrSpendNow();
			}
		}
		else
		{
			if (DateTime.Now < _attrNextStep || _attrQ.Count > 0)
			{
				return;
			}
			if (_attrWaitRaise)
			{
				if ((DateTime.Now - _attrSentAt).TotalSeconds > 6.0)
				{
					AttrStop("the server didn't answer the raise");
				}
				return;
			}
			long num = Unassigned();
			foreach (AttrRow item in AttrOrder(currentSettings))
			{
				if (!AttrOn(currentSettings, item))
				{
					continue;
				}
				if (item.Cost <= 0)
				{
					if ((DateTime.Now - _attrAskedAt).TotalSeconds > 5.0)
					{
						AttrAskOne(item);
						_attrNextStep = DateTime.Now.AddSeconds(1.5);
						return;
					}
				}
				else
				{
					if (item.Cost > num)
					{
						continue;
					}
					int num2 = 1;
					for (int num3 = 10; num3 > 1; num3--)
					{
						if (AttrCost(item, num3) <= num)
						{
							num2 = num3;
							break;
						}
					}
					_attrStatus = "raising " + item.Name + " +" + num2;
					_attrSpentLevels += num2;
					_attrSpentNote = _attrSpentNote + item.Name + " +" + num2 + ", ";
					AttrRaise(item, num2);
					_attrWaitRaise = true;
					return;
				}
			}
			AttrStop((num > 0) ? "can't pay for the next level of any ticked one" : "no unassigned XP");
		}
	}

	private static string XpBig(long v)
	{
		return (v < 0) ? "?" : Lum(v);
	}

	private static void DrawAttr()
	{
		Settings currentSettings = PluginCore.CurrentSettings;
		if (currentSettings == null)
		{
			return;
		}
		Vector4 vector = new Vector4(0.45f, 0.9f, 0.45f, 1f);
		Vector4 col = new Vector4(1f, 0.5f, 0.45f, 1f);
		Vector4 vector2 = new Vector4(0.6f, 0.6f, 0.6f, 1f);
		bool flag = false;
		AttrRow[] attrRows = AttrRows;
		foreach (AttrRow attrRow in attrRows)
		{
			if (attrRow.Cost > 0)
			{
				flag = true;
			}
		}
		if (!flag && !_attrSpending && (DateTime.Now - _attrAskedAt).TotalSeconds > 30.0)
		{
			AttrAsk();
		}
		long num = Unassigned();
		int num2 = 0;
		long v = 0L;
		try
		{
			num2 = CoreManager.Current.CharacterFilter.Level;
			v = CoreManager.Current.CharacterFilter.TotalXP;
		}
		catch
		{
		}
		if (ImGui.Button("Refresh costs##attrref"))
		{
			AttrAsk();
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Sends /xp all quietly - the server's cost for the next level of each.");
		}
		ImGui.SameLine();
		Im.TextColored(Cyan, "Level " + num2 + "   Total XP " + XpBig(v) + "   Unassigned " + XpBig(num));
		bool flag2 = false;
		flag2 |= ImGui.Checkbox("Auto spend##attrauto", ref currentSettings.AttrAuto);
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Every so many minutes: reads the costs, then raises the ticked ones in the order below -\nthe first one the XP pays for (10 levels at a time when it can, else 1), again and again until it can't pay for any.");
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		if (ImGui.InputInt("every (min)##attrint", ref currentSettings.AttrIntervalMin, 1, 5))
		{
			if (currentSettings.AttrIntervalMin < 1)
			{
				currentSettings.AttrIntervalMin = 1;
			}
			flag2 = true;
			_attrNextAuto = DateTime.Now.AddMinutes(currentSettings.AttrIntervalMin);
		}
		ImGui.SameLine();
		if (_attrSpending)
		{
			if (ImGui.Button("Stop##attrstop"))
			{
				AttrStop("stopped");
			}
		}
		else if (ImGui.Button("Spend now##attrspend"))
		{
			AttrSpendNow();
		}
		if (currentSettings.AttrAuto && !_attrSpending)
		{
			ImGui.SameLine();
			Im.TextColored(vector2, "next in " + Math.Max(0, (int)(_attrNextAuto - DateTime.Now).TotalMinutes) + "m");
		}
		if (_attrStatus.Length > 0)
		{
			Im.TextColored(_attrSpending ? Yellow : vector2, _attrStatus);
		}
		List<AttrRow> list = AttrOrder(currentSettings);
		int num3 = -1;
		int num4 = 0;
		if (ImGui.BeginTable("##attrtbl", 6, ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("Auto");
			ImGui.TableSetupColumn("Order");
			ImGui.TableSetupColumn("Attribute", ImGuiTableColumnFlags.WidthStretch);
			ImGui.TableSetupColumn("Base");
			ImGui.TableSetupColumn("+1");
			ImGui.TableSetupColumn("+10");
			ImGui.TableHeadersRow();
			for (int j = 0; j < list.Count; j++)
			{
				AttrRow attrRow2 = list[j];
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				bool v2 = AttrOn(currentSettings, attrRow2);
				if (ImGui.Checkbox("##attron" + attrRow2.Abbr, ref v2))
				{
					AttrSetOn(currentSettings, attrRow2, v2);
					flag2 = true;
				}
				ImGui.TableSetColumnIndex(1);
				if (j == 0)
				{
					ImGui.BeginDisabled();
				}
				if (ImGui.ArrowButton("##attrup" + attrRow2.Abbr, ImGuiDir.Up))
				{
					num3 = j;
					num4 = -1;
				}
				if (j == 0)
				{
					ImGui.EndDisabled();
				}
				ImGui.SameLine();
				if (j == list.Count - 1)
				{
					ImGui.BeginDisabled();
				}
				if (ImGui.ArrowButton("##attrdn" + attrRow2.Abbr, ImGuiDir.Down))
				{
					num3 = j;
					num4 = 1;
				}
				if (j == list.Count - 1)
				{
					ImGui.EndDisabled();
				}
				ImGui.TableSetColumnIndex(2);
				ImGui.AlignTextToFramePadding();
				Im.Text(j + 1 + ". " + attrRow2.Name);
				ImGui.TableSetColumnIndex(3);
				ImGui.AlignTextToFramePadding();
				int num5 = AttrBase(attrRow2);
				Im.Text((num5 >= 0) ? num5.ToString(CultureInfo.InvariantCulture) : "?");
				long num6 = AttrCost(attrRow2, 1);
				long num7 = AttrCost(attrRow2, 10);
				ImGui.TableSetColumnIndex(4);
				if (num6 > 0 && num6 > num)
				{
					ImGui.PushStyleColor(ImGuiCol.Text, col);
				}
				if (ImGui.Button(((num6 > 0) ? XpBig(num6) : "?") + "##attr1" + attrRow2.Abbr, new Vector2(90f, 0f)) && !_attrSpending)
				{
					AttrRaise(attrRow2, 1);
				}
				if (num6 > 0 && num6 > num)
				{
					ImGui.PopStyleColor();
				}
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip("/attr " + attrRow2.Abbr + " 1" + ((num6 > 0) ? (" - " + num6.ToString("N0", CultureInfo.InvariantCulture) + " XP") : " (Refresh costs first)"));
				}
				ImGui.TableSetColumnIndex(5);
				if (num7 > 0 && num7 > num)
				{
					ImGui.PushStyleColor(ImGuiCol.Text, col);
				}
				if (ImGui.Button(((num7 > 0) ? (((attrRow2.Cost10 > 0) ? "" : "~") + XpBig(num7)) : "?") + "##attr10" + attrRow2.Abbr, new Vector2(90f, 0f)) && !_attrSpending)
				{
					AttrRaise(attrRow2, 10);
				}
				if (num7 > 0 && num7 > num)
				{
					ImGui.PopStyleColor();
				}
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip("/attr " + attrRow2.Abbr + " 10 - about " + ((num7 > 0) ? num7.ToString("N0", CultureInfo.InvariantCulture) : "?") + " XP (the server's figure)");
				}
			}
			ImGui.EndTable();
		}
		if (num3 >= 0)
		{
			AttrRow value = list[num3];
			list[num3] = list[num3 + num4];
			list[num3 + num4] = value;
			List<string> list2 = new List<string>();
			foreach (AttrRow item in list)
			{
				list2.Add(item.Key);
			}
			currentSettings.AttrOrder = string.Join(",", list2.ToArray());
			flag2 = true;
		}
		Im.TextColored(vector2, "Red = more than your unassigned XP (~ = estimated). The server raises at most 10 at a time.");
		if (flag2)
		{
			PluginCore.SaveAllNow();
		}
	}
}
