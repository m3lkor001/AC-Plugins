using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
#if !RETAIL
using ACGodot.DecalShim;
using ACGodot.Plugins;
using Godot;
#endif
using AcClient;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using MelkTank.Metas;

namespace MelkTank;

// MelkTank's own /ub commands - one file for both builds (it was two copies): what's the same is here once; where the
// two clients do it differently (ACGodot through the game, retail through the client's memory and UtilityBelt) each
// has its own version, marked #if RETAIL / #if !RETAIL.
#if RETAIL
public static unsafe class UbCmd
#else
public static class UbCmd
#endif
{
	private enum Where
	{
		All,
		Inventory,
		Landscape
	}

	private class GiveStep
	{
		public int Item;

		public int Amount;
	}

	private struct WRECT
	{
		public int L;

		public int T;

		public int R;

		public int B;
	}

	[UnmanagedFunctionPointer(CallingConvention.ThisCall)]
	private delegate void ThisVoid(int self);

	[UnmanagedFunctionPointer(CallingConvention.ThisCall)]
	private delegate float ThisFloat(int self);

	[UnmanagedFunctionPointer(CallingConvention.ThisCall)]
	private delegate void ThisVoidInt(int self, int a);

	[UnmanagedFunctionPointer(CallingConvention.ThisCall)]
	private delegate double ThisDouble(int self);

	[UnmanagedFunctionPointer(CallingConvention.ThisCall)]
	private delegate bool ThisHeading(int self, float deg, int send);

	private enum JState
	{
		Idle,
		Turning,
		Charging,
		Checking
	}

	private static readonly Regex Head = new Regex("^[/@]ub\\s+(?<verb>[a-z]+)\\s*(?<rest>.*)$", RegexOptions.IgnoreCase);

	private static readonly Regex UseRx = new Regex("^(?<one>.+?)(?=\\son|$)( on (?<two>.+))?$");

	private static readonly Regex GiveRx = new Regex("^((?<n>\\d+)? ?(?<item>.+?) to (?<to>.+)|(?<stop>stop|cancel|quit|abort))$");

	private static readonly Queue<GiveStep> _give = new Queue<GiveStep>();

	private static int _giveTarget;

	private static int _giveWaitItem;

	private static int _giveDelayMs;

	private static int _giveDone;

	private static int _giveTotal;

	private static DateTime _giveSent = DateTime.MinValue;
#if !RETAIL

	private static DateTime _acgCommence = DateTime.MinValue;
#endif

	private static JState _j = JState.Idle;

	private static float _jHeading;

	private static float _jPower;

	private static bool _jShift;

	private static bool _jW;

	private static bool _jX;

	private static bool _jZ;

	private static bool _jC;

	private static DateTime _jAt;

	private static DateTime _jCharge;

	private static DateTime _jTurnAsk;

	private static DateTime _jReleased;

	private static int _jTries;

	private static bool _jAir;

	private static double _jX0;

	private static double _jY0;

	private static double _jZ0;

	private static bool _frameHooked;

	private static readonly Regex JumpRx = new Regex("^((?<h>[\\.\\d]+)\\s+)?(?<ms>\\d+)?$");

	private static float _jStartP;

	private static bool _jRising;

	private static DateTime _jChargeStart;

	public static bool Giving => _giveTarget != 0;
#if !RETAIL

	public static string GiveProgress => (_giveTarget == 0) ? "" : (_giveDone + " of " + _giveTotal + " stacks handed over");
#else

	public static string GiveProgress => (_giveTarget != 0) ? (_giveDone + " of " + _giveTotal + " stacks handed over") : "";
#endif

	public static bool Jumping => _j != JState.Idle;
#if !RETAIL

	private static int CombatSystem
	{
		get
		{
			ACGodot.Plugins.PluginHost host = Bridge.Host;
			return (host != null && host.Player?.Active == true) ? 1 : 0;
		}
	}
#else

	private unsafe static int CombatSystem => *(int*)8853100;
#endif

	public static bool Try(string command)
	{
		return Try(command, ours: false);
	}
#if !RETAIL

	public static bool Try(string command, bool ours)
	{
		Settings currentSettings = PluginCore.CurrentSettings;
		if (currentSettings != null)
		{
			if (currentSettings.UbNative || !ours)
			{
			}
			if (!string.IsNullOrEmpty(command))
			{
				Match match = Head.Match(command.Trim());
				if (!match.Success)
				{
					return false;
				}
				string value = match.Groups["verb"].Value;
				string text = match.Groups["rest"].Value.Trim();
				string text2 = value.ToLowerInvariant();
				try
				{
					if (text2.StartsWith("use"))
					{
						return Use(value.Substring(3), text);
					}
					if (text2.StartsWith("select"))
					{
						return Select(value.Substring(6), text);
					}
					if (text2.StartsWith("give"))
					{
						return Give(value.Substring(4), text);
					}
					if (text2 == "face")
					{
						return Face(text);
					}
					if (text2.StartsWith("jump"))
					{
						return Jump(text2.Substring(4), text);
					}
					switch (text2)
					{
					case "vendor":
						return VendorCmd(text);
					case "combatstate":
						return CombatStateCmd(text);
					case "fellow":
						return Fellow(text);
					case "resolution":
						return Resolution(text);
					case "mexec":
						if (UbExpr.Own)
						{
							object v = Expr.Eval(text, out var error);
							Util.WriteToChat((error != null) ? ("mexec error: " + error) : ("Result: [" + Expr.TypeName(v) + "] " + Expr.Str(v)));
							return true;
						}
						break;
					}
				}
				catch (Exception ex)
				{
					Util.LogError(ex);
					Util.WriteToChat("/ub " + value + ": " + ex.Message);
					return true;
				}
				return false;
			}
		}
		return false;
	}
#else

	public static bool Try(string command, bool ours)
	{
		Settings currentSettings = PluginCore.CurrentSettings;
		if (currentSettings == null || (!currentSettings.UbNative && !ours) || string.IsNullOrEmpty(command))
		{
			return false;
		}
		Match match = Head.Match(command.Trim());
		if (!match.Success)
		{
			return false;
		}
		string value = match.Groups["verb"].Value;
		string text = match.Groups["rest"].Value.Trim();
		string text2 = value.ToLowerInvariant();
		try
		{
			if (text2.StartsWith("use"))
			{
				return Use(value.Substring(3), text);
			}
			if (text2.StartsWith("select"))
			{
				return Select(value.Substring(6), text);
			}
			if (text2.StartsWith("give"))
			{
				return Give(value.Substring(4), text);
			}
			if (text2 == "face")
			{
				return Face(text);
			}
			if (text2.StartsWith("jump"))
			{
				return Jump(text2.Substring(4), text);
			}
			switch (text2)
			{
			case "combatstate":
				return CombatStateCmd(text);
			case "fellow":
				return Fellow(text);
			case "resolution":
				return Resolution(text);
			case "mexec":
				if (UbExpr.Own)
				{
					object v = Expr.Eval(text, out var error);
					Util.WriteToChat((error == null) ? ("Result: [" + Expr.TypeName(v) + "] " + Expr.Str(v)) : ("mexec error: " + error));
					return true;
				}
				break;
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			Util.WriteToChat("/ub " + value + ": " + ex.Message);
			return true;
		}
		return false;
	}
#endif

	private static WorldObject Special(string name)
	{
		WorldFilter worldFilter = CoreManager.Current.WorldFilter;
		if (int.TryParse(name, out var result) && worldFilter[result] != null)
		{
			return worldFilter[result];
		}
		try
		{
			result = Convert.ToInt32(name, 16);
			if (worldFilter[result] != null)
			{
				return worldFilter[result];
			}
		}
		catch
		{
		}
		if (name == "selected")
		{
			int currentSelection = CoreManager.Current.Actions.CurrentSelection;
			if (currentSelection != 0 && worldFilter[currentSelection] != null)
			{
				return worldFilter[currentSelection];
			}
		}
		return null;
	}
#if !RETAIL

	private static bool NameIs(WorldObject o, string name, bool partial)
	{
		return partial ? ItemNames.Contains(o, name) : ItemNames.Is(o, name);
	}
#else

	private static bool NameIs(WorldObject o, string name, bool partial)
	{
		return (!partial) ? ItemNames.Is(o, name) : ItemNames.Contains(o, name);
	}
#endif
#if !RETAIL

	private static WorldObject Find(string name, Where where, bool partial, WorldObject exclude = null)
	{
		WorldObject worldObject = Special(name);
		if (worldObject != null)
		{
			return worldObject;
		}
		WorldFilter worldFilter = CoreManager.Current.WorldFilter;
		if (where != Where.Landscape)
		{
			foreach (WorldObject item in worldFilter.GetInventory())
			{
				if (item != null && (exclude == null || item.Id != exclude.Id) && NameIs(item, name, partial))
				{
					return item;
				}
			}
			if (where == Where.All && CoreManager.Current.Actions.OpenedContainer != 0)
			{
				foreach (WorldObject item2 in worldFilter.GetByContainer(CoreManager.Current.Actions.OpenedContainer))
				{
					if (item2 != null && (exclude == null || item2.Id != exclude.Id) && NameIs(item2, name, partial))
					{
						return item2;
					}
				}
			}
			if (where == Where.Inventory)
			{
				return null;
			}
		}
		WorldObject result = null;
		double num = double.MaxValue;
		foreach (WorldObject item3 in worldFilter.GetLandscape())
		{
			if (item3 != null && (exclude == null || item3.Id != exclude.Id) && NameIs(item3, name, partial))
			{
				double num2 = CombatEngine.Distance(item3);
				if (num2 < num)
				{
					num = num2;
					result = item3;
				}
			}
		}
		return result;
	}
#else

	private static WorldObject Find(string name, Where where, bool partial, WorldObject exclude = null)
	{
		WorldObject val = Special(name);
		if (val != null)
		{
			return val;
		}
		WorldFilter worldFilter = CoreManager.Current.WorldFilter;
		if (where != Where.Landscape)
		{
			foreach (WorldObject item in worldFilter.GetInventory())
			{
				if (item != null && (exclude == null || item.Id != exclude.Id) && NameIs(item, name, partial))
				{
					return item;
				}
			}
			if (where == Where.All && CoreManager.Current.Actions.OpenedContainer != 0)
			{
				foreach (WorldObject item2 in worldFilter.GetByContainer(CoreManager.Current.Actions.OpenedContainer))
				{
					if (item2 != null && (exclude == null || item2.Id != exclude.Id) && NameIs(item2, name, partial))
					{
						return item2;
					}
				}
			}
			if (where == Where.Inventory)
			{
				return null;
			}
		}
		WorldObject result = null;
		double num = double.MaxValue;
		foreach (WorldObject item3 in worldFilter.GetLandscape())
		{
			if (item3 != null && (exclude == null || item3.Id != exclude.Id) && NameIs(item3, name, partial))
			{
				double num2 = CombatEngine.Distance(item3);
				if (num2 < num)
				{
					num = num2;
					result = item3;
				}
			}
		}
		return result;
	}
#endif
#if !RETAIL

	private static WorldObject FindPerson(string name, bool partial, params ObjectClass[] oc)
	{
		WorldObject worldObject = (string.IsNullOrEmpty(name) ? null : Special(name));
		if (worldObject != null)
		{
			return worldObject;
		}
		int id = CoreManager.Current.CharacterFilter.Id;
		WorldObject result = null;
		double num = double.MaxValue;
		foreach (WorldObject item in CoreManager.Current.WorldFilter.GetLandscape())
		{
			if (item != null && item.Id != id && Array.IndexOf(oc, item.ObjectClass) >= 0 && (string.IsNullOrEmpty(name) || (partial ? ItemNames.Contains(item, name) : ItemNames.Is(item, name))))
			{
				double num2 = CombatEngine.Distance(item);
				if (num2 < num)
				{
					num = num2;
					result = item;
				}
			}
		}
		return result;
	}
#else

	private static WorldObject FindPerson(string name, bool partial, params ObjectClass[] oc)
	{
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		WorldObject val = ((!string.IsNullOrEmpty(name)) ? Special(name) : null);
		if (val != null)
		{
			return val;
		}
		int id = CoreManager.Current.CharacterFilter.Id;
		WorldObject result = null;
		double num = double.MaxValue;
		foreach (WorldObject item in CoreManager.Current.WorldFilter.GetLandscape())
		{
			if (item != null && item.Id != id && Array.IndexOf(oc, item.ObjectClass) >= 0 && (string.IsNullOrEmpty(name) || ((!partial) ? ItemNames.Is(item, name) : ItemNames.Contains(item, name))))
			{
				double num2 = CombatEngine.Distance(item);
				if (num2 < num)
				{
					num = num2;
					result = item;
				}
			}
		}
		return result;
	}
#endif

	private static bool Flags(string f, out Where where, out bool partial)
	{
		f = f.ToLowerInvariant();
		partial = f.Contains("p");
		where = (f.Contains("i") ? Where.Inventory : (f.Contains("l") ? Where.Landscape : Where.All));
		if (f.Contains("i") && f.Contains("l"))
		{
			Util.WriteToChat("l and i cannot be used in the same command");
			return false;
		}
		return true;
	}
#if !RETAIL

	private static bool Use(string f, string rest)
	{
		if (!Flags(f, out var where, out var partial) || rest.Length == 0)
		{
			return true;
		}
		Match match = UseRx.Match(rest);
		string value = match.Groups["one"].Value;
		string value2 = match.Groups["two"].Value;
		WorldObject worldObject = Find(value, where, partial);
		if (worldObject == null)
		{
			Util.WriteToChat("Could not find object: " + value);
			return true;
		}
		if (string.IsNullOrEmpty(value2))
		{
			Util.WriteToChat("using " + worldObject.Name);
			CoreManager.Current.Actions.UseItem(worldObject.Id, 0);
			return true;
		}
		WorldObject worldObject2 = Find(value2, Where.All, partial, worldObject);
		if (worldObject2 == null)
		{
			Util.WriteToChat(value2 + " is null");
			return true;
		}
		Util.WriteToChat("using " + worldObject.Name + " on " + worldObject2.Name);
		if (worldObject.ObjectClass == ObjectClass.WandStaffOrb && CoreManager.Current.Actions.CombatMode == CombatState.Magic)
		{
			CoreManager.Current.Actions.SelectItem(worldObject2.Id);
			CoreManager.Current.Actions.UseItem(worldObject.Id, 1, worldObject2.Id);
		}
		else
		{
			CoreManager.Current.Actions.ApplyItem(worldObject.Id, worldObject2.Id);
		}
		return true;
	}
#else

	private static bool Use(string f, string rest)
	{
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Invalid comparison between Unknown and I4
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Invalid comparison between Unknown and I4
		if (!Flags(f, out var where, out var partial) || rest.Length == 0)
		{
			return true;
		}
		Match match = UseRx.Match(rest);
		string value = match.Groups["one"].Value;
		string value2 = match.Groups["two"].Value;
		WorldObject val = Find(value, where, partial);
		if (val == null)
		{
			Util.WriteToChat("Could not find object: " + value);
			return true;
		}
		if (string.IsNullOrEmpty(value2))
		{
			Util.WriteToChat("using " + val.Name);
			CoreManager.Current.Actions.UseItem(val.Id, 0);
			return true;
		}
		WorldObject val2 = Find(value2, Where.All, partial, val);
		if (val2 == null)
		{
			Util.WriteToChat(value2 + " is null");
			return true;
		}
		Util.WriteToChat("using " + val.Name + " on " + val2.Name);
		if ((int)val.ObjectClass == 31 && (int)CoreManager.Current.Actions.CombatMode == 8)
		{
			CoreManager.Current.Actions.SelectItem(val2.Id);
			CoreManager.Current.Actions.UseItem(val.Id, 1, val2.Id);
		}
		else
		{
			CoreManager.Current.Actions.ApplyItem(val.Id, val2.Id);
		}
		return true;
	}
#endif
#if !RETAIL

	// the nearest thing about with this name, whatever kind it is (not you, not what you carry)
	private static WorldObject FindNamedHere(string name, bool partial)
	{
		if (string.IsNullOrEmpty(name))
		{
			return null;
		}
		int id = CoreManager.Current.CharacterFilter.Id;
		WorldObject result = null;
		double num = double.MaxValue;
		foreach (WorldObject item in CoreManager.Current.WorldFilter.GetLandscape())
		{
			if (item != null && item.Id != id && (partial ? ItemNames.Contains(item, name) : ItemNames.Is(item, name)))
			{
				double num2 = CombatEngine.Distance(item);
				if (num2 >= 0.0 && num2 < num)
				{
					num = num2;
					result = item;
				}
			}
		}
		return result;
	}
#endif
#if !RETAIL

	// /ub vendor open[p] <name> | addbuy[p] [count] <ware> | buyall | clearbuy | addsell[p] <item> | sellall | clearsell
	private static readonly Regex VendorCountRx = new Regex("^(?<n>\\d+)\\s+(?<name>.+)$");
#endif
#if !RETAIL

	// what /ub vendor addbuy put on the buy list (said in chat with the Vendor page's "Say the buy list"), and after
	// buyall what came (said with "Say what was bought") - as MelkTank's own vendor visits say them
	private class UbBuy
	{
		public string Name;
		public int Count;
		public long Each;
		public int Before;
	}
#endif
#if !RETAIL

	private static readonly List<UbBuy> _ubBuys = new List<UbBuy>();
#endif
#if !RETAIL

	private static List<UbBuy> _ubWatch;
#endif
#if !RETAIL

	private static DateTime _ubWatchUntil;
#endif
#if !RETAIL

	private static void UbAddedBuy(Vendor vendor, WorldObject ware, int count)
	{
		long each = VendorRun.PriceOf(ware, (vendor != null && vendor.SellRate > 0f) ? vendor.SellRate : 1f);
		UbBuy b = _ubBuys.Find((UbBuy x) => string.Equals(x.Name, ware.Name, StringComparison.OrdinalIgnoreCase));
		if (b == null) _ubBuys.Add(b = new UbBuy { Name = ware.Name, Each = each });
		b.Count += count;
		if (PluginCore.CurrentSettings?.VendorSayBuyList == true)
		{
			Util.WriteToChat("Vendor: added to the buy list: " + ware.Name + " x" + count + " (" + VendorRun.Money(each * count) + ") - " + VendorRun.Money(UbBuyTotal()) + " on it in all");
		}
	}
#endif
#if !RETAIL

	private static long UbBuyTotal()
	{
		long t = 0L;
		foreach (UbBuy x in _ubBuys) t += x.Each * x.Count;
		return t;
	}
#endif
#if !RETAIL

	private static void UbBought()
	{
		if (_ubBuys.Count == 0) return;
		foreach (UbBuy b in _ubBuys) b.Before = VendorRun.CountByName(b.Name);
		_ubWatch = new List<UbBuy>(_ubBuys);
		_ubBuys.Clear();
		_ubWatchUntil = DateTime.Now.AddSeconds(8.0);
	}
#endif
#if !RETAIL

	private static void UbBuyTick()
	{
		if (_ubWatch == null) return;
		bool all = _ubWatch.TrueForAll((UbBuy b) => VendorRun.CountByName(b.Name) - b.Before >= b.Count);
		if (!all && DateTime.Now < _ubWatchUntil) return;
		List<UbBuy> watch = _ubWatch;
		_ubWatch = null;
		if (PluginCore.CurrentSettings?.VendorSayBought != true) return;
		List<string> got = new List<string>();
		long paid = 0L;
		foreach (UbBuy b in watch)
		{
			int n = Math.Max(0, Math.Min(b.Count, VendorRun.CountByName(b.Name) - b.Before));
			if (n > 0) { got.Add(b.Name + " x" + n); paid += b.Each * n; }
		}
		Util.WriteToChat(got.Count > 0 ? "Vendor: bought " + string.Join(", ", got.ToArray()) + " - " + VendorRun.Money(paid) : "Vendor: nothing came from the buy list");
	}
#endif
#if !RETAIL

	private static bool VendorCmd(string rest)
	{
		string[] array = rest.Split(new char[1] { ' ' }, 2, StringSplitOptions.RemoveEmptyEntries);
		if (array.Length == 0)
		{
			Util.WriteToChat("Usage: /ub vendor open[p] <name> | addbuy[p] [count] <item> | buyall | clearbuy | addsell[p] <item> | sellall | clearsell");
			return true;
		}
		string text = array[0].ToLowerInvariant();
		string text2 = ((array.Length > 1) ? array[1].Trim() : "");
		bool partial = text.EndsWith("p") && text != "open" && !text.StartsWith("opencancel");
		string text3 = (partial ? text.Substring(0, text.Length - 1) : text);
		var actions = CoreManager.Current.Actions;
		switch (text3)
		{
		case "open":
		{
			WorldObject worldObject = FindPerson(text2, partial, ObjectClass.Vendor, ObjectClass.Npc) ?? FindNamedHere(text2, partial);
			if (worldObject == null)
			{
				Util.WriteToChat("vendor: " + text2 + " not found");
				return true;
			}
			actions.SelectItem(worldObject.Id);
			actions.UseItem(worldObject.Id, 0);
			return true;
		}
		case "opencancel":
			return true;
		case "clearbuy":
			actions.VendorClearBuyList();
			_ubBuys.Clear();
			return true;
		case "clearsell":
			actions.VendorClearSellList();
			return true;
		case "buyall":
			if (CoreManager.Current.WorldFilter.OpenVendor == null)
			{
				Util.WriteToChat("vendor: no vendor open");
				return true;
			}
			actions.VendorBuyAll();
			UbBought();
			return true;
		case "sellall":
			if (CoreManager.Current.WorldFilter.OpenVendor == null)
			{
				Util.WriteToChat("vendor: no vendor open");
				return true;
			}
			actions.VendorSellAll();
			return true;
		case "addbuy":
		{
			Vendor openVendor = CoreManager.Current.WorldFilter.OpenVendor;
			if (openVendor == null)
			{
				Util.WriteToChat("vendor: no vendor open");
				return true;
			}
			int result = 1;
			string text4 = text2;
			Match match = VendorCountRx.Match(text2);
			if (match.Success)
			{
				int.TryParse(match.Groups["n"].Value, out result);
				text4 = match.Groups["name"].Value.Trim();
			}
			WorldObject worldObject2 = null;
			foreach (WorldObject item in openVendor)
			{
				if (item != null && (partial ? (item.Name ?? "").IndexOf(text4, StringComparison.OrdinalIgnoreCase) >= 0 : string.Equals(item.Name, text4, StringComparison.OrdinalIgnoreCase)))
				{
					worldObject2 = item;
					break;
				}
			}
			if (worldObject2 == null)
			{
				Util.WriteToChat("vendor: " + text4 + " isn't for sale here");
				return true;
			}
			actions.VendorAddBuyList(worldObject2.Id, Math.Max(1, result));
			UbAddedBuy(openVendor, worldObject2, Math.Max(1, result));
			return true;
		}
		case "addsell":
		{
			WorldObject worldObject3 = Find(text2, Where.Inventory, partial);
			if (worldObject3 == null)
			{
				Util.WriteToChat("vendor: " + text2 + " not in your inventory");
				return true;
			}
			actions.VendorAddSellList(worldObject3.Id);
			return true;
		}
		default:
			Util.WriteToChat("vendor: unknown command " + text);
			return true;
		}
	}
#endif
#if !RETAIL

	private static bool Select(string f, string rest)
	{
		if (!Flags(f, out var where, out var partial) || rest.Length == 0)
		{
			return true;
		}
		WorldObject worldObject = Find(rest, where, partial);
		if (worldObject != null)
		{
			CoreManager.Current.Actions.SelectItem(worldObject.Id);
		}
		return true;
	}
#else

	private static bool Select(string f, string rest)
	{
		if (!Flags(f, out var where, out var partial) || rest.Length == 0)
		{
			return true;
		}
		WorldObject val = Find(rest, where, partial);
		if (val != null)
		{
			CoreManager.Current.Actions.SelectItem(val.Id);
		}
		return true;
	}
#endif
#if !RETAIL

	private static bool Give(string f, string rest)
	{
		Match match = GiveRx.Match(rest);
		if (!match.Success)
		{
			Util.WriteToChat("Usage: /ub give[p][P][r] [count] <item> to <target>");
			return true;
		}
		if (match.Groups["stop"].Success && match.Groups["stop"].Value.Length > 0)
		{
			_give.Clear();
			_giveTarget = 0;
			Util.WriteToChat("give: stopped.");
			return true;
		}
		bool partial = f.Contains("P");
		bool flag = f.Contains("p");
		bool flag2 = f.Contains("r");
		int result = 0;
		if (match.Groups["n"].Success)
		{
			int.TryParse(match.Groups["n"].Value, out result);
		}
		if (result < 1)
		{
			result = int.MaxValue;
		}
		string value = match.Groups["item"].Value;
		string value2 = match.Groups["to"].Value;
		// (whatever is named - a person, an NPC, a statue, a chest: the server says whether it takes it)
		WorldObject worldObject = FindPerson(value2, partial, ObjectClass.Player, ObjectClass.Npc, ObjectClass.Vendor) ?? FindNamedHere(value2, partial);
		if (worldObject == null)
		{
			Util.WriteToChat("give: " + value2 + " not found");
			return true;
		}
		if (_give.Count > 0)
		{
			Util.WriteToChat("give: already giving - wait, or /ub give stop");
			return true;
		}
		Regex regex = (flag2 ? new Regex(value) : null);
		long num = result;
		foreach (WorldObject item in CoreManager.Current.WorldFilter.GetInventory())
		{
			if (num <= 0)
			{
				break;
			}
			if (item != null)
			{
				string text = item.Name ?? "";
				bool flag3;
				if (flag2)
				{
					flag3 = regex.IsMatch(text);
				}
				else
				{
					flag3 = (flag ? (text.IndexOf(value, StringComparison.OrdinalIgnoreCase) >= 0) : text.Equals(value, StringComparison.OrdinalIgnoreCase));
				}
				if (flag3)
				{
					int num2 = Math.Max(1, item.Values(LongValueKey.StackCount, 1));
					int num3 = (int)Math.Min(num2, num);
					_give.Enqueue(new GiveStep
					{
						Item = item.Id,
						Amount = num3
					});
					num -= num3;
				}
			}
		}
		if (_give.Count == 0)
		{
			Util.WriteToChat("give: no " + value + " in your pack");
			return true;
		}
		_giveTarget = worldObject.Id;
		_giveWaitItem = 0;
		_giveDelayMs = 0;
		_giveDone = 0;
		_giveTotal = _give.Count;
		return true;
	}
#else

	private static bool Give(string f, string rest)
	{
		Match match = GiveRx.Match(rest);
		if (!match.Success)
		{
			Util.WriteToChat("Usage: /ub give[p][P][r] [count] <item> to <target>");
			return true;
		}
		if (match.Groups["stop"].Success && match.Groups["stop"].Value.Length > 0)
		{
			_give.Clear();
			_giveTarget = 0;
			Util.WriteToChat("give: stopped.");
			return true;
		}
		bool partial = f.Contains("P");
		bool flag = f.Contains("p");
		bool flag2 = f.Contains("r");
		int result = 0;
		if (match.Groups["n"].Success)
		{
			int.TryParse(match.Groups["n"].Value, out result);
		}
		if (result < 1)
		{
			result = int.MaxValue;
		}
		string value = match.Groups["item"].Value;
		string value2 = match.Groups["to"].Value;
		WorldObject val = FindPerson(value2, partial, (ObjectClass)24, (ObjectClass)37);
		if (val == null)
		{
			Util.WriteToChat("give: player " + value2 + " not found");
			return true;
		}
		if (_give.Count > 0)
		{
			Util.WriteToChat("give: already giving - wait, or /ub give stop");
			return true;
		}
		Regex regex = ((!flag2) ? null : new Regex(value));
		long num = result;
		foreach (WorldObject item in CoreManager.Current.WorldFilter.GetInventory())
		{
			if (num <= 0)
			{
				break;
			}
			if (item != null)
			{
				string text = item.Name ?? "";
				bool flag3;
				if (flag2)
				{
					flag3 = regex.IsMatch(text);
				}
				else
				{
					flag3 = ((!flag) ? text.Equals(value, StringComparison.OrdinalIgnoreCase) : (text.IndexOf(value, StringComparison.OrdinalIgnoreCase) >= 0));
				}
				if (flag3)
				{
					int num2 = Math.Max(1, item.Values((LongValueKey)218103814, 1));
					int num3 = (int)Math.Min(num2, num);
					_give.Enqueue(new GiveStep
					{
						Item = item.Id,
						Amount = num3
					});
					num -= num3;
				}
			}
		}
		if (_give.Count == 0)
		{
			Util.WriteToChat("give: no " + value + " in your pack");
			return true;
		}
		_giveTarget = val.Id;
		_giveWaitItem = 0;
		_giveDelayMs = 0;
		_giveDone = 0;
		_giveTotal = _give.Count;
		return true;
	}
#endif
#if !RETAIL

	public static string StartGive(int targetId, string itemName, long count, int delayMs)
	{
		if (_give.Count > 0 || _giveTarget != 0)
		{
			return "Already giving - Stop first.";
		}
		WorldObject worldObject = CoreManager.Current.WorldFilter[targetId];
		if (worldObject == null)
		{
			return "The target isn't around any more.";
		}
		long num = ((count > 0) ? count : long.MaxValue);
		foreach (WorldObject item in CoreManager.Current.WorldFilter.GetInventory())
		{
			if (num <= 0)
			{
				break;
			}
			if (item != null && ItemNames.Is(item, itemName) && item.Values(LongValueKey.EquippedSlots, 0) == 0)
			{
				int num2 = Math.Max(1, item.Values(LongValueKey.StackCount, 1));
				int num3 = (int)Math.Min(num2, num);
				_give.Enqueue(new GiveStep
				{
					Item = item.Id,
					Amount = num3
				});
				num -= num3;
			}
		}
		if (_give.Count == 0)
		{
			return "No " + itemName + " in your pack.";
		}
		_giveTarget = targetId;
		_giveWaitItem = 0;
		_giveDelayMs = Math.Max(0, delayMs);
		_giveDone = 0;
		_giveTotal = _give.Count;
		return "Giving " + itemName + " to " + worldObject.Name + " (" + _giveTotal + " stack" + ((_giveTotal == 1) ? "" : "s") + ").";
	}
#else

	public static string StartGive(int targetId, string itemName, long count, int delayMs)
	{
		if (_give.Count > 0 || _giveTarget != 0)
		{
			return "Already giving - Stop first.";
		}
		WorldObject val = CoreManager.Current.WorldFilter[targetId];
		if (val == null)
		{
			return "The target isn't around any more.";
		}
		long num = ((count <= 0) ? long.MaxValue : count);
		foreach (WorldObject item in CoreManager.Current.WorldFilter.GetInventory())
		{
			if (num <= 0)
			{
				break;
			}
			if (item != null && ItemNames.Is(item, itemName) && item.Values((LongValueKey)10, 0) == 0)
			{
				int num2 = Math.Max(1, item.Values((LongValueKey)218103814, 1));
				int num3 = (int)Math.Min(num2, num);
				_give.Enqueue(new GiveStep
				{
					Item = item.Id,
					Amount = num3
				});
				num -= num3;
			}
		}
		if (_give.Count == 0)
		{
			return "No " + itemName + " in your pack.";
		}
		_giveTarget = targetId;
		_giveWaitItem = 0;
		_giveDelayMs = Math.Max(0, delayMs);
		_giveDone = 0;
		_giveTotal = _give.Count;
		return "Giving " + itemName + " to " + val.Name + " (" + _giveTotal + " stack" + ((_giveTotal != 1) ? "s" : "") + ").";
	}
#endif

	public static void StopGive()
	{
		_give.Clear();
		_giveTarget = 0;
		_giveWaitItem = 0;
	}
#if !RETAIL

	private static void GiveTick()
	{
		if (_giveTarget == 0)
		{
			return;
		}
		if (_giveWaitItem != 0)
		{
			WorldObject worldObject = CoreManager.Current.WorldFilter[_giveWaitItem];
			bool flag = worldObject == null || (worldObject.Container != CoreManager.Current.CharacterFilter.Id && !InPack(worldObject));
			if (!flag && (DateTime.Now - _giveSent).TotalSeconds < 3.0)
			{
				return;
			}
			if (flag)
			{
				_giveDone++;
			}
			_giveWaitItem = 0;
		}
		if (_giveDelayMs > 0 && (DateTime.Now - _giveSent).TotalMilliseconds < (double)_giveDelayMs)
		{
			return;
		}
		if (_give.Count == 0)
		{
			_giveTarget = 0;
			return;
		}
		GiveStep giveStep = _give.Dequeue();
		if (CoreManager.Current.WorldFilter[giveStep.Item] != null)
		{
			CM_Inventory.Event_GiveObjectRequest((uint)_giveTarget, (uint)giveStep.Item, (uint)giveStep.Amount);
			_giveWaitItem = giveStep.Item;
			_giveSent = DateTime.Now;
		}
	}
#else

	private static void GiveTick()
	{
		if (_giveTarget == 0)
		{
			return;
		}
		if (_giveWaitItem != 0)
		{
			WorldObject val = CoreManager.Current.WorldFilter[_giveWaitItem];
			bool flag = val == null || (val.Container != CoreManager.Current.CharacterFilter.Id && !InPack(val));
			if (!flag && (DateTime.Now - _giveSent).TotalSeconds < 3.0)
			{
				return;
			}
			if (flag)
			{
				_giveDone++;
			}
			_giveWaitItem = 0;
		}
		if (_giveDelayMs > 0 && (DateTime.Now - _giveSent).TotalMilliseconds < (double)_giveDelayMs)
		{
			return;
		}
		if (_give.Count == 0)
		{
			_giveTarget = 0;
			return;
		}
		GiveStep giveStep = _give.Dequeue();
		if (CoreManager.Current.WorldFilter[giveStep.Item] != null)
		{
			CM_Inventory.Event_GiveObjectRequest((uint)_giveTarget, (uint)giveStep.Item, (uint)giveStep.Amount);
			_giveWaitItem = giveStep.Item;
			_giveSent = DateTime.Now;
		}
	}
#endif

	private static bool InPack(WorldObject o) => o != null && InvCache.Has(o.Id);

	private static bool Face(string rest)
	{
		if (!double.TryParse(rest, NumberStyles.Float, CultureInfo.InvariantCulture, out var result))
		{
			Util.WriteToChat("Invalid heading: " + rest);
			return true;
		}
		CoreManager.Current.Actions.FaceHeading(result, true);
		return true;
	}
#if !RETAIL

	private static bool CombatStateCmd(string rest)
	{
		CombatState combatMode;
		switch (rest.Trim().ToLowerInvariant())
		{
		case "peace":
			combatMode = CombatState.Peace;
			break;
		case "melee":
			combatMode = CombatState.Melee;
			break;
		case "missile":
			combatMode = CombatState.Missile;
			break;
		case "magic":
			combatMode = CombatState.Magic;
			break;
		default:
			Util.WriteToChat("Usage: /ub combatstate (peace|melee|missile|magic)");
			return true;
		}
		CoreManager.Current.Actions.SetCombatMode(combatMode);
		return true;
	}
#else

	private static bool CombatStateCmd(string rest)
	{
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		CombatState combatMode;
		switch (rest.Trim().ToLowerInvariant())
		{
		case "peace":
			combatMode = (CombatState)1;
			break;
		case "melee":
			combatMode = (CombatState)2;
			break;
		case "missile":
			combatMode = (CombatState)4;
			break;
		case "magic":
			combatMode = (CombatState)8;
			break;
		default:
			Util.WriteToChat("Usage: /ub combatstate (peace|melee|missile|magic)");
			return true;
		}
		CoreManager.Current.Actions.SetCombatMode(combatMode);
		return true;
	}
#endif
#if !RETAIL

	private static bool Fellow(string rest)
	{
		string text = rest.ToLowerInvariant();
		switch (text)
		{
		case "quit":
			CM_Fellowship.Event_Quit(0);
			return true;
		case "disband":
			CM_Fellowship.Event_Quit(1);
			return true;
		default:
			if (!(text == "close"))
			{
				Match match = Regex.Match(rest, "^(?<v>recruit|dismiss|leader)(?<p>p)?(?: (?<n>.+))?$", RegexOptions.IgnoreCase);
				if (!match.Success)
				{
					return false;
				}
				string text2 = match.Groups["v"].Value.ToLowerInvariant();
				string text3 = match.Groups["n"].Value.Trim();
				WorldObject worldObject = FindPerson(text3, match.Groups["p"].Success && match.Groups["p"].Value.Length > 0, ObjectClass.Player);
				if (worldObject == null)
				{
					Util.WriteToChat("fellow " + text2 + ": no player " + ((text3.Length > 0) ? text3 : "nearby"));
					return true;
				}
				if (text2 == "recruit")
				{
					CM_Fellowship.Event_Recruit((uint)worldObject.Id);
				}
				else if (text2 == "dismiss")
				{
					CM_Fellowship.Event_Dismiss((uint)worldObject.Id);
				}
				else
				{
					CM_Fellowship.Event_AssignNewLeader((uint)worldObject.Id);
				}
				return true;
			}
			goto case "open";
		case "open":
			CM_Fellowship.Event_ChangeFellowOpeness((text == "open") ? 1 : 0);
			return true;
		}
	}
#else

	private static bool Fellow(string rest)
	{
		string text = rest.ToLowerInvariant();
		switch (text)
		{
		case "quit":
			CM_Fellowship.Event_Quit(0);
			return true;
		case "disband":
			CM_Fellowship.Event_Quit(1);
			return true;
		case "open":
		case "close":
			CM_Fellowship.Event_ChangeFellowOpeness((text == "open") ? 1 : 0);
			return true;
		default:
		{
			Match match = Regex.Match(rest, "^(?<v>recruit|dismiss|leader)(?<p>p)?(?: (?<n>.+))?$", RegexOptions.IgnoreCase);
			if (!match.Success)
			{
				return false;
			}
			string text2 = match.Groups["v"].Value.ToLowerInvariant();
			string text3 = match.Groups["n"].Value.Trim();
			WorldObject val = FindPerson(text3, match.Groups["p"].Success && match.Groups["p"].Value.Length > 0, (ObjectClass)24);
			if (val == null)
			{
				Util.WriteToChat("fellow " + text2 + ": no player " + ((text3.Length <= 0) ? "nearby" : text3));
				return true;
			}
			if (text2 == "recruit")
			{
				CM_Fellowship.Event_Recruit((uint)val.Id);
			}
			else if (text2 == "dismiss")
			{
				CM_Fellowship.Event_Dismiss((uint)val.Id);
			}
			else
			{
				CM_Fellowship.Event_AssignNewLeader((uint)val.Id);
			}
			return true;
		}
		}
	}
#endif

	[DllImport("user32.dll")]
	private static extern bool SystemParametersInfo(int action, int param, ref WRECT r, int winIni);

	[DllImport("user32.dll")]
	private static extern bool AdjustWindowRectEx(ref WRECT r, int style, bool menu, int exStyle);
#if !RETAIL

	[DllImport("user32.dll")]
	private static extern int GetWindowLong(nint h, int idx);
#else

	[DllImport("user32.dll")]
	private static extern int GetWindowLong(IntPtr h, int idx);
#endif
#if !RETAIL

	[DllImport("user32.dll")]
	private static extern bool SetWindowPos(nint h, nint after, int x, int y, int w, int hgt, int flags);
#else

	[DllImport("user32.dll")]
	private static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int w, int hgt, int flags);
#endif
#if !RETAIL

	private static bool Resolution(string rest)
	{
		string text = (rest ?? "").Trim();
		if (text.StartsWith("max", StringComparison.OrdinalIgnoreCase))
		{
			DisplayServer.WindowSetMode(DisplayServer.WindowMode.Maximized);
			Util.WriteToChat("Setting Resolution: maximized");
			return true;
		}
		Match match = Regex.Match(text, "^(\\d+)[x ](\\d+)$");
		if (!match.Success || !int.TryParse(match.Groups[1].Value, out var result) || !int.TryParse(match.Groups[2].Value, out var result2) || result < 100 || result2 < 100 || result > 10000 || result2 > 10000)
		{
			Util.WriteToChat("Requested resolution was not valid (" + rest + ")");
			return true;
		}
		Util.WriteToChat("Setting Resolution " + result + "x" + result2);
		DisplayServer.WindowSetMode(DisplayServer.WindowMode.Windowed);
		DisplayServer.WindowSetSize(new Vector2I(result, result2));
		return true;
	}
#else

	private unsafe static bool Resolution(string rest)
	{
		string text = rest.Trim();
		if (text.Equals("max", StringComparison.OrdinalIgnoreCase) || text.StartsWith("max ", StringComparison.OrdinalIgnoreCase))
		{
			return ResolutionMax(text.Substring(3));
		}
		Match match = Regex.Match(rest, "^(\\d+)[x ](\\d+)$");
		if (!match.Success || !ushort.TryParse(match.Groups[1].Value, out var result) || !ushort.TryParse(match.Groups[2].Value, out var result2) || result < 100 || result2 < 100 || result > 10000 || result2 > 10000)
		{
			Util.WriteToChat("Requested resolution was not valid (" + rest + ")");
			return true;
		}
		Util.WriteToChat("Setting Resolution " + result + "x" + result2);
		*(ushort*)8489828 = result2;
		*(ushort*)8489830 = result;
		return true;
	}
#endif
#if !RETAIL

	private static void CommenceJump(int cs)
	{
		_acgCommence = DateTime.Now;
	}
#endif
#if !RETAIL

	private static float JumpPower(int cs)
	{
		return (_acgCommence == DateTime.MinValue) ? 0f : ((float)Math.Min(1.0, (DateTime.Now - _acgCommence).TotalSeconds));
	}
#endif
#if !RETAIL

	private static bool Jump(string f, string rest)
	{
		if (_j != JState.Idle)
		{
			Util.WriteToChat("You are already jumping. try again later.");
			return true;
		}
		Match match = JumpRx.Match(rest);
		if (!match.Success)
		{
			Util.WriteToChat("Usage: /ub jump[swzxc] [heading] [holdtime]");
			return true;
		}
		int result = 0;
		if (match.Groups["ms"].Success && match.Groups["ms"].Value.Length > 0 && (!int.TryParse(match.Groups["ms"].Value, out result) || result < 0 || result > 1000))
		{
			Util.WriteToChat("holdtime should be a number between 0 and 1000");
			return true;
		}
		double result2 = CoreManager.Current.Actions.Heading;
		bool flag = false;
		if (match.Groups["h"].Success && match.Groups["h"].Value.Length > 0)
		{
			if (!double.TryParse(match.Groups["h"].Value, NumberStyles.Float, CultureInfo.InvariantCulture, out result2))
			{
				Util.WriteToChat("direction should be a number between 0 and 359");
				return true;
			}
			// (past a full turn - a meta's "/vt jump 700 ..." - round again, as VTank takes it: 700 is 340)
			result2 %= 360.0;
			if (result2 < 0.0)
			{
				result2 += 360.0;
			}
			flag = true;
		}
		_jHeading = (float)result2;
		_jPower = Math.Min(1f, (float)result / 1000f);
		_jShift = f.Contains("s");
		_jW = f.Contains("w");
		_jX = f.Contains("x");
		_jZ = f.Contains("z");
		_jC = f.Contains("c");
		_jAt = DateTime.Now;
		_jTries = 0;
		if (flag)
		{
			CoreManager.Current.Actions.FaceHeading(result2, true);
			_jTurnAsk = DateTime.Now;
			_j = JState.Turning;
		}
		else
		{
			StartCharge();
		}
		if (!_frameHooked)
		{
			CoreManager.Current.RenderFrame += OnFrame;
			_frameHooked = true;
		}
		return true;
	}
#else

	private static bool Jump(string f, string rest)
	{
		if (_j != JState.Idle)
		{
			Util.WriteToChat("You are already jumping. try again later.");
			return true;
		}
		Match match = JumpRx.Match(rest);
		if (!match.Success)
		{
			Util.WriteToChat("Usage: /ub jump[swzxc] [heading] [holdtime]");
			return true;
		}
		int result = 0;
		if (match.Groups["ms"].Success && match.Groups["ms"].Value.Length > 0 && (!int.TryParse(match.Groups["ms"].Value, out result) || result < 0 || result > 1000))
		{
			Util.WriteToChat("holdtime should be a number between 0 and 1000");
			return true;
		}
		double result2 = CoreManager.Current.Actions.Heading;
		bool flag = false;
		if (match.Groups["h"].Success && match.Groups["h"].Value.Length > 0)
		{
			if (!double.TryParse(match.Groups["h"].Value, NumberStyles.Float, CultureInfo.InvariantCulture, out result2) || result2 < 0.0 || result2 > 359.0)
			{
				Util.WriteToChat("direction should be a number between 0 and 359");
				return true;
			}
			flag = true;
		}
		_jHeading = (float)result2;
		_jPower = Math.Min(1f, (float)result / 1000f);
		_jShift = f.Contains("s");
		_jW = f.Contains("w");
		_jX = f.Contains("x");
		_jZ = f.Contains("z");
		_jC = f.Contains("c");
		_jAt = DateTime.Now;
		_jTries = 0;
		if (flag)
		{
			CoreManager.Current.Actions.FaceHeading(result2, true);
			_jTurnAsk = DateTime.Now;
			_j = JState.Turning;
		}
		else
		{
			StartCharge();
		}
		if (!_frameHooked)
		{
			CoreManager.Current.RenderFrame += OnFrame;
			_frameHooked = true;
		}
		return true;
	}
#endif

	private static void StartCharge()
	{
		_j = JState.Charging;
		_jCharge = DateTime.Now;
		_jChargeStart = DateTime.Now;
		int combatSystem = CombatSystem;
		_jStartP = 0f;
		_jRising = false;
		try
		{
			if (combatSystem != 0)
			{
				_jStartP = JumpPower(combatSystem);
			}
		}
		catch
		{
		}
		CommenceJump(combatSystem);
	}

	private static void JumpDone()
	{
		_j = JState.Idle;
		if (_frameHooked)
		{
			try
			{
				CoreManager.Current.RenderFrame -= OnFrame;
			}
			catch
			{
			}
			_frameHooked = false;
		}
	}
#if !RETAIL

	private static void OnFrame(object sender, EventArgs e)
	{
		try
		{
			if ((DateTime.Now - _jAt).TotalSeconds > 20.0)
			{
				Util.WriteToChat("Jump: gave up (took too long).");
				JumpDone();
				return;
			}
			if (_j == JState.Turning)
			{
				double num = Math.Abs(CoreManager.Current.Actions.Heading - (double)_jHeading) % 360.0;
				if (num > 180.0)
				{
					num = 360.0 - num;
				}
				if (num < 1.5)
				{
					StartCharge();
				}
				else if ((DateTime.Now - _jAt).TotalSeconds > 5.0)
				{
					Util.WriteToChat("Jump: turning failed.");
					JumpDone();
				}
				else if ((DateTime.Now - _jTurnAsk).TotalSeconds > 0.5)
				{
					_jTurnAsk = DateTime.Now;
					CoreManager.Current.Actions.FaceHeading(_jHeading, true);
				}
				return;
			}
			if (_j == JState.Checking)
			{
				double x;
				double y;
				double z;
				if (Airborne())
				{
					_jAir = true;
				}
				else if (_jAir)
				{
					JumpDone();
				}
				else if (MyPos(out x, out y, out z) && (z - _jZ0 > 0.15 || Math.Abs(x - _jX0) + Math.Abs(y - _jY0) > 0.3))
				{
					JumpDone();
				}
				else if (!((DateTime.Now - _jReleased).TotalSeconds < 1.5))
				{
					if (++_jTries >= 3)
					{
						Util.WriteToChat("Jump: failed to jump 3 times.");
						JumpDone();
					}
					else
					{
						StartCharge();
					}
				}
				return;
			}
			if (_j != JState.Charging)
			{
				JumpDone();
				return;
			}
			int combatSystem = CombatSystem;
			if (combatSystem == 0)
			{
				JumpDone();
				return;
			}
			float num2 = JumpPower(combatSystem);
			if (!_jRising)
			{
				if (!(num2 < _jStartP - 0.001f) && !(num2 < _jPower) && !((DateTime.Now - _jChargeStart).TotalSeconds > 0.25))
				{
					return;
				}
				_jRising = true;
			}
			if (num2 < _jPower)
			{
				if ((DateTime.Now - _jCharge).TotalSeconds > 1.25)
				{
					_jCharge = DateTime.Now;
					CommenceJump(combatSystem);
				}
			}
			else
			{
				MyPos(out _jX0, out _jY0, out _jZ0);
				Release();
				_jReleased = DateTime.Now;
				_jAir = false;
				_j = JState.Checking;
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			JumpDone();
		}
	}
#else

	private static void OnFrame(object sender, EventArgs e)
	{
		try
		{
			if ((DateTime.Now - _jAt).TotalSeconds > 20.0)
			{
				Util.WriteToChat("Jump: gave up (took too long).");
				JumpDone();
				return;
			}
			if (_j == JState.Turning)
			{
				double num = Math.Abs(CoreManager.Current.Actions.Heading - (double)_jHeading) % 360.0;
				if (num > 180.0)
				{
					num = 360.0 - num;
				}
				if (num < 1.5)
				{
					StartCharge();
				}
				else if ((DateTime.Now - _jAt).TotalSeconds > 5.0)
				{
					Util.WriteToChat("Jump: turning failed.");
					JumpDone();
				}
				else if ((DateTime.Now - _jTurnAsk).TotalSeconds > 0.5)
				{
					_jTurnAsk = DateTime.Now;
					CoreManager.Current.Actions.FaceHeading((double)_jHeading, true);
				}
				return;
			}
			if (_j == JState.Checking)
			{
				double x;
				double y;
				double z;
				if (Airborne())
				{
					_jAir = true;
				}
				else if (_jAir)
				{
					JumpDone();
				}
				else if (MyPos(out x, out y, out z) && (z - _jZ0 > 0.15 || Math.Abs(x - _jX0) + Math.Abs(y - _jY0) > 0.3))
				{
					JumpDone();
				}
				else if (!((DateTime.Now - _jReleased).TotalSeconds < 1.5))
				{
					if (++_jTries >= 3)
					{
						Util.WriteToChat("Jump: failed to jump 3 times.");
						JumpDone();
					}
					else
					{
						StartCharge();
					}
				}
				return;
			}
			if (_j != JState.Charging)
			{
				JumpDone();
				return;
			}
			int combatSystem = CombatSystem;
			if (combatSystem == 0)
			{
				JumpDone();
				return;
			}
			float num2 = JumpPower(combatSystem);
			if (!_jRising)
			{
				if (!(num2 < _jStartP - 0.001f) && !(num2 < _jPower) && !((DateTime.Now - _jChargeStart).TotalSeconds > 0.25))
				{
					return;
				}
				_jRising = true;
			}
			if (num2 < _jPower)
			{
				if ((DateTime.Now - _jCharge).TotalSeconds > 1.25)
				{
					_jCharge = DateTime.Now;
					CommenceJump(combatSystem);
				}
			}
			else
			{
				MyPos(out _jX0, out _jY0, out _jZ0);
				Release();
				_jReleased = DateTime.Now;
				_jAir = false;
				_j = JState.Checking;
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			JumpDone();
		}
	}
#endif
#if !RETAIL

	private static bool MyPos(out double x, out double y, out double z)
	{
		x = (y = (z = 0.0));
		ACGodot.Plugins.PluginHost host = Bridge.Host;
		if (host?.Player == null || !host.Player.Active)
		{
			return false;
		}
		(uint, double, double, double) tuple = Bridge.Place(host.Player.Position, host.Player.Cell);
		x = tuple.Item2;
		y = tuple.Item3;
		z = tuple.Item4;
		return true;
	}
#else

	private unsafe static bool MyPos(out double x, out double y, out double z)
	{
		x = (y = (z = 0.0));
		try
		{
			int physics = Physics;
			if (physics == 0)
			{
				return false;
			}
			CPhysicsObj* ptr = (CPhysicsObj*)physics;
			x = ptr->m_position.frame.m_fOrigin.x;
			y = ptr->m_position.frame.m_fOrigin.y;
			z = ptr->m_position.frame.m_fOrigin.z;
			return true;
		}
		catch
		{
			return false;
		}
	}
#endif
#if !RETAIL

	private static bool Airborne()
	{
		ACGodot.Plugins.PluginHost host = Bridge.Host;
		return host?.Player != null && host.Player.Airborne;
	}
#else

	private static bool Airborne()
	{
		try
		{
			int physics = Physics;
			return physics != 0 && (((CPhysicsObj*)physics)->transient_state & 1) == 0;
		}
		catch
		{
			return false;
		}
	}
#endif
#if !RETAIL

	private static void Release()
	{
		ACGodot.Plugins.PluginHost host = Bridge.Host;
		if (host?.Player != null)
		{
			int keys = (_jW ? 1 : 0) | (_jX ? 2 : 0) | (_jZ ? 16 : 0) | (_jC ? 32 : 0);
			host.Player.PluginJump(_jPower, keys, _jShift);
		}
	}
#else

	private unsafe static void Release()
	{
		int motionInterp = MotionInterp;
		if (motionInterp == 0)
		{
			DoJump(CombatSystem, 1);
			return;
		}
		double num = MaxSpeed(motionInterp) / 4.0;
		if (_jW || _jX)
		{
			if (_jW)
			{
				*(int*)(motionInterp + 76) = 1140850695;
				*(float*)(motionInterp + 80) = ((!_jShift) ? ((float)num) : 1f);
			}
			else
			{
				*(int*)(motionInterp + 76) = 1157627909;
				*(float*)(motionInterp + 80) = ((!_jShift) ? ((float)(-0.65 * num)) : (-1f));
			}
		}
		else
		{
			*(int*)(motionInterp + 76) = 1090519043;
		}
		if (_jZ || _jC)
		{
			*(int*)(motionInterp + 84) = 1694498831;
			double num2 = num * 1.248;
			if (_jShift)
			{
				num2 *= 0.5;
			}
			if (num2 > 3.0)
			{
				num2 = 3.0;
			}
			*(float*)(motionInterp + 88) = ((!_jC) ? ((float)(0.0 - num2)) : ((float)num2));
		}
		else
		{
			*(int*)(motionInterp + 84) = 0;
		}
		*(int*)(motionInterp + 92) = 0;
		SetHeading(Physics, _jHeading, 0);
		DoJump(CombatSystem, 1);
		if (_jZ || _jC)
		{
			*(int*)(motionInterp + 84) = 0;
		}
		if (_jW || _jX)
		{
			*(int*)(motionInterp + 76) = 1090519043;
		}
	}
#endif
#if !RETAIL

	public static void Tick()
	{
		try
		{
			UbBuyTick();
			GiveTick();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			_give.Clear();
			_giveTarget = 0;
		}
	}
#else

	public static void Tick()
	{
		try
		{
			GiveTick();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			_give.Clear();
			_giveTarget = 0;
		}
	}
#endif

	public static void Dispose()
	{
		JumpDone();
		_give.Clear();
		_giveTarget = 0;
	}
#if RETAIL

	private static readonly ThisVoid CommenceJump = (ThisVoid)Marshal.GetDelegateForFunctionPointer((IntPtr)5684432, typeof(ThisVoid));
#endif
#if RETAIL

	private static readonly ThisFloat JumpPower = (ThisFloat)Marshal.GetDelegateForFunctionPointer((IntPtr)5684624, typeof(ThisFloat));
#endif
#if RETAIL

	private static readonly ThisVoidInt DoJump = (ThisVoidInt)Marshal.GetDelegateForFunctionPointer((IntPtr)5684816, typeof(ThisVoidInt));
#endif
#if RETAIL

	private static readonly ThisDouble MaxSpeed = (ThisDouble)Marshal.GetDelegateForFunctionPointer((IntPtr)5408960, typeof(ThisDouble));
#endif
#if RETAIL

	private static readonly ThisHeading SetHeading = (ThisHeading)Marshal.GetDelegateForFunctionPointer((IntPtr)5327968, typeof(ThisHeading));
#endif
#if RETAIL

	private unsafe static int Physics => *(int*)8670568;
#endif
#if RETAIL

	private unsafe static int MotionInterp
	{
		get
		{
			int physics = Physics;
			if (physics == 0)
			{
				return 0;
			}
			int num = *(int*)(physics + 196);
			return (num != 0) ? (*(int*)num) : 0;
		}
	}
#endif
#if RETAIL

	private unsafe static bool ResolutionMax(string extra)
	{
		Settings currentSettings = PluginCore.CurrentSettings;
		int num = currentSettings?.ResMaxReserve ?? 0;
		if (int.TryParse((extra ?? "").Trim(), out var result) && result >= 0 && result < 600)
		{
			num = result;
			if (currentSettings != null)
			{
				currentSettings.ResMaxReserve = result;
				try
				{
					PluginCore.SaveAllNow();
				}
				catch
				{
				}
			}
		}
		WRECT r = default;
		if (!SystemParametersInfo(48, 0, ref r, 0))
		{
			Util.WriteToChat("resolution max: couldn't read the desktop size.");
			return true;
		}
		IntPtr hwnd = CoreManager.Current.Decal.Hwnd;
		int windowLong = GetWindowLong(hwnd, -16);
		int windowLong2 = GetWindowLong(hwnd, -20);
		WRECT r2 = default;
		AdjustWindowRectEx(ref r2, windowLong, menu: false, windowLong2);
		int num2 = r.R - r.L - (r2.R - r2.L);
		int num3 = r.B - r.T - (r2.B - r2.T) - num;
		if (num2 < 100 || num3 < 100)
		{
			Util.WriteToChat("resolution max: the desktop came back as " + (r.R - r.L) + "x" + (r.B - r.T) + " - not used.");
			return true;
		}
		Util.WriteToChat("Setting Resolution " + num2 + "x" + num3 + " (desktop " + (r.R - r.L) + "x" + (r.B - r.T) + " less the window frame" + ((num <= 0) ? "" : (" and " + num + " px for the taskbar / title bar")) + ")" + ((num != 0) ? "" : " - if it goes under your taskbar: /mt resolution max <pixels to leave off>, e.g. /mt resolution max 70"));
		*(ushort*)8489828 = (ushort)num3;
		*(ushort*)8489830 = (ushort)num2;
		SetWindowPos(hwnd, IntPtr.Zero, r.L, r.T, 0, 0, 21);
		return true;
	}
#endif
}
