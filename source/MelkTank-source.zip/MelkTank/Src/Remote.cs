using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
#if !RETAIL
using AcClient;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using MelkTank.Bounties;
using MelkTank.Loot;

namespace MelkTank;

public static class Remote
{
	private class ChatLine
	{
		public DateTime At;

		public string Kind;

		public string Text;

		public int Color;
	}

	private class Pending
	{
		public DateTime Added;

		public string Text;

		public bool Idle;
	}

	private class HeldLine
	{
		public string Text;

		public int Color;

		public ChatTextInterceptEventArgs E;

		public DateTime At;
	}

	private class InvLine
	{
		public long Sig;

		public int Pk;

		public string Json;

		public DateTime Until;
	}

	private struct RECT
	{
		public int Left;

		public int Top;

		public int Right;

		public int Bottom;
	}

	private class Json
	{
		private readonly StringBuilder _sb = new StringBuilder("{");

		private bool _first = true;

		private void Name(string n)
		{
			if (!_first)
			{
				_sb.Append(',');
			}
			_first = false;
			_sb.Append("\n  ").Append(Q(n)).Append(": ");
		}

		public void Str(string n, string v)
		{
			Name(n);
			_sb.Append(Q(v ?? ""));
		}

		public void Num(string n, long v)
		{
			Name(n);
			_sb.Append(v.ToString(CultureInfo.InvariantCulture));
		}

		public void Bool(string n, bool v)
		{
			Name(n);
			_sb.Append(v ? "true" : "false");
		}

		public void List(string n, List<string> v)
		{
			Name(n);
			_sb.Append('[');
			for (int i = 0; i < v.Count; i++)
			{
				if (i > 0)
				{
					_sb.Append(", ");
				}
				_sb.Append(Q(v[i]));
			}
			_sb.Append(']');
		}

		public override string ToString()
		{
			return _sb.ToString() + "\n}\n";
		}

		private static string Q(string s) => Util.JsonQuote(s);
	}

	public const string CoinName = "Enlightened Coin";

	private static System.Windows.Forms.Timer _timer;

	private static string _dir;

	private static DateTime _loginAtUtc = DateTime.MinValue;

	private static DateTime _clientStartUtc = DateTime.UtcNow;

	public static DateTime ClientStartUtc = DateTime.MinValue;

	private static DateTime _lastWriteUtc = DateTime.MinValue;

	private static DateTime _lastDeathUtc = DateTime.MinValue;

	private static int _deaths;

	private static bool _inWorld;

	private static bool _loginStarted;

	private static long _lumChar = -1L;

	private static long _lumCharMax = -1L;

	private static long _lumBank = -1L;

	private static long _coinsBank = -1L;

	private static int _slotCount;

	private static string _lastCommand = "";

	private static string _loginNote = "";

	private static string _handledStamp = "";

	private static int _loginStep;

	private static DateTime _nextStepUtc = DateTime.MinValue;

	private static int _loginTries;

	private static bool _quitRequested;

	private static DateTime _quitAtUtc = DateTime.MinValue;

	private static int _quitStep;

	private static string _activeStamp = "";

	private static readonly object _wLock = new object();

	private static readonly object _wIo = new object();

	private static readonly Dictionary<string, string> _wText = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

	private static readonly List<string> _wOrder = new List<string>();

	private static Thread _wThread;

	private static readonly AutoResetEvent _wSignal = new AutoResetEvent(initialState: false);

	private static volatile bool _wStop;

	private static bool _logoffRequested;

	private static bool _logoffAsked;

	private static bool _dropped;

	public static DateTime LogoffAskedAt = DateTime.MinValue;

	private static DateTime _lastServerMsgUtc = DateTime.MinValue;

	private static int _intervalCached = 45;

	private static DateTime _intervalReadUtc = DateTime.MinValue;

	private static DateTime _lastCmdScanUtc = DateTime.MinValue;

	private static bool _writeSoon;

	private static readonly List<ChatLine> _chat = new List<ChatLine>();

	private static bool _chatDirty;

	private static readonly List<Pending> _pendingChat = new List<Pending>();

	private const double BankGapS = 6.0;

	private static DateTime _lastBankAt = DateTime.MinValue;

	private const string DepositPauser = "phone deposit";

	private static DateTime _depStart = DateTime.MinValue;

	private static DateTime _depResumeAt = DateTime.MinValue;

	private static string _depText;

	private static DateTime _notBusySince = DateTime.MaxValue;

	private static DateTime _chatSentAt = DateTime.MinValue;

	private static readonly Regex CombatRx = new Regex("for [\\d,]+ points?\\b|\\b(evaded|evades|resist|resists|critical hit|sneak attack|you killed|you've banked|has killed|killing blow|obliterate|smite|slay|annihilate|eviscerate|decapitate|impale|cleave|run .+ through|flatten|electrify|incinerat|dessicat|liquif|shatter|torn to pieces|untimely end|lifeless pulp|next morningthaw|reduced to|last strength|catches your attack|your assault|your attack|corpse smolders|only friend now|is utterly destroyed|you split|periodic \\w+ damage|aetheria surges|weaves |void magic spreads|void enchantments prime|points of health due to|you reduce .+ to )|^You cast |^Your spell fizzle|^You have killed [\\d,]+ |^You fail to affect |\\bdelivers an? .+ to |\\[Overkill: [\\d,]+\\]|ancestors feel |^Your .+ spreads to | for [\\d,]+ \\w+ damage|\\b(drains|restores) [\\d,]+ points? of (your|its|his|her) ", RegexOptions.IgnoreCase);

	private static readonly Regex ChannelRx = new Regex("^\\[(General|Trade|LFG|Roleplay|Society|Olthoi|Allegiance|Fellowship|Fellow|Co-?Vassals|Patron|Vassals|Monarch|Global|Help|Celestial Hand|Eldrytch Web|Radiant Blood)\\]", RegexOptions.IgnoreCase);

	private static readonly Regex TellTagRx = new Regex("<Tell:[^>]*>(.*?)<\\\\Tell>");

	private static readonly List<HeldLine> _held = new List<HeldLine>();

	private static HashSet<string> _spellWords;

	private static string _lastSay;

	private static DateTime _lastSayAt = DateTime.MinValue;

	private static int _vitTier = -2;

	private static int _hpSeen;

	private static int _stSeen;

	private static int _mpSeen;

	private static readonly Dictionary<string, DateTime> _pluginSaid = new Dictionary<string, DateTime>();

	private static DateTime _chatWriteUtc = DateTime.MinValue;

	private static readonly List<ChatLine> _tells = new List<ChatLine>();

	private static string _tellsFor = "";

	private static int _tellSeq;

	private static string _tellLast = "";

	private static readonly Regex TellFromRx = new Regex("^(?:\\[[^\\]]*\\]\\s*)?(.+?) tells you, \"(.*)\"\\s*$");

	private static string _chatDoing = "";

	private static int _bagOpen = int.MinValue;

	private static int _bagStep;

	private static bool _bagClose;

	private static bool _invWindowOpen;

	private static DateTime _bagAt;

	private static DateTime _bagWaitUntil;

	private static string _invKeyInfo;

	private static readonly string[] InvKeyNames = new string[5] { "ToggleInventoryPanel", "ToggleBackpackPanel", "ToggleInventory", "InventoryPanel", "ToggleBackpack" };

	private static bool _tbarLogged;

	private const string UsePauser = "Phone: using an item";

	private static readonly List<int> _useQueue = new List<int>();

	private static int _useId;

	private static DateTime _useStartUtc;

	private static DateTime _useIdleSince = DateTime.MaxValue;

	private static DateTime _useDoneAt = DateTime.MaxValue;

	private static string _confirmText = "";

	private static int _confirmType;

	private static int _confirmContext;

	private static DateTime _confirmAt = DateTime.MinValue;

	private static DateTime _lastUseUtc = DateTime.MinValue;

	private static bool _confirmForUse;

	private static bool _confirmAnswered;

	private static DateTime _expectYesUntil = DateTime.MinValue;

	private static string _expectYesText = "";

	private static Delegate _confirmHandler;

	private static EventInfo _confirmEvent;

	private static System.Windows.Forms.Timer _yesTimer;

	private static readonly Regex Sure100Rx = new Regex("(?<![\\d.])100(\\.0+)?\\s*(%|percent)", RegexOptions.IgnoreCase);

	private static DateTime _invSoonUtc = DateTime.MaxValue;

	private static DateTime _invAgainUtc = DateTime.MaxValue;

	private static int _invPack;

	private static string _orgWritten;

	private static DateTime _orgAt = DateTime.MinValue;

	private static readonly string[] SlotNames = new string[31]
	{
		"Head", "Chest (under)", "Abdomen (under)", "Upper arms (under)", "Lower arms (under)", "Hands", "Upper legs (under)", "Lower legs (under)", "Feet", "Chest",
		"Abdomen", "Upper arms", "Lower arms", "Upper legs", "Lower legs", "Neck", "Left wrist", "Right wrist", "Left ring", "Right ring",
		"Weapon", "Shield", "Missile weapon", "Ammo", "Wand / staff / orb", "Two-handed", "Trinket", "Cloak", "Blue aetheria", "Yellow aetheria",
		"Red aetheria"
	};

	private static readonly HashSet<int> _bagAsked = new HashSet<int>();

	private static readonly Dictionary<int, InvLine> _invLines = new Dictionary<int, InvLine>();

	private static int _invFreshId;

	private static DateTime _invFreshUntil = DateTime.MinValue;

	private static DateTime _lumBankAt = DateTime.MinValue;

	private static DateTime _coinsBankAt = DateTime.MinValue;

	private static DateTime _xferAt = DateTime.MinValue;

	private static string _xferKind;

	private static string _xferTarget;

	/// <summary>What /b t can send (its letter, and the name /bank gives it) - the rest of the bank stays put.</summary>
	public static IReadOnlyDictionary<string, string> Transferable => BankKinds;

	/// <summary>Sends all of one kind (less the 1 the server keeps) to someone: /bank first, for how much there is.</summary>
	public static void TransferAll(string kind, string name)
	{
		kind = (kind ?? "").Trim().ToLowerInvariant();
		name = (name ?? "").Trim().Trim('"');
		if (!BankKinds.ContainsKey(kind) || name.Length == 0)
		{
			return;
		}
		_xferKind = kind;
		_xferTarget = name;
		_xferAt = DateTime.UtcNow;
		SendOrQueue("/bank", idle: false);
		_lastCommand = DateTime.UtcNow.ToString("o") + " transfer: checking the bank first";
	}

	private static readonly Dictionary<string, string> BankKinds = new Dictionary<string, string>
	{
		{ "l", "Luminance" },
		{ "e", "Enlightened Coins" },
		{ "we", "Weakly Enlightened Coins" },
		{ "p", "Pyreals" },
		{ "k", "Legendary Keys" },
		{ "mk", "Mythical Keys" }
	};

	private static readonly Dictionary<string, long> _bankHave = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase);

	private static readonly Dictionary<string, DateTime> _bankAt = new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);

	private static DateTime _rewriteAt = DateTime.MaxValue;

	private const int LiveSeconds = 2;

	private static DateTime _liveReadUtc = DateTime.MinValue;

	private static DateTime _sessionWriteUtc = DateTime.MinValue;

	private static long _liveUntil;

	private static bool _liveSession;

	private static bool _liveChat;

	private static bool _relaunch;

	private const uint WM_CLOSE = 16u;

	private const uint WM_KEYDOWN = 256u;

	private const uint WM_KEYUP = 257u;

	internal static DateTime LoginAtUtc
	{
		get
		{
			return _loginAtUtc;
		}
		set
		{
			_loginAtUtc = value;
		}
	}

	public static double ServerQuietSecs => (_lastServerMsgUtc == DateTime.MinValue) ? (-1.0) : (DateTime.UtcNow - _lastServerMsgUtc).TotalSeconds;

	public static string Dir
	{
		get
		{
			if (_dir == null)
			{
				try
				{
					string directoryName = Path.GetDirectoryName(Path.GetDirectoryName(Util.BasePath));
					_dir = Path.Combine(directoryName, "MelkTankRemote");
				}
				catch
				{
					_dir = Path.Combine(Util.BasePath, "Remote");
				}
				try
				{
					Directory.CreateDirectory(_dir);
				}
				catch
				{
				}
			}
			return _dir;
		}
	}

	private static string Account
	{
		get
		{
			try
			{
				return CoreManager.Current.CharacterFilter.AccountName ?? "";
			}
			catch
			{
				return "";
			}
		}
	}

	public static int IntervalSeconds
	{
		get
		{
			if ((DateTime.UtcNow - _intervalReadUtc).TotalSeconds < 5.0)
			{
				return _intervalCached;
			}
			_intervalReadUtc = DateTime.UtcNow;
			return _intervalCached = ReadIntervalSeconds();
		}
	}

	private static HashSet<string> SpellWords
	{
		get
		{
			if (_spellWords != null)
			{
				return _spellWords;
			}
			_spellWords = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "Jevak Ves", "Jevak Bor", "Zojak Bor", "Slavu Bor" };
			try
			{
				string path = Util.FullPath("MelkTank_SpellWords.txt");
				if (File.Exists(path))
				{
					string[] array = File.ReadAllLines(path);
					foreach (string text in array)
					{
						if (text.Trim().Length > 0)
						{
							_spellWords.Add(text.Trim());
						}
					}
				}
			}
			catch
			{
			}
			return _spellWords;
		}
	}

	public static bool ConfirmPending => _confirmForUse && (DateTime.UtcNow - _confirmAt).TotalSeconds < 25.0;

	public static DateTime LastConfirmUtc => _confirmAt;

	public static string LastConfirmText => _confirmText;

	public static DateTime HookAnsweredUtc { get; private set; }

	public static bool LauncherManaged
	{
		get
		{
			try
			{
				string account = Account;
				return account.Length > 0 && File.Exists(Path.Combine(Dir, "launch_" + Key(account) + ".txt"));
			}
			catch
			{
				return false;
			}
		}
	}

	public static void Startup()
	{
		try
		{
			_clientStartUtc = ((ClientStartUtc != DateTime.MinValue) ? ClientStartUtc : DateTime.UtcNow);
			CoreManager.Current.EchoFilter.ServerDispatch += OnServer;
			CoreManager.Current.ChatBoxMessage += OnChat;
			CoreManager.Current.CharacterFilter.Login += OnLoginStarted;
			HookConfirm(on: true);
			_timer = new System.Windows.Forms.Timer();
			_timer.Interval = 1000;
			_timer.Tick += OnTick;
			_timer.Start();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void WriteLater(string path, string text)
	{
		if (_wStop)
		{
			Util.WriteShared(path, text);
			return;
		}
		lock (_wLock)
		{
			if (!_wText.ContainsKey(path))
			{
				_wOrder.Add(path);
			}
			_wText[path] = text;
			if (_wThread == null || !_wThread.IsAlive)
			{
				_wThread = new Thread(WriterLoop)
				{
					IsBackground = true,
					Name = "MelkTank phone files"
				};
				_wThread.Start();
			}
		}
		_wSignal.Set();
	}

	private static void WriterLoop()
	{
		while (!_wStop)
		{
			try
			{
				_wSignal.WaitOne(1000);
				FlushWrites();
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
		}
	}

	private static void FlushWrites()
	{
		lock (_wIo)
		{
			while (true)
			{
				string text;
				string text2;
				lock (_wLock)
				{
					if (_wOrder.Count == 0)
					{
						break;
					}
					text = _wOrder[0];
					_wOrder.RemoveAt(0);
					text2 = _wText[text];
					_wText.Remove(text);
				}
				try
				{
					Util.WriteShared(text, text2);
				}
				catch (Exception ex)
				{
					Util.LogError(ex);
				}
			}
		}
	}

	private static void StopWriter()
	{
		try
		{
			_wStop = true;
			_wSignal.Set();
			FlushWrites();
			Thread wThread = _wThread;
			if (wThread != null && wThread.IsAlive)
			{
				wThread.Join(2000);
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void Shutdown()
	{
		try
		{
			ShutdownInner();
		}
		finally
		{
			StopWriter();
		}
	}

	private static void ShutdownInner()
	{
		try
		{
			if (_timer != null)
			{
				_timer.Stop();
				_timer.Dispose();
				_timer = null;
			}
			if (_yesTimer != null)
			{
				_yesTimer.Stop();
				_yesTimer.Dispose();
				_yesTimer = null;
			}
			CoreManager.Current.EchoFilter.ServerDispatch -= OnServer;
			CoreManager.Current.ChatBoxMessage -= OnChat;
			CoreManager.Current.CharacterFilter.Login -= OnLoginStarted;
			HookConfirm(on: false);
			if (!PluginCore.HotReloading)
			{
				if (!_inWorld && !_dropped)
				{
					_logoffRequested = true;
				}
				_inWorld = false;
				WriteStatus(running: false);
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void LoggedIn()
	{
		_logoffRequested = false;
		_logoffAsked = false;
		_dropped = false;
		_inWorld = true;
		_loginStarted = true;
		_loginAtUtc = DateTime.UtcNow;
		_loginNote = "";
		try
		{
			RememberCharacter(Account, CoreManager.Current.CharacterFilter.Name);
		}
		catch
		{
		}
		try
		{
			if (ReadKeyValues(Path.Combine(Dir, "launch_" + Key(Account) + ".txt")).TryGetValue("time", out var value))
			{
				_handledStamp = value;
			}
		}
		catch
		{
		}
		WriteStatusSoon();
	}

	public static void LogoffAsked()
	{
		LogoffAskedAt = DateTime.Now;
		double num = ((_lastServerMsgUtc == DateTime.MinValue) ? 0.0 : (DateTime.UtcNow - _lastServerMsgUtc).TotalSeconds);
		if (num >= 20.0 && !_quitRequested)
		{
			try
			{
				Notes.Add("lost the server (nothing from it for " + num.ToString("0") + " s) - the client logged itself off; told the PC service it's a disconnect", "auto", quiet: true);
				return;
			}
			catch
			{
				return;
			}
		}
		_logoffAsked = true;
	}

	public static void NoteServerMessage()
	{
		_lastServerMsgUtc = DateTime.UtcNow;
	}

	public static void LoggedOut()
	{
		_logoffRequested = _logoffAsked || _quitRequested;
		_dropped = !_logoffRequested;
		_inWorld = false;
		_loginStarted = false;
		_loginAtUtc = DateTime.MinValue;
		WriteStatus(running: true);
	}

	public static void NoteDeath()
	{
		_deaths++;
		_lastDeathUtc = DateTime.UtcNow;
		WriteStatus(running: true);
	}

	private static void OnLoginStarted(object sender, LoginEventArgs e)
	{
		_loginStarted = true;
	}

	/// <summary>
	/// A phone command handed over by ACGodot (which carries out only its own few): written as the command file the phone
	/// service writes for the retail client, so it's done the same way, on the next look for commands.
	/// </summary>
	public static bool QueueCommand(string action, IReadOnlyDictionary<string, string> values)
	{
		try
		{
			if (string.IsNullOrWhiteSpace(action)) return false;
			var lines = new List<string> { "action=" + action.Trim() };
			foreach (string k in new[] { "feature", "value", "name" })
			{
				if (values != null && values.TryGetValue(k, out var v) && !string.IsNullOrEmpty(v))
					lines.Add(k + "=" + v.Replace("\r", " ").Replace("\n", " "));
			}
			// (the service sends some under their own names: a transfer's kind and target)
			if (values != null && action.Equals("banktransfer", StringComparison.OrdinalIgnoreCase))
			{
				if (values.TryGetValue("kind", out var kind) && kind.Length > 0) lines.Add("value=" + kind);
				if (values.TryGetValue("target", out var to) && to.Length > 0) lines.Add("name=" + to);
			}
			string stamp = ((long)(DateTime.UtcNow - new DateTime(1970, 1, 1)).TotalMilliseconds).ToString("D15");
			Directory.CreateDirectory(Dir);
			string path = Path.Combine(Dir, "cmd_" + Key(Account) + "_" + stamp + ".txt");
			File.WriteAllText(path + ".tmp", string.Join("\n", lines) + "\n");
			File.Move(path + ".tmp", path);
			_lastCmdScanUtc = DateTime.MinValue;   // (looked at on the next tick)
			return true;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			return false;
		}
	}

	public static string Key(string account)
	{
		StringBuilder stringBuilder = new StringBuilder();
		string text = (account ?? "").Trim().ToLowerInvariant();
		foreach (char c in text)
		{
			stringBuilder.Append((char.IsLetterOrDigit(c) || c == '-' || c == '_') ? c : '_');
		}
		return (stringBuilder.Length > 0) ? stringBuilder.ToString() : "unknown";
	}

	private static Dictionary<string, string> ReadKeyValues(string path)
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
		if (!File.Exists(path))
		{
			return dictionary;
		}
		string[] array = Util.Locked(path, () => File.ReadAllLines(path));
		string[] array2 = array;
		foreach (string text in array2)
		{
			string text2 = text.Trim();
			int num2 = text2.IndexOf('=');
			if (text2.Length != 0 && !text2.StartsWith("#") && num2 > 0)
			{
				dictionary[text2.Substring(0, num2).Trim()] = text2.Substring(num2 + 1).Trim();
			}
		}
		return dictionary;
	}

	private static int ReadIntervalSeconds()
	{
		try
		{
			if (ReadKeyValues(Path.Combine(Dir, "remote_settings.txt")).TryGetValue("interval", out var value) && int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var result))
			{
				return Math.Max(15, Math.Min(600, result));
			}
		}
		catch
		{
		}
		return 45;
	}

	private static void OnTick(object sender, EventArgs e)
	{
		long t = Perf.Begin();
		try
		{
			OnTickInner(sender, e);
		}
		finally
		{
			Perf.Lap("Phone status (1 s tick)", t);
		}
	}

	private static void OnTickInner(object sender, EventArgs e)
	{
		try
		{
			string account = Account;
			if (account.Length != 0)
			{
				long t = Perf.Begin();
				if (_quitRequested)
				{
					QuitTick();
				}
				HeldChatTick();
				OtherPluginsTick();
				PausedDepositTick();
				if (_inWorld)
				{
					PendingChatTick();
					TransferTick();
					InventoryTick(account);
					UseTick(account);
					BagTick();
					OrganizeTick(account);
				}
				else if (!_inWorld && !_loginStarted)
				{
					AutoLoginTick(account);
				}
				t = Perf.Lap("  phone: chat / inventory / organize ticks", t);
				if ((DateTime.UtcNow - _lastCmdScanUtc).TotalSeconds >= 2.0)
				{
					_lastCmdScanUtc = DateTime.UtcNow;
					ProcessCommands(account);
				}
				t = Perf.Lap("  phone: commands", t);
				Live(out var live, out var _);
				if (_writeSoon || (DateTime.UtcNow - _lastWriteUtc).TotalSeconds >= (double)(live ? 2 : IntervalSeconds))
				{
					_writeSoon = false;
					WriteStatus(running: true);
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void WriteStatusSoon()
	{
		_writeSoon = true;
	}

	private static bool IsBank(string text)
	{
		string text2 = Regex.Replace((text ?? "").Trim().ToLowerInvariant(), "\\s+", " ");
		return text2 == "/b d" || text2.StartsWith("/b d ") || text2.StartsWith("/b t ") || text2.StartsWith("/b w ") || text2.StartsWith("/bank d") || text2.StartsWith("/bank t");
	}

	private static void SendOrQueue(string text, bool idle)
	{
		if (!idle && _pendingChat.Count == 0 && (!IsBank(text) || (DateTime.UtcNow - _lastBankAt).TotalSeconds >= 6.0))
		{
			SendNow(text);
			return;
		}
		_pendingChat.Add(new Pending
		{
			Added = DateTime.UtcNow,
			Text = text,
			Idle = idle
		});
		_lastCommand = DateTime.UtcNow.ToString("o") + (idle ? " waiting until not busy: " : " queued: ") + text;
		_chatDirty = true;
	}

	private static void StartPausedDeposit(string text)
	{
		if (!(_depStart != DateTime.MinValue))
		{
			_depText = text;
			_depStart = DateTime.UtcNow;
			_depResumeAt = DateTime.MinValue;
			PluginCore.Pause("phone deposit");
			_lastCommand = DateTime.UtcNow.ToString("o") + " paused 2 s to deposit";
			_chatDirty = true;
		}
	}

	private static void PausedDepositTick()
	{
		if (_depStart == DateTime.MinValue)
		{
			return;
		}
		DateTime utcNow = DateTime.UtcNow;
		if (_depResumeAt == DateTime.MinValue)
		{
			bool flag = (utcNow - _lastBankAt).TotalSeconds >= 6.0;
			if (((utcNow - _depStart).TotalSeconds >= 2.0) & flag)
			{
				SendNow(_depText);
				_depResumeAt = utcNow.AddSeconds(1.5);
			}
			else if ((utcNow - _depStart).TotalSeconds > 15.0)
			{
				_depResumeAt = utcNow;
			}
		}
		else if (!(utcNow < _depResumeAt))
		{
			PluginCore.Resume("phone deposit");
			_depStart = DateTime.MinValue;
			_depResumeAt = DateTime.MinValue;
		}
	}

	private static void SendNow(string text)
	{
		if (IsBank(text))
		{
			_lastBankAt = DateTime.UtcNow;
		}
		string text2 = text.Trim().ToLowerInvariant();
		if (text2 == "/bank" || text2.StartsWith("/aug"))
		{
			_rewriteAt = DateTime.UtcNow.AddSeconds(2.5);
		}
		Session.QuietNext(text);
		_chatSentAt = DateTime.UtcNow;
		Util.Command(text);
		_lastCommand = DateTime.UtcNow.ToString("o") + " sent: " + text;
		_chatDirty = true;
	}

	private static string ChatKind(string t)
	{
		if (t.IndexOf(" tells you, ", StringComparison.OrdinalIgnoreCase) >= 0 || t.StartsWith("You tell ", StringComparison.OrdinalIgnoreCase))
		{
			return "tell";
		}
		if (ChannelRx.IsMatch(t))
		{
			return "channel";
		}
		if (t.StartsWith("Your pet ", StringComparison.OrdinalIgnoreCase))
		{
			return "pet";
		}
		if (IsSpellWords(t))
		{
			return "combat";
		}
		if (t.StartsWith("[Pet]", StringComparison.OrdinalIgnoreCase) || t.IndexOf("PetSummoner", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			return "pet";
		}
		if (t.StartsWith("Pets: ", StringComparison.Ordinal) || t.StartsWith("[MelkTank] Pets: ", StringComparison.Ordinal))
		{
			return "pet";
		}
		if (CombatRx.IsMatch(t))
		{
			return "combat";
		}
		return "other";
	}

	private static void HoldChat(string t, int color, ChatTextInterceptEventArgs e)
	{
		if (string.IsNullOrEmpty(t))
		{
			return;
		}
		lock (_held)
		{
			_held.Add(new HeldLine
			{
				Text = t,
				Color = color,
				E = e,
				At = DateTime.UtcNow
			});
		}
	}

	private static void HeldChatTick()
	{
		List<HeldLine> list;
		lock (_held)
		{
			if (_held.Count == 0)
			{
				return;
			}
			list = _held.FindAll((HeldLine h) => (DateTime.UtcNow - h.At).TotalMilliseconds >= 100.0);
			_held.RemoveAll((HeldLine h) => (DateTime.UtcNow - h.At).TotalMilliseconds >= 100.0);
		}
		foreach (HeldLine item in list)
		{
			bool flag = false;
			try
			{
				flag = item.E != null && item.E.Eat;
			}
			catch
			{
			}
			if (!flag)
			{
				NoteChat(item.Text, item.Color);
			}
		}
	}

	private static string SaidWords(string t)
	{
		if (!t.StartsWith("You say, \"", StringComparison.Ordinal) || !t.EndsWith("\""))
		{
			return null;
		}
		return t.Substring(10, t.Length - 11);
	}

	private static bool IsSpellWords(string t)
	{
		string text = SaidWords(t);
		return text != null && SpellWords.Contains(text);
	}

	private static void LearnSpellWords(string t)
	{
		string text = SaidWords(t);
		if (text != null)
		{
			_lastSay = text;
			_lastSayAt = DateTime.UtcNow;
		}
		else
		{
			if (_lastSay == null || !t.StartsWith("You cast ", StringComparison.OrdinalIgnoreCase) || (DateTime.UtcNow - _lastSayAt).TotalSeconds > 6.0)
			{
				return;
			}
			string lastSay = _lastSay;
			_lastSay = null;
			if (SpellWords.Contains(lastSay))
			{
				return;
			}
			SpellWords.Add(lastSay);
			try
			{
				File.AppendAllText(Util.FullPath("MelkTank_SpellWords.txt"), lastSay + Environment.NewLine);
			}
			catch
			{
			}
			string text2 = "You say, \"" + lastSay + "\"";
			foreach (ChatLine item in _chat)
			{
				if (item.Kind != "combat" && item.Text == text2)
				{
					item.Kind = "combat";
				}
			}
		}
	}

	private static void OtherPluginsTick()
	{
		Queue queue = null;
		try
		{
			queue = AppDomain.CurrentDomain.GetData("Melk.PluginChat") as Queue;
		}
		catch
		{
		}
		if (queue == null)
		{
			return;
		}
		List<object[]> list = new List<object[]>();
		lock (queue.SyncRoot)
		{
			while (queue.Count > 0)
			{
				if (queue.Dequeue() is object[] array && array.Length >= 2)
				{
					list.Add(array);
				}
			}
		}
		foreach (object[] item in list)
		{
			string text = item[0] as string;
			int color = 5;
			try
			{
				color = Convert.ToInt32(item[1]);
			}
			catch
			{
			}
			if (!string.IsNullOrEmpty(text))
			{
				AddPluginLine(text.Trim(), color, "plugin");
			}
		}
	}

	public static void PluginLine(string t, int color)
	{
		if (!string.IsNullOrEmpty(t))
		{
			AddPluginLine(t, color, t.StartsWith("[MelkTank] Pets: ", StringComparison.Ordinal) ? "pet" : "melktank");
		}
	}

	private static void AddPluginLine(string t, int color, string kind)
	{
		DateTime utcNow = DateTime.UtcNow;
		if (!_pluginSaid.TryGetValue(t, out var value) || !((utcNow - value).TotalSeconds < 60.0))
		{
			if (_pluginSaid.Count > 300)
			{
				_pluginSaid.Clear();
			}
			_pluginSaid[t] = utcNow;
			_chat.Add(new ChatLine
			{
				At = utcNow,
				Kind = kind,
				Text = t,
				Color = color
			});
			TrimChat();
			_chatDirty = true;
		}
	}

	private static void TrimChat()
	{
		while (_chat.Count > 200)
		{
			int mine = 0;
			Predicate<ChatLine> ours = (ChatLine l) => l.Kind == "melktank" || l.Kind == "plugin";
			foreach (ChatLine item in _chat)
			{
				if (ours(item))
				{
					mine++;
				}
			}
			int num = _chat.FindIndex((ChatLine l) => (mine > 40) ? ours(l) : (!ours(l)));
			_chat.RemoveAt((num >= 0) ? num : 0);
		}
	}

	private static void NoteChat(string t, int color)
	{
		if (string.IsNullOrEmpty(t))
		{
			return;
		}
		try
		{
			LearnSpellWords(t);
		}
		catch
		{
		}
		try
		{
			if (ChatFilter.Hides(t))
			{
				return;
			}
		}
		catch
		{
		}
		if (t.IndexOf("<Tell:", StringComparison.Ordinal) >= 0)
		{
			t = TellTagRx.Replace(t, "$1");
		}
		string text = ChatKind(t);
		if (text == "tell")
		{
			try
			{
				NoteTell(t, color);
			}
			catch
			{
			}
		}
		_chat.Add(new ChatLine
		{
			At = DateTime.UtcNow,
			Kind = text,
			Text = t,
			Color = color
		});
		TrimChat();
		_chatDirty = true;
	}

	private static string TellFile(string ch)
	{
		string text = ch;
		char[] invalidFileNameChars = Path.GetInvalidFileNameChars();
		foreach (char c in invalidFileNameChars)
		{
			text = text.Replace(c.ToString(), "");
		}
		return Util.FullPath(Path.Combine("Logs", Path.Combine(text, "MelkTank_Tells_" + text + ".txt")));
	}

	private static void TellsFor(string ch)
	{
		if (ch == _tellsFor)
		{
			return;
		}
		_tellsFor = ch;
		_tells.Clear();
		_tellSeq = 0;
		_tellLast = "";
		Settings currentSettings = PluginCore.CurrentSettings;
		if (currentSettings == null || !currentSettings.TellKeep || ch.Length == 0)
		{
			return;
		}
		try
		{
			string path = TellFile(ch);
			if (!File.Exists(path))
			{
				return;
			}
			string[] array = File.ReadAllLines(path);
			for (int i = Math.Max(0, array.Length - 3000); i < array.Length; i++)
			{
				string[] array2 = array[i].Split(new char[1] { '\t' }, 2);
				if (array2.Length == 2 && DateTime.TryParse(array2[0], CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out var result))
				{
					_tells.Add(new ChatLine
					{
						At = result,
						Kind = "tell",
						Text = array2[1],
						Color = 0
					});
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void NoteTell(string t, int color)
	{
		Settings currentSettings = PluginCore.CurrentSettings;
		if (currentSettings == null || !currentSettings.TellLog)
		{
			return;
		}
		string text = "";
		try
		{
			text = Globals.Core.CharacterFilter.Name ?? "";
		}
		catch
		{
		}
		TellsFor(text);
		DateTime utcNow = DateTime.UtcNow;
		_tells.Add(new ChatLine
		{
			At = utcNow,
			Kind = "tell",
			Text = t,
			Color = color
		});
		if (_tells.Count > 3000)
		{
			_tells.RemoveRange(0, _tells.Count - 3000);
		}
		Match match = TellFromRx.Match(t);
		if (match.Success && !NpcTeller(match.Groups[1].Value))
		{
			_tellSeq++;
			_tellLast = match.Groups[1].Value + ": " + match.Groups[2].Value;
			WriteStatusSoon();
		}
		if (!currentSettings.TellKeep || text.Length <= 0)
		{
			return;
		}
		try
		{
			File.AppendAllText(TellFile(text), utcNow.ToString("o") + "\t" + t.Replace("\r", " ").Replace("\n", " ") + Environment.NewLine);
		}
		catch
		{
		}
	}

	// a tell from something that isn't a player (a vendor, a quest giver - they "tell you" too): logged with the rest,
	// but no phone notification. Players carry the game's clickable name markup; anything else near you that isn't a
	// player counts as an NPC
	private static bool NpcTeller(string who)
	{
		try
		{
			string name = Regex.Replace(who ?? "", "<[^>]*>", "").Trim();
			if (who != null && who.IndexOf("<Tell:", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				return false;
			}
			if (name.Length == 0)
			{
				return false;
			}
			foreach (WorldObject wo in Globals.Core.WorldFilter.GetLandscape())
			{
				if (string.Equals(wo.Name, name, StringComparison.OrdinalIgnoreCase))
				{
					return wo.ObjectClass != ObjectClass.Player;
				}
			}
		}
		catch
		{
		}
		return false;
	}

	private static void WriteChat(string acct)
	{
		string text = "";
		try
		{
			CombatEngine currentEngine = PluginCore.CurrentEngine;
			if (currentEngine != null)
			{
				text = currentEngine.Status ?? "";
			}
		}
		catch
		{
		}
		Live(out var live, out var _);
		if (!_chatDirty && (!live || !_liveChat || !(text != _chatDoing)))
		{
			return;
		}
		_chatDoing = text;
		if ((!live || !_liveChat) && (DateTime.UtcNow - _chatWriteUtc).TotalSeconds < (double)IntervalSeconds)
		{
			return;
		}
		_chatWriteUtc = DateTime.UtcNow;
		_chatDirty = false;
		try
		{
			StringBuilder stringBuilder = new StringBuilder("{\n  \"updated\": \"" + DateTime.UtcNow.ToString("o") + "\",\n  \"doing\": " + JsonQ(text) + ",\n  \"waiting\": [");
			for (int i = 0; i < _pendingChat.Count; i++)
			{
				stringBuilder.Append((i > 0) ? ", " : "").Append(JsonQ(_pendingChat[i].Text));
			}
			stringBuilder.Append("],\n  \"lines\": [");
			for (int j = 0; j < _chat.Count; j++)
			{
				ChatLine chatLine = _chat[j];
				stringBuilder.Append((j > 0) ? ",\n    " : "\n    ").Append("{\"t\": \"").Append(chatLine.At.ToString("o"))
					.Append("\", \"k\": \"")
					.Append(chatLine.Kind)
					.Append("\", \"c\": ")
					.Append(chatLine.Color)
					.Append(", \"x\": ")
					.Append(JsonQ(chatLine.Text))
					.Append('}');
			}
			stringBuilder.Append("\n  ],\n  \"tells\": [");
			for (int k = 0; k < _tells.Count; k++)
			{
				ChatLine chatLine2 = _tells[k];
				stringBuilder.Append((k > 0) ? ",\n    " : "\n    ").Append("{\"t\": \"").Append(chatLine2.At.ToString("o"))
					.Append("\", \"k\": \"tell\", \"c\": ")
					.Append(chatLine2.Color)
					.Append(", \"x\": ")
					.Append(JsonQ(chatLine2.Text))
					.Append('}');
			}
			stringBuilder.Append("\n  ]\n}\n");
			WriteLater(Path.Combine(Dir, "chat_" + Key(acct) + ".json"), stringBuilder.ToString());
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static string JsonQ(string s) => Util.JsonQuote(s);

	private static int InventoryKey()
	{
		StringBuilder stringBuilder = new StringBuilder();
		int num = 0;
		string[] invKeyNames = InvKeyNames;
		foreach (string text in invKeyNames)
		{
			int num2 = 0;
			try
			{
				num2 = CoreManager.Current.QueryKeyBoardMap(text);
			}
			catch
			{
			}
			stringBuilder.Append(text).Append('=').Append(num2.ToString("X"))
				.Append(' ');
			if (num == 0 && num2 > 0)
			{
				num = num2;
			}
		}
		if (_invKeyInfo == null)
		{
			_invKeyInfo = stringBuilder.ToString().Trim();
			Util.WriteToChat("Phone: inventory key lookup: " + _invKeyInfo);
		}
		return num;
	}

	[DllImport("user32.dll")]
	private static extern uint MapVirtualKey(uint code, uint mapType);

	private static void ClickPackIcon(int index)
	{
		Rectangle rectangle = CoreManager.Current.Actions.UIElementRegion(UIElementType.Panels);
		if (rectangle.Width <= 0)
		{
			Util.WriteToChat("Phone: couldn't find the inventory window.");
			return;
		}
		double num = rectangle.Width;
		int x = rectangle.Left + (int)(num * 0.867);
		int y = rectangle.Top + (int)(num * (0.243 + 0.1206 * (double)(index + 1)));
		Util.WriteToChat("Phone: inventory window at " + rectangle.Left + "," + rectangle.Top + " " + rectangle.Width + "x" + rectangle.Height + " - clicking pack " + (index + 1) + " at " + x + "," + y + ".");
		Click(x, y);
	}

	private static bool ShowInventory(bool show)
	{
		try
		{
			CM_UI.SendNotice_SetDisplayInventory(show ? 1 : 0);
			return true;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			return ClickBackpack();
		}
	}

	private static bool ClickBackpack()
	{
		try
		{
			Rectangle rectangle = CoreManager.Current.Actions.UIElementRegion(UIElementType.TBar);
			if (rectangle.Width <= 0 || rectangle.Height <= 0)
			{
				Util.WriteToChat("Phone: couldn't find the game's toolbar.");
				return false;
			}
			int x = rectangle.Right - (int)((double)rectangle.Height * 0.26);
			int y = rectangle.Top + (int)((double)rectangle.Height * 0.24);
			if (!_tbarLogged)
			{
				_tbarLogged = true;
				Util.WriteToChat("Phone: toolbar at " + rectangle.Left + "," + rectangle.Top + " " + rectangle.Width + "x" + rectangle.Height + " - clicking the backpack at " + x + "," + y + ".");
			}
			Click(x, y);
			return true;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			return false;
		}
	}

	private static void PressKey(int code)
	{
		nint hwnd;
		try
		{
			hwnd = CoreManager.Current.Decal.Hwnd;
		}
		catch
		{
			return;
		}
		uint num = (uint)(code & 0xFF);
		bool flag = (code & 0x100) != 0;
		uint num2 = MapVirtualKey(num, 1u);
		if (num2 == 0)
		{
			num2 = num;
		}
		int num3 = (int)(1 | (num << 16)) | (flag ? 16777216 : 0);
		PostMessage(hwnd, 256u, (nint)num2, num3);
		PostMessage(hwnd, 257u, (nint)num2, num3 | -1073741824);
	}

	private static void BagTick()
	{
		if (!_bagClose && _bagOpen == int.MinValue)
		{
			return;
		}
		if ((DateTime.UtcNow - _bagAt).TotalSeconds > 15.0)
		{
			_bagClose = false;
			_bagOpen = int.MinValue;
			_bagStep = 0;
			return;
		}
		int num = 0;
		try
		{
			num = CoreManager.Current.Actions.BusyState;
		}
		catch
		{
		}
		if (num != 0)
		{
			return;
		}
		if (_bagClose)
		{
			if (!_invWindowOpen)
			{
				Util.WriteToChat("Phone: the inventory window should already be closed (use Toggle if it isn't).");
			}
			else if (ShowInventory(show: false))
			{
				_invWindowOpen = false;
				Util.WriteToChat("Phone: closing the inventory window.");
			}
			_bagClose = false;
			_bagStep = 0;
			return;
		}
		if (_bagStep == 0)
		{
			_bagStep = 1;
			if (!_invWindowOpen)
			{
				ShowInventory(show: true);
				_invWindowOpen = true;
				_bagWaitUntil = DateTime.UtcNow.AddSeconds(0.8);
				return;
			}
		}
		if (DateTime.UtcNow < _bagWaitUntil)
		{
			return;
		}
		int pack = _bagOpen;
		_bagOpen = int.MinValue;
		_bagStep = 0;
		try
		{
			int index = -1;
			if (pack != 0)
			{
				List<WorldObject> list = new List<WorldObject>();
				int id = CoreManager.Current.CharacterFilter.Id;
				foreach (WorldObject item in InvCache.All())
				{
					if (item.Container == id && item.ObjectClass == ObjectClass.Container && item.Values(LongValueKey.EquippedSlots, 0) == 0)
					{
						list.Add(item);
					}
				}
				list.Sort((WorldObject a, WorldObject b) => a.Values(LongValueKey.Slot, 0).CompareTo(b.Values(LongValueKey.Slot, 0)));
				index = list.FindIndex((WorldObject x) => x.Id == pack);
			}
			bool flag = false;
			try
			{
				CM_UI.SendNotice_OpenContainedContainer((uint)((pack != 0) ? pack : CoreManager.Current.CharacterFilter.Id));
				flag = true;
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
			if (!flag)
			{
				ClickPackIcon(index);
			}
			WorldObject worldObject = ((pack != 0) ? CoreManager.Current.WorldFilter[pack] : null);
			Util.WriteToChat("Phone: showing " + ((worldObject != null) ? worldObject.Name : "the main pack") + " in the inventory window.");
		}
		catch (Exception ex2)
		{
			Util.LogError(ex2);
		}
	}

	public static bool ClickConfirmYes()
	{
		if ((DateTime.UtcNow - HookAnsweredUtc).TotalSeconds < 5.0)
		{
			return true;
		}
		AnswerConfirm(yes: true);
		try
		{
			nint hwnd = CoreManager.Current.Decal.Hwnd;
			if (!GetClientRect(hwnd, out var rect))
			{
				return false;
			}
			int num = rect.Right - rect.Left;
			int num2 = rect.Bottom - rect.Top;
			Click(num / 2 - 84, num2 / 2 + 24);
			return true;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			return false;
		}
	}

	public static void ExpectYes(double seconds, string textPart)
	{
		ExpectYes(seconds, textPart, 0);
	}

	/// <summary>Yes to the next confirmation in the next few seconds - only one of this type (0: any; 5: crafting).</summary>
	public static void ExpectYes(double seconds, string textPart, int type)
	{
		_expectYesUntil = DateTime.UtcNow.AddSeconds(seconds);
		_expectYesText = textPart ?? "";
		_expectYesType = type;
	}

	private static int _expectYesType;

	private static void YesSoon()
	{
		try
		{
			AnswerConfirm(yes: true);
			string text = ((_confirmText.Length > 80) ? (_confirmText.Substring(0, 80) + "...") : _confirmText);
			Util.WriteToChat("Answered Yes: " + text);
			if (_yesTimer == null)
			{
				_yesTimer = new System.Windows.Forms.Timer
				{
					Interval = 400
				};
				_yesTimer.Tick += (object? o, EventArgs e) =>
				{
					_yesTimer.Stop();
					try
					{
						nint hwnd = CoreManager.Current.Decal.Hwnd;
						if (GetClientRect(hwnd, out var rect))
						{
							Click((rect.Right - rect.Left) / 2 - 84, (rect.Bottom - rect.Top) / 2 + 24);
						}
					}
					catch (Exception ex2)
					{
						Util.LogError(ex2);
					}
				};
			}
			_yesTimer.Stop();
			_yesTimer.Start();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void HookConfirm(bool on)
	{
		try
		{
			if (!on)
			{
				if (_confirmEvent != null && (object)_confirmHandler != null)
				{
					_confirmEvent.RemoveEventHandler(null, _confirmHandler);
				}
				_confirmHandler = null;
				_confirmEvent = null;
				return;
			}
			Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
			foreach (Assembly assembly in assemblies)
			{
				if (assembly.FullName.StartsWith("UtilityBelt.Helper", StringComparison.Ordinal))
				{
					Type type = assembly.GetType("UBHelper.ConfirmationRequest");
					EventInfo eventInfo = ((type != null) ? type.GetEvent("ConfirmationRequestEvent") : null);
					if (!(eventInfo == null))
					{
						MethodInfo method = typeof(Remote).GetMethod("OnConfirmRequest", BindingFlags.Static | BindingFlags.NonPublic);
						_confirmHandler = Delegate.CreateDelegate(eventInfo.EventHandlerType, method);
						eventInfo.AddEventHandler(null, _confirmHandler);
						_confirmEvent = eventInfo;
					}
					break;
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void OnConfirmRequest(object sender, EventArgs e)
	{
		try
		{
			Type type = e.GetType();
			string text = (type.GetProperty("Text").GetValue(e, null) as string) ?? "";
			Settings currentSettings = PluginCore.CurrentSettings;
			if (currentSettings != null && currentSettings.AutoYes100 && Sure100Rx.IsMatch(text))
			{
				type.GetProperty("ClickYes").SetValue(e, true, null);
				HookAnsweredUtc = DateTime.UtcNow;
				Util.WriteToChat("Answered Yes (100%): " + ((text.Length > 80) ? (text.Substring(0, 80) + "...") : text));
			}
			else if (!(DateTime.UtcNow > _expectYesUntil) && (_expectYesText.Length <= 0 || text.IndexOf(_expectYesText, StringComparison.OrdinalIgnoreCase) >= 0))
			{
				type.GetProperty("ClickYes").SetValue(e, true, null);
				_expectYesUntil = DateTime.MinValue;
				HookAnsweredUtc = DateTime.UtcNow;
				_confirmAnswered = true;
				Util.WriteToChat("Answered Yes: " + ((text.Length > 80) ? (text.Substring(0, 80) + "...") : text));
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static bool AnswerConfirm(bool yes)
	{
		try
		{
			CM_Character.Event_ConfirmationResponse(_confirmType, (uint)_confirmContext, yes ? 1 : 0);
			return true;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			return false;
		}
	}

	public static void SmallJump(int holdMs)
	{
		try
		{
			if (UbCmd.Try("/ub jump " + Math.Max(0, Math.Min(1000, holdMs))))
			{
				return;
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		try
		{
			Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
			foreach (Assembly assembly in assemblies)
			{
				if (assembly.FullName.StartsWith("UtilityBelt.Helper", StringComparison.Ordinal))
				{
					Type type = assembly.GetType("UBHelper.Jumper");
					MethodInfo methodInfo = ((type != null) ? type.GetMethod("Jump", new Type[7]
					{
						typeof(float),
						typeof(float),
						typeof(bool),
						typeof(bool),
						typeof(bool),
						typeof(bool),
						typeof(bool)
					}) : null);
					if (methodInfo == null)
					{
						break;
					}
					float num = (float)CoreManager.Current.Actions.Heading;
					methodInfo.Invoke(null, new object[7]
					{
						num,
						Math.Max(0.05f, Math.Min(1f, (float)holdMs / 1000f)),
						false,
						false,
						false,
						false,
						false
					});
					return;
				}
			}
		}
		catch (Exception ex2)
		{
			Util.LogError(ex2);
		}
		nint wnd;
		try
		{
			wnd = CoreManager.Current.Decal.Hwnd;
		}
		catch
		{
			return;
		}
		int lDown = 3735553;
		PostMessage(wnd, 256u, 32, lDown);
		System.Threading.Timer t = null;
		t = new System.Threading.Timer((object? _) =>
		{
			try
			{
				PostMessage(wnd, 257u, 32, lDown | -1073741824);
			}
			catch
			{
			}
			try
			{
				t.Dispose();
			}
			catch
			{
			}
		}, null, Math.Max(30, holdMs), -1);
	}

	private static void QueueUse(int id)
	{
		if (id == _useId || _useQueue.Contains(id))
		{
			return;
		}
		_useQueue.Add(id);
		string text = "item";
		try
		{
			WorldObject worldObject = CoreManager.Current.WorldFilter[id];
			if (worldObject != null)
			{
				text = worldObject.Name;
			}
		}
		catch
		{
		}
		Util.WriteToChat("Phone: will use " + text + " once idle (pausing MelkTank).");
	}

	private static void UseTick(string acct)
	{
		if (_useId == 0)
		{
			if (_useQueue.Count != 0)
			{
				_useId = _useQueue[0];
				_useQueue.RemoveAt(0);
				_useStartUtc = DateTime.UtcNow;
				_useIdleSince = DateTime.MaxValue;
				_useDoneAt = DateTime.MaxValue;
				PluginCore.Pause("Phone: using an item");
			}
			return;
		}
		CoreManager current = CoreManager.Current;
		WorldObject worldObject = null;
		try
		{
			worldObject = current.WorldFilter[_useId];
		}
		catch
		{
		}
		if (_useDoneAt != DateTime.MaxValue)
		{
			if (ConfirmPending && !_confirmAnswered && (DateTime.UtcNow - _confirmAt).TotalSeconds > 0.8 && _confirmText.IndexOf("luminance", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				_confirmAnswered = true;
				try
				{
					nint hwnd = CoreManager.Current.Decal.Hwnd;
					if (GetClientRect(hwnd, out var rect))
					{
						int num = rect.Right - rect.Left;
						int num2 = rect.Bottom - rect.Top;
						int x = num / 2 - 84;
						int y = num2 / 2 + 24;
						AnswerConfirm(yes: true);
						Click(x, y);
						Util.WriteToChat("Phone: answered Yes (" + num + "x" + num2 + " window, clicked " + x + "," + y + ").");
					}
				}
				catch (Exception ex)
				{
					Util.LogError(ex);
				}
				_confirmForUse = false;
				_useDoneAt = DateTime.UtcNow.AddSeconds(2.5);
			}
			else if (!(DateTime.UtcNow < _useDoneAt) && !ConfirmPending)
			{
				FinishUse(acct);
			}
			return;
		}
		if (worldObject == null)
		{
			Util.WriteToChat("Phone: that item isn't in your inventory any more.");
			FinishUse(acct);
			return;
		}
		if ((DateTime.UtcNow - _useStartUtc).TotalSeconds > 45.0)
		{
			Util.WriteToChat("Phone: gave up using " + worldObject.Name + " - the character never went idle.");
			FinishUse(acct);
			return;
		}
		int num3 = 1;
		try
		{
			num3 = current.Actions.BusyState;
		}
		catch
		{
		}
		if (num3 != 0)
		{
			_useIdleSince = DateTime.MaxValue;
		}
		else if (_useIdleSince == DateTime.MaxValue)
		{
			_useIdleSince = DateTime.UtcNow;
		}
		else
		{
			if ((DateTime.UtcNow - _useIdleSince).TotalSeconds < 1.0)
			{
				return;
			}
			try
			{
				if (current.Actions.CombatMode != CombatState.Peace)
				{
					current.Actions.SetCombatMode(CombatState.Peace);
					_useIdleSince = DateTime.MaxValue;
					return;
				}
				ExpectYes(15.0, "luminance");
				current.Actions.UseItem(_useId, 0);
				_lastUseUtc = DateTime.UtcNow;
				Util.WriteToChat("Phone: using " + worldObject.Name + ".");
			}
			catch (Exception ex2)
			{
				Util.LogError(ex2);
			}
			_useDoneAt = DateTime.UtcNow.AddSeconds(2.5);
		}
	}

	private static void FinishUse(string acct)
	{
		_useId = 0;
		if (_useQueue.Count == 0)
		{
			PluginCore.Resume("Phone: using an item");
		}
		WriteInventory(acct);
	}

	private static void OrganizeTick(string acct)
	{
		if ((DateTime.UtcNow - _orgAt).TotalSeconds < 2.0)
		{
			return;
		}
		_orgAt = DateTime.UtcNow;
		try
		{
			string text = PackOrganizer.Json();
			if (!(text == _orgWritten))
			{
				_orgWritten = text;
				WriteLater(Path.Combine(Dir, "organize_" + Key(acct) + ".json"), text);
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void InventoryTick(string acct)
	{
		if (DateTime.UtcNow >= _invSoonUtc)
		{
			_invSoonUtc = DateTime.MaxValue;
			WriteInventory(acct);
		}
		else if (DateTime.UtcNow >= _invAgainUtc)
		{
			_invAgainUtc = DateTime.MaxValue;
			WriteInventory(acct);
		}
	}

	private static string SlotName(int mask)
	{
		for (int i = 0; i < SlotNames.Length; i++)
		{
			if ((mask & (1 << i)) != 0)
			{
				return SlotNames[i];
			}
		}
		return "Equipped";
	}

	private static int LowBit(int mask)
	{
		for (int i = 0; i < 31; i++)
		{
			if ((mask & (1 << i)) != 0)
			{
				return i;
			}
		}
		return 31;
	}

	private static string FullText(WorldObject o, string desc)
	{
		StringBuilder stringBuilder = new StringBuilder(desc ?? "");
		int[] array = new int[3] { 16, 15, 14 };
		foreach (int key in array)
		{
			string text = (LootMatcher.Str(o, key) ?? "").Replace("\r", "").Trim();
			if (text.Length != 0 && stringBuilder.ToString().IndexOf(text, StringComparison.Ordinal) < 0)
			{
				stringBuilder.Append((stringBuilder.Length > 0) ? "\n\n" : "").Append(text);
			}
		}
		return stringBuilder.ToString();
	}

	private static void WriteInventory(string acct)
	{
		try
		{
			CoreManager current = CoreManager.Current;
			int id = current.CharacterFilter.Id;
			List<WorldObject> list = new List<WorldObject>();
			List<WorldObject> list2 = new List<WorldObject>();
			List<WorldObject> list3 = new List<WorldObject>();
			List<WorldObject> list4 = new List<WorldObject>();
			List<WorldObject> list5 = new List<WorldObject>();
			foreach (WorldObject item in InvCache.All())
			{
				list5.Add(item);
			}
			Dictionary<int, int> dictionary = new Dictionary<int, int>();
			foreach (WorldObject item2 in list5)
			{
				int container = item2.Container;
				dictionary.TryGetValue(container, out var value);
				dictionary[container] = value + 1;
				int num = 0;
				try
				{
					num = item2.Values(LongValueKey.EquippedSlots, 0);
				}
				catch
				{
				}
				if (num != 0)
				{
					list.Add(item2);
				}
				else if (item2.Container == id && item2.ObjectClass == ObjectClass.Container)
				{
					list3.Add(item2);
				}
				else if (item2.Container == id)
				{
					list2.Add(item2);
				}
				else if (_invPack != 0 && item2.Container == _invPack)
				{
					list4.Add(item2);
				}
			}
			list3.Sort((WorldObject a, WorldObject b) => a.Values(LongValueKey.Slot, 0).CompareTo(b.Values(LongValueKey.Slot, 0)));
			list4.Sort((WorldObject a, WorldObject b) => a.Values(LongValueKey.Slot, 0).CompareTo(b.Values(LongValueKey.Slot, 0)));
			if (_invPack != 0 && !list3.Exists((WorldObject x) => x.Id == _invPack))
			{
				_invPack = 0;
			}
			list.Sort((WorldObject a, WorldObject b) => LowBit(a.Values(LongValueKey.EquippedSlots, 0)).CompareTo(LowBit(b.Values(LongValueKey.EquippedSlots, 0))));
			list2.Sort((WorldObject a, WorldObject b) => a.Values(LongValueKey.Slot, 0).CompareTo(b.Values(LongValueKey.Slot, 0)));
			DateTime utcNow = DateTime.UtcNow;
			HashSet<int> hashSet = new HashSet<int>();
			StringBuilder stringBuilder = new StringBuilder("{\n  \"updated\": \"" + DateTime.UtcNow.ToString("o") + "\",\n  \"openPack\": " + _invPack + ",\n  \"packs\": [");
			bool flag = true;
			foreach (WorldObject item3 in list3)
			{
				dictionary.TryGetValue(item3.Id, out var value2);
				int value3 = 0;
				try
				{
					value3 = item3.Values(LongValueKey.ItemSlots, 0);
				}
				catch
				{
				}
				stringBuilder.Append(flag ? "\n    " : ",\n    ").Append("{\"id\": ").Append(item3.Id)
					.Append(", \"n\": ")
					.Append(JsonQ(item3.Name ?? "Pack"))
					.Append(", \"count\": ")
					.Append(value2)
					.Append(", \"cap\": ")
					.Append(value3)
					.Append('}');
				flag = false;
			}
			stringBuilder.Append("\n  ],\n  \"items\": [");
			flag = true;
			List<WorldObject>[] array = new List<WorldObject>[3] { list, list2, list4 };
			foreach (List<WorldObject> list6 in array)
			{
				foreach (WorldObject item4 in list6)
				{
					int num3 = ((list6 == list) ? item4.Values(LongValueKey.EquippedSlots, 0) : 0);
					if ((item4.Name ?? "").StartsWith("Bag of", StringComparison.OrdinalIgnoreCase) && !item4.HasIdData && _bagAsked.Add(item4.Id))
					{
						try
						{
							Util.RequestId(item4.Id);
							_invAgainUtc = DateTime.UtcNow.AddSeconds(4.0);
						}
						catch
						{
						}
					}
					int num4 = ((list6 == list4) ? _invPack : 0);
					bool hasIdData = item4.HasIdData;
					long num5 = (long)((ulong)((long)Math.Max(1, item4.Values(LongValueKey.StackCount, 1)) << 34) ^ ((ulong)(uint)num3 << 2) ^ (ulong)(hasIdData ? 2 : 0)) ^ (long)((num4 != 0) ? 1 : 0);
					if (!_invLines.TryGetValue(item4.Id, out var value4) || value4.Sig != num5 || value4.Pk != num4 || utcNow >= value4.Until || (item4.Id == _invFreshId && utcNow < _invFreshUntil))
					{
						string text = "";
						string s = "";
						if (hasIdData)
						{
							try
							{
								text = ItemReport.Describe(item4, null);
							}
							catch
							{
							}
							text = FullText(item4, text);
							try
							{
								UtlRule utlRule = ((Looter.Current != null) ? Looter.Current.Match(item4) : null);
								if (utlRule != null)
								{
									s = (utlRule.Name ?? "").Trim() + ((utlRule.Act == "0") ? " (don't loot)" : "");
								}
							}
							catch
							{
							}
						}
						StringBuilder stringBuilder2 = new StringBuilder();
						stringBuilder2.Append("{\"id\": ").Append(item4.Id).Append(", \"n\": ")
							.Append(JsonQ(ItemReport.FullName(item4)))
							.Append(", \"q\": ")
							.Append(Math.Max(1, item4.Values(LongValueKey.StackCount, 1)))
							.Append(", \"eq\": ")
							.Append(JsonQ((num3 != 0) ? SlotName(num3) : ""))
							.Append(", \"pk\": ")
							.Append(num4)
							.Append(", \"c\": ")
							.Append(JsonQ(Session.Category(item4.ObjectClass)))
							.Append(", \"r\": ")
							.Append(JsonQ(s))
							.Append(", \"d\": ")
							.Append(JsonQ(text))
							.Append('}');
						value4 = new InvLine
						{
							Sig = num5,
							Pk = num4,
							Json = stringBuilder2.ToString(),
							Until = utcNow.AddSeconds(120 + (item4.Id & 0x3F))
						};
						_invLines[item4.Id] = value4;
					}
					hashSet.Add(item4.Id);
					stringBuilder.Append(flag ? "\n    " : ",\n    ").Append(value4.Json);
					flag = false;
				}
			}
			if (_invLines.Count > hashSet.Count + 50)
			{
				foreach (int item5 in new List<int>(_invLines.Keys))
				{
					if (!hashSet.Contains(item5))
					{
						_invLines.Remove(item5);
					}
				}
			}
			stringBuilder.Append("\n  ]\n}\n");
			WriteLater(Path.Combine(Dir, "inventory_" + Key(acct) + ".json"), stringBuilder.ToString());
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void TransferTick()
	{
		if (_xferKind == null)
		{
			return;
		}
		if (!BankKinds.TryGetValue(_xferKind, out var value))
		{
			_xferKind = null;
			return;
		}
		if (!_bankAt.TryGetValue(value, out var value2))
		{
			value2 = DateTime.MinValue;
		}
		if (!_bankHave.TryGetValue(value, out var value3))
		{
			value3 = 0L;
		}
		bool flag = value2 > _xferAt;
		if (!flag && (DateTime.UtcNow - _xferAt).TotalSeconds < 10.0)
		{
			return;
		}
		string text = value.ToLowerInvariant();
		string xferKind = _xferKind;
		string xferTarget = _xferTarget;
		_xferKind = null;
		if (!flag)
		{
			_lastCommand = DateTime.UtcNow.ToString("o") + " transfer cancelled: /bank didn't answer with " + text;
			Util.WriteToChat("Transfer cancelled: no " + text + " line from /bank.");
			_chatDirty = true;
			return;
		}
		long num = value3 - 1;
		if (num < 1)
		{
			_lastCommand = DateTime.UtcNow.ToString("o") + " transfer: only " + value3 + " " + text + " in the bank - nothing to send";
			Util.WriteToChat("Transfer: only " + value3 + " " + text + " in the bank - nothing to send.");
			_chatDirty = true;
		}
		else
		{
			string text2 = "/b t " + xferKind + " " + num.ToString(CultureInfo.InvariantCulture) + " \"" + xferTarget + "\"";
			SendOrQueue(text2, idle: false);
		}
	}

	private static void PendingChatTick()
	{
		if (DateTime.UtcNow >= _rewriteAt)
		{
			_rewriteAt = DateTime.MaxValue;
			WriteStatusSoon();
		}
		if (_pendingChat.Count == 0)
		{
			_notBusySince = DateTime.MaxValue;
			return;
		}
		_pendingChat.RemoveAll((Pending p) => (DateTime.UtcNow - p.Added).TotalMinutes > 10.0);
		if (_pendingChat.Count == 0)
		{
			_chatDirty = true;
			return;
		}
		int num = 1;
		try
		{
			num = CoreManager.Current.Actions.BusyState;
		}
		catch
		{
		}
		if (num != 0)
		{
			_notBusySince = DateTime.MaxValue;
		}
		else if (_notBusySince == DateTime.MaxValue)
		{
			_notBusySince = DateTime.UtcNow;
		}
		Pending pending = _pendingChat[0];
		if (!((DateTime.UtcNow - _chatSentAt).TotalSeconds < 1.0) && (!pending.Idle || (!(_notBusySince == DateTime.MaxValue) && !((DateTime.UtcNow - _notBusySince).TotalSeconds < 1.0))) && (!IsBank(pending.Text) || !((DateTime.UtcNow - _lastBankAt).TotalSeconds < 6.0)))
		{
			_pendingChat.RemoveAt(0);
			_notBusySince = DateTime.MaxValue;
			SendNow(pending.Text);
		}
	}

	private static void Live(out bool live, out bool session)
	{
		if ((DateTime.UtcNow - _liveReadUtc).TotalSeconds >= 1.0)
		{
			_liveReadUtc = DateTime.UtcNow;
			_liveUntil = 0L;
			_liveSession = false;
			_liveChat = false;
			try
			{
				string path = Path.Combine(Dir, "live.txt");
				if (File.Exists(path))
				{
					Dictionary<string, string> dictionary = ReadKeyValues(path);
					if (dictionary.TryGetValue("until", out var value))
					{
						long.TryParse(value, out _liveUntil);
					}
					_liveSession = dictionary.TryGetValue("session", out value) && value.Trim() == "1";
					_liveChat = dictionary.TryGetValue("chat", out value) && value.Trim() == "1";
				}
			}
			catch
			{
			}
		}
		long num = (long)(DateTime.UtcNow - new DateTime(1970, 1, 1)).TotalSeconds;
		live = _liveUntil > num;
		session = live && _liveSession;
	}

	private static void AutoLoginTick(string acct)
	{
		if (DateTime.UtcNow < _nextStepUtc)
		{
			return;
		}
		string path = Path.Combine(Dir, "launch_" + Key(acct) + ".txt");
		Dictionary<string, string> dictionary = ReadKeyValues(path);
		if (!dictionary.TryGetValue("time", out var value) || value == _handledStamp)
		{
			return;
		}
		if (!DateTime.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal, out var result) || (DateTime.UtcNow - result).TotalMinutes > 5.0)
		{
			_handledStamp = value;
			return;
		}
		if (value != _activeStamp)
		{
			_activeStamp = value;
			_loginTries = 0;
			_loginStep = 0;
		}
		dictionary.TryGetValue("character", out var character);
		character = (character ?? "").Trim();
		dictionary.TryGetValue("picker", out var value2);
		bool flag = string.Equals((value2 ?? "").Trim(), "thwargfilter", StringComparison.OrdinalIgnoreCase);
		_handledStamp = value;
		_loginNote = ((character.Length > 0) ? ((flag ? "ThwargFilter" : "MelkTank's login filter") + " is logging in " + character + ".") : "Waiting on the character screen.");
		WriteStatusSoon();
	}

	private static string CharsFile(string acct)
	{
		return Path.Combine(Dir, "chars_" + Key(acct) + ".txt");
	}

	private static void RememberCharacter(string acct, string name)
	{
		if (!string.IsNullOrEmpty(acct) && !string.IsNullOrEmpty(name))
		{
			List<string> list = KnownCharacters(acct);
			if (!list.Exists((string n) => string.Equals(n, name, StringComparison.OrdinalIgnoreCase)))
			{
				list.Add(name);
				list.Sort(StringComparer.OrdinalIgnoreCase);
				Util.WriteShared(CharsFile(acct), string.Join("\r\n", list.ToArray()) + "\r\n");
			}
		}
	}

	private static List<string> KnownCharacters(string acct)
	{
		List<string> list = new List<string>();
		try
		{
			string f = CharsFile(acct);
			if (File.Exists(f))
			{
				string[] array = Util.Locked(f, () => File.ReadAllLines(f));
				foreach (string text in array)
				{
					if (text.Trim().Length > 0)
					{
						list.Add(text.Trim());
					}
				}
			}
		}
		catch
		{
		}
		// the game's own list (every character on the account, from the character screen): that's what's there - kept,
		// so it's known before the next login too, and a character deleted there goes from it
		List<AccountCharInfo> all = SortedCharacters();
		if (all.Count > 0 && !string.IsNullOrEmpty(acct))
		{
			List<string> names = all.ConvertAll((AccountCharInfo c) => c.Name);
			names.Sort(StringComparer.OrdinalIgnoreCase);
			if (string.Join("\n", names.ToArray()).ToLowerInvariant() != string.Join("\n", list.ToArray()).ToLowerInvariant())
			{
				try { Util.WriteShared(CharsFile(acct), string.Join("\r\n", names.ToArray()) + "\r\n"); } catch { }
			}
			return names;
		}
		list.Sort(StringComparer.OrdinalIgnoreCase);
		return list;
	}

	private static List<AccountCharInfo> SortedCharacters()
	{
		List<AccountCharInfo> list = new List<AccountCharInfo>();
		try
		{
			foreach (AccountCharInfo character in CoreManager.Current.CharacterFilter.Characters)
			{
				list.Add(character);
			}
		}
		catch
		{
		}
		list.Sort((AccountCharInfo a, AccountCharInfo b) => string.Compare(a.Name, b.Name, StringComparison.Ordinal));
		return list;
	}

	[DllImport("user32.dll")]
	private static extern bool PostMessage(nint hWnd, uint msg, nint wParam, nint lParam);

	private static void Click(int x, int y)
	{
		try
		{
			nint hwnd = CoreManager.Current.Decal.Hwnd;
			nint lParam = (y << 16) | (x & 0xFFFF);
			PostMessage(hwnd, 512u, IntPtr.Zero, lParam);
			PostMessage(hwnd, 513u, 1, lParam);
			PostMessage(hwnd, 514u, IntPtr.Zero, lParam);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void OnServer(object sender, NetworkMessageEventArgs e)
	{
		try
		{
			if (e.Message == null)
			{
				return;
			}
			if (e.Message.Type == 63064)
			{
				try
				{
					_slotCount = Convert.ToInt32(e.Message["slotCount"]);
				}
				catch
				{
				}
				if (!_inWorld)
				{
					WriteStatusSoon();
				}
			}
			else if (e.Message.Type == 63408)
			{
				byte[] rawData = e.Message.RawData;
				if (rawData == null || rawData.Length < 16)
				{
					return;
				}
				int num = ((BitConverter.ToUInt32(rawData, 0) == 63408) ? 4 : 0);
				if (rawData.Length < num + 20 || BitConverter.ToUInt32(rawData, num + 8) != 628)
				{
					return;
				}
				_confirmType = (int)BitConverter.ToUInt32(rawData, num + 12);
				_confirmContext = (int)BitConverter.ToUInt32(rawData, num + 16);
				string text = "";
				try
				{
					int num2 = num + 20;
					int num3 = BitConverter.ToUInt16(rawData, num2);
					if (num3 > 0 && num2 + 2 + num3 <= rawData.Length)
					{
						text = Encoding.ASCII.GetString(rawData, num2 + 2, num3);
					}
				}
				catch
				{
				}
				_confirmText = text.Replace("\r", " ").Replace("\n", " ").Trim();
				try
				{
					Session.NoteConfirmText(_confirmText);
				}
				catch
				{
				}
				_confirmAt = DateTime.UtcNow;
				_confirmAnswered = (DateTime.UtcNow - HookAnsweredUtc).TotalSeconds < 3.0;
				if (!_confirmAnswered && DateTime.UtcNow <= _expectYesUntil && (_expectYesType == 0 || _confirmType == _expectYesType) && (_expectYesText.Length == 0 || _confirmText.IndexOf(_expectYesText, StringComparison.OrdinalIgnoreCase) >= 0))
				{
					_expectYesUntil = DateTime.MinValue;
					_confirmAnswered = true;
					YesSoon();
				}
				if (_confirmForUse = _useDoneAt != DateTime.MaxValue || (DateTime.UtcNow - _lastUseUtc).TotalSeconds < 15.0)
				{
					Util.WriteToChat("Phone: the game asks to confirm (type " + _confirmType + "): " + _confirmText);
					WriteStatusSoon();
				}
			}
			else
			{
				if (e.Message.Type != 719)
				{
					return;
				}
				byte[] rawData2 = e.Message.RawData;
				if (rawData2 == null || rawData2.Length < 13)
				{
					return;
				}
				int num4 = ((BitConverter.ToUInt32(rawData2, 0) == 719) ? 4 : 0);
				if (rawData2.Length >= num4 + 13)
				{
					uint num5 = BitConverter.ToUInt32(rawData2, num4 + 1);
					long num6 = BitConverter.ToInt64(rawData2, num4 + 5);
					switch (num5)
					{
					case 6u:
						_lumChar = num6;
						break;
					case 7u:
						_lumCharMax = num6;
						break;
					}
				}
			}
		}
		catch
		{
		}
	}

	private static void OnChat(object sender, ChatTextInterceptEventArgs e)
	{
		try
		{
			string text = Util.NoTints(e.Text ?? "").Trim();
			HoldChat(text, e.Color, e);
			if (!text.StartsWith("[bank]", StringComparison.OrdinalIgnoreCase))
			{
				return;
			}
			long value;
			foreach (string value2 in BankKinds.Values)
			{
				if (TryBankLine(text, "[bank] " + value2.ToLowerInvariant() + ":", out value))
				{
					_bankHave[value2] = value;
					_bankAt[value2] = DateTime.UtcNow;
					break;
				}
			}
			if (TryBankLine(text, "[bank] luminance:", out value))
			{
				_lumBank = value;
				_lumBankAt = DateTime.UtcNow;
			}
			else if (TryBankLine(text, "[bank] enlightened coins:", out value))
			{
				_coinsBank = value;
				_coinsBankAt = DateTime.UtcNow;
			}
		}
		catch
		{
		}
	}

	private static bool TryBankLine(string text, string prefix, out long value)
	{
		value = 0L;
		if (!text.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
		{
			return false;
		}
		string text2 = text.Substring(prefix.Length).Replace(",", "").Trim();
		int num = text2.IndexOf(' ');
		if (num > 0)
		{
			text2 = text2.Substring(0, num);
		}
		return long.TryParse(text2, NumberStyles.Integer, CultureInfo.InvariantCulture, out value);
	}

	private static void ProcessCommands(string acct)
	{
		string[] files;
		try
		{
			files = Directory.GetFiles(Dir, "cmd_" + Key(acct) + "_*.txt");
		}
		catch
		{
			return;
		}
		if (files.Length == 0)
		{
			return;
		}
		Array.Sort(files, StringComparer.Ordinal);
		string[] array = files;
		foreach (string path in array)
		{
			try
			{
				if ((DateTime.UtcNow - File.GetLastWriteTimeUtc(path)).TotalMinutes > 10.0)
				{
					File.Delete(path);
					continue;
				}
				Dictionary<string, string> dictionary = ReadKeyValues(path);
				dictionary.TryGetValue("action", out var value);
				if (string.Equals(value, "quit", StringComparison.OrdinalIgnoreCase))
				{
					File.Delete(path);
					StartQuit();
					break;
				}
				if (!_inWorld)
				{
					continue;
				}
				File.Delete(path);
				if (string.Equals(value, "resetsession", StringComparison.OrdinalIgnoreCase))
				{
					try
					{
						Session.Reset();
						Util.WriteToChat("Session reset (from the phone) - tracking from here.");
					}
					catch (Exception ex)
					{
						Util.LogError(ex);
					}
					_sessionWriteUtc = DateTime.MinValue;
				}
				else if (string.Equals(value, "rebuff", StringComparison.OrdinalIgnoreCase))
				{
					dictionary.TryGetValue("value", out var value2);
					try
					{
						CombatEngine currentEngine = PluginCore.CurrentEngine;
						if (currentEngine != null)
						{
							if (string.Equals(value2, "cancel", StringComparison.OrdinalIgnoreCase))
							{
								currentEngine.Buffer.Stop();
								Util.WriteToChat("Rebuff cancelled (from the phone).");
							}
							else
							{
								currentEngine.Buffer.RebuffNow();
								Util.WriteToChat("Rebuff started (from the phone).");
							}
						}
					}
					catch (Exception ex2)
					{
						Util.LogError(ex2);
					}
					_sessionWriteUtc = DateTime.MinValue;
				}
				else if (string.Equals(value, "useitem", StringComparison.OrdinalIgnoreCase))
				{
					dictionary.TryGetValue("name", out var value3);
					if (int.TryParse((value3 ?? "").Trim(), out var result) && result != 0)
					{
						QueueUse(result);
					}
				}
				else if (string.Equals(value, "reloadloot", StringComparison.OrdinalIgnoreCase))
				{
					dictionary.TryGetValue("name", out var value4);
					try
					{
						Looter current = Looter.Current;
						if (current != null && !string.IsNullOrEmpty(value4))
						{
							bool flag = current.Load(value4);
							Util.WriteToChat("Loot profile " + value4 + (flag ? " reloaded (pushed from the loot editor)." : " couldn't be read."));
						}
					}
					catch (Exception ex3)
					{
						Util.LogError(ex3);
					}
				}
				else if (string.Equals(value, "openpack", StringComparison.OrdinalIgnoreCase))
				{
					dictionary.TryGetValue("name", out var value5);
					if (string.Equals((value5 ?? "").Trim(), "toggle", StringComparison.OrdinalIgnoreCase))
					{
						if (ShowInventory(!_invWindowOpen))
						{
							_invWindowOpen = !_invWindowOpen;
						}
						_bagOpen = int.MinValue;
						_bagClose = false;
						continue;
					}
					int result2;
					if (string.Equals((value5 ?? "").Trim(), "close", StringComparison.OrdinalIgnoreCase))
					{
						_bagClose = true;
						_bagOpen = int.MinValue;
					}
					else if (int.TryParse((value5 ?? "").Trim(), out result2))
					{
						_bagOpen = result2;
						_bagClose = false;
						dictionary.TryGetValue("value", out var value6);
						if (string.Equals(value6, "nokey", StringComparison.OrdinalIgnoreCase))
						{
							_invWindowOpen = true;
						}
					}
					_bagAt = DateTime.UtcNow;
					_bagStep = 0;
				}
				else if (string.Equals(value, "showpack", StringComparison.OrdinalIgnoreCase))
				{
					dictionary.TryGetValue("name", out var value7);
					int.TryParse((value7 ?? "").Trim(), out var result3);
					_invPack = result3;
					_invSoonUtc = DateTime.UtcNow.AddSeconds(0.3);
				}
				else if (string.Equals(value, "identify", StringComparison.OrdinalIgnoreCase))
				{
					dictionary.TryGetValue("name", out var value8);
					if (int.TryParse((value8 ?? "").Trim(), out var result4) && result4 != 0)
					{
						try
						{
							Util.RequestId(result4);
						}
						catch
						{
						}
						_invFreshId = result4;
						_invFreshUntil = DateTime.UtcNow.AddSeconds(8.0);
						_invSoonUtc = DateTime.UtcNow.AddSeconds(2.5);
						_invAgainUtc = DateTime.UtcNow.AddSeconds(6.0);
					}
				}
				else if (string.Equals(value, "banktransfer", StringComparison.OrdinalIgnoreCase))
				{
					dictionary.TryGetValue("value", out var value9);
					dictionary.TryGetValue("name", out var value10);
					value9 = (value9 ?? "").Trim().ToLowerInvariant();
					value10 = (value10 ?? "").Trim().Trim('"');
					if (BankKinds.ContainsKey(value9) && value10.Length > 0)
					{
						_xferKind = value9;
						_xferTarget = value10;
						_xferAt = DateTime.UtcNow;
						SendOrQueue("/bank", idle: false);
						_lastCommand = DateTime.UtcNow.ToString("o") + " transfer: checking the bank first";
					}
				}
				else if (string.Equals(value, "setmany", StringComparison.OrdinalIgnoreCase))
				{
					dictionary.TryGetValue("name", out var value11);
					List<KeyValuePair<string, string>> list = new List<KeyValuePair<string, string>>();
					string[] array2 = (value11 ?? "").Split('\u0003');
					foreach (string text in array2)
					{
						int num = text.IndexOf('\u0002');
						if (num > 0)
						{
							list.Add(new KeyValuePair<string, string>(text.Substring(0, num), text.Substring(num + 1)));
						}
					}
					List<string> list2 = SettingsTools.SetMany(list, "phone");
					foreach (string item in list2)
					{
						Util.WriteToChat("Phone set: " + item);
					}
					_lastCommand = DateTime.UtcNow.ToString("o") + " set: " + string.Join("; ", list2.ToArray());
					WriteStatus(running: true);
				}
				else if (string.Equals(value, "organize", StringComparison.OrdinalIgnoreCase))
				{
					dictionary.TryGetValue("value", out var value12);
					dictionary.TryGetValue("name", out var value13);
					string text2 = PackOrganizer.Command(value12, value13);
					try
					{
						PluginCore.SaveAllNow();
					}
					catch
					{
					}
					_lastCommand = DateTime.UtcNow.ToString("o") + " " + text2;
					_orgWritten = null;
					WriteStatus(running: true);
				}
				else if (string.Equals(value, "snap", StringComparison.OrdinalIgnoreCase))
				{
					dictionary.TryGetValue("value", out var value14);
					dictionary.TryGetValue("name", out var value15);
					value14 = (value14 ?? "").Trim().ToLowerInvariant();
					string text3 = value14 switch
					{
						"delete" => SettingsTools.SnapDelete(value15), 
						"restore" => SettingsTools.SnapRestore(value15, "phone"), 
						"save" => SettingsTools.SnapSave(value15, "phone"), 
						_ => "unknown snapshot action", 
					};
					Util.WriteToChat("Phone: " + text3);
					_lastCommand = DateTime.UtcNow.ToString("o") + " " + text3;
					WriteStatus(running: true);
				}
				else if (string.Equals(value, "mem", StringComparison.OrdinalIgnoreCase))
				{
					Notes.Add(Notes.MemText(), "mem check", quiet: true);
				}
				else if (string.Equals(value, "markertest", StringComparison.OrdinalIgnoreCase))
				{
					PluginCore.CurrentEngine?.Nav.MarkerTest();
				}
				else if (string.Equals(value, "note", StringComparison.OrdinalIgnoreCase))
				{
					dictionary.TryGetValue("name", out var value16);
					Notes.Add(value16, "phone");
					_lastCommand = DateTime.UtcNow.ToString("o") + " note";
				}
				else if (string.Equals(value, "chat", StringComparison.OrdinalIgnoreCase))
				{
					dictionary.TryGetValue("name", out var value17);
					dictionary.TryGetValue("value", out var value18);
					value17 = (value17 ?? "").Trim();
					if (value17.Length != 0)
					{
						bool flag2 = string.Equals(value18, "wait", StringComparison.OrdinalIgnoreCase);
						string text4 = value17.ToLowerInvariant();
						if (flag2 && (text4 == "/b d" || text4 == "/bank d" || text4 == "/bank deposit"))
						{
							StartPausedDeposit(value17);
						}
						else
						{
							SendOrQueue(value17, flag2);
						}
					}
				}
				else
				{
					dictionary.TryGetValue("feature", out var value19);
					dictionary.TryGetValue("value", out var value20);
					dictionary.TryGetValue("name", out var value21);
					string text5 = PluginCore.RemoteApply(value ?? "", value19 ?? "", value20 ?? "", value21 ?? "");
					_lastCommand = DateTime.UtcNow.ToString("o") + " " + text5;
					WriteStatus(running: true);
				}
			}
			catch (Exception ex4)
			{
				Util.LogError(ex4);
			}
		}
	}

	public static void PlannedRelog(string why)
	{
		_relaunch = true;
		StartQuit("Planned relog (" + why + ") - exiting, the PC service starts it again");
	}

	private static void StartQuit()
	{
		StartQuit(null);
	}

	private static void StartQuit(string note)
	{
		if (_quitRequested)
		{
			return;
		}
		_quitRequested = true;
		_logoffAsked = true;
		_quitAtUtc = DateTime.UtcNow;
		_quitStep = 0;
		_loginNote = note ?? "Exiting the game (from the phone)...";
		_lastCommand = DateTime.UtcNow.ToString("o") + ((note == null) ? " exit game" : " planned relog");
		if (note == null)
		{
			try
			{
				Util.WriteToChat("Phone: exiting the game.");
			}
			catch
			{
			}
		}
		WriteStatus(running: true);
		try
		{
			if (_inWorld)
			{
				CoreManager.Current.Actions.Logout();
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void QuitTick()
	{
		double totalSeconds = (DateTime.UtcNow - _quitAtUtc).TotalSeconds;
		if (_inWorld && totalSeconds < 30.0)
		{
			return;
		}
		nint hwnd;
		try
		{
			hwnd = CoreManager.Current.Decal.Hwnd;
		}
		catch
		{
			return;
		}
		if (_quitStep == 0)
		{
			PostMessage(hwnd, 16u, IntPtr.Zero, IntPtr.Zero);
			_quitStep = 1;
			_quitAtUtc = DateTime.UtcNow;
		}
		else if (_quitStep == 1 && totalSeconds > 8.0)
		{
			PostMessage(hwnd, 256u, 27, 65537);
			PostMessage(hwnd, 257u, 27, -1073676287);
			_quitStep = 2;
			_quitAtUtc = DateTime.UtcNow;
		}
		else
		{
			if (_quitStep != 2 || !(totalSeconds > 2.0))
			{
				return;
			}
			if (GetClientRect(hwnd, out var rect))
			{
				for (int i = 18; i <= 31; i += 6)
				{
					Click((rect.Right - rect.Left) / 2 - 80, (rect.Bottom - rect.Top) / 2 + i);
				}
			}
			_quitStep = 3;
			_loginNote = "Asked the game to exit - use Force close if it's still open.";
			WriteStatus(running: true);
		}
	}

	[DllImport("user32.dll")]
	private static extern bool GetClientRect(nint hWnd, out RECT rect);

	// ACGodot: there's no status file to write - its phone plugin asks for the status itself, and gets what the file would have held
	private static bool _capture;

	private static string _captured = "";

	public static string StatusJsonNow()
	{
		_capture = true;
		_captured = "";
		try
		{
			WriteStatus(running: true);
		}
		finally
		{
			_capture = false;
		}
		return _captured;
	}

	public static void WriteStatus(bool running)
	{
		try
		{
			string account = Account;
			if (account.Length == 0)
			{
				if (!_capture)
				{
					return;
				}
				account = "ACGodot";
			}
			_lastWriteUtc = DateTime.UtcNow;
			long t = Perf.Begin();
			CoreManager core = CoreManager.Current;
			Settings currentSettings = PluginCore.CurrentSettings;
			CombatEngine currentEngine = PluginCore.CurrentEngine;
			bool flag = (_inWorld || _capture) && currentSettings != null && currentEngine != null;
			Json json = new Json();
			json.Str("account", account);
			json.Str("server", Safe(() => core.CharacterFilter.Server));
			json.Str("character", flag ? Safe(() => core.CharacterFilter.Name) : "");
			json.Bool("running", running);
			json.Bool("loggedIn", flag);
			json.Str("updated", DateTime.UtcNow.ToString("o"));
			json.Num("interval", IntervalSeconds);
			json.Str("clientStarted", _clientStartUtc.ToString("o"));
			json.Str("build", BuildInfo.Label);
			json.Str("loginNote", _loginNote);
			json.Bool("logoffRequested", _logoffRequested);
			json.Bool("relaunch", _relaunch);
			try
			{
				Settings currentSettings2 = PluginCore.CurrentSettings;
				json.Num("relogMB", (currentSettings2 != null && currentSettings2.AutoRelogOn) ? ((long)(currentSettings2.AutoRelogGB * 1024f)) : 0);
				if (MemWatch.PendingSince != DateTime.MinValue)
				{
					json.Bool("relogPending", v: true);
				}
			}
			catch
			{
			}
			json.List("characters", KnownCharacters(account));
			if (flag)
			{
				json.Str("loginTime", _loginAtUtc.ToString("o"));
				json.Str("lastAttack", (currentEngine.LastAttackAt == DateTime.MinValue) ? "" : currentEngine.LastAttackAt.ToUniversalTime().ToString("o"));
				json.Num("lum", _lumChar);
				json.Num("lumMax", _lumCharMax);
				json.Num("lumBank", _lumBank);
				json.Num("coins", CountInventory("Enlightened Coin"));
				json.Num("coinsBank", _coinsBank);
				json.Num("deaths", _deaths);
				try
				{
					Session.EnlPhone(out var on, out var status, out var target, out var now);
					json.Bool("enlOn", on);
					json.Str("enlStatus", status);
					json.Num("enlTarget", target);
					json.Num("enlNow", now);
					json.List("enlLines", Session.EnlPhoneLines(target));
				}
				catch
				{
				}
				try
				{
					try
					{
						TellsFor(Globals.Core.CharacterFilter.Name ?? "");
					}
					catch
					{
					}
					json.Num("tellSeq", _tellSeq);
					json.Str("tellLast", _tellLast);
				}
				catch
				{
				}
				try
				{
					json.Num("landcell", (uint)core.Actions.Landcell);
				}
				catch
				{
				}
				try
				{
					CharacterFilter characterFilter = core.CharacterFilter;
					int health = characterFilter.Health;
					int stamina = characterFilter.Stamina;
					int mana = characterFilter.Mana;
					int num = 0;
					int num2 = 0;
					int num3 = 0;
					try
					{
						num = characterFilter.EffectiveVital[CharFilterVitalType.Health];
					}
					catch
					{
					}
					try
					{
						num2 = characterFilter.EffectiveVital[CharFilterVitalType.Stamina];
					}
					catch
					{
					}
					try
					{
						num3 = characterFilter.EffectiveVital[CharFilterVitalType.Mana];
					}
					catch
					{
					}
					int max = 0;
					try
					{
						PluginCore.CurrentEngine?.Healer.HealthPercent(out var _, out max);
					}
					catch
					{
					}
					if (max > num)
					{
						num = max;
					}
					int num4 = -1;
					try
					{
						CombatEngine currentEngine2 = PluginCore.CurrentEngine;
						if (currentEngine2 != null)
						{
							num4 = currentEngine2.Tier.Tier;
						}
					}
					catch
					{
					}
					if (num4 != _vitTier)
					{
						_vitTier = num4;
						_hpSeen = (_stSeen = (_mpSeen = 0));
					}
					_hpSeen = Math.Max(_hpSeen, health);
					_stSeen = Math.Max(_stSeen, stamina);
					_mpSeen = Math.Max(_mpSeen, mana);
					json.Num("hp", health);
					json.Num("hpMax", (num >= health) ? num : _hpSeen);
					json.Num("st", stamina);
					json.Num("stMax", (num2 >= stamina) ? num2 : _stSeen);
					json.Num("mp", mana);
					json.Num("mpMax", (num3 >= mana) ? num3 : _mpSeen);
				}
				catch
				{
				}
				json.Str("lastDeath", (_lastDeathUtc == DateTime.MinValue) ? "" : _lastDeathUtc.ToString("o"));
				json.Bool("master", currentSettings.MasterEnabled);
				json.Bool("combat", currentSettings.CombatEnabled);
				json.Bool("nav", currentSettings.NavEnabled);
				json.Bool("loot", currentSettings.LootEnabled);
				try
				{
					json.Num("mobs", currentEngine.MobsInRangeCount());
					json.Num("corpses", currentEngine.Looter.UnlootedInRange());
				}
				catch
				{
				}
				try
				{
					Rectangle rectangle = CoreManager.Current.Actions.UIElementRegion(UIElementType.Panels);
					Rectangle rectangle2 = CoreManager.Current.Actions.UIElementRegion(UIElementType.TBar);
					long num5 = 0L;
					try
					{
						num5 = ((IntPtr)CoreManager.Current.Actions.UIElementLookup(UIElementType.Panels)).ToInt64();
					}
					catch
					{
					}
					json.Str("uiDiag", "panels " + rectangle.Left + "," + rectangle.Top + " " + rectangle.Width + "x" + rectangle.Height + " lookup " + num5.ToString("X") + " | tbar " + rectangle2.Left + "," + rectangle2.Top + " " + rectangle2.Width + "x" + rectangle2.Height + " | believedOpen " + _invWindowOpen);
				}
				catch
				{
				}
				if (ConfirmPending)
				{
					json.Str("confirmText", _confirmText);
					json.Str("confirmAt", _confirmAt.ToString("o"));
					json.Num("confirmType", _confirmType);
				}
				json.Bool("summon", currentSettings.MelksPetEnabled);
				json.Bool("buff", currentSettings.MelksBufferEnabled);
				json.Bool("debug", currentSettings.DebugLog);
				json.Bool("paused", PluginCore.IsPaused);
				json.Str("pausedBy", PluginCore.PausedByText);
				json.Num("navMode", currentSettings.NavMode);
				json.Str("navRoute", currentSettings.NavRouteSelected ?? "");
				List<string> list = new List<string>();
				foreach (NavRoute navRoute in currentSettings.NavRoutes)
				{
					list.Add(navRoute.Name);
				}
				json.List("navRoutes", list);
				json.Str("navSpot", currentSettings.NavSelected ?? "");
				List<string> list2 = new List<string>();
				foreach (NavSpot navSpot in currentSettings.NavSpots)
				{
					list2.Add(navSpot.Name);
				}
				json.List("navSpots", list2);
				try
				{
					json.Bool("meta", currentEngine.Nav.MetaRunning);
					json.Str("metaName", (currentEngine.Nav.CurrentMeta != null) ? currentEngine.Nav.CurrentMeta.Name : "");
					json.Str("metaState", currentEngine.Nav.MetaRunning ? (currentEngine.Nav.MetaCurState ?? "") : "");
					json.List("metas", currentEngine.Nav.MetaNames());
				}
				catch
				{
				}
				json.Str("engineStatus", currentEngine.Status ?? "");
				json.Str("location", Location(currentEngine));
				try
				{
					json.Str("navStatus", currentEngine.Nav.PhoneStatus());
				}
				catch
				{
				}
				try
				{
					json.Num("killsPerHour", (long)Math.Round(Session.KillsPerHourRecent));
				}
				catch
				{
				}
				try
				{
					if (Session.Packs > 0)
					{
						json.Num("packAvg", (long)Math.Round(Session.PackAvg));
					}
				}
				catch
				{
				}
				try
				{
					json.Num("lumPerHour", (long)LumTrack.EffectiveLumPerHour);   // (the Lum tab's effective lum/hr: by the bank with shares and passup, plus coins as lum - just your own earned when the bank isn't polled)
					json.Num("xpPerHour", (long)Session.XpPerHourRecent);
				}
				catch
				{
				}
			}
			json.Str("lastCommand", _lastCommand);
			if (_capture)
			{
				_captured = json.ToString();
				return;
			}
			WriteLater(Path.Combine(Dir, "status_" + Key(account) + ".json"), json.ToString());
			t = Perf.Lap("  phone: status", t);
			Live(out var live, out var session);
			if (flag)
			{
				WriteChat(account);
			}
			if (!flag || (!(!live | session) && !((DateTime.UtcNow - _sessionWriteUtc).TotalSeconds >= (double)IntervalSeconds)))
			{
				return;
			}
			_sessionWriteUtc = DateTime.UtcNow;
			t = Perf.Lap("  phone: chat", t);
			try
			{
				WriteLater(Path.Combine(Dir, "session_" + Key(account) + ".json"), Session.SessionJson(Safe(() => core.CharacterFilter.Name)));
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
			t = Perf.Lap("  phone: session", t);
			WriteInventory(account);
			t = Perf.Lap("  phone: inventory", t);
		}
		catch (Exception ex2)
		{
			Util.LogError(ex2);
		}
	}

	private static string Location(CombatEngine eng)
	{
		string text = "";
		int num = -1;
		try
		{
			if (BountyTracker.Current != null)
			{
				text = BountyTracker.Current.CurrentZone;
			}
		}
		catch
		{
		}
		if (text.Length == 0)
		{
			try
			{
				Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
				foreach (Assembly assembly in assemblies)
				{
					if (assembly.FullName.StartsWith("MelksBounty,"))
					{
						Type type = assembly.GetType("MelksBounty.PluginCore");
						PropertyInfo propertyInfo = ((type == null) ? null : type.GetProperty("CurrentZone"));
						PropertyInfo propertyInfo2 = ((type == null) ? null : type.GetProperty("CurrentTier"));
						if (propertyInfo != null)
						{
							text = (propertyInfo.GetValue(null, null) as string) ?? "";
						}
						if (propertyInfo2 != null)
						{
							num = (int)propertyInfo2.GetValue(null, null);
						}
						break;
					}
				}
			}
			catch
			{
			}
		}
		try
		{
			if (eng != null && eng.Tier != null && eng.Tier.Tier >= 0)
			{
				num = eng.Tier.Tier;
			}
		}
		catch
		{
		}
		string text2 = text;
		if (text2.Length == 0)
		{
			string areaName = null;
			try
			{
				AreaLink areaLink = eng?.Areas.Find(Areas.CurrentLandblock());
				if (areaLink != null)
				{
					areaName = areaLink.Name;
				}
			}
			catch
			{
			}
			text2 = Locations.Here(areaName);
		}
		try
		{
			Settings currentSettings = PluginCore.CurrentSettings;
			if (currentSettings != null && eng != null && currentSettings.NavSpots != null)
			{
				NavSpot navSpot = null;
				double num2 = double.MaxValue;
				foreach (NavSpot navSpot2 in currentSettings.NavSpots)
				{
					double num3 = eng.Nav.DistanceTo(navSpot2);
					if (num3 >= 0.0 && num3 < num2)
					{
						num2 = num3;
						navSpot = navSpot2;
					}
				}
				if (navSpot != null && num2 <= 10.0)
				{
					text2 = ((text2.Length > 0) ? (text2 + " · ") : "") + "at " + navSpot.Name + ((num2 >= 3.0) ? (" (" + Math.Round(num2) + " m)") : "");
				}
			}
		}
		catch
		{
		}
		if (num >= 11)
		{
			text2 = ((text2.Length > 0) ? (text2 + " · T" + num) : ("T" + num));
			string text3 = Locations.Coords();
			if (text3.Length > 0 && text2.IndexOf(text3, StringComparison.Ordinal) < 0)
			{
				text2 = text2 + " · " + text3;
			}
		}
		return text2;
	}

	private static long CountInventory(string name)
	{
		long num = 0L;
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase) || string.Equals(item.Name, name + "s", StringComparison.OrdinalIgnoreCase))
				{
					num += Math.Max(1, item.Values(LongValueKey.StackCount, 1));
				}
			}
		}
		catch
		{
		}
		return num;
	}

	private static string Safe(Func<object> f)
	{
		try
		{
			object obj = f();
			return (obj == null) ? "" : Convert.ToString(obj, CultureInfo.InvariantCulture);
		}
		catch
		{
			return "";
		}
	}
}
