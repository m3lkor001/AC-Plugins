using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using MelkTank.Metas;
using AcClient;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Bounties;
using MelkTank.Buffs;

namespace MelkTank;

public static partial class Session
{
	// ── Skill Credit Gems (the Ancient Statue of unknown origin, for Enlightened Coins; patch 11-21) ──
	// 1 credit 100 coins, 10x 1,000, 50x 5,000, 100x 10,000 - permanent credits, kept through enlightenment
	private static readonly int[] CreditGemSizes = new int[4] { 100, 50, 10, 1 };
	private const int CoinsPerCredit = 100;
	private static int _creditsWant = 10;
	private static string _creditStatus = "";
	private static List<int> _creditUseQueue;
	private static DateTime _creditUseNext = DateTime.MinValue;

	private static readonly Regex CreditGemRx = new Regex("^(?:(\\d+)x )?Skill Credit Gems?$", RegexOptions.IgnoreCase);

	private static int CreditGemSize(string name)
	{
		Match m = CreditGemRx.Match((name ?? "").Trim());
		if (!m.Success) return 0;
		int n = 1;
		if (m.Groups[1].Success) int.TryParse(m.Groups[1].Value, out n);
		return n;
	}

	private static Dictionary<int, WorldObject> VendorCreditGems()
	{
		Dictionary<int, WorldObject> d = new Dictionary<int, WorldObject>();
		try
		{
			Vendor v = CoreManager.Current.WorldFilter.OpenVendor;
			if (v == null || v.MerchantId == 0) return d;
			foreach (WorldObject o in v)
			{
				int n = CreditGemSize(o.Name);
				if (n > 0 && !d.ContainsKey(n)) d[n] = o;
			}
		}
		catch
		{
		}
		return d;
	}

	// the fewest gems for that many credits (all cost the same per credit)
	private static List<KeyValuePair<int, int>> CreditGemSplit(int credits)
	{
		List<KeyValuePair<int, int>> l = new List<KeyValuePair<int, int>>();
		foreach (int size in CreditGemSizes)
		{
			int k = credits / size;
			if (k > 0) l.Add(new KeyValuePair<int, int>(size, k));
			credits -= k * size;
		}
		return l;
	}

	private static List<WorldObject> CarriedCreditGems()
	{
		List<WorldObject> l = new List<WorldObject>();
		try
		{
			foreach (WorldObject o in CoreManager.Current.WorldFilter.GetInventory())
				if (CreditGemSize(o.Name) > 0) l.Add(o);
		}
		catch
		{
		}
		return l;
	}

	// "You gain 1 skill credit for good: skill credits from gems stay with you through enlightenment." - counted as each
	// gem is used (/aug doesn't list them), kept per character
	private static readonly Regex GemCreditRx = new Regex("^You gain ([\\d,]+) skill credits? for good", RegexOptions.IgnoreCase);
	private static long _gemCredits = -1;

	private static string GemCreditFile => (_augFile == null) ? null : _augFile.Replace("MelkTank_Augs_", "MelkTank_SkillCredits_");

	private static long GemCredits()
	{
		if (_gemCredits >= 0)
		{
			return _gemCredits;
		}
		_gemCredits = 0;
		try
		{
			string f = GemCreditFile;
			if (f != null && File.Exists(f) && long.TryParse(File.ReadAllText(f).Trim(), out var n))
			{
				_gemCredits = n;
			}
		}
		catch
		{
		}
		return _gemCredits;
	}

	/// <summary>/mtank credits N - sets the skill credits bought from gems (ones used before they were counted).</summary>
	public static string SetGemCredits(string arg)
	{
		if (!long.TryParse(arg.Replace(",", ""), out var n) || n < 0)
		{
			return "skill credits bought from gems: " + GemCredits().ToString("N0") + " (/mtank credits N to set it).";
		}
		_gemCredits = n;
		try
		{
			string f = GemCreditFile;
			if (f != null)
			{
				Util.Locked(f, () => File.WriteAllText(f, n.ToString()));
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		return "skill credits bought from gems set to " + n.ToString("N0") + ".";
	}

	private static void GemCreditChat(string text)
	{
		Match m = GemCreditRx.Match(text.Trim());
		if (!m.Success || !long.TryParse(m.Groups[1].Value.Replace(",", ""), out var n))
		{
			return;
		}
		_gemCredits = GemCredits() + n;
		try
		{
			string f = GemCreditFile;
			if (f != null)
			{
				Util.Locked(f, () => File.WriteAllText(f, _gemCredits.ToString()));
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	// the skill credits bought so far: counted from the gems used here (or /aug's line, should it ever list them)
	private static long CreditsBought()
	{
		long counted = GemCredits();
		foreach (KeyValuePair<string, string> aug in _augs)
		{
			if (aug.Key.IndexOf("Skill Credit", StringComparison.OrdinalIgnoreCase) < 0) continue;
			Match m = Regex.Match(aug.Value ?? "", "[\\d,]+");
			if (m.Success && long.TryParse(m.Value.Replace(",", ""), out var n)) return Math.Max(n, counted);
		}
		return counted;
	}

	private static void DrawSkillCredits()
	{
		if (ImGui.Button("Check /aug + /bank##skillcredits"))
		{
			QuietNext("/aug");
			Util.Command("/aug");
			QuietNext("/bank");
			Util.Command("/bank");
		}
		long bought = CreditsBought();
		long lum = BankLuminance();
		long coins = BankCount("Enlightened Coins");
		double coinLum = CoinLum();
		double rate = (LumPerHourRecent > 0.0) ? LumPerHourRecent : LumPerHour;
		try
		{
			double tr = (PluginCore.CurrentSettings == null || PluginCore.CurrentSettings.AugRatesFromTracker) ? TrackerRate() : (-1.0);
			if (tr > 0.0) rate = tr;
		}
		catch
		{
		}
		ImGui.SameLine();
		Im.TextColored(Cyan, "Skill credits bought " + bought.ToString("N0"));
		if (ImGui.IsItemHovered()) Im.SetTooltip("Counted from \"You gain N skill credit for good\" as each gem is used (/aug doesn't list them), kept for this character.\nGems used before this build weren't counted - set the count with /mtank credits N.");
		ImGui.SameLine();
		Im.Text("   Luminance " + ((lum >= 0) ? Big(lum) : "?") + "   Coins " + ((coins >= 0) ? coins.ToString("N0") : "?") + "   1 coin = " + ((coinLum > 0.0) ? Big(coinLum) : "?") + " lum");
		Im.TextDisabled("Skill Credit Gems: the Ancient Statue of unknown origin, " + CoinsPerCredit + " Enlightened Coins a credit. Permanent - kept through every enlightenment.");
		if (ImGui.BeginTable("augcostcredits", 6, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("Gem", ImGuiTableColumnFlags.WidthFixed, 40f);
			ImGui.TableSetupColumn("Credits", ImGuiTableColumnFlags.WidthFixed, 60f);
			ImGui.TableSetupColumn("Coins", ImGuiTableColumnFlags.WidthFixed, 70f);
			ImGui.TableSetupColumn("Coin lum", ImGuiTableColumnFlags.WidthFixed, 150f);
			ImGui.TableSetupColumn("When", ImGuiTableColumnFlags.WidthStretch);
			ImGui.TableSetupColumn("In your pack", ImGuiTableColumnFlags.WidthFixed, 80f);
			ImGui.TableHeadersRow();
			List<WorldObject> carried = CarriedCreditGems();
			foreach (int size in GemSizes)
			{
				long need = (long)size * CoinsPerCredit;
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				ImGui.TextUnformatted(size + "x");
				ImGui.TableSetColumnIndex(1);
				ImGui.TextUnformatted(size.ToString("N0"));
				ImGui.TableSetColumnIndex(2);
				Im.TextColored((coins >= need) ? AugGreen : AugYellow, need.ToString("N0"));
				ImGui.TableSetColumnIndex(3);
				ImGui.TextUnformatted((coinLum > 0.0) ? ((double)need * coinLum).ToString("N0") : "?");
				if (ImGui.IsItemHovered()) Im.SetTooltip(need.ToString("N0") + " coins x " + Big(coinLum) + " lum (Session > Lum's buying rate)");
				ImGui.TableSetColumnIndex(4);
				WhenText(0L, need, lum, coins, coinLum, rate);
				ImGui.TableSetColumnIndex(5);
				List<WorldObject> mine = carried.FindAll((WorldObject o) => CreditGemSize(o.Name) == size);
				if (mine.Count == 0)
				{
					Im.TextDisabled("none");
				}
				else if (ImGui.SmallButton("Use (" + mine.Count + ")##usesc" + size))
				{
					try
					{
						Globals.Core.Actions.UseItem(mine[0].Id, 0);
						Util.WriteToChat("Augs: using " + mine[0].Name + "...");
						_augRecheckAt = DateTime.Now.AddSeconds(2.5);
					}
					catch (Exception ex)
					{
						Util.WriteToChat("Augs: " + ex.Message);
					}
				}
			}
			ImGui.EndTable();
		}
		// the goal: credits bought to reach, what it costs, and buying it at the statue
		Im.Text("Goal credits");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(100f);
		if (!_augGoal.TryGetValue("Skill Credits", out var goalText)) goalText = "";
		if (ImGui.InputText("##goalcredits", ref goalText, 12u, ImGuiInputTextFlags.CharsDecimal)) _augGoal["Skill Credits"] = goalText;
		if (long.TryParse(goalText.Replace(",", ""), out var goal) && goal > 0)
		{
			ImGui.SameLine();
			if (goal <= bought)
			{
				Im.TextDisabled("already there");
			}
			else
			{
				long more = goal - bought;
				long cost = more * CoinsPerCredit;
				Im.Text("+" + more.ToString("N0") + " credits: " + cost.ToString("N0") + " coins" + ((coinLum > 0.0) ? (" = " + Big(cost * coinLum) + " lum") : "") + "   ");
				ImGui.SameLine();
				WhenText(0L, cost, lum, coins, coinLum, rate);
				List<KeyValuePair<int, int>> split = CreditGemSplit((int)Math.Min(more, 1000000L));
				Dictionary<int, WorldObject> sold = VendorCreditGems();
				bool open = sold.Count > 0, enough = coins < 0 || coins >= cost;
				ImGui.SameLine();
				if (!open || !enough) ImGui.BeginDisabled();
				if (ImGui.SmallButton("Buy##scbuy"))
				{
					try
					{
						HooksWrapper actions = CoreManager.Current.Actions;
						actions.VendorClearBuyList();
						foreach (KeyValuePair<int, int> x in split)
							if (sold.TryGetValue(x.Key, out var g)) actions.VendorAddBuyList(g.Id, x.Value);
						actions.VendorBuyAll();
						_creditStatus = "asked to buy " + string.Join(", ", split.ConvertAll((KeyValuePair<int, int> x) => x.Value + " x " + x.Key + "x").ToArray());
						_bankRecheckAt = DateTime.Now.AddSeconds(2.0);
					}
					catch (Exception ex)
					{
						_creditStatus = "buy failed: " + ex.Message;
					}
				}
				if (!open || !enough) ImGui.EndDisabled();
				if (ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenDisabled))
					Im.SetTooltip((!open ? "Open the Ancient Statue of unknown origin's shop first.\n" : (!enough ? "Not enough Enlightened Coins banked.\n" : "")) + "Buys " + string.Join(", ", split.ConvertAll((KeyValuePair<int, int> x) => x.Value + " x " + x.Key + "x gem").ToArray()) + " (the fewest gems for that many credits).");
			}
		}
		if (_creditStatus.Length > 0) Im.TextDisabled(_creditStatus);
		Im.TextDisabled("No soft caps known for this one. Specialized Skill Aug Gems no longer give skill credits.");
	}

	// one gem used a second, until the queue's done (a stack: the same gem again while some are left)
	private static void CreditUseTick()
	{
		if (_creditUseQueue == null || _creditUseQueue.Count == 0 || DateTime.Now < _creditUseNext) return;
		int id = _creditUseQueue[0];
		_creditUseQueue.RemoveAt(0);
		_creditUseNext = DateTime.Now.AddSeconds(1.0);
		try
		{
			WorldObject o = CoreManager.Current.WorldFilter[id];
			if (o == null)
			{
				_creditUseQueue.RemoveAll((int x) => x == id);
				return;
			}
			CoreManager.Current.Actions.UseItem(id, 0);
			if (_creditUseQueue.Count == 0) _creditStatus = "used the gems";
		}
		catch (Exception ex)
		{
			_creditUseQueue.Clear();
			_creditStatus = "use failed: " + ex.Message;
		}
	}
}
