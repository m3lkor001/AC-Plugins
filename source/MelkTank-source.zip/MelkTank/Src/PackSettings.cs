using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Xml;

namespace MelkTank;

public static class PackSettings
{
	private static readonly HashSet<string> Skip = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
	{
		"MasterEnabled", "CombatEnabled", "NavEnabled", "LootEnabled", "DebugLog", "MetaRun", "MetaLast", "NavSelected", "NavRouteSelected", "CalibObservedMinutes",
		"CalibBaseMinutes", "DebuffMultiplier", "Charms", "HealKitId", "HealKitName", "ManaItemId", "ManaItemName", "StaminaItemId", "StaminaItemName", "HoverItemType",
		"FellowName", "LoginWindows", "MaxHealthLowTier", "MaxHealthHighTier", "DurationAugs", "FollowName"
	};

	private static string _forChar;

	private static readonly Dictionary<string, int> _byKey = new Dictionary<string, int>();

	private static readonly Dictionary<int, SortedDictionary<string, string>> _sets = new Dictionary<int, SortedDictionary<string, string>>();

	private static int _max;

	private static int _lastUsed;

	private static string _lastKey;

	private static DateTime _lastAt = DateTime.MinValue;

	private static string FilePath => Util.FullPath("MelkTank_PackSettings_" + CharPart() + ".txt");

	private static string CharPart() => Util.CharFilePart();

	private static SortedDictionary<string, string> Now()
	{
		SortedDictionary<string, string> sortedDictionary = new SortedDictionary<string, string>(StringComparer.Ordinal);
		sortedDictionary["Build"] = "b" + BuildInfo.Number;
		Settings currentSettings = PluginCore.CurrentSettings;
		if (currentSettings != null)
		{
			XmlElement xmlElement = currentSettings.BuildCharacterNow(new XmlDocument());
			foreach (XmlNode childNode in xmlElement.ChildNodes)
			{
				if (!(childNode is XmlElement xmlElement2) || Skip.Contains(xmlElement2.Name))
				{
					continue;
				}
				if (xmlElement2.Name == "Monsters")
				{
					sortedDictionary["MonsterList"] = Short(xmlElement2.OuterXml);
					continue;
				}
				bool flag = true;
				foreach (XmlNode childNode2 in xmlElement2.ChildNodes)
				{
					if (childNode2 is XmlElement)
					{
						flag = false;
						break;
					}
				}
				if (flag)
				{
					sortedDictionary[xmlElement2.Name] = Norm(xmlElement2.InnerText);
				}
			}
			sortedDictionary["MonsterProfile"] = ((currentSettings.ActiveProfile.Length > 0) ? currentSettings.ActiveProfile : "(own list)");
		}
		foreach (Tuning.Entry item in Tuning.All)
		{
			sortedDictionary["T." + item.Key] = item.Value.ToString("R", CultureInfo.InvariantCulture);
		}
		return sortedDictionary;
	}

	private static string Norm(string v)
	{
		return (v ?? "").Replace("\r", " ").Replace("\n", " ").Replace("; ", ";");
	}

	private static string Short(string text)
	{
		uint num = 2166136261u;
		foreach (char c in text)
		{
			num ^= c;
			num *= 16777619;
		}
		return num.ToString("x8");
	}

	private static string Key(SortedDictionary<string, string> d)
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (KeyValuePair<string, string> item in d)
		{
			stringBuilder.Append(item.Key).Append('=').Append(item.Value)
				.Append("; ");
		}
		return stringBuilder.ToString().TrimEnd(new char[2] { ' ', ';' });
	}

	private static void Load()
	{
		string text = CharPart();
		if (_forChar == text)
		{
			return;
		}
		_forChar = text;
		_byKey.Clear();
		_sets.Clear();
		_max = 0;
		_lastUsed = 0;
		_lastKey = null;
		try
		{
			string filePath = FilePath;
			if (!File.Exists(filePath))
			{
				return;
			}
			string[] array = File.ReadAllLines(filePath);
			foreach (string text2 in array)
			{
				if (!text2.StartsWith("SET ", StringComparison.Ordinal))
				{
					continue;
				}
				int num = text2.IndexOf(' ', 4);
				if (num < 0 || !int.TryParse(text2.Substring(4, num - 4), out var result))
				{
					continue;
				}
				int num2 = text2.IndexOf("  ", num + 2 + 16, StringComparison.Ordinal);
				if (num2 < 0)
				{
					continue;
				}
				string text3 = text2.Substring(num2 + 2);
				_byKey[text3] = result;
				SortedDictionary<string, string> sortedDictionary = new SortedDictionary<string, string>(StringComparer.Ordinal);
				string[] array2 = text3.Split(new string[1] { "; " }, StringSplitOptions.None);
				foreach (string text4 in array2)
				{
					int num3 = text4.IndexOf('=');
					if (num3 > 0)
					{
						sortedDictionary[text4.Substring(0, num3)] = text4.Substring(num3 + 1);
					}
				}
				_sets[result] = sortedDictionary;
				if (result > _max)
				{
					_max = result;
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static int _ver, _keyVer = -1;

	private static DateTime _keyAt = DateTime.MinValue;

	private static string _keyChar;

	/// <summary>The settings were saved (so may be different): the next pack works its set out again.</summary>
	public static void SettingsSaved()
	{
		_ver++;
	}

	public static int Current(Action<string> packsLog)
	{
		try
		{
			Load();
			// Writing out every setting to compare took ~100 ms - once at the end of each fight, a hitch as looting
			// starts. The settings only change when they're saved, so the set is worked out again only after a save.
			if (_lastUsed > 0 && _keyVer == _ver && _keyChar == _forChar)
			{
				return _lastUsed;
			}
			// (and not more than every 10 minutes even then: settings are saved often - a pet turned on, a window moved - and
			// working the set out took 100-300 ms each time, a freeze at the end of nearly every fight)
			if (_lastUsed > 0 && _keyChar == _forChar && DateTime.Now - _keyAt < TimeSpan.FromMinutes(10.0))
			{
				return _lastUsed;
			}
			_keyAt = DateTime.Now;
			_keyVer = _ver;
			_keyChar = _forChar;
			SortedDictionary<string, string> sortedDictionary = Now();
			string text = Key(sortedDictionary);
			if (text == _lastKey && _lastUsed > 0)
			{
				return _lastUsed;
			}
			bool flag = !_byKey.TryGetValue(text, out var value);
			if (flag)
			{
				value = ++_max;
				_byKey[text] = value;
				_sets[value] = sortedDictionary;
				string filePath = FilePath;
				Util.AppendShared(filePath, "SET " + value + "  " + DateTime.Now.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture) + "  " + text + Environment.NewLine);
			}
			if (_lastUsed != value && packsLog != null)
			{
				string text2 = ((_lastUsed <= 0 || !_sets.TryGetValue(_lastUsed, out var value2)) ? ("(first set this session" + (flag ? ", new" : "") + ")") : Diff(value2, sortedDictionary));
				packsLog(DateTime.Now.ToString("HH:mm:ss", CultureInfo.InvariantCulture) + "  ----- set " + value + (flag ? " (new)" : " (used before)") + ((_lastUsed > 0) ? (" - from set " + _lastUsed + ": ") : ": ") + text2);
			}
			_lastUsed = value;
			_lastKey = text;
			return value;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			return 0;
		}
	}

	private static string Diff(SortedDictionary<string, string> a, SortedDictionary<string, string> b)
	{
		List<string> list = new List<string>();
		foreach (KeyValuePair<string, string> item in b)
		{
			if (!a.TryGetValue(item.Key, out var value))
			{
				list.Add(item.Key + " " + item.Value + " (new)");
			}
			else if (value != item.Value)
			{
				list.Add(item.Key + " " + Clip(value) + " -> " + Clip(item.Value));
			}
		}
		foreach (string key in a.Keys)
		{
			if (!b.ContainsKey(key))
			{
				list.Add(key + " (gone)");
			}
		}
		return (list.Count == 0) ? "no change" : string.Join(", ", list.ToArray());
	}

	private static string Clip(string v)
	{
		string result;
		if (v.Length != 0)
		{
			result = ((v.Length > 30) ? (v.Substring(0, 27) + "...") : v);
		}
		else
		{
			result = "(blank)";
		}
		return result;
	}
}
