using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
#if !RETAIL
using ACGodot.DecalShim;
using ACGodot.Plugins;
using ACGodot.UI;
#endif
#if !RETAIL
using AcClient;
#else
using SmartBox = AcClient.SmartBox;
using ACCmdInterp = AcClient.ACCmdInterp;
using CommandInterpreter = AcClient.CommandInterpreter;
using CommandListElement = AcClient.CommandListElement;
using CPhysicsObj = AcClient.CPhysicsObj;
using Position = AcClient.Position;
using CTransition = AcClient.CTransition;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
#if !RETAIL
using Godot;
#endif
using ImGuiNET;
using MelkTank.Loot;
using MelkTank.Metas;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public partial class Nav
{
	private bool DrawRoute()
	{
		bool flag = false;
		NavRoute navRoute = CurrentRoute;
		List<string> list = new List<string>();
		foreach (NavRoute navRoute3 in _s.NavRoutes)
		{
			list.Add(navRoute3.Name);
		}
		int num = list.FindIndex((string n) => string.Equals(n, _s.NavRouteSelected, StringComparison.OrdinalIgnoreCase));
		string[] array = ((list.Count != 0) ? list.ToArray() : new string[1] { "(no routes yet)" });
		int current_item = ((num >= 0) ? num : 0);
		bool flag2 = IsMetaRoute(navRoute);
		ImGui.SetNextItemWidth(220f);
		if (flag2)
		{
			if (ImGui.BeginCombo("Route##navroute", navRoute.Name))
			{
				for (int num2 = 0; num2 < list.Count; num2++)
				{
					if (ImGui.Selectable(list[num2] + "##rn" + num2))
					{
						_s.NavRouteSelected = list[num2];
						Stop();
						RouteReset();
						_rSel = -1;
						flag = true;
					}
				}
				ImGui.EndCombo();
			}
			navRoute = CurrentRoute;
			flag2 = IsMetaRoute(navRoute);
		}
		else if (ImGui.Combo("Route##navroute", ref current_item, array, array.Length) && list.Count > 0)
		{
			_s.NavRouteSelected = list[current_item];
			Stop();
			RouteReset();
			_rSel = -1;
			flag = true;
			navRoute = CurrentRoute;
		}
		if (flag2)
		{
			ImGui.SameLine();
			Im.TextColored(Yellow, "loaded by meta " + ((_meta != null) ? _meta.Name : "?"));
			ImGui.SameLine();
			if (ImGui.SmallButton("Update the meta's route##rmetaupd"))
			{
				UpdateMetaRoute();
			}
			Tip("Puts this route, with your changes, back into the meta (saved straight away for a .mtmet).\nChanges here aren't kept anywhere else.");
			ImGui.SameLine();
			if (ImGui.SmallButton("Copy to my routes##rmetacopy"))
			{
				NavRoute c = EmbeddedMtRoute(Meta.Enc.GetBytes("x\r\n0\r\n" + RouteXml(navRoute)));
				if (c != null)
				{
					string text = (navRoute.Name.StartsWith("[meta] ", StringComparison.Ordinal) ? navRoute.Name.Substring(7) : navRoute.Name);
					c.Name = text;
					c.File = "";
					int num3 = 2;
					while (_s.NavRoutes.Exists((NavRoute x) => string.Equals(x.Name, c.Name, StringComparison.OrdinalIgnoreCase)))
					{
						c.Name = text + " (" + num3++ + ")";
					}
					_s.NavRoutes.Add(c);
					flag = true;
					Util.WriteToChat("Nav: " + c.Name + " added to your routes.");
				}
			}
		}
		ImGui.SameLine();
		if (navRoute != null && !flag2 && ImGui.Button("Delete##rdel"))
		{
			_s.NavRoutes.Remove(navRoute);
			_s.NavRouteSelected = ((_s.NavRoutes.Count > 0) ? _s.NavRoutes[0].Name : "");
			Stop();
			RouteReset();
			flag = true;
			navRoute = CurrentRoute;
		}
		ImGui.SetNextItemWidth(220f);
		ImGui.InputText("Name##rname", ref _rNewName, 64u);
		ImGui.SameLine();
		if (ImGui.Button("New route") && _rNewName.Trim().Length > 0)
		{
			NavRoute navRoute2 = new NavRoute
			{
				Name = _rNewName.Trim()
			};
			_s.NavRoutes.Add(navRoute2);
			_s.NavRouteSelected = navRoute2.Name;
			_rNewName = "";
			_rSel = -1;
			RouteReset();
			flag = true;
			navRoute = navRoute2;
		}
		if (navRoute != null)
		{
			ImGui.SameLine();
			if (ImGui.Button("Rename##rren") && _rNewName.Trim().Length > 0)
			{
				navRoute.Name = _rNewName.Trim();
				_s.NavRouteSelected = navRoute.Name;
				_rNewName = "";
				flag = true;
			}
		}
		if (navRoute == null)
		{
			Im.TextColored(Grey, "Type a name and click New route - or load a file on the Settings tab.");
			return flag;
		}
		ImGui.Separator();
		ImGui.SetNextItemWidth(220f);
		if (ImGui.Combo("Repeat##rmode", ref navRoute.Mode, RouteModes, RouteModes.Length))
		{
			flag = true;
		}
		Tip("Once: walk it once, then stop - nav does nothing more until another route is loaded or it is started again.\nBack and forth: to the end, then back to the start of the repeating part, and so on.\nRound and round: from the end straight back to the start of the repeating part.\n\nSteps above a 'Loop starts here' step are done only once - e.g. run from town and take a portal,\nthen circle the hunting area. With no loop step, the whole route repeats.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(100f);
		flag |= ImGui.InputFloat("point size (m)##rarr", ref navRoute.Arrive, 0.5f, 1f, "%.1f");
		if (navRoute.Arrive < 0.5f)
		{
			navRoute.Arrive = 0.5f;
		}
		Tip("How close counts as reaching a point (the ring drawn on the point is this size). This route only.\nSmall (0.5 - 1 m) for tight spots: doorways, ledges, standing on an exact spot. Bigger (3 - 5 m) for open hunting\nroutes - less stopping and turning.\nA meta's route: click 'Update the meta's route' to keep the change.");
		ImGui.SetNextItemWidth(220f);
		if (ImGui.Combo("When stuck##rstuck", ref navRoute.StuckAction, StuckActions, StuckActions.Length))
		{
			flag = true;
		}
		Tip("What to do when the way to a point is blocked (monsters in the way, a wall) - normally it waits 30 s and tries again:\n  Turn combat on - fight what's in the way; combat goes off again once the point is reached\n    (unless a Switch step turns it on or off first)\n  Back up and try again - walk back over the last few points, then come forward again\n  Start the route over - from step 1\n  Skip that point - on to the next step");
		if (navRoute.StuckAction == 2)
		{
			ImGui.SameLine();
			ImGui.SetNextItemWidth(90f);
			if (ImGui.InputInt("points##rstuckback", ref navRoute.StuckBack, 1, 1))
			{
				flag = true;
			}
			if (navRoute.StuckBack < 1)
			{
				navRoute.StuckBack = 1;
			}
			if (navRoute.StuckBack > 20)
			{
				navRoute.StuckBack = 20;
			}
		}
		if (navRoute.StuckAction != 0)
		{
			ImGui.SameLine();
			ImGui.SetNextItemWidth(90f);
			if (ImGui.InputInt("after tries##rstuckafter", ref navRoute.StuckAfter, 1, 1))
			{
				flag = true;
			}
			if (navRoute.StuckAfter < 1)
			{
				navRoute.StuckAfter = 1;
			}
			if (navRoute.StuckAfter > 10)
			{
				navRoute.StuckAfter = 10;
			}
			Tip("How many times in a row it can't get to the same point before doing this (each try is about 5 s of no progress + 30 s wait).");
		}
		if (ImGui.Checkbox("Start over from step 1 when stuck on a step for##rstuckmin", ref navRoute.RestartIfStuck))
		{
			flag = true;
		}
		Tip("When the route hasn't got past the step it's on for this many minutes (whatever held it - a wall, a monster it\ncan't reach, a door), it starts again from step 1. Time in portal space or dead doesn't count.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(100f);
		flag |= ImGui.InputFloat("min##rstuckm", ref navRoute.RestartStuckMin, 1f, 5f, "%.0f");
		if (navRoute.RestartStuckMin < 1f)
		{
			navRoute.RestartStuckMin = 1f;
		}
		if (_rStuckAcc > 30.0 && navRoute.RestartIfStuck)
		{
			ImGui.SameLine();
			Im.TextColored(Grey, "(on this step " + (int)(_rStuckAcc / 60.0) + "m" + ((int)_rStuckAcc % 60).ToString("00") + "s)");
		}
		float cursorPosX = ImGui.GetCursorPosX();
		if (ImGui.Checkbox("Start over from step 1 when further than##rfar", ref navRoute.RestartIfFar))
		{
			flag = true;
		}
		Tip("When the next point is further away than this (you portalled, recalled or died somewhere else),\nthe route starts again from step 1 - so put the gem / recall that gets you there first.\nAt most once a minute; if step 1's point is far too, it waits as usual.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(100f);
		flag |= ImGui.InputFloat("m##rfarm", ref navRoute.RestartFarM, 10f, 50f, "%.0f");
		if (navRoute.RestartFarM < 10f)
		{
			navRoute.RestartFarM = 10f;
		}
		ImGui.SameLine(cursorPosX + 606f + ImGui.GetStyle().ItemSpacing.X);
		if (AddButton("Pop-out tools##rtools"))
		{
			ToggleTools();
		}
		Tip("A small window with Add point here, Record, Add portal / NPC, Add wait and Add preset - to build the route while you\nwalk it (the main window can be closed). Steps go after the selected step, or at the end.");
		if (_rEdit != null && !navRoute.Steps.Contains(_rEdit))
		{
			_rEdit = null;
		}
		ImGui.Separator();
		int num4 = -1;
		int num5 = -1;
		int num6 = -1;
		if (ImGui.BeginTable("routesteps", 5, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY, new System.Numerics.Vector2(606f, Math.Max(300f, _rAddH))))
		{
			ImGui.TableSetupColumn("#", ImGuiTableColumnFlags.WidthFixed, 30f);
			ImGui.TableSetupColumn("Step", ImGuiTableColumnFlags.WidthFixed, 80f);
			ImGui.TableSetupColumn("Detail", ImGuiTableColumnFlags.WidthFixed, 330f);
			ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 60f);
			ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 26f);
			ImGui.TableSetupScrollFreeze(0, 1);
			ImGui.TableHeadersRow();
			bool flag3 = navRoute.Steps.Count != _rLastCount && _rLastCount >= 0;
			_rLastCount = navRoute.Steps.Count;
			int num7;
			if (flag3)
			{
				num7 = ((_rSel >= 0 && _rSel < navRoute.Steps.Count) ? Math.Min(_rSel + 1, navRoute.Steps.Count - 1) : (navRoute.Steps.Count - 1));
			}
			else
			{
				num7 = -1;
			}
			float frameHeight = ImGui.GetFrameHeight();
			for (int num8 = 0; num8 < navRoute.Steps.Count; num8++)
			{
				RouteStep routeStep = navRoute.Steps[num8];
				ImGui.TableNextRow(ImGuiTableRowFlags.None, frameHeight);
				ImGui.TableSetColumnIndex(0);
				if (num8 != num7 && !ImGui.IsRectVisible(new System.Numerics.Vector2(1f, frameHeight)) && (routeStep.Kind != StepKind.Preset || _presetClosed.Contains(routeStep)))
				{
					continue;
				}
				if (num8 == num7)
				{
					ImGui.SetScrollHereY(0.5f);
				}
				ImGui.PushID(num8);
				bool flag4 = _s.NavEnabled && num8 == _rIdx && !_rDone;
				ImGui.TableSetColumnIndex(0);
				Im.TextColored(flag4 ? Green : Grey, (flag4 ? ">" : "") + (num8 + 1));
				ImGui.TableSetColumnIndex(1);
				string text2;
				if (routeStep.Kind != StepKind.Point)
				{
					if (routeStep.Kind == StepKind.Command)
					{
						text2 = "Command";
					}
					else if (routeStep.Kind == StepKind.Use)
					{
						text2 = "Use";
					}
					else if (routeStep.Kind == StepKind.Wait)
					{
						text2 = "Wait";
					}
					else if (routeStep.Kind == StepKind.Toggle)
					{
						text2 = "Switch";
					}
					else if (routeStep.Kind == StepKind.Cast)
					{
						text2 = "Cast";
					}
					else if (routeStep.Kind == StepKind.ChatWait)
					{
						text2 = "Chat wait";
					}
					else if (routeStep.Kind == StepKind.ItemCheck)
					{
						text2 = "Item check";
					}
					else if (routeStep.Kind == StepKind.LoopEnd)
					{
						text2 = "Loop end";
					}
					else if (routeStep.Kind == StepKind.GoRoute)
					{
						text2 = "Go to route";
					}
					else if (routeStep.Kind == StepKind.UseItem)
					{
						text2 = "Use item";
					}
					else if (routeStep.Kind == StepKind.Preset)
					{
						text2 = "Preset";
					}
					else if (routeStep.Kind == StepKind.Vendor)
					{
						text2 = "Vendor";
					}
					else
					{
						text2 = ((routeStep.Kind == StepKind.PlayerSkip) ? "Player skip" : "Loop");
					}
				}
				else
				{
					text2 = "Point";
				}
				if (ImGui.Selectable(text2 + "##rs", _rSel == num8, ImGuiSelectableFlags.SpanAllColumns | ImGuiSelectableFlags.AllowOverlap))
				{
					_rSel = ((_rSel == num8) ? (-1) : num8);
				}
				if (ImGui.IsItemClicked(ImGuiMouseButton.Right))
				{
					_rIdx = num8;
					_rSubFor = -1;
					_rDone = false;
					_rStarted = false;
					_rUntil = DateTime.MinValue;
					Stop();
				}
				Tip("Left click: select (new steps go after it). Right click: go to this step now.");
				ImGui.TableSetColumnIndex(2);
				if (routeStep.Kind == StepKind.Preset)
				{
					bool flag5 = !_presetClosed.Contains(routeStep);
					if (ImGui.SmallButton((flag5 ? "-" : "+") + "##rpo"))
					{
						if (flag5)
						{
							_presetClosed.Add(routeStep);
						}
						else
						{
							_presetClosed.Remove(routeStep);
						}
					}
					Tip(flag5 ? "Hide the preset's steps" : "Show the preset's steps");
					ImGui.SameLine();
				}
				System.Numerics.Vector4 col;
				if (routeStep == _rEdit)
				{
					col = Yellow;
				}
				else if (routeStep.Kind == StepKind.LoopStart || routeStep.Kind == StepKind.LoopEnd)
				{
					col = Cyan;
				}
				else if (routeStep.Kind == StepKind.Preset)
				{
					col = Purple;
				}
				else
				{
					col = (flag4 ? Green : System.Numerics.Vector4.One);
				}
				Im.TextColored(col, ((routeStep == _rEdit) ? "(editing) " : "") + Describe(routeStep));
				ImGui.TableSetColumnIndex(3);
				if (num8 > 0)
				{
					if (Im.UpButton("##rup"))
					{
						num4 = num8;
					}
					ImGui.SameLine();
				}
				if (num8 < navRoute.Steps.Count - 1 && Im.DownButton("##rdn"))
				{
					num5 = num8;
				}
				ImGui.TableSetColumnIndex(4);
				if (ImGui.SmallButton("x"))
				{
					num6 = num8;
				}
				ImGui.PopID();
				if (routeStep.Kind == StepKind.Preset && !_presetClosed.Contains(routeStep))
				{
					DrawPresetSubRows(routeStep, num8, flag4);
				}
			}
			ImGui.EndTable();
		}
		ImGui.SameLine();
		ImGui.BeginGroup();
		flag |= DrawAddRows(navRoute);
		ImGui.EndGroup();
		_rAddH = ImGui.GetItemRectSize().Y;
		if (num4 > 0 || num5 >= 0)
		{
			RouteStep routeStep2 = ((_rSel >= 0 && _rSel < navRoute.Steps.Count) ? navRoute.Steps[_rSel] : null);
			Im.Move(navRoute.Steps, (num4 > 0) ? num4 : num5, num4 > 0);
			if (routeStep2 != null)
			{
				_rSel = navRoute.Steps.IndexOf(routeStep2);
			}
			flag = true;
		}
		if (num6 >= 0)
		{
			if (navRoute.Steps[num6] == _rEdit)
			{
				_rEdit = null;
			}
			navRoute.Steps.RemoveAt(num6);
			if (_rSel >= navRoute.Steps.Count)
			{
				_rSel = navRoute.Steps.Count - 1;
			}
			if (_rIdx >= navRoute.Steps.Count)
			{
				_rIdx = 0;
			}
			flag = true;
		}
		if (_rSel >= 0 && _rSel < navRoute.Steps.Count && navRoute.Steps[_rSel].Kind == StepKind.LoopEnd)
		{
			flag |= DrawLoopEnd(navRoute, navRoute.Steps[_rSel]);
		}
		ImGui.Separator();
		bool v = _s.NavEnabled;
		if (ImGui.Checkbox("Follow this route", ref v))
		{
			_s.NavEnabled = v;
			if (!v)
			{
				Stop();
			}
			flag = true;
		}
		Tip("Walks the route whenever there's nothing to fight or loot (fights and looting pause it; it carries on from the same step).");
		ImGui.SameLine();
		if (ImGui.Button("Start from step 1"))
		{
			Stop();
			RouteReset();
		}
		ImGui.SameLine();
		if (ImGui.Button("Start at the nearest point"))
		{
			int num9 = NearestPoint(navRoute, this, out var dist);
			if (num9 < 0)
			{
				Util.WriteToChat("Nav: this route has no points.");
			}
			else
			{
				Stop();
				RouteReset();
				_rIdx = num9;
				_rName = navRoute.Name;
				Util.WriteToChat("Nav: starting " + navRoute.Name + " at step " + (num9 + 1) + " (" + dist.ToString("0") + " m away).");
			}
		}
		Tip("Goes to the route's point closest to you and carries on from there.");
		ImGui.SameLine();
		if (_s.NavEnabled)
		{
			Im.TextColored(_rDone ? Grey : Yellow, _rDone ? "Finished" : ("Step " + (_rIdx + 1) + ((Status.Length > 0) ? (" - " + Status) : "")));
		}
		return flag;
	}
}
