using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
#if !RETAIL
using ACGodot.DecalShim;
using ACGodot.Plugins;
using ACGodot.UI;
#endif
#if !RETAIL
using AcClient;
#else
using SmartBox = AcClient.SmartBox;
using ACCmdInterp = AcClient.ACCmdInterp;
using CommandInterpreter = AcClient.CommandInterpreter;
using CommandListElement = AcClient.CommandListElement;
using CPhysicsObj = AcClient.CPhysicsObj;
using Position = AcClient.Position;
using CTransition = AcClient.CTransition;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
#if !RETAIL
using Godot;
#endif
using ImGuiNET;
using MelkTank.Loot;
using MelkTank.Metas;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public partial class Nav
{
	private static string HotChar()
	{
		try
		{
			CharacterFilter characterFilter = CoreManager.Current.CharacterFilter;
			return characterFilter.Server + "/" + characterFilter.Name;
		}
		catch
		{
			return "";
		}
	}

	private void SaveHotState()
	{
		try
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["char"] = HotChar();
			dictionary["at"] = DateTime.UtcNow.Ticks.ToString(HCI);
			if (_meta != null && !string.IsNullOrEmpty(_meta.File))
			{
				dictionary["metaFile"] = _meta.File;
				dictionary["state"] = _mState ?? "";
				dictionary["stateAge"] = (DateTime.Now - _mStateAt).TotalSeconds.ToString("R", HCI);
				dictionary["persistAge"] = (DateTime.Now - _mStatePersistAt).TotalSeconds.ToString("R", HCI);
				List<string> list = new List<string>();
				for (int i = 0; i < _meta.Rules.Count; i++)
				{
					if (_mFired.Contains(_meta.Rules[i]))
					{
						list.Add(i.ToString(HCI));
					}
				}
				dictionary["fired"] = string.Join(",", list.ToArray());
				dictionary["calls"] = string.Join("\n", _mCalls.ToArray());
				List<string> list2 = new List<string>();
				foreach (KeyValuePair<string, string> mOpt in _mOpts)
				{
					list2.Add(Uri.EscapeDataString(mOpt.Key) + "=" + Uri.EscapeDataString(mOpt.Value ?? ""));
				}
				dictionary["opts"] = string.Join("&", list2.ToArray());
				if (_wdOn)
				{
					dictionary["wdState"] = _wdState ?? "";
					dictionary["wdDist"] = _wdDist.ToString("R", HCI);
					dictionary["wdSecs"] = _wdSecs.ToString("R", HCI);
				}
			}
			if (_metaRoute != null)
			{
				dictionary["metaRoute"] = RouteXml(_metaRoute);
				dictionary["metaRouteName"] = _metaRoute.Name ?? "";
				dictionary["metaRouteMode"] = _metaRoute.Mode.ToString(HCI);
			}
			dictionary["rName"] = _rName ?? "";
			dictionary["rIdx"] = _rIdx.ToString(HCI);
			dictionary["rDir"] = _rDir.ToString(HCI);
			dictionary["rDone"] = (_rDone ? "1" : "0");
			dictionary["rStarted"] = (_rStarted ? "1" : "0");
			dictionary["rSub"] = _rSub.ToString(HCI);
			dictionary["rSubFor"] = _rSubFor.ToString(HCI);
			AppDomain.CurrentDomain.SetData("MelkTank.NavHotCarry", dictionary);
			L("hot carry: meta " + (dictionary.ContainsKey("metaFile") ? (_meta.Name + " in " + _mState) : "-") + ", route " + _rName + " step " + (_rIdx + 1));
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void RestoreHotState()
	{
		if (_hotTried)
		{
			return;
		}
		Dictionary<string, string> dictionary;
		try
		{
			dictionary = AppDomain.CurrentDomain.GetData("MelkTank.NavHotCarry") as Dictionary<string, string>;
		}
		catch
		{
			_hotTried = true;
			return;
		}
		if (dictionary == null)
		{
			_hotTried = true;
			return;
		}
		string text = HotChar();
		if (text.Length < 2 || text == "/")
		{
			return;
		}
		_hotTried = true;
		AppDomain.CurrentDomain.SetData("MelkTank.NavHotCarry", null);
		try
		{
			if (!dictionary.TryGetValue("char", out var value) || value != text || !dictionary.TryGetValue("at", out value) || !long.TryParse(value, NumberStyles.Integer, HCI, out var result) || (DateTime.UtcNow - new DateTime(result, DateTimeKind.Utc)).TotalMinutes > 10.0)
			{
				return;
			}
			_metaTriedLast = true;
			List<string> list = new List<string>();
			if (dictionary.TryGetValue("metaFile", out var value2) && File.Exists(value2))
			{
				if (_meta == null || !string.Equals(_meta.File, value2, StringComparison.OrdinalIgnoreCase))
				{
					OpenMeta(value2);
				}
				if (_meta != null)
				{
					string text2 = (dictionary.ContainsKey("state") ? dictionary["state"] : "Default");
					_mMeta = _meta;
					_mState = text2;
					_mStateAt = DateTime.Now.AddSeconds(0.0 - Num(dictionary, "stateAge"));
					_mStatePersistAt = DateTime.Now.AddSeconds(0.0 - Num(dictionary, "persistAge"));
					_mFired.Clear();
					_mChat.Clear();
					if (dictionary.TryGetValue("fired", out value))
					{
						string[] array = value.Split(new char[1] { ',' }, StringSplitOptions.RemoveEmptyEntries);
						foreach (string s in array)
						{
							if (int.TryParse(s, NumberStyles.Integer, HCI, out var result2) && result2 >= 0 && result2 < _meta.Rules.Count)
							{
								_mFired.Add(_meta.Rules[result2]);
							}
						}
					}
					_mCalls.Clear();
					if (dictionary.TryGetValue("calls", out value) && value.Length > 0)
					{
						string[] array2 = value.Split('\n');
						for (int num = array2.Length - 1; num >= 0; num--)
						{
							_mCalls.Push(array2[num]);
						}
					}
					_mOpts.Clear();
					if (dictionary.TryGetValue("opts", out value))
					{
						string[] array3 = value.Split(new char[1] { '&' }, StringSplitOptions.RemoveEmptyEntries);
						foreach (string text3 in array3)
						{
							int num2 = text3.IndexOf('=');
							if (num2 > 0)
							{
								_mOpts[Uri.UnescapeDataString(text3.Substring(0, num2))] = Uri.UnescapeDataString(text3.Substring(num2 + 1));
							}
						}
					}
					_mDied = (_mPortalIn = (_mPortalOut = false));
					_mVendorSeen = VendorOpen();
					_wdOn = false;
					if (dictionary.TryGetValue("wdState", out value) && MyPos(out var ns, out var ew, out var _))
					{
						_wdState = value;
						_wdDist = Num(dictionary, "wdDist");
						_wdSecs = Num(dictionary, "wdSecs");
						_wdNS = ns;
						_wdEW = ew;
						_wdAt = DateTime.Now;
						_wdOn = true;
					}
					MLog("carried over from the last build: state " + text2);
					list.Add("meta " + _meta.Name + " in state " + text2);
				}
			}
			if (dictionary.TryGetValue("metaRoute", out value) && value.Length > 0)
			{
				NavRoute navRoute = EmbeddedMtRoute(Meta.Enc.GetBytes(value));
				if (navRoute != null)
				{
					navRoute.Name = (dictionary.ContainsKey("metaRouteName") ? dictionary["metaRouteName"] : "[meta] route");
					navRoute.File = "";
					if (dictionary.TryGetValue("metaRouteMode", out value) && int.TryParse(value, NumberStyles.Integer, HCI, out var result3))
					{
						navRoute.Mode = result3;
					}
					_metaRoute = navRoute;
					_metaRouteSrc = FindEmbeddedSrc(navRoute.Name);
				}
			}
			if (dictionary.TryGetValue("rName", out var value3) && value3.Length > 0 && CurrentRoute != null && string.Equals(CurrentRoute.Name, value3, StringComparison.Ordinal))
			{
				_rName = value3;
				RouteReset();
				_rIdx = (int)Num(dictionary, "rIdx");
				_rDir = (int)Num(dictionary, "rDir");
				if (_rDir == 0)
				{
					_rDir = 1;
				}
				_rDone = dictionary.ContainsKey("rDone") && dictionary["rDone"] == "1";
				_rStarted = dictionary.ContainsKey("rStarted") && dictionary["rStarted"] == "1";
				_rSub = (int)Num(dictionary, "rSub");
				_rSubFor = (int)Num(dictionary, "rSubFor");
				if (_rIdx < 0 || _rIdx >= CurrentRoute.Steps.Count)
				{
					_rIdx = 0;
				}
				_resumeNearest = false;
				list.Add("route " + value3 + " at step " + (_rIdx + 1));
			}
			if (list.Count > 0)
			{
				Util.WriteToChat("Nav: carried on after the reload - " + string.Join(", ", list.ToArray()) + ".");
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static double Num(Dictionary<string, string> d, string k)
	{
		string value;
		double result;
		return (d.TryGetValue(k, out value) && double.TryParse(value, NumberStyles.Float, HCI, out result)) ? result : 0.0;
	}

	private MVal FindEmbeddedSrc(string routeName)
	{
		if (_meta == null)
		{
			return null;
		}
		string bare = (routeName.StartsWith("[meta] ", StringComparison.Ordinal) ? routeName.Substring(7) : routeName);
		MVal found = null;
		Action<MAct> walk = null;
		walk = (MAct a) =>
		{
			if (a != null && found == null)
			{
				if (a.Type == 4 && a.Data != null && a.Data.B != null)
				{
					MetaText.NavSummary(a.Data.B, out var name, out var _);
					string a2 = ((name.Length > 0) ? Path.GetFileNameWithoutExtension(name) : "");
					if (string.Equals(a2, bare, StringComparison.OrdinalIgnoreCase))
					{
						found = a.Data;
					}
				}
				if (a.Kids != null)
				{
					foreach (MAct kid in a.Kids)
					{
						walk(kid);
					}
				}
			}
		};
		foreach (MRule rule in _meta.Rules)
		{
			walk(rule.A);
		}
		return found;
	}

	private NavRoute MapRoute()
	{
		return _s.NavRoutes.Find((NavRoute x) => string.Equals(x.Name, "Map route", StringComparison.OrdinalIgnoreCase));
	}

	public void MapRouteCommand(string rest)
	{
		string[] array = (rest ?? "").Trim().Split(new char[1] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
		if (array.Length == 0)
		{
			Util.WriteToChat("Map route: /mtank maproute add <ns> <ew> [z] | clear");
			return;
		}
		NavRoute navRoute = MapRoute();
		if (array[0].Equals("clear", StringComparison.OrdinalIgnoreCase))
		{
			if (navRoute != null)
			{
				bool flag = CurrentRoute == navRoute;
				navRoute.Steps.Clear();
				navRoute.Mode = 0;
				if (flag)
				{
					Stop();
					RouteReset();
				}
				RouteChanged();
				if (SaveAll != null)
				{
					SaveAll();
				}
			}
			PublishMapRoute(now: true);
			Util.WriteToChat("Map route cleared.");
			return;
		}
		double result = 0.0;
		if (!array[0].Equals("add", StringComparison.OrdinalIgnoreCase) || array.Length < 3 || !double.TryParse(array[1], NumberStyles.Float, MCI, out var result2) || !double.TryParse(array[2], NumberStyles.Float, MCI, out var result3))
		{
			Util.WriteToChat("Map route: /mtank maproute add <ns> <ew> [z] | clear");
			return;
		}
		if (array.Length > 3)
		{
			double.TryParse(array[3], NumberStyles.Float, MCI, out result);
		}
		if (_travelRoute != null)
		{
			Util.WriteToChat("Map route: auto travel is running - stop it first.");
			return;
		}
		bool flag2 = false;
		if (navRoute == null)
		{
			navRoute = new NavRoute
			{
				Name = "Map route",
				Mode = 0
			};
			_s.NavRoutes.Add(navRoute);
			flag2 = true;
		}
		else if (CurrentRoute != navRoute || _rDone || navRoute.Steps.Count == 0)
		{
			navRoute.Steps.Clear();
			navRoute.Mode = 0;
			flag2 = true;
		}
		navRoute.Steps.Add(new RouteStep
		{
			Kind = StepKind.Point,
			NS = result2,
			EW = result3,
			Z = result
		});
		bool flag3 = _s.NavMode == 1 && string.Equals(_s.NavRouteSelected, navRoute.Name, StringComparison.OrdinalIgnoreCase);
		_s.NavMode = 1;
		_s.NavRouteSelected = navRoute.Name;
		if (flag2 || !flag3)
		{
			Stop();
			RouteReset();
			_rSel = -1;
		}
		else if (_rDone)
		{
			_rDone = false;
		}
		RouteChanged();
		if (SaveAll != null)
		{
			SaveAll();
		}
		PublishMapRoute(now: true);
		int count = navRoute.Steps.Count;
		Util.WriteToChat("Map route: point " + count + " added" + ((count == 1) ? " (a new route)" : "") + (_s.NavEnabled ? "." : " - turn Nav on to run it."));
	}

	public void PublishMapRoute(bool now)
	{
		if (!now && (DateTime.Now - _mapPubAt).TotalSeconds < 1.0)
		{
			return;
		}
		_mapPubAt = DateTime.Now;
		string text = "";
		try
		{
			NavRoute navRoute = MapRoute();
			if (navRoute != null && CurrentRoute == navRoute && _s.NavMode == 1)
			{
				StringBuilder stringBuilder = new StringBuilder();
				foreach (RouteStep step in navRoute.Steps)
				{
					if (step.Kind == StepKind.Point)
					{
						stringBuilder.Append(step.NS.ToString("R", MCI)).Append(',').Append(step.EW.ToString("R", MCI))
							.Append(',')
							.Append(step.Z.ToString("0.##", MCI))
							.Append(';');
					}
				}
				text = stringBuilder.ToString();
			}
		}
		catch
		{
		}
		if (text == _mapPublished)
		{
			return;
		}
		_mapPublished = text;
		try
		{
			AppDomain.CurrentDomain.SetData("MelkTank.MapRoute", text);
		}
		catch
		{
		}
	}
}
