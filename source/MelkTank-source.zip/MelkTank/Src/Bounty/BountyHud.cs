using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Reflection;
using ImGuiNET;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank.Bounties;

public class BountyHud : IDisposable
{
	private readonly Hud _hud;

	private readonly BountyTracker _t;

	private readonly Settings _s;

	private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

	private static readonly Vector4 Cyan = new Vector4(0.35f, 0.85f, 0.95f, 1f);

	private static readonly Vector4 Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f);

	private static readonly Vector4 Gold = new Vector4(0.95f, 0.8f, 0.3f, 1f);

	private static readonly Vector4 BarColor = new Vector4(0.2f, 0.55f, 0.3f, 1f);

	private static readonly Vector4 BarAll = new Vector4(0.3f, 0.4f, 0.65f, 1f);

	public static BountyHud Current;

	private static List<KeyValuePair<string, bool>> _ktCache = new List<KeyValuePair<string, bool>>();

	private static DateTime _ktAt = DateTime.MinValue;

	private static string _ktLogged = "";

	private bool _restored;



	public bool Visible
	{
		get
		{
			return _hud.Visible;
		}
		set
		{
			_hud.Visible = value;
		}
	}

	private static string PosFile => Util.FullPath("MelkTank_BountyPos.txt");

	public BountyHud(BountyTracker t, Settings s)
	{
		Current = this;
		_t = t;
		_s = s;
		_hud = UBService.Huds.CreateHud("MelkTank Bounty", BarIcon.Make("Bnty"));
		_hud.ShowInBar = true;
		_hud.WindowSettings = ImGuiWindowFlags.NoTitleBar | ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoCollapse | ImGuiWindowFlags.AlwaysAutoResize;
		_hud.OnPreRender += OnPreRender;
		_hud.OnRender += OnRender;
		_hud.Visible = s.BountyHudOn;
	}

	public void Dispose()
	{
		if (Current == this)
		{
			Current = null;
		}
		try
		{
			_hud.OnPreRender -= OnPreRender;
			_hud.OnRender -= OnRender;
			_hud.Dispose();
		}
		catch
		{
		}
	}

	public static List<KeyValuePair<string, bool>> KtLines()
	{
		if ((DateTime.Now - _ktAt).TotalSeconds < 1.0)
		{
			return _ktCache;
		}
		_ktAt = DateTime.Now;
		List<KeyValuePair<string, bool>> list = new List<KeyValuePair<string, bool>>();
		string text = "MelksQB not loaded";
		int num = 0;
		try
		{
			// Decal builds it as MelksQuestTracker.dll, ACGodot as MelksQB.dll (same MelksQuestTracker namespace). After a
			// hot reload the old copy can still be loaded: use the newest one whose PluginCore is running.
			List<Assembly> list2 = Util.PluginAssemblies("MelksQuestTracker");
			list2.AddRange(Util.PluginAssemblies("MelksQB"));
			num = list2.Count;
			Assembly pick = null;
			for (int i = list2.Count - 1; i >= 0 && pick == null; i--)
			{
				Type t = list2[i].GetType("MelksQuestTracker.PluginCore");
				FieldInfo inst = t?.GetField("Instance", BindingFlags.Static | BindingFlags.Public);
				if (inst != null && inst.GetValue(null) != null)
				{
					pick = list2[i];
				}
			}
			if (pick == null && list2.Count > 0)
			{
				pick = list2[list2.Count - 1];
			}
			if (pick != null)
			{
				Assembly current = pick;
				text = "PopupKtLines";
				Type type = current.GetType("MelksQuestTracker.PluginCore");
				MethodInfo methodInfo = ((type == null) ? null : type.GetMethod("PopupKtLines", BindingFlags.Static | BindingFlags.Public));
				if (type == null)
				{
					text = "no MelksQuestTracker.PluginCore in " + current.FullName;
				}
				else if (methodInfo == null)
				{
					text = "old MelksQB (no PopupKtLines)";
				}
				if (methodInfo != null)
				{
					foreach (string item in (methodInfo.Invoke(null, null) as List<string>) ?? new List<string>())
					{
						if (item.Length > 2)
						{
							list.Add(new KeyValuePair<string, bool>(item.Substring(2), item.StartsWith("D|")));
						}
					}
				}
				else
				{
					Func<List<KeyValuePair<string, bool>>> func = OldQbLines(current);
					if (func != null)
					{
						list.AddRange(func() ?? new List<KeyValuePair<string, bool>>());
					}
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			text = "error: " + ex.Message;
		}
		string text2 = text + "|" + num + "|" + list.Count;
		if (text2 != _ktLogged)
		{
			_ktLogged = text2;
			try
			{
				PluginCore.CurrentEngine?.NoteLine("KTPOP " + list.Count + " line(s) via " + text + ((num != 1) ? (" (" + num + " MelksQuestTracker assemblies loaded)") : "") + ((list.Count > 0) ? (": " + string.Join(" / ", list.ConvertAll((KeyValuePair<string, bool> x) => x.Key).ToArray())) : ""));
			}
			catch
			{
			}
		}
		_ktCache = list;
		return list;
	}

	private static Func<List<KeyValuePair<string, bool>>> OldQbLines(Assembly asm)
	{
		Type type = asm.GetType("MelksQuestTracker.BountyHud");
		if (type == null)
		{
			return null;
		}
		FieldInfo field = type.GetField("_current", BindingFlags.Static | BindingFlags.NonPublic);
		object obj = ((field == null) ? null : field.GetValue(null));
		if (obj == null)
		{
			return null;
		}
		FieldInfo field2 = type.GetField("ExtraLines");
		Func<List<KeyValuePair<string, bool>>> func = ((field2 == null) ? null : (field2.GetValue(obj) as Func<List<KeyValuePair<string, bool>>>));
		AppDomain currentDomain = AppDomain.CurrentDomain;
		if (func != null && func == currentDomain.GetData("MelkTank.QbCoinWrap"))
		{
			func = currentDomain.GetData("MelkTank.QbCoinOrig") as Func<List<KeyValuePair<string, bool>>>;
			field2.SetValue(obj, func);
			currentDomain.SetData("MelkTank.QbCoinWrap", null);
		}
		try
		{
			PropertyInfo property = type.GetProperty("Visible");
			if (property != null && (bool)property.GetValue(obj, null))
			{
				property.SetValue(obj, false, null);
			}
			FieldInfo field3 = type.GetField("_t", BindingFlags.Instance | BindingFlags.NonPublic);
			object obj2 = ((field3 == null) ? null : field3.GetValue(obj));
			FieldInfo fieldInfo = obj2?.GetType().GetField("Enabled");
			if (fieldInfo != null && (bool)fieldInfo.GetValue(obj2))
			{
				fieldInfo.SetValue(obj2, false);
			}
		}
		catch
		{
		}
		return func;
	}

	public static List<string> PhoneLines(Settings s)
	{
		List<string> list = new List<string>();
		BountyTracker current = BountyTracker.Current;
		if (current == null)
		{
			return list;
		}
		try
		{
			foreach (KeyValuePair<string, KeyValuePair<string, bool>> item in current.TierBounties())
			{
				list.Add("B|" + item.Key + "|" + item.Value.Key + "|");
			}
			foreach (Bounty item2 in current.Here)
			{
				bool flag = BountyTracker.IsAllZones(item2) && !current.AllZonesCount;
				bool flag2 = item2.UnlocksAt != DateTime.MinValue;
				string text = ((flag | flag2) ? "" : current.TimeToGo(item2));
				string text2 = (flag2 ? ("unlocks in " + BountyTracker.Countdown(item2.UnlocksIn)) : (item2.Have.ToString("N0", Inv) + " / " + item2.Need.ToString("N0", Inv) + ((text.Length > 0) ? ("  (" + text + " to go)") : "")));
				if (flag)
				{
					text2 += "  - not counting here";
				}
				list.Add("B|" + (flag ? "All zones" : current.ZoneName(item2)) + "|" + text2 + "|" + item2.Reward);
			}
			if (current.LastEvent.Length > 0 && (DateTime.Now - current.LastEventAt).TotalMinutes < 10.0)
			{
				list.Add("E|" + current.LastEvent);
			}
			string text3 = Session.CoinLine();
			if (text3.Length > 0)
			{
				list.Add("K|" + text3);
			}
			string augLine = Session.AugLine();
			if (augLine.Length > 0)
			{
				// (A|colour|text: the aug pace's colour - g full rate to the reset, y slowing, r stopping; n a note under it)
				char pace = Session.AugPace(out var paceNotes);
				list.Add("A|" + (pace == ' ' ? 'n' : pace) + "|" + augLine);
				foreach (string n in paceNotes) list.Add("A|n|" + n);
			}
			if (s == null || s.BountyShowKts)
			{
				foreach (KeyValuePair<string, bool> item3 in KtLines())
				{
					list.Add((item3.Value ? "D|" : "K|") + item3.Key);
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		return list;
	}

	private void OnPreRender(object sender, EventArgs e)
	{
		if (_restored)
		{
			return;
		}
		_restored = true;
		try
		{
			string path = PosFile;
			if (!File.Exists(path))
			{
				string text = Path.Combine(Path.Combine(Path.GetDirectoryName(Util.BasePath.TrimEnd(new char[2] { '\\', '/' })), "MelksQB"), "MQT_BountyPos.txt");
				if (!File.Exists(text))
				{
					return;
				}
				path = text;
			}
			string[] array = File.ReadAllText(path).Trim().Split('|');
			if (array.Length == 2 && float.TryParse(array[0], NumberStyles.Float, Inv, out var result) && float.TryParse(array[1], NumberStyles.Float, Inv, out var result2))
			{
				ImGui.SetNextWindowPos(new Vector2(result, result2), ImGuiCond.Always);
			}
		}
		catch
		{
		}
	}


	private void OnRender(object sender, EventArgs e)
	{
		long t = Perf.Begin();
		try
		{
			OnRenderInner(sender, e);
		}
		finally
		{
			Perf.Lap("Window: bounties", t);
		}
	}

	// "Your bounties: none going (you can have up to 4) ..." - nothing to show
	private static bool NoneGoing(string s)
	{
		return s.IndexOf("none going", StringComparison.OrdinalIgnoreCase) >= 0;
	}

	private void ItemSlotLines()
	{
		List<string> itemSlots = _t.ItemSlots;
		if (itemSlots == null || itemSlots.Count == 0)
		{
			return;
		}
		bool flag = false;
		foreach (string item in itemSlots)
		{
			if (item.IndexOf("all empty", StringComparison.OrdinalIgnoreCase) < 0 && !NoneGoing(item))
			{
				flag = true;
				break;
			}
		}
		if (!flag)
		{
			return;
		}
		ImGui.PushTextWrapPos(ImGui.GetCursorPosX() + 260f);
		foreach (string item2 in itemSlots)
		{
			if (item2.IndexOf("all empty", StringComparison.OrdinalIgnoreCase) < 0 && !NoneGoing(item2))
			{
				Im.TextColored(Gold, item2);
			}
		}
		ImGui.PopTextWrapPos();
	}

	private void OnRenderInner(object sender, EventArgs e)
	{
		try
		{
			WinMem.Frame("Bounty", size: false);
			Im.TextColored(Cyan, "Bounties");
			foreach (KeyValuePair<string, KeyValuePair<string, bool>> item in _t.TierBounties())
			{
				bool value = item.Value.Value;
				Im.TextColored(value ? new Vector4(0.4f, 0.9f, 0.4f, 1f) : Gold, item.Key + " - " + item.Value.Key);
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip("Tou Tou's bounty for each tier your augs allow (T11: Creature 4,000, Life / Item 2,000; +500 each a tier).\n" + (value ? "Ready - kills there count." : "Waiting to unlock."));
				}
			}
			if (_t.Here.Count == 0)
			{
				Vector4 grey = Grey;
				string s;
				if (_t.UpdatedAt == DateTime.MinValue)
				{
					s = "Checking...";
				}
				else
				{
					s = ((_t.Note.Length > 0) ? _t.Note : "No bounties here.");
				}
				Im.TextColored(grey, s);
			}
			foreach (Bounty item2 in _t.Here)
			{
				bool flag = BountyTracker.IsAllZones(item2);
				bool flag2 = flag && !_t.AllZonesCount;
				if (flag2)
				{
					Im.TextColored(Grey, "All zones (not here - tier 11+ only)");
				}
				else
				{
					ImGui.TextUnformatted(_t.ZoneName(item2));
				}
				bool flag3 = item2.UnlocksAt != DateTime.MinValue;
				float fraction;
				if (flag3)
				{
					fraction = 0f;
				}
				else
				{
					fraction = ((item2.Need > 0) ? Math.Min(1f, (float)item2.Have / (float)item2.Need) : 0f);
				}
				Vector4 col;
				if (flag2 | flag3)
				{
					col = new Vector4(0.35f, 0.35f, 0.35f, 1f);
				}
				else
				{
					col = (flag ? BarAll : BarColor);
				}
				ImGui.PushStyleColor(ImGuiCol.PlotHistogram, col);
				string text = (flag2 ? "" : _t.TimeToGo(item2));
				ImGui.ProgressBar(fraction, new Vector2(240f, 0f), flag3 ? ("unlocks in " + BountyTracker.Countdown(item2.UnlocksIn)) : (item2.Have.ToString("N0", Inv) + " / " + item2.Need.ToString("N0", Inv) + ((text.Length > 0) ? ("   " + text) : "")));
				ImGui.PopStyleColor();
				if (ImGui.IsItemHovered())
				{
					string text2 = _t.LimitFor(item2);
					int num = Math.Max(0, item2.Need - item2.Have);
					ImGui.BeginTooltip();
					Im.TextColored(Gold, "Reward: " + item2.Reward);
					ImGui.TextUnformatted("Every " + item2.Need.ToString("N0", Inv) + " kills" + ((text2.Length > 0) ? (" (" + text2 + ")") : ""));
					if (flag3)
					{
						Im.TextColored(Gold, "Paid out - kills count again in " + BountyTracker.Countdown(item2.UnlocksIn) + " (at " + item2.UnlocksAt.ToString("h:mm tt") + ")");
					}
					else
					{
						ImGui.TextUnformatted(num.ToString("N0", Inv) + " kills to go");
					}
					double num2 = _t.KillsPerMinute();
					if (!flag3 && !flag2)
					{
						ImGui.TextUnformatted((num2 <= 0.0) ? "Time to go: after 1 minute of kills" : ((num2 * 60.0).ToString("N0", Inv) + " kills/hr (last 60 min) - done in " + text));
					}
					if (flag2)
					{
						Im.TextColored(Grey, "Kills here don't count - this area is tier " + _t.Tier + ".");
					}
					ImGui.EndTooltip();
				}
			}
			if (_t.LastEvent.Length > 0 && (DateTime.Now - _t.LastEventAt).TotalMinutes < 10.0)
			{
				ImGui.PushTextWrapPos(ImGui.GetCursorPosX() + 240f);
				Im.TextColored(Gold, _t.LastEvent);
				ImGui.PopTextWrapPos();
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip(_t.LastEventAt.ToString("h:mm tt"));
				}
			}
			ItemSlotLines();
			string text3 = Session.CoinLine();
			if (text3.Length > 0)
			{
				Im.TextColored(Gold, text3);
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip(Session.CoinTipText());
				}
			}
			string augLine = Session.AugLine();
			if (augLine.Length > 0)
			{
				char pace = Session.AugPace(out var paceNotes);
				var col = pace == 'g' ? new Vector4(0.45f, 0.9f, 0.45f, 1f) : pace == 'y' ? new Vector4(0.95f, 0.85f, 0.35f, 1f) : pace == 'r' ? new Vector4(1f, 0.45f, 0.4f, 1f) : Gold;
				Im.TextColored(col, augLine);
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip(Session.AugTipText() + "\n\nGreen: at your kills/hr (last hour) the full rate lasts till the weekly reset. Yellow: it slows to the second step's rate first. Red: the week's rewards run out before the reset.");
				}
				foreach (string n in paceNotes)
				{
					Im.TextColored(new Vector4(col.X * 0.85f, col.Y * 0.85f, col.Z * 0.85f, 1f), "  " + n);
				}
			}
			ImGui.Spacing();
			if (ImGui.Button("/bounty"))
			{
				_t.SendManual("/bounty");
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("The bounties where you stand, in chat.");
			}
			ImGui.SameLine();
			if (ImGui.Button("/bounty list"))
			{
				_t.SendManual("/bounty list");
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Every bounty, in chat.");
			}
			string text4 = "Tier " + ((_t.Tier >= 0) ? _t.Tier.ToString() : "?");
			string text5;
			if (_t.UpdatedAt == DateTime.MinValue)
			{
				text5 = "";
			}
			else if (_t.Paused)
			{
				text5 = text4 + " - no bounties count here, waiting for a portal";
			}
			else
			{
				int num3 = (int)(DateTime.Now - _t.UpdatedAt).TotalSeconds;
				text5 = text4 + " - updated " + ((num3 < 60) ? (num3 + "s") : (num3 / 60 + "m")) + " ago";
			}
			if (text5.Length > 0)
			{
				Im.TextColored(Grey, text5);
			}
			if (!_s.BountyShowKts)
			{
				return;
			}
			foreach (KeyValuePair<string, bool> item3 in KtLines())
			{
				Im.TextColored(item3.Value ? Gold : Cyan, item3.Key);
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}
}
