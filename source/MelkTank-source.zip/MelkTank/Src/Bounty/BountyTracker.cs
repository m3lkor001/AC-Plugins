using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using MelkTank.Metas;
using Decal.Adapter.Wrappers;

namespace MelkTank.Bounties;

public class BountyTracker
{
	public static BountyTracker Current;

	public int IntervalSeconds = 60;

	public bool Enabled = true;

	public int Version;

	public List<Bounty> Here = new List<Bounty>();

	public List<Bounty> All = new List<Bounty>();

	public DateTime UpdatedAt = DateTime.MinValue;

	public string Note = "";

	public const int AllZonesTier = 11;

	private DateTime _due = DateTime.Now.AddSeconds(4.0);

	private DateTime _lastSent = DateTime.MinValue;

	private DateTime _quietUntil = DateTime.MinValue;

	private DateTime _lastHereAt = DateTime.MinValue;

	private DateTime _nextCheck = DateTime.MinValue;

	private bool _wantList = true;

	private bool _inList;

	private List<Bounty> _listBuilding;

	private int _tierSeen = -2;

	public Action<string> Log = (string m) =>
	{
	};

	private string _readyWhy = null;

	private static Dictionary<int, string> _lbZones;

	public string LastEvent = "";

	public DateTime LastEventAt = DateTime.MinValue;

	private DateTime _awaitFrom = DateTime.MinValue;

	private DateTime _awaitUntil = DateTime.MinValue;

	private List<string> _itemSlots;

	public List<string> ItemSlots = new List<string>();

	public DateTime ItemSlotsAt = DateTime.MinValue;

	private bool _staleHere;

	private int _answerLb;

	public bool Paused { get; private set; }

	public int Tier
	{
		get
		{
			try
			{
				return Session.CurrentTier();
			}
			catch
			{
				return -1;
			}
		}
	}

	public bool AllZonesCount
	{
		get
		{
			int tier = Tier;
			return tier < 0 || tier >= 11;
		}
	}

	private static string LbFile => Util.FullPath("MelkTank_ZoneLandblocks.txt");

	public string CurrentZone
	{
		get
		{
			foreach (Bounty item in Here)
			{
				if (!IsAllZones(item))
				{
					string text = ZoneName(item);
					if (text != "This area")
					{
						return text;
					}
				}
			}
			return "";
		}
	}

	public bool AnyLocked
	{
		get
		{
			foreach (Bounty item in Here)
			{
				if (item.Locked)
				{
					return true;
				}
			}
			foreach (Bounty item2 in All)
			{
				if (item2.Locked)
				{
					return true;
				}
			}
			return false;
		}
	}

	public string StateText()
	{
		int lb = Landblock();
		string text = FixTier(LbZone(lb));
		return "on " + Enabled + ", paused " + Paused + ", list " + All.Count + ", answered " + ((UpdatedAt == DateTime.MinValue) ? "never" : UpdatedAt.ToString("HH:mm:ss")) + ", stale here " + _staleHere + ", landblock " + lb.ToString("X4") + " -> " + (text ?? "?") + ", zone '" + CurrentZone + "', tier " + Tier + ", next ask " + ((_due == DateTime.MinValue) ? "now" : _due.ToString("HH:mm:ss")) + ", want list " + _wantList;
	}

	public BountyTracker()
	{
		Current = this;
		try
		{
			UbExpr.SetVar("bountyready", 0.0);
		}
		catch
		{
		}
	}

	public void Tick()
	{
		DateTime now = DateTime.Now;
		if (now < _nextCheck)
		{
			return;
		}
		_nextCheck = now.AddSeconds(1.0);
		PublishVars();
		int tier = Tier;
		if (tier != _tierSeen)
		{
			_tierSeen = tier;
			if (UpdatedAt != DateTime.MinValue && !_staleHere)
			{
				UpdatePaused();
			}
		}
		if (!Enabled)
		{
			if (_wantList && now >= _due)
			{
				_wantList = false;
				SendQuiet("/bounty list");
			}
		}
		else if (!Paused && !(now < _due))
		{
			if (_wantList)
			{
				_wantList = false;
				SendQuiet("/bounty list");
				_due = now.AddSeconds(3.0);
			}
			else
			{
				SendQuiet("/bounty");
			}
		}
	}

	private void PublishVars()
	{
		int num = Landblock();
		string text = FixTier(LbZone(num));
		if (!_staleHere && num > 0 && num == _answerLb)
		{
			string text2 = VarKey(CurrentZone);
			if (text2.Length > 0)
			{
				Learn(num, text2);
			}
		}
		UbExpr.SetVar("landblock", (double)num);
		bool flag = All.Count > 0 && UpdatedAt != DateTime.MinValue && (!_staleHere || text != null);
		UbExpr.SetVar("bountyready", flag ? 1.0 : 0.0);
		string text3 = (flag ? "ready" : "not ready") + " (list " + All.Count + ", answered " + (UpdatedAt != DateTime.MinValue) + ", stale here " + _staleHere + ", landblock " + num.ToString("X4") + " -> " + (text ?? "?") + ")";
		if (text3 != _readyWhy)
		{
			_readyWhy = text3;
			Log("bountyready = " + (flag ? 1 : 0) + ": " + text3);
		}
		string text4 = text ?? (_staleHere ? "" : VarKey(CurrentZone));
		foreach (Bounty item in All)
		{
			string text5 = VarKey(item.Zone);
			if (text5.Length > 0 && !IsAllZones(item))
			{
				UbExpr.SetVar("inzone_" + text5, (text4 == text5) ? 1.0 : 0.0);
			}
		}
		foreach (Bounty item2 in All)
		{
			string text6 = VarKey(item2.Zone);
			if (text6.Length != 0)
			{
				double num2 = (item2.Locked ? Math.Ceiling(item2.UnlocksIn.TotalSeconds) : 0.0);
				UbExpr.SetVar("bounty_" + text6, num2);
				UbExpr.SetVar("bountykills_" + text6, (double)Math.Max(0, item2.Need - item2.Have));
			}
		}
	}

	private static int Landblock()
	{
		try
		{
			return Globals.Core.Actions.Landcell >>> 16;
		}
		catch
		{
			return 0;
		}
	}

	private string FixTier(string key)
	{
		if (string.IsNullOrEmpty(key))
		{
			return key;
		}
		int tier = Tier;
		if (tier < 11 || ZoneTier(key) == tier)
		{
			return key;
		}
		string text = key.TrimEnd(new char[10] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' });
		foreach (Bounty item in All)
		{
			string text2 = VarKey(item.Zone);
			if (text2.TrimEnd(new char[10] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' }) == text && ZoneTier(item.Zone) == tier)
			{
				return text2;
			}
		}
		return key;
	}

	private static string LbZone(int lb)
	{
		LoadLb();
		string value;
		return (lb > 0 && _lbZones.TryGetValue(lb, out value)) ? value : null;
	}

	private static void LoadLb()
	{
		if (_lbZones != null)
		{
			return;
		}
		_lbZones = new Dictionary<int, string>();
		try
		{
			string lbFile = LbFile;
			if (!File.Exists(lbFile))
			{
				return;
			}
			string[] array = File.ReadAllLines(lbFile);
			foreach (string text in array)
			{
				string[] array2 = text.Split('\t');
				if (array2.Length >= 2 && int.TryParse(array2[0], NumberStyles.HexNumber, null, out var result) && array2[1].Trim().Length > 0)
				{
					_lbZones[result] = array2[1].Trim();
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void Learn(int lb, string zone)
	{
		LoadLb();
		if (_lbZones.TryGetValue(lb, out var value) && value == zone)
		{
			return;
		}
		_lbZones[lb] = zone;
		try
		{
			StringBuilder stringBuilder = new StringBuilder();
			foreach (KeyValuePair<int, string> lbZone in _lbZones)
			{
				stringBuilder.Append(lbZone.Key.ToString("X4")).Append('\t').Append(lbZone.Value)
					.Append("\r\n");
			}
			Util.WriteShared(LbFile, stringBuilder.ToString());
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static string VarKey(string zone)
	{
		StringBuilder stringBuilder = new StringBuilder();
		string text = (zone ?? "").ToLowerInvariant();
		foreach (char c in text)
		{
			if (char.IsLetterOrDigit(c))
			{
				stringBuilder.Append(c);
			}
		}
		return stringBuilder.ToString();
	}

	public void AreaChanged()
	{
		_staleHere = true;
		LastEvent = "";
		LastEventAt = DateTime.MinValue;
		Paused = false;
		DateTime dateTime = _lastSent.AddSeconds(10.0);
		DateTime dateTime2 = DateTime.Now.AddSeconds(4.0);
		_due = ((dateTime > dateTime2) ? dateTime : dateTime2);
	}

	public void Expect(string cmd)
	{
		string text = (cmd ?? "").Trim().ToLowerInvariant();
		if (!(text != "/bounty") || !(text != "@bounty"))
		{
			_awaitFrom = DateTime.Now;
			_awaitUntil = DateTime.Now.AddSeconds(6.0);
		}
	}

	private void SendQuiet(string cmd)
	{
		Expect(cmd);
		_quietUntil = DateTime.Now.AddSeconds(6.0);
		_lastSent = DateTime.Now;
		_due = DateTime.Now.AddSeconds(IntervalSeconds);
		Log("sent " + cmd + " (quiet)");
		try
		{
			Globals.Core.Actions.InvokeChatParser(cmd);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public void RequestList()
	{
		_quietUntil = DateTime.Now.AddSeconds(6.0);
		try
		{
			Globals.Core.Actions.InvokeChatParser("/bounty list");
		}
		catch
		{
		}
	}

	public void SendManual(string cmd)
	{
		_quietUntil = DateTime.MinValue;
		Expect(cmd);
		try
		{
			Globals.Core.Actions.InvokeChatParser(cmd);
		}
		catch
		{
		}
	}

	public Bounty ListEntryFor(Bounty b)
	{
		Bounty bounty = null;
		int tier = Tier;
		foreach (Bounty item in All)
		{
			if (!string.Equals(item.Reward, b.Reward, StringComparison.OrdinalIgnoreCase))
			{
				continue;
			}
			if (b.Zone.Length > 0)
			{
				if (string.Equals(item.Zone, b.Zone, StringComparison.OrdinalIgnoreCase))
				{
					return item;
				}
			}
			else if (item.Need == b.Need && !IsAllZones(item))
			{
				if (tier > 0 && ZoneTier(item.Zone) == tier)
				{
					return item;
				}
				if (bounty == null)
				{
					bounty = item;
				}
			}
		}
		return bounty;
	}

	private static int ZoneTier(string zone)
	{
		Match match = Regex.Match(zone ?? "", "(\\d+)\\s*$");
		int result;
		return (match.Success && int.TryParse(match.Groups[1].Value, out result)) ? result : 11;
	}

	public string LimitFor(Bounty b)
	{
		Bounty bounty = ListEntryFor(b);
		return (bounty == null) ? "" : bounty.Limit;
	}

	public string ZoneName(Bounty b)
	{
		if (IsAllZones(b))
		{
			return "All zones";
		}
		if (b.Zone.Length > 0)
		{
			return b.Zone;
		}
		Bounty bounty = ListEntryFor(b);
		return (bounty != null) ? bounty.Zone : "This area";
	}

	public bool TierBounty(out string label, out string state, out bool ready)
	{
		label = (state = "");
		ready = false;
		int num = Session.EligibleTier();
		if (num <= 0)
		{
			return false;
		}
		Bounty bounty = null;
		int num2 = -1;
		foreach (Bounty item in All)
		{
			if (item.Zone.IndexOf("tou tou", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				Match match = Regex.Match(item.Zone, "(\\d+)");
				int result = 11;
				if ((!match.Success || int.TryParse(match.Groups[1].Value, out result)) && result <= num && result > num2)
				{
					bounty = item;
					num2 = result;
				}
			}
		}
		if (bounty == null)
		{
			return false;
		}
		label = "Tou Tou T" + num2;
		ready = !bounty.Locked;
		state = (ready ? "Ready" : Countdown(bounty.UnlocksIn));
		return true;
	}

	public List<KeyValuePair<string, KeyValuePair<string, bool>>> TierBounties()
	{
		List<KeyValuePair<string, KeyValuePair<string, bool>>> list = new List<KeyValuePair<string, KeyValuePair<string, bool>>>();
		int num = Session.EligibleTier();
		if (num <= 0)
		{
			return list;
		}
		SortedDictionary<int, Bounty> sortedDictionary = new SortedDictionary<int, Bounty>();
		foreach (Bounty item in All)
		{
			if (item.Zone.IndexOf("tou tou", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				int num2 = ZoneTier(item.Zone);
				if (num2 <= num && !sortedDictionary.ContainsKey(num2))
				{
					sortedDictionary[num2] = item;
				}
			}
		}
		List<int> list2 = new List<int>(sortedDictionary.Keys);
		list2.Reverse();
		foreach (int item2 in list2)
		{
			Bounty bounty = sortedDictionary[item2];
			bool flag = !bounty.Locked;
			list.Add(new KeyValuePair<string, KeyValuePair<string, bool>>("Tou Tou T" + item2, new KeyValuePair<string, bool>(flag ? "Ready" : Countdown(bounty.UnlocksIn), flag)));
		}
		return list;
	}

	/// <summary>The bounties a kill here counts toward now: this zone's (and all zones') that aren't waiting out a cooldown.</summary>
	public List<Bounty> HereBounties()
	{
		List<Bounty> l = new List<Bounty>();
		try
		{
			int lb = Landblock();
			string fixedKey = FixTier(LbZone(lb));
			string here = fixedKey ?? (_staleHere ? "" : VarKey(CurrentZone));
			foreach (Bounty b in All)
			{
				if (b.Locked || b.Need <= 0) continue;
				if (IsAllZones(b) || (here.Length > 0 && VarKey(b.Zone) == here)) l.Add(b);
			}
		}
		catch
		{
		}
		return l;
	}

	public static bool IsAllZones(Bounty b)
	{
		return string.Equals(b.Zone, "all zones", StringComparison.OrdinalIgnoreCase);
	}

	public bool OnChat(string text)
	{
		if (string.IsNullOrEmpty(text))
		{
			return false;
		}
		bool flag = DateTime.Now < _quietUntil;
		bool flag2 = false;
		bool flag3 = false;
		string[] array = text.Replace("\r", "").Split('\n');
		foreach (string text2 in array)
		{
			if (text2.Trim().Length == 0)
			{
				continue;
			}
			BountyParser.Kind kind = BountyParser.Read(text2, _inList, out var b);
			if (kind != BountyParser.Kind.None)
			{
				Log("read " + kind.ToString() + ": " + text2.Trim());
			}
			switch (kind)
			{
			case BountyParser.Kind.Here:
				AddHere(b);
				break;
			case BountyParser.Kind.ListHeader:
				_inList = true;
				_listBuilding = new List<Bounty>();
				break;
			case BountyParser.Kind.ListItem:
				if (_listBuilding == null)
				{
					_listBuilding = new List<Bounty>();
				}
				_listBuilding.Add(b);
				break;
			case BountyParser.Kind.ItemSlots:
			{
				string text3 = BountyParser.Clean(text2).Trim();
				// a new listing starts the list afresh: its heading, or its first entry (#1 / R1) - stale lines after 4 kept off
				if (text3.StartsWith("Item bount", StringComparison.OrdinalIgnoreCase) || text3.StartsWith("Bounty Ledger", StringComparison.OrdinalIgnoreCase) || text3.StartsWith("Your bounties", StringComparison.OrdinalIgnoreCase)
					|| text3.StartsWith("#1", StringComparison.Ordinal) || text3.StartsWith("Bounty #1", StringComparison.OrdinalIgnoreCase)
					|| (DateTime.Now - ItemSlotsAt).TotalSeconds > 5.0)
				{
					_itemSlots = new List<string>();
				}
				if (_itemSlots == null)
				{
					_itemSlots = new List<string>();
				}
				_itemSlots.Add(text3);
				ItemSlots = new List<string>(_itemSlots);
				ItemSlotsAt = DateTime.Now;
				break;
			}
			case BountyParser.Kind.ListFooter:
				_inList = false;
				if (_listBuilding != null)
				{
					All = _listBuilding;
					Version++;
				}
				_listBuilding = null;
				break;
			case BountyParser.Kind.OtherBounty:
				if (!_inList)
				{
					if (DateTime.Now < _awaitUntil && _lastHereAt < _awaitFrom)
					{
						StartHereBatch();
						Note = BountyParser.Clean(text2).Trim();
						UpdatedAt = DateTime.Now;
						UpdatePaused();
					}
					else
					{
						LastEvent = BountyParser.Clean(text2).Trim();
						LastEventAt = DateTime.Now;
						Paused = false;
						DateTime dateTime = DateTime.Now.AddSeconds(3.0);
						DateTime dateTime2 = _lastSent.AddSeconds(IntervalSeconds);
						_due = ((dateTime2 > dateTime) ? dateTime2 : dateTime);
					}
				}
				break;
			default:
				flag3 = true;
				break;
			}
			if (kind != BountyParser.Kind.None)
			{
				flag2 = true;
			}
		}
		return (flag & flag2) && !flag3;
	}

	private void StartHereBatch()
	{
		if ((DateTime.Now - _lastHereAt).TotalSeconds > 1.5)
		{
			Here = new List<Bounty>();
			Note = "";
		}
		_lastHereAt = DateTime.Now;
		_staleHere = false;
		_answerLb = Landblock();
	}

	public double KillsPerMinute()
	{
		double killsPerHourRecent = Session.KillsPerHourEstimate;
		return (killsPerHourRecent > 0.0) ? (killsPerHourRecent / 60.0) : (-1.0);
	}

	public string TimeToGo(Bounty b)
	{
		if (b.Locked || b.Need <= 0)
		{
			return "";
		}
		double num = KillsPerMinute();
		if (num <= 0.0)
		{
			return "";
		}
		int num2 = Math.Max(0, b.Need - b.Have);
		if (num2 == 0)
		{
			return "0:00";
		}
		int num3 = (int)Math.Ceiling((double)num2 / num);
		return num3 / 60 + ":" + (num3 % 60).ToString("00");
	}

	public void Kill()
	{
		if (_staleHere)
		{
			return;
		}
		bool flag = false;
		foreach (Bounty item in Here)
		{
			if (!item.Locked && item.Need > 0 && item.Have < item.Need && (!IsAllZones(item) || AllZonesCount))
			{
				item.Have++;
				Bounty bounty = ListEntryFor(item);
				if (bounty != null && bounty != item)
				{
					bounty.Have = item.Have;
				}
				flag = true;
			}
		}
		if (flag)
		{
			Version++;
		}
	}

	private void AddHere(Bounty b)
	{
		StartHereBatch();
		Here.Add(b);
		Bounty bounty = ListEntryFor(b);
		if (bounty != null)
		{
			bounty.Have = b.Have;
			bounty.Need = b.Need;
			bounty.UnlocksAt = b.UnlocksAt;
		}
		Version++;
		UpdatedAt = DateTime.Now;
		_due = DateTime.Now.AddSeconds(IntervalSeconds);
		foreach (Bounty item in Here)
		{
			if (item.Locked && item.UnlocksAt.AddSeconds(3.0) < _due)
			{
				_due = item.UnlocksAt.AddSeconds(3.0);
			}
		}
		UpdatePaused();
	}

	public static string Countdown(TimeSpan t)
	{
		if (t <= TimeSpan.Zero)
		{
			return "unlocking...";
		}
		if (t.TotalHours >= 1.0)
		{
			return (int)t.TotalHours + ":" + t.Minutes.ToString("00") + ":" + t.Seconds.ToString("00");
		}
		return t.Minutes + ":" + t.Seconds.ToString("00");
	}

	private void UpdatePaused()
	{
		bool flag = false;
		foreach (Bounty item in Here)
		{
			if (!IsAllZones(item) || AllZonesCount)
			{
				flag = true;
			}
		}
		bool paused = Paused;
		Paused = !flag;
		if (paused && !Paused && _due < DateTime.Now)
		{
			_due = DateTime.Now.AddSeconds(IntervalSeconds);
		}
	}
}
