using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Numerics;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Buffs;
using MelkTank.Loot;
using MelkTank.Pets;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public class MainView : IDisposable
{
	private class TrackRow
	{
		public TrackedMonster Tm;

		public double D;

		public MonsterRule Rule;

		public int Src;

		public bool E;

		public bool Q;

		public string DistText;

		public string PrioText;

		public string RuleText;

		public TrackCells C;
	}

	private class TrackCells
	{
		public int Bits = -1;

		public string Label;

		public string Reset;

		public int TimeSec = -1;

		public string Time;

		public DateTime NfAt = DateTime.MinValue;

		public bool NfHas;

		public bool NfReady;

		public string Nf;

		public readonly Dictionary<Slot, DbCell> Db = new Dictionary<Slot, DbCell>();
	}

	private class DbCell
	{
		public int Sec = int.MinValue;

		public string Text;

		public string Id;

		public Vector2 Size;
	}

	private readonly Hud _hud;

	private readonly Settings _s;

	private readonly CombatEngine _engine;

	private int _dbgShown = -1;

	private readonly Action _saveAll;

	private readonly Action<bool> _onBufferToggled;

	private readonly Action<bool> _onPetToggled;

	private string _newMonsterName = "";

	private int _swapWith = -1;

	private readonly MonsterDbTab _dbTab = new MonsterDbTab();

	private string _profileName = "";

	private bool _confirmDelete;

	private List<string> _profiles;

	private DateTime _profilesReadAt = DateTime.MinValue;

	// (the game's other names too: void is nether, blade is slash, bludgeon is blunt)
	private static readonly string[] DmgNames = new string[9] { "Auto", "Void / Nether", "Fire", "Cold", "Acid", "Lightning", "Blade / Slash", "Pierce", "Bludgeon / Blunt" };

	private static readonly string[] ExVulnNames = BuildExVulnNames();

	private static readonly string[] KindNames = Enum.GetNames(typeof(WeaponKind));

	private static readonly string[] TypeNames = new string[10] { "Caster", "Melee", "Missile", "Ammo", "Mana", "Stamina", "Health", "Mana stone", "Lockpick", "Dispel" };

	private static readonly Vector4 Cyan = new Vector4(0.35f, 0.85f, 0.95f, 1f);

	private static readonly Vector4 Red = new Vector4(0.95f, 0.35f, 0.35f, 1f);

	private static readonly Vector4 Green = new Vector4(0.45f, 0.9f, 0.45f, 1f);

	private static readonly Vector4 Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f);

	private static readonly Vector4 Yellow = new Vector4(0.95f, 0.85f, 0.35f, 1f);

	private static readonly Vector4 Purple = new Vector4(0.75f, 0.45f, 0.95f, 1f);

	private Hud _trackHud;

	private bool _inTrackPop;

	private readonly BuffTab _buffTab;

	private readonly PetTab _petTab;

	private readonly PortalsTab _portalsTab;

	private readonly LootTab _lootTab;

	private bool _restored;

	private float[] _lastRect;

	private DateTime _rectDirtySince = DateTime.MinValue;

	public Action MiniReset;

	private int _catchShown = -1;

	private string _advFilter = "";

	private string[] _extraNew = new string[2] { "", "" };

	private const string NoProfile = "(this character's list)";

	private int _trackSort = 2;

	private bool _trackSortDesc;

	private readonly Dictionary<int, TrackCells> _trackCells = new Dictionary<int, TrackCells>();

	private List<TrackRow> _trackRows;

	private DateTime _trackRowsAt = DateTime.MinValue;

	private int _trackRowsSort = -1;

	private bool _trackRowsDesc;

	private static string WindowFile => Util.FullPath("MelkTank_Window.txt");

	public MainView(Settings settings, CombatEngine engine, Action saveAll, Action<bool> onBufferToggled, Action<bool> onPetToggled)
	{
		MainView mainView = this;
		_s = settings;
		_engine = engine;
		_saveAll = saveAll;
		_onBufferToggled = onBufferToggled;
		_onPetToggled = onPetToggled;
		_hud = UBService.Huds.CreateHud("MelkTank", BarIcon.Make("Tank"));
		_hud.Title = "MelkTank  " + BuildInfo.Label;
		_hud.ShowInBar = true;
		_hud.OnPreRender += OnPreRender;
		_hud.OnRender += OnRender;
		_lootTab = new LootTab(settings, engine.Looter, saveAll);
		_lootTab.LootModeText = () => engine.LootMode ? ("Attack range " + engine.AttackRangeNow.ToString("0") + " m - finishing looting") : null;
		_buffTab = new BuffTab(engine.Buffer, settings, PluginCore.SetBuffingFromUi);
		MonsterLog.AddToList = MonsterLogAdd;
		_petTab = new PetTab(settings, saveAll, (bool on) =>
		{
			mainView._s.MelksPetEnabled = on;
			mainView._onPetToggled(on);
			saveAll();
		}, () => engine.AttackRangeNow);
		_portalsTab = new PortalsTab(settings, saveAll);
		engine.Nav.DrawPortals = () =>
		{
			mainView._portalsTab.Draw();
		};
		engine.Compare.SaveAll = saveAll;
		engine.Nav.SaveAll = saveAll;
		engine.Windows.SaveAll = saveAll;
		engine.Areas.SaveAll = saveAll;
		if (_s.TrackPopOut)
		{
			ShowTrackPop(on: true);
		}
	}

	private void ShowTrackPop(bool on)
	{
		try
		{
			if (on && _trackHud == null)
			{
				_trackHud = UBService.Huds.CreateHud("MelkTank Tracking", BarIcon.Make("Trk"));
				_trackHud.ShowInBar = false;
				_trackHud.OnRender += OnTrackRender;
			}
			if (_trackHud != null)
			{
				_trackHud.Visible = on;
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void OnTrackRender(object sender, EventArgs e)
	{
		long t = Perf.Begin();
		try
		{
			OnTrackRenderInner(sender, e);
		}
		finally
		{
			Perf.Lap("Window: tracking pop-out", t);
		}
	}

	private void OnTrackRenderInner(object sender, EventArgs e)
	{
		try
		{
			if (_trackHud.Visible)
			{
				if (!_s.TrackPopOut)
				{
					_trackHud.Visible = false;
					return;
				}
				ImGui.SetWindowSize(new Vector2(560f, 300f), ImGuiCond.FirstUseEver);
				WinMem.Frame("Tracking");
				_inTrackPop = true;
				DrawTracking();
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		finally
		{
			_inTrackPop = false;
		}
	}

	public void Dispose()
	{
		try
		{
			_hud.OnPreRender -= OnPreRender;
			_hud.OnRender -= OnRender;
			_hud.Dispose();
		}
		catch
		{
		}
		try
		{
			_lootTab.Dispose();
		}
		catch
		{
		}
		try
		{
			_portalsTab.Dispose();
		}
		catch
		{
		}
		try
		{
			if (_trackHud != null)
			{
				_trackHud.OnRender -= OnTrackRender;
				_trackHud.Dispose();
				_trackHud = null;
			}
		}
		catch
		{
		}
	}

	private static string[] BuildExVulnNames()
	{
		string[] names = (string[])DmgNames.Clone();
		names[0] = "None";
		return names;
	}

	private void OnPreRender(object sender, EventArgs e)
	{
		if (!_restored)
		{
			_restored = true;
			float[] array = LoadWindowRect();
			if (array != null)
			{
				ImGui.SetNextWindowPos(new Vector2(array[0], array[1]), ImGuiCond.Always);
				ImGui.SetNextWindowSize(new Vector2(array[2], array[3]), ImGuiCond.Always);
				return;
			}
		}
		ImGui.SetNextWindowSize(new Vector2(880f, 470f), ImGuiCond.FirstUseEver);
	}

	private static float[] LoadWindowRect()
	{
		try
		{
			if (!File.Exists(WindowFile))
			{
				return null;
			}
			string[] array = File.ReadAllText(WindowFile).Trim().Split('|');
			if (array.Length != 4)
			{
				return null;
			}
			float[] array2 = new float[4];
			for (int i = 0; i < 4; i++)
			{
				if (!float.TryParse(array[i], NumberStyles.Float, CultureInfo.InvariantCulture, out array2[i]))
				{
					return null;
				}
			}
			return array2;
		}
		catch
		{
			return null;
		}
	}

	private void TrackWindowRect()
	{
		Vector2 windowPos = ImGui.GetWindowPos();
		Vector2 windowSize = ImGui.GetWindowSize();
		float[] array = new float[4] { windowPos.X, windowPos.Y, windowSize.X, windowSize.Y };
		bool flag = _lastRect == null;
		if (!flag)
		{
			for (int i = 0; i < 4; i++)
			{
				if (Math.Abs(array[i] - _lastRect[i]) > 0.5f)
				{
					flag = true;
				}
			}
		}
		if (flag)
		{
			_lastRect = array;
			_rectDirtySince = DateTime.Now;
		}
		if (!(_rectDirtySince != DateTime.MinValue) || !((DateTime.Now - _rectDirtySince).TotalSeconds > 1.5))
		{
			return;
		}
		_rectDirtySince = DateTime.MinValue;
		try
		{
			File.WriteAllText(WindowFile, string.Join("|", Array.ConvertAll(array, (float f) => f.ToString(CultureInfo.InvariantCulture))));
		}
		catch
		{
		}
	}

	private void OnRender(object sender, EventArgs e)
	{
		long t = Perf.Begin();
		try
		{
			OnRenderInner(sender, e);
		}
		finally
		{
			Perf.Lap("Window: main", t);
		}
	}

	private void OnRenderInner(object sender, EventArgs e)
	{
		try
		{
			TrackWindowRect();
		}
		catch
		{
		}
		WinMem.Frame("Main");
		try
		{
			if (!ImGui.BeginTabBar("MelkTankTabs"))
			{
				return;
			}
			if (ImGui.BeginTabItem("Main"))
			{
				DrawMain();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Monsters"))
			{
				DrawMonsters();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Buffs"))
			{
				_buffTab.Draw();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Items"))
			{
				if (ImGui.BeginTabBar("itemtabs"))
				{
					if (ImGui.BeginTabItem("Weapons"))
					{
						DrawItems(weapons: true);
						ImGui.EndTabItem();
					}
					if (ImGui.BeginTabItem("Other Items"))
					{
						DrawItems(weapons: false);
						ImGui.EndTabItem();
					}
					if (ServerMode.Ilt && ImGui.BeginTabItem("Charms"))
					{
						if (Charms.Draw(_s))
						{
							_saveAll();
						}
						ImGui.EndTabItem();
					}
					if (ImGui.BeginTabItem("Organize"))
					{
						if (PackOrganizer.Draw(_s))
						{
							_saveAll();
						}
						ImGui.EndTabItem();
					}
					if (ImGui.BeginTabItem("Vendor"))
					{
						if (VendorTab.Draw(_s, _engine, _lootTab.EditFile))
						{
							_saveAll();
						}
						ImGui.EndTabItem();
					}
					if (ImGui.BeginTabItem("Salvage"))
					{
						Crafting.Draw();
						ImGui.EndTabItem();
					}
					if (ImGui.BeginTabItem("Inventory"))
					{
						if (InventoryTab.Draw(_s))
						{
							_saveAll();
						}
						ImGui.EndTabItem();
					}
					ImGui.EndTabBar();
				}
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Pets"))
			{
				_petTab.Draw();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Nav"))
			{
				_engine.Nav.Draw();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Loot"))
			{
				_lootTab.Draw();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Tracking"))
			{
				DrawTrackingTabs();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Session"))
			{
				Session.Draw();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Settings"))
			{
				DrawSettings();
				ImGui.EndTabItem();
			}
			ImGui.EndTabBar();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void DrawMain()
	{
		bool flag = false;
		ImGui.PushStyleColor(ImGuiCol.Button, _s.CombatEnabled ? new Vector4(0.15f, 0.55f, 0.2f, 1f) : new Vector4(0.55f, 0.15f, 0.15f, 1f));
		if (ImGui.Button(_s.CombatEnabled ? "Combat: ON " : "Combat: OFF", new Vector2(140f, 0f)))
		{
			_s.CombatEnabled = !_s.CombatEnabled;
			flag = true;
		}
		ImGui.PopStyleColor();
		ImGui.SameLine();
		Im.TextColored(_s.CombatEnabled ? Green : Grey, _engine.Status ?? "");
		DrawMemWarning();
		ImGui.Separator();
		ImGui.SetNextItemWidth(120f);
		flag |= ImGui.InputFloat("Attack range (m)", ref _s.AttackRange, 1f, 5f, "%.0f");
		Im.SetTooltipIfHovered("/mt set AttackRange <number>");
		if (_s.AttackRange < 1f)
		{
			_s.AttackRange = 1f;
		}
		ImGui.SameLine(0f, 20f);
		ImGui.SetNextItemWidth(120f);
		flag |= ImGui.InputFloat("Loot range (m)##mainloot", ref _s.LootRange, 1f, 5f, "%.0f");
		Im.SetTooltipIfHovered("/mt set LootRange <number>");
		if (_s.LootRange < 1f)
		{
			_s.LootRange = 1f;
		}
		Tip("Corpse range - same setting as on the Loot tab.");
		ImGui.SetNextItemWidth(120f);
		flag |= ImGui.InputFloat("Approach range (m)##approach", ref _s.ApproachRange, 1f, 5f, "%.0f");
		Im.SetTooltipIfHovered("/mt set ApproachRange <number>");
		if (_s.ApproachRange < 0f)
		{
			_s.ApproachRange = 0f;
		}
		Tip("A monster past the attack range but inside this: it runs over to it (as nav would) until it's inside the\nattack range, then fights - so a melee attack starts close instead of a long charge.\nOnly counts when it's bigger than the attack range. 0: off.");
		ImGui.SameLine(0f, 20f);
		flag |= ImGui.Checkbox("Skip monsters behind walls##wallskip", ref _s.SkipBehindWalls);
		Tip("A monster with a wall, shut door or object (a table, a pillar) between you is left alone - not fired at - until the line is clear. Your pets and other creatures don't count as in the way. (ACGodot only.)\n/mt set SkipBehindWalls on|off");
		ImGui.SameLine(0f, 20f);
		flag |= ImGui.Checkbox("Prefer the monster attacking me##attfirst", ref _s.PreferAttacker);
		Tip("Among monsters of the same priority, go for the one the server says is hitting you first. Priority still comes first. (ACGodot only.)\n/mt set PreferAttacker on|off");
		bool v = _engine.Buffer.Enabled;
		if (ImGui.Checkbox("Buffing", ref v))
		{
			PluginCore.SetBuffingFromUi(v);
		}
		Tip("Same switch as the Buffs tab's ON/OFF and 'Buff' on the mini panel.\n/mt buff on|off  -  /mt rebuff rebuffs now");
		ImGui.SameLine(0f, 20f);
		flag |= ImGui.Checkbox("Nav", ref _s.NavEnabled);
		Tip("Return to the selected spot on the Nav tab" + ((_engine.Nav.Current != null) ? (" (" + _engine.Nav.Current.Name + ")") : " - no spot saved yet") + ".\nSame switch as 'Return to spot' there.\n/mt set NavEnabled on|off");
		ImGui.SameLine(0f, 20f);
		flag |= ImGui.Checkbox("Looting", ref _s.LootEnabled);
		Tip("Same switch as the Loot tab's Looting ON/OFF.\n/mt loot on|off");
		ImGui.SameLine(0f, 20f);
		flag |= ImGui.Checkbox("Shiny / Enraged = normal monster", ref _s.ShinySameAsBase);
		Tip("'Shiny Banshee', 'Enraged Banshee' and 'Enraged Shiny Banshee' use the Banshee row on the Monsters tab\n(attacks, debuffs, weapon...) unless they have a row of their own.\n/mt set ShinySameAsBase on|off");
		flag |= ImGui.Checkbox("Nav priority boost##navboost", ref _s.NavBoost);
		Tip("While Nav has somewhere to go, keep going - don't stop to fight or loot (healing, buffs and vitals still come first).\nWith a route, that's the whole route.\n/mt set NavBoost on|off");
		ImGui.SameLine(0f, 20f);
		flag |= ImGui.Checkbox("Loot priority boost##lootboost", ref _s.LootBoost);
		Tip("Loot every corpse in range that your loot rules want before fighting - even with monsters around.\n(Nav priority boost wins when both are on.)\n/mt set LootBoost on|off");
		flag |= ImGui.Checkbox("Level 1 ring##main", ref _s.RingLevel1);
		Im.SetTooltipIfHovered("/mt set RingLevel1 on|off");
		ImGui.SameLine(0f, 20f);
		Im.Text("Ring when");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		flag |= ImGui.InputInt("monsters##ringmin2", ref _s.RingMinMonsters);
		Im.SetTooltipIfHovered("/mt set RingMinMonsters <number>");
		if (_s.RingMinMonsters < 1)
		{
			_s.RingMinMonsters = 1;
		}
		ImGui.SameLine();
		Im.Text("within");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(120f);
		flag |= ImGui.SliderFloat("m of me##ringrad2", ref _s.RingRadius, 1f, 7f, "%.1f");
		Tip("On monsters with R checked: cast a ring when at least this many monsters are this close.\nWith fewer, cast an arc/bolt (A) or streak (S) instead. With only R checked, it always rings.\n/mt set RingRadius <number>");
		ImGui.SameLine();
		Im.TextColored(Grey, "(now: " + _engine.MonstersNear(_s.RingRadius) + ")");
		if (ImGui.CollapsingHeader("Pet Options###hdrpet"))
		{
			ImGui.Indent(8f);
			bool v2 = _s.MelksPetEnabled;
			if (ImGui.Checkbox("Enable Pet Summoning", ref v2))
			{
				_s.MelksPetEnabled = v2;
				_onPetToggled(v2);
				flag = true;
			}
			Tip("Summons the pets on the Pets tab, for the element in each monster's PetDmg column (Monsters tab - its row, else\nthe DEFAULT row). Auto: the monster's damage order - yours (DB tab), else VTank's, else your species order -\nthe first element you have a ticked pet for, else any ticked pet. Same switch as 'Summon' on the mini panel.\n/mt summon on|off");
			flag |= ImGui.Checkbox("Only summon while Combat is on", ref _s.PetOnlyInCombat);
			Tip("While Combat is off (or MelkTank is off), nothing is summoned - not even a pet it was about to swap in.\nIt carries on as soon as Combat is back on. Pets already out stay out; recharging still happens.\n/mt set PetOnlyInCombat on|off");
			flag |= ImGui.Checkbox("Summon before the fight only", ref _s.PetNoSummonInFight);
			Tip("No summons (or pet swaps) once a fight has started - Combat on with monsters in range or a cast going.\nThe pet comes out on the way in: the summoner looks " + Tuning.V("PetLeadM").ToString("0") + " m further out than the pet range\n(Tuning: 'Summon before the fight: look ahead').\n/mt set PetNoSummonInFight on|off");
			flag |= ImGui.Checkbox("Recharge pets between packs only", ref _s.PetRechargeBetweenPacks);
			Tip("A pet that needs recharging waits until the fight is over (nothing in range) - even the 'after 90 s anyway' -\nso casting doesn't wait on it.\n/mt set PetRechargeBetweenPacks on|off");
			flag |= PetTab.DrawRange(_s, () => _engine.AttackRangeNow);
			ImGui.Unindent(8f);
		}
		if (ImGui.CollapsingHeader("Dispel###hdrdispel"))
		{
			ImGui.Indent(8f);
			flag |= Dispel.Draw(Tip);
			ImGui.Unindent(8f);
		}
		if (ImGui.CollapsingHeader("Fellowship Options###hdrfellow"))
		{
			ImGui.Indent(8f);
			flag |= FellowManager.Draw(Tip);
			ImGui.Unindent(8f);
		}
		if (flag)
		{
			_saveAll();
		}
	}

	private void DrawSettings()
	{
		if (ImGui.BeginTabBar("settabs"))
		{
			if (ImGui.BeginTabItem("Basic"))
			{
				DrawBasicSettings();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Advanced"))
			{
				DrawAdvanced();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Commands"))
			{
				LoginCommands.Draw();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Debug"))
			{
				DrawDebugTab();
				ImGui.EndTabItem();
			}
			ImGui.EndTabBar();
		}
	}

	private void DrawMemWarning()
	{
		bool flag = true;
	}

	private void DrawBasicSettings()
	{
		bool flag = false;
		if (ImGui.CollapsingHeader("Memory###hdrmem"))
		{
			ImGui.Indent(8f);
			flag |= ImGui.Checkbox("Relog before memory runs out##autorelog", ref _s.AutoRelogOn);
			Tip("The game client's memory climbs as items are seen (a known AC leak) and it hangs at about 1.6-1.7 GB.\nOn: past this size, at the next calm moment (nothing in range, nothing to loot - or after 20 minutes regardless),\nMelkTank exits the game cleanly and the PC service (MelkTank Remote) starts it again.\nOnly when this game was started by the MelkTank launcher - otherwise (Windows, ThwargLauncher) nothing would start it\nagain, so it doesn't relog (it says so in chat once).\n/mt set AutoRelogOn on|off");
			ImGui.SameLine();
			ImGui.SetNextItemWidth(110f);
			flag |= ImGui.InputFloat("GB##autorelogb", ref _s.AutoRelogGB, 0.05f, 0.1f, "%.2f");
			Im.SetTooltipIfHovered("/mt set AutoRelogGB <number>");
			if (_s.AutoRelogGB < 0.5f)
			{
				_s.AutoRelogGB = 0.5f;
			}
			ImGui.SameLine();
			Im.TextColored(Grey, "(now " + ((MemWatch.InUse > 0) ? (MemWatch.GB.ToString("0.00") + " GB") : "?") + ")");
			ImGui.SetNextItemWidth(110f);
			flag |= ImGui.InputInt("Relog anyway after this many minutes without a calm moment##autorelogwait", ref _s.AutoRelogWaitMin, 1, 5);
			Im.SetTooltipIfHovered("/mt set AutoRelogWaitMin <number>");
			flag |= ImGui.Checkbox("Log where the memory goes (once a minute)##memlog", ref _s.MemLog);
			Tip("Logs\\<character>\\MelkTank_MemLog_<character>.csv, a line a minute: private memory, the .NET heap (every .NET plugin together),\nthe rest (the game client itself and Decal's native parts), builds loaded by hot reloads, objects the client knows,\ninventory and kills - to see which part climbs. Takes effect straight away.\n/mt set MemLog on|off");
			if (_s.AutoRelogWaitMin < 1)
			{
				_s.AutoRelogWaitMin = 1;
			}
			Tip("Past the memory size MelkTank waits for a calm moment (nothing in range, nothing to loot) to exit;\nafter this long it exits anyway.");
			ImGui.Unindent(8f);
		}
		if (ImGui.CollapsingHeader("Healing Options###hdrheal"))
		{
			ImGui.Indent(8f);
			flag |= DrawHealing();
			ImGui.Unindent(8f);
		}
		if (ImGui.CollapsingHeader("Debuffs / DoTs###hdrdeb"))
		{
			ImGui.Indent(8f);
			flag |= ImGui.Checkbox("Debuff all nearby monsters first", ref _s.DebuffAllFirst);
			Tip("On: vuln/DoT every monster in range (highest priority first, then closest) before attacking.\nOff: debuff only the current target, then attack it.\n/mt set DebuffAllFirst on|off");
			flag |= ImGui.Checkbox("Refresh DoTs", ref _s.RefreshDots);
			Im.SetTooltipIfHovered("/mt set RefreshDots on|off");
			ImGui.SameLine();
			flag |= ImGui.Checkbox("Refresh vulns", ref _s.RefreshVulns);
			Im.SetTooltipIfHovered("/mt set RefreshVulns on|off");
			ImGui.SetNextItemWidth(120f);
			flag |= ImGui.InputFloat("Reapply seconds before it ends", ref _s.RefreshLeadSeconds, 1f, 5f, "%.0f");
			Im.SetTooltipIfHovered("/mt set RefreshLeadSeconds <number>");
			if (_s.RefreshLeadSeconds < 0f)
			{
				_s.RefreshLeadSeconds = 0f;
			}
			if (ServerMode.Ilt)
			{
				Im.TextColored(Cyan, "Nether Fracture (NF column)");
				ImGui.SetNextItemWidth(120f);
				flag |= ImGui.InputFloat("Nether Streak delay after priming (s)##frdelay", ref _s.FractureDelayS, 1f, 2f, "%.1f");
				Im.SetTooltipIfHovered("/mt set FractureDelayS <number>");
				if (_s.FractureDelayS < 0f)
				{
					_s.FractureDelayS = 0f;
				}
				Tip("Monsters with NF ticked get Corrosion, Corruption and Destructive Curse (that primes them), then Nether Streak\nthis many seconds after the third one landed. The burst is built from the last 8 s of DoT damage, so waiting\n~8 s makes it hit for more.");
				flag |= ImGui.Checkbox("Only prime when at least##frminon", ref _s.FractureMinOn);
				Im.SetTooltipIfHovered("/mt set FractureMinOn on|off");
				ImGui.SameLine();
				ImGui.SetNextItemWidth(90f);
				flag |= ImGui.InputInt("monsters within 5 m of it##frmin", ref _s.FractureMin, 1, 1);
				Im.SetTooltipIfHovered("/mt set FractureMin <number>");
				if (_s.FractureMin < 1)
				{
					_s.FractureMin = 1;
				}
				Tip("The burst splits across up to 4 monsters within 5 m of the primed one. Counting it: 2 = it plus one more.\nOff: an NF monster is always primed (and released after the delay).");
				flag |= ImGui.Checkbox("Prime again after each release##frre", ref _s.FractureReprime);
				Tip("On: after its Nether Streak the three DoTs are cast again and it's released again after the delay - for monsters\nthat live long. Off: one release per monster, then it's attacked as usual.\n/mt set FractureReprime on|off");
				flag |= ImGui.Checkbox("Nether Streak anything primed, until it's dead##strprimed", ref _s.StreakPrimed);
				Tip("Like ticking S on its row, for every monster the game has said is primed (it was cast on by hand), even after its\nprime is used up: once there's nothing else to cast (debuffs up), it's attacked with Nether Streak until it dies.\nNot while its Nether Fracture delay is running (a Streak releases the burst - too early and it's a small one).\n/mt set StreakPrimed on|off");
				flag |= ImGui.Checkbox("... and anything with all three void DoTs (from the spread)##strdotted", ref _s.StreakDotted);
				Tip("Also streak monsters that have Corruption, Destructive Curse and Corrosion but were never primed - the ones that\ngot them from the void spread (with 'Trust the void spread' on, they aren't cast on, so they're never primed).\n/mt set StreakDotted on|off");
				flag |= ImGui.Checkbox("Prime the focused monster##primefocus", ref _s.PrimeFocus);
				Tip("The monster you focus (Focus selected) always gets Corruption, Destructive Curse and Corrosion cast on it by hand -\neven if it has them from the void spread - so it's primed, then released with Nether Streak after the delay.\nIts NF column doesn't need to be ticked, and the 'at least N monsters within 5 m' check doesn't apply.\n/mt set PrimeFocus on|off");
				flag |= ImGui.Checkbox("Always prime monsters with priority at least##primehigh", ref _s.PrimeHigh);
				Im.SetTooltipIfHovered("/mt set PrimeHigh on|off");
				ImGui.SameLine();
				ImGui.SetNextItemWidth(90f);
				flag |= ImGui.InputInt("##primehighmin", ref _s.PrimeHighMin, 1, 1);
				Im.SetTooltipIfHovered("/mt set PrimeHighMin <number>");
				if (_s.PrimeHighMin < 1)
				{
					_s.PrimeHighMin = 1;
				}
				Tip("Rows with this priority or higher (the big ones in a pack) are always primed by hand - Corruption, Destructive\nCurse, Corrosion, even if the void spread already put them on - and released with Nether Streak, in every group\nincluding adds. Their NF column doesn't need ticking and the 'at least N within 5 m' check doesn't apply.");
				flag |= ImGui.Checkbox("One prime per wand (mixed packs)##primeoneperwand", ref _s.PrimeOnePerWand);
				Tip("Monsters that use the same wand (its slayer is for them) get one of them primed and released - the big one\n(forced / highest priority), else the nearest - instead of each one. Then the next wand's monsters the same way,\nthen streaks (wand in hand first), swapping back for any left. Forced ones (focus, priority at least N) are still primed.\n/mt set PrimeOnePerWand on|off");
				if (_s.PrimeOnePerWand)
				{
					ImGui.Indent(16f);
					flag |= ImGui.Checkbox("New prime if the pack is barely touched##reprimefresh", ref _s.RePrimeFresh);
					Tip("When a wand's primed monster dies, the rest of its pack is checked (identified for their health): if one is still\nabove 95%, the nearest one above 90% becomes a new prime - its DoTs are cast again from scratch (whatever MelkTank\nthought the spread put on it). Both values are on the Tuning tab (Casting).\n/mt set RePrimeFresh on|off");
					ImGui.Unindent(16f);
				}
				flag |= ImGui.Checkbox("Nether Fracture on every monster##frall", ref _s.FractureAll);
				Tip("On: every monster is treated as if its NF column were ticked - primed and released with Nether Streak -\nwithout going through the monster list. Off: only the rows with NF ticked.\n/mt set FractureAll on|off");
				flag |= ImGui.Checkbox("Prime every NF monster yourself - higher priority first, then the furthest from it##primeevery", ref _s.PrimeEveryNF);
				Tip("Every NF monster gets Corruption, Destructive Curse and Corrosion cast on it by hand (copies from the void\nspread don't count - they don't prime it), so each one is primed and released.\nOrder: the highest priority first, then the ones furthest from it (from the first one primed, if they're all the\nsame priority), then the closer ones.\nThe 'at least N within 5 m' check still applies.\n/mt set PrimeEveryNF on|off");
			}
			flag |= ImGui.Checkbox("Trust the void spread within##trustspread", ref _s.TrustSpread);
			Im.SetTooltipIfHovered("/mt set TrustSpread on|off");
			ImGui.SameLine();
			ImGui.SetNextItemWidth(90f);
			flag |= ImGui.InputFloat("m##trustspreadm", ref _s.TrustSpreadM, 1f, 2f, "%.0f");
			Im.SetTooltipIfHovered("/mt set TrustSpreadM <number>");
			if (_s.TrustSpreadM < 1f)
			{
				_s.TrustSpreadM = 1f;
			}
			ImGui.SameLine();
			ImGui.SetNextItemWidth(80f);
			flag |= ImGui.InputInt("nearest at most##trustspreadmax", ref _s.TrustSpreadMax, 1, 1);
			Im.SetTooltipIfHovered("/mt set TrustSpreadMax <number>");
			if (_s.TrustSpreadMax < 0)
			{
				_s.TrustSpreadMax = 0;
			}
			Tip("The spread reaches at most this many more monsters (2 - the dev, Nov 7: your target + 2 more, at every charm level). Only the\nnearest this many are counted as getting the DoTs; the others get theirs cast by hand. 0 = no limit.\nAfter each spread their health is checked - one whose health didn't move gets its DoTs cast by hand first.");
			Tip("'Your void magic spreads to N more creatures': the monsters around the one cast on get its Corruption, Destructive\nCurse and Corrosion too (about 9-10 m reach). On: those copies count as cast, so they aren't cast again - fewer\ncasts, but those monsters aren't primed (that takes all three cast by hand), so only the one cast on gets a\nNether Streak; the rest die to the DoTs and its burst. Off: all three are cast on each (each primed and released).");
			flag |= ImGui.Checkbox("Use the DoT damage lines##dotlines", ref _s.UseDotLines);
			Tip("Needs the game's DoT lines on (/ilt dotlines 1-10): each DoT on each monster reports its damage every few seconds.\nOn: a DoT whose lines stop coming has ended - it's cast again then, not when its timer guessed. With 'Trust the\nvoid spread' on, a DoT seen ticking on a monster you didn't cast it on (the spread) counts as on while it ticks.\nLines naming a monster that has others of the same name around are only used when it's clear which one.\n/mt set UseDotLines on|off");
			ImGui.Unindent(8f);
		}
		if (ImGui.CollapsingHeader("Spell Options###hdrspell"))
		{
			ImGui.Indent(8f);
			Im.Text("Spell level (unchecked = level 8):");
			flag |= ImGui.Checkbox("Level 1 DoT", ref _s.Level1Dot);
			Im.SetTooltipIfHovered("/mt set Level1Dot on|off");
			ImGui.SameLine();
			flag |= ImGui.Checkbox("Level 1 vuln", ref _s.Level1Vuln);
			Im.SetTooltipIfHovered("/mt set Level1Vuln on|off");
			ImGui.SameLine();
			flag |= ImGui.Checkbox("Level 1 war", ref _s.Level1War);
			Im.SetTooltipIfHovered("/mt set Level1War on|off");
			ImGui.SameLine();
			flag |= ImGui.Checkbox("Level 1 void", ref _s.Level1Void);
			Tip("If the chosen level isn't in your spellbook, the nearest known level is used.\n/mt set Level1Void on|off");
			flag |= ImGui.Checkbox("Level 1 ring", ref _s.RingLevel1);
			Tip("Checked: level 6 rings (Cassius' Ring of Fire, Clouded Soul, ...).\nUnchecked: level 7 rings (Cassius' Ring of Fire II, Clouded Soul II, ...).\nFalls back to the other one if you don't know it.\n/mt set RingLevel1 on|off");
			flag |= ImGui.Checkbox("Bolts instead of arcs", ref _s.UseBolts);
			Tip("Unticked: the A column casts arcs. Ticked: it casts bolts.\n/mt set UseBolts on|off");
			Im.Text("Ring when");
			ImGui.SameLine();
			ImGui.SetNextItemWidth(90f);
			flag |= ImGui.InputInt("monsters##ringmin", ref _s.RingMinMonsters);
			Im.SetTooltipIfHovered("/mt set RingMinMonsters <number>");
			if (_s.RingMinMonsters < 1)
			{
				_s.RingMinMonsters = 1;
			}
			ImGui.SameLine();
			Im.Text("within");
			ImGui.SameLine();
			ImGui.SetNextItemWidth(120f);
			flag |= ImGui.SliderFloat("m of me##ringrad", ref _s.RingRadius, 1f, 7f, "%.1f");
			Tip("On monsters with R checked: cast a ring when at least this many monsters are this close.\nWith fewer, cast an arc/bolt (A) or streak (S) instead. With only R checked, it always rings.\n/mt set RingRadius <number>");
			ImGui.SameLine();
			Im.TextColored(Grey, "(now: " + _engine.MonstersNear(_s.RingRadius) + ")");
			ImGui.SetNextItemWidth(120f);
			flag |= ImGui.InputInt("Cast recovery (ms)", ref _s.CastRecoveryMs, 100, 500);
			Im.SetTooltipIfHovered("/mt set CastRecoveryMs <number>");
			if (_s.CastRecoveryMs < 0)
			{
				_s.CastRecoveryMs = 0;
			}
			Tip("Pause after 'You cast ...' before sending the next cast. The game ignores a cast sent\nwhile your character is still finishing the last one. If the debug log still shows MISS\nright after a LAND, raise this; if there's no MISS, you can try lowering it.");
			ImGui.Unindent(8f);
		}
		if (ImGui.CollapsingHeader("Default Attacks###hdratk"))
		{
			ImGui.Indent(8f);
			int current_item = (int)_s.DefaultAttack;
			ImGui.SetNextItemWidth(120f);
			if (ImGui.Combo("Default attack", ref current_item, KindNames, 3))
			{
				_s.DefaultAttack = (WeaponKind)current_item;
				flag = true;
			}
			Tip("Used when a monster's Weapon is <AUTO>.");
			flag |= ImGui.Checkbox("Shield with one-handed melee weapons##defshield", ref _s.DefaultShield);
			Tip("For monsters whose Off hand is <AUTO>: while fighting with a one-handed melee weapon, the shield on your Items list is put on.\nNot with a wand, a bow or a two-handed weapon. A row's own Off hand (a shield by name, <AUTO SHIELD>, <NONE>...) still wins.\n/mt set DefaultShield on|off");
			flag |= ImGui.Checkbox("Auto damage: use what the species is weakest to", ref _s.AutoElementBySpecies);
			Im.SetTooltipIfHovered("/mt set AutoElementBySpecies on|off");
			if (_s.AutoElementBySpecies)
			{
				ImGui.SameLine();
				flag |= ImGui.Checkbox("switching melee <-> bow for it##automm", ref _s.AutoSwitchMeleeMissile);
				Tip("With a melee or missile default attack and <AUTO> weapons: when a bow you carry does an element the monster is weaker to\nthan any melee weapon you carry (or the other way round), it's used - a monster immune to your sword's fire gets your lightning bow.\nOnly where the monster's Attack (Monsters tab) allows that kind. Off: only weapons of your default attack's kind.\n/mt set AutoSwitchMeleeMissile on|off");
			}
			Tip("For monsters whose damage is Auto (and an Auto default): the monster's species is looked up in VTank's game database\n(damage types best first) and the best one you have a wand / weapon for on the Items tab is used.\nNo nether in that list - a row set to Void (or any element) is used as set. Off: Auto works as before.");
			flag |= ImGui.Checkbox("Start the Tracking timer on my pet's hits too", ref _s.TimerOnPetHit);
			Tip("The Time column on the Tracking tab starts at your first debuff or attack on a monster.\nTicked: your pet's first hit on it starts it too (\"[Pet] ... hit <monster> for ...\").\n/mt set TimerOnPetHit on|off");
			flag |= ImGui.Checkbox("Start the Tracking timer when the void spread reaches it##timerspread", ref _s.TimerOnSpread);
			Tip("'Your void magic spreads to N more creatures': the monsters around the one cast on (within the spread's reach -\nthe 'Trust the void spread within' metres, else 10 m) start their Tracking timer then, as if you'd hit them.\n/mt set TimerOnSpread on|off");
			ImGui.SetNextItemWidth(160f);
			flag |= ImGui.SliderFloat("Melee/missile power %", ref _s.AttackPower, 5f, 100f, "%.0f");
			Tip("Melee power / missile accuracy for weapon attacks (like the power bar).\nAttacks are sent directly - no keys are pressed. Turn on auto-repeat attacks in AC's options.\n/mt set AttackPower <number>");
			string[] array = new string[3] { "High", "Medium", "Low" };
			for (int i = 0; i < array.Length; i++)
			{
				ImGui.SameLine();
				bool flag2 = _s.AttackHeight == i;
				ImGui.PushStyleColor(ImGuiCol.Button, flag2 ? new Vector4(0.15f, 0.55f, 0.2f, 1f) : new Vector4(0.25f, 0.27f, 0.3f, 1f));
				if (ImGui.SmallButton(array[i] + "##ah"))
				{
					_s.AttackHeight = i;
					flag = true;
				}
				ImGui.PopStyleColor();
				Tip("Weapon attacks hit " + array[i].ToLowerInvariant() + " (like AC's High / Medium / Low attack keys).");
			}
			flag |= ImGui.Checkbox("Stop VTank navigation while in combat", ref _s.HoldVTankNav);
			Tip("Holds VTank's navigation while monsters are in range, or while any monster you've\nDoT'd is still alive. VTank resumes its route a moment after the last one dies.\n/mt set HoldVTankNav on|off");
			if (_s.HoldVTankNav)
			{
				ImGui.SameLine();
				Im.TextColored(_engine.NavHeld ? Yellow : Grey, _engine.NavHeld ? "(nav held)" : "(nav free)");
			}
			flag |= ImGui.Checkbox("Swap weapons as little as possible", ref _s.FewerWeaponSwaps);
			Tip("Monsters whose row uses the weapon you're holding are attacked first - ahead of Priority - so it's only\nswapped when none of them are left. Vulns are cast with whatever wand is in hand (a slayer doesn't change them); DoTs use the row's wand (the slayer counts),\nand everything the wand in hand can do goes first.\nA focused monster and the weapon test still go first.\n/mt set FewerWeaponSwaps on|off");
			flag |= ImGui.Checkbox("Go on when the swap is done##confirmswaps", ref _s.ConfirmSwaps);
			Tip("Weapon swaps and combat mode changes: carry on as soon as the game shows them done (the wand in your hands,\nthe new mode) instead of waiting out the full Equip / Mode timers. Shortest waits and the extra settle time are on\nthe Tuning tab (Swap: ...). Off: the full timers, as before.\n/mt set ConfirmSwaps on|off");
			ImGui.SameLine(0f, 20f);
			flag |= ImGui.Checkbox("Equip the next pack's wand on the way##preequip", ref _s.PreEquipOnApproach);
			Tip("Following a route: when monsters come within the Tuning tab's \"Equip on the way\" distance (40 m), the wand most of\nthem need (their slayer) goes in hand while you're still walking, so the fight starts with the first cast.\n/mt set PreEquipOnApproach on|off");
			flag |= ImGui.Checkbox("Peace mode when idle after##peaceidle", ref _s.PeaceWhenIdle);
			Tip("Nothing in attack range, no corpses waiting and nothing being cast or buffed for this long:\nput weapons / wand away (peace mode). Running is faster and nothing drains while you travel.\nCombat picks the right mode again as soon as there's something to fight.\n/mt set PeaceWhenIdle on|off");
			ImGui.SameLine();
			ImGui.SetNextItemWidth(90f);
			flag |= ImGui.InputFloat("s##peaceidles", ref _s.PeaceIdleS, 1f, 5f, "%.0f");
			Im.SetTooltipIfHovered("/mt set PeaceIdleS <number>");
			if (_s.PeaceIdleS < 1f)
			{
				_s.PeaceIdleS = 1f;
			}
			ImGui.SameLine(0f, 20f);
			flag |= ImGui.Checkbox("Peace mode right away##peacenow", ref _s.PeaceRightAway);
			Tip("With Combat on: peace mode the moment the last monster in attack range dies - before looting, no wait.\nThe weapon / wand stays equipped (only the stance changes). Waits only for a cast still in the air, buffing,\nhealing, salvaging or aetheria. Works without the box on the left.\n/mt set PeaceRightAway on|off");
			ImGui.SameLine(0f, 20f);
			flag |= ImGui.Checkbox("Only with Nav on##peacenav", ref _s.PeaceOnlyNav);
			Tip("Both peace mode settings only do anything while Nav is on. With Nav off you stay in the stance you're in.\n/mt set PeaceOnlyNav on|off");
			flag |= ImGui.Checkbox("When surrounded, turn the least", ref _s.CloseTurnLeast);
			Tip("Monsters this close are taken in order of how little you have to turn - the one beside or behind\nyour last target next - instead of strictly the nearest. Priority still comes first.\n/mt set CloseTurnLeast on|off");
			ImGui.SameLine();
			ImGui.SetNextItemWidth(90f);
			flag |= ImGui.InputFloat("within m##closeturn", ref _s.CloseTurnRange, 0.5f, 1f, "%.1f");
			Im.SetTooltipIfHovered("/mt set CloseTurnRange <number>");
			if (_s.CloseTurnRange < 0.5f)
			{
				_s.CloseTurnRange = 0.5f;
			}
			ImGui.Unindent(8f);
		}
		if (ImGui.CollapsingHeader("Spell Duration###hdrdur"))
		{
			ImGui.Indent(8f);
			ImGui.SetNextItemWidth(120f);
			flag |= ImGui.InputInt("Duration augs", ref _s.DurationAugs);
			Im.SetTooltipIfHovered("/mt set DurationAugs <number>");
			ImGui.SetNextItemWidth(120f);
			flag |= ImGui.InputFloat("Known buff base (min)", ref _s.CalibBaseMinutes, 1f, 10f, "%.0f");
			Im.SetTooltipIfHovered("/mt set CalibBaseMinutes <number>");
			ImGui.SetNextItemWidth(120f);
			flag |= ImGui.InputFloat("Same buff in game (min)", ref _s.CalibObservedMinutes, 1f, 60f, "%.0f");
			Tip("Cast a buff whose base you know (level 8 creature = 90 min), read its duration in game,\nand enter both. The multiplier is applied to every vuln and DoT.\n/mt set CalibObservedMinutes <number>");
			Im.TextColored(Yellow, $"Buff multiplier: {_s.DurationMultiplier:0.##}x   (sheet's 5%/aug would be {1.0 + 0.05 * (double)_s.DurationAugs:0.##}x)");
			ImGui.SetNextItemWidth(120f);
			flag |= ImGui.InputFloat("Vuln/DoT duration multiplier", ref _s.DebuffMultiplier, 0.1f, 1f, "%.2f");
			Im.SetTooltipIfHovered("/mt set DebuffMultiplier <number>");
			if (_s.DebuffMultiplier < 0.1f)
			{
				_s.DebuffMultiplier = 0.1f;
			}
			Tip("How much longer than the spell sheet's base your vulns and DoTs last on monsters.\n103 = same as your buffs. Lower it if they wear off before being reapplied.");
			ImGui.SameLine();
			if (ImGui.SmallButton("Use buff multiplier"))
			{
				_s.DebuffMultiplier = _s.DurationMultiplier;
				flag = true;
			}
			ShowDurationExample("Corrosion", _s.Level1Dot);
			ShowDurationExample("Imperil", _s.Level1Vuln);
			ImGui.Unindent(8f);
		}
		if (ImGui.CollapsingHeader("Items###hdritems"))
		{
			ImGui.Indent(8f);
			flag |= ImGui.Checkbox("Open the backpack at login##openpack", ref _s.OpenPackAtLogin);
			Tip("Like Mag-Tools' Open Main Pack On Login: your main pack's window opens as you enter the world.\n/mt set OpenPackAtLogin on|off");
			flag |= ImGui.Checkbox("Pick up tracked items in loot range##trkpick", ref _s.TrackPickup);
			Tip("Items on the ground found by Tracking > List whose entry is ticked \"Pick up\" are picked up (you run over to them)\nwhen they're within loot range. Up to 3 tries each.\n/mt set TrackPickup on|off");
			ImGui.Indent(16f);
			flag |= ImGui.Checkbox("Stop for monsters on the way##detourfight", ref _s.DetourStopsForCombat);
			Tip("Going to pick up a tracked item (Pick up or Detour): a monster coming into attack range stops the run -\nit's fought first, then the item's gone for again (a run cut short doesn't count as one of its 3 tries).\n/mt set DetourStopsForCombat on|off");
			ImGui.Unindent(16f);
			flag |= ImGui.Checkbox("Loot items for QB stamps I don't have##lootqb", ref _s.LootQbStamps);
			Tip("Corpses and chests: an item whose name matches a QB stamp you haven't got yet (MelksQB's quest list) is picked up\nwhatever the loot profiles say - \"Second Half of a Battered Sword\" for SecondHalfBatteredSwordPickUp. Check chests lists it.\nNeeds MelksQB loaded (it says which stamps are still missing).\n/mt set LootQbStamps on|off");
			if (ImGui.Checkbox("Loot chests##lootchests", ref _s.LootChests))
			{
				if (_s.LootChests)
				{
					_s.CheckChests = false;
				}
				flag = true;
			}
			Tip("A chest you open is looted with every loot profile ticked on the Loot tab, whatever the Looting switch says.\nHousing storage is never touched.\n/mt set LootChests on|off");
			if (ImGui.Checkbox("Check chests##checkchests", ref _s.CheckChests))
			{
				if (_s.CheckChests)
				{
					_s.LootChests = false;
				}
				flag = true;
			}
			Tip("A chest you open is checked with every loot profile ticked on the Loot tab, whatever the Looting switch says:\nchat says what's in it that the profiles would take - nothing is taken; it goes on the Tracking tab with how many it holds that they want. Housing storage is never touched.\n/mt set CheckChests on|off");
			flag |= ImGui.Checkbox("Auto loot chests with Looting on##autochests", ref _s.AutoChests);
			Tip("While Looting is on, chests in loot range are opened and looted for you too, with every loot profile ticked on the Loot tab.\nHousing storage is never touched; a chest is only looked in again once it has locked again (that is when it refills).\n/mt set AutoChests on|off");
			ImGui.SameLine();
			flag |= ImGui.Checkbox("Pick locked chests##chestpick", ref _s.ChestPickLocks);
			Tip("Auto loot chests: a locked chest gets a lockpick from the Items tab (like Nav's doors) when your Lockpick skill is\nat least the door margin (Nav > Doors) over its lock - up to 6 tries. Without this, a locked chest is skipped.\n/mt set ChestPickLocks on|off");
			flag |= ImGui.Checkbox("Say when a chest has nothing##chestsummary", ref _s.ChestSummary);
			Tip("A chest checked or looted (any of the above) with nothing the profiles want gets a line:\n\"Dirty Old Crate scanned - No Loot Filter Matches\". (Items that match always get their own line.)\n/mt set ChestSummary on|off");
			flag |= ImGui.Checkbox("Check corpses##checkcorpses", ref _s.CheckCorpses);
			Tip("With Looting off (or MelkTank off): a corpse you open yourself is checked with every loot profile ticked on the Loot tab -\nchat says what's in it that the profiles would take; nothing is taken. (With Looting on, corpses are looted as usual.)\n/mt set CheckCorpses on|off");
			ImGui.SameLine();
			flag |= ImGui.Checkbox("Say when a corpse has nothing##corpsesummary", ref _s.CorpseSummary);
			Tip("With Looting off: a corpse you open with nothing the profiles want gets a line - \"Corpse of Drudge Skulker scanned -\nNo Loot Filter Matches\" (on its own, it also has corpses you open checked). Items that match always get their own line.\n/mt set CorpseSummary on|off");
			flag |= ImGui.Checkbox("Answer Yes to 100% pop-ups (tinkering)##mtyes100", ref _s.AutoYes100);
			Tip("Like Mag-Tools' Auto Click Yes on 100%: a yes/no pop-up that says 100% (tinkering's \"100% chance ... continue?\")\nis answered Yes before it shows. Anything less than 100% still asks you.\n/mt set AutoYes100 on|off");
			ImGui.Separator();
			flag |= ImGui.Checkbox("Stack items", ref _s.AutoStack);
			Tip("While on, everything that can stack is stacked, wherever it is. Main pack items go onto their stack in a side pack first,\nor else onto another stack in the main pack; stacks in side packs are merged with each other (smaller onto bigger).\nA full stack is skipped for another with room; with none it stays put.\n/mt set AutoStack on|off");
			ImGui.Separator();
			flag |= ImGui.Checkbox("Top up gear mana below", ref _s.ManaTopUp);
			Tip("Your worn and wielded items are appraised every 30 s. When any has less mana than this %, a mana stone\n(the ones on Items > Other Items first, top to bottom, then any infinite one) is used on you, which fills everything you have equipped.\n/mt set ManaTopUp on|off");
			ImGui.SameLine();
			ImGui.SetNextItemWidth(90f);
			flag |= ImGui.InputInt("%##manapct", ref _s.ManaTopUpPercent, 5, 10);
			Im.SetTooltipIfHovered("/mt set ManaTopUpPercent <number>");
			if (_s.ManaTopUpPercent < 1)
			{
				_s.ManaTopUpPercent = 1;
			}
			if (_s.ManaTopUpPercent > 99)
			{
				_s.ManaTopUpPercent = 99;
			}
			if (_s.ManaTopUp)
			{
				ImGui.SameLine();
				Im.TextColored(Grey, (_engine.Mana.Lowest.Length > 0) ? ("lowest: " + _engine.Mana.Lowest + ((_engine.Mana.Status.Length > 0) ? (" - " + _engine.Mana.Status) : "")) : "(reading your gear...)");
			}
			flag |= ImGui.Checkbox("Salvage what the loot profile marks Salvage", ref _s.AutoSalvage);
			Tip("Items looted by a rule with the Salvage action are salvaged when nothing is in attack range and no corpses are waiting:\nthe ust is opened, they go in, it's salvaged and the window closed. Needs a ust in your pack.\n/mt set AutoSalvage on|off");
			ImGui.SameLine();
			flag |= ImGui.Checkbox("with partial bags", ref _s.SalvagePartialBags);
			Tip("Also put in salvage bags with less than 100 units of the same material (or two or more partial bags of one\nmaterial), so they combine.\n/mt set SalvagePartialBags on|off");
			if (_s.AutoSalvage)
			{
				ImGui.SameLine();
				Im.TextColored(Grey, Salvager.Waiting.Count + " waiting" + ((_engine.Salvage.Status.Length > 0) ? (" - " + _engine.Salvage.Status) : ""));
			}
			flag |= ImGui.Checkbox("Chunk aetheria (Chunk rules)", ref _s.AutoChunkAetheria);
			Tip("When nothing is in attack range and every corpse is looted: each untuned Coalesced Aetheria whose first matching\nloot rule has the Chunk action gets your Lugian Aetheria Hammer used on it (peace mode first) - it becomes chunks.\n/mt set AutoChunkAetheria on|off");
			ImGui.SameLine();
			flag |= ImGui.Checkbox("Chunk corrupted weapons (Chunk rules)", ref _s.ChunkWeapons);
			Tip("The same for weapons a Chunk rule catches - only ones without an imbue (corrupted weapons; T11+ loot always has one).\nThey become powder.\n/mt set ChunkWeapons on|off");
			ImGui.SameLine();
			flag |= ImGui.Checkbox("Reveal aetheria (Reveal rules)", ref _s.RevealAetheria);
			Tip("The same for the Reveal action: an Aetheria Mana Stone is used on it (revealing its colour and surge).\nOff: Reveal rules still loot them, they just aren't revealed.\n/mt set RevealAetheria on|off");
			flag |= ImGui.Checkbox("Chunk even in a fight when more than", ref _s.ChunkForce);
			Tip("For low level spots that never go quiet: once more than this many items are waiting for the hammer,\nchunk them anyway, between casts / attacks (MelkTank goes to peace mode for each one, then back).\n/mt set ChunkForce on|off");
			ImGui.SameLine();
			ImGui.SetNextItemWidth(90f);
			flag |= ImGui.InputInt("waiting##chunkforce", ref _s.ChunkForceCount, 1, 5);
			if (_s.ChunkForceCount < 1)
			{
				_s.ChunkForceCount = 1;
			}
			if (_s.AutoChunkAetheria || _s.ChunkWeapons)
			{
				ImGui.SameLine();
				Im.TextColored(Grey, _engine.Aetheria.ChunkWaiting + " waiting");
			}
			if (_s.AutoChunkAetheria && _engine.Aetheria.Status.Length > 0)
			{
				ImGui.SameLine();
				Im.TextColored(Grey, _engine.Aetheria.Status);
			}
			ImGui.Separator();
			flag |= ImGui.Checkbox("Chat line for each looted item", ref _s.LootAnnounce);
			Im.SetTooltipIfHovered("/mt set LootAnnounce on|off");
			flag |= ImGui.Checkbox("Chat line for items I identify", ref _s.IdAnnounce);
			Tip("When you appraise an item, its stats go to chat:\nItemInfo: <matching rule> - <name>, <spells>, Wield ..., Craft, Value, BU, Mods [...]\nThe item name shows as a green item link.\n/mt set IdAnnounce on|off");
			ImGui.SameLine();
			ImGui.SetNextItemWidth(150f);
			string[] array2 = new string[5] { "in main chat", "in chat window 1", "in chat window 2", "in chat window 3", "in chat window 4" };
			int current_item2 = _s.IdChatWindow;
			if (ImGui.Combo("##idchatwin", ref current_item2, array2, array2.Length))
			{
				_s.IdChatWindow = current_item2;
				flag = true;
			}
			Tip("Where the identify lines (and the compare line) go: the main chat, or one of the game's floating chat windows.\nOpen the floating window first (the chat menu's window buttons) or the lines won't be seen.");
			ImGui.Indent(16f);
			if (!_s.IdAnnounce)
			{
				ImGui.BeginDisabled();
			}
			flag |= ImGui.Checkbox("... and for monsters##idmobs", ref _s.IdMobs);
			Tip("Identify a monster: Brown Rabbit - Level 4 - 5/5 Health D: 10 DR: 5 - No Essence Caught - No QB\n(D / DR only when it has them; Essence Caught / QB for Catch from the Dex).\n/mt set IdMobs on|off");
			ImGui.SameLine();
			flag |= ImGui.Checkbox("... and for players##idplayers", ref _s.IdPlayers);
			Tip("Identify a player: Name - Level 275 - Enl 3 - D: 20 CD: 15 DR: 30\n/mt set IdPlayers on|off");
			if (!_s.IdAnnounce)
			{
				ImGui.EndDisabled();
			}
			ImGui.Unindent(16f);
			flag |= ImGui.Checkbox("Compare to my weapon", ref _s.IdCompare);
			Tip("When you identify a weapon like the one you're wielding (same element for casters and bows, same weapon type for melee),\nadd a line comparing them. Colour: green better, yellow mixed, red worse - from\nwands: % vs. Monsters and Void Rend; bows: Damage Mod, Elemental Damage and rend; melee: damage and rend.\nArmor / jewelry / clothing: Damage Resist, Damage Rating, Crit Damage Rating and All Attributes as a % of the max (69)\nagainst the piece you wear there (rings / bracelets: the weaker of the two), and their total.\n/mt set IdCompare on|off");
			ImGui.Indent(16f);
			flag |= ImGui.Checkbox("Keep special pieces##keepspecial", ref _s.CompareKeepSpecial);
			Tip("A piece you wear with a slot special (Regeneration bracers, Fortify Vitals helm, Pct HP Damage gauntlets,\nBattle Mending chest, Cheat Death boots) is only compared against an item that has the same special and fits there -\nanything else is compared with your other places it can go (or says it would replace a special piece).\n/mt set CompareKeepSpecial on|off");
			ImGui.Unindent(16f);
			flag |= ImGui.Checkbox("Main weapon back in hand before looting", ref _s.LootMainWeapon);
			Tip("When the fight is over (nothing left to cast at - DoTs can still be ticking) and corpses are waiting,\nswap from a monster row's weapon (a slayer, say) back to the Default row's weapon before opening the first corpse,\nso loot is compared - and \"vs Equipped\" loot rules judged - against your main weapon.\nOnly swaps like for like (wand for wand ...). The next fight wields the row's weapon again.\nNot needed (and skipped) when a weapon is ticked \"Compare\" on the Items tab.\n/mt set LootMainWeapon on|off");
			flag |= BadItems.Draw(_s);
			ImGui.Unindent(8f);
		}
		if (ImGui.CollapsingHeader("Item giver###hdrgiver"))
		{
			ImGui.Indent(8f);
			Im.TextColored(Grey, "Hand items to someone: pick the target and the item, how many (0 = all), the delay, then Give.");
			if (ImGui.Checkbox("Show in the plugin bar##giverbar", ref _s.GiverInBar))
			{
				GiveWindow.SetInBar(_s.GiverInBar);
				flag = true;
			}
			Tip("Its icon in UtilityBelt.Service's plugin bar - click it to open / close the window.\n/mt set GiverInBar on|off");
			ImGui.SameLine(0f, 20f);
			if (ImGui.Button((GiveWindow.Visible ? "Hide" : "Show") + "##givershow"))
			{
				GiveWindow.Toggle();
			}
			Tip("Opens or closes the item giver window (also /mt giver).");
			ImGui.SameLine();
			if (ImGui.Button("Reset##giverreset"))
			{
				GiveWindow.ResetPosition();
			}
			Tip("Brings the window back to the middle of the screen (if it's been moved off it).");
			ImGui.Unindent(8f);
		}
		if (ImGui.CollapsingHeader("Item Hover###hdrhover"))
		{
			ImGui.Indent(8f);
			flag |= ImGui.Checkbox("Item panel when I hover an item##hoverinfo", ref _s.HoverInfoOn);
			Tip("Hover an item in your packs, on your paper doll or in an open corpse / chest: a panel beside the mouse shows\nthe loot rule that takes it (and its profile), its ItemInfo summary and how it compares with what you have on.\n/mt set HoverInfoOn on|off");
			ImGui.SameLine();
			flag |= ImGui.Checkbox("ask for its ID##hoverask", ref _s.HoverInfoAskId);
			Tip("An item that hasn't been identified yet is appraised when you hover it, so the panel can fill in.\n/mt set HoverInfoAskId on|off");
			if (!_s.HoverInfoOn)
			{
				ImGui.BeginDisabled();
			}
			Im.TextColored(Grey, "Show:");
			ImGui.SameLine();
			flag |= ImGui.Checkbox("Loot rule##hovloot", ref _s.HoverLootRule);
			Tip("Which loot profile and rule takes it, and what it does (keep, salvage...).\n/mt set HoverLootRule on|off");
			ImGui.SameLine();
			flag |= ImGui.Checkbox("Details##hovdet", ref _s.HoverDetails);
			Tip("The ItemInfo summary: spells, wield, craft, value, burden, mods / details.\n/mt set HoverDetails on|off");
			ImGui.SameLine();
			flag |= ImGui.Checkbox("Score##hovscore", ref _s.HoverScore);
			Tip("The numbers the loot rules use: armor / jewelry - the four mods as a % of the max, yours, and the difference;\ncasters - the damage gain overall and on the best slayer.\n/mt set HoverScore on|off");
			ImGui.SameLine();
			flag |= ImGui.Checkbox("Compare##hovcmp", ref _s.HoverCompare);
			Tip("The line comparing it with what you have on (or your Compare weapon / listed shield).\n/mt set HoverCompare on|off");
			ImGui.SameLine();
			flag |= ImGui.Checkbox("Compare colours##hovcol", ref _s.HoverColors);
			Tip("Colour the compare line like chat: green better, light green better overall (some lower),\nlight red worse overall (some higher), red worse.\n/mt set HoverColors on|off");
			if (!_s.HoverInfoOn)
			{
				ImGui.EndDisabled();
			}
			ImGui.Unindent(8f);
		}
		if (ImGui.CollapsingHeader("Areas###hdrareas"))
		{
			ImGui.Indent(8f);
			Im.TextColored(Yellow, "T11+");
			ImGui.Separator();
			flag |= ImGui.Checkbox("Count lum tokens as luminance earned##lumtok", ref _s.CountLumTokens);
			Tip("Thaelaryn Tokens of Luminance (the T11 and Banshee bounty rewards) count toward the Session's\nluminance earned and lum / hr when they land in your packs - whether you deposit them or not.\n/mt set CountLumTokens on|off");
			ImGui.SameLine();
			ImGui.SetNextItemWidth(90f);
			flag |= ImGui.InputFloat("B each##lumtokb", ref _s.LumTokenB, 1f, 10f, "%.0f");
			Im.SetTooltipIfHovered("/mt set LumTokenB <number>");
			if (_s.LumTokenB < 0f)
			{
				_s.LumTokenB = 0f;
			}
			Session.CountLumTokens = _s.CountLumTokens;
			Session.LumTokenValue = (double)_s.LumTokenB * 1000000000.0;
			flag |= ImGui.Checkbox("Use \"Gem of\" attack augmentation gems after looting##attackgems", ref _s.AutoUseAttackGems);
			Tip("Gem of War / Void / Melee / Missile Augmentation (hunting drops in T11+, +1 each): used as they land in your packs,\nonce the corpse is looted and you're not busy - one every 2 seconds. A gem that won't use (an old one) is left alone.\n/mt set AutoUseAttackGems on|off");
			if (AttackGems.Used > 0)
			{
				ImGui.SameLine();
				Im.TextDisabled("(" + AttackGems.Used + " used this session)");
			}
			ImGui.Separator();
			flag |= Session.DrawBountySettings(_s);
			int num = ((!_s.AugRatesFromTracker) ? 1 : 0);
			Im.Text("Augs lum/hr from");
			ImGui.SameLine();
			if (ImGui.RadioButton("Session > Lum (effective)##augsrc0", num == 0))
			{
				_s.AugRatesFromTracker = true;
				flag = true;
			}
			ImGui.SameLine();
			if (ImGui.RadioButton("MelkTank's own##augsrc1", num == 1))
			{
				_s.AugRatesFromTracker = false;
				flag = true;
			}
			Tip("The rate Session > Augs uses for its 'When' times.\nSession > Lum: its effective lum/hr (coins earned counted as luminance at your conversion rate) for When (all),\nits lum/hr for When (lum).\nMelkTank's own: the Session tab's lum/hr (last 60 min, else the whole session) for both. It starts again on a reload.");
			flag |= ImGui.Checkbox("Day / night pop-up##daynight", ref _s.DayNightHudOn);
			Tip("A small borderless pop-up: a sun or moon for whether it's day or night in Dereth, and the real minutes until it changes\n(like UB's Dereth Time). Drag it where you want it.\n/mt set DayNightHudOn on|off");
			flag |= _engine.Areas.Draw();
			ImGui.Unindent(8f);
		}
		if (ImGui.CollapsingHeader("Chat###hdrchat"))
		{
			ImGui.Indent(8f);
			flag |= ImGui.Checkbox("Log tells##telllog", ref _s.TellLog);
			Im.SetTooltipIfHovered("/mt set TellLog on|off");
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Every tell to and from you this session, for the phone's \"Tells only\" (all of them, not just the last 200 chat lines).");
			}
			ImGui.SameLine();
			if (!_s.TellLog)
			{
				ImGui.BeginDisabled();
			}
			flag |= ImGui.Checkbox("Keep them between sessions##tellkeep", ref _s.TellKeep);
			Im.SetTooltipIfHovered("/mt set TellKeep on|off");
			if (!_s.TellLog)
			{
				ImGui.EndDisabled();
			}
			if (ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenDisabled))
			{
				Im.SetTooltip("Stored in Logs\\<character>\\MelkTank_Tells_<character>.txt - otherwise a new session starts with none.");
			}
			ImGui.Separator();
			flag |= ChatFilters.Draw(_s);
			ChatFilter.Draw();
			ImGui.Unindent(8f);
		}
		if (ImGui.CollapsingHeader("Import from Virindi Tank / Virindi Sense###hdrvtimp"))
		{
			ImGui.Indent(8f);
			flag |= VTankImport.Draw(_s, AddItem);
			ImGui.Unindent(8f);
		}
		if (ImGui.CollapsingHeader("Mini control window###hdrmini"))
		{
			ImGui.Indent(8f);
			flag |= ImGui.Checkbox("Show the mini control window##minishow", ref _s.MiniShow);
			Tip("The small window with the Master / Combat / Nav / Loot ... switches. Also: /mtank mini [on|off|reset],\nor its icon on UtilityBelt's bar.\n/mt set MiniShow on|off");
			ImGui.SameLine();
			if (ImGui.SmallButton("Put it back on screen##minireset"))
			{
				MiniReset?.Invoke();
				flag = true;
			}
			Tip("Moves it to the top left of the game window and shows it - if it ended up off screen (after a resolution change, say).");
			ImGui.Unindent(8f);
		}
		if (ImGui.CollapsingHeader("Windows at login###hdrwin"))
		{
			ImGui.Indent(8f);
			_engine.Windows.Draw();
			ImGui.Unindent(8f);
		}
		if (flag)
		{
			_saveAll();
		}
	}

	private void DrawDebugTab()
	{
		bool flag = false;
		flag |= ImGui.Checkbox("Log max health changes##maxhplog", ref _s.MaxHpLog);
		Tip("A MAXHP line in the debug log whenever the game's max health (or the max MelkTank uses) changes,\nwith health at that moment and the spells that came on or went off since the last line.\n/mt set MaxHpLog on|off");
		if (ImGui.CollapsingHeader("Timing - where MelkTank's time goes###perfhdr"))
		{
			Im.TextColored(Grey, Perf.FrameMsPerSec.ToString("0.0") + " ms of every second (" + (Perf.FrameMsPerSec / 10.0).ToString("0.0") + "%) at " + Perf.Fps + " fps. Updated every 5 s; /mtank perf prints the top ones.");
			if (ImGui.BeginTable("##perf", 5, ImGuiTableFlags.RowBg | ImGuiTableFlags.BordersInnerV | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY, new Vector2(0f, 230f)))
			{
				ImGui.TableSetupScrollFreeze(0, 1);
				ImGui.TableSetupColumn("Part", ImGuiTableColumnFlags.WidthStretch);
				ImGui.TableSetupColumn("ms / s (avg)", ImGuiTableColumnFlags.WidthFixed, 90f);
				ImGui.TableSetupColumn("ms / s (now)", ImGuiTableColumnFlags.WidthFixed, 90f);
				ImGui.TableSetupColumn("longest (ms)", ImGuiTableColumnFlags.WidthFixed, 90f);
				ImGui.TableSetupColumn("runs / s", ImGuiTableColumnFlags.WidthFixed, 70f);
				ImGui.TableHeadersRow();
				foreach (Perf.Part item in Perf.Sorted())
				{
					ImGui.TableNextRow();
					ImGui.TableNextColumn();
					Im.Text(item.Name);
					ImGui.TableNextColumn();
					Im.Text(item.AvgMsPerSec.ToString("0.00"));
					ImGui.TableNextColumn();
					Im.Text(item.MsPerSec.ToString("0.00"));
					ImGui.TableNextColumn();
					if (item.MaxMs >= 8.0)
					{
						Im.TextColored(new Vector4(1f, 0.6f, 0.3f, 1f), item.MaxMs.ToString("0.0"));
					}
					else
					{
						Im.Text(item.MaxMs.ToString("0.0"));
					}
					ImGui.TableNextColumn();
					Im.Text(item.CallsPerSec.ToString());
				}
				ImGui.EndTable();
			}
			Tip("A frame at 60 fps is 16.7 ms. \"longest\" in orange (8 ms or more) is a hitch you could feel.\nIndented rows are inside Combat engine.");
			if (ImGui.Checkbox("Perf log##perflog", ref _s.PerfLog))
			{
				flag = true;
			}
			Tip("Every minute: this table is written to Logs\\<character>\\MelkTank_Perf_<character>.txt (the latest only) and one line\n(time, total, fps, the top parts) is added to MelkTank_PerfLog_<character>.txt - how it went over a session.\nOff: nothing is written (/mtank perf still writes the table once).\n/mt set PerfLog on|off");
		}
		flag |= ImGui.Checkbox("Debug log", ref _s.DebugLog);
		Tip("Writes every cast, every 'You cast' line and every status change to MelkTank_debug_[character].txt\nin Logs\\[character] (one per character; the older half is dropped past the Tuning size cap), with millisecond times.\n/mt set DebugLog on|off");
		_engine.PreloadDebug();
		bool liveDebug = _engine.LiveDebug;
		if (liveDebug)
		{
			ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(0.15f, 0.55f, 0.25f, 1f));
		}
		if (ImGui.Button(liveDebug ? "Live debug: on" : "Live debug: off"))
		{
			_engine.LiveDebug = !liveDebug;
		}
		if (liveDebug)
		{
			ImGui.PopStyleColor();
		}
		Tip("On: the debug lines go into the list below as they happen, even with Debug log (the file) off.\nOff: the list only fills while Debug log is on. Not saved - off after a relog.");
		ImGui.SameLine();
		if (ImGui.Button("Clear##dbgclear"))
		{
			lock (_engine.DebugLines)
			{
				_engine.DebugLines.Clear();
			}
		}
		ImGui.SameLine();
		if (ImGui.Button("Copy##dbgcopy"))
		{
			lock (_engine.DebugLines)
			{
				ImGui.SetClipboardText(string.Join("\n", _engine.DebugLines.ToArray()));
			}
		}
		Tip("Copies the lines to the clipboard, to paste them somewhere.");
		ImGui.SameLine();
		Im.TextColored(Grey, (_s.DebugLog || _engine.LiveDebug) ? ("last " + 100 + " lines, newest at the bottom") : "Debug log and Live debug are both off - nothing new comes in");
		if (ImGui.BeginChild("dbglines", new Vector2(0f, ImGui.GetContentRegionAvail().Y * 0.5f), border: true, ImGuiWindowFlags.HorizontalScrollbar))
		{
			string[] array;
			lock (_engine.DebugLines)
			{
				array = _engine.DebugLines.ToArray();
			}
			bool flag2 = ImGui.GetScrollY() >= ImGui.GetScrollMaxY() - 4f;
			string[] array2 = array;
			foreach (string text in array2)
			{
				ImGui.TextUnformatted(text);
			}
			if (flag2 && _engine.DebugSeq != _dbgShown)
			{
				ImGui.SetScrollHereY(1f);
			}
			_dbgShown = _engine.DebugSeq;
		}
		ImGui.EndChild();
		Im.TextColored(Cyan, "Item / monster info");
		ImGui.SameLine();
		if (ImGui.Button("Dump value"))
		{
			ObjectDump.DumpSelected();
		}
		Tip("Writes everything readable off the selected item, monster or pet - every property, value, spell - to\nLogs\\MelkTank_Dump.txt. Items show more once they've been identified.");
		ImGui.SameLine();
		if (ImGui.Button("List actions"))
		{
			ObjectDump.DumpActionMethodNames();
		}
		Tip("Writes the names of every Decal action (Core.Actions) to MelkTank_Dump.txt.");
		PetSummoner current2 = PetSummoner.Current;
		if (current2 != null)
		{
			ImGui.SameLine();
			if (ImGui.Button(current2.DispatchLogOn ? "Dispatch log: on" : "Dispatch log: off"))
			{
				current2.SetDispatchLog(!current2.DispatchLogOn);
			}
			Tip("Counts the server's message types while on - for finding the message something sends.");
			ImGui.SameLine();
			if (ImGui.Button("Report##dispatch"))
			{
				current2.ReportDispatchLog();
			}
			Tip("Writes the counts to MelkTank_DispatchLog.txt.");
			ImGui.SameLine();
			bool v = current2.DebugDumps;
			if (ImGui.Checkbox("Echo dumps", ref v))
			{
				current2.DebugDumps = v;
			}
			Tip("Dumps a pet essence before and after Apply Echoes (Pets > Echoes) to MelkTank_Dump.txt. Not saved.");
		}
		Im.TextColored(Cyan, "Caught messages");
		Tip("Chat lines that match a trigger in Settings\\MelkTank_Catch.txt - kept here and written to\nLogs\\MelkTank_Caught.txt with their time, so login text can't push them out of sight.\nEdit MelkTank_Catch.txt any time (on|off, name, pattern - a regex); it's read again within 2 s.");
		lock (Catcher.Triggers)
		{
			int count = Catcher.Triggers.Count;
			int val = (count + 1) / 2;
			for (int j = 0; j < count; j++)
			{
				Catcher.Trigger trigger = Catcher.Triggers[j];
				if (j % Math.Max(1, val) != 0)
				{
					ImGui.SameLine();
				}
				bool v2 = trigger.On;
				if (ImGui.Checkbox(trigger.Name + "##catch" + trigger.Name + trigger.Pattern, ref v2))
				{
					Catcher.SetOn(trigger, v2);
				}
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip("Pattern: " + trigger.Pattern);
				}
			}
		}
		if (ImGui.Button("Clear##catchclear"))
		{
			lock (Catcher.Lines)
			{
				Catcher.Lines.Clear();
			}
		}
		ImGui.SameLine();
		if (ImGui.Button("Copy##catchcopy"))
		{
			lock (Catcher.Lines)
			{
				ImGui.SetClipboardText(string.Join("\n", Catcher.Lines.ToArray()));
			}
		}
		if (Catcher.Problem.Length > 0)
		{
			ImGui.SameLine();
			Im.TextColored(new Vector4(0.95f, 0.35f, 0.35f, 1f), Catcher.Problem);
		}
		if (ImGui.BeginChild("catchlines", new Vector2(0f, -2f), border: true, ImGuiWindowFlags.HorizontalScrollbar))
		{
			string[] array3;
			lock (Catcher.Lines)
			{
				array3 = Catcher.Lines.ToArray();
			}
			bool flag3 = ImGui.GetScrollY() >= ImGui.GetScrollMaxY() - 4f;
			string[] array4 = array3;
			foreach (string text2 in array4)
			{
				ImGui.TextUnformatted(text2);
			}
			if (flag3 && Catcher.Seq != _catchShown)
			{
				ImGui.SetScrollHereY(1f);
			}
			_catchShown = Catcher.Seq;
		}
		ImGui.EndChild();
		if (flag)
		{
			_saveAll();
		}
	}

	private void DrawAdvanced()
	{
		bool flag = false;
		if (ImGui.CollapsingHeader("Server: " + ServerMode.Name + "###hdrserver"))
		{
			ImGui.Indent(8f);
			string[] array = new string[3] { "Auto (by the server's name)", "Infinite Leaftide", "Standard (retail-like)" };
			ImGui.SetNextItemWidth(230f);
			if (ImGui.Combo("Server##serverkind", ref _s.ServerKind, array, array.Length))
			{
				flag = true;
			}
			Tip("Standard turns off Infinite Leaftide's own features: XP past max (Attr), augs, tier 11+, bounties, the bank,\ndeeds, enlightenment (auto enlighten, medallions), essence catching, potency, Savage Echoes, charms and Nether Fracture -\nand casts spells of every level. Auto: Infinite Leaftide when the server's name has Leaftide in it, else Standard.");
			bool ilt = ServerMode.Ilt;
			if (!ilt)
			{
				ImGui.BeginDisabled();
			}
			bool v = ServerMode.AllLevels;
			if (ImGui.Checkbox("Cast every spell level##allspelllevels", ref v))
			{
				_s.AllSpellLevels = v;
				flag = true;
			}
			if (!ilt)
			{
				ImGui.EndDisabled();
			}
			Tip("Buffs and combat spells at the best level the character can cast right now - known, enough skill and the components in\nthe pack - instead of only level 1 / level 8. Always on for a standard server.\nBuffs count as up whatever level of them is on you; debuff timers use that level's duration.");
			if (ServerMode.AllLevels)
			{
				ImGui.SetNextItemWidth(110f);
				if (ImGui.InputInt("skill over difficulty##spellmargin", ref _s.SpellSkillMargin, 5, 10))
				{
					if (_s.SpellSkillMargin < -50)
					{
						_s.SpellSkillMargin = -50;
					}
					flag = true;
				}
				Tip("A level is cast when your magic skill is at least its difficulty plus this (0 = about a coin flip, 20 ~ 65%, 50 ~ 80%).\n/mt set SpellSkillMargin <number>");
				ImGui.SameLine();
				flag |= ImGui.Checkbox("Need the components##checkcomps", ref _s.CheckComponents);
				Tip("Only levels whose components are in your pack (your own formula: scarab, tapers - Prismatic Tapers count for any -\nherbs, powders, potions, talismans; a Foci of the school covers all but the scarab and tapers).\nOff for a server that doesn't use components.\n/mt set CheckComponents on|off");
			}
			ImGui.Unindent(8f);
		}
		if (ImGui.CollapsingHeader("Ghost monsters###hdrghost"))
		{
			ImGui.Indent(8f);
			Im.TextColored(Grey, "Monsters the game still shows that the server no longer has (died out of sight, or gone): swung at with no\nhit, evade or health drop, they're skipped for a while instead of swung at forever.");
			flag |= ImGui.Checkbox("Skip monsters that aren't really there##ghostchk", ref _s.GhostCheck);
			Tip("Off: never skip a monster for this (it's swung at until it dies or something else takes over).\n/mt set GhostCheck on|off");
			if (!_s.GhostCheck)
			{
				ImGui.BeginDisabled();
			}
			ImGui.SetNextItemWidth(110f);
			if (ImGui.InputFloat("seconds with no sign before it's a ghost##ghosts", ref _s.GhostSeconds, 1f, 5f, "%.0f"))
			{
				_s.GhostSeconds = Math.Max(3f, Math.Min(300f, _s.GhostSeconds));
				flag = true;
			}
			Tip("How long melee / missile attacks can go on without one of your hits landing, the monster evading, or (below)\nits health going down, before it's taken for a ghost. Raise it for very tough monsters.\n/mt set GhostSeconds <seconds>   (3 - 300, default 12)");
			ImGui.SetNextItemWidth(110f);
			if (ImGui.InputFloat("seconds to leave a ghost alone##ghostfor", ref _s.GhostSkipSeconds, 10f, 60f, "%.0f"))
			{
				_s.GhostSkipSeconds = Math.Max(5f, Math.Min(3600f, _s.GhostSkipSeconds));
				flag = true;
			}
			Tip("After that it's a target again (if it's still shown).\n/mt set GhostSkipSeconds <seconds>   (5 - 3600, default 120)");
			flag |= ImGui.Checkbox("Its health going down counts as a sign it's there##ghosthp", ref _s.GhostHealthCounts);
			Tip("The health bar of the selected monster dropping keeps it from being called a ghost, even when the hit lines\naren't recognised.\n/mt set GhostHealthCounts on|off");
			if (!_s.GhostCheck)
			{
				ImGui.EndDisabled();
			}
			ImGui.Unindent(8f);
		}
		Im.TextColored(Grey, "Timers and distances MelkTank works with. Changed values show yellow; the button after one puts it back.");
		ImGui.SetNextItemWidth(220f);
		ImGui.InputTextWithHint("##advflt", "filter...", ref _advFilter, 60u);
		ImGui.SameLine();
		if (ImGui.Button("Reset all to defaults"))
		{
			foreach (Tuning.Entry item in Tuning.All)
			{
				item.Value = item.Default;
			}
			flag = true;
		}
#if RETAIL
		if (ImGui.CollapsingHeader("VTank replacement###hdrvtrepl"))
		{
			ImGui.Indent(8f);
			Im.TextColored(Grey, "What MelkTank does so the game runs with Virindi Tank switched off in Decal.");
			bool flag2 = false;
			flag2 |= ImGui.Checkbox("Give UtilityBelt VTank's library (uTank2)##vtsi", ref _s.VtStandIn);
			Tip("UtilityBelt asks for VTank's library every time it writes to chat. With VTank off it can't find it and fills\nexceptions.txt and chat with errors; this hands it VTank's file (only loaded - VTank itself doesn't start).\nUB asks as it starts: a change applies from the next login.\n/mt set VtStandIn on|off");
			flag2 |= ImGui.Checkbox("Give UtilityBelt the other Virindi libraries (VirindiHUDs, Views, Chat)##vtsiv", ref _s.VtStandInVirindi);
			Tip("With VTank off nothing loads VirindiHUDs (and friends) for UtilityBelt, so UB stops part way through starting:\nno /ub commands, no getvar / setvar for metas, and a UB icon for every try. This hands it the files from\nthe VirindiPlugins folder. A change applies from the next login.\n/mt set VtStandInVirindi on|off");
			flag2 |= ImGui.Checkbox("Run /vt commands from metas and routes##vtcmd", ref _s.VtCommands);
			Tip("While a meta runs, /vt lines it or a route sends (mexec, addnavpt, opendoors ...) are done by MelkTank\ninstead of going to VTank.\n/mt set VtCommands on|off");
			flag2 |= ImGui.Checkbox("Stop UtilityBelt waiting for VTank's loot profile##vtublw", ref _s.VtUbLootWatch);
			Tip("UB's inventory tool asks VTank for its loot profile on every radar update until it gets one - with VTank off\nthat throws each time (red \"RadarUpdate threw an error ... InventoryManager\" lines). This takes that check off.\n/mt set VtUbLootWatch on|off");
			flag2 |= ImGui.Checkbox("Use the running UtilityBelt when it's loaded more than once##vtlive", ref _s.VtLiveUb);
			Tip("Meta expressions (getvar, setvar ...) go to the UtilityBelt copy that has them set up - an old copy left\nfrom a failed start doesn't, and conditions then never come true.\n/mt set VtLiveUb on|off");
			if (flag2)
			{
				_s.ApplyVt();
				flag = true;
			}
			ImGui.Unindent(8f);
		}
		if (ImGui.CollapsingHeader("UtilityBelt replacement###hdrubrepl"))
		{
			ImGui.Indent(8f);
			Im.TextColored(Grey, "What MelkTank does so you can switch UtilityBelt off.");
			flag |= ImGui.Checkbox("Do UtilityBelt's /ub commands##ubnative", ref _s.UbNative);
			Tip("/ub use, select, give, jump, face, combatstate, fellow (quit / disband / open / close / recruit / dismiss / leader)\nand resolution are done by MelkTank, with UB's syntax - from metas, routes, login commands, MelkTank itself\nand what you type. UB doesn't get them (so they never run twice). Others (fellow create ...) still go to UB.\n/mt set UbNative on|off");
			flag |= ImGui.Checkbox("Stop drawing the 3D world##videokill", ref _s.VideoKill);
			Tip("UtilityBelt's VideoPatch: the game stops drawing the world (much less CPU / GPU); it still runs, and MelkTank's\nwindows and chat still draw. Click the window to wake it. Name tags hide while it's blank.\nIf UB's own VideoPatch is on, MelkTank's waits (turn UB's off to use this one).\n/mt set VideoKill on|off");
			ImGui.SameLine();
			flag |= ImGui.Checkbox("only when the game isn't the active window##videokillbg", ref _s.VideoKillBgOnly);
			Im.SetTooltipIfHovered("/mt set VideoKillBgOnly on|off");
			if (ImGui.Checkbox("Run meta expressions with MelkTank's own engine##ownexpr", ref _s.OwnExpr))
			{
				_s.ApplyVt();
				flag = true;
			}
			Tip("getvar / setvar / @pvars / &gvars, wobject..., list..., dict..., coordinates, quest flags (/myquests) and the rest of\nUtilityBelt's expression language, done by MelkTank - so metas work with UB off. /ub mexec and /vt mexec use it too.\nSaved @ and & variables are copied from UB the first time (while UB is still loaded).\nUnticked: UB's engine (UB must be loaded).\n/mt set OwnExpr on|off");
			Im.TextColored(Grey, "Attributes from XP: Session > Attr.");
			ImGui.Unindent(8f);
		}
		if (ImGui.CollapsingHeader("Mag-Tools replacement###hdrmtrepl"))
		{
			ImGui.Indent(8f);
			Im.TextColored(Grey, "What MelkTank does so you can switch Mag-Tools off.");
			flag |= ImGui.Checkbox("Do Mag-Tools' /mt commands from metas and routes##mtcmd", ref _s.MtCommands);
			Tip("/mt use / give / select / jump / face / combatstate / fellow are done as the matching /ub command,\n/mt drop drops from the pack, /mt click yes|no answers the yes/no pop-up - so metas don't need Mag-Tools.\nOthers (/mt send ...) are passed on as typed.\n/mt set MtCommands on|off");
			flag |= ImGui.Checkbox("Answer Yes to 100% pop-ups (tinkering)##mtyes100b", ref _s.AutoYes100);
			Tip("Same switch as Settings > Basic > Items: a yes/no pop-up that says 100% (\"100% chance ... continue?\") is answered Yes.\n/mt set AutoYes100 on|off");
			Im.TextColored(Grey, "Login / periodic commands: Settings > Commands (Import from Mag-Tools there).");
			ImGui.Unindent(8f);
		}
#endif
		if (ImGui.BeginChild("advlist", new Vector2(0f, 0f), border: false))
		{
			string f = _advFilter.Trim();
			string[] categories = Tuning.Categories;
			foreach (string cat in categories)
			{
				List<Tuning.Entry> list = Tuning.All.FindAll((Tuning.Entry e) => e.Category == cat && (f.Length == 0 || e.Label.IndexOf(f, StringComparison.OrdinalIgnoreCase) >= 0 || cat.IndexOf(f, StringComparison.OrdinalIgnoreCase) >= 0 || (e.Tip ?? "").IndexOf(f, StringComparison.OrdinalIgnoreCase) >= 0));
				if (list.Count == 0)
				{
					continue;
				}
				int count = list.FindAll((Tuning.Entry e) => e.Value != e.Default).Count;
				if (f.Length > 0)
				{
					ImGui.SetNextItemOpen(is_open: true);
				}
				if (!ImGui.CollapsingHeader(cat + ((count > 0) ? ("  (" + count + " changed)") : "") + "###adv" + cat))
				{
					continue;
				}
				ImGui.Indent(8f);
				if (ImGui.BeginTable("advt" + cat, 4, ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
				{
					ImGui.TableSetupColumn("name", ImGuiTableColumnFlags.WidthFixed, 260f);
					ImGui.TableSetupColumn("value", ImGuiTableColumnFlags.WidthFixed, 130f);
					ImGui.TableSetupColumn("unit", ImGuiTableColumnFlags.WidthFixed, 40f);
					ImGui.TableSetupColumn("reset", ImGuiTableColumnFlags.WidthStretch);
					foreach (Tuning.Entry item2 in list)
					{
						ImGui.PushID(item2.Key);
						ImGui.TableNextRow();
						ImGui.TableSetColumnIndex(0);
						bool flag2 = item2.Value != item2.Default;
						if (flag2)
						{
							Im.TextColored(Yellow, item2.Label);
						}
						else
						{
							ImGui.TextUnformatted(item2.Label);
						}
						Tip(item2.Tip + (string.IsNullOrEmpty(item2.Tip) ? "" : "\n") + "Default " + Fmt(item2, item2.Default) + " " + item2.Unit + "  (" + Fmt(item2, item2.Min) + " to " + Fmt(item2, item2.Max) + ")");
						ImGui.TableSetColumnIndex(1);
						ImGui.SetNextItemWidth(-1f);
						if (item2.Whole)
						{
							int v2 = (int)Math.Round(item2.Value);
							if (ImGui.InputInt("##v", ref v2, (int)Math.Max(1.0, item2.Step), (int)Math.Max(1.0, item2.Step * 10.0)))
							{
								item2.Value = Math.Max(item2.Min, Math.Min(item2.Max, v2));
								flag = true;
							}
						}
						else
						{
							double v3 = item2.Value;
							if (ImGui.InputDouble("##v", ref v3, (item2.Step > 0.0) ? (item2.Step / 5.0) : 0.1, item2.Step, "%.2f"))
							{
								item2.Value = Math.Max(item2.Min, Math.Min(item2.Max, v3));
								flag = true;
							}
						}
						ImGui.TableSetColumnIndex(2);
						Im.TextColored(Grey, item2.Unit);
						ImGui.TableSetColumnIndex(3);
						if (flag2 && ImGui.SmallButton("default (" + Fmt(item2, item2.Default) + ")"))
						{
							item2.Value = item2.Default;
							flag = true;
						}
						ImGui.PopID();
					}
					ImGui.EndTable();
				}
				ImGui.Unindent(8f);
			}
		}
		ImGui.EndChild();
		if (flag)
		{
			_saveAll();
		}
	}

	private static string Fmt(Tuning.Entry e, double v)
	{
		return e.Whole ? ((int)Math.Round(v)).ToString() : v.ToString("0.##");
	}

	private bool DrawHealing()
	{
		bool flag = false;
		bool flag2 = !Healer.HasHealItems(_s);
		if (flag2)
		{
			ImGui.PushStyleColor(ImGuiCol.Text, Purple);
		}
		flag |= ImGui.Checkbox("Heal with kit below", ref _s.HealEnabled);
		Im.SetTooltipIfHovered("/mt set HealEnabled on|off");
		if (flag2)
		{
			ImGui.PopStyleColor();
		}
		Tip((flag2 ? "No healing kit or health potion set - add one on the Items tab (select it, Add Selected).\n\n" : "") + "Uses the healing kit and Health items on the Items tab, top to bottom - the first one you still have\n(potions are drunk one every 3 seconds).\nWhen health drops below this %, stops casting and attacking and uses the healing kit\nevery half second until 'You heal yourself' shows up, then carries on.\nWorks even with combat off.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		flag |= ImGui.InputFloat("%##healpct", ref _s.HealPercent, 1f, 5f, "%.0f");
		Im.SetTooltipIfHovered("/mt set HealPercent <number>");
		if (_s.HealPercent < 1f)
		{
			_s.HealPercent = 1f;
		}
		if (_s.HealPercent > 99f)
		{
			_s.HealPercent = 99f;
		}
		ImGui.SameLine();
		double num = _engine.Healer.HealthPercent(out var cur, out var max);
		Im.TextColored(_engine.Healer.Active ? Red : Grey, (num < 0.0) ? "(now: --)" : ("(now: " + num.ToString("0") + "%  " + cur + "/" + max + ")"));
		ImGui.SameLine();
		Tip("Max health is the server's own number (asked every 30 s), so the % is right in tier 11+ too." + ((Healer.ServerMax > 0) ? ("\nServer's max health: " + Healer.ServerMax + ".") : ("\nThe server hasn't answered yet - until it does, the game's max (" + _engine.Healer.LastEffective + ") is used.")));
		flag |= DrawVital("Mana", ref _s.ManaEnabled, ref _s.ManaPercent, ref _s.ManaMode, ref _s.ManaItemId, ref _s.ManaItemName, "Stamina to Mana spell", _engine.Vitals.ManaSpellName());
		flag |= DrawVital("Stamina", ref _s.StaminaEnabled, ref _s.StaminaPercent, ref _s.StaminaMode, ref _s.StaminaItemId, ref _s.StaminaItemName, "Revitalize spell", _engine.Vitals.StaminaSpellName());
		Im.Text("On death, turn off:");
		ImGui.SameLine();
		flag |= ImGui.Checkbox("Combat##dth", ref _s.DeathStopCombat);
		Im.SetTooltipIfHovered("/mt set DeathStopCombat on|off");
		ImGui.SameLine();
		flag |= ImGui.Checkbox("Buffing##dth", ref _s.DeathStopBuff);
		Im.SetTooltipIfHovered("/mt set DeathStopBuff on|off");
		ImGui.SameLine();
		flag |= ImGui.Checkbox("Looting##dth", ref _s.DeathStopLoot);
		Im.SetTooltipIfHovered("/mt set DeathStopLoot on|off");
		ImGui.SameLine();
		flag |= ImGui.Checkbox("Summoning##dth", ref _s.DeathStopPet);
		Tip("When you die, the ticked ones are switched off (and stay off until you turn them back on).\n/mt set DeathStopPet on|off");
		return flag;
	}

	private bool DrawVital(string label, ref bool on, ref float pct, ref int mode, ref int itemId, ref string itemName, string spellLabel, string spellName)
	{
		bool flag = false;
		flag |= ImGui.Checkbox(label + " below##v" + label, ref on);
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		flag |= ImGui.InputFloat("%##vp" + label, ref pct, 1f, 5f, "%.0f");
		if (pct < 1f)
		{
			pct = 1f;
		}
		if (pct > 99f)
		{
			pct = 99f;
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(170f);
		string[] items = new string[2] { "Kit / potion", spellLabel };
		if (ImGui.Combo("##vm" + label, ref mode, items, 2))
		{
			flag = true;
		}
		ImGui.SameLine();
		if (mode == 0)
		{
			WeaponKind weaponKind = ((label == "Mana") ? WeaponKind.ManaKit : WeaponKind.StaminaKit);
			int num = 0;
			string text = null;
			foreach (WeaponItem item in _s.Items)
			{
				if (item.Kind == weaponKind)
				{
					num++;
					if (text == null && ItemInfo.CountInPack(item.Name) > 0)
					{
						text = item.Name;
					}
				}
			}
			if (num == 0)
			{
				Im.TextColored(Purple, "(add one on the Items tab)");
			}
			else if (text == null)
			{
				Im.TextColored(Red, "(none left)");
			}
			else
			{
				Im.TextColored(Green, text);
			}
			Tip("Uses the " + label.ToLowerInvariant() + " kits and potions on the Items tab, top to bottom - the first one you still have.\nAdd them there with Add Selected; reorder with the arrows.");
		}
		else
		{
			Im.TextColored((spellName == null) ? Purple : Green, spellName ?? "(you don't know it)");
			Tip("Cast on yourself (the highest level you know). Needs magic mode - you holding a wand.");
		}
		ImGui.SameLine();
		double num2 = ((label == "Mana") ? _engine.Vitals.ManaPercent(out var cur, out var max) : _engine.Vitals.StaminaPercent(out cur, out max));
		Im.TextColored(Grey, (num2 < 0.0) ? "(now: --)" : ("(now: " + num2.ToString("0") + "%  " + cur + "/" + max + ")"));
		return flag;
	}

	private void ShowDurationExample(string familyKey, bool level1)
	{
		if (SpellData.Families.TryGetValue(familyKey, out var value))
		{
			SpellLevel spellLevel = (level1 ? value.Levels[0] : value.Levels[7]);
			if (spellLevel != null)
			{
				TimeSpan t = SpellBook.Duration(spellLevel, _s);
				Im.TextDisabled($"  {spellLevel.Name}: {spellLevel.BaseDurationSeconds}s base -> {FormatSpan(t)}");
			}
		}
	}

	private void DrawMonsters()
	{
		if (!ImGui.BeginTabBar("monlists"))
		{
			return;
		}
		if (ImGui.BeginTabItem("Main list" + ((_s.ActiveProfile.Length > 0) ? (": " + _s.ActiveProfile) : "") + "###ml0"))
		{
			DrawProfileBar();
			ImGui.SameLine(0f, 20f);
			if (ImGui.Checkbox("Monster log", ref _s.MonsterLogOn))
			{
				MonsterLog.Toggled(_s.MonsterLogOn);
				_saveAll();
			}
			Tip("Every new monster you come across that no row of this list covers gets its own row (a copy of its family's row,\nelse of DEFAULT), saved to the profile that's loaded. Each new name (once a session) is also written to\nMelkTank_MonsterNames.csv (name, species, level, landblock, where), with a full dump in MelkTank_MonsterProbe.txt.\n/mt set MonsterLogOn on|off");
			if (DrawMonsterTable(_s.Monsters, isMain: true))
			{
				_s.SaveMonsters();
			}
			ImGui.EndTabItem();
		}
		for (int i = 0; i < 2; i++)
		{
			string text = _s.ExtraProfile[i];
			if (ImGui.BeginTabItem("List " + (i + 2) + ((text.Length > 0) ? (": " + text) : " (off)") + "###ml" + (i + 1)))
			{
				DrawExtraBar(i);
				if (text.Length > 0 && DrawMonsterTable(_s.ExtraMonsters[i], isMain: false))
				{
					_s.SaveExtra(i);
				}
				ImGui.EndTabItem();
			}
		}
		if (ImGui.BeginTabItem("DB###mldb"))
		{
			_dbTab.Draw();
			ImGui.EndTabItem();
		}
		ImGui.EndTabBar();
	}

	private void DrawExtraBar(int x)
	{
		if (_profiles == null || (DateTime.Now - _profilesReadAt).TotalSeconds > 5.0)
		{
			_profiles = Settings.ListProfiles();
			_profilesReadAt = DateTime.Now;
		}
		Im.TextColored(Cyan, "List " + (x + 2));
		ImGui.SameLine();
		ImGui.SetNextItemWidth(220f);
		string text = ((_s.ExtraProfile[x].Length > 0) ? _s.ExtraProfile[x] : "(none - off)");
		if (ImGui.BeginCombo("##extra" + x, text))
		{
			if (ImGui.Selectable("(none - off)", _s.ExtraProfile[x].Length == 0))
			{
				_s.SetExtraProfile(x, "");
			}
			foreach (string profile in _profiles)
			{
				if (!string.Equals(profile, _s.ActiveProfile, StringComparison.OrdinalIgnoreCase) && !string.Equals(profile, _s.ExtraProfile[1 - x], StringComparison.OrdinalIgnoreCase))
				{
					bool flag = string.Equals(profile, _s.ExtraProfile[x], StringComparison.OrdinalIgnoreCase);
					if (ImGui.Selectable(profile, flag) && !flag && _s.SetExtraProfile(x, profile))
					{
						Util.WriteToChat("List " + (x + 2) + ": '" + profile + "' - always used alongside the main list.");
					}
				}
			}
			ImGui.EndCombo();
		}
		Tip("A profile used as well as the main list, all the time (a zone list, a watch list...).\nA monster is looked up in the main list first, then list 2, then list 3. Only the main list has the DEFAULT row.\nChanges here save straight into this profile.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(160f);
		bool flag2 = ImGui.InputTextWithHint("##extranew" + x, "new list name", ref _extraNew[x], 64u, ImGuiInputTextFlags.EnterReturnsTrue);
		ImGui.SameLine();
		if ((ImGui.Button("New##extranewbtn" + x) | flag2) && _s.CreateExtraProfile(x, _extraNew[x]))
		{
			Util.WriteToChat("List " + (x + 2) + ": new empty list '" + _s.ExtraProfile[x] + "'.");
			_extraNew[x] = "";
			_profiles = null;
		}
		Tip("Makes a new, empty profile for this slot.");
		if (_s.ExtraProfile[x].Length == 0)
		{
			Im.TextColored(Grey, "Off. Pick a profile above, or make a new one.");
		}
	}

	private bool DrawMonsterTable(List<MonsterRule> list, bool isMain)
	{
		bool flag = false;
		int column = Slots.All.Length + 12;
		ImGuiTableFlags flags = ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollX | ImGuiTableFlags.ScrollY | ImGuiTableFlags.Hideable;   // (Hideable: the Fracture column is hidden off Leaftide - without it ImGui asserts)
		if (ImGui.BeginTable(outer_size: new Vector2(0f, (0f - ImGui.GetFrameHeightWithSpacing()) * 1.4f), str_id: "monsters", column: column, flags: flags))
		{
			string[] labels = Slots.Labels;
			foreach (string text in labels)
			{
				ImGui.TableSetupColumn(text, ImGuiTableColumnFlags.WidthFixed, 22f);
			}
			ImGui.TableSetupColumn("Name", ImGuiTableColumnFlags.WidthFixed, 170f);
			ImGui.TableSetupColumn("P", ImGuiTableColumnFlags.WidthFixed, 34f);
			ImGui.TableSetupColumn("Dmg type", ImGuiTableColumnFlags.WidthFixed, 80f);
			ImGui.TableSetupColumn("Ex. Vuln", ImGuiTableColumnFlags.WidthFixed, 80f);
			ImGui.TableSetupColumn("Weapon", ImGuiTableColumnFlags.WidthFixed, 130f);
			ImGui.TableSetupColumn("Attack", ImGuiTableColumnFlags.WidthFixed, 90f);
			ImGui.TableSetupColumn("Offhand", ImGuiTableColumnFlags.WidthFixed, 110f);
			ImGui.TableSetupColumn("PetDmg", ImGuiTableColumnFlags.WidthFixed, 80f);
			ImGui.TableSetupColumn("ALT", ImGuiTableColumnFlags.WidthFixed, 30f);
			ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 22f);
			ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 22f);
			ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 22f);
			ImGui.TableSetupScrollFreeze(0, 1);
			if (!ServerMode.Ilt)
			{
				ImGui.TableSetColumnEnabled((int)Slot.Fracture, v: false);
			}
			ImGui.TableNextRow(ImGuiTableRowFlags.Headers);
			for (int j = 0; j < Slots.All.Length; j++)
			{
				ImGui.TableSetColumnIndex(j);
				Slot slot = Slots.All[j];
				Im.TextColored((Slots.IsWarShape(slot) || slot == Slot.Corruption || slot == Slot.DestructiveCurse || slot == Slot.Corrosion) ? Red : Cyan, Slots.Labels[j]);
				Tip(Slots.Tooltips[j]);
			}
			string[] array = new string[9] { "Name", "P", "Dmg type", "Ex. Vuln", "Weapon", "Attack", "Offhand", "PetDmg", "ALT" };
			for (int k = 0; k < array.Length; k++)
			{
				ImGui.TableSetColumnIndex(Slots.All.Length + k);
				Im.TextColored(Cyan, array[k]);
			}
			ImGui.TableSetColumnIndex(Slots.All.Length + 1);
			Tip("Priority. Higher is attacked first. -1 = never attack.");
			ImGui.TableSetColumnIndex(Slots.All.Length + 4);
			Tip("What to hit it with. <AUTO>: your default attack. <ANY WAND> / <ANY MELEE> / <ANY MISSILE>: the best of that kind you carry\nfor its weakness. Or one weapon by name. Debuffs ticked on the row are still cast first (with a wand) when Attack allows magic.");
			ImGui.TableSetColumnIndex(Slots.All.Length + 5);
			Tip("What can hurt it. Some monsters are immune to magic (banshees, Valley of Death), some take only one kind.\nWhen your weapon can't hurt it, MelkTank swaps to one that can (debuffs and war spells are skipped without Magic);\nwhen nothing you carry can, it's left alone. Click to change.");
			ImGui.TableSetColumnIndex(Slots.All.Length + 8);
			Tip("Alert: a chat message the first time one is seen (at any distance), and a row on the\nTracking tab while it's around, so you can see how far it is and select it.");
			if (ItemLabels.FixDuplicates(_s))
			{
				flag = true;
			}
			string[] options = WeaponChoices();
			string[] options2 = OffhandChoices();
			int num = -1;
			int num2 = -1;
			int num3 = -1;
			int num4 = (isMain ? 1 : 0);
			for (int l = 0; l < list.Count; l++)
			{
				MonsterRule monsterRule = list[l];
				ImGui.TableNextRow();
				ImGui.PushID(l);
				for (int m = 0; m < Slots.All.Length; m++)
				{
					ImGui.TableSetColumnIndex(m);
					ImGui.PushID(m);
					flag |= ImGui.Checkbox("##s", ref monsterRule.Slots[m]);
					ImGui.PopID();
				}
				int num5 = Slots.All.Length;
				ImGui.TableSetColumnIndex(num5++);
				if (monsterRule.IsDefault)
				{
					Im.TextColored(Yellow, monsterRule.Name);
				}
				else if (MonsterMatch.IsExpression(monsterRule.Name))
				{
					string text2 = MonsterMatch.Problem(monsterRule.Name);
					Im.TextColored((text2 != null) ? Red : new Vector4(0.75f, 0.6f, 1f, 1f), monsterRule.Name);
					Tip((text2 != null) ? ("This rule can't be used: " + text2 + ".\nDelete it and add it again written the right way (hover the ? below the list).") : ("A rule, not a single name: it covers every monster it matches. Rows are tried top to bottom -\nthe first one that matches is used, so put specific rows above general ones." + (MonsterMatch.NeedsId(monsterRule.Name) ? "\n(species / maxhp: known once the monster's been appraised - MelkTank appraises them.)" : "")));
				}
				else
				{
					ImGui.TextUnformatted(monsterRule.Name);
				}
				ImGui.TableSetColumnIndex(num5++);
				ImGui.SetNextItemWidth(-1f);
				flag |= ImGui.InputInt("##p", ref monsterRule.Priority, 0, 0);
				ImGui.TableSetColumnIndex(num5++);
				int current_item = (int)monsterRule.Dmg;
				ImGui.SetNextItemWidth(-1f);
				if (ImGui.Combo("##dmg", ref current_item, DmgNames, DmgNames.Length))
				{
					monsterRule.Dmg = (DmgType)current_item;
					flag = true;
				}
				ImGui.TableSetColumnIndex(num5++);
				int current_item2 = (int)monsterRule.ExVuln;
				ImGui.SetNextItemWidth(-1f);
				if (ImGui.Combo("##ex", ref current_item2, ExVulnNames, ExVulnNames.Length))
				{
					monsterRule.ExVuln = (DmgType)current_item2;
					flag = true;
				}
				ImGui.TableSetColumnIndex(num5++);
				flag |= StringCombo("##wpn", ref monsterRule.Weapon, options);
				ImGui.TableSetColumnIndex(num5++);
				if (ImGui.SmallButton(monsterRule.AttackText + "##atk"))
				{
					ImGui.OpenPopup("atkpop");
				}
				if (ImGui.BeginPopup("atkpop"))
				{
					flag |= ImGui.Checkbox("Magic##atkmg", ref monsterRule.Magic);
					flag |= ImGui.Checkbox("Melee##atkme", ref monsterRule.Melee);
					flag |= ImGui.Checkbox("Missile##atkmi", ref monsterRule.Missile);
					ImGui.EndPopup();
				}
				ImGui.TableSetColumnIndex(num5++);
				flag |= StringCombo("##off", ref monsterRule.Offhand, options2);
				ImGui.TableSetColumnIndex(num5++);
				int current_item3 = (int)monsterRule.PetDmg;
				ImGui.SetNextItemWidth(-1f);
				if (ImGui.Combo("##pd", ref current_item3, DmgNames, DmgNames.Length))
				{
					monsterRule.PetDmg = (DmgType)current_item3;
					flag = true;
				}
				ImGui.TableSetColumnIndex(num5++);
				if (!monsterRule.IsDefault)
				{
					flag |= ImGui.Checkbox("##alt", ref monsterRule.Alert);
				}
				ImGui.TableSetColumnIndex(num5++);
				if (!monsterRule.IsDefault && l > num4)
				{
					if (Im.UpButton("##up"))
					{
						num = l;
					}
					Tip("Move up");
				}
				ImGui.TableSetColumnIndex(num5++);
				if (!monsterRule.IsDefault && l < list.Count - 1)
				{
					if (Im.DownButton("##down"))
					{
						num2 = l;
					}
					Tip("Move down");
				}
				ImGui.TableSetColumnIndex(num5++);
				if (!monsterRule.IsDefault)
				{
					ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(0.6f, 0.15f, 0.15f, 1f));
					if (ImGui.SmallButton("X"))
					{
						num3 = l;
					}
					ImGui.PopStyleColor();
					Tip("Remove " + monsterRule.Name);
				}
				ImGui.PopID();
			}
			ImGui.EndTable();
			if (num > num4)
			{
				Im.Move(list, num, up: true, num4);
				flag = true;
			}
			if (num2 >= num4 && num2 < list.Count - 1)
			{
				Im.Move(list, num2, up: false, num4);
				flag = true;
			}
			if (num3 >= num4 && num3 < list.Count)
			{
				list.RemoveAt(num3);
				flag = true;
			}
		}
		ImGui.SetNextItemWidth(260f);
		bool flag2 = ImGui.InputText("##newmon", ref _newMonsterName, 128u, ImGuiInputTextFlags.EnterReturnsTrue);
		ImGui.SameLine();
		if (ImGui.Button("Add") | flag2)
		{
			flag |= AddMonster(list, _newMonsterName);
		}
		ImGui.SameLine();
		if (ImGui.Button("Add Sel"))
		{
			WorldObject worldObject = Selected();
			if (worldObject != null && worldObject.ObjectClass == ObjectClass.Monster)
			{
				flag |= AddMonster(list, worldObject.Name);
			}
			else
			{
				Util.WriteToChat("Select a monster first.");
			}
		}
		ImGui.SameLine();
		DrawRuleHelp();
		return flag;
	}

	private void DrawProfileBar()
	{
		if (_profiles == null || (DateTime.Now - _profilesReadAt).TotalSeconds > 5.0)
		{
			_profiles = Settings.ListProfiles();
			_profilesReadAt = DateTime.Now;
		}
		Im.TextColored(Cyan, "Profile");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(220f);
		string text = ((_s.ActiveProfile.Length > 0) ? _s.ActiveProfile : "(this character's list)");
		if (ImGui.BeginCombo("##profile", text))
		{
			if (ImGui.Selectable("(this character's list)", _s.ActiveProfile.Length == 0) && _s.ActiveProfile.Length > 0)
			{
				_s.SwitchProfile("");
				_confirmDelete = false;
			}
			foreach (string profile in _profiles)
			{
				bool flag = string.Equals(profile, _s.ActiveProfile, StringComparison.OrdinalIgnoreCase);
				if (ImGui.Selectable(profile, flag) && !flag)
				{
					if (_s.SwitchProfile(profile))
					{
						Util.WriteToChat("Loaded profile '" + profile + "'.");
					}
					_confirmDelete = false;
				}
			}
			ImGui.EndCombo();
		}
		Tip((_s.ActiveProfile.Length > 0) ? "Changes to the list are saved into this profile as you make them." : "No profile - changes are saved to this character only.\nUse 'Save as' to turn this list into a profile.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(160f);
		bool flag2 = ImGui.InputTextWithHint("##profname", "new profile name", ref _profileName, 64u, ImGuiInputTextFlags.EnterReturnsTrue);
		ImGui.SameLine();
		if (ImGui.Button("Save as") | flag2)
		{
			string text2 = Settings.CleanProfileName(_profileName);
			bool flag3 = Settings.FindProfile(text2) != null && !string.Equals(text2, _s.ActiveProfile, StringComparison.OrdinalIgnoreCase);
			if (_s.SaveAsProfile(_profileName))
			{
				Util.WriteToChat((flag3 ? "Overwrote" : "Saved") + " profile '" + _s.ActiveProfile + "'.");
				_profileName = "";
				_profiles = null;
			}
		}
		Tip("Saves the list as shown into a profile with this name and switches to it.\nAn existing profile with the same name is overwritten.");
		if (_s.ActiveProfile.Length <= 0)
		{
			return;
		}
		ImGui.SameLine();
		if (!_confirmDelete)
		{
			if (ImGui.Button("Delete"))
			{
				_confirmDelete = true;
			}
			Tip("Deletes this profile and goes back to this character's own list.");
			return;
		}
		if (ImGui.Button("Really delete?"))
		{
			string activeProfile = _s.ActiveProfile;
			if (_s.DeleteActiveProfile())
			{
				Util.WriteToChat("Deleted profile '" + activeProfile + "'.");
			}
			_confirmDelete = false;
			_profiles = null;
		}
		ImGui.SameLine();
		if (ImGui.Button("Cancel"))
		{
			_confirmDelete = false;
		}
	}

	private void DrawRuleHelp()
	{
		ImGui.PushStyleVar(ImGuiStyleVar.FrameBorderSize, 1f);
		ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(0f, 0f, 0f, 0f));
		ImGui.PushStyleColor(ImGuiCol.Border, Cyan);
		ImGui.SmallButton(" ? ##rulehelp");
		ImGui.PopStyleColor(2);
		ImGui.PopStyleVar();
		if (!ImGui.IsItemHovered())
		{
			return;
		}
		ImGui.BeginTooltip();
		Im.TextColored(Cyan, "A row can be one creature's name, or a rule. Rows are tried top to bottom - the first match is used.");
		if (ImGui.BeginTable("rulehelptbl", 2, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("Goal", ImGuiTableColumnFlags.WidthFixed, 330f);
			ImGui.TableSetupColumn("Rule", ImGuiTableColumnFlags.WidthFixed, 330f);
			ImGui.TableHeadersRow();
			string[][] examples = MonsterMatch.Examples;
			foreach (string[] array in examples)
			{
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				ImGui.TextUnformatted(array[0]);
				ImGui.TableSetColumnIndex(1);
				Im.TextColored(new Vector4(0.75f, 0.6f, 1f, 1f), array[1]);
			}
			ImGui.EndTable();
		}
		Im.TextColored(Grey, "name: ==  !=  # (contains / regex, ^ = starts with)    species: == !=  (virindi, drudge, tumerok... or the number)\nrange (metres from you), maxhp: ==  !=  <  <=  >  >=      hasshield: ==true / ==false\n&& = and,  || = or  (&& goes first).  Plain names and name== also cover Shiny / Enraged versions when that's on.");
		ImGui.EndTooltip();
	}

	private void MonsterLogAdd(string name)
	{
		name = (name ?? "").Trim();
		if (name.Length == 0)
		{
			return;
		}
		string b = (_s.ShinySameAsBase ? Settings.BaseMonsterName(name) : name);
		MonsterMatch.Ctx c = new MonsterMatch.Ctx(name, null, _s.ShinySameAsBase);
		foreach (MonsterRule monster in _s.Monsters)
		{
			if (monster.IsDefault || (!string.Equals(monster.Name, name, StringComparison.OrdinalIgnoreCase) && !string.Equals(monster.Name, b, StringComparison.OrdinalIgnoreCase) && (!MonsterMatch.IsExpression(monster.Name) || !MonsterMatch.Matches(monster.Name, c))))
			{
				continue;
			}
			return;
		}
		string newMonsterName = _newMonsterName;
		bool flag = AddMonster(_s.Monsters, name);
		_newMonsterName = newMonsterName;
		if (flag)
		{
			_s.SaveMonsters();
			Util.WriteToChat("Monster log: added " + name + " to " + ((_s.ActiveProfile.Length > 0) ? ("profile " + _s.ActiveProfile) : "the main list") + ".");
		}
	}

	private bool AddMonster(List<MonsterRule> list, string name)
	{
		name = (name ?? "").Trim();
		if (name.Length == 0)
		{
			return false;
		}
		foreach (MonsterRule item in list)
		{
			if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
			{
				Util.WriteToChat(name + " is already on this list.");
				return false;
			}
		}
		int num = -1;
		MonsterRule monsterRule = null;
		for (int i = 0; i < list.Count; i++)
		{
			MonsterRule monsterRule2 = list[i];
			if (!monsterRule2.IsDefault && (Settings.NameContains(name, monsterRule2.Name) || Settings.NameContains(monsterRule2.Name, name)))
			{
				num = i;
				if (Settings.NameContains(name, monsterRule2.Name) && (monsterRule == null || monsterRule2.Name.Length > monsterRule.Name.Length))
				{
					monsterRule = monsterRule2;
				}
			}
		}
		if (!MonsterMatch.IsExpression(name))
		{
			MonsterMatch.Ctx c = new MonsterMatch.Ctx(name, null, _s.ShinySameAsBase);
			for (int j = 0; j < list.Count; j++)
			{
				MonsterRule monsterRule3 = list[j];
				if (!monsterRule3.IsDefault && MonsterMatch.IsExpression(monsterRule3.Name) && MonsterMatch.Matches(monsterRule3.Name, c))
				{
					num = j - 1;
					if (monsterRule == null)
					{
						monsterRule = monsterRule3;
					}
					break;
				}
			}
		}
		MonsterRule monsterRule4 = monsterRule ?? _s.DefaultRule;
		MonsterRule monsterRule5 = new MonsterRule(name);
		monsterRule5.Priority = monsterRule4.Priority;
		Array.Copy(monsterRule4.Slots, monsterRule5.Slots, monsterRule5.Slots.Length);
		if (monsterRule != null)
		{
			monsterRule5.Dmg = monsterRule.Dmg;
			monsterRule5.ExVuln = monsterRule.ExVuln;
			monsterRule5.Weapon = monsterRule.Weapon;
			monsterRule5.Offhand = monsterRule.Offhand;
			monsterRule5.PetDmg = monsterRule.PetDmg;
			monsterRule5.Magic = monsterRule.Magic;
			monsterRule5.Melee = monsterRule.Melee;
			monsterRule5.Missile = monsterRule.Missile;
		}
		else
		{
			monsterRule5.Dmg = DmgType.Auto;
			monsterRule5.Weapon = "<AUTO>";
			monsterRule5.Offhand = "<AUTO>";
		}
		int val = ((list.Count > 0 && list[0].IsDefault) ? 1 : 0);
		if (num >= 0 || (num == -1 && monsterRule != null && MonsterMatch.IsExpression(monsterRule.Name)))
		{
			list.Insert(Math.Max(val, num + 1), monsterRule5);
		}
		else
		{
			list.Add(monsterRule5);
		}
		_s.RulesChanged();
		_newMonsterName = "";
		return true;
	}

	private static void Swap(List<MonsterRule> list, int a, int b)
	{
		MonsterRule value = list[a];
		list[a] = list[b];
		list[b] = value;
	}

	private string[] WeaponChoices()
	{
		List<string> list = new List<string> { "<AUTO>", "<ANY WAND>", "<ANY MELEE>", "<ANY MISSILE>" };
		foreach (WeaponItem item in _s.Items)
		{
			if (!item.IsShield && item.Kind != WeaponKind.Ammo && !ItemInfo.IsSupply(item.Kind) && !list.Contains(item.Name))
			{
				list.Add(item.Name);
			}
		}
		return list.ToArray();
	}

	private string[] OffhandChoices()
	{
		List<string> list = new List<string> { "<AUTO>", "<AUTO SHIELD>", "<AUTO OFFHAND>", "<NONE>" };
		foreach (WeaponItem item in _s.Items)
		{
			if (item.IsShield && !list.Contains(item.Name))
			{
				list.Add(item.Name);
			}
		}
		foreach (WeaponItem item2 in _s.Items)
		{
			if (!item2.IsShield && item2.Kind == WeaponKind.Melee && !CombatEngine.IsTwoHanded(item2.Id) && !list.Contains(item2.Name))
			{
				list.Add(item2.Name);
			}
		}
		return list.ToArray();
	}

	private static bool StringCombo(string id, ref string value, string[] options)
	{
		bool result = false;
		ImGui.SetNextItemWidth(-1f);
		if (ImGui.BeginCombo(id, value ?? ""))
		{
			foreach (string text in options)
			{
				bool flag = text == value;
				if (ImGui.Selectable(text, flag))
				{
					value = text;
					result = true;
				}
				if (flag)
				{
					ImGui.SetItemDefaultFocus();
				}
			}
			ImGui.EndCombo();
		}
		return result;
	}

	private static bool OnWeaponsTab(WeaponItem w)
	{
		return !ItemInfo.IsSupply(w.Kind);
	}

	private void DrawItems(bool weapons)
	{
		bool flag = false;
		foreach (WeaponItem item in _s.Items)
		{
			WorldObject worldObject = Globals.Core.WorldFilter[item.Id];
			if (item.Kind == WeaponKind.Missile && ItemInfo.IsAmmo(worldObject))
			{
				item.Kind = WeaponKind.Ammo;
				flag = true;
			}
			if (worldObject != null && !ItemInfo.IsSupply(item.Kind))
			{
				string text = ItemReport.FullName(worldObject);
				if (text.Length > 0 && !(item.Name ?? "").StartsWith(text, StringComparison.OrdinalIgnoreCase))
				{
					item.Name = text;
					flag = true;
				}
			}
		}
		WeaponItem weaponItem = null;
		foreach (WeaponItem item2 in _s.Items)
		{
			if (item2.Kind == WeaponKind.HealKit)
			{
				weaponItem = item2;
				break;
			}
		}
		if (_s.HealKitId != 0)
		{
			if (weaponItem == null)
			{
				weaponItem = new WeaponItem
				{
					Kind = WeaponKind.HealKit
				};
				_s.Items.Insert(0, weaponItem);
				flag = true;
			}
			weaponItem.Id = _s.HealKitId;
			weaponItem.Name = _s.HealKitName;
		}
		ImGuiTableFlags imGuiTableFlags = ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY;
		Vector2 outer_size = new Vector2(0f, (0f - ImGui.GetFrameHeightWithSpacing()) * 1.4f);
		ImGuiTableColumnFlags imGuiTableColumnFlags = ((!weapons) ? ImGuiTableColumnFlags.DefaultHide : ImGuiTableColumnFlags.None);
		if (ImGui.BeginTable(weapons ? "items" : "items2c", 9, (ImGuiTableFlags)((int)imGuiTableFlags | ((!weapons) ? 4 : 0)), outer_size))
		{
			ImGui.TableSetupColumn("Name", ImGuiTableColumnFlags.WidthStretch);
			ImGui.TableSetupColumn("Type", ImGuiTableColumnFlags.WidthFixed, 90f);
			ImGui.TableSetupColumn("Element", ImGuiTableColumnFlags.WidthFixed | imGuiTableColumnFlags, 90f);
			ImGui.TableSetupColumn("Shield", ImGuiTableColumnFlags.WidthFixed | imGuiTableColumnFlags, 50f);
			ImGui.TableSetupColumn("Compare", ImGuiTableColumnFlags.WidthFixed | imGuiTableColumnFlags, 60f);
			ImGui.TableSetupColumn("Status", ImGuiTableColumnFlags.WidthFixed, 80f);
			ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 22f);
			ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 22f);
			ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 22f);
			ImGui.TableSetupScrollFreeze(0, 1);
			ImGui.TableHeadersRow();
			int num = -1;
			int num2 = -1;
			int num3 = -1;
			if (weapons && ItemLabels.FixDuplicates(_s))
			{
				flag = true;
			}
			List<int> list = new List<int>();
			for (int i = 0; i < _s.Items.Count; i++)
			{
				if (OnWeaponsTab(_s.Items[i]) == weapons)
				{
					list.Add(i);
				}
			}
			for (int j = 0; j < list.Count; j++)
			{
				int num4 = list[j];
				WeaponItem weaponItem2 = _s.Items[num4];
				ImGui.TableNextRow();
				ImGui.PushID(num4);
				ImGui.TableSetColumnIndex(0);
				ImGui.TextUnformatted(weaponItem2.Name);
				ImGui.TableSetColumnIndex(1);
				if (weaponItem2.Kind == WeaponKind.HealKit)
				{
					Im.TextColored(Cyan, "Heal kit");
				}
				else
				{
					int current_item;
					if (weaponItem2.Kind == WeaponKind.ManaKit)
					{
						current_item = 4;
					}
					else if (weaponItem2.Kind == WeaponKind.StaminaKit)
					{
						current_item = 5;
					}
					else if (weaponItem2.Kind == WeaponKind.Health)
					{
						current_item = 6;
					}
					else if (weaponItem2.Kind == WeaponKind.ManaStone)
					{
						current_item = 7;
					}
					else if (weaponItem2.Kind == WeaponKind.Lockpick)
					{
						current_item = 8;
					}
					else
					{
						current_item = (int)((weaponItem2.Kind == WeaponKind.Dispel) ? WeaponKind.Lockpick : weaponItem2.Kind);
					}
					ImGui.SetNextItemWidth(-1f);
					if (ImGui.Combo("##kind", ref current_item, TypeNames, TypeNames.Length))
					{
						weaponItem2.Kind = current_item switch
						{
							9 => WeaponKind.Dispel, 
							8 => WeaponKind.Lockpick, 
							7 => WeaponKind.ManaStone, 
							6 => WeaponKind.Health, 
							5 => WeaponKind.StaminaKit, 
							4 => WeaponKind.ManaKit, 
							_ => (WeaponKind)current_item, 
						};
						flag = true;
					}
					if (weaponItem2.Kind == WeaponKind.ManaStone)
					{
						Tip("Used on you to fill your equipped items' mana (Settings, Items: top up gear mana).\nMana stones are used top to bottom: the first one you still have.");
					}
				}
				ImGui.TableSetColumnIndex(2);
				if (ItemInfo.IsSupply(weaponItem2.Kind))
				{
					Im.TextColored(Grey, "-");
				}
				else if (weaponItem2.Kind == WeaponKind.Ammo)
				{
					Im.TextColored(Grey, ItemInfo.MissileTypeName(ItemInfo.MissileType(weaponItem2.Id), ammo: true));
				}
				else
				{
					int current_item2 = (int)weaponItem2.Element;
					ImGui.SetNextItemWidth(-1f);
					if (ImGui.Combo("##el", ref current_item2, DmgNames, DmgNames.Length))
					{
						weaponItem2.Element = (DmgType)current_item2;
						flag = true;
					}
				}
				ImGui.TableSetColumnIndex(3);
				if (!ItemInfo.IsSupply(weaponItem2.Kind) && weaponItem2.Kind != WeaponKind.Ammo)
				{
					flag |= ImGui.Checkbox("##sh", ref weaponItem2.IsShield);
				}
				ImGui.TableSetColumnIndex(4);
				if (!ItemInfo.IsSupply(weaponItem2.Kind) && weaponItem2.Kind != WeaponKind.Ammo)
				{
					bool v = weaponItem2.CompareTo;
					if (ImGui.Checkbox("##cmp", ref v))
					{
						int num5 = CmpGroup(weaponItem2);
						foreach (WeaponItem item3 in _s.Items)
						{
							if (CmpGroup(item3) == num5)
							{
								item3.CompareTo = false;
							}
						}
						weaponItem2.CompareTo = v;
						flag = true;
					}
					if (weaponItem2.IsShield)
					{
						Tip("Looted shields are compared against this one (worn or in your pack). Only one shield can be ticked.\nNone ticked: the top-most shield on the list that you have.");
					}
					else
					{
						Tip("Loot is compared against this weapon (the \"vs\" line when you ID one, and the \"Damage vs Equipped\"\nloot rules) - wielded or not, so the slayer in your hand doesn't matter.\nOne can be ticked in each group: wand, missile, two-handed, one-handed (this one: " + ItemCompare.GroupNames[CmpGroup(weaponItem2)] + ").\nLooted weapons are compared with the ticked one of their group (wands also need the same element, melee the same\ndamage type); a group with none ticked uses the weapon in your hand. Ticked: no swapping back to the main weapon before looting.");
					}
				}
				ImGui.TableSetColumnIndex(5);
				WorldObject worldObject2 = Globals.Core.WorldFilter[weaponItem2.Id];
				bool flag2 = CombatEngine.IsWielded(weaponItem2.Id);
				if (weaponItem2.Kind == WeaponKind.ManaKit || weaponItem2.Kind == WeaponKind.StaminaKit || weaponItem2.Kind == WeaponKind.Health || weaponItem2.Kind == WeaponKind.ManaStone || weaponItem2.Kind == WeaponKind.Lockpick || weaponItem2.Kind == WeaponKind.Dispel)
				{
					int num6 = ItemInfo.CountInPack(weaponItem2.Name);
					if (num6 == 0)
					{
						Im.TextColored(Red, "None left");
					}
					else
					{
						Im.TextColored(Green, "Ready (" + num6 + ")");
					}
				}
				else if (worldObject2 == null)
				{
					Im.TextColored(Red, "Missing");
				}
				else if (weaponItem2.Kind == WeaponKind.HealKit)
				{
					Im.TextColored(Green, "Ready");
				}
				else if (flag2)
				{
					Im.TextColored(Green, "Wielded");
				}
				else
				{
					Im.TextColored(Grey, "In pack");
				}
				ImGui.TableSetColumnIndex(6);
				if (j > 0)
				{
					if (Im.UpButton("##iup"))
					{
						num2 = num4;
						_swapWith = list[j - 1];
					}
					Tip("Move up");
				}
				ImGui.TableSetColumnIndex(7);
				if (j < list.Count - 1)
				{
					if (Im.DownButton("##idown"))
					{
						num3 = num4;
						_swapWith = list[j + 1];
					}
					Tip("Move down");
				}
				ImGui.TableSetColumnIndex(8);
				if (ImGui.SmallButton("X"))
				{
					num = num4;
				}
				ImGui.PopID();
			}
			ImGui.EndTable();
			int num7 = ((num2 >= 0) ? num2 : num3);
			if (num7 >= 0 && Im.Far)
			{
				Im.Far = false;
				int num8 = list.IndexOf(num7);
				while (true)
				{
					bool num9;
					if (num2 < 0)
					{
						if (num8 < 0)
						{
							break;
						}
						num9 = num8 < list.Count - 1;
					}
					else
					{
						num9 = num8 > 0;
					}
					if (!num9)
					{
						break;
					}
					int index = list[(num2 >= 0) ? (num8 - 1) : (num8 + 1)];
					WeaponItem value = _s.Items[list[num8]];
					_s.Items[list[num8]] = _s.Items[index];
					_s.Items[index] = value;
					num8 += ((num2 < 0) ? 1 : (-1));
				}
				flag = true;
			}
			else if (num7 >= 0 && _swapWith >= 0 && _swapWith < _s.Items.Count)
			{
				Im.Far = false;
				WeaponItem value2 = _s.Items[num7];
				_s.Items[num7] = _s.Items[_swapWith];
				_s.Items[_swapWith] = value2;
				flag = true;
			}
			_swapWith = -1;
			if (num >= 0)
			{
				if (_s.Items[num].Kind == WeaponKind.HealKit)
				{
					_s.HealKitId = 0;
					_s.HealKitName = "";
				}
				_s.Items.RemoveAt(num);
				flag = true;
			}
		}
		if (ImGui.Button("Add Selected"))
		{
			flag |= AddSelectedItem();
		}
		Tip("Select a weapon, wand, shield, ammo (arrows, quarrels, darts), healing kit, or a mana / stamina kit or potion in your inventory, then click.\nWhen a bow, crossbow or atlatl is equipped, the matching ammo from this list is equipped with it.\nMana and stamina items are used top to bottom: the first one you still have is used (move them with the arrows).");
		if (flag)
		{
			_saveAll();
		}
	}

	private static int CmpGroup(WeaponItem w)
	{
		if (w.IsShield)
		{
			return 5;
		}
		int num = ItemCompare.Group(Globals.Core.WorldFilter[w.Id]);
		if (num != 0)
		{
			return num;
		}
		return (w.Kind == WeaponKind.Caster) ? 1 : ((w.Kind == WeaponKind.Missile) ? 2 : 4);
	}

	private int CompareShieldId()
	{
		foreach (WeaponItem item in _s.Items)
		{
			if (item.IsShield && Globals.Core.WorldFilter[item.Id] != null)
			{
				return item.Id;
			}
		}
		return 0;
	}

	private bool AddSelectedItem()
	{
		WorldObject worldObject = Selected();
		if (worldObject == null)
		{
			Util.WriteToChat("Select an item in your inventory first.");
			return false;
		}
		return AddItem(worldObject);
	}

	public bool AddItem(WorldObject sel)
	{
		if (sel == null)
		{
			return false;
		}
		bool flag = false;
		foreach (WorldObject item in InvCache.All())
		{
			if (item.Id == sel.Id)
			{
				flag = true;
				break;
			}
		}
		if (!flag)
		{
			Util.WriteToChat("That isn't in your inventory.");
			return false;
		}
		foreach (WeaponItem item2 in _s.Items)
		{
			if (item2.Id == sel.Id)
			{
				Util.WriteToChat(sel.Name + " is already on the list.");
				return false;
			}
		}
		string text = sel.Name.ToLowerInvariant();
		if (text.Contains("dispel"))
		{
			_s.Items.Add(new WeaponItem
			{
				Id = sel.Id,
				Name = sel.Name,
				Kind = WeaponKind.Dispel
			});
			Util.WriteToChat("Added " + sel.Name + " as a dispel item - used when a harmful spell lands on you (Main > Dispel).");
			return true;
		}
		if (sel.ObjectClass == ObjectClass.Lockpick || text.Contains("lockpick"))
		{
			_s.Items.Add(new WeaponItem
			{
				Id = sel.Id,
				Name = sel.Name,
				Kind = WeaponKind.Lockpick
			});
			Util.WriteToChat("Added " + sel.Name + " as a lockpick - used on locked doors in the way (Nav > Settings).");
			return true;
		}
		if (sel.ObjectClass == ObjectClass.ManaStone || text.Contains("mana charge") || text.Contains("mana stone"))
		{
			foreach (WeaponItem item3 in _s.Items)
			{
				if (item3.Kind == WeaponKind.ManaStone && string.Equals(item3.Name, sel.Name, StringComparison.OrdinalIgnoreCase))
				{
					Util.WriteToChat(sel.Name + " is already on the list.");
					return false;
				}
			}
			_s.Items.Add(new WeaponItem
			{
				Id = sel.Id,
				Name = sel.Name,
				Kind = WeaponKind.ManaStone
			});
			Util.WriteToChat("Added " + sel.Name + " as a mana stone (Other Items) - used on you when your gear's mana runs low.");
			return true;
		}
		if (!text.Contains("mana") && !text.Contains("stamina") && (sel.ObjectClass == ObjectClass.HealingKit || text.Contains("health kit") || text.Contains("healing kit")))
		{
			_s.Items.RemoveAll((WeaponItem x) => x.Kind == WeaponKind.HealKit);
			_s.HealKitId = sel.Id;
			_s.HealKitName = sel.Name;
			_s.Items.Insert(0, new WeaponItem
			{
				Id = sel.Id,
				Name = sel.Name,
				Kind = WeaponKind.HealKit
			});
			Util.WriteToChat("Healing kit set to " + sel.Name + ".");
			return true;
		}
		if (sel.ObjectClass != ObjectClass.WandStaffOrb && sel.ObjectClass != ObjectClass.MeleeWeapon && sel.ObjectClass != ObjectClass.MissileWeapon && sel.ObjectClass != ObjectClass.Armor && sel.ObjectClass != ObjectClass.Clothing && sel.ObjectClass != ObjectClass.Jewelry && sel.ObjectClass != ObjectClass.ManaStone && (text.Contains("mana") || text.Contains("stamina") || text.Contains("health") || text.Contains("healing")))
		{
			WeaponKind weaponKind;
			if (text.Contains("stamina"))
			{
				weaponKind = WeaponKind.StaminaKit;
			}
			else
			{
				weaponKind = (text.Contains("mana") ? WeaponKind.ManaKit : WeaponKind.Health);
			}
			foreach (WeaponItem item4 in _s.Items)
			{
				if (item4.Kind == weaponKind && string.Equals(item4.Name, sel.Name, StringComparison.OrdinalIgnoreCase))
				{
					Util.WriteToChat(sel.Name + " is already on the list.");
					return false;
				}
			}
			_s.Items.Add(new WeaponItem
			{
				Id = sel.Id,
				Name = sel.Name,
				Kind = weaponKind
			});
			Util.WriteToChat("Added " + sel.Name + " for " + weaponKind switch
			{
				WeaponKind.StaminaKit => "stamina", 
				WeaponKind.ManaKit => "mana", 
				_ => "health", 
			} + " (used in list order - change the Type if that's wrong).");
			return true;
		}
		if (!sel.HasIdData)
		{
			try
			{
				Util.RequestId(sel.Id);
			}
			catch
			{
			}
		}
		WeaponItem weaponItem = new WeaponItem
		{
			Id = sel.Id,
			Name = ItemLabels.Unique(_s, ItemLabels.Label(sel), sel.Id)
		};
		switch (sel.ObjectClass)
		{
		case ObjectClass.WandStaffOrb:
			weaponItem.Kind = WeaponKind.Caster;
			break;
		case ObjectClass.MissileWeapon:
			weaponItem.Kind = (ItemInfo.IsAmmo(sel) ? WeaponKind.Ammo : WeaponKind.Missile);
			break;
		default:
			weaponItem.Kind = WeaponKind.Melee;
			break;
		}
		if (weaponItem.Kind == WeaponKind.Ammo)
		{
			_s.Items.Add(weaponItem);
			Util.WriteToChat("Added " + weaponItem.Name + " as ammo (" + ItemInfo.MissileTypeName(ItemInfo.MissileType(weaponItem.Id), ammo: true) + ").");
			return true;
		}
		string text2 = sel.Name.ToLowerInvariant();
		weaponItem.IsShield = sel.ObjectClass == ObjectClass.Armor || text2.Contains("shield") || text2.Contains("buckler") || text2.Contains("aegis");
		weaponItem.Element = GuessElement(text2);
		_s.Items.Add(weaponItem);
		Util.WriteToChat("Added " + weaponItem.Name + " as " + (weaponItem.IsShield ? "shield" : weaponItem.Kind.ToString()) + ", element " + weaponItem.Element.ToString() + ".");
		return true;
	}

	private static DmgType GuessElement(string n)
	{
		if (n.Contains("nether") || n.Contains("void") || n.Contains("corrupt"))
		{
			return DmgType.Void;
		}
		if (n.Contains("fire") || n.Contains("flame") || n.Contains("pyro"))
		{
			return DmgType.Fire;
		}
		if (n.Contains("frost") || n.Contains("cold") || n.Contains("ice"))
		{
			return DmgType.Cold;
		}
		if (n.Contains("acid"))
		{
			return DmgType.Acid;
		}
		if (n.Contains("lightning") || n.Contains("electric") || n.Contains("shock"))
		{
			return DmgType.Lightning;
		}
		if (n.Contains("blade") || n.Contains("slash"))
		{
			return DmgType.Blade;
		}
		if (n.Contains("pierc"))
		{
			return DmgType.Pierce;
		}
		if (n.Contains("bludg"))
		{
			return DmgType.Bludgeon;
		}
		return DmgType.Auto;
	}

	private TrackedMonster _selTracked;

	private List<TrackRow> TrackRows()
	{
		DateTime now = DateTime.Now;
		if (_trackRows != null && (now - _trackRowsAt).TotalMilliseconds < 250.0 && _trackRowsSort == _trackSort && _trackRowsDesc == _trackSortDesc)
		{
			return _trackRows;
		}
		List<TrackRow> list = new List<TrackRow>();
		List<TrackedMonster> list3 = new List<TrackedMonster>(_engine.Tracked.Values);
		// the monster you have selected, out of range and so not tracked: shown too while it's selected (distance,
		// priority, rule - its debuffs aren't known out there)
		try
		{
			int sel = Globals.Core.Actions.CurrentSelection;
			WorldObject so = (sel != 0 && !_engine.Tracked.ContainsKey(sel)) ? Globals.Core.WorldFilter[sel] : null;
			if (so != null && so.ObjectClass == ObjectClass.Monster)
			{
				if (_selTracked == null || _selTracked.Id != sel)
				{
					_selTracked = new TrackedMonster { Id = sel, Name = so.Name };
				}
				list3.Add(_selTracked);
			}
		}
		catch
		{
		}
		foreach (TrackedMonster item in list3)
		{
			WorldObject worldObject = Globals.Core.WorldFilter[item.Id];
			if (worldObject != null)
			{
				TrackRow trackRow = new TrackRow
				{
					Tm = item,
					D = CombatEngine.Distance(worldObject),
					Rule = _s.FindRule(worldObject),
					Src = _s.RuleSource(worldObject)
				};
				try
				{
					trackRow.E = Dex.NotCaught(item.Name);
					trackRow.Q = Dex.GivesQb(worldObject);
				}
				catch
				{
				}
				trackRow.DistText = ((trackRow.D < 0.0) ? "?" : trackRow.D.ToString("0"));
				trackRow.PrioText = trackRow.Rule.Priority.ToString();
				trackRow.RuleText = ((trackRow.Src <= 0) ? "own row" : ("list " + (trackRow.Src + 1)));
				if (!_trackCells.TryGetValue(item.Id, out trackRow.C))
				{
					_trackCells[item.Id] = (trackRow.C = new TrackCells());
				}
				list.Add(trackRow);
			}
		}
		if (_trackCells.Count > list.Count + 20)
		{
			HashSet<int> hashSet = new HashSet<int>();
			foreach (TrackRow item2 in list)
			{
				hashSet.Add(item2.Tm.Id);
			}
			foreach (int item3 in new List<int>(_trackCells.Keys))
			{
				if (!hashSet.Contains(item3))
				{
					_trackCells.Remove(item3);
				}
			}
		}
		if (_trackSort == 2 || _trackSort == 3)
		{
			bool desc = _trackSortDesc;
			int col = _trackSort;
			list.Sort((TrackRow x, TrackRow y) =>
			{
				double num = ((col != 2) ? ((double)x.Rule.Priority) : ((x.D < 0.0) ? double.MaxValue : x.D));
				double value = ((col != 2) ? ((double)y.Rule.Priority) : ((y.D < 0.0) ? double.MaxValue : y.D));
				int num2 = num.CompareTo(value);
				if (desc)
				{
					num2 = -num2;
				}
				return (num2 != 0) ? num2 : string.Compare(x.Tm.Name, y.Tm.Name, StringComparison.OrdinalIgnoreCase);
			});
		}
		_trackRows = list;
		_trackRowsAt = now;
		_trackRowsSort = _trackSort;
		_trackRowsDesc = _trackSortDesc;
		return list;
	}

	private void DrawTrackingTabs()
	{
		if (!ImGui.BeginTabBar("##trktabs"))
		{
			return;
		}
		if (ImGui.BeginTabItem("Main##trkmain"))
		{
			DrawTracking();
			ImGui.EndTabItem();
		}
		if (ImGui.BeginTabItem("List##trklist"))
		{
			if (ItemTracker.Draw(_s))
			{
				_saveAll();
			}
			ImGui.EndTabItem();
		}
		if (ImGui.BeginTabItem("Items##trkitems"))
		{
			ItemBar.DrawTab(_s);
			ImGui.EndTabItem();
		}
#if RETAIL
		if (ImGui.BeginTabItem("Name tags##trknt"))
		{
			if (NameTags.Draw(_s))
			{
				_saveAll();
			}
			ImGui.EndTabItem();
		}
#endif
		if (ImGui.BeginTabItem("Settings##trkset"))
		{
			if (ImGui.Checkbox("Max range##m", ref _s.TrackMaxRange))
			{
				_saveAll();
			}
			Tip("Which other monsters Main lists, combat on or off - unticked: those within your attack range;\nticked: every monster the game shows you (the attack range used for fighting isn't changed).\nAlways at any distance, whatever this says: monsters with ALT ticked on the Monsters tab and anything on\nTracking > List - they show up as soon as the game client knows about them.\n/mt set TrackMaxRange on|off");
			ImGui.Separator();
			if (VTankImport.DrawSense(_s))
			{
				_saveAll();
			}
			ImGui.EndTabItem();
		}
		ImGui.EndTabBar();
	}

	// the Debuffs column's width: as wide as the widest row's debuffs and NF note, kept there (only narrowed once
	// they've been shorter for a few seconds) - the name column takes whatever the window has left
	private float _dbW, _dbWant;
	private DateTime _dbNarrowAt = DateTime.MinValue;

	private void DrawTracking()
	{
		if (!_inTrackPop)
		{
			if (_s.TrackPopOut && _trackHud != null && !_trackHud.Visible)
			{
				_s.TrackPopOut = false;
				_saveAll();
			}
			Im.TextColored(_s.CombatEnabled ? Green : Grey, _s.CombatEnabled ? "Combat ON" : "Combat OFF");
			ImGui.SameLine();
			Im.TextColored(_s.CombatEnabled ? Green : Grey, _engine.Status ?? "");
			Im.TextColored(Yellow, "Range " + _engine.AttackRangeNow.ToString("0") + " m" + (_engine.LootMode ? " (finishing looting)" : ""));
			if (_s.TrackMaxRange)
			{
				ImGui.SameLine(0f, 20f);
				Im.TextColored(Grey, "(max range)");
			}
			ImGui.SameLine(0f, 20f);
			if (ImGui.SmallButton(_s.TrackPopOut ? "Pop-in##trkpop" : "Pop-out##trkpop"))
			{
				_s.TrackPopOut = !_s.TrackPopOut;
				ShowTrackPop(_s.TrackPopOut);
				_saveAll();
			}
			Tip("This list in a window of its own - it stays up when the main window is minimized or closed.\nPop-in (or the window's X) closes it.");
		}
		ImGuiTableFlags imGuiTableFlags = ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY;
		if (!ImGui.BeginTable(_inTrackPop ? "trackingp2" : "tracking", 7, (ImGuiTableFlags)((int)imGuiTableFlags | (_inTrackPop ? 4 : 0)), new Vector2(0f, 0f)))
		{
			return;
		}
		{
			float head = ImGui.CalcTextSize("Debuffs (time left)").X;
			float want = Math.Max(head, _dbWant);
			if (want > _dbW + 0.5f || _dbW <= 0f) { _dbW = want; _dbNarrowAt = DateTime.MinValue; }
			else if (want < _dbW - 0.5f)
			{
				if (_dbNarrowAt == DateTime.MinValue) _dbNarrowAt = DateTime.Now;
				else if ((DateTime.Now - _dbNarrowAt).TotalSeconds > 4.0) { _dbW = want; _dbNarrowAt = DateTime.MinValue; }
			}
			else _dbNarrowAt = DateTime.MinValue;
			_dbWant = 0f;
		}
		ImGui.TableSetupColumn("Monster/Item", ImGuiTableColumnFlags.WidthStretch, 1f);
		ImGui.TableSetupColumn("Rule", (ImGuiTableColumnFlags)(0x10 | (_inTrackPop ? 2 : 0)), 70f);
		ImGui.TableSetupColumn("Dist", ImGuiTableColumnFlags.WidthFixed, 45f);
		ImGui.TableSetupColumn("P", ImGuiTableColumnFlags.WidthFixed, 30f);
		ImGui.TableSetupColumn("Time", ImGuiTableColumnFlags.WidthFixed, 48f);
		ImGui.TableSetupColumn("Debuffs (time left)", ImGuiTableColumnFlags.WidthFixed | ImGuiTableColumnFlags.NoResize, _dbW);
		ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 46f);
		ImGui.TableSetupScrollFreeze(0, 1);
		ImGui.TableNextRow(ImGuiTableRowFlags.Headers);
		string[] array = new string[7] { "Monster/Item", "Rule", "Dist", "P", "Time", "Debuffs (time left)", "" };
		for (int i = 0; i < array.Length; i++)
		{
			ImGui.TableSetColumnIndex(i);
			bool flag = i == 2 || i == 3;
			string text;
			if (_trackSort != i)
			{
				text = "";
			}
			else
			{
				text = (_trackSortDesc ? " v" : " ^");
			}
			if (!flag)
			{
				Im.TextColored(Cyan, array[i]);
				continue;
			}
			ImGui.PushStyleColor(ImGuiCol.Text, Cyan);
			if (ImGui.Selectable(array[i] + text + "##th" + i, _trackSort == i))
			{
				if (_trackSort == i)
				{
					_trackSortDesc = !_trackSortDesc;
				}
				else
				{
					_trackSort = i;
					_trackSortDesc = i == 3;
				}
			}
			ImGui.PopStyleColor();
			Tip((i == 2) ? "Sort by distance (click again to reverse)." : "Sort by priority (click again to reverse).");
		}
		int num = 0;
		try
		{
			num = Globals.Core.Actions.CurrentSelection;
		}
		catch
		{
		}
		float textLineHeight = ImGui.GetTextLineHeight();
		float y = ImGui.GetWindowPos().Y;
		float num2 = y + ImGui.GetWindowSize().Y;
		DateTime now = DateTime.Now;
		foreach (TrackRow item in TrackRows())
		{
			TrackedMonster tm = item.Tm;
			double d = item.D;
			MonsterRule rule = item.Rule;
			TrackCells c = item.C;
			ImGui.TableNextRow();
			ImGui.TableSetColumnIndex(0);
			float y2 = ImGui.GetCursorScreenPos().Y;
			if (y2 > num2 || y2 + textLineHeight + 8f < y)
			{
				ImGui.Dummy(new Vector2(1f, textLineHeight));
				continue;
			}
			bool flag2 = tm.Id == _engine.CurrentTargetId;
			if (flag2)
			{
				ImGui.PushStyleColor(ImGuiCol.Text, Green);
			}
			bool flag3 = tm.Id == _engine.FocusId;
			bool flag4 = tm.Id == _engine.CastingOnId && tm.Id != _engine.CurrentTargetId;
			if (flag4)
			{
				Im.TextColored(new Vector4(1f, 0.6f, 0.2f, 1f), ">");
				ImGui.SameLine(0f, 4f);
			}
			int num3 = (flag2 ? 1 : 0) | (flag3 ? 2 : 0) | (tm.Alert ? 4 : 0) | (tm.Blocked ? 8 : 0) | (tm.Deferred ? 16 : 0) | (item.E ? 32 : 0) | (item.Q ? 64 : 0);
			if (c.Bits != num3 || c.Label == null)
			{
				string text2 = (flag3 ? "[FOCUS] " : "");
				string text3 = (tm.Alert ? "[ALERT] " : "");
				string text4;
				if (tm.Blocked)
				{
					text4 = "[BLOCKED] ";
				}
				else
				{
					text4 = (tm.Deferred ? "[moving] " : "");
				}
				string text5 = text2 + text3 + text4;
				c.Label = (flag2 ? "> " : "") + text5 + tm.Name + (item.E ? " (E)" : "") + (item.Q ? " (Q)" : "") + (PluginCore.IsPetOnly(tm.Name) ? " (Pet only)" : "") + "##trk" + tm.Id;
				c.Bits = num3;
			}
			if (ImGui.Selectable(c.Label, num == tm.Id))
			{
				try
				{
					Globals.Core.Actions.SelectItem(tm.Id);
				}
				catch (Exception ex)
				{
					Util.LogError(ex);
				}
			}
			if (ImGui.IsItemClicked(ImGuiMouseButton.Right))
			{
				_engine.SetFocus(tm.Id);
			}
			if (flag2)
			{
				ImGui.PopStyleColor();
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip((tm.Blocked ? "BLOCKED: two casts / attacks never reached it while it stood still - a hill or trees are in the way.\nIt's left alone until it moves (or a minute passes).\n\n" : "") + (tm.Deferred ? "Moving: two casts / attacks missed it while it moved, so it goes after the others for a few seconds.\n\n" : "") + (flag4 ? "Being cast on now (vuln / DoT) - the green > is the one being attacked.\n\n" : "") + (item.E ? "(E): not caught for your Monster-Dex yet.\n" : "") + (item.Q ? ("(Q): catching it stamps a QB - the first " + (tm.Name.StartsWith("Shiny ", StringComparison.OrdinalIgnoreCase) ? "shiny " : "") + "of its species.\n") : "") + ((item.E || item.Q) ? "\n" : "") + "Left click: select it in game.\nRight click: focus it - its vulns / DoTs first, then attacked until it dies, before the others.\nRight click it again to clear the focus." + (flag2 ? "\n\nThis is what MelkTank is attacking now." : ""));
			}
			ImGui.TableSetColumnIndex(1);
			int src = item.Src;
			if (rule.IsDefault)
			{
				Im.TextColored(Yellow, "DEFAULT");
			}
			else
			{
				ImGui.TextUnformatted(item.RuleText);
			}
			if (ImGui.IsItemHovered())
			{
				string tooltip;
				if (rule.IsDefault)
				{
					tooltip = "Not on any monster list - using the << DEFAULT >> row's checkboxes.";
				}
				else
				{
					tooltip = ((src <= 0) ? "Using this monster's own row on the main list." : ("Using its row on list " + (src + 1) + " (" + _s.ExtraProfile[src - 1] + ")."));
				}
				Im.SetTooltip(tooltip);
			}
			ImGui.TableSetColumnIndex(2);
			Im.TextColored((d >= 0.0 && d <= (double)_engine.AttackRangeNow) ? Cyan : Grey, item.DistText);
			ImGui.TableSetColumnIndex(3);
			ImGui.TextUnformatted(item.PrioText);
			ImGui.TableSetColumnIndex(4);
			if (tm.EngagedAt == DateTime.MinValue)
			{
				Im.TextDisabled("-");
			}
			else
			{
				TimeSpan timeSpan = now - tm.EngagedAt;
				int num4 = (int)timeSpan.TotalSeconds;
				if (c.TimeSec != num4 || c.Time == null)
				{
					c.TimeSec = num4;
					c.Time = ((timeSpan.TotalHours >= 1.0) ? ((int)timeSpan.TotalHours + ":" + timeSpan.Minutes.ToString("00") + ":" + timeSpan.Seconds.ToString("00")) : ((int)timeSpan.TotalMinutes + ":" + timeSpan.Seconds.ToString("00")));
				}
				ImGui.TextUnformatted(c.Time);
			}
			Tip("How long since your first debuff or attack landed on it (Reset starts it over).");
			ImGui.TableSetColumnIndex(5);
			float dbStart = ImGui.GetCursorScreenPos().X;
			bool flag5 = true;
			Slot? slot = null;
			foreach (KeyValuePair<Slot, ActiveDebuff> debuff in tm.Debuffs)
			{
				TimeSpan t = debuff.Value.ExpiresAt - now;
				if (!flag5)
				{
					ImGui.SameLine();
				}
				flag5 = false;
				Vector4 col;
				if (t.TotalSeconds <= (double)_s.RefreshLeadSeconds)
				{
					col = Red;
				}
				else
				{
					col = (Slots.IsDot(debuff.Key) ? Red : Cyan);
				}
				if (!c.Db.TryGetValue(debuff.Key, out var value))
				{
					value = (c.Db[debuff.Key] = new DbCell());
				}
				int num5 = (int)Math.Floor(t.TotalSeconds);
				if (value.Sec != num5 || value.Text == null)
				{
					value.Sec = num5;
					value.Text = Slots.Labels[(int)debuff.Key] + " " + FormatSpan(t);
					value.Id = value.Text + "##db" + tm.Id + "_" + (int)debuff.Key;
					value.Size = ImGui.CalcTextSize(value.Text);
				}
				ImGui.PushStyleColor(ImGuiCol.Text, col);
				if (ImGui.Selectable(value.Id, selected: false, ImGuiSelectableFlags.None, value.Size))
				{
					slot = debuff.Key;
				}
				ImGui.PopStyleColor();
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip(debuff.Value.SpellName + "\nClick if it isn't really on it - it's cast again.");
				}
			}
			if ((now - c.NfAt).TotalMilliseconds >= 250.0 || now < c.NfAt)
			{
				c.NfAt = now;
				c.NfHas = _engine.FractureState(tm, out c.Nf, out c.NfReady);
			}
			string nf = c.Nf;
			bool nfReady = c.NfReady;
			if (c.NfHas)
			{
				if (!flag5)
				{
					ImGui.SameLine();
				}
				flag5 = false;
				Vector4 col2;
				if (nfReady)
				{
					col2 = Green;
				}
				else
				{
					col2 = ((nf == "NF alone" || nf == "NF done") ? Grey : Purple);
				}
				Im.TextColored(col2, nf);
				string text6;
				if (nf == "NF alone")
				{
					text6 = "Nether Fracture: not primed - too few monsters within 5 m of it (Settings > Debuffs / DoTs).";
				}
				else
				{
					text6 = ((nf == "NF done") ? "Nether Fracture: had its release." : "Nether Fracture: primed.\nThe time is until its Nether Streak - the delay after priming, or the 8 s Fracture cooldown, whichever is longer.");
				}
				Tip(text6);
			}
			if (flag5)
			{
				Im.TextDisabled("-");
			}
			_dbWant = Math.Max(_dbWant, ImGui.GetItemRectMax().X - dbStart);
			if (slot.HasValue)
			{
				_engine.ForgetDebuff(tm.Id, slot.Value);
			}
			ImGui.TableSetColumnIndex(6);
			if (c.Reset == null)
			{
				c.Reset = "Reset##rs" + tm.Id;
			}
			if (ImGui.SmallButton(c.Reset))
			{
				_engine.ResetMonster(tm.Id);
			}
			Tip("Forget its vulns / DoTs and any BLOCKED / moving mark - MelkTank casts them all again.\n(Use it when it's shown DoT'd, vuln'd or blocked but isn't.)");
		}
		try
		{
			ItemTracker.DrawRows(_trackSort, _trackSortDesc);
		}
		catch (Exception ex2)
		{
			Util.LogError(ex2);
		}
		ImGui.EndTable();
	}

	private static WorldObject Selected()
	{
		try
		{
			int currentSelection = Globals.Core.Actions.CurrentSelection;
			return (currentSelection == 0) ? null : Globals.Core.WorldFilter[currentSelection];
		}
		catch
		{
			return null;
		}
	}

	private static void Tip(string text)
	{
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip(text);
		}
	}

	private static string FormatSpan(TimeSpan t)
	{
		if (t.TotalSeconds < 0.0)
		{
			return "0:00";
		}
		if (t.TotalHours >= 1.0)
		{
			return $"{(int)t.TotalHours}h {t.Minutes:00}m";
		}
		return $"{(int)t.TotalMinutes}:{t.Seconds:00}";
	}
}
