using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using MelkTank.Metas;
using AcClient;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Bounties;
using MelkTank.Buffs;

namespace MelkTank;

public static partial class Session
{
	private static string CarryFile()
	{
		CharacterFilter characterFilter = CoreManager.Current.CharacterFilter;
		string text = characterFilter.Server + "-" + characterFilter.Name;
		char[] invalidFileNameChars = Path.GetInvalidFileNameChars();
		foreach (char oldChar in invalidFileNameChars)
		{
			text = text.Replace(oldChar, '_');
		}
		return Util.FullPath("MelkTank_HotCarry_" + text + ".txt");
	}

	private static string E(string s)
	{
		return Uri.EscapeDataString(s ?? "");
	}

	private static string U(string s)
	{
		return Uri.UnescapeDataString(s ?? "");
	}

	private static string D(double d)
	{
		return d.ToString("R", CI);
	}

	public static void SaveCarry()
	{
		try
		{
			if (CoreManager.Current.CharacterFilter.LoginStatus != 3)
			{
				return;
			}
			StringBuilder b = new StringBuilder();
			Action<string, string> action = (string k, string v) =>
			{
				b.Append(k).Append('=').Append(v)
					.Append('\n');
			};
			action("pid", Process.GetCurrentProcess().Id.ToString(CI));
			action("char", E(CoreManager.Current.CharacterFilter.Name));
			action("saved", DateTime.UtcNow.Ticks.ToString(CI));
			action("login", Remote.LoginAtUtc.Ticks.ToString(CI));
			action("since", Cur.Since.ToUniversalTime().Ticks.ToString(CI));
			action("counts", string.Join(",", Array.ConvertAll(new int[10] { Cur.Kills, Cur.Deaths, Cur.LootItems, Cur.Corpses, Cur.CorpsesKept, Cur.LootArmor, Cur.LootClothing, Cur.LootJewelry, Cur.LootWeapons, Cur.LootMisc }, (int i) => i.ToString(CI))));
			foreach (MobStat value in Cur.Mobs.Values)
			{
				action("mob", E(value.Name) + "," + value.Species.ToString(CI) + "," + value.Kills.ToString(CI) + "," + D(value.TotalSecs) + "," + D(value.Fastest) + "," + D(value.Slowest));
			}
			List<string> list = new List<string>();
			foreach (DateTime item in _recent)
			{
				list.Add(item.ToUniversalTime().Ticks.ToString(CI));
			}
			action("recent", string.Join(",", list.ToArray()));
			action("recentsince", (_recentSince == DateTime.MinValue) ? "0" : _recentSince.ToUniversalTime().Ticks.ToString(CI));
			action("lum", string.Join(",", Array.ConvertAll(new long[5] { _lumEarned, _xpStart, _tokBase, _tokGot, _tokHeld }, (long i) => i.ToString(CI))));
			foreach (Sample sample in _samples)
			{
				action("sample", sample.At.ToUniversalTime().Ticks.ToString(CI) + "," + sample.Lum.ToString(CI) + "," + sample.Xp.ToString(CI));
			}
			action("packs", Packs.ToString(CI) + "," + PackKills.ToString(CI) + "," + D(PackTotalSecs) + "," + D(PackFastest) + "," + D(PackSlowest) + "," + D(PackLast));
			action("coins", D(_coinAcc) + "," + (_coinSynced ? "1" : "0") + "," + _coinsGot.ToString(CI) + "," + _coinAt.ToUniversalTime().Ticks.ToString(CI));
			List<string> list2 = new List<string>();
			foreach (DateTime coinTime in _coinTimes)
			{
				list2.Add(coinTime.ToUniversalTime().Ticks.ToString(CI));
			}
			action("cointimes", string.Join(",", list2.ToArray()));
			foreach (LootRec item2 in Looted)
			{
				action("loot", item2.At.ToUniversalTime().Ticks.ToString(CI) + "," + E(item2.Rule) + "," + E(item2.Desc) + "," + E(item2.Cat) + "," + E(item2.Vs) + "," + item2.VsColor.ToString(CI));
			}
			File.WriteAllText(CarryFile(), b.ToString());
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void LoadCarry()
	{
		string text = null;
		try
		{
			text = CarryFile();
			if (!File.Exists(text))
			{
				return;
			}
			string[] array = File.ReadAllLines(text);
			try
			{
				File.Delete(text);
			}
			catch
			{
			}
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			List<KeyValuePair<string, string>> list = new List<KeyValuePair<string, string>>();
			string[] array2 = array;
			foreach (string text2 in array2)
			{
				int num = text2.IndexOf('=');
				if (num > 0)
				{
					string key = text2.Substring(0, num);
					string value = (dictionary[key] = text2.Substring(num + 1));
					list.Add(new KeyValuePair<string, string>(key, value));
				}
			}
			int id = Process.GetCurrentProcess().Id;
			if (!dictionary.TryGetValue("pid", out var value2) || value2 != id.ToString(CI) || !dictionary.TryGetValue("char", out value2) || U(value2) != CoreManager.Current.CharacterFilter.Name || !dictionary.TryGetValue("saved", out value2) || (DateTime.UtcNow - new DateTime(long.Parse(value2, CI), DateTimeKind.Utc)).TotalMinutes > 5.0)
			{
				return;
			}
			Func<string, DateTime> func = (string x) =>
			{
				long num5 = long.Parse(x, CI);
				return (num5 <= DateTime.MinValue.Ticks + 864000000000L) ? DateTime.MinValue : new DateTime(num5, DateTimeKind.Utc).ToLocalTime();
			};
			if (dictionary.TryGetValue("login", out value2))
			{
				long num2 = long.Parse(value2, CI);
				if (num2 > 0)
				{
					Remote.LoginAtUtc = new DateTime(num2, DateTimeKind.Utc);
				}
			}
			if (dictionary.TryGetValue("since", out value2))
			{
				Cur.Since = func(value2);
			}
			if (dictionary.TryGetValue("counts", out value2))
			{
				string[] c = value2.Split(',');
				Func<int, int> func2 = (int num5) => (num5 < c.Length) ? int.Parse(c[num5], CI) : 0;
				Cur.Kills = func2(0);
				Cur.Deaths = func2(1);
				Cur.LootItems = func2(2);
				Cur.Corpses = func2(3);
				Cur.CorpsesKept = func2(4);
				Cur.LootArmor = func2(5);
				Cur.LootClothing = func2(6);
				Cur.LootJewelry = func2(7);
				Cur.LootWeapons = func2(8);
				Cur.LootMisc = func2(9);
			}
			Cur.Mobs.Clear();
			_recent.Clear();
			_samples.Clear();
			_coinTimes.Clear();
			Looted.Clear();
			foreach (KeyValuePair<string, string> item in list)
			{
				string[] array3 = item.Value.Split(',');
				switch (item.Key)
				{
				case "mob":
					if (array3.Length >= 6)
					{
						MobStat mobStat = new MobStat
						{
							Name = U(array3[0]),
							Species = int.Parse(array3[1], CI),
							Kills = int.Parse(array3[2], CI),
							TotalSecs = double.Parse(array3[3], CI),
							Fastest = double.Parse(array3[4], CI),
							Slowest = double.Parse(array3[5], CI)
						};
						Cur.Mobs[mobStat.Name] = mobStat;
					}
					break;
				case "recent":
				{
					string[] array4 = array3;
					foreach (string text4 in array4)
					{
						if (text4.Length > 0)
						{
							_recent.Add(func(text4));
						}
					}
					break;
				}
				case "recentsince":
					if (array3.Length != 0 && array3[0] != "0")
					{
						_recentSince = func(array3[0]);
					}
					break;
				case "lum":
					if (array3.Length >= 5)
					{
						_lumEarned = long.Parse(array3[0], CI);
						_xpStart = long.Parse(array3[1], CI);
						_tokBase = long.Parse(array3[2], CI);
						_tokGot = long.Parse(array3[3], CI);
						_tokHeld = long.Parse(array3[4], CI);
						_tokArmAt = DateTime.MinValue;
					}
					break;
				case "sample":
					if (array3.Length >= 3)
					{
						_samples.Add(new Sample
						{
							At = func(array3[0]),
							Lum = long.Parse(array3[1], CI),
							Xp = long.Parse(array3[2], CI)
						});
					}
					break;
				case "packs":
					if (array3.Length >= 6)
					{
						Packs = int.Parse(array3[0], CI);
						PackKills = int.Parse(array3[1], CI);
						PackTotalSecs = double.Parse(array3[2], CI);
						PackFastest = double.Parse(array3[3], CI);
						PackSlowest = double.Parse(array3[4], CI);
						PackLast = double.Parse(array3[5], CI);
					}
					break;
				case "coins":
					if (array3.Length >= 4)
					{
						_coinAcc = double.Parse(array3[0], CI);
						_coinSynced = array3[1] == "1";
						_coinsGot = int.Parse(array3[2], CI);
						_coinAt = func(array3[3]);
					}
					break;
				case "cointimes":
				{
					string[] array5 = array3;
					foreach (string text5 in array5)
					{
						if (text5.Length > 0)
						{
							_coinTimes.Add(func(text5));
						}
					}
					break;
				}
				case "loot":
					if (array3.Length >= 6)
					{
						Looted.Add(new LootRec
						{
							At = func(array3[0]),
							Rule = U(array3[1]),
							Desc = U(array3[2]),
							Cat = U(array3[3]),
							Vs = U(array3[4]),
							VsColor = int.Parse(array3[5], CI)
						});
					}
					break;
				}
			}
			_ratesAt = DateTime.MinValue;
			Util.WriteToChat("Session: carried on from the last build (" + Cur.Kills + " kills, " + Packs + " packs, " + Cur.Corpses + " corpses).");
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}
}
