using System;
using System.Collections;
using System.Collections.Generic;
using Decal.Adapter.Wrappers;
using MelkTank.Loot;

namespace MelkTank;

public class Vitals
{
	private class Keeper
	{
		private readonly Settings _s;

		private readonly string _label;

		private readonly string _spellBase;

		private readonly CharFilterVitalType _type;

		private readonly WeaponKind _kind;

		private readonly Func<bool> _enabled;

		private readonly Func<float> _pct;

		private readonly Func<int> _mode;

		private string _usedName = "";

		private DateTime _nextTry = DateTime.MinValue;

		private DateTime _holdUntil = DateTime.MinValue;

		private DateTime _lastWarn = DateTime.MinValue;

		private int _maxObserved;

		private int _spellId;

		private string _spellName;

		private DateTime _spellLookedUp = DateTime.MinValue;

		public string LastAction = "";

		public bool Busy => DateTime.Now < _holdUntil;

		public Keeper(Settings s, string label, CharFilterVitalType type, string spellBase, WeaponKind kind, Func<bool> enabled, Func<float> pct, Func<int> mode)
		{
			_s = s;
			_label = label;
			_type = type;
			_spellBase = spellBase;
			_kind = kind;
			_enabled = enabled;
			_pct = pct;
			_mode = mode;
		}

		public double Percent(out int cur, out int max)
		{
			cur = 0;
			max = 0;
			try
			{
				CharacterFilter characterFilter = Globals.Core.CharacterFilter;
				cur = ((_type == CharFilterVitalType.Mana) ? characterFilter.Mana : characterFilter.Stamina);
				int num = 0;
				try
				{
					num = characterFilter.EffectiveVital[_type];
				}
				catch
				{
				}
				if (cur > _maxObserved)
				{
					_maxObserved = cur;
				}
				max = ((num >= cur && num > 0) ? num : _maxObserved);
				if (max <= 0)
				{
					return -1.0;
				}
				double num2 = (double)cur * 100.0 / (double)max;
				return (num2 > 100.0) ? 100.0 : num2;
			}
			catch
			{
				return -1.0;
			}
		}

		public bool Tick()
		{
			if (!_enabled())
			{
				return false;
			}
			DateTime now = DateTime.Now;
			if (now < _nextTry)
			{
				return false;
			}
			double num = Percent(out var _, out var _);
			if (num < 0.0 || num >= (double)_pct())
			{
				return false;
			}
			if (_mode() == 1)
			{
				if (Globals.Core.Actions.CombatMode != CombatState.Magic)
				{
					bool flag = false;
					if (ReadyToCast != null)
					{
						try
						{
							flag = ReadyToCast();
						}
						catch
						{
						}
					}
					if (!flag)
					{
						if (ReadyToCast == null)
						{
							Warn(_label + " " + num.ToString("0") + "% - casting " + _spellBase.Replace(" Self", "") + " needs magic mode (holding a wand).");
							_nextTry = now.AddSeconds(5.0);
							return false;
						}
						LastAction = "switching to magic for " + _spellBase.Replace(" Self", "") + " (" + _label.ToLowerInvariant() + " " + num.ToString("0") + "%)";
						_holdUntil = now.AddSeconds(1.5);
						_nextTry = now.AddMilliseconds(400.0);
						return true;
					}
				}
				string text = BestSpell(out var id);
				if (id == 0)
				{
					Warn(_label + " " + num.ToString("0") + "% - you don't know any " + _spellBase + " spell.");
					_nextTry = now.AddSeconds(30.0);
					return false;
				}
				try
				{
					Globals.Core.Actions.CastSpell(id, Globals.Core.CharacterFilter.Id);
				}
				catch (Exception ex)
				{
					Util.LogError(ex);
				}
				LastAction = "casting " + text + " (" + _label.ToLowerInvariant() + " " + num.ToString("0") + "%)";
				_holdUntil = now.AddSeconds(2.0);
				_nextTry = now.AddSeconds(2.5);
				return true;
			}
			int num2 = FindItem();
			if (num2 == 0)
			{
				bool flag2 = false;
				foreach (WeaponItem item in _s.Items)
				{
					if (item.Kind == _kind)
					{
						flag2 = true;
					}
				}
				Warn(_label + " " + num.ToString("0") + "% but " + (flag2 ? ("none of the " + _label.ToLowerInvariant() + " items on the Items tab are left in your pack") : ("no " + _label.ToLowerInvariant() + " kit or potion is on the Items tab")) + ".");
				_nextTry = now.AddSeconds(10.0);
				return false;
			}
			try
			{
				WorldObject worldObject = Globals.Core.WorldFilter[num2];
				if (worldObject != null && (worldObject.ObjectClass == ObjectClass.HealingKit || worldObject.Name.IndexOf("kit", StringComparison.OrdinalIgnoreCase) >= 0))
				{
					Globals.Core.Actions.ApplyItem(num2, Globals.Core.CharacterFilter.Id);
				}
				else
				{
					Globals.Core.Actions.UseItem(num2, 0);
				}
			}
			catch (Exception ex2)
			{
				Util.LogError(ex2);
			}
			LastAction = "using " + _usedName + " (" + _label.ToLowerInvariant() + " " + num.ToString("0") + "%)";
			_holdUntil = now.AddSeconds(1.0);
			_nextTry = now.AddSeconds(1.5);
			return true;
		}

		private void Warn(string msg)
		{
			if (!(DateTime.Now - _lastWarn < TimeSpan.FromSeconds(30L)))
			{
				_lastWarn = DateTime.Now;
				Util.WriteToChat(msg);
			}
		}

		private int FindItem()
		{
			try
			{
				foreach (WeaponItem item in _s.Items)
				{
					if (item.Kind != _kind)
					{
						continue;
					}
					WorldObject worldObject = ((item.Id != 0) ? Globals.Core.WorldFilter[item.Id] : null);
					if (worldObject != null && InPack(item.Id))
					{
						_usedName = item.Name;
						return item.Id;
					}
					foreach (WorldObject item2 in InvCache.All())
					{
						if (string.Equals(item2.Name, item.Name, StringComparison.OrdinalIgnoreCase))
						{
							item.Id = item2.Id;
							_usedName = item.Name;
							return item2.Id;
						}
					}
				}
			}
			catch
			{
			}
			return 0;
		}

		private static bool InPack(int id) => InvCache.Has(id);

		public string BestSpell(out int id)
		{
			if ((DateTime.Now - _spellLookedUp).TotalSeconds > 60.0)
			{
				_spellLookedUp = DateTime.Now;
				_spellId = 0;
				_spellName = null;
				int num = 0;
				foreach (int item in KnownSpells())
				{
					string text = SpellNames.Name(item);
					int num2 = Level(text);
					if (num2 > num)
					{
						num = num2;
						_spellId = item;
						_spellName = text;
					}
				}
			}
			id = _spellId;
			return _spellName;
		}

		private int Level(string n)
		{
			if (string.IsNullOrEmpty(n))
			{
				return 0;
			}
			if (n.Equals("Incantation of " + _spellBase, StringComparison.OrdinalIgnoreCase))
			{
				return 8;
			}
			if (n.Equals(_spellBase, StringComparison.OrdinalIgnoreCase))
			{
				return 1;
			}
			if (!n.StartsWith(_spellBase + " ", StringComparison.OrdinalIgnoreCase))
			{
				return 0;
			}
			return n.Substring(_spellBase.Length + 1).Trim().ToUpperInvariant() switch
			{
				"I" => 1, 
				"II" => 2, 
				"III" => 3, 
				"IV" => 4, 
				"V" => 5, 
				"VI" => 6, 
				"VII" => 7, 
				_ => 0, 
			};
		}

		private static IEnumerable<int> KnownSpells() => PortalsTab.KnownSpellIds();
	}

	public const int ModeItem = 0;

	public const int ModeSpell = 1;

	public static Func<bool> ReadyToCast;

	private readonly Settings _s;

	private readonly Keeper _mana;

	private readonly Keeper _stamina;

	public bool Busy => _mana.Busy || _stamina.Busy;

	public string LastAction => _mana.Busy ? _mana.LastAction : _stamina.LastAction;

	public Vitals(Settings s)
	{
		_s = s;
		Migrate(WeaponKind.ManaKit, ref _s.ManaItemId, ref _s.ManaItemName);
		Migrate(WeaponKind.StaminaKit, ref _s.StaminaItemId, ref _s.StaminaItemName);
		_mana = new Keeper(_s, "Mana", CharFilterVitalType.Mana, "Stamina to Mana Self", WeaponKind.ManaKit, () => _s.ManaEnabled, () => _s.ManaPercent, () => _s.ManaMode);
		_stamina = new Keeper(_s, "Stamina", CharFilterVitalType.Stamina, "Revitalize Self", WeaponKind.StaminaKit, () => _s.StaminaEnabled, () => _s.StaminaPercent, () => _s.StaminaMode);
	}

	private void Migrate(WeaponKind kind, ref int id, ref string name)
	{
		if (string.IsNullOrEmpty(name))
		{
			return;
		}
		bool flag = false;
		foreach (WeaponItem item in _s.Items)
		{
			if (item.Kind == kind && string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
			{
				flag = true;
			}
		}
		if (!flag)
		{
			_s.Items.Add(new WeaponItem
			{
				Id = id,
				Name = name,
				Kind = kind
			});
		}
		id = 0;
		name = "";
	}

	public bool Tick()
	{
		if (_mana.Busy || _stamina.Busy)
		{
			return true;
		}
		if (_mana.Tick())
		{
			return true;
		}
		return _stamina.Tick();
	}

	public double ManaPercent(out int cur, out int max)
	{
		return _mana.Percent(out cur, out max);
	}

	public double StaminaPercent(out int cur, out int max)
	{
		return _stamina.Percent(out cur, out max);
	}

	public string ManaSpellName()
	{
		int id;
		return _mana.BestSpell(out id);
	}

	public string StaminaSpellName()
	{
		int id;
		return _stamina.BestSpell(out id);
	}
}
