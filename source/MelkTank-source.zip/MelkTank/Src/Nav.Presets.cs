using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
#if !RETAIL
using ACGodot.DecalShim;
using ACGodot.Plugins;
using ACGodot.UI;
#endif
#if !RETAIL
using AcClient;
#else
using SmartBox = AcClient.SmartBox;
using ACCmdInterp = AcClient.ACCmdInterp;
using CommandInterpreter = AcClient.CommandInterpreter;
using CommandListElement = AcClient.CommandListElement;
using CPhysicsObj = AcClient.CPhysicsObj;
using Position = AcClient.Position;
using CTransition = AcClient.CTransition;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
#if !RETAIL
using Godot;
#endif
using ImGuiNET;
using MelkTank.Loot;
using MelkTank.Metas;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public partial class Nav
{
	private bool DrawPresetRow(NavRoute r)
	{
		bool result = false;
		List<string> list = NavPresets.Names();
		if (list.Count == 0)
		{
			ImGui.BeginDisabled();
			AddButton("Add preset");
			ImGui.EndDisabled();
			ImGui.SameLine();
			Im.TextColored(Grey, "make one on the Presets tab first");
			return false;
		}
		if (_rPresetPick >= list.Count)
		{
			_rPresetPick = 0;
		}
		if (AddButton("Add preset"))
		{
			Insert(r, new RouteStep
			{
				Kind = StepKind.Preset,
				Text = list[_rPresetPick]
			});
			result = true;
		}
		Tip("A set of steps made on the Presets tab (e.g. Mob Pack: combat on, wait, combat off) - put it where it's needed.\nLinked: changing the preset changes it in every route that uses it.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(200f);
		ImGui.Combo("##rpreset", ref _rPresetPick, list.ToArray(), list.Count);
		if (_rSel >= 0 && _rSel < r.Steps.Count && r.Steps[_rSel].Kind == StepKind.Preset)
		{
			ImGui.SameLine();
			if (ImGui.SmallButton("make plain steps##rpflat"))
			{
				RouteStep routeStep = r.Steps[_rSel];
				NavRoute navRoute = NavPresets.Find(routeStep.Text);
				if (navRoute == null)
				{
					Util.WriteToChat("Nav: there's no preset called " + routeStep.Text + ".");
				}
				else
				{
					int rSel = _rSel;
					r.Steps.RemoveAt(rSel);
					for (int i = 0; i < navRoute.Steps.Count; i++)
					{
						r.Steps.Insert(rSel + i, NavPresets.Copy(navRoute.Steps[i]));
					}
					if (_rIdx > rSel)
					{
						_rIdx += navRoute.Steps.Count - 1;
					}
					_rSubFor = -1;
					Util.WriteToChat("Nav: " + routeStep.Text + " turned into " + navRoute.Steps.Count + " plain steps in this route (not linked any more).");
					result = true;
				}
			}
			Tip("Puts the preset's steps into this route as ordinary steps, so they can be changed here only.");
		}
		return result;
	}

	private void DrawPresetSubRows(RouteStep st, int i, bool here)
	{
		NavRoute navRoute = NavPresets.Find(st.Text);
		if (navRoute != null)
		{
			int num = (here ? SubNow() : (-1));
			for (int j = 0; j < navRoute.Steps.Count; j++)
			{
				RouteStep routeStep = navRoute.Steps[j];
				ImGui.TableNextRow();
				ImGui.PushID("ps" + i + "_" + j);
				System.Numerics.Vector4 col = ((num == j) ? Green : Grey);
				ImGui.TableSetColumnIndex(0);
				Im.TextColored(col, ((num == j) ? ">" : "") + (i + 1) + "." + (j + 1));
				ImGui.TableSetColumnIndex(1);
				Im.TextColored(col, "  " + KindName(routeStep.Kind));
				ImGui.TableSetColumnIndex(2);
				Im.TextColored(col, "    " + Describe(routeStep));
				ImGui.PopID();
			}
		}
	}

	private void DrawPresetsTab()
	{
		bool flag = false;
		bool flag2 = false;
		NavPresets.Load();
		List<string> list = NavPresets.Names();
		NavRoute navRoute = NavPresets.Find(_pName);
		if (navRoute == null && NavPresets.All.Count > 0)
		{
			navRoute = NavPresets.All[0];
			_pName = navRoute.Name;
			_pSel = -1;
			_pEdit = null;
		}
		Im.TextColored(Grey, "Sets of steps without locations (switches, waits, commands, use item ...) to drop into routes with \"Add preset\".\nLinked: a change here changes every route that uses the preset. Shared by all your characters.");
		ImGui.SetNextItemWidth(220f);
		if (ImGui.BeginCombo("Preset##pname", (navRoute != null) ? navRoute.Name : "(no presets yet)"))
		{
			for (int i = 0; i < list.Count; i++)
			{
				if (ImGui.Selectable(list[i] + "##pn" + i, navRoute != null && list[i] == navRoute.Name))
				{
					_pName = list[i];
					_pSel = -1;
					_pEdit = null;
				}
			}
			ImGui.EndCombo();
		}
		navRoute = NavPresets.Find(_pName);
		if (navRoute != null)
		{
			ImGui.SameLine();
			if (ImGui.Button("Copy##pcopy"))
			{
				NavRoute navRoute2 = new NavRoute
				{
					Name = UniqueName(navRoute.Name + " copy"),
					Mode = 0
				};
				foreach (RouteStep step in navRoute.Steps)
				{
					navRoute2.Steps.Add(NavPresets.Copy(step));
				}
				NavPresets.All.Add(navRoute2);
				_pName = navRoute2.Name;
				_pSel = -1;
				_pEdit = null;
				flag = true;
			}
			ImGui.SameLine();
			int num = Uses(navRoute.Name);
			if (ImGui.Button("Delete##pdel"))
			{
				NavPresets.All.Remove(navRoute);
				flag = true;
				if (num > 0)
				{
					Util.WriteToChat("Nav: preset " + navRoute.Name + " deleted - " + num + " route step" + ((num == 1) ? "" : "s") + " using it will be skipped.");
				}
				_pName = ((NavPresets.All.Count > 0) ? NavPresets.All[0].Name : "");
				_pSel = -1;
				_pEdit = null;
				navRoute = NavPresets.Find(_pName);
			}
			Tip("Routes that use it skip that step (say so in chat) until a preset with the same name is made again.");
			ImGui.SameLine();
			Im.TextColored(Grey, (num == 0) ? "not used in this character's routes" : ("used " + num + " time" + ((num == 1) ? "" : "s") + " in this character's routes"));
		}
		ImGui.SetNextItemWidth(220f);
		ImGui.InputText("Name##pnewname", ref _pNewName, 64u);
		ImGui.SameLine();
		string text = _pNewName.Trim();
		bool flag3 = text.Length > 0 && NavPresets.Find(text) != null;
		if (ImGui.Button("New preset##pnew") && text.Length > 0 && !flag3)
		{
			NavRoute navRoute3 = new NavRoute
			{
				Name = text,
				Mode = 0
			};
			NavPresets.All.Add(navRoute3);
			_pName = text;
			_pNewName = "";
			_pSel = -1;
			_pEdit = null;
			flag = true;
			navRoute = navRoute3;
		}
		if (navRoute != null)
		{
			ImGui.SameLine();
			if (ImGui.Button("Rename##pren") && text.Length > 0 && !flag3)
			{
				string name = navRoute.Name;
				navRoute.Name = text;
				_pName = text;
				_pNewName = "";
				foreach (NavRoute navRoute4 in _s.NavRoutes)
				{
					foreach (RouteStep step2 in navRoute4.Steps)
					{
						if (step2.Kind == StepKind.Preset && string.Equals(step2.Text, name, StringComparison.OrdinalIgnoreCase))
						{
							step2.Text = text;
							flag2 = true;
						}
					}
				}
				flag = true;
				Util.WriteToChat("Nav: preset " + name + " is now " + text + " (this character's routes changed to match; another character's routes still say " + name + ").");
			}
		}
		if (flag3)
		{
			ImGui.SameLine();
			Im.TextColored(Yellow, "there's already a preset called that");
		}
		if (navRoute == null)
		{
			Im.TextColored(Grey, "Type a name and click New preset.");
			if (flag)
			{
				NavPresets.Save();
			}
			return;
		}
		ImGui.Separator();
		if (_pEdit != null && !navRoute.Steps.Contains(_pEdit))
		{
			_pEdit = null;
		}
		int num2 = -1;
		int num3 = -1;
		int num4 = -1;
		if (ImGui.BeginTable("presetsteps", 5, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY, new System.Numerics.Vector2(606f, 300f)))
		{
			ImGui.TableSetupColumn("#", ImGuiTableColumnFlags.WidthFixed, 30f);
			ImGui.TableSetupColumn("Step", ImGuiTableColumnFlags.WidthFixed, 80f);
			ImGui.TableSetupColumn("Detail", ImGuiTableColumnFlags.WidthFixed, 330f);
			ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 60f);
			ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 26f);
			ImGui.TableSetupScrollFreeze(0, 1);
			ImGui.TableHeadersRow();
			for (int j = 0; j < navRoute.Steps.Count; j++)
			{
				RouteStep routeStep = navRoute.Steps[j];
				ImGui.TableNextRow();
				ImGui.PushID("p" + j);
				ImGui.TableSetColumnIndex(0);
				Im.TextColored(Grey, (j + 1).ToString());
				ImGui.TableSetColumnIndex(1);
				if (ImGui.Selectable(KindName(routeStep.Kind) + "##ps", _pSel == j, ImGuiSelectableFlags.SpanAllColumns | ImGuiSelectableFlags.AllowOverlap))
				{
					_pSel = ((_pSel == j) ? (-1) : j);
				}
				Tip("Click: select (new steps go after it; Edit step changes it).");
				ImGui.TableSetColumnIndex(2);
				Im.TextColored((routeStep == _pEdit) ? Yellow : System.Numerics.Vector4.One, ((routeStep == _pEdit) ? "(editing) " : "") + Describe(routeStep));
				ImGui.TableSetColumnIndex(3);
				if (j > 0)
				{
					if (Im.UpButton("##pup"))
					{
						num2 = j;
					}
					ImGui.SameLine();
				}
				if (j < navRoute.Steps.Count - 1 && Im.DownButton("##pdn"))
				{
					num3 = j;
				}
				ImGui.TableSetColumnIndex(4);
				if (ImGui.SmallButton("x"))
				{
					num4 = j;
				}
				ImGui.PopID();
			}
			ImGui.EndTable();
		}
		ImGui.SameLine();
		ImGui.BeginGroup();
		int rSel = _rSel;
		RouteStep rEdit = _rEdit;
		_rSel = _pSel;
		_rEdit = _pEdit;
		try
		{
			flag |= DrawAddRows(navRoute, preset: true);
		}
		finally
		{
			_pSel = _rSel;
			_pEdit = _rEdit;
			_rSel = rSel;
			_rEdit = rEdit;
		}
		ImGui.EndGroup();
		if (num2 > 0 || num3 >= 0)
		{
			RouteStep routeStep2 = ((_pSel >= 0 && _pSel < navRoute.Steps.Count) ? navRoute.Steps[_pSel] : null);
			Im.Move(navRoute.Steps, (num2 > 0) ? num2 : num3, num2 > 0);
			if (routeStep2 != null)
			{
				_pSel = navRoute.Steps.IndexOf(routeStep2);
			}
			flag = true;
		}
		if (num4 >= 0)
		{
			if (navRoute.Steps[num4] == _pEdit)
			{
				_pEdit = null;
			}
			navRoute.Steps.RemoveAt(num4);
			if (_pSel >= navRoute.Steps.Count)
			{
				_pSel = navRoute.Steps.Count - 1;
			}
			flag = true;
		}
		if (navRoute.Steps.Count == 0)
		{
			Im.TextColored(Grey, "No steps yet - add them with the buttons on the right.");
		}
		if (flag)
		{
			NavPresets.Save();
		}
		if (flag2 && SaveAll != null)
		{
			SaveAll();
		}
	}

	private static string UniqueName(string b)
	{
		string text = b;
		int num = 2;
		while (NavPresets.Find(text) != null)
		{
			text = b + " " + num++;
		}
		return text;
	}

	private int Uses(string name)
	{
		int num = 0;
		foreach (NavRoute navRoute in _s.NavRoutes)
		{
			foreach (RouteStep step in navRoute.Steps)
			{
				if (step.Kind == StepKind.Preset && string.Equals(step.Text, name, StringComparison.OrdinalIgnoreCase))
				{
					num++;
				}
			}
		}
		return num;
	}
}
