using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using MelkTank.Metas;
using AcClient;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Bounties;
using MelkTank.Buffs;

namespace MelkTank;

public static partial class Session
{
	public class MobStat
	{
		public string Name;

		public int Species;

		public int Kills;

		public double TotalSecs;

		public double Fastest = double.MaxValue;

		public double Slowest;

		public double Avg => (Kills > 0) ? (TotalSecs / (double)Kills) : 0.0;
	}

	public class Stats
	{
		public DateTime Since = DateTime.Now;

		public double PlayedSecs;

		public int Kills;

		public int Deaths;

		public int LootItems;

		public int Corpses;

		public int CorpsesKept;

		public int LootArmor;

		public int LootClothing;

		public int LootJewelry;

		public int LootWeapons;

		public int LootMisc;

		public readonly Dictionary<string, MobStat> Mobs = new Dictionary<string, MobStat>(StringComparer.OrdinalIgnoreCase);

		public void Clear()
		{
			Since = DateTime.Now;
			PlayedSecs = 0.0;
			Kills = (Deaths = (LootItems = (Corpses = (CorpsesKept = 0))));
			LootArmor = (LootClothing = (LootJewelry = (LootWeapons = (LootMisc = 0))));
			Mobs.Clear();
		}

		public void AddKill(string name, int species, double secs)
		{
			Kills++;
			if (!Mobs.TryGetValue(name, out var value))
			{
				value = new MobStat
				{
					Name = name
				};
				Mobs[name] = value;
			}
			if (species > 0)
			{
				value.Species = species;
			}
			value.Kills++;
			value.TotalSecs += secs;
			if (secs < value.Fastest)
			{
				value.Fastest = secs;
			}
			if (secs > value.Slowest)
			{
				value.Slowest = secs;
			}
		}

		public void AddLoot(ObjectClass c)
		{
			LootItems++;
			switch (c)
			{
			case ObjectClass.Armor:
				LootArmor++;
				break;
			case ObjectClass.Clothing:
				LootClothing++;
				break;
			case ObjectClass.Jewelry:
				LootJewelry++;
				break;
			case ObjectClass.MeleeWeapon:
			case ObjectClass.MissileWeapon:
			case ObjectClass.WandStaffOrb:
				LootWeapons++;
				break;
			default:
				LootMisc++;
				break;
			}
		}
	}

	private class Gone
	{
		public string Name;

		public int Species;

		public DateTime EngagedAt;

		public DateTime At;

		public bool Unengaged;
	}

	private class KillText
	{
		public string Text;

		public DateTime At;
	}

	private class Corpse
	{
		public string Name;

		public DateTime At;
	}

	public class LootRec
	{
		public DateTime At;

		public string Rule = "";

		public string Desc = "";

		public string Cat = "";

		public string Vs = "";

		public int VsColor = 7;
	}

	private class SeenBounty
	{
		public string Zone;

		public string Reward;

		public string Count;

		public DateTime At;

		public DateTime UnlocksAt;

		public int Have;

		public int Need;
	}

	private class BankLine
	{
		public string Name;

		public string Value;

		public DateTime At;
	}

	private class Sample
	{
		public DateTime At;

		public long Lum;

		public long Xp;
	}

	private class SortState
	{
		public int Col = 1;

		public bool Desc = true;

		public int OpenAll;
	}

	private class Group
	{
		public int Species;

		public string Name;

		public readonly List<MobStat> Mobs = new List<MobStat>();

		public int Kills;

		public double TotalSecs;

		public double Fastest = double.MaxValue;

		public double Slowest;

		public double Avg => (Kills > 0) ? (TotalSecs / (double)Kills) : 0.0;
	}

	private class AttrRow
	{
		public string Key;

		public string Name;

		public string Abbr;

		public long Cost;

		public long Cost10;

		public DateTime CostAt;
	}

	private class AugKind
	{
		public string Tab;

		public string Key;

		public string Gem;

		public int Coins;

		public int[] Caps;

		public AugKind(string t, string k, string g, int coins, params int[] caps)
		{
			Tab = t;
			Key = k;
			Gem = g;
			Coins = coins;
			Caps = ((caps != null && caps.Length != 0) ? caps : null);
		}
	}

	private class AugQuote
	{
		public long Level;

		public long Levels;

		public long Lum;
	}

	private enum Ae
	{
		Off,
		Train,
		Start,
		Going,
		Outside,
		Jumped,
		Sent,
		Yes,
		Subway
	}

	public class BountyTier
	{
		public double RewardB = 100.0;

		public double CooldownMin = 60.0;

		public int Kills = 300;

		public bool Set;
	}

	public class DeedTier
	{
		public int QB;

		public bool Unlocked;

		public List<string> Lines = new List<string>();
	}

	public class EnlPlanResult
	{
		public int Reach;

		public string Stop = "";

		public long BuyTokens;

		public long SellCoins;

		public long SellLum;

		public long Medallions;

		public long Parts;

		public long TokensUsed;

		public long LumNeeded;

		public long LumShort;

		public long TokensShort;

		public long PartsShort;

		public bool Possible = true;
	}

	public class RtEntry
	{
		public int Skill;

		public bool Train;

		public bool Spec;

		public bool Enl;
	}

	[UnmanagedFunctionPointer(CallingConvention.ThisCall)]
	private delegate nint GetSkillBaseDel(nint table, uint skill);

	private static readonly Vector4 BGreen = new Vector4(0.45f, 0.9f, 0.45f, 1f);

	private static readonly Vector4 BGold = new Vector4(0.95f, 0.8f, 0.3f, 1f);

	private static readonly Vector4 BOrange = new Vector4(1f, 0.6f, 0.2f, 1f);

	private static readonly Vector4 BGrey = new Vector4(0.6f, 0.6f, 0.6f, 1f);

	public static readonly Stats Cur = new Stats();

	public static readonly Stats All = new Stats();

	private static readonly List<KillText> _killTexts = new List<KillText>();

	private static readonly List<Gone> _gone = new List<Gone>();

	private static readonly List<Corpse> _corpses = new List<Corpse>();

	private static DateTime _killLineAt = DateTime.MinValue;

	private static DateTime _killEventAt = DateTime.MinValue;

	// what your pet hit, and when ("[Pet] Melka Summoner's Alarming Simulacrum Melee hit Crusty Cheese for 31020"): a monster
	// only the pet fought leaves no death line and no corpse (pet-only ones), just the luminance banked - that and the pet's hit count it
	private static readonly Dictionary<string, DateTime> _petHits = new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);
	private static readonly Regex PetHitRx = new Regex("^\\[Pet\\] .+? hit (.+?) for [\\d,]+", RegexOptions.Compiled);
	private static bool PetKilled(Gone g) =>
		_petHits.TryGetValue(g.Name, out DateTime at) && (g.At - at).TotalSeconds < 30.0 && Math.Abs((_killLineAt - g.At).TotalSeconds) <= 5.0;

	private static DateTime _nextTick = DateTime.MinValue;

	private const double MatchSecs = 5.0;

	private const double NearM = 60.0;

	private static string _file;

	private static DateTime _playedMark = DateTime.Now;

	private static bool _allDirty;

	private static DateTime _savedAt = DateTime.MinValue;

	public static readonly List<LootRec> Looted = new List<LootRec>();

	private const int MaxLooted = 500;

	private static readonly Dictionary<string, SeenBounty> _bounties = new Dictionary<string, SeenBounty>(StringComparer.OrdinalIgnoreCase);

	private static readonly Regex BountyHereRx = new Regex("^Bounty(?: \\((?<zone>[^)]*)\\))?:\\s*(?<reward>.+?)\\s+-\\s+(?<have>[\\d,]+) of (?<need>[\\d,]+) kills\\.?$", RegexOptions.IgnoreCase);

	private static readonly Regex BountyLockedRx = new Regex("^Bounty(?: \\((?<zone>[^)]*)\\))?:\\s*(?<reward>.+?)\\s+-\\s+unlocks in (?<time>.+?),\\s*then (?<need>[\\d,]+) kills required\\.?$", RegexOptions.IgnoreCase);

	private static readonly Regex SpanPartRx = new Regex("(?<n>\\d+)\\s*(?<u>days?|d|hours?|hrs?|h|minutes?|mins?|m|seconds?|secs?|s)\\b", RegexOptions.IgnoreCase);

	private static readonly Regex HaveNeedRx = new Regex("^\\s*([\\d,]+)\\s*/\\s*([\\d,]+)");

	private static bool _hooked;

	private static readonly List<BankLine> _bank = new List<BankLine>();

	private static string _bankFile;

	private static readonly Regex BankRx = new Regex("^\\[BANK\\]\\s*(?<n>[^:]+?):\\s*(?<v>.+)$", RegexOptions.IgnoreCase);

	private static DateTime _bankDirtyAt = DateTime.MinValue;

	private static readonly List<KeyValuePair<string, string>> _augs = new List<KeyValuePair<string, string>>();

	private static DateTime _augsAt = DateTime.MinValue;

	private static DateTime _augCaptureUntil = DateTime.MinValue;

	private static string _augFile;

	private static readonly Regex AugLineRx = new Regex("^(?<n>[A-Za-z][^:]{1,60}?):\\s*(?<v>.+)$");

	private static DateTime _augDirtyAt = DateTime.MinValue;

	// /aug's "Hunting rewards this week" part (T11+): augmentations earned by kills in your own tier
	private static readonly List<string> _augHunt = new List<string>();

	private static bool _augInHunt;

	// ── augs gained by hunting this session (T11+): Creature/Item/Life from rewards, read off /aug reading to reading ──
	private static readonly Dictionary<string, long> _huntGain = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase);
	private static readonly Dictionary<string, long> _huntSnap = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase);
	private static readonly string[] HuntKinds = { "Creature", "Item", "Life" };

	/// <summary>A new /aug (its rows read, its hunting part starting): what Creature, Item and Life went up by since the last
	/// one is hunting's - no more than the rewards the kills between could have given (a few more allowed), so levels
	/// bought with luminance in between aren't counted.</summary>
	private static void NoteHuntGains()
	{
		int rate = 0;
		AugKillsLeft(out rate);
		if (rate <= 0) rate = 119;
		long most = _augKillsSince / rate + 2;
		foreach (string k in HuntKinds)
		{
			int i = _augs.FindIndex(a => string.Equals(a.Key, k, StringComparison.OrdinalIgnoreCase));
			if (i < 0 || !long.TryParse(Regex.Match(_augs[i].Value, "^[\\d,]+").Value.Replace(",", ""), out long now)) continue;
			if (_huntSnap.TryGetValue(k, out long was) && now > was)
			{
				_huntGain.TryGetValue(k, out long g);
				_huntGain[k] = g + Math.Min(now - was, most);
			}
			_huntSnap[k] = now;
		}
	}

	/// <summary>Augs gained an hour this session by hunting (rewards) and attack gems, by kind - and all together.</summary>
	public static List<KeyValuePair<string, double>> AugRates(out double total)
	{
		var list = new List<KeyValuePair<string, double>>();
		total = 0;
		double h = Hours;
		if (h <= 1.0 / 60.0) return list;
		foreach (string k in HuntKinds)
			if (_huntGain.TryGetValue(k, out long g) && g > 0) { list.Add(new KeyValuePair<string, double>(k, g / h)); total += g / h; }
		foreach (var kv in AttackGems.UsedBySchool)
			if (kv.Value > 0) { list.Add(new KeyValuePair<string, double>(kv.Key, kv.Value / h)); total += kv.Value / h; }
		return list;
	}

	/// <summary>Kills (in T11+) since /aug last gave the week's count.</summary>
	private static int _augKillsSince;

	private static DateTime _augHuntResetAt = DateTime.MinValue;

	private static readonly Regex AugHuntLineRx = new Regex("^(Hunting rewards|Each reward|Attack school|Kills this week|First [\\d,]+ kills|After [\\d,]+ kills|Beyond [\\d,]+ kills|Week resets|This tier so far)", RegexOptions.IgnoreCase);

	private static readonly Regex AugNumberRowRx = new Regex("^(?<n>[A-Za-z][^:]{1,60}?):\\s*(?<v>[\\d,]+(\\s.*)?)$");

	private static readonly Regex AugResetInRx = new Regex("\\(in (?:(?<d>\\d+) days?)?\\s*(?:(?<h>\\d+) hours?)?\\s*(?:(?<m>\\d+) min(?:ute)?s?)?\\)", RegexOptions.IgnoreCase);

	private static readonly Regex AugTierSoFarRx = new Regex("(?<n>[A-Za-z]+) (?<v>[\\d,]+) of (?<c>[\\d,]+)");

	private static DateTime _quietBankUntil = DateTime.MinValue;

	private static DateTime _quietAugUntil = DateTime.MinValue;

	private static DateTime _bankNextPoll = DateTime.MinValue;

	private static long _lumEarned;

	private static long _xpStart = -1L;

	public static bool CountLumTokens = true;

	public static double LumTokenValue = 50000000000.0;

	private const string LumTokenName = "thaelaryn token of luminance";

	private static long _tokBase = -1L;

	private static long _tokGot;

	private static long _tokHeld;

	// (the "You've banked ... Luminance" lines alone - what the bank gained beyond them is fellowship shares and passup)
	private static long _lumBankedLines;

	public static long LumBankedLines => _lumBankedLines;

	private static readonly Regex TokDepositRx = new Regex("^Deposited (?<n>[\\d,]+) x Thaelaryn Tokens? of Luminance", RegexOptions.IgnoreCase);

	private static DateTime _tokNext = DateTime.MinValue;

	private static DateTime _tokArmAt = DateTime.MinValue;

	private static readonly List<Sample> _samples = new List<Sample>();

	private static DateTime _nextSample = DateTime.MinValue;

	private static DateTime _ratesAt = DateTime.MinValue;

	private static double _lumPh;

	private static double _xpPh;

	private static double _lumPhR;

	private static double _xpPhR;

	public const int PackMinKills = 3;

	private static bool _inFight;

	private static DateTime _fightStart;

	private static DateTime _lastMobsAt;

	private static DateTime _fightEndAt;

	private static int _fightKills0;

	public static int Packs;

	public static int PackKills;

	public static double PackTotalSecs;

	public static double PackFastest = double.MaxValue;

	public static double PackSlowest;

	public static double PackLast;

	private static readonly List<DateTime> _recent = new List<DateTime>();

	private static DateTime _recentSince = DateTime.MinValue;

	private static readonly Vector4 Cyan = new Vector4(0.35f, 0.85f, 0.95f, 1f);

	private static readonly Vector4 Yellow = new Vector4(0.95f, 0.85f, 0.35f, 1f);

	private static readonly SortState _curSort = new SortState();

	private static readonly SortState _allSort = new SortState();

	private static bool _confirmReset;

	private static bool _confirmResetAll;

	private static readonly AttrRow[] AttrRows = new AttrRow[9]
	{
		new AttrRow
		{
			Key = "Strength",
			Name = "Strength",
			Abbr = "str"
		},
		new AttrRow
		{
			Key = "Endurance",
			Name = "Endurance",
			Abbr = "end"
		},
		new AttrRow
		{
			Key = "Coordination",
			Name = "Coordination",
			Abbr = "coo"
		},
		new AttrRow
		{
			Key = "Quickness",
			Name = "Quickness",
			Abbr = "qui"
		},
		new AttrRow
		{
			Key = "Focus",
			Name = "Focus",
			Abbr = "foc"
		},
		new AttrRow
		{
			Key = "Self",
			Name = "Self",
			Abbr = "sel"
		},
		new AttrRow
		{
			Key = "MaxHealth",
			Name = "Max Health",
			Abbr = "hea"
		},
		new AttrRow
		{
			Key = "MaxStamina",
			Name = "Max Stamina",
			Abbr = "sta"
		},
		new AttrRow
		{
			Key = "MaxMana",
			Name = "Max Mana",
			Abbr = "man"
		}
	};

	private const double AttrGrowth = 1.077;

	private static readonly Regex AttrCostRx = new Regex("^\\[XP\\] Your XP cost for next (\\d+) (\\w+) levels? is: ([\\d,]+)", RegexOptions.IgnoreCase);

	private static readonly Regex AttrRaisedRx = new Regex("Your base (?:Maximum )?(\\w+) is now ([\\d,]+)!", RegexOptions.IgnoreCase);

	private static DateTime _attrQuietUntil = DateTime.MinValue;

	private static DateTime _attrNextAuto = DateTime.MinValue;

	private static DateTime _attrSentAt = DateTime.MinValue;

	private static DateTime _attrAskedAt = DateTime.MinValue;

	private static bool _attrSpending;

	private static bool _attrWaitRaise;

	private static string _attrStatus = "";

	private static string _attrSpentNote = "";

	private static int _attrSpentLevels;

	private static readonly List<string> _attrQ = new List<string>();

	private static DateTime _attrNextStep = DateTime.MinValue;

	private static readonly AugKind[] AugKinds = new AugKind[10]
	{
		new AugKind("Creature", "Creature", "Creature Magic", 3, 2750, 4000, 4750, 5250),
		new AugKind("Item", "Item", "Item Magic", 18, 1250, 2000, 3000, 3500),
		new AugKind("Life", "Life", "Life Magic", 12, 1000, 2000, 3000, 3750),
		new AugKind("War", "War", "War Magic", 5, 1750, 2500, 3000, 3750),
		new AugKind("Void", "Void", "Void Magic", 5, 1750, 2500, 3000, 3750),
		new AugKind("Duration", "Duration", "Spell Duration", 5, 1000, 2000, 2500, 3000),
		new AugKind("Specialization", "Specialization", "Specialized Skill", 50),
		new AugKind("Summon", "Summon", "Summoning", 36, 1250, 2000, 3000, 3500),
		new AugKind("Melee", "Melee", "Melee", 5, 1750, 2500, 3000, 3750),
		new AugKind("Missile", "Missile", "Missile", 5, 1750, 2500, 3000, 3750)
	};

	private static readonly int[] GemSizes = new int[4] { 1, 10, 50, 100 };

	private static readonly Dictionary<string, string> _augGoal = new Dictionary<string, string>();

	private static DateTime _augRecheckAt = DateTime.MinValue;

	private static Dictionary<string, AugQuote> _augQuotes;

	private static readonly Regex AugQuoteRx = new Regex("spend ([\\d,]+) luminance to add ([\\d,]+) points? to your (.+?)(?: spell effects| abilit| skill|\\.|$)", RegexOptions.IgnoreCase);

	private static double _coinLum = -1.0;

	private static DateTime _coinLumAt = DateTime.MinValue;

	private static readonly Vector4 AugGreen = new Vector4(0.45f, 0.9f, 0.45f, 1f);

	private static readonly Vector4 AugYellow = new Vector4(0.95f, 0.85f, 0.35f, 1f);

	private const string AePauser = "Auto enlighten";

	public static string AeGo = "";

	public static int AeTarget;

	private static Ae _ae = Ae.Off;

	private static string _aeStatus = "";

	private static DateTime _aeAt = DateTime.MinValue;

	private static DateTime _aeStepAt = DateTime.MinValue;

	private static DateTime _aeCellAt = DateTime.MinValue;

	private static DateTime _aeLvlAt = DateTime.MinValue;

	private static int _aeCell;

	private static int _aeTries;

	private static int _aeRefused;

	private static int _aeDone;

	private static bool _aeError;

	private static bool _aeMagicAsked;

	private static bool _aeStill;

	private static string _aeLastError = "";

	private static List<string> _aeOpts;

	private static DateTime _aeOptsAt = DateTime.MinValue;

	public const int BountyTierMin = 11;

	public const int BountyTierMax = 25;

	public static bool BountyRateOn;

	public static Func<int> CurrentTier = () => -1;

	private static readonly Dictionary<int, BountyTier> _bountyTiers = new Dictionary<int, BountyTier>();

	private static bool _bountyLoaded;

	private static bool _lumIsBounty;

	private static int _bountyPick = -1;

	private static readonly CultureInfo CI = CultureInfo.InvariantCulture;

	private static readonly double[] CoinRates = new double[8] { 0.05, 0.06, 0.072, 0.086, 0.104, 0.124, 0.149, 0.179 };

	private static double _coinAcc;

	private static bool _coinSynced;

	private static int _coinsGot;

	private static DateTime _coinAt = DateTime.MinValue;

	private static readonly List<DateTime> _coinTimes = new List<DateTime>();

	private static readonly Regex CoinRx = new Regex("^(?<n>[\\d,]+) Prestige Coins? (?:has|have) been added to your bank", RegexOptions.IgnoreCase);

	private static readonly List<KeyValuePair<DateTime, int>> _coinLog = new List<KeyValuePair<DateTime, int>>();

	private static readonly List<DeedTier> _deeds = new List<DeedTier>();

	private static readonly List<KeyValuePair<string, string>> _bonus = new List<KeyValuePair<string, string>>();

	private static string _deedsHead = "";

	private static string _qbCount = "";

	private static bool _deedsOn = true;

	private static DateTime _deedsAt = DateTime.MinValue;

	private static DateTime _qbAt = DateTime.MinValue;

	private static DateTime _bonusAt = DateTime.MinValue;

	private static DateTime _deedCaptureUntil = DateTime.MinValue;

	private static DateTime _bonusCaptureUntil = DateTime.MinValue;

	private static DateTime _deedsDirtyAt = DateTime.MinValue;

	private static DateTime _quietDeedsUntil = DateTime.MinValue;

	private static DateTime _quietQbUntil = DateTime.MinValue;

	private static DateTime _quietBonusUntil = DateTime.MinValue;

	private static string _deedsFile;

	private static DeedTier _curTier;

	private static readonly Regex DeedHeadRx = new Regex("^Your QB:\\s*[\\d,]+\\s*-\\s*Deeds bonuses are (?<on>ON|OFF)", RegexOptions.IgnoreCase);

	private static readonly Regex DeedTierRx = new Regex("^(?<qb>\\d[\\d,]*)\\s*QB(?<u>\\s*\\(unlocked\\))?\\s*$", RegexOptions.IgnoreCase);

	private static readonly Regex QbRx = new Regex("Your current quest bonus count:\\s*(?<n>[\\d,]+)", RegexOptions.IgnoreCase);

	private static readonly Regex BonusRx = new Regex("^\\[BONUS\\]\\s*Your (?:XP multiplier from )?(?<n>.+?) is:\\s*(?<v>.+)$", RegexOptions.IgnoreCase);

	private static readonly CultureInfo EnlInv = CultureInfo.InvariantCulture;

	private static int _enlManual;

	private static readonly string[] EnlItems = new string[7] { "Enlightenment Medallion", "Enlightenment Token", "Part of a Medallion", "Trophy", "Yellow Aetheria Powder", "Yellow Aetheria Chunk", "Aetheria Desiccant" };

	private static readonly Dictionary<string, int> _enlHave = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

	private static DateTime _enlCountAt = DateTime.MinValue;

	public static bool MkPowder = true;

	public static bool MkParts = true;

	public static bool MkMedallions = true;

	public static bool MkFiun = true;

	private const string FiunBig = "Fiun of Great Enlightenment";

	private const string FiunSmall = "Fiun of Enlightenment";

	private static int _mkPartsBefore;

	private static int _mkFiunN;

	public static int MkStopAt;

	private static bool _mkOn;

	private static string _mkStatus = "";

	private static string _mkStep = "";

	private static DateTime _mkSentAt = DateTime.MinValue;

	private static DateTime _mkPeaceAsked = DateTime.MinValue;

	private static DateTime _mkNextAt = DateTime.MinValue;

	private static bool _mkWaiting;

	private static bool _mkGot;

	private static int _mkMisses;

	private static int _mkMade;

	private static readonly Dictionary<string, int> _mkCounts = new Dictionary<string, int>();

	private static int _enlTarget;

	private static int _calcFor = -1;

	private static int _calcLevel;

	private static int _calcTokens;

	private static int _calcMedals;

	private static long _calcLum;

	public const int CoinsPerToken = 20;

	public static bool MkBank = true;

	private static DateTime _bankCmdAt = DateTime.MinValue;

	private static DateTime _bankRecheckAt = DateTime.MinValue;

	private static bool _mkWithdrawing;

	private static int _mkTokBefore;

	private static DateTime _mkWdSent;

	private const double BankCmdGapS = 6.0;

	private const int MaxTokensPerBuy = 100;

	private static long _buyLeft;

	private static long _buyTotal;

	private static long _buyDone;

	private static bool _buyWaiting;

	private static int _buyMisses;

	private static int _buyTokBefore;

	private static int _buyNow;

	private static DateTime _buyNextAt = DateTime.MinValue;

	private static DateTime _buySentAt;

	private static double _lpc = -1.0;

	private static DateTime _lpcAt = DateTime.MinValue;

	private static readonly Regex FrPrimeRx = new Regex("^Your void enchantments prime ", RegexOptions.IgnoreCase);

	private static readonly Regex FrDeathRx = new Regex("^Your primed enchantments release Nether Fracture as ", RegexOptions.IgnoreCase);

	private static DateTime _frDeathAt = DateTime.MinValue;

	private static readonly Regex FrHitRx = new Regex("^Your Nether Fracture strikes (?<who>.+?) for (?<n>[\\d,]+) points", RegexOptions.IgnoreCase);

	private static int _frPrimes;

	private static int _frBursts;

	private static int _frByStreak;

	private static int _frOnDeath;

	private static int _frHits;

	private static int _frNoDmg;

	private static bool _frWaiting;

	private static long _frDmg;

	private static long _frMax;

	private static long _frCur;

	private static DateTime _frLastHit = DateTime.MinValue;

	private static DateTime _frStreakAt = DateTime.MinValue;

	private static double _paceRoom = -1.0;

	private static double _paceMax = 30.0;

	private static double _paceRate = 375.0;

	private static double _paceSlow = 0.5;

	private static DateTime _paceAt = DateTime.MinValue;

	private static int _paceMyTier = -1;

	private static int _paceZoneTier = -1;

	private static double _paceCredit = -1.0;

	private static DateTime _paceChecked = DateTime.MinValue;

	private static DateTime _paceQuietUntil = DateTime.MinValue;

	private static DateTime _paceSent = DateTime.MinValue;

	private static int _paceCheckedTier = -1;

	private static bool _paceSlowNow;

	// the coin hour (patch 11-21, in place of the 11-11 pace): from the first Prestige Coin kill, 60 minutes; the first
	// 375 kills pay full, then each 75 pay half the step before (50%, 25%, 12.5% ...). A kill below your tier uses its
	// share of a kill. One count per character across zones, kept through relogs - read back from /tierdip.
	private const double HourFull = 375.0, HourStep = 75.0;
	private static DateTime _hourStart = DateTime.MinValue;
	private static double _hourKills;
	private static DateTime _hourSynced = DateTime.MinValue;
	private static readonly Regex HourKillsRx = new Regex("([\\d,]+(?:\\.\\d+)?)\\s*(?:/|of)\\s*375\\b|([\\d,]+(?:\\.\\d+)?)\\s+(?:coin[- ]hour\\s+)?kills?\\b(?! of)", RegexOptions.IgnoreCase);
	private static readonly Regex HourLeftRx = new Regex("(\\d+)\\s*(?:m\\b|min)", RegexOptions.IgnoreCase);

	private static readonly Regex PaceMyRx = new Regex("^Your tier:\\s*T(\\d+)", RegexOptions.IgnoreCase);

	private static readonly Regex PaceZoneRx = new Regex("^This zone:\\s*T(\\d+)", RegexOptions.IgnoreCase);

	private static readonly Regex PaceCreditRx = new Regex("^Kills here give you .*?\\((\\d+(?:\\.\\d+)?) pct\\)", RegexOptions.IgnoreCase);

	private static readonly Regex PaceRateRx = new Regex("full rate up to ([\\d,]+) kills an hour.*?pays (\\d+) pct", RegexOptions.IgnoreCase);

	private static readonly Regex PaceRoomRx = new Regex("You can get ([\\d.]+) kills? ahead of that pace.*?\\(the most is ([\\d.]+)\\)", RegexOptions.IgnoreCase);

	private static readonly Regex PaceAnyRx = new Regex("^(Your tier:|This zone:|Kills here give you|Each tier below your own costs|Prestige Coins: full rate|You can get [\\d.]+ kills? ahead|You are [\\d.]+ kills? (past|ahead|over)|.*\\bcoin hour\\b|.*Portal Gem.*\\b(cap|capping|capped)\\b|You have no (Tou Tou )?(Endgame )?Portal Gem|T11 needs no gem)", RegexOptions.IgnoreCase);

	private static readonly int[] RtAll = new int[38]
	{
		32, 34, 43, 33, 31, 54, 16, 14, 15, 6,
		7, 21, 44, 45, 46, 47, 41, 48, 49, 50,
		51, 52, 18, 28, 29, 30, 37, 38, 39, 19,
		20, 23, 27, 35, 36, 22, 24, 40
	};

	private static readonly int[] RtAuto = new int[3] { 22, 24, 40 };

	private static readonly Dictionary<int, string> RtNames = new Dictionary<int, string>
	{
		{ 6, "Melee Defense" },
		{ 7, "Missile Defense" },
		{ 14, "Arcane Lore" },
		{ 15, "Magic Defense" },
		{ 16, "Mana Conversion" },
		{ 18, "Item Tinkering" },
		{ 19, "Assess Person" },
		{ 20, "Deception" },
		{ 21, "Healing" },
		{ 22, "Jump" },
		{ 23, "Lockpick" },
		{ 24, "Run" },
		{ 27, "Assess Creature" },
		{ 28, "Weapon Tinkering" },
		{ 29, "Armor Tinkering" },
		{ 30, "Magic Item Tinkering" },
		{ 31, "Creature Enchantment" },
		{ 32, "Item Enchantment" },
		{ 33, "Life Magic" },
		{ 34, "War Magic" },
		{ 35, "Leadership" },
		{ 36, "Loyalty" },
		{ 37, "Fletching" },
		{ 38, "Alchemy" },
		{ 39, "Cooking" },
		{ 40, "Salvaging" },
		{ 41, "Two Handed Combat" },
		{ 43, "Void Magic" },
		{ 44, "Heavy Weapons" },
		{ 45, "Light Weapons" },
		{ 46, "Finesse Weapons" },
		{ 47, "Missile Weapons" },
		{ 48, "Shield" },
		{ 49, "Dual Wield" },
		{ 50, "Recklessness" },
		{ 51, "Sneak Attack" },
		{ 52, "Dirty Fighting" },
		{ 54, "Summoning" }
	};

	public static List<RtEntry> Rt = RtDefault();

	public static bool RtSpecAtEnd;

	public static bool RtLevelSkills = true;

	private static bool _rtOn;

	private static bool _rtSpec;

	private static int _rtIdx;

	private static int _rtPhase;

	private static int _rtWait;

	private static DateTime _rtAt;

	private static string _rtStatus = "";

	private static string _rtFailed;

	private static readonly List<string> _rtMissing = new List<string>();

	private static readonly List<string> _rtSkipped = new List<string>();

	private static readonly Dictionary<int, string> _rtCost = new Dictionary<int, string>();

	public static int KillCount => Cur.Kills;

	public static double Hours => HoursOf(Cur);

	public static int Kills => Cur.Kills;

	public static long LumEarned => _lumEarned;

	public static long XpEarned
	{
		get
		{
			long num = XpNow();
			return (_xpStart >= 0 && num >= _xpStart) ? (num - _xpStart) : 0;
		}
	}

	public static double LumPerHour
	{
		get
		{
			Rates();
			return _lumPh;
		}
	}

	public static double XpPerHour
	{
		get
		{
			Rates();
			return _xpPh;
		}
	}

	public static double LumPerHourRecent
	{
		get
		{
			Rates();
			return _lumPhR;
		}
	}

	public static double XpPerHourRecent
	{
		get
		{
			Rates();
			return _xpPhR;
		}
	}

	public static double PackAvg => (Packs > 0) ? (PackTotalSecs / (double)Packs) : 0.0;

	private static double _kphEstimate = double.NaN;

	private static DateTime _kphEstimateAt;

	/// <summary>
	/// Kills/hr over the last 60 min for the estimates (bounty and aug time to go, coins/hr, lum/hr): worked out once every
	/// 10 s - live, they rolled down constantly between kills.
	/// </summary>
	public static double KillsPerHourEstimate
	{
		get
		{
			if (double.IsNaN(_kphEstimate) || (DateTime.Now - _kphEstimateAt).TotalSeconds >= 10.0)
			{
				_kphEstimate = KillsPerHourRecent;
				_kphEstimateAt = DateTime.Now;
			}
			return _kphEstimate;
		}
	}

	public static double KillsPerHourRecent
	{
		get
		{
			DateTime now = DateTime.Now;
			DateTime from = now.AddHours(-1.0);
			_recent.RemoveAll((DateTime t) => t < from);
			DateTime dateTime = ((_recentSince > Cur.Since) ? _recentSince : Cur.Since);
			double num = Math.Min(60.0, (now - dateTime).TotalMinutes);
			if (num < 1.0)
			{
				return -1.0;
			}
			return (double)_recent.Count * 60.0 / num;
		}
	}

	private static string AugQuoteFile => Util.FullPath("MelkTank_AugPrices.txt");

	private static Dictionary<string, AugQuote> AugQuotes
	{
		get
		{
			if (_augQuotes != null)
			{
				return _augQuotes;
			}
			Dictionary<string, AugQuote> dictionary = new Dictionary<string, AugQuote>(StringComparer.OrdinalIgnoreCase);
			try
			{
				if (File.Exists(AugQuoteFile))
				{
					string[] array = File.ReadAllLines(AugQuoteFile);
					foreach (string text in array)
					{
						string[] array2 = text.Split('|');
						if (array2.Length == 4 && long.TryParse(array2[1], out var result) && long.TryParse(array2[2], out var result2) && long.TryParse(array2[3], out var result3))
						{
							dictionary[array2[0]] = new AugQuote
							{
								Level = result,
								Levels = result2,
								Lum = result3
							};
						}
					}
				}
			}
			catch
			{
			}
			if (!dictionary.ContainsKey("War"))
			{
				dictionary["War"] = new AugQuote
				{
					Level = 2400L,
					Levels = 10L,
					Lum = 101019000430L
				};
			}
			if (!dictionary.ContainsKey("Void"))
			{
				dictionary["Void"] = new AugQuote
				{
					Level = 2150L,
					Levels = 10L,
					Lum = 111366401659L
				};
			}
			_augQuotes = dictionary;
			return dictionary;
		}
	}

	private static bool AeOn => _ae != Ae.Off;

	private static string BountyFile => Util.FullPath("MelkTank_BountyTiers.txt");

	public static bool LumRateIsBounty
	{
		get
		{
			Rates();
			return _lumIsBounty;
		}
	}

	private static bool RtAfterEnl => Rt.Exists((RtEntry x) => x.Enl);

	private static bool RtBusy => _rtOn;

	private static DateTime NearbyTimerStart(WorldObject o, DateTime fallback)
	{
		DateTime dateTime = DateTime.MaxValue;
		try
		{
			CombatEngine currentEngine = PluginCore.CurrentEngine;
			CoordsObject coordsObject = o.Coordinates();
			if (currentEngine == null || coordsObject == null)
			{
				return fallback;
			}
			foreach (TrackedMonster value in currentEngine.Tracked.Values)
			{
				if (value.EngagedAt == DateTime.MinValue || value.EngagedAt >= dateTime)
				{
					continue;
				}
				CoordsObject coordsObject2 = Globals.Core.WorldFilter[value.Id]?.Coordinates();
				if (coordsObject2 != null)
				{
					double num = (coordsObject2.NorthSouth - coordsObject.NorthSouth) * 240.0;
					double num2 = (coordsObject2.EastWest - coordsObject.EastWest) * 240.0;
					if (num * num + num2 * num2 <= 400.0)
					{
						dateTime = value.EngagedAt;
					}
				}
			}
		}
		catch
		{
		}
		return (dateTime == DateTime.MaxValue || dateTime > DateTime.Now) ? fallback : dateTime;
	}

	public static bool KillLineSince(string name, DateTime since)
	{
		if (string.IsNullOrEmpty(name))
		{
			return false;
		}
		foreach (KillText killText in _killTexts)
		{
			if (killText.At >= since && killText.Text.IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0)
			{
				return true;
			}
		}
		return false;
	}

	private static bool TakeKillText(string name, DateTime around)
	{
		for (int i = 0; i < _killTexts.Count; i++)
		{
			KillText killText = _killTexts[i];
			if (!(Math.Abs((killText.At - around).TotalSeconds) > 5.0) && killText.Text.IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0)
			{
				_killTexts.RemoveAt(i);
				return true;
			}
		}
		return false;
	}

	public static string Category(ObjectClass c)
	{
		switch (c)
		{
		case ObjectClass.Armor:
			return "Armor";
		case ObjectClass.Clothing:
			return "Clothing";
		case ObjectClass.Jewelry:
			return "Jewelry";
		case ObjectClass.MeleeWeapon:
		case ObjectClass.MissileWeapon:
		case ObjectClass.WandStaffOrb:
			return "Weapons";
		default:
			return "Misc";
		}
	}

	public static void NoteLootItem(string rule, string desc, ObjectClass c, string vs = null, int vsColor = 7)
	{
		Looted.Insert(0, new LootRec
		{
			At = DateTime.Now,
			Rule = (rule ?? ""),
			Desc = (desc ?? ""),
			Cat = Category(c),
			Vs = (vs ?? ""),
			VsColor = vsColor
		});
		if (Looted.Count > 500)
		{
			Looted.RemoveAt(Looted.Count - 1);
		}
	}

	public static string SessionJson(string character)
	{
		CultureInfo invariantCulture = CultureInfo.InvariantCulture;
		Stats cur = Cur;
		double num = HoursOf(cur);
		StringBuilder stringBuilder = new StringBuilder("{");
		stringBuilder.Append("\n  \"character\": ").Append(Q(character));
		stringBuilder.Append(",\n  \"updated\": ").Append(Q(DateTime.UtcNow.ToString("o")));
		string s = "";
		try
		{
			CombatEngine currentEngine = PluginCore.CurrentEngine;
			if (currentEngine != null)
			{
				s = currentEngine.Status ?? "";
			}
		}
		catch
		{
		}
		stringBuilder.Append(",\n  \"doing\": ").Append(Q(s));
		stringBuilder.Append(",\n  \"started\": ").Append(Q(cur.Since.ToUniversalTime().ToString("o")));
		stringBuilder.Append(",\n  \"playedSecs\": ").Append(((long)PlayedSecs(cur)).ToString(invariantCulture));
		stringBuilder.Append(",\n  \"kills\": ").Append(cur.Kills);
		stringBuilder.Append(",\n  \"killsPerHour\": ").Append(((long)Math.Round((double)cur.Kills / num)).ToString(invariantCulture));
		int num2 = OutKills(cur);
		if (num2 > 0)
		{
			stringBuilder.Append(",\n  \"killsPerHourTuned\": ").Append(((long)Math.Round((double)(cur.Kills - num2) / TunedHours(cur, num))).ToString(invariantCulture));
		}
		stringBuilder.Append(",\n  \"lumEarned\": ").Append(LumEarned.ToString(invariantCulture));
		stringBuilder.Append(",\n  \"lumPerHour\": ").Append(((long)LumPerHour).ToString(invariantCulture));
		stringBuilder.Append(",\n  \"lumPerHourRecent\": ").Append(((long)LumPerHourRecent).ToString(invariantCulture));
		// (Session > Lum's figures - the app's Lum card)
		try
		{
			stringBuilder.Append(",\n  \"lumTab\": ").Append(LumTrack.Json());
		}
		catch
		{
		}
		stringBuilder.Append(",\n  \"xpEarned\": ").Append(XpEarned.ToString(invariantCulture));
		stringBuilder.Append(",\n  \"xpPerHour\": ").Append(((long)XpPerHour).ToString(invariantCulture));
		stringBuilder.Append(",\n  \"xpPerHourRecent\": ").Append(((long)XpPerHourRecent).ToString(invariantCulture));
		stringBuilder.Append(",\n  \"packs\": ").Append(Packs);
		stringBuilder.Append(",\n  \"packAvg\": ").Append(PackAvg.ToString("0.0", invariantCulture));
		stringBuilder.Append(",\n  \"packFastest\": ").Append(((Packs > 0) ? PackFastest : 0.0).ToString("0.0", invariantCulture));
		stringBuilder.Append(",\n  \"packSlowest\": ").Append(PackSlowest.ToString("0.0", invariantCulture));
		stringBuilder.Append(",\n  \"packLast\": ").Append(PackLast.ToString("0.0", invariantCulture));
		stringBuilder.Append(",\n  \"packKills\": ").Append((Packs > 0) ? ((double)PackKills / (double)Packs).ToString("0.0", invariantCulture) : "0");
		stringBuilder.Append(",\n  \"killsPerHourRecent\": ").Append(((long)Math.Round(KillsPerHourRecent)).ToString(invariantCulture));
		stringBuilder.Append(",\n  \"deaths\": ").Append(cur.Deaths);
		stringBuilder.Append(",\n  \"corpses\": ").Append(cur.Corpses);
		stringBuilder.Append(",\n  \"corpsesKept\": ").Append(cur.CorpsesKept);
		stringBuilder.Append(",\n  \"lootItems\": ").Append(cur.LootItems);
		stringBuilder.Append(",\n  \"lootArmor\": ").Append(cur.LootArmor);
		stringBuilder.Append(",\n  \"lootClothing\": ").Append(cur.LootClothing);
		stringBuilder.Append(",\n  \"lootJewelry\": ").Append(cur.LootJewelry);
		stringBuilder.Append(",\n  \"lootWeapons\": ").Append(cur.LootWeapons);
		stringBuilder.Append(",\n  \"lootMisc\": ").Append(cur.LootMisc);
		try
		{
			NearbyPlayers.AppendJson(stringBuilder, Q);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		try
		{
			PackStats.AppendJson(stringBuilder, Q);
		}
		catch (Exception ex2)
		{
			Util.LogError(ex2);
		}
		stringBuilder.Append(",\n  \"mobs\": [");
		bool flag = true;
		List<MobStat> list = new List<MobStat>(cur.Mobs.Values);
		list.Sort((MobStat x, MobStat y) => y.Kills.CompareTo(x.Kills));
		foreach (MobStat item in list)
		{
			string text = "";
			try
			{
				text = SpeciesNameOf(item);
			}
			catch
			{
			}
			stringBuilder.Append(flag ? "\n    " : ",\n    ");
			flag = false;
			stringBuilder.Append("{\"name\": ").Append(Q(item.Name)).Append(", \"species\": ")
				.Append(Q(text ?? ""))
				.Append(", \"kills\": ")
				.Append(item.Kills)
				.Append(", \"avg\": ")
				.Append(item.Avg.ToString("0.0", invariantCulture))
				.Append(", \"fastest\": ")
				.Append(((item.Fastest == double.MaxValue) ? 0.0 : item.Fastest).ToString("0.0", invariantCulture))
				.Append(", \"slowest\": ")
				.Append(item.Slowest.ToString("0.0", invariantCulture))
				.Append(", \"out\": ")
				.Append(PackStats.IsOut(item.Name) ? "true" : "false")
				.Append('}');
		}
		stringBuilder.Append("\n  ],\n  \"popup\": [");
		flag = true;
		foreach (string item2 in PopupLines())
		{
			stringBuilder.Append(flag ? "\n    " : ",\n    ");
			flag = false;
			stringBuilder.Append(Q(item2));
		}
		stringBuilder.Append("\n  ],\n  \"buffs\": ").Append(BuffJson());
		DateTime dateTime = DateTime.MinValue;
		foreach (BankLine item3 in _bank)
		{
			if (item3.At > dateTime)
			{
				dateTime = item3.At;
			}
		}
		stringBuilder.Append(",\n  \"bank\": {\"at\": ").Append(Q((dateTime == DateTime.MinValue) ? "" : dateTime.ToUniversalTime().ToString("o"))).Append(", \"rows\": [");
		bool flag2 = true;
		foreach (BankLine item4 in BankSorted())
		{
			stringBuilder.Append(flag2 ? "" : ", ").Append('[').Append(Q(item4.Name))
				.Append(", ")
				.Append(Q(item4.Value))
				.Append(']');
			flag2 = false;
		}
		stringBuilder.Append("]},\n  \"augs\": {\"at\": ").Append(Q((_augsAt == DateTime.MinValue) ? "" : _augsAt.ToUniversalTime().ToString("o"))).Append(", \"rows\": [");
		flag2 = true;
		foreach (KeyValuePair<string, string> aug in AugRowsWithHunt())
		{
			stringBuilder.Append(flag2 ? "" : ", ").Append('[').Append(Q(aug.Key))
				.Append(", ")
				.Append(Q(aug.Value))
				.Append(']');
			flag2 = false;
		}
		stringBuilder.Append("]}");
		long value = BankCount("Prestige Coins");
		stringBuilder.Append(",\n  \"charms\": {\"prestigeCoins\": ").Append(value).Append(", \"rows\": [");
		flag2 = true;
		try
		{
			foreach (string[] item5 in Charms.Summary())
			{
				stringBuilder.Append(flag2 ? "" : ", ").Append('[');
				for (int num3 = 0; num3 < item5.Length; num3++)
				{
					stringBuilder.Append((num3 > 0) ? ", " : "").Append(Q(item5[num3]));
				}
				stringBuilder.Append(']');
				flag2 = false;
			}
		}
		catch (Exception ex3)
		{
			Util.LogError(ex3);
		}
		stringBuilder.Append("]}");
		stringBuilder.Append(",\n  \"loot\": [");
		flag = true;
		foreach (LootRec item6 in Looted)
		{
			stringBuilder.Append(flag ? "\n    " : ",\n    ");
			flag = false;
			stringBuilder.Append("{\"time\": ").Append(Q(item6.At.ToUniversalTime().ToString("o"))).Append(", \"rule\": ")
				.Append(Q(item6.Rule))
				.Append(", \"cat\": ")
				.Append(Q(item6.Cat))
				.Append(", \"id\": ")
				.Append(Q(item6.Desc));
			if (item6.Vs.Length > 0)
			{
				stringBuilder.Append(", \"vs\": ").Append(Q(item6.Vs)).Append(", \"vsColor\": ")
					.Append(item6.VsColor);
			}
			stringBuilder.Append('}');
		}
		stringBuilder.Append("\n  ]\n}\n");
		return stringBuilder.ToString();
	}

	private static string BuffJson()
	{
		CultureInfo inv = CultureInfo.InvariantCulture;
		StringBuilder b = new StringBuilder("{");
		try
		{
			MelkTank.Buffs.Buffer bf = PluginCore.CurrentEngine?.Buffer;
			if (bf == null)
			{
				return "{}";
			}
			b.Append("\"enabled\": ").Append(bf.Enabled ? "true" : "false").Append(", \"busy\": ")
				.Append(bf.Busy ? "true" : "false")
				.Append(", \"paused\": ")
				.Append(bf.Paused ? "true" : "false")
				.Append(", \"status\": ")
				.Append(Q(bf.Status ?? ""))
				.Append(", \"rebuffMin\": ")
				.Append(bf.RebuffMinutes)
				.Append(", \"rows\": [");
			bool first = true;
			Action<string, string, double, bool> action = (string name, string kind, double left, bool off) =>
			{
				b.Append(first ? "\n    " : ",\n    ");
				first = false;
				b.Append("{\"n\": ").Append(Q(name)).Append(", \"k\": ")
					.Append(Q(kind))
					.Append(", \"left\": ")
					.Append(Math.Max(0.0, left).ToString("0", inv))
					.Append(", \"rebuffIn\": ")
					.Append((left - bf.RebuffSeconds).ToString("0", inv))
					.Append(", \"off\": ")
					.Append(off ? "true" : "false")
					.Append('}');
			};
			action("Creature Enchantment Mastery", "Creature", MelkTank.Buffs.Buffer.GetSpellRemaining(4530), !bf.MasteryTriggers);
			foreach (SpellGem spellGem in bf.SpellGems)
			{
				bool arg = !bf.SpellGemsEnabled || !spellGem.Enabled;
				if (!spellGem.Learned || spellGem.SpellIds.Count == 0)
				{
					action(spellGem.Name, "Gem (not learned yet)", 0.0, arg);
					continue;
				}
				double num = double.MaxValue;
				foreach (int spellId in spellGem.SpellIds)
				{
					num = Math.Min(num, MelkTank.Buffs.Buffer.GetSpellRemaining(spellId));
				}
				action(spellGem.Name, "Gem", (num == double.MaxValue) ? 0.0 : num, arg);
			}
			b.Append("\n  ]");
		}
		catch
		{
			return "{}";
		}
		return b.Append('}').ToString();
	}

	private static string SpeciesNameOf(MobStat m)
	{
		int num = m.Species;
		if (num <= 0)
		{
			try
			{
				num = GameInfo.SpeciesByName(m.Name);
			}
			catch
			{
			}
			if (num > 0)
			{
				m.Species = num;
			}
		}
		return (num > 0) ? MonsterMatch.SpeciesName(num) : "";
	}

	private static List<string> PopupLines()
	{
		List<string> list = BountyHud.PhoneLines(PluginCore.CurrentSettings);
		for (int i = 0; i < list.Count; i++)
		{
			if (!list[i].StartsWith("B|"))
			{
				continue;
			}
			string[] array = list[i].Split('|');
			if (array.Length >= 4 && array[3].Trim().Length != 0)
			{
				long num = RewardCount(array[3]);
				if (num >= 0)
				{
					list[i] = list[i] + "|" + num.ToString(CultureInfo.InvariantCulture);
				}
			}
		}
		return list;
	}

	private static void NoteBountyLine(string text)
	{
		string text2 = (text ?? "").Replace("\r", "").Trim();
		if (!text2.StartsWith("Bounty", StringComparison.OrdinalIgnoreCase))
		{
			return;
		}
		Match match = BountyLockedRx.Match(text2);
		SeenBounty seenBounty = null;
		if (match.Success)
		{
			TimeSpan zero = TimeSpan.Zero;
			foreach (Match item in SpanPartRx.Matches(match.Groups["time"].Value))
			{
				int num = int.Parse(item.Groups["n"].Value);
				zero += char.ToLowerInvariant(item.Groups["u"].Value[0]) switch
				{
					'm' => TimeSpan.FromMinutes(num), 
					'h' => TimeSpan.FromHours(num), 
					'd' => TimeSpan.FromDays(num), 
					_ => TimeSpan.FromSeconds(num), 
				};
			}
			seenBounty = new SeenBounty
			{
				UnlocksAt = DateTime.Now + zero,
				Need = ParseInt(match.Groups["need"].Value)
			};
		}
		else if ((match = BountyHereRx.Match(text2)).Success)
		{
			seenBounty = new SeenBounty
			{
				Have = ParseInt(match.Groups["have"].Value),
				Need = ParseInt(match.Groups["need"].Value)
			};
		}
		if (seenBounty != null)
		{
			seenBounty.Zone = match.Groups["zone"].Value.Trim();
			seenBounty.Reward = match.Groups["reward"].Value.Trim();
			seenBounty.At = DateTime.Now;
			_bounties[seenBounty.Zone + "|" + seenBounty.Reward] = seenBounty;
		}
	}

	private static int ParseInt(string s)
	{
		int result;
		return int.TryParse((s ?? "").Replace(",", ""), out result) ? result : 0;
	}

	private static List<string> OwnBountyLines()
	{
		List<string> list = new List<string>();
		foreach (SeenBounty value in _bounties.Values)
		{
			if ((DateTime.Now - value.At).TotalMinutes > 3.0)
			{
				continue;
			}
			string text;
			if (value.Zone.Length != 0)
			{
				text = (value.Zone.Equals("all zones", StringComparison.OrdinalIgnoreCase) ? "All zones" : value.Zone);
			}
			else
			{
				text = "This area";
			}
			string text2;
			if (value.UnlocksAt != DateTime.MinValue)
			{
				TimeSpan timeSpan = value.UnlocksAt - DateTime.Now;
				text2 = ((timeSpan <= TimeSpan.Zero) ? "unlocking..." : ("unlocks in " + ((timeSpan.TotalHours >= 1.0) ? ((int)timeSpan.TotalHours + ":" + timeSpan.Minutes.ToString("00") + ":" + timeSpan.Seconds.ToString("00")) : (timeSpan.Minutes + ":" + timeSpan.Seconds.ToString("00")))));
			}
			else
			{
				text2 = value.Have.ToString("N0") + " / " + value.Need.ToString("N0");
				string text3 = BountyEta(text2);
				if (text3.Length > 0)
				{
					text2 = text2 + "  (" + text3 + " to go)";
				}
			}
			string text4 = "B|" + text + "|" + text2 + "|" + value.Reward;
			long num = RewardCount(value.Reward);
			if (num >= 0)
			{
				text4 = text4 + "|" + num.ToString(CultureInfo.InvariantCulture);
			}
			list.Add(text4);
		}
		return list;
	}

	private static string BountyEta(string count)
	{
		Match match = HaveNeedRx.Match(count ?? "");
		if (!match.Success)
		{
			return "";
		}
		int num = Math.Max(0, ParseInt(match.Groups[2].Value) - ParseInt(match.Groups[1].Value));
		if (num == 0)
		{
			return "0:00";
		}
		double killsPerHourRecent = KillsPerHourEstimate;
		if (killsPerHourRecent <= 0.0)
		{
			return "";
		}
		int num2 = (int)Math.Ceiling((double)num / (killsPerHourRecent / 60.0));
		return num2 / 60 + ":" + (num2 % 60).ToString("00");
	}

	private static long RewardCount(string reward)
	{
		string s = Regex.Replace(reward.Trim(), "^[\\d,]+\\s*x?\\s+", "");
		string text = Loose(s);
		if (text.Length == 0)
		{
			return -1L;
		}
		long num = 0L;
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (Loose(item.Name) == text)
				{
					num += Math.Max(1, item.Values(LongValueKey.StackCount, 1));
				}
			}
		}
		catch
		{
			return -1L;
		}
		return num;
	}

	private static string Loose(string s)
	{
		List<string> list = new List<string>();
		string[] array = (s ?? "").ToLowerInvariant().Split(new char[1] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
		foreach (string text in array)
		{
			list.Add((text.Length > 3 && text.EndsWith("s") && !text.EndsWith("ss")) ? text.Substring(0, text.Length - 1) : text);
		}
		return string.Join(" ", list.ToArray());
	}

	private static string Q(string s) => Util.JsonQuote(s);

	/// <summary>/bank, its answer kept out of chat (Session > Lum's coins by the bank).</summary>
	public static void QuietBank()
	{
		QuietNext("/bank");
		Util.Command("/bank");
	}

	public static void Reset()
	{
		LumTrack.Reset();
		_huntGain.Clear();
		_huntSnap.Clear();
		AttackGems.ResetCounts();
		Cur.Clear();
		_recent.Clear();
		ResetPacks();
		try
		{
			PackStats.Reset();
		}
		catch
		{
		}
		FractureReset();
		CoinsReset();
		_lumEarned = 0L;
		_tokGot = 0L;
		_tokBase = -1L;
		_tokHeld = 0L;
		_xpStart = XpNow();
		_samples.Clear();
		_nextSample = DateTime.MinValue;
		_ratesAt = DateTime.MinValue;
		Looted.Clear();
		_gone.Clear();
		_corpses.Clear();
		_killLineAt = DateTime.MinValue;
	}

	public static void ResetAll()
	{
		All.Clear();
		_playedMark = DateTime.Now;
		SaveAll();
	}

	public static void LoggedIn()
	{
		Reset();
		try
		{
			CharacterFilter characterFilter = CoreManager.Current.CharacterFilter;
			string text = characterFilter.Server + "-" + characterFilter.Name;
			char[] invalidFileNameChars = Path.GetInvalidFileNameChars();
			foreach (char oldChar in invalidFileNameChars)
			{
				text = text.Replace(oldChar, '_');
			}
			_file = Util.FullPath("MelkTank_Stats_" + text + ".txt");
			_bankFile = Util.FullPath("MelkTank_Bank_" + text + ".txt");
			_augFile = Util.FullPath("MelkTank_Augs_" + text + ".txt");
			_gemCredits = -1;
			DeedsLoggedIn(text);
			MkStop("logged in");
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			_file = null;
		}
		LoadAll();
		LoadBank();
		LoadAugs();
		LoadCarry();
		_playedMark = DateTime.Now;
		if (_hooked)
		{
			return;
		}
		try
		{
			CoreManager.Current.WorldFilter.CreateObject += OnCreate;
			_hooked = true;
		}
		catch (Exception ex2)
		{
			Util.LogError(ex2);
		}
	}

	public static void LoggedOut()
	{
		SaveAll();
		if (_hooked)
		{
			try
			{
				CoreManager.Current.WorldFilter.CreateObject -= OnCreate;
			}
			catch
			{
			}
			_hooked = false;
		}
	}

	public static void ObjectGone(WorldObject o, TrackedMonster tm)
	{
		try
		{
			if (o == null || tm == null)
			{
				return;
			}
			double num = CombatEngine.Distance(o);
			if (num > 60.0)
			{
				return;
			}
			int species = 0;
			try
			{
				species = GameInfo.Species(o);
			}
			catch
			{
			}
			bool flag = tm.EngagedAt == DateTime.MinValue;
			Gone gone = new Gone
			{
				Name = (tm.Name ?? o.Name),
				Species = species,
				EngagedAt = (flag ? NearbyTimerStart(o, tm.FirstSeen) : tm.EngagedAt),
				At = DateTime.Now,
				Unengaged = flag
			};
			if (flag)
			{
				if (TakeKillText(gone.Name, gone.At) || PetKilled(gone))
				{
					Count(gone);
				}
				else
				{
					_gone.Add(gone);
				}
				return;
			}
			for (int i = 0; i < _corpses.Count; i++)
			{
				if (string.Equals(_corpses[i].Name, gone.Name, StringComparison.OrdinalIgnoreCase))
				{
					_corpses.RemoveAt(i);
					Count(gone);
					return;
				}
			}
			_gone.Add(gone);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void OnCreate(object sender, CreateObjectEventArgs e)
	{
		try
		{
			WorldObject worldObject = e.New;
			if (worldObject == null || worldObject.ObjectClass != ObjectClass.Corpse || worldObject.Name == null || !worldObject.Name.StartsWith("Corpse of "))
			{
				return;
			}
			string text = worldObject.Name.Substring(10).Trim();
			string b = "";
			try
			{
				b = CoreManager.Current.CharacterFilter.Name ?? "";
			}
			catch
			{
			}
			if (string.Equals(text, b, StringComparison.OrdinalIgnoreCase))
			{
				return;
			}
			double num = CombatEngine.Distance(worldObject);
			if (num > 60.0)
			{
				return;
			}
			for (int i = 0; i < _gone.Count; i++)
			{
				if (!_gone[i].Unengaged && string.Equals(_gone[i].Name, text, StringComparison.OrdinalIgnoreCase))
				{
					Gone g = _gone[i];
					_gone.RemoveAt(i);
					Count(g);
					return;
				}
			}
			_corpses.Add(new Corpse
			{
				Name = text,
				At = DateTime.Now
			});
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void OnChat(string text)
	{
		if (string.IsNullOrEmpty(text))
		{
			return;
		}
		try
		{
			GemCreditChat(text);
			LumTrack.OnChat(text);
		}
		catch (Exception ex0)
		{
			Util.LogError(ex0);
		}
		if ((DateTime.Now - _killEventAt).TotalMilliseconds < 400.0)
		{
			_killTexts.Add(new KillText
			{
				Text = text,
				At = DateTime.Now
			});
			try
			{
				PluginCore.CurrentEngine?.NoteKillText(text);
			}
			catch
			{
			}
			if (_killTexts.Count > 50)
			{
				_killTexts.RemoveAt(0);
			}
		}
		if (text.StartsWith("[Pet]", StringComparison.Ordinal))
		{
			Match ph = PetHitRx.Match(text);
			if (ph.Success)
			{
				_petHits[ph.Groups[1].Value.Trim()] = DateTime.Now;
				if (_petHits.Count > 40) { foreach (var k in System.Linq.Enumerable.ToList(System.Linq.Enumerable.Select(System.Linq.Enumerable.Where(_petHits, kv => (DateTime.Now - kv.Value).TotalMinutes > 2), kv => kv.Key))) _petHits.Remove(k); }
			}
		}
		if (text.StartsWith("[BANK]", StringComparison.OrdinalIgnoreCase))
		{
			NoteBank(text);
		}
		NoteDeeds(text);
		NoteBountyLine(text);
		CoinChat(text);
		try
		{
			PaceChat(text);
		}
		catch
		{
		}
		TokenDepositChat(text);
		MkChat(text);
		try
		{
			AttrChat(text);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		AeChat(text);
		FractureChat(text);
		if (DateTime.Now <= _augCaptureUntil || text.IndexOf("Advanced Augmentation Levels", StringComparison.OrdinalIgnoreCase) >= 0 || Regex.IsMatch(text, "^\\s*Creature:\\s*[\\d,]+\\s*$", RegexOptions.Multiline))
		{
			NoteAugs(text);
		}
		AttackGems.OnChat(text);
		if (text.StartsWith("You've banked ", StringComparison.OrdinalIgnoreCase) && text.IndexOf("Luminance", StringComparison.OrdinalIgnoreCase) > 0)
		{
			_killLineAt = DateTime.Now;
			Match match = Regex.Match(text, "banked ([\\d,]+) Luminance", RegexOptions.IgnoreCase);
			if (match.Success && long.TryParse(match.Groups[1].Value.Replace(",", ""), out var result))
			{
				_lumEarned += result;
				_lumBankedLines += result;
			}
		}
	}

	public static void OnServerMessage(Message m)
	{
		try
		{
			if (m.Type == 63408 && m.Value<int>("event") == 429)
			{
				_killLineAt = DateTime.Now;
				_killEventAt = DateTime.Now;
			}
		}
		catch
		{
		}
	}

	public static void NoteDeath()
	{
		Cur.Deaths++;
		All.Deaths++;
		_allDirty = true;
	}

	public static void NoteLoot(ObjectClass c)
	{
		Cur.AddLoot(c);
		All.AddLoot(c);
		_allDirty = true;
	}

	public static void NoteCorpse(bool kept)
	{
		Cur.Corpses++;
		All.Corpses++;
		if (kept)
		{
			Cur.CorpsesKept++;
			All.CorpsesKept++;
		}
		_allDirty = true;
	}

	public static void Tick()
	{
		if (DateTime.Now < _nextTick)
		{
			return;
		}
		_nextTick = DateTime.Now.AddMilliseconds(500.0);
		SampleTick();
		BankFileTick();
		AugFileTick();
		try { AttackGems.Tick(); } catch (Exception ex) { Util.LogError(ex); }
		try { AugVarsTick(); } catch (Exception ex) { Util.LogError(ex); }
		bool ilt = ServerMode.Ilt;
		if (ilt)
		{
			try
			{
				AugsTick();
			}
			catch
			{
			}
		}
		DeedsFileTick();
		if (ilt)
		{
			MkTick();
			try
			{
				LumTrack.Tick();
				EnlBankTick();
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
			try
			{
				AttrTick();
			}
			catch (Exception ex2)
			{
				Util.LogError(ex2);
			}
		}
		try
		{
			PaceTick();
		}
		catch
		{
		}
		if (ilt)
		{
			AeTick();
		}
		RtTick();
		if (ilt)
		{
			try
			{
				Charms.Tick();
			}
			catch (Exception ex3)
			{
				Util.LogError(ex3);
			}
		}
		if (ilt)
		{
			try
			{
				LumTokenTick();
			}
			catch
			{
			}
		}
		try
		{
			BountyHud.KtLines();
		}
		catch
		{
		}
		if (ilt)
		{
			FractureTick();
		}
		try
		{
			NearbyPlayers.Tick();
		}
		catch (Exception ex4)
		{
			Util.LogError(ex4);
		}
		for (int i = 0; i < _gone.Count; i++)
		{
			Gone gone = _gone[i];
			if (gone.Unengaged ? (TakeKillText(gone.Name, gone.At) || PetKilled(gone)) : (Math.Abs((_killLineAt - gone.At).TotalSeconds) <= 5.0))
			{
				_gone.RemoveAt(i--);
				Count(gone);
			}
			else if ((DateTime.Now - gone.At).TotalSeconds > 5.0)
			{
				_gone.RemoveAt(i--);
			}
		}
		_corpses.RemoveAll((Corpse c) => (DateTime.Now - c.At).TotalSeconds > 5.0);
		_killTexts.RemoveAll((KillText k) => (DateTime.Now - k.At).TotalSeconds > 10.0);
		double totalSeconds = (DateTime.Now - _savedAt).TotalSeconds;
		if ((_allDirty && totalSeconds > 60.0) || totalSeconds > 300.0)
		{
			SaveAll();
		}
	}

	private static void Count(Gone g)
	{
		double secs = Math.Max(0.0, (g.At - g.EngagedAt).TotalSeconds);
		Cur.AddKill(g.Name, g.Species, secs);
		try
		{
			BountyProgressKill();
		}
		catch (Exception exb)
		{
			Util.LogError(exb);
		}
		try
		{
			PackStats.Killed(g.Name);
		}
		catch
		{
		}
		try
		{
			CoinKill();
		}
		catch
		{
		}
		try
		{
			AugKill();
		}
		catch
		{
		}
		try
		{
			if (BountyTracker.Current != null)
			{
				BountyTracker.Current.Kill();
			}
		}
		catch
		{
		}
		_recent.Add(DateTime.Now);
		All.AddKill(g.Name, g.Species, secs);
		_allDirty = true;
	}

	private static double PlayedSecs(Stats s)
	{
		return (s == All) ? (All.PlayedSecs + (DateTime.Now - _playedMark).TotalSeconds) : (DateTime.Now - Cur.Since).TotalSeconds;
	}

	private static double HoursOf(Stats s)
	{
		return Math.Max(0.0002777777777777778, PlayedSecs(s) / 3600.0);
	}

	private static void CountTokens(long got, string how)
	{
		if (LumFromBountyProgress)
		{
			// (already counted kill by kill as the bounty filled)
			_tokGot += got;
			return;
		}
		_tokGot += got;
		_lumEarned += (long)((double)got * LumTokenValue);
		Util.WriteToChat("Session: " + got + " Thaelaryn Token" + ((got == 1) ? "" : "s") + " of Luminance " + how + " = +" + Big((double)got * LumTokenValue) + " luminance earned.");
	}

	private static void TokenDepositChat(string text)
	{
		if (!CountLumTokens)
		{
			return;
		}
		Match match = TokDepositRx.Match(text.Trim());
		if (match.Success && long.TryParse(match.Groups["n"].Value.Replace(",", ""), out var result) && result > 0)
		{
			long num = result - _tokHeld;
			if (num > 0)
			{
				CountTokens(num, "deposited (not seen arriving)");
			}
			// (their luminance goes into the bank - counted already as tokens: not counted again by the bank)
			LumTrack.TokensDeposited((double)result * LumTokenValue);
			_tokHeld = Math.Max(0L, _tokHeld - result);
		}
	}

	private static void LumTokenTick()
	{
		if (DateTime.Now < _tokNext)
		{
			return;
		}
		_tokNext = DateTime.Now.AddSeconds(2.0);
		long num = 0L;
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (Loose(item.Name) == "thaelaryn token of luminance")
				{
					num += Math.Max(1, item.Values(LongValueKey.StackCount, 1));
				}
			}
		}
		catch
		{
			return;
		}
		if (_tokBase < 0)
		{
			_tokArmAt = DateTime.Now.AddSeconds(30.0);
		}
		if (DateTime.Now < _tokArmAt)
		{
			_tokHeld = num;
		}
		if (_tokBase >= 0 && num > _tokBase && CountLumTokens && DateTime.Now >= _tokArmAt)
		{
			long num2 = num - _tokBase;
			_tokHeld += num2;
			CountTokens(num2, "received");
		}
		_tokBase = num;
	}

	private static long XpNow()
	{
		try
		{
			return CoreManager.Current.CharacterFilter.TotalXP;
		}
		catch
		{
			return -1L;
		}
	}

	private static void Rates()
	{
		if (!((DateTime.Now - _ratesAt).TotalSeconds < 10.0))
		{
			_ratesAt = DateTime.Now;
			double num = HoursOf(Cur);
			_lumPh = (double)_lumEarned / num;
			_xpPh = (double)XpEarned / num;
			_lumPhR = Recent(lum: true);
			_xpPhR = Recent(lum: false);
			double num2 = BountyLumPerHour();
			_lumIsBounty = num2 > 0.0;
			if (_lumIsBounty)
			{
				_lumPh = num2;
				_lumPhR = num2;
			}
		}
	}

	private static double Recent(bool lum)
	{
		Sample sample = null;
		// lum looks back further (Session > Lum > Settings): a T12 run + the hour waiting in banshees is one cycle,
		// and one 60-minute slice of it reads far too low or far too high
		DateTime dateTime = lum ? DateTime.Now.AddMinutes(-LumTrack.WindowMin) : DateTime.Now.AddHours(-1.0);
		foreach (Sample sample2 in _samples)
		{
			if (sample2.At >= dateTime)
			{
				sample = sample2;
				break;
			}
		}
		if (sample == null || (DateTime.Now - sample.At).TotalMinutes < 5.0)
		{
			return (double)(lum ? _lumEarned : XpEarned) / HoursOf(Cur);
		}
		double totalHours = (DateTime.Now - sample.At).TotalHours;
		return (double)((lum ? _lumEarned : XpEarned) - (lum ? sample.Lum : sample.Xp)) / totalHours;
	}

	private static void SampleTick()
	{
		if (!(DateTime.Now < _nextSample))
		{
			_nextSample = DateTime.Now.AddSeconds(30.0);
			if (_xpStart < 0)
			{
				_xpStart = XpNow();
			}
			_samples.Add(new Sample
			{
				At = DateTime.Now,
				Lum = _lumEarned,
				Xp = XpEarned
			});
			DateTime old = DateTime.Now.AddMinutes(-Math.Max(62.0, LumTrack.WindowMin + 2.0));
			_samples.RemoveAll((Sample x) => x.At < old);
		}
	}

	public static string Big(double v)
	{
		double num = Math.Abs(v);
		if (num >= 1000000000000000.0)
		{
			return (v / 1000000000000000.0).ToString("0.##") + "Q";
		}
		if (num >= 1000000000000.0)
		{
			return (v / 1000000000000.0).ToString("0.##") + "T";
		}
		if (num >= 1000000000.0)
		{
			return (v / 1000000000.0).ToString("0.##") + "B";
		}
		if (num >= 1000000.0)
		{
			return (v / 1000000.0).ToString("0.##") + "M";
		}
		if (num >= 10000.0)
		{
			return (v / 1000.0).ToString("0.#") + "K";
		}
		return v.ToString("N0");
	}

	public static void NoteFight(int mobsInRange)
	{
		DateTime now = DateTime.Now;
		if (mobsInRange > 0)
		{
			if (_inFight && _fightEndAt != DateTime.MinValue)
			{
				FinishFight();
			}
			if (!_inFight)
			{
				_inFight = true;
				_fightStart = now;
				_fightKills0 = Cur.Kills;
				_fightEndAt = DateTime.MinValue;
				try
				{
					PackStats.PackStart();
				}
				catch
				{
				}
			}
			_lastMobsAt = now;
			_fightEndAt = DateTime.MinValue;
		}
		else if (_inFight && !((now - _lastMobsAt).TotalSeconds < 3.0))
		{
			if (_fightEndAt == DateTime.MinValue)
			{
				_fightEndAt = now;
			}
			if (!((now - _fightEndAt).TotalSeconds < 6.0))
			{
				FinishFight();
			}
		}
	}

	private static void FinishFight()
	{
		_inFight = false;
		int num = Cur.Kills - _fightKills0;
		double totalSeconds = (_lastMobsAt - _fightStart).TotalSeconds;
		bool flag = false;
		try
		{
			flag = PackStats.PackEnd(num, Math.Max(0.0, totalSeconds));
		}
		catch
		{
		}
		if (!((num < 3 || totalSeconds <= 0.0) | flag))
		{
			Packs++;
			PackKills += num;
			PackTotalSecs += totalSeconds;
			PackLast = totalSeconds;
			if (totalSeconds < PackFastest)
			{
				PackFastest = totalSeconds;
			}
			if (totalSeconds > PackSlowest)
			{
				PackSlowest = totalSeconds;
			}
		}
	}

	private static void ResetPacks()
	{
		_inFight = false;
		Packs = (PackKills = 0);
		PackTotalSecs = (PackSlowest = (PackLast = 0.0));
		PackFastest = double.MaxValue;
	}

	public static void ResetRecentRate()
	{
		_recent.Clear();
		_recentSince = DateTime.Now;
	}

	private static string N(double v)
	{
		return v.ToString("R", CultureInfo.InvariantCulture);
	}

	private static void SaveAll()
	{
		if (_file == null)
		{
			return;
		}
		try
		{
			All.PlayedSecs += (DateTime.Now - _playedMark).TotalSeconds;
			_playedMark = DateTime.Now;
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append("# MelkTank all-time stats for this character (Session tab > All Time). Reset there.\r\n");
			stringBuilder.Append("P\t").Append(N(All.PlayedSecs)).Append('\t')
				.Append(All.Since.Ticks)
				.Append('\t')
				.Append(All.Kills)
				.Append('\t')
				.Append(All.Deaths)
				.Append('\t')
				.Append(All.LootItems)
				.Append('\t')
				.Append(All.Corpses)
				.Append('\t')
				.Append(All.CorpsesKept)
				.Append('\t')
				.Append(All.LootArmor)
				.Append('\t')
				.Append(All.LootClothing)
				.Append('\t')
				.Append(All.LootJewelry)
				.Append('\t')
				.Append(All.LootWeapons)
				.Append('\t')
				.Append(All.LootMisc)
				.Append("\r\n");
			foreach (MobStat value in All.Mobs.Values)
			{
				stringBuilder.Append("M\t").Append((value.Name ?? "").Replace("\t", " ")).Append('\t')
					.Append(value.Species)
					.Append('\t')
					.Append(value.Kills)
					.Append('\t')
					.Append(N(value.TotalSecs))
					.Append('\t')
					.Append(N((value.Fastest == double.MaxValue) ? 0.0 : value.Fastest))
					.Append('\t')
					.Append(N(value.Slowest))
					.Append("\r\n");
			}
			Util.WriteShared(_file, stringBuilder.ToString());
			_allDirty = false;
			_savedAt = DateTime.Now;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void LoadAll()
	{
		All.Clear();
		_savedAt = DateTime.Now;
		_allDirty = false;
		if (_file == null || !File.Exists(_file))
		{
			return;
		}
		try
		{
			CultureInfo invariantCulture = CultureInfo.InvariantCulture;
			string[] array = Util.Locked(_file, () => File.ReadAllLines(_file));
			string[] array2 = array;
			foreach (string text in array2)
			{
				string[] array3 = text.Split('\t');
				if (array3[0] == "P" && array3.Length >= 13)
				{
					double.TryParse(array3[1], NumberStyles.Float, invariantCulture, out All.PlayedSecs);
					if (long.TryParse(array3[2], out var result) && result > 0)
					{
						All.Since = new DateTime(result);
					}
					int.TryParse(array3[3], out All.Kills);
					int.TryParse(array3[4], out All.Deaths);
					int.TryParse(array3[5], out All.LootItems);
					int.TryParse(array3[6], out All.Corpses);
					int.TryParse(array3[7], out All.CorpsesKept);
					int.TryParse(array3[8], out All.LootArmor);
					int.TryParse(array3[9], out All.LootClothing);
					int.TryParse(array3[10], out All.LootJewelry);
					int.TryParse(array3[11], out All.LootWeapons);
					int.TryParse(array3[12], out All.LootMisc);
				}
				else if (array3[0] == "M" && array3.Length >= 7 && array3[1].Length > 0)
				{
					MobStat mobStat = new MobStat
					{
						Name = array3[1]
					};
					int.TryParse(array3[2], out mobStat.Species);
					int.TryParse(array3[3], out mobStat.Kills);
					double.TryParse(array3[4], NumberStyles.Float, invariantCulture, out mobStat.TotalSecs);
					if (double.TryParse(array3[5], NumberStyles.Float, invariantCulture, out var result2) && result2 > 0.0)
					{
						mobStat.Fastest = result2;
					}
					double.TryParse(array3[6], NumberStyles.Float, invariantCulture, out mobStat.Slowest);
					All.Mobs[mobStat.Name] = mobStat;
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}
}
