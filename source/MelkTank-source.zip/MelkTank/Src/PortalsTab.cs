using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Text.RegularExpressions;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Loot;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public class PortalsTab : IDisposable
{
	private static readonly Vector4 Cyan = new Vector4(0.35f, 0.85f, 0.95f, 1f);

	private static readonly Vector4 Red = new Vector4(0.95f, 0.35f, 0.35f, 1f);

	private static readonly Vector4 Green = new Vector4(0.45f, 0.9f, 0.45f, 1f);

	private static readonly Vector4 Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f);

	private static readonly Vector4 Yellow = new Vector4(0.95f, 0.85f, 0.35f, 1f);

	public static readonly string[] DefaultGems = new string[24]
	{
		"Vaulted Dungeons Recall Gem", "Mellas Court Recall Gem", "Halls of Introduction Gem", "Penthouse Penthouse Recall Gem", "Marketplace Recall Gem", "Thaelaryn Lassel Recall Gem", "Valley of Death Encampment Gem", "Igmo's Retreat Recall Gem", "Zerivax Recall Gem", "Camp Ruggan",
		"Abandoned Mines Portal Sending Gem", "Mhoire Castle Portal Sending Gem", "Tusker King Sending Gem", "Timaru Portal Sending Gem", "Eldrytch Web Stronghold Portal Gem", "Restored Portal Gem", "Wicked Wares Gem", "Infinite Town Network Portal Gem", "Gaerlan's Library Portal Sending Gem", "Enlightened Facility Hub Portal Gem",
		"Town Network Sending Gem", "Hoshino Tent Sending Gem", "Frozen Valley Everlasting Portal Gem", "Portal Recall Gem"
	};

	private static readonly Regex RecallRx = new Regex("recall|sending|^return to |^call of the ", RegexOptions.IgnoreCase);

	private static readonly Regex NotRecallRx = new Regex("\\btie\\b|recall the spirits|^summon ", RegexOptions.IgnoreCase);

	private readonly Settings _s;

	private readonly Action _saveAll;

	private List<KeyValuePair<int, string>> _spells = new List<KeyValuePair<int, string>>();

	private DateTime _spellsAt = DateTime.MinValue;

	private int _pendingSpell;

	private string _pendingName;

	private DateTime _pendingUntil = DateTime.MinValue;


	private readonly Dictionary<string, int> _gemIcon = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

	private Hud _bar;

	private bool _barPushed;

	private bool _barRestored;

	private float[] _barLastPos;

	private DateTime _barDirtySince = DateTime.MinValue;

	private static string BarPosFile => Util.FullPath("MelkTank_PortalBarPos.txt");

	private static void DrawIcon(int icon, float size) => Im.Icon(icon, size);

	public PortalsTab(Settings s, Action saveAll)
	{
		_s = s;
		_saveAll = saveAll;
		try
		{
			_bar = UBService.Huds.CreateHud("MelkTank Portal Gems", BarIcon.Make("Gems"));
			_bar.ShowInBar = false;
			_bar.WindowSettings = ImGuiWindowFlags.NoTitleBar | ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoCollapse | ImGuiWindowFlags.AlwaysAutoResize | ImGuiWindowFlags.NoFocusOnAppearing;
			_bar.OnPreRender += OnBarPreRender;
			_bar.OnRender += OnBarRender;
			_bar.Visible = _s.PortalBarShow;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public void Dispose()
	{
		try
		{
			if (_bar != null)
			{
				_bar.OnPreRender -= OnBarPreRender;
				_bar.OnRender -= OnBarRender;
				_bar.Dispose();
			}
		}
		catch
		{
		}
		_bar = null;
		Im.DisposeIcons();
	}

	private HashSet<string> BarGems()
	{
		HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		string[] array = (_s.PortalBarGems ?? "").Split('|');
		foreach (string text in array)
		{
			if (text.Trim().Length > 0)
			{
				hashSet.Add(text.Trim());
			}
		}
		return hashSet;
	}

	private void SetBarGem(string g, bool on)
	{
		HashSet<string> hashSet = BarGems();
		if (on)
		{
			hashSet.Add(g);
		}
		else
		{
			hashSet.Remove(g);
		}
		List<string> list = new List<string>(hashSet);
		_s.PortalBarGems = string.Join("|", list.ToArray());
	}

	private void OnBarPreRender(object sender, EventArgs e)
	{
		ImGui.SetNextWindowBgAlpha(0.6f);
		ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, new Vector2(3f, 3f));
		ImGui.PushStyleVar(ImGuiStyleVar.ItemSpacing, new Vector2(3f, 3f));
		ImGui.PushStyleVar(ImGuiStyleVar.WindowBorderSize, 0f);
		_barPushed = true;
		if (_barRestored)
		{
			return;
		}
		_barRestored = true;
		try
		{
			if (!File.Exists(BarPosFile))
			{
				ImGui.SetNextWindowPos(new Vector2(60f, 140f), ImGuiCond.Always);
				return;
			}
			string[] array = File.ReadAllText(BarPosFile).Trim().Split('|');
			if (array.Length == 2 && float.TryParse(array[0], NumberStyles.Float, CultureInfo.InvariantCulture, out var result) && float.TryParse(array[1], NumberStyles.Float, CultureInfo.InvariantCulture, out var result2))
			{
				ImGui.SetNextWindowPos(new Vector2(result, result2), ImGuiCond.Always);
			}
		}
		catch
		{
		}
	}

	private void OnBarRender(object sender, EventArgs e)
	{
		try
		{
			WinMem.Frame("Portal gems", size: false);
			if (_barPushed)
			{
				ImGui.PopStyleVar(3);
				_barPushed = false;
			}
			Vector2 windowPos = ImGui.GetWindowPos();
			if (_barLastPos == null || Math.Abs(windowPos.X - _barLastPos[0]) > 0.5f || Math.Abs(windowPos.Y - _barLastPos[1]) > 0.5f)
			{
				_barLastPos = new float[2] { windowPos.X, windowPos.Y };
				_barDirtySince = DateTime.Now;
			}
			if (_barDirtySince != DateTime.MinValue && (DateTime.Now - _barDirtySince).TotalSeconds > 1.5)
			{
				_barDirtySince = DateTime.MinValue;
				try
				{
					File.WriteAllText(BarPosFile, _barLastPos[0].ToString(CultureInfo.InvariantCulture) + "|" + _barLastPos[1].ToString(CultureInfo.InvariantCulture));
				}
				catch
				{
				}
			}
			HashSet<string> on = BarGems();
			List<string> list = GemList().FindAll((string g) => on.Contains(g));
			float num = 32f * Math.Max(0.5f, Math.Min(2f, _s.PortalBarScale));
			if (list.Count == 0)
			{
				Im.TextDisabled("Tick gems on Nav > Portals");
				return;
			}
			int num2 = Math.Max(1, Math.Min(list.Count, _s.PortalBarCols));
			for (int num3 = 0; num3 < list.Count; num3++)
			{
				if (num3 % num2 != 0)
				{
					ImGui.SameLine();
				}
				string text = list[num3];
				WorldObject worldObject = FindInPack(text);
				int value = 0;
				if (worldObject != null)
				{
					try
					{
						value = worldObject.Icon;
					}
					catch
					{
					}
					if (value != 0)
					{
						_gemIcon[text] = value;
					}
				}
				else
				{
					_gemIcon.TryGetValue(text, out value);
				}
				Vector2 cursorScreenPos = ImGui.GetCursorScreenPos();
				DrawIcon(value, num);
				bool flag = ImGui.IsItemHovered();
				if (worldObject == null)
				{
					ImGui.GetWindowDrawList().AddRectFilled(cursorScreenPos, cursorScreenPos + new Vector2(num, num), ImGui.GetColorU32(new Vector4(0f, 0f, 0f, 0.6f)));
				}
				if (flag)
				{
					string text2 = text;
					if (worldObject == null)
					{
						text2 += "\n(not in your pack)";
					}
					else
					{
						int num4 = 0;
						try
						{
							num4 = worldObject.Values(LongValueKey.UsesRemaining);
						}
						catch
						{
						}
						int num5 = ItemInfo.CountInPack(text);
						text2 = text2 + "\n" + ((num5 > 1) ? (num5 + " carried, ") : "") + ((num4 > 0 && num4 < 1000) ? (num4 + " uses left") : "click to use");
					}
					Im.SetTooltip(text2);
					ImGui.GetWindowDrawList().AddRect(cursorScreenPos, cursorScreenPos + new Vector2(num, num), ImGui.GetColorU32(new Vector4(0.35f, 0.85f, 0.95f, 1f)));
				}
				if (flag && ImGui.IsMouseClicked(ImGuiMouseButton.Left) && worldObject != null)
				{
					Use(worldObject);
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public void Draw()
	{
		CastPendingSpell();
		bool flag = false;
		float num = ImGui.GetFrameHeight() * 1.5f;
		Vector2 size = new Vector2(66f, num);
		float x = (ImGui.GetContentRegionAvail().X - ImGui.GetStyle().ItemSpacing.X) * 0.42f;
		if (ImGui.BeginChild("recalls", new Vector2(x, 0f), border: true))
		{
			Im.TextColored(Cyan, "Recall spells you know");
			Im.TextColored(Grey, "Cast needs a wand wielded (magic mode is switched on for you).");
			RefreshSpells();
			if (_spells.Count == 0)
			{
				Im.TextDisabled("None found.");
			}
			if (ImGui.BeginTable("recalltbl", 3, ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
			{
				ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, num);
				ImGui.TableSetupColumn("Spell", ImGuiTableColumnFlags.WidthStretch);
				ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, size.X);
				foreach (KeyValuePair<int, string> spell in _spells)
				{
					ImGui.TableNextRow(ImGuiTableRowFlags.None, num);
					ImGui.TableSetColumnIndex(0);
					DrawIcon(SpellNames.Icon(spell.Key), num);
					ImGui.TableSetColumnIndex(1);
					CenterText(num);
					Im.TextColored((_pendingSpell == spell.Key) ? Yellow : Vector4.One, spell.Value);
					ImGui.TableSetColumnIndex(2);
					if (ImGui.Button("Cast##rc" + spell.Key, size))
					{
						Cast(spell.Key, spell.Value);
					}
				}
				ImGui.EndTable();
			}
		}
		ImGui.EndChild();
		ImGui.SameLine();
		if (ImGui.BeginChild("gems", new Vector2(0f, 0f), border: true))
		{
			List<string> list = GemList();
			Im.TextColored(Cyan, "Portal gems");
			ImGui.SameLine();
			if (ImGui.SmallButton("Add selected##gem"))
			{
				WorldObject sel = null;
				try
				{
					sel = Globals.Core.WorldFilter[Globals.Core.Actions.CurrentSelection];
				}
				catch
				{
				}
				if (sel == null)
				{
					Util.WriteToChat("Select a portal gem first.");
				}
				else if (list.Exists((string g) => string.Equals(g, sel.Name, StringComparison.OrdinalIgnoreCase)))
				{
					Util.WriteToChat(sel.Name + " is already on the list.");
				}
				else
				{
					list.Add(sel.Name);
					SaveGems(list);
					flag = true;
					Util.WriteToChat("Added " + sel.Name + " to the portal gems.");
				}
			}
			Tip("Select a gem (in your pack or anywhere) and click to add it to the list.");
			bool flag2 = _bar != null && _bar.Visible;
			if (ImGui.Button((flag2 ? "Hide" : "Show") + " gem pop-up##gempop"))
			{
				_s.PortalBarShow = !flag2;
				if (_bar != null)
				{
					_bar.Visible = _s.PortalBarShow;
				}
				flag = true;
			}
			Tip("A small window with the ticked gems as icons - click one to use it. Drag it anywhere.");
			ImGui.SameLine(0f, 16f);
			ImGui.SetNextItemWidth(110f);
			float v = _s.PortalBarScale;
			if (ImGui.SliderFloat("Scale##gemsc", ref v, 0.5f, 2f, "%.2fx"))
			{
				_s.PortalBarScale = v;
			}
			if (ImGui.IsItemDeactivatedAfterEdit())
			{
				flag = true;
			}
			ImGui.SameLine(0f, 16f);
			ImGui.SetNextItemWidth(80f);
			int v2 = _s.PortalBarCols;
			if (ImGui.InputInt("Columns##gemcols", ref v2))
			{
				_s.PortalBarCols = Math.Max(1, Math.Min(30, v2));
				flag = true;
			}
			Tip("How many icons across - more gems than that start a new row.");
			int num2 = -1;
			int num3 = -1;
			int num4 = -1;
			HashSet<string> hashSet = BarGems();
			if (ImGui.BeginTable("gemtbl", 8, ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
			{
				ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, ImGui.GetFrameHeight());
				ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, num);
				ImGui.TableSetupColumn("Gem", ImGuiTableColumnFlags.WidthStretch);
				ImGui.TableSetupColumn("Have", ImGuiTableColumnFlags.WidthFixed, 110f);
				ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, size.X);
				ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 22f);
				ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 22f);
				ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 22f);
				for (int num5 = 0; num5 < list.Count; num5++)
				{
					string text = list[num5];
					WorldObject worldObject = FindInPack(text);
					ImGui.TableNextRow(ImGuiTableRowFlags.None, num);
					ImGui.PushID("gem" + num5);
					ImGui.TableSetColumnIndex(0);
					CenterText(num, ImGui.GetFrameHeight());
					bool v3 = hashSet.Contains(text);
					if (ImGui.Checkbox("##gbar", ref v3))
					{
						SetBarGem(text, v3);
						flag = true;
					}
					if (ImGui.IsItemHovered())
					{
						Im.SetTooltip("Show this gem on the pop-up");
					}
					ImGui.TableSetColumnIndex(1);
					int value = 0;
					if (worldObject != null)
					{
						try
						{
							value = worldObject.Icon;
						}
						catch
						{
						}
						if (value != 0)
						{
							_gemIcon[text] = value;
						}
					}
					else
					{
						_gemIcon.TryGetValue(text, out value);
					}
					DrawIcon(value, num);
					ImGui.TableSetColumnIndex(2);
					CenterText(num);
					Im.TextColored((worldObject != null) ? Vector4.One : Grey, text);
					ImGui.TableSetColumnIndex(3);
					CenterText(num);
					if (worldObject == null)
					{
						Im.TextColored(Red, "not in pack");
					}
					else
					{
						int num6 = 0;
						try
						{
							num6 = worldObject.Values(LongValueKey.UsesRemaining);
						}
						catch
						{
						}
						int num7 = ItemInfo.CountInPack(text);
						Im.TextColored(Green, ((num7 > 1) ? (num7 + " - ") : "") + ((num6 > 0 && num6 < 1000) ? (num6 + " uses left") : "ready"));
					}
					ImGui.TableSetColumnIndex(4);
					if (worldObject != null && ImGui.Button("Use", size))
					{
						Use(worldObject);
					}
					ImGui.TableSetColumnIndex(5);
					CenterText(num, ImGui.GetFrameHeight());
					if (num5 > 0 && Im.UpButton("##gup"))
					{
						num3 = num5;
					}
					ImGui.TableSetColumnIndex(6);
					CenterText(num, ImGui.GetFrameHeight());
					if (num5 < list.Count - 1 && Im.DownButton("##gdn"))
					{
						num4 = num5;
					}
					ImGui.TableSetColumnIndex(7);
					CenterText(num, ImGui.GetFrameHeight());
					if (ImGui.SmallButton("X"))
					{
						num2 = num5;
					}
					ImGui.PopID();
				}
				ImGui.EndTable();
			}
			if (num3 > 0)
			{
				Im.Move(list, num3, up: true);
				SaveGems(list);
				flag = true;
			}
			if (num4 >= 0 && num4 < list.Count - 1)
			{
				Im.Move(list, num4, up: false);
				SaveGems(list);
				flag = true;
			}
			if (num2 >= 0)
			{
				list.RemoveAt(num2);
				SaveGems(list);
				flag = true;
			}
		}
		ImGui.EndChild();
		if (flag)
		{
			_saveAll();
		}
	}

	private List<string> GemList()
	{
		List<string> list = new List<string>();
		string[] array = (_s.PortalGems ?? "").Split('|');
		foreach (string text in array)
		{
			if (text.Trim().Length > 0)
			{
				list.Add(text.Trim());
			}
		}
		return list;
	}

	private void SaveGems(List<string> l)
	{
		_s.PortalGems = string.Join("|", l.ToArray());
	}

	private static WorldObject FindInPack(string name)
	{
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
				{
					return item;
				}
			}
		}
		catch
		{
		}
		return null;
	}

	private static void Use(WorldObject o)
	{
		try
		{
			Globals.Core.Actions.UseItem(o.Id, 0);
			Util.WriteToChat("Using " + o.Name + ".");
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void RefreshSpells()
	{
		if ((DateTime.Now - _spellsAt).TotalSeconds < 30.0)
		{
			return;
		}
		_spellsAt = DateTime.Now;
		List<KeyValuePair<int, string>> list = new List<KeyValuePair<int, string>>();
		foreach (int item in KnownSpellIds())
		{
			string n = SpellNames.Name(item);
			if (!string.IsNullOrEmpty(n) && (PortalSpellIds.All.Contains(item) || (RecallRx.IsMatch(n) && !NotRecallRx.IsMatch(n))) && !list.Exists((KeyValuePair<int, string> x) => x.Value == n))
			{
				list.Add(new KeyValuePair<int, string>(item, n));
			}
		}
		list.Sort((KeyValuePair<int, string> a, KeyValuePair<int, string> b) => string.Compare(a.Value, b.Value, StringComparison.OrdinalIgnoreCase));
		_spells = list;
	}

	public static List<KeyValuePair<int, string>> RecallSpells()
	{
		List<KeyValuePair<int, string>> list = new List<KeyValuePair<int, string>>();
		foreach (int item in KnownSpellIds())
		{
			string n = SpellNames.Name(item);
			if (!string.IsNullOrEmpty(n) && (PortalSpellIds.All.Contains(item) || (RecallRx.IsMatch(n) && !NotRecallRx.IsMatch(n))) && !list.Exists((KeyValuePair<int, string> x) => x.Value == n))
			{
				list.Add(new KeyValuePair<int, string>(item, n));
			}
		}
		list.Sort((KeyValuePair<int, string> a, KeyValuePair<int, string> b) => string.Compare(a.Value, b.Value, StringComparison.OrdinalIgnoreCase));
		return list;
	}

	public static List<string> CarriedGems(Settings s)
	{
		List<string> list = new List<string>();
		string[] array = (s?.PortalGems ?? "").Split('|');
		foreach (string text in array)
		{
			if (text.Trim().Length > 0)
			{
				list.Add(text.Trim());
			}
		}
		List<string> list2 = new List<string>();
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				string n = item.Name ?? "";
				if ((list.Exists((string k) => string.Equals(k, n, StringComparison.OrdinalIgnoreCase)) || (n.IndexOf("Gem", StringComparison.OrdinalIgnoreCase) >= 0 && (RecallRx.IsMatch(n) || n.IndexOf("Portal", StringComparison.OrdinalIgnoreCase) >= 0))) && !list2.Exists((string x) => string.Equals(x, n, StringComparison.OrdinalIgnoreCase)))
				{
					list2.Add(n);
				}
			}
		}
		catch
		{
		}
		list2.Sort(StringComparer.OrdinalIgnoreCase);
		return list2;
	}

	private static bool InMagicMode()
	{
		try
		{
			return Globals.Core.Actions.CombatMode == CombatState.Magic;
		}
		catch
		{
			return false;
		}
	}

	private void Cast(int id, string name)
	{
		if (InMagicMode())
		{
			DoCast(id, name);
			return;
		}
		try
		{
			Globals.Core.Actions.SetCombatMode(CombatState.Magic);
		}
		catch
		{
		}
		_pendingSpell = id;
		_pendingName = name;
		_pendingUntil = DateTime.Now.AddSeconds(4.0);
	}

	private void CastPendingSpell()
	{
		if (_pendingSpell != 0)
		{
			if (InMagicMode())
			{
				int pendingSpell = _pendingSpell;
				_pendingSpell = 0;
				DoCast(pendingSpell, _pendingName);
			}
			else if (DateTime.Now > _pendingUntil)
			{
				_pendingSpell = 0;
				Util.WriteToChat("Couldn't cast " + _pendingName + " - wield a wand first (magic mode didn't come on).");
			}
		}
	}

	private static void DoCast(int id, string name)
	{
		try
		{
			Globals.Core.Actions.CastSpell(id, Globals.Core.CharacterFilter.Id);
			Util.WriteToChat("Casting " + name + ".");
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static List<int> KnownSpellIds()
	{
		List<int> list = new List<int>();
		try
		{
			if (Util.TryGetProperty(Globals.Core.CharacterFilter, "SpellBook") is IEnumerable enumerable)
			{
				foreach (object item in enumerable)
				{
					if (item is int)
					{
						list.Add((int)item);
						continue;
					}
					object obj = Util.TryGetProperty(item, "Id") ?? Util.TryGetProperty(item, "SpellId") ?? Util.TryGetProperty(item, "Key");
					if (obj is int)
					{
						list.Add((int)obj);
					}
				}
			}
		}
		catch
		{
		}
		return list;
	}

	private static void CenterText(float rowH, float itemH = 0f)
	{
		if (itemH <= 0f)
		{
			itemH = ImGui.GetTextLineHeight();
		}
		float num = (rowH - itemH) * 0.5f;
		if (num > 0f)
		{
			ImGui.SetCursorPosY(ImGui.GetCursorPosY() + num);
		}
	}

	private static void Tip(string text)
	{
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip(text);
		}
	}
}
