using System;
using System.Collections.Generic;
using System.Numerics;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;

namespace MelkTank;

/// <summary>Items > Vendor: a vendor visit by hand (or a dry run), the last visit's summary, the money settings (trade
/// notes, or /b d on Infinite Leaftide) and the vendor profiles.</summary>
public static class VendorTab
{
	private static readonly Vector4 Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f);

	private static readonly Vector4 Cyan = new Vector4(0.4f, 0.85f, 1f, 1f);

	private static readonly Vector4 Green = new Vector4(0.45f, 1f, 0.45f, 1f);

	private static readonly Vector4 Yellow = new Vector4(1f, 0.85f, 0.3f, 1f);

	private static readonly Vector4 Red = new Vector4(1f, 0.4f, 0.4f, 1f);

	private static readonly int[] NoteSizes = new int[10] { 100, 500, 1000, 5000, 10000, 50000, 100000, 150000, 200000, 250000 };

	private static string _newName = "";

	private static int _newScope;

	private static List<string> _files;

	private static DateTime _filesAt;

	private static string _deleteAsk = "";

	private static DateTime _deleteAskAt;

	private static void Tip(string s)
	{
		Im.SetTooltipIfHovered(s);
	}

	public static bool Draw(Settings s, CombatEngine engine, Action<string> editProfile)
	{
		bool flag = false;
		VendorRun vendor = engine.Vendor;
		bool ilt = ServerMode.Ilt;
		Im.TextColored(Grey, ilt ? "Infinite Leaftide: no trade notes - after a visit the pyreals you carry go to the bank with /b d." : "This server: pyreals are managed with trade notes - cashed to pay, bought back to bank the change.");
		// ── a visit by hand ──
		ImGui.SetNextItemWidth(240f);
		ImGui.InputText("##vnpc", ref s.VendorNpc, 120u);
		Tip("The vendor's exact name (the nearest one with that name is used).");
		ImGui.SameLine();
		if (ImGui.SmallButton("sel##vsel"))
		{
			try
			{
				WorldObject worldObject = CoreManager.Current.WorldFilter[CoreManager.Current.Actions.CurrentSelection];
				if (worldObject != null)
				{
					s.VendorNpc = worldObject.Name;
					flag = true;
				}
			}
			catch
			{
			}
		}
		Tip("Use the NPC you have selected.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(200f);
		if (ImGui.BeginCombo("##vprof", (s.VendorProfile.Length > 0) ? s.VendorProfile : "(named after the vendor)"))
		{
			if (ImGui.Selectable("(named after the vendor)", s.VendorProfile.Length == 0))
			{
				s.VendorProfile = "";
				flag = true;
			}
			foreach (string item in vendor.ProfileNames())
			{
				if (ImGui.Selectable(item, item == s.VendorProfile))
				{
					s.VendorProfile = item;
					flag = true;
				}
			}
			ImGui.EndCombo();
		}
		Tip("Which vendor profile to use. \"Named after the vendor\": the profile called after the NPC - this character's first,\nthen this server's, then everyone's.");
		if (vendor.Busy)
		{
			if (ImGui.Button("Stop##vstop", new Vector2(110f, 0f)))
			{
				vendor.Abort("stopped by hand");
			}
			Tip("Stops the visit.\n/mt vendor stop");
			ImGui.SameLine();
			Im.TextColored(Yellow, vendor.Status);
		}
		else
		{
			if (ImGui.Button("Visit now##vgo", new Vector2(110f, 0f)))
			{
				vendor.Start(s.VendorNpc, s.VendorProfile, dry: false);
			}
			Tip("Opens the shop and does the whole visit: sells, " + (ilt ? "buys, then deposits pyreals with /b d." : "cashes notes if needed, buys, then banks the change into notes.") + "\nThe NPC has to be near enough to use. Runs with MelkTank off too.\n/mt vendor <NPC> [/ profile]");
			ImGui.SameLine();
			if (ImGui.Button("Dry run##vdry", new Vector2(110f, 0f)))
			{
				vendor.Start(s.VendorNpc, s.VendorProfile, dry: true);
			}
			Tip("Opens the shop and says what the visit would sell, cash, buy and bank - without trading anything.\nGood for setting up a new profile.\n/mt vendor dry <NPC> [/ profile]");
		}
		if (VendorRun.LastSummary.Length > 0)
		{
			Vector4 col = ((VendorRun.Last == VendorRun.Result.Success) ? Green : ((VendorRun.Last == VendorRun.Result.Partial) ? Yellow : Red));
			Im.TextColored(col, "Last visit (" + VendorRun.ResultWord(VendorRun.Last) + ", " + VendorRun.LastAt.ToString("HH:mm") + "):");
			ImGui.SameLine();
			ImGui.PushTextWrapPos(0f);
			ImGui.TextUnformatted(VendorRun.LastSummary);
			ImGui.PopTextWrapPos();
			if (VendorRun.LastProfile.Length > 0)
			{
				Im.TextColored(Grey, "Profile used: " + VendorRun.LastProfile);
			}
		}
		flag |= ImGui.Checkbox("Auto-vendor when a shop opens##vauto", ref s.VendorAutoOnOpen);
		Tip("When any shop opens - you talking to a vendor, a route or a meta using one - and there's a vendor profile named\nafter that vendor, the whole visit runs by itself (like UtilityBelt's AutoVendor, without VTank).\nOnly when the shop opens, not again while it stays open.\n/mt vendor auto on|off  -  /mt set VendorAutoOnOpen on|off");
		ImGui.SameLine();
		flag |= ImGui.Checkbox("Dry run every visit##vdryall", ref s.VendorDryRun);
		Tip("Every visit - route steps and metas too - only reports what it would do. Turn it off to trade.\n/mt vendor dryrun on|off  -  /mt set VendorDryRun on|off");
		flag |= ImGui.Checkbox("Say the buy list in chat##vsaylist", ref s.VendorSayBuyList);
		Tip("When a visit puts things on the vendor's buy list, chat says what and what it costs.\n/mt set VendorSayBuyList on|off");
		ImGui.SameLine();
		flag |= ImGui.Checkbox("Say what was bought in chat##vsaybought", ref s.VendorSayBought);
		Tip("When the buying's done, chat says what came and what it cost.\n/mt set VendorSayBought on|off");
		flag |= ImGui.Checkbox("Sell anything over the Keep-up-to count##vsellover", ref s.VendorSellOverKeep);
		Tip("Keep-up-to rules both ways: under the count, it's bought up to it; over it, the extra is sold down to it\n(whole stacks first, then the rest split off a stack). A Keep rule still protects what it matches.\n/mt set VendorSellOverKeep on|off");
		ImGui.Separator();
		// ── money ──
		Im.TextColored(Cyan, "Money");
		if (ilt)
		{
			flag |= ImGui.Checkbox("Deposit pyreals with /b d after a visit##vdep", ref s.VendorIltDeposit);
			Tip("When a visit is done, the pyreals you carry are put in the bank (/b d).\n/mt set VendorIltDeposit on|off");
		}
		else
		{
			Im.TextColored(Grey, "Carrying " + VendorRun.Money(VendorRun.Coins()) + " pyreals and " + VendorRun.Money(VendorRun.NotesValue()) + " in trade notes.");
			flag |= ImGui.Checkbox("Pay with trade notes when pyreals run short##vpay", ref s.VendorPayWithNotes);
			Tip("Before buying, if your pyreals don't cover it, just enough trade notes are sold to the vendor to make it up -\nthe smallest notes first (a stack is split so only what's needed goes).\n/mt vendor notes on|off  -  /mt set VendorPayWithNotes on|off");
			flag |= ImGui.Checkbox("Bank the change into notes##vbank", ref s.VendorBankChange);
			Tip("After the visit, with more pyreals than the amount below, trade notes are bought to bring them back down to\nthe pyreals to keep. Vendors sell notes at 115% of their value, so banking costs 15% of what's banked.\n/mt vendor bank on|off  -  /mt set VendorBankChange on|off");
			ImGui.SetNextItemWidth(140f);
			flag |= ImGui.InputInt("Pyreals to keep on hand##vkeep", ref s.VendorKeepLoose, 10000, 100000);
			Tip("Banking the change leaves you this many loose pyreals.\n/mt set VendorKeepLoose <number>");
			ImGui.SetNextItemWidth(140f);
			flag |= ImGui.InputInt("Bank into notes above##vabove", ref s.VendorBankAbove, 10000, 100000);
			Tip("The change is only banked when you carry more pyreals than this.\n/mt set VendorBankAbove <number>");
			ImGui.SetNextItemWidth(140f);
			if (ImGui.BeginCombo("Note size to buy##vsize", s.VendorNoteSize.ToString("N0")))
			{
				int[] noteSizes = NoteSizes;
				foreach (int num in noteSizes)
				{
					if (ImGui.Selectable(num.ToString("N0"), num == s.VendorNoteSize))
					{
						s.VendorNoteSize = num;
						flag = true;
					}
				}
				ImGui.EndCombo();
			}
			Tip("The trade notes bought when banking the change (the vendor has to sell that size).\n/mt set VendorNoteSize <number>");
			ImGui.SetNextItemWidth(140f);
			flag |= ImGui.InputInt("Money floor##vfloor", ref s.VendorFloor, 10000, 100000);
			Tip("A visit never takes your pyreals plus notes below this (0: no floor).\n/mt set VendorFloor <number>");
		}
		ImGui.SetNextItemWidth(140f);
		flag |= ImGui.InputInt("Trade notes cashed at a time##vnotesper", ref s.VendorNotesPerSale, 1, 5);
		Tip("When notes pay for the buying, a visit sells this many at a time, buys what that covers, and goes again until the list is done\n(a server turns down one big sale of notes, and their pyreals fill the packs - 25,000 to a stack).\nFewer if your packs haven't the room.\n/mt set VendorNotesPerSale <number>");
		ImGui.SetNextItemWidth(140f);
		flag |= ImGui.InputInt("Most to spend per visit##vmax", ref s.VendorMaxSpend, 10000, 100000);
		Tip("A visit buys no more than this (0: no limit). What doesn't fit is left off - the summary says so.\n/mt set VendorMaxSpend <number>");
		if (s.VendorKeepLoose < 0)
		{
			s.VendorKeepLoose = 0;
		}
		if (s.VendorBankAbove < 0)
		{
			s.VendorBankAbove = 0;
		}
		if (s.VendorFloor < 0)
		{
			s.VendorFloor = 0;
		}
		if (s.VendorMaxSpend < 0)
		{
			s.VendorMaxSpend = 0;
		}
		if (s.VendorNotesPerSale < 1)
		{
			s.VendorNotesPerSale = 1;
		}
		ImGui.Separator();
		// ── profiles ──
		Im.TextColored(Cyan, "Vendor profiles");
		Im.TextColored(Grey, "Ordinary loot-editor rule lists: Keep up to N = buy until you carry N.  Sell = sell what matches.\nKeep = never sell what matches (even when a Sell rule matches too). Other actions are ignored.");
		if (_files == null || (DateTime.Now - _filesAt).TotalSeconds > 5.0)
		{
			_files = VendorRun.ListVendorProfiles(engine.Looter.ProfileDir);
			_filesAt = DateTime.Now;
		}
		if (_files.Count == 0)
		{
			Im.TextColored(Grey, "   (none yet - make one below)");
		}
		string[] scopes = new string[3] { "this character", "this server", "everyone" };
		foreach (string file in _files.ToArray())
		{
			if (ImGui.SmallButton("Edit##ve" + file))
			{
				editProfile(file);
			}
			Tip("Opens it in the loot editor.");
			ImGui.SameLine();
			// who it's for: changed here, it's moved to that folder
			int scope = VendorRun.ScopeOf(file);
			ImGui.SetNextItemWidth(120f);
			if (ImGui.Combo("##vsc" + file, ref scope, scopes, 3))
			{
				try
				{
					string moved = vendor.MoveProfile(file, scope);
					if (moved == null) Util.WriteToChat("Vendor: there's already a profile called " + System.IO.Path.GetFileNameWithoutExtension(file) + " for " + scopes[scope] + " - not moved.");
					else if (moved != file) Util.WriteToChat("Vendor: " + System.IO.Path.GetFileNameWithoutExtension(file) + " is now for " + scopes[scope] + ".");
				}
				catch (Exception ex)
				{
					Util.WriteToChat("Vendor: couldn't move the profile: " + ex.Message);
				}
				_files = null;
			}
			Tip("Who it's for. \"This character\" / \"this server\" mean the one you're on now: changing it moves the profile\n(a profile of another character's moved to \"this character\" becomes yours).");
			ImGui.SameLine();
			bool asking = _deleteAsk == file && (DateTime.Now - _deleteAskAt).TotalSeconds < 4.0;
			if (ImGui.SmallButton((asking ? "Sure?" : "Delete") + "##vdel" + file))
			{
				if (!asking)
				{
					_deleteAsk = file;
					_deleteAskAt = DateTime.Now;
				}
				else
				{
					try
					{
						vendor.DeleteProfile(file);
						Util.WriteToChat("Vendor: " + System.IO.Path.GetFileNameWithoutExtension(file) + " deleted (kept in Vendor/_deleted, if you want it back).");
					}
					catch (Exception ex2)
					{
						Util.WriteToChat("Vendor: couldn't delete the profile: " + ex2.Message);
					}
					_deleteAsk = "";
					_files = null;
				}
			}
			Tip("Deletes the profile - click again within 4 s to be sure. (It's moved to Vendor/_deleted, dated, so it can be got back.)");
			ImGui.SameLine();
			ImGui.TextUnformatted(file.Replace('\\', '/'));
			if (_files == null) break;
		}
		ImGui.SetNextItemWidth(200f);
		ImGui.InputText("##vnew", ref _newName, 80u);
		Tip("The new profile's name - name it after the vendor (its exact name) and route steps that don't name a profile pick it up.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(150f);
		ImGui.Combo("##vscope", ref _newScope, new string[3] { "this character", "this server", "everyone" }, 3);
		Tip("Who it's for: this character's profiles are looked at first, then this server's, then everyone's.");
		ImGui.SameLine();
		if (ImGui.Button("New profile##vnewbtn") && _newName.Trim().Length > 0)
		{
			try
			{
				string obj = vendor.NewProfile(_newName.Trim(), _newScope);
				_files = null;
				_newName = "";
				editProfile(obj);
			}
			catch (Exception ex)
			{
				Util.WriteToChat("Vendor: couldn't make the profile: " + ex.Message);
			}
		}
		Tip("Makes an empty profile and opens it in the loot editor.");
		if (ImGui.SmallButton("From the selected NPC##vnewsel"))
		{
			try
			{
				WorldObject worldObject2 = CoreManager.Current.WorldFilter[CoreManager.Current.Actions.CurrentSelection];
				if (worldObject2 != null)
				{
					_newName = worldObject2.Name;
				}
			}
			catch
			{
			}
		}
		Tip("Names the new profile after the NPC you have selected.");
		return flag;
	}
}
