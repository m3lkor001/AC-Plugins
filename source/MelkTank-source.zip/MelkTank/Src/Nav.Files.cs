using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
#if !RETAIL
using ACGodot.DecalShim;
using ACGodot.Plugins;
using ACGodot.UI;
#endif
#if !RETAIL
using AcClient;
#else
using SmartBox = AcClient.SmartBox;
using ACCmdInterp = AcClient.ACCmdInterp;
using CommandInterpreter = AcClient.CommandInterpreter;
using CommandListElement = AcClient.CommandListElement;
using CPhysicsObj = AcClient.CPhysicsObj;
using Position = AcClient.Position;
using CTransition = AcClient.CTransition;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
#if !RETAIL
using Godot;
#endif
using ImGuiNET;
using MelkTank.Loot;
using MelkTank.Metas;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public partial class Nav
{
	public NavRoute ImportNav(string path)
	{
		string[] lines;
		try
		{
			lines = File.ReadAllLines(path);
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Nav: can't read " + path + ": " + ex.Message);
			return null;
		}
		int i = 0;
		Func<string> next = () => (i < lines.Length) ? lines[i++].Trim() : null;
		Func<double> func = () =>
		{
			string s = next();
			double result5;
			return double.TryParse(s, NumberStyles.Float, Inv, out result5) ? result5 : 0.0;
		};
		if (!(next() ?? "").StartsWith("uTank2 NAV", StringComparison.OrdinalIgnoreCase))
		{
			Util.WriteToChat("Nav: " + Path.GetFileName(path) + " isn't a VTank nav file.");
			return null;
		}
		int.TryParse(next(), out var result);
		NavRoute navRoute = new NavRoute
		{
			Name = Path.GetFileNameWithoutExtension(path)
		};
		navRoute.Mode = result switch
		{
			4 => 0, 
			2 => 1, 
			_ => 2, 
		};
		if (result == 3)
		{
			string text = next();
			Util.WriteToChat("Nav: " + Path.GetFileName(path) + " is a VTank follow nav for " + text + " - use Nav mode 'Follow a player' for that.");
			return null;
		}
		int.TryParse(next(), out var result2);
		List<string> list = new List<string>();
		for (int num = 0; num < result2; num++)
		{
			if (i >= lines.Length)
			{
				break;
			}
			if (!int.TryParse(next(), out var result3))
			{
				break;
			}
			double eW = func();
			double nS = func();
			double z = func() * 240.0;
			next();
			RouteStep item = new RouteStep
			{
				Kind = StepKind.Point,
				NS = nS,
				EW = eW,
				Z = z
			};
			switch (result3)
			{
			case 0:
			case 8:
				navRoute.Steps.Add(item);
				break;
			case 2:
			{
				int.TryParse(next(), out var result4);
				navRoute.Steps.Add(new RouteStep
				{
					Kind = StepKind.Cast,
					Text = result4.ToString(Inv)
				});
				break;
			}
			case 3:
			{
				double num4 = func();
				navRoute.Steps.Add(new RouteStep
				{
					Kind = StepKind.Wait,
					WaitMs = (int)num4
				});
				break;
			}
			case 4:
				navRoute.Steps.Add(new RouteStep
				{
					Kind = StepKind.Command,
					Text = (next() ?? ""),
					WaitMs = 1000
				});
				break;
			case 5:
			{
				next();
				string text2 = next() ?? "";
				navRoute.Steps.Add(new RouteStep
				{
					Kind = StepKind.Use,
					Text = text2,
					NS = nS,
					EW = eW,
					Z = z
				});
				break;
			}
			case 6:
			case 7:
			{
				string text3 = next() ?? "";
				next();
				next();
				double eW2 = func();
				double nS2 = func();
				double z2 = func() * 240.0;
				navRoute.Steps.Add(new RouteStep
				{
					Kind = StepKind.Use,
					Text = text3,
					NS = nS2,
					EW = eW2,
					Z = z2
				});
				break;
			}
			case 9:
			{
				double num2 = func();
				string a = next();
				double num3 = func();
				bool flag = string.Equals(a, "True", StringComparison.OrdinalIgnoreCase);
				navRoute.Steps.Add(new RouteStep
				{
					Kind = StepKind.Command,
					Text = "/ub jump" + (flag ? "s" : "") + "w " + num2.ToString("0", Inv) + " " + num3.ToString("0", Inv),
					WaitMs = 1500
				});
				break;
			}
			default:
				list.Add("type " + result3);
				navRoute.Steps.Add(item);
				break;
			}
		}
		Util.WriteToChat("Nav: imported " + Path.GetFileName(path) + " - " + navRoute.Steps.Count + " steps, " + RouteModes[navRoute.Mode] + "." + ((list.Count > 0) ? (" Unknown waypoints kept as points: " + string.Join(", ", list.ToArray()) + ".") : ""));
		return navRoute;
	}

	public bool ExportNav(NavRoute r, string path, bool quiet = false)
	{
		r = NavPresets.Expanded(r);
		StringBuilder stringBuilder = new StringBuilder();
		int num = 0;
		int num2 = 0;
		RouteStep routeStep = null;
		Func<RouteStep, string> func = (RouteStep s) => ((s == null) ? "0\n0\n0" : (s.EW.ToString("R", Inv) + "\n" + s.NS.ToString("R", Inv) + "\n" + (s.Z / 240.0).ToString("R", Inv))) + "\n0\n";
		foreach (RouteStep step in r.Steps)
		{
			switch (step.Kind)
			{
			case StepKind.Point:
				stringBuilder.Append("0\n").Append(func(step));
				routeStep = step;
				num++;
				break;
			case StepKind.Command:
				stringBuilder.Append("4\n").Append(func(routeStep)).Append(step.Text)
					.Append('\n');
				num++;
				break;
			case StepKind.Wait:
				stringBuilder.Append("3\n").Append(func(routeStep)).Append(step.WaitMs.ToString(Inv))
					.Append('\n');
				num++;
				break;
			case StepKind.Cast:
				stringBuilder.Append("2\n").Append(func(routeStep)).Append(step.Text)
					.Append('\n');
				num++;
				break;
			case StepKind.UseItem:
				stringBuilder.Append("4\n").Append(func(routeStep)).Append("/ub use " + step.Text)
					.Append('\n');
				num++;
				break;
			case StepKind.Use:
				stringBuilder.Append("6\n").Append(func(routeStep ?? step)).Append(step.Text)
					.Append("\n14\nTrue\n")
					.Append(step.EW.ToString("R", Inv))
					.Append('\n')
					.Append(step.NS.ToString("R", Inv))
					.Append('\n')
					.Append((step.Z / 240.0).ToString("R", Inv))
					.Append('\n');
				num++;
				break;
			default:
				num2++;
				break;
			}
		}
		int num3 = ((r.Mode == 0) ? 4 : ((r.Mode != 1) ? 1 : 2));
		try
		{
			File.WriteAllText(path, "uTank2 NAV 1.2\r\n" + num3 + "\r\n" + num + "\r\n" + stringBuilder.ToString().Replace("\n", "\r\n").Replace("\r\r\n", "\r\n"));
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Nav: couldn't write " + path + ": " + ex.Message);
			return false;
		}
		if (!quiet || num2 > 0)
		{
			Util.WriteToChat((quiet ? ("Nav: " + r.Name + ":") : ("Nav: exported " + r.Name + " as " + Path.GetFileName(path) + " (" + num + " waypoints).")) + ((num2 > 0) ? (" Left out " + num2 + " step(s) VTank's nav format can't hold (loop start / end, switches, chat waits, item checks, go to route).") : ""));
		}
		return true;
	}

	public bool SaveRouteFile(NavRoute r, string path)
	{
		return SaveRouteFile(r, path, quiet: false);
	}

	public bool SaveRouteFile(NavRoute r, string path, bool quiet)
	{
		try
		{
			XmlDocument xmlDocument = new XmlDocument();
			XmlElement xmlElement = xmlDocument.CreateElement("MelkTankRoute");
			xmlDocument.AppendChild(xmlElement);
			Settings.WriteRoute(xmlDocument, xmlElement, r);
			xmlDocument.Save(path);
			if (!quiet)
			{
				Util.WriteToChat("Nav: saved " + r.Name + " to " + Path.GetFileName(path) + ".");
			}
			return true;
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Nav: couldn't save " + path + ": " + ex.Message);
			return false;
		}
	}

	public NavRoute LoadRouteFile(string path)
	{
		try
		{
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.Load(path);
			NavRoute navRoute = Settings.ReadRoute(xmlDocument.DocumentElement);
			if (navRoute != null && navRoute.Name.Length == 0)
			{
				navRoute.Name = Path.GetFileNameWithoutExtension(path);
			}
			return navRoute;
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Nav: couldn't read " + path + ": " + ex.Message);
			return null;
		}
	}

	private static string SafeName(string n)
	{
		char[] invalidFileNameChars = Path.GetInvalidFileNameChars();
		foreach (char oldChar in invalidFileNameChars)
		{
			n = n.Replace(oldChar, '_');
		}
		return (n.Trim().Length == 0) ? "route" : n.Trim();
	}

	private bool DrawRouteFiles(NavRoute r)
	{
		bool result = false;
		ImGui.Indent(8f);
		string dir = Dir;
		if (ImGui.RadioButton("MelkTank Navs folder", !_showVtankDir))
		{
			_showVtankDir = false;
			_treeAt = DateTime.MinValue;
			_pickFile = (_pickFolder = null);
		}
		ImGui.SameLine();
		if (VtankDir != null)
		{
			if (ImGui.RadioButton("VTank folder", _showVtankDir))
			{
				_showVtankDir = true;
				_treeAt = DateTime.MinValue;
				_pickFile = (_pickFolder = null);
			}
		}
		else
		{
			Im.TextColored(Grey, "(no VTank folder found)");
		}
		ImGui.SameLine();
		if (ImGui.SmallButton("Refresh"))
		{
			_treeAt = DateTime.MinValue;
		}
		Im.TextColored(Grey, dir);
		if (_tree == null || _tree.Path != dir || (DateTime.Now - _treeAt).TotalSeconds > 5.0)
		{
			_tree = Scan(dir, 0);
			_treeAt = DateTime.Now;
		}
		if (_pickFolder == null || !_pickFolder.StartsWith(dir, StringComparison.OrdinalIgnoreCase))
		{
			_pickFolder = dir;
		}
		if (ImGui.BeginChild("##navtree", new System.Numerics.Vector2(0f, 180f), border: true))
		{
			if (_tree.Dirs.Count == 0 && _tree.Files.Count == 0)
			{
				Im.TextColored(Grey, "No .nav / .mtnav files here yet. Make sub folders (Dungeons, Quests...) to group them.");
			}
			DrawTreeDir(_tree, top: true);
		}
		ImGui.EndChild();
		bool flag = _pickFile != null && File.Exists(_pickFile);
		if (flag && _pickFile.EndsWith(".met", StringComparison.OrdinalIgnoreCase))
		{
			if (ImGui.Button("Deconstruct meta into navs"))
			{
				DeconstructMeta(_pickFile);
				_treeAt = DateTime.MinValue;
			}
			Tip("Saves every nav built into this VTank meta as its own .nav file: <meta>Nav1_<its name>.nav, Nav2... \nThey go in the same folder as the meta (or the MelkTank Navs folder when the meta is in VTank's folder).\nThe meta itself isn't changed.");
			ImGui.SameLine();
			Im.TextColored(Grey, Path.GetFileName(_pickFile));
			ImGui.Unindent(8f);
			return result;
		}
		if (!flag)
		{
			ImGui.BeginDisabled();
		}
		if (ImGui.Button("Load") & flag)
		{
			bool flag2 = _pickFile.EndsWith(".mtnav", StringComparison.OrdinalIgnoreCase);
			NavSpot sp = (flag2 ? LoadSpotFile(_pickFile) : null);
			NavRoute nr;
			if (sp != null)
			{
				nr = null;
			}
			else
			{
				nr = (flag2 ? LoadRouteFile(_pickFile) : ImportNav(_pickFile));
			}
			if (sp != null)
			{
				sp.File = (_pickFile.StartsWith(NavDir, StringComparison.OrdinalIgnoreCase) ? _pickFile : "");
				string name = sp.Name;
				int num = 2;
				while (_s.NavSpots.Exists((NavSpot x) => string.Equals(x.Name, sp.Name, StringComparison.OrdinalIgnoreCase)))
				{
					sp.Name = name + " (" + num++ + ")";
				}
				_s.NavSpots.Add(sp);
				_s.NavSelected = sp.Name;
				Stop();
				result = true;
				Util.WriteToChat("Nav: spot " + sp.Name + " loaded (Nav mode: Stay on a spot).");
			}
			if (nr != null)
			{
				nr.File = ((flag2 && _pickFile.StartsWith(NavDir, StringComparison.OrdinalIgnoreCase)) ? _pickFile : "");
				string name2 = nr.Name;
				int num2 = 2;
				while (_s.NavRoutes.Exists((NavRoute x) => string.Equals(x.Name, nr.Name, StringComparison.OrdinalIgnoreCase)))
				{
					nr.Name = name2 + " (" + num2++ + ")";
				}
				_s.NavRoutes.Add(nr);
				_s.NavRouteSelected = nr.Name;
				Stop();
				RouteReset();
				_rSel = -1;
				result = true;
			}
		}
		if (!flag)
		{
			ImGui.EndDisabled();
		}
		Tip("Click a file in the list first. A route file is added as a new route (a VTank .nav is converted);\na spot file (in Spots) as a new spot. The file itself isn't changed.");
		if (flag)
		{
			ImGui.SameLine();
			Im.TextColored(Grey, Path.GetFileName(_pickFile));
		}
		if (r != null)
		{
			string text = ((_pickFolder.Length > dir.Length) ? _pickFolder.Substring(dir.Length).TrimStart(new char[2] { '\\', '/' }) : "");
			Im.TextColored(Grey, "Saves go to: " + ((text.Length > 0) ? text : "(top folder)") + "   - click a folder to change");
			if (ImGui.Button("Save as MelkTank file (.mtnav)") && SaveRouteFile(r, Path.Combine(_pickFolder, SafeName(r.Name) + ".mtnav")))
			{
				_treeAt = DateTime.MinValue;
			}
			Tip("Everything in the route - for your other characters, or to keep a copy. Same name: replaced.");
			ImGui.SameLine();
			if (ImGui.Button("Export as VTank .nav") && ExportNav(r, Path.Combine(_pickFolder, SafeName(r.Name) + ".nav")))
			{
				_treeAt = DateTime.MinValue;
			}
			Tip("For VTank. Loop starts and combat / looting switches can't be written in VTank's format - they're left out.");
		}
		ImGui.Unindent(8f);
		return result;
	}

	public void RouteChanged()
	{
		_routeDirtyAt = DateTime.Now;
	}

	public void SaveRouteFiles(bool now)
	{
		try
		{
			SaveSpotFiles(now);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		if (!_filesChecked)
		{
			_filesChecked = true;
			foreach (NavRoute navRoute in _s.NavRoutes)
			{
				if (string.IsNullOrEmpty(navRoute.File) || !File.Exists(navRoute.File))
				{
					AutoSave(navRoute);
				}
			}
		}
		if (!(_routeDirtyAt == DateTime.MinValue) && (now || !((DateTime.Now - _routeDirtyAt).TotalSeconds < 1.5)))
		{
			_routeDirtyAt = DateTime.MinValue;
			NavRoute currentRoute = CurrentRoute;
			if (currentRoute != null && !IsMetaRoute(currentRoute))
			{
				AutoSave(currentRoute);
			}
		}
	}

	private void AutoSave(NavRoute r)
	{
		if (string.Equals(r.Name, "Map route", StringComparison.OrdinalIgnoreCase))
		{
			return;
		}
		try
		{
			string path = SafeName(r.Name) + ".mtnav";
			string text = ((!string.IsNullOrEmpty(r.File) && Directory.Exists(Path.GetDirectoryName(r.File))) ? Path.GetDirectoryName(r.File) : NavDir);
			string text2 = Path.Combine(text, path);
			Directory.CreateDirectory(text);
			if (!string.IsNullOrEmpty(r.File) && !string.Equals(r.File, text2, StringComparison.OrdinalIgnoreCase) && File.Exists(r.File))
			{
				try
				{
					File.Delete(r.File);
				}
				catch
				{
				}
			}
			bool flag = string.IsNullOrEmpty(r.File) || !File.Exists(text2);
			if (SaveRouteFile(r, text2, quiet: true))
			{
				bool flag2 = !string.Equals(r.File, text2, StringComparison.OrdinalIgnoreCase);
				r.File = text2;
				if (flag)
				{
					Util.WriteToChat("Nav: route " + r.Name + " is saved as " + text2.Substring(Math.Min(text2.Length, NavDir.Length)).TrimStart(new char[2] { '\\', '/' }) + " (kept up to date as you edit).");
				}
				_treeAt = DateTime.MinValue;
				if (flag2 && SaveAll != null)
				{
					SaveAll();
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public void SpotChanged()
	{
		_spotDirtyAt = DateTime.Now;
	}

	public bool SaveSpotFile(NavSpot p, string path)
	{
		try
		{
			XmlDocument xmlDocument = new XmlDocument();
			XmlElement xmlElement = xmlDocument.CreateElement("MelkTankSpot");
			xmlDocument.AppendChild(xmlElement);
			xmlElement.SetAttribute("name", p.Name);
			xmlElement.SetAttribute("ns", p.NS.ToString("R", CultureInfo.InvariantCulture));
			xmlElement.SetAttribute("ew", p.EW.ToString("R", CultureInfo.InvariantCulture));
			xmlElement.SetAttribute("z", p.Z.ToString("R", CultureInfo.InvariantCulture));
			xmlElement.SetAttribute("heading", p.Heading.ToString("R", CultureInfo.InvariantCulture));
			xmlElement.SetAttribute("face", p.FaceHeading.ToString());
			xmlDocument.Save(path);
			return true;
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Nav: couldn't save " + path + ": " + ex.Message);
			return false;
		}
	}

	public NavSpot LoadSpotFile(string path)
	{
		try
		{
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.Load(path);
			XmlElement documentElement = xmlDocument.DocumentElement;
			if (documentElement == null || documentElement.Name != "MelkTankSpot")
			{
				return null;
			}
			NavSpot navSpot = new NavSpot
			{
				Name = documentElement.GetAttribute("name")
			};
			if (navSpot.Name.Length == 0)
			{
				navSpot.Name = Path.GetFileNameWithoutExtension(path);
			}
			double.TryParse(documentElement.GetAttribute("ns"), NumberStyles.Float, CultureInfo.InvariantCulture, out navSpot.NS);
			double.TryParse(documentElement.GetAttribute("ew"), NumberStyles.Float, CultureInfo.InvariantCulture, out navSpot.EW);
			double.TryParse(documentElement.GetAttribute("z"), NumberStyles.Float, CultureInfo.InvariantCulture, out navSpot.Z);
			if (!double.TryParse(documentElement.GetAttribute("heading"), NumberStyles.Float, CultureInfo.InvariantCulture, out navSpot.Heading))
			{
				navSpot.Heading = -1.0;
			}
			navSpot.FaceHeading = !bool.TryParse(documentElement.GetAttribute("face"), out var result) | result;
			return navSpot;
		}
		catch
		{
			return null;
		}
	}

	private void SaveSpotFiles(bool now)
	{
		if (!_spotFilesChecked)
		{
			_spotFilesChecked = true;
			foreach (NavSpot navSpot in _s.NavSpots)
			{
				if (string.IsNullOrEmpty(navSpot.File) || !File.Exists(navSpot.File))
				{
					AutoSaveSpot(navSpot);
				}
			}
		}
		if (!(_spotDirtyAt == DateTime.MinValue) && (now || !((DateTime.Now - _spotDirtyAt).TotalSeconds < 1.5)))
		{
			_spotDirtyAt = DateTime.MinValue;
			NavSpot current2 = Current;
			if (current2 != null)
			{
				AutoSaveSpot(current2);
			}
		}
	}

	private void AutoSaveSpot(NavSpot p)
	{
		try
		{
			string text = ((!string.IsNullOrEmpty(p.File) && Directory.Exists(Path.GetDirectoryName(p.File))) ? Path.GetDirectoryName(p.File) : SpotDir);
			Directory.CreateDirectory(text);
			string text2 = Path.Combine(text, SafeName(p.Name) + ".mtnav");
			if (!string.IsNullOrEmpty(p.File) && !string.Equals(p.File, text2, StringComparison.OrdinalIgnoreCase) && File.Exists(p.File))
			{
				try
				{
					File.Delete(p.File);
				}
				catch
				{
				}
			}
			bool flag = string.IsNullOrEmpty(p.File) || !File.Exists(text2);
			if (SaveSpotFile(p, text2))
			{
				bool flag2 = !string.Equals(p.File, text2, StringComparison.OrdinalIgnoreCase);
				p.File = text2;
				if (flag)
				{
					Util.WriteToChat("Nav: spot " + p.Name + " is saved as " + text2.Substring(Math.Min(text2.Length, NavDir.Length)).TrimStart(new char[2] { '\\', '/' }) + ".");
				}
				_treeAt = DateTime.MinValue;
				if (flag2 && SaveAll != null)
				{
					SaveAll();
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public int DeconstructMeta(string metPath)
	{
		byte[] array;
		try
		{
			array = File.ReadAllBytes(metPath);
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Nav: can't read " + metPath + ": " + ex.Message);
			return 0;
		}
		string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(metPath);
		string text = Path.GetDirectoryName(metPath);
		if (!text.StartsWith(NavDir, StringComparison.OrdinalIgnoreCase))
		{
			text = NavDir;
		}
		int num = 0;
		int num2 = 0;
		List<string> list = new List<string>();
		while (num2 < array.Length)
		{
			int num3 = FindLine(array, num2, "ba");
			if (num3 < 0)
			{
				break;
			}
			int num4 = num3;
			int num5 = Array.IndexOf(array, (byte)10, num4);
			if (num5 < 0)
			{
				break;
			}
			if (!int.TryParse(Encoding.ASCII.GetString(array, num4, num5 - num4).Trim(), out var result) || result <= 0 || num5 + 1 + result > array.Length)
			{
				num2 = num5 + 1;
				continue;
			}
			int num6 = num5 + 1;
			string text2 = Encoding.Default.GetString(array, num6, result);
			num2 = num6 + result;
			int num7 = text2.IndexOf("uTank2 NAV", StringComparison.OrdinalIgnoreCase);
			if (num7 >= 0)
			{
				string text3 = text2.Substring(0, (text2.IndexOfAny(new char[2] { '\r', '\n' }) >= 0) ? text2.IndexOfAny(new char[2] { '\r', '\n' }) : 0).Trim();
				if (text3.EndsWith(".nav", StringComparison.OrdinalIgnoreCase))
				{
					text3 = text3.Substring(0, text3.Length - 4);
				}
				if (text3.StartsWith("uTank2", StringComparison.OrdinalIgnoreCase) || text3.Equals("[None]", StringComparison.OrdinalIgnoreCase))
				{
					text3 = "";
				}
				num++;
				string text4 = SafeName(fileNameWithoutExtension + "Nav" + num + ((text3.Length > 0) ? ("_" + text3) : "")) + ".nav";
				try
				{
					File.WriteAllText(Path.Combine(text, text4), text2.Substring(num7), Encoding.Default);
					list.Add(text4);
				}
				catch (Exception ex2)
				{
					Util.WriteToChat("Nav: couldn't write " + text4 + ": " + ex2.Message);
				}
			}
		}
		if (list.Count == 0)
		{
			Util.WriteToChat("Nav: no navs found inside " + Path.GetFileName(metPath) + ".");
		}
		else
		{
			Util.WriteToChat("Nav: " + Path.GetFileName(metPath) + " -> " + list.Count + " nav(s) in " + text + ": " + string.Join(", ", list.ToArray()));
		}
		return list.Count;
	}

	private static int FindLine(byte[] b, int from, string line)
	{
		byte[] bytes = Encoding.ASCII.GetBytes(line);
		for (int i = from; i + bytes.Length < b.Length; i++)
		{
			if (i > 0 && b[i - 1] != 10)
			{
				continue;
			}
			bool flag = true;
			for (int j = 0; (j < bytes.Length) & flag; j++)
			{
				flag = b[i + j] == bytes[j];
			}
			if (flag)
			{
				int num = i + bytes.Length;
				if (num < b.Length && b[num] == 13)
				{
					num++;
				}
				if (num < b.Length && b[num] == 10)
				{
					return num + 1;
				}
			}
		}
		return -1;
	}

	private void DrawTreeDir(TreeDir d, bool top)
	{
		foreach (TreeDir dir in d.Dirs)
		{
			ImGuiTreeNodeFlags imGuiTreeNodeFlags = ImGuiTreeNodeFlags.OpenOnDoubleClick | ImGuiTreeNodeFlags.OpenOnArrow | ImGuiTreeNodeFlags.SpanAvailWidth;
			if (string.Equals(_pickFolder, dir.Path, StringComparison.OrdinalIgnoreCase))
			{
				imGuiTreeNodeFlags |= ImGuiTreeNodeFlags.Selected;
			}
			bool flag = ImGui.TreeNodeEx(dir.Name + "###d" + dir.Path, imGuiTreeNodeFlags);
			if (ImGui.IsItemClicked() && !ImGui.IsItemToggledOpen())
			{
				_pickFolder = dir.Path;
			}
			if (flag)
			{
				DrawTreeDir(dir, top: false);
				ImGui.TreePop();
			}
		}
		foreach (string file in d.Files)
		{
			bool selected = string.Equals(_pickFile, file, StringComparison.OrdinalIgnoreCase);
			bool flag2 = file.EndsWith(".nav", StringComparison.OrdinalIgnoreCase);
			bool flag3 = file.EndsWith(".met", StringComparison.OrdinalIgnoreCase);
			System.Numerics.Vector4 col;
			if (flag3)
			{
				col = new System.Numerics.Vector4(0.8f, 0.65f, 1f, 1f);
			}
			else
			{
				col = (flag2 ? new System.Numerics.Vector4(0.85f, 0.85f, 0.6f, 1f) : new System.Numerics.Vector4(0.6f, 0.85f, 1f, 1f));
			}
			ImGui.PushStyleColor(ImGuiCol.Text, col);
			if (ImGui.Selectable("    " + Path.GetFileName(file) + "###f" + file, selected))
			{
				_pickFile = file;
				_pickFolder = Path.GetDirectoryName(file);
			}
			ImGui.PopStyleColor();
			if (ImGui.IsItemHovered() && ImGui.IsMouseDoubleClicked(ImGuiMouseButton.Left))
			{
				_pickFile = file;
			}
		}
	}

	private static double Flat(NavSpot a, NavSpot b)
	{
		double num = (a.NS - b.NS) * 240.0;
		double num2 = (a.EW - b.EW) * 240.0;
		return Math.Sqrt(num * num + num2 * num2);
	}
}
