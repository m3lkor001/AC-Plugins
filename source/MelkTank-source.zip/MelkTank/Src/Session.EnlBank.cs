using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using MelkTank.Metas;
using AcClient;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Bounties;
using MelkTank.Buffs;

namespace MelkTank;

public static partial class Session
{
	public static List<string> EnlPhoneLines(int target)
	{
		List<string> o = new List<string>();
		CountEnlItems(now: false);
		int num = EnlCount(out var _);
		if (num < 0)
		{
			o.Add("n|Enlightenment not known yet - Update on the Enl tab (or type it there).");
			return o;
		}
		int num2 = 0;
		try
		{
			num2 = CoreManager.Current.CharacterFilter.Level;
		}
		catch
		{
		}
		long num3 = BankNum("Luminance");
		long num4 = Math.Max(0L, BankNum("Enlightenment Tokens"));
		long coins = Math.Max(0L, BankNum("Enlightened Coins"));
		int num5 = Have("Enlightenment Token");
		int num6 = Have("Enlightenment Medallion");
		Func<long, string> func = (long v) => v.ToString("N0", EnlInv);
		Action<bool, string> action = (bool ok, string t) =>
		{
			o.Add((ok ? "g|" : "r|") + t);
		};
		o.Add("h|Enlightenment " + num);
		int n = num + 1;
		bool flag = EnlUsesMedallions(n);
		int num7 = EnlTokensNeeded(n);
		int num8 = (flag ? num6 : num5);
		o.Add("h|Enlightenment " + n + " needs:");
		action(num2 >= EnlLevelNeeded(n), "Level " + EnlLevelNeeded(n) + " (you: " + ((num2 > 0) ? num2.ToString() : "?") + ")");
		if (num7 > 0)
		{
			action(num8 >= num7, (flag ? "Medallions " : "Tokens ") + func(num7) + " (have " + func(num8) + ((flag || num4 == 0L) ? "" : (", +" + func(num4) + " in the bank")) + ")" + ((num8 >= num7) ? "" : (" - short " + func(num7 - num8))));
		}
		long num9 = EnlLumNeeded(n);
		if (num9 > 0)
		{
			action(num3 >= num9, "Luminance " + Lum(num9) + " (banked " + ((num3 >= 0) ? Lum(num3) : "?") + ")" + ((num3 >= 0 && num3 < num9) ? (" - short " + Lum(num9 - num3)) : ""));
		}
		if (flag && num8 < num7)
		{
			MedalLines(o, num7 - num8, num4, coins, "To make the missing medallions:");
		}
		if (target > num)
		{
			int num10 = 0;
			int num11 = 0;
			long num12 = 0L;
			for (int num13 = num + 1; num13 <= target; num13++)
			{
				if (EnlUsesMedallions(num13))
				{
					num11 += EnlTokensNeeded(num13);
				}
				else
				{
					num10 += EnlTokensNeeded(num13);
				}
				num12 += EnlLumNeeded(num13);
			}
			o.Add("h|Up to " + target + " (" + (target - num) + " more):");
			action(num2 >= EnlLevelNeeded(target), "Level " + EnlLevelNeeded(target) + " for the last one");
			if (num10 > 0)
			{
				action(num5 + num4 >= num10, "Tokens " + func(num10) + " (have " + func(num5 + num4) + ")" + ((num5 + num4 >= num10) ? "" : (" - short " + func(num10 - num5 - num4))));
			}
			if (num11 > 0)
			{
				action(num6 >= num11, "Medallions " + func(num11) + " (have " + func(num6) + ")" + ((num6 >= num11) ? "" : (" - short " + func(num11 - num6))));
			}
			if (num12 > 0)
			{
				action(num3 >= num12, "Luminance " + Lum(num12) + " (banked " + ((num3 >= 0) ? Lum(num3) : "?") + ")" + ((num3 >= 0 && num3 < num12) ? (" - short " + Lum(num12 - num3)) : ""));
			}
			if (num11 > num6)
			{
				MedalLines(o, num11 - num6, Math.Max(0L, num4 - Math.Max(0, num10 - num5)), coins, "To make the missing medallions:");
			}
		}
		else
		{
			int num14 = num;
			int num15 = 0;
			int num16 = 0;
			long num17 = 0L;
			string text = "";
			for (int num18 = num + 1; num18 < num + 2000; num18++)
			{
				int num19 = EnlTokensNeeded(num18);
				bool flag2 = EnlUsesMedallions(num18);
				if (num2 < EnlLevelNeeded(num18))
				{
					text = "level " + EnlLevelNeeded(num18);
					break;
				}
				if (!flag2 && num15 + num19 > num5 + num4)
				{
					text = "tokens";
					break;
				}
				if (flag2 && num16 + num19 > num6)
				{
					text = "medallions";
					break;
				}
				if (num3 >= 0 && num17 + EnlLumNeeded(num18) > num3)
				{
					text = "luminance";
					break;
				}
				if (flag2)
				{
					num16 += num19;
				}
				else
				{
					num15 += num19;
				}
				num17 += EnlLumNeeded(num18);
				num14 = num18;
			}
			o.Add("h|With what you have:");
			action(num14 > num, (num14 > num) ? ("You can go up to " + num14 + " (" + (num14 - num) + " more)" + ((text.Length > 0) ? (" - then short of " + text) : "")) : ("Not even the next one yet" + ((text.Length > 0) ? (" - short of " + text) : "")));
		}
		try
		{
			o.AddRange(EnlPlanLines(target));
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		return o;
	}

	private static void MedalLines(List<string> o, int missing, long bankTokens, long coins, string title)
	{
		Func<long, string> N = (long v) => v.ToString("N0", EnlInv);
		int num = Have("Part of a Medallion");
		int num2 = Have("Enlightenment Token");
		int num3 = Have("Trophy");
		int num4 = Have("Yellow Aetheria Powder");
		int num5 = Have("Yellow Aetheria Chunk");
		int num6 = Have("Aetheria Desiccant");
		int num7 = Math.Max(0, missing - num);
		int num8 = Math.Max(0, num7 - num4);
		long num9 = Math.Max(0, missing - num2);
		o.Add("n|" + title + " " + missing + " (one each of):");
		Action<string, long, long, string> action = (string what, long have, long need, string note) =>
		{
			o.Add(((have >= need) ? "g|" : "r|") + "  " + what + ": " + N(have) + " / " + N(need) + ((have >= need) ? "" : (" - short " + N(need - have))) + ((note != null) ? (" (" + note + ")") : ""));
		};
		action("Enlightenment Tokens", num2, missing, (bankTokens > 0) ? (N(bankTokens) + " in the bank") : null);
		if (num9 > bankTokens)
		{
			long num10 = num9 - bankTokens;
			o.Add(((coins >= num10 * 20) ? "g|" : "r|") + "    buy " + N(num10) + " = " + N(num10 * 20) + " Enlightened Coins (banked " + N(coins) + ")");
		}
		action("Parts of a Medallion", num, missing, null);
		if (num7 > 0)
		{
			action("  Trophies", num3, num7, "VoD drops");
			action("  Yellow Aetheria Powder", num4, num7, null);
			if (num8 > 0)
			{
				action("    Yellow Aetheria Chunks", num5, num8, null);
				action("    Aetheria Desiccant", num6, num8, null);
			}
		}
	}

	private static void NeedRow(string what, string need, string have, bool ok, Vector4 green, Vector4 red)
	{
		ImGui.TableNextRow();
		ImGui.TableSetColumnIndex(0);
		Im.TextColored(ok ? green : red, what);
		ImGui.TableSetColumnIndex(1);
		Im.TextColored(ok ? green : red, need);
		ImGui.TableSetColumnIndex(2);
		Im.TextColored(ok ? green : red, have);
	}

	private static void Have2(string what, long have, long need, Vector4 green, Vector4 red, string note)
	{
		Im.TextColored((have >= need) ? green : red, "  " + what + ": " + have.ToString("N0", EnlInv) + " / " + need.ToString("N0", EnlInv) + ((have >= need) ? "" : (" - short " + (need - have).ToString("N0", EnlInv))) + ((note != null) ? ("  (" + note + ")") : ""));
	}

	private static bool BankReady()
	{
		return (DateTime.Now - _bankCmdAt).TotalSeconds >= 6.0;
	}

	private static void BankAdd(string name, long delta)
	{
		foreach (BankLine item in _bank)
		{
			if (!string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
			{
				continue;
			}
			string[] array = item.Value.Split(new char[1] { ' ' }, 2);
			if (long.TryParse(array[0].Replace(",", ""), NumberStyles.Integer, EnlInv, out var result))
			{
				item.Value = Math.Max(0L, result + delta).ToString("N0", EnlInv) + ((array.Length > 1) ? (" " + array[1]) : "");
			}
			break;
		}
	}

	public static string WithdrawTokens(long n)
	{
		if (n < 1)
		{
			return "Nothing to withdraw.";
		}
		if (!BankReady())
		{
			return "The bank needs a few seconds between commands - try again.";
		}
		_bankCmdAt = DateTime.Now;
		Util.Command("/b w et " + n.ToString(EnlInv));
		BankAdd("Enlightenment Tokens", -n);
		_bankRecheckAt = DateTime.Now.AddSeconds(2.5);
		return "Withdrawing " + n + " Enlightenment Token" + ((n == 1) ? "" : "s") + ".";
	}

	private static Dictionary<int, WorldObject> VendorTokens()
	{
		Dictionary<int, WorldObject> dictionary = new Dictionary<int, WorldObject>();
		try
		{
			Vendor openVendor = CoreManager.Current.WorldFilter.OpenVendor;
			if (openVendor == null || openVendor.MerchantId == 0)
			{
				return dictionary;
			}
			foreach (WorldObject item in openVendor)
			{
				string input = item.Name ?? "";
				Match match = Regex.Match(input, "^(?:(\\d+)x )?Enlightenment Tokens?$", RegexOptions.IgnoreCase);
				if (match.Success)
				{
					int result = 1;
					if (match.Groups[1].Success)
					{
						int.TryParse(match.Groups[1].Value, out result);
					}
					if (result > 0 && !dictionary.ContainsKey(result))
					{
						dictionary[result] = item;
					}
				}
			}
		}
		catch
		{
		}
		return dictionary;
	}

	public static bool TokenVendorOpen()
	{
		return VendorTokens().Count > 0;
	}

	public static string BuyTokens(long n)
	{
		Dictionary<int, WorldObject> dictionary = VendorTokens();
		if (dictionary.Count == 0)
		{
			return "Buy tokens: open the aug gem vendor first (tokens are under Misc).";
		}
		long num = BankNum("Enlightened Coins");
		if (num >= 0)
		{
			n = Math.Min(n, num / 20);
		}
		if (n < 1)
		{
			return "Buy tokens: not enough Enlightened Coins (" + 20 + " each" + ((num >= 0) ? (", banked " + num.ToString("N0", EnlInv)) : "") + ").";
		}
		_buyLeft = n;
		_buyTotal = n;
		_buyDone = 0L;
		_buyWaiting = false;
		_buyMisses = 0;
		_buyNextAt = DateTime.MinValue;
		return "Buying " + n.ToString("N0", EnlInv) + " Enlightenment Token" + ((n == 1) ? "" : "s") + " (" + (n * 20).ToString("N0", EnlInv) + " coins)" + ((n > 100) ? (", " + 100 + " at a time") : "") + ".";
	}

	private static void BuyStop(string why)
	{
		if (_buyLeft > 0 || _buyWaiting)
		{
			_buyLeft = 0L;
			_buyWaiting = false;
			Util.WriteToChat("Buy tokens: " + why + " - bought " + _buyDone.ToString("N0", EnlInv) + " of " + _buyTotal.ToString("N0", EnlInv) + ".");
			_bankRecheckAt = DateTime.Now.AddSeconds(1.5);
		}
	}

	private static void BuyTick()
	{
		if (_buyLeft <= 0 && !_buyWaiting)
		{
			return;
		}
		if (_buyWaiting)
		{
			CountEnlItems(now: true);
			if (Have("Enlightenment Token") >= _buyTokBefore + _buyNow)
			{
				_buyWaiting = false;
				_buyMisses = 0;
				_buyDone += _buyNow;
				_buyLeft -= _buyNow;
				BankAdd("Enlightened Coins", -_buyNow * 20);
				_buyNextAt = DateTime.Now.AddMilliseconds(800.0);
				if (_buyLeft <= 0)
				{
					Util.WriteToChat("Buy tokens: bought " + _buyDone.ToString("N0", EnlInv) + ".");
					_bankRecheckAt = DateTime.Now.AddSeconds(1.5);
				}
			}
			else if (!((DateTime.Now - _buySentAt).TotalSeconds < 5.0))
			{
				_buyWaiting = false;
				if (++_buyMisses >= 2)
				{
					BuyStop("the vendor didn't sell (out of coins?)");
				}
				else
				{
					_buyNextAt = DateTime.Now.AddSeconds(1.0);
				}
			}
		}
		else
		{
			if (DateTime.Now < _buyNextAt)
			{
				return;
			}
			Dictionary<int, WorldObject> dictionary = VendorTokens();
			if (dictionary.Count != 0)
			{
				WorldObject worldObject = null;
				using (Dictionary<int, WorldObject>.Enumerator enumerator = dictionary.GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						worldObject = enumerator.Current.Value;
					}
				}
				int num = (int)Math.Min(_buyLeft, 100L);
				try
				{
					CountEnlItems(now: true);
					_buyTokBefore = Have("Enlightenment Token");
					HooksWrapper actions = CoreManager.Current.Actions;
					actions.VendorClearBuyList();
					actions.VendorAddBuyList(worldObject.Id, num);
					actions.VendorBuyAll();
					_buyNow = num;
					_buyWaiting = true;
					_buySentAt = DateTime.Now;
					return;
				}
				catch (Exception ex)
				{
					BuyStop(ex.Message);
					return;
				}
			}
			BuyStop("the vendor closed");
		}
	}

	private static void EnlBankTick()
	{
		BuyTick();
		CreditUseTick();
		if (!(_bankRecheckAt == DateTime.MinValue) && !(DateTime.Now < _bankRecheckAt))
		{
			_bankRecheckAt = DateTime.MinValue;
			QuietNext("/bank");
			Util.Command("/bank");
		}
	}

	private static int PartsPossible(bool countMaking)
	{
		int num = Have("Part of a Medallion");
		if (!countMaking)
		{
			return num;
		}
		int val = Have("Yellow Aetheria Powder") + Math.Min(Have("Yellow Aetheria Chunk"), Have("Aetheria Desiccant"));
		return num + Math.Min(Have("Trophy"), val);
	}

	private static bool MkBankStep()
	{
		if (_mkWithdrawing)
		{
			CountEnlItems(now: true);
			if (Have("Enlightenment Token") > _mkTokBefore)
			{
				_mkWithdrawing = false;
				_mkNextAt = DateTime.Now.AddMilliseconds(600.0);
				return true;
			}
			if ((DateTime.Now - _mkWdSent).TotalSeconds > 12.0)
			{
				_mkWithdrawing = false;
				MkStop("the tokens from the bank didn't arrive");
				return true;
			}
			_mkStatus = "waiting for the tokens from the bank";
			return true;
		}
		if (!MkBank || (!MkFiun && !MkMedallions))
		{
			return false;
		}
		int num = Have("Enlightenment Token");
		int num2 = PartsPossible(MkParts) - num;
		if (MkStopAt > 0)
		{
			num2 = Math.Min(num2, MkStopAt - Have("Enlightenment Medallion") - num);
		}
		if (num2 <= 0)
		{
			return false;
		}
		long num3 = BankNum("Enlightenment Tokens");
		if (num3 <= 0)
		{
			return false;
		}
		if (!BankReady())
		{
			_mkStatus = "waiting for the bank";
			return true;
		}
		long n = Math.Min(num2, num3);
		_mkTokBefore = num;
		_mkWdSent = DateTime.Now;
		_mkWithdrawing = true;
		_mkStatus = "withdrawing " + n + " tokens";
		WithdrawTokens(n);
		return true;
	}

	// the luminance a coin costs: Session > Lum's buying rate
	private static double LumPerCoin()
	{
		return LumTrack.LumPerCoinBuy;
	}

	private static double LumPerCoinCached()
	{
		if ((DateTime.Now - _lpcAt).TotalSeconds > 60.0)
		{
			_lpcAt = DateTime.Now;
			_lpc = LumPerCoin();
		}
		return _lpc;
	}

	private static EnlPlanResult PlanTo(int cur, int n, int lvl, long lum, long tokens, long medals, long parts, long coins, double lpc)
	{
		EnlPlanResult enlPlanResult = new EnlPlanResult
		{
			Reach = n
		};
		long num = 0L;
		long num2 = 0L;
		long num3 = 0L;
		for (int i = cur + 1; i <= n; i++)
		{
			if (EnlUsesMedallions(i))
			{
				num2 += EnlTokensNeeded(i);
			}
			else
			{
				num += EnlTokensNeeded(i);
			}
			num3 += EnlLumNeeded(i);
		}
		long num4 = (enlPlanResult.Parts = (enlPlanResult.Medallions = Math.Max(0L, num2 - medals)));
		enlPlanResult.PartsShort = Math.Max(0L, num4 - parts);
		enlPlanResult.TokensShort = Math.Max(0L, (enlPlanResult.TokensUsed = num + num4) - tokens);
		enlPlanResult.BuyTokens = enlPlanResult.TokensShort;
		long num5 = coins - enlPlanResult.BuyTokens * 20;
		enlPlanResult.LumNeeded = num3;
		enlPlanResult.LumShort = ((lum >= 0) ? Math.Max(0L, num3 - lum) : 0);
		if (enlPlanResult.LumShort > 0 && lpc > 0.0)
		{
			enlPlanResult.SellCoins = (long)Math.Ceiling((double)enlPlanResult.LumShort / lpc);
			enlPlanResult.SellLum = (long)((double)enlPlanResult.SellCoins * lpc);
		}
		if (lvl > 0 && lvl < EnlLevelNeeded(n))
		{
			enlPlanResult.Possible = false;
			enlPlanResult.Stop = "level " + EnlLevelNeeded(n);
		}
		else if (enlPlanResult.PartsShort > 0)
		{
			enlPlanResult.Possible = false;
			enlPlanResult.Stop = "parts of a medallion";
		}
		else if (num5 < 0)
		{
			enlPlanResult.Possible = false;
			enlPlanResult.Stop = "tokens";
		}
		else if (enlPlanResult.LumShort > 0 && (lpc <= 0.0 || enlPlanResult.SellCoins > num5))
		{
			enlPlanResult.Possible = false;
			enlPlanResult.Stop = "luminance";
		}
		return enlPlanResult;
	}

	private static void PlanInputs(out int cur, out int lvl, out long lum, out long tokens, out long medals, out long parts, out long coins, out double lpc)
	{
		CountEnlItems(now: false);
		cur = EnlCount(out var _);
		lvl = 0;
		try
		{
			lvl = CoreManager.Current.CharacterFilter.Level;
		}
		catch
		{
		}
		lum = BankNum("Luminance");
		tokens = Have("Enlightenment Token") + Math.Max(0L, BankNum("Enlightenment Tokens"));
		medals = Have("Enlightenment Medallion");
		parts = PartsPossible(countMaking: true);
		coins = Math.Max(0L, BankNum("Enlightened Coins"));
		lpc = LumPerCoinCached();
	}

	public static EnlPlanResult EnlPlan(int target)
	{
		PlanInputs(out var cur, out var lvl, out var lum, out var tokens, out var medals, out var parts, out var coins, out var lpc);
		if (cur < 0)
		{
			return null;
		}
		if (target > cur)
		{
			return PlanTo(cur, target, lvl, lum, tokens, medals, parts, coins, lpc);
		}
		EnlPlanResult enlPlanResult = new EnlPlanResult
		{
			Reach = cur
		};
		for (int i = cur + 1; i < cur + 3000; i++)
		{
			EnlPlanResult enlPlanResult2 = PlanTo(cur, i, lvl, lum, tokens, medals, parts, coins, lpc);
			if (!enlPlanResult2.Possible)
			{
				enlPlanResult.Stop = enlPlanResult2.Stop;
				break;
			}
			enlPlanResult = enlPlanResult2;
		}
		return enlPlanResult;
	}

	public static List<string> EnlPlanLines(int target)
	{
		List<string> list = new List<string>();
		PlanInputs(out var cur, out var _, out var lum, out var tokens, out var _, out var parts, out var coins, out var lpc);
		if (cur < 0)
		{
			return list;
		}
		Func<long, string> func = (long v) => v.ToString("N0", EnlInv);
		EnlPlanResult enlPlanResult = EnlPlan(target);
		if (enlPlanResult == null)
		{
			return list;
		}
		bool flag = target > cur;
		if (flag)
		{
			list.Add("h|Up to " + target + " with coins:");
		}
		else
		{
			list.Add("h|As far as it goes, coins included:");
		}
		if (!flag)
		{
			if (enlPlanResult.Reach <= cur)
			{
				list.Add("r|Not even the next one" + ((enlPlanResult.Stop.Length > 0) ? (" - short of " + enlPlanResult.Stop) : ""));
				return list;
			}
			list.Add("g|Up to " + enlPlanResult.Reach + " (" + (enlPlanResult.Reach - cur) + " more)" + ((enlPlanResult.Stop.Length > 0) ? (" - then short of " + enlPlanResult.Stop) : ""));
		}
		else
		{
			list.Add(enlPlanResult.Possible ? "g|Possible" : ("r|Not yet - short of " + enlPlanResult.Stop));
		}
		if (enlPlanResult.Medallions > 0)
		{
			list.Add(((enlPlanResult.PartsShort > 0) ? "r|" : "g|") + "  Make " + func(enlPlanResult.Medallions) + " medallions (parts on you or makeable: " + func(parts) + ")");
		}
		list.Add(((enlPlanResult.TokensShort == 0L) ? "g|" : "n|") + "  Tokens: " + func(enlPlanResult.TokensUsed) + " (on you + bank: " + func(tokens) + ")");
		if (enlPlanResult.BuyTokens > 0)
		{
			list.Add(((enlPlanResult.BuyTokens * 20 <= coins) ? "g|" : "r|") + "  Buy " + func(enlPlanResult.BuyTokens) + " tokens = " + func(enlPlanResult.BuyTokens * 20) + " coins (banked " + func(coins) + ")");
		}
		if (enlPlanResult.LumNeeded > 0)
		{
			list.Add(((enlPlanResult.LumShort == 0L) ? "g|" : "n|") + "  Luminance: " + Lum(enlPlanResult.LumNeeded) + " (banked " + ((lum >= 0) ? Lum(lum) : "?") + ")");
		}
		if (enlPlanResult.SellCoins > 0)
		{
			list.Add(((enlPlanResult.Possible || enlPlanResult.Stop != "luminance") ? "g|" : "r|") + "  Sell " + func(enlPlanResult.SellCoins) + " coins for ~" + Lum(enlPlanResult.SellLum) + " luminance (at " + Lum((long)lpc) + " per coin)");
		}
		else if (enlPlanResult.LumShort > 0 && lpc <= 0.0)
		{
			list.Add("r|  Short " + Lum(enlPlanResult.LumShort) + " luminance (set the Coin-Lum rate in the luminance tracker to plan selling coins)");
		}
		long num = coins - enlPlanResult.BuyTokens * 20 - enlPlanResult.SellCoins;
		if (num > 0 && enlPlanResult.Possible)
		{
			list.Add("n|  Coins left over: " + func(num));
		}
		return list;
	}

	public static long TokensToBuyNeeded(int target)
	{
		EnlPlanResult enlPlanResult = EnlPlan(target);
		if (enlPlanResult == null)
		{
			return 0L;
		}
		long num = Math.Max(0L, BankNum("Enlightened Coins"));
		return Math.Min(enlPlanResult.BuyTokens, num / 20);
	}

	public static long TokensToBuyMax()
	{
		return Math.Max(0L, BankNum("Enlightened Coins")) / 20;
	}

	private static string EnlBankCommand(string arg)
	{
		if (arg.StartsWith("buy"))
		{
			string text = arg.Substring(3).Trim();
			long result;
			if (text == "" || text == "need")
			{
				result = TokensToBuyNeeded(AeTarget);
			}
			else if (text == "max")
			{
				result = TokensToBuyMax();
			}
			else if (!long.TryParse(text, out result))
			{
				return "Usage: /mtank enl buy need | max | <number>";
			}
			if (result < 1)
			{
				return (text == "max") ? "Buy tokens: not enough Enlightened Coins (or /bank not read yet)." : ("Buy tokens: none needed for " + ((AeTarget > 0) ? ("enlightenment " + AeTarget) : "the plan") + ".");
			}
			return BuyTokens(result);
		}
		if (arg.StartsWith("withdraw"))
		{
			string text2 = arg.Substring(8).Trim();
			long num = BankNum("Enlightenment Tokens");
			long result2;
			if (text2 == "" || text2 == "all")
			{
				result2 = num;
			}
			else if (!long.TryParse(text2, out result2))
			{
				return "Usage: /mtank enl withdraw [number | all]";
			}
			if (result2 < 1)
			{
				return "No tokens in the bank (or /bank not read yet).";
			}
			return WithdrawTokens(result2);
		}
		return null;
	}

	private static void DrawEnlBank()
	{
		if (!ImGui.CollapsingHeader("Tokens & coins###enlbank"))
		{
			return;
		}
		Vector4 vector = new Vector4(0.45f, 0.9f, 0.45f, 1f);
		Vector4 vector2 = new Vector4(1f, 0.5f, 0.45f, 1f);
		Vector4 vector3 = new Vector4(0.6f, 0.6f, 0.6f, 1f);
		foreach (string item in EnlPlanLines(AeTarget))
		{
			string text = item.Substring(0, 1);
			string s = item.Substring(2);
			Im.TextColored(text switch
			{
				"h" => Cyan, 
				"r" => vector2, 
				"g" => vector, 
				_ => vector3, 
			}, s);
		}
		Im.TextColored(vector3, "(target = auto enlighten's: " + ((AeTarget > 0) ? AeTarget.ToString() : "none - as far as it goes") + ")");
		long num = TokensToBuyNeeded(AeTarget);
		long num2 = TokensToBuyMax();
		long num3 = Math.Max(0L, BankNum("Enlightenment Tokens"));
		if (_buyLeft > 0 || _buyWaiting)
		{
			Im.TextColored(Yellow, "Buying tokens: " + _buyDone.ToString("N0", EnlInv) + " of " + _buyTotal.ToString("N0", EnlInv));
			ImGui.SameLine();
			if (ImGui.SmallButton("Stop##buystop"))
			{
				BuyStop("stopped");
			}
		}
		bool flag = TokenVendorOpen() && _buyLeft <= 0 && !_buyWaiting;
		if (!flag)
		{
			ImGui.BeginDisabled();
		}
		if (ImGui.Button("Buy what's needed (" + num + ")##buyneed") && num > 0)
		{
			Util.WriteToChat(BuyTokens(num));
		}
		ImGui.SameLine();
		if (ImGui.Button("Buy all the coins allow (" + num2 + ")##buymax") && num2 > 0)
		{
			Util.WriteToChat(BuyTokens(num2));
		}
		if (!flag)
		{
			ImGui.EndDisabled();
		}
		ImGui.SameLine();
		if (ImGui.Button("Withdraw " + num3 + " from the bank##wdall") && num3 > 0)
		{
			Util.WriteToChat(WithdrawTokens(num3));
		}
		ImGui.Checkbox("Medallion maker withdraws tokens from the bank##mkbank", ref MkBank);
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("When the maker has parts (or can make them) but not enough tokens on you, it takes them from the bank\n(/b w et N) before handing parts to Fiun or combining.");
		}
		if (!flag)
		{
			Im.TextColored(vector3, "Buy buttons: open the aug gem vendor (tokens are under its Misc list).");
		}
	}
}
