using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Text.RegularExpressions;
using Decal.Adapter.Wrappers;
using ImGuiNET;

namespace MelkTank;

public static class VTankImport
{
	public class Table
	{
		public List<string> Cols = new List<string>();

		public List<object[]> Rows = new List<object[]>();

		public int Col(string n)
		{
			return Cols.IndexOf(n);
		}
	}

	private class SetRow
	{
		public string Label;

		public string Key;

		public string Show;

		public bool Tick = true;

		public Action<Settings> Apply;
	}

	private static readonly Vector4 Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f);

	private static readonly Vector4 Yellow = new Vector4(1f, 0.85f, 0.3f, 1f);

	private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

	private static List<string> _files;

	private static int _pick = -1;

	private static string _activeFile = "";

	private static Dictionary<string, Table> _usd;

	private static string _readFile;

	private static string _readError;

	private static string _profileName = "";

	private static List<SetRow> _sets;

	private static string _done = "";

	private static string _senseDone = "";

	private static string _senseName = "Virindi Sense";

	private static string SensePath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), "Decal Plugins\\Virindi Sense\\patterns.txt");

	private static Dictionary<string, Table> ReadUsd(string path)
	{
		string[] array = File.ReadAllText(path).Replace("\r", "").Split('\n');
		int i = 0;
		int num = int.Parse(array[i++], Inv);
		Dictionary<string, Table> dictionary = new Dictionary<string, Table>(StringComparer.OrdinalIgnoreCase);
		for (int j = 0; j < num; j++)
		{
			string key = array[i++];
			dictionary[key] = ReadTable(array, ref i);
		}
		return dictionary;
	}

	private static Table ReadTable(string[] L, ref int i)
	{
		Table table = new Table();
		int num = int.Parse(L[i++], Inv);
		for (int j = 0; j < num; j++)
		{
			table.Cols.Add(L[i++]);
		}
		i += num;
		int num2 = int.Parse(L[i++], Inv);
		for (int k = 0; k < num2; k++)
		{
			object[] array = new object[num];
			for (int l = 0; l < num; l++)
			{
				string text = L[i++];
				if (text == "TABLE")
				{
					array[l] = ReadTable(L, ref i);
				}
				else
				{
					array[l] = L[i++];
				}
			}
			table.Rows.Add(array);
		}
		return table;
	}

	private static string S(object[] row, int c)
	{
		return (c >= 0 && c < row.Length) ? ((row[c] as string) ?? "") : "";
	}

	private static int I(object[] row, int c)
	{
		int result;
		return int.TryParse(S(row, c), NumberStyles.Integer, Inv, out result) ? result : 0;
	}

	private static bool B(object[] row, int c)
	{
		return string.Equals(S(row, c), "True", StringComparison.OrdinalIgnoreCase);
	}

	private static string VTankDir()
	{
		string path = "";
		try
		{
			path = Path.GetDirectoryName(typeof(VTankImport).Assembly.Location) ?? "";
		}
		catch
		{
		}
		List<string> list = new List<string>();
		try
		{
			list.Add(Path.GetFullPath(Path.Combine(path, "..\\..\\VirindiPlugins\\VirindiTank")));
		}
		catch
		{
		}
		list.Add("C:\\Games\\VirindiPlugins\\VirindiTank");
		list.Add("C:\\Program Files (x86)\\VirindiPlugins\\VirindiTank");
		list.Add("C:\\Program Files\\VirindiPlugins\\VirindiTank");
		foreach (string item in list)
		{
			if (Directory.Exists(item))
			{
				return item;
			}
		}
		return null;
	}

	private static void Scan()
	{
		_files = new List<string>();
		_activeFile = "";
		string text = VTankDir();
		if (text == null)
		{
			return;
		}
		string text2 = "";
		string text3 = "";
		try
		{
			text2 = Globals.Core.CharacterFilter.Name ?? "";
			text3 = Globals.Core.CharacterFilter.Server ?? "";
		}
		catch
		{
		}
		try
		{
			string[] files = Directory.GetFiles(text, "*.usd");
			foreach (string text4 in files)
			{
				string fileName = Path.GetFileName(text4);
				if (fileName.StartsWith("--" + text2 + "_" + text3, StringComparison.OrdinalIgnoreCase))
				{
					_files.Add(text4);
				}
			}
			_files.Sort(StringComparer.OrdinalIgnoreCase);
			string path = Path.Combine(text, text3 + "_" + text2 + ".cdf");
			if (File.Exists(path))
			{
				string[] array = File.ReadAllLines(path);
				if (array.Length > 1)
				{
					_activeFile = array[1].Trim();
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		_pick = -1;
		for (int j = 0; j < _files.Count; j++)
		{
			if (string.Equals(Path.GetFileName(_files[j]), _activeFile, StringComparison.OrdinalIgnoreCase))
			{
				_pick = j;
			}
		}
		if (_pick < 0 && _files.Count > 0)
		{
			_pick = 0;
		}
	}

	private static string ProfileLabel(string f)
	{
		string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(f);
		string text = "";
		string text2 = "";
		try
		{
			text = Globals.Core.CharacterFilter.Name ?? "";
			text2 = Globals.Core.CharacterFilter.Server ?? "";
		}
		catch
		{
		}
		string text3 = ((fileNameWithoutExtension.Length > ("--" + text + "_" + text2).Length) ? fileNameWithoutExtension.Substring(("--" + text + "_" + text2).Length).TrimStart('_') : "");
		return ((text3.Length == 0) ? "(default)" : text3) + (string.Equals(Path.GetFileName(f), _activeFile, StringComparison.OrdinalIgnoreCase) ? "  - in use" : "");
	}

	private static void Read(Settings s, string f)
	{
		_readFile = f;
		_readError = null;
		_usd = null;
		_sets = null;
		_done = "";
		try
		{
			_usd = ReadUsd(f);
		}
		catch (Exception ex)
		{
			_readError = "Couldn't read it: " + ex.Message;
			return;
		}
		string text = ProfileLabel(f).Replace("  - in use", "");
		_profileName = "VTank " + ((text == "(default)") ? (Globals.Core.CharacterFilter.Name ?? "") : text);
		_sets = SettingRows(s);
	}

	private static DmgType Elem(int v)
	{
		return v switch
		{
			0 => DmgType.Pierce, 
			1 => DmgType.Bludgeon, 
			2 => DmgType.Blade, 
			3 => DmgType.Acid, 
			4 => DmgType.Lightning, 
			5 => DmgType.Cold, 
			6 => DmgType.Fire, 
			9 => DmgType.Void, 
			_ => DmgType.Auto, 
		};
	}

	private static Dictionary<int, string> WeaponNames(Settings s, Table mons, Func<WorldObject, bool> addItem, out int missing)
	{
		Dictionary<int, string> dictionary = new Dictionary<int, string>();
		missing = 0;
		int c = mons.Col("WeaponToUse");
		int c2 = mons.Col("SecondaryEquip");
		HashSet<int> hashSet = new HashSet<int>();
		foreach (object[] row in mons.Rows)
		{
			int num = I(row, c);
			int num2 = I(row, c2);
			if (num > 0 || num < -1)
			{
				hashSet.Add(num);
			}
			if (num2 > 3 || num2 < 0)
			{
				hashSet.Add(num2);
			}
		}
		foreach (int id in hashSet)
		{
			WeaponItem weaponItem = s.Items.Find((WeaponItem x) => x.Id == id);
			if (weaponItem == null)
			{
				WorldObject worldObject = Globals.Core.WorldFilter[id];
				if (worldObject == null || !InPack(id))
				{
					missing++;
					continue;
				}
				try
				{
					addItem(worldObject);
				}
				catch
				{
				}
				weaponItem = s.Items.Find((WeaponItem x) => x.Id == id);
			}
			if (weaponItem != null)
			{
				dictionary[id] = weaponItem.Name;
			}
		}
		return dictionary;
	}

	private static bool InPack(int id) => InvCache.Has(id);

	private static List<MonsterRule> Monsters(Table t, Dictionary<int, string> wn)
	{
		List<MonsterRule> list = new List<MonsterRule>();
		int c = t.Col("MonsterName");
		int c2 = t.Col("AttackPriority");
		int c3 = t.Col("DamageType");
		int c4 = t.Col("WeaponToUse");
		int c5 = t.Col("SecondaryVuln");
		int c6 = t.Col("SecondaryEquip");
		int c7 = t.Col("PetDamageType");
		Dictionary<string, Slot> dictionary = new Dictionary<string, Slot>
		{
			{
				"Imperil",
				Slot.Imperil
			},
			{
				"Vuln",
				Slot.Vuln
			},
			{
				"Yield",
				Slot.Yield
			},
			{
				"GravityW",
				Slot.Gravity
			},
			{
				"Attack",
				Slot.Arc
			},
			{
				"Ring",
				Slot.Ring
			},
			{
				"Broadside",
				Slot.Broadside
			},
			{
				"Fester",
				Slot.Fester
			},
			{
				"WeakeningCurse",
				Slot.WeakeningCurse
			},
			{
				"FesteringCurse",
				Slot.FesteringCurse
			},
			{
				"Corruption",
				Slot.Corruption
			},
			{
				"DestructiveCurse",
				Slot.DestructiveCurse
			},
			{
				"Corrosion",
				Slot.Corrosion
			},
			{
				"Streak",
				Slot.Streak
			}
		};
		foreach (object[] row in t.Rows)
		{
			string text = S(row, c).Trim();
			if (text.Length == 0)
			{
				continue;
			}
			MonsterRule monsterRule = new MonsterRule((text == "<DEFAULT>") ? "<< DEFAULT >>" : text);
			monsterRule.Priority = I(row, c2);
			monsterRule.Dmg = Elem(I(row, c3));
			foreach (KeyValuePair<string, Slot> item in dictionary)
			{
				int num = t.Col(item.Key);
				if (num >= 0)
				{
					monsterRule.Slots[(int)item.Value] = B(row, num);
				}
			}
			int num2 = I(row, c4);
			monsterRule.Weapon = ((num2 == -1 || !wn.TryGetValue(num2, out var value)) ? "<AUTO>" : value);
			monsterRule.ExVuln = Elem(I(row, c5));
			int num3 = I(row, c6);
			ref string offhand = ref monsterRule.Offhand;
			string text2;
			if (num3 == 1)
			{
				text2 = "<AUTO SHIELD>";
			}
			else if (num3 == 3)
			{
				text2 = "<NONE>";
			}
			else
			{
				text2 = (((num3 > 3 || num3 < 0) && wn.TryGetValue(num3, out value)) ? value : "<AUTO>");
			}
			offhand = text2;
			monsterRule.PetDmg = Elem(I(row, c7));
			list.Add(monsterRule);
		}
		if (!list.Exists((MonsterRule x) => x.IsDefault))
		{
			list.Insert(0, new MonsterRule("<< DEFAULT >>"));
		}
		return list;
	}

	private static List<SetRow> SettingRows(Settings s)
	{
		List<SetRow> l = new List<SetRow>();
		if (_usd == null || !_usd.TryGetValue("Settings", out var value))
		{
			return l;
		}
		Dictionary<string, string> v = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
		foreach (object[] row in value.Rows)
		{
			string text = S(row, 0);
			if (text.Length > 0 && row.Length > 1 && row[1] is string)
			{
				v[text] = (string)row[1];
			}
		}
		Func<string, bool?> func = (string k) => v.TryGetValue(k, out var value2) ? new bool?(string.Equals(value2, "True", StringComparison.OrdinalIgnoreCase)) : ((bool?)null);
		Func<string, double?> func2 = (string k) => (v.TryGetValue(k, out var value2) && double.TryParse(value2, NumberStyles.Float, Inv, out var result)) ? new double?(result) : ((double?)null);
		Action<string, string, bool?, Func<bool>, Action<bool>> action = (string label, string key, bool? val, Func<bool> cur, Action<bool> set) =>
		{
			if (val.HasValue)
			{
				bool nv = val.Value;
				l.Add(new SetRow
				{
					Label = label,
					Key = key,
					Show = (nv ? "on" : "off") + ((cur() == nv) ? "  (same)" : ("  (now " + (cur() ? "on" : "off") + ")")),
					Tick = (cur() != nv),
					Apply = (Settings st) =>
					{
						set(nv);
					}
				});
			}
		};
		Action<string, string, double?, double, string, Func<double>, Action<double>> action2 = (string label, string key, double? val, double mul, string unit, Func<double> cur, Action<double> set) =>
		{
			if (val.HasValue)
			{
				double nv = Math.Round(val.Value * mul, 1);
				bool flag = Math.Abs(cur() - nv) < 0.05;
				l.Add(new SetRow
				{
					Label = label,
					Key = key,
					Show = nv.ToString("0.#", Inv) + unit + (flag ? "  (same)" : ("  (now " + cur().ToString("0.#", Inv) + unit + ")")),
					Tick = !flag,
					Apply = (Settings st) =>
					{
						set(nv);
					}
				});
			}
		};
		action("Combat", "CombatEnabled", func("EnableCombat"), () => s.CombatEnabled, (bool x) =>
		{
			s.CombatEnabled = x;
		});
		action("Navigation", "NavEnabled", func("EnableNav"), () => s.NavEnabled, (bool x) =>
		{
			s.NavEnabled = x;
		});
		action("Looting", "LootEnabled", func("EnableLooting"), () => s.LootEnabled, (bool x) =>
		{
			s.LootEnabled = x;
		});
		action("Buffing (buffer)", "MelksBufferEnabled", func("EnableBuffing"), () => s.MelksBufferEnabled, (bool x) =>
		{
			s.MelksBufferEnabled = x;
		});
		action("Summon pets", "MelksPetEnabled", func("SummonPets"), () => s.MelksPetEnabled, (bool x) =>
		{
			s.MelksPetEnabled = x;
		});
		action2("Attack range", "AttackRange", func2("AttackDistance"), 240.0, " m", () => s.AttackRange, (double x) =>
		{
			s.AttackRange = (float)x;
		});
		action2("Ring: monsters within", "RingRadius", func2("RingDistance"), 240.0, " m", () => s.RingRadius, (double x) =>
		{
			s.RingRadius = (float)x;
		});
		action2("Ring: at least this many monsters", "RingMinMonsters", func2("MinimumRingTargets"), 1.0, "", () => s.RingMinMonsters, (double x) =>
		{
			s.RingMinMonsters = (int)x;
		});
		double? num = func2("DebuffEachFirst");
		if (num.HasValue)
		{
			action("Debuff every monster before attacking", "DebuffAllFirst", num.Value != 0.0, () => s.DebuffAllFirst, (bool x) =>
			{
				s.DebuffAllFirst = x;
			});
		}
		action("Peace mode when idle", "PeaceWhenIdle", func("IdlePeaceMode"), () => s.PeaceWhenIdle, (bool x) =>
		{
			s.PeaceWhenIdle = x;
		});
		action("Stack items", "AutoStack", func("AutoStack"), () => s.AutoStack, (bool x) =>
		{
			s.AutoStack = x;
		});
		action("Loot fellows' kills too", "LootFellowKills", func("LootFellowCorpses"), () => s.LootFellowKills, (bool x) =>
		{
			s.LootFellowKills = x;
		});
		action2("Loot range", "LootRange", func2("CorpseApproachRange-Min"), 240.0, " m", () => s.LootRange, (double x) =>
		{
			s.LootRange = (float)x;
		});
		action("Open doors in the way", "NavOpenDoors", func("OpenDoors"), () => s.NavOpenDoors, (bool x) =>
		{
			s.NavOpenDoors = x;
		});
		action2("Door range", "NavDoorRange", func2("DoorOpenRange"), 240.0, " m", () => s.NavDoorRange, (double x) =>
		{
			s.NavDoorRange = (float)x;
		});
		action2("Nav point counts as reached within", "NavCloseDist", func2("NavCloseStopRange"), 240.0, " m", () => s.NavCloseDist, (double x) =>
		{
			s.NavCloseDist = (float)x;
		});
		double? num2 = func2("PetRangeMode");
		if (num2.HasValue)
		{
			action("Pets: own range", "PetRangeOverride", num2.Value == 1.0, () => s.PetRangeOverride, (bool x) =>
			{
				s.PetRangeOverride = x;
			});
		}
		action2("Pets: range", "PetRange", func2("PetCustomRange"), 240.0, " m", () => s.PetRange, (double x) =>
		{
			s.PetRange = (float)x;
		});
		action("Top up gear mana", "ManaTopUp", func("RefillWornMana"), () => s.ManaTopUp, (bool x) =>
		{
			s.ManaTopUp = x;
		});
		action2("Top up gear mana below", "ManaTopUpPercent", func2("RefillWornMana-Item-ManaPercent"), 1.0, " %", () => s.ManaTopUpPercent, (double x) =>
		{
			s.ManaTopUpPercent = (int)x;
		});
		return l;
	}

	private static int ImportAssist(Settings s, Func<WorldObject, bool> addItem, out int notFound)
	{
		notFound = 0;
		if (_usd == null || !_usd.TryGetValue("AssistItems", out var value))
		{
			return 0;
		}
		int num = 0;
		foreach (object[] row in value.Rows)
		{
			string name = S(row, 0).Trim();
			if (name.Length == 0 || name.StartsWith("[") || s.Items.Exists((WeaponItem x) => string.Equals(x.Name, name, StringComparison.OrdinalIgnoreCase)))
			{
				continue;
			}
			WorldObject worldObject = null;
			try
			{
				foreach (WorldObject item in Globals.Core.WorldFilter.GetInventory())
				{
					if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
					{
						worldObject = item;
						break;
					}
				}
			}
			catch
			{
			}
			if (worldObject == null)
			{
				notFound++;
				continue;
			}
			try
			{
				if (addItem(worldObject))
				{
					num++;
				}
			}
			catch
			{
			}
		}
		return num;
	}

	private static List<string> SensePatterns(out string err)
	{
		err = null;
		List<string> list = new List<string>();
		try
		{
			if (!File.Exists(SensePath))
			{
				err = "No Virindi Sense list at " + SensePath + ".";
				return list;
			}
			string[] array = File.ReadAllLines(SensePath);
			for (int i = 0; i < array.Length; i++)
			{
				string text = array[i].Trim();
				if (text.Length != 0 && (i != 0 || !int.TryParse(text, out var _)))
				{
					Match match = Regex.Match(text, "^\\^(.*)\\$$");
					if (match.Success && !Regex.IsMatch(match.Groups[1].Value, "[\\\\.*+?()\\[\\]{}|^$]"))
					{
						list.Add(match.Groups[1].Value);
					}
					else
					{
						list.Add("name#" + text);
					}
				}
			}
		}
		catch (Exception ex)
		{
			err = "Couldn't read it: " + ex.Message;
		}
		return list;
	}

	public static bool Draw(Settings s, Func<WorldObject, bool> addItem)
	{
		bool result = false;
		Im.TextColored(Grey, "Brings a Virindi Tank profile (monsters, settings, kits and weapons) and Virindi Sense's alerts into MelkTank.\nRun it on the character the profile belongs to - VTank keeps weapons as that character's item ids.");
		if (_files == null)
		{
			Scan();
		}
		ImGui.Separator();
		ImGui.TextUnformatted("Virindi Tank profile:");
		ImGui.SameLine();
		if (_files.Count == 0)
		{
			Im.TextColored(Grey, (VTankDir() == null) ? "Virindi Tank's folder wasn't found." : "none for this character.");
		}
		else
		{
			ImGui.SetNextItemWidth(240f);
			if (ImGui.BeginCombo("##vtprof", (_pick >= 0) ? ProfileLabel(_files[_pick]) : ""))
			{
				for (int i = 0; i < _files.Count; i++)
				{
					if (ImGui.Selectable(ProfileLabel(_files[i]) + "##vtp" + i, i == _pick))
					{
						_pick = i;
						_readFile = null;
					}
				}
				ImGui.EndCombo();
			}
		}
		ImGui.SameLine();
		if (ImGui.SmallButton("Look again##vtrescan"))
		{
			_files = null;
			_readFile = null;
			return false;
		}
		if (_pick >= 0 && _pick < _files.Count)
		{
			if (_readFile != _files[_pick])
			{
				Read(s, _files[_pick]);
			}
			if (_readError != null)
			{
				Im.TextColored(Yellow, _readError);
			}
			else if (_usd != null)
			{
				_usd.TryGetValue("MyMonsters", out var value);
				ImGui.TextUnformatted("Monsters: " + (value?.Rows.Count ?? 0) + "  - as a new monster profile named");
				ImGui.SameLine();
				ImGui.SetNextItemWidth(180f);
				ImGui.InputText("##vtpname", ref _profileName, 60u);
				ImGui.SameLine();
				if (ImGui.SmallButton("Import monsters##vtimpm") && value != null)
				{
					Dictionary<int, string> wn = WeaponNames(s, value, addItem, out var missing);
					string text = s.SaveMonsterProfile(_profileName, Monsters(value, wn));
					_done = ((text == null) ? "Couldn't save the monster profile." : ("Monster profile '" + text + "' made (" + value.Rows.Count + " monsters) - pick it on the Monsters tab." + ((missing > 0) ? (" " + missing + " weapon(s) the rows use aren't in your pack: those rows use <AUTO>.") : "")));
					Util.WriteToChat("VTank import: " + _done);
					result = true;
				}
				Tip("Every row with its priority, damage type, the debuff / attack columns (I V Y G B F, arc, ring, streak, WC FC Cp DC Cs),\nsecondary vuln, offhand and pet damage. Weapons are looked up in your pack and put on the Items list.\nNothing of yours is changed: it's a new profile.");
				if (_sets != null && _sets.Count > 0)
				{
					ImGui.TextUnformatted("Settings with a MelkTank match (ticked ones are changed):");
					if (ImGui.BeginTable("##vtsets", 3, ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
					{
						foreach (SetRow set in _sets)
						{
							ImGui.TableNextRow();
							ImGui.TableSetColumnIndex(0);
							ImGui.Checkbox("##vts" + set.Key, ref set.Tick);
							ImGui.TableSetColumnIndex(1);
							ImGui.TextUnformatted(set.Label);
							ImGui.TableSetColumnIndex(2);
							Im.TextColored(set.Show.Contains("(same)") ? Grey : Yellow, set.Show);
						}
						ImGui.EndTable();
					}
					if (ImGui.SmallButton("Apply the ticked settings##vtapply"))
					{
						int num = 0;
						foreach (SetRow set2 in _sets)
						{
							if (set2.Tick)
							{
								try
								{
									set2.Apply(s);
									num++;
								}
								catch
								{
								}
							}
						}
						_sets = SettingRows(s);
						_done = num + " setting(s) changed.";
						Util.WriteToChat("VTank import: " + _done);
						result = true;
					}
				}
				if (ImGui.SmallButton("Add its kits / mana stones / lockpicks to Items##vtassist"))
				{
					_done = ImportAssist(s, addItem, out var notFound) + " item(s) added to the Items list" + ((notFound > 0) ? (", " + notFound + " not in your pack") : "") + ".";
					Util.WriteToChat("VTank import: " + _done);
					result = true;
				}
				Tip("VTank's Assist Items (health / mana kits, mana charges, lockpicks) - found in your pack by name.");
				if (_done.Length > 0)
				{
					Im.TextColored(Grey, _done);
				}
			}
		}
		ImGui.Separator();
		DrawSense(s);
		return result;
	}

	public static bool DrawSense(Settings s)
	{
		ImGui.TextUnformatted("Import Virindi Sense alerts as the tracking profile");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(160f);
		ImGui.InputText("##vsname", ref _senseName, 60u);
		ImGui.SameLine();
		if (ImGui.SmallButton("Import##vsimp"))
		{
			List<string> list = SensePatterns(out var err);
			if (err != null)
			{
				_senseDone = err;
			}
			else
			{
				int num = Settings.AddToTrackProfile(_senseName, list, out var used);
				_senseDone = ((num < 0) ? "Couldn't write the tracking profile." : ("Item profile '" + used + "': " + num + " of " + list.Count + " alert(s) added" + ((num < list.Count) ? " (the rest were there already)" : "") + " - pick it on Tracking > List."));
			}
			Util.WriteToChat("Virindi Sense import: " + _senseDone);
		}
		Tip("Virindi Sense's list (patterns.txt) as an Tracking > List profile (made, or added to if it's there) - your own list isn't changed.\nTracking alerts when an item, NPC, portal or monster with a matching name shows up.\n\"^Name$\" becomes an exact name, anything else a part of the name.");
		if (_senseDone.Length > 0)
		{
			Im.TextColored(Grey, _senseDone);
		}
		return false;
	}

	private static void Tip(string t)
	{
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip(t);
		}
	}
}
