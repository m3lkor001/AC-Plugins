#if !RETAIL
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using ACGodot.DecalShim;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using MelkTank.Loot;
using MelkTank.Metas;

namespace MelkTank;

/// <summary>
/// UtilityBelt's other commands (https://utilitybelt.gitlab.io/docs/command-line), for ACGodot - which has no
/// UtilityBelt. UbCmd does use / select / give / face / jump / vendor / combatstate / fellow / resolution / mexec; this
/// does the rest MelkTank has something for. Client tweaks (getui, textures, videopatch, frame limits ...), Lifestoned,
/// broadcasting to other clients and the like aren't here.
/// </summary>
public static class UbMore
{
	private static readonly string[] Help =
	{
		"help [command]", "date[utc] [format]", "delay <ms> <command>", "closestportal", "portal[p] <name>",
		"follow[p] <name>", "pos", "id", "propertydump", "vitae", "close corpse", "logout", "myquests",
		"dumpskills", "fellow create <name>", "ig[p] <profile> to <name>", "autovendor <profile|cancel>",
		"xp", "autosalvage", "autostack", "autocram", "count item <name> | profile <profile> | player <range> [think]",
		"chatfilter <recharge|otherscast|youcast|misc|attackonyou|attackontarget|all|test> <true|false>",
		"quests check <flag>", "listvars | listpvars | listgvars",
		"(and: use, select, give, face, jump, vendor, combatstate, fellow, resolution, mexec)"
	};

	private static readonly List<KeyValuePair<DateTime, string>> _delayed = new List<KeyValuePair<DateTime, string>>();

	private static bool _hooked;

	/// <summary>Handles one UB command (verb in lower case, rest as typed). False: not one of these.</summary>
	public static bool Try(string verb, string rest)
	{
		switch (verb)
		{
		case "help":
			Say("MelkTank b" + BuildInfo.Number + " - UB commands done here:\n  /ub " + string.Join("\n  /ub ", Help));
			return true;
		case "date":
		case "dateutc":
		{
			DateTime d = (verb == "dateutc") ? DateTime.UtcNow : DateTime.Now;
			string text;
			try
			{
				text = (rest.Length > 0) ? d.ToString(rest, CultureInfo.InvariantCulture) : d.ToString(CultureInfo.InvariantCulture);
			}
			catch (FormatException)
			{
				text = d.ToString(CultureInfo.InvariantCulture) + " (bad format: " + rest + ")";
			}
			Say("Current Date" + ((verb == "dateutc") ? " (UTC)" : "") + ": " + text);
			return true;
		}
		case "delay":
			return Delay(rest);
		case "closestportal":
			return ClosestPortal();
		case "portal":
		case "portalp":
			return UbCmd.Try("/ub use" + ((verb == "portalp") ? "p" : "") + " " + rest);
		case "follow":
		case "followp":
			return Follow(rest, verb == "followp");
		case "pos":
			return Pos();
		case "id":
		{
			WorldObject o = Selected();
			Say((o == null) ? "Nothing selected." : (o.Name + ": " + o.Id + " (0x" + o.Id.ToString("X8") + ")"));
			return true;
		}
		case "propertydump":
			try
			{
				MelkTank.Pets.ObjectDump.DumpSelected();
			}
			catch (Exception ex)
			{
				Say("propertydump: " + ex.Message);
			}
			return true;
		case "vitae":
			Think("My vitae is " + Math.Max(0, CoreManager.Current.CharacterFilter.Vitae) + "%");
			return true;
		case "close":
			if (rest.Trim().Equals("corpse", StringComparison.OrdinalIgnoreCase))
			{
				Bridge.Host?.Net?.CloseContainer();
				return true;
			}
			return false;
		case "logout":
			CoreManager.Current.Actions.Logout();
			return true;
		case "myquests":
			ExprQuests.RefreshQuiet();
			return true;
		case "dumpskills":
			return DumpSkills();
		case "fellow":
		{
			// (UbCmd does the other fellow commands; only create comes here)
			Match m = Regex.Match(rest, "^create\\s+(?<n>.+)$", RegexOptions.IgnoreCase);
			if (!m.Success)
			{
				return false;
			}
			Bridge.Host?.Net?.CreateFellowship(m.Groups["n"].Value.Trim(), true);
			return true;
		}
		case "ig":
		case "igp":
			ItemGiver.Command(rest, verb == "igp");
			return true;
		case "autovendor":
			return AutoVendor(rest);
		case "xp":
			Session.AttrSpendNow();
			return true;
		case "autosalvage":
		{
			CombatEngine e = PluginCore.CurrentEngine;
			if (e?.Salvage == null)
			{
				return true;
			}
			e.Salvage.OnceUntil = DateTime.Now.AddMinutes(2.0);
			Say("autosalvage: salvaging what's waiting (" + Salvager.Waiting.Count + " item" + ((Salvager.Waiting.Count == 1) ? "" : "s") + ").");
			return true;
		}
		case "autostack":
		{
			CombatEngine e = PluginCore.CurrentEngine;
			if (e?.Stacker != null)
			{
				e.Stacker.OnceUntil = DateTime.Now.AddSeconds(30.0);
				Say("autostack: stacking.");
			}
			return true;
		}
		case "autocram":
			PackOrganizer.RunNow();
			Say("autocram: organizing the packs (the Packs tab's rules).");
			return true;
		case "count":
			return Count(rest);
		case "chatfilter":
			return ChatFilter(rest);
		case "quests":
			return Quests(rest);
		case "listvars":
			return ListVars("Variables", Expr.SessionVars);
		case "listpvars":
			return ListVars("Persistent variables", Expr.PVars);
		case "listgvars":
			return ListVars("Global variables", Expr.GVarsHere);
		}
		return false;
	}

	// ── helpers ──

	private static void Say(string text)
	{
		Util.WriteToChat(text);
	}

	/// <summary>"Thinks to yourself": a tell to yourself, as UB does.</summary>
	private static void Think(string text)
	{
		string me = CoreManager.Current.CharacterFilter.Name ?? "";
		if (me.Length == 0)
		{
			Say(text);
			return;
		}
		Util.Command("/tell " + me + ", " + text);
	}

	private static WorldObject Selected()
	{
		int id = CoreManager.Current.Actions.CurrentSelection;
		return (id == 0) ? null : CoreManager.Current.WorldFilter[id];
	}

	private static double MetresTo(WorldObject o)
	{
		try
		{
			return CombatEngine.Distance(o);
		}
		catch
		{
			return double.MaxValue;
		}
	}

	// ── delay ──

	private static bool Delay(string rest)
	{
		Match m = Regex.Match(rest, "^(?<ms>\\d+)\\s+(?<cmd>.+)$");
		if (!m.Success)
		{
			Say("Usage: /ub delay <milliseconds> <command>");
			return true;
		}
		_delayed.Add(new KeyValuePair<DateTime, string>(DateTime.Now.AddMilliseconds(double.Parse(m.Groups["ms"].Value, CultureInfo.InvariantCulture)), m.Groups["cmd"].Value.Trim()));
		if (!_hooked)
		{
			CoreManager.Current.RenderFrame += OnFrame;
			_hooked = true;
		}
		return true;
	}

	private static void OnFrame(object sender, EventArgs e)
	{
		if (_delayed.Count == 0)
		{
			return;
		}
		DateTime now = DateTime.Now;
		for (int i = 0; i < _delayed.Count; i++)
		{
			if (_delayed[i].Key <= now)
			{
				string cmd = _delayed[i].Value;
				_delayed.RemoveAt(i--);
				try
				{
					Util.Command(cmd);
				}
				catch (Exception ex)
				{
					Util.LogError(ex);
				}
			}
		}
	}

	// ── moving about ──

	private static bool ClosestPortal()
	{
		WorldObject best = null;
		double bestD = double.MaxValue;
		foreach (WorldObject o in CoreManager.Current.WorldFilter.GetLandscape())
		{
			if (o.ObjectClass != ObjectClass.Portal)
			{
				continue;
			}
			double d = MetresTo(o);
			if (d < bestD)
			{
				best = o;
				bestD = d;
			}
		}
		if (best == null)
		{
			Say("closestportal: no portal in sight.");
			return true;
		}
		CoreManager.Current.Actions.SelectItem(best.Id);
		CoreManager.Current.Actions.UseItem(best.Id, 0);
		return true;
	}

	private static bool Follow(string rest, bool partial)
	{
		string name = rest.Trim();
		if (name.Length == 0)
		{
			Say("Usage: /ub follow[p] <name>");
			return true;
		}
		WorldObject who = null;
		foreach (WorldObject o in CoreManager.Current.WorldFilter.GetLandscape())
		{
			if (o.ObjectClass == ObjectClass.Player && (partial ? (o.Name.IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0) : o.Name.Equals(name, StringComparison.OrdinalIgnoreCase)) && (who == null || MetresTo(o) < MetresTo(who)))
			{
				who = o;
			}
		}
		string target = (who != null) ? who.Name : name;
		SettingsTools.Set("FollowName", target, "");
		SettingsTools.Set("NavMode", "2", "");
		SettingsTools.Set("NavEnabled", "on", "");
		Say("follow: following " + target + (who == null ? " (not in sight yet)" : "") + " - Nav is on, in follow mode.");
		return true;
	}

	// ── looking at things ──

	private static bool Pos()
	{
		WorldObject o = Selected() ?? CoreManager.Current.WorldFilter[CoreManager.Current.CharacterFilter.Id];
		if (o == null)
		{
			Say("pos: nothing selected.");
			return true;
		}
		CoordsObject c = o.Coordinates();
		Vector3Object r = o.RawCoordinates();
		int cell = 0;
		try
		{
			cell = o.Values(LongValueKey.Landblock);
		}
		catch
		{
		}
		Say(o.Name + ": " + ((c != null) ? (FormatNs(c.NorthSouth) + ", " + FormatEw(c.EastWest)) : "?") + "  cell 0x" + cell.ToString("X8") + ((r != null) ? ("  [" + r.X.ToString("0.00", CultureInfo.InvariantCulture) + " " + r.Y.ToString("0.00", CultureInfo.InvariantCulture) + " " + r.Z.ToString("0.00", CultureInfo.InvariantCulture) + "]") : "") + "  " + MetresTo(o).ToString("0.0", CultureInfo.InvariantCulture) + " m away");
		return true;
	}

	private static string FormatNs(double v)
	{
		return Math.Abs(v).ToString("0.00", CultureInfo.InvariantCulture) + ((v >= 0.0) ? "N" : "S");
	}

	private static string FormatEw(double v)
	{
		return Math.Abs(v).ToString("0.00", CultureInfo.InvariantCulture) + ((v >= 0.0) ? "E" : "W");
	}

	private static bool DumpSkills()
	{
		List<string> lines = new List<string>();
		foreach (CharFilterSkillType t in Enum.GetValues(typeof(CharFilterSkillType)))
		{
			try
			{
				SkillInfoWrapper s = CoreManager.Current.CharacterFilter.Skills[t];
				if (s == null || string.IsNullOrEmpty(s.Name) || s.Training == TrainingType.Unusable)
				{
					continue;
				}
				lines.Add(s.Name + ": " + s.Training + " " + s.Current);
			}
			catch
			{
			}
		}
		Say((lines.Count == 0) ? "dumpskills: no skills read." : ("Skills:\n  " + string.Join("\n  ", lines.ToArray())));
		return true;
	}

	// ── vendors ──

	private static bool AutoVendor(string rest)
	{
		VendorRun v = PluginCore.CurrentEngine?.Vendor;
		if (v == null)
		{
			return true;
		}
		string arg = rest.Trim();
		if (arg.Equals("cancel", StringComparison.OrdinalIgnoreCase))
		{
			v.Abort("cancelled (/ub autovendor cancel)");
			return true;
		}
		Vendor open = CoreManager.Current.WorldFilter.OpenVendor;
		WorldObject npc = (open != null) ? CoreManager.Current.WorldFilter[open.MerchantId] : null;
		if (npc == null)
		{
			Say("autovendor: open a vendor first (or /mt vendor <NPC> [/ profile]).");
			return true;
		}
		v.Start(npc.Name, (arg.Length > 0) ? Path.GetFileNameWithoutExtension(arg) : "", dry: false);
		return true;
	}

	// ── counting ──

	private static bool Count(string rest)
	{
		bool think = Regex.IsMatch(rest, "\\bthink\\s*$", RegexOptions.IgnoreCase);
		string text = Regex.Replace(rest, "\\s+(debug|think)\\b", "", RegexOptions.IgnoreCase).Trim();
		Match m = Regex.Match(text, "^(?<k>item|profile|player)\\s+(?<a>.+)$", RegexOptions.IgnoreCase);
		if (!m.Success)
		{
			Say("Usage: /ub count item <name> | profile <loot profile> | player <range> [think]");
			return true;
		}
		string kind = m.Groups["k"].Value.ToLowerInvariant();
		string arg = m.Groups["a"].Value.Trim();
		string answer;
		if (kind == "player")
		{
			double range;
			if (!double.TryParse(arg, NumberStyles.Float, CultureInfo.InvariantCulture, out range))
			{
				range = 50.0;
			}
			int me = CoreManager.Current.CharacterFilter.Id;
			int n = CoreManager.Current.WorldFilter.GetLandscape().Count((WorldObject o) => o.ObjectClass == ObjectClass.Player && o.Id != me && MetresTo(o) <= range);
			answer = n + " player" + ((n == 1) ? "" : "s") + " within " + range.ToString("0", CultureInfo.InvariantCulture) + " m";
		}
		else if (kind == "item")
		{
			Regex rx = null;
			try
			{
				rx = new Regex("^" + arg + "$", RegexOptions.IgnoreCase);
			}
			catch
			{
			}
			int n = 0;
			foreach (WorldObject o in InvCache.All())
			{
				if ((rx != null) ? rx.IsMatch(o.Name) : o.Name.Equals(arg, StringComparison.OrdinalIgnoreCase))
				{
					n += Math.Max(1, o.Values(LongValueKey.StackCount, 1));
				}
			}
			answer = "I have " + n + " " + arg;
		}
		else
		{
			string file = ItemGiver.FindProfile(arg);
			if (file == null)
			{
				Say("count: no loot profile " + arg + " (in " + string.Join(", ", ItemGiver.Folders()) + ")");
				return true;
			}
			UtlProfile p = UtlProfile.Load(file);
			int n = 0;
			foreach (WorldObject o in InvCache.All())
			{
				UtlRule r = LootMatcher.FirstMatch(p, o);
				if (r != null && r.Act != "0")
				{
					n += Math.Max(1, o.Values(LongValueKey.StackCount, 1));
				}
			}
			answer = "I have " + n + " items matching " + Path.GetFileNameWithoutExtension(file);
		}
		if (think)
		{
			Think(answer);
		}
		else
		{
			Say(answer);
		}
		return true;
	}

	// ── chat filters (UB's groups mapped onto MelkTank's Chat filter tab) ──

	private static readonly Dictionary<string, string[]> FilterGroups = new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase)
	{
		["recharge"] = new string[2] { "givetake", "healself" },
		["otherscast"] = new string[2] { "otherscast", "otherssay" },
		["youcast"] = new string[2] { "youcast", "yousay" },
		["misc"] = new string[3] { "fizzle", "comps", "expired" },
		["attackonyou"] = new string[4] { "dmgin", "dmgspellin", "evadein", "resistin" },
		["attackontarget"] = new string[3] { "dmgout", "evadeout", "resistout" }
	};

	private static bool ChatFilter(string rest)
	{
		Settings s = PluginCore.CurrentSettings;
		string[] a = rest.Trim().Split(new char[1] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
		if (s == null || a.Length == 0)
		{
			Say("Usage: /ub chatfilter <recharge|otherscast|youcast|misc|attackonyou|attackontarget|all|test> <true|false>");
			return true;
		}
		HashSet<string> on = new HashSet<string>((s.ChatFilterOn ?? "").Split(new char[1] { ',' }, StringSplitOptions.RemoveEmptyEntries), StringComparer.OrdinalIgnoreCase);
		if (a[0].Equals("test", StringComparison.OrdinalIgnoreCase))
		{
			Say("Chat filters on: " + ((on.Count == 0) ? "none" : string.Join(", ", on.OrderBy((string x) => x).ToArray())));
			return true;
		}
		bool value = a.Length < 2 || a[1].Equals("true", StringComparison.OrdinalIgnoreCase) || a[1].Equals("on", StringComparison.OrdinalIgnoreCase);
		IEnumerable<string> keys;
		if (a[0].Equals("all", StringComparison.OrdinalIgnoreCase))
		{
			keys = FilterGroups.Values.SelectMany((string[] x) => x);
		}
		else if (FilterGroups.TryGetValue(a[0], out var g))
		{
			keys = g;
		}
		else
		{
			Say("chatfilter: no group " + a[0] + " - recharge, otherscast, youcast, misc, attackonyou, attackontarget, all, test");
			return true;
		}
		foreach (string k in keys)
		{
			if (value)
			{
				on.Add(k);
			}
			else
			{
				on.Remove(k);
			}
		}
		s.ChatFilterOn = string.Join(",", on.ToArray());
		SettingsTools.Set("ChatFilterOn", s.ChatFilterOn, "");
		Say("chatfilter: " + a[0] + " " + (value ? "filtered" : "shown"));
		return true;
	}

	// ── quests and variables ──

	private static bool Quests(string rest)
	{
		Match m = Regex.Match(rest, "^check\\s+(?<f>\\S+)", RegexOptions.IgnoreCase);
		if (!m.Success)
		{
			Say("Usage: /ub quests check <questFlag>");
			return true;
		}
		string f = m.Groups["f"].Value;
		if (!ExprQuests.Has(f))
		{
			Think("Quest " + f + ": not started (or /myquests not read yet)");
			return true;
		}
		int solves = ExprQuests.Solves(f);
		int max = ExprQuests.MaxSolves(f);
		Think("Quest " + f + ": " + solves + ((max > 0) ? ("/" + max) : "") + " solves, " + (ExprQuests.Ready(f) ? "ready" : "not ready yet"));
		return true;
	}

	private static bool ListVars(string what, IEnumerable<KeyValuePair<string, object>> vars)
	{
		List<string> lines = (vars ?? Enumerable.Empty<KeyValuePair<string, object>>()).OrderBy((KeyValuePair<string, object> v) => v.Key).Select((KeyValuePair<string, object> v) => v.Key + " = " + Expr.Str(v.Value)).ToList();
		Say(what + ((lines.Count == 0) ? ": none" : (":\n  " + string.Join("\n  ", lines.ToArray()))));
		return true;
	}
}
#endif
