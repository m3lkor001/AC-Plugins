using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
#if !RETAIL
using ACGodot.DecalShim;
using ACGodot.Plugins;
using ACGodot.UI;
#endif
#if !RETAIL
using AcClient;
#else
using SmartBox = AcClient.SmartBox;
using ACCmdInterp = AcClient.ACCmdInterp;
using CommandInterpreter = AcClient.CommandInterpreter;
using CommandListElement = AcClient.CommandListElement;
using CPhysicsObj = AcClient.CPhysicsObj;
using Position = AcClient.Position;
using CTransition = AcClient.CTransition;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
#if !RETAIL
using Godot;
#endif
using ImGuiNET;
using MelkTank.Loot;
using MelkTank.Metas;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public partial class Nav
{
	public void MetaCommand(string cmd)
	{
		cmd = (cmd ?? "").Trim();
		if (cmd.Length != 0)
		{
			MLog("send " + cmd);
			if (!MtCommand(cmd) && !VtCommand(cmd))
			{
				Util.Command(cmd);
			}
		}
	}

	public bool MtCommand(string cmd)
	{
		string text = (cmd ?? "").Trim();
		if (_s == null || (!_s.MtCommands && false))
		{
			return false;
		}
		if (!text.StartsWith("/mt ", StringComparison.OrdinalIgnoreCase) && !text.StartsWith("@mt ", StringComparison.OrdinalIgnoreCase))
		{
			return false;
		}
		string text2 = text.Substring(4).Trim();
		int num = text2.IndexOf(' ');
		string text3 = ((num < 0) ? text2 : text2.Substring(0, num)).ToLowerInvariant();
		string text4 = ((num < 0) ? "" : text2.Substring(num + 1).Trim());
		if (text3.StartsWith("use") || text3.StartsWith("give") || text3.StartsWith("select") || text3.StartsWith("jump") || text3 == "face" || text3 == "combatstate" || text3 == "fellow")
		{
			MLog("/mt -> /ub " + text2);
			Util.Command("/ub " + text2);
			return true;
		}
		if (text3.StartsWith("drop"))
		{
			bool flag = text3.Substring(4).Contains("p");
			WorldObject worldObject = null;
			foreach (WorldObject item in Globals.Core.WorldFilter.GetInventory())
			{
				string text5 = item.Name ?? "";
				if (flag ? (text5.IndexOf(text4, StringComparison.OrdinalIgnoreCase) >= 0) : string.Equals(text5, text4, StringComparison.OrdinalIgnoreCase))
				{
					worldObject = item;
					break;
				}
			}
			if (worldObject == null)
			{
				MLog("/mt " + text3 + ": no " + text4 + " in the pack");
				return true;
			}
			MLog("/mt " + text3 + ": dropping " + worldObject.Name);
			Globals.Core.Actions.DropItem(worldObject.Id);
			return true;
		}
		if (text3 == "click")
		{
			bool flag2 = !text4.StartsWith("n", StringComparison.OrdinalIgnoreCase);
			if ((DateTime.UtcNow - Remote.LastConfirmUtc).TotalSeconds < 15.0)
			{
				if (flag2)
				{
					Remote.ClickConfirmYes();
				}
				else
				{
					Remote.AnswerConfirm(yes: false);
				}
			}
			else if (flag2)
			{
				Remote.ExpectYes(10.0, null);
			}
			MLog("/mt click " + (flag2 ? "yes" : "no"));
			return true;
		}
		bool flag3 = true;
		return false;
	}

	public bool VtCommand(string cmd)
	{
		string text = cmd.Trim();
		if (!text.StartsWith("/vt ", StringComparison.OrdinalIgnoreCase) && !text.StartsWith("@vt ", StringComparison.OrdinalIgnoreCase))
		{
			return false;
		}
		string text2 = text.Substring(4).Trim();
		string text3 = text2.ToLowerInvariant();
		if (text3.StartsWith("jump"))
		{
			string[] array = text2.Split(new char[1] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
			string text4 = array[0].ToLowerInvariant();
			string text5 = "";
			string text6 = "";
			bool flag = text4.Substring(4).Contains("s");
			for (int i = 1; i < array.Length; i++)
			{
				string text7 = array[i].ToLowerInvariant();
				if (text7 == "true")
				{
					flag = true;
				}
				else if (!(text7 == "false"))
				{
					if (text5.Length == 0 && i == 1)
					{
						text5 = text7;
					}
					else
					{
						text6 = text7;
					}
				}
			}
			string text8 = text4.Substring(4).Replace("s", "");
			if (text8.IndexOfAny(new char[4] { 'w', 'x', 'z', 'c' }) < 0)
			{
				text8 = "w";
			}
			string text9 = "/ub jump" + (flag ? "s" : "") + text8 + ((text5.Length > 0) ? (" " + text5) : "") + ((text6.Length > 0) ? (" " + text6) : "");
			if (text5.Length > 0 && text6.Length == 0)
			{
				text9 += " 0";
			}
			if (UbCmd.Try(text9, ours: true))
			{
				return true;
			}
		}
		if (text3.StartsWith("setmetastate "))
		{
			GoState(text2.Substring(13).Trim());
			return true;
		}
		if (text3.StartsWith("opt set "))
		{
			string[] array2 = text2.Substring(8).Trim().Split(new char[1] { ' ' }, 2);
			OptSet(array2[0], (array2.Length > 1) ? array2[1] : "");
			return true;
		}
		if (text3.StartsWith("nav load "))
		{
			string n = text2.Substring(9).Trim();
			NavRoute navRoute = _s.NavRoutes.Find((NavRoute x) => string.Equals(x.Name, n, StringComparison.OrdinalIgnoreCase));
			if (navRoute == null)
			{
				Util.WriteToChat("Meta: no route called " + n + " (Nav > Routes).");
				return true;
			}
			if (_s.NavEnabled && _s.NavMode == 1 && string.Equals(_s.NavRouteSelected, navRoute.Name, StringComparison.OrdinalIgnoreCase) && _metaRoute == null)
			{
				MLog("route " + navRoute.Name + " already running - left as it is");
				return true;
			}
			_s.NavRouteSelected = navRoute.Name;
			_s.NavMode = 1;
			Stop();
			RouteReset();
			if (SaveAll != null)
			{
				SaveAll();
			}
			return true;
		}
		if (text3.StartsWith("nav spot "))
		{
			string n2 = text2.Substring(9).Trim();
			NavSpot navSpot = _s.NavSpots.Find((NavSpot x) => string.Equals(x.Name, n2, StringComparison.OrdinalIgnoreCase));
			if (navSpot == null)
			{
				Util.WriteToChat("Meta: no spot called " + n2 + " (Nav > Spots).");
				return true;
			}
			_metaRoute = null;
			_s.NavSelected = navSpot.Name;
			_s.NavMode = 0;
			Stop();
			if (SaveAll != null)
			{
				SaveAll();
			}
			MLog("spot " + navSpot.Name);
			return true;
		}
		if (text3.StartsWith("addnavpt"))
		{
			Match match = AddPtRx.Match(text2.Substring(8));
			if (!match.Success)
			{
				MWarn("addnavpt", "couldn't read the coordinates in: " + cmd);
				return true;
			}
			double nS = double.Parse(match.Groups[1].Value, CultureInfo.InvariantCulture) * (double)((!(match.Groups[2].Value.ToUpperInvariant() == "S")) ? 1 : (-1));
			double eW = double.Parse(match.Groups[3].Value, CultureInfo.InvariantCulture) * (double)((!(match.Groups[4].Value.ToUpperInvariant() == "W")) ? 1 : (-1));
			double result = 0.0;
			if (match.Groups[5].Success)
			{
				double.TryParse(match.Groups[5].Value, NumberStyles.Float, CultureInfo.InvariantCulture, out result);
			}
			if (_metaRoute == null || !string.Equals(_s.NavRouteSelected, _metaRoute.Name, StringComparison.Ordinal))
			{
				_metaRoute = new NavRoute
				{
					Name = "[meta] points",
					Mode = 2
				};
				_s.NavRouteSelected = _metaRoute.Name;
			}
			bool flag2 = RouteEmpty();
			_metaRoute.Steps.Add(new RouteStep
			{
				Kind = StepKind.Point,
				NS = nS,
				EW = eW,
				Z = 0.0
			});
			_s.NavMode = 1;
			if (flag2)
			{
				Stop();
				RouteReset();
			}
			MLog("point added " + nS.ToString("0.00") + ", " + eW.ToString("0.00") + " (" + _metaRoute.Steps.Count + " in the route)");
			return true;
		}
		if (text3.StartsWith("mexec "))
		{
			UbExpr.Eval(text2.Substring(6).Trim(), out var error);
			if (error != null)
			{
				MWarn("mexec:" + text2, "expression error in /vt mexec: " + error);
			}
			return true;
		}
		if (text3 == "nav clear")
		{
			_metaRoute = null;
			_s.NavRouteSelected = "";
			Stop();
			RouteReset();
			return true;
		}
		if (text3.StartsWith("meta load "))
		{
			string text10 = text2.Substring(10).Trim();
			string text11 = FindMetaFile(text10);
			if (text11 == null)
			{
				Util.WriteToChat("Meta: no meta called " + text10 + ".");
				return true;
			}
			if (OpenMeta(text11))
			{
				MetaStart();
			}
			return true;
		}
		return false;
	}

	public bool LoadMetaByName(string name)
	{
		string text = FindMetaFile(name);
		return text != null && OpenMeta(text);
	}

	public List<string> MetaNames()
	{
		if (_metaNames != null && (DateTime.Now - _metaNamesAt).TotalSeconds < 30.0)
		{
			return _metaNames;
		}
		_metaNamesAt = DateTime.Now;
		List<string> list = new List<string>();
		try
		{
			string[] files = Directory.GetFiles(MetaDir);
			foreach (string path in files)
			{
				string text = Path.GetExtension(path).ToLowerInvariant();
				if (!(text != ".mtmet") || !(text != ".met"))
				{
					string n = Path.GetFileNameWithoutExtension(path);
					if (!list.Exists((string x) => string.Equals(x, n, StringComparison.OrdinalIgnoreCase)))
					{
						list.Add(n);
					}
				}
			}
		}
		catch
		{
		}
		list.Sort(StringComparer.OrdinalIgnoreCase);
		return _metaNames = list;
	}

	private string FindMetaFile(string name)
	{
		string[] array = new string[2] { MetaDir, VtankDir };
		foreach (string text in array)
		{
			if (string.IsNullOrEmpty(text))
			{
				continue;
			}
			string[] array2 = new string[2] { ".mtmet", ".met" };
			foreach (string text2 in array2)
			{
				string text3 = Path.Combine(text, name + text2);
				if (File.Exists(text3))
				{
					return text3;
				}
			}
		}
		return null;
	}

	private static bool OptTrue(string v)
	{
		v = (v ?? "").Trim();
		return v == "1" || v.Equals("true", StringComparison.OrdinalIgnoreCase) || v.Equals("on", StringComparison.OrdinalIgnoreCase);
	}

	private void OptSet(string opt, string val)
	{
		bool flag = OptTrue(val);
		string text = (opt ?? "").Trim().ToLowerInvariant();
		MLog("option " + opt + " = " + val);
		switch (text)
		{
		case "enablecombat":
			_s.CombatEnabled = flag;
			break;
		case "enablelooting":
			_s.LootEnabled = flag;
			break;
		case "enablebuffing":
			PluginCore.SetBuffingFromUi(flag);
			break;
		case "enablenav":
			if (flag && !_s.NavEnabled && MetaRunning)
			{
				_s.MetaTurnedNavOn = true;
			}
			if (!flag)
			{
				_s.MetaTurnedNavOn = false;
			}
			_s.NavEnabled = flag;
			if (flag && CurrentRoute != null)
			{
				_s.NavMode = 1;
			}
			if (!flag)
			{
				Stop();
			}
			break;
		case "enablemeta":
			if (!flag)
			{
				MetaStop();
			}
			break;
		case "enablesummoning":
			PluginCore.SetSummoningFromNav(flag);
			break;
		case "enabledoors":
		case "opendoors":
			_s.NavOpenDoors = flag;
			break;
		default:
			if (VtOptSet(text, val))
			{
				break;
			}
			_mOpts[opt] = val;
			MWarn("opt:" + text, "option " + opt + " isn't one of MelkTank's switches - noted, not used.");
			return;
		}
		if (SaveAll != null)
		{
			SaveAll();
		}
	}

	private bool VtOptSet(string o, string val)
	{
		bool flag = double.TryParse((val ?? "").Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out var result);
		bool flag2 = OptTrue(val);
		switch (o)
		{
		case "idlepeacemode":
			_s.PeaceWhenIdle = flag2;
			return true;
		case "autostack":
			_s.AutoStack = flag2;
			return true;
		case "lootfellowcorpses":
			_s.LootFellowKills = flag2;
			return true;
		case "refillwornmana":
			_s.ManaTopUp = flag2;
			return true;
		case "summonpets":
			PluginCore.SetSummoningFromNav(flag2);
			return true;
		case "attackdistance":
			if (!flag)
			{
				return false;
			}
			_s.AttackRange = (float)(result * 240.0);
			return true;
		case "ringdistance":
			if (!flag)
			{
				return false;
			}
			_s.RingRadius = (float)(result * 240.0);
			return true;
		case "minimumringtargets":
			if (!flag)
			{
				return false;
			}
			_s.RingMinMonsters = (int)result;
			return true;
		case "debuffeachfirst":
			_s.DebuffAllFirst = (flag ? (result != 0.0) : flag2);
			return true;
		case "corpseapproachrange-min":
			if (!flag)
			{
				return false;
			}
			_s.LootRange = (float)(result * 240.0);
			return true;
		case "dooropenrange":
			if (!flag)
			{
				return false;
			}
			_s.NavDoorRange = (float)(result * 240.0);
			return true;
		case "navclosestoprange":
			if (!flag)
			{
				return false;
			}
			_s.NavCloseDist = (float)(result * 240.0);
			return true;
		case "petcustomrange":
			if (!flag)
			{
				return false;
			}
			_s.PetRange = (float)(result * 240.0);
			return true;
		case "petrangemode":
			_s.PetRangeOverride = (flag ? (result == 1.0) : flag2);
			return true;
		case "refillwornmana-item-manapercent":
			if (!flag)
			{
				return false;
			}
			_s.ManaTopUpPercent = (int)result;
			return true;
		default:
			return false;
		}
	}

	private static string VtNum(double v)
	{
		return v.ToString("0.#####", CultureInfo.InvariantCulture);
	}

	private string VtOptGet(string o)
	{
		return o switch
		{
			"idlepeacemode" => _s.PeaceWhenIdle ? "1" : "0", 
			"autostack" => _s.AutoStack ? "1" : "0", 
			"lootfellowcorpses" => _s.LootFellowKills ? "1" : "0", 
			"refillwornmana" => _s.ManaTopUp ? "1" : "0", 
			"summonpets" => _s.MelksPetEnabled ? "1" : "0", 
			"attackdistance" => VtNum((double)_s.AttackRange / 240.0), 
			"ringdistance" => VtNum((double)_s.RingRadius / 240.0), 
			"minimumringtargets" => _s.RingMinMonsters.ToString(), 
			"debuffeachfirst" => _s.DebuffAllFirst ? "1" : "0", 
			"corpseapproachrange-min" => VtNum((double)_s.LootRange / 240.0), 
			"dooropenrange" => VtNum((double)_s.NavDoorRange / 240.0), 
			"navclosestoprange" => VtNum((double)_s.NavCloseDist / 240.0), 
			"petcustomrange" => VtNum((double)_s.PetRange / 240.0), 
			"petrangemode" => _s.PetRangeOverride ? "1" : "0", 
			"refillwornmana-item-manapercent" => _s.ManaTopUpPercent.ToString(), 
			_ => null, 
		};
	}

	private string OptGet(string opt)
	{
		string text = (opt ?? "").Trim().ToLowerInvariant();
		switch (text)
		{
		case "enablecombat":
			return _s.CombatEnabled ? "1" : "0";
		case "enablelooting":
			return _s.LootEnabled ? "1" : "0";
		case "enablebuffing":
			return _s.MelksBufferEnabled ? "1" : "0";
		case "enablenav":
			return _s.NavEnabled ? "1" : "0";
		case "enablemeta":
			return MetaRunning ? "1" : "0";
		case "enablesummoning":
			return _s.MelksPetEnabled ? "1" : "0";
		case "enabledoors":
			return _s.NavOpenDoors ? "1" : "0";
		default:
		{
			string text2 = VtOptGet(text);
			if (text2 != null)
			{
				return text2;
			}
			string value;
			return _mOpts.TryGetValue(opt ?? "", out value) ? value : "0";
		}
		}
	}

	public void UpdateMetaRoute()
	{
		if (_metaRoute == null || _metaRouteSrc == null || _meta == null)
		{
			Util.WriteToChat("Meta: this route isn't from the open meta.");
			return;
		}
		string text = (_metaRoute.Name.StartsWith("[meta] ", StringComparison.Ordinal) ? _metaRoute.Name.Substring(7) : _metaRoute.Name);
		NavRoute navRoute = EmbeddedMtRoute(Meta.Enc.GetBytes("x\r\n0\r\n" + RouteXml(_metaRoute)));
		if (navRoute != null)
		{
			navRoute.Name = text;
			navRoute.File = "";
			_metaRouteSrc.T = "ba";
			_metaRouteSrc.B = Meta.Enc.GetBytes(SafeName(text) + ".mtnav\r\n" + navRoute.Steps.Count + "\r\n" + RouteXml(navRoute));
			MetaChanged();
			if (!string.IsNullOrEmpty(_meta.File) && _meta.File.EndsWith(".mtmet", StringComparison.OrdinalIgnoreCase))
			{
				SaveMeta(vtank: false);
			}
			Util.WriteToChat("Meta: route " + text + " updated in " + _meta.Name + " (" + navRoute.Steps.Count + " steps)" + (_meta.Dirty ? " - save the meta to keep it." : "."));
		}
	}

	public static WorldObject PackItem(string name)
	{
		if (string.IsNullOrEmpty(name))
		{
			return null;
		}
		WorldObject worldObject = null;
		foreach (WorldObject item in InvCache.All())
		{
			if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
			{
				return item;
			}
			if (worldObject == null && (item.Name ?? "").IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0)
			{
				worldObject = item;
			}
		}
		return worldObject;
	}

	public static WorldObject NearestNamed(string name, int kind)
	{
		if (string.IsNullOrEmpty(name))
		{
			return null;
		}
		WorldObject result = null;
		double num = double.MaxValue;
		bool flag = false;
		foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
		{
			if ((kind == 1 && item.ObjectClass != ObjectClass.Npc && item.ObjectClass != ObjectClass.Vendor) || (kind == 2 && item.ObjectClass != ObjectClass.Portal))
			{
				continue;
			}
			bool flag2 = string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase);
			if (flag2 || (item.Name ?? "").IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0)
			{
				double num2 = CombatEngine.Distance(item);
				if (num2 < 0.0)
				{
					num2 = 9999.0;
				}
				if ((flag2 && !flag) || (flag2 == flag && num2 < num))
				{
					result = item;
					num = num2;
					flag = flag2;
				}
			}
		}
		return result;
	}

	private void UseByName(string name, int kind)
	{
		WorldObject worldObject = ((kind == 0) ? PackItem(name) : NearestNamed(name, kind));
		string text = kind switch
		{
			1 => "NPC", 
			0 => "item", 
			_ => "portal", 
		};
		if (worldObject == null)
		{
			MLog("no " + text + " called " + name);
			Util.WriteToChat("Meta: no " + text + " called " + name + ((kind == 0) ? " in your pack." : " nearby."));
		}
		else
		{
			MLog(((kind == 1) ? "talk to " : "use ") + worldObject.Name);
			Globals.Core.Actions.UseItem(worldObject.Id, 0);
		}
	}

	private void GiveTo(string item, string npc)
	{
		WorldObject worldObject = PackItem(item);
		WorldObject worldObject2 = NearestNamed(npc, 1);
		if (worldObject == null)
		{
			MLog("no item called " + item);
			Util.WriteToChat("Meta: no item called " + item + " in your pack.");
		}
		else if (worldObject2 == null)
		{
			MLog("no NPC called " + npc);
			Util.WriteToChat("Meta: no NPC called " + npc + " nearby.");
		}
		else
		{
			MLog("give " + worldObject.Name + " to " + worldObject2.Name);
			Globals.Core.Actions.GiveItem(worldObject.Id, worldObject2.Id);
		}
	}

	private void LoadEmbedded(MVal src)
	{
		byte[] array = src?.B;
		NavRoute navRoute = null;
		MetaText.NavSummary(array, out var name, out var points);
		if (array == null || array.Length == 0 || points == 0)
		{
			_metaRoute = null;
			if (_s.NavRouteSelected.StartsWith("[meta] ", StringComparison.Ordinal))
			{
				_s.NavRouteSelected = "";
			}
			Stop();
			RouteReset();
			MLog("route cleared");
			return;
		}
		if (IsMtRoute(array))
		{
			navRoute = EmbeddedMtRoute(array);
		}
		else
		{
			try
			{
				string text = Meta.Enc.GetString(array);
				int startIndex = text.IndexOf("uTank2 NAV", StringComparison.OrdinalIgnoreCase);
				string path = Path.Combine(Path.GetTempPath(), "mt_metanav.nav");
				File.WriteAllText(path, text.Substring(startIndex), Meta.Enc);
				navRoute = ImportNav(path);
				try
				{
					File.Delete(path);
				}
				catch
				{
				}
			}
			catch (Exception ex)
			{
				Util.WriteToChat("Meta: couldn't load the embedded route: " + ex.Message);
			}
		}
		if (navRoute != null)
		{
			string text2;
			if (name.Length > 0)
			{
				text2 = Path.GetFileNameWithoutExtension(name);
			}
			else
			{
				text2 = ((navRoute.Name.Length > 0) ? navRoute.Name : "route");
			}
			navRoute.Name = "[meta] " + text2;
			navRoute.File = "";
			_metaRoute = navRoute;
			_metaRouteSrc = src;
			_s.NavRouteSelected = navRoute.Name;
			_s.NavMode = 1;
			Stop();
			RouteReset();
			MLog("route " + text2 + " loaded (" + navRoute.Steps.Count + " steps)");
		}
	}
}
