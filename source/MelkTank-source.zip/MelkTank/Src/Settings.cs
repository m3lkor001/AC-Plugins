using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;
using System.Xml;
using Decal.Adapter.Wrappers;
using MelkTank.Metas;

namespace MelkTank;

public class Settings
{
	public bool MasterEnabled = true;

	public bool CombatEnabled = false;

	public float AttackRange = 25f;

	// past the attack range, out to this: it runs to the monster until it's inside the attack range, then fights
	// (only counts when bigger than the attack range; 0 = off)
	public float ApproachRange = 0f;

	public bool RefreshDots = true;

	public float FractureDelayS = 8f;

	public bool FractureMinOn = true;

	public int FractureMin = 2;

	public bool FractureReprime = false;

	public bool FractureAll = false;

	public bool PrimeEveryNF = false;

	public bool StreakPrimed = false;

	public bool StreakDotted = false;

	public bool PrimeFocus = false;

	public bool PrimeOnePerWand = true;

	public bool RePrimeFresh = true;

	public bool PrimeHigh = false;

	public int PrimeHighMin = 2;

	public bool TrustSpread = false;

	public bool BountyHudOn = true;

	public int BountyMinutes = 1;

	public bool BountyShowKts = true;

	public bool UseDotLines = true;

	public int TrustSpreadMax = 2;

	public float TrustSpreadM = 10f;

	public bool RefreshVulns = true;

	public float RefreshLeadSeconds = 5f;

	public bool DebuffAllFirst = true;

	public bool TellLog = true;

	public string ChatFilterOn = "";

	public bool LootQbStamps = true;

	public bool TrackPickup = false;

	// a detour to a tracked item stops when a monster comes into attack range: fight it, then carry on
	public bool DetourStopsForCombat = true;

	public int ResMaxReserve = 0;

	public bool LootChests = false;

	public bool CheckChests = false;

	public bool ChestSummary = false;

	public bool ChestPickLocks = false;

	public bool AutoChests = false;

	public bool BadItemAutoRemove = false;

	public bool BadItemNotify = true;

	public bool OpenPackAtLogin = false;

	public string PortalBarGems = "";

	public bool PortalBarShow = false;

	public float PortalBarScale = 1f;

	public int PortalBarCols = 4;

	public bool GiverInBar = true;

	public bool TellKeep = false;

	public bool VtStandIn = true;

	public bool VtStandInVirindi = true;

	public bool VtCommands = true;

	public bool VtLiveUb = true;

	public bool OwnExpr = true;

	public bool VtUbLootWatch = true;

	public bool MtCommands = true;

	public bool AutoYes100 = true;

	public bool FewerWeaponSwaps = true;

	public bool ConfirmSwaps = true;

	public bool PreEquipOnApproach = true;

	public bool Level1Dot = false;

	public bool Level1Vuln = false;

	public bool Level1War = false;

	public bool Level1Void = false;

	public bool RingLevel1 = false;

	public bool UseBolts = false;

	public int RingMinMonsters = 3;

	public float RingRadius = 3f;

	public WeaponKind DefaultAttack = WeaponKind.Caster;

	public int AttackKeyIndex = 0;

	public float AttackPower = 100f;

	public int AttackHeight = 1;

	public bool UseMagicForDebuffsOnly = false;

	public bool HoldVTankNav = true;

	public bool DebugLog = true;

	public int CastRecoveryMs = 1000;

	public int DurationAugs = 2000;

	public float CalibBaseMinutes = 90f;

	public float CalibObservedMinutes = 9270f;

	public float DebuffMultiplier = 103f;

	public bool MelksBufferEnabled = false;

	public bool MelksPetEnabled = false;

	public bool PetUseMelkTankInfo = false;

	public bool PetOnlyInCombat = false;

	public bool PetDmgCommas = true;

	// monsters only pets can hurt (ILT): one name per line
	public string PetOnlyMonsters = "Crusty Cheese\nRotten Egg\nLeftover Pizza\nSour Grapes";

	public bool PetNoSummonInFight = false;

	public bool PetRechargeBetweenPacks = false;

	public bool PetRangeOverride = false;

	public float PetRange = 20f;

	public string BufferOnCommand = "/mbuff on";

	public string BufferOffCommand = "/mbuff off";

	public string PetOnCommand = "/mpets on";

	public bool CountLumTokens = true;

	public float LumTokenB = 50f;

	/// <summary>T11+: use the attack school gems (Gem of War / Void / Melee / Missile Augmentation) after looting.</summary>
	public bool AutoUseAttackGems;

	public bool DispelOn = false;

	public float DispelCooldownS = 7f;

	public string PackSubs = "";

	private string _subsShared;

	private DateTime _subsCheckAt = DateTime.MinValue;

	private DateTime _subsFileTime = DateTime.MinValue;

	public string PackRules = "";

	public bool PackOrgOn = false;

	public bool AugNoSingles = true;

	public bool PerfLog = true;

	public bool PackMerge = true;

	public bool PackRulesSeeded = false;

	public bool CharmGemAutoBuy = true;

	public string Charms = "";

	public string DispelIgnore = "";

	public string MetaLast = "";

	public bool MetaOpenLast = true;

	public bool MetaVtankDir = false;

	public bool MetaTurnedNavOn = false;

	public bool MetaRun = false;

	public bool MetaSameRestarts = false;

	public bool NavOpenDoors = false;

	public float NavDoorRange = 4f;

	public bool NavPickLocks = false;

	public int NavLockpickMargin = -50;

	public bool FellowOpenOnCreate = true;

	public bool FellowRelock = false;

	public bool FmOn = false;

	public bool FmWaitList = true;

	public bool FmVoteKick = true;

	public bool FmVoteBan = true;

	public bool FmVoteLeader = true;

	public bool FmVoteOpen = true;

	public bool FellowAuto = false;

	public string FellowKeywords = "xp";

	public bool FellowScan = false;

	public float FellowScanRange = 0f;

	public bool FellowLandblock = false;

	public float FellowLandblockMin = 5f;

	public string FellowIgnore = "";

	public bool FellowCreate = false;

	public string FellowName = "";

	public string PetOffCommand = "/mpets off";

	public bool HealEnabled = false;

	public float HealPercent = 60f;

	public int HealKitId = 0;

	public string HealKitName = "";

	public int MaxHealthLowTier = 0;

	public int MaxHealthHighTier = 0;

	public bool ManaEnabled = false;

	public float ManaPercent = 30f;

	public int ManaMode = 0;

	public int ManaItemId = 0;

	public string ManaItemName = "";

	public bool StaminaEnabled = false;

	public float StaminaPercent = 30f;

	public int StaminaMode = 0;

	public int StaminaItemId = 0;

	public string StaminaItemName = "";

	public bool DeathStopCombat = true;

	public bool DeathStopBuff = true;

	public bool DeathStopLoot = true;

	public bool DeathStopPet = true;

	public bool TrackMaxRange = false;

	public bool TrackPopOut = false;

	public string TuneOut = "";

	public string ActiveProfile = "";

	public bool LootEnabled = false;

	public float LootRange = 20f;

	public string PortalGems = string.Join("|", PortalsTab.DefaultGems);

	public bool LootOwnCorpse = false;

	public bool ShinySameAsBase = true;

	public List<NavSpot> NavSpots = new List<NavSpot>();

	public string NavSelected = "";

	public bool NavEnabled = false;

	public bool NavPriority = false;

	public bool NavFaceHeading = true;

	public bool NavShowMarker = true;

	public bool NavArrow = false;

	public bool NavChamberSpots = true;

	public bool NavDebugChamber = false;

	public float NavDrift = 1.5f;

	public bool NavHideUnfocused = true;

	public string LoginWindows = "";

	public bool AutoStack = false;

	public bool TimerOnPetHit = false;

	/// <summary>Ghost monsters: skip a monster swung at for GhostSeconds with not one hit, evade (or health drop) - one the
	/// client still shows but the server no longer has.</summary>
	public bool GhostCheck = true;

	public float GhostSeconds = 12f;

	public float GhostSkipSeconds = 120f;

	/// <summary>The monster's health going down counts as a sign it's really there.</summary>
	public bool GhostHealthCounts = true;

	public bool TimerOnSpread = false;

	public bool AutoElementBySpecies = true;

	public bool AutoSwitchMeleeMissile = true;

	/// <summary>Monsters whose Off hand is &lt;AUTO&gt;: a shield from the Items list beside a one-handed melee weapon.</summary>
	public bool DefaultShield;

	public bool AreasEnabled = false;

	public bool AreaLoadNav = true;

	public bool AreaLoadLoot = true;

	public bool AreasOnArrival = true;

	public List<AreaLink> AreaLinks = new List<AreaLink>();

	public float NavTurnAngle = 60f;

	public float NavCloseDist = 5f;

	public float NavCloseAngle = 15f;

	public bool TravelKeep;

	public bool TKMaster;

	public bool TKCombat;

	public bool TKNav;

	public int TKNavMode;

	public string TKNavRoute = "";

	public float NavMaxRunM = 1500f;

	public bool NavSmoothSteer = true;

	public float NavSmoothSteerS = 0.15f;

	public float NavSteerDeadband = 4f;

	public bool NavRouteShowAll = true;

	public bool NavRouteShowNext = true;

	public bool NavRouteArrow = true;

	public string FollowName = "";

	public float FollowDist = 3f;

	public bool FollowPortals = true;

	public bool FollowRing = true;

	public bool FollowArrow = true;

	public bool FollowExactPath = false;

	public int NavMode = 0;

	public List<NavRoute> NavRoutes = new List<NavRoute>();

	public string NavRouteSelected = "";

	public bool ManaTopUp = false;

	public int ManaTopUpPercent = 20;

	public string ManaStoneNames = "Infinite, Eternal Mana Charge";

	public bool AutoSalvage = false;

	public bool AutoChunkAetheria = true;

	public int ChunkMaxLevel = 8;

	public bool RevealAetheria = true;

	public bool ChunkWeapons = true;

	public bool ChunkForce = false;

	public int ChunkForceCount = 10;

	public bool SalvagePartialBags = true;

	public bool HoverInfoOn = true;

	public bool HoverInfoAskId = true;

	public bool HoverLootRule = true;

	public bool HoverDetails = true;

	public bool HoverScore = true;

	public bool HoverCompare = true;

	public bool HoverColors = true;

	public uint HoverItemType = 0u;

	public bool PeaceWhenIdle = false;

	public float PeaceIdleS = 10f;

	public bool PeaceRightAway = false;

	public bool PeaceOnlyNav = false;

	public bool SkipBehindWalls = true;

	public bool PreferAttacker = true;

	public bool LootRares = true;

	public bool LootOnlyRare = false;

	public bool CloseTurnLeast = true;

	public float CloseTurnRange = 4f;

	public bool PetUseCombatRange = false;

	public bool PetRangeMigrated = false;

	public bool MonsterLogOn = false;

	public bool DexAsheronShiny = false;

	public bool DexResonantShiny = false;

	public bool DexCatch = false;

	public bool DexLensFirst = true;

	public bool DexAsheron = false;

	public bool DexResonant = true;

	public bool DexCorruption = true;

	public bool DexResonator = true;

	public bool DexPetT11 = true;

	public int DexLensTries = 3;

	public int DexLensGapMs = 500;

	public int DexLensWaitMs = 6000;

	public int DexGiveUpSecs = 60;

	public float DexHoldPct = 40f;

	public int DexLens = 2;

	public int DexCorruptionAbove = 25000;

	public string TrackItems = "";

	public string TrackProfile = "";

	private string _ownTrack = "";

	public string DexSkip = "";

	public bool AugRatesFromTracker = true;

	public bool BountyLumRate = false;

	public int LootSkipMaxedPct = 95;

	public bool DayNightHudOn = false;

	public bool AutoRelogOn = true;

	public string ItemBarProfile = "Default";

	public bool ItemBarShow = true;

	public bool NavBoost = false;

	public bool LootBoost = false;

	public float ItemBarOpacity = 0.85f;

	public float ItemBarScale = 1f;

	public bool UbNative = true;

	public int ServerKind = 0;

	public bool AllSpellLevels = false;

	public int SpellSkillMargin = 20;

	public bool CheckComponents = true;

	public bool VideoKill = true;

	public bool VideoKillBgOnly = true;

	public bool NtEnabled = true;

	public float NtMaxRange = 35f;

	public bool NtVulnIcon = true;

	public int NtVulnPos = 1;

	public float NtVulnGap = 1f;

	public string NtStyles = "";

	public bool AttrAuto;

	public bool BankPoll;

	public int BankPollMin = 10;

	// Session > Bank transfers: the last few names sent to (newest first, | between), and what was sent last
	public string BankXferNames = "";

	public string BankXferKind = "l";

	public int AttrIntervalMin = 5;

	public string AttrOrder = "Coordination,Quickness,Strength,Endurance,Focus,Self,MaxHealth,MaxStamina,MaxMana";

	public string AttrOn = "";

	public bool MiniShow = true;

	public bool MaxHpLog = true;

	public bool MemLog = true;

	public bool LumPopOut = false;

	public int AutoRelogWaitMin = 20;

	public float AutoRelogGB = 1.5f;

	public bool CmpHoldWeapon = false;

	public bool InvOn = true;

	public int InvUpdateMin = 60;

	public string InvFolder = "";


	public bool VendorPayWithNotes = true;

	public bool VendorAutoOnOpen = false;

	public bool VendorBankChange = true;

	public int VendorKeepLoose = 500000;

	public int VendorBankAbove = 2000000;

	public int VendorNoteSize = 250000;

	public int VendorMaxSpend = 0;

	public int VendorFloor = 0;

	public bool VendorDryRun = false;

	public bool VendorSayBuyList = true;

	public bool VendorSayBought = true;

	public int VendorNotesPerSale = 5;

	public bool VendorIltDeposit = true;

	public string VendorNpc = "";

	public string VendorProfile = "";


	public bool CmpCombatOnStart = false;

	public bool CmpCombatOffEnd = false;

	public bool CmpCombatOffCorrosion = false;

	public bool LootModeEnabled = false;

	public float LootModeRange = 20f;

	public int LootModeCorpses = 10;

	public bool LootFellowKills = false;

	public string LootProfileDir = "";

	public string LootProfile = "";

	public bool LootUseGeneral = true;

	public bool LootMiscOn = false;

	public bool LootArmorOn = false;

	public bool LootWeaponOn = false;

	public bool LootSalvageOn = false;

	public string LootMiscProfile = "";

	public string LootArmorProfile = "";

	public string LootWeaponProfile = "";

	public string LootSalvageProfile = "";

	public bool LootAnnounce = true;

	public bool IdAnnounce = true;

	public bool IdMobs = false;

	public bool IdPlayers = false;

	public int IdChatWindow = 0;

	public bool LootMainWeapon = true;

	public bool IdCompare = true;

	public bool CompareKeepSpecial = true;

	public List<WeaponItem> Items = new List<WeaponItem>();

	public List<MonsterRule> Monsters = new List<MonsterRule>();

	public const int ExtraCount = 2;

	public readonly string[] ExtraProfile = new string[2] { "", "" };

	public readonly List<MonsterRule>[] ExtraMonsters = new List<MonsterRule>[2]
	{
		new List<MonsterRule>(),
		new List<MonsterRule>()
	};

	private readonly Dictionary<int, KeyValuePair<DateTime, KeyValuePair<MonsterRule, int>>> _ruleCache = new Dictionary<int, KeyValuePair<DateTime, KeyValuePair<MonsterRule, int>>>();

	private static readonly Dictionary<string, Regex> _wordRx = new Dictionary<string, Regex>(StringComparer.OrdinalIgnoreCase);

	private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

	private string _charKey = "";

	public float DurationMultiplier => (CalibBaseMinutes > 0f) ? (CalibObservedMinutes / CalibBaseMinutes) : 1f;

	private static string SubsPath => Util.FullPath("MelkTank_PackSubs.txt");

	public MonsterRule DefaultRule
	{
		get
		{
			foreach (MonsterRule monster in Monsters)
			{
				if (monster.IsDefault)
				{
					return monster;
				}
			}
			MonsterRule monsterRule = new MonsterRule("<< DEFAULT >>");
			monsterRule.Dmg = DmgType.Void;
			Monsters.Insert(0, monsterRule);
			return monsterRule;
		}
	}

	public static string TrackDir => Path.Combine(ProfileDir, "Items");

	public static string ProfileDir => Util.FullPath("Profiles");

	public void ApplyLive(List<XmlElement> changed)
	{
		XmlDocument xmlDocument = new XmlDocument();
		XmlElement xmlElement = BuildCharacter(xmlDocument, _charKey, null);
		bool flag = false;
		foreach (XmlElement item in changed)
		{
			XmlNode newChild = xmlDocument.ImportNode(item, deep: true);
			XmlNode xmlNode = xmlElement.SelectSingleNode(item.Name);
			if (xmlNode != null)
			{
				xmlElement.ReplaceChild(newChild, xmlNode);
			}
			else
			{
				xmlElement.AppendChild(newChild);
			}
			if (item.Name == "Monsters")
			{
				flag = true;
			}
		}
		ApplyCharacter(xmlElement);
		if (flag && ActiveProfile.Length == 0)
		{
			XmlNode xmlNode2 = xmlElement.SelectSingleNode("Monsters");
			Monsters.Clear();
			if (xmlNode2 != null)
			{
				ReadMonsters(xmlNode2);
			}
			MonsterRule defaultRule = DefaultRule;
			Monsters.Remove(defaultRule);
			Monsters.Insert(0, defaultRule);
		}
		RulesChanged();
	}

	private static string ReadSharedSubs()
	{
		try
		{
			string subsPath = SubsPath;
			// (an empty file says nothing: it was taking every character's sub-groups away)
			string t = File.Exists(subsPath) ? File.ReadAllText(subsPath).Trim() : null;
			return string.IsNullOrEmpty(t) ? null : t;
		}
		catch
		{
			return null;
		}
	}

	private void WriteSharedSubs(string v)
	{
		try
		{
			Util.WriteShared(SubsPath, v ?? "");
			_subsFileTime = File.GetLastWriteTimeUtc(SubsPath);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public void RefreshSharedSubs()
	{
		if (DateTime.Now < _subsCheckAt)
		{
			return;
		}
		_subsCheckAt = DateTime.Now.AddSeconds(15.0);
		try
		{
			string subsPath = SubsPath;
			if (!File.Exists(subsPath))
			{
				return;
			}
			DateTime lastWriteTimeUtc = File.GetLastWriteTimeUtc(subsPath);
			if (!(lastWriteTimeUtc == _subsFileTime))
			{
				_subsFileTime = lastWriteTimeUtc;
				string text = File.ReadAllText(subsPath).Trim();
				if (text.Length > 0 && text != PackSubs && PackSubs == _subsShared)
				{
					PackSubs = text;
					_subsShared = text;
				}
			}
		}
		catch
		{
		}
	}

	public MonsterRule FindRule(string monsterName)
	{
		WorldObject o = NearestNamed(monsterName);
		int src;
		return Resolve(monsterName, o, out src) ?? DefaultRule;
	}

	public MonsterRule FindRule(WorldObject o)
	{
		if (o == null)
		{
			return DefaultRule;
		}
		int src;
		return Resolve(o.Name, o, out src) ?? DefaultRule;
	}

	private static WorldObject NearestNamed(string name)
	{
		WorldObject result = null;
		double num = double.MaxValue;
		try
		{
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				if (item.ObjectClass == ObjectClass.Monster && string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
				{
					double num2 = CombatEngine.Distance(item);
					if (num2 >= 0.0 && num2 < num)
					{
						num = num2;
						result = item;
					}
				}
			}
		}
		catch
		{
		}
		return result;
	}

	private MonsterRule Resolve(string monsterName, WorldObject o, out int src)
	{
		if (o != null && _ruleCache.TryGetValue(o.Id, out var value) && (DateTime.Now - value.Key).TotalMilliseconds < 250.0)
		{
			src = value.Value.Value;
			return value.Value.Key;
		}
		MonsterMatch.Ctx c = new MonsterMatch.Ctx(monsterName, o, ShinySameAsBase);
		MonsterRule monsterRule = null;
		src = -1;
		for (int i = 0; i <= 2; i++)
		{
			if (monsterRule != null)
			{
				break;
			}
			foreach (MonsterRule item in (i == 0) ? Monsters : ExtraMonsters[i - 1])
			{
				if (item.IsDefault || string.IsNullOrEmpty(item.Name) || !MonsterMatch.Matches(item.Name, c))
				{
					continue;
				}
				monsterRule = item;
				src = i;
				break;
			}
		}
		if (o != null)
		{
			if (_ruleCache.Count > 500)
			{
				_ruleCache.Clear();
			}
			_ruleCache[o.Id] = new KeyValuePair<DateTime, KeyValuePair<MonsterRule, int>>(DateTime.Now, new KeyValuePair<MonsterRule, int>(monsterRule, src));
		}
		return monsterRule;
	}

	public void RulesChanged()
	{
		_ruleCache.Clear();
	}

	public static bool NameContains(string longer, string part)
	{
		if (string.IsNullOrEmpty(longer) || string.IsNullOrEmpty(part) || part.Length >= longer.Length)
		{
			return false;
		}
		if (!_wordRx.TryGetValue(part, out var value))
		{
			value = new Regex("(?<![A-Za-z'])" + Regex.Escape(part.Trim()) + "(?![A-Za-z'])", RegexOptions.IgnoreCase);
			_wordRx[part] = value;
		}
		return value.IsMatch(longer);
	}

	public static NavRoute ReadRoute(XmlElement re)
	{
		if (re == null)
		{
			return null;
		}
		NavRoute navRoute = new NavRoute
		{
			Name = re.GetAttribute("name"),
			File = re.GetAttribute("file")
		};
		int.TryParse(re.GetAttribute("mode"), out navRoute.Mode);
		if (!float.TryParse(re.GetAttribute("arrive"), NumberStyles.Float, CultureInfo.InvariantCulture, out navRoute.Arrive) || navRoute.Arrive < 0.5f)
		{
			navRoute.Arrive = 2.5f;
		}
		if (int.TryParse(re.GetAttribute("stuck"), out var result))
		{
			navRoute.StuckAction = result;
		}
		if (int.TryParse(re.GetAttribute("stuckback"), out result) && result > 0)
		{
			navRoute.StuckBack = result;
		}
		if (int.TryParse(re.GetAttribute("stuckafter"), out result) && result > 0)
		{
			navRoute.StuckAfter = result;
		}
		navRoute.RestartIfFar = re.GetAttribute("restartfar") == "1";
		if (float.TryParse(re.GetAttribute("restartfarm"), NumberStyles.Float, CultureInfo.InvariantCulture, out var result2) && result2 >= 10f)
		{
			navRoute.RestartFarM = result2;
		}
		navRoute.RestartIfStuck = re.GetAttribute("restartstuck") == "1";
		if (float.TryParse(re.GetAttribute("restartstuckm"), NumberStyles.Float, CultureInfo.InvariantCulture, out var result3) && result3 >= 1f)
		{
			navRoute.RestartStuckMin = result3;
		}
		foreach (XmlNode item in re.SelectNodes("Step"))
		{
			if (!(item is XmlElement xmlElement))
			{
				continue;
			}
			RouteStep routeStep = new RouteStep();
			try
			{
				routeStep.Kind = (StepKind)Enum.Parse(typeof(StepKind), xmlElement.GetAttribute("kind"));
			}
			catch
			{
				continue;
			}
			double.TryParse(xmlElement.GetAttribute("ns"), NumberStyles.Float, CultureInfo.InvariantCulture, out routeStep.NS);
			double.TryParse(xmlElement.GetAttribute("ew"), NumberStyles.Float, CultureInfo.InvariantCulture, out routeStep.EW);
			double.TryParse(xmlElement.GetAttribute("z"), NumberStyles.Float, CultureInfo.InvariantCulture, out routeStep.Z);
			routeStep.Text = xmlElement.GetAttribute("text");
			if (int.TryParse(xmlElement.GetAttribute("wait"), out var result4))
			{
				routeStep.WaitMs = result4;
			}
			routeStep.Op = xmlElement.GetAttribute("op");
			routeStep.Profile = xmlElement.GetAttribute("profile");
			if (int.TryParse(xmlElement.GetAttribute("count"), out var result5))
			{
				routeStep.Count = result5;
			}
			foreach (XmlNode item2 in xmlElement.SelectNodes("Cond"))
			{
				if (item2 is XmlElement xmlElement2)
				{
					LoopCond loopCond = new LoopCond
					{
						Chat = (xmlElement2.GetAttribute("chat") == "1"),
						Text = xmlElement2.GetAttribute("text"),
						Op = xmlElement2.GetAttribute("op")
					};
					if (int.TryParse(xmlElement2.GetAttribute("count"), out var result6))
					{
						loopCond.Count = result6;
					}
					routeStep.Conds.Add(loopCond);
				}
			}
			navRoute.Steps.Add(routeStep);
		}
		return (navRoute.Name.Length == 0 && navRoute.Steps.Count == 0) ? null : navRoute;
	}

	public static void WriteRoute(XmlDocument doc, XmlElement re, NavRoute r)
	{
		re.SetAttribute("name", r.Name);
		re.SetAttribute("mode", r.Mode.ToString());
		if (!string.IsNullOrEmpty(r.File))
		{
			re.SetAttribute("file", r.File);
		}
		re.SetAttribute("arrive", r.Arrive.ToString("R", CultureInfo.InvariantCulture));
		if (r.StuckAction != 0)
		{
			re.SetAttribute("stuck", r.StuckAction.ToString());
			re.SetAttribute("stuckback", r.StuckBack.ToString());
			re.SetAttribute("stuckafter", r.StuckAfter.ToString());
		}
		if (r.RestartIfStuck)
		{
			re.SetAttribute("restartstuck", "1");
			re.SetAttribute("restartstuckm", r.RestartStuckMin.ToString("R", CultureInfo.InvariantCulture));
		}
		if (r.RestartIfFar)
		{
			re.SetAttribute("restartfar", "1");
			re.SetAttribute("restartfarm", r.RestartFarM.ToString("R", CultureInfo.InvariantCulture));
		}
		foreach (RouteStep step in r.Steps)
		{
			XmlElement xmlElement = doc.CreateElement("Step");
			xmlElement.SetAttribute("kind", step.Kind.ToString());
			xmlElement.SetAttribute("ns", step.NS.ToString("R", CultureInfo.InvariantCulture));
			xmlElement.SetAttribute("ew", step.EW.ToString("R", CultureInfo.InvariantCulture));
			xmlElement.SetAttribute("z", step.Z.ToString("R", CultureInfo.InvariantCulture));
			xmlElement.SetAttribute("text", step.Text ?? "");
			xmlElement.SetAttribute("wait", step.WaitMs.ToString());
			if (!string.IsNullOrEmpty(step.Op))
			{
				xmlElement.SetAttribute("op", step.Op);
			}
			if (step.Count != 0)
			{
				xmlElement.SetAttribute("count", step.Count.ToString());
			}
			if (!string.IsNullOrEmpty(step.Profile))
			{
				xmlElement.SetAttribute("profile", step.Profile);
			}
			foreach (LoopCond cond in step.Conds)
			{
				XmlElement xmlElement2 = doc.CreateElement("Cond");
				if (cond.Chat)
				{
					xmlElement2.SetAttribute("chat", "1");
				}
				xmlElement2.SetAttribute("text", cond.Text ?? "");
				xmlElement2.SetAttribute("op", cond.Op ?? "");
				xmlElement2.SetAttribute("count", cond.Count.ToString());
				xmlElement.AppendChild(xmlElement2);
			}
			re.AppendChild(xmlElement);
		}
	}

	public static string BaseMonsterName(string name)
	{
		string text = (name ?? "").Trim();
		bool flag = true;
		while (flag)
		{
			flag = false;
			string[] array = new string[2] { "Enraged ", "Shiny " };
			foreach (string text2 in array)
			{
				if (text.StartsWith(text2, StringComparison.OrdinalIgnoreCase) && text.Length > text2.Length)
				{
					text = text.Substring(text2.Length).TrimStart();
					flag = true;
				}
			}
		}
		return text;
	}

	public int RuleSource(WorldObject o)
	{
		int src;
		return (o != null && Resolve(o.Name, o, out src) != null) ? src : (-1);
	}

	public IEnumerable<MonsterRule> AllRules()
	{
		foreach (MonsterRule monster in Monsters)
		{
			yield return monster;
		}
		for (int i = 0; i < 2; i++)
		{
			foreach (MonsterRule item in ExtraMonsters[i])
			{
				yield return item;
			}
		}
	}

	public bool SetExtraProfile(int i, string name)
	{
		name = (string.IsNullOrEmpty(name) ? "" : (FindProfile(name) ?? ""));
		ExtraProfile[i] = name;
		LoadExtra(i);
		SaveCharacter(_charKey);
		return true;
	}

	public bool CreateExtraProfile(int i, string name)
	{
		name = CleanProfileName(name);
		if (name.Length == 0)
		{
			Util.WriteToChat("Type a name for the new list first.");
			return false;
		}
		if (FindProfile(name) != null)
		{
			Util.WriteToChat("There's already a profile called '" + name + "' - pick it from the list instead.");
			return false;
		}
		try
		{
			Directory.CreateDirectory(ProfileDir);
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Can't create the Profiles folder: " + ex.Message);
			return false;
		}
		ExtraMonsters[i] = new List<MonsterRule>();
		if (!WriteMonsterFile(ProfilePath(name), ExtraMonsters[i]))
		{
			return false;
		}
		ExtraProfile[i] = name;
		SaveCharacter(_charKey);
		return true;
	}

	private void ClearExtraIfSame(string name)
	{
		if (string.IsNullOrEmpty(name))
		{
			return;
		}
		for (int i = 0; i < 2; i++)
		{
			if (string.Equals(ExtraProfile[i], name, StringComparison.OrdinalIgnoreCase))
			{
				ExtraProfile[i] = "";
				ExtraMonsters[i] = new List<MonsterRule>();
			}
		}
	}

	public void LoadExtra(int i)
	{
		ExtraMonsters[i] = new List<MonsterRule>();
		if (ExtraProfile[i].Length == 0)
		{
			return;
		}
		try
		{
			if (!File.Exists(ProfilePath(ExtraProfile[i])))
			{
				Util.WriteToChat("Monster list '" + ExtraProfile[i] + "' is missing - list " + (i + 2) + " is off.");
				ExtraProfile[i] = "";
			}
			else
			{
				XmlDocument xmlDocument = new XmlDocument();
				Util.LoadXml(xmlDocument, ProfilePath(ExtraProfile[i]));
				ReadMonsters(xmlDocument.DocumentElement, ExtraMonsters[i]);
				ExtraMonsters[i].RemoveAll((MonsterRule r) => r.IsDefault);
			}
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Load list " + (i + 2) + " error: " + ex.Message);
		}
	}

	public void SaveExtra(int i)
	{
		if (ExtraProfile[i].Length > 0)
		{
			WriteMonsterFile(ProfilePath(ExtraProfile[i]), ExtraMonsters[i]);
		}
	}

	public void Load(string charKey)
	{
		_charKey = charKey ?? "";
		LoadCharacter(charKey);
		if (ActiveProfile.Length > 0 && !File.Exists(ProfilePath(ActiveProfile)))
		{
			Util.WriteToChat("Profile '" + ActiveProfile + "' is missing - using this character's own monster list.");
			ActiveProfile = "";
		}
		LoadMonsters();
		for (int i = 0; i < 2; i++)
		{
			if (ExtraProfile[i].Length > 0 && string.Equals(ExtraProfile[i], ActiveProfile, StringComparison.OrdinalIgnoreCase))
			{
				ExtraProfile[i] = "";
			}
			LoadExtra(i);
		}
	}

	public void Save(string charKey)
	{
		_charKey = charKey ?? _charKey;
		SaveCharacter(_charKey);
		if (ActiveProfile.Length > 0)
		{
			SaveMonsters();
		}
		if (TrackProfile.Length > 0)
		{
			WriteTrackFile(TrackProfile);
		}
		for (int i = 0; i < 2; i++)
		{
			SaveExtra(i);
		}
	}

	public static string TrackPath(string name)
	{
		return Path.Combine(TrackDir, name + ".xml");
	}

	private static void PutList(XmlDocument doc, XmlElement parent, string name, string lines)
	{
		XmlElement xmlElement = doc.CreateElement(name);
		parent.AppendChild(xmlElement);
		string[] array = (lines ?? "").Split('\n');
		foreach (string text in array)
		{
			if (text.Trim().Length > 0)
			{
				Put(doc, xmlElement, "Item", text.Trim());
			}
		}
	}

	private static string ReadList(XmlNode l)
	{
		List<string> list = new List<string>();
		foreach (XmlNode item in l.SelectNodes("Item"))
		{
			if (item.InnerText.Trim().Length > 0)
			{
				list.Add(item.InnerText.Trim());
			}
		}
		return string.Join("\n", list.ToArray());
	}

	private void LoadTrack(XmlNode c)
	{
		XmlNode xmlNode = c.SelectSingleNode("TrackList");
		if (xmlNode != null)
		{
			_ownTrack = ReadList(xmlNode);
		}
		else
		{
			XmlNode xmlNode2 = c.SelectSingleNode("TrackItems");
			if (xmlNode2 != null && xmlNode2.SelectSingleNode("*") == null)
			{
				_ownTrack = xmlNode2.InnerText;
			}
		}
		TrackItems = _ownTrack;
		TrackProfile = GetString(c, "TrackProfile", "");
		if (TrackProfile.Length > 0 && !ReadTrackFile(TrackProfile))
		{
			TrackProfile = "";
		}
	}

	public static List<string> ListTrackProfiles()
	{
		List<string> list = new List<string>();
		try
		{
			if (Directory.Exists(TrackDir))
			{
				string[] files = Directory.GetFiles(TrackDir, "*.xml");
				foreach (string path in files)
				{
					list.Add(Path.GetFileNameWithoutExtension(path));
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		list.Sort(StringComparer.OrdinalIgnoreCase);
		return list;
	}

	public static string FindTrackProfile(string name)
	{
		foreach (string item in ListTrackProfiles())
		{
			if (string.Equals(item, name, StringComparison.OrdinalIgnoreCase))
			{
				return item;
			}
		}
		return null;
	}

	private bool ReadTrackFile(string name)
	{
		try
		{
			if (!File.Exists(TrackPath(name)))
			{
				return false;
			}
			XmlDocument xmlDocument = new XmlDocument();
			Util.LoadXml(xmlDocument, TrackPath(name));
			TrackItems = ReadList(xmlDocument.DocumentElement);
			return true;
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Load item profile error: " + ex.Message);
			return false;
		}
	}

	private bool WriteTrackFile(string name)
	{
		try
		{
			Directory.CreateDirectory(TrackDir);
			XmlDocument xmlDocument = new XmlDocument();
			XmlElement xmlElement = xmlDocument.CreateElement("TrackItems");
			xmlDocument.AppendChild(xmlElement);
			string[] array = (TrackItems ?? "").Split('\n');
			foreach (string text in array)
			{
				if (text.Trim().Length > 0)
				{
					Put(xmlDocument, xmlElement, "Item", text.Trim());
				}
			}
			Util.SaveXml(xmlDocument, TrackPath(name));
			return true;
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Save item profile error: " + ex.Message);
			return false;
		}
	}

	public static int AddToTrackProfile(string name, IEnumerable<string> lines, out string used)
	{
		used = CleanProfileName(name);
		if (used.Length == 0)
		{
			return -1;
		}
		string text = FindTrackProfile(used);
		if (text != null)
		{
			used = text;
		}
		try
		{
			List<string> list = new List<string>();
			HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
			if (File.Exists(TrackPath(used)))
			{
				XmlDocument xmlDocument = new XmlDocument();
				Util.LoadXml(xmlDocument, TrackPath(used));
				string[] array = ReadList(xmlDocument.DocumentElement).Split('\n');
				foreach (string text2 in array)
				{
					if (text2.Trim().Length > 0)
					{
						list.Add(text2.Trim());
						hashSet.Add(text2.Trim().TrimStart('~'));
					}
				}
			}
			int num = 0;
			foreach (string line in lines)
			{
				string text3 = (line ?? "").Trim();
				if (text3.Length > 0 && hashSet.Add(text3))
				{
					list.Add(text3);
					num++;
				}
			}
			Directory.CreateDirectory(TrackDir);
			XmlDocument xmlDocument2 = new XmlDocument();
			XmlElement xmlElement = xmlDocument2.CreateElement("TrackItems");
			xmlDocument2.AppendChild(xmlElement);
			foreach (string item in list)
			{
				Put(xmlDocument2, xmlElement, "Item", item);
			}
			Util.SaveXml(xmlDocument2, TrackPath(used));
			return num;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			return -1;
		}
	}

	public string SwitchTrackProfile(string name)
	{
		name = (name ?? "").Trim();
		if (name.Length > 0)
		{
			string text = FindTrackProfile(name);
			if (text == null)
			{
				return "No item profile named '" + name + "'.";
			}
			name = text;
		}
		if (string.Equals(name, TrackProfile, StringComparison.OrdinalIgnoreCase))
		{
			return null;
		}
		if (TrackProfile.Length > 0)
		{
			WriteTrackFile(TrackProfile);
		}
		else
		{
			_ownTrack = TrackItems;
		}
		TrackProfile = name;
		if (name.Length == 0)
		{
			TrackItems = _ownTrack;
		}
		else if (!ReadTrackFile(name))
		{
			TrackProfile = "";
			TrackItems = _ownTrack;
			return "Couldn't read item profile '" + name + "'.";
		}
		SaveCharacter(_charKey);
		return null;
	}

	public string SaveTrackProfileAs(string name)
	{
		name = CleanProfileName(name);
		if (name.Length == 0)
		{
			return "Type an item profile name first.";
		}
		string text = FindTrackProfile(name);
		if (text != null)
		{
			name = text;
		}
		if (TrackProfile.Length == 0)
		{
			_ownTrack = TrackItems;
		}
		if (!WriteTrackFile(name))
		{
			return "Couldn't save item profile '" + name + "'.";
		}
		TrackProfile = name;
		SaveCharacter(_charKey);
		return null;
	}

	public string DeleteTrackProfile()
	{
		if (TrackProfile.Length == 0)
		{
			return "No item profile in use.";
		}
		try
		{
			File.Delete(TrackPath(TrackProfile));
		}
		catch (Exception ex)
		{
			return "Couldn't delete item profile: " + ex.Message;
		}
		TrackProfile = "";
		TrackItems = _ownTrack;
		SaveCharacter(_charKey);
		return null;
	}

	public static string ProfilePath(string name)
	{
		return Path.Combine(ProfileDir, name + ".xml");
	}

	public static string CleanProfileName(string name)
	{
		name = (name ?? "").Trim();
		char[] invalidFileNameChars = Path.GetInvalidFileNameChars();
		foreach (char c in invalidFileNameChars)
		{
			name = name.Replace(c.ToString(), "");
		}
		return name.Trim().TrimEnd('.');
	}

	public static List<string> ListProfiles()
	{
		List<string> list = new List<string>();
		try
		{
			if (Directory.Exists(ProfileDir))
			{
				string[] files = Directory.GetFiles(ProfileDir, "*.xml");
				foreach (string path in files)
				{
					list.Add(Path.GetFileNameWithoutExtension(path));
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		list.Sort(StringComparer.OrdinalIgnoreCase);
		return list;
	}

	public static string FindProfile(string name)
	{
		foreach (string item in ListProfiles())
		{
			if (string.Equals(item, name, StringComparison.OrdinalIgnoreCase))
			{
				return item;
			}
		}
		return null;
	}

	public bool SwitchProfile(string name)
	{
		if (!string.IsNullOrEmpty(name))
		{
			string text = FindProfile(name);
			if (text == null)
			{
				Util.WriteToChat("No profile named '" + name + "'.");
				return false;
			}
			name = text;
		}
		else
		{
			name = "";
		}
		SaveMonsters();
		ActiveProfile = name;
		LoadMonsters();
		ClearExtraIfSame(name);
		SaveCharacter(_charKey);
		return true;
	}

	public bool SaveAsProfile(string name)
	{
		name = CleanProfileName(name);
		if (name.Length == 0)
		{
			Util.WriteToChat("Type a profile name first.");
			return false;
		}
		string text = FindProfile(name);
		if (text != null)
		{
			name = text;
		}
		if (ActiveProfile.Length == 0)
		{
			SaveCharacter(_charKey);
		}
		try
		{
			Directory.CreateDirectory(ProfileDir);
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Can't create the Profiles folder: " + ex.Message);
			return false;
		}
		if (!WriteMonsterFile(ProfilePath(name)))
		{
			return false;
		}
		ActiveProfile = name;
		ClearExtraIfSame(name);
		SaveCharacter(_charKey);
		return true;
	}

	public bool DeleteActiveProfile()
	{
		if (ActiveProfile.Length == 0)
		{
			return false;
		}
		try
		{
			File.Delete(ProfilePath(ActiveProfile));
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Couldn't delete profile: " + ex.Message);
			return false;
		}
		ActiveProfile = "";
		LoadMonsters();
		SaveCharacter(_charKey);
		return true;
	}

	private void LoadCharacter(string charKey)
	{
		try
		{
			string path = Util.FullPath("MelkTank_Settings.xml");
			if (File.Exists(path))
			{
				XmlDocument xmlDocument = new XmlDocument();
				Util.LoadXml(xmlDocument, path);
				XmlNode xmlNode = xmlDocument.SelectSingleNode("/MelkTank/Character[@key=" + XPathLiteral(charKey) + "]");
				if (xmlNode != null)
				{
					ApplyCharacter(xmlNode);
				}
			}
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Load settings error: " + ex.Message);
		}
	}

	private void ApplyCharacter(XmlNode c)
	{
		try
		{
			MasterEnabled = GetBool(c, "MasterEnabled", MasterEnabled);
			CombatEnabled = GetBool(c, "CombatEnabled", CombatEnabled);
			AttackRange = GetFloat(c, "AttackRange", AttackRange);
			ApproachRange = GetFloat(c, "ApproachRange", ApproachRange);
			RefreshDots = GetBool(c, "RefreshDots", RefreshDots);
			FractureDelayS = GetFloat(c, "FractureDelayS", FractureDelayS);
			FractureMinOn = GetBool(c, "FractureMinOn", FractureMinOn);
			FractureMin = GetInt(c, "FractureMin", FractureMin);
			FractureReprime = GetBool(c, "FractureReprime", FractureReprime);
			FractureAll = GetBool(c, "FractureAll", FractureAll);
			PrimeEveryNF = GetBool(c, "PrimeEveryNF", PrimeEveryNF);
			StreakPrimed = GetBool(c, "StreakPrimed", StreakPrimed);
			StreakDotted = GetBool(c, "StreakDotted", StreakDotted);
			PrimeFocus = GetBool(c, "PrimeFocus", PrimeFocus);
			PrimeHigh = GetBool(c, "PrimeHigh", PrimeHigh);
			PrimeHighMin = GetInt(c, "PrimeHighMin", PrimeHighMin);
			PrimeOnePerWand = GetBool(c, "PrimeOnePerWand", PrimeOnePerWand);
			RePrimeFresh = GetBool(c, "RePrimeFresh", RePrimeFresh);
			TrustSpread = GetBool(c, "TrustSpread", TrustSpread);
			TrustSpreadM = GetFloat(c, "TrustSpreadM", TrustSpreadM);
			TrustSpreadMax = GetInt(c, "TrustSpreadMax", TrustSpreadMax);
			UseDotLines = GetBool(c, "UseDotLines", UseDotLines);
			BountyHudOn = GetBool(c, "BountyHudOn", BountyHudOn);
			BountyMinutes = Math.Max(1, GetInt(c, "BountyMinutes", BountyMinutes));
			BountyShowKts = GetBool(c, "BountyShowKts", BountyShowKts);
			RefreshVulns = GetBool(c, "RefreshVulns", RefreshVulns);
			RefreshLeadSeconds = GetFloat(c, "RefreshLeadSeconds", RefreshLeadSeconds);
			DebuffAllFirst = GetBool(c, "DebuffAllFirst", DebuffAllFirst);
			FewerWeaponSwaps = GetBool(c, "FewerWeaponSwaps", FewerWeaponSwaps);
			TellLog = GetBool(c, "TellLog", TellLog);
			TellKeep = GetBool(c, "TellKeep", TellKeep);
			GiverInBar = GetBool(c, "GiverInBar", GiverInBar);
			PortalBarGems = GetString(c, "PortalBarGems", PortalBarGems);
			PortalBarShow = GetBool(c, "PortalBarShow", PortalBarShow);
			PortalBarScale = GetFloat(c, "PortalBarScale", PortalBarScale);
			PortalBarCols = GetInt(c, "PortalBarCols", PortalBarCols);
			OpenPackAtLogin = GetBool(c, "OpenPackAtLogin", OpenPackAtLogin);
			BadItemAutoRemove = GetBool(c, "BadItemAutoRemove", BadItemAutoRemove);
			BadItemNotify = GetBool(c, "BadItemNotify", BadItemNotify);
			LootChests = GetBool(c, "LootChests", LootChests);
			ResMaxReserve = GetInt(c, "ResMaxReserve", ResMaxReserve);
			TrackPickup = GetBool(c, "TrackPickup", TrackPickup);
			DetourStopsForCombat = GetBool(c, "DetourStopsForCombat", DetourStopsForCombat);
			LootQbStamps = GetBool(c, "LootQbStamps", LootQbStamps);
			CheckChests = GetBool(c, "CheckChests", CheckChests);
			ChestSummary = GetBool(c, "ChestSummary", ChestSummary);
			AutoChests = GetBool(c, "AutoChests", AutoChests);
			ChestPickLocks = GetBool(c, "ChestPickLocks", ChestPickLocks);
			ChatFilterOn = GetString(c, "ChatFilterOn", ChatFilterOn);
			VtStandIn = GetBool(c, "VtStandIn", VtStandIn);
			VtStandInVirindi = GetBool(c, "VtStandInVirindi", VtStandInVirindi);
			VtCommands = GetBool(c, "VtCommands", VtCommands);
			MtCommands = GetBool(c, "MtCommands", GetBool(c, "VtMtCommands", MtCommands));
			AutoYes100 = GetBool(c, "AutoYes100", AutoYes100);
			VtLiveUb = GetBool(c, "VtLiveUb", VtLiveUb);
			OwnExpr = GetBool(c, "OwnExpr", OwnExpr);
			VtUbLootWatch = GetBool(c, "VtUbLootWatch", VtUbLootWatch);
			ApplyVt();
			ConfirmSwaps = GetBool(c, "ConfirmSwaps", ConfirmSwaps);
			PreEquipOnApproach = GetBool(c, "PreEquipOnApproach", PreEquipOnApproach);
			Level1Dot = GetBool(c, "Level1Dot", Level1Dot);
			Level1Vuln = GetBool(c, "Level1Vuln", Level1Vuln);
			Level1War = GetBool(c, "Level1War", Level1War);
			Level1Void = GetBool(c, "Level1Void", Level1Void);
			RingLevel1 = GetBool(c, "RingLevel1", RingLevel1);
			UseBolts = GetBool(c, "UseBolts", UseBolts);
			RingMinMonsters = GetInt(c, "RingMinMonsters", RingMinMonsters);
			RingRadius = GetFloat(c, "RingRadius", RingRadius);
			DefaultAttack = (WeaponKind)GetInt(c, "DefaultAttack", (int)DefaultAttack);
			AttackKeyIndex = GetInt(c, "AttackKeyIndex", AttackKeyIndex);
			AttackPower = GetFloat(c, "AttackPower", AttackPower);
			AttackHeight = GetInt(c, "AttackHeight", AttackHeight);
			UseMagicForDebuffsOnly = GetBool(c, "UseMagicForDebuffsOnly", UseMagicForDebuffsOnly);
			HoldVTankNav = GetBool(c, "HoldVTankNav", HoldVTankNav);
			DebugLog = GetBool(c, "DebugLog", DebugLog);
			CastRecoveryMs = GetInt(c, "CastRecoveryMs", CastRecoveryMs);
			DurationAugs = GetInt(c, "DurationAugs", DurationAugs);
			CalibBaseMinutes = GetFloat(c, "CalibBaseMinutes", CalibBaseMinutes);
			CalibObservedMinutes = GetFloat(c, "CalibObservedMinutes", CalibObservedMinutes);
			DebuffMultiplier = GetFloat(c, "DebuffMultiplier", DebuffMultiplier);
			MelksBufferEnabled = GetBool(c, "MelksBufferEnabled", MelksBufferEnabled);
			MelksPetEnabled = GetBool(c, "MelksPetEnabled", MelksPetEnabled);
			PetUseMelkTankInfo = GetBool(c, "PetUseMelkTankInfo", PetUseMelkTankInfo);
			PetRangeOverride = GetBool(c, "PetRangeOverride", PetRangeOverride);
			PetOnlyInCombat = GetBool(c, "PetOnlyInCombat", PetOnlyInCombat);
			PetDmgCommas = GetBool(c, "PetDmgCommas", PetDmgCommas);
			PetNoSummonInFight = GetBool(c, "PetNoSummonInFight", PetNoSummonInFight);
			PetRechargeBetweenPacks = GetBool(c, "PetRechargeBetweenPacks", PetRechargeBetweenPacks);
			PetRange = GetFloat(c, "PetRange", PetRange);
			BufferOnCommand = GetString(c, "BufferOnCommand", BufferOnCommand);
			BufferOffCommand = GetString(c, "BufferOffCommand", BufferOffCommand);
			PetOnCommand = GetString(c, "PetOnCommand", PetOnCommand);
			FellowAuto = GetBool(c, "FellowAuto", FellowAuto);
			FellowOpenOnCreate = GetBool(c, "FellowOpenOnCreate", FellowOpenOnCreate);
			FellowRelock = GetBool(c, "FellowRelock", FellowRelock);
			FmOn = GetBool(c, "FmOn", FmOn);
			FmWaitList = GetBool(c, "FmWaitList", FmWaitList);
			FmVoteKick = GetBool(c, "FmVoteKick", FmVoteKick);
			FmVoteBan = GetBool(c, "FmVoteBan", FmVoteBan);
			FmVoteLeader = GetBool(c, "FmVoteLeader", FmVoteLeader);
			FmVoteOpen = GetBool(c, "FmVoteOpen", FmVoteOpen);
			NavOpenDoors = GetBool(c, "NavOpenDoors", NavOpenDoors);
			MetaLast = GetString(c, "MetaLast", MetaLast);
			MetaOpenLast = GetBool(c, "MetaOpenLast", MetaOpenLast);
			MetaRun = GetBool(c, "MetaRun", MetaRun);
			MetaSameRestarts = GetBool(c, "MetaSameRestarts", MetaSameRestarts);
			MetaVtankDir = GetBool(c, "MetaVtankDir", MetaVtankDir);
			DispelOn = GetBool(c, "DispelOn", DispelOn);
			DispelCooldownS = GetFloat(c, "DispelCooldownS", DispelCooldownS);
			DispelIgnore = GetString(c, "DispelIgnore", DispelIgnore);
			Charms = GetString(c, "Charms", Charms);
			CharmGemAutoBuy = GetBool(c, "CharmGemAutoBuy", CharmGemAutoBuy);
			PackRules = GetString(c, "PackRules", PackRules);
			PackSubs = GetString(c, "PackSubs", PackSubs);
			string text = ReadSharedSubs();
			if (text != null)
			{
				PackSubs = text;
			}
			else if (PackSubs.Length > 0)
			{
				WriteSharedSubs(PackSubs);
			}
			_subsShared = PackSubs;
			PackOrgOn = GetBool(c, "PackOrgOn", PackOrgOn);
			PackMerge = GetBool(c, "PackMerge", PackMerge);
			PerfLog = GetBool(c, "PerfLog", PerfLog);
			AugNoSingles = GetBool(c, "AugNoSingles", AugNoSingles);
			PackRulesSeeded = GetBool(c, "PackRulesSeeded", PackRulesSeeded);
			NavDoorRange = GetFloat(c, "NavDoorRange", NavDoorRange);
			NavPickLocks = GetBool(c, "NavPickLocks", NavPickLocks);
			NavLockpickMargin = GetInt(c, "NavLockpickMargin", NavLockpickMargin);
			CountLumTokens = GetBool(c, "CountLumTokens", CountLumTokens);
			LumTokenB = GetFloat(c, "LumTokenB", LumTokenB);
			AutoUseAttackGems = GetBool(c, "AutoUseAttackGems", AutoUseAttackGems);
			FellowKeywords = GetString(c, "FellowKeywords", FellowKeywords);
			FellowScan = GetBool(c, "FellowScan", FellowScan);
			FellowScanRange = GetFloat(c, "FellowScanRange", FellowScanRange);
			FellowLandblock = GetBool(c, "FellowLandblock", FellowLandblock);
			FellowLandblockMin = GetFloat(c, "FellowLandblockMin", FellowLandblockMin);
			FellowIgnore = GetString(c, "FellowIgnore", FellowIgnore);
			FellowCreate = GetBool(c, "FellowCreate", FellowCreate);
			FellowName = GetString(c, "FellowName", FellowName);
			PetOffCommand = GetString(c, "PetOffCommand", PetOffCommand);
			ActiveProfile = GetString(c, "ActiveProfile", "");
			ExtraProfile[0] = GetString(c, "ExtraProfile1", "");
			ExtraProfile[1] = GetString(c, "ExtraProfile2", "");
			HealEnabled = GetBool(c, "HealEnabled", HealEnabled);
			HealPercent = GetFloat(c, "HealPercent", HealPercent);
			HealKitId = GetInt(c, "HealKitId", HealKitId);
			HealKitName = GetString(c, "HealKitName", HealKitName);
			MaxHealthLowTier = GetInt(c, "MaxHealthLowTier", MaxHealthLowTier);
			MaxHealthHighTier = GetInt(c, "MaxHealthHighTier", MaxHealthHighTier);
			ManaEnabled = GetBool(c, "ManaEnabled", ManaEnabled);
			ManaPercent = GetFloat(c, "ManaPercent", ManaPercent);
			ManaMode = GetInt(c, "ManaMode", ManaMode);
			ManaItemId = GetInt(c, "ManaItemId", ManaItemId);
			ManaItemName = GetString(c, "ManaItemName", ManaItemName);
			StaminaEnabled = GetBool(c, "StaminaEnabled", StaminaEnabled);
			StaminaPercent = GetFloat(c, "StaminaPercent", StaminaPercent);
			StaminaMode = GetInt(c, "StaminaMode", StaminaMode);
			StaminaItemId = GetInt(c, "StaminaItemId", StaminaItemId);
			StaminaItemName = GetString(c, "StaminaItemName", StaminaItemName);
			DeathStopCombat = GetBool(c, "DeathStopCombat", DeathStopCombat);
			DeathStopBuff = GetBool(c, "DeathStopBuff", DeathStopBuff);
			DeathStopLoot = GetBool(c, "DeathStopLoot", DeathStopLoot);
			DeathStopPet = GetBool(c, "DeathStopPet", DeathStopPet);
			TrackMaxRange = GetBool(c, "TrackMaxRange", TrackMaxRange);
			TrackPopOut = GetBool(c, "TrackPopOut", TrackPopOut);
			TuneOut = GetString(c, "TuneOut", TuneOut);
			LootEnabled = GetBool(c, "LootEnabled", LootEnabled);
			LootRange = GetFloat(c, "LootRange", LootRange);
			LootFellowKills = GetBool(c, "LootFellowKills", LootFellowKills);
			LootOwnCorpse = GetBool(c, "LootOwnCorpse", LootOwnCorpse);
			ShinySameAsBase = GetBool(c, "ShinySameAsBase", ShinySameAsBase);
			NavSelected = GetString(c, "NavSelected", NavSelected);
			NavEnabled = GetBool(c, "NavEnabled", NavEnabled);
			MetaTurnedNavOn = GetBool(c, "MetaTurnedNavOn", MetaTurnedNavOn);
			NavChamberSpots = GetBool(c, "NavChamberSpots", NavChamberSpots);
			NavPriority = GetBool(c, "NavPriority", NavPriority);
			NavFaceHeading = GetBool(c, "NavFaceHeading", NavFaceHeading);
			NavShowMarker = GetBool(c, "NavShowMarker", NavShowMarker);
			NavArrow = GetBool(c, "NavArrow", NavArrow);
			NavDrift = GetFloat(c, "NavDrift", NavDrift);
			NavHideUnfocused = GetBool(c, "NavHideUnfocused", NavHideUnfocused);
			LoginWindows = GetString(c, "LoginWindows", LoginWindows);
			NavSpots.Clear();
			foreach (XmlNode item in c.SelectNodes("NavSpots/Spot"))
			{
				if (item is XmlElement xmlElement && xmlElement.GetAttribute("name").Length != 0)
				{
					NavSpot navSpot = new NavSpot
					{
						Name = xmlElement.GetAttribute("name"),
						File = xmlElement.GetAttribute("file")
					};
					double.TryParse(xmlElement.GetAttribute("ns"), NumberStyles.Float, CultureInfo.InvariantCulture, out navSpot.NS);
					double.TryParse(xmlElement.GetAttribute("ew"), NumberStyles.Float, CultureInfo.InvariantCulture, out navSpot.EW);
					double.TryParse(xmlElement.GetAttribute("z"), NumberStyles.Float, CultureInfo.InvariantCulture, out navSpot.Z);
					if (!double.TryParse(xmlElement.GetAttribute("heading"), NumberStyles.Float, CultureInfo.InvariantCulture, out navSpot.Heading))
					{
						navSpot.Heading = -1.0;
					}
					navSpot.FaceHeading = (bool.TryParse(xmlElement.GetAttribute("face"), out var result) ? result : NavFaceHeading);
					NavSpots.Add(navSpot);
				}
			}
			CloseTurnLeast = GetBool(c, "CloseTurnLeast", CloseTurnLeast);
			PeaceWhenIdle = GetBool(c, "PeaceWhenIdle", PeaceWhenIdle);
			HoverInfoOn = GetBool(c, "HoverInfoOn", HoverInfoOn);
			HoverInfoAskId = GetBool(c, "HoverInfoAskId", HoverInfoAskId);
			HoverLootRule = GetBool(c, "HoverLootRule", HoverLootRule);
			HoverDetails = GetBool(c, "HoverDetails", HoverDetails);
			HoverScore = GetBool(c, "HoverScore", HoverScore);
			HoverCompare = GetBool(c, "HoverCompare", HoverCompare);
			HoverColors = GetBool(c, "HoverColors", HoverColors);
			HoverItemType = (uint)GetInt(c, "HoverItemType", (int)HoverItemType);
			PeaceIdleS = GetFloat(c, "PeaceIdleS", PeaceIdleS);
			PeaceRightAway = GetBool(c, "PeaceRightAway", PeaceRightAway);
			PeaceOnlyNav = GetBool(c, "PeaceOnlyNav", PeaceOnlyNav);
			SkipBehindWalls = GetBool(c, "SkipBehindWalls", SkipBehindWalls);
			PreferAttacker = GetBool(c, "PreferAttacker", PreferAttacker);
			LootOnlyRare = GetBool(c, "LootOnlyRare", LootOnlyRare);
			LootRares = GetBool(c, "LootRares", LootRares);
			AutoStack = GetBool(c, "AutoStack", AutoStack);
			TimerOnPetHit = GetBool(c, "TimerOnPetHit", TimerOnPetHit);
			GhostCheck = GetBool(c, "GhostCheck", GhostCheck);
			GhostSeconds = GetFloat(c, "GhostSeconds", GhostSeconds);
			GhostSkipSeconds = GetFloat(c, "GhostSkipSeconds", GhostSkipSeconds);
			GhostHealthCounts = GetBool(c, "GhostHealthCounts", GhostHealthCounts);
			TimerOnSpread = GetBool(c, "TimerOnSpread", TimerOnSpread);
			AutoElementBySpecies = GetBool(c, "AutoElementBySpecies", AutoElementBySpecies);
			AutoSwitchMeleeMissile = GetBool(c, "AutoSwitchMeleeMissile", AutoSwitchMeleeMissile);
			DefaultShield = GetBool(c, "DefaultShield", DefaultShield);
			AreasEnabled = GetBool(c, "AreasEnabled", AreasEnabled);
			AreaLoadNav = GetBool(c, "AreaLoadNav", AreaLoadNav);
			AreasOnArrival = GetBool(c, "AreasOnArrival", AreasOnArrival);
			AreaLoadLoot = GetBool(c, "AreaLoadLoot", AreaLoadLoot);
			ManaTopUp = GetBool(c, "ManaTopUp", ManaTopUp);
			ManaTopUpPercent = GetInt(c, "ManaTopUpPercent", ManaTopUpPercent);
			ManaStoneNames = GetString(c, "ManaStoneNames", ManaStoneNames);
			Tuning.Load(c);
			AutoSalvage = GetBool(c, "AutoSalvage", AutoSalvage);
			AutoChunkAetheria = GetBool(c, "AutoChunkAetheria", AutoChunkAetheria);
			RevealAetheria = GetBool(c, "RevealAetheria", RevealAetheria);
			ChunkForce = GetBool(c, "ChunkForce", ChunkForce);
			ChunkWeapons = GetBool(c, "ChunkWeapons", ChunkWeapons);
			if (int.TryParse(GetString(c, "ChunkForceCount", ChunkForceCount.ToString()), out var result2))
			{
				ChunkForceCount = result2;
			}
			if (int.TryParse(GetString(c, "ChunkMaxLevel", ChunkMaxLevel.ToString()), out var result3))
			{
				ChunkMaxLevel = result3;
			}
			SalvagePartialBags = GetBool(c, "SalvagePartialBags", SalvagePartialBags);
			NavMode = GetInt(c, "NavMode", NavMode);
			FollowName = GetString(c, "FollowName", FollowName);
			FollowDist = GetFloat(c, "FollowDist", FollowDist);
			FollowPortals = GetBool(c, "FollowPortals", FollowPortals);
			FollowRing = GetBool(c, "FollowRing", FollowRing);
			FollowArrow = GetBool(c, "FollowArrow", FollowArrow);
			FollowExactPath = GetBool(c, "FollowExactPath", FollowExactPath);
			NavRouteShowAll = GetBool(c, "NavRouteShowAll", NavRouteShowAll);
			NavRouteShowNext = GetBool(c, "NavRouteShowNext", NavRouteShowNext);
			NavRouteArrow = GetBool(c, "NavRouteArrow", NavRouteArrow);
			NavTurnAngle = GetFloat(c, "NavTurnAngle", NavTurnAngle);
			NavSmoothSteer = GetBool(c, "NavSteerWhileRunning", NavSmoothSteer);
			NavMaxRunM = GetFloat(c, "NavMaxRunM", NavMaxRunM);
			NavSmoothSteerS = GetFloat(c, "NavSmoothSteerS", NavSmoothSteerS);
			NavSteerDeadband = GetFloat(c, "NavSteerDeadband", NavSteerDeadband);
			NavCloseDist = GetFloat(c, "NavCloseDist", NavCloseDist);
			NavCloseAngle = GetFloat(c, "NavCloseAngle", NavCloseAngle);
			NavRouteSelected = GetString(c, "NavRouteSelected", NavRouteSelected);
			NavRoutes.Clear();
			foreach (XmlNode item2 in c.SelectNodes("NavRoutes/Route"))
			{
				NavRoute navRoute = ReadRoute(item2 as XmlElement);
				if (navRoute != null)
				{
					NavRoutes.Add(navRoute);
				}
			}
			AreaLinks.Clear();
			foreach (XmlNode item3 in c.SelectNodes("Areas/Area"))
			{
				if (!(item3 is XmlElement xmlElement2) || xmlElement2.GetAttribute("name").Length == 0)
				{
					continue;
				}
				AreaLink areaLink = new AreaLink
				{
					Name = xmlElement2.GetAttribute("name"),
					Monster = xmlElement2.GetAttribute("monster"),
					Extra1 = xmlElement2.GetAttribute("extra1"),
					Extra2 = xmlElement2.GetAttribute("extra2"),
					Nav = xmlElement2.GetAttribute("nav")
				};
				areaLink.NavOn = bool.TryParse(xmlElement2.GetAttribute("navOn"), out var result4) & result4;
				areaLink.NavMode = (int.TryParse(xmlElement2.GetAttribute("navMode"), out var result5) ? result5 : (-1));
				areaLink.NavRoute = xmlElement2.GetAttribute("navRoute");
				areaLink.LootGeneral = !bool.TryParse(xmlElement2.GetAttribute("lootGeneral"), out result4) | result4;
				for (int i = 0; i < 5; i++)
				{
					areaLink.LootFiles[i] = xmlElement2.GetAttribute("loot" + i);
					areaLink.LootOns[i] = bool.TryParse(xmlElement2.GetAttribute("lootOn" + i), out result4) & result4;
				}
				string[] array = xmlElement2.GetAttribute("landblocks").Split(new char[1] { ',' }, StringSplitOptions.RemoveEmptyEntries);
				foreach (string text2 in array)
				{
					if (int.TryParse(text2.Trim(), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var result6))
					{
						areaLink.Landblocks.Add(result6);
					}
				}
				AreaLinks.Add(areaLink);
			}
			CloseTurnRange = GetFloat(c, "CloseTurnRange", CloseTurnRange);
			PetUseCombatRange = GetBool(c, "PetUseCombatRange", PetUseCombatRange);
			PetRangeMigrated = GetBool(c, "PetRangeMigrated", PetRangeMigrated);
			MonsterLogOn = GetBool(c, "MonsterLogOn", MonsterLogOn);
			DexCatch = GetBool(c, "DexCatch", DexCatch);
			DexLensFirst = GetBool(c, "DexLensFirst", DexLensFirst);
			DexAsheron = GetBool(c, "DexAsheron", DexAsheron);
			DexResonant = GetBool(c, "DexResonant", DexResonant);
			DexAsheronShiny = GetBool(c, "DexAsheronShiny", DexAsheronShiny);
			DexResonantShiny = GetBool(c, "DexResonantShiny", DexResonantShiny);
			DexCorruption = GetBool(c, "DexCorruption", DexCorruption);
			DexResonator = GetBool(c, "DexResonator", DexResonator);
			DexLens = GetInt(c, "DexLens", DexLens);
			DexCorruptionAbove = GetInt(c, "DexCorruptionAbove", DexCorruptionAbove);
			DexSkip = GetString(c, "DexSkip", DexSkip);
			LoadTrack(c);
			DexPetT11 = GetBool(c, "DexPetT11", DexPetT11);
			DexHoldPct = GetFloat(c, "DexHoldPct", DexHoldPct);
			DexGiveUpSecs = GetInt(c, "DexGiveUpSecs", DexGiveUpSecs);
			DexLensTries = GetInt(c, "DexLensTries", DexLensTries);
			DexLensGapMs = GetInt(c, "DexLensGapMs", DexLensGapMs);
			DexLensWaitMs = GetInt(c, "DexLensWaitMs", DexLensWaitMs);
			AugRatesFromTracker = GetBool(c, "AugRatesFromTracker", AugRatesFromTracker);
			BountyLumRate = GetBool(c, "BountyLumRate", BountyLumRate);
			LootSkipMaxedPct = GetInt(c, "LootSkipMaxedPct", LootSkipMaxedPct);
			AutoRelogOn = GetBool(c, "AutoRelogOn", AutoRelogOn);
			DayNightHudOn = GetBool(c, "DayNightHudOn", DayNightHudOn);
			AutoRelogGB = GetFloat(c, "AutoRelogGB", AutoRelogGB);
			AutoRelogWaitMin = GetInt(c, "AutoRelogWaitMin", AutoRelogWaitMin);
			MemLog = GetBool(c, "MemLog", MemLog);
			LumPopOut = GetBool(c, "LumPopOut", LumPopOut);
			MaxHpLog = GetBool(c, "MaxHpLog", MaxHpLog);
			MiniShow = GetBool(c, "MiniShow", MiniShow);
			UbNative = GetBool(c, "UbNative", UbNative);
			ServerKind = GetInt(c, "ServerKind", ServerKind);
			AllSpellLevels = GetBool(c, "AllSpellLevels", AllSpellLevels);
			SpellSkillMargin = GetInt(c, "SpellSkillMargin", SpellSkillMargin);
			CheckComponents = GetBool(c, "CheckComponents", CheckComponents);
			VideoKill = GetBool(c, "VideoKill", VideoKill);
			VideoKillBgOnly = GetBool(c, "VideoKillBgOnly", VideoKillBgOnly);
			NtEnabled = GetBool(c, "NtEnabled", NtEnabled);
			NtMaxRange = GetFloat(c, "NtMaxRange", NtMaxRange);
			NtStyles = GetString(c, "NtStyles", NtStyles);
			NtVulnIcon = GetBool(c, "NtVulnIcon", NtVulnIcon);
			NtVulnPos = GetInt(c, "NtVulnPos", NtVulnPos);
			NtVulnGap = GetFloat(c, "NtVulnGap", NtVulnGap);
			AttrAuto = GetBool(c, "AttrAuto", AttrAuto);
			BankPoll = GetBool(c, "BankPoll", BankPoll);
			BankPollMin = GetInt(c, "BankPollMin", BankPollMin);
			BankXferNames = GetString(c, "BankXferNames", BankXferNames);
			BankXferKind = GetString(c, "BankXferKind", BankXferKind);
			AttrIntervalMin = GetInt(c, "AttrIntervalMin", AttrIntervalMin);
			AttrOrder = GetString(c, "AttrOrder", AttrOrder);
			AttrOn = GetString(c, "AttrOn", AttrOn);
			ItemBarProfile = GetString(c, "ItemBarProfile", ItemBarProfile);
			ItemBarShow = GetBool(c, "ItemBarShow", ItemBarShow);
			ItemBarOpacity = GetFloat(c, "ItemBarOpacity", ItemBarOpacity);
			NavBoost = GetBool(c, "NavBoost", NavBoost);
			LootBoost = GetBool(c, "LootBoost", LootBoost);
			ItemBarScale = GetFloat(c, "ItemBarScale", ItemBarScale);
			CmpHoldWeapon = GetBool(c, "CmpHoldWeapon", CmpHoldWeapon);
			InvOn = GetBool(c, "InvOn", InvOn);
			InvUpdateMin = GetInt(c, "InvUpdateMin", InvUpdateMin);
			InvFolder = GetString(c, "InvFolder", InvFolder);
			VendorPayWithNotes = GetBool(c, "VendorPayWithNotes", VendorPayWithNotes);
			VendorAutoOnOpen = GetBool(c, "VendorAutoOnOpen", VendorAutoOnOpen);
			VendorBankChange = GetBool(c, "VendorBankChange", VendorBankChange);
			VendorKeepLoose = GetInt(c, "VendorKeepLoose", VendorKeepLoose);
			VendorBankAbove = GetInt(c, "VendorBankAbove", VendorBankAbove);
			VendorNoteSize = GetInt(c, "VendorNoteSize", VendorNoteSize);
			VendorMaxSpend = GetInt(c, "VendorMaxSpend", VendorMaxSpend);
			VendorFloor = GetInt(c, "VendorFloor", VendorFloor);
			VendorDryRun = GetBool(c, "VendorDryRun", VendorDryRun);
			VendorSayBuyList = GetBool(c, "VendorSayBuyList", VendorSayBuyList);
			VendorSayBought = GetBool(c, "VendorSayBought", VendorSayBought);
			VendorNotesPerSale = GetInt(c, "VendorNotesPerSale", VendorNotesPerSale);
			VendorIltDeposit = GetBool(c, "VendorIltDeposit", VendorIltDeposit);
			VendorNpc = GetString(c, "VendorNpc", VendorNpc);
			VendorProfile = GetString(c, "VendorProfile", VendorProfile);
			CmpCombatOnStart = GetBool(c, "CmpCombatOnStart", CmpCombatOnStart);
			CmpCombatOffEnd = GetBool(c, "CmpCombatOffEnd", CmpCombatOffEnd);
			CmpCombatOffCorrosion = GetBool(c, "CmpCombatOffCorrosion", CmpCombatOffCorrosion);
			PortalGems = GetString(c, "PortalGems", PortalGems);
			LootModeEnabled = GetBool(c, "LootModeEnabled", LootModeEnabled);
			LootModeRange = GetFloat(c, "LootModeRange", LootModeRange);
			LootModeCorpses = GetInt(c, "LootModeCorpses", LootModeCorpses);
			LootProfileDir = GetString(c, "LootProfileDir", LootProfileDir);
			LootProfile = GetString(c, "LootProfile", LootProfile);
			LootUseGeneral = GetBool(c, "LootUseGeneral", LootUseGeneral);
			LootMiscOn = GetBool(c, "LootMiscOn", LootMiscOn);
			LootArmorOn = GetBool(c, "LootArmorOn", LootArmorOn);
			LootWeaponOn = GetBool(c, "LootWeaponOn", LootWeaponOn);
			LootSalvageOn = GetBool(c, "LootSalvageOn", LootSalvageOn);
			LootMiscProfile = GetString(c, "LootMiscProfile", LootMiscProfile);
			LootArmorProfile = GetString(c, "LootArmorProfile", LootArmorProfile);
			LootWeaponProfile = GetString(c, "LootWeaponProfile", LootWeaponProfile);
			LootSalvageProfile = GetString(c, "LootSalvageProfile", LootSalvageProfile);
			LootAnnounce = GetBool(c, "LootAnnounce", LootAnnounce);
			IdAnnounce = GetBool(c, "IdAnnounce", IdAnnounce);
			IdMobs = GetBool(c, "IdMobs", IdMobs);
			IdPlayers = GetBool(c, "IdPlayers", IdPlayers);
			IdChatWindow = Math.Max(0, Math.Min(4, GetInt(c, "IdChatWindow", IdChatWindow)));
			IdCompare = GetBool(c, "IdCompare", IdCompare);
			CompareKeepSpecial = GetBool(c, "CompareKeepSpecial", CompareKeepSpecial);
			LootMainWeapon = GetBool(c, "LootMainWeapon", LootMainWeapon);
			Items.Clear();
			foreach (XmlNode item4 in c.SelectNodes("Items/Item"))
			{
				WeaponItem weaponItem = new WeaponItem();
				weaponItem.Id = GetInt(item4, "Id", 0);
				weaponItem.Name = GetString(item4, "Name", "");
				weaponItem.Kind = (WeaponKind)GetInt(item4, "Kind", 0);
				weaponItem.Element = (DmgType)GetInt(item4, "Element", 0);
				weaponItem.IsShield = GetBool(item4, "IsShield", def: false);
				weaponItem.CompareTo = GetBool(item4, "CompareTo", def: false);
				if (weaponItem.Id != 0)
				{
					Items.Add(weaponItem);
				}
			}
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Load settings error: " + ex.Message);
		}
	}

	private void SaveCharacter(string charKey)
	{
		PackSettings.SettingsSaved();
		Util.Locked(Util.FullPath("MelkTank_Settings.xml"), () =>
		{
			SaveCharacterLocked(charKey);
		});
	}

	private void SaveCharacterLocked(string charKey)
	{
		try
		{
			string path = Util.FullPath("MelkTank_Settings.xml");
			XmlDocument xmlDocument = new XmlDocument();
			XmlElement xmlElement;
			if (File.Exists(path))
			{
				Util.LoadXml(xmlDocument, path);
				xmlElement = xmlDocument.DocumentElement;
			}
			else
			{
				xmlElement = xmlDocument.CreateElement("MelkTank");
				xmlDocument.AppendChild(xmlElement);
			}
			XmlNode xmlNode = xmlElement.SelectSingleNode("Character[@key=" + XPathLiteral(charKey) + "]");
			XmlNode oldOwnList = xmlNode?.SelectSingleNode("Monsters");
			if (xmlNode != null)
			{
				xmlElement.RemoveChild(xmlNode);
			}
			XmlElement xmlElement2 = BuildCharacter(xmlDocument, charKey, oldOwnList);
			xmlElement.AppendChild(xmlElement2);
			Util.SaveXml(xmlDocument, path);
			try
			{
				LiveSettings.Mirror(this, xmlElement2);
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
		}
		catch (Exception ex2)
		{
			Util.WriteToChat("Save settings error: " + ex2.Message);
		}
	}

	private XmlElement BuildCharacter(XmlDocument doc, string charKey, XmlNode oldOwnList)
	{
		XmlElement xmlElement = doc.CreateElement("Character");
		xmlElement.SetAttribute("key", charKey);
		Put(doc, xmlElement, "MasterEnabled", TravelKeep ? TKMaster : MasterEnabled);
		Put(doc, xmlElement, "CombatEnabled", (TravelKeep && !CombatEnabled) ? TKCombat : CombatEnabled);
		Put(doc, xmlElement, "AttackRange", AttackRange);
		Put(doc, xmlElement, "ApproachRange", ApproachRange);
		Put(doc, xmlElement, "RefreshDots", RefreshDots);
		Put(doc, xmlElement, "FractureDelayS", FractureDelayS);
		Put(doc, xmlElement, "FractureMinOn", FractureMinOn);
		Put(doc, xmlElement, "FractureMin", FractureMin);
		Put(doc, xmlElement, "FractureReprime", FractureReprime);
		Put(doc, xmlElement, "FractureAll", FractureAll);
		Put(doc, xmlElement, "PrimeEveryNF", PrimeEveryNF);
		Put(doc, xmlElement, "StreakPrimed", StreakPrimed);
		Put(doc, xmlElement, "StreakDotted", StreakDotted);
		Put(doc, xmlElement, "PrimeFocus", PrimeFocus);
		Put(doc, xmlElement, "PrimeHigh", PrimeHigh);
		Put(doc, xmlElement, "PrimeHighMin", PrimeHighMin);
		Put(doc, xmlElement, "PrimeOnePerWand", PrimeOnePerWand);
		Put(doc, xmlElement, "RePrimeFresh", RePrimeFresh);
		Put(doc, xmlElement, "TrustSpread", TrustSpread);
		Put(doc, xmlElement, "TrustSpreadM", TrustSpreadM);
		Put(doc, xmlElement, "TrustSpreadMax", TrustSpreadMax);
		Put(doc, xmlElement, "UseDotLines", UseDotLines);
		Put(doc, xmlElement, "BountyHudOn", BountyHudOn);
		Put(doc, xmlElement, "BountyMinutes", BountyMinutes);
		Put(doc, xmlElement, "BountyShowKts", BountyShowKts);
		Put(doc, xmlElement, "RefreshVulns", RefreshVulns);
		Put(doc, xmlElement, "RefreshLeadSeconds", RefreshLeadSeconds);
		Put(doc, xmlElement, "DebuffAllFirst", DebuffAllFirst);
		Put(doc, xmlElement, "FewerWeaponSwaps", FewerWeaponSwaps);
		Put(doc, xmlElement, "TellLog", TellLog);
		Put(doc, xmlElement, "TellKeep", TellKeep);
		Put(doc, xmlElement, "GiverInBar", GiverInBar);
		Put(doc, xmlElement, "PortalBarGems", PortalBarGems);
		Put(doc, xmlElement, "PortalBarShow", PortalBarShow);
		Put(doc, xmlElement, "PortalBarScale", PortalBarScale);
		Put(doc, xmlElement, "PortalBarCols", PortalBarCols);
		Put(doc, xmlElement, "OpenPackAtLogin", OpenPackAtLogin);
		Put(doc, xmlElement, "BadItemAutoRemove", BadItemAutoRemove);
		Put(doc, xmlElement, "BadItemNotify", BadItemNotify);
		Put(doc, xmlElement, "LootChests", LootChests);
		Put(doc, xmlElement, "ResMaxReserve", ResMaxReserve);
		Put(doc, xmlElement, "TrackPickup", TrackPickup);
		Put(doc, xmlElement, "DetourStopsForCombat", DetourStopsForCombat);
		Put(doc, xmlElement, "LootQbStamps", LootQbStamps);
		Put(doc, xmlElement, "CheckChests", CheckChests);
		Put(doc, xmlElement, "ChestSummary", ChestSummary);
		Put(doc, xmlElement, "AutoChests", AutoChests);
		Put(doc, xmlElement, "ChestPickLocks", ChestPickLocks);
		Put(doc, xmlElement, "ChatFilterOn", ChatFilterOn);
		Put(doc, xmlElement, "VtStandIn", VtStandIn);
		Put(doc, xmlElement, "VtStandInVirindi", VtStandInVirindi);
		Put(doc, xmlElement, "VtCommands", VtCommands);
		Put(doc, xmlElement, "MtCommands", MtCommands);
		Put(doc, xmlElement, "AutoYes100", AutoYes100);
		Put(doc, xmlElement, "VtLiveUb", VtLiveUb);
		Put(doc, xmlElement, "OwnExpr", OwnExpr);
		Put(doc, xmlElement, "VtUbLootWatch", VtUbLootWatch);
		ApplyVt();
		Put(doc, xmlElement, "ConfirmSwaps", ConfirmSwaps);
		Put(doc, xmlElement, "PreEquipOnApproach", PreEquipOnApproach);
		Put(doc, xmlElement, "Level1Dot", Level1Dot);
		Put(doc, xmlElement, "Level1Vuln", Level1Vuln);
		Put(doc, xmlElement, "Level1War", Level1War);
		Put(doc, xmlElement, "Level1Void", Level1Void);
		Put(doc, xmlElement, "RingLevel1", RingLevel1);
		Put(doc, xmlElement, "UseBolts", UseBolts);
		Put(doc, xmlElement, "RingMinMonsters", RingMinMonsters);
		Put(doc, xmlElement, "RingRadius", RingRadius);
		Put(doc, xmlElement, "DefaultAttack", (int)DefaultAttack);
		Put(doc, xmlElement, "AttackKeyIndex", AttackKeyIndex);
		Put(doc, xmlElement, "AttackPower", AttackPower);
		Put(doc, xmlElement, "AttackHeight", AttackHeight);
		Put(doc, xmlElement, "UseMagicForDebuffsOnly", UseMagicForDebuffsOnly);
		Put(doc, xmlElement, "HoldVTankNav", HoldVTankNav);
		Put(doc, xmlElement, "DebugLog", DebugLog);
		Put(doc, xmlElement, "CastRecoveryMs", CastRecoveryMs);
		Put(doc, xmlElement, "DurationAugs", DurationAugs);
		Put(doc, xmlElement, "CalibBaseMinutes", CalibBaseMinutes);
		Put(doc, xmlElement, "CalibObservedMinutes", CalibObservedMinutes);
		Put(doc, xmlElement, "DebuffMultiplier", DebuffMultiplier);
		Put(doc, xmlElement, "MelksBufferEnabled", MelksBufferEnabled);
		Put(doc, xmlElement, "MelksPetEnabled", MelksPetEnabled);
		Put(doc, xmlElement, "PetUseMelkTankInfo", PetUseMelkTankInfo);
		Put(doc, xmlElement, "PetRangeOverride", PetRangeOverride);
		Put(doc, xmlElement, "PetOnlyInCombat", PetOnlyInCombat);
		Put(doc, xmlElement, "PetDmgCommas", PetDmgCommas);
		Put(doc, xmlElement, "PetNoSummonInFight", PetNoSummonInFight);
		Put(doc, xmlElement, "PetRechargeBetweenPacks", PetRechargeBetweenPacks);
		Put(doc, xmlElement, "PetRange", PetRange);
		Put(doc, xmlElement, "BufferOnCommand", BufferOnCommand);
		Put(doc, xmlElement, "BufferOffCommand", BufferOffCommand);
		Put(doc, xmlElement, "PetOnCommand", PetOnCommand);
		Put(doc, xmlElement, "FellowAuto", FellowAuto);
		Put(doc, xmlElement, "FellowOpenOnCreate", FellowOpenOnCreate);
		Put(doc, xmlElement, "FellowRelock", FellowRelock);
		Put(doc, xmlElement, "FmOn", FmOn);
		Put(doc, xmlElement, "FmWaitList", FmWaitList);
		Put(doc, xmlElement, "FmVoteKick", FmVoteKick);
		Put(doc, xmlElement, "FmVoteBan", FmVoteBan);
		Put(doc, xmlElement, "FmVoteLeader", FmVoteLeader);
		Put(doc, xmlElement, "FmVoteOpen", FmVoteOpen);
		Put(doc, xmlElement, "NavOpenDoors", NavOpenDoors);
		Put(doc, xmlElement, "MetaLast", MetaLast);
		Put(doc, xmlElement, "MetaOpenLast", MetaOpenLast);
		Put(doc, xmlElement, "MetaRun", MetaRun);
		Put(doc, xmlElement, "MetaSameRestarts", MetaSameRestarts);
		Put(doc, xmlElement, "MetaVtankDir", MetaVtankDir);
		Put(doc, xmlElement, "DispelOn", DispelOn);
		Put(doc, xmlElement, "DispelCooldownS", DispelCooldownS);
		Put(doc, xmlElement, "DispelIgnore", DispelIgnore);
		Put(doc, xmlElement, "Charms", Charms);
		Put(doc, xmlElement, "CharmGemAutoBuy", CharmGemAutoBuy);
		Put(doc, xmlElement, "PackRules", PackRules);
		if (PackSubs != _subsShared)
		{
			WriteSharedSubs(PackSubs);
			_subsShared = PackSubs;
		}
		Put(doc, xmlElement, "PackSubs", PackSubs);
		Put(doc, xmlElement, "PackOrgOn", PackOrgOn);
		Put(doc, xmlElement, "PackMerge", PackMerge);
		Put(doc, xmlElement, "PerfLog", PerfLog);
		Put(doc, xmlElement, "AugNoSingles", AugNoSingles);
		Put(doc, xmlElement, "PackRulesSeeded", PackRulesSeeded);
		Put(doc, xmlElement, "NavDoorRange", NavDoorRange);
		Put(doc, xmlElement, "NavPickLocks", NavPickLocks);
		Put(doc, xmlElement, "NavLockpickMargin", NavLockpickMargin);
		Put(doc, xmlElement, "CountLumTokens", CountLumTokens);
		Put(doc, xmlElement, "LumTokenB", LumTokenB);
		Put(doc, xmlElement, "AutoUseAttackGems", AutoUseAttackGems);
		Put(doc, xmlElement, "FellowKeywords", FellowKeywords);
		Put(doc, xmlElement, "FellowScan", FellowScan);
		Put(doc, xmlElement, "FellowScanRange", FellowScanRange);
		Put(doc, xmlElement, "FellowLandblock", FellowLandblock);
		Put(doc, xmlElement, "FellowLandblockMin", FellowLandblockMin);
		Put(doc, xmlElement, "FellowIgnore", FellowIgnore);
		Put(doc, xmlElement, "FellowCreate", FellowCreate);
		Put(doc, xmlElement, "FellowName", FellowName);
		Put(doc, xmlElement, "PetOffCommand", PetOffCommand);
		Put(doc, xmlElement, "ActiveProfile", ActiveProfile);
		Put(doc, xmlElement, "ExtraProfile1", ExtraProfile[0]);
		Put(doc, xmlElement, "ExtraProfile2", ExtraProfile[1]);
		Put(doc, xmlElement, "HealEnabled", HealEnabled);
		Put(doc, xmlElement, "HealPercent", HealPercent);
		Put(doc, xmlElement, "HealKitId", HealKitId);
		Put(doc, xmlElement, "HealKitName", HealKitName);
		Put(doc, xmlElement, "MaxHealthLowTier", MaxHealthLowTier);
		Put(doc, xmlElement, "MaxHealthHighTier", MaxHealthHighTier);
		Put(doc, xmlElement, "ManaEnabled", ManaEnabled);
		Put(doc, xmlElement, "ManaPercent", ManaPercent);
		Put(doc, xmlElement, "ManaMode", ManaMode);
		Put(doc, xmlElement, "ManaItemId", ManaItemId);
		Put(doc, xmlElement, "ManaItemName", ManaItemName);
		Put(doc, xmlElement, "StaminaEnabled", StaminaEnabled);
		Put(doc, xmlElement, "StaminaPercent", StaminaPercent);
		Put(doc, xmlElement, "StaminaMode", StaminaMode);
		Put(doc, xmlElement, "StaminaItemId", StaminaItemId);
		Put(doc, xmlElement, "StaminaItemName", StaminaItemName);
		Put(doc, xmlElement, "DeathStopCombat", DeathStopCombat);
		Put(doc, xmlElement, "DeathStopBuff", DeathStopBuff);
		Put(doc, xmlElement, "DeathStopLoot", DeathStopLoot);
		Put(doc, xmlElement, "DeathStopPet", DeathStopPet);
		Put(doc, xmlElement, "TrackMaxRange", TrackMaxRange);
		Put(doc, xmlElement, "TrackPopOut", TrackPopOut);
		Put(doc, xmlElement, "TuneOut", TuneOut ?? "");
		Put(doc, xmlElement, "LootEnabled", LootEnabled);
		Put(doc, xmlElement, "LootRange", LootRange);
		Put(doc, xmlElement, "LootFellowKills", LootFellowKills);
		Put(doc, xmlElement, "LootOwnCorpse", LootOwnCorpse);
		Put(doc, xmlElement, "ShinySameAsBase", ShinySameAsBase);
		Put(doc, xmlElement, "AutoStack", AutoStack);
		Put(doc, xmlElement, "TimerOnPetHit", TimerOnPetHit);
		Put(doc, xmlElement, "GhostCheck", GhostCheck);
		Put(doc, xmlElement, "GhostSeconds", GhostSeconds);
		Put(doc, xmlElement, "GhostSkipSeconds", GhostSkipSeconds);
		Put(doc, xmlElement, "GhostHealthCounts", GhostHealthCounts);
		Put(doc, xmlElement, "TimerOnSpread", TimerOnSpread);
		Put(doc, xmlElement, "AutoElementBySpecies", AutoElementBySpecies);
		Put(doc, xmlElement, "AutoSwitchMeleeMissile", AutoSwitchMeleeMissile);
		Put(doc, xmlElement, "DefaultShield", DefaultShield);
		Put(doc, xmlElement, "AreasEnabled", AreasEnabled);
		Put(doc, xmlElement, "AreaLoadNav", AreaLoadNav);
		Put(doc, xmlElement, "AreasOnArrival", AreasOnArrival);
		Put(doc, xmlElement, "AreaLoadLoot", AreaLoadLoot);
		Put(doc, xmlElement, "ManaTopUp", ManaTopUp);
		Put(doc, xmlElement, "ManaTopUpPercent", ManaTopUpPercent);
		Put(doc, xmlElement, "ManaStoneNames", ManaStoneNames);
		Tuning.Save(doc, xmlElement);
		Put(doc, xmlElement, "AutoSalvage", AutoSalvage);
		Put(doc, xmlElement, "AutoChunkAetheria", AutoChunkAetheria);
		Put(doc, xmlElement, "RevealAetheria", RevealAetheria);
		Put(doc, xmlElement, "ChunkForce", ChunkForce);
		Put(doc, xmlElement, "ChunkWeapons", ChunkWeapons);
		Put(doc, xmlElement, "ChunkForceCount", ChunkForceCount.ToString());
		Put(doc, xmlElement, "ChunkMaxLevel", ChunkMaxLevel.ToString());
		Put(doc, xmlElement, "SalvagePartialBags", SalvagePartialBags);
		Put(doc, xmlElement, "NavMode", TravelKeep ? TKNavMode : NavMode);
		Put(doc, xmlElement, "FollowName", FollowName);
		Put(doc, xmlElement, "FollowDist", FollowDist);
		Put(doc, xmlElement, "FollowPortals", FollowPortals);
		Put(doc, xmlElement, "FollowRing", FollowRing);
		Put(doc, xmlElement, "FollowArrow", FollowArrow);
		Put(doc, xmlElement, "FollowExactPath", FollowExactPath);
		Put(doc, xmlElement, "NavRouteShowAll", NavRouteShowAll);
		Put(doc, xmlElement, "NavRouteShowNext", NavRouteShowNext);
		Put(doc, xmlElement, "NavRouteArrow", NavRouteArrow);
		Put(doc, xmlElement, "NavTurnAngle", NavTurnAngle);
		Put(doc, xmlElement, "NavSteerWhileRunning", NavSmoothSteer);
		Put(doc, xmlElement, "NavMaxRunM", NavMaxRunM);
		Put(doc, xmlElement, "NavSteerDeadband", NavSteerDeadband);
		Put(doc, xmlElement, "NavCloseDist", NavCloseDist);
		Put(doc, xmlElement, "NavCloseAngle", NavCloseAngle);
		Put(doc, xmlElement, "NavRouteSelected", TravelKeep ? TKNavRoute : NavRouteSelected);
		XmlElement xmlElement2 = doc.CreateElement("NavRoutes");
		xmlElement.AppendChild(xmlElement2);
		foreach (NavRoute navRoute in NavRoutes)
		{
			XmlElement xmlElement3 = doc.CreateElement("Route");
			WriteRoute(doc, xmlElement3, navRoute);
			xmlElement2.AppendChild(xmlElement3);
		}
		XmlElement xmlElement4 = doc.CreateElement("Areas");
		xmlElement.AppendChild(xmlElement4);
		foreach (AreaLink areaLink in AreaLinks)
		{
			XmlElement xmlElement5 = doc.CreateElement("Area");
			xmlElement5.SetAttribute("name", areaLink.Name);
			xmlElement5.SetAttribute("monster", areaLink.Monster);
			xmlElement5.SetAttribute("extra1", areaLink.Extra1);
			xmlElement5.SetAttribute("extra2", areaLink.Extra2);
			xmlElement5.SetAttribute("nav", areaLink.Nav);
			xmlElement5.SetAttribute("navOn", areaLink.NavOn.ToString());
			xmlElement5.SetAttribute("lootGeneral", areaLink.LootGeneral.ToString());
			if (areaLink.NavMode >= 0)
			{
				xmlElement5.SetAttribute("navMode", areaLink.NavMode.ToString());
				xmlElement5.SetAttribute("navRoute", areaLink.NavRoute ?? "");
			}
			for (int i = 0; i < 5; i++)
			{
				xmlElement5.SetAttribute("loot" + i, areaLink.LootFiles[i] ?? "");
				xmlElement5.SetAttribute("lootOn" + i, areaLink.LootOns[i].ToString());
			}
			List<string> list = new List<string>();
			foreach (int landblock in areaLink.Landblocks)
			{
				list.Add(landblock.ToString("X4"));
			}
			xmlElement5.SetAttribute("landblocks", string.Join(",", list.ToArray()));
			xmlElement4.AppendChild(xmlElement5);
		}
		Put(doc, xmlElement, "NavSelected", NavSelected);
		Put(doc, xmlElement, "NavEnabled", TravelKeep ? TKNav : NavEnabled);
		Put(doc, xmlElement, "MetaTurnedNavOn", MetaTurnedNavOn);
		Put(doc, xmlElement, "NavChamberSpots", NavChamberSpots);
		Put(doc, xmlElement, "NavPriority", NavPriority);
		Put(doc, xmlElement, "NavFaceHeading", NavFaceHeading);
		Put(doc, xmlElement, "NavShowMarker", NavShowMarker);
		Put(doc, xmlElement, "NavArrow", NavArrow);
		Put(doc, xmlElement, "NavDrift", NavDrift);
		Put(doc, xmlElement, "NavHideUnfocused", NavHideUnfocused);
		Put(doc, xmlElement, "LoginWindows", LoginWindows);
		XmlElement xmlElement6 = doc.CreateElement("NavSpots");
		xmlElement.AppendChild(xmlElement6);
		foreach (NavSpot navSpot in NavSpots)
		{
			XmlElement xmlElement7 = doc.CreateElement("Spot");
			xmlElement7.SetAttribute("name", navSpot.Name);
			xmlElement7.SetAttribute("ns", navSpot.NS.ToString("R", CultureInfo.InvariantCulture));
			xmlElement7.SetAttribute("ew", navSpot.EW.ToString("R", CultureInfo.InvariantCulture));
			xmlElement7.SetAttribute("z", navSpot.Z.ToString("R", CultureInfo.InvariantCulture));
			xmlElement7.SetAttribute("heading", navSpot.Heading.ToString("R", CultureInfo.InvariantCulture));
			xmlElement7.SetAttribute("face", navSpot.FaceHeading.ToString());
			if (!string.IsNullOrEmpty(navSpot.File))
			{
				xmlElement7.SetAttribute("file", navSpot.File);
			}
			xmlElement6.AppendChild(xmlElement7);
		}
		Put(doc, xmlElement, "CloseTurnLeast", CloseTurnLeast);
		Put(doc, xmlElement, "PeaceWhenIdle", PeaceWhenIdle);
		Put(doc, xmlElement, "HoverInfoOn", HoverInfoOn);
		Put(doc, xmlElement, "HoverInfoAskId", HoverInfoAskId);
		Put(doc, xmlElement, "HoverLootRule", HoverLootRule);
		Put(doc, xmlElement, "HoverDetails", HoverDetails);
		Put(doc, xmlElement, "HoverScore", HoverScore);
		Put(doc, xmlElement, "HoverCompare", HoverCompare);
		Put(doc, xmlElement, "HoverColors", HoverColors);
		Put(doc, xmlElement, "HoverItemType", (int)HoverItemType);
		Put(doc, xmlElement, "PeaceIdleS", PeaceIdleS);
		Put(doc, xmlElement, "PeaceRightAway", PeaceRightAway);
		Put(doc, xmlElement, "PeaceOnlyNav", PeaceOnlyNav);
		Put(doc, xmlElement, "SkipBehindWalls", SkipBehindWalls);
		Put(doc, xmlElement, "PreferAttacker", PreferAttacker);
		Put(doc, xmlElement, "LootOnlyRare", LootOnlyRare);
		Put(doc, xmlElement, "LootRares", LootRares);
		Put(doc, xmlElement, "CloseTurnRange", CloseTurnRange);
		Put(doc, xmlElement, "PetUseCombatRange", PetUseCombatRange);
		Put(doc, xmlElement, "PetRangeMigrated", PetRangeMigrated);
		Put(doc, xmlElement, "MonsterLogOn", MonsterLogOn);
		Put(doc, xmlElement, "DexCatch", DexCatch);
		Put(doc, xmlElement, "DexLensFirst", DexLensFirst);
		Put(doc, xmlElement, "DexAsheron", DexAsheron);
		Put(doc, xmlElement, "DexResonant", DexResonant);
		Put(doc, xmlElement, "DexAsheronShiny", DexAsheronShiny);
		Put(doc, xmlElement, "DexResonantShiny", DexResonantShiny);
		Put(doc, xmlElement, "DexCorruption", DexCorruption);
		Put(doc, xmlElement, "DexResonator", DexResonator);
		Put(doc, xmlElement, "DexLens", DexLens);
		Put(doc, xmlElement, "DexCorruptionAbove", DexCorruptionAbove);
		Put(doc, xmlElement, "DexSkip", DexSkip ?? "");
		Put(doc, xmlElement, "DexPetT11", DexPetT11);
		Put(doc, xmlElement, "DexHoldPct", DexHoldPct);
		Put(doc, xmlElement, "DexGiveUpSecs", DexGiveUpSecs);
		Put(doc, xmlElement, "DexLensTries", DexLensTries);
		Put(doc, xmlElement, "DexLensGapMs", DexLensGapMs);
		Put(doc, xmlElement, "DexLensWaitMs", DexLensWaitMs);
		Put(doc, xmlElement, "AugRatesFromTracker", AugRatesFromTracker);
		Put(doc, xmlElement, "BountyLumRate", BountyLumRate);
		Put(doc, xmlElement, "LootSkipMaxedPct", LootSkipMaxedPct);
		Put(doc, xmlElement, "AutoRelogOn", AutoRelogOn);
		Put(doc, xmlElement, "DayNightHudOn", DayNightHudOn);
		Put(doc, xmlElement, "AutoRelogGB", AutoRelogGB);
		Put(doc, xmlElement, "AutoRelogWaitMin", AutoRelogWaitMin);
		Put(doc, xmlElement, "MemLog", MemLog);
		Put(doc, xmlElement, "LumPopOut", LumPopOut);
		Put(doc, xmlElement, "MaxHpLog", MaxHpLog);
		Put(doc, xmlElement, "MiniShow", MiniShow);
		Put(doc, xmlElement, "UbNative", UbNative);
		Put(doc, xmlElement, "ServerKind", ServerKind);
		Put(doc, xmlElement, "AllSpellLevels", AllSpellLevels);
		Put(doc, xmlElement, "SpellSkillMargin", SpellSkillMargin);
		Put(doc, xmlElement, "CheckComponents", CheckComponents);
		Put(doc, xmlElement, "VideoKill", VideoKill);
		Put(doc, xmlElement, "VideoKillBgOnly", VideoKillBgOnly);
		Put(doc, xmlElement, "NtEnabled", NtEnabled);
		Put(doc, xmlElement, "NtMaxRange", NtMaxRange);
		Put(doc, xmlElement, "NtStyles", NtStyles);
		Put(doc, xmlElement, "NtVulnIcon", NtVulnIcon);
		Put(doc, xmlElement, "NtVulnPos", NtVulnPos);
		Put(doc, xmlElement, "NtVulnGap", NtVulnGap);
		Put(doc, xmlElement, "AttrAuto", AttrAuto);
		Put(doc, xmlElement, "BankPoll", BankPoll);
		Put(doc, xmlElement, "BankPollMin", BankPollMin);
		Put(doc, xmlElement, "BankXferNames", BankXferNames);
		Put(doc, xmlElement, "BankXferKind", BankXferKind);
		Put(doc, xmlElement, "AttrIntervalMin", AttrIntervalMin);
		Put(doc, xmlElement, "AttrOrder", AttrOrder);
		Put(doc, xmlElement, "AttrOn", AttrOn);
		Put(doc, xmlElement, "ItemBarProfile", ItemBarProfile);
		Put(doc, xmlElement, "ItemBarShow", ItemBarShow);
		Put(doc, xmlElement, "ItemBarOpacity", ItemBarOpacity);
		Put(doc, xmlElement, "NavBoost", NavBoost);
		Put(doc, xmlElement, "LootBoost", LootBoost);
		Put(doc, xmlElement, "ItemBarScale", ItemBarScale);
		Put(doc, xmlElement, "CmpHoldWeapon", CmpHoldWeapon);
		Put(doc, xmlElement, "InvOn", InvOn);
		Put(doc, xmlElement, "InvUpdateMin", InvUpdateMin);
		Put(doc, xmlElement, "InvFolder", InvFolder);
		Put(doc, xmlElement, "VendorPayWithNotes", VendorPayWithNotes);
		Put(doc, xmlElement, "VendorAutoOnOpen", VendorAutoOnOpen);
		Put(doc, xmlElement, "VendorBankChange", VendorBankChange);
		Put(doc, xmlElement, "VendorKeepLoose", VendorKeepLoose);
		Put(doc, xmlElement, "VendorBankAbove", VendorBankAbove);
		Put(doc, xmlElement, "VendorNoteSize", VendorNoteSize);
		Put(doc, xmlElement, "VendorMaxSpend", VendorMaxSpend);
		Put(doc, xmlElement, "VendorFloor", VendorFloor);
		Put(doc, xmlElement, "VendorDryRun", VendorDryRun);
		Put(doc, xmlElement, "VendorSayBuyList", VendorSayBuyList);
		Put(doc, xmlElement, "VendorSayBought", VendorSayBought);
		Put(doc, xmlElement, "VendorNotesPerSale", VendorNotesPerSale);
		Put(doc, xmlElement, "VendorIltDeposit", VendorIltDeposit);
		Put(doc, xmlElement, "VendorNpc", VendorNpc);
		Put(doc, xmlElement, "VendorProfile", VendorProfile);
		Put(doc, xmlElement, "CmpCombatOnStart", CmpCombatOnStart);
		Put(doc, xmlElement, "CmpCombatOffEnd", CmpCombatOffEnd);
		Put(doc, xmlElement, "CmpCombatOffCorrosion", CmpCombatOffCorrosion);
		Put(doc, xmlElement, "PortalGems", PortalGems);
		Put(doc, xmlElement, "LootModeEnabled", LootModeEnabled);
		Put(doc, xmlElement, "LootModeRange", LootModeRange);
		Put(doc, xmlElement, "LootModeCorpses", LootModeCorpses);
		Put(doc, xmlElement, "LootProfileDir", LootProfileDir);
		Put(doc, xmlElement, "LootProfile", LootProfile);
		Put(doc, xmlElement, "LootUseGeneral", LootUseGeneral);
		Put(doc, xmlElement, "LootMiscOn", LootMiscOn);
		Put(doc, xmlElement, "LootArmorOn", LootArmorOn);
		Put(doc, xmlElement, "LootWeaponOn", LootWeaponOn);
		Put(doc, xmlElement, "LootSalvageOn", LootSalvageOn);
		Put(doc, xmlElement, "LootMiscProfile", LootMiscProfile);
		Put(doc, xmlElement, "LootArmorProfile", LootArmorProfile);
		Put(doc, xmlElement, "LootWeaponProfile", LootWeaponProfile);
		Put(doc, xmlElement, "LootSalvageProfile", LootSalvageProfile);
		Put(doc, xmlElement, "LootAnnounce", LootAnnounce);
		Put(doc, xmlElement, "IdAnnounce", IdAnnounce);
		Put(doc, xmlElement, "IdMobs", IdMobs);
		Put(doc, xmlElement, "IdPlayers", IdPlayers);
		Put(doc, xmlElement, "IdChatWindow", IdChatWindow);
		Put(doc, xmlElement, "IdCompare", IdCompare);
		Put(doc, xmlElement, "CompareKeepSpecial", CompareKeepSpecial);
		Put(doc, xmlElement, "LootMainWeapon", LootMainWeapon);
		XmlElement xmlElement8 = doc.CreateElement("Items");
		xmlElement.AppendChild(xmlElement8);
		foreach (WeaponItem item in Items)
		{
			XmlElement xmlElement9 = doc.CreateElement("Item");
			Put(doc, xmlElement9, "Id", item.Id);
			Put(doc, xmlElement9, "Name", item.Name);
			Put(doc, xmlElement9, "Kind", (int)item.Kind);
			Put(doc, xmlElement9, "Element", (int)item.Element);
			Put(doc, xmlElement9, "IsShield", item.IsShield);
			if (item.CompareTo)
			{
				Put(doc, xmlElement9, "CompareTo", true);
			}
			xmlElement8.AppendChild(xmlElement9);
		}
		Put(doc, xmlElement, "TrackProfile", TrackProfile ?? "");
		PutList(doc, xmlElement, "TrackList", (TrackProfile.Length == 0) ? TrackItems : _ownTrack);
		PutList(doc, xmlElement, "TrackLive", TrackItems);
		PutList(doc, xmlElement, "TrackProfiles", string.Join("\n", ListTrackProfiles().ToArray()));
		PutList(doc, xmlElement, "ChatFilter", string.Join("\n", ChatFilter.Items().ToArray()));
		if (ActiveProfile.Length == 0)
		{
			XmlElement xmlElement10 = doc.CreateElement("Monsters");
			xmlElement.AppendChild(xmlElement10);
			WriteMonsters(doc, xmlElement10);
		}
		else if (oldOwnList != null)
		{
			xmlElement.AppendChild(doc.ImportNode(oldOwnList, deep: true));
		}
		return xmlElement;
	}

	private void LoadMonsters()
	{
		Monsters.Clear();
		try
		{
			XmlNode xmlNode = null;
			if (ActiveProfile.Length > 0)
			{
				XmlDocument xmlDocument = new XmlDocument();
				Util.LoadXml(xmlDocument, ProfilePath(ActiveProfile));
				xmlNode = xmlDocument.DocumentElement;
			}
			else
			{
				string path = Util.FullPath("MelkTank_Settings.xml");
				if (File.Exists(path))
				{
					XmlDocument xmlDocument2 = new XmlDocument();
					Util.LoadXml(xmlDocument2, path);
					xmlNode = xmlDocument2.SelectSingleNode("/MelkTank/Character[@key=" + XPathLiteral(_charKey) + "]/Monsters");
				}
				if (xmlNode == null && File.Exists(Util.FullPath("MelkTank_Monsters.xml")))
				{
					XmlDocument xmlDocument3 = new XmlDocument();
					Util.LoadXml(xmlDocument3, Util.FullPath("MelkTank_Monsters.xml"));
					xmlNode = xmlDocument3.DocumentElement;
				}
			}
			if (xmlNode != null)
			{
				ReadMonsters(xmlNode);
			}
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Load monsters error: " + ex.Message);
		}
		MonsterRule defaultRule = DefaultRule;
		Monsters.Remove(defaultRule);
		Monsters.Insert(0, defaultRule);
	}

	public void SaveMonsters()
	{
		PackSettings.SettingsSaved();
		if (ActiveProfile.Length > 0)
		{
			WriteMonsterFile(ProfilePath(ActiveProfile));
		}
		else
		{
			SaveCharacter(_charKey);
		}
	}

	private bool WriteMonsterFile(string path)
	{
		return WriteMonsterFile(path, Monsters);
	}

	public string SaveMonsterProfile(string name, List<MonsterRule> list)
	{
		name = CleanProfileName(name);
		if (name.Length == 0)
		{
			return null;
		}
		try
		{
			Directory.CreateDirectory(ProfileDir);
		}
		catch
		{
		}
		string text = FindProfile(name);
		if (text != null)
		{
			name = text;
		}
		return WriteMonsterFile(ProfilePath(name), list) ? name : null;
	}

	private bool WriteMonsterFile(string path, List<MonsterRule> list)
	{
		try
		{
			XmlDocument xmlDocument = new XmlDocument();
			XmlElement xmlElement = xmlDocument.CreateElement("Monsters");
			xmlDocument.AppendChild(xmlElement);
			WriteMonsters(xmlDocument, xmlElement, list);
			Util.SaveXml(xmlDocument, path);
			return true;
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Save monsters error: " + ex.Message);
			return false;
		}
	}

	private void ReadMonsters(XmlNode parent)
	{
		ReadMonsters(parent, Monsters);
	}

	private void ReadMonsters(XmlNode parent, List<MonsterRule> into)
	{
		foreach (XmlNode item in parent.SelectNodes("Monster"))
		{
			MonsterRule monsterRule = new MonsterRule(GetString(item, "Name", ""));
			if (!string.IsNullOrEmpty(monsterRule.Name))
			{
				monsterRule.Priority = GetInt(item, "Priority", 1);
				string text = GetString(item, "Slots", "");
				for (int i = 0; i < monsterRule.Slots.Length && i < text.Length; i++)
				{
					monsterRule.Slots[i] = text[i] == '1';
				}
				monsterRule.Dmg = (DmgType)GetInt(item, "Dmg", 0);
				monsterRule.ExVuln = (DmgType)GetInt(item, "ExVuln", 0);
				monsterRule.Weapon = GetString(item, "Weapon", "<AUTO>");
				monsterRule.Offhand = GetString(item, "Offhand", "<AUTO>");
				monsterRule.PetDmg = (DmgType)GetInt(item, "PetDmg", 0);
				monsterRule.Alert = GetBool(item, "Alert", def: false);
				string atk = GetString(item, "Attack", "");
				if (atk.Length > 0)
				{
					monsterRule.Magic = atk.IndexOf("Magic", StringComparison.OrdinalIgnoreCase) >= 0;
					monsterRule.Melee = atk.IndexOf("Melee", StringComparison.OrdinalIgnoreCase) >= 0;
					monsterRule.Missile = atk.IndexOf("Missile", StringComparison.OrdinalIgnoreCase) >= 0;
				}
				into.Add(monsterRule);
			}
		}
	}

	private void WriteMonsters(XmlDocument doc, XmlElement parent)
	{
		WriteMonsters(doc, parent, Monsters);
	}

	private void WriteMonsters(XmlDocument doc, XmlElement parent, List<MonsterRule> list)
	{
		foreach (MonsterRule item in list)
		{
			XmlElement xmlElement = doc.CreateElement("Monster");
			Put(doc, xmlElement, "Name", item.Name);
			Put(doc, xmlElement, "Priority", item.Priority);
			char[] array = new char[item.Slots.Length];
			for (int i = 0; i < array.Length; i++)
			{
				array[i] = (item.Slots[i] ? '1' : '0');
			}
			Put(doc, xmlElement, "Slots", new string(array));
			Put(doc, xmlElement, "Dmg", (int)item.Dmg);
			Put(doc, xmlElement, "ExVuln", (int)item.ExVuln);
			Put(doc, xmlElement, "Weapon", item.Weapon);
			Put(doc, xmlElement, "Offhand", item.Offhand);
			Put(doc, xmlElement, "PetDmg", (int)item.PetDmg);
			Put(doc, xmlElement, "Alert", item.Alert);
			if (!item.AllAttacks)
			{
				Put(doc, xmlElement, "Attack", item.AttackText);
			}
			parent.AppendChild(xmlElement);
		}
	}

	private static string XPathLiteral(string s)
	{
		if (!s.Contains("'"))
		{
			return "'" + s + "'";
		}
		return "concat('" + s.Replace("'", "', \"'\", '") + "')";
	}

	private static void Put(XmlDocument doc, XmlNode parent, string name, object value)
	{
		XmlElement xmlElement = doc.CreateElement(name);
		xmlElement.InnerText = Convert.ToString(value, Inv);
		parent.AppendChild(xmlElement);
	}

	private static string GetString(XmlNode n, string name, string def)
	{
		XmlNode xmlNode = n.SelectSingleNode(name);
		return (xmlNode == null) ? def : xmlNode.InnerText;
	}

	private static bool GetBool(XmlNode n, string name, bool def)
	{
		bool result;
		return bool.TryParse(GetString(n, name, null), out result) ? result : def;
	}

	private static int GetInt(XmlNode n, string name, int def)
	{
		int result;
		return int.TryParse(GetString(n, name, null), NumberStyles.Integer, Inv, out result) ? result : def;
	}

	private static float GetFloat(XmlNode n, string name, float def)
	{
		float result;
		return float.TryParse(GetString(n, name, null), NumberStyles.Float, Inv, out result) ? result : def;
	}

	public void ApplyVt()
	{
#if RETAIL
		VTankStandIn.TankOn = VtStandIn;
		VTankStandIn.VirindiOn = VtStandInVirindi;
		UbExpr.PickLive = VtLiveUb;
		UbExpr.Own = OwnExpr;
#else
		UbExpr.PickLive = false;
		UbExpr.Own = true;
#endif
	}

	public XmlElement BuildCharacterNow(XmlDocument doc)
	{
		return BuildCharacter(doc, _charKey, null);
	}
}
