using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using MelkTank.Metas;
using AcClient;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Bounties;
using MelkTank.Buffs;

namespace MelkTank;

public static partial class Session
{
	private static void DeedsLoggedIn(string key)
	{
		_deedsFile = Util.FullPath("MelkTank_Deeds_" + key + ".txt");
		LoadDeeds();
	}

	private static void NoteDeeds(string text)
	{
		string[] array = text.Replace("\r", "").Split('\n');
		foreach (string text2 in array)
		{
			string text3 = text2.Trim();
			if (text3.Length == 0)
			{
				continue;
			}
			Match match = QbRx.Match(text3);
			if (match.Success)
			{
				_qbCount = match.Groups["n"].Value;
				_qbAt = DateTime.Now;
				_deedsDirtyAt = DateTime.Now;
				continue;
			}
			match = BonusRx.Match(text3);
			if (match.Success)
			{
				if (DateTime.Now > _bonusCaptureUntil)
				{
					_bonus.Clear();
				}
				// (by name: clicking a few times quickly brought several answers inside one capture, and each was added again)
				string bn = match.Groups["n"].Value.Trim();
				int bi = _bonus.FindIndex((KeyValuePair<string, string> b) => string.Equals(b.Key, bn, StringComparison.OrdinalIgnoreCase));
				KeyValuePair<string, string> bv = new KeyValuePair<string, string>(bn, match.Groups["v"].Value.Trim());
				if (bi >= 0)
				{
					_bonus[bi] = bv;
				}
				else
				{
					_bonus.Add(bv);
				}
				_bonusAt = DateTime.Now;
				_bonusCaptureUntil = DateTime.Now.AddSeconds(3.0);
				_deedsDirtyAt = DateTime.Now;
				continue;
			}
			match = DeedHeadRx.Match(text3);
			if (match.Success)
			{
				_deeds.Clear();
				_curTier = null;
				_deedsHead = text3;
				_deedsOn = match.Groups["on"].Value.Equals("ON", StringComparison.OrdinalIgnoreCase);
				match = Regex.Match(text3, "Your QB:\\s*(?<n>[\\d,]+)");
				if (match.Success)
				{
					_qbCount = match.Groups["n"].Value;
					_qbAt = DateTime.Now;
				}
				_deedsAt = DateTime.Now;
				_deedCaptureUntil = DateTime.Now.AddSeconds(3.0);
				_deedsDirtyAt = DateTime.Now;
			}
			else
			{
				if (DateTime.Now > _deedCaptureUntil || text3.Trim('-').Length == 0)
				{
					continue;
				}
				match = DeedTierRx.Match(text3);
				if (match.Success)
				{
					int.TryParse(match.Groups["qb"].Value.Replace(",", ""), out var result);
					// (a tier already listed - two answers close together - is filled again, not added twice)
					_deeds.RemoveAll((DeedTier d) => d.QB == result);
					_curTier = new DeedTier
					{
						QB = result,
						Unlocked = match.Groups["u"].Success
					};
					_deeds.Add(_curTier);
					_deeds.Sort((DeedTier a, DeedTier b) => a.QB.CompareTo(b.QB));
				}
				else
				{
					if (!text3.StartsWith("*") || _curTier == null)
					{
						_deedCaptureUntil = DateTime.MinValue;
						continue;
					}
					_curTier.Lines.Add(text3.Substring(1).Trim());
				}
				_deedCaptureUntil = DateTime.Now.AddSeconds(3.0);
				_deedsDirtyAt = DateTime.Now;
			}
		}
	}

	private static void QuietNextDeeds(string t)
	{
		switch (t)
		{
		case "/deeds":
			_quietDeedsUntil = DateTime.Now.AddSeconds(8.0);
			break;
		case "/qb":
			_quietQbUntil = DateTime.Now.AddSeconds(8.0);
			break;
		case "/bonus":
			_quietBonusUntil = DateTime.Now.AddSeconds(8.0);
			break;
		}
	}

	private static bool QuietDeeds(string s)
	{
		string text = s.Trim();
		if (DateTime.Now <= _quietQbUntil && QbRx.IsMatch(text))
		{
			_quietQbUntil = DateTime.MinValue;
			return true;
		}
		if (DateTime.Now <= _quietBonusUntil && text.StartsWith("[BONUS]", StringComparison.OrdinalIgnoreCase))
		{
			_quietBonusUntil = DateTime.Now.AddSeconds(2.0);
			return true;
		}
		if (DateTime.Now <= _quietDeedsUntil)
		{
			if (text.Length == 0 || text.Trim('-').Length == 0)
			{
				return true;
			}
			if (DeedHeadRx.IsMatch(text.Split('\n')[0].Trim()) || DateTime.Now <= _deedCaptureUntil)
			{
				_quietDeedsUntil = DateTime.Now.AddSeconds(2.0);
				return true;
			}
		}
		return false;
	}

	private static void DeedsFileTick()
	{
		if (_deedsDirtyAt == DateTime.MinValue || (DateTime.Now - _deedsDirtyAt).TotalSeconds < 4.0 || _deedsFile == null)
		{
			return;
		}
		_deedsDirtyAt = DateTime.MinValue;
		try
		{
			StringBuilder stringBuilder = new StringBuilder("# MelkTank: the last /deeds, /qb and /bonus answers for this character (Session > Deeds)\r\n");
			stringBuilder.Append("E\t").Append(_enlManual).Append("\r\n");
			stringBuilder.Append("AE\t").Append(AeGo.Replace("\t", " ")).Append('\t')
				.Append(AeTarget)
				.Append("\r\n");
			stringBuilder.Append("RT\t").Append(RtSave()).Append("\r\n");
			stringBuilder.Append("Q\t").Append(_qbCount).Append('\t')
				.Append(_qbAt.Ticks)
				.Append("\r\n");
			stringBuilder.Append("D\t").Append(_deedsHead.Replace("\t", " ")).Append('\t')
				.Append(_deedsAt.Ticks)
				.Append('\t')
				.Append(_deedsOn ? "1" : "0")
				.Append("\r\n");
			stringBuilder.Append("@B\t").Append(_bonusAt.Ticks).Append("\r\n");
			foreach (KeyValuePair<string, string> bonu in _bonus)
			{
				stringBuilder.Append("B\t").Append(bonu.Key.Replace("\t", " ")).Append('\t')
					.Append(bonu.Value.Replace("\t", " "))
					.Append("\r\n");
			}
			foreach (DeedTier deed in _deeds)
			{
				stringBuilder.Append("T\t").Append(deed.QB).Append('\t')
					.Append(deed.Unlocked ? "1" : "0")
					.Append("\r\n");
				foreach (string line in deed.Lines)
				{
					stringBuilder.Append("I\t").Append(line.Replace("\t", " ")).Append("\r\n");
				}
			}
			Util.WriteShared(_deedsFile, stringBuilder.ToString());
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void LoadDeeds()
	{
		_deeds.Clear();
		_bonus.Clear();
		_deedsHead = "";
		_qbCount = "";
		_deedsOn = true;
		_enlManual = 0;
		_deedsAt = (_qbAt = (_bonusAt = DateTime.MinValue));
		if (_deedsFile == null || !File.Exists(_deedsFile))
		{
			return;
		}
		try
		{
			string[] array = Util.Locked(_deedsFile, () => File.ReadAllLines(_deedsFile));
			foreach (string text in array)
			{
				string[] array2 = text.Split('\t');
				long result;
				switch (array2[0])
				{
				case "E":
					if (array2.Length >= 2)
					{
						int.TryParse(array2[1], out _enlManual);
					}
					break;
				case "AE":
					if (array2.Length >= 3)
					{
						AeGo = array2[1];
						int.TryParse(array2[2], out AeTarget);
					}
					break;
				case "RT":
					if (array2.Length >= 2)
					{
						RtLoad(array2[1]);
					}
					break;
				case "Q":
					if (array2.Length >= 3)
					{
						_qbCount = array2[1];
						if (long.TryParse(array2[2], out result))
						{
							_qbAt = new DateTime(result);
						}
					}
					break;
				case "D":
					if (array2.Length >= 4)
					{
						_deedsHead = array2[1];
						if (long.TryParse(array2[2], out result))
						{
							_deedsAt = new DateTime(result);
						}
						_deedsOn = array2[3] == "1";
					}
					break;
				case "@B":
					if (array2.Length >= 2 && long.TryParse(array2[1], out result))
					{
						_bonusAt = new DateTime(result);
					}
					break;
				case "B":
					if (array2.Length >= 3)
					{
						_bonus.Add(new KeyValuePair<string, string>(array2[1], array2[2]));
					}
					break;
				case "T":
				{
					if (array2.Length >= 3 && int.TryParse(array2[1], out var result2))
					{
						_deeds.Add(new DeedTier
						{
							QB = result2,
							Unlocked = (array2[2] == "1")
						});
					}
					break;
				}
				case "I":
					if (array2.Length >= 2 && _deeds.Count > 0)
					{
						_deeds[_deeds.Count - 1].Lines.Add(array2[1]);
					}
					break;
				}
			}
			_deeds.Sort((DeedTier a, DeedTier b) => a.QB.CompareTo(b.QB));
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static string When(DateTime t)
	{
		string result;
		if (t == DateTime.MinValue)
		{
			result = "never";
		}
		else
		{
			result = ((t.Date == DateTime.Today) ? t.ToString("HH:mm") : t.ToString("MM-dd HH:mm"));
		}
		return result;
	}

	private static void Check(string cmd)
	{
		QuietNext(cmd);
		Util.Command(cmd);
	}

	private static void DrawDeeds()
	{
		Vector4 vector = new Vector4(0.45f, 0.9f, 0.45f, 1f);
		Vector4 vector2 = new Vector4(0.95f, 0.95f, 0.95f, 1f);
		Vector4 col = new Vector4(0.6f, 0.6f, 0.6f, 1f);
		if (ImGui.Button("Update all"))
		{
			Check("/qb");
			Check("/bonus");
			Check("/deeds");
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Sends /qb, /bonus and /deeds - the answers are read here and kept out of chat.");
		}
		ImGui.SameLine();
		if (ImGui.Button("/qb##dq"))
		{
			Check("/qb");
		}
		ImGui.SameLine();
		if (ImGui.Button("/bonus##db"))
		{
			Check("/bonus");
		}
		ImGui.SameLine();
		if (ImGui.Button("/deeds##dd"))
		{
			Check("/deeds");
		}
		Im.TextColored(Cyan, "Quest bonus:");
		ImGui.SameLine();
		ImGui.TextUnformatted((_qbCount.Length > 0) ? _qbCount : "-");
		ImGui.SameLine();
		Im.TextColored(col, "(" + When(_qbAt) + ")");
		if (_bonus.Count > 0)
		{
			if (ImGui.BeginTable("bonuslist", 2, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
			{
				ImGui.TableSetupColumn("XP multiplier (" + When(_bonusAt) + ")", ImGuiTableColumnFlags.WidthFixed, 200f);
				ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthStretch);
				ImGui.TableHeadersRow();
				foreach (KeyValuePair<string, string> bonu in _bonus)
				{
					ImGui.TableNextRow();
					bool flag = bonu.Key.IndexOf("Total", StringComparison.OrdinalIgnoreCase) >= 0;
					ImGui.TableSetColumnIndex(0);
					Im.TextColored(flag ? Yellow : Cyan, bonu.Key);
					ImGui.TableSetColumnIndex(1);
					if (flag)
					{
						Im.TextColored(Yellow, bonu.Value);
					}
					else
					{
						ImGui.TextUnformatted(bonu.Value);
					}
				}
				ImGui.EndTable();
			}
		}
		else
		{
			Im.TextDisabled("XP multipliers: nothing yet - click /bonus.");
		}
		ImGui.Separator();
		if (_deeds.Count == 0)
		{
			Im.TextDisabled("Deeds: nothing yet - click /deeds.");
			return;
		}
		Im.TextColored(_deedsOn ? vector : Yellow, _deedsHead);
		Im.TextColored(col, "as of " + When(_deedsAt) + (_deedsOn ? "" : " - deeds bonuses are OFF, so none are active"));
		foreach (DeedTier deed in _deeds)
		{
			Vector4 col2;
			if (deed.Unlocked && _deedsOn)
			{
				col2 = vector;
			}
			else
			{
				col2 = (deed.Unlocked ? Yellow : vector2);
			}
			ImGui.PushStyleColor(ImGuiCol.Text, col2);
			bool flag2 = ImGui.CollapsingHeader(deed.QB.ToString("N0") + " QB" + (deed.Unlocked ? " - unlocked" : "") + "##deed" + deed.QB);
			ImGui.PopStyleColor();
			if (!flag2)
			{
				continue;
			}
			ImGui.Indent();
			foreach (string line in deed.Lines)
			{
				if (line.StartsWith("("))
				{
					Im.TextColored(col, line);
				}
				else
				{
					Im.TextColored(col2, line);
				}
			}
			ImGui.Unindent();
		}
	}
}
