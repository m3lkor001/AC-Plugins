using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
#if !RETAIL
using ACGodot.DecalShim;
using ACGodot.Plugins;
using ACGodot.UI;
#endif
#if !RETAIL
using AcClient;
#else
using SmartBox = AcClient.SmartBox;
using ACCmdInterp = AcClient.ACCmdInterp;
using CommandInterpreter = AcClient.CommandInterpreter;
using CommandListElement = AcClient.CommandListElement;
using CPhysicsObj = AcClient.CPhysicsObj;
using Position = AcClient.Position;
using CTransition = AcClient.CTransition;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
#if !RETAIL
using Godot;
#endif
using ImGuiNET;
using MelkTank.Loot;
using MelkTank.Metas;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public partial class Nav
{
	private void RecordCrumb(WorldObject p)
	{
		if (!_s.FollowExactPath)
		{
			_crumbs.Clear();
			return;
		}
		CoordsObject coordsObject = null;
		try
		{
			coordsObject = p.Coordinates();
		}
		catch
		{
		}
		if (coordsObject == null)
		{
			return;
		}
		double z = 0.0;
		try
		{
			z = p.RawCoordinates().Z;
		}
		catch
		{
		}
		NavSpot navSpot = new NavSpot
		{
			Name = "trail",
			NS = coordsObject.NorthSouth,
			EW = coordsObject.EastWest,
			Z = z,
			Heading = -1.0
		};
		if (_crumbs.Count > 0)
		{
			double num = Flat(navSpot, _crumbs[_crumbs.Count - 1]);
			if (num < CrumbStep)
			{
				return;
			}
			if (num > Tuning.V("CrumbJumpM"))
			{
				_crumbs.Clear();
			}
		}
		_crumbs.Add(navSpot);
		if (_crumbs.Count > 2000)
		{
			_crumbs.RemoveRange(0, _crumbs.Count - 2000);
		}
	}

	private bool FollowTrail(NavSpot leader)
	{
		NavSpot navSpot = MeSpot();
		if (navSpot == null)
		{
			return false;
		}
		while (_crumbs.Count > 0 && Flat(navSpot, _crumbs[0]) <= CrumbArrive)
		{
			_crumbs.RemoveAt(0);
		}
		while (_crumbs.Count > 1 && Flat(navSpot, _crumbs[1]) < Flat(navSpot, _crumbs[0]) && Flat(navSpot, _crumbs[0]) < 3.0)
		{
			_crumbs.RemoveAt(0);
		}
		double num = 0.0;
		NavSpot a = navSpot;
		foreach (NavSpot crumb in _crumbs)
		{
			num += Flat(a, crumb);
			a = crumb;
		}
		num += Flat(a, leader);
		if (num <= (double)_s.FollowDist || _crumbs.Count == 0)
		{
			if (_crumbs.Count == 0 && Flat(navSpot, leader) > (double)_s.FollowDist + 0.5)
			{
				return false;
			}
			if (_running)
			{
				Stop();
			}
			Status = "Following " + _s.FollowName + " on their path (" + num.ToString("0.0") + " m)";
			return true;
		}
		NavSpot navSpot2 = _crumbs[0];
		double num2 = Flat(navSpot, navSpot2);
		if (_running && num2 <= CrumbArrive * 1.5 && _crumbs.Count > 1)
		{
			double num3 = CombatEngine.MyHeading();
			double num4 = ((num3 < 0.0) ? 0.0 : AngleDiff(BearingTo(_crumbs[1]), num3));
			if (num4 >= (double)_s.NavTurnAngle)
			{
				L("follow: their path turns " + num4.ToString("0") + " deg - stop and turn");
				Stop();
				_crumbs.RemoveAt(0);
				return true;
			}
		}
		_bestDist = num2;
		_lastProgressAt = DateTime.Now;
		ReturnTick(navSpot2, CrumbArrive, CrumbArrive, precise: false);
		Status = "Following " + _s.FollowName + " on their path (" + num.ToString("0.0") + " m behind)";
		return true;
	}

	private NavSpot MeSpot()
	{
		try
		{
			CoordsObject coordsObject = Globals.Core.WorldFilter[Globals.Core.CharacterFilter.Id]?.Coordinates();
			if (coordsObject == null)
			{
				return null;
			}
			return new NavSpot
			{
				NS = coordsObject.NorthSouth,
				EW = coordsObject.EastWest
			};
		}
		catch
		{
			return null;
		}
	}

	private static WorldObject FindPlayer(string name)
	{
		if (string.IsNullOrEmpty(name))
		{
			return null;
		}
		try
		{
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				if (item.ObjectClass == ObjectClass.Player && string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
				{
					return item;
				}
			}
		}
		catch
		{
		}
		return null;
	}

	private bool FollowTick()
	{
		if (!_s.NavEnabled || string.IsNullOrEmpty(_s.FollowName))
		{
			Stop();
			return false;
		}
		DateTime now = DateTime.Now;
		WorldObject worldObject = FindPlayer(_s.FollowName);
		if (worldObject == null)
		{
			Stop();
			if (_s.FollowPortals && _fHasLast && (now - _fLastSeen).TotalSeconds < 4.0 && (now - _fPortalUsedAt).TotalSeconds > 20.0)
			{
				WorldObject worldObject2 = null;
				double num = 6.0;
				try
				{
					foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
					{
						if (item.ObjectClass != ObjectClass.Portal)
						{
							continue;
						}
						CoordsObject coordsObject = item.Coordinates();
						if (coordsObject != null)
						{
							double num2 = (coordsObject.NorthSouth - _fLastNS) * 240.0;
							double num3 = (coordsObject.EastWest - _fLastEW) * 240.0;
							double num4 = Math.Sqrt(num2 * num2 + num3 * num3);
							if (num4 < num)
							{
								num = num4;
								worldObject2 = item;
							}
						}
					}
				}
				catch
				{
				}
				if (worldObject2 != null)
				{
					_fPortalUsedAt = now;
					try
					{
						Globals.Core.Actions.UseItem(worldObject2.Id, 0);
					}
					catch (Exception ex)
					{
						Util.LogError(ex);
					}
					Util.WriteToChat("Nav: " + _s.FollowName + " went through " + worldObject2.Name + " - following.");
					L("follow: using " + worldObject2.Name);
					Status = "Following " + _s.FollowName + " through " + worldObject2.Name;
					return true;
				}
			}
			if ((now - _fLostSaid).TotalSeconds > 60.0 && _fHasLast)
			{
				_fLostSaid = now;
				Util.WriteToChat("Nav: can't see " + _s.FollowName + " - waiting for them to show up.");
			}
			Status = "Waiting for " + _s.FollowName;
			return false;
		}
		_fLostSaid = DateTime.MinValue;
		try
		{
			CoordsObject coordsObject2 = worldObject.Coordinates();
			if (coordsObject2 != null)
			{
				_fLastNS = coordsObject2.NorthSouth;
				_fLastEW = coordsObject2.EastWest;
				_fHasLast = true;
				_fLastSeen = now;
			}
		}
		catch
		{
		}
		double z = 0.0;
		try
		{
			z = worldObject.RawCoordinates().Z;
		}
		catch
		{
		}
		NavSpot navSpot = new NavSpot
		{
			Name = _s.FollowName,
			NS = _fLastNS,
			EW = _fLastEW,
			Z = z,
			Heading = -1.0
		};
		if (_s.FollowExactPath && _crumbs.Count > 0 && FollowTrail(navSpot))
		{
			return _running;
		}
		double num5 = DistanceTo(navSpot);
		if (num5 >= 0.0 && num5 <= (double)_s.FollowDist)
		{
			if (_running)
			{
				Stop();
			}
			Status = "Following " + _s.FollowName + " (" + num5.ToString("0.0") + " m)";
			return false;
		}
		_bestDist = num5;
		_lastProgressAt = now;
		bool result = ReturnTick(navSpot, (double)_s.FollowDist + 0.5, _s.FollowDist, precise: false);
		Status = "Following " + _s.FollowName + " (" + num5.ToString("0.0") + " m)";
		return result;
	}

	private void UpdateFollowMarkers()
	{
		WorldObject worldObject = ((_s.NavMode == 2 && _s.NavEnabled) ? FindPlayer(_s.FollowName) : null);
		if (worldObject != null)
		{
			RecordCrumb(worldObject);
		}
		else if (_s.NavMode != 2 || !_s.NavEnabled)
		{
			_crumbs.Clear();
		}
		string text = ((worldObject == null) ? "" : (worldObject.Id + "|" + _s.FollowRing + "|" + _s.FollowArrow));
		if (text == _fMarkKey)
		{
			if (worldObject != null && (DateTime.Now - _fVisCheck).TotalMilliseconds >= 250.0)
			{
				_fVisCheck = DateTime.Now;
				bool show = !_s.NavHideUnfocused || GameFocused();
				SetVisible(_fRing, show);
				SetVisible(_fArrow, show);
			}
			return;
		}
		_fMarkKey = text;
		ClearFollowMarkers();
		if (worldObject == null)
		{
			return;
		}
		try
		{
			D3DService d3DService = Globals.Core.D3DService;
			if (_s.FollowRing)
			{
				_fRing = d3DService.MarkObjectWithShape(worldObject.Id, D3DShape.Ring, -11149995);
				if (_fRing != null)
				{
					_fRing.Scale(1f);
				}
			}
			if (_s.FollowArrow)
			{
				_fArrow = d3DService.PointToObject(worldObject.Id, -11149995);
			}
			_fMarked = worldObject.Id;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void ClearFollowMarkers()
	{
		D3DObj[] array = new D3DObj[2] { _fRing, _fArrow };
		foreach (D3DObj d3DObj in array)
		{
			if (d3DObj != null)
			{
				try
				{
					d3DObj.Visible = false;
				}
				catch
				{
				}
				try
				{
					((IDisposable)d3DObj)?.Dispose();
				}
				catch
				{
				}
			}
		}
		_fRing = (_fArrow = null);
		_fMarked = 0;
	}

	private bool DrawFollow()
	{
		bool flag = false;
		if (ImGui.Button("Follow selected"))
		{
			int num = 0;
			try
			{
				num = Globals.Core.Actions.CurrentSelection;
			}
			catch
			{
			}
			WorldObject worldObject = ((num != 0) ? Globals.Core.WorldFilter[num] : null);
			if (worldObject == null || worldObject.ObjectClass != ObjectClass.Player)
			{
				Util.WriteToChat("Nav: select a player first.");
			}
			else
			{
				_s.FollowName = worldObject.Name;
				_s.NavEnabled = true;
				Stop();
				_crumbs.Clear();
				flag = true;
				Util.WriteToChat("Nav: following " + worldObject.Name + ".");
			}
		}
		ImGui.SameLine();
		Im.TextColored((_s.FollowName.Length > 0) ? Cyan : Grey, (_s.FollowName.Length > 0) ? ("Player: " + _s.FollowName) : "No one picked - select a player and click Follow selected.");
		bool v = _s.NavEnabled;
		if (ImGui.Checkbox("Follow", ref v))
		{
			_s.NavEnabled = v;
			if (!v)
			{
				Stop();
			}
			flag = true;
		}
		Tip("Keeps you within the distance below of them whenever there's nothing to fight or loot.");
		ImGui.SameLine(0f, 20f);
		ImGui.SetNextItemWidth(100f);
		flag |= ImGui.InputFloat("stay within (m)##fdist", ref _s.FollowDist, 0.5f, 1f, "%.1f");
		Im.SetTooltipIfHovered("/mt set FollowDist <number>");
		if (_s.FollowDist < 1f)
		{
			_s.FollowDist = 1f;
		}
		if (ImGui.Checkbox("Follow their exact path", ref _s.FollowExactPath))
		{
			_crumbs.Clear();
			flag = true;
		}
		Tip("Walks where they walked, metre by metre - turns at the same corners (inside buildings, around monsters)\ninstead of cutting straight across. Sharp turns stop and turn (Nav settings: the bend angle).\nThe trail starts when you tick this or pick who to follow.\n/mt set FollowExactPath on|off");
		flag |= ImGui.Checkbox("Follow them through portals", ref _s.FollowPortals);
		Tip("When they disappear right next to a portal, that portal is used too.\n/mt set FollowPortals on|off");
		flag |= ImGui.Checkbox("Ring under them", ref _s.FollowRing);
		Im.SetTooltipIfHovered("/mt set FollowRing on|off");
		ImGui.SameLine(0f, 20f);
		flag |= ImGui.Checkbox("Arrow to them", ref _s.FollowArrow);
		Im.SetTooltipIfHovered("/mt set FollowArrow on|off");
		ImGui.SameLine(0f, 20f);
		flag |= ImGui.Checkbox("Hide them while the game isn't the active window##fhide", ref _s.NavHideUnfocused);
		Im.SetTooltipIfHovered("/mt set NavHideUnfocused on|off");
		if (_s.NavEnabled && Status.Length > 0)
		{
			Im.TextColored(_running ? Yellow : Grey, Status);
		}
		return flag;
	}
}
