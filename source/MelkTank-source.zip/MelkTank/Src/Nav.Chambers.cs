using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
#if !RETAIL
using ACGodot.DecalShim;
using ACGodot.Plugins;
using ACGodot.UI;
#endif
#if !RETAIL
using AcClient;
#else
using SmartBox = AcClient.SmartBox;
using ACCmdInterp = AcClient.ACCmdInterp;
using CommandInterpreter = AcClient.CommandInterpreter;
using CommandListElement = AcClient.CommandListElement;
using CPhysicsObj = AcClient.CPhysicsObj;
using Position = AcClient.Position;
using CTransition = AcClient.CTransition;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
#if !RETAIL
using Godot;
#endif
using ImGuiNET;
using MelkTank.Loot;
using MelkTank.Metas;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public partial class Nav
{
	public void OnChamberChat(string text)
	{
		if (_s.NavChamberSpots && !string.IsNullOrEmpty(text) && !text.Contains(" says, ") && !text.Contains(" tells you") && !text.Contains("You say, ") && !text.Contains("You tell ") && !text.StartsWith("[") && !text.StartsWith("Nav:") && !text.StartsWith("<Tell:") && ChamberWord.IsMatch(text) && text.IndexOf(" kills", StringComparison.OrdinalIgnoreCase) < 0)
		{
			Match match = NumberRx.Match(text);
			int result;
			if (!match.Success)
			{
				Catcher.Note("chamber-nonumber", text);
			}
			else if (int.TryParse(match.Groups[1].Success ? match.Groups[1].Value : match.Groups[2].Value, out result))
			{
				_chamber = result;
				_chamberText = text;
				_chamberDue = DateTime.Now.AddSeconds(2.0);
			}
		}
	}

	public static void EarlyChat(string text)
	{
		if (!string.IsNullOrEmpty(text) && ChamberWord.IsMatch(text))
		{
			_earlyText = text;
			_earlyAt = DateTime.Now;
		}
	}

	public void ChamberTick()
	{
		if (_earlyText != null)
		{
			string earlyText = _earlyText;
			_earlyText = null;
			if ((DateTime.Now - _earlyAt).TotalSeconds < 90.0)
			{
				OnChamberChat(earlyText);
			}
		}
		bool navEnabled = _s.NavEnabled;
		if (navEnabled && !_navWasOn && _s.NavMode == 1)
		{
			NavRoute currentRoute = CurrentRoute;
			if (currentRoute != null && string.Equals(currentRoute.Name, "Map route", StringComparison.OrdinalIgnoreCase))
			{
				if (_rDone)
				{
					_rName = "";
				}
			}
			else
			{
				_resumeNearest = true;
			}
		}
		_navWasOn = navEnabled;
		if (DateTime.Now < _chamberDue)
		{
			return;
		}
		if (_s.NavEnabled && _s.NavMode == 1 && CurrentRoute != null && !_rDone)
		{
			_chamberDue = DateTime.Now.AddSeconds(2.0);
			return;
		}
		_chamberDue = DateTime.MaxValue;
		int chamber = _chamber;
		string text = (_chamberText ?? "").ToLowerInvariant();
		List<NavSpot> list = new List<NavSpot>();
		List<NavSpot> list2 = new List<NavSpot>();
		foreach (NavSpot navSpot2 in _s.NavSpots)
		{
			string text2 = (navSpot2.Name ?? "").Trim();
			Match match = SpotNumberRx.Match(text2);
			if (!match.Success || !int.TryParse(match.Groups[1].Value, out var result) || result != chamber)
			{
				continue;
			}
			list.Add(navSpot2);
			string text3 = text2.Substring(0, match.Index).Trim().ToLowerInvariant();
			if (text3.Length == 0)
			{
				continue;
			}
			bool flag = text.Contains(text3) || (text3.EndsWith("s") && text.Contains(text3.TrimEnd('s')));
			string[][] dungeonAliases = DungeonAliases;
			foreach (string[] array in dungeonAliases)
			{
				if (text.Contains(array[0]) && text3.StartsWith(array[1]))
				{
					flag = true;
				}
			}
			if (flag)
			{
				list2.Add(navSpot2);
			}
		}
		bool flag2 = false;
		string[][] dungeonAliases2 = DungeonAliases;
		foreach (string[] array2 in dungeonAliases2)
		{
			if (text.Contains(array2[0]))
			{
				flag2 = true;
			}
		}
		NavSpot navSpot = null;
		double num = double.MaxValue;
		List<NavSpot> list3;
		if (list2.Count > 0)
		{
			list3 = list2;
		}
		else
		{
			list3 = (flag2 ? list2 : list);
		}
		foreach (NavSpot item in list3)
		{
			double num2 = DistanceTo(item);
			if (num2 < 0.0)
			{
				num2 = 1000000.0;
			}
			if (num2 < num)
			{
				navSpot = item;
				num = num2;
			}
		}
		if (list2.Count == 0 && navSpot != null && num > 1500.0 && num < 1000000.0)
		{
			navSpot = null;
		}
		if (navSpot != null)
		{
			bool flag3 = string.Equals(_s.NavSelected, navSpot.Name, StringComparison.OrdinalIgnoreCase) && _s.NavMode == 0;
			_s.NavSelected = navSpot.Name;
			_s.NavMode = 0;
			_lastHeadingFix = DateTime.MinValue;
			if (!flag3)
			{
				Stop();
				SpotChanged();
				if (SaveAll != null)
				{
					SaveAll();
				}
			}
			Util.WriteToChat("Nav: chamber " + chamber + " - " + (flag3 ? "staying on" : "switched to") + " spot '" + navSpot.Name + "'" + (_s.NavEnabled ? "." : " (Nav is off)."));
			Catcher.Note("chamber-spot", navSpot.Name + " (" + ((num < 1000000.0) ? (num.ToString("0") + " m") : "distance unknown") + ") from: " + _chamberText);
		}
		else if (_s.NavEnabled)
		{
			_s.NavEnabled = false;
			Stop();
			if (SaveAll != null)
			{
				SaveAll();
			}
			Util.WriteToChat("Nav: chamber " + chamber + " has no saved spot (name one ending in C" + chamber + ") - Nav turned off.");
			Catcher.Note("chamber-navoff", _chamberText);
		}
		else
		{
			Util.WriteToChat("Nav: chamber " + chamber + " has no saved spot (name one ending in C" + chamber + ").");
		}
	}

	private bool DoorInTheWay()
	{
		if (!OpenDoorsNow)
		{
			return false;
		}
		if (_doorId != 0 && (DateTime.Now - _doorAt).TotalSeconds < 2.5)
		{
			return true;
		}
		bool flag = _doorId != 0 && (DateTime.Now - _doorAt).TotalSeconds < 10.0;
		WorldObject worldObject = null;
		double num = _s.NavDoorRange;
		try
		{
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				if (IsDoor(item))
				{
					double num2 = CombatEngine.Distance(item);
					if (num2 >= 0.0 && num2 <= num)
					{
						num = num2;
						worldObject = item;
					}
				}
			}
		}
		catch
		{
			return false;
		}
		if (worldObject == null)
		{
			return false;
		}
		if (flag && worldObject.Id == _doorId)
		{
			return false;
		}
		_doorTries.TryGetValue(worldObject.Id, out var value);
		if (value >= 6)
		{
			return false;
		}
		_doorTries[worldObject.Id] = value + 1;
		if (_doorId != worldObject.Id)
		{
			_doorId = worldObject.Id;
			_doorLocked = false;
		}
		bool? flag2 = DoorShut(worldObject.Id);
		if (!flag2.HasValue)
		{
			_doorTries[worldObject.Id] = value;
			Status = "Checking " + worldObject.Name;
			return true;
		}
		if (flag2 == false)
		{
			L("door: " + worldObject.Name + " is open already - not using it");
			_doorTries[worldObject.Id] = value;
			_doorAt = DateTime.Now.AddSeconds(-2.6);
			return false;
		}
		if (_doorLocked && _s.NavPickLocks && TryPick(worldObject))
		{
			return true;
		}
		try
		{
			Globals.Core.Actions.UseItem(worldObject.Id, 0);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			return false;
		}
		_doorAt = DateTime.Now;
		_doorUseAt = DateTime.Now;
		_doorRerun = false;
		L("door: using " + worldObject.Name + " (" + num.ToString("0.0") + " m)");
		Status = "Opening " + worldObject.Name;
		return true;
	}

	private bool TryPick(WorldObject door)
	{
		if (_doorNoPick.Contains(door.Id))
		{
			return false;
		}
		if (!door.HasIdData)
		{
			if ((DateTime.Now - _doorPickAt).TotalSeconds > 3.0)
			{
				_doorPickAt = DateTime.Now;
				try
				{
					Util.RequestId(door.Id);
				}
				catch
				{
				}
			}
			_doorAt = DateTime.Now;
			Status = "Checking the lock on " + door.Name;
			return true;
		}
		int num = LootMatcher.Long(door, 38);
		int num2 = Character.EffectiveSkill(23);
		if (num >= 9999 || num2 - num < _s.NavLockpickMargin)
		{
			_doorNoPick.Add(door.Id);
			Util.WriteToChat("Nav: " + door.Name + " is locked - " + ((num >= 9999) ? "it can't be picked" : ("lock " + num + ", your Lockpick is " + num2)) + ".");
			return false;
		}
		WeaponItem weaponItem = null;
		foreach (WeaponItem item in _s.Items)
		{
			if (item.Kind == WeaponKind.Lockpick && ItemInfo.CountInPack(item.Name) > 0)
			{
				weaponItem = item;
				break;
			}
		}
		if (weaponItem == null)
		{
			_doorNoPick.Add(door.Id);
			Util.WriteToChat("Nav: " + door.Name + " is locked and there's no lockpick on the Items tab (add one: select it, Add selected).");
			return false;
		}
		WorldObject worldObject = Globals.Core.WorldFilter[weaponItem.Id];
		int num3 = ((worldObject != null) ? weaponItem.Id : FindByName(weaponItem.Name));
		if (num3 == 0)
		{
			return false;
		}
		try
		{
			CM_Inventory.Event_UseWithTargetEvent((uint)num3, (uint)door.Id);
		}
		catch
		{
			try
			{
				Globals.Core.Actions.ApplyItem(num3, door.Id);
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
				return false;
			}
		}
		_doorAt = DateTime.Now;
		L("door: picking " + door.Name + " (lock " + num + ", skill " + num2 + ") with " + weaponItem.Name);
		Status = "Picking the lock on " + door.Name;
		return true;
	}

	private static int FindByName(string name)
	{
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
				{
					return item.Id;
				}
			}
		}
		catch
		{
		}
		return 0;
	}

	public void OnDoorChat(string text)
	{
		if (_s.NavOpenDoors && _doorId != 0 && !((DateTime.Now - _doorAt).TotalSeconds > 10.0))
		{
			if (text.IndexOf(" is locked", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				_doorLocked = true;
				_doorAt = DateTime.Now.AddSeconds(-2.0);
			}
			else if (text.IndexOf("unlock", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("picked the lock", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				_doorLocked = false;
				_doorAt = DateTime.Now.AddSeconds(-2.0);
			}
		}
	}

	private bool DrawDoorSettings()
	{
		bool flag = false;
		flag |= ImGui.Checkbox("Open doors in the way", ref _s.NavOpenDoors);
		Tip("When running stops getting closer and a door is within the range, it's used (opened).\nOnly then - doors aren't checked or ID'd otherwise.\n/mt set NavOpenDoors on|off");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		flag |= ImGui.InputFloat("m##doorrange", ref _s.NavDoorRange, 0.5f, 1f, "%.1f");
		Im.SetTooltipIfHovered("/mt set NavDoorRange <number>");
		if (_s.NavDoorRange < 1f)
		{
			_s.NavDoorRange = 1f;
		}
		ImGui.Indent(16f);
		if (!_s.NavOpenDoors)
		{
			ImGui.PushStyleVar(ImGuiStyleVar.Alpha, 0.5f);
		}
		flag |= ImGui.Checkbox("Pick locked doors", ref _s.NavPickLocks);
		Tip("A locked door is ID'd for its lock (9999 = can't be picked), and a lockpick from the Items tab is used on it\nwhen your Lockpick skill minus the lock is at least the number here (-50 = up to 50 below still tries).\n/mt set NavPickLocks on|off");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		flag |= ImGui.InputInt("skill over lock##lpmargin", ref _s.NavLockpickMargin, 10, 50);
		Im.SetTooltipIfHovered("/mt set NavLockpickMargin <number>");
		if (!_s.NavOpenDoors)
		{
			ImGui.PopStyleVar();
			Tip("Needs 'Open doors in the way' ticked.");
		}
		ImGui.Unindent(16f);
		return flag;
	}

	private static TreeDir Scan(string dir, int depth)
	{
		TreeDir treeDir = new TreeDir
		{
			Path = dir,
			Name = Path.GetFileName(dir)
		};
		if (depth > 6)
		{
			return treeDir;
		}
		try
		{
			List<string> list = new List<string>(Directory.GetDirectories(dir));
			list.Sort(StringComparer.OrdinalIgnoreCase);
			foreach (string item in list)
			{
				TreeDir treeDir2 = Scan(item, depth + 1);
				if (treeDir2.Files.Count > 0 || treeDir2.Dirs.Count > 0 || depth == 0)
				{
					treeDir.Dirs.Add(treeDir2);
				}
			}
			string[] files = Directory.GetFiles(dir);
			foreach (string text in files)
			{
				if (text.EndsWith(".nav", StringComparison.OrdinalIgnoreCase) || text.EndsWith(".mtnav", StringComparison.OrdinalIgnoreCase) || text.EndsWith(".met", StringComparison.OrdinalIgnoreCase))
				{
					treeDir.Files.Add(text);
				}
			}
			treeDir.Files.Sort(StringComparer.OrdinalIgnoreCase);
		}
		catch
		{
		}
		return treeDir;
	}
}
