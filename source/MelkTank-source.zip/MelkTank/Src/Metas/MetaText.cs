using System;
using System.Collections.Generic;
using System.Globalization;

namespace MelkTank.Metas;

public static class MetaText
{
	public class TypeDef
	{
		public int Id;

		public string Name;

		public string Data;

		public string Help;

		public string[][] Keys;
	}

	private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

	public static readonly TypeDef[] Conds = new TypeDef[30]
	{
		D(0, "Never", "", "Never true - the rule is switched off."),
		D(1, "Always", "", "Always true."),
		D(2, "All of", "kids", "True when every condition under it is true."),
		D(3, "Any of", "kids", "True when at least one condition under it is true."),
		D(4, "Chat line matches", "s", "A chat line matched this (regular expression) since the state started."),
		D(5, "Main pack free slots <=", "i", "Free slots in your main pack are at most this many."),
		D(6, "Seconds in this state >=", "i", "You've been in this state at least this many seconds."),
		D(7, "Route finished / empty", "", "The nav route has nothing left to do."),
		D(8, "You died", "", "You died (since the state started)."),
		D(9, "A vendor is open", "", "Any vendor window is open."),
		D(10, "The vendor closed", "", "A vendor window closed."),
		D(11, "Item count <=", "kv", "You carry at most this many of an item.", "n", "s", "item", "c", "i", "count"),
		D(12, "Item count >=", "kv", "You carry at least this many of an item.", "n", "s", "item", "c", "i", "count"),
		D(13, "Monsters named ... within", "kv", "At least this many monsters with the name (regex) within the distance.", "n", "s", "name", "c", "i", "count", "r", "d", "distance"),
		D(14, "Monsters of priority ... within", "kv", "At least this many monsters of this priority within the distance.", "p", "i", "priority", "c", "i", "count", "r", "d", "distance"),
		D(15, "Need to buff", "", "Buffs need doing."),
		D(16, "No monsters within", "kv", "No monsters within the distance.", "r", "d", "distance"),
		D(17, "Landblock is", "hex", "You're in this landblock."),
		D(18, "Landcell is", "hex", "You're in this landcell."),
		D(19, "Entered portal space", "", "You went into portal space (since the state started)."),
		D(20, "Left portal space", "", "You came out of portal space (since the state started)."),
		D(21, "Not", "kids", "True when the condition under it is false."),
		D(22, "Seconds in state (persistent) >=", "i", "Like seconds in this state, but it keeps counting through calls to other states."),
		D(23, "Time left on spell >=", "kv", "A spell on you has at least this long left.", "sid", "i", "spell id", "sec", "i", "seconds"),
		D(24, "Burden % >=", "i", "Your burden is at least this %."),
		D(25, "Distance to any route point >=", "i", "You're at least this far from every point of the route."),
		D(26, "Expression", "kv", "A meta expression is true.", "e", "s", "expression"),
		D(27, "Client dialog popup", "kv", "A dialog popped up.", "p", "s", "text"),
		D(28, "Chat capture", "kv", "A chat line matched (regex with named groups) - the groups become variables.", "p", "s", "pattern", "c", "s", "colours"),
		D(100, "Vendor visit finished", "kv", "A vendor visit (Items > Vendor) finished since the state started, with this result: success, partial, failed or any.", "r", "s", "result")
	};

	public static readonly TypeDef[] Acts = new TypeDef[22]
	{
		D(0, "Nothing", "", "Does nothing."),
		D(1, "Go to state", "s", "Switches to another state."),
		D(2, "Chat command", "s", "Sends a chat command (/vt ..., /ub ..., /mt ...)."),
		D(3, "Do all of", "kids", "Does every action under it, in order."),
		D(4, "Load embedded route", "ba", "Loads the nav route stored in the meta."),
		D(5, "Call state", "kv", "Goes to a state; a 'Return from call' comes back to the return state.", "st", "s", "state", "ret", "s", "return to"),
		D(6, "Return from call", "", "Goes back to where the last call came from."),
		D(7, "Expression", "kv", "Runs a meta expression.", "e", "s", "expression"),
		D(8, "Chat expression", "kv", "Sends the result of an expression as a chat command.", "e", "s", "expression"),
		D(9, "Set watchdog", "kv", "If you don't move this far in this time, go to the state.", "s", "s", "state", "r", "d", "distance", "t", "d", "seconds"),
		D(10, "Clear watchdog", "", "Turns the watchdog off."),
		D(11, "Get MT option", "kv", "Puts one of MelkTank's switches (combat, looting, buffing...) into a variable (1 on, 0 off).", "o", "s", "option", "v", "s", "variable"),
		D(12, "Set MT option", "kv", "Turns one of MelkTank's switches (combat, looting, buffing...) on or off.", "o", "s", "option", "v", "s", "value"),
		D(13, "Create view", "kv", "Makes a meta view (a window of buttons) from XML.", "n", "s", "name", "x", "ba", "xml"),
		D(14, "Destroy view", "kv", "Closes a meta view.", "n", "s", "name"),
		D(15, "Destroy all views", "", "Closes every meta view."),
		D(100, "Use item", "kv", "Uses an item in your pack by name.", "n", "s", "item"),
		D(101, "Talk to NPC", "kv", "Uses (talks to) the nearest NPC with this name.", "n", "s", "NPC"),
		D(102, "Use portal", "kv", "Uses the nearest portal with this name.", "n", "s", "portal"),
		D(103, "Give item to NPC", "kv", "Gives an item from your pack to the nearest NPC with this name.", "i", "s", "item", "n", "s", "NPC"),
		D(104, "Load route", "kv", "Loads one of your routes (Nav > Routes) by name - not embedded, so editing the route changes what the meta runs.", "n", "s", "route"),
		D(105, "Vendor at NPC", "kv", "A whole vendor visit (Items > Vendor): sells, buys and banks by the profile (empty: the one named after the vendor). The condition \"Vendor visit finished\" says how it went.", "n", "s", "NPC", "p", "s", "profile")
	};

	public static readonly string[][] Options = new string[7][]
	{
		new string[2] { "EnableCombat", "combat" },
		new string[2] { "EnableLooting", "looting" },
		new string[2] { "EnableBuffing", "buffing" },
		new string[2] { "EnableNav", "nav" },
		new string[2] { "EnableMeta", "the meta" },
		new string[2] { "EnableSummoning", "summoning" },
		new string[2] { "EnableDoors", "doors" }
	};

	private static TypeDef D(int id, string name, string data, string help, params string[] keys)
	{
		TypeDef typeDef = new TypeDef
		{
			Id = id,
			Name = name,
			Data = data,
			Help = help
		};
		if (keys.Length != 0)
		{
			List<string[]> list = new List<string[]>();
			for (int i = 0; i + 2 < keys.Length; i += 3)
			{
				list.Add(new string[3]
				{
					keys[i],
					keys[i + 1],
					keys[i + 2]
				});
			}
			typeDef.Keys = list.ToArray();
		}
		return typeDef;
	}

	public static TypeDef Cond(int id)
	{
		TypeDef[] conds = Conds;
		foreach (TypeDef typeDef in conds)
		{
			if (typeDef.Id == id)
			{
				return typeDef;
			}
		}
		return null;
	}

	public static TypeDef Act(int id)
	{
		TypeDef[] acts = Acts;
		foreach (TypeDef typeDef in acts)
		{
			if (typeDef.Id == id)
			{
				return typeDef;
			}
		}
		return null;
	}

	public static string CondName(int id)
	{
		TypeDef typeDef = Cond(id);
		return (typeDef != null) ? typeDef.Name : ("condition " + id);
	}

	public static string ActName(int id)
	{
		TypeDef typeDef = Act(id);
		return (typeDef != null) ? typeDef.Name : ("action " + id);
	}

	private static string Num(MVal v)
	{
		return (v == null) ? "?" : v.S;
	}

	public static string NavSummary(byte[] b, out string name, out int points)
	{
		name = "";
		points = 0;
		string text = Meta.Enc.GetString(b ?? new byte[0]);
		string[] array = text.Split(new string[2] { "\r\n", "\n" }, StringSplitOptions.None);
		if (array.Length != 0)
		{
			name = array[0].Trim();
		}
		if (text.IndexOf("<MelkTankRoute", StringComparison.Ordinal) >= 0)
		{
			if (array.Length > 1)
			{
				int.TryParse(array[1].Trim(), out points);
			}
			return name;
		}
		int num = Array.FindIndex(array, (string x) => x.StartsWith("uTank2 NAV", StringComparison.OrdinalIgnoreCase));
		if (num >= 0 && num + 2 < array.Length)
		{
			int.TryParse(array[num + 2].Trim(), out points);
		}
		if (name.StartsWith("uTank2", StringComparison.OrdinalIgnoreCase))
		{
			name = "";
		}
		return name;
	}

	public static string Describe(MCond c)
	{
		if (c == null)
		{
			return "?";
		}
		MVal data = c.Data;
		return c.Type switch
		{
			0 => "never", 
			1 => "always", 
			2 => (c.Kids == null || c.Kids.Count == 0) ? "always (empty 'all of')" : Join(c.Kids, " and "), 
			3 => (c.Kids == null || c.Kids.Count == 0) ? "never (empty 'any of')" : Join(c.Kids, " or "), 
			21 => "not (" + ((c.Kids != null && c.Kids.Count > 0) ? Join(c.Kids, " and ") : "?") + ")", 
			4 => "chat says \"" + ((data != null) ? data.S : "") + "\"", 
			5 => "main pack free slots <= " + Num(data), 
			6 => Num(data) + " s in this state", 
			7 => "route finished", 
			8 => "you died", 
			9 => "a vendor is open", 
			10 => "the vendor closed", 
			11 => "have <= " + data.GetS("c") + " " + data.GetS("n"), 
			12 => "have >= " + data.GetS("c") + " " + data.GetS("n"), 
			13 => ">= " + data.GetS("c") + " \"" + data.GetS("n") + "\" within " + data.GetS("r"), 
			14 => ">= " + data.GetS("c") + " priority-" + data.GetS("p") + " monsters within " + data.GetS("r"), 
			15 => "need to buff", 
			16 => "no monsters within " + data.GetS("r"), 
			17 => "in landblock " + Hex(data, block: true), 
			18 => "in landcell " + Hex(data, block: false), 
			19 => "went into portal space", 
			20 => "came out of portal space", 
			22 => Num(data) + " s in this state (persistent)", 
			23 => "spell " + data.GetS("sid") + " has >= " + data.GetS("sec") + " s left", 
			24 => "burden >= " + Num(data) + "%", 
			25 => "route point distance >= " + Num(data), 
			26 => "[" + data.GetS("e") + "]", 
			27 => "dialog \"" + data.GetS("p") + "\"", 
			28 => "chat captures \"" + data.GetS("p") + "\"", 
			_ => CondName(c.Type), 
		};
	}

	private static string Join(List<MCond> l, string sep)
	{
		List<string> list = new List<string>();
		foreach (MCond item in l)
		{
			string text = Describe(item);
			if ((item.Type == 2 || item.Type == 3) && item.Kids != null && item.Kids.Count > 1)
			{
				text = "(" + text + ")";
			}
			list.Add(text);
		}
		return string.Join(sep, list.ToArray());
	}

	private static string Hex(MVal d, bool block)
	{
		if (d == null)
		{
			return "?";
		}
		return ((uint)d.AsInt).ToString("X8", Inv);
	}

	public static string Describe(MAct a)
	{
		if (a == null)
		{
			return "?";
		}
		MVal data = a.Data;
		switch (a.Type)
		{
		case 0:
			return "nothing";
		case 1:
			return "go to " + ((data != null) ? data.S : "?");
		case 2:
			return "send " + ((data != null) ? data.S : "");
		case 3:
		{
			if (a.Kids == null || a.Kids.Count == 0)
			{
				return "nothing (empty 'do all')";
			}
			List<string> list = new List<string>();
			foreach (MAct kid in a.Kids)
			{
				list.Add(Describe(kid));
			}
			return string.Join("; ", list.ToArray());
		}
		case 4:
		{
			NavSummary(data?.B, out var name, out var points);
			bool flag = data != null && data.B != null && Meta.Enc.GetString(data.B).IndexOf("<MelkTankRoute", StringComparison.Ordinal) >= 0;
			return "load route " + ((name.Length > 0) ? name : "(unnamed)") + " (" + points + (flag ? " steps)" : " points)");
		}
		case 5:
			return "call " + data.GetS("st") + " (back to " + data.GetS("ret") + ")";
		case 6:
			return "return from call";
		case 7:
			return "run [" + data.GetS("e") + "]";
		case 8:
			return "send [" + data.GetS("e") + "]";
		case 9:
			return "watchdog: if not " + data.GetS("r") + " in " + data.GetS("t") + " s, go to " + data.GetS("s");
		case 10:
			return "clear watchdog";
		case 11:
			return "get " + OptLabel(data.GetS("o")) + " into $" + data.GetS("v");
		case 12:
			return "turn " + OptLabel(data.GetS("o")) + (IsOn(data.GetS("v")) ? " on" : " off");
		case 100:
			return "use " + data.GetS("n");
		case 101:
			return "talk to " + data.GetS("n");
		case 102:
			return "use portal " + data.GetS("n");
		case 103:
			return "give " + data.GetS("i") + " to " + data.GetS("n");
		case 104:
			return "load route " + data.GetS("n");
		case 13:
			return "open view " + data.GetS("n");
		case 14:
			return "close view " + data.GetS("n");
		case 15:
			return "close all views";
		default:
			return ActName(a.Type);
		}
	}

	public static string OptLabel(string o)
	{
		string[][] options = Options;
		foreach (string[] array in options)
		{
			if (string.Equals(array[0], o, StringComparison.OrdinalIgnoreCase))
			{
				return array[1];
			}
		}
		return o;
	}

	public static bool IsOn(string v)
	{
		v = (v ?? "").Trim();
		return v == "1" || v.Equals("true", StringComparison.OrdinalIgnoreCase) || v.Equals("on", StringComparison.OrdinalIgnoreCase);
	}

	public static MVal NewData(TypeDef t)
	{
		if (t == null)
		{
			return MVal.Int(0);
		}
		string data = t.Data;
		string text = data;
		if (text == null || text.Length != 0)
		{
			switch (text)
			{
			case "i":
			case "hex":
				break;
			case "s":
				return MVal.Str("");
			case "ba":
				return MVal.Bytes(new byte[0]);
			case "kids":
				return null;
			default:
			{
				MVal mVal = MVal.Dict();
				if (t.Keys != null)
				{
					string[][] keys = t.Keys;
					foreach (string[] array in keys)
					{
						MVal mVal2 = mVal;
						string key = array[0];
						MVal val;
						if (array[1] == "i")
						{
							val = MVal.Int(0);
						}
						else if (array[1] == "d")
						{
							val = MVal.Dbl(0.0);
						}
						else
						{
							val = ((array[1] == "ba") ? MVal.Bytes(new byte[0]) : MVal.Str(""));
						}
						mVal2.Set(key, val);
					}
				}
				return mVal;
			}
			}
		}
		return MVal.Int(0);
	}
}
