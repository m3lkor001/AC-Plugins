using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using MelkTank.Loot;

namespace MelkTank.Metas;

public static class ExprFuncs
{
	private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

	private static readonly Random _rnd = new Random();

	private static CoreManager Core => CoreManager.Current;

	private static int Me => Core.CharacterFilter.Id;

	private static Nav NavNow => PluginCore.CurrentEngine?.Nav;

	private static void Need(object[] a, int n, string f)
	{
		if (a.Length < n)
		{
			throw new Exception(f + " expects " + n + " argument" + ((n == 1) ? "" : "s") + ". " + a.Length + " were passed.");
		}
	}

	private static object A(object[] a, int i)
	{
		return (i < a.Length) ? a[i] : null;
	}

	private static double N(object[] a, int i)
	{
		object obj = A(a, i);
		if (!(obj is double result))
		{
			if (obj is ExprWO)
			{
				return ((ExprWO)obj).Id;
			}
			if (obj is string && double.TryParse((string)obj, NumberStyles.Float, Inv, out var result2))
			{
				return result2;
			}
			throw new Exception("argument #" + (i + 1) + " should be a number but a " + Expr.TypeName(obj) + " was passed (" + Expr.Str(obj) + ")");
		}
		return result;
	}

	private static int I(object[] a, int i)
	{
		return Convert.ToInt32(N(a, i));
	}

	private static string S(object[] a, int i)
	{
		return Expr.Str(A(a, i));
	}

	private static ExprWO W(object[] a, int i)
	{
		object obj = A(a, i);
		if (obj is ExprWO result)
		{
			return result;
		}
		if (obj is double)
		{
			return new ExprWO(Convert.ToInt32((double)obj));
		}
		throw new NullReferenceException();
	}

	private static ExprList L(object[] a, int i)
	{
		if (!(A(a, i) is ExprList result))
		{
			throw new Exception("argument #" + (i + 1) + " should be a list but a " + Expr.TypeName(A(a, i)) + " was passed");
		}
		return result;
	}

	private static ExprDict D(object[] a, int i)
	{
		if (!(A(a, i) is ExprDict result))
		{
			throw new Exception("argument #" + (i + 1) + " should be a dictionary but a " + Expr.TypeName(A(a, i)) + " was passed");
		}
		return result;
	}

	private static ExprCoords C(object[] a, int i)
	{
		if (!(A(a, i) is ExprCoords result))
		{
			throw new Exception("argument #" + (i + 1) + " should be coordinates but a " + Expr.TypeName(A(a, i)) + " was passed");
		}
		return result;
	}

	private static ExprStopwatch SW(object[] a, int i)
	{
		if (!(A(a, i) is ExprStopwatch result))
		{
			throw new Exception("argument #" + (i + 1) + " should be a stopwatch");
		}
		return result;
	}

	private static object WOrZero(WorldObject o)
	{
		return (o != null) ? new ExprWO(o.Id) : ((object)0.0);
	}

	private static ExprList WList(IEnumerable<WorldObject> objs)
	{
		ExprList exprList = new ExprList();
		foreach (WorldObject obj in objs)
		{
			if (obj != null && Core.Actions.IsValidObject(obj.Id))
			{
				exprList.Items.Add(new ExprWO(obj.Id));
			}
		}
		return exprList;
	}

	private static double Dist(WorldObject o)
	{
		try
		{
			return CombatEngine.Distance(o);
		}
		catch
		{
			return double.MaxValue;
		}
	}

	private static WorldObject Nearest(IEnumerable<WorldObject> objs, Func<WorldObject, bool> ok)
	{
		WorldObject result = null;
		double num = double.MaxValue;
		int me = Me;
		foreach (WorldObject obj in objs)
		{
			if (obj != null && obj.Id != me && ok(obj))
			{
				double num2 = Dist(obj);
				if (num2 < num)
				{
					num = num2;
					result = obj;
				}
			}
		}
		return result;
	}

	private static long StackOf(WorldObject o)
	{
		int num = o.Values(LongValueKey.StackCount, 0);
		return (num < 1) ? 1 : num;
	}

	public static ExprCoords CoordsOf(WorldObject o)
	{
		CoordsObject coordsObject = o.Coordinates();
		double z = 0.0;
		try
		{
			z = o.RawCoordinates().Z;
		}
		catch
		{
		}
		return new ExprCoords(coordsObject.EastWest, coordsObject.NorthSouth, z);
	}

	public static object Run(string f, object[] a)
	{
		switch (f)
		{
		case "getvar":
			Need(a, 1, f);
			return Expr.GetSession(S(a, 0));
		case "setvar":
			Need(a, 2, f);
			return Expr.SetSession(S(a, 0), A(a, 1));
		case "testvar":
			Need(a, 1, f);
			return Expr.TestSession(S(a, 0));
		case "clearvar":
			Need(a, 1, f);
			return Expr.ClearSession(S(a, 0));
		case "clearallvars":
			Expr.ClearAllSession();
			return 1.0;
		case "touchvar":
			Need(a, 1, f);
			if (Expr.TestSession(S(a, 0)))
			{
				return 1.0;
			}
			Expr.SetSession(S(a, 0), 0.0);
			return 0.0;
		case "getpvar":
			Need(a, 1, f);
			return Expr.GetP(S(a, 0));
		case "setpvar":
			Need(a, 2, f);
			return Expr.SetP(S(a, 0), A(a, 1));
		case "testpvar":
			Need(a, 1, f);
			return Expr.TestP(S(a, 0));
		case "clearpvar":
			Need(a, 1, f);
			return Expr.ClearP(S(a, 0));
		case "clearallpvars":
			Expr.ClearAllP();
			return 1.0;
		case "touchpvar":
			Need(a, 1, f);
			if (Expr.TestP(S(a, 0)))
			{
				return 1.0;
			}
			Expr.SetP(S(a, 0), 0.0);
			return 0.0;
		case "getgvar":
			Need(a, 1, f);
			return Expr.GetG(S(a, 0));
		case "setgvar":
			Need(a, 2, f);
			return Expr.SetG(S(a, 0), A(a, 1));
		case "testgvar":
			Need(a, 1, f);
			return Expr.TestG(S(a, 0));
		case "cleargvar":
			Need(a, 1, f);
			return Expr.ClearG(S(a, 0));
		case "clearallgvars":
			Expr.ClearAllG();
			return 1.0;
		case "touchgvar":
			Need(a, 1, f);
			if (Expr.TestG(S(a, 0)))
			{
				return 1.0;
			}
			Expr.SetG(S(a, 0), 0.0);
			return 0.0;
		case "echo":
			Need(a, 1, f);
			Util.WriteToChatColor(Expr.Str(A(a, 0)), (a.Length <= 1) ? 1 : I(a, 1));
			return 1.0;
		case "chatbox":
			Need(a, 1, f);
			Util.Command(S(a, 0));
			return S(a, 0);
		case "chatboxpaste":
			Need(a, 1, f);
			Util.Command(S(a, 0));
			return 1.0;
		case "exec":
			Need(a, 1, f);
			return Expr.Run(S(a, 0));
		case "delayexec":
			Need(a, 2, f);
			return (double)Expr.Delay(N(a, 0), S(a, 1));
		case "clearexec":
			Need(a, 1, f);
			return Expr.ClearDelay(I(a, 0));
		case "ifthen":
			Need(a, 2, f);
			if (Expr.IsTruthy(A(a, 0)))
			{
				return Expr.Run(S(a, 1));
			}
			return (a.Length > 2) ? Expr.Run(S(a, 2)) : ((object)0.0);
		case "iif":
			Need(a, 3, f);
			return Expr.IsTruthy(A(a, 0)) ? A(a, 1) : A(a, 2);
		case "istrue":
			Need(a, 1, f);
			return Expr.IsTruthy(A(a, 0)) ? 1.0 : 0.0;
		case "isfalse":
			Need(a, 1, f);
			return (A(a, 0) is double && (double)A(a, 0) == 0.0) ? 1.0 : 0.0;
		case "getobjectinternaltype":
		{
			object obj5 = A(a, 0);
			if (obj5 == null)
			{
				return 0.0;
			}
			if (obj5 is double)
			{
				return 1.0;
			}
			if (obj5 is string)
			{
				return 3.0;
			}
			if (obj5 is ExprWO && ((ExprWO)obj5).Wo == null)
			{
				return 0.0;
			}
			return 7.0;
		}
		case "cstr":
			Need(a, 1, f);
			return Expr.Str(N(a, 0));
		case "tostring":
			Need(a, 1, f);
			return Expr.Str(A(a, 0));
		case "cstrf":
		{
			Need(a, 2, f);
			string text5 = S(a, 1);
			return text5.Contains("X") ? ((uint)N(a, 0)).ToString(text5, Inv) : N(a, 0).ToString(text5, Inv);
		}
		case "cnumber":
		{
			Need(a, 1, f);
			double result;
			return double.TryParse(S(a, 0), NumberStyles.Float, Inv, out result) ? result : 0.0;
		}
		case "hexstr":
			Need(a, 1, f);
			return "0x" + ((int)N(a, 0)).ToString("X");
		case "strlen":
			Need(a, 1, f);
			return (double)S(a, 0).Length;
		case "chr":
			Need(a, 1, f);
			return ((char)I(a, 0)).ToString();
		case "ord":
		{
			Need(a, 1, f);
			string text3 = S(a, 0);
			return (text3.Length > 0) ? ((double)(int)text3[0]) : 0.0;
		}
		case "getregexmatch":
		{
			Need(a, 2, f);
			Regex regex3 = new Regex(S(a, 1));
			Match match = regex3.Match(S(a, 0));
			return match.Success ? match.Value : ((object)0.0);
		}
		case "randint":
			Need(a, 2, f);
			return (double)_rnd.Next(I(a, 0), I(a, 1));
		case "abs":
			return Math.Abs(N(a, 0));
		case "floor":
			return Math.Floor(N(a, 0));
		case "ceiling":
			return Math.Ceiling(N(a, 0));
		case "round":
			return Math.Round(N(a, 0));
		case "sqrt":
			return Math.Sqrt(N(a, 0));
		case "sin":
			return Math.Sin(N(a, 0));
		case "cos":
			return Math.Cos(N(a, 0));
		case "tan":
			return Math.Tan(N(a, 0));
		case "asin":
			return Math.Asin(N(a, 0));
		case "acos":
			return Math.Acos(N(a, 0));
		case "atan":
			return Math.Atan(N(a, 0));
		case "sinh":
			return Math.Sinh(N(a, 0));
		case "cosh":
			return Math.Cosh(N(a, 0));
		case "tanh":
			return Math.Tanh(N(a, 0));
		case "getunixtime":
			return DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1)).TotalSeconds;
		case "getdatetimelocal":
			return DateTime.Now.ToString((a.Length != 0) ? S(a, 0) : "G", Inv);
		case "getdatetimeutc":
			return DateTime.UtcNow.ToString((a.Length != 0) ? S(a, 0) : "G", Inv);
		case "listcreate":
		{
			ExprList exprList13 = new ExprList();
			foreach (object item in a)
			{
				exprList13.Items.Add(item);
			}
			return exprList13;
		}
		case "listadd":
			Need(a, 2, f);
			L(a, 0).Items.Add(A(a, 1));
			return L(a, 0);
		case "listinsert":
		{
			Need(a, 3, f);
			ExprList exprList12 = L(a, 0);
			int num17 = I(a, 2);
			if (num17 > exprList12.Items.Count)
			{
				throw new Exception("Attempted to insert item at index " + num17 + " of list, but list only has " + exprList12.Items.Count + " items");
			}
			exprList12.Items.Insert(num17, A(a, 1));
			return exprList12;
		}
		case "listremove":
			Need(a, 2, f);
			L(a, 0).Items.Remove(A(a, 1));
			return L(a, 0);
		case "listremoveat":
		{
			Need(a, 2, f);
			ExprList exprList11 = L(a, 0);
			int num15 = I(a, 1);
			if (num15 > exprList11.Items.Count - 1)
			{
				throw new Exception("Attempted to remove item at index " + num15 + " of list, but list only has " + exprList11.Items.Count + " items");
			}
			exprList11.Items.RemoveAt(num15);
			return exprList11;
		}
		case "listgetitem":
		{
			Need(a, 2, f);
			ExprList exprList10 = L(a, 0);
			int num14 = I(a, 1);
			if (num14 > exprList10.Items.Count - 1)
			{
				throw new Exception("Attempted to get item at index " + num14 + " of list, but list only has " + exprList10.Items.Count + " items");
			}
			return exprList10.Items[num14];
		}
		case "listcontains":
			Need(a, 2, f);
			return L(a, 0).Items.Contains(A(a, 1));
		case "listindexof":
			Need(a, 2, f);
			return (double)L(a, 0).Items.IndexOf(A(a, 1));
		case "listlastindexof":
			Need(a, 2, f);
			return (double)L(a, 0).Items.LastIndexOf(A(a, 1));
		case "listcount":
			Need(a, 1, f);
			return (double)L(a, 0).Items.Count;
		case "listclear":
			Need(a, 1, f);
			L(a, 0).Items.Clear();
			return L(a, 0);
		case "listcopy":
		{
			Need(a, 1, f);
			ExprList exprList8 = new ExprList();
			exprList8.Items.AddRange(L(a, 0).Items);
			return exprList8;
		}
		case "listreverse":
		{
			Need(a, 1, f);
			ExprList exprList9 = new ExprList();
			exprList9.Items.AddRange(L(a, 0).Items);
			exprList9.Items.Reverse();
			return exprList9;
		}
		case "listpop":
		{
			Need(a, 1, f);
			ExprList exprList6 = L(a, 0);
			int num13 = ((a.Length > 1) ? I(a, 1) : (-1));
			if (exprList6.Items.Count == 0 || num13 > exprList6.Items.Count - 1)
			{
				throw new Exception("Attempted to pop item at index " + num13 + " of list, but list only has " + exprList6.Items.Count + " items");
			}
			if (num13 == -1)
			{
				num13 = exprList6.Items.Count - 1;
			}
			object result3 = exprList6.Items[num13];
			exprList6.Items.RemoveAt(num13);
			return result3;
		}
		case "listfromrange":
		{
			Need(a, 2, f);
			int num9 = (int)N(a, 0);
			int num10 = (int)N(a, 1);
			ExprList exprList5 = new ExprList();
			if (num9 == num10)
			{
				exprList5.Items.Add((double)num9);
				return exprList5;
			}
			int num11 = ((num9 < num10) ? 1 : (-1));
			for (int num12 = num9; (num11 > 0) ? (num12 <= num10) : (num12 >= num10); num12 += num11)
			{
				exprList5.Items.Add((double)num12);
			}
			return exprList5;
		}
		case "listsort":
		{
			Need(a, 1, f);
			ExprList exprList4 = new ExprList();
			exprList4.Items.AddRange(L(a, 0).Items);
			bool desc = a.Length > 1 && S(a, 1).Trim().ToUpperInvariant() == "DESC";
			exprList4.Items.Sort((object x, object y) => ((x is double && y is double) ? ((double)x).CompareTo((double)y) : string.Compare(Expr.Str(x), Expr.Str(y), StringComparison.OrdinalIgnoreCase)) * ((!desc) ? 1 : (-1)));
			return exprList4;
		}
		case "listfilter":
			Need(a, 2, f);
			return Iterate(L(a, 0), S(a, 1), 0);
		case "listmap":
			Need(a, 2, f);
			return Iterate(L(a, 0), S(a, 1), 1);
		case "listreduce":
			Need(a, 2, f);
			return Iterate(L(a, 0), S(a, 1), 2);
		case "dictcreate":
		{
			if (a.Length % 2 == 1)
			{
				throw new Exception("You passed in an odd number of arguments which cannot be used to create a dictionary");
			}
			ExprDict exprDict2 = new ExprDict();
			for (int num8 = 0; num8 < a.Length; num8 += 2)
			{
				if (!(a[num8] is string))
				{
					throw new Exception("Error with key " + Expr.Str(a[num8]) + ". Keys must be strings");
				}
				exprDict2.Set((string)a[num8], a[num8 + 1]);
			}
			return exprDict2;
		}
		case "dictgetitem":
		{
			Need(a, 2, f);
			if (!D(a, 0).Items.TryGetValue(S(a, 1), out var value))
			{
				throw new Exception("Attempted to get item at for key " + S(a, 1) + " of dictionary but it was not found");
			}
			return value;
		}
		case "dictadditem":
		{
			Need(a, 3, f);
			bool flag = D(a, 0).Items.ContainsKey(S(a, 1));
			D(a, 0).Set(S(a, 1), A(a, 2));
			return flag ? 1.0 : 0.0;
		}
		case "dicthaskey":
			Need(a, 2, f);
			return D(a, 0).Items.ContainsKey(S(a, 1));
		case "dictremovekey":
			Need(a, 2, f);
			return D(a, 0).Remove(S(a, 1));
		case "dictkeys":
		{
			Need(a, 1, f);
			ExprList exprList2 = new ExprList();
			foreach (string key in D(a, 0).Keys)
			{
				exprList2.Items.Add(key);
			}
			return exprList2;
		}
		case "dictvalues":
		{
			Need(a, 1, f);
			ExprList exprList3 = new ExprList();
			foreach (string key2 in D(a, 0).Keys)
			{
				exprList3.Items.Add(D(a, 0).Items[key2]);
			}
			return exprList3;
		}
		case "dictsize":
			Need(a, 1, f);
			return (double)D(a, 0).Items.Count;
		case "dictclear":
			Need(a, 1, f);
			D(a, 0).Items.Clear();
			D(a, 0).Keys.Clear();
			return D(a, 0);
		case "dictcopy":
		{
			Need(a, 1, f);
			ExprDict exprDict = new ExprDict();
			foreach (string key3 in D(a, 0).Keys)
			{
				exprDict.Set(key3, D(a, 0).Items[key3]);
			}
			return exprDict;
		}
		case "stopwatchcreate":
			return new ExprStopwatch();
		case "stopwatchstart":
			Need(a, 1, f);
			SW(a, 0).Watch.Start();
			return SW(a, 0);
		case "stopwatchstop":
			Need(a, 1, f);
			SW(a, 0).Watch.Stop();
			return SW(a, 0);
		case "stopwatchelapsedseconds":
			Need(a, 1, f);
			return SW(a, 0).Elapsed();
		case "getplayercoordinates":
			return CoordsOf(Core.WorldFilter[Me]);
		case "wobjectgetphysicscoordinates":
			Need(a, 1, f);
			return CoordsOf(W(a, 0).W);
		case "coordinatetostring":
			Need(a, 1, f);
			return C(a, 0).ToString();
		case "coordinatedistancewithz":
			Need(a, 2, f);
			return C(a, 0).DistanceTo(C(a, 1), withZ: true);
		case "coordinatedistanceflat":
			Need(a, 2, f);
			return C(a, 0).DistanceTo(C(a, 1), withZ: false);
		case "coordinategetns":
			Need(a, 1, f);
			return C(a, 0).NS;
		case "coordinategetwe":
			Need(a, 1, f);
			return C(a, 0).EW;
		case "coordinategetz":
			Need(a, 1, f);
			return C(a, 0).Z;
		case "coordinateparse":
		{
			Need(a, 1, f);
			Match match2 = Regex.Match(S(a, 0), "(?<ns>\\d+(\\.\\d+)?)\\s*(?<nsd>[ns])[,\\s]+(?<ew>\\d+(\\.\\d+)?)\\s*(?<ewd>[ew])(?:[,\\s]+(?<z>-?\\d+(\\.\\d+)?)\\s*z)?", RegexOptions.IgnoreCase);
			if (!match2.Success)
			{
				return 0.0;
			}
			double ns = double.Parse(match2.Groups["ns"].Value, Inv) * (double)((!(match2.Groups["nsd"].Value.ToLowerInvariant() == "s")) ? 1 : (-1));
			double ew = double.Parse(match2.Groups["ew"].Value, Inv) * (double)((!(match2.Groups["ewd"].Value.ToLowerInvariant() == "w")) ? 1 : (-1));
			double z = (match2.Groups["z"].Success ? (double.Parse(match2.Groups["z"].Value, Inv) * 240.0) : 0.0);
			return new ExprCoords(ew, ns, z);
		}
		case "vendoropen":
			return VendorRun.ShopOpenAny() ? 1.0 : 0.0;
		case "vendorbusy":
			return (VendorRun.I != null && VendorRun.I.Busy) ? 1.0 : 0.0;
		case "lastvendorresult":
			return VendorRun.ResultWord(VendorRun.Last);
		case "lastvendorsummary":
			return VendorRun.LastSummary;
		case "getcharintprop":
		{
			Need(a, 1, f);
			int charProperty = Core.CharacterFilter.GetCharProperty(I(a, 0));
			return (charProperty == -1) ? 0.0 : ((double)charProperty);
		}
		case "getchardoubleprop":
			Need(a, 1, f);
			return Core.WorldFilter[Me].Values((DoubleValueKey)I(a, 0), 0.0);
		case "getcharboolprop":
			Need(a, 1, f);
			return Core.WorldFilter[Me].Values((BoolValueKey)I(a, 0), false);
		case "getcharstringprop":
		{
			Need(a, 1, f);
			string text6 = Core.WorldFilter[Me].Values((StringValueKey)I(a, 0), "");
			return string.IsNullOrEmpty(text6) ? ((object)0.0) : text6;
		}
		case "getcharattribute_base":
			Need(a, 1, f);
			return (double)Core.CharacterFilter.Attributes[(CharFilterAttributeType)I(a, 0)].Base;
		case "getcharattribute_buffed":
			Need(a, 1, f);
			return (double)Core.CharacterFilter.EffectiveAttribute[(CharFilterAttributeType)I(a, 0)];
		case "getcharvital_base":
			Need(a, 1, f);
			return (double)Core.CharacterFilter.Vitals[(CharFilterVitalType)(I(a, 0) * 2)].Base;
		case "getcharvital_buffedmax":
			Need(a, 1, f);
			return (double)Core.CharacterFilter.EffectiveVital[(CharFilterVitalType)(I(a, 0) * 2)];
		case "getcharvital_current":
		{
			Need(a, 1, f);
			int num20 = I(a, 0);
			CharacterFilter characterFilter = Core.CharacterFilter;
			return (double)(num20 switch
			{
				3 => characterFilter.Mana, 
				2 => characterFilter.Stamina, 
				1 => characterFilter.Health, 
				_ => 0, 
			});
		}
		case "getcharskill_base":
			Need(a, 1, f);
			return (double)Core.CharacterFilter.Skills[(CharFilterSkillType)I(a, 0)].Base;
		case "getcharskill_buffed":
		{
			Need(a, 1, f);
			double num18 = Core.CharacterFilter.EffectiveSkill[(CharFilterSkillType)I(a, 0)];
			if (Core.CharacterFilter.GetCharProperty(326) == 1)
			{
				num18 += 5.0;
			}
			if (Core.CharacterFilter.GetCharProperty(302) == 1)
			{
				num18 += 10.0;
			}
			return num18;
		}
		case "getcharskill_traininglevel":
			Need(a, 1, f);
			return (double)Core.CharacterFilter.Skills[(CharFilterSkillType)I(a, 0)].Training;
		case "getcharburden":
			return (double)Core.CharacterFilter.Burden;
		case "getisspellknown":
			Need(a, 1, f);
			return Core.CharacterFilter.IsSpellKnown(I(a, 0));
		case "getcombatstate":
			return Core.Actions.CombatMode.ToString();
		case "setcombatstate":
			Need(a, 1, f);
			switch (S(a, 0).ToLowerInvariant())
			{
			case "peace":
				Core.Actions.SetCombatMode(CombatState.Peace);
				return 1.0;
			case "melee":
				Core.Actions.SetCombatMode(CombatState.Melee);
				return 1.0;
			case "missile":
				Core.Actions.SetCombatMode(CombatState.Missile);
				return 1.0;
			case "magic":
				Core.Actions.SetCombatMode(CombatState.Magic);
				return 1.0;
			default:
				Util.WriteToChat(S(a, 0) + " is not a valid option");
				return 0.0;
			}
		case "getbusystate":
			return (double)Core.Actions.BusyState;
		case "getplayerlandcell":
			return (double)(uint)Core.Actions.Landcell;
		case "getplayerlandblock":
			return (double)(uint)(Core.Actions.Landcell & -65536);
		case "getheading":
		{
			Need(a, 1, f);
			ExprWO exprWO2 = W(a, 0);
			if (exprWO2.Id == Me)
			{
				return Core.Actions.Heading;
			}
			return HeadingOf(exprWO2.W);
		}
		case "getheadingto":
		{
			Need(a, 1, f);
			ExprCoords exprCoords = CoordsOf(Core.WorldFilter[Me]);
			ExprCoords exprCoords2 = CoordsOf(W(a, 0).W);
			double num16 = Math.Atan2(exprCoords2.EW - exprCoords.EW, exprCoords2.NS - exprCoords.NS) * 180.0 / Math.PI;
			return (num16 < 0.0) ? (num16 + 360.0) : num16;
		}
		case "isportaling":
		{
			Nav navNow4 = NavNow;
			try
			{
				if (Core.CharacterFilter.LoginStatus != 3)
				{
					return 1.0;
				}
			}
			catch
			{
			}
			return (navNow4 != null && navNow4.InPortal) ? 1.0 : 0.0;
		}
		case "getworldname":
			return Core.CharacterFilter.Server;
		case "getcharacterindex":
			return 0.0;
		case "vitae":
			return (double)Core.CharacterFilter.Vitae;
		case "iscasting":
			return Core.Actions.BusyState != 0 && Core.Actions.CombatMode == CombatState.Magic;
		case "getequippedweapontype":
			foreach (WorldObject item2 in Core.WorldFilter.GetInventory())
			{
				if (item2.Values(LongValueKey.EquippedSlots, 0) != 0 && (item2.ObjectClass == ObjectClass.MeleeWeapon || item2.ObjectClass == ObjectClass.MissileWeapon || item2.ObjectClass == ObjectClass.WandStaffOrb))
				{
					return (double)item2.ObjectClass;
				}
			}
			return 0.0;
		case "getfellowshipstatus":
			return CorpseKillers.InFellow;
		case "getfellowshipcount":
			return (double)(CorpseKillers.InFellow ? (CorpseKillers.FellowCount + 1) : 0);
		case "getfellowshipisleader":
			return CorpseKillers.InFellow && CorpseKillers.LeaderId == Me;
		case "getfellowshipleaderid":
			return (double)CorpseKillers.LeaderId;
		case "getfellowshipisopen":
			return CorpseKillers.Open == true;
		case "getfellowshiplocked":
			return CorpseKillers.Locked == true;
		case "getfellownames":
		{
			ExprList exprList7 = new ExprList();
			if (CorpseKillers.InFellow)
			{
				exprList7.Items.Add(Core.CharacterFilter.Name);
				foreach (string fellow in CorpseKillers.Fellows)
				{
					exprList7.Items.Add(fellow);
				}
			}
			return exprList7;
		}
		case "testquestflag":
			Need(a, 1, f);
			return ExprQuests.Has(S(a, 0));
		case "getqueststatus":
			Need(a, 1, f);
			return ExprQuests.Ready(S(a, 0));
		case "getquestktprogress":
			Need(a, 1, f);
			return (double)ExprQuests.Solves(S(a, 0));
		case "getquestktrequired":
			Need(a, 1, f);
			return (double)ExprQuests.MaxSolves(S(a, 0));
		case "isrefreshingquests":
			return ExprQuests.Refreshing;
		case "vtgetsetting":
		{
			Need(a, 1, f);
			Nav navNow3 = NavNow;
			string text4 = ((navNow3 != null) ? navNow3.ExprOptGet(S(a, 0)) : "0");
			double result2;
			return double.TryParse(text4, NumberStyles.Float, Inv, out result2) ? ((object)result2) : text4;
		}
		case "vtsetsetting":
			Need(a, 2, f);
			NavNow?.ExprOptSet(S(a, 0), S(a, 1));
			return 1.0;
		case "vtsetmetastate":
			Need(a, 1, f);
			NavNow?.VtCommand("/vt setmetastate " + S(a, 0));
			return 1.0;
		case "vtgetmetastate":
		{
			Nav navNow2 = NavNow;
			return (navNow2 != null) ? navNow2.MetaCurState : "";
		}
		case "vtgetmeta":
		{
			Nav navNow = NavNow;
			return (navNow != null) ? navNow.MetaName : "";
		}
		case "vtmacroenabled":
			return NavNow?.MetaRunning ?? false;
		case "uboptget":
			Need(a, 1, f);
			return 0.0;
		case "uboptset":
			Need(a, 2, f);
			return 1.0;
		case "uigetcontrol":
		case "uisetlabel":
		case "uisetvisible":
		case "uiviewexists":
		case "uiviewvisible":
			return 0.0;
		case "statushud":
		case "statushudcolored":
			return 1.0;
		case "actiontryselect":
			Need(a, 1, f);
			Core.Actions.SelectItem(W(a, 0).W.Id);
			return 0.0;
		case "actiontryuseitem":
			Need(a, 1, f);
			Core.Actions.UseItem(W(a, 0).W.Id, 0);
			return 0.0;
		case "actiontryapplyitem":
		{
			Need(a, 2, f);
			if (Core.Actions.BusyState != 0)
			{
				return 0.0;
			}
			WorldObject w2 = W(a, 0).W;
			WorldObject w3 = W(a, 1).W;
			if (w2.ObjectClass == ObjectClass.WandStaffOrb && Core.Actions.CombatMode != CombatState.Magic)
			{
				return 0.0;
			}
			Core.Actions.SelectItem(w3.Id);
			if (w2.ObjectClass == ObjectClass.WandStaffOrb)
			{
				Core.Actions.UseItem(w2.Id, 1, w3.Id);
			}
			else
			{
				Core.Actions.ApplyItem(w2.Id, w3.Id);
			}
			return 1.0;
		}
		case "actiontrygiveitem":
			Need(a, 2, f);
			if (Core.Actions.BusyState != 0)
			{
				return 0.0;
			}
			Core.Actions.GiveItem(W(a, 0).W.Id, W(a, 1).W.Id);
			return 1.0;
		case "actiontrydrop":
			Need(a, 1, f);
			if (Core.Actions.BusyState != 0)
			{
				return 0.0;
			}
			Core.Actions.DropItem(W(a, 0).W.Id);
			return 1.0;
		case "actiontryequipanywand":
			return EquipAnyWand();
		case "actiontrycastbyid":
			Need(a, 1, f);
			return CastById(I(a, 0), 0);
		case "actiontrycastbyidontarget":
			Need(a, 2, f);
			return CastById(I(a, 0), W(a, 1).W.Id);
		case "setmotion":
			Need(a, 2, f);
			return SetMotion(S(a, 0), N(a, 1) != 0.0);
		case "clearmotion":
			SetMotion("forward", on: false);
			return 1.0;
		case "wobjectgetplayer":
			return new ExprWO(Me);
		case "wobjectgetselection":
		{
			int currentSelection = Core.Actions.CurrentSelection;
			return Core.Actions.IsValidObject(currentSelection) ? new ExprWO(currentSelection) : ((object)0.0);
		}
		case "wobjectgetopencontainer":
		{
			int openedContainer = Core.Actions.OpenedContainer;
			return (openedContainer == 0) ? ((object)0.0) : new ExprWO(openedContainer);
		}
		case "wobjectfindbyid":
		{
			Need(a, 1, f);
			int id2 = I(a, 0);
			return (Core.Actions.IsValidObject(id2) && Core.WorldFilter[id2] != null) ? new ExprWO(id2) : ((object)0.0);
		}
		case "wobjectisvalid":
		{
			Need(a, 1, f);
			ExprWO exprWO = W(a, 0);
			try
			{
				return Core.Actions.IsValidObject(exprWO.Id) && Core.Actions.Underlying.GetPhysicsObjectPtr(exprWO.Id) != 0;
			}
			catch
			{
				return 0.0;
			}
		}
		case "wobjectgetid":
			Need(a, 1, f);
			return (double)W(a, 0).W.Id;
		case "wobjectgetname":
			Need(a, 1, f);
			return W(a, 0).W.Name;
		case "wobjectgetobjectclass":
			Need(a, 1, f);
			return (double)W(a, 0).W.ObjectClass;
		case "wobjectgettemplatetype":
			Need(a, 1, f);
			return (double)W(a, 0).W.Type;
		case "wobjectgetintprop":
			Need(a, 2, f);
			return (double)W(a, 0).W.Values((LongValueKey)I(a, 1), 0);
		case "wobjectgetdoubleprop":
			Need(a, 2, f);
			return W(a, 0).W.Values((DoubleValueKey)I(a, 1), 0.0);
		case "wobjectgetboolprop":
			Need(a, 2, f);
			return W(a, 0).W.Values((BoolValueKey)I(a, 1), false);
		case "wobjectgetstringprop":
			Need(a, 2, f);
			return W(a, 0).W.Values((StringValueKey)I(a, 1), "");
		case "wobjecthasdata":
			Need(a, 1, f);
			return W(a, 0).W.HasIdData;
		case "wobjectrequestdata":
			Need(a, 1, f);
			Util.RequestId(W(a, 0).Id);
			return 1.0;
		case "wobjectlastidtime":
			Need(a, 1, f);
			return (double)W(a, 0).W.LastIdTime;
		case "wobjectgethealth":
			Need(a, 1, f);
			return Expr.HealthOf(W(a, 0).W.Id);
		case "wobjectgetisdooropen":
			Need(a, 1, f);
			return DoorOpen(W(a, 0).W);
		case "wobjectgetspellids":
		case "wobjectgetactivespellids":
		{
			Need(a, 1, f);
			ExprList exprList = new ExprList();
			WorldObject w = W(a, 0).W;
			try
			{
				for (int num7 = 0; num7 < w.SpellCount; num7++)
				{
					exprList.Items.Add((double)w.Spell(num7));
				}
			}
			catch
			{
			}
			return exprList;
		}
		case "wobjectfindnearestmonster":
			return WOrZero(Nearest(Core.WorldFilter.GetByObjectClass(ObjectClass.Monster), (WorldObject o) => true));
		case "wobjectfindnearestdoor":
			return WOrZero(Nearest(Core.WorldFilter.GetByObjectClass(ObjectClass.Door), (WorldObject o) => true));
		case "wobjectfindnearestbyobjectclass":
			Need(a, 1, f);
			return WOrZero(Nearest(Core.WorldFilter.GetByObjectClass((ObjectClass)I(a, 0)), (WorldObject o) => true));
		case "wobjectfindnearestbynameandobjectclass":
		{
			Need(a, 2, f);
			Regex r4 = new Regex(S(a, 1));
			return WOrZero(Nearest(Core.WorldFilter.GetByObjectClass((ObjectClass)I(a, 0)), (WorldObject o) => r4.IsMatch(o.Name ?? "")));
		}
		case "wobjectfindnearestbytemplatetype":
		{
			Need(a, 1, f);
			int t4 = I(a, 0);
			return WOrZero(Nearest(Core.WorldFilter.GetLandscape(), (WorldObject o) => o.Type == t4));
		}
		case "wobjectfindininventorybyname":
		{
			Need(a, 1, f);
			string text2 = S(a, 0);
			foreach (WorldObject item3 in Core.WorldFilter.GetInventory())
			{
				if (item3.Name == text2)
				{
					return new ExprWO(item3.Id);
				}
			}
			return 0.0;
		}
		case "wobjectfindininventorybynamerx":
		{
			Need(a, 1, f);
			Regex regex2 = new Regex(S(a, 0));
			foreach (WorldObject item4 in Core.WorldFilter.GetInventory())
			{
				if (regex2.IsMatch(item4.Name ?? ""))
				{
					return new ExprWO(item4.Id);
				}
			}
			return 0.0;
		}
		case "wobjectfindininventorybytemplatetype":
		{
			Need(a, 1, f);
			int num6 = I(a, 0);
			foreach (WorldObject item5 in Core.WorldFilter.GetInventory())
			{
				if (item5.Type == num6)
				{
					return new ExprWO(item5.Id);
				}
			}
			return 0.0;
		}
		case "wobjectfindall":
			return WList(Core.WorldFilter.GetAll());
		case "wobjectfindallinventory":
			return WList(Core.WorldFilter.GetInventory());
		case "wobjectfindalllandscape":
			return WList(Core.WorldFilter.GetLandscape());
		case "wobjectfindallbycontainer":
		{
			Need(a, 1, f);
			object obj2 = A(a, 0);
			int id = ((obj2 is ExprWO) ? ((ExprWO)obj2).Id : I(a, 0));
			return WList(Core.WorldFilter.GetByContainer(id));
		}
		case "wobjectfindallbyobjectclass":
			Need(a, 1, f);
			return WList(Core.WorldFilter.GetByObjectClass((ObjectClass)I(a, 0)));
		case "wobjectfindallinventorybyobjectclass":
		{
			Need(a, 1, f);
			ObjectClass oc2 = (ObjectClass)I(a, 0);
			return WList(Filter(Core.WorldFilter.GetInventory(), (WorldObject o) => o.ObjectClass == oc2));
		}
		case "wobjectfindalllandscapebyobjectclass":
		{
			Need(a, 1, f);
			ObjectClass oc = (ObjectClass)I(a, 0);
			return WList(Filter(Core.WorldFilter.GetLandscape(), (WorldObject o) => o.ObjectClass == oc));
		}
		case "wobjectfindallbytemplatetype":
		{
			Need(a, 1, f);
			int t3 = I(a, 0);
			return WList(Filter(Core.WorldFilter.GetAll(), (WorldObject o) => o.Type == t3));
		}
		case "wobjectfindallinventorybytemplatetype":
		{
			Need(a, 1, f);
			int t2 = I(a, 0);
			return WList(Filter(Core.WorldFilter.GetInventory(), (WorldObject o) => o.Type == t2));
		}
		case "wobjectfindalllandscapebytemplatetype":
		{
			Need(a, 1, f);
			int t = I(a, 0);
			return WList(Filter(Core.WorldFilter.GetLandscape(), (WorldObject o) => o.Type == t));
		}
		case "wobjectfindallbynamerx":
		{
			Need(a, 1, f);
			Regex r3 = new Regex(S(a, 0));
			return WList(Filter(Core.WorldFilter.GetAll(), (WorldObject o) => r3.IsMatch(o.Name ?? "")));
		}
		case "wobjectfindallinventorybynamerx":
		{
			Need(a, 1, f);
			Regex r2 = new Regex(S(a, 0));
			return WList(Filter(Core.WorldFilter.GetInventory(), (WorldObject o) => r2.IsMatch(o.Name ?? "")));
		}
		case "wobjectfindalllandscapebynamerx":
		{
			Need(a, 1, f);
			Regex r = new Regex(S(a, 0));
			return WList(Filter(Core.WorldFilter.GetLandscape(), (WorldObject o) => r.IsMatch(o.Name ?? "")));
		}
		case "getitemcountininventorybyname":
		{
			Need(a, 1, f);
			string b = S(a, 0);
			long num5 = 0L;
			foreach (WorldObject item6 in Core.WorldFilter.GetInventory())
			{
				if (string.Equals(item6.Name, b, StringComparison.OrdinalIgnoreCase))
				{
					num5 += StackOf(item6);
				}
			}
			return (double)num5;
		}
		case "getitemcountininventorybynamerx":
		{
			Need(a, 1, f);
			Regex regex = new Regex(S(a, 0));
			long num4 = 0L;
			foreach (WorldObject item7 in Core.WorldFilter.GetInventory())
			{
				if (regex.IsMatch(item7.Name ?? ""))
				{
					num4 += StackOf(item7);
				}
			}
			return (double)num4;
		}
		case "getinventorycountbytemplatetype":
		{
			Need(a, 1, f);
			int num2 = I(a, 0);
			long num3 = 0L;
			foreach (WorldObject item8 in Core.WorldFilter.GetInventory())
			{
				if (item8.Type == num2)
				{
					num3 += StackOf(item8);
				}
			}
			return (double)num3;
		}
		case "getfreeitemslots":
			return (double)FreeSlots(containers: false);
		case "getfreecontainerslots":
			return (double)FreeSlots(containers: true);
		case "getcontaineritemcount":
		{
			Need(a, 1, f);
			int num = 0;
			foreach (WorldObject item9 in Core.WorldFilter.GetByContainer(W(a, 0).Id))
			{
				num++;
			}
			return (double)num;
		}
		case "spellname":
		{
			Need(a, 1, f);
			string text = null;
			try
			{
				text = SpellNames.Name(I(a, 0));
			}
			catch
			{
			}
			return text ?? "";
		}
		default:
			throw new Exception("Unknown expression method: " + f);
		}
	}

	private static IEnumerable<WorldObject> Filter(IEnumerable<WorldObject> src, Func<WorldObject, bool> ok)
	{
		foreach (WorldObject o in src)
		{
			if (o != null && ok(o))
			{
				yield return o;
			}
		}
	}

	private static object Iterate(ExprList list, string expr, int mode)
	{
		object session = Expr.GetSession("0");
		object session2 = Expr.GetSession("1");
		object session3 = Expr.GetSession("2");
		ExprList exprList = new ExprList();
		object obj = 0.0;
		int num = 0;
		try
		{
			foreach (object item in new List<object>(list.Items))
			{
				Expr.SetSession("0", (double)num++);
				Expr.SetSession("1", item);
				if (mode == 2)
				{
					Expr.SetSession("2", obj);
				}
				object obj2 = Expr.Run(expr);
				switch (mode)
				{
				case 0:
					if (Expr.IsTruthy(obj2))
					{
						exprList.Items.Add(item);
					}
					break;
				case 1:
					exprList.Items.Add(obj2);
					break;
				default:
					obj = obj2;
					break;
				}
			}
		}
		finally
		{
			Expr.SetSession("0", session);
			Expr.SetSession("1", session2);
			Expr.SetSession("2", session3);
		}
		return (mode == 2) ? obj : exprList;
	}

	private static double HeadingOf(WorldObject o)
	{
		try
		{
			Vector4Object vector4Object = o.Orientation();
			double num = Math.Atan2(2.0 * (vector4Object.W * vector4Object.Z + vector4Object.X * vector4Object.Y), 1.0 - 2.0 * (vector4Object.Y * vector4Object.Y + vector4Object.Z * vector4Object.Z)) * 180.0 / Math.PI;
			num = (360.0 - num) % 360.0;
			return (num < 0.0) ? (num + 360.0) : num;
		}
		catch
		{
			return 0.0;
		}
	}

	private static double DoorOpen(WorldObject door)
	{
		try
		{
			return door.Values(BoolValueKey.Open, false) ? 1.0 : 0.0;
		}
		catch
		{
			return 0.0;
		}
	}

	private static int FreeSlots(bool containers)
	{
		int num = 0;
		int me = Me;
		foreach (WorldObject item in Core.WorldFilter.GetByContainer(me))
		{
			if (item.Values(LongValueKey.EquippedSlots, 0) == 0)
			{
				bool flag = item.ObjectClass == ObjectClass.Container || item.ObjectClass == ObjectClass.Foci;
				if (containers ? flag : (!flag))
				{
					num++;
				}
			}
		}
		int num2 = (containers ? Core.WorldFilter[me].Values((LongValueKey)7, 7) : Core.WorldFilter[me].Values(LongValueKey.ItemSlots, 102));
		return Math.Max(0, num2 - num);
	}

	private static double EquipAnyWand()
	{
		WorldObject worldObject = null;
		WorldObject worldObject2 = null;
		foreach (WorldObject item in Core.WorldFilter.GetInventory())
		{
			if (item.ObjectClass == ObjectClass.WandStaffOrb)
			{
				if (item.Values(LongValueKey.EquippedSlots, 0) != 0)
				{
					worldObject = item;
				}
				else if (worldObject2 == null)
				{
					worldObject2 = item;
				}
			}
		}
		if (worldObject == null)
		{
			if (worldObject2 == null)
			{
				return 0.0;
			}
			if (Core.Actions.BusyState == 0)
			{
				Core.Actions.UseItem(worldObject2.Id, 0);
			}
			return 0.0;
		}
		if (Core.Actions.CombatMode != CombatState.Magic)
		{
			Core.Actions.SetCombatMode(CombatState.Magic);
			return 0.0;
		}
		return 1.0;
	}

	private static double CastById(int spell, int target)
	{
		if (!Core.CharacterFilter.IsSpellKnown(spell))
		{
			return 2.0;
		}
		if (EquipAnyWand() != 1.0)
		{
			return 0.0;
		}
		if (Core.Actions.BusyState != 0)
		{
			return 0.0;
		}
		Core.Actions.CastSpell(spell, target);
		return 1.0;
	}

	[DllImport("user32.dll")]
	private static extern bool PostMessage(nint h, int msg, nint w, nint l);

	private static double SetMotion(string motion, bool on)
	{
		int num;
		int num2;
		switch ((motion ?? "").Trim().ToLowerInvariant())
		{
		case "forward":
			num = 87;
			num2 = 17;
			break;
		case "backward":
			num = 88;
			num2 = 45;
			break;
		case "turnleft":
			num = 65;
			num2 = 30;
			break;
		case "turnright":
			num = 68;
			num2 = 32;
			break;
		case "strafeleft":
			num = 90;
			num2 = 44;
			break;
		case "straferight":
			num = 67;
			num2 = 46;
			break;
		case "walk":
			num = 16;
			num2 = 42;
			break;
		default:
			Util.WriteToChat("Invalid motion (" + motion + "). Valid values are: Forward, Backward, TurnLeft, TurnRight, StrafeLeft, StrafeRight, Walk");
			return 0.0;
		}
		nint hwnd;
		try
		{
			hwnd = Core.Decal.Hwnd;
		}
		catch
		{
			return 0.0;
		}
		int num3 = 1 | (num2 << 16);
		PostMessage(hwnd, on ? 256 : 257, num, on ? num3 : (num3 | -1073741824));
		return 1.0;
	}
}
