using System;
using System.Collections;
using System.Globalization;
using System.Reflection;

namespace MelkTank.Metas;

public static class UbExpr
{
	private static object _vt;

	private static MethodInfo _eval;

	private static MethodInfo _setvar;

	private static DateTime _triedAt = DateTime.MinValue;

	private static bool _warned;

	public static bool Own = true;

	public static bool PickLive = true;

	public static bool Ready => Own || Find();

	private static bool Find()
	{
		if (_vt != null && _eval != null)
		{
			return true;
		}
		if ((DateTime.Now - _triedAt).TotalSeconds < 10.0)
		{
			return false;
		}
		_triedAt = DateTime.Now;
		try
		{
			if (PickLive && FindLive())
			{
				return true;
			}
			Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
			foreach (Assembly assembly in assemblies)
			{
				if (!assembly.FullName.StartsWith("UtilityBelt,", StringComparison.Ordinal))
				{
					continue;
				}
				Type type = assembly.GetType("UtilityBelt.Tools.VTankControl");
				Type type2 = assembly.GetType("UtilityBelt.UtilityBeltPlugin");
				if (type == null)
				{
					continue;
				}
				object obj = null;
				Type[] array = SafeTypes(assembly);
				foreach (Type type3 in array)
				{
					if (obj != null)
					{
						break;
					}
					FieldInfo[] fields = type3.GetFields(BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
					foreach (FieldInfo fieldInfo in fields)
					{
						if (type.IsAssignableFrom(fieldInfo.FieldType))
						{
							obj = fieldInfo.GetValue(null);
							if (obj != null)
							{
								break;
							}
						}
					}
					if (obj != null)
					{
						break;
					}
					PropertyInfo[] properties = type3.GetProperties(BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
					foreach (PropertyInfo propertyInfo in properties)
					{
						if (type.IsAssignableFrom(propertyInfo.PropertyType) && propertyInfo.GetIndexParameters().Length == 0)
						{
							try
							{
								obj = propertyInfo.GetValue(null, null);
							}
							catch
							{
							}
							if (obj != null)
							{
								break;
							}
						}
					}
				}
				if (obj == null && type2 != null)
				{
					object obj3 = null;
					Type[] array2 = SafeTypes(assembly);
					foreach (Type type4 in array2)
					{
						FieldInfo[] fields2 = type4.GetFields(BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
						foreach (FieldInfo fieldInfo2 in fields2)
						{
							if (type2.IsAssignableFrom(fieldInfo2.FieldType))
							{
								obj3 = fieldInfo2.GetValue(null);
								if (obj3 != null)
								{
									break;
								}
							}
						}
						if (obj3 != null)
						{
							break;
						}
						PropertyInfo[] properties2 = type4.GetProperties(BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
						foreach (PropertyInfo propertyInfo2 in properties2)
						{
							if (type2.IsAssignableFrom(propertyInfo2.PropertyType) && propertyInfo2.GetIndexParameters().Length == 0)
							{
								try
								{
									obj3 = propertyInfo2.GetValue(null, null);
								}
								catch
								{
								}
								if (obj3 != null)
								{
									break;
								}
							}
						}
						if (obj3 != null)
						{
							break;
						}
					}
					if (obj3 != null)
					{
						FieldInfo[] fields3 = type2.GetFields(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
						foreach (FieldInfo fieldInfo3 in fields3)
						{
							if (!fieldInfo3.IsStatic && type.IsAssignableFrom(fieldInfo3.FieldType))
							{
								obj = fieldInfo3.GetValue(obj3);
								if (obj != null)
								{
									break;
								}
							}
						}
						if (obj == null)
						{
							PropertyInfo[] properties3 = type2.GetProperties(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
							foreach (PropertyInfo propertyInfo3 in properties3)
							{
								if (type.IsAssignableFrom(propertyInfo3.PropertyType) && propertyInfo3.GetIndexParameters().Length == 0)
								{
									try
									{
										obj = propertyInfo3.GetValue(obj3, null);
									}
									catch
									{
									}
									if (obj != null)
									{
										break;
									}
								}
							}
						}
					}
				}
				if (obj != null)
				{
					_eval = type.GetMethod("EvaluateExpression", BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic, null, new Type[2]
					{
						typeof(string),
						typeof(bool)
					}, null);
					_setvar = type.GetMethod("Setvar", BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic, null, new Type[2]
					{
						typeof(string),
						typeof(object)
					}, null);
					if (!(_eval == null))
					{
						_vt = obj;
						return true;
					}
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		if (!_warned)
		{
			_warned = true;
			Util.WriteToChat("Meta: UtilityBelt's expression engine wasn't found - expressions count as false until it is.");
		}
		return false;
	}

	private static bool FindLive()
	{
		object obj = null;
		Type type = null;
		int num = 0;
		Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
		foreach (Assembly assembly in assemblies)
		{
			try
			{
				if (!assembly.FullName.StartsWith("UtilityBelt,", StringComparison.Ordinal))
				{
					continue;
				}
				Type type2 = assembly.GetType("UtilityBelt.UtilityBeltPlugin");
				Type type3 = assembly.GetType("UtilityBelt.Tools.VTankControl");
				if (type2 == null || type3 == null)
				{
					continue;
				}
				FieldInfo field = type2.GetField("Instance", BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
				object obj2 = ((field != null) ? field.GetValue(null) : null);
				if (obj2 == null)
				{
					continue;
				}
				num++;
				FieldInfo field2 = type2.GetField("RegisteredExpressions", BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
				IDictionary dictionary = ((field2 != null) ? (field2.GetValue(obj2) as IDictionary) : null);
				if (dictionary != null && dictionary.Contains("getvar"))
				{
					FieldInfo field3 = type2.GetField("VTank", BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
					object obj3 = ((field3 != null) ? field3.GetValue(obj2) : null);
					if (obj3 != null)
					{
						obj = obj3;
						type = type3;
					}
				}
			}
			catch
			{
			}
		}
		if (obj == null)
		{
			return false;
		}
		MethodInfo method = type.GetMethod("EvaluateExpression", BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic, null, new Type[2]
		{
			typeof(string),
			typeof(bool)
		}, null);
		if (method == null)
		{
			return false;
		}
		_eval = method;
		_setvar = type.GetMethod("Setvar", BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic, null, new Type[2]
		{
			typeof(string),
			typeof(object)
		}, null);
		_vt = obj;
		if (num > 1)
		{
			Util.WriteToChat("Meta: UtilityBelt is loaded " + num + " times - using the one that's running.");
		}
		return true;
	}

	private static void Lost()
	{
		_vt = null;
		_eval = null;
		_setvar = null;
		_triedAt = DateTime.MinValue;
	}

	private static Type[] SafeTypes(Assembly a)
	{
		try
		{
			return a.GetTypes();
		}
		catch (ReflectionTypeLoadException ex)
		{
			return Array.FindAll(ex.Types, (Type t) => t != null);
		}
	}

	public static object Eval(string expr, out string error)
	{
		error = null;
		if (string.IsNullOrEmpty(expr))
		{
			return null;
		}
		if (Own)
		{
			return Expr.Eval(expr, out error);
		}
		if (!Find())
		{
			error = "UtilityBelt isn't ready";
			return null;
		}
		try
		{
			return _eval.Invoke(_vt, new object[2] { expr, true });
		}
		catch (TargetInvocationException ex)
		{
			error = ((ex.InnerException != null) ? ex.InnerException.Message : ex.Message);
			if (error.IndexOf("Unknown expression method", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				Lost();
			}
			return null;
		}
		catch (Exception ex2)
		{
			error = ex2.Message;
			return null;
		}
	}

	public static bool Truthy(object v)
	{
		if (v == null)
		{
			return false;
		}
		if (!(v is bool result))
		{
			if (v is double)
			{
				return (double)v != 0.0;
			}
			if (v is int)
			{
				return (int)v != 0;
			}
			if (v is float)
			{
				return (float)v != 0f;
			}
			string text = v.ToString();
			if (text.Length == 0 || text == "0" || text.Equals("false", StringComparison.OrdinalIgnoreCase))
			{
				return false;
			}
			if (double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out var result2))
			{
				return result2 != 0.0;
			}
			return true;
		}
		return result;
	}

	public static string Text(object v)
	{
		if (v == null)
		{
			return "";
		}
		if (v is double num)
		{
			return num.ToString("0.################", CultureInfo.InvariantCulture);
		}
		if (v is bool)
		{
			return ((bool)v) ? "1" : "0";
		}
		return v.ToString();
	}

	public static void SetVar(string name, object value)
	{
		if (Own)
		{
			Expr.SetSession(name, value);
		}
		else if (Find() && !(_setvar == null))
		{
			try
			{
				_setvar.Invoke(_vt, new object[2] { name, value });
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
		}
	}
}
