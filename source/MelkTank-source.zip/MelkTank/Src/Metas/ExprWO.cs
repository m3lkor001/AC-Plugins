using System;
using Decal.Adapter;
using Decal.Adapter.Wrappers;

namespace MelkTank.Metas;

public class ExprWO
{
	public int Id;

	public WorldObject Wo
	{
		get
		{
			try
			{
				if (!CoreManager.Current.Actions.IsValidObject(Id))
				{
					return null;
				}
				return CoreManager.Current.WorldFilter[Id];
			}
			catch
			{
				return null;
			}
		}
	}

	public WorldObject W
	{
		get
		{
			WorldObject wo = Wo;
			if (wo == null)
			{
				throw new NullReferenceException();
			}
			return wo;
		}
	}

	public ExprWO(int id)
	{
		Id = id;
	}

	public override string ToString()
	{
		WorldObject wo = Wo;
		return (wo != null) ? ("0x" + Id.ToString("X8") + ": " + wo.Name) : ("0x" + Id.ToString("X8") + " (Invalid)");
	}

	public override bool Equals(object obj)
	{
		return obj is ExprWO exprWO && exprWO.Id == Id;
	}

	public override int GetHashCode()
	{
		return 2108858624 + Id.GetHashCode();
	}
}
