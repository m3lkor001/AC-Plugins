using System.Collections.Generic;

namespace MelkTank.Metas;

public class MAct
{
	public int Type;

	public MVal Data = MVal.Int(0);

	public List<MAct> Kids;

	public MAct Clone()
	{
		MAct mAct = new MAct
		{
			Type = Type,
			Data = ((Data == null) ? null : Data.Clone())
		};
		if (Kids != null)
		{
			mAct.Kids = new List<MAct>();
			foreach (MAct kid in Kids)
			{
				mAct.Kids.Add(kid.Clone());
			}
		}
		return mAct;
	}
}
