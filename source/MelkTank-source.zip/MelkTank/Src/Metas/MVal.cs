using System.Collections.Generic;
using System.Globalization;

namespace MelkTank.Metas;

public class MVal
{
	public string T = "i";

	public string S = "0";

	public byte[] B;

	public MTable Tb;

	public int AsInt
	{
		get
		{
			int result;
			return int.TryParse(S, NumberStyles.Integer, CultureInfo.InvariantCulture, out result) ? result : 0;
		}
	}

	public double AsDbl
	{
		get
		{
			double result;
			return double.TryParse(S, NumberStyles.Float, CultureInfo.InvariantCulture, out result) ? result : 0.0;
		}
	}

	public bool IsDict => T == "TABLE" && Tb != null && Tb.Cols.Count == 2 && Tb.Cols[0] == "k";

	public bool IsList => T == "TABLE" && Tb != null && Tb.Cols.Count == 2 && Tb.Cols[0] == "K";

	public static MVal Int(int v)
	{
		return new MVal
		{
			T = "i",
			S = v.ToString(CultureInfo.InvariantCulture)
		};
	}

	public static MVal Str(string v)
	{
		return new MVal
		{
			T = "s",
			S = (v ?? "")
		};
	}

	public static MVal Dbl(double v)
	{
		return new MVal
		{
			T = "d",
			S = v.ToString("R", CultureInfo.InvariantCulture)
		};
	}

	public static MVal Bytes(byte[] b)
	{
		MVal mVal = new MVal();
		mVal.T = "ba";
		mVal.B = b ?? new byte[0];
		return mVal;
	}

	public static MVal Dict(params object[] kv)
	{
		MVal mVal = new MVal();
		mVal.T = "TABLE";
		mVal.Tb = MTable.Make("k", "v");
		MVal mVal2 = mVal;
		for (int i = 0; i + 1 < kv.Length; i += 2)
		{
			mVal2.Tb.Rows.Add(new List<MVal>
			{
				Str((string)kv[i]),
				(MVal)kv[i + 1]
			});
		}
		return mVal2;
	}

	public MVal Get(string key)
	{
		if (!IsDict)
		{
			return null;
		}
		foreach (List<MVal> row in Tb.Rows)
		{
			if (row[0].S == key)
			{
				return row[1];
			}
		}
		return null;
	}

	public string GetS(string key)
	{
		MVal mVal = Get(key);
		string result;
		if (mVal == null)
		{
			result = "";
		}
		else
		{
			result = ((mVal.T == "ba") ? Meta.Enc.GetString(mVal.B ?? new byte[0]) : mVal.S);
		}
		return result;
	}

	public void Set(string key, MVal val)
	{
		if (!IsDict)
		{
			return;
		}
		foreach (List<MVal> row in Tb.Rows)
		{
			if (row[0].S == key)
			{
				row[1] = val;
				return;
			}
		}
		Tb.Rows.Add(new List<MVal>
		{
			Str(key),
			val
		});
	}

	public MVal Clone()
	{
		MVal mVal = new MVal
		{
			T = T,
			S = S,
			B = ((B == null) ? null : ((byte[])B.Clone()))
		};
		if (Tb != null)
		{
			mVal.Tb = new MTable
			{
				Cols = new List<string>(Tb.Cols),
				Flags = new List<string>(Tb.Flags)
			};
			foreach (List<MVal> row in Tb.Rows)
			{
				List<MVal> list = new List<MVal>();
				foreach (MVal item in row)
				{
					list.Add(item.Clone());
				}
				mVal.Tb.Rows.Add(list);
			}
		}
		return mVal;
	}
}
