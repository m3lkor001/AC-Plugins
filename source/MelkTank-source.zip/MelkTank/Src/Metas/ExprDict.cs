using System.Collections.Generic;

namespace MelkTank.Metas;

public class ExprDict
{
	public List<string> Keys = new List<string>();

	public Dictionary<string, object> Items = new Dictionary<string, object>();

	public void Set(string k, object v)
	{
		if (!Items.ContainsKey(k))
		{
			Keys.Add(k);
		}
		Items[k] = v;
	}

	public bool Remove(string k)
	{
		Keys.Remove(k);
		return Items.Remove(k);
	}

	public override string ToString()
	{
		List<string> list = new List<string>();
		foreach (string key in Keys)
		{
			list.Add(key + "=>" + Expr.Str(Items[key]));
		}
		return "[" + string.Join(",", list.ToArray()) + "]";
	}
}
