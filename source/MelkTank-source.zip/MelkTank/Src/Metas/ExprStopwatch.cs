using System.Diagnostics;

namespace MelkTank.Metas;

public class ExprStopwatch
{
	public Stopwatch Watch = new Stopwatch();

	public double Elapsed()
	{
		return (double)Watch.ElapsedMilliseconds / 1000.0;
	}

	public override string ToString()
	{
		return "Running:" + (Watch.IsRunning ? "True" : "False") + " Elapsed:(" + Expr.Str(Elapsed()) + ")";
	}
}
