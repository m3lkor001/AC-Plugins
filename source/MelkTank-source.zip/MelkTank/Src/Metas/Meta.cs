using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

namespace MelkTank.Metas;

public class Meta
{
	private class Reader
	{
		private readonly byte[] _b;

		private int _p;

		public bool End => _p >= _b.Length;

		public Reader(byte[] b)
		{
			_b = b;
		}

		public string Line()
		{
			int i;
			for (i = _p; i < _b.Length && _b[i] != 10; i++)
			{
			}
			int num = i;
			if (num > _p && _b[num - 1] == 13)
			{
				num--;
			}
			string result = Enc.GetString(_b, _p, num - _p);
			_p = Math.Min(_b.Length, i + 1);
			return result;
		}

		public byte[] Raw(int n)
		{
			n = Math.Max(0, Math.Min(n, _b.Length - _p));
			byte[] array = new byte[n];
			Array.Copy(_b, _p, array, 0, n);
			_p += n;
			return array;
		}
	}

	public string Name = "";

	public string File = "";

	public List<MRule> Rules = new List<MRule>();

	public bool Dirty;

	public const int CAll = 2;

	public const int CAny = 3;

	public const int CNot = 21;

	public const int AAll = 3;

	public static readonly Encoding Enc = Encoding.GetEncoding(28591);

	public List<string> States()
	{
		List<string> list = new List<string>();
		foreach (MRule rule in Rules)
		{
			if (!list.Contains(rule.State))
			{
				list.Add(rule.State);
			}
		}
		int num = list.IndexOf("Default");
		if (num > 0)
		{
			list.RemoveAt(num);
			list.Insert(0, "Default");
		}
		if (list.Count == 0)
		{
			list.Add("Default");
		}
		return list;
	}

	private static MVal ReadVal(Reader r)
	{
		string text = r.Line();
		switch (text)
		{
		case "i":
		case "s":
		case "d":
		case "b":
			return new MVal
			{
				T = text,
				S = r.Line()
			};
		case "ba":
		{
			int.TryParse(r.Line(), out var result);
			return new MVal
			{
				T = "ba",
				B = r.Raw(result)
			};
		}
		case "TABLE":
			return new MVal
			{
				T = "TABLE",
				Tb = ReadTable(r)
			};
		default:
			throw new FormatException("unknown value type '" + text + "'");
		}
	}

	private static MTable ReadTable(Reader r)
	{
		MTable mTable = new MTable();
		int num = int.Parse(r.Line(), CultureInfo.InvariantCulture);
		for (int i = 0; i < num; i++)
		{
			mTable.Cols.Add(r.Line());
		}
		for (int j = 0; j < num; j++)
		{
			mTable.Flags.Add(r.Line());
		}
		int num2 = int.Parse(r.Line(), CultureInfo.InvariantCulture);
		for (int k = 0; k < num2; k++)
		{
			List<MVal> list = new List<MVal>();
			for (int l = 0; l < num; l++)
			{
				list.Add(ReadVal(r));
			}
			mTable.Rows.Add(list);
		}
		return mTable;
	}

	private static MCond ToCond(int type, MVal data)
	{
		MCond mCond = new MCond
		{
			Type = type,
			Data = data
		};
		if ((type == 2 || type == 3 || type == 21) && data.IsList)
		{
			mCond.Kids = new List<MCond>();
			foreach (List<MVal> row in data.Tb.Rows)
			{
				mCond.Kids.Add(ToCond(row[0].AsInt, row[1]));
			}
			mCond.Data = null;
		}
		return mCond;
	}

	private static MAct ToAct(int type, MVal data)
	{
		MAct mAct = new MAct
		{
			Type = type,
			Data = data
		};
		if (type == 3 && data.IsList)
		{
			mAct.Kids = new List<MAct>();
			foreach (List<MVal> row in data.Tb.Rows)
			{
				mAct.Kids.Add(ToAct(row[0].AsInt, row[1]));
			}
			mAct.Data = null;
		}
		return mAct;
	}

	public static Meta Load(string path)
	{
		Reader reader = new Reader(System.IO.File.ReadAllBytes(path));
		string text = reader.Line();
		string text2 = reader.Line();
		if (text2 != "CondAct")
		{
			throw new FormatException("not a VTank meta (no CondAct table)");
		}
		MTable mTable = ReadTable(reader);
		Meta meta = new Meta
		{
			Name = Path.GetFileNameWithoutExtension(path),
			File = path
		};
		foreach (List<MVal> row in mTable.Rows)
		{
			if (row.Count >= 5)
			{
				meta.Rules.Add(new MRule
				{
					C = ToCond(row[0].AsInt, row[2]),
					A = ToAct(row[1].AsInt, row[3]),
					State = row[4].S
				});
			}
		}
		return meta;
	}

	private static MVal FromCond(MCond c)
	{
		if (c.Kids == null)
		{
			return c.Data ?? MVal.Int(0);
		}
		MVal mVal = new MVal();
		mVal.T = "TABLE";
		mVal.Tb = MTable.Make("K", "V");
		MVal mVal2 = mVal;
		foreach (MCond kid in c.Kids)
		{
			mVal2.Tb.Rows.Add(new List<MVal>
			{
				MVal.Int(kid.Type),
				FromCond(kid)
			});
		}
		return mVal2;
	}

	private static MVal FromAct(MAct a)
	{
		if (a.Kids == null)
		{
			return a.Data ?? MVal.Int(0);
		}
		MVal mVal = new MVal();
		mVal.T = "TABLE";
		mVal.Tb = MTable.Make("K", "V");
		MVal mVal2 = mVal;
		foreach (MAct kid in a.Kids)
		{
			mVal2.Tb.Rows.Add(new List<MVal>
			{
				MVal.Int(kid.Type),
				FromAct(kid)
			});
		}
		return mVal2;
	}

	private static void WriteLine(Stream o, string s)
	{
		byte[] bytes = Enc.GetBytes(s + "\r\n");
		o.Write(bytes, 0, bytes.Length);
	}

	private static void WriteVal(Stream o, MVal v)
	{
		WriteLine(o, v.T);
		string t = v.T;
		string text = t;
		if (!(text == "ba"))
		{
			if (text == "TABLE")
			{
				WriteTable(o, v.Tb);
			}
			else
			{
				WriteLine(o, v.S ?? "");
			}
			return;
		}
		WriteLine(o, (v.B ?? new byte[0]).Length.ToString(CultureInfo.InvariantCulture));
		if (v.B != null)
		{
			o.Write(v.B, 0, v.B.Length);
		}
	}

	private static void WriteTable(Stream o, MTable t)
	{
		WriteLine(o, t.Cols.Count.ToString(CultureInfo.InvariantCulture));
		foreach (string col in t.Cols)
		{
			WriteLine(o, col);
		}
		foreach (string flag in t.Flags)
		{
			WriteLine(o, flag);
		}
		WriteLine(o, t.Rows.Count.ToString(CultureInfo.InvariantCulture));
		foreach (List<MVal> row in t.Rows)
		{
			foreach (MVal item in row)
			{
				WriteVal(o, item);
			}
		}
	}

	public byte[] ToBytes()
	{
		MTable mTable = MTable.Make("CType", "AType", "CData", "AData", "State");
		foreach (MRule rule in Rules)
		{
			mTable.Rows.Add(new List<MVal>
			{
				MVal.Int(rule.C.Type),
				MVal.Int(rule.A.Type),
				FromCond(rule.C),
				FromAct(rule.A),
				MVal.Str(rule.State)
			});
		}
		using MemoryStream memoryStream = new MemoryStream();
		WriteLine(memoryStream, "1");
		WriteLine(memoryStream, "CondAct");
		WriteTable(memoryStream, mTable);
		return memoryStream.ToArray();
	}

	public void Save(string path)
	{
		System.IO.File.WriteAllBytes(path, ToBytes());
		File = path;
		Name = Path.GetFileNameWithoutExtension(path);
		Dirty = false;
	}

	public List<string> NotForVtank()
	{
		List<string> l = new List<string>();
		Action<MCond> c = null;
		Action<MAct> a = null;
		c = (MCond x) =>
		{
			if (x.Type >= 100)
			{
				l.Add(MetaText.CondName(x.Type));
			}
			if (x.Kids != null)
			{
				foreach (MCond kid in x.Kids)
				{
					c(kid);
				}
			}
		};
		a = (MAct x) =>
		{
			if (x.Type >= 104)
			{
				l.Add(MetaText.ActName(x.Type));
			}
			if (x.Kids != null)
			{
				foreach (MAct kid2 in x.Kids)
				{
					a(kid2);
				}
			}
		};
		foreach (MRule rule in Rules)
		{
			c(rule.C);
			a(rule.A);
		}
		return l;
	}
}
