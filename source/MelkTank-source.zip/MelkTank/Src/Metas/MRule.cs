namespace MelkTank.Metas;

public class MRule
{
	public MCond C = new MCond
	{
		Type = 1
	};

	public MAct A = new MAct
	{
		Type = 2,
		Data = MVal.Str("")
	};

	public string State = "Default";
}
