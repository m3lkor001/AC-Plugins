using System.Collections.Generic;

namespace MelkTank.Metas;

public class ExprList
{
	public List<object> Items = new List<object>();

	public override string ToString()
	{
		List<string> list = new List<string>();
		foreach (object item in Items)
		{
			list.Add(Expr.Str(item));
		}
		return "[" + string.Join(",", list.ToArray()) + "]";
	}
}
