using System;
using System.Globalization;

namespace MelkTank.Metas;

public class ExprCoords
{
	public double NS;

	public double EW;

	public double Z;

	public ExprCoords(double ew, double ns, double z)
	{
		EW = ew;
		NS = ns;
		Z = z;
	}

	public double DistanceTo(ExprCoords o, bool withZ)
	{
		double num = (NS * 10.0 + 1019.5) * 24.0 - (o.NS * 10.0 + 1019.5) * 24.0;
		double num2 = (EW * 10.0 + 1019.5) * 24.0 - (o.EW * 10.0 + 1019.5) * 24.0;
		return Math.Sqrt(num * num + num2 * num2 + (withZ ? ((Z - o.Z) * (Z - o.Z)) : 0.0));
	}

	public override string ToString()
	{
		CultureInfo invariantCulture = CultureInfo.InvariantCulture;
		return Math.Abs(NS).ToString("F2", invariantCulture) + ((NS >= 0.0) ? "N" : "S") + ", " + Math.Abs(EW).ToString("F2", invariantCulture) + ((EW >= 0.0) ? "E" : "W") + ", " + (Z / 240.0).ToString("F2", invariantCulture) + "Z";
	}
}
