using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Text.RegularExpressions;
using Decal.Adapter;

namespace MelkTank.Metas;

public static class ExprQuests
{
	private class Flag
	{
		public int Solves;

		public int MaxSolves;

		public DateTime CompletedOn = DateTime.MinValue;

		public TimeSpan Repeat;
	}

	private static readonly Regex Line = new Regex("(?<key>\\S+) \\- (?<solves>\\d+) solves \\((?<completedOn>\\d{0,11})\\)\"?((?<description>.*)\" (?<maxSolves>.*) (?<repeatTime>\\d{0,11}))?.*$");

	private static readonly Dictionary<string, Flag> _flags = new Dictionary<string, Flag>(StringComparer.OrdinalIgnoreCase);

	private static string _char;

	private static bool _asked;

	private static bool _quiet;

	private static DateTime _askAt = DateTime.MinValue;

	private static DateTime _lastLine = DateTime.MinValue;

	private static DateTime _quietUntil = DateTime.MinValue;

	private const string CarryKey = "MelkTank.ExprQuests";

	private static bool _dirty;

	public static bool Refreshing => _quiet && DateTime.Now < _quietUntil;

	public static bool Has(string k)
	{
		Check();
		return _flags.ContainsKey(k.ToLowerInvariant());
	}

	public static int Solves(string k)
	{
		Check();
		Flag value;
		return _flags.TryGetValue(k.ToLowerInvariant(), out value) ? value.Solves : 0;
	}

	public static int MaxSolves(string k)
	{
		Check();
		Flag value;
		return _flags.TryGetValue(k.ToLowerInvariant(), out value) ? value.MaxSolves : 0;
	}

	public static bool Ready(string k)
	{
		Check();
		if (!_flags.TryGetValue(k.ToLowerInvariant(), out var value))
		{
			return true;
		}
		return value.CompletedOn + value.Repeat <= DateTime.UtcNow;
	}

	private static void Check()
	{
		string text = "";
		try
		{
			text = CoreManager.Current.CharacterFilter.Name ?? "";
		}
		catch
		{
		}
		if (text == _char)
		{
			return;
		}
		_char = text;
		_flags.Clear();
		_asked = false;
		_askAt = DateTime.Now.AddSeconds(8.0);
		try
		{
			object data = AppDomain.CurrentDomain.GetData("MelkTank.ExprQuests");
			Dictionary<string, long[]> dictionary = data as Dictionary<string, long[]>;
			object data2 = AppDomain.CurrentDomain.GetData("MelkTank.ExprQuests.char");
			if (dictionary == null || !(data2 is string) || !((string)data2 == text) || text.Length <= 0)
			{
				return;
			}
			foreach (KeyValuePair<string, long[]> item in dictionary)
			{
				_flags[item.Key] = new Flag
				{
					Solves = (int)item.Value[0],
					MaxSolves = (int)item.Value[1],
					CompletedOn = new DateTime(item.Value[2], DateTimeKind.Utc),
					Repeat = new TimeSpan(item.Value[3])
				};
			}
			_asked = true;
		}
		catch
		{
		}
	}

	private static void Carry()
	{
		if (!_dirty || (DateTime.Now - _lastLine).TotalSeconds < 3.0)
		{
			return;
		}
		_dirty = false;
		try
		{
			Dictionary<string, long[]> dictionary = new Dictionary<string, long[]>(StringComparer.OrdinalIgnoreCase);
			foreach (KeyValuePair<string, Flag> flag in _flags)
			{
				dictionary[flag.Key] = new long[4]
				{
					flag.Value.Solves,
					flag.Value.MaxSolves,
					flag.Value.CompletedOn.Ticks,
					flag.Value.Repeat.Ticks
				};
			}
			AppDomain.CurrentDomain.SetData("MelkTank.ExprQuests", dictionary);
			AppDomain.CurrentDomain.SetData("MelkTank.ExprQuests.char", _char ?? "");
		}
		catch
		{
		}
	}

	/// <summary>/myquests asked now, its answer kept out of chat (/ub myquests).</summary>
	public static void RefreshQuiet()
	{
		_quiet = true;
		_quietUntil = DateTime.Now.AddSeconds(20.0);
		Util.Command("/myquests");
	}

	public static void Tick()
	{
		Check();
		Carry();
		if (_asked || string.IsNullOrEmpty(_char) || DateTime.Now < _askAt)
		{
			return;
		}
		try
		{
			if (CoreManager.Current.CharacterFilter.LoginStatus != 3)
			{
				return;
			}
		}
		catch
		{
			return;
		}
		_asked = true;
		Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
		foreach (Assembly assembly in assemblies)
		{
			// (UtilityBelt asks for itself. MelksQB doesn't ask at login: this answer - hidden from chat - is read by it too)
			if (assembly.FullName.StartsWith("UtilityBelt,", StringComparison.Ordinal))
			{
				return;
			}
		}
		_quiet = true;
		_quietUntil = DateTime.Now.AddSeconds(20.0);
		Util.Command("/myquests");
	}

	public static bool OnChat(string text)
	{
		if (string.IsNullOrEmpty(text))
		{
			return false;
		}
		if (_quiet && DateTime.Now < _quietUntil && (text.Contains("This command may only be run once every") || text.StartsWith("Quest list is empty")))
		{
			_quiet = false;
			return true;
		}
		if (text.IndexOf(" solves (", StringComparison.Ordinal) < 0)
		{
			return false;
		}
		Match match = Line.Match(text.Trim());
		if (!match.Success)
		{
			return false;
		}
		Check();
		Flag flag = new Flag();
		int.TryParse(match.Groups["solves"].Value, out flag.Solves);
		int.TryParse(match.Groups["maxSolves"].Value, out flag.MaxSolves);
		if (double.TryParse(match.Groups["completedOn"].Value, NumberStyles.Float, CultureInfo.InvariantCulture, out var result))
		{
			flag.CompletedOn = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddSeconds(result);
			if (double.TryParse(match.Groups["repeatTime"].Value, NumberStyles.Float, CultureInfo.InvariantCulture, out var result2))
			{
				flag.Repeat = TimeSpan.FromSeconds(result2);
			}
		}
		_flags[match.Groups["key"].Value.ToLowerInvariant()] = flag;
		_lastLine = DateTime.Now;
		_dirty = true;
		if (_quiet && DateTime.Now < _quietUntil)
		{
			_quietUntil = DateTime.Now.AddSeconds(5.0);
			return true;
		}
		_quiet = false;
		return false;
	}
}
