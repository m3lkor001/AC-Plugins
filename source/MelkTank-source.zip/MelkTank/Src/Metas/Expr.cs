using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using Decal.Adapter;

namespace MelkTank.Metas;

public static class Expr
{
	private enum T
	{
		End,
		Punct,
		Bool,
		Number,
		Hex,
		Str,
		Minus
	}

	private struct Tok
	{
		public T Kind;

		public string Text;

		public int Pos;
	}

	internal abstract class Node
	{
		public abstract object Eval();
	}

	private class Lit : Node
	{
		public object V;

		public override object Eval()
		{
			return V;
		}
	}

	private class Call : Node
	{
		public string Name;

		public List<Node> Args = new List<Node>();

		public override object Eval()
		{
			object[] array = new object[Args.Count];
			for (int i = 0; i < array.Length; i++)
			{
				array[i] = Ev(Args[i]);
			}
			return ExprFuncs.Run(Name, array);
		}
	}

	private class GetVar : Node
	{
		public string Kind;

		public Node Name;

		public override object Eval()
		{
			string n = Str(Ev(Name));
			object result;
			if (Kind == "$")
			{
				result = GetSession(n);
			}
			else
			{
				result = ((Kind == "@") ? GetP(n) : GetG(n));
			}
			return result;
		}
	}

	private class SetVar : Node
	{
		public string Kind;

		public Node Name;

		public Node Value;

		public override object Eval()
		{
			string n = Str(Ev(Name));
			object v = Ev(Value);
			if (Kind == "$")
			{
				return SetSession(n, v);
			}
			if (Kind == "@")
			{
				return SetP(n, v);
			}
			return SetG(n, v);
		}
	}

	private class Index : Node
	{
		public Node Target;

		public Node I1;

		public Node I2;

		public bool Range;

		public override object Eval()
		{
			object obj = Ev(Target);
			if (obj is ExprList exprList)
			{
				int num = Idx(I1, exprList.Items.Count, 0);
				if (!Range)
				{
					return exprList.Items[num];
				}
				int num2 = Idx(I2, exprList.Items.Count, exprList.Items.Count);
				ExprList exprList2 = new ExprList();
				for (int i = num; i < num2 && i < exprList.Items.Count; i++)
				{
					exprList2.Items.Add(exprList.Items[i]);
				}
				return exprList2;
			}
			if (obj is string text)
			{
				int num3 = Idx(I1, text.Length, 0);
				if (!Range)
				{
					return text.Substring(num3, 1);
				}
				int num4 = Idx(I2, text.Length, text.Length);
				return text.Substring(num3, Math.Max(0, num4 - num3));
			}
			if (obj is ExprDict exprDict)
			{
				if (Range)
				{
					throw new Exception("Range indices not supported with dictionaries");
				}
				if (!(Ev(I1) is string key))
				{
					throw new Exception("Dictionary key must be a string");
				}
				object value;
				return exprDict.Items.TryGetValue(key, out value) ? value : null;
			}
			throw new Exception(TypeName(obj) + " does not support indice access");
		}

		private static int Idx(Node n, int len, int def)
		{
			int num = def;
			if (n != null)
			{
				object obj = Ev(n);
				if (!(obj is double))
				{
					throw new Exception("Indice was type " + TypeName(obj) + " (" + Str(obj) + "). Indices need to be numbers.");
				}
				num = (int)(double)obj;
			}
			if (num < 0)
			{
				num = len + num;
				if (num < 0)
				{
					throw new Exception("Indice was " + num + ". Cannot be less than zero.");
				}
			}
			if (num > len)
			{
				throw new Exception("Indice was " + num + ". Cannot be greater than length (" + len + ").");
			}
			return num;
		}
	}

	private class Unary : Node
	{
		public Node A;

		public override object Eval()
		{
			return (double)(~Convert.ToInt32(Num(Ev(A), "~")));
		}
	}

	private class Bin : Node
	{
		public string Op;

		public Node A;

		public Node B;

		public override object Eval()
		{
			string op = Op;
			string text = op;
			if (!(text == "&&"))
			{
				if (text == "||")
				{
					object obj = Ev(A);
					return IsTruthy(obj) ? obj : Ev(B);
				}
				object obj2 = Ev(A);
				object obj3 = Ev(B);
				switch (Op)
				{
				case "==":
					if (obj2 is string)
					{
						return string.Equals(Str(obj2), Str(obj3), StringComparison.OrdinalIgnoreCase) ? 1.0 : 0.0;
					}
					return obj2.Equals(obj3) ? 1.0 : 0.0;
				case "!=":
					if (obj2 is string)
					{
						return string.Equals(Str(obj2), Str(obj3), StringComparison.OrdinalIgnoreCase) ? 0.0 : 1.0;
					}
					return obj2.Equals(obj3) ? 0.0 : 1.0;
				case "<":
				case ">":
				case "<=":
				case ">=":
				{
					if (!(obj2 is double) || !(obj3 is double))
					{
						throw new Exception("Invalid comparison of non number types");
					}
					double num = (double)obj2;
					double num2 = (double)obj3;
					bool flag;
					if (Op == "<")
					{
						flag = num < num2;
					}
					else if (Op == ">")
					{
						flag = num > num2;
					}
					else
					{
						flag = ((Op == "<=") ? (num <= num2) : (num >= num2));
					}
					return flag ? 1.0 : 0.0;
				}
				case "+":
					if (obj2 is double && obj3 is double)
					{
						return (double)obj2 + (double)obj3;
					}
					if (obj2 is string)
					{
						return (string)obj2 + Str(obj3);
					}
					throw new Exception("Unable to add type " + TypeName(obj3) + " to type " + TypeName(obj2));
				case "-":
					if (obj2 is double && obj3 is double)
					{
						return (double)obj2 - (double)obj3;
					}
					throw new Exception("Unable to subtract type " + TypeName(obj3) + " from type " + TypeName(obj2));
				case "*":
					return Num(obj2, Op) * Num(obj3, Op);
				case "/":
					return Num(obj2, Op) / Num(obj3, Op);
				case "%":
					return Num(obj2, Op) % Num(obj3, Op);
				case ">>":
					return (double)(Convert.ToInt32(Num(obj2, Op)) >> Convert.ToInt32(Num(obj3, Op)));
				case "<<":
					return (double)(Convert.ToInt32(Num(obj2, Op)) << Convert.ToInt32(Num(obj3, Op)));
				case "&":
					return (double)(Convert.ToInt32(Num(obj2, Op)) & Convert.ToInt32(Num(obj3, Op)));
				case "|":
					return (double)(Convert.ToInt32(Num(obj2, Op)) | Convert.ToInt32(Num(obj3, Op)));
				case "^":
					return (double)(Convert.ToInt32(Num(obj2, Op)) ^ Convert.ToInt32(Num(obj3, Op)));
				case "#":
				{
					Regex regex = new Regex(Str(obj3), RegexOptions.IgnoreCase);
					Match match = regex.Match(Str(obj2));
					if (match.Success)
					{
						string[] groupNames = regex.GetGroupNames();
						foreach (string text2 in groupNames)
						{
							if (match.Groups[text2].Success)
							{
								SetSession("capturegroup_" + text2, match.Groups[text2].Value);
							}
							else
							{
								ClearSession("capturegroup_" + text2);
							}
						}
					}
					return match.Success ? 1.0 : 0.0;
				}
				default:
					throw new Exception("Unknown operator " + Op);
				}
			}
			object o = Ev(A);
			if (!IsTruthy(o))
			{
				return 0.0;
			}
			object obj4 = Ev(B);
			return IsTruthy(obj4) ? obj4 : ((object)0.0);
		}
	}

	private class Parser
	{
		private readonly List<Tok> _t;

		private int _p;

		private readonly string _src;

		private Tok Peek => _t[_p];

		public Parser(string src)
		{
			_src = src;
			_t = Lex(src);
		}

		private bool IsP(string s)
		{
			return Peek.Kind == T.Punct && Peek.Text == s;
		}

		private Tok Next()
		{
			return _t[_p++];
		}

		private void Want(string s)
		{
			if (!IsP(s))
			{
				throw new Exception("Expected '" + s + "' at " + Peek.Pos + ((Peek.Kind == T.End) ? " (end)" : (" near '" + Peek.Text + "'")) + " in: " + _src);
			}
			_p++;
		}

		public List<Node> ParseAll()
		{
			List<Node> list = new List<Node>();
			if (Peek.Kind == T.End)
			{
				return list;
			}
			list.Add(Expr(0));
			while (IsP(";"))
			{
				_p++;
				if (Peek.Kind == T.End)
				{
					break;
				}
				list.Add(Expr(0));
			}
			if (Peek.Kind != T.End)
			{
				throw new Exception("Unexpected '" + Peek.Text + "' at " + Peek.Pos + " in: " + _src);
			}
			return list;
		}

		private static int Prec(Tok t)
		{
			if (t.Kind == T.Minus)
			{
				return 9;
			}
			if (t.Kind != T.Punct)
			{
				return -1;
			}
			switch (t.Text)
			{
			case ">>":
			case "<<":
				return 13;
			case "&":
			case "^":
			case "|":
				return 12;
			case "*":
			case "/":
			case "%":
				return 10;
			case "+":
				return 9;
			case "#":
				return 8;
			case ">":
			case "<":
			case ">=":
			case "<=":
			case "==":
			case "!=":
				return 6;
			case "&&":
			case "||":
				return 5;
			default:
				return -1;
			}
		}

		public Node Expr(int min)
		{
			Node node = Postfix(Primary());
			while (true)
			{
				Tok peek = Peek;
				int num = Prec(peek);
				if (num < 0 || num < min)
				{
					break;
				}
				_p++;
				Node b = Expr(num + 1);
				node = new Bin
				{
					Op = ((peek.Kind == T.Minus) ? "-" : peek.Text),
					A = node,
					B = b
				};
			}
			return node;
		}

		private Node Postfix(Node n)
		{
			while (IsP("{"))
			{
				_p++;
				Index index = new Index
				{
					Target = n
				};
				if (IsP(":"))
				{
					_p++;
					index.Range = true;
					if (!IsP("}"))
					{
						index.I2 = Expr(0);
					}
				}
				else
				{
					index.I1 = Expr(0);
					if (IsP(":"))
					{
						_p++;
						index.Range = true;
						if (!IsP("}"))
						{
							index.I2 = Expr(0);
						}
					}
				}
				Want("}");
				n = index;
			}
			return n;
		}

		private Node Primary()
		{
			Tok peek = Peek;
			if (peek.Kind == T.Punct)
			{
				if (peek.Text == "(")
				{
					_p++;
					Node result = Expr(0);
					Want(")");
					return result;
				}
				if (peek.Text == "$" || peek.Text == "@" || peek.Text == "&")
				{
					_p++;
					Node name = Postfix(Primary());
					if (IsP("="))
					{
						_p++;
						return new SetVar
						{
							Kind = peek.Text,
							Name = name,
							Value = Expr(7)
						};
					}
					return new GetVar
					{
						Kind = peek.Text,
						Name = name
					};
				}
				if (peek.Text == "~")
				{
					_p++;
					return new Unary
					{
						A = Expr(14)
					};
				}
				throw new Exception("Unexpected character: " + peek.Text + " @ " + peek.Pos);
			}
			if (peek.Kind == T.Minus)
			{
				_p++;
				if (Peek.Kind == T.Number)
				{
					Tok tok = Next();
					return new Lit
					{
						V = 0.0 - double.Parse(tok.Text, CultureInfo.InvariantCulture)
					};
				}
				throw new Exception("Unexpected character: - @ " + peek.Pos);
			}
			if (peek.Kind == T.Number)
			{
				_p++;
				return new Lit
				{
					V = double.Parse(peek.Text, CultureInfo.InvariantCulture)
				};
			}
			if (peek.Kind == T.Hex)
			{
				_p++;
				return new Lit
				{
					V = (double)Convert.ToInt32(peek.Text, 16)
				};
			}
			if (peek.Kind == T.Bool)
			{
				_p++;
				return new Lit
				{
					V = ((peek.Text.Trim().ToLowerInvariant() == "true") ? 1.0 : 0.0)
				};
			}
			if (peek.Kind == T.Str)
			{
				_p++;
				if (IsP("["))
				{
					_p++;
					Call call = new Call
					{
						Name = peek.Text.Trim().ToLowerInvariant()
					};
					if (!IsP("]"))
					{
						call.Args.Add(Expr(0));
						while (IsP(","))
						{
							_p++;
							call.Args.Add(Expr(0));
						}
					}
					Want("]");
					return call;
				}
				string v = (peek.Text.StartsWith("`") ? Unescape(peek.Text.Substring(1, peek.Text.Length - 2)) : Unescape(peek.Text));
				return new Lit
				{
					V = v
				};
			}
			throw new Exception("Unexpected end of expression");
		}
	}

	private class Delayed
	{
		public int Id;

		public string Expr;

		public DateTime At;
	}

	private static readonly string[] Puncts = new string[31]
	{
		">>", "<<", ">=", "<=", "==", "!=", "&&", "||", ";", "(",
		")", "$", "@", "&", "{", ":", "}", "~", "^", "|",
		"*", "/", "%", "+", "#", "=", ">", "<", "[", ",",
		"]"
	};

	private static readonly Dictionary<string, List<Node>> _cache = new Dictionary<string, List<Node>>();

	private static readonly List<Delayed> _delayed = new List<Delayed>();

	private static int _nextDelay = 1;

	private static readonly Dictionary<int, double> _health = new Dictionary<int, double>();

	private const string SessionKey = "MelkTank.ExprVars";

	private static Dictionary<string, object> _session;

	private static string _sessionChar;

	private static Dictionary<string, object> _p;

	private static Dictionary<string, object> _g;

	private static string _pChar;

	private static bool _pDirty;

	private static bool _gDirty;

	private static DateTime _saveAt = DateTime.MinValue;

	private static Dictionary<string, object> Session
	{
		get
		{
			string text = CharName();
			if (_session != null && _sessionChar == text)
			{
				return _session;
			}
			_sessionChar = text;
			object obj = null;
			try
			{
				obj = AppDomain.CurrentDomain.GetData("MelkTank.ExprVars:" + text);
			}
			catch
			{
			}
			Dictionary<string, object> dictionary = obj as Dictionary<string, object>;
			_session = new Dictionary<string, object>();
			if (dictionary != null)
			{
				foreach (KeyValuePair<string, object> item in dictionary)
				{
					if (item.Value is double || item.Value is string)
					{
						_session[item.Key] = item.Value;
					}
				}
			}
			try
			{
				AppDomain.CurrentDomain.SetData("MelkTank.ExprVars:" + text, _session);
			}
			catch
			{
			}
			return _session;
		}
	}

	public static IEnumerable<KeyValuePair<string, object>> SessionVars => Session;

	private static string PFile
	{
		get
		{
			string text = CharName();
			return Util.FullPath("MelkTank_PVars_" + text.Replace(' ', '_') + ".txt");
		}
	}

	private static string GFile => Util.FullPath("MelkTank_GVars.txt");

	private static Dictionary<string, object> P
	{
		get
		{
			string text = CharName();
			if (_p != null && _pChar == text)
			{
				return _p;
			}
			SaveNow();
			_pChar = text;
			_p = new Dictionary<string, object>();
			try
			{
				string pFile = PFile;
				if (File.Exists(pFile))
				{
					Load(pFile, _p, global: false);
				}
				else if (ImportUb(_p, pvars: true))
				{
					_pDirty = true;
				}
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
			return _p;
		}
	}

	private static Dictionary<string, object> G
	{
		get
		{
			if (_g != null)
			{
				return _g;
			}
			_g = new Dictionary<string, object>();
			try
			{
				string gFile = GFile;
				if (File.Exists(gFile))
				{
					Load(gFile, _g, global: true);
				}
				else if (ImportUb(_g, pvars: false))
				{
					_gDirty = true;
				}
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
			return _g;
		}
	}

	public static IEnumerable<KeyValuePair<string, object>> PVars => P;

	public static IEnumerable<KeyValuePair<string, object>> GVarsHere
	{
		get
		{
			string pre = Server() + "\t";
			foreach (KeyValuePair<string, object> kv in G)
			{
				if (kv.Key.StartsWith(pre, StringComparison.Ordinal))
				{
					yield return new KeyValuePair<string, object>(kv.Key.Substring(pre.Length), kv.Value);
				}
			}
		}
	}

	private static bool StrStart(char c)
	{
		int result;
		switch (c)
		{
		default:
			result = ((c >= 'a' && c <= 'z') ? 1 : 0);
			break;
		case '"':
		case '\'':
		case 'A':
		case 'B':
		case 'C':
		case 'D':
		case 'E':
		case 'F':
		case 'G':
		case 'H':
		case 'I':
		case 'J':
		case 'K':
		case 'L':
		case 'M':
		case 'N':
		case 'O':
		case 'P':
		case 'Q':
		case 'R':
		case 'S':
		case 'T':
		case 'U':
		case 'V':
		case 'W':
		case 'X':
		case 'Y':
		case 'Z':
		case '_':
			result = 1;
			break;
		}
		return (byte)result != 0;
	}

	private static bool StrPart(char c)
	{
		return c == ' ' || StrStart(c) || (c >= '0' && c <= '9');
	}

	private static bool Digit(char c)
	{
		return c >= '0' && c <= '9';
	}

	private static bool HexDigit(char c)
	{
		return Digit(c) || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
	}

	private static List<Tok> Lex(string s)
	{
		List<Tok> list = new List<Tok>();
		int i = 0;
		while (true)
		{
			bool flag = true;
			for (; i < s.Length && (s[i] == ' ' || s[i] == '\t' || s[i] == '\r' || s[i] == '\n'); i++)
			{
			}
			if (i >= s.Length)
			{
				break;
			}
			int num = 0;
			T kind = T.Punct;
			string[] puncts = Puncts;
			foreach (string text in puncts)
			{
				if (string.CompareOrdinal(s, i, text, 0, text.Length) == 0 && text.Length > num)
				{
					num = text.Length;
					kind = T.Punct;
				}
			}
			string[] array = new string[2] { "true", "false" };
			foreach (string text2 in array)
			{
				if (i + text2.Length <= s.Length && string.Compare(s, i, text2, 0, text2.Length, StringComparison.OrdinalIgnoreCase) == 0 && text2.Length > num)
				{
					num = text2.Length;
					kind = T.Bool;
				}
			}
			if (s[i] == '-' && num < 1)
			{
				num = 1;
				kind = T.Minus;
			}
			int l;
			for (l = i; l < s.Length && Digit(s[l]); l++)
			{
			}
			int num2 = l - i;
			if (l < s.Length && s[l] == '.')
			{
				int m;
				for (m = l + 1; m < s.Length && Digit(s[m]); m++)
				{
				}
				if (m > l + 1)
				{
					num2 = m - i;
				}
			}
			if (num2 > num)
			{
				num = num2;
				kind = T.Number;
			}
			if (i + 2 < s.Length && s[i] == '0' && s[i + 1] == 'x' && HexDigit(s[i + 2]))
			{
				int n;
				for (n = i + 2; n < s.Length && HexDigit(s[n]); n++)
				{
				}
				if (n - i > num)
				{
					num = n - i;
					kind = T.Hex;
				}
			}
			if (s[i] == '`')
			{
				int num3;
				for (num3 = i + 1; num3 < s.Length && s[num3] != '`'; num3++)
				{
					if (s[num3] == '\\' && num3 + 1 < s.Length)
					{
						num3++;
					}
				}
				if (num3 < s.Length)
				{
					int num4 = num3 + 1 - i;
					if (num4 > num)
					{
						num = num4;
						kind = T.Str;
					}
				}
			}
			else if (StrStart(s[i]) || (s[i] == '\\' && i + 1 < s.Length))
			{
				int num5;
				for (num5 = i; num5 < s.Length && (StrStart(s[num5]) || (s[num5] == '\\' && num5 + 1 < s.Length)); num5 += ((s[num5] != '\\') ? 1 : 2))
				{
				}
				for (; num5 < s.Length && (StrPart(s[num5]) || (s[num5] == '\\' && num5 + 1 < s.Length)); num5 += ((s[num5] != '\\') ? 1 : 2))
				{
				}
				while (num5 > i && s[num5 - 1] == ' ' && (num5 < 2 || s[num5 - 2] != '\\'))
				{
					num5--;
				}
				if (num5 - i > num)
				{
					num = num5 - i;
					kind = T.Str;
				}
			}
			if (num == 0)
			{
				list.Add(new Tok
				{
					Kind = T.Punct,
					Text = s.Substring(i, 1),
					Pos = i
				});
				i++;
			}
			else
			{
				list.Add(new Tok
				{
					Kind = kind,
					Text = s.Substring(i, num),
					Pos = i
				});
				i += num;
			}
		}
		list.Add(new Tok
		{
			Kind = T.End,
			Text = "",
			Pos = i
		});
		return list;
	}

	private static double Num(object v, string op)
	{
		if (v is double)
		{
			return (double)v;
		}
		throw new Exception("Expected a number for " + op + " but got a " + TypeName(v) + " (" + Str(v) + ")");
	}

	internal static object Ev(Node n)
	{
		object v;
		try
		{
			v = n.Eval();
		}
		catch (NullReferenceException)
		{
			return 0.0;
		}
		return Fix(v);
	}

	public static object Fix(object v)
	{
		if (v == null)
		{
			return 0.0;
		}
		if (v is bool)
		{
			return ((bool)v) ? 1.0 : 0.0;
		}
		if (v is int)
		{
			return (double)(int)v;
		}
		if (v is uint)
		{
			return (double)(uint)v;
		}
		if (v is long)
		{
			return (double)(long)v;
		}
		if (v is float)
		{
			return (double)(float)v;
		}
		if (v is short)
		{
			return (double)(short)v;
		}
		if (v is byte)
		{
			return (double)(int)(byte)v;
		}
		return v;
	}

	public static bool IsTruthy(object o)
	{
		if (o == null)
		{
			return false;
		}
		if (o is double)
		{
			return (double)o != 0.0;
		}
		if (o is string text)
		{
			return text.Length > 0;
		}
		return true;
	}

	public static string Str(object v)
	{
		if (v == null)
		{
			return "0";
		}
		if (v is double num)
		{
			return num.ToString(CultureInfo.InvariantCulture);
		}
		if (v is bool)
		{
			return ((bool)v) ? "True" : "False";
		}
		return v.ToString();
	}

	public static string TypeName(object v)
	{
		if (v == null)
		{
			return "null";
		}
		if (v is double || v is bool || v is int)
		{
			return "number";
		}
		if (v is string)
		{
			return "string";
		}
		if (v is ExprWO)
		{
			return "WorldObject";
		}
		if (v is ExprList)
		{
			return "List";
		}
		if (v is ExprDict)
		{
			return "Dictionary";
		}
		if (v is ExprCoords)
		{
			return "Coordinates";
		}
		if (v is ExprStopwatch)
		{
			return "Stopwatch";
		}
		return v.GetType().Name;
	}

	private static string Unescape(string s)
	{
		return Regex.Replace(s, "\\\\(.)", "$1");
	}

	private static List<Node> Compile(string expr)
	{
		if (_cache.TryGetValue(expr, out var value))
		{
			return value;
		}
		value = new Parser(expr).ParseAll();
		if (_cache.Count > 2000)
		{
			_cache.Clear();
		}
		_cache[expr] = value;
		return value;
	}

	public static object Run(string expr)
	{
		object result = 0.0;
		foreach (Node item in Compile(expr ?? ""))
		{
			result = Ev(item);
		}
		return result;
	}

	public static object Eval(string expr, out string error)
	{
		error = null;
		if (string.IsNullOrEmpty(expr))
		{
			return null;
		}
		try
		{
			return Run(expr);
		}
		catch (Exception ex)
		{
			error = ex.Message;
			return null;
		}
	}

	public static int Delay(double ms, string expr)
	{
		Delayed delayed = new Delayed
		{
			Id = _nextDelay++,
			Expr = expr,
			At = DateTime.UtcNow.AddMilliseconds(ms)
		};
		_delayed.Add(delayed);
		return delayed.Id;
	}

	public static bool ClearDelay(int id)
	{
		return _delayed.RemoveAll((Delayed d) => d.Id == id) > 0;
	}

	public static void Tick()
	{
		if (_delayed.Count > 0)
		{
			DateTime now = DateTime.UtcNow;
			List<Delayed> list = _delayed.FindAll((Delayed d) => d.At <= now);
			if (list.Count > 0)
			{
				_delayed.RemoveAll((Delayed d) => d.At <= now);
				foreach (Delayed item in list)
				{
					Eval(item.Expr, out var error);
					if (error != null)
					{
						Util.WriteToChat("delayexec: " + error);
					}
				}
			}
		}
		VarsTick();
		ExprQuests.Tick();
	}

	public static double HealthOf(int id)
	{
		double value;
		return _health.TryGetValue(id, out value) ? value : (-1.0);
	}

	public static void OnServerMessage(Message msg)
	{
		if (msg == null || msg.Type != 63408)
		{
			return;
		}
		byte[] rawData = msg.RawData;
		if (rawData != null && rawData.Length >= 24 && BitConverter.ToUInt32(rawData, 12) == 448)
		{
			int key = BitConverter.ToInt32(rawData, 16);
			float num = BitConverter.ToSingle(rawData, 20);
			if (_health.Count > 3000)
			{
				_health.Clear();
			}
			_health[key] = num;
		}
	}

	private static string CharName()
	{
		try
		{
			return CoreManager.Current.CharacterFilter.Name ?? "";
		}
		catch
		{
			return "";
		}
	}

	private static string Server()
	{
		try
		{
			return CoreManager.Current.CharacterFilter.Server ?? "";
		}
		catch
		{
			return "";
		}
	}

	public static object GetSession(string n)
	{
		object value;
		return Session.TryGetValue(n, out value) ? value : ((object)0.0);
	}

	public static object SetSession(string n, object v)
	{
		Session[n] = v ?? ((object)0.0);
		return v;
	}

	public static bool ClearSession(string n)
	{
		return Session.Remove(n);
	}

	public static bool TestSession(string n)
	{
		return Session.ContainsKey(n);
	}

	public static void ClearAllSession()
	{
		Session.Clear();
	}

	public static object GetP(string n)
	{
		object value;
		return P.TryGetValue(n, out value) ? value : ((object)0.0);
	}

	public static object SetP(string n, object v)
	{
		if (!Saveable(v))
		{
			return 0.0;
		}
		P[n] = v ?? ((object)0.0);
		_pDirty = true;
		return v;
	}

	public static bool TestP(string n)
	{
		return P.ContainsKey(n);
	}

	public static bool ClearP(string n)
	{
		bool flag = P.Remove(n);
		if (flag)
		{
			_pDirty = true;
		}
		return flag;
	}

	public static void ClearAllP()
	{
		P.Clear();
		_pDirty = true;
	}

	private static string GK(string n)
	{
		return Server() + "\t" + n;
	}

	public static object GetG(string n)
	{
		object value;
		return G.TryGetValue(GK(n), out value) ? value : ((object)0.0);
	}

	public static object SetG(string n, object v)
	{
		if (!Saveable(v))
		{
			return 0.0;
		}
		G[GK(n)] = v ?? ((object)0.0);
		_gDirty = true;
		return v;
	}

	public static bool TestG(string n)
	{
		return G.ContainsKey(GK(n));
	}

	public static bool ClearG(string n)
	{
		bool flag = G.Remove(GK(n));
		if (flag)
		{
			_gDirty = true;
		}
		return flag;
	}

	public static void ClearAllG()
	{
		string value = Server() + "\t";
		foreach (string item in new List<string>(G.Keys))
		{
			if (item.StartsWith(value, StringComparison.Ordinal))
			{
				G.Remove(item);
			}
		}
		_gDirty = true;
	}

	private static bool Saveable(object v)
	{
		return !(v is ExprStopwatch);
	}

	private static void VarsTick()
	{
		if ((_pDirty || _gDirty) && DateTime.Now >= _saveAt)
		{
			_saveAt = DateTime.Now.AddSeconds(2.0);
			SaveNow();
		}
	}

	public static void SaveNow()
	{
		try
		{
			if (_pDirty && _p != null && !string.IsNullOrEmpty(_pChar))
			{
				_pDirty = false;
				string f = Util.FullPath("MelkTank_PVars_" + _pChar.Replace(' ', '_') + ".txt");
				StringBuilder sb = new StringBuilder("# MelkTank: this character's saved expression variables (@name / setpvar)\r\n");
				foreach (KeyValuePair<string, object> item in _p)
				{
					sb.Append(Esc(item.Key)).Append('\t').Append(ToJson(item.Value))
						.Append("\r\n");
				}
				Util.Locked(f, () =>
				{
					File.WriteAllText(f, sb.ToString());
				});
			}
			if (!_gDirty || _g == null)
			{
				return;
			}
			_gDirty = false;
			string f2 = GFile;
			StringBuilder sb2 = new StringBuilder("# MelkTank: expression variables saved for every character on a server (&name / setgvar)\r\n");
			foreach (KeyValuePair<string, object> item2 in _g)
			{
				int num = item2.Key.IndexOf('\t');
				sb2.Append(Esc(item2.Key.Substring(0, num))).Append('\t').Append(Esc(item2.Key.Substring(num + 1)))
					.Append('\t')
					.Append(ToJson(item2.Value))
					.Append("\r\n");
			}
			Util.Locked(f2, () =>
			{
				File.WriteAllText(f2, sb2.ToString());
			});
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static string Esc(string s)
	{
		return (s ?? "").Replace("\\", "\\\\").Replace("\t", "\\t").Replace("\r", "\\r")
			.Replace("\n", "\\n");
	}

	private static string Unesc(string s)
	{
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < s.Length; i++)
		{
			if (s[i] == '\\' && i + 1 < s.Length)
			{
				char c = s[++i];
				stringBuilder.Append(c switch
				{
					'n' => '\n', 
					'r' => '\r', 
					't' => '\t', 
					_ => c, 
				});
			}
			else
			{
				stringBuilder.Append(s[i]);
			}
		}
		return stringBuilder.ToString();
	}

	private static void Load(string f, Dictionary<string, object> into, bool global)
	{
		string[] array = Util.Locked(f, () => File.ReadAllLines(f));
		foreach (string text in array)
		{
			if (text.Length == 0 || text[0] == '#')
			{
				continue;
			}
			string[] array2 = text.Split('\t');
			try
			{
				if (global)
				{
					if (array2.Length >= 3)
					{
						into[Unesc(array2[0]) + "\t" + Unesc(array2[1])] = FromJson(array2[2]);
					}
				}
				else if (array2.Length >= 2)
				{
					into[Unesc(array2[0])] = FromJson(array2[1]);
				}
			}
			catch
			{
			}
		}
	}

	private static string ToJson(object v)
	{
		if (v == null)
		{
			return "0";
		}
		if (v is double num)
		{
			return num.ToString("R", CultureInfo.InvariantCulture);
		}
		if (v is string s)
		{
			return JStr(s);
		}
		if (v is ExprWO exprWO)
		{
			return "{\"$w\":" + exprWO.Id + "}";
		}
		if (v is ExprCoords exprCoords)
		{
			return "{\"$c\":[" + ToJson(exprCoords.NS) + "," + ToJson(exprCoords.EW) + "," + ToJson(exprCoords.Z) + "]}";
		}
		if (v is ExprList exprList)
		{
			List<string> list = new List<string>();
			foreach (object item in exprList.Items)
			{
				list.Add(ToJson(item));
			}
			return "{\"$l\":[" + string.Join(",", list.ToArray()) + "]}";
		}
		if (v is ExprDict exprDict)
		{
			List<string> list2 = new List<string>();
			foreach (string key in exprDict.Keys)
			{
				list2.Add(JStr(key) + ":" + ToJson(exprDict.Items[key]));
			}
			return "{\"$d\":{" + string.Join(",", list2.ToArray()) + "}}";
		}
		return JStr(v.ToString());
	}

	private static string JStr(string s) => Util.JsonQuote(s);

	private static object FromJson(string s)
	{
		int i = 0;
		return ToValue(JParse(s, ref i));
	}

	private static object JParse(string s, ref int i)
	{
		while (i < s.Length && char.IsWhiteSpace(s[i]))
		{
			i++;
		}
		if (i >= s.Length)
		{
			return null;
		}
		switch (s[i])
		{
		case '"':
		{
			StringBuilder stringBuilder = new StringBuilder();
			i++;
			while (i < s.Length && s[i] != '"')
			{
				if (s[i] == '\\' && i + 1 < s.Length)
				{
					char c = s[++i];
					if (c == 'u' && i + 4 < s.Length)
					{
						stringBuilder.Append((char)Convert.ToInt32(s.Substring(i + 1, 4), 16));
						i += 4;
					}
					else
					{
						stringBuilder.Append(c switch
						{
							'f' => '\f', 
							'b' => '\b', 
							'r' => '\r', 
							't' => '\t', 
							'n' => '\n', 
							_ => c, 
						});
					}
				}
				else
				{
					stringBuilder.Append(s[i]);
				}
				i++;
			}
			i++;
			return stringBuilder.ToString();
		}
		case '[':
		{
			List<object> list2 = new List<object>();
			i++;
			while (true)
			{
				bool flag2 = true;
				while (i < s.Length && char.IsWhiteSpace(s[i]))
				{
					i++;
				}
				if (i >= s.Length || s[i] == ']')
				{
					break;
				}
				list2.Add(JParse(s, ref i));
				while (i < s.Length && char.IsWhiteSpace(s[i]))
				{
					i++;
				}
				if (i < s.Length && s[i] == ',')
				{
					i++;
				}
			}
			i++;
			return list2;
		}
		case '{':
		{
			List<KeyValuePair<string, object>> list = new List<KeyValuePair<string, object>>();
			i++;
			while (true)
			{
				bool flag = true;
				while (i < s.Length && char.IsWhiteSpace(s[i]))
				{
					i++;
				}
				if (i >= s.Length || s[i] == '}')
				{
					break;
				}
				string key = (JParse(s, ref i) as string) ?? "";
				while (i < s.Length && (char.IsWhiteSpace(s[i]) || s[i] == ':'))
				{
					i++;
				}
				list.Add(new KeyValuePair<string, object>(key, JParse(s, ref i)));
				while (i < s.Length && char.IsWhiteSpace(s[i]))
				{
					i++;
				}
				if (i < s.Length && s[i] == ',')
				{
					i++;
				}
			}
			i++;
			return list;
		}
		default:
		{
			int num = i;
			while (i < s.Length && ",]} \t\r\n".IndexOf(s[i]) < 0)
			{
				i++;
			}
			string text = s.Substring(num, i - num);
			if (text == "true")
			{
				return 1.0;
			}
			if (text == "false" || text == "null")
			{
				return 0.0;
			}
			double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out var result);
			return result;
		}
		}
	}

	private static object Field(List<KeyValuePair<string, object>> d, string k)
	{
		foreach (KeyValuePair<string, object> item in d)
		{
			if (string.Equals(item.Key, k, StringComparison.OrdinalIgnoreCase))
			{
				return item.Value;
			}
		}
		return null;
	}

	private static object ToValue(object j)
	{
		if (j is List<object> list)
		{
			ExprList exprList = new ExprList();
			foreach (object item in list)
			{
				exprList.Items.Add(ToValue(item));
			}
			return exprList;
		}
		if (!(j is List<KeyValuePair<string, object>> d))
		{
			return j ?? ((object)0.0);
		}
		object obj;
		if ((obj = Field(d, "$w")) != null)
		{
			return new ExprWO((int)(double)obj);
		}
		if ((obj = Field(d, "$c")) != null)
		{
			List<object> list2 = (List<object>)obj;
			return new ExprCoords((double)list2[1], (double)list2[0], (double)list2[2]);
		}
		if ((obj = Field(d, "$l")) != null)
		{
			return ToValue(obj);
		}
		if ((obj = Field(d, "$d")) != null)
		{
			ExprDict exprDict = new ExprDict();
			foreach (KeyValuePair<string, object> item2 in (List<KeyValuePair<string, object>>)obj)
			{
				exprDict.Set(item2.Key, ToValue(item2.Value));
			}
			return exprDict;
		}
		string text = (Field(d, "$type") as string) ?? "";
		if (text.Contains("ExpressionWorldObject"))
		{
			return new ExprWO((int)(double)(Field(d, "Id") ?? ((object)0.0)));
		}
		if (text.Contains("ExpressionCoordinates"))
		{
			return new ExprCoords((double)(Field(d, "EW") ?? ((object)0.0)), (double)(Field(d, "NS") ?? ((object)0.0)), (double)(Field(d, "Z") ?? ((object)0.0)));
		}
		if (text.Contains("ExpressionList"))
		{
			ExprList exprList2 = new ExprList();
			object obj2 = Field(d, "Items");
			List<object> list3 = ((obj2 is List<KeyValuePair<string, object>> d2) ? (Field(d2, "$values") as List<object>) : (obj2 as List<object>));
			if (list3 != null)
			{
				foreach (object item3 in list3)
				{
					exprList2.Items.Add(ToValue(item3));
				}
			}
			return exprList2;
		}
		if (text.Contains("ExpressionDictionary"))
		{
			ExprDict exprDict2 = new ExprDict();
			if (Field(d, "Items") is List<KeyValuePair<string, object>> list4)
			{
				foreach (KeyValuePair<string, object> item4 in list4)
				{
					if (!item4.Key.StartsWith("$"))
					{
						exprDict2.Set(item4.Key, ToValue(item4.Value));
					}
				}
			}
			return exprDict2;
		}
		return 0.0;
	}

	private static bool ImportUb(Dictionary<string, object> into, bool pvars)
	{
		try
		{
			Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
			foreach (Assembly assembly in assemblies)
			{
				if (!assembly.FullName.StartsWith("UtilityBelt,", StringComparison.Ordinal))
				{
					continue;
				}
				Type type = assembly.GetType("UtilityBelt.UtilityBeltPlugin");
				object obj = ((type == null) ? null : Get(type, null, "Instance", BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic));
				object obj2 = ((obj == null) ? null : Get(type, obj, "Database", BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic));
				object obj3 = ((obj2 == null) ? null : Get(obj2.GetType(), obj2, pvars ? "PersistentVariables" : "GlobalVariables", BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic));
				if (obj3 == null)
				{
					continue;
				}
				MethodInfo method = obj3.GetType().GetMethod("FindAll", Type.EmptyTypes);
				IEnumerable enumerable = ((method != null) ? (method.Invoke(obj3, null) as IEnumerable) : null);
				if (enumerable == null)
				{
					continue;
				}
				int num = 0;
				string b = CharName();
				string b2 = Server();
				foreach (object item in enumerable)
				{
					Type type2 = item.GetType();
					string text = Get(type2, item, "Name", BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic) as string;
					string text2 = Get(type2, item, "Server", BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic) as string;
					string text3 = Get(type2, item, "Value", BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic) as string;
					if (string.IsNullOrEmpty(text) || text3 == null)
					{
						continue;
					}
					object value;
					try
					{
						value = FromJson(text3);
					}
					catch
					{
						continue;
					}
					if (pvars)
					{
						string a = Get(type2, item, "Character", BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic) as string;
						if (!string.Equals(a, b, StringComparison.Ordinal) || !string.Equals(text2, b2, StringComparison.Ordinal))
						{
							continue;
						}
						into[text] = value;
					}
					else
					{
						into[text2 + "\t" + text] = value;
					}
					num++;
				}
				if (num > 0)
				{
					Util.WriteToChat("Expressions: copied " + num + " saved " + (pvars ? "character (@)" : "global (&)") + " variable" + ((num == 1) ? "" : "s") + " from UtilityBelt.");
				}
				return num > 0;
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		return false;
	}

	private static object Get(Type t, object o, string name, BindingFlags f)
	{
		PropertyInfo property = t.GetProperty(name, f);
		if (property != null)
		{
			return property.GetValue(o, null);
		}
		FieldInfo field = t.GetField(name, f);
		return (field != null) ? field.GetValue(o) : null;
	}
}
