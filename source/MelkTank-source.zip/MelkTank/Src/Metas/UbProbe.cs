using System;
using System.IO;
using System.Reflection;
using System.Text;

namespace MelkTank.Metas;

public static class UbProbe
{
	private static bool _done;

	private static DateTime _at = DateTime.Now.AddSeconds(20.0);

	public static void Tick()
	{
		if (_done || DateTime.Now < _at)
		{
			return;
		}
		_done = true;
		try
		{
			StringBuilder stringBuilder = new StringBuilder("MelkTank: UtilityBelt probe " + DateTime.Now.ToString() + "\r\n");
			Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
			foreach (Assembly assembly in assemblies)
			{
				string name = assembly.GetName().Name;
				if (name.IndexOf("UtilityBelt", StringComparison.OrdinalIgnoreCase) < 0)
				{
					continue;
				}
				stringBuilder.Append("== ").Append(assembly.FullName).Append("  @ ")
					.Append(SafeLoc(assembly))
					.Append("\r\n");
				Type[] types;
				try
				{
					types = assembly.GetTypes();
				}
				catch (ReflectionTypeLoadException ex)
				{
					types = ex.Types;
				}
				Type[] array = types;
				foreach (Type type in array)
				{
					if (type == null)
					{
						continue;
					}
					string text = type.FullName ?? type.Name;
					bool flag = text.IndexOf("Expression", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("VTank", StringComparison.OrdinalIgnoreCase) >= 0 || text.EndsWith(".UtilityBeltPlugin") || text.IndexOf("Meta", StringComparison.OrdinalIgnoreCase) >= 0;
					MethodInfo[] methods = type.GetMethods(BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
					foreach (MethodInfo methodInfo in methods)
					{
						string name2 = methodInfo.Name;
						if (name2.IndexOf("Evaluat", StringComparison.OrdinalIgnoreCase) >= 0 || name2.IndexOf("Expression", StringComparison.OrdinalIgnoreCase) >= 0 || name2.IndexOf("Exec", StringComparison.OrdinalIgnoreCase) >= 0 || (flag && methodInfo.IsPublic))
						{
							stringBuilder.Append(methodInfo.IsStatic ? "static " : "").Append(text).Append(".")
								.Append(name2)
								.Append("(");
							ParameterInfo[] parameters = methodInfo.GetParameters();
							for (int l = 0; l < parameters.Length; l++)
							{
								stringBuilder.Append((l > 0) ? ", " : "").Append(parameters[l].ParameterType.Name).Append(" ")
									.Append(parameters[l].Name);
							}
							stringBuilder.Append(") : ").Append(methodInfo.ReturnType.Name).Append("\r\n");
						}
					}
					if (flag)
					{
						PropertyInfo[] properties = type.GetProperties(BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public);
						foreach (PropertyInfo propertyInfo in properties)
						{
							stringBuilder.Append("  prop ").Append(text).Append(".")
								.Append(propertyInfo.Name)
								.Append(" : ")
								.Append(propertyInfo.PropertyType.Name)
								.Append("\r\n");
						}
					}
				}
			}
			File.WriteAllText(Util.FullPath("MelkTank_ubprobe.txt"), stringBuilder.ToString());
		}
		catch (Exception ex2)
		{
			Util.LogError(ex2);
		}
	}

	private static string SafeLoc(Assembly a)
	{
		try
		{
			return a.Location;
		}
		catch
		{
			return "?";
		}
	}
}
