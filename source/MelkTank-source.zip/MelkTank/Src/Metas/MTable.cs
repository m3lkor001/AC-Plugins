using System.Collections.Generic;

namespace MelkTank.Metas;

public class MTable
{
	public List<string> Cols = new List<string>();

	public List<string> Flags = new List<string>();

	public List<List<MVal>> Rows = new List<List<MVal>>();

	public static MTable Make(params string[] cols)
	{
		MTable mTable = new MTable();
		foreach (string item in cols)
		{
			mTable.Cols.Add(item);
			mTable.Flags.Add("n");
		}
		return mTable;
	}
}
