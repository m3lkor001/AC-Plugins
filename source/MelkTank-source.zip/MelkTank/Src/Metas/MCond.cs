using System.Collections.Generic;

namespace MelkTank.Metas;

public class MCond
{
	public int Type;

	public MVal Data = MVal.Int(0);

	public List<MCond> Kids;

	public MCond Clone()
	{
		MCond mCond = new MCond
		{
			Type = Type,
			Data = ((Data == null) ? null : Data.Clone())
		};
		if (Kids != null)
		{
			mCond.Kids = new List<MCond>();
			foreach (MCond kid in Kids)
			{
				mCond.Kids.Add(kid.Clone());
			}
		}
		return mCond;
	}
}
