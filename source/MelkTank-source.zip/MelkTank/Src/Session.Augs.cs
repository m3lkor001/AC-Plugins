using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using MelkTank.Metas;
using AcClient;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Bounties;
using MelkTank.Buffs;

namespace MelkTank;

public static partial class Session
{
	private static void NoteAugs(string text)
	{
		string[] array = text.Replace("\r", "").Split('\n');
		foreach (string text2 in array)
		{
			string text3 = text2.Trim();
			if (text3.Length == 0 || text3.Trim('-').Length == 0)
			{
				continue;
			}
			bool capturing = DateTime.Now <= _augCaptureUntil;
			// (the list starts with its title - or, since T11+'s change, may start straight at "Creature: N")
			bool header = text3.StartsWith("Advanced Augmentation Levels", StringComparison.OrdinalIgnoreCase);
			bool firstRow = !capturing && Regex.IsMatch(text3, "^Creature:\\s*[\\d,]+$");
			if (header || firstRow)
			{
				_augs.Clear();
				_augHunt.Clear();
				_augInHunt = false;
				_augHuntResetAt = DateTime.MinValue;
				_augsAt = DateTime.Now;
				_augCaptureUntil = DateTime.Now.AddSeconds(3.0);
				_augDirtyAt = DateTime.Now;
				if (header)
				{
					continue;
				}
				capturing = true;
			}
			if (!capturing)
			{
				continue;
			}
			if (AugHuntLineRx.IsMatch(text3) || (_augInHunt && text3.IndexOf("<- you are here", StringComparison.OrdinalIgnoreCase) >= 0))
			{
				_augInHunt = true;
				// ("Hunting rewards this week:" is just the title; "Hunting rewards: they start once..." says why there are none)
				if (!text3.StartsWith("Hunting rewards", StringComparison.OrdinalIgnoreCase) || !text3.TrimEnd().EndsWith(":"))
				{
					_augHunt.Add(text3);
				}
				if (text3.StartsWith("Kills this week", StringComparison.OrdinalIgnoreCase))
				{
					NoteHuntGains();
					_augKillsSince = 0;   // (the server's count from here: MelkTank's kills add on till the next /aug)
				}
				Match m = AugResetInRx.Match(text3);
				if (text3.StartsWith("Week resets", StringComparison.OrdinalIgnoreCase) && m.Success)
				{
					int.TryParse(m.Groups["d"].Value, out var d);
					int.TryParse(m.Groups["h"].Value, out var h);
					int.TryParse(m.Groups["m"].Value, out var mi);
					_augHuntResetAt = DateTime.Now.AddDays(d).AddHours(h).AddMinutes(mi);
				}
				_augCaptureUntil = DateTime.Now.AddSeconds(3.0);
				_augDirtyAt = DateTime.Now;
				continue;
			}
			Match match = (_augInHunt ? AugNumberRowRx : AugLineRx).Match(text3);
			if (!match.Success)
			{
				_augCaptureUntil = DateTime.MinValue;
				_augInHunt = false;
				continue;
			}
			_augInHunt = false;
			_augs.Add(new KeyValuePair<string, string>(match.Groups["n"].Value.Trim(), match.Groups["v"].Value.Trim()));
			_augCaptureUntil = DateTime.Now.AddSeconds(3.0);
			_augDirtyAt = DateTime.Now;
		}
	}

	/// <summary>"This tier so far" from /aug: each augmentation's count and where this tier ends (Creature -> (4501, 5000)).</summary>
	private static Dictionary<string, KeyValuePair<long, long>> AugTierSoFar()
	{
		var d = new Dictionary<string, KeyValuePair<long, long>>(StringComparer.OrdinalIgnoreCase);
		string line = _augHunt.Find(l => l.StartsWith("This tier so far", StringComparison.OrdinalIgnoreCase));
		if (line == null) return d;
		foreach (Match m in AugTierSoFarRx.Matches(line))
		{
			if (long.TryParse(m.Groups["v"].Value.Replace(",", ""), out var v) && long.TryParse(m.Groups["c"].Value.Replace(",", ""), out var c))
				d[m.Groups["n"].Value] = new KeyValuePair<long, long>(v, c);
		}
		return d;
	}

	private static string AugResetText()
	{
		if (_augHuntResetAt == DateTime.MinValue) return "";
		TimeSpan left = _augHuntResetAt - DateTime.Now;
		if (left.TotalMinutes < 1) return "the weekly reset has passed - Check /aug";
		string i = left.TotalDays >= 1 ? $"{(int)left.TotalDays}d {left.Hours}h" : left.TotalHours >= 1 ? $"{(int)left.TotalHours}h {left.Minutes}m" : $"{left.Minutes}m";
		return $"{_augHuntResetAt:ddd h:mm tt} (in {i})";
	}

	public static void QuietNext(string command)
	{
		string text = (command ?? "").Trim().ToLowerInvariant();
		if (text == "/bank")
		{
			_quietBankUntil = DateTime.Now.AddSeconds(8.0);
		}
		else if (text == "/aug" || text.StartsWith("/aug "))
		{
			_quietAugUntil = DateTime.Now.AddSeconds(8.0);
		}
		else
		{
			QuietNextDeeds(text);
		}
	}

	public static bool Quiet(string text)
	{
		if (string.IsNullOrEmpty(text))
		{
			return false;
		}
		string text2 = text.TrimStart();
		if (QuietDeeds(text2))
		{
			return true;
		}
		if (QuietPace(text2))
		{
			return true;
		}
		if (AttrQuiet(text2))
		{
			return true;
		}
		if (DateTime.Now <= _quietBankUntil && text2.Trim().Length > 0 && text2.Trim().Trim('-').Length == 0)
		{
			return true;
		}
		if (DateTime.Now <= _quietBankUntil && text2.StartsWith("[BANK]", StringComparison.OrdinalIgnoreCase))
		{
			_quietBankUntil = DateTime.Now.AddSeconds(2.0);
			return true;
		}
		if (DateTime.Now <= _quietAugUntil)
		{
			string text3 = text2.Trim();
			if (text3.Length > 0 && text3.Trim('-').Length == 0)
			{
				return true;
			}
			if (text2.IndexOf("Advanced Augmentation Levels", StringComparison.OrdinalIgnoreCase) >= 0 || (DateTime.Now > _augCaptureUntil && Regex.IsMatch(text2.Trim(), "^Creature:\\s*[\\d,]+$")))
			{
				_quietAugUntil = DateTime.Now.AddSeconds(2.0);
				return true;
			}
			if (DateTime.Now <= _augCaptureUntil && (text2.Trim().Trim('-').Length == 0 || AugLineRx.IsMatch(text2.Trim()) || AugHuntLineRx.IsMatch(text2.Trim()) || text2.IndexOf("<- you are here", StringComparison.OrdinalIgnoreCase) >= 0))
			{
				_quietAugUntil = DateTime.Now.AddSeconds(2.0);
				return true;
			}
		}
		return false;
	}

	private static void AugFileTick()
	{
		if (_augDirtyAt == DateTime.MinValue || (DateTime.Now - _augDirtyAt).TotalSeconds < 4.0 || _augFile == null)
		{
			return;
		}
		_augDirtyAt = DateTime.MinValue;
		try
		{
			StringBuilder stringBuilder = new StringBuilder("# MelkTank: the last /aug list for this character (Session > Augs)\r\n@" + _augsAt.Ticks + "\r\n");
			foreach (KeyValuePair<string, string> aug in _augs)
			{
				stringBuilder.Append(aug.Key.Replace("\t", " ")).Append('\t').Append(aug.Value.Replace("\t", " "))
					.Append("\r\n");
			}
			if (_augHuntResetAt != DateTime.MinValue)
			{
				stringBuilder.Append("~reset\t").Append(_augHuntResetAt.Ticks).Append("\r\n");
			}
			foreach (string h in _augHunt)
			{
				stringBuilder.Append("~hunt\t").Append(h.Replace("\t", " ")).Append("\r\n");
			}
			Util.WriteShared(_augFile, stringBuilder.ToString());
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void LoadAugs()
	{
		_augs.Clear();
		_augHunt.Clear();
		_augHuntResetAt = DateTime.MinValue;
		_augsAt = DateTime.MinValue;
		if (_augFile == null || !File.Exists(_augFile))
		{
			return;
		}
		try
		{
			string[] array = Util.Locked(_augFile, () => File.ReadAllLines(_augFile));
			foreach (string text in array)
			{
				if (text.StartsWith("#"))
				{
					continue;
				}
				if (text.StartsWith("@") && long.TryParse(text.Substring(1), out var result))
				{
					_augsAt = new DateTime(result);
					continue;
				}
				string[] array2 = text.Split('\t');
				if (array2.Length >= 2 && array2[0] == "~hunt")
				{
					_augHunt.Add(array2[1]);
				}
				else if (array2.Length >= 2 && array2[0] == "~reset")
				{
					if (long.TryParse(array2[1], out var rt)) _augHuntResetAt = new DateTime(rt);
				}
				else if (array2.Length >= 2)
				{
					_augs.Add(new KeyValuePair<string, string>(array2[0], array2[1]));
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void DrawCreditsRow()
	{
		ImGui.TableNextRow();
		ImGui.TableSetColumnIndex(0);
		Im.TextColored(Cyan, "Skill Credits (gems)");
		if (ImGui.IsItemHovered()) Im.SetTooltip("Not in /aug: counted as each Skill Credit Gem is used (/mtank credits N to set it).");
		ImGui.TableSetColumnIndex(1);
		ImGui.TextUnformatted(CreditsBought().ToString("N0"));
	}

	private static void DrawAugs()
	{
		if (ImGui.Button("Check /aug"))
		{
			QuietNext("/aug");
			Util.Command("/aug");
		}
		if (_augs.Count == 0)
		{
			Im.TextDisabled("Nothing yet - click Check /aug.");
			return;
		}
		ImGui.SameLine();
		Im.TextDisabled("as of " + ((_augsAt.Date == DateTime.Today) ? _augsAt.ToString("HH:mm") : _augsAt.ToString("MM-dd HH:mm")));
		if (!ImGui.BeginTable("auglist", 2, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
		{
			return;
		}
		ImGui.TableSetupColumn("Augmentation", ImGuiTableColumnFlags.WidthFixed, 200f);
		ImGui.TableSetupColumn("Level", ImGuiTableColumnFlags.WidthStretch);
		ImGui.TableHeadersRow();
		bool creditsShown = false;
		var soFar = AugTierSoFar();
		// (the combat augs - War, Void, Melee, Missile; not Summon - aren't in /aug's "this tier so far": their window is
		// worked out from the tier, T11 2,000-2,500 and +500 a tier (T12 2,500-3,000), and shown once one's in it; moving
		// up a tier needs one of them at the next tier's level)
		int tier = AugTier(soFar);
		long combatFrom = tier > 0 ? 2000 + 500L * (tier - 11) : 0, combatTo = combatFrom + 500;
		foreach (KeyValuePair<string, string> aug in _augs)
		{
			ImGui.TableNextRow();
			ImGui.TableSetColumnIndex(0);
			Im.TextColored(Cyan, aug.Key);
			ImGui.TableSetColumnIndex(1);
			ImGui.TextUnformatted(aug.Value);
			// (T11+: how far into this tier's +500 - its end is where hunting stops adding till you move up)
			if (soFar.TryGetValue(aug.Key, out var t))
			{
				ImGui.SameLine();
				if (t.Key >= t.Value) Im.TextColored(AugGreen, "  tier's end reached (" + t.Value.ToString("N0") + ") - move up a tier");
				else Im.TextDisabled("  of " + t.Value.ToString("N0") + " this tier (" + (t.Value - t.Key).ToString("N0") + " to go)");
			}
			else if (tier > 0 && IsCombatAug(aug.Key) && AugValue(aug.Value) is long lv && lv >= combatFrom)
			{
				ImGui.SameLine();
				if (lv >= combatTo) Im.TextColored(AugGreen, "  at the next tier's level (" + combatTo.ToString("N0") + ")");
				else Im.TextDisabled("  of " + combatTo.ToString("N0") + " this tier (" + (combatTo - lv).ToString("N0") + " to go)");
			}
			// (skill credits from gems: /aug doesn't list them - shown under Specialization, from the count kept here)
			if (!creditsShown && aug.Key.StartsWith("Specialization", StringComparison.OrdinalIgnoreCase))
			{
				creditsShown = true;
				DrawCreditsRow();
			}
		}
		if (!creditsShown)
		{
			DrawCreditsRow();
		}
		ImGui.EndTable();
		if (tier > 0)
		{
			// one combat aug at the next tier's level is needed to move up: the nearest one
			string best = null;
			long bestLv = -1;
			foreach (var a in _augs)
				if (IsCombatAug(a.Key) && AugValue(a.Value) is long v && v > bestLv) { bestLv = v; best = a.Key; }
			if (best != null)
			{
				Im.TextColored(Cyan, "Combat aug to move up to T" + (tier + 1) + ":");
				ImGui.SameLine();
				if (bestLv >= combatTo) Im.TextColored(AugGreen, best + " " + bestLv.ToString("N0") + " - at " + combatTo.ToString("N0") + ", done");
				else ImGui.TextUnformatted("one of War / Void / Melee / Missile at " + combatTo.ToString("N0") + " - nearest " + best + " " + bestLv.ToString("N0") + " (" + (combatTo - bestLv).ToString("N0") + " to go)");
			}
		}
		DrawAugHunt();
	}

	private static bool IsCombatAug(string name) =>
		name.Equals("War", StringComparison.OrdinalIgnoreCase) || name.Equals("Void", StringComparison.OrdinalIgnoreCase)
		|| name.Equals("Melee", StringComparison.OrdinalIgnoreCase) || name.Equals("Missile", StringComparison.OrdinalIgnoreCase);

	/// <summary>An aug's level from /aug's text ("2,410" or "2,410 ...").</summary>
	private static long? AugValue(string v)
	{
		v = (v ?? "").Trim();
		int sp = v.IndexOf(' ');
		if (sp > 0) v = v.Substring(0, sp);
		return long.TryParse(v.Replace(",", ""), out long n) ? n : (long?)null;
	}

	/// <summary>The tier you're in, from where /aug says this tier ends (Creature 4,500 + 500 a tier past T11 -> its end
	/// 5,000 at T12; Item / Life 2,500 -> 3,000); 0 if /aug didn't say.</summary>
	private static int AugTier(Dictionary<string, KeyValuePair<long, long>> soFar)
	{
		if (soFar.TryGetValue("Creature", out var c) && c.Value >= 4500) return (int)((c.Value - 4500) / 500) + 11;
		foreach (string k in new[] { "Item", "Life" })
			if (soFar.TryGetValue(k, out var t) && t.Value >= 2500) return (int)((t.Value - 2500) / 500) + 11;
		return 0;
	}

	/// <summary>The augs list with /aug's hunting part after it, as rows (for the phone).</summary>
	private static List<KeyValuePair<string, string>> AugRowsWithHunt()
	{
		var rows = new List<KeyValuePair<string, string>>(_augs);
		foreach (var kv in AugHuntRows()) rows.Add(kv);
		var rates = AugRates(out double total);
		if (rates.Count > 0)
		{
			rows.Add(new KeyValuePair<string, string>("Augs/hr", total.ToString("0.0")));
			foreach (var kv in rates) rows.Add(new KeyValuePair<string, string>("  " + kv.Key + "/hr", kv.Value.ToString("0.0")));
		}
		return rows;
	}

	/// <summary>/aug's hunting rewards, boiled down: kills this week, the rate you're on and how long it lasts, the reset.</summary>
	private static List<KeyValuePair<string, string>> AugHuntRows()
	{
		var rows = new List<KeyValuePair<string, string>>();
		if (_augHunt.Count == 0) return rows;
		string kills = _augHunt.Find(l => l.StartsWith("Kills this week", StringComparison.OrdinalIgnoreCase));
		if (kills == null)
		{
			// (below T11: "Hunting rewards: they start once you can fight in the T11 lands.")
			string why = _augHunt.Find(l => l.StartsWith("Hunting rewards", StringComparison.OrdinalIgnoreCase));
			if (why != null) rows.Add(new KeyValuePair<string, string>("Hunting rewards", why.Substring(why.IndexOf(':') + 1).Trim()));
			return rows;
		}
		rows.Add(new KeyValuePair<string, string>("Kills this week", kills.Substring(kills.IndexOf(':') + 1).Trim() + (_augKillsSince > 0 ? " (+" + _augKillsSince + " since)" : "")));
		int toGo = AugKillsLeft(out int _);
		if (toGo > 0) rows.Add(new KeyValuePair<string, string>("Next aug", toGo.ToString("N0") + " kills"));
		else if (toGo == -2) rows.Add(new KeyValuePair<string, string>("Next aug", "none left this week"));
		// (the phone colours a value that starts "g|", "y|" or "r|")
		char pace = AugPace(out var paceNotes);
		foreach (string n in paceNotes) rows.Add(new KeyValuePair<string, string>("Pace", (pace == ' ' ? "" : pace + "|") + n));

		string here = _augHunt.Find(l => l.IndexOf("<- you are here", StringComparison.OrdinalIgnoreCase) >= 0);
		if (here != null)
		{
			Match rate = Regex.Match(here, "1 reward per ([\\d,]+) kills", RegexOptions.IgnoreCase);
			Match left = Regex.Match(here, "\\(([\\d,]+) kills left\\)", RegexOptions.IgnoreCase);
			if (rate.Success) rows.Add(new KeyValuePair<string, string>("Hunting reward", "1 per " + rate.Groups[1].Value + " kills" + (left.Success ? " (this rate for " + left.Groups[1].Value + " more)" : "")));
			else rows.Add(new KeyValuePair<string, string>("Hunting reward", here.Replace("<- you are here", "").Trim()));
		}
		else if (_augHunt.Exists(l => l.StartsWith("Beyond", StringComparison.OrdinalIgnoreCase)) && kills != null)
		{
			// (no "you are here" line at all: past the last step)
		}
		string reset = AugResetText();
		if (reset.Length > 0) rows.Add(new KeyValuePair<string, string>("Week resets", reset));
		return rows;
	}

	private static void DrawAugRates()
	{
		var rates = AugRates(out double total);
		if (rates.Count == 0) return;
		ImGui.Spacing();
		Im.TextColored(AugYellow, "Augs an hour (this session): " + total.ToString("0.0"));
		if (ImGui.IsItemHovered()) Im.SetTooltip("From the new hunting augs only, over the session's time (" + Hours.ToString("0.0") + " hr):\nCreature/Item/Life - the rewards, read from /aug each time (levels bought with luminance aren't counted);\nWar/Void/Melee/Missile - attack gems used (yours or MelkTank's).");
		foreach (var kv in rates)
		{
			Im.TextColored(Cyan, "   " + kv.Key + ":");
			ImGui.SameLine();
			ImGui.TextUnformatted(kv.Value.ToString("0.0") + "/hr");
		}
	}

	private static void DrawAugHunt()
	{
		DrawAugRates();
		if (_augHunt.Count == 0) return;
		ImGui.Spacing();
		Im.TextColored(AugYellow, "Hunting rewards this week");
		if (ImGui.IsItemHovered()) Im.SetTooltip("T11+: kills in your own tier (giving XP or luminance, you the top damager - pets count) add 1 to Creature, Item or Life at random.\nAttack school gems (War/Void/Melee/Missile) drop on their own - double click one for +1.");
		foreach (var kv in AugHuntRows())
		{
			Im.TextColored(Cyan, kv.Key + ":");
			ImGui.SameLine();
			// (a pace line's "g|" / "y|" / "r|" is its colour - for the phone; here it's drawn in it)
			string v = kv.Value;
			if (v.Length > 2 && v[1] == '|' && (v[0] == 'g' || v[0] == 'y' || v[0] == 'r'))
				Im.TextColored(v[0] == 'g' ? AugGreen : v[0] == 'y' ? AugYellow : new Vector4(1f, 0.45f, 0.4f, 1f), v.Substring(2));
			else ImGui.TextUnformatted(v);
		}
		// the steps, as /aug gives them
		foreach (string l in _augHunt)
		{
			if (l.StartsWith("First", StringComparison.OrdinalIgnoreCase) || l.StartsWith("After", StringComparison.OrdinalIgnoreCase) || l.StartsWith("Beyond", StringComparison.OrdinalIgnoreCase))
			{
				bool here = l.IndexOf("<- you are here", StringComparison.OrdinalIgnoreCase) >= 0;
				string t = "   " + Regex.Replace(l.Replace("<- you are here", ""), "\\s{2,}", "  ").Trim();
				if (here) Im.TextColored(AugGreen, t + "   <- now");
				else Im.TextDisabled(t);
			}
		}
	}

	private static void DrawAugsTabs()
	{
		if (!ImGui.BeginTabBar("augtabs"))
		{
			return;
		}
		if (ImGui.BeginTabItem("All###augall"))
		{
			DrawAugs();
			ImGui.EndTabItem();
		}
		AugKind[] augKinds = AugKinds;
		foreach (AugKind augKind in augKinds)
		{
			if (ImGui.BeginTabItem(augKind.Tab + "###aug" + augKind.Tab))
			{
				DrawAugPage(augKind);
				ImGui.EndTabItem();
			}
		}
		if (ImGui.BeginTabItem("Skill Credits###augcredits"))
		{
			DrawSkillCredits();
			ImGui.EndTabItem();
		}
		ImGui.EndTabBar();
	}

	public static double CoinsPerKill(int tier)
	{
		if (tier < 11)
		{
			return 0.0;
		}
		if (tier - 11 < CoinRates.Length)
		{
			return CoinRates[tier - 11];
		}
		return CoinRates[CoinRates.Length - 1] * Math.Pow(1.2, tier - 18);
	}

	private static void AugKill()
	{
		int tier = -1;
		try { tier = CurrentTier(); } catch { }
		if (tier < 11) return;
		_augKillsSince++;
		// (a reward due on this kill: read /aug again shortly - the new counts, and the server's kill count to go on from)
		if (AugKillsLeft(out int rate) == rate && rate > 0) _augRecheckAt = DateTime.Now.AddSeconds(5.0);
	}

	private static readonly Regex AugStepRx = new Regex("^(?<w>First|After|Beyond) (?<n>[\\d,]+) kills:\\s*(?:1 reward per (?<r>[\\d,]+) kills)?", RegexOptions.IgnoreCase);

	/// <summary>Kills to the next hunting augmentation (T11+), from /aug's count of the week's kills plus MelkTank's since:
	/// -1 = not known (no /aug with a hunting part), -2 = no more this week. rate = the kills per reward you're on.</summary>
	public static int AugKillsLeft(out int rate)
	{
		rate = 0;
		string kills = _augHunt.Find(l => l.StartsWith("Kills this week", StringComparison.OrdinalIgnoreCase));
		if (kills == null || !long.TryParse(Regex.Replace(kills.Substring(kills.IndexOf(':') + 1), "[^\\d]", ""), out var week)) return -1;
		if (_augHuntResetAt != DateTime.MinValue && DateTime.Now >= _augHuntResetAt) { week = 0; }
		long k = week + _augKillsSince;
		long from = 0;
		foreach (string l in _augHunt)
		{
			Match m = AugStepRx.Match(l);
			if (!m.Success) continue;
			long n = long.Parse(m.Groups["n"].Value.Replace(",", ""));
			string w = m.Groups["w"].Value.ToLowerInvariant();
			if (w == "first")
			{
				int r = int.Parse(m.Groups["r"].Value.Replace(",", ""));
				if (k < n) { rate = r; return (int)(r - k % r); }
				from = n;
			}
			else if (w == "after" && m.Groups["r"].Success)
			{
				int r = int.Parse(m.Groups["r"].Value.Replace(",", ""));
				rate = r;
				long off = k - from;
				return (int)(r - off % r);
			}
			else if (w == "beyond" && k >= n) { return -2; }
		}
		return -1;
	}

	private static DateTime _augVarsAt = DateTime.MinValue;
	private static DateTime _augResetChecked = DateTime.MinValue;
	private static DateTime _augAutoAt = DateTime.MinValue;

	/// <summary>
	/// For metas (getvar): augweekkills - this week's kills in your tier, /aug's count plus MelkTank's since (-1 not known);
	/// augkillsleft - kills to the next hunting aug (-1 not known, -2 none left this week); augweekdone - 1 once the week's
	/// hunting rewards are used up (past the last step), else 0 - so a meta can hunt its tier till then and do something
	/// else after. /aug is read again (quietly) when the week resets, and every 30 min while hunting in T11+.
	/// </summary>
	private static void AugVarsTick()
	{
		if ((DateTime.Now - _augVarsAt).TotalSeconds < 2.0) return;
		_augVarsAt = DateTime.Now;
		int left = AugKillsLeft(out int _);
		long week = -1;
		string kills = _augHunt.Find(l => l.StartsWith("Kills this week", StringComparison.OrdinalIgnoreCase));
		if (kills != null && long.TryParse(Regex.Replace(kills.Substring(kills.IndexOf(':') + 1), "[^\\d]", ""), out var w))
			week = (_augHuntResetAt != DateTime.MinValue && DateTime.Now >= _augHuntResetAt ? 0 : w) + _augKillsSince;
		UbExpr.SetVar("augweekkills", (double)week);
		UbExpr.SetVar("augkillsleft", (double)left);
		UbExpr.SetVar("augweekdone", left == -2 ? 1.0 : 0.0);
		if (_augRecheckAt != DateTime.MinValue || !ServerMode.Ilt) return;
		// (the week's reset gone by: the new week's numbers)
		if (_augHuntResetAt != DateTime.MinValue && DateTime.Now >= _augHuntResetAt.AddMinutes(1) && _augResetChecked != _augHuntResetAt)
		{
			_augResetChecked = _augHuntResetAt;
			_augRecheckAt = DateTime.Now.AddSeconds(5.0);
			return;
		}
		int tier = -1;
		try { tier = CurrentTier(); } catch { }
		if (tier >= 11 && (DateTime.Now - _augsAt).TotalMinutes >= 30.0 && (DateTime.Now - _augAutoAt).TotalMinutes >= 30.0)
		{
			_augAutoAt = DateTime.Now;
			_augRecheckAt = DateTime.Now.AddSeconds(5.0);
		}
	}

	/// <summary>
	/// Whether this week's hunting keeps its pace till the reset, at your kills/hr over the last hour: 'g' - the full rate
	/// all the way; 'y' - it'll slow (or has) to the second step's rate; 'r' - it'll reach the end of the rewards before the
	/// reset; ' ' - not known (no /aug, no kills yet). notes: when it slows / stops.
	/// </summary>
	public static char AugPace(out List<string> notes)
	{
		notes = new List<string>();
		if (_augHuntResetAt == DateTime.MinValue) return ' ';
		string kills = _augHunt.Find(l => l.StartsWith("Kills this week", StringComparison.OrdinalIgnoreCase));
		if (kills == null || !long.TryParse(Regex.Replace(kills.Substring(kills.IndexOf(':') + 1), "[^\\d]", ""), out long week)) return ' ';
		if (DateTime.Now >= _augHuntResetAt) return ' ';
		long k = week + _augKillsSince;
		long first = -1, beyond = -1; int slow = 0;
		foreach (string l in _augHunt)
		{
			Match m = AugStepRx.Match(l);
			if (!m.Success) continue;
			long n = long.Parse(m.Groups["n"].Value.Replace(",", ""));
			string w = m.Groups["w"].Value.ToLowerInvariant();
			if (w == "first") first = n;
			else if (w == "after") { if (m.Groups["r"].Success) int.TryParse(m.Groups["r"].Value.Replace(",", ""), out slow); }
			else if (w == "beyond") beyond = n;
		}
		if (first < 0 || beyond < 0) return ' ';
		if (k >= beyond) { notes.Add("No more this week - resets " + _augHuntResetAt.ToString("ddd h:mm tt")); return 'r'; }
		double kph = KillsPerHourEstimate;
		if (kph <= 0) return k >= first ? 'y' : ' ';
		double hoursLeft = (_augHuntResetAt - DateTime.Now).TotalHours;
		double by = k + kph * hoursLeft;
		string At(long target) => DateTime.Now.AddHours((target - k) / kph).ToString("ddd h:mm tt");
		char c = by >= beyond ? 'r' : (by >= first || k >= first) ? 'y' : 'g';
		if (k < first && by >= first) notes.Add("Slows" + (slow > 0 ? " to 1 per " + slow : "") + " ~" + At(first) + " (at " + first.ToString("N0") + " kills)");
		if (by >= beyond) notes.Add("Stops ~" + At(beyond) + " (at " + beyond.ToString("N0") + " kills) - resets " + _augHuntResetAt.ToString("ddd h:mm tt"));
		if (c == 'g') notes.Add("Full rate till the reset at " + kph.ToString("N0") + " kills/hr (~" + by.ToString("N0") + " by " + _augHuntResetAt.ToString("ddd h:mm tt") + ")");
		return c;
	}

	/// <summary>The bounty popup's line: kills to the next hunting augmentation.</summary>
	public static string AugLine()
	{
		int left = AugKillsLeft(out int rate);
		if (left == -2) return "Aug reward: none left this week";
		if (left < 0) return "";
		return "Aug reward: " + left.ToString("N0", CultureInfo.InvariantCulture) + " kills to go (1 per " + rate + ")";
	}

	public static string AugTipText()
	{
		return "T11+ hunting: every so many kills in your own tier adds 1 to Creature, Item or Life at random.\n" +
			"Counted from /aug's kills this week plus MelkTank's kills since (" + _augKillsSince + ") - a pet's or a fellow's kills, or ones\nthat gave no XP, can make it a little off. Check /aug in Session > Augs to set it right.";
	}

	private static void CoinKill()
	{
		int tier = -1;
		try
		{
			tier = CurrentTier();
		}
		catch
		{
		}
		double num = 1.0;
		try
		{
			num = PaceKill();
		}
		catch
		{
		}
		_coinAcc += CoinsPerKill(tier) * num;
	}

	private static void CoinChat(string text)
	{
		Match match = CoinRx.Match(text);
		if (match.Success)
		{
			if (!int.TryParse(match.Groups["n"].Value.Replace(",", ""), out var result) || result <= 0)
			{
				result = 1;
			}
			_coinsGot += result;
			_coinLog.Add(new KeyValuePair<DateTime, int>(DateTime.Now, result));
			_coinAt = DateTime.Now;
			for (int i = 0; i < result; i++)
			{
				_coinTimes.Add(DateTime.Now);
			}
			_coinTimes.RemoveAll((DateTime t) => (DateTime.Now - t).TotalHours > 1.0);
			_coinAcc = 0.0;
			_coinSynced = true;
		}
	}

	public static long PrestigeCoins(out DateTime bankAt)
	{
		bankAt = DateTime.MinValue;
		BankLine bankLine = _bank.Find((BankLine x) => string.Equals(x.Name, "Prestige Coins", StringComparison.OrdinalIgnoreCase));
		long num = BankCount("Prestige Coins");
		if (bankLine == null || num < 0)
		{
			return -1L;
		}
		bankAt = bankLine.At;
		foreach (KeyValuePair<DateTime, int> item in _coinLog)
		{
			if (item.Key > bankLine.At)
			{
				num += item.Value;
			}
		}
		return num;
	}

	private static void CoinsReset()
	{
		_coinAcc = 0.0;
		_coinSynced = false;
		_coinsGot = 0;
		_coinAt = DateTime.MinValue;
		_coinTimes.Clear();
	}

	public static int CoinKillsLeft()
	{
		int tier = -1;
		try
		{
			tier = CurrentTier();
		}
		catch
		{
		}
		double num = CoinsPerKill(tier);
		if (num <= 0.0)
		{
			return -1;
		}
		return Math.Max(1, (int)Math.Ceiling((1.0 - Math.Min(0.9999, _coinAcc)) / num - 1E-09));
	}

	public static double CoinsPerHour()
	{
		int tier = -1;
		try
		{
			tier = CurrentTier();
		}
		catch
		{
		}
		double num = CoinsPerKill(tier);
		double killsPerHourRecent = KillsPerHourEstimate;
		return (num > 0.0 && killsPerHourRecent > 0.0) ? (num * killsPerHourRecent) : (-1.0);
	}

	public static string CoinLine()
	{
		int num = CoinKillsLeft();
		if (num < 0)
		{
			return "";
		}
		int tier = -1;
		try
		{
			tier = CurrentTier();
		}
		catch
		{
		}
		double num2 = 1.0 / CoinsPerKill(tier);
		double num3 = CoinsPerHour();
		int num4 = (int)Math.Round(num2);
		int num5 = Math.Max(0, Math.Min(num4 - 1, num4 - num));
		return "Prestige Coin: " + (_coinSynced ? "" : "~") + num5 + " / " + num2.ToString((Math.Abs(num2 - (double)num4) < 0.05) ? "0" : "0.0", CultureInfo.InvariantCulture) + ((num3 > 0.0) ? (" - " + num3.ToString("0.0", CultureInfo.InvariantCulture) + "/hr") : "") + PaceText();
	}

	private static string CoinTip()
	{
		return "T11+ kills earn a share of a Prestige Coin (T11 1 per 20 kills, more each tier); a whole one goes to your bank.\n" + (_coinSynced ? ("Counted from the last coin (" + _coinAt.ToString("h:mm tt") + ") with MelkTank's kills - a pet's or a fellow's kills can make it a little early.") : "~ = no coin line yet this session, so where you stand isn't known - it counts from login until the first one.") + "\nCoins this session: " + _coinsGot + ", last 60 min: " + _coinTimes.FindAll((DateTime t) => (DateTime.Now - t).TotalHours <= 1.0).Count + ".\n/hr = your kills / hr over the last 60 min x this tier's share." + PaceTip();
	}

	public static string CoinTipText()
	{
		return CoinTip();
	}
}
