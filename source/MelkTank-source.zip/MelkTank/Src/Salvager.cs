using System;
using System.Collections.Generic;
using System.IO;
using Decal.Adapter.Wrappers;

namespace MelkTank;

public class Salvager
{
	private enum State
	{
		Idle,
		Opening,
		Adding,
		Salvaging,
		Closing
	}

	private const int MaterialKey = 131;

	private readonly Settings _s;

	private readonly Action<string> _log;

	private State _state = State.Idle;

	private DateTime _until = DateTime.MinValue;

	private DateTime _nextTry = DateTime.MinValue;

	private int _ust;

	private readonly List<int> _adding = new List<int>();

	private int _addIdx;

	private readonly Dictionary<int, int> _tries = new Dictionary<int, int>();

	public static readonly HashSet<int> Waiting = new HashSet<int>();

	private static string _file;

	public string Status = "";

	public bool Busy => _state != State.Idle;

	/// <summary>Salvaging once (/ub autosalvage) runs till then, even with Auto salvage off.</summary>
	public DateTime OnceUntil = DateTime.MinValue;

	public Salvager(Settings s, Action<string> log)
	{
		_s = s;
		_log = log;
	}

	public static void LoggedIn(string charName)
	{
		_file = Util.FullPath("MelkTank_Salvage_" + charName + ".txt");
		Waiting.Clear();
		try
		{
			if (!File.Exists(_file))
			{
				return;
			}
			string[] array = File.ReadAllLines(_file);
			foreach (string text in array)
			{
				if (int.TryParse(text.Trim(), out var result))
				{
					Waiting.Add(result);
				}
			}
		}
		catch
		{
		}
	}

	private static void Save()
	{
		if (_file == null)
		{
			return;
		}
		try
		{
			List<string> list = new List<string>();
			foreach (int item in Waiting)
			{
				list.Add(item.ToString());
			}
			File.WriteAllLines(_file, list.ToArray());
		}
		catch
		{
		}
	}

	public static void Add(int id)
	{
		if (Waiting.Add(id))
		{
			Save();
		}
	}

	private static bool Mine(WorldObject o, int me)
	{
		if (o == null)
		{
			return false;
		}
		try
		{
			if (o.Values(LongValueKey.EquippedSlots) != 0 || o.Values(LongValueKey.Wielder) == me)
			{
				return false;
			}
		}
		catch
		{
		}
		return Globals.Core.WorldFilter[o.Id] != null && o.Container != 0;
	}

	private static int Ust()
	{
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (item.ObjectClass == ObjectClass.Ust)
				{
					return item.Id;
				}
			}
		}
		catch
		{
		}
		return 0;
	}

	public bool Tick(bool canAct)
	{
		DateTime now = DateTime.Now;
		if (_state == State.Idle)
		{
			if ((!_s.AutoSalvage && now >= OnceUntil) || !canAct || now < _nextTry || Waiting.Count == 0)
			{
				return false;
			}
			_nextTry = now.AddSeconds(5.0);
			int id = Globals.Core.CharacterFilter.Id;
			List<int> list = new List<int>();
			foreach (int item in Waiting)
			{
				if (!Mine(Globals.Core.WorldFilter[item], id))
				{
					list.Add(item);
				}
			}
			if (list.Count > 0)
			{
				foreach (int item2 in list)
				{
					Waiting.Remove(item2);
				}
				Save();
			}
			if (Waiting.Count == 0)
			{
				return false;
			}
			_ust = Ust();
			if (_ust == 0)
			{
				Status = "no ust in your pack";
				_nextTry = now.AddSeconds(60.0);
				return false;
			}
			_adding.Clear();
			HashSet<int> hashSet = new HashSet<int>();
			foreach (int item3 in Waiting)
			{
				_adding.Add(item3);
				try
				{
					hashSet.Add(Globals.Core.WorldFilter[item3].Values(LongValueKey.Material));
				}
				catch
				{
				}
			}
			if (_s.SalvagePartialBags)
			{
				Dictionary<int, List<int>> dictionary = new Dictionary<int, List<int>>();
				foreach (WorldObject item4 in InvCache.All())
				{
					if (item4.ObjectClass != ObjectClass.Salvage)
					{
						continue;
					}
					int num = 100;
					try
					{
						num = item4.Values(LongValueKey.UsesRemaining);
					}
					catch
					{
					}
					if (num > 0 && num < 100)
					{
						int key = 0;
						try
						{
							key = item4.Values(LongValueKey.Material);
						}
						catch
						{
						}
						if (!dictionary.TryGetValue(key, out var value))
						{
							value = (dictionary[key] = new List<int>());
						}
						value.Add(item4.Id);
					}
				}
				foreach (KeyValuePair<int, List<int>> item5 in dictionary)
				{
					if (hashSet.Contains(item5.Key) || item5.Value.Count >= 2)
					{
						_adding.AddRange(item5.Value);
					}
				}
			}
			try
			{
				Globals.Core.Actions.UseItem(_ust, 0);
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
				return false;
			}
			if (_log != null)
			{
				_log("SALV  opening the ust for " + Waiting.Count + " item(s), " + (_adding.Count - Waiting.Count) + " partial bag(s)");
			}
			_state = State.Opening;
			_until = now.AddMilliseconds(Tuning.V("SalvOpenMs"));
			Status = "opening the ust";
			return true;
		}
		if (now < _until)
		{
			return true;
		}
		switch (_state)
		{
		case State.Opening:
			_addIdx = 0;
			_state = State.Adding;
			break;
		case State.Adding:
			if (_addIdx < _adding.Count)
			{
				try
				{
					Globals.Core.Actions.SalvagePanelAdd(_adding[_addIdx]);
				}
				catch (Exception ex2)
				{
					Util.LogError(ex2);
				}
				_addIdx++;
				_until = now.AddMilliseconds(Tuning.V("SalvAddMs"));
				Status = "adding " + _addIdx + "/" + _adding.Count;
			}
			else
			{
				try
				{
					Globals.Core.Actions.SalvagePanelSalvage();
				}
				catch (Exception ex3)
				{
					Util.LogError(ex3);
				}
				_state = State.Salvaging;
				_until = now.AddMilliseconds(Tuning.V("SalvDoMs"));
				Status = "salvaging";
			}
			break;
		case State.Salvaging:
			try
			{
				Globals.Core.Actions.UseItem(_ust, 0);
			}
			catch
			{
			}
			_state = State.Closing;
			_until = now.AddMilliseconds(Tuning.V("SalvCloseMs"));
			break;
		case State.Closing:
		{
			int id2 = Globals.Core.CharacterFilter.Id;
			int num2 = 0;
			foreach (int item6 in new List<int>(Waiting))
			{
				if (!Mine(Globals.Core.WorldFilter[item6], id2))
				{
					Waiting.Remove(item6);
					_tries.Remove(item6);
					continue;
				}
				_tries.TryGetValue(item6, out var value2);
				value2 = (_tries[item6] = value2 + 1);
				if (value2 >= 2)
				{
					Waiting.Remove(item6);
					_tries.Remove(item6);
					Util.WriteToChat("Salvage: couldn't salvage " + Globals.Core.WorldFilter[item6].Name + " - left in your pack.");
				}
				else
				{
					num2++;
				}
			}
			Save();
			if (_log != null)
			{
				_log("SALV  done" + ((num2 > 0) ? (", " + num2 + " to try again") : ""));
			}
			Status = ((num2 > 0) ? (num2 + " to try again") : "");
			_state = State.Idle;
			_nextTry = now.AddSeconds((num2 > 0) ? 10 : 2);
			return false;
		}
		}
		return true;
	}
}
