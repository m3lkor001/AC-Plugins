using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
#if !RETAIL
using ACGodot.DecalShim;
using ACGodot.Plugins;
using ACGodot.UI;
#endif
#if !RETAIL
using AcClient;
#else
using SmartBox = AcClient.SmartBox;
using ACCmdInterp = AcClient.ACCmdInterp;
using CommandInterpreter = AcClient.CommandInterpreter;
using CommandListElement = AcClient.CommandListElement;
using CPhysicsObj = AcClient.CPhysicsObj;
using Position = AcClient.Position;
using CTransition = AcClient.CTransition;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
#if !RETAIL
using Godot;
#endif
using ImGuiNET;
using MelkTank.Loot;
using MelkTank.Metas;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public partial class Nav
{
#if RETAIL
	private unsafe static bool Motion(uint motion, bool on)
	{
		try
		{
			SmartBox** smartbox = SmartBox.smartbox;
			if (smartbox == null)
			{
				return false;
			}
			SmartBox* ptr = *smartbox;
			if (ptr == null || ptr->cmdinterp == null)
			{
				return false;
			}
			((ACCmdInterp*)ptr->cmdinterp)->SetMotion(motion, on);
			return true;
		}
		catch
		{
			return false;
		}
	}
#else
	private static bool Motion(uint motion, bool on)
	{
		ACGodot.Plugins.PluginHost host = Bridge.Host;
		if (host?.Player == null)
		{
			return false;
		}
		int num = motion switch
		{
			1694498831u => 32, 
			1694498832u => 16, 
			1694498829u => 8, 
			1694498830u => 4, 
			1157627910u => 2, 
			1157627909u => 1, 
			_ => 0, 
		};
		if (num == 0)
		{
			return false;
		}
		host.NavKeys = (on ? (host.NavKeys | num) : (host.NavKeys & ~num));
		return true;
	}
#endif

	private void WantHeading(double want)
	{
		_steerWant = want;
		_steerWantAt = DateTime.Now;
	}

	private void ReleaseTurn()
	{
		if (_turning != 0)
		{
			Motion((_turning * _turnSign > 0) ? 1694498829u : 1694498830u, on: false);
			_turning = 0;
		}
	}

	private static readonly bool HeadingSteer = true;

	public void SteerFrame()
	{
		try
		{
			if (!KeySteer || !_running || !_moving || _steerWant < 0.0 || (DateTime.Now - _steerWantAt).TotalMilliseconds > 600.0)
			{
				ReleaseTurn();
				return;
			}
			double num = CombatEngine.MyHeading();
			if (num < 0.0)
			{
				ReleaseTurn();
				return;
			}
			double num2 = ((_steerWant - num) % 360.0 + 540.0) % 360.0 - 180.0;
			// ACGodot: steered by the heading wanted, which the client turns to at its own pace and stops on exactly -
			// held turn keys, let go only at the next tick, swung past it and back (the run to a point or a corpse
			// went left-right-left)
			if (HeadingSteer)
			{
				ReleaseTurn();
				if (Math.Abs(num2) > 1.0)
				{
					try
					{
						Globals.Core.Actions.FaceHeading(_steerWant, true);
					}
					catch
					{
					}
				}
				return;
			}
			double num3 = Math.Max(1f, _s.NavSteerDeadband);
			int num4 = ((_turning == 0) ? ((!(Math.Abs(num2) <= num3)) ? ((num2 > 0.0) ? 1 : (-1)) : 0) : (((_turning <= 0 || !(num2 < 0.0)) && (_turning >= 0 || !(num2 > 0.0)) && !(Math.Abs(num2) <= 1.0)) ? _turning : 0));
			if (num4 == _turning)
			{
				if (num4 != 0 && (DateTime.Now - _turnStartAt).TotalMilliseconds > 400.0 && Math.Abs(num2) > Math.Abs(_turnStartDiff) + 20.0)
				{
					ReleaseTurn();
					_turnSign = -_turnSign;
					L("steer: turning made it worse (" + _turnStartDiff.ToString("0") + " -> " + num2.ToString("0") + " deg) - left / right swapped");
				}
				return;
			}
			ReleaseTurn();
			if (num4 == 0)
			{
				return;
			}
			if (!Motion((num4 * _turnSign > 0) ? 1694498829u : 1694498830u, on: true))
			{
				_motionBroken = true;
				L("steer: the client turn call isn't available - using turn-to-heading as before");
				return;
			}
			_turning = num4;
			_turnStartDiff = num2;
			_turnStartAt = DateTime.Now;
			if (_steerLogs < 40 && Math.Abs(num2) > 10.0)
			{
				_steerLogs++;
				L("steer: holding " + ((num4 > 0) ? "right" : "left") + " for " + Math.Abs(num2).ToString("0") + " deg");
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			ReleaseTurn();
		}
	}

	public string SyncRouteFile(string rel, string op, string oldName)
	{
		string path = Path.Combine(NavDir, (rel ?? "").Replace('/', '\\').TrimStart('\\'));
		Func<NavRoute, bool> same = (NavRoute x) => (!string.IsNullOrEmpty(x.File) && string.Equals(Path.GetFullPath(x.File), Path.GetFullPath(path), StringComparison.OrdinalIgnoreCase)) || (!string.IsNullOrEmpty(oldName) && string.Equals(x.Name, oldName, StringComparison.OrdinalIgnoreCase));
		if (op == "deleted")
		{
			int num = _s.NavRoutes.RemoveAll((NavRoute x) => same(x));
			return (num > 0) ? ("route " + (oldName ?? rel) + " removed") : ("no route for " + rel);
		}
		NavRoute nr = LoadRouteFile(path);
		if (nr == null)
		{
			return "couldn't read " + rel;
		}
		nr.File = path;
		int num2 = _s.NavRoutes.FindIndex((NavRoute x) => same(x) || string.Equals(x.Name, nr.Name, StringComparison.OrdinalIgnoreCase));
		bool flag = num2 >= 0 && string.Equals(_s.NavRouteSelected, _s.NavRoutes[num2].Name, StringComparison.OrdinalIgnoreCase);
		if (num2 >= 0)
		{
			_s.NavRoutes[num2] = nr;
		}
		else
		{
			_s.NavRoutes.Add(nr);
		}
		if (flag)
		{
			_s.NavRouteSelected = nr.Name;
			if (_rIdx >= nr.Steps.Count)
			{
				RouteReset();
			}
			_rSubFor = -1;
			_rSub = 0;
		}
		_treeAt = DateTime.MinValue;
		return "route " + nr.Name + ((num2 >= 0) ? " updated" : " added") + " (" + nr.Steps.Count + " steps)";
	}

	public string SyncMetaFile(string name)
	{
		if (_meta == null || string.IsNullOrEmpty(_meta.File))
		{
			return "no meta loaded";
		}
		if (!string.Equals(Path.GetFileNameWithoutExtension(_meta.File), (name ?? "").Trim(), StringComparison.OrdinalIgnoreCase))
		{
			return "meta " + name + " isn't the one loaded";
		}
		try
		{
			string metaState = _metaState;
			Meta meta = (_meta = Meta.Load(_meta.File));
			_metaEdit = -1;
			_metaState = (meta.States().Contains(metaState) ? metaState : meta.States()[0]);
			Util.WriteToChat("Meta: " + meta.Name + " read again (changed on the phone) - " + meta.Rules.Count + " rules, state " + _metaState + ".");
			return "meta " + meta.Name + " reloaded";
		}
		catch (Exception ex)
		{
			return "couldn't read " + name + ": " + ex.Message;
		}
	}

	public void ToggleTools()
	{
		try
		{
			if (_toolsHud == null)
			{
				_toolsHud = UBService.Huds.CreateHud("MelkTank Route tools", BarIcon.Make("Rte"));
				_toolsHud.ShowInBar = false;
				_toolsHud.WindowSettings = ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoCollapse | ImGuiWindowFlags.AlwaysAutoResize;
				_toolsHud.OnRender += OnToolsRender;
				_toolsHud.Visible = true;
			}
			else
			{
				_toolsHud.Visible = !_toolsHud.Visible;
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public void DisposeTools()
	{
		try
		{
			if (_toolsHud != null)
			{
				_toolsHud.OnRender -= OnToolsRender;
				_toolsHud.Dispose();
			}
		}
		catch
		{
		}
		_toolsHud = null;
	}

	private void OnToolsRender(object sender, EventArgs e)
	{
		try
		{
			WinMem.Frame("Route tools", size: false);
			bool flag = false;
			NavRoute currentRoute = CurrentRoute;
			if (currentRoute == null || _s.NavMode != 1)
			{
				Im.TextColored(Grey, "Pick a route on Nav > Routes (Follow a route).");
				CloseButton();
				return;
			}
			Im.TextColored(Cyan, currentRoute.Name);
			ImGui.SameLine();
			Im.TextColored(Grey, (_rSel >= 0 && _rSel < currentRoute.Steps.Count) ? ("- adds after step " + (_rSel + 1)) : ("- adds at the end (" + currentRoute.Steps.Count + " steps)"));
			if (ImGui.Button("Add point here", new System.Numerics.Vector2(130f, 0f)))
			{
				RouteStep routeStep = NewPointHere(StepKind.Point);
				Insert(currentRoute, routeStep);
				if (_recording && routeStep != null)
				{
					_recNS = routeStep.NS;
					_recEW = routeStep.EW;
				}
				flag = true;
			}
			ImGui.SameLine();
			if (!_recording)
			{
				if (ImGui.Button("Record##trec", new System.Numerics.Vector2(70f, 0f)))
				{
					StartRecording(currentRoute);
					flag = true;
				}
			}
			else
			{
				ImGui.PushStyleColor(ImGuiCol.Button, new System.Numerics.Vector4(0.7f, 0.15f, 0.15f, 1f));
				if (ImGui.Button("Stop##trec", new System.Numerics.Vector2(70f, 0f)))
				{
					StopRecording();
					flag = true;
				}
				ImGui.PopStyleColor();
			}
			ImGui.SameLine();
			ImGui.SetNextItemWidth(80f);
			ImGui.InputFloat("m##trecm", ref _recEvery, 1f, 5f, "%.0f");
			if (_recEvery < 2f)
			{
				_recEvery = 2f;
			}
			if (_recEvery > 100f)
			{
				_recEvery = 100f;
			}
			if (_recording)
			{
				ImGui.SameLine();
				Im.TextColored(Yellow, "recording...");
			}
			if (ImGui.Button("Add portal / NPC", new System.Numerics.Vector2(130f, 0f)))
			{
				RouteStep routeStep2 = UseStepFromSelection();
				if (routeStep2 != null)
				{
					Insert(currentRoute, routeStep2);
					flag = true;
				}
			}
			ImGui.SameLine();
			Im.TextColored(Grey, "the one you have selected");
			if (ImGui.Button("Add wait", new System.Numerics.Vector2(130f, 0f)))
			{
				Insert(currentRoute, new RouteStep
				{
					Kind = StepKind.Wait,
					WaitMs = _rWaitSecs * 1000
				});
				flag = true;
			}
			ImGui.SameLine();
			ImGui.SetNextItemWidth(80f);
			ImGui.InputInt("s##twait", ref _rWaitSecs, 1, 5);
			if (_rWaitSecs < 0)
			{
				_rWaitSecs = 0;
			}
			List<string> list = NavPresets.Names();
			if (list.Count == 0)
			{
				ImGui.BeginDisabled();
				ImGui.Button("Add preset##tpre", new System.Numerics.Vector2(130f, 0f));
				ImGui.EndDisabled();
				ImGui.SameLine();
				Im.TextColored(Grey, "make one on the Presets tab");
			}
			else
			{
				if (_rPresetPick >= list.Count)
				{
					_rPresetPick = 0;
				}
				if (ImGui.Button("Add preset##tpre", new System.Numerics.Vector2(130f, 0f)))
				{
					Insert(currentRoute, new RouteStep
					{
						Kind = StepKind.Preset,
						Text = list[_rPresetPick]
					});
					flag = true;
				}
				ImGui.SameLine();
				ImGui.SetNextItemWidth(160f);
				ImGui.Combo("##tpreset", ref _rPresetPick, list.ToArray(), list.Count);
			}
			CloseButton();
			if (flag)
			{
				RouteChanged();
				if (SaveAll != null)
				{
					SaveAll();
				}
			}
			SaveRouteFiles(now: false);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void CloseButton()
	{
		if (ImGui.SmallButton("Close##tclose") && _toolsHud != null)
		{
			_toolsHud.Visible = false;
		}
	}
}
