using System;
using System.Collections.Generic;
using System.Numerics;
using ImGuiNET;

namespace MelkTank.Pets;

public class PetTab
{
	private readonly Settings _s;

	private readonly Action _save;

	private readonly Action<bool> _setEnabled;

	private readonly Func<double> _attackRange;

	private string _addName = "";

	private static readonly Vector4 Cyan = new Vector4(0.35f, 0.85f, 0.95f, 1f);

	private static readonly Vector4 Red = new Vector4(0.95f, 0.35f, 0.35f, 1f);

	private static readonly Vector4 Green = new Vector4(0.45f, 0.9f, 0.45f, 1f);

	private static readonly Vector4 Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f);

	private static readonly Vector4 Yellow = new Vector4(0.95f, 0.85f, 0.35f, 1f);

	private static readonly string[] ElementNames = new string[9] { "None", "Nether / Void", "Bludgeon / Blunt", "Slash / Blade", "Pierce", "Fire", "Cold", "Acid", "Lightning" };

	private int _dexOpen;

	private string _dexFind = "";

	private static readonly string[] LensNames = new string[3] { "Flawed Siphon Lens (5-10%)", "Pristine Siphon Lens (5-20%)", "Perfect Siphon Lens (5-30%)" };

	public PetTab(Settings s, Action save, Action<bool> setEnabled, Func<double> attackRange)
	{
		_s = s;
		_save = save;
		_setEnabled = setEnabled;
		_attackRange = attackRange;
	}

	private static void Tip(string t)
	{
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip(t);
		}
	}

	public void Draw()
	{
		PetSummoner current = PetSummoner.Current;
		if (current == null)
		{
			Im.TextDisabled("Not logged in.");
			return;
		}
		DrawBar(current);
		if (PetSummoner.ExternalLoaded)
		{
			Im.TextColored(Red, "The separate MelksPetSummoner plugin is still loaded, so this tab does nothing. Untick it in Decal and relog.");
		}
		ImGui.Separator();
		if (ImGui.BeginTabBar("pettabs"))
		{
			if (ImGui.BeginTabItem("Pets"))
			{
				DrawPets(current);
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Echoes"))
			{
				DrawEchoes(current);
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Dex"))
			{
				DrawDex();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Breed"))
			{
				Breeding.Current?.Draw();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Settings###petsettings"))
			{
				DrawSettings(current);
				ImGui.EndTabItem();
			}
			ImGui.EndTabBar();
		}
	}

	private void DrawBar(PetSummoner p)
	{
		bool melksPetEnabled = _s.MelksPetEnabled;
		ImGui.PushStyleColor(ImGuiCol.Button, melksPetEnabled ? new Vector4(0.15f, 0.55f, 0.2f, 1f) : new Vector4(0.55f, 0.15f, 0.15f, 1f));
		if (ImGui.Button(melksPetEnabled ? "Pet summoning: ON " : "Pet summoning: OFF", new Vector2(160f, 0f)))
		{
			_setEnabled(!melksPetEnabled);
		}
		ImGui.PopStyleColor();
		Tip("Same switch as 'Enable Pet Summoning' on the Main tab and 'Summon' on the mini panel.\n/mt summon on|off");
		ImGui.SameLine();
		if (ImGui.Button("Summon now"))
		{
			p.SummonNow();
		}
		Tip("Summons a pet now, with summoning on or off: the only ticked one, else the one for the nearest monster,\nelse the one used last.");
		ImGui.SameLine();
		if (ImGui.Button("Dismiss"))
		{
			p.UnsummonNow();
		}
		ImGui.SameLine();
		string text = PluginCore.PetRange().ToString("0") + " m";
		Im.TextColored(p.Enabled ? Green : Grey, (p.Enabled ? "On" : ((_s.MelksPetEnabled && !_s.MasterEnabled) ? "MelkTank is off" : "Off")) + "  -  range " + text + "  -  " + (p.AnyOut ? ("pet out (" + PetSummoner.TankStatus() + ")") : ("no pet out" + ((Breeding.Current?.HoldSummons ?? false) ? " - held for breeding (Breed tab: Done)" : (p.Enabled && p.Idle.Length > 0 ? " - " + p.Idle : "")))));
		ImGui.SameLine();
		Im.TextColored(Grey, "   ES " + p.SpiritCount + "   echoes " + p.EchoCount.ToString("N0") + " (" + p.EchoRate + "/hr)");
	}

	private void DrawPets(PetSummoner p)
	{
		ImGui.SetNextItemWidth(260f);
		bool flag = ImGui.InputTextWithHint("##petadd", "part of the name (or leave empty: the selected item)", ref _addName, 128u, ImGuiInputTextFlags.EnterReturnsTrue);
		ImGui.SameLine();
		if (ImGui.Button("Add") | flag)
		{
			p.Add(_addName);
			_addName = "";
		}
		Tip("Adds a pet essence from your pack: the first one whose name has this in it, or with the box empty, the item\nselected in your pack.");
		List<PetRecord> pets = p.Pets;
		if (pets.Count == 0)
		{
			Im.TextDisabled("No pets yet - select a pet essence in your pack and click Add.");
			return;
		}
		ImGuiTableFlags flags = ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY;
		if (!ImGui.BeginTable("petlist", 7, flags, new Vector2(0f, 0f)))
		{
			return;
		}
		ImGui.TableSetupColumn("On", ImGuiTableColumnFlags.WidthFixed, 26f);
		ImGui.TableSetupColumn("Pet", ImGuiTableColumnFlags.WidthStretch);
		ImGui.TableSetupColumn("Uses", ImGuiTableColumnFlags.WidthFixed, 40f);
		ImGui.TableSetupColumn("Status", ImGuiTableColumnFlags.WidthFixed, 80f);
		ImGui.TableSetupColumn("Bond", ImGuiTableColumnFlags.WidthFixed, 44f);
		ImGui.TableSetupColumn("Element", ImGuiTableColumnFlags.WidthFixed, 100f);
		ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 26f);
		ImGui.TableSetupScrollFreeze(0, 1);
		ImGui.TableHeadersRow();
		PetRecord petRecord = null;
		foreach (PetRecord item in pets)
		{
			ImGui.PushID(item.DeviceId);
			ImGui.TableNextRow();
			ImGui.TableSetColumnIndex(0);
			bool v = item.Enabled;
			if (ImGui.Checkbox("##en", ref v))
			{
				p.ToggleEnabled(item);
			}
			ImGui.TableSetColumnIndex(1);
			Im.TextColored(p.IsOut(item) ? Green : Cyan, item.Name);
			ImGui.TableSetColumnIndex(2);
			ImGui.TextUnformatted((item.UsesRemaining >= 0) ? item.UsesRemaining.ToString() : "?");
			ImGui.TableSetColumnIndex(3);
			string text = p.StatusOf(item);
			Vector4 col;
			if (text == "Out")
			{
				col = Green;
			}
			else if (text.StartsWith("Recharg"))
			{
				col = Yellow;
			}
			else
			{
				col = ((text == "Not in pack") ? Red : Grey);
			}
			Im.TextColored(col, text);
			ImGui.TableSetColumnIndex(4);
			ImGui.TextUnformatted((item.BondLevel > 0) ? item.BondLevel.ToString() : "?");
			ImGui.TableSetColumnIndex(5);
			int current_item = (int)item.Element;
			ImGui.SetNextItemWidth(-1f);
			if (ImGui.Combo("##el", ref current_item, ElementNames, ElementNames.Length))
			{
				p.SetElement(item, (DamageElement)current_item);
			}
			ImGui.TableSetColumnIndex(6);
			if (ImGui.SmallButton("X"))
			{
				petRecord = item;
			}
			Tip("Remove " + item.Name + " from the list (a pet that's out is dismissed first).");
			ImGui.PopID();
		}
		ImGui.EndTable();
		if (petRecord != null)
		{
			p.Remove(petRecord);
		}
	}

	private void DrawEchoes(PetSummoner p)
	{
		Im.Text("Savage Echoes: " + p.EchoCount.ToString("N0") + "   (" + p.EchoRate + "/hr)");
		ImGui.SameLine();
		if (ImGui.SmallButton("Reset /hr"))
		{
			p.ResetEchoRate();
		}
		ImGui.SameLine();
		if (ImGui.Button("Apply Echoes"))
		{
			p.ApplyEchoes();
		}
		Tip("Applies Savage Echoes to the pet picked below (the next potency level costs (level) x 20).");
		List<PetRecord> pets = p.Pets;
		if (!ImGui.BeginTable("echolist", 4, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY, new Vector2(0f, 0f)))
		{
			return;
		}
		ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 26f);
		ImGui.TableSetupColumn("Pet", ImGuiTableColumnFlags.WidthStretch);
		ImGui.TableSetupColumn("Potency", ImGuiTableColumnFlags.WidthFixed, 60f);
		ImGui.TableSetupColumn("Next costs", ImGuiTableColumnFlags.WidthFixed, 80f);
		ImGui.TableSetupScrollFreeze(0, 1);
		ImGui.TableHeadersRow();
		foreach (PetRecord item in pets)
		{
			ImGui.PushID(item.DeviceId);
			ImGui.TableNextRow();
			ImGui.TableSetColumnIndex(0);
			bool flag = p.SelectedEchoDeviceId == item.DeviceId;
			if (ImGui.RadioButton("##pick", flag))
			{
				p.SelectedEchoDeviceId = ((!flag) ? item.DeviceId : 0);
			}
			ImGui.TableSetColumnIndex(1);
			Im.TextColored(Cyan, item.Name);
			ImGui.TableSetColumnIndex(2);
			ImGui.TextUnformatted(item.PotencyApplied.ToString());
			int num = (item.PotencyApplied + 1) * 20;
			ImGui.TableSetColumnIndex(3);
			Im.TextColored((p.EchoCount >= num) ? Green : Grey, num.ToString("N0"));
			ImGui.PopID();
		}
		ImGui.EndTable();
	}

	private void DrawSettings(PetSummoner p)
	{
		bool flag = false;
		bool flag2 = false;
		Im.TextColored(Cyan, "Range");
		flag |= DrawRange(_s, _attackRange);
		flag2 |= ImGui.Checkbox("Dismiss the pet when nothing's in range", ref p.UnsummonOnClear);
		Im.SetTooltipIfHovered("A pet that's out is dismissed once no monster is in the summoning range.\n/mt dismiss on|off");
		ImGui.Spacing();
		Im.TextColored(Cyan, "When to summon");
		flag |= ImGui.Checkbox("Only summon while Combat is on", ref _s.PetOnlyInCombat);
		Im.SetTooltipIfHovered("/mt set PetOnlyInCombat on|off");
		flag |= ImGui.Checkbox("Summon before the fight only", ref _s.PetNoSummonInFight);
		Tip("No summons (or pet swaps) once a fight has started. The summoner looks " + Tuning.V("PetLeadM").ToString("0") + " m further out than the range\n(Tuning: 'Summon before the fight: look ahead') so the pet is out before the first cast.\n/mt set PetNoSummonInFight on|off");
		ImGui.Spacing();
		Im.TextColored(Cyan, "Recharge (Encapsulated Spirits: " + p.SpiritCount + ")");
		flag2 |= ImGui.Checkbox("Recharge below", ref p.RechargeEnabled);
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		if (ImGui.InputInt("uses##rechth", ref p.RechargeThreshold))
		{
			if (p.RechargeThreshold < 1)
			{
				p.RechargeThreshold = 1;
			}
			flag2 = true;
		}
		flag2 |= ImGui.Checkbox("Recharge even with monsters around", ref p.ForceRechargeInCombat);
		Tip("Off: it waits for nothing in range (or 90 s at most).");
		flag |= ImGui.Checkbox("Recharge between packs only", ref _s.PetRechargeBetweenPacks);
		Tip("Waits until the fight is over - even the 'after 90 s anyway' - so casting doesn't wait on it.\n/mt set PetRechargeBetweenPacks on|off");
		ImGui.Spacing();
		Im.TextColored(Cyan, "Chat");
		flag |= ImGui.Checkbox("Commas in pet damage", ref _s.PetDmgCommas);
		Tip("[Pet] hit lines show 12,345 instead of 12345 (the server's /ilt dmgformat doesn't reach pet damage).\n/mt set PetDmgCommas on|off");
		ImGui.SameLine();
		if (ImGui.Button("Echo notices (/echo-notify)"))
		{
			Util.Command("/echo-notify");
		}
		Tip("Sends /echo-notify: turns the server's Savage Echo notices off (or back on).");
		ImGui.Spacing();
		Im.TextColored(Cyan, "Pet-only monsters");
		string po = _s.PetOnlyMonsters ?? "";
		if (ImGui.InputTextMultiline("##petonly", ref po, 4000u, new Vector2(300f, 90f))) { _s.PetOnlyMonsters = po; flag = true; }
		Tip("Monsters only a pet can hurt, one name per line: shown as (Pet only) in Tracking, never attacked by MelkTank,\nand the pet is summoned for them even when 'only while Combat is on' would hold it back.");
		ImGui.Spacing();
		Im.TextColored(Cyan, "Bond level / potency");
		bool v = p.ForceIdEnabled;
		if (ImGui.Checkbox("Force ID (identify the pet essences now and then)", ref v))
		{
			p.SetForceId(v);
		}
		Tip("Bond level and potency are in the essence's description, which only comes once it's been identified.\nOn: asks the client to identify them (one every 20 s) - the same call UtilityBelt's assessor uses.");
		if (flag)
		{
			_save();
		}
		if (flag2)
		{
			p.Save();
		}
	}

	public static bool DrawRange(Settings s, Func<double> attackRange)
	{
		bool flag = ImGui.Checkbox("Use combat range##petcr", ref s.PetUseCombatRange);
		Tip("The pet summons for monsters within your attack range (Main tab) - including the smaller range while finishing looting.\n/mt set PetUseCombatRange on|off");
		ImGui.SameLine();
		if (s.PetUseCombatRange)
		{
			Im.TextColored(Grey, "(" + attackRange().ToString("0") + " m)");
		}
		else
		{
			ImGui.SetNextItemWidth(110f);
			flag |= ImGui.InputFloat("Pet range (m)##petrange", ref s.PetRange, 1f, 5f, "%.0f");
			Im.SetTooltipIfHovered("/mt set PetRange <number>");
			if (s.PetRange < 1f)
			{
				s.PetRange = 1f;
			}
			Tip("The pet summons for monsters within this distance.");
		}
		if (s.PetNoSummonInFight)
		{
			ImGui.SameLine();
			Im.TextColored(Grey, "+ " + Tuning.V("PetLeadM").ToString("0") + " m look-ahead");
		}
		return flag;
	}

	private void DrawDex()
	{
		if (ImGui.BeginTabBar("dextabs"))
		{
			if (ImGui.BeginTabItem("Main##dexmain"))
			{
				DrawDexMain();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Catch##dexcatch"))
			{
				DrawDexCatch();
				ImGui.EndTabItem();
			}
			ImGui.EndTabBar();
		}
	}

	private void DrawDexMain()
	{
		List<Dex.Species> book = Dex.Book;
		int num = 0;
		foreach (Dex.Species item in book)
		{
			num += item.Entries.Count;
		}
		if (book.Count == 0 && Dex.PetLog.Count == 0)
		{
			Im.TextDisabled("Nothing read yet - open the Monster-Dex, or press Read /pets.");
			if (ImGui.Button("Read /pets"))
			{
				Dex.AskPetLog();
			}
			return;
		}
		Im.Text("Pet Log: " + Dex.PetLog.Count + " pets   -   Monster-Dex: " + book.Count + " species");
		ImGui.SameLine();
		Im.TextColored(Grey, "   (/pets read " + ((Dex.PetLogAt == DateTime.MinValue) ? "never" : Dex.PetLogAt.ToString("MMM d HH:mm")) + ", book " + ((Dex.BookAt == DateTime.MinValue) ? "never" : Dex.BookAt.ToString("MMM d HH:mm")) + ")");
		ImGui.SameLine();
		if (ImGui.SmallButton("Read /pets"))
		{
			Dex.AskPetLog();
		}
		ImGui.SameLine();
		if (ImGui.SmallButton("Read the book"))
		{
			Dex.ReadBook();
		}
		Tip("Opens the Monster-Dex, saves its pages (each species and its monsters) and closes it again.\nDone by itself after a turn-in.");
		Tip("Asks the game for your Pet Log (/pets) - the list stays out of chat. Done by itself at login and after a turn-in.");
		if (ImGui.Button("Expand all"))
		{
			_dexOpen = 1;
		}
		ImGui.SameLine();
		if (ImGui.Button("Collapse all"))
		{
			_dexOpen = -1;
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(180f);
		ImGui.InputTextWithHint("##dexfind", "find a monster", ref _dexFind, 64u);
		int siphonedCount = Dex.SiphonedCount;
		if (siphonedCount > 0)
		{
			ImGui.SameLine();
			Im.TextColored(Yellow, "   " + siphonedCount + " siphoned essence" + ((siphonedCount == 1) ? "" : "s") + " waiting for Prof. Ruggan");
		}
		ImGuiTableFlags flags = ImGuiTableFlags.RowBg | ImGuiTableFlags.BordersInnerV | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY;
		if (!ImGui.BeginTable("dexbook", 3, flags, new Vector2(0f, 0f)))
		{
			_dexOpen = 0;
			return;
		}
		ImGui.TableSetupColumn("Species / Monster", ImGuiTableColumnFlags.WidthStretch);
		ImGui.TableSetupColumn("Normal", ImGuiTableColumnFlags.WidthFixed, 80f);
		ImGui.TableSetupColumn("Shiny", ImGuiTableColumnFlags.WidthFixed, 80f);
		ImGui.TableSetupScrollFreeze(0, 1);
		ImGui.TableHeadersRow();
		string text = (_dexFind ?? "").Trim();
		foreach (Dex.Species item2 in book)
		{
			bool flag = text.Length == 0 || item2.Name.IndexOf(text, StringComparison.OrdinalIgnoreCase) >= 0;
			if (!flag)
			{
				foreach (Dex.Entry entry in item2.Entries)
				{
					if (entry.Name.IndexOf(text, StringComparison.OrdinalIgnoreCase) >= 0)
					{
						flag = true;
						break;
					}
				}
			}
			if (!flag)
			{
				continue;
			}
			int num2 = 0;
			int num3 = 0;
			foreach (Dex.Entry entry2 in item2.Entries)
			{
				if (entry2.Normal || Dex.InPetLog(entry2.Name, shiny: false))
				{
					num2++;
				}
				if (entry2.Shiny || Dex.InPetLog(entry2.Name, shiny: true))
				{
					num3++;
				}
			}
			ImGui.TableNextRow();
			ImGui.TableSetColumnIndex(0);
			if (_dexOpen != 0)
			{
				ImGui.SetNextItemOpen(_dexOpen > 0);
			}
			else if (text.Length > 0)
			{
				ImGui.SetNextItemOpen(is_open: true);
			}
			bool flag2 = ImGui.TreeNodeEx(item2.Name + "##sp", ImGuiTreeNodeFlags.SpanFullWidth);
			ImGui.TableSetColumnIndex(1);
			Im.TextColored(Grey, num2 + "/" + item2.Entries.Count);
			ImGui.TableSetColumnIndex(2);
			Im.TextColored(Grey, num3 + "/" + item2.Entries.Count);
			if (!flag2)
			{
				continue;
			}
			foreach (Dex.Entry entry3 in item2.Entries)
			{
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				ImGui.Indent(18f);
				Im.Text(entry3.Name);
				ImGui.Unindent(18f);
				ImGui.TableSetColumnIndex(1);
				if (entry3.Normal || Dex.InPetLog(entry3.Name, shiny: false))
				{
					Im.TextColored(Green, "Caught");
				}
				else
				{
					Im.TextColored(Grey, "-");
				}
				ImGui.TableSetColumnIndex(2);
				if (entry3.Shiny || Dex.InPetLog(entry3.Name, shiny: true))
				{
					Im.TextColored(Yellow, "Caught");
				}
				else
				{
					Im.TextColored(Grey, "-");
				}
			}
			ImGui.TreePop();
		}
		HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		foreach (Dex.Species item3 in book)
		{
			foreach (Dex.Entry entry4 in item3.Entries)
			{
				hashSet.Add(entry4.Name);
			}
		}
		List<string> list = new List<string>();
		foreach (string item4 in Dex.PetLog)
		{
			string text2 = (item4.StartsWith("Shiny ", StringComparison.OrdinalIgnoreCase) ? item4.Substring(6) : item4);
			if (!hashSet.Contains(text2) && !list.Contains(text2) && (text.Length == 0 || text2.IndexOf(text, StringComparison.OrdinalIgnoreCase) >= 0))
			{
				list.Add(text2);
			}
		}
		list.Sort(StringComparer.OrdinalIgnoreCase);
		if (list.Count > 0)
		{
			ImGui.TableNextRow();
			ImGui.TableSetColumnIndex(0);
			if (_dexOpen != 0)
			{
				ImGui.SetNextItemOpen(_dexOpen > 0);
			}
			else if (text.Length > 0)
			{
				ImGui.SetNextItemOpen(is_open: true);
			}
			bool flag3 = ImGui.TreeNodeEx("New (Pet Log, not in the book yet)##spnew", ImGuiTreeNodeFlags.SpanFullWidth);
			ImGui.TableSetColumnIndex(1);
			Im.TextColored(Grey, list.Count.ToString());
			if (flag3)
			{
				foreach (string item5 in list)
				{
					ImGui.TableNextRow();
					ImGui.TableSetColumnIndex(0);
					ImGui.Indent(18f);
					Im.Text(item5);
					ImGui.Unindent(18f);
					ImGui.TableSetColumnIndex(1);
					if (Dex.InPetLog(item5, shiny: false))
					{
						Im.TextColored(Green, "Caught");
					}
					else
					{
						Im.TextColored(Grey, "-");
					}
					ImGui.TableSetColumnIndex(2);
					if (Dex.InPetLog(item5, shiny: true))
					{
						Im.TextColored(Yellow, "Caught");
					}
					else
					{
						Im.TextColored(Grey, "-");
					}
				}
				ImGui.TreePop();
			}
		}
		ImGui.EndTable();
		_dexOpen = 0;
	}

	private void DrawDexCatch()
	{
		bool flag = false;
		flag |= ImGui.Checkbox("Catch monsters I haven't caught yet", ref _s.DexCatch);
		Tip("With combat on: a monster that isn't in the Monster-Dex (normal, or the Shiny one) and isn't in your pack as a\nsiphoned essence gets caught - pet dismissed first, brought under 20% with the bats (Corruption I if it's huge),\nthen the lens. In T11 and up the fight goes on as usual and the lens goes on once it's under 20%\n(no Nether Fracture releases meanwhile).\n/mt set DexCatch on|off");
		flag |= ImGui.Checkbox("In T10 and up, try even if a pet is out", ref _s.DexPetT11);
		Tip("Ticked: in T11+ the pet stays out (and keeps being summoned) while catching - it does too little damage there to matter.\nElsewhere it's always dismissed first.\n/mt set DexPetT11 on|off");
		ImGui.SetNextItemWidth(70f);
		float v = _s.DexHoldPct;
		if (ImGui.InputFloat("% - T11+: stop everything once the monster is under this##dexhold", ref v, 0f, 0f, "%.0f"))
		{
			_s.DexHoldPct = Math.Max(20f, Math.Min(100f, v));
			flag = true;
		}
		Tip("In T11 and up the fight goes on while it's caught - until it's under this much health. Then nothing else is cast\n(no streaks on other monsters keeping you busy), its DoTs bring it down, and the lens goes on under 20%.\nBelow T11 everything is already stopped for the whole catch.");
		ImGui.SetNextItemWidth(70f);
		int v2 = _s.DexGiveUpSecs;
		if (ImGui.InputInt("s - give up and fight it normally when its health hasn't dropped for this long##dexgiveup", ref v2, 0, 0))
		{
			_s.DexGiveUpSecs = Math.Max(0, Math.Min(3600, v2));
			flag = true;
		}
		Tip("Below T11: if bats and Corruption haven't brought its health down for this many seconds (magic immune, too much health),\nit's left to the normal fight and that kind isn't tried again for 30 minutes. 0 = never give up.");
		Im.Text("Use the lens");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(80f);
		int v3 = _s.DexLensTries;
		if (ImGui.InputInt("times,##dexlt", ref v3, 1, 1))
		{
			_s.DexLensTries = Math.Max(1, Math.Min(10, v3));
			flag = true;
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		int v4 = _s.DexLensGapMs;
		if (ImGui.InputInt("ms apart, then wait##dexlg", ref v4, 100, 500))
		{
			_s.DexLensGapMs = Math.Max(100, v4);
			flag = true;
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		int v5 = _s.DexLensWaitMs;
		if (ImGui.InputInt("ms for an answer##dexlw", ref v5, 500, 1000))
		{
			_s.DexLensWaitMs = Math.Max(500, v5);
			flag = true;
		}
		Tip("When it's time, the lens goes on this many times this far apart (stopping as soon as the game answers -\ncaught, resisted, too strong...), then it waits this long for an answer before trying again.");
		ImGui.SetNextItemWidth(240f);
		flag |= ImGui.Combo("Lens##dexlens", ref _s.DexLens, LensNames, LensNames.Length);
		ImGui.SameLine();
		flag |= ImGui.Checkbox("Use this lens first", ref _s.DexLensFirst);
		Tip("Ticked: this lens until it runs out, then the next worse one (Perfect > Pristine > Flawed), then better ones.\nNot ticked: the cheapest lens you have first.\n/mt set DexLensFirst on|off");
		flag |= ImGui.Checkbox("Use Asheron's Lens (always catches)", ref _s.DexAsheron);
		Tip("Ticked: Asheron's Lens goes on before the others while you have any.\n/mt set DexAsheron on|off");
		ImGui.SameLine(0f, 16f);
		flag |= ImGui.Checkbox("Only on shinies##ashsh", ref _s.DexAsheronShiny);
		Tip("Ticked: Asheron's Lens is kept for shiny monsters - the others get the normal lenses.\n/mt set DexAsheronShiny on|off");
		flag |= ImGui.Checkbox("Use Resonant Lens (one more try after a fail)", ref _s.DexResonant);
		Tip("A failed try turns the monster Enraged - it can only be tried again after a Resonant Lens (once per monster),\nthen the lens above again.\n/mt set DexResonant on|off");
		ImGui.SameLine(0f, 16f);
		flag |= ImGui.Checkbox("Only on shinies##ressh", ref _s.DexResonantShiny);
		Tip("Ticked: the Resonant Lens is only used when a shiny gets away - a normal one that gets away is left Enraged.\n/mt set DexResonantShiny on|off");
		flag |= ImGui.Checkbox("Take off cast-on-strike gear before catching", ref _s.DexStripProcs);
		Tip("Necklaces, bracelets, rings and cloaks that cast on strike, and aetheria with Surge of Affliction, come off before\nthe bat comes out (a proc kills a little monster first) - and go back on in the same slots after the catch.\n/mt set DexStripProcs on|off");
		flag |= ImGui.Checkbox("Corruption I on very big monsters, over", ref _s.DexCorruption);
		Im.SetTooltipIfHovered("/mt set DexCorruption on|off");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(100f);
		int v6 = _s.DexCorruptionAbove;
		if (ImGui.InputInt("health##dexcorr", ref v6, 0, 0))
		{
			_s.DexCorruptionAbove = Math.Max(0, v6);
			flag = true;
		}
		Tip("Above this much health Corruption I is cast (again every 30 s) and its health watched closely;\nbelow it, the bonk bats.");
		flag |= ImGui.Checkbox("Essence Resonator on the hollows after a turn-in", ref _s.DexResonator);
		Tip("Only the Hollow essences that turn-in gave you.\n/mt set DexResonator on|off");
		ImGui.SetNextItemWidth(360f);
		string input = _s.DexSkip ?? "";
		if (ImGui.InputTextWithHint("Never catch##dexskip", "names, comma separated", ref input, 512u))
		{
			_s.DexSkip = input;
			flag = true;
		}
		if (flag)
		{
			_save();
		}
		ImGui.Separator();
		if (ImGui.Button("Catch selected"))
		{
			Dex.CatchSelected();
		}
		Tip("Catches the monster you have selected, even if it's been caught before, tried already or is on Never catch -\nalso with \"Catch monsters I haven't caught yet\" off. Same steps as any catch (pet dismissed, bats, lens).\nWorks with combat off (only MelkTank has to be on); the fight leaves it alone if you turn combat on meanwhile.\nStops a catch of another monster that's running.");
		ImGui.SameLine();
		if (ImGui.Button(Dex.TurnIn.Busy ? "Stop the turn-in" : "Go to Camp Ruggan and turn in"))
		{
			Dex.TurnIn.Start();
		}
		Tip("Uses the Camp Ruggan Portal gem, hands every Siphoned essence to Prof. Ruggan, puts the Essence Resonator\non the hollows that gave you (if ticked), then reads /pets so the Main tab is up to date.\nMelkTank does nothing else while it runs.");
		ImGui.SameLine();
		if (ImGui.Button("Resonator on main-pack hollows"))
		{
			Dex.TurnIn.ResonateMainPack();
		}
		Tip("Uses the Essence Resonator on every Hollow essence in your main pack (side packs are left alone).");
		ImGui.SameLine();
		Im.TextColored(Grey, Dex.SiphonedCount + " siphoned essence" + ((Dex.SiphonedCount == 1) ? "" : "s") + " in your pack");
		if (Dex.TurnIn.Busy)
		{
			Im.TextColored(Cyan, "Turn-in: " + Dex.TurnIn.Status);
		}
		ImGui.Separator();
		Vector4 cyan = Cyan;
		string text;
		if (string.IsNullOrEmpty(Dex.Status))
		{
			text = (_s.DexCatch ? "-" : "off");
		}
		else
		{
			text = Dex.Status;
		}
		Im.TextColored(cyan, "Now: " + text);
		Im.Text("This session: " + Dex.Tried + " tried, " + Dex.Caught + " caught, " + Dex.Enraged + " enraged (the lens went on but it resisted)");
		Im.Text("Lenses: Perfect " + Dex.Lens(Dex.Lenses[2]) + ", Pristine " + Dex.Lens(Dex.Lenses[1]) + ", Flawed " + Dex.Lens(Dex.Lenses[0]) + ", Resonant " + Dex.Lens("Resonant Lens") + ", Asheron's " + Dex.Lens("Asheron's Lens"));
		Im.TextColored(Grey, "Turn off auto-repeat attacks in AC's options - each bat swing is checked against its health first.");
	}
}
