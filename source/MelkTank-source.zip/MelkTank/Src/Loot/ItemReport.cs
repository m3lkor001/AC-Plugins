using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;
using Decal.Adapter.Wrappers;

namespace MelkTank.Loot;

public static class ItemReport
{
	private class TextInfo
	{
		public string Count;

		public string Grade;

		public readonly List<string> Wield = new List<string>();

		public readonly List<string> Lines = new List<string>();
	}

	private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

	private static readonly Dictionary<int, string> Materials = new Dictionary<int, string>
	{
		{ 1, "Ceramic" },
		{ 2, "Porcelain" },
		{ 4, "Linen" },
		{ 5, "Satin" },
		{ 6, "Silk" },
		{ 7, "Velvet" },
		{ 8, "Wool" },
		{ 10, "Agate" },
		{ 11, "Amber" },
		{ 12, "Amethyst" },
		{ 13, "Aquamarine" },
		{ 14, "Azurite" },
		{ 15, "Black Garnet" },
		{ 16, "Black Opal" },
		{ 17, "Bloodstone" },
		{ 18, "Carnelian" },
		{ 19, "Citrine" },
		{ 20, "Diamond" },
		{ 21, "Emerald" },
		{ 22, "Fire Opal" },
		{ 23, "Green Garnet" },
		{ 24, "Green Jade" },
		{ 25, "Hematite" },
		{ 26, "Imperial Topaz" },
		{ 27, "Jet" },
		{ 28, "Lapis Lazuli" },
		{ 29, "Lavender Jade" },
		{ 30, "Malachite" },
		{ 31, "Moonstone" },
		{ 32, "Onyx" },
		{ 33, "Opal" },
		{ 34, "Peridot" },
		{ 35, "Red Garnet" },
		{ 36, "Red Jade" },
		{ 37, "Rose Quartz" },
		{ 38, "Ruby" },
		{ 39, "Sapphire" },
		{ 40, "Smokey Quartz" },
		{ 41, "Sunstone" },
		{ 42, "Tiger Eye" },
		{ 43, "Tourmaline" },
		{ 44, "Turquoise" },
		{ 45, "White Jade" },
		{ 46, "White Quartz" },
		{ 47, "White Sapphire" },
		{ 48, "Yellow Garnet" },
		{ 49, "Yellow Topaz" },
		{ 50, "Zircon" },
		{ 51, "Ivory" },
		{ 52, "Leather" },
		{ 53, "Armoredillo Hide" },
		{ 54, "Gromnie Hide" },
		{ 55, "Reed Shark Hide" },
		{ 57, "Brass" },
		{ 58, "Bronze" },
		{ 59, "Copper" },
		{ 60, "Gold" },
		{ 61, "Iron" },
		{ 62, "Pyreal" },
		{ 63, "Silver" },
		{ 64, "Steel" },
		{ 66, "Alabaster" },
		{ 67, "Granite" },
		{ 68, "Marble" },
		{ 69, "Obsidian" },
		{ 70, "Sandstone" },
		{ 71, "Serpentine" },
		{ 73, "Ebony" },
		{ 74, "Mahogany" },
		{ 75, "Oak" },
		{ 76, "Pine" },
		{ 77, "Teak" }
	};

	private static readonly Dictionary<int, string> Skills = new Dictionary<int, string>
	{
		{ 1, "Axe" },
		{ 2, "Bow" },
		{ 3, "Crossbow" },
		{ 4, "Dagger" },
		{ 5, "Mace" },
		{ 6, "Melee Def" },
		{ 7, "Missile Def" },
		{ 9, "Spear" },
		{ 10, "Staff" },
		{ 11, "Sword" },
		{ 12, "Thrown" },
		{ 13, "Unarmed" },
		{ 14, "Arcane Lore" },
		{ 15, "Magic Def" },
		{ 16, "Mana Conv" },
		{ 31, "Creature" },
		{ 32, "Item" },
		{ 33, "Life" },
		{ 34, "War" },
		{ 41, "Two Handed" },
		{ 43, "Void" },
		{ 44, "Heavy" },
		{ 45, "Light" },
		{ 46, "Finesse" },
		{ 47, "Missile" },
		{ 48, "Shield" },
		{ 49, "Dual Wield" },
		{ 54, "Summoning" }
	};

	private static readonly string[] Attributes = new string[7] { "", "Str", "End", "Quick", "Coord", "Focus", "Self" };

	private static readonly Dictionary<int, string> Counters = new Dictionary<int, string>
	{
		{ 294, "Creature Augs" },
		{ 295, "Item Augs" },
		{ 296, "Life Augs" },
		{ 297, "War Augs" },
		{ 328, "Void Augs" },
		{ 9007, "Creature Augs" },
		{ 9008, "Life Augs" },
		{ 9009, "Item Augs" },
		{ 50000, "Triune Weave" },
		{ 50001, "Battlemage's Wrath" },
		{ 50002, "Nether Veil" },
		{ 50003, "Crashing Steel" },
		{ 50004, "True Shot" }
	};

	private static readonly string[][] ModShort = new string[24][]
	{
		new string[2] { "Crit Damage Resist", "CDR" },
		new string[2] { "Crit Damage Rating", "CD" },
		new string[2] { "Damage Resist", "DR" },
		new string[2] { "Damage Rating", "D" },
		new string[2] { "Crit Resist", "CR" },
		new string[2] { "Crit Chance", "Crit" },
		new string[2] { "Nether Resist", "NR" },
		new string[2] { "Max Health Pct", "HP%" },
		new string[2] { "Max Health", "HP" },
		new string[2] { "All Attributes", "Attr" },
		new string[2] { "Healing Boost", "Heal" },
		new string[2] { "Spell Duration", "SpellDur" },
		new string[2] { "Life on Hit", "LoH" },
		new string[2] { "Armor Level", "AL" },
		new string[2] { "Reinforced", "Reinf" },
		new string[2] { "Fortify Vitals", "FortVit" },
		new string[2] { "Pct HP Damage", "PctHP" },
		new string[2] { "Regeneration", "Regen" },
		new string[2] { "Biting Strike:", "BS" },
		new string[2] { "Crushing Blow:", "CB" },
		new string[2] { "Cast on Strike:", "CoS" },
		new string[2] { "Effective Melee Defense:", "MeleeD" },
		new string[2] { "Weapon Grade:", "Grade" },
		new string[2] { "Spell Armor Rend:", "SAR" }
	};

	private static readonly Dictionary<int, string> Elements = new Dictionary<int, string>
	{
		{ 1, "Slash" },
		{ 2, "Pierce" },
		{ 4, "Bludgeon" },
		{ 8, "Cold" },
		{ 16, "Fire" },
		{ 32, "Acid" },
		{ 64, "Lightning" },
		{ 1024, "Nether" }
	};

	private static readonly Regex Band = new Regex("\\s*\\[(\\d[^\\]]*)\\]");

	private static readonly Regex PctOf = new Regex("^(\\S+)\\s*\\((\\d+%)");

	public static int LauncherDamageBonus(WorldObject o)
	{
		return LootMatcher.Long(o, 218103842);
	}

	public static int LauncherElemental(WorldObject o)
	{
		return LootMatcher.Long(o, 204);
	}

	public static double LauncherDamageMod(WorldObject o)
	{
		return LootMatcher.Dbl(o, 167772174);
	}

	public static List<string> LauncherStats(WorldObject o)
	{
		List<string> list = new List<string>();
		int num = LauncherDamageBonus(o);
		int num2 = LauncherElemental(o);
		double num3 = LauncherDamageMod(o);
		if (num > 0)
		{
			list.Add("Damage Bonus +" + num.ToString("N0", Inv));
		}
		if (num2 != 0)
		{
			list.Add("Elemental Dmg +" + num2);
		}
		if (num3 > 0.0)
		{
			list.Add("Damage Mod " + MultPct(num3));
		}
		return list;
	}

	public static string MultPct(double m)
	{
		double num = (m - 1.0) * 100.0;
		return ((num >= 0.0) ? "+" : "") + num.ToString("0.#", CultureInfo.InvariantCulture) + "%";
	}

	public static string FullName(WorldObject o)
	{
		if (o == null)
		{
			return "";
		}
		string text = o.Name ?? "";
		try
		{
			if (Materials.TryGetValue(LootMatcher.Long(o, 131), out var value) && !text.StartsWith(value, StringComparison.OrdinalIgnoreCase))
			{
				text = value + " " + text;
			}
		}
		catch
		{
		}
		return text;
	}

	public static string Describe(WorldObject o, UtlRule rule)
	{
		return Describe(o, rule, link: false);
	}

	public static string Describe(WorldObject o, UtlRule rule, bool link)
	{
		List<string> list = new List<string>();
		ObjectClass objectClass = o.ObjectClass;
		bool flag = objectClass == ObjectClass.MeleeWeapon || objectClass == ObjectClass.MissileWeapon || objectClass == ObjectClass.WandStaffOrb;
		string text = o.Name ?? "?";
		if (Materials.TryGetValue(LootMatcher.Long(o, 131), out var value) && !text.StartsWith(value, StringComparison.OrdinalIgnoreCase))
		{
			text = value + " " + text;
		}
		if (flag)
		{
			int num = LootMatcher.Long(o, 45);
			if (num == 0)
			{
				num = LootMatcher.Long(o, 218103841);
			}
			if (Elements.TryGetValue(num, out var value2))
			{
				text = text + " (" + value2 + ")";
			}
		}
		string text2 = ((rule != null && rule.Name.Trim().Length > 0) ? (rule.Name.Trim() + " - ") : "") + text;
		list.Add(link ? ("<Tell:IIDString:" + o.Id + ":" + text + ">" + text2 + "<\\Tell>") : text2);
		bool flag2 = (LootMatcher.Long(o, 218103822) & 0x8000000) != 0;
		if (flag2)
		{
			int num2 = LootMatcher.Long(o, 319);
			if (num2 > 0)
			{
				list.Add("Lvl " + num2);
			}
			if (LootMatcher.Long(o, 352) == 2)
			{
				list.Add("200 Dmg Reduction");
			}
			List<string> list2 = SpellNames.Of(o);
			if (list2.Count > 0)
			{
				list.Add(string.Join(", ", list2.ToArray()));
			}
		}
		int num3 = LootMatcher.Long(o, 218103822) & 0x70000000;
		string text3 = (o.Name ?? "").Trim();
		bool flag3 = text3.Equals("Aetheria", StringComparison.OrdinalIgnoreCase) || text3.EndsWith(" Aetheria", StringComparison.OrdinalIgnoreCase);
		if (!flag2 && ((num3 != 0) | flag3))
		{
			string text4;
			if ((num3 & 0x10000000) != 0)
			{
				text4 = "Blue";
			}
			else if ((num3 & 0x20000000) != 0)
			{
				text4 = "Yellow";
			}
			else
			{
				text4 = (((num3 & 0x40000000) != 0) ? "Red" : null);
			}
			int num4 = LootMatcher.Long(o, 218103809);
			int num5 = LootMatcher.Long(o, 218103849);
			if (text4 == null)
			{
				text4 = num4 switch
				{
					27660 => "Yellow", 
					27659 => "Red", 
					27658 => "Blue", 
					_ => null, 
				};
			}
			if (text4 == null)
			{
				string[] array = new string[3] { "Blue", "Yellow", "Red" };
				foreach (string text5 in array)
				{
					if ((o.Name ?? "").IndexOf(text5, StringComparison.OrdinalIgnoreCase) >= 0)
					{
						text4 = text5;
						break;
					}
				}
			}
			int num6 = LootMatcher.Long(o, 319);
			if (num6 <= 0 && num5 >= 27700 && num5 <= 27709)
			{
				num6 = num5 - 27699;
			}
			string text6 = text4 + ((num6 > 0) ? (((text4 != null) ? " " : "") + "Lvl " + num6) : "");
			if (text6.Length > 0)
			{
				list.Add(text6);
			}
		}
		TextInfo textInfo = Read(LootMatcher.Str(o, 16), LootMatcher.Str(o, 14));
		if (flag)
		{
			string text7 = ItemCompare.LooksBuffed(o);
			if (text7 != null)
			{
				list.Add("BUFFED (" + text7 + " - updating with a fresh ID)");
			}
			double num7 = LootMatcher.Dbl(o, 152);
			double num8 = LootMatcher.Dbl(o, 29);
			double num9 = LootMatcher.Dbl(o, 144);
			double num10 = LootMatcher.Dbl(o, 149);
			double num11 = LootMatcher.Dbl(o, 150);
			double num12 = LootMatcher.Dbl(o, 167772172);
			if (num7 > 1.0)
			{
				list.Add("+" + Pct(num7) + "% vs. Monsters");
			}
			if (num8 > 1.0)
			{
				list.Add(Pct1(num8) + "%md");
			}
			if (num12 > 1.0)
			{
				list.Add(Pct1(num12) + "%as");
			}
			if (num10 > 1.0)
			{
				list.Add(Pct1(num10) + "%msd");
			}
			if (num11 > 1.0)
			{
				list.Add(Pct1(num11) + "%mgd");
			}
			if (objectClass != ObjectClass.WandStaffOrb && (LootMatcher.Long(o, 47) & 0x79E0) != 0)
			{
				list.Add("Multi-Strike");
			}
			if (num9 > 1.0)
			{
				list.Add(Pct(num9) + "%mc");
			}
			bool flag4 = objectClass == ObjectClass.MissileWeapon && !ItemInfo.IsAmmo(o);
			if (objectClass != ObjectClass.WandStaffOrb && !flag4)
			{
				int num13 = LootMatcher.Long(o, 218103842);
				if (num13 > 0)
				{
					list.Add("Dmg " + Math.Round((double)num13 * (1.0 - LootMatcher.Dbl(o, 167772171))) + "-" + num13);
				}
			}
			if (objectClass == ObjectClass.MissileWeapon && !ItemInfo.IsAmmo(o))
			{
				foreach (string item in LauncherStats(o))
				{
					list.Add(item);
				}
			}
		}
		List<string> list3 = SpellNames.Of(o);
		if (list3.Count > 0 && !flag2)
		{
			list.Add(string.Join(", ", list3.ToArray()));
		}
		if (LootMatcher.Dbl(o, 159) > 0.0)
		{
			list.Add("Magic Absorb");
		}
		if (LootMatcher.Long(o, 36) >= 9999)
		{
			list.Add("Unenchantable");
		}
		string text8 = ((textInfo.Wield.Count > 0) ? string.Join(" + ", textInfo.Wield.ToArray()) : Wield(o));
		if (text8.Length > 0)
		{
			list.Add("Wield " + text8);
		}
		int num14 = LootMatcher.Long(o, 105);
		if (num14 > 0)
		{
			list.Add("Craft " + num14);
		}
		int num15 = LootMatcher.Long(o, 19);
		if (num15 > 0)
		{
			list.Add("Value " + num15.ToString("N0", Inv));
		}
		int num16 = LootMatcher.Long(o, 5);
		if (num16 > 0)
		{
			list.Add("BU " + num16.ToString("N0", Inv));
		}
		int num17 = LootMatcher.Long(o, 28);
		if (num17 > 0)
		{
			list.Add("AL " + num17);
		}
		if (textInfo.Count != null || textInfo.Grade != null || textInfo.Lines.Count > 0)
		{
			List<string> list4 = new List<string>(textInfo.Lines);
			string text9;
			if (flag)
			{
				text9 = "Details" + ((textInfo.Count != null) ? (" " + textInfo.Count) : "");
				if (textInfo.Grade != null)
				{
					list4.Insert(0, "Grade " + textInfo.Grade);
				}
			}
			else
			{
				text9 = "Mods" + ((textInfo.Count != null) ? (" " + textInfo.Count) : "") + ((textInfo.Grade != null) ? (" Grade " + textInfo.Grade) : "");
			}
			list.Add(text9 + ((list4.Count > 0) ? (" [" + string.Join(", ", list4.ToArray()) + "]") : ""));
		}
		else if (flag && LootMatcher.Long(o, 9060) > 0)
		{
			list.Add("Grade " + Grade(LootMatcher.Long(o, 9060)));
		}
		List<string> list5 = new List<string>();
		// (a pet's essence: its combat ratings as its description gives them - base and mutations added up. The item's own
		// rating numbers are the base alone, and one it carries (crit damage resist) shows nowhere in the game)
		string petDesc = LootMatcher.Str(o, 16) ?? "";
		if (petDesc.IndexOf("Combat Ratings", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			void PetRating(string label, string pattern)
			{
				var m = System.Text.RegularExpressions.Regex.Match(petDesc, pattern + @":\s*(-?\d+)\s*\(Base:\s*(-?\d+),\s*Mut:\s*\+?(-?\d+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
				if (!m.Success) return;
				int mut = int.Parse(m.Groups[3].Value);
				list5.Add(label + m.Groups[1].Value + (mut != 0 ? "(+" + mut + ")" : ""));
			}
			PetRating("D", @"\bDamage");
			PetRating("DR", @"Damage Resist");
			PetRating("C", @"Crit Rating");
			if (list5.Count > 0)
			{
				list.Add("Pet ratings " + string.Join(" ", list5.ToArray()));
				list5.Clear();
				goto ratingsDone;
			}
		}
		AddRating(o, list5, 370, "D");
		AddRating(o, list5, 374, "CD");
		AddRating(o, list5, 371, "DR");
		AddRating(o, list5, 375, "CDR");
		AddRating(o, list5, 372, "C");
		AddRating(o, list5, 373, "CR");
		AddRating(o, list5, 376, "HB");
		AddRating(o, list5, 379, "Vit");
		if (list5.Count > 0)
		{
			list.Add("Ratings " + string.Join(" ", list5.ToArray()));
		}
		ratingsDone:
		if (objectClass == ObjectClass.Salvage)
		{
			double num18 = LootMatcher.Dbl(o, 167772169);
			if (num18 > 0.0)
			{
				list.Add("Work " + num18.ToString("0.00", Inv));
			}
		}
		return string.Join(", ", list.ToArray());
	}

	private static string Pct(double v)
	{
		return Math.Round((v - 1.0) * 100.0).ToString("0", Inv);
	}

	private static string Pct1(double v)
	{
		return Math.Round((v - 1.0) * 100.0, 1).ToString("0.#", Inv);
	}

	private static void AddRating(WorldObject o, List<string> l, int key, string label)
	{
		int num = LootMatcher.Long(o, key);
		if (num > 0)
		{
			l.Add(label + num);
		}
	}

	private static string Grade(int q)
	{
		string result;
		if (q >= 1000)
		{
			result = "S";
		}
		else if (q >= 900)
		{
			result = "A";
		}
		else if (q >= 800)
		{
			result = "B";
		}
		else if (q >= 650)
		{
			result = "C";
		}
		else
		{
			result = ((q >= 500) ? "D" : "F");
		}
		return result;
	}

	private static TextInfo Read(params string[] texts)
	{
		TextInfo textInfo = new TextInfo();
		HashSet<string> hashSet = new HashSet<string>();
		foreach (string text in texts)
		{
			if (string.IsNullOrEmpty(text))
			{
				continue;
			}
			string[] array = text.Split('\n');
			foreach (string text2 in array)
			{
				string text3 = text2.Trim();
				if (text3.StartsWith("- "))
				{
					text3 = text3.Substring(2).Trim();
				}
				else if (!text3.StartsWith("Wield requires", StringComparison.OrdinalIgnoreCase))
				{
					continue;
				}
				if (text3.Length == 0 || !hashSet.Add(text3))
				{
					continue;
				}
				if (text3.StartsWith("Wield requires", StringComparison.OrdinalIgnoreCase))
				{
					int num = text3.IndexOf(':');
					string text4 = ((num >= 0) ? text3.Substring(num + 1) : text3.Substring(14)).Trim().Replace("Augmentations", "Augs").Replace("Augmentation", "Aug");
					if (text4.Length > 0)
					{
						textInfo.Wield.Add(text4);
					}
				}
				else if (text3.StartsWith("Properties:"))
				{
					string[] array2 = text3.Substring(11).Trim().Split(new string[1] { " of " }, StringSplitOptions.None);
					textInfo.Count = ((array2.Length == 2) ? (array2[0].Trim() + "/" + array2[1].Trim()) : text3.Substring(11).Trim());
				}
				else if (text3.StartsWith("Gear Grade:") || text3.StartsWith("Weapon Grade:") || text3.StartsWith("Grade:"))
				{
					string text5 = text3.Substring(text3.IndexOf(':') + 1).Trim();
					Match match = PctOf.Match(text5);
					textInfo.Grade = ((text3.StartsWith("Weapon") && match.Success) ? (match.Groups[1].Value + " (" + match.Groups[2].Value + ")") : text5.Split(' ')[0]);
				}
				else
				{
					if (text3.StartsWith("Effective "))
					{
						continue;
					}
					text3 = Band.Replace(text3, " ($1)").Replace(" (Built-in)", "");
					string[][] modShort = ModShort;
					foreach (string[] array3 in modShort)
					{
						if (text3.StartsWith(array3[0], StringComparison.Ordinal))
						{
							text3 = array3[1] + text3.Substring(array3[0].Length);
							break;
						}
					}
					if (text3.StartsWith("CoS "))
					{
						text3 = "Proc " + text3.Substring(4).Replace(" proc chance)", ")");
					}
					text3 = text3.Replace(" Rending:", " Rend").Replace(" Slayer:", " Slayer").Replace(" Crit Chance", "")
						.Replace(" Crit Dmg", "")
						.Replace(" Spell Armor Ignored", "")
						.Replace(" Dmg", "");
					textInfo.Lines.Add(text3.Replace("  ", " ").Trim());
				}
			}
		}
		return textInfo;
	}

	private static string Wield(WorldObject o)
	{
		List<string> list = new List<string>();
		int[][] array = new int[4][]
		{
			new int[3] { 158, 159, 160 },
			new int[3] { 270, 271, 272 },
			new int[3] { 273, 274, 275 },
			new int[3] { 276, 277, 278 }
		};
		int[][] array2 = array;
		foreach (int[] array3 in array2)
		{
			int num = LootMatcher.Long(o, array3[0]);
			int num2 = LootMatcher.Long(o, array3[1]);
			int num3 = LootMatcher.Long(o, array3[2]);
			if (num3 > 0 || num > 0)
			{
				string text;
				string value;
				switch (num)
				{
				case 1:
				case 2:
					text = (Skills.TryGetValue(num2, out value) ? value : ("Skill " + num2));
					break;
				case 3:
				case 4:
					text = ((num2 > 0 && num2 < Attributes.Length) ? Attributes[num2] : ("Attr " + num2));
					break;
				case 7:
					text = "Lvl";
					break;
				case 8:
					list.Add((Skills.TryGetValue(num2, out value) ? value : ("Skill " + num2)) + ((num3 >= 3) ? " specialized" : " trained"));
					continue;
				default:
					if (Counters.TryGetValue(num2, out value))
					{
						text = value;
					}
					else
					{
						text = ((num2 > 0) ? ("#" + num2) : "");
					}
					break;
				}
				if (num == 7)
				{
					list.Add("Lvl " + num3.ToString("N0", Inv));
				}
				else if (Counters.ContainsKey(num2) || num > 7)
				{
					list.Add(num3.ToString("N0", Inv) + " " + text);
				}
				else
				{
					list.Add(text + " " + num3.ToString("N0", Inv));
				}
			}
		}
		return string.Join(" + ", list.ToArray());
	}
}
