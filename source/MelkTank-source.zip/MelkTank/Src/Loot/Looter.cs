using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
#if !RETAIL
using AcClient;
#endif
using Decal.Adapter.Wrappers;

namespace MelkTank.Loot;

public class Looter
{
	private enum State
	{
		Idle,
		Opening,
		Settling,
		Items,
		Identifying,
		BuffWait,
		Moving,
		Picking,
		Fetching
	}

	public class LogEntry
	{
		public string Time;

		public string Rule;

		public string Name;

		public string Rest;

		public string Vs;

		public int VsColor = 7;
	}

	private class Loaded
	{
		public UtlProfile P;

		public UtlProfile Edit;

		public string Path;

		public DateTime WrittenAt;
	}

	private readonly Settings _s;

	private State _state = State.Idle;

	private DateTime _until = DateTime.MinValue;

	private DateTime _next = DateTime.MinValue;

	private int _corpse;

	private int _openTries;

	private readonly List<int> _items = new List<int>();

	private int _itemIdx;

	private int _moveTries;

	private UtlRule _moveRule;

	private readonly HashSet<int> _done = new HashSet<int>();

	private readonly HashSet<int> _idByUs = new HashSet<int>();

	private readonly HashSet<string> _warnedRules = new HashSet<string>();

	private DateTime _packFullUntil = DateTime.MinValue;

	public Action<string> DebugOut;

	private bool _rescanned;

	private int _idTries;

	private bool _idTimedOut;

	public readonly List<LogEntry> Log = new List<LogEntry>();

	public static Looter Current;

	private DateTime _portalAt = DateTime.MinValue;

	private readonly Dictionary<int, DateTime> _doneAt = new Dictionary<int, DateTime>();

	private static bool _lootSeeded;

	public const int General = 0;

	public const int Misc = 1;

	public const int Armor = 2;

	public const int Weapon = 3;

	public const int Salvage = 4;

	public static readonly string[] SlotNames = new string[5] { "General", "Misc", "Armor", "Weapon", "Salvage" };

	private readonly Dictionary<string, Loaded> _loaded = new Dictionary<string, Loaded>(StringComparer.OrdinalIgnoreCase);

	private readonly Dictionary<string, DateTime> _failed = new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);

	private readonly HashSet<string> _backedUp = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

	private readonly HashSet<int> _maxedSaid = new HashSet<int>();

	private DateTime _rareAt = DateTime.MinValue;

	private static readonly List<KeyValuePair<string, DateTime>> _rareNames = new List<KeyValuePair<string, DateTime>>();

	private static readonly Regex SpecialRx = new Regex("\\b(?<item>(?:Pristine|Prisitine|Ascendant)\\b[^!.,\\r\\n]*)", RegexOptions.IgnoreCase);

	private static readonly Regex RareRx = new Regex("^(?:\\[[^\\]]*\\]\\s*)?(?<who>You|.+?) (?:have|has) (?:just )?discovered (?:the |a |an )?(?<item>.+?)!", RegexOptions.IgnoreCase);

	private readonly Dictionary<int, string> _result = new Dictionary<int, string>();

	private readonly Dictionary<int, int> _lootedCount = new Dictionary<int, int>();

	private int _unlootedCount;

	private DateTime _unlootedAt = DateTime.MinValue;

	private readonly HashSet<int> _cleared = new HashSet<int>();

	private int _priority;

	private int _lastIdShown;

	private DateTime _lastIdShownAt = DateTime.MinValue;

	private int _userChest;

	private static readonly TimeSpan ChestAgain = TimeSpan.FromMinutes(10L);

	private bool _isChest;

	private bool _chestCheck;

	private bool _userCorpse;   // (a corpse you opened, gone over only to say what's in it: Check corpses)

	private int _lastChestId;

	private DateTime _lastChestAt = DateTime.MinValue;

	private readonly List<string> _chestHits = new List<string>();

	private readonly HashSet<int> _chestIds = new HashSet<int>();

	private readonly Dictionary<int, DateTime> _chestTimer = new Dictionary<int, DateTime>();

	private bool _chestLocked;

	private int _pickTries;

	private const int ResistLockpick = 38;

	/// <summary>
	/// Chests only a key opens (lock resistance 9,999 - "Use a Mythical Valley Key to open it"), by name: once one is found,
	/// every chest of that name is left alone for the rest of the session, instead of being walked to and tried every
	/// 10 minutes.
	/// </summary>
	private static readonly HashSet<string> _keyOnly = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

	private bool _pickWaitId;

	private bool _lockSaid;

	private int _fetchId;

	private readonly HashSet<int> _chestIdAsked = new HashSet<int>();

	private readonly Dictionary<int, DateTime> _chestRecheckAt = new Dictionary<int, DateTime>();

	private readonly HashSet<int> _seenUnlocked = new HashSet<int>();

	private bool _ownCorpse;

	private bool _weOpened;

	private readonly Dictionary<int, DateTime> _idAskedAt = new Dictionary<int, DateTime>();

	private static readonly UtlRule RareRule = new UtlRule
	{
		Name = "Rare",
		Act = "1"
	};

	private int _buffRetries;

	private int _buffItem;

	private string _lastName;

	private ObjectClass _lastClass;

	public string Status { get; private set; }

	public bool Busy => _state != State.Idle;

	public bool Opening => _state == State.Opening || _state == State.Moving;

	private static TimeSpan CorpseMemory => TimeSpan.FromMinutes(Tuning.V("CorpseMemoryMin"));

	private static string CorpseLogPath
	{
		get
		{
			string text = "";
			try
			{
				text = Globals.Core.CharacterFilter.Name ?? "";
			}
			catch
			{
			}
			char[] invalidFileNameChars = Path.GetInvalidFileNameChars();
			foreach (char oldChar in invalidFileNameChars)
			{
				text = text.Replace(oldChar, '_');
			}
			return Util.FullPath("MelkTank_Corpses_" + text.Replace(' ', '_') + ".txt");
		}
	}

	public string ProfileDir
	{
		get
		{
			if (!string.IsNullOrEmpty(_s.LootProfileDir))
			{
				return _s.LootProfileDir;
			}
			string text = Util.ProfilesDir("Loot", moveOld: false);
			SeedLoot(text);
			return text;
		}
	}

	public bool HasProfile
	{
		get
		{
			if (SlotOn(0))
			{
				return SlotProfile(0) != null;
			}
			for (int i = 1; i <= 4; i++)
			{
				if (SlotOn(i) && SlotProfile(i) != null)
				{
					return true;
				}
			}
			return false;
		}
	}

	public bool RareWindow => (DateTime.Now - _rareAt).TotalSeconds < 60.0;

	public bool PacksFull { get; private set; }

	public DateTime LastBusyAt { get; private set; }

	public bool CorpsesOn => _s.LootEnabled;

	// (and "Say when a chest has nothing" alone: a chest you open is still gone over, to say what's in it for the profiles)
	public bool OpenedChestsOn => _s.LootChests || _s.CheckChests || _s.ChestSummary;

	public bool AutoChestsOn => _s.AutoChests && _s.LootEnabled;

	// (Looting off: a corpse you open yourself checked - what's in it for the profiles said - with Check corpses or
	// "Say when a corpse has nothing")
	public bool OpenedCorpsesOn => (_s.CheckCorpses || _s.CorpseSummary) && (!_s.LootEnabled || !_s.MasterEnabled);

	public bool On => CorpsesOn || OpenedChestsOn || OpenedCorpsesOn || _s.TrackPickup || Forcing;

	/// <summary>A /mt loot is waiting or under way (it runs with MelkTank and the chest settings off too).</summary>
	public bool Forcing => _forceNext || (_forcedId != 0 && _forcedId == _corpse && _state != State.Idle);

	private int _forcedId;

	public bool PicksLocks => _s.AutoChests && _s.ChestPickLocks;

	public bool HoldsNav
	{
		get
		{
			if (!On)
			{
				return false;
			}
			double totalSeconds = (DateTime.Now - LastBusyAt).TotalSeconds;
			if (totalSeconds < 2.0)
			{
				return true;
			}
			return totalSeconds < 15.0 && !PacksFull && DateTime.Now >= _packFullUntil && UnlootedInRange() > 0;
		}
	}

	private void Dbg(string s)
	{
		try
		{
			if (DebugOut != null)
			{
				DebugOut("LOOT  " + s);
			}
		}
		catch
		{
		}
	}

	public Looter(Settings s)
	{
		LootMatcher.RareFoundNamed = RareFoundNamed;
		Current = this;
		_s = s;
		Status = "Idle";
		LoadAll();
		LoadCorpseLog();
	}

	public void NotePortal()
	{
		_portalAt = DateTime.Now;
	}

	public void CorpseReleased(int id, double dist)
	{
		if (!((DateTime.Now - _portalAt).TotalSeconds < 10.0) && !(dist < 0.0) && !(dist > Tuning.V("RotDistM")) && _doneAt.Remove(id))
		{
			_cleared.Remove(id);
			_done.Remove(id);
			_result.Remove(id);
			_lootedCount.Remove(id);
			SaveCorpseLog();
		}
	}

	private void LoadCorpseLog()
	{
		try
		{
			string corpseLogPath = CorpseLogPath;
			if (!File.Exists(corpseLogPath))
			{
				return;
			}
			string[] array = File.ReadAllLines(corpseLogPath);
			foreach (string text in array)
			{
				string[] array2 = text.Split('|');
				if (array2.Length < 4 || !int.TryParse(array2[0], out var result) || !long.TryParse(array2[2], out var result2))
				{
					continue;
				}
				DateTime dateTime = new DateTime(result2);
				if (DateTime.Now - dateTime > CorpseMemory)
				{
					continue;
				}
				try
				{
					WorldObject worldObject = Globals.Core.WorldFilter[result];
					if (worldObject != null && worldObject.ObjectClass == ObjectClass.Container)
					{
						continue;
					}
				}
				catch
				{
				}
				_done.Add(result);
				_doneAt[result] = dateTime;
				if (array2[1].Length > 0)
				{
					_result[result] = array2[1];
				}
				if (array2[3] == "1")
				{
					_cleared.Add(result);
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void SaveCorpseLog()
	{
		try
		{
			List<string> list = new List<string>();
			foreach (int item in _done)
			{
				if (!_doneAt.TryGetValue(item, out var value))
				{
					value = DateTime.Now;
					_doneAt[item] = value;
				}
				if (!(DateTime.Now - value > CorpseMemory) && !_chestIds.Contains(item))
				{
					_result.TryGetValue(item, out var value2);
					list.Add(item + "|" + (value2 ?? "").Replace("|", "/") + "|" + value.Ticks + "|" + (_cleared.Contains(item) ? "1" : "0"));
				}
			}
			File.WriteAllLines(CorpseLogPath, list.ToArray());
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void SeedLoot(string dir)
	{
		if (_lootSeeded)
		{
			return;
		}
		_lootSeeded = true;
		try
		{
			string[] files = Directory.GetFiles(Util.BasePath, "*.utl");
			foreach (string text in files)
			{
				string text2 = Path.Combine(dir, Path.GetFileName(text));
				if (!File.Exists(text2))
				{
					File.Move(text, text2);
				}
			}
			string[] array = new string[3] { "C:\\Games\\VirindiPlugins\\VirindiTank", "C:\\Program Files\\VirindiPlugins\\VirindiTank", "C:\\Program Files (x86)\\VirindiPlugins\\VirindiTank" };
			foreach (string path in array)
			{
				if (!Directory.Exists(path))
				{
					continue;
				}
				string[] files2 = Directory.GetFiles(path, "ILT_*.utl");
				foreach (string text3 in files2)
				{
					string text4 = Path.Combine(dir, Path.GetFileName(text3));
					if (!File.Exists(text4))
					{
						File.Copy(text3, text4);
					}
				}
				break;
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public List<string> ListProfiles()
	{
		List<string> list = new List<string>();
		try
		{
			string[] files = Directory.GetFiles(ProfileDir, "*.utl");
			foreach (string path in files)
			{
				list.Add(Path.GetFileName(path));
			}
		}
		catch
		{
		}
		list.Sort(StringComparer.OrdinalIgnoreCase);
		return list;
	}

	public bool SlotOn(int i)
	{
		return i switch
		{
			0 => _s.LootUseGeneral, 
			1 => _s.LootMiscOn, 
			2 => _s.LootArmorOn, 
			3 => _s.LootWeaponOn, 
			_ => _s.LootSalvageOn, 
		};
	}

	public void SetSlotOn(int i, bool on)
	{
		switch (i)
		{
		case 0:
			_s.LootUseGeneral = on;
			break;
		case 1:
			_s.LootMiscOn = on;
			break;
		case 2:
			_s.LootArmorOn = on;
			break;
		case 3:
			_s.LootWeaponOn = on;
			break;
		default:
			_s.LootSalvageOn = on;
			break;
		}
	}

	public string SlotFile(int i)
	{
		return i switch
		{
			0 => _s.LootProfile ?? "", 
			1 => _s.LootMiscProfile ?? "", 
			2 => _s.LootArmorProfile ?? "", 
			3 => _s.LootWeaponProfile ?? "", 
			_ => _s.LootSalvageProfile ?? "", 
		};
	}

	public void SetSlotFile(int i, string f)
	{
		switch (i)
		{
		case 0:
			_s.LootProfile = f;
			break;
		case 1:
			_s.LootMiscProfile = f;
			break;
		case 2:
			_s.LootArmorProfile = f;
			break;
		case 3:
			_s.LootWeaponProfile = f;
			break;
		default:
			_s.LootSalvageProfile = f;
			break;
		}
		if (!string.IsNullOrEmpty(f))
		{
			Get(f);
		}
	}

	public UtlProfile SlotProfile(int i)
	{
		string text = SlotFile(i);
		return (text.Length == 0) ? null : Get(text);
	}

	public UtlProfile Get(string file)
	{
		if (string.IsNullOrEmpty(file))
		{
			return null;
		}
		if (_loaded.TryGetValue(file, out var value))
		{
			return value.P;
		}
		if (_failed.TryGetValue(file, out var value2) && DateTime.Now < value2)
		{
			return null;
		}
		return Load(file) ? _loaded[file].P : null;
	}

	public UtlProfile GetEdit(string file)
	{
		if (Get(file) == null)
		{
			return null;
		}
		Loaded loaded = _loaded[file];
		if (loaded.Edit == null)
		{
			loaded.Edit = loaded.P.Clone();
		}
		return loaded.Edit;
	}

	public void DiscardEdit(string file)
	{
		if (!string.IsNullOrEmpty(file) && _loaded.TryGetValue(file, out var value))
		{
			value.Edit = null;
		}
	}

	public bool IsLoaded(string file)
	{
		return !string.IsNullOrEmpty(file) && _loaded.ContainsKey(file);
	}

	public bool Load(string file)
	{
		if (string.IsNullOrEmpty(file))
		{
			return false;
		}
		string path = Path.Combine(ProfileDir, file);
		try
		{
			Loaded loaded = new Loaded
			{
				P = UtlProfile.Load(path),
				Path = path,
				WrittenAt = File.GetLastWriteTimeUtc(path)
			};
			_loaded[file] = loaded;
			_failed.Remove(file);
			WarnUnsupported(loaded.P);
			return true;
		}
		catch (Exception ex)
		{
			_loaded.Remove(file);
			_failed[file] = DateTime.Now.AddSeconds(30.0);
			Util.WriteToChat("Couldn't read loot profile " + file + ": " + ex.Message);
			return false;
		}
	}

	public void LoadAll()
	{
		_loaded.Clear();
		_warnedRules.Clear();
		for (int i = 0; i < SlotNames.Length; i++)
		{
			SlotProfile(i);
		}
	}

	public bool Save(string file)
	{
		if (string.IsNullOrEmpty(file) || !_loaded.TryGetValue(file, out var value))
		{
			return false;
		}
		try
		{
			if (!_backedUp.Contains(value.Path) && File.Exists(value.Path))
			{
				File.Copy(value.Path, value.Path + ".bak", overwrite: true);
				_backedUp.Add(value.Path);
			}
			UtlProfile utlProfile = value.Edit ?? value.P;
			utlProfile.Save(value.Path);
			value.WrittenAt = File.GetLastWriteTimeUtc(value.Path);
			if (value.Edit != null)
			{
				value.P = value.Edit.Clone();
			}
			return true;
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Couldn't save loot profile: " + ex.Message);
			return false;
		}
	}

	public string SaveAs(string from, string newName)
	{
		if (string.IsNullOrEmpty(from) || !_loaded.TryGetValue(from, out var value))
		{
			return null;
		}
		newName = (newName ?? "").Trim();
		if (newName.Length == 0)
		{
			return null;
		}
		if (!newName.EndsWith(".utl", StringComparison.OrdinalIgnoreCase))
		{
			newName += ".utl";
		}
		string text = Path.Combine(ProfileDir, newName);
		try
		{
			if (File.Exists(text) && !_backedUp.Contains(text))
			{
				File.Copy(text, text + ".bak", overwrite: true);
				_backedUp.Add(text);
			}
			UtlProfile utlProfile = value.Edit ?? value.P;
			utlProfile.Save(text);
			_loaded[newName] = new Loaded
			{
				P = utlProfile.Clone(),
				Edit = utlProfile,
				Path = text,
				WrittenAt = File.GetLastWriteTimeUtc(text)
			};
			if (!string.Equals(from, newName, StringComparison.OrdinalIgnoreCase))
			{
				if (File.Exists(value.Path))
				{
					Load(from);
				}
				else
				{
					_loaded.Remove(from);
				}
			}
			return newName;
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Couldn't save loot profile as " + newName + ": " + ex.Message);
			return null;
		}
	}

	public bool FileExists(string name)
	{
		name = (name ?? "").Trim();
		if (name.Length == 0)
		{
			return false;
		}
		if (!name.EndsWith(".utl", StringComparison.OrdinalIgnoreCase))
		{
			name += ".utl";
		}
		try
		{
			return File.Exists(Path.Combine(ProfileDir, name));
		}
		catch
		{
			return false;
		}
	}

	public bool ChangedOnDisk(string file)
	{
		if (string.IsNullOrEmpty(file) || !_loaded.TryGetValue(file, out var value))
		{
			return false;
		}
		try
		{
			return File.GetLastWriteTimeUtc(value.Path) != value.WrittenAt;
		}
		catch
		{
			return false;
		}
	}

	public List<string> LoadedFiles()
	{
		return new List<string>(_loaded.Keys);
	}

	public UtlRule Match(WorldObject o, out string file)
	{
		file = null;
		if (SlotOn(0))
		{
			file = SlotFile(0);
			return LootMatcher.FirstMatch(SlotProfile(0), o);
		}
		int i = SlotFor(o);
		UtlRule utlRule = (SlotOn(i) ? LootMatcher.FirstMatch(SlotProfile(i), o) : null);
		if (SlotOn(i))
		{
			file = SlotFile(i);
		}
		if (utlRule != null && utlRule.Act != "0")
		{
			return utlRule;
		}
		if (SlotOn(4))
		{
			UtlRule utlRule2 = LootMatcher.FirstMatch(SlotProfile(4), o);
			if (utlRule2 != null && utlRule2.Act != "0")
			{
				file = SlotFile(4);
				return utlRule2;
			}
		}
		return utlRule;
	}

	public UtlRule Match(WorldObject o)
	{
		if (SlotOn(0))
		{
			return LootMatcher.FirstMatch(SlotProfile(0), o);
		}
		int i = SlotFor(o);
		UtlRule utlRule = (SlotOn(i) ? LootMatcher.FirstMatch(SlotProfile(i), o) : null);
		if (utlRule != null && utlRule.Act != "0")
		{
			return utlRule;
		}
		if (SlotOn(4))
		{
			UtlRule utlRule2 = LootMatcher.FirstMatch(SlotProfile(4), o);
			if (utlRule2 != null && utlRule2.Act != "0")
			{
				return utlRule2;
			}
		}
		return utlRule;
	}

	public bool NeedsId(WorldObject o)
	{
		if (o.ObjectClass == ObjectClass.ManaStone)
		{
			return false;
		}
		if (_s.LootSkipMaxedPct > 0 && ArmorCompare.SlotsMaxed(o, _s.LootSkipMaxedPct, out var why))
		{
			if (_maxedSaid.Add(o.Id))
			{
				if (_maxedSaid.Count > 500)
				{
					_maxedSaid.Clear();
				}
				Dbg("skip ID " + o.Name + " - " + why);
			}
			return false;
		}
		UtlRule rule;
		if (SlotOn(0))
		{
			return !LootMatcher.DecideWithoutId(SlotProfile(0), o, out rule);
		}
		int i = SlotFor(o);
		rule = null;
		if (SlotOn(i) && !LootMatcher.DecideWithoutId(SlotProfile(i), o, out rule))
		{
			return true;
		}
		if (rule != null && rule.Act != "0")
		{
			return false;
		}
		if (SlotOn(4) && !LootMatcher.DecideWithoutId(SlotProfile(4), o, out rule))
		{
			return true;
		}
		return false;
	}

	public static int SlotFor(WorldObject o)
	{
		ObjectClass objectClass = o.ObjectClass;
		if (objectClass == ObjectClass.MeleeWeapon || objectClass == ObjectClass.MissileWeapon || objectClass == ObjectClass.WandStaffOrb)
		{
			return 3;
		}
		if (objectClass == ObjectClass.Armor || objectClass == ObjectClass.Jewelry || objectClass == ObjectClass.Clothing)
		{
			return 2;
		}
		return 1;
	}

	public static bool RareFoundNamed(string name)
	{
		lock (_rareNames)
		{
			foreach (KeyValuePair<string, DateTime> rareName in _rareNames)
			{
				if ((DateTime.Now - rareName.Value).TotalMinutes <= 10.0 && !string.IsNullOrEmpty(name) && (name.Equals(rareName.Key, StringComparison.OrdinalIgnoreCase) || name.IndexOf(rareName.Key, StringComparison.OrdinalIgnoreCase) >= 0 || rareName.Key.IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0))
				{
					return true;
				}
			}
		}
		return false;
	}

	private void SpecialDrop(string text)
	{
		Match match = SpecialRx.Match(text);
		if (!match.Success || text.IndexOf("Pristine Siphon Lens", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			return;
		}
		string text2 = Globals.Core.CharacterFilter.Name ?? "";
		if ((text2.Length <= 0 || text.IndexOf(text2, StringComparison.OrdinalIgnoreCase) < 0) && !Regex.IsMatch(text, "^(?:\\[[^\\]]*\\]\\s*)?You\\b", RegexOptions.IgnoreCase))
		{
			Dbg("zone drop line (not yours): " + text.Trim());
			return;
		}
		string input = match.Groups["item"].Value.Trim();
		input = Regex.Replace(input, "\\s+(?:from|on|in|at|off|dropped|has|was)\\b.*$", "", RegexOptions.IgnoreCase).Trim();
		if (input.Length == 0)
		{
			return;
		}
		_rareAt = DateTime.Now;
		lock (_rareNames)
		{
			_rareNames.RemoveAll((KeyValuePair<string, DateTime> x) => (DateTime.Now - x.Value).TotalMinutes > 10.0);
			_rareNames.Add(new KeyValuePair<string, DateTime>(input, DateTime.Now));
		}
		Dbg("your drop: " + input + " (from: " + text.Trim() + ")");
		if (_s.LootOnlyRare)
		{
			Util.WriteToChat(input + " dropped - looting your corpses for a minute.");
		}
	}

	public void OnChat(string text)
	{
		try
		{
			Match match = RareRx.Match(text ?? "");
			if (match.Success)
			{
				string text2 = match.Groups["who"].Value.Trim();
				string value = Globals.Core.CharacterFilter.Name ?? "";
				if (text2.Equals("You", StringComparison.OrdinalIgnoreCase) || text2.Equals(value, StringComparison.OrdinalIgnoreCase))
				{
					_rareAt = DateTime.Now;
					lock (_rareNames)
					{
						_rareNames.RemoveAll((KeyValuePair<string, DateTime> x) => (DateTime.Now - x.Value).TotalMinutes > 10.0);
						_rareNames.Add(new KeyValuePair<string, DateTime>(match.Groups["item"].Value.Trim(), DateTime.Now));
					}
					if (_s.LootOnlyRare)
					{
						Util.WriteToChat("Rare found (" + match.Groups["item"].Value + ") - looting your corpses for a minute.");
					}
				}
			}
			else
			{
				SpecialDrop(text ?? "");
			}
		}
		catch
		{
		}
		if (text.IndexOf(" is locked", StringComparison.OrdinalIgnoreCase) >= 0 && _state == State.Idle)
		{
			try
			{
				int currentSelection = Globals.Core.Actions.CurrentSelection;
				if (currentSelection != 0 && _done.Contains(currentSelection))
				{
					WorldObject worldObject = Globals.Core.WorldFilter[currentSelection];
					if (worldObject != null && worldObject.ObjectClass == ObjectClass.Container)
					{
						_done.Remove(currentSelection);
						_doneAt.Remove(currentSelection);
						_result.Remove(currentSelection);
						Dbg(worldObject.Name + " is locked again - trying it again");
					}
				}
			}
			catch
			{
			}
		}
		if (text.IndexOf("complete this quest again", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("solved this quest too recently", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			int num = ((_isChest && _state != State.Idle) ? _corpse : (((DateTime.Now - _lastChestAt).TotalSeconds < 20.0) ? _lastChestId : 0));
			if (num != 0)
			{
				TimeSpan timeSpan = ((text.IndexOf("again in", StringComparison.OrdinalIgnoreCase) >= 0) ? QuestWait(text) : TimeSpan.FromHours(1));
				DateTime dateTime = DateTime.Now + timeSpan;
				if (!_chestTimer.TryGetValue(num, out var value2) || value2 < dateTime)
				{
					_chestTimer[num] = dateTime;
				}
				_done.Add(num);
				_doneAt[num] = DateTime.Now;
				_result[num] = "Skipped: quest timer";
				Dbg("chest on a quest timer - left for " + timeSpan);
				if (_isChest && _state != State.Idle && num == _corpse)
				{
					FinishCorpse("quest timer");
				}
			}
		}
		else
		{
			if (_state == State.Idle)
			{
				return;
			}
			if (_isChest && (_state == State.Opening || _state == State.Picking) && text.IndexOf(" is locked", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				_chestLocked = true;
				_lockSaid = true;
				if (_state == State.Opening)
				{
					_until = DateTime.Now;
				}
			}
			else if (_state == State.Opening && text.IndexOf("too busy", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				_until = DateTime.Now.AddMilliseconds(Tuning.V("CorpseBusyRetryMs"));
				if (_openTries > 1)
				{
					_openTries--;
				}
			}
			else if (text.IndexOf("permission to loot", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("You don't have permission", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				FinishCorpse("no permission");
			}
			else if (_state == State.Moving && (text.IndexOf("too encumbered", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("not enough room", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("pack is full", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("can't carry", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("cannot carry", StringComparison.OrdinalIgnoreCase) >= 0))
			{
				Util.WriteToChat("Couldn't pick that up (" + text.Trim() + ") - your packs look full. Looting paused for 60s.");
				_packFullUntil = DateTime.Now.AddSeconds(Tuning.V("PackFullPauseS"));
				Abort("pack full");
			}
		}
	}

	public int UnlootedInRange()
	{
		if ((DateTime.Now - _unlootedAt).TotalSeconds < 1.0)
		{
			return _unlootedCount;
		}
		_unlootedAt = DateTime.Now;
		int num = 0;
		try
		{
			string b = "Corpse of " + Globals.Core.CharacterFilter.Name;
			bool corpsesOn = CorpsesOn;
			bool flag = AutoChestsOn && HasProfile;
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				if (flag && item.ObjectClass == ObjectClass.Container)
				{
					if (!OnTimer(item.Id) && !_done.Contains(item.Id) && IsChest(item))
					{
						double num2 = CombatEngine.Distance(item);
						if (num2 >= 0.0 && num2 <= (double)_s.LootRange)
						{
							num++;
						}
					}
				}
				else
				{
					if (item.ObjectClass != ObjectClass.Corpse || _done.Contains(item.Id) || !corpsesOn)
					{
						continue;
					}
					bool flag2 = string.Equals(item.Name, b, StringComparison.OrdinalIgnoreCase);
					if ((!flag2 || _s.LootOwnCorpse) && (flag2 || !_s.LootOnlyRare || RareWindow) && (flag2 || CorpseKillers.Allowed(item, _s.LootFellowKills, out var _)))
					{
						double num3 = CombatEngine.Distance(item);
						if (num3 >= 0.0 && num3 <= (double)_s.LootRange)
						{
							num++;
						}
					}
				}
			}
		}
		catch
		{
		}
		try
		{
			PacksFull = Character.AllPacksFreeSlots() <= 0;
		}
		catch
		{
		}
		return _unlootedCount = num;
	}

	public string CorpseStatus(int id)
	{
		if (Busy && id == _corpse)
		{
			return "Looting now";
		}
		string value;
		return _result.TryGetValue(id, out value) ? value : null;
	}

	public bool IsCleared(int id)
	{
		return _cleared.Contains(id);
	}

	public int ClearCorpses()
	{
		int num = 0;
		try
		{
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				if (item.ObjectClass == ObjectClass.Corpse && (!Busy || item.Id != _corpse))
				{
					if (_cleared.Add(item.Id))
					{
						num++;
					}
					_done.Add(item.Id);
					if (!_result.ContainsKey(item.Id))
					{
						_result[item.Id] = "Cleared";
					}
				}
			}
		}
		catch
		{
		}
		if (num > 0)
		{
			SaveCorpseLog();
		}
		return num;
	}

	public void Recheck(int id)
	{
		if (!Busy || id != _corpse)
		{
			_cleared.Remove(id);
			_done.Remove(id);
			_result.Remove(id);
			_lootedCount.Remove(id);
			_priority = id;
			_doneAt.Remove(id);
			SaveCorpseLog();
			WorldObject worldObject = Globals.Core.WorldFilter[id];
			double num = ((worldObject == null) ? (-1.0) : CombatEngine.Distance(worldObject));
			string text = ((worldObject != null) ? worldObject.Name : "Corpse");
			string? text2;
			if (_s.LootEnabled)
			{
				text2 = ((num < 0.0 || num > (double)_s.LootRange) ? (" when it's within corpse range (" + _s.LootRange.ToString("0") + "m).") : ".");
			}
			else
			{
				text2 = " once looting is on.";
			}
			Util.WriteToChat(text + " will be looted again" + text2);
		}
	}

	public void OnObjectReleased(int id)
	{
		_idByUs.Remove(id);
		if (!_doneAt.TryGetValue(id, out var value) || !(DateTime.Now - value <= CorpseMemory))
		{
			_cleared.Remove(id);
			_done.Remove(id);
			_result.Remove(id);
			_lootedCount.Remove(id);
			_doneAt.Remove(id);
		}
	}

	public void OnIdentified(int id, bool quiet = false)
	{
		try
		{
			ItemCompare.Remember(Globals.Core.WorldFilter[id]);
		}
		catch
		{
		}
		ChestRelocked(id);
		if (_idByUs.Remove(id) | quiet || !_s.IdAnnounce || (id == _lastIdShown && DateTime.Now - _lastIdShownAt < TimeSpan.FromSeconds(3L)))
		{
			return;
		}
		try
		{
			if (Globals.Core.Actions.CurrentSelection != id)
			{
				return;
			}
			WorldObject worldObject = Globals.Core.WorldFilter[id];
			if (worldObject == null || worldObject.ObjectClass == ObjectClass.Monster || worldObject.ObjectClass == ObjectClass.Player || worldObject.ObjectClass == ObjectClass.Npc || worldObject.ObjectClass == ObjectClass.Corpse)
			{
				return;
			}
			UtlRule utlRule = Match(worldObject);
			if (utlRule != null && utlRule.Act == "0")
			{
				utlRule = null;
			}
			_lastIdShown = id;
			_lastIdShownAt = DateTime.Now;
			Util.WriteToChat("ItemInfo: " + ItemReport.Describe(worldObject, utlRule, link: true) + ((QbStamps.Collected(worldObject.Name) != null) ? " (QB Collected)" : ""), 5, _s.IdChatWindow);
			int color = 7;
			string text = (_s.IdCompare ? ItemCompare.Describe(worldObject, out color) : null);
			if (text != null)
			{
				Util.WriteToChat(Util.TintCompare(text), color, _s.IdChatWindow);
			}
			if (_s.IdCompare)
			{
				string text2 = ItemCompare.DescribeOffhand(worldObject, out var color2);
				if (text2 != null)
				{
					Util.WriteToChat(Util.TintCompare(text2), color2, _s.IdChatWindow);
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	// monsters in attack range (set by the engine): a run to a tracked item waits for them, and one under way stops
	public static Func<bool> MonstersNear;

	private static bool FightFirst(Settings s)
	{
		try
		{
			return s.DetourStopsForCombat && MonstersNear != null && MonstersNear();
		}
		catch
		{
			return false;
		}
	}

	public void Abort(string why)
	{
		if (_state != State.Idle)
		{
			_state = State.Idle;
			_corpse = 0;
			Status = "Stopped (" + why + ")";
		}
	}

	// (/mt loot: the open container looted now with the profile - whatever its name, whatever the chest settings)
	private bool _forceNext;

	public string LootOpenNow()
	{
		int oc = 0;
		try
		{
			oc = Globals.Core.Actions.OpenedContainer;
		}
		catch
		{
		}
		WorldObject o = (oc != 0) ? Globals.Core.WorldFilter[oc] : null;
		if (o == null)
		{
			return "loot: open the chest first.";
		}
		if (!HasProfile)
		{
			return "loot: no loot profile is picked (Loot tab).";
		}
		if (!IsOpenedChest(o))
		{
			return "loot: " + o.Name + " isn't a container on the ground, or it's a house's.";
		}
		if (_state != State.Idle && _corpse == oc)
		{
			Abort("looting it now");
		}
		_userChest = 0;
		_done.Remove(oc);
		_forceNext = true;
		return "loot: looting " + o.Name + ".";
	}

	/// <summary>A container you opened that may be gone over: on the ground and nobody's house's - any name
	/// ("Storage Chest" in a quest is a chest). The auto-chest search is choosier (IsChest).</summary>
	public static bool IsOpenedChest(WorldObject o)
	{
		if (o == null || o.ObjectClass != ObjectClass.Container)
		{
			return false;
		}
		try
		{
			return o.Container == 0 && o.Values(LongValueKey.HouseOwner, 0) == 0;
		}
		catch
		{
			return false;
		}
	}

	private bool TakeUserChest()
	{
		int num = 0;
		try
		{
			num = Globals.Core.Actions.OpenedContainer;
		}
		catch
		{
		}
		if (num == 0)
		{
			_userChest = 0;
			return false;
		}
		if (num == _userChest || (!OpenedChestsOn && !OpenedCorpsesOn && !_forceNext) || !HasProfile)
		{
			return false;
		}
		WorldObject worldObject = Globals.Core.WorldFilter[num];
		// (a corpse you opened yourself, Looting off: only checked - what's in it for the profiles said)
		if (!_forceNext && OpenedCorpsesOn && worldObject != null && worldObject.ObjectClass == ObjectClass.Corpse)
		{
			_userChest = num;
			_done.Remove(num);
			_corpse = num;
			_isChest = false;
			_userCorpse = true;
			_ownCorpse = false;
			_chestCheck = false;
			_forcedId = 0;
			_chestHits.Clear();
			_openTries = 1;
			_weOpened = false;
			_lootedCount.Remove(num);
			_state = State.Settling;
			_until = DateTime.Now.AddMilliseconds(Tuning.V("CorpseSettleMs"));
			Status = "Checking " + worldObject.Name;
			return true;
		}
		if (!IsOpenedChest(worldObject) || (!OpenedChestsOn && !_forceNext))
		{
			_forceNext = false;
			return false;
		}
		_userChest = num;
		_done.Remove(num);
		_corpse = num;
		_isChest = true;
		_userCorpse = false;
		_ownCorpse = false;
		// (looted only with Loot chests and Looting on, and MelkTank on - otherwise only checked, and said)
		_chestCheck = !_forceNext && (_s.CheckChests || !_s.LootChests || !_s.LootEnabled || !_s.MasterEnabled);
		_forcedId = _forceNext ? num : 0;
		_forceNext = false;
		_chestHits.Clear();
		if (_chestCheck)
		{
			ItemTracker.SetChest(worldObject, "checking");
		}
		_openTries = 1;
		_weOpened = false;
		_lootedCount.Remove(num);
		_state = State.Settling;
		_until = DateTime.Now.AddMilliseconds(Tuning.V("CorpseSettleMs"));
		Status = (_chestCheck ? "Checking " : "Looting ") + worldObject.Name;
		return true;
	}

	private static TimeSpan QuestWait(string text)
	{
		double num = 0.0;
		foreach (Match item in Regex.Matches(text, "(\\d+)\\s*([dhms])\\b"))
		{
			double num2 = double.Parse(item.Groups[1].Value);
			num = item.Groups[2].Value switch
			{
				"d" => num + num2 * 86400.0, 
				"h" => num + num2 * 3600.0, 
				"m" => num + num2 * 60.0, 
				_ => num + num2, 
			};
		}
		return TimeSpan.FromSeconds((num > 0.0) ? (num + 5.0) : 3600.0);
	}

	private bool OnTimer(int id)
	{
		if (!_chestTimer.TryGetValue(id, out var value))
		{
			return false;
		}
		if (DateTime.Now < value)
		{
			return true;
		}
		_chestTimer.Remove(id);
		return false;
	}

	private void PickLock(WorldObject c)
	{
		_chestLocked = false;
		if (_chestCheck || !PicksLocks)
		{
			if (c.HasIdData && LootMatcher.Long(c, ResistLockpick) >= 9999 && _keyOnly.Add(c.Name ?? ""))
			{
				Util.WriteToChat(c.Name + " only opens with a key - chests of that name are left alone from now on (this session).");
			}
			else if (!c.HasIdData)
			{
				try { Util.RequestId(c.Id); } catch { }   // (so its lock is known next time it's looked at)
			}
			FinishCorpse("locked");
			return;
		}
		if (_pickTries >= 6)
		{
			FinishCorpse("couldn't pick the lock");
			return;
		}
		if (!c.HasIdData)
		{
			try
			{
				Util.RequestId(c.Id);
			}
			catch
			{
			}
			_state = State.Picking;
			_until = DateTime.Now.AddSeconds(2.0);
			_pickWaitId = true;
			Status = "Checking the lock on " + c.Name;
			return;
		}
		if (_pickTries == 0 && !c.Values(BoolValueKey.Locked, false) && !_lockSaid)
		{
			FinishCorpse("couldn't open it (not locked)");
			return;
		}
		_lockSaid = false;
		int num = LootMatcher.Long(c, 38);
		int num2 = Character.EffectiveSkill(23);
		if (num >= 9999)
		{
			if (_keyOnly.Add(c.Name ?? ""))
			{
				Util.WriteToChat(c.Name + " only opens with a key - chests of that name are left alone from now on (this session).");
			}
			FinishCorpse("key only");
			return;
		}
		if (num2 - num < _s.NavLockpickMargin)
		{
			Util.WriteToChat(c.Name + " is locked - lock " + num + ", your Lockpick is " + num2 + ".");
			FinishCorpse("locked");
			return;
		}
		int num3 = 0;
		string text = "";
		foreach (WeaponItem item in _s.Items)
		{
			if (item.Kind != WeaponKind.Lockpick || ItemInfo.CountInPack(item.Name) <= 0)
			{
				continue;
			}
			text = item.Name;
			num3 = ((Globals.Core.WorldFilter[item.Id] != null) ? item.Id : 0);
			if (num3 == 0)
			{
				foreach (WorldObject item2 in InvCache.All())
				{
					if (string.Equals(item2.Name, item.Name, StringComparison.OrdinalIgnoreCase))
					{
						num3 = item2.Id;
						break;
					}
				}
			}
			if (num3 == 0)
			{
				continue;
			}
			break;
		}
		if (num3 == 0)
		{
			Util.WriteToChat(c.Name + " is locked and there's no lockpick on the Items tab (add one: select it, Add selected).");
			FinishCorpse("locked - no lockpick");
			return;
		}
		_pickTries++;
		try
		{
			CM_Inventory.Event_UseWithTargetEvent((uint)num3, (uint)c.Id);
		}
		catch
		{
			try
			{
				Globals.Core.Actions.ApplyItem(num3, c.Id);
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
				FinishCorpse("couldn't use the lockpick");
				return;
			}
		}
		Dbg("picking " + c.Name + " (lock " + num + ", skill " + num2 + ") with " + text + " - try " + _pickTries);
		_state = State.Picking;
		_pickWaitId = false;
		_until = DateTime.Now.AddSeconds(3.0 + Math.Max(0.0, CombatEngine.Distance(c)) * 0.4);
		Status = "Picking the lock on " + c.Name;
	}

	private void FetchingTick()
	{
		WorldObject worldObject = Globals.Core.WorldFilter[_fetchId];
		if (worldObject != null && worldObject.Container == 0 && FightFirst(_s))
		{
			// (a monster on the way: stop the run and fight - the item's gone for again after, the try not counted)
			Dbg("monster in range - stopping the run to " + worldObject.Name + " to fight first");
			ItemTracker.PickupUntried(_fetchId);
			try
			{
				Globals.Core.Actions.SetAutorun(on: false);
			}
			catch
			{
			}
			_state = State.Idle;
			_fetchId = 0;
			Status = "Stopped for monsters on the way";
			return;
		}
		if (worldObject == null || worldObject.Container != 0)
		{
			Dbg("tracked item picked up");
			_state = State.Idle;
			_fetchId = 0;
		}
		else if (DateTime.Now >= _until)
		{
			Dbg("didn't get to " + worldObject.Name + " - leaving it for now");
			_state = State.Idle;
			_fetchId = 0;
		}
	}

	private void PickingTick()
	{
		WorldObject worldObject = Globals.Core.WorldFilter[_corpse];
		if (worldObject == null)
		{
			FinishCorpse("gone");
		}
		else if (_pickWaitId && worldObject.HasIdData)
		{
			PickLock(worldObject);
		}
		else if (!(DateTime.Now < _until))
		{
			if (_pickWaitId)
			{
				FinishCorpse("locked - no ID");
				return;
			}
			_chestLocked = false;
			_openTries = 0;
			OpenCorpse(worldObject, CombatEngine.Distance(worldObject));
		}
	}

	public static bool IsChest(WorldObject o)
	{
		if (o == null || o.ObjectClass != ObjectClass.Container)
		{
			return false;
		}
		try
		{
			if (o.Container != 0)
			{
				return false;
			}
			if (o.Values(LongValueKey.HouseOwner, 0) != 0)
			{
				return false;
			}
			string text = (o.Name ?? "").ToLowerInvariant();
			if (text.Length == 0 || text.Contains("storage") || text.Contains("pack") || text.Contains("sack") || text.Contains("pouch") || text.Contains("bag") || text.Contains("quiver") || text.Contains("satchel") || text.Contains("foci") || text.Contains("corpse") || text.Contains("hook"))
			{
				return false;
			}
			if (o.Values(BoolValueKey.Locked, false) && (Current == null || !Current.PicksLocks))
			{
				return false;
			}
			if (_keyOnly.Contains(o.Name ?? "") || (o.HasIdData && LootMatcher.Long(o, ResistLockpick) >= 9999))
			{
				return false;   // (only a key opens it)
			}
		}
		catch
		{
			return false;
		}
		return true;
	}

	private void ChestRelocked(int id)
	{
		try
		{
			if (!_done.Contains(id) || id == _corpse || OnTimer(id))
			{
				return;
			}
			WorldObject worldObject = Globals.Core.WorldFilter[id];
			if (worldObject == null || worldObject.ObjectClass != ObjectClass.Container)
			{
				return;
			}
			if (!worldObject.Values(BoolValueKey.Locked, false))
			{
				_seenUnlocked.Add(id);
			}
			else if (_seenUnlocked.Contains(id))
			{
				_seenUnlocked.Remove(id);
				if (!_result.TryGetValue(id, out var value) || (!(value == "Skipped: locked") && !value.Contains("no lockpick")))
				{
					_done.Remove(id);
					_doneAt.Remove(id);
					_result.Remove(id);
					Dbg(worldObject.Name + " is locked again - it has filled up again, trying it again");
				}
			}
		}
		catch
		{
		}
	}

	private void ChestAgainCheck(WorldObject o)
	{
		if (_done.Contains(o.Id) && _doneAt.TryGetValue(o.Id, out var value) && DateTime.Now - value > ChestAgain)
		{
			_done.Remove(o.Id);
		}
	}

	private bool _onlyUserChest;

	/// <summary>A chest you've opened yourself is open (or still being gone over).</summary>
	public bool UserChestOpen()
	{
		if (_isChest && _state != State.Idle)
		{
			return true;
		}
		try
		{
			int oc = Globals.Core.Actions.OpenedContainer;
			if (oc == 0 || oc == _userChest) return false;
			WorldObject o = Globals.Core.WorldFilter[oc];
			return IsOpenedChest(o) || (OpenedCorpsesOn && o != null && o.ObjectClass == ObjectClass.Corpse);
		}
		catch
		{
			return false;
		}
	}

	/// <summary>MelkTank off: only a chest you opened yourself is gone over (checked and said) - nothing else is looted.</summary>
	public bool TickUserChestOnly()
	{
		_onlyUserChest = true;
		try
		{
			return Tick();
		}
		finally
		{
			_onlyUserChest = false;
		}
	}

	public bool Tick()
	{
		bool flag = TickInner();
		if (flag)
		{
			LastBusyAt = DateTime.Now;
		}
		return flag;
	}

	private bool TickInner()
	{
		if (!On)
		{
			Abort("off");
			Status = "Off";
			return false;
		}
		if (DateTime.Now < _packFullUntil)
		{
			Status = "Pack full - waiting";
			return false;
		}
		if (DateTime.Now < _next)
		{
			return Busy;
		}
		_next = DateTime.Now.AddMilliseconds(Tuning.V("LootStepMs"));
		try
		{
			switch (_state)
			{
			case State.Idle:
				return StartNextCorpse();
			case State.Opening:
				OpeningTick();
				break;
			case State.Settling:
				if (DateTime.Now >= _until)
				{
					ReadCorpse();
				}
				break;
			case State.Items:
				NextItem();
				break;
			case State.Identifying:
				IdentifyingTick();
				break;
			case State.BuffWait:
				BuffWaitTick();
				break;
			case State.Moving:
				MovingTick();
				break;
			case State.Picking:
				PickingTick();
				break;
			case State.Fetching:
				FetchingTick();
				break;
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			Abort("error: " + ex.Message);
		}
		return Busy;
	}

	private bool StartNextCorpse()
	{
		WorldObject worldObject = null;
		double dist = double.MaxValue;
		string b = "Corpse of " + Globals.Core.CharacterFilter.Name;
		WorldObject worldObject2 = null;
		double num = 0.0;
		double num2 = double.MaxValue;
		double num3 = -2.0;
		if (TakeUserChest())
		{
			return true;
		}
		if (_onlyUserChest)
		{
			return false;
		}
		try
		{
			WorldObject worldObject3 = FightFirst(_s) ? null : ItemTracker.PickupCandidate(_s, _s.LootRange);
			if (worldObject3 != null)
			{
				ItemTracker.PickupTried(worldObject3.Id);
				double num4 = Math.Max(0.0, CombatEngine.Distance(worldObject3));
				Globals.Core.Actions.MoveItem(worldObject3.Id, Globals.Core.CharacterFilter.Id, 0, stack: true);
				Dbg("picking up tracked " + worldObject3.Name + " (" + num4.ToString("0") + " m)");
				Status = "Picking up " + worldObject3.Name;
				_fetchId = worldObject3.Id;
				_state = State.Fetching;
				_until = DateTime.Now.AddSeconds(Math.Min(90.0, 3.0 + num4 * 0.35));
				return true;
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		bool corpsesOn = CorpsesOn;
		bool autoChestsOn = AutoChestsOn;
		WorldObject worldObject4 = null;
		double num5 = double.MaxValue;
		foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
		{
			if (autoChestsOn && item.ObjectClass == ObjectClass.Container)
			{
				if (OnTimer(item.Id))
				{
					continue;
				}
				if (_done.Contains(item.Id) && PicksLocks && item.Id != _corpse && (!_chestRecheckAt.TryGetValue(item.Id, out var value) || (DateTime.Now - value).TotalSeconds > 60.0) && CombatEngine.Distance(item) <= (double)_s.LootRange)
				{
					_chestRecheckAt[item.Id] = DateTime.Now;
					try
					{
						Util.RequestId(item.Id);
					}
					catch
					{
					}
				}
				if (_done.Contains(item.Id) || !HasProfile || !IsChest(item))
				{
					continue;
				}
				double num6 = CombatEngine.Distance(item);
				if (!(num6 >= 0.0) || !(num6 <= (double)_s.LootRange))
				{
					continue;
				}
				if (PicksLocks && !item.HasIdData && _chestIdAsked.Add(item.Id))
				{
					try
					{
						Util.RequestId(item.Id);
					}
					catch
					{
					}
				}
				if (num6 < num5)
				{
					worldObject4 = item;
					num5 = num6;
				}
			}
			else
			{
				if (item.ObjectClass != ObjectClass.Corpse || _done.Contains(item.Id) || (!corpsesOn && (!_s.LootOwnCorpse || !_s.LootEnabled)))
				{
					continue;
				}
				if (string.Equals(item.Name, b, StringComparison.OrdinalIgnoreCase))
				{
					double num7 = CombatEngine.Distance(item);
					if (_s.LootOwnCorpse && num7 >= 0.0 && num7 <= (double)_s.LootRange && (worldObject2 == null || num7 < num))
					{
						worldObject2 = item;
						num = num7;
					}
				}
				else
				{
					if (!corpsesOn)
					{
						continue;
					}
					bool flag = _s.LootRares && RareWindow;
					if ((!HasProfile && !flag) || (_s.LootOnlyRare && !RareWindow) || !CorpseKillers.Allowed(item, _s.LootFellowKills, out var _))
					{
						continue;
					}
					double num8 = CombatEngine.Distance(item);
					if (num8 < 0.0 || num8 > (double)_s.LootRange)
					{
						continue;
					}
					double num9 = num8;
					if (_s.CloseTurnLeast && num8 <= (double)_s.CloseTurnRange)
					{
						if (num3 == -2.0)
						{
							num3 = CombatEngine.MyHeading();
						}
						if (num3 >= 0.0)
						{
							num9 = -1000.0 + CombatEngine.TurnTo(item, num3);
						}
					}
					if (!(num9 >= num2))
					{
						worldObject = item;
						dist = num8;
						num2 = num9;
					}
				}
			}
		}
		if (_priority != 0)
		{
			WorldObject worldObject5 = Globals.Core.WorldFilter[_priority];
			double num10 = ((worldObject5 == null) ? (-1.0) : CombatEngine.Distance(worldObject5));
			if (((worldObject5 != null) & corpsesOn) && !_done.Contains(worldObject5.Id) && num10 >= 0.0 && num10 <= (double)_s.LootRange && HasProfile && CorpseKillers.Allowed(worldObject5, _s.LootFellowKills, out var _))
			{
				worldObject = worldObject5;
				dist = num10;
			}
			if (worldObject5 == null || _done.Contains(_priority))
			{
				_priority = 0;
			}
		}
		if (worldObject == null && worldObject4 != null)
		{
			worldObject = worldObject4;
			dist = num5;
		}
		if (worldObject2 != null)
		{
			worldObject = worldObject2;
			dist = num;
		}
		if (worldObject == null)
		{
			Looter looter = this;
			string status;
			if (HasProfile)
			{
				if (corpsesOn & autoChestsOn)
				{
					status = "No corpses or chests in range";
				}
				else
				{
					status = (autoChestsOn ? "No chests in range" : "No corpses in range");
				}
			}
			else
			{
				status = "No loot profile loaded";
			}
			looter.Status = status;
			return false;
		}
		_isChest = worldObject.ObjectClass == ObjectClass.Container;
		_chestCheck = false;
		_userCorpse = false;
		_chestLocked = false;
		_pickTries = 0;
		_lockSaid = false;
		if (_isChest && PicksLocks && worldObject.HasIdData && worldObject.Values(BoolValueKey.Locked, false))
		{
			_corpse = worldObject.Id;
			_openTries = 1;
			_weOpened = true;
			Dbg(worldObject.Name + " is locked - picking it");
			PickLock(worldObject);
			return true;
		}
		if (worldObject.Id == _priority)
		{
			_priority = 0;
		}
		_ownCorpse = worldObject2 != null && worldObject.Id == worldObject2.Id;
		_corpse = worldObject.Id;
		_openTries = 0;
		OpenCorpse(worldObject, dist);
		return true;
	}

	private void OpenCorpse(WorldObject corpse, double dist)
	{
		_openTries++;
		if (Globals.Core.Actions.OpenedContainer == corpse.Id)
		{
			if (_openTries == 1)
			{
				_weOpened = false;
			}
			_state = State.Opening;
			_until = DateTime.Now;
			Status = "Reading " + corpse.Name;
			return;
		}
		if (_openTries == 1)
		{
			_weOpened = true;
		}
		Globals.Core.Actions.UseItem(corpse.Id, 0);
		_state = State.Opening;
		_until = DateTime.Now.AddSeconds(2.0 + Math.Max(0.0, dist) * 0.4);
		Status = "Opening " + corpse.Name + " (" + dist.ToString("0") + "m)";
	}

	private void OpeningTick()
	{
		WorldObject worldObject = Globals.Core.WorldFilter[_corpse];
		if (worldObject == null)
		{
			FinishCorpse("gone");
		}
		else if (Globals.Core.Actions.OpenedContainer == _corpse)
		{
			_state = State.Settling;
			_until = DateTime.Now.AddMilliseconds(Tuning.V("CorpseSettleMs"));
			Status = "Reading " + worldObject.Name;
		}
		else if (_isChest && _chestLocked)
		{
			PickLock(worldObject);
		}
		else if (!(DateTime.Now < _until))
		{
			if (_openTries < 2)
			{
				OpenCorpse(worldObject, CombatEngine.Distance(worldObject));
			}
			else if (_isChest && PicksLocks && !_chestCheck && _pickTries < 6)
			{
				Dbg(worldObject.Name + " didn't open - looking at its lock");
				PickLock(worldObject);
			}
			else
			{
				FinishCorpse("couldn't open it");
			}
		}
	}

	private void ReadCorpse()
	{
		_items.Clear();
		foreach (WorldObject item in Globals.Core.WorldFilter.GetByContainer(_corpse))
		{
			_items.Add(item.Id);
		}
		_itemIdx = 0;
		_rescanned = false;
		Dbg(_items.Count + " item" + ((_items.Count == 1) ? "" : "s") + " on the corpse");
		if (_items.Count == 0)
		{
			FinishCorpse("empty");
			return;
		}
		PrefetchIds();
		_state = State.Items;
	}

	private void NextItem()
	{
		if (Globals.Core.Actions.OpenedContainer != _corpse)
		{
			Abort("corpse closed");
			return;
		}
		while (_itemIdx < _items.Count)
		{
			WorldObject worldObject = Globals.Core.WorldFilter[_items[_itemIdx]];
			if (worldObject == null || worldObject.Container != _corpse)
			{
				_itemIdx++;
				continue;
			}
			if (!_ownCorpse && !worldObject.HasIdData && (!_s.LootOnlyRare || !RareFoundNamed(worldObject.Name)) && (_s.LootOnlyRare || NeedsId(worldObject)))
			{
				_idByUs.Add(worldObject.Id);
				_idTries = 1;
				_idTimedOut = false;
				if (!_idAskedAt.ContainsKey(worldObject.Id))
				{
					Util.RequestId(worldObject.Id);
					_idAskedAt[worldObject.Id] = DateTime.Now;
				}
				_state = State.Identifying;
				_until = DateTime.Now.AddSeconds(Tuning.V("IdWaitS"));
				Status = "Identifying " + worldObject.Name;
			}
			else
			{
				_idTimedOut = false;
				Decide(worldObject);
			}
			return;
		}
		if (!_rescanned)
		{
			_rescanned = true;
			int num = 0;
			foreach (WorldObject item in Globals.Core.WorldFilter.GetByContainer(_corpse))
			{
				if (!_items.Contains(item.Id))
				{
					_items.Add(item.Id);
					num++;
				}
			}
			if (num > 0)
			{
				Dbg(num + " more item" + ((num == 1) ? "" : "s") + " arrived late - checking them too");
				PrefetchIds();
				return;
			}
		}
		FinishCorpse(null);
	}

	private void PrefetchIds()
	{
		if (_ownCorpse)
		{
			return;
		}
		if (_idAskedAt.Count > 300)
		{
			_idAskedAt.Clear();
		}
		int num = 0;
		foreach (int item in _items)
		{
			WorldObject worldObject = Globals.Core.WorldFilter[item];
			if (worldObject != null && !worldObject.HasIdData && !_idAskedAt.ContainsKey(item) && (_s.LootOnlyRare || NeedsId(worldObject)))
			{
				_idByUs.Add(item);
				Util.RequestId(item);
				_idAskedAt[item] = DateTime.Now;
				num++;
			}
		}
		if (num > 0)
		{
			Dbg("asked for " + num + " ID" + ((num == 1) ? "" : "s") + " at once");
		}
	}

	private void BuffWaitTick()
	{
		WorldObject worldObject = Globals.Core.WorldFilter[_items[_itemIdx]];
		if (worldObject == null)
		{
			_itemIdx++;
			_state = State.Items;
		}
		else if (!(DateTime.Now < _until) || ItemCompare.LooksBuffed(worldObject) == null)
		{
			Decide(worldObject);
		}
	}

	private void IdentifyingTick()
	{
		WorldObject worldObject = Globals.Core.WorldFilter[_items[_itemIdx]];
		if (worldObject == null)
		{
			_itemIdx++;
			_state = State.Items;
		}
		else if (worldObject.HasIdData)
		{
			Decide(worldObject);
		}
		else if (!(DateTime.Now < _until))
		{
			if (_idTries < (int)Tuning.V("IdTries"))
			{
				_idTries++;
				Dbg("no ID for " + worldObject.Name + " yet - asking again");
				Util.RequestId(worldObject.Id);
				_until = DateTime.Now.AddSeconds(Tuning.V("IdWaitS"));
			}
			else
			{
				_idTimedOut = true;
				Decide(worldObject);
			}
		}
	}

	private void Decide(WorldObject o)
	{
		if (!_ownCorpse && o.HasIdData && ItemCompare.LooksBuffed(o) != null)
		{
			if (_buffItem != o.Id)
			{
				_buffItem = o.Id;
				_buffRetries = 0;
			}
			if (_buffRetries < 3)
			{
				_buffRetries++;
				Dbg(o.Name + " shows buffed numbers - asking for a fresh ID (" + _buffRetries + "/3)");
				_state = State.BuffWait;
				_until = DateTime.Now.AddSeconds(2.0);
				Status = "Re-identifying " + o.Name;
				return;
			}
			Dbg(o.Name + " still shows buffed numbers - judged without its compare");
		}
		UtlRule utlRule = (_ownCorpse ? null : Match(o));
		if (!_ownCorpse && _s.LootRares && (utlRule == null || utlRule.Act == "0") && (LootMatcher.Long(o, 17) > 0 || (!o.HasIdData && RareFoundNamed(o.Name))))
		{
			utlRule = RareRule;
		}
		if (!_ownCorpse && _s.LootQbStamps && (utlRule == null || utlRule.Act == "0"))
		{
			string text = QbStamps.For(o.Name);
			if (text != null)
			{
				utlRule = new UtlRule
				{
					Name = "QB stamp " + text,
					Act = "1"
				};
				Dbg(o.Name + " gives a QB stamp you don't have: " + text);
			}
		}
		if (!_ownCorpse && !_isChest && _s.LootOnlyRare)
		{
			if (LootMatcher.Long(o, 17) <= 0 && !RareFoundNamed(o.Name))
			{
				Dbg("leave " + o.Name + " - not a rare / pristine / ascendant (only rares)");
				_itemIdx++;
				_state = State.Items;
				return;
			}
			utlRule = RareRule;
		}
		if (!_ownCorpse && (utlRule == null || utlRule.Act == "0" || !UnderKeepLimit(utlRule, o)))
		{
			Dbg("leave " + o.Name + (o.HasIdData ? "" : (_idTimedOut ? " (ID never came back)" : " (no ID needed)")) + " - " + ((utlRule == null) ? "no rule matches" : ((utlRule.Act == "0") ? ("rule '" + (utlRule.Name ?? "").Trim() + "' says don't loot") : ("rule '" + (utlRule.Name ?? "").Trim() + "' is at its keep limit"))));
			_itemIdx++;
			_state = State.Items;
		}
		else if ((_isChest && _chestCheck) || _userCorpse)
		{
			WorldObject worldObject = Globals.Core.WorldFilter[_corpse];
			_chestHits.Add(o.Name);
			Util.WriteToChat(((worldObject != null) ? worldObject.Name : (_userCorpse ? "Corpse" : "Chest")) + ": " + ItemReport.Describe(o, utlRule, link: true), 5, _s.IdChatWindow);
			_lootedCount.TryGetValue(_corpse, out var value);
			_lootedCount[_corpse] = value + 1;
			Dbg("chest " + o.Name + " - rule '" + ((utlRule != null) ? (utlRule.Name ?? "").Trim() : "") + "' (check only, left in it)");
			_itemIdx++;
			_state = State.Items;
		}
		else if (Character.AllPacksFreeSlots() <= 0)
		{
			Util.WriteToChat("All your packs are full - can't loot " + o.Name + ". Looting paused for 60s.");
			_packFullUntil = DateTime.Now.AddSeconds(Tuning.V("PackFullPauseS"));
			Abort("pack full");
		}
		else
		{
			Looter looter = this;
			string name = o.Name;
			string text2;
			if (o.HasIdData)
			{
				text2 = "";
			}
			else
			{
				text2 = (_idTimedOut ? " (ID never came back)" : " (no ID needed)");
			}
			looter.Dbg("keep  " + name + text2 + ((utlRule != null) ? (" - rule '" + (utlRule.Name ?? "").Trim() + "'") : ""));
			_moveRule = utlRule;
			_moveTries = 0;
			Move(o);
		}
	}

	private void Move(WorldObject o)
	{
		_moveTries++;
		_lastName = o.Name;
		_lastClass = o.ObjectClass;
		Globals.Core.Actions.MoveItem(o.Id, Globals.Core.CharacterFilter.Id, 0, stack: true);
		_state = State.Moving;
		_until = DateTime.Now.AddSeconds(Tuning.V("ItemWaitS"));
		Status = "Looting " + o.Name;
	}

	private void MovingTick()
	{
		int id = _items[_itemIdx];
		WorldObject worldObject = Globals.Core.WorldFilter[id];
		if (worldObject == null || worldObject.Container != _corpse)
		{
			Announce(worldObject, id);
			_itemIdx++;
			_state = State.Items;
		}
		else if (!(DateTime.Now < _until))
		{
			if (_moveTries < 2)
			{
				Move(worldObject);
				return;
			}
			Util.WriteToChat("Couldn't pick up " + worldObject.Name + ".");
			_itemIdx++;
			_state = State.Items;
		}
	}

	private void Announce(WorldObject o, int id)
	{
		string text = ((o != null) ? ItemReport.Describe(o, _moveRule) : (((_moveRule != null) ? (_moveRule.Name.Trim() + " - ") : "") + (_lastName ?? "item")));
		string text2 = ((o != null) ? ItemReport.Describe(o, null) : (_lastName ?? "item"));
		int num = text2.IndexOf(", ", StringComparison.Ordinal);
		string text3 = null;
		int color = 7;
		if (o != null && _s.IdCompare)
		{
			try
			{
				text3 = ItemCompare.Describe(o, out color);
			}
			catch
			{
				text3 = null;
			}
		}
		Log.Insert(0, new LogEntry
		{
			Time = DateTime.Now.ToString("HH:mm"),
			Rule = ((_moveRule != null) ? _moveRule.Name.Trim() : ""),
			Name = ((num > 0) ? text2.Substring(0, num) : text2),
			Rest = ((num > 0) ? text2.Substring(num + 2) : ""),
			Vs = (text3 ?? ""),
			VsColor = color
		});
		if (Log.Count > 50)
		{
			Log.RemoveAt(Log.Count - 1);
		}
		if (_s.LootAnnounce)
		{
			Util.WriteToChat("Looted: " + ((o != null) ? ItemReport.Describe(o, _moveRule, link: true) : text));
		}
		_lootedCount.TryGetValue(_corpse, out var value);
		_lootedCount[_corpse] = value + 1;
		try
		{
			Session.NoteLoot(_lastClass);
		}
		catch
		{
		}
		try
		{
			Session.NoteLootItem((_moveRule != null) ? _moveRule.Name.Trim() : "", text2, _lastClass, text3, color);
		}
		catch
		{
		}
		if (o != null && _moveRule != null && _moveRule.Act == "2")
		{
			Salvager.Add(id);
		}
	}

	private void FinishCorpse(string why)
	{
		try
		{
			if (_corpse != 0 && _weOpened && Globals.Core.Actions.OpenedContainer == _corpse)
			{
				Globals.Core.Actions.UseItem(_corpse, 0);
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		_weOpened = false;
		if (_corpse != 0)
		{
			if (_isChest)
			{
				_chestIds.Add(_corpse);
				_lastChestId = _corpse;
				_lastChestAt = DateTime.Now;
			}
			_done.Add(_corpse);
			_lootedCount.TryGetValue(_corpse, out var value);
			if (_userCorpse)
			{
				if (_s.CorpseSummary && (why == null || why == "empty") && _chestHits.Count == 0)
				{
					WorldObject wc = Globals.Core.WorldFilter[_corpse];
					Util.WriteToChat(((wc != null) ? wc.Name : "Corpse") + " scanned - No Loot Filter Matches", 5, _s.IdChatWindow);
				}
				_chestHits.Clear();
			}
			else if (_isChest && _chestCheck)
			{
				WorldObject worldObject = Globals.Core.WorldFilter[_corpse];
				if (worldObject != null)
				{
					ItemTracker.SetChest(worldObject, (why == null && value > 0) ? (value + " wanted") : null);
				}
				if (_s.ChestSummary && (why == null || why == "empty") && _chestHits.Count == 0)
				{
					Util.WriteToChat(((worldObject != null) ? worldObject.Name : "Chest") + " scanned - No Loot Filter Matches", 5, _s.IdChatWindow);
				}
				_chestHits.Clear();
			}
			else if (_isChest && _s.ChestSummary && (why == null || why == "empty") && value == 0)
			{
				WorldObject worldObject2 = Globals.Core.WorldFilter[_corpse];
				Util.WriteToChat(((worldObject2 != null) ? worldObject2.Name : "Chest") + " scanned - No Loot Filter Matches", 5, _s.IdChatWindow);
			}
			Dictionary<int, string> result = _result;
			int corpse = _corpse;
			string value2;
			if (_userCorpse && why == null)
			{
				value2 = (_chestHits.Count > 0 || value > 0) ? "Checked" : "Checked - nothing wanted";
			}
			else if (why != null || !_isChest || !_chestCheck)
			{
				if (why != null)
				{
					value2 = ((why == "empty") ? "Empty" : ("Skipped: " + why));
				}
				else
				{
					value2 = ((value > 0) ? ("Looted " + value + " item" + ((value == 1) ? "" : "s")) : "Checked - nothing to keep");
				}
			}
			else
			{
				value2 = ((value > 0) ? (value + " the profiles would take - left in it") : "Checked - nothing the profiles want");
			}
			result[corpse] = value2;
			_doneAt[_corpse] = DateTime.Now;
			if (!_isChest && (why == null || why == "empty"))
			{
				try
				{
					Session.NoteCorpse(value > 0);
				}
				catch
				{
				}
			}
			SaveCorpseLog();
		}
		_corpse = 0;
		_state = State.Idle;
		_next = DateTime.Now.AddSeconds(Tuning.V("AfterCorpseS"));
		Status = ((why == null) ? "Corpse done" : ("Skipped corpse (" + why + ")"));
	}

	private bool UnderKeepLimit(UtlRule rule, WorldObject item)
	{
		if (rule.Act != "10")
		{
			return true;
		}
		if (!int.TryParse(rule.KeepN, out var result))
		{
			result = 1;
		}
		int num = 0;
		foreach (WorldObject item2 in InvCache.All())
		{
			if (LootMatcher.RuleMatches(rule, item2) && (!rule.KeepEach || string.Equals(item2.Name, item.Name, StringComparison.OrdinalIgnoreCase)))
			{
				int num2 = LootMatcher.Long(item2, 218103814);
				num += ((num2 <= 0) ? 1 : num2);
				if (num >= result)
				{
					return false;
				}
			}
		}
		return true;
	}

	public void WarnUnsupported(UtlProfile p)
	{
		if (p == null)
		{
			return;
		}
		foreach (UtlRule rule in p.Rules)
		{
			if (!rule.Off && LootMatcher.UsesUnsupported(rule) && _warnedRules.Add(rule.Name))
			{
				Util.WriteToChat("Loot rule '" + rule.Name.Trim() + "' uses a requirement MelkTank can't check (colour / buffed damage) - it won't match.");
			}
		}
	}
}
