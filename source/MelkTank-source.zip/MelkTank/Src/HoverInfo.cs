using System;
using System.Collections.Generic;
using System.IO;
using System.Numerics;
#if !RETAIL
using ACGodot.DecalShim;
#else
using AcClient;
#endif
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Loot;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public static class HoverInfo
{
	private static Hud _hud;

	private static Settings _s;

	private static int _id;

	private static int _shownId;

	private static DateTime _lastSeen = DateTime.MinValue;

	private static readonly Dictionary<int, DateTime> _asked = new Dictionary<int, DateTime>();

	private static bool _broken;

	public static Action SaveAll;

	private static readonly Vector4 Gold = new Vector4(0.95f, 0.8f, 0.3f, 1f);

	private static readonly Vector4 Grey = new Vector4(0.62f, 0.62f, 0.62f, 1f);

	private static readonly Vector4 Green = new Vector4(0.45f, 0.9f, 0.45f, 1f);

	private static readonly Vector4 Red = new Vector4(0.95f, 0.4f, 0.4f, 1f);

	private static readonly Vector4 Yellow = new Vector4(0.95f, 0.85f, 0.35f, 1f);

	private static readonly Vector4 Orange = new Vector4(0.95f, 0.6f, 0.25f, 1f);

	private static readonly Vector4 Purple = new Vector4(0.75f, 0.55f, 0.95f, 1f);

	private static readonly Vector4 Cyan = new Vector4(0.35f, 0.85f, 0.95f, 1f);

	private static float _px;

	private static float _py;

	private static readonly Vector4 LightGreen = new Vector4(0.7f, 0.95f, 0.55f, 1f);

	private static readonly Vector4 LightRed = new Vector4(0.95f, 0.6f, 0.55f, 1f);

	public static void Init(Settings s)
	{
		_s = s;
		try
		{
			_hud = UBService.Huds.CreateHud("MelkTank Item", BarIcon.Make("Item"));
			_hud.ShowInBar = false;
			_hud.WindowSettings = ImGuiWindowFlags.NoInputs | ImGuiWindowFlags.NoTitleBar | ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoCollapse | ImGuiWindowFlags.AlwaysAutoResize | ImGuiWindowFlags.NoBackground | ImGuiWindowFlags.NoSavedSettings | ImGuiWindowFlags.NoFocusOnAppearing;
			_hud.OnPreRender += OnPreRender;
			_hud.OnRender += OnRender;
			_hud.Visible = false;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			_hud = null;
		}
	}

	public static void Dispose()
	{
		try
		{
			if (_hud != null)
			{
				_hud.OnPreRender -= OnPreRender;
				_hud.OnRender -= OnRender;
				_hud.Dispose();
			}
		}
		catch
		{
		}
		_hud = null;
	}

	public static void Tick()
	{
		if (_hud == null || _s == null)
		{
			return;
		}
		int num = 0;
		if (_s.HoverInfoOn && !_broken)
		{
			try
			{
				num = HoveredItem();
			}
			catch (Exception ex)
			{
				_broken = true;
				Util.LogError(ex);
				Util.WriteToChat("Item hover panel switched off - couldn't read the game's UI (" + ex.Message + ").");
			}
		}
		if (num != 0)
		{
			_id = num;
			_lastSeen = DateTime.Now;
		}
		else if ((DateTime.Now - _lastSeen).TotalMilliseconds > 120.0)
		{
			_id = 0;
		}
		if (_id != 0 && _s.HoverInfoAskId)
		{
			try
			{
				WorldObject worldObject = Globals.Core.WorldFilter[_id];
				if (worldObject != null && !worldObject.HasIdData && (!_asked.TryGetValue(_id, out var value) || (DateTime.Now - value).TotalSeconds > 10.0))
				{
					_asked[_id] = DateTime.Now;
					if (_asked.Count > 500)
					{
						_asked.Clear();
					}
					Util.RequestId(_id);
				}
			}
			catch
			{
			}
		}
		bool flag = _id != 0;
		if (_hud.Visible != flag)
		{
			_hud.Visible = flag;
		}
	}

#if RETAIL
	private unsafe static int HoveredItem()
	{
		UIElementManager* ptr = *(UIElementManager**)8642620;
		if (ptr == null)
		{
			return 0;
		}
		UIElement* ptr2 = ptr->m_pElementLastOver;
		uint hoverItemType = _s.HoverItemType;
		int num = 0;
		while (ptr2 != null && num < 4)
		{
			uint type = (ptr2->m_desc).m_type;
			if (hoverItemType == 0 || type == hoverItemType)
			{
				UIElement_UIItem* ptr3 = (UIElement_UIItem*)ptr2;
				uint itemID = ptr3->itemID;
				if (itemID != 0 && ptr3->weenObj != null && itemID < 4294967280u)
				{
					WorldObject val = Globals.Core.WorldFilter[(int)itemID];
					if (val != null)
					{
						if (hoverItemType == 0 && type != 0)
						{
							_s.HoverItemType = type;
							if (SaveAll != null)
							{
								SaveAll();
							}
						}
						return (int)itemID;
					}
				}
			}
			ptr2 = (UIElement*)((UIRegion*)ptr2)->m_parent;
			num++;
		}
		return 0;
	}
#else
	private static int HoveredItem()
	{
		return Bridge.HoveredItemId();
	}
#endif

	private static void OnPreRender(object sender, EventArgs e)
	{
		try
		{
			Vector2 mousePos = ImGui.GetIO().MousePos;
			Vector2 displaySize = ImGui.GetIO().DisplaySize;
			float num = 440f;
			float num2 = 230f;
			float num3 = mousePos.X + 24f;
			float num4 = mousePos.Y + 12f;
			if (num3 + num > displaySize.X)
			{
				num3 = Math.Max(0f, mousePos.X - num - 16f);
			}
			if (num4 + num2 > displaySize.Y)
			{
				num4 = Math.Max(0f, displaySize.Y - num2);
			}
			_px = num3;
			_py = num4;
			ImGui.SetNextWindowPos(new Vector2(0f, 0f), ImGuiCond.Always);
			ImGui.SetNextWindowSize(new Vector2(1f, 1f), ImGuiCond.Always);
		}
		catch
		{
		}
	}

	private static void OnRender(object sender, EventArgs e)
	{
		long t = Perf.Begin();
		try
		{
			OnRenderInner(sender, e);
		}
		finally
		{
			Perf.Lap("Window: item pop-up", t);
		}
	}

	private static void OnRenderInner(object sender, EventArgs e)
	{
		bool flag = false;
		try
		{
			WorldObject worldObject = ((_id != 0) ? Globals.Core.WorldFilter[_id] : null);
			if (worldObject == null)
			{
				return;
			}
			ImGui.SetNextWindowPos(new Vector2(_px, _py), ImGuiCond.Always);
			ImGui.SetNextWindowBgAlpha(0.92f);
			ImGui.BeginTooltip();
			flag = true;
#if !RETAIL
			// (the game's own little pop-up for it stays away while this one shows)
			try { ACGodot.Combat.ItemSlot.PluginTipShown(); } catch { }
#endif
			ImGui.PushTextWrapPos(430f);
			string text = ItemReport.Describe(worldObject, null);
			int num = text.IndexOf(", ", StringComparison.Ordinal);
			string s = ((num > 0) ? text.Substring(0, num) : text);
			string text2 = ((num > 0) ? text.Substring(num + 2) : "");
			Im.TextColored(Gold, s);
			if (worldObject.Values(LongValueKey.StackCount, 1) > 1)
			{
				ImGui.SameLine();
				Im.TextColored(Grey, "x" + worldObject.Values(LongValueKey.StackCount, 1));
			}
			Looter current = Looter.Current;
			if (_s.HoverLootRule && current != null && current.HasProfile)
			{
				UtlRule utlRule = current.Match(worldObject, out var file);
				string text3 = (string.IsNullOrEmpty(file) ? "" : ("[" + Path.GetFileName(file) + "] "));
				if (utlRule == null)
				{
					Im.TextColored(Grey, "Loot " + text3 + "no rule matches");
				}
				else
				{
					string text4 = ((utlRule.Act == "10") ? ("Keep " + (utlRule.KeepN ?? "1") + (utlRule.KeepEach ? " each" : "")) : UtlSpec.ActionName(utlRule.Act));
					Vector4 col;
					if (utlRule.Act == "0")
					{
						col = Grey;
					}
					else if (utlRule.Act == "1" || utlRule.Act == "10")
					{
						col = Green;
					}
					else if (utlRule.Act == "2")
					{
						col = Orange;
					}
					else
					{
						col = ((utlRule.Act == "3") ? Purple : Cyan);
					}
					Im.TextColored(col, "Loot " + text3 + (utlRule.Name ?? "").Trim() + " - " + text4);
				}
			}
			// (one of the weapons, ammo, wands or shields on the Items tab)
			if (_s.Items != null && _s.Items.Exists((WeaponItem w) => w.Id == worldObject.Id && (w.IsShield || w.Kind == WeaponKind.Caster || w.Kind == WeaponKind.Melee || w.Kind == WeaponKind.Missile || w.Kind == WeaponKind.Ammo)))
			{
				Im.TextColored(Gold, "In Items");
			}
			// (one of the combat pets on the Pets tab - ticked to be summoned, or not)
			Pets.PetRecord petRec = Pets.PetSummoner.Current?.Pets.Find((Pets.PetRecord p) => p.DeviceId == worldObject.Id);
			if (petRec != null)
			{
				Im.TextColored(petRec.Enabled ? Gold : Grey, petRec.Enabled ? "In Pets" : "In Pets (not summoned - unticked)");
			}
			bool? charmOn;
			foreach (string cl in Charms.HoverLines(worldObject, out charmOn))
			{
				Im.TextColored(cl.StartsWith("Status") ? ((charmOn == true) ? Green : Grey) : Cyan, cl);
			}
			if (!worldObject.HasIdData)
			{
				Im.TextColored(Grey, _s.HoverInfoAskId ? "Asking for its ID..." : "Not identified yet");
			}
			if (_s.HoverDetails && text2.Length > 0)
			{
				ImGui.Separator();
				foreach (string item in Group(text2))
				{
					ImGui.TextUnformatted(item);
				}
			}
			bool flag2 = ItemCompare.IsEquipped(worldObject);
			bool flag3 = false;
			bool flag4 = false;
			if (!flag2 && !worldObject.HasIdData && (_s.HoverScore || _s.HoverCompare) && (ItemCompare.IsWeapon(worldObject) || ArmorCompare.IsGear(worldObject)))
			{
				ImGui.Separator();
				Im.TextColored(Grey, "Score and compare once it's identified");
			}
			else if (_s.HoverScore && !flag2)
			{
				// (a weapon compared below gets its score from the comparison - against the slayer you keep for that
				// species too - so the two lines can't disagree)
				string text5 = (_s.HoverCompare && worldObject.HasIdData && ItemCompare.IsWeapon(worldObject) && !ItemInfo.IsAmmo(worldObject) && ItemCompare.EquippedCounterpart(worldObject) != null) ? null : Score(worldObject);
				if (text5 != null)
				{
					ImGui.Separator();
					flag3 = true;
					flag4 = true;
					Im.TextColored(Cyan, text5);
				}
			}
			if (_s.HoverCompare && !flag2 && worldObject.HasIdData)
			{
				string text6 = ItemCompare.Describe(worldObject, out var color, !flag4);
				if (!string.IsNullOrEmpty(text6))
				{
					if (!flag3)
					{
						ImGui.Separator();
					}
					Im.TextColored(_s.HoverColors ? CompareColor(color) : Vector4.One, text6);
					string text7 = ItemCompare.DescribeOffhand(worldObject, out var color2);
					if (!string.IsNullOrEmpty(text7))
					{
						Im.TextColored(_s.HoverColors ? CompareColor(color2) : Vector4.One, text7);
					}
				}
			}
			else if (flag2)
			{
				ImGui.Separator();
				Im.TextColored(Grey, "Equipped");
			}
			ImGui.PopTextWrapPos();
			ImGui.EndTooltip();
			flag = false;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			if (flag)
			{
				try
				{
					ImGui.PopTextWrapPos();
					ImGui.EndTooltip();
					return;
				}
				catch
				{
					return;
				}
			}
		}
	}

	private static Vector4 CompareColor(int c)
	{
		return c switch
		{
			10 => Green, 
			18 => LightGreen, 
			8 => LightRed, 
			15 => Red, 
			_ => Vector4.One, 
		};
	}

	private static string Score(WorldObject o)
	{
		double overall;
		double bestSlayer;
		if (ArmorCompare.IsGear(o))
		{
			if (!ArmorCompare.Estimate(o, out overall, out bestSlayer))
			{
				return null;
			}
			return "Score: mods " + overall.ToString("0") + "% of max | yours " + (overall - bestSlayer).ToString("0") + "% | difference " + ((bestSlayer >= 0.0) ? "+" : "") + bestSlayer.ToString("0") + "%";
		}
		if (ItemCompare.IsWeapon(o) && !ItemInfo.IsAmmo(o))
		{
			if (!ItemCompare.Estimate(o, out overall, out bestSlayer))
			{
				return null;
			}
			return "Score: damage " + ((overall >= 0.0) ? "+" : "") + (overall * 100.0).ToString("0") + "% overall" + ((bestSlayer > -1.0) ? (" | Best slayer " + ((bestSlayer >= 0.0) ? "+" : "") + (bestSlayer * 100.0).ToString("0") + "%") : "");
		}
		return null;
	}

	private static List<string> Group(string s)
	{
		List<string> list = new List<string>();
		int num = 0;
		int num2 = 0;
		for (int i = 0; i < s.Length; i++)
		{
			char c = s[i];
			if (c == '[' || c == '(')
			{
				num++;
			}
			else if ((c == ']' || c == ')') && num > 0)
			{
				num--;
			}
			else if (c == ',' && num == 0 && i + 1 < s.Length && s[i + 1] == ' ')
			{
				list.Add(s.Substring(num2, i - num2));
				num2 = i + 2;
			}
		}
		if (num2 < s.Length)
		{
			list.Add(s.Substring(num2));
		}
		List<string> list2 = new List<string>();
		string text = "";
		foreach (string item in list)
		{
			if (item.StartsWith("BUFFED") || item.StartsWith("Details") || item.StartsWith("Mods") || item.StartsWith("Wield") || item.StartsWith("Ratings"))
			{
				if (text.Length > 0)
				{
					list2.Add(text);
				}
				list2.Add(item);
				text = "";
			}
			else
			{
				if (text.Length > 0 && text.Length + item.Length > 60)
				{
					list2.Add(text);
					text = "";
				}
				text = ((text.Length == 0) ? item : (text + " | " + item));
			}
		}
		if (text.Length > 0)
		{
			list2.Add(text);
		}
		return list2;
	}
}
