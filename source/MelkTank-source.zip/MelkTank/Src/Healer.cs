using System;
using System.Collections.Generic;
using AcClient;
using Decal.Adapter;
using Decal.Adapter.Wrappers;

namespace MelkTank;

public class Healer
{
	private readonly Settings _s;

	private DateTime _nextTryAt = DateTime.MinValue;

	private DateTime _lastWarnAt = DateTime.MinValue;

	private readonly int[] _maxObserved = new int[2];

	private readonly int[] _manualMax = new int[2];

	private int _bucket;

	private bool _kitAnswered;

	private DateTime _kitSentAt = DateTime.MinValue;

	private int _startHealth;

	private DateTime _portalAt = DateTime.MinValue;

	private static readonly TimeSpan PortalWindow = TimeSpan.FromSeconds(60L);

	private static DateTime _nextAsk = DateTime.MinValue;

	private bool _tierKnown;

	private DateTime _tierPendingUntil = DateTime.MinValue;

	private DateTime _lastIgnoredAt = DateTime.MinValue;

	private bool _lastWasKit = true;

	private DateTime _busySince = DateTime.MaxValue;

	private static TimeSpan RetryInterval => Tuning.Ms("HealRetryMs");

	private int _maxObservedCur
	{
		get
		{
			return _maxObserved[_bucket];
		}
		set
		{
			_maxObserved[_bucket] = value;
		}
	}

	private int _manualMaxCur
	{
		get
		{
			return _manualMax[_bucket];
		}
		set
		{
			_manualMax[_bucket] = value;
		}
	}

	private static TimeSpan KitLandTime => Tuning.Sec("KitLandS");

	public bool Active { get; private set; }

	public static int ServerMax { get; private set; }

	public static DateTime ServerMaxAt { get; private set; }

	private bool JustPortaled => DateTime.Now - _portalAt < PortalWindow;

	public int Tries { get; private set; }

	public bool HighTierBucket => _bucket == 1;

	public bool TierKnown => _tierKnown;

	public int LastEffective { get; private set; }

	public void NotePortal()
	{
		_portalAt = DateTime.Now;
		_tierPendingUntil = DateTime.Now.AddSeconds(4.0);
		_tierKnown = false;
		ServerMax = 0;
		_nextAsk = DateTime.Now.AddSeconds(5.0);
	}

	private static void AskServer()
	{
		DateTime now = DateTime.Now;
		if (now < _nextAsk)
		{
			return;
		}
		_nextAsk = now.AddSeconds(30.0);
		int num = 0;
		try
		{
			num = Globals.Core.CharacterFilter.Id;
		}
		catch
		{
		}
		if (num == 0)
		{
			return;
		}
		try
		{
			CM_Combat.Event_QueryHealth((uint)num);
		}
		catch
		{
		}
	}

	public static void OnServerMessage(Message msg)
	{
		if (msg == null || msg.Type != 63408)
		{
			return;
		}
		int num = 0;
		try
		{
			num = Globals.Core.CharacterFilter.Id;
		}
		catch
		{
		}
		if (num == 0)
		{
			return;
		}
		try
		{
			if (WeaponCompare.ReadHealthAny(msg, out var obj2, out var _, out var max) && obj2 == num && max > 0)
			{
				ServerMax = max;
				ServerMaxAt = DateTime.Now;
				return;
			}
			byte[] rawData = msg.RawData;
			if (rawData != null && rawData.Length >= 24 && BitConverter.ToUInt32(rawData, 12) == 448 && BitConverter.ToInt32(rawData, 16) == num)
			{
				float num2 = BitConverter.ToSingle(rawData, 20);
				int health = Globals.Core.CharacterFilter.Health;
				if (num2 > 0.02f && num2 <= 1f && health > 0)
				{
					ServerMax = (int)Math.Round((float)health / num2);
					ServerMaxAt = DateTime.Now;
				}
			}
		}
		catch
		{
		}
	}

	public Healer(Settings s)
	{
		_s = s;
		_portalAt = DateTime.Now;
		_tierPendingUntil = DateTime.Now.AddSeconds(8.0);
		_manualMax[0] = s.MaxHealthLowTier;
		_manualMax[1] = s.MaxHealthHighTier;
	}

	public void SetTier(int tier)
	{
		if (tier >= 0)
		{
			_bucket = ((tier >= 11 && ServerMode.Ilt) ? 1 : 0);
			_tierPendingUntil = DateTime.MinValue;
			if (!_tierKnown)
			{
				_manualMax[0] = _s.MaxHealthLowTier;
				_manualMax[1] = _s.MaxHealthHighTier;
			}
			_tierKnown = true;
		}
	}

	public int RememberedMax(bool highTier)
	{
		return _manualMax[highTier ? 1 : 0];
	}

	public double HealthPercent()
	{
		int cur;
		int max;
		return HealthPercent(out cur, out max);
	}

	public double HealthPercent(out int cur, out int max)
	{
		cur = 0;
		max = 0;
		try
		{
			CharacterFilter characterFilter = Globals.Core.CharacterFilter;
			cur = characterFilter.Health;
			if (cur <= 0)
			{
				return -1.0;
			}
			int num = 0;
			try
			{
				num = characterFilter.EffectiveVital[CharFilterVitalType.Health];
			}
			catch
			{
			}
			if (cur > _maxObservedCur)
			{
				_maxObservedCur = cur;
			}
			LastEffective = num;
			if (ServerMax > 0 && ServerMax >= cur && (DateTime.Now - ServerMaxAt).TotalMinutes < 10.0)
			{
				max = ServerMax;
			}
			else if (_bucket == 0 && num > 0 && num >= cur)
			{
				max = num;
			}
			else if (_manualMaxCur > 0 && _manualMaxCur >= cur)
			{
				max = _manualMaxCur;
			}
			else
			{
				max = ((num >= cur) ? num : _maxObservedCur);
			}
			if (max <= 0)
			{
				return -1.0;
			}
			double num2 = (double)cur * 100.0 / (double)max;
			return (num2 > 100.0) ? 100.0 : num2;
		}
		catch
		{
			return -1.0;
		}
	}

	public void SetMaxToCurrent()
	{
		try
		{
			int manualMaxCur = (_maxObservedCur = Globals.Core.CharacterFilter.Health);
			_manualMaxCur = manualMaxCur;
			if (_tierKnown)
			{
				if (_bucket == 1)
				{
					_s.MaxHealthHighTier = _manualMaxCur;
				}
				else
				{
					_s.MaxHealthLowTier = _manualMaxCur;
				}
			}
		}
		catch
		{
		}
	}

	public bool Tick()
	{
		try
		{
			AskServer();
		}
		catch
		{
		}
		if (!_s.HealEnabled || !HasHealItems(_s))
		{
			Stop();
			return false;
		}
		if (!Active && DateTime.Now < _tierPendingUntil)
		{
			return false;
		}
		double num = HealthPercent();
		if (num < 0.0)
		{
			return Active;
		}
		if (!Active)
		{
			if (num >= (double)_s.HealPercent)
			{
				return false;
			}
			Active = true;
			Tries = 0;
			_nextTryAt = DateTime.MinValue;
			_kitAnswered = false;
			try
			{
				_startHealth = Globals.Core.CharacterFilter.Health;
			}
			catch
			{
				_startHealth = -1;
			}
		}
		else if (num >= (double)_s.HealPercent && Tries > 0 && (_kitAnswered || !_lastWasKit || DateTime.Now - _kitSentAt > KitLandTime))
		{
			Stop();
			return false;
		}
		if (Active && Tries >= 4 && !_kitAnswered && JustPortaled && _lastWasKit)
		{
			int num2 = -2;
			try
			{
				num2 = Globals.Core.CharacterFilter.Health;
			}
			catch
			{
			}
			if (num2 == _startHealth)
			{
				AlreadyFull();
				return false;
			}
		}
		if (num >= (double)_s.HealPercent && Tries > 0)
		{
			return true;
		}
		if (DateTime.Now >= _nextTryAt)
		{
			int num3 = 0;
			try
			{
				num3 = Globals.Core.Actions.BusyState;
			}
			catch
			{
			}
			if (num3 != 0)
			{
				if (_busySince == DateTime.MaxValue)
				{
					_busySince = DateTime.Now;
				}
				if ((DateTime.Now - _busySince).TotalSeconds < 3.0)
				{
					return true;
				}
			}
			_busySince = DateTime.MaxValue;
			_nextTryAt = DateTime.Now + RetryInterval;
			int num4 = FindKit(out var isKit);
			if (num4 == 0)
			{
				if (DateTime.Now - _lastWarnAt > TimeSpan.FromSeconds(10L))
				{
					_lastWarnAt = DateTime.Now;
					Util.WriteToChat("Health " + num.ToString("0") + "% but none of the healing kits / health potions on the Items tab are left in your pack.");
				}
				Stop();
				return false;
			}
			try
			{
				_lastWasKit = isKit;
				if (isKit)
				{
					Globals.Core.Actions.ApplyItem(num4, Globals.Core.CharacterFilter.Id);
					_kitSentAt = DateTime.Now;
					_nextTryAt = DateTime.Now + TimeSpan.FromMilliseconds(Math.Max(RetryInterval.TotalMilliseconds, 1200.0));
				}
				else
				{
					Globals.Core.Actions.UseItem(num4, 0);
					_nextTryAt = DateTime.Now + Tuning.Sec("HealNextTryS");
				}
				Tries++;
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
		}
		return true;
	}

	public void OnChat(string text)
	{
		if (Active)
		{
			if (IsHealLine(text) || text.IndexOf("too busy", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("fail", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				_kitAnswered = true;
			}
			if (text.StartsWith("You heal yourself", StringComparison.OrdinalIgnoreCase))
			{
				Stop();
			}
			else if (text.IndexOf("full health", StringComparison.OrdinalIgnoreCase) >= 0 && AboutMe(text))
			{
				AlreadyFull();
			}
		}
	}

	public void AlreadyFull()
	{
		if (!Active)
		{
			return;
		}
		double num = HealthPercent(out var cur, out var max);
		if (!JustPortaled && num >= 0.0 && num < 80.0)
		{
			if (DateTime.Now - _lastIgnoredAt > TimeSpan.FromSeconds(30L))
			{
				_lastIgnoredAt = DateTime.Now;
				Util.WriteToChat("Ignored an 'already at full health' at " + cur + "/" + max + " - not right after a portal, so max health stays.");
			}
		}
		else
		{
			SetMaxToCurrent();
			Stop();
			Util.WriteToChat("Already at full health - max health set to " + Globals.Core.CharacterFilter.Health + " (Max = now).");
		}
	}

	public static bool AboutMe(string text)
	{
		string text2 = "";
		try
		{
			text2 = Globals.Core.CharacterFilter.Name ?? "";
		}
		catch
		{
		}
		return text.IndexOf("You are", StringComparison.OrdinalIgnoreCase) >= 0 || (text2.Length > 0 && text.IndexOf(text2, StringComparison.OrdinalIgnoreCase) >= 0);
	}

	public static bool IsHealLine(string text)
	{
		return text.IndexOf("heal yourself", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("healing kit", StringComparison.OrdinalIgnoreCase) >= 0;
	}

	private void Stop()
	{
		Active = false;
		Tries = 0;
	}

	public static bool HasHealItems(Settings s)
	{
		if (s.HealKitId != 0)
		{
			return true;
		}
		foreach (WeaponItem item in s.Items)
		{
			if (item.Kind == WeaponKind.HealKit || item.Kind == WeaponKind.Health)
			{
				return true;
			}
		}
		return false;
	}

	private int FindKit(out bool isKit)
	{
		isKit = true;
		try
		{
			List<WeaponItem> list = new List<WeaponItem>();
			foreach (WeaponItem item in _s.Items)
			{
				if (item.Kind == WeaponKind.HealKit || item.Kind == WeaponKind.Health)
				{
					list.Add(item);
				}
			}
			if (list.Count == 0 && _s.HealKitId != 0)
			{
				list.Add(new WeaponItem
				{
					Id = _s.HealKitId,
					Name = _s.HealKitName,
					Kind = WeaponKind.HealKit
				});
			}
			foreach (WeaponItem item2 in list)
			{
				int num = 0;
				WorldObject worldObject = ((item2.Id != 0) ? Globals.Core.WorldFilter[item2.Id] : null);
				if (worldObject != null && InPack(item2.Id))
				{
					num = item2.Id;
				}
				else
				{
					foreach (WorldObject item3 in InvCache.All())
					{
						if (string.Equals(item3.Name, item2.Name, StringComparison.OrdinalIgnoreCase))
						{
							num = item3.Id;
							worldObject = item3;
							break;
						}
					}
				}
				if (num == 0)
				{
					continue;
				}
				item2.Id = num;
				if (item2.Kind == WeaponKind.HealKit)
				{
					_s.HealKitId = num;
				}
				isKit = item2.Kind == WeaponKind.HealKit || worldObject.ObjectClass == ObjectClass.HealingKit || item2.Name.IndexOf("kit", StringComparison.OrdinalIgnoreCase) >= 0;
				return num;
			}
		}
		catch
		{
		}
		return 0;
	}

	private static bool InPack(int id) => InvCache.Has(id);
}
