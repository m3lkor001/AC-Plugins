using System;

namespace MelkTank;

public static class SpellBook
{
	public static SpellLevel Resolve(string familyKey, bool wantLevel1)
	{
		if (familyKey == null)
		{
			return null;
		}
		if (!SpellData.Families.TryGetValue(familyKey, out var value))
		{
			return null;
		}
		if (ServerMode.AllLevels)
		{
			return SpellLevels.BestOf(value);
		}
		if (wantLevel1)
		{
			for (int i = 0; i < value.Levels.Length; i++)
			{
				if (IsKnown(value.Levels[i]))
				{
					return value.Levels[i];
				}
			}
		}
		else
		{
			for (int num = value.Levels.Length - 1; num >= 0; num--)
			{
				if (IsKnown(value.Levels[num]))
				{
					return value.Levels[num];
				}
			}
		}
		return null;
	}

	public static SpellLevel ResolveRing(string familyKey, bool level6)
	{
		if (familyKey == null)
		{
			return null;
		}
		if (!SpellData.Families.TryGetValue(familyKey, out var value))
		{
			return null;
		}
		SpellLevel spellLevel = value.Levels[5];
		SpellLevel spellLevel2 = value.Levels[6];
		SpellLevel spellLevel3 = (level6 ? spellLevel : spellLevel2);
		SpellLevel spellLevel4 = (level6 ? spellLevel2 : spellLevel);
		if (ServerMode.AllLevels)
		{
			// (the one asked for first - "level 1 rings" is the first ring, not the II - then the other if it can't be cast)
			if (spellLevel3 != null && SpellLevels.Castable(spellLevel3.Id, out var why))
			{
				return spellLevel3;
			}
			if (spellLevel4 != null && SpellLevels.Castable(spellLevel4.Id, out why))
			{
				return spellLevel4;
			}
		}
		if (IsKnown(spellLevel3))
		{
			return spellLevel3;
		}
		if (IsKnown(spellLevel4))
		{
			return spellLevel4;
		}
		return null;
	}

	public static bool IsKnown(SpellLevel s)
	{
		if (s == null)
		{
			return false;
		}
		try
		{
			return Globals.Core.CharacterFilter.IsSpellKnown(s.Id) && !SpellLevels.IsRefused(s.Id);
		}
		catch
		{
			return false;
		}
	}

	public static TimeSpan Duration(SpellLevel s, Settings settings)
	{
		if (s == null || s.BaseDurationSeconds <= 0)
		{
			return TimeSpan.Zero;
		}
		return TimeSpan.FromSeconds((float)s.BaseDurationSeconds * settings.DebuffMultiplier);
	}

	public static SpellLevel FindByName(string name)
	{
		foreach (SpellFamily value in SpellData.Families.Values)
		{
			SpellLevel[] levels = value.Levels;
			foreach (SpellLevel spellLevel in levels)
			{
				if (spellLevel != null && string.Equals(spellLevel.Name, name, StringComparison.OrdinalIgnoreCase))
				{
					return spellLevel;
				}
			}
		}
		return null;
	}
}
