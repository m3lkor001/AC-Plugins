using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

namespace MelkTank;

public static class Catcher
{
	public class Trigger
	{
		public bool On;

		public string Name;

		public string Pattern;

		public Regex Rx;
	}

	public static readonly List<Trigger> Triggers = new List<Trigger>();

	public static readonly List<string> Lines = new List<string>();

	public static int Seq;

	public const int Keep = 500;

	public static string Problem = "";

	private static DateTime _fileStamp = DateTime.MinValue;

	private static DateTime _nextCheck = DateTime.MinValue;

	private static bool _added;

	private const string Default = "# MelkTank: chat lines to catch (Debug tab > Caught messages, and MelkTank_Caught.txt).\r\n# One per line: on or off, a name, then the pattern - separated by a tab or two or more spaces.\r\n# The pattern is a regular expression (case doesn't matter). Saved changes are picked up within 2 s.\r\non\tchamber\tchamber\r\non\tconfirm\tare you sure\r\non\taetheria\t(hammer|aetheria)\r\noff\tbank\t^\\[BANK\\]\r\non\tfellow\t^\\[Fellowship\\]\r\non\tallegiance\t^\\[Allegiance\\]\r\n# 'login' is special: every chat line for 40 s after picking a character (its pattern isn't used)\r\noff\tlogin\t.\r\n";

	private static readonly Regex Split = new Regex("\\t+| {2,}");

	private static DateTime _loginUntil = DateTime.Now.AddSeconds(20.0);

	private static string TriggerFile => Util.FullPath("MelkTank_Catch.txt");

	private static string LogFile => Util.FullPath("MelkTank_Caught.txt");

	public static void Tick()
	{
		if (DateTime.Now < _nextCheck)
		{
			return;
		}
		_nextCheck = DateTime.Now.AddSeconds(2.0);
		try
		{
			string triggerFile = TriggerFile;
			if (!File.Exists(triggerFile))
			{
				File.WriteAllText(triggerFile, "# MelkTank: chat lines to catch (Debug tab > Caught messages, and MelkTank_Caught.txt).\r\n# One per line: on or off, a name, then the pattern - separated by a tab or two or more spaces.\r\n# The pattern is a regular expression (case doesn't matter). Saved changes are picked up within 2 s.\r\non\tchamber\tchamber\r\non\tconfirm\tare you sure\r\non\taetheria\t(hammer|aetheria)\r\noff\tbank\t^\\[BANK\\]\r\non\tfellow\t^\\[Fellowship\\]\r\non\tallegiance\t^\\[Allegiance\\]\r\n# 'login' is special: every chat line for 40 s after picking a character (its pattern isn't used)\r\noff\tlogin\t.\r\n");
			}
			else if (!_added)
			{
				_added = true;
				string text = File.ReadAllText(triggerFile);
				string text2 = "";
				if (!Regex.IsMatch(text, "^\\s*(on|off)\\s+fellow\\s", RegexOptions.IgnoreCase | RegexOptions.Multiline))
				{
					text2 += "on\tfellow\t^\\[Fellowship\\]\r\n";
				}
				if (!Regex.IsMatch(text, "^\\s*(on|off)\\s+allegiance\\s", RegexOptions.IgnoreCase | RegexOptions.Multiline))
				{
					text2 += "on\tallegiance\t^\\[Allegiance\\]\r\n";
				}
				if (text2.Length > 0)
				{
					File.AppendAllText(triggerFile, (text.EndsWith("\n") ? "" : "\r\n") + text2);
				}
			}
			DateTime lastWriteTimeUtc = File.GetLastWriteTimeUtc(triggerFile);
			if (!(lastWriteTimeUtc == _fileStamp))
			{
				_fileStamp = lastWriteTimeUtc;
				Load(File.ReadAllLines(triggerFile));
			}
		}
		catch (Exception ex)
		{
			Problem = ex.Message;
		}
	}

	private static void Load(string[] lines)
	{
		List<Trigger> list = new List<Trigger>();
		List<string> list2 = new List<string>();
		foreach (string text in lines)
		{
			string text2 = text.Trim();
			if (text2.Length == 0 || text2.StartsWith("#"))
			{
				continue;
			}
			string[] array = Split.Split(text2, 3);
			if (array.Length < 3)
			{
				list2.Add(text2);
				continue;
			}
			Trigger trigger = new Trigger
			{
				On = array[0].Trim().Equals("on", StringComparison.OrdinalIgnoreCase),
				Name = array[1].Trim(),
				Pattern = array[2].Trim()
			};
			try
			{
				trigger.Rx = new Regex(trigger.Pattern, RegexOptions.IgnoreCase);
			}
			catch
			{
				list2.Add(text2);
				continue;
			}
			list.Add(trigger);
		}
		lock (Triggers)
		{
			Triggers.Clear();
			Triggers.AddRange(list);
		}
		Problem = ((list2.Count > 0) ? ("couldn't read: " + string.Join(" | ", list2.ToArray())) : "");
	}

	public static void LoginStarted()
	{
		DateTime dateTime = DateTime.Now.AddSeconds(40.0);
		if (dateTime > _loginUntil)
		{
			_loginUntil = dateTime;
		}
	}

	public static void OnChat(string text)
	{
		if (string.IsNullOrEmpty(text))
		{
			return;
		}
		if (DateTime.Now < _loginUntil && IsOn("login"))
		{
			Add("login", text);
			return;
		}
		List<string> list = null;
		lock (Triggers)
		{
			foreach (Trigger trigger in Triggers)
			{
				if (trigger.On && trigger.Rx != null && !trigger.Name.Equals("login", StringComparison.OrdinalIgnoreCase) && trigger.Rx.IsMatch(text))
				{
					(list ?? (list = new List<string>())).Add(trigger.Name);
				}
			}
		}
		if (list != null)
		{
			Add(string.Join(",", list.ToArray()), text);
		}
	}

	public static bool IsOn(string name)
	{
		lock (Triggers)
		{
			foreach (Trigger trigger in Triggers)
			{
				if (trigger.On && trigger.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
				{
					return true;
				}
			}
		}
		return false;
	}

	public static void Note(string name, string text)
	{
		int num = name.IndexOf('-');
		if (IsOn((num > 0) ? name.Substring(0, num) : name))
		{
			Add(name, text);
		}
	}

	public static void Add(string name, string text)
	{
		string text2 = DateTime.Now.ToString("MM-dd HH:mm:ss") + "  [" + name + "]  " + text.Replace("\r", " ").Replace("\n", " | ");
		lock (Lines)
		{
			Lines.Add(text2);
			if (Lines.Count > 500)
			{
				Lines.RemoveRange(0, Lines.Count - 500);
			}
			Seq++;
		}
		try
		{
			File.AppendAllText(LogFile, text2 + "\r\n");
		}
		catch
		{
		}
	}

	public static void SetOn(Trigger t, bool on)
	{
		t.On = on;
		try
		{
			string[] array = File.ReadAllLines(TriggerFile);
			for (int i = 0; i < array.Length; i++)
			{
				string text = array[i].Trim();
				if (text.Length != 0 && !text.StartsWith("#"))
				{
					string[] array2 = Split.Split(text, 3);
					if (array2.Length >= 3 && array2[1].Trim() == t.Name && array2[2].Trim() == t.Pattern)
					{
						array[i] = (on ? "on" : "off") + "\t" + t.Name + "\t" + t.Pattern;
					}
				}
			}
			File.WriteAllLines(TriggerFile, array);
			_fileStamp = File.GetLastWriteTimeUtc(TriggerFile);
		}
		catch (Exception ex)
		{
			Problem = ex.Message;
		}
	}
}
