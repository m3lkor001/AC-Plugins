using System.Collections.Generic;

namespace MelkTank;

public class AreaLink
{
	public string Name = "";

	public List<int> Landblocks = new List<int>();

	public string Monster = "";

	public string Extra1 = "";

	public string Extra2 = "";

	public string Nav = "";

	public bool NavOn;

	public int NavMode = -1;

	public string NavRoute = "";

	public bool LootGeneral = true;

	public string[] LootFiles = new string[5] { "", "", "", "", "" };

	public bool[] LootOns = new bool[5];
}
