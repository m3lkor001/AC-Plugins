using System;

namespace MelkTank;

public static class Slots
{
	public static readonly Slot[] All = (Slot[])Enum.GetValues(typeof(Slot));

	public static readonly string[] Labels = new string[15]
	{
		"F", "B", "G", "I", "Y", "V", "A", "R", "S", "WC",
		"FC", "Cp", "DC", "Cs", "NF"
	};

	public static readonly string[] Tooltips = new string[15]
	{
		"Fester Other (lower healing)", "Defenselessness Other (lower missile defense)", "Vulnerability Other (lower melee defense)", "Imperil Other (lower armor)", "Magic Yield Other (lower magic defense)", "Element vulnerability (uses Ex. Vuln, else Dmg type)", "Attack. In magic: arcs (bolts if 'Bolts instead of arcs' is ticked on the Main tab) - usually off when R or S is on.\nWith a melee weapon or bow: attacking it at all - unticked, it isn't attacked with them", "Attack with rings when enough monsters are close (Main tab), otherwise arc/streak", "Attack with streaks", "Weakening Curse (DoT)",
		"Festering Curse (DoT)", "Corruption (DoT)", "Destructive Curse (DoT)", "Corrosion (DoT)", "Nether Fracture (T11+, Pandemic charm): prime it with Corrosion, Corruption and Destructive Curse (cast even if\nCs / Cp / DC aren't ticked), then Nether Streak at it after the delay - Settings > Debuffs / DoTs"
	};

	public static bool IsVuln(Slot s)
	{
		return s <= Slot.Vuln;
	}

	public static bool IsWarShape(Slot s)
	{
		return s == Slot.Arc || s == Slot.Ring || s == Slot.Streak;
	}

	public static bool IsDot(Slot s)
	{
		return s >= Slot.WeakeningCurse && s <= Slot.Corrosion;
	}

	public static bool IsPrime(Slot s)
	{
		return s == Slot.Corruption || s == Slot.DestructiveCurse || s == Slot.Corrosion;
	}

	public static string FamilyKeyForDot(Slot s)
	{
		return s switch
		{
			Slot.WeakeningCurse => "WeakeningCurse", 
			Slot.FesteringCurse => "FesteringCurse", 
			Slot.Corruption => "Corruption", 
			Slot.DestructiveCurse => "DestructiveCurse", 
			Slot.Corrosion => "Corrosion", 
			_ => null, 
		};
	}

	public static string FamilyKeyForVuln(Slot s, DmgType element)
	{
		return s switch
		{
			Slot.Fester => "Fester", 
			Slot.Broadside => "Broadside", 
			Slot.Gravity => "Gravity", 
			Slot.Imperil => "Imperil", 
			Slot.Yield => "Yield", 
			Slot.Vuln => element switch
			{
				DmgType.Fire => "VulnFire", 
				DmgType.Cold => "VulnCold", 
				DmgType.Acid => "VulnAcid", 
				DmgType.Lightning => "VulnLightning", 
				DmgType.Blade => "VulnBlade", 
				DmgType.Pierce => "VulnPierce", 
				DmgType.Bludgeon => "VulnBludgeon", 
				_ => null, 
			}, 
			_ => null, 
		};
	}

	public static string AttackFamilyKey(string shape, DmgType element)
	{
		string text;
		switch (element)
		{
		case DmgType.Void:
			text = "Void";
			break;
		case DmgType.Fire:
			text = "Fire";
			break;
		case DmgType.Cold:
			text = "Cold";
			break;
		case DmgType.Acid:
			text = "Acid";
			break;
		case DmgType.Lightning:
			text = "Lightning";
			break;
		case DmgType.Blade:
			text = "Blade";
			break;
		case DmgType.Pierce:
			text = "Pierce";
			break;
		case DmgType.Bludgeon:
			text = "Bludgeon";
			break;
		default:
			return null;
		}
		return shape + text;
	}
}
