using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using MelkTank.Loot;

namespace MelkTank;

/// <summary>
/// A whole vendor visit, as one route step / meta action / command: find the NPC (exact name, nearest), open its shop
/// and wait until it's really open, sell what the profile's Sell rules catch (Keep rules protect), make the money up
/// (trade notes, off Infinite Leaftide), buy up to each Keep-up-to rule's count, bank the change (notes - or /b d on
/// Infinite Leaftide), and say in one line how it went. Waits on what the server does, not on fixed timers.
/// </summary>
public class VendorRun
{
	public enum Result
	{
		None,
		Success,
		Partial,
		Failed
	}

	private enum State
	{
		Idle,
		Opening,
		Selling,
		Splitting,
		CashingNotes,
		Buying,
		Banking
	}

	private class Buy
	{
		public WorldObject Ware;
		public string Name;
		public int Want;
		public int Have;
		public int Count;
		public long Each;
	}

	private class NoteStack
	{
		public int Id;
		public string Name;
		public long Each;
		public int Count;
	}

	public static VendorRun I;

	public static Result Last = Result.None;

	public static DateTime LastAt = DateTime.MinValue;

	public static string LastSummary = "";

	public static string LastProfile = "";

	public static string LastVendor = "";

	private readonly Settings _s;

	private readonly Func<string> _lootDir;

	private readonly Action<string> _log;

	private State _state;

	private DateTime _until;

	private int _tries;

	private string _npcName = "";

	private string _profileName = "";

	private bool _dry;

	private WorldObject _npc;

	private UtlProfile _profile;

	private string _profileFile = "";

	private readonly List<int> _selling = new List<int>();

	private readonly List<Buy> _buys = new List<Buy>();

	private readonly List<string> _missing = new List<string>();

	private readonly List<NoteStack> _cash = new List<NoteStack>();

	private readonly List<int> _splitWant = new List<int>();

	private HashSet<int> _splitBefore;

	private long _startWealth;

	private long _coinsBefore;

	private long _soldFor;

	private int _soldCount;

	private int _notesCashed;

	private long _cashedEach;

	private int _notesBanked;

	private long _bankEach;

	private bool _short;

	private Dictionary<string, int> _countsBefore;

	public bool Busy => _state != State.Idle;

	public string Status { get; private set; } = "";

	public VendorRun(Settings s, Func<string> lootDir, Action<string> log)
	{
		_s = s;
		_lootDir = lootDir;
		_log = log;
		I = this;
	}

	private static CoreManager Core => CoreManager.Current;

	private static bool Ilt => ServerMode.Ilt;

	// ── starting and stopping ──

	public bool Start(string npc, string profile, bool dry)
	{
		npc = (npc ?? "").Trim();
		if (npc.Length == 0)
		{
			Util.WriteToChat("Vendor: say which NPC (its exact name).");
			return false;
		}
		Reset();
		_npcName = npc;
		_profileName = (profile ?? "").Trim();
		_dry = dry || _s.VendorDryRun;
		_npc = FindNpc(npc);
		if (_npc == null)
		{
			Finish(Result.Failed, npc + " isn't nearby (looked for that exact name).");
			return false;
		}
		_profile = ResolveProfile(_profileName, _npc.Name, out _profileFile);
		if (_profile == null)
		{
			Finish(Result.Failed, "no vendor profile " + (_profileName.Length > 0 ? ("called " + _profileName) : ("named after " + _npc.Name)) + " (looked in " + string.Join(", ", ProfileDirs().Select(Short).ToArray()) + ").");
			return false;
		}
		LastProfile = _profileFile;
		Say("using profile " + Short(_profileFile) + (_dry ? " - dry run, nothing is traded" : ""));
		_state = State.Opening;
		_tries = 0;
		_until = DateTime.MinValue;
		Status = "opening " + _npc.Name;
		return true;
	}

	private int _seenShop;

	/// <summary>Auto-vendor: when a shop opens (by you, a route or anything else) and there's a vendor profile named after
	/// that vendor, the visit runs by itself. Only on the shop opening - not again while it stays open.</summary>
	public void Watch()
	{
		int num = 0;
		try
		{
			num = Core.Actions.VendorId;
		}
		catch
		{
		}
		if (num == _seenShop)
		{
			return;
		}
		_seenShop = num;
		if (num == 0 || Busy || !_s.VendorAutoOnOpen)
		{
			return;
		}
		WorldObject worldObject = null;
		try
		{
			worldObject = Core.WorldFilter[num];
		}
		catch
		{
		}
		if (worldObject != null && ResolveProfile("", worldObject.Name, out var _) != null)
		{
			Util.WriteToChat("Vendor " + ShortName(worldObject.Name) + ": shop opened - auto-vendoring.");
			Start(worldObject.Name, "", dry: false);
		}
	}

	public void Abort(string why)
	{
		if (Busy)
		{
			Finish(Result.Failed, "stopped (" + why + ").");
		}
	}

	private void Reset()
	{
		_state = State.Idle;
		_selling.Clear();
		_buys.Clear();
		_missing.Clear();
		_cash.Clear();
		_splitWant.Clear();
		_soldFor = 0L;
		_soldCount = 0;
		_notesCashed = 0;
		_notesBanked = 0;
		_cashedEach = 0L;
		_bankEach = 0L;
		_short = false;
		_countsBefore = null;
	}

	// ── each tick ──

	public void Tick()
	{
		if (!Busy)
		{
			return;
		}
		try
		{
			Step();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			Finish(Result.Failed, "something went wrong: " + ex.Message);
		}
	}

	private void Step()
	{
		DateTime now = DateTime.Now;
		switch (_state)
		{
		case State.Opening:
			if (ShopOpen())
			{
				_startWealth = Coins() + NotesValue();
				_coinsBefore = Coins();
				PlanSales();
				if (_dry)
				{
					DryReport();
					return;
				}
				if (_selling.Count > 0)
				{
					foreach (int item in _selling)
					{
						Core.Actions.VendorAddSellList(item);
					}
					Core.Actions.VendorSellAll();
					_state = State.Selling;
					_until = now.AddSeconds(Tuning.V("VendorWaitS"));
					Status = "selling " + _selling.Count + " item" + ((_selling.Count == 1) ? "" : "s");
					_log("VENDOR sell " + _selling.Count + " items to " + _npc.Name);
				}
				else
				{
					AfterSales();
				}
			}
			else if (now >= _until)
			{
				if (_tries >= 3)
				{
					Finish(Result.Failed, "the shop didn't open (tried " + _tries + " times).");
					return;
				}
				_tries++;
				_npc = FindNpc(_npcName) ?? _npc;
				try
				{
					Core.Actions.SelectItem(_npc.Id);
					Core.Actions.UseItem(_npc.Id, 0);
				}
				catch (Exception ex)
				{
					Util.LogError(ex);
				}
				_until = now.AddSeconds(Tuning.V("VendorOpenS"));
				Status = "opening " + _npc.Name + " (try " + _tries + ")";
				_log("VENDOR use " + _npc.Name + " (try " + _tries + ")");
			}
			break;
		case State.Selling:
			if (_selling.All((int id) => !InPack(id)) || now >= _until)
			{
				_soldCount = _selling.Count((int id) => !InPack(id));
				_soldFor = Math.Max(0L, Coins() - _coinsBefore);
				AfterSales();
			}
			break;
		case State.Splitting:
		{
			NoteStack noteStack = NewSplitStack();
			if (noteStack != null || now >= _until)
			{
				if (noteStack != null)
				{
					int idx = _splitWant[0];
					_cash[idx] = noteStack;
				}
				_splitWant.RemoveAt(0);
				NextSplitOrCash();
			}
			break;
		}
		case State.CashingNotes:
			if (_cash.All((NoteStack n) => !InPack(n.Id)) || now >= _until)
			{
				foreach (NoteStack item2 in _cash)
				{
					if (!InPack(item2.Id))
					{
						_notesCashed += item2.Count;
						_cashedEach = item2.Each;
					}
				}
				DoBuys();
			}
			break;
		case State.Buying:
			if (BuysArrived() || now >= _until)
			{
				Bank();
			}
			break;
		case State.Banking:
			if (Coins() < _coinsBefore || now >= _until)
			{
				if (Coins() < _coinsBefore)
				{
					_notesBanked = (int)Math.Max(0L, Math.Round((double)(_coinsBefore - Coins()) / (double)NoteCost(_bankEach)));
				}
				Done();
			}
			break;
		}
	}

	// ── selling ──

	private void PlanSales()
	{
		_selling.Clear();
		foreach (WorldObject item in InvCache.All())
		{
			if (Sellable(item) && SellVerdict(item) == "sell")
			{
				_selling.Add(item.Id);
			}
		}
	}

	private bool Sellable(WorldObject o)
	{
		if (o == null || o.ObjectClass == ObjectClass.Money || IsNote(o) || o.ObjectClass == ObjectClass.Container || o.ObjectClass == ObjectClass.Foci)
		{
			return false;
		}
		if (o.Values(LongValueKey.EquippedSlots, 0) != 0 || o.Values(LongValueKey.Wielder, 0) != 0)
		{
			return false;
		}
		if (o.Values(StringValueKey.Inscription, "").Length > 0)
		{
			return false;
		}
		return true;
	}

	/// <summary>What the profile says of an item in the packs: "keep" (a Keep rule - never sold, whatever else matches),
	/// "sell", or "" (nothing to do with it).</summary>
	private string SellVerdict(WorldObject o)
	{
		bool flag = false;
		foreach (UtlRule rule in _profile.Rules)
		{
			if (!rule.Off && !rule.IsSection && (rule.Act == "1" || rule.Act == "3") && LootMatcher.RuleMatches(rule, o))
			{
				if (rule.Act == "1")
				{
					return "keep";
				}
				flag = true;
			}
		}
		return flag ? "sell" : "";
	}

	private void AfterSales()
	{
		PlanBuys();
		long num = _buys.Sum((Buy b) => b.Each * b.Count);
		long num2 = Coins();
		if (!Ilt && num > num2 && _s.VendorPayWithNotes)
		{
			PlanNotes(num - num2);
			if (_cash.Count > 0)
			{
				NextSplitOrCash();
				return;
			}
		}
		DoBuys();
	}

	// ── buying ──

	private void PlanBuys()
	{
		_buys.Clear();
		_missing.Clear();
		Vendor vendor = Core.WorldFilter.OpenVendor;
		List<WorldObject> list = new List<WorldObject>();
		if (vendor != null)
		{
			foreach (WorldObject item in vendor)
			{
				list.Add(item);
			}
		}
		float rate = (vendor != null && vendor.SellRate > 0f) ? vendor.SellRate : 1f;
		foreach (UtlRule rule in _profile.Rules)
		{
			if (rule.Off || rule.IsSection || rule.Act != "10")
			{
				continue;
			}
			if (!int.TryParse(rule.KeepN, out var result))
			{
				result = 1;
			}
			List<WorldObject> list2 = list.Where((WorldObject w) => LootMatcher.RuleMatches(rule, w)).ToList();
			if (list2.Count == 0)
			{
				_missing.Add(RuleLabel(rule));
				continue;
			}
			// (keep each: up to N of every ware it catches; otherwise N altogether, of the first ware that matches)
			foreach (WorldObject ware in rule.KeepEach ? list2 : list2.Take(1).ToList())
			{
				int num = rule.KeepEach ? CountInPacks(rule, ware.Name) : CountInPacks(rule, null);
				int num2 = result - num;
				if (num2 > 0 && !_buys.Exists((Buy b) => b.Ware.Id == ware.Id))
				{
					long each = PriceOf(ware, rate);
					_buys.Add(new Buy
					{
						Ware = ware,
						Name = ware.Name,
						Want = num2,
						Have = num,
						Count = num2,
						Each = each
					});
				}
			}
		}
		// what may be spent: the per-visit limit, and (off Infinite Leaftide) what's carried - pyreals, notes if they
		// may pay - above the money floor
		long num3 = ((_s.VendorMaxSpend > 0) ? _s.VendorMaxSpend : long.MaxValue);
		if (!Ilt)
		{
			long num4 = Coins() + (_s.VendorPayWithNotes ? NotesValue() : 0L);
			long num5 = Coins() + NotesValue() - _s.VendorFloor;
			num3 = Math.Min(num3, Math.Min(num4, num5));
		}
		long num6 = Math.Max(0L, num3);
		foreach (Buy buy in _buys)
		{
			int num7 = (int)Math.Min(buy.Count, (buy.Each > 0) ? (num6 / buy.Each) : buy.Count);
			if (num7 < buy.Count)
			{
				_short = true;
			}
			buy.Count = num7;
			num6 -= num7 * buy.Each;
		}
		_buys.RemoveAll((Buy b) => b.Count <= 0);
	}

	private void DoBuys()
	{
		_countsBefore = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
		foreach (Buy buy in _buys)
		{
			_countsBefore[buy.Name] = CountByName(buy.Name);
		}
		_coinsBefore = Coins();
		if (_buys.Count == 0)
		{
			Bank();
			return;
		}
		Core.Actions.VendorClearBuyList();
		foreach (Buy buy2 in _buys)
		{
			Core.Actions.VendorAddBuyList(buy2.Ware.Id, buy2.Count);
		}
		Core.Actions.VendorBuyAll();
		_state = State.Buying;
		_until = DateTime.Now.AddSeconds(Tuning.V("VendorWaitS"));
		Status = "buying " + string.Join(", ", _buys.Select((Buy b) => b.Name + " x" + b.Count).ToArray());
		_log("VENDOR buy " + Status.Substring(7));
	}

	private bool BuysArrived()
	{
		foreach (Buy buy in _buys)
		{
			if (CountByName(buy.Name) - _countsBefore[buy.Name] < buy.Count)
			{
				return false;
			}
		}
		return true;
	}

	// ── trade notes: cashing them to pay, buying them to bank the change ──

	private void PlanNotes(long shortBy)
	{
		_cash.Clear();
		List<NoteStack> list = Notes().OrderBy((NoteStack n) => n.Each).ToList();
		long num = shortBy;
		foreach (NoteStack item in list)
		{
			if (num <= 0)
			{
				break;
			}
			int num2 = (int)Math.Min(item.Count, (num + item.Each - 1) / item.Each);
			num -= num2 * item.Each;
			_cash.Add(new NoteStack
			{
				Id = item.Id,
				Name = item.Name,
				Each = item.Each,
				Count = num2
			});
			if (num2 < item.Count)
			{
				_splitWant.Add(_cash.Count - 1);
			}
		}
	}

	private void NextSplitOrCash()
	{
		if (_splitWant.Count > 0)
		{
			NoteStack noteStack = _cash[_splitWant[0]];
			_splitBefore = new HashSet<int>(Notes().Select((NoteStack n) => n.Id));
			try
			{
				Core.Actions.SelectedStackCount = noteStack.Count;
				Core.Actions.MoveItem(noteStack.Id, Core.CharacterFilter.Id, 0, false);
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
			_state = State.Splitting;
			_until = DateTime.Now.AddSeconds(Tuning.V("VendorWaitS"));
			Status = "splitting off " + noteStack.Count + " " + noteStack.Name;
			return;
		}
		_coinsBefore = Coins();
		Core.Actions.VendorClearSellList();
		foreach (NoteStack item in _cash)
		{
			Core.Actions.VendorAddSellList(item.Id);
		}
		Core.Actions.VendorSellAll();
		_state = State.CashingNotes;
		_until = DateTime.Now.AddSeconds(Tuning.V("VendorWaitS"));
		Status = "cashing " + _cash.Sum((NoteStack n) => n.Count) + " trade note(s)";
		_log("VENDOR " + Status);
	}

	private NoteStack NewSplitStack()
	{
		NoteStack want = _cash[_splitWant[0]];
		return Notes().FirstOrDefault((NoteStack n) => !_splitBefore.Contains(n.Id) && n.Each == want.Each && n.Count == want.Count);
	}

	private void Bank()
	{
		long num = Coins();
		if (Ilt || _dry || !_s.VendorBankChange || num <= _s.VendorBankAbove)
		{
			Done();
			return;
		}
		WorldObject worldObject = NoteWare(_s.VendorNoteSize);
		if (worldObject == null)
		{
			_missing.Add("Trade Note (" + _s.VendorNoteSize.ToString("N0", CultureInfo.InvariantCulture) + ") to bank the change");
			Done();
			return;
		}
		_bankEach = Math.Max(1, worldObject.Values(LongValueKey.Value, 0));
		long num2 = NoteCost(_bankEach);
		int num3 = (int)Math.Max(0L, (num - _s.VendorKeepLoose) / num2);
		if (num3 <= 0)
		{
			Done();
			return;
		}
		_coinsBefore = num;
		Core.Actions.VendorClearBuyList();
		Core.Actions.VendorAddBuyList(worldObject.Id, num3);
		Core.Actions.VendorBuyAll();
		_state = State.Banking;
		_until = DateTime.Now.AddSeconds(Tuning.V("VendorWaitS"));
		Status = "banking " + num3 + " x " + worldObject.Name;
		_log("VENDOR " + Status);
	}

	// (vendors sell notes at 115% of their value - ACE's rate for them - and buy them back at their value)
	private static long NoteCost(long each)
	{
		return Math.Max(1L, (long)Math.Ceiling(1.15 * (double)each - 0.1));
	}

	private WorldObject NoteWare(long size)
	{
		Vendor openVendor = Core.WorldFilter.OpenVendor;
		if (openVendor == null)
		{
			return null;
		}
		foreach (WorldObject item in openVendor)
		{
			if (IsNote(item) && item.Values(LongValueKey.Value, 0) == size)
			{
				return item;
			}
		}
		return null;
	}

	// ── finishing ──

	private void Done()
	{
		List<string> list = new List<string>();
		bool flag = false;
		if (_soldCount > 0)
		{
			list.Add("sold " + _soldCount + " item" + ((_soldCount == 1) ? "" : "s") + " for " + Money(_soldFor));
		}
		if (_soldCount < _selling.Count)
		{
			list.Add((_selling.Count - _soldCount) + " didn't sell");
			flag = true;
		}
		List<string> list2 = new List<string>();
		foreach (Buy buy in _buys)
		{
			int num = CountByName(buy.Name) - _countsBefore[buy.Name];
			if (num > 0)
			{
				list2.Add(buy.Name + " x" + num);
			}
			if (num < buy.Count)
			{
				flag = true;
			}
		}
		if (list2.Count > 0)
		{
			list.Add("bought " + string.Join(", ", list2.ToArray()));
		}
		if (_missing.Count > 0)
		{
			list.Add(string.Join(", ", _missing.ToArray()) + " not stocked");
			flag = true;
		}
		if (_short)
		{
			list.Add("bought less than wanted (money floor / spend limit / not enough money)");
			flag = true;
		}
		if (_notesCashed > 0)
		{
			list.Add("cashed " + _notesCashed + "x " + Money(_cashedEach) + " note" + ((_notesCashed == 1) ? "" : "s"));
		}
		if (_notesBanked > 0)
		{
			list.Add("banked " + _notesBanked + "x " + Money(_bankEach) + " note" + ((_notesBanked == 1) ? "" : "s"));
		}
		long num2 = Coins() + NotesValue();
		long num3 = _startWealth - num2;
		if (!Ilt)
		{
			list.Add(((num3 >= 0) ? ("spent " + Money(num3)) : ("made " + Money(-num3))) + ", " + Money(num2) + " left");
		}
		if (list.Count == 0)
		{
			list.Add("nothing to buy or sell");
		}
		if (Ilt && _s.VendorIltDeposit && Coins() > 0)
		{
			Util.Command("/b d");
			list.Add("pyreals deposited (/b d)");
		}
		Finish(flag ? Result.Partial : Result.Success, string.Join(". ", list.ToArray()) + ".");
	}

	private void DryReport()
	{
		List<string> list = new List<string>();
		long num = 0L;
		Vendor openVendor = Core.WorldFilter.OpenVendor;
		float num2 = ((openVendor != null && openVendor.BuyRate > 0f) ? openVendor.BuyRate : 1f);
		foreach (int item in _selling)
		{
			WorldObject worldObject = Core.WorldFilter[item];
			if (worldObject != null)
			{
				num += (long)Math.Floor((double)num2 * (double)worldObject.Values(LongValueKey.Value, 0) + 0.1);
			}
		}
		list.Add("would sell " + _selling.Count + " item" + ((_selling.Count == 1) ? "" : "s") + ((_selling.Count > 0) ? (" for about " + Money(num) + " (" + string.Join(", ", _selling.Take(8).Select((int id) => Core.WorldFilter[id]?.Name ?? "?").ToArray()) + ((_selling.Count > 8) ? ", ..." : "") + ")") : ""));
		PlanBuys();
		long num3 = _buys.Sum((Buy b) => b.Each * b.Count);
		if (_buys.Count > 0)
		{
			list.Add("would buy " + string.Join(", ", _buys.Select((Buy b) => b.Name + " x" + b.Count).ToArray()) + " for " + Money(num3));
		}
		if (_missing.Count > 0)
		{
			list.Add(string.Join(", ", _missing.ToArray()) + " not stocked");
		}
		if (_short)
		{
			list.Add("would buy less than wanted (money floor / spend limit / money)");
		}
		long num4 = Coins() + num;
		if (!Ilt && num3 > num4 && _s.VendorPayWithNotes)
		{
			PlanNotes(num3 - num4);
			if (_cash.Count > 0)
			{
				list.Add("would cash " + string.Join(", ", _cash.Select((NoteStack n) => n.Count + "x " + Money(n.Each)).ToArray()) + " notes" + ((_splitWant.Count > 0) ? " (splitting a stack)" : ""));
			}
		}
		long num5 = num4 + _cash.Sum((NoteStack n) => n.Each * n.Count) - num3;
		if (!Ilt && _s.VendorBankChange && num5 > _s.VendorBankAbove)
		{
			WorldObject worldObject2 = NoteWare(_s.VendorNoteSize);
			if (worldObject2 == null)
			{
				list.Add("couldn't bank the change - no " + Money(_s.VendorNoteSize) + " notes sold here");
			}
			else
			{
				long num6 = (num5 - _s.VendorKeepLoose) / NoteCost(worldObject2.Values(LongValueKey.Value, 0));
				if (num6 > 0)
				{
					list.Add("would bank " + num6 + "x " + Money(_s.VendorNoteSize) + " notes");
				}
			}
		}
		if (Ilt && _s.VendorIltDeposit)
		{
			list.Add("would deposit pyreals (/b d)");
		}
		_selling.Clear();
		_buys.Clear();
		Finish(Result.Success, "DRY RUN - " + string.Join(". ", list.ToArray()) + ".");
	}

	private void Finish(Result r, string text)
	{
		_state = State.Idle;
		Last = r;
		LastAt = DateTime.Now;
		LastVendor = (_npc != null) ? _npc.Name : _npcName;
		string text2 = ShortName(LastVendor);
		LastSummary = text2 + ": " + text;
		Status = "";
		Util.WriteToChat("Vendor " + LastSummary + ((r == Result.Failed) ? " (failed)" : ((r == Result.Partial) ? " (partly done)" : "")));
		_log("VENDOR " + r.ToString().ToLowerInvariant() + " - " + LastSummary);
	}

	private void Say(string text)
	{
		Util.WriteToChat("Vendor " + ShortName(_npc?.Name ?? _npcName) + ": " + text);
	}

	// ── profiles ──

	/// <summary>Where vendor profiles are looked for, in order: this character's, this server's, everyone's (all under
	/// Vendor in the loot profile folder), then the loot profile folder itself.</summary>
	public List<string> ProfileDirs()
	{
		string text = _lootDir();
		string path = Path.Combine(text, "Vendor");
		string text2 = Safe(Core.CharacterFilter.Server ?? "");
		string text3 = Safe(Core.CharacterFilter.Name ?? "");
		List<string> list = new List<string>();
		if (text2.Length > 0 && text3.Length > 0)
		{
			list.Add(Path.Combine(Path.Combine(path, text2), text3));
		}
		if (text2.Length > 0)
		{
			list.Add(Path.Combine(path, text2));
		}
		list.Add(path);
		list.Add(text);
		return list;
	}

	public UtlProfile ResolveProfile(string name, string vendor, out string file)
	{
		file = "";
		List<string> list = new List<string>();
		if (!string.IsNullOrEmpty(name))
		{
			list.Add(name);
		}
		else if (!string.IsNullOrEmpty(vendor))
		{
			list.Add(vendor);
		}
		foreach (string item in list)
		{
			string text = (item.EndsWith(".utl", StringComparison.OrdinalIgnoreCase) ? item : (item + ".utl"));
			foreach (string item2 in ProfileDirs())
			{
				string text2 = Path.Combine(item2, Safe(text));
				if (File.Exists(text2))
				{
					try
					{
						file = text2;
						return UtlProfile.Load(text2);
					}
					catch (Exception ex)
					{
						Util.WriteToChat("Vendor: couldn't read " + Short(text2) + ": " + ex.Message);
						return null;
					}
				}
			}
		}
		return null;
	}

	/// <summary>Every vendor profile under the Vendor folder, as paths relative to the loot profile folder.</summary>
	public static List<string> ListVendorProfiles(string lootDir)
	{
		List<string> list = new List<string>();
		try
		{
			string path = Path.Combine(lootDir, "Vendor");
			if (Directory.Exists(path))
			{
				string[] files = Directory.GetFiles(path, "*.utl", SearchOption.AllDirectories);
				foreach (string text in files)
				{
					list.Add(text.Substring(lootDir.Length).TrimStart('/', '\\'));
				}
			}
		}
		catch
		{
		}
		list.Sort(StringComparer.OrdinalIgnoreCase);
		return list;
	}

	/// <summary>The vendor profiles' names (no folder, no .utl), each once.</summary>
	public List<string> ProfileNames()
	{
		List<string> list = new List<string>();
		foreach (string item in ListVendorProfiles(_lootDir()))
		{
			string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(item);
			if (!list.Contains(fileNameWithoutExtension, StringComparer.OrdinalIgnoreCase))
			{
				list.Add(fileNameWithoutExtension);
			}
		}
		list.Sort(StringComparer.OrdinalIgnoreCase);
		return list;
	}

	/// <summary>Makes an empty vendor profile (for this character, this server or everyone) and gives its path relative to the loot profile folder.</summary>
	public string NewProfile(string name, int scope)
	{
		List<string> list = ProfileDirs();
		string text = ((scope == 0 && list.Count == 4) ? list[0] : ((scope == 1 && list.Count >= 3) ? list[list.Count - 3] : list[list.Count - 2]));
		Directory.CreateDirectory(text);
		string text2 = Path.Combine(text, Safe(name.EndsWith(".utl", StringComparison.OrdinalIgnoreCase) ? name : (name + ".utl")));
		if (!File.Exists(text2))
		{
			new UtlProfile
			{
				Version = 1
			}.Save(text2);
		}
		return text2.Substring(_lootDir().Length).TrimStart('/', '\\');
	}

	private string Short(string path)
	{
		string text = _lootDir();
		return (path.StartsWith(text, StringComparison.OrdinalIgnoreCase) ? path.Substring(text.Length).TrimStart('/', '\\') : path).Replace('\\', '/');
	}

	private static string Safe(string s)
	{
		char[] invalidFileNameChars = Path.GetInvalidFileNameChars();
		foreach (char oldChar in invalidFileNameChars)
		{
			s = s.Replace(oldChar, '_');
		}
		return s;
	}

	// ── what's around and what's carried ──

	public static WorldObject FindNpc(string name)
	{
		int id = Core.CharacterFilter.Id;
		WorldObject result = null;
		double num = double.MaxValue;
		foreach (WorldObject item in Core.WorldFilter.GetLandscape())
		{
			if (item != null && item.Id != id && (item.ObjectClass == ObjectClass.Vendor || item.ObjectClass == ObjectClass.Npc) && string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
			{
				double num2 = CombatEngine.Distance(item);
				if (num2 < num)
				{
					num = num2;
					result = item;
				}
			}
		}
		return result;
	}

	public static bool ShopOpenAny()
	{
		try
		{
			return Core.Actions.VendorId != 0;
		}
		catch
		{
			return false;
		}
	}

	private bool ShopOpen()
	{
		try
		{
			Vendor openVendor = Core.WorldFilter.OpenVendor;
			return _npc != null && Core.Actions.VendorId == _npc.Id && openVendor != null && openVendor.MerchantId == _npc.Id;
		}
		catch
		{
			return false;
		}
	}

	private static bool InPack(int id)
	{
		foreach (WorldObject item in InvCache.All())
		{
			if (item.Id == id)
			{
				return true;
			}
		}
		return false;
	}

	private static int Stack(WorldObject o)
	{
		return Math.Max(1, o.Values(LongValueKey.StackCount, 1));
	}

	public static long Coins()
	{
		long num = 0L;
		foreach (WorldObject item in InvCache.All())
		{
			if (item.ObjectClass == ObjectClass.Money && (item.Name == "Pyreal" || item.Name == "Pyreals"))
			{
				num += Stack(item);
			}
		}
		return num;
	}

	private static bool IsNote(WorldObject o)
	{
		return o != null && (o.ObjectClass == ObjectClass.TradeNote || (o.Name ?? "").StartsWith("Trade Note", StringComparison.OrdinalIgnoreCase));
	}

	private static List<NoteStack> Notes()
	{
		List<NoteStack> list = new List<NoteStack>();
		foreach (WorldObject item in InvCache.All())
		{
			if (IsNote(item))
			{
				int num = Stack(item);
				long num2 = Math.Max(1, item.Values(LongValueKey.Value, 0));
				list.Add(new NoteStack
				{
					Id = item.Id,
					Name = item.Name,
					Count = num,
					Each = Math.Max(1L, num2 / num)
				});
			}
		}
		return list;
	}

	public static long NotesValue()
	{
		return Notes().Sum((NoteStack n) => n.Each * n.Count);
	}

	private static int CountByName(string name)
	{
		int num = 0;
		foreach (WorldObject item in InvCache.All())
		{
			if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
			{
				num += Stack(item);
			}
		}
		return num;
	}

	private static int CountInPacks(UtlRule rule, string name)
	{
		int num = 0;
		foreach (WorldObject item in InvCache.All())
		{
			if ((name == null || string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase)) && LootMatcher.RuleMatches(rule, item))
			{
				num += Stack(item);
			}
		}
		return num;
	}

	private static long PriceOf(WorldObject ware, float rate)
	{
		long num = Math.Max(0, ware.Values(LongValueKey.Value, 0));
		int num2 = Stack(ware);
		if (num2 > 1)
		{
			num /= num2;
		}
		if (IsNote(ware))
		{
			return NoteCost(num);
		}
		return Math.Max(1L, (long)Math.Ceiling((double)rate * (double)num - 0.1));
	}

	private static string RuleLabel(UtlRule r)
	{
		string text = (r.Name ?? "").Trim();
		return (text.Length > 0) ? text : "a Keep-up-to rule";
	}

	private static string ShortName(string n)
	{
		n = n ?? "";
		int num = n.IndexOf(' ');
		return (num > 0) ? n.Substring(0, num) : n;
	}

	public static string Money(long v)
	{
		double num = Math.Abs((double)v);
		if (num >= 1000000000.0)
		{
			return ((double)v / 1000000000.0).ToString("0.##", CultureInfo.InvariantCulture) + "B";
		}
		if (num >= 1000000.0)
		{
			return ((double)v / 1000000.0).ToString("0.##", CultureInfo.InvariantCulture) + "M";
		}
		if (num >= 1000.0)
		{
			return ((double)v / 1000.0).ToString("0.#", CultureInfo.InvariantCulture) + "k";
		}
		return v.ToString(CultureInfo.InvariantCulture);
	}

	public static string ResultWord(Result r)
	{
		return r switch
		{
			Result.Success => "success",
			Result.Partial => "partial",
			Result.Failed => "failed",
			_ => "",
		};
	}
}
