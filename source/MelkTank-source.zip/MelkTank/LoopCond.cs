using System;

namespace MelkTank;

public class LoopCond
{
	public bool Chat;

	public string Text = "";

	public string Op = "";

	public int Count;

	[NonSerialized]
	public bool Seen;
}
