using System;
using Decal.Adapter;

namespace MelkTank;

public static class ServerMode
{
	public static bool Ilt
	{
		get
		{
			switch (PluginCore.CurrentSettings?.ServerKind ?? 0)
			{
			case 1:
				return true;
			case 2:
				return false;
			default:
			{
				string text = "";
				try
				{
					text = CoreManager.Current.CharacterFilter.Server ?? "";
				}
				catch
				{
				}
				return text.Length == 0 || text.IndexOf("Leaftide", StringComparison.OrdinalIgnoreCase) >= 0 || text == "ACGodot";
			}
			}
		}
	}

	public static bool AllLevels
	{
		get
		{
			Settings currentSettings = PluginCore.CurrentSettings;
			return !Ilt || (currentSettings?.AllSpellLevels ?? false);
		}
	}

	public static string Name => Ilt ? "Infinite Leaftide" : "Standard";
}
