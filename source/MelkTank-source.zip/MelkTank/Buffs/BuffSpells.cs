using System.Collections.Generic;

namespace MelkTank.Buffs;

public static class BuffSpells
{
	public class SpellGroup
	{
		public string Name;

		public List<BuffSpell> Spells;
	}

	public static readonly List<BuffSpell> CreatureSpells = new List<BuffSpell>
	{
		new BuffSpell(4530, "Incantation of Creature Enchantment Mastery Self", "Creature"),
		new BuffSpell(4305, "Incantation of Focus Self", "Creature"),
		new BuffSpell(4329, "Incantation of Willpower Self", "Creature"),
		new BuffSpell(4602, "Incantation of Mana Conversion Mastery Self", "Creature"),
		new BuffSpell(4325, "Incantation of Strength Self", "Creature"),
		new BuffSpell(4299, "Incantation of Endurance Self", "Creature"),
		new BuffSpell(4297, "Incantation of Coordination Self", "Creature"),
		new BuffSpell(4319, "Incantation of Quickness Self", "Creature"),
		new BuffSpell(4558, "Incantation of Impregnability Self", "Creature"),
		new BuffSpell(4560, "Incantation of Invulnerability Self", "Creature"),
		new BuffSpell(4596, "Incantation of Magic Resistance Self", "Creature"),
		new BuffSpell(4522, "Incantation of Missile Weapon Mastery Self", "Creature"),
		new BuffSpell(4538, "Incantation of Finesse Weapon Mastery Self", "Creature"),
		new BuffSpell(4624, "Incantation of Heavy Weapon Mastery Self", "Creature"),
		new BuffSpell(4518, "Incantation of Light Weapon Mastery Self", "Creature"),
		new BuffSpell(5032, "Incantation of Two Handed Combat Mastery Self", "Creature"),
		new BuffSpell(5810, "Incantation of Dual Wield Mastery Self", "Creature"),
		new BuffSpell(5786, "Incantation of Dirty Fighting Mastery Self", "Creature"),
		new BuffSpell(5834, "Incantation of Recklessness Mastery Self", "Creature"),
		new BuffSpell(5858, "Incantation of Shield Mastery Self", "Creature"),
		new BuffSpell(5882, "Incantation of Sneak Attack Mastery Self", "Creature"),
		new BuffSpell(4564, "Incantation of Item Enchantment Mastery Self", "Creature"),
		new BuffSpell(4582, "Incantation of Life Magic Mastery Self", "Creature"),
		new BuffSpell(4638, "Incantation of War Magic Mastery Self", "Creature"),
		new BuffSpell(5418, "Incantation of Void Magic Mastery Self", "Creature"),
		new BuffSpell(4510, "Incantation of Arcane Enlightenment Self", "Creature"),
		new BuffSpell(4542, "Incantation of Deception Mastery Self", "Creature"),
		new BuffSpell(4548, "Incantation of Fealty Self", "Creature"),
		new BuffSpell(4552, "Incantation of Fletching Mastery Self", "Creature"),
		new BuffSpell(4556, "Incantation of Healing Mastery Self", "Creature"),
		new BuffSpell(4572, "Incantation of Jumping Mastery Self", "Creature"),
		new BuffSpell(4578, "Incantation of Leadership Mastery Self", "Creature"),
		new BuffSpell(4586, "Incantation of Lockpick Mastery Self", "Creature"),
		new BuffSpell(4616, "Incantation of Sprint Self", "Creature"),
		new BuffSpell(4604, "Incantation of Monster Attunement Self", "Creature"),
		new BuffSpell(4608, "Incantation of Person Attunement Self", "Creature"),
		new BuffSpell(4512, "Incantation of Armor Tinkering Expertise Self", "Creature"),
		new BuffSpell(4566, "Incantation of Item Tinkering Expertise Self", "Creature"),
		new BuffSpell(4592, "Incantation of Magic Item Tinkering Expertise Self", "Creature"),
		new BuffSpell(4640, "Incantation of Weapon Tinkering Expertise Self", "Creature"),
		new BuffSpell(4526, "Incantation of Cooking Mastery Self", "Creature"),
		new BuffSpell(4506, "Incantation of Alchemy Mastery Self", "Creature"),
		new BuffSpell(6123, "Incantation of Summoning Mastery Self", "Creature"),
		new BuffSpell(4499, "Incantation of Arcanum Salvaging Self", "Creature")
	};

	public static readonly List<BuffSpell> LifeSpells = new List<BuffSpell>
	{
		new BuffSpell(4291, "Incantation of Armor Self", "Life"),
		new BuffSpell(4496, "Incantation of Regeneration Self", "Life"),
		new BuffSpell(4498, "Incantation of Rejuvenation Self", "Life"),
		new BuffSpell(4494, "Incantation of Mana Renewal Self", "Life"),
		new BuffSpell(4462, "Incantation of Blade Protection Self", "Life"),
		new BuffSpell(4472, "Incantation of Piercing Protection Self", "Life"),
		new BuffSpell(4464, "Incantation of Bludgeoning Protection Self", "Life"),
		new BuffSpell(4468, "Incantation of Fire Protection Self", "Life"),
		new BuffSpell(4466, "Incantation of Cold Protection Self", "Life"),
		new BuffSpell(4460, "Incantation of Acid Protection Self", "Life"),
		new BuffSpell(4470, "Incantation of Lightning Protection Self", "Life")
	};

	public static readonly List<BuffSpell> ItemSpells = new List<BuffSpell>
	{
		new BuffSpell(4400, "Aura of Incantation of Defender Self", "Item"),
		new BuffSpell(4417, "Aura of Incantation of Swift Killer Self", "Item"),
		new BuffSpell(4405, "Aura of Incantation of Heart Seeker Self", "Item"),
		new BuffSpell(5183, "Aura of Incantation of Blood Drinker Self", "Item"),
		new BuffSpell(4414, "Aura of Incantation of Spirit Drinker Self", "Item"),
		new BuffSpell(4418, "Aura of Incantation of Hermetic Link Self", "Item"),
		new BuffSpell(4407, "Incantation of Impenetrability", "Item"),
		new BuffSpell(4393, "Incantation of Blade Bane", "Item"),
		new BuffSpell(4412, "Incantation of Piercing Bane", "Item"),
		new BuffSpell(4401, "Incantation of Flame Bane", "Item"),
		new BuffSpell(4403, "Incantation of Frost Bane", "Item"),
		new BuffSpell(4391, "Incantation of Acid Bane", "Item"),
		new BuffSpell(4409, "Incantation of Lightning Bane", "Item"),
		new BuffSpell(4397, "Incantation of Bludgeon Bane", "Item")
	};

	public static readonly List<BuffSpell> ItemSelfSpells = ItemSpells.FindAll((BuffSpell s) => !new HashSet<int> { 4407, 4393, 4412, 4401, 4403, 4391, 4409, 4397 }.Contains(s.Id));

	public static readonly List<BuffSpell> BaneSpells = ItemSpells.FindAll((BuffSpell s) => new HashSet<int> { 4407, 4393, 4412, 4401, 4403, 4391, 4409, 4397 }.Contains(s.Id));

	public static readonly List<SpellGroup> CreatureGroups = Groups(CreatureSpells, "Attributes", new int[6] { 4305, 4329, 4325, 4299, 4297, 4319 }, "Weapon Masteries", new int[7] { 4522, 4538, 4624, 4518, 5032, 5810, 5858 }, "Magic", new int[8] { 4530, 4564, 4582, 4638, 5418, 6123, 4602, 4510 }, "Attack / Defense", new int[7] { 4558, 4560, 4596, 5834, 5882, 5786, 4542 }, "Crafting", new int[8] { 4512, 4566, 4592, 4640, 4526, 4506, 4552, 4499 }, "Misc", new int[0]);

	public static readonly List<SpellGroup> LifeGroups = Groups(LifeSpells, "Renews", new int[3] { 4496, 4498, 4494 }, "Protections", new int[0]);

	public static readonly HashSet<int> BaneSpellIds = new HashSet<int> { 4407, 4393, 4412, 4401, 4403, 4391, 4409, 4397 };

	public const int CreatureMasterySpellId = 4530;

	public static readonly HashSet<int> GemSpellBlacklist = new HashSet<int>
	{
		5171, 5172, 5173, 5204, 5205, 5206, 5207, 5208, 5122, 5133,
		5134, 5135, 5136
	};

	private static List<SpellGroup> Groups(List<BuffSpell> all, params object[] nameThenIds)
	{
		List<SpellGroup> list = new List<SpellGroup>();
		HashSet<int> hashSet = new HashSet<int>();
		for (int i = 0; i + 1 < nameThenIds.Length; i += 2)
		{
			HashSet<int> ids = new HashSet<int>((int[])nameThenIds[i + 1]);
			SpellGroup spellGroup = new SpellGroup
			{
				Name = (string)nameThenIds[i],
				Spells = all.FindAll((BuffSpell s) => ids.Contains(s.Id))
			};
			foreach (BuffSpell spell in spellGroup.Spells)
			{
				hashSet.Add(spell.Id);
			}
			list.Add(spellGroup);
		}
		if (list.Count > 0)
		{
			foreach (BuffSpell item in all)
			{
				if (!hashSet.Contains(item.Id))
				{
					list[list.Count - 1].Spells.Add(item);
				}
			}
		}
		return list;
	}
}
