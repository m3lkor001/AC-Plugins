namespace MelkTank.Buffs;

public class BaneItem
{
	public int ItemId { get; set; }

	public string Name { get; set; }

	public bool Enabled { get; set; }

	public BaneItem(int itemId, string name)
	{
		ItemId = itemId;
		Name = name;
		Enabled = true;
	}
}
