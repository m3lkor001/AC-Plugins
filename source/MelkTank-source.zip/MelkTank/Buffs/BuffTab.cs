using System;
using System.Collections.Generic;
using System.Numerics;
using ImGuiNET;

namespace MelkTank.Buffs;

public class BuffTab
{
	private readonly Buffer _b;

	private readonly Settings _s;

	private readonly Action<bool> _setEnabled;

	private static readonly Vector4 Cyan = new Vector4(0.35f, 0.85f, 0.95f, 1f);

	private static readonly Vector4 Red = new Vector4(0.95f, 0.35f, 0.35f, 1f);

	private static readonly Vector4 Green = new Vector4(0.45f, 0.9f, 0.45f, 1f);

	private static readonly Vector4 Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f);

	private static readonly Vector4 Yellow = new Vector4(0.95f, 0.85f, 0.35f, 1f);

	private static readonly Vector4 Purple = new Vector4(0.75f, 0.45f, 0.95f, 1f);

	public BuffTab(Buffer buffer, Settings settings, Action<bool> setEnabled)
	{
		_b = buffer;
		_s = settings;
		_setEnabled = setEnabled;
	}

	public void Draw()
	{
		DrawControlBar();
		ImGui.Separator();
		if (ImGui.BeginTabBar("BuffTabs"))
		{
			if (ImGui.BeginTabItem("Status"))
			{
				DrawStatus();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Creature"))
			{
				DrawSpellGroups("creature", BuffSpells.CreatureSpells, BuffSpells.CreatureGroups, _b.CreatureExclude, _b.CreatureEnabled);
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Life"))
			{
				DrawSpellGroups("life", BuffSpells.LifeSpells, BuffSpells.LifeGroups, _b.LifeExclude, _b.LifeEnabled);
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Item"))
			{
				DrawItem();
				ImGui.EndTabItem();
			}
			ImGui.EndTabBar();
		}
	}

	private void DrawControlBar()
	{
		bool melksBufferEnabled = _s.MelksBufferEnabled;
		ImGui.PushStyleColor(ImGuiCol.Button, melksBufferEnabled ? new Vector4(0.15f, 0.55f, 0.2f, 1f) : new Vector4(0.55f, 0.15f, 0.15f, 1f));
		if (ImGui.Button(melksBufferEnabled ? "Buffing: ON " : "Buffing: OFF", new Vector2(130f, 0f)))
		{
			_setEnabled(!melksBufferEnabled);
		}
		ImGui.PopStyleColor();
		Tip("Same switch as 'Melk's buffer' on the Main tab and 'Buff' on the mini panel.\nOn: rebuffs when Creature Enchantment Mastery has less than the Settings tab's minutes left.\n/mt buff on|off");
		ImGui.SameLine();
		if (ImGui.Button("Rebuff now"))
		{
			_b.RebuffNow();
		}
		Tip("Casts everything ticked now (works with buffing off too).\n/mt rebuff");
		ImGui.SameLine();
		if (ImGui.Button("Rebane armor"))
		{
			_b.RebaneNow();
		}
		Tip("For new armor: casts only the ticked banes - on you (all your worn armor) and on the\nindividual bane items - and nothing else. The Creature / Life / Item switches are left as they are,\nso there's nothing to turn off first or back on after.");
		ImGui.SameLine();
		if (ImGui.Button("Stop"))
		{
			_b.Stop();
		}
		Tip("Stops the buff cycle and goes back to the combat mode you were in.");
		ImGui.SameLine();
		if (ImGui.Button(_b.Paused ? "Resume" : "Pause", new Vector2(70f, 0f)))
		{
			_b.TogglePause();
		}
		Tip("Pause freezes the cycle where it is (gear left as it is) and lets combat carry on.\nResume continues from the same spell.");
		ImGui.SameLine();
		Vector4 col;
		if (_b.WaitingForHeal)
		{
			col = Purple;
		}
		else if (_b.Busy)
		{
			col = Yellow;
		}
		else if (_b.Paused)
		{
			col = Red;
		}
		else
		{
			col = (_s.MelksBufferEnabled ? Green : Grey);
		}
		Im.TextColored(col, _b.Status + ((_b.SpellsLeft > 0) ? ("   -   " + _b.SpellsLeft + " spell(s) left") : ""));
		if (_b.WaitingForHeal)
		{
			Tip("The Main tab's healer is using a kit. Buffing carries on once the heal lands.");
		}
	}

	private void DrawStatus()
	{
		if (ImGui.BeginTable("statuslayout", 2, ImGuiTableFlags.SizingStretchProp | ImGuiTableFlags.BordersInnerV, new Vector2(0f, 0f)))
		{
			ImGui.TableSetupColumn("settings", ImGuiTableColumnFlags.WidthStretch, 2f);
			ImGui.TableSetupColumn("list", ImGuiTableColumnFlags.WidthStretch, 3f);
			ImGui.TableNextRow();
			ImGui.TableSetColumnIndex(0);
			DrawSettings();
			ImGui.TableSetColumnIndex(1);
			DrawStatusList();
			ImGui.EndTable();
		}
	}

	private void DrawStatusList()
	{
		ImGuiTableFlags flags = ImGuiTableFlags.Borders | ImGuiTableFlags.SizingStretchProp | ImGuiTableFlags.RowBg | ImGuiTableFlags.ScrollY;
		if (!ImGui.BeginTable("buffstatus", 3, flags, new Vector2(0f, 0f)))
		{
			return;
		}
		ImGui.TableSetupColumn("Spell", ImGuiTableColumnFlags.WidthStretch, 3f);
		ImGui.TableSetupColumn("From", ImGuiTableColumnFlags.WidthStretch, 3f);
		ImGui.TableSetupColumn("Time left", ImGuiTableColumnFlags.WidthStretch, 1.2f);
		ImGui.TableSetupScrollFreeze(0, 1);
		ImGui.TableHeadersRow();
		double spellRemaining = Buffer.GetSpellRemaining(4530);
		Row("Creature Enchantment Mastery", Cyan, _b.MasteryTriggers ? ("Rebuff trigger - full rebuff under " + _b.RebuffMinutes + " min") : "Not cast (Creature off or it's unticked) - only Rebuff now starts a full rebuff", _b.MasteryTriggers ? Grey : Yellow, Buffer.FormatTime(spellRemaining), TimeColor(spellRemaining));
		List<KeyValuePair<SpellGem, int>> list = new List<KeyValuePair<SpellGem, int>>();
		foreach (SpellGem spellGem in _b.SpellGems)
		{
			string text = GemOff(spellGem);
			if (!spellGem.Learned)
			{
				Row(spellGem.Name, Grey, "Gem - learns its spells on next use" + text, Grey, "", Grey);
				continue;
			}
			if (spellGem.SpellIds.Count == 0)
			{
				Row(spellGem.Name, Grey, "Gem - learned nothing (Item tab: Relearn)" + text, Grey, "", Grey);
				continue;
			}
			foreach (int spellId in spellGem.SpellIds)
			{
				list.Add(new KeyValuePair<SpellGem, int>(spellGem, spellId));
			}
		}
		list.Sort((KeyValuePair<SpellGem, int> a, KeyValuePair<SpellGem, int> b) => Buffer.GetSpellRemaining(a.Value).CompareTo(Buffer.GetSpellRemaining(b.Value)));
		foreach (KeyValuePair<SpellGem, int> item in list)
		{
			double spellRemaining2 = Buffer.GetSpellRemaining(item.Value);
			string text2 = GemOff(item.Key);
			Row(Buffer.GetSpellName(item.Value), (text2.Length > 0) ? Grey : Vector4.One, "Gem: " + item.Key.Name + text2, (text2.Length > 0) ? Yellow : Grey, Buffer.FormatTime(spellRemaining2), (text2.Length > 0) ? Grey : TimeColor(spellRemaining2));
		}
		foreach (KeyValuePair<int, DateTime> item2 in _b.Dispelled)
		{
			bool flag = Buffer.GetSpellRemaining(item2.Key) > 0.0;
			Row(Buffer.GetSpellName(item2.Key), Red, "Dispelled at " + item2.Value.ToString("h:mm tt") + (_b.ReplaceDispelled ? "" : " (replacing is off)"), Grey, flag ? "back on" : "waiting", flag ? Green : Red);
		}
		ImGui.EndTable();
	}

	private string GemOff(SpellGem gem)
	{
		if (!_b.SpellGemsEnabled)
		{
			return "  - disabled (Use spell gems is off)";
		}
		if (!gem.Enabled)
		{
			return "  - disabled (unticked on the Item tab)";
		}
		return "";
	}

	private static void Row(string spell, Vector4 spellCol, string from, Vector4 fromCol, string left, Vector4 leftCol)
	{
		ImGui.TableNextRow();
		ImGui.TableSetColumnIndex(0);
		Im.TextColored(spellCol, spell);
		ImGui.TableSetColumnIndex(1);
		Im.TextColored(fromCol, from);
		ImGui.TableSetColumnIndex(2);
		Im.TextColored(leftCol, left);
	}

	private Vector4 TimeColor(double seconds)
	{
		if (seconds <= 0.0)
		{
			return Red;
		}
		if (seconds < _b.RebuffSeconds)
		{
			return Yellow;
		}
		return Green;
	}

	private void DrawSpellGroups(string id, List<BuffSpell> all, List<BuffSpells.SpellGroup> groups, HashSet<int> exclude, bool schoolOn)
	{
		if (!schoolOn)
		{
			Im.TextColored(Yellow, "This school is switched off on the Status tab - nothing here is cast.");
		}
		int num = 0;
		foreach (BuffSpell item in all)
		{
			if (!exclude.Contains(item.Id))
			{
				num++;
			}
		}
		Im.TextColored(Grey, num + " of " + all.Count + " ticked");
		ImGui.SameLine();
		if (ImGui.SmallButton("All##" + id))
		{
			_b.SetAll(exclude, all, on: true);
		}
		ImGui.SameLine();
		if (ImGui.SmallButton("None##" + id))
		{
			_b.SetAll(exclude, all, on: false);
		}
		ImGui.BeginChild("groups" + id, new Vector2(0f, 0f), border: false);
		for (int i = 0; i < groups.Count; i++)
		{
			BuffSpells.SpellGroup spellGroup = groups[i];
			if (spellGroup.Spells.Count == 0)
			{
				continue;
			}
			string text = id + "g" + i;
			int num2 = 0;
			foreach (BuffSpell spell in spellGroup.Spells)
			{
				if (!exclude.Contains(spell.Id))
				{
					num2++;
				}
			}
			ImGui.Spacing();
			Im.TextColored(Cyan, spellGroup.Name);
			ImGui.SameLine();
			Im.TextColored(Grey, "(" + num2 + "/" + spellGroup.Spells.Count + ")");
			ImGui.SameLine();
			if (ImGui.SmallButton("All##" + text))
			{
				_b.SetAll(exclude, spellGroup.Spells, on: true);
			}
			ImGui.SameLine();
			if (ImGui.SmallButton("None##" + text))
			{
				_b.SetAll(exclude, spellGroup.Spells, on: false);
			}
			ImGuiTableFlags flags = ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingStretchSame;
			if (!ImGui.BeginTable("grid" + text, 4, flags))
			{
				continue;
			}
			int num3 = (spellGroup.Spells.Count + 4 - 1) / 4;
			for (int j = 0; j < num3; j++)
			{
				ImGui.TableNextRow();
				for (int k = 0; k < 4; k++)
				{
					int num4 = k * num3 + j;
					if (num4 < spellGroup.Spells.Count)
					{
						ImGui.TableSetColumnIndex(k);
						BuffSpell buffSpell = spellGroup.Spells[num4];
						bool v = !exclude.Contains(buffSpell.Id);
						if (ImGui.Checkbox(Buffer.ShortName(buffSpell.Name) + "##" + id + buffSpell.Id, ref v))
						{
							_b.ToggleExclude(exclude, buffSpell.Id);
						}
					}
				}
			}
			ImGui.EndTable();
		}
		ImGui.EndChild();
	}

	private void DrawSpellGrid(string id, List<BuffSpell> spells, HashSet<int> exclude, bool schoolOn, int columns, float height = 0f)
	{
		if (!schoolOn)
		{
			Im.TextColored(Yellow, "This school is switched off on the Status tab - nothing here is cast.");
		}
		int num = 0;
		foreach (BuffSpell spell in spells)
		{
			if (!exclude.Contains(spell.Id))
			{
				num++;
			}
		}
		Im.TextColored(Grey, num + " of " + spells.Count + " ticked");
		ImGui.SameLine();
		if (ImGui.SmallButton("All##" + id))
		{
			_b.SetAll(exclude, spells, on: true);
		}
		ImGui.SameLine();
		if (ImGui.SmallButton("None##" + id))
		{
			_b.SetAll(exclude, spells, on: false);
		}
		ImGuiTableFlags flags = ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingStretchSame | ImGuiTableFlags.ScrollY;
		if (!ImGui.BeginTable("grid" + id, columns, flags, new Vector2(0f, height)))
		{
			return;
		}
		int num2 = (spells.Count + columns - 1) / columns;
		for (int i = 0; i < num2; i++)
		{
			ImGui.TableNextRow();
			for (int j = 0; j < columns; j++)
			{
				int num3 = j * num2 + i;
				if (num3 < spells.Count)
				{
					ImGui.TableSetColumnIndex(j);
					BuffSpell buffSpell = spells[num3];
					bool v = !exclude.Contains(buffSpell.Id);
					if (ImGui.Checkbox(Buffer.ShortName(buffSpell.Name) + "##" + id + buffSpell.Id, ref v))
					{
						_b.ToggleExclude(exclude, buffSpell.Id);
					}
				}
			}
		}
		ImGui.EndTable();
	}

	private void DrawItem()
	{
		if (!ImGui.BeginTable("itemlayout", 2, ImGuiTableFlags.BordersInnerV | ImGuiTableFlags.SizingStretchSame, new Vector2(0f, 0f)))
		{
			return;
		}
		ImGui.TableNextRow();
		ImGui.TableSetColumnIndex(0);
		float height = (ImGui.GetContentRegionAvail().Y - ImGui.GetFrameHeightWithSpacing() * 4f) / 2f;
		Im.TextColored(Cyan, "Item self buffs");
		if (!_b.ItemEnabled)
		{
			ImGui.SameLine();
			Im.TextColored(Yellow, "(Item is off on the Status tab)");
		}
		DrawSpellGrid("itemself", BuffSpells.ItemSelfSpells, _b.ItemExclude, schoolOn: true, 2, height);
		Im.TextColored(Cyan, "Banes");
		if (!_b.BanesEnabled)
		{
			ImGui.SameLine();
			Im.TextColored(Yellow, "(Banes is off on the Status tab)");
		}
		DrawSpellGrid("banes", BuffSpells.BaneSpells, _b.ItemExclude, schoolOn: true, 2, -1f);
		ImGui.TableSetColumnIndex(1);
		float y = (ImGui.GetContentRegionAvail().Y - ImGui.GetFrameHeightWithSpacing() * 2f) / 2f;
		Im.TextColored(Cyan, "Individual bane items");
		ImGui.SameLine();
		if (ImGui.SmallButton("Add selected##bane"))
		{
			_b.AddBaneFromSelection();
		}
		Tip("Select a shield or other item in your inventory, then click. The ticked banes on the left\nare cast on it too (when 'Buff individual items' is on in Settings).");
		ImGui.SameLine();
		if (ImGui.SmallButton("Remove unticked##bane"))
		{
			_b.RemoveUntickedBanes();
		}
		if (!_b.BaneItemsEnabled || !_b.BanesEnabled)
		{
			ImGui.SameLine();
			Im.TextColored(Yellow, (!_b.BanesEnabled) ? "(Banes is off)" : "(off on the Status tab)");
		}
		if (ImGui.BeginChild("banes", new Vector2(0f, y), border: true))
		{
			if (_b.BaneItems.Count == 0)
			{
				Im.TextDisabled("None yet.");
			}
			foreach (BaneItem baneItem in _b.BaneItems)
			{
				bool v = baneItem.Enabled;
				if (ImGui.Checkbox(baneItem.Name + "##bane" + baneItem.ItemId, ref v))
				{
					baneItem.Enabled = v;
					_b.SaveSettings();
				}
				if (Globals.Core.WorldFilter[baneItem.ItemId] == null)
				{
					ImGui.SameLine();
					Im.TextColored(Red, "missing");
				}
			}
		}
		ImGui.EndChild();
		Im.TextColored(Cyan, "Spell gems");
		ImGui.SameLine();
		if (ImGui.SmallButton("Add selected##gem"))
		{
			_b.AddGemFromSelection();
		}
		Tip("Select a gem (or any item that casts buffs when used) in your inventory, then click.\nThe first use learns which spells it casts; after that it's reused when one runs low.");
		ImGui.SameLine();
		if (ImGui.SmallButton("Remove unticked##gem"))
		{
			_b.RemoveUntickedGems();
		}
		if (!_b.SpellGemsEnabled)
		{
			ImGui.SameLine();
			Im.TextColored(Yellow, "(off on the Status tab)");
		}
		if (ImGui.BeginChild("gems", new Vector2(0f, 0f), border: true))
		{
			if (_b.SpellGems.Count == 0)
			{
				Im.TextDisabled("None yet.");
			}
			foreach (SpellGem spellGem in _b.SpellGems)
			{
				bool v2 = spellGem.Enabled;
				if (ImGui.Checkbox(spellGem.Name + "##gem" + spellGem.ItemId, ref v2))
				{
					spellGem.Enabled = v2;
					_b.SaveSettings();
				}
				ImGui.SameLine();
				if (!spellGem.Learned)
				{
					Im.TextColored(Grey, "(learns on next use)");
				}
				else
				{
					List<string> list = new List<string>();
					foreach (int spellId in spellGem.SpellIds)
					{
						list.Add(Buffer.GetSpellName(spellId));
					}
					Im.TextColored(Grey, (spellGem.SpellIds.Count == 0) ? "(learned nothing)" : ("(" + spellGem.SpellIds.Count + ")"));
					Tip((list.Count > 0) ? string.Join("\n", list.ToArray()) : "No spells were seen when it was first used.\nUse Relearn to try again.");
				}
				ImGui.SameLine();
				if (ImGui.SmallButton("Relearn##gem" + spellGem.ItemId))
				{
					_b.ResetGemLearning(spellGem);
					_b.SaveSettings();
				}
				Tip("Forget the spells it learned; the next use learns them again.");
			}
		}
		ImGui.EndChild();
		ImGui.EndTable();
	}

	private void DrawSettings()
	{
		bool flag = false;
		Im.TextColored(Cyan, "Buffing instrument");
		if (_b.PickInstrument(out var name, out var wielded) == 0)
		{
			Im.TextColored(Purple, "None - wield a wand, or add one (Caster) to the Items tab.");
		}
		else
		{
			Im.TextColored(Green, name + (wielded ? "  (wielded)" : "  (first wand on the Items tab)"));
		}
		Tip("Buffs are cast with the wand, staff or orb you're wielding. If you aren't wielding one,\nthe first Caster on the Items tab is wielded for the buffs and your weapon is put back after.\nMove a wand up the Items tab list to make it the one used.");
		ImGui.SetNextItemWidth(110f);
		int v = _b.RebuffMinutes;
		if (ImGui.InputInt("Rebuff when minutes left", ref v))
		{
			_b.RebuffMinutes = Math.Max(1, v);
			flag = true;
		}
		Tip("A full rebuff starts when Creature Enchantment Mastery has less than this left.\nGems are reused when one of their spells has less than this left.");
		ImGui.Spacing();
		Im.TextColored(Cyan, "Cast");
		bool v2 = _b.CreatureEnabled;
		if (ImGui.Checkbox("Creature", ref v2))
		{
			_b.CreatureEnabled = v2;
			flag = true;
		}
		ImGui.SameLine();
		v2 = _b.LifeEnabled;
		if (ImGui.Checkbox("Life", ref v2))
		{
			_b.LifeEnabled = v2;
			flag = true;
		}
		ImGui.SameLine();
		v2 = _b.ItemEnabled;
		if (ImGui.Checkbox("Item", ref v2))
		{
			_b.ItemEnabled = v2;
			flag = true;
		}
		Tip("Item self buffs: Defender, Swift Killer, Heart Seeker, Blood / Spirit Drinker, Hermetic Link.");
		ImGui.SameLine();
		v2 = _b.BanesEnabled;
		if (ImGui.Checkbox("Banes", ref v2))
		{
			_b.BanesEnabled = v2;
			flag = true;
		}
		Tip("Impenetrability and the element banes - on you, and on the bane items (Item tab) when 'Buff individual items' is ticked.");
		ImGui.SameLine();
		v2 = _b.SpellGemsEnabled;
		if (ImGui.Checkbox("Spell gems", ref v2))
		{
			_b.SpellGemsEnabled = v2;
			flag = true;
		}
		v2 = _b.BaneItemsEnabled;
		if (ImGui.Checkbox("Buff individual items (banes)", ref v2))
		{
			_b.BaneItemsEnabled = v2;
			flag = true;
		}
		Tip("Casts the ticked banes on each item in the Item tab's bane list too.");
		ImGui.Spacing();
		Im.TextColored(Cyan, "Dispels");
		v2 = _b.ReplaceDispelled;
		if (ImGui.Checkbox("Replace dispelled buffs", ref v2))
		{
			_b.ReplaceDispelled = v2;
			flag = true;
		}
		Tip("When a ticked buff disappears outside a buff cycle, recast just that one.");
		v2 = _b.DispelWaitForClear;
		if (ImGui.Checkbox("Wait for monsters to clear##disp", ref v2))
		{
			_b.DispelWaitForClear = v2;
			flag = true;
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(100f);
		float v3 = _b.ClearRange;
		if (ImGui.InputFloat("m##clearrange", ref v3, 1f, 5f, "%.0f"))
		{
			_b.ClearRange = Math.Max(1f, v3);
			flag = true;
		}
		Tip("Rebuffs (full and dispel) wait until no monster is this close.");
		v2 = _b.PauseForMonsters;
		if (ImGui.Checkbox("Pause buffing to fight monsters in range##pausemon", ref v2))
		{
			_b.PauseForMonsters = v2;
			flag = true;
		}
		Tip("A buff cycle already going stops between casts when a monster comes within the range above:\nyour gear goes back, the monsters are fought, and once none is that close the cycle carries on\nwith the buffs it had left (not from the start). Buffing only happens when nothing's around.");
		if (flag)
		{
			_b.SaveSettings();
		}
	}

	private static void Tip(string text)
	{
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip(text);
		}
	}
}
