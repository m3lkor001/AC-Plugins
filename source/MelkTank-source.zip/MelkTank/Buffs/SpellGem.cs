using System.Collections.Generic;

namespace MelkTank.Buffs;

public class SpellGem
{
	public int ItemId { get; set; }

	public string Name { get; set; }

	public List<int> SpellIds { get; set; }

	public double MaxDuration { get; set; }

	public bool Enabled { get; set; }

	public bool Learned { get; set; }

	public SpellGem(int itemId, string name)
	{
		ItemId = itemId;
		Name = name;
		SpellIds = new List<int>();
		MaxDuration = 0.0;
		Enabled = true;
		Learned = false;
	}
}
