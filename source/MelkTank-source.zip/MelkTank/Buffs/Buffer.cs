using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Xml;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using MelkTank.Loot;

namespace MelkTank.Buffs;

public class Buffer
{
	private enum BuffState
	{
		Idle,
		WaitingForClear,
		EquippingWand,
		WaitNotBusy,
		Casting,
		WaitingFizzle,
		UnequippingWand
	}

	private struct CastEntry
	{
		public int SpellId;

		public int TargetId;

		public bool IsGem;

		public int GemItemId;

		public static CastEntry Spell(int spellId, int targetId)
		{
			return new CastEntry
			{
				SpellId = spellId,
				TargetId = targetId
			};
		}

		public static CastEntry Gem(int itemId)
		{
			return new CastEntry
			{
				IsGem = true,
				GemItemId = itemId
			};
		}
	}

	private readonly Healer _healer;

	private BuffState _state = BuffState.Idle;

	private int _castingBaseId;

	private DateTime _stateEntered = DateTime.MinValue;

	private int _castingSpellId;

	private int _castingTargetId;

	private int _fizzleRetries;

	private Queue<CastEntry> _castQueue = new Queue<CastEntry>();

	public bool ReplaceDispelled = true;

	public bool DispelWaitForClear = true;

	// a buff cycle stops between casts when monsters come within the clear range (so they're fought), and carries on
	// with what was left once they're gone
	public bool PauseForMonsters;

	private Queue<CastEntry> _heldQueue;

	private bool _heldBanes;

	private bool _heldManual;

	public float ClearRange = 15f;

	public int RebuffMinutes = 30;

	public bool CreatureEnabled = true;

	public bool LifeEnabled = true;

	public bool ItemEnabled = true;

	public bool BaneItemsEnabled = true;

	public bool BanesEnabled = true;

	public bool SpellGemsEnabled = true;

	public readonly HashSet<int> CreatureExclude = new HashSet<int>();

	public readonly HashSet<int> LifeExclude = new HashSet<int>();

	public readonly HashSet<int> ItemExclude = new HashSet<int>();

	private readonly HashSet<int> _creatureInclude = new HashSet<int>();

	private readonly HashSet<int> _lifeInclude = new HashSet<int>();

	private readonly HashSet<int> _itemInclude = new HashSet<int>();

	public readonly List<BaneItem> BaneItems = new List<BaneItem>();

	public readonly List<SpellGem> SpellGems = new List<SpellGem>();

	private readonly Dictionary<int, DateTime> _groupUsedAt = new Dictionary<int, DateTime>();

	private readonly Dictionary<int, int> _groupUsedBy = new Dictionary<int, int>();

	private int _prevMainHand;

	private int _prevCombatMode;

	private Dictionary<int, double> _buffSnapshot = new Dictionary<int, double>();

	private DateTime _lastSnapshotTime = DateTime.MinValue;

	private readonly HashSet<int> _dispelledSpells = new HashSet<int>();

	public readonly Dictionary<int, DateTime> Dispelled = new Dictionary<int, DateTime>();

	private SpellGem _gemBeingDetected;

	private DateTime _gemDetectionStarted = DateTime.MinValue;

	private bool _rebuffTriggered;

	private bool _manualRebuff;

	private bool _castConfirmedByChat;

	private bool _banesOnly;

	private DateTime _lastCastConfirmed = DateTime.MinValue;

	private bool _paused;

	private int _equipStep;

	private DateTime _lastEquipAction = DateTime.MinValue;

	private bool _skipGearSwap;

	private int _pendingGemId;

	private DateTime _lastCycleEnd = DateTime.MinValue;

	private bool _waitingForHeal;

	private DateTime _healHoldUntil = DateTime.MinValue;

	private DateTime _loadedAt = DateTime.MinValue;

	private DateTime _nextGemCheck = DateTime.MinValue;

	private string _charKey = "";

	private string _status;

	private readonly Settings _s;

	public Func<bool> ExtraHold;

	private DateTime _nextTriggerCheck = DateTime.MinValue;

	private static readonly Regex GemLineRx = new Regex("^(?:You cast (?<s>.+?) on yourself|.+? cast (?<s>.+?) on you)(?:,|\\.|$)", RegexOptions.IgnoreCase);

	private bool _vtankWasEnabled;

	private static CoreManager Core => Globals.Core;

	public bool Enabled { get; private set; }

	public int WandItemId { get; private set; }

	public string WandName { get; private set; }

	private static int GEM_DETECTION_MS => (int)Tuning.V("GemDetectMs");

	public bool MasteryTriggers => CreatureEnabled && !CreatureExclude.Contains(4530);

	public bool Busy => !_paused && _state != BuffState.Idle && _state != BuffState.WaitingForClear;

	public bool Paused => _paused;

	public bool WaitingForHeal => _waitingForHeal;

	public int SpellsLeft => _castQueue.Count;

	public string Status => _status ?? IdleStatus();

	public double RebuffSeconds => (double)RebuffMinutes * 60.0;

	private static string SettingsPath => Util.FullPath("MelkTank_Buffs.xml");

	public Buffer(Healer healer, Settings settings)
	{
		_healer = healer;
		_s = settings;
		WandName = "(none selected)";
	}

	private string IdleStatus()
	{
		return Enabled ? "Enabled - waiting for buffs to run low" : "Disabled";
	}

	private static void Say(string msg)
	{
		Util.WriteToChat("Buffs: " + msg);
	}

	private void SetStatus(string msg = null)
	{
		_status = msg;
	}

	public void Init(string charKey, bool enabled)
	{
		_charKey = charKey;
		InitSpellLists();
		LoadSettings();
		Enabled = enabled;
		_loadedAt = DateTime.Now;
		SetStatus();
	}

	private void InitSpellLists()
	{
		_creatureInclude.Clear();
		foreach (BuffSpell creatureSpell in BuffSpells.CreatureSpells)
		{
			_creatureInclude.Add(creatureSpell.Id);
		}
		_lifeInclude.Clear();
		foreach (BuffSpell lifeSpell in BuffSpells.LifeSpells)
		{
			_lifeInclude.Add(lifeSpell.Id);
		}
		_itemInclude.Clear();
		foreach (BuffSpell itemSpell in BuffSpells.ItemSpells)
		{
			_itemInclude.Add(itemSpell.Id);
		}
	}

	public void Tick()
	{
		try
		{
			long t = Perf.Begin();
			bool flag = (_healer != null && _healer.Active) || (ExtraHold != null && ExtraHold());
			Perf.Lap("  buffer: hold checks", t);
			if (flag)
			{
				if (_state != BuffState.Idle && _state != BuffState.WaitingForClear)
				{
					if (!_waitingForHeal)
					{
						SetStatus("Waiting for heal (" + _castQueue.Count + " left)");
					}
					_waitingForHeal = true;
				}
				return;
			}
			if (_waitingForHeal)
			{
				_waitingForHeal = false;
				_healHoldUntil = DateTime.Now.AddSeconds(0.75);
				_lastCastConfirmed = DateTime.Now;
				if (_state != BuffState.Idle)
				{
					SetStatus("Healed - carrying on (" + _castQueue.Count + " left)");
				}
			}
			if (!(DateTime.Now < _healHoldUntil))
			{
				long t2 = Perf.Begin();
				CheckGemsInInventory();
				TakeBuffSnapshot();
				t2 = Perf.Lap("  buffer: gems / snapshot", t2);
				CheckRebuffTrigger();
				t2 = Perf.Lap("  buffer: rebuff check", t2);
				RunStateMachine();
				Perf.Lap("  buffer: state machine", t2);
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void CheckGemsInInventory()
	{
		if (DateTime.Now < _nextGemCheck || (DateTime.Now - _loadedAt).TotalSeconds < 15.0)
		{
			return;
		}
		_nextGemCheck = DateTime.Now.AddSeconds(5.0);
		bool flag = false;
		foreach (SpellGem spellGem in SpellGems)
		{
			if (spellGem.Enabled && Core.WorldFilter[spellGem.ItemId] == null)
			{
				spellGem.Enabled = false;
				flag = true;
				Say("Gem not in your pack any more, unticked: " + spellGem.Name);
			}
		}
		if (flag)
		{
			SaveSettings();
		}
	}

	private void TakeBuffSnapshot()
	{
		if ((DateTime.Now - _lastSnapshotTime).TotalSeconds < 5.0)
		{
			return;
		}
		_lastSnapshotTime = DateTime.Now;
		Dictionary<int, double> dictionary = new Dictionary<int, double>();
		try
		{
			foreach (EnchantmentWrapper enchantment in Core.CharacterFilter.Enchantments)
			{
				dictionary[enchantment.SpellId] = enchantment.TimeRemaining;
			}
		}
		catch
		{
			return;
		}
		foreach (int item in new List<int>(Dispelled.Keys))
		{
			if (dictionary.ContainsKey(item))
			{
				Dispelled.Remove(item);
			}
		}
		if (_buffSnapshot.Count > 0 && _state == BuffState.Idle)
		{
			foreach (KeyValuePair<int, double> item2 in _buffSnapshot)
			{
				if (!dictionary.ContainsKey(item2.Key) && IsManagedSpell(item2.Key) && _dispelledSpells.Add(item2.Key))
				{
					Say("Buff dispelled: " + GetSpellName(item2.Key));
					Dispelled[item2.Key] = DateTime.Now;
				}
			}
			if (_dispelledSpells.Count > 0 && ReplaceDispelled && Enabled && (!DispelWaitForClear || !MonstersNearby()))
			{
				StartDispelRebuff();
			}
		}
		_buffSnapshot = dictionary;
	}

	public bool IsIncluded(int spellId)
	{
		if (_creatureInclude.Contains(spellId))
		{
			return !CreatureExclude.Contains(spellId);
		}
		if (_lifeInclude.Contains(spellId))
		{
			return !LifeExclude.Contains(spellId);
		}
		if (_itemInclude.Contains(spellId))
		{
			return !ItemExclude.Contains(spellId);
		}
		return false;
	}

	private bool IsManagedSpell(int spellId)
	{
		if (CreatureEnabled && _creatureInclude.Contains(spellId) && !CreatureExclude.Contains(spellId))
		{
			return true;
		}
		if (LifeEnabled && _lifeInclude.Contains(spellId) && !LifeExclude.Contains(spellId))
		{
			return true;
		}
		if (_itemInclude.Contains(spellId) && !ItemExclude.Contains(spellId))
		{
			return BuffSpells.BaneSpellIds.Contains(spellId) ? BanesEnabled : ItemEnabled;
		}
		return false;
	}

	private void CheckRebuffTrigger()
	{
		if (!Enabled || _state != BuffState.Idle || DateTime.Now < _nextTriggerCheck)
		{
			return;
		}
		_nextTriggerCheck = DateTime.Now.AddSeconds(1.0);
		if (SpellGemsEnabled && !_rebuffTriggered && (DateTime.Now - _lastCycleEnd).TotalSeconds >= Tuning.V("GemRecheckS"))
		{
			double rebuffSeconds = RebuffSeconds;
			List<SpellGem> list = new List<SpellGem>();
			HashSet<int> hashSet = new HashSet<int>();
			foreach (SpellGem spellGem in SpellGems)
			{
				if (!spellGem.Enabled)
				{
					continue;
				}
				int num = GameInfo.CooldownGroup(spellGem.Name);
				if (num != 0 && (hashSet.Contains(num) || (_groupUsedAt.TryGetValue(num, out var value) && (DateTime.Now - value).TotalMinutes < Tuning.V("GemSharedCdMin") && _groupUsedBy.ContainsKey(num) && _groupUsedBy[num] != spellGem.ItemId)))
				{
					continue;
				}
				if (!spellGem.Learned)
				{
					list.Add(spellGem);
					if (num != 0)
					{
						hashSet.Add(num);
					}
				}
				else
				{
					if (spellGem.SpellIds.Count == 0)
					{
						continue;
					}
					foreach (int spellId in spellGem.SpellIds)
					{
						double spellRemaining = GetSpellRemaining(spellId);
						if (spellRemaining < 0.0 || spellRemaining < rebuffSeconds)
						{
							list.Add(spellGem);
							if (num != 0)
							{
								hashSet.Add(num);
							}
							break;
						}
					}
				}
			}
			if (list.Count > 0)
			{
				Say(list.Count + " gem(s) need reuse.");
				_castQueue.Clear();
				foreach (SpellGem item in list)
				{
					if (Core.WorldFilter[item.ItemId] != null)
					{
						_castQueue.Enqueue(CastEntry.Gem(item.ItemId));
					}
				}
				if (_castQueue.Count > 0)
				{
					_lastCycleEnd = DateTime.Now;
					EquipWand();
				}
				return;
			}
		}
		if (!_rebuffTriggered && MasteryTriggers)
		{
			double spellRemaining2 = GetSpellRemaining(4530);
			if (spellRemaining2 < 0.0 || spellRemaining2 < RebuffSeconds)
			{
				_rebuffTriggered = true;
				Say("Creature mastery below " + RebuffMinutes + " min. Rebuff triggered.");
			}
		}
	}

	private void RunStateMachine()
	{
		if (_paused)
		{
			return;
		}
		if (!Enabled && !_manualRebuff && _state != BuffState.Idle)
		{
			AbortBuffCycle();
			return;
		}
		switch (_state)
		{
		case BuffState.Idle:
			if (_rebuffTriggered)
			{
				if (MonstersNearby())
				{
					_state = BuffState.WaitingForClear;
					SetStatus("Waiting for monsters to clear...");
				}
				else
				{
					StartFullRebuff();
				}
			}
			break;
		case BuffState.WaitingForClear:
			if (!MonstersNearby())
			{
				if (_heldQueue != null)
				{
					ResumeHeld();
				}
				else
				{
					StartFullRebuff();
				}
			}
			break;
		case BuffState.EquippingWand:
		{
			if ((DateTime.Now - _stateEntered).TotalSeconds < 0.3)
			{
				break;
			}
			_stateEntered = DateTime.Now;
			bool flag2 = (DateTime.Now - _lastEquipAction).TotalSeconds >= Tuning.V("EquipSettleS");
			switch (_equipStep)
			{
			case 0:
				if (Core.Actions.CombatMode == CombatState.Peace)
				{
					_equipStep = 1;
					break;
				}
				SetStatus("Equipping wand - entering peace mode");
				if (!flag2)
				{
					break;
				}
				_lastEquipAction = DateTime.Now;
				try
				{
					Core.Actions.SetCombatMode(CombatState.Peace);
					break;
				}
				catch
				{
					break;
				}
			case 1:
				if (IsWieldedAny(WandItemId))
				{
					_equipStep = 2;
					break;
				}
				SetStatus("Equipping wand - using " + WandName);
				if (!flag2)
				{
					break;
				}
				_lastEquipAction = DateTime.Now;
				try
				{
					Core.Actions.UseItem(WandItemId, 0);
					break;
				}
				catch
				{
					break;
				}
			case 2:
				if (Core.Actions.CombatMode == CombatState.Magic)
				{
					_equipStep = 0;
					CastNextInQueue();
					break;
				}
				SetStatus("Equipping wand - entering magic mode");
				if (!flag2)
				{
					break;
				}
				_lastEquipAction = DateTime.Now;
				try
				{
					Core.Actions.SetCombatMode(CombatState.Magic);
					break;
				}
				catch
				{
					break;
				}
			}
			break;
		}
		case BuffState.WaitNotBusy:
		{
			if ((DateTime.Now - _stateEntered).TotalSeconds < Tuning.V("GemAfterCastS"))
			{
				break;
			}
			_state = BuffState.Casting;
			_stateEntered = DateTime.Now;
			SpellGem spellGem = SpellGems.Find((SpellGem g) => g.ItemId == _pendingGemId);
			WorldObject worldObject = Core.WorldFilter[_pendingGemId];
			if (worldObject == null || !InInventory(_pendingGemId))
			{
				if (spellGem != null)
				{
					spellGem.Enabled = false;
					Say("Gem not in your pack, unticked: " + spellGem.Name);
					SaveSettings();
				}
				CastNextInQueue();
				break;
			}
			if (spellGem != null && !spellGem.Learned)
			{
				_gemBeingDetected = spellGem;
				_gemDetectionStarted = DateTime.Now;
				Say("Learning spells for gem: " + spellGem.Name);
			}
			else
			{
				_gemBeingDetected = null;
			}
			_castingSpellId = 0;
			_castingTargetId = 0;
			_castConfirmedByChat = false;
			SetStatus("Using gem: " + ((spellGem != null) ? spellGem.Name : worldObject.Name));
			int num = GameInfo.CooldownGroup(worldObject.Name);
			if (num != 0)
			{
				_groupUsedAt[num] = DateTime.Now;
				_groupUsedBy[num] = worldObject.Id;
			}
			try
			{
				Core.Actions.UseItem(worldObject.Id, 0);
				break;
			}
			catch
			{
				break;
			}
		}
		case BuffState.Casting:
		{
			double totalSeconds = (DateTime.Now - _stateEntered).TotalSeconds;
			if (_gemBeingDetected != null && !_gemBeingDetected.Learned && totalSeconds < (double)GEM_DETECTION_MS / 1000.0)
			{
				_castConfirmedByChat = false;
			}
			else if (_castConfirmedByChat)
			{
				_castConfirmedByChat = false;
				CastNextInQueue();
			}
			else if (_castingSpellId == 0 && totalSeconds >= 3.0)
			{
				_castConfirmedByChat = false;
				CastNextInQueue();
			}
			else if (_castingSpellId != 0 && totalSeconds >= 0.3 && (DateTime.Now - _lastCastConfirmed).TotalSeconds >= 0.3)
			{
				_lastCastConfirmed = DateTime.Now;
				try
				{
					Core.Actions.CastSpell(_castingSpellId, _castingTargetId);
					break;
				}
				catch
				{
					break;
				}
			}
			break;
		}
		case BuffState.WaitingFizzle:
			if ((DateTime.Now - _stateEntered).TotalSeconds >= Tuning.V("CastRetryS"))
			{
				RetryCast();
			}
			break;
		case BuffState.UnequippingWand:
		{
			if ((DateTime.Now - _stateEntered).TotalSeconds < 0.3)
			{
				break;
			}
			_stateEntered = DateTime.Now;
			bool flag = (DateTime.Now - _lastEquipAction).TotalSeconds >= Tuning.V("RestoreWaitS");
			switch (_equipStep)
			{
			case 0:
				if (Core.Actions.CombatMode == CombatState.Peace)
				{
					_equipStep = 1;
					_lastEquipAction = DateTime.MinValue;
					break;
				}
				SetStatus("Restoring gear - entering peace mode");
				if (!flag)
				{
					break;
				}
				_lastEquipAction = DateTime.Now;
				try
				{
					Core.Actions.SetCombatMode(CombatState.Peace);
					break;
				}
				catch
				{
					break;
				}
			case 1:
				if (_prevMainHand == 0)
				{
					_equipStep = 2;
					_lastEquipAction = DateTime.MinValue;
					break;
				}
				SetStatus("Restoring gear - wielding main hand");
				if (flag)
				{
					_lastEquipAction = DateTime.Now;
					try
					{
						Core.Actions.UseItem(_prevMainHand, 0);
					}
					catch
					{
					}
					_equipStep = 2;
				}
				break;
			case 2:
				if (Core.Actions.CombatMode == (CombatState)_prevCombatMode || _prevCombatMode == 1)
				{
					_equipStep = 0;
					FinishBuffCycle();
					break;
				}
				SetStatus("Restoring gear - restoring combat mode");
				if (!flag)
				{
					break;
				}
				_lastEquipAction = DateTime.Now;
				try
				{
					Core.Actions.SetCombatMode((CombatState)_prevCombatMode);
					break;
				}
				catch
				{
					break;
				}
			}
			break;
		}
		}
	}

	private void StartFullRebuff()
	{
		Say(_banesOnly ? "Rebaning your armor..." : "Starting full rebuff cycle...");
		_castQueue.Clear();
		if (!_banesOnly)
		{
			_dispelledSpells.Clear();
		}
		if (_banesOnly)
		{
			BuildBaneQueue();
		}
		else
		{
			BuildFullCastQueue();
		}
		if (_castQueue.Count == 0)
		{
			Say("No spells to cast.");
			_rebuffTriggered = false;
			_manualRebuff = false;
			_state = BuffState.Idle;
			SetStatus();
		}
		else
		{
			EquipWand();
		}
	}

	private void BuildFullCastQueue()
	{
		int id = Core.CharacterFilter.Id;
		EnqueueIfIncluded(4530, id, CreatureEnabled, _creatureInclude, CreatureExclude);
		EnqueueIfIncluded(4305, id, CreatureEnabled, _creatureInclude, CreatureExclude);
		EnqueueIfIncluded(4329, id, CreatureEnabled, _creatureInclude, CreatureExclude);
		EnqueueIfIncluded(4602, id, CreatureEnabled, _creatureInclude, CreatureExclude);
		EnqueueIfIncluded(4496, id, LifeEnabled, _lifeInclude, LifeExclude);
		EnqueueIfIncluded(4498, id, LifeEnabled, _lifeInclude, LifeExclude);
		EnqueueIfIncluded(4494, id, LifeEnabled, _lifeInclude, LifeExclude);
		HashSet<int> hashSet = new HashSet<int> { 4530, 4305, 4329, 4602 };
		if (CreatureEnabled)
		{
			foreach (BuffSpell creatureSpell in BuffSpells.CreatureSpells)
			{
				if (!hashSet.Contains(creatureSpell.Id))
				{
					EnqueueIfIncluded(creatureSpell.Id, id, schoolEnabled: true, _creatureInclude, CreatureExclude);
				}
			}
		}
		HashSet<int> hashSet2 = new HashSet<int> { 4496, 4498, 4494 };
		if (LifeEnabled)
		{
			foreach (BuffSpell lifeSpell in BuffSpells.LifeSpells)
			{
				if (!hashSet2.Contains(lifeSpell.Id))
				{
					EnqueueIfIncluded(lifeSpell.Id, id, schoolEnabled: true, _lifeInclude, LifeExclude);
				}
			}
		}
		if (ItemEnabled)
		{
			foreach (BuffSpell itemSelfSpell in BuffSpells.ItemSelfSpells)
			{
				EnqueueIfIncluded(itemSelfSpell.Id, id, schoolEnabled: true, _itemInclude, ItemExclude);
			}
		}
		if (BanesEnabled)
		{
			foreach (BuffSpell baneSpell in BuffSpells.BaneSpells)
			{
				EnqueueIfIncluded(baneSpell.Id, id, schoolEnabled: true, _itemInclude, ItemExclude);
			}
		}
		if (BanesEnabled && BaneItemsEnabled)
		{
			foreach (BaneItem baneItem in BaneItems)
			{
				if (!baneItem.Enabled)
				{
					continue;
				}
				foreach (int baneSpellId in BuffSpells.BaneSpellIds)
				{
					if (_itemInclude.Contains(baneSpellId) && !ItemExclude.Contains(baneSpellId))
					{
						_castQueue.Enqueue(CastEntry.Spell(baneSpellId, baneItem.ItemId));
					}
				}
			}
		}
		if (!SpellGemsEnabled)
		{
			return;
		}
		foreach (SpellGem spellGem in SpellGems)
		{
			if (spellGem.Enabled && Core.WorldFilter[spellGem.ItemId] != null)
			{
				_castQueue.Enqueue(CastEntry.Gem(spellGem.ItemId));
			}
		}
	}

	private void BuildBaneQueue()
	{
		int id = Core.CharacterFilter.Id;
		foreach (BuffSpell baneSpell in BuffSpells.BaneSpells)
		{
			EnqueueIfIncluded(baneSpell.Id, id, schoolEnabled: true, _itemInclude, ItemExclude);
		}
		foreach (BaneItem baneItem in BaneItems)
		{
			if (!BaneItemsEnabled || !baneItem.Enabled || Core.WorldFilter[baneItem.ItemId] == null)
			{
				continue;
			}
			foreach (int baneSpellId in BuffSpells.BaneSpellIds)
			{
				if (_itemInclude.Contains(baneSpellId) && !ItemExclude.Contains(baneSpellId))
				{
					_castQueue.Enqueue(CastEntry.Spell(baneSpellId, baneItem.ItemId));
				}
			}
		}
	}

	private void EnqueueIfIncluded(int spellId, int targetId, bool schoolEnabled, HashSet<int> include, HashSet<int> exclude)
	{
		if (schoolEnabled && include.Contains(spellId) && !exclude.Contains(spellId))
		{
			_castQueue.Enqueue(CastEntry.Spell(spellId, targetId));
		}
	}

	private void StartDispelRebuff()
	{
		if (_dispelledSpells.Count == 0)
		{
			return;
		}
		Say("Recasting " + _dispelledSpells.Count + " dispelled spell(s)...");
		_castQueue.Clear();
		int id = Core.CharacterFilter.Id;
		foreach (int dispelledSpell in _dispelledSpells)
		{
			if (!IsManagedSpell(dispelledSpell))
			{
				continue;
			}
			_castQueue.Enqueue(CastEntry.Spell(dispelledSpell, id));
			if (!BuffSpells.BaneSpellIds.Contains(dispelledSpell))
			{
				continue;
			}
			foreach (BaneItem baneItem in BaneItems)
			{
				_castQueue.Enqueue(CastEntry.Spell(dispelledSpell, baneItem.ItemId));
			}
		}
		_dispelledSpells.Clear();
		if (_castQueue.Count > 0)
		{
			EquipWand();
		}
	}

	private void EquipWand()
	{
		bool flag = false;
		foreach (CastEntry item in _castQueue)
		{
			if (!item.IsGem)
			{
				flag = true;
				break;
			}
		}
		if (!flag)
		{
			_skipGearSwap = true;
			_prevCombatMode = (int)Core.Actions.CombatMode;
			VtPause();
			SetStatus("Using gems...");
			CastNextInQueue();
			return;
		}
		if (Core.Actions.CombatMode == CombatState.Magic)
		{
			_skipGearSwap = true;
			_prevCombatMode = 8;
			VtPause();
			SetStatus("Already in magic mode - buffing");
			CastNextInQueue();
			return;
		}
		_skipGearSwap = false;
		int num = PickInstrument(out var name, out var wielded);
		if (num == 0)
		{
			Say("No wand to buff with - wield one, or add one to the Items tab. Aborting.");
			AbortBuffCycle();
			return;
		}
		WandItemId = num;
		WandName = name;
		VtPause();
		try
		{
			int id = Core.CharacterFilter.Id;
			_prevCombatMode = (int)Core.Actions.CombatMode;
			_prevMainHand = 0;
			foreach (WorldObject item2 in InvCache.All())
			{
				try
				{
					if (item2.Values(LongValueKey.Wielder) == id && item2.Values(LongValueKey.WieldingSlot) == 1)
					{
						_prevMainHand = item2.Id;
						break;
					}
				}
				catch
				{
				}
			}
			if (_prevMainHand == 0)
			{
				foreach (WorldObject item3 in Core.WorldFilter.GetLandscape())
				{
					try
					{
						if (item3.Values(LongValueKey.Wielder) == id && item3.Values(LongValueKey.WieldingSlot) == 1)
						{
							_prevMainHand = item3.Id;
							break;
						}
					}
					catch
					{
					}
				}
			}
		}
		catch
		{
		}
		if (wielded)
		{
			_prevMainHand = 0;
		}
		SetStatus(wielded ? ("Using your wielded " + WandName) : ("Equipping " + WandName + "..."));
		_equipStep = 0;
		_lastEquipAction = DateTime.MinValue;
		_state = BuffState.EquippingWand;
		_stateEntered = DateTime.MinValue;
	}

	private void ResumeHeld()
	{
		_castQueue.Clear();
		foreach (CastEntry e in _heldQueue)
		{
			_castQueue.Enqueue(e);
		}
		_banesOnly = _heldBanes;
		_manualRebuff = _heldManual;
		_rebuffTriggered = true;
		_heldQueue = null;
		Say("Monsters gone - carrying on buffing (" + _castQueue.Count + " left).");
		EquipWand();
	}

	private void CastNextInQueue()
	{
		CloseGemDetection();
		if (PauseForMonsters && _castQueue.Count > 0 && MonstersNearby())
		{
			// (between casts: what's left is kept, the gear put back, and the monsters fought)
			_heldQueue = new Queue<CastEntry>(_castQueue);
			_heldBanes = _banesOnly;
			_heldManual = _manualRebuff;
			_castQueue.Clear();
			Say("Buffing paused - monsters within " + ClearRange.ToString("0") + " m. Carrying on when they're gone (" + _heldQueue.Count + " left).");
			RestoreGear();
			return;
		}
		if (_castQueue.Count == 0)
		{
			RestoreGear();
			return;
		}
		CastEntry castEntry = _castQueue.Dequeue();
		if (castEntry.IsGem)
		{
			UseGem(castEntry.GemItemId);
			return;
		}
		int num = castEntry.SpellId;
		if (ServerMode.AllLevels)
		{
			num = SpellLevels.Best(castEntry.SpellId);
			if (num == 0)
			{
				CastNextInQueue();
				return;
			}
		}
		_castingBaseId = castEntry.SpellId;
		_castingSpellId = num;
		_castingTargetId = castEntry.TargetId;
		_fizzleRetries = 0;
		_castConfirmedByChat = false;
		_lastCastConfirmed = DateTime.Now;
		SetStatus("Casting: " + GetSpellName(_castingSpellId));
		try
		{
			Core.Actions.CastSpell(_castingSpellId, _castingTargetId);
		}
		catch (Exception ex)
		{
			Say("Cast error: " + ex.Message);
		}
		_state = BuffState.Casting;
		_stateEntered = DateTime.Now;
	}

	private void CloseGemDetection()
	{
		if (_gemBeingDetected == null)
		{
			return;
		}
		SpellGem gemBeingDetected = _gemBeingDetected;
		_gemBeingDetected = null;
		if (gemBeingDetected.Learned)
		{
			return;
		}
		gemBeingDetected.Learned = true;
		if (gemBeingDetected.SpellIds.Count == 0)
		{
			Say("No spells detected for gem: " + gemBeingDetected.Name + " - it won't be reused. Remove and re-add it to try again.");
		}
		else
		{
			List<string> list = new List<string>();
			foreach (int spellId in gemBeingDetected.SpellIds)
			{
				list.Add(GetSpellName(spellId));
			}
			Say("Learned gem " + gemBeingDetected.Name + ": " + string.Join(", ", list.ToArray()) + ". Remove and re-add the gem to relearn.");
		}
		SaveSettings();
	}

	private void DiscardGemDetection()
	{
		if (_gemBeingDetected != null)
		{
			SpellGem gemBeingDetected = _gemBeingDetected;
			_gemBeingDetected = null;
			if (!gemBeingDetected.Learned && gemBeingDetected.SpellIds.Count > 0)
			{
				gemBeingDetected.SpellIds.Clear();
				gemBeingDetected.MaxDuration = 0.0;
				Say("Gem learning interrupted for " + gemBeingDetected.Name + " - will retry on next use.");
				SaveSettings();
			}
		}
	}

	private void RetryCast()
	{
		if (_castingSpellId == 0)
		{
			CastNextInQueue();
			return;
		}
		_fizzleRetries++;
		SetStatus("Retrying (" + _fizzleRetries + "): " + GetSpellName(_castingSpellId));
		_castConfirmedByChat = false;
		_lastCastConfirmed = DateTime.Now;
		_state = BuffState.Casting;
		_stateEntered = DateTime.Now;
		try
		{
			Core.Actions.CastSpell(_castingSpellId, _castingTargetId);
		}
		catch
		{
		}
	}

	private void UseGem(int itemId)
	{
		_pendingGemId = itemId;
		_state = BuffState.WaitNotBusy;
		_stateEntered = DateTime.Now;
		SpellGem spellGem = SpellGems.Find((SpellGem g) => g.ItemId == itemId);
		SetStatus("Waiting to use gem: " + ((spellGem != null) ? spellGem.Name : itemId.ToString()));
	}

	private void RestoreGear()
	{
		if (_skipGearSwap)
		{
			FinishBuffCycle();
			return;
		}
		SetStatus("Restoring gear...");
		_equipStep = 0;
		_lastEquipAction = DateTime.MinValue;
		_state = BuffState.UnequippingWand;
		_stateEntered = DateTime.MinValue;
	}

	private void FinishBuffCycle()
	{
		CloseGemDetection();
		bool banesOnly = _banesOnly;
		Queue<CastEntry> held = _heldQueue;
		bool hb = _heldBanes, hm = _heldManual;
		ResetCycle();
		if (held != null)
		{
			// (paused for monsters: waiting for them to clear, the rest of the cycle kept)
			_heldQueue = held;
			_heldBanes = hb;
			_heldManual = hm;
			_state = BuffState.WaitingForClear;
			VtResume();
			SetStatus("Paused for monsters - " + held.Count + " buffs left");
			return;
		}
		if (!banesOnly)
		{
			_lastCycleEnd = DateTime.Now;
		}
		VtResume();
		SetStatus();
		Say("Buff cycle complete.");
	}

	private void ResetCycle()
	{
		_castQueue.Clear();
		_rebuffTriggered = false;
		_manualRebuff = false;
		_banesOnly = false;
		_equipStep = 0;
		_castingSpellId = 0;
		_castingTargetId = 0;
		_castConfirmedByChat = false;
		_fizzleRetries = 0;
		_skipGearSwap = false;
		_pendingGemId = 0;
		_paused = false;
		_heldQueue = null;
		_state = BuffState.Idle;
	}

	public void SetEnabled(bool on, bool quiet = false)
	{
		if (Enabled != on)
		{
			Enabled = on;
			if (!quiet)
			{
				Say(on ? "ENABLED." : "DISABLED.");
			}
			if (!on && (_state != BuffState.Idle || _paused))
			{
				AbortBuffCycle();
			}
			SetStatus((_state == BuffState.Idle) ? null : _status);
		}
	}

	/// <summary>A rebuff started by hand is under way: it's carried through even with MelkTank's master switch off.</summary>
	public bool ManualRunning => _manualRebuff && (_state != BuffState.Idle || _paused);

	public void RebuffNow()
	{
		DiscardGemDetection();
		ResetCycle();
		_manualRebuff = true;
		_lastCycleEnd = DateTime.MinValue;
		Say("Manual rebuff triggered.");
		StartFullRebuff();
	}

	public void RebaneNow()
	{
		DiscardGemDetection();
		ResetCycle();
		_manualRebuff = true;
		_banesOnly = true;
		StartFullRebuff();
	}

	public void Stop()
	{
		AbortBuffCycle();
	}

	public void StopIfRunning()
	{
		if (_state != BuffState.Idle || _paused)
		{
			AbortBuffCycle();
		}
	}

	public void TogglePause()
	{
		if (_paused)
		{
			ResumeBuffCycle();
		}
		else
		{
			PauseBuffCycle();
		}
	}

	private void PauseBuffCycle()
	{
		if (_state == BuffState.Idle && !_rebuffTriggered)
		{
			Say("Nothing to pause.");
			return;
		}
		_paused = true;
		DiscardGemDetection();
		VtResume();
		Say("Paused - " + _castQueue.Count + " spell(s) left. Gear left as it is.");
		SetStatus("Paused (" + _castQueue.Count + " spell(s) left)");
	}

	private void ResumeBuffCycle()
	{
		if (_castQueue.Count == 0 && !_rebuffTriggered && _state == BuffState.Idle)
		{
			_paused = false;
			Say("Nothing to resume.");
			SetStatus();
		}
		else if ((_state == BuffState.EquippingWand || _state == BuffState.WaitNotBusy || _state == BuffState.Casting || _state == BuffState.WaitingFizzle || _state == BuffState.UnequippingWand) && !_skipGearSwap && WandItemId != 0 && !InInventory(WandItemId))
		{
			Say("Buffing instrument isn't in your pack any more - stopping instead of resuming.");
			AbortBuffCycle();
		}
		else
		{
			_paused = false;
			VtPause();
			Say("Resumed - " + _castQueue.Count + " spell(s) left.");
			SetStatus("Resumed (" + _castQueue.Count + " left)");
		}
	}

	private void AbortBuffCycle()
	{
		DiscardGemDetection();
		bool flag = _state != BuffState.Idle;
		ResetCycle();
		VtResume();
		if (flag)
		{
			try
			{
				Core.Actions.SetCombatMode((CombatState)_prevCombatMode);
			}
			catch
			{
			}
		}
		SetStatus();
		Say("Buff cycle stopped.");
	}

	public int PickInstrument(out string name, out bool wielded)
	{
		name = "";
		wielded = false;
		try
		{
			int id = Core.CharacterFilter.Id;
			foreach (WorldObject item in InvCache.All())
			{
				try
				{
					if (item.ObjectClass == ObjectClass.WandStaffOrb && item.Values(LongValueKey.Wielder) == id)
					{
						name = ItemLabels.Label(item);
						wielded = true;
						return item.Id;
					}
				}
				catch
				{
				}
			}
			if (_s != null)
			{
				foreach (WeaponItem item2 in _s.Items)
				{
					if (item2.Kind == WeaponKind.Caster)
					{
						WorldObject worldObject = Core.WorldFilter[item2.Id];
						if (worldObject != null && InInventory(item2.Id))
						{
							name = ItemLabels.Label(worldObject);
							return item2.Id;
						}
					}
				}
			}
			if (WandItemId != 0 && Core.WorldFilter[WandItemId] != null && InInventory(WandItemId))
			{
				name = ItemLabels.Label(Core.WorldFilter[WandItemId]);
				return WandItemId;
			}
		}
		catch
		{
		}
		return 0;
	}

	public bool SetWandFromSelection()
	{
		WorldObject worldObject = SelectedInInventory("a wand, staff or orb");
		if (worldObject == null)
		{
			return false;
		}
		WandItemId = worldObject.Id;
		WandName = worldObject.Name;
		SaveSettings();
		Say("Buffing instrument set to " + WandName + ".");
		return true;
	}

	public void AddBaneFromSelection()
	{
		WorldObject obj = SelectedInInventory("an item");
		if (obj != null)
		{
			if (BaneItems.Find((BaneItem b) => b.ItemId == obj.Id) != null)
			{
				Say("Already on the list: " + obj.Name);
				return;
			}
			BaneItems.Add(new BaneItem(obj.Id, obj.Name));
			SaveSettings();
			Say("Bane item added: " + obj.Name);
		}
	}

	public void RemoveUntickedBanes()
	{
		int num = BaneItems.RemoveAll((BaneItem b) => !b.Enabled);
		SaveSettings();
		if (num == 0)
		{
			Say("Untick the bane items to remove first.");
		}
	}

	public void AddGemFromSelection()
	{
		WorldObject obj = SelectedInInventory("a gem");
		if (obj != null)
		{
			if (SpellGems.Find((SpellGem g) => g.ItemId == obj.Id) != null)
			{
				Say("Already on the gem list: " + obj.Name);
				return;
			}
			SpellGems.Add(new SpellGem(obj.Id, obj.Name));
			SaveSettings();
			Say("Spell gem added: " + obj.Name + " - its spells are learned on its next use.");
		}
	}

	public void RemoveUntickedGems()
	{
		int num = 0;
		for (int num2 = SpellGems.Count - 1; num2 >= 0; num2--)
		{
			if (!SpellGems[num2].Enabled)
			{
				if (_gemBeingDetected == SpellGems[num2])
				{
					_gemBeingDetected = null;
				}
				SpellGems.RemoveAt(num2);
				num++;
			}
		}
		SaveSettings();
		if (num == 0)
		{
			Say("Untick the gems to remove first.");
		}
	}

	public void ResetGemLearning(SpellGem gem)
	{
		gem.SpellIds.Clear();
		gem.MaxDuration = 0.0;
		gem.Learned = false;
	}

	public void ToggleExclude(HashSet<int> exclude, int spellId)
	{
		if (!exclude.Remove(spellId))
		{
			exclude.Add(spellId);
		}
		SaveSettings();
	}

	public void SetAll(HashSet<int> exclude, List<BuffSpell> spells, bool on)
	{
		foreach (BuffSpell spell in spells)
		{
			if (on)
			{
				exclude.Remove(spell.Id);
			}
			else
			{
				exclude.Add(spell.Id);
			}
		}
		SaveSettings();
	}

	private static WorldObject SelectedInInventory(string what)
	{
		int currentSelection = Core.Actions.CurrentSelection;
		if (currentSelection == 0)
		{
			Say("Select " + what + " in your inventory first.");
			return null;
		}
		WorldObject worldObject = Core.WorldFilter[currentSelection];
		if (worldObject == null)
		{
			return null;
		}
		if (!InInventory(currentSelection))
		{
			Say("Select " + what + " from your inventory.");
			return null;
		}
		return worldObject;
	}

	private static bool InInventory(int id)
	{
		foreach (WorldObject item in InvCache.All())
		{
			if (item.Id == id)
			{
				return true;
			}
		}
		return false;
	}

	public void ProcessCommand(string[] tokens, Action<bool> setEnabled)
	{
		if (tokens.Length < 2)
		{
			PrintHelp();
			return;
		}
		switch (tokens[1].ToLowerInvariant())
		{
		case "on":
			setEnabled(obj: true);
			break;
		case "off":
			setEnabled(obj: false);
			break;
		case "buff":
			RebuffNow();
			break;
		case "stop":
			AbortBuffCycle();
			break;
		case "pause":
			PauseBuffCycle();
			break;
		case "resume":
			ResumeBuffCycle();
			break;
		case "gems":
			PrintGems();
			break;
		case "relearn":
			RelearnGems(tokens);
			break;
		default:
			PrintHelp();
			break;
		}
	}

	private void PrintGems()
	{
		if (SpellGems.Count == 0)
		{
			Say("No spell gems set up.");
			return;
		}
		for (int i = 0; i < SpellGems.Count; i++)
		{
			SpellGem spellGem = SpellGems[i];
			string text = i + 1 + ". " + spellGem.Name + (spellGem.Enabled ? "" : " (unticked)");
			if (!spellGem.Learned)
			{
				Say(text + " - not learned yet");
				continue;
			}
			if (spellGem.SpellIds.Count == 0)
			{
				Say(text + " - learned, no spells detected");
				continue;
			}
			List<string> list = new List<string>();
			foreach (int spellId in spellGem.SpellIds)
			{
				list.Add(GetSpellName(spellId));
			}
			Say(text + " - " + string.Join(", ", list.ToArray()));
		}
		Say("/mbuff relearn <#|all> clears a gem's spells so it learns them again.");
	}

	private void RelearnGems(string[] tokens)
	{
		if (tokens.Length < 3)
		{
			Say("Usage: /mbuff relearn <#|all>   (see /mbuff gems)");
			return;
		}
		if (tokens[2].ToLowerInvariant() == "all")
		{
			foreach (SpellGem spellGem in SpellGems)
			{
				ResetGemLearning(spellGem);
			}
			Say("All gems reset - they relearn on next use.");
		}
		else
		{
			if (!int.TryParse(tokens[2], out var result) || result < 1 || result > SpellGems.Count)
			{
				Say("Invalid gem number. See /mbuff gems.");
				return;
			}
			ResetGemLearning(SpellGems[result - 1]);
			Say("Reset " + SpellGems[result - 1].Name + " - it relearns on next use.");
		}
		SaveSettings();
	}

	private static void PrintHelp()
	{
		Say("/mbuff on | off | buff (rebuff now) | stop | pause | resume | gems | relearn <#|all>");
	}

	public void OnChangeEnchantments(EventArgs e)
	{
		try
		{
			EnchantmentWrapper enchantmentWrapper = null;
			string text = "";
			try
			{
				PropertyInfo property = e.GetType().GetProperty("Enchantment");
				if (property != null)
				{
					enchantmentWrapper = property.GetValue(e, null) as EnchantmentWrapper;
				}
				PropertyInfo property2 = e.GetType().GetProperty("Type");
				if (property2 != null)
				{
					text = Convert.ToString(property2.GetValue(e, null));
				}
			}
			catch
			{
			}
			if (enchantmentWrapper != null && _gemBeingDetected != null && !_gemBeingDetected.Learned && (DateTime.Now - _gemDetectionStarted).TotalMilliseconds <= (double)GEM_DETECTION_MS && text == "Add")
			{
				if (enchantmentWrapper.SpellId > 0 && !BuffSpells.GemSpellBlacklist.Contains(enchantmentWrapper.SpellId) && !_gemBeingDetected.SpellIds.Contains(enchantmentWrapper.SpellId))
				{
					_gemBeingDetected.SpellIds.Add(enchantmentWrapper.SpellId);
					SaveSettings();
				}
				if (enchantmentWrapper.Duration > _gemBeingDetected.MaxDuration)
				{
					_gemBeingDetected.MaxDuration = enchantmentWrapper.Duration;
				}
			}
			if (_state != BuffState.Casting)
			{
				return;
			}
			bool num;
			if (_castingSpellId == 0)
			{
				if (!(text == "Add"))
				{
					return;
				}
				num = (DateTime.Now - _stateEntered).TotalSeconds > 0.5;
			}
			else
			{
				if (enchantmentWrapper == null)
				{
					return;
				}
				num = enchantmentWrapper.SpellId == _castingSpellId;
			}
			if (num)
			{
				_castConfirmedByChat = true;
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public bool OnChat(string raw)
	{
		if (string.IsNullOrEmpty(raw))
		{
			return false;
		}
		string text = raw.Trim().ToLowerInvariant();
		if (text.Contains("unknown command") && text.Contains("vt"))
		{
			return true;
		}
		// The server won't cast it for want of components: the next level down that can be, or on to the next spell -
		// not the same one over and over.
		if (_state == BuffState.Casting && _castingSpellId != 0 && text.Contains("don't have all the components"))
		{
			int was = _castingSpellId;
			SpellLevels.Refused(was);
			int alt = (ServerMode.AllLevels && _castingBaseId != 0) ? SpellLevels.Best(_castingBaseId) : 0;
			if (alt != 0 && alt != was && !SpellLevels.IsRefused(alt))
			{
				Say("No components for " + SpellLevels.Name(was) + " - casting " + SpellLevels.Name(alt) + " instead.");
				_castingSpellId = alt;
				_castConfirmedByChat = false;
				_lastCastConfirmed = DateTime.Now;
				_stateEntered = DateTime.Now;
				SetStatus("Casting: " + GetSpellName(alt));
			}
			else
			{
				Say("No components for " + SpellLevels.Name(was) + " - skipped.");
				_castConfirmedByChat = false;
				CastNextInQueue();
			}
			return false;
		}
		if (_state == BuffState.Casting && text.Contains("your spell fizzled"))
		{
			_state = BuffState.WaitingFizzle;
			_stateEntered = DateTime.Now;
			return false;
		}
		if (_gemBeingDetected != null && !_gemBeingDetected.Learned && (DateTime.Now - _gemDetectionStarted).TotalMilliseconds <= (double)(GEM_DETECTION_MS + 1000) && text.IndexOf("surpassed by", StringComparison.Ordinal) < 0)
		{
			Match match = GemLineRx.Match(Plain(raw.Trim()));
			if (match.Success)
			{
				LearnGemSpellByName(match.Groups["s"].Value.Trim());
			}
		}
		if (_state == BuffState.Casting && _castingSpellId != 0 && BuffSpells.BaneSpellIds.Contains(_castingSpellId) && text.StartsWith("you cast ") && text.Contains(GetSpellName(_castingSpellId).ToLowerInvariant()))
		{
			_castConfirmedByChat = true;
		}
		return false;
	}

	private void LearnGemSpellByName(string name)
	{
		try
		{
			SpellGem gemBeingDetected = _gemBeingDetected;
			if (gemBeingDetected == null)
			{
				return;
			}
			foreach (EnchantmentWrapper enchantment in Core.CharacterFilter.Enchantments)
			{
				if (enchantment.SpellId <= 0 || !string.Equals(GetSpellName(enchantment.SpellId), name, StringComparison.OrdinalIgnoreCase))
				{
					continue;
				}
				if (!BuffSpells.GemSpellBlacklist.Contains(enchantment.SpellId) && !gemBeingDetected.SpellIds.Contains(enchantment.SpellId))
				{
					gemBeingDetected.SpellIds.Add(enchantment.SpellId);
					if (enchantment.Duration > gemBeingDetected.MaxDuration)
					{
						gemBeingDetected.MaxDuration = enchantment.Duration;
					}
					SaveSettings();
				}
				break;
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static double GetSpellRemaining(int spellId)
	{
		if (ServerMode.AllLevels)
		{
			double num = SpellLevels.FamilyRemaining(spellId);
			if (num != -2.0)
			{
				return num;
			}
		}
		try
		{
			foreach (EnchantmentWrapper enchantment in Core.CharacterFilter.Enchantments)
			{
				if (enchantment.SpellId == spellId)
				{
					return enchantment.TimeRemaining;
				}
			}
		}
		catch
		{
		}
		try
		{
			string spellName = GetSpellName(spellId);
			if (spellName.StartsWith("Spell "))
			{
				return -1.0;
			}
			double num2 = -1.0;
			foreach (EnchantmentWrapper enchantment2 in Core.CharacterFilter.Enchantments)
			{
				if (enchantment2.SpellId != spellId && string.Equals(GetSpellName(enchantment2.SpellId), spellName, StringComparison.OrdinalIgnoreCase) && (double)enchantment2.TimeRemaining > num2)
				{
					num2 = enchantment2.TimeRemaining;
				}
			}
			return num2;
		}
		catch
		{
			return -1.0;
		}
	}

	private static bool IsWieldedAny(int itemId)
	{
		try
		{
			WorldObject worldObject = Core.WorldFilter[itemId];
			return worldObject != null && worldObject.Values(LongValueKey.Wielder) == Core.CharacterFilter.Id;
		}
		catch
		{
			return false;
		}
	}

	private bool MonstersNearby()
	{
		try
		{
			WorldObject worldObject = Core.WorldFilter[Core.CharacterFilter.Id];
			string value = Core.CharacterFilter.Name + "'s ";
			foreach (WorldObject item in Core.WorldFilter.GetLandscape())
			{
				if (item.ObjectClass != ObjectClass.Monster || item.Name.StartsWith(value, StringComparison.OrdinalIgnoreCase))
				{
					continue;
				}
				if (worldObject == null)
				{
					return true;
				}
				try
				{
					double num = item.RawCoordinates().X - worldObject.RawCoordinates().X;
					double num2 = item.RawCoordinates().Y - worldObject.RawCoordinates().Y;
					double num3 = item.RawCoordinates().Z - worldObject.RawCoordinates().Z;
					if (Math.Sqrt(num * num + num2 * num2 + num3 * num3) <= (double)ClearRange)
					{
						return true;
					}
				}
				catch
				{
					return true;
				}
			}
		}
		catch
		{
		}
		return false;
	}

	public static string GetSpellName(int spellId)
	{
		foreach (BuffSpell creatureSpell in BuffSpells.CreatureSpells)
		{
			if (creatureSpell.Id == spellId)
			{
				return ShortName(creatureSpell.Name);
			}
		}
		foreach (BuffSpell lifeSpell in BuffSpells.LifeSpells)
		{
			if (lifeSpell.Id == spellId)
			{
				return ShortName(lifeSpell.Name);
			}
		}
		foreach (BuffSpell itemSpell in BuffSpells.ItemSpells)
		{
			if (itemSpell.Id == spellId)
			{
				return ShortName(itemSpell.Name);
			}
		}
		string text = SpellNames.Name(spellId);
		return string.IsNullOrEmpty(text) ? ("Spell " + spellId) : Plain(text);
	}

	public static string Plain(string s)
	{
		return (s ?? "").Replace('’', '\'').Replace('‘', '\'').Replace('“', '"')
			.Replace('”', '"');
	}

	public static string ShortName(string n)
	{
		return (n ?? "").Replace("Aura of Incantation of ", "").Replace("Incantation of ", "").Replace("Aura of ", "");
	}

	public static string FormatTime(double seconds)
	{
		if (seconds <= 0.0)
		{
			return "not active";
		}
		int num = (int)seconds;
		int num2 = num / 3600;
		int num3 = num % 3600 / 60;
		if (num2 > 0)
		{
			return num2 + "h " + num3 + "m";
		}
		return num3 + "m " + num % 60 + "s";
	}

	private static Type GetVTankType()
	{
		Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
		foreach (Assembly assembly in assemblies)
		{
			if (assembly.FullName.Contains("UtilityBelt.Helper"))
			{
				Type type = assembly.GetType("UBHelper.vTank");
				if (type != null)
				{
					return type;
				}
			}
		}
		return null;
	}

	private static PropertyInfo MacroProp(out object instance)
	{
		instance = null;
		Type vTankType = GetVTankType();
		if (vTankType == null)
		{
			return null;
		}
		PropertyInfo property = vTankType.GetProperty("Instance");
		instance = ((property == null) ? null : property.GetValue(null, null));
		return (instance == null) ? null : instance.GetType().GetProperty("MacroEnabled");
	}

	private void VtPause()
	{
		try
		{
			PropertyInfo propertyInfo = MacroProp(out var instance);
			if (!(propertyInfo == null))
			{
				object value = propertyInfo.GetValue(instance, null);
				if (value is bool)
				{
					_vtankWasEnabled = (bool)value;
				}
				if (_vtankWasEnabled)
				{
					propertyInfo.SetValue(instance, false, null);
				}
			}
		}
		catch
		{
		}
	}

	private void VtResume()
	{
		try
		{
			if (_vtankWasEnabled)
			{
				_vtankWasEnabled = false;
				PropertyInfo propertyInfo = MacroProp(out var instance);
				if (propertyInfo != null)
				{
					propertyInfo.SetValue(instance, true, null);
				}
			}
		}
		catch
		{
		}
	}

	private static void MigrateOldSettings()
	{
		try
		{
			if (File.Exists(SettingsPath))
			{
				return;
			}
			string directoryName = Path.GetDirectoryName(Util.BasePath.TrimEnd(new char[2] { '\\', '/' }));
			string[] array = new string[2] { "MelksBuffer\\bin\\Debug\\MelksBuffer_Settings.xml", "MelksBuffer\\MelksBuffer_Settings.xml" };
			foreach (string path in array)
			{
				string text = Path.Combine(directoryName, path);
				if (File.Exists(text))
				{
					File.Copy(text, SettingsPath);
					Say("Copied your MelksBuffer settings into MelkTank_Buffs.xml.");
					break;
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void LoadSettings()
	{
		try
		{
			MigrateOldSettings();
			if (!File.Exists(SettingsPath))
			{
				return;
			}
			XmlDocument xmlDocument = new XmlDocument();
			Util.LoadXml(xmlDocument, SettingsPath);
			XmlNode xmlNode = xmlDocument.SelectSingleNode("/MelksBuffer/Character[@key='" + _charKey + "']");
			if (xmlNode == null)
			{
				return;
			}
			if (bool.TryParse(GetXml(xmlNode, "ReplaceDispelled"), out var result))
			{
				ReplaceDispelled = result;
			}
			if (bool.TryParse(GetXml(xmlNode, "DispelWaitClear"), out result))
			{
				DispelWaitForClear = result;
			}
			if (bool.TryParse(GetXml(xmlNode, "PauseForMonsters"), out result))
			{
				PauseForMonsters = result;
			}
			if (double.TryParse(GetXml(xmlNode, "ClearRange"), NumberStyles.Float, CultureInfo.InvariantCulture, out var result2) && result2 > 0.0)
			{
				ClearRange = (float)result2;
			}
			if (int.TryParse(GetXml(xmlNode, "RebuffMinutes"), out var result3) && result3 > 0)
			{
				RebuffMinutes = result3;
			}
			if (bool.TryParse(GetXml(xmlNode, "CreatureEnabled"), out result))
			{
				CreatureEnabled = result;
			}
			if (bool.TryParse(GetXml(xmlNode, "LifeEnabled"), out result))
			{
				LifeEnabled = result;
			}
			if (bool.TryParse(GetXml(xmlNode, "ItemEnabled"), out result))
			{
				ItemEnabled = result;
			}
			if (bool.TryParse(GetXml(xmlNode, "BaneItemsEnabled"), out result))
			{
				BaneItemsEnabled = result;
			}
			BanesEnabled = ItemEnabled;
			if (bool.TryParse(GetXml(xmlNode, "BanesEnabled"), out result))
			{
				BanesEnabled = result;
			}
			if (bool.TryParse(GetXml(xmlNode, "SpellGemsEnabled"), out result))
			{
				SpellGemsEnabled = result;
			}
			if (int.TryParse(GetXml(xmlNode, "WandItemId"), out result3))
			{
				WandItemId = result3;
			}
			string xml = GetXml(xmlNode, "WandName");
			WandName = (string.IsNullOrEmpty(xml) ? "(none selected)" : xml);
			LoadSpellSet(xmlNode, "CreatureExclude", CreatureExclude);
			LoadSpellSet(xmlNode, "LifeExclude", LifeExclude);
			LoadSpellSet(xmlNode, "ItemExclude", ItemExclude);
			BaneItems.Clear();
			foreach (XmlNode item in xmlNode.SelectNodes("BaneItems/Item"))
			{
				if (item.Attributes["id"] != null && int.TryParse(item.Attributes["id"].Value, out var result4))
				{
					BaneItem baneItem = new BaneItem(result4, item.InnerText);
					bool result5 = true;
					if (item.Attributes["enabled"] != null)
					{
						bool.TryParse(item.Attributes["enabled"].Value, out result5);
					}
					baneItem.Enabled = result5;
					BaneItems.Add(baneItem);
				}
			}
			SpellGems.Clear();
			foreach (XmlNode item2 in xmlNode.SelectNodes("SpellGems/Gem"))
			{
				if (item2.Attributes["id"] == null || !int.TryParse(item2.Attributes["id"].Value, out var result6))
				{
					continue;
				}
				SpellGem spellGem = new SpellGem(result6, (item2.Attributes["name"] != null) ? item2.Attributes["name"].Value : item2.Attributes["id"].Value);
				bool result7 = true;
				if (item2.Attributes["enabled"] != null)
				{
					bool.TryParse(item2.Attributes["enabled"].Value, out result7);
				}
				spellGem.Enabled = result7;
				double result8 = 0.0;
				if (item2.Attributes["maxDuration"] != null)
				{
					double.TryParse(item2.Attributes["maxDuration"].Value, NumberStyles.Float, CultureInfo.InvariantCulture, out result8);
				}
				spellGem.MaxDuration = result8;
				foreach (XmlNode item3 in item2.SelectNodes("SpellId"))
				{
					if (int.TryParse(item3.InnerText, out var result9) && result9 > 0 && !BuffSpells.GemSpellBlacklist.Contains(result9) && !spellGem.SpellIds.Contains(result9))
					{
						spellGem.SpellIds.Add(result9);
					}
				}
				bool result10 = spellGem.SpellIds.Count > 0;
				if (item2.Attributes["learned"] != null)
				{
					bool.TryParse(item2.Attributes["learned"].Value, out result10);
				}
				spellGem.Learned = result10;
				SpellGems.Add(spellGem);
			}
		}
		catch (Exception ex)
		{
			Say("Couldn't read MelkTank_Buffs.xml: " + ex.Message);
			Util.LogError(ex);
		}
	}

	public void SaveSettings()
	{
		Util.Locked(SettingsPath, SaveSettingsLocked);
	}

	private void SaveSettingsLocked()
	{
		try
		{
			if (_charKey.Length == 0)
			{
				return;
			}
			XmlDocument xmlDocument = new XmlDocument();
			XmlElement xmlElement;
			if (File.Exists(SettingsPath))
			{
				Util.LoadXml(xmlDocument, SettingsPath);
				xmlElement = xmlDocument.DocumentElement;
			}
			else
			{
				xmlElement = xmlDocument.CreateElement("MelksBuffer");
				xmlDocument.AppendChild(xmlElement);
			}
			XmlNode xmlNode = xmlElement.SelectSingleNode("Character[@key='" + _charKey + "']");
			if (xmlNode == null)
			{
				XmlElement xmlElement2 = xmlDocument.CreateElement("Character");
				xmlElement2.SetAttribute("key", _charKey);
				xmlElement.AppendChild(xmlElement2);
				xmlNode = xmlElement2;
			}
			string[] array = new string[5] { "Enabled", "HealKitItemId", "HealKitName", "HealPercent", "HealAnytime" };
			foreach (string name in array)
			{
				RemoveChild(xmlNode, name);
			}
			SetXml(xmlDocument, xmlNode, "ReplaceDispelled", ReplaceDispelled.ToString());
			SetXml(xmlDocument, xmlNode, "DispelWaitClear", DispelWaitForClear.ToString());
			SetXml(xmlDocument, xmlNode, "PauseForMonsters", PauseForMonsters.ToString());
			SetXml(xmlDocument, xmlNode, "ClearRange", ClearRange.ToString(CultureInfo.InvariantCulture));
			SetXml(xmlDocument, xmlNode, "RebuffMinutes", RebuffMinutes.ToString());
			SetXml(xmlDocument, xmlNode, "CreatureEnabled", CreatureEnabled.ToString());
			SetXml(xmlDocument, xmlNode, "LifeEnabled", LifeEnabled.ToString());
			SetXml(xmlDocument, xmlNode, "ItemEnabled", ItemEnabled.ToString());
			SetXml(xmlDocument, xmlNode, "BaneItemsEnabled", BaneItemsEnabled.ToString());
			SetXml(xmlDocument, xmlNode, "BanesEnabled", BanesEnabled.ToString());
			SetXml(xmlDocument, xmlNode, "SpellGemsEnabled", SpellGemsEnabled.ToString());
			SetXml(xmlDocument, xmlNode, "WandItemId", WandItemId.ToString());
			SetXml(xmlDocument, xmlNode, "WandName", WandName);
			SaveSpellSet(xmlDocument, xmlNode, "CreatureExclude", CreatureExclude);
			SaveSpellSet(xmlDocument, xmlNode, "LifeExclude", LifeExclude);
			SaveSpellSet(xmlDocument, xmlNode, "ItemExclude", ItemExclude);
			RemoveChild(xmlNode, "BaneItems");
			XmlElement xmlElement3 = xmlDocument.CreateElement("BaneItems");
			xmlNode.AppendChild(xmlElement3);
			foreach (BaneItem baneItem in BaneItems)
			{
				XmlElement xmlElement4 = xmlDocument.CreateElement("Item");
				xmlElement4.SetAttribute("id", baneItem.ItemId.ToString());
				xmlElement4.SetAttribute("enabled", baneItem.Enabled.ToString());
				xmlElement4.InnerText = baneItem.Name;
				xmlElement3.AppendChild(xmlElement4);
			}
			RemoveChild(xmlNode, "SpellGems");
			XmlElement xmlElement5 = xmlDocument.CreateElement("SpellGems");
			xmlNode.AppendChild(xmlElement5);
			foreach (SpellGem spellGem in SpellGems)
			{
				XmlElement xmlElement6 = xmlDocument.CreateElement("Gem");
				xmlElement6.SetAttribute("id", spellGem.ItemId.ToString());
				xmlElement6.SetAttribute("enabled", spellGem.Enabled.ToString());
				xmlElement6.SetAttribute("name", spellGem.Name);
				xmlElement6.SetAttribute("maxDuration", spellGem.MaxDuration.ToString(CultureInfo.InvariantCulture));
				xmlElement6.SetAttribute("learned", spellGem.Learned.ToString());
				foreach (int spellId in spellGem.SpellIds)
				{
					XmlElement xmlElement7 = xmlDocument.CreateElement("SpellId");
					xmlElement7.InnerText = spellId.ToString();
					xmlElement6.AppendChild(xmlElement7);
				}
				xmlElement5.AppendChild(xmlElement6);
			}
			Util.SaveXml(xmlDocument, SettingsPath);
		}
		catch (Exception ex)
		{
			Say("Couldn't save MelkTank_Buffs.xml: " + ex.Message);
			Util.LogError(ex);
		}
	}

	private static string GetXml(XmlNode parent, string name)
	{
		XmlNode xmlNode = parent.SelectSingleNode(name);
		return (xmlNode != null) ? xmlNode.InnerText : "";
	}

	private static void SetXml(XmlDocument doc, XmlNode parent, string name, string value)
	{
		XmlNode xmlNode = parent.SelectSingleNode(name);
		if (xmlNode != null)
		{
			xmlNode.InnerText = value;
			return;
		}
		XmlElement xmlElement = doc.CreateElement(name);
		xmlElement.InnerText = value;
		parent.AppendChild(xmlElement);
	}

	private static void RemoveChild(XmlNode parent, string name)
	{
		XmlNode xmlNode = parent.SelectSingleNode(name);
		if (xmlNode != null)
		{
			parent.RemoveChild(xmlNode);
		}
	}

	private static void LoadSpellSet(XmlNode parent, string name, HashSet<int> set)
	{
		set.Clear();
		foreach (XmlNode item in parent.SelectNodes(name + "/Spell"))
		{
			if (int.TryParse(item.InnerText, out var result))
			{
				set.Add(result);
			}
		}
	}

	private static void SaveSpellSet(XmlDocument doc, XmlNode parent, string name, HashSet<int> set)
	{
		RemoveChild(parent, name);
		XmlElement xmlElement = doc.CreateElement(name);
		parent.AppendChild(xmlElement);
		foreach (int item in set)
		{
			XmlElement xmlElement2 = doc.CreateElement("Spell");
			xmlElement2.InnerText = item.ToString();
			xmlElement.AppendChild(xmlElement2);
		}
	}
}
