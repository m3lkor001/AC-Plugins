namespace MelkTank.Buffs;

public class BuffSpell
{
	public int Id { get; set; }

	public string Name { get; set; }

	public string School { get; set; }

	public BuffSpell(int id, string name, string school)
	{
		Id = id;
		Name = name;
		School = school;
	}
}
