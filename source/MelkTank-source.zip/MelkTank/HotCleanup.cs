using System;
using System.Collections;
using System.Reflection;
using System.Runtime.InteropServices;

namespace MelkTank;

internal static class HotCleanup
{
	private struct MEMORYSTATUSEX
	{
		public uint dwLength;

		public uint dwMemoryLoad;

		public ulong ullTotalPhys;

		public ulong ullAvailPhys;

		public ulong ullTotalPageFile;

		public ulong ullAvailPageFile;

		public ulong ullTotalVirtual;

		public ulong ullAvailVirtual;

		public ulong ullAvailExtendedVirtual;
	}

	private struct PROCESS_MEMORY_COUNTERS_EX
	{
		public uint cb;

		public uint PageFaultCount;

		public nuint PeakWorkingSetSize;

		public nuint WorkingSetSize;

		public nuint QuotaPeakPagedPoolUsage;

		public nuint QuotaPagedPoolUsage;

		public nuint QuotaPeakNonPagedPoolUsage;

		public nuint QuotaNonPagedPoolUsage;

		public nuint PagefileUsage;

		public nuint PeakPagefileUsage;

		public nuint PrivateUsage;
	}

	public static int Free()
	{
		int num = 0;
		Type[] types;
		try
		{
			types = Assembly.GetExecutingAssembly().GetTypes();
		}
		catch (ReflectionTypeLoadException ex)
		{
			types = ex.Types;
		}
		Type[] array = types;
		foreach (Type type in array)
		{
			if (type == null || type.IsGenericTypeDefinition)
			{
				continue;
			}
			FieldInfo[] fields;
			try
			{
				fields = type.GetFields(BindingFlags.DeclaredOnly | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
			}
			catch
			{
				continue;
			}
			FieldInfo[] array2 = fields;
			foreach (FieldInfo fieldInfo in array2)
			{
				try
				{
					if (fieldInfo.IsLiteral || fieldInfo.FieldType.IsValueType || fieldInfo.FieldType == typeof(string))
					{
						continue;
					}
					object value = fieldInfo.GetValue(null);
					if (value == null || Native(value.GetType()) || Marshal.IsComObject(value))
					{
						continue;
					}
					if (value is Array)
					{
						Array array3 = (Array)value;
						if (!array3.GetType().GetElementType().IsValueType && array3.Length > 0)
						{
							Array.Clear(array3, 0, array3.Length);
							num++;
						}
					}
					else if (value is IDictionary)
					{
						((IDictionary)value).Clear();
						num++;
					}
					else if (value is IList && !((IList)value).IsReadOnly && !((IList)value).IsFixedSize)
					{
						((IList)value).Clear();
						num++;
					}
					else
					{
						MethodInfo method = value.GetType().GetMethod("Clear", Type.EmptyTypes);
						if (method != null && value is IEnumerable)
						{
							method.Invoke(value, null);
							num++;
						}
					}
					if (!fieldInfo.IsInitOnly)
					{
						fieldInfo.SetValue(null, null);
						num++;
					}
				}
				catch
				{
				}
			}
		}
		return num;
	}

	private static bool Native(Type t)
	{
		if (t == null)
		{
			return false;
		}
		if (t.IsArray)
		{
			return Native(t.GetElementType());
		}
		if (t.IsCOMObject || t.IsInterface || t == typeof(object))
		{
			return true;
		}
		string text = t.Assembly.GetName().Name ?? "";
		if (text.StartsWith("Decal", StringComparison.OrdinalIgnoreCase) || text.StartsWith("UtilityBelt", StringComparison.OrdinalIgnoreCase) || text.StartsWith("UB", StringComparison.Ordinal) || text.IndexOf("ImGui", StringComparison.OrdinalIgnoreCase) >= 0 || text.StartsWith("Interop", StringComparison.OrdinalIgnoreCase) || text.StartsWith("System.Drawing", StringComparison.OrdinalIgnoreCase))
		{
			return true;
		}
		if (t.IsGenericType)
		{
			Type[] genericArguments = t.GetGenericArguments();
			foreach (Type t2 in genericArguments)
			{
				if (Native(t2))
				{
					return true;
				}
			}
		}
		return false;
	}

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern bool GlobalMemoryStatusEx(ref MEMORYSTATUSEX m);

	[DllImport("psapi.dll", SetLastError = true)]
	private static extern bool GetProcessMemoryInfo(nint process, out PROCESS_MEMORY_COUNTERS_EX c, uint size);

	[DllImport("kernel32.dll")]
	private static extern nint GetCurrentProcess();

	public static long PrivateBytes()
	{
		try
		{
			if (GetProcessMemoryInfo(GetCurrentProcess(), out var c, (uint)Marshal.SizeOf(typeof(PROCESS_MEMORY_COUNTERS_EX))))
			{
				long num = (long)((UIntPtr)c.PrivateUsage).ToUInt64();
				if (num <= 0)
				{
					num = (long)((UIntPtr)c.PagefileUsage).ToUInt64();
				}
				if (num > 0)
				{
					return num;
				}
			}
		}
		catch
		{
		}
		return -1L;
	}

	public static bool AddressSpace(out long used, out long total)
	{
		used = (total = 0L);
		try
		{
			MEMORYSTATUSEX m = new MEMORYSTATUSEX
			{
				dwLength = (uint)Marshal.SizeOf(typeof(MEMORYSTATUSEX))
			};
			if (!GlobalMemoryStatusEx(ref m) || m.ullTotalVirtual == 0)
			{
				return false;
			}
			total = (long)m.ullTotalVirtual;
			used = (long)(m.ullTotalVirtual - m.ullAvailVirtual);
			return true;
		}
		catch
		{
			return false;
		}
	}
}
