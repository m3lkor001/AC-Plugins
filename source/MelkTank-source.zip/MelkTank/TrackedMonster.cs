using System;
using System.Collections.Generic;

namespace MelkTank;

public class TrackedMonster
{
	public int Id;

	public string Name;

	public DateTime DeadAt = DateTime.MinValue;

	public readonly Dictionary<Slot, ActiveDebuff> Debuffs = new Dictionary<Slot, ActiveDebuff>();

	public DateTime FirstSeen = DateTime.Now;

	public DateTime PrimedAt = DateTime.MinValue;

	public DateTime ReleasedAt = DateTime.MinValue;

	public bool FractureDone;

	public bool EverPrimed;

	public DateTime GamePrimedAt = DateTime.MinValue;

	public DateTime FractureCastAt = DateTime.MinValue;

	public bool SpreadMissed;

	public bool Alert;

	public int Misses;

	public bool Blocked;

	// (a wall or object between us, seen before anything was fired: skipped till the line is clear again)
	public bool WallBlocked;

	public DateTime WallCheckAt = DateTime.MinValue;

	public double BlockX;

	public double BlockY;

	public DateTime BlockedAt = DateTime.MinValue;

	public DateTime DeferUntil = DateTime.MinValue;

	public int MissileMisses;

	public double MissileX;

	public double MissileY;

	public readonly Dictionary<Slot, DateTime> RetryAfter = new Dictionary<Slot, DateTime>();

	public DateTime EngagedAt = DateTime.MinValue;

	public bool HasLand;

	public double LandX;

	public double LandY;

	public double LandDist;

	public bool Deferred => DateTime.Now < DeferUntil;
}
