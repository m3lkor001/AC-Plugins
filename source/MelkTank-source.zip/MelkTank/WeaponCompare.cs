using System;
using System.Collections.Generic;
using System.Globalization;
using System.Numerics;
using System.Text.RegularExpressions;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Loot;

namespace MelkTank;

public class WeaponCompare
{
	public class Result
	{
		public string Time;

		public string Weapon;

		public string Mob;

		public double Seconds;

		public long Total;

		public long HitDamage;

		public long Overkill;

		public int Hits;

		public int Crits;

		public bool HealthKnown;

		public bool OneShot;

		public long Other => Math.Max(0L, Total - HitDamage);

		public double Dps => (Seconds > 0.0) ? ((double)Total / Seconds) : 0.0;

		public double AvgHit => (Hits > 0) ? ((double)HitDamage / (double)Hits) : 0.0;
	}

	private static readonly Vector4 Cyan = new Vector4(0.35f, 0.85f, 0.95f, 1f);

	private static readonly Vector4 Green = new Vector4(0.45f, 0.9f, 0.45f, 1f);

	private static readonly Vector4 Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f);

	private static readonly Vector4 Yellow = new Vector4(0.95f, 0.85f, 0.35f, 1f);

	private static readonly Vector4 Red = new Vector4(0.95f, 0.35f, 0.35f, 1f);

	private static readonly Regex HitRx = new Regex("^(?<crit>Critical hit!\\s*)?You \\w+ (?:the )?(?<mob>.+?) for (?<n>[\\d,]+) points? of", RegexOptions.IgnoreCase);

	private readonly Settings _s;

	private readonly CombatEngine _engine;

	public readonly List<Result> Results = new List<Result>();

	private int _target;

	private string _mob = "";

	private string _weapon = "";

	private DateTime _pressedAt;

	private DateTime _firstDamageAt = DateTime.MinValue;

	private DateTime _lastDamageAt;

	private int _maxHealth;

	private int _startHealth = -1;

	private int _lastHealth = -1;

	private int _lowest = -1;

	private long _hitDamage;

	private int _hits;

	private int _crits;

	private DateTime _nextId = DateTime.MinValue;

	public Action SaveAll;

	private bool _corrosionOff;

	private static readonly Regex OverkillRx = new Regex("\\[Overkill:\\s*(?<n>[\\d,]+)\\]", RegexOptions.IgnoreCase);

	private long _overkill;

	private bool _oneShot;

	public bool Running => _target != 0;

	public int TargetId => _target;

	public WeaponCompare(Settings s, CombatEngine engine)
	{
		_s = s;
		_engine = engine;
	}

	public void Start()
	{
		int num = 0;
		try
		{
			num = Globals.Core.Actions.CurrentSelection;
		}
		catch
		{
		}
		WorldObject worldObject = ((num != 0) ? Globals.Core.WorldFilter[num] : null);
		if (worldObject == null || worldObject.ObjectClass != ObjectClass.Monster)
		{
			Util.WriteToChat("Compare: select a monster first.");
			return;
		}
		if (!_s.CombatEnabled && _s.CmpCombatOnStart)
		{
			_s.CombatEnabled = true;
			Util.WriteToChat("Compare: combat ON for the test.");
		}
		else if (!_s.CombatEnabled)
		{
			Util.WriteToChat("Compare: combat is OFF - turn it on so the test attacks.");
		}
		_corrosionOff = false;
		_target = num;
		_mob = worldObject.Name;
		_weapon = WieldedWeapon();
		_pressedAt = DateTime.Now;
		_firstDamageAt = DateTime.MinValue;
		_lastDamageAt = DateTime.MinValue;
		_maxHealth = 0;
		_startHealth = (_lastHealth = (_lowest = -1));
		_hitDamage = 0L;
		_hits = (_crits = 0);
		_overkill = 0L;
		_oneShot = false;
		_nextId = DateTime.MinValue;
		if (_engine.FocusId != num)
		{
			_engine.SetFocus(num);
		}
		Util.WriteToChat("Compare: testing " + _weapon + " on " + _mob + ".");
	}

	public void Stop(string why)
	{
		if (_target != 0)
		{
			Finish(died: false);
			Util.WriteToChat("Compare: stopped (" + why + ").");
		}
	}

	private void CombatOff(string why)
	{
		if (_s.CombatEnabled)
		{
			_s.CombatEnabled = false;
			try
			{
				_engine.ReleaseNav();
			}
			catch
			{
			}
			Util.WriteToChat("Compare: combat OFF (" + why + ").");
		}
	}

	private void Finish(bool died)
	{
		if (_s.CmpCombatOffEnd || _corrosionOff)
		{
			CombatOff("test over");
		}
		bool flag = _maxHealth > 0 && _startHealth >= 0;
		long num;
		if (died & flag)
		{
			num = _startHealth + _overkill;
		}
		else
		{
			num = ((!flag || _lowest < 0) ? _hitDamage : (_startHealth - _lowest));
		}
		if (num < _hitDamage)
		{
			num = _hitDamage;
		}
		DateTime dateTime;
		if (died)
		{
			dateTime = DateTime.Now;
		}
		else
		{
			dateTime = ((_lastDamageAt != DateTime.MinValue) ? _lastDamageAt : DateTime.Now);
		}
		DateTime dateTime2 = ((_firstDamageAt != DateTime.MinValue && !_oneShot) ? _firstDamageAt : _pressedAt);
		Result result = new Result
		{
			Time = DateTime.Now.ToString("HH:mm"),
			Weapon = _weapon,
			Mob = _mob + (died ? "" : " (not dead)"),
			Seconds = Math.Max(0.1, (dateTime - dateTime2).TotalSeconds),
			Total = num,
			HitDamage = _hitDamage,
			Hits = _hits,
			Crits = _crits,
			HealthKnown = flag,
			Overkill = _overkill,
			OneShot = (_oneShot & died)
		};
		Results.Insert(0, result);
		if (Results.Count > 100)
		{
			Results.RemoveAt(Results.Count - 1);
		}
		if (died)
		{
			Util.WriteToChat("Compare: " + _weapon + " killed " + _mob + " in " + result.Seconds.ToString("0.0") + "s - " + result.Dps.ToString("0") + " dps" + ((result.Hits > 0) ? (", avg hit " + result.AvgHit.ToString("0")) : "") + ((result.Other > 0) ? (", other/DoT " + result.Other) : "") + ".");
		}
		if (_engine.FocusId == _target)
		{
			_engine.SetFocus(0);
		}
		_target = 0;
	}

	public void Tick()
	{
		if (_target == 0)
		{
			return;
		}
		if (Globals.Core.WorldFilter[_target] == null)
		{
			Finish(died: true);
			return;
		}
		if (_s.CmpCombatOffCorrosion && !_corrosionOff && _engine.Tracked.TryGetValue(_target, out var value) && value.Debuffs.ContainsKey(Slot.Corrosion))
		{
			_corrosionOff = true;
			CombatOff("Corrosion landed - the DoT finishes it");
		}
		if (!(DateTime.Now < _nextId))
		{
			_nextId = DateTime.Now.AddSeconds(1.0);
			try
			{
				Util.RequestId(_target);
			}
			catch
			{
			}
			if ((DateTime.Now - _pressedAt).TotalMinutes > 2.0 && _firstDamageAt == DateTime.MinValue)
			{
				Stop("no damage in 2 minutes");
			}
		}
	}

	public void OnReleased(int id)
	{
		if (_target != 0 && id == _target)
		{
			Finish(died: true);
		}
	}

	public void OnChat(string text)
	{
		if (_target == 0 || string.IsNullOrEmpty(text))
		{
			return;
		}
		Match match = OverkillRx.Match(text);
		if (match.Success && text.IndexOf(_mob, StringComparison.OrdinalIgnoreCase) >= 0)
		{
			if (long.TryParse(match.Groups["n"].Value.Replace(",", ""), NumberStyles.Integer, CultureInfo.InvariantCulture, out var result))
			{
				long num = ((_lastHealth >= 0) ? _lastHealth : ((_maxHealth > 0 && _firstDamageAt == DateTime.MinValue) ? _maxHealth : 0));
				_oneShot = _firstDamageAt == DateTime.MinValue;
				_overkill = result;
				_hitDamage += num + result;
				_hits++;
				Damaged();
				string text2 = WieldedWeapon();
				if (text2.Length > 0)
				{
					_weapon = text2;
				}
			}
			return;
		}
		Match match2 = HitRx.Match(text.Trim());
		if (match2.Success && string.Equals(match2.Groups["mob"].Value.Trim(), _mob, StringComparison.OrdinalIgnoreCase) && int.TryParse(match2.Groups["n"].Value.Replace(",", ""), NumberStyles.Integer, CultureInfo.InvariantCulture, out var result2))
		{
			_hitDamage += result2;
			_hits++;
			if (match2.Groups["crit"].Success)
			{
				_crits++;
			}
			Damaged();
			string text3 = WieldedWeapon();
			if (text3.Length > 0)
			{
				_weapon = text3;
			}
		}
	}

	private void Damaged()
	{
		if (_firstDamageAt == DateTime.MinValue)
		{
			_firstDamageAt = DateTime.Now;
		}
		_lastDamageAt = DateTime.Now;
	}

	public void OnServerMessage(Message msg)
	{
		if (_target == 0 || msg == null || msg.Type != 63408)
		{
			return;
		}
		int num;
		try
		{
			num = msg.Value<int>("event");
		}
		catch
		{
			return;
		}
		if (num != 201)
		{
			return;
		}
		int num2 = 0;
		try
		{
			num2 = msg.Value<int>("object");
		}
		catch
		{
		}
		if (num2 != _target)
		{
			return;
		}
		int cur = -1;
		int max = -1;
		Walk(msg, ref cur, ref max, 0);
		if (cur >= 0 && max > 0)
		{
			_maxHealth = max;
			if (_startHealth < 0)
			{
				_startHealth = cur;
			}
			if (_lastHealth >= 0 && cur < _lastHealth)
			{
				Damaged();
			}
			_lastHealth = cur;
			if (_lowest < 0 || cur < _lowest)
			{
				_lowest = cur;
			}
		}
	}

	public static bool ReadHealthAny(Message msg, out int obj, out int cur, out int max)
	{
		obj = 0;
		cur = -1;
		max = -1;
		if (msg == null || msg.Type != 63408)
		{
			return false;
		}
		int num;
		try
		{
			num = msg.Value<int>("event");
		}
		catch
		{
			return false;
		}
		if (num != 201)
		{
			return false;
		}
		try
		{
			obj = msg.Value<int>("object");
		}
		catch
		{
			return false;
		}
		Walk(msg, ref cur, ref max, 0);
		return obj != 0 && max > 0;
	}

	public static bool ReadHealth(Message msg, int target, out int cur, out int max)
	{
		cur = -1;
		max = -1;
		if (msg == null || msg.Type != 63408)
		{
			return false;
		}
		int num;
		try
		{
			num = msg.Value<int>("event");
		}
		catch
		{
			return false;
		}
		if (num != 201)
		{
			return false;
		}
		int num2 = 0;
		try
		{
			num2 = msg.Value<int>("object");
		}
		catch
		{
		}
		if (num2 != target)
		{
			return false;
		}
		Walk(msg, ref cur, ref max, 0);
		return cur >= 0 && max > 0;
	}

	private static void Walk(Message m, ref int cur, ref int max, int depth)
	{
		for (int i = 0; i < m.Count; i++)
		{
			object v = null;
			string n = null;
			try
			{
				v = m[i];
			}
			catch
			{
			}
			try
			{
				n = m.Name(i);
			}
			catch
			{
			}
			Visit(v, n, ref cur, ref max, depth);
		}
	}

	private static void Walk(MessageStruct s, ref int cur, ref int max, int depth)
	{
		if (s == null || depth > 6)
		{
			return;
		}
		for (int i = 0; i < s.Count; i++)
		{
			object v = null;
			string n = null;
			try
			{
				v = s[i];
			}
			catch
			{
			}
			try
			{
				n = s.Name(i);
			}
			catch
			{
			}
			Visit(v, n, ref cur, ref max, depth);
		}
	}

	private static void Visit(object v, string n, ref int cur, ref int max, int depth)
	{
		if (v is MessageStruct)
		{
			Walk((MessageStruct)v, ref cur, ref max, depth + 1);
		}
		else
		{
			if (n == null || n.IndexOf("health", StringComparison.OrdinalIgnoreCase) < 0)
			{
				return;
			}
			int num;
			if (v is int)
			{
				num = (int)v;
			}
			else
			{
				if (!(v is uint))
				{
					return;
				}
				num = (int)(uint)v;
			}
			if (n.IndexOf("max", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				max = num;
			}
			else
			{
				cur = num;
			}
		}
	}

	private static string WieldedWeapon()
	{
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if ((item.ObjectClass != ObjectClass.MeleeWeapon && item.ObjectClass != ObjectClass.MissileWeapon && item.ObjectClass != ObjectClass.WandStaffOrb) || ItemInfo.IsAmmo(item) || item.Values(LongValueKey.Wielder) != Globals.Core.CharacterFilter.Id)
				{
					continue;
				}
				return ItemReport.FullName(item);
			}
		}
		catch
		{
		}
		return "(nothing wielded)";
	}

	public void Draw()
	{
		if (!Running)
		{
			if (ImGui.Button("Test selected monster", new Vector2(180f, 0f)))
			{
				Start();
			}
			Tip("Select a monster, then click: it becomes the focus and is attacked the way its monster rule says\n(default attack, Corrosion when that's ticked...) until it dies. Combat has to be ON.\nHealth is read by appraising it every second; hits are read from chat.\nDismiss your pet first, or its damage counts as 'Other'.");
		}
		else
		{
			if (ImGui.Button("Stop test", new Vector2(180f, 0f)))
			{
				Stop("stopped by you");
			}
			ImGui.SameLine();
			string text = ((_maxHealth > 0 && _lastHealth >= 0) ? ("  health " + _lastHealth + "/" + _maxHealth) : "  (waiting for its health)");
			double num = ((_firstDamageAt == DateTime.MinValue) ? 0.0 : (DateTime.Now - _firstDamageAt).TotalSeconds);
			Im.TextColored(Yellow, "Testing " + _weapon + " on " + _mob + text + "  " + num.ToString("0.0") + "s  hits " + _hits + " (" + _hitDamage + ")");
		}
		ImGui.SameLine();
		if (ImGui.Button("Clear results"))
		{
			Results.Clear();
		}
		if (ImGui.CollapsingHeader("Options###cmpopts"))
		{
			ImGui.Indent(8f);
			bool flag = false;
			flag |= ImGui.Checkbox("Don't change weapons during a test", ref _s.CmpHoldWeapon);
			Tip("The weapon or wand in your hands when you click Test is used for the whole test,\nwhatever the monster's rule says.\n/mt set CmpHoldWeapon on|off");
			flag |= ImGui.Checkbox("Turn combat on when a test starts", ref _s.CmpCombatOnStart);
			Im.SetTooltipIfHovered("/mt set CmpCombatOnStart on|off");
			flag |= ImGui.Checkbox("Turn combat off when a test ends", ref _s.CmpCombatOffEnd);
			Im.SetTooltipIfHovered("/mt set CmpCombatOffEnd on|off");
			flag |= ImGui.Checkbox("Turn combat off once Corrosion is on the target", ref _s.CmpCombatOffCorrosion);
			Tip("As soon as your Corrosion lands on the test monster, combat goes off and the DoT finishes it -\nso the time and Other/DoT numbers are Corrosion alone. (Combat stays off afterwards.)\n/mt set CmpCombatOffCorrosion on|off");
			if (flag && SaveAll != null)
			{
				SaveAll();
			}
			ImGui.Unindent(8f);
		}
		try
		{
			_engine.Dots.Draw();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		DrawSummary();
		DrawResults();
	}

	private void DrawSummary()
	{
		Dictionary<string, List<Result>> dictionary = new Dictionary<string, List<Result>>();
		List<string> list = new List<string>();
		foreach (Result result in Results)
		{
			if (!result.Mob.EndsWith("(not dead)"))
			{
				string text = result.Weapon + "\u0001" + result.Mob;
				if (!dictionary.ContainsKey(text))
				{
					dictionary[text] = new List<Result>();
					list.Add(text);
				}
				dictionary[text].Add(result);
			}
		}
		Im.TextColored(Cyan, "Averages (kills only)");
		ImGuiTableFlags flags = ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit;
		if (!ImGui.BeginTable("cmpsum", 7, flags))
		{
			return;
		}
		ImGui.TableSetupColumn("Weapon", ImGuiTableColumnFlags.WidthStretch);
		ImGui.TableSetupColumn("Monster", ImGuiTableColumnFlags.WidthStretch);
		ImGui.TableSetupColumn("Kills", ImGuiTableColumnFlags.WidthFixed, 40f);
		ImGui.TableSetupColumn("Avg time", ImGuiTableColumnFlags.WidthFixed, 65f);
		ImGui.TableSetupColumn("Avg DPS", ImGuiTableColumnFlags.WidthFixed, 65f);
		ImGui.TableSetupColumn("Avg hit", ImGuiTableColumnFlags.WidthFixed, 60f);
		ImGui.TableSetupColumn("Avg other/DoT", ImGuiTableColumnFlags.WidthFixed, 95f);
		ImGui.TableHeadersRow();
		if (list.Count == 0)
		{
			ImGui.TableNextRow();
			ImGui.TableSetColumnIndex(0);
			Im.TextColored(Grey, "No kills tested yet.");
		}
		foreach (string item in list)
		{
			List<Result> list2 = dictionary[item];
			double num = 0.0;
			double num2 = 0.0;
			double num3 = 0.0;
			long num4 = 0L;
			int num5 = 0;
			foreach (Result item2 in list2)
			{
				num += item2.Seconds;
				num2 += item2.Dps;
				num3 += (double)item2.Other;
				num4 += item2.HitDamage;
				num5 += item2.Hits;
			}
			ImGui.TableNextRow();
			ImGui.TableSetColumnIndex(0);
			ImGui.TextUnformatted(list2[0].Weapon);
			ImGui.TableSetColumnIndex(1);
			ImGui.TextUnformatted(list2[0].Mob);
			ImGui.TableSetColumnIndex(2);
			ImGui.TextUnformatted(list2.Count.ToString());
			ImGui.TableSetColumnIndex(3);
			ImGui.TextUnformatted((num / (double)list2.Count).ToString("0.0") + "s");
			ImGui.TableSetColumnIndex(4);
			Im.TextColored(Green, (num2 / (double)list2.Count).ToString("0"));
			ImGui.TableSetColumnIndex(5);
			ImGui.TextUnformatted((num5 > 0) ? ((double)num4 / (double)num5).ToString("0") : "-");
			ImGui.TableSetColumnIndex(6);
			ImGui.TextUnformatted((num3 > 0.0) ? (num3 / (double)list2.Count).ToString("0") : "-");
		}
		ImGui.EndTable();
	}

	private void DrawResults()
	{
		ImGui.Spacing();
		Im.TextColored(Cyan, "Each test (newest first)");
		ImGuiTableFlags flags = ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY;
		if (!ImGui.BeginTable("cmpres", 9, flags, new Vector2(0f, 0f)))
		{
			return;
		}
		ImGui.TableSetupColumn("When", ImGuiTableColumnFlags.WidthFixed, 42f);
		ImGui.TableSetupColumn("Weapon", ImGuiTableColumnFlags.WidthStretch);
		ImGui.TableSetupColumn("Monster", ImGuiTableColumnFlags.WidthStretch);
		ImGui.TableSetupColumn("Time", ImGuiTableColumnFlags.WidthFixed, 50f);
		ImGui.TableSetupColumn("Damage", ImGuiTableColumnFlags.WidthFixed, 60f);
		ImGui.TableSetupColumn("DPS", ImGuiTableColumnFlags.WidthFixed, 50f);
		ImGui.TableSetupColumn("Hits (crits)", ImGuiTableColumnFlags.WidthFixed, 80f);
		ImGui.TableSetupColumn("Avg hit", ImGuiTableColumnFlags.WidthFixed, 55f);
		ImGui.TableSetupColumn("Other/DoT", ImGuiTableColumnFlags.WidthFixed, 70f);
		ImGui.TableSetupScrollFreeze(0, 1);
		ImGui.TableHeadersRow();
		foreach (Result result in Results)
		{
			ImGui.TableNextRow();
			ImGui.TableSetColumnIndex(0);
			Im.TextColored(Grey, result.Time);
			ImGui.TableSetColumnIndex(1);
			ImGui.TextUnformatted(result.Weapon);
			ImGui.TableSetColumnIndex(2);
			ImGui.TextUnformatted(result.Mob);
			ImGui.TableSetColumnIndex(3);
			ImGui.TextUnformatted(result.Seconds.ToString("0.0") + "s");
			ImGui.TableSetColumnIndex(4);
			Im.TextColored(result.HealthKnown ? Vector4.One : Yellow, result.Total.ToString());
			if (!result.HealthKnown)
			{
				Tip("Its health never came back from the appraisal - this is hit damage only.");
			}
			ImGui.TableSetColumnIndex(5);
			Im.TextColored(Green, result.Dps.ToString("0"));
			ImGui.TableSetColumnIndex(6);
			ImGui.TextUnformatted(result.Hits + ((result.Crits > 0) ? (" (" + result.Crits + ")") : "") + (result.OneShot ? " 1-shot" : ""));
			if (result.Overkill > 0)
			{
				Tip("Killing blow overkill: " + result.Overkill.ToString("N0") + (result.OneShot ? "\nKilled in one hit - the time is from clicking Test." : ""));
			}
			ImGui.TableSetColumnIndex(7);
			ImGui.TextUnformatted((result.Hits > 0) ? result.AvgHit.ToString("0") : "-");
			ImGui.TableSetColumnIndex(8);
			ImGui.TextUnformatted(result.HealthKnown ? result.Other.ToString() : "?");
		}
		ImGui.EndTable();
	}

	private static void Tip(string text)
	{
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip(text);
		}
	}
}
