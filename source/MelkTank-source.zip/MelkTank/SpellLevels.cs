using System;
using System.Collections.Generic;
using ACE.DatLoader;
using ACE.DatLoader.Entity;
using ACE.DatLoader.FileTypes;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using UtilityBelt.Service;

namespace MelkTank;

public static class SpellLevels
{
	private static Dictionary<int, List<int>> _family;

	private static DateTime _builtTry = DateTime.MinValue;

	private static readonly Dictionary<int, DateTime> _saidNone = new Dictionary<int, DateTime>();

	private static PortalDatDatabase Dat
	{
		get
		{
			try
			{
				return UBService.PortalDat;
			}
			catch
			{
				return null;
			}
		}
	}

	private static SpellBase Spell(int id)
	{
		PortalDatDatabase dat = Dat;
		SpellBase value;
		return (dat != null && dat.SpellTable != null && dat.SpellTable.Spells.TryGetValue((uint)id, out value)) ? value : null;
	}

	private static bool Build()
	{
		if (_family != null)
		{
			return true;
		}
		if ((DateTime.Now - _builtTry).TotalSeconds < 30.0)
		{
			return false;
		}
		_builtTry = DateTime.Now;
		PortalDatDatabase dat = Dat;
		if (dat == null || dat.SpellTable == null)
		{
			return false;
		}
		try
		{
			Dictionary<string, List<int>> dictionary = new Dictionary<string, List<int>>();
			foreach (KeyValuePair<uint, SpellBase> spell in dat.SpellTable.Spells)
			{
				SpellBase value = spell.Value;
				// (only spells a player casts - a formula with a scarab in it. What items and gems cast (Zongo's Fist...) shares
				// the category and can be "known" on a test character, but isn't a level of the spell)
				if (value != null && value.Category != 0 && PlayerCast(dat, value))
				{
					string key = value.Category + "|" + value.School + "|" + (value.Bitfield & 0x200C);
					if (!dictionary.TryGetValue(key, out var value2))
					{
						value2 = (dictionary[key] = new List<int>());
					}
					value2.Add((int)spell.Key);
				}
			}
			Dictionary<int, List<int>> dictionary2 = new Dictionary<int, List<int>>();
			foreach (List<int> value3 in dictionary.Values)
			{
				value3.Sort(delegate(int a, int b)
				{
					// (the longest lasting first, then the strongest: a spell's own levels last longer the higher they are, and the
					// odd ones sharing the category - quest and item spells - are short however strong)
					int c = Spell(b).Duration.CompareTo(Spell(a).Duration);
					return c != 0 ? c : Spell(b).Power.CompareTo(Spell(a).Power);
				});
				foreach (int item in value3)
				{
					dictionary2[item] = value3;
				}
			}
			_family = dictionary2;
			return true;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			return false;
		}
	}

	private static bool PlayerCast(PortalDatDatabase dat, SpellBase sb)
	{
		try
		{
			if (dat.SpellComponentsTable == null || sb.Formula == null) return true;
			foreach (uint c in sb.Formula)
			{
				if (dat.SpellComponentsTable.SpellComponents.TryGetValue(c, out var comp) && comp != null && (comp.Name ?? "").IndexOf("Scarab", StringComparison.OrdinalIgnoreCase) >= 0) return true;
			}
			return false;
		}
		catch { return true; }
	}

	public static List<int> Family(int id)
	{
		if (Build() && _family.TryGetValue(id, out var value))
		{
			return value;
		}
		return new List<int> { id };
	}

	public static bool Known(int id)
	{
		try
		{
			return CoreManager.Current.CharacterFilter.IsSpellKnown(id);
		}
		catch
		{
			return false;
		}
	}

	private static CharFilterSkillType SchoolSkill(SpellBase sb)
	{
		return (int)sb.School switch
		{
			1 => CharFilterSkillType.WarMagic, 
			2 => CharFilterSkillType.LifeMagic, 
			3 => CharFilterSkillType.ItemEnchantment, 
			4 => CharFilterSkillType.CreatureEnchantment, 
			_ => CharFilterSkillType.VoidMagic, 
		};
	}

	public static int Skill(int id)
	{
		SpellBase spellBase = Spell(id);
		if (spellBase == null)
		{
			return -1;
		}
		try
		{
			return CoreManager.Current.CharacterFilter.EffectiveSkill[SchoolSkill(spellBase)];
		}
		catch
		{
			return -1;
		}
	}

	public static int Difficulty(int id)
	{
		return ((int?)Spell(id)?.Power) ?? (-1);
	}

	public static bool SkillOk(int id)
	{
		int num = Difficulty(id);
		int num2 = Skill(id);
		if (num < 0 || num2 < 0)
		{
			return true;
		}
		return num2 >= num + (PluginCore.CurrentSettings?.SpellSkillMargin ?? 20);
	}

	public static bool CompsOk(int id, out string why)
	{
		why = null;
		Settings currentSettings = PluginCore.CurrentSettings;
		if (currentSettings != null && !currentSettings.CheckComponents)
		{
			return true;
		}
		PortalDatDatabase dat = Dat;
		if (dat == null || dat.SpellTable == null || dat.SpellComponentsTable == null)
		{
			return true;
		}
		try
		{
			string account = "";
			try
			{
				account = CoreManager.Current.CharacterFilter.AccountName ?? "";
			}
			catch
			{
			}
			List<uint> spellFormula = ACE.DatLoader.FileTypes.SpellTable.GetSpellFormula(dat.SpellTable, (uint)id, account);
			if (spellFormula == null || spellFormula.Count == 0)
			{
				return true;
			}
			Dictionary<string, long> dictionary = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase);
			foreach (WorldObject item in CoreManager.Current.WorldFilter.GetInventory())
			{
				if (item.ObjectClass == ObjectClass.SpellComponent || item.ObjectClass == ObjectClass.Foci)
				{
					string key = item.Name ?? "";
					dictionary.TryGetValue(key, out var value);
					dictionary[key] = value + Math.Max(1, item.Values(LongValueKey.StackCount, 1));
				}
			}
			SpellBase spellBase = Spell(id);
			bool flag = spellBase != null && HasFocus(dictionary, (int)spellBase.School);
			dictionary.TryGetValue("Prismatic Taper", out var value2);
			Dictionary<string, int> dictionary2 = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
			int num = 0;
			foreach (uint item2 in spellFormula)
			{
				if (dat.SpellComponentsTable.SpellComponents.TryGetValue(item2, out var value3) && value3 != null)
				{
					string text = value3.Name ?? "";
					if (text.IndexOf("Taper", StringComparison.OrdinalIgnoreCase) >= 0)
					{
						num++;
					}
					else if (!flag || text.IndexOf("Scarab", StringComparison.OrdinalIgnoreCase) >= 0)
					{
						dictionary2.TryGetValue(text, out var value4);
						dictionary2[text] = value4 + 1;
					}
				}
			}
			foreach (KeyValuePair<string, int> item3 in dictionary2)
			{
				dictionary.TryGetValue(item3.Key, out var value5);
				if (value5 < item3.Value)
				{
					why = "no " + item3.Key;
					return false;
				}
			}
			if (num > 0)
			{
				long num2 = 0L;
				foreach (KeyValuePair<string, long> item4 in dictionary)
				{
					if (item4.Key.IndexOf("Taper", StringComparison.OrdinalIgnoreCase) >= 0 && !item4.Key.StartsWith("Prismatic", StringComparison.OrdinalIgnoreCase))
					{
						num2 += item4.Value;
					}
				}
				if (value2 + num2 < num)
				{
					why = "not enough tapers";
					return false;
				}
			}
			return true;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			return true;
		}
	}

	private static bool HasFocus(Dictionary<string, long> have, int school)
	{
		return have.ContainsKey(school switch
		{
			4 => "Foci of Enchantment", 
			3 => "Foci of Artifice", 
			2 => "Foci of Verdancy", 
			1 => "Foci of Strife", 
			_ => "Foci of Shadow", 
		});
	}

	private static readonly Dictionary<int, DateTime> _refused = new Dictionary<int, DateTime>();

	/// <summary>The server wouldn't cast it for want of components (whatever the pack looked like): not tried again for 10 minutes.</summary>
	public static void Refused(int id) { _refused[id] = DateTime.Now; }

	public static bool IsRefused(int id)
	{
		return _refused.TryGetValue(id, out var at) && (DateTime.Now - at).TotalMinutes < 10.0;
	}

	public static bool Castable(int id, out string why)
	{
		why = null;
		if (IsRefused(id))
		{
			why = "the server says the components aren't there";
			return false;
		}
		if (!Known(id))
		{
			why = "not known";
			return false;
		}
		if (!SkillOk(id))
		{
			why = "skill " + Skill(id) + " < " + Difficulty(id) + " + margin";
			return false;
		}
		return CompsOk(id, out why);
	}

	public static int Best(int id)
	{
		List<int> list = Family(id);
		string why = null;
		string text = null;
		int num = 0;
		SpellBase asked = Spell(id);
		foreach (int item in list)
		{
			// (never a stronger spell than the one ticked: only it, or its lower levels)
			SpellBase sb = Spell(item);
			if (item != id && asked != null && sb != null && sb.Power > asked.Power)
			{
				continue;
			}
			if (Castable(item, out why))
			{
				return item;
			}
			if (text == null && why != "not known")
			{
				text = why;
			}
			if (Known(item) && !IsRefused(item))
			{
				num = item;
			}
		}
		if (num != 0 && text != null && (!_saidNone.TryGetValue(list[0], out var value) || (DateTime.Now - value).TotalMinutes > 10.0))
		{
			_saidNone[list[0]] = DateTime.Now;
			Util.WriteToChat("Spells: no level of " + Name(list[0]) + " is castable right now (" + text + ") - trying " + Name(num) + ".");
		}
		return num;
	}

	public static SpellLevel BestOf(SpellFamily fam)
	{
		SpellLevel result = null;
		SpellLevel spellLevel = null;
		SpellLevel[] levels = fam.Levels;
		foreach (SpellLevel spellLevel2 in levels)
		{
			if (spellLevel2 != null)
			{
				spellLevel = spellLevel2;
				break;
			}
		}
		string why;
		if (spellLevel != null && Build() && _family.ContainsKey(spellLevel.Id))
		{
			int num = 0;
			foreach (int item in Family(spellLevel.Id))
			{
				if (Castable(item, out why))
				{
					return AsLevel(fam, item);
				}
				if (Known(item) && !IsRefused(item))
				{
					num = item;
				}
			}
			return (num != 0) ? AsLevel(fam, num) : null;
		}
		for (int num2 = fam.Levels.Length - 1; num2 >= 0; num2--)
		{
			SpellLevel spellLevel3 = fam.Levels[num2];
			if (spellLevel3 != null)
			{
				if (Castable(spellLevel3.Id, out why))
				{
					return spellLevel3;
				}
				if (Known(spellLevel3.Id))
				{
					result = spellLevel3;
				}
			}
		}
		return result;
	}

	private static SpellLevel AsLevel(SpellFamily fam, int id)
	{
		SpellLevel[] levels = fam.Levels;
		foreach (SpellLevel spellLevel in levels)
		{
			if (spellLevel != null && spellLevel.Id == id)
			{
				return spellLevel;
			}
		}
		SpellBase spellBase = Spell(id);
		return new SpellLevel(id, Name(id), (spellBase != null && spellBase.Duration > 0.0) ? ((int)spellBase.Duration) : (-1));
	}

	public static string Name(int id)
	{
		SpellBase spellBase = Spell(id);
		return (spellBase != null && !string.IsNullOrEmpty(spellBase.Name)) ? spellBase.Name : ("spell " + id);
	}

	public static double FamilyRemaining(int id)
	{
		List<int> list = Family(id);
		if (list.Count <= 1)
		{
			return -2.0;
		}
		double num = -1.0;
		try
		{
			foreach (EnchantmentWrapper enchantment in CoreManager.Current.CharacterFilter.Enchantments)
			{
				if (list.Contains(enchantment.SpellId) && (double)enchantment.TimeRemaining > num)
				{
					num = enchantment.TimeRemaining;
				}
			}
		}
		catch
		{
		}
		return num;
	}
}
