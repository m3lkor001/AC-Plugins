using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Numerics;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
#if !RETAIL
using AcClient;
#endif
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Pets;

namespace MelkTank;

public static class PackOrganizer
{
	public enum Kind
	{
		NameContains,
		NameIs,
		ItemType,
		Charms,
		SortPack,
		Pets
	}

	public enum Pos
	{
		Anywhere,
		Top,
		Bottom
	}

	public class Rule
	{
		public bool On = true;

		public Kind Kind;

		public string Text = "";

		public string Pack = "";

		public Pos Pos;
	}

	public class Sub
	{
		public string Type = "Misc";

		public string Text = "";

		public string Name = "";

		public bool On = true;
	}

	private class Info
	{
		public string Name;

		public string Group;

		public string Sub;

		public string SubKey;

		public bool Pet;

		public bool Charm;

		public bool Nc;
	}

	private sealed class RefEq : IEqualityComparer<WorldObject>
	{
		public bool Equals(WorldObject a, WorldObject b)
		{
			return a == b;
		}

		public int GetHashCode(WorldObject o)
		{
			return RuntimeHelpers.GetHashCode(o);
		}
	}

	private sealed class Snap
	{
		public WorldObject O;

		public int Id;

		public string Name;

		public string Cls;

		public string Group;

		public string Sub;

		public string SubKey;

		public bool Pet;

		public bool Charm;

		public bool Nc;

		private long _v = long.MinValue;

		private long _b = long.MinValue;

		private long _n = long.MinValue;

		private long _s = long.MinValue;

		public int OrderIdx = int.MinValue;

		public bool OrderRest;

		public object OrderFor;

		public long Value
		{
			get
			{
				if (_v == long.MinValue)
				{
					_v = Val(O, LongValueKey.Value);
				}
				return _v;
			}
		}

		public long Burden
		{
			get
			{
				if (_b == long.MinValue)
				{
					_b = Val(O, LongValueKey.Burden);
				}
				return _b;
			}
		}

		public long Stack
		{
			get
			{
				if (_n == long.MinValue)
				{
					_n = Math.Max(1L, Val(O, LongValueKey.StackCount));
				}
				return _n;
			}
		}

		public long Slot
		{
			get
			{
				if (_s == long.MinValue)
				{
					_s = Slot(O);
				}
				return _s;
			}
		}
	}

	private class PackInfo
	{
		public int Id;

		public string Name;

		public int Cap;

		public readonly List<WorldObject> Items = new List<WorldObject>();
	}

	public const string MainPack = "Main pack";

	private static readonly string[] KindNames = new string[6] { "Name contains", "Name is", "Item type", "Charms (Charms tab)", "Sort pack", "Pets (summoning essences)" };

	private static readonly string[] PosNames = new string[3] { "anywhere", "at the top", "at the bottom" };

	private static readonly Vector4 Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f);

	private static readonly Vector4 Cyan = new Vector4(0.35f, 0.85f, 0.95f, 1f);

	private static readonly Vector4 Yellow = new Vector4(0.95f, 0.85f, 0.35f, 1f);

	public static readonly string[] SortModes = new string[6] { "type", "name", "value", "burden", "stack", "order" };

	public static readonly string[] SortLabels = new string[6] { "type (group)", "name", "value (high first)", "burden (heaviest first)", "stack size (biggest first)", "your type order" };

	public static readonly string[] ThenModes = new string[4] { "name", "namedesc", "value", "burden" };

	public static readonly string[] ThenLabels = new string[4] { "name (A-Z)", "name (Z-A)", "value (high first)", "burden (heaviest first)" };

	public static readonly string[] SubGroups = new string[8] { "Siphon Lenses", "Salvage", "Spell Components", "Keys", "Golem Hearts", "Aetheria & Mana", "Recall Gems", "Tools" };

	private static readonly string[] CompPotions = new string[12]
	{
		"Brimstone", "Cadmia", "Cinnabar", "Cobalt", "Colcothar", "Gypsum", "Quicksilver", "Realgar", "Stibnite", "Turpeth",
		"Verdigris", "Vitriol"
	};

	private static string _subsText;

	private static List<Sub> _subs = new List<Sub>();

	public static readonly string[] SubTypes = SubTypeList();

	private static HashSet<int> _petIds = new HashSet<int>();

	private static DateTime _petIdsAt = DateTime.MinValue;

	private static readonly Dictionary<int, Info> _info = new Dictionary<int, Info>();

	private static string _infoVer = null;

	private static string _charmsText = null;

	private static HashSet<int> _charmSet = new HashSet<int>();

	public const string NcPets = "Non-combat Pets";

	public const string Rest = "Everything else";

	private static readonly string[] PetNames = new string[1] { "Baby Yanga" };

	private static readonly Dictionary<WorldObject, Snap> _snaps = new Dictionary<WorldObject, Snap>(new RefEq());

	private static Settings _s;

	private static Action<string> _log = (string s) =>
	{
	};

	private static DateTime _next = DateTime.MinValue;

	private static DateTime _runUntil = DateTime.MinValue;

	private static readonly Dictionary<int, int> _tries = new Dictionary<int, int>();

	private static readonly Dictionary<int, DateTime> _skipUntil = new Dictionary<int, DateTime>();

	private static readonly Dictionary<int, KeyValuePair<int, int>> _askedMove = new Dictionary<int, KeyValuePair<int, int>>();

	private static int _lastMoveId;

	private static int _lastMoveCont;

	private static int _lastMoveSlot = -1;

	public static string Status = "";

	public static int Moves;

	private static readonly HashSet<int> _logged = new HashSet<int>();

	private static volatile bool _fullNeeded = true;

	private static readonly HashSet<int> _dirtyPacks = new HashSet<int>();

	private static List<PackInfo> _packCache;

	private static string _lastSig;

	private static DateTime _lastFull = DateTime.MinValue;

	private static readonly Dictionary<int, DateTime> _openedAt = new Dictionary<int, DateTime>();

	private static readonly Dictionary<int, DateTime> _readAt = new Dictionary<int, DateTime>();

	private static int _newKind;

	private static int _newPack;

	private static int _newPos;

	private static int _newType;

	private static int _newSort;

	private static int _newThen;

	private static int _orderPick;

	private static string _newOrder = "";

	private static string _newText = "";

	private static string[] _types;

	private static int _editRule = -1;

	private static int _editSub = -1;

	private static readonly Vector4 Green = new Vector4(0.55f, 0.88f, 0.55f, 1f);

	private static int _subType = 1;

	private static string _subText = "";

	private static string _subName = "";

	public static List<Sub> Subs
	{
		get
		{
			if (_s != null)
			{
				_s.RefreshSharedSubs();
			}
			string text = ((_s == null) ? "" : (_s.PackSubs ?? ""));
			if (text != _subsText)
			{
				_subsText = text;
				_subs = ParseSubs(text);
				_types = null;
			}
			return _subs;
		}
	}

	private static Dictionary<int, List<int>> Orders
	{
		get
		{
			Dictionary<int, List<int>> dictionary = AppDomain.CurrentDomain.GetData("MelkTank.PackOrder") as Dictionary<int, List<int>>;
			if (dictionary == null)
			{
				dictionary = new Dictionary<int, List<int>>();
				AppDomain.CurrentDomain.SetData("MelkTank.PackOrder", dictionary);
			}
			return dictionary;
		}
	}

	private static HashSet<int> FreshPacks
	{
		get
		{
			HashSet<int> hashSet = AppDomain.CurrentDomain.GetData("MelkTank.PackFresh") as HashSet<int>;
			if (hashSet == null)
			{
				hashSet = new HashSet<int>();
				AppDomain.CurrentDomain.SetData("MelkTank.PackFresh", hashSet);
			}
			return hashSet;
		}
	}

	private static string[] Types
	{
		get
		{
			List<Sub> subs = Subs;
			if (_types == null)
			{
				_types = TypeList();
			}
			return _types;
		}
	}

	public static List<Rule> Parse(string s)
	{
		List<Rule> list = new List<Rule>();
		string[] array = (s ?? "").Split(new char[1] { ';' }, StringSplitOptions.RemoveEmptyEntries);
		foreach (string text in array)
		{
			string[] array2 = text.Split('|');
			if (array2.Length >= 5)
			{
				int.TryParse(array2[1], out var result);
				int.TryParse(array2[4], out var result2);
				list.Add(new Rule
				{
					On = (array2[0] == "1"),
					Kind = (Kind)result,
					Text = Uri.UnescapeDataString(array2[2]),
					Pack = Uri.UnescapeDataString(array2[3]),
					Pos = (Pos)result2
				});
			}
		}
		return list;
	}

	public static string Join(List<Rule> l)
	{
		List<string> list = new List<string>();
		foreach (Rule item in l)
		{
			string[] array = new string[9]
			{
				item.On ? "1" : "0",
				"|",
				null,
				null,
				null,
				null,
				null,
				null,
				null
			};
			int kind = (int)item.Kind;
			array[2] = kind.ToString();
			array[3] = "|";
			array[4] = Uri.EscapeDataString(item.Text ?? "");
			array[5] = "|";
			array[6] = Uri.EscapeDataString(item.Pack ?? "");
			array[7] = "|";
			kind = (int)item.Pos;
			array[8] = kind.ToString();
			list.Add(string.Concat(array));
		}
		return string.Join(";", list.ToArray());
	}

	public static string Describe(Rule r)
	{
		string text = ((r.Pack.Length == 0) ? "?" : r.Pack);
		return r.Kind switch
		{
			Kind.NameContains => "\"" + r.Text + "\" in the name -> " + text + ", " + PosNames[(int)r.Pos], 
			Kind.NameIs => "named \"" + r.Text + "\" -> " + text + ", " + PosNames[(int)r.Pos], 
			Kind.ItemType => "every " + r.Text + " -> " + text + ", " + PosNames[(int)r.Pos], 
			Kind.Charms => "charms (Charms tab) -> " + text + ", " + PosNames[(int)r.Pos], 
			Kind.Pets => "pets (summoning essences) -> " + text + ", " + PosNames[(int)r.Pos], 
			Kind.SortPack => "keep " + text + " sorted by " + SortLabel(r.Text), 
			_ => "", 
		};
	}

	private static string BaseText(string text)
	{
		string text2 = text ?? "";
		int num = text2.IndexOf(";then=", StringComparison.OrdinalIgnoreCase);
		return (num < 0) ? text2 : text2.Substring(0, num);
	}

	public static string ThenMode(string text)
	{
		string text2 = text ?? "";
		int num = text2.IndexOf(";then=", StringComparison.OrdinalIgnoreCase);
		string text3 = ((num < 0) ? "name" : text2.Substring(num + 6).Trim().ToLowerInvariant());
		return (Array.IndexOf(ThenModes, text3) >= 0) ? text3 : "name";
	}

	public static string WithThen(string text, string then)
	{
		return (then == null || then == "name") ? text : (text + ";then=" + then);
	}

	public static string SortMode(string text)
	{
		text = BaseText(text);
		string text2 = (text ?? "").Trim().ToLowerInvariant();
		if (text2.StartsWith("order:"))
		{
			return "order";
		}
		return (Array.IndexOf(SortModes, text2) >= 0) ? text2 : "type";
	}

	public static List<string> SortOrder(string text)
	{
		List<string> list = new List<string>();
		string text2 = BaseText(text);
		if (!text2.StartsWith("order:", StringComparison.OrdinalIgnoreCase))
		{
			return list;
		}
		string[] array = text2.Substring(6).Split(',');
		foreach (string text3 in array)
		{
			if (text3.Trim().Length > 0)
			{
				list.Add(text3.Trim());
			}
		}
		return list;
	}

	public static string SortLabel(string text)
	{
		string text2 = SortMode(text);
		string text3 = ThenMode(text);
		string text4 = ((text3 == "name") ? "" : (", within each by " + ThenLabels[Array.IndexOf(ThenModes, text3)]));
		if (text2 == "order")
		{
			List<string> list = SortOrder(text);
			return ((list.Count == 0) ? "your type order (none set: type)" : (string.Join(", ", list.ToArray()) + (list.Exists((string x) => string.Equals(x, "Everything else", StringComparison.OrdinalIgnoreCase)) ? "" : ", then the rest"))) + text4;
		}
		if (text2 == "type" && text4.Length > 0)
		{
			return "type" + text4;
		}
		return SortLabels[Array.IndexOf(SortModes, text2)] + text4;
	}

	private static bool NameLike(string n, string pattern)
	{
		bool flag = false;
		bool flag2 = false;
		string[] array = (pattern ?? "").Split('|');
		foreach (string text in array)
		{
			string text2 = text.Trim();
			if (text2.Length == 0)
			{
				continue;
			}
			if (text2.StartsWith("-"))
			{
				if (text2.Length > 1 && OnePattern(n, text2.Substring(1).Trim()))
				{
					return false;
				}
				continue;
			}
			flag = true;
			if (flag2)
			{
				continue;
			}
			bool flag3 = true;
			string[] array2 = text2.Split('&');
			foreach (string text3 in array2)
			{
				string text4 = text3.Trim();
				if (text4.Length > 0 && !OnePattern(n, text4))
				{
					flag3 = false;
					break;
				}
			}
			if (flag3)
			{
				flag2 = true;
			}
		}
		return flag & flag2;
	}

	private static bool OnePattern(string n, string p)
	{
		if (p.Length == 0)
		{
			return false;
		}
		bool flag = p.Length > 2 && p.StartsWith("!") && p.EndsWith("!");
		if (flag)
		{
			p = p.Substring(1, p.Length - 2).Trim();
		}
		if (!flag && p.IndexOf('*') < 0)
		{
			return Has(n, p);
		}
		string text = Regex.Escape(p).Replace("\\*", flag ? "\\S+" : ".*");
		if (flag)
		{
			text = "^" + text + "$";
		}
		return Regex.IsMatch(n.Trim(), text, RegexOptions.IgnoreCase);
	}

	private static bool Has(string n, string x)
	{
		return n.IndexOf(x, StringComparison.OrdinalIgnoreCase) >= 0;
	}

	public static List<Sub> ParseSubs(string text)
	{
		List<Sub> list = new List<Sub>();
		string[] array = (text ?? "").Split(new char[1] { ';' }, StringSplitOptions.RemoveEmptyEntries);
		foreach (string text2 in array)
		{
			string[] array2 = text2.Split('|');
			if (array2.Length >= 3)
			{
				Sub sub = new Sub
				{
					Type = Uri.UnescapeDataString(array2[0]),
					Text = Uri.UnescapeDataString(array2[1]),
					Name = Uri.UnescapeDataString(array2[2]).Trim(),
					On = array2.Length < 4 || array2[3] != "0"
				};
				if (sub.Text.Length > 0 && sub.Name.Length > 0)
				{
					list.Add(sub);
				}
			}
		}
		return list;
	}

	public static string JoinSubs(List<Sub> l)
	{
		List<string> list = new List<string>();
		foreach (Sub item in l)
		{
			list.Add(Uri.EscapeDataString(item.Type ?? "") + "|" + Uri.EscapeDataString(item.Text ?? "") + "|" + Uri.EscapeDataString(item.Name ?? "") + (item.On ? "" : "|0"));
		}
		return string.Join(";", list.ToArray());
	}

	private static string[] SubTypeList()
	{
		List<string> list = new List<string> { "Any", "Misc", "Armor", "Clothing", "Jewelry", "Weapons" };
		string[] names = Enum.GetNames(typeof(ObjectClass));
		foreach (string text in names)
		{
			if (!list.Contains(text) && text != "NumObjectClasses")
			{
				list.Add(text);
			}
		}
		return list.ToArray();
	}

	private static bool IsSubName(string t)
	{
		if (Array.Exists(SubGroups, (string x) => string.Equals(x, t, StringComparison.OrdinalIgnoreCase)))
		{
			return true;
		}
		return Subs.Exists((Sub x) => string.Equals(x.Name, t, StringComparison.OrdinalIgnoreCase));
	}

	public static string SubGroup(WorldObject o)
	{
		if (o == null)
		{
			return "";
		}
		string n = o.Name ?? "";
		ObjectClass objectClass = o.ObjectClass;
		foreach (Sub sub in Subs)
		{
			if (!sub.On)
			{
				continue;
			}
			if ((string.Equals(sub.Type, "Any", StringComparison.OrdinalIgnoreCase) || string.Equals(sub.Type, Session.Category(objectClass), StringComparison.OrdinalIgnoreCase) || string.Equals(sub.Type, objectClass.ToString(), StringComparison.OrdinalIgnoreCase)) && NameLike(n, sub.Text))
			{
				return sub.Name;
			}
		}
		if (objectClass == ObjectClass.WandStaffOrb || objectClass == ObjectClass.MeleeWeapon || objectClass == ObjectClass.MissileWeapon || objectClass == ObjectClass.Armor || objectClass == ObjectClass.Clothing || objectClass == ObjectClass.Jewelry)
		{
			return "";
		}
		if (Has(n, "Siphon Lens") || n.Equals("Asheron's Lens", StringComparison.OrdinalIgnoreCase) || n.Equals("Resonant Lens", StringComparison.OrdinalIgnoreCase))
		{
			return "Siphon Lenses";
		}
		if (objectClass == ObjectClass.Salvage || n.StartsWith("Salvage", StringComparison.OrdinalIgnoreCase))
		{
			return "Salvage";
		}
		if (objectClass == ObjectClass.SpellComponent || n.StartsWith("Powdered ", StringComparison.OrdinalIgnoreCase) || Array.Exists(CompPotions, (string x) => n.Equals(x, StringComparison.OrdinalIgnoreCase)))
		{
			return "Spell Components";
		}
		if (objectClass == ObjectClass.Key || Has(n, "Keyring") || Has(n, "Key Ring") || Regex.IsMatch(n, "\\bKeys?\\b", RegexOptions.IgnoreCase))
		{
			return "Keys";
		}
		if (Has(n, "Golem Heart"))
		{
			return "Golem Hearts";
		}
		if (objectClass == ObjectClass.Ust || objectClass == ObjectClass.HealingKit || objectClass == ObjectClass.Lockpick || Regex.IsMatch(n, "\\b(Tools?|Kits?|Ust|Alembic|Mortar and Pestle|Knife|Pan|Pot|Hammer|Cutter|Grinder|Press|Crucible|Dropper|Pick Axe|Lockpick)\\b", RegexOptions.IgnoreCase))
		{
			return "Tools";
		}
		if (Has(n, "Aetheria") || Has(n, "Coalesced Mana") || Has(n, "Mana Charge"))
		{
			return "Aetheria & Mana";
		}
		if (Has(n, "Recall") || Has(n, "Portal Gem") || Has(n, "Sending Gem") || Has(n, "Lifestone Gem") || (objectClass == ObjectClass.Gem && (n.EndsWith(" Gem", StringComparison.OrdinalIgnoreCase) || Has(n, "Portal") || LV(o, 218103835) == 67108880)) || (objectClass == ObjectClass.Gem && PortsYou(o)))
		{
			return "Recall Gems";
		}
		return "";
	}

	// a gem whose spell takes you somewhere (a portal, recall or sending spell) - a server's own named ones ("Camp Ruggan")
	private static bool PortsYou(WorldObject o)
	{
		try
		{
			for (int i = 0; i < o.SpellCount; i++)
			{
				int sp = o.Spell(i);
				if (PortalSpellIds.All.Contains(sp)) return true;
				string nm = Loot.SpellNames.Name(sp) ?? "";
				if (Regex.IsMatch(nm, "\\b(Portal|Recall|Sending|Gateway|Teleport|Lifestone)\\b", RegexOptions.IgnoreCase)) return true;
			}
		}
		catch
		{
		}
		return false;
	}

	private static string SubKeyRaw(WorldObject o, string group, string g)
	{
		if (group == "Charms" || group == "Pets" || group == "Non-combat Pets")
		{
			return "";
		}
		if (g == "Spell Components")
		{
			string n = o.Name ?? "";
			string text = "0";
			if (Has(n, "Taper"))
			{
				text = "5";
			}
			else if (Has(n, "Talisman"))
			{
				text = "4";
			}
			else if (n.StartsWith("Powdered", StringComparison.OrdinalIgnoreCase))
			{
				text = "3";
			}
			else if (Array.Exists(CompPotions, (string x) => n.StartsWith(x, StringComparison.OrdinalIgnoreCase)))
			{
				text = "2";
			}
			else if (!Has(n, "Scarab") && !Has(n, "Prismatic"))
			{
				text = "1";
			}
			return g + " " + text;
		}
		return (g.Length > 0) ? g : o.ObjectClass.ToString();
	}

	private static Info Get(WorldObject o)
	{
		if ((DateTime.Now - _petIdsAt).TotalSeconds > 5.0)
		{
			_petIdsAt = DateTime.Now;
			HashSet<int> hashSet = new HashSet<int>();
			try
			{
				PetSummoner current = PetSummoner.Current;
				if (current != null)
				{
					foreach (PetRecord pet in current.Pets)
					{
						hashSet.Add(pet.DeviceId);
					}
				}
			}
			catch
			{
			}
			_petIds = hashSet;
		}
		string text = ((_s == null) ? "" : (_s.Charms ?? ""));
		if (text != _charmsText)
		{
			_charmsText = text;
			HashSet<int> hashSet2 = new HashSet<int>();
			string[] array = text.Split(new char[1] { '|' }, StringSplitOptions.RemoveEmptyEntries);
			foreach (string text2 in array)
			{
				if (int.TryParse(text2.Split(':')[0], out var result))
				{
					hashSet2.Add(result);
				}
			}
			_charmSet = hashSet2;
		}
		long num = 0L;
		foreach (int petId in _petIds)
		{
			num += petId;
		}
		string text3 = text + "\n" + ((_s == null) ? "" : (_s.PackSubs ?? "")) + "\n" + _petIds.Count + ":" + num;
		if (text3 != _infoVer)
		{
			_infoVer = text3;
			_info.Clear();
		}
		string text4 = ItemNames.Of(o);
		if (_info.TryGetValue(o.Id, out var value) && value.Name == text4)
		{
			return value;
		}
		value = new Info
		{
			Name = text4
		};
		value.Charm = _charmSet.Contains(o.Id);
		value.Pet = IsPetRaw(o);
		value.Nc = !value.Pet && IsNcPetRaw(o);
		ref string reference = ref value.Group;
		string text5;
		if (value.Charm)
		{
			text5 = "Charms";
		}
		else if (value.Pet)
		{
			text5 = "Pets";
		}
		else
		{
			text5 = (value.Nc ? "Non-combat Pets" : Session.Category(o.ObjectClass));
		}
		reference = text5;
		value.Sub = SubGroup(o);
		value.SubKey = SubKeyRaw(o, value.Group, value.Sub);
		_info[o.Id] = value;
		return value;
	}

	public static bool IsPet(WorldObject o)
	{
		return o != null && Get(o).Pet;
	}

	public static bool IsNcPet(WorldObject o)
	{
		return o != null && Get(o).Nc;
	}

	private static string SubOf(WorldObject o)
	{
		return Get(o).Sub;
	}

	private static string SubKey(WorldObject o)
	{
		return Get(o).SubKey;
	}

	private static bool IsPetRaw(WorldObject o)
	{
		if (o == null)
		{
			return false;
		}
		if (_petIds.Contains(o.Id))
		{
			return true;
		}
		if (Array.Exists(PetNames, (string x) => string.Equals(x, o.Name, StringComparison.OrdinalIgnoreCase)))
		{
			return true;
		}
		string text = Regex.Replace(o.Name ?? "", "\\s*\\(\\d[\\d,]*\\)\\s*$", "");
		if (!text.EndsWith(" Essence", StringComparison.OrdinalIgnoreCase) || text.StartsWith("Viridian", StringComparison.OrdinalIgnoreCase))
		{
			return false;
		}
		try
		{
			return o.Values(LongValueKey.UsesRemaining, -1) >= 0 || o.Values(LongValueKey.UsesTotal, -1) > 0;
		}
		catch
		{
			return true;
		}
	}

	public static bool IsCharm(WorldObject o)
	{
		return o != null && _s != null && Get(o).Charm;
	}

	public static string Group(WorldObject o)
	{
		return Get(o).Group;
	}

	private static long LV(WorldObject o, int key)
	{
		try
		{
			return o.Values((LongValueKey)key, 0);
		}
		catch
		{
			return 0L;
		}
	}

	private static bool IsNcPetRaw(WorldObject o)
	{
		if (o == null)
		{
			return false;
		}
		if (o.ObjectClass != ObjectClass.Misc)
		{
			return false;
		}
		return LV(o, 218103826) == 16 && LV(o, 218103831) == 16 && LV(o, 218103843) == 8;
	}

	private static long Val(WorldObject o, LongValueKey k)
	{
		try
		{
			return o.Values(k, 0);
		}
		catch
		{
			return 0L;
		}
	}

	private static Snap S(WorldObject o)
	{
		if (_snaps.TryGetValue(o, out var value))
		{
			return value;
		}
		Info info = Get(o);
		value = new Snap
		{
			O = o,
			Id = o.Id,
			Name = info.Name,
			Cls = o.ObjectClass.ToString(),
			Group = info.Group,
			Sub = info.Sub,
			SubKey = info.SubKey,
			Pet = info.Pet,
			Charm = info.Charm,
			Nc = info.Nc
		};
		_snaps[o] = value;
		return value;
	}

	private static Comparison<WorldObject> Sorter(string text)
	{
		string m = SortMode(text);
		List<string> order = SortOrder(text);
		string th = ((m == "name") ? "name" : ThenMode(text));
		object me = new object();
		int ie = order.FindIndex((string x) => string.Equals(x, "Everything else", StringComparison.OrdinalIgnoreCase));
		Func<Snap, int> place = (Snap x) =>
		{
			if (x.OrderFor == me)
			{
				return x.OrderIdx;
			}
			bool sp = x.Group == "Pets" || x.Group == "Charms" || x.Group == "Non-combat Pets";
			string u = (sp ? "" : x.Sub);
			int num = order.FindIndex((string y) => (u.Length > 0 && string.Equals(y, u, StringComparison.OrdinalIgnoreCase)) || (!sp && string.Equals(y, x.Cls, StringComparison.OrdinalIgnoreCase)) || string.Equals(y, x.Group, StringComparison.OrdinalIgnoreCase));
			x.OrderRest = num < 0;
			ref int orderIdx = ref x.OrderIdx;
			int num2 = ((num >= 0) ? num : ((ie >= 0) ? ie : int.MaxValue));
			orderIdx = num2;
			x.OrderFor = me;
			return x.OrderIdx;
		};
		return (WorldObject oa, WorldObject ob) =>
		{
			Snap snap = S(oa);
			Snap snap2 = S(ob);
			int num = 0;
			switch (m)
			{
			case "value":
				num = snap2.Value.CompareTo(snap.Value);
				break;
			case "burden":
				num = snap2.Burden.CompareTo(snap.Burden);
				break;
			case "stack":
				num = snap2.Stack.CompareTo(snap.Stack);
				break;
			case "order":
				if (order.Count > 0)
				{
					num = place(snap).CompareTo(place(snap2));
					if (num == 0 && snap.OrderRest != snap2.OrderRest)
					{
						num = (snap.OrderRest ? 1 : (-1));
					}
					if (num == 0 && snap.OrderRest)
					{
						num = string.Compare(snap.Group, snap2.Group, StringComparison.OrdinalIgnoreCase);
					}
					if (num == 0)
					{
						num = string.Compare(snap.SubKey, snap2.SubKey, StringComparison.OrdinalIgnoreCase);
					}
					break;
				}
				goto default;
			default:
				num = string.Compare(snap.Group, snap2.Group, StringComparison.OrdinalIgnoreCase);
				if (num == 0)
				{
					num = string.Compare(snap.SubKey, snap2.SubKey, StringComparison.OrdinalIgnoreCase);
				}
				break;
			case "name":
				break;
			}
			if (num == 0)
			{
				switch (th)
				{
				case "namedesc":
					num = string.Compare(snap2.Name, snap.Name, StringComparison.OrdinalIgnoreCase);
					break;
				case "value":
					num = snap2.Value.CompareTo(snap.Value);
					break;
				case "burden":
					num = snap2.Burden.CompareTo(snap.Burden);
					break;
				}
			}
			if (num == 0)
			{
				num = string.Compare(snap.Name, snap2.Name, StringComparison.OrdinalIgnoreCase);
			}
			// (alike in every way - three Nether Batons: by which they are, not where they sit - by place, each move
			// reordered them and they were shuffled round again and again)
			return (num != 0) ? num : snap.Id.CompareTo(snap2.Id);
		};
	}

	public static void Init(Settings s, Action<string> log)
	{
		_s = s;
		if (log != null)
		{
			_log = log;
		}
	}

	private static void ForgetUnread()
	{
		lock (Orders)
		{
			List<int> list = new List<int>();
			foreach (int key in Orders.Keys)
			{
				bool flag;
				lock (_readAt)
				{
					flag = _readAt.TryGetValue(key, out var value) && (DateTime.Now - value).TotalSeconds < 120.0;
				}
				if (!flag)
				{
					list.Add(key);
				}
			}
			foreach (int item in list)
			{
				Orders.Remove(item);
			}
		}
	}

	public static void ForgetOrders()
	{
		try
		{
			lock (Orders)
			{
				Orders.Clear();
			}
			lock (FreshPacks)
			{
				FreshPacks.Clear();
			}
			lock (_readAt)
			{
				_readAt.Clear();
			}
		}
		catch
		{
		}
	}

	public static void RunNow()
	{
		_runUntil = DateTime.Now.AddMinutes(2.0);
		_skipUntil.Clear();
		_tries.Clear();
		_openedAt.Clear();
		_logged.Clear();
		_fullNeeded = true;
		Status = "starting...";
	}

	private static int Slot(WorldObject o)
	{
		try
		{
			return o.Values(LongValueKey.Slot, 0);
		}
		catch
		{
			return 0;
		}
	}

	private static bool Worn(WorldObject o)
	{
		try
		{
			return o.Values(LongValueKey.EquippedSlots, 0) != 0 || o.Values(LongValueKey.Wielder, 0) != 0;
		}
		catch
		{
			return false;
		}
	}

	public static void Tick(bool canAct)
	{
		if (!_hookFailed)
		{
			try
			{
				HookTakenOff();
			}
			catch
			{
				_hookFailed = true;   // (a game older than this build: no hook to set)
			}
		}
		if (_s == null || (!_s.PackOrgOn && !(DateTime.Now < _runUntil)))
		{
			return;
		}
		DateTime now = DateTime.Now;
		if (now < _next)
		{
			return;
		}
		_next = now.AddMilliseconds(700.0);
		// (busy - casting, bending down: the server won't move anything about in the packs till that's done)
		if (ServerBusy())
		{
			return;
		}
		if (!canAct)
		{
			if (DateTime.Now < _runUntil)
			{
				Status = "waiting for a quiet moment...";
			}
			return;
		}
		try
		{
			if (Globals.Core.Actions.BusyState != 0)
			{
				return;
			}
		}
		catch
		{
		}
		if (_s.PackMerge && MergeStep())
		{
			return;
		}
		List<Rule> list = Parse(_s.PackRules);
		if (list.Count == 0)
		{
			Status = "no rules";
			return;
		}
		string text = _s.PackRules + "\n" + _s.PackSubs + "\n" + _s.Charms;
		bool flag = _packCache == null || _fullNeeded || text != _lastSig || (now - _lastFull).TotalMinutes >= 5.0;
		HashSet<int> hashSet = null;
		if (!flag)
		{
			lock (_dirtyPacks)
			{
				if (_dirtyPacks.Count == 0)
				{
					return;
				}
				hashSet = new HashSet<int>(_dirtyPacks);
				_dirtyPacks.Clear();
			}
		}
		else
		{
			lock (_dirtyPacks)
			{
				_dirtyPacks.Clear();
			}
			_fullNeeded = false;
			_lastSig = text;
			_lastFull = now;
		}
		Stopwatch stopwatch = Stopwatch.StartNew();
		try
		{
			Step(list, hashSet);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			Status = "error: " + ex.Message;
		}
		stopwatch.Stop();
		if (stopwatch.ElapsedMilliseconds >= 15)
		{
			_log("ORG   slow check: " + stopwatch.ElapsedMilliseconds + " ms, " + ((hashSet == null) ? "all packs" : (hashSet.Count + " pack(s)")) + " (" + Status + ")");
		}
		if (Status == "all in place" && _next < now.AddSeconds(5.0))
		{
			_next = now.AddSeconds(5.0);
		}
	}

	private static void Dirty(int pack)
	{
		lock (_dirtyPacks)
		{
			_dirtyPacks.Add(pack);
		}
	}

	public static void NewItemIn(int container)
	{
		if (container == 0)
		{
			return;
		}
		if (IsOurPack(container))
		{
			Dirty(container);
			return;
		}
		int num = 0;
		try
		{
			num = Globals.Core.CharacterFilter.Id;
		}
		catch
		{
		}
		if (container == num)
		{
			_fullNeeded = true;
		}
	}

	private static int PackOf(int item)
	{
		Dictionary<int, List<int>> orders = Orders;
		lock (orders)
		{
			foreach (KeyValuePair<int, List<int>> item2 in orders)
			{
				if (item2.Value.Contains(item))
				{
					return item2.Key;
				}
			}
		}
		return 0;
	}

	private static bool IsOurPack(int id)
	{
		List<PackInfo> packCache = _packCache;
		if (packCache == null)
		{
			return false;
		}
		foreach (PackInfo item in packCache)
		{
			if (item.Id == id)
			{
				return true;
			}
		}
		return false;
	}

	private static void Step(List<Rule> rules, HashSet<int> only)
	{
		_snaps.Clear();
		int id = Globals.Core.CharacterFilter.Id;
		List<PackInfo> packs;
		if (only == null || _packCache == null)
		{
			only = null;
			List<WorldObject> list = new List<WorldObject>();
			foreach (WorldObject item in InvCache.All())
			{
				list.Add(item);
			}
			packs = new List<PackInfo>
			{
				new PackInfo
				{
					Id = id,
					Name = "Main pack",
					Cap = 102
				}
			};
			foreach (KeyValuePair<WorldObject, string> item2 in SidePacks(list))
			{
				int num = 0;
				try
				{
					num = item2.Key.Values(LongValueKey.ItemSlots, 0);
				}
				catch
				{
				}
				packs.Add(new PackInfo
				{
					Id = item2.Key.Id,
					Name = item2.Value,
					Cap = ((num > 0) ? num : 24)
				});
			}
			Dictionary<int, PackInfo> dictionary = new Dictionary<int, PackInfo>();
			foreach (PackInfo item3 in packs)
			{
				dictionary[item3.Id] = item3;
			}
			foreach (WorldObject item4 in list)
			{
				if (dictionary.TryGetValue(item4.Container, out var value) && item4.ObjectClass != ObjectClass.Container && item4.ObjectClass != ObjectClass.Foci && (value.Id != id || !Worn(item4)))
				{
					value.Items.Add(item4);
				}
			}
			_packCache = packs;
		}
		else
		{
			packs = _packCache;
			foreach (PackInfo item5 in packs)
			{
				if (!only.Contains(item5.Id))
				{
					continue;
				}
				item5.Items.Clear();
				foreach (WorldObject item6 in Globals.Core.WorldFilter.GetByContainer(item5.Id))
				{
					if (item6.ObjectClass != ObjectClass.Container && item6.ObjectClass != ObjectClass.Foci && (item5.Id != id || !Worn(item6)))
					{
						item5.Items.Add(item6);
					}
				}
			}
		}
		foreach (PackInfo item7 in packs)
		{
			if (only == null || only.Contains(item7.Id))
			{
				OrderItems(item7.Id, item7.Items);
			}
		}
		HashSet<int> hashSet = new HashSet<int>();
		string[] array = (_s.Charms ?? "").Split(new char[1] { '|' }, StringSplitOptions.RemoveEmptyEntries);
		foreach (string text in array)
		{
			if (int.TryParse(text.Split(':')[0], out var result))
			{
				hashSet.Add(result);
			}
		}
		Dictionary<int, Rule> dictionary2 = new Dictionary<int, Rule>();
		Dictionary<int, PackInfo> dictionary3 = new Dictionary<int, PackInfo>();
		foreach (PackInfo item8 in packs)
		{
			if (only != null && !only.Contains(item8.Id))
			{
				continue;
			}
			foreach (WorldObject item9 in item8.Items)
			{
				foreach (Rule rule2 in rules)
				{
					if (!rule2.On || rule2.Kind == Kind.SortPack || !Matches(rule2, item9, hashSet))
					{
						continue;
					}
					PackInfo packInfo = FindPack(packs, rule2.Pack);
					if (packInfo != null)
					{
						dictionary2[item9.Id] = rule2;
						dictionary3[item9.Id] = packInfo;
					}
					break;
				}
			}
		}
		foreach (Rule rule3 in rules)
		{
			foreach (KeyValuePair<int, Rule> item10 in dictionary2)
			{
				if (item10.Value != rule3)
				{
					continue;
				}
				WorldObject worldObject = Globals.Core.WorldFilter[item10.Key];
				PackInfo packInfo2 = dictionary3[item10.Key];
				if (worldObject != null && worldObject.Container != packInfo2.Id && !Skipped(worldObject.Id))
				{
					if (packInfo2.Items.Count < packInfo2.Cap)
					{
						Move(worldObject, packInfo2, (rule3.Pos != Pos.Top) ? packInfo2.Items.Count : 0, "to " + packInfo2.Name + ((rule3.Pos == Pos.Anywhere) ? "" : (" (" + PosNames[(int)rule3.Pos] + ")")));
						return;
					}
					Status = packInfo2.Name + " is full - " + worldObject.Name + " stays where it is";
				}
			}
		}
		foreach (PackInfo p in packs)
		{
			if (only != null && !only.Contains(p.Id))
			{
				continue;
			}
			List<WorldObject> items = p.Items;
			Rule rule = rules.Find((Rule r) => r.On && r.Kind == Kind.SortPack && FindPack(packs, r.Pack) == p);
			if (rule == null)
			{
				continue;
			}
			if (NeedsFreshOrder(p.Id, id))
			{
				return;
			}
			List<WorldObject> list2 = new List<WorldObject>(items);
			list2.Sort(Sorter(rule.Text));
			Dictionary<int, int> dictionary4 = new Dictionary<int, int>();
			for (int num2 = 0; num2 < list2.Count; num2++)
			{
				dictionary4[list2[num2].Id] = num2;
			}
			List<WorldObject> items2 = p.Items;
			HashSet<int> keep = InOrder(items2, dictionary4);
			if (!_logged.Contains(p.Id))
			{
				_logged.Add(p.Id);
				_log("ORG   " + p.Name + " now: " + string.Join(", ", p.Items.ConvertAll((WorldObject x) => ItemNames.Of(x) + (keep.Contains(x.Id) ? "" : "*")).ToArray()));
				_log("ORG   " + p.Name + " wanted: " + string.Join(", ", list2.ConvertAll((WorldObject x) => ItemNames.Of(x)).ToArray()));
			}
			foreach (WorldObject item11 in list2)
			{
				if (keep.Contains(item11.Id) || Skipped(item11.Id))
				{
					continue;
				}
				int num3 = dictionary4[item11.Id];
				int num4 = -1;
				for (int num5 = num3 - 1; num5 >= 0; num5--)
				{
					if (keep.Contains(list2[num5].Id))
					{
						num4 = p.Items.IndexOf(list2[num5]);
						break;
					}
				}
				int num6 = p.Items.IndexOf(item11);
				int num7 = ((num4 >= 0) ? ((num6 < num4) ? num4 : (num4 + 1)) : 0);
				if (num7 == num6)
				{
					keep.Add(item11.Id);
					continue;
				}
				Move(item11, p, num7, "sorting " + p.Name);
				return;
			}
		}
		Status = "all in place";
		if (DateTime.Now < _runUntil)
		{
			_runUntil = DateTime.MinValue;
			Util.WriteToChat("Organize: everything is where the list says (" + Moves + " move" + ((Moves == 1) ? "" : "s") + ").");
			Moves = 0;
		}
	}

	private static HashSet<int> InOrder(List<WorldObject> cur, Dictionary<int, int> rank)
	{
		int count = cur.Count;
		int[] array = new int[count];
		int[] array2 = new int[count];
		int[] array3 = new int[count];
		int num = 0;
		for (int i = 0; i < count; i++)
		{
			int num2 = rank[cur[i].Id];
			int num3 = 0;
			int num4 = num;
			while (num3 < num4)
			{
				int num5 = (num3 + num4) / 2;
				if (array[num5] < num2)
				{
					num3 = num5 + 1;
				}
				else
				{
					num4 = num5;
				}
			}
			array[num3] = num2;
			array2[num3] = i;
			array3[i] = ((num3 > 0) ? array2[num3 - 1] : (-1));
			if (num3 == num)
			{
				num++;
			}
		}
		HashSet<int> hashSet = new HashSet<int>();
		for (int num6 = ((num > 0) ? array2[num - 1] : (-1)); num6 >= 0; num6 = array3[num6])
		{
			hashSet.Add(cur[num6].Id);
		}
		return hashSet;
	}

	private static PackInfo FindPack(List<PackInfo> packs, string name)
	{
		if (string.IsNullOrEmpty(name))
		{
			return null;
		}
		foreach (PackInfo pack in packs)
		{
			if (string.Equals(pack.Name, name, StringComparison.OrdinalIgnoreCase))
			{
				return pack;
			}
		}
		return null;
	}

	private static bool Matches(Rule r, WorldObject wo, HashSet<int> charms)
	{
		Snap snap = S(wo);
		string text = snap.Name ?? "";
		switch (r.Kind)
		{
		case Kind.NameContains:
			return r.Text.Length > 0 && ItemNames.Contains(wo, r.Text);
		case Kind.NameIs:
			return ItemNames.Is(wo, r.Text);
		case Kind.ItemType:
			if (string.Equals(r.Text, "Charms", StringComparison.OrdinalIgnoreCase))
			{
				return snap.Charm;
			}
			if (string.Equals(r.Text, "Everything else", StringComparison.OrdinalIgnoreCase))
			{
				return true;
			}
			if (string.Equals(r.Text, "Pets", StringComparison.OrdinalIgnoreCase))
			{
				return snap.Pet;
			}
			if (string.Equals(r.Text, "Non-combat Pets", StringComparison.OrdinalIgnoreCase))
			{
				return !snap.Charm && snap.Nc;
			}
			if (IsSubName(r.Text))
			{
				return !snap.Charm && !snap.Pet && string.Equals(snap.Sub, r.Text, StringComparison.OrdinalIgnoreCase);
			}
			if (Array.IndexOf(new string[5] { "Armor", "Clothing", "Jewelry", "Weapons", "Misc" }, r.Text) >= 0 && !string.Equals(snap.Cls, r.Text, StringComparison.OrdinalIgnoreCase))
			{
				return string.Equals(snap.Group, r.Text, StringComparison.OrdinalIgnoreCase);
			}
			return string.Equals(snap.Cls, r.Text, StringComparison.OrdinalIgnoreCase);
		case Kind.Charms:
			return charms.Contains(snap.Id);
		case Kind.Pets:
			return snap.Pet;
		default:
			return false;
		}
	}

	private static bool MergeStep()
	{
		Dictionary<string, List<WorldObject>> dictionary = new Dictionary<string, List<WorldObject>>();
		foreach (WorldObject item in InvCache.All())
		{
			long num = Val(item, LongValueKey.StackMax);
			long num2 = Val(item, LongValueKey.StackCount);
			if (num > 1 && num2 > 0 && num2 < num && !Worn(item) && !Skipped(item.Id))
			{
				string key = item.Name + "|" + Val(item, LongValueKey.Type) + "|" + num;
				if (!dictionary.TryGetValue(key, out var value))
				{
					value = (dictionary[key] = new List<WorldObject>());
				}
				value.Add(item);
			}
		}
		foreach (List<WorldObject> value3 in dictionary.Values)
		{
			if (value3.Count < 2)
			{
				continue;
			}
			value3.Sort((WorldObject a, WorldObject b) => Val(a, LongValueKey.StackCount).CompareTo(Val(b, LongValueKey.StackCount)));
			WorldObject worldObject = value3[0];
			WorldObject worldObject2 = value3[value3.Count - 1];
			long val = Val(worldObject2, LongValueKey.StackMax) - Val(worldObject2, LongValueKey.StackCount);
			long val2 = Val(worldObject, LongValueKey.StackCount);
			int num3 = (int)Math.Min(val, val2);
			if (num3 <= 0)
			{
				continue;
			}
			if (worldObject.Id == _lastMoveId && worldObject2.Id == _lastMoveCont)
			{
				_tries.TryGetValue(worldObject.Id, out var value2);
				value2 = (_tries[worldObject.Id] = value2 + 1);
				if (value2 >= 3)
				{
					_skipUntil[worldObject.Id] = DateTime.Now.AddMinutes(10.0);
					_tries.Remove(worldObject.Id);
					_log("ORG   " + worldObject.Name + " won't merge - left for 10 min");
					continue;
				}
			}
			_lastMoveId = worldObject.Id;
			_lastMoveCont = worldObject2.Id;
			_lastMoveSlot = -1;
			Status = "merging " + worldObject.Name + " (" + num3 + " onto a stack of " + Val(worldObject2, LongValueKey.StackCount) + ")";
			_log("ORG   merge " + worldObject.Name + " x" + num3 + " -> stack of " + Val(worldObject2, LongValueKey.StackCount));
			Moves++;
			_next = DateTime.Now.AddMilliseconds(900.0);
			int num5 = PackOf(worldObject.Id);
			int num6 = PackOf(worldObject2.Id);
			try
			{
				CM_Inventory.Event_StackableMerge((uint)worldObject.Id, (uint)worldObject2.Id, num3);
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
				_skipUntil[worldObject.Id] = DateTime.Now.AddMinutes(10.0);
				return false;
			}
			if (num5 != 0)
			{
				Dirty(num5);
			}
			if (num6 != 0)
			{
				Dirty(num6);
			}
			_fullNeeded = true;
			InvCache.Invalidate();
			return true;
		}
		return false;
	}

	private static bool Skipped(int id)
	{
		DateTime value;
		return _skipUntil.TryGetValue(id, out value) && DateTime.Now < value;
	}

	private static DateTime _serverBusyAt = DateTime.MinValue, _castBusyAt = DateTime.MinValue;

	/// <summary>
	/// Too busy for the server to take a move about in the packs: casting (and a moment after, while the hands come back -
	/// the server's spell "recoil"), or bending down to pick something up. Melee and missile attacks don't stop it: the
	/// server only refuses a move during a pickup or a spell's recoil - so the organizer works between them in a fight.
	/// </summary>
	// something taken off (a slayer wand swapped out, say): straight to where the rules want it, rather than the front of the
	// main pack and moved there after - only while organizing is on
	private static bool _hookFailed;

#if RETAIL
	// (the retail client has no hook for where a taken-off item lands: the organizer moves it after, as before)
	private static void HookTakenOff()
	{
	}

	internal static void UnhookTakenOff()
	{
	}

#else
	private static Func<ACGodot.Combat.Item, (uint pack, int slot)?> _takenOffHook;


	private static void HookTakenOff()
	{
		var net = ACGodot.DecalShim.Bridge.Host?.Net;
		if (net == null)
		{
			return;
		}
		if (_takenOffHook == null)
		{
			_takenOffHook = TakenOffPlace;
		}
		if (net.PlaceTakenOff != _takenOffHook)
		{
			net.PlaceTakenOff = _takenOffHook;
		}
	}

	internal static void UnhookTakenOff()
	{
		try
		{
			var net = ACGodot.DecalShim.Bridge.Host?.Net;
			if (net != null && _takenOffHook != null && net.PlaceTakenOff == _takenOffHook)
			{
				net.PlaceTakenOff = null;
			}
		}
		catch
		{
		}
	}

	private static (uint pack, int slot)? TakenOffPlace(ACGodot.Combat.Item it)
	{
		try
		{
			if (!PlaceFor(ACGodot.DecalShim.Bridge.IdOf(it), out int container, out int slot))
			{
				return null;
			}
			if (container == Globals.Core.CharacterFilter.Id)
			{
				return (0u, slot);
			}
			if (ACGodot.DecalShim.Bridge.ThingOf(container) is ACGodot.Combat.Item pack && pack.Guid != 0)
			{
				return (pack.Guid, slot);
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		return null;
	}

#endif
	/// <summary>Where this item belongs by the rules (its pack, and the place in it next to what it sorts after); false when
	/// organizing is off or nothing says.</summary>
	internal static bool PlaceFor(int itemId, out int container, out int slot)
	{
		container = 0;
		slot = 0;
		if (_s == null || !_s.PackOrgOn || _packCache == null)
		{
			return false;
		}
		WorldObject wo = Globals.Core.WorldFilter[itemId];
		if (wo == null)
		{
			return false;
		}
		List<Rule> rules = Parse(_s.PackRules);
		if (rules.Count == 0)
		{
			return false;
		}
		int me = Globals.Core.CharacterFilter.Id;
		HashSet<int> charms = new HashSet<int>();
		foreach (string text in (_s.Charms ?? "").Split(new char[1] { '|' }, StringSplitOptions.RemoveEmptyEntries))
		{
			if (int.TryParse(text.Split(':')[0], out var c))
			{
				charms.Add(c);
			}
		}
		List<PackInfo> packs = _packCache;
		PackInfo target = packs.Find((PackInfo p) => p.Id == me);
		Rule move = null;
		foreach (Rule r in rules)
		{
			if (!r.On || r.Kind == Kind.SortPack || !Matches(r, wo, charms))
			{
				continue;
			}
			PackInfo pi = FindPack(packs, r.Pack);
			if (pi != null)
			{
				target = pi;
				move = r;
			}
			break;
		}
		if (target == null)
		{
			return false;
		}
		// what's in that pack now, in the order it's in
		List<WorldObject> cur = new List<WorldObject>();
		lock (Orders)
		{
			if (Orders.TryGetValue(target.Id, out var order))
			{
				foreach (int id in order)
				{
					if (id != itemId && Globals.Core.WorldFilter[id] is WorldObject o)
					{
						cur.Add(o);
					}
				}
			}
		}
		if (cur.Count >= target.Cap)
		{
			return false;
		}
		Rule sort = rules.Find((Rule r) => r.On && r.Kind == Kind.SortPack && FindPack(packs, r.Pack) == target);
		if (sort == null)
		{
			if (move == null)
			{
				return false;
			}
			container = target.Id;
			slot = (move.Pos == Pos.Top) ? 0 : cur.Count;
			return true;
		}
		List<WorldObject> all = new List<WorldObject>(cur) { wo };
		all.Sort(Sorter(sort.Text));
		int k = all.IndexOf(wo);
		container = target.Id;
		slot = (k <= 0) ? 0 : (cur.IndexOf(all[k - 1]) + 1);
		_log("ORG   " + ItemNames.Of(wo) + " taken off: straight to " + target.Name + " (slot " + slot + ")");
		return true;
	}

	internal static bool ServerBusy()
	{
#if RETAIL
		return false;
#else
		try
		{
			var h = ACGodot.DecalShim.Bridge.Host;
			if (h == null) return false;
			if (h.Magic?.Casting == true || h.Player?.Bending == true) { _castBusyAt = DateTime.UtcNow; return true; }
			return (DateTime.UtcNow - _castBusyAt).TotalSeconds < 1.0;
		}
		catch { return false; }
#endif
	}

	/// <summary>What the character was doing when the server said it was too busy (for the log).</summary>
	private static string BusyWhat()
	{
#if RETAIL
		return "?";
#else
		try
		{
			var h = ACGodot.DecalShim.Bridge.Host;
			if (h == null) return "?";
			var bits = new System.Collections.Generic.List<string>();
			if (h.Magic?.Casting == true) bits.Add("casting");
			if (h.Combat?.InAttack == true) bits.Add("attacking");
			if (h.Player?.Bending == true) bits.Add("picking up");
			return bits.Count == 0 ? "nothing the client knew of" : string.Join(", ", bits);
		}
		catch { return "?"; }
#endif
	}

	private static void Move(WorldObject o, PackInfo to, int slot, string why)
	{
		// (the same move of this item asked before - whatever else was moved in between: two things each wanting one
		// place took turns for ever when the server refused both)
		bool again = (o.Id == _lastMoveId && to.Id == _lastMoveCont && slot == _lastMoveSlot)
			|| (_askedMove.TryGetValue(o.Id, out var before) && before.Key == to.Id && before.Value == slot);
		_askedMove[o.Id] = new KeyValuePair<int, int>(to.Id, slot);
		if (again)
		{
			_tries.TryGetValue(o.Id, out var value);
			value = (_tries[o.Id] = value + 1);
			if (value >= 3)
			{
				_skipUntil[o.Id] = DateTime.Now.AddMinutes(10.0);
				_tries.Remove(o.Id);
				_log("ORG   " + o.Name + " won't move " + why + " - left for 10 min");
				return;
			}
		}
		else
		{
			_tries.Remove(o.Id);
		}
		_lastMoveId = o.Id;
		_lastMoveCont = to.Id;
		_lastMoveSlot = slot;
		Status = "moving " + o.Name + " " + why;
		_log("ORG   " + o.Name + " " + why + " (slot " + slot + ")");
		Moves++;
		_next = DateTime.Now.AddMilliseconds(900.0);
		int num2 = PackOf(o.Id);
		try
		{
			Globals.Core.Actions.MoveItem(o.Id, to.Id, slot, stack: true);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			_skipUntil[o.Id] = DateTime.Now.AddMinutes(10.0);
			return;
		}
		Placed(o.Id, to.Id, slot);
		InvCache.Invalidate();
		Dirty(to.Id);
		if (num2 != 0)
		{
			Dirty(num2);
		}
	}

	private static void OrderItems(int pack, List<WorldObject> items)
	{
		Dictionary<int, List<int>> orders = Orders;
		lock (orders)
		{
			if (!orders.TryGetValue(pack, out var value))
			{
				List<WorldObject> list = new List<WorldObject>(items);
				list.Sort((WorldObject a, WorldObject b) => Slot(a).CompareTo(Slot(b)));
				value = (orders[pack] = list.ConvertAll((WorldObject o) => o.Id));
			}
			HashSet<int> here = new HashSet<int>();
			foreach (WorldObject item in items)
			{
				here.Add(item.Id);
			}
			value.RemoveAll((int id) => !here.Contains(id));
			bool flag = false;
			foreach (WorldObject item2 in items)
			{
				if (!value.Contains(item2.Id))
				{
					value.Insert(Math.Max(0, Math.Min(value.Count, Slot(item2))), item2.Id);
					flag = true;
				}
			}
			if (flag)
			{
				lock (FreshPacks)
				{
					FreshPacks.Remove(pack);
				}
			}
			Dictionary<int, int> at = new Dictionary<int, int>();
			for (int num = 0; num < value.Count; num++)
			{
				at[value[num]] = num;
			}
			items.Sort((WorldObject a, WorldObject b) => at[a.Id].CompareTo(at[b.Id]));
		}
	}

	private static void Placed(int item, int container, int slot)
	{
		Dictionary<int, List<int>> orders = Orders;
		lock (orders)
		{
			foreach (List<int> value2 in orders.Values)
			{
				value2.Remove(item);
			}
			if (orders.TryGetValue(container, out var value))
			{
				value.Insert(Math.Max(0, Math.Min(value.Count, slot)), item);
			}
		}
	}

	public static void OnServerMessage(int type, byte[] raw)
	{
		if (type != 63408 || raw == null || raw.Length < 16)
		{
			return;
		}
		int num = ((BitConverter.ToUInt32(raw, 0) == 63408) ? 4 : 0);
		if (raw.Length < num + 12)
		{
			return;
		}
		uint num2 = BitConverter.ToUInt32(raw, num + 8);
		int num3 = num + 12;
		// the server too busy for a move (WeenieError "you're too busy", then the move refused): logged, and the move
		// tried again in a moment - not counted as one that won't go
		if (num2 == 650 && raw.Length >= num3 + 4 && BitConverter.ToUInt32(raw, num3) == 0x1D)
		{
			_serverBusyAt = DateTime.Now;
			return;
		}
		if (num2 == 160 && raw.Length >= num3 + 4)
		{
			int item = (int)BitConverter.ToUInt32(raw, num3);
			uint why = raw.Length >= num3 + 8 ? BitConverter.ToUInt32(raw, num3 + 4) : 0;
			bool busy = why == 0x1D || (DateTime.Now - _serverBusyAt).TotalSeconds < 3.0;
			if (item != 0 && item == _lastMoveId)
			{
				string name = "item " + item;
				try { name = ItemNames.Of(Globals.Core.WorldFilter[item]); } catch { }
				if (busy)
				{
					_log("ORG   the server was busy (" + BusyWhat() + ") - " + name + " not moved, trying again shortly");
					_tries.Remove(item);
					_askedMove.Remove(item);
					_lastMoveId = 0;
					_next = DateTime.Now.AddSeconds(1.5);
				}
				else
				{
					_log("ORG   the server refused to move " + name + (why != 0 ? " (reason " + why.ToString("X") + ")" : ""));
				}
				Dirty(PackOf(item));
				InvCache.Invalidate();
			}
			return;
		}
		if (num2 == 34 || num2 == 35 || num2 == 36 || num2 == 410 || num2 == 406)
		{
			InvCache.Invalidate();
		}
		if (num2 == 36 && raw.Length >= num3 + 4)
		{
			int num4 = PackOf((int)BitConverter.ToUInt32(raw, num3));
			if (num4 != 0)
			{
				Dirty(num4);
			}
		}
		if (num2 == 406 && raw.Length >= num3 + 8)
		{
			int num5 = (int)BitConverter.ToUInt32(raw, num3);
			if (!IsOurPack(num5))
			{
				return;
			}
			Dirty(num5);
			int num6 = (int)BitConverter.ToUInt32(raw, num3 + 4);
			List<int> list = new List<int>();
			for (int i = 0; i < num6 && num3 + 8 + i * 8 + 8 <= raw.Length; i++)
			{
				int item = (int)BitConverter.ToUInt32(raw, num3 + 8 + i * 8);
				if (BitConverter.ToUInt32(raw, num3 + 12 + i * 8) == 0)
				{
					list.Add(item);
				}
			}
			Dictionary<int, List<int>> orders = Orders;
			lock (orders)
			{
				orders[num5] = list;
			}
			lock (FreshPacks)
			{
				FreshPacks.Add(num5);
			}
			lock (_readAt)
			{
				_readAt[num5] = DateTime.Now;
			}
			try
			{
				_log("ORG   contents list for " + num5 + ": " + list.Count + " items");
				return;
			}
			catch
			{
				return;
			}
		}
		if (num2 != 34 || raw.Length < num3 + 16)
		{
			return;
		}
		int item2 = (int)BitConverter.ToUInt32(raw, num3);
		int num7 = (int)BitConverter.ToUInt32(raw, num3 + 4);
		int slot = (int)BitConverter.ToUInt32(raw, num3 + 8);
		uint num8 = BitConverter.ToUInt32(raw, num3 + 12);
		int num9 = PackOf(item2);
		if (IsOurPack(num7) || num9 != 0)
		{
			if (num8 != 0)
			{
				_fullNeeded = true;
			}
			if (IsOurPack(num7))
			{
				Dirty(num7);
			}
			if (num9 != 0)
			{
				Dirty(num9);
			}
		}
		if (num8 == 0)
		{
			Placed(item2, num7, slot);
		}
	}

	private static bool NeedsFreshOrder(int pack, int me)
	{
		return false;
	}

	private static bool NeedsFreshOrderByOpening(int pack, int me)
	{
		if (pack == me)
		{
			return false;
		}
		lock (FreshPacks)
		{
			if (FreshPacks.Contains(pack))
			{
				return false;
			}
		}
		if (_openedAt.TryGetValue(pack, out var value) && (DateTime.Now - value).TotalSeconds < 20.0)
		{
			return (DateTime.Now - value).TotalSeconds < 3.0;
		}
		_openedAt[pack] = DateTime.Now;
		try
		{
			Globals.Core.Actions.UseItem(pack, 0);
		}
		catch
		{
		}
		Status = "opening the pack to read its order...";
		_next = DateTime.Now.AddSeconds(1.5);
		return true;
	}

	public static string Json()
	{
		StringBuilder stringBuilder = new StringBuilder("{");
		stringBuilder.Append("\"auto\": ").Append((_s != null && _s.PackOrgOn) ? "true" : "false");
		stringBuilder.Append(", \"merge\": ").Append((_s != null && _s.PackMerge) ? "true" : "false");
		stringBuilder.Append(", \"status\": ").Append(Q(Status));
		stringBuilder.Append(", \"running\": ").Append((DateTime.Now < _runUntil) ? "true" : "false");
		stringBuilder.Append(", \"rulesText\": ").Append(Q((_s == null) ? "" : _s.PackRules));
		stringBuilder.Append(", \"rules\": [");
		List<Rule> list = Parse((_s == null) ? "" : _s.PackRules);
		for (int i = 0; i < list.Count; i++)
		{
			Rule rule = list[i];
			stringBuilder.Append((i == 0) ? "" : ", ").Append("{\"on\": ").Append(rule.On ? "true" : "false")
				.Append(", \"kind\": ")
				.Append((int)rule.Kind)
				.Append(", \"text\": ")
				.Append(Q(rule.Text))
				.Append(", \"pack\": ")
				.Append(Q(rule.Pack))
				.Append(", \"pos\": ")
				.Append((int)rule.Pos)
				.Append(", \"desc\": ")
				.Append(Q(Describe(rule)))
				.Append("}");
		}
		stringBuilder.Append("], \"packs\": [");
		List<string> list2 = PackNames();
		for (int j = 0; j < list2.Count; j++)
		{
			stringBuilder.Append((j == 0) ? "" : ", ").Append(Q(list2[j]));
		}
		stringBuilder.Append("], \"kinds\": [");
		for (int k = 0; k < KindNames.Length; k++)
		{
			stringBuilder.Append((k == 0) ? "" : ", ").Append(Q(KindNames[k]));
		}
		stringBuilder.Append("], \"positions\": [");
		for (int l = 0; l < PosNames.Length; l++)
		{
			stringBuilder.Append((l == 0) ? "" : ", ").Append(Q(PosNames[l]));
		}
		stringBuilder.Append("], \"sortModes\": [");
		for (int m = 0; m < SortModes.Length; m++)
		{
			stringBuilder.Append((m == 0) ? "" : ", ").Append(Q(SortModes[m]));
		}
		stringBuilder.Append("], \"sortLabels\": [");
		for (int n = 0; n < SortLabels.Length; n++)
		{
			stringBuilder.Append((n == 0) ? "" : ", ").Append(Q(SortLabels[n]));
		}
		stringBuilder.Append("], \"thenModes\": [");
		for (int num = 0; num < ThenModes.Length; num++)
		{
			stringBuilder.Append((num == 0) ? "" : ", ").Append(Q(ThenModes[num]));
		}
		stringBuilder.Append("], \"thenLabels\": [");
		for (int num2 = 0; num2 < ThenLabels.Length; num2++)
		{
			stringBuilder.Append((num2 == 0) ? "" : ", ").Append(Q(ThenLabels[num2]));
		}
		stringBuilder.Append("], \"types\": [");
		for (int num3 = 0; num3 < Types.Length; num3++)
		{
			stringBuilder.Append((num3 == 0) ? "" : ", ").Append(Q(Types[num3]));
		}
		stringBuilder.Append("], \"subTypes\": [");
		for (int num4 = 0; num4 < SubTypes.Length; num4++)
		{
			stringBuilder.Append((num4 == 0) ? "" : ", ").Append(Q(SubTypes[num4]));
		}
		stringBuilder.Append("], \"subsText\": ").Append(Q((_s == null) ? "" : (_s.PackSubs ?? "")));
		stringBuilder.Append(", \"subs\": [");
		List<Sub> subs = Subs;
		for (int num5 = 0; num5 < subs.Count; num5++)
		{
			stringBuilder.Append((num5 == 0) ? "" : ", ").Append("{\"type\": ").Append(Q(subs[num5].Type))
				.Append(", \"text\": ")
				.Append(Q(subs[num5].Text))
				.Append(", \"name\": ")
				.Append(Q(subs[num5].Name))
				.Append("}");
		}
		stringBuilder.Append("]}");
		return stringBuilder.ToString();
	}

	private static string Q(string s)
	{
		StringBuilder stringBuilder = new StringBuilder("\"");
		string text = s ?? "";
		foreach (char c in text)
		{
			if (c == '"' || c == '\\')
			{
				stringBuilder.Append('\\').Append(c);
			}
			else if (c < ' ')
			{
				StringBuilder stringBuilder2 = stringBuilder.Append("\\u");
				int num = c;
				stringBuilder2.Append(num.ToString("x4"));
			}
			else
			{
				stringBuilder.Append(c);
			}
		}
		return stringBuilder.Append('"').ToString();
	}

	/// <summary>/mtank orgwhy: for every pack with a sort rule, what each thing in it is taken for (its class, group and
	/// sub-group) and the order the rule wants - to Logs\MelkTank_OrgWhy.txt.</summary>
	public static string Why()
	{
		try
		{
			_snaps.Clear();
			int id = Globals.Core.CharacterFilter.Id;
			List<WorldObject> all = new List<WorldObject>(InvCache.All());
			List<PackInfo> packs = new List<PackInfo> { new PackInfo { Id = id, Name = "Main pack", Cap = 102 } };
			foreach (KeyValuePair<WorldObject, string> sp in SidePacks(all)) packs.Add(new PackInfo { Id = sp.Key.Id, Name = sp.Value, Cap = 24 });
			Dictionary<int, PackInfo> byId = new Dictionary<int, PackInfo>();
			foreach (PackInfo p in packs) byId[p.Id] = p;
			foreach (WorldObject o in all)
				if (byId.TryGetValue(o.Container, out var pk) && o.ObjectClass != ObjectClass.Container && o.ObjectClass != ObjectClass.Foci && (pk.Id != id || !Worn(o))) pk.Items.Add(o);
			List<Rule> rules = Parse(_s.PackRules);
			StringBuilder sb = new StringBuilder();
			sb.AppendLine("Organize - why things sort where they do, " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
			foreach (PackInfo p in packs)
			{
				Rule rule = rules.Find((Rule r) => r.On && r.Kind == Kind.SortPack && FindPack(packs, r.Pack) == p);
				if (rule == null) continue;
				OrderItems(p.Id, p.Items);
				sb.AppendLine().AppendLine("== " + p.Name + ": " + SortLabel(rule.Text) + "  [" + rule.Text + "]");
				sb.AppendLine("   now: " + string.Join(", ", p.Items.ConvertAll((WorldObject x) => ItemNames.Of(x)).ToArray()));
				List<WorldObject> want = new List<WorldObject>(p.Items);
				want.Sort(Sorter(rule.Text));
				foreach (WorldObject o in want)
				{
					Snap n = S(o);
					sb.AppendLine("   " + n.Name + "  | class " + n.Cls + " | group " + n.Group + " | sub " + (n.Sub.Length > 0 ? n.Sub : "-") + " | key " + (n.SubKey ?? "") + " | type 0x" + Val(o, LongValueKey.Type).ToString("X") + " icon 0x" + o.Icon.ToString("X"));
				}
			}
			string path = Util.FullPath(System.IO.Path.Combine("Logs", "MelkTank_OrgWhy.txt"));
			System.IO.File.WriteAllText(path, sb.ToString());
			return "written to Logs\\MelkTank_OrgWhy.txt";
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			return "failed: " + ex.Message;
		}
	}

	// a small ? box: what it shows comes up while the mouse is over it (as on the Monsters tab)
	private static void HelpMark(string id, Action body)
	{
		ImGui.PushStyleVar(ImGuiStyleVar.FrameBorderSize, 1f);
		ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(0f, 0f, 0f, 0f));
		ImGui.PushStyleColor(ImGuiCol.Border, Cyan);
		ImGui.SmallButton(" ? ##" + id);
		ImGui.PopStyleColor(2);
		ImGui.PopStyleVar();
		if (!ImGui.IsItemHovered()) return;
		ImGui.BeginTooltip();
		body();
		ImGui.EndTooltip();
	}

	private static void HelpRows(string id, string[][] rows)
	{
		if (!ImGui.BeginTable(id, 2, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit)) return;
		ImGui.TableSetupColumn("What", ImGuiTableColumnFlags.WidthFixed, 230f);
		ImGui.TableSetupColumn("How", ImGuiTableColumnFlags.WidthFixed, 430f);
		ImGui.TableHeadersRow();
		foreach (string[] r in rows)
		{
			ImGui.TableNextRow();
			ImGui.TableSetColumnIndex(0); Im.Text(r[0]);
			ImGui.TableSetColumnIndex(1); Im.TextColored(Cyan, r[1]);
		}
		ImGui.EndTable();
	}

	private static void RulesHelp()
	{
		Im.TextColored(Cyan, "Rules are tried top to bottom - the first one an item matches decides where it goes. Move rules with the arrows.");
		HelpRows("orgrulehelptbl", new string[][]
		{
			new string[] { "Name contains", "part of the name: Bag of  ->  every \"Bag of ...\" goes to that pack" },
			new string[] { "Name is", "the whole name exactly: Mana Forge Key" },
			new string[] { "Item type", "a class (WandStaffOrb, MeleeWeapon, Armor, Gem, Misc ...), a group (Weapons, Armor,\nClothing, Jewelry, Misc), Pets, Non-combat Pets, Charms, Everything else - or one of your sub-groups" },
			new string[] { "Charms (Charms tab)", "the items ticked as charms on the Charms tab" },
			new string[] { "Pets (summoning essences)", "your combat pets' essences" },
			new string[] { "Sort pack: type (group)", "by group, then sub-group, then the second sort (name, value ...)" },
			new string[] { "Sort pack: your type order", "a list, front of the pack first: Everything else, WandStaffOrb, Pets, Bonk Bats ...\neach entry a class, group or sub-group; Everything else is where anything not listed goes" },
			new string[] { "Sort pack: name / value / burden / stack", "just that, for the whole pack" },
			new string[] { "anywhere / at the top / at the bottom", "where in the pack it's put (a sort rule on that pack overrides this)" },
		});
	}

	private static void SubsHelp()
	{
		Im.TextColored(Cyan, "Sub-groups name a set of items by their names, to use in rules and sort orders. The first sub-group an item matches is its own.");
		HelpRows("orgsubhelptbl", new string[][]
		{
			new string[] { "Part of the name", "Bag of  ->  any name with \"Bag of\" in it" },
			new string[] { "* anything", "Gem of * Slaying  ->  Gem of Lugian Slaying, Gem of Drudge Slaying ..." },
			new string[] { "| or", "Bouquet of Eyes|Gromnie Eye  ->  either one" },
			new string[] { "& and", "Isparian&Wand  ->  names with both" },
			new string[] { "-not", "Aetheria|-Aetheria Mana Stone  ->  Aetheria, but not the mana stones" },
			new string[] { "!whole name!", "!* Plant!  ->  the whole name is one word and Plant (Mana Plant, not Plant Fiber);\n!Water!  ->  only items named exactly Water" },
			new string[] { "Type", "Any, or only items of that type (Misc, Weapons, Gem ...)" },
			new string[] { "sel", "adds the selected item's name (on the end with | when there's text already); the type is the item's\nfor the first name, and turns to Any when a name of another type is added" },
			new string[] { "Sub-group name", "what rules and sort orders call it (Pet Stuff, Slayer Gems ...)" },
		});
	}

	public static string Command(string what, string rules)
	{
		if (_s == null)
		{
			return "not logged in";
		}
		switch ((what ?? "").Trim().ToLowerInvariant())
		{
		case "run":
			RunNow();
			return "organizing now";
		case "on":
			_s.PackOrgOn = true;
			return "organize automatically: on";
		case "off":
			_s.PackOrgOn = false;
			return "organize automatically: off";
		case "mergeon":
			_s.PackMerge = true;
			return "merge partial stacks: on";
		case "mergeoff":
			_s.PackMerge = false;
			return "merge partial stacks: off";
		case "rules":
			_s.PackRules = Join(Parse(rules));
			return "organize list saved (" + Parse(_s.PackRules).Count + " rules)";
		case "subs":
			_s.PackSubs = JoinSubs(ParseSubs(rules));
			return "sub-groups saved (" + Subs.Count + ")";
		case "dump":
		{
			int id = Globals.Core.CharacterFilter.Id;
			int num = 0;
			int num2 = 0;
			foreach (KeyValuePair<WorldObject, string> item in SidePacks(null))
			{
				if (string.Equals(item.Value, (rules ?? "").Trim(), StringComparison.OrdinalIgnoreCase))
				{
					num = item.Key.Id;
				}
			}
			if (num == 0)
			{
				return "no pack called " + rules;
			}
			foreach (WorldObject item2 in InvCache.All())
			{
				if (item2.Container == num)
				{
					ObjectDump.DumpTo("MelkTank_PackDump.txt", item2, "Pack dump: " + item2.Name);
					num2++;
				}
			}
			foreach (WorldObject item3 in InvCache.All())
			{
				if (IsPet(item3))
				{
					ObjectDump.DumpTo("MelkTank_PackDump.txt", item3, "Pack dump (combat pet, to compare): " + item3.Name);
					break;
				}
			}
			return "dumped " + num2 + " items";
		}
		default:
			return "unknown organize command";
		}
	}

	private static string[] TypeList()
	{
		List<string> list = new List<string> { "Everything else", "Charms", "Pets", "Non-combat Pets", "Armor", "Clothing", "Jewelry", "Weapons", "Misc" };
		list.AddRange(SubGroups);
		foreach (Sub x in Subs)
		{
			if (!list.Exists((string y) => string.Equals(y, x.Name, StringComparison.OrdinalIgnoreCase)))
			{
				list.Add(x.Name);
			}
		}
		string[] names = Enum.GetNames(typeof(ObjectClass));
		foreach (string item in names)
		{
			if (!list.Contains(item))
			{
				list.Add(item);
			}
		}
		return list.ToArray();
	}

	private static List<string> PackNames()
	{
		List<string> list = new List<string> { "Main pack" };
		try
		{
			foreach (KeyValuePair<WorldObject, string> item in SidePacks(null))
			{
				list.Add(item.Value);
			}
		}
		catch
		{
		}
		return list;
	}

	private static List<KeyValuePair<WorldObject, string>> SidePacks(List<WorldObject> inv)
	{
		int id = Globals.Core.CharacterFilter.Id;
		List<WorldObject> list = new List<WorldObject>();
		if (inv == null)
		{
			inv = new List<WorldObject>();
			foreach (WorldObject item in InvCache.All())
			{
				inv.Add(item);
			}
		}
		foreach (WorldObject item2 in inv)
		{
			if (item2.Container == id && item2.ObjectClass == ObjectClass.Container)
			{
				list.Add(item2);
			}
		}
		list.Sort((WorldObject a, WorldObject b) => Slot(a).CompareTo(Slot(b)));
		Dictionary<string, int> dictionary = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
		foreach (WorldObject item3 in list)
		{
			string key = item3.Name ?? "";
			dictionary.TryGetValue(key, out var value);
			dictionary[key] = value + 1;
		}
		List<KeyValuePair<WorldObject, string>> list2 = new List<KeyValuePair<WorldObject, string>>();
		for (int num = 0; num < list.Count; num++)
		{
			string text = list[num].Name ?? "";
			list2.Add(new KeyValuePair<WorldObject, string>(list[num], (dictionary[text] > 1) ? (text + " " + (num + 1)) : text));
		}
		return list2;
	}

	public static bool Draw(Settings s)
	{
		bool flag = false;
		flag |= ImGui.Checkbox("Organize automatically##orgon", ref s.PackOrgOn);
		Im.SetTooltipIfHovered("/mt set PackOrgOn on|off");
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Keeps your packs the way this list says, one move at a time, whenever nothing else is going on\n(no monsters in range, not looting, casting or buffing).");
		}
		ImGui.SameLine();
		if (ImGui.Button("Run now##orgrun"))
		{
			RunNow();
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Work through the list now (for up to 2 minutes), automatically on or not - still only in quiet moments.");
		}
		ImGui.SameLine();
		Vector4 grey = Grey;
		string s2;
		if (Status.Length > 0)
		{
			s2 = Status;
		}
		else
		{
			s2 = (s.PackOrgOn ? "on" : "off");
		}
		Im.TextColored(grey, s2);
		flag |= ImGui.Checkbox("Merge partial stacks##orgmerge", ref s.PackMerge);
		Im.SetTooltipIfHovered("/mt set PackMerge on|off");
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Two part-stacks of the same thing (arrows, scarabs, salvage...) are merged into one, the smaller onto the bigger,\nbefore anything is placed - with the game's own stack merge. Whenever organizing runs (automatically or Run now).");
		}
		Im.TextColored(Grey, "The top of the list wins when an item matches more than one rule. Packs are found by their name.");
		List<Rule> list = Parse(s.PackRules);
		List<string> list2 = PackNames();
		int num = -1;
		int num2 = -1;
		int num3 = -1;
		int num4 = -1;
		if (_editRule >= list.Count)
		{
			_editRule = -1;
		}
		if (ImGui.BeginTable("orgrules", 4, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("#", ImGuiTableColumnFlags.WidthFixed, 26f);
			ImGui.TableSetupColumn("On", ImGuiTableColumnFlags.WidthFixed, 30f);
			ImGui.TableSetupColumn("Rule", ImGuiTableColumnFlags.WidthFixed, 520f);
			ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 120f);
			ImGui.TableHeadersRow();
			for (int i = 0; i < list.Count; i++)
			{
				Rule r = list[i];
				ImGui.PushID("org" + i);
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				Im.TextColored(Grey, (i + 1).ToString());
				ImGui.TableSetColumnIndex(1);
				if (ImGui.Checkbox("##on", ref r.On))
				{
					flag = true;
				}
				ImGui.TableSetColumnIndex(2);
				bool flag2 = !list2.Exists((string p) => string.Equals(p, r.Pack, StringComparison.OrdinalIgnoreCase));
				Vector4 col;
				if (i == _editRule)
				{
					col = Green;
				}
				else if (r.On)
				{
					col = (flag2 ? Yellow : Vector4.One);
				}
				else
				{
					col = Grey;
				}
				Im.TextColored(col, Describe(r) + (flag2 ? "   (no pack by that name now)" : ""));
				ImGui.TableSetColumnIndex(3);
				if (ImGui.SmallButton("edit"))
				{
					num4 = i;
				}
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip("Load this rule into the form below to change it.");
				}
				ImGui.SameLine();
				if (i > 0)
				{
					if (Im.UpButton("##up"))
					{
						num = i;
					}
					ImGui.SameLine();
				}
				if (i < list.Count - 1)
				{
					if (Im.DownButton("##dn"))
					{
						num2 = i;
					}
					ImGui.SameLine();
				}
				if (ImGui.SmallButton("x"))
				{
					num3 = i;
				}
				ImGui.PopID();
			}
			ImGui.EndTable();
		}
		if (list.Count == 0)
		{
			Im.TextColored(Grey, "No rules yet.");
		}
		if (num > 0 || num2 >= 0)
		{
			Rule rule = ((_editRule >= 0) ? list[_editRule] : null);
			Im.Move(list, (num > 0) ? num : num2, num > 0);
			if (rule != null)
			{
				_editRule = list.IndexOf(rule);
			}
			flag = true;
		}
		if (num3 >= 0)
		{
			list.RemoveAt(num3);
			flag = true;
			if (_editRule == num3)
			{
				_editRule = -1;
			}
			else if (_editRule > num3)
			{
				_editRule--;
			}
		}
		if (num4 >= 0)
		{
			LoadRule(list[num4], num4, list2);
		}
		ImGui.Separator();
		Im.TextColored((_editRule >= 0) ? Green : Cyan, (_editRule >= 0) ? ("Edit rule " + (_editRule + 1)) : "Add a rule");
		ImGui.SetNextItemWidth(170f);
		ImGui.Combo("##orgkind", ref _newKind, KindNames, KindNames.Length);
		Kind newKind = (Kind)_newKind;
		if (newKind == Kind.NameContains || newKind == Kind.NameIs)
		{
			ImGui.SameLine();
			ImGui.SetNextItemWidth(220f);
			ImGui.InputTextWithHint("##orgtext", "name text", ref _newText, 400u);
			ImGui.SameLine();
			if (ImGui.SmallButton("sel##orgsel"))
			{
				try
				{
					WorldObject worldObject = Globals.Core.WorldFilter[Globals.Core.Actions.CurrentSelection];
					if (worldObject != null)
					{
						_newText = ItemNames.Of(worldObject);
					}
				}
				catch
				{
				}
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("The name of the item you have selected.");
			}
		}
		else if (newKind == Kind.ItemType)
		{
			ImGui.SameLine();
			ImGui.SetNextItemWidth(170f);
			ImGui.Combo("##orgtype", ref _newType, Types, Types.Length);
		}
		ImGui.SameLine();
		Im.TextColored(Grey, (newKind == Kind.SortPack) ? "pack" : "->");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(190f);
		if (_newPack >= list2.Count)
		{
			_newPack = 0;
		}
		ImGui.Combo("##orgpack", ref _newPack, list2.ToArray(), list2.Count);
		if (newKind != Kind.SortPack)
		{
			ImGui.SameLine();
			ImGui.SetNextItemWidth(110f);
			ImGui.Combo("##orgpos", ref _newPos, PosNames, PosNames.Length);
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Where the move drops it - nothing keeps it there afterwards (a sort rule on the pack decides the order).");
			}
		}
		else
		{
			ImGui.SameLine();
			Im.TextColored(Grey, "by");
			ImGui.SameLine();
			ImGui.SetNextItemWidth(190f);
			ImGui.Combo("##orgsort", ref _newSort, SortLabels, SortLabels.Length);
			if (SortModes[_newSort] != "name")
			{
				ImGui.SameLine();
				Im.TextColored(Grey, "then");
				ImGui.SameLine();
				ImGui.SetNextItemWidth(150f);
				ImGui.Combo("##orgthen", ref _newThen, ThenLabels, ThenLabels.Length);
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip("The order inside each group (or among items that tie): name A-Z, Z-A, value or burden.");
				}
			}
		}
		if (newKind == Kind.SortPack && SortModes[_newSort] == "order")
		{
			ImGui.SetNextItemWidth(330f);
			ImGui.InputTextWithHint("##orgorder", "type order, e.g. WandStaffOrb, Armor, Jewelry, Misc", ref _newOrder, 2000u);
			ImGui.SameLine();
			ImGui.SetNextItemWidth(150f);
			ImGui.Combo("##orgopick", ref _orderPick, Types, Types.Length);
			ImGui.SameLine();
			if (ImGui.Button("+##orgoadd", new Vector2(60f, 0f)))
			{
				_newOrder = ((_newOrder.Trim().Length > 0) ? (_newOrder.Trim().TrimEnd(',') + ", ") : "") + Types[_orderPick];
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Add this type to the order. Item types or the groups Charms, Pets, Armor, Clothing, Jewelry, Weapons, Misc;\nanything not named comes after - or wherever you put \"Everything else\".");
			}
		}
		ImGui.SameLine(0f, 24f);
		bool flag3 = newKind == Kind.Charms || newKind == Kind.Pets || newKind == Kind.SortPack || newKind == Kind.ItemType || _newText.Trim().Length > 0;
		if (!flag3)
		{
			ImGui.BeginDisabled();
		}
		bool flag4 = _editRule >= 0 && _editRule < list.Count;
		if (ImGui.Button((flag4 ? "Update" : "Add") + "##orgadd", new Vector2(60f, 0f)))
		{
			Rule rule2 = new Rule
			{
				Kind = newKind,
				Pack = list2[_newPack],
				Pos = ((newKind != Kind.SortPack) ? ((Pos)_newPos) : Pos.Anywhere)
			};
			object text;
			switch (newKind)
			{
			default:
				text = "";
				break;
			case Kind.SortPack:
				text = WithThen((SortModes[_newSort] == "order") ? ("order:" + _newOrder.Trim()) : SortModes[_newSort], (SortModes[_newSort] == "name") ? "name" : ThenModes[_newThen]);
				break;
			case Kind.NameContains:
			case Kind.NameIs:
				text = _newText.Trim();
				break;
			case Kind.ItemType:
				text = Types[_newType];
				break;
			}
			rule2.Text = (string)text;
			Rule rule3 = rule2;
			if (flag4)
			{
				rule3.On = list[_editRule].On;
				list[_editRule] = rule3;
				_editRule = -1;
			}
			else
			{
				list.Add(rule3);
			}
			_newText = "";
			flag = true;
		}
		if (!flag3)
		{
			ImGui.EndDisabled();
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip(flag4 ? ("Save the changes to rule " + (_editRule + 1) + " (it keeps its place in the list).") : "Added at the bottom (lowest priority) - move it up with the arrows.");
		}
		if (flag4)
		{
			ImGui.SameLine();
			if (ImGui.Button("Cancel##orgcancel", new Vector2(60f, 0f)))
			{
				_editRule = -1;
				_newText = "";
			}
		}
		ImGui.SameLine();
		HelpMark("orgrulehelp", RulesHelp);
		if (flag)
		{
			s.PackRules = Join(list);
		}
		return flag | DrawSubs(s);
	}

	private static void LoadRule(Rule r, int index, List<string> packs)
	{
		_editRule = index;
		_newKind = (int)r.Kind;
		_newText = ((r.Kind == Kind.NameContains || r.Kind == Kind.NameIs) ? (r.Text ?? "") : "");
		if (r.Kind == Kind.ItemType)
		{
			int num = Array.FindIndex(Types, (string x) => string.Equals(x, r.Text, StringComparison.OrdinalIgnoreCase));
			if (num >= 0)
			{
				_newType = num;
			}
		}
		int num2 = packs.FindIndex((string x) => string.Equals(x, r.Pack, StringComparison.OrdinalIgnoreCase));
		if (num2 >= 0)
		{
			_newPack = num2;
		}
		_newPos = (int)r.Pos;
		if (r.Kind == Kind.SortPack)
		{
			string text = SortMode(r.Text);
			_newSort = Math.Max(0, Array.IndexOf(SortModes, text));
			_newOrder = ((text == "order") ? string.Join(", ", SortOrder(r.Text).ToArray()) : "");
			_newThen = Math.Max(0, Array.IndexOf(ThenModes, ThenMode(r.Text)));
		}
	}

	private static bool DrawSubs(Settings s)
	{
		bool flag = false;
		ImGui.Separator();
		if (!ImGui.CollapsingHeader("Your sub-groups (" + Subs.Count + ")##orgsubs"))
		{
			return false;
		}
		Im.TextColored(Grey, "Items of that type with that text in the name sort together under your name for them (A-Z among the sub-groups),\nand the name is in the type lists for type orders and move rules. Yours win over the built-in ones; the first match wins.\nShared by all your characters.");
		List<Sub> subs = new List<Sub>(Subs);
		int num = -1;
		int num2 = -1;
		int edit = -1;
		if (_editSub >= subs.Count)
		{
			_editSub = -1;
		}
		// a list: on/off, the sub-group's name, its type, the names it takes (wrapped, all of it shown), and the buttons
		int down = -1;
		ImGuiTableFlags tf = ImGuiTableFlags.RowBg | ImGuiTableFlags.BordersInnerH | ImGuiTableFlags.BordersOuter | ImGuiTableFlags.SizingFixedFit;
		if (subs.Count > 0 && ImGui.BeginTable("osublist", 5, tf, new Vector2(ImGui.GetContentRegionAvail().X - 8f, 0f)))
		{
			ImGui.TableSetupColumn("On", ImGuiTableColumnFlags.WidthFixed, 26f);
			ImGui.TableSetupColumn("Sub-group", ImGuiTableColumnFlags.WidthFixed, 130f);
			ImGui.TableSetupColumn("Type", ImGuiTableColumnFlags.WidthFixed, 70f);
			ImGui.TableSetupColumn("Name has", ImGuiTableColumnFlags.WidthStretch);
			// (wide enough for the four buttons at any font size - at a fixed 118 the x went past the edge)
			ImGuiStylePtr st = ImGui.GetStyle();
			float bw = ImGui.GetFrameHeight() * 2f + ImGui.CalcTextSize("edit").X + ImGui.CalcTextSize("x").X + st.FramePadding.X * 4f + st.ItemSpacing.X * 3f + st.CellPadding.X * 2f + 6f;
			ImGui.TableSetupColumn("##osubbtns", ImGuiTableColumnFlags.WidthFixed, bw);
			ImGui.TableHeadersRow();
			for (int i = 0; i < subs.Count; i++)
			{
				ImGui.PushID("osub" + i);
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				bool on = subs[i].On;
				if (ImGui.Checkbox("##on", ref on))
				{
					subs[i].On = on;
					flag = true;
				}
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip(on ? "On - untick to set this sub-group aside without losing it." : "Off - nothing is put in this sub-group.");
				}
				Vector4 col = (i == _editSub) ? Green : (subs[i].On ? Vector4.One : Grey);
				ImGui.TableSetColumnIndex(1);
				Im.TextColored(col, subs[i].Name);
				ImGui.TableSetColumnIndex(2);
				Im.TextColored(Grey, subs[i].Type);
				ImGui.TableSetColumnIndex(3);
				ImGui.PushStyleColor(ImGuiCol.Text, col);
				ImGui.PushTextWrapPos(0f);
				ImGui.TextUnformatted(subs[i].Text.Replace("|", " | "));
				ImGui.PopTextWrapPos();
				ImGui.PopStyleColor();
				ImGui.TableSetColumnIndex(4);
				if (i > 0)
				{
					if (Im.UpButton("##sup"))
					{
						num2 = i;
					}
				}
				else
				{
					ImGui.Dummy(new Vector2(ImGui.GetFrameHeight(), ImGui.GetFrameHeight()));
				}
				ImGui.SameLine();
				if (i < subs.Count - 1)
				{
					if (Im.DownButton("##sdown"))
					{
						down = i;
					}
				}
				else
				{
					ImGui.Dummy(new Vector2(ImGui.GetFrameHeight(), ImGui.GetFrameHeight()));
				}
				ImGui.SameLine();
				if (ImGui.SmallButton("edit"))
				{
					edit = i;
				}
				ImGui.SameLine();
				if (ImGui.SmallButton("x"))
				{
					num = i;
				}
				ImGui.PopID();
			}
			ImGui.EndTable();
		}
		if (down >= 0)
		{
			Sub keepEdit = ((_editSub >= 0) ? subs[_editSub] : null);
			Im.Move(subs, down, up: false);
			if (keepEdit != null)
			{
				_editSub = subs.IndexOf(keepEdit);
			}
			flag = true;
		}
		if (num2 > 0)
		{
			Sub sub = ((_editSub >= 0) ? subs[_editSub] : null);
			Im.Move(subs, num2, up: true);
			if (sub != null)
			{
				_editSub = subs.IndexOf(sub);
			}
			flag = true;
		}
		if (num >= 0)
		{
			subs.RemoveAt(num);
			flag = true;
			if (_editSub == num)
			{
				_editSub = -1;
			}
			else if (_editSub > num)
			{
				_editSub--;
			}
		}
		if (edit >= 0)
		{
			_editSub = edit;
			int num3 = Array.FindIndex(SubTypes, (string x) => string.Equals(x, subs[edit].Type, StringComparison.OrdinalIgnoreCase));
			if (num3 >= 0)
			{
				_subType = num3;
			}
			_subText = subs[edit].Text;
			_subName = subs[edit].Name;
		}
		if (_editSub >= 0)
		{
			Im.TextColored(Green, "Editing " + subs[_editSub].Name + ":");
		}
		ImGui.SetNextItemWidth(130f);
		ImGui.Combo("##osubtype", ref _subType, SubTypes, SubTypes.Length);
		ImGui.SameLine();
		ImGui.SetNextItemWidth(170f);
		ImGui.InputTextWithHint("##osubtext", "part of the name, e.g. Bag of  (* anything, & and, | or, -not, !whole name!)", ref _subText, 4000u);
		ImGui.SameLine();
		if (ImGui.SmallButton("sel##osubsel"))
		{
			try
			{
				WorldObject worldObject = Globals.Core.WorldFilter[Globals.Core.Actions.CurrentSelection];
				if (worldObject != null)
				{
					// (added on the end with | when there's text already - another name for the same sub-group)
					string nm = worldObject.Name ?? "";
					string cur = _subText.Trim();
					if (cur.Length == 0) _subText = nm;
					else if (Array.IndexOf(Array.ConvertAll(cur.Split('|'), (string x) => x.Trim().ToLowerInvariant()), nm.Trim().ToLowerInvariant()) < 0) _subText = cur + "|" + nm;
					// the type: the item's when it's the first name; adding another name of a different type makes it Any
					// (it was set to the last item's - a Tools list turned into "Gem" and left its other tools out)
					int num4 = Array.IndexOf(SubTypes, worldObject.ObjectClass.ToString());
					if (cur.Length == 0)
					{
						if (num4 >= 0) _subType = num4;
					}
					else if (num4 != _subType)
					{
						int any = Array.IndexOf(SubTypes, "Any");
						if (any >= 0) _subType = any;
					}
				}
			}
			catch
			{
			}
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("The selected item's name (added on the end with | if there's text already). The type is the item's for the first name,\nand turns to Any when a name of another type is added.");
		}
		ImGui.SameLine();
		Im.TextColored(Grey, "->");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(150f);
		ImGui.InputTextWithHint("##osubname", "sub-group name", ref _subName, 100u);
		ImGui.SameLine();
		bool flag2 = _subText.Trim().Length > 0 && _subName.Trim().Length > 0;
		if (!flag2)
		{
			ImGui.BeginDisabled();
		}
		bool flag3 = _editSub >= 0 && _editSub < subs.Count;
		if (ImGui.Button((flag3 ? "Update" : "Add") + "##osubadd", new Vector2(60f, 0f)))
		{
			Sub sub2 = new Sub
			{
				Type = SubTypes[_subType],
				Text = _subText.Trim(),
				Name = _subName.Trim()
			};
			if (flag3)
			{
				sub2.On = subs[_editSub].On;
				subs[_editSub] = sub2;
				_editSub = -1;
			}
			else
			{
				subs.Add(sub2);
			}
			_subText = "";
			_subName = "";
			flag = true;
		}
		if (!flag2)
		{
			ImGui.EndDisabled();
		}
		if (flag3)
		{
			ImGui.SameLine();
			if (ImGui.Button("Cancel##osubcancel", new Vector2(60f, 0f)))
			{
				_editSub = -1;
				_subText = "";
				_subName = "";
			}
		}
		ImGui.SameLine();
		HelpMark("orgsubhelp", SubsHelp);
		if (flag)
		{
			s.PackSubs = JoinSubs(subs);
		}
		return flag;
	}
}
