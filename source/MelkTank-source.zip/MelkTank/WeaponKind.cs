namespace MelkTank;

public enum WeaponKind
{
	Caster,
	Melee,
	Missile,
	Ammo,
	HealKit,
	ManaKit,
	StaminaKit,
	Health,
	ManaStone,
	Lockpick,
	Dispel
}
