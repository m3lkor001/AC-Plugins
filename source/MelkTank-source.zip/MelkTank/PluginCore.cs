using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using MelkTank.Bounties;
using MelkTank.Loot;
using MelkTank.Metas;
using MelkTank.Pets;

namespace MelkTank;

public class PluginCore
{
	private static PluginCore _hot;

	private static volatile string _pruneNote;

	internal static bool HotReloading;

	private static Timer _freeTimer;

	internal static DateTime HotStartedAt = DateTime.MinValue;

	private static readonly HashSet<string> _pausedBy = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

	private static Settings _current;

	private Settings _settings;

	private CombatEngine _engine;

	private MainView _view;

	private MiniHud _mini;

	private DayNightHud _dayNight;

	private ItemBar _itemBar;

	private BountyTracker _bounty;

	private BountyHud _bountyHud;

	private PetSummoner _pets;

	private Breeding _breeding;

	private bool _loggedIn;

	private string _charKey;

	private string _loadedKey;

	private bool _keyWarned;

	private bool _startedInWorld;

	private static DateTime _idleSetAt = DateTime.MinValue;

	private DateTime _saveDueAt = DateTime.MinValue;

	private DateTime _saveFirstAt = DateTime.MinValue;

	private static PluginCore _instance;

	private DateTime _petCommandAt = DateTime.MinValue;

	private DateTime _petPolledAt = DateTime.MinValue;

	private bool? _petLastSeen;

	private FieldInfo _petInstField;

	private FieldInfo _petEnabledField;

	private bool _petLookedUp;

	internal const bool Acg = true;

	protected PluginHost Host { get; private set; }

	protected CoreManager Core { get; private set; }

	public static bool IsPaused => _pausedBy.Count > 0;

	public static string PausedByText => string.Join(", ", new List<string>(_pausedBy).ToArray());

	internal static Settings CurrentSettings => _current;

	internal static CombatEngine CurrentEngine => _instance?._engine;

	public static void HotStart(PluginHost host, CoreManager core, string dir, DateTime clientStartUtc)
	{
		Util.SetBasePath(dir);
		try
		{
			Util.ProfilesDir("Navs");
			Util.ProfilesDir("Metas");
			Util.FullPath("Snapshots");
			Util.FullPath("Profiles");
		}
		catch
		{
		}
		Remote.ClientStartUtc = clientStartUtc;
		HotStartedAt = DateTime.Now;
		_hot = new PluginCore
		{
			Host = host,
			Core = core
		};
		_hot.Startup();
		ThreadPool.QueueUserWorkItem((object? _) =>
		{
			PruneOldBuilds(dir, 10);
		});
		try
		{
			if (core.CharacterFilter.LoginStatus == 3)
			{
				Notes.AddLater("build " + BuildInfo.Label + " took over (hot reload / rollback)", "auto", 8.0);
			}
		}
		catch
		{
		}
	}

	private static void PruneOldBuilds(string dir, int keep)
	{
		try
		{
			string path = Path.Combine(dir, "_to_delete");
			if (!Directory.Exists(path))
			{
				return;
			}
			FileInfo[] files = new DirectoryInfo(path).GetFiles("MelkTankCore.old-b*.dll");
			if (files.Length <= keep)
			{
				return;
			}
			Array.Sort(files, (FileInfo a, FileInfo b) => b.LastWriteTimeUtc.CompareTo(a.LastWriteTimeUtc));
			int num = 0;
			long num2 = 0L;
			for (int num3 = keep; num3 < files.Length; num3++)
			{
				try
				{
					long length = files[num3].Length;
					files[num3].Delete();
					num++;
					num2 += length;
				}
				catch
				{
				}
			}
			if (num > 0)
			{
				_pruneNote = "Old builds: removed " + num + " from _to_delete (" + num2 / 1048576 + " MB), kept the newest " + keep + ".";
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void HotStop(bool reload)
	{
		HotReloading = reload;
		try
		{
			// (a call of its own: on a game older than this build the hook isn't there to unhook)
			PackOrganizer.UnhookTakenOff();
		}
		catch
		{
		}
		if (reload)
		{
			try
			{
				Session.SaveCarry();
			}
			catch
			{
			}
		}
		try
		{
			if (_hot != null)
			{
				_hot.Shutdown();
			}
		}
		finally
		{
			_hot = null;
		}
		if (!reload || !(Tuning.V("FreeOldBuild") >= 1.0))
		{
			return;
		}
		_freeTimer = new Timer((object? _) =>
		{
			try
			{
				HotCleanup.Free();
			}
			catch
			{
			}
		}, null, 10000, -1);
	}

	public static void Pause(string who)
	{
		if (string.IsNullOrEmpty(who))
		{
			who = "external";
		}
		_pausedBy.Add(who);
	}

	public static void Resume(string who)
	{
		if (string.IsNullOrEmpty(who))
		{
			who = "external";
		}
		_pausedBy.Remove(who);
	}

	public static string PetElementFor(string monsterName)
	{
		try
		{
			Settings current = _current;
			if (current == null)
			{
				return null;
			}
			MonsterRule monsterRule = current.FindRule(monsterName ?? "");
			DmgType petDmg = monsterRule.PetDmg;
			if (petDmg == DmgType.Auto && !monsterRule.IsDefault)
			{
				petDmg = current.DefaultRule.PetDmg;
			}
			return petDmg switch
			{
				DmgType.Auto => "None", 
				DmgType.Void => "Nether", 
				DmgType.Blade => "Slash", 
				_ => petDmg.ToString(), 
			};
		}
		catch
		{
			return null;
		}
	}

	/// <summary>A monster only pets can hurt (Pets > Settings list): never attacked, and the pet comes for it.</summary>
	public static bool IsPetOnly(string name)
	{
		var s = _current;
		if (s == null || string.IsNullOrEmpty(name) || string.IsNullOrEmpty(s.PetOnlyMonsters)) return false;
		foreach (string line in s.PetOnlyMonsters.Split('\n'))
			if (line.Trim().Length > 0 && string.Equals(line.Trim(), name.Trim(), StringComparison.OrdinalIgnoreCase)) return true;
		return false;
	}

	// "Leftover Pizza can only be harmed by combat pets." - put on the pet-only list (Pets > Settings) the first time
	private static readonly System.Text.RegularExpressions.Regex PetOnlyRx = new System.Text.RegularExpressions.Regex(@"^\s*(.+?) can only be harmed by combat pets", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
	private void LearnPetOnly(string text)
	{
		var s = _current;
		if (s == null || string.IsNullOrEmpty(text)) return;
		var m = PetOnlyRx.Match(text);
		if (!m.Success) return;
		string name = m.Groups[1].Value.Trim();
		if (name.Length == 0 || name.Length > 60 || IsPetOnly(name)) return;
		s.PetOnlyMonsters = (s.PetOnlyMonsters ?? "").TrimEnd('\n') + (string.IsNullOrEmpty(s.PetOnlyMonsters) ? "" : "\n") + name;
		try { SaveAll(); } catch { }
		Util.WriteToChat("Pets: " + name + " is pet-only - added to the list (Pets > Settings).");
	}

	public static string PetHoldWhy()
	{
		Settings current = _current;
		if (current == null) return "";
		if (current.PetOnlyInCombat && (!current.CombatEnabled || !current.MasterEnabled)) return "only summons while Combat is on";
		return "summons before the fight only";
	}

	public static bool PetHold()
	{
		Settings current = _current;
		if (current == null)
		{
			return false;
		}
		if (current.PetOnlyInCombat && (!current.CombatEnabled || !current.MasterEnabled))
		{
			return true;
		}
		CombatEngine currentEngine = CurrentEngine;
		return current.PetNoSummonInFight && currentEngine != null && currentEngine.FightingNow;
	}

	public static bool PetRechargeHold()
	{
		Settings current = _current;
		CombatEngine currentEngine = CurrentEngine;
		return current != null && current.PetRechargeBetweenPacks && currentEngine != null && currentEngine.FightingNow;
	}

	public static double PetRangeOverride()
	{
		return (_current == null) ? (-1.0) : PetRange();
	}

	public static double PetRange()
	{
		Settings current = _current;
		if (current == null)
		{
			return 20.0;
		}
		double num = (current.PetNoSummonInFight ? Tuning.V("PetLeadM") : 0.0);
		if (current.PetUseCombatRange)
		{
			PluginCore instance = _instance;
			return (double)((instance != null && instance._engine != null) ? instance._engine.AttackRangeNow : current.AttackRange) + num;
		}
		return (double)Math.Max(1f, current.PetRange) + num;
	}

	protected void Startup()
	{
		try
		{
			Globals.Init(Host, Core);
#if RETAIL
			VTankStandIn.Hook();
#endif
			Core.CharacterFilter.LoginComplete += OnLoginComplete;
			Core.CharacterFilter.Logoff += OnLogoff;
			Core.CommandLineText += OnCommandLineText;
			Core.ChatBoxMessage += OnEarlyChat;
			Core.CharacterFilter.Login += OnCharacterChosen;
			Remote.Startup();
			if (Core.CharacterFilter.LoginStatus == 3)
			{
				_startedInWorld = true;
				OnLoginComplete(this, EventArgs.Empty);
			}
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Startup error: " + ex.Message);
			Util.LogError(ex);
		}
	}

	private void OnEarlyChat(object sender, ChatTextInterceptEventArgs e)
	{
		try
		{
			Catcher.OnChat(e.Text);
			if (_engine == null || !_loggedIn)
			{
				Nav.EarlyChat(e.Text);
			}
		}
		catch
		{
		}
	}

	private void OnCharacterChosen(object sender, LoginEventArgs e)
	{
		try
		{
			Catcher.LoginStarted();
		}
		catch
		{
		}
	}

	protected void Shutdown()
	{
		try
		{
			Core.ChatBoxMessage -= OnEarlyChat;
			Core.CharacterFilter.Login -= OnCharacterChosen;
		}
		catch
		{
		}
		try
		{
			MonsterDb.Flush();
		}
		catch
		{
		}
		try
		{
			BookReader.Unhook();
		}
		catch
		{
		}
		try
		{
			Teardown();
			Remote.Shutdown();
			Core.CharacterFilter.LoginComplete -= OnLoginComplete;
			Core.CharacterFilter.Logoff -= OnLogoff;
			Core.CommandLineText -= OnCommandLineText;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private string CharKey()
	{
		string name = Core.CharacterFilter.Name;
		if (!string.IsNullOrEmpty(name) && !name.Equals("LoginNotComplete", StringComparison.OrdinalIgnoreCase))
		{
			_charKey = Core.CharacterFilter.Server + "-" + name;
		}
		return _charKey ?? (Core.CharacterFilter.Server + "-" + name);
	}

	private void OnLoginComplete(object sender, EventArgs e)
	{
		if (_loggedIn)
		{
			return;
		}
		// (lum/hr by the bank starts again from the bank as it is now)
		LumTrack.NewLogin();
		bool flag = !_startedInWorld;
		_startedInWorld = false;
		try
		{
			Catcher.LoginStarted();
		}
		catch
		{
		}
		_loggedIn = true;
		try
		{
			BookReader.HookUb();
		}
		catch
		{
		}
		try
		{
			_settings = new Settings();
			_loadedKey = CharKey();
			_settings.Load(_loadedKey);
			if (flag && _settings.OpenPackAtLogin)
			{
				try
				{
					Core.Actions.UseItem(Core.CharacterFilter.Id, 0);
				}
				catch
				{
				}
			}
			LiveSettings.Init(_settings, SaveAll);
			SettingsTools.Init(_settings, SaveAll);
			SettingsTools.WriteTuningInfo();
			SettingsTools.WriteSettingsInfo();
			PackStats.RouteStep = () => (_engine != null) ? _engine.Nav.RouteStepNow : 0;
			PackStats.RouteName = () => (_engine != null) ? _engine.Nav.RouteNameNow : "";
			_current = _settings;
			_engine = new CombatEngine(_settings);
			_engine.Nav.MetaNeedBuff = () => _engine.Buffer.Busy || _engine.Buffer.SpellsLeft > 0;
			_view = new MainView(_settings, _engine, SaveAll, OnBufferToggled, OnPetToggled);
			_mini = new MiniHud(_settings, _engine, SaveAll, OnBufferToggled, OnPetToggled);
			try
			{
				_dayNight = new DayNightHud(_settings, SaveAll);
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
			try
			{
				_itemBar = new ItemBar(_settings, SaveAll);
			}
			catch (Exception ex2)
			{
				Util.LogError(ex2);
			}
			GiveWindow.Init(_settings);
			IdInfo.Init(_settings);
			_view.MiniReset = () =>
			{
				if (_mini != null)
				{
					_mini.ResetPosition();
				}
			};
			try
			{
				_bounty = new BountyTracker
				{
					IntervalSeconds = Math.Max(1, _settings.BountyMinutes) * 60,
					Enabled = _settings.BountyHudOn
				};
				CombatEngine eng = _engine;
				_bounty.Log = (string m) =>
				{
					try
					{
						if (eng.Nav.Log != null)
						{
							eng.Nav.Log("BOUNTY " + m);
						}
					}
					catch
					{
					}
				};
				_bountyHud = new BountyHud(_bounty, _settings);
				LumPopout.Restore(_settings);   // (the Lum pop-out, if it was open)
			}
			catch (Exception ex3)
			{
				Util.LogError(ex3);
			}
			try
			{
				Charms.Init(_settings);
			}
			catch
			{
			}
			try
			{
				BadItems.Init(_settings);
				PackOrganizer.Init(_settings, (string l) =>
				{
					try
					{
						if (_engine != null)
						{
							_engine.NoteLine(l);
						}
					}
					catch
					{
					}
				});
				if (!_settings.PackRulesSeeded)
				{
					_settings.PackRulesSeeded = true;
					List<PackOrganizer.Rule> list = PackOrganizer.Parse(_settings.PackRules);
					list.Add(new PackOrganizer.Rule
					{
						Kind = PackOrganizer.Kind.Charms,
						Pack = "Weapon Rack"
					});
					list.Add(new PackOrganizer.Rule
					{
						Kind = PackOrganizer.Kind.NameContains,
						Text = "Bag of",
						Pack = "Weapon Rack",
						Pos = PackOrganizer.Pos.Bottom
					});
					_settings.PackRules = PackOrganizer.Join(list);
				}
			}
			catch (Exception ex4)
			{
				Util.LogError(ex4);
			}
			try
			{
				HoverInfo.SaveAll = SaveAll;
				HoverInfo.Init(_settings);
				Hotkeys.Init();
			}
			catch (Exception ex5)
			{
				Util.LogError(ex5);
			}
			_engine.Buffer.Init(CharKey(), _settings.MelksBufferEnabled && _settings.MasterEnabled);
			MonsterLog.On = () => _settings != null && _settings.MonsterLogOn;
			_pets = new PetSummoner(_settings, SaveAll);
			try
			{
				_pets.Start(CharKey());
				_breeding = new Breeding(_settings, SaveAll);
				_breeding.Start(Globals.Core.CharacterFilter.Name);
			}
			catch (Exception ex6)
			{
				Util.LogError(ex6);
			}
			try
			{
				Dex.Reset();
				Dex.LoadBook();
				Dex.LoadPetLog();
				Dex.AskPetLogSoon(8.0);
			}
			catch (Exception ex7)
			{
				Util.LogError(ex7);
			}
			_instance = this;
			_engine.Windows.LoggedIn();
			try
			{
				CombatEngine eng2 = _engine;
				LoginCommands.Log = (string m) =>
				{
					try
					{
						if (eng2.Nav.Log != null)
						{
							eng2.Nav.Log(m);
						}
					}
					catch
					{
					}
				};
				LoginCommands.LoggedIn(Core.CharacterFilter.Server, Core.CharacterFilter.Name);
			}
			catch (Exception ex8)
			{
				Util.LogError(ex8);
			}
			try
			{
				Salvager.LoggedIn(Core.CharacterFilter.Name);
			}
			catch
			{
			}
			Core.RenderFrame += OnRenderFrame;
			Core.ChatBoxMessage += OnChatBoxMessage;
			Core.StatusBoxMessage += OnStatusBoxMessage;
			Core.EchoFilter.ServerDispatch += OnServerMessage;
			Core.EchoFilter.ClientDispatch += OnClientMessage;
			Core.CharacterFilter.ChangePortalMode += OnPortal;
			Core.WorldFilter.ReleaseObject += OnReleaseObject;
			Core.WorldFilter.ChangeObject += OnChangeObject;
			Core.CharacterFilter.ChangeEnchantments += OnChangeEnchantments;
			Core.CharacterFilter.Death += OnDeath;
			Remote.LoggedIn();
			NoIdleLogout();
			if (!HotReloading)
			{
				PackOrganizer.ForgetOrders();
			}
			Session.LoggedIn();
			FellowManager.Init(_settings);
			Dispel.Init(_settings);
			Dispel.SaveAll = SaveAll;
			FellowManager.SaveAll = SaveAll;
			FellowManager.CurrentTier = () => (_engine != null && _engine.Tier != null) ? _engine.Tier.Tier : (-1);
			Session.CountLumTokens = _settings.CountLumTokens;
			Session.BountyRateOn = _settings.BountyLumRate;
			Session.CurrentTier = () => (_engine != null && _engine.Tier != null) ? _engine.Tier.Tier : (-1);
			Session.LumTokenValue = (double)_settings.LumTokenB * 1000000000.0;
			FellowManager.LoggedIn();
			Util.WriteToChat("Loaded. Combat is " + (_settings.CombatEnabled ? "ON" : "OFF") + ". /mtank help for commands.");
		}
		catch (Exception ex9)
		{
			Util.WriteToChat("Login error: " + ex9.Message);
			Util.LogError(ex9);
		}
	}

	public static void NoIdleLogout()
	{
		try
		{
			CoreManager.Current.Actions.SetIdleTime(double.MaxValue);
			_idleSetAt = DateTime.Now;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void OnLogoff(object sender, LogoffEventArgs e)
	{
		// (this character's packs, for Items > Inventory - before they're gone)
		try
		{
			if (!HotReloading)
			{
				InvStore.Save("logout");
			}
		}
		catch
		{
		}
		try
		{
			if (e.Type == LogoffEventType.Requested)
			{
				Remote.LogoffAsked();
			}
		}
		catch
		{
		}
		try
		{
			if (!HotReloading)
			{
				DateTime now = DateTime.Now;
				string text = ((Remote.LogoffAskedAt != DateTime.MinValue && (now - Remote.LogoffAskedAt).TotalSeconds < 60.0) ? ("the client asked to log out " + (now - Remote.LogoffAskedAt).TotalSeconds.ToString("0.0") + " s before (Exit / the X / /logout / a plugin's logout)") : "nothing asked to log out (a drop)");
				double serverQuietSecs = Remote.ServerQuietSecs;
				string text2 = ((Util.LastCommandAt == DateTime.MinValue) ? "none" : ("\"" + Util.LastCommand + "\" " + (now - Util.LastCommandAt).TotalSeconds.ToString("0") + " s before"));
				Notes.Add("logged out (" + e.Type.ToString() + ") - " + text + "; server last heard " + ((serverQuietSecs < 0.0) ? "?" : (serverQuietSecs.ToString("0.0") + " s")) + " before; MelkTank's last command: " + text2 + (MemWatch.Relogging ? "; MelkTank's memory relog" : ""), "auto", quiet: true);
			}
		}
		catch
		{
		}
		Teardown();
	}

	private void Teardown()
	{
		if (!_loggedIn)
		{
			return;
		}
		_loggedIn = false;
		if (!HotReloading)
		{
			try
			{
				Remote.LoggedOut();
			}
			catch
			{
			}
		}
		try
		{
			Session.LoggedOut();
		}
		catch
		{
		}
		try
		{
			Locations.Flush();
		}
		catch
		{
		}
		try
		{
			try
			{
				if (_engine != null)
				{
					_engine.Nav.TravelStop("logging off", finished: false);
				}
			}
			catch
			{
			}
			SaveAllFlush();
			_current = null;
			if (_engine != null)
			{
				_engine.ReleaseNav();
			}
			if (_engine != null)
			{
				_engine.Nav.Dispose();
			}
			Core.RenderFrame -= OnRenderFrame;
			Core.ChatBoxMessage -= OnChatBoxMessage;
			Core.StatusBoxMessage -= OnStatusBoxMessage;
			Core.EchoFilter.ServerDispatch -= OnServerMessage;
			Core.EchoFilter.ClientDispatch -= OnClientMessage;
			Core.CharacterFilter.ChangePortalMode -= OnPortal;
			Core.WorldFilter.ReleaseObject -= OnReleaseObject;
			InvCache.Unhook();
			Core.WorldFilter.ChangeObject -= OnChangeObject;
			Core.CharacterFilter.ChangeEnchantments -= OnChangeEnchantments;
			Core.CharacterFilter.Death -= OnDeath;
			if (_engine != null)
			{
				_engine.Buffer.StopIfRunning();
			}
			try
			{
				if (_pets != null)
				{
					_pets.Stop(HotReloading);
				}
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
			_pets = null;
			_instance = null;
			if (_view != null)
			{
				_view.Dispose();
			}
			_view = null;
			if (_mini != null)
			{
				_mini.Dispose();
			}
			if (_dayNight != null)
			{
				_dayNight.Dispose();
				_dayNight = null;
			}
			try
			{
				if (_itemBar != null)
				{
					_itemBar.Dispose();
				}
			}
			catch
			{
			}
			try
			{
				GiveWindow.Dispose();
			}
			catch
			{
			}
			try
			{
				UbCmd.Dispose();
			}
			catch
			{
			}
#if RETAIL
			try
			{
				VideoKill.Unhook();
			}
			catch
			{
			}
			try
			{
				NameTags.Stop();
			}
			catch
			{
			}
#endif
			try
			{
				Expr.SaveNow();
			}
			catch
			{
			}
			_itemBar = null;
			try
			{
				if (_bountyHud != null)
				{
					_bountyHud.Dispose();
				}
			}
			catch
			{
			}
			_bountyHud = null;
			LumPopout.Dispose();
			if (BountyTracker.Current == _bounty)
			{
				BountyTracker.Current = null;
			}
			_bounty = null;
			try
			{
				HoverInfo.Dispose();
				Hotkeys.Dispose();
			}
			catch
			{
			}
			_mini = null;
		}
		catch (Exception ex2)
		{
			Util.LogError(ex2);
		}
	}

	// /mt vendor <npc> [/ profile] - a whole visit; "dry" first: report only. /mt vendor stop. Switches: notes, bank, dryrun.
	private void VendorCommand(string args)
	{
		VendorRun vendorRun = _engine?.Vendor;
		if (vendorRun == null)
		{
			return;
		}
		string text = args.ToLowerInvariant();
		if (text.Length == 0)
		{
			Util.WriteToChat("/mt vendor <NPC exact name> [/ profile]  |  /mt vendor dry <NPC> [/ profile]  |  /mt vendor stop  |  /mt vendor auto on|off  |  /mt vendor notes on|off  |  /mt vendor bank on|off  |  /mt vendor dryrun on|off" + ((VendorRun.LastSummary.Length > 0) ? ("\nLast visit: " + VendorRun.LastSummary) : ""));
			return;
		}
		if (text == "stop")
		{
			vendorRun.Abort("stopped by hand");
			return;
		}
		string[] array = new string[4] { "notes", "bank", "dryrun", "auto" };
		foreach (string text2 in array)
		{
			if (text == text2 + " on" || text == text2 + " off")
			{
				bool flag = text.EndsWith(" on");
				if (text2 == "notes")
				{
					_settings.VendorPayWithNotes = flag;
				}
				else if (text2 == "bank")
				{
					_settings.VendorBankChange = flag;
				}
				else if (text2 == "auto")
				{
					_settings.VendorAutoOnOpen = flag;
				}
				else
				{
					_settings.VendorDryRun = flag;
				}
				SaveAll();
				Util.WriteToChat("Vendor: " + ((text2 == "notes") ? "pay with trade notes" : ((text2 == "bank") ? "bank the change into notes" : ((text2 == "auto") ? "auto-vendor when a shop opens" : "dry run"))) + " " + (flag ? "ON" : "OFF") + ".");
				return;
			}
		}
		bool dry = false;
		if (text.StartsWith("dry "))
		{
			dry = true;
			args = args.Substring(4).Trim();
		}
		string npc = args;
		string profile = "";
		int num = args.IndexOf('/');
		if (num >= 0)
		{
			npc = args.Substring(0, num).Trim();
			profile = args.Substring(num + 1).Trim();
		}
		vendorRun.Start(npc, profile, dry);
	}

	private void SaveAll()
	{
		DateTime now = DateTime.Now;
		if (_saveFirstAt == DateTime.MinValue)
		{
			_saveFirstAt = now;
		}
		_saveDueAt = now.AddMilliseconds(700.0);
		if ((_saveDueAt - _saveFirstAt).TotalSeconds > 3.0)
		{
			_saveDueAt = _saveFirstAt.AddSeconds(3.0);
		}
	}

	private void SaveAllFlush()
	{
		_saveDueAt = DateTime.MinValue;
		_saveFirstAt = DateTime.MinValue;
		string text = CharKey();
		if (_settings != null && text.IndexOf("LoginNotComplete", StringComparison.OrdinalIgnoreCase) < 0)
		{
			// (never under another character's name than the one these settings were loaded for: loaded before the
			// character's name was known, they're someone else's - or nobody's - and saving them would wipe the real ones)
			if (_loadedKey != null && !string.Equals(_loadedKey, text, StringComparison.OrdinalIgnoreCase))
			{
				if (!_keyWarned)
				{
					_keyWarned = true;
					Util.WriteToChat("Settings NOT saved: they were loaded for '" + _loadedKey + "' but this is '" + text + "'. Relog so this character's own settings load.");
				}
				return;
			}
			_settings.Save(text);
		}
	}

	private void OnRenderFrame(object sender, EventArgs e)
	{
		if (_engine == null || !_loggedIn)
		{
			return;
		}
		Perf.Frame();
		if (_pruneNote != null)
		{
			Util.WriteToChat(_pruneNote);
			_pruneNote = null;
		}
		long t = Perf.Begin();
		if (_saveDueAt != DateTime.MinValue && DateTime.Now >= _saveDueAt)
		{
			try
			{
				SaveAllFlush();
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
			t = Perf.Lap("Settings save", t);
		}
		_engine.Tier.Tick();
		t = Perf.Lap("Tier watch", t);
		try
		{
			BadItems.Tick();
		}
		catch (Exception ex2)
		{
			Util.LogError(ex2);
		}
		try
		{
			SettingsTools.NavTick();
		}
		catch (Exception ex3)
		{
			Util.LogError(ex3);
		}
		try
		{
			PackOrganizer.Tick(!_settings.MasterEnabled || ((!_settings.CombatEnabled || _engine.CalmNow) && !_engine.Looter.Busy && !_engine.Buffer.Busy));
		}
		catch (Exception ex4)
		{
			Util.LogError(ex4);
		}
		t = Perf.Lap("Pack organizer", t);
		try
		{
			CorpseKillers.Tick();
		}
		catch
		{
		}
		t = Perf.Lap("Corpse killers", t);
		try
		{
			Session.Tick();
		}
		catch
		{
		}
		t = Perf.Lap("Session", t);
		if (ServerMode.Ilt)
		{
			try
			{
				if (_bounty != null)
				{
					_bounty.Tick();
				}
			}
			catch (Exception ex5)
			{
				Util.LogError(ex5);
			}
		}
		else
		{
			try
			{
				if (BountyHud.Current != null && BountyHud.Current.Visible)
				{
					BountyHud.Current.Visible = false;
				}
			}
			catch
			{
			}
		}
		t = Perf.Lap("Bounty", t);
		try
		{
			LiveSettings.Tick();
		}
		catch (Exception ex6)
		{
			Util.LogError(ex6);
		}
		t = Perf.Lap("Live settings", t);
		try
		{
			Notes.Tick();
		}
		catch (Exception ex7)
		{
			Util.LogError(ex7);
		}
		t = Perf.Lap("Notes", t);
		try
		{
			FellowManager.Tick();
		}
		catch
		{
		}
		t = Perf.Lap("Fellowship", t);
		try
		{
			Dispel.Tick();
		}
		catch
		{
		}
		t = Perf.Lap("Dispel", t);
		try
		{
			UbProbe.Tick();
		}
		catch
		{
		}
		t = Perf.Lap("UB probe", t);
		try
		{
			Locations.Tick();
		}
		catch
		{
		}
		t = Perf.Lap("Locations", t);
		try
		{
			if (PetSummoner.ExternalLoaded)
			{
				SyncPetState();
			}
		}
		catch
		{
		}
		t = Perf.Lap("Pet sync", t);
		try
		{
			if (_pets != null)
			{
				_pets.Tick();
			}
			_breeding?.Tick();
		}
		catch (Exception ex8)
		{
			Util.LogError(ex8);
		}
		t = Perf.Lap("Pet summoner", t);
		try
		{
			MemWatch.Tick(_settings, _engine);
			Backups.Tick(Util.BasePath, Backups.PluginData);   // (settings, profiles, metas - into Backup\, now and then)
			IdMigrate.Tick(_settings, SaveAll);
		}
		catch (Exception ex9)
		{
			Util.LogError(ex9);
		}
		try
		{
			MaxHpWatch.Tick(_settings, _engine);
		}
		catch (Exception ex10)
		{
			Util.LogError(ex10);
		}
#if RETAIL
		try
		{
			UbLootWatchFix.Tick(_settings);
		}
		catch (Exception exLw)
		{
			Util.LogError(exLw);
		}
#endif
		try
		{
			if (_mini != null)
			{
				_mini.Sync();
			}
		}
		catch
		{
		}
		try
		{
			if (_dayNight != null)
			{
				_dayNight.Sync();
			}
		}
		catch
		{
		}
		if (_loggedIn && (DateTime.Now - _idleSetAt).TotalMinutes > 10.0)
		{
			NoIdleLogout();
		}
		try
		{
			if (_itemBar != null)
			{
				_itemBar.Tick();
			}
		}
		catch (Exception ex11)
		{
			Util.LogError(ex11);
		}
		UbCmd.Tick();
#if RETAIL
		try
		{
			VideoKill.Tick(_settings);
		}
		catch (Exception exVk)
		{
			Util.LogError(exVk);
		}
		try
		{
			NameTags.Tick(_settings);
		}
		catch (Exception exNt)
		{
			Util.LogError(exNt);
		}
#endif
		try
		{
			if (UbExpr.Own)
			{
				Expr.Tick();
			}
		}
		catch (Exception ex12)
		{
			Util.LogError(ex12);
		}
		t = Perf.Lap("Memory watch", t);
		try
		{
			// (a rebuff asked for by hand - Rebuff now, /mbuff buff, the phone - runs with MelkTank off too)
			if (_settings.MasterEnabled || _engine.Buffer.ManualRunning)
			{
				_engine.Buffer.Tick();
			}
		}
		catch (Exception ex13)
		{
			Util.LogError(ex13);
		}
		t = Perf.Lap("Buffer", t);
		_engine.OnRenderFrame();
		t = Perf.Lap("Combat engine", t);
		try
		{
			_engine.Nav.RecordTick();
			_engine.Nav.ChamberTick();
			Catcher.Tick();
		}
		catch (Exception ex14)
		{
			Util.LogError(ex14);
		}
		t = Perf.Lap("Nav record / chamber / catcher", t);
		try
		{
			HoverInfo.Tick();
		}
		catch
		{
		}
		t = Perf.Lap("Hover info", t);
		try
		{
			Dex.FrameTick();
		}
		catch
		{
		}
		t = Perf.Lap("Dex", t);
		try
		{
			ItemTracker.Tick(_current);
		}
		catch
		{
		}
		t = Perf.Lap("Item tracker", t);
		try
		{
			GearSnap.Tick();
		}
		catch
		{
		}
		t = Perf.Lap("Gear snapshot", t);
		try
		{
			ArmorCompare.ZoneTick();
		}
		catch (Exception ex15)
		{
			Util.LogError(ex15);
		}
		t = Perf.Lap("Armor compare", t);
		try
		{
			_engine.Nav.MetaTick();
		}
		catch (Exception ex16)
		{
			Util.LogError(ex16);
		}
		t = Perf.Lap("Metas", t);
		try
		{
			_engine.Nav.SteerFrame();
		}
		catch (Exception ex17)
		{
			Util.LogError(ex17);
		}
		t = Perf.Lap("Nav steering", t);
	}

	private void OnStatusBoxMessage(object sender, StatusTextInterceptEventArgs e)
	{
		try
		{
			if (_engine != null && e.Text != null)
			{
				_engine.Mana.OnChat(e.Text);
			}
		}
		catch
		{
		}
		try
		{
			if (_engine != null && e.Text != null && (e.Text.IndexOf("lock", StringComparison.OrdinalIgnoreCase) >= 0 || e.Text.IndexOf("complete this quest again", StringComparison.OrdinalIgnoreCase) >= 0))
			{
				_engine.Looter.OnChat(e.Text);
				_engine.Nav.OnDoorChat(e.Text);
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		try
		{
			if (!e.Eat && ChatFilters.MatchesStatus(_settings, e.Text))
			{
				e.Eat = true;
			}
		}
		catch (Exception ex2)
		{
			Util.LogError(ex2);
		}
	}

	// a [Pet] line put back with commas: shown as it is, not read again (the original was read)
	private static string _ownRepost;
	private static DateTime _ownRepostAt;

	private static readonly System.Text.RegularExpressions.Regex PetNumRx = new System.Text.RegularExpressions.Regex("(?<![\\d,.])\\d{4,}(?![\\d,.])");

	/// <summary>A [Pet] hit line with commas in its numbers (null: nothing to change).</summary>
	private static string PetCommas(string text)
	{
		if (text == null || !text.StartsWith("[Pet]", StringComparison.Ordinal)) return null;
		int at = text.IndexOf(" for ", StringComparison.Ordinal);
		if (at < 0) return null;
		string tail = PetNumRx.Replace(text.Substring(at), m => long.TryParse(m.Value, out long n) ? n.ToString("N0", System.Globalization.CultureInfo.InvariantCulture) : m.Value);
		string line = text.Substring(0, at) + tail;
		return line == text ? null : line;
	}

	private void OnChatBoxMessage(object sender, ChatTextInterceptEventArgs e)
	{
		if (_ownRepost != null && (DateTime.Now - _ownRepostAt).TotalSeconds < 1.0 && e.Text != null && e.Text.TrimEnd('\r', '\n') == _ownRepost)
		{
			_ownRepost = null;
			return;
		}
		try
		{
			OnChatBoxMessageInner(e);
		}
		finally
		{
			try
			{
				if (!e.Eat && _settings != null && _settings.PetDmgCommas)
				{
					string line = PetCommas(e.Text?.TrimEnd('\r', '\n'));
					if (line != null)
					{
						e.Eat = true;
						_ownRepost = line;
						_ownRepostAt = DateTime.Now;
						Globals.Host.Actions.AddChatText(line, e.Color, e.Target);
					}
				}
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
		}
	}

	private void OnChatBoxMessageInner(ChatTextInterceptEventArgs e)
	{
		try
		{
			if (_engine == null)
			{
				return;
			}
			if (_engine.Tier.OnChat(e.Text))
			{
				e.Eat = true;
				return;
			}
			if (_engine.Buffer.OnChat(e.Text))
			{
				e.Eat = true;
				return;
			}
			bool flag = false;
			try
			{
				if (_bounty != null)
				{
					flag = _bounty.OnChat(e.Text);
				}
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
			try
			{
				if (_pets != null)
				{
					_pets.OnChat(e.Text);
					LearnPetOnly(e.Text);
					_breeding?.OnChat(e.Text);
				}
			}
			catch
			{
			}
			try
			{
				if (Dex.OnChat(e.Text))
				{
					e.Eat = true;
					return;
				}
			}
			catch (Exception ex2)
			{
				Util.LogError(ex2);
			}
			_engine.OnChat(e.Text);
			try
			{
				_engine.Nav.OnChamberChat(e.Text);
			}
			catch
			{
			}
			try
			{
				_engine.Nav.OnDoorChat(e.Text);
			}
			catch
			{
			}
			try
			{
				_engine.Nav.MetaChat(e.Text);
			}
			catch
			{
			}
			try
			{
				Charms.OnChat(e.Text);
			}
			catch
			{
			}
			try
			{
				QbStamps.OnChat(e.Text);
			}
			catch
			{
			}
			try
			{
				if (_engine != null)
				{
					_engine.Mana.OnChat(e.Text);
				}
			}
			catch
			{
			}
			try
			{
				Session.OnChat(e.Text);
			}
			catch
			{
			}
			try
			{
				FellowManager.OnChat(e.Text);
			}
			catch
			{
			}
			if (flag)
			{
				e.Eat = true;
				return;
			}
			try
			{
				if (Session.Quiet(e.Text))
				{
					e.Eat = true;
					return;
				}
			}
			catch
			{
			}
			try
			{
				if (ExprQuests.OnChat(e.Text))
				{
					e.Eat = true;
					return;
				}
			}
			catch
			{
			}
			if (ChatFilter.Matches(e.Text))
			{
				e.Eat = true;
			}
			else if (ChatFilters.Matches(_settings, e.Text))
			{
				e.Eat = true;
			}
		}
		catch (Exception ex3)
		{
			Util.LogError(ex3);
		}
	}

	private void OnClientMessage(object sender, NetworkMessageEventArgs e)
	{
		try
		{
			Locations.OnClientMessage(e.Message);
		}
		catch
		{
		}
		try
		{
			if (e.Message != null)
			{
				BookReader.OnClientMessage(e.Message.RawData);
			}
		}
		catch
		{
		}
		try
		{
			if (e.Message != null && e.Message.Type == 63059)
			{
				Remote.LogoffAsked();
			}
		}
		catch
		{
		}
	}

	private void OnServerMessage(object sender, NetworkMessageEventArgs e)
	{
		try
		{
			Remote.NoteServerMessage();
			try
			{
				if (e.Message != null && e.Message.Type == 63408)
				{
					PackOrganizer.OnServerMessage(e.Message.Type, e.Message.RawData);
				}
			}
			catch
			{
			}
			try
			{
				if (e.Message != null)
				{
					BookReader.OnServerMessage((uint)e.Message.Type, e.Message.RawData);
				}
			}
			catch
			{
			}
			if (_engine == null || e.Message == null)
			{
				return;
			}
			try
			{
				CorpseKillers.OnServerMessage(e.Message);
			}
			catch
			{
			}
			try
			{
				Session.OnServerMessage(e.Message);
			}
			catch
			{
			}
			try
			{
				BadItems.OnServerMessage(e.Message);
			}
			catch
			{
			}
			try
			{
				_engine.Compare.OnServerMessage(e.Message);
			}
			catch
			{
			}
			try
			{
				_engine.Dots.OnServerMessage(e.Message);
			}
			catch
			{
			}
			try
			{
				Dex.OnServerMessage(e.Message);
			}
			catch
			{
			}
			try
			{
				IdInfo.OnServerMessage(e.Message);
			}
			catch
			{
			}
			try
			{
				Healer.OnServerMessage(e.Message);
			}
			catch
			{
			}
			try
			{
				Expr.OnServerMessage(e.Message);
			}
			catch
			{
			}
			try
			{
				if (WeaponCompare.ReadHealthAny(e.Message, out var obj12, out var cur, out var max))
				{
					MonsterMatch.MaxHealth[obj12] = max;
					MonsterDb.Learn(obj12, max);
					CombatEngine.NoteHealth(obj12, cur, max);
				}
			}
			catch
			{
			}
			if (!_engine.Healer.Active || e.Message.Type != 63408)
			{
				return;
			}
			string text = null;
			try
			{
				for (int i = 0; i < e.Message.Count; i++)
				{
					if (text != null)
					{
						break;
					}
					if (e.Message[i] is string text2 && text2.IndexOf("full health", StringComparison.OrdinalIgnoreCase) >= 0)
					{
						text = text2;
					}
				}
			}
			catch
			{
			}
			if (text == null)
			{
				byte[] rawData = e.Message.RawData;
				if (rawData != null && rawData.Length < 4096)
				{
					string text3 = Encoding.GetEncoding(28591).GetString(rawData);
					if (text3.IndexOf("full health", StringComparison.OrdinalIgnoreCase) >= 0)
					{
						text = text3;
					}
				}
			}
			if (text != null)
			{
				string text4 = Core.CharacterFilter.Name ?? "";
				if (text4.Length <= 0 || text.IndexOf(text4, StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("You are", StringComparison.OrdinalIgnoreCase) >= 0)
				{
					_engine.Healer.AlreadyFull();
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void OnPortal(object sender, ChangePortalModeEventArgs e)
	{
		try
		{
			if (_engine != null)
			{
				_engine.Looter.NotePortal();
			}
		}
		catch
		{
		}
		try
		{
			if (_engine != null && e.Type == PortalEventType.EnterPortal)
			{
				_engine.Nav.NotePortalEnter();
			}
		}
		catch
		{
		}
		try
		{
			if (_bounty != null && e.Type == PortalEventType.ExitPortal)
			{
				_bounty.AreaChanged();
			}
		}
		catch
		{
		}
		try
		{
			if (_engine != null && e.Type == PortalEventType.ExitPortal)
			{
				_engine.Tier.OnPortalExit();
				_engine.Healer.NotePortal();
				_engine.Areas.Reset();
				_engine.Nav.NotePortalExit();
				Locations.OnPortalExit();
				Remote.WriteStatusSoon();
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void OnReleaseObject(object sender, ReleaseObjectEventArgs e)
	{
		try
		{
			if (_engine != null && e.Released.ObjectClass == ObjectClass.Corpse)
			{
				_engine.Looter.CorpseReleased(e.Released.Id, CombatEngine.Distance(e.Released));
			}
		}
		catch
		{
		}
		try
		{
			TrackedMonster value = null;
			if (_engine != null)
			{
				_engine.Tracked.TryGetValue(e.Released.Id, out value);
			}
			Session.ObjectGone(e.Released, value);
		}
		catch
		{
		}
		try
		{
			if (_engine != null)
			{
				_engine.OnObjectReleased(e.Released.Id);
			}
		}
		catch
		{
		}
		try
		{
			CorpseKillers.OnReleased(e.Released.Id);
		}
		catch
		{
		}
	}

	private void OnChangeObject(object sender, ChangeObjectEventArgs e)
	{
		try
		{
			// MelkTank's own appraisals (combat, loot, compare, pets...) aren't announced in chat - only the player's are.
			bool ours = e.Change == WorldChangeType.IdentReceived && Util.TakeOurId(e.Changed.Id);
			if (e.Change == WorldChangeType.IdentReceived)
			{
				ArmorCompare.NoteFullMods(e.Changed);
				GearSnap.OnIdentified(e.Changed.Id);
			}
			if (_engine != null && e.Change == WorldChangeType.IdentReceived && !CorpseKillers.OnIdentified(e.Changed.Id))
			{
				_engine.Looter.OnIdentified(e.Changed.Id, ours);
			}
			if (e.Change == WorldChangeType.IdentReceived && !ours)
			{
				IdInfo.OnIdentified(e.Changed.Id);
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void OnDeath(object sender, DeathEventArgs e)
	{
		try
		{
			if (_settings != null && _engine != null)
			{
				List<string> list = new List<string>();
				if (_settings.DeathStopCombat && _settings.CombatEnabled)
				{
					_settings.CombatEnabled = false;
					_engine.ReleaseNav();
					list.Add("combat");
				}
				if (_settings.DeathStopBuff && _settings.MelksBufferEnabled)
				{
					_settings.MelksBufferEnabled = false;
					_engine.Buffer.SetEnabled(on: false, quiet: true);
					list.Add("buffing");
				}
				_engine.Buffer.StopIfRunning();
				if (_settings.DeathStopLoot && _settings.LootEnabled)
				{
					_settings.LootEnabled = false;
					_engine.Looter.Abort("died");
					list.Add("looting");
				}
				if (_settings.DeathStopPet && _settings.MelksPetEnabled)
				{
					_settings.MelksPetEnabled = false;
					OnPetToggled(on: false);
					list.Add("summoning");
				}
				SaveAll();
				try
				{
					_engine.Nav.NoteDeath();
				}
				catch
				{
				}
				Remote.NoteDeath();
				Session.NoteDeath();
				Util.WriteToChat("You died" + ((list.Count > 0) ? (" - turned off " + string.Join(", ", list.ToArray()) + ".") : "."));
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void OnChangeEnchantments(object sender, EventArgs e)
	{
		try
		{
			if (_engine != null)
			{
				_engine.Buffer.OnChangeEnchantments(e);
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		try
		{
			Dispel.OnChangeEnchantments(e);
		}
		catch (Exception ex2)
		{
			Util.LogError(ex2);
		}
	}

	private void OnBufferToggled(bool on)
	{
		if (_engine != null)
		{
			_engine.Buffer.SetEnabled(on);
		}
	}

	private void SetBuffing(bool on)
	{
		_settings.MelksBufferEnabled = on;
		if (_settings.MasterEnabled)
		{
			_engine.Buffer.SetEnabled(on);
		}
		else
		{
			Util.WriteToChat("Buffing " + (on ? "ticked" : "unticked") + " - MelkTank is OFF (mini panel), so nothing runs until it's back on.");
		}
		SaveAll();
	}

	internal static void SaveAllNow()
	{
		_instance?.SaveAllFlush();
	}

	internal static string RemoteApply(string action, string feature, string value, string name)
	{
		PluginCore instance = _instance;
		if (instance == null || instance._settings == null || instance._engine == null)
		{
			return "not logged in";
		}
		Settings settings = instance._settings;
		action = (action ?? "").Trim().ToLowerInvariant();
		feature = (feature ?? "").Trim().ToLowerInvariant();
		bool flag = string.Equals((value ?? "").Trim(), "on", StringComparison.OrdinalIgnoreCase) || string.Equals((value ?? "").Trim(), "true", StringComparison.OrdinalIgnoreCase);
		string text;
		switch (action)
		{
		case "refresh":
			return "refresh";
		case "set":
			switch (feature)
			{
			case "master":
				if (instance._mini != null)
				{
					instance._mini.SetMaster(flag);
				}
				else
				{
					settings.MasterEnabled = flag;
				}
				break;
			case "combat":
				settings.CombatEnabled = flag;
				if (!flag)
				{
					instance._engine.ReleaseNav();
				}
				break;
			case "nav":
				settings.NavEnabled = flag;
				if (!flag)
				{
					instance._engine.Nav.Stop();
				}
				break;
			case "loot":
				settings.LootEnabled = flag;
				if (!flag)
				{
					instance._engine.Looter.Abort("off");
				}
				break;
			case "summon":
				settings.MelksPetEnabled = flag;
				if (settings.MasterEnabled)
				{
					instance.OnPetToggled(flag);
				}
				break;
			case "buff":
				instance.SetBuffing(flag);
				break;
			case "debug":
				settings.DebugLog = flag;
				break;
			case "meta":
				if (flag)
				{
					instance._engine.Nav.MetaStart();
				}
				else
				{
					instance._engine.Nav.MetaStop();
				}
				break;
			default:
				return "unknown feature '" + feature + "'";
			}
			text = feature + " " + (flag ? "ON" : "OFF");
			break;
		case "navroute":
		{
			NavRoute navRoute = null;
			foreach (NavRoute navRoute2 in settings.NavRoutes)
			{
				if (string.Equals(navRoute2.Name, (name ?? "").Trim(), StringComparison.OrdinalIgnoreCase))
				{
					navRoute = navRoute2;
				}
			}
			if (navRoute == null)
			{
				return "no nav route named '" + name + "'";
			}
			settings.NavRouteSelected = navRoute.Name;
			settings.NavMode = 1;
			instance._engine.Nav.Stop();
			instance._engine.Nav.RouteReset();
			text = "nav route " + navRoute.Name;
			break;
		}
		case "metaload":
		{
			bool metaRunning = instance._engine.Nav.MetaRunning;
			if (!instance._engine.Nav.LoadMetaByName((name ?? "").Trim()))
			{
				return "no meta named '" + name + "'";
			}
			if (metaRunning)
			{
				instance._engine.Nav.MetaStart();
			}
			text = "meta " + name + (metaRunning ? " (running)" : " (loaded - turn Meta on to run it)");
			break;
		}
		case "navfile":
			text = instance._engine.Nav.SyncRouteFile(name, ((value ?? "").ToLowerInvariant() == "deleted") ? "deleted" : "changed", feature);
			break;
		case "metafile":
			text = instance._engine.Nav.SyncMetaFile(name);
			break;
		case "navspot":
		{
			NavSpot navSpot = null;
			foreach (NavSpot navSpot2 in settings.NavSpots)
			{
				if (string.Equals(navSpot2.Name, (name ?? "").Trim(), StringComparison.OrdinalIgnoreCase))
				{
					navSpot = navSpot2;
				}
			}
			if (navSpot == null)
			{
				return "no nav spot named '" + name + "'";
			}
			settings.NavSelected = navSpot.Name;
			settings.NavMode = 0;
			instance._engine.Nav.Stop();
			text = "nav spot " + navSpot.Name;
			break;
		}
		default:
			return "unknown action '" + action + "'";
		}
		instance.SaveAll();
		Util.WriteToChat("Phone: " + text + ".");
		return text;
	}

	public static void BuffCommand(string text)
	{
		try
		{
			PluginCore instance = _instance;
			if (instance != null && instance._engine != null && !string.IsNullOrEmpty(text))
			{
				instance._engine.Buffer.ProcessCommand(text.Trim().Split(new char[1] { ' ' }, StringSplitOptions.RemoveEmptyEntries), instance.SetBuffing);
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static bool ActionInProgress()
	{
		PluginCore instance = _instance;
		try
		{
			return instance != null && instance._engine != null && instance._engine.ActionInProgress;
		}
		catch
		{
			return false;
		}
	}

	public static void SetSummoningFromNav(bool on)
	{
		PluginCore instance = _instance;
		if (instance != null && instance._settings != null && instance._settings.MelksPetEnabled != on)
		{
			instance._settings.MelksPetEnabled = on;
			if (instance._settings.MasterEnabled)
			{
				instance.OnPetToggled(on);
			}
			instance.SaveAll();
		}
	}

	public static void SetBuffingFromUi(bool on)
	{
		PluginCore instance = _instance;
		if (instance != null && instance._engine != null)
		{
			instance.SetBuffing(on);
		}
	}

	private void OnPetToggled(bool on)
	{
		_petCommandAt = DateTime.Now;
		if (PetSummoner.ExternalLoaded)
		{
			Util.Command(on ? "/mpets on" : "/mpets off");
		}
	}

	private void SyncPetState()
	{
		if ((DateTime.Now - _petPolledAt).TotalSeconds < 1.0)
		{
			return;
		}
		_petPolledAt = DateTime.Now;
		bool? petLastSeen = ReadPetEnabled();
		if (petLastSeen.HasValue)
		{
			bool flag = _petLastSeen.HasValue && _petLastSeen.Value != petLastSeen.Value;
			_petLastSeen = petLastSeen;
			if (flag && _settings.MasterEnabled && !((DateTime.Now - _petCommandAt).TotalSeconds < 3.0) && _settings.MelksPetEnabled != petLastSeen.Value)
			{
				_settings.MelksPetEnabled = petLastSeen.Value;
				SaveAll();
			}
		}
	}

	private bool? ReadPetEnabled()
	{
		try
		{
			if (!_petLookedUp)
			{
				_petLookedUp = true;
				Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
				foreach (Assembly assembly in assemblies)
				{
					Type type = assembly.GetType("MelksPetSummoner.PluginCore");
					if (!(type == null))
					{
						_petInstField = type.GetField("_instance", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
						_petEnabledField = type.GetField("_enabled", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
						break;
					}
				}
			}
			if (_petInstField == null || _petEnabledField == null)
			{
				return null;
			}
			object value = _petInstField.GetValue(null);
			if (value == null)
			{
				_petLookedUp = false;
				return null;
			}
			return (bool)_petEnabledField.GetValue(value);
		}
		catch
		{
			return null;
		}
	}

	private static bool MagToolsLoaded()
	{
		bool flag = true;
		return false;
	}

	private static void Rollback()
	{
		try
		{
			string text = Util.FullPath("MelkTankCore.dll");
			string text2 = Util.FullPath("MelkTankCore.old.dll");
			string text3 = Util.FullPath("MelkTankCore.swap.dll");
			if (!File.Exists(text2))
			{
				Util.WriteToChat("Rollback: there's no previous build (MelkTankCore.old.dll).");
				return;
			}
			DateTime lastWriteTime = File.GetLastWriteTime(text);
			DateTime lastWriteTime2 = File.GetLastWriteTime(text2);
			if (File.Exists(text3))
			{
				File.Delete(text3);
			}
			File.Move(text, text3);
			try
			{
				File.Move(text2, text);
			}
			catch
			{
				File.Move(text3, text);
				throw;
			}
			File.Move(text3, text2);
			Util.WriteToChat("Rollback: going back to the build of " + lastWriteTime2.ToString("MMM d HH:mm:ss") + " (from " + lastWriteTime.ToString("MMM d HH:mm:ss") + ") - it loads in a few seconds. /mtank rollback again undoes it.");
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			Util.WriteToChat("Rollback failed: " + ex.Message);
		}
	}

	private void OnCommandLineText(object sender, ChatParserInterceptEventArgs e)
	{
		string text = e.Text.Trim();
		try
		{
			if (_bounty != null)
			{
				_bounty.Expect(text);
			}
		}
		catch
		{
		}
		if (text.StartsWith("/mbuff", StringComparison.OrdinalIgnoreCase) || text.StartsWith("@mbuff", StringComparison.OrdinalIgnoreCase))
		{
			e.Eat = true;
			BuffCommand(text);
			return;
		}
		if ((text.StartsWith("/mpets", StringComparison.OrdinalIgnoreCase) || text.StartsWith("@mpets", StringComparison.OrdinalIgnoreCase)) && !PetSummoner.ExternalLoaded)
		{
			e.Eat = true;
			if (_pets != null)
			{
				_pets.Command(text);
			}
			return;
		}
		if ((text.StartsWith("/ub ", StringComparison.OrdinalIgnoreCase) || text.StartsWith("@ub ", StringComparison.OrdinalIgnoreCase)) && UbCmd.Try(text))
		{
			e.Eat = true;
			return;
		}
		if ((text.StartsWith("/vt jump", StringComparison.OrdinalIgnoreCase) || text.StartsWith("@vt jump", StringComparison.OrdinalIgnoreCase)) && _engine != null && _engine.Nav.VtCommand(text))
		{
			e.Eat = true;
			return;
		}
		if ((text.StartsWith("/vt ", StringComparison.OrdinalIgnoreCase) || text.StartsWith("@vt ", StringComparison.OrdinalIgnoreCase)) && _engine != null && _engine.Nav.MetaRunning && _settings != null && (_settings.VtCommands || true) && _engine.Nav.VtCommand(text))
		{
			e.Eat = true;
			return;
		}
		if (string.Equals(text, "/mt", StringComparison.OrdinalIgnoreCase) || text.StartsWith("/mt ", StringComparison.OrdinalIgnoreCase) || text.StartsWith("@mt ", StringComparison.OrdinalIgnoreCase))
		{
			string text2 = ((text.Length > 3) ? text.Substring(3).Trim() : "");
			if (text2.Length > 0 && UbCmd.Try("/ub " + text2, ours: true))
			{
				e.Eat = true;
				return;
			}
			if (text2.Length > 0 && _engine != null && _engine.Nav.MtCommand("/mt " + text2))
			{
				e.Eat = true;
				return;
			}
			if (MagToolsLoaded())
			{
				return;
			}
			text = "/mtank" + ((text2.Length > 0) ? (" " + text2) : "");
		}
		if (!text.StartsWith("/mtank", StringComparison.OrdinalIgnoreCase))
		{
			return;
		}
		e.Eat = true;
		if (_settings == null)
		{
			return;
		}
		string text3 = ((text.Length > 6) ? text.Substring(6).Trim() : "");
		string text4 = text3.ToLowerInvariant();
		if (text4 == "vendor" || text4.StartsWith("vendor "))
		{
			VendorCommand(text3.Substring(6).Trim());
			return;
		}
		if (text4.StartsWith("credits"))
		{
			Util.WriteToChat("MelkTank: " + Session.SetGemCredits(text3.Substring(7).Trim()));
			return;
		}
		switch (text4)
		{
		case "rollback":
			Rollback();
			break;
		case "giver":
			GiveWindow.Toggle();
			break;
		case "clearbugged":
			BadItems.ScanNow();
			break;
		case "mem":
			Util.WriteToChat("MelkTank: " + Notes.MemText() + ".");
			break;
		case "orgwhy":
			Util.WriteToChat("MelkTank: organize - " + PackOrganizer.Why() + ".");
			break;
		case "markertest":
			if (_engine != null)
			{
				_engine.Nav.MarkerTest();
			}
			break;
		default:
			if (!text4.StartsWith("tuneout "))
			{
				if (text4.StartsWith("expr "))
				{
					string text5 = text3.Substring(5).Trim();
					object obj2 = UbExpr.Eval(text5, out var error);
					Util.WriteToChat("Expr " + text5 + " = " + ((error != null) ? ("error: " + error) : ("[" + ((obj2 == null) ? "null" : obj2.GetType().Name) + "] " + UbExpr.Text(obj2))));
				}
				else if (text4 == "mini" || text4.StartsWith("mini "))
				{
					string text6 = ((text4.Length > 5) ? text4.Substring(5).Trim() : "");
					if (text6 == "reset")
					{
						if (_mini != null)
						{
							_mini.ResetPosition();
						}
					}
					else
					{
						_settings.MiniShow = text6 == "on" || (!(text6 == "off") && !_settings.MiniShow);
					}
					SaveAll();
					Util.WriteToChat("Mini control window " + (_settings.MiniShow ? "shown" : "hidden") + ((text6 == "reset") ? ", moved to the top left" : "") + ".  /mtank mini [on|off|reset]");
				}
				else if (text4 == "bounty")
				{
					Util.WriteToChat((_bounty != null) ? ("Bounty tracker: " + _bounty.StateText()) : "Bounty tracker isn't running.");
				}
				else if (text4 == "set" || text4.StartsWith("set "))
				{
					string[] array = ((text3.Length > 3) ? text3.Substring(3).Trim().Split(new char[1] { ' ' }, 2, StringSplitOptions.RemoveEmptyEntries) : new string[0]);
					if (array.Length < 2)
					{
						Util.WriteToChat("/mtank set [name] [value] - e.g. /mtank set CastRecoveryMs 950 (on/off for switches). /mtank get [part] shows names.");
					}
					else
					{
						Util.WriteToChat("Set: " + SettingsTools.Set(array[0], array[1], ""));
					}
				}
				else if (text4 == "navset" || text4.StartsWith("navset "))
				{
					string[] array2 = ((text3.Length > 6) ? text3.Substring(6).Trim().Split(new char[1] { ' ' }, 2, StringSplitOptions.RemoveEmptyEntries) : new string[0]);
					if (array2.Length < 2)
					{
						Util.WriteToChat("/mtank navset [name] [value] - like /mtank set, but put back when Nav is switched off (for a meta's start state).");
					}
					else
					{
						Util.WriteToChat("Set: " + SettingsTools.NavSet(array2[0], array2[1]));
					}
				}
				else if (text4 == "get" || text4.StartsWith("get "))
				{
					string text7 = ((text3.Length > 3) ? text3.Substring(3).Trim() : "");
					List<string> list = SettingsTools.Get(text7);
					if (list.Count == 0)
					{
						Util.WriteToChat("No setting names contain " + text7 + ".");
						break;
					}
					int num = Math.Min(list.Count, 25);
					for (int i = 0; i < num; i++)
					{
						Util.WriteToChat("  " + list[i]);
					}
					if (list.Count > num)
					{
						Util.WriteToChat("  ... " + (list.Count - num) + " more - narrow it down (/mtank get " + ((text7.Length > 0) ? text7 : "fracture") + ").");
					}
				}
				else if (text4 == "snap" || text4.StartsWith("snap ") || text4 == "snaps")
				{
					string[] array3 = ((text3.Length > 4) ? text3.Substring(4).Trim().Split(new char[1] { ' ' }, 2, StringSplitOptions.RemoveEmptyEntries) : new string[0]);
					string text8 = ((array3.Length != 0) ? array3[0].ToLowerInvariant() : "list");
					string text9 = ((array3.Length > 1) ? array3[1].Trim() : "");
					if (text4 == "snaps")
					{
						text8 = "list";
					}
					switch (text8)
					{
					case "save":
						Util.WriteToChat(SettingsTools.SnapSave(text9, ""));
						break;
					case "restore":
						if (text9.Length == 0)
						{
							Util.WriteToChat("/mtank snap restore [name]");
						}
						else
						{
							Util.WriteToChat(SettingsTools.SnapRestore(text9, ""));
						}
						break;
					case "delete":
						if (text9.Length == 0)
						{
							Util.WriteToChat("/mtank snap delete [name]");
						}
						else
						{
							Util.WriteToChat(SettingsTools.SnapDelete(text9));
						}
						break;
					default:
					{
						List<string> list2 = SettingsTools.SnapList();
						Util.WriteToChat((list2.Count == 0) ? "No settings snapshots yet - /mtank snap save [name]." : ("Snapshots: " + string.Join(", ", list2.ToArray())));
						Util.WriteToChat("/mtank snap save [name] | restore [name] | delete [name] | list");
						break;
					}
					}
				}
				else if (text4 == "note" || text4.StartsWith("note "))
				{
					Notes.Add((text3.Length > 4) ? text3.Substring(4) : "", "");
				}
				else
				{
					if (text4 == "reload" || text4.StartsWith("reload "))
					{
						break;
					}
					if (text4 == "perf")
					{
						Util.WriteToChat(Perf.Summary(8));
						Perf.WriteFile();
						break;
					}
					if (text4 == "enl" || text4.StartsWith("enl "))
					{
						Util.WriteToChat(Session.EnlCommand((text4.Length > 3) ? text4.Substring(4).Trim() : ""));
						break;
					}
					if (text4 == "profiles" || text4 == "profile")
					{
						List<string> list3 = Settings.ListProfiles();
						Util.WriteToChat("Profile: " + ((_settings.ActiveProfile.Length > 0) ? _settings.ActiveProfile : "(this character's list)") + ".  Available: " + ((list3.Count > 0) ? string.Join(", ", list3.ToArray()) : "none yet"));
						break;
					}
					if (text4.StartsWith("profile "))
					{
						string text10 = text3.Substring(8).Trim();
						bool flag = text10.Equals("none", StringComparison.OrdinalIgnoreCase) && Settings.FindProfile(text10) == null;
						if (_settings.SwitchProfile(flag ? "" : text10))
						{
							Util.WriteToChat(flag ? "Using this character's own monster list." : ("Loaded profile '" + _settings.ActiveProfile + "'."));
						}
						break;
					}
					if (text4 == "why" || text4.StartsWith("why "))
					{
						LootWhy.Run((text3.Length > 3) ? text3.Substring(3) : "");
						break;
					}
					if (text4 == "chattest")
					{
						int currentSelection = Core.Actions.CurrentSelection;
						WorldObject worldObject = ((currentSelection == 0) ? null : Core.WorldFilter[currentSelection]);
						string text11 = ((worldObject == null) ? "Test Item" : worldObject.Name);
						string text12 = "<Tell:IIDString:" + currentSelection + ":" + text11 + ">" + text11 + "<\\Tell>";
						Host.Actions.AddChatText("[MelkTank] A link: " + text12 + ", rest of line", 5);
						Host.Actions.AddChatTextRaw("[MelkTank] B raw link: " + text12 + ", rest of line", 5);
						Host.Actions.AddChatText("[MelkTank] C plain: " + text11 + ", rest of line", 5);
						break;
					}
					if (text4 == "colors")
					{
						for (int j = 0; j <= 31; j++)
						{
							Host.Actions.AddChatText("[MelkTank] chat colour " + j, j);
						}
						break;
					}
					if (text4.StartsWith("maproute"))
					{
						_engine.Nav.MapRouteCommand((text3.Length > 8) ? text3.Substring(8) : "");
						break;
					}
					if (text4.StartsWith("travel"))
					{
						_engine.Nav.TravelCommand((text3.Length > 6) ? text3.Substring(6) : "");
						break;
					}
					if (text4.StartsWith("nav load ") || text4.StartsWith("nav spot ") || text4 == "nav clear" || text4.StartsWith("meta load "))
					{
						_engine.Nav.VtCommand("/vt " + text3.Trim());
						break;
					}
					switch (text4)
					{
					case "session reset":
						try
						{
							Session.Reset();
							Util.WriteToChat("Session reset - tracking from here.");
							break;
						}
						catch (Exception ex)
						{
							Util.LogError(ex);
							break;
						}
					case "meta on":
						_engine.Nav.MetaStart();
						break;
					case "meta off":
						_engine.Nav.MetaStop();
						break;
					default:
						if (text4.StartsWith("meta state "))
						{
							_engine.Nav.MetaSetState(text3.Substring(11).Trim(), persistReset: true);
							break;
						}
						if (text4 == "meta")
						{
							Util.WriteToChat(_engine.Nav.MetaRunning ? ("Meta: " + _engine.Nav.CurrentMeta.Name + " running, state " + _engine.Nav.MetaCurState + ".") : "Meta: not running. /mtank meta on | off | state <name>");
							break;
						}
						if (text4 == "all on" || text4 == "all off")
						{
							if (_mini != null)
							{
								_mini.SetMaster(text4 == "all on");
							}
							else
							{
								_settings.MasterEnabled = text4 == "all on";
							}
							SaveAll();
							break;
						}
						if (text4 == "loot rares on" || text4 == "loot rares off" || text4 == "loot rares")
						{
							_settings.LootOnlyRare = ((text4 == "loot rares") ? (!_settings.LootOnlyRare) : (text4 == "loot rares on"));
							SaveAll();
							Util.WriteToChat("Only rares / pristine / ascendant " + (_settings.LootOnlyRare ? "ON" : "OFF") + ".");
							break;
						}
						if (text4 == "loot on" || text4 == "loot off")
						{
							_settings.LootEnabled = text4 == "loot on";
							if (!_settings.LootEnabled)
							{
								_engine.Looter.Abort("off");
							}
							SaveAll();
							Util.WriteToChat("Looting " + (_settings.LootEnabled ? "ON" : "OFF") + ((_settings.LootEnabled && !_engine.Looter.HasProfile) ? " - but no loot profile is picked (Loot tab)." : "."));
							break;
						}
						if (text4 == "buff on" || text4 == "buff off" || text4 == "buffing on" || text4 == "buffing off")
						{
							SetBuffingFromUi(text4.EndsWith(" on"));
							SaveAll();
							Util.WriteToChat("Buffing " + (text4.EndsWith(" on") ? "ON" : "OFF") + ".");
							break;
						}
						if (text4 == "rebuff")
						{
							_engine.Buffer.RebuffNow();
							Util.WriteToChat("Rebuffing now.");
							break;
						}
						if (text4 == "summon on" || text4 == "summon off" || text4 == "pets on" || text4 == "pets off")
						{
							SetSummoningFromNav(text4.EndsWith(" on"));
							SaveAll();
							Util.WriteToChat("Pet summoning " + (text4.EndsWith(" on") ? "ON" : "OFF") + ".");
							break;
						}
						if (text4 == "dismiss on" || text4 == "dismiss off")
						{
							if (PetSummoner.Current != null)
							{
								PetSummoner.Current.UnsummonOnClear = text4 == "dismiss on";
								PetSummoner.Current.Save();
							}
							Util.WriteToChat("Dismiss the pet when nothing's in range: " + (text4 == "dismiss on" ? "ON" : "OFF") + ".");
							break;
						}
						if (text4 == "on" || text4 == "off")
						{
							_settings.CombatEnabled = text4 == "on";
							if (!_settings.CombatEnabled)
							{
								_engine.ReleaseNav();
							}
							SaveAll();
							Util.WriteToChat("Combat " + (_settings.CombatEnabled ? "ON" : "OFF") + ".");
							break;
						}
						switch (text4)
						{
						case "pause":
							Pause("chat");
							Util.WriteToChat("Paused. /mtank resume to continue.");
							break;
						case "resume":
							Resume("chat");
							Util.WriteToChat(IsPaused ? ("Still paused by: " + PausedByText) : "Resumed.");
							break;
						case "status":
							Util.WriteToChat((_settings.CombatEnabled ? "ON" : "OFF") + (IsPaused ? (" (paused by " + PausedByText + ")") : "") + " - " + _engine.Status + " - tracking " + _engine.Tracked.Count + " monster(s).");
							break;
						default:
							Util.WriteToChat("/mt (or /mtank) all on | all off | on | off | meta on | meta off | meta state <name> | meta load <name> | nav load <route> | nav spot <spot> | nav clear | session reset | pause | resume | status | loot on | loot off | loot rares on|off | buff on|off | rebuff | summon on|off | dismiss on|off | vendor [dry] <npc> [/ profile] | vendor stop | vendor auto on|off | vendor notes on|off | vendor bank on|off | vendor dryrun on|off | why [rule] | profiles | profile <name> | profile none | note [text] | set [name] [value] | get [part] | snap save|restore|delete|list [name] | reload | rollback");
							break;
						}
						break;
					}
				}
				break;
			}
			goto case "tuneout";
		case "tuneout":
		{
			string text13 = ((text3.Length > 7) ? text3.Substring(7).Trim() : "");
			if (text13.Length == 0)
			{
				Util.WriteToChat("Left out of tuning: " + (string.IsNullOrEmpty(_settings.TuneOut) ? "none" : _settings.TuneOut.Replace("|", ", ")) + ".  /mtank tuneout <monster> [on|off]");
				break;
			}
			bool? want = null;
			if (text13.EndsWith(" on", StringComparison.OrdinalIgnoreCase))
			{
				want = true;
				text13 = text13.Substring(0, text13.Length - 3).Trim();
			}
			else if (text13.EndsWith(" off", StringComparison.OrdinalIgnoreCase))
			{
				want = false;
				text13 = text13.Substring(0, text13.Length - 4).Trim();
			}
			bool flag2 = PackStats.SetOut(text13, want);
			Util.WriteToChat(text13 + (flag2 ? " is left out of the packs / tuning numbers." : " counts in the packs / tuning numbers again."));
			break;
		}
		}
	}
}
