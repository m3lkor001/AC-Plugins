using System;
using System.Collections.Generic;
using Decal.Adapter.Wrappers;

namespace MelkTank;

/// <summary>
/// ACGodot gave a server's items ids of its own making (0x6....... - the server's number with its top digit changed), so
/// the items listed in the game's own client (by the server's number) all showed as missing there, and ones added there
/// were missing in the game's client. It now uses the server's number like the game's client does; this turns any ids
/// saved in the old form into the real ones, once the pack is known, so nothing has to be added a third time.
/// </summary>
public static class IdMigrate
{
	private static DateTime _until = DateTime.MinValue;

	private static DateTime _next = DateTime.MinValue;

	private static bool _done;

	private static bool Old(int id)
	{
		return (unchecked((uint)id) & 0xF0000000u) == 0x60000000u;
	}

	public static void Tick(Settings s, Action save)
	{
		if (_done || s == null)
		{
			return;
		}
		DateTime now = DateTime.Now;
		if (now < _next)
		{
			return;
		}
		_next = now.AddSeconds(5.0);
		bool any = Old(s.HealKitId) || Old(s.ManaItemId) || Old(s.StaminaItemId);
		foreach (WeaponItem item in s.Items)
		{
			any |= Old(item.Id);
		}
		if (!any)
		{
			_done = true;
			return;
		}
		List<WorldObject> inv;
		try
		{
			inv = InvCache.All();
		}
		catch
		{
			return;
		}
		if (inv == null || inv.Count == 0)
		{
			return;
		}
		// (the pack comes in over the first moments in the world: looked at for a minute from when it's first seen)
		if (_until == DateTime.MinValue)
		{
			_until = now.AddSeconds(60.0);
		}
		Dictionary<uint, int> real = new Dictionary<uint, int>();
		foreach (WorldObject o in inv)
		{
			if (!Old(o.Id))
			{
				real[unchecked((uint)o.Id) & 0x0FFFFFFFu] = o.Id;
			}
		}
		int changed = 0;
		int Fix(int id)
		{
			if (Old(id) && real.TryGetValue(unchecked((uint)id) & 0x0FFFFFFFu, out var r))
			{
				changed++;
				return r;
			}
			return id;
		}
		s.HealKitId = Fix(s.HealKitId);
		s.ManaItemId = Fix(s.ManaItemId);
		s.StaminaItemId = Fix(s.StaminaItemId);
		HashSet<int> have = new HashSet<int>();
		foreach (WeaponItem item in s.Items)
		{
			if (!Old(item.Id))
			{
				have.Add(item.Id);
			}
		}
		for (int i = s.Items.Count - 1; i >= 0; i--)
		{
			WeaponItem w = s.Items[i];
			if (!Old(w.Id))
			{
				continue;
			}
			int n = Fix(w.Id);
			if (n == w.Id)
			{
				continue;
			}
			if (have.Contains(n))
			{
				s.Items.RemoveAt(i);   // (the same item is on the list under its real id too - from the game's own client)
			}
			else
			{
				w.Id = n;
				have.Add(n);
			}
		}
		if (changed > 0)
		{
			Util.WriteToChat("Item list: " + changed + " item id" + ((changed == 1) ? "" : "s") + " saved in ACGodot's old form put right.");
			try
			{
				save?.Invoke();
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
		}
		if (now > _until)
		{
			_done = true;
		}
	}
}
