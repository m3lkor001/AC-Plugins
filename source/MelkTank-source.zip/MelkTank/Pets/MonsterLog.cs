using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using Decal.Adapter.Wrappers;

namespace MelkTank.Pets;

public static class MonsterLog
{
	public static Func<bool> On = () => false;

	public static Action<string> AddToList;

	private static readonly HashSet<string> _seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

	private static readonly Dictionary<int, DateTime> _pending = new Dictionary<int, DateTime>();

	private static DateTime _nextTick = DateTime.MinValue;

	public static void OnMonster(WorldObject obj)
	{
		if (!On() || obj == null || !_seen.Add(obj.Name))
		{
			return;
		}
		try
		{
			if (AddToList != null)
			{
				AddToList(obj.Name);
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		_pending[obj.Id] = DateTime.Now;
		try
		{
			Util.RequestId(obj.Id);
		}
		catch
		{
		}
	}

	public static void Tick()
	{
		if (_pending.Count == 0 || DateTime.Now < _nextTick)
		{
			return;
		}
		_nextTick = DateTime.Now.AddSeconds(1.0);
		List<int> list = new List<int>();
		foreach (KeyValuePair<int, DateTime> item in _pending)
		{
			if ((DateTime.Now - item.Value).TotalMilliseconds >= 1500.0)
			{
				list.Add(item.Key);
			}
		}
		foreach (int item2 in list)
		{
			_pending.Remove(item2);
			WorldObject worldObject = Globals.Core.WorldFilter[item2];
			if (worldObject == null)
			{
				continue;
			}
			try
			{
				int num = 0;
				int num2 = 0;
				int num3 = 0;
				try
				{
					num = worldObject.Values(LongValueKey.Species);
				}
				catch
				{
				}
				try
				{
					num2 = worldObject.Values(LongValueKey.CreatureLevel);
				}
				catch
				{
				}
				try
				{
					num3 = worldObject.Values(LongValueKey.Landblock);
				}
				catch
				{
				}
				string text = "";
				try
				{
					CoordsObject coordsObject = worldObject.Coordinates();
					if (coordsObject != null)
					{
						text = coordsObject.NorthSouth.ToString("0.00", CultureInfo.InvariantCulture) + "," + coordsObject.EastWest.ToString("0.00", CultureInfo.InvariantCulture);
					}
				}
				catch
				{
				}
				string path = Util.FullPath("MelkTank_MonsterNames.csv");
				if (!File.Exists(path))
				{
					Util.AppendShared(path, "time,name,species,level,landblock,ns,ew" + Environment.NewLine);
				}
				Util.AppendShared(path, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ",\"" + worldObject.Name.Replace("\"", "'") + "\"," + ((num != 0) ? num.ToString() : "") + "," + num2 + "," + ((uint)num3 >> 16).ToString("X4") + "," + text + Environment.NewLine);
				ObjectDump.DumpTo("MelkTank_MonsterProbe.txt", worldObject, "Monster log: " + worldObject.Name);
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
		}
	}

	public static void Toggled(bool on)
	{
		if (on)
		{
			_seen.Clear();
			try
			{
				foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
				{
					if (item.ObjectClass == ObjectClass.Monster && item.Name.IndexOf("'s ", StringComparison.Ordinal) < 0)
					{
						OnMonster(item);
					}
				}
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
		}
		Util.WriteToChat("Monster log " + (on ? "on - new monster names go to MelkTank_MonsterNames.csv (a full dump of each in MelkTank_MonsterProbe.txt)." : "off."));
	}
}
