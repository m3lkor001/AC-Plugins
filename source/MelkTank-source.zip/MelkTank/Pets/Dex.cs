using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
#if !RETAIL
using AcClient;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;

namespace MelkTank.Pets;

public static class Dex
{
	public class Entry
	{
		public string Name;

		public bool Normal;

		public bool Shiny;
	}

	public class Species
	{
		public string Name;

		public readonly List<Entry> Entries = new List<Entry>();
	}

	private enum St
	{
		Idle,
		Pets,
		Lower,
		Approach,
		Lens,
		Failed,
		Resonant
	}

	public static class TurnIn
	{
		private enum T
		{
			Off,
			Gem,
			Arrive,
			Give,
			Settle,
			Resonate,
			Book
		}

		private static bool _resOnly;

		private static int _resDone;

		private static int _resTries;

		private static DateTime _nextRes = DateTime.MinValue;

		private static T _t = T.Off;

		private static DateTime _at;

		private static DateTime _sentAt;

		private static int _npc;

		private static int _giving;

		private static int _resId;

		private static int _given;

		private static readonly HashSet<int> _hollowBefore = new HashSet<int>();

		private static readonly Queue<int> _toGive = new Queue<int>();

		private static readonly Queue<int> _toRes = new Queue<int>();

		private static bool _gemTwice;

		public static string Status = "";

		private static bool _busySaid;

		private static bool _returned;

		private static DateTime _nextGive = DateTime.MinValue;

		private static readonly Dictionary<int, int> _tries = new Dictionary<int, int>();

		public static bool Busy => _t != T.Off;

		private static void Go(T t)
		{
			_t = t;
			_at = DateTime.Now;
			_sentAt = DateTime.MinValue;
		}

		public static void Stop()
		{
			_t = T.Off;
			_toGive.Clear();
			_toRes.Clear();
		}

		private static WorldObject Ruggan()
		{
			try
			{
				WorldObject result = null;
				double num = 80.0;
				foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
				{
					string text = (item.Name ?? "").Trim();
					if (text.IndexOf("Ruggan", StringComparison.OrdinalIgnoreCase) >= 0 && text.StartsWith("Prof", StringComparison.OrdinalIgnoreCase) && item.ObjectClass != ObjectClass.Portal && item.ObjectClass != ObjectClass.Gem)
					{
						double num2 = CombatEngine.Distance(item);
						if (num2 >= 0.0 && num2 < num)
						{
							num = num2;
							result = item;
						}
					}
				}
				return result;
			}
			catch
			{
			}
			return null;
		}

		public static void ResonateMainPack()
		{
			if (Busy)
			{
				Util.WriteToChat("Dex: busy - " + Status);
				return;
			}
			if (FindInPack((string n) => n.Equals("Essence Resonator", StringComparison.OrdinalIgnoreCase)) == null)
			{
				Util.WriteToChat("Dex: no Essence Resonator in your pack.");
				return;
			}
			_toRes.Clear();
			int id = Globals.Core.CharacterFilter.Id;
			foreach (WorldObject item in InvCache.All())
			{
				if ((item.Name ?? "").StartsWith("Hollow ", StringComparison.OrdinalIgnoreCase) && item.Container == id)
				{
					_toRes.Enqueue(item.Id);
				}
			}
			if (_toRes.Count == 0)
			{
				Util.WriteToChat("Dex: no Hollow essences in your main pack.");
				return;
			}
			Util.WriteToChat("Dex: Essence Resonator on " + _toRes.Count + " hollow" + ((_toRes.Count == 1) ? "" : "s") + ".");
			_resOnly = true;
			_resId = 0;
			_resDone = 0;
			Go(T.Resonate);
		}

		public static void Start()
		{
			if (Busy)
			{
				Stop();
				Util.WriteToChat("Dex: turn-in stopped.");
				return;
			}
			Pack(force: true);
			if (_siphonedIds.Count == 0)
			{
				Util.WriteToChat("Dex: no siphoned essences to turn in.");
				return;
			}
			_toGive.Clear();
			foreach (int siphonedId in _siphonedIds)
			{
				_toGive.Enqueue(siphonedId);
			}
			_hollowBefore.Clear();
			foreach (WorldObject item in InvCache.All())
			{
				if ((item.Name ?? "").StartsWith("Hollow ", StringComparison.OrdinalIgnoreCase))
				{
					_hollowBefore.Add(item.Id);
				}
			}
			_resOnly = false;
			_resDone = 0;
			_given = 0;
			_gemTwice = false;
			_tries.Clear();
			_giving = 0;
			_nextGive = DateTime.MinValue;
			Util.WriteToChat("Dex: taking " + _toGive.Count + " siphoned essence" + ((_toGive.Count == 1) ? "" : "s") + " to Prof. Ruggan.");
			if (Ruggan() != null)
			{
				Go(T.Give);
			}
			else
			{
				Go(T.Gem);
			}
		}

		public static void OnChat(string t)
		{
			if (Busy)
			{
				if (t.IndexOf("too busy to accept", StringComparison.OrdinalIgnoreCase) >= 0)
				{
					_busySaid = true;
				}
				else if (t.IndexOf("returns a Hollow", StringComparison.OrdinalIgnoreCase) >= 0)
				{
					_returned = true;
				}
			}
		}

		public static bool Tick()
		{
			DateTime now = DateTime.Now;
			switch (_t)
			{
			case T.Gem:
			{
				WorldObject worldObject5 = FindInPack((string n) => n.IndexOf("Camp Ruggan", StringComparison.OrdinalIgnoreCase) >= 0);
				if (worldObject5 == null)
				{
					Util.WriteToChat("Dex: no Camp Ruggan Portal gem in your pack.");
					Stop();
					return false;
				}
				try
				{
					Globals.Core.Actions.UseItem(worldObject5.Id, 0);
				}
				catch (Exception ex3)
				{
					Util.LogError(ex3);
				}
				Status = "Using " + worldObject5.Name;
				Go(T.Arrive);
				return true;
			}
			case T.Arrive:
			{
				WorldObject worldObject6 = Ruggan();
				if (worldObject6 != null && (now - _at).TotalSeconds > 3.0)
				{
					Go(T.Give);
					return true;
				}
				if ((now - _at).TotalSeconds > 12.0 && !_gemTwice && worldObject6 == null)
				{
					_gemTwice = true;
					Go(T.Gem);
					return true;
				}
				if ((now - _at).TotalSeconds > 45.0)
				{
					Util.WriteToChat("Dex: couldn't find Prof. Ruggan after the portal.");
					Stop();
					return false;
				}
				Status = "Portaling to Camp Ruggan";
				return true;
			}
			case T.Give:
			{
				WorldObject worldObject4 = Ruggan();
				if (worldObject4 == null)
				{
					if ((now - _at).TotalSeconds > 10.0)
					{
						Util.WriteToChat("Dex: Prof. Ruggan isn't here.");
						Stop();
						return false;
					}
					return true;
				}
				_npc = worldObject4.Id;
				if (_giving != 0)
				{
					bool flag2 = false;
					try
					{
						foreach (WorldObject item in InvCache.All())
						{
							if (item.Id == _giving)
							{
								flag2 = true;
								break;
							}
						}
					}
					catch
					{
					}
					if (_busySaid & flag2)
					{
						_tries.TryGetValue(_giving, out var value);
						_tries[_giving] = value + 1;
						if (value + 1 < 6)
						{
							_toGive.Enqueue(_giving);
						}
						_giving = 0;
						_busySaid = false;
						_nextGive = now.AddSeconds(2.0);
					}
					else if (!flag2)
					{
						if (!_returned && (now - _sentAt).TotalSeconds < 6.0)
						{
							Status = "Prof. Ruggan is examining it (" + _given + " so far)";
							return true;
						}
						_given++;
						_giving = 0;
						_nextGive = now.AddMilliseconds(600.0);
					}
					else
					{
						if ((now - _sentAt).TotalSeconds < 8.0)
						{
							Status = "Handing essences to " + worldObject4.Name + " (" + _given + " so far)";
							return true;
						}
						_toGive.Enqueue(_giving);
						_giving = 0;
					}
				}
				if (now < _nextGive)
				{
					return true;
				}
				if (_toGive.Count == 0)
				{
					Go(T.Settle);
					return true;
				}
				_giving = _toGive.Dequeue();
				if (Globals.Core.WorldFilter[_giving] == null)
				{
					_giving = 0;
					return true;
				}
				_busySaid = false;
				_returned = false;
				try
				{
					Globals.Core.Actions.GiveItem(_giving, _npc);
				}
				catch (Exception ex2)
				{
					Util.LogError(ex2);
				}
				_sentAt = now;
				Status = "Handing essences to " + worldObject4.Name + " (" + _given + " so far)";
				return true;
			}
			case T.Settle:
				if ((now - _at).TotalSeconds < 3.5)
				{
					Status = "Turn-in done - waiting for the hollows";
					return true;
				}
				_toRes.Clear();
				if (Settings().DexResonator)
				{
					foreach (WorldObject item2 in InvCache.All())
					{
						if ((item2.Name ?? "").StartsWith("Hollow ", StringComparison.OrdinalIgnoreCase) && !_hollowBefore.Contains(item2.Id))
						{
							_toRes.Enqueue(item2.Id);
						}
					}
				}
				_resId = 0;
				Go((_toRes.Count > 0) ? T.Resonate : T.Book);
				return true;
			case T.Resonate:
			{
				if (_resId != 0)
				{
					WorldObject worldObject = Globals.Core.WorldFilter[_resId];
					bool flag = worldObject == null || !(worldObject.Name ?? "").StartsWith("Hollow ", StringComparison.OrdinalIgnoreCase);
					if (!flag && (now - _sentAt).TotalSeconds < 3.0)
					{
						Status = "Essence Resonator on the hollows (" + _toRes.Count + " left)";
						return true;
					}
					if (!flag && ++_resTries < 4)
					{
						WorldObject worldObject2 = FindInPack((string n) => n.Equals("Essence Resonator", StringComparison.OrdinalIgnoreCase));
						if (worldObject2 != null)
						{
							try
							{
								Globals.Core.Actions.ApplyItem(worldObject2.Id, _resId);
							}
							catch
							{
							}
						}
						_sentAt = now;
						return true;
					}
					if (flag)
					{
						_resDone++;
					}
					_resId = 0;
					_nextRes = now.AddMilliseconds(800.0);
				}
				if (now < _nextRes)
				{
					return true;
				}
				if (_toRes.Count == 0)
				{
					Go(T.Book);
					return true;
				}
				WorldObject worldObject3 = FindInPack((string n) => n.Equals("Essence Resonator", StringComparison.OrdinalIgnoreCase));
				if (worldObject3 == null)
				{
					Util.WriteToChat("Dex: no Essence Resonator in your pack.");
					Go(T.Book);
					return true;
				}
				_resId = _toRes.Dequeue();
				_resTries = 0;
				if (Globals.Core.WorldFilter[_resId] == null)
				{
					_resId = 0;
					return true;
				}
				try
				{
					Globals.Core.Actions.ApplyItem(worldObject3.Id, _resId);
				}
				catch (Exception ex)
				{
					Util.LogError(ex);
				}
				_sentAt = now;
				Status = "Essence Resonator on the hollows (" + _toRes.Count + " left)";
				return true;
			}
			case T.Book:
				if (_resOnly)
				{
					Util.WriteToChat("Dex: Essence Resonator used on " + _resDone + " hollow" + ((_resDone == 1) ? "" : "s") + ".");
					_resOnly = false;
					Stop();
					return false;
				}
				AskPetLog();
				_bookAfter = DateTime.Now.AddSeconds(2.0);
				Util.WriteToChat("Dex: turned in " + _given + " essence" + ((_given == 1) ? "" : "s") + ".");
				Dex.Status = "Turned in " + _given;
				_caughtNow.Clear();
				Stop();
				return false;
			default:
				return false;
			}
		}
	}

	public static List<Species> Book = new List<Species>();

	public static DateTime BookAt = DateTime.MinValue;

	private static readonly Dictionary<string, Entry> _byName = new Dictionary<string, Entry>(StringComparer.OrdinalIgnoreCase);

	private static readonly Regex Line = new Regex("^\\[([^\\]]*)\\]\\s*\\[([^\\]]*)\\]\\s*(.+?)\\s*$");

	private static DateTime _packAt = DateTime.MinValue;

	private static readonly HashSet<string> _siphoned = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

	public static readonly Dictionary<string, int> LensCount = new Dictionary<string, int>();

	private static readonly List<int> _siphonedIds = new List<int>();

	public static readonly string[] Lenses = new string[3] { "Flawed Siphon Lens", "Pristine Siphon Lens", "Perfect Siphon Lens" };

	public const string AsheronLens = "Asheron's Lens";

	public const string ResonantLens = "Resonant Lens";

	public static readonly string[] Bats = new string[6] { "Baby Bonk Bat", "Bonk Starter Bat", "Bonk Plus Bat", "Bonk Pro Bat", "Bonk Pro Plus Gold Bat", "Bonk Enterprise Bat" };

	public static readonly int[] BatMax = new int[6] { 10, 50, 100, 500, 1000, 2500 };

	private static readonly Dictionary<string, string> _alias = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

	private static CombatEngine _eng;

	private static readonly HashSet<string> _logged = new HashSet<string>();

	private static St _st = St.Idle;

	private static int _target;

	private static string _base = "";

	private static bool _shiny;

	private static bool _resUsed;

	private static bool _watch;

	private static DateTime _stAt;

	private static DateTime _sentAt;

	private static DateTime _scanAt;

	private static DateTime _idAt;

	private static DateTime _swingAt;

	private static DateTime _swingDone;

	private static DateTime _corrAt;

	private static DateTime _startAt;

	private static bool _swinging;

	private static int _noAnswer;

	private static string _lastLens = "";

	private static readonly HashSet<string> _caughtNow = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

	private static readonly Dictionary<string, DateTime> _skip = new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);

	private static readonly HashSet<int> _doneIds = new HashSet<int>();

	private static int _wanted;

	private static string _qb = "";

	private static string _status = "";

	public static int Tried;

	public static int Caught;

	public static int Enraged;

	private static string _wrongHit;

	private static int _spam;

	private static int _lensId;

	private static bool _tierKnown;

	private static DateTime _noTierSince = DateTime.MinValue;

	private static double _bestPct = 999.0;

	private static DateTime _bestAt = DateTime.MinValue;

	private static bool _protNear;

	private static string _protName = "";

	private static DateTime _protScanAt = DateTime.MinValue;

	private static DateTime _lensAt = DateTime.MinValue;

	private static bool _lensHave;

	private static bool _lensHaveNormal;

	private static bool _hi;

	private static bool _heldNear;

	private static DateTime _heldScanAt = DateTime.MinValue;

	private static Settings _blank;

	private static Dictionary<int, double> _pct = new Dictionary<int, double>();

	private static Dictionary<int, DateTime> _pctAt = new Dictionary<int, DateTime>();

	private static int _idMax;

	private static readonly Regex Hit = new Regex("^(?:Critical hit!\\s*)?You \\w+ (.+?) for ([\\d,]+) points?", RegexOptions.IgnoreCase);

	public static readonly HashSet<string> PetLog = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

	public static DateTime PetLogAt = DateTime.MinValue;

	private static readonly List<string> _plNew = new List<string>();

	private static int _plWant = -1;

	private static DateTime _plLastLine = DateTime.MinValue;

	private static DateTime _plQuietUntil = DateTime.MinValue;

	private static DateTime _plAskAt = DateTime.MinValue;

	private static readonly Regex PlHead = new Regex("^=+\\s*Your Pet Log \\((\\d+)", RegexOptions.IgnoreCase);

	private static readonly Regex PlLine = new Regex("^(\\d+)\\.\\s+(.+?)\\s*$");

	private static readonly Regex PlReg = new Regex("^Registered:\\s*(.+?)!", RegexOptions.IgnoreCase);

	private static DateTime _bookAskAt = DateTime.MinValue;

	private static DateTime _bookOpenAt = DateTime.MinValue;

	public static DateTime _bookAfter = DateTime.MinValue;

	private static bool _bookClose;

	private static readonly HashSet<string> _stamps = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

	private static readonly Regex StampRx = new Regex("^First (.+?) captured!", RegexOptions.IgnoreCase);

	private const double BatRoom = 0.6;

	private const int BatHits = 2;

	public const int FightNormallyFrom = 10;

	private static DateTime _equipAt = DateTime.MinValue;

	private static DateTime _modeAt = DateTime.MinValue;

	private static bool _approaching;

	private static DateTime _facedAt = DateTime.MinValue;

	private static DateTime _apBestAt = DateTime.MinValue;

	private static double _apBest = -1.0;

	private const double StopAt = 2.0;

	private const double LensReach = 5.5;

	private static DateTime _bounceAt = DateTime.MinValue;

	private static DateTime _readyAt = DateTime.MinValue;

	private static bool _near;

	private static DateTime _approachAt;

	// The book as this character read it (its caught marks are this character's - never another account's), and the
	// kinds of monsters any character has read, shared: each fills in what the other's book is missing, nothing taken away.
	public static string PagesPath => PetLogPath.Replace("MelkTank_PetLog.txt", "Book_Monster-Dex_Pages.txt");

	private static string SharedPagesPath => Util.FullPath(Path.Combine("Logs", "Book_Monster-Dex_Pages.txt"));

	private static string KindsPath => Util.FullPath(Path.Combine("Logs", "Monster-Dex_Kinds.txt"));

	/// <summary>The monster kinds every character has seen in the book: species, then its entries ("  name").</summary>
	private static List<Species> LoadKinds()
	{
		List<Species> list = new List<Species>();
		try
		{
			if (!File.Exists(KindsPath)) return list;
			Species sp = null;
			foreach (string raw in File.ReadAllLines(KindsPath))
			{
				string t = raw.Trim();
				if (t.Length == 0) continue;
				if (t.StartsWith("Species:", StringComparison.OrdinalIgnoreCase))
				{
					sp = new Species { Name = t.Substring(8).Trim() };
					list.Add(sp);
				}
				else if (sp != null)
				{
					sp.Entries.Add(new Entry { Name = t });
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		return list;
	}

	/// <summary>Adds what this book has that the shared list doesn't (in the book's order) - never takes anything out.</summary>
	private static List<Species> MergeKinds(List<Species> book)
	{
		List<Species> kinds = LoadKinds();
		bool changed = false;
		foreach (Species b in book)
		{
			Species k = kinds.FirstOrDefault((Species x) => x.Name.Equals(b.Name, StringComparison.OrdinalIgnoreCase));
			if (k == null)
			{
				k = new Species { Name = b.Name };
				kinds.Add(k);
				changed = true;
			}
			int at = 0;
			foreach (Entry e in b.Entries)
			{
				int i = k.Entries.FindIndex((Entry x) => x.Name.Equals(e.Name, StringComparison.OrdinalIgnoreCase));
				if (i < 0)
				{
					k.Entries.Insert(Math.Min(at, k.Entries.Count), new Entry { Name = e.Name });
					changed = true;
					at++;
				}
				else
				{
					at = i + 1;
				}
			}
		}
		if (changed)
		{
			try
			{
				StringBuilder sb = new StringBuilder();
				sb.Append("Monster-Dex kinds, from every character's book (shared - only ever added to)\r\n\r\n");
				foreach (Species k in kinds)
				{
					sb.Append("Species: ").Append(k.Name).Append("\r\n");
					foreach (Entry e in k.Entries) sb.Append("  ").Append(e.Name).Append("\r\n");
					sb.Append("\r\n");
				}
				Directory.CreateDirectory(Path.GetDirectoryName(KindsPath));
				File.WriteAllText(KindsPath, sb.ToString());
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
		}
		return kinds;
	}

	public static int SiphonedCount
	{
		get
		{
			Pack();
			return _siphonedIds.Count;
		}
	}

	public static IEnumerable<string> SiphonedNames
	{
		get
		{
			Pack();
			return _siphoned;
		}
	}

	private static string AliasPath => PetLogPath.Replace("MelkTank_PetLog.txt", "MelkTank_PetAliases.txt");

	public static string Status
	{
		get
		{
			return _status;
		}
		set
		{
			_status = ((_target != 0 && !string.IsNullOrEmpty(value) && _qb.Length > 0 && value.IndexOf("QB", StringComparison.Ordinal) < 0) ? (value + _qb) : value);
		}
	}

	public static bool HoldPets
	{
		get
		{
			Settings settings = Settings();
			return settings.DexCatch && ServerMode.Ilt && (!_hi || !_tierKnown || !settings.DexPetT11) && ((settings.CombatEnabled && (_target != 0 || _wanted != 0)) || _protNear);
		}
	}

	public static bool HoldFracture => _hi && _heldNear && On();

	private static string PetLogPath
	{
		get
		{
			string text = "";
			try
			{
				text = Globals.Core.CharacterFilter.Name ?? "";
			}
			catch
			{
			}
			char[] invalidFileNameChars = Path.GetInvalidFileNameChars();
			foreach (char c in invalidFileNameChars)
			{
				text = text.Replace(c.ToString(), "");
			}
			return Util.FullPath(Path.Combine("Settings", Path.Combine((text.Length > 0) ? text : "_", "MelkTank_PetLog.txt")));
		}
	}

	private static string StampsPath => PetLogPath.Replace("MelkTank_PetLog.txt", "MelkTank_PetStamps.txt");

	private static List<Species> ReadBook(string path)
	{
		List<Species> list = new List<Species>();
		Species sp = null;
		foreach (string raw in File.ReadAllLines(path))
		{
			string t = raw.Trim();
			if (t.StartsWith("Species:", StringComparison.OrdinalIgnoreCase))
			{
				sp = new Species { Name = t.Substring(8).Trim() };
				list.Add(sp);
				continue;
			}
			if (sp == null) continue;
			Match m = Line.Match(t);
			if (m.Success && m.Groups[3].Value != "Normal" && !m.Groups[3].Value.StartsWith("Normal "))
			{
				sp.Entries.Add(new Entry { Name = m.Groups[3].Value, Normal = m.Groups[1].Value.Trim().Length > 0, Shiny = m.Groups[2].Value.Trim().Length > 0 });
			}
		}
		return list;
	}

	public static void LoadBook()
	{
		try
		{
			string pagesPath = PagesPath;
			List<Species> list = new List<Species>();
			Species species = null;
			// (the book saved before each character had its own: whose caught marks it holds isn't known - only its
			// kinds are used, put in the shared list)
			if (File.Exists(SharedPagesPath))
			{
				List<Species> old = ReadBook(SharedPagesPath);
				foreach (Species o in old)
				{
					foreach (Entry e in o.Entries) e.Normal = e.Shiny = false;
				}
				MergeKinds(old);
				try
				{
					string dir = Util.FullPath(Path.Combine("Logs", "_to_delete"));
					Directory.CreateDirectory(dir);
					string to = Path.Combine(dir, "Book_Monster-Dex_Pages.old-" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".txt");
					File.Move(SharedPagesPath, to);
				}
				catch (Exception ex2)
				{
					Util.LogError(ex2);
				}
			}
			string[] array = File.Exists(pagesPath) ? File.ReadAllLines(pagesPath) : new string[0];
			foreach (string text in array)
			{
				string text2 = text.Trim();
				if (text2.StartsWith("Species:", StringComparison.OrdinalIgnoreCase))
				{
					species = new Species
					{
						Name = text2.Substring(8).Trim()
					};
					list.Add(species);
				}
				else
				{
					if (species == null)
					{
						continue;
					}
					Match match = Line.Match(text2);
					if (match.Success)
					{
						string text3 = match.Groups[1].Value.Trim();
						string text4 = match.Groups[2].Value.Trim();
						if (!(match.Groups[3].Value == "Normal") && !match.Groups[3].Value.StartsWith("Normal "))
						{
							species.Entries.Add(new Entry
							{
								Name = match.Groups[3].Value,
								Normal = (text3.Length > 0),
								Shiny = (text4.Length > 0)
							});
						}
					}
				}
			}
			// what other characters' books have that this one hasn't read (not caught here - nothing of theirs is)
			foreach (Species k in MergeKinds(list))
			{
				Species mine = list.FirstOrDefault((Species x) => x.Name.Equals(k.Name, StringComparison.OrdinalIgnoreCase));
				if (mine == null)
				{
					mine = new Species { Name = k.Name };
					list.Add(mine);
				}
				foreach (Entry e in k.Entries)
				{
					if (!mine.Entries.Any((Entry x) => x.Name.Equals(e.Name, StringComparison.OrdinalIgnoreCase)))
					{
						mine.Entries.Add(new Entry { Name = e.Name });
					}
				}
			}
			Book = list;
			_byName.Clear();
			foreach (Species item in list)
			{
				foreach (Entry entry in item.Entries)
				{
					_byName[entry.Name] = entry;
				}
			}
			BookAt = File.Exists(pagesPath) ? File.GetLastWriteTime(pagesPath) : DateTime.MinValue;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static int CaughtCount(bool shiny)
	{
		int num = 0;
		foreach (Species item in Book)
		{
			foreach (Entry entry in item.Entries)
			{
				if (shiny ? entry.Shiny : entry.Normal)
				{
					num++;
				}
			}
		}
		return num;
	}

	public static string BaseName(string name, out bool shiny, out bool enraged)
	{
		shiny = false;
		enraged = false;
		string text = (name ?? "").Trim();
		for (int i = 0; i < 3; i++)
		{
			if (text.StartsWith("Enraged ", StringComparison.OrdinalIgnoreCase))
			{
				enraged = true;
				text = text.Substring(8).TrimStart();
				continue;
			}
			if (text.StartsWith("Shiny ", StringComparison.OrdinalIgnoreCase))
			{
				shiny = true;
				text = text.Substring(6).TrimStart();
				continue;
			}
			break;
		}
		return text;
	}

	private static void Pack(bool force = false)
	{
		if (!force && DateTime.Now - _packAt < TimeSpan.FromSeconds(2L))
		{
			return;
		}
		_packAt = DateTime.Now;
		_siphoned.Clear();
		_siphonedIds.Clear();
		LensCount.Clear();
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				string text = item.Name ?? "";
				if (text.StartsWith("Siphoned ", StringComparison.OrdinalIgnoreCase) && text.EndsWith(" Essence", StringComparison.OrdinalIgnoreCase))
				{
					_siphoned.Add(text.Substring(9, text.Length - 9 - 8).Trim());
					_siphonedIds.Add(item.Id);
				}
				else
				{
					if (text.IndexOf("Lens", StringComparison.OrdinalIgnoreCase) < 0)
					{
						continue;
					}
					string text2 = LensKey(text);
					if (text2 != null)
					{
						int num = 1;
						try
						{
							num = Math.Max(1, item.Values(LongValueKey.StackCount));
						}
						catch
						{
						}
						LensCount.TryGetValue(text2, out var value);
						LensCount[text2] = value + num;
					}
				}
			}
		}
		catch
		{
		}
	}

	private static string LensKey(string n)
	{
		string[] lenses = Lenses;
		foreach (string text in lenses)
		{
			if (n.Equals(text, StringComparison.OrdinalIgnoreCase))
			{
				return text;
			}
		}
		if (n.IndexOf("Asheron", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			return "Asheron's Lens";
		}
		if (n.IndexOf("Resonan", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			return "Resonant Lens";
		}
		return null;
	}

	public static int Lens(string key)
	{
		Pack();
		int value;
		return LensCount.TryGetValue(key, out value) ? value : 0;
	}

	private static WorldObject FindInPack(Func<string, bool> match)
	{
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (match(item.Name ?? ""))
				{
					return item;
				}
			}
		}
		catch
		{
		}
		return null;
	}

	private static WorldObject LensItem(string key)
	{
		return FindInPack((string n) => LensKey(n) == key);
	}

	public static bool IsCaught(string baseName, bool shiny)
	{
		string why;
		return IsCaught(baseName, shiny, out why);
	}

	private static bool Covers(string caught, string mob)
	{
		return mob.Equals(caught, StringComparison.OrdinalIgnoreCase) || mob.StartsWith(caught + " ", StringComparison.OrdinalIgnoreCase);
	}

	public static bool IsCaught(string baseName, bool shiny, out string why)
	{
		why = null;
		string text = Dexed(baseName);
		if (!text.Equals(baseName, StringComparison.OrdinalIgnoreCase))
		{
			if (IsCaughtName(text, shiny, out why))
			{
				why = why + " (its essence is " + text + ")";
				return true;
			}
			return false;
		}
		return IsCaughtName(baseName, shiny, out why);
	}

	private static bool IsCaughtName(string baseName, bool shiny, out string why)
	{
		why = null;
		foreach (Entry value in _byName.Values)
		{
			if ((shiny ? value.Shiny : value.Normal) && Covers(value.Name, baseName))
			{
				why = "in the book as " + value.Name;
				return true;
			}
		}
		Pack();
		string mob = (shiny ? "Shiny " : "") + baseName;
		foreach (string item in PetLog)
		{
			if (Covers(item, mob))
			{
				why = "in the Pet Log as " + item;
				return true;
			}
		}
		foreach (string item2 in _siphoned)
		{
			if (Covers(item2, mob))
			{
				why = "Siphoned " + item2 + " Essence in the pack";
				return true;
			}
		}
		foreach (string item3 in _caughtNow)
		{
			if (Covers(item3, mob))
			{
				why = "caught " + item3 + " this session";
				return true;
			}
		}
		return false;
	}

	private static void LoadAliases()
	{
		_alias.Clear();
		try
		{
			if (!File.Exists(AliasPath))
			{
				return;
			}
			string[] array = File.ReadAllLines(AliasPath);
			foreach (string text in array)
			{
				int num = text.IndexOf('=');
				if (num > 0)
				{
					_alias[text.Substring(0, num).Trim()] = text.Substring(num + 1).Trim();
				}
			}
		}
		catch
		{
		}
	}

	private static void SaveAliases()
	{
		try
		{
			List<string> list = new List<string>();
			foreach (KeyValuePair<string, string> item in _alias)
			{
				list.Add(item.Key + "=" + item.Value);
			}
			File.WriteAllLines(AliasPath, list.ToArray());
		}
		catch
		{
		}
	}

	private static string Dexed(string baseName)
	{
		string value;
		return _alias.TryGetValue(baseName, out value) ? value : baseName;
	}

	private static void Log(string s)
	{
		try
		{
			if (_eng != null)
			{
				_eng.NoteLine("DEX   " + s);
			}
		}
		catch
		{
		}
	}

	private static void LogOnce(int id, string s)
	{
		if (_logged.Count > 2000)
		{
			_logged.Clear();
		}
		if (_logged.Add(id + s))
		{
			Log(s);
		}
	}

	private static bool LensCached(Settings s)
	{
		return LensCached(s, shiny: true);
	}

	private static bool LensCached(Settings s, bool shiny)
	{
		if (DateTime.Now >= _lensAt)
		{
			_lensAt = DateTime.Now.AddSeconds(2.0);
			_lensHave = AnyLens(s, shiny: true);
			_lensHaveNormal = AnyLens(s, shiny: false);
		}
		return shiny ? _lensHave : _lensHaveNormal;
	}

	public static bool NotCaught(string name)
	{
		try
		{
			string text = BaseName(name, out var shiny, out var _);
			return text.Length > 0 && !IsCaught(text, shiny);
		}
		catch
		{
			return false;
		}
	}

	public static bool Protected(WorldObject o)
	{
		if (o == null)
		{
			return false;
		}
		Settings settings = Settings();
		if (!settings.DexCatch || !ServerMode.Ilt)
		{
			return false;
		}
		if (o.Id == _target)
		{
			return !_hi || !_tierKnown;
		}
		if (_hi && _tierKnown)
		{
			return false;
		}
		if (_doneIds.Contains(o.Id))
		{
			return false;
		}
		string text = BaseName(o.Name, out var shiny, out var enraged);
		if (enraged || text.Length == 0 || IsCaught(text, shiny) || Skipped((shiny ? "Shiny " : "") + text))
		{
			return false;
		}
		return LensCached(settings, shiny);
	}

	private static void ScanProtected(CombatEngine e)
	{
		DateTime now = DateTime.Now;
		if (now < _protScanAt)
		{
			return;
		}
		_protScanAt = now.AddMilliseconds(400.0);
		_tierKnown = e != null && e.Tier != null && e.Tier.Tier >= 0;
		if (_tierKnown)
		{
			_hi = HighTier(e);
		}
		bool protNear = false;
		string protName = "";
		double num = double.MaxValue;
		double num2 = (e?.AttackRangeNow ?? 30f) + 15f;
		try
		{
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				if (item.ObjectClass == ObjectClass.Monster && (e == null || e.IsHostileMonster(item)))
				{
					double num3 = CombatEngine.Distance(item);
					if (!(num3 < 0.0) && !(num3 > num2) && !(num3 >= num) && Protected(item))
					{
						protNear = true;
						protName = item.Name;
						num = num3;
					}
				}
			}
		}
		catch
		{
		}
		_protNear = protNear;
		_protName = protName;
	}

	private static bool On()
	{
		Settings settings = Settings();
		return settings.DexCatch && settings.CombatEnabled && ServerMode.Ilt;
	}

	public static bool Held(WorldObject o)
	{
		if (!_hi || o == null || !On())
		{
			return false;
		}
		if (o.Id == _target)
		{
			return true;
		}
		if (_doneIds.Contains(o.Id))
		{
			return false;
		}
		string text = BaseName(o.Name, out var shiny, out var enraged);
		if (enraged || text.Length == 0 || IsCaught(text, shiny) || Skipped((shiny ? "Shiny " : "") + text))
		{
			return false;
		}
		return AnyLens(Settings(), shiny);
	}

	private static Settings Settings()
	{
		return PluginCore.CurrentSettings ?? _blank ?? (_blank = new Settings());
	}

	private static void NotePct(int id, double pct)
	{
		lock (_pct)
		{
			_pct[id] = pct;
			_pctAt[id] = DateTime.Now;
		}
	}

#if !RETAIL
	// ACGodot: the monster's health as the client keeps it (from its ID and the health answers) - the game messages it's
	// read from on retail don't carry it here. A changed value is new now; an unchanged one counts as fresh once the ID
	// asked for after the last swing has had time to come back
	private static readonly Dictionary<int, double> _fighterPct = new Dictionary<int, double>();

	private static void FromFighter(int id)
	{
		try
		{
			if (!(ACGodot.DecalShim.Bridge.ThingOf(id) is ACGodot.Objects.ObjectStreamer.Selectable sel)) return;
			ACGodot.Combat.Fighter f = ACGodot.DecalShim.Bridge.Host?.FighterOf(sel);
			if (f == null || f.MaxHealth <= 0) return;
			double p = 100.0 * f.Health / f.MaxHealth;
			bool changed = !_fighterPct.TryGetValue(id, out var was) || Math.Abs(was - p) > 1e-6;
			_fighterPct[id] = p;
			if (id == _target && _idMax <= 0) _idMax = f.MaxHealth;
			DateTime asOf = changed ? DateTime.Now : ((_idAt != DateTime.MinValue && (DateTime.Now - _idAt).TotalSeconds > 0.4) ? _idAt.AddSeconds(0.4) : DateTime.MinValue);
			if (asOf == DateTime.MinValue) return;
			lock (_pct)
			{
				if (!_pctAt.TryGetValue(id, out var at) || at < asOf)
				{
					_pct[id] = p;
					_pctAt[id] = asOf;
				}
			}
		}
		catch
		{
		}
	}
#endif

	private static bool Health(int id, DateTime since, out double pct, out int cur, out int max)
	{
		pct = -1.0;
		cur = -1;
		max = 0;
#if !RETAIL
		FromFighter(id);
#endif
		lock (_pct)
		{
			if (!_pctAt.TryGetValue(id, out var value) || value < since)
			{
				return false;
			}
			pct = _pct[id];
		}
		if (id == _target)
		{
			max = _idMax;
		}
		else if (!MonsterMatch.MaxHealth.TryGetValue(id, out max))
		{
			max = 0;
		}
		if (max > 0)
		{
			cur = (int)Math.Round(pct * (double)max / 100.0);
		}
		return true;
	}

	public static void OnServerMessage(Message msg)
	{
		if (msg == null || msg.Type != 63408)
		{
			return;
		}
		try
		{
			if (WeaponCompare.ReadHealthAny(msg, out var obj, out var cur, out var max) && max > 0)
			{
				if (obj == _target && _target != 0)
				{
					_idMax = max;
				}
				NotePct(obj, 100.0 * (double)cur / (double)max);
			}
			byte[] rawData = msg.RawData;
			if (rawData != null && rawData.Length >= 24 && BitConverter.ToUInt32(rawData, 12) == 448)
			{
				NotePct(BitConverter.ToInt32(rawData, 16), (double)BitConverter.ToSingle(rawData, 20) * 100.0);
			}
			if (_target == 0 || _st != St.Lens)
			{
				return;
			}
			for (int i = 0; i < msg.Count; i++)
			{
				if (msg[i] is string text && text.IndexOf("20%", StringComparison.Ordinal) >= 0)
				{
					Log("game says: " + text);
					OnText(text);
				}
			}
		}
		catch
		{
		}
	}

	public static bool OnChat(string text)
	{
		if (string.IsNullOrEmpty(text))
		{
			return false;
		}
		string t = text.Trim();
		bool result = PetLogLine(t);
		try
		{
			TurnIn.OnChat(t);
		}
		catch
		{
		}
		if (_target != 0)
		{
			OnText(t);
		}
		return result;
	}

	public static void LoadPetLog()
	{
		LoadStamps();
		LoadAliases();
		PetLog.Clear();
		try
		{
			string petLogPath = PetLogPath;
			if (!File.Exists(petLogPath))
			{
				return;
			}
			string[] array = File.ReadAllLines(petLogPath);
			foreach (string text in array)
			{
				if (text.Trim().Length > 0)
				{
					PetLog.Add(text.Trim());
				}
			}
			PetLogAt = File.GetLastWriteTime(petLogPath);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void SavePetLog()
	{
		try
		{
			string petLogPath = PetLogPath;
			Directory.CreateDirectory(Path.GetDirectoryName(petLogPath));
			List<string> list = new List<string>(PetLog);
			File.WriteAllLines(petLogPath, list.ToArray());
			PetLogAt = DateTime.Now;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void AskPetLog()
	{
		_plQuietUntil = DateTime.Now.AddSeconds(8.0);
		try
		{
			Globals.Core.Actions.InvokeChatParser("/pets");
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void AskPetLogSoon(double seconds)
	{
		_plAskAt = DateTime.Now.AddSeconds(seconds);
	}

	private static bool PetLogLine(string t)
	{
		bool result = DateTime.Now <= _plQuietUntil;
		Match match = PlReg.Match(t);
		if (match.Success)
		{
			PetLog.Add(match.Groups[1].Value.Trim());
			SavePetLog();
			return false;
		}
		match = StampRx.Match(t);
		if (match.Success)
		{
			_stamps.Add(Norm(match.Groups[1].Value.Replace("Shiny ", "Shiny_")).Replace("Shiny_", "Shiny "));
			SaveStamps();
			return false;
		}
		match = PlHead.Match(t);
		if (match.Success)
		{
			_plWant = int.Parse(match.Groups[1].Value);
			_plNew.Clear();
			_plLastLine = DateTime.Now;
			if (_plWant == 0)
			{
				PetLogDone();
			}
			return result;
		}
		if (_plWant < 0)
		{
			return false;
		}
		match = PlLine.Match(t);
		if (!match.Success)
		{
			return false;
		}
		_plNew.Add(match.Groups[2].Value.Trim());
		_plLastLine = DateTime.Now;
		if (_plNew.Count >= _plWant)
		{
			PetLogDone();
		}
		return result;
	}

	private static void PetLogDone()
	{
		_plWant = -1;
		PetLog.Clear();
		foreach (string item in _plNew)
		{
			PetLog.Add(item);
		}
		_plNew.Clear();
		SavePetLog();
		Log("pet log read: " + PetLog.Count + " pets");
	}

	public static void FrameTick()
	{
		DateTime now = DateTime.Now;
		try
		{
			ApproachFrame();
		}
		catch
		{
		}
		try
		{
			BookFrame();
		}
		catch
		{
		}
		if (_bookAfter != DateTime.MinValue && now >= _bookAfter)
		{
			_bookAfter = DateTime.MinValue;
			ReadBook();
		}
		if (_plWant > 0 && _plNew.Count > 0 && (now - _plLastLine).TotalSeconds > 3.0)
		{
			PetLogDone();
		}
		if (_plAskAt != DateTime.MinValue && now >= _plAskAt)
		{
			_plAskAt = DateTime.MinValue;
			AskPetLog();
		}
	}

	[DllImport("user32.dll")]
	private static extern bool PostMessage(nint hWnd, uint msg, nint wParam, nint lParam);

	public static void ReadBook()
	{
		WorldObject worldObject = FindInPack((string n) => n.Equals("Monster-Dex", StringComparison.OrdinalIgnoreCase));
		if (worldObject == null)
		{
			Util.WriteToChat("Dex: no Monster-Dex in your pack.");
			return;
		}
		BookReader.HookUb();
		try
		{
			Globals.Core.Actions.UseItem(worldObject.Id, 0);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			return;
		}
		_bookAskAt = DateTime.Now;
		_bookOpenAt = DateTime.MinValue;
		_bookClose = true;
		Log("opening the Monster-Dex");
	}

	private static void BookFrame()
	{
		if (!_bookClose)
		{
			return;
		}
		DateTime now = DateTime.Now;
		if ((now - _bookAskAt).TotalSeconds > 10.0)
		{
			_bookClose = false;
			Log("the book didn't open");
		}
		else
		{
			if (BookReader.LastOpenAt < _bookAskAt)
			{
				return;
			}
			if (_bookOpenAt == DateTime.MinValue)
			{
				_bookOpenAt = now;
			}
			else if (!((now - _bookOpenAt).TotalSeconds < 1.0))
			{
				_bookClose = false;
				try
				{
					nint hwnd = Globals.Core.Decal.Hwnd;
					if (hwnd == 0)
					{
						return;   // (ACGodot: the pages are read without a book window to shut)
					}
					PostMessage(hwnd, 256u, 27, 65537);
					PostMessage(hwnd, 257u, 27, -1073676287);
					Log("closed the Monster-Dex (Esc)");
				}
				catch (Exception ex)
				{
					Util.LogError(ex);
				}
			}
		}
	}

	public static bool InPetLog(string name, bool shiny)
	{
		return PetLog.Contains((shiny ? "Shiny " : "") + name);
	}

	private static string Norm(string species)
	{
		return (species ?? "").Replace(" ", "").Replace("-", "").Replace("'", "")
			.Trim();
	}

	private static string SpeciesOf(string dexName)
	{
		foreach (Species item in Book)
		{
			foreach (Entry entry in item.Entries)
			{
				if (Covers(entry.Name, dexName) || Covers(dexName, entry.Name))
				{
					return Norm(item.Name);
				}
			}
		}
		try
		{
			int num = GameInfo.SpeciesByName(dexName);
			if (num > 0)
			{
				return Norm(MonsterMatch.SpeciesName(num));
			}
		}
		catch
		{
		}
		return "";
	}

	private static bool SpeciesHas(string species, bool shiny)
	{
		if (species.Length == 0)
		{
			return false;
		}
		if (_stamps.Contains((shiny ? "Shiny " : "") + species))
		{
			return true;
		}
		foreach (Species item in Book)
		{
			if (!Norm(item.Name).Equals(species, StringComparison.OrdinalIgnoreCase))
			{
				continue;
			}
			foreach (Entry entry in item.Entries)
			{
				if (shiny ? entry.Shiny : entry.Normal)
				{
					return true;
				}
			}
		}
		foreach (string item2 in PetLog)
		{
			bool flag = item2.StartsWith("Shiny ", StringComparison.OrdinalIgnoreCase);
			if (flag != shiny || !SpeciesOf(flag ? item2.Substring(6) : item2).Equals(species, StringComparison.OrdinalIgnoreCase))
			{
				continue;
			}
			return true;
		}
		foreach (string item3 in _siphoned)
		{
			bool flag2 = item3.StartsWith("Shiny ", StringComparison.OrdinalIgnoreCase);
			if (flag2 == shiny && SpeciesOf(flag2 ? item3.Substring(6) : item3).Equals(species, StringComparison.OrdinalIgnoreCase))
			{
				return true;
			}
		}
		return false;
	}

	public static bool GivesQb(WorldObject o)
	{
		try
		{
			if (o == null)
			{
				return false;
			}
			int num = 0;
			try
			{
				num = GameInfo.Species(o);
			}
			catch
			{
			}
			string baseName = BaseName(o.Name, out var shiny, out var _);
			string text = ((num > 0) ? Norm(MonsterMatch.SpeciesName(num)) : SpeciesOf(Dexed(baseName)));
			if (text.Length == 0)
			{
				return false;
			}
			Pack();
			return !SpeciesHas(text, shiny);
		}
		catch
		{
			return false;
		}
	}

	public static string QbText(WorldObject o)
	{
		if (o == null)
		{
			return "";
		}
		int num = 0;
		try
		{
			num = GameInfo.Species(o);
		}
		catch
		{
		}
		string baseName = BaseName(o.Name, out var shiny, out var _);
		string text = ((num > 0) ? Norm(MonsterMatch.SpeciesName(num)) : SpeciesOf(Dexed(baseName)));
		if (text.Length == 0)
		{
			return " - QB unknown (species?)";
		}
		Pack();
		return (!SpeciesHas(text, shiny)) ? (" - QB! (first " + (shiny ? "shiny " : "") + text + ")") : (" - no QB (" + (shiny ? "shiny " : "") + text + " done)");
	}

	private static void LoadStamps()
	{
		_stamps.Clear();
		try
		{
			if (!File.Exists(StampsPath))
			{
				return;
			}
			string[] array = File.ReadAllLines(StampsPath);
			foreach (string text in array)
			{
				if (text.Trim().Length > 0)
				{
					_stamps.Add(text.Trim());
				}
			}
		}
		catch
		{
		}
	}

	private static void SaveStamps()
	{
		try
		{
			File.WriteAllLines(StampsPath, new List<string>(_stamps).ToArray());
		}
		catch
		{
		}
	}

	private static void OnText(string t)
	{
		WorldObject worldObject = Globals.Core.WorldFilter[_target];
		string text = ((worldObject != null) ? worldObject.Name : _base);
		if (_swinging)
		{
			Match match = Hit.Match(t);
			if (match.Success && text.IndexOf(match.Groups[1].Value.Trim(), StringComparison.OrdinalIgnoreCase) >= 0)
			{
				EndSwing();
				return;
			}
			if (t.IndexOf("evaded your attack", StringComparison.OrdinalIgnoreCase) >= 0 || t.StartsWith("You miss", StringComparison.OrdinalIgnoreCase))
			{
				EndSwing();
				return;
			}
		}
		if (t.IndexOf("You successfully siphoned the essence of", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			Caught++;
			Match match2 = Regex.Match(t, "essence of (?:the |a |an )?(.+?)[!.]?\\s*$", RegexOptions.IgnoreCase);
			string text2 = (match2.Success ? match2.Groups[1].Value.Trim() : "");
			_caughtNow.Add((text2.Length > 0) ? text2 : ((_shiny ? "Shiny " : "") + _base));
			string text3 = (text2.StartsWith("Shiny ", StringComparison.OrdinalIgnoreCase) ? text2.Substring(6) : text2);
			if (text3.Length > 0 && !Covers(text3, _base) && !Covers(_base, text3))
			{
				Log("the lens caught " + text3 + " (closer) instead of " + _base);
				Util.WriteToChat("Dex: the lens caught the " + text3 + " standing closer, not the " + _base + ".");
				int target = _target;
				Finish(ok: false);
				_doneIds.Remove(target);
			}
			else
			{
				Log("caught: " + t);
				Util.WriteToChat("Dex: caught " + (_shiny ? "Shiny " : "") + _base + "!");
				Finish(ok: true);
			}
		}
		else if (t.IndexOf("becomes enraged", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			if (t.IndexOf(_base, StringComparison.OrdinalIgnoreCase) >= 0)
			{
				Enraged++;
				return;
			}
			int num = t.IndexOf(" becomes enraged", StringComparison.OrdinalIgnoreCase);
			_wrongHit = ((num > 0) ? t.Substring(0, num).Trim() : "another monster");
		}
		else
		{
			if (_st != St.Lens && _st != St.Resonant)
			{
				return;
			}
			if (t.IndexOf("resisted your capture", StringComparison.OrdinalIgnoreCase) >= 0 || t.IndexOf("siphon failed", StringComparison.OrdinalIgnoreCase) >= 0 || t.IndexOf("lens shatters", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				if (_st == St.Lens)
				{
					Go(St.Failed);
				}
			}
			else if (t.IndexOf("20%", StringComparison.Ordinal) >= 0 && _st == St.Lens)
			{
				_idAt = DateTime.MinValue;
				_swingDone = DateTime.Now;
				_bounceAt = DateTime.Now;
				Go(St.Lower);
			}
		}
	}

	private static void Go(St s)
	{
		if (s != _st)
		{
			Log((_shiny ? "Shiny " : "") + _base + " [" + _target + "]: " + _st.ToString() + " -> " + s);
		}
		_st = s;
		_stAt = DateTime.Now;
	}

	private static void Finish(bool ok)
	{
		if (_target != 0)
		{
			_doneIds.Add(_target);
		}
		if (_swinging)
		{
			EndSwing();
		}
		if (_approaching)
		{
			try
			{
				Globals.Core.Actions.SetAutorun(on: false);
			}
			catch
			{
			}
			_approaching = false;
		}
		_target = 0;
		_wanted = 0;
		_st = St.Idle;
		_watch = false;
		Status = (ok ? ("Caught " + _lastCaughtName()) : Status);
		Log("done with " + _lastCaughtName() + (ok ? " - caught" : (" - " + Status)));
	}

	private static string _lastCaughtName()
	{
		return (_shiny ? "Shiny " : "") + _base;
	}

	private static void Skip(string why, int minutes)
	{
		string text = (_shiny ? "Shiny " : "") + _base;
		_skip[text] = DateTime.Now.AddMinutes(minutes);
		Util.WriteToChat("Dex: leaving " + text + " - " + why + ".");
		Log("skipping " + text + " - " + why);
		Status = "Skipped " + text + " - " + why;
		Finish(ok: false);
	}

	private static bool Skipped(string key)
	{
		if (_skip.TryGetValue(key, out var value) && DateTime.Now < value)
		{
			return true;
		}
		string[] array = (Settings().DexSkip ?? "").Split(new char[3] { ',', ';', '\n' }, StringSplitOptions.RemoveEmptyEntries);
		foreach (string text in array)
		{
			if (text.Trim().Length > 0 && key.IndexOf(text.Trim(), StringComparison.OrdinalIgnoreCase) >= 0)
			{
				return true;
			}
		}
		return false;
	}

	private static bool AsheronFor(Settings s, bool shiny)
	{
		return s.DexAsheron && (shiny || !s.DexAsheronShiny);
	}

	private static bool ResonantFor(Settings s, bool shiny)
	{
		return s.DexResonant && (shiny || !s.DexResonantShiny);
	}

	private static bool AnyLens(Settings s)
	{
		return AnyLens(s, shiny: true);
	}

	private static bool AnyLens(Settings s, bool shiny)
	{
		if (AsheronFor(s, shiny) && Lens("Asheron's Lens") > 0)
		{
			return true;
		}
		string[] lenses = Lenses;
		foreach (string key in lenses)
		{
			if (Lens(key) > 0)
			{
				return true;
			}
		}
		return false;
	}

	private static WorldObject BatFor(int cur, out int max)
	{
		max = 0;
		WorldObject worldObject = null;
		WorldObject worldObject2 = null;
		int num = 0;
		for (int num2 = Bats.Length - 1; num2 >= 0; num2--)
		{
			string bn = Bats[num2];
			WorldObject worldObject3 = FindInPack((string n) => n.Equals(bn, StringComparison.OrdinalIgnoreCase));
			if (worldObject3 != null)
			{
				worldObject2 = worldObject3;
				num = BatMax[num2];
				if (worldObject == null && ((cur < 0) ? (num2 == 0) : ((double)(BatMax[num2] * 2) <= (double)cur * 0.6)))
				{
					worldObject = worldObject3;
					max = BatMax[num2];
				}
			}
		}
		if (worldObject == null && worldObject2 != null)
		{
			worldObject = worldObject2;
			max = num;
		}
		return worldObject;
	}

	private static bool HaveBat()
	{
		string[] bats = Bats;
		foreach (string text in bats)
		{
			string bn = text;
			if (FindInPack((string n) => n.Equals(bn, StringComparison.OrdinalIgnoreCase)) != null)
			{
				return true;
			}
		}
		return false;
	}

	private static bool HighTier(CombatEngine e)
	{
		return e != null && e.Tier != null && e.Tier.Tier >= 10;
	}

	private static WorldObject Candidate(CombatEngine e, double range)
	{
		WorldObject result = null;
		double num = double.MaxValue;
		foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
		{
			if (item.ObjectClass != ObjectClass.Monster || !e.IsHostileMonster(item))
			{
				continue;
			}
			double num2 = CombatEngine.Distance(item);
			if (num2 < 0.0 || num2 > range)
			{
				continue;
			}
			string text = BaseName(item.Name, out var shiny, out var enraged);
			if (_doneIds.Contains(item.Id))
			{
				LogOnce(item.Id, item.Name + " [" + item.Id + "] not tried: already tried this one");
			}
			else if (enraged)
			{
				LogOnce(item.Id, item.Name + " [" + item.Id + "] not tried: enraged");
			}
			else if (text.Length != 0)
			{
				TrackedMonster value;
				if (IsCaught(text, shiny, out var why))
				{
					LogOnce(item.Id, item.Name + " [" + item.Id + "] not tried: " + why);
				}
				else if (Skipped((shiny ? "Shiny " : "") + text))
				{
					LogOnce(item.Id, item.Name + " [" + item.Id + "] not tried: skipped for now / Never catch");
				}
				else if (!AnyLens(Settings(), shiny))
				{
					LogOnce(item.Id, item.Name + " [" + item.Id + "] not tried: only shiny-only lenses left");
				}
				else if ((!e.Tracked.TryGetValue(item.Id, out value) || !(value.DeadAt != DateTime.MinValue)) && !(num2 >= num))
				{
					result = item;
					num = num2;
				}
			}
		}
		return result;
	}

	public static bool Tick(CombatEngine e)
	{
		if (TurnIn.Busy)
		{
			return TurnIn.Tick();
		}
		_eng = e;
		Settings settings = Settings();
		bool flag = settings.DexCatch && ServerMode.Ilt;
		if (flag)
		{
			ScanProtected(e);
		}
		if (!flag || !settings.CombatEnabled)
		{
			if (_target != 0)
			{
				Finish(ok: false);
			}
			_wanted = 0;
			Status = (settings.DexCatch ? ("Combat is off" + (_protNear ? (" - not caught yet nearby: " + _protName + " (the fight will leave it alone)") : "")) : "");
			return false;
		}
		DateTime now = DateTime.Now;
		_hi = HighTier(e);
		if (_hi && now >= _heldScanAt)
		{
			_heldScanAt = now.AddMilliseconds(400.0);
			bool heldNear = false;
			double num = e.AttackRangeNow + 15f;
			try
			{
				foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
				{
					if (item.ObjectClass == ObjectClass.Monster && e.IsHostileMonster(item))
					{
						double num2 = CombatEngine.Distance(item);
						if (num2 >= 0.0 && num2 <= num && Held(item))
						{
							heldNear = true;
							break;
						}
					}
				}
			}
			catch
			{
			}
			_heldNear = heldNear;
		}
		else if (!_hi)
		{
			_heldNear = false;
		}
		if (_target == 0)
		{
			if (now < _scanAt)
			{
				return false;
			}
			_scanAt = now.AddMilliseconds(500.0);
			if (!AnyLens(settings))
			{
				_wanted = 0;
				Status = "No siphon lenses in your pack";
				return false;
			}
			if (e.Tier == null || e.Tier.Tier < 0)
			{
				if (_noTierSince == DateTime.MinValue)
				{
					_noTierSince = now;
				}
				if ((now - _noTierSince).TotalSeconds < 10.0)
				{
					_wanted = 0;
					Status = "Waiting to know this area's tier" + (_protNear ? (" - leaving " + _protName + " alone till then") : "");
					return false;
				}
			}
			else
			{
				_noTierSince = DateTime.MinValue;
			}
			double range = e.AttackRangeNow;
			WorldObject worldObject = Candidate(e, range);
			_wanted = worldObject?.Id ?? 0;
			if (worldObject == null)
			{
				Status = "Watching for monsters you haven't caught";
				return false;
			}
			bool flag2 = HighTier(e);
			bool flag3 = MonsterMatch.MaxHealth.TryGetValue(worldObject.Id, out var value) && value > 0 && value <= 20;
			if (!flag2 && !flag3 && !HaveBat() && (!settings.DexCorruption || !SpellBook.IsKnown(SpellBook.FindByName("Corruption I"))))
			{
				Status = "No bonk bat in your pack to bring " + worldObject.Name + " down";
				return false;
			}
			_target = worldObject.Id;
			_idMax = 0;
			_base = BaseName(worldObject.Name, out _shiny, out var _);
			_resUsed = false;
			_watch = flag2;
			_wrongHit = null;
			_noAnswer = 0;
			_swinging = false;
			_corrAt = DateTime.MinValue;
			_idAt = DateTime.MinValue;
			_startAt = now;
			_bestPct = 999.0;
			_bestAt = now;
			Tried++;
			Log("catching " + worldObject.Name + " [" + worldObject.Id + "] at " + CombatEngine.Distance(worldObject).ToString("0.0") + " m" + (flag2 ? " (T11: watching)" : ""));
			_qb = QbText(worldObject);
			Util.WriteToChat("Dex: catching " + worldObject.Name + _qb + (flag2 ? " (T11: fighting as usual until it's under 20%)" : "") + ".");
			Go(St.Pets);
		}
		WorldObject worldObject2 = Globals.Core.WorldFilter[_target];
		if (worldObject2 == null && _st != St.Failed)
		{
			Status = (_shiny ? "Shiny " : "") + _base + " is gone";
			Finish(ok: false);
			return false;
		}
		if ((now - _startAt).TotalMinutes > 6.0)
		{
			Skip("no catch after 6 minutes", 15);
			return false;
		}
		if (worldObject2 != null && now - _idAt > TimeSpan.FromMilliseconds(_near ? 350 : 700))
		{
			_idAt = now;
			try
			{
				double num3 = CombatEngine.Distance(worldObject2);
				if (num3 >= 0.0 && num3 <= (double)e.AttackRangeNow && Globals.Core.Actions.CurrentSelection != worldObject2.Id)
				{
					Globals.Core.Actions.SelectItem(worldObject2.Id);
				}
				Util.RequestId(worldObject2.Id);
				// (its health asked for too: an ID's answer doesn't always carry it where it's read - ACGodot - and the
				// catch waits on knowing it before the bat comes out)
				CM_Combat.Event_QueryHealth((uint)worldObject2.Id);
			}
			catch
			{
			}
		}
		switch (_st)
		{
		case St.Pets:
		{
			PetSummoner current3 = PetSummoner.Current;
			if (current3 == null || !current3.AnyOut || (_watch && settings.DexPetT11))
			{
				Go(St.Lower);
				return !_watch;
			}
			if (current3.PetFighting && (now - _stAt).TotalSeconds > 2.0)
			{
				Skip("your pet was already fighting", 2);
				return false;
			}
			if ((now - _stAt).TotalSeconds > 10.0)
			{
				Skip("the pet couldn't be dismissed", 2);
				return false;
			}
			Status = "Dismissing your pet before catching " + worldObject2.Name;
			return true;
		}
		case St.Lower:
			return Lower(e, settings, worldObject2, now);
		case St.Approach:
			return Approach(e, worldObject2, now);
		case St.Lens:
		{
			Settings settings2 = Settings();
			int lensGap = Math.Max(100, settings2.DexLensGapMs);
			if (_spam < Math.Max(1, settings2.DexLensTries) && (now - _sentAt).TotalMilliseconds >= (double)lensGap && worldObject2 != null)
			{
				WorldObject worldObject6 = Globals.Core.WorldFilter[_lensId];
				if (worldObject6 == null)
				{
					worldObject6 = LensItem(_lastLens);
				}
				if (worldObject6 != null)
				{
					try
					{
						Globals.Core.Actions.ApplyItem(worldObject6.Id, worldObject2.Id);
					}
					catch
					{
					}
					_lensId = worldObject6.Id;
				}
				_spam++;
				_sentAt = now;
				Log(_lastLens + " -> " + worldObject2.Name + " again (" + _spam + ")");
			}
			if (_spam >= Math.Max(1, settings2.DexLensTries) && (now - _sentAt).TotalMilliseconds > (double)Math.Max(500, settings2.DexLensWaitMs))
			{
				if (++_noAnswer >= 3)
				{
					Skip("the lens got no answer", 10);
					return false;
				}
				Go(St.Lower);
			}
			Status = "Siphoning " + ((worldObject2 != null) ? worldObject2.Name : _base) + " with " + _lastLens;
			return true;
		}
		case St.Failed:
		{
			if (_wrongHit != null || (worldObject2 != null && worldObject2.Name.IndexOf("Enraged", StringComparison.OrdinalIgnoreCase) < 0 && (now - _stAt).TotalSeconds > 0.8))
			{
				if (worldObject2 != null && worldObject2.Name.IndexOf("Enraged", StringComparison.OrdinalIgnoreCase) < 0)
				{
					Log("the lens went to " + (_wrongHit ?? "another monster") + " - still after " + worldObject2.Name);
					Util.WriteToChat("Dex: the lens went to the " + (_wrongHit ?? "monster") + " standing closer - trying " + worldObject2.Name + " again.");
					_wrongHit = null;
					_idAt = DateTime.MinValue;
					Go(St.Lower);
					return !_watch;
				}
				_wrongHit = null;
			}
			if ((now - _stAt).TotalSeconds < 0.5)
			{
				return true;
			}
			WorldObject worldObject3 = worldObject2;
			if (worldObject3 == null || worldObject3.Name.IndexOf("Enraged", StringComparison.OrdinalIgnoreCase) < 0)
			{
				WorldObject worldObject4 = null;
				double num4 = 30.0;
				foreach (WorldObject item2 in Globals.Core.WorldFilter.GetLandscape())
				{
					if (item2.ObjectClass == ObjectClass.Monster && item2.Name.IndexOf("Enraged", StringComparison.OrdinalIgnoreCase) >= 0 && BaseName(item2.Name, out var shiny, out var _).Equals(_base, StringComparison.OrdinalIgnoreCase) && shiny == _shiny)
					{
						double num5 = CombatEngine.Distance(item2);
						if (num5 >= 0.0 && num5 < num4)
						{
							num4 = num5;
							worldObject4 = item2;
						}
					}
				}
				if (worldObject4 != null)
				{
					worldObject3 = worldObject4;
					_target = worldObject4.Id;
				}
			}
			if (!ResonantFor(settings, _shiny) || _resUsed || Lens("Resonant Lens") <= 0)
			{
				Util.WriteToChat("Dex: " + (_shiny ? "Shiny " : "") + _base + " got away" + (_resUsed ? " (Resonant Lens already used on it)" : (settings.DexResonant ? " (no Resonant Lens left)" : "")) + ".");
				if (worldObject3 != null)
				{
					_doneIds.Add(worldObject3.Id);
				}
				Finish(ok: false);
				return false;
			}
			if (worldObject3 == null || worldObject3.Name.IndexOf("Enraged", StringComparison.OrdinalIgnoreCase) < 0)
			{
				if ((now - _stAt).TotalSeconds > 6.0)
				{
					if (worldObject2 != null)
					{
						_doneIds.Add(worldObject2.Id);
					}
					Finish(ok: false);
					return false;
				}
				Status = "Waiting for the enraged " + _base;
				return true;
			}
			WorldObject worldObject5 = LensItem("Resonant Lens");
			try
			{
				Globals.Core.Actions.ApplyItem(worldObject5.Id, worldObject3.Id);
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
			_resUsed = true;
			Util.WriteToChat("Dex: Resonant Lens on " + worldObject3.Name + ", then trying again.");
			Go(St.Resonant);
			return true;
		}
		case St.Resonant:
			if ((now - _stAt).TotalSeconds < 2.5)
			{
				Status = "Resonant Lens on " + ((worldObject2 != null) ? worldObject2.Name : _base);
				return true;
			}
			_idAt = DateTime.MinValue;
			_swingDone = now;
			Go(St.Lower);
			return true;
		default:
			return false;
		}
	}

	private static bool Lower(CombatEngine e, Settings s, WorldObject t, DateTime now)
	{
		bool flag = _idMax > 0 && _idMax <= 20;
		bool flag2 = Health(t.Id, (_swingDone > _corrAt) ? _swingDone : _corrAt, out var pct, out var cur, out var _);
		double num = 19.5;
		if ((now - _bounceAt).TotalSeconds < 15.0)
		{
			num -= 3.0;
		}
		_near = flag2 && pct < Math.Max(num + 12.0, _watch ? (s.DexHoldPct + 5f) : 0f);
		if (flag || (flag2 && pct < num))
		{
			if (_swinging)
			{
				EndSwing();
			}
			return StartLens(e, s, t, now);
		}
		if (flag2 && pct < _bestPct - 1.0)
		{
			_bestPct = pct;
			_bestAt = now;
		}
		if (_bestAt == DateTime.MinValue)
		{
			_bestAt = now;
		}
		if (!_watch && s.DexGiveUpSecs > 0 && (now - _bestAt).TotalSeconds > (double)s.DexGiveUpSecs)
		{
			if (_swinging)
			{
				EndSwing();
			}
			Skip("its health hasn't gone down in " + s.DexGiveUpSecs + " s - fighting it normally (add it to Never catch to always skip it)", 30);
			return false;
		}
		if (_watch)
		{
			if (flag2 && pct < (double)s.DexHoldPct)
			{
				Status = "Holding everything - " + t.Name + " at " + pct.ToString("0") + "% (lens under 20%)";
				return true;
			}
			Status = "Watching " + t.Name + (flag2 ? (" - " + pct.ToString("0") + "%") : "") + " (holding at " + s.DexHoldPct.ToString("0") + "%, lens under 20%)";
			return false;
		}
		if (_swinging)
		{
			if ((now - _swingAt).TotalSeconds > 3.0)
			{
				EndSwing();
			}
			Status = "Bonking " + t.Name;
			return true;
		}
		if (!flag2)
		{
			Status = "Checking " + t.Name + "'s health";
			return true;
		}
		if (cur < 0 && (now - _startAt).TotalSeconds < 6.0)
		{
			Status = "Identifying " + t.Name + " - " + pct.ToString("0") + "%";
			return true;
		}
		SpellLevel spellLevel = SpellBook.FindByName("Corruption I");
		if (s.DexCorruption && cur > 0 && cur > s.DexCorruptionAbove && SpellBook.IsKnown(spellLevel))
		{
			Status = "Corruption I on " + t.Name + " - " + pct.ToString("0") + "% (" + cur.ToString("N0") + ")";
			if ((now - _corrAt).TotalSeconds < 30.0)
			{
				return true;
			}
			if (!HoldCaster(e))
			{
				return true;
			}
			if (!Mode(CombatState.Magic))
			{
				return true;
			}
			try
			{
				Globals.Core.Actions.CastSpell(spellLevel.Id, t.Id);
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
			_corrAt = now;
			return true;
		}
		WorldObject worldObject = BatFor(cur, out var _);
		if (worldObject == null)
		{
			Skip("no bonk bat to bring it down", 5);
			return false;
		}
		if (!CombatEngine.IsWielded(worldObject.Id))
		{
			Status = "Equipping " + worldObject.Name;
			Wield(worldObject);
			return true;
		}
		if (!Mode(CombatState.Melee))
		{
			Status = "Melee mode";
			return true;
		}
		try
		{
			CM_Combat.Event_TargetedMeleeAttack((uint)t.Id, ATTACK_HEIGHT.LOW_ATTACK_HEIGHT, 0f);
		}
		catch (Exception ex2)
		{
			Util.LogError(ex2);
			return true;
		}
		_swinging = true;
		_swingAt = now;
		Status = "Bonking " + t.Name + " with " + worldObject.Name + " - " + pct.ToString("0") + "%" + ((cur >= 0) ? (" (" + cur.ToString("N0") + ")") : "");
		return true;
	}

	private static void EndSwing()
	{
		_swinging = false;
		_swingDone = DateTime.Now;
		_idAt = DateTime.MinValue;
		try
		{
			CM_Combat.Event_CancelAttack();
		}
		catch
		{
		}
	}

	private static void Wield(WorldObject item)
	{
		if (DateTime.Now - _equipAt < TimeSpan.FromSeconds(2.5))
		{
			return;
		}
		_equipAt = DateTime.Now;
		try
		{
			if (Globals.Core.Actions.CombatMode != CombatState.Peace)
			{
				Globals.Core.Actions.SetCombatMode(CombatState.Peace);
			}
			else
			{
				Session.Wield(item.Id);
			}
		}
		catch
		{
		}
	}

	private static bool Mode(CombatState m)
	{
		try
		{
			if (Globals.Core.Actions.CombatMode == m)
			{
				return true;
			}
			if (DateTime.Now - _equipAt < TimeSpan.FromSeconds(1.5) || DateTime.Now - _modeAt < TimeSpan.FromSeconds(1.5))
			{
				return false;
			}
			_modeAt = DateTime.Now;
			Globals.Core.Actions.SetCombatMode(m);
		}
		catch
		{
		}
		return false;
	}

	private static bool HoldCaster(CombatEngine e)
	{
		Settings settings = Settings();
		foreach (WeaponItem item in settings.Items)
		{
			if (item.Kind == WeaponKind.Caster && CombatEngine.IsWielded(item.Id))
			{
				return true;
			}
		}
		foreach (WeaponItem item2 in settings.Items)
		{
			if (item2.Kind == WeaponKind.Caster)
			{
				WorldObject worldObject = Globals.Core.WorldFilter[item2.Id];
				if (worldObject != null)
				{
					Status = "Equipping " + worldObject.Name + " for Corruption I";
					Wield(worldObject);
					return false;
				}
			}
		}
		return true;
	}

	private static void ApproachFrame()
	{
		if (!_approaching || _target == 0)
		{
			return;
		}
		WorldObject worldObject = Globals.Core.WorldFilter[_target];
		if (worldObject == null)
		{
			return;
		}
		double num = CombatEngine.Distance(worldObject);
		if (num < 0.0)
		{
			return;
		}
		if (num <= 2.0 || (_apBest >= 0.0 && num > _apBest + 0.5))
		{
			try
			{
				Globals.Core.Actions.SetAutorun(on: false);
			}
			catch
			{
			}
			_approaching = false;
		}
		else if (_apBest < 0.0 || num < _apBest)
		{
			_apBest = num;
		}
	}

	private static WorldObject Closest(CombatEngine e)
	{
		WorldObject result = null;
		double num = double.MaxValue;
		foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
		{
			if (item.ObjectClass == ObjectClass.Monster && e.IsHostileMonster(item))
			{
				double num2 = CombatEngine.Distance(item);
				if (num2 >= 0.0 && num2 < num)
				{
					num = num2;
					result = item;
				}
			}
		}
		return result;
	}

	private static bool StartLens(CombatEngine e, Settings s, WorldObject t, DateTime now)
	{
#if !RETAIL
		// (the lens goes to the monster named, not the closest one - no waiting for another monster to move off, which
		// kept swinging until it died)
		WorldObject worldObject = null;
#else
		WorldObject worldObject = Closest(e);
#endif
		if (CombatEngine.Distance(t) > 5.5 || (worldObject != null && worldObject.Id != t.Id))
		{
			_approachAt = now;
			_apBest = -1.0;
			_apBestAt = now;
			Go(St.Approach);
			return Approach(e, t, now);
		}
		return UseLens(s, t, now);
	}


	private static bool Approach(CombatEngine e, WorldObject t, DateTime now)
	{
#if !RETAIL
		WorldObject worldObject = null;
#else
		WorldObject worldObject = Closest(e);
#endif
		double num = CombatEngine.Distance(t);
		bool flag = num >= 0.0 && num <= 5.5 && (worldObject == null || worldObject.Id == t.Id);
		if (num >= 0.0 && (_apBest < 0.0 || num < _apBest - 0.3))
		{
			_apBest = num;
			_apBestAt = now;
		}
		bool flag2 = num >= 0.0 && num <= 6.0 && (now - _apBestAt).TotalSeconds > 0.8 && (worldObject == null || worldObject.Id == t.Id);
		if ((now - _approachAt).TotalSeconds > 10.0 && worldObject != null && worldObject.Id != t.Id)
		{
			if (_approaching)
			{
				try
				{
					Globals.Core.Actions.SetAutorun(on: false);
				}
				catch
				{
				}
				_approaching = false;
			}
			Log(t.Name + ": " + worldObject.Name + " stays closer - not using the lens");
			Go(St.Lower);
			return !_watch;
		}
		if ((flag | flag2) || (now - _approachAt).TotalSeconds > 10.0)
		{
			if (_approaching)
			{
				try
				{
					Globals.Core.Actions.SetAutorun(on: false);
				}
				catch
				{
				}
				_approaching = false;
			}
			return UseLens(Settings(), t, now);
		}
		bool flag3 = _apBest >= 0.0 && num > _apBest + 0.5;
		if (num >= 0.0 && ((num <= 2.0) | flag3) && !_approaching && !flag3)
		{
			Status = "Next to " + t.Name + " - waiting for " + ((worldObject != null) ? worldObject.Name : "the other one") + " to be farther than it";
			return true;
		}
		if (num >= 0.0 && ((num <= 2.0) | flag3))
		{
			try
			{
				Globals.Core.Actions.SetAutorun(on: false);
			}
			catch
			{
			}
			_approaching = false;
			if (!flag3)
			{
				Status = "Next to " + t.Name;
				return true;
			}
			_apBest = num;
			_facedAt = DateTime.MinValue;
		}
		try
		{
			double num2 = CombatEngine.TurnTo(t, CombatEngine.MyHeading());
			if (num2 > 20.0 && now - _facedAt > TimeSpan.FromMilliseconds(700L))
			{
				double num3 = Bearing(t);
				if (num3 >= 0.0)
				{
					Globals.Core.Actions.FaceHeading(num3, true);
				}
				_facedAt = now;
				_approaching = false;
			}
			else if (!_approaching && now - _facedAt > TimeSpan.FromMilliseconds(350L))
			{
				Globals.Core.Actions.SetAutorun(on: true);
				_approaching = true;
			}
		}
		catch
		{
		}
		Status = "Moving in on " + t.Name + " - " + num.ToString("0.0") + " m" + ((worldObject != null && worldObject.Id != t.Id) ? (" (" + worldObject.Name + " is closer)") : "");
		return true;
	}

	private static double Bearing(WorldObject obj)
	{
		try
		{
			WorldObject worldObject = Globals.Core.WorldFilter[Globals.Core.CharacterFilter.Id];
			CoordsObject coordsObject = obj.Coordinates();
			CoordsObject coordsObject2 = worldObject.Coordinates();
			double y = coordsObject.EastWest - coordsObject2.EastWest;
			double x = coordsObject.NorthSouth - coordsObject2.NorthSouth;
			double num = Math.Atan2(y, x) * 180.0 / Math.PI;
			return (num < 0.0) ? (num + 360.0) : num;
		}
		catch
		{
			return -1.0;
		}
	}

	private static string PickLens(Settings s)
	{
		if (AsheronFor(s, _shiny) && Lens("Asheron's Lens") > 0)
		{
			return "Asheron's Lens";
		}
		int num = Math.Max(0, Math.Min(Lenses.Length - 1, s.DexLens));
		List<int> list = new List<int>();
		if (s.DexLensFirst)
		{
			list.Add(num);
			for (int num2 = num - 1; num2 >= 0; num2--)
			{
				list.Add(num2);
			}
			for (int i = num + 1; i < Lenses.Length; i++)
			{
				list.Add(i);
			}
		}
		else
		{
			for (int j = 0; j < Lenses.Length; j++)
			{
				list.Add(j);
			}
		}
		foreach (int item in list)
		{
			if (Lens(Lenses[item]) > 0)
			{
				return Lenses[item];
			}
		}
		return null;
	}

	private static bool UseLens(Settings s, WorldObject t, DateTime now)
	{
		if (_readyAt == DateTime.MinValue || (now - _readyAt).TotalSeconds > 5.0)
		{
			_readyAt = now;
		}
		if (_eng != null && _eng.ActionInProgress && (now - _readyAt).TotalSeconds < 3.0)
		{
			Status = "Waiting to use the lens on " + t.Name + " - holding everything";
			return true;
		}
		_readyAt = DateTime.MinValue;
		string text = PickLens(s);
		if (text == null)
		{
			Skip("out of siphon lenses", 30);
			return false;
		}
		WorldObject worldObject = LensItem(text);
		if (worldObject == null)
		{
			Pack(force: true);
			return true;
		}
		try
		{
			Globals.Core.Actions.ApplyItem(worldObject.Id, t.Id);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		_lastLens = text;
		_lensId = worldObject.Id;
		_spam = 1;
		Log(text + " -> " + t.Name + " [" + t.Id + "] at " + CombatEngine.Distance(t).ToString("0.0") + " m");
		_sentAt = now;
		_packAt = DateTime.MinValue;
		Go(St.Lens);
		Status = "Siphoning " + t.Name + " with " + text;
		return true;
	}

	public static void Reset()
	{
		if (_target != 0)
		{
			Finish(ok: false);
		}
		_doneIds.Clear();
		_skip.Clear();
		_caughtNow.Clear();
		TurnIn.Stop();
	}
}
