using System;

namespace MelkTank.Pets;

public class PetRecord
{
	public int DeviceId { get; set; }

	public string Name { get; set; }

	public int LiveWorldId { get; set; }

	public int LiveWorldGuid { get; set; }

	public bool Enabled { get; set; }

	public bool MatchLogged { get; set; }

	public int UsesRemaining { get; set; }

	public bool NeedsRecharge { get; set; }

	public DateTime LastSummoned { get; set; }

	public DateTime NeedsRechargeSince { get; set; }

	public int PotencyApplied { get; set; }

	public int BondLevel { get; set; }

	public DamageElement Element { get; set; }

	public PetRecord(int deviceId, string name)
	{
		DeviceId = deviceId;
		Name = name;
		LiveWorldId = 0;
		LiveWorldGuid = 0;
		Enabled = true;
		MatchLogged = false;
		UsesRemaining = -1;
		NeedsRecharge = false;
		NeedsRechargeSince = DateTime.MinValue;
		LastSummoned = DateTime.MinValue;
		PotencyApplied = 0;
		BondLevel = 0;
		Element = Elements.ParseFromName(name);
	}
}
