using System;

namespace MelkTank.Pets;

public static class Elements
{
	private static readonly DamageElement[] Cycle = new DamageElement[9]
	{
		DamageElement.None,
		DamageElement.Nether,
		DamageElement.Bludgeon,
		DamageElement.Slash,
		DamageElement.Pierce,
		DamageElement.Fire,
		DamageElement.Cold,
		DamageElement.Acid,
		DamageElement.Lightning
	};

	public static DamageElement Next(DamageElement current)
	{
		for (int i = 0; i < Cycle.Length; i++)
		{
			if (Cycle[i] == current)
			{
				return Cycle[(i + 1) % Cycle.Length];
			}
		}
		return DamageElement.None;
	}

	public static DamageElement ParseFromName(string name)
	{
		if (string.IsNullOrEmpty(name))
		{
			return DamageElement.None;
		}
		for (int i = 1; i < Cycle.Length; i++)
		{
			if (name.IndexOf(Cycle[i].ToString(), StringComparison.OrdinalIgnoreCase) >= 0)
			{
				return Cycle[i];
			}
		}
		return DamageElement.None;
	}

	public static DamageElement Parse(string s)
	{
		if (string.IsNullOrEmpty(s))
		{
			return DamageElement.None;
		}
		try
		{
			return (DamageElement)Enum.Parse(typeof(DamageElement), s, ignoreCase: true);
		}
		catch
		{
			return DamageElement.None;
		}
	}

	public static string Abbrev(DamageElement e)
	{
		return e switch
		{
			DamageElement.None => "-", 
			DamageElement.Nether => "Neth", 
			DamageElement.Bludgeon => "Blud", 
			DamageElement.Slash => "Slsh", 
			DamageElement.Pierce => "Pier", 
			DamageElement.Fire => "Fire", 
			DamageElement.Cold => "Cold", 
			DamageElement.Acid => "Acid", 
			DamageElement.Lightning => "Ltng", 
			_ => e.ToString(), 
		};
	}
}
