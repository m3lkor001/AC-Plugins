using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Xml;
using Decal.Adapter;
using Decal.Adapter.Wrappers;

namespace MelkTank.Pets;

public class PetSummoner
{
	[UnmanagedFunctionPointer(CallingConvention.StdCall)]
	private delegate bool IdentifyFunc(int objectId);

	private const int SUMMON_COOLDOWN_MS = 8000;

	private const int RECHARGE_FORCE_TIMEOUT_MS = 90000;

	private static readonly TimeSpan DEFERRED_SUMMON_CHECK_DELAY = TimeSpan.FromMilliseconds(750L);

	private const string SAVAGE_ECHO_NAME = "Savage Echo";

	private readonly Settings _s;

	private readonly Action _saveAll;

	private string _charKey;

	private readonly Dictionary<int, PetRecord> _petRecords = new Dictionary<int, PetRecord>();

	private readonly HashSet<int> _livePetIds = new HashSet<int>();

	private readonly Dictionary<int, DateTime> _cooldowns = new Dictionary<int, DateTime>();

	private readonly Dictionary<int, DateTime> _pendingRemovalRetry = new Dictionary<int, DateTime>();

	public bool UnsummonOnClear;

	public bool RechargeEnabled;

	public int RechargeThreshold = 5;

	public bool ForceRechargeInCombat;

	private bool _forceIdEnabled = true;

	private DateTime _lastScan = DateTime.MinValue;

	private DateTime _lastSummonCheck = DateTime.MinValue;

	private DateTime _deferredSummonCheckAt = DateTime.MinValue;

	private int _activeDeviceId;

	private int _rechargingDeviceId;

	private int _rechargeStage;

	private int _rechargeStartUses = -1;

	private DateTime _rechargeStageAt = DateTime.MinValue;

	private int _rechargePrevCombatMode = 1;

	private int _pendingSummonId;

	public int SelectedEchoDeviceId;

	private int _echoBaselineCount;

	private int _echoesSpentSinceReset;

	private bool _echoBaselineSet;

	private DateTime _echoRateStart = DateTime.Now;

	public bool DebugDumps;

	private int _pendingDumpDeviceId;

	private string _pendingDumpPetName;

	private static FieldInfo _extInst;

	private static bool _extLooked;

	private static readonly TimeSpan PET_DEATH_WAIT = TimeSpan.FromSeconds(10L);

	private DateTime _petDiedAt = DateTime.MinValue;

	private static readonly Regex PotencyRegex = new Regex("Potency:\\s*(\\d+)\\s*stored", RegexOptions.IgnoreCase);

	private static readonly Regex BondLevelRegex = new Regex("Bond Level:\\s*([\\d,]+)", RegexOptions.IgnoreCase);

	private readonly HashSet<int> _hintedMissingId = new HashSet<int>();

	private readonly Dictionary<int, string> _lastSeenDescription = new Dictionary<int, string>();

	private readonly Dictionary<int, DateTime> _pendingRefreshUntil = new Dictionary<int, DateTime>();

	private static readonly TimeSpan PENDING_REFRESH_TIMEOUT = TimeSpan.FromSeconds(45L);

	private const int ID_FUNCTION_MASK = 436554;

	private IdentifyFunc _identifyFunc;

	private readonly Queue<int> _forceIdQueue = new Queue<int>();

	private readonly HashSet<int> _forceIdQueued = new HashSet<int>();

	private DateTime _nextForceIdSend = DateTime.MinValue;

	private static readonly TimeSpan FORCE_ID_SPACING = TimeSpan.FromSeconds(20L);

	private const int ITEM_USE_DONE_EVENT_ID = 455;

	private int _lastUseItemDeviceId;

	private DateTime _lastUseItemAt = DateTime.MinValue;

	private static readonly TimeSpan USE_ITEM_CORRELATION_WINDOW = TimeSpan.FromSeconds(3L);

	private readonly Dictionary<int, int> _dispatchTypeCounts = new Dictionary<int, int>();

	private readonly Dictionary<int, int> _dispatchSubEventCounts = new Dictionary<int, int>();

	private DateTime _deviceBusyUntil = DateTime.MinValue;

	private static readonly TimeSpan DeviceRecovery = TimeSpan.FromMilliseconds(200L);

	private DateTime _waitTankSince = DateTime.MinValue;

	private const string PauseName = "Pet summoner";

	private string _tankStatus = "";

	private DateTime _tankStatusAt = DateTime.MinValue;

	private static readonly TimeSpan PET_COMBAT_LOCK = TimeSpan.FromSeconds(7.5);

	private static readonly TimeSpan DISMISS_RETRY = TimeSpan.FromSeconds(4L);
	// one dismissal, however many tries it takes: said once (and once more if the game keeps refusing)
	private int _dismissTries;
	private int _dismissFor;
	// an essence's cooldown after it's used (summoning or dismissing): a bonded one's is 10 s at the longest (after its
	// pet dies); a fresh, unbonded one keeps to the Cooldown Duration it shows (45 s). A dismissal waits it out instead of
	// trying every few seconds; refused anyway ("used this item too recently"), it tries again a few seconds later
	private static readonly TimeSpan DefaultEssenceCooldown = TimeSpan.FromSeconds(10.0);
	private TimeSpan EssenceCooldown(int deviceId)
	{
		try
		{
			WorldObject o = Core.WorldFilter[deviceId];
			if (o != null && MelkTank.Loot.LootMatcher.Long(o, 33) == 0)
			{
				double secs = MelkTank.Loot.LootMatcher.Dbl(o, 167);
				if (secs > 0.0 && secs < 600.0)
				{
					return TimeSpan.FromSeconds(secs);
				}
			}
		}
		catch
		{
		}
		return DefaultEssenceCooldown;
	}

	// the essence the pet that's out came from, by the pet's name ("<you>'s <pet>") - not the one last used: a pet out from
	// another essence (summoned by hand, or the last summon refused) was "dismissed" with the wrong essence, which
	// summoned that one's pet in its place
	private int DeviceForLivePet()
	{
		try
		{
			string me = Core.CharacterFilter.Name;
			foreach (int id in _livePetIds)
			{
				foreach (PetRecord rec in _petRecords.Values)
				{
					if (rec.LiveWorldId == id)
					{
						return rec.DeviceId;
					}
				}
				WorldObject obj = Core.WorldFilter[id];
				if (obj == null || obj.Name.Length <= me.Length + 3)
				{
					continue;
				}
				string pet = obj.Name.Substring(me.Length + 3);
				foreach (PetRecord rec in _petRecords.Values)
				{
					if (rec.Name.IndexOf(pet, StringComparison.OrdinalIgnoreCase) >= 0)
					{
						return rec.DeviceId;
					}
				}
			}
		}
		catch
		{
		}
		return 0;
	}
	private bool _saidCooling;
	private bool CoolingDown(int deviceId, out TimeSpan left)
	{
		left = TimeSpan.Zero;
		if (!_cooldowns.TryGetValue(deviceId, out var used))
		{
			return false;
		}
		left = used + EssenceCooldown(deviceId) - DateTime.Now;
		return left > TimeSpan.Zero;
	}

	private DateTime _lastPetCombatAt = DateTime.MinValue;

	private DateTime _lastDismissAt = DateTime.MinValue;

	private bool _dismissWanted;

	private bool _loaded;

	public static PetSummoner Current { get; private set; }

	private static CoreManager Core => Globals.Core;

	public bool ForceIdEnabled => _forceIdEnabled;

	public int EchoCount { get; private set; }

	public int SpiritCount { get; private set; }

	public int EchoRate
	{
		get
		{
			double totalHours = (DateTime.Now - _echoRateStart).TotalHours;
			return (totalHours > 1.0 / 60.0) ? ((int)Math.Round((double)(EchoCount - _echoBaselineCount + _echoesSpentSinceReset) / totalHours)) : 0;
		}
	}

	public static bool ExternalLoaded
	{
		get
		{
			try
			{
				if (!_extLooked)
				{
					_extLooked = true;
					Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
					foreach (Assembly assembly in assemblies)
					{
						if (assembly.FullName.StartsWith("MelksPetSummoner,"))
						{
							Type type = assembly.GetType("MelksPetSummoner.PluginCore");
							if (type != null)
							{
								_extInst = type.GetField("_instance", BindingFlags.Static | BindingFlags.NonPublic);
							}
						}
					}
				}
				return _extInst != null && _extInst.GetValue(null) != null;
			}
			catch
			{
				return false;
			}
		}
	}

	/// <summary>Why no pet is being summoned just now ("" when nothing's in the way) - shown by the Pets tab.</summary>
	public string Idle = "";

	public bool Enabled => _s.MelksPetEnabled && _s.MasterEnabled && !ExternalLoaded && !(Breeding.Current?.HoldSummons ?? false);

	public bool DispatchLogOn { get; private set; }

	public static bool DeviceWanted
	{
		get
		{
			PetSummoner current = Current;
			return current != null && current._waitTankSince != DateTime.MinValue && (DateTime.Now - current._waitTankSince).TotalSeconds < 2.0;
		}
	}

	public static bool DeviceBusy
	{
		get
		{
			PetSummoner current = Current;
			return current != null && DateTime.Now < current._deviceBusyUntil;
		}
	}

	private double RangeDist => PluginCore.PetRange();

	public List<PetRecord> Pets => new List<PetRecord>(_petRecords.Values);

	public bool AnyOut => _livePetIds.Count > 0;

	public bool PetFighting => DateTime.Now - _lastPetCombatAt < PET_COMBAT_LOCK;

	private static string SettingsPath => Util.FullPath("MelkTank_Pets.xml");

	public PetSummoner(Settings s, Action saveAll)
	{
		_s = s;
		_saveAll = saveAll;
	}

	public void Start(string charKey)
	{
		_charKey = charKey;
		Current = this;
		LoadSettings();
		try
		{
			object data = AppDomain.CurrentDomain.GetData("MelkTank.PetActive");
			if (data is int)
			{
				_activeDeviceId = (int)data;
			}
		}
		catch
		{
		}
		AppDomain.CurrentDomain.SetData("MelkTank.PetActive", null);
		_echoRateStart = DateTime.Now;
		_echoBaselineSet = false;
		_echoesSpentSinceReset = 0;
		if (_forceIdEnabled)
		{
			EnsureIdentifyFunctionInitialized();
			foreach (int key in _petRecords.Keys)
			{
				QueueForceId(key);
			}
		}
		Core.WorldFilter.CreateObject += OnCreateObject;
		Core.WorldFilter.ReleaseObject += OnReleaseObject;
		Core.EchoFilter.ServerDispatch += OnServerDispatch;
		if (ExternalLoaded)
		{
			Util.WriteToChat("Pets: the separate MelksPetSummoner is still loaded - MelkTank's pet summoning stays off. Untick it in Decal and relog to use the Pets tab.");
		}
	}

	public void Stop(bool hotReload)
	{
		try
		{
			Core.WorldFilter.CreateObject -= OnCreateObject;
			Core.WorldFilter.ReleaseObject -= OnReleaseObject;
			Core.EchoFilter.ServerDispatch -= OnServerDispatch;
		}
		catch
		{
		}
		if (_rechargingDeviceId != 0)
		{
			try
			{
				Core.Actions.SetCombatMode((CombatState)_rechargePrevCombatMode);
			}
			catch
			{
			}
			PluginCore.Resume("Pet summoner");
		}
		if (hotReload && _activeDeviceId != 0)
		{
			AppDomain.CurrentDomain.SetData("MelkTank.PetActive", _activeDeviceId);
		}
		Save();
		if (Current == this)
		{
			Current = null;
		}
	}

	public void Tick()
	{
		Guard(MonsterLog.Tick);
		if (ExternalLoaded)
		{
			return;
		}
		DateTime now = DateTime.Now;
		if (_deferredSummonCheckAt != DateTime.MinValue && now >= _deferredSummonCheckAt)
		{
			_deferredSummonCheckAt = DateTime.MinValue;
			if (Enabled)
			{
				_lastSummonCheck = now;
				Guard(CheckAndReSummonPets);
			}
		}
		if ((now - _lastScan).TotalMilliseconds >= 5000.0)
		{
			_lastScan = now;
			if (ServerMode.Ilt)
			{
				Guard(UpdateEchoTracking);
			}
			Guard(UpdateSpiritCount);
			Guard(UpdatePetStatsFromInventory);
			Guard(UpdateUsesFromInventory);
			Guard(ProcessForceIdQueue);
			Guard(ProcessPendingRemovals);
			if (ServerMode.Ilt)
			{
				Guard(CheckPendingPotencyDump);
			}
		}
		if (Enabled && (now - _lastSummonCheck).TotalMilliseconds >= 1000.0)
		{
			_lastSummonCheck = now;
			Guard(CheckAndReSummonPets);
		}
		else if (!Enabled && _rechargingDeviceId != 0)
		{
			Guard(ProcessRechargeInProgress);
		}
	}

	private static void Guard(Action a)
	{
		try
		{
			a();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public void OnChat(string text)
	{
		if (!string.IsNullOrEmpty(text))
		{
			text = text.Trim();
			if (text.StartsWith("[Pet] ") && text.IndexOf(Core.CharacterFilter.Name + "'s ", StringComparison.Ordinal) > 0)
			{
				_lastPetCombatAt = DateTime.Now;
			}
			// an essence used too soon after the last time: its cooldown is longer than we had it - waited out from now on
			if (text.IndexOf("used this item too recently", StringComparison.OrdinalIgnoreCase) >= 0 && _lastUseItemAt != DateTime.MinValue && DateTime.Now - _lastUseItemAt < TimeSpan.FromSeconds(3.0))
			{
				_lastDismissAt = DateTime.Now;
			}
			if (text.IndexOf("Your combat pet ", StringComparison.Ordinal) >= 0 && text.EndsWith(" has died.", StringComparison.Ordinal))
			{
				_petDiedAt = DateTime.Now;
				Util.WriteToChat("Pets: pet died - summoning again in " + PET_DEATH_WAIT.TotalSeconds.ToString("0") + " s (fighting on meanwhile).");
			}
		}
	}

	private void UpdateSpiritCount()
	{
		int num = 0;
		foreach (WorldObject item in InvCache.All())
		{
			if (item.Name.Equals("Encapsulated Spirit", StringComparison.OrdinalIgnoreCase))
			{
				try
				{
					num += item.Values(LongValueKey.StackCount);
				}
				catch
				{
					num++;
				}
			}
		}
		SpiritCount = num;
	}

	private void UpdateEchoTracking()
	{
		EchoCount = GetEchoInventoryCount();
		if (!_echoBaselineSet)
		{
			_echoBaselineCount = EchoCount;
			_echoBaselineSet = true;
		}
	}

	public void ResetEchoRate()
	{
		_echoBaselineCount = GetEchoInventoryCount();
		_echoBaselineSet = true;
		_echoesSpentSinceReset = 0;
		_echoRateStart = DateTime.Now;
		Util.WriteToChat("Pets: echoes/hr reset.");
	}

	private void UpdatePetStatsFromInventory()
	{
		foreach (PetRecord value in _petRecords.Values)
		{
			WorldObject worldObject = Core.WorldFilter[value.DeviceId];
			if (worldObject != null)
			{
				UpdatePotencyAndBondLevel(value, worldObject);
			}
		}
	}

	private void UpdateUsesFromInventory()
	{
		foreach (PetRecord value in _petRecords.Values)
		{
			WorldObject worldObject = Core.WorldFilter[value.DeviceId];
			if (worldObject != null)
			{
				try
				{
					value.UsesRemaining = worldObject.Values(LongValueKey.UsesRemaining);
				}
				catch
				{
				}
			}
		}
	}

	private void MarkPendingRefresh(int deviceId)
	{
		if (deviceId != 0)
		{
			try
			{
				WorldObject worldObject = Core.WorldFilter[deviceId];
				_lastSeenDescription[deviceId] = worldObject?.Values(StringValueKey.FullDescription) ?? "";
			}
			catch
			{
				_lastSeenDescription[deviceId] = "";
			}
			_pendingRefreshUntil[deviceId] = DateTime.Now + PENDING_REFRESH_TIMEOUT;
		}
	}

	private void UpdatePotencyAndBondLevel(PetRecord rec, WorldObject device)
	{
		try
		{
			string text = device.Values(StringValueKey.FullDescription);
			if (string.IsNullOrEmpty(text))
			{
				if (_forceIdEnabled)
				{
					QueueForceId(rec.DeviceId);
				}
				else if (_hintedMissingId.Add(rec.DeviceId))
				{
					Util.WriteToChat("Pets: " + rec.Name + ": level / potency show once it's been looked at (select it once, or turn Force ID on in Pets > Settings).");
				}
				return;
			}
			_hintedMissingId.Remove(rec.DeviceId);
			if (_pendingRefreshUntil.TryGetValue(rec.DeviceId, out var value))
			{
				_lastSeenDescription.TryGetValue(rec.DeviceId, out var value2);
				if ((value2 == null || !(text != value2)) && DateTime.Now < value)
				{
					return;
				}
				_pendingRefreshUntil.Remove(rec.DeviceId);
				_lastSeenDescription.Remove(rec.DeviceId);
			}
			Match match = PotencyRegex.Match(text);
			if (match.Success && int.TryParse(match.Groups[1].Value, out var result))
			{
				rec.PotencyApplied = result;
			}
			match = BondLevelRegex.Match(text);
			if (match.Success && int.TryParse(match.Groups[1].Value.Replace(",", ""), out result))
			{
				rec.BondLevel = result;
			}
		}
		catch
		{
		}
	}

	private void CheckPendingPotencyDump()
	{
		if (_pendingDumpDeviceId == 0)
		{
			return;
		}
		try
		{
			WorldObject worldObject = Core.WorldFilter[_pendingDumpDeviceId];
			if (worldObject != null)
			{
				ObjectDump.DumpObjectValues(worldObject, "AFTER apply Savage Echo to " + (_pendingDumpPetName ?? "pet"), full: false);
			}
		}
		finally
		{
			_pendingDumpDeviceId = 0;
			_pendingDumpPetName = null;
		}
	}

	private void EnsureIdentifyFunctionInitialized()
	{
		if (_identifyFunc == null)
		{
			_identifyFunc = (int id) => true;
		}
	}

	public void SetForceId(bool on)
	{
		_forceIdEnabled = on;
		if (on)
		{
			EnsureIdentifyFunctionInitialized();
			foreach (int key in _petRecords.Keys)
			{
				QueueForceId(key);
			}
		}
		else
		{
			_forceIdQueue.Clear();
			_forceIdQueued.Clear();
		}
		Util.WriteToChat("Pets: Force ID " + (on ? "on" : "off") + ".");
		Save();
	}

	private void QueueForceId(int deviceId)
	{
		if (_forceIdEnabled && deviceId != 0 && _forceIdQueued.Add(deviceId))
		{
			_forceIdQueue.Enqueue(deviceId);
		}
	}

	private void ProcessForceIdQueue()
	{
		if (!_forceIdEnabled || _forceIdQueue.Count == 0 || DateTime.Now < _nextForceIdSend)
		{
			return;
		}
		int num = _forceIdQueue.Dequeue();
		_forceIdQueued.Remove(num);
		WorldObject worldObject = Core.WorldFilter[num];
		if (worldObject != null)
		{
			EnsureIdentifyFunctionInitialized();
			if (_identifyFunc != null)
			{
				Util.RequestId(worldObject.Id);
				_nextForceIdSend = DateTime.Now + FORCE_ID_SPACING;
			}
		}
	}

	private void OnCreateObject(object sender, CreateObjectEventArgs e)
	{
		try
		{
			WorldObject worldObject = e.New;
			if (worldObject.ObjectClass != ObjectClass.Monster)
			{
				return;
			}
			if (!IsPetObject(worldObject))
			{
				if (!IsLikelyOtherPlayersPet(worldObject))
				{
					MonsterLog.OnMonster(worldObject);
				}
				if (!IsLikelyOtherPlayersPet(worldObject) && Enabled)
				{
					_deferredSummonCheckAt = DateTime.Now + DEFERRED_SUMMON_CHECK_DELAY;
				}
			}
			else
			{
				_livePetIds.Add(worldObject.Id);
				CorrelateNewPet(worldObject);
			}
		}
		catch
		{
		}
	}

	private void OnReleaseObject(object sender, ReleaseObjectEventArgs e)
	{
		try
		{
			int id = e.Released.Id;
			if (!_livePetIds.Remove(id))
			{
				return;
			}
			DeviceDone();
			if (_dismissFor != 0)
			{
				_cooldowns[_dismissFor] = DateTime.Now;
			}
			_dismissFor = 0;
			foreach (PetRecord value in _petRecords.Values)
			{
				if (value.LiveWorldId == id)
				{
					value.LiveWorldId = 0;
					value.LiveWorldGuid = 0;
					value.MatchLogged = false;
					if (_activeDeviceId == value.DeviceId && _pendingSummonId == 0)
					{
						_activeDeviceId = 0;
					}
				}
			}
			if (!ExternalLoaded)
			{
				Util.WriteToChat("Pets: pet left." + ((_pendingSummonId != 0) ? " Switching pet..." : ""));
			}
		}
		catch
		{
		}
	}

	private void CorrelateNewPet(WorldObject obj)
	{
		if (_activeDeviceId == 0)
		{
			string value = obj.Name.Substring(Core.CharacterFilter.Name.Length + 3);
			foreach (PetRecord value3 in _petRecords.Values)
			{
				if (value3.Name.IndexOf(value, StringComparison.OrdinalIgnoreCase) >= 0)
				{
					_activeDeviceId = value3.DeviceId;
					break;
				}
			}
			if (_activeDeviceId == 0)
			{
				return;
			}
		}
		if (!_petRecords.TryGetValue(_activeDeviceId, out var value2) || value2.LiveWorldId == obj.Id)
		{
			return;
		}
		value2.LiveWorldId = obj.Id;
		value2.LiveWorldGuid = obj.Id;
		DeviceDone();
		if (!value2.MatchLogged)
		{
			value2.MatchLogged = true;
			if (!ExternalLoaded)
			{
				Util.WriteToChat("Pets: " + obj.Name + " is out.");
			}
		}
	}

	private void OnServerDispatch(object sender, NetworkMessageEventArgs e)
	{
		try
		{
			int value;
			if (DispatchLogOn)
			{
				_dispatchTypeCounts.TryGetValue(e.Message.Type, out value);
				_dispatchTypeCounts[e.Message.Type] = value + 1;
			}
			if (e.Message.Type == 63408)
			{
				int num = e.Message.Value<int>("event");
				if (DispatchLogOn)
				{
					_dispatchSubEventCounts.TryGetValue(num, out value);
					_dispatchSubEventCounts[num] = value + 1;
				}
				if (num == 455 && _lastUseItemDeviceId != 0 && DateTime.Now - _lastUseItemAt <= USE_ITEM_CORRELATION_WINDOW)
				{
					_cooldowns[_lastUseItemDeviceId] = DateTime.Now;
					_lastUseItemDeviceId = 0;
				}
			}
		}
		catch
		{
		}
	}

	public void SetDispatchLog(bool on)
	{
		DispatchLogOn = on;
		if (on)
		{
			_dispatchTypeCounts.Clear();
			_dispatchSubEventCounts.Clear();
		}
		Util.WriteToChat("Dispatch log " + (on ? "on - counting server message types. Do what you're chasing, then click Report." : "off."));
	}

	public void ReportDispatchLog()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendLine("============================================================");
		stringBuilder.AppendLine(DateTime.Now.ToString() + "   Dispatch log report");
		stringBuilder.AppendLine("-- Message.Type counts --");
		foreach (KeyValuePair<int, int> dispatchTypeCount in _dispatchTypeCounts)
		{
			stringBuilder.AppendLine("  0x" + dispatchTypeCount.Key.ToString("X") + "  x" + dispatchTypeCount.Value);
		}
		stringBuilder.AppendLine("-- 0xF7B0 'event' sub-ID counts --");
		foreach (KeyValuePair<int, int> dispatchSubEventCount in _dispatchSubEventCounts)
		{
			stringBuilder.AppendLine("  event=0x" + dispatchSubEventCount.Key.ToString("X") + "  x" + dispatchSubEventCount.Value);
		}
		stringBuilder.AppendLine();
		Util.AppendShared(Util.FullPath("MelkTank_DispatchLog.txt"), stringBuilder.ToString());
		Util.WriteToChat("Dispatch log: wrote " + _dispatchTypeCounts.Count + " type(s), " + _dispatchSubEventCounts.Count + " 0xF7B0 event(s) to MelkTank_DispatchLog.txt.");
	}

	private void DeviceDone()
	{
		if (DateTime.Now < _deviceBusyUntil)
		{
			_deviceBusyUntil = DateTime.Now + DeviceRecovery;
		}
	}

	private bool TankLetsMeGo()
	{
		if (!PluginCore.ActionInProgress() || (_waitTankSince != DateTime.MinValue && (DateTime.Now - _waitTankSince).TotalSeconds > 1.0))
		{
			_waitTankSince = DateTime.MinValue;
			return true;
		}
		if (_waitTankSince == DateTime.MinValue)
		{
			_waitTankSince = DateTime.Now;
		}
		return false;
	}

	public static string TankStatus()
	{
		try
		{
			PetSummoner current = Current;
			if (current == null || ExternalLoaded)
			{
				return "";
			}
			if ((DateTime.Now - current._tankStatusAt).TotalSeconds < 1.0)
			{
				return current._tankStatus;
			}
			current._tankStatusAt = DateTime.Now;
			bool flag = current._livePetIds.Count > 0;
			DamageElement e = DamageElement.None;
			bool flag2 = false;
			if (flag)
			{
				if (current._activeDeviceId != 0 && current._petRecords.TryGetValue(current._activeDeviceId, out var value) && value.LiveWorldId != 0 && current._livePetIds.Contains(value.LiveWorldId))
				{
					e = value.Element;
					flag2 = true;
				}
				else
				{
					foreach (PetRecord value2 in current._petRecords.Values)
					{
						if (value2.LiveWorldId != 0 && current._livePetIds.Contains(value2.LiveWorldId))
						{
							e = value2.Element;
							flag2 = true;
							break;
						}
					}
				}
			}
			string text;
			if (flag2)
			{
				text = ShortElement(e);
			}
			else if (current.Enabled)
			{
				text = (current.MonstersInRange(current.RangeDist) ? ShortElement(current.GetTargetElement()) : "None");
			}
			else
			{
				text = "Off";
			}
			if (text != "Off" && text != "None")
			{
				text += (flag ? " IW" : " Aw");
			}
			else if ((text == "None") & flag)
			{
				text += " IW";
			}
			current._tankStatus = text;
			return text;
		}
		catch
		{
			return "";
		}
	}

	private static string ShortElement(DamageElement e)
	{
		return e switch
		{
			DamageElement.Nether => "Neth", 
			DamageElement.Bludgeon => "Bldg", 
			DamageElement.Slash => "Slsh", 
			DamageElement.Pierce => "Prce", 
			DamageElement.Fire => "Fire", 
			DamageElement.Cold => "Cold", 
			DamageElement.Acid => "Acid", 
			DamageElement.Lightning => "Ltng", 
			_ => "Any", 
		};
	}

	private void CheckAndReSummonPets()
	{
		Idle = "";
		RefreshLivePetSnapshot();
		UpdateUsesFromInventory();
		if (_dismissWanted)
		{
			if (_livePetIds.Count != 0)
			{
				TryDismissActivePet();
				return;
			}
			_dismissWanted = false;
		}
		if (Dex.HoldPets)
		{
			Idle = "held while the Dex catches";
			if (_livePetIds.Count > 0 && !PetFighting)
			{
				TryDismissActivePet();
			}
			return;
		}
		if (UnsummonOnClear && _livePetIds.Count > 0 && !MonstersInRange(RangeDist))
		{
			TryDismissActivePet();
			return;
		}
		if (RechargeEnabled)
		{
			if (_rechargingDeviceId != 0)
			{
				Idle = "recharging";
				ProcessRechargeInProgress();
				return;
			}
			foreach (PetRecord value4 in _petRecords.Values)
			{
				if (!value4.Enabled || value4.UsesRemaining < 0)
				{
					continue;
				}
				if (value4.NeedsRecharge && value4.UsesRemaining >= RechargeThreshold)
				{
					value4.NeedsRecharge = false;
					value4.NeedsRechargeSince = DateTime.MinValue;
					continue;
				}
				if (value4.UsesRemaining < RechargeThreshold && !value4.NeedsRecharge)
				{
					value4.NeedsRecharge = true;
					value4.NeedsRechargeSince = DateTime.Now;
					Util.WriteToChat("Pets: " + value4.Name + " has " + value4.UsesRemaining + " uses left - recharging when clear.");
				}
				if (!value4.NeedsRecharge)
				{
					continue;
				}
				if (PluginCore.PetRechargeHold())
				{
					break;
				}
				bool flag = ForceRechargeInCombat || !MonstersInRange(RangeDist);
				bool flag2 = !flag && value4.NeedsRechargeSince != DateTime.MinValue && (DateTime.Now - value4.NeedsRechargeSince).TotalMilliseconds >= 90000.0;
				if (!(flag | flag2))
				{
					continue;
				}
				if (flag2)
				{
					Util.WriteToChat("Pets: " + value4.Name + " has waited a while to recharge with no clear moment - doing it now.");
				}
				BeginRecharge(value4);
				return;
			}
		}
		// (a monster only pets can hurt near: the pet comes for it whatever holds it back otherwise)
		bool petOnlyNear = PetOnlyInRange(RangeDist);
		if ((PluginCore.PetHold() && !petOnlyNear) || DateTime.Now - _petDiedAt < PET_DEATH_WAIT)
		{
			Idle = DateTime.Now - _petDiedAt < PET_DEATH_WAIT ? "pet died - waiting" : PluginCore.PetHoldWhy();
			return;
		}
		if (_pendingSummonId != 0)
		{
			if (_livePetIds.Count > 0)
			{
				TryDismissActivePet();
				return;
			}
			if (_petRecords.TryGetValue(_pendingSummonId, out var value))
			{
				WorldObject worldObject = Core.WorldFilter[value.DeviceId];
				if (worldObject != null)
				{
					if (DoSummon(value, worldObject))
					{
						_pendingSummonId = 0;
					}
					return;
				}
			}
			_pendingSummonId = 0;
		}
		else
		{
			if (!MonstersInRange(RangeDist))
			{
				Idle = "no monster within " + RangeDist.ToString("0") + " m";
				return;
			}
			DamageElement targetElement = GetTargetElement();
			if (_activeDeviceId != 0 && _petRecords.TryGetValue(_activeDeviceId, out var value2) && value2.Enabled && !value2.NeedsRecharge && value2.LiveWorldId != 0 && _livePetIds.Contains(value2.LiveWorldId) && (targetElement == DamageElement.None || value2.Element == targetElement))
			{
				return;
			}
			PetRecord petRecord = ChooseBestPetForSummon(targetElement);
			if (petRecord == null || (_cooldowns.TryGetValue(petRecord.DeviceId, out var value3) && (DateTime.Now - value3).TotalMilliseconds < 8000.0))
			{
				Idle = petRecord == null ? "no pet ticked On (or all need recharging)" : "essence cooling down";
				return;
			}
			WorldObject worldObject2 = Core.WorldFilter[petRecord.DeviceId];
			if (worldObject2 == null)
			{
				Idle = petRecord.Name + " isn't in the pack";
				return;
			}
			if (_livePetIds.Count > 0 && _activeDeviceId != petRecord.DeviceId)
			{
				if (!(DateTime.Now - _lastPetCombatAt < PET_COMBAT_LOCK))
				{
					TryDismissActivePet();
				}
			}
			else
			{
				DoSummon(petRecord, worldObject2);
			}
		}
	}

	private DamageElement GetTargetElement()
	{
		try
		{
			WorldObject worldObject = null;
			double num = double.MaxValue;
			double rangeDist = RangeDist;
			foreach (WorldObject item in Core.WorldFilter.GetLandscape())
			{
				if (item.ObjectClass == ObjectClass.Monster && !_livePetIds.Contains(item.Id) && !IsPetObject(item) && !IsLikelyOtherPlayersPet(item))
				{
					double distance = GetDistance(item);
					if (!(distance < 0.0) && !(distance > rangeDist) && distance < num)
					{
						num = distance;
						worldObject = item;
					}
				}
			}
			if (worldObject == null)
			{
				return DamageElement.None;
			}
			DamageElement damageElement = Elements.Parse(PluginCore.PetElementFor(worldObject.Name) ?? "None");
			if (damageElement != DamageElement.None)
			{
				return damageElement;
			}
			foreach (DmgType item2 in GameInfo.PetRanking(worldObject))
			{
				DamageElement damageElement2 = item2 switch
				{
					DmgType.Blade => DamageElement.Slash, 
					DmgType.Void => DamageElement.Nether, 
					_ => Elements.Parse(item2.ToString()), 
				};
				if (damageElement2 == DamageElement.None)
				{
					continue;
				}
				foreach (PetRecord value in _petRecords.Values)
				{
					if (value.Enabled && !value.NeedsRecharge && value.Element == damageElement2)
					{
						return damageElement2;
					}
				}
			}
			return DamageElement.None;
		}
		catch
		{
			return DamageElement.None;
		}
	}

	private PetRecord ChooseBestPetForSummon(DamageElement target)
	{
		PetRecord petRecord = null;
		PetRecord petRecord2 = null;
		foreach (PetRecord value2 in _petRecords.Values)
		{
			if (value2.Enabled && !value2.NeedsRecharge && (value2.LiveWorldId == 0 || !_livePetIds.Contains(value2.LiveWorldId)) && (!_cooldowns.TryGetValue(value2.DeviceId, out var value) || !((DateTime.Now - value).TotalMilliseconds < 8000.0)))
			{
				if (petRecord2 == null)
				{
					petRecord2 = value2;
				}
				if (target != DamageElement.None && value2.Element == target && petRecord == null)
				{
					petRecord = value2;
				}
			}
		}
		return petRecord ?? petRecord2;
	}

	private void TryDismissActivePet()
	{
		if (_activeDeviceId == 0 || DateTime.Now - _lastPetCombatAt < PET_COMBAT_LOCK || DateTime.Now - _lastDismissAt < DISMISS_RETRY || !TankLetsMeGo())
		{
			return;
		}
		int liveDev = DeviceForLivePet();
		if (liveDev != 0 && liveDev != _activeDeviceId)
		{
			_activeDeviceId = liveDev;
		}
		if (liveDev == 0 && _livePetIds.Count > 0)
		{
			// (a pet's out but none of the essences is its: using one would summon that one's pet instead)
			Idle = "can't tell which essence the pet came from";
			return;
		}
		if (!_petRecords.TryGetValue(_activeDeviceId, out var value))
		{
			return;
		}
		if (CoolingDown(value.DeviceId, out var coolLeft))
		{
			Idle = "essence cooling down - dismissing in " + Math.Ceiling(coolLeft.TotalSeconds).ToString("0") + " s";
			if (!_saidCooling)
			{
				_saidCooling = true;
				Util.WriteToChat("Pets: " + value.Name + " is cooling down - dismissing it in " + Math.Ceiling(coolLeft.TotalSeconds).ToString("0") + " s.");
			}
			return;
		}
		_saidCooling = false;
		DateTime prevDismiss = _lastDismissAt;
		_lastDismissAt = DateTime.Now;
		WorldObject worldObject = Core.WorldFilter[value.DeviceId];
		if (worldObject == null)
		{
			return;
		}
		try
		{
			if (_dismissFor != value.DeviceId || DateTime.Now - prevDismiss > TimeSpan.FromSeconds(15.0))
			{
				_dismissFor = value.DeviceId;
				_dismissTries = 0;
			}
			_dismissTries++;
			if (_dismissTries == 1)
			{
				Util.WriteToChat("Pets: dismissing " + value.Name + "...");
			}
			else if (_dismissTries == 4)
			{
				Util.WriteToChat("Pets: the game hasn't let " + value.Name + " be dismissed yet - still trying.");
			}
			_lastUseItemDeviceId = value.DeviceId;
			_lastUseItemAt = DateTime.Now;
			_deviceBusyUntil = DateTime.Now.AddSeconds(1.0);   // (the game answers at once: the pet appears or goes - which ends this - or it was refused)
			Core.Actions.UseItem(worldObject.Id, 0);
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Pets: dismiss error: " + ex.Message);
		}
	}

	private bool DoSummon(PetRecord rec, WorldObject device)
	{
		if (!TankLetsMeGo())
		{
			return false;
		}
		try
		{
			Util.WriteToChat("Pets: summoning " + rec.Name + "...");
			_lastUseItemDeviceId = rec.DeviceId;
			_lastUseItemAt = DateTime.Now;
			_deviceBusyUntil = DateTime.Now.AddSeconds(1.0);   // (the game answers at once: the pet appears or goes - which ends this - or it was refused)
			Core.Actions.UseItem(device.Id, 0);
			_cooldowns[rec.DeviceId] = DateTime.Now;
			rec.LastSummoned = DateTime.Now;
			_activeDeviceId = rec.DeviceId;
			MarkPendingRefresh(rec.DeviceId);
			QueueForceId(rec.DeviceId);
			foreach (PetRecord value in _petRecords.Values)
			{
				if (value.DeviceId != rec.DeviceId)
				{
					value.LiveWorldId = 0;
					value.LiveWorldGuid = 0;
					value.MatchLogged = false;
				}
			}
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Pets: summon error: " + ex.Message);
		}
		return true;
	}

	private void RefreshLivePetSnapshot()
	{
		_livePetIds.Clear();
		foreach (WorldObject item in Core.WorldFilter.GetLandscape())
		{
			if (IsPetObject(item))
			{
				_livePetIds.Add(item.Id);
				if (_activeDeviceId == 0)
				{
					CorrelateNewPet(item);
				}
			}
		}
		foreach (PetRecord value in _petRecords.Values)
		{
			if (value.LiveWorldId != 0 && !_livePetIds.Contains(value.LiveWorldId))
			{
				value.LiveWorldId = 0;
				value.LiveWorldGuid = 0;
				value.MatchLogged = false;
			}
		}
	}

	private bool MonstersInRange(double metres)
	{
		try
		{
			foreach (WorldObject item in Core.WorldFilter.GetLandscape())
			{
				if (item.ObjectClass == ObjectClass.Monster && !_livePetIds.Contains(item.Id) && !IsPetObject(item) && !IsLikelyOtherPlayersPet(item))
				{
					double distance = GetDistance(item);
					if (distance >= 0.0 && distance <= metres)
					{
						return true;
					}
				}
			}
		}
		catch
		{
		}
		return false;
	}

	private bool PetOnlyInRange(double metres)
	{
		try
		{
			foreach (WorldObject item in Core.WorldFilter.GetLandscape())
				if (item.ObjectClass == ObjectClass.Monster && PluginCore.IsPetOnly(item.Name)) { double d = GetDistance(item); if (d >= 0.0 && d <= metres) return true; }
		}
		catch { }
		return false;
	}

	private static int LandblockKey(WorldObject o)
	{
		try
		{
			return (o.Values(LongValueKey.Landblock) >>> 16) & 0xFFFF;
		}
		catch
		{
			return -1;
		}
	}

	private double GetDistance(WorldObject obj)
	{
		try
		{
			WorldObject worldObject = Core.WorldFilter[Core.CharacterFilter.Id];
			if (worldObject == null || LandblockKey(obj) != LandblockKey(worldObject))
			{
				return -1.0;
			}
			double num = obj.RawCoordinates().X - worldObject.RawCoordinates().X;
			double num2 = obj.RawCoordinates().Y - worldObject.RawCoordinates().Y;
			double num3 = obj.RawCoordinates().Z - worldObject.RawCoordinates().Z;
			return Math.Sqrt(num * num + num2 * num2 + num3 * num3);
		}
		catch
		{
			return -1.0;
		}
	}

	private bool IsPetObject(WorldObject obj)
	{
		return obj.ObjectClass == ObjectClass.Monster && obj.Name.StartsWith(Core.CharacterFilter.Name + "'s ", StringComparison.OrdinalIgnoreCase);
	}

	private static bool IsLikelyOtherPlayersPet(WorldObject obj)
	{
		try
		{
			return obj.Name.IndexOf("'s ", StringComparison.OrdinalIgnoreCase) > 0 || obj.Values(LongValueKey.CreateFlags2) != 0;
		}
		catch
		{
			return false;
		}
	}

	private WorldObject FindByName(string name)
	{
		foreach (WorldObject item in InvCache.All())
		{
			if (item.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
			{
				return item;
			}
		}
		return null;
	}

	private void BeginRecharge(PetRecord rec)
	{
		if (Core.WorldFilter[rec.DeviceId] == null)
		{
			Util.WriteToChat("Pets: " + rec.Name + " isn't in your pack - can't recharge it.");
			rec.NeedsRecharge = false;
			return;
		}
		if (FindByName("Encapsulated Spirit") == null)
		{
			Util.WriteToChat("Pets: no Encapsulated Spirit - recharge cancelled.");
			rec.NeedsRecharge = false;
			return;
		}
		PluginCore.Pause("Pet summoner");
		try
		{
			_rechargePrevCombatMode = (int)Core.Actions.CombatMode;
		}
		catch
		{
			_rechargePrevCombatMode = 1;
		}
		_rechargeStartUses = rec.UsesRemaining;
		try
		{
			Core.Actions.SetCombatMode(CombatState.Peace);
		}
		catch
		{
		}
		Util.WriteToChat("Pets: recharging " + rec.Name + "...");
		_rechargingDeviceId = rec.DeviceId;
		_rechargeStage = 1;
		_rechargeStageAt = DateTime.Now;
	}

	private void ProcessRechargeInProgress()
	{
		if (!_petRecords.TryGetValue(_rechargingDeviceId, out var value))
		{
			_rechargingDeviceId = 0;
			_rechargeStage = 0;
			PluginCore.Resume("Pet summoner");
		}
		else if (_rechargeStage == 1)
		{
			bool flag = false;
			try
			{
				flag = Core.Actions.CombatMode == CombatState.Peace;
			}
			catch
			{
			}
			if (!flag && (DateTime.Now - _rechargeStageAt).TotalMilliseconds <= 2000.0)
			{
				return;
			}
			WorldObject worldObject = Core.WorldFilter[value.DeviceId];
			WorldObject worldObject2 = FindByName("Encapsulated Spirit");
			if (worldObject == null || worldObject2 == null)
			{
				Util.WriteToChat("Pets: recharge stopped - the device or the spirit went missing.");
				FinishRecharge(value, ok: false);
				return;
			}
			try
			{
				Core.Actions.ApplyItem(worldObject2.Id, worldObject.Id);
			}
			catch (Exception ex)
			{
				Util.WriteToChat("Pets: recharge error: " + ex.Message);
			}
			_rechargeStage = 2;
			_rechargeStageAt = DateTime.Now;
		}
		else
		{
			if (_rechargeStage != 2 || (DateTime.Now - _rechargeStageAt).TotalMilliseconds < 1500.0)
			{
				return;
			}
			int num = value.UsesRemaining;
			WorldObject worldObject3 = Core.WorldFilter[value.DeviceId];
			if (worldObject3 != null)
			{
				try
				{
					num = worldObject3.Values(LongValueKey.UsesRemaining);
				}
				catch
				{
				}
			}
			if (num > _rechargeStartUses)
			{
				value.UsesRemaining = num;
				Util.WriteToChat("Pets: " + value.Name + " recharged (" + num + " uses).");
				FinishRecharge(value, ok: true);
			}
			else
			{
				Util.WriteToChat("Pets: the recharge of " + value.Name + " didn't take - trying again later.");
				FinishRecharge(value, ok: false);
			}
		}
	}

	private void FinishRecharge(PetRecord rec, bool ok)
	{
		if (ok)
		{
			rec.NeedsRecharge = false;
			rec.NeedsRechargeSince = DateTime.MinValue;
		}
		_rechargingDeviceId = 0;
		_rechargeStage = 0;
		try
		{
			Core.Actions.SetCombatMode((CombatState)_rechargePrevCombatMode);
		}
		catch
		{
		}
		PluginCore.Resume("Pet summoner");
	}

	public bool IsOut(PetRecord r)
	{
		return r.LiveWorldId != 0 && _livePetIds.Contains(r.LiveWorldId);
	}

	public string StatusOf(PetRecord r)
	{
		if (_rechargingDeviceId == r.DeviceId)
		{
			return "Recharging";
		}
		if (IsOut(r))
		{
			return "Out";
		}
		if (r.NeedsRecharge)
		{
			return "Recharge";
		}
		if (Core.WorldFilter[r.DeviceId] == null)
		{
			return "Not in pack";
		}
		return "Away";
	}

	public void ToggleEnabled(PetRecord rec)
	{
		rec.Enabled = !rec.Enabled;
		if (!rec.Enabled && _activeDeviceId == rec.DeviceId && _livePetIds.Count > 0)
		{
			_dismissWanted = true;
			TryDismissActivePet();
		}
		Save();
	}

	public void SetElement(PetRecord rec, DamageElement e)
	{
		rec.Element = e;
		Save();
	}

	private void CheckNewPetRecharge(PetRecord rec)
	{
		if (!RechargeEnabled)
		{
			return;
		}
		try
		{
			WorldObject worldObject = Core.WorldFilter[rec.DeviceId];
			if (worldObject != null)
			{
				rec.UsesRemaining = worldObject.Values(LongValueKey.UsesRemaining);
				if (rec.UsesRemaining >= 0 && rec.UsesRemaining < RechargeThreshold)
				{
					rec.NeedsRecharge = true;
					rec.NeedsRechargeSince = DateTime.Now;
				}
			}
		}
		catch
		{
		}
	}

	private void Track(WorldObject obj)
	{
		if (_petRecords.ContainsKey(obj.Id))
		{
			Util.WriteToChat("Pets: already in the list: " + obj.Name);
			return;
		}
		PetRecord petRecord = new PetRecord(obj.Id, obj.Name);
		_petRecords[obj.Id] = petRecord;
		CheckNewPetRecharge(petRecord);
		QueueForceId(obj.Id);
		Util.WriteToChat("Pets: added " + obj.Name + ".");
		Save();
	}

	public void Add(string name)
	{
		name = (name ?? "").Trim();
		if (name.Length > 0)
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (item.Name.IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0 && !_petRecords.ContainsKey(item.Id))
				{
					Track(item);
					return;
				}
			}
			Util.WriteToChat("Pets: nothing new in your pack called \"" + name + "\".");
			return;
		}
		int currentSelection = Core.Actions.CurrentSelection;
		if (currentSelection == 0)
		{
			Util.WriteToChat("Pets: type part of the name, or select the pet's essence in your pack.");
			return;
		}
		foreach (WorldObject item2 in InvCache.All())
		{
			if (item2.Id == currentSelection)
			{
				Track(item2);
				return;
			}
		}
		Util.WriteToChat("Pets: select it in your pack (not in the world).");
	}

	/// <summary>Adds this very essence (by its id - many share a name, in different packs). False: not in the pack here.</summary>
	public bool AddById(int id)
	{
		if (_petRecords.ContainsKey(id)) { Util.WriteToChat("Pets: it's on the list already."); return true; }
		foreach (WorldObject item in InvCache.All())
			if (item.Id == id) { Track(item); return true; }
		Util.WriteToChat("Pets: that essence isn't in your pack.");
		return false;
	}

	public bool Has(int id) => _petRecords.ContainsKey(id);

	public void Remove(PetRecord rec)
	{
		if (!_petRecords.ContainsKey(rec.DeviceId))
		{
			return;
		}
		int deviceId = rec.DeviceId;
		if (_activeDeviceId == deviceId || IsOut(rec))
		{
			bool flag = _cooldowns.TryGetValue(deviceId, out var value) && (DateTime.Now - value).TotalMilliseconds < 8000.0;
			WorldObject worldObject = Core.WorldFilter[deviceId];
			if (worldObject != null)
			{
				Util.WriteToChat("Pets: " + rec.Name + " is out - dismissing it first.");
				try
				{
					Core.Actions.UseItem(worldObject.Id, 0);
				}
				catch
				{
				}
			}
			if (flag)
			{
				_pendingRemovalRetry[deviceId] = DateTime.Now.AddMilliseconds(8500.0);
				Util.WriteToChat("Pets: it was just summoned - removing it once it's gone.");
				return;
			}
		}
		_petRecords.Remove(deviceId);
		_pendingRemovalRetry.Remove(deviceId);
		_cooldowns.Remove(deviceId);
		if (_activeDeviceId == deviceId)
		{
			_activeDeviceId = 0;
		}
		if (_pendingSummonId == deviceId)
		{
			_pendingSummonId = 0;
		}
		if (SelectedEchoDeviceId == deviceId)
		{
			SelectedEchoDeviceId = 0;
		}
		Util.WriteToChat("Pets: removed " + rec.Name + ".");
		Save();
	}

	private void ProcessPendingRemovals()
	{
		List<int> list = new List<int>();
		foreach (KeyValuePair<int, DateTime> item in _pendingRemovalRetry)
		{
			if (DateTime.Now >= item.Value)
			{
				list.Add(item.Key);
			}
		}
		foreach (int item2 in list)
		{
			_pendingRemovalRetry.Remove(item2);
			if (_petRecords.TryGetValue(item2, out var value))
			{
				Remove(value);
			}
		}
	}

	public void SummonNow()
	{
		if (ExternalLoaded)
		{
			Util.WriteToChat("Pets: the separate MelksPetSummoner is still loaded - use its window.");
			return;
		}
		List<PetRecord> list = new List<PetRecord>();
		foreach (PetRecord value in _petRecords.Values)
		{
			if (value.Enabled)
			{
				list.Add(value);
			}
		}
		if (list.Count == 0)
		{
			Util.WriteToChat("Pets: no pets ticked.");
			return;
		}
		PetRecord petRecord = null;
		if (list.Count == 1)
		{
			petRecord = list[0];
		}
		else
		{
			DamageElement targetElement = GetTargetElement();
			if (targetElement != DamageElement.None)
			{
				foreach (PetRecord item in list)
				{
					if (item.Element == targetElement)
					{
						petRecord = item;
						break;
					}
				}
			}
			if (petRecord == null)
			{
				foreach (PetRecord item2 in list)
				{
					if (petRecord == null || item2.LastSummoned > petRecord.LastSummoned)
					{
						petRecord = item2;
					}
				}
			}
		}
		if (IsOut(petRecord))
		{
			Util.WriteToChat("Pets: " + petRecord.Name + " is already out.");
			return;
		}
		if (petRecord.NeedsRecharge)
		{
			Util.WriteToChat("Pets: " + petRecord.Name + " needs a recharge first.");
			return;
		}
		WorldObject worldObject = Core.WorldFilter[petRecord.DeviceId];
		if (worldObject == null)
		{
			Util.WriteToChat("Pets: " + petRecord.Name + " isn't in your pack.");
		}
		else if (_livePetIds.Count > 0 && _activeDeviceId != petRecord.DeviceId)
		{
			TryDismissActivePet();
			_pendingSummonId = petRecord.DeviceId;
		}
		else if (!DoSummon(petRecord, worldObject))
		{
			_pendingSummonId = petRecord.DeviceId;
		}
	}

	public void UnsummonNow()
	{
		if (_activeDeviceId == 0 || _livePetIds.Count == 0)
		{
			Util.WriteToChat("Pets: no pet out.");
			return;
		}
		if (DateTime.Now - _lastPetCombatAt < PET_COMBAT_LOCK)
		{
			Util.WriteToChat("Pets: it's still fighting - dismissing it 7.5 s after its last hit.");
		}
		_dismissWanted = true;
		TryDismissActivePet();
	}

	private int GetEchoInventoryCount()
	{
		int num = 0;
		foreach (WorldObject item in InvCache.All())
		{
			if (item.Name.Equals("Savage Echo", StringComparison.OrdinalIgnoreCase))
			{
				try
				{
					num += item.Values(LongValueKey.StackCount);
				}
				catch
				{
					num++;
				}
			}
		}
		return num;
	}

	public void ApplyEchoes()
	{
		if (SelectedEchoDeviceId == 0 || !_petRecords.TryGetValue(SelectedEchoDeviceId, out var value))
		{
			Util.WriteToChat("Pets: pick a pet in the Echoes list first.");
			return;
		}
		WorldObject worldObject = Core.WorldFilter[value.DeviceId];
		if (worldObject == null)
		{
			Util.WriteToChat("Pets: " + value.Name + " isn't in your pack.");
			return;
		}
		WorldObject worldObject2 = FindByName("Savage Echo");
		if (worldObject2 == null)
		{
			Util.WriteToChat("Pets: no Savage Echo in your pack.");
			return;
		}
		if (DebugDumps)
		{
			ObjectDump.DumpObjectValues(worldObject, "BEFORE apply Savage Echo to " + value.Name, full: false);
		}
		int num = value.PotencyApplied + 1;
		int num2 = num * 20;
		bool flag = EchoCount >= num2;
		Core.Actions.ApplyItem(worldObject2.Id, worldObject.Id);
		if (!flag)
		{
			Util.WriteToChat("Pets: sent, but level " + num + " needs " + num2.ToString("N0") + " echoes and you have " + EchoCount.ToString("N0") + " - not counted.");
			return;
		}
		Util.WriteToChat("Pets: applied Savage Echoes to " + value.Name + ".");
		value.PotencyApplied++;
		_echoesSpentSinceReset += num2;
		Save();
		MarkPendingRefresh(value.DeviceId);
		QueueForceId(value.DeviceId);
		if (DebugDumps)
		{
			_pendingDumpDeviceId = value.DeviceId;
			_pendingDumpPetName = value.Name;
		}
	}

	public void Command(string text)
	{
		string[] array = (text ?? "").Trim().Split(new char[1] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
		string text2 = ((array.Length < 2) ? "help" : array[1].ToLowerInvariant());
		string text3 = ((array.Length > 2) ? string.Join(" ", array, 2, array.Length - 2) : "");
		switch (text2)
		{
		case "on":
			PluginCore.SetSummoningFromNav(on: true);
			Util.WriteToChat("Pet summoning ON.");
			break;
		case "off":
			PluginCore.SetSummoningFromNav(on: false);
			Util.WriteToChat("Pet summoning OFF.");
			break;
		case "status":
			Util.WriteToChat("Pets: " + (Enabled ? "ON" : "OFF") + " | pets: " + _petRecords.Count + " | out: " + _livePetIds.Count + " | range " + RangeDist.ToString("0") + " m");
			break;
		case "list":
			if (_petRecords.Count == 0)
			{
				Util.WriteToChat("Pets: none added yet.");
			}
			{
				foreach (PetRecord value in _petRecords.Values)
				{
					Util.WriteToChat("  " + (value.Enabled ? "[x] " : "[ ] ") + value.Name + "  uses " + ((value.UsesRemaining >= 0) ? value.UsesRemaining.ToString() : "?") + "  " + value.Element.ToString() + "  " + StatusOf(value));
				}
				break;
			}
		case "add":
			Add(text3);
			break;
		case "remove":
			foreach (PetRecord value2 in _petRecords.Values)
			{
				if (value2.Name.IndexOf(text3, StringComparison.OrdinalIgnoreCase) >= 0 && text3.Length > 0)
				{
					Remove(value2);
					return;
				}
			}
			Util.WriteToChat("Pets: none in the list called \"" + text3 + "\".");
			break;
		case "summon":
			SummonNow();
			break;
		case "dismiss":
		case "unsummon":
			UnsummonNow();
			break;
		case "debug":
			DebugDumps = !DebugDumps;
			Util.WriteToChat("Pets: echo before / after dumps " + (DebugDumps ? "on (MelkTank_Dump.txt)." : "off."));
			break;
		case "dumpvalues":
			ObjectDump.DumpSelected();
			break;
		case "listactions":
			ObjectDump.DumpActionMethodNames();
			break;
		case "forceid":
			SetForceId((text3.Length > 0) ? text3.Equals("on", StringComparison.OrdinalIgnoreCase) : (!_forceIdEnabled));
			break;
		case "dispatchlog":
			if (text3.Equals("report", StringComparison.OrdinalIgnoreCase))
			{
				ReportDispatchLog();
			}
			else
			{
				SetDispatchLog((text3.Length > 0) ? text3.Equals("on", StringComparison.OrdinalIgnoreCase) : (!DispatchLogOn));
			}
			break;
		default:
			Util.WriteToChat("/mpets on|off | status | list | add [name] | remove <name> | summon | dismiss | forceid on|off | debug | dumpvalues | listactions | dispatchlog on|off|report");
			break;
		}
	}

	private static void MigrateOldSettings()
	{
		try
		{
			if (File.Exists(SettingsPath))
			{
				return;
			}
			string directoryName = Path.GetDirectoryName(Util.BasePath.TrimEnd(new char[2] { '\\', '/' }));
			string[] array = new string[2] { "MelksPetSummoner\\bin\\Debug\\MelksPetSummoner_Settings.xml", "MelksPetSummoner\\MelksPetSummoner_Settings.xml" };
			foreach (string path in array)
			{
				string old = Path.Combine(directoryName, path);
				if (File.Exists(old))
				{
					Util.Locked(old, () =>
					{
						File.Copy(old, SettingsPath);
					});
					Util.WriteToChat("Pets: copied your MelksPetSummoner pets and settings into MelkTank_Pets.xml.");
					break;
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void LoadSettings()
	{
		_loaded = false;
		try
		{
			MigrateOldSettings();
			if (!File.Exists(SettingsPath))
			{
				_loaded = true;
				return;
			}
			XmlDocument xmlDocument = null;
			for (int i = 0; i < 5; i++)
			{
				if (xmlDocument != null)
				{
					break;
				}
				try
				{
					XmlDocument xmlDocument2 = new XmlDocument();
					Util.LoadXml(xmlDocument2, SettingsPath);
					xmlDocument = xmlDocument2;
				}
				catch
				{
					Thread.Sleep(150);
				}
			}
			if (xmlDocument == null)
			{
				Util.WriteToChat("Pets: couldn't read MelkTank_Pets.xml - not saving this session so your pets aren't overwritten.");
				return;
			}
			XmlNode xmlNode = xmlDocument.SelectSingleNode("/MelksPetSummoner/Character[@key='" + _charKey + "']");
			if (xmlNode == null)
			{
				_loaded = true;
				return;
			}
			if (!_s.PetRangeMigrated)
			{
				_s.PetRangeMigrated = true;
				if (!_s.PetRangeOverride)
				{
					XmlNode xmlNode2 = xmlNode.SelectSingleNode("RangeDistance");
					_s.PetUseCombatRange = false;
					_s.PetRange = ((xmlNode2 != null && double.TryParse(xmlNode2.InnerText, out var result) && result > 0.0) ? ((float)result) : 20f);
				}
				if (_saveAll != null)
				{
					_saveAll();
				}
			}
			UnsummonOnClear = B(xmlNode, "UnsummonOnClear", def: false);
			RechargeEnabled = B(xmlNode, "RechargeEnabled", def: false);
			XmlNode xmlNode3 = xmlNode.SelectSingleNode("RechargeThreshold");
			if (xmlNode3 != null && int.TryParse(xmlNode3.InnerText, out var result2))
			{
				RechargeThreshold = Math.Max(1, result2);
			}
			ForceRechargeInCombat = B(xmlNode, "ForceRechargeInCombat", def: false);
			_forceIdEnabled = B(xmlNode, "ForceIdEnabled", def: true);
			_petRecords.Clear();
			foreach (XmlNode item in xmlNode.SelectNodes("Pets/Pet"))
			{
				XmlNode xmlNode5 = item.SelectSingleNode("DeviceId");
				XmlNode xmlNode6 = item.SelectSingleNode("Name");
				if (xmlNode5 != null && xmlNode6 != null && int.TryParse(xmlNode5.InnerText, out var result3))
				{
					PetRecord petRecord = new PetRecord(result3, xmlNode6.InnerText);
					petRecord.Enabled = B(item, "Enabled", def: true);
					XmlNode xmlNode7 = item.SelectSingleNode("PotencyApplied");
					if (xmlNode7 != null && int.TryParse(xmlNode7.InnerText, out var result4))
					{
						petRecord.PotencyApplied = result4;
					}
					XmlNode xmlNode8 = item.SelectSingleNode("Element");
					if (xmlNode8 != null)
					{
						petRecord.Element = Elements.Parse(xmlNode8.InnerText);
					}
					_petRecords[result3] = petRecord;
				}
			}
			_loaded = true;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static bool B(XmlNode n, string name, bool def)
	{
		XmlNode xmlNode = n.SelectSingleNode(name);
		bool result;
		return (xmlNode != null && bool.TryParse(xmlNode.InnerText, out result)) ? result : def;
	}

	public void Save()
	{
		if (!_loaded || string.IsNullOrEmpty(_charKey))
		{
			return;
		}
		try
		{
			Util.Locked(SettingsPath, SaveLocked);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void SaveLocked()
	{
		XmlDocument xmlDocument = new XmlDocument();
		XmlElement xmlElement;
		if (File.Exists(SettingsPath))
		{
			bool flag = false;
			for (int i = 0; i < 5; i++)
			{
				if (flag)
				{
					break;
				}
				try
				{
					xmlDocument = new XmlDocument();
					xmlDocument.Load(SettingsPath);
					flag = true;
				}
				catch
				{
					Thread.Sleep(150);
				}
			}
			if (!flag)
			{
				return;
			}
			xmlElement = xmlDocument.DocumentElement;
		}
		else
		{
			xmlElement = xmlDocument.CreateElement("MelksPetSummoner");
			xmlDocument.AppendChild(xmlElement);
		}
		XmlNode xmlNode = xmlElement.SelectSingleNode("Character[@key='" + _charKey + "']");
		if (xmlNode == null)
		{
			XmlElement xmlElement2 = xmlDocument.CreateElement("Character");
			xmlElement2.SetAttribute("key", _charKey);
			xmlElement.AppendChild(xmlElement2);
			xmlNode = xmlElement2;
		}
		Put(xmlDocument, xmlNode, "UnsummonOnClear", UnsummonOnClear.ToString());
		Put(xmlDocument, xmlNode, "RechargeEnabled", RechargeEnabled.ToString());
		Put(xmlDocument, xmlNode, "RechargeThreshold", RechargeThreshold.ToString());
		Put(xmlDocument, xmlNode, "ForceRechargeInCombat", ForceRechargeInCombat.ToString());
		Put(xmlDocument, xmlNode, "ForceIdEnabled", _forceIdEnabled.ToString());
		XmlNode xmlNode2 = xmlNode.SelectSingleNode("Pets");
		if (xmlNode2 != null)
		{
			xmlNode.RemoveChild(xmlNode2);
		}
		XmlElement xmlElement3 = xmlDocument.CreateElement("Pets");
		xmlNode.AppendChild(xmlElement3);
		foreach (PetRecord value in _petRecords.Values)
		{
			XmlElement xmlElement4 = xmlDocument.CreateElement("Pet");
			Put(xmlDocument, xmlElement4, "DeviceId", value.DeviceId.ToString());
			Put(xmlDocument, xmlElement4, "Name", value.Name);
			Put(xmlDocument, xmlElement4, "Enabled", value.Enabled.ToString());
			Put(xmlDocument, xmlElement4, "PotencyApplied", value.PotencyApplied.ToString());
			Put(xmlDocument, xmlElement4, "Element", value.Element.ToString());
			xmlElement3.AppendChild(xmlElement4);
		}
		XmlWriterSettings settings = new XmlWriterSettings
		{
			Indent = true,
			IndentChars = "    "
		};
		string text = SettingsPath + ".tmp";
		using (XmlWriter w = XmlWriter.Create(text, settings))
		{
			xmlDocument.Save(w);
		}
		if (File.Exists(SettingsPath))
		{
			try
			{
				File.Copy(SettingsPath, SettingsPath + ".bak", overwrite: true);
			}
			catch
			{
			}
			File.Delete(SettingsPath);
		}
		File.Move(text, SettingsPath);
	}

	private static void Put(XmlDocument doc, XmlNode parent, string name, string value)
	{
		XmlNode xmlNode = parent.SelectSingleNode(name);
		if (xmlNode == null)
		{
			xmlNode = doc.CreateElement(name);
			parent.AppendChild(xmlNode);
		}
		xmlNode.InnerText = value;
	}
}
