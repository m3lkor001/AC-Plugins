using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text.Json;
using System.Text.RegularExpressions;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;

namespace MelkTank.Pets;

/// <summary>
/// Pets > Breed: Professor Ruggan's pet breeding (Infinite Leaftide). Reads every pet essence's description (sex, the
/// male's charges, the female's rest, growth, bond, potency, the mutated combat ratings), shares each character's list
/// with the others on this computer (a file per character), and suggests the best male x female pair across them - the
/// stats the baby can be expected to take - with the steps to breed it. Both characters' MelkTanks can summon the
/// chosen pets and dance together from one button.
/// </summary>
public class Breeding
{
	public static Breeding Current;

	public sealed class Pet
	{
		public string Owner { get; set; } = "";
		public int Id { get; set; }
		public string Name { get; set; } = "";
		public int Tier { get; set; }
		public string Sex { get; set; } = "";          // Male / Female / ""
		public string SexNote { get; set; } = "";      // what's in brackets after it
		public int Charges { get; set; } = -1;         // male: charges left today
		public int ChargesMax { get; set; } = -1;
		public bool Ready { get; set; }                // female: ready to breed (as last worked out - ReadyNow is what's used)
		// ("recovering - ready to breed in 3h 55m" is resting, not ready)
		[System.Text.Json.Serialization.JsonIgnore]
		public bool ReadyNow => SexNote.IndexOf("ready", StringComparison.OrdinalIgnoreCase) >= 0
		                        && SexNote.IndexOf("recover", StringComparison.OrdinalIgnoreCase) < 0
		                        && !Regex.IsMatch(SexNote, @"ready to breed in", RegexOptions.IgnoreCase);
		[System.Text.Json.Serialization.JsonIgnore]
		public string RestLeft { get { var m = Regex.Match(SexNote, @"\bin\s+(.+)$", RegexOptions.IgnoreCase); return m.Success ? m.Groups[1].Value.Trim() : ""; } }
		public string Growth { get; set; } = "Adult";
		public string GrowthText { get; set; } = "";   // the whole growth line ("Newborn 1/5 - 60 kills to Whelp, 300 to Adult")
		public DateTime FirstSeen { get; set; }
		public int Bond { get; set; }
		public bool Unbound { get; set; }
		public int Potency { get; set; }
		public int Mutations { get; set; }
		public int Dmg { get; set; }
		public int DmgMut { get; set; }
		public int Dr { get; set; }
		public int DrMut { get; set; }
		public int Crit { get; set; }
		public int CritMut { get; set; }
		public int Translucency { get; set; }
		public bool Shiny { get; set; }
		public bool Neutered { get; set; }
		public bool Read { get; set; }                 // its description has been seen
		public DateTime Seen { get; set; }

		public bool Adult => Growth.Equals("Adult", StringComparison.OrdinalIgnoreCase);
		public bool Male => Sex == "Male";
		public bool Female => Sex == "Female";

		/// <summary>Why it can't breed right now ("" if it can).</summary>
		public string Why()
		{
			if (!Read) return "not looked at yet";
			if (Sex.Length == 0) return "no sex in its description (not a combat pet?)";
			if (Tier < 100) return $"tier {Tier} (100+ breeds)";
			if (Bond < 100) return $"bond {Bond} (100+)";
			if (Shiny) return "shiny";
			if (Neutered) return "neutered";
			if (!Adult) return Growth;
			if (Male && Charges == 0) return "no charges left today";
			if (Female && !ReadyNow) return RestLeft.Length > 0 ? "resting, " + RestLeft + " left" : SexNote.Length > 0 ? SexNote : "resting";
			return "";
		}

		/// <summary>How good a parent it is, for the lines that matter: mutations count most.</summary>
		public double Score => Dmg + Dr + Crit * 2 + DmgMut * 3 + DrMut * 3 + CritMut * 6 + Potency / 25.0;
		public Pet As(string owner) { var c = (Pet)MemberwiseClone(); c.Owner = owner; return c; }
	}

	private readonly Settings _s;
	private readonly Action _save;
	private string _me = "";
	private readonly Dictionary<int, Pet> _mine = new Dictionary<int, Pet>();
	private List<Pet> _others = new List<Pet>();
	private readonly Dictionary<string, Dictionary<string, int>> _theirItems = new Dictionary<string, Dictionary<string, int>>();
	private Dictionary<string, int> _myItems = new Dictionary<string, int>();
	private readonly Dictionary<int, DateTime> _firstSeen = new Dictionary<int, DateTime>();
	private bool _primed;   // (what was in the pack at login isn't "new")

	// the shop's things for a litter, best first
	private static readonly string[] Incenses = { "Exquisite Courtship Incense", "Refined Courtship Incense", "Lesser Courtship Incense" };
	private const string Subjugation = "Offering of Subjugation";

	private sealed class Shared
	{
		public List<Pet> pets { get; set; } = new List<Pet>();
		public Dictionary<string, int> items { get; set; } = new Dictionary<string, int>();
	}
	private DateTime _nextScan = DateTime.MinValue, _nextRead = DateTime.MinValue, _nextShare = DateTime.MinValue, _nextIdAsk = DateTime.MinValue;
	private bool _dirty;
	private long _signalSeen;
	private int _maleId, _femaleId;           // the pair picked (any owner)
	private string _maleOwner = "", _femaleOwner = "";
	private int _babyId; private string _babyOwner = "";
	private int _reIdId; private DateTime _reIdAt;
	private Pet _suggestRaise;   // (the pet the suggested action says to raise)   // (a baby fed: looked at again a moment after)   // (a baby picked in the second list)
	private const string Nurturing = "Nurturing Draught";
	public bool HoldSummons;                   // breeding: the pet summoner leaves pets alone
	private DateTime _holdSince;               // (let go by itself: a baby born, or 30 s on)

	private static readonly Vector4 Cyan = new Vector4(0.45f, 0.85f, 1f, 1f), Dim = new Vector4(0.6f, 0.6f, 0.6f, 1f),
		Good = new Vector4(0.5f, 0.95f, 0.45f, 1f), Bad = new Vector4(1f, 0.55f, 0.45f, 1f), Pink = new Vector4(1f, 0.6f, 0.8f, 1f), White = new Vector4(0.9f, 0.92f, 1f, 1f);

	private static readonly Regex SexRx = new Regex(@"Sex:\s*(Male|Female)\s*(?:\(([^)]*)\))?", RegexOptions.IgnoreCase);
	private static readonly Regex ChargesRx = new Regex(@"(\d+)\s*/\s*(\d+)\s*breeding charges", RegexOptions.IgnoreCase);
	private static readonly Regex GrowthRx = new Regex(@"Growth:\s*([A-Za-z]+)([^\r\n]*)", RegexOptions.IgnoreCase);
	private static readonly Regex BondRx = new Regex(@"Bond Level:\s*([\d,]+)", RegexOptions.IgnoreCase);
	private static readonly Regex PotencyRx = new Regex(@"Potency:\s*([\d,]+)\s*stored", RegexOptions.IgnoreCase);
	private static readonly Regex MutsRx = new Regex(@"Total Mutations:\s*(\d+)", RegexOptions.IgnoreCase);
	private static readonly Regex DmgRx = new Regex(@"\bDamage:\s*(-?\d+)\s*\(Base:\s*(-?\d+),\s*Mut:\s*\+?(-?\d+)", RegexOptions.IgnoreCase);
	private static readonly Regex DrRx = new Regex(@"Damage Resist:\s*(-?\d+)\s*\(Base:\s*(-?\d+),\s*Mut:\s*\+?(-?\d+)", RegexOptions.IgnoreCase);
	private static readonly Regex CritRx = new Regex(@"Crit Rating:\s*(-?\d+)\s*\(Base:\s*(-?\d+),\s*Mut:\s*\+?(-?\d+)", RegexOptions.IgnoreCase);
	private static readonly Regex TransRx = new Regex(@"Translucency:\s*(\d+)%", RegexOptions.IgnoreCase);
	private static readonly Regex TierRx = new Regex(@"\((\d+)\)\s*$");

	public Breeding(Settings s, Action save) { _s = s; _save = save; Current = this; }

	private static string Dir
	{
		get
		{
			string d = Path.Combine(Util.BasePath, "Pets", "breeding");
			try { Directory.CreateDirectory(d); } catch { }
			return d;
		}
	}

	public void Start(string character)
	{
		_me = character ?? "";
		// (when each essence was first seen, as last saved - a baby stays "new" across a relog)
		try
		{
			if (File.Exists(MyFile))
				foreach (var p in ReadShared(File.ReadAllText(MyFile)).pets) if (p.FirstSeen != default) _firstSeen[p.Id] = p.FirstSeen;
		}
		catch { }
		try { if (File.Exists(SignalPath)) _signalSeen = ReadSignal().t; } catch { }
	}

	public void Tick()
	{
		try
		{
			var now = DateTime.Now;
			if (now >= _nextScan) { _nextScan = now.AddSeconds(5); Scan(); }
			CheckPair();
			if (HoldSummons && now - _holdSince > TimeSpan.FromSeconds(30)) { HoldSummons = false; Util.WriteToChat("Breed: 30 s without a litter - pet summoning carries on."); }
			if (_reIdId != 0 && now >= _reIdAt) { int rid = _reIdId; _reIdId = 0; try { Util.RequestId(rid); } catch { } }
			if (_dirty && now >= _nextShare) { _nextShare = now.AddSeconds(15); Share(); }
			if (now >= _nextRead) { _nextRead = now.AddSeconds(10); ReadOthers(); }
			CheckSignal();
		}
		catch (Exception ex) { Util.LogError(ex); }
	}

	// every essence in the pack: its description read (asked for, one a second, when it isn't there yet)
	private void Scan()
	{
		var core = CoreManager.Current;
		if (core?.CharacterFilter == null || string.IsNullOrEmpty(_me)) return;
		var seen = new HashSet<int>();
		var items = new Dictionary<string, int>();
		foreach (WorldObject wo in core.WorldFilter.GetInventory())
		{
			string name = wo.Name ?? "";
			if (name == Subjugation || name == Nurturing || Incenses.Contains(name))
			{
				int n = Math.Max(1, wo.Values(LongValueKey.StackCount, 1));
				items[name] = (items.TryGetValue(name, out int had) ? had : 0) + n;
				continue;
			}
			if (name.IndexOf("Essence", StringComparison.OrdinalIgnoreCase) < 0) continue;
			string desc = wo.Values(StringValueKey.FullDescription) ?? "";
			if (desc.Length == 0)
			{
				if (!_mine.ContainsKey(wo.Id) && DateTime.Now >= _nextIdAsk && name.Contains("(")) { _nextIdAsk = DateTime.Now.AddSeconds(1.2); try { Util.RequestId(wo.Id); } catch { } }
				if (!_mine.ContainsKey(wo.Id)) continue;
			}
			else if (desc.IndexOf("Sex:", StringComparison.OrdinalIgnoreCase) < 0) continue;   // (not a combat pet's)
			seen.Add(wo.Id);
			if (!_mine.TryGetValue(wo.Id, out var p))
			{
				if (!_firstSeen.ContainsKey(wo.Id)) _firstSeen[wo.Id] = _primed ? DateTime.Now : DateTime.MinValue.AddDays(1);
				_mine[wo.Id] = p = new Pet { Owner = _me, Id = wo.Id, FirstSeen = _firstSeen[wo.Id] };
				_dirty = true;
			}
			if (desc.Length > 0 && Parse(p, name, desc)) _dirty = true;
		}
		foreach (int gone in _mine.Keys.Where(k => !seen.Contains(k)).ToList()) { _mine.Remove(gone); _dirty = true; }
		if (!items.OrderBy(k => k.Key).SequenceEqual(_myItems.OrderBy(k => k.Key))) { _myItems = items; _dirty = true; }
		_primed = true;
	}

	private static int Int(Match m, int g) => m.Success && int.TryParse(m.Groups[g].Value.Replace(",", ""), out int v) ? v : 0;

	/// <summary>Reads an essence's description; true if anything changed.</summary>
	public static bool Parse(Pet p, string name, string desc)
	{
		var fs = p.FirstSeen; p.FirstSeen = default;
		string before = JsonSerializer.Serialize(p);
		p.Name = name;
		var t = TierRx.Match(name); p.Tier = t.Success ? int.Parse(t.Groups[1].Value) : 0;
		var sx = SexRx.Match(desc);
		p.Sex = sx.Success ? char.ToUpper(sx.Groups[1].Value[0]) + sx.Groups[1].Value.Substring(1).ToLower() : "";
		p.SexNote = sx.Success ? sx.Groups[2].Value.Trim() : "";
		var ch = ChargesRx.Match(desc);
		p.Charges = ch.Success ? Int(ch, 1) : -1; p.ChargesMax = ch.Success ? Int(ch, 2) : -1;
		p.Ready = p.ReadyNow;
		var g = GrowthRx.Match(desc); p.Growth = g.Success ? g.Groups[1].Value : "Adult";
		p.GrowthText = g.Success ? (g.Groups[1].Value + g.Groups[2].Value).Trim() : "";
		p.Bond = Int(BondRx.Match(desc), 1);
		p.Unbound = desc.IndexOf("Unbound", StringComparison.OrdinalIgnoreCase) >= 0;
		p.Potency = Int(PotencyRx.Match(desc), 1);
		p.Mutations = Int(MutsRx.Match(desc), 1);
		var d = DmgRx.Match(desc); p.Dmg = Int(d, 1); p.DmgMut = Int(d, 3);
		var r = DrRx.Match(desc); p.Dr = Int(r, 1); p.DrMut = Int(r, 3);
		var c = CritRx.Match(desc); p.Crit = Int(c, 1); p.CritMut = Int(c, 3);
		p.Translucency = Int(TransRx.Match(desc), 1);
		p.Shiny = name.IndexOf("Shiny", StringComparison.OrdinalIgnoreCase) >= 0 || Regex.IsMatch(desc, @"\bShiny\b", RegexOptions.IgnoreCase);
		p.Neutered = desc.IndexOf("Neutered", StringComparison.OrdinalIgnoreCase) >= 0;
		p.Read = true;
		bool changed = JsonSerializer.Serialize(p) != before;
		p.FirstSeen = fs;
		if (changed) p.Seen = DateTime.Now;
		return changed;
	}

	private string MyFile => Path.Combine(Dir, Safe(_me) + ".json");
	private static string Safe(string s) => string.Concat((s ?? "").Select(ch => Path.GetInvalidFileNameChars().Contains(ch) ? '_' : ch));

	private void Share()
	{
		_dirty = false;
		try { File.WriteAllText(MyFile, JsonSerializer.Serialize(new Shared { pets = _mine.Values.ToList(), items = _myItems })); } catch { }
	}

	private void ReadOthers()
	{
		var all = new List<Pet>();
		try
		{
			foreach (string f in Directory.GetFiles(Dir, "*.json"))
			{
				if (Path.GetFileName(f).Equals(Path.GetFileName(MyFile), StringComparison.OrdinalIgnoreCase) || Path.GetFileName(f) == "signal.json") continue;
				try
				{
					var sh = ReadShared(File.ReadAllText(f));
					all.AddRange(sh.pets);
					if (sh.pets.Count > 0) _theirItems[sh.pets[0].Owner] = sh.items;
					else _theirItems[Path.GetFileNameWithoutExtension(f)] = sh.items;
				}
				catch { }
			}
		}
		catch { }
		_others = all;
	}

	private static Shared ReadShared(string json)
	{
		json = json.TrimStart();
		if (json.StartsWith("[")) return new Shared { pets = JsonSerializer.Deserialize<List<Pet>>(json) ?? new List<Pet>() };   // (the first way it was kept)
		return JsonSerializer.Deserialize<Shared>(json) ?? new Shared();
	}

	private List<Pet> Everyone => _mine.Values.Concat(_others).ToList();

	private Dictionary<string, int> ItemsOf(string owner) => owner == _me ? _myItems : _theirItems.TryGetValue(owner, out var d) ? d : new Dictionary<string, int>();

	private static int Count(Dictionary<string, int> d, string name) => d.TryGetValue(name, out int n) ? n : 0;

	// one of mine of this name (the inventory item), for using it
	private static int ItemId(string name)
	{
		foreach (WorldObject wo in CoreManager.Current.WorldFilter.GetInventory()) if (wo.Name == name) return wo.Id;
		return 0;
	}

	/// <summary>Uses the best courtship incense this character has on this essence; what was used (null: none to use).</summary>
	private static string ApplyBestIncense(int essence)
	{
		foreach (string inc in Incenses)
		{
			int id = ItemId(inc);
			if (id == 0) continue;
			try { CoreManager.Current.Actions.ApplyItem(id, essence); } catch (Exception ex) { Util.LogError(ex); return null; }
			return inc;
		}
		return null;
	}

	// the baby, as can be expected from two parents: each line the better parent's value 55% of the time
	private static double Expect(int a, int b) => 0.55 * Math.Max(a, b) + 0.45 * Math.Min(a, b);

	private (Pet m, Pet f, double score)? BestPair() => BestOf(Breedable.Where(p => p.Why().Length == 0).ToList());

	private static double PairScore(Pet m, Pet f) =>
		Expect(m.Dmg, f.Dmg) + Expect(m.Dr, f.Dr) + 2 * Expect(m.Crit, f.Crit) + Expect(m.Potency, f.Potency) / 25.0
		+ 3 * Expect(m.DmgMut, f.DmgMut) + 3 * Expect(m.DrMut, f.DrMut) + 6 * Expect(m.CritMut, f.CritMut);

	private static (Pet m, Pet f, double score)? BestOf(List<Pet> all)
	{
		(Pet, Pet, double)? best = null;
		foreach (var m in all.Where(p => p.Male))
			foreach (var f in all.Where(p => p.Female && p.Owner != m.Owner))   // (two players dance: one pet each)
			{
				double sc = PairScore(m, f);
				if (best == null || sc > best.Value.Item3) best = (m, f, sc);
			}
		return best;
	}

	// what's worth doing before the next breeding: a pet that isn't grown or bonded yet, raised first, may make a
	// better pair than any there is to breed (rests and charges left out - they come back by themselves)
	private string SuggestedAction(List<Pet> everyone)
	{
		bool Sound(Pet p) => p.Read && p.Sex.Length > 0 && !p.Neutered;
		bool Ready(Pet p) => Sound(p) && p.Adult && p.Bond >= 100;
		var ready = everyone.Where(Ready).ToList();
		var now = BestOf(ready);
		var owners = everyone.Select(p => p.Owner).Where(o => o.Length > 0).Distinct().ToList();
		// every pet not grown or bonded yet, on each character it could be raised on: the best pair it would make
		var cands = new List<(Pet m, Pet f, double score, Pet raise)>();
		foreach (var y in everyone.Where(p => Sound(p) && !Ready(p)))
			foreach (var who in y.Unbound ? owners : new List<string> { y.Owner })
			{
				var as_ = y.As(who);
				var b = BestOf(ready.Concat(new[] { as_ }).ToList());
				if (b == null || (b.Value.m != as_ && b.Value.f != as_)) continue;
				cands.Add((b.Value.m, b.Value.f, b.Value.score, as_));
			}
		cands = cands.OrderByDescending(c => c.score).ToList();
		_suggestRaise = null; _suggestRaise2 = null; _suggestText2 = "";
		bool Beats((Pet m, Pet f, double score, Pet raise) c) => now == null || c.score >= now.Value.score * 1.03;
		if (cands.Count == 0 || !Beats(cands[0]))
			return now != null ? "Suggested action: breed the suggested pair - no pet growing now would make a better one." : "";
		var top = cands[0];
		_suggestRaise = top.raise;
		// the other character's own best to raise (a different pet, raised there)
		var second = cands.Where(c => c.raise.Owner != top.raise.Owner && c.raise.Id != top.raise.Id).Select(c => ((Pet m, Pet f, double score, Pet raise)?)c).FirstOrDefault();
		string otherChar = owners.FirstOrDefault(o => o != top.raise.Owner) ?? "";
		if (second != null)
		{
			_suggestRaise2 = second.Value.raise;
			_suggestText2 = "And on " + second.Value.raise.Owner + ": " + RaiseText(second.Value, now) + (Beats(second.Value) ? "" : " (it wouldn't beat the pair you can breed now, but it's the best growing on " + second.Value.raise.Owner + ")");
		}
		else if (otherChar.Length > 0) _suggestText2 = "And on " + otherChar + ": nothing growing there to raise for a better pair.";
		return "Suggested action: " + RaiseText(top, now);
	}
	private Pet _suggestRaise2;
	private string _suggestText2 = "";

	private static string RaiseText((Pet m, Pet f, double score, Pet raise) c, (Pet m, Pet f, double score)? now)
	{
		var r = c.raise;
		static string R(int v, int mut) => mut > 0 ? $"{v} (+{mut})" : v.ToString();
		string ratings = $"Dmg {R(r.Dmg, r.DmgMut)}, DR {R(r.Dr, r.DrMut)}, Crit {R(r.Crit, r.CritMut)}, Potency {r.Potency}, {r.Mutations} mutation{(r.Mutations == 1 ? "" : "s")}";
		var steps = new List<string>();
		if (!r.Adult) steps.Add($"level it to Adult (now {r.Growth}{(r.GrowthText.Length > 0 ? ": " + r.GrowthText : "")})");
		if (r.Bond < 100) steps.Add($"raise its bond to 100 (now {r.Bond})");
		var other = c.m == r ? c.f : c.m;
		string gain = now != null ? $" - about {(c.score / now.Value.score - 1) * 100:0}% better than the best pair you can breed now" : " - there's no pair to breed now";
		return $"raise {r.Name} [{r.Sex}, {ratings}] on {r.Owner}{(r.Unbound ? " (unbound: summon it there first)" : "")}: {string.Join(" and ", steps)}. "
		     + $"Then breed it with {other.Name} ({other.Owner}){gain}.";
	}

	// ---------------------------------------------------------------- together: summon and dance on both characters

	// what the server says of a breeding: a charge spent (that pet's count), a baby born (the parents looked at again)
	private static readonly Regex ChargeSpentRx = new Regex(@"\[Breeding\] (.+?) spent a breeding charge: (\d+)/(\d+)", RegexOptions.Compiled);
	public void OnChat(string text)
	{
		if (string.IsNullOrEmpty(text)) return;
		var m = ChargeSpentRx.Match(text);
		if (m.Success)
		{
			foreach (var p in _mine.Values)
				if (p.Name == m.Groups[1].Value) { p.Charges = int.Parse(m.Groups[2].Value); p.ChargesMax = int.Parse(m.Groups[3].Value); _dirty = true; }
			return;
		}
		if (text.Contains("A baby pet has been born"))
		{
			if (HoldSummons) { HoldSummons = false; Util.WriteToChat("Breed: baby born - pet summoning carries on (3. Summon both holds it again)."); }
			int mine = MyPairEssence();
			if (mine != 0) { try { Util.RequestId(mine); } catch { } }
			_nextScan = DateTime.Now.AddSeconds(2);
			}
	}

	private static string SignalPath => Path.Combine(Dir, "signal.json");

	// the pair picked, the same on both characters (whoever picks it)
	private static string PairPath => Path.Combine(Dir, "pair.json");
	private sealed class PairFile
	{
		public int maleId { get; set; }
		public string maleOwner { get; set; } = "";
		public int femaleId { get; set; }
		public string femaleOwner { get; set; } = "";
	}
	private long _pairSeen;
	private void SharePair()
	{
		try
		{
			File.WriteAllText(PairPath, JsonSerializer.Serialize(new PairFile { maleId = _maleId, maleOwner = _maleOwner, femaleId = _femaleId, femaleOwner = _femaleOwner }));
			_pairSeen = new DateTimeOffset(File.GetLastWriteTime(PairPath)).ToUnixTimeMilliseconds();
		}
		catch { }
	}
	private void CheckPair()
	{
		try
		{
			if (!File.Exists(PairPath)) return;
			long stamp = new DateTimeOffset(File.GetLastWriteTime(PairPath)).ToUnixTimeMilliseconds();
			if (stamp <= _pairSeen) return;
			_pairSeen = stamp;
			var pf = JsonSerializer.Deserialize<PairFile>(File.ReadAllText(PairPath));
			if (pf == null) return;
			_maleId = pf.maleId; _maleOwner = pf.maleOwner ?? ""; _femaleId = pf.femaleId; _femaleOwner = pf.femaleOwner ?? "";
		}
		catch { }
	}

	// this character's own essence of the pair, if it's in the pack here (0: none)
	private int MyPairEssence()
	{
		int id = _maleOwner == _me ? _maleId : _femaleOwner == _me ? _femaleId : 0;
		if (id == 0) return 0;
		try { foreach (WorldObject wo in CoreManager.Current.WorldFilter.GetInventory()) if (wo.Id == id) return id; } catch { }
		return 0;
	}

	private sealed class Signal
	{
		public long t { get; set; }
		public string action { get; set; } = "";
		public string from { get; set; } = "";
		public Dictionary<string, int> pets { get; set; } = new Dictionary<string, int>();   // owner -> essence to summon
	}

	private static Signal ReadSignal() { try { return JsonSerializer.Deserialize<Signal>(File.ReadAllText(SignalPath)) ?? new Signal(); } catch { return new Signal(); } }

	private void Send(string action)
	{
		var sig = new Signal { t = DateTimeOffset.Now.ToUnixTimeMilliseconds(), action = action, from = _me };
		if (_maleId != 0) sig.pets[_maleOwner] = _maleId;
		if (_femaleId != 0) sig.pets[_femaleOwner] = _femaleId;
		try { File.WriteAllText(SignalPath, JsonSerializer.Serialize(sig)); } catch { }
	}

	private void CheckSignal()
	{
		long stamp;
		try { if (!File.Exists(SignalPath)) return; stamp = new DateTimeOffset(File.GetLastWriteTime(SignalPath)).ToUnixTimeMilliseconds(); } catch { return; }
		if (stamp <= _signalSeen) return;
		var sig = ReadSignal();
		_signalSeen = Math.Max(stamp, sig.t);
		if (DateTimeOffset.Now.ToUnixTimeMilliseconds() - sig.t > 8000) return;   // (an old one)
		if (!sig.pets.TryGetValue(_me, out int id)) return;                          // (not one of the two)
		bool here = false;
		try { foreach (WorldObject wo in CoreManager.Current.WorldFilter.GetInventory()) if (wo.Id == id) { here = true; break; } } catch { }
		if (!here) { Util.WriteToChat("Breed: this character's pet of the pair isn't in the pack (" + sig.action + " not done)."); return; }
		switch (sig.action)
		{
			case "summon":
				HoldSummons = true; _holdSince = DateTime.Now;
				try { CoreManager.Current.Actions.UseItem(id, 0); Util.WriteToChat("Breed: summoning the breeding pet."); } catch { }
				break;
			case "incense":
			{
				string used = ApplyBestIncense(id);
				string pn = CoreManager.Current.WorldFilter[id]?.Name ?? "the breeding pet";
				Util.WriteToChat(used != null ? "Breed: " + used + " on " + pn + "." : "Breed: no courtship incense here to use.");
				break;
			}
			case "dance":
				try { CoreManager.Current.Actions.InvokeChatParser("/dance"); } catch { }
				break;
			case "done":
				HoldSummons = false;
				break;
		}
	}

	private static void Say(string text) { try { CoreManager.Current.Actions.InvokeChatParser(text); } catch (Exception ex) { Util.LogError(ex); } }

	private static void Tip(string t) { if (ImGui.IsItemHovered()) Im.SetTooltip(t); }

	// ---------------------------------------------------------------- the tab

	// (only level 300 essences breed, and never a shiny: the others aren't listed at all)
	private IEnumerable<Pet> Breedable => Everyone.Where(p => p.Tier == 300 && !p.Shiny);

	public void Draw()
	{
		var everyone = Breedable.ToList();
		var best = BestPair();

		// commands
		if (ImGui.Button("Courtship dance")) Say("/dance");
		Tip("/dance - the courtship dance. Both owners within 5 seconds, the two pets side by side.");
		ImGui.SameLine();
		if (ImGui.Button("Breed check")) Say("@breed-debug");
		Tip("@breed-debug - checks your location, your pet's sex and its charges.");
		ImGui.SameLine();
		if (ImGui.Button("Pet description")) Say("@petdesc");
		Tip("@petdesc - your pet's appearance details.");
		ImGui.SameLine();
		if (ImGui.Button("Pet registry")) Say("@pets");
		Tip("@pets - your Pet Registry.");
		ImGui.Separator();

		// the pair
		Im.TextColored(Cyan, "Breeding pair");
		Pet male = everyone.FirstOrDefault(p => p.Id == _maleId && p.Owner == _maleOwner);
		Pet female = everyone.FirstOrDefault(p => p.Id == _femaleId && p.Owner == _femaleOwner);
		if (male == null && female == null && best != null)
		{
			Im.TextColored(Dim, $"Suggested: {best.Value.m.Name} ({best.Value.m.Owner}) x {best.Value.f.Name} ({best.Value.f.Owner})");
			ImGui.SameLine();
			if (ImGui.SmallButton("Use this pair")) { Pick(best.Value.m); Pick(best.Value.f); }
		}
		if (male == null && female == null)
		{
			string act = SuggestedAction(everyone);
			if (act.Length > 0) { ImGui.PushStyleColor(ImGuiCol.Text, Cyan); Line(act); ImGui.PopStyleColor(); }
			if (_suggestRaise != null && ImGui.SmallButton("Select it below##s1"))
			{
				// (by its id: the owner it has now - an unbound one was tried on either character)
				var real = everyone.FirstOrDefault(p => p.Id == _suggestRaise.Id);
				if (real != null) SelectBaby(real);
			}
			if (_suggestText2.Length > 0) { ImGui.PushStyleColor(ImGuiCol.Text, Cyan); Line(_suggestText2); ImGui.PopStyleColor(); }
			if (_suggestRaise2 != null && ImGui.SmallButton("Select it below##s2"))
			{
				var real = everyone.FirstOrDefault(p => p.Id == _suggestRaise2.Id);
				if (real != null) SelectBaby(real);
			}
		}
		ImGui.TextUnformatted("Male:   "); ImGui.SameLine(); Im.TextColored(White, male != null ? $"{male.Name} - {male.Owner}" : "(pick one below)");
		ImGui.TextUnformatted("Female: "); ImGui.SameLine(); Im.TextColored(Pink, female != null ? $"{female.Name} - {female.Owner}  (the baby goes to {female.Owner})" : "(pick one below)");
		if (male != null && female != null)
		{
			if (male.Owner == female.Owner) Im.TextColored(Bad, "Both are one character's - two players dance, one pet each. Pick one from the other character.");
			string mw = male.Why(), fw = female.Why();
			if (mw.Length > 0) Im.TextColored(Bad, "Male: " + mw);
			if (fw.Length > 0) Im.TextColored(Bad, "Female: " + fw);
			ImGui.TextUnformatted("Baby can be expected to have: " +
				$"Damage {Expect(male.Dmg, female.Dmg):0.#} (mut {Expect(male.DmgMut, female.DmgMut):0.#}), " +
				$"Damage Resist {Expect(male.Dr, female.Dr):0.#} (mut {Expect(male.DrMut, female.DrMut):0.#}), " +
				$"Crit {Expect(male.Crit, female.Crit):0.#} (mut {Expect(male.CritMut, female.CritMut):0.#}), " +
				$"Potency {Expect(male.Potency, female.Potency):0}");
			Tip("Each line takes the better parent's value 55% of the time, the other's 45% (mutations come with their line).\nAbout 1 litter in 13 also mutates: +10 Damage, +10 Damage Resist, +5 Crit or +50 Vitality, or +25 Potency.");
			bool both = male.Owner != female.Owner;
			// what each has for a litter
			foreach (var owner in new[] { male.Owner, female.Owner }.Distinct())
			{
				var it = ItemsOf(owner);
				Im.TextColored(Dim, $"{owner}: Exquisite {Count(it, Incenses[0])}, Refined {Count(it, Incenses[1])}, Lesser {Count(it, Incenses[2])} courtship incense; {Count(it, Subjugation)} Offering of Subjugation; {Count(it, Nurturing)} Nurturing Draught");
			}
			Pet myParent = male.Owner == _me ? male : female.Owner == _me ? female : null;
			if (!both) ImGui.BeginDisabled();
			if (ImGui.Button("1. Incense on both")) Send("incense");
			Tip("Both characters use their best courtship incense (Exquisite, else Refined, else Lesser) on their pet of the pair - the bonuses add up: Exquisite on both is 25% on a fresh line. Used up by the next litter.");
			ImGui.SameLine();
			if (myParent == null) ImGui.BeginDisabled();
			if (ImGui.Button("2. Offering of Subjugation"))
			{
				int id = ItemId(Subjugation);
				int mine = MyPairEssence();
				if (mine == 0) Util.WriteToChat("Breed: this character's pet of the pair isn't in the pack.");
				else if (id == 0) Util.WriteToChat("Breed: no Offering of Subjugation here.");
				else { try { CoreManager.Current.Actions.ApplyItem(id, mine); Util.WriteToChat("Breed: Offering of Subjugation on " + myParent.Name + "."); } catch (Exception ex) { Util.LogError(ex); } }
			}
			Tip("On your parent of the pair (this character's): if the litter mutates, the spirit hits for half and takes 2.5x damage - win the fight for an extra mutation. Only used up when there's a fight.");
			if (myParent == null) ImGui.EndDisabled();
			ImGui.SameLine();
			if (ImGui.Button("3. Summon both")) Send("summon");
			Tip("Both characters' MelkTanks summon their pet of the pair (their pet summoning is held off while breeding). Stand the two pets on the same patch of floor.");
			ImGui.SameLine();
			if (ImGui.Button("4. Dance together")) Send("dance");
			Tip("Both characters /dance at once.");
			ImGui.SameLine();
			if (ImGui.Button("Done")) { Send("done"); HoldSummons = false; }
			Tip("Breeding over: pet summoning carries on as usual on both.");
			if (!both) ImGui.EndDisabled();
			ImGui.SameLine();
			if (ImGui.SmallButton("Clear pair")) { _maleId = _femaleId = 0; _maleOwner = _femaleOwner = ""; SharePair(); }
		}
		if (HoldSummons) Im.TextColored(Cyan, "Breeding: pet summoning is held off (Done carries it on).");
		ImGui.Separator();

		// the grown ones, both characters
		var adults = everyone.Where(p => p.Adult).ToList();
		var young = everyone.Where(p => !p.Adult).ToList();
		Im.TextColored(Cyan, $"Adults ({adults.Count}) - click one to pick it for the pair");
		PetTable("breedpets", adults.OrderByDescending(x => x.Why().Length == 0).ThenByDescending(x => x.Score), 200, false);
		Im.TextColored(Dim, "The other characters' essences come from their MelkTank (as they last saw them). Ratings include mutations; the mutations' share is in brackets.");

		// the young: best first - who to raise them on
		ImGui.Spacing();
		Im.TextColored(Cyan, $"Babies and growing ({young.Count}) - raise the top ones first");
		Tip("Best first (mutations, then stats and potency). 'Raise on' is who should summon an unbound newborn first - it imprints on them:\nmales on the stud's side, females on the other character, so the two always make a pair (the baby goes to the female's owner).");
		PetTable("breedyoung", young.OrderByDescending(x => x.Score), 150, true);
		var baby = young.FirstOrDefault(p => p.Id == _babyId && p.Owner == _babyOwner);
		int draughts = Count(ItemsOf(_me), Nurturing);
		bool babyHere = baby != null && baby.Owner == _me;
		if (!babyHere) ImGui.BeginDisabled();
		bool listed = baby != null && (PetSummoner.Current?.Has(baby.Id) ?? false);
		if (ImGui.Button(listed ? "On pets list" : "Add to pets list") && !listed) PetSummoner.Current?.AddById(baby.Id);
		Tip("Puts this very essence on the Pets list (by its id - many have the same name, in different packs), so it's the one summoned.");
		ImGui.SameLine();
		if (ImGui.Button($"Use Nurturing Draught ({draughts})"))
		{
			int id = ItemId(Nurturing);
			bool inPack = false;
			try { foreach (WorldObject wo in CoreManager.Current.WorldFilter.GetInventory()) if (wo.Id == baby.Id) { inPack = true; break; } } catch { }
			if (!inPack) Util.WriteToChat("Breed: " + baby.Name + " isn't in the pack.");
			else if (id == 0) Util.WriteToChat("Breed: no Nurturing Draught here.");
			else { try { CoreManager.Current.Actions.ApplyItem(id, baby.Id); Util.WriteToChat("Breed: Nurturing Draught on " + baby.Name + "."); int bid = baby.Id; _nextScan = DateTime.Now.AddSeconds(3); _reIdId = bid; _reIdAt = DateTime.Now.AddSeconds(1.5); } catch (Exception ex) { Util.LogError(ex); } }
		}
		if (!babyHere) ImGui.EndDisabled();
		ImGui.SameLine();
		Im.TextColored(Dim, baby == null ? "(click a baby above)" : baby.Owner == _me ? baby.Name : $"{baby.Name} is {baby.Owner}'s - use it from there");

		if (ImGui.CollapsingHeader("How to get the best pets (Melka and Melkoran)"))
		{
			Plan();
		}
	}

	// who should summon an unbound baby first: males with the stud, females on the other character
	private string RaiseOn(Pet p, List<Pet> everyone)
	{
		if (!p.Unbound) return p.Owner + " (bound)";
		var owners = everyone.Select(x => x.Owner).Where(o => o.Length > 0).Distinct().ToList();
		var stud = everyone.Where(x => x.Male && x.Adult && !x.Neutered).OrderByDescending(x => x.Score).FirstOrDefault();
		string studSide = stud?.Owner ?? p.Owner;
		string other = owners.FirstOrDefault(o => o != studSide) ?? p.Owner;
		return p.Male ? studSide : p.Female ? other : p.Owner;
	}

	private void PetTable(string id, IEnumerable<Pet> pets, float height, bool young)
	{
		var list = pets.ToList();
		var everyone = Breedable.ToList();
		// (the newest baby, seen in the last day: in green)
		var newest = list.Where(x => x.FirstSeen > DateTime.Now.AddDays(-1)).OrderByDescending(x => x.FirstSeen).FirstOrDefault();
		if (!ImGui.BeginTable(id, young ? 10 : 9, ImGuiTableFlags.RowBg | ImGuiTableFlags.BordersInnerH | ImGuiTableFlags.ScrollY, new Vector2(0, height))) return;
		ImGui.TableSetupColumn("Essence", ImGuiTableColumnFlags.WidthStretch);
		ImGui.TableSetupColumn("Owner", ImGuiTableColumnFlags.WidthFixed, 90);
		ImGui.TableSetupColumn("Sex", ImGuiTableColumnFlags.WidthFixed, 110);
		ImGui.TableSetupColumn(young ? "Growth" : "Growth", ImGuiTableColumnFlags.WidthFixed, young ? 150 : 60);
		ImGui.TableSetupColumn("Dmg", ImGuiTableColumnFlags.WidthFixed, 65);
		ImGui.TableSetupColumn("DR", ImGuiTableColumnFlags.WidthFixed, 65);
		ImGui.TableSetupColumn("Crit", ImGuiTableColumnFlags.WidthFixed, 65);
		ImGui.TableSetupColumn("Pot", ImGuiTableColumnFlags.WidthFixed, 45);
		if (young) { ImGui.TableSetupColumn("Raise on", ImGuiTableColumnFlags.WidthFixed, 120); ImGui.TableSetupColumn("#", ImGuiTableColumnFlags.WidthFixed, 24); }
		else ImGui.TableSetupColumn("Can breed", ImGuiTableColumnFlags.WidthFixed, 150);
		ImGui.TableSetupScrollFreeze(0, 1);
		ImGui.TableHeadersRow();
		int rank = 0;
		foreach (var p in list)
		{
			rank++;
			ImGui.TableNextRow();
			ImGui.TableNextColumn();
			bool picked = young ? p.Id == _babyId && p.Owner == _babyOwner : (p.Id == _maleId && p.Owner == _maleOwner) || (p.Id == _femaleId && p.Owner == _femaleOwner);
			bool isNew = p == newest;
			if (isNew) ImGui.PushStyleColor(ImGuiCol.Text, Good);
			if (ImGui.Selectable(p.Name + (isNew ? "  (new)" : "") + "##" + p.Owner + p.Id, picked, ImGuiSelectableFlags.SpanAllColumns)) { if (young) SelectBaby(p); else Pick(p); }
			if (isNew) ImGui.PopStyleColor();
			if (ImGui.IsItemHovered()) Im.SetTooltip($"{p.Name}\nBond {p.Bond:N0}{(p.Unbound ? " (unbound - imprints on first summon)" : "")}, mutations {p.Mutations}, translucency {p.Translucency}%\nDamage {p.Dmg} (+{p.DmgMut} mut), Damage Resist {p.Dr} (+{p.DrMut}), Crit {p.Crit} (+{p.CritMut}), Potency {p.Potency}" + (p.GrowthText.Length > 0 ? "\n" + p.GrowthText : ""));
			ImGui.TableNextColumn(); ImGui.TextUnformatted(p.Owner);
			ImGui.TableNextColumn();
			if (p.Male) Im.TextColored(White, p.Charges >= 0 ? $"Male {p.Charges}/{p.ChargesMax}" : "Male");
			else if (p.Female) Im.TextColored(Pink, p.ReadyNow ? "Female, ready" : young ? "Female" : p.RestLeft.Length > 0 ? "Female, rests " + p.RestLeft : "Female" + (p.SexNote.Length > 0 ? ", " + p.SexNote : ""));
			else Im.TextColored(Dim, p.Read ? "-" : "?");
			ImGui.TableNextColumn(); ImGui.TextUnformatted(young && p.GrowthText.Length > 0 ? p.GrowthText : p.Growth);
			ImGui.TableNextColumn(); ImGui.TextUnformatted(p.DmgMut > 0 ? $"{p.Dmg} (+{p.DmgMut})" : p.Dmg.ToString());
			ImGui.TableNextColumn(); ImGui.TextUnformatted(p.DrMut > 0 ? $"{p.Dr} (+{p.DrMut})" : p.Dr.ToString());
			ImGui.TableNextColumn(); ImGui.TextUnformatted(p.CritMut > 0 ? $"{p.Crit} (+{p.CritMut})" : p.Crit.ToString());
			ImGui.TableNextColumn(); ImGui.TextUnformatted(p.Potency.ToString());
			ImGui.TableNextColumn();
			if (young)
			{
				string on = RaiseOn(p, everyone);
				if (p.Unbound) Im.TextColored(Cyan, on); else Im.TextColored(Dim, on);
				ImGui.TableNextColumn(); ImGui.TextUnformatted(rank.ToString());
			}
			else
			{
				string why = p.Why();
				if (why.Length == 0) Im.TextColored(Good, "yes"); else Im.TextColored(Dim, why);
			}
		}
		ImGui.EndTable();
	}

	// a baby picked: in the list, and in the game too when it's this character's
	private void SelectBaby(Pet p)
	{
		_babyId = p.Id; _babyOwner = p.Owner;
		if (p.Owner == _me) { try { CoreManager.Current.Actions.SelectItem(p.Id); } catch { } }
	}

	private void Pick(Pet p)
	{
		if (p.Male) { _maleId = p.Id; _maleOwner = p.Owner; }
		else if (p.Female) { _femaleId = p.Id; _femaleOwner = p.Owner; }
		SharePair();
	}

	private static void Line(string s) { ImGui.PushTextWrapPos(0); ImGui.TextUnformatted(s); ImGui.PopTextWrapPos(); }

	private static void Plan()
	{
		Im.TextColored(Cyan, "The idea");
		Line("A stat mutation is +10 Damage, +10 Damage Resist, +5 Crit or +50 Vitality; a potency mutation +25 Potency. Mutations are permanent, pass down with their line and stack with no cap. So the best pet is grown over generations: keep every mutated baby, raise it, and breed mutated parents together so their lines join in one baby.");
		Im.TextColored(Cyan, "The two characters");
		Line("One player per pet, so it's always one of Melka's with one of Melkoran's. A male has 10 litters a day, a female one every 4 hours - so the best male (the stud) does most of the work, and each character keeps a few females to rotate. The baby goes to whoever owns the female, so keep females on the character you want the babies on.");
		Im.TextColored(Cyan, "Each litter");
		Line("1. Both to Ruggan's Annex (Portal to Seedy Motel in Lin, about 54.7S 73.5E). The female's owner needs a free main-pack slot.");
		Line("2. Exquisite Courtship Incense on both parents: up to +10% each, 25% stat-mutation chance on a fresh line (it shrinks as the line collects mutations, never below 2%). Used up by the litter either way.");
		Line("3. Offering of Subjugation on a parent: if the litter mutates, the spirit hits for half and takes 2.5x - win the 90 s fight for one extra mutation (the Awakened Blessing). Only used up when there is a fight.");
		Line("4. Summon both, pets on the same patch of floor, dance together (the buttons above do it on both characters). Not just before a server restart - a restart mid-fight loses the litter.");
		Im.TextColored(Cyan, "Raising them");
		Line("Babies are born at half size and strength and grow at 60/120/180/240/300 kills (Adult at 300): your pet out, doing 10%+ of the creature's health, on creatures at or above the essence's tier in level. A Nurturing Draught counts kills double. Only adults breed.");
		Line("A bred essence imprints on the first character who summons it: summon a baby only on the character that will keep it (sell spares before anyone summons them).");
		Im.TextColored(Cyan, "Choosing parents");
		Line("Pick by the mutation numbers first (the + numbers in the list): each line takes the better parent's value 55% of the time, so two parents strong on different lines give the best chance of a baby with both. Potency comes down too. Breed a mutated baby back to the stud once it's grown, and pair mutated adults with each other.");
		Im.TextColored(Cyan, "The look");
		Line("Once the stats are right, the look is separate: a Pet Tailoring Kit moves one pet's whole look (and damage type) onto another, keeping its stats and mutations; applying a siphoned or hollow essence changes the look, and a weapon-holder's damage type. Mutagenic Serum re-rolls the colour; Solidifying / Fading Tincture changes how see-through it is.");
	}
}
