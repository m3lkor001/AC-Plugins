using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using Decal.Adapter;
using Decal.Adapter.Wrappers;

namespace MelkTank.Pets;

public static class ObjectDump
{
	private const string DumpFile = "MelkTank_Dump.txt";

	private static readonly Dictionary<int, string> DumpMaterials = new Dictionary<int, string>
	{
		{ 1, "Ceramic" },
		{ 2, "Porcelain" },
		{ 4, "Linen" },
		{ 5, "Satin" },
		{ 6, "Silk" },
		{ 7, "Velvet" },
		{ 8, "Wool" },
		{ 10, "Agate" },
		{ 11, "Amber" },
		{ 12, "Amethyst" },
		{ 13, "Aquamarine" },
		{ 14, "Azurite" },
		{ 15, "Black Garnet" },
		{ 16, "Black Opal" },
		{ 17, "Bloodstone" },
		{ 18, "Carnelian" },
		{ 19, "Citrine" },
		{ 20, "Diamond" },
		{ 21, "Emerald" },
		{ 22, "Fire Opal" },
		{ 23, "Green Garnet" },
		{ 24, "Green Jade" },
		{ 25, "Hematite" },
		{ 26, "Imperial Topaz" },
		{ 27, "Jet" },
		{ 28, "Lapis Lazuli" },
		{ 29, "Lavender Jade" },
		{ 30, "Malachite" },
		{ 31, "Moonstone" },
		{ 32, "Onyx" },
		{ 33, "Opal" },
		{ 34, "Peridot" },
		{ 35, "Red Garnet" },
		{ 36, "Red Jade" },
		{ 37, "Rose Quartz" },
		{ 38, "Ruby" },
		{ 39, "Sapphire" },
		{ 40, "Smokey Quartz" },
		{ 41, "Sunstone" },
		{ 42, "Tiger Eye" },
		{ 43, "Tourmaline" },
		{ 44, "Turquoise" },
		{ 45, "White Jade" },
		{ 46, "White Quartz" },
		{ 47, "White Sapphire" },
		{ 48, "Yellow Garnet" },
		{ 49, "Yellow Topaz" },
		{ 50, "Zircon" },
		{ 51, "Ivory" },
		{ 52, "Leather" },
		{ 53, "Armoredillo Hide" },
		{ 54, "Gromnie Hide" },
		{ 55, "Reed Shark Hide" },
		{ 57, "Brass" },
		{ 58, "Bronze" },
		{ 59, "Copper" },
		{ 60, "Gold" },
		{ 61, "Iron" },
		{ 62, "Pyreal" },
		{ 63, "Silver" },
		{ 64, "Steel" },
		{ 66, "Alabaster" },
		{ 67, "Granite" },
		{ 68, "Marble" },
		{ 69, "Obsidian" },
		{ 70, "Sandstone" },
		{ 71, "Serpentine" },
		{ 73, "Ebony" },
		{ 74, "Mahogany" },
		{ 75, "Oak" },
		{ 76, "Pine" },
		{ 77, "Teak" }
	};

	public static void DumpSelected()
	{
		int currentSelection = Globals.Core.Actions.CurrentSelection;
		if (currentSelection == 0)
		{
			Util.WriteToChat("Dump: select an item, monster or pet first.");
			return;
		}
		WorldObject worldObject = Globals.Core.WorldFilter[currentSelection];
		if (worldObject == null)
		{
			Util.WriteToChat("Dump: the selected object isn't known.");
		}
		else
		{
			DumpObjectValues(worldObject, "Manual dump: " + DumpFullName(worldObject));
		}
	}

	public static void DumpTo(string file, WorldObject obj, string label)
	{
		DumpObjectValues(obj, label, full: true, file);
	}

	public static void DumpObjectValues(WorldObject obj, string label, bool full = true, string file = null)
	{
		if (obj == null)
		{
			Util.WriteToChat("Dump: Debug dump: object is null.");
			return;
		}
		try
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine("============================================================");
			stringBuilder.AppendLine(DateTime.Now.ToString() + "   " + label);
			stringBuilder.AppendLine("Object: " + DumpFullName(obj) + "   (Id " + obj.Id + ")");
			try
			{
				string value = obj.Values(StringValueKey.FullDescription);
				if (string.IsNullOrEmpty(value))
				{
					stringBuilder.AppendLine("  *** FullDescription is empty - item not identified yet. ***");
					stringBuilder.AppendLine("  *** Select or examine it once in-game, then run this dump again. ***");
				}
			}
			catch
			{
			}
			if (full)
			{
				stringBuilder.AppendLine("-- WorldObject properties (reflection) --");
				try
				{
					PropertyInfo[] properties = obj.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);
					foreach (PropertyInfo propertyInfo in properties)
					{
						if (propertyInfo.GetIndexParameters().Length != 0)
						{
							continue;
						}
						try
						{
							object value2 = propertyInfo.GetValue(obj, null);
							if (value2 != null)
							{
								string text = value2.ToString();
								if (!string.IsNullOrEmpty(text) && !(text == "0") && !(text == "False"))
								{
									stringBuilder.AppendLine("  " + propertyInfo.Name + " = " + text);
								}
							}
						}
						catch
						{
						}
					}
				}
				catch
				{
				}
				stringBuilder.AppendLine("-- Position --");
				try
				{
					stringBuilder.AppendLine("  RawCoordinates = X:" + obj.RawCoordinates().X + " Y:" + obj.RawCoordinates().Y + " Z:" + obj.RawCoordinates().Z);
				}
				catch
				{
				}
				try
				{
					stringBuilder.AppendLine("  LandblockKey (top16 of 0xD000003) = " + ((obj.Values(LongValueKey.Landblock) >>> 16) & 0xFFFF));
				}
				catch
				{
				}
			}
			stringBuilder.AppendLine("-- LongValueKey (nonzero) --");
			foreach (LongValueKey value3 in Enum.GetValues(typeof(LongValueKey)))
			{
				try
				{
					int num = obj.Values(value3);
					if (num != 0)
					{
						string[] array = new string[6]
						{
							"  ",
							value3.ToString(),
							" (0x",
							null,
							null,
							null
						};
						int num2 = (int)value3;
						array[3] = num2.ToString("X");
						array[4] = ") = ";
						array[5] = num.ToString();
						stringBuilder.AppendLine(string.Concat(array));
					}
				}
				catch
				{
				}
			}
			stringBuilder.AppendLine("-- DoubleValueKey (nonzero) --");
			foreach (DoubleValueKey value4 in Enum.GetValues(typeof(DoubleValueKey)))
			{
				try
				{
					double num3 = obj.Values(value4);
					if (num3 != 0.0)
					{
						string[] array2 = new string[6]
						{
							"  ",
							value4.ToString(),
							" (0x",
							null,
							null,
							null
						};
						int num2 = (int)value4;
						array2[3] = num2.ToString("X");
						array2[4] = ") = ";
						array2[5] = num3.ToString();
						stringBuilder.AppendLine(string.Concat(array2));
					}
				}
				catch
				{
				}
			}
			stringBuilder.AppendLine("-- BoolValueKey (true only) --");
			foreach (BoolValueKey value5 in Enum.GetValues(typeof(BoolValueKey)))
			{
				try
				{
					if (obj.Values(value5))
					{
						string[] array3 = new string[5]
						{
							"  ",
							value5.ToString(),
							" (0x",
							null,
							null
						};
						int num2 = (int)value5;
						array3[3] = num2.ToString("X");
						array3[4] = ") = true";
						stringBuilder.AppendLine(string.Concat(array3));
					}
				}
				catch
				{
				}
			}
			stringBuilder.AppendLine("-- StringValueKey (non-empty) --");
			foreach (StringValueKey value6 in Enum.GetValues(typeof(StringValueKey)))
			{
				try
				{
					string text2 = obj.Values(value6);
					if (!string.IsNullOrEmpty(text2))
					{
						string[] array4 = new string[6]
						{
							"  ",
							value6.ToString(),
							" (0x",
							null,
							null,
							null
						};
						int num2 = (int)value6;
						array4[3] = num2.ToString("X");
						array4[4] = ") = ";
						array4[5] = text2;
						stringBuilder.AppendLine(string.Concat(array4));
					}
				}
				catch
				{
				}
			}
			stringBuilder.AppendLine("-- Spells --");
			try
			{
				int spellCount = obj.SpellCount;
				for (int j = 0; j < spellCount; j++)
				{
					int id = obj.Spell(j);
					stringBuilder.AppendLine("  " + id + " = " + (DumpSpellName(id) ?? "?"));
				}
				if (spellCount == 0)
				{
					stringBuilder.AppendLine("  (none)");
				}
			}
			catch (Exception ex)
			{
				stringBuilder.AppendLine("  (couldn't list: " + ex.Message + ")");
			}
			stringBuilder.AppendLine("-- Other properties (no Decal name) --");
			try
			{
				foreach (int longKey in obj.LongKeys)
				{
					if (!Enum.IsDefined(typeof(LongValueKey), longKey))
					{
						try
						{
							stringBuilder.AppendLine("  int #" + longKey + " (0x" + longKey.ToString("X") + ") = " + obj.Values((LongValueKey)longKey));
						}
						catch
						{
						}
					}
				}
				foreach (int doubleKey in obj.DoubleKeys)
				{
					if (!Enum.IsDefined(typeof(DoubleValueKey), doubleKey))
					{
						try
						{
							stringBuilder.AppendLine("  double #" + doubleKey + " (0x" + doubleKey.ToString("X") + ") = " + obj.Values((DoubleValueKey)doubleKey));
						}
						catch
						{
						}
					}
				}
				foreach (int boolKey in obj.BoolKeys)
				{
					if (!Enum.IsDefined(typeof(BoolValueKey), boolKey))
					{
						try
						{
							stringBuilder.AppendLine("  bool #" + boolKey + " (0x" + boolKey.ToString("X") + ") = " + obj.Values((BoolValueKey)boolKey));
						}
						catch
						{
						}
					}
				}
				foreach (int stringKey in obj.StringKeys)
				{
					if (!Enum.IsDefined(typeof(StringValueKey), stringKey))
					{
						try
						{
							stringBuilder.AppendLine("  string #" + stringKey + " (0x" + stringKey.ToString("X") + ") = " + obj.Values((StringValueKey)stringKey));
						}
						catch
						{
						}
					}
				}
			}
			catch (Exception ex2)
			{
				stringBuilder.AppendLine("  (couldn't list: " + ex2.Message + ")");
			}
			stringBuilder.AppendLine("============================================================");
			stringBuilder.AppendLine();
			string path = Util.FullPath(file ?? "MelkTank_Dump.txt");
			Util.AppendShared(path, stringBuilder.ToString());
			if (file == null)
			{
				Util.WriteToChat("Dump: Debug: wrote \"" + label + "\" to MelkTank_Dump.txt");
			}
		}
		catch (Exception ex3)
		{
			Util.WriteToChat("Dump: Dump error: " + ex3.Message);
		}
	}

	private static string DumpFullName(WorldObject obj)
	{
		string text = obj.Name ?? "";
		try
		{
			if (DumpMaterials.TryGetValue(obj.Values(LongValueKey.Material), out var value) && !text.StartsWith(value + " "))
			{
				return value + " " + text;
			}
		}
		catch
		{
		}
		return text;
	}

	private static string DumpSpellName(int id)
	{
		try
		{
			Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
			foreach (Assembly assembly in assemblies)
			{
				Type type = assembly.GetType("MelkTank.Loot.SpellNames");
				if (!(type == null))
				{
					string text = type.GetMethod("Name", new Type[1] { typeof(int) }).Invoke(null, new object[1] { id }) as string;
					if (!string.IsNullOrEmpty(text))
					{
						return text;
					}
					break;
				}
			}
		}
		catch
		{
		}
		try
		{
			object current = CoreManager.Current;
			object obj2 = null;
			try
			{
				PropertyInfo property = current.GetType().GetProperty("FileService");
				if (property != null)
				{
					obj2 = property.GetValue(current, null);
				}
			}
			catch
			{
			}
			if (obj2 == null)
			{
				Assembly[] assemblies2 = AppDomain.CurrentDomain.GetAssemblies();
				foreach (Assembly assembly2 in assemblies2)
				{
					Type type2 = assembly2.GetType("Decal.Filters.FileService");
					if (!(type2 == null))
					{
						MethodInfo method = current.GetType().GetMethod("Filter");
						if (method != null)
						{
							obj2 = method.MakeGenericMethod(type2).Invoke(current, null);
						}
						break;
					}
				}
			}
			if (obj2 == null)
			{
				return null;
			}
			object value = obj2.GetType().GetProperty("SpellTable").GetValue(obj2, null);
			object obj4 = value.GetType().GetMethod("GetById", new Type[1] { typeof(int) }).Invoke(value, new object[1] { id });
			return (obj4 == null) ? null : (obj4.GetType().GetProperty("Name").GetValue(obj4, null) as string);
		}
		catch
		{
			return null;
		}
	}

	public static void DumpActionMethodNames()
	{
		try
		{
			object actions = Globals.Core.Actions;
			if (actions == null)
			{
				Util.WriteToChat("Dump: Globals.Core.Actions is null.");
				return;
			}
			Type type = actions.GetType();
			MethodInfo[] methods = type.GetMethods(BindingFlags.Instance | BindingFlags.Public);
			List<string> list = new List<string>();
			MethodInfo[] array = methods;
			foreach (MethodInfo methodInfo in array)
			{
				ParameterInfo[] parameters = methodInfo.GetParameters();
				string text = "";
				ParameterInfo[] array2 = parameters;
				foreach (ParameterInfo parameterInfo in array2)
				{
					if (text.Length > 0)
					{
						text += ", ";
					}
					text = text + parameterInfo.ParameterType.Name + " " + parameterInfo.Name;
				}
				list.Add(methodInfo.ReturnType.Name + " " + methodInfo.Name + "(" + text + ")");
			}
			list.Sort();
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine("============================================================");
			stringBuilder.AppendLine(DateTime.Now.ToString() + "   Globals.Core.Actions method list (" + type.FullName + ")");
			foreach (string item in list)
			{
				stringBuilder.AppendLine("  " + item);
			}
			stringBuilder.AppendLine("============================================================");
			stringBuilder.AppendLine();
			string path = Util.FullPath("MelkTank_Dump.txt");
			Util.AppendShared(path, stringBuilder.ToString());
			Util.WriteToChat("Dump: Wrote " + list.Count + " Globals.Core.Actions method signatures to MelkTank_Dump.txt. Look for anything with 'exam', 'id', 'appraise', or 'inquir' in the name.");
		}
		catch (Exception ex)
		{
			Util.WriteToChat("Dump: listactions error: " + ex.Message);
		}
	}
}
