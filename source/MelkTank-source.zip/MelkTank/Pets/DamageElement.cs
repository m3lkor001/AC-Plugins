namespace MelkTank.Pets;

public enum DamageElement
{
	None,
	Nether,
	Bludgeon,
	Slash,
	Pierce,
	Fire,
	Cold,
	Acid,
	Lightning
}
