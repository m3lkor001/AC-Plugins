namespace MelkTank;

public enum StepKind
{
	Point,
	Command,
	Use,
	Wait,
	LoopStart,
	Toggle,
	Cast,
	ChatWait,
	ItemCheck,
	LoopEnd,
	GoRoute,
	UseItem,
	Preset,
	PlayerSkip,
	Vendor
}
