using System;
using System.Collections.Generic;
using System.IO;
using System.Numerics;
using ImGuiNET;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

/// <summary>
/// Keys that run MelkTank (or any chat) commands - up to three each, in order - in the game window that has the keys
/// (so the other characters you're running aren't touched), never while you're typing. Settings > Commands > Hotkeys.
/// Kept for every character (MelkTank_Hotkeys.txt).
/// </summary>
public static class Hotkeys
{
	public class Key
	{
		public string Name = "";

		public int Mask;

		public string[] Cmds = new string[3] { "", "", "" };
	}

	private static readonly Vector4 Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f);

	private static readonly Vector4 Yellow = new Vector4(1f, 0.85f, 0.3f, 1f);

	private static readonly Vector4 Red = new Vector4(1f, 0.45f, 0.4f, 1f);

	private static List<Key> _keys;

	private static Hud _hud;

	private static int _capturing = -1;

	private static DateTime _captureFrom;

	private static DateTime _nextFileCheck = DateTime.MinValue;

	private static DateTime _fileTime = DateTime.MinValue;

	private static string File_ => Util.FullPath("MelkTank_Hotkeys.txt");

	public static List<Key> Keys
	{
		get
		{
			if (_keys == null)
			{
				Load();
			}
			return _keys;
		}
	}

	public static void Init()
	{
		try
		{
			// (an empty window drawn every frame - where the keys are looked at)
			_hud = UBService.Huds.CreateHud("MelkTank Keys", BarIcon.Make("Keys"));
			_hud.ShowInBar = false;
			_hud.WindowSettings = ImGuiWindowFlags.NoInputs | ImGuiWindowFlags.NoTitleBar | ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoCollapse | ImGuiWindowFlags.NoBackground | ImGuiWindowFlags.NoSavedSettings | ImGuiWindowFlags.NoFocusOnAppearing | ImGuiWindowFlags.NoMove | ImGuiWindowFlags.NoResize;
			_hud.OnPreRender += OnPreRender;
			_hud.OnRender += OnRender;
			_hud.Visible = true;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			_hud = null;
		}
	}

	public static void Dispose()
	{
		try
		{
			if (_hud != null)
			{
				_hud.OnPreRender -= OnPreRender;
				_hud.OnRender -= OnRender;
				_hud.Dispose();
			}
		}
		catch
		{
		}
		_hud = null;
	}

	private static void OnPreRender(object sender, EventArgs e)
	{
		try
		{
			ImGui.SetNextWindowPos(new Vector2(-50f, -50f));
			ImGui.SetNextWindowSize(new Vector2(1f, 1f));
		}
		catch
		{
		}
	}

	private static void OnRender(object sender, EventArgs e)
	{
		try
		{
			Check();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void Load()
	{
		_keys = new List<Key>();
		try
		{
			if (!File.Exists(File_))
			{
				return;
			}
			string[] array = Util.Locked(File_, () => File.ReadAllLines(File_));
			foreach (string text in array)
			{
				if (text.StartsWith("#"))
				{
					continue;
				}
				string[] array2 = text.Split('\t');
				if (array2.Length >= 2)
				{
					Key key = new Key
					{
						Name = array2[0]
					};
					int.TryParse(array2[1], out key.Mask);
					for (int j = 0; j < 3; j++)
					{
						key.Cmds[j] = ((array2.Length > 2 + j) ? array2[2 + j] : "");
					}
					_keys.Add(key);
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void Save()
	{
		try
		{
			List<string> list = new List<string> { "# MelkTank hotkeys: key, modifiers (1 Shift, 2 Ctrl, 4 Alt), up to three commands" };
			foreach (Key key in Keys)
			{
				list.Add(key.Name + "\t" + key.Mask + "\t" + string.Join("\t", Array.ConvertAll(key.Cmds, (string c) => (c ?? "").Replace('\t', ' '))));
			}
			Util.WriteShared(File_, string.Join("\n", list.ToArray()) + "\n");
			_fileTime = File.GetLastWriteTimeUtc(File_);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static int ModsNow()
	{
		ImGuiIOPtr iO = ImGui.GetIO();
		return (iO.KeyShift ? 1 : 0) | (iO.KeyCtrl ? 2 : 0) | (iO.KeyAlt ? 4 : 0);
	}

	private static bool Typing()
	{
		try
		{
			if (ImGui.GetIO().WantTextInput)
			{
				return true;
			}
		}
		catch
		{
		}
		try
		{
			return Globals.Core.Actions.ChatState;
		}
		catch
		{
			return false;
		}
	}

	private static bool IsMod(ImGuiKey k)
	{
		return k == ImGuiKey.LeftCtrl || k == ImGuiKey.RightCtrl || k == ImGuiKey.LeftShift || k == ImGuiKey.RightShift || k == ImGuiKey.LeftAlt || k == ImGuiKey.RightAlt || k == ImGuiKey.LeftSuper || k == ImGuiKey.RightSuper || k == ImGuiKey.ModCtrl || k == ImGuiKey.ModShift || k == ImGuiKey.ModAlt || k == ImGuiKey.ModSuper || k == ImGuiKey.ReservedForModCtrl || k == ImGuiKey.ReservedForModShift || k == ImGuiKey.ReservedForModAlt || k == ImGuiKey.ReservedForModSuper;
	}

	private static void Check()
	{
		if (_capturing >= 0)
		{
			Capture();
			return;
		}
		// (another client - another character - may have changed them)
		if (DateTime.Now >= _nextFileCheck)
		{
			_nextFileCheck = DateTime.Now.AddSeconds(5.0);
			try
			{
				DateTime dateTime = (File.Exists(File_) ? File.GetLastWriteTimeUtc(File_) : DateTime.MinValue);
				if (dateTime != _fileTime)
				{
					_fileTime = dateTime;
					Load();
				}
			}
			catch
			{
			}
		}
		if (Keys.Count == 0 || Typing())
		{
			return;
		}
		int num = ModsNow();
		foreach (Key key in Keys)
		{
			if (key.Name.Length == 0 || key.Mask != num || !Enum.TryParse<ImGuiKey>(key.Name, out var result) || !ImGui.IsKeyPressed(result, repeat: false))
			{
				continue;
			}
			foreach (string cmd in key.Cmds)
			{
				string text = (cmd ?? "").Trim();
				if (text.Length > 0)
				{
					Util.Command(text);
				}
			}
		}
	}

	// the next key pressed (with Ctrl / Shift / Alt) becomes the hotkey being set; Escape gives up
	private static void Capture()
	{
		if ((DateTime.Now - _captureFrom).TotalSeconds < 0.25)
		{
			return;
		}
		if ((DateTime.Now - _captureFrom).TotalSeconds > 15.0)
		{
			_capturing = -1;
			return;
		}
		for (ImGuiKey imGuiKey = ImGuiKey.Tab; imGuiKey < ImGuiKey.GamepadStart; imGuiKey++)
		{
			if (IsMod(imGuiKey) || !ImGui.IsKeyPressed(imGuiKey, repeat: false))
			{
				continue;
			}
			if (imGuiKey == ImGuiKey.Escape)
			{
				_capturing = -1;
				return;
			}
			if (_capturing < Keys.Count)
			{
				Keys[_capturing].Name = imGuiKey.ToString();
				Keys[_capturing].Mask = ModsNow();
				Save();
			}
			_capturing = -1;
			return;
		}
	}

	public static string Label(Key k)
	{
		if (k.Name.Length == 0)
		{
			return "(none)";
		}
		string text = k.Name;
		if (text.StartsWith("_") && text.Length == 2)
		{
			text = text.Substring(1);
		}
		return (((k.Mask & 2) != 0) ? "Ctrl+" : "") + (((k.Mask & 4) != 0) ? "Alt+" : "") + (((k.Mask & 1) != 0) ? "Shift+" : "") + text;
	}

	// the game's own name for a key (its keymap's): F1 -> DIK_F1, A -> DIK_A, _1 -> DIK_1, Keypad1 -> DIK_NUMPAD1
	private static string DikName(string imgui)
	{
		if (imgui.StartsWith("Keypad"))
		{
			string text = imgui.Substring(6);
			if (text.Length == 1 && char.IsDigit(text[0]))
			{
				return "DIK_NUMPAD" + text;
			}
			return text switch
			{
				"Add" => "DIK_ADD",
				"Subtract" => "DIK_SUBTRACT",
				"Multiply" => "DIK_MULTIPLY",
				"Divide" => "DIK_DIVIDE",
				"Decimal" => "DIK_DECIMAL",
				"Enter" => "DIK_NUMPADENTER",
				_ => "DIK_" + text.ToUpperInvariant(),
			};
		}
		if (imgui.StartsWith("_") && imgui.Length == 2)
		{
			return "DIK_" + imgui.Substring(1);
		}
		return imgui switch
		{
			"Enter" => "DIK_RETURN",
			"Escape" => "DIK_ESCAPE",
			"Backspace" => "DIK_BACK",
			"Space" => "DIK_SPACE",
			"Tab" => "DIK_TAB",
			"PageUp" => "DIK_PRIOR",
			"PageDown" => "DIK_NEXT",
			"UpArrow" => "DIK_UP",
			"DownArrow" => "DIK_DOWN",
			"LeftArrow" => "DIK_LEFT",
			"RightArrow" => "DIK_RIGHT",
			"Minus" => "DIK_MINUS",
			"Equal" => "DIK_EQUALS",
			"LeftBracket" => "DIK_LBRACKET",
			"RightBracket" => "DIK_RBRACKET",
			"Semicolon" => "DIK_SEMICOLON",
			"Apostrophe" => "DIK_APOSTROPHE",
			"GraveAccent" => "DIK_GRAVE",
			"Backslash" => "DIK_BACKSLASH",
			"Comma" => "DIK_COMMA",
			"Period" => "DIK_PERIOD",
			"Slash" => "DIK_SLASH",
			_ => "DIK_" + imgui.ToUpperInvariant(),
		};
	}

	/// <summary>What the game already does with a key (ACGodot tells us, from its keymap); null: not known here (retail).</summary>
	private static string[] GameUses(Key k)
	{
		try
		{
			if (AppDomain.CurrentDomain.GetData("ACGodot.KeyUsedBy") is Func<string, int, string[]> func)
			{
				return func(DikName(k.Name), k.Mask);
			}
		}
		catch
		{
		}
		return null;
	}

	public static void Draw()
	{
		Im.TextColored(Grey, "A key runs up to three commands, in order (MelkTank's /mt ..., or any chat command). Only the game window that has\nthe keys runs them - the other characters you're running aren't touched - and never while you're typing.");
		bool flag = false;
		int num = -1;
		for (int i = 0; i < Keys.Count; i++)
		{
			Key key = Keys[i];
			ImGui.PushID("hk" + i);
			string text = ((_capturing == i) ? "Press a key... (Esc: cancel)" : Label(key));
			if (ImGui.Button(text + "##k", new Vector2(190f, 0f)))
			{
				_capturing = i;
				_captureFrom = DateTime.Now;
			}
			Im.SetTooltipIfHovered("Click, then press the key (with Ctrl / Shift / Alt if you like).");
			ImGui.SameLine();
			if (ImGui.SmallButton("x"))
			{
				num = i;
			}
			Im.SetTooltipIfHovered("Removes this hotkey.");
			if (key.Name.Length > 0 && _capturing != i)
			{
				string[] array = GameUses(key);
				ImGui.SameLine();
				if (array == null)
				{
					Im.TextColored(Grey, "(check the game's keymap doesn't use it too)");
				}
				else if (array.Length != 0)
				{
					Im.TextColored(Red, "the game uses it too: " + string.Join(", ", array));
				}
				else
				{
					Im.TextColored(Grey, "free in the game");
				}
				foreach (Key key2 in Keys)
				{
					if (key2 != key && key2.Name == key.Name && key2.Mask == key.Mask)
					{
						ImGui.SameLine();
						Im.TextColored(Yellow, "(set twice)");
						break;
					}
				}
			}
			for (int j = 0; j < 3; j++)
			{
				ImGui.SetNextItemWidth(ImGui.GetContentRegionAvail().X / 3f - 6f);
				if (ImGui.InputTextWithHint("##c" + j, (j == 0) ? "/mt meta state Default" : "and then...", ref key.Cmds[j], 300u))
				{
					flag = true;
				}
				if (j < 2)
				{
					ImGui.SameLine();
				}
			}
			ImGui.Separator();
			ImGui.PopID();
		}
		if (num >= 0)
		{
			Keys.RemoveAt(num);
			_capturing = -1;
			flag = true;
		}
		if (ImGui.Button("Add a hotkey##hkadd"))
		{
			Keys.Add(new Key());
			_capturing = Keys.Count - 1;
			_captureFrom = DateTime.Now;
			flag = true;
		}
		Im.SetTooltipIfHovered("Adds one and waits for its key.");
		if (flag)
		{
			Save();
		}
	}
}
