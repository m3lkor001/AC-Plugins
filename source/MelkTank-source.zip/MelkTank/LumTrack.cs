using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Text;
using System.Text.RegularExpressions;
using ImGuiNET;

namespace MelkTank;

/// <summary>
/// Session > Lum: what MelksLuminanceTracker did - lum/hr, coins/hr, each turned into the other at your conversion
/// rates, and the effective rates (both added together). Dungeon drops that turn in for coins ("X gives you Ancient
/// Pyreal.") are counted as they come and valued at their turn-in rates. The rates and the item list are shared by
/// every character (Settings\MelkTank_Lum.txt). Session > Augs uses the conversion rate and the effective rates.
/// </summary>
public static class LumTrack
{
	public class Item
	{
		public string Names = "";   // what drops ("Ancient Pyreal"); several with + for a set turned in together, | for other spellings
		public int Per = 100;       // how many (sets) a turn-in takes
		public double Coins;        // Enlightened Coins it gives
		public double LumM;         // luminance it gives, in millions
		public string Other = "";   // anything else it gives (MMD, keys ...) - shown, not counted in the rates
		public bool On = true;
	}

	// lum you get selling 1 coin, and lum it costs to buy 1 coin (millions) - as the tracker kept them
	public static double SellM = 72.0, BuyM = 73.0;
	public static bool CoinsByBank;
	/// <summary>Lum/hr by the bank (as the lum tracker does it): what the bank gained since it was read at login or the last
	/// reset, averaged over that time - fellowship shares and vassal passup with it, deposited tokens taken off.</summary>
	public static bool LumByBank = true;
	public static int WindowMin = 180;   // how far back lum/hr looks (minutes)
	public static string WindowText => WindowMin % 60 == 0 ? (WindowMin / 60) + " hr" : WindowMin + " min";
	public static int PollMinutes = 1;
	/// <summary>Ask /bank on a timer (kept out of chat) - what the Bank tab, lum/hr and coins/hr by the bank read.</summary>
	public static bool BankPoll = true;
	public static List<Item> Items = Defaults();

	private static readonly Dictionary<string, int> _counts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
	private static DateTime _start = DateTime.Now;
	private static long _bankCoinsStart = -1, _bankCoinsNow = -1;
	private static DateTime _pollAt = DateTime.MinValue;
	private static bool _loaded;
	private static DateTime _fileTime = DateTime.MinValue;
	private static readonly Regex GivesRx = new Regex("^(?:.+?) gives you (?:(?<n>[\\d,]+) )?(?<item>.+?)\\.?$", RegexOptions.IgnoreCase);

	public static double LumPerCoinBuy => BuyM * 1000000.0;
	public static double LumPerCoinSell => SellM * 1000000.0;

	private static List<Item> Defaults()
	{
		// the turn-ins MelksLuminanceTracker knew
		return new List<Item>
		{
			new Item { Names = "Red Aetheria Chunk + Ancient Empyrean Trinket", Per = 1, Coins = 1 },
			new Item { Names = "Blue Aetheria Chunk + Ancient Falatacot Trinket", Per = 1, Coins = 3, Other = "(weakly coins, the tracker counted them as coins)" },
			new Item { Names = "Ancient Pyreal", Per = 100, Coins = 37 },
			new Item { Names = "Dire Siraluun Egg", Per = 100, Coins = 10, Other = "100 Trade Note (250,000)" },
			new Item { Names = "Straberry Jam Jar|Strawberry Jam Jar", Per = 100, Coins = 10 },
			new Item { Names = "Anachronistic Speck", Per = 100, Coins = 100 },
			new Item { Names = "Badass Skull", Per = 100, Coins = 200, Other = "80 MMD (the 200 are weakly coins)" },
			new Item { Names = "Olthoi Slimy Shell", Per = 100, Coins = 0, Other = "350 MMD, 5 Mythical Keys" },
			new Item { Names = "Enlightened Coin", Per = 1, Coins = 1 },
		};
	}

	private static string FilePath => Util.FullPath("MelkTank_Lum.txt");

	// ── settings file: shared by every character ──
	public static void Load()
	{
		try
		{
			string p = FilePath;
			if (!File.Exists(p))
			{
				_loaded = true;
				return;
			}
			DateTime t = File.GetLastWriteTimeUtc(p);
			if (_loaded && t == _fileTime) return;
			_fileTime = t;
			_loaded = true;
			List<Item> items = new List<Item>();
			bool sawPollOn = false;
			foreach (string raw in File.ReadAllLines(p))
			{
				string line = raw.Trim();
				if (line.Length == 0 || line.StartsWith("#")) continue;
				int eq = line.IndexOf('=');
				if (line.StartsWith("item|"))
				{
					string[] f = line.Split('|');
					if (f.Length < 6) continue;
					Item it = new Item { Names = Uri.UnescapeDataString(f[1]), Other = Uri.UnescapeDataString(f[5]) };
					int.TryParse(f[2], out it.Per);
					double.TryParse(f[3], NumberStyles.Float, CultureInfo.InvariantCulture, out it.Coins);
					double.TryParse(f[4], NumberStyles.Float, CultureInfo.InvariantCulture, out it.LumM);
					it.On = f.Length < 7 || f[6] != "0";
					if (it.Per < 1) it.Per = 1;
					if (it.Names.Trim().Length > 0) items.Add(it);
				}
				else if (eq > 0)
				{
					string k = line.Substring(0, eq).Trim().ToLowerInvariant(), v = line.Substring(eq + 1).Trim();
					double d;
					if (k == "sell" && double.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out d) && d > 0) SellM = d;
					else if (k == "buy" && double.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out d) && d > 0) BuyM = d;
					else if (k == "window" && int.TryParse(v, out int wm) && wm >= 30) WindowMin = wm;
					else if (k == "bountyprogress") Session.LumFromBountyProgress = v == "1" || v.Equals("true", StringComparison.OrdinalIgnoreCase);
					else if (k == "coinsbybank") CoinsByBank = v == "1" || v.Equals("true", StringComparison.OrdinalIgnoreCase);
					else if (k == "lumbybank") LumByBank = v == "1" || v.Equals("true", StringComparison.OrdinalIgnoreCase);
					else if (k == "poll" && int.TryParse(v, out var n) && n > 0) PollMinutes = n;
					else if (k == "pollon") { BankPoll = v == "1" || v.Equals("true", StringComparison.OrdinalIgnoreCase); sawPollOn = true; }
				}
			}
			Items = items;
			// (a file from before the bank poller moved here: its 2-minute timer becomes the new 1-minute default)
			if (!sawPollOn) PollMinutes = 1;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void Save()
	{
		try
		{
			StringBuilder sb = new StringBuilder();
			sb.AppendLine("# MelkTank - Session > Lum (shared by every character). Rates in millions of luminance.");
			sb.AppendLine("sell=" + SellM.ToString(CultureInfo.InvariantCulture));
			sb.AppendLine("buy=" + BuyM.ToString(CultureInfo.InvariantCulture));
			sb.AppendLine("coinsbybank=" + (CoinsByBank ? "1" : "0"));
			sb.AppendLine("lumbybank=" + (LumByBank ? "1" : "0"));
		sb.AppendLine("window=" + WindowMin);
		sb.AppendLine("bountyprogress=" + (Session.LumFromBountyProgress ? "1" : "0"));
			sb.AppendLine("poll=" + PollMinutes);
			sb.AppendLine("pollon=" + (BankPoll ? "1" : "0"));
			foreach (Item it in Items)
				sb.AppendLine("item|" + Uri.EscapeDataString(it.Names) + "|" + it.Per + "|" + it.Coins.ToString(CultureInfo.InvariantCulture) + "|" + it.LumM.ToString(CultureInfo.InvariantCulture) + "|" + Uri.EscapeDataString(it.Other ?? "") + "|" + (it.On ? "1" : "0"));
			Util.WriteShared(FilePath, sb.ToString());
			_fileTime = File.GetLastWriteTimeUtc(FilePath);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	// ── counting ──
	public static void Reset()
	{
		_counts.Clear();
		_calcAt = DateTime.MinValue;
		_start = DateTime.Now;
		_bankCoinsStart = _bankCoinsNow;
		// (the bank read again: lum/hr by the bank starts from it)
		_bankLumStart = -1;
		_bankLumAskedAt = DateTime.MinValue;
	}

	// ── lum by the bank ──
	public static void NewLogin()
	{
		_bankLumStart = -1;
		_bankLumAskedAt = DateTime.MinValue;
	}

	private static long _bankLumStart = -1, _bankLumNow = -1, _linesAtStart, _earnedAtStart;
	private static DateTime _bankLumStartAt, _bankLumAskedAt = DateTime.MinValue;
	private static double _depositedLum;

	/// <summary>The bank's luminance (from a /bank reading): the first since login or a reset is where the average starts.</summary>
	public static void BankLum(long lum)
	{
		if (lum < 0) return;
		if (_bankLumStart < 0)
		{
			_bankLumStart = lum;
			_bankLumStartAt = DateTime.Now;
			_linesAtStart = Session.LumBankedLines;
			_earnedAtStart = Session.LumEarned;
			_depositedLum = 0;
		}
		_bankLumNow = lum;
		_calcAt = DateTime.MinValue;
		// (any /bank answer - the Bank tab's button, the charm buyer, enlightening, the phone - counts as this poller's:
		// its timer starts again from it rather than asking again straight after)
		_pollAt = DateTime.Now;
	}

	/// <summary>Luminance tokens deposited (their luminance lands in the bank - counted as tokens when they came).</summary>
	public static void TokensDeposited(double lum)
	{
		if (_bankLumStart >= 0 && lum > 0) _depositedLum += lum;
	}

	public static bool HaveBankLum => LumByBank && _bankLumStart >= 0 && _bankLumNow >= 0 && (DateTime.Now - _bankLumStartAt).TotalMinutes >= 2.0;
	public static double BankLumHours => Math.Max(1.0 / 60.0, (DateTime.Now - _bankLumStartAt).TotalHours);
	/// <summary>Luminance earned yourself since the bank was first read (kills' banked lines, tokens).</summary>
	public static double OwnLumSinceBank => Math.Max(0, Session.LumEarned - _earnedAtStart);
	/// <summary>What the bank gained beyond your own banked lines: fellowship shares and vassal passup.</summary>
	public static double SharedLumSinceBank => Math.Max(0, (_bankLumNow - _bankLumStart - _depositedLum) - (Session.LumBankedLines - _linesAtStart));

	/// <summary>A chat line: "Ancient Warrior gives you Ancient Pyreal." - counted if it's one of the list's items.</summary>
	public static void OnChat(string text)
	{
		if (string.IsNullOrEmpty(text) || text.IndexOf(" gives you ", StringComparison.OrdinalIgnoreCase) < 0) return;
		Match m = GivesRx.Match(text.Trim());
		if (!m.Success) return;
		string item = m.Groups["item"].Value.Trim();
		int n = 1;
		if (m.Groups["n"].Success) int.TryParse(m.Groups["n"].Value.Replace(",", ""), out n);
		foreach (Item it in Items)
		{
			if (!it.On) continue;
			foreach (string part in it.Names.Split('+'))
				foreach (string name in part.Split('|'))
				{
					string nm = name.Trim();
					// (a plural: "Ancient Pyreals")
					if (nm.Length > 0 && (item.Equals(nm, StringComparison.OrdinalIgnoreCase) || item.Equals(nm + "s", StringComparison.OrdinalIgnoreCase)))
					{
						_counts.TryGetValue(nm, out var c);
						_counts[nm] = c + Math.Max(1, n);
						return;
					}
				}
		}
	}

	/// <summary>The bank's Enlightened Coins (from Session's /bank reading), for counting coins by the bank.</summary>
	public static void BankCoins(long coins)
	{
		if (coins < 0) return;
		_bankCoinsNow = coins;
		if (_bankCoinsStart < 0) _bankCoinsStart = coins;
	}

	public static void Tick()
	{
		LumPopout.Tick();
		if (!_loaded || (DateTime.Now - _pollAt).TotalSeconds > 30) { Load(); }
		// (the bank read at login and after a reset - lum by the bank starts from it - asked again each minute till it answers)
		if ((LumByBank || BankPoll) && _bankLumStart < 0 && (DateTime.Now - _bankLumAskedAt).TotalSeconds >= 60 && (DateTime.UtcNow - Remote.LoginAtUtc).TotalSeconds >= 10)
		{
			_bankLumAskedAt = DateTime.Now;
			_pollAt = DateTime.Now;
			Session.QuietBank();
		}
		else if (BankPoll && (DateTime.Now - _pollAt).TotalMinutes >= Math.Max(1, PollMinutes))
		{
			_pollAt = DateTime.Now;
			Session.QuietBank();
		}
		else if (!BankPoll && (DateTime.Now - _pollAt).TotalSeconds > 30)
		{
			_pollAt = DateTime.Now;
		}
	}

	private static int Count(string names)
	{
		int sum = 0;
		foreach (string name in names.Split('|'))
			if (_counts.TryGetValue(name.Trim(), out var c)) sum += c;
		return sum;
	}

	// how many of this turn-in you have: a set of several items counts as many as the fewest of them
	public static int Sets(Item it)
	{
		int least = int.MaxValue;
		foreach (string part in it.Names.Split('+'))
			least = Math.Min(least, Count(part));
		return (least == int.MaxValue) ? 0 : least;
	}

	public static double Hours => Math.Max(1.0 / 60.0, (DateTime.Now - _start).TotalHours);

	public static double ItemCoins()
	{
		double c = 0;
		foreach (Item it in Items) if (it.On) c += it.Coins * Sets(it) / Math.Max(1, it.Per);
		return c;
	}

	public static double ItemLum()
	{
		double l = 0;
		foreach (Item it in Items) if (it.On) l += it.LumM * 1000000.0 * Sets(it) / Math.Max(1, it.Per);
		return l;
	}

	public static double BankCoinGain => (_bankCoinsStart >= 0 && _bankCoinsNow >= 0) ? Math.Max(0, _bankCoinsNow - _bankCoinsStart) : 0;

	// (worked out at most every 5 seconds - the tab, Session > Augs and the rest read these)
	private static DateTime _calcAt = DateTime.MinValue;
	private static double _lumPh, _coinsPh, _itemLum, _pace, _ownPh = -1, _sharedPh = -1;
	private static string _paceLines = "";

	private static void Calc()
	{
		if ((DateTime.Now - _calcAt).TotalSeconds < 5.0) return;
		_calcAt = DateTime.Now;
		double hours = Hours;
		_itemLum = ItemLum();
		_coinsPh = ((CoinsByBank ? BankCoinGain : 0) + ItemCoins()) / hours;
		double r = (Session.LumPerHourRecent > 0.0) ? Session.LumPerHourRecent : Session.LumPerHour;
		if (HaveBankLum)
		{
			// (yours and the shares/passup, over the time since the bank was first read)
			double bh = BankLumHours;
			_ownPh = OwnLumSinceBank / bh;
			_sharedPh = SharedLumSinceBank / bh;
			r = _ownPh + _sharedPh;
		}
		else { _ownPh = -1; _sharedPh = -1; }
		_lumPh = Math.Max(0.0, r) + _itemLum / hours;
		try { _pace = Session.TokenBountyPace(out _paceLines); } catch { _pace = 0; _paceLines = ""; }
	}

	/// <summary>The Lum tab's figures as JSON (the app's Lum card): banked, the rates, and the turn-ins counted.</summary>
	public static string Json()
	{
		var ci = CultureInfo.InvariantCulture;
		string N(double v) => double.IsNaN(v) || double.IsInfinity(v) ? "0" : v.ToString("0.###", ci);
		string Q(string v) => "\"" + (v ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"") + "\"";
		var sb = new StringBuilder("{");
		double lph = LumPerHour;
		sb.Append("\"bankedLum\": ").Append(Session.BankedLum.ToString(ci));
		sb.Append(", \"bankedCoins\": ").Append(Session.BankedCoins.ToString(ci));
		sb.Append(", \"lumPh\": ").Append(N(lph));
		sb.Append(", \"byBank\": ").Append(_ownPh >= 0 ? "true" : "false");
		if (_ownPh >= 0)
		{
			sb.Append(", \"ownPh\": ").Append(N(_ownPh)).Append(", \"sharedPh\": ").Append(N(_sharedPh));
			sb.Append(", \"since\": ").Append(Q(_bankLumStartAt.ToUniversalTime().ToString("o")));
		}
		sb.Append(", \"coinsPh\": ").Append(N(CoinsPerHour));
		sb.Append(", \"lumCoinsPh\": ").Append(N(LumCoinsPerHour));
		sb.Append(", \"coinsLumPh\": ").Append(N(CoinsLumPerHour));
		sb.Append(", \"effCoinsPh\": ").Append(N(EffectiveCoinsPerHour));
		sb.Append(", \"effLumPh\": ").Append(N(EffectiveLumPerHour));
		sb.Append(", \"sellM\": ").Append(N(SellM)).Append(", \"buyM\": ").Append(N(BuyM));
		sb.Append(", \"counting\": ").Append(((long)(DateTime.Now - _start).TotalSeconds).ToString(ci));
		sb.Append(", \"turnIns\": [");
		bool first = true;
		foreach (Item it in Items)
		{
			if (!it.On) continue;
			int sets = Sets(it);
			if (sets <= 0) continue;
			if (!first) sb.Append(", ");
			first = false;
			sb.Append("{\"name\": ").Append(Q(it.Names.Replace("|", " / ").Replace("+", " + "))).Append(", \"have\": ").Append(sets).Append(", \"per\": ").Append(it.Per)
				.Append(", \"coins\": ").Append(N(it.Coins * sets / Math.Max(1, it.Per))).Append(", \"lum\": ").Append(N(it.LumM * 1000000.0 * sets / Math.Max(1, it.Per))).Append("}");
		}
		sb.Append("]}");
		return sb.ToString();
	}

	/// <summary>The figures are worked out again on the next read (after a reset, a rate changed).</summary>
	public static void Recalc() => _calcAt = DateTime.MinValue;

	public static double CoinsPerHour { get { Calc(); return _coinsPh; } }

	public static double LumPerHour { get { Calc(); return _lumPh; } }

	public static double LumCoinsPerHour => LumPerHour / LumPerCoinBuy;          // lum/hr turned into coins
	public static double CoinsLumPerHour => CoinsPerHour * LumPerCoinSell;       // coins/hr turned into lum
	public static double EffectiveCoinsPerHour => CoinsPerHour + LumCoinsPerHour;
	public static double EffectiveLumPerHour => LumPerHour + CoinsLumPerHour;

	// ── the tab ──
	private static readonly Vector4 Cyan = new Vector4(0.35f, 0.85f, 0.95f, 1f), Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f), Gold = new Vector4(0.95f, 0.8f, 0.3f, 1f);
	private static string _newNames = "", _newOther = "";
	private static int _newPer = 100;
	private static float _newCoins, _newLum;

	public static void Draw()
	{
		if (!ImGui.BeginTabBar("lumtabs")) return;
		if (ImGui.BeginTabItem("Rates##lumrates"))
		{
			DrawRates();
			ImGui.EndTabItem();
		}
		if (ImGui.BeginTabItem("Settings##lumsettings"))
		{
			DrawSettings();
			ImGui.EndTabItem();
		}
		ImGui.EndTabBar();
	}

	private static string C(double v) => (v >= 100 ? v.ToString("N0", CultureInfo.InvariantCulture) : v.ToString("N1", CultureInfo.InvariantCulture));

	private static void Row(string what, string value, string tip)
	{
		ImGui.TableNextRow();
		ImGui.TableSetColumnIndex(0);
		Im.Text(what);
		ImGui.TableSetColumnIndex(1);
		Im.TextColored(Cyan, value);
		if (tip != null && ImGui.IsItemHovered()) Im.SetTooltip(tip);
	}

	private static void DrawRates()
	{
		if (ImGui.SmallButton("/b##lumb")) Util.Command("/b");
		ImGui.SameLine();
		if (ImGui.SmallButton("/b d##lumbd")) Util.Command("/b d");
		ImGui.SameLine();
		if (ImGui.SmallButton("/clap all##lumclap")) Util.Command("/clap all");
		ImGui.SameLine();
		if (ImGui.SmallButton("Report##lumreport"))
			Util.WriteToChat("Lum: " + Session.Big(LumPerHour) + "/hr, coins " + C(CoinsPerHour) + "/hr - effective " + Session.Big(EffectiveLumPerHour) + " lum/hr, " + C(EffectiveCoinsPerHour) + " coins/hr (" + C(SellM) + "M / " + C(BuyM) + "M a coin).");
		ImGui.SameLine();
		if (ImGui.SmallButton((LumPopout.Open ? "Close pop-out" : "Pop out") + "##lumpop")) LumPopout.Show(!LumPopout.Open);
		if (ImGui.IsItemHovered()) Im.SetTooltip("A window of its own that stays open: what's banked, these rates, /b d and /clap all - and a Tx tab to send all your coins or luminance to a character.");
		ImGui.SameLine();
		if (ImGui.SmallButton("Reset counts##lumreset")) Reset();
		if (ImGui.IsItemHovered()) Im.SetTooltip("Starts the item counts (and the coins from the bank) again from now. Lum/hr is the Session's.");
		ImGui.SameLine();
		TimeSpan run = DateTime.Now - _start;
		Im.TextColored(Grey, "   counting " + ((int)run.TotalHours).ToString() + ":" + run.Minutes.ToString("00"));
		DrawRateTable("lumrates");
		ImGui.Spacing();
		DrawTurnIns();
	}

	/// <summary>The rates (the Lum tab's and its pop-out's).</summary>
	public static void DrawRateTable(string id)
	{
		if (ImGui.BeginTable(id, 2, ImGuiTableFlags.RowBg | ImGuiTableFlags.BordersInnerV | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("##w", ImGuiTableColumnFlags.WidthFixed, 170f);
			ImGui.TableSetupColumn("##v", ImGuiTableColumnFlags.WidthStretch);
			double lph = LumPerHour;
			if (_ownPh >= 0)
			{
				TimeSpan since = DateTime.Now - _bankLumStartAt;
				Row("Lum/hr", Session.Big(lph), "By the bank: what it gained since it was read at " + _bankLumStartAt.ToString("HH:mm") + " (" + (int)since.TotalHours + ":" + since.Minutes.ToString("00") + " ago - login or the last reset), averaged over that time." +
					"\nFellowship shares and vassal passup are in it; luminance tokens deposited are taken off (they're counted when you get them)." + ((_itemLum > 0) ? "\nPlus luminance from turn-ins." : "") + (BankPoll ? "\nThe bank is read every " + PollMinutes + " min without showing in chat." : "\nThe bank poller is off (Settings) - this only moves when the bank is read."));
				Row("   earned", Session.Big(_ownPh) + "/hr", "Your own: the \"You've banked ... Luminance\" lines and luminance tokens (" + Session.Big(OwnLumSinceBank) + " since " + _bankLumStartAt.ToString("HH:mm") + ").");
				Row("   fellow / passup", Session.Big(_sharedPh) + "/hr", "The rest of what the bank gained: fellowship shares and vassal passup (" + Session.Big(SharedLumSinceBank) + " since " + _bankLumStartAt.ToString("HH:mm") + ").");
			}
			else
				Row("Lum/hr", Session.Big(lph), "The Session's lum/hr over the last " + WindowText + " (the whole session until it's that old)" + ((_itemLum > 0) ? ", plus luminance from turn-ins." : ".") +
					(LumByBank ? "\nBy the bank once it's been read and a couple of minutes have passed - then fellowship shares and passup count too." : "") + "\nThese figures are worked out every 5 seconds.");
			double pace = _pace;
			string paceLines = _paceLines;
			if (pace > 0)
				Row("   token bounty here", Session.Big(pace) + "/hr", "What the luminance-token bounties where you are pay right now, at your kills/hr over the last 60 min:" + paceLines + "\nAlready inside lum/hr kill by kill (Settings) - this is the pace on its own, for comparing.");
			Row("Coins/hr", C(CoinsPerHour), "Enlightened Coins: the turn-ins counted below at their rates" + (CoinsByBank ? ", plus what the bank gained (polled every " + PollMinutes + " min)." : "."));
			Row("Lum-Coins/hr", C(LumCoinsPerHour), "Lum/hr turned into coins at " + C(BuyM) + "M lum a coin.");
			Row("Coins-Lum/hr", Session.Big(CoinsLumPerHour), "Coins/hr turned into luminance at " + C(SellM) + "M lum a coin.");
			Row("Effective coins/hr", C(EffectiveCoinsPerHour), "Coins/hr + Lum-Coins/hr.");
			Row("Effective lum/hr", Session.Big(EffectiveLumPerHour), "Lum/hr + Coins-Lum/hr - what Session > Augs uses for its When (all) times.");
			ImGui.EndTable();
		}
	}

	private static void DrawTurnIns()
	{
		Im.TextColored(Gold, "Turn-ins");
		if (ImGui.BeginTable("lumitems", 5, ImGuiTableFlags.RowBg | ImGuiTableFlags.Borders | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("Item", ImGuiTableColumnFlags.WidthStretch);
			ImGui.TableSetupColumn("Got", ImGuiTableColumnFlags.WidthFixed, 70f);
			ImGui.TableSetupColumn("Coins", ImGuiTableColumnFlags.WidthFixed, 70f);
			ImGui.TableSetupColumn("Lum", ImGuiTableColumnFlags.WidthFixed, 80f);
			ImGui.TableSetupColumn("Other", ImGuiTableColumnFlags.WidthFixed, 200f);
			ImGui.TableHeadersRow();
			bool any = false;
			foreach (Item it in Items)
			{
				if (!it.On) continue;
				int sets = Sets(it);
				bool partial = false;
				foreach (string part in it.Names.Split('+')) if (Count(part) > 0) partial = true;
				if (!partial) continue;
				any = true;
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				Im.Text(it.Names.Replace("|", " / "));
				ImGui.TableSetColumnIndex(1);
				string got = it.Names.Contains("+") ? string.Join(" + ", Array.ConvertAll(it.Names.Split('+'), (string p) => Count(p).ToString())) : sets.ToString("N0");
				Im.Text(got);
				ImGui.TableSetColumnIndex(2);
				Im.Text(C(it.Coins * sets / Math.Max(1, it.Per)));
				ImGui.TableSetColumnIndex(3);
				Im.Text((it.LumM > 0) ? Session.Big(it.LumM * 1000000.0 * sets / Math.Max(1, it.Per)) : "-");
				ImGui.TableSetColumnIndex(4);
				Im.TextColored(Grey, it.Other ?? "");
			}
			ImGui.EndTable();
			if (!any) Im.TextDisabled("Nothing from the list has dropped since counting started.");
		}
	}

	private static void DrawSettings()
	{
		bool changed = false;
		Im.TextColored(Gold, "Conversion rates (millions of luminance a coin) - shared by every character");
		float sell = (float)SellM, buy = (float)BuyM;
		ImGui.SetNextItemWidth(110f);
		if (ImGui.InputFloat("Coin -> Lum (selling a coin)##lumsell", ref sell, 0.5f, 1f, "%.1f") && sell > 0) { SellM = sell; changed = true; }
		ImGui.SetNextItemWidth(110f);
		if (ImGui.InputFloat("Lum -> Coin (buying a coin)##lumbuy", ref buy, 0.5f, 1f, "%.1f") && buy > 0) { BuyM = buy; changed = true; }
		Im.TextColored(Grey, "Buying: Session > Augs' \"1 coin = ... lum\" and its coin costs. Selling: coins/hr counted as luminance.");
		ImGui.Spacing();
		ImGui.SetNextItemWidth(110f);
		int win = WindowMin / 30;
		if (ImGui.SliderInt("Lum/hr looks back##lumwin", ref win, 1, 16, (win * 30 % 60 == 0 ? (win / 2) + " hr" : (win * 30) + " min"))) { WindowMin = win * 30; changed = true; }
		if (ImGui.IsItemHovered()) Im.SetTooltip("How far back lum/hr is measured. Make it at least one whole cycle of how you hunt\n(a T12 run + the hour in Wailing Cells waiting out its cooldown), or it swings with whichever part you're in.\nUntil the session is that old it's the whole session.");
		bool bp = Session.LumFromBountyProgress;
		if (ImGui.Checkbox("Count luminance-token bounties kill by kill##lumbp", ref bp)) { Session.LumFromBountyProgress = bp; changed = true; }
		if (ImGui.IsItemHovered()) Im.SetTooltip("Each kill toward a bounty that pays Thaelaryn Tokens of Luminance adds its share of the reward to lum/hr\n(Wailing Cells 1 token / 1,200 kills = 50 B / 1,200 a kill; a 2-token / 300-kill bounty = 100 B / 300).\nOnly the bounties for the area you're in (and all-zones ones), and none while a bounty is on its cooldown.\nThe token itself then isn't counted again when it arrives. Off: counted only when a token arrives.");
		if (Session.LumFromBountyProgress && !Session._progressCredited)
		{
			ImGui.SameLine();
			if (ImGui.SmallButton("Add kills so far##lumbpcredit")) Session.CreditBountyProgress();
			if (ImGui.IsItemHovered()) Im.SetTooltip("Adds the share for the kills the bounty here already has (made before kill-by-kill counting), once.\nOnly if those kills were this session - otherwise lum/hr reads high.");
		}
		if (ImGui.Checkbox("Poll the bank##lumpollon", ref BankPoll)) { changed = true; _pollAt = DateTime.MinValue; }
		if (ImGui.IsItemHovered()) Im.SetTooltip("Asks /bank on this timer by itself, kept out of chat - for the Bank tab, lum/hr by the bank and coins by the bank.\nOff: the bank is only read at login, after a reset, or when you ask (/b).\nKept for every character.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		if (ImGui.InputInt("min between /bank##lumpoll", ref PollMinutes, 1, 1)) { if (PollMinutes < 1) PollMinutes = 1; if (PollMinutes > 240) PollMinutes = 240; changed = true; }
		if (ImGui.IsItemHovered()) Im.SetTooltip("How often the bank is read (1 min by default).");
		if (ImGui.Checkbox("Lum/hr by the bank##lumbybank", ref LumByBank)) { changed = true; Recalc(); }
		if (ImGui.IsItemHovered()) Im.SetTooltip("Lum/hr from what the bank gains (read at login and on a reset, then every " + PollMinutes + " min, kept out of chat), averaged since -\nso fellowship shares and vassal passup count, as in the lum tracker. Deposited luminance tokens are taken off.\nOff: only your own banked lines and tokens.");
		if (ImGui.Checkbox("Coins by the bank too##lumbank", ref CoinsByBank)) changed = true;
		if (ImGui.IsItemHovered()) Im.SetTooltip("Adds what the bank's Enlightened Coins gained to coins/hr (from the bank poller above).\nOff: only the turn-ins below are counted.");
		ImGui.Spacing();
		Im.TextColored(Gold, "Dungeon items and their turn-ins");
		Im.TextColored(Grey, "Counted from \"... gives you <item>.\" while you hunt. A set of items turned in together: Red Aetheria Chunk + Ancient Empyrean Trinket.\nOther spellings of one item: Straberry Jam Jar|Strawberry Jam Jar. Coins and Lum go into the rates; Other is only shown.");
		int remove = -1;
		if (ImGui.BeginTable("lumitemset", 7, ImGuiTableFlags.RowBg | ImGuiTableFlags.Borders | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("On", ImGuiTableColumnFlags.WidthFixed, 26f);
			ImGui.TableSetupColumn("Item(s)", ImGuiTableColumnFlags.WidthStretch);
			ImGui.TableSetupColumn("Per", ImGuiTableColumnFlags.WidthFixed, 60f);
			ImGui.TableSetupColumn("Coins", ImGuiTableColumnFlags.WidthFixed, 70f);
			ImGui.TableSetupColumn("Lum (M)", ImGuiTableColumnFlags.WidthFixed, 80f);
			ImGui.TableSetupColumn("Other", ImGuiTableColumnFlags.WidthFixed, 180f);
			ImGui.TableSetupColumn("##x", ImGuiTableColumnFlags.WidthFixed, 24f);
			ImGui.TableHeadersRow();
			for (int i = 0; i < Items.Count; i++)
			{
				Item it = Items[i];
				ImGui.PushID("lumit" + i);
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				if (ImGui.Checkbox("##on", ref it.On)) changed = true;
				ImGui.TableSetColumnIndex(1);
				ImGui.SetNextItemWidth(-1f);
				ImGui.InputText("##n", ref it.Names, 300u);
				if (ImGui.IsItemDeactivatedAfterEdit()) changed = true;
				ImGui.TableSetColumnIndex(2);
				ImGui.SetNextItemWidth(-1f);
				if (ImGui.InputInt("##p", ref it.Per, 0, 0)) { if (it.Per < 1) it.Per = 1; changed = true; }
				ImGui.TableSetColumnIndex(3);
				float c = (float)it.Coins;
				ImGui.SetNextItemWidth(-1f);
				if (ImGui.InputFloat("##c", ref c, 0f, 0f, "%.1f")) { it.Coins = Math.Max(0f, c); changed = true; }
				ImGui.TableSetColumnIndex(4);
				float l = (float)it.LumM;
				ImGui.SetNextItemWidth(-1f);
				if (ImGui.InputFloat("##l", ref l, 0f, 0f, "%.1f")) { it.LumM = Math.Max(0f, l); changed = true; }
				ImGui.TableSetColumnIndex(5);
				ImGui.SetNextItemWidth(-1f);
				ImGui.InputText("##o", ref it.Other, 200u);
				if (ImGui.IsItemDeactivatedAfterEdit()) changed = true;
				ImGui.TableSetColumnIndex(6);
				if (ImGui.SmallButton("x")) remove = i;
				ImGui.PopID();
			}
			ImGui.EndTable();
		}
		if (remove >= 0) { Items.RemoveAt(remove); changed = true; }
		// a new one
		ImGui.SetNextItemWidth(260f);
		ImGui.InputTextWithHint("##lumnewn", "item name (dropped)", ref _newNames, 300u);
		ImGui.SameLine();
		ImGui.SetNextItemWidth(70f);
		ImGui.InputInt("per##lumnewp", ref _newPer, 0, 0);
		ImGui.SameLine();
		ImGui.SetNextItemWidth(70f);
		ImGui.InputFloat("coins##lumnewc", ref _newCoins, 0f, 0f, "%.1f");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(70f);
		ImGui.InputFloat("lum M##lumnewl", ref _newLum, 0f, 0f, "%.1f");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(160f);
		ImGui.InputTextWithHint("##lumnewo", "other (MMD, keys ...)", ref _newOther, 200u);
		ImGui.SameLine();
		bool can = _newNames.Trim().Length > 0;
		if (!can) ImGui.BeginDisabled();
		if (ImGui.Button("Add##lumnewadd"))
		{
			Items.Add(new Item { Names = _newNames.Trim(), Per = Math.Max(1, _newPer), Coins = Math.Max(0f, _newCoins), LumM = Math.Max(0f, _newLum), Other = _newOther.Trim() });
			_newNames = ""; _newOther = ""; _newPer = 100; _newCoins = 0; _newLum = 0;
			changed = true;
		}
		if (!can) ImGui.EndDisabled();
		ImGui.SameLine();
		if (ImGui.SmallButton("Defaults##lumdefaults")) { Items = Defaults(); changed = true; }
		if (ImGui.IsItemHovered()) Im.SetTooltip("Puts back the turn-ins MelksLuminanceTracker knew (your own rows go).");
		if (changed) Save();
	}
}
