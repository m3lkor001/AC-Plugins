using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Decal.Adapter.Wrappers;

namespace MelkTank;

public static class MonsterDb
{
	public class Entry
	{
		public string Name = "";

		public int Species;

		public int MaxHp;

		public int Level;

		public List<DmgType> Ranking = new List<DmgType>();

		public string Notes = "";

		public bool SpeciesEdited;

		public bool HpEdited;

		public DateTime LastSeen = DateTime.MinValue;

		public int Seen;

		public long Updated;
	}

	private static readonly Dictionary<string, Entry> _byName = new Dictionary<string, Entry>(StringComparer.OrdinalIgnoreCase);

	private static readonly Dictionary<int, List<DmgType>> _species = new Dictionary<int, List<DmgType>>();

	private static bool _loaded;

	private static bool _dirty;

	private static readonly HashSet<string> _removed = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

	private static readonly HashSet<int> _speciesTouched = new HashSet<int>();

	private static DateTime _savedAt = DateTime.MinValue;

	public static int Version;

	private static DateTime _checkedAt = DateTime.MinValue;

	private static DateTime _fileTime = DateTime.MinValue;

	private static string FilePath => Util.FullPath("MelkTank_MonsterDb.txt");

	public static IEnumerable<Entry> All
	{
		get
		{
			Load();
			return _byName.Values;
		}
	}

	public static int Count
	{
		get
		{
			Load();
			return _byName.Count;
		}
	}

	private static void PickUpOthers()
	{
		if ((DateTime.Now - _checkedAt).TotalSeconds < 30.0)
		{
			return;
		}
		_checkedAt = DateTime.Now;
		try
		{
			DateTime dateTime = (File.Exists(FilePath) ? File.GetLastWriteTimeUtc(FilePath) : DateTime.MinValue);
			if (dateTime <= _fileTime)
			{
				return;
			}
			_fileTime = dateTime;
			Dictionary<string, Entry> disk = new Dictionary<string, Entry>(StringComparer.OrdinalIgnoreCase);
			Dictionary<int, List<DmgType>> diskSp = new Dictionary<int, List<DmgType>>();
			Util.Locked(FilePath, () =>
			{
				ReadFile(disk, diskSp);
			});
			foreach (KeyValuePair<string, Entry> item in disk)
			{
				if (!_removed.Contains(item.Key) && (!_byName.TryGetValue(item.Key, out var value) || item.Value.Updated > value.Updated))
				{
					_byName[item.Key] = item.Value;
				}
			}
			foreach (KeyValuePair<int, List<DmgType>> item2 in diskSp)
			{
				if (!_speciesTouched.Contains(item2.Key))
				{
					_species[item2.Key] = item2.Value;
				}
			}
			Version++;
		}
		catch
		{
		}
	}

	public static Entry Get(string name)
	{
		if (string.IsNullOrEmpty(name))
		{
			return null;
		}
		Load();
		PickUpOthers();
		Entry value;
		return _byName.TryGetValue(name, out value) ? value : null;
	}

	public static List<DmgType> SpeciesRanking(int species)
	{
		Load();
		List<DmgType> value;
		return _species.TryGetValue(species, out value) ? value : null;
	}

	public static bool HasSpeciesRanking(int species)
	{
		List<DmgType> list = SpeciesRanking(species);
		return list != null && list.Count > 0;
	}

	public static void SetSpeciesRanking(int species, List<DmgType> r)
	{
		Load();
		if (r == null || r.Count == 0)
		{
			_species.Remove(species);
		}
		else
		{
			_species[species] = new List<DmgType>(r);
		}
		_speciesTouched.Add(species);
		Changed(now: true);
	}

	public static Entry GetOrAdd(string name)
	{
		Load();
		if (!_byName.TryGetValue(name, out var value))
		{
			value = new Entry
			{
				Name = name,
				Updated = DateTime.Now.Ticks
			};
			_byName[name] = value;
			_removed.Remove(name);
			Changed(now: false);
		}
		return value;
	}

	public static void Remove(string name)
	{
		Load();
		if (_byName.Remove(name))
		{
			_removed.Add(name);
			Changed(now: true);
		}
	}

	public static void Touch(Entry e)
	{
		if (e != null)
		{
			e.Updated = DateTime.Now.Ticks;
		}
	}

	public static void Learn(int id, int maxHp)
	{
		try
		{
			WorldObject worldObject = Globals.Core.WorldFilter[id];
			if (worldObject != null && worldObject.ObjectClass == ObjectClass.Monster && !string.IsNullOrEmpty(worldObject.Name))
			{
				Entry orAdd = GetOrAdd(worldObject.Name);
				int num = 0;
				int num2 = 0;
				try
				{
					num = worldObject.Values(LongValueKey.Species);
				}
				catch
				{
				}
				try
				{
					num2 = worldObject.Values(LongValueKey.CreatureLevel);
				}
				catch
				{
				}
				bool flag = false;
				if (!orAdd.SpeciesEdited && num > 0 && orAdd.Species != num)
				{
					orAdd.Species = num;
					flag = true;
				}
				if (!orAdd.HpEdited && maxHp > 0 && orAdd.MaxHp != maxHp)
				{
					orAdd.MaxHp = maxHp;
					flag = true;
				}
				if (num2 > 0 && orAdd.Level != num2)
				{
					orAdd.Level = num2;
					flag = true;
				}
				if ((DateTime.Now - orAdd.LastSeen).TotalMinutes > 5.0)
				{
					orAdd.Seen++;
					flag = true;
				}
				orAdd.LastSeen = DateTime.Now;
				if (flag)
				{
					Touch(orAdd);
					Changed(now: false);
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void Changed(bool now)
	{
		_dirty = true;
		Version++;
		if (now || (DateTime.Now - _savedAt).TotalSeconds > 30.0)
		{
			Save();
		}
	}

	public static void Flush()
	{
		if (_dirty)
		{
			Save();
		}
	}

	private static string Esc(string s)
	{
		return (s ?? "").Replace("\t", " ").Replace("\r", " ").Replace("\n", " ");
	}

	public static string RankText(List<DmgType> r)
	{
		return (r == null) ? "" : string.Join(",", r.ConvertAll((DmgType d) => d.ToString()).ToArray());
	}

	public static List<DmgType> ParseRank(string s)
	{
		List<DmgType> list = new List<DmgType>();
		string[] array = (s ?? "").Split(',');
		foreach (string text in array)
		{
			try
			{
				string text2 = text.Trim();
				if (text2.Length != 0)
				{
					DmgType dmgType = (DmgType)Enum.Parse(typeof(DmgType), text2, ignoreCase: true);
					if (dmgType != DmgType.Auto && !list.Contains(dmgType))
					{
						list.Add(dmgType);
					}
				}
			}
			catch
			{
			}
		}
		return list;
	}

	private static void Load()
	{
		if (_loaded)
		{
			return;
		}
		_loaded = true;
		Util.Locked(FilePath, () =>
		{
			ReadFile(_byName, _species);
		});
		try
		{
			if (File.Exists(FilePath))
			{
				_fileTime = File.GetLastWriteTimeUtc(FilePath);
			}
		}
		catch
		{
		}
	}

	private static void ReadFile(Dictionary<string, Entry> into, Dictionary<int, List<DmgType>> species)
	{
		try
		{
			if (!File.Exists(FilePath))
			{
				return;
			}
			string[] array = File.ReadAllLines(FilePath);
			foreach (string text in array)
			{
				string[] array2 = text.Split('\t');
				if (array2.Length >= 3 && array2[0] == "S")
				{
					if (int.TryParse(array2[1], out var result))
					{
						List<DmgType> list = ParseRank(array2[2]);
						if (list.Count > 0)
						{
							species[result] = list;
						}
					}
				}
				else if (array2.Length >= 9 && array2[0] == "M" && array2[1].Length > 0)
				{
					Entry entry = new Entry
					{
						Name = array2[1]
					};
					int.TryParse(array2[2], out entry.Species);
					int.TryParse(array2[3], out entry.MaxHp);
					int.TryParse(array2[4], out entry.Level);
					entry.Ranking = ParseRank(array2[5]);
					entry.Notes = array2[6];
					entry.SpeciesEdited = array2[7].Contains("s");
					entry.HpEdited = array2[7].Contains("h");
					if (long.TryParse(array2[8], out var result2) && result2 > 0)
					{
						entry.LastSeen = new DateTime(result2);
					}
					if (array2.Length >= 10)
					{
						int.TryParse(array2[9], out entry.Seen);
					}
					if (array2.Length >= 11)
					{
						long.TryParse(array2[10], out entry.Updated);
					}
					into[entry.Name] = entry;
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void Save()
	{
		Util.Locked(FilePath, SaveLocked);
	}

	private static void SaveLocked()
	{
		try
		{
			Dictionary<string, Entry> dictionary = new Dictionary<string, Entry>(StringComparer.OrdinalIgnoreCase);
			Dictionary<int, List<DmgType>> dictionary2 = new Dictionary<int, List<DmgType>>();
			ReadFile(dictionary, dictionary2);
			foreach (KeyValuePair<string, Entry> item in dictionary)
			{
				if (!_removed.Contains(item.Key) && (!_byName.TryGetValue(item.Key, out var value) || item.Value.Updated > value.Updated))
				{
					_byName[item.Key] = item.Value;
				}
			}
			foreach (KeyValuePair<int, List<DmgType>> item2 in dictionary2)
			{
				if (!_speciesTouched.Contains(item2.Key))
				{
					_species[item2.Key] = item2.Value;
				}
			}
			foreach (int item3 in new List<int>(_species.Keys))
			{
				if (!_speciesTouched.Contains(item3) && !dictionary2.ContainsKey(item3))
				{
					_species.Remove(item3);
				}
			}
			_removed.Clear();
			_speciesTouched.Clear();
			Version++;
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append("# MelkTank monster DB: M name species maxhp level damage-order notes edited(s=species h=hp) lastseen-ticks times-seen updated-ticks / S species damage-order\r\n");
			foreach (KeyValuePair<int, List<DmgType>> item4 in _species)
			{
				stringBuilder.Append("S\t").Append(item4.Key).Append('\t')
					.Append(RankText(item4.Value))
					.Append("\r\n");
			}
			List<Entry> list = new List<Entry>(_byName.Values);
			list.Sort((Entry a, Entry b) => string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase));
			foreach (Entry item5 in list)
			{
				stringBuilder.Append("M\t").Append(Esc(item5.Name)).Append('\t')
					.Append(item5.Species)
					.Append('\t')
					.Append(item5.MaxHp)
					.Append('\t')
					.Append(item5.Level)
					.Append('\t')
					.Append(RankText(item5.Ranking))
					.Append('\t')
					.Append(Esc(item5.Notes))
					.Append('\t')
					.Append(item5.SpeciesEdited ? "s" : "")
					.Append(item5.HpEdited ? "h" : "")
					.Append('\t')
					.Append(item5.LastSeen.Ticks)
					.Append('\t')
					.Append(item5.Seen)
					.Append('\t')
					.Append(item5.Updated)
					.Append("\r\n");
			}
			Util.WriteShared(FilePath, stringBuilder.ToString());
			try
			{
				_fileTime = File.GetLastWriteTimeUtc(FilePath);
			}
			catch
			{
			}
			_dirty = false;
			_savedAt = DateTime.Now;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}
}
