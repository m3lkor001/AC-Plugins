using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using MelkTank.Metas;
using AcClient;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Bounties;
using MelkTank.Buffs;

namespace MelkTank;

public static class Session
{
	public class MobStat
	{
		public string Name;

		public int Species;

		public int Kills;

		public double TotalSecs;

		public double Fastest = double.MaxValue;

		public double Slowest;

		public double Avg => (Kills > 0) ? (TotalSecs / (double)Kills) : 0.0;
	}

	public class Stats
	{
		public DateTime Since = DateTime.Now;

		public double PlayedSecs;

		public int Kills;

		public int Deaths;

		public int LootItems;

		public int Corpses;

		public int CorpsesKept;

		public int LootArmor;

		public int LootClothing;

		public int LootJewelry;

		public int LootWeapons;

		public int LootMisc;

		public readonly Dictionary<string, MobStat> Mobs = new Dictionary<string, MobStat>(StringComparer.OrdinalIgnoreCase);

		public void Clear()
		{
			Since = DateTime.Now;
			PlayedSecs = 0.0;
			Kills = (Deaths = (LootItems = (Corpses = (CorpsesKept = 0))));
			LootArmor = (LootClothing = (LootJewelry = (LootWeapons = (LootMisc = 0))));
			Mobs.Clear();
		}

		public void AddKill(string name, int species, double secs)
		{
			Kills++;
			if (!Mobs.TryGetValue(name, out var value))
			{
				value = new MobStat
				{
					Name = name
				};
				Mobs[name] = value;
			}
			if (species > 0)
			{
				value.Species = species;
			}
			value.Kills++;
			value.TotalSecs += secs;
			if (secs < value.Fastest)
			{
				value.Fastest = secs;
			}
			if (secs > value.Slowest)
			{
				value.Slowest = secs;
			}
		}

		public void AddLoot(ObjectClass c)
		{
			LootItems++;
			switch (c)
			{
			case ObjectClass.Armor:
				LootArmor++;
				break;
			case ObjectClass.Clothing:
				LootClothing++;
				break;
			case ObjectClass.Jewelry:
				LootJewelry++;
				break;
			case ObjectClass.MeleeWeapon:
			case ObjectClass.MissileWeapon:
			case ObjectClass.WandStaffOrb:
				LootWeapons++;
				break;
			default:
				LootMisc++;
				break;
			}
		}
	}

	private class Gone
	{
		public string Name;

		public int Species;

		public DateTime EngagedAt;

		public DateTime At;

		public bool Unengaged;
	}

	private class KillText
	{
		public string Text;

		public DateTime At;
	}

	private class Corpse
	{
		public string Name;

		public DateTime At;
	}

	public class LootRec
	{
		public DateTime At;

		public string Rule = "";

		public string Desc = "";

		public string Cat = "";

		public string Vs = "";

		public int VsColor = 7;
	}

	private class SeenBounty
	{
		public string Zone;

		public string Reward;

		public string Count;

		public DateTime At;

		public DateTime UnlocksAt;

		public int Have;

		public int Need;
	}

	private class BankLine
	{
		public string Name;

		public string Value;

		public DateTime At;
	}

	private class Sample
	{
		public DateTime At;

		public long Lum;

		public long Xp;
	}

	private class SortState
	{
		public int Col = 1;

		public bool Desc = true;

		public int OpenAll;
	}

	private class Group
	{
		public int Species;

		public string Name;

		public readonly List<MobStat> Mobs = new List<MobStat>();

		public int Kills;

		public double TotalSecs;

		public double Fastest = double.MaxValue;

		public double Slowest;

		public double Avg => (Kills > 0) ? (TotalSecs / (double)Kills) : 0.0;
	}

	private class AttrRow
	{
		public string Key;

		public string Name;

		public string Abbr;

		public long Cost;

		public long Cost10;

		public DateTime CostAt;
	}

	private class AugKind
	{
		public string Tab;

		public string Key;

		public string Gem;

		public int Coins;

		public int[] Caps;

		public AugKind(string t, string k, string g, int coins, params int[] caps)
		{
			Tab = t;
			Key = k;
			Gem = g;
			Coins = coins;
			Caps = ((caps != null && caps.Length != 0) ? caps : null);
		}
	}

	private class AugQuote
	{
		public long Level;

		public long Levels;

		public long Lum;
	}

	private enum Ae
	{
		Off,
		Train,
		Start,
		Going,
		Outside,
		Jumped,
		Sent,
		Yes,
		Subway
	}

	public class BountyTier
	{
		public double RewardB = 100.0;

		public double CooldownMin = 60.0;

		public int Kills = 300;

		public bool Set;
	}

	public class DeedTier
	{
		public int QB;

		public bool Unlocked;

		public List<string> Lines = new List<string>();
	}

	public class EnlPlanResult
	{
		public int Reach;

		public string Stop = "";

		public long BuyTokens;

		public long SellCoins;

		public long SellLum;

		public long Medallions;

		public long Parts;

		public long TokensUsed;

		public long LumNeeded;

		public long LumShort;

		public long TokensShort;

		public long PartsShort;

		public bool Possible = true;
	}

	public class RtEntry
	{
		public int Skill;

		public bool Train;

		public bool Spec;

		public bool Enl;
	}

	[UnmanagedFunctionPointer(CallingConvention.ThisCall)]
	private delegate nint GetSkillBaseDel(nint table, uint skill);

	private static readonly Vector4 BGreen = new Vector4(0.45f, 0.9f, 0.45f, 1f);

	private static readonly Vector4 BGold = new Vector4(0.95f, 0.8f, 0.3f, 1f);

	private static readonly Vector4 BOrange = new Vector4(1f, 0.6f, 0.2f, 1f);

	private static readonly Vector4 BGrey = new Vector4(0.6f, 0.6f, 0.6f, 1f);

	public static readonly Stats Cur = new Stats();

	public static readonly Stats All = new Stats();

	private static readonly List<KillText> _killTexts = new List<KillText>();

	private static readonly List<Gone> _gone = new List<Gone>();

	private static readonly List<Corpse> _corpses = new List<Corpse>();

	private static DateTime _killLineAt = DateTime.MinValue;

	private static DateTime _killEventAt = DateTime.MinValue;

	// what your pet hit, and when ("[Pet] Melka Summoner's Alarming Simulacrum Melee hit Crusty Cheese for 31020"): a monster
	// only the pet fought leaves no death line and no corpse (pet-only ones), just the luminance banked - that and the pet's hit count it
	private static readonly Dictionary<string, DateTime> _petHits = new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);
	private static readonly Regex PetHitRx = new Regex("^\\[Pet\\] .+? hit (.+?) for [\\d,]+", RegexOptions.Compiled);
	private static bool PetKilled(Gone g) =>
		_petHits.TryGetValue(g.Name, out DateTime at) && (g.At - at).TotalSeconds < 30.0 && Math.Abs((_killLineAt - g.At).TotalSeconds) <= 5.0;

	private static DateTime _nextTick = DateTime.MinValue;

	private const double MatchSecs = 5.0;

	private const double NearM = 60.0;

	private static string _file;

	private static DateTime _playedMark = DateTime.Now;

	private static bool _allDirty;

	private static DateTime _savedAt = DateTime.MinValue;

	public static readonly List<LootRec> Looted = new List<LootRec>();

	private const int MaxLooted = 500;

	private static readonly Dictionary<string, SeenBounty> _bounties = new Dictionary<string, SeenBounty>(StringComparer.OrdinalIgnoreCase);

	private static readonly Regex BountyHereRx = new Regex("^Bounty(?: \\((?<zone>[^)]*)\\))?:\\s*(?<reward>.+?)\\s+-\\s+(?<have>[\\d,]+) of (?<need>[\\d,]+) kills\\.?$", RegexOptions.IgnoreCase);

	private static readonly Regex BountyLockedRx = new Regex("^Bounty(?: \\((?<zone>[^)]*)\\))?:\\s*(?<reward>.+?)\\s+-\\s+unlocks in (?<time>.+?),\\s*then (?<need>[\\d,]+) kills required\\.?$", RegexOptions.IgnoreCase);

	private static readonly Regex SpanPartRx = new Regex("(?<n>\\d+)\\s*(?<u>days?|d|hours?|hrs?|h|minutes?|mins?|m|seconds?|secs?|s)\\b", RegexOptions.IgnoreCase);

	private static readonly Regex HaveNeedRx = new Regex("^\\s*([\\d,]+)\\s*/\\s*([\\d,]+)");

	private static bool _hooked;

	private static readonly List<BankLine> _bank = new List<BankLine>();

	private static string _bankFile;

	private static readonly Regex BankRx = new Regex("^\\[BANK\\]\\s*(?<n>[^:]+?):\\s*(?<v>.+)$", RegexOptions.IgnoreCase);

	private static DateTime _bankDirtyAt = DateTime.MinValue;

	private static readonly List<KeyValuePair<string, string>> _augs = new List<KeyValuePair<string, string>>();

	private static DateTime _augsAt = DateTime.MinValue;

	private static DateTime _augCaptureUntil = DateTime.MinValue;

	private static string _augFile;

	private static readonly Regex AugLineRx = new Regex("^(?<n>[A-Za-z][^:]{1,60}?):\\s*(?<v>.+)$");

	private static DateTime _augDirtyAt = DateTime.MinValue;

	// /aug's "Hunting rewards this week" part (T11+): augmentations earned by kills in your own tier
	private static readonly List<string> _augHunt = new List<string>();

	private static bool _augInHunt;

	/// <summary>Kills (in T11+) since /aug last gave the week's count.</summary>
	private static int _augKillsSince;

	private static DateTime _augHuntResetAt = DateTime.MinValue;

	private static readonly Regex AugHuntLineRx = new Regex("^(Hunting rewards|Each reward|Attack school|Kills this week|First [\\d,]+ kills|After [\\d,]+ kills|Beyond [\\d,]+ kills|Week resets|This tier so far)", RegexOptions.IgnoreCase);

	private static readonly Regex AugNumberRowRx = new Regex("^(?<n>[A-Za-z][^:]{1,60}?):\\s*(?<v>[\\d,]+(\\s.*)?)$");

	private static readonly Regex AugResetInRx = new Regex("\\(in (?:(?<d>\\d+) days?)?\\s*(?:(?<h>\\d+) hours?)?\\s*(?:(?<m>\\d+) min(?:ute)?s?)?\\)", RegexOptions.IgnoreCase);

	private static readonly Regex AugTierSoFarRx = new Regex("(?<n>[A-Za-z]+) (?<v>[\\d,]+) of (?<c>[\\d,]+)");

	private static DateTime _quietBankUntil = DateTime.MinValue;

	private static DateTime _quietAugUntil = DateTime.MinValue;

	private static DateTime _bankNextPoll = DateTime.MinValue;

	private static long _lumEarned;

	private static long _xpStart = -1L;

	public static bool CountLumTokens = true;

	public static double LumTokenValue = 50000000000.0;

	private const string LumTokenName = "thaelaryn token of luminance";

	private static long _tokBase = -1L;

	private static long _tokGot;

	private static long _tokHeld;

	// (the "You've banked ... Luminance" lines alone - what the bank gained beyond them is fellowship shares and passup)
	private static long _lumBankedLines;

	public static long LumBankedLines => _lumBankedLines;

	private static readonly Regex TokDepositRx = new Regex("^Deposited (?<n>[\\d,]+) x Thaelaryn Tokens? of Luminance", RegexOptions.IgnoreCase);

	private static DateTime _tokNext = DateTime.MinValue;

	private static DateTime _tokArmAt = DateTime.MinValue;

	private static readonly List<Sample> _samples = new List<Sample>();

	private static DateTime _nextSample = DateTime.MinValue;

	private static DateTime _ratesAt = DateTime.MinValue;

	private static double _lumPh;

	private static double _xpPh;

	private static double _lumPhR;

	private static double _xpPhR;

	public const int PackMinKills = 3;

	private static bool _inFight;

	private static DateTime _fightStart;

	private static DateTime _lastMobsAt;

	private static DateTime _fightEndAt;

	private static int _fightKills0;

	public static int Packs;

	public static int PackKills;

	public static double PackTotalSecs;

	public static double PackFastest = double.MaxValue;

	public static double PackSlowest;

	public static double PackLast;

	private static readonly List<DateTime> _recent = new List<DateTime>();

	private static DateTime _recentSince = DateTime.MinValue;

	private static readonly Vector4 Cyan = new Vector4(0.35f, 0.85f, 0.95f, 1f);

	private static readonly Vector4 Yellow = new Vector4(0.95f, 0.85f, 0.35f, 1f);

	private static readonly SortState _curSort = new SortState();

	private static readonly SortState _allSort = new SortState();

	private static bool _confirmReset;

	private static bool _confirmResetAll;

	private static readonly AttrRow[] AttrRows = new AttrRow[9]
	{
		new AttrRow
		{
			Key = "Strength",
			Name = "Strength",
			Abbr = "str"
		},
		new AttrRow
		{
			Key = "Endurance",
			Name = "Endurance",
			Abbr = "end"
		},
		new AttrRow
		{
			Key = "Coordination",
			Name = "Coordination",
			Abbr = "coo"
		},
		new AttrRow
		{
			Key = "Quickness",
			Name = "Quickness",
			Abbr = "qui"
		},
		new AttrRow
		{
			Key = "Focus",
			Name = "Focus",
			Abbr = "foc"
		},
		new AttrRow
		{
			Key = "Self",
			Name = "Self",
			Abbr = "sel"
		},
		new AttrRow
		{
			Key = "MaxHealth",
			Name = "Max Health",
			Abbr = "hea"
		},
		new AttrRow
		{
			Key = "MaxStamina",
			Name = "Max Stamina",
			Abbr = "sta"
		},
		new AttrRow
		{
			Key = "MaxMana",
			Name = "Max Mana",
			Abbr = "man"
		}
	};

	private const double AttrGrowth = 1.077;

	private static readonly Regex AttrCostRx = new Regex("^\\[XP\\] Your XP cost for next (\\d+) (\\w+) levels? is: ([\\d,]+)", RegexOptions.IgnoreCase);

	private static readonly Regex AttrRaisedRx = new Regex("Your base (?:Maximum )?(\\w+) is now ([\\d,]+)!", RegexOptions.IgnoreCase);

	private static DateTime _attrQuietUntil = DateTime.MinValue;

	private static DateTime _attrNextAuto = DateTime.MinValue;

	private static DateTime _attrSentAt = DateTime.MinValue;

	private static DateTime _attrAskedAt = DateTime.MinValue;

	private static bool _attrSpending;

	private static bool _attrWaitRaise;

	private static string _attrStatus = "";

	private static string _attrSpentNote = "";

	private static int _attrSpentLevels;

	private static readonly List<string> _attrQ = new List<string>();

	private static DateTime _attrNextStep = DateTime.MinValue;

	private static readonly AugKind[] AugKinds = new AugKind[10]
	{
		new AugKind("Creature", "Creature", "Creature Magic", 3, 2750, 4000, 4750, 5250),
		new AugKind("Item", "Item", "Item Magic", 18, 1250, 2000, 3000, 3500),
		new AugKind("Life", "Life", "Life Magic", 12, 1000, 2000, 3000, 3750),
		new AugKind("War", "War", "War Magic", 5, 1750, 2500, 3000, 3750),
		new AugKind("Void", "Void", "Void Magic", 5, 1750, 2500, 3000, 3750),
		new AugKind("Duration", "Duration", "Spell Duration", 5, 1000, 2000, 2500, 3000),
		new AugKind("Specialization", "Specialization", "Specialized Skill", 50),
		new AugKind("Summon", "Summon", "Summoning", 36, 1250, 2000, 3000, 3500),
		new AugKind("Melee", "Melee", "Melee", 5, 1750, 2500, 3000, 3750),
		new AugKind("Missile", "Missile", "Missile", 5, 1750, 2500, 3000, 3750)
	};

	private static readonly int[] GemSizes = new int[4] { 1, 10, 50, 100 };

	private static readonly Dictionary<string, string> _augGoal = new Dictionary<string, string>();

	private static DateTime _augRecheckAt = DateTime.MinValue;

	private static Dictionary<string, AugQuote> _augQuotes;

	private static readonly Regex AugQuoteRx = new Regex("spend ([\\d,]+) luminance to add ([\\d,]+) points? to your (.+?)(?: spell effects| abilit| skill|\\.|$)", RegexOptions.IgnoreCase);

	private static double _coinLum = -1.0;

	private static DateTime _coinLumAt = DateTime.MinValue;

	private static readonly Vector4 AugGreen = new Vector4(0.45f, 0.9f, 0.45f, 1f);

	private static readonly Vector4 AugYellow = new Vector4(0.95f, 0.85f, 0.35f, 1f);

	private const string AePauser = "Auto enlighten";

	public static string AeGo = "";

	public static int AeTarget;

	private static Ae _ae = Ae.Off;

	private static string _aeStatus = "";

	private static DateTime _aeAt = DateTime.MinValue;

	private static DateTime _aeStepAt = DateTime.MinValue;

	private static DateTime _aeCellAt = DateTime.MinValue;

	private static DateTime _aeLvlAt = DateTime.MinValue;

	private static int _aeCell;

	private static int _aeTries;

	private static int _aeRefused;

	private static int _aeDone;

	private static bool _aeError;

	private static bool _aeMagicAsked;

	private static bool _aeStill;

	private static string _aeLastError = "";

	private static List<string> _aeOpts;

	private static DateTime _aeOptsAt = DateTime.MinValue;

	public const int BountyTierMin = 11;

	public const int BountyTierMax = 25;

	public static bool BountyRateOn;

	public static Func<int> CurrentTier = () => -1;

	private static readonly Dictionary<int, BountyTier> _bountyTiers = new Dictionary<int, BountyTier>();

	private static bool _bountyLoaded;

	private static bool _lumIsBounty;

	private static int _bountyPick = -1;

	private static readonly CultureInfo CI = CultureInfo.InvariantCulture;

	private static readonly double[] CoinRates = new double[8] { 0.05, 0.06, 0.072, 0.086, 0.104, 0.124, 0.149, 0.179 };

	private static double _coinAcc;

	private static bool _coinSynced;

	private static int _coinsGot;

	private static DateTime _coinAt = DateTime.MinValue;

	private static readonly List<DateTime> _coinTimes = new List<DateTime>();

	private static readonly Regex CoinRx = new Regex("^(?<n>[\\d,]+) Prestige Coins? (?:has|have) been added to your bank", RegexOptions.IgnoreCase);

	private static readonly List<KeyValuePair<DateTime, int>> _coinLog = new List<KeyValuePair<DateTime, int>>();

	private static readonly List<DeedTier> _deeds = new List<DeedTier>();

	private static readonly List<KeyValuePair<string, string>> _bonus = new List<KeyValuePair<string, string>>();

	private static string _deedsHead = "";

	private static string _qbCount = "";

	private static bool _deedsOn = true;

	private static DateTime _deedsAt = DateTime.MinValue;

	private static DateTime _qbAt = DateTime.MinValue;

	private static DateTime _bonusAt = DateTime.MinValue;

	private static DateTime _deedCaptureUntil = DateTime.MinValue;

	private static DateTime _bonusCaptureUntil = DateTime.MinValue;

	private static DateTime _deedsDirtyAt = DateTime.MinValue;

	private static DateTime _quietDeedsUntil = DateTime.MinValue;

	private static DateTime _quietQbUntil = DateTime.MinValue;

	private static DateTime _quietBonusUntil = DateTime.MinValue;

	private static string _deedsFile;

	private static DeedTier _curTier;

	private static readonly Regex DeedHeadRx = new Regex("^Your QB:\\s*[\\d,]+\\s*-\\s*Deeds bonuses are (?<on>ON|OFF)", RegexOptions.IgnoreCase);

	private static readonly Regex DeedTierRx = new Regex("^(?<qb>\\d[\\d,]*)\\s*QB(?<u>\\s*\\(unlocked\\))?\\s*$", RegexOptions.IgnoreCase);

	private static readonly Regex QbRx = new Regex("Your current quest bonus count:\\s*(?<n>[\\d,]+)", RegexOptions.IgnoreCase);

	private static readonly Regex BonusRx = new Regex("^\\[BONUS\\]\\s*Your (?:XP multiplier from )?(?<n>.+?) is:\\s*(?<v>.+)$", RegexOptions.IgnoreCase);

	private static readonly CultureInfo EnlInv = CultureInfo.InvariantCulture;

	private static int _enlManual;

	private static readonly string[] EnlItems = new string[7] { "Enlightenment Medallion", "Enlightenment Token", "Part of a Medallion", "Trophy", "Yellow Aetheria Powder", "Yellow Aetheria Chunk", "Aetheria Desiccant" };

	private static readonly Dictionary<string, int> _enlHave = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

	private static DateTime _enlCountAt = DateTime.MinValue;

	public static bool MkPowder = true;

	public static bool MkParts = true;

	public static bool MkMedallions = true;

	public static bool MkFiun = true;

	private const string FiunBig = "Fiun of Great Enlightenment";

	private const string FiunSmall = "Fiun of Enlightenment";

	private static int _mkPartsBefore;

	private static int _mkFiunN;

	public static int MkStopAt;

	private static bool _mkOn;

	private static string _mkStatus = "";

	private static string _mkStep = "";

	private static DateTime _mkSentAt = DateTime.MinValue;

	private static DateTime _mkPeaceAsked = DateTime.MinValue;

	private static DateTime _mkNextAt = DateTime.MinValue;

	private static bool _mkWaiting;

	private static bool _mkGot;

	private static int _mkMisses;

	private static int _mkMade;

	private static readonly Dictionary<string, int> _mkCounts = new Dictionary<string, int>();

	private static int _enlTarget;

	private static int _calcFor = -1;

	private static int _calcLevel;

	private static int _calcTokens;

	private static int _calcMedals;

	private static long _calcLum;

	public const int CoinsPerToken = 20;

	public static bool MkBank = true;

	private static DateTime _bankCmdAt = DateTime.MinValue;

	private static DateTime _bankRecheckAt = DateTime.MinValue;

	private static bool _mkWithdrawing;

	private static int _mkTokBefore;

	private static DateTime _mkWdSent;

	private const double BankCmdGapS = 6.0;

	private const int MaxTokensPerBuy = 100;

	private static long _buyLeft;

	private static long _buyTotal;

	private static long _buyDone;

	private static bool _buyWaiting;

	private static int _buyMisses;

	private static int _buyTokBefore;

	private static int _buyNow;

	private static DateTime _buyNextAt = DateTime.MinValue;

	private static DateTime _buySentAt;

	private static double _lpc = -1.0;

	private static DateTime _lpcAt = DateTime.MinValue;

	private static readonly Regex FrPrimeRx = new Regex("^Your void enchantments prime ", RegexOptions.IgnoreCase);

	private static readonly Regex FrDeathRx = new Regex("^Your primed enchantments release Nether Fracture as ", RegexOptions.IgnoreCase);

	private static DateTime _frDeathAt = DateTime.MinValue;

	private static readonly Regex FrHitRx = new Regex("^Your Nether Fracture strikes (?<who>.+?) for (?<n>[\\d,]+) points", RegexOptions.IgnoreCase);

	private static int _frPrimes;

	private static int _frBursts;

	private static int _frByStreak;

	private static int _frOnDeath;

	private static int _frHits;

	private static int _frNoDmg;

	private static bool _frWaiting;

	private static long _frDmg;

	private static long _frMax;

	private static long _frCur;

	private static DateTime _frLastHit = DateTime.MinValue;

	private static DateTime _frStreakAt = DateTime.MinValue;

	private static double _paceRoom = -1.0;

	private static double _paceMax = 30.0;

	private static double _paceRate = 375.0;

	private static double _paceSlow = 0.5;

	private static DateTime _paceAt = DateTime.MinValue;

	private static int _paceMyTier = -1;

	private static int _paceZoneTier = -1;

	private static double _paceCredit = -1.0;

	private static DateTime _paceChecked = DateTime.MinValue;

	private static DateTime _paceQuietUntil = DateTime.MinValue;

	private static DateTime _paceSent = DateTime.MinValue;

	private static int _paceCheckedTier = -1;

	private static bool _paceSlowNow;

	// the coin hour (patch 11-21, in place of the 11-11 pace): from the first Prestige Coin kill, 60 minutes; the first
	// 375 kills pay full, then each 75 pay half the step before (50%, 25%, 12.5% ...). A kill below your tier uses its
	// share of a kill. One count per character across zones, kept through relogs - read back from /tierdip.
	private const double HourFull = 375.0, HourStep = 75.0;
	private static DateTime _hourStart = DateTime.MinValue;
	private static double _hourKills;
	private static DateTime _hourSynced = DateTime.MinValue;
	private static readonly Regex HourKillsRx = new Regex("([\\d,]+(?:\\.\\d+)?)\\s*(?:/|of)\\s*375\\b|([\\d,]+(?:\\.\\d+)?)\\s+(?:coin[- ]hour\\s+)?kills?\\b(?! of)", RegexOptions.IgnoreCase);
	private static readonly Regex HourLeftRx = new Regex("(\\d+)\\s*(?:m\\b|min)", RegexOptions.IgnoreCase);

	private static readonly Regex PaceMyRx = new Regex("^Your tier:\\s*T(\\d+)", RegexOptions.IgnoreCase);

	private static readonly Regex PaceZoneRx = new Regex("^This zone:\\s*T(\\d+)", RegexOptions.IgnoreCase);

	private static readonly Regex PaceCreditRx = new Regex("^Kills here give you .*?\\((\\d+(?:\\.\\d+)?) pct\\)", RegexOptions.IgnoreCase);

	private static readonly Regex PaceRateRx = new Regex("full rate up to ([\\d,]+) kills an hour.*?pays (\\d+) pct", RegexOptions.IgnoreCase);

	private static readonly Regex PaceRoomRx = new Regex("You can get ([\\d.]+) kills? ahead of that pace.*?\\(the most is ([\\d.]+)\\)", RegexOptions.IgnoreCase);

	private static readonly Regex PaceAnyRx = new Regex("^(Your tier:|This zone:|Kills here give you|Each tier below your own costs|Prestige Coins: full rate|You can get [\\d.]+ kills? ahead|You are [\\d.]+ kills? (past|ahead|over)|.*\\bcoin hour\\b|.*Portal Gem.*\\b(cap|capping|capped)\\b|You have no (Tou Tou )?(Endgame )?Portal Gem|T11 needs no gem)", RegexOptions.IgnoreCase);

	private static readonly int[] RtAll = new int[38]
	{
		32, 34, 43, 33, 31, 54, 16, 14, 15, 6,
		7, 21, 44, 45, 46, 47, 41, 48, 49, 50,
		51, 52, 18, 28, 29, 30, 37, 38, 39, 19,
		20, 23, 27, 35, 36, 22, 24, 40
	};

	private static readonly int[] RtAuto = new int[3] { 22, 24, 40 };

	private static readonly Dictionary<int, string> RtNames = new Dictionary<int, string>
	{
		{ 6, "Melee Defense" },
		{ 7, "Missile Defense" },
		{ 14, "Arcane Lore" },
		{ 15, "Magic Defense" },
		{ 16, "Mana Conversion" },
		{ 18, "Item Tinkering" },
		{ 19, "Assess Person" },
		{ 20, "Deception" },
		{ 21, "Healing" },
		{ 22, "Jump" },
		{ 23, "Lockpick" },
		{ 24, "Run" },
		{ 27, "Assess Creature" },
		{ 28, "Weapon Tinkering" },
		{ 29, "Armor Tinkering" },
		{ 30, "Magic Item Tinkering" },
		{ 31, "Creature Enchantment" },
		{ 32, "Item Enchantment" },
		{ 33, "Life Magic" },
		{ 34, "War Magic" },
		{ 35, "Leadership" },
		{ 36, "Loyalty" },
		{ 37, "Fletching" },
		{ 38, "Alchemy" },
		{ 39, "Cooking" },
		{ 40, "Salvaging" },
		{ 41, "Two Handed Combat" },
		{ 43, "Void Magic" },
		{ 44, "Heavy Weapons" },
		{ 45, "Light Weapons" },
		{ 46, "Finesse Weapons" },
		{ 47, "Missile Weapons" },
		{ 48, "Shield" },
		{ 49, "Dual Wield" },
		{ 50, "Recklessness" },
		{ 51, "Sneak Attack" },
		{ 52, "Dirty Fighting" },
		{ 54, "Summoning" }
	};

	public static List<RtEntry> Rt = RtDefault();

	public static bool RtSpecAtEnd;

	public static bool RtLevelSkills = true;

	private static bool _rtOn;

	private static bool _rtSpec;

	private static int _rtIdx;

	private static int _rtPhase;

	private static int _rtWait;

	private static DateTime _rtAt;

	private static string _rtStatus = "";

	private static string _rtFailed;

	private static readonly List<string> _rtMissing = new List<string>();

	private static readonly List<string> _rtSkipped = new List<string>();

	private static readonly Dictionary<int, string> _rtCost = new Dictionary<int, string>();

	public static int KillCount => Cur.Kills;

	public static double Hours => HoursOf(Cur);

	public static int Kills => Cur.Kills;

	public static long LumEarned => _lumEarned;

	public static long XpEarned
	{
		get
		{
			long num = XpNow();
			return (_xpStart >= 0 && num >= _xpStart) ? (num - _xpStart) : 0;
		}
	}

	public static double LumPerHour
	{
		get
		{
			Rates();
			return _lumPh;
		}
	}

	public static double XpPerHour
	{
		get
		{
			Rates();
			return _xpPh;
		}
	}

	public static double LumPerHourRecent
	{
		get
		{
			Rates();
			return _lumPhR;
		}
	}

	public static double XpPerHourRecent
	{
		get
		{
			Rates();
			return _xpPhR;
		}
	}

	public static double PackAvg => (Packs > 0) ? (PackTotalSecs / (double)Packs) : 0.0;

	public static double KillsPerHourRecent
	{
		get
		{
			DateTime now = DateTime.Now;
			DateTime from = now.AddHours(-1.0);
			_recent.RemoveAll((DateTime t) => t < from);
			DateTime dateTime = ((_recentSince > Cur.Since) ? _recentSince : Cur.Since);
			double num = Math.Min(60.0, (now - dateTime).TotalMinutes);
			if (num < 1.0)
			{
				return -1.0;
			}
			return (double)_recent.Count * 60.0 / num;
		}
	}

	private static string AugQuoteFile => Util.FullPath("MelkTank_AugPrices.txt");

	private static Dictionary<string, AugQuote> AugQuotes
	{
		get
		{
			if (_augQuotes != null)
			{
				return _augQuotes;
			}
			Dictionary<string, AugQuote> dictionary = new Dictionary<string, AugQuote>(StringComparer.OrdinalIgnoreCase);
			try
			{
				if (File.Exists(AugQuoteFile))
				{
					string[] array = File.ReadAllLines(AugQuoteFile);
					foreach (string text in array)
					{
						string[] array2 = text.Split('|');
						if (array2.Length == 4 && long.TryParse(array2[1], out var result) && long.TryParse(array2[2], out var result2) && long.TryParse(array2[3], out var result3))
						{
							dictionary[array2[0]] = new AugQuote
							{
								Level = result,
								Levels = result2,
								Lum = result3
							};
						}
					}
				}
			}
			catch
			{
			}
			if (!dictionary.ContainsKey("War"))
			{
				dictionary["War"] = new AugQuote
				{
					Level = 2400L,
					Levels = 10L,
					Lum = 101019000430L
				};
			}
			if (!dictionary.ContainsKey("Void"))
			{
				dictionary["Void"] = new AugQuote
				{
					Level = 2150L,
					Levels = 10L,
					Lum = 111366401659L
				};
			}
			_augQuotes = dictionary;
			return dictionary;
		}
	}

	private static bool AeOn => _ae != Ae.Off;

	private static string BountyFile => Util.FullPath("MelkTank_BountyTiers.txt");

	public static bool LumRateIsBounty
	{
		get
		{
			Rates();
			return _lumIsBounty;
		}
	}

	private static bool RtAfterEnl => Rt.Exists((RtEntry x) => x.Enl);

	private static bool RtBusy => _rtOn;

	private static void DrawBounties()
	{
		Settings currentSettings = PluginCore.CurrentSettings;
		BountyTracker current = BountyTracker.Current;
		if (currentSettings == null || current == null)
		{
			Im.TextColored(BGrey, "Not logged in yet.");
			return;
		}
		bool flag = false;
		if (ImGui.Checkbox("Bounty pop-up##bhud", ref currentSettings.BountyHudOn))
		{
			flag = true;
			current.Enabled = currentSettings.BountyHudOn;
			if (BountyHud.Current != null)
			{
				BountyHud.Current.Visible = currentSettings.BountyHudOn;
			}
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("The small bounty window. Off: it's hidden and /bounty isn't asked (the list below only updates on Refresh).");
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		int v = currentSettings.BountyMinutes;
		if (ImGui.InputInt("min between /bounty##bmin", ref v, 1, 5))
		{
			currentSettings.BountyMinutes = Math.Max(1, Math.Min(60, v));
			current.IntervalSeconds = currentSettings.BountyMinutes * 60;
			flag = true;
		}
		ImGui.SameLine();
		flag |= ImGui.Checkbox("Show kill tasks##bkts", ref currentSettings.BountyShowKts);
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("MelksQB's kill tasks (its KTs tab - the ones ticked to show on the pop-up) under the bounties.");
		}
		ImGui.SameLine();
		if (ImGui.Button("Refresh list##brefresh"))
		{
			current.RequestList();
		}
		string text = ((current.All.Count == 0) ? "Bounty list: loading after login..." : (current.All.Count + " bounties"));
		if (current.Tier >= 0)
		{
			text = text + "  -  this area: tier " + current.Tier;
		}
		if (!currentSettings.BountyHudOn)
		{
			text += "  -  pop-up off: the list only updates on Refresh";
		}
		else if (current.Paused && current.UpdatedAt != DateTime.MinValue)
		{
			text += "  -  no bounties count here, waiting for a portal";
		}
		else if (current.UpdatedAt != DateTime.MinValue)
		{
			text = text + "  -  updated " + (int)(DateTime.Now - current.UpdatedAt).TotalSeconds + "s ago";
		}
		Im.TextColored(BGrey, text + "   (green = counts here, gold = ready)");
		string text2 = CoinLine();
		if (text2.Length > 0)
		{
			Im.TextColored(BGold, text2);
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip(CoinTip());
			}
		}
		if (current.All.Count > 0 && ImGui.BeginTable("bountylist", 4, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("Zone", ImGuiTableColumnFlags.WidthFixed, 200f);
			ImGui.TableSetupColumn("Reward", ImGuiTableColumnFlags.WidthFixed, 260f);
			ImGui.TableSetupColumn("Kills", ImGuiTableColumnFlags.WidthFixed, 200f);
			ImGui.TableSetupColumn("Limit", ImGuiTableColumnFlags.WidthStretch);
			ImGui.TableHeadersRow();
			foreach (Bounty item in current.All)
			{
				bool flag2 = false;
				foreach (Bounty item2 in current.Here)
				{
					if (current.ListEntryFor(item2) == item)
					{
						flag2 = true;
					}
				}
				bool flag3 = BountyTracker.IsAllZones(item) && !current.AllZonesCount;
				Vector4 col;
				if (item.Need > 0 && item.Have >= item.Need)
				{
					col = BGold;
				}
				else
				{
					col = ((flag2 && !flag3) ? BGreen : Vector4.One);
				}
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				Im.TextColored(col, item.Zone);
				ImGui.TableSetColumnIndex(1);
				Im.TextColored(col, item.Reward);
				ImGui.TableSetColumnIndex(2);
				if (item.Locked)
				{
					Im.TextColored(BOrange, "unlocks in " + BountyTracker.Countdown(item.UnlocksIn));
				}
				else
				{
					string text3 = ((flag2 && !flag3) ? current.TimeToGo(item) : "");
					Im.TextColored(col, item.Have.ToString("N0", CultureInfo.InvariantCulture) + " / " + item.Need.ToString("N0", CultureInfo.InvariantCulture) + ((text3.Length > 0) ? ("  (" + text3 + ")") : ""));
				}
				ImGui.TableSetColumnIndex(3);
				Im.TextColored(BGrey, item.Limit);
			}
			ImGui.EndTable();
		}
		if (!flag)
		{
			return;
		}
		try
		{
			PluginCore.SaveAllNow();
		}
		catch
		{
		}
	}

	private static DateTime NearbyTimerStart(WorldObject o, DateTime fallback)
	{
		DateTime dateTime = DateTime.MaxValue;
		try
		{
			CombatEngine currentEngine = PluginCore.CurrentEngine;
			CoordsObject coordsObject = o.Coordinates();
			if (currentEngine == null || coordsObject == null)
			{
				return fallback;
			}
			foreach (TrackedMonster value in currentEngine.Tracked.Values)
			{
				if (value.EngagedAt == DateTime.MinValue || value.EngagedAt >= dateTime)
				{
					continue;
				}
				CoordsObject coordsObject2 = Globals.Core.WorldFilter[value.Id]?.Coordinates();
				if (coordsObject2 != null)
				{
					double num = (coordsObject2.NorthSouth - coordsObject.NorthSouth) * 240.0;
					double num2 = (coordsObject2.EastWest - coordsObject.EastWest) * 240.0;
					if (num * num + num2 * num2 <= 400.0)
					{
						dateTime = value.EngagedAt;
					}
				}
			}
		}
		catch
		{
		}
		return (dateTime == DateTime.MaxValue || dateTime > DateTime.Now) ? fallback : dateTime;
	}

	public static bool KillLineSince(string name, DateTime since)
	{
		if (string.IsNullOrEmpty(name))
		{
			return false;
		}
		foreach (KillText killText in _killTexts)
		{
			if (killText.At >= since && killText.Text.IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0)
			{
				return true;
			}
		}
		return false;
	}

	private static bool TakeKillText(string name, DateTime around)
	{
		for (int i = 0; i < _killTexts.Count; i++)
		{
			KillText killText = _killTexts[i];
			if (!(Math.Abs((killText.At - around).TotalSeconds) > 5.0) && killText.Text.IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0)
			{
				_killTexts.RemoveAt(i);
				return true;
			}
		}
		return false;
	}

	public static string Category(ObjectClass c)
	{
		switch (c)
		{
		case ObjectClass.Armor:
			return "Armor";
		case ObjectClass.Clothing:
			return "Clothing";
		case ObjectClass.Jewelry:
			return "Jewelry";
		case ObjectClass.MeleeWeapon:
		case ObjectClass.MissileWeapon:
		case ObjectClass.WandStaffOrb:
			return "Weapons";
		default:
			return "Misc";
		}
	}

	public static void NoteLootItem(string rule, string desc, ObjectClass c, string vs = null, int vsColor = 7)
	{
		Looted.Insert(0, new LootRec
		{
			At = DateTime.Now,
			Rule = (rule ?? ""),
			Desc = (desc ?? ""),
			Cat = Category(c),
			Vs = (vs ?? ""),
			VsColor = vsColor
		});
		if (Looted.Count > 500)
		{
			Looted.RemoveAt(Looted.Count - 1);
		}
	}

	public static string SessionJson(string character)
	{
		CultureInfo invariantCulture = CultureInfo.InvariantCulture;
		Stats cur = Cur;
		double num = HoursOf(cur);
		StringBuilder stringBuilder = new StringBuilder("{");
		stringBuilder.Append("\n  \"character\": ").Append(Q(character));
		stringBuilder.Append(",\n  \"updated\": ").Append(Q(DateTime.UtcNow.ToString("o")));
		string s = "";
		try
		{
			CombatEngine currentEngine = PluginCore.CurrentEngine;
			if (currentEngine != null)
			{
				s = currentEngine.Status ?? "";
			}
		}
		catch
		{
		}
		stringBuilder.Append(",\n  \"doing\": ").Append(Q(s));
		stringBuilder.Append(",\n  \"started\": ").Append(Q(cur.Since.ToUniversalTime().ToString("o")));
		stringBuilder.Append(",\n  \"playedSecs\": ").Append(((long)PlayedSecs(cur)).ToString(invariantCulture));
		stringBuilder.Append(",\n  \"kills\": ").Append(cur.Kills);
		stringBuilder.Append(",\n  \"killsPerHour\": ").Append(((long)Math.Round((double)cur.Kills / num)).ToString(invariantCulture));
		int num2 = OutKills(cur);
		if (num2 > 0)
		{
			stringBuilder.Append(",\n  \"killsPerHourTuned\": ").Append(((long)Math.Round((double)(cur.Kills - num2) / TunedHours(cur, num))).ToString(invariantCulture));
		}
		stringBuilder.Append(",\n  \"lumEarned\": ").Append(LumEarned.ToString(invariantCulture));
		stringBuilder.Append(",\n  \"lumPerHour\": ").Append(((long)LumPerHour).ToString(invariantCulture));
		stringBuilder.Append(",\n  \"lumPerHourRecent\": ").Append(((long)LumPerHourRecent).ToString(invariantCulture));
		// (Session > Lum's figures - the app's Lum card)
		try
		{
			stringBuilder.Append(",\n  \"lumTab\": ").Append(LumTrack.Json());
		}
		catch
		{
		}
		stringBuilder.Append(",\n  \"xpEarned\": ").Append(XpEarned.ToString(invariantCulture));
		stringBuilder.Append(",\n  \"xpPerHour\": ").Append(((long)XpPerHour).ToString(invariantCulture));
		stringBuilder.Append(",\n  \"xpPerHourRecent\": ").Append(((long)XpPerHourRecent).ToString(invariantCulture));
		stringBuilder.Append(",\n  \"packs\": ").Append(Packs);
		stringBuilder.Append(",\n  \"packAvg\": ").Append(PackAvg.ToString("0.0", invariantCulture));
		stringBuilder.Append(",\n  \"packFastest\": ").Append(((Packs > 0) ? PackFastest : 0.0).ToString("0.0", invariantCulture));
		stringBuilder.Append(",\n  \"packSlowest\": ").Append(PackSlowest.ToString("0.0", invariantCulture));
		stringBuilder.Append(",\n  \"packLast\": ").Append(PackLast.ToString("0.0", invariantCulture));
		stringBuilder.Append(",\n  \"packKills\": ").Append((Packs > 0) ? ((double)PackKills / (double)Packs).ToString("0.0", invariantCulture) : "0");
		stringBuilder.Append(",\n  \"killsPerHourRecent\": ").Append(((long)Math.Round(KillsPerHourRecent)).ToString(invariantCulture));
		stringBuilder.Append(",\n  \"deaths\": ").Append(cur.Deaths);
		stringBuilder.Append(",\n  \"corpses\": ").Append(cur.Corpses);
		stringBuilder.Append(",\n  \"corpsesKept\": ").Append(cur.CorpsesKept);
		stringBuilder.Append(",\n  \"lootItems\": ").Append(cur.LootItems);
		stringBuilder.Append(",\n  \"lootArmor\": ").Append(cur.LootArmor);
		stringBuilder.Append(",\n  \"lootClothing\": ").Append(cur.LootClothing);
		stringBuilder.Append(",\n  \"lootJewelry\": ").Append(cur.LootJewelry);
		stringBuilder.Append(",\n  \"lootWeapons\": ").Append(cur.LootWeapons);
		stringBuilder.Append(",\n  \"lootMisc\": ").Append(cur.LootMisc);
		try
		{
			NearbyPlayers.AppendJson(stringBuilder, Q);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		try
		{
			PackStats.AppendJson(stringBuilder, Q);
		}
		catch (Exception ex2)
		{
			Util.LogError(ex2);
		}
		stringBuilder.Append(",\n  \"mobs\": [");
		bool flag = true;
		List<MobStat> list = new List<MobStat>(cur.Mobs.Values);
		list.Sort((MobStat x, MobStat y) => y.Kills.CompareTo(x.Kills));
		foreach (MobStat item in list)
		{
			string text = "";
			try
			{
				text = SpeciesNameOf(item);
			}
			catch
			{
			}
			stringBuilder.Append(flag ? "\n    " : ",\n    ");
			flag = false;
			stringBuilder.Append("{\"name\": ").Append(Q(item.Name)).Append(", \"species\": ")
				.Append(Q(text ?? ""))
				.Append(", \"kills\": ")
				.Append(item.Kills)
				.Append(", \"avg\": ")
				.Append(item.Avg.ToString("0.0", invariantCulture))
				.Append(", \"fastest\": ")
				.Append(((item.Fastest == double.MaxValue) ? 0.0 : item.Fastest).ToString("0.0", invariantCulture))
				.Append(", \"slowest\": ")
				.Append(item.Slowest.ToString("0.0", invariantCulture))
				.Append(", \"out\": ")
				.Append(PackStats.IsOut(item.Name) ? "true" : "false")
				.Append('}');
		}
		stringBuilder.Append("\n  ],\n  \"popup\": [");
		flag = true;
		foreach (string item2 in PopupLines())
		{
			stringBuilder.Append(flag ? "\n    " : ",\n    ");
			flag = false;
			stringBuilder.Append(Q(item2));
		}
		stringBuilder.Append("\n  ],\n  \"buffs\": ").Append(BuffJson());
		DateTime dateTime = DateTime.MinValue;
		foreach (BankLine item3 in _bank)
		{
			if (item3.At > dateTime)
			{
				dateTime = item3.At;
			}
		}
		stringBuilder.Append(",\n  \"bank\": {\"at\": ").Append(Q((dateTime == DateTime.MinValue) ? "" : dateTime.ToUniversalTime().ToString("o"))).Append(", \"rows\": [");
		bool flag2 = true;
		foreach (BankLine item4 in BankSorted())
		{
			stringBuilder.Append(flag2 ? "" : ", ").Append('[').Append(Q(item4.Name))
				.Append(", ")
				.Append(Q(item4.Value))
				.Append(']');
			flag2 = false;
		}
		stringBuilder.Append("]},\n  \"augs\": {\"at\": ").Append(Q((_augsAt == DateTime.MinValue) ? "" : _augsAt.ToUniversalTime().ToString("o"))).Append(", \"rows\": [");
		flag2 = true;
		foreach (KeyValuePair<string, string> aug in AugRowsWithHunt())
		{
			stringBuilder.Append(flag2 ? "" : ", ").Append('[').Append(Q(aug.Key))
				.Append(", ")
				.Append(Q(aug.Value))
				.Append(']');
			flag2 = false;
		}
		stringBuilder.Append("]}");
		long value = BankCount("Prestige Coins");
		stringBuilder.Append(",\n  \"charms\": {\"prestigeCoins\": ").Append(value).Append(", \"rows\": [");
		flag2 = true;
		try
		{
			foreach (string[] item5 in Charms.Summary())
			{
				stringBuilder.Append(flag2 ? "" : ", ").Append('[');
				for (int num3 = 0; num3 < item5.Length; num3++)
				{
					stringBuilder.Append((num3 > 0) ? ", " : "").Append(Q(item5[num3]));
				}
				stringBuilder.Append(']');
				flag2 = false;
			}
		}
		catch (Exception ex3)
		{
			Util.LogError(ex3);
		}
		stringBuilder.Append("]}");
		stringBuilder.Append(",\n  \"loot\": [");
		flag = true;
		foreach (LootRec item6 in Looted)
		{
			stringBuilder.Append(flag ? "\n    " : ",\n    ");
			flag = false;
			stringBuilder.Append("{\"time\": ").Append(Q(item6.At.ToUniversalTime().ToString("o"))).Append(", \"rule\": ")
				.Append(Q(item6.Rule))
				.Append(", \"cat\": ")
				.Append(Q(item6.Cat))
				.Append(", \"id\": ")
				.Append(Q(item6.Desc));
			if (item6.Vs.Length > 0)
			{
				stringBuilder.Append(", \"vs\": ").Append(Q(item6.Vs)).Append(", \"vsColor\": ")
					.Append(item6.VsColor);
			}
			stringBuilder.Append('}');
		}
		stringBuilder.Append("\n  ]\n}\n");
		return stringBuilder.ToString();
	}

	private static string BuffJson()
	{
		CultureInfo inv = CultureInfo.InvariantCulture;
		StringBuilder b = new StringBuilder("{");
		try
		{
			MelkTank.Buffs.Buffer bf = PluginCore.CurrentEngine?.Buffer;
			if (bf == null)
			{
				return "{}";
			}
			b.Append("\"enabled\": ").Append(bf.Enabled ? "true" : "false").Append(", \"busy\": ")
				.Append(bf.Busy ? "true" : "false")
				.Append(", \"paused\": ")
				.Append(bf.Paused ? "true" : "false")
				.Append(", \"status\": ")
				.Append(Q(bf.Status ?? ""))
				.Append(", \"rebuffMin\": ")
				.Append(bf.RebuffMinutes)
				.Append(", \"rows\": [");
			bool first = true;
			Action<string, string, double, bool> action = (string name, string kind, double left, bool off) =>
			{
				b.Append(first ? "\n    " : ",\n    ");
				first = false;
				b.Append("{\"n\": ").Append(Q(name)).Append(", \"k\": ")
					.Append(Q(kind))
					.Append(", \"left\": ")
					.Append(Math.Max(0.0, left).ToString("0", inv))
					.Append(", \"rebuffIn\": ")
					.Append((left - bf.RebuffSeconds).ToString("0", inv))
					.Append(", \"off\": ")
					.Append(off ? "true" : "false")
					.Append('}');
			};
			action("Creature Enchantment Mastery", "Creature", MelkTank.Buffs.Buffer.GetSpellRemaining(4530), !bf.MasteryTriggers);
			foreach (SpellGem spellGem in bf.SpellGems)
			{
				bool arg = !bf.SpellGemsEnabled || !spellGem.Enabled;
				if (!spellGem.Learned || spellGem.SpellIds.Count == 0)
				{
					action(spellGem.Name, "Gem (not learned yet)", 0.0, arg);
					continue;
				}
				double num = double.MaxValue;
				foreach (int spellId in spellGem.SpellIds)
				{
					num = Math.Min(num, MelkTank.Buffs.Buffer.GetSpellRemaining(spellId));
				}
				action(spellGem.Name, "Gem", (num == double.MaxValue) ? 0.0 : num, arg);
			}
			b.Append("\n  ]");
		}
		catch
		{
			return "{}";
		}
		return b.Append('}').ToString();
	}

	private static string SpeciesNameOf(MobStat m)
	{
		int num = m.Species;
		if (num <= 0)
		{
			try
			{
				num = GameInfo.SpeciesByName(m.Name);
			}
			catch
			{
			}
			if (num > 0)
			{
				m.Species = num;
			}
		}
		return (num > 0) ? MonsterMatch.SpeciesName(num) : "";
	}

	private static List<string> PopupLines()
	{
		List<string> list = BountyHud.PhoneLines(PluginCore.CurrentSettings);
		for (int i = 0; i < list.Count; i++)
		{
			if (!list[i].StartsWith("B|"))
			{
				continue;
			}
			string[] array = list[i].Split('|');
			if (array.Length >= 4 && array[3].Trim().Length != 0)
			{
				long num = RewardCount(array[3]);
				if (num >= 0)
				{
					list[i] = list[i] + "|" + num.ToString(CultureInfo.InvariantCulture);
				}
			}
		}
		return list;
	}

	private static void NoteBountyLine(string text)
	{
		string text2 = (text ?? "").Replace("\r", "").Trim();
		if (!text2.StartsWith("Bounty", StringComparison.OrdinalIgnoreCase))
		{
			return;
		}
		Match match = BountyLockedRx.Match(text2);
		SeenBounty seenBounty = null;
		if (match.Success)
		{
			TimeSpan zero = TimeSpan.Zero;
			foreach (Match item in SpanPartRx.Matches(match.Groups["time"].Value))
			{
				int num = int.Parse(item.Groups["n"].Value);
				zero += char.ToLowerInvariant(item.Groups["u"].Value[0]) switch
				{
					'm' => TimeSpan.FromMinutes(num), 
					'h' => TimeSpan.FromHours(num), 
					'd' => TimeSpan.FromDays(num), 
					_ => TimeSpan.FromSeconds(num), 
				};
			}
			seenBounty = new SeenBounty
			{
				UnlocksAt = DateTime.Now + zero,
				Need = ParseInt(match.Groups["need"].Value)
			};
		}
		else if ((match = BountyHereRx.Match(text2)).Success)
		{
			seenBounty = new SeenBounty
			{
				Have = ParseInt(match.Groups["have"].Value),
				Need = ParseInt(match.Groups["need"].Value)
			};
		}
		if (seenBounty != null)
		{
			seenBounty.Zone = match.Groups["zone"].Value.Trim();
			seenBounty.Reward = match.Groups["reward"].Value.Trim();
			seenBounty.At = DateTime.Now;
			_bounties[seenBounty.Zone + "|" + seenBounty.Reward] = seenBounty;
		}
	}

	private static int ParseInt(string s)
	{
		int result;
		return int.TryParse((s ?? "").Replace(",", ""), out result) ? result : 0;
	}

	private static List<string> OwnBountyLines()
	{
		List<string> list = new List<string>();
		foreach (SeenBounty value in _bounties.Values)
		{
			if ((DateTime.Now - value.At).TotalMinutes > 3.0)
			{
				continue;
			}
			string text;
			if (value.Zone.Length != 0)
			{
				text = (value.Zone.Equals("all zones", StringComparison.OrdinalIgnoreCase) ? "All zones" : value.Zone);
			}
			else
			{
				text = "This area";
			}
			string text2;
			if (value.UnlocksAt != DateTime.MinValue)
			{
				TimeSpan timeSpan = value.UnlocksAt - DateTime.Now;
				text2 = ((timeSpan <= TimeSpan.Zero) ? "unlocking..." : ("unlocks in " + ((timeSpan.TotalHours >= 1.0) ? ((int)timeSpan.TotalHours + ":" + timeSpan.Minutes.ToString("00") + ":" + timeSpan.Seconds.ToString("00")) : (timeSpan.Minutes + ":" + timeSpan.Seconds.ToString("00")))));
			}
			else
			{
				text2 = value.Have.ToString("N0") + " / " + value.Need.ToString("N0");
				string text3 = BountyEta(text2);
				if (text3.Length > 0)
				{
					text2 = text2 + "  (" + text3 + " to go)";
				}
			}
			string text4 = "B|" + text + "|" + text2 + "|" + value.Reward;
			long num = RewardCount(value.Reward);
			if (num >= 0)
			{
				text4 = text4 + "|" + num.ToString(CultureInfo.InvariantCulture);
			}
			list.Add(text4);
		}
		return list;
	}

	private static string BountyEta(string count)
	{
		Match match = HaveNeedRx.Match(count ?? "");
		if (!match.Success)
		{
			return "";
		}
		int num = Math.Max(0, ParseInt(match.Groups[2].Value) - ParseInt(match.Groups[1].Value));
		if (num == 0)
		{
			return "0:00";
		}
		double killsPerHourRecent = KillsPerHourRecent;
		if (killsPerHourRecent <= 0.0)
		{
			return "";
		}
		int num2 = (int)Math.Ceiling((double)num / (killsPerHourRecent / 60.0));
		return num2 / 60 + ":" + (num2 % 60).ToString("00");
	}

	private static long RewardCount(string reward)
	{
		string s = Regex.Replace(reward.Trim(), "^[\\d,]+\\s*x?\\s+", "");
		string text = Loose(s);
		if (text.Length == 0)
		{
			return -1L;
		}
		long num = 0L;
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (Loose(item.Name) == text)
				{
					num += Math.Max(1, item.Values(LongValueKey.StackCount, 1));
				}
			}
		}
		catch
		{
			return -1L;
		}
		return num;
	}

	private static string Loose(string s)
	{
		List<string> list = new List<string>();
		string[] array = (s ?? "").ToLowerInvariant().Split(new char[1] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
		foreach (string text in array)
		{
			list.Add((text.Length > 3 && text.EndsWith("s") && !text.EndsWith("ss")) ? text.Substring(0, text.Length - 1) : text);
		}
		return string.Join(" ", list.ToArray());
	}

	private static string Q(string s)
	{
		StringBuilder stringBuilder = new StringBuilder("\"");
		string text = s ?? "";
		foreach (char c in text)
		{
			if (c == '"')
			{
				stringBuilder.Append("\\\"");
			}
			else if (c == '\\')
			{
				stringBuilder.Append("\\\\");
			}
			else if (c < ' ')
			{
				StringBuilder stringBuilder2 = stringBuilder.Append("\\u");
				int num = c;
				stringBuilder2.Append(num.ToString("x4"));
			}
			else
			{
				stringBuilder.Append(c);
			}
		}
		return stringBuilder.Append('"').ToString();
	}

	/// <summary>/bank, its answer kept out of chat (Session > Lum's coins by the bank).</summary>
	public static void QuietBank()
	{
		QuietNext("/bank");
		Util.Command("/bank");
	}

	public static void Reset()
	{
		LumTrack.Reset();
		Cur.Clear();
		_recent.Clear();
		ResetPacks();
		try
		{
			PackStats.Reset();
		}
		catch
		{
		}
		FractureReset();
		CoinsReset();
		_lumEarned = 0L;
		_tokGot = 0L;
		_tokBase = -1L;
		_tokHeld = 0L;
		_xpStart = XpNow();
		_samples.Clear();
		_nextSample = DateTime.MinValue;
		_ratesAt = DateTime.MinValue;
		Looted.Clear();
		_gone.Clear();
		_corpses.Clear();
		_killLineAt = DateTime.MinValue;
	}

	public static void ResetAll()
	{
		All.Clear();
		_playedMark = DateTime.Now;
		SaveAll();
	}

	public static void LoggedIn()
	{
		Reset();
		try
		{
			CharacterFilter characterFilter = CoreManager.Current.CharacterFilter;
			string text = characterFilter.Server + "-" + characterFilter.Name;
			char[] invalidFileNameChars = Path.GetInvalidFileNameChars();
			foreach (char oldChar in invalidFileNameChars)
			{
				text = text.Replace(oldChar, '_');
			}
			_file = Util.FullPath("MelkTank_Stats_" + text + ".txt");
			_bankFile = Util.FullPath("MelkTank_Bank_" + text + ".txt");
			_augFile = Util.FullPath("MelkTank_Augs_" + text + ".txt");
			_gemCredits = -1;
			DeedsLoggedIn(text);
			MkStop("logged in");
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			_file = null;
		}
		LoadAll();
		LoadBank();
		LoadAugs();
		LoadCarry();
		_playedMark = DateTime.Now;
		if (_hooked)
		{
			return;
		}
		try
		{
			CoreManager.Current.WorldFilter.CreateObject += OnCreate;
			_hooked = true;
		}
		catch (Exception ex2)
		{
			Util.LogError(ex2);
		}
	}

	public static void LoggedOut()
	{
		SaveAll();
		if (_hooked)
		{
			try
			{
				CoreManager.Current.WorldFilter.CreateObject -= OnCreate;
			}
			catch
			{
			}
			_hooked = false;
		}
	}

	public static void ObjectGone(WorldObject o, TrackedMonster tm)
	{
		try
		{
			if (o == null || tm == null)
			{
				return;
			}
			double num = CombatEngine.Distance(o);
			if (num > 60.0)
			{
				return;
			}
			int species = 0;
			try
			{
				species = GameInfo.Species(o);
			}
			catch
			{
			}
			bool flag = tm.EngagedAt == DateTime.MinValue;
			Gone gone = new Gone
			{
				Name = (tm.Name ?? o.Name),
				Species = species,
				EngagedAt = (flag ? NearbyTimerStart(o, tm.FirstSeen) : tm.EngagedAt),
				At = DateTime.Now,
				Unengaged = flag
			};
			if (flag)
			{
				if (TakeKillText(gone.Name, gone.At) || PetKilled(gone))
				{
					Count(gone);
				}
				else
				{
					_gone.Add(gone);
				}
				return;
			}
			for (int i = 0; i < _corpses.Count; i++)
			{
				if (string.Equals(_corpses[i].Name, gone.Name, StringComparison.OrdinalIgnoreCase))
				{
					_corpses.RemoveAt(i);
					Count(gone);
					return;
				}
			}
			_gone.Add(gone);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void OnCreate(object sender, CreateObjectEventArgs e)
	{
		try
		{
			WorldObject worldObject = e.New;
			if (worldObject == null || worldObject.ObjectClass != ObjectClass.Corpse || worldObject.Name == null || !worldObject.Name.StartsWith("Corpse of "))
			{
				return;
			}
			string text = worldObject.Name.Substring(10).Trim();
			string b = "";
			try
			{
				b = CoreManager.Current.CharacterFilter.Name ?? "";
			}
			catch
			{
			}
			if (string.Equals(text, b, StringComparison.OrdinalIgnoreCase))
			{
				return;
			}
			double num = CombatEngine.Distance(worldObject);
			if (num > 60.0)
			{
				return;
			}
			for (int i = 0; i < _gone.Count; i++)
			{
				if (!_gone[i].Unengaged && string.Equals(_gone[i].Name, text, StringComparison.OrdinalIgnoreCase))
				{
					Gone g = _gone[i];
					_gone.RemoveAt(i);
					Count(g);
					return;
				}
			}
			_corpses.Add(new Corpse
			{
				Name = text,
				At = DateTime.Now
			});
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void NoteBank(string text)
	{
		Match match = BankRx.Match(text.Trim());
		if (match.Success)
		{
			string n = match.Groups["n"].Value.Trim();
			string value = match.Groups["v"].Value.Trim();
			BankLine bankLine = _bank.Find((BankLine x) => string.Equals(x.Name, n, StringComparison.OrdinalIgnoreCase));
			if (bankLine == null)
			{
				bankLine = new BankLine
				{
					Name = n
				};
				_bank.Add(bankLine);
			}
			bankLine.Value = value;
			bankLine.At = DateTime.Now;
			_bankDirtyAt = DateTime.Now;
			if (string.Equals(n, "Enlightened Coins", StringComparison.OrdinalIgnoreCase))
			{
				LumTrack.BankCoins(BankCount("Enlightened Coins"));
			}
			if (string.Equals(n, "Luminance", StringComparison.OrdinalIgnoreCase))
			{
				LumTrack.BankLum(BankLuminance());
			}
		}
	}

	private static int BankRank(string name)
	{
		string text = (name ?? "").ToLowerInvariant();
		if (text.Contains("weakly"))
		{
			return 2;
		}
		if (text.Contains("luminance"))
		{
			return 0;
		}
		if (text.Contains("enlightened coin"))
		{
			return 1;
		}
		if (text.Contains("pyreal"))
		{
			return 3;
		}
		if (text.Contains("enlightenment token"))
		{
			return 4;
		}
		if (text.Contains("prestige"))
		{
			return 5;
		}
		if (text.Contains("mythic"))
		{
			return 6;
		}
		if (text.Contains("legendary") || text.StartsWith("leg "))
		{
			return 7;
		}
		return 100;
	}

	private static List<BankLine> BankSorted()
	{
		List<BankLine> list = new List<BankLine>(_bank);
		List<KeyValuePair<int, BankLine>> list2 = new List<KeyValuePair<int, BankLine>>();
		for (int i = 0; i < list.Count; i++)
		{
			list2.Add(new KeyValuePair<int, BankLine>(i, list[i]));
		}
		list2.Sort((KeyValuePair<int, BankLine> a, KeyValuePair<int, BankLine> b) =>
		{
			int num = BankRank(a.Value.Name).CompareTo(BankRank(b.Value.Name));
			return (num != 0) ? num : a.Key.CompareTo(b.Key);
		});
		return list2.ConvertAll((KeyValuePair<int, BankLine> x) => x.Value);
	}

	private static void NoteAugs(string text)
	{
		string[] array = text.Replace("\r", "").Split('\n');
		foreach (string text2 in array)
		{
			string text3 = text2.Trim();
			if (text3.Length == 0 || text3.Trim('-').Length == 0)
			{
				continue;
			}
			bool capturing = DateTime.Now <= _augCaptureUntil;
			// (the list starts with its title - or, since T11+'s change, may start straight at "Creature: N")
			bool header = text3.StartsWith("Advanced Augmentation Levels", StringComparison.OrdinalIgnoreCase);
			bool firstRow = !capturing && Regex.IsMatch(text3, "^Creature:\\s*[\\d,]+$");
			if (header || firstRow)
			{
				_augs.Clear();
				_augHunt.Clear();
				_augInHunt = false;
				_augHuntResetAt = DateTime.MinValue;
				_augsAt = DateTime.Now;
				_augCaptureUntil = DateTime.Now.AddSeconds(3.0);
				_augDirtyAt = DateTime.Now;
				if (header)
				{
					continue;
				}
				capturing = true;
			}
			if (!capturing)
			{
				continue;
			}
			if (AugHuntLineRx.IsMatch(text3) || (_augInHunt && text3.IndexOf("<- you are here", StringComparison.OrdinalIgnoreCase) >= 0))
			{
				_augInHunt = true;
				// ("Hunting rewards this week:" is just the title; "Hunting rewards: they start once..." says why there are none)
				if (!text3.StartsWith("Hunting rewards", StringComparison.OrdinalIgnoreCase) || !text3.TrimEnd().EndsWith(":"))
				{
					_augHunt.Add(text3);
				}
				if (text3.StartsWith("Kills this week", StringComparison.OrdinalIgnoreCase))
				{
					_augKillsSince = 0;   // (the server's count from here: MelkTank's kills add on till the next /aug)
				}
				Match m = AugResetInRx.Match(text3);
				if (text3.StartsWith("Week resets", StringComparison.OrdinalIgnoreCase) && m.Success)
				{
					int.TryParse(m.Groups["d"].Value, out var d);
					int.TryParse(m.Groups["h"].Value, out var h);
					int.TryParse(m.Groups["m"].Value, out var mi);
					_augHuntResetAt = DateTime.Now.AddDays(d).AddHours(h).AddMinutes(mi);
				}
				_augCaptureUntil = DateTime.Now.AddSeconds(3.0);
				_augDirtyAt = DateTime.Now;
				continue;
			}
			Match match = (_augInHunt ? AugNumberRowRx : AugLineRx).Match(text3);
			if (!match.Success)
			{
				_augCaptureUntil = DateTime.MinValue;
				_augInHunt = false;
				continue;
			}
			_augInHunt = false;
			_augs.Add(new KeyValuePair<string, string>(match.Groups["n"].Value.Trim(), match.Groups["v"].Value.Trim()));
			_augCaptureUntil = DateTime.Now.AddSeconds(3.0);
			_augDirtyAt = DateTime.Now;
		}
	}

	/// <summary>"This tier so far" from /aug: each augmentation's count and where this tier ends (Creature -> (4501, 5000)).</summary>
	private static Dictionary<string, KeyValuePair<long, long>> AugTierSoFar()
	{
		var d = new Dictionary<string, KeyValuePair<long, long>>(StringComparer.OrdinalIgnoreCase);
		string line = _augHunt.Find(l => l.StartsWith("This tier so far", StringComparison.OrdinalIgnoreCase));
		if (line == null) return d;
		foreach (Match m in AugTierSoFarRx.Matches(line))
		{
			if (long.TryParse(m.Groups["v"].Value.Replace(",", ""), out var v) && long.TryParse(m.Groups["c"].Value.Replace(",", ""), out var c))
				d[m.Groups["n"].Value] = new KeyValuePair<long, long>(v, c);
		}
		return d;
	}

	private static string AugResetText()
	{
		if (_augHuntResetAt == DateTime.MinValue) return "";
		TimeSpan left = _augHuntResetAt - DateTime.Now;
		if (left.TotalMinutes < 1) return "the weekly reset has passed - Check /aug";
		string i = left.TotalDays >= 1 ? $"{(int)left.TotalDays}d {left.Hours}h" : left.TotalHours >= 1 ? $"{(int)left.TotalHours}h {left.Minutes}m" : $"{left.Minutes}m";
		return $"{_augHuntResetAt:ddd h:mm tt} (in {i})";
	}

	public static void QuietNext(string command)
	{
		string text = (command ?? "").Trim().ToLowerInvariant();
		if (text == "/bank")
		{
			_quietBankUntil = DateTime.Now.AddSeconds(8.0);
		}
		else if (text == "/aug" || text.StartsWith("/aug "))
		{
			_quietAugUntil = DateTime.Now.AddSeconds(8.0);
		}
		else
		{
			QuietNextDeeds(text);
		}
	}

	public static bool Quiet(string text)
	{
		if (string.IsNullOrEmpty(text))
		{
			return false;
		}
		string text2 = text.TrimStart();
		if (QuietDeeds(text2))
		{
			return true;
		}
		if (QuietPace(text2))
		{
			return true;
		}
		if (AttrQuiet(text2))
		{
			return true;
		}
		if (DateTime.Now <= _quietBankUntil && text2.Trim().Length > 0 && text2.Trim().Trim('-').Length == 0)
		{
			return true;
		}
		if (DateTime.Now <= _quietBankUntil && text2.StartsWith("[BANK]", StringComparison.OrdinalIgnoreCase))
		{
			_quietBankUntil = DateTime.Now.AddSeconds(2.0);
			return true;
		}
		if (DateTime.Now <= _quietAugUntil)
		{
			string text3 = text2.Trim();
			if (text3.Length > 0 && text3.Trim('-').Length == 0)
			{
				return true;
			}
			if (text2.IndexOf("Advanced Augmentation Levels", StringComparison.OrdinalIgnoreCase) >= 0 || (DateTime.Now > _augCaptureUntil && Regex.IsMatch(text2.Trim(), "^Creature:\\s*[\\d,]+$")))
			{
				_quietAugUntil = DateTime.Now.AddSeconds(2.0);
				return true;
			}
			if (DateTime.Now <= _augCaptureUntil && (text2.Trim().Trim('-').Length == 0 || AugLineRx.IsMatch(text2.Trim()) || AugHuntLineRx.IsMatch(text2.Trim()) || text2.IndexOf("<- you are here", StringComparison.OrdinalIgnoreCase) >= 0))
			{
				_quietAugUntil = DateTime.Now.AddSeconds(2.0);
				return true;
			}
		}
		return false;
	}

	private static void AugFileTick()
	{
		if (_augDirtyAt == DateTime.MinValue || (DateTime.Now - _augDirtyAt).TotalSeconds < 4.0 || _augFile == null)
		{
			return;
		}
		_augDirtyAt = DateTime.MinValue;
		try
		{
			StringBuilder stringBuilder = new StringBuilder("# MelkTank: the last /aug list for this character (Session > Augs)\r\n@" + _augsAt.Ticks + "\r\n");
			foreach (KeyValuePair<string, string> aug in _augs)
			{
				stringBuilder.Append(aug.Key.Replace("\t", " ")).Append('\t').Append(aug.Value.Replace("\t", " "))
					.Append("\r\n");
			}
			if (_augHuntResetAt != DateTime.MinValue)
			{
				stringBuilder.Append("~reset\t").Append(_augHuntResetAt.Ticks).Append("\r\n");
			}
			foreach (string h in _augHunt)
			{
				stringBuilder.Append("~hunt\t").Append(h.Replace("\t", " ")).Append("\r\n");
			}
			Util.WriteShared(_augFile, stringBuilder.ToString());
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void LoadAugs()
	{
		_augs.Clear();
		_augHunt.Clear();
		_augHuntResetAt = DateTime.MinValue;
		_augsAt = DateTime.MinValue;
		if (_augFile == null || !File.Exists(_augFile))
		{
			return;
		}
		try
		{
			string[] array = Util.Locked(_augFile, () => File.ReadAllLines(_augFile));
			foreach (string text in array)
			{
				if (text.StartsWith("#"))
				{
					continue;
				}
				if (text.StartsWith("@") && long.TryParse(text.Substring(1), out var result))
				{
					_augsAt = new DateTime(result);
					continue;
				}
				string[] array2 = text.Split('\t');
				if (array2.Length >= 2 && array2[0] == "~hunt")
				{
					_augHunt.Add(array2[1]);
				}
				else if (array2.Length >= 2 && array2[0] == "~reset")
				{
					if (long.TryParse(array2[1], out var rt)) _augHuntResetAt = new DateTime(rt);
				}
				else if (array2.Length >= 2)
				{
					_augs.Add(new KeyValuePair<string, string>(array2[0], array2[1]));
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void DrawCreditsRow()
	{
		ImGui.TableNextRow();
		ImGui.TableSetColumnIndex(0);
		Im.TextColored(Cyan, "Skill Credits (gems)");
		if (ImGui.IsItemHovered()) Im.SetTooltip("Not in /aug: counted as each Skill Credit Gem is used (/mtank credits N to set it).");
		ImGui.TableSetColumnIndex(1);
		ImGui.TextUnformatted(CreditsBought().ToString("N0"));
	}

	private static void DrawAugs()
	{
		if (ImGui.Button("Check /aug"))
		{
			QuietNext("/aug");
			Util.Command("/aug");
		}
		if (_augs.Count == 0)
		{
			Im.TextDisabled("Nothing yet - click Check /aug.");
			return;
		}
		ImGui.SameLine();
		Im.TextDisabled("as of " + ((_augsAt.Date == DateTime.Today) ? _augsAt.ToString("HH:mm") : _augsAt.ToString("MM-dd HH:mm")));
		if (!ImGui.BeginTable("auglist", 2, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
		{
			return;
		}
		ImGui.TableSetupColumn("Augmentation", ImGuiTableColumnFlags.WidthFixed, 200f);
		ImGui.TableSetupColumn("Level", ImGuiTableColumnFlags.WidthStretch);
		ImGui.TableHeadersRow();
		bool creditsShown = false;
		var soFar = AugTierSoFar();
		foreach (KeyValuePair<string, string> aug in _augs)
		{
			ImGui.TableNextRow();
			ImGui.TableSetColumnIndex(0);
			Im.TextColored(Cyan, aug.Key);
			ImGui.TableSetColumnIndex(1);
			ImGui.TextUnformatted(aug.Value);
			// (T11+: how far into this tier's +500 - its end is where hunting stops adding till you move up)
			if (soFar.TryGetValue(aug.Key, out var t))
			{
				ImGui.SameLine();
				if (t.Key >= t.Value) Im.TextColored(AugGreen, "  tier's end reached (" + t.Value.ToString("N0") + ") - move up a tier");
				else Im.TextDisabled("  of " + t.Value.ToString("N0") + " this tier (" + (t.Value - t.Key).ToString("N0") + " to go)");
			}
			// (skill credits from gems: /aug doesn't list them - shown under Specialization, from the count kept here)
			if (!creditsShown && aug.Key.StartsWith("Specialization", StringComparison.OrdinalIgnoreCase))
			{
				creditsShown = true;
				DrawCreditsRow();
			}
		}
		if (!creditsShown)
		{
			DrawCreditsRow();
		}
		ImGui.EndTable();
		DrawAugHunt();
	}

	/// <summary>The augs list with /aug's hunting part after it, as rows (for the phone).</summary>
	private static List<KeyValuePair<string, string>> AugRowsWithHunt()
	{
		var rows = new List<KeyValuePair<string, string>>(_augs);
		foreach (var kv in AugHuntRows()) rows.Add(kv);
		return rows;
	}

	/// <summary>/aug's hunting rewards, boiled down: kills this week, the rate you're on and how long it lasts, the reset.</summary>
	private static List<KeyValuePair<string, string>> AugHuntRows()
	{
		var rows = new List<KeyValuePair<string, string>>();
		if (_augHunt.Count == 0) return rows;
		string kills = _augHunt.Find(l => l.StartsWith("Kills this week", StringComparison.OrdinalIgnoreCase));
		if (kills == null)
		{
			// (below T11: "Hunting rewards: they start once you can fight in the T11 lands.")
			string why = _augHunt.Find(l => l.StartsWith("Hunting rewards", StringComparison.OrdinalIgnoreCase));
			if (why != null) rows.Add(new KeyValuePair<string, string>("Hunting rewards", why.Substring(why.IndexOf(':') + 1).Trim()));
			return rows;
		}
		rows.Add(new KeyValuePair<string, string>("Kills this week", kills.Substring(kills.IndexOf(':') + 1).Trim() + (_augKillsSince > 0 ? " (+" + _augKillsSince + " since)" : "")));
		int toGo = AugKillsLeft(out int _);
		if (toGo > 0) rows.Add(new KeyValuePair<string, string>("Next aug", toGo.ToString("N0") + " kills"));
		else if (toGo == -2) rows.Add(new KeyValuePair<string, string>("Next aug", "none left this week"));
		string here = _augHunt.Find(l => l.IndexOf("<- you are here", StringComparison.OrdinalIgnoreCase) >= 0);
		if (here != null)
		{
			Match rate = Regex.Match(here, "1 reward per ([\\d,]+) kills", RegexOptions.IgnoreCase);
			Match left = Regex.Match(here, "\\(([\\d,]+) kills left\\)", RegexOptions.IgnoreCase);
			if (rate.Success) rows.Add(new KeyValuePair<string, string>("Hunting reward", "1 per " + rate.Groups[1].Value + " kills" + (left.Success ? " (this rate for " + left.Groups[1].Value + " more)" : "")));
			else rows.Add(new KeyValuePair<string, string>("Hunting reward", here.Replace("<- you are here", "").Trim()));
		}
		else if (_augHunt.Exists(l => l.StartsWith("Beyond", StringComparison.OrdinalIgnoreCase)) && kills != null)
		{
			// (no "you are here" line at all: past the last step)
		}
		string reset = AugResetText();
		if (reset.Length > 0) rows.Add(new KeyValuePair<string, string>("Week resets", reset));
		return rows;
	}

	private static void DrawAugHunt()
	{
		if (_augHunt.Count == 0) return;
		ImGui.Spacing();
		Im.TextColored(AugYellow, "Hunting rewards this week");
		if (ImGui.IsItemHovered()) Im.SetTooltip("T11+: kills in your own tier (giving XP or luminance, you the top damager - pets count) add 1 to Creature, Item or Life at random.\nAttack school gems (War/Void/Melee/Missile) drop on their own - double click one for +1.");
		foreach (var kv in AugHuntRows())
		{
			Im.TextColored(Cyan, kv.Key + ":");
			ImGui.SameLine();
			ImGui.TextUnformatted(kv.Value);
		}
		// the steps, as /aug gives them
		foreach (string l in _augHunt)
		{
			if (l.StartsWith("First", StringComparison.OrdinalIgnoreCase) || l.StartsWith("After", StringComparison.OrdinalIgnoreCase) || l.StartsWith("Beyond", StringComparison.OrdinalIgnoreCase))
			{
				bool here = l.IndexOf("<- you are here", StringComparison.OrdinalIgnoreCase) >= 0;
				string t = "   " + Regex.Replace(l.Replace("<- you are here", ""), "\\s{2,}", "  ").Trim();
				if (here) Im.TextColored(AugGreen, t + "   <- now");
				else Im.TextDisabled(t);
			}
		}
	}

	private static void BankFileTick()
	{
		if (_bankDirtyAt == DateTime.MinValue || (DateTime.Now - _bankDirtyAt).TotalSeconds < 3.0 || _bankFile == null)
		{
			return;
		}
		_bankDirtyAt = DateTime.MinValue;
		try
		{
			StringBuilder stringBuilder = new StringBuilder("# MelkTank: the last /bank lines for this character (Session > Bank)\r\n");
			foreach (BankLine item in _bank)
			{
				stringBuilder.Append(item.Name.Replace("\t", " ")).Append('\t').Append(item.Value.Replace("\t", " "))
					.Append('\t')
					.Append(item.At.Ticks)
					.Append("\r\n");
			}
			Util.WriteShared(_bankFile, stringBuilder.ToString());
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void LoadBank()
	{
		_bank.Clear();
		if (_bankFile == null || !File.Exists(_bankFile))
		{
			return;
		}
		try
		{
			string[] array = Util.Locked(_bankFile, () => File.ReadAllLines(_bankFile));
			foreach (string text in array)
			{
				if (!text.StartsWith("#"))
				{
					string[] array2 = text.Split('\t');
					if (array2.Length >= 3 && long.TryParse(array2[2], out var result))
					{
						_bank.Add(new BankLine
						{
							Name = array2[0],
							Value = array2[1],
							At = new DateTime(result)
						});
					}
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void DrawBank()
	{
		if (ImGui.Button("Check /bank"))
		{
			QuietNext("/bank");
			Util.Command("/bank");
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Asks the server for your bank (the lines may be hidden in chat by the chat filter - they're still read here).");
		}
		// (polling the bank: Session > Lum > Settings now - one poller for the bank tab, lum/hr and coins/hr)
		Settings bs = PluginCore.CurrentSettings;
		DateTime dateTime = DateTime.MinValue;
		foreach (BankLine item in _bank)
		{
			if (item.At > dateTime)
			{
				dateTime = item.At;
			}
		}
		if (_bank.Count > 0)
		{
			ImGui.SameLine();
			Im.TextDisabled("as of " + ((dateTime.Date == DateTime.Today) ? dateTime.ToString("HH:mm") : dateTime.ToString("MM-dd HH:mm")));
		}
		ImGui.SameLine();
		if (ImGui.Button("/b d##bankdep"))
		{
			Util.Command("/b d");
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("/b d - puts what you carry that the bank takes (pyreals, luminance, coins, keys...) into the bank.");
		}
		ImGui.SameLine();
		if (ImGui.Button("/clap all##bankclap"))
		{
			Util.Command("/clap all");
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Sends /clap all.");
		}
		if (bs != null)
		{
			DrawTransfer(bs);
		}
		if (_bank.Count == 0)
		{
			Im.TextDisabled("Nothing yet - click Check /bank.");
			return;
		}
		if (!ImGui.BeginTable("banklist", 2, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY, new Vector2(0f, 0f)))
		{
			return;
		}
		ImGui.TableSetupColumn("Item", ImGuiTableColumnFlags.WidthFixed, 230f);
		ImGui.TableSetupColumn("In the bank", ImGuiTableColumnFlags.WidthStretch);
		ImGui.TableSetupScrollFreeze(0, 1);
		ImGui.TableHeadersRow();
		foreach (BankLine item2 in BankSorted())
		{
			if (true)
			{
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				Im.TextColored(Cyan, item2.Name);
				ImGui.TableSetColumnIndex(1);
				ImGui.TextUnformatted(item2.Value);
			}
		}
		ImGui.EndTable();
	}

	// ---------------------------------------------------------------- transfers (/b t)
	private static string _xferName = "";

	private static string _xferAmount = "";

	private static DateTime _xferConfirmUntil = DateTime.MinValue;

	private static string _xferConfirmWhat = "";

	/// <summary>"1100", "1,100", "1.1k", "2b", "3.5m", "1t" as a whole number (0: not one).</summary>
	public static long ParseAmount(string s)
	{
		s = (s ?? "").Trim().Replace(",", "").Replace("_", "").Replace(" ", "").ToLowerInvariant();
		if (s.Length == 0)
		{
			return 0L;
		}
		double mult = 1.0;
		char last = s[s.Length - 1];
		switch (last)
		{
		case 'k':
			mult = 1e3;
			break;
		case 'm':
			mult = 1e6;
			break;
		case 'b':
			mult = 1e9;
			break;
		case 't':
			mult = 1e12;
			break;
		}
		if (mult > 1.0)
		{
			s = s.Substring(0, s.Length - 1);
		}
		if (!double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out var v) || v <= 0.0 || double.IsInfinity(v))
		{
			return 0L;
		}
		double total = Math.Round(v * mult);
		return (total >= 9.2e18) ? 0L : (long)total;
	}

	private static List<string> XferNames(Settings s)
	{
		List<string> list = new List<string>();
		foreach (string part in (s.BankXferNames ?? "").Split('|'))
		{
			string n = part.Trim();
			if (n.Length > 0 && !list.Exists((string x) => x.Equals(n, StringComparison.OrdinalIgnoreCase)))
			{
				list.Add(n);
			}
		}
		return list;
	}

	private static void RememberXferName(Settings s, string name)
	{
		List<string> list = XferNames(s);
		list.RemoveAll((string x) => x.Equals(name, StringComparison.OrdinalIgnoreCase));
		list.Insert(0, name);
		if (list.Count > 8)
		{
			list.RemoveRange(8, list.Count - 8);
		}
		s.BankXferNames = string.Join("|", list);
		PluginCore.SaveAllNow();
	}

	/// <summary>The Lum pop-out's Tx tab: one character, and a button each for all the coins and all the luminance
	/// (the same names as the transfer above; each sends on a second click within 5 s).</summary>
	public static void DrawTransferAll(Settings s)
	{
		List<string> names = XferNames(s);
		if (_xferName.Length == 0 && names.Count > 0)
		{
			_xferName = names[0];
		}
		Im.TextColored(Cyan, "To");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(170f);
		ImGui.InputTextWithHint("##popxfername", "character", ref _xferName, 64u);
		ImGui.SameLine(0f, 2f);
		if (ImGui.BeginCombo("##popxferrecent", "", ImGuiComboFlags.NoPreview))
		{
			if (names.Count == 0)
			{
				Im.TextDisabled("no one yet");
			}
			foreach (string n in names)
			{
				if (ImGui.Selectable(n + "##popxfn", n.Equals(_xferName, StringComparison.OrdinalIgnoreCase)))
				{
					_xferName = n;
				}
			}
			ImGui.EndCombo();
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("The last few you've sent to.");
		}
		string name = _xferName.Trim().Trim('"');
		bool ok = name.Length > 0;
		foreach (var (kind, label) in new[] { ("e", "coins"), ("l", "lum") })
		{
			string what = "all " + kind + " " + name;
			bool armed = DateTime.Now < _xferConfirmUntil && _xferConfirmWhat == what;
			if (!ok)
			{
				ImGui.BeginDisabled();
			}
			if (ImGui.Button((armed ? "Send all " + label + "?" : "Transfer all " + label) + "##popxfer" + kind, new Vector2(150f, 0f)))
			{
				if (!armed)
				{
					_xferConfirmUntil = DateTime.Now.AddSeconds(5.0);
					_xferConfirmWhat = what;
				}
				else
				{
					_xferConfirmUntil = DateTime.MinValue;
					Remote.TransferAll(kind, name);
					RememberXferName(s, name);
				}
			}
			if (!ok)
			{
				ImGui.EndDisabled();
			}
			if (ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenDisabled))
			{
				Im.SetTooltip(ok ? ("All the " + (kind == "e" ? "Enlightened Coins" : "luminance") + " in the bank to " + name + " (it checks /bank first; the server keeps 1) - click again to send.") : "A name first.");
			}
			if (kind == "e") ImGui.SameLine();
		}
	}

	private static void DrawTransfer(Settings s)
	{
		Im.TextColored(Cyan, "Transfer");
		ImGui.SameLine();
		List<string> names = XferNames(s);
		if (_xferName.Length == 0 && names.Count > 0)
		{
			_xferName = names[0];
		}
		ImGui.SetNextItemWidth(160f);
		ImGui.InputTextWithHint("##xfername", "character", ref _xferName, 64u);
		ImGui.SameLine(0f, 2f);
		if (ImGui.BeginCombo("##xferrecent", "", ImGuiComboFlags.NoPreview))
		{
			if (names.Count == 0)
			{
				Im.TextDisabled("no one yet");
			}
			foreach (string n in names)
			{
				if (ImGui.Selectable(n + "##xfn", n.Equals(_xferName, StringComparison.OrdinalIgnoreCase)))
				{
					_xferName = n;
				}
			}
			ImGui.EndCombo();
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("The last few you've sent to.");
		}
		ImGui.SameLine();
		IReadOnlyDictionary<string, string> kinds = Remote.Transferable;
		if (!kinds.ContainsKey(s.BankXferKind ?? ""))
		{
			s.BankXferKind = "l";
		}
		ImGui.SetNextItemWidth(190f);
		if (ImGui.BeginCombo("##xferkind", kinds[s.BankXferKind]))
		{
			foreach (KeyValuePair<string, string> k in kinds)
			{
				if (ImGui.Selectable(k.Value + "##xfk", k.Key == s.BankXferKind))
				{
					s.BankXferKind = k.Key;
					PluginCore.SaveAllNow();
				}
			}
			ImGui.EndCombo();
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(110f);
		ImGui.InputTextWithHint("##xferamt", "how much", ref _xferAmount, 32u);
		long amount = ParseAmount(_xferAmount);
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("A whole number - 1100, 1,100, 1.1k, 2.5m, 2b, 1t." + ((amount > 0) ? ("\n= " + amount.ToString("N0")) : ""));
		}
		string name = _xferName.Trim().Trim('"');
		bool ok = name.Length > 0;
		ImGui.SameLine();
		// (a second click within 5 s sends it: nothing goes off on one stray click)
		string what = amount + " " + s.BankXferKind + " " + name;
		bool armed = DateTime.Now < _xferConfirmUntil && _xferConfirmWhat == what;
		if (!ok || amount <= 0)
		{
			ImGui.BeginDisabled();
		}
		if (ImGui.Button((armed ? "Send " + amount.ToString("N0") + "?" : "Transfer") + "##xfergo"))
		{
			if (!armed)
			{
				_xferConfirmUntil = DateTime.Now.AddSeconds(5.0);
				_xferConfirmWhat = what;
			}
			else
			{
				_xferConfirmUntil = DateTime.MinValue;
				Util.Command("/b t " + s.BankXferKind + " " + amount.ToString(CultureInfo.InvariantCulture) + " \"" + name + "\"");
				RememberXferName(s, name);
			}
		}
		if (!ok || amount <= 0)
		{
			ImGui.EndDisabled();
		}
		if (ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenDisabled))
		{
			Im.SetTooltip((ok && amount > 0) ? ("/b t " + s.BankXferKind + " " + amount + " \"" + name + "\" - click again to send.") : "A name and how much first.");
		}
		ImGui.SameLine();
		string whatAll = "all " + s.BankXferKind + " " + name;
		bool armedAll = DateTime.Now < _xferConfirmUntil && _xferConfirmWhat == whatAll;
		if (!ok)
		{
			ImGui.BeginDisabled();
		}
		if (ImGui.Button((armedAll ? "Send all?" : "All") + "##xferall"))
		{
			if (!armedAll)
			{
				_xferConfirmUntil = DateTime.Now.AddSeconds(5.0);
				_xferConfirmWhat = whatAll;
			}
			else
			{
				_xferConfirmUntil = DateTime.MinValue;
				Remote.TransferAll(s.BankXferKind, name);
				RememberXferName(s, name);
			}
		}
		if (!ok)
		{
			ImGui.EndDisabled();
		}
		if (ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenDisabled))
		{
			Im.SetTooltip("Everything of that kind in the bank (it checks /bank first; the server keeps 1) - click again to send.");
		}
	}

	public static void OnChat(string text)
	{
		if (string.IsNullOrEmpty(text))
		{
			return;
		}
		try
		{
			GemCreditChat(text);
			LumTrack.OnChat(text);
		}
		catch (Exception ex0)
		{
			Util.LogError(ex0);
		}
		if ((DateTime.Now - _killEventAt).TotalMilliseconds < 400.0)
		{
			_killTexts.Add(new KillText
			{
				Text = text,
				At = DateTime.Now
			});
			try
			{
				PluginCore.CurrentEngine?.NoteKillText(text);
			}
			catch
			{
			}
			if (_killTexts.Count > 50)
			{
				_killTexts.RemoveAt(0);
			}
		}
		if (text.StartsWith("[Pet]", StringComparison.Ordinal))
		{
			Match ph = PetHitRx.Match(text);
			if (ph.Success)
			{
				_petHits[ph.Groups[1].Value.Trim()] = DateTime.Now;
				if (_petHits.Count > 40) { foreach (var k in System.Linq.Enumerable.ToList(System.Linq.Enumerable.Select(System.Linq.Enumerable.Where(_petHits, kv => (DateTime.Now - kv.Value).TotalMinutes > 2), kv => kv.Key))) _petHits.Remove(k); }
			}
		}
		if (text.StartsWith("[BANK]", StringComparison.OrdinalIgnoreCase))
		{
			NoteBank(text);
		}
		NoteDeeds(text);
		NoteBountyLine(text);
		CoinChat(text);
		try
		{
			PaceChat(text);
		}
		catch
		{
		}
		TokenDepositChat(text);
		MkChat(text);
		try
		{
			AttrChat(text);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		AeChat(text);
		FractureChat(text);
		if (DateTime.Now <= _augCaptureUntil || text.IndexOf("Advanced Augmentation Levels", StringComparison.OrdinalIgnoreCase) >= 0 || Regex.IsMatch(text, "^\\s*Creature:\\s*[\\d,]+\\s*$", RegexOptions.Multiline))
		{
			NoteAugs(text);
		}
		AttackGems.OnChat(text);
		if (text.StartsWith("You've banked ", StringComparison.OrdinalIgnoreCase) && text.IndexOf("Luminance", StringComparison.OrdinalIgnoreCase) > 0)
		{
			_killLineAt = DateTime.Now;
			Match match = Regex.Match(text, "banked ([\\d,]+) Luminance", RegexOptions.IgnoreCase);
			if (match.Success && long.TryParse(match.Groups[1].Value.Replace(",", ""), out var result))
			{
				_lumEarned += result;
				_lumBankedLines += result;
			}
		}
	}

	public static void OnServerMessage(Message m)
	{
		try
		{
			if (m.Type == 63408 && m.Value<int>("event") == 429)
			{
				_killLineAt = DateTime.Now;
				_killEventAt = DateTime.Now;
			}
		}
		catch
		{
		}
	}

	public static void NoteDeath()
	{
		Cur.Deaths++;
		All.Deaths++;
		_allDirty = true;
	}

	public static void NoteLoot(ObjectClass c)
	{
		Cur.AddLoot(c);
		All.AddLoot(c);
		_allDirty = true;
	}

	public static void NoteCorpse(bool kept)
	{
		Cur.Corpses++;
		All.Corpses++;
		if (kept)
		{
			Cur.CorpsesKept++;
			All.CorpsesKept++;
		}
		_allDirty = true;
	}

	public static void Tick()
	{
		if (DateTime.Now < _nextTick)
		{
			return;
		}
		_nextTick = DateTime.Now.AddMilliseconds(500.0);
		SampleTick();
		BankFileTick();
		AugFileTick();
		try { AttackGems.Tick(); } catch (Exception ex) { Util.LogError(ex); }
		try { AugVarsTick(); } catch (Exception ex) { Util.LogError(ex); }
		bool ilt = ServerMode.Ilt;
		if (ilt)
		{
			try
			{
				AugsTick();
			}
			catch
			{
			}
		}
		DeedsFileTick();
		if (ilt)
		{
			MkTick();
			try
			{
				LumTrack.Tick();
				EnlBankTick();
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
			try
			{
				AttrTick();
			}
			catch (Exception ex2)
			{
				Util.LogError(ex2);
			}
		}
		try
		{
			PaceTick();
		}
		catch
		{
		}
		if (ilt)
		{
			AeTick();
		}
		RtTick();
		if (ilt)
		{
			try
			{
				Charms.Tick();
			}
			catch (Exception ex3)
			{
				Util.LogError(ex3);
			}
		}
		if (ilt)
		{
			try
			{
				LumTokenTick();
			}
			catch
			{
			}
		}
		try
		{
			BountyHud.KtLines();
		}
		catch
		{
		}
		if (ilt)
		{
			FractureTick();
		}
		try
		{
			NearbyPlayers.Tick();
		}
		catch (Exception ex4)
		{
			Util.LogError(ex4);
		}
		for (int i = 0; i < _gone.Count; i++)
		{
			Gone gone = _gone[i];
			if (gone.Unengaged ? (TakeKillText(gone.Name, gone.At) || PetKilled(gone)) : (Math.Abs((_killLineAt - gone.At).TotalSeconds) <= 5.0))
			{
				_gone.RemoveAt(i--);
				Count(gone);
			}
			else if ((DateTime.Now - gone.At).TotalSeconds > 5.0)
			{
				_gone.RemoveAt(i--);
			}
		}
		_corpses.RemoveAll((Corpse c) => (DateTime.Now - c.At).TotalSeconds > 5.0);
		_killTexts.RemoveAll((KillText k) => (DateTime.Now - k.At).TotalSeconds > 10.0);
		double totalSeconds = (DateTime.Now - _savedAt).TotalSeconds;
		if ((_allDirty && totalSeconds > 60.0) || totalSeconds > 300.0)
		{
			SaveAll();
		}
	}

	// luminance tokens earned as you go: each kill that counts toward a bounty paying Thaelaryn Tokens of Luminance is worth
	// its share of the reward (Wailing Cells: 1 token per 1,200 kills = 50 B / 1,200 a kill) - so an hour in Wailing Cells
	// waiting out the T12 bounty's cooldown shows in lum/hr, not only the moment a token arrives two hours later
	public static bool LumFromBountyProgress = true;
	private static double _lumProgress;
	private static readonly Regex TokRewardRx = new Regex("^(?:(?<n>[\\d,]+)\\s+)?Thaelaryn Tokens? of Luminance\\b", RegexOptions.IgnoreCase);

	/// <summary>What the luminance-token bounties you're on pay an hour at your kills/hr over the last 60 min, with a line per bounty.</summary>
	public static double TokenBountyPace(out string lines)
	{
		lines = "";
		double total = 0.0;
		BountyTracker t = BountyTracker.Current;
		double kph = KillsPerHourRecent;
		if (t == null || kph <= 0.0 || LumTokenValue <= 0.0) return 0.0;
		foreach (Bounty b in t.HereBounties())
		{
			Match m = TokRewardRx.Match((b.Reward ?? "").Trim());
			if (!m.Success) continue;
			int n = 1;
			if (m.Groups["n"].Success) int.TryParse(m.Groups["n"].Value.Replace(",", ""), out n);
			double r = n * LumTokenValue * kph / b.Need;
			total += r;
			lines += "\n" + b.Zone + ": " + n + " token" + (n == 1 ? "" : "s") + " / " + b.Need.ToString("N0") + " kills at " + kph.ToString("N0") + " kills/hr = " + Big(r) + "/hr (" + (b.Need / kph).ToString("0.0") + " hr a reward)";
		}
		return total;
	}

	/// <summary>Credits the kills a token bounty here already has (made before kill-by-kill counting was on). Once per session.</summary>
	public static bool _progressCredited;
	public static long CreditBountyProgress()
	{
		BountyTracker t = BountyTracker.Current;
		if (t == null || _progressCredited || LumTokenValue <= 0.0) return 0;
		double add = 0.0;
		foreach (Bounty b in t.HereBounties())
		{
			Match m = TokRewardRx.Match((b.Reward ?? "").Trim());
			if (!m.Success) continue;
			int n = 1;
			if (m.Groups["n"].Success) int.TryParse(m.Groups["n"].Value.Replace(",", ""), out n);
			add += n * LumTokenValue * Math.Min(b.Have, b.Need) / b.Need;
		}
		if (add >= 1.0)
		{
			_lumEarned += (long)add;
			_progressCredited = true;
			_ratesAt = DateTime.MinValue;
			Util.WriteToChat("Session: +" + Big(add) + " luminance for the token-bounty kills you already had.");
		}
		return (long)add;
	}

	private static void BountyProgressKill()
	{
		if (!LumFromBountyProgress || !CountLumTokens || LumTokenValue <= 0.0) return;
		BountyTracker t = BountyTracker.Current;
		if (t == null) return;
		foreach (Bounty b in t.HereBounties())
		{
			Match m = TokRewardRx.Match((b.Reward ?? "").Trim());
			if (!m.Success) continue;
			int n = 1;
			if (m.Groups["n"].Success) int.TryParse(m.Groups["n"].Value.Replace(",", ""), out n);
			_lumProgress += n * LumTokenValue / b.Need;
		}
		if (_lumProgress >= 1.0)
		{
			long whole = (long)_lumProgress;
			_lumEarned += whole;
			_lumProgress -= whole;
		}
	}

	private static void Count(Gone g)
	{
		double secs = Math.Max(0.0, (g.At - g.EngagedAt).TotalSeconds);
		Cur.AddKill(g.Name, g.Species, secs);
		try
		{
			BountyProgressKill();
		}
		catch (Exception exb)
		{
			Util.LogError(exb);
		}
		try
		{
			PackStats.Killed(g.Name);
		}
		catch
		{
		}
		try
		{
			CoinKill();
		}
		catch
		{
		}
		try
		{
			AugKill();
		}
		catch
		{
		}
		try
		{
			if (BountyTracker.Current != null)
			{
				BountyTracker.Current.Kill();
			}
		}
		catch
		{
		}
		_recent.Add(DateTime.Now);
		All.AddKill(g.Name, g.Species, secs);
		_allDirty = true;
	}

	private static double PlayedSecs(Stats s)
	{
		return (s == All) ? (All.PlayedSecs + (DateTime.Now - _playedMark).TotalSeconds) : (DateTime.Now - Cur.Since).TotalSeconds;
	}

	private static double HoursOf(Stats s)
	{
		return Math.Max(0.0002777777777777778, PlayedSecs(s) / 3600.0);
	}

	private static void CountTokens(long got, string how)
	{
		if (LumFromBountyProgress)
		{
			// (already counted kill by kill as the bounty filled)
			_tokGot += got;
			return;
		}
		_tokGot += got;
		_lumEarned += (long)((double)got * LumTokenValue);
		Util.WriteToChat("Session: " + got + " Thaelaryn Token" + ((got == 1) ? "" : "s") + " of Luminance " + how + " = +" + Big((double)got * LumTokenValue) + " luminance earned.");
	}

	private static void TokenDepositChat(string text)
	{
		if (!CountLumTokens)
		{
			return;
		}
		Match match = TokDepositRx.Match(text.Trim());
		if (match.Success && long.TryParse(match.Groups["n"].Value.Replace(",", ""), out var result) && result > 0)
		{
			long num = result - _tokHeld;
			if (num > 0)
			{
				CountTokens(num, "deposited (not seen arriving)");
			}
			// (their luminance goes into the bank - counted already as tokens: not counted again by the bank)
			LumTrack.TokensDeposited((double)result * LumTokenValue);
			_tokHeld = Math.Max(0L, _tokHeld - result);
		}
	}

	private static void LumTokenTick()
	{
		if (DateTime.Now < _tokNext)
		{
			return;
		}
		_tokNext = DateTime.Now.AddSeconds(2.0);
		long num = 0L;
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (Loose(item.Name) == "thaelaryn token of luminance")
				{
					num += Math.Max(1, item.Values(LongValueKey.StackCount, 1));
				}
			}
		}
		catch
		{
			return;
		}
		if (_tokBase < 0)
		{
			_tokArmAt = DateTime.Now.AddSeconds(30.0);
		}
		if (DateTime.Now < _tokArmAt)
		{
			_tokHeld = num;
		}
		if (_tokBase >= 0 && num > _tokBase && CountLumTokens && DateTime.Now >= _tokArmAt)
		{
			long num2 = num - _tokBase;
			_tokHeld += num2;
			CountTokens(num2, "received");
		}
		_tokBase = num;
	}

	private static long XpNow()
	{
		try
		{
			return CoreManager.Current.CharacterFilter.TotalXP;
		}
		catch
		{
			return -1L;
		}
	}

	private static void Rates()
	{
		if (!((DateTime.Now - _ratesAt).TotalSeconds < 10.0))
		{
			_ratesAt = DateTime.Now;
			double num = HoursOf(Cur);
			_lumPh = (double)_lumEarned / num;
			_xpPh = (double)XpEarned / num;
			_lumPhR = Recent(lum: true);
			_xpPhR = Recent(lum: false);
			double num2 = BountyLumPerHour();
			_lumIsBounty = num2 > 0.0;
			if (_lumIsBounty)
			{
				_lumPh = num2;
				_lumPhR = num2;
			}
		}
	}

	private static double Recent(bool lum)
	{
		Sample sample = null;
		// lum looks back further (Session > Lum > Settings): a T12 run + the hour waiting in banshees is one cycle,
		// and one 60-minute slice of it reads far too low or far too high
		DateTime dateTime = lum ? DateTime.Now.AddMinutes(-LumTrack.WindowMin) : DateTime.Now.AddHours(-1.0);
		foreach (Sample sample2 in _samples)
		{
			if (sample2.At >= dateTime)
			{
				sample = sample2;
				break;
			}
		}
		if (sample == null || (DateTime.Now - sample.At).TotalMinutes < 5.0)
		{
			return (double)(lum ? _lumEarned : XpEarned) / HoursOf(Cur);
		}
		double totalHours = (DateTime.Now - sample.At).TotalHours;
		return (double)((lum ? _lumEarned : XpEarned) - (lum ? sample.Lum : sample.Xp)) / totalHours;
	}

	private static void SampleTick()
	{
		if (!(DateTime.Now < _nextSample))
		{
			_nextSample = DateTime.Now.AddSeconds(30.0);
			if (_xpStart < 0)
			{
				_xpStart = XpNow();
			}
			_samples.Add(new Sample
			{
				At = DateTime.Now,
				Lum = _lumEarned,
				Xp = XpEarned
			});
			DateTime old = DateTime.Now.AddMinutes(-Math.Max(62.0, LumTrack.WindowMin + 2.0));
			_samples.RemoveAll((Sample x) => x.At < old);
		}
	}

	public static string Big(double v)
	{
		double num = Math.Abs(v);
		if (num >= 1000000000000000.0)
		{
			return (v / 1000000000000000.0).ToString("0.##") + "Q";
		}
		if (num >= 1000000000000.0)
		{
			return (v / 1000000000000.0).ToString("0.##") + "T";
		}
		if (num >= 1000000000.0)
		{
			return (v / 1000000000.0).ToString("0.##") + "B";
		}
		if (num >= 1000000.0)
		{
			return (v / 1000000.0).ToString("0.##") + "M";
		}
		if (num >= 10000.0)
		{
			return (v / 1000.0).ToString("0.#") + "K";
		}
		return v.ToString("N0");
	}

	public static void NoteFight(int mobsInRange)
	{
		DateTime now = DateTime.Now;
		if (mobsInRange > 0)
		{
			if (_inFight && _fightEndAt != DateTime.MinValue)
			{
				FinishFight();
			}
			if (!_inFight)
			{
				_inFight = true;
				_fightStart = now;
				_fightKills0 = Cur.Kills;
				_fightEndAt = DateTime.MinValue;
				try
				{
					PackStats.PackStart();
				}
				catch
				{
				}
			}
			_lastMobsAt = now;
			_fightEndAt = DateTime.MinValue;
		}
		else if (_inFight && !((now - _lastMobsAt).TotalSeconds < 3.0))
		{
			if (_fightEndAt == DateTime.MinValue)
			{
				_fightEndAt = now;
			}
			if (!((now - _fightEndAt).TotalSeconds < 6.0))
			{
				FinishFight();
			}
		}
	}

	private static void FinishFight()
	{
		_inFight = false;
		int num = Cur.Kills - _fightKills0;
		double totalSeconds = (_lastMobsAt - _fightStart).TotalSeconds;
		bool flag = false;
		try
		{
			flag = PackStats.PackEnd(num, Math.Max(0.0, totalSeconds));
		}
		catch
		{
		}
		if (!((num < 3 || totalSeconds <= 0.0) | flag))
		{
			Packs++;
			PackKills += num;
			PackTotalSecs += totalSeconds;
			PackLast = totalSeconds;
			if (totalSeconds < PackFastest)
			{
				PackFastest = totalSeconds;
			}
			if (totalSeconds > PackSlowest)
			{
				PackSlowest = totalSeconds;
			}
		}
	}

	private static void ResetPacks()
	{
		_inFight = false;
		Packs = (PackKills = 0);
		PackTotalSecs = (PackSlowest = (PackLast = 0.0));
		PackFastest = double.MaxValue;
	}

	public static void ResetRecentRate()
	{
		_recent.Clear();
		_recentSince = DateTime.Now;
	}

	private static string N(double v)
	{
		return v.ToString("R", CultureInfo.InvariantCulture);
	}

	private static void SaveAll()
	{
		if (_file == null)
		{
			return;
		}
		try
		{
			All.PlayedSecs += (DateTime.Now - _playedMark).TotalSeconds;
			_playedMark = DateTime.Now;
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append("# MelkTank all-time stats for this character (Session tab > All Time). Reset there.\r\n");
			stringBuilder.Append("P\t").Append(N(All.PlayedSecs)).Append('\t')
				.Append(All.Since.Ticks)
				.Append('\t')
				.Append(All.Kills)
				.Append('\t')
				.Append(All.Deaths)
				.Append('\t')
				.Append(All.LootItems)
				.Append('\t')
				.Append(All.Corpses)
				.Append('\t')
				.Append(All.CorpsesKept)
				.Append('\t')
				.Append(All.LootArmor)
				.Append('\t')
				.Append(All.LootClothing)
				.Append('\t')
				.Append(All.LootJewelry)
				.Append('\t')
				.Append(All.LootWeapons)
				.Append('\t')
				.Append(All.LootMisc)
				.Append("\r\n");
			foreach (MobStat value in All.Mobs.Values)
			{
				stringBuilder.Append("M\t").Append((value.Name ?? "").Replace("\t", " ")).Append('\t')
					.Append(value.Species)
					.Append('\t')
					.Append(value.Kills)
					.Append('\t')
					.Append(N(value.TotalSecs))
					.Append('\t')
					.Append(N((value.Fastest == double.MaxValue) ? 0.0 : value.Fastest))
					.Append('\t')
					.Append(N(value.Slowest))
					.Append("\r\n");
			}
			Util.WriteShared(_file, stringBuilder.ToString());
			_allDirty = false;
			_savedAt = DateTime.Now;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void LoadAll()
	{
		All.Clear();
		_savedAt = DateTime.Now;
		_allDirty = false;
		if (_file == null || !File.Exists(_file))
		{
			return;
		}
		try
		{
			CultureInfo invariantCulture = CultureInfo.InvariantCulture;
			string[] array = Util.Locked(_file, () => File.ReadAllLines(_file));
			string[] array2 = array;
			foreach (string text in array2)
			{
				string[] array3 = text.Split('\t');
				if (array3[0] == "P" && array3.Length >= 13)
				{
					double.TryParse(array3[1], NumberStyles.Float, invariantCulture, out All.PlayedSecs);
					if (long.TryParse(array3[2], out var result) && result > 0)
					{
						All.Since = new DateTime(result);
					}
					int.TryParse(array3[3], out All.Kills);
					int.TryParse(array3[4], out All.Deaths);
					int.TryParse(array3[5], out All.LootItems);
					int.TryParse(array3[6], out All.Corpses);
					int.TryParse(array3[7], out All.CorpsesKept);
					int.TryParse(array3[8], out All.LootArmor);
					int.TryParse(array3[9], out All.LootClothing);
					int.TryParse(array3[10], out All.LootJewelry);
					int.TryParse(array3[11], out All.LootWeapons);
					int.TryParse(array3[12], out All.LootMisc);
				}
				else if (array3[0] == "M" && array3.Length >= 7 && array3[1].Length > 0)
				{
					MobStat mobStat = new MobStat
					{
						Name = array3[1]
					};
					int.TryParse(array3[2], out mobStat.Species);
					int.TryParse(array3[3], out mobStat.Kills);
					double.TryParse(array3[4], NumberStyles.Float, invariantCulture, out mobStat.TotalSecs);
					if (double.TryParse(array3[5], NumberStyles.Float, invariantCulture, out var result2) && result2 > 0.0)
					{
						mobStat.Fastest = result2;
					}
					double.TryParse(array3[6], NumberStyles.Float, invariantCulture, out mobStat.Slowest);
					All.Mobs[mobStat.Name] = mobStat;
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void Draw()
	{
		if (ImGui.BeginTabBar("sessiontabs"))
		{
			bool ilt = ServerMode.Ilt;
			if (ImGui.BeginTabItem("Main"))
			{
				DrawMain();
				ImGui.EndTabItem();
			}
			if (ilt && ImGui.BeginTabItem("Bounties"))
			{
				DrawBounties();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Kills"))
			{
				DrawKills(Cur, _curSort, "sesskills", "No kills yet this session.");
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("All Time"))
			{
				DrawAllTime();
				ImGui.EndTabItem();
			}
			if (ilt && ImGui.BeginTabItem("Lum"))
			{
				LumTrack.Draw();
				ImGui.EndTabItem();
			}
			if (ilt && ImGui.BeginTabItem("Bank"))
			{
				DrawBank();
				ImGui.EndTabItem();
			}
			if (ilt && ImGui.BeginTabItem("Augs"))
			{
				DrawAugsTabs();
				ImGui.EndTabItem();
			}
			if (ilt && ImGui.BeginTabItem("Attr"))
			{
				DrawAttr();
				ImGui.EndTabItem();
			}
			if (ilt && ImGui.BeginTabItem("Deeds"))
			{
				DrawDeeds();
				ImGui.EndTabItem();
			}
			if (ilt && ImGui.BeginTabItem("Enl"))
			{
				DrawEnl();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Players"))
			{
				NearbyPlayers.Draw();
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem("Packs"))
			{
				PackStats.Draw();
				ImGui.EndTabItem();
			}
			ImGui.EndTabBar();
		}
	}

	private static string Span(double secs)
	{
		TimeSpan timeSpan = TimeSpan.FromSeconds(Math.Max(0.0, secs));
		return (int)timeSpan.TotalHours + ":" + timeSpan.Minutes.ToString("00") + ":" + timeSpan.Seconds.ToString("00");
	}

	private static string Secs(double s)
	{
		if (s <= 0.0 || s == double.MaxValue)
		{
			return "-";
		}
		return (s < 60.0) ? (s.ToString("0.0") + "s") : ((int)(s / 60.0) + ":" + ((int)s % 60).ToString("00"));
	}

	private static void Row(string label, string value, string tip = null)
	{
		ImGui.TableNextRow();
		ImGui.TableSetColumnIndex(0);
		Im.TextColored(Cyan, label);
		if (tip != null && ImGui.IsItemHovered())
		{
			Im.SetTooltip(tip);
		}
		ImGui.TableSetColumnIndex(1);
		ImGui.TextUnformatted(value);
	}

	private static void Row2(string l1, string v1, string l2, string v2)
	{
		ImGui.TableNextRow();
		ImGui.TableSetColumnIndex(0);
		Im.TextColored(Cyan, l1);
		ImGui.TableSetColumnIndex(1);
		ImGui.TextUnformatted(v1);
		ImGui.TableSetColumnIndex(2);
		if (l2 != null)
		{
			Im.TextColored(Cyan, l2);
		}
		ImGui.TableSetColumnIndex(3);
		if (v2 != null)
		{
			ImGui.TextUnformatted(v2);
		}
	}

	private static string CorpsesText(Stats s)
	{
		return s.Corpses.ToString("N0") + ((s.Corpses > 0) ? ("  (" + (100.0 * (double)s.CorpsesKept / (double)s.Corpses).ToString("0") + "% kept something)") : "");
	}

	private static string LootText(Stats s)
	{
		return s.LootItems.ToString("N0") + ((s.Corpses > 0) ? ("  (" + ((double)s.LootItems / (double)s.Corpses).ToString("0.##") + " per corpse)") : "");
	}

	private static void DrawMain()
	{
		Stats cur = Cur;
		double num = HoursOf(cur);
		if (ImGui.BeginTable("sessmain", 2, ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("a", ImGuiTableColumnFlags.WidthFixed, 140f);
			ImGui.TableSetupColumn("b", ImGuiTableColumnFlags.WidthStretch);
			Row("Time played", Span(PlayedSecs(cur)), "Since this character logged in (or since Reset).");
			Row("Kills", cur.Kills.ToString("N0"), "Monsters MelkTank was fighting that died close by.\nKill times per monster are on the Kills tab.");
			Row("Kills / hour", ((double)cur.Kills / num).ToString("N0"), "Over the whole session.");
			int num2 = OutKills(cur);
			if (num2 > 0)
			{
				double num3 = TunedHours(cur, num);
				Row("Kills / hour (tuned)", ((double)(cur.Kills - num2) / num3).ToString("N0"), "Without the monsters left out of tuning (" + num2.ToString("N0") + " kills) and their time: their fights and the waits\nfrom one of their fights to the next (" + Fmt((num - num3) * 3600.0) + " of the session's " + Fmt(num * 3600.0) + ").");
			}
			double killsPerHourRecent = KillsPerHourRecent;
			Row("   last 60 min", (killsPerHourRecent < 0.0) ? "after 1 minute" : killsPerHourRecent.ToString("N0"), "Kills per hour over the last 60 minutes - what you're doing now.\nMelksQB uses this for the bounty time to go.");
			string text = CoinLine();
			if (text.Length > 0)
			{
				Row("Prestige coins", text.Substring("Prestige Coin: ".Length) + "  kills toward the next", CoinTip());
			}
			Row("Deaths", cur.Deaths.ToString());
			Row("Packs", (Packs == 0) ? "none yet" : (Packs.ToString("N0") + "   avg " + Secs(PackAvg) + " · fastest " + Secs(PackFastest) + " · slowest " + Secs(PackSlowest) + " · last " + Secs(PackLast) + " · " + ((double)PackKills / (double)Packs).ToString("0.0") + " kills each"), "A pack = a fight with " + 3 + "+ kills: from the first monster in attack range until none is left.");
			Row("Luminance earned", Big(LumEarned) + (LumRateIsBounty ? ("   (" + Big(LumPerHour) + "/hr from the bounty reward - Settings > Areas)") : ("   (" + Big(LumPerHour) + "/hr, last " + LumTrack.WindowText + " " + Big(LumPerHourRecent) + "/hr)")), "From the \"You've banked ... Luminance\" lines" + (CountLumTokens ? (", plus " + LumTokenValue.ToString("0,,,") + " B for each Thaelaryn Token of Luminance you receive" + ((_tokGot > 0) ? (" (" + _tokGot + " so far)") : "") + ".\nTokens in your packs now: " + Math.Max(0L, _tokBase)) : "") + ".");
			DrawFractureRow();
			Row("XP earned", Big(XpEarned) + "   (" + Big(XpPerHour) + "/hr, last 60 min " + Big(XpPerHourRecent) + "/hr)");
			Row("Corpses looted", cur.Corpses.ToString("N0") + ((cur.Corpses > 0) ? ("   (" + cur.CorpsesKept.ToString("N0") + " had something to keep, " + (100.0 * (double)cur.CorpsesKept / (double)cur.Corpses).ToString("0") + "%)") : ""), "Corpses the looter opened and went through (skipped ones aren't counted).");
			Row("Loot kept", cur.LootItems.ToString("N0") + " item" + ((cur.LootItems == 1) ? "" : "s") + ((cur.Corpses > 0) ? ("   (" + ((double)cur.LootItems / (double)cur.Corpses).ToString("0.##") + " per corpse)") : ""), "Items the looter picked up.");
			Row("      Armor", cur.LootArmor.ToString("N0"));
			Row("      Clothing", cur.LootClothing.ToString("N0"));
			Row("      Jewelry", cur.LootJewelry.ToString("N0"));
			Row("      Weapons", cur.LootWeapons.ToString("N0"), "Melee, missile, and wands / staffs / orbs.");
			Row("      Misc", cur.LootMisc.ToString("N0"), "Everything else: gems, salvage, keys, trophies, scrolls...");
			ImGui.EndTable();
		}
		ImGui.Spacing();
		if (!_confirmReset)
		{
			if (ImGui.Button("Reset session"))
			{
				_confirmReset = true;
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Starts this session's numbers over (they also start over every time you log in).\nAll Time isn't touched.");
			}
			return;
		}
		Im.TextColored(Yellow, "Start the session over?");
		ImGui.SameLine();
		if (ImGui.Button("Yes##sessreset"))
		{
			Reset();
			_confirmReset = false;
		}
		ImGui.SameLine();
		if (ImGui.Button("No##sessreset"))
		{
			_confirmReset = false;
		}
	}

	private static void DrawAllTime()
	{
		Stats all = All;
		double num = HoursOf(all);
		Im.TextDisabled("This character, every session since " + all.Since.ToString("yyyy-MM-dd HH:mm"));
		string text = (_confirmResetAll ? "" : "Reset all time");
		float num2 = (_confirmResetAll ? 230f : (ImGui.CalcTextSize(text).X + 16f));
		ImGui.SameLine(Math.Max(ImGui.GetCursorPosX() + 10f, ImGui.GetWindowContentRegionMax().X - num2));
		if (!_confirmResetAll)
		{
			if (ImGui.Button(text))
			{
				_confirmResetAll = true;
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Clears every all-time number and kill for this character. This session's tabs aren't touched.");
			}
		}
		else
		{
			Im.TextColored(Yellow, "Clear all time?");
			ImGui.SameLine();
			if (ImGui.Button("Yes##allreset"))
			{
				ResetAll();
				_confirmResetAll = false;
			}
			ImGui.SameLine();
			if (ImGui.Button("No##allreset"))
			{
				_confirmResetAll = false;
			}
		}
		if (ImGui.BeginTable("allmain", 4, ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("a", ImGuiTableColumnFlags.WidthFixed, 110f);
			ImGui.TableSetupColumn("b", ImGuiTableColumnFlags.WidthStretch);
			ImGui.TableSetupColumn("c", ImGuiTableColumnFlags.WidthFixed, 90f);
			ImGui.TableSetupColumn("d", ImGuiTableColumnFlags.WidthStretch);
			Row2("Time played", Span(PlayedSecs(all)), "Deaths", all.Deaths.ToString("N0"));
			Row2("Kills", all.Kills.ToString("N0"), "Kills / hour", ((double)all.Kills / num).ToString("N0"));
			Row2("Corpses looted", CorpsesText(all), "Loot kept", LootText(all));
			Row2("Armor", all.LootArmor.ToString("N0"), "Clothing", all.LootClothing.ToString("N0"));
			Row2("Jewelry", all.LootJewelry.ToString("N0"), "Weapons", all.LootWeapons.ToString("N0"));
			Row2("Misc", all.LootMisc.ToString("N0"), null, null);
			ImGui.EndTable();
		}
		ImGui.Separator();
		DrawKills(all, _allSort, "allkills", "No kills saved for this character yet.");
	}

	private static int Compare(SortState st, int kills1, double avg1, double fast1, double slow1, double total1, string name1, int kills2, double avg2, double fast2, double slow2, double total2, string name2)
	{
		int num;
		switch (st.Col)
		{
		case 1:
		case 5:
			num = kills1.CompareTo(kills2);
			break;
		case 2:
			num = avg1.CompareTo(avg2);
			break;
		case 3:
			num = fast1.CompareTo(fast2);
			break;
		case 4:
			num = slow1.CompareTo(slow2);
			break;
		case 6:
			num = total1.CompareTo(total2);
			break;
		default:
			num = 0;
			break;
		}
		if (st.Desc)
		{
			num = -num;
		}
		return (num != 0) ? num : string.Compare(name1, name2, StringComparison.OrdinalIgnoreCase);
	}

	private static double TunedHours(Stats s, double h)
	{
		if (s != Cur)
		{
			return h;
		}
		double val = h - PackStats.OutSecs / 3600.0;
		return Math.Max(val, Math.Min(h, 1.0 / 60.0));
	}

	private static string Fmt(double secs)
	{
		TimeSpan timeSpan = TimeSpan.FromSeconds(Math.Max(0.0, secs));
		return (timeSpan.TotalHours >= 1.0) ? ((int)timeSpan.TotalHours + "h " + timeSpan.Minutes + "m") : (timeSpan.Minutes + "m " + timeSpan.Seconds + "s");
	}

	private static int OutKills(Stats s)
	{
		int num = 0;
		foreach (MobStat value in s.Mobs.Values)
		{
			if (PackStats.IsOut(value.Name))
			{
				num += value.Kills;
			}
		}
		return num;
	}

	private static void Cells(int kills, double avg, double fast, double slow, double total, double totalAll, double h)
	{
		ImGui.TableSetColumnIndex(1);
		ImGui.TextUnformatted(kills.ToString("N0"));
		ImGui.TableSetColumnIndex(2);
		ImGui.TextUnformatted(Secs(avg));
		ImGui.TableSetColumnIndex(3);
		ImGui.TextUnformatted(Secs(fast));
		ImGui.TableSetColumnIndex(4);
		ImGui.TextUnformatted(Secs(slow));
		ImGui.TableSetColumnIndex(5);
		ImGui.TextUnformatted(((double)kills / h).ToString("0"));
		ImGui.TableSetColumnIndex(6);
		ImGui.TextUnformatted((totalAll > 0.0) ? ((100.0 * total / totalAll).ToString("0") + "%") : "-");
	}

	private static void DrawKills(Stats s, SortState st, string id, string empty)
	{
		if (s.Mobs.Count == 0)
		{
			Im.TextDisabled(empty);
			Im.TextWrapped("Each monster's time runs from your first attack, debuff or pet hit that landed (the Tracking tab's timer) to when it dies.");
			return;
		}
		double num = 0.0;
		Dictionary<int, Group> dictionary = new Dictionary<int, Group>();
		foreach (MobStat value2 in s.Mobs.Values)
		{
			num += value2.TotalSecs;
			try
			{
				SpeciesNameOf(value2);
			}
			catch
			{
			}
			if (!dictionary.TryGetValue(value2.Species, out var value))
			{
				string text = SpeciesNameOf(value2);
				value = new Group
				{
					Species = value2.Species,
					Name = (string.IsNullOrEmpty(text) ? "Unknown species" : text)
				};
				dictionary[value2.Species] = value;
			}
			value.Mobs.Add(value2);
			value.Kills += value2.Kills;
			value.TotalSecs += value2.TotalSecs;
			if (value2.Fastest < value.Fastest)
			{
				value.Fastest = value2.Fastest;
			}
			if (value2.Slowest > value.Slowest)
			{
				value.Slowest = value2.Slowest;
			}
		}
		double h = HoursOf(s);
		if (ImGui.SmallButton("Expand all##" + id))
		{
			st.OpenAll = 1;
		}
		ImGui.SameLine();
		if (ImGui.SmallButton("Collapse all##" + id))
		{
			st.OpenAll = -1;
		}
		ImGui.SameLine();
		Im.TextDisabled(s.Mobs.Count + " monster" + ((s.Mobs.Count == 1) ? "" : "s") + " in " + dictionary.Count + " species");
		ImGuiTableFlags flags = ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY;
		if (!ImGui.BeginTable(id, 8, flags, new Vector2(0f, 0f)))
		{
			st.OpenAll = 0;
			return;
		}
		ImGui.TableSetupColumn("Monster", ImGuiTableColumnFlags.WidthStretch);
		ImGui.TableSetupColumn("Kills", ImGuiTableColumnFlags.WidthFixed, 52f);
		ImGui.TableSetupColumn("Avg", ImGuiTableColumnFlags.WidthFixed, 52f);
		ImGui.TableSetupColumn("Fastest", ImGuiTableColumnFlags.WidthFixed, 56f);
		ImGui.TableSetupColumn("Slowest", ImGuiTableColumnFlags.WidthFixed, 56f);
		ImGui.TableSetupColumn("/hr", ImGuiTableColumnFlags.WidthFixed, 48f);
		ImGui.TableSetupColumn("Time", ImGuiTableColumnFlags.WidthFixed, 50f);
		ImGui.TableSetupColumn("Out", ImGuiTableColumnFlags.WidthFixed, 34f);
		ImGui.TableSetupScrollFreeze(0, 1);
		string[] array = new string[8] { "Monster", "Kills", "Avg", "Fastest", "Slowest", "/hr", "Time", "Out" };
		string[] array2 = new string[8] { "Sort by name.", "How many died.", "Average kill time: first landed hit to death. Lower = quicker to kill.", "Quickest kill.", "Slowest kill.", "Kills per hour of play time.", "Share of all your fighting time spent on these.", "Ticked: left out of the Packs / Tuning numbers (packs of only these, their damage, slow kills, kills by stretch\nof route). Their kills and kills / hour still count here and for the bounty timers." };
		ImGui.TableNextRow(ImGuiTableRowFlags.Headers);
		for (int i = 0; i < array.Length; i++)
		{
			ImGui.TableSetColumnIndex(i);
			if (i == 7)
			{
				Im.TextColored(Cyan, array[i]);
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip(array2[i]);
				}
				continue;
			}
			string text2;
			if (st.Col != i)
			{
				text2 = "";
			}
			else
			{
				text2 = (st.Desc ? " v" : " ^");
			}
			ImGui.PushStyleColor(ImGuiCol.Text, Cyan);
			if (ImGui.Selectable(array[i] + text2 + "##" + id + i, st.Col == i))
			{
				if (st.Col == i)
				{
					st.Desc = !st.Desc;
				}
				else
				{
					st.Col = i;
					st.Desc = i != 0 && i != 2 && i != 3;
				}
			}
			ImGui.PopStyleColor();
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip(array2[i] + "\nSpecies are sorted by their totals, and the monsters inside each one too.\nClick to sort, again to reverse.");
			}
		}
		List<Group> list = new List<Group>(dictionary.Values);
		list.Sort((Group a, Group b) => Compare(st, a.Kills, a.Avg, a.Fastest, a.Slowest, a.TotalSecs, a.Name, b.Kills, b.Avg, b.Fastest, b.Slowest, b.TotalSecs, b.Name));
		foreach (Group item in list)
		{
			ImGui.TableNextRow();
			ImGui.TableSetColumnIndex(0);
			if (st.OpenAll != 0)
			{
				ImGui.SetNextItemOpen(st.OpenAll > 0);
			}
			ImGui.PushStyleColor(ImGuiCol.Text, Yellow);
			bool flag = ImGui.TreeNodeEx(item.Name + " (" + item.Mobs.Count + ")##" + id + "sp" + item.Species, ImGuiTreeNodeFlags.SpanFullWidth);
			ImGui.PopStyleColor();
			Cells(item.Kills, item.Avg, item.Fastest, item.Slowest, item.TotalSecs, num, h);
			ImGui.TableSetColumnIndex(7);
			bool flag2 = item.Mobs.Count > 0 && item.Mobs.TrueForAll((MobStat m) => PackStats.IsOut(m.Name));
			bool v = flag2;
			if (ImGui.Checkbox("##out" + id + "sp" + item.Species, ref v))
			{
				foreach (MobStat mob in item.Mobs)
				{
					PackStats.SetOut(mob.Name, v);
				}
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Leave every " + item.Name + " here out of the Packs / Tuning numbers.");
			}
			if (!flag)
			{
				continue;
			}
			item.Mobs.Sort((MobStat a, MobStat b) => Compare(st, a.Kills, a.Avg, a.Fastest, a.Slowest, a.TotalSecs, a.Name, b.Kills, b.Avg, b.Fastest, b.Slowest, b.TotalSecs, b.Name));
			foreach (MobStat mob2 in item.Mobs)
			{
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				ImGui.Indent();
				bool v2 = PackStats.IsOut(mob2.Name);
				if (v2)
				{
					Im.TextDisabled(mob2.Name + "  (left out)");
				}
				else
				{
					ImGui.TextUnformatted(mob2.Name);
				}
				ImGui.Unindent();
				Cells(mob2.Kills, mob2.Avg, mob2.Fastest, mob2.Slowest, mob2.TotalSecs, num, h);
				ImGui.TableSetColumnIndex(7);
				if (ImGui.Checkbox("##out" + id + mob2.Name, ref v2))
				{
					PackStats.SetOut(mob2.Name, v2);
				}
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip(array2[7]);
				}
			}
			ImGui.TreePop();
		}
		ImGui.EndTable();
		st.OpenAll = 0;
	}

	private static AttrRow AttrByKey(string k)
	{
		AttrRow[] attrRows = AttrRows;
		foreach (AttrRow attrRow in attrRows)
		{
			if (string.Equals(attrRow.Key, k, StringComparison.OrdinalIgnoreCase) || string.Equals(attrRow.Key, "Max" + k, StringComparison.OrdinalIgnoreCase))
			{
				return attrRow;
			}
		}
		return null;
	}

	private static List<AttrRow> AttrOrder(Settings s)
	{
		List<AttrRow> list = new List<AttrRow>();
		string[] array = ((s != null && s.AttrOrder != null) ? s.AttrOrder : "").Split(',');
		foreach (string text in array)
		{
			AttrRow attrRow = AttrByKey(text.Trim());
			if (attrRow != null && !list.Contains(attrRow))
			{
				list.Add(attrRow);
			}
		}
		AttrRow[] attrRows = AttrRows;
		foreach (AttrRow item in attrRows)
		{
			if (!list.Contains(item))
			{
				list.Add(item);
			}
		}
		return list;
	}

	private static bool AttrOn(Settings s, AttrRow r)
	{
		return s != null && ("," + s.AttrOn + ",").IndexOf("," + r.Key + ",", StringComparison.OrdinalIgnoreCase) >= 0;
	}

	private static void AttrSetOn(Settings s, AttrRow r, bool on)
	{
		List<string> list = new List<string>();
		AttrRow[] attrRows = AttrRows;
		foreach (AttrRow attrRow in attrRows)
		{
			if ((attrRow == r) ? on : AttrOn(s, attrRow))
			{
				list.Add(attrRow.Key);
			}
		}
		s.AttrOn = string.Join(",", list.ToArray());
	}

	private static long Unassigned()
	{
		try
		{
			return CoreManager.Current.CharacterFilter.UnassignedXP;
		}
		catch
		{
			return 0L;
		}
	}

	private static int AttrBase(AttrRow r)
	{
		try
		{
			CharacterFilter characterFilter = CoreManager.Current.CharacterFilter;
			switch (r.Abbr)
			{
			case "str":
				return characterFilter.Attributes[CharFilterAttributeType.Strength].Base;
			case "end":
				return characterFilter.Attributes[CharFilterAttributeType.Endurance].Base;
			case "coo":
				return characterFilter.Attributes[CharFilterAttributeType.Coordination].Base;
			case "qui":
				return characterFilter.Attributes[CharFilterAttributeType.Quickness].Base;
			case "foc":
				return characterFilter.Attributes[CharFilterAttributeType.Focus].Base;
			case "sel":
				return characterFilter.Attributes[CharFilterAttributeType.Self].Base;
			case "hea":
				return characterFilter.Vitals[CharFilterVitalType.Health].Base;
			case "sta":
				return characterFilter.Vitals[CharFilterVitalType.Stamina].Base;
			case "man":
				return characterFilter.Vitals[CharFilterVitalType.Mana].Base;
			}
		}
		catch
		{
		}
		return -1;
	}

	private static long AttrCost(AttrRow r, int n)
	{
		if (n == 10 && r.Cost10 > 0)
		{
			return r.Cost10;
		}
		if (r.Cost <= 0)
		{
			return -1L;
		}
		double num = AttrGrowthFor(r);
		double num2 = r.Cost;
		double num3 = 0.0;
		for (int i = 0; i < n; i++)
		{
			num3 += num2;
			num2 *= num;
		}
		return (num3 > 9.223372036854776E+18) ? long.MaxValue : ((long)num3);
	}

	private static double AttrGrowthFor(AttrRow r)
	{
		if (r.Cost <= 0 || r.Cost10 <= 0)
		{
			return 1.077;
		}
		double num = (double)r.Cost10 / (double)r.Cost;
		if (num <= 10.0)
		{
			return 1.0;
		}
		double num2 = 1.0;
		double num3 = 3.0;
		for (int i = 0; i < 60; i++)
		{
			double num4 = (num2 + num3) / 2.0;
			double num5 = 0.0;
			double num6 = 1.0;
			for (int j = 0; j < 10; j++)
			{
				num5 += num6;
				num6 *= num4;
			}
			if (num5 < num)
			{
				num2 = num4;
			}
			else
			{
				num3 = num4;
			}
		}
		return (num2 + num3) / 2.0;
	}

	private static void AttrQueue(string cmd)
	{
		if (!_attrQ.Contains(cmd))
		{
			_attrQ.Add(cmd);
		}
		_attrAskedAt = DateTime.Now;
	}

	private static void AttrQueueTick()
	{
		if (_attrQ.Count != 0)
		{
			string command = _attrQ[0];
			_attrQ.RemoveAt(0);
			_attrQuietUntil = DateTime.Now.AddSeconds(4.0);
			Util.Command(command);
		}
	}

	private static void AttrAskOne(AttrRow r)
	{
		AttrQueue("/xp " + r.Abbr + " 1");
		AttrQueue("/xp " + r.Abbr + " 10");
	}

	private static void AttrAsk()
	{
		AttrQueue("/xp all");
		AttrRow[] attrRows = AttrRows;
		foreach (AttrRow attrRow in attrRows)
		{
			AttrQueue("/xp " + attrRow.Abbr + " 10");
		}
	}

	private static void AttrRaise(AttrRow r, int n)
	{
		n = Math.Max(1, Math.Min(10, n));
		Util.Command("/attr " + r.Abbr + " " + n.ToString(CultureInfo.InvariantCulture));
		r.Cost = 0L;
		r.Cost10 = 0L;
		_attrSentAt = DateTime.Now;
	}

	private static void AttrChat(string text)
	{
		string input = text.Trim();
		Match match = AttrCostRx.Match(input);
		if (match.Success)
		{
			AttrRow attrRow = AttrByKey(match.Groups[2].Value);
			if (attrRow != null && int.TryParse(match.Groups[1].Value, out var result) && long.TryParse(match.Groups[3].Value.Replace(",", ""), NumberStyles.Integer, CultureInfo.InvariantCulture, out var result2))
			{
				switch (result)
				{
				case 1:
					attrRow.Cost = result2;
					break;
				case 10:
					attrRow.Cost10 = result2;
					break;
				}
				attrRow.CostAt = DateTime.Now;
			}
		}
		else if (AttrRaisedRx.IsMatch(input))
		{
			AttrRow attrRow2 = AttrByKey(AttrRaisedRx.Match(input).Groups[1].Value);
			if (_attrWaitRaise)
			{
				_attrWaitRaise = false;
				_attrNextStep = DateTime.Now.AddMilliseconds(400.0);
			}
			if (attrRow2 != null && (DateTime.Now - _attrSentAt).TotalSeconds < 8.0)
			{
				AttrAskOne(attrRow2);
			}
		}
	}

	private static bool AttrQuiet(string s)
	{
		if (DateTime.Now > _attrQuietUntil)
		{
			return false;
		}
		if (s.StartsWith("[XP]", StringComparison.OrdinalIgnoreCase))
		{
			_attrQuietUntil = DateTime.Now.AddSeconds(2.0);
			return true;
		}
		return false;
	}

	public static void AttrSpendNow()
	{
		if (!_attrSpending)
		{
			_attrSpending = true;
			_attrWaitRaise = false;
			_attrSpentLevels = 0;
			_attrSpentNote = "";
			_attrStatus = "reading the costs";
			AttrAsk();
			_attrNextStep = DateTime.Now.AddSeconds(2.5);
		}
	}

	private static void AttrStop(string why)
	{
		if (_attrSpending)
		{
			_attrSpending = false;
			_attrWaitRaise = false;
			_attrStatus = why + ((_attrSpentLevels > 0) ? (" - raised " + _attrSpentNote.TrimEnd(new char[2] { ',', ' ' })) : "");
			if (_attrSpentLevels > 0)
			{
				Util.WriteToChat("Attributes: raised " + _attrSpentNote.TrimEnd(new char[2] { ',', ' ' }) + ".");
			}
			AttrAsk();
		}
	}

	private static void AttrTick()
	{
		Settings currentSettings = PluginCore.CurrentSettings;
		if (currentSettings == null)
		{
			return;
		}
		AttrQueueTick();
		if (!_attrSpending)
		{
			if (currentSettings.AttrAuto && DateTime.Now >= _attrNextAuto)
			{
				_attrNextAuto = DateTime.Now.AddMinutes(Math.Max(1, currentSettings.AttrIntervalMin));
				AttrSpendNow();
			}
		}
		else
		{
			if (DateTime.Now < _attrNextStep || _attrQ.Count > 0)
			{
				return;
			}
			if (_attrWaitRaise)
			{
				if ((DateTime.Now - _attrSentAt).TotalSeconds > 6.0)
				{
					AttrStop("the server didn't answer the raise");
				}
				return;
			}
			long num = Unassigned();
			foreach (AttrRow item in AttrOrder(currentSettings))
			{
				if (!AttrOn(currentSettings, item))
				{
					continue;
				}
				if (item.Cost <= 0)
				{
					if ((DateTime.Now - _attrAskedAt).TotalSeconds > 5.0)
					{
						AttrAskOne(item);
						_attrNextStep = DateTime.Now.AddSeconds(1.5);
						return;
					}
				}
				else
				{
					if (item.Cost > num)
					{
						continue;
					}
					int num2 = 1;
					for (int num3 = 10; num3 > 1; num3--)
					{
						if (AttrCost(item, num3) <= num)
						{
							num2 = num3;
							break;
						}
					}
					_attrStatus = "raising " + item.Name + " +" + num2;
					_attrSpentLevels += num2;
					_attrSpentNote = _attrSpentNote + item.Name + " +" + num2 + ", ";
					AttrRaise(item, num2);
					_attrWaitRaise = true;
					return;
				}
			}
			AttrStop((num > 0) ? "can't pay for the next level of any ticked one" : "no unassigned XP");
		}
	}

	private static string XpBig(long v)
	{
		return (v < 0) ? "?" : Lum(v);
	}

	private static void DrawAttr()
	{
		Settings currentSettings = PluginCore.CurrentSettings;
		if (currentSettings == null)
		{
			return;
		}
		Vector4 vector = new Vector4(0.45f, 0.9f, 0.45f, 1f);
		Vector4 col = new Vector4(1f, 0.5f, 0.45f, 1f);
		Vector4 vector2 = new Vector4(0.6f, 0.6f, 0.6f, 1f);
		bool flag = false;
		AttrRow[] attrRows = AttrRows;
		foreach (AttrRow attrRow in attrRows)
		{
			if (attrRow.Cost > 0)
			{
				flag = true;
			}
		}
		if (!flag && !_attrSpending && (DateTime.Now - _attrAskedAt).TotalSeconds > 30.0)
		{
			AttrAsk();
		}
		long num = Unassigned();
		int num2 = 0;
		long v = 0L;
		try
		{
			num2 = CoreManager.Current.CharacterFilter.Level;
			v = CoreManager.Current.CharacterFilter.TotalXP;
		}
		catch
		{
		}
		if (ImGui.Button("Refresh costs##attrref"))
		{
			AttrAsk();
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Sends /xp all quietly - the server's cost for the next level of each.");
		}
		ImGui.SameLine();
		Im.TextColored(Cyan, "Level " + num2 + "   Total XP " + XpBig(v) + "   Unassigned " + XpBig(num));
		bool flag2 = false;
		flag2 |= ImGui.Checkbox("Auto spend##attrauto", ref currentSettings.AttrAuto);
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Every so many minutes: reads the costs, then raises the ticked ones in the order below -\nthe first one the XP pays for (10 levels at a time when it can, else 1), again and again until it can't pay for any.");
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		if (ImGui.InputInt("every (min)##attrint", ref currentSettings.AttrIntervalMin, 1, 5))
		{
			if (currentSettings.AttrIntervalMin < 1)
			{
				currentSettings.AttrIntervalMin = 1;
			}
			flag2 = true;
			_attrNextAuto = DateTime.Now.AddMinutes(currentSettings.AttrIntervalMin);
		}
		ImGui.SameLine();
		if (_attrSpending)
		{
			if (ImGui.Button("Stop##attrstop"))
			{
				AttrStop("stopped");
			}
		}
		else if (ImGui.Button("Spend now##attrspend"))
		{
			AttrSpendNow();
		}
		if (currentSettings.AttrAuto && !_attrSpending)
		{
			ImGui.SameLine();
			Im.TextColored(vector2, "next in " + Math.Max(0, (int)(_attrNextAuto - DateTime.Now).TotalMinutes) + "m");
		}
		if (_attrStatus.Length > 0)
		{
			Im.TextColored(_attrSpending ? Yellow : vector2, _attrStatus);
		}
		List<AttrRow> list = AttrOrder(currentSettings);
		int num3 = -1;
		int num4 = 0;
		if (ImGui.BeginTable("##attrtbl", 6, ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("Auto");
			ImGui.TableSetupColumn("Order");
			ImGui.TableSetupColumn("Attribute", ImGuiTableColumnFlags.WidthStretch);
			ImGui.TableSetupColumn("Base");
			ImGui.TableSetupColumn("+1");
			ImGui.TableSetupColumn("+10");
			ImGui.TableHeadersRow();
			for (int j = 0; j < list.Count; j++)
			{
				AttrRow attrRow2 = list[j];
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				bool v2 = AttrOn(currentSettings, attrRow2);
				if (ImGui.Checkbox("##attron" + attrRow2.Abbr, ref v2))
				{
					AttrSetOn(currentSettings, attrRow2, v2);
					flag2 = true;
				}
				ImGui.TableSetColumnIndex(1);
				if (j == 0)
				{
					ImGui.BeginDisabled();
				}
				if (ImGui.ArrowButton("##attrup" + attrRow2.Abbr, ImGuiDir.Up))
				{
					num3 = j;
					num4 = -1;
				}
				if (j == 0)
				{
					ImGui.EndDisabled();
				}
				ImGui.SameLine();
				if (j == list.Count - 1)
				{
					ImGui.BeginDisabled();
				}
				if (ImGui.ArrowButton("##attrdn" + attrRow2.Abbr, ImGuiDir.Down))
				{
					num3 = j;
					num4 = 1;
				}
				if (j == list.Count - 1)
				{
					ImGui.EndDisabled();
				}
				ImGui.TableSetColumnIndex(2);
				ImGui.AlignTextToFramePadding();
				Im.Text(j + 1 + ". " + attrRow2.Name);
				ImGui.TableSetColumnIndex(3);
				ImGui.AlignTextToFramePadding();
				int num5 = AttrBase(attrRow2);
				Im.Text((num5 >= 0) ? num5.ToString(CultureInfo.InvariantCulture) : "?");
				long num6 = AttrCost(attrRow2, 1);
				long num7 = AttrCost(attrRow2, 10);
				ImGui.TableSetColumnIndex(4);
				if (num6 > 0 && num6 > num)
				{
					ImGui.PushStyleColor(ImGuiCol.Text, col);
				}
				if (ImGui.Button(((num6 > 0) ? XpBig(num6) : "?") + "##attr1" + attrRow2.Abbr, new Vector2(90f, 0f)) && !_attrSpending)
				{
					AttrRaise(attrRow2, 1);
				}
				if (num6 > 0 && num6 > num)
				{
					ImGui.PopStyleColor();
				}
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip("/attr " + attrRow2.Abbr + " 1" + ((num6 > 0) ? (" - " + num6.ToString("N0", CultureInfo.InvariantCulture) + " XP") : " (Refresh costs first)"));
				}
				ImGui.TableSetColumnIndex(5);
				if (num7 > 0 && num7 > num)
				{
					ImGui.PushStyleColor(ImGuiCol.Text, col);
				}
				if (ImGui.Button(((num7 > 0) ? (((attrRow2.Cost10 > 0) ? "" : "~") + XpBig(num7)) : "?") + "##attr10" + attrRow2.Abbr, new Vector2(90f, 0f)) && !_attrSpending)
				{
					AttrRaise(attrRow2, 10);
				}
				if (num7 > 0 && num7 > num)
				{
					ImGui.PopStyleColor();
				}
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip("/attr " + attrRow2.Abbr + " 10 - about " + ((num7 > 0) ? num7.ToString("N0", CultureInfo.InvariantCulture) : "?") + " XP (the server's figure)");
				}
			}
			ImGui.EndTable();
		}
		if (num3 >= 0)
		{
			AttrRow value = list[num3];
			list[num3] = list[num3 + num4];
			list[num3 + num4] = value;
			List<string> list2 = new List<string>();
			foreach (AttrRow item in list)
			{
				list2.Add(item.Key);
			}
			currentSettings.AttrOrder = string.Join(",", list2.ToArray());
			flag2 = true;
		}
		Im.TextColored(vector2, "Red = more than your unassigned XP (~ = estimated). The server raises at most 10 at a time.");
		if (flag2)
		{
			PluginCore.SaveAllNow();
		}
	}

	private static void DrawAugsTabs()
	{
		if (!ImGui.BeginTabBar("augtabs"))
		{
			return;
		}
		if (ImGui.BeginTabItem("All###augall"))
		{
			DrawAugs();
			ImGui.EndTabItem();
		}
		AugKind[] augKinds = AugKinds;
		foreach (AugKind augKind in augKinds)
		{
			if (ImGui.BeginTabItem(augKind.Tab + "###aug" + augKind.Tab))
			{
				DrawAugPage(augKind);
				ImGui.EndTabItem();
			}
		}
		if (ImGui.BeginTabItem("Skill Credits###augcredits"))
		{
			DrawSkillCredits();
			ImGui.EndTabItem();
		}
		ImGui.EndTabBar();
	}

	// ── Skill Credit Gems (the Ancient Statue of unknown origin, for Enlightened Coins; patch 11-21) ──
	// 1 credit 100 coins, 10x 1,000, 50x 5,000, 100x 10,000 - permanent credits, kept through enlightenment
	private static readonly int[] CreditGemSizes = new int[4] { 100, 50, 10, 1 };
	private const int CoinsPerCredit = 100;
	private static int _creditsWant = 10;
	private static string _creditStatus = "";
	private static List<int> _creditUseQueue;
	private static DateTime _creditUseNext = DateTime.MinValue;

	private static readonly Regex CreditGemRx = new Regex("^(?:(\\d+)x )?Skill Credit Gems?$", RegexOptions.IgnoreCase);

	private static int CreditGemSize(string name)
	{
		Match m = CreditGemRx.Match((name ?? "").Trim());
		if (!m.Success) return 0;
		int n = 1;
		if (m.Groups[1].Success) int.TryParse(m.Groups[1].Value, out n);
		return n;
	}

	private static Dictionary<int, WorldObject> VendorCreditGems()
	{
		Dictionary<int, WorldObject> d = new Dictionary<int, WorldObject>();
		try
		{
			Vendor v = CoreManager.Current.WorldFilter.OpenVendor;
			if (v == null || v.MerchantId == 0) return d;
			foreach (WorldObject o in v)
			{
				int n = CreditGemSize(o.Name);
				if (n > 0 && !d.ContainsKey(n)) d[n] = o;
			}
		}
		catch
		{
		}
		return d;
	}

	// the fewest gems for that many credits (all cost the same per credit)
	private static List<KeyValuePair<int, int>> CreditGemSplit(int credits)
	{
		List<KeyValuePair<int, int>> l = new List<KeyValuePair<int, int>>();
		foreach (int size in CreditGemSizes)
		{
			int k = credits / size;
			if (k > 0) l.Add(new KeyValuePair<int, int>(size, k));
			credits -= k * size;
		}
		return l;
	}

	private static List<WorldObject> CarriedCreditGems()
	{
		List<WorldObject> l = new List<WorldObject>();
		try
		{
			foreach (WorldObject o in CoreManager.Current.WorldFilter.GetInventory())
				if (CreditGemSize(o.Name) > 0) l.Add(o);
		}
		catch
		{
		}
		return l;
	}

	// "You gain 1 skill credit for good: skill credits from gems stay with you through enlightenment." - counted as each
	// gem is used (/aug doesn't list them), kept per character
	private static readonly Regex GemCreditRx = new Regex("^You gain ([\\d,]+) skill credits? for good", RegexOptions.IgnoreCase);
	private static long _gemCredits = -1;

	private static string GemCreditFile => (_augFile == null) ? null : _augFile.Replace("MelkTank_Augs_", "MelkTank_SkillCredits_");

	private static long GemCredits()
	{
		if (_gemCredits >= 0)
		{
			return _gemCredits;
		}
		_gemCredits = 0;
		try
		{
			string f = GemCreditFile;
			if (f != null && File.Exists(f) && long.TryParse(File.ReadAllText(f).Trim(), out var n))
			{
				_gemCredits = n;
			}
		}
		catch
		{
		}
		return _gemCredits;
	}

	/// <summary>/mtank credits N - sets the skill credits bought from gems (ones used before they were counted).</summary>
	public static string SetGemCredits(string arg)
	{
		if (!long.TryParse(arg.Replace(",", ""), out var n) || n < 0)
		{
			return "skill credits bought from gems: " + GemCredits().ToString("N0") + " (/mtank credits N to set it).";
		}
		_gemCredits = n;
		try
		{
			string f = GemCreditFile;
			if (f != null)
			{
				Util.Locked(f, () => File.WriteAllText(f, n.ToString()));
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		return "skill credits bought from gems set to " + n.ToString("N0") + ".";
	}

	private static void GemCreditChat(string text)
	{
		Match m = GemCreditRx.Match(text.Trim());
		if (!m.Success || !long.TryParse(m.Groups[1].Value.Replace(",", ""), out var n))
		{
			return;
		}
		_gemCredits = GemCredits() + n;
		try
		{
			string f = GemCreditFile;
			if (f != null)
			{
				Util.Locked(f, () => File.WriteAllText(f, _gemCredits.ToString()));
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	// the skill credits bought so far: counted from the gems used here (or /aug's line, should it ever list them)
	private static long CreditsBought()
	{
		long counted = GemCredits();
		foreach (KeyValuePair<string, string> aug in _augs)
		{
			if (aug.Key.IndexOf("Skill Credit", StringComparison.OrdinalIgnoreCase) < 0) continue;
			Match m = Regex.Match(aug.Value ?? "", "[\\d,]+");
			if (m.Success && long.TryParse(m.Value.Replace(",", ""), out var n)) return Math.Max(n, counted);
		}
		return counted;
	}

	private static void DrawSkillCredits()
	{
		if (ImGui.Button("Check /aug + /bank##skillcredits"))
		{
			QuietNext("/aug");
			Util.Command("/aug");
			QuietNext("/bank");
			Util.Command("/bank");
		}
		long bought = CreditsBought();
		long lum = BankLuminance();
		long coins = BankCount("Enlightened Coins");
		double coinLum = CoinLum();
		double rate = (LumPerHourRecent > 0.0) ? LumPerHourRecent : LumPerHour;
		try
		{
			double tr = (PluginCore.CurrentSettings == null || PluginCore.CurrentSettings.AugRatesFromTracker) ? TrackerRate() : (-1.0);
			if (tr > 0.0) rate = tr;
		}
		catch
		{
		}
		ImGui.SameLine();
		Im.TextColored(Cyan, "Skill credits bought " + bought.ToString("N0"));
		if (ImGui.IsItemHovered()) Im.SetTooltip("Counted from \"You gain N skill credit for good\" as each gem is used (/aug doesn't list them), kept for this character.\nGems used before this build weren't counted - set the count with /mtank credits N.");
		ImGui.SameLine();
		Im.Text("   Luminance " + ((lum >= 0) ? Big(lum) : "?") + "   Coins " + ((coins >= 0) ? coins.ToString("N0") : "?") + "   1 coin = " + ((coinLum > 0.0) ? Big(coinLum) : "?") + " lum");
		Im.TextDisabled("Skill Credit Gems: the Ancient Statue of unknown origin, " + CoinsPerCredit + " Enlightened Coins a credit. Permanent - kept through every enlightenment.");
		if (ImGui.BeginTable("augcostcredits", 6, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("Gem", ImGuiTableColumnFlags.WidthFixed, 40f);
			ImGui.TableSetupColumn("Credits", ImGuiTableColumnFlags.WidthFixed, 60f);
			ImGui.TableSetupColumn("Coins", ImGuiTableColumnFlags.WidthFixed, 70f);
			ImGui.TableSetupColumn("Coin lum", ImGuiTableColumnFlags.WidthFixed, 150f);
			ImGui.TableSetupColumn("When", ImGuiTableColumnFlags.WidthStretch);
			ImGui.TableSetupColumn("In your pack", ImGuiTableColumnFlags.WidthFixed, 80f);
			ImGui.TableHeadersRow();
			List<WorldObject> carried = CarriedCreditGems();
			foreach (int size in GemSizes)
			{
				long need = (long)size * CoinsPerCredit;
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				ImGui.TextUnformatted(size + "x");
				ImGui.TableSetColumnIndex(1);
				ImGui.TextUnformatted(size.ToString("N0"));
				ImGui.TableSetColumnIndex(2);
				Im.TextColored((coins >= need) ? AugGreen : AugYellow, need.ToString("N0"));
				ImGui.TableSetColumnIndex(3);
				ImGui.TextUnformatted((coinLum > 0.0) ? ((double)need * coinLum).ToString("N0") : "?");
				if (ImGui.IsItemHovered()) Im.SetTooltip(need.ToString("N0") + " coins x " + Big(coinLum) + " lum (Session > Lum's buying rate)");
				ImGui.TableSetColumnIndex(4);
				WhenText(0L, need, lum, coins, coinLum, rate);
				ImGui.TableSetColumnIndex(5);
				List<WorldObject> mine = carried.FindAll((WorldObject o) => CreditGemSize(o.Name) == size);
				if (mine.Count == 0)
				{
					Im.TextDisabled("none");
				}
				else if (ImGui.SmallButton("Use (" + mine.Count + ")##usesc" + size))
				{
					try
					{
						Globals.Core.Actions.UseItem(mine[0].Id, 0);
						Util.WriteToChat("Augs: using " + mine[0].Name + "...");
						_augRecheckAt = DateTime.Now.AddSeconds(2.5);
					}
					catch (Exception ex)
					{
						Util.WriteToChat("Augs: " + ex.Message);
					}
				}
			}
			ImGui.EndTable();
		}
		// the goal: credits bought to reach, what it costs, and buying it at the statue
		Im.Text("Goal credits");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(100f);
		if (!_augGoal.TryGetValue("Skill Credits", out var goalText)) goalText = "";
		if (ImGui.InputText("##goalcredits", ref goalText, 12u, ImGuiInputTextFlags.CharsDecimal)) _augGoal["Skill Credits"] = goalText;
		if (long.TryParse(goalText.Replace(",", ""), out var goal) && goal > 0)
		{
			ImGui.SameLine();
			if (goal <= bought)
			{
				Im.TextDisabled("already there");
			}
			else
			{
				long more = goal - bought;
				long cost = more * CoinsPerCredit;
				Im.Text("+" + more.ToString("N0") + " credits: " + cost.ToString("N0") + " coins" + ((coinLum > 0.0) ? (" = " + Big(cost * coinLum) + " lum") : "") + "   ");
				ImGui.SameLine();
				WhenText(0L, cost, lum, coins, coinLum, rate);
				List<KeyValuePair<int, int>> split = CreditGemSplit((int)Math.Min(more, 1000000L));
				Dictionary<int, WorldObject> sold = VendorCreditGems();
				bool open = sold.Count > 0, enough = coins < 0 || coins >= cost;
				ImGui.SameLine();
				if (!open || !enough) ImGui.BeginDisabled();
				if (ImGui.SmallButton("Buy##scbuy"))
				{
					try
					{
						HooksWrapper actions = CoreManager.Current.Actions;
						actions.VendorClearBuyList();
						foreach (KeyValuePair<int, int> x in split)
							if (sold.TryGetValue(x.Key, out var g)) actions.VendorAddBuyList(g.Id, x.Value);
						actions.VendorBuyAll();
						_creditStatus = "asked to buy " + string.Join(", ", split.ConvertAll((KeyValuePair<int, int> x) => x.Value + " x " + x.Key + "x").ToArray());
						_bankRecheckAt = DateTime.Now.AddSeconds(2.0);
					}
					catch (Exception ex)
					{
						_creditStatus = "buy failed: " + ex.Message;
					}
				}
				if (!open || !enough) ImGui.EndDisabled();
				if (ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenDisabled))
					Im.SetTooltip((!open ? "Open the Ancient Statue of unknown origin's shop first.\n" : (!enough ? "Not enough Enlightened Coins banked.\n" : "")) + "Buys " + string.Join(", ", split.ConvertAll((KeyValuePair<int, int> x) => x.Value + " x " + x.Key + "x gem").ToArray()) + " (the fewest gems for that many credits).");
			}
		}
		if (_creditStatus.Length > 0) Im.TextDisabled(_creditStatus);
		Im.TextDisabled("No soft caps known for this one. Specialized Skill Aug Gems no longer give skill credits.");
	}

	// one gem used a second, until the queue's done (a stack: the same gem again while some are left)
	private static void CreditUseTick()
	{
		if (_creditUseQueue == null || _creditUseQueue.Count == 0 || DateTime.Now < _creditUseNext) return;
		int id = _creditUseQueue[0];
		_creditUseQueue.RemoveAt(0);
		_creditUseNext = DateTime.Now.AddSeconds(1.0);
		try
		{
			WorldObject o = CoreManager.Current.WorldFilter[id];
			if (o == null)
			{
				_creditUseQueue.RemoveAll((int x) => x == id);
				return;
			}
			CoreManager.Current.Actions.UseItem(id, 0);
			if (_creditUseQueue.Count == 0) _creditStatus = "used the gems";
		}
		catch (Exception ex)
		{
			_creditUseQueue.Clear();
			_creditStatus = "use failed: " + ex.Message;
		}
	}

	private static void AugsTick()
	{
		if (!(_augRecheckAt == DateTime.MinValue) && !(DateTime.Now < _augRecheckAt))
		{
			_augRecheckAt = DateTime.MinValue;
			QuietNext("/aug");
			Util.Command("/aug");
			QuietNext("/bank");
			Util.Command("/bank");
		}
	}

	private static long AugLevel(AugKind k)
	{
		foreach (KeyValuePair<string, string> aug in _augs)
		{
			if (string.Equals(aug.Key, k.Key, StringComparison.OrdinalIgnoreCase))
			{
				string text = aug.Value;
				int num = text.IndexOf(' ');
				if (num > 0)
				{
					text = text.Substring(0, num);
				}
				if (long.TryParse(text.Replace(",", ""), out var result))
				{
					return result;
				}
			}
		}
		return -1L;
	}

	public static int EligibleTier()
	{
		long num = -1L;
		long num2 = -1L;
		long num3 = -1L;
		AugKind[] augKinds = AugKinds;
		foreach (AugKind augKind in augKinds)
		{
			if (augKind.Key == "Creature")
			{
				num = AugLevel(augKind);
			}
			else if (augKind.Key == "Life")
			{
				num2 = AugLevel(augKind);
			}
			else if (augKind.Key == "Item")
			{
				num3 = AugLevel(augKind);
			}
		}
		if (num < 0 || num2 < 0 || num3 < 0)
		{
			return -1;
		}
		long num4 = Math.Min((num - 4000) / 500, Math.Min((num2 - 2000) / 500, (num3 - 2000) / 500));
		if (num < 4000 || num2 < 2000 || num3 < 2000)
		{
			return 0;
		}
		return (int)Math.Min(25L, 11 + num4);
	}

	/// <summary>Luminance in the bank as /bank last said (-1: not read yet).</summary>
	public static long BankedLum { get { long v = BankLuminance(); return (v > 0 || _bank.Exists(b => string.Equals(b.Name, "Luminance", StringComparison.OrdinalIgnoreCase))) ? v : -1; } }

	/// <summary>Enlightened Coins in the bank as /bank last said (-1: not read yet).</summary>
	public static long BankedCoins { get { long v = BankCount("Enlightened Coins"); return (v > 0 || _bank.Exists(b => string.Equals(b.Name, "Enlightened Coins", StringComparison.OrdinalIgnoreCase))) ? v : -1; } }

	private static long BankLuminance()
	{
		foreach (BankLine item in _bank)
		{
			if (string.Equals(item.Name, "Luminance", StringComparison.OrdinalIgnoreCase))
			{
				string text = item.Value;
				int num = text.IndexOf(' ');
				if (num > 0)
				{
					text = text.Substring(0, num);
				}
				if (long.TryParse(text.Replace(",", ""), out var result))
				{
					return result;
				}
			}
		}
		return -1L;
	}

	private static long AugMultiplier(AugKind k, long target)
	{
		if (k.Caps == null)
		{
			return 1L;
		}
		long[] array = new long[4] { 4L, 8L, 16L, 24L };
		long result = 1L;
		for (int i = 0; i < k.Caps.Length && i < array.Length; i++)
		{
			if (target > k.Caps[i])
			{
				result = array[i];
			}
		}
		return result;
	}

	private static long LevelBase(AugKind k, long target)
	{
		if (k.Tab == "Specialization")
		{
			return 9025000 * (target - 1);
		}
		return 1650000 * target - 650000;
	}

	private static long AugCost(AugKind k, long from, long levels)
	{
		double num = AugScale(k);
		return (long)Math.Round((double)AugCostRaw(k, from, levels) * num);
	}

	private static long AugCostRaw(AugKind k, long from, long levels)
	{
		long num = 0L;
		for (long num2 = 1L; num2 <= levels; num2++)
		{
			num += AugMultiplier(k, from + num2) * LevelBase(k, from + num2);
		}
		return num;
	}

	private static double AugScale(AugKind k)
	{
		if (!AugQuotes.TryGetValue(k.Key, out var value))
		{
			return 1.0;
		}
		long num = AugCostRaw(k, value.Level, value.Levels);
		return (num > 0) ? ((double)value.Lum / (double)num) : 1.0;
	}

	public static void NoteConfirmText(string text)
	{
		try
		{
			Match match = AugQuoteRx.Match(text ?? "");
			if (!match.Success)
			{
				return;
			}
			long lum = long.Parse(match.Groups[1].Value.Replace(",", ""));
			long num = long.Parse(match.Groups[2].Value.Replace(",", ""));
			string value = match.Groups[3].Value;
			AugKind augKind = null;
			AugKind[] augKinds = AugKinds;
			foreach (AugKind augKind2 in augKinds)
			{
				if (value.IndexOf(augKind2.Gem, StringComparison.OrdinalIgnoreCase) >= 0 || value.IndexOf(augKind2.Key, StringComparison.OrdinalIgnoreCase) >= 0)
				{
					augKind = augKind2;
					break;
				}
			}
			if (augKind == null)
			{
				return;
			}
			long num2 = AugLevel(augKind);
			if (num2 < 0 || num <= 0)
			{
				return;
			}
			AugQuotes[augKind.Key] = new AugQuote
			{
				Level = num2,
				Levels = num,
				Lum = lum
			};
			List<string> list = new List<string>();
			foreach (KeyValuePair<string, AugQuote> augQuote in AugQuotes)
			{
				list.Add(augQuote.Key + "|" + augQuote.Value.Level + "|" + augQuote.Value.Levels + "|" + augQuote.Value.Lum);
			}
			try
			{
				File.WriteAllLines(AugQuoteFile, list.ToArray());
			}
			catch
			{
			}
		}
		catch
		{
		}
	}

	private static List<WorldObject> Gems(AugKind k, int size)
	{
		List<WorldObject> list = new List<WorldObject>();
		string value = ((size == 1) ? "" : (size + "x "));
		foreach (WorldObject item in InvCache.All())
		{
			string text = item.Name ?? "";
			if (text.EndsWith("Augmentation Gem", StringComparison.OrdinalIgnoreCase) && !text.StartsWith("Boxed", StringComparison.OrdinalIgnoreCase) && text.IndexOf(k.Gem, StringComparison.OrdinalIgnoreCase) >= 0)
			{
				bool flag = Regex.IsMatch(text, "^\\d+x ");
				if (!((size == 1) ? flag : (!text.StartsWith(value, StringComparison.OrdinalIgnoreCase))))
				{
					list.Add(item);
				}
			}
		}
		return list;
	}

	private static Dictionary<int, WorldObject> VendorGems(AugKind k)
	{
		Dictionary<int, WorldObject> dictionary = new Dictionary<int, WorldObject>();
		try
		{
			Vendor openVendor = CoreManager.Current.WorldFilter.OpenVendor;
			if (openVendor == null || openVendor.MerchantId == 0)
			{
				return dictionary;
			}
			foreach (WorldObject item in openVendor)
			{
				string text = item.Name ?? "";
				if (text.EndsWith("Augmentation Gem", StringComparison.OrdinalIgnoreCase) && !text.StartsWith("Boxed", StringComparison.OrdinalIgnoreCase) && text.IndexOf(k.Gem, StringComparison.OrdinalIgnoreCase) >= 0)
				{
					int result = 1;
					Match match = Regex.Match(text, "^(\\d+)x ");
					if (match.Success)
					{
						int.TryParse(match.Groups[1].Value, out result);
					}
					if (result > 0 && !dictionary.ContainsKey(result))
					{
						dictionary[result] = item;
					}
				}
			}
		}
		catch
		{
		}
		return dictionary;
	}

	private static long HeldGemLevels(AugKind k)
	{
		long num = 0L;
		int[] gemSizes = GemSizes;
		foreach (int num2 in gemSizes)
		{
			foreach (WorldObject item in Gems(k, num2))
			{
				int num3 = 1;
				try
				{
					num3 = Math.Max(1, item.Values(LongValueKey.StackCount, 1));
				}
				catch
				{
				}
				num += (long)num2 * (long)num3;
			}
		}
		return num;
	}

	private static long LevelsFor(AugKind k, long level, long lum)
	{
		long num = 0L;
		long num2 = 0L;
		for (; num < 100000; num++)
		{
			long num3 = AugMultiplier(k, level + num + 1) * LevelBase(k, level + num + 1);
			if (num2 + num3 > lum)
			{
				break;
			}
			num2 += num3;
		}
		return num;
	}

	private static void DrawAugBuy(AugKind k, long level, long lum, long coinsHave)
	{
		Dictionary<int, WorldObject> dictionary = VendorGems(k);
		if (dictionary.Count == 0)
		{
			return;
		}
		long num = HeldGemLevels(k);
		Settings currentSettings = PluginCore.CurrentSettings;
		bool flag = k.Tab == "Specialization";
		if (!flag && currentSettings != null && currentSettings.AugNoSingles && dictionary.Count > 1)
		{
			dictionary.Remove(1);
		}
		Im.Text("Vendor:");
		ImGui.SameLine();
		if (lum < 0)
		{
			Im.TextDisabled("luminance not known - check /bank");
		}
		else
		{
			long num2 = LevelsFor(k, level, lum);
			long need = Math.Max(0L, num2 - num);
			AugBuyButton(k, dictionary, need, "lum", level + num, "As many levels as your bank luminance (" + Big(lum) + ") pays to use: " + num2.ToString("N0") + ((num > 0) ? (", less the " + num.ToString("N0") + " in gems you carry") : "") + ".", (num2 <= num) ? ("your luminance pays for " + num2.ToString("N0") + " levels" + ((num > 0) ? (" - you carry gems for " + num.ToString("N0")) : "")) : null);
		}
		ImGui.SameLine(0f, 24f);
		if (coinsHave < 0 || k.Coins <= 0)
		{
			Im.TextDisabled("coins not known - check /bank");
		}
		else
		{
			long num3 = coinsHave / k.Coins;
			AugBuyButton(k, dictionary, num3, "coins", level + num, "As many levels as your bank coins (" + coinsHave.ToString("N0") + ") buy, at " + k.Coins + " coins a level: " + num3.ToString("N0") + ".", (num3 <= 0) ? ("not enough coins for one level (" + k.Coins + ")") : null);
		}
		if (!flag && currentSettings != null)
		{
			ImGui.SameLine(0f, 24f);
			if (ImGui.Checkbox("No singles##augns", ref currentSettings.AugNoSingles))
			{
				PluginCore.SaveAllNow();
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Don't buy 1-level gems: only 10x and up (what's left under 10 isn't bought).\nEvery tab except Specialization, which always buys singles.");
			}
		}
	}

	private static void AugBuyButton(AugKind k, Dictionary<int, WorldObject> vg, long need, string tag, long fromLevel, string why, string nothing)
	{
		List<int> list = new List<int>(vg.Keys);
		list.Sort((int x, int y) => y.CompareTo(x));
		List<KeyValuePair<WorldObject, int>> list2 = new List<KeyValuePair<WorldObject, int>>();
		List<string> list3 = new List<string>();
		long num = need;
		foreach (int item in list)
		{
			long num2 = num / item;
			if (num2 > 0)
			{
				list2.Add(new KeyValuePair<WorldObject, int>(vg[item], (int)Math.Min(num2, 2147483647L)));
				list3.Add(num2.ToString("N0") + " x " + ((item == 1) ? "1" : (item + "x")));
				num -= num2 * item;
			}
		}
		long num3 = need - num;
		if (num3 <= 0)
		{
			Im.TextDisabled("(" + tag + ": " + (nothing ?? "nothing to buy") + ")");
			return;
		}
		if (ImGui.Button("Buy " + num3.ToString("N0") + " levels (" + tag + ")##augbuy" + tag + k.Tab))
		{
			try
			{
				HooksWrapper actions = CoreManager.Current.Actions;
				actions.VendorClearBuyList();
				foreach (KeyValuePair<WorldObject, int> item2 in list2)
				{
					actions.VendorAddBuyList(item2.Key.Id, item2.Value);
				}
				actions.VendorBuyAll();
				Util.WriteToChat("Augs: buying " + string.Join(", ", list3.ToArray()) + " " + k.Gem + " gems (" + num3.ToString("N0") + " levels).");
				_augRecheckAt = DateTime.Now.AddSeconds(2.5);
			}
			catch (Exception ex)
			{
				Util.WriteToChat("Augs: " + ex.Message);
			}
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip(why + "\nGems: " + string.Join(" + ", list3.ToArray()) + "\nUsing them costs " + Big(AugCost(k, fromLevel, num3)) + " luminance, buying them " + (num3 * k.Coins).ToString("N0") + " coins.");
		}
	}

	private static string Eta(double hours)
	{
		if (hours < 1.0)
		{
			return "~" + Math.Max(1, (int)Math.Round(hours * 60.0)) + "m";
		}
		if (hours < 24.0)
		{
			return "~" + Math.Round(hours, 1) + "h";
		}
		int num = (int)(hours / 24.0);
		return "~" + num + "d " + (int)Math.Round(hours - (double)num * 24.0) + "h";
	}

	// Session > Lum's conversion: the luminance a coin costs (buying one)
	private static double CoinLum()
	{
		return LumTrack.LumPerCoinBuy;
	}

	// Session > Lum's effective lum/hr (coins earned counted as luminance)
	private static double TrackerRate()
	{
		double r = LumTrack.EffectiveLumPerHour;
		return (r > 0.0) ? r : (-1.0);
	}

	// Session > Lum's lum/hr (with turn-ins that give luminance)
	private static double TrackerLumRate()
	{
		double r = LumTrack.LumPerHour;
		return (r > 0.0) ? r : (-1.0);
	}

	private static long BankCount(string name)
	{
		foreach (BankLine item in _bank)
		{
			if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
			{
				string text = item.Value;
				int num = text.IndexOf(' ');
				if (num > 0)
				{
					text = text.Substring(0, num);
				}
				if (long.TryParse(text.Replace(",", ""), out var result))
				{
					return result;
				}
			}
		}
		return -1L;
	}

	private static void WhenText(long lumCost, long coins, long lumHave, long coinsHave, double coinLum, double rate)
	{
		if (lumHave < 0)
		{
			Im.TextDisabled("Check /bank");
			return;
		}
		double num = ((coinsHave >= 0) ? Math.Max(0L, coins - coinsHave) : coins);
		double num2 = (double)lumCost + ((coinLum > 0.0) ? (num * coinLum) : 0.0);
		if (num > 0.0 && coinLum <= 0.0)
		{
			Im.TextDisabled("short " + num.ToString("N0") + " coins");
		}
		else if ((double)lumHave >= num2)
		{
			Im.TextColored(AugGreen, (num > 0.0) ? ("now (buying " + num.ToString("N0") + " coins)") : "now");
		}
		else if (rate <= 0.0)
		{
			Im.TextDisabled("short " + Big(num2 - (double)lumHave));
		}
		else
		{
			Im.TextColored(AugYellow, Eta((num2 - (double)lumHave) / rate) + "  (short " + Big(num2 - (double)lumHave) + ")");
		}
	}

	private static void LumWhen(long lumCost, long lumHave, double lumRate)
	{
		if (lumHave < 0)
		{
			Im.TextDisabled("Check /bank");
			return;
		}
		if (lumHave >= lumCost)
		{
			Im.TextColored(AugGreen, "now");
			return;
		}
		if (lumRate <= 0.0)
		{
			Im.TextDisabled("short " + Big(lumCost - lumHave));
			return;
		}
		Im.TextColored(AugYellow, Eta((double)(lumCost - lumHave) / lumRate));
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Short " + Big(lumCost - lumHave) + " luminance, at " + Big(lumRate) + " lum/hr (luminance only).");
		}
	}

	private static void DrawAugPage(AugKind k)
	{
		if (ImGui.Button("Check /aug + /bank##" + k.Tab))
		{
			QuietNext("/aug");
			Util.Command("/aug");
			QuietNext("/bank");
			Util.Command("/bank");
		}
		long num = AugLevel(k);
		long num2 = BankLuminance();
		long num3 = BankCount("Enlightened Coins");
		bool flag = PluginCore.CurrentSettings == null || PluginCore.CurrentSettings.AugRatesFromTracker;
		double num4 = CoinLum();
		double num5 = (flag ? TrackerRate() : (-1.0));
		double num6;
		if (num5 > 0.0)
		{
			num6 = num5;
		}
		else
		{
			num6 = ((LumPerHourRecent > 0.0) ? LumPerHourRecent : LumPerHour);
		}
		double num7 = (flag ? TrackerLumRate() : (-1.0));
		double lumRate;
		if (num7 > 0.0)
		{
			lumRate = num7;
		}
		else
		{
			lumRate = ((LumPerHourRecent > 0.0) ? LumPerHourRecent : LumPerHour);
		}
		ImGui.SameLine();
		Im.TextColored(Cyan, k.Tab + " level " + ((num >= 0) ? num.ToString("N0") : "?"));
		ImGui.SameLine();
		Im.Text("   Luminance " + ((num2 >= 0) ? Big(num2) : "?") + "   Coins " + ((num3 >= 0) ? num3.ToString("N0") : "?") + "   1 coin = " + ((num4 > 0.0) ? Big(num4) : "?") + " lum   " + ((num6 > 0.0) ? (Big(num6) + "/hr" + ((num5 > 0.0) ? " (tracker, effective)" : " (MelkTank)")) : ""));
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("1 coin: Session > Lum's buying rate (Settings there, shared by every character).\n/hr: " + (flag ? "Session > Lum's effective lum/hr (luminance + coins earned, as luminance); When (lum) uses its lum/hr." : "MelkTank's own lum/hr (Session: last 60 min, else the whole session) for both When columns.") + "\nSwitch it in Settings > Basic > Areas.");
		}
		if (num < 0)
		{
			Im.TextDisabled("Level not known yet - click Check.");
			return;
		}
		DrawAugBuy(k, num, num2, num3);
		if (ImGui.BeginTable("augcost" + k.Tab, 8, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("Gem", ImGuiTableColumnFlags.WidthFixed, 40f);
			ImGui.TableSetupColumn("Luminance", ImGuiTableColumnFlags.WidthFixed, 140f);
			ImGui.TableSetupColumn("When (lum)", ImGuiTableColumnFlags.WidthFixed, 180f);
			ImGui.TableSetupColumn("Coins", ImGuiTableColumnFlags.WidthFixed, 55f);
			ImGui.TableSetupColumn("Coin lum", ImGuiTableColumnFlags.WidthFixed, 140f);
			ImGui.TableSetupColumn("Total lum", ImGuiTableColumnFlags.WidthFixed, 140f);
			ImGui.TableSetupColumn("When (all)", ImGuiTableColumnFlags.WidthStretch);
			ImGui.TableSetupColumn("In your pack", ImGuiTableColumnFlags.WidthFixed, 80f);
			ImGui.TableHeadersRow();
			int[] gemSizes = GemSizes;
			for (int i = 0; i < gemSizes.Length; i++)
			{
				int num8 = gemSizes[i];
				long num9 = AugCost(k, num, num8);
				long num10 = (long)k.Coins * (long)num8;
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				ImGui.TextUnformatted(num8 + "x");
				ImGui.TableSetColumnIndex(1);
				ImGui.TextUnformatted(num9.ToString("N0"));
				ImGui.TableSetColumnIndex(2);
				LumWhen(num9, num2, lumRate);
				ImGui.TableSetColumnIndex(3);
				Im.TextColored((num3 >= num10) ? AugGreen : AugYellow, num10.ToString("N0"));
				ImGui.TableSetColumnIndex(4);
				ImGui.TextUnformatted((num4 > 0.0) ? ((double)num10 * num4).ToString("N0") : "?");
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip(num10.ToString("N0") + " coins x " + Big(num4) + " lum (Session > Lum's buying rate)");
				}
				ImGui.TableSetColumnIndex(5);
				ImGui.TextUnformatted((num4 > 0.0) ? ((double)num9 + (double)num10 * num4).ToString("N0") : "?");
				ImGui.TableSetColumnIndex(6);
				WhenText(num9, num10, num2, num3, num4, num6);
				ImGui.TableSetColumnIndex(7);
				List<WorldObject> list = Gems(k, num8);
				if (list.Count == 0)
				{
					Im.TextDisabled("none");
				}
				else if (ImGui.SmallButton("Use (" + list.Count + ")##use" + k.Tab + num8))
				{
					try
					{
						Remote.ExpectYes(10.0, "luminance");
						Globals.Core.Actions.UseItem(list[0].Id, 0);
						Util.WriteToChat("Augs: using " + list[0].Name + "...");
						_augRecheckAt = DateTime.Now.AddSeconds(2.5);
					}
					catch (Exception ex)
					{
						Util.WriteToChat("Augs: " + ex.Message);
					}
				}
				if (list.Count > 0 && ImGui.IsItemHovered())
				{
					Im.SetTooltip("Uses one " + list[0].Name + " (pays its luminance), then checks /aug and /bank again.");
				}
			}
			ImGui.EndTable();
		}
		if (!_augGoal.TryGetValue(k.Tab, out var value))
		{
			value = "";
		}
		Im.Text("Goal level");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(100f);
		if (ImGui.InputText("##goal" + k.Tab, ref value, 12u, ImGuiInputTextFlags.CharsDecimal))
		{
			_augGoal[k.Tab] = value;
		}
		if (long.TryParse(value.Replace(",", ""), out var result) && result > 0)
		{
			ImGui.SameLine();
			if (result <= num)
			{
				Im.TextDisabled("already there");
			}
			else
			{
				long num11 = result - num;
				long num12 = AugCost(k, num, num11);
				long num13 = k.Coins * num11;
				Im.Text("+" + num11.ToString("N0") + " levels: " + Big(num12) + " lum + " + num13.ToString("N0") + " coins = " + ((num4 > 0.0) ? Big((double)num12 + (double)num13 * num4) : "?") + " lum   ");
				ImGui.SameLine();
				WhenText(num12, num13, num2, num3, num4, num6);
				ImGui.SameLine();
				Im.TextDisabled("   lum only:");
				ImGui.SameLine();
				LumWhen(num12, num2, lumRate);
			}
		}
		if (k.Caps != null)
		{
			string text = "";
			for (int j = 0; j < k.Caps.Length; j++)
			{
				if (num < k.Caps[j])
				{
					text = "   Next soft cap: " + k.Caps[j].ToString("N0") + " (cost x" + (new int[4] { 4, 8, 16, 24 })[j] + ")";
					break;
				}
			}
			Im.TextDisabled("Soft caps " + string.Join(" / ", Array.ConvertAll(k.Caps, (int c) => c.ToString("N0"))) + text);
		}
		else
		{
			Im.TextDisabled("No soft caps known for this one.");
		}
	}

	private static int Landcell()
	{
		try
		{
			return CoreManager.Current.Actions.Landcell;
		}
		catch
		{
			return 0;
		}
	}

	private static bool Outdoors(int cell)
	{
		return cell != 0 && (cell & 0xFFFF) < 256;
	}

	private static int Level()
	{
		try
		{
			return CoreManager.Current.CharacterFilter.Level;
		}
		catch
		{
			return 0;
		}
	}

	private static void AeStart()
	{
		if (AeGo.Length == 0)
		{
			_aeStatus = "pick how to get outside first";
			return;
		}
		_ae = Ae.Start;
		_aeDone = 0;
		_aeRefused = 0;
		_aeTries = 0;
		_aeStepAt = DateTime.Now;
		_aeStatus = "starting";
		PluginCore.Pause("Auto enlighten");
		Check("/bank");
		Check("/bonus");
		Util.WriteToChat("Auto enlighten: started" + ((AeTarget > 0) ? (" - up to enlightenment " + AeTarget) : "") + ".");
	}

	private static void AeStop(string why)
	{
		if (_ae != Ae.Off)
		{
			_ae = Ae.Off;
			_aeStatus = why;
			PluginCore.Resume("Auto enlighten");
			if (RtSpecAtEnd && (why.StartsWith("reached", StringComparison.Ordinal) || why.StartsWith("out of", StringComparison.Ordinal)))
			{
				RtStart(spec: true);
			}
			Util.WriteToChat("Auto enlighten: stopped - " + why + ((_aeDone > 0) ? (" (" + _aeDone + " enlightenment" + ((_aeDone == 1) ? "" : "s") + " done)") : "") + ".");
		}
	}

	private static void AeChat(string text)
	{
		if (_ae == Ae.Sent || _ae == Ae.Jumped)
		{
			string text2 = text.ToLowerInvariant();
			if (text2.IndexOf("enlighten", StringComparison.Ordinal) >= 0 && (text2.IndexOf("cannot", StringComparison.Ordinal) >= 0 || text2.IndexOf("can't", StringComparison.Ordinal) >= 0 || text2.IndexOf("must", StringComparison.Ordinal) >= 0 || text2.IndexOf("unable", StringComparison.Ordinal) >= 0 || text2.IndexOf("not ", StringComparison.Ordinal) >= 0 || text2.IndexOf("need", StringComparison.Ordinal) >= 0))
			{
				_aeError = true;
				_aeLastError = text.Trim();
			}
		}
	}

	private static string AeShort(int next)
	{
		CountEnlItems(now: true);
		int num = EnlTokensNeeded(next);
		bool flag = EnlUsesMedallions(next);
		int num2 = (flag ? Have("Enlightenment Medallion") : Have("Enlightenment Token"));
		if (num > num2)
		{
			return "out of " + (flag ? "medallions" : "tokens") + " (" + num2 + " of " + num + ")";
		}
		long num3 = EnlLumNeeded(next);
		long num4 = BankNum("Luminance");
		if (num3 > 0 && num4 >= 0 && num4 < num3)
		{
			return "out of luminance (" + Lum(num4) + " of " + Lum(num3) + ")";
		}
		return null;
	}

	private static bool AeUse(string go, out string err)
	{
		err = null;
		HooksWrapper actions = CoreManager.Current.Actions;
		if (go.StartsWith("gem:", StringComparison.Ordinal))
		{
			int num = FirstStack(go.Substring(4));
			if (num == 0)
			{
				err = "out of " + go.Substring(4);
				return false;
			}
			if (actions.CombatMode != CombatState.Peace)
			{
				actions.SetCombatMode(CombatState.Peace);
				return false;
			}
			actions.UseItem(num, 0);
			return true;
		}
		if (go.StartsWith("spell:", StringComparison.Ordinal))
		{
			string[] array = go.Split(new char[1] { ':' }, 3);
			if (array.Length < 2 || !int.TryParse(array[1], out var result))
			{
				err = "that spell isn't known";
				return false;
			}
			if (actions.CombatMode != CombatState.Magic)
			{
				if (!_aeMagicAsked)
				{
					_aeMagicAsked = true;
					if (!WandInHand())
					{
						int num2 = AnyWand();
						if (num2 == 0)
						{
							err = "no wand to cast with";
							return false;
						}
						Wield(num2);
						return false;
					}
					actions.SetCombatMode(CombatState.Magic);
				}
				else if ((DateTime.Now - _aeStepAt).TotalSeconds > 3.0)
				{
					_aeMagicAsked = false;
					_aeStepAt = DateTime.Now;
				}
				return false;
			}
			actions.CastSpell(result, CoreManager.Current.CharacterFilter.Id);
			return true;
		}
		err = "pick how to get outside";
		return false;
	}

	internal static bool WandInHand()
	{
		try
		{
			int id = CoreManager.Current.CharacterFilter.Id;
			foreach (WorldObject item in InvCache.All())
			{
				if (item.ObjectClass == ObjectClass.WandStaffOrb && item.Values(LongValueKey.Wielder) == id)
				{
					return true;
				}
			}
		}
		catch
		{
		}
		return false;
	}

	internal static int AnyWand()
	{
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (item.ObjectClass == ObjectClass.WandStaffOrb)
				{
					return item.Id;
				}
			}
		}
		catch
		{
		}
		return 0;
	}

	private static string SubwayGo()
	{
		foreach (string item in PortalsTab.CarriedGems(PluginCore.CurrentSettings))
		{
			if (item.IndexOf("Subway", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				return "gem:" + item;
			}
		}
		foreach (KeyValuePair<int, string> item2 in PortalsTab.RecallSpells())
		{
			if (item2.Value.IndexOf("Subway", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				return "spell:" + item2.Key + ":" + item2.Value;
			}
		}
		return null;
	}

	private static void AeGoTo(Ae s, string status)
	{
		_ae = s;
		_aeStepAt = DateTime.Now;
		_aeStatus = status;
		_aeMagicAsked = false;
	}

	private static void AeTick()
	{
		if (_ae == Ae.Off)
		{
			return;
		}
		try
		{
			int num = EnlCount(out var _);
			double totalSeconds = (DateTime.Now - _aeStepAt).TotalSeconds;
			int num2 = Landcell();
			switch (_ae)
			{
			case Ae.Train:
				if (RtBusy)
				{
					_aeStatus = "retraining - " + _rtStatus;
					break;
				}
				if (_rtFailed != null)
				{
					AeStop("retrain: " + _rtFailed);
					break;
				}
				if (AeGo.StartsWith("spell:", StringComparison.Ordinal) && !WandInHand())
				{
					int num3 = AnyWand();
					if (num3 != 0)
					{
						Wield(num3);
					}
				}
				AeGoTo(Ae.Start, "retrained - starting");
				_aeStepAt = DateTime.Now.AddSeconds(-1.0);
				break;
			case Ae.Start:
			{
				if (RtAfterEnl && RtNeedsTraining())
				{
					RtStart(spec: false);
					AeGoTo(Ae.Train, "retraining");
					break;
				}
				if (totalSeconds < 2.0)
				{
					_aeStatus = "checking luminance and tokens";
					break;
				}
				if (num < 0)
				{
					AeStop("your enlightenment count isn't known - click Update or type it");
					break;
				}
				if (AeTarget > 0 && num >= AeTarget)
				{
					AeStop("reached enlightenment " + num);
					break;
				}
				string text = AeShort(num + 1);
				if (text != null)
				{
					AeStop(text);
					break;
				}
				_aeCell = num2;
				_aeTries++;
				if (_aeTries > 3)
				{
					AeStop("the way outside didn't take you anywhere 3 times");
					break;
				}
				AeGoTo(Ae.Going, "going outside (" + AeName(AeGo) + ")");
				goto case Ae.Going;
			}
			case Ae.Going:
			case Ae.Subway:
				if (_aeCellAt == DateTime.MinValue || _aeCellAt < _aeStepAt)
				{
					if (num2 != _aeCell && num2 != 0)
					{
						_aeCellAt = DateTime.Now;
						_aeCell = num2;
						break;
					}
					if (_aeAt < _aeStepAt)
					{
						if (AeUse((_ae == Ae.Subway) ? (SubwayGo() ?? "") : AeGo, out var err))
						{
							_aeAt = DateTime.Now;
						}
						else if (err != null)
						{
							AeStop(err);
							break;
						}
					}
					if (totalSeconds > 25.0)
					{
						AeGoTo((_ae == Ae.Subway) ? Ae.Subway : Ae.Start, "trying again");
						_aeAt = DateTime.MinValue;
					}
				}
				else if (!((DateTime.Now - _aeCellAt).TotalSeconds < 3.0))
				{
					_aeAt = DateTime.MinValue;
					if (_ae == Ae.Subway)
					{
						_aeTries = 0;
						AeGoTo(Ae.Start, "at the Subway - going outside again");
						_aeStepAt = DateTime.Now.AddSeconds(-2.0);
					}
					else if (!Outdoors(num2))
					{
						AeStop("the way outside left you indoors (" + num2.ToString("X8") + ")");
					}
					else
					{
						_aeTries = 0;
						_aeLvlAt = DateTime.MinValue;
						AeGoTo(Ae.Outside, "outside - waiting for level " + EnlLevelNeeded(num + 1));
					}
				}
				break;
			case Ae.Outside:
			{
				int num4 = EnlLevelNeeded(num + 1);
				int num5 = Level();
				if (num5 < num4)
				{
					_aeStatus = "outside - waiting for level " + num4 + " (now " + num5 + ")";
					_aeLvlAt = DateTime.MinValue;
				}
				else if (_aeLvlAt == DateTime.MinValue)
				{
					_aeLvlAt = DateTime.Now;
				}
				else if (!((DateTime.Now - _aeLvlAt).TotalSeconds < 1.0))
				{
					string text2 = AeShort(num + 1);
					if (text2 != null)
					{
						AeStop(text2);
						break;
					}
					if (CoreManager.Current.Actions.CombatMode != CombatState.Peace)
					{
						CoreManager.Current.Actions.SetCombatMode(CombatState.Peace);
						break;
					}
					Remote.SmallJump(150);
					_aeError = false;
					AeGoTo(Ae.Jumped, "jumped - /enl in 3 s");
				}
				break;
			}
			case Ae.Jumped:
				if (!(totalSeconds < 3.0))
				{
					_aeError = false;
					Remote.ExpectYes(12.0, null);
					Util.Command("/enl");
					AeGoTo(Ae.Sent, "sent /enl - waiting for the pop-up");
				}
				break;
			case Ae.Sent:
				if (Remote.LastConfirmUtc > _aeStepAt.ToUniversalTime() || Remote.HookAnsweredUtc > _aeStepAt.ToUniversalTime())
				{
					if (!((DateTime.UtcNow - Remote.LastConfirmUtc).TotalSeconds < 0.8))
					{
						Remote.ClickConfirmYes();
						_aeCell = num2;
						AeGoTo(Ae.Yes, "said Yes - waiting for the trip to the lifestone");
					}
				}
				else
				{
					if (!_aeError && !(totalSeconds > 10.0))
					{
						break;
					}
					string text3 = (_aeError ? _aeLastError : "no pop-up after /enl");
					Util.WriteToChat("Auto enlighten: /enl refused - " + text3);
					string text4 = AeShort(num + 1);
					if (text4 != null)
					{
						AeStop(text4);
						break;
					}
					if (++_aeRefused >= 3)
					{
						AeStop("/enl refused 3 times in a row (" + text3 + ")");
						break;
					}
					string text5 = SubwayGo();
					if (text5 == null)
					{
						AeStop("/enl refused and there's no Subway recall (gem or spell) to start over from");
						break;
					}
					_aeCell = num2;
					_aeAt = DateTime.MinValue;
					AeGoTo(Ae.Subway, "refused - Subway recall, then outside again");
				}
				break;
			case Ae.Yes:
				if (num2 != _aeCell && num2 != 0)
				{
					_aeDone++;
					_aeRefused = 0;
					_aeTries = 0;
					if (_enlManual > 0)
					{
						_enlManual++;
						_deedsDirtyAt = DateTime.Now;
					}
					Util.WriteToChat("Auto enlighten: enlightenment " + ((num < 0) ? "?" : ((_enlManual > 0) ? _enlManual : (num + 1)).ToString()) + " done.");
					Check("/bank");
					Check("/bonus");
					AeGoTo(Ae.Start, "enlightened - starting over");
				}
				else if (totalSeconds > 90.0)
				{
					AeStop("no trip to the lifestone 90 s after Yes");
				}
				break;
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			AeStop("error: " + ex.Message);
		}
	}

	public static string EnlCommand(string arg)
	{
		arg = (arg ?? "").Trim().ToLowerInvariant();
		string text = EnlBankCommand(arg);
		if (text != null)
		{
			return text;
		}
		if (arg == "start")
		{
			if (AeOn)
			{
				return "Auto enlighten is already running - " + _aeStatus;
			}
			AeStart();
			return "Auto enlighten: " + _aeStatus;
		}
		if (arg == "stop")
		{
			if (!AeOn)
			{
				return "Auto enlighten isn't running.";
			}
			AeStop("stopped");
			return "Auto enlighten stopped.";
		}
		if (arg.StartsWith("target"))
		{
			if (!int.TryParse(arg.Substring(6).Trim(), out var result) || result < 0)
			{
				return "Usage: /mtank enl target <number> (0 = keep going)";
			}
			AeTarget = result;
			_deedsDirtyAt = DateTime.Now;
			return "Auto enlighten: " + ((result > 0) ? ("up to enlightenment " + result) : "until out of luminance / mats") + ".";
		}
		return "Auto enlighten " + (AeOn ? "running" : "not running") + " - " + ((_aeStatus.Length > 0) ? _aeStatus : "idle") + ". /mtank enl start | stop | target <n> | buy need|max|<n> | withdraw [n|all]";
	}

	public static void EnlPhone(out bool on, out string status, out int target, out int now)
	{
		on = AeOn;
		status = ((_aeStatus.Length > 0) ? _aeStatus : "idle") + ((_aeDone > 0) ? (" - " + _aeDone + " done") : "");
		target = AeTarget;
		now = EnlCount(out var _);
	}

	private static string AeName(string go)
	{
		if (go.StartsWith("gem:", StringComparison.Ordinal))
		{
			return go.Substring(4);
		}
		if (go.StartsWith("spell:", StringComparison.Ordinal))
		{
			string[] array = go.Split(new char[1] { ':' }, 3);
			return (array.Length > 2) ? array[2] : "spell";
		}
		return "(none)";
	}

	private static void DrawAutoEnl(int cur)
	{
		Vector4 vector = new Vector4(0.6f, 0.6f, 0.6f, 1f);
		if (_aeOpts == null || (DateTime.Now - _aeOptsAt).TotalSeconds > 5.0)
		{
			_aeOptsAt = DateTime.Now;
			_aeOpts = new List<string>();
			foreach (string item in PortalsTab.CarriedGems(PluginCore.CurrentSettings))
			{
				_aeOpts.Add("gem:" + item);
			}
			foreach (KeyValuePair<int, string> item2 in PortalsTab.RecallSpells())
			{
				_aeOpts.Add("spell:" + item2.Key + ":" + item2.Value);
			}
		}
		Im.Text("Get outside with");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(260f);
		string text = ((AeGo.Length == 0) ? "(pick one)" : ((AeGo.StartsWith("spell:") ? "Spell: " : "Gem: ") + AeName(AeGo)));
		if (ImGui.BeginCombo("##aego", text))
		{
			foreach (string aeOpt in _aeOpts)
			{
				if (ImGui.Selectable((aeOpt.StartsWith("spell:") ? "Spell: " : "Gem: ") + AeName(aeOpt) + "##" + aeOpt, aeOpt == AeGo))
				{
					AeGo = aeOpt;
					_deedsDirtyAt = DateTime.Now;
				}
			}
			if (_aeOpts.Count == 0)
			{
				Im.TextDisabled("No portal gems or recall spells found.");
			}
			ImGui.EndCombo();
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("You have to be outside to enlighten. A portal gem you carry, or a recall spell you know\n(a spell needs a wand and the magic skill for it).");
		}
		ImGui.SameLine();
		Im.Text("up to");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(100f);
		if (ImGui.InputInt("##aetarget", ref AeTarget, 1, 10))
		{
			AeTarget = Math.Max(0, AeTarget);
			_deedsDirtyAt = DateTime.Now;
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Stop once you reach this enlightenment (0 = until the luminance, tokens or medallions run out).");
		}
		Im.TextColored(vector, RtAfterEnl ? "Trains the skills ticked Enl on the Retrain tab after each enlighten." : "No skills ticked Enl on the Retrain tab - none are trained between enlightens.");
		if (!AeOn)
		{
			if (ImGui.Button("Start##ae"))
			{
				AeStart();
			}
		}
		else if (ImGui.Button("Stop##ae"))
		{
			AeStop("stopped");
		}
		ImGui.SameLine();
		Im.TextColored(AeOn ? Yellow : vector, (_aeStatus.Length > 0) ? _aeStatus : "idle");
		Im.TextColored(vector, "Each time: outside, wait for the level, small jump, 3 s, /enl, Yes - then the lifestone and again.\nRefused with everything there: Subway recall (gem or spell), outside again, retry. MelkTank's fighting is paused meanwhile.");
	}

	public static BountyTier Bounty(int tier)
	{
		LoadBountyTiers();
		if (!_bountyTiers.TryGetValue(tier, out var value))
		{
			value = new BountyTier();
			_bountyTiers[tier] = value;
		}
		return value;
	}

	private static void LoadBountyTiers()
	{
		if (_bountyLoaded)
		{
			return;
		}
		_bountyLoaded = true;
		try
		{
			string f = BountyFile;
			if (!File.Exists(f))
			{
				return;
			}
			string[] array = Util.Locked(f, () => File.ReadAllLines(f));
			foreach (string text in array)
			{
				if (!text.StartsWith("#"))
				{
					string[] array2 = text.Split('\t');
					if (array2.Length >= 4 && int.TryParse(array2[0], out var result) && double.TryParse(array2[1], NumberStyles.Float, CultureInfo.InvariantCulture, out var result2) && double.TryParse(array2[2], NumberStyles.Float, CultureInfo.InvariantCulture, out var result3) && int.TryParse(array2[3], out var result4))
					{
						_bountyTiers[result] = new BountyTier
						{
							RewardB = result2,
							CooldownMin = result3,
							Kills = result4,
							Set = true
						};
					}
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void SaveBountyTiers()
	{
		try
		{
			StringBuilder stringBuilder = new StringBuilder("# MelkTank: bounty reward per tier - tier, reward (billions of lum), cooldown (min), kills per reward\r\n");
			List<int> list = new List<int>(_bountyTiers.Keys);
			list.Sort();
			foreach (int item in list)
			{
				BountyTier bountyTier = _bountyTiers[item];
				if (bountyTier.Set)
				{
					stringBuilder.Append(item).Append('\t').Append(bountyTier.RewardB.ToString(CultureInfo.InvariantCulture))
						.Append('\t')
						.Append(bountyTier.CooldownMin.ToString(CultureInfo.InvariantCulture))
						.Append('\t')
						.Append(bountyTier.Kills)
						.Append("\r\n");
				}
			}
			Util.WriteShared(BountyFile, stringBuilder.ToString());
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static double BountyLumPerHour()
	{
		if (!BountyRateOn)
		{
			return -1.0;
		}
		int num = -1;
		try
		{
			num = CurrentTier();
		}
		catch
		{
		}
		if (num < 11 || num > 25)
		{
			return -1.0;
		}
		double killsPerHourRecent = KillsPerHourRecent;
		if (killsPerHourRecent <= 0.0)
		{
			return -1.0;
		}
		BountyTier bountyTier = Bounty(num);
		double num2 = (double)bountyTier.Kills / killsPerHourRecent + bountyTier.CooldownMin / 60.0;
		return (num2 > 0.0) ? (bountyTier.RewardB * 1000000000.0 / num2) : (-1.0);
	}

	public static bool DrawBountySettings(Settings s)
	{
		bool result = false;
		if (Im.WithTip("/mt set BountyLumRate on|off", ImGui.Checkbox("T11+: lum/hr from the bounty reward##bountyrate", ref s.BountyLumRate)))
		{
			result = true;
			BountyRateOn = s.BountyLumRate;
			_ratesAt = DateTime.MinValue;
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("In T11-T25 all the luminance comes from the bounty: a reward every N kills, then a cooldown before kills count again.\nOn: once the session is 1 minute old, lum/hr = reward / (N kills at your kills/hr over the last 60 min + the cooldown).\nIt's used everywhere lum/hr shows (Session tab, the phone, Augs) while you're in T11-T25; anywhere else, the measured lum/hr.");
		}
		int num = -1;
		try
		{
			num = CurrentTier();
		}
		catch
		{
		}
		if (_bountyPick < 0)
		{
			_bountyPick = ((num >= 11 && num <= 25) ? num : 11);
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(80f);
		if (ImGui.BeginCombo("##bountytier", "T" + _bountyPick))
		{
			for (int i = 11; i <= 25; i++)
			{
				if (ImGui.Selectable("T" + i + ((i == num) ? "  (here)" : "") + (Bounty(i).Set ? "" : "  -"), i == _bountyPick))
				{
					_bountyPick = i;
				}
			}
			ImGui.EndCombo();
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Pick a tier to see / set its bounty. The tier you're in is used (it follows you); '-' = not set yet (default numbers).");
		}
		BountyTier bountyTier = Bounty(_bountyPick);
		bool flag = false;
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		float v = (float)bountyTier.RewardB;
		if (ImGui.InputFloat("B reward##bountyrew", ref v, 0f, 0f, "%.0f"))
		{
			bountyTier.RewardB = Math.Max(0f, v);
			flag = true;
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(70f);
		float v2 = (float)bountyTier.CooldownMin;
		if (ImGui.InputFloat("min cooldown##bountycd", ref v2, 0f, 0f, "%.0f"))
		{
			bountyTier.CooldownMin = Math.Max(0f, v2);
			flag = true;
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(70f);
		int v3 = bountyTier.Kills;
		if (ImGui.InputInt("kills##bountykills", ref v3, 0, 0))
		{
			bountyTier.Kills = Math.Max(1, v3);
			flag = true;
		}
		if (flag)
		{
			bountyTier.Set = true;
			SaveBountyTiers();
			_ratesAt = DateTime.MinValue;
		}
		if (!bountyTier.Set)
		{
			ImGui.SameLine();
			Im.TextDisabled("(default)");
		}
		double killsPerHourRecent = KillsPerHourRecent;
		if (num < 11 || num > 25)
		{
			Im.TextDisabled("   You're not in T11-T25 (tier " + ((num < 0) ? "unknown" : num.ToString()) + ") - the measured lum/hr is used.");
		}
		else if (killsPerHourRecent <= 0.0)
		{
			Im.TextDisabled("   T" + num + ": after 1 minute of the session (needs kills/hr).");
		}
		else
		{
			BountyTier bountyTier2 = Bounty(num);
			double num2 = (double)bountyTier2.Kills / killsPerHourRecent * 60.0;
			double num3 = num2 + bountyTier2.CooldownMin;
			Im.TextDisabled("   T" + num + ": " + killsPerHourRecent.ToString("N0") + " kills/hr -> " + bountyTier2.Kills + " kills in " + num2.ToString("0.0") + " min + " + bountyTier2.CooldownMin.ToString("0") + " min cooldown = a reward every " + num3.ToString("0.0") + " min -> " + Big(bountyTier2.RewardB * 1000000000.0 * 60.0 / num3) + " lum/hr" + (s.BountyLumRate ? "" : "  (off)"));
		}
		return result;
	}

	private static string CarryFile()
	{
		CharacterFilter characterFilter = CoreManager.Current.CharacterFilter;
		string text = characterFilter.Server + "-" + characterFilter.Name;
		char[] invalidFileNameChars = Path.GetInvalidFileNameChars();
		foreach (char oldChar in invalidFileNameChars)
		{
			text = text.Replace(oldChar, '_');
		}
		return Util.FullPath("MelkTank_HotCarry_" + text + ".txt");
	}

	private static string E(string s)
	{
		return Uri.EscapeDataString(s ?? "");
	}

	private static string U(string s)
	{
		return Uri.UnescapeDataString(s ?? "");
	}

	private static string D(double d)
	{
		return d.ToString("R", CI);
	}

	public static void SaveCarry()
	{
		try
		{
			if (CoreManager.Current.CharacterFilter.LoginStatus != 3)
			{
				return;
			}
			StringBuilder b = new StringBuilder();
			Action<string, string> action = (string k, string v) =>
			{
				b.Append(k).Append('=').Append(v)
					.Append('\n');
			};
			action("pid", Process.GetCurrentProcess().Id.ToString(CI));
			action("char", E(CoreManager.Current.CharacterFilter.Name));
			action("saved", DateTime.UtcNow.Ticks.ToString(CI));
			action("login", Remote.LoginAtUtc.Ticks.ToString(CI));
			action("since", Cur.Since.ToUniversalTime().Ticks.ToString(CI));
			action("counts", string.Join(",", Array.ConvertAll(new int[10] { Cur.Kills, Cur.Deaths, Cur.LootItems, Cur.Corpses, Cur.CorpsesKept, Cur.LootArmor, Cur.LootClothing, Cur.LootJewelry, Cur.LootWeapons, Cur.LootMisc }, (int i) => i.ToString(CI))));
			foreach (MobStat value in Cur.Mobs.Values)
			{
				action("mob", E(value.Name) + "," + value.Species.ToString(CI) + "," + value.Kills.ToString(CI) + "," + D(value.TotalSecs) + "," + D(value.Fastest) + "," + D(value.Slowest));
			}
			List<string> list = new List<string>();
			foreach (DateTime item in _recent)
			{
				list.Add(item.ToUniversalTime().Ticks.ToString(CI));
			}
			action("recent", string.Join(",", list.ToArray()));
			action("recentsince", (_recentSince == DateTime.MinValue) ? "0" : _recentSince.ToUniversalTime().Ticks.ToString(CI));
			action("lum", string.Join(",", Array.ConvertAll(new long[5] { _lumEarned, _xpStart, _tokBase, _tokGot, _tokHeld }, (long i) => i.ToString(CI))));
			foreach (Sample sample in _samples)
			{
				action("sample", sample.At.ToUniversalTime().Ticks.ToString(CI) + "," + sample.Lum.ToString(CI) + "," + sample.Xp.ToString(CI));
			}
			action("packs", Packs.ToString(CI) + "," + PackKills.ToString(CI) + "," + D(PackTotalSecs) + "," + D(PackFastest) + "," + D(PackSlowest) + "," + D(PackLast));
			action("coins", D(_coinAcc) + "," + (_coinSynced ? "1" : "0") + "," + _coinsGot.ToString(CI) + "," + _coinAt.ToUniversalTime().Ticks.ToString(CI));
			List<string> list2 = new List<string>();
			foreach (DateTime coinTime in _coinTimes)
			{
				list2.Add(coinTime.ToUniversalTime().Ticks.ToString(CI));
			}
			action("cointimes", string.Join(",", list2.ToArray()));
			foreach (LootRec item2 in Looted)
			{
				action("loot", item2.At.ToUniversalTime().Ticks.ToString(CI) + "," + E(item2.Rule) + "," + E(item2.Desc) + "," + E(item2.Cat) + "," + E(item2.Vs) + "," + item2.VsColor.ToString(CI));
			}
			File.WriteAllText(CarryFile(), b.ToString());
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void LoadCarry()
	{
		string text = null;
		try
		{
			text = CarryFile();
			if (!File.Exists(text))
			{
				return;
			}
			string[] array = File.ReadAllLines(text);
			try
			{
				File.Delete(text);
			}
			catch
			{
			}
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			List<KeyValuePair<string, string>> list = new List<KeyValuePair<string, string>>();
			string[] array2 = array;
			foreach (string text2 in array2)
			{
				int num = text2.IndexOf('=');
				if (num > 0)
				{
					string key = text2.Substring(0, num);
					string value = (dictionary[key] = text2.Substring(num + 1));
					list.Add(new KeyValuePair<string, string>(key, value));
				}
			}
			int id = Process.GetCurrentProcess().Id;
			if (!dictionary.TryGetValue("pid", out var value2) || value2 != id.ToString(CI) || !dictionary.TryGetValue("char", out value2) || U(value2) != CoreManager.Current.CharacterFilter.Name || !dictionary.TryGetValue("saved", out value2) || (DateTime.UtcNow - new DateTime(long.Parse(value2, CI), DateTimeKind.Utc)).TotalMinutes > 5.0)
			{
				return;
			}
			Func<string, DateTime> func = (string x) =>
			{
				long num5 = long.Parse(x, CI);
				return (num5 <= DateTime.MinValue.Ticks + 864000000000L) ? DateTime.MinValue : new DateTime(num5, DateTimeKind.Utc).ToLocalTime();
			};
			if (dictionary.TryGetValue("login", out value2))
			{
				long num2 = long.Parse(value2, CI);
				if (num2 > 0)
				{
					Remote.LoginAtUtc = new DateTime(num2, DateTimeKind.Utc);
				}
			}
			if (dictionary.TryGetValue("since", out value2))
			{
				Cur.Since = func(value2);
			}
			if (dictionary.TryGetValue("counts", out value2))
			{
				string[] c = value2.Split(',');
				Func<int, int> func2 = (int num5) => (num5 < c.Length) ? int.Parse(c[num5], CI) : 0;
				Cur.Kills = func2(0);
				Cur.Deaths = func2(1);
				Cur.LootItems = func2(2);
				Cur.Corpses = func2(3);
				Cur.CorpsesKept = func2(4);
				Cur.LootArmor = func2(5);
				Cur.LootClothing = func2(6);
				Cur.LootJewelry = func2(7);
				Cur.LootWeapons = func2(8);
				Cur.LootMisc = func2(9);
			}
			Cur.Mobs.Clear();
			_recent.Clear();
			_samples.Clear();
			_coinTimes.Clear();
			Looted.Clear();
			foreach (KeyValuePair<string, string> item in list)
			{
				string[] array3 = item.Value.Split(',');
				switch (item.Key)
				{
				case "mob":
					if (array3.Length >= 6)
					{
						MobStat mobStat = new MobStat
						{
							Name = U(array3[0]),
							Species = int.Parse(array3[1], CI),
							Kills = int.Parse(array3[2], CI),
							TotalSecs = double.Parse(array3[3], CI),
							Fastest = double.Parse(array3[4], CI),
							Slowest = double.Parse(array3[5], CI)
						};
						Cur.Mobs[mobStat.Name] = mobStat;
					}
					break;
				case "recent":
				{
					string[] array4 = array3;
					foreach (string text4 in array4)
					{
						if (text4.Length > 0)
						{
							_recent.Add(func(text4));
						}
					}
					break;
				}
				case "recentsince":
					if (array3.Length != 0 && array3[0] != "0")
					{
						_recentSince = func(array3[0]);
					}
					break;
				case "lum":
					if (array3.Length >= 5)
					{
						_lumEarned = long.Parse(array3[0], CI);
						_xpStart = long.Parse(array3[1], CI);
						_tokBase = long.Parse(array3[2], CI);
						_tokGot = long.Parse(array3[3], CI);
						_tokHeld = long.Parse(array3[4], CI);
						_tokArmAt = DateTime.MinValue;
					}
					break;
				case "sample":
					if (array3.Length >= 3)
					{
						_samples.Add(new Sample
						{
							At = func(array3[0]),
							Lum = long.Parse(array3[1], CI),
							Xp = long.Parse(array3[2], CI)
						});
					}
					break;
				case "packs":
					if (array3.Length >= 6)
					{
						Packs = int.Parse(array3[0], CI);
						PackKills = int.Parse(array3[1], CI);
						PackTotalSecs = double.Parse(array3[2], CI);
						PackFastest = double.Parse(array3[3], CI);
						PackSlowest = double.Parse(array3[4], CI);
						PackLast = double.Parse(array3[5], CI);
					}
					break;
				case "coins":
					if (array3.Length >= 4)
					{
						_coinAcc = double.Parse(array3[0], CI);
						_coinSynced = array3[1] == "1";
						_coinsGot = int.Parse(array3[2], CI);
						_coinAt = func(array3[3]);
					}
					break;
				case "cointimes":
				{
					string[] array5 = array3;
					foreach (string text5 in array5)
					{
						if (text5.Length > 0)
						{
							_coinTimes.Add(func(text5));
						}
					}
					break;
				}
				case "loot":
					if (array3.Length >= 6)
					{
						Looted.Add(new LootRec
						{
							At = func(array3[0]),
							Rule = U(array3[1]),
							Desc = U(array3[2]),
							Cat = U(array3[3]),
							Vs = U(array3[4]),
							VsColor = int.Parse(array3[5], CI)
						});
					}
					break;
				}
			}
			_ratesAt = DateTime.MinValue;
			Util.WriteToChat("Session: carried on from the last build (" + Cur.Kills + " kills, " + Packs + " packs, " + Cur.Corpses + " corpses).");
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static double CoinsPerKill(int tier)
	{
		if (tier < 11)
		{
			return 0.0;
		}
		if (tier - 11 < CoinRates.Length)
		{
			return CoinRates[tier - 11];
		}
		return CoinRates[CoinRates.Length - 1] * Math.Pow(1.2, tier - 18);
	}

	private static void AugKill()
	{
		int tier = -1;
		try { tier = CurrentTier(); } catch { }
		if (tier < 11) return;
		_augKillsSince++;
		// (a reward due on this kill: read /aug again shortly - the new counts, and the server's kill count to go on from)
		if (AugKillsLeft(out int rate) == rate && rate > 0) _augRecheckAt = DateTime.Now.AddSeconds(5.0);
	}

	private static readonly Regex AugStepRx = new Regex("^(?<w>First|After|Beyond) (?<n>[\\d,]+) kills:\\s*(?:1 reward per (?<r>[\\d,]+) kills)?", RegexOptions.IgnoreCase);

	/// <summary>Kills to the next hunting augmentation (T11+), from /aug's count of the week's kills plus MelkTank's since:
	/// -1 = not known (no /aug with a hunting part), -2 = no more this week. rate = the kills per reward you're on.</summary>
	public static int AugKillsLeft(out int rate)
	{
		rate = 0;
		string kills = _augHunt.Find(l => l.StartsWith("Kills this week", StringComparison.OrdinalIgnoreCase));
		if (kills == null || !long.TryParse(Regex.Replace(kills.Substring(kills.IndexOf(':') + 1), "[^\\d]", ""), out var week)) return -1;
		if (_augHuntResetAt != DateTime.MinValue && DateTime.Now >= _augHuntResetAt) { week = 0; }
		long k = week + _augKillsSince;
		long from = 0;
		foreach (string l in _augHunt)
		{
			Match m = AugStepRx.Match(l);
			if (!m.Success) continue;
			long n = long.Parse(m.Groups["n"].Value.Replace(",", ""));
			string w = m.Groups["w"].Value.ToLowerInvariant();
			if (w == "first")
			{
				int r = int.Parse(m.Groups["r"].Value.Replace(",", ""));
				if (k < n) { rate = r; return (int)(r - k % r); }
				from = n;
			}
			else if (w == "after" && m.Groups["r"].Success)
			{
				int r = int.Parse(m.Groups["r"].Value.Replace(",", ""));
				rate = r;
				long off = k - from;
				return (int)(r - off % r);
			}
			else if (w == "beyond" && k >= n) { return -2; }
		}
		return -1;
	}

	private static DateTime _augVarsAt = DateTime.MinValue;
	private static DateTime _augResetChecked = DateTime.MinValue;
	private static DateTime _augAutoAt = DateTime.MinValue;

	/// <summary>
	/// For metas (getvar): augweekkills - this week's kills in your tier, /aug's count plus MelkTank's since (-1 not known);
	/// augkillsleft - kills to the next hunting aug (-1 not known, -2 none left this week); augweekdone - 1 once the week's
	/// hunting rewards are used up (past the last step), else 0 - so a meta can hunt its tier till then and do something
	/// else after. /aug is read again (quietly) when the week resets, and every 30 min while hunting in T11+.
	/// </summary>
	private static void AugVarsTick()
	{
		if ((DateTime.Now - _augVarsAt).TotalSeconds < 2.0) return;
		_augVarsAt = DateTime.Now;
		int left = AugKillsLeft(out int _);
		long week = -1;
		string kills = _augHunt.Find(l => l.StartsWith("Kills this week", StringComparison.OrdinalIgnoreCase));
		if (kills != null && long.TryParse(Regex.Replace(kills.Substring(kills.IndexOf(':') + 1), "[^\\d]", ""), out var w))
			week = (_augHuntResetAt != DateTime.MinValue && DateTime.Now >= _augHuntResetAt ? 0 : w) + _augKillsSince;
		UbExpr.SetVar("augweekkills", (double)week);
		UbExpr.SetVar("augkillsleft", (double)left);
		UbExpr.SetVar("augweekdone", left == -2 ? 1.0 : 0.0);
		if (_augRecheckAt != DateTime.MinValue || !ServerMode.Ilt) return;
		// (the week's reset gone by: the new week's numbers)
		if (_augHuntResetAt != DateTime.MinValue && DateTime.Now >= _augHuntResetAt.AddMinutes(1) && _augResetChecked != _augHuntResetAt)
		{
			_augResetChecked = _augHuntResetAt;
			_augRecheckAt = DateTime.Now.AddSeconds(5.0);
			return;
		}
		int tier = -1;
		try { tier = CurrentTier(); } catch { }
		if (tier >= 11 && (DateTime.Now - _augsAt).TotalMinutes >= 30.0 && (DateTime.Now - _augAutoAt).TotalMinutes >= 30.0)
		{
			_augAutoAt = DateTime.Now;
			_augRecheckAt = DateTime.Now.AddSeconds(5.0);
		}
	}

	/// <summary>The bounty popup's line: kills to the next hunting augmentation.</summary>
	public static string AugLine()
	{
		int left = AugKillsLeft(out int rate);
		if (left == -2) return "Aug reward: none left this week";
		if (left < 0) return "";
		return "Aug reward: " + left.ToString("N0", CultureInfo.InvariantCulture) + " kills to go (1 per " + rate + ")";
	}

	public static string AugTipText()
	{
		return "T11+ hunting: every so many kills in your own tier adds 1 to Creature, Item or Life at random.\n" +
			"Counted from /aug's kills this week plus MelkTank's kills since (" + _augKillsSince + ") - a pet's or a fellow's kills, or ones\nthat gave no XP, can make it a little off. Check /aug in Session > Augs to set it right.";
	}

	private static void CoinKill()
	{
		int tier = -1;
		try
		{
			tier = CurrentTier();
		}
		catch
		{
		}
		double num = 1.0;
		try
		{
			num = PaceKill();
		}
		catch
		{
		}
		_coinAcc += CoinsPerKill(tier) * num;
	}

	private static void CoinChat(string text)
	{
		Match match = CoinRx.Match(text);
		if (match.Success)
		{
			if (!int.TryParse(match.Groups["n"].Value.Replace(",", ""), out var result) || result <= 0)
			{
				result = 1;
			}
			_coinsGot += result;
			_coinLog.Add(new KeyValuePair<DateTime, int>(DateTime.Now, result));
			_coinAt = DateTime.Now;
			for (int i = 0; i < result; i++)
			{
				_coinTimes.Add(DateTime.Now);
			}
			_coinTimes.RemoveAll((DateTime t) => (DateTime.Now - t).TotalHours > 1.0);
			_coinAcc = 0.0;
			_coinSynced = true;
		}
	}

	public static long PrestigeCoins(out DateTime bankAt)
	{
		bankAt = DateTime.MinValue;
		BankLine bankLine = _bank.Find((BankLine x) => string.Equals(x.Name, "Prestige Coins", StringComparison.OrdinalIgnoreCase));
		long num = BankCount("Prestige Coins");
		if (bankLine == null || num < 0)
		{
			return -1L;
		}
		bankAt = bankLine.At;
		foreach (KeyValuePair<DateTime, int> item in _coinLog)
		{
			if (item.Key > bankLine.At)
			{
				num += item.Value;
			}
		}
		return num;
	}

	private static void CoinsReset()
	{
		_coinAcc = 0.0;
		_coinSynced = false;
		_coinsGot = 0;
		_coinAt = DateTime.MinValue;
		_coinTimes.Clear();
	}

	public static int CoinKillsLeft()
	{
		int tier = -1;
		try
		{
			tier = CurrentTier();
		}
		catch
		{
		}
		double num = CoinsPerKill(tier);
		if (num <= 0.0)
		{
			return -1;
		}
		return Math.Max(1, (int)Math.Ceiling((1.0 - Math.Min(0.9999, _coinAcc)) / num - 1E-09));
	}

	public static double CoinsPerHour()
	{
		int tier = -1;
		try
		{
			tier = CurrentTier();
		}
		catch
		{
		}
		double num = CoinsPerKill(tier);
		double killsPerHourRecent = KillsPerHourRecent;
		return (num > 0.0 && killsPerHourRecent > 0.0) ? (num * killsPerHourRecent) : (-1.0);
	}

	public static string CoinLine()
	{
		int num = CoinKillsLeft();
		if (num < 0)
		{
			return "";
		}
		int tier = -1;
		try
		{
			tier = CurrentTier();
		}
		catch
		{
		}
		double num2 = 1.0 / CoinsPerKill(tier);
		double num3 = CoinsPerHour();
		int num4 = (int)Math.Round(num2);
		int num5 = Math.Max(0, Math.Min(num4 - 1, num4 - num));
		return "Prestige Coin: " + (_coinSynced ? "" : "~") + num5 + " / " + num2.ToString((Math.Abs(num2 - (double)num4) < 0.05) ? "0" : "0.0", CultureInfo.InvariantCulture) + ((num3 > 0.0) ? (" - " + num3.ToString("0.0", CultureInfo.InvariantCulture) + "/hr") : "") + PaceText();
	}

	private static string CoinTip()
	{
		return "T11+ kills earn a share of a Prestige Coin (T11 1 per 20 kills, more each tier); a whole one goes to your bank.\n" + (_coinSynced ? ("Counted from the last coin (" + _coinAt.ToString("h:mm tt") + ") with MelkTank's kills - a pet's or a fellow's kills can make it a little early.") : "~ = no coin line yet this session, so where you stand isn't known - it counts from login until the first one.") + "\nCoins this session: " + _coinsGot + ", last 60 min: " + _coinTimes.FindAll((DateTime t) => (DateTime.Now - t).TotalHours <= 1.0).Count + ".\n/hr = your kills / hr over the last 60 min x this tier's share." + PaceTip();
	}

	public static string CoinTipText()
	{
		return CoinTip();
	}

	private static void DeedsLoggedIn(string key)
	{
		_deedsFile = Util.FullPath("MelkTank_Deeds_" + key + ".txt");
		LoadDeeds();
	}

	private static void NoteDeeds(string text)
	{
		string[] array = text.Replace("\r", "").Split('\n');
		foreach (string text2 in array)
		{
			string text3 = text2.Trim();
			if (text3.Length == 0)
			{
				continue;
			}
			Match match = QbRx.Match(text3);
			if (match.Success)
			{
				_qbCount = match.Groups["n"].Value;
				_qbAt = DateTime.Now;
				_deedsDirtyAt = DateTime.Now;
				continue;
			}
			match = BonusRx.Match(text3);
			if (match.Success)
			{
				if (DateTime.Now > _bonusCaptureUntil)
				{
					_bonus.Clear();
				}
				// (by name: clicking a few times quickly brought several answers inside one capture, and each was added again)
				string bn = match.Groups["n"].Value.Trim();
				int bi = _bonus.FindIndex((KeyValuePair<string, string> b) => string.Equals(b.Key, bn, StringComparison.OrdinalIgnoreCase));
				KeyValuePair<string, string> bv = new KeyValuePair<string, string>(bn, match.Groups["v"].Value.Trim());
				if (bi >= 0)
				{
					_bonus[bi] = bv;
				}
				else
				{
					_bonus.Add(bv);
				}
				_bonusAt = DateTime.Now;
				_bonusCaptureUntil = DateTime.Now.AddSeconds(3.0);
				_deedsDirtyAt = DateTime.Now;
				continue;
			}
			match = DeedHeadRx.Match(text3);
			if (match.Success)
			{
				_deeds.Clear();
				_curTier = null;
				_deedsHead = text3;
				_deedsOn = match.Groups["on"].Value.Equals("ON", StringComparison.OrdinalIgnoreCase);
				match = Regex.Match(text3, "Your QB:\\s*(?<n>[\\d,]+)");
				if (match.Success)
				{
					_qbCount = match.Groups["n"].Value;
					_qbAt = DateTime.Now;
				}
				_deedsAt = DateTime.Now;
				_deedCaptureUntil = DateTime.Now.AddSeconds(3.0);
				_deedsDirtyAt = DateTime.Now;
			}
			else
			{
				if (DateTime.Now > _deedCaptureUntil || text3.Trim('-').Length == 0)
				{
					continue;
				}
				match = DeedTierRx.Match(text3);
				if (match.Success)
				{
					int.TryParse(match.Groups["qb"].Value.Replace(",", ""), out var result);
					// (a tier already listed - two answers close together - is filled again, not added twice)
					_deeds.RemoveAll((DeedTier d) => d.QB == result);
					_curTier = new DeedTier
					{
						QB = result,
						Unlocked = match.Groups["u"].Success
					};
					_deeds.Add(_curTier);
					_deeds.Sort((DeedTier a, DeedTier b) => a.QB.CompareTo(b.QB));
				}
				else
				{
					if (!text3.StartsWith("*") || _curTier == null)
					{
						_deedCaptureUntil = DateTime.MinValue;
						continue;
					}
					_curTier.Lines.Add(text3.Substring(1).Trim());
				}
				_deedCaptureUntil = DateTime.Now.AddSeconds(3.0);
				_deedsDirtyAt = DateTime.Now;
			}
		}
	}

	private static void QuietNextDeeds(string t)
	{
		switch (t)
		{
		case "/deeds":
			_quietDeedsUntil = DateTime.Now.AddSeconds(8.0);
			break;
		case "/qb":
			_quietQbUntil = DateTime.Now.AddSeconds(8.0);
			break;
		case "/bonus":
			_quietBonusUntil = DateTime.Now.AddSeconds(8.0);
			break;
		}
	}

	private static bool QuietDeeds(string s)
	{
		string text = s.Trim();
		if (DateTime.Now <= _quietQbUntil && QbRx.IsMatch(text))
		{
			_quietQbUntil = DateTime.MinValue;
			return true;
		}
		if (DateTime.Now <= _quietBonusUntil && text.StartsWith("[BONUS]", StringComparison.OrdinalIgnoreCase))
		{
			_quietBonusUntil = DateTime.Now.AddSeconds(2.0);
			return true;
		}
		if (DateTime.Now <= _quietDeedsUntil)
		{
			if (text.Length == 0 || text.Trim('-').Length == 0)
			{
				return true;
			}
			if (DeedHeadRx.IsMatch(text.Split('\n')[0].Trim()) || DateTime.Now <= _deedCaptureUntil)
			{
				_quietDeedsUntil = DateTime.Now.AddSeconds(2.0);
				return true;
			}
		}
		return false;
	}

	private static void DeedsFileTick()
	{
		if (_deedsDirtyAt == DateTime.MinValue || (DateTime.Now - _deedsDirtyAt).TotalSeconds < 4.0 || _deedsFile == null)
		{
			return;
		}
		_deedsDirtyAt = DateTime.MinValue;
		try
		{
			StringBuilder stringBuilder = new StringBuilder("# MelkTank: the last /deeds, /qb and /bonus answers for this character (Session > Deeds)\r\n");
			stringBuilder.Append("E\t").Append(_enlManual).Append("\r\n");
			stringBuilder.Append("AE\t").Append(AeGo.Replace("\t", " ")).Append('\t')
				.Append(AeTarget)
				.Append("\r\n");
			stringBuilder.Append("RT\t").Append(RtSave()).Append("\r\n");
			stringBuilder.Append("Q\t").Append(_qbCount).Append('\t')
				.Append(_qbAt.Ticks)
				.Append("\r\n");
			stringBuilder.Append("D\t").Append(_deedsHead.Replace("\t", " ")).Append('\t')
				.Append(_deedsAt.Ticks)
				.Append('\t')
				.Append(_deedsOn ? "1" : "0")
				.Append("\r\n");
			stringBuilder.Append("@B\t").Append(_bonusAt.Ticks).Append("\r\n");
			foreach (KeyValuePair<string, string> bonu in _bonus)
			{
				stringBuilder.Append("B\t").Append(bonu.Key.Replace("\t", " ")).Append('\t')
					.Append(bonu.Value.Replace("\t", " "))
					.Append("\r\n");
			}
			foreach (DeedTier deed in _deeds)
			{
				stringBuilder.Append("T\t").Append(deed.QB).Append('\t')
					.Append(deed.Unlocked ? "1" : "0")
					.Append("\r\n");
				foreach (string line in deed.Lines)
				{
					stringBuilder.Append("I\t").Append(line.Replace("\t", " ")).Append("\r\n");
				}
			}
			Util.WriteShared(_deedsFile, stringBuilder.ToString());
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void LoadDeeds()
	{
		_deeds.Clear();
		_bonus.Clear();
		_deedsHead = "";
		_qbCount = "";
		_deedsOn = true;
		_enlManual = 0;
		_deedsAt = (_qbAt = (_bonusAt = DateTime.MinValue));
		if (_deedsFile == null || !File.Exists(_deedsFile))
		{
			return;
		}
		try
		{
			string[] array = Util.Locked(_deedsFile, () => File.ReadAllLines(_deedsFile));
			foreach (string text in array)
			{
				string[] array2 = text.Split('\t');
				long result;
				switch (array2[0])
				{
				case "E":
					if (array2.Length >= 2)
					{
						int.TryParse(array2[1], out _enlManual);
					}
					break;
				case "AE":
					if (array2.Length >= 3)
					{
						AeGo = array2[1];
						int.TryParse(array2[2], out AeTarget);
					}
					break;
				case "RT":
					if (array2.Length >= 2)
					{
						RtLoad(array2[1]);
					}
					break;
				case "Q":
					if (array2.Length >= 3)
					{
						_qbCount = array2[1];
						if (long.TryParse(array2[2], out result))
						{
							_qbAt = new DateTime(result);
						}
					}
					break;
				case "D":
					if (array2.Length >= 4)
					{
						_deedsHead = array2[1];
						if (long.TryParse(array2[2], out result))
						{
							_deedsAt = new DateTime(result);
						}
						_deedsOn = array2[3] == "1";
					}
					break;
				case "@B":
					if (array2.Length >= 2 && long.TryParse(array2[1], out result))
					{
						_bonusAt = new DateTime(result);
					}
					break;
				case "B":
					if (array2.Length >= 3)
					{
						_bonus.Add(new KeyValuePair<string, string>(array2[1], array2[2]));
					}
					break;
				case "T":
				{
					if (array2.Length >= 3 && int.TryParse(array2[1], out var result2))
					{
						_deeds.Add(new DeedTier
						{
							QB = result2,
							Unlocked = (array2[2] == "1")
						});
					}
					break;
				}
				case "I":
					if (array2.Length >= 2 && _deeds.Count > 0)
					{
						_deeds[_deeds.Count - 1].Lines.Add(array2[1]);
					}
					break;
				}
			}
			_deeds.Sort((DeedTier a, DeedTier b) => a.QB.CompareTo(b.QB));
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static string When(DateTime t)
	{
		string result;
		if (t == DateTime.MinValue)
		{
			result = "never";
		}
		else
		{
			result = ((t.Date == DateTime.Today) ? t.ToString("HH:mm") : t.ToString("MM-dd HH:mm"));
		}
		return result;
	}

	private static void Check(string cmd)
	{
		QuietNext(cmd);
		Util.Command(cmd);
	}

	private static void DrawDeeds()
	{
		Vector4 vector = new Vector4(0.45f, 0.9f, 0.45f, 1f);
		Vector4 vector2 = new Vector4(0.95f, 0.95f, 0.95f, 1f);
		Vector4 col = new Vector4(0.6f, 0.6f, 0.6f, 1f);
		if (ImGui.Button("Update all"))
		{
			Check("/qb");
			Check("/bonus");
			Check("/deeds");
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Sends /qb, /bonus and /deeds - the answers are read here and kept out of chat.");
		}
		ImGui.SameLine();
		if (ImGui.Button("/qb##dq"))
		{
			Check("/qb");
		}
		ImGui.SameLine();
		if (ImGui.Button("/bonus##db"))
		{
			Check("/bonus");
		}
		ImGui.SameLine();
		if (ImGui.Button("/deeds##dd"))
		{
			Check("/deeds");
		}
		Im.TextColored(Cyan, "Quest bonus:");
		ImGui.SameLine();
		ImGui.TextUnformatted((_qbCount.Length > 0) ? _qbCount : "-");
		ImGui.SameLine();
		Im.TextColored(col, "(" + When(_qbAt) + ")");
		if (_bonus.Count > 0)
		{
			if (ImGui.BeginTable("bonuslist", 2, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
			{
				ImGui.TableSetupColumn("XP multiplier (" + When(_bonusAt) + ")", ImGuiTableColumnFlags.WidthFixed, 200f);
				ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthStretch);
				ImGui.TableHeadersRow();
				foreach (KeyValuePair<string, string> bonu in _bonus)
				{
					ImGui.TableNextRow();
					bool flag = bonu.Key.IndexOf("Total", StringComparison.OrdinalIgnoreCase) >= 0;
					ImGui.TableSetColumnIndex(0);
					Im.TextColored(flag ? Yellow : Cyan, bonu.Key);
					ImGui.TableSetColumnIndex(1);
					if (flag)
					{
						Im.TextColored(Yellow, bonu.Value);
					}
					else
					{
						ImGui.TextUnformatted(bonu.Value);
					}
				}
				ImGui.EndTable();
			}
		}
		else
		{
			Im.TextDisabled("XP multipliers: nothing yet - click /bonus.");
		}
		ImGui.Separator();
		if (_deeds.Count == 0)
		{
			Im.TextDisabled("Deeds: nothing yet - click /deeds.");
			return;
		}
		Im.TextColored(_deedsOn ? vector : Yellow, _deedsHead);
		Im.TextColored(col, "as of " + When(_deedsAt) + (_deedsOn ? "" : " - deeds bonuses are OFF, so none are active"));
		foreach (DeedTier deed in _deeds)
		{
			Vector4 col2;
			if (deed.Unlocked && _deedsOn)
			{
				col2 = vector;
			}
			else
			{
				col2 = (deed.Unlocked ? Yellow : vector2);
			}
			ImGui.PushStyleColor(ImGuiCol.Text, col2);
			bool flag2 = ImGui.CollapsingHeader(deed.QB.ToString("N0") + " QB" + (deed.Unlocked ? " - unlocked" : "") + "##deed" + deed.QB);
			ImGui.PopStyleColor();
			if (!flag2)
			{
				continue;
			}
			ImGui.Indent();
			foreach (string line in deed.Lines)
			{
				if (line.StartsWith("("))
				{
					Im.TextColored(col, line);
				}
				else
				{
					Im.TextColored(col2, line);
				}
			}
			ImGui.Unindent();
		}
	}

	public static int EnlLevelNeeded(int n)
	{
		return 274 + n;
	}

	public static int EnlTokensNeeded(int n)
	{
		return (n >= 6) ? (n - 5) : 0;
	}

	public static bool EnlUsesMedallions(int n)
	{
		return n > 150;
	}

	public static long EnlLumNeeded(int n)
	{
		long result;
		if (n < 50)
		{
			result = 0L;
		}
		else
		{
			result = ((n > 150) ? ((long)n * 1000000000L) : ((long)n * 100000000L));
		}
		return result;
	}

	private static int EnlCount(out string source)
	{
		source = "";
		if (_enlManual > 0)
		{
			source = "typed in";
			return _enlManual;
		}
		try
		{
			int charProperty = CoreManager.Current.CharacterFilter.GetCharProperty(390);
			if (charProperty > 0)
			{
				source = "character";
				return charProperty;
			}
		}
		catch
		{
		}
		foreach (KeyValuePair<string, string> bonu in _bonus)
		{
			if (bonu.Key.IndexOf("Enlighten", StringComparison.OrdinalIgnoreCase) < 0 || !double.TryParse(bonu.Value.TrimStart(new char[2] { 'x', 'X' }).Replace(",", ""), NumberStyles.Float, EnlInv, out var result) || !(result >= 1.0))
			{
				continue;
			}
			source = "from /bonus (x" + result.ToString("0.00", EnlInv) + ")";
			return (int)Math.Round((result - 1.0) / 0.1);
		}
		return -1;
	}

	private static int Have(string name)
	{
		int value;
		return _enlHave.TryGetValue(name, out value) ? value : 0;
	}

	private static void CountEnlItems(bool now)
	{
		if (!now && (DateTime.Now - _enlCountAt).TotalSeconds < 2.0)
		{
			return;
		}
		_enlCountAt = DateTime.Now;
		_enlHave.Clear();
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				string name = item.Name;
				if (Array.IndexOf(EnlItems, name) >= 0)
				{
					int val = item.Values(LongValueKey.StackCount, 1);
					_enlHave[name] = Have(name) + Math.Max(1, val);
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static int FirstStack(string name)
	{
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
				{
					return item.Id;
				}
			}
		}
		catch
		{
		}
		return 0;
	}

	private static long BankNum(string name)
	{
		foreach (BankLine item in _bank)
		{
			if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
			{
				string s = item.Value.Split(' ')[0].Replace(",", "");
				if (long.TryParse(s, NumberStyles.Integer, EnlInv, out var result))
				{
					return result;
				}
			}
		}
		return -1L;
	}

	public static string Lum(long v)
	{
		if (v >= 1000000000000000L)
		{
			return ((double)v / 1000000000000000.0).ToString("0.###", EnlInv) + " Q";
		}
		if (v >= 1000000000000L)
		{
			return ((double)v / 1000000000000.0).ToString("0.###", EnlInv) + " T";
		}
		if (v >= 1000000000)
		{
			return ((double)v / 1000000000.0).ToString("0.###", EnlInv) + " B";
		}
		if (v >= 1000000)
		{
			return ((double)v / 1000000.0).ToString("0.#", EnlInv) + " M";
		}
		return v.ToString("N0", EnlInv);
	}

	private static void MkStart()
	{
		_mkOn = true;
		_mkWaiting = false;
		_mkMisses = 0;
		_mkMade = 0;
		_mkCounts.Clear();
		_mkPeaceAsked = DateTime.MinValue;
		_mkNextAt = DateTime.MinValue;
		_mkStatus = "starting";
		_mkWithdrawing = false;
		Check("/bank");
		_mkNextAt = DateTime.Now.AddSeconds(2.0);
		Util.WriteToChat("Medallion maker: started.");
	}

	private static void MkStop(string why)
	{
		if (!_mkOn)
		{
			return;
		}
		_mkOn = false;
		_mkWaiting = false;
		_mkStatus = why;
		List<string> list = new List<string>();
		foreach (KeyValuePair<string, int> mkCount in _mkCounts)
		{
			list.Add(mkCount.Value + " " + mkCount.Key);
		}
		Util.WriteToChat("Medallion maker: stopped - " + why + ((list.Count > 0) ? (" (made " + string.Join(", ", list.ToArray()) + ")") : "") + ".");
	}

	private static void MkChat(string text)
	{
		if (_mkOn && _mkWaiting && (text.IndexOf("link together effortlessly", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("combine the trophy with the powder", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("combine a part of a medallion with an enlightenment token", StringComparison.OrdinalIgnoreCase) >= 0))
		{
			_mkGot = true;
		}
	}

	private static void MkTick()
	{
		if (!_mkOn)
		{
			return;
		}
		try
		{
			HooksWrapper actions = CoreManager.Current.Actions;
			if (actions.CombatMode != CombatState.Peace)
			{
				if (_mkPeaceAsked == DateTime.MinValue)
				{
					_mkPeaceAsked = DateTime.Now;
					actions.SetCombatMode(CombatState.Peace);
					_mkStatus = "going to peace mode";
				}
				else if (!((DateTime.Now - _mkPeaceAsked).TotalSeconds < 4.0) || _mkMade != 0 || _mkWaiting)
				{
					MkStop("left peace mode");
				}
				return;
			}
			if (_mkPeaceAsked == DateTime.MinValue)
			{
				_mkPeaceAsked = DateTime.Now;
			}
			if (_mkWaiting && _mkStep == "Fiun")
			{
				CountEnlItems(now: true);
				int num = Have("Part of a Medallion");
				if (num < _mkPartsBefore)
				{
					_mkWaiting = false;
					_mkMisses = 0;
					int num2 = _mkPartsBefore - num;
					_mkMade += num2;
					_mkCounts.TryGetValue("medallions (Fiun)", out var value);
					_mkCounts["medallions (Fiun)"] = value + num2;
					_mkNextAt = DateTime.Now.AddSeconds(1.5);
				}
				else
				{
					if (!((DateTime.Now - _mkSentAt).TotalSeconds > 8.0))
					{
						return;
					}
					_mkWaiting = false;
					if (++_mkMisses >= 3)
					{
						MkStop("Fiun didn't take the parts 3 times");
						return;
					}
					_mkNextAt = DateTime.Now.AddSeconds(1.0);
				}
			}
			if (_mkWaiting)
			{
				if (_mkGot)
				{
					_mkWaiting = false;
					_mkMisses = 0;
					_mkMade++;
					_mkCounts.TryGetValue(_mkStep, out var value2);
					_mkCounts[_mkStep] = value2 + 1;
					_mkNextAt = DateTime.Now.AddMilliseconds(400.0);
				}
				else
				{
					if (!((DateTime.Now - _mkSentAt).TotalSeconds > 5.0))
					{
						return;
					}
					_mkWaiting = false;
					if (++_mkMisses >= 3)
					{
						MkStop("3 combines in a row did nothing");
						return;
					}
					_mkNextAt = DateTime.Now.AddSeconds(1.0);
				}
			}
			if (DateTime.Now < _mkNextAt)
			{
				return;
			}
			CountEnlItems(now: true);
			if (MkStopAt > 0 && Have("Enlightenment Medallion") >= MkStopAt)
			{
				MkStop("you have " + Have("Enlightenment Medallion") + " medallions");
			}
			else
			{
				if (MkBankStep())
				{
					return;
				}
				if (MkFiun)
				{
					int num3 = Math.Min(Have("Part of a Medallion"), Have("Enlightenment Token"));
					WorldObject worldObject = null;
					int mkFiunN = 0;
					if (num3 >= 100)
					{
						worldObject = NearNpc("Fiun of Great Enlightenment");
						mkFiunN = 100;
					}
					if (worldObject == null && num3 >= 10)
					{
						worldObject = NearNpc("Fiun of Enlightenment");
						mkFiunN = 10;
					}
					if (worldObject != null)
					{
						_mkStep = "Fiun";
						_mkWaiting = true;
						_mkSentAt = DateTime.Now;
						_mkPartsBefore = Have("Part of a Medallion");
						_mkFiunN = mkFiunN;
						_mkStatus = "handing " + mkFiunN + " parts to " + worldObject.Name;
						Util.Command("/ub give " + mkFiunN + " Part of a Medallion to " + worldObject.Name);
						return;
					}
				}
				string text = null;
				string text2 = null;
				string text3 = null;
				if (MkMedallions && Have("Part of a Medallion") > 0 && Have("Enlightenment Token") > 0)
				{
					text = "Part of a Medallion";
					text2 = "Enlightenment Token";
					text3 = "medallions";
				}
				else if (MkParts && Have("Trophy") > 0 && Have("Yellow Aetheria Powder") > 0)
				{
					text = "Trophy";
					text2 = "Yellow Aetheria Powder";
					text3 = "parts";
				}
				else if (MkPowder && Have("Aetheria Desiccant") > 0 && Have("Yellow Aetheria Chunk") > 0)
				{
					text = "Aetheria Desiccant";
					text2 = "Yellow Aetheria Chunk";
					text3 = "powder";
				}
				if (text == null)
				{
					MkStop("nothing left to combine");
					return;
				}
				int num4 = FirstStack(text);
				int num5 = FirstStack(text2);
				if (num4 == 0 || num5 == 0)
				{
					MkStop("couldn't find " + ((num4 == 0) ? text : text2));
					return;
				}
				_mkStep = text3;
				_mkGot = false;
				_mkWaiting = true;
				_mkSentAt = DateTime.Now;
				_mkStatus = "making " + text3 + " (" + text + " on " + text2 + ")";
				actions.ApplyItem(num4, num5);
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			MkStop("error: " + ex.Message);
		}
	}

	private static WorldObject NearNpc(string name)
	{
		try
		{
			foreach (WorldObject item in CoreManager.Current.WorldFilter.GetByName(name))
			{
				if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase) && CombatEngine.Distance(item) <= 12.0)
				{
					return item;
				}
			}
		}
		catch
		{
		}
		return null;
	}

	private static void DrawEnl()
	{
		if (!ImGui.BeginTabBar("##enltabs"))
		{
			return;
		}
		if (ImGui.BeginTabItem("Main##enlmain"))
		{
			DrawEnlMain();
			ImGui.EndTabItem();
		}
		if (ImGui.BeginTabItem((AeOn ? "Auto enlighten (running)" : "Auto enlighten") + "###enlauto"))
		{
			int num = EnlCount(out var _);
			if (num < 0)
			{
				Im.TextDisabled("Your enlightenment count isn't known - click Update on the Main tab or type it there.");
			}
			else
			{
				DrawAutoEnl(num);
			}
			ImGui.EndTabItem();
		}
		if (ImGui.BeginTabItem((_rtOn ? "Retrain (running)" : "Retrain") + "###enlrt"))
		{
			DrawRetrain();
			ImGui.EndTabItem();
		}
		ImGui.EndTabBar();
	}

	private static void DrawEnlMain()
	{
		Vector4 vector = new Vector4(0.45f, 0.9f, 0.45f, 1f);
		Vector4 vector2 = new Vector4(1f, 0.5f, 0.45f, 1f);
		Vector4 vector3 = new Vector4(0.6f, 0.6f, 0.6f, 1f);
		CountEnlItems(now: false);
		if (ImGui.Button("Update"))
		{
			Check("/bonus");
			Check("/bank");
			CountEnlItems(now: true);
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Sends /bonus (your enlightenment count) and /bank (luminance, tokens) quietly.");
		}
		int num = EnlCount(out var source);
		int num2 = 0;
		try
		{
			num2 = CoreManager.Current.CharacterFilter.Level;
		}
		catch
		{
		}
		ImGui.SameLine();
		Im.TextColored(Cyan, "Enlightenment");
		ImGui.SameLine();
		int v = ((num >= 0) ? num : 0);
		ImGui.SetNextItemWidth(100f);
		if (ImGui.InputInt("##enlcur", ref v, 1, 10))
		{
			_enlManual = Math.Max(0, v);
			_deedsDirtyAt = DateTime.Now;
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Your enlightenments. Worked out from the character (or /bonus) - if it's wrong, type the right number\n(set it to 0 to go back to working it out).");
		}
		ImGui.SameLine();
		Im.TextColored(vector3, (num < 0) ? "unknown - click Update or type it" : ("(" + source + ")"));
		if (num < 0)
		{
			return;
		}
		int num3 = num + 1;
		long num4 = BankNum("Luminance");
		long num5 = Math.Max(0L, BankNum("Enlightenment Tokens"));
		long num6 = Math.Max(0L, BankNum("Enlightened Coins"));
		bool flag = EnlUsesMedallions(num3);
		int num7 = EnlTokensNeeded(num3);
		int num8 = (flag ? Have("Enlightenment Medallion") : Have("Enlightenment Token"));
		ImGui.Separator();
		Im.TextColored(Cyan, "Enlightenment " + num3 + " needs:");
		if (ImGui.BeginTable("enlneed", 3, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 150f);
			ImGui.TableSetupColumn("Needed", ImGuiTableColumnFlags.WidthFixed, 110f);
			ImGui.TableSetupColumn("You have", ImGuiTableColumnFlags.WidthStretch);
			ImGui.TableHeadersRow();
			NeedRow("Level", EnlLevelNeeded(num3).ToString(), (num2 > 0) ? num2.ToString() : "?", num2 >= EnlLevelNeeded(num3), vector, vector2);
			if (num7 > 0)
			{
				string what = (flag ? "Medallions" : "Tokens");
				string need = num7.ToString("N0", EnlInv);
				string text = num8.ToString("N0", EnlInv);
				string? text2;
				if (flag)
				{
					text2 = "";
				}
				else
				{
					text2 = ((num5 > 0) ? (" (+" + num5 + " in the bank)") : "");
				}
				NeedRow(what, need, text + text2, num8 >= num7, vector, vector2);
			}
			long num9 = EnlLumNeeded(num3);
			if (num9 > 0)
			{
				NeedRow("Luminance", Lum(num9), (num4 >= 0) ? (Lum(num4) + " banked") : "? - click Update", num4 >= num9, vector, vector2);
			}
			ImGui.EndTable();
		}
		if (num3 >= 31)
		{
			Im.TextColored(vector3, "Also: Master rank in a society" + ((num3 > 150) ? ", and all 50 Paragon Weapon levels (ParagonEnlCompleted)." : "."));
		}
		Im.TextColored(vector3, "Enlighten with /enl - outside, standing still (portal somewhere outside, then a small jump).");
		if (flag && num8 < num7)
		{
			int num10 = num7 - num8;
			ImGui.Separator();
			Im.TextColored(Yellow, "To make the " + num10 + " missing medallion" + ((num10 == 1) ? "" : "s") + " (one each of):");
			int num11 = Have("Part of a Medallion");
			int num12 = Have("Enlightenment Token");
			int num13 = Have("Trophy");
			int num14 = Have("Yellow Aetheria Powder");
			int num15 = Have("Yellow Aetheria Chunk");
			int num16 = Have("Aetheria Desiccant");
			int num17 = Math.Max(0, num10 - num11);
			int num18 = Math.Max(0, num17 - num14);
			long num19 = Math.Max(0, num10 - num12);
			Have2("Enlightenment Tokens", num12, num10, vector, vector2, (num5 > 0) ? (num5 + " more in the bank") : null);
			if (num19 > num5)
			{
				long num20 = num19 - num5;
				Im.TextColored((num6 >= num20 * 20) ? vector : vector2, "      buy " + num20 + " more = " + (num20 * 20).ToString("N0", EnlInv) + " Enlightened Coins (banked: " + num6.ToString("N0", EnlInv) + ")");
			}
			Have2("Parts of a Medallion", num11, num10, vector, vector2, null);
			if (num17 > 0)
			{
				Have2("    Trophies", num13, num17, vector, vector2, "VoD drops");
				Have2("    Yellow Aetheria Powder", num14, num17, vector, vector2, null);
				if (num18 > 0)
				{
					Have2("        Yellow Aetheria Chunks", num15, num18, vector, vector2, null);
					Have2("        Aetheria Desiccant", num16, num18, vector, vector2, null);
				}
			}
		}
		ImGui.Separator();
		Im.TextColored(Cyan, "Up to enlightenment");
		ImGui.SameLine();
		if (_enlTarget <= num)
		{
			_enlTarget = num + 10;
		}
		ImGui.SetNextItemWidth(110f);
		ImGui.InputInt("##enltarget", ref _enlTarget, 1, 10);
		ImGui.SameLine();
		if (ImGui.Button("Calc"))
		{
			_calcFor = _enlTarget;
			_calcTokens = 0;
			_calcMedals = 0;
			_calcLum = 0L;
			for (int i = num + 1; i <= _enlTarget; i++)
			{
				if (EnlUsesMedallions(i))
				{
					_calcMedals += EnlTokensNeeded(i);
				}
				else
				{
					_calcTokens += EnlTokensNeeded(i);
				}
				_calcLum += EnlLumNeeded(i);
			}
			_calcLevel = EnlLevelNeeded(_enlTarget);
		}
		if (_calcFor > num)
		{
			int num21 = Have("Enlightenment Medallion");
			int num22 = Have("Enlightenment Token");
			Im.TextColored(vector3, "From " + (num + 1) + " to " + _calcFor + " (" + (_calcFor - num) + " enlightenments):");
			Im.TextColored((num2 >= _calcLevel) ? vector : Vector4.One, "  Level " + _calcLevel + " for the last one");
			if (_calcTokens > 0)
			{
				Im.TextColored((num22 + num5 >= _calcTokens) ? vector : Vector4.One, "  " + _calcTokens.ToString("N0", EnlInv) + " tokens (have " + (num22 + num5) + ")");
			}
			if (_calcMedals > 0)
			{
				Im.TextColored((num21 >= _calcMedals) ? vector : Vector4.One, "  " + _calcMedals.ToString("N0", EnlInv) + " medallions (have " + num21 + ", short " + Math.Max(0, _calcMedals - num21).ToString("N0", EnlInv) + ")");
			}
			if (_calcLum > 0)
			{
				Im.TextColored((num4 >= _calcLum) ? vector : Vector4.One, "  " + Lum(_calcLum) + " luminance (banked " + ((num4 >= 0) ? Lum(num4) : "?") + ")");
			}
		}
		ImGui.Separator();
		DrawEnlBank();
		if (!ImGui.CollapsingHeader("Medallion maker" + (_mkOn ? " - running###mkhdr" : "###mkhdr")))
		{
			return;
		}
		Im.TextColored(vector3, "(peace mode only - stops if you leave it)");
		ImGui.Checkbox("Powder##mkp", ref MkPowder);
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Aetheria Desiccant on Yellow Aetheria Chunk -> Yellow Aetheria Powder");
		}
		ImGui.SameLine();
		ImGui.Checkbox("Parts##mkt", ref MkParts);
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Trophy on Yellow Aetheria Powder -> Part of a Medallion");
		}
		ImGui.SameLine();
		ImGui.Checkbox("Medallions##mkm", ref MkMedallions);
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Part of a Medallion on Enlightenment Token -> Enlightenment Medallion");
		}
		ImGui.SameLine();
		ImGui.Checkbox("Hand to Fiun##mkf", ref MkFiun);
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Standing by Fiun in Arwic: hands Parts of a Medallion over 100 at a time (Fiun of Great Enlightenment)\nor 10 at a time (Fiun of Enlightenment) - he turns them into medallions with your tokens.\nNeeds as many tokens as parts; whatever's left under 10 is combined by hand (Medallions ticked).");
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		ImGui.InputInt("stop at##mkstop", ref MkStopAt, 10, 50);
		if (MkStopAt < 0)
		{
			MkStopAt = 0;
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Stop once you carry this many medallions (0 = keep going until something runs out).");
		}
		if (!_mkOn)
		{
			if (ImGui.Button("Start##mk"))
			{
				MkStart();
			}
		}
		else if (ImGui.Button("Stop##mk"))
		{
			MkStop("stopped");
		}
		ImGui.SameLine();
		Im.TextColored(_mkOn ? Yellow : vector3, (_mkStatus.Length > 0) ? _mkStatus : "idle");
		Im.TextColored(vector3, "Carrying: " + Have("Enlightenment Medallion") + " medallions, " + Have("Enlightenment Token") + " tokens, " + Have("Part of a Medallion") + " parts, " + Have("Trophy") + " trophies, " + Have("Yellow Aetheria Powder") + " powder, " + Have("Yellow Aetheria Chunk") + " chunks, " + Have("Aetheria Desiccant") + " desiccant");
	}

	public static List<string> EnlPhoneLines(int target)
	{
		List<string> o = new List<string>();
		CountEnlItems(now: false);
		int num = EnlCount(out var _);
		if (num < 0)
		{
			o.Add("n|Enlightenment not known yet - Update on the Enl tab (or type it there).");
			return o;
		}
		int num2 = 0;
		try
		{
			num2 = CoreManager.Current.CharacterFilter.Level;
		}
		catch
		{
		}
		long num3 = BankNum("Luminance");
		long num4 = Math.Max(0L, BankNum("Enlightenment Tokens"));
		long coins = Math.Max(0L, BankNum("Enlightened Coins"));
		int num5 = Have("Enlightenment Token");
		int num6 = Have("Enlightenment Medallion");
		Func<long, string> func = (long v) => v.ToString("N0", EnlInv);
		Action<bool, string> action = (bool ok, string t) =>
		{
			o.Add((ok ? "g|" : "r|") + t);
		};
		o.Add("h|Enlightenment " + num);
		int n = num + 1;
		bool flag = EnlUsesMedallions(n);
		int num7 = EnlTokensNeeded(n);
		int num8 = (flag ? num6 : num5);
		o.Add("h|Enlightenment " + n + " needs:");
		action(num2 >= EnlLevelNeeded(n), "Level " + EnlLevelNeeded(n) + " (you: " + ((num2 > 0) ? num2.ToString() : "?") + ")");
		if (num7 > 0)
		{
			action(num8 >= num7, (flag ? "Medallions " : "Tokens ") + func(num7) + " (have " + func(num8) + ((flag || num4 == 0L) ? "" : (", +" + func(num4) + " in the bank")) + ")" + ((num8 >= num7) ? "" : (" - short " + func(num7 - num8))));
		}
		long num9 = EnlLumNeeded(n);
		if (num9 > 0)
		{
			action(num3 >= num9, "Luminance " + Lum(num9) + " (banked " + ((num3 >= 0) ? Lum(num3) : "?") + ")" + ((num3 >= 0 && num3 < num9) ? (" - short " + Lum(num9 - num3)) : ""));
		}
		if (flag && num8 < num7)
		{
			MedalLines(o, num7 - num8, num4, coins, "To make the missing medallions:");
		}
		if (target > num)
		{
			int num10 = 0;
			int num11 = 0;
			long num12 = 0L;
			for (int num13 = num + 1; num13 <= target; num13++)
			{
				if (EnlUsesMedallions(num13))
				{
					num11 += EnlTokensNeeded(num13);
				}
				else
				{
					num10 += EnlTokensNeeded(num13);
				}
				num12 += EnlLumNeeded(num13);
			}
			o.Add("h|Up to " + target + " (" + (target - num) + " more):");
			action(num2 >= EnlLevelNeeded(target), "Level " + EnlLevelNeeded(target) + " for the last one");
			if (num10 > 0)
			{
				action(num5 + num4 >= num10, "Tokens " + func(num10) + " (have " + func(num5 + num4) + ")" + ((num5 + num4 >= num10) ? "" : (" - short " + func(num10 - num5 - num4))));
			}
			if (num11 > 0)
			{
				action(num6 >= num11, "Medallions " + func(num11) + " (have " + func(num6) + ")" + ((num6 >= num11) ? "" : (" - short " + func(num11 - num6))));
			}
			if (num12 > 0)
			{
				action(num3 >= num12, "Luminance " + Lum(num12) + " (banked " + ((num3 >= 0) ? Lum(num3) : "?") + ")" + ((num3 >= 0 && num3 < num12) ? (" - short " + Lum(num12 - num3)) : ""));
			}
			if (num11 > num6)
			{
				MedalLines(o, num11 - num6, Math.Max(0L, num4 - Math.Max(0, num10 - num5)), coins, "To make the missing medallions:");
			}
		}
		else
		{
			int num14 = num;
			int num15 = 0;
			int num16 = 0;
			long num17 = 0L;
			string text = "";
			for (int num18 = num + 1; num18 < num + 2000; num18++)
			{
				int num19 = EnlTokensNeeded(num18);
				bool flag2 = EnlUsesMedallions(num18);
				if (num2 < EnlLevelNeeded(num18))
				{
					text = "level " + EnlLevelNeeded(num18);
					break;
				}
				if (!flag2 && num15 + num19 > num5 + num4)
				{
					text = "tokens";
					break;
				}
				if (flag2 && num16 + num19 > num6)
				{
					text = "medallions";
					break;
				}
				if (num3 >= 0 && num17 + EnlLumNeeded(num18) > num3)
				{
					text = "luminance";
					break;
				}
				if (flag2)
				{
					num16 += num19;
				}
				else
				{
					num15 += num19;
				}
				num17 += EnlLumNeeded(num18);
				num14 = num18;
			}
			o.Add("h|With what you have:");
			action(num14 > num, (num14 > num) ? ("You can go up to " + num14 + " (" + (num14 - num) + " more)" + ((text.Length > 0) ? (" - then short of " + text) : "")) : ("Not even the next one yet" + ((text.Length > 0) ? (" - short of " + text) : "")));
		}
		try
		{
			o.AddRange(EnlPlanLines(target));
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		return o;
	}

	private static void MedalLines(List<string> o, int missing, long bankTokens, long coins, string title)
	{
		Func<long, string> N = (long v) => v.ToString("N0", EnlInv);
		int num = Have("Part of a Medallion");
		int num2 = Have("Enlightenment Token");
		int num3 = Have("Trophy");
		int num4 = Have("Yellow Aetheria Powder");
		int num5 = Have("Yellow Aetheria Chunk");
		int num6 = Have("Aetheria Desiccant");
		int num7 = Math.Max(0, missing - num);
		int num8 = Math.Max(0, num7 - num4);
		long num9 = Math.Max(0, missing - num2);
		o.Add("n|" + title + " " + missing + " (one each of):");
		Action<string, long, long, string> action = (string what, long have, long need, string note) =>
		{
			o.Add(((have >= need) ? "g|" : "r|") + "  " + what + ": " + N(have) + " / " + N(need) + ((have >= need) ? "" : (" - short " + N(need - have))) + ((note != null) ? (" (" + note + ")") : ""));
		};
		action("Enlightenment Tokens", num2, missing, (bankTokens > 0) ? (N(bankTokens) + " in the bank") : null);
		if (num9 > bankTokens)
		{
			long num10 = num9 - bankTokens;
			o.Add(((coins >= num10 * 20) ? "g|" : "r|") + "    buy " + N(num10) + " = " + N(num10 * 20) + " Enlightened Coins (banked " + N(coins) + ")");
		}
		action("Parts of a Medallion", num, missing, null);
		if (num7 > 0)
		{
			action("  Trophies", num3, num7, "VoD drops");
			action("  Yellow Aetheria Powder", num4, num7, null);
			if (num8 > 0)
			{
				action("    Yellow Aetheria Chunks", num5, num8, null);
				action("    Aetheria Desiccant", num6, num8, null);
			}
		}
	}

	private static void NeedRow(string what, string need, string have, bool ok, Vector4 green, Vector4 red)
	{
		ImGui.TableNextRow();
		ImGui.TableSetColumnIndex(0);
		Im.TextColored(ok ? green : red, what);
		ImGui.TableSetColumnIndex(1);
		Im.TextColored(ok ? green : red, need);
		ImGui.TableSetColumnIndex(2);
		Im.TextColored(ok ? green : red, have);
	}

	private static void Have2(string what, long have, long need, Vector4 green, Vector4 red, string note)
	{
		Im.TextColored((have >= need) ? green : red, "  " + what + ": " + have.ToString("N0", EnlInv) + " / " + need.ToString("N0", EnlInv) + ((have >= need) ? "" : (" - short " + (need - have).ToString("N0", EnlInv))) + ((note != null) ? ("  (" + note + ")") : ""));
	}

	private static bool BankReady()
	{
		return (DateTime.Now - _bankCmdAt).TotalSeconds >= 6.0;
	}

	private static void BankAdd(string name, long delta)
	{
		foreach (BankLine item in _bank)
		{
			if (!string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
			{
				continue;
			}
			string[] array = item.Value.Split(new char[1] { ' ' }, 2);
			if (long.TryParse(array[0].Replace(",", ""), NumberStyles.Integer, EnlInv, out var result))
			{
				item.Value = Math.Max(0L, result + delta).ToString("N0", EnlInv) + ((array.Length > 1) ? (" " + array[1]) : "");
			}
			break;
		}
	}

	public static string WithdrawTokens(long n)
	{
		if (n < 1)
		{
			return "Nothing to withdraw.";
		}
		if (!BankReady())
		{
			return "The bank needs a few seconds between commands - try again.";
		}
		_bankCmdAt = DateTime.Now;
		Util.Command("/b w et " + n.ToString(EnlInv));
		BankAdd("Enlightenment Tokens", -n);
		_bankRecheckAt = DateTime.Now.AddSeconds(2.5);
		return "Withdrawing " + n + " Enlightenment Token" + ((n == 1) ? "" : "s") + ".";
	}

	private static Dictionary<int, WorldObject> VendorTokens()
	{
		Dictionary<int, WorldObject> dictionary = new Dictionary<int, WorldObject>();
		try
		{
			Vendor openVendor = CoreManager.Current.WorldFilter.OpenVendor;
			if (openVendor == null || openVendor.MerchantId == 0)
			{
				return dictionary;
			}
			foreach (WorldObject item in openVendor)
			{
				string input = item.Name ?? "";
				Match match = Regex.Match(input, "^(?:(\\d+)x )?Enlightenment Tokens?$", RegexOptions.IgnoreCase);
				if (match.Success)
				{
					int result = 1;
					if (match.Groups[1].Success)
					{
						int.TryParse(match.Groups[1].Value, out result);
					}
					if (result > 0 && !dictionary.ContainsKey(result))
					{
						dictionary[result] = item;
					}
				}
			}
		}
		catch
		{
		}
		return dictionary;
	}

	public static bool TokenVendorOpen()
	{
		return VendorTokens().Count > 0;
	}

	public static string BuyTokens(long n)
	{
		Dictionary<int, WorldObject> dictionary = VendorTokens();
		if (dictionary.Count == 0)
		{
			return "Buy tokens: open the aug gem vendor first (tokens are under Misc).";
		}
		long num = BankNum("Enlightened Coins");
		if (num >= 0)
		{
			n = Math.Min(n, num / 20);
		}
		if (n < 1)
		{
			return "Buy tokens: not enough Enlightened Coins (" + 20 + " each" + ((num >= 0) ? (", banked " + num.ToString("N0", EnlInv)) : "") + ").";
		}
		_buyLeft = n;
		_buyTotal = n;
		_buyDone = 0L;
		_buyWaiting = false;
		_buyMisses = 0;
		_buyNextAt = DateTime.MinValue;
		return "Buying " + n.ToString("N0", EnlInv) + " Enlightenment Token" + ((n == 1) ? "" : "s") + " (" + (n * 20).ToString("N0", EnlInv) + " coins)" + ((n > 100) ? (", " + 100 + " at a time") : "") + ".";
	}

	private static void BuyStop(string why)
	{
		if (_buyLeft > 0 || _buyWaiting)
		{
			_buyLeft = 0L;
			_buyWaiting = false;
			Util.WriteToChat("Buy tokens: " + why + " - bought " + _buyDone.ToString("N0", EnlInv) + " of " + _buyTotal.ToString("N0", EnlInv) + ".");
			_bankRecheckAt = DateTime.Now.AddSeconds(1.5);
		}
	}

	private static void BuyTick()
	{
		if (_buyLeft <= 0 && !_buyWaiting)
		{
			return;
		}
		if (_buyWaiting)
		{
			CountEnlItems(now: true);
			if (Have("Enlightenment Token") >= _buyTokBefore + _buyNow)
			{
				_buyWaiting = false;
				_buyMisses = 0;
				_buyDone += _buyNow;
				_buyLeft -= _buyNow;
				BankAdd("Enlightened Coins", -_buyNow * 20);
				_buyNextAt = DateTime.Now.AddMilliseconds(800.0);
				if (_buyLeft <= 0)
				{
					Util.WriteToChat("Buy tokens: bought " + _buyDone.ToString("N0", EnlInv) + ".");
					_bankRecheckAt = DateTime.Now.AddSeconds(1.5);
				}
			}
			else if (!((DateTime.Now - _buySentAt).TotalSeconds < 5.0))
			{
				_buyWaiting = false;
				if (++_buyMisses >= 2)
				{
					BuyStop("the vendor didn't sell (out of coins?)");
				}
				else
				{
					_buyNextAt = DateTime.Now.AddSeconds(1.0);
				}
			}
		}
		else
		{
			if (DateTime.Now < _buyNextAt)
			{
				return;
			}
			Dictionary<int, WorldObject> dictionary = VendorTokens();
			if (dictionary.Count != 0)
			{
				WorldObject worldObject = null;
				using (Dictionary<int, WorldObject>.Enumerator enumerator = dictionary.GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						worldObject = enumerator.Current.Value;
					}
				}
				int num = (int)Math.Min(_buyLeft, 100L);
				try
				{
					CountEnlItems(now: true);
					_buyTokBefore = Have("Enlightenment Token");
					HooksWrapper actions = CoreManager.Current.Actions;
					actions.VendorClearBuyList();
					actions.VendorAddBuyList(worldObject.Id, num);
					actions.VendorBuyAll();
					_buyNow = num;
					_buyWaiting = true;
					_buySentAt = DateTime.Now;
					return;
				}
				catch (Exception ex)
				{
					BuyStop(ex.Message);
					return;
				}
			}
			BuyStop("the vendor closed");
		}
	}

	private static void EnlBankTick()
	{
		BuyTick();
		CreditUseTick();
		if (!(_bankRecheckAt == DateTime.MinValue) && !(DateTime.Now < _bankRecheckAt))
		{
			_bankRecheckAt = DateTime.MinValue;
			QuietNext("/bank");
			Util.Command("/bank");
		}
	}

	private static int PartsPossible(bool countMaking)
	{
		int num = Have("Part of a Medallion");
		if (!countMaking)
		{
			return num;
		}
		int val = Have("Yellow Aetheria Powder") + Math.Min(Have("Yellow Aetheria Chunk"), Have("Aetheria Desiccant"));
		return num + Math.Min(Have("Trophy"), val);
	}

	private static bool MkBankStep()
	{
		if (_mkWithdrawing)
		{
			CountEnlItems(now: true);
			if (Have("Enlightenment Token") > _mkTokBefore)
			{
				_mkWithdrawing = false;
				_mkNextAt = DateTime.Now.AddMilliseconds(600.0);
				return true;
			}
			if ((DateTime.Now - _mkWdSent).TotalSeconds > 12.0)
			{
				_mkWithdrawing = false;
				MkStop("the tokens from the bank didn't arrive");
				return true;
			}
			_mkStatus = "waiting for the tokens from the bank";
			return true;
		}
		if (!MkBank || (!MkFiun && !MkMedallions))
		{
			return false;
		}
		int num = Have("Enlightenment Token");
		int num2 = PartsPossible(MkParts) - num;
		if (MkStopAt > 0)
		{
			num2 = Math.Min(num2, MkStopAt - Have("Enlightenment Medallion") - num);
		}
		if (num2 <= 0)
		{
			return false;
		}
		long num3 = BankNum("Enlightenment Tokens");
		if (num3 <= 0)
		{
			return false;
		}
		if (!BankReady())
		{
			_mkStatus = "waiting for the bank";
			return true;
		}
		long n = Math.Min(num2, num3);
		_mkTokBefore = num;
		_mkWdSent = DateTime.Now;
		_mkWithdrawing = true;
		_mkStatus = "withdrawing " + n + " tokens";
		WithdrawTokens(n);
		return true;
	}

	// the luminance a coin costs: Session > Lum's buying rate
	private static double LumPerCoin()
	{
		return LumTrack.LumPerCoinBuy;
	}

	private static double LumPerCoinCached()
	{
		if ((DateTime.Now - _lpcAt).TotalSeconds > 60.0)
		{
			_lpcAt = DateTime.Now;
			_lpc = LumPerCoin();
		}
		return _lpc;
	}

	private static EnlPlanResult PlanTo(int cur, int n, int lvl, long lum, long tokens, long medals, long parts, long coins, double lpc)
	{
		EnlPlanResult enlPlanResult = new EnlPlanResult
		{
			Reach = n
		};
		long num = 0L;
		long num2 = 0L;
		long num3 = 0L;
		for (int i = cur + 1; i <= n; i++)
		{
			if (EnlUsesMedallions(i))
			{
				num2 += EnlTokensNeeded(i);
			}
			else
			{
				num += EnlTokensNeeded(i);
			}
			num3 += EnlLumNeeded(i);
		}
		long num4 = (enlPlanResult.Parts = (enlPlanResult.Medallions = Math.Max(0L, num2 - medals)));
		enlPlanResult.PartsShort = Math.Max(0L, num4 - parts);
		enlPlanResult.TokensShort = Math.Max(0L, (enlPlanResult.TokensUsed = num + num4) - tokens);
		enlPlanResult.BuyTokens = enlPlanResult.TokensShort;
		long num5 = coins - enlPlanResult.BuyTokens * 20;
		enlPlanResult.LumNeeded = num3;
		enlPlanResult.LumShort = ((lum >= 0) ? Math.Max(0L, num3 - lum) : 0);
		if (enlPlanResult.LumShort > 0 && lpc > 0.0)
		{
			enlPlanResult.SellCoins = (long)Math.Ceiling((double)enlPlanResult.LumShort / lpc);
			enlPlanResult.SellLum = (long)((double)enlPlanResult.SellCoins * lpc);
		}
		if (lvl > 0 && lvl < EnlLevelNeeded(n))
		{
			enlPlanResult.Possible = false;
			enlPlanResult.Stop = "level " + EnlLevelNeeded(n);
		}
		else if (enlPlanResult.PartsShort > 0)
		{
			enlPlanResult.Possible = false;
			enlPlanResult.Stop = "parts of a medallion";
		}
		else if (num5 < 0)
		{
			enlPlanResult.Possible = false;
			enlPlanResult.Stop = "tokens";
		}
		else if (enlPlanResult.LumShort > 0 && (lpc <= 0.0 || enlPlanResult.SellCoins > num5))
		{
			enlPlanResult.Possible = false;
			enlPlanResult.Stop = "luminance";
		}
		return enlPlanResult;
	}

	private static void PlanInputs(out int cur, out int lvl, out long lum, out long tokens, out long medals, out long parts, out long coins, out double lpc)
	{
		CountEnlItems(now: false);
		cur = EnlCount(out var _);
		lvl = 0;
		try
		{
			lvl = CoreManager.Current.CharacterFilter.Level;
		}
		catch
		{
		}
		lum = BankNum("Luminance");
		tokens = Have("Enlightenment Token") + Math.Max(0L, BankNum("Enlightenment Tokens"));
		medals = Have("Enlightenment Medallion");
		parts = PartsPossible(countMaking: true);
		coins = Math.Max(0L, BankNum("Enlightened Coins"));
		lpc = LumPerCoinCached();
	}

	public static EnlPlanResult EnlPlan(int target)
	{
		PlanInputs(out var cur, out var lvl, out var lum, out var tokens, out var medals, out var parts, out var coins, out var lpc);
		if (cur < 0)
		{
			return null;
		}
		if (target > cur)
		{
			return PlanTo(cur, target, lvl, lum, tokens, medals, parts, coins, lpc);
		}
		EnlPlanResult enlPlanResult = new EnlPlanResult
		{
			Reach = cur
		};
		for (int i = cur + 1; i < cur + 3000; i++)
		{
			EnlPlanResult enlPlanResult2 = PlanTo(cur, i, lvl, lum, tokens, medals, parts, coins, lpc);
			if (!enlPlanResult2.Possible)
			{
				enlPlanResult.Stop = enlPlanResult2.Stop;
				break;
			}
			enlPlanResult = enlPlanResult2;
		}
		return enlPlanResult;
	}

	public static List<string> EnlPlanLines(int target)
	{
		List<string> list = new List<string>();
		PlanInputs(out var cur, out var _, out var lum, out var tokens, out var _, out var parts, out var coins, out var lpc);
		if (cur < 0)
		{
			return list;
		}
		Func<long, string> func = (long v) => v.ToString("N0", EnlInv);
		EnlPlanResult enlPlanResult = EnlPlan(target);
		if (enlPlanResult == null)
		{
			return list;
		}
		bool flag = target > cur;
		if (flag)
		{
			list.Add("h|Up to " + target + " with coins:");
		}
		else
		{
			list.Add("h|As far as it goes, coins included:");
		}
		if (!flag)
		{
			if (enlPlanResult.Reach <= cur)
			{
				list.Add("r|Not even the next one" + ((enlPlanResult.Stop.Length > 0) ? (" - short of " + enlPlanResult.Stop) : ""));
				return list;
			}
			list.Add("g|Up to " + enlPlanResult.Reach + " (" + (enlPlanResult.Reach - cur) + " more)" + ((enlPlanResult.Stop.Length > 0) ? (" - then short of " + enlPlanResult.Stop) : ""));
		}
		else
		{
			list.Add(enlPlanResult.Possible ? "g|Possible" : ("r|Not yet - short of " + enlPlanResult.Stop));
		}
		if (enlPlanResult.Medallions > 0)
		{
			list.Add(((enlPlanResult.PartsShort > 0) ? "r|" : "g|") + "  Make " + func(enlPlanResult.Medallions) + " medallions (parts on you or makeable: " + func(parts) + ")");
		}
		list.Add(((enlPlanResult.TokensShort == 0L) ? "g|" : "n|") + "  Tokens: " + func(enlPlanResult.TokensUsed) + " (on you + bank: " + func(tokens) + ")");
		if (enlPlanResult.BuyTokens > 0)
		{
			list.Add(((enlPlanResult.BuyTokens * 20 <= coins) ? "g|" : "r|") + "  Buy " + func(enlPlanResult.BuyTokens) + " tokens = " + func(enlPlanResult.BuyTokens * 20) + " coins (banked " + func(coins) + ")");
		}
		if (enlPlanResult.LumNeeded > 0)
		{
			list.Add(((enlPlanResult.LumShort == 0L) ? "g|" : "n|") + "  Luminance: " + Lum(enlPlanResult.LumNeeded) + " (banked " + ((lum >= 0) ? Lum(lum) : "?") + ")");
		}
		if (enlPlanResult.SellCoins > 0)
		{
			list.Add(((enlPlanResult.Possible || enlPlanResult.Stop != "luminance") ? "g|" : "r|") + "  Sell " + func(enlPlanResult.SellCoins) + " coins for ~" + Lum(enlPlanResult.SellLum) + " luminance (at " + Lum((long)lpc) + " per coin)");
		}
		else if (enlPlanResult.LumShort > 0 && lpc <= 0.0)
		{
			list.Add("r|  Short " + Lum(enlPlanResult.LumShort) + " luminance (set the Coin-Lum rate in the luminance tracker to plan selling coins)");
		}
		long num = coins - enlPlanResult.BuyTokens * 20 - enlPlanResult.SellCoins;
		if (num > 0 && enlPlanResult.Possible)
		{
			list.Add("n|  Coins left over: " + func(num));
		}
		return list;
	}

	public static long TokensToBuyNeeded(int target)
	{
		EnlPlanResult enlPlanResult = EnlPlan(target);
		if (enlPlanResult == null)
		{
			return 0L;
		}
		long num = Math.Max(0L, BankNum("Enlightened Coins"));
		return Math.Min(enlPlanResult.BuyTokens, num / 20);
	}

	public static long TokensToBuyMax()
	{
		return Math.Max(0L, BankNum("Enlightened Coins")) / 20;
	}

	private static string EnlBankCommand(string arg)
	{
		if (arg.StartsWith("buy"))
		{
			string text = arg.Substring(3).Trim();
			long result;
			if (text == "" || text == "need")
			{
				result = TokensToBuyNeeded(AeTarget);
			}
			else if (text == "max")
			{
				result = TokensToBuyMax();
			}
			else if (!long.TryParse(text, out result))
			{
				return "Usage: /mtank enl buy need | max | <number>";
			}
			if (result < 1)
			{
				return (text == "max") ? "Buy tokens: not enough Enlightened Coins (or /bank not read yet)." : ("Buy tokens: none needed for " + ((AeTarget > 0) ? ("enlightenment " + AeTarget) : "the plan") + ".");
			}
			return BuyTokens(result);
		}
		if (arg.StartsWith("withdraw"))
		{
			string text2 = arg.Substring(8).Trim();
			long num = BankNum("Enlightenment Tokens");
			long result2;
			if (text2 == "" || text2 == "all")
			{
				result2 = num;
			}
			else if (!long.TryParse(text2, out result2))
			{
				return "Usage: /mtank enl withdraw [number | all]";
			}
			if (result2 < 1)
			{
				return "No tokens in the bank (or /bank not read yet).";
			}
			return WithdrawTokens(result2);
		}
		return null;
	}

	private static void DrawEnlBank()
	{
		if (!ImGui.CollapsingHeader("Tokens & coins###enlbank"))
		{
			return;
		}
		Vector4 vector = new Vector4(0.45f, 0.9f, 0.45f, 1f);
		Vector4 vector2 = new Vector4(1f, 0.5f, 0.45f, 1f);
		Vector4 vector3 = new Vector4(0.6f, 0.6f, 0.6f, 1f);
		foreach (string item in EnlPlanLines(AeTarget))
		{
			string text = item.Substring(0, 1);
			string s = item.Substring(2);
			Im.TextColored(text switch
			{
				"h" => Cyan, 
				"r" => vector2, 
				"g" => vector, 
				_ => vector3, 
			}, s);
		}
		Im.TextColored(vector3, "(target = auto enlighten's: " + ((AeTarget > 0) ? AeTarget.ToString() : "none - as far as it goes") + ")");
		long num = TokensToBuyNeeded(AeTarget);
		long num2 = TokensToBuyMax();
		long num3 = Math.Max(0L, BankNum("Enlightenment Tokens"));
		if (_buyLeft > 0 || _buyWaiting)
		{
			Im.TextColored(Yellow, "Buying tokens: " + _buyDone.ToString("N0", EnlInv) + " of " + _buyTotal.ToString("N0", EnlInv));
			ImGui.SameLine();
			if (ImGui.SmallButton("Stop##buystop"))
			{
				BuyStop("stopped");
			}
		}
		bool flag = TokenVendorOpen() && _buyLeft <= 0 && !_buyWaiting;
		if (!flag)
		{
			ImGui.BeginDisabled();
		}
		if (ImGui.Button("Buy what's needed (" + num + ")##buyneed") && num > 0)
		{
			Util.WriteToChat(BuyTokens(num));
		}
		ImGui.SameLine();
		if (ImGui.Button("Buy all the coins allow (" + num2 + ")##buymax") && num2 > 0)
		{
			Util.WriteToChat(BuyTokens(num2));
		}
		if (!flag)
		{
			ImGui.EndDisabled();
		}
		ImGui.SameLine();
		if (ImGui.Button("Withdraw " + num3 + " from the bank##wdall") && num3 > 0)
		{
			Util.WriteToChat(WithdrawTokens(num3));
		}
		ImGui.Checkbox("Medallion maker withdraws tokens from the bank##mkbank", ref MkBank);
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("When the maker has parts (or can make them) but not enough tokens on you, it takes them from the bank\n(/b w et N) before handing parts to Fiun or combining.");
		}
		if (!flag)
		{
			Im.TextColored(vector3, "Buy buttons: open the aug gem vendor (tokens are under its Misc list).");
		}
	}

	public static void NoteFractureStreak()
	{
		if (_frWaiting)
		{
			_frNoDmg++;
		}
		_frStreakAt = DateTime.Now;
		_frWaiting = true;
	}

	private static void FractureTick()
	{
		if (_frWaiting && (DateTime.Now - _frStreakAt).TotalSeconds > 4.0)
		{
			_frWaiting = false;
			_frNoDmg++;
		}
	}

	private static void FractureReset()
	{
		_frPrimes = (_frBursts = (_frByStreak = (_frOnDeath = (_frHits = (_frNoDmg = 0)))));
		_frWaiting = false;
		_frDmg = (_frMax = (_frCur = 0L));
		_frLastHit = DateTime.MinValue;
	}

	private static void FractureChat(string text)
	{
		string input = text.Trim();
		if (FrPrimeRx.IsMatch(input))
		{
			_frPrimes++;
			return;
		}
		if (FrDeathRx.IsMatch(input))
		{
			_frDeathAt = DateTime.Now;
			return;
		}
		Match match = FrHitRx.Match(input);
		if (!match.Success || !long.TryParse(match.Groups["n"].Value.Replace(",", ""), out var result))
		{
			return;
		}
		if ((DateTime.Now - _frLastHit).TotalSeconds > 1.0)
		{
			_frBursts++;
			_frCur = 0L;
			if ((DateTime.Now - _frDeathAt).TotalSeconds <= 2.0)
			{
				_frOnDeath++;
			}
			else if (_frWaiting && (DateTime.Now - _frStreakAt).TotalSeconds <= 4.0)
			{
				_frByStreak++;
				_frWaiting = false;
			}
			else
			{
				_frOnDeath++;
			}
		}
		_frLastHit = DateTime.Now;
		_frHits++;
		_frDmg += result;
		_frCur += result;
		if (_frCur > _frMax)
		{
			_frMax = _frCur;
		}
	}

	private static void DrawFractureRow()
	{
		if (_frPrimes != 0 || _frBursts != 0 || _frNoDmg != 0)
		{
			string text = _frBursts.ToString("N0") + " burst" + ((_frBursts == 1) ? "" : "s") + " (" + _frByStreak + " by streak, " + _frOnDeath + " on death, " + _frNoDmg + " no damage)";
			if (_frBursts > 0)
			{
				text = text + "   avg " + Big((double)_frDmg / (double)_frBursts) + " · biggest " + Big(_frMax) + " · " + ((double)_frHits / (double)_frBursts).ToString("0.0") + " monsters each · total " + Big(_frDmg);
			}
			text = text + "   · " + _frPrimes + " primed";
			Row("Nether Fracture", text, "From chat: \"Your void enchantments prime ...\" (primed) and \"Your Nether Fracture strikes ...\" (each monster a burst hit).\nBy streak = within 4 s of MelkTank's Nether Streak release; on death = the prime burst when the monster died;\nno damage = a Nether Streak release with no Fracture line after it (4 s).\nAvg / biggest are per burst (all the monsters it hit together).");
		}
	}

	public static double PaceRoom()
	{
		return HourOn() ? Math.Max(0.0, HourFull - _hourKills) : -1.0;
	}

	private static bool HourOn()
	{
		return _hourStart != DateTime.MinValue && (DateTime.Now - _hourStart).TotalMinutes < 60.0;
	}

	// what a kill at this many kills into the hour pays: full to 375, then half for each 75 after
	private static double HourRate(double k)
	{
		if (k < HourFull) return 1.0;
		return Math.Pow(0.5, Math.Floor((k - HourFull) / HourStep) + 1.0);
	}

	private static double PaceKill()
	{
		double num = ((_paceCredit >= 0.0 && _paceZoneTier == SafeTier()) ? _paceCredit : 1.0);
		if (!HourOn())
		{
			_hourStart = DateTime.Now;
			_hourKills = 0.0;
		}
		double rate = HourRate(_hourKills);
		_hourKills += num;
		_paceSlowNow = rate < 1.0;
		return rate * num;
	}

	private static int SafeTier()
	{
		int result = -1;
		try
		{
			if (CurrentTier != null)
			{
				result = CurrentTier();
			}
		}
		catch
		{
		}
		return result;
	}

	private static void PaceChat(string text)
	{
		string text2 = (text ?? "").Trim();
		Match match;
		if ((match = PaceMyRx.Match(text2)).Success)
		{
			_paceMyTier = int.Parse(match.Groups[1].Value);
		}
		else if ((match = PaceZoneRx.Match(text2)).Success)
		{
			_paceZoneTier = int.Parse(match.Groups[1].Value);
		}
		else if ((match = PaceCreditRx.Match(text2)).Success)
		{
			_paceCredit = double.Parse(match.Groups[1].Value, CultureInfo.InvariantCulture) / 100.0;
		}
		else if (text2.IndexOf("coin hour", StringComparison.OrdinalIgnoreCase) >= 0 && (text2.IndexOf("first 375", StringComparison.OrdinalIgnoreCase) >= 0 || text2.IndexOf("per coin hour", StringComparison.OrdinalIgnoreCase) >= 0))
		{
			// "Prestige Coins from kills here, per coin hour: full for the first 375 kills, then 50 pct less every 75 kills" - the rule
		}
		else if (text2.IndexOf("starts a new coin hour", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			// "Your next coin kill starts a new coin hour (60 minutes)." - none running
			_hourStart = DateTime.MinValue;
			_hourKills = 0.0;
			_hourSynced = DateTime.Now;
			_paceChecked = DateTime.Now;
			_paceCheckedTier = SafeTier();
			_paceSlowNow = false;
		}
		else if (text2.IndexOf("coin hour", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			// the server's word on the coin hour (/tierdip, and its notice at each step): kills so far, minutes left
			Match k = HourKillsRx.Match(text2);
			string kv = k.Success ? (k.Groups[1].Success ? k.Groups[1].Value : k.Groups[2].Value) : null;
			if (kv != null && double.TryParse(kv.Replace(",", ""), NumberStyles.Float, CultureInfo.InvariantCulture, out var kills))
			{
				Match l = HourLeftRx.Match(text2);
				if (l.Success && int.TryParse(l.Groups[1].Value, out var left) && left <= 60)
				{
					_hourStart = DateTime.Now.AddMinutes(left - 60);
				}
				else if (!HourOn())
				{
					_hourStart = DateTime.Now;
				}
				// "Your coin hour so far counts as 12 kills here and ends in 58 minutes: your next kill here pays 100 pct of its
				// coins." - kills *here*: at this zone's credit (a half-credit zone's kill is half a kill of the hour)
				double here = (text2.IndexOf("kills here", StringComparison.OrdinalIgnoreCase) >= 0 && _paceCredit > 0.0) ? _paceCredit : 1.0;
				_hourKills = kills * here;
				_hourSynced = DateTime.Now;
				_paceChecked = DateTime.Now;
				_paceCheckedTier = SafeTier();
				_paceSlowNow = HourRate(_hourKills) < 1.0;
			}
			else if (text2.IndexOf("not started", StringComparison.OrdinalIgnoreCase) >= 0 || text2.IndexOf("no coin hour", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				_hourStart = DateTime.MinValue;
				_hourKills = 0.0;
				_hourSynced = DateTime.Now;
				_paceChecked = DateTime.Now;
				_paceCheckedTier = SafeTier();
			}
			else
			{
				Notes.Add("coin hour line not read: " + text2, "session", true);
			}
		}
		else
		{
			if (text2.IndexOf("Prestige Coin", StringComparison.OrdinalIgnoreCase) < 0 || text2.IndexOf("pace", StringComparison.OrdinalIgnoreCase) < 0)
			{
				return;
			}
			if (text2.IndexOf("full", StringComparison.OrdinalIgnoreCase) >= 0 && (text2.IndexOf("back", StringComparison.OrdinalIgnoreCase) >= 0 || text2.IndexOf("again", StringComparison.OrdinalIgnoreCase) >= 0))
			{
				_paceSlowNow = false;
				if (PaceRoom() < 1.0)
				{
					_paceRoom = 1.0;
					_paceAt = DateTime.Now;
				}
			}
			else if (text2.IndexOf("less", StringComparison.OrdinalIgnoreCase) >= 0 || text2.IndexOf("half", StringComparison.OrdinalIgnoreCase) >= 0 || text2.IndexOf("slow", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				_paceSlowNow = true;
				_paceRoom = 0.0;
				_paceAt = DateTime.Now;
			}
		}
	}

	private static bool QuietPace(string s)
	{
		if (DateTime.Now > _paceQuietUntil)
		{
			return false;
		}
		// "You are not in a T11+ zone: kills here give their normal rewards." - asked from a zone the tier reading took
		// for T11+ (it lags a portal): hidden, and not asked again here for 10 minutes
		if (s.IndexOf("not in a T11+ zone", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			_paceCheckedTier = SafeTier();
			_paceChecked = DateTime.Now;
			_paceQuietUntil = DateTime.MinValue;
			return true;
		}
		if (!PaceAnyRx.IsMatch(s.Trim()))
		{
			return false;
		}
		_paceQuietUntil = DateTime.Now.AddSeconds(2.0);
		return true;
	}

	private static void PaceTick()
	{
		int num = SafeTier();
		if (num < 11 || (DateTime.Now - _paceSent).TotalSeconds < 60.0 || (num == _paceCheckedTier && (DateTime.Now - _paceChecked).TotalMinutes < 10.0))
		{
			return;
		}
		try
		{
			if (Globals.Core.CharacterFilter.LoginStatus != 3)
			{
				return;
			}
		}
		catch
		{
			return;
		}
		_paceSent = DateTime.Now;
		_paceQuietUntil = DateTime.Now.AddSeconds(8.0);
		try
		{
			Globals.Core.Actions.InvokeChatParser("/tierdip");
		}
		catch
		{
		}
	}

	public static string PaceText()
	{
		if (!HourOn())
		{
			return "";
		}
		int left = Math.Max(0, (int)Math.Ceiling(60.0 - (DateTime.Now - _hourStart).TotalMinutes));
		double rate = HourRate(_hourKills);
		if (rate >= 1.0)
		{
			return " · coin hour: " + _hourKills.ToString("0", CultureInfo.InvariantCulture) + "/" + HourFull.ToString("0") + " full · " + left + "m left";
		}
		return " · coin hour: " + (rate * 100.0).ToString((rate < 0.1) ? "0.0" : "0", CultureInfo.InvariantCulture) + "% coins (" + _hourKills.ToString("0", CultureInfo.InvariantCulture) + " kills) · " + left + "m left";
	}

	private static string PaceTip()
	{
		string rule = "\nCoin hour: from your first Prestige Coin kill, 60 minutes. The first 375 kills pay full coins, then every 75 kills pay half the step before (50%, 25%, 12.5% ...).\nA kill below your tier uses its share of a kill. One count per character across every zone; relogging doesn't reset it.";
		if (!HourOn())
		{
			return rule + "\nNo coin hour running" + ((_hourStart != DateTime.MinValue) ? " - the last one ended; the next coin kill starts a new one." : " (or not known yet - MelkTank asks /tierdip in a T11+ zone).");
		}
		double next = (_hourKills < HourFull) ? (HourFull - _hourKills) : (HourStep - (_hourKills - HourFull) % HourStep);
		return rule + "\nThis hour: " + _hourKills.ToString("0.#", CultureInfo.InvariantCulture) + " kills, started " + _hourStart.ToString("h:mm tt") + ", ends " + _hourStart.AddMinutes(60.0).ToString("h:mm tt") + ". Now paying " + (HourRate(_hourKills) * 100.0).ToString("0.#", CultureInfo.InvariantCulture) + "%; " + next.ToString("0", CultureInfo.InvariantCulture) + " kills to the next step." + ((_paceMyTier > 0) ? ("\nYour reward tier T" + _paceMyTier + ((_paceZoneTier > 0) ? (", this zone T" + _paceZoneTier) : "") + ((_paceCredit >= 0.0) ? (" - a kill here counts " + (_paceCredit * 100.0).ToString("0") + "%.") : ".") + " (Your reward tier is capped by the best Tou Tou Endgame Portal Gem you carry.)") : "") + ((_hourSynced != DateTime.MinValue) ? ("\nRead from the server at " + _hourSynced.ToString("h:mm tt") + ", counted with MelkTank's kills since.") : "\nCounted with MelkTank's kills (not read from /tierdip yet).");
	}

	private static bool AutoTrained(int id)
	{
		return Array.IndexOf(RtAuto, id) >= 0;
	}

	private static List<RtEntry> RtDefault()
	{
		List<RtEntry> list = new List<RtEntry>();
		int[] rtAll = RtAll;
		foreach (int skill in rtAll)
		{
			list.Add(new RtEntry
			{
				Skill = skill
			});
		}
		return list;
	}

	private static bool Ticked(RtEntry e)
	{
		return e.Train || e.Enl || (AutoTrained(e.Skill) && e.Spec);
	}

	private static string SkillName(int id)
	{
		string value;
		return RtNames.TryGetValue(id, out value) ? value : ("skill " + id);
	}

	private static string GemName(int id)
	{
		return SkillName(id) + " Gem of Enlightenment";
	}

	private static string RtSave()
	{
		List<string> list = new List<string> { (RtAfterEnl ? "1" : "0") + (RtSpecAtEnd ? "1" : "0") + (RtLevelSkills ? "1" : "0") };
		foreach (RtEntry item in Rt)
		{
			list.Add(item.Skill + ":" + (item.Train ? "1" : "0") + (item.Spec ? "1" : "0") + (item.Enl ? "1" : "0"));
		}
		return string.Join(",", list.ToArray());
	}

	private static void RtLoad(string s)
	{
		string[] array = s.Split(',');
		if (array.Length == 0 || array[0].Length < 2)
		{
			return;
		}
		RtSpecAtEnd = array[0][1] == '1';
		if (array[0].Length >= 3)
		{
			RtLevelSkills = array[0][2] == '1';
		}
		List<RtEntry> list = new List<RtEntry>();
		for (int i = 1; i < array.Length; i++)
		{
			string[] array2 = array[i].Split(':');
			if (array2.Length >= 2 && array2[1].Length >= 2 && int.TryParse(array2[0], out var id) && Array.IndexOf(RtAll, id) >= 0 && !list.Exists((RtEntry x) => x.Skill == id))
			{
				list.Add(new RtEntry
				{
					Skill = id,
					Train = (array2[1][0] == '1'),
					Spec = (array2[1][1] == '1'),
					Enl = (array2[1].Length >= 3 && array2[1][2] == '1')
				});
			}
		}
		int[] rtAll = RtAll;
		foreach (int id2 in rtAll)
		{
			if (!list.Exists((RtEntry x) => x.Skill == id2))
			{
				list.Add(new RtEntry
				{
					Skill = id2
				});
			}
		}
		Rt = list;
	}

	private static TrainingType Training(int skill)
	{
		try
		{
			return CoreManager.Current.CharacterFilter.Skills[(CharFilterSkillType)skill].Training;
		}
		catch
		{
			return TrainingType.Unusable;
		}
	}

	private static bool Untrained(int skill)
	{
		return Training(skill) == TrainingType.Untrained;
	}

#if RETAIL
	public unsafe static int SkillCost(int skill, bool spec)
	{
		DBObj* ptr = null;
		try
		{
			ptr = DBObj.GetByEnum(4, 2, 268435460u);
			if (ptr == null)
			{
				return -1;
			}
			GetSkillBaseDel getSkillBaseDel = (GetSkillBaseDel)Marshal.GetDelegateForFunctionPointer((IntPtr)4831408, typeof(GetSkillBaseDel));
			SkillBase* ptr2 = (SkillBase*)(void*)getSkillBaseDel((IntPtr)ptr, (uint)skill);
			if (ptr2 == null)
			{
				return -1;
			}
			return (int)((!spec) ? ptr2->_trained_cost : ptr2->_specialized_cost);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			return -1;
		}
		finally
		{
			try
			{
				if (ptr != null)
				{
					ptr->Release();
				}
			}
			catch
			{
			}
		}
	}
#else
	public static int SkillCost(int skill, bool spec)
	{
		return -1;
	}
#endif

	public static string TrainSkill(int skill)
	{
		if (!Untrained(skill))
		{
			return SkillName(skill) + " isn't untrained";
		}
		int num = SkillCost(skill, spec: false);
		if (num <= 0)
		{
			return "couldn't read what " + SkillName(skill) + " costs";
		}
		int num2 = 0;
		try
		{
			num2 = CoreManager.Current.CharacterFilter.SkillPoints;
		}
		catch
		{
		}
		if (num2 < num)
		{
			return "not enough skill credits for " + SkillName(skill) + " (" + num2 + " of " + num + ")";
		}
		CM_Train.Event_TrainSkillAdvancementClass((uint)skill, (uint)num);
		return null;
	}

	public static bool Wield(int id)
	{
		try
		{
			CoreManager current = CoreManager.Current;
			int num = current.WorldFilter[id]?.Values(LongValueKey.EquipableSlots, 0) ?? 0;
			bool flag = num != 0 && (num & (num - 1)) == 0;
			if (flag)
			{
				int num2 = (((num & 0x3700000) != 0) ? 57671680 : num);
				int id2 = current.CharacterFilter.Id;
				foreach (WorldObject item in InvCache.All())
				{
					if (item.Id != id && item.Values(LongValueKey.Wielder, 0) == id2 && (item.Values(LongValueKey.EquippedSlots, 0) & num2) != 0)
					{
						flag = false;
						break;
					}
				}
			}
			if (flag)
			{
				CM_Inventory.Event_GetAndWieldItem((uint)id, (uint)num);
				return true;
			}
			current.Actions.UseItem(id, 0);
			return true;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			return false;
		}
	}

	private static WorldObject VendorItem(string name)
	{
		try
		{
			Vendor openVendor = CoreManager.Current.WorldFilter.OpenVendor;
			if (openVendor == null || openVendor.MerchantId == 0)
			{
				return null;
			}
			foreach (WorldObject item in openVendor)
			{
				if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
				{
					return item;
				}
			}
		}
		catch
		{
		}
		return null;
	}

	private static bool BuyOne(WorldObject item)
	{
		try
		{
			HooksWrapper actions = CoreManager.Current.Actions;
			actions.VendorClearBuyList();
			actions.VendorAddBuyList(item.Id, 1);
			actions.VendorBuyAll();
			return true;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			return false;
		}
	}

	private static void BuyGems()
	{
		List<string> list = new List<string>();
		List<string> list2 = new List<string>();
		try
		{
			HooksWrapper actions = CoreManager.Current.Actions;
			actions.VendorClearBuyList();
			foreach (RtEntry item in Rt)
			{
				if (item.Spec && Training(item.Skill) != TrainingType.Specialized && FirstStack(GemName(item.Skill)) == 0)
				{
					WorldObject worldObject = VendorItem(GemName(item.Skill));
					if (worldObject == null)
					{
						list2.Add(SkillName(item.Skill));
						continue;
					}
					actions.VendorAddBuyList(worldObject.Id, 1);
					list.Add(SkillName(item.Skill));
				}
			}
			if (list.Count > 0)
			{
				actions.VendorBuyAll();
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		Util.WriteToChat("Buy gems: " + ((list.Count > 0) ? ("bought " + string.Join(", ", list.ToArray())) : "nothing needed") + ((list2.Count > 0) ? ("; this vendor doesn't sell " + string.Join(", ", list2.ToArray())) : "") + ".");
	}

	private static bool RtNeedsTraining()
	{
		foreach (RtEntry item in Rt)
		{
			if (item.Enl && Untrained(item.Skill))
			{
				return true;
			}
		}
		return false;
	}

	private static void RtStart(bool spec)
	{
		_rtOn = true;
		_rtSpec = spec;
		_rtIdx = 0;
		_rtPhase = 0;
		_rtWait = 0;
		_rtFailed = null;
		_rtMissing.Clear();
		_rtSkipped.Clear();
		_rtStatus = "starting";
	}

	private static void RtDone(string failed)
	{
		_rtOn = false;
		_rtFailed = failed;
		if (RtLevelSkills && failed != "stopped")
		{
			Util.Command("/ilt levelskills");
		}
		List<string> list = new List<string>();
		list.AddRange(_rtSkipped);
		list.AddRange(_rtMissing);
		_rtStatus = failed ?? ("done" + ((list.Count > 0) ? (" - " + string.Join("; ", list.ToArray())) : ""));
		Util.WriteToChat("Retrain: " + _rtStatus + ".");
	}

	private static int FreeCredits()
	{
		try
		{
			return CoreManager.Current.CharacterFilter.SkillPoints;
		}
		catch
		{
			return 0;
		}
	}

	private static void RtTick()
	{
		if (!_rtOn)
		{
			return;
		}
		try
		{
			if (_rtWait != 0)
			{
				TrainingType trainingType = ((_rtPhase == 0) ? TrainingType.Trained : TrainingType.Specialized);
				if (Training(_rtWait) >= trainingType)
				{
					_rtWait = 0;
				}
				else if (!((DateTime.Now - _rtAt).TotalSeconds < (double)((_rtPhase == 0) ? 3 : 6)))
				{
					_rtSkipped.Add("stopped at " + SkillName(_rtWait) + ((_rtPhase == 0) ? " - it didn't train" : " - it didn't specialize"));
					RtDone(null);
				}
				return;
			}
			while (_rtIdx < Rt.Count)
			{
				RtEntry rtEntry = Rt[_rtIdx];
				TrainingType trainingType2 = Training(rtEntry.Skill);
				bool flag = (_rtSpec ? rtEntry.Train : rtEntry.Enl);
				bool flag2 = _rtSpec && rtEntry.Spec;
				if (flag && trainingType2 == TrainingType.Untrained)
				{
					int num = SkillCost(rtEntry.Skill, spec: false);
					if (num <= 0)
					{
						_rtSkipped.Add("stopped at " + SkillName(rtEntry.Skill) + " - its cost couldn't be read");
						RtDone(null);
					}
					else if (FreeCredits() < num)
					{
						_rtSkipped.Add("stopped at " + SkillName(rtEntry.Skill) + " - needs " + num + " credits, have " + FreeCredits());
						RtDone(null);
					}
					else
					{
						CM_Train.Event_TrainSkillAdvancementClass((uint)rtEntry.Skill, (uint)num);
						_rtPhase = 0;
						_rtWait = rtEntry.Skill;
						_rtAt = DateTime.Now;
						_rtStatus = "training " + SkillName(rtEntry.Skill);
					}
					return;
				}
				if (flag2 && trainingType2 == TrainingType.Trained)
				{
					int num2 = SkillCost(rtEntry.Skill, spec: false);
					int num3 = SkillCost(rtEntry.Skill, spec: true);
					if (num2 > 0 && num3 > num2 && FreeCredits() < num3 - num2)
					{
						_rtSkipped.Add("stopped at " + SkillName(rtEntry.Skill) + " - specializing needs " + (num3 - num2) + " credits, have " + FreeCredits());
						RtDone(null);
						return;
					}
					int num4 = FirstStack(GemName(rtEntry.Skill));
					if (num4 == 0)
					{
						WorldObject worldObject = VendorItem(GemName(rtEntry.Skill));
						if (worldObject == null)
						{
							_rtMissing.Add("stopped at " + SkillName(rtEntry.Skill) + " - no " + GemName(rtEntry.Skill) + " (open the gem vendor and press Train / spec now)");
							RtDone(null);
						}
						else if (_rtStatus == "buying " + GemName(rtEntry.Skill))
						{
							if (!((DateTime.Now - _rtAt).TotalSeconds < 6.0))
							{
								_rtMissing.Add("stopped at " + SkillName(rtEntry.Skill) + " - the gem didn't arrive");
								RtDone(null);
							}
						}
						else
						{
							BuyOne(worldObject);
							_rtAt = DateTime.Now;
							_rtStatus = "buying " + GemName(rtEntry.Skill);
						}
					}
					else
					{
						CoreManager.Current.Actions.UseItem(num4, 0);
						_rtPhase = 1;
						_rtWait = rtEntry.Skill;
						_rtAt = DateTime.Now;
						_rtStatus = "specializing " + SkillName(rtEntry.Skill);
					}
					return;
				}
				_rtIdx++;
			}
			RtDone(null);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			RtDone("error: " + ex.Message);
		}
	}

	private static void DrawRetrain()
	{
		Vector4 vector = new Vector4(0.6f, 0.6f, 0.6f, 1f);
		Vector4 vector2 = new Vector4(0.45f, 0.9f, 0.45f, 1f);
		Im.TextColored(vector, "Enl column: trained after each enlighten (auto enlighten, no gems). Train / Spec: Train / spec now, and the end of a run.");
		if (ImGui.Checkbox("When the run finishes, train / spec (Train and Spec columns)##rtend", ref RtSpecAtEnd))
		{
			_deedsDirtyAt = DateTime.Now;
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Once auto enlighten reaches the target or runs out of luminance / tokens / medallions (an enlighten would undo it):\nthe same as pressing Train / spec now. Gems you don't carry are bought from the open vendor.");
		}
		if (ImGui.Checkbox("Then /ilt levelskills##rtlvl", ref RtLevelSkills))
		{
			_deedsDirtyAt = DateTime.Now;
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("At the end of every retrain, sends /ilt levelskills - the server raises every skill it can to the max.");
		}
		if (ImGui.Button(_rtOn ? "Stop##rtnow" : "Train / spec now##rtnow"))
		{
			if (_rtOn)
			{
				RtDone("stopped");
			}
			else
			{
				RtStart(spec: true);
			}
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Goes down the list in order: trains each ticked skill, then specializes it if \"Spec\" is ticked, before the next one.\nStops at the first one your skill credits don't cover (it's still trained if specializing is what it can't afford), or whose gem you don't carry with no gem vendor open.\nGems are bought from the open vendor (1p, from the bank). Then /ilt levelskills.");
		}
		ImGui.SameLine();
		bool flag = false;
		try
		{
			Vendor openVendor = CoreManager.Current.WorldFilter.OpenVendor;
			flag = openVendor != null && openVendor.MerchantId != 0;
		}
		catch
		{
		}
		if (!flag)
		{
			ImGui.BeginDisabled();
		}
		if (ImGui.Button("Buy gems now##rtbuy"))
		{
			BuyGems();
		}
		if (!flag)
		{
			ImGui.EndDisabled();
		}
		if (ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenDisabled))
		{
			Im.SetTooltip(flag ? "Buys one gem for each \"Spec\" skill that isn't specialized yet and you don't already carry (1p each, from the bank)." : "Open the gem vendor first.");
		}
		ImGui.SameLine();
		int num = 0;
		try
		{
			num = CoreManager.Current.CharacterFilter.SkillPoints;
		}
		catch
		{
		}
		Im.TextColored(vector, "Credits " + num + ((_rtStatus.Length > 0) ? (" | " + _rtStatus) : ""));
		if (!ImGui.BeginTable("##rt2", 7, ImGuiTableFlags.RowBg | ImGuiTableFlags.BordersInnerV | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY, new Vector2(0f, ImGui.GetContentRegionAvail().Y)))
		{
			return;
		}
		ImGui.TableSetupScrollFreeze(0, 1);
		ImGui.TableSetupColumn("Train", ImGuiTableColumnFlags.WidthFixed, 44f);
		ImGui.TableSetupColumn("Spec", ImGuiTableColumnFlags.WidthFixed, 40f);
		ImGui.TableSetupColumn("Enl", ImGuiTableColumnFlags.WidthFixed, 34f);
		ImGui.TableSetupColumn("Order", ImGuiTableColumnFlags.WidthFixed, 56f);
		ImGui.TableSetupColumn("Skill", ImGuiTableColumnFlags.WidthStretch);
		ImGui.TableSetupColumn("Now", ImGuiTableColumnFlags.WidthFixed, 84f);
		ImGui.TableSetupColumn("Cost", ImGuiTableColumnFlags.WidthFixed, 70f);
		ImGui.TableHeadersRow();
		int num2 = -1;
		int num3 = 0;
		bool flag2 = false;
		for (int i = 0; i < Rt.Count; i++)
		{
			RtEntry rtEntry = Rt[i];
			ImGui.PushID(rtEntry.Skill);
			ImGui.TableNextRow();
			ImGui.TableNextColumn();
			bool flag3 = AutoTrained(rtEntry.Skill);
			if (flag3)
			{
				rtEntry.Train = false;
				rtEntry.Enl = false;
				ImGui.BeginDisabled();
			}
			if (ImGui.Checkbox("##t", ref rtEntry.Train))
			{
				_deedsDirtyAt = DateTime.Now;
			}
			if (flag3)
			{
				ImGui.EndDisabled();
			}
			if (flag3 && ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenDisabled))
			{
				Im.SetTooltip("Comes trained - it can only be specialized");
			}
			ImGui.TableNextColumn();
			if (ImGui.Checkbox("##s", ref rtEntry.Spec))
			{
				if (rtEntry.Spec && !flag3)
				{
					rtEntry.Train = true;
				}
				_deedsDirtyAt = DateTime.Now;
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Specialize it with " + GemName(rtEntry.Skill));
			}
			ImGui.TableNextColumn();
			if (flag3)
			{
				ImGui.BeginDisabled();
			}
			if (ImGui.Checkbox("##e", ref rtEntry.Enl))
			{
				_deedsDirtyAt = DateTime.Now;
			}
			if (flag3)
			{
				ImGui.EndDisabled();
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Train it after each enlighten (auto enlighten) - no gems");
			}
			ImGui.TableNextColumn();
			if (Im.UpButton("##u"))
			{
				num2 = i;
				num3 = -1;
				flag2 = Im.Far;
				Im.Far = false;
			}
			ImGui.SameLine(0f, 2f);
			if (Im.DownButton("##d"))
			{
				num2 = i;
				num3 = 1;
				flag2 = Im.Far;
				Im.Far = false;
			}
			ImGui.TableNextColumn();
			if (rtEntry.Train || rtEntry.Enl || (flag3 && rtEntry.Spec))
			{
				Im.Text(SkillName(rtEntry.Skill));
			}
			else
			{
				Im.TextColored(vector, SkillName(rtEntry.Skill));
			}
			ImGui.TableNextColumn();
			TrainingType trainingType = Training(rtEntry.Skill);
			Im.TextColored((trainingType >= TrainingType.Trained) ? vector2 : vector, trainingType switch
			{
				TrainingType.Untrained => "untrained", 
				TrainingType.Trained => "trained", 
				TrainingType.Specialized => "specialized", 
				_ => "-", 
			});
			ImGui.TableNextColumn();
			Im.TextColored(vector, RtCostText(rtEntry.Skill));
			ImGui.PopID();
		}
		if (num2 >= 0)
		{
			int j;
			for (j = num2 + num3; j >= 0 && j < Rt.Count; j += num3)
			{
				if (!Ticked(Rt[num2]))
				{
					break;
				}
				if (Ticked(Rt[j]))
				{
					break;
				}
			}
			if (flag2)
			{
				if (num3 < 0)
				{
					j = 0;
				}
				else
				{
					j = Rt.Count - 1;
					if (Ticked(Rt[num2]))
					{
						int val = Rt.FindLastIndex((RtEntry x) => Ticked(x));
						j = Math.Max(num2, val);
					}
				}
			}
			if (j >= 0 && j < Rt.Count)
			{
				RtEntry item = Rt[num2];
				Rt.RemoveAt(num2);
				Rt.Insert(j, item);
				_deedsDirtyAt = DateTime.Now;
			}
		}
		ImGui.EndTable();
	}

	private static string RtCostText(int skill)
	{
		if (_rtCost.TryGetValue(skill, out var value))
		{
			return value;
		}
		int num = SkillCost(skill, spec: false);
		int num2 = SkillCost(skill, spec: true);
		value = ((num < 0) ? "?" : (num + ((num2 > 0) ? (" / " + num2) : "")));
		if (num >= 0)
		{
			_rtCost[skill] = value;
		}
		return value;
	}
}
