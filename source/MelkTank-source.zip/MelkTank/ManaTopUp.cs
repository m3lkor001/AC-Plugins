using System;
using System.Collections.Generic;
using Decal.Adapter.Wrappers;

namespace MelkTank;

public class ManaTopUp
{
	private const int EquippedSlotsKey = 10;

	private readonly Settings _s;

	private readonly Action<string> _log;

	private DateTime _nextSweep = DateTime.MinValue;

	private DateTime _nextId = DateTime.MinValue;

	private DateTime _cooldownUntil = DateTime.MinValue;

	private DateTime _nextLow = DateTime.MinValue;

	private readonly Queue<int> _toId = new Queue<int>();

	public string Status = "";

	public string Lowest = "";

	private int _lastLowId;

	private readonly Dictionary<int, int> _noNeed = new Dictionary<int, int>();

	public ManaTopUp(Settings s, Action<string> log)
	{
		_s = s;
		_log = log;
	}

	public void OnChat(string text)
	{
		if (string.IsNullOrEmpty(text) || text.IndexOf("no items equipped that need mana", StringComparison.OrdinalIgnoreCase) < 0)
		{
			return;
		}
		if (_lastLowId != 0)
		{
			int value = -1;
			try
			{
				WorldObject worldObject = Globals.Core.WorldFilter[_lastLowId];
				if (worldObject != null)
				{
					value = worldObject.Values(LongValueKey.CurrentMana);
				}
			}
			catch
			{
			}
			_noNeed[_lastLowId] = value;
		}
		_cooldownUntil = DateTime.Now.AddSeconds(60.0);
		_nextSweep = DateTime.Now.AddSeconds(2.0);
		Status = "nothing needed mana (gear re-read)";
	}

	private bool Skip(WorldObject o)
	{
		if (!_noNeed.TryGetValue(o.Id, out var value))
		{
			return false;
		}
		int num = -1;
		try
		{
			num = o.Values(LongValueKey.CurrentMana);
		}
		catch
		{
		}
		if (num != value)
		{
			_noNeed.Remove(o.Id);
			return false;
		}
		return true;
	}

	private static List<WorldObject> Equipped()
	{
		List<WorldObject> list = new List<WorldObject>();
		int num = 0;
		try
		{
			num = Globals.Core.CharacterFilter.Id;
		}
		catch
		{
		}
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				bool flag = false;
				try
				{
					flag = item.Values(LongValueKey.EquippedSlots) != 0 || item.Values(LongValueKey.Wielder) == num;
				}
				catch
				{
				}
				if (flag)
				{
					int num2 = 0;
					try
					{
						num2 = item.Values(LongValueKey.MaximumMana);
					}
					catch
					{
					}
					if (num2 > 0)
					{
						list.Add(item);
					}
				}
			}
		}
		catch
		{
		}
		return list;
	}

	private static double Pct(WorldObject o)
	{
		try
		{
			int num = o.Values(LongValueKey.MaximumMana);
			int num2 = o.Values(LongValueKey.CurrentMana);
			return (num > 0) ? ((double)num2 * 100.0 / (double)num) : 100.0;
		}
		catch
		{
			return 100.0;
		}
	}

	private int FindStone()
	{
		foreach (WeaponItem item in _s.Items)
		{
			if (item.Kind != WeaponKind.ManaStone)
			{
				continue;
			}
			try
			{
				WorldObject worldObject = Globals.Core.WorldFilter[item.Id];
				if (worldObject != null && InPack(worldObject.Id))
				{
					return worldObject.Id;
				}
				foreach (WorldObject item2 in InvCache.All())
				{
					if (string.Equals(item2.Name, item.Name, StringComparison.OrdinalIgnoreCase))
					{
						return item2.Id;
					}
				}
			}
			catch
			{
			}
		}
		List<string> list = new List<string>();
		string[] array = (_s.ManaStoneNames ?? "").Split(new char[2] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries);
		foreach (string text in array)
		{
			if (text.Trim().Length > 0)
			{
				list.Add(text.Trim());
			}
		}
		int num = 0;
		try
		{
			foreach (WorldObject item3 in InvCache.All())
			{
				string text2 = item3.Name ?? "";
				foreach (string item4 in list)
				{
					if (text2.IndexOf(item4, StringComparison.OrdinalIgnoreCase) >= 0)
					{
						return item3.Id;
					}
				}
				if (item3.ObjectClass == ObjectClass.ManaStone)
				{
					int num2 = 0;
					try
					{
						num2 = item3.Values(LongValueKey.CurrentMana);
					}
					catch
					{
					}
					if (num2 > 0 && num == 0)
					{
						num = item3.Id;
					}
				}
			}
		}
		catch
		{
		}
		return num;
	}

	private static bool InPack(int id)
	{
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (item.Id == id)
				{
					return true;
				}
			}
		}
		catch
		{
		}
		return false;
	}

	public string MarkSelected()
	{
		WorldObject worldObject = null;
		try
		{
			worldObject = Globals.Core.WorldFilter[Globals.Core.Actions.CurrentSelection];
		}
		catch
		{
		}
		if (worldObject == null || string.IsNullOrEmpty(worldObject.Name))
		{
			return "Select the item first.";
		}
		string[] array = (_s.ManaStoneNames ?? "").Split(',');
		foreach (string text in array)
		{
			if (text.Trim().Length > 0 && worldObject.Name.IndexOf(text.Trim(), StringComparison.OrdinalIgnoreCase) >= 0)
			{
				return worldObject.Name + " is already on the list.";
			}
		}
		_s.ManaStoneNames = (((_s.ManaStoneNames ?? "").Trim().Length > 0) ? (_s.ManaStoneNames.Trim() + ", ") : "") + worldObject.Name;
		return worldObject.Name + " added.";
	}

	public bool Tick(bool canAct)
	{
		if (!_s.ManaTopUp)
		{
			Status = "";
			return false;
		}
		DateTime now = DateTime.Now;
		if (now < _cooldownUntil)
		{
			return (_cooldownUntil - now).TotalSeconds > Tuning.V("ManaCooldownS") - 2.0;
		}
		if (now >= _nextSweep)
		{
			_nextSweep = now.AddSeconds(Tuning.V("ManaSweepS"));
			_toId.Clear();
			foreach (WorldObject item in Equipped())
			{
				_toId.Enqueue(item.Id);
			}
		}
		if (_toId.Count > 0 && now >= _nextId)
		{
			_nextId = now.AddMilliseconds(Tuning.V("ManaIdMs"));
			try
			{
				Util.RequestId(_toId.Dequeue());
			}
			catch
			{
			}
			return false;
		}
		if (now < _nextLow)
		{
			return false;
		}
		_nextLow = now.AddSeconds(1.0);
		WorldObject worldObject = null;
		double num = 101.0;
		foreach (WorldObject item2 in Equipped())
		{
			if (!Skip(item2))
			{
				double num2 = Pct(item2);
				if (num2 < num)
				{
					num = num2;
					worldObject = item2;
				}
			}
		}
		Lowest = ((worldObject == null) ? "" : (worldObject.Name + " " + num.ToString("0") + "%"));
		if (worldObject == null || num >= (double)_s.ManaTopUpPercent)
		{
			Status = "";
			return false;
		}
		if (!canAct)
		{
			Status = "waiting to top up " + Lowest;
			return false;
		}
		int num3 = FindStone();
		if (num3 == 0)
		{
			Status = "no mana stone";
			_cooldownUntil = now.AddSeconds(30.0);
			return false;
		}
		_lastLowId = worldObject.Id;
		try
		{
			Globals.Core.Actions.ApplyItem(num3, Globals.Core.CharacterFilter.Id);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		if (_log != null)
		{
			_log("MANA  " + Lowest + " - mana stone used on you");
		}
		Status = "topped up (" + Lowest + " was lowest)";
		_cooldownUntil = now.AddSeconds(Tuning.V("ManaCooldownS"));
		_nextSweep = now.AddSeconds(3.0);
		return true;
	}
}
