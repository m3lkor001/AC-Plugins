namespace MelkTank;

public class WeaponItem
{
	public int Id;

	public string Name;

	public WeaponKind Kind;

	public DmgType Element = DmgType.Auto;

	public bool IsShield;

	public bool CompareTo;
}
