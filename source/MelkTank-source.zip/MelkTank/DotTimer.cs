using System;
using System.Collections.Generic;
using System.Numerics;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;

namespace MelkTank;

public class DotTimer
{
	private static readonly Vector4 Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f);

	private static readonly Vector4 Yellow = new Vector4(0.95f, 0.85f, 0.35f, 1f);

	private static readonly Vector4 Green = new Vector4(0.45f, 0.9f, 0.45f, 1f);

	private readonly Settings _s;

	private readonly CombatEngine _engine;

	private readonly Action<string> _log;

	private int _pick = 4;

	private static readonly Slot[] DotSlots = new Slot[5]
	{
		Slot.WeakeningCurse,
		Slot.FesteringCurse,
		Slot.Corruption,
		Slot.DestructiveCurse,
		Slot.Corrosion
	};

	private static readonly string[] DotNames = new string[5] { "Weakening Curse", "Festering Curse", "Corruption", "Destructive Curse", "Corrosion" };

	private int _target;

	private string _mob = "";

	private SpellLevel _spell;

	private bool _combatWas;

	private DateTime _castAt = DateTime.MinValue;

	private DateTime _sentAt = DateTime.MinValue;

	private int _sends;

	private double _wait = 30.0;

	private double _lo = 0.0;

	private double _hi = -1.0;

	private DateTime _nextId = DateTime.MinValue;

	private int _lastHealth = -1;

	private readonly List<DateTime> _ticks = new List<DateTime>();

	private readonly List<int> _tickDmg = new List<int>();

	private readonly List<double> _tickGaps = new List<double>();

	private long _tickTotal;

	private int _tickCount;

	private bool _firstLanding;

	private bool _initial;

	public string Result = "";

	public bool Running => _target != 0;

	public DotTimer(Settings s, CombatEngine engine, Action<string> log)
	{
		_s = s;
		_engine = engine;
		_log = log;
	}

	private void Say(string s)
	{
		Util.WriteToChat("DoT timer: " + s);
		if (_log != null)
		{
			_log("DOT   " + s);
		}
	}

	public void Start()
	{
		int num = 0;
		try
		{
			num = Globals.Core.Actions.CurrentSelection;
		}
		catch
		{
		}
		WorldObject worldObject = ((num != 0) ? Globals.Core.WorldFilter[num] : null);
		if (worldObject == null || worldObject.ObjectClass != ObjectClass.Monster)
		{
			Say("select a monster first.");
			return;
		}
		Slot s = DotSlots[_pick];
		SpellLevel spellLevel = SpellBook.Resolve(Slots.FamilyKeyForDot(s), _s.Level1Dot);
		if (spellLevel == null)
		{
			Say("you don't know any " + DotNames[_pick] + " spell.");
			return;
		}
		if (Globals.Core.Actions.CombatMode != CombatState.Magic)
		{
			Say("hold your wand in magic mode first.");
			return;
		}
		_target = num;
		_mob = worldObject.Name;
		_spell = spellLevel;
		_combatWas = _s.CombatEnabled;
		if (_s.CombatEnabled)
		{
			_s.CombatEnabled = false;
			try
			{
				_engine.ReleaseNav();
			}
			catch
			{
			}
		}
		_castAt = DateTime.MinValue;
		_sentAt = DateTime.MinValue;
		_sends = 0;
		_wait = 45.0;
		_lo = 0.0;
		_hi = -1.0;
		_lastHealth = -1;
		_ticks.Clear();
		_tickDmg.Clear();
		_tickGaps.Clear();
		_tickTotal = 0L;
		_tickCount = 0;
		_firstLanding = true;
		_initial = true;
		Result = "";
		Say("timing " + spellLevel.Name + " on " + _mob + " (combat off during the test; dismiss your pet so it doesn't kill it).");
		Cast();
	}

	public void Stop(string why)
	{
		if (_target != 0)
		{
			Report(why);
			_target = 0;
			if (_combatWas)
			{
				_s.CombatEnabled = true;
			}
		}
	}

	private void Cast()
	{
		try
		{
			Globals.Core.Actions.CastSpell(_spell.Id, _target);
		}
		catch (Exception ex)
		{
			Say("cast error: " + ex.Message);
		}
		_sentAt = DateTime.Now;
		_sends++;
	}

	private double Since()
	{
		return (_castAt == DateTime.MinValue) ? 0.0 : (DateTime.Now - _castAt).TotalSeconds;
	}

	public void Tick()
	{
		if (_target == 0)
		{
			return;
		}
		if (Globals.Core.WorldFilter[_target] == null)
		{
			Stop(_mob + " died or went away");
			return;
		}
		DateTime now = DateTime.Now;
		if (now >= _nextId)
		{
			_nextId = now.AddSeconds(1.0);
			try
			{
				Util.RequestId(_target);
			}
			catch
			{
			}
		}
		if (_sentAt != DateTime.MinValue)
		{
			if ((now - _sentAt).TotalSeconds > 6.0)
			{
				if (_sends >= 6)
				{
					Stop("the cast never landed");
				}
				else
				{
					Cast();
				}
			}
		}
		else
		{
			if (_castAt == DateTime.MinValue)
			{
				return;
			}
			double num = Since();
			if (_initial && _ticks.Count == 0 && num > 60.0)
			{
				_initial = false;
				_wait = Math.Min(_wait, 60.0);
				Say("no damage seen in 60 s (a curse that doesn't hurt, or it can't be read) - finding it by recasting instead.");
			}
			if (_ticks.Count >= 2)
			{
				double num2 = AvgGap();
				double totalSeconds = (now - _ticks[_ticks.Count - 1]).TotalSeconds;
				if (num2 > 0.0 && totalSeconds > Math.Max(10.0, num2 * 2.5) && num < _wait)
				{
					if (_log != null)
					{
						_log("DOT   ticks stopped " + totalSeconds.ToString("0") + "s ago (every " + num2.ToString("0.0") + "s) - checking now at " + num.ToString("0") + "s");
					}
					_wait = num;
				}
			}
			if (num >= _wait)
			{
				Cast();
			}
		}
	}

	private double Tolerance()
	{
		return Math.Max(4.0, _lo * 0.01);
	}

	private double Best()
	{
		double num = _hi;
		double num2 = AvgGap();
		if (num2 > 0.0 && num > _lo + num2)
		{
			num = _lo + num2;
		}
		return (_lo + num) / 2.0;
	}

	private double AvgGap()
	{
		if (_tickGaps.Count == 0)
		{
			return 0.0;
		}
		double num = 0.0;
		foreach (double tickGap in _tickGaps)
		{
			num += tickGap;
		}
		return num / (double)_tickGaps.Count;
	}

	public void OnChat(string text)
	{
		if (_target == 0 || string.IsNullOrEmpty(text) || _spell == null)
		{
			return;
		}
		string text2 = text.Trim();
		if (_sentAt != DateTime.MinValue && (text2.IndexOf("resists your spell", StringComparison.OrdinalIgnoreCase) >= 0 || text2.IndexOf("Your spell fizzled", StringComparison.OrdinalIgnoreCase) >= 0))
		{
			_sentAt = DateTime.Now.AddSeconds(-4.5);
			return;
		}
		string text3 = "You cast " + _spell.Name + " on ";
		if (!text2.StartsWith(text3, StringComparison.OrdinalIgnoreCase) || text2.IndexOf(_mob, text3.Length, StringComparison.OrdinalIgnoreCase) < 0 || _sentAt == DateTime.MinValue)
		{
			return;
		}
		bool flag = text2.IndexOf("refreshing", StringComparison.OrdinalIgnoreCase) >= 0;
		double num = Since();
		_sentAt = DateTime.MinValue;
		_sends = 0;
		if (_firstLanding)
		{
			_firstLanding = false;
			if (flag)
			{
				Say("it already had " + _spell.Name + " on it - that's fine, the clock starts now.");
			}
			Say("watching its health until the damage stops...");
			_wait = 7200.0;
			_castAt = DateTime.Now;
			_ticks.Clear();
			_tickDmg.Clear();
			Result = Bounds();
			return;
		}
		if (flag)
		{
			_lo = Math.Max(_lo, num);
			if (_log != null)
			{
				_log("DOT   still on after " + num.ToString("0") + "s");
			}
		}
		else
		{
			_hi = ((_hi < 0.0) ? num : Math.Min(_hi, num));
			if (_log != null)
			{
				_log("DOT   ran out by " + num.ToString("0") + "s");
			}
			if (_initial)
			{
				Say("first run: still on at " + _lo.ToString("0") + "s, gone by " + _hi.ToString("0") + "s - now narrowing it down by recasting.");
			}
		}
		_initial = false;
		if (_hi < 0.0)
		{
			_wait = Math.Max(30.0, ((_lo > 0.0) ? _lo : 15.0) * 2.0);
		}
		else
		{
			if (_hi - _lo <= Tolerance())
			{
				_castAt = DateTime.Now;
				_ticks.Clear();
				_tickDmg.Clear();
				Stop("done");
				return;
			}
			_wait = (_lo + _hi) / 2.0;
		}
		_castAt = DateTime.Now;
		_ticks.Clear();
		_tickDmg.Clear();
		Result = Bounds();
	}

	public void OnServerMessage(Message msg)
	{
		if (_target == 0 || !WeaponCompare.ReadHealth(msg, _target, out var cur, out var _))
		{
			return;
		}
		if (_lastHealth >= 0 && cur < _lastHealth && _castAt != DateTime.MinValue && _sentAt == DateTime.MinValue)
		{
			DateTime now = DateTime.Now;
			if (_ticks.Count > 0)
			{
				_tickGaps.Add((now - _ticks[_ticks.Count - 1]).TotalSeconds);
			}
			if (_tickGaps.Count > 50)
			{
				_tickGaps.RemoveAt(0);
			}
			_ticks.Add(now);
			_tickDmg.Add(_lastHealth - cur);
			_tickTotal += _lastHealth - cur;
			_tickCount++;
			double num = Since();
			if (num > _lo && (_hi < 0.0 || num < _hi))
			{
				_lo = num;
			}
		}
		_lastHealth = cur;
	}

	public void OnReleased(int id)
	{
		if (_target != 0 && id == _target)
		{
			Stop(_mob + " died or went away");
		}
	}

	private string Bounds()
	{
		if (_hi < 0.0)
		{
			return "still on after " + _lo.ToString("0") + "s";
		}
		return "between " + _lo.ToString("0") + "s and " + _hi.ToString("0") + "s";
	}

	private void Report(string why)
	{
		string text = ((_spell != null) ? _spell.Name : DotNames[_pick]);
		string text2 = ((!(_hi < 0.0)) ? ("about " + Best().ToString("0") + "s (" + (Best() / 60.0).ToString("0.0") + " min; still on at " + _lo.ToString("0") + "s, gone by " + _hi.ToString("0") + "s)") : ("at least " + _lo.ToString("0") + "s (never saw it run out)"));
		string text3 = "";
		if (_spell != null && _spell.BaseDurationSeconds > 0)
		{
			double totalSeconds = SpellBook.Duration(_spell, _s).TotalSeconds;
			text3 = ". MelkTank assumes " + totalSeconds.ToString("0") + "s (spell sheet " + _spell.BaseDurationSeconds.ToString("0") + "s x " + _s.DebuffMultiplier.ToString("0.##") + ")";
			if (_hi > 0.0)
			{
				text3 = text3 + " - a multiplier of " + (Best() / (double)_spell.BaseDurationSeconds).ToString("0.##") + " would match";
			}
		}
		string text4 = ((_tickCount > 0) ? (". Damage ticks: " + _tickCount + ", every " + AvgGap().ToString("0.0") + "s, about " + _tickTotal / _tickCount + " each") : "");
		Result = text + " on " + _mob + ": " + text2 + text3 + text4 + " (" + why + ").";
		Say(Result);
	}

	public void Draw()
	{
		if (!ImGui.CollapsingHeader("Time a DoT###dottimer"))
		{
			return;
		}
		ImGui.Indent(8f);
		Im.TextColored(Grey, "How long a DoT really lasts: it's cast, then recast later - \"refreshing\" means it was still on.\nSelect a monster with plenty of health, hold your wand in magic mode, and dismiss your pet.");
		if (!Running)
		{
			ImGui.SetNextItemWidth(170f);
			ImGui.Combo("##dotpick", ref _pick, DotNames, DotNames.Length);
			ImGui.SameLine();
			if (ImGui.Button("Time it on the selected monster"))
			{
				Start();
			}
		}
		else
		{
			if (ImGui.Button("Stop##dotstop"))
			{
				Stop("stopped by you");
			}
			ImGui.SameLine();
			string text;
			if (_sentAt != DateTime.MinValue)
			{
				text = "casting...";
			}
			else
			{
				text = (_initial ? ("watching the damage (" + Since().ToString("0") + "s)") : ("next cast in " + Math.Max(0.0, _wait - Since()).ToString("0") + "s"));
			}
			Im.TextColored(Yellow, ((_spell != null) ? _spell.Name : "") + " on " + _mob + ": " + Bounds() + " - " + text + ((_tickCount > 0) ? ("  (ticks: " + _tickCount + ", every " + AvgGap().ToString("0.0") + "s)") : ""));
		}
		if (Result.Length > 0)
		{
			ImGui.TextWrapped(Result);
		}
		ImGui.Unindent(8f);
	}
}
