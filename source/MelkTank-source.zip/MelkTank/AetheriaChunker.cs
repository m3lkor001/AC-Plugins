using System;
using System.Collections.Generic;
using Decal.Adapter.Wrappers;
using MelkTank.Loot;

namespace MelkTank;

public class AetheriaChunker
{
	private enum State
	{
		Idle,
		Peace,
		Applied
	}

	private readonly Settings _s;

	private readonly Action<string> _log;

	private State _state = State.Idle;

	private DateTime _until = DateTime.MinValue;

	private DateTime _nextTry = DateTime.MinValue;

	private int _tool;

	private int _target;

	private bool _chunking;

	private readonly Dictionary<int, int> _tries = new Dictionary<int, int>();

	public string Status = "";

	private DateTime _nextScan = DateTime.MinValue;

	private readonly List<int> _chunkList = new List<int>();

	private readonly List<int> _revealList = new List<int>();

	public bool Busy => _state != State.Idle;

	public int ChunkWaiting { get; private set; }

	public AetheriaChunker(Settings s, Action<string> log)
	{
		_s = s;
		_log = log;
	}

	private static int Long(WorldObject o, int key)
	{
		try
		{
			return o.Values((LongValueKey)key);
		}
		catch
		{
			return 0;
		}
	}

	public static int Level(WorldObject o)
	{
		int num = Long(o, 319);
		if (num > 0)
		{
			return num;
		}
		int num2 = Long(o, 218103849);
		return (num2 >= 27700 && num2 <= 27709) ? (num2 - 27699) : 0;
	}

	private static bool Untuned(WorldObject o)
	{
		if (o == null || (o.Name ?? "").IndexOf("Coalesced Aetheria", StringComparison.OrdinalIgnoreCase) < 0)
		{
			return false;
		}
		if ((Long(o, 218103822) & 0x70000000) != 0)
		{
			return false;
		}
		if (Long(o, 10) != 0)
		{
			return false;
		}
		return true;
	}

	private static int Find(string name)
	{
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if ((item.Name ?? "").IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0)
				{
					return item.Id;
				}
			}
		}
		catch
		{
		}
		return 0;
	}

	private static bool Imbued(WorldObject o)
	{
		return Long(o, 179) != 0;
	}

	private static bool IsWeapon(WorldObject o)
	{
		ObjectClass objectClass = o.ObjectClass;
		return objectClass == ObjectClass.MeleeWeapon || objectClass == ObjectClass.MissileWeapon || objectClass == ObjectClass.WandStaffOrb;
	}

	private void Scan()
	{
		_chunkList.Clear();
		_revealList.Clear();
		Looter current = Looter.Current;
		if (current == null)
		{
			ChunkWaiting = 0;
			return;
		}
		int id = Globals.Core.CharacterFilter.Id;
		foreach (WorldObject item in InvCache.All())
		{
			if (Long(item, 10) != 0 || item.Container == 0)
			{
				continue;
			}
			bool flag = Untuned(item);
			bool flag2 = !flag && IsWeapon(item);
			if (!flag && !flag2)
			{
				continue;
			}
			_tries.TryGetValue(item.Id, out var value);
			if (value >= 2)
			{
				continue;
			}
			if (!item.HasIdData)
			{
				try
				{
					Util.RequestId(item.Id);
				}
				catch
				{
				}
				continue;
			}
			UtlRule utlRule = null;
			try
			{
				utlRule = current.Match(item);
			}
			catch
			{
			}
			if (utlRule == null)
			{
				continue;
			}
			if (utlRule.Act == "5")
			{
				bool num;
				if (!flag)
				{
					if (!_s.ChunkWeapons)
					{
						goto IL_0193;
					}
					num = !Imbued(item);
				}
				else
				{
					num = _s.AutoChunkAetheria;
				}
				if (num)
				{
					_chunkList.Add(item.Id);
					continue;
				}
			}
			goto IL_0193;
			IL_0193:
			if ((utlRule.Act == "6") & flag)
			{
				_revealList.Add(item.Id);
			}
		}
		ChunkWaiting = _chunkList.Count;
	}

	public bool Tick(bool calm, bool free)
	{
		DateTime now = DateTime.Now;
		if (_state == State.Idle)
		{
			if (!_s.AutoChunkAetheria && !_s.ChunkWeapons && !_s.RevealAetheria)
			{
				ChunkWaiting = 0;
				return false;
			}
			if (now >= _nextScan)
			{
				_nextScan = now.AddSeconds(5.0);
				try
				{
					Scan();
				}
				catch (Exception ex)
				{
					Util.LogError(ex);
				}
			}
			bool flag = (_s.ChunkForce & free) && ChunkWaiting > _s.ChunkForceCount;
			if (!(calm | flag) || now < _nextTry)
			{
				return false;
			}
			_nextTry = now.AddSeconds(1.0);
			int num = Find("Aetheria Hammer");
			int num2 = Find("Aetheria Mana Stone");
			_target = 0;
			_tool = 0;
			if (num != 0)
			{
				foreach (int chunk in _chunkList)
				{
					if (Globals.Core.WorldFilter[chunk] != null)
					{
						_target = chunk;
						_tool = num;
						_chunking = true;
						break;
					}
				}
			}
			if (((_target == 0) & calm) && _s.RevealAetheria && num2 != 0)
			{
				foreach (int reveal in _revealList)
				{
					if (Globals.Core.WorldFilter[reveal] != null)
					{
						_target = reveal;
						_tool = num2;
						_chunking = false;
						break;
					}
				}
			}
			if (_target == 0)
			{
				Status = ((_chunkList.Count > 0 && num == 0) ? "no Aetheria Hammer in your pack" : "");
				return false;
			}
			_chunkList.Remove(_target);
			_revealList.Remove(_target);
			_tries.TryGetValue(_target, out var value);
			_tries[_target] = value + 1;
			_state = State.Peace;
			_until = now;
			return true;
		}
		if (now < _until)
		{
			return true;
		}
		try
		{
			switch (_state)
			{
			case State.Peace:
			{
				if (Globals.Core.Actions.BusyState != 0)
				{
					_until = now.AddMilliseconds(300.0);
					return true;
				}
				if (Globals.Core.Actions.CombatMode != CombatState.Peace)
				{
					Globals.Core.Actions.SetCombatMode(CombatState.Peace);
					Status = "peace mode";
					_until = now.AddMilliseconds(Tuning.V("ModeWaitMs"));
					return true;
				}
				WorldObject worldObject = Globals.Core.WorldFilter[_target];
				if (worldObject == null)
				{
					_state = State.Idle;
					return false;
				}
				Globals.Core.Actions.ApplyItem(_tool, _target);
				Status = (_chunking ? "chunking " : "revealing ") + (Untuned(worldObject) ? ("Lvl " + Level(worldObject) + " aetheria") : worldObject.Name);
				if (_log != null)
				{
					_log("CHUNK " + Status);
				}
				_state = State.Applied;
				_until = now.AddMilliseconds(2500.0);
				return true;
			}
			case State.Applied:
				_state = State.Idle;
				_nextTry = now.AddSeconds(1.0);
				Status = "";
				return false;
			}
		}
		catch (Exception ex2)
		{
			Util.LogError(ex2);
			_state = State.Idle;
		}
		return false;
	}
}
