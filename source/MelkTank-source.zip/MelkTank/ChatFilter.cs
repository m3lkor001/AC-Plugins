using System;
using System.Collections.Generic;
using System.IO;
using ImGuiNET;

namespace MelkTank;

public static class ChatFilter
{
	private static readonly List<string> _items = new List<string>();

	private static string _file;

	private static DateTime _fileTime = DateTime.MinValue;

	private static DateTime _nextCheck = DateTime.MinValue;

	private static string _input = "";

	public static int Hidden;

	private static string File => _file ?? (_file = Util.FullPath("MelkTank_ChatFilter.txt"));

	private static void Reload(bool force)
	{
		if (!force && DateTime.Now < _nextCheck)
		{
			return;
		}
		_nextCheck = DateTime.Now.AddSeconds(5.0);
		try
		{
			if (!System.IO.File.Exists(File))
			{
				_items.Clear();
				_fileTime = DateTime.MinValue;
				return;
			}
			DateTime lastWriteTimeUtc = System.IO.File.GetLastWriteTimeUtc(File);
			if (!force && lastWriteTimeUtc == _fileTime)
			{
				return;
			}
			_fileTime = lastWriteTimeUtc;
			string[] array = Util.Locked(File, () => System.IO.File.ReadAllLines(File));
			_items.Clear();
			string[] array2 = array;
			foreach (string text in array2)
			{
				if (text.Trim().Length > 0 && !text.StartsWith("#"))
				{
					_items.Add(text.Trim());
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void Save()
	{
		try
		{
			Util.WriteShared(File, "# MelkTank chat filter: chat lines containing any of these (not case sensitive) are hidden.\r\n" + string.Join("\r\n", _items.ToArray()) + "\r\n");
			_fileTime = System.IO.File.GetLastWriteTimeUtc(File);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static List<string> Items()
	{
		Reload(force: false);
		return new List<string>(_items);
	}

	public static void SetItems(List<string> items)
	{
		_items.Clear();
		foreach (string t in items)
		{
			if (t.Trim().Length > 0 && !_items.Exists((string x) => string.Equals(x, t.Trim(), StringComparison.OrdinalIgnoreCase)))
			{
				_items.Add(t.Trim());
			}
		}
		Save();
	}

	public static bool Matches(string text)
	{
		if (string.IsNullOrEmpty(text))
		{
			return false;
		}
		Reload(force: false);
		foreach (string item in _items)
		{
			if (text.IndexOf(item, StringComparison.OrdinalIgnoreCase) >= 0)
			{
				Hidden++;
				return true;
			}
		}
		return false;
	}

	public static bool Hides(string text)
	{
		if (string.IsNullOrEmpty(text))
		{
			return false;
		}
		Reload(force: false);
		foreach (string item in _items)
		{
			if (text.IndexOf(item, StringComparison.OrdinalIgnoreCase) >= 0)
			{
				return true;
			}
		}
		return false;
	}

	public static void Draw()
	{
		Reload(force: false);
		ImGui.SetNextItemWidth(320f);
		bool flag = ImGui.InputText("##chatfilter", ref _input, 200u, ImGuiInputTextFlags.EnterReturnsTrue);
		ImGui.SameLine();
		if ((ImGui.Button("Filter##chatfilteradd") | flag) && _input.Trim().Length > 0)
		{
			Reload(force: true);
			string t = _input.Trim();
			if (!_items.Exists((string x) => string.Equals(x, t, StringComparison.OrdinalIgnoreCase)))
			{
				_items.Add(t);
				Save();
			}
			_input = "";
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Hides every chat line that contains this text (not case sensitive) - e.g. [BANK] Enlightenment Tokens:\nThe list is shared by all your characters.");
		}
		if (_items.Count == 0)
		{
			Im.TextDisabled("Nothing filtered yet. Type part of a line above and click Filter.");
			return;
		}
		int num = -1;
		if (ImGui.BeginTable("chatfilters", 2, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("text", ImGuiTableColumnFlags.WidthFixed, 380f);
			ImGui.TableSetupColumn("x", ImGuiTableColumnFlags.WidthFixed, 22f);
			for (int num2 = 0; num2 < _items.Count; num2++)
			{
				ImGui.TableNextRow();
				ImGui.PushID(num2);
				ImGui.TableSetColumnIndex(0);
				ImGui.TextUnformatted(_items[num2]);
				ImGui.TableSetColumnIndex(1);
				if (ImGui.SmallButton("x"))
				{
					num = num2;
				}
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip("Stop filtering this.");
				}
				ImGui.PopID();
			}
			ImGui.EndTable();
		}
		if (num >= 0)
		{
			Reload(force: true);
			if (num < _items.Count)
			{
				_items.RemoveAt(num);
				Save();
			}
		}
		if (Hidden > 0)
		{
			Im.TextDisabled(Hidden + " line" + ((Hidden == 1) ? "" : "s") + " hidden since you logged in.");
		}
	}
}
