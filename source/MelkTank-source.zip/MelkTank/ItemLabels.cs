using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Decal.Adapter.Wrappers;
using MelkTank.Loot;

namespace MelkTank;

public static class ItemLabels
{
	private static readonly Regex SlayerRx = new Regex("(?:^|\\n)- (.+?) Slayer:\\s*[\\d.]+x");

	private static readonly HashSet<int> _asked = new HashSet<int>();

	private static DateTime _next = DateTime.MinValue;

	public static string Slayer(WorldObject o)
	{
		try
		{
			Match match = SlayerRx.Match((LootMatcher.Str(o, 16) ?? "").Replace("\r", ""));
			return match.Success ? match.Groups[1].Value.Trim() : null;
		}
		catch
		{
			return null;
		}
	}

	public static string Label(WorldObject o)
	{
		string text = ItemReport.FullName(o);
		string text2 = Slayer(o);
		return (text2 == null) ? text : (text + " (" + text2 + " Slayer)");
	}

	public static string Unique(Settings s, string label, int selfId)
	{
		string text = label;
		int num = 2;
		while (Taken(s, text, selfId))
		{
			text = label + " #" + num;
			num++;
		}
		return text;
	}

	private static bool Taken(Settings s, string name, int selfId)
	{
		foreach (WeaponItem item in s.Items)
		{
			if (item.Id != selfId && !ItemInfo.IsSupply(item.Kind) && string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
			{
				return true;
			}
		}
		return false;
	}

	public static bool FixDuplicates(Settings s)
	{
		if (s == null || DateTime.Now < _next)
		{
			return false;
		}
		_next = DateTime.Now.AddSeconds(2.0);
		bool result = false;
		try
		{
			Dictionary<string, List<WeaponItem>> dictionary = new Dictionary<string, List<WeaponItem>>(StringComparer.OrdinalIgnoreCase);
			foreach (WeaponItem item in s.Items)
			{
				if (!ItemInfo.IsSupply(item.Kind) && !string.IsNullOrEmpty(item.Name))
				{
					if (!dictionary.TryGetValue(item.Name, out var value))
					{
						value = (dictionary[item.Name] = new List<WeaponItem>());
					}
					value.Add(item);
				}
			}
			foreach (KeyValuePair<string, List<WeaponItem>> item2 in dictionary)
			{
				if (item2.Value.Count < 2)
				{
					continue;
				}
				bool flag = true;
				foreach (WeaponItem item3 in item2.Value)
				{
					WorldObject worldObject = Globals.Core.WorldFilter[item3.Id];
					if (worldObject == null || worldObject.HasIdData)
					{
						continue;
					}
					flag = false;
					if (_asked.Add(item3.Id))
					{
						try
						{
							Util.RequestId(item3.Id);
						}
						catch
						{
						}
					}
				}
				if (!flag)
				{
					continue;
				}
				string key = item2.Key;
				WeaponItem weaponItem = item2.Value[0];
				foreach (WeaponItem item4 in item2.Value)
				{
					WorldObject worldObject2 = Globals.Core.WorldFilter[item4.Id];
					string label = ((worldObject2 != null) ? Label(worldObject2) : item4.Name);
					item4.Name = Unique(s, label, item4.Id);
				}
				List<MonsterRule> list2 = new List<MonsterRule>(s.Monsters);
				List<MonsterRule>[] extraMonsters = s.ExtraMonsters;
				foreach (List<MonsterRule> collection in extraMonsters)
				{
					list2.AddRange(collection);
				}
				foreach (MonsterRule item5 in list2)
				{
					if (string.Equals(item5.Weapon, key, StringComparison.OrdinalIgnoreCase))
					{
						item5.Weapon = weaponItem.Name;
					}
					if (string.Equals(item5.Offhand, key, StringComparison.OrdinalIgnoreCase))
					{
						item5.Offhand = weaponItem.Name;
					}
				}
				List<string> list3 = new List<string>();
				foreach (WeaponItem item6 in item2.Value)
				{
					list3.Add(item6.Name);
				}
				Util.WriteToChat("Items that shared the name " + key + " are now: " + string.Join(", ", list3.ToArray()) + ".");
				result = true;
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		return result;
	}
}
