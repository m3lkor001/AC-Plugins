namespace MelkTank;

public enum DmgType
{
	Auto,
	Void,
	Fire,
	Cold,
	Acid,
	Lightning,
	Blade,
	Pierce,
	Bludgeon
}
