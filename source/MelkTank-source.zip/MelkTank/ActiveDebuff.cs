using System;

namespace MelkTank;

public class ActiveDebuff
{
	public Slot Slot;

	public string SpellName;

	public DateTime AppliedAt;

	public DateTime ExpiresAt;

	public bool FromSpread;

	public DateTime LineAt = DateTime.MinValue;

	public bool LineOnly;
}
