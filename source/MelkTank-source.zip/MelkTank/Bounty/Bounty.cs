using System;

namespace MelkTank.Bounties;

public class Bounty
{
	public string Zone = "";

	public string Reward = "";

	public int Have;

	public int Need;

	public string Limit = "";

	public DateTime UnlocksAt = DateTime.MinValue;

	public bool Locked => UnlocksAt > DateTime.Now;

	public TimeSpan UnlocksIn => UnlocksAt - DateTime.Now;
}
