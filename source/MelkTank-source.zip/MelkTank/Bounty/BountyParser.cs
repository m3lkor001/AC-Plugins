using System;
using System.Globalization;
using System.Text.RegularExpressions;

namespace MelkTank.Bounties;

public static class BountyParser
{
	public enum Kind
	{
		None,
		Here,
		ListHeader,
		ListItem,
		ListFooter,
		OtherBounty,
		ItemSlots
	}

	// the old ring / bracelet slots (R1 R2 B1 B2) and, since 11-21, the Bounty Ledger's #1 to #4
	private static readonly Regex ItemSlotsRx = new Regex("^(Item bount(y|ies)\\b|Your bounties\\b|Bounty Ledger\\b|(R1|R2|B1|B2|#[1-4])\\s*[:\\-.)]|Bounty #[1-4]\\b)", RegexOptions.IgnoreCase);

	private static readonly Regex HereRx = new Regex("^Bounty(?: \\((?<zone>[^)]*)\\))?:\\s*(?<reward>.+?)\\s+-\\s+(?<have>[\\d,]+) of (?<need>[\\d,]+) kills\\.?$", RegexOptions.IgnoreCase);

	private static readonly Regex LockedRx = new Regex("^Bounty(?: \\((?<zone>[^)]*)\\))?:\\s*(?<reward>.+?)\\s+-\\s+unlocks in (?<time>.+?),\\s*then (?<need>[\\d,]+) kills required\\.?$", RegexOptions.IgnoreCase);

	private static readonly Regex ListAnyRx = new Regex("^(?<zone>[^:]+):\\s*(?<reward>.+?)\\s+every\\s+(?<need>[\\d,]+)\\s+kills(?:\\s*\\((?<limit>[^)]*)\\))?\\s+-\\s+(?<rest>.+)$", RegexOptions.IgnoreCase);

	private static readonly Regex UnlockTimeRx = new Regex("unlocks in (?<time>[^,.]+)", RegexOptions.IgnoreCase);

	private static readonly Regex PartRx = new Regex("(?<n>\\d+)\\s*(?<u>days?|d|hours?|hrs?|h|minutes?|mins?|m|seconds?|secs?|s)\\b", RegexOptions.IgnoreCase);

	private static readonly Regex ListRx = new Regex("^(?<zone>[^:]+):\\s*(?<reward>.+?)\\s+every\\s+[\\d,]+\\s+kills(?:\\s*\\((?<limit>[^)]*)\\))?\\s+-\\s+you:\\s*(?<have>[\\d,]+) of (?<need>[\\d,]+) kills\\.?$", RegexOptions.IgnoreCase);

	public static TimeSpan ParseSpan(string s)
	{
		TimeSpan zero = TimeSpan.Zero;
		foreach (Match item in PartRx.Matches(s ?? ""))
		{
			int num = int.Parse(item.Groups["n"].Value, CultureInfo.InvariantCulture);
			switch (char.ToLowerInvariant(item.Groups["u"].Value[0]))
			{
			case 'd':
				zero += TimeSpan.FromDays(num);
				break;
			case 'h':
				zero += TimeSpan.FromHours(num);
				break;
			case 'm':
				zero += TimeSpan.FromMinutes(num);
				break;
			default:
				zero += TimeSpan.FromSeconds(num);
				break;
			}
		}
		return zero;
	}

	private static int Num(string s)
	{
		int result;
		return int.TryParse(s.Replace(",", ""), NumberStyles.Integer, CultureInfo.InvariantCulture, out result) ? result : 0;
	}

	public static string Clean(string text)
	{
		return (text ?? "").Replace("\r", "").TrimEnd(new char[2] { '\n', ' ' });
	}

	public static Kind Read(string rawLine, bool inList, out Bounty b)
	{
		b = null;
		string text = Clean(rawLine);
		string text2 = text.Trim();
		if (text2.Length == 0)
		{
			return Kind.None;
		}
		if (ItemSlotsRx.IsMatch(text2))
		{
			return Kind.ItemSlots;
		}
		Match match = HereRx.Match(text2);
		if (match.Success)
		{
			b = new Bounty
			{
				Zone = match.Groups["zone"].Value.Trim(),
				Reward = match.Groups["reward"].Value.Trim(),
				Have = Num(match.Groups["have"].Value),
				Need = Num(match.Groups["need"].Value)
			};
			return Kind.Here;
		}
		match = LockedRx.Match(text2);
		if (match.Success)
		{
			b = new Bounty
			{
				Zone = match.Groups["zone"].Value.Trim(),
				Reward = match.Groups["reward"].Value.Trim(),
				Have = 0,
				Need = Num(match.Groups["need"].Value)
			};
			b.UnlocksAt = DateTime.Now + ParseSpan(match.Groups["time"].Value);
			return Kind.Here;
		}
		if (text2 == "Bounties:")
		{
			return Kind.ListHeader;
		}
		if (text2.StartsWith("Bounty: type /bounty", StringComparison.OrdinalIgnoreCase))
		{
			return Kind.ListFooter;
		}
		if (inList || text.StartsWith("  "))
		{
			match = ListRx.Match(text2);
			if (match.Success)
			{
				b = new Bounty
				{
					Zone = match.Groups["zone"].Value.Trim(),
					Reward = match.Groups["reward"].Value.Trim(),
					Have = Num(match.Groups["have"].Value),
					Need = Num(match.Groups["need"].Value),
					Limit = match.Groups["limit"].Value.Trim()
				};
				return Kind.ListItem;
			}
			match = ListAnyRx.Match(text2);
			if (match.Success)
			{
				b = new Bounty
				{
					Zone = match.Groups["zone"].Value.Trim(),
					Reward = match.Groups["reward"].Value.Trim(),
					Need = Num(match.Groups["need"].Value),
					Limit = match.Groups["limit"].Value.Trim()
				};
				Match match2 = UnlockTimeRx.Match(match.Groups["rest"].Value);
				if (match2.Success)
				{
					b.UnlocksAt = DateTime.Now + ParseSpan(match2.Groups["time"].Value);
				}
				return Kind.ListItem;
			}
		}
		if (text2.StartsWith("Bounty", StringComparison.OrdinalIgnoreCase))
		{
			return Kind.OtherBounty;
		}
		return Kind.None;
	}
}
