using System;
using System.Collections.Generic;
using System.IO;
using ACGodot.DecalShim;
using ACGodot.Plugins;
using Decal.Adapter;
using Decal.Adapter.Wrappers;

namespace MelkTank;

public sealed class AcgPlugin : IPlugin, IBotSwitches, IReloadable, IDebugSwitches
{
	/// <summary>MelkTank's logging switches, for ACGodot's Options > Plugins > Debug (each saved as if ticked on its own tab).</summary>
	public IEnumerable<DebugSwitch> DebugSwitches()
	{
		Settings s = PluginCore.CurrentSettings;
		if (s == null) yield break;
		DebugSwitch Sw(string name, string tip, Func<Settings, bool> get, Action<Settings, bool> set) =>
			new DebugSwitch(name, tip, () => PluginCore.CurrentSettings != null && get(PluginCore.CurrentSettings),
				v => { Settings c = PluginCore.CurrentSettings; if (c == null) return; set(c, v); PluginCore.SaveAllNow(); });
		yield return Sw("Debug log", "Logs\\<character>\\MelkTank_debug_<character>.txt", c => c.DebugLog, (c, v) => c.DebugLog = v);
		yield return new DebugSwitch("Live debug", "The engine's step-by-step lines (this session only)",
			() => PluginCore.CurrentEngine?.LiveDebug == true, v => { if (PluginCore.CurrentEngine != null) PluginCore.CurrentEngine.LiveDebug = v; });
		yield return Sw("Perf log", "Where the time goes, every minute", c => c.PerfLog, (c, v) => c.PerfLog = v);
		yield return Sw("Memory log", "Where the memory goes, every minute", c => c.MemLog, (c, v) => c.MemLog = v);
		yield return Sw("Max health log", "Max health changes", c => c.MaxHpLog, (c, v) => c.MaxHpLog = v);
		yield return Sw("Tell log", "Tells to and from you", c => c.TellLog, (c, v) => c.TellLog = v);
		yield return Sw("Monster log", "Monsters seen and fought", c => c.MonsterLogOn, (c, v) => { c.MonsterLogOn = v; MelkTank.Pets.MonsterLog.Toggled(v); });
		yield return Sw("Nav chamber debug", "Nav's chamber checks", c => c.NavDebugChamber, (c, v) => c.NavDebugChamber = v);
	}

	public string Name => "MelkTank";

	public string RouteName => PluginCore.CurrentSettings?.NavRouteSelected ?? "";

	public string NavMode => (PluginCore.CurrentSettings == null) ? "" : PluginCore.CurrentSettings.NavMode.ToString();

	public string Status
	{
		get
		{
			Settings currentSettings = PluginCore.CurrentSettings;
			string result;
			if (currentSettings == null)
			{
				result = "not logged in";
			}
			else if (currentSettings.MasterEnabled)
			{
				// (what the engine is doing - the same line the retail client's status file carries - not just "on")
				string doing = "";
				try
				{
					CombatEngine e = PluginCore.CurrentEngine;
					if (e != null)
					{
						doing = e.Status ?? "";
						if (doing.Length == 0 && e.Buffer != null && e.Buffer.Busy) doing = "Buffing: " + e.Buffer.Status;
						if (doing.Length == 0 && currentSettings.NavEnabled) doing = e.Nav.PhoneStatus() ?? "";
					}
				}
				catch
				{
				}
				result = PluginCore.IsPaused ? ("paused" + (doing.Length > 0 ? " - " + doing : "")) : (doing.Length > 0 ? doing : "on");
			}
			else
			{
				result = "off";
			}
			return result;
		}
	}

	public bool PhoneCommand(string action, IReadOnlyDictionary<string, string> values) => Remote.QueueCommand(action, values);

	public void Start(ACGodot.Plugins.PluginHost host)
	{
		Bridge.Start(host);
		string text = Path.GetDirectoryName(typeof(AcgPlugin).Assembly.Location) ?? ".";
		Directory.CreateDirectory(text);
		PluginCore.HotStart(new Decal.Adapter.Wrappers.PluginHost(), CoreManager.Current, text, DateTime.UtcNow);
	}

	/// <summary>A new copy of the DLL is taking over (ACGodot reloads it in place): stopped as for a hot reload - the session
	/// carried over, the other plugins not told the character logged off.</summary>
	public void StopForReload() => PluginCore.HotStop(reload: true);

	public void Stop()
	{
		try
		{
			CoreManager.Current.CharacterFilter.RaiseLogoff();
		}
		catch
		{
		}
		PluginCore.HotStop(reload: false);
	}

	public bool Get(string feature)
	{
		Settings currentSettings = PluginCore.CurrentSettings;
		if (currentSettings == null)
		{
			return false;
		}
		return feature switch
		{
			"master" => currentSettings.MasterEnabled, 
			"combat" => currentSettings.CombatEnabled, 
			"nav" => currentSettings.NavEnabled, 
			"loot" => currentSettings.LootEnabled, 
			"buff" => currentSettings.MelksBufferEnabled, 
			"summon" => currentSettings.MelksPetEnabled, 
			_ => false, 
		};
	}

	public bool SetFeature(string feature, bool on)
	{
		return !PluginCore.RemoteApply("set", feature, on ? "on" : "off", "").StartsWith("unknown", StringComparison.Ordinal);
	}

	public IEnumerable<string> Routes()
	{
		Settings s = PluginCore.CurrentSettings;
		if (s == null)
		{
			yield break;
		}
		foreach (NavRoute r in s.NavRoutes)
		{
			yield return r.Name;
		}
	}

	public void LoadRoute(string name)
	{
		PluginCore.RemoteApply("navroute", "", "", name);
	}

	// what the phone shows of the session: MelkTank's own (kills, loot, the bank, augmentations, bounties), as its files have it on retail
	public string StatusJson()
	{
		try
		{
			return (PluginCore.CurrentSettings == null) ? "" : Remote.StatusJsonNow();
		}
		catch
		{
			return "";
		}
	}

	public string SessionJson()
	{
		try
		{
			if (PluginCore.CurrentSettings == null)
			{
				return "";
			}
			string name = "";
			try
			{
				name = Decal.Adapter.CoreManager.Current.CharacterFilter.Name ?? "";
			}
			catch
			{
			}
			return Session.SessionJson(name) ?? "";
		}
		catch
		{
			return "";
		}
	}
}
