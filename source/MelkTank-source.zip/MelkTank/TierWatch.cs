using System;
using System.Text.RegularExpressions;

namespace MelkTank;

public class TierWatch
{
	public const int HighTier = 11;

	private readonly Settings _s;

	private readonly Healer _healer;

	private DateTime _askAt = DateTime.MaxValue;

	private DateTime _quietUntil = DateTime.MinValue;

	private DateTime _checkMaxAt = DateTime.MaxValue;

	private DateTime _retryAt = DateTime.MaxValue;

	private DateTime _checkUntil = DateTime.MinValue;

	private int _retries;

	private static readonly Regex V = new Regex("\\bv:\\s*(\\d+)");

	public int Tier { get; private set; }

	public TierWatch(Settings s, Healer healer)
	{
		_s = s;
		_healer = healer;
		Tier = -1;
		_askAt = DateTime.Now.AddSeconds(3.0);
	}

	public void OnPortalExit()
	{
		_askAt = DateTime.Now.AddSeconds(1.5);
		_retries = 0;
	}

	public void Tick()
	{
		DateTime now = DateTime.Now;
		if (now >= _askAt)
		{
			_askAt = DateTime.MaxValue;
			_quietUntil = now.AddSeconds(6.0);
			if (Tier < 0 && _retries < 5)
			{
				_retries++;
				_retryAt = now.AddSeconds(10.0);
			}
			try
			{
				Globals.Core.Actions.InvokeChatParser("/location");
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
		}
		if (now >= _retryAt && Tier < 0)
		{
			_retryAt = DateTime.MaxValue;
			_askAt = now;
		}
		if (now >= _checkMaxAt && now < _checkUntil)
		{
			_checkMaxAt = now.AddSeconds(1.0);
			double num = _healer.HealthPercent(out var cur, out var _);
			if (num >= 0.0 && num < 99.0)
			{
				_checkMaxAt = DateTime.MaxValue;
				_healer.SetMaxToCurrent();
				Util.WriteToChat("Entered tier " + Tier + " - health read " + num.ToString("0") + "%, so max health is now " + cur + " (Max = now).");
			}
		}
	}

	public bool OnChat(string text)
	{
		if (string.IsNullOrEmpty(text))
		{
			return false;
		}
		string text2 = text.Trim();
		if (!text2.StartsWith("Your location is:", StringComparison.OrdinalIgnoreCase))
		{
			return false;
		}
		Match match = V.Match(text2);
		if (match.Success || DateTime.Now < _quietUntil)
		{
			try
			{
				AppDomain.CurrentDomain.SetData("MelkTank.Variation", (match.Success ? match.Groups[1].Value : "0") + "|" + DateTime.UtcNow.Ticks);
			}
			catch
			{
			}
		}
		if (match.Success)
		{
			_retryAt = DateTime.MaxValue;
			int tier = Tier;
			Tier = int.Parse(match.Groups[1].Value);
			_healer.SetTier(Tier);
		}
		return DateTime.Now < _quietUntil;
	}
}
