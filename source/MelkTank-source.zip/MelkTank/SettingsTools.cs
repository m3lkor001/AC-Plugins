using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Xml;
using Decal.Adapter;

namespace MelkTank;

public static class SettingsTools
{
	private class NavSetEntry
	{
		public string Name;

		public string Original;

		public string SetTo;
	}

	private static Settings _s;

	private static Action _saveAll;

	private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

	private static List<NavSetEntry> _navSet;

	private static string _navSetChar;

	private static bool _navWasOn;

	private static string Dir => Util.FullPath("Snapshots");

	public static void Init(Settings s, Action saveAll)
	{
		_s = s;
		_saveAll = saveAll;
	}

	public static List<string> SetMany(List<KeyValuePair<string, string>> changes, string from)
	{
		List<string> list = new List<string>();
		List<string> list2 = new List<string>();
		if (_s == null)
		{
			list2.Add("not logged in");
			return list2;
		}
		XmlDocument doc = new XmlDocument();
		XmlElement c = _s.BuildCharacterNow(doc);
		List<XmlElement> list3 = new List<XmlElement>();
		bool flag = false;
		foreach (KeyValuePair<string, string> change in changes)
		{
			string text = (change.Key ?? "").Trim();
			string text2 = (change.Value ?? "").Trim();
			if (string.Equals(text, "TrackProfile", StringComparison.OrdinalIgnoreCase) || string.Equals(text, "TrackSaveAs", StringComparison.OrdinalIgnoreCase) || string.Equals(text, "TrackDeleteProfile", StringComparison.OrdinalIgnoreCase))
			{
				string trackProfile = _s.TrackProfile;
				string text3;
				if (text.Equals("TrackSaveAs", StringComparison.OrdinalIgnoreCase))
				{
					text3 = _s.SaveTrackProfileAs(text2);
				}
				else
				{
					text3 = ((!text.Equals("TrackDeleteProfile", StringComparison.OrdinalIgnoreCase)) ? _s.SwitchTrackProfile(text2) : _s.DeleteTrackProfile());
				}
				if (text3 != null)
				{
					list2.Add(text3);
					continue;
				}
				ItemTracker.ListChanged();
				flag = true;
				list.Add("item profile " + ((trackProfile.Length == 0) ? "(own list)" : trackProfile) + " -> " + ((_s.TrackProfile.Length == 0) ? "(own list)" : _s.TrackProfile));
				continue;
			}
			if (string.Equals(text, "ChatFilter", StringComparison.OrdinalIgnoreCase))
			{
				List<string> list4 = new List<string>();
				string[] array = text2.Split('\u0001', '\n');
				foreach (string text4 in array)
				{
					if (text4.Trim().Length > 0)
					{
						list4.Add(text4.Trim());
					}
				}
				ChatFilter.SetItems(list4);
				flag = true;
				list.Add("ChatFilter -> " + list4.Count + " entr" + ((list4.Count == 1) ? "y" : "ies"));
				continue;
			}
			if (string.Equals(text, "TrackItems", StringComparison.OrdinalIgnoreCase))
			{
				List<string> list5 = new List<string>();
				string[] array2 = text2.Split('\u0001', '\n');
				foreach (string text5 in array2)
				{
					if (text5.Trim().Length > 0)
					{
						list5.Add(text5.Trim());
					}
				}
				string text6 = string.Join("\n", list5.ToArray());
				if (text6 == (_s.TrackItems ?? ""))
				{
					list2.Add("TrackItems is already that");
					continue;
				}
				_s.TrackItems = text6;
				flag = true;
				ItemTracker.ListChanged();
				list.Add("TrackItems -> " + list5.Count + " item" + ((list5.Count == 1) ? "" : "s"));
				continue;
			}
			XmlElement xmlElement = Find(c, text);
			if (xmlElement != null)
			{
				string innerText = xmlElement.InnerText;
				string text7 = Convert(innerText, text2, out var nv);
				if (text7 != null)
				{
					list2.Add(xmlElement.Name + ": " + text7);
					continue;
				}
				if (nv == innerText)
				{
					list2.Add(xmlElement.Name + " is already " + innerText);
					continue;
				}
				xmlElement.InnerText = nv;
				list3.Add(xmlElement);
				list.Add(xmlElement.Name + " " + Show(innerText) + " -> " + Show(nv));
				continue;
			}
			Tuning.Entry entry = FindTuning(text);
			if (entry != null)
			{
				if (!double.TryParse(text2.Replace(",", ""), NumberStyles.Float, Inv, out var result))
				{
					list2.Add(entry.Key + ": not a number (" + text2 + ")");
					continue;
				}
				double num = Math.Max(entry.Min, Math.Min(entry.Max, entry.Whole ? Math.Round(result) : result));
				double value = entry.Value;
				if (num == value)
				{
					list2.Add(entry.Key + " is already " + Num(value));
					continue;
				}
				entry.Value = num;
				flag = true;
				list.Add(entry.Key + " " + Num(value) + " -> " + Num(num) + ((num != result) ? (" (kept within " + Num(entry.Min) + "-" + Num(entry.Max) + ")") : ""));
			}
			else
			{
				list2.Add("no setting called " + text + " (/mtank get " + text + " finds close names)");
			}
		}
		if (list3.Count > 0)
		{
			_s.ApplyLive(list3);
		}
		if ((list3.Count > 0) | flag)
		{
			if (_saveAll != null)
			{
				_saveAll();
			}
			Notes.Add("set " + string.Join(", ", list.ToArray()), from, quiet: true);
		}
		list.AddRange(list2);
		return list;
	}

	public static string Set(string name, string value, string from)
	{
		List<string> list = SetMany(new List<KeyValuePair<string, string>>
		{
			new KeyValuePair<string, string>(name, value)
		}, from);
		return (list.Count > 0) ? list[0] : "";
	}

	private static string NavSetFile(string ch)
	{
		return Util.FullPath("MelkTank_NavSet_" + ch + ".txt");
	}

	private static List<NavSetEntry> NavSets()
	{
		string text = "";
		try
		{
			text = CoreManager.Current.CharacterFilter.Name ?? "";
		}
		catch
		{
		}
		if (_navSet != null && text == _navSetChar)
		{
			return _navSet;
		}
		_navSetChar = text;
		_navSet = new List<NavSetEntry>();
		try
		{
			string path = NavSetFile(text);
			if (File.Exists(path))
			{
				string[] array = File.ReadAllLines(path);
				foreach (string text2 in array)
				{
					string[] array2 = text2.Split('\t');
					if (array2.Length == 3)
					{
						_navSet.Add(new NavSetEntry
						{
							Name = array2[0],
							Original = array2[1],
							SetTo = array2[2]
						});
					}
				}
			}
		}
		catch
		{
		}
		return _navSet;
	}

	private static void SaveNavSets()
	{
		try
		{
			string path = NavSetFile(_navSetChar ?? "");
			if (_navSet == null || _navSet.Count == 0)
			{
				if (File.Exists(path))
				{
					File.Delete(path);
				}
				return;
			}
			List<string> list = new List<string>();
			foreach (NavSetEntry item in _navSet)
			{
				list.Add(item.Name + "\t" + item.Original + "\t" + item.SetTo);
			}
			File.WriteAllLines(path, list.ToArray());
		}
		catch
		{
		}
	}

	private static string RawValue(string name, out string realName)
	{
		realName = name;
		if (_s == null)
		{
			return null;
		}
		XmlElement xmlElement = Find(_s.BuildCharacterNow(new XmlDocument()), name);
		if (xmlElement != null)
		{
			realName = xmlElement.Name;
			return xmlElement.InnerText;
		}
		Tuning.Entry entry = FindTuning(name);
		if (entry != null)
		{
			realName = entry.Key;
			return entry.Value.ToString(Inv);
		}
		return null;
	}

	public static string NavSet(string name, string value)
	{
		string text = RawValue(name, out var real);
		if (text == null)
		{
			return "no setting called " + name + " (/mtank get " + name + " finds close names)";
		}
		string text2 = Set(real, value, "navset");
		string text3 = RawValue(real, out real);
		if (text3 == null || text3 == text)
		{
			return text2;
		}
		List<NavSetEntry> list = NavSets();
		NavSetEntry navSetEntry = list.Find((NavSetEntry x) => string.Equals(x.Name, real, StringComparison.OrdinalIgnoreCase));
		if (navSetEntry == null)
		{
			list.Add(new NavSetEntry
			{
				Name = real,
				Original = text,
				SetTo = text3
			});
		}
		else
		{
			navSetEntry.SetTo = text3;
		}
		if (navSetEntry != null && navSetEntry.Original == text3)
		{
			list.Remove(navSetEntry);
		}
		SaveNavSets();
		return text2 + " (until Nav is switched off)";
	}

	public static void NavTick()
	{
		if (_s == null)
		{
			return;
		}
		bool navEnabled = _s.NavEnabled;
		bool flag = _navWasOn && !navEnabled;
		_navWasOn = navEnabled;
		if (!flag)
		{
			return;
		}
		List<NavSetEntry> list = NavSets();
		if (list.Count == 0)
		{
			return;
		}
		List<KeyValuePair<string, string>> list2 = new List<KeyValuePair<string, string>>();
		List<string> list3 = new List<string>();
		foreach (NavSetEntry item in list)
		{
			string text = RawValue(item.Name, out var _);
			if (text != null && text == item.SetTo)
			{
				list2.Add(new KeyValuePair<string, string>(item.Name, item.Original));
			}
			else
			{
				list3.Add(item.Name);
			}
		}
		list.Clear();
		SaveNavSets();
		if (list2.Count > 0)
		{
			Util.WriteToChat("Nav off - put back: " + string.Join(", ", SetMany(list2, "navset").ToArray()));
		}
		if (list3.Count > 0)
		{
			Util.WriteToChat("Nav off - left as you changed them: " + string.Join(", ", list3.ToArray()));
		}
	}

	public static List<string> Get(string part)
	{
		List<string> list = new List<string>();
		if (_s == null)
		{
			return list;
		}
		part = (part ?? "").Trim();
		XmlElement xmlElement = _s.BuildCharacterNow(new XmlDocument());
		foreach (XmlNode childNode in xmlElement.ChildNodes)
		{
			if (childNode is XmlElement xmlElement2 && Simple(xmlElement2) && (part.Length == 0 || xmlElement2.Name.IndexOf(part, StringComparison.OrdinalIgnoreCase) >= 0))
			{
				list.Add(xmlElement2.Name + " = " + Show(xmlElement2.InnerText));
			}
		}
		foreach (Tuning.Entry item in Tuning.All)
		{
			if (part.Length == 0 || item.Key.IndexOf(part, StringComparison.OrdinalIgnoreCase) >= 0 || item.Label.IndexOf(part, StringComparison.OrdinalIgnoreCase) >= 0)
			{
				list.Add(item.Key + " = " + Num(item.Value) + " " + item.Unit + "  (tuning: " + item.Label + ((item.Value != item.Default) ? (", default " + Num(item.Default)) : "") + ")");
			}
		}
		return list;
	}

	private static bool Simple(XmlElement e)
	{
		foreach (XmlNode childNode in e.ChildNodes)
		{
			if (childNode is XmlElement)
			{
				return false;
			}
		}
		return true;
	}

	private static XmlElement Find(XmlElement c, string name)
	{
		foreach (XmlNode childNode in c.ChildNodes)
		{
			if (childNode is XmlElement xmlElement && Simple(xmlElement) && string.Equals(xmlElement.Name, name, StringComparison.OrdinalIgnoreCase))
			{
				return xmlElement;
			}
		}
		return null;
	}

	private static Tuning.Entry FindTuning(string name)
	{
		foreach (Tuning.Entry item in Tuning.All)
		{
			if (string.Equals(item.Key, name, StringComparison.OrdinalIgnoreCase))
			{
				return item;
			}
		}
		return null;
	}

	private static string Convert(string old, string val, out string nv)
	{
		nv = val;
		if (old == "True" || old == "False")
		{
			string text = val.ToLowerInvariant();
			switch (text)
			{
			default:
				if (!(text == "yes"))
				{
					switch (text)
					{
					default:
						if (!(text == "no"))
						{
							return "on/off setting - use on or off";
						}
						goto case "false";
					case "false":
					case "off":
					case "0":
						nv = "False";
						return null;
					}
				}
				goto case "true";
			case "true":
			case "on":
			case "1":
				nv = "True";
				return null;
			}
		}
		if (old.Length > 0 && double.TryParse(old, NumberStyles.Float, Inv, out var result))
		{
			string s = val.Replace(",", "");
			if (old.IndexOf('.') < 0 && !old.Contains("E"))
			{
				if (!long.TryParse(s, NumberStyles.Integer, Inv, out var result2))
				{
					return "a whole number (" + val + ")";
				}
				nv = result2.ToString(Inv);
				return null;
			}
			if (!double.TryParse(s, NumberStyles.Float, Inv, out result))
			{
				return "a number (" + val + ")";
			}
			nv = result.ToString(Inv);
			return null;
		}
		return null;
	}

	private static string Show(string v)
	{
		string result;
		if (v.Length != 0)
		{
			result = ((v.Length > 60) ? (v.Substring(0, 57) + "...") : v);
		}
		else
		{
			result = "(blank)";
		}
		return result;
	}

	private static string Num(double v)
	{
		return v.ToString("0.###", Inv);
	}

	private static string CharPart()
	{
		string text = "";
		try
		{
			text = Globals.Core.CharacterFilter.Name ?? "";
		}
		catch
		{
		}
		StringBuilder stringBuilder = new StringBuilder();
		string text2 = text;
		foreach (char c in text2)
		{
			stringBuilder.Append(char.IsLetterOrDigit(c) ? c : '_');
		}
		return stringBuilder.ToString();
	}

	private static string Clean(string name)
	{
		StringBuilder stringBuilder = new StringBuilder();
		string text = (name ?? "").Trim();
		foreach (char c in text)
		{
			stringBuilder.Append((char.IsLetterOrDigit(c) || c == '-' || c == '.') ? c : '_');
		}
		string text2 = stringBuilder.ToString().Trim(new char[2] { '_', '.' });
		return (text2.Length > 40) ? text2.Substring(0, 40) : text2;
	}

	private static string SnapPath(string name)
	{
		return Path.Combine(Dir, CharPart() + "_" + Clean(name) + ".xml");
	}

	public static string SnapSave(string name, string from)
	{
		if (_s == null)
		{
			return "not logged in";
		}
		name = Clean(name);
		if (name.Length == 0)
		{
			name = DateTime.Now.ToString("yyyy-MM-dd_HHmm");
		}
		if (_saveAll != null)
		{
			_saveAll();
		}
		XmlDocument doc = new XmlDocument();
		XmlElement xmlElement = _s.BuildCharacterNow(doc);
		doc.AppendChild(xmlElement);
		xmlElement.SetAttribute("snapshot", name);
		xmlElement.SetAttribute("saved", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", Inv));
		xmlElement.SetAttribute("build", BuildInfo.Label);
		Directory.CreateDirectory(Dir);
		string path = SnapPath(name);
		Util.Locked(path, () =>
		{
			doc.Save(path);
		});
		if (name != "before-restore")
		{
			Notes.Add("settings snapshot saved: " + name, from, quiet: true);
		}
		return "Snapshot " + name + " saved.";
	}

	public static string SnapRestore(string name, string from)
	{
		if (_s == null)
		{
			return "not logged in";
		}
		string path = SnapPath(name);
		if (!File.Exists(path))
		{
			return "There's no snapshot called " + Clean(name) + " for this character (/mtank snap list).";
		}
		XmlDocument doc = new XmlDocument();
		try
		{
			Util.Locked(path, () =>
			{
				doc.Load(path);
			});
		}
		catch (Exception ex)
		{
			return "Couldn't read snapshot " + name + ": " + ex.Message;
		}
		if (!string.Equals(Clean(name), "before-restore", StringComparison.OrdinalIgnoreCase))
		{
			SnapSave("before-restore", from);
		}
		List<XmlElement> list = new List<XmlElement>();
		foreach (XmlNode childNode in doc.DocumentElement.ChildNodes)
		{
			if (childNode is XmlElement)
			{
				list.Add((XmlElement)childNode);
			}
		}
		_s.ApplyLive(list);
		if (_saveAll != null)
		{
			_saveAll();
		}
		string attribute = doc.DocumentElement.GetAttribute("saved");
		Notes.Add("settings snapshot restored: " + Clean(name) + ((attribute.Length > 0) ? (" (saved " + attribute + ")") : ""), from, quiet: true);
		return "Restored snapshot " + Clean(name) + ((attribute.Length > 0) ? (" (saved " + attribute + ")") : "") + ". The settings before it are in snapshot before-restore.";
	}

	public static string SnapDelete(string name)
	{
		string path = SnapPath(name);
		if (!File.Exists(path))
		{
			return "There's no snapshot called " + Clean(name) + ".";
		}
		File.Delete(path);
		return "Snapshot " + Clean(name) + " deleted.";
	}

	public static List<string> SnapList()
	{
		List<string> list = new List<string>();
		if (!Directory.Exists(Dir))
		{
			return list;
		}
		string text = CharPart() + "_";
		string[] files = Directory.GetFiles(Dir, text + "*.xml");
		foreach (string path in files)
		{
			string text2 = Path.GetFileNameWithoutExtension(path).Substring(text.Length);
			list.Add(text2 + "  (" + File.GetLastWriteTime(path).ToString("MMM d HH:mm", Inv) + ")");
		}
		list.Sort(StringComparer.OrdinalIgnoreCase);
		return list;
	}

	public static void WriteTuningInfo()
	{
		try
		{
			StringBuilder b = new StringBuilder("[\n");
			for (int i = 0; i < Tuning.All.Count; i++)
			{
				Tuning.Entry entry = Tuning.All[i];
				b.Append((i == 0) ? "  {" : ",\n  {");
				b.Append("\"key\": ").Append(Q(entry.Key)).Append(", \"category\": ")
					.Append(Q(entry.Category))
					.Append(", \"label\": ")
					.Append(Q(entry.Label));
				b.Append(", \"unit\": ").Append(Q(entry.Unit)).Append(", \"tip\": ")
					.Append(Q(entry.Tip));
				b.Append(", \"default\": ").Append(Num(entry.Default)).Append(", \"min\": ")
					.Append(Num(entry.Min))
					.Append(", \"max\": ")
					.Append(Num(entry.Max));
				b.Append(", \"whole\": ").Append(entry.Whole ? "true" : "false").Append("}");
			}
			b.Append("\n]\n");
			string path = Util.FullPath("MelkTank_TuningInfo.json");
			Util.Locked(path, () =>
			{
				File.WriteAllText(path, b.ToString());
			});
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void WriteSettingsInfo()
	{
		try
		{
			StringBuilder b = new StringBuilder("[\n");
			for (int i = 0; i < SettingsMap.All.Length; i++)
			{
				string[] array = SettingsMap.All[i];
				b.Append((i == 0) ? "  {" : ",\n  {").Append("\"key\": ").Append(Q(array[0]))
					.Append(", \"section\": ")
					.Append(Q(array[1]))
					.Append(", \"label\": ")
					.Append(Q(array[2]))
					.Append("}");
			}
			b.Append("\n]\n");
			string path = Util.FullPath("MelkTank_SettingsInfo.json");
			Util.Locked(path, () =>
			{
				File.WriteAllText(path, b.ToString());
			});
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static string Q(string s)
	{
		StringBuilder stringBuilder = new StringBuilder("\"");
		string text = s ?? "";
		foreach (char c in text)
		{
			if (c == '"' || c == '\\')
			{
				stringBuilder.Append('\\').Append(c);
			}
			else if (c < ' ')
			{
				StringBuilder stringBuilder2 = stringBuilder.Append("\\u");
				int num = c;
				stringBuilder2.Append(num.ToString("x4"));
			}
			else
			{
				stringBuilder.Append(c);
			}
		}
		return stringBuilder.Append('"').ToString();
	}
}
