using System;
using System.Collections.Generic;
using Decal.Adapter.Wrappers;
using MelkTank.Loot;

namespace MelkTank;

public static class MaxHpWatch
{
	private static DateTime _next = DateTime.MinValue;

	private static int _lastEff = -1;

	private static int _lastUsed = -1;

	private static int _lastServer = -1;

	private static HashSet<int> _lastEnch;

	public static void Tick(Settings s, CombatEngine e)
	{
		if (s == null || e == null || !s.MaxHpLog || DateTime.Now < _next)
		{
			return;
		}
		_next = DateTime.Now.AddSeconds(1.0);
		CharacterFilter characterFilter = Globals.Core.CharacterFilter;
		int health = characterFilter.Health;
		int num = -1;
		try
		{
			num = characterFilter.EffectiveVital[CharFilterVitalType.Health];
		}
		catch
		{
			num = -2;
		}
		e.Healer.HealthPercent(out var _, out var max);
		HashSet<int> hashSet = new HashSet<int>();
		try
		{
			foreach (EnchantmentWrapper enchantment in characterFilter.Enchantments)
			{
				hashSet.Add(enchantment.SpellId);
			}
		}
		catch
		{
		}
		int serverMax = Healer.ServerMax;
		if (num == _lastEff && max == _lastUsed && serverMax == _lastServer)
		{
			_lastEnch = hashSet;
			return;
		}
		_lastServer = serverMax;
		List<string> list = new List<string>();
		List<string> list2 = new List<string>();
		if (_lastEnch != null)
		{
			foreach (int item in hashSet)
			{
				if (!_lastEnch.Contains(item))
				{
					list.Add(Name(item));
				}
			}
			foreach (int item2 in _lastEnch)
			{
				if (!hashSet.Contains(item2))
				{
					list2.Add(Name(item2));
				}
			}
		}
		string obj3 = "MAXHP game max " + Show(_lastEff) + " -> " + Show(num) + ", MelkTank's max " + ((_lastUsed < 0) ? "?" : _lastUsed.ToString()) + " -> " + max + ", server's max " + ((Healer.ServerMax > 0) ? Healer.ServerMax.ToString() : "?") + ", health " + health + ", tier " + e.Tier.Tier + (e.Healer.HighTierBucket ? " (remembered max)" : "") + ((list.Count > 0) ? (", spells on: " + string.Join(", ", list.ToArray())) : "") + ((list2.Count > 0) ? (", spells off: " + string.Join(", ", list2.ToArray())) : "") + ((_lastEnch != null && list.Count == 0 && list2.Count == 0) ? ", no spell change" : "");
		_lastEff = num;
		_lastUsed = max;
		_lastEnch = hashSet;
		try
		{
			if (e.Nav.Log != null)
			{
				e.Nav.Log(obj3);
			}
		}
		catch
		{
		}
	}

	private static string Show(int v)
	{
		return v switch
		{
			-2 => "error", 
			-1 => "?", 
			_ => v.ToString(), 
		};
	}

	private static string Name(int id)
	{
		string text = null;
		try
		{
			text = SpellNames.Name(id);
		}
		catch
		{
		}
		return string.IsNullOrEmpty(text) ? ("spell " + id) : text;
	}
}
