using System;
using Decal.Adapter.Wrappers;

namespace MelkTank;

public static class ItemInfo
{
	public const int AmmoSlot = 8388608;

	public static bool IsSupply(WeaponKind k)
	{
		return k == WeaponKind.HealKit || k == WeaponKind.ManaKit || k == WeaponKind.StaminaKit || k == WeaponKind.Health || k == WeaponKind.ManaStone || k == WeaponKind.Lockpick || k == WeaponKind.Dispel;
	}

	public static int CountInPack(string name)
	{
		int num = 0;
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
				{
					int num2 = 0;
					try
					{
						num2 = item.Values(LongValueKey.StackCount);
					}
					catch
					{
					}
					num += ((num2 <= 0) ? 1 : num2);
				}
			}
		}
		catch
		{
		}
		return num;
	}

	public static int MissileType(int id)
	{
		try
		{
			return Globals.Core.WorldFilter[id]?.Values(LongValueKey.MissileType) ?? 0;
		}
		catch
		{
			return 0;
		}
	}

	public static bool IsAmmo(WorldObject o)
	{
		try
		{
			return o != null && o.Values(LongValueKey.EquipableSlots) == 8388608;
		}
		catch
		{
			return false;
		}
	}

	public static string MissileTypeName(int mt, bool ammo)
	{
		return mt switch
		{
			1 => ammo ? "Arrow" : "Bow", 
			2 => ammo ? "Quarrel" : "Crossbow", 
			4 => ammo ? "Dart" : "Atlatl", 
			_ => "?", 
		};
	}
}
