using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;

namespace MelkTank;

public static class Notes
{
	private static string _laterText;

	private static string _laterFrom;

	private static DateTime _laterAt = DateTime.MaxValue;

	public static void Add(string text, string from)
	{
		Add(text, from, quiet: false);
	}

	public static void Add(string text, string from, bool quiet)
	{
		text = (text ?? "").Trim();
		if (text.Length == 0)
		{
			text = "(mark)";
		}
		DateTime now = DateTime.Now;
		string text2 = Context();
		string text3 = "===== NOTE " + now.ToString("HH:mm:ss") + (string.IsNullOrEmpty(from) ? "" : (" (" + from + ")")) + ": " + text + "   [" + text2 + "]";
		try
		{
			PluginCore.CurrentEngine?.NoteLine(text3);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		try
		{
			PackStats.NoteLine(now.ToString("yyyy-MM-dd ") + text3);
		}
		catch (Exception ex2)
		{
			Util.LogError(ex2);
		}
		try
		{
			string text4 = "";
			try
			{
				text4 = Globals.Core.CharacterFilter.Name ?? "";
			}
			catch
			{
			}
			Util.AppendShared(Util.FullPath("MelkTank_Notes.txt"), now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + text4 + "  " + text + "   [" + text2 + "]" + Environment.NewLine);
		}
		catch (Exception ex3)
		{
			Util.LogError(ex3);
		}
		if (!quiet)
		{
			Util.WriteToChat("Note added: " + text);
		}
	}

	public static string MemText()
	{
		long num = 0L;
		long num2 = 0L;
		try
		{
			Process currentProcess = Process.GetCurrentProcess();
			currentProcess.Refresh();
			num = currentProcess.PrivateMemorySize64;
			num2 = currentProcess.WorkingSet64;
		}
		catch
		{
		}
		if (num <= 0)
		{
			num = HotCleanup.PrivateBytes();
		}
		string text = (HotCleanup.AddressSpace(out var used, out var total) ? (", address space " + (used >> 20) + " of " + (total >> 20) + " MB") : "");
		long totalMemory = GC.GetTotalMemory(forceFullCollection: false);
		int num3 = 0;
		Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
		foreach (Assembly assembly in assemblies)
		{
			if (assembly.FullName.StartsWith("MelkTankCore,", StringComparison.Ordinal))
			{
				num3++;
			}
		}
		return "memory " + ((num > 0) ? ((num >> 20) + " MB private") : "private ?") + ", " + (num2 >> 20) + " MB in use" + text + ", .NET heap " + (totalMemory >> 20) + " MB, " + num3 + " build" + ((num3 == 1) ? "" : "s") + " loaded";
	}

	public static void AddLater(string text, string from, double seconds)
	{
		_laterText = text;
		_laterFrom = from;
		_laterAt = DateTime.Now.AddSeconds(seconds);
	}

	public static void Tick()
	{
		if (!(DateTime.Now < _laterAt))
		{
			_laterAt = DateTime.MaxValue;
			Add(_laterText, _laterFrom, quiet: true);
		}
	}

	private static string Context()
	{
		CultureInfo invariantCulture = CultureInfo.InvariantCulture;
		List<string> list = new List<string>();
		try
		{
			list.Add("build " + BuildInfo.Label);
		}
		catch
		{
		}
		try
		{
			CombatEngine currentEngine = PluginCore.CurrentEngine;
			if (currentEngine != null)
			{
				string routeNameNow = currentEngine.Nav.RouteNameNow;
				int routeStepNow = currentEngine.Nav.RouteStepNow;
				if (routeNameNow.Length > 0)
				{
					list.Add("route " + routeNameNow + ((routeStepNow > 0) ? (" step " + routeStepNow) : ""));
				}
			}
		}
		catch
		{
		}
		try
		{
			double killsPerHourRecent = Session.KillsPerHourRecent;
			if (killsPerHourRecent >= 0.0)
			{
				list.Add(killsPerHourRecent.ToString("0", invariantCulture) + " kills/h");
			}
		}
		catch
		{
		}
		try
		{
			list.Add(Session.Packs + " packs");
		}
		catch
		{
		}
		try
		{
			list.Add(MemText());
		}
		catch
		{
		}
		return string.Join(", ", list.ToArray());
	}
}
