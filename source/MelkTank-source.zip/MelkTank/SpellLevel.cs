namespace MelkTank;

public class SpellLevel
{
	public readonly int Id;

	public readonly string Name;

	public readonly int BaseDurationSeconds;

	public SpellLevel(int id, string name, int dur)
	{
		Id = id;
		Name = name;
		BaseDurationSeconds = dur;
	}
}
