namespace MelkTank.Loot;

public class T11Def
{
	public string Id;

	public string Label;

	public string Unit;

	public string Def;

	public string Opt;

	public string Where;

	public bool Dec;

	public bool NoValue;
}
