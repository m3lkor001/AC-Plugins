using System.Collections.Generic;

namespace MelkTank.Loot;

public class UtlReq
{
	public string Type;

	public List<string> Vals;

	public string LenStr;

	public string Raw;

	public bool Dirty;

	public static bool Flag(string type)
	{
		return type == "9999" || type == "3005";
	}

	public static UtlReq New(string type, params string[] vals)
	{
		return new UtlReq
		{
			Type = type,
			Vals = new List<string>(vals),
			Dirty = true
		};
	}
}
