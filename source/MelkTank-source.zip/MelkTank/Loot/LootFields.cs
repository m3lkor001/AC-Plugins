using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using Decal.Adapter.Wrappers;

namespace MelkTank.Loot;

public static class LootFields
{
	private static readonly CultureInfo Inv;

	public static readonly List<FieldDef> Fields;

	public static readonly List<string> Groups;

	public static readonly Dictionary<string, List<KeyValuePair<string, string>>> Maps;

	public static readonly Dictionary<string, Dictionary<int, PropInfo>> Catalog;

	public static readonly Dictionary<string, List<PropInfo>> Pickable;

	public static FieldDef AnyInt;

	public static FieldDef AnyDbl;

	public static FieldDef AnyStr;

	public static readonly Dictionary<string, string> OpNames;

	private static readonly Dictionary<string, string> IntType;

	private static readonly Dictionary<string, string> DblType;

	public static readonly ModDef[] Mods;

	public static readonly Dictionary<string, T11Def> T11;

	public static readonly string[] SlayerT11;

	public static readonly string[] SlayerAll;

	public static readonly string[] GearGrades;

	public static readonly string[] Rends;

	private const string LINE = "(?:^|\\n)- ";

	private static readonly Regex T11Head;

	public static readonly string[] CloakKinds;

	public static readonly string[] NewProcs;

	private static readonly Regex ProcRx;

	public static readonly string[] CloakElements;

	private static readonly string[] RingSpells;

	public const int CloakDrKey = 352;

	public static readonly int[] RatingKeys;

	public static readonly string[] RatingNames;

	public static readonly string[] RatingCodes;

	private static ModDef Mod(int k, string n, string fmt, string band, string special = null, string unit = null, bool tenths = false)
	{
		return new ModDef
		{
			Key = k,
			Name = n,
			Fmt = fmt,
			Band = band,
			Special = special,
			Unit = unit,
			Tenths = tenths
		};
	}

	public static ModDef ModByKey(string k)
	{
		int num = (int)Math.Floor(JsNum(k));
		ModDef[] mods = Mods;
		foreach (ModDef modDef in mods)
		{
			if (modDef.Key == num)
			{
				return modDef;
			}
		}
		return null;
	}

	private static void T(string id, string label, string unit, string def, string where, string opt = null, bool dec = false, bool noValue = false)
	{
		T11[id] = new T11Def
		{
			Id = id,
			Label = label,
			Unit = unit,
			Def = def,
			Where = where,
			Opt = opt,
			Dec = dec,
			NoValue = noValue
		};
	}

	public static string GearGradePattern(string min)
	{
		string value = (string.IsNullOrEmpty(min) ? "C" : min.Substring(0, 1).ToUpperInvariant());
		int num = Array.IndexOf(GearGrades, value);
		if (num < 0)
		{
			num = 0;
		}
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = num; i < GearGrades.Length; i++)
		{
			stringBuilder.Append(GearGrades[i]);
		}
		return "(?:^|\\n)- (?:Gear )?Grade: [" + stringBuilder?.ToString() + "][+\\-]?(?![A-Za-z0-9])";
	}

	static LootFields()
	{
		Inv = CultureInfo.InvariantCulture;
		Fields = new List<FieldDef>();
		Groups = new List<string>();
		Maps = new Dictionary<string, List<KeyValuePair<string, string>>>();
		Catalog = new Dictionary<string, Dictionary<int, PropInfo>>
		{
			{
				"int",
				new Dictionary<int, PropInfo>()
			},
			{
				"double",
				new Dictionary<int, PropInfo>()
			},
			{
				"string",
				new Dictionary<int, PropInfo>()
			}
		};
		Pickable = new Dictionary<string, List<PropInfo>>();
		OpNames = new Dictionary<string, string>
		{
			{ ">=", "at least" },
			{ "<=", "at most" },
			{ "=", "is" },
			{ "!=", "is not" },
			{ "flag", "includes" },
			{ "matches", "matches" }
		};
		IntType = new Dictionary<string, string>
		{
			{ ">=", "3" },
			{ "<=", "2" },
			{ "=", "12" },
			{ "!=", "13" },
			{ "flag", "11" }
		};
		DblType = new Dictionary<string, string>
		{
			{ ">=", "5" },
			{ "<=", "4" }
		};
		Mods = new ModDef[20]
		{
			Mod(28, "Damage Rating", "+{0}", "14-69"),
			Mod(29, "Crit Damage Rating", "+{0}", "14-69"),
			Mod(19, "Max Health", "+{0}", "14-69"),
			Mod(47, "Max Health Pct", "+{0}%", "1-3", null, "%"),
			Mod(43, "All Attributes", "+{0}", "14-69"),
			Mod(33, "Crit Chance", "+{0}", "1-3"),
			Mod(31, "Healing Boost", "+{0}", "14-69"),
			Mod(32, "Spell Duration", "+{0} lvl", "1-3", null, " levels"),
			Mod(48, "Life on Hit", "{0}% HP per hit", "1-3", null, "% HP per hit"),
			Mod(25, "Armor Level", "+{0}", "50-250"),
			Mod(49, "Reinforced", "+{0}", "1-3"),
			Mod(50, "Damage Resist", "+{0}", "35-69"),
			Mod(51, "Crit Damage Resist", "+{0}", "21-42"),
			Mod(52, "Crit Resist", "+{0}", "21-42"),
			Mod(53, "Nether Resist", "+{0}", "21-42"),
			Mod(41, "Fortify Vitals", "+{0}% vitals", "5-25", "Helm", "% vitals"),
			Mod(44, "Pct HP Damage", "{0} (", "4-6", "Gauntlets", "% of max HP", tenths: true),
			Mod(46, "Regeneration", "+{0}% per tick", "1-5", "Bracers", "% per tick"),
			Mod(42, "Battle Mending", "", null, "Chest"),
			Mod(45, "Cheat Death", "", null, "Boots")
		};
		T11 = new Dictionary<string, T11Def>();
		SlayerT11 = new string[16]
		{
			"Human", "Golem", "Undead", "Thrungus", "Shadow", "Banderling", "Ursuin", "Skeleton", "Moarsman", "Reedshark",
			"Sleech", "Grievver", "Chittick", "Shreth", "Niffis", "Remoran"
		};
		SlayerAll = new string[89]
		{
			"Acid Elemental", "Altered Human", "Armoredillo", "Aun Tumerok", "Auroch", "Banderling", "Bleached Rabbit", "Bunny", "Burun", "Carenzi",
			"Chicken", "Chittick", "Cow", "Crystal", "Dark Sarcophagus", "Deru", "Device", "Doll", "Drudge", "Eater",
			"Elemental", "Empyrean", "Enchanted Arms", "Fae", "Fire Elemental", "Fiun", "Frost Elemental", "Ghost", "Golem", "Gotrok Lugian",
			"Grievver", "Grimacing Rabbit", "Gromnie", "Harbinger", "Hea Tumerok", "Hollow Minion", "Hopeslayer", "Human", "Idol", "Knathtead",
			"Lightning Elemental", "Lugian", "Margul", "Marionette", "Mattekar", "Mite", "Moar", "Moarsman", "Monouga", "Mosswart",
			"Mukkir", "Mumiyah", "Nasty Rabbit", "Niffis", "Olthoi", "Olthoi Larvae", "Penguin", "Phyntos Wasp", "Rabbit", "Rat",
			"Reedshark", "Remoran", "Rockslide", "Ruschk", "Scarecrow", "Sclavus", "Shadow", "Shallows Shark", "Shreth", "Simulacrum",
			"Siraluun", "Skeleton", "Sleech", "Slithis", "Snowman", "Statue", "Swarm", "Target", "Thrungus", "Tumerok",
			"Tusker", "Undead", "Unknown", "Ursuin", "Viamontian Knight", "Virindi", "Wall", "Wisp", "Zefir"
		};
		GearGrades = new string[6] { "F", "D", "C", "B", "A", "S" };
		Rends = new string[9] { "Fire", "Cold", "Acid", "Electric", "Lightning", "Slash", "Pierce", "Bludgeon", "Nether" };
		T11Head = new Regex("^\\(\\?#T11 ([A-Za-z0-9_]+)([^)]*)\\)");
		CloakKinds = new string[13]
		{
			"Shroud of Darkness (Melee) - old", "Shroud of Darkness (Missile) - old", "Shroud of Darkness (Magic) - old", "Shroud of Darkness (any) - old", "Damage Reduction - old", "Skill Boost (Cloaked in Skill) - old", "Ring Spell - old", "Any old spell proc", "Calming Breeze (heals 500)", "Smoke Screen (negates a hit)",
			"Artful Dodger (hits go to stamina)", "Asheron's Grace (2 s no damage)", "Any new proc"
		};
		NewProcs = new string[4] { "Calming Breeze", "Smoke Screen", "Artful Dodger", "Asheron's Grace" };
		ProcRx = new Regex("(?:^|\\n)-?\\s*(Calming Breeze|Smoke Screen|Artful Dodger|Asheron's Grace):");
		CloakElements = new string[9] { "Any", "Acid", "Cold", "Fire", "Lightning", "Nether", "Slashing", "Piercing", "Bludgeoning" };
		RingSpells = new string[9] { null, "Searing Disc", "Halo of Frost", "Cassius' Ring of Fire", "Eye of the Storm", "Clouded Soul", "Horizon's Blades", "Nuhmudira's Spines", "Tectonic Rifts" };
		RatingKeys = new int[6] { 372, 374, 370, 371, 375, 373 };
		RatingNames = new string[6] { "Crit", "Crit Damage", "Damage", "Damage Resist", "Crit Damage Resist", "Crit Resist" };
		RatingCodes = new string[6] { "C", "CD", "D", "DR", "CDR", "CR" };
		T("spellrend", "Spell Armor Rend", "% spell armor ignored", "5", "16");
		T("biting", "Biting Strike", "% crit chance", "30", "16");
		T("crush", "Crushing Blow", "x crit damage", "3.5", "16", null, dec: true);
		T("rend", "Rending", "% damage", "150", "16", "el");
		T("slayer", "Slayer", "x damage", "1.5", "16", "sp", dec: true);
		T("cleave", "Cleaving", "extra targets", "1", "16");
		T("armorcl", "Armor Cleaving", "% armor ignored", "20", "16");
		T("shieldcl", "Shield Cleaving", "% shield ignored", "20", "16");
		T("split", "Split Arrow", "extra targets", "1", "16");
		T("proc", "Cast on Strike", null, null, "16", "name", dec: false, noValue: true);
		T("modcount", "Modifier lines", "lines", "6", "14");
		T("gear", "Gear Grade", null, null, "14", "grade", dec: false, noValue: true);
		T("mod", "Modifier", null, null, "14");
		InitMaps();
		List<KeyValuePair<string, string>> list = Maps["charm"];
		list.RemoveAll((KeyValuePair<string, string> kv) => kv.Key == "9007" || kv.Key == "9008" || kv.Key == "9009");
		list.Insert(0, new KeyValuePair<string, string>("9009", "Item Augs"));
		list.Insert(0, new KeyValuePair<string, string>("9008", "Life Augs"));
		list.Insert(0, new KeyValuePair<string, string>("9007", "Creature Augs"));
		InitFields();
		InitCatalog();
		string[] order = new string[10] { "Item", "Weapon", "Armor", "Ratings", "Spells and mana", "Requirements", "Consumables", "ILT Custom", "ILT Custom Pets", "Other" };
		string[] array = new string[3] { "int", "double", "string" };
		foreach (string key in array)
		{
			List<PropInfo> list2 = new List<PropInfo>();
			foreach (PropInfo value in Catalog[key].Values)
			{
				if (value.Pick)
				{
					list2.Add(value);
				}
			}
			list2.Sort((PropInfo a, PropInfo b) =>
			{
				int num2 = Array.IndexOf(order, (a.Group.Length > 0) ? a.Group : "Other");
				int num3 = Array.IndexOf(order, (b.Group.Length > 0) ? b.Group : "Other");
				return (num2 != num3) ? num2.CompareTo(num3) : string.Compare(a.Label, b.Label, StringComparison.OrdinalIgnoreCase);
			});
			Pickable[key] = list2;
		}
	}

	private static void M(string vk, params string[] kv)
	{
		List<KeyValuePair<string, string>> list = new List<KeyValuePair<string, string>>();
		for (int i = 0; i + 1 < kv.Length; i += 2)
		{
			list.Add(new KeyValuePair<string, string>(kv[i], kv[i + 1]));
		}
		Maps[vk] = list;
	}

	private static void F(string group, string label, string kind, int? key, string vk, string[] ops, string tag, string hint, string type, string t11, int? modK, string tip)
	{
		FieldDef fieldDef = new FieldDef
		{
			Group = group,
			Label = label,
			Kind = kind,
			Key = key,
			Vk = vk,
			Ops = ops,
			Tag = tag,
			Hint = hint,
			Type = type,
			T11Id = t11,
			ModK = modK,
			Tip = tip
		};
		Fields.Add(fieldDef);
		if (!Groups.Contains(group))
		{
			Groups.Add(group);
		}
		if (group == "Advanced" && !key.HasValue)
		{
			switch (kind)
			{
			case "int":
				AnyInt = fieldDef;
				fieldDef.IsAny = true;
				break;
			case "dbl":
				AnyDbl = fieldDef;
				fieldDef.IsAny = true;
				break;
			case "str":
				AnyStr = fieldDef;
				fieldDef.IsAny = true;
				break;
			}
		}
	}

	private static void P(string kind, int id, string label, string group, bool pick, int sent, string note, string tag)
	{
		Catalog[kind][id] = new PropInfo
		{
			Id = id,
			Label = label,
			Group = group,
			Pick = pick,
			Sent = sent,
			Note = note,
			Tag = tag
		};
	}

	public static string CatKind(FieldDef f)
	{
		string result;
		if (f.Kind == "dbl")
		{
			result = "double";
		}
		else
		{
			result = ((f.Kind == "str") ? "string" : "int");
		}
		return result;
	}

	public static PropInfo Prop(string kind, int id)
	{
		if (Catalog[kind].TryGetValue(id, out var value))
		{
			return value;
		}
		return new PropInfo
		{
			Id = id,
			Label = "Property " + id,
			Group = "",
			Note = "",
			Tag = "",
			Sent = -1
		};
	}

	public static double JsNum(string s)
	{
		if (s == null)
		{
			return 0.0;
		}
		s = s.Trim();
		if (s.Length == 0)
		{
			return 0.0;
		}
		if (double.TryParse(s, NumberStyles.Float, Inv, out var result) && !double.IsNaN(result) && !double.IsInfinity(result))
		{
			return result;
		}
		return 0.0;
	}

	private static double JsRound(double d)
	{
		return Math.Floor(d + 0.5);
	}

	public static string IntGE(double n)
	{
		n = Math.Max(0.0, Math.Floor(n));
		if (n == 0.0)
		{
			return "\\d+";
		}
		string text = ((long)n).ToString(Inv);
		int length = text.Length;
		List<string> list = new List<string> { "[1-9]\\d{" + length + ",}" };
		for (int i = 0; i < length; i++)
		{
			int num = text[i] - 48;
			if (num < 9)
			{
				int num2 = length - i - 1;
				List<string> list2 = list;
				string text2 = text.Substring(0, i);
				string obj = ((num + 1 == 9) ? "9" : ("[" + (num + 1) + "-9]"));
				string? text3;
				if (num2 <= 0)
				{
					text3 = "";
				}
				else
				{
					text3 = ((num2 == 1) ? "\\d" : ("\\d{" + num2 + "}"));
				}
				list2.Add(text2 + obj + text3);
			}
		}
		list.Add(text);
		return "(?:" + string.Join("|", list.ToArray()) + ")";
	}

	public static string IntGE(string n)
	{
		return IntGE(JsNum(n));
	}

	public static string DecGE(string t)
	{
		long num = (long)Math.Max(0.0, JsRound(JsNum(t) * 100.0));
		long num2 = num / 100;
		long num3 = num % 100;
		List<string> list = new List<string> { IntGE(num2 + 1) + "(?:\\.\\d{1,2})?" };
		if (num3 == 0)
		{
			list.Add(num2 + "(?:\\.\\d{1,2})?");
		}
		else
		{
			long num4 = num3 / 10;
			long num5 = num3 % 10;
			List<string> list2 = new List<string>();
			if (num4 < 9)
			{
				list2.Add("\\." + ((num4 + 1 == 9) ? "9" : ("[" + (num4 + 1) + "-9]")) + "\\d?");
			}
			list2.Add((num5 == 0L) ? ("\\." + num4 + "\\d?") : ("\\." + num4 + ((num5 == 9) ? "9" : ("[" + num5 + "-9]"))));
			list.Add(num2 + "(?:" + string.Join("|", list2.ToArray()) + ")");
		}
		return "(?:" + string.Join("|", list.ToArray()) + ")";
	}

	public static string Esc(string s)
	{
		StringBuilder stringBuilder = new StringBuilder();
		string text = s ?? "";
		foreach (char value in text)
		{
			if (".*+?^${}()|[]\\".IndexOf(value) >= 0)
			{
				stringBuilder.Append('\\');
			}
			stringBuilder.Append(value);
		}
		return stringBuilder.ToString();
	}

	public static string ModPattern(ModDef mod, string min)
	{
		if (string.IsNullOrEmpty(mod.Fmt))
		{
			return "(?:^|\\n)- " + Esc(mod.Name) + "(?=\\r?\\n|$)";
		}
		double n = (mod.Tenths ? JsRound(JsNum(min) * 10.0) : JsNum(min));
		int num = mod.Fmt.IndexOf("{0}", StringComparison.Ordinal);
		string s = mod.Fmt.Substring(0, num);
		string s2 = mod.Fmt.Substring(num + 3);
		return "(?:^|\\n)- " + Esc(mod.Name) + " " + Esc(s) + IntGE(n) + "(?!\\d)" + Esc(s2);
	}

	public static string T11Body(string id, ReqRow p)
	{
		string text = p.Get("v");
		switch (id)
		{
		case "biting":
			return "(?:^|\\n)- Biting Strike: \\+" + IntGE(text) + "(?!\\d)\\s?%";
		case "crush":
			return "(?:^|\\n)- Crushing Blow: " + DecGE(text) + "x";
		case "rend":
		{
			string text4 = p.Get("el");
			string text5;
			if (string.IsNullOrEmpty(text4))
			{
				text5 = "\\w+";
			}
			else
			{
				text5 = ((text4.Equals("Nether", StringComparison.OrdinalIgnoreCase) || text4.Equals("Void", StringComparison.OrdinalIgnoreCase)) ? "(?:Void|Nether)" : Esc(text4));
			}
			return "(?:^|\\n)- " + text5 + " Rending: \\+" + IntGE(text) + "(?!\\d)\\s?%";
		}
		case "slayer":
		{
			string text2 = p.Get("sp");
			return "(?:^|\\n)- " + ((!string.IsNullOrEmpty(text2)) ? Esc(text2) : "[^\\n:]+") + " Slayer: " + DecGE(text) + "x";
		}
		case "cleave":
			return "(?:^|\\n)- Cleaving: \\+" + IntGE(text) + "(?!\\d) Targets";
		case "spellrend":
			return "(?:^|\\n)- Spell Armor Rend: " + IntGE(text) + "(?!\\d)\\s?%";
		case "armorcl":
			return "(?:^|\\n)- Armor Cleaving: " + IntGE(text) + "(?!\\d)\\s?%";
		case "shieldcl":
			return "(?:^|\\n)- Shield Cleaving: " + IntGE(text) + "(?!\\d)\\s?%";
		case "split":
			return "(?:^|\\n)- Split Arrow: \\+" + IntGE(text) + "(?!\\d) Targets";
		case "proc":
		{
			string text3 = p.Get("name");
			return "(?:^|\\n)- Cast on Strike: " + ((!string.IsNullOrEmpty(text3)) ? ("[^\\n]*" + Esc(text3)) : "");
		}
		case "modcount":
			return "Modifiers:\\n(?:- [^\\n]*(?:\\r?\\n|$)){" + Math.Max(1L, (long)Math.Floor(JsNum(text))) + "}";
		case "mod":
			return ModPattern(ModByKey(p.Get("k")) ?? Mods[0], text);
		case "gear":
			return GearGradePattern(p.Get("g"));
		default:
			return "";
		}
	}

	public static string TagEnc(string s)
	{
		StringBuilder stringBuilder = new StringBuilder();
		byte[] bytes = Encoding.UTF8.GetBytes(s ?? "");
		for (int i = 0; i < bytes.Length; i++)
		{
			byte b = bytes[i];
			char c = (char)b;
			if (b < 128 && (char.IsLetterOrDigit(c) || "-_.!~*'".IndexOf(c) >= 0))
			{
				stringBuilder.Append(c);
			}
			else
			{
				stringBuilder.Append('%').Append(b.ToString("X2"));
			}
		}
		return stringBuilder.ToString();
	}

	public static string T11Pattern(string id, ReqRow p)
	{
		StringBuilder stringBuilder = new StringBuilder("(?#T11 " + id);
		foreach (KeyValuePair<string, string> item in p.P)
		{
			if (!string.IsNullOrEmpty(item.Value))
			{
				stringBuilder.Append(' ').Append(item.Key).Append('=')
					.Append(TagEnc(item.Value));
			}
		}
		return stringBuilder.Append(')').Append(T11Body(id, p)).ToString();
	}

	public static bool ReadT11(string regex, out string id, out List<KeyValuePair<string, string>> p)
	{
		id = null;
		p = null;
		Match match = T11Head.Match(regex ?? "");
		if (!match.Success || !T11.ContainsKey(match.Groups[1].Value))
		{
			return false;
		}
		id = match.Groups[1].Value;
		p = new List<KeyValuePair<string, string>>();
		string[] array = match.Groups[2].Value.Trim().Split(new char[2] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
		foreach (string text in array)
		{
			int num = text.IndexOf('=');
			string key = ((num < 0) ? text : text.Substring(0, num));
			string text2 = ((num < 0) ? "" : text.Substring(num + 1));
			try
			{
				text2 = Uri.UnescapeDataString(text2);
			}
			catch
			{
			}
			p.Add(new KeyValuePair<string, string>(key, text2));
		}
		return true;
	}

	private static FieldDef FieldFor(string kind, int key)
	{
		foreach (FieldDef field in Fields)
		{
			if (field.Kind == kind && field.Key == key)
			{
				return field;
			}
		}
		return null;
	}

	private static FieldDef FieldKind(string kind)
	{
		foreach (FieldDef field in Fields)
		{
			if (field.Kind == kind)
			{
				return field;
			}
		}
		return null;
	}

	private static FieldDef FieldT11(string id, string k)
	{
		foreach (FieldDef field in Fields)
		{
			if (field.Kind == "t11" && field.T11Id == id && (id != "mod" || field.ModK == (int)Math.Floor(JsNum(k))))
			{
				return field;
			}
		}
		return null;
	}

	private static int Int(string s)
	{
		return (int)Math.Floor(JsNum(s));
	}

	public static string CloakProc(WorldObject o)
	{
		try
		{
			Match match = ProcRx.Match((LootMatcher.Str(o, 14) + "\n" + LootMatcher.Str(o, 16)).Replace("\r", ""));
			return match.Success ? match.Groups[1].Value : null;
		}
		catch
		{
			return null;
		}
	}

	public static string NewProcFor(string oldPattern)
	{
		if (!ReadCloakPattern(oldPattern, out var kind, out var _) || kind >= 8)
		{
			return null;
		}
		if (kind <= 3)
		{
			return "^Smoke Screen$";
		}
		return kind switch
		{
			5 => "^Asheron's Grace$", 
			6 => "^Calming Breeze$", 
			7 => CloakPattern(12, 0), 
			_ => null, 
		};
	}

	private static string RingPattern(int el)
	{
		if (el > 0 && el < RingSpells.Length)
		{
			return "^" + RingSpells[el] + "$";
		}
		List<string> list = new List<string>();
		for (int i = 1; i < RingSpells.Length; i++)
		{
			list.Add(RingSpells[i]);
		}
		return "^(" + string.Join("|", list.ToArray()) + ")$";
	}

	public static string CloakPattern(int kind, int el)
	{
		switch (kind)
		{
		case 0:
			return "^Shroud of Darkness \\(Melee\\)$";
		case 1:
			return "^Shroud of Darkness \\(Missile\\)$";
		case 2:
			return "^Shroud of Darkness \\(Magic\\)$";
		case 3:
			return "^Shroud of Darkness \\((Melee|Missile|Magic)\\)$";
		case 5:
			return "^Cloaked in Skill$";
		case 6:
			return RingPattern(el);
		case 7:
		{
			string text = RingPattern(0);
			return "^(Shroud of Darkness \\((Melee|Missile|Magic)\\)|Cloaked in Skill|" + text.Substring(2, text.Length - 4) + ")$";
		}
		case 8:
		case 9:
		case 10:
		case 11:
			return "^" + NewProcs[kind - 8] + "$";
		case 12:
			return "^(" + string.Join("|", NewProcs) + ")$";
		default:
			return null;
		}
	}

	private static bool ReadCloakPattern(string p, out int kind, out int el)
	{
		kind = 0;
		while (kind < CloakKinds.Length)
		{
			if (kind == 6)
			{
				for (el = 0; el < CloakElements.Length; el++)
				{
					if (RingPattern(el) == p)
					{
						return true;
					}
				}
			}
			else
			{
				el = 0;
				if (CloakPattern(kind, 0) == p)
				{
					return true;
				}
			}
			kind++;
		}
		kind = 0;
		el = 0;
		return false;
	}

	public static int RatingIndex(int key)
	{
		return Array.IndexOf(RatingKeys, key);
	}

	public static ReqRow ToRow(UtlReq q)
	{
		if (q.Vals == null)
		{
			return null;
		}
		List<string> v = q.Vals;
		Func<int, string> func = (int i) => (i < v.Count) ? v[i] : "";
		string type = q.Type;
		ReqRow reqRow = new ReqRow();
		if (type == "12" && Int(func(1)) == 352 && Int(func(0)) == 2)
		{
			reqRow.F = FieldKind("cloakspell");
			reqRow.V.Add("4");
			reqRow.V.Add("0");
			return reqRow;
		}
		if (type == "0" && ReadCloakPattern(func(0), out var kind, out var el))
		{
			reqRow.F = FieldKind("cloakspell");
			reqRow.V.Add(kind.ToString(Inv));
			reqRow.V.Add(el.ToString(Inv));
			return reqRow;
		}
		string text = type switch
		{
			"11" => "flag", 
			"13" => "!=", 
			"12" => "=", 
			"2" => "<=", 
			"3" => ">=", 
			_ => null, 
		};
		if (type == "3" && RatingIndex(Int(func(1))) >= 0)
		{
			reqRow.F = FieldKind("aethrating");
			reqRow.Key = Int(func(1));
			reqRow.Op = ">=";
			reqRow.V.Add(func(0));
			return reqRow;
		}
		if (text != null)
		{
			int num = Int(func(1));
			reqRow.F = FieldFor("int", num) ?? AnyInt;
			reqRow.Key = num;
			reqRow.Op = text;
			reqRow.V.Add(func(0));
			return reqRow;
		}
		if (type == "5" || type == "4")
		{
			int num2 = Int(func(1));
			reqRow.F = FieldFor("dbl", num2) ?? AnyDbl;
			reqRow.Key = num2;
			reqRow.Op = ((type == "5") ? ">=" : "<=");
			reqRow.V.Add(func(0));
			return reqRow;
		}
		if (type == "1")
		{
			if (ReadT11(func(0), out var id, out var p))
			{
				string k = null;
				foreach (KeyValuePair<string, string> item in p)
				{
					if (item.Key == "k")
					{
						k = item.Value;
					}
				}
				FieldDef fieldDef = FieldT11(id, k);
				if (fieldDef != null)
				{
					reqRow.F = fieldDef;
					reqRow.P = p;
					reqRow.Where = func(1);
					return reqRow;
				}
			}
			int num3 = Int(func(1));
			reqRow.F = FieldFor("str", num3) ?? AnyStr;
			reqRow.Key = num3;
			reqRow.Op = "matches";
			reqRow.V.Add(func(0));
			return reqRow;
		}
		switch (type)
		{
		case "7":
			reqRow.F = FieldKind("oclass");
			reqRow.V.Add(func(0));
			return reqRow;
		case "0":
			reqRow.F = FieldKind("spellname");
			reqRow.V.Add(func(0));
			return reqRow;
		case "9":
			reqRow.F = FieldKind("spells");
			reqRow.V.AddRange(v);
			return reqRow;
		case "8":
			reqRow.F = FieldKind("spellcount");
			reqRow.Op = ">=";
			reqRow.V.Add(func(0));
			return reqRow;
		case "1002":
		case "1003":
			reqRow.F = FieldKind("charlvl");
			reqRow.Op = ((type == "1002") ? ">=" : "<=");
			reqRow.V.Add(func(0));
			return reqRow;
		case "1000":
			reqRow.F = FieldKind("charskill");
			reqRow.Op = ">=";
			reqRow.V.Add(func(0));
			reqRow.V.Add(func(1));
			return reqRow;
		case "1004":
			reqRow.F = FieldKind("charbase");
			reqRow.V.AddRange(v);
			return reqRow;
		case "1001":
			reqRow.F = FieldKind("packslots");
			reqRow.Op = ">=";
			reqRow.V.Add(func(0));
			return reqRow;
		default:
		{
			foreach (FieldDef field in Fields)
			{
				if (field.Kind == "calc" && field.Type == type)
				{
					reqRow.F = field;
					reqRow.Op = ">=";
					reqRow.V.Add(func(0));
					return reqRow;
				}
			}
			foreach (FieldDef field2 in Fields)
			{
				if (field2.Kind == "raw" && field2.Type == type)
				{
					reqRow.F = field2;
					reqRow.V.AddRange(v);
					return reqRow;
				}
			}
			UtlSpec.ReqType reqType = UtlSpec.Get(type);
			reqRow.F = new FieldDef
			{
				Kind = "raw",
				Type = type,
				Group = "Advanced",
				Label = ((reqType != null) ? reqType.Name : ("Unknown requirement " + type)),
				Tip = ""
			};
			reqRow.V.AddRange(v);
			return reqRow;
		}
		}
	}

	public static UtlReq FromRow(ReqRow row)
	{
		FieldDef f = row.F;
		Func<int, string, string> func = (int i, string d) => (i < row.V.Count && row.V[i] != null) ? row.V[i] : d;
		string text;
		if (row.Key.HasValue)
		{
			text = row.Key.Value.ToString(Inv);
		}
		else
		{
			text = (f.Key.HasValue ? f.Key.Value.ToString(Inv) : null);
		}
		string value;
		switch (f.Kind)
		{
		case "int":
			return UtlReq.New(IntType.TryGetValue(row.Op ?? "", out value) ? value : "3", func(0, "0"), text ?? "28");
		case "aethrating":
			return UtlReq.New("3", func(0, "1"), text ?? "372");
		case "dbl":
			return UtlReq.New(DblType.TryGetValue(row.Op ?? "", out value) ? value : "5", func(0, "0"), text ?? "159");
		case "str":
			return UtlReq.New("1", func(0, ""), text ?? "1");
		case "t11":
			return UtlReq.New("1", T11Pattern(f.T11Id, row), (!string.IsNullOrEmpty(row.Where)) ? row.Where : T11[f.T11Id].Where);
		case "oclass":
			return UtlReq.New("7", func(0, "2"));
		case "spellname":
			return UtlReq.New("0", func(0, ""));
		case "cloakspell":
		{
			int num2 = Int(func(0, "0"));
			int el = Int(func(1, "0"));
			if (num2 == 4)
			{
				return UtlReq.New("12", "2", 352.ToString(Inv));
			}
			return UtlReq.New("0", CloakPattern(num2, el) ?? CloakPattern(7, 0));
		}
		case "spells":
			return UtlReq.New("9", func(0, ""), func(1, ""), func(2, "1"));
		case "spellcount":
			return UtlReq.New("8", func(0, "1"));
		case "charlvl":
			return UtlReq.New((row.Op == "<=") ? "1003" : "1002", func(0, "1"));
		case "charskill":
			return UtlReq.New("1000", func(0, "0"), func(1, "6"));
		case "charbase":
			return UtlReq.New("1004", func(0, "6"), func(1, "0"), func(2, "999"));
		case "packslots":
			return UtlReq.New("1001", func(0, "1"));
		case "calc":
			return UtlReq.New(f.Type, func(0, "0"));
		default:
		{
			UtlSpec.ReqType reqType = UtlSpec.Get(f.Type);
			List<string> list = new List<string>();
			if (reqType != null)
			{
				for (int num = 0; num < reqType.Fields.Length; num++)
				{
					list.Add(func(num, "0"));
				}
			}
			else
			{
				list.AddRange(row.V);
			}
			return UtlReq.New(f.Type, list.ToArray());
		}
		}
	}

	private static string VkDefault(string vk)
	{
		return vk switch
		{
			"grade" => "800", 
			"slot" => "2097152", 
			"material" => "64", 
			"dmgtype" => "16", 
			"skill" => "46", 
			"mastery" => "1", 
			"attack" => "31200", 
			"heritage" => "1", 
			"charm" => "50000", 
			"petstat" => "1", 
			"imbue" => "17400", 
			"unench" => "9999", 
			_ => "0", 
		};
	}

	public static ReqRow NewRow(FieldDef f)
	{
		ReqRow reqRow = new ReqRow
		{
			F = f,
			Key = (f.Key ?? ((f.Kind == "dbl") ? 159 : ((f.Kind == "str") ? 16 : 28))),
			Op = ((f.Ops != null) ? f.Ops[0] : ">=")
		};
		if (f.Kind == "int" || f.Kind == "dbl")
		{
			reqRow.V.Add(VkDefault(f.Vk));
		}
		if (f.Kind == "str")
		{
			reqRow.Op = "matches";
			reqRow.V.Add("");
		}
		if (f.Kind == "t11")
		{
			if (f.T11Id == "mod")
			{
				ModDef modDef = ModByKey(f.ModK.Value.ToString(Inv));
				reqRow.Set("k", f.ModK.Value.ToString(Inv));
				if (!string.IsNullOrEmpty(modDef.Fmt))
				{
					string[] array = modDef.Band.Split('-');
					reqRow.Set("v", modDef.Tenths ? "5" : JsRound((JsNum(array[0]) + JsNum(array[1])) / 2.0).ToString(Inv));
				}
			}
			else if (f.T11Id == "gear")
			{
				reqRow.Set("g", "C");
			}
			else if (!T11[f.T11Id].NoValue)
			{
				reqRow.Set("v", T11[f.T11Id].Def);
			}
			reqRow.Where = T11[f.T11Id].Where;
		}
		if (f.Kind == "oclass")
		{
			reqRow.V.Add("2");
		}
		if (f.Kind == "spellname")
		{
			reqRow.V.Add("");
		}
		if (f.Kind == "cloakspell")
		{
			reqRow.V.AddRange(new string[2] { "0", "0" });
		}
		if (f.Kind == "spells")
		{
			reqRow.V.AddRange(new string[3] { "Legendary", "", "1" });
		}
		if (f.Kind == "spellcount" || f.Kind == "packslots" || f.Kind == "charlvl")
		{
			reqRow.V.Add("1");
		}
		if (f.Kind == "calc")
		{
			reqRow.V.Add("0");
		}
		if (f.Kind == "aethrating")
		{
			reqRow.Op = ">=";
			reqRow.V.Add("1");
		}
		if (f.Kind == "charskill")
		{
			reqRow.V.AddRange(new string[2] { "0", "6" });
		}
		if (f.Kind == "charbase")
		{
			reqRow.V.AddRange(new string[3] { "6", "0", "999" });
		}
		if (f.Kind == "raw")
		{
			UtlSpec.ReqType reqType = UtlSpec.Get(f.Type);
			if (reqType != null)
			{
				string[][] fields = reqType.Fields;
				foreach (string[] array2 in fields)
				{
					List<string> v = reqRow.V;
					string item;
					if (array2[1] == "ikey")
					{
						item = "28";
					}
					else
					{
						item = ((array2[1] == "dkey") ? "159" : "0");
					}
					v.Add(item);
				}
			}
		}
		return reqRow;
	}

	public static string FieldLabel(ReqRow row)
	{
		if (row.F.IsAny && row.Key.HasValue)
		{
			return Prop(CatKind(row.F), row.Key.Value).Label;
		}
		return row.F.Label;
	}

	public static string MapText(string vk, string x)
	{
		if (vk == null || !Maps.TryGetValue(vk, out var value))
		{
			return x;
		}
		if (vk == "grade")
		{
			double num = JsNum(x);
			foreach (KeyValuePair<string, string> item in value)
			{
				if (num >= JsNum(item.Key))
				{
					return item.Value.Substring(0, 1) + " (" + x + ")";
				}
			}
			return "F (" + x + ")";
		}
		foreach (KeyValuePair<string, string> item2 in value)
		{
			if (item2.Key == x)
			{
				return item2.Value;
			}
		}
		return x;
	}

	private static string SkillName(string x)
	{
		string text = MapText("skill", x);
		return (text == x) ? ("Skill " + x) : text;
	}

	public static string RowSay(ReqRow row)
	{
		FieldDef f = row.F;
		Func<int, string> func = (int i) => (i < row.V.Count) ? row.V[i] : "";
		OpNames.TryGetValue(row.Op ?? "", out var value);
		switch (f.Kind)
		{
		case "int":
		case "dbl":
			return FieldLabel(row) + " " + value + " " + MapText(f.Vk, func(0));
		case "str":
			return FieldLabel(row) + " matches " + func(0);
		case "t11":
		{
			string text = row.Get("v");
			if (f.T11Id == "mod")
			{
				ModDef modDef = ModByKey(row.Get("k")) ?? Mods[0];
				return (!string.IsNullOrEmpty(modDef.Fmt)) ? (modDef.Name + " at least " + text + modDef.Unit) : ("Has " + modDef.Name);
			}
			if (f.T11Id == "modcount")
			{
				return "At least " + text + " modifier lines";
			}
			if (f.T11Id == "gear")
			{
				return "Gear Grade at least " + (row.Get("g") ?? "C");
			}
			if (f.T11Id == "proc")
			{
				string text2 = row.Get("name");
				return "Cast on Strike" + ((!string.IsNullOrEmpty(text2)) ? (": " + text2) : " (any)");
			}
			T11Def t11Def = T11[f.T11Id];
			string text3 = row.Get("el");
			if (string.IsNullOrEmpty(text3))
			{
				text3 = row.Get("sp");
			}
			return t11Def.Label + ((!string.IsNullOrEmpty(text3)) ? (" (" + text3 + ")") : "") + " at least " + text + ((t11Def.Unit.StartsWith("%") || t11Def.Unit.StartsWith("x")) ? "" : " ") + t11Def.Unit;
		}
		case "oclass":
		{
			int num = Int(func(0));
			return "Item type is " + ((num >= 0 && num < UtlSpec.ObjectClasses.Length) ? UtlSpec.ObjectClasses[num] : func(0));
		}
		case "spellname":
			return "Has a spell named like " + func(0);
		case "cloakspell":
		{
			int num3 = Int(func(0));
			int num4 = Int(func(1));
			if (num3 < 0 || num3 >= CloakKinds.Length)
			{
				num3 = 0;
			}
			if (num4 < 0 || num4 >= CloakElements.Length)
			{
				num4 = 0;
			}
			if (num3 == 6)
			{
				return "Cloak spell: Ring Spell (" + ((num4 == 0) ? "any element" : CloakElements[num4]) + ")";
			}
			return "Cloak spell: " + CloakKinds[num3];
		}
		case "spells":
			return "At least " + func(2) + " spell(s) like " + func(0) + ((func(1).Length > 0) ? (", not " + func(1)) : "");
		case "spellcount":
			return "At least " + func(0) + " spells";
		case "charlvl":
			return "Character level " + value + " " + func(0);
		case "charskill":
			return SkillName(func(1)) + " skill at least " + func(0);
		case "charbase":
			return SkillName(func(0)) + " base skill " + func(1) + " to " + func(2);
		case "packslots":
			return "At least " + func(0) + " free main pack slots";
		case "calc":
			return f.Label + " at least " + func(0);
		case "aethrating":
		{
			int num2 = RatingIndex(row.Key ?? 372);
			return "Rating " + ((num2 >= 0) ? (RatingNames[num2] + " (" + RatingCodes[num2] + ")") : "?") + " at least " + func(0);
		}
		default:
			return f.Label + ((row.V.Count > 0) ? (": " + string.Join(", ", row.V.ToArray())) : "");
		}
	}

	public static string RowWarn(ReqRow row, out bool bad)
	{
		bad = false;
		FieldDef f = row.F;
		if ((f.Kind != "int" && f.Kind != "dbl" && f.Kind != "str") || !row.Key.HasValue)
		{
			return null;
		}
		PropInfo propInfo = Prop(CatKind(f), row.Key.Value);
		if (propInfo.Sent == 0)
		{
			bad = true;
			return propInfo.Label + " is never sent to the client - VTank can not see it, so this never matches.";
		}
		if (propInfo.Sent < 0)
		{
			return "Property #" + row.Key.Value + " is not in the list - only use it if you know the server sends it.";
		}
		return null;
	}

	private static void InitMaps()
	{
		M("material", "1", "Ceramic", "2", "Porcelain", "4", "Linen", "5", "Satin", "6", "Silk", "7", "Velvet", "8", "Wool", "10", "Agate", "11", "Amber", "12", "Amethyst", "13", "Aquamarine", "14", "Azurite", "15", "Black Garnet", "16", "Black Opal", "17", "Bloodstone", "18", "Carnelian", "19", "Citrine", "20", "Diamond", "21", "Emerald", "22", "Fire Opal", "23", "Green Garnet", "24", "Green Jade", "25", "Hematite", "26", "Imperial Topaz", "27", "Jet", "28", "Lapis Lazuli", "29", "Lavender Jade", "30", "Malachite", "31", "Moonstone", "32", "Onyx", "33", "Opal", "34", "Peridot", "35", "Red Garnet", "36", "Red Jade", "37", "Rose Quartz", "38", "Ruby", "39", "Sapphire", "40", "Smokey Quartz", "41", "Sunstone", "42", "Tiger Eye", "43", "Tourmaline", "44", "Turquoise", "45", "White Jade", "46", "White Quartz", "47", "White Sapphire", "48", "Yellow Garnet", "49", "Yellow Topaz", "50", "Zircon", "51", "Ivory", "52", "Leather", "53", "Armoredillo Hide", "54", "Gromnie Hide", "55", "Reed Shark Hide", "57", "Brass", "58", "Bronze", "59", "Copper", "60", "Gold", "61", "Iron", "62", "Pyreal", "63", "Silver", "64", "Steel", "66", "Alabaster", "67", "Granite", "68", "Marble", "69", "Obsidian", "70", "Sandstone", "71", "Serpentine", "73", "Ebony", "74", "Mahogany", "75", "Oak", "76", "Pine", "77", "Teak");
		M("slot", "1", "Head", "32", "Hands", "256", "Feet", "512", "Chest", "1024", "Abdomen", "2048", "Upper arms", "4096", "Lower arms", "8192", "Upper legs", "16384", "Lower legs", "2", "Chest (under)", "4", "Abdomen (under)", "8", "Upper arms (under)", "16", "Lower arms (under)", "64", "Upper legs (under)", "128", "Lower legs (under)", "32768", "Necklace", "196608", "Bracelet", "65536", "Right bracelet", "131072", "Left bracelet", "786432", "Ring", "262144", "Right ring", "524288", "Left ring", "1048576", "Melee weapon", "2097152", "Shield", "4194304", "Missile weapon", "8388608", "Ammunition", "16777216", "Wand", "33554432", "Two-handed weapon", "67108864", "Trinket", "134217728", "Cloak", "268435456", "Blue sigil", "536870912", "Yellow sigil", "1073741824", "Red sigil");
		M("dmgtype", "1", "Slash", "2", "Pierce", "4", "Bludgeon", "8", "Cold", "16", "Fire", "32", "Acid", "64", "Electric", "1024", "Nether");
		M("skill", "1", "Axe", "2", "Bow", "3", "Crossbow", "4", "Dagger", "5", "Mace", "6", "Melee Defense", "7", "Missile Defense", "9", "Spear", "10", "Staff", "11", "Sword", "12", "Thrown Weapons", "13", "Unarmed", "14", "Arcane Lore", "15", "Magic Defense", "16", "Mana Conversion", "18", "Item Tinkering", "19", "Assess Person", "20", "Deception", "21", "Healing", "22", "Jump", "23", "Lockpick", "24", "Run", "27", "Assess Creature", "28", "Weapon Tinkering", "29", "Armor Tinkering", "30", "Magic Item Tinkering", "31", "Creature Enchantment", "32", "Item Enchantment", "33", "Life Magic", "34", "War Magic", "35", "Leadership", "36", "Loyalty", "37", "Fletching", "38", "Alchemy", "39", "Cooking", "40", "Salvaging", "41", "Two Handed Combat", "42", "Gearcraft", "43", "Void Magic", "44", "Heavy Weapons", "45", "Light Weapons", "46", "Finesse Weapons", "47", "Missile Weapons", "48", "Shield", "49", "Dual Wield", "50", "Recklessness", "51", "Sneak Attack", "52", "Dirty Fighting", "54", "Summoning");
		M("mastery", "1", "Unarmed", "2", "Sword", "3", "Axe", "4", "Mace", "5", "Spear", "6", "Dagger", "7", "Staff", "8", "Bow", "9", "Crossbow", "10", "Thrown", "11", "Two-handed");
		M("attack", "31200", "Multi-strike (any)", "2", "Thrust", "4", "Slash", "6", "Thrust or slash", "32", "Double slash", "64", "Triple slash", "128", "Double thrust", "256", "Triple thrust", "1", "Punch", "8", "Kick");
		M("heritage", "1", "Aluvian", "2", "Gharundim", "3", "Sho", "4", "Viamontian", "5", "Shadowbound", "6", "Gearknight", "7", "Tumerok", "8", "Lugian", "9", "Empyrean", "10", "Penumbraen", "11", "Undead", "12", "Olthoi", "13", "Olthoi (acid)");
		M("charm", "9008", "Item augmentations", "50000", "Triune Weave", "50001", "Battlemage's Wrath", "50002", "Nether Veil", "50003", "Crashing Steel", "50004", "True Shot");
		M("petstat", "1", "Damage rating", "2", "Damage resist rating", "3", "Crit rating", "4", "Vitality", "5", "Potency");
		M("imbue", "17400", "Any element rend", "512", "Fire Rending", "128", "Cold Rending", "64", "Acid Rending", "256", "Lightning Rending", "16384", "Nether Rending", "8", "Slash Rending", "16", "Pierce Rending", "32", "Bludgeon Rending", "4", "Armor Rending", "2", "Crushing Blow imbue (retail)", "1", "Biting Strike imbue (retail)", "1024", "Melee Defense imbue", "2048", "Missile Defense imbue", "4096", "Magic Defense imbue", "8192", "Spellbook imbue", "1073741824", "Always critical", "536870912", "Ignores some magic projectile damage", "0", "No imbue");
		M("unench", "9999", "Yes (can't be enchanted)");
		M("grade", "1000", "S (quality 1000+)", "900", "A (quality 900+)", "800", "B (quality 800+)", "650", "C (quality 650+)", "500", "D (quality 500+)", "0", "F (quality 0+)");
	}

	private static void InitFields()
	{
		F("Better Than Equipped", "Damage vs Equipped %", "calc", null, null, null, null, "wands / staves / orbs: % more damage", "3001", null, null, "How much more damage this caster does than the one you're wielding of the same element, by the server's damage formula (% vs. Monsters x matching rend x spell armor rend at your tier) - the \"~+14% damage\" in the compare line.\nExample: Damage vs Equipped % at least 5 (keeps anything 5% or more better)\nNeeds a wielded caster of the same element. Calculated by MelkTank.");
		F("Better Than Equipped", "Damage vs Equipped with Slayer %", "calc", null, null, null, null, "best % more on a slayer's creature type", "3002", null, null, "Like Damage vs Equipped %, but against the creature type of a slayer on either caster, counting the slayer - the best of those (the \"(+42% on Banderling)\" in the compare line).\nExample: Damage vs Equipped with Slayer % at least 10\nNeeds a wielded caster of the same element and a slayer on one of them. Calculated by MelkTank.");
		F("Better Than Equipped", "Gear Mods vs Equipped %", "calc", null, null, null, null, "armor / jewelry: DR+D+CD+Attr vs what you wear", "3003", null, null, "Armor, jewelry and clothing: the total of Damage Resist, Damage Rating, Crit Damage Rating and All Attributes as a % of\nits max (T11 4 x 69 = 276, T12 4 x 74 = 296 - read from its ranges), minus the same for the piece you wear in a slot it can go in (rings / bracelets, or a piece that\ncovers several slots: the weakest of those) - the \"(+24%)\" at the end of the compare line. Nothing worn there counts as 0.\nExample: Gear Mods vs Equipped % at least 1 (keeps anything better than what you wear)\nCalculated by MelkTank.");
		F("Better Than Equipped", "Gear Mods % of Max", "calc", null, null, null, null, "armor / jewelry: DR+D+CD+Attr as % of its max", "3004", null, null, "Armor, jewelry and clothing: the total of Damage Resist, Damage Rating, Crit Damage Rating and All Attributes as a % of\nits max (T11 4 x 69 = 276, T12 4 x 74 = 296 - read from its ranges) - not compared with anything.\nExample: Gear Mods % of Max at least 85\nCalculated by MelkTank.");
		F("Aetheria", "Aetheria Rating", "aethrating", 372, null, null, null, "C4, CD3, DR2... pick the rating + level", null, null, null, "One rating on the item, picked from the list - what the ID line shows as C4, CD3, D2, DR1, CDR2...\nCrit (C), Crit Damage (CD), Damage (D), Damage Resist (DR), Crit Damage Resist (CDR), Crit Resist (CR).\nExample: Aetheria Rating Crit at least 4, with Name matching Aetheria and Cloak / Aetheria Level at least 7\nSaved as the rating's property (#370-375) at least the number, so VTank reads it too.");
		F("Aetheria", "Aetheria Level", "int", 319, null, null, null, "1-10 (untuned ones too)", null, null, null, "The aetheria's level, 1 to 10 - the Lvl in its ID line. Untuned (Coalesced) aetheria have it too.\nExample: Aetheria Level at least 7\nProperty #319 (Item Max Level) - the same as Cloak / Aetheria Level.");
		F("Item", "Name", "str", 1, null, null, null, "text match", null, null, null, "The item's name. Matches anywhere in the name; | means \"or\", ^ and $ pin the start and end.\nExample: ^Gold Pea$|Mana Stone\nProperty #1 (text)");
		F("Item", "Item Type", "oclass", null, null, null, null, "armor, weapon, jewelry...", null, null, null, "VTank's item class: armor, melee weapon, missile weapon, jewelry, clothing, gem, salvage, wand / staff / orb ...\nExample: Armor");
		F("Item", "Slot", "int", 218103822, "slot", new string[2] { "=", "flag" }, null, "head, ring, shield...", null, null, null, "Where the item is worn or wielded. \"includes\" also matches items that fit more than one slot (a ring fits either hand).\nExample: Slot is Shield\nProperty #218103822");
		F("Item", "Material", "int", 131, "material", new string[2] { "=", "!=" }, null, null, null, null, null, "What the item is made of - the salvage it gives.\nExample: Material is Steel\nProperty #131");
		F("Item", "Unenchantable", "int", 36, "unench", new string[2] { "!=", "=" }, null, "can't be buffed / enchanted", null, null, null, "Items that can't be enchanted (your buffs and debuffs don't land on them) - the ID line says Unenchantable.\nExample: Unenchantable is not Yes (leaves those items behind)\nProperty #36");
		F("Item", "Value", "int", 19, null, null, null, null, null, null, null, "What the item is worth, in pyreals.\nExample: Value at least 50000\nProperty #19");
		F("Item", "Burden", "int", 5, null, null, null, null, null, null, null, "How heavy the item is (burden units).\nExample: Burden at most 500\nProperty #5");
		F("Item", "Workmanship", "int", 105, null, null, null, null, null, null, null, "Workmanship, 1 to 10. Higher gives better salvage.\nExample: Workmanship at least 9\nProperty #105");
		F("Item", "Arcane Lore Requirement", "int", 109, null, null, null, null, null, null, null, "The Arcane Lore needed to use the item's spells.\nExample: Arcane Lore Requirement at most 400\nProperty #109");
		F("Item", "Wield Requirement Value", "int", 160, null, null, null, null, null, null, null, "The number on the item's first wield requirement - the level or skill you need to wield it.\nExample: Wield Requirement Value at least 420\nProperty #160");
		F("Item", "Cloak / Aetheria Level", "int", 319, null, null, null, "cloak 1-5, aetheria 1-10", null, null, null, "The cloak's (or aetheria's) level - cloaks 1 to 5, aetheria 1 to 10. Shown in game as the cloak's level.\nExample: Cloak / Aetheria Level at least 5\nProperty #319 (Item Max Level)");
		F("Item", "Stack Size", "int", 218103814, null, null, null, null, null, null, null, "How many are in the stack.\nExample: Stack Size at least 25\nProperty #218103814");
		F("Item", "Rare", "int", 17, null, null, null, "rare id", null, null, null, "The rare id. Any rare has one above 0.\nExample: Rare at least 1\nProperty #17");
		F("Item", "WCID", "int", 218103808, null, new string[2] { "=", "!=" }, null, null, null, null, null, "The item's exact template number. Matches one exact item.\nExample: WCID is 20630\nProperty #218103808");
		F("Item", "Description", "str", 16, null, null, null, "text match", null, null, null, "The item's long description text. T11+ weapons list their cards here (\"Property Details:\").\nExample: Biting Strike\nProperty #16 (text)");
		F("Spells", "Has a Spell Named", "spellname", null, null, null, null, null, null, null, null, "The item carries a spell whose name matches.\nExample: Legendary Blood Thirst");
		F("Spells", "Cloak Spell", "cloakspell", null, null, null, null, "cloak proc: Calming Breeze, Smoke Screen...", null, null, null, "What the cloak does when it triggers. Since the T11+ cloak patch: Calming Breeze (heals 500 - was the rings),\nSmoke Screen (negates a hit - was the Shrouds), Artful Dodger (your next 3 hits go to stamina - was the -200 damage weave)\nor Asheron's Grace (2 s of no damage - was Cloaked in Skill). The old choices still work: each means the proc that replaced it.\nExample: Cloak spell is Smoke Screen\nSaved as a spell-name match (the old Damage Reduction as property #352 is 2).");
		F("Spells", "Spells Matching", "spells", null, null, null, null, "count spells like Legendary...", null, null, null, "Counts the item's spells whose names match (and do not match \"but not\"), and needs at least that many.\nExample: Legendary|Epic, at least 2");
		F("Spells", "Number of Spells", "spellcount", null, null, null, null, null, null, null, null, "How many spells the item carries.\nExample: Number of Spells at least 4");
		F("Spells", "Spellcraft", "int", 106, null, null, null, null, null, null, null, "The item's spellcraft - how hard its spells are to resist.\nExample: Spellcraft at least 400\nProperty #106");
		F("Spells", "Max Mana", "int", 108, null, null, null, null, null, null, null, "The item's mana pool.\nExample: Max Mana at least 1000\nProperty #108");
		F("Ratings", "Total Ratings", "calc", null, null, null, null, "damage + crit damage + resists...", "2007", null, null, "VTank adds up 8 retail ratings on the item: damage, damage resist, crit, crit resist, crit damage, crit damage resist, healing boost and vitality. ILT modifier lines are not counted - use ILT Custom Mods for those.\nExample: Total Ratings at least 10\nCalculated by VTank from the item.");
		F("Ratings", "Damage Rating", "int", 370, null, null, null, "retail ratings - for ILT mods use ILT Custom Mods", null, null, null, "A retail rating on the item (Damage). Counts toward Total Ratings. ILT modifier lines are text, not this number - use ILT Custom Mods for those.\nExample: Damage Rating at least 3\nProperty #370");
		F("Ratings", "Crit Damage Rating", "int", 374, null, null, null, "retail ratings - for ILT mods use ILT Custom Mods", null, null, null, "A retail rating on the item (Crit Damage). Counts toward Total Ratings. ILT modifier lines are text, not this number - use ILT Custom Mods for those.\nExample: Crit Damage Rating at least 3\nProperty #374");
		F("Ratings", "Damage Resist Rating", "int", 371, null, null, null, "retail ratings - for ILT mods use ILT Custom Mods", null, null, null, "A retail rating on the item (Damage Resist). Counts toward Total Ratings. ILT modifier lines are text, not this number - use ILT Custom Mods for those.\nExample: Damage Resist Rating at least 3\nProperty #371");
		F("Ratings", "Crit Damage Resist Rating", "int", 375, null, null, null, "retail ratings - for ILT mods use ILT Custom Mods", null, null, null, "A retail rating on the item (Crit Damage Resist). Counts toward Total Ratings. ILT modifier lines are text, not this number - use ILT Custom Mods for those.\nExample: Crit Damage Resist Rating at least 3\nProperty #375");
		F("Ratings", "Crit Rating", "int", 372, null, null, null, "retail ratings - for ILT mods use ILT Custom Mods", null, null, null, "A retail rating on the item (Crit). Counts toward Total Ratings. ILT modifier lines are text, not this number - use ILT Custom Mods for those.\nExample: Crit Rating at least 3\nProperty #372");
		F("Ratings", "Crit Resist Rating", "int", 373, null, null, null, "retail ratings - for ILT mods use ILT Custom Mods", null, null, null, "A retail rating on the item (Crit Resist). Counts toward Total Ratings. ILT modifier lines are text, not this number - use ILT Custom Mods for those.\nExample: Crit Resist Rating at least 3\nProperty #373");
		F("Ratings", "Healing Boost Rating", "int", 376, null, null, null, "retail ratings - for ILT mods use ILT Custom Mods", null, null, null, "A retail rating on the item (Healing Boost). Counts toward Total Ratings. ILT modifier lines are text, not this number - use ILT Custom Mods for those.\nExample: Healing Boost Rating at least 3\nProperty #376");
		F("Ratings", "Vitality Rating (Max Health)", "int", 379, null, null, null, "retail ratings - for ILT mods use ILT Custom Mods", null, null, null, "A retail rating on the item (Vitality). Counts toward Total Ratings. ILT modifier lines are text, not this number - use ILT Custom Mods for those.\nExample: Vitality Rating (Max Health) at least 3\nProperty #379");
		F("Ratings", "Nether Resist Rating", "int", 377, null, null, "new", "retail gear rating", null, null, null, "A retail rating on the item (Nether Resist). ILT modifier lines are text, not this number - use ILT Custom Mods for those.\nExample: Nether Resist Rating at least 3\nProperty #377\nNew: retail, but missing from the Virindi loot editor.");
		F("Ratings", "Life Resist Rating", "int", 378, null, null, "new", "retail gear rating", null, null, null, "A retail rating on the item (Life Resist). ILT modifier lines are text, not this number - use ILT Custom Mods for those.\nExample: Life Resist Rating at least 3\nProperty #378\nNew: retail, but missing from the Virindi loot editor.");
		F("Ratings", "Overpower Rating", "int", 388, null, null, "new", "retail gear rating", null, null, null, "A retail rating on the item (Overpower). ILT modifier lines are text, not this number - use ILT Custom Mods for those.\nExample: Overpower Rating at least 3\nProperty #388\nNew: retail, but missing from the Virindi loot editor.");
		F("Ratings", "Overpower Resist Rating", "int", 389, null, null, "new", "retail gear rating", null, null, null, "A retail rating on the item (Overpower Resist). ILT modifier lines are text, not this number - use ILT Custom Mods for those.\nExample: Overpower Resist Rating at least 3\nProperty #389\nNew: retail, but missing from the Virindi loot editor.");
		F("Weapon", "Max Damage", "int", 218103842, null, null, null, null, null, null, null, "The weapon's top damage, before its own spells.\nExample: Max Damage at least 80\nProperty #218103842");
		F("Weapon", "Min Damage", "calc", null, null, null, null, null, "10", null, null, "The weapon's lowest damage: max damage minus its variance.\nExample: Min Damage at least 40\nCalculated by VTank from the item.");
		F("Weapon", "Buffed Median Damage", "calc", null, null, null, null, null, "2000", null, null, "Halfway between min and max damage, with the weapon's own spells (Blood Drinker cantrips) counted.\nExample: Buffed Median Damage at least 60\nCalculated by VTank from the item.");
		F("Weapon", "Buffed Missile Damage", "calc", null, null, null, null, null, "2001", null, null, "For launchers: max damage plus the damage modifier and elemental bonus, with the launcher's own spells counted.\nExample: Buffed Missile Damage at least 90\nCalculated by VTank from the item.");
		F("Weapon", "Calculated Buffed Tinked Damage", "calc", null, null, null, null, null, "2006", null, null, "VTank's estimate of the weapon's damage after its remaining tinks (iron and granite), with its own spells. For judging unfinished weapons.\nExample: Calculated Buffed Tinked Damage at least 50\nCalculated by VTank from the item.");
		F("Weapon", "Speed", "int", 218103839, null, null, null, null, null, null, null, "Weapon speed. Lower is faster.\nExample: Speed at most 30\nProperty #218103839");
		F("Weapon", "Damage Type", "int", 218103841, "dmgtype", new string[2] { "=", "flag" }, null, null, null, null, null, "The kind of damage the weapon does: slash, pierce, bludgeon, fire, cold, acid, electric, nether.\nExample: Damage Type is Fire\nProperty #218103841");
		F("Weapon", "Weapon Skill", "int", 218103840, "skill", new string[2] { "=", "!=" }, null, null, null, null, null, "The skill that wields it (Heavy Weapons, Missile Weapons, War Magic ...).\nExample: Weapon Skill is Heavy Weapons\nProperty #218103840");
		F("Weapon", "Weapon Mastery", "int", 353, "mastery", new string[2] { "=", "!=" }, null, null, null, null, null, "The weapon family: sword, axe, bow, two-handed ...\nExample: Weapon Mastery is Bow\nProperty #353");
		F("Weapon", "Attack Bonus", "dbl", 167772172, null, null, null, null, null, null, null, "Bonus to attack skill, as a multiplier: 1.20 is +20%.\nExample: Attack Bonus at least 1.15\nProperty #167772172 (decimal)");
		F("Weapon", "Melee Defense Bonus", "dbl", 29, null, null, null, null, null, null, null, "Bonus to melee defense while wielded: 1.20 is +20%.\nExample: Melee Defense Bonus at least 1.2\nProperty #29 (decimal)");
		F("Weapon", "Missile Defense Bonus", "dbl", 149, null, null, null, null, null, null, null, "Bonus to missile defense while wielded: 1.10 is +10%.\nExample: Missile Defense Bonus at least 1.05\nProperty #149 (decimal)");
		F("Weapon", "Magic Defense Bonus", "dbl", 150, null, null, null, null, null, null, null, "Bonus to magic defense while wielded: 1.10 is +10%.\nExample: Magic Defense Bonus at least 1.05\nProperty #150 (decimal)");
		F("Weapon", "Mana Conversion Bonus", "dbl", 144, null, null, null, null, null, null, null, "Wands, staves and orbs: bonus to mana conversion.\nExample: Mana Conversion Bonus at least 1.1\nProperty #144 (decimal)");
		F("Weapon", "Elemental Damage vs Monsters", "dbl", 152, null, null, null, null, null, null, null, "Wands, staves and orbs: extra war / void damage against monsters. 1.10 is +10%.\nExample: Elemental Damage vs Monsters at least 1.12\nProperty #152 (decimal)");
		F("Weapon", "Damage Bonus", "dbl", 167772174, null, null, null, null, null, null, null, "The weapon's damage multiplier value as VTank reads it (launchers: their damage modifier).\nExample: Damage Bonus at least 2\nProperty #167772174 (decimal)");
		F("Weapon", "Imbues", "int", 179, "imbue", new string[3] { "flag", "=", "!=" }, null, "rends, armor rending, crushing...", null, null, null, "The weapon's imbues: element rends, armor rending, crushing blow, biting strike, defense imbues. \"includes\" matches when that imbue is on it.\nExample: Imbues includes Fire Rending\nProperty #179");
		F("Weapon", "Damage Modifier", "dbl", 63, null, null, "new", "bows, crossbows, atlatls", null, null, null, "Bows, crossbows and atlatls: the launcher's damage modifier. 2.20 is +120%.\nExample: Damage Modifier at least 2\nProperty #63 (decimal)\nNew: retail, but missing from the Virindi loot editor.");
		F("Weapon", "Attack Type", "int", 47, "attack", new string[2] { "flag", "=" }, "new", "multi-strike, thrust, slash", null, null, null, "How the weapon swings: thrust, slash, or a multi-strike (double / triple).\nExample: Attack Type includes Multi-strike (any)\nProperty #47\nNew: retail, but missing from the Virindi loot editor.");
		F("Weapon", "Cleave Targets", "int", 292, null, null, "new", null, null, null, null, "Retail cleaving: how many extra enemies each swing hits.\nExample: Cleave Targets at least 1\nProperty #292\nNew: retail, but missing from the Virindi loot editor.");
		F("Weapon", "Resistance Cleaving Element", "int", 263, "dmgtype", new string[2] { "=", "!=" }, "new", null, null, null, null, "The element whose resistance the weapon cuts through.\nExample: Resistance Cleaving Element is Fire\nProperty #263\nNew: retail, but missing from the Virindi loot editor.");
		F("Weapon", "Resistance Cleaving Amount", "dbl", 157, null, null, "new", null, null, null, null, "How much of that element's resistance it cuts through.\nExample: Resistance Cleaving Amount at least 1\nProperty #157 (decimal)\nNew: retail, but missing from the Virindi loot editor.");
		F("Weapon", "Armor Ignored (Armor Rending)", "dbl", 155, null, null, "new", "0 to 1", null, null, null, "The share of the target's armor the weapon ignores, 0 to 1.\nExample: Armor Ignored at least 0.2\nProperty #155 (decimal)\nNew: retail, but missing from the Virindi loot editor.");
		F("Armor", "Armor Level", "int", 28, null, null, null, null, null, null, null, "The armor's protection value.\nExample: Armor Level at least 500\nProperty #28");
		F("Armor", "Magic Absorb", "dbl", 159, null, null, "new", "shields", null, null, null, "Shields: the share of magic damage absorbed. The server shows it as exactly 1 when the shield has any, so test at least 1.\nExample: Magic Absorb at least 1\nProperty #159 (decimal)\nNew: retail, but missing from the Virindi loot editor.");
		F("Armor", "Slash Protection", "dbl", 167772160, null, null, null, null, null, null, null, "How well the armor stops slash damage, as a multiplier: 1.0 is average, higher is better.\nExample: Slash Protection at least 1.2\nProperty #167772160 (decimal)");
		F("Armor", "Pierce Protection", "dbl", 167772161, null, null, null, null, null, null, null, "How well the armor stops pierce damage, as a multiplier: 1.0 is average, higher is better.\nExample: Pierce Protection at least 1.2\nProperty #167772161 (decimal)");
		F("Armor", "Bludgeon Protection", "dbl", 167772162, null, null, null, null, null, null, null, "How well the armor stops bludgeon damage, as a multiplier: 1.0 is average, higher is better.\nExample: Bludgeon Protection at least 1.2\nProperty #167772162 (decimal)");
		F("Armor", "Acid Protection", "dbl", 167772163, null, null, null, null, null, null, null, "How well the armor stops acid damage, as a multiplier: 1.0 is average, higher is better.\nExample: Acid Protection at least 1.2\nProperty #167772163 (decimal)");
		F("Armor", "Lightning Protection", "dbl", 167772164, null, null, null, null, null, null, null, "How well the armor stops lightning damage, as a multiplier: 1.0 is average, higher is better.\nExample: Lightning Protection at least 1.2\nProperty #167772164 (decimal)");
		F("Armor", "Fire Protection", "dbl", 167772165, null, null, null, null, null, null, null, "How well the armor stops fire damage, as a multiplier: 1.0 is average, higher is better.\nExample: Fire Protection at least 1.2\nProperty #167772165 (decimal)");
		F("Armor", "Cold Protection", "dbl", 167772166, null, null, null, null, null, null, null, "How well the armor stops cold damage, as a multiplier: 1.0 is average, higher is better.\nExample: Cold Protection at least 1.2\nProperty #167772166 (decimal)");
		F("Armor", "Armor Set", "int", 265, null, new string[2] { "=", "!=" }, null, null, null, null, null, "The armor set the piece belongs to (set bonus number).\nExample: Armor Set is 13\nProperty #265");
		F("Armor", "Coverage", "int", 218103821, "slot", new string[2] { "flag", "=" }, null, null, null, null, null, "The body parts the armor covers. \"includes\" matches pieces that cover that part.\nExample: Coverage includes Chest\nProperty #218103821");
		F("Armor", "Heritage Armor", "int", 324, "heritage", new string[2] { "=", "!=" }, "new", null, null, null, null, "Heritage-only armor: the heritage group that can wear it.\nExample: Heritage Armor is Viamontian\nProperty #324\nNew: retail, but missing from the Virindi loot editor.");
		F("ILT Custom Mods", "Spell Armor Rend", "t11", null, null, null, "ilt", "weapon, wands", null, "spellrend", null, "Weapon card: the target's spell armor the weapon's spells ignore. Line: \"Spell Armor Rend: 9% Spell Armor Ignored\".\nExample: at least 8\nRead from the item text: the Description (#16) under \"Property Details:\".\nILT Custom content.");
		F("ILT Custom Mods", "Weapon Grade", "int", 9060, "grade", null, "ilt", "S A B C D F", null, null, null, "How well the T11+ weapon rolled, 0 to 1000: S 1000, A 900+, B 800+, C 650+, D 500+, F below. Shown on the weapon as \"Weapon Grade: B\".\nExample: Weapon Grade at least B\nProperty #9060\nILT Custom content.");
		F("ILT Custom Mods", "Weapon Tier", "int", 9061, null, null, "ilt", null, null, null, null, "The tier the T11+ weapon dropped for (11, 12 ...).\nExample: Weapon Tier at least 12\nProperty #9061\nILT Custom content.");
		F("ILT Custom Mods", "Gear Tier", "int", 50109, null, null, "ilt", "armor, jewelry", null, null, null, "The tier a T11+ armor or jewelry piece dropped for (11, 12 ...).\nExample: Gear Tier at least 11\nProperty #50109\nILT Custom content.");
		F("ILT Custom Mods", "Biting Strike", "t11", null, null, null, "ilt", "weapon", null, "biting", null, "Weapon card: extra critical hit chance. Line: \"Biting Strike: +33% Crit Chance\".\nExample: at least 30\nRead from the item text: the Description (#16) under \"Property Details:\".\nILT Custom content.");
		F("ILT Custom Mods", "Crushing Blow", "t11", null, null, null, "ilt", "weapon", null, "crush", null, "Weapon card: bigger critical hits. Line: \"Crushing Blow: 3.86x Crit Dmg\".\nExample: at least 3.5\nRead from the item text: the Description (#16) under \"Property Details:\".\nILT Custom content.");
		F("ILT Custom Mods", "Rending", "t11", null, null, null, "ilt", "weapon", null, "rend", null, "Weapon card: extra damage of one element. Line: \"Fire Rending: +165% Dmg\". Pick the element, or any.\nExample: at least 150, element Fire\nRead from the item text: the Description (#16) under \"Property Details:\".\nILT Custom content.");
		F("ILT Custom Mods", "Slayer", "t11", null, null, null, "ilt", "weapon", null, "slayer", null, "Weapon card: extra damage against one creature species. Line: \"Human Slayer: 1.87x Damage\". A slayer drop is tied to the species that dropped it.\nExample: at least 1.5, slayer of Human\nRead from the item text: the Description (#16) under \"Property Details:\".\nILT Custom content.");
		F("ILT Custom Mods", "Cleaving", "t11", null, null, null, "ilt", "weapon", null, "cleave", null, "Weapon card: hits extra enemies each swing. Line: \"Cleaving: +2 Targets\".\nExample: at least 1\nRead from the item text: the Description (#16) under \"Property Details:\".\nILT Custom content.");
		F("ILT Custom Mods", "Armor Cleaving", "t11", null, null, null, "ilt", "weapon", null, "armorcl", null, "Weapon card: ignores part of the target's armor. Line: \"Armor Cleaving: 25%\".\nExample: at least 20\nRead from the item text: the Description (#16) under \"Property Details:\".\nILT Custom content.");
		F("ILT Custom Mods", "Shield Cleaving", "t11", null, null, null, "ilt", "weapon", null, "shieldcl", null, "Weapon card: ignores part of the target's shield. Line: \"Shield Cleaving: 25%\".\nExample: at least 20\nRead from the item text: the Description (#16) under \"Property Details:\".\nILT Custom content.");
		F("ILT Custom Mods", "Split Arrow", "t11", null, null, null, "ilt", "weapon", null, "split", null, "Bow card: arrows split to hit extra enemies. Line: \"Split Arrow: +2 Targets\".\nExample: at least 1\nRead from the item text: the Description (#16) under \"Property Details:\".\nILT Custom content.");
		F("ILT Custom Mods", "Cast on Strike", "t11", null, null, null, "ilt", "weapon", null, "proc", null, "Weapon card: casts a spell when it hits. Line: \"Cast on Strike: Nether Arc (18% proc chance)\". Leave the spell empty for any.\nExample: Nether Arc\nRead from the item text: the Description (#16) under \"Property Details:\".\nILT Custom content.");
		F("ILT Custom Mods", "Split Arrow Count", "int", 9031, null, null, "ilt", "bows, number", null, null, null, "Bows: how many extra enemies the split arrows hit (the number behind the Split Arrow card).\nExample: Split Arrow Count at least 2\nProperty #9031\nILT Custom content.");
		F("ILT Custom Mods", "Split Arrow Range", "dbl", 9032, null, null, "ilt", "bows", null, null, null, "Bows: how far from the target the split arrows reach.\nExample: Split Arrow Range at least 5\nProperty #9032 (decimal)\nILT Custom content.");
		F("ILT Custom Mods", "Split Arrow Damage", "dbl", 9033, null, null, "ilt", "bows, 0 to 1", null, null, null, "Bows: how much damage the split arrows do, 0 to 1 of a normal hit.\nExample: Split Arrow Damage at least 0.5\nProperty #9033 (decimal)\nILT Custom content.");
		F("ILT Custom Mods", "Damage Rating", "t11", null, null, null, "ilt", "modifier", null, "mod", 28, "Armor / jewelry / shield modifier: more damage dealt. Line: \"Damage Rating +69 [14-69]\". Rolls 14-69.\nExample: at least 14\nRead from the item text: the Use text (#14) under \"Modifiers:\".\nILT Custom content.");
		F("ILT Custom Mods", "Crit Damage Rating", "t11", null, null, null, "ilt", "modifier", null, "mod", 29, "Armor / jewelry / shield modifier: bigger critical hits. Line: \"Crit Damage Rating +69 [14-69]\". Rolls 14-69.\nExample: at least 14\nRead from the item text: the Use text (#14) under \"Modifiers:\".\nILT Custom content.");
		F("ILT Custom Mods", "Max Health", "t11", null, null, null, "ilt", "modifier", null, "mod", 19, "Armor / jewelry / shield modifier: more max health. Line: \"Max Health +69 [14-69]\". Rolls 14-69.\nExample: at least 14\nRead from the item text: the Use text (#14) under \"Modifiers:\".\nILT Custom content.");
		F("ILT Custom Mods", "Max Health Pct", "t11", null, null, null, "ilt", "modifier", null, "mod", 47, "Armor / jewelry / shield modifier: more max health, as a percent. Line: \"Max Health Pct +3% [1-3]\". Rolls 1-3.\nExample: at least 1\nRead from the item text: the Use text (#14) under \"Modifiers:\".\nILT Custom content.");
		F("ILT Custom Mods", "All Attributes", "t11", null, null, null, "ilt", "modifier", null, "mod", 43, "Armor / jewelry / shield modifier: raises all six attributes. Line: \"All Attributes +69 [14-69]\". Rolls 14-69.\nExample: at least 14\nRead from the item text: the Use text (#14) under \"Modifiers:\".\nILT Custom content.");
		F("ILT Custom Mods", "Crit Chance", "t11", null, null, null, "ilt", "modifier", null, "mod", 33, "Armor / jewelry / shield modifier: more critical hit chance. Line: \"Crit Chance +3 [1-3]\". Rolls 1-3.\nExample: at least 1\nRead from the item text: the Use text (#14) under \"Modifiers:\".\nILT Custom content.");
		F("ILT Custom Mods", "Healing Boost", "t11", null, null, null, "ilt", "modifier", null, "mod", 31, "Armor / jewelry / shield modifier: stronger heals. Line: \"Healing Boost +69 [14-69]\". Rolls 14-69.\nExample: at least 14\nRead from the item text: the Use text (#14) under \"Modifiers:\".\nILT Custom content.");
		F("ILT Custom Mods", "Spell Duration", "t11", null, null, null, "ilt", "modifier", null, "mod", 32, "Armor / jewelry / shield modifier: longer spell durations. Line: \"Spell Duration +3 lvl [1-3]\". Rolls 1-3.\nExample: at least 1\nRead from the item text: the Use text (#14) under \"Modifiers:\".\nILT Custom content.");
		F("ILT Custom Mods", "Life on Hit", "t11", null, null, null, "ilt", "modifier", null, "mod", 48, "Armor / jewelry / shield modifier: heals you for part of your health on each hit. Line: \"Life on Hit 3% HP per hit [1-3]\". Rolls 1-3.\nExample: at least 1\nRead from the item text: the Use text (#14) under \"Modifiers:\".\nILT Custom content.");
		F("ILT Custom Mods", "Armor Level", "t11", null, null, null, "ilt", "modifier", null, "mod", 25, "Armor / jewelry / shield modifier: more armor. Line: \"Armor Level +250 [50-250]\". Rolls 50-250.\nExample: at least 50\nRead from the item text: the Use text (#14) under \"Modifiers:\".\nILT Custom content.");
		F("ILT Custom Mods", "Reinforced", "t11", null, null, null, "ilt", "modifier", null, "mod", 49, "Armor / jewelry / shield modifier: raises the armor's protection rank (Superior / Excellent / Unparalleled). Line: \"Reinforced +3 [1-3]\". Rolls 1-3.\nExample: at least 1\nRead from the item text: the Use text (#14) under \"Modifiers:\".\nILT Custom content.");
		F("ILT Custom Mods", "Damage Resist", "t11", null, null, null, "ilt", "modifier", null, "mod", 50, "Armor / jewelry / shield modifier: less damage taken. Line: \"Damage Resist +69 [35-69]\". Rolls 35-69.\nExample: at least 35\nRead from the item text: the Use text (#14) under \"Modifiers:\".\nILT Custom content.");
		F("ILT Custom Mods", "Crit Damage Resist", "t11", null, null, null, "ilt", "modifier", null, "mod", 51, "Armor / jewelry / shield modifier: smaller critical hits taken. Line: \"Crit Damage Resist +42 [21-42]\". Rolls 21-42.\nExample: at least 21\nRead from the item text: the Use text (#14) under \"Modifiers:\".\nILT Custom content.");
		F("ILT Custom Mods", "Crit Resist", "t11", null, null, null, "ilt", "modifier", null, "mod", 52, "Armor / jewelry / shield modifier: fewer critical hits taken. Line: \"Crit Resist +42 [21-42]\". Rolls 21-42.\nExample: at least 21\nRead from the item text: the Use text (#14) under \"Modifiers:\".\nILT Custom content.");
		F("ILT Custom Mods", "Nether Resist", "t11", null, null, null, "ilt", "modifier", null, "mod", 53, "Armor / jewelry / shield modifier: less nether damage taken. Line: \"Nether Resist +42 [21-42]\". Rolls 21-42.\nExample: at least 21\nRead from the item text: the Use text (#14) under \"Modifiers:\".\nILT Custom content.");
		F("ILT Custom Mods", "Fortify Vitals", "t11", null, null, null, "ilt", "Helm special", null, "mod", 41, "Armor / jewelry / shield modifier: raises your max vitals by a percent. A Helm special. Line: \"Fortify Vitals +25% vitals [5-25]\". Rolls 5-25.\nExample: at least 5\nRead from the item text: the Use text (#14) under \"Modifiers:\".\nILT Custom content.");
		F("ILT Custom Mods", "Pct HP Damage", "t11", null, null, null, "ilt", "Gauntlets special", null, "mod", 44, "Armor / jewelry / shield modifier: hits also deal a share of the target's max health. A Gauntlets special.\nRead from the item text: the Use text (#14) under \"Modifiers:\".\nILT Custom content.");
		F("ILT Custom Mods", "Regeneration", "t11", null, null, null, "ilt", "Bracers special", null, "mod", 46, "Armor / jewelry / shield modifier: regenerates vitals each tick. A Bracers special. Line: \"Regeneration +5% per tick [1-5]\". Rolls 1-5.\nExample: at least 1\nRead from the item text: the Use text (#14) under \"Modifiers:\".\nILT Custom content.");
		F("ILT Custom Mods", "Battle Mending", "t11", null, null, null, "ilt", "Chest special", null, "mod", 42, "Armor / jewelry / shield modifier: below 25% health it heals you to full, 60 s cooldown. A Chest special. On or off - it has no number.\nRead from the item text: the Use text (#14) under \"Modifiers:\".\nILT Custom content.");
		F("ILT Custom Mods", "Cheat Death", "t11", null, null, null, "ilt", "Boots special", null, "mod", 45, "Armor / jewelry / shield modifier: a killing blow leaves you at 1 HP with 5 s of immunity, 10 min cooldown. A Boots special. On or off - it has no number.\nRead from the item text: the Use text (#14) under \"Modifiers:\".\nILT Custom content.");
		F("ILT Custom Mods", "Gear Grade", "t11", null, null, null, "ilt", "armor, jewelry, cloaks, shields", null, "gear", null, "How well T11+ armor, jewelry, cloaks and shields rolled: F (worst), D, C, B, A, S (best), with + / - in between. Line: \"Gear Grade: C+\".\nExample: Gear Grade at least B (takes B-, B, B+, A-, A, A+, S...)\nRead from the item text: the Use text (#14).\nILT Custom content.");
		F("ILT Custom Mods", "Number of Modifier Lines", "t11", null, null, null, "ilt", null, null, "modcount", null, "How many lines the T11+ armor, jewelry or shield has under \"Modifiers:\".\nExample: at least 6\nRead from the item text: the Use text (#14) under \"Modifiers:\".\nILT Custom content.");
		F("ILT Custom Mods", "Wield Requirement 3: Counter", "int", 274, "charm", new string[2] { "=", "!=" }, "ilt", "T16+ charm gate", null, null, null, "T16+ gear: the charm counter you need to wield it (Triune Weave, Nether Veil ...).\nExample: is Triune Weave\nProperty #274\nILT Custom content.");
		F("ILT Custom Mods", "Wield Requirement 3: Amount", "int", 275, null, null, "ilt", "T16+ charm gate", null, null, null, "T16+ gear: how much of that charm counter you need.\nExample: at most 3\nProperty #275\nILT Custom content.");
		F("ILT Custom Mods", "Wield Requirement 4: Counter", "int", 277, "charm", new string[2] { "=", "!=" }, "ilt", "T16+ charm gate", null, null, null, "T16+ gear: a second charm counter you need to wield it.\nExample: is Nether Veil\nProperty #277\nILT Custom content.");
		F("ILT Custom Mods", "Wield Requirement 4: Amount", "int", 278, null, null, "ilt", "T16+ charm gate", null, null, null, "T16+ gear: how much of the second charm counter you need.\nExample: at most 3\nProperty #278\nILT Custom content.");
		F("ILT Custom Pets", "Pet Bond Level", "int", 9053, null, null, "ilt", "pet essence", null, null, null, "A stat on an ILT combat pet essence: Bond Level.\nExample: Pet Bond Level at least 1\nProperty #9053\nILT Custom content.");
		F("ILT Custom Pets", "Pet Potency Stored", "int", 9056, null, null, "ilt", "pet essence", null, null, null, "A stat on an ILT combat pet essence: Potency Stored.\nExample: Pet Potency Stored at least 1\nProperty #9056\nILT Custom content.");
		F("ILT Custom Pets", "Pet Breeding Charges", "int", 9057, null, null, "ilt", "pet essence", null, null, null, "A stat on an ILT combat pet essence: Breeding Charges.\nExample: Pet Breeding Charges at least 1\nProperty #9057\nILT Custom content.");
		F("ILT Custom Pets", "Pet Vitality Rating", "int", 9058, null, null, "ilt", "pet essence", null, null, null, "A stat on an ILT combat pet essence: Vitality Rating.\nExample: Pet Vitality Rating at least 1\nProperty #9058\nILT Custom content.");
		F("ILT Custom Pets", "Pet Mutations (Total)", "int", 9075, null, null, "ilt", "pet essence", null, null, null, "A stat on an ILT combat pet essence: Mutations (Total).\nExample: Pet Mutations (Total) at least 1\nProperty #9075\nILT Custom content.");
		F("ILT Custom Pets", "Pet Damage Mutations", "int", 9070, null, null, "ilt", "pet essence", null, null, null, "A stat on an ILT combat pet essence: Damage Mutations.\nExample: Pet Damage Mutations at least 1\nProperty #9070\nILT Custom content.");
		F("ILT Custom Pets", "Pet Damage Resist Mutations", "int", 9071, null, null, "ilt", "pet essence", null, null, null, "A stat on an ILT combat pet essence: Damage Resist Mutations.\nExample: Pet Damage Resist Mutations at least 1\nProperty #9071\nILT Custom content.");
		F("ILT Custom Pets", "Pet Crit Mutations", "int", 9072, null, null, "ilt", "pet essence", null, null, null, "A stat on an ILT combat pet essence: Crit Mutations.\nExample: Pet Crit Mutations at least 1\nProperty #9072\nILT Custom content.");
		F("ILT Custom Pets", "Pet Vitality Mutations", "int", 9073, null, null, "ilt", "pet essence", null, null, null, "A stat on an ILT combat pet essence: Vitality Mutations.\nExample: Pet Vitality Mutations at least 1\nProperty #9073\nILT Custom content.");
		F("ILT Custom Pets", "Pet Potency Mutations", "int", 9074, null, null, "ilt", "pet essence", null, null, null, "A stat on an ILT combat pet essence: Potency Mutations.\nExample: Pet Potency Mutations at least 1\nProperty #9074\nILT Custom content.");
		F("ILT Custom Pets", "Pet Maturity Kills", "int", 9077, null, null, "ilt", "pet essence", null, null, null, "A stat on an ILT combat pet essence: Maturity Kills.\nExample: Pet Maturity Kills at least 1\nProperty #9077\nILT Custom content.");
		F("ILT Custom Pets", "Pet Last Mutated Stat", "int", 9078, "petstat", null, "ilt", "pet essence", null, null, null, "A stat on an ILT combat pet essence: Last Mutated Stat.\nExample: Pet Last Mutated Stat at least 1\nProperty #9078\nILT Custom content.");
		F("Character", "Character Level", "charlvl", null, null, null, null, null, null, null, null, "Your character, not the item: only true while your level is in range. Use it to change what you loot as you level.\nExample: Character Level at least 275\nChecks your character, not the item.");
		F("Character", "Character Skill", "charskill", null, null, null, null, null, null, null, null, "Your character's buffed skill, not the item.\nExample: Salvaging at least 400\nChecks your character, not the item.");
		F("Character", "Character Base Skill", "charbase", null, null, null, null, null, null, null, null, "Your character's unbuffed skill between two values, not the item.\nExample: Salvaging from 300 to 500\nChecks your character, not the item.");
		F("Character", "Main Pack Empty Slots", "packslots", null, null, null, null, null, null, null, null, "Free slots in your main pack. Stops looting junk when you are nearly full.\nExample: Main Pack Empty Slots at least 5\nChecks your character, not the item.");
		F("Advanced", "Any Number Property", "int", null, null, null, null, "pick by name or number", null, null, null, "Armor Level: Any number the server sends about an item, picked by name or number. For things not in the lists above.\nProperty #28");
		F("Advanced", "Any Decimal Property", "dbl", null, null, null, null, null, null, null, null, "Magic Absorb: Any decimal number the server sends about an item, picked by name or number. Magic absorb. The server shows it as exactly 1 when the item has any - test >= 1.\nProperty #159 (decimal)");
		F("Advanced", "Any Text Property", "str", null, null, null, null, null, null, null, null, "Description: Any text the server sends about an item (name, description, use text ...), matched with a pattern. Long description. On T11 WEAPONS it holds the 'Property Details:' block (grade, cards, modifiers).\nProperty #16 (text)");
		F("Advanced", "Any Similar Color", "raw", null, null, null, null, null, "14", null, null, "An advanced VTClassic requirement: Any similar color. Kept exactly as VTank wrote it.");
		F("Advanced", "Similar Color on Armor Type", "raw", null, null, null, null, null, "15", null, null, "An advanced VTClassic requirement: Similar color on armor type. Kept exactly as VTank wrote it.");
		F("Advanced", "Slot Has Similar Color", "raw", null, null, null, null, null, "16", null, null, "An advanced VTClassic requirement: Slot has similar color. Kept exactly as VTank wrote it.");
		F("Advanced", "Slot Has Exact Palette", "raw", null, null, null, null, null, "17", null, null, "An advanced VTClassic requirement: Slot has exact palette. Kept exactly as VTank wrote it.");
		F("Advanced", "Buffed Number Property >=", "raw", null, null, null, null, null, "2003", null, null, "An advanced VTClassic requirement: Buffed number property >=. Kept exactly as VTank wrote it.");
		F("Advanced", "Buffed Decimal Property >=", "raw", null, null, null, null, null, "2005", null, null, "An advanced VTClassic requirement: Buffed decimal property >=. Kept exactly as VTank wrote it.");
		F("Advanced", "Buffed Tinked Target Melee", "raw", null, null, null, null, null, "2008", null, null, "An advanced VTClassic requirement: Buffed tinked target melee. Kept exactly as VTank wrote it.");
	}

	private static void InitCatalog()
	{
		P("int", 0, "Undef", "", pick: false, 0, "", "");
		P("int", 1, "Item Type", "", pick: false, 0, "", "");
		P("int", 2, "Species", "", pick: false, 1, "", "");
		P("int", 3, "Palette Template", "", pick: false, 0, "", "");
		P("int", 4, "Clothing Priority", "", pick: false, 0, "", "");
		P("int", 5, "Burden", "Item", pick: true, 1, "", "");
		P("int", 6, "Items Capacity", "", pick: false, 0, "", "");
		P("int", 7, "Containers Capacity", "", pick: false, 0, "", "");
		P("int", 8, "Mass", "", pick: false, 0, "", "");
		P("int", 9, "Valid Locations", "", pick: false, 0, "", "");
		P("int", 10, "Equipped Slots", "", pick: false, 1, "", "");
		P("int", 11, "Max Stack Size", "", pick: false, 0, "", "");
		P("int", 12, "Stack Size", "", pick: false, 0, "", "");
		P("int", 13, "Stack Unit Encumbrance", "", pick: false, 0, "", "");
		P("int", 14, "Stack Unit Mass", "", pick: false, 0, "", "");
		P("int", 15, "Stack Unit Value", "", pick: false, 0, "", "");
		P("int", 16, "Item Useable", "", pick: false, 0, "", "");
		P("int", 17, "Rare Id", "Item", pick: true, 1, "", "");
		P("int", 18, "Ui Effects", "", pick: false, 0, "", "");
		P("int", 19, "Value", "Item", pick: true, 1, "", "");
		P("int", 20, "Total Value", "", pick: false, 0, "", "");
		P("int", 21, "Total Experience", "", pick: false, 0, "", "");
		P("int", 22, "Available Character", "", pick: false, 0, "", "");
		P("int", 23, "Total Skill Credits", "", pick: false, 0, "", "");
		P("int", 24, "Skill Credits Avail", "", pick: false, 0, "", "");
		P("int", 25, "Creature Level", "", pick: false, 1, "", "");
		P("int", 26, "Restricted To To D", "", pick: false, 0, "", "");
		P("int", 27, "Armor Type", "", pick: false, 0, "", "");
		P("int", 28, "Armor Level", "Armor", pick: true, 1, "", "");
		P("int", 29, "Allegiance Cp Pool", "", pick: false, 0, "", "");
		P("int", 30, "Rank", "", pick: false, 1, "", "");
		P("int", 31, "Channels Allowed", "", pick: false, 0, "", "");
		P("int", 32, "Channels Active", "", pick: false, 0, "", "");
		P("int", 33, "Bonded", "Item", pick: true, 1, "", "");
		P("int", 34, "Monarchs Rank", "", pick: false, 0, "", "");
		P("int", 35, "Number Followers", "", pick: false, 1, "", "");
		P("int", 36, "Unenchantable", "Item", pick: true, 1, "", "");
		P("int", 37, "Resist Item Appraisal", "", pick: false, 0, "", "");
		P("int", 38, "Lockpick Difficulty", "", pick: false, 1, "", "");
		P("int", 39, "Deprecated Resist Repair", "", pick: false, 0, "", "");
		P("int", 40, "Combat Mode", "", pick: false, 0, "", "");
		P("int", 41, "Current Attack Height", "", pick: false, 0, "", "");
		P("int", 42, "Combat Collisions", "", pick: false, 0, "", "");
		P("int", 43, "Deaths", "", pick: false, 1, "", "");
		P("int", 44, "Damage", "", pick: false, 0, "", "");
		P("int", 45, "Wand Elem Dmg Type", "Weapon", pick: true, 1, "", "");
		P("int", 46, "Default Combat Style", "", pick: false, 0, "", "");
		P("int", 47, "Attack Type", "Weapon", pick: true, 1, "", "new");
		P("int", 48, "Weapon Skill", "", pick: false, 0, "", "");
		P("int", 49, "Weapon Time", "", pick: false, 0, "", "");
		P("int", 50, "Ammo Type", "", pick: false, 0, "", "");
		P("int", 51, "Combat Use", "", pick: false, 0, "", "");
		P("int", 52, "Parent Location", "", pick: false, 0, "", "");
		P("int", 53, "Placement Position", "", pick: false, 0, "", "");
		P("int", 54, "Weapon Encumbrance", "", pick: false, 0, "", "");
		P("int", 55, "Weapon Mass", "", pick: false, 0, "", "");
		P("int", 56, "Shield Value", "", pick: false, 0, "", "");
		P("int", 57, "Shield Encumbrance", "", pick: false, 0, "", "");
		P("int", 58, "Missile Inventory Location", "", pick: false, 0, "", "");
		P("int", 59, "Full Damage Type", "", pick: false, 0, "", "");
		P("int", 60, "Weapon Range", "", pick: false, 0, "", "");
		P("int", 61, "Attackers Skill", "", pick: false, 0, "", "");
		P("int", 62, "Defenders Skill", "", pick: false, 0, "", "");
		P("int", 63, "Attackers Skill Value", "", pick: false, 0, "", "");
		P("int", 64, "Attackers Class", "", pick: false, 0, "", "");
		P("int", 65, "Placement", "", pick: false, 0, "", "");
		P("int", 66, "Checkpoint Status", "", pick: false, 0, "", "");
		P("int", 67, "Tolerance", "", pick: false, 0, "", "");
		P("int", 68, "Targeting Tactic", "", pick: false, 0, "", "");
		P("int", 69, "Combat Tactic", "", pick: false, 0, "", "");
		P("int", 70, "Homesick Targeting Tactic", "", pick: false, 0, "", "");
		P("int", 71, "Num Follow Failures", "", pick: false, 0, "", "");
		P("int", 72, "Friend Type", "", pick: false, 0, "", "");
		P("int", 73, "Foe Type", "", pick: false, 0, "", "");
		P("int", 74, "Merchandise Item Types", "", pick: false, 0, "", "");
		P("int", 75, "Merchandise Min Value", "", pick: false, 0, "", "");
		P("int", 76, "Merchandise Max Value", "", pick: false, 0, "", "");
		P("int", 77, "Num Items Sold", "", pick: false, 0, "", "");
		P("int", 78, "Num Items Bought", "", pick: false, 0, "", "");
		P("int", 79, "Money Income", "", pick: false, 0, "", "");
		P("int", 80, "Money Outflow", "", pick: false, 0, "", "");
		P("int", 81, "Max Generated Objects", "", pick: false, 0, "", "");
		P("int", 82, "Init Generated Objects", "", pick: false, 0, "", "");
		P("int", 83, "Activation Response", "", pick: false, 0, "", "");
		P("int", 84, "Original Value", "", pick: false, 0, "", "");
		P("int", 85, "Num Move Failures", "", pick: false, 0, "", "");
		P("int", 86, "Min Level Restrict", "Requirements", pick: true, 1, "", "");
		P("int", 87, "Max Level Restrict", "Requirements", pick: true, 1, "", "");
		P("int", 88, "Lockpick Skill Bonus", "", pick: false, 0, "", "");
		P("int", 89, "Affects Vital Id", "Consumables", pick: true, 1, "", "");
		P("int", 90, "Affects Vital Amt", "Consumables", pick: true, 1, "", "");
		P("int", 91, "Uses Total", "Consumables", pick: true, 1, "", "");
		P("int", 92, "Uses Remaining", "Consumables", pick: true, 1, "", "");
		P("int", 93, "Physics State", "", pick: false, 0, "", "");
		P("int", 94, "Target Type", "", pick: false, 0, "", "");
		P("int", 95, "Radar Blip Color", "", pick: false, 0, "", "");
		P("int", 96, "Encumbrance Capacity", "", pick: false, 0, "", "");
		P("int", 97, "Login Timestamp", "", pick: false, 0, "", "");
		P("int", 98, "Date Of Birth", "", pick: false, 1, "", "");
		P("int", 99, "Pk Level Modifier", "", pick: false, 0, "", "");
		P("int", 100, "Generator Type", "", pick: false, 0, "", "");
		P("int", 101, "Ai Allowed Combat Style", "", pick: false, 0, "", "");
		P("int", 102, "Logoff Timestamp", "", pick: false, 0, "", "");
		P("int", 103, "Generator Destruction Type", "", pick: false, 0, "", "");
		P("int", 104, "Activation Create Class", "", pick: false, 0, "", "");
		P("int", 105, "Workmanship", "Spells and mana", pick: true, 1, "", "");
		P("int", 106, "Spellcraft", "Spells and mana", pick: true, 1, "", "");
		P("int", 107, "Current Mana", "Spells and mana", pick: true, 1, "", "");
		P("int", 108, "Maximum Mana", "Spells and mana", pick: true, 1, "", "");
		P("int", 109, "Lore Requirement", "Requirements", pick: true, 1, "", "");
		P("int", 110, "Rank Requirement", "Requirements", pick: true, 1, "", "");
		P("int", 111, "Portal Restrictions", "", pick: false, 1, "", "");
		P("int", 112, "Advocate Level", "", pick: false, 0, "", "");
		P("int", 113, "Gender", "", pick: false, 1, "", "");
		P("int", 114, "Attuned", "Item", pick: true, 1, "", "");
		P("int", 115, "Skill Level Req", "Requirements", pick: true, 1, "", "");
		P("int", 116, "Gate Logic", "", pick: false, 0, "", "");
		P("int", 117, "Mana Cost", "Spells and mana", pick: true, 1, "", "");
		P("int", 118, "Logoff", "", pick: false, 0, "", "");
		P("int", 119, "Active", "", pick: false, 0, "", "");
		P("int", 120, "Attack Height", "", pick: false, 0, "", "");
		P("int", 121, "Num Attack Failures", "", pick: false, 0, "", "");
		P("int", 122, "Ai Cp Threshold", "", pick: false, 0, "", "");
		P("int", 123, "Ai Advancement Strategy", "", pick: false, 0, "", "");
		P("int", 124, "Version", "", pick: false, 0, "", "");
		P("int", 125, "Age", "", pick: false, 1, "", "");
		P("int", 126, "Vendor Happy Mean", "", pick: false, 0, "", "");
		P("int", 127, "Vendor Happy Variance", "", pick: false, 0, "", "");
		P("int", 128, "Cloak Status", "", pick: false, 0, "", "");
		P("int", 129, "XP For VP Reduction", "", pick: false, 0, "", "");
		P("int", 130, "Num Services Sold", "", pick: false, 0, "", "");
		P("int", 131, "Material", "Item", pick: true, 1, "", "");
		P("int", 132, "Num Allegiance Breaks", "", pick: false, 0, "", "");
		P("int", 133, "Showable On Radar", "", pick: false, 0, "", "");
		P("int", 134, "Player Killer Status", "", pick: false, 1, "", "");
		P("int", 135, "Vendor Happy Max Items", "", pick: false, 0, "", "");
		P("int", 136, "Score Page Num", "", pick: false, 0, "", "");
		P("int", 137, "Score Config Num", "", pick: false, 0, "", "");
		P("int", 138, "Score Num Scores", "", pick: false, 0, "", "");
		P("int", 139, "Death Level", "", pick: false, 0, "", "");
		P("int", 140, "Ai Options", "", pick: false, 0, "", "");
		P("int", 141, "Open To Everyone", "", pick: false, 0, "", "");
		P("int", 142, "Generator Time Type", "", pick: false, 0, "", "");
		P("int", 143, "Generator Start Time", "", pick: false, 0, "", "");
		P("int", 144, "Generator End Time", "", pick: false, 0, "", "");
		P("int", 145, "Generator End Destruction Type", "", pick: false, 0, "", "");
		P("int", 146, "Xp Override", "", pick: false, 0, "", "");
		P("int", 147, "Num Crash And Turns", "", pick: false, 0, "", "");
		P("int", 148, "Component Warning Threshold", "", pick: false, 0, "", "");
		P("int", 149, "House Status", "", pick: false, 0, "", "");
		P("int", 150, "Hook Placement", "", pick: false, 0, "", "");
		P("int", 151, "Hook Type", "", pick: false, 0, "", "");
		P("int", 152, "Hook Item Type", "", pick: false, 0, "", "");
		P("int", 153, "Ai Pp Threshold", "", pick: false, 0, "", "");
		P("int", 154, "Generator Version", "", pick: false, 0, "", "");
		P("int", 155, "House Type", "", pick: false, 0, "", "");
		P("int", 156, "Pickup Emote Offset", "", pick: false, 0, "", "");
		P("int", 157, "Weenie Iteration", "", pick: false, 0, "", "");
		P("int", 158, "Wield Req Type", "Requirements", pick: true, 1, "", "");
		P("int", 159, "Wield Req Attribute", "Requirements", pick: true, 1, "", "");
		P("int", 160, "Wield Req Value", "Requirements", pick: true, 1, "", "");
		P("int", 161, "House Max Hooks Usable", "", pick: false, 0, "", "");
		P("int", 162, "House Current Hooks Usable", "", pick: false, 0, "", "");
		P("int", 163, "Allegiance Min Level", "", pick: false, 0, "", "");
		P("int", 164, "Allegiance Max Level", "", pick: false, 0, "", "");
		P("int", 165, "House Relink Hook Count", "", pick: false, 0, "", "");
		P("int", 166, "Slayer Species", "Weapon", pick: true, 1, "Slayer species (retail slayers).", "");
		P("int", 167, "Cooldown Seconds", "", pick: false, 0, "", "");
		P("int", 168, "Confirmation Type In Progress", "", pick: false, 0, "", "");
		P("int", 169, "Tsys Mutation Data", "", pick: false, 0, "", "");
		P("int", 170, "Number Items Salvaged From", "Item", pick: true, 1, "", "");
		P("int", 171, "Number Times Tinkered", "Item", pick: true, 1, "", "");
		P("int", 172, "Description Format", "", pick: false, 1, "", "");
		P("int", 173, "Appraisal Lockpick Success Percent", "", pick: false, 1, "", "");
		P("int", 174, "Pages Used", "", pick: false, 1, "", "");
		P("int", 175, "Pages Total", "", pick: false, 1, "", "");
		P("int", 176, "Activation Req Skill Id", "Requirements", pick: true, 1, "", "");
		P("int", 177, "Gem Setting Qty", "Item", pick: true, 1, "", "");
		P("int", 178, "Gem Setting Type", "Item", pick: true, 1, "", "");
		P("int", 179, "Imbued", "Weapon", pick: true, 1, "Imbued effect flags (rends, crushing, biting ...).", "");
		P("int", 180, "Attackers Raw Skill Value", "", pick: false, 0, "", "");
		P("int", 181, "Chess Rank", "", pick: false, 1, "", "");
		P("int", 182, "Chess Total Games", "", pick: false, 0, "", "");
		P("int", 183, "Chess Games Won", "", pick: false, 0, "", "");
		P("int", 184, "Chess Games Lost", "", pick: false, 0, "", "");
		P("int", 185, "Type Of Alteration", "", pick: false, 0, "", "");
		P("int", 186, "Skill To Be Altered", "", pick: false, 0, "", "");
		P("int", 187, "Skill Alteration Count", "", pick: false, 0, "", "");
		P("int", 188, "Heritage", "Item", pick: true, 1, "", "");
		P("int", 189, "Transfer From Attribute", "", pick: false, 0, "", "");
		P("int", 190, "Transfer To Attribute", "", pick: false, 0, "", "");
		P("int", 191, "Attribute Transfer Count", "", pick: false, 0, "", "");
		P("int", 192, "Fishing Skill", "", pick: false, 1, "", "");
		P("int", 193, "Keys Held", "", pick: false, 1, "", "");
		P("int", 194, "Death Timestamp", "", pick: false, 0, "", "");
		P("int", 195, "Pk Timestamp", "", pick: false, 0, "", "");
		P("int", 196, "Victim Timestamp", "", pick: false, 0, "", "");
		P("int", 197, "Hook Group", "", pick: false, 0, "", "");
		P("int", 198, "Allegiance Swear Timestamp", "", pick: false, 0, "", "");
		P("int", 199, "House Purchase Timestamp", "", pick: false, 0, "", "");
		P("int", 200, "Redirectable Equipped Armor Count", "", pick: false, 0, "", "");
		P("int", 201, "Melee Defense Imbued Effect Type Cache", "", pick: false, 0, "", "");
		P("int", 202, "Missile Defense Imbued Effect Type Cache", "", pick: false, 0, "", "");
		P("int", 203, "Magic Defense Imbued Effect Type Cache", "", pick: false, 0, "", "");
		P("int", 204, "Elemental Dmg Bonus", "Weapon", pick: true, 1, "", "");
		P("int", 205, "Imbue Attempts", "", pick: false, 0, "", "");
		P("int", 206, "Imbue Successes", "", pick: false, 0, "", "");
		P("int", 207, "Creature Kills", "", pick: false, 0, "", "");
		P("int", 208, "Player Kills Pk", "", pick: false, 0, "", "");
		P("int", 209, "Player Kills Pkl", "", pick: false, 0, "", "");
		P("int", 210, "Rares Tier One", "", pick: false, 0, "", "");
		P("int", 211, "Rares Tier Two", "", pick: false, 0, "", "");
		P("int", 212, "Rares Tier Three", "", pick: false, 0, "", "");
		P("int", 213, "Rares Tier Four", "", pick: false, 0, "", "");
		P("int", 214, "Rares Tier Five", "", pick: false, 0, "", "");
		P("int", 215, "Augmentation Stat", "", pick: false, 0, "", "");
		P("int", 216, "Augmentation Family Stat", "", pick: false, 0, "", "");
		P("int", 217, "Augmentation Innate Family", "", pick: false, 0, "", "");
		P("int", 218, "Augmentation Innate Strength", "", pick: false, 0, "", "");
		P("int", 219, "Augmentation Innate Endurance", "", pick: false, 0, "", "");
		P("int", 220, "Augmentation Innate Coordination", "", pick: false, 0, "", "");
		P("int", 221, "Augmentation Innate Quickness", "", pick: false, 0, "", "");
		P("int", 222, "Augmentation Innate Focus", "", pick: false, 0, "", "");
		P("int", 223, "Augmentation Innate Self", "", pick: false, 0, "", "");
		P("int", 224, "Augmentation Specialize Salvaging", "", pick: false, 0, "", "");
		P("int", 225, "Augmentation Specialize Item Tinkering", "", pick: false, 0, "", "");
		P("int", 226, "Augmentation Specialize Armor Tinkering", "", pick: false, 0, "", "");
		P("int", 227, "Augmentation Specialize Magic Item Tinkering", "", pick: false, 0, "", "");
		P("int", 228, "Augmentation Specialize Weapon Tinkering", "", pick: false, 0, "", "");
		P("int", 229, "Augmentation Extra Pack Slot", "", pick: false, 0, "", "");
		P("int", 230, "Augmentation Increased Carrying Capacity", "", pick: false, 0, "", "");
		P("int", 231, "Augmentation Less Death Item Loss", "", pick: false, 0, "", "");
		P("int", 232, "Augmentation Spells Remain Past Death", "", pick: false, 0, "", "");
		P("int", 233, "Augmentation Critical Defense", "", pick: false, 0, "", "");
		P("int", 234, "Augmentation Bonus Xp", "", pick: false, 0, "", "");
		P("int", 235, "Augmentation Bonus Salvage", "", pick: false, 0, "", "");
		P("int", 236, "Augmentation Bonus Imbue Chance", "", pick: false, 0, "", "");
		P("int", 237, "Augmentation Faster Regen", "", pick: false, 0, "", "");
		P("int", 238, "Augmentation Increased Spell Duration", "", pick: false, 0, "", "");
		P("int", 239, "Augmentation Resistance Family", "", pick: false, 0, "", "");
		P("int", 240, "Augmentation Resistance Slash", "", pick: false, 0, "", "");
		P("int", 241, "Augmentation Resistance Pierce", "", pick: false, 0, "", "");
		P("int", 242, "Augmentation Resistance Blunt", "", pick: false, 0, "", "");
		P("int", 243, "Augmentation Resistance Acid", "", pick: false, 0, "", "");
		P("int", 244, "Augmentation Resistance Fire", "", pick: false, 0, "", "");
		P("int", 245, "Augmentation Resistance Frost", "", pick: false, 0, "", "");
		P("int", 246, "Augmentation Resistance Lightning", "", pick: false, 0, "", "");
		P("int", 247, "Rares Tier One Login", "", pick: false, 0, "", "");
		P("int", 248, "Rares Tier Two Login", "", pick: false, 0, "", "");
		P("int", 249, "Rares Tier Three Login", "", pick: false, 0, "", "");
		P("int", 250, "Rares Tier Four Login", "", pick: false, 0, "", "");
		P("int", 251, "Rares Tier Five Login", "", pick: false, 0, "", "");
		P("int", 252, "Rares Login Timestamp", "", pick: false, 0, "", "");
		P("int", 253, "Rares Tier Six", "", pick: false, 0, "", "");
		P("int", 254, "Rares Tier Seven", "", pick: false, 0, "", "");
		P("int", 255, "Rares Tier Six Login", "", pick: false, 0, "", "");
		P("int", 256, "Rares Tier Seven Login", "", pick: false, 0, "", "");
		P("int", 257, "Item Attribute Limit", "", pick: false, 1, "", "");
		P("int", 258, "Item Attribute Level Limit", "", pick: false, 1, "", "");
		P("int", 259, "Item Attribute2nd Limit", "", pick: false, 1, "", "");
		P("int", 260, "Item Attribute2nd Level Limit", "", pick: false, 1, "", "");
		P("int", 261, "Character Title Id", "", pick: false, 1, "", "");
		P("int", 262, "Num Character Titles", "", pick: false, 1, "", "");
		P("int", 263, "Resistance Cleaving Element", "Weapon", pick: true, 1, "", "new");
		P("int", 264, "Free Tinkers Bitfield", "", pick: false, 0, "", "");
		P("int", 265, "Armor Set ID", "Armor", pick: true, 1, "", "");
		P("int", 266, "Pet Class", "", pick: false, 0, "", "");
		P("int", 267, "Lifespan", "", pick: false, 1, "", "");
		P("int", 268, "Remaining Lifespan", "", pick: false, 1, "", "");
		P("int", 269, "Use Create Quantity", "", pick: false, 0, "", "");
		P("int", 270, "Wield Requirements2", "", pick: false, 1, "", "");
		P("int", 271, "Wield Skill Type2", "", pick: false, 1, "", "");
		P("int", 272, "Wield Difficulty2", "", pick: false, 1, "", "");
		P("int", 273, "Wield Requirement 3: Type", "ILT Custom", pick: true, 1, "", "ilt");
		P("int", 274, "Wield Requirement 3: Counter", "ILT Custom", pick: true, 1, "", "ilt");
		P("int", 275, "Wield Requirement 3: Amount", "ILT Custom", pick: true, 1, "", "ilt");
		P("int", 276, "Wield Requirement 4: Type", "ILT Custom", pick: true, 1, "", "ilt");
		P("int", 277, "Wield Requirement 4: Counter", "ILT Custom", pick: true, 1, "", "ilt");
		P("int", 278, "Wield Requirement 4: Amount", "ILT Custom", pick: true, 1, "", "ilt");
		P("int", 279, "Unique", "Item", pick: false, 1, "", "");
		P("int", 280, "Shared Cooldown", "", pick: false, 1, "", "");
		P("int", 281, "Faction1Bits", "", pick: false, 1, "", "");
		P("int", 282, "Faction2Bits", "", pick: false, 0, "", "");
		P("int", 283, "Faction3Bits", "", pick: false, 0, "", "");
		P("int", 284, "Hatred1Bits", "", pick: false, 0, "", "");
		P("int", 285, "Hatred2Bits", "", pick: false, 0, "", "");
		P("int", 286, "Hatred3Bits", "", pick: false, 0, "", "");
		P("int", 287, "Society Rank Celhan", "", pick: false, 1, "", "");
		P("int", 288, "Society Rank Eldweb", "", pick: false, 1, "", "");
		P("int", 289, "Society Rank Radblo", "", pick: false, 1, "", "");
		P("int", 290, "Hear Local Signals", "", pick: false, 0, "", "");
		P("int", 291, "Hear Local Signals Radius", "", pick: false, 0, "", "");
		P("int", 292, "Cleave Targets", "Weapon", pick: true, 1, "", "new");
		P("int", 293, "Augmentation Specialize Gearcraft", "", pick: false, 0, "", "");
		P("int", 294, "Augmentation Infused Creature Magic", "", pick: false, 0, "", "");
		P("int", 295, "Augmentation Infused Item Magic", "", pick: false, 0, "", "");
		P("int", 296, "Augmentation Infused Life Magic", "", pick: false, 0, "", "");
		P("int", 297, "Augmentation Infused War Magic", "", pick: false, 0, "", "");
		P("int", 298, "Augmentation Critical Expertise", "", pick: false, 0, "", "");
		P("int", 299, "Augmentation Critical Power", "", pick: false, 0, "", "");
		P("int", 300, "Augmentation Skilled Melee", "", pick: false, 0, "", "");
		P("int", 301, "Augmentation Skilled Missile", "", pick: false, 0, "", "");
		P("int", 302, "Augmentation Skilled Magic", "", pick: false, 0, "", "");
		P("int", 303, "Imbued Effect2", "", pick: false, 1, "", "");
		P("int", 304, "Imbued Effect3", "", pick: false, 1, "", "");
		P("int", 305, "Imbued Effect4", "", pick: false, 1, "", "");
		P("int", 306, "Imbued Effect5", "", pick: false, 1, "", "");
		P("int", 307, "Damage Rating", "", pick: false, 1, "", "");
		P("int", 308, "Damage Resist Rating", "", pick: false, 1, "", "");
		P("int", 309, "Augmentation Damage Bonus", "", pick: false, 0, "", "");
		P("int", 310, "Augmentation Damage Reduction", "", pick: false, 0, "", "");
		P("int", 311, "Imbue Stacking Bits", "", pick: false, 0, "", "");
		P("int", 312, "Heal Over Time", "", pick: false, 0, "", "");
		P("int", 313, "Crit Rating", "", pick: false, 1, "", "");
		P("int", 314, "Crit Damage Rating", "", pick: false, 1, "", "");
		P("int", 315, "Crit Resist Rating", "", pick: false, 1, "", "");
		P("int", 316, "Crit Damage Resist Rating", "", pick: false, 1, "", "");
		P("int", 317, "Healing Resist Rating", "", pick: false, 0, "", "");
		P("int", 318, "Damage Over Time", "", pick: false, 0, "", "");
		P("int", 319, "Item Max Level", "Requirements", pick: true, 1, "", "");
		P("int", 320, "Item Xp Style", "", pick: false, 1, "", "");
		P("int", 321, "Equipment Set Extra", "", pick: false, 0, "", "");
		P("int", 322, "Aetheria Bitfield", "", pick: false, 0, "", "");
		P("int", 323, "Healing Boost Rating", "", pick: false, 1, "", "");
		P("int", 324, "Heritage Armor", "Armor", pick: true, 1, "", "new");
		P("int", 325, "Alternate Racial Skills", "", pick: false, 0, "", "");
		P("int", 326, "Augmentation Jack Of All Trades", "", pick: false, 0, "", "");
		P("int", 327, "Augmentation Resistance Nether", "", pick: false, 0, "", "");
		P("int", 328, "Augmentation Infused Void Magic", "", pick: false, 0, "", "");
		P("int", 329, "Weakness Rating", "", pick: false, 0, "", "");
		P("int", 330, "Nether Over Time", "", pick: false, 0, "", "");
		P("int", 331, "Nether Resist Rating", "", pick: false, 0, "", "");
		P("int", 332, "Luminance Award", "", pick: false, 0, "", "");
		P("int", 333, "Lum Aug Damage Rating", "", pick: false, 0, "", "");
		P("int", 334, "Lum Aug Damage Reduction Rating", "", pick: false, 0, "", "");
		P("int", 335, "Lum Aug Crit Damage Rating", "", pick: false, 0, "", "");
		P("int", 336, "Lum Aug Crit Reduction Rating", "", pick: false, 0, "", "");
		P("int", 337, "Lum Aug Surge Effect Rating", "", pick: false, 0, "", "");
		P("int", 338, "Lum Aug Surge Chance Rating", "", pick: false, 0, "", "");
		P("int", 339, "Lum Aug Item Mana Usage", "", pick: false, 0, "", "");
		P("int", 340, "Lum Aug Item Mana Gain", "", pick: false, 0, "", "");
		P("int", 341, "Lum Aug Vitality", "", pick: false, 0, "", "");
		P("int", 342, "Lum Aug Healing Rating", "", pick: false, 0, "", "");
		P("int", 343, "Lum Aug Skilled Craft", "", pick: false, 0, "", "");
		P("int", 344, "Lum Aug Skilled Spec", "", pick: false, 0, "", "");
		P("int", 345, "Lum Aug No Destroy Craft", "", pick: false, 0, "", "");
		P("int", 346, "Restrict Interaction", "", pick: false, 0, "", "");
		P("int", 347, "Olthoi Loot Timestamp", "", pick: false, 0, "", "");
		P("int", 348, "Olthoi Loot Step", "", pick: false, 0, "", "");
		P("int", 349, "Use Creates Contract Id", "", pick: false, 0, "", "");
		P("int", 350, "Dot Resist Rating", "", pick: false, 1, "", "");
		P("int", 351, "Life Resist Rating", "", pick: false, 1, "", "");
		P("int", 352, "Cloak Chance Type", "Requirements", pick: true, 1, "", "");
		P("int", 353, "Weapon Mastery Category", "Weapon", pick: true, 1, "", "");
		P("int", 354, "Melee Mastery", "", pick: false, 0, "", "");
		P("int", 355, "Ranged Mastery", "", pick: false, 0, "", "");
		P("int", 356, "Sneak Attack Rating", "", pick: false, 0, "", "");
		P("int", 357, "Recklessness Rating", "", pick: false, 0, "", "");
		P("int", 358, "Deception Rating", "", pick: false, 0, "", "");
		P("int", 359, "Combat Pet Range", "", pick: false, 0, "", "");
		P("int", 360, "Weapon Aura Damage", "", pick: false, 0, "", "");
		P("int", 361, "Weapon Aura Speed", "", pick: false, 0, "", "");
		P("int", 362, "Summoning Mastery", "", pick: false, 0, "", "");
		P("int", 363, "Heartbeat Lifespan", "", pick: false, 0, "", "");
		P("int", 364, "Use Level Requirement", "", pick: false, 0, "", "");
		P("int", 365, "Lum Aug All Skills", "", pick: false, 0, "", "");
		P("int", 366, "Use Requires Skill", "", pick: false, 1, "", "");
		P("int", 367, "Summoning Gem Buffed Skill Req", "Requirements", pick: true, 1, "", "");
		P("int", 368, "Use Requires Skill Spec", "", pick: false, 1, "", "");
		P("int", 369, "Summoning Gem Level Req", "Requirements", pick: true, 1, "", "");
		P("int", 370, "Damage Rating", "Ratings", pick: true, 1, "", "");
		P("int", 371, "Damage Resist Rating", "Ratings", pick: true, 1, "", "");
		P("int", 372, "Crit Rating", "Ratings", pick: true, 1, "", "");
		P("int", 373, "Crit Resist Rating", "Ratings", pick: true, 1, "", "");
		P("int", 374, "Crit Damage Rating", "Ratings", pick: true, 1, "", "");
		P("int", 375, "Crit Damage Resist Rating", "Ratings", pick: true, 1, "", "");
		P("int", 376, "Healing Boost Rating", "Ratings", pick: true, 1, "", "");
		P("int", 377, "Nether Resist Rating", "Ratings", pick: true, 1, "", "new");
		P("int", 378, "Life Resist Rating", "Ratings", pick: true, 1, "", "new");
		P("int", 379, "Vitality Rating (Max Health)", "Ratings", pick: true, 1, "", "");
		P("int", 380, "Unknown380", "", pick: false, 0, "", "");
		P("int", 381, "PK Damage Rating", "", pick: false, 1, "", "");
		P("int", 382, "PK Damage Resist Rating", "", pick: false, 1, "", "");
		P("int", 383, "Gear PK Damage Rating", "", pick: false, 1, "", "");
		P("int", 384, "Gear PK Damage Resist Rating", "", pick: false, 1, "", "");
		P("int", 385, "Unknown385", "", pick: false, 0, "", "");
		P("int", 386, "Overpower", "", pick: false, 1, "", "");
		P("int", 387, "Overpower Resist", "", pick: false, 1, "", "");
		P("int", 388, "Overpower Rating", "Ratings", pick: true, 1, "", "new");
		P("int", 389, "Overpower Resist Rating", "Ratings", pick: true, 1, "", "new");
		P("int", 390, "Enlightenment", "", pick: false, 1, "", "");
		P("int", 8007, "PCAP Recorded Autonomous Movement", "", pick: false, 0, "", "");
		P("int", 8030, "PCAP Recorded Max Velocity Estimated", "", pick: false, 0, "", "");
		P("int", 8041, "PCAP Recorded Placement", "", pick: false, 0, "", "");
		P("int", 8042, "PCAP Recorded Appraisal Pages", "", pick: false, 0, "", "");
		P("int", 8043, "PCAP Recorded Appraisal Max Pages", "", pick: false, 0, "", "");
		P("int", 9008, "Current Loyalty At Last Logoff", "", pick: false, 0, "", "");
		P("int", 9009, "Current Leadership At Last Logoff", "", pick: false, 0, "", "");
		P("int", 9010, "Allegiance Officer Rank", "", pick: false, 0, "", "");
		P("int", 9011, "House Rent Timestamp", "", pick: false, 0, "", "");
		P("int", 9012, "Hairstyle", "", pick: false, 0, "", "");
		P("int", 9013, "Visual Clothing Priority", "", pick: false, 0, "", "");
		P("int", 9014, "Squelch Global", "", pick: false, 0, "", "");
		P("int", 9015, "Inventory Order", "", pick: false, 0, "", "");
		P("int", 9016, "Bank Account Number", "", pick: false, 0, "", "");
		P("int", 9017, "Lum Augment Melee Range", "", pick: false, 0, "", "");
		P("int", 9018, "Lum Augment Power Bar Speed", "", pick: false, 0, "", "");
		P("int", 9019, "Portal Req Type", "", pick: false, 0, "", "");
		P("int", 9020, "Portal Req Value", "", pick: false, 0, "", "");
		P("int", 9021, "Portal Req Max Value", "", pick: false, 0, "", "");
		P("int", 9022, "Portal Req Type2", "", pick: false, 0, "", "");
		P("int", 9023, "Portal Req Value2", "", pick: false, 0, "", "");
		P("int", 9024, "Portal Req Max Value2", "", pick: false, 0, "", "");
		P("int", 9025, "Enrage Fog Color", "", pick: false, 0, "", "");
		P("int", 9026, "Enrage Sound", "", pick: false, 0, "", "");
		P("int", 9027, "Enrage Visual Effect", "", pick: false, 0, "", "");
		P("int", 9031, "Split Arrow Count", "ILT Custom", pick: true, 1, "", "ilt");
		P("int", 9032, "Capture Creature Type", "", pick: false, 0, "", "");
		P("int", 9033, "Captured Creature WCID", "", pick: false, 0, "", "");
		P("int", 9034, "Captured Palette Template", "", pick: false, 0, "", "");
		P("int", 9035, "Visual Override Palette Template", "", pick: false, 0, "", "");
		P("int", 9036, "Crystal Tier", "", pick: false, 0, "", "");
		P("int", 9037, "Captured Creature Type", "", pick: false, 0, "", "");
		P("int", 9038, "Creature Variant", "", pick: false, 0, "", "");
		P("int", 9039, "Captured Creature Variant", "", pick: false, 0, "", "");
		P("int", 9040, "Portal Use Count", "", pick: false, 0, "", "");
		P("int", 9041, "Failed Shiny Capture WCID", "", pick: false, 0, "", "");
		P("int", 9042, "Failed Shiny Capture Guid", "", pick: false, 0, "", "");
		P("int", 9043, "Prestige Level", "", pick: false, 1, "", "");
		P("int", 9044, "Times Jailed", "", pick: false, 0, "", "");
		P("int", 9045, "Times Ucm Check Passed", "", pick: false, 0, "", "");
		P("int", 9046, "Targeting Flags", "", pick: false, 0, "", "");
		P("int", 9047, "Spell Suppression Schools", "", pick: false, 0, "", "");
		P("int", 9053, "Pet Bond Level", "ILT Custom Pets", pick: true, 1, "", "ilt");
		P("int", 9054, "Captured Source Damage Type", "", pick: false, 0, "", "");
		P("int", 9055, "Pet Device Min Lum Aug Summon Count", "", pick: false, 0, "", "");
		P("int", 9056, "Pet Potency Stored", "ILT Custom Pets", pick: true, 1, "", "ilt");
		P("int", 9057, "Pet Breeding Charges", "ILT Custom Pets", pick: true, 1, "", "ilt");
		P("int", 9058, "Pet Vitality Rating", "ILT Custom Pets", pick: true, 1, "", "ilt");
		P("int", 9060, "Weapon Quality (Grade)", "ILT Custom", pick: true, 1, "T11 weapon QUALITY 0-1000 (grade: S 1000, A 900+, B 800+, C 650+, D 500+, F below). Sent since 2026-09-29.", "ilt");
		P("int", 9061, "Weapon Tier", "ILT Custom", pick: true, 1, "T11 weapon TIER (11-25). Sent since 2026-09-29.", "ilt");
		P("int", 9062, "Pet Mut Crit Rating", "", pick: false, 0, "", "");
		P("int", 9063, "Pet Mut Crit Damage Rating", "", pick: false, 0, "", "");
		P("int", 9064, "Pet Mut Crit Resist Rating", "", pick: false, 0, "", "");
		P("int", 9065, "Pet Mut Crit Damage Resist Rating", "", pick: false, 0, "", "");
		P("int", 9066, "Pet Mut Vitality", "", pick: false, 0, "", "");
		P("int", 9067, "Pet Mut Potency", "", pick: false, 0, "", "");
		P("int", 9068, "Pet Mut Damage Rating", "", pick: false, 0, "", "");
		P("int", 9069, "Pet Mut Damage Resist Rating", "", pick: false, 0, "", "");
		P("int", 9070, "Pet Damage Mutations", "ILT Custom Pets", pick: true, 1, "", "ilt");
		P("int", 9071, "Pet Damage Resist Mutations", "ILT Custom Pets", pick: true, 1, "", "ilt");
		P("int", 9072, "Pet Crit Mutations", "ILT Custom Pets", pick: true, 1, "", "ilt");
		P("int", 9073, "Pet Vitality Mutations", "ILT Custom Pets", pick: true, 1, "", "ilt");
		P("int", 9074, "Pet Potency Mutations", "ILT Custom Pets", pick: true, 1, "", "ilt");
		P("int", 9075, "Pet Mutations (Total)", "ILT Custom Pets", pick: true, 1, "", "ilt");
		P("int", 9076, "Essence Salvage Yield", "", pick: false, 0, "", "");
		P("int", 9077, "Pet Maturity Kills", "ILT Custom Pets", pick: true, 1, "", "ilt");
		P("int", 9078, "Pet Last Mutated Stat", "ILT Custom Pets", pick: true, 1, "", "ilt");
		P("int", 9079, "Pet Litters Bred", "", pick: false, 0, "", "");
		P("int", 50000, "Charm Grants Ability", "", pick: false, 0, "", "");
		P("int", 50005, "Charm Level", "", pick: false, 0, "", "");
		P("int", 50006, "Charm Max Level", "", pick: false, 0, "", "");
		P("int", 50016, "Active Charm Level", "", pick: false, 0, "", "");
		P("int", 50060, "Item Expiration Timestamp", "", pick: false, 0, "", "");
		P("int", 50101, "Damage Number Format", "", pick: false, 0, "", "");
		P("int", 50102, "Empower Group", "", pick: false, 0, "", "");
		P("int", 50103, "Variation Scaled Spawn Base", "", pick: false, 0, "", "");
		P("int", 50104, "Variation Scaled Spawn Baseline", "", pick: false, 0, "", "");
		P("int", 50105, "Endgame Forced Variation", "", pick: false, 0, "", "");
		P("int", 50106, "Elemental Weakness Mask", "", pick: false, 0, "", "");
		P("int", 50107, "Outgoing Damage Type Override", "", pick: false, 0, "", "");
		P("int", 50108, "Boss Group Id", "", pick: false, 0, "", "");
		P("int", 50109, "Gear Tier", "ILT Custom", pick: true, 1, "Gear TIER (11-25) on armor/jewelry. Sent since 2026-09-29.", "ilt");
		P("int", 50110, "Zc Resolved Version", "", pick: false, 0, "", "");
		P("int", 218103808, "Weenie Id (WCID)", "Item", pick: true, 1, "", "");
		P("int", 218103809, "Icon", "Item", pick: true, 1, "", "");
		P("int", 218103810, "Container", "", pick: false, 1, "", "");
		P("int", 218103811, "Landblock", "", pick: false, 1, "", "");
		P("int", 218103812, "Item Slots", "Item", pick: true, 1, "", "");
		P("int", 218103813, "Pack Slots", "Item", pick: true, 1, "", "");
		P("int", 218103814, "Stack Count", "Item", pick: true, 1, "", "");
		P("int", 218103815, "Stack Max", "Item", pick: true, 1, "", "");
		P("int", 218103816, "Associated Spell", "", pick: false, 1, "", "");
		P("int", 218103817, "Slot", "", pick: false, 1, "", "");
		P("int", 218103818, "Wielder", "", pick: false, 1, "", "");
		P("int", 218103819, "Wielding Slot", "", pick: false, 1, "", "");
		P("int", 218103820, "Monarch", "", pick: false, 1, "", "");
		P("int", 218103821, "Coverage", "Armor", pick: true, 1, "", "");
		P("int", 218103822, "Equippable Slots", "Armor", pick: true, 1, "", "");
		P("int", 218103823, "Equip Type", "", pick: false, 1, "", "");
		P("int", 218103824, "Icon Outline", "", pick: false, 1, "", "");
		P("int", 218103825, "Missile Type", "Weapon", pick: true, 1, "", "");
		P("int", 218103826, "Usage Mask", "", pick: false, 1, "", "");
		P("int", 218103827, "House Owner", "", pick: false, 1, "", "");
		P("int", 218103828, "Hook Mask", "", pick: false, 1, "", "");
		P("int", 218103829, "Hook Type", "", pick: false, 1, "", "");
		P("int", 218103830, "Model", "", pick: false, 1, "", "");
		P("int", 218103831, "Flags", "", pick: false, 1, "", "");
		P("int", 218103832, "Create Flags1", "", pick: false, 1, "", "");
		P("int", 218103833, "Create Flags2", "", pick: false, 1, "", "");
		P("int", 218103834, "Category", "", pick: false, 1, "", "");
		P("int", 218103835, "Behavior", "", pick: false, 1, "", "");
		P("int", 218103836, "Magic Def", "", pick: false, 1, "", "");
		P("int", 218103837, "Special Props", "", pick: false, 1, "", "");
		P("int", 218103838, "Spell Count", "Spells and mana", pick: true, 1, "", "");
		P("int", 218103839, "Weap Speed", "Weapon", pick: true, 1, "", "");
		P("int", 218103840, "Equip Skill", "Weapon", pick: true, 1, "", "");
		P("int", 218103841, "Damage Type", "Weapon", pick: true, 1, "", "");
		P("int", 218103842, "Max Damage", "Weapon", pick: true, 1, "", "");
		P("int", 218103843, "Unknown10", "", pick: false, 1, "", "");
		P("int", 218103844, "Unknown100000", "", pick: false, 1, "", "");
		P("int", 218103845, "Unknown800000", "", pick: false, 1, "", "");
		P("int", 218103846, "Unknown8000000", "", pick: false, 1, "", "");
		P("int", 218103847, "Physics Data Flags", "", pick: false, 1, "", "");
		P("int", 218103848, "Active Spell Count", "", pick: false, 1, "", "");
		P("int", 218103849, "Icon Overlay", "Item", pick: true, 1, "", "");
		P("int", 218103850, "Icon Underlay", "Item", pick: true, 1, "", "");
		P("int", 218103851, "Equipped By", "", pick: false, 1, "", "");
		P("int", 218103852, "Last Attacker", "", pick: false, 1, "", "");
		P("int", 218103853, "Allegiance Object", "", pick: false, 1, "", "");
		P("int", 218103854, "Patron", "", pick: false, 1, "", "");
		P("int", 226492416, "Identify Flags1", "", pick: false, 1, "", "");
		P("int", 226492417, "Creature Current Health", "", pick: false, 1, "", "");
		P("int", 226492418, "Creature Maximum Health", "", pick: false, 1, "", "");
		P("int", 226492419, "Creature Buffed Strength", "", pick: false, 1, "", "");
		P("int", 226492420, "Creature Buffed Endurance", "", pick: false, 1, "", "");
		P("int", 226492421, "Creature Buffed Quickness", "", pick: false, 1, "", "");
		P("int", 226492422, "Creature Buffed Coordination", "", pick: false, 1, "", "");
		P("int", 226492423, "Creature Buffed Focus", "", pick: false, 1, "", "");
		P("int", 226492424, "Creature Buffed Self", "", pick: false, 1, "", "");
		P("int", 226492425, "Creature Current Stamina", "", pick: false, 1, "", "");
		P("int", 226492426, "Creature Current Mana", "", pick: false, 1, "", "");
		P("int", 226492427, "Creature Maximum Stamina", "", pick: false, 1, "", "");
		P("int", 226492428, "Creature Maximum Mana", "", pick: false, 1, "", "");
		P("int", 226492429, "Creature Attribute Highlight", "", pick: false, 1, "", "");
		P("int", 226492430, "Creature Attribute Color", "", pick: false, 1, "", "");
		P("double", 0, "Undef", "", pick: false, 0, "", "");
		P("double", 1, "Heartbeat Interval", "", pick: false, 0, "", "");
		P("double", 2, "Heartbeat Timestamp", "", pick: false, 0, "", "");
		P("double", 3, "Health Rate", "", pick: false, 0, "", "");
		P("double", 4, "Stamina Rate", "", pick: false, 0, "", "");
		P("double", 5, "Mana Rate Of Change", "", pick: false, 1, "", "");
		P("double", 6, "Health Upon Resurrection", "", pick: false, 0, "", "");
		P("double", 7, "Stamina Upon Resurrection", "", pick: false, 0, "", "");
		P("double", 8, "Mana Upon Resurrection", "", pick: false, 0, "", "");
		P("double", 9, "Start Time", "", pick: false, 0, "", "");
		P("double", 10, "Stop Time", "", pick: false, 0, "", "");
		P("double", 11, "Reset Interval", "", pick: false, 0, "", "");
		P("double", 12, "Shade", "", pick: false, 0, "", "");
		P("double", 13, "Armor Mod Vs Slash", "", pick: false, 0, "", "");
		P("double", 14, "Armor Mod Vs Pierce", "", pick: false, 0, "", "");
		P("double", 15, "Armor Mod Vs Bludgeon", "", pick: false, 0, "", "");
		P("double", 16, "Armor Mod Vs Cold", "", pick: false, 0, "", "");
		P("double", 17, "Armor Mod Vs Fire", "", pick: false, 0, "", "");
		P("double", 18, "Armor Mod Vs Acid", "", pick: false, 0, "", "");
		P("double", 19, "Armor Mod Vs Electric", "", pick: false, 0, "", "");
		P("double", 20, "Combat Speed", "", pick: false, 0, "", "");
		P("double", 21, "Weapon Length", "", pick: false, 0, "", "");
		P("double", 22, "Damage Variance", "", pick: false, 0, "", "");
		P("double", 23, "Current Power Mod", "", pick: false, 0, "", "");
		P("double", 24, "Accuracy Mod", "", pick: false, 0, "", "");
		P("double", 25, "Strength Mod", "", pick: false, 0, "", "");
		P("double", 26, "Maximum Velocity", "", pick: false, 0, "", "");
		P("double", 27, "Rotation Speed", "", pick: false, 0, "", "");
		P("double", 28, "Motion Timestamp", "", pick: false, 0, "", "");
		P("double", 29, "Melee Defense Bonus", "Weapon", pick: true, 1, "", "");
		P("double", 30, "Wimpy Level", "", pick: false, 0, "", "");
		P("double", 31, "Visual Awareness Range", "", pick: false, 0, "", "");
		P("double", 32, "Aural Awareness Range", "", pick: false, 0, "", "");
		P("double", 33, "Perception Level", "", pick: false, 0, "", "");
		P("double", 34, "Powerup Time", "", pick: false, 0, "", "");
		P("double", 35, "Max Charge Distance", "", pick: false, 0, "", "");
		P("double", 36, "Charge Speed", "", pick: false, 0, "", "");
		P("double", 37, "Buy Price", "", pick: false, 0, "", "");
		P("double", 38, "Sell Price", "", pick: false, 0, "", "");
		P("double", 39, "Default Scale", "", pick: false, 0, "", "");
		P("double", 40, "Lockpick Mod", "", pick: false, 0, "", "");
		P("double", 41, "Regeneration Interval", "", pick: false, 0, "", "");
		P("double", 42, "Regeneration Timestamp", "", pick: false, 0, "", "");
		P("double", 43, "Generator Radius", "", pick: false, 0, "", "");
		P("double", 44, "Time To Rot", "", pick: false, 0, "", "");
		P("double", 45, "Death Timestamp", "", pick: false, 0, "", "");
		P("double", 46, "Pk Timestamp", "", pick: false, 0, "", "");
		P("double", 47, "Victim Timestamp", "", pick: false, 0, "", "");
		P("double", 48, "Login Timestamp", "", pick: false, 0, "", "");
		P("double", 49, "Creation Timestamp", "", pick: false, 0, "", "");
		P("double", 50, "Minimum Time Since Pk", "", pick: false, 0, "", "");
		P("double", 51, "Deprecated Housekeeping Priority", "", pick: false, 0, "", "");
		P("double", 52, "Abuse Logging Timestamp", "", pick: false, 0, "", "");
		P("double", 53, "Last Portal Teleport Timestamp", "", pick: false, 0, "", "");
		P("double", 54, "Use Radius", "", pick: false, 0, "", "");
		P("double", 55, "Home Radius", "", pick: false, 0, "", "");
		P("double", 56, "Released Timestamp", "", pick: false, 0, "", "");
		P("double", 57, "Min Home Radius", "", pick: false, 0, "", "");
		P("double", 58, "Facing", "", pick: false, 0, "", "");
		P("double", 59, "Reset Timestamp", "", pick: false, 0, "", "");
		P("double", 60, "Logoff Timestamp", "", pick: false, 0, "", "");
		P("double", 61, "Econ Recovery Interval", "", pick: false, 0, "", "");
		P("double", 62, "Weapon Offense", "", pick: false, 0, "", "");
		P("double", 63, "Damage Modifier", "Weapon", pick: true, 1, "", "new");
		P("double", 64, "Resist Slash", "", pick: false, 0, "", "");
		P("double", 65, "Resist Pierce", "", pick: false, 0, "", "");
		P("double", 66, "Resist Bludgeon", "", pick: false, 0, "", "");
		P("double", 67, "Resist Fire", "", pick: false, 0, "", "");
		P("double", 68, "Resist Cold", "", pick: false, 0, "", "");
		P("double", 69, "Resist Acid", "", pick: false, 0, "", "");
		P("double", 70, "Resist Electric", "", pick: false, 0, "", "");
		P("double", 71, "Resist Health Boost", "", pick: false, 0, "", "");
		P("double", 72, "Resist Stamina Drain", "", pick: false, 0, "", "");
		P("double", 73, "Resist Stamina Boost", "", pick: false, 0, "", "");
		P("double", 74, "Resist Mana Drain", "", pick: false, 0, "", "");
		P("double", 75, "Resist Mana Boost", "", pick: false, 0, "", "");
		P("double", 76, "Translucency", "", pick: false, 0, "", "");
		P("double", 77, "Physics Script Intensity", "", pick: false, 0, "", "");
		P("double", 78, "Friction", "", pick: false, 0, "", "");
		P("double", 79, "Elasticity", "", pick: false, 0, "", "");
		P("double", 80, "Ai Use Magic Delay", "", pick: false, 0, "", "");
		P("double", 81, "Item Min Spellcraft Mod", "", pick: false, 0, "", "");
		P("double", 82, "Item Max Spellcraft Mod", "", pick: false, 0, "", "");
		P("double", 83, "Item Rank Probability", "", pick: false, 0, "", "");
		P("double", 84, "Shade2", "", pick: false, 0, "", "");
		P("double", 85, "Shade3", "", pick: false, 0, "", "");
		P("double", 86, "Shade4", "", pick: false, 0, "", "");
		P("double", 87, "Mana Transfer Efficiency", "Spells and mana", pick: true, 1, "", "");
		P("double", 88, "Item Mana Update Timestamp", "", pick: false, 0, "", "");
		P("double", 89, "Spell Gesture Speed Mod", "", pick: false, 0, "", "");
		P("double", 90, "Spell Stance Speed Mod", "", pick: false, 0, "", "");
		P("double", 91, "Allegiance Appraisal Timestamp", "", pick: false, 0, "", "");
		P("double", 92, "Power Level", "", pick: false, 0, "", "");
		P("double", 93, "Accuracy Level", "", pick: false, 0, "", "");
		P("double", 94, "Attack Angle", "", pick: false, 0, "", "");
		P("double", 95, "Attack Timestamp", "", pick: false, 0, "", "");
		P("double", 96, "Checkpoint Timestamp", "", pick: false, 0, "", "");
		P("double", 97, "Sold Timestamp", "", pick: false, 0, "", "");
		P("double", 98, "Use Timestamp", "", pick: false, 0, "", "");
		P("double", 99, "Use Lock Timestamp", "", pick: false, 0, "", "");
		P("double", 100, "Healing Kit Restore Bonus", "Consumables", pick: true, 1, "", "");
		P("double", 101, "Frozen Timestamp", "", pick: false, 0, "", "");
		P("double", 102, "Health Rate Mod", "", pick: false, 0, "", "");
		P("double", 103, "Allegiance Swear Timestamp", "", pick: false, 0, "", "");
		P("double", 104, "Obvious Radar Range", "", pick: false, 0, "", "");
		P("double", 105, "Hotspot Cycle Time", "", pick: false, 0, "", "");
		P("double", 106, "Hotspot Cycle Time Variance", "", pick: false, 0, "", "");
		P("double", 107, "Spam Timestamp", "", pick: false, 0, "", "");
		P("double", 108, "Spam Rate", "", pick: false, 0, "", "");
		P("double", 109, "Bond Wielded Treasure", "", pick: false, 0, "", "");
		P("double", 110, "Bulk Mod", "", pick: false, 0, "", "");
		P("double", 111, "Size Mod", "", pick: false, 0, "", "");
		P("double", 112, "Gag Timestamp", "", pick: false, 0, "", "");
		P("double", 113, "Generator Update Timestamp", "", pick: false, 0, "", "");
		P("double", 114, "Death Spam Timestamp", "", pick: false, 0, "", "");
		P("double", 115, "Death Spam Rate", "", pick: false, 0, "", "");
		P("double", 116, "Wild Attack Probability", "", pick: false, 0, "", "");
		P("double", 117, "Focused Probability", "", pick: false, 0, "", "");
		P("double", 118, "Crash And Turn Probability", "", pick: false, 0, "", "");
		P("double", 119, "Crash And Turn Radius", "", pick: false, 0, "", "");
		P("double", 120, "Crash And Turn Bias", "", pick: false, 0, "", "");
		P("double", 121, "Generator Initial Delay", "", pick: false, 0, "", "");
		P("double", 122, "Ai Acquire Health", "", pick: false, 0, "", "");
		P("double", 123, "Ai Acquire Stamina", "", pick: false, 0, "", "");
		P("double", 124, "Ai Acquire Mana", "", pick: false, 0, "", "");
		P("double", 125, "Resist Health Drain", "", pick: false, 0, "", "");
		P("double", 126, "Lifestone Protection Timestamp", "", pick: false, 0, "", "");
		P("double", 127, "Ai Counteract Enchantment", "", pick: false, 0, "", "");
		P("double", 128, "Ai Dispel Enchantment", "", pick: false, 0, "", "");
		P("double", 129, "Trade Timestamp", "", pick: false, 0, "", "");
		P("double", 130, "Ai Targeted Detection Radius", "", pick: false, 0, "", "");
		P("double", 131, "Emote Priority", "", pick: false, 0, "", "");
		P("double", 132, "Last Teleport Start Timestamp", "", pick: false, 0, "", "");
		P("double", 133, "Event Spam Timestamp", "", pick: false, 0, "", "");
		P("double", 134, "Event Spam Rate", "", pick: false, 0, "", "");
		P("double", 135, "Inventory Offset", "", pick: false, 0, "", "");
		P("double", 136, "Crushing Blow Multiplier", "Weapon", pick: true, 1, "Crushing Blow crit damage multiplier.", "new");
		P("double", 137, "Mana Stone Chance Destruct", "Spells and mana", pick: true, 1, "", "");
		P("double", 138, "Slayer Damage Bonus", "", pick: false, 0, "", "");
		P("double", 139, "Allegiance Info Spam Timestamp", "", pick: false, 0, "", "");
		P("double", 140, "Allegiance Info Spam Rate", "", pick: false, 0, "", "");
		P("double", 141, "Next Spellcast Timestamp", "", pick: false, 0, "", "");
		P("double", 142, "Appraisal Requested Timestamp", "", pick: false, 0, "", "");
		P("double", 143, "Appraisal Heartbeat Due Timestamp", "", pick: false, 0, "", "");
		P("double", 144, "Mana C Bonus", "Weapon", pick: true, 1, "", "");
		P("double", 145, "Last Pk Attack Timestamp", "", pick: false, 0, "", "");
		P("double", 146, "Fellowship Update Timestamp", "", pick: false, 0, "", "");
		P("double", 147, "Biting Strike Chance", "Weapon", pick: true, 1, "Biting Strike crit chance (0-1).", "new");
		P("double", 148, "Limbo Start Timestamp", "", pick: false, 0, "", "");
		P("double", 149, "Missile D Bonus", "Weapon", pick: true, 1, "", "");
		P("double", 150, "Magic D Bonus", "Weapon", pick: true, 1, "", "");
		P("double", 151, "Ignore Shield", "", pick: false, 0, "", "");
		P("double", 152, "Elemental Damage Versus Monsters", "Weapon", pick: true, 1, "", "");
		P("double", 153, "Start Missile Attack Timestamp", "", pick: false, 0, "", "");
		P("double", 154, "Last Rare Used Timestamp", "", pick: false, 0, "", "");
		P("double", 155, "Armor Ignored (Armor Rending)", "Weapon", pick: true, 1, "", "new");
		P("double", 156, "Proc Spell Rate", "", pick: false, 0, "", "");
		P("double", 157, "Resistance Cleaving Amount", "Weapon", pick: true, 1, "", "new");
		P("double", 158, "Allegiance Gag Timestamp", "", pick: false, 0, "", "");
		P("double", 159, "Magic Absorb", "Armor", pick: true, 1, "Magic absorb. The server shows it as exactly 1 when the item has any - test >= 1.", "new");
		P("double", 160, "Cached Max Absorb Magic Damage", "", pick: false, 0, "", "");
		P("double", 161, "Gag Duration", "", pick: false, 0, "", "");
		P("double", 162, "Allegiance Gag Duration", "", pick: false, 0, "", "");
		P("double", 163, "Global Xp Mod", "", pick: false, 0, "", "");
		P("double", 164, "Healing Modifier", "", pick: false, 0, "", "");
		P("double", 165, "Armor Mod Vs Nether", "", pick: false, 0, "", "");
		P("double", 166, "Resist Nether", "", pick: false, 0, "", "");
		P("double", 167, "Cooldown Duration", "", pick: false, 1, "", "");
		P("double", 168, "Weapon Aura Offense", "", pick: false, 0, "", "");
		P("double", 169, "Weapon Aura Defense", "", pick: false, 0, "", "");
		P("double", 170, "Weapon Aura Elemental", "", pick: false, 0, "", "");
		P("double", 171, "Weapon Aura Mana Conv", "", pick: false, 0, "", "");
		P("double", 280, "Cooldown Time Seconds", "", pick: false, 0, "", "");
		P("double", 8004, "PCAP Recorded Workmanship", "", pick: false, 0, "", "");
		P("double", 8010, "PCAP Recorded Velocity X", "", pick: false, 0, "", "");
		P("double", 8011, "PCAP Recorded Velocity Y", "", pick: false, 0, "", "");
		P("double", 8012, "PCAP Recorded Velocity Z", "", pick: false, 0, "", "");
		P("double", 8013, "PCAP Recorded Acceleration X", "", pick: false, 0, "", "");
		P("double", 8014, "PCAP Recorded Acceleration Y", "", pick: false, 0, "", "");
		P("double", 8015, "PCAP Recorded Acceleration Z", "", pick: false, 0, "", "");
		P("double", 8016, "PCAP Recorde Omega X", "", pick: false, 0, "", "");
		P("double", 8017, "PCAP Recorde Omega Y", "", pick: false, 0, "", "");
		P("double", 8018, "PCAP Recorde Omega Z", "", pick: false, 0, "", "");
		P("double", 9000, "Previous Level Cost", "", pick: false, 0, "", "");
		P("double", 9001, "Total Experience Double", "", pick: false, 0, "", "");
		P("double", 9002, "Spent Experience Strength", "", pick: false, 0, "", "");
		P("double", 9003, "Spent Experience Endurance", "", pick: false, 0, "", "");
		P("double", 9004, "Spent Experience Coordination", "", pick: false, 0, "", "");
		P("double", 9005, "Spent Experience Quickness", "", pick: false, 0, "", "");
		P("double", 9006, "Spent Experience Focus", "", pick: false, 0, "", "");
		P("double", 9007, "Spent Experience Self", "", pick: false, 0, "", "");
		P("double", 9008, "Spent Experience Health", "", pick: false, 0, "", "");
		P("double", 9009, "Spent Experience Stamina", "", pick: false, 0, "", "");
		P("double", 9010, "Spent Experience Mana", "", pick: false, 0, "", "");
		P("double", 9011, "Enrage Damage Multiplier", "", pick: false, 0, "", "");
		P("double", 9012, "Enrage Damage Reduction", "", pick: false, 0, "", "");
		P("double", 9013, "Enrage Threshold", "", pick: false, 0, "", "");
		P("double", 9032, "Split Arrow Range", "ILT Custom", pick: true, 1, "", "ilt");
		P("double", 9033, "Split Arrow Damage", "ILT Custom", pick: true, 1, "", "ilt");
		P("double", 9034, "Max Random Spawn Time", "", pick: false, 0, "", "");
		P("double", 9035, "Weapon Multi Strike Decay", "", pick: false, 0, "", "");
		P("double", 9036, "Weapon Cleave Strike Decay", "", pick: false, 0, "", "");
		P("double", 9037, "Life Aug Tuning Constant Override", "", pick: false, 0, "", "");
		P("double", 9038, "Life Aug Prot Max Bonus Override", "", pick: false, 0, "", "");
		P("double", 9039, "Life Aug New Curve Amount", "", pick: false, 0, "", "");
		P("double", 9040, "Captured Shade", "", pick: false, 0, "", "");
		P("double", 9041, "Captured Scale", "", pick: false, 0, "", "");
		P("double", 9042, "Visual Override Shade", "", pick: false, 0, "", "");
		P("double", 9043, "Visual Override Scale", "", pick: false, 0, "", "");
		P("double", 9044, "Capture Difficulty", "", pick: false, 0, "", "");
		P("double", 9045, "Damage Cap Multiplier", "", pick: false, 1, "", "");
		P("double", 9046, "Spell Suppression Radius", "", pick: false, 0, "", "");
		P("double", 9047, "Captured Scale Combat Pet", "", pick: false, 0, "", "");
		P("double", 9048, "Aoe Range Multiplier", "", pick: false, 0, "", "");
		P("double", 9049, "Percent Hp Damage Override", "", pick: false, 0, "", "");
		P("double", 9050, "Percent Hp Reduction Cap Override", "", pick: false, 0, "", "");
		P("double", 9051, "Percent Hp Reduction R Override", "", pick: false, 0, "", "");
		P("double", 9052, "Vuln Effectiveness Override", "", pick: false, 0, "", "");
		P("double", 9053, "Vuln Cap Override", "", pick: false, 0, "", "");
		P("double", 9054, "Mob Dmg Taken Override", "", pick: false, 0, "", "");
		P("double", 9055, "Elemental Weakness Factor", "", pick: false, 0, "", "");
		P("double", 9056, "Pet Next Breeding Time", "", pick: false, 1, "", "");
		P("double", 9057, "Pet Male Charges Refresh Time", "", pick: false, 1, "", "");
		P("double", 9058, "Pet Incense Bonus", "", pick: false, 1, "", "");
		P("double", 9059, "Pet Maturity Xp Multiplier", "", pick: false, 1, "", "");
		P("double", 9060, "Showcase Colour Cycle Seconds", "", pick: false, 0, "", "");
		P("double", 9061, "Spawn Colour Mutation Chance", "", pick: false, 0, "", "");
		P("double", 9062, "Pet Translucency", "", pick: false, 0, "", "");
		P("double", 50502, "Pressure Plate Cooldown", "", pick: false, 0, "", "");
		P("double", 167772160, "Slash Prot", "Armor", pick: true, 1, "", "");
		P("double", 167772161, "Pierce Prot", "Armor", pick: true, 1, "", "");
		P("double", 167772162, "Bludgeon Prot", "Armor", pick: true, 1, "", "");
		P("double", 167772163, "Acid Prot", "Armor", pick: true, 1, "", "");
		P("double", 167772164, "Lightning Prot", "Armor", pick: true, 1, "", "");
		P("double", 167772165, "Fire Prot", "Armor", pick: true, 1, "", "");
		P("double", 167772166, "Cold Prot", "Armor", pick: true, 1, "", "");
		P("double", 167772167, "Heading", "", pick: false, 1, "", "");
		P("double", 167772168, "Approach Distance", "", pick: false, 1, "", "");
		P("double", 167772169, "Salvage Workmanship", "Item", pick: true, 1, "", "");
		P("double", 167772170, "Scale", "", pick: false, 1, "", "");
		P("double", 167772171, "Variance", "Weapon", pick: true, 1, "", "");
		P("double", 167772172, "Attack Bonus", "Weapon", pick: true, 1, "", "");
		P("double", 167772173, "Range", "Weapon", pick: true, 1, "", "");
		P("double", 167772174, "Damage Bonus", "Weapon", pick: true, 1, "", "");
		P("string", 0, "Undef", "", pick: false, 0, "", "");
		P("string", 1, "Name", "Item", pick: true, 1, "", "");
		P("string", 2, "Title", "", pick: false, 0, "", "");
		P("string", 3, "Sex", "", pick: false, 0, "", "");
		P("string", 4, "Heritage Group", "", pick: false, 0, "", "");
		P("string", 5, "Title", "", pick: false, 1, "", "");
		P("string", 6, "Attackers Name", "", pick: false, 0, "", "");
		P("string", 7, "Inscription", "Item", pick: true, 1, "", "");
		P("string", 8, "Inscribed By", "Item", pick: true, 1, "", "");
		P("string", 9, "Vendors Name", "", pick: false, 0, "", "");
		P("string", 10, "Fellowship Name", "", pick: false, 1, "", "");
		P("string", 11, "Monarchs Name", "", pick: false, 0, "", "");
		P("string", 12, "Lock Code", "", pick: false, 0, "", "");
		P("string", 13, "Key Code", "", pick: false, 0, "", "");
		P("string", 14, "Use Text", "Item", pick: true, 1, "Use text. On T11 ARMOR / JEWELRY / SHIELDS it holds the 'Modifiers:' block.", "");
		P("string", 15, "Simple Description", "Item", pick: true, 1, "", "");
		P("string", 16, "Description", "Item", pick: true, 1, "Long description. On T11 WEAPONS it holds the 'Property Details:' block (grade, cards, modifiers).", "");
		P("string", 17, "Activation Talk", "", pick: false, 0, "", "");
		P("string", 18, "Use Message", "", pick: false, 0, "", "");
		P("string", 19, "Item Heritage Group Restriction", "", pick: false, 0, "", "");
		P("string", 20, "Plural Name", "", pick: false, 0, "", "");
		P("string", 21, "Monarch Name", "", pick: false, 1, "", "");
		P("string", 22, "Activation Failure", "", pick: false, 0, "", "");
		P("string", 23, "Scribe Account", "", pick: false, 1, "", "");
		P("string", 24, "Town Name", "", pick: false, 0, "", "");
		P("string", 25, "Only Activated By", "Item", pick: true, 1, "", "");
		P("string", 26, "Use Pk Server Error", "", pick: false, 0, "", "");
		P("string", 27, "Score Cached Text", "", pick: false, 0, "", "");
		P("string", 28, "Score Default Entry Format", "", pick: false, 0, "", "");
		P("string", 29, "Score First Entry Format", "", pick: false, 0, "", "");
		P("string", 30, "Score Last Entry Format", "", pick: false, 0, "", "");
		P("string", 31, "Score Only Entry Format", "", pick: false, 0, "", "");
		P("string", 32, "Score No Entry", "", pick: false, 0, "", "");
		P("string", 33, "Quest", "", pick: false, 0, "", "");
		P("string", 34, "Generator Event", "", pick: false, 0, "", "");
		P("string", 35, "Patron", "", pick: false, 0, "", "");
		P("string", 36, "House Owner Name", "", pick: false, 0, "", "");
		P("string", 37, "Quest Restriction", "", pick: false, 0, "", "");
		P("string", 38, "Portal Destination", "Item", pick: true, 1, "", "");
		P("string", 39, "Last Tinkered By", "Item", pick: true, 1, "", "");
		P("string", 40, "Imbued By", "Item", pick: true, 1, "", "");
		P("string", 41, "House Owner Account", "", pick: false, 0, "", "");
		P("string", 42, "Display Name", "", pick: false, 0, "", "");
		P("string", 43, "Date Born", "", pick: false, 1, "", "");
		P("string", 44, "Third Party Api", "", pick: false, 0, "", "");
		P("string", 45, "Kill Quest", "", pick: false, 0, "", "");
		P("string", 46, "Afk", "", pick: false, 0, "", "");
		P("string", 47, "Allegiance Name", "", pick: false, 1, "", "");
		P("string", 48, "Augmentation Add Quest", "", pick: false, 0, "", "");
		P("string", 49, "Kill Quest2", "", pick: false, 0, "", "");
		P("string", 50, "Kill Quest3", "", pick: false, 0, "", "");
		P("string", 51, "Use Sends Signal", "", pick: false, 0, "", "");
		P("string", 52, "Gear Plating Name", "", pick: false, 1, "", "");
		P("string", 8006, "PCAP Recorded Current Motion State", "", pick: false, 0, "", "");
		P("string", 8031, "PCAP Recorded Server Name", "", pick: false, 0, "", "");
		P("string", 8032, "PCAP Recorded Character Name", "", pick: false, 0, "", "");
		P("string", 9001, "Allegiance Motd", "", pick: false, 0, "", "");
		P("string", 9002, "Allegiance Motd Set By", "", pick: false, 0, "", "");
		P("string", 9003, "Allegiance Speaker Title", "", pick: false, 0, "", "");
		P("string", 9004, "Allegiance Seneschal Title", "", pick: false, 0, "", "");
		P("string", 9005, "Allegiance Castellan Title", "", pick: false, 0, "", "");
		P("string", 9006, "God State", "", pick: false, 0, "", "");
		P("string", 9007, "Tinker Log", "", pick: false, 0, "", "");
		P("string", 9008, "Captured Creatures", "", pick: false, 0, "", "");
		P("string", 9009, "Captured Creature Name", "", pick: false, 0, "", "");
		P("string", 9010, "Captured Items", "", pick: false, 0, "", "");
		P("string", 9011, "Captured Obj Desc Anim Parts", "", pick: false, 0, "", "");
		P("string", 9012, "Captured Obj Desc Palettes", "", pick: false, 0, "", "");
		P("string", 9013, "Captured Obj Desc Textures", "", pick: false, 0, "", "");
		P("string", 9014, "Friend Type String", "", pick: false, 0, "", "");
		P("string", 9015, "Foe Type String", "", pick: false, 0, "", "");
		P("string", 9016, "Friendly Quest String", "", pick: false, 0, "", "");
		P("string", 9017, "Spell Suppression Message", "", pick: false, 0, "", "");
		P("string", 9018, "Pet Custom Name", "", pick: false, 0, "", "");
		P("string", 50100, "Zc Modifiers", "", pick: false, 0, "", "");
		P("string", 50500, "Room Assign Rooms", "", pick: false, 0, "", "");
		P("string", 50504, "Room Assign Bounty", "", pick: false, 0, "", "");
		P("string", 50505, "Bounty Progress", "", pick: false, 0, "", "");
		P("string", 50506, "Bounty Owed", "", pick: false, 0, "", "");
		P("string", 184549376, "Secondary Name", "", pick: false, 1, "", "");
	}
}
