using System;
using Decal.Adapter.Wrappers;

namespace MelkTank.Loot;

public static class Character
{
	public static int Level()
	{
		try
		{
			return Globals.Core.CharacterFilter.Level;
		}
		catch
		{
			return 0;
		}
	}

	public static int EffectiveSkill(int id)
	{
		try
		{
			return Globals.Core.CharacterFilter.EffectiveSkill[(CharFilterSkillType)id];
		}
		catch
		{
			return 0;
		}
	}

	public static int BaseSkill(int id)
	{
		try
		{
			return Globals.Core.CharacterFilter.Skills[(CharFilterSkillType)id].Base;
		}
		catch
		{
			return 0;
		}
	}

	public static int AllPacksFreeSlots()
	{
		int num = MainPackFreeSlots();
		try
		{
			int id = Globals.Core.CharacterFilter.Id;
			foreach (WorldObject item in Globals.Core.WorldFilter.GetByContainer(id))
			{
				if (item.ObjectClass != ObjectClass.Container)
				{
					continue;
				}
				int num2 = LootMatcher.Long(item, 218103812);
				if (num2 <= 0)
				{
					num2 = 24;
				}
				int num3 = 0;
				foreach (WorldObject item2 in Globals.Core.WorldFilter.GetByContainer(item.Id))
				{
					num3++;
				}
				num += Math.Max(0, num2 - num3);
			}
		}
		catch
		{
		}
		return num;
	}

	public static int MainPackFreeSlots()
	{
		try
		{
			int id = Globals.Core.CharacterFilter.Id;
			int num = 0;
			WorldObject worldObject = Globals.Core.WorldFilter[id];
			if (worldObject != null)
			{
				num = LootMatcher.Long(worldObject, 218103812);
			}
			if (num <= 0)
			{
				num = 102;
			}
			int num2 = 0;
			foreach (WorldObject item in Globals.Core.WorldFilter.GetByContainer(id))
			{
				if (item.ObjectClass != ObjectClass.Container && item.ObjectClass != ObjectClass.Foci && LootMatcher.Long(item, 218103818) != id && LootMatcher.Long(item, 10) == 0)
				{
					num2++;
				}
			}
			return Math.Max(0, num - num2);
		}
		catch
		{
			return 99;
		}
	}
}
