using System.Collections.Generic;

namespace MelkTank.Loot;

public class ReqRow
{
	public FieldDef F;

	public int? Key;

	public string Op;

	public List<string> V = new List<string>();

	public List<KeyValuePair<string, string>> P = new List<KeyValuePair<string, string>>();

	public string Where;

	public string Get(string k)
	{
		foreach (KeyValuePair<string, string> item in P)
		{
			if (item.Key == k)
			{
				return item.Value;
			}
		}
		return null;
	}

	public void Set(string k, string v)
	{
		for (int i = 0; i < P.Count; i++)
		{
			if (P[i].Key == k)
			{
				P[i] = new KeyValuePair<string, string>(k, v);
				return;
			}
		}
		P.Add(new KeyValuePair<string, string>(k, v));
	}

	public string Val(int i)
	{
		while (V.Count <= i)
		{
			V.Add("");
		}
		return V[i];
	}
}
