using System;
using System.Collections.Generic;
using System.Reflection;
using Decal.Adapter.Wrappers;

namespace MelkTank.Loot;

public static class SpellNames
{
	private static object _table;

	private static MethodInfo _getById;

	private static bool _tried;

	public static List<string> Of(WorldObject o)
	{
		List<string> list = new List<string>();
		List<int> list2 = GearSnap.Spells(o);
		if (list2 != null)
		{
			foreach (int item in list2)
			{
				string text = Name(item);
				if (text != null)
				{
					list.Add(text);
				}
			}
			return list;
		}
		try
		{
			int spellCount = o.SpellCount;
			for (int i = 0; i < spellCount; i++)
			{
				string text2 = Name(o.Spell(i));
				if (text2 != null)
				{
					list.Add(text2);
				}
			}
		}
		catch
		{
		}
		return list;
	}

	public static string Name(int id)
	{
		try
		{
			if (!_tried)
			{
				_tried = true;
				object obj = Util.TryGetProperty(Globals.Core, "FileService");
				if (obj == null)
				{
					Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
					foreach (Assembly assembly in assemblies)
					{
						Type type = assembly.GetType("Decal.Filters.FileService");
						if (!(type == null))
						{
							MethodInfo method = Globals.Core.GetType().GetMethod("Filter");
							if (method != null)
							{
								obj = method.MakeGenericMethod(type).Invoke(Globals.Core, null);
							}
							break;
						}
					}
				}
				_table = Util.TryGetProperty(obj, "SpellTable");
				if (_table != null)
				{
					_getById = _table.GetType().GetMethod("GetById", new Type[1] { typeof(int) });
				}
			}
			if (_getById == null)
			{
				return null;
			}
			object target = _getById.Invoke(_table, new object[1] { id });
			return Util.TryGetProperty(target, "Name") as string;
		}
		catch
		{
			return null;
		}
	}

	public static object Prop(int id, string prop)
	{
		try
		{
			if (Name(id) == null || _getById == null)
			{
				return null;
			}
			object target = _getById.Invoke(_table, new object[1] { id });
			return Util.TryGetProperty(target, prop);
		}
		catch
		{
			return null;
		}
	}

	public static int Icon(int id)
	{
		try
		{
			if (Name(id) == null || _getById == null)
			{
				return 0;
			}
			object target = _getById.Invoke(_table, new object[1] { id });
			object obj = Util.TryGetProperty(target, "IconId") ?? Util.TryGetProperty(target, "Icon");
			return (obj is int) ? ((int)obj) : ((int)((obj is uint) ? ((uint)obj) : 0));
		}
		catch
		{
			return 0;
		}
	}
}
