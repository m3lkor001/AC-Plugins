using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using Decal.Adapter.Wrappers;

namespace MelkTank.Loot;

public static class ArmorCompare
{
	private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

	private const int ValidSlots = 218103822;

	private const int WornSlots = 10;

	private const int T11Max = 69;

	private static readonly string[] Names = new string[4] { "Damage Resist", "Damage Rating", "Crit Damage Rating", "All Attributes" };

	private static readonly string[] Short = new string[4] { "DR", "D", "CD", "Attr" };

	private static readonly Regex Line = new Regex("^(Damage Resist|Damage Rating|Crit Damage Rating|All Attributes) \\+(\\d+)(?:\\s*\\[(\\d+)\\s*-\\s*(\\d+)\\])?");

	private static readonly Dictionary<int, DateTime> _askedAt = new Dictionary<int, DateTime>();

	private static Dictionary<int, string> _full;

	private static Dictionary<int, string> _owner;

	private static readonly Dictionary<int, string> _seen = new Dictionary<int, string>();

	private static readonly Queue<int> _seenOrder = new Queue<int>();

	private static DateTime _seenCheckAt = DateTime.MinValue;

	private static readonly int[] SlotBits = new int[22]
	{
		1, 32, 256, 512, 1024, 2048, 4096, 8192, 16384, 2,
		4, 8, 16, 64, 128, 32768, 65536, 131072, 262144, 524288,
		67108864, 134217728
	};

	private static readonly string[] SlotNames = new string[22]
	{
		"Head", "Hands", "Feet", "Chest", "Abdomen", "Upper arms", "Lower arms", "Upper legs", "Lower legs", "Chest (under)",
		"Abdomen (under)", "Upper arms (under)", "Lower arms (under)", "Upper legs (under)", "Lower legs (under)", "Necklace", "Right bracelet", "Left bracelet", "Right ring", "Left ring",
		"Trinket", "Cloak"
	};

	private const int ShieldSlot = 2097152;

	public static Func<IEnumerable<int>> ListedShields;

	private static DateTime _wornAskAt = DateTime.MinValue;

	private const int UnderTop = 26;

	private const int UnderBottom = 196;

	private const int Feet = 256;

	private const int ChestA = 512;

	private const int AbdomenA = 1024;

	private const int UpperArmA = 2048;

	private const int LowerArmA = 4096;

	private const int UpperLegA = 8192;

	private const int LowerLegA = 16384;

	private static string FullFile => Util.FullPath("MelkTank_ZoneMods.txt");

	private static string Me
	{
		get
		{
			try
			{
				return Globals.Core.CharacterFilter.Name ?? "";
			}
			catch
			{
				return "";
			}
		}
	}

	private static int TierMax(int tier)
	{
		return (tier >= 11) ? (69 + 5 * (tier - 11)) : 69;
	}

	private static int ZoneTier()
	{
		try
		{
			int num = Session.CurrentTier();
			return (num >= 11) ? num : 11;
		}
		catch
		{
			return 11;
		}
	}

	private static int[] Maxes(WorldObject o)
	{
		int tier = 0;
		try
		{
			tier = LootMatcher.Long(o, 50109);
		}
		catch
		{
		}
		int num = TierMax(tier);
		int[] array = new int[4] { -1, -1, -1, -1 };
		string text = ModText(o, out var _);
		string[] array2 = new string[2]
		{
			text,
			LootMatcher.Str(o, 16) ?? ""
		};
		foreach (string text2 in array2)
		{
			string[] array3 = text2.Replace("\r", "").Split('\n');
			foreach (string text3 in array3)
			{
				string text4 = text3.Trim();
				if (!text4.StartsWith("- "))
				{
					continue;
				}
				Match match = Line.Match(text4.Substring(2).Trim());
				if (match.Success && match.Groups[4].Success)
				{
					int num2 = Array.IndexOf(Names, match.Groups[1].Value);
					if (num2 >= 0 && array[num2] < 0 && int.TryParse(match.Groups[4].Value, NumberStyles.Integer, Inv, out var result) && result > 0)
					{
						array[num2] = result;
						num = Math.Max(num, result);
					}
				}
			}
		}
		for (int k = 0; k < 4; k++)
		{
			if (array[k] < 0)
			{
				array[k] = num;
			}
		}
		return array;
	}

	private static int Scale(WorldObject o)
	{
		int num = 0;
		if (o != null)
		{
			int[] array = Maxes(o);
			foreach (int num2 in array)
			{
				num += num2;
			}
		}
		return Math.Max(num, 4 * TierMax(ZoneTier()));
	}

	private static bool Ask(int id)
	{
		if (GearSnap.Has(id))
		{
			if (_askedAt.ContainsKey(id))
			{
				return false;
			}
			_askedAt[id] = DateTime.Now;
			return true;
		}
		if (_askedAt.TryGetValue(id, out var value) && (DateTime.Now - value).TotalSeconds < 10.0)
		{
			return false;
		}
		_askedAt[id] = DateTime.Now;
		return true;
	}

	public static bool IsGear(WorldObject o)
	{
		ObjectClass objectClass = o.ObjectClass;
		return objectClass == ObjectClass.Armor || objectClass == ObjectClass.Jewelry || objectClass == ObjectClass.Clothing;
	}

	public static bool PowerReduced(string text)
	{
		return (text ?? "").IndexOf("Power Reduced", StringComparison.OrdinalIgnoreCase) >= 0;
	}

	private static bool Mine(WorldObject o)
	{
		try
		{
			int id = Globals.Core.CharacterFilter.Id;
			int container = o.Container;
			if (container == id || o.Values(LongValueKey.Wielder, 0) == id)
			{
				return true;
			}
			WorldObject worldObject = ((container != 0) ? Globals.Core.WorldFilter[container] : null);
			return worldObject != null && worldObject.Container == id;
		}
		catch
		{
			return false;
		}
	}

	private static void LoadFull()
	{
		if (_full != null)
		{
			return;
		}
		_full = new Dictionary<int, string>();
		_owner = new Dictionary<int, string>();
		try
		{
			string f = FullFile;
			if (!File.Exists(f))
			{
				return;
			}
			string[] array = Util.Locked(f, () => File.ReadAllLines(f));
			foreach (string text in array)
			{
				string[] array2 = text.Split(new char[1] { '\t' }, 3);
				if (array2.Length >= 2 && int.TryParse(array2[0], out var result))
				{
					if (array2.Length == 3)
					{
						_owner[result] = array2[1];
						_full[result] = array2[2].Replace("\\n", "\n");
					}
					else
					{
						_owner[result] = "";
						_full[result] = array2[1].Replace("\\n", "\n");
					}
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void NoteFullMods(WorldObject o)
	{
		try
		{
			if (o == null || !IsGear(o))
			{
				return;
			}
			string text = LootMatcher.LiveStr(o, 14);
			if (string.IsNullOrEmpty(text) || PowerReduced(text) || !HasModLine(text))
			{
				return;
			}
			if (!Mine(o))
			{
				if (!_seen.ContainsKey(o.Id))
				{
					_seenOrder.Enqueue(o.Id);
					while (_seenOrder.Count > 400)
					{
						_seen.Remove(_seenOrder.Dequeue());
					}
				}
				_seen[o.Id] = text;
			}
			else
			{
				Keep(o.Id, text);
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void ZoneTick()
	{
		if (DateTime.Now < _seenCheckAt || _seen.Count == 0)
		{
			return;
		}
		_seenCheckAt = DateTime.Now.AddSeconds(10.0);
		List<int> list = null;
		foreach (KeyValuePair<int, string> item in _seen)
		{
			WorldObject worldObject = Globals.Core.WorldFilter[item.Key];
			if (worldObject != null && Mine(worldObject))
			{
				(list ?? (list = new List<int>())).Add(item.Key);
			}
		}
		if (list == null)
		{
			return;
		}
		foreach (int item2 in list)
		{
			string t = _seen[item2];
			_seen.Remove(item2);
			Keep(item2, t);
		}
	}

	private static void Keep(int id, string t)
	{
		LoadFull();
		string me = Me;
		if (_full.TryGetValue(id, out var value) && value == t && _owner.TryGetValue(id, out var value2) && value2 == me)
		{
			return;
		}
		_full[id] = t;
		_owner[id] = me;
		HashSet<int> hashSet = new HashSet<int>();
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				hashSet.Add(item.Id);
			}
		}
		catch
		{
		}
		List<int> list = new List<int>();
		foreach (KeyValuePair<int, string> item2 in _owner)
		{
			if ((item2.Value == me || item2.Value.Length == 0) && hashSet.Count > 0 && !hashSet.Contains(item2.Key))
			{
				list.Add(item2.Key);
			}
		}
		foreach (int item3 in list)
		{
			_full.Remove(item3);
			_owner.Remove(item3);
		}
		foreach (int item4 in new List<int>(_owner.Keys))
		{
			if (_owner[item4].Length == 0)
			{
				_owner[item4] = me;
			}
		}
		StringBuilder stringBuilder = new StringBuilder();
		foreach (KeyValuePair<int, string> item5 in _full)
		{
			stringBuilder.Append(item5.Key).Append('\t').Append(_owner[item5.Key])
				.Append('\t')
				.Append(item5.Value.Replace("\r", "").Replace("\n", "\\n"))
				.Append("\r\n");
		}
		Util.WriteShared(FullFile, stringBuilder.ToString());
	}

	private static string FirstModLine(string t)
	{
		string[] array = (t ?? "").Replace("\r", "").Split('\n');
		foreach (string text in array)
		{
			string text2 = text.Trim();
			if (text2.StartsWith("- ") && Line.IsMatch(text2.Substring(2).Trim()))
			{
				return text2.Substring(2).Trim();
			}
		}
		return "";
	}

	private static bool HasModLine(string t)
	{
		return FirstModLine(t).Length > 0;
	}

	private static string ModText(WorldObject o, out bool reduced)
	{
		reduced = false;
		string text = LootMatcher.Str(o, 14) ?? "";
		if (!PowerReduced(text))
		{
			return text;
		}
		LoadFull();
		if (_full.TryGetValue(o.Id, out var value))
		{
			return value;
		}
		if (_seen.TryGetValue(o.Id, out value))
		{
			return value;
		}
		reduced = true;
		return text;
	}

	public static bool Reduced(WorldObject o)
	{
		ModText(o, out var reduced);
		return reduced;
	}

	public static int[] Mods(WorldObject o)
	{
		int[] array = new int[4] { -1, -1, -1, -1 };
		string text = ModText(o, out var _);
		string[] array2 = new string[2]
		{
			text,
			LootMatcher.Str(o, 16) ?? ""
		};
		foreach (string text2 in array2)
		{
			string[] array3 = text2.Replace("\r", "").Split('\n');
			foreach (string text3 in array3)
			{
				string text4 = text3.Trim();
				if (!text4.StartsWith("- "))
				{
					continue;
				}
				Match match = Line.Match(text4.Substring(2).Trim());
				if (match.Success)
				{
					int num = Array.IndexOf(Names, match.Groups[1].Value);
					if (num >= 0 && array[num] < 0 && int.TryParse(match.Groups[2].Value, NumberStyles.Integer, Inv, out var result))
					{
						array[num] = result;
					}
				}
			}
		}
		return array;
	}

	private static string SlotName(int mask)
	{
		List<string> list = new List<string>();
		for (int i = 0; i < SlotBits.Length; i++)
		{
			if ((mask & SlotBits[i]) != 0)
			{
				list.Add(SlotNames[i]);
			}
		}
		return (list.Count > 0) ? string.Join(" / ", list.ToArray()) : ("slot " + mask);
	}

	private static List<WorldObject> Rivals(WorldObject o, out bool waiting, out bool fromList)
	{
		waiting = false;
		fromList = false;
		List<WorldObject> list = new List<WorldObject>();
		int num = Reduced(LootMatcher.Long(o, 218103822));
		if (num == 0)
		{
			return list;
		}
		List<WorldObject> list2 = new List<WorldObject>();
		if ((num & 0x200000) != 0 && ListedShields != null)
		{
			foreach (int item in ListedShields())
			{
				WorldObject worldObject = ((item != o.Id) ? Globals.Core.WorldFilter[item] : null);
				if (worldObject != null)
				{
					list2.Add(worldObject);
					fromList = true;
					break;
				}
			}
		}
		if (!fromList)
		{
			foreach (WorldObject item2 in InvCache.All())
			{
				if (item2.Id != o.Id && SameSpot(num, LootMatcher.Long(item2, 10)))
				{
					list2.Add(item2);
				}
			}
		}
		foreach (WorldObject item3 in list2)
		{
			if (!GearSnap.Known(item3))
			{
				waiting = true;
				if (Ask(item3.Id))
				{
					try
					{
						Util.RequestId(item3.Id);
					}
					catch
					{
					}
				}
			}
			else
			{
				list.Add(item3);
			}
		}
		// a worn piece with a slot special (Regeneration bracers ...) is only up against an item with the same special
		_keptSpecial = null;
		Settings s = PluginCore.CurrentSettings;
		if (s != null && s.CompareKeepSpecial && list.Count > 0)
		{
			HashSet<string> mine = Specials(o);
			for (int i = list.Count - 1; i >= 0; i--)
			{
				HashSet<string> theirs = Specials(list[i]);
				if (theirs.Count == 0)
				{
					continue;
				}
				bool all = true;
				foreach (string sp in theirs)
				{
					if (!mine.Contains(sp))
					{
						all = false;
					}
				}
				if (!all)
				{
					_keptSpecial = (_keptSpecial == null ? "" : _keptSpecial + ", ") + string.Join("/", new List<string>(theirs).ToArray()) + " " + SlotName(LootMatcher.Long(list[i], 10));
					list.RemoveAt(i);
				}
			}
		}
		return list;
	}

	// the worn pieces left out last time (their special kept), for the line
	private static string _keptSpecial;

	/// <summary>The worn special pieces the last Estimate left the item out against (null: none).</summary>
	public static string KeptSpecial;

	/// <summary>The slot specials an item has (read from its Modifiers lines): "Regeneration", "Fortify Vitals" ...</summary>
	public static HashSet<string> Specials(WorldObject o)
	{
		HashSet<string> set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		string text = LootMatcher.Str(o, 14) ?? "";
		if (text.Length == 0)
		{
			return set;
		}
		foreach (ModDef m in LootFields.Mods)
		{
			if (m.Special != null && text.IndexOf("- " + m.Name, StringComparison.OrdinalIgnoreCase) >= 0)
			{
				set.Add(m.Name);
			}
		}
		return set;
	}

	public static bool Estimate(WorldObject o, out double pct, out double diff)
	{
		pct = (diff = 0.0);
		if (o == null || !IsGear(o) || LootMatcher.Long(o, 10) != 0)
		{
			return false;
		}
		int[] v = Mods(o);
		int num = Total(v);
		if (num == 0)
		{
			return false;
		}
		int num2 = Scale(o);
		pct = 100.0 * (double)num / (double)num2;
		List<WorldObject> list = Rivals(o, out var waiting, out var _);
		if (waiting)
		{
			return false;
		}
		// a worn special piece (Regeneration bracers ...) it would take the place of: never better (Keep special
		// pieces) - it was put up against nothing for that slot, so anything at all read as an upgrade
		KeptSpecial = _keptSpecial;
		if (_keptSpecial != null)
		{
			diff = -100.0;
			return true;
		}
		int num3 = -1;
		foreach (WorldObject item in list)
		{
			int num4 = Total(Mods(item));
			if (num3 < 0 || num4 < num3)
			{
				num3 = num4;
			}
		}
		diff = pct - 100.0 * (double)Math.Max(0, num3) / (double)num2;
		return true;
	}

	public static bool SlotsMaxed(WorldObject o, int pct, out string why)
	{
		why = null;
		if (o == null || pct <= 0 || !IsGear(o) || LootMatcher.Long(o, 10) != 0)
		{
			return false;
		}
		List<WorldObject> list = Rivals(o, out var waiting, out var _);
		if (waiting || list.Count == 0)
		{
			return false;
		}
		WorldObject o2 = null;
		int num = int.MaxValue;
		foreach (WorldObject item in list)
		{
			if (Reduced(item))
			{
				return false;
			}
			int num2 = Total(Mods(item));
			if (num2 < num)
			{
				num = num2;
				o2 = item;
			}
		}
		double num3 = 100.0 * (double)num / (double)Scale(o2);
		if (num3 < (double)pct)
		{
			return false;
		}
		why = "you wear " + ItemReport.FullName(o2) + " there at " + num3.ToString("0", Inv) + "% (" + SlotName(LootMatcher.Long(o2, 10)) + ")";
		return true;
	}

	public static void RequestWorn()
	{
		if (DateTime.Now < _wornAskAt)
		{
			return;
		}
		_wornAskAt = DateTime.Now.AddSeconds(10.0);
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (IsGear(item) && LootMatcher.Long(item, 10) != 0 && !item.HasIdData && Ask(item.Id))
				{
					Util.RequestId(item.Id);
				}
			}
			if (ListedShields == null)
			{
				return;
			}
			foreach (int item2 in ListedShields())
			{
				WorldObject worldObject = Globals.Core.WorldFilter[item2];
				if (worldObject != null && !worldObject.HasIdData && Ask(item2))
				{
					Util.RequestId(item2);
				}
			}
		}
		catch
		{
		}
	}

	private static int Kind(int mask)
	{
		if ((mask & 0x100) != 0)
		{
			return 3;
		}
		if ((mask & -223) != 0)
		{
			return 0;
		}
		if ((mask & 0x1A) != 0)
		{
			return 1;
		}
		return ((mask & 0xC4) != 0) ? 2 : 0;
	}

	private static bool SameSpot(int slots, int worn)
	{
		if (worn == 0 || slots == 0)
		{
			return false;
		}
		int num = Kind(slots);
		int num2 = Kind(worn);
		if (num != 0 || num2 != 0)
		{
			return num == num2;
		}
		return (slots & worn) != 0;
	}

	private static int Reduced(int slots)
	{
		int num = slots & 0x7E00;
		if (num == 0 || (num & (num - 1)) == 0)
		{
			return slots;
		}
		if ((num & 0x200) != 0)
		{
			return 512;
		}
		return num;
	}

	private static int Total(int[] v)
	{
		int num = 0;
		foreach (int num2 in v)
		{
			if (num2 > 0)
			{
				num += num2;
			}
		}
		return num;
	}

	private static string Pct(int n, int max)
	{
		return ((int)Math.Round(100.0 * (double)n / (double)Math.Max(1, max))).ToString(Inv) + "%";
	}

	public static string Describe(WorldObject o, out int color)
	{
		color = 7;
		if (o == null || !IsGear(o) || LootMatcher.Long(o, 10) != 0)
		{
			return null;
		}
		int[] array = Mods(o);
		bool flag = Reduced(o);
		if (Total(array) == 0 && !flag)
		{
			return null;
		}
		List<WorldObject> list = Rivals(o, out var waiting, out var fromList);
		WorldObject worldObject = null;
		int[] array2 = null;
		foreach (WorldObject item in list)
		{
			int[] array3 = Mods(item);
			if (worldObject == null || Total(array3) < Total(array2))
			{
				worldObject = item;
				array2 = array3;
			}
		}
		int[] array4 = Maxes(o);
		int num = Scale(o);
		List<string> list2 = new List<string>();
		int num2 = 0;
		int num3 = 0;
		for (int i = 0; i < 4; i++)
		{
			int num4 = array[i];
			int num5 = ((array2 != null) ? array2[i] : (-1));
			if (num4 < 0 && num5 < 0)
			{
				continue;
			}
			string text = Short[i] + " " + ((num4 >= 0) ? (num4 + " (" + Pct(num4, array4[i]) + ")") : "-");
			if (array2 != null)
			{
				int num6 = Math.Max(0, num4) - Math.Max(0, num5);
				if (num6 > 0)
				{
					num2++;
				}
				else if (num6 < 0)
				{
					num3++;
				}
				text = text + " vs " + ((num5 >= 0) ? num5.ToString(Inv) : "-") + " (" + ((num6 == 0) ? "=" : (((num6 > 0) ? "+" : "") + num6)) + ")";
			}
			list2.Add(text);
		}
		int num7 = Total(array);
		string text2 = "total " + num7 + "/" + num + " " + (int)Math.Round(100.0 * (double)num7 / (double)num) + "%";
		if (array2 != null)
		{
			int num8 = Total(array2);
			int num9 = (int)Math.Round(100.0 * (double)num7 / (double)num) - (int)Math.Round(100.0 * (double)num8 / (double)num);
			text2 = text2 + " vs " + num8 + " " + (int)Math.Round(100.0 * (double)num8 / (double)num) + "% (" + ((num9 == 0) ? "=" : (((num9 > 0) ? "+" : "") + num9 + "%")) + ")";
			ref int reference = ref color;
			int num10;
			if (num7 <= num8)
			{
				if (num7 >= num8)
				{
					num10 = ((num2 > 0 && num3 > 0) ? 8 : 7);
				}
				else
				{
					num10 = ((num2 == 0) ? 15 : 8);
				}
			}
			else
			{
				num10 = ((num3 == 0) ? 10 : 18);
			}
			reference = num10;
		}
		string text3 = "";
		if (worldObject != null)
		{
			text3 = " (" + SlotName(LootMatcher.Long(worldObject, 10));
			if (list.Count > 1)
			{
				List<string> list3 = new List<string>();
				foreach (WorldObject item2 in list)
				{
					if (item2.Id != worldObject.Id)
					{
						list3.Add(SlotName(LootMatcher.Long(item2, 10)) + " " + Total(Mods(item2)));
					}
				}
				text3 = text3 + " - weakest of " + list.Count + " it can go in; " + string.Join(", ", list3.ToArray());
			}
			text3 += ")";
		}
		if (flag)
		{
			color = 7;
			string text4 = "";
			Match match = Regex.Match(LootMatcher.Str(o, 16) ?? "", "Location: ([^\\r\\n]+)");
			if (match.Success)
			{
				text4 = " (" + match.Groups[1].Value.Trim() + ")";
			}
			return "Zone locked (power reduced) here - its real modifiers weren't seen in its zone" + text4 + ", so it can't be compared. ID it there once.";
		}
		if (worldObject != null && Reduced(worldObject))
		{
			text3 += " - zone locked here, real numbers not known: shown as 0";
		}
		if ((worldObject != null) & fromList)
		{
			text3 = ((LootMatcher.Long(worldObject, 10) != 0) ? " (your shield)" : " (your shield, in your pack)");
		}
		if (worldObject != null && _keptSpecial != null)
		{
			text3 += " (your " + _keptSpecial + " kept: this hasn't its special)";
		}
		string text5;
		if (worldObject != null)
		{
			text5 = ((fromList && LootMatcher.Long(worldObject, 10) == 0) ? "vs " : "vs equipped ") + ItemReport.FullName(worldObject) + text3;
		}
		else
		{
			text5 = (waiting ? "vs equipped (identifying yours - ID this again in a moment)" : (_keptSpecial != null ? "vs max (your " + _keptSpecial + " kept - this hasn't its special)" : "vs max (nothing worn there)"));
		}

		string text6 = LootFields.CloakProc(o);
		string text7 = ((worldObject != null) ? LootFields.CloakProc(worldObject) : null);
		string text8 = ((text6 != null || text7 != null) ? (" | " + (text6 ?? "no proc") + ((worldObject != null) ? (" vs " + (text7 ?? "no proc")) : "")) : "");
		return text5 + ": " + string.Join(", ", list2.ToArray()) + " | " + text2 + text8;
	}
}
