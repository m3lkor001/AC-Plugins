using System;
using System.Collections.Generic;
using System.Globalization;
using Decal.Adapter.Wrappers;

namespace MelkTank.Loot;

public static class LootWhy
{
	private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

	public static void Run(string filter)
	{
		Looter current = Looter.Current;
		int currentSelection = Globals.Core.Actions.CurrentSelection;
		WorldObject worldObject = ((currentSelection != 0) ? Globals.Core.WorldFilter[currentSelection] : null);
		if (current == null)
		{
			Util.WriteToChat("Why: looting isn't set up yet.");
			return;
		}
		if (worldObject == null)
		{
			Util.WriteToChat("Why: select an item first (and ID it).");
			return;
		}
		if (!worldObject.HasIdData)
		{
			Util.WriteToChat("Why: " + ItemReport.FullName(worldObject) + " isn't identified yet - ID it for a full answer.");
		}
		filter = (filter ?? "").Trim();
		List<int> list = new List<int>();
		if (current.SlotOn(0))
		{
			list.Add(0);
		}
		else
		{
			int num = Looter.SlotFor(worldObject);
			if (current.SlotOn(num))
			{
				list.Add(num);
			}
			if (current.SlotOn(4))
			{
				list.Add(4);
			}
		}
		if (list.Count == 0)
		{
			Util.WriteToChat("Why: no loot profile is ticked for a " + Looter.SlotNames[Looter.SlotFor(worldObject)] + " item.");
			return;
		}
		int num2 = 0;
		foreach (int item in list)
		{
			string text = current.SlotFile(item);
			UtlProfile utlProfile = current.SlotProfile(item);
			if (utlProfile == null)
			{
				Util.WriteToChat("Why: " + Looter.SlotNames[item] + " profile " + ((text.Length > 0) ? text : "(none)") + " isn't loaded.");
				continue;
			}
			int num3 = -1;
			for (int i = 0; i < utlProfile.Rules.Count; i++)
			{
				if (!utlProfile.Rules[i].Off && LootMatcher.RuleMatches(utlProfile.Rules[i], worldObject))
				{
					num3 = i;
					break;
				}
			}
			Util.WriteToChat("Why " + ItemReport.FullName(worldObject) + " - " + Looter.SlotNames[item] + " profile " + text + ": " + ((num3 < 0) ? "no rule matches." : ("rule #" + (num3 + 1) + " \"" + utlProfile.Rules[num3].Name.Trim() + "\" (" + Act(utlProfile.Rules[num3]) + ") decides it.")));
			if (filter.Length == 0)
			{
				if (num3 >= 0)
				{
					Explain(utlProfile, num3, worldObject, num3);
				}
				continue;
			}
			for (int j = 0; j < utlProfile.Rules.Count; j++)
			{
				UtlRule utlRule = utlProfile.Rules[j];
				if (!utlRule.IsSection && !utlRule.IsSpacer && utlRule.Name.IndexOf(filter, StringComparison.OrdinalIgnoreCase) >= 0)
				{
					if (++num2 > 12)
					{
						Util.WriteToChat("  ... more rules match \"" + filter + "\" - use more of the name.");
						break;
					}
					Explain(utlProfile, j, worldObject, num3);
				}
			}
		}
		if (filter.Length > 0 && num2 == 0)
		{
			Util.WriteToChat("Why: no rule named like \"" + filter + "\".");
		}
		else if (filter.Length == 0)
		{
			Util.WriteToChat("  (/mtank why <part of a rule name> shows why that rule didn't match)");
		}
	}

	private static void Explain(UtlProfile p, int i, WorldObject o, int decider)
	{
		UtlRule utlRule = p.Rules[i];
		bool flag = true;
		List<string> list = new List<string>();
		foreach (UtlReq req in utlRule.Reqs)
		{
			if (!UtlReq.Flag(req.Type))
			{
				bool flag2;
				try
				{
					flag2 = LootMatcher.ReqMatches(req, o);
				}
				catch
				{
					flag2 = false;
				}
				if (!flag2)
				{
					flag = false;
				}
				list.Add((flag2 ? "[OK] " : "[NO] ") + Say(req) + ItemValue(req, o));
			}
		}
		string text;
		if (utlRule.Off)
		{
			text = "switched off";
		}
		else if (flag)
		{
			if (i == decider)
			{
				text = "matches - decides it";
			}
			else
			{
				text = ((decider >= 0 && decider < i) ? ("matches, but rule #" + (decider + 1) + " comes first") : "matches");
			}
		}
		else
		{
			text = "doesn't match";
		}
		Util.WriteToChat("  #" + (i + 1) + " \"" + utlRule.Name.Trim() + "\" (" + Act(utlRule) + "): " + text);
		if (list.Count == 0)
		{
			Util.WriteToChat("      (no requirements - matches everything)");
		}
		foreach (string item in list)
		{
			Util.WriteToChat("      " + item);
		}
	}

	private static string Act(UtlRule r)
	{
		if (r.Act == "10")
		{
			return "Keep " + (r.KeepN ?? "1") + (r.KeepEach ? " of each" : "");
		}
		if (r.Act == "5")
		{
			return "Chunk";
		}
		if (r.Act == "6")
		{
			return "Reveal";
		}
		return UtlSpec.ActionName(r.Act);
	}

	private static string Say(UtlReq q)
	{
		try
		{
			ReqRow reqRow = LootFields.ToRow(q);
			if (reqRow != null)
			{
				return LootFields.RowSay(reqRow);
			}
		}
		catch
		{
		}
		return "type " + q.Type + " " + ((q.Vals != null) ? string.Join(" ", q.Vals.ToArray()) : "");
	}

	private static string ItemValue(UtlReq q, WorldObject o)
	{
		try
		{
			Func<int, string> func = (int i) => (q.Vals != null && i < q.Vals.Count) ? q.Vals[i] : "";
			int result;
			switch (q.Type)
			{
			case "2":
			case "3":
			case "11":
			case "12":
			case "13":
				if (!int.TryParse(func(1), NumberStyles.Integer, Inv, out result))
				{
					return "";
				}
				return "  (item: " + LootMatcher.Long(o, result).ToString(Inv) + ")";
			case "4":
			case "5":
				if (!int.TryParse(func(1), NumberStyles.Integer, Inv, out result))
				{
					return "";
				}
				return "  (item: " + LootMatcher.Dbl(o, result).ToString("0.####", Inv) + ")";
			case "7":
				return "  (item: " + o.ObjectClass.ToString() + ")";
			case "3003":
			case "3004":
			{
				if (!ArmorCompare.Estimate(o, out var pct, out var diff))
				{
					return "  (item: can't tell - " + ((!ArmorCompare.IsGear(o)) ? "not armor / jewelry" : "none of the four mods, or your worn piece isn't identified yet") + ")";
				}
				if (q.Type == "3003" && ArmorCompare.KeptSpecial != null)
				{
					return "  (item: no special - your " + ArmorCompare.KeptSpecial + " is kept)";
				}
				return (q.Type == "3004") ? ("  (item: " + pct.ToString("0", Inv) + "% of max)") : ("  (item: " + diff.ToString("+0;-0;0", Inv) + "% vs worn)");
			}
			case "3001":
			case "3002":
			{
				if (!ItemCompare.Estimate(o, out var overall, out var bestSlayer))
				{
					return "  (item: can't tell - " + ((o.ObjectClass != ObjectClass.WandStaffOrb) ? "not a caster" : "no wielded caster of its element") + ")";
				}
				if (q.Type == "3001")
				{
					return "  (item: " + (overall * 100.0).ToString("+0;-0", Inv) + "%)";
				}
				return (bestSlayer <= -0.999999999) ? "  (item: no slayer on either caster)" : ("  (item: best " + (bestSlayer * 100.0).ToString("+0;-0", Inv) + "%)");
			}
			}
		}
		catch
		{
		}
		return "";
	}
}
