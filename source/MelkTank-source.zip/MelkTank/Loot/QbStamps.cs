using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace MelkTank.Loot;

public static class QbStamps
{
	private static string[] _raw;

	private static List<KeyValuePair<string, string>> _stamps = new List<KeyValuePair<string, string>>();

	private static readonly HashSet<string> Small = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "of", "a", "an", "the", "old" };

	private static readonly HashSet<string> _got = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

	private static readonly Regex StampedRx = new Regex("^You've stamped (\\S+?)!");

	private static string Norm(string s)
	{
		StringBuilder stringBuilder = new StringBuilder();
		string text = (s ?? "").ToLowerInvariant();
		foreach (char c in text)
		{
			if (char.IsLetterOrDigit(c))
			{
				stringBuilder.Append(c);
			}
		}
		return stringBuilder.ToString();
	}

	private static void Refresh()
	{
		string[] array = null;
		try
		{
			array = AppDomain.CurrentDomain.GetData("MelksQB.WantedStamps") as string[];
		}
		catch
		{
		}
		if (array != null && array == _raw)
		{
			return;
		}
		_raw = array;
		List<KeyValuePair<string, string>> list = new List<KeyValuePair<string, string>>();
		if (array != null)
		{
			string[] array2 = array;
			foreach (string text in array2)
			{
				int num = text.IndexOf('|');
				string text2 = ((num >= 0) ? text.Substring(0, num) : text);
				string text3 = ((num >= 0) ? text.Substring(num + 1) : "");
				text3 = text3.Replace('_', ' ');
				if (!_got.Contains(text2))
				{
					string text4 = Norm(text2);
					if (text4.EndsWith("pickup"))
					{
						text4 = text4.Substring(0, text4.Length - 6);
					}
					if (text4.Length >= 6)
					{
						list.Add(new KeyValuePair<string, string>(text4, text2 + ((text3.Length > 0) ? (" (" + text3 + ")") : "")));
					}
				}
			}
		}
		_stamps = list;
	}

	public static void OnChat(string text)
	{
		Match match = StampedRx.Match((text ?? "").Trim());
		if (match.Success && _got.Add(match.Groups[1].Value))
		{
			_raw = null;
		}
	}

	private static string[] _haveRaw;
	private static List<KeyValuePair<string, string>> _have = new List<KeyValuePair<string, string>>();

	/// <summary>The QB stamp an item gives that you have already (MelksQB's "MelksQB.HaveStamps", and those stamped this
	/// session), or null.</summary>
	public static string Collected(string itemName)
	{
		string[] array = null;
		try
		{
			array = AppDomain.CurrentDomain.GetData("MelksQB.HaveStamps") as string[];
		}
		catch
		{
		}
		if (array != _haveRaw || _got.Count != _gotSeen)
		{
			_haveRaw = array;
			_gotSeen = _got.Count;
			List<KeyValuePair<string, string>> list = new List<KeyValuePair<string, string>>();
			foreach (string text in (array ?? new string[0]))
			{
				int num = text.IndexOf('|');
				list.Add(Entry((num >= 0) ? text.Substring(0, num) : text, (num >= 0) ? text.Substring(num + 1) : ""));
			}
			foreach (string g in _got)
			{
				list.Add(Entry(g, ""));
			}
			list.RemoveAll((KeyValuePair<string, string> e) => e.Key.Length < 6);
			_have = list;
		}
		return Find(_have, itemName);
	}

	private static int _gotSeen = -1;

	private static KeyValuePair<string, string> Entry(string flag, string quest)
	{
		quest = (quest ?? "").Replace('_', ' ');
		string key = Norm(flag);
		if (key.EndsWith("pickup"))
		{
			key = key.Substring(0, key.Length - 6);
		}
		return new KeyValuePair<string, string>(key, flag + ((quest.Length > 0) ? (" (" + quest + ")") : ""));
	}

	public static string For(string itemName)
	{
		Refresh();
		return Find(_stamps, itemName);
	}

	private static string Find(List<KeyValuePair<string, string>> stamps, string itemName)
	{
		if (stamps.Count == 0 || string.IsNullOrEmpty(itemName))
		{
			return null;
		}
		List<string> list = new List<string>();
		string[] array = itemName.Split(new char[4] { ' ', '-', ',', '\'' }, StringSplitOptions.RemoveEmptyEntries);
		foreach (string s in array)
		{
			string text = Norm(s);
			if (text.Length > 0 && !Small.Contains(text))
			{
				list.Add(text);
			}
		}
		if (list.Count < 3)
		{
			return null;
		}
		int num = 0;
		foreach (string item in list)
		{
			num += item.Length;
		}
		foreach (KeyValuePair<string, string> stamp in stamps)
		{
			bool flag = true;
			foreach (string item2 in list)
			{
				if (stamp.Key.IndexOf(item2, StringComparison.Ordinal) < 0)
				{
					flag = false;
					break;
				}
			}
			if (flag && (double)num >= (double)stamp.Key.Length * 0.6)
			{
				return stamp.Value;
			}
		}
		return null;
	}
}
