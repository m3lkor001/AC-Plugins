using System;
using System.Collections.Generic;
using System.IO;
using System.Numerics;
using System.Text.RegularExpressions;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank.Loot;

public class LootTab : IDisposable
{
	private readonly Settings _s;

	private readonly Looter _l;

	private readonly Action _saveAll;

	private int _sel = -1;

	private string _filter = "";

	private List<string> _files;

	private DateTime _filesReadAt = DateTime.MinValue;

	private DateTime _diskCheckAt = DateTime.MinValue;

	private bool _diskChanged;

	private static readonly Vector4 Cyan = new Vector4(0.35f, 0.85f, 0.95f, 1f);

	private static readonly Vector4 Red = new Vector4(0.95f, 0.35f, 0.35f, 1f);

	private static readonly Vector4 Green = new Vector4(0.45f, 0.9f, 0.45f, 1f);

	private static readonly Vector4 Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f);

	private static readonly Vector4 Yellow = new Vector4(0.95f, 0.85f, 0.35f, 1f);

	private static readonly Vector4 Orange = new Vector4(0.95f, 0.65f, 0.2f, 1f);

	private static readonly Vector4 Purple = new Vector4(0.72f, 0.52f, 0.95f, 1f);

	public const string ActChunk = "5";

	public const string ActReveal = "6";

	private static readonly string[] ActIds = new string[7] { "1", "2", "3", "10", "0", "5", "6" };

	private static readonly string[] ActNames = new string[7] { "Keep", "Salvage", "Sell", "Keep up to", "No loot", "Chunk (hammer)", "Reveal (aetheria)" };

	private readonly Dictionary<UtlReq, ReqRow> _rows = new Dictionary<UtlReq, ReqRow>();

	private Action<FieldDef> _fieldPicked;

	private bool _openFieldPick;

	private string _fieldSearch = "";

	private Action<int> _propPicked;

	private string _propKind = "int";

	private bool _openPropPick;

	private string _propSearch = "";

	public Func<string> LootModeText;

	private Hud _editor;

	private string _editFile;

	private readonly HashSet<string> _dirtyFiles = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

	private string _saveAsName = "";

	private ReqRow _propChanged;

	private int _corpseSort = 2;

	private bool _corpseSortDesc;

	private bool _showHiddenCorpses;

	private int _hiddenCount;

	public bool EditorOpen => _editor != null && _editor.Visible;

	private bool _dirty
	{
		get
		{
			return _editFile != null && _dirtyFiles.Contains(_editFile);
		}
		set
		{
			if (_editFile != null)
			{
				if (value)
				{
					_dirtyFiles.Add(_editFile);
				}
				else
				{
					_dirtyFiles.Remove(_editFile);
				}
			}
		}
	}

	private UtlProfile EditProfile => _l.GetEdit(_editFile);

	public LootTab(Settings s, Looter looter, Action saveAll)
	{
		_s = s;
		_l = looter;
		_saveAll = saveAll;
	}

	/// <summary>Opens the editor on a profile (a path relative to the loot profile folder - a vendor profile under Vendor too).</summary>
	public void EditFile(string f)
	{
		SetEditFile(f);
		ShowEditor(show: true);
	}

	public void ShowEditor(bool show)
	{
		if (_editor == null)
		{
			if (!show)
			{
				return;
			}
			_editor = UBService.Huds.CreateHud("MelkTank Loot Editor", BarIcon.Make("Loot"));
			_editor.ShowInBar = false;
			_editor.OnPreRender += (object? o, EventArgs e) =>
			{
				ImGui.SetNextWindowSize(new Vector2(820f, 640f), ImGuiCond.FirstUseEver);
			};
			_editor.OnRender += (object? o, EventArgs e) =>
			{
				try
				{
					WinMem.Frame("Loot editor");
					DrawEditorWindow();
				}
				catch (Exception ex)
				{
					Util.LogError(ex);
				}
			};
		}
		_editor.Visible = show;
	}

	public void Dispose()
	{
		try
		{
			if (_editor != null)
			{
				_editor.Dispose();
			}
		}
		catch
		{
		}
		_editor = null;
	}

	private void DrawEditorWindow()
	{
		bool changed = false;
		DrawProfileBar(ref changed);
		if (changed)
		{
			_saveAll();
		}
		UtlProfile editProfile = EditProfile;
		if (editProfile == null)
		{
			Im.TextColored(Grey, "Pick a profile to edit above.");
			return;
		}
		DrawRuleList(editProfile);
		ImGui.Separator();
		DrawRuleEditor(editProfile);
	}

	public void Draw()
	{
		bool changed = false;
		ImGui.PushStyleColor(ImGuiCol.Button, _s.LootEnabled ? new Vector4(0.15f, 0.55f, 0.2f, 1f) : new Vector4(0.55f, 0.15f, 0.15f, 1f));
		if (ImGui.Button(_s.LootEnabled ? "Looting: ON " : "Looting: OFF", new Vector2(140f, 0f)))
		{
			_s.LootEnabled = !_s.LootEnabled;
			changed = true;
		}
		ImGui.PopStyleColor();
		Tip("Opens corpses within the range below, identifies every item and loots what the profile keeps.\nOnly while no monsters are in attack range. Turn VTank's own looting off while this is on.\n/mt loot on|off");
		ImGui.SameLine();
		Im.TextColored(_l.Busy ? Yellow : Grey, _l.Status ?? "");
		string text = ((LootModeText != null) ? LootModeText() : null);
		if (!string.IsNullOrEmpty(text))
		{
			ImGui.SameLine(0f, 20f);
			Im.TextColored(Orange, text);
		}
		DrawCorpses();
		ImGui.Separator();
		CheckDisk();
		if (ImGui.CollapsingHeader("Profiles and options###profopts"))
		{
			ImGui.Indent(8f);
			ImGui.SetNextItemWidth(110f);
			changed |= ImGui.InputFloat("Corpse range (m)", ref _s.LootRange, 1f, 5f, "%.0f");
			Im.SetTooltipIfHovered("/mt set LootRange <number>");
			if (_s.LootRange < 1f)
			{
				_s.LootRange = 1f;
			}
			ImGui.SameLine();
			changed |= ImGui.Checkbox("Fellows' kills too", ref _s.LootFellowKills);
			Im.SetTooltipIfHovered("/mt set LootFellowKills on|off");
			string text2 = string.Join(", ", new List<string>(CorpseKillers.Fellows).ToArray());
			Tip("Off: only corpses you (or your pet) killed are listed and looted.\nOn: your fellowship's kills too.\n" + ((text2.Length > 0) ? ("Fellowship: " + text2) : "No fellowship seen yet (it's picked up when you join, or log in while in one)."));
			ImGui.SameLine();
			changed |= ImGui.Checkbox("Always loot my own corpse", ref _s.LootOwnCorpse);
			Tip("When your own corpse is within corpse range, it's looted first and everything on it comes back to your pack -\nno loot profile needed (Looting still has to be ON).\n/mt set LootOwnCorpse on|off");
			ImGui.SameLine();
			changed |= ImGui.Checkbox("Always pick up rares", ref _s.LootRares);
			Tip("When you find a rare (the game's \"You have discovered the ...!\" line), your corpses in range are opened for a\nminute and the rare is picked up - even with no loot profile on, or none that keeps it. Along with whatever\nyour profiles keep (they still work as usual). Nothing extra is opened or identified without that line.\n(Looting still has to be ON.)\n/mt set LootRares on|off");
			ImGui.SameLine();
			changed |= ImGui.Checkbox("Only rares / pristine / ascendant", ref _s.LootOnlyRare);
			Tip("Only open a corpse when you've just found a rare (the game's \"... discovered the ...!\" line) or a Pristine or\nAscendant item dropped for you (the zone-wide line naming you), and from it pick up only that item (a rare id -\nproperty #17 - or the name from the line) - nothing else, whatever the profiles say.\nFor a minute after that line your corpses in range are opened, then it goes back to leaving them.\nYour own corpse is still looted with 'Always loot my own corpse'.\n/mt set LootOnlyRare on|off");
			ImGui.SameLine();
			if (ImGui.Button(_showHiddenCorpses ? "Hide others' corpses" : ("Show hidden (" + _hiddenCount + ")")))
			{
				_showHiddenCorpses = !_showHiddenCorpses;
			}
			Tip("Show or hide corpses other people killed, and ones you cleared. Shown ones are greyed out and aren't looted\n(right-click one in the list to loot it after all).");
			ImGui.SameLine();
			if (ImGui.Button("Clear corpse list"))
			{
				int num = _l.ClearCorpses();
				Util.WriteToChat((num == 0) ? "No corpses to clear." : ("Cleared " + num + " corpse" + ((num == 1) ? "" : "s") + " from the list - they won't be looted. New ones show up as usual."));
			}
			Tip("Take every corpse around now off the list; the looter leaves them alone.\nShow hidden brings them back (greyed), and right-clicking one loots it after all.");
			ImGui.SetNextItemWidth(110f);
			if (ImGui.InputInt("% - skip armor / jewelry for slots already this good##skipmaxed", ref _s.LootSkipMaxedPct, 1, 5))
			{
				_s.LootSkipMaxedPct = Math.Max(0, Math.Min(100, _s.LootSkipMaxedPct));
				changed = true;
			}
			Tip("Armor, jewelry and clothing aren't identified (and so are left) when every slot they could go in already holds a\npiece at this % or more of the four mods' max (Damage Resist + Damage Rating + Crit Damage Rating + All Attributes:\n276 in T11, 296 in T12 - the zone's tier, or the piece's own if higher). Rings / bracelets: the weaker of the two. Fewer IDs - less time and less item memory.\n0 = off (check everything).\n/mt set LootSkipMaxedPct <number>");
			changed |= ImGui.Checkbox("Finish looting first", ref _s.LootModeEnabled);
			Tip("When more than the set number of corpses are waiting and no monster is within your attack range,\nthe attack range drops to the range here until every corpse is looted - so monsters that\nrespawn further out don't pull you away. Monsters that come inside it are still fought.\n/mt set LootModeEnabled on|off");
			ImGui.SameLine();
			ImGui.SetNextItemWidth(90f);
			changed |= ImGui.InputFloat("range (m)##lootmode", ref _s.LootModeRange, 1f, 5f, "%.0f");
			Im.SetTooltipIfHovered("/mt set LootModeRange <number>");
			if (_s.LootModeRange < 1f)
			{
				_s.LootModeRange = 1f;
			}
			ImGui.SameLine();
			ImGui.SetNextItemWidth(90f);
			changed |= ImGui.InputInt("when more than this many corpses##lootmode", ref _s.LootModeCorpses);
			Im.SetTooltipIfHovered("/mt set LootModeCorpses <number>");
			if (_s.LootModeCorpses < 0)
			{
				_s.LootModeCorpses = 0;
			}
			ImGui.Separator();
			DrawSlots(ref changed);
			ImGui.Unindent(8f);
		}
		if (changed)
		{
			_saveAll();
		}
		bool editorOpen = EditorOpen;
		ImGui.PushStyleColor(ImGuiCol.Button, editorOpen ? new Vector4(0.15f, 0.45f, 0.6f, 1f) : new Vector4(0.25f, 0.3f, 0.4f, 1f));
		if (ImGui.Button(editorOpen ? "Close loot editor" : "Open loot editor", new Vector2(160f, 0f)))
		{
			ShowEditor(!editorOpen);
		}
		ImGui.PopStyleColor();
		Tip("Opens the rules in their own window - add, change and test rules there.");
		if (_dirtyFiles.Count > 0)
		{
			ImGui.SameLine();
			Im.TextColored(Orange, "Unsaved edits: " + string.Join(", ", new List<string>(_dirtyFiles).ToArray()));
		}
		if (!_l.HasProfile)
		{
			Im.TextColored(Grey, "Pick a .utl profile above. The folder is VTank's (set it under Profile folder if it isn't found).");
		}
		DrawLog();
	}

	private void RefreshFiles()
	{
		if (_files == null || (DateTime.Now - _filesReadAt).TotalSeconds > 5.0)
		{
			_files = _l.ListProfiles();
			_filesReadAt = DateTime.Now;
		}
	}

	private static int ActiveRules(UtlProfile p)
	{
		int num = 0;
		if (p != null)
		{
			foreach (UtlRule rule in p.Rules)
			{
				if (!rule.Off && !rule.IsSection && !rule.IsSpacer)
				{
					num++;
				}
			}
		}
		return num;
	}

	private void DrawSlots(ref bool changed)
	{
		RefreshFiles();
		bool flag = _l.SlotOn(0);
		for (int i = 0; i < Looter.SlotNames.Length; i++)
		{
			ImGui.PushID("slot" + i);
			bool v = _l.SlotOn(i);
			if (ImGui.Checkbox("##on", ref v))
			{
				_l.SetSlotOn(i, v);
				changed = true;
			}
			Tip(i switch
			{
				2 => "Armor, shields, jewelry and clothing.", 
				1 => "Everything that isn't a weapon, armor, jewelry or clothing (gems, keys, salvage, trophies ...).", 
				4 => "Checked against every item the type profile doesn't loot.", 
				0 => "Ticked: every item is checked against this profile only (the others are ignored).", 
				_ => "Melee and missile weapons, wands, staves and orbs.", 
			});
			ImGui.SameLine();
			bool flag2 = (i != 0) & flag;
			Vector4 col;
			if (flag2)
			{
				col = Grey;
			}
			else
			{
				col = ((i == 0) ? Cyan : new Vector4(1f, 1f, 1f, 1f));
			}
			Im.TextColored(col, Looter.SlotNames[i] + ((i == 0) ? "" : " profile"));
			ImGui.SameLine(130f);
			string text = _l.SlotFile(i);
			ImGui.SetNextItemWidth(240f);
			if (ImGui.BeginCombo("##utl", (text.Length == 0) ? "(none)" : text))
			{
				if (ImGui.Selectable("(none)", text.Length == 0))
				{
					_l.SetSlotFile(i, "");
					changed = true;
				}
				foreach (string file in _files)
				{
					if (ImGui.Selectable(file, string.Equals(file, text, StringComparison.OrdinalIgnoreCase)))
					{
						_l.SetSlotFile(i, file);
						changed = true;
					}
				}
				ImGui.EndCombo();
			}
			UtlProfile utlProfile = _l.SlotProfile(i);
			if (utlProfile != null)
			{
				ImGui.SameLine();
				Im.TextColored(flag2 ? Grey : new Vector4(0.8f, 0.8f, 0.8f, 1f), "(" + utlProfile.Rules.Count + ") (" + ActiveRules(utlProfile) + ")");
				Tip(utlProfile.Rules.Count + " rules, " + ActiveRules(utlProfile) + " switched on (section headings and spacers not counted).");
				ImGui.SameLine();
				if (ImGui.SmallButton("Edit"))
				{
					SetEditFile(text);
					ShowEditor(show: true);
				}
				Tip("Open this profile in the loot editor.");
			}
			ImGui.PopID();
		}
		if (ImGui.CollapsingHeader("Profile folder"))
		{
			ImGui.SetNextItemWidth(420f);
			if (ImGui.InputTextWithHint("##dir", _l.ProfileDir, ref _s.LootProfileDir, 260u))
			{
				changed = true;
				_files = null;
				_l.LoadAll();
			}
			Tip("Leave empty to use MelkTank's Profiles\\Loot folder (VTank's ILT_* profiles were copied in).");
		}
	}

	private void SetEditFile(string f)
	{
		if (!string.Equals(f, _editFile, StringComparison.OrdinalIgnoreCase))
		{
			_editFile = f;
			_sel = -1;
			_diskChanged = false;
		}
	}

	private void CheckDisk()
	{
		if ((DateTime.Now - _diskCheckAt).TotalSeconds < 3.0)
		{
			return;
		}
		_diskCheckAt = DateTime.Now;
		foreach (string item in _l.LoadedFiles())
		{
			if (_l.ChangedOnDisk(item))
			{
				if (!_dirtyFiles.Contains(item))
				{
					_l.Load(item);
					Util.WriteToChat("Loot profile " + item + " changed on disk - reloaded.");
				}
				else if (string.Equals(item, _editFile, StringComparison.OrdinalIgnoreCase))
				{
					_diskChanged = true;
				}
			}
		}
	}

	private void DrawSaveAs()
	{
		if (!ImGui.BeginPopup("##saveas"))
		{
			return;
		}
		Im.TextColored(Cyan, "Save " + _editFile + " as");
		if (ImGui.IsWindowAppearing())
		{
			ImGui.SetKeyboardFocusHere();
		}
		ImGui.SetNextItemWidth(260f);
		bool flag = ImGui.InputTextWithHint("##name", "new profile name", ref _saveAsName, 120u, ImGuiInputTextFlags.EnterReturnsTrue);
		ImGui.SameLine();
		Im.TextColored(Grey, ".utl");
		string text = _saveAsName.Trim();
		bool flag2 = text.Length == 0 || text.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0;
		bool flag3 = !flag2 && _l.FileExists(text);
		if (flag2 && text.Length > 0)
		{
			Im.TextColored(Red, "That name has characters a file name can't have.");
		}
		if (flag3)
		{
			Im.TextColored(Orange, "A profile with that name exists - saving replaces it (a .bak copy is kept).");
		}
		if ((ImGui.Button(flag3 ? "Replace" : "Save") | flag) && !flag2)
		{
			string editFile = _editFile;
			string text2 = _l.SaveAs(editFile, text);
			if (text2 != null)
			{
				_dirtyFiles.Remove(editFile);
				_dirtyFiles.Remove(text2);
				_editFile = text2;
				_diskChanged = false;
				_files = null;
				Util.WriteToChat("Saved as " + text2 + ". Pick it on the Loot tab to loot with it.");
			}
			ImGui.CloseCurrentPopup();
		}
		ImGui.SameLine();
		if (ImGui.Button("Cancel"))
		{
			ImGui.CloseCurrentPopup();
		}
		ImGui.EndPopup();
	}

	private void DrawProfileBar(ref bool changed)
	{
		RefreshFiles();
		CheckDisk();
		if (_editFile == null)
		{
			for (int i = 0; i < Looter.SlotNames.Length; i++)
			{
				if (_editFile != null)
				{
					break;
				}
				if (_l.SlotFile(i).Length > 0)
				{
					_editFile = _l.SlotFile(i);
				}
			}
		}
		Im.TextColored(Cyan, "Profile");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(300f);
		string text = (string.IsNullOrEmpty(_editFile) ? "(none)" : _editFile);
		if (ImGui.BeginCombo("##utl", text, ImGuiComboFlags.HeightLarge))
		{
			Im.TextColored(Cyan, "In use on the Loot tab");
			bool flag = false;
			for (int j = 0; j < Looter.SlotNames.Length; j++)
			{
				string text2 = _l.SlotFile(j);
				if (text2.Length != 0)
				{
					flag = true;
					bool flag2 = _l.SlotOn(j) && (j == 0 || !_l.SlotOn(0));
					ImGui.PushStyleColor(ImGuiCol.Text, flag2 ? new Vector4(1f, 1f, 1f, 1f) : Grey);
					if (ImGui.Selectable(Looter.SlotNames[j] + ":  " + text2 + (_dirtyFiles.Contains(text2) ? " *" : "") + "##slot" + j, string.Equals(text2, _editFile, StringComparison.OrdinalIgnoreCase)))
					{
						SetEditFile(text2);
					}
					ImGui.PopStyleColor();
				}
			}
			if (!flag)
			{
				Im.TextColored(Grey, "   (none picked)");
			}
			List<string> list = VendorRun.ListVendorProfiles(_l.ProfileDir);
			if (list.Count > 0)
			{
				ImGui.Separator();
				Im.TextColored(Cyan, "Vendor profiles (Items > Vendor)");
				foreach (string item in list)
				{
					if (ImGui.Selectable(item.Replace('\\', '/') + (_dirtyFiles.Contains(item) ? " *" : "") + "##vend", string.Equals(item, _editFile, StringComparison.OrdinalIgnoreCase)))
					{
						SetEditFile(item);
					}
				}
			}
			ImGui.Separator();
			Im.TextColored(Cyan, "All profiles");
			foreach (string file in _files)
			{
				if (ImGui.Selectable(file + (_dirtyFiles.Contains(file) ? " *" : "") + "##all", string.Equals(file, _editFile, StringComparison.OrdinalIgnoreCase)))
				{
					SetEditFile(file);
				}
			}
			ImGui.EndCombo();
		}
		Tip("Which profile to edit. Picking one here doesn't change what the looter uses - that's set on the Loot tab.");
		ImGui.SameLine();
		if (ImGui.Button("Reload") && !string.IsNullOrEmpty(_editFile))
		{
			_l.Load(_editFile);
			_dirty = false;
			_diskChanged = false;
			UtlProfile editProfile = EditProfile;
			_sel = Math.Min(_sel, (editProfile == null) ? (-1) : (editProfile.Rules.Count - 1));
		}
		Tip("Reads the file again (picks up changes saved by LootEditor.html). Unsaved edits here are dropped.");
		ImGui.SameLine();
		bool dirty = _dirty;
		if (dirty)
		{
			ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(0.6f, 0.45f, 0.1f, 1f));
		}
		bool flag3 = ImGui.Button(dirty ? "Save *" : "Save");
		if (dirty)
		{
			ImGui.PopStyleColor();
		}
		if (flag3 && EditProfile != null && _l.Save(_editFile))
		{
			_dirty = false;
			_diskChanged = false;
			Util.WriteToChat("Saved " + _editFile + ". Reload it in VTank if VTank has it open.");
		}
		Tip("Writes the profile back to the .utl file - looting uses your edits from then on (not before).\nThe first save each session keeps a copy as .utl.bak.");
		ImGui.SameLine();
		bool flag4 = !_dirty;
		if (flag4)
		{
			ImGui.BeginDisabled();
		}
		if (ImGui.Button("Cancel") && _dirty)
		{
			_l.DiscardEdit(_editFile);
			_dirty = false;
			_diskChanged = false;
			UtlProfile editProfile2 = EditProfile;
			_sel = Math.Min(_sel, (editProfile2 == null) ? (-1) : (editProfile2.Rules.Count - 1));
			Util.WriteToChat("Edits to " + _editFile + " dropped - back to the saved profile.");
		}
		if (flag4)
		{
			ImGui.EndDisabled();
		}
		Tip("Drops the unsaved edits to this profile (back to the saved one). Looting never used them.");
		ImGui.SameLine();
		if (ImGui.Button("Save as...") && EditProfile != null)
		{
			_saveAsName = Path.GetFileNameWithoutExtension(_editFile) + " copy";
			ImGui.OpenPopup("##saveas");
		}
		Tip("Saves this profile (with any unsaved edits) under a new name - the way to start a new profile.\nThe original file is left as it was last saved.");
		DrawSaveAs();
		ImGui.SameLine();
		if (ImGui.Button("Add selected item") && EditProfile != null)
		{
			AddFromSelected();
		}
		Tip("Adds a Keep rule matching the selected item's exact name, below the selected rule (top of the list if none).");
		UtlProfile editProfile3 = EditProfile;
		if (editProfile3 != null)
		{
			ImGui.SameLine();
			Im.TextColored(Grey, "(" + editProfile3.Rules.Count + ") (" + ActiveRules(editProfile3) + ")");
		}
		if (_diskChanged)
		{
			Im.TextColored(Orange, "The file changed on disk while you have unsaved edits here. Save overwrites it; Reload takes the disk version.");
		}
	}

	private void DrawRuleList(UtlProfile p)
	{
		ImGui.SetNextItemWidth(200f);
		ImGui.InputTextWithHint("##filter", "filter rules", ref _filter, 64u);
		ImGui.SameLine();
		if (ImGui.Button("+ Rule"))
		{
			InsertRule(p, new UtlRule
			{
				Name = "New rule"
			});
		}
		ImGui.SameLine();
		if (ImGui.Button("+ Section"))
		{
			UtlRule utlRule = new UtlRule
			{
				Name = "***** New section *****"
			};
			utlRule.Reqs.Add(UtlReq.New("1", "do not edit", "1"));
			utlRule.SetOff(off: true);
			InsertRule(p, utlRule);
		}
		ImGui.SameLine();
		Im.TextColored(Grey, p.Rules.Count + " rules - first match wins");
		ImGuiTableFlags flags = ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY;
		if (!ImGui.BeginTable("lootrules", 3, flags, new Vector2(0f, 230f)))
		{
			return;
		}
		ImGui.TableSetupColumn("On", ImGuiTableColumnFlags.WidthFixed, 26f);
		ImGui.TableSetupColumn("Rule", ImGuiTableColumnFlags.WidthStretch);
		ImGui.TableSetupColumn("Action", ImGuiTableColumnFlags.WidthFixed, 90f);
		ImGui.TableSetupScrollFreeze(0, 1);
		ImGui.TableHeadersRow();
		string text = _filter.Trim();
		for (int i = 0; i < p.Rules.Count; i++)
		{
			UtlRule utlRule2 = p.Rules[i];
			if (text.Length > 0 && utlRule2.Name.IndexOf(text, StringComparison.OrdinalIgnoreCase) < 0)
			{
				continue;
			}
			ImGui.TableNextRow();
			ImGui.PushID(i);
			ImGui.TableSetColumnIndex(0);
			if (!utlRule2.IsSection && !utlRule2.IsSpacer)
			{
				bool v = !utlRule2.Off;
				if (ImGui.Checkbox("##on", ref v))
				{
					utlRule2.SetOff(!v);
					_dirty = true;
				}
			}
			ImGui.TableSetColumnIndex(1);
			string text2;
			if (utlRule2.IsSpacer)
			{
				text2 = "------";
			}
			else
			{
				text2 = ((utlRule2.Name.Trim().Length > 0) ? utlRule2.Name.Trim() : "(no name)");
			}
			Vector4 col;
			if (utlRule2.IsSection)
			{
				col = Red;
			}
			else if (utlRule2.Off)
			{
				col = Grey;
			}
			else
			{
				col = (LootMatcher.UsesUnsupported(utlRule2) ? Orange : new Vector4(1f, 1f, 1f, 1f));
			}
			ImGui.PushStyleColor(ImGuiCol.Text, col);
			if (ImGui.Selectable(text2 + "##r", i == _sel, ImGuiSelectableFlags.SpanAllColumns | ImGuiSelectableFlags.AllowOverlap))
			{
				_sel = i;
			}
			ImGui.PopStyleColor();
			if (LootMatcher.UsesUnsupported(utlRule2))
			{
				Tip("Uses a colour or buffed-damage requirement MelkTank can't check - never matches here (VTank still uses it).");
			}
			ImGui.TableSetColumnIndex(2);
			if (!utlRule2.IsSection && !utlRule2.IsSpacer)
			{
				Im.TextColored(ActColor(utlRule2.Act), (utlRule2.Act == "10") ? ("Keep " + utlRule2.KeepN + (utlRule2.KeepEach ? " each" : "")) : UtlSpec.ActionName(utlRule2.Act));
			}
			ImGui.PopID();
		}
		ImGui.EndTable();
	}

	private static Vector4 ActColor(string a)
	{
		switch (a)
		{
		case "0":
			return Grey;
		case "1":
		case "10":
			return Green;
		case "2":
			return Orange;
		case "3":
			return Purple;
		default:
			return Grey;
		}
	}

	private void InsertRule(UtlProfile p, UtlRule r)
	{
		int num = ((_sel >= 0 && _sel < p.Rules.Count) ? (_sel + 1) : 0);
		p.Rules.Insert(num, r);
		_sel = num;
		_dirty = true;
	}

	private void AddFromSelected()
	{
		WorldObject worldObject = null;
		try
		{
			int currentSelection = Globals.Core.Actions.CurrentSelection;
			worldObject = ((currentSelection == 0) ? null : Globals.Core.WorldFilter[currentSelection]);
		}
		catch
		{
		}
		if (worldObject == null)
		{
			Util.WriteToChat("Select an item first.");
			return;
		}
		UtlRule utlRule = new UtlRule
		{
			Name = worldObject.Name,
			Act = "1"
		};
		utlRule.Reqs.Add(UtlReq.New("1", "^" + Regex.Escape(worldObject.Name) + "$", "1"));
		InsertRule(EditProfile, utlRule);
		Util.WriteToChat("Added rule '" + worldObject.Name + "' (Keep). Save to write it to the profile.");
	}

	private void DrawRuleEditor(UtlProfile p)
	{
		if (_sel < 0 || _sel >= p.Rules.Count)
		{
			Im.TextColored(Grey, "Click a rule to edit it.");
			return;
		}
		UtlRule utlRule = p.Rules[_sel];
		ImGui.SetNextItemWidth(300f);
		string input = utlRule.Name;
		if (ImGui.InputText("Name##rn", ref input, 256u))
		{
			utlRule.Name = input;
			_dirty = true;
		}
		if (!utlRule.IsSection && !utlRule.IsSpacer)
		{
			ImGui.SameLine();
			int current_item = Array.IndexOf(ActIds, utlRule.Act);
			string[] array = ActNames;
			if (current_item < 0)
			{
				array = new List<string>(ActNames) { UtlSpec.ActionName(utlRule.Act) }.ToArray();
				current_item = array.Length - 1;
			}
			ImGui.SetNextItemWidth(110f);
			if (ImGui.Combo("##act", ref current_item, array, array.Length) && current_item < ActIds.Length)
			{
				utlRule.Act = ActIds[current_item];
				if (utlRule.Act == "10" && utlRule.KeepN == null)
				{
					utlRule.KeepN = "1";
				}
				_dirty = true;
			}
			Tip("MelkTank loots Keep, Salvage, Sell and Keep up to; No loot stops later rules from looting it.\nChunk / Reveal: looted like Keep; then, when it's calm, an untuned aetheria or un-imbued weapon this rule catches first\nis broken up with the Aetheria Hammer (Chunk), or an untuned aetheria revealed with an Aetheria Mana Stone (Reveal) -\nwhile the matching checkbox on Settings > Items is on. Saved as User 1 / User 2, which VTank also loots.");
			if (utlRule.Act == "10")
			{
				ImGui.SameLine();
				ImGui.SetNextItemWidth(70f);
				string input2 = utlRule.KeepN ?? "1";
				if (ImGui.InputText("up to##kn", ref input2, 8u))
				{
					utlRule.KeepN = input2;
					_dirty = true;
				}
				ImGui.SameLine();
				bool v = utlRule.KeepEach;
				if (ImGui.Checkbox("of each name##ke", ref v))
				{
					utlRule.SetKeepEach(v);
					_dirty = true;
				}
				Tip("On: counts each item name separately - a rule for Golem Hearts with Keep up to 1 keeps one Copper Golem Heart,\none Vapor Golem Heart, and so on.\nOff: everything the rule matches counts together (one heart in all).");
			}
		}
		if (Im.SmallUp("Up") && _sel > 0)
		{
			Swap(p, _sel, _sel - 1);
			_sel--;
		}
		ImGui.SameLine();
		if (Im.SmallDown("Down") && _sel < p.Rules.Count - 1)
		{
			Swap(p, _sel, _sel + 1);
			_sel++;
		}
		ImGui.SameLine();
		if (ImGui.SmallButton("Clone"))
		{
			InsertRule(p, utlRule.Clone());
			return;
		}
		ImGui.SameLine();
		ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(0.6f, 0.15f, 0.15f, 1f));
		if (ImGui.SmallButton("Delete rule"))
		{
			p.Rules.RemoveAt(_sel);
			_sel = Math.Min(_sel, p.Rules.Count - 1);
			_dirty = true;
			ImGui.PopStyleColor();
			return;
		}
		ImGui.PopStyleColor();
		if (utlRule.IsSection || utlRule.IsSpacer)
		{
			Im.TextColored(Grey, "A heading in the list - VTank never matches it.");
			return;
		}
		Im.TextColored(Cyan, "Requirements - all must match");
		int num = -1;
		for (int i = 0; i < utlRule.Reqs.Count; i++)
		{
			UtlReq utlReq = utlRule.Reqs[i];
			if (!UtlReq.Flag(utlReq.Type))
			{
				ImGui.PushID(i);
				ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(0.6f, 0.15f, 0.15f, 1f));
				if (ImGui.SmallButton("X"))
				{
					num = i;
				}
				ImGui.PopStyleColor();
				Tip("Remove this requirement");
				ImGui.SameLine();
				DrawReq(utlRule, utlReq);
				ImGui.PopID();
			}
		}
		if (num >= 0)
		{
			_rows.Remove(utlRule.Reqs[num]);
			utlRule.Reqs.RemoveAt(num);
			_dirty = true;
		}
		if (utlRule.Reqs.FindAll((UtlReq x) => !UtlReq.Flag(x.Type)).Count == 0)
		{
			Im.TextColored(Grey, "No requirements: this rule matches every item.");
		}
		if (ImGui.Button("+ Add requirement"))
		{
			UtlRule target = utlRule;
			_fieldPicked = (FieldDef nf) =>
			{
				ReqRow reqRow = LootFields.NewRow(nf);
				UtlReq utlReq2 = LootFields.FromRow(reqRow);
				_rows[utlReq2] = reqRow;
				int num2 = target.Reqs.FindIndex((UtlReq x) => x.Type == "9999");
				if (num2 >= 0)
				{
					target.Reqs.Insert(num2, utlReq2);
				}
				else
				{
					target.Reqs.Add(utlReq2);
				}
				_dirty = true;
			};
			_openFieldPick = true;
		}
		Tip("Pick what the item should have - armor level, biting strike, a spell, a slot ...");
		ImGui.SameLine();
		if (ImGui.Button("Test on selected"))
		{
			WorldObject worldObject = null;
			try
			{
				int currentSelection = Globals.Core.Actions.CurrentSelection;
				worldObject = ((currentSelection == 0) ? null : Globals.Core.WorldFilter[currentSelection]);
			}
			catch
			{
			}
			if (worldObject == null)
			{
				Util.WriteToChat("Select an item first.");
			}
			else
			{
				UtlRule utlRule2 = LootMatcher.FirstMatch(p, worldObject);
				Util.WriteToChat(worldObject.Name + ": this rule " + (LootMatcher.RuleMatches(utlRule, worldObject) ? "MATCHES" : "does not match") + (worldObject.HasIdData ? "" : " (not identified yet - ID it for a fair test)") + ". First matching rule: " + ((utlRule2 == null) ? "none" : (utlRule2.Name.Trim() + " (" + UtlSpec.ActionName(utlRule2.Act) + ")")) + ".");
			}
		}
		DrawFieldPicker();
		DrawPropPicker();
	}

	private void Swap(UtlProfile p, int a, int b)
	{
		UtlRule value = p.Rules[a];
		p.Rules[a] = p.Rules[b];
		p.Rules[b] = value;
		_dirty = true;
	}

	private ReqRow RowOf(UtlReq q)
	{
		if (_rows.TryGetValue(q, out var value))
		{
			return value;
		}
		if (_rows.Count > 4000)
		{
			_rows.Clear();
		}
		value = LootFields.ToRow(q);
		_rows[q] = value;
		return value;
	}

	private void Commit(UtlRule r, UtlReq q, ReqRow row)
	{
		int num = r.Reqs.IndexOf(q);
		if (num >= 0)
		{
			UtlReq utlReq = LootFields.FromRow(row);
			_rows.Remove(q);
			r.Reqs[num] = utlReq;
			_rows[utlReq] = row;
			_dirty = true;
		}
	}

	private void DrawReq(UtlRule r, UtlReq q)
	{
		ReqRow row = RowOf(q);
		if (row == null)
		{
			Im.TextColored(Grey, "Requirement type " + q.Type + " (kept as is)");
			return;
		}
		FieldDef f = row.F;
		bool flag = false;
		string text;
		if (f.Tag == "ilt")
		{
			text = "[ILT] ";
		}
		else
		{
			text = ((f.Tag == "new") ? "[new] " : "");
		}
		bool flag2 = LootMatcher.Unsupported.Contains(q.Type);
		Vector4 col;
		if (flag2)
		{
			col = Orange;
		}
		else
		{
			col = ((f.Tag == "ilt") ? Purple : new Vector4(1f, 1f, 1f, 1f));
		}
		ImGui.PushStyleColor(ImGuiCol.Text, col);
		bool flag3 = ImGui.Button(text + LootFields.FieldLabel(row) + "##fld");
		ImGui.PopStyleColor();
		Tip(LootFields.FieldLabel(row) + "\n" + f.Tip + (flag2 ? "\n\nMelkTank can't check this one (VTank still does) - the rule never matches in MelkTank." : "") + "\n\nClick to change what is checked.");
		if (flag3)
		{
			FieldDef old = f;
			_fieldPicked = (FieldDef nf) =>
			{
				ReqRow reqRow = LootFields.NewRow(nf);
				if ((nf.Kind == "int" || nf.Kind == "dbl") && nf.Kind == old.Kind && nf.Vk == null && old.Vk == null)
				{
					reqRow.V = row.V;
				}
				Commit(r, q, reqRow);
			};
			_openFieldPick = true;
		}
		switch (f.Kind)
		{
		case "int":
		case "dbl":
		{
			if (f.IsAny)
			{
				flag |= PropButton(LootFields.CatKind(f), row);
			}
			string[] ops = f.Ops ?? ((!(f.Kind == "dbl")) ? new string[4] { ">=", "<=", "=", "!=" } : new string[2] { ">=", "<=" });
			ImGui.SameLine();
			flag |= OpCombo("##op", ops, ref row.Op);
			ImGui.SameLine();
			string v13 = row.Val(0);
			if (f.Vk != null && LootFields.Maps.ContainsKey(f.Vk))
			{
				if (MapCombo("##val", f.Vk, ref v13, 190f))
				{
					row.V[0] = v13;
					flag = true;
				}
			}
			else if (NumInput("##val", ref v13, 100f))
			{
				row.V[0] = v13;
				flag = true;
			}
			break;
		}
		case "str":
		{
			if (f.IsAny)
			{
				flag |= PropButton("string", row);
			}
			ImGui.SameLine();
			ImGui.TextUnformatted("matches");
			ImGui.SameLine();
			string v2 = row.Val(0);
			if (TextInput("##rx", "regex, | = or", ref v2, 280f))
			{
				row.V[0] = v2;
				flag = true;
			}
			RegexCheck(v2);
			break;
		}
		case "t11":
			flag |= DrawT11(row);
			break;
		case "oclass":
		{
			ImGui.SameLine();
			ImGui.TextUnformatted("is");
			ImGui.SameLine();
			int current_item4 = (int)Math.Floor(LootFields.JsNum(row.Val(0)));
			if (current_item4 < 0 || current_item4 >= UtlSpec.ObjectClasses.Length)
			{
				current_item4 = 0;
			}
			ImGui.SetNextItemWidth(170f);
			if (ImGui.Combo("##oc", ref current_item4, UtlSpec.ObjectClasses, UtlSpec.ObjectClasses.Length))
			{
				row.V[0] = current_item4.ToString();
				flag = true;
			}
			break;
		}
		case "spellname":
		{
			ImGui.SameLine();
			string v6 = row.Val(0);
			if (TextInput("##sp", "spell name, | = or", ref v6, 280f))
			{
				row.V[0] = v6;
				flag = true;
			}
			RegexCheck(v6);
			break;
		}
		case "cloakspell":
		{
			int current_item2 = (int)Math.Floor(LootFields.JsNum(row.Val(0)));
			int current_item3 = (int)Math.Floor(LootFields.JsNum(row.Val(1)));
			if (current_item2 < 0 || current_item2 >= LootFields.CloakKinds.Length)
			{
				current_item2 = 0;
			}
			if (current_item3 < 0 || current_item3 >= LootFields.CloakElements.Length)
			{
				current_item3 = 0;
			}
			ImGui.SameLine();
			ImGui.TextUnformatted("is");
			ImGui.SameLine();
			ImGui.SetNextItemWidth(230f);
			if (ImGui.Combo("##ck", ref current_item2, LootFields.CloakKinds, LootFields.CloakKinds.Length))
			{
				row.V[0] = current_item2.ToString();
				flag = true;
			}
			if (current_item2 == 6)
			{
				ImGui.SameLine();
				ImGui.TextUnformatted("element");
				ImGui.SameLine();
				ImGui.SetNextItemWidth(120f);
				if (ImGui.Combo("##ce", ref current_item3, LootFields.CloakElements, LootFields.CloakElements.Length))
				{
					row.V[1] = current_item3.ToString();
					flag = true;
				}
			}
			break;
		}
		case "spells":
		{
			string v10 = row.Val(2);
			string v11 = row.Val(0);
			string v12 = row.Val(1);
			ImGui.SameLine();
			ImGui.TextUnformatted("at least");
			ImGui.SameLine();
			if (NumInput("##n", ref v10, 45f))
			{
				row.V[2] = v10;
				flag = true;
			}
			ImGui.SameLine();
			ImGui.TextUnformatted("like");
			ImGui.SameLine();
			if (TextInput("##like", "Legendary|Epic", ref v11, 190f))
			{
				row.V[0] = v11;
				flag = true;
			}
			ImGui.SameLine();
			ImGui.TextUnformatted("but not");
			ImGui.SameLine();
			if (TextInput("##not", "(optional)", ref v12, 130f))
			{
				row.V[1] = v12;
				flag = true;
			}
			RegexCheck(v11);
			RegexCheck(v12);
			break;
		}
		case "charlvl":
		{
			ImGui.SameLine();
			flag |= OpCombo("##op", new string[2] { ">=", "<=" }, ref row.Op);
			string v8 = row.Val(0);
			ImGui.SameLine();
			if (NumInput("##lv", ref v8, 80f))
			{
				row.V[0] = v8;
				flag = true;
			}
			break;
		}
		case "charskill":
		{
			string v14 = row.Val(1);
			string v15 = row.Val(0);
			ImGui.SameLine();
			if (MapCombo("##sk", "skill", ref v14, 170f))
			{
				row.V[1] = v14;
				flag = true;
			}
			ImGui.SameLine();
			ImGui.TextUnformatted("at least");
			ImGui.SameLine();
			if (NumInput("##v", ref v15, 80f))
			{
				row.V[0] = v15;
				flag = true;
			}
			break;
		}
		case "charbase":
		{
			string v3 = row.Val(0);
			string v4 = row.Val(1);
			string v5 = row.Val(2);
			ImGui.SameLine();
			if (MapCombo("##sk", "skill", ref v3, 170f))
			{
				row.V[0] = v3;
				flag = true;
			}
			ImGui.SameLine();
			ImGui.TextUnformatted("from");
			ImGui.SameLine();
			if (NumInput("##lo", ref v4, 70f))
			{
				row.V[1] = v4;
				flag = true;
			}
			ImGui.SameLine();
			ImGui.TextUnformatted("to");
			ImGui.SameLine();
			if (NumInput("##hi", ref v5, 70f))
			{
				row.V[2] = v5;
				flag = true;
			}
			break;
		}
		case "aethrating":
		{
			int current_item = LootFields.RatingIndex(row.Key ?? 372);
			if (current_item < 0)
			{
				current_item = 0;
			}
			string[] array = new string[LootFields.RatingNames.Length];
			for (int num2 = 0; num2 < array.Length; num2++)
			{
				array[num2] = LootFields.RatingNames[num2] + " (" + LootFields.RatingCodes[num2] + ")";
			}
			ImGui.SameLine();
			ImGui.SetNextItemWidth(190f);
			if (ImGui.Combo("##rating", ref current_item, array, array.Length))
			{
				row.Key = LootFields.RatingKeys[current_item];
				flag = true;
			}
			string v9 = row.Val(0);
			ImGui.SameLine();
			ImGui.TextUnformatted("at least");
			ImGui.SameLine();
			if (NumInput("##v", ref v9, 80f))
			{
				row.V[0] = v9;
				flag = true;
			}
			break;
		}
		case "spellcount":
		case "packslots":
		case "calc":
		{
			string v7 = row.Val(0);
			ImGui.SameLine();
			ImGui.TextUnformatted("at least");
			ImGui.SameLine();
			if (NumInput("##v", ref v7, 100f))
			{
				row.V[0] = v7;
				flag = true;
			}
			break;
		}
		default:
		{
			UtlSpec.ReqType reqType = UtlSpec.Get(f.Type);
			if (reqType == null)
			{
				ImGui.SameLine();
				Im.TextColored(Grey, "(kept as is)");
				break;
			}
			for (int num = 0; num < reqType.Fields.Length; num++)
			{
				string text2 = reqType.Fields[num][1];
				if (text2 == "bool")
				{
					continue;
				}
				string v = row.Val(num);
				ImGui.PushID(num);
				ImGui.SameLine();
				Im.TextColored(Grey, reqType.Fields[num][0]);
				ImGui.SameLine();
				if (text2 == "skill")
				{
					if (MapCombo("##f", "skill", ref v, 150f))
					{
						row.V[num] = v;
						flag = true;
					}
				}
				else if (NumInput("##f", ref v, text2.EndsWith("key") ? 90 : 70))
				{
					row.V[num] = v;
					flag = true;
				}
				if (text2 == "ikey" || text2 == "dkey")
				{
					ImGui.SameLine();
					Im.TextColored(Grey, int.TryParse(v, out var result) ? LootFields.Prop((text2 == "dkey") ? "double" : "int", result).Label : "?");
				}
				ImGui.PopID();
			}
			break;
		}
		}
		string text3 = LootFields.RowWarn(row, out var bad);
		if (text3 != null)
		{
			Im.TextColored(bad ? Red : Orange, "      " + text3);
		}
		if (flag)
		{
			Commit(r, q, row);
		}
	}

	private bool DrawT11(ReqRow row)
	{
		bool result = false;
		string t11Id = row.F.T11Id;
		T11Def t11Def = LootFields.T11[t11Id];
		ModDef modDef = ((t11Id == "mod") ? (LootFields.ModByKey(row.Get("k")) ?? LootFields.Mods[0]) : null);
		if ((modDef != null) ? (!string.IsNullOrEmpty(modDef.Fmt)) : (!t11Def.NoValue))
		{
			string v = row.Get("v") ?? "";
			ImGui.SameLine();
			ImGui.TextUnformatted("at least");
			ImGui.SameLine();
			if (NumInput("##v", ref v, 70f))
			{
				row.Set("v", v);
				result = true;
			}
			ImGui.SameLine();
			Im.TextColored(Grey, (modDef != null) ? (modDef.Unit + "  (range " + modDef.Band + ")").Trim() : t11Def.Unit);
		}
		else if (modDef != null)
		{
			ImGui.SameLine();
			Im.TextColored(Grey, "on or off - it has no number");
		}
		if (t11Def.Opt == "el")
		{
			string text = row.Get("el") ?? "";
			ImGui.SameLine();
			ImGui.TextUnformatted("element");
			ImGui.SameLine();
			ImGui.SetNextItemWidth(110f);
			if (ImGui.BeginCombo("##el", (text.Length == 0) ? "any" : text))
			{
				if (ImGui.Selectable("any", text.Length == 0))
				{
					row.Set("el", "");
					result = true;
				}
				string[] rends = LootFields.Rends;
				foreach (string text2 in rends)
				{
					if (ImGui.Selectable(text2, text == text2))
					{
						row.Set("el", text2);
						result = true;
					}
				}
				ImGui.EndCombo();
			}
		}
		if (t11Def.Opt == "sp")
		{
			string text3 = row.Get("sp") ?? "";
			ImGui.SameLine();
			ImGui.TextUnformatted("slayer of");
			ImGui.SameLine();
			ImGui.SetNextItemWidth(150f);
			if (ImGui.BeginCombo("##sp", (text3.Length == 0) ? "any species" : text3, ImGuiComboFlags.HeightLarge))
			{
				if (ImGui.Selectable("any species", text3.Length == 0))
				{
					row.Set("sp", "");
					result = true;
				}
				Im.TextColored(Cyan, "Found in T11");
				string[] slayerT = LootFields.SlayerT11;
				foreach (string text4 in slayerT)
				{
					if (ImGui.Selectable(text4 + "##t", text3 == text4))
					{
						row.Set("sp", text4);
						result = true;
					}
				}
				ImGui.Separator();
				Im.TextColored(Cyan, "Every other species");
				string[] slayerAll = LootFields.SlayerAll;
				foreach (string text5 in slayerAll)
				{
					if (Array.IndexOf(LootFields.SlayerT11, text5) < 0 && ImGui.Selectable(text5 + "##a", text3 == text5))
					{
						row.Set("sp", text5);
						result = true;
					}
				}
				ImGui.EndCombo();
			}
		}
		if (t11Def.Opt == "grade")
		{
			string text6 = row.Get("g") ?? "C";
			if (text6.Length > 1)
			{
				text6 = text6.Substring(0, 1);
			}
			ImGui.SameLine();
			ImGui.TextUnformatted("at least");
			ImGui.SameLine();
			ImGui.SetNextItemWidth(70f);
			if (ImGui.BeginCombo("##gg", text6))
			{
				for (int num = LootFields.GearGrades.Length - 1; num >= 0; num--)
				{
					string text7 = LootFields.GearGrades[num];
					if (ImGui.Selectable(text7, text6 == text7))
					{
						row.Set("g", text7);
						result = true;
					}
				}
				ImGui.EndCombo();
			}
			ImGui.SameLine();
			Im.TextColored(Grey, "(F worst ... S best; each takes its - and +: B = B-, B, B+)");
		}
		if (t11Def.Opt == "name")
		{
			string v2 = row.Get("name") ?? "";
			ImGui.SameLine();
			ImGui.TextUnformatted("spell contains");
			ImGui.SameLine();
			if (TextInput("##nm", "any - or Nether Arc", ref v2, 170f))
			{
				row.Set("name", v2.Trim());
				result = true;
			}
		}
		if (t11Id == "mod" || t11Id == "modcount")
		{
			string text8 = (string.IsNullOrEmpty(row.Where) ? t11Def.Where : row.Where);
			ImGui.SameLine();
			ImGui.TextUnformatted("on");
			ImGui.SameLine();
			ImGui.SetNextItemWidth(170f);
			if (ImGui.BeginCombo("##on", (text8 == "16") ? "Weapons" : "Armor, jewelry, shields"))
			{
				if (ImGui.Selectable("Armor, jewelry, shields", text8 == "14"))
				{
					row.Where = "14";
					result = true;
				}
				if (ImGui.Selectable("Weapons", text8 == "16"))
				{
					row.Where = "16";
					result = true;
				}
				ImGui.EndCombo();
			}
		}
		return result;
	}

	private static bool NumInput(string id, ref string v, float w)
	{
		ImGui.SetNextItemWidth(w);
		if (v == null)
		{
			v = "";
		}
		return ImGui.InputText(id, ref v, 32u);
	}

	private static bool TextInput(string id, string hint, ref string v, float w)
	{
		ImGui.SetNextItemWidth(w);
		if (v == null)
		{
			v = "";
		}
		bool result = ImGui.InputTextWithHint(id, hint, ref v, 2048u);
		if (v.Length > 30)
		{
			Tip(v);
		}
		return result;
	}

	private static void RegexCheck(string v)
	{
		if (string.IsNullOrEmpty(v))
		{
			return;
		}
		try
		{
			LootMatcher.Rx(v);
		}
		catch
		{
			ImGui.SameLine();
			Im.TextColored(Red, "pattern error");
		}
	}

	private static bool OpCombo(string id, string[] ops, ref string op)
	{
		bool result = false;
		if (Array.IndexOf(ops, op) < 0)
		{
			op = ops[0];
		}
		LootFields.OpNames.TryGetValue(op, out var value);
		ImGui.SetNextItemWidth(80f);
		if (ImGui.BeginCombo(id, value ?? op))
		{
			foreach (string text in ops)
			{
				LootFields.OpNames.TryGetValue(text, out var value2);
				if (ImGui.Selectable(value2 ?? text, text == op))
				{
					op = text;
					result = true;
				}
			}
			ImGui.EndCombo();
		}
		return result;
	}

	private static bool MapCombo(string id, string vk, ref string v, float w)
	{
		bool result = false;
		List<KeyValuePair<string, string>> list = LootFields.Maps[vk];
		string text = null;
		foreach (KeyValuePair<string, string> item in list)
		{
			if (item.Key == v)
			{
				text = item.Value;
			}
		}
		ImGui.SetNextItemWidth(w);
		if (ImGui.BeginCombo(id, text ?? ("Other: " + v), ImGuiComboFlags.HeightLarge))
		{
			if (text == null)
			{
				ImGui.Selectable("Other: " + v, selected: true);
			}
			foreach (KeyValuePair<string, string> item2 in list)
			{
				if (ImGui.Selectable(item2.Value + "##" + item2.Key, item2.Key == v))
				{
					v = item2.Key;
					result = true;
				}
			}
			ImGui.EndCombo();
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Value " + v);
		}
		return result;
	}

	private bool PropButton(string kind, ReqRow row)
	{
		ImGui.SameLine();
		string text = (row.Key.HasValue ? ("#" + row.Key.Value) : "Pick a property");
		if (ImGui.Button(text + "##prop"))
		{
			_propKind = kind;
			_propPicked = (int k) =>
			{
				row.Key = k;
				_propChanged = row;
			};
			_openPropPick = true;
		}
		Tip("Click to pick a different property, by name or number.");
		if (_propChanged == row)
		{
			_propChanged = null;
			return true;
		}
		return false;
	}

	private static bool Matches(string query, params string[] texts)
	{
		if (query.Trim().Length == 0)
		{
			return true;
		}
		string text = string.Join(" ", texts).ToLowerInvariant();
		string[] array = query.ToLowerInvariant().Split(new char[1] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
		foreach (string value in array)
		{
			if (text.IndexOf(value, StringComparison.Ordinal) < 0)
			{
				return false;
			}
		}
		return true;
	}

	private void DrawFieldPicker()
	{
		if (_openFieldPick)
		{
			ImGui.OpenPopup("##fieldpick");
			_fieldSearch = "";
			_openFieldPick = false;
		}
		if (!ImGui.BeginPopup("##fieldpick"))
		{
			return;
		}
		if (ImGui.IsWindowAppearing())
		{
			ImGui.SetKeyboardFocusHere();
		}
		ImGui.SetNextItemWidth(420f);
		bool flag = ImGui.InputTextWithHint("##fs", "What should the item have? e.g. armor level, biting, ring...", ref _fieldSearch, 64u, ImGuiInputTextFlags.EnterReturnsTrue);
		FieldDef fieldDef = null;
		FieldDef fieldDef2 = null;
		ImGui.BeginChild("##fl", new Vector2(420f, 380f), border: true);
		foreach (string group in LootFields.Groups)
		{
			bool flag2 = false;
			foreach (FieldDef field in LootFields.Fields)
			{
				if (!(field.Group != group) && Matches(_fieldSearch, field.Group, field.Label, field.Hint ?? "", (field.Tag == "ilt") ? "ilt custom" : (field.Tag ?? "")))
				{
					if (!flag2)
					{
						Im.TextColored(Cyan, group.ToUpperInvariant());
						flag2 = true;
					}
					if (fieldDef2 == null)
					{
						fieldDef2 = field;
					}
					if (ImGui.Selectable("   " + field.Label + "##fp" + LootFields.Fields.IndexOf(field)))
					{
						fieldDef = field;
					}
					if (ImGui.IsItemHovered() && !string.IsNullOrEmpty(field.Tip))
					{
						Im.SetTooltip(field.Tip);
					}
					string text;
					if (field.Tag == "ilt")
					{
						text = "ILT ";
					}
					else
					{
						text = ((field.Tag == "new") ? "new " : "");
					}
					string text2 = text + field.Hint;
					if (text2.Length > 0)
					{
						ImGui.SameLine(230f);
						Im.TextColored(Grey, (text2.Length > 34) ? (text2.Substring(0, 33) + "…") : text2);
					}
				}
			}
		}
		if (fieldDef2 == null)
		{
			Im.TextColored(Grey, "Nothing matches.");
		}
		ImGui.EndChild();
		if (flag && fieldDef2 != null)
		{
			fieldDef = fieldDef2;
		}
		if (fieldDef != null)
		{
			Action<FieldDef> fieldPicked = _fieldPicked;
			_fieldPicked = null;
			ImGui.CloseCurrentPopup();
			fieldPicked?.Invoke(fieldDef);
		}
		ImGui.EndPopup();
	}

	private void DrawPropPicker()
	{
		if (_openPropPick)
		{
			ImGui.OpenPopup("##proppick");
			_propSearch = "";
			_openPropPick = false;
		}
		if (!ImGui.BeginPopup("##proppick"))
		{
			return;
		}
		if (ImGui.IsWindowAppearing())
		{
			ImGui.SetKeyboardFocusHere();
		}
		ImGui.SetNextItemWidth(380f);
		bool flag = ImGui.InputTextWithHint("##ps", "Name or number...", ref _propSearch, 32u, ImGuiInputTextFlags.EnterReturnsTrue);
		int num = -1;
		int num2 = -1;
		ImGui.BeginChild("##pl", new Vector2(380f, 360f), border: true);
		string text = null;
		foreach (PropInfo item in LootFields.Pickable[_propKind])
		{
			string text2 = ((item.Group.Length > 0) ? item.Group : "Other");
			if (Matches(_propSearch, text2, item.Label, "#" + item.Id, item.Id.ToString()))
			{
				if (text2 != text)
				{
					Im.TextColored(Cyan, text2.ToUpperInvariant());
					text = text2;
				}
				if (num2 < 0)
				{
					num2 = item.Id;
				}
				if (ImGui.Selectable("   " + item.Label + "##pp" + item.Id))
				{
					num = item.Id;
				}
				if (ImGui.IsItemHovered() && item.Note.Length > 0)
				{
					Im.SetTooltip(item.Note);
				}
				ImGui.SameLine(300f);
				Im.TextColored(Grey, "#" + item.Id);
			}
		}
		ImGui.EndChild();
		if (flag)
		{
			num = ((int.TryParse(_propSearch.Trim(), out var result) && result >= 0) ? result : num2);
		}
		if (num >= 0)
		{
			Action<int> propPicked = _propPicked;
			_propPicked = null;
			ImGui.CloseCurrentPopup();
			propPicked?.Invoke(num);
		}
		ImGui.EndPopup();
	}

	private int StatusRank(string st, double dist)
	{
		if (st == null)
		{
			return (dist >= 0.0 && dist <= (double)_s.LootRange) ? 1 : 2;
		}
		if (st == "Looting now")
		{
			return 0;
		}
		if (st.StartsWith("Skipped"))
		{
			return 3;
		}
		if (st.StartsWith("Looted"))
		{
			return 4;
		}
		return 5;
	}

	private void DrawCorpses()
	{
		List<KeyValuePair<double, WorldObject>> list = new List<KeyValuePair<double, WorldObject>>();
		int num = 0;
		int num2 = 0;
		int num3 = 0;
		HashSet<int> hashSet = new HashSet<int>();
		try
		{
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				if (item.ObjectClass != ObjectClass.Corpse)
				{
					continue;
				}
				bool pending;
				if (_l.IsCleared(item.Id))
				{
					num3++;
					if (!_showHiddenCorpses)
					{
						continue;
					}
					hashSet.Add(item.Id);
				}
				else if (!CorpseKillers.Allowed(item, _s.LootFellowKills, out pending))
				{
					if (pending)
					{
						num2++;
					}
					else
					{
						num++;
					}
					if (!_showHiddenCorpses)
					{
						continue;
					}
					hashSet.Add(item.Id);
				}
				list.Add(new KeyValuePair<double, WorldObject>(CombatEngine.Distance(item), item));
			}
		}
		catch
		{
		}
		list.Sort((KeyValuePair<double, WorldObject> a, KeyValuePair<double, WorldObject> b) => a.Key.CompareTo(b.Key));
		int num4 = 0;
		foreach (KeyValuePair<double, WorldObject> item2 in list)
		{
			if (!hashSet.Contains(item2.Value.Id))
			{
				string text = _l.CorpseStatus(item2.Value.Id);
				if (text == null || text == "Looting now")
				{
					num4++;
				}
			}
		}
		_hiddenCount = num + num2 + num3;
		string text2 = ((num > 0) ? (num + (_showHiddenCorpses ? " others shown" : " others hidden")) : "") + ((num3 > 0) ? (((num > 0) ? ", " : "") + num3 + " cleared") : "") + ((num2 > 0) ? (((num > 0) ? ", " : "") + num2 + " checking") : "");
		if (!ImGui.CollapsingHeader("Nearby corpses (" + (list.Count - hashSet.Count) + ") (" + num4 + ")" + ((text2.Length > 0) ? ("  - " + text2) : "") + "###corpses2", ImGuiTreeNodeFlags.DefaultOpen))
		{
			return;
		}
		ImGuiTableFlags flags = ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY;
		float num5 = ImGui.GetTextLineHeight() + ImGui.GetStyle().CellPadding.Y * 2f;
		float y = num5 * 9f + 4f;
		if (!ImGui.BeginTable("corpses", 4, flags, new Vector2(0f, y)))
		{
			return;
		}
		ImGui.TableSetupColumn("Corpse", ImGuiTableColumnFlags.WidthStretch);
		ImGui.TableSetupColumn("Killed by", ImGuiTableColumnFlags.WidthFixed, 140f);
		ImGui.TableSetupColumn("Dist", ImGuiTableColumnFlags.WidthFixed, 45f);
		ImGui.TableSetupColumn("Status", ImGuiTableColumnFlags.WidthFixed, 190f);
		ImGui.TableSetupScrollFreeze(0, 1);
		ImGui.TableNextRow(ImGuiTableRowFlags.Headers);
		string[] array = new string[4] { "Corpse", "Killed by", "Dist", "Status" };
		for (int num6 = 0; num6 < array.Length; num6++)
		{
			ImGui.TableSetColumnIndex(num6);
			if (num6 < 2)
			{
				Im.TextColored(Cyan, array[num6]);
				continue;
			}
			int num7 = num6 - 1;
			ImGui.PushStyleColor(ImGuiCol.Text, Cyan);
			string obj2 = array[num6];
			string text3;
			if (_corpseSort != num7)
			{
				text3 = "";
			}
			else
			{
				text3 = (_corpseSortDesc ? " v" : " ^");
			}
			if (ImGui.Selectable(obj2 + text3 + "##ch" + num6, _corpseSort == num7))
			{
				if (_corpseSort == num7)
				{
					_corpseSortDesc = !_corpseSortDesc;
				}
				else
				{
					_corpseSort = num7;
					_corpseSortDesc = false;
				}
			}
			ImGui.PopStyleColor();
			Tip((num7 == 1) ? "Sort by distance (click again to reverse)." : "Sort by status: looting now, not looted yet, out of range, skipped, looted, empty (click again to reverse).");
		}
		if (_corpseSort == 2)
		{
			Dictionary<int, int> rank = new Dictionary<int, int>();
			foreach (KeyValuePair<double, WorldObject> item3 in list)
			{
				rank[item3.Value.Id] = StatusRank(_l.CorpseStatus(item3.Value.Id), item3.Key);
			}
			list.Sort((KeyValuePair<double, WorldObject> a, KeyValuePair<double, WorldObject> b) =>
			{
				int num8 = rank[a.Value.Id].CompareTo(rank[b.Value.Id]);
				if (_corpseSortDesc)
				{
					num8 = -num8;
				}
				return (num8 != 0) ? num8 : a.Key.CompareTo(b.Key);
			});
		}
		else if (_corpseSortDesc)
		{
			list.Reverse();
		}
		if (list.Count == 0)
		{
			ImGui.TableNextRow();
			ImGui.TableSetColumnIndex(0);
			Im.TextColored(Grey, "No corpses around.");
		}
		foreach (KeyValuePair<double, WorldObject> item4 in list)
		{
			string text4 = _l.CorpseStatus(item4.Value.Id);
			bool flag = hashSet.Contains(item4.Value.Id);
			Vector4 col;
			if (flag && _l.IsCleared(item4.Value.Id))
			{
				text4 = "Cleared (right-click to loot)";
				col = Grey;
			}
			else if (flag)
			{
				text4 = ((CorpseKillers.Killer(item4.Value.Id) == null) ? "Checking who killed it" : "Not yours - not looted");
				col = Grey;
			}
			else if (text4 != null)
			{
				if (text4 == "Looting now")
				{
					col = Cyan;
				}
				else if (text4.StartsWith("Looted"))
				{
					col = Green;
				}
				else
				{
					col = ((!text4.StartsWith("Skipped")) ? Grey : Orange);
				}
			}
			else
			{
				bool flag2 = item4.Key >= 0.0 && item4.Key <= (double)_s.LootRange;
				text4 = (flag2 ? "Not looted yet" : "Out of range");
				col = (flag2 ? Yellow : Grey);
			}
			ImGui.TableNextRow();
			ImGui.TableSetColumnIndex(0);
			int id = item4.Value.Id;
			bool selected = false;
			try
			{
				selected = Globals.Core.Actions.CurrentSelection == id;
			}
			catch
			{
			}
			if (flag)
			{
				ImGui.PushStyleColor(ImGuiCol.Text, Grey);
			}
			bool flag3 = ImGui.Selectable(item4.Value.Name + "##corpse" + id, selected, ImGuiSelectableFlags.AllowDoubleClick);
			if (flag)
			{
				ImGui.PopStyleColor();
			}
			if (flag3)
			{
				try
				{
					Globals.Core.Actions.SelectItem(id);
					if (ImGui.IsMouseDoubleClicked(ImGuiMouseButton.Left))
					{
						Globals.Core.Actions.UseItem(id, 0);
					}
				}
				catch (Exception ex)
				{
					Util.LogError(ex);
				}
			}
			if (ImGui.IsItemClicked(ImGuiMouseButton.Right))
			{
				_l.Recheck(id);
			}
			Tip("Click to select, double-click to open, right-click to loot it again (after a skip, say).");
			ImGui.TableSetColumnIndex(1);
			string text5 = CorpseKillers.Killer(id);
			if (string.IsNullOrEmpty(text5))
			{
				Im.TextColored(Grey, (text5 == null) ? "..." : "?");
			}
			else
			{
				Vector4 col2;
				if (CorpseKillers.IsMine(text5))
				{
					col2 = Green;
				}
				else
				{
					col2 = (CorpseKillers.IsFellow(text5) ? Cyan : Grey);
				}
				Im.TextColored(col2, text5);
			}
			ImGui.TableSetColumnIndex(2);
			ImGui.TextUnformatted((item4.Key < 0.0) ? "?" : item4.Key.ToString("0"));
			ImGui.TableSetColumnIndex(3);
			Im.TextColored(col, text4);
		}
		ImGui.EndTable();
	}

	private void DrawLog()
	{
		if (!ImGui.CollapsingHeader("Looted (" + _l.Log.Count + ")"))
		{
			return;
		}
		foreach (Looter.LogEntry item in _l.Log)
		{
			Im.TextColored(Grey, item.Time);
			ImGui.SameLine();
			if (item.Rule.Length > 0)
			{
				Im.TextColored(Green, item.Rule);
				ImGui.SameLine(0f, 0f);
				ImGui.TextUnformatted(" - ");
				ImGui.SameLine(0f, 0f);
			}
			Im.TextColored(Orange, item.Name);
			if (item.Rest.Length > 0)
			{
				ImGui.SameLine(0f, 0f);
				Im.TextWrapped(", " + item.Rest);
			}
			if (!string.IsNullOrEmpty(item.Vs))
			{
				Vector4 col;
				if (item.VsColor == 10)
				{
					col = new Vector4(0.95f, 0.85f, 0.3f, 1f);
				}
				else if (item.VsColor == 18)
				{
					col = new Vector4(1f, 0.6f, 0.2f, 1f);
				}
				else if (item.VsColor == 15)
				{
					col = new Vector4(0.95f, 0.4f, 0.4f, 1f);
				}
				else
				{
					col = ((item.VsColor == 8) ? new Vector4(0.45f, 0.8f, 0.95f, 1f) : Grey);
				}
				ImGui.Indent(16f);
				ImGui.PushStyleColor(ImGuiCol.Text, col);
				Im.TextWrapped(item.Vs);
				ImGui.PopStyleColor();
				ImGui.Unindent(16f);
			}
		}
	}

	private static void Tip(string text)
	{
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip(text);
		}
	}
}
