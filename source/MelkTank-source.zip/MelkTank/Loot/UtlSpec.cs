using System;
using System.Collections.Generic;

namespace MelkTank.Loot;

public static class UtlSpec
{
	public class ReqType
	{
		public string Id;

		public string Name;

		public string[][] Fields;
	}

	private static readonly Dictionary<string, ReqType> _all;

	public static readonly List<ReqType> Ordered;

	public static readonly string[] Actions;

	public static readonly string[] ObjectClasses;

	public static readonly Dictionary<int, string> IntNames;

	public static readonly Dictionary<int, string> DoubleNames;

	public static readonly Dictionary<int, string> StringNames;

	private static void A(string id, string name, params string[] f)
	{
		string[][] array = new string[f.Length / 2][];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = new string[2]
			{
				f[i * 2],
				f[i * 2 + 1]
			};
		}
		ReqType reqType = new ReqType
		{
			Id = id,
			Name = name,
			Fields = array
		};
		_all[id] = reqType;
		Ordered.Add(reqType);
	}

	static UtlSpec()
	{
		_all = new Dictionary<string, ReqType>();
		Ordered = new List<ReqType>();
		Actions = new string[11]
		{
			"No loot", "Keep", "Salvage", "Sell", "Read", "User 1", "User 2", "User 3", "User 4", "User 5",
			"Keep up to"
		};
		ObjectClasses = new string[44]
		{
			"Unknown", "Melee weapon", "Armor", "Clothing", "Jewelry", "Monster", "Food", "Money", "Misc", "Missile weapon",
			"Container", "Gem", "Spell component", "Key", "Portal", "Trade note", "Mana stone", "Plant", "Base cooking", "Base alchemy",
			"Base fletching", "Crafted cooking", "Crafted alchemy", "Crafted fletching", "Player", "Vendor", "Door", "Corpse", "Lifestone", "Healing kit",
			"Lockpick", "Wand / staff / orb", "Bundle", "Book", "Journal", "Sign", "Housing", "NPC", "Foci", "Salvage",
			"Ust", "Services", "Scroll", "Combat pet"
		};
		IntNames = new Dictionary<int, string>
		{
			{ 5, "Burden" },
			{ 17, "Rare id" },
			{ 19, "Value" },
			{ 28, "Armor level" },
			{ 33, "Bonded" },
			{ 36, "Unenchantable" },
			{ 47, "Attack type" },
			{ 105, "Workmanship" },
			{ 106, "Spellcraft" },
			{ 107, "Current mana" },
			{ 108, "Max mana" },
			{ 109, "Arcane lore req" },
			{ 131, "Material" },
			{ 158, "Wield req type" },
			{ 159, "Wield req skill/attr" },
			{ 160, "Wield req value" },
			{ 179, "Imbued" },
			{ 265, "Armor set" },
			{ 292, "Cleave targets" },
			{ 319, "Item max level" },
			{ 352, "Cloak chance type" },
			{ 353, "Weapon mastery" },
			{ 370, "Damage rating" },
			{ 371, "Damage resist rating" },
			{ 372, "Crit rating" },
			{ 373, "Crit resist rating" },
			{ 374, "Crit damage rating" },
			{ 375, "Crit damage resist rating" },
			{ 376, "Heal boost rating" },
			{ 379, "Vitality rating" },
			{ 9031, "Split Arrow count" },
			{ 9060, "Weapon quality (grade)" },
			{ 9061, "Weapon tier" },
			{ 50109, "Gear tier" },
			{ 218103808, "WCID" },
			{ 218103809, "Icon" },
			{ 218103814, "Stack size" },
			{ 218103817, "Slot" },
			{ 218103821, "Coverage" },
			{ 218103822, "Equippable slots" },
			{ 218103825, "Missile type" },
			{ 218103838, "Spell count" },
			{ 218103839, "Speed" },
			{ 218103840, "Weapon skill" },
			{ 218103841, "Damage type" },
			{ 218103842, "Max damage" },
			{ 218103849, "Icon overlay" },
			{ 218103850, "Icon underlay" }
		};
		DoubleNames = new Dictionary<int, string>
		{
			{ 29, "Melee defense bonus" },
			{ 63, "Damage modifier" },
			{ 136, "Crushing Blow mult" },
			{ 144, "Mana conversion bonus" },
			{ 147, "Biting Strike chance" },
			{ 149, "Missile defense bonus" },
			{ 150, "Magic defense bonus" },
			{ 152, "Elemental dmg vs monsters" },
			{ 155, "Armor ignored" },
			{ 159, "Magic absorb" },
			{ 167772160, "Slash prot" },
			{ 167772161, "Pierce prot" },
			{ 167772162, "Bludgeon prot" },
			{ 167772163, "Acid prot" },
			{ 167772164, "Lightning prot" },
			{ 167772165, "Fire prot" },
			{ 167772166, "Cold prot" },
			{ 167772169, "Salvage workmanship" },
			{ 167772171, "Variance" },
			{ 167772172, "Attack bonus" },
			{ 167772174, "Damage bonus" }
		};
		StringNames = new Dictionary<int, string>
		{
			{ 1, "Name" },
			{ 7, "Inscription" },
			{ 8, "Inscribed by" },
			{ 14, "Use text" },
			{ 15, "Simple description" },
			{ 16, "Description" },
			{ 38, "Portal destination" },
			{ 39, "Last tinkered by" }
		};
		A("0", "Spell name matches", "Spell name regex", "regex");
		A("1", "Text property matches", "Regex", "regex", "Property", "skey");
		A("2", "Number property <=", "Value", "num", "Property", "ikey");
		A("3", "Number property >=", "Value", "num", "Property", "ikey");
		A("4", "Decimal property <=", "Value", "dec", "Property", "dkey");
		A("5", "Decimal property >=", "Value", "dec", "Property", "dkey");
		A("6", "Damage percent >= (never matches)", "Value", "dec");
		A("7", "Object class is", "Class", "oclass");
		A("8", "Spell count >=", "Count", "num");
		A("9", "Spells match", "Spell regex", "regex", "But not regex", "regex", "At least", "num");
		A("10", "Min damage >=", "Value", "dec");
		A("11", "Number property has flag", "Flag mask", "num", "Property", "ikey");
		A("12", "Number property =", "Value", "num", "Property", "ikey");
		A("13", "Number property is not", "Value", "num", "Property", "ikey");
		A("14", "Any similar color", "Red", "num", "Green", "num", "Blue", "num", "Max hue diff", "dec", "Max sat/val diff", "dec");
		A("15", "Similar color on armor type", "Red", "num", "Green", "num", "Blue", "num", "Max hue diff", "dec", "Max sat/val diff", "dec", "Armor group", "text");
		A("16", "Slot has similar color", "Red", "num", "Green", "num", "Blue", "num", "Max hue diff", "dec", "Max sat/val diff", "dec", "Slot", "num");
		A("17", "Slot has exact palette", "Slot", "num", "Palette", "num");
		A("1000", "Character skill >=", "Value", "num", "Skill", "skill");
		A("1001", "Main pack empty slots >=", "Slots", "num");
		A("1002", "Character level >=", "Level", "num");
		A("1003", "Character level <=", "Level", "num");
		A("1004", "Character base skill between", "Skill", "skill", "Min", "num", "Max", "num");
		A("2000", "Buffed median damage >=", "Value", "dec");
		A("2001", "Buffed missile damage >=", "Value", "dec");
		A("2003", "Buffed number property >=", "Value", "dec", "Property", "ikey");
		A("2005", "Buffed decimal property >=", "Value", "dec", "Property", "dkey");
		A("2006", "Calculated buffed tinked damage >=", "Value", "dec");
		A("2007", "Total ratings >=", "Value", "dec");
		A("2008", "Buffed tinked target melee", "Target DoT", "dec", "Melee D bonus", "dec", "Attack bonus", "dec");
		A("3001", "Damage vs equipped % >= (MelkTank)", "Value", "dec");
		A("3002", "Damage vs equipped with slayer % >= (MelkTank)", "Value", "dec");
		A("3003", "Gear mods vs equipped % >= (MelkTank)", "Value", "dec");
		A("3004", "Gear mods % of max >= (MelkTank)", "Value", "dec");
		A("3005", "Keep up to counts each name separately (MelkTank)", "On", "bool");
		A("9999", "Rule switched off", "Off", "bool");
	}

	public static ReqType Get(string id)
	{
		ReqType value;
		return (id != null && _all.TryGetValue(id, out value)) ? value : null;
	}

	public static string ActionName(string act)
	{
		int result;
		return (int.TryParse(act, out result) && result >= 0 && result < Actions.Length) ? Actions[result] : ("Action " + act);
	}

	public static string PropName(string kind, string key)
	{
		if (!int.TryParse(key, out var result))
		{
			return "?";
		}
		Dictionary<int, string> dictionary;
		if (kind == "dkey")
		{
			dictionary = DoubleNames;
		}
		else
		{
			dictionary = ((kind == "skey") ? StringNames : IntNames);
		}
		string value;
		return dictionary.TryGetValue(result, out value) ? value : ("#" + result);
	}

	public static string T11Tag(string regex)
	{
		if (regex == null || !regex.StartsWith("(?#T11 "))
		{
			return null;
		}
		int num = regex.IndexOf(')');
		return (num < 0) ? null : Uri.UnescapeDataString(regex.Substring(7, num - 7));
	}

	public static string Describe(UtlReq q)
	{
		ReqType reqType = Get(q.Type);
		if (reqType == null || q.Vals == null)
		{
			return "Unknown requirement " + q.Type + " (kept as is)";
		}
		List<string> v = q.Vals;
		Func<int, string> func = (int i) => (i < v.Count) ? v[i] : "";
		switch (q.Type)
		{
		case "1":
		{
			string text = T11Tag(func(0));
			return (text != null) ? ("T11 " + text + " (" + PropName("skey", func(1)) + ")") : (PropName("skey", func(1)) + " matches " + func(0));
		}
		case "2":
			return PropName("ikey", func(1)) + " <= " + func(0);
		case "3":
			return PropName("ikey", func(1)) + " >= " + func(0);
		case "4":
			return PropName("dkey", func(1)) + " <= " + func(0);
		case "5":
			return PropName("dkey", func(1)) + " >= " + func(0);
		case "11":
			return PropName("ikey", func(1)) + " has flag " + func(0);
		case "12":
			return PropName("ikey", func(1)) + " = " + func(0);
		case "13":
			return PropName("ikey", func(1)) + " is not " + func(0);
		case "2003":
			return "Buffed " + PropName("ikey", func(1)) + " >= " + func(0);
		case "2005":
			return "Buffed " + PropName("dkey", func(1)) + " >= " + func(0);
		case "7":
		{
			int result;
			return "Item type is " + ((int.TryParse(func(0), out result) && result >= 0 && result < ObjectClasses.Length) ? ObjectClasses[result] : func(0));
		}
		case "9":
			return "At least " + func(2) + " spell(s) like " + func(0) + ((func(1).Length > 0) ? (", not " + func(1)) : "");
		case "0":
			return "Has a spell like " + func(0);
		default:
			return reqType.Name + ((v.Count > 0) ? (": " + string.Join(", ", v.ToArray())) : "");
		}
	}
}
