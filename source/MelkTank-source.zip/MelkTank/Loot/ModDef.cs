namespace MelkTank.Loot;

public class ModDef
{
	public int Key;

	public string Name;

	public string Fmt;

	public string Band;

	public string Special;

	public string Unit;

	public bool Tenths;
}
