using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using Decal.Adapter.Wrappers;

namespace MelkTank.Loot;

public static class GearSnap
{
	private class Snap
	{
		public string Name = "";

		public bool Clean;

		public readonly Dictionary<int, int> L = new Dictionary<int, int>();

		public readonly Dictionary<int, double> D = new Dictionary<int, double>();

		public readonly Dictionary<int, string> S = new Dictionary<int, string>();

		public readonly List<int> Spells = new List<int>();
	}

	private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

	private static Dictionary<int, Snap> _snaps;

	public static Func<IEnumerable<int>> CharmIds;

	private static readonly HashSet<int> _askedListed = new HashSet<int>();

	private static string _file;

	private static DateTime _loadedAt = DateTime.MaxValue;

	private static DateTime _scanAt = DateTime.MinValue;

	private static readonly HashSet<int> Live = new HashSet<int> { 10, 218103810, 218103811, 218103814, 218103817, 218103818, 218103819, 231735296 };

	public static bool ForceLive;

	private static string FilePath
	{
		get
		{
			if (_file != null)
			{
				return _file;
			}
			string text = "";
			try
			{
				text = Globals.Core.CharacterFilter.Name ?? "";
			}
			catch
			{
			}
			if (text.Length == 0)
			{
				return null;
			}
			StringBuilder stringBuilder = new StringBuilder();
			string text2 = text;
			foreach (char c in text2)
			{
				stringBuilder.Append(char.IsLetterOrDigit(c) ? c : '_');
			}
			return _file = Util.FullPath("MelkTank_Gear_" + stringBuilder?.ToString() + ".txt");
		}
	}

	private static bool Load()
	{
		if (_snaps != null)
		{
			return true;
		}
		string filePath = FilePath;
		if (filePath == null)
		{
			return false;
		}
		_snaps = new Dictionary<int, Snap>();
		_loadedAt = DateTime.Now;
		try
		{
			if (!File.Exists(filePath))
			{
				return true;
			}
			string[] array = File.ReadAllLines(filePath);
			foreach (string text in array)
			{
				string[] array2 = text.Split(new char[1] { '|' }, 4);
				if (array2.Length < 3 || !int.TryParse(array2[0], NumberStyles.Integer, Inv, out var result))
				{
					continue;
				}
				if (!_snaps.TryGetValue(result, out var value))
				{
					value = (_snaps[result] = new Snap());
				}
				string s = ((array2.Length > 3) ? array2[3] : "");
				int result2;
				switch (array2[1])
				{
				case "N":
					value.Name = Unesc(array2[2]);
					break;
				case "C":
					value.Clean = array2[2] == "1";
					break;
				case "P":
					if (int.TryParse(array2[2], NumberStyles.Integer, Inv, out result2))
					{
						value.Spells.Add(result2);
					}
					break;
				case "L":
				{
					if (int.TryParse(array2[2], NumberStyles.Integer, Inv, out result2) && int.TryParse(s, NumberStyles.Integer, Inv, out var result4))
					{
						value.L[result2] = result4;
					}
					break;
				}
				case "D":
				{
					if (int.TryParse(array2[2], NumberStyles.Integer, Inv, out result2) && double.TryParse(s, NumberStyles.Float, Inv, out var result3))
					{
						value.D[result2] = result3;
					}
					break;
				}
				case "S":
					if (int.TryParse(array2[2], NumberStyles.Integer, Inv, out result2))
					{
						value.S[result2] = Unesc(s);
					}
					break;
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		return true;
	}

	private static string Esc(string s)
	{
		return (s ?? "").Replace("\\", "\\\\").Replace("\r", "").Replace("\n", "\\n")
			.Replace("|", "\\p");
	}

	private static string Unesc(string s)
	{
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < s.Length; i++)
		{
			if (s[i] == '\\' && i + 1 < s.Length)
			{
				char c = s[++i];
				stringBuilder.Append(c switch
				{
					'p' => '|', 
					'n' => '\n', 
					_ => c, 
				});
			}
			else
			{
				stringBuilder.Append(s[i]);
			}
		}
		return stringBuilder.ToString();
	}

	private static void Save()
	{
		string filePath = FilePath;
		if (filePath == null || _snaps == null)
		{
			return;
		}
		try
		{
			if ((DateTime.Now - _loadedAt).TotalSeconds > 120.0)
			{
				HashSet<int> hashSet = new HashSet<int>();
				foreach (WorldObject item in InvCache.All())
				{
					hashSet.Add(item.Id);
				}
				if (hashSet.Count > 0)
				{
					List<int> list = new List<int>();
					foreach (int key in _snaps.Keys)
					{
						if (!hashSet.Contains(key) && !Listed(key))
						{
							list.Add(key);
						}
					}
					foreach (int item2 in list)
					{
						_snaps.Remove(item2);
					}
				}
			}
			StringBuilder stringBuilder = new StringBuilder();
			foreach (KeyValuePair<int, Snap> snap in _snaps)
			{
				string value = snap.Key.ToString(Inv);
				stringBuilder.Append(value).Append("|N|").Append(Esc(snap.Value.Name))
					.Append("\r\n");
				stringBuilder.Append(value).Append("|C|").Append(snap.Value.Clean ? "1" : "0")
					.Append("\r\n");
				foreach (KeyValuePair<int, int> item3 in snap.Value.L)
				{
					stringBuilder.Append(value).Append("|L|").Append(item3.Key.ToString(Inv))
						.Append('|')
						.Append(item3.Value.ToString(Inv))
						.Append("\r\n");
				}
				foreach (KeyValuePair<int, double> item4 in snap.Value.D)
				{
					stringBuilder.Append(value).Append("|D|").Append(item4.Key.ToString(Inv))
						.Append('|')
						.Append(item4.Value.ToString("R", Inv))
						.Append("\r\n");
				}
				foreach (KeyValuePair<int, string> item5 in snap.Value.S)
				{
					stringBuilder.Append(value).Append("|S|").Append(item5.Key.ToString(Inv))
						.Append('|')
						.Append(Esc(item5.Value))
						.Append("\r\n");
				}
				foreach (int spell in snap.Value.Spells)
				{
					stringBuilder.Append(value).Append("|P|").Append(spell.ToString(Inv))
						.Append("\r\n");
				}
			}
			Util.WriteShared(filePath, stringBuilder.ToString());
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static bool Listed(int id)
	{
		try
		{
			if (ItemCompare.IsCompare(id))
			{
				return true;
			}
			if (ArmorCompare.ListedShields != null)
			{
				foreach (int item in ArmorCompare.ListedShields())
				{
					if (item == id)
					{
						return true;
					}
				}
			}
			if (ItemCompare.ListedIds != null)
			{
				foreach (int item2 in ItemCompare.ListedIds())
				{
					if (item2 == id)
					{
						return true;
					}
				}
			}
			if (CharmIds != null)
			{
				foreach (int item3 in CharmIds())
				{
					if (item3 == id)
					{
						return true;
					}
				}
			}
		}
		catch
		{
		}
		return false;
	}

	public static bool IsReference(WorldObject o)
	{
		if (o == null)
		{
			return false;
		}
		if (Listed(o.Id))
		{
			return true;
		}
		if (LootMatcher.LiveLong(o, 10) == 0)
		{
			return false;
		}
		return ArmorCompare.IsGear(o) || ItemCompare.IsWeapon(o);
	}

	public static bool Has(int id)
	{
		return Load() && _snaps.ContainsKey(id);
	}

	public static bool Known(WorldObject o)
	{
		return o != null && (o.HasIdData || Has(o.Id));
	}

	private static bool UseSaved(WorldObject o, out Snap s)
	{
		s = null;
		if (ForceLive)
		{
			return false;
		}
		if (o == null || !Load() || !_snaps.TryGetValue(o.Id, out s))
		{
			return false;
		}
		if (!o.HasIdData)
		{
			return true;
		}
		// (a tier 11+ item: always its numbers as they are in tier - zone locked here, the live ones are cut down)
		if (s.Clean && Tier(s))
		{
			return true;
		}
		if (!s.Clean || !ItemCompare.IsWeapon(o))
		{
			return false;
		}
		if (ItemCompare.IsCompare(o.Id))
		{
			return true;
		}
		if (OutOfZone(o))
		{
			return true;
		}
		return LootMatcher.LiveLong(o, 10) != 0 || ItemCompare.IsEquipped(o) || ItemCompare.BuffedReason(o) != null;
	}

	public static bool TryLong(WorldObject o, int key, out int v)
	{
		v = 0;
		if (Live.Contains(key) || !UseSaved(o, out var s))
		{
			return false;
		}
		return s.L.TryGetValue(key, out v);
	}

	public static bool TryDbl(WorldObject o, int key, out double v)
	{
		v = 0.0;
		if (!UseSaved(o, out var s))
		{
			return false;
		}
		return s.D.TryGetValue(key, out v);
	}

	public static bool TryStr(WorldObject o, int key, out string v)
	{
		v = null;
		if (!UseSaved(o, out var s))
		{
			return false;
		}
		return s.S.TryGetValue(key, out v);
	}

	private static bool Tier(Snap s)
	{
		return s != null && s.S.TryGetValue(16, out var d) && d != null && d.IndexOf("Augmentations", StringComparison.OrdinalIgnoreCase) >= 0 && d.IndexOf("Zone Locked", StringComparison.OrdinalIgnoreCase) < 0;
	}

	/// <summary>Its in-tier numbers are kept (a tier 11+ item ID'd somewhere it's at full power).</summary>
	public static bool HasTier(int id)
	{
		Snap value;
		return Load() && _snaps.TryGetValue(id, out value) && value.Clean && Tier(value);
	}

	public static bool HasClean(int id)
	{
		Snap value;
		return Load() && _snaps.TryGetValue(id, out value) && value.Clean;
	}

	public static List<int> Spells(WorldObject o)
	{
		if (o == null || !Load() || !_snaps.TryGetValue(o.Id, out var value) || o.HasIdData)
		{
			return null;
		}
		return value.Spells;
	}

	public static bool OutOfZone(WorldObject o)
	{
		try
		{
			string text = LootMatcher.LiveStr(o, 16) ?? "";
			if (text.IndexOf("Augmentations", StringComparison.OrdinalIgnoreCase) < 0)
			{
				return false;
			}
			int num = Session.CurrentTier();
			return num >= 0 && num < 11;
		}
		catch
		{
			return false;
		}
	}

	public static void OnIdentified(int id)
	{
		try
		{
			WorldObject worldObject = Globals.Core.WorldFilter[id];
			if (worldObject == null || !worldObject.HasIdData || !IsReference(worldObject) || !Load())
			{
				return;
			}
			// (ID'd where it's zone locked: the game shows those numbers, but they aren't what it is - not kept)
			if (ItemCompare.ZoneLocked(worldObject))
			{
				return;
			}
			Snap snap = Take(worldObject);
			_snaps.TryGetValue(id, out var value);
			if ((!snap.Clean && value != null && value.Clean) || (value != null && ItemCompare.IsWeapon(worldObject) && OutOfZone(worldObject)))
			{
				return;
			}
			if (value != null && snap.S.TryGetValue(14, out var value2) && ArmorCompare.PowerReduced(value2) && value.S.TryGetValue(14, out var value3) && !ArmorCompare.PowerReduced(value3))
			{
				snap.S[14] = value3;
			}
			if (((value == null) ? (-1) : Diff(value, snap)) == 0)
			{
				return;
			}
			_snaps[id] = snap;
			Save();
			bool flag = false;
			if (CharmIds != null)
			{
				foreach (int item in CharmIds())
				{
					if (item == id)
					{
						flag = true;
						break;
					}
				}
			}
			if (flag)
			{
				return;
			}
			if (value == null)
			{
				Util.WriteToChat("Gear saved for compares: " + ItemReport.FullName(worldObject) + ".");
			}
			else if (RealChange(value, snap))
			{
				Util.WriteToChat("Gear updated: " + ItemReport.FullName(worldObject) + " changed - saved.");
			}
			else if (TextDiff(value, snap))
			{
				try
				{
					Util.AppendShared(Util.FullPath("MelkTank_GearChanges.txt"), DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + ItemReport.FullName(worldObject) + " - " + WhatChanged(value, snap) + Environment.NewLine);
					return;
				}
				catch
				{
					return;
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void Tick()
	{
		if (DateTime.Now < _scanAt)
		{
			return;
		}
		_scanAt = DateTime.Now.AddSeconds(20.0);
		try
		{
			if (!Load())
			{
				return;
			}
			foreach (WorldObject item in InvCache.All())
			{
				if (item.HasIdData && IsReference(item) && (!_snaps.ContainsKey(item.Id) || (!_snaps[item.Id].Clean && ItemCompare.IsWeapon(item) && LootMatcher.LiveLong(item, 10) == 0 && ItemCompare.BuffedReason(item) == null)))
				{
					OnIdentified(item.Id);
				}
			}
			if (ItemCompare.ListedIds != null)
			{
				foreach (int item2 in ItemCompare.ListedIds())
				{
					if (_snaps.ContainsKey(item2) || !_askedListed.Add(item2))
					{
						continue;
					}
					WorldObject worldObject = Globals.Core.WorldFilter[item2];
					if (worldObject == null)
					{
						continue;
					}
					if (worldObject.HasIdData)
					{
						OnIdentified(item2);
						continue;
					}
					try
					{
						Util.RequestId(item2);
					}
					catch
					{
					}
				}
			}
			if (ItemCompare.CompareIds == null)
			{
				return;
			}
			foreach (int item3 in ItemCompare.CompareIds())
			{
				if (item3 != 0 && !_snaps.ContainsKey(item3))
				{
					WorldObject worldObject2 = Globals.Core.WorldFilter[item3];
					if (worldObject2 != null && worldObject2.HasIdData)
					{
						OnIdentified(item3);
					}
				}
			}
		}
		catch
		{
		}
	}

	private static Snap Take(WorldObject o)
	{
		Snap snap = new Snap
		{
			Name = (o.Name ?? "")
		};
		snap.Clean = !ItemCompare.IsWeapon(o) || (LootMatcher.LiveLong(o, 10) == 0 && ItemCompare.BuffedReason(o) == null);
		foreach (int longKey in o.LongKeys)
		{
			if (!Live.Contains(longKey))
			{
				snap.L[longKey] = LootMatcher.LiveLong(o, longKey);
			}
		}
		foreach (int doubleKey in o.DoubleKeys)
		{
			snap.D[doubleKey] = LootMatcher.LiveDbl(o, doubleKey);
		}
		foreach (int stringKey in o.StringKeys)
		{
			snap.S[stringKey] = LootMatcher.LiveStr(o, stringKey);
		}
		try
		{
			for (int i = 0; i < o.SpellCount; i++)
			{
				snap.Spells.Add(o.Spell(i));
			}
		}
		catch
		{
		}
		return snap;
	}

	private static bool RealChange(Snap a, Snap b)
	{
		if (!string.Equals(a.Name, b.Name, StringComparison.Ordinal))
		{
			return true;
		}
		if (a.Spells.Count != b.Spells.Count)
		{
			return true;
		}
		List<int> list = new List<int>(a.Spells);
		List<int> list2 = new List<int>(b.Spells);
		list.Sort();
		list2.Sort();
		for (int i = 0; i < list.Count; i++)
		{
			if (list[i] != list2[i])
			{
				return true;
			}
		}
		return false;
	}

	private static string WhatChanged(Snap a, Snap b)
	{
		List<string> list = new List<string>();
		foreach (KeyValuePair<int, string> item in b.S)
		{
			if (!a.S.TryGetValue(item.Key, out var value) || value != item.Value)
			{
				list.Add("S" + item.Key);
			}
		}
		if (a.Spells.Count != b.Spells.Count)
		{
			list.Add("spells " + a.Spells.Count + "->" + b.Spells.Count);
		}
		else
		{
			for (int i = 0; i < a.Spells.Count; i++)
			{
				if (a.Spells[i] != b.Spells[i])
				{
					list.Add("spell order");
					break;
				}
			}
		}
		return string.Join(", ", list.ToArray());
	}

	private static bool TextDiff(Snap a, Snap b)
	{
		foreach (KeyValuePair<int, string> item in b.S)
		{
			if (!a.S.TryGetValue(item.Key, out var value) || value != item.Value)
			{
				return true;
			}
		}
		if (a.Spells.Count != b.Spells.Count)
		{
			return true;
		}
		for (int i = 0; i < a.Spells.Count; i++)
		{
			if (a.Spells[i] != b.Spells[i])
			{
				return true;
			}
		}
		return false;
	}

	private static int Diff(Snap a, Snap b)
	{
		int num = 0;
		foreach (KeyValuePair<int, int> item in b.L)
		{
			if (!a.L.TryGetValue(item.Key, out var value) || value != item.Value)
			{
				num++;
			}
		}
		foreach (KeyValuePair<int, double> item2 in b.D)
		{
			if (!a.D.TryGetValue(item2.Key, out var value2) || Math.Abs(value2 - item2.Value) > 1E-09)
			{
				num++;
			}
		}
		foreach (KeyValuePair<int, string> item3 in b.S)
		{
			if (!a.S.TryGetValue(item3.Key, out var value3) || value3 != item3.Value)
			{
				num++;
			}
		}
		if (a.Spells.Count != b.Spells.Count)
		{
			num++;
		}
		else
		{
			for (int i = 0; i < a.Spells.Count; i++)
			{
				if (a.Spells[i] != b.Spells[i])
				{
					num++;
					break;
				}
			}
		}
		return num;
	}
}
