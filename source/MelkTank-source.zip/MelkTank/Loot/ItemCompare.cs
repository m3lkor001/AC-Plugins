using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using Decal.Adapter.Wrappers;

namespace MelkTank.Loot;

public static class ItemCompare
{
	private class Card
	{
		public string Key;

		public string Label;

		public string Text;

		public double Value;
	}

	private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

	private const int ElemVsMonsters = 152;

	private const int EquippedSlots = 10;

	private const int WandElement = 45;

	private const int Mastery = 353;

	private const int MaxDamage = 218103842;

	private static Dictionary<string, double> _base;

	private static readonly int[] DefenseProps = new int[4] { 29, 167772172, 149, 150 };

	private static readonly string[] DefenseNames = new string[4] { "md", "as", "msd", "mgd" };

	private static string _charFile;

	public static Func<IEnumerable<int>> ListedIds;

	private static bool _notYet;

	private static DateTime _loadedAt = DateTime.MaxValue;

	private const bool NoItemBuffs = true;

	public static Func<List<int>> CompareIds;

	public static readonly string[] GroupNames = new string[5] { "", "Wand", "Missile", "Two-handed", "One-handed" };

	private static int _askedId;

	private static DateTime _askedAt = DateTime.MinValue;

	private static readonly HashSet<int> _askedOnce = new HashSet<int>();

	private static WorldObject _forceEq;

	private static readonly Dictionary<int, string> ElemNames = new Dictionary<int, string>
	{
		{ 1, "Slash" },
		{ 2, "Pierce" },
		{ 3, "Slash/Pierce" },
		{ 128, "Void" },
		{ 4, "Bludgeon" },
		{ 8, "Cold" },
		{ 16, "Fire" },
		{ 32, "Acid" },
		{ 64, "Lightning" },
		{ 1024, "Nether" }
	};

	private static readonly Regex GradeRx = new Regex("^Weapon Grade:\\s*(\\S+)\\s*\\((\\d+)%");

	private static readonly Regex RendRx = new Regex("^(\\w+) Rending:\\s*\\+?(\\d+)%");

	private static readonly Regex BitingRx = new Regex("^Biting Strike:\\s*\\+?(\\d+)%");

	private static readonly Regex CrushRx = new Regex("^Crushing Blow:\\s*([\\d.]+)x");

	private static readonly Regex SlayerRx = new Regex("^(.+?) Slayer:\\s*([\\d.]+)x");

	private static readonly Regex ProcRx = new Regex("^Cast on Strike:\\s*([^(]+?)\\s*\\((\\d+)%");

	private static readonly Regex CleaveRx = new Regex("^Cleav\\w*:\\s*\\+?(\\d+)", RegexOptions.IgnoreCase);

	private static readonly Regex SarRx = new Regex("^Spell Armor Rend\\w*:\\s*\\+?([\\d.]+)%", RegexOptions.IgnoreCase);

	private static readonly Dictionary<int, string[]> RendNames = new Dictionary<int, string[]>
	{
		{
			1,
			new string[2] { "Slash", "Slashing" }
		},
		{
			2,
			new string[2] { "Pierce", "Piercing" }
		},
		{
			4,
			new string[3] { "Bludgeon", "Bludgeoning", "Blunt" }
		},
		{
			8,
			new string[2] { "Cold", "Frost" }
		},
		{
			16,
			new string[2] { "Fire", "Flame" }
		},
		{
			32,
			new string[1] { "Acid" }
		},
		{
			64,
			new string[2] { "Electric", "Lightning" }
		},
		{
			1024,
			new string[2] { "Void", "Nether" }
		}
	};

	private const int MaxDamageKey = 218103842;

	private const int VarianceKey = 167772171;

	private static readonly Dictionary<int, DateTime> _refreshAt = new Dictionary<int, DateTime>();

	private static bool _zone;

	private static string SharedPath => Util.FullPath("MelkTank_BaseStats.txt");

	private static string FilePath
	{
		get
		{
			if (_charFile != null)
			{
				return _charFile;
			}
			string text = "";
			try
			{
				text = Globals.Core.CharacterFilter.Name ?? "";
			}
			catch
			{
			}
			if (text.Length == 0)
			{
				return null;
			}
			StringBuilder stringBuilder = new StringBuilder();
			string text2 = text;
			foreach (char c in text2)
			{
				stringBuilder.Append(char.IsLetterOrDigit(c) ? c : '_');
			}
			return _charFile = Util.FullPath("MelkTank_BaseStats_" + stringBuilder?.ToString() + ".txt");
		}
	}

	private static string Key(int id, int prop)
	{
		return (prop == 152) ? id.ToString(Inv) : (id.ToString(Inv) + ":" + prop.ToString(Inv));
	}

	private static HashSet<int> Owned()
	{
		HashSet<int> hashSet = new HashSet<int>();
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				hashSet.Add(item.Id);
			}
			if (hashSet.Count == 0)
			{
				return null;
			}
			if (ListedIds != null)
			{
				foreach (int item2 in ListedIds())
				{
					hashSet.Add(item2);
				}
			}
		}
		catch
		{
			return null;
		}
		return hashSet;
	}

	private static int IdOf(string key)
	{
		int num = key.IndexOf(':');
		int result;
		return int.TryParse((num < 0) ? key : key.Substring(0, num), NumberStyles.Integer, Inv, out result) ? result : 0;
	}

	private static void ReadInto(string path, Dictionary<string, double> into)
	{
		string[] array = Util.Locked(path, () => File.ReadAllLines(path));
		foreach (string text in array)
		{
			string[] array2 = text.Split('|');
			if (array2.Length >= 2 && array2[0].Length > 0 && double.TryParse(array2[1], NumberStyles.Float, Inv, out var result))
			{
				into[array2[0]] = result;
			}
		}
	}

	private static void Load()
	{
		if (_base != null && !_notYet)
		{
			return;
		}
		string filePath = FilePath;
		if (filePath == null)
		{
			_base = new Dictionary<string, double>();
			_notYet = true;
			return;
		}
		_notYet = false;
		_loadedAt = DateTime.Now;
		_base = new Dictionary<string, double>();
		try
		{
			if (File.Exists(filePath))
			{
				ReadInto(filePath, _base);
			}
			else
			{
				if (!File.Exists(SharedPath))
				{
					return;
				}
				Dictionary<string, double> dictionary = new Dictionary<string, double>();
				ReadInto(SharedPath, dictionary);
				HashSet<int> hashSet = Owned();
				if (hashSet == null)
				{
					_base = dictionary;
					return;
				}
				foreach (KeyValuePair<string, double> item in dictionary)
				{
					if (hashSet.Contains(IdOf(item.Key)))
					{
						_base[item.Key] = item.Value;
					}
				}
				Save();
				Util.WriteToChat("MelkTank: weapon base stats moved to " + Path.GetFileName(filePath) + " (" + _base.Count + " of " + dictionary.Count + " entries - the ones you carry).");
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void Save()
	{
		string filePath = FilePath;
		if (filePath == null || _base == null || _notYet)
		{
			return;
		}
		try
		{
			HashSet<int> hashSet = (((DateTime.Now - _loadedAt).TotalSeconds > 120.0) ? Owned() : null);
			if (hashSet != null)
			{
				List<string> list = new List<string>();
				foreach (string key in _base.Keys)
				{
					if (!hashSet.Contains(IdOf(key)))
					{
						list.Add(key);
					}
				}
				foreach (string item in list)
				{
					_base.Remove(item);
				}
			}
			StringBuilder stringBuilder = new StringBuilder();
			foreach (KeyValuePair<string, double> item2 in _base)
			{
				stringBuilder.Append(item2.Key).Append('|').Append(item2.Value.ToString("R", Inv))
					.Append("\r\n");
			}
			Util.WriteShared(filePath, stringBuilder.ToString());
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static bool Carried(WorldObject o)
	{
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (item.Id == o.Id)
				{
					return true;
				}
			}
		}
		catch
		{
		}
		return false;
	}

	public static bool IsWeapon(WorldObject o)
	{
		ObjectClass objectClass = o.ObjectClass;
		return objectClass == ObjectClass.WandStaffOrb || objectClass == ObjectClass.MeleeWeapon || objectClass == ObjectClass.MissileWeapon;
	}

	public static bool IsEquipped(WorldObject o)
	{
		return LootMatcher.Long(o, 10) != 0;
	}

	public static void Remember(WorldObject o)
	{
		try
		{
			if (o == null || !o.HasIdData || !IsWeapon(o) || IsEquipped(o) || !Carried(o) || LooksBuffed(o) != null || ZoneLocked(o))
			{
				return;
			}
			Load();
			if (_notYet)
			{
				return;
			}
			bool flag = false;
			List<int> list = new List<int> { 152 };
			list.AddRange(DefenseProps);
			foreach (int item in list)
			{
				double num = LootMatcher.Dbl(o, item);
				string key = Key(o.Id, item);
				if (!_base.TryGetValue(key, out var value) || !(Math.Abs(value - num) < 1E-09))
				{
					_base[key] = num;
					flag = true;
				}
			}
			int num2 = LootMatcher.Long(o, 218103842);
			if (num2 > 0)
			{
				string key2 = o.Id.ToString(Inv) + ":L" + 218103842.ToString(Inv);
				if (!_base.TryGetValue(key2, out var value2) || Math.Abs(value2 - (double)num2) > 1E-09)
				{
					_base[key2] = num2;
					flag = true;
				}
			}
			if (flag)
			{
				Save();
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static bool IsCompare(int id)
	{
		try
		{
			return id != 0 && CompareIds != null && CompareIds().Contains(id);
		}
		catch
		{
			return false;
		}
	}

	public static int Group(WorldObject o)
	{
		if (o == null)
		{
			return 0;
		}
		switch (o.ObjectClass)
		{
		case ObjectClass.WandStaffOrb:
			return 1;
		case ObjectClass.MissileWeapon:
			return 2;
		case ObjectClass.MeleeWeapon:
		{
			int num = 0;
			try
			{
				num = o.Values(LongValueKey.EquipableSlots);
			}
			catch
			{
			}
			return ((num & 0x2000000) != 0) ? 3 : 4;
		}
		default:
			return 0;
		}
	}

	public static int CompareFor(WorldObject o)
	{
		int num = Group(o);
		if (num == 0 || CompareIds == null)
		{
			return 0;
		}
		foreach (int item in CompareIds())
		{
			WorldObject worldObject = Globals.Core.WorldFilter[item];
			if (worldObject != null && Group(worldObject) == num)
			{
				return item;
			}
		}
		return 0;
	}

	private static WorldObject CompareCounterpart(WorldObject o)
	{
		bool pending;
		return CompareCounterpart(o, out pending);
	}

	private static WorldObject CompareCounterpart(WorldObject o, out bool pending)
	{
		pending = false;
		int num = CompareFor(o);
		if (num == 0 || num == o.Id)
		{
			return null;
		}
		WorldObject worldObject = Globals.Core.WorldFilter[num];
		if (worldObject == null || worldObject.ObjectClass != o.ObjectClass)
		{
			return null;
		}
		if (!worldObject.HasIdData && GearSnap.Has(num))
		{
			if (_askedOnce.Add(num))
			{
				try
				{
					Util.RequestId(num);
				}
				catch
				{
				}
			}
			return SameElementOk(worldObject, o) ? worldObject : null;
		}
		if (!worldObject.HasIdData)
		{
			pending = true;
			if (_askedId != num || (DateTime.Now - _askedAt).TotalSeconds > 10.0)
			{
				_askedId = num;
				_askedAt = DateTime.Now;
				try
				{
					Util.RequestId(num);
				}
				catch
				{
				}
			}
			return null;
		}
		return SameElementOk(worldObject, o) ? worldObject : null;
	}

	public static bool CompareWaiting(WorldObject o)
	{
		if (o == null || !IsWeapon(o) || IsEquipped(o) || ItemInfo.IsAmmo(o))
		{
			return false;
		}
		CompareCounterpart(o, out var pending);
		return pending;
	}

	public static bool UsesCompareWeapon(WorldObject o)
	{
		WorldObject worldObject = ((o != null && IsWeapon(o) && !IsEquipped(o) && !ItemInfo.IsAmmo(o)) ? CompareCounterpart(o) : null);
		return worldObject != null && !IsEquipped(worldObject);
	}

	public static WorldObject OffhandWeapon()
	{
		try
		{
			int id = Globals.Core.CharacterFilter.Id;
			foreach (WorldObject item in InvCache.All())
			{
				if (item.ObjectClass == ObjectClass.MeleeWeapon && item.Values(LongValueKey.Wielder, 0) == id && (item.Values(LongValueKey.EquippedSlots, 0) & 0x200000) != 0)
				{
					return item;
				}
			}
		}
		catch
		{
		}
		return null;
	}

	public static string DescribeOffhand(WorldObject o, out int color)
	{
		color = 7;
		if (o == null || o.ObjectClass != ObjectClass.MeleeWeapon || IsEquipped(o) || CombatEngine.IsTwoHanded(o.Id))
		{
			return null;
		}
		WorldObject worldObject = OffhandWeapon();
		if (worldObject == null)
		{
			return null;
		}
		WorldObject worldObject2 = EquippedCounterpart(o);
		if (worldObject2 != null && worldObject2.Id == worldObject.Id)
		{
			return null;
		}
		_forceEq = worldObject;
		try
		{
			return Describe(o, out color)?.Replace(" | vs equipped ", " | vs off hand ");
		}
		finally
		{
			_forceEq = null;
		}
	}

	public static WorldObject EquippedCounterpart(WorldObject o)
	{
		if (o == null || !IsWeapon(o) || IsEquipped(o) || ItemInfo.IsAmmo(o))
		{
			return null;
		}
		if (_forceEq != null)
		{
			return _forceEq;
		}
		WorldObject worldObject = CompareCounterpart(o, out var pending);
		if (worldObject != null)
		{
			return worldObject;
		}
		if (pending)
		{
			return null;
		}
		int num = Element(o);
		foreach (WorldObject item in InvCache.All())
		{
			if (item.Id == o.Id || !IsEquipped(item) || item.ObjectClass != o.ObjectClass || ItemInfo.IsAmmo(item) || Element(item) != num)
			{
				continue;
			}
			return item;
		}
		return null;
	}

	private static bool SameElementOk(WorldObject w, WorldObject o)
	{
		return true;
	}

	private static string ElemName(int e)
	{
		string result;
		if (ElemNames.TryGetValue(e, out var value))
		{
			result = value;
		}
		else
		{
			result = ((e == 0) ? "?" : ("#" + e));
		}
		return result;
	}

	private static int Element(WorldObject o)
	{
		if (o.ObjectClass == ObjectClass.WandStaffOrb)
		{
			return LootMatcher.Long(o, 45);
		}
		int num = LootMatcher.Long(o, 218103841);
		return (num != 0) ? num : LootMatcher.Long(o, 45);
	}

	private static Dictionary<string, Card> Cards(WorldObject o)
	{
		Dictionary<string, Card> dictionary = new Dictionary<string, Card>();
		string text = LootMatcher.Str(o, 16) ?? "";
		string[] array = text.Replace("\r", "").Split('\n');
		foreach (string text2 in array)
		{
			string text3 = text2.Trim();
			if (text3.StartsWith("- "))
			{
				text3 = text3.Substring(2).Trim();
				Match match;
				if ((match = SarRx.Match(text3)).Success)
				{
					dictionary["sar"] = new Card
					{
						Key = "sar",
						Label = "Spell Armor Rend",
						Text = match.Groups[1].Value + "%",
						Value = Num(match.Groups[1].Value)
					};
				}
				else if ((match = GradeRx.Match(text3)).Success)
				{
					dictionary["grade"] = new Card
					{
						Key = "grade",
						Label = "Grade",
						Text = match.Groups[1].Value + " " + match.Groups[2].Value + "%",
						Value = Num(match.Groups[2].Value)
					};
				}
				else if ((match = RendRx.Match(text3)).Success)
				{
					string value = match.Groups[1].Value;
					dictionary["rend:" + value] = new Card
					{
						Key = "rend:" + value,
						Label = ((value == "Void") ? "Void" : value) + " Rend",
						Text = "+" + match.Groups[2].Value + "%",
						Value = Num(match.Groups[2].Value)
					};
				}
				else if ((match = BitingRx.Match(text3)).Success)
				{
					dictionary["biting"] = new Card
					{
						Key = "biting",
						Label = "Biting Strike",
						Text = "+" + match.Groups[1].Value + "%",
						Value = Num(match.Groups[1].Value)
					};
				}
				else if ((match = CrushRx.Match(text3)).Success)
				{
					dictionary["crush"] = new Card
					{
						Key = "crush",
						Label = "Crushing Blow",
						Text = match.Groups[1].Value + "x",
						Value = Num(match.Groups[1].Value)
					};
				}
				else if ((match = SlayerRx.Match(text3)).Success)
				{
					string value2 = match.Groups[1].Value;
					dictionary["slayer:" + value2] = new Card
					{
						Key = "slayer:" + value2,
						Label = value2 + " Slayer",
						Text = match.Groups[2].Value + "x",
						Value = Num(match.Groups[2].Value)
					};
				}
				else if ((match = CleaveRx.Match(text3)).Success)
				{
					dictionary["cleave"] = new Card
					{
						Key = "cleave",
						Label = "Cleave",
						Text = "+" + match.Groups[1].Value,
						Value = Num(match.Groups[1].Value)
					};
				}
				else if ((match = ProcRx.Match(text3)).Success)
				{
					string text4 = match.Groups[1].Value.Trim();
					dictionary["proc:" + text4] = new Card
					{
						Key = "proc:" + text4,
						Label = "Proc " + text4,
						Text = match.Groups[2].Value + "%",
						Value = Num(match.Groups[2].Value)
					};
				}
			}
		}
		return dictionary;
	}

	private static double BestRend(Dictionary<string, Card> d)
	{
		double num = 0.0;
		foreach (Card value in d.Values)
		{
			if (value.Key.StartsWith("rend:") && value.Value > num)
			{
				num = value.Value;
			}
		}
		return num;
	}

	private static double Num(string s)
	{
		double result;
		return double.TryParse(s, NumberStyles.Float, Inv, out result) ? result : 0.0;
	}

	private static string Signed(double d, string unit, string fmt)
	{
		if (Math.Abs(d) < 1E-09)
		{
			return "=";
		}
		return ((d > 0.0) ? "+" : "-") + Math.Abs(d).ToString(fmt, Inv) + unit;
	}

	private static void Num(List<string> parts, string label, double mine, double theirs, bool mult, ref int up, ref int down)
	{
		if (!(mine <= 0.0) || !(theirs <= 0.0))
		{
			if (mine > theirs + 1E-09)
			{
				up++;
			}
			else if (mine < theirs - 1E-09)
			{
				down++;
			}
			string text = (mult ? ItemReport.MultPct(mine) : ("+" + mine.ToString("0", Inv)));
			string text2 = (mult ? ItemReport.MultPct(theirs) : ("+" + theirs.ToString("0", Inv)));
			string text3 = (mult ? Signed((mine - theirs) * 100.0, "%", "0.#") : Signed(mine - theirs, "", "0"));
			parts.Add(label + " " + text + " vs " + text2 + " (" + text3 + ")");
		}
	}

	private static string Pc(double m)
	{
		return Math.Round((m - 1.0) * 100.0, 1).ToString("0.#", Inv) + "%";
	}

	private static double MatchingRend(WorldObject o, Dictionary<string, Card> cards)
	{
		if (RendNames.TryGetValue(LootMatcher.Long(o, 45), out var value))
		{
			string[] array = value;
			foreach (string text in array)
			{
				if (cards.TryGetValue("rend:" + text, out var value2))
				{
					return value2.Value;
				}
			}
			return 0.0;
		}
		return BestRend(cards);
	}

	private static int CurrentTier()
	{
		try
		{
			CombatEngine currentEngine = PluginCore.CurrentEngine;
			if (currentEngine != null && currentEngine.Tier != null && currentEngine.Tier.Tier >= 11)
			{
				return currentEngine.Tier.Tier;
			}
		}
		catch
		{
		}
		return 11;
	}

	private static double SarFactor(double pct, int tier)
	{
		if (pct <= 0.0)
		{
			return 1.0;
		}
		double num = (double)tier * 100.0;
		double num2 = 66.6;
		return (num + num2) / (num * (1.0 - Math.Min(99.0, pct) / 100.0) + num2);
	}

	private static double Slayer(Dictionary<string, Card> cards, string species)
	{
		Card value;
		return (cards.TryGetValue("slayer:" + species, out value) && value.Value > 0.0) ? value.Value : 1.0;
	}

	private static double HitValue(WorldObject o, Dictionary<string, Card> c, double arrow)
	{
		double num2;
		if (o.ObjectClass == ObjectClass.MissileWeapon)
		{
			double num = ItemReport.LauncherDamageMod(o);
			if (num <= 0.0)
			{
				num = 1.0;
			}
			num2 = (arrow + (double)ItemReport.LauncherElemental(o)) * num;
		}
		else
		{
			double num3 = LootMatcher.Long(o, 218103842);
			double val = LootMatcher.Dbl(o, 167772171);
			if (_base.Count > 0 && !_zone && !ZoneLocked(o) && _base.TryGetValue(o.Id.ToString(Inv) + ":L" + 218103842.ToString(Inv), out var value) && value > 0.0)
			{
				num3 = value;
			}
			num2 = num3 * (1.0 - Math.Max(0.0, Math.Min(1.0, val)) / 2.0);
		}
		double num4 = ((c.TryGetValue("biting", out var value2) && value2.Value > 0.0) ? (value2.Value / 100.0) : 0.1);
		double num5 = ((c.TryGetValue("crush", out value2) && value2.Value > 0.0) ? value2.Value : 2.0);
		double num6 = 1.0 - num4 + num4 * num5;
		double pct = (c.TryGetValue("sar", out value2) ? value2.Value : 0.0);
		return num2 * (1.0 + MatchingRend(o, c) / 100.0) * num6 * SarFactor(pct, CurrentTier());
	}

	private static double ArrowAvg()
	{
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (ItemInfo.IsAmmo(item) && IsEquipped(item))
				{
					double num = LootMatcher.Long(item, 218103842);
					double val = LootMatcher.Dbl(item, 167772171);
					if (num > 0.0)
					{
						return num * (1.0 - Math.Max(0.0, Math.Min(1.0, val)) / 2.0);
					}
				}
			}
		}
		catch
		{
		}
		return 40.0;
	}

	private static void OtherEstimate(WorldObject o, WorldObject eq, Dictionary<string, Card> me, Dictionary<string, Card> them, out double overall, out double bestSlayer, out string best)
	{
		double arrow = ((o.ObjectClass == ObjectClass.MissileWeapon) ? ArrowAvg() : 0.0);
		double num = HitValue(o, me, arrow);
		double num2 = HitValue(eq, them, arrow);
		overall = ((num2 > 0.0 && num > 0.0) ? (num / num2 - 1.0) : 0.0);
		SlayerBest(me, them, num, num2, out bestSlayer, out best);
	}

	private static void SlayerBest(Dictionary<string, Card> me, Dictionary<string, Card> them, double a, double b, out double bestSlayer, out string best)
	{
		bestSlayer = double.MinValue;
		best = "";
		List<string> list = new List<string>();
		foreach (string key in me.Keys)
		{
			if (key.StartsWith("slayer:"))
			{
				list.Add(key.Substring(7));
			}
		}
		foreach (string key2 in them.Keys)
		{
			if (key2.StartsWith("slayer:") && !list.Contains(key2.Substring(7)))
			{
				list.Add(key2.Substring(7));
			}
		}
		foreach (string item in list)
		{
			if (b <= 0.0)
			{
				break;
			}
			double num = a * Slayer(me, item) / (b * Slayer(them, item)) - 1.0;
			if (num > bestSlayer)
			{
				bestSlayer = num;
				best = item;
			}
		}
	}

	private static string BestSpecies(Dictionary<string, Card> me, Dictionary<string, Card> them, WorldObject o, WorldObject eq, double bestSlayer)
	{
		if (bestSlayer == double.MinValue)
		{
			return "";
		}
		SlayerBest(me, them, 1.0, 1.0, out var _, out var best);
		return best;
	}

	// "Best slayer": against the slayer of that kind on the item list. "With Slayer": none listed - against the
	// compare weapon (what it would do with its slayer on, against yours without)
	private static string ScoreText(double overall, double bestSlayer, string best, string listedName = null)
	{
		bool listed = !string.IsNullOrEmpty(listedName);
		return "Score: damage " + Signed(overall * 100.0, "%", "0") + " overall" + ((bestSlayer > double.MinValue) ? (" | " + (listed ? "Best slayer " : "With Slayer ") + Signed(bestSlayer * 100.0, "%", "0") + ((best.Length > 0) ? (" (" + best + (listed ? " - vs " + listedName : "") + ")") : "")) : "");
	}

	/// <summary>The candidate against the item list's own slayer of this kind (same sort of weapon), with that slayer on
	/// both: how much better or worse (NaN: no such slayer listed).</summary>
	private static double VsListedSlayer(WorldObject o, WorldObject eq, Dictionary<string, Card> me, string species, bool caster, out string name)
	{
		name = null;
		if (string.IsNullOrEmpty(species) || ListedIds == null)
		{
			return double.NaN;
		}
		int group = Group(o);
		foreach (int id in ListedIds())
		{
			if (id == o.Id || (eq != null && id == eq.Id))
			{
				continue;
			}
			WorldObject w = Globals.Core.WorldFilter[id];
			if (w == null || Group(w) != group || w.ObjectClass != o.ObjectClass)
			{
				continue;
			}
			Dictionary<string, Card> wc = Cards(w);
			if (!wc.ContainsKey("slayer:" + species))
			{
				continue;
			}
			double a, b;
			if (caster)
			{
				int tier = CurrentTier();
				a = CasterValue(o, me, tier);
				b = CasterValue(w, wc, tier);
			}
			else
			{
				double arrow = ((o.ObjectClass == ObjectClass.MissileWeapon) ? ArrowAvg() : 0.0);
				a = HitValue(o, me, arrow);
				b = HitValue(w, wc, arrow);
			}
			if (a <= 0.0 || b <= 0.0)
			{
				continue;
			}
			name = ItemLabels.Label(w);   // (with its material: "Gold Nether Staff", not "Nether Staff")
			return a * Slayer(me, species) / (b * Slayer(wc, species)) - 1.0;
		}
		return double.NaN;
	}

	private static double CasterValue(WorldObject w, Dictionary<string, Card> cards, int tier)
	{
		double d = LootMatcher.Dbl(w, 152);
		if (d <= 0.0)
		{
			d = 1.0;
		}
		double sar = (cards.TryGetValue("sar", out var v) ? v.Value : 0.0);
		return d * (1.0 + MatchingRend(w, cards) / 100.0) * SarFactor(sar, tier);
	}

	private static string CasterEstimate(WorldObject o, WorldObject eq, Dictionary<string, Card> me, Dictionary<string, Card> them, out double overall, out double bestSlayer)
	{
		overall = 0.0;
		bestSlayer = double.MinValue;
		double num = LootMatcher.Dbl(o, 152);
		double value = 0.0;
		bool flag = !_zone && _base.TryGetValue(Key(eq.Id, 152), out value);
		if (!flag)
		{
			value = LootMatcher.Dbl(eq, 152);
		}
		if (num <= 0.0)
		{
			num = 1.0;
		}
		if (value <= 0.0)
		{
			value = 1.0;
		}
		int tier = CurrentTier();
		double num2 = (me.TryGetValue("sar", out var value2) ? value2.Value : 0.0);
		double num3 = (them.TryGetValue("sar", out var value3) ? value3.Value : 0.0);
		double num4 = num * (1.0 + MatchingRend(o, me) / 100.0) * SarFactor(num2, tier);
		double num5 = value * (1.0 + MatchingRend(eq, them) / 100.0) * SarFactor(num3, tier);
		overall = num4 / num5 - 1.0;
		string text = "~" + Signed(overall * 100.0, "%", "0") + " damage" + ((flag || (_zone && !IsEquipped(eq))) ? "" : " (yours buffed)");
		List<string> list = new List<string>();
		foreach (string key in me.Keys)
		{
			if (key.StartsWith("slayer:"))
			{
				list.Add(key.Substring(7));
			}
		}
		foreach (string key2 in them.Keys)
		{
			if (key2.StartsWith("slayer:") && !list.Contains(key2.Substring(7)))
			{
				list.Add(key2.Substring(7));
			}
		}
		List<string> list2 = new List<string>();
		foreach (string item in list)
		{
			double num6 = num4 * Slayer(me, item) / (num5 * Slayer(them, item)) - 1.0;
			if (num6 > bestSlayer)
			{
				bestSlayer = num6;
			}
			list2.Add(Signed(num6 * 100.0, "%", "0") + " on " + item);
		}
		if (list2.Count > 0)
		{
			text = text + " (" + string.Join(", ", list2.ToArray()) + ")";
		}
		if (num2 > 0.0 || num3 > 0.0)
		{
			text = text + " [T" + tier + "]";
		}
		return text;
	}

	public static bool Estimate(WorldObject o, out double overall, out double bestSlayer)
	{
		overall = 0.0;
		bestSlayer = double.MinValue;
		if (o == null || !IsWeapon(o) || ItemInfo.IsAmmo(o))
		{
			return false;
		}
		if (LooksBuffed(o) != null)
		{
			return false;
		}
		WorldObject worldObject = EquippedCounterpart(o);
		if (worldObject == null)
		{
			return false;
		}
		Load();
		if (ZoneMissing(o, worldObject) != null)
		{
			return false;
		}
		return EstimateWith(o, worldObject, out overall, out bestSlayer);
	}

	private static bool EstimateWith(WorldObject o, WorldObject eq, out double overall, out double bestSlayer)
	{
		overall = 0.0;
		bestSlayer = double.MinValue;
		if (o.ObjectClass == ObjectClass.WandStaffOrb)
		{
			CasterEstimate(o, eq, Cards(o), Cards(eq), out overall, out bestSlayer);
		}
		else
		{
			OtherEstimate(o, eq, Cards(o), Cards(eq), out overall, out bestSlayer, out var _);
		}
		if (bestSlayer == double.MinValue)
		{
			bestSlayer = -1.0;
		}
		return true;
	}

	public static string LooksBuffed(WorldObject o)
	{
		if (o == null || !IsWeapon(o) || IsEquipped(o) || ItemInfo.IsAmmo(o) || !o.HasIdData)
		{
			return null;
		}
		if (GearSnap.HasClean(o.Id))
		{
			return null;
		}
		string text = BuffedReason(o);
		if (text != null)
		{
			Refresh(o.Id);
		}
		return text;
	}

	public static string BuffedReason(WorldObject o)
	{
		if (o == null || !IsWeapon(o) || !o.HasIdData)
		{
			return null;
		}
		string text = null;
		try
		{
			int activeSpellCount = o.ActiveSpellCount;
			if (activeSpellCount > 0)
			{
				text = activeSpellCount + " spell" + ((activeSpellCount == 1) ? "" : "s") + " active on it";
			}
		}
		catch
		{
		}
		double num = LootMatcher.LiveDbl(o, 29);
		double num2 = LootMatcher.LiveDbl(o, 152);
		double num3 = LootMatcher.LiveDbl(o, 144);
		if (text == null && num > 1.601 && !ZoneLocked(o))
		{
			text = ((num - 1.0) * 100.0).ToString("0", Inv) + "% md";
		}
		if (text == null && num2 > 6.0)
		{
			text = "+" + ((num2 - 1.0) * 100.0).ToString("0", Inv) + "% vs. Monsters";
		}
		if (text == null && num3 > 2.0)
		{
			text = ((num3 - 1.0) * 100.0).ToString("0", Inv) + "% mc";
		}
		return text;
	}

	public static void Refresh(int id)
	{
		if (_refreshAt.TryGetValue(id, out var value) && (DateTime.Now - value).TotalSeconds < 3.0)
		{
			return;
		}
		_refreshAt[id] = DateTime.Now;
		if (_refreshAt.Count > 300)
		{
			_refreshAt.Clear();
		}
		try
		{
			Util.RequestId(id);
		}
		catch
		{
		}
	}

	public static bool ZoneLocked(WorldObject o)
	{
		return o != null && LootMatcher.LiveStr(o, 16).IndexOf("Zone Locked", StringComparison.OrdinalIgnoreCase) >= 0;
	}

	private static bool IsT11Item(WorldObject o)
	{
		return o != null && (LootMatcher.Str(o, 16) ?? "").IndexOf("Augmentations", StringComparison.OrdinalIgnoreCase) >= 0;
	}

	public static string Describe(WorldObject o, out int color, bool withScore)
	{
		string text = Describe(o, out color);
		if (!withScore && text != null && text.StartsWith("Score: "))
		{
			int num = text.IndexOf(" | vs ");
			if (num > 0)
			{
				text = text.Substring(num + 3);
			}
		}
		return text;
	}

	public static string Describe(WorldObject o, out int color)
	{
		color = 7;
		if (o == null || !IsWeapon(o))
		{
			return DescribeInner(o, out color);
		}
		WorldObject worldObject = EquippedCounterpart(o);
		string missing = (worldObject == null) ? null : ZoneMissing(o, worldObject);
		if (missing != null)
		{
			return missing;
		}
		string text = DescribeInner(o, out color);
		return (text != null && (ZoneLocked(o) || (worldObject != null && ZoneLocked(worldObject)))) ? ("[in-tier numbers] " + text) : text;
	}

	// tier 11+ items are always compared at their in-tier numbers (kept from an ID where they're at full power). Zone
	// locked here, one whose in-tier numbers aren't kept can't be compared yet: what's missing (null: nothing)
	private static string ZoneMissing(WorldObject o, WorldObject eq)
	{
		foreach (WorldObject w in new WorldObject[2] { o, eq })
		{
			if (w != null && ZoneLocked(w) && !GearSnap.HasTier(w.Id))
			{
				return "Not compared: " + ItemLabels.Label(w) + " is zone locked here and its tier 11+ numbers aren't saved yet - ID it once in a tier 11+ area.";
			}
		}
		return null;
	}

	private static string DescribeInner(WorldObject o, out int color)
	{
		color = 7;
		if (o != null && ArmorCompare.IsGear(o))
		{
			return ArmorCompare.Describe(o, out color);
		}
		string text = LooksBuffed(o);
		if (text != null)
		{
			return "Not compared yet: its numbers are buffed (" + text + ") - asking for a fresh ID with its real ones.";
		}
		WorldObject worldObject = EquippedCounterpart(o);
		if (worldObject == null)
		{
			return null;
		}
		int num = 0;
		int num2 = 0;
		bool flag = o.ObjectClass == ObjectClass.WandStaffOrb;
		bool flag2 = o.ObjectClass == ObjectClass.MissileWeapon;
		bool flag3 = o.ObjectClass == ObjectClass.MeleeWeapon;
		int num3 = 0;
		int num4 = 0;
		Load();
		List<string> list = new List<string>();
		double num5 = LootMatcher.Dbl(o, 152);
		if (num5 > 0.0 || o.ObjectClass == ObjectClass.WandStaffOrb)
		{
			double value = 0.0;
			string text2 = "+" + ((num5 - 1.0) * 100.0).ToString("0", Inv) + "%";
			bool flag4 = _zone || true;
			if (flag4)
			{
				value = LootMatcher.Dbl(worldObject, 152);
			}
			if ((flag4 && value > 0.0) || (!flag4 && _base.TryGetValue(Key(worldObject.Id, 152), out value)))
			{
				if (num5 > value + 1E-09)
				{
					num++;
					num3++;
				}
				else if (num5 < value - 1E-09)
				{
					num2++;
					num4++;
				}
				list.Add("Monsters " + text2 + " vs +" + ((value - 1.0) * 100.0).ToString("0", Inv) + "% (" + Signed((num5 - value) * 100.0, "%", "0") + ")");
			}
			else
			{
				list.Add("Monsters " + text2 + " vs ? (unequip and ID yours once so its unbuffed value is known)");
			}
		}
		for (int i = 0; i < DefenseProps.Length; i++)
		{
			int num6 = DefenseProps[i];
			double num7 = LootMatcher.Dbl(o, num6);
			double value2 = 0.0;
			bool flag5 = !_zone && _base.TryGetValue(Key(worldObject.Id, num6), out value2);
			if (!flag5)
			{
				value2 = LootMatcher.Dbl(worldObject, num6);
			}
			if (!(num7 <= 1.0) || !(value2 <= 1.0))
			{
				if (num7 <= 0.0)
				{
					num7 = 1.0;
				}
				if (value2 <= 0.0)
				{
					value2 = 1.0;
				}
				if (num7 > value2 + 1E-09)
				{
					num++;
				}
				else if (num7 < value2 - 1E-09)
				{
					num2++;
				}
				string[] array = new string[9]
				{
					DefenseNames[i],
					" ",
					Pc(num7),
					" vs ",
					Pc(value2),
					null,
					null,
					null,
					null
				};
				if (!flag5)
				{
				}
				array[5] = "";
				array[6] = " (";
				array[7] = Signed((num7 - value2) * 100.0, "%", "0.#");
				array[8] = ")";
				list.Add(string.Concat(array));
			}
		}
		if (Element(o) != Element(worldObject))
		{
			list.Add("Element " + ElemName(Element(o)) + " vs " + ElemName(Element(worldObject)));
		}
		if (flag3)
		{
			int num8 = LootMatcher.Long(o, 218103842);
			double value3 = 0.0;
			bool flag6 = !_zone && _base.TryGetValue(worldObject.Id.ToString(Inv) + ":L" + 218103842.ToString(Inv), out value3);
			if (!flag6)
			{
				value3 = LootMatcher.Long(worldObject, 218103842);
			}
			if (num8 > 0 || value3 > 0.0)
			{
				if ((double)num8 > value3)
				{
					num3++;
				}
				else if ((double)num8 < value3)
				{
					num4++;
				}
				string[] array2 = new string[8]
				{
					"Dmg ",
					num8.ToString(),
					" vs ",
					value3.ToString("0", Inv),
					null,
					null,
					null,
					null
				};
				if (!flag6)
				{
				}
				array2[4] = "";
				array2[5] = " (";
				array2[6] = Signed((double)num8 - value3, "", "0");
				array2[7] = ")";
				list.Add(string.Concat(array2));
			}
		}
		if (flag2 && !ItemInfo.IsAmmo(o))
		{
			int up = 0;
			int down = 0;
			Num(list, "Elemental Dmg", ItemReport.LauncherElemental(o), ItemReport.LauncherElemental(worldObject), mult: false, ref up, ref down);
			num3 += up;
			num4 += down;
			int up2 = 0;
			int down2 = 0;
			Num(list, "Damage Mod", ItemReport.LauncherDamageMod(o), ItemReport.LauncherDamageMod(worldObject), mult: true, ref up2, ref down2);
			num3 += up2;
			num4 += down2;
		}
		Dictionary<string, Card> dictionary = Cards(o);
		Dictionary<string, Card> dictionary2 = Cards(worldObject);
		double num9 = BestRend(dictionary);
		double num10 = BestRend(dictionary2);
		if (num9 > 0.0 || num10 > 0.0)
		{
			if (num9 > num10)
			{
				num++;
			}
			else if (num9 < num10)
			{
				num2++;
			}
		}
		if (flag)
		{
			double num11 = (dictionary.TryGetValue("rend:Void", out var value4) ? value4.Value : 0.0);
			double num12 = (dictionary2.TryGetValue("rend:Void", out var value5) ? value5.Value : 0.0);
			if (num11 > num12)
			{
				num3++;
			}
			else if (num11 < num12)
			{
				num4++;
			}
		}
		else if (num9 > 0.0 || num10 > 0.0)
		{
			if (num9 > num10)
			{
				num3++;
			}
			else if (num9 < num10)
			{
				num4++;
			}
		}
		num = num3;
		num2 = num4;
		if (num2 == 0 && num > 0)
		{
			color = 10;
		}
		else if (num2 > 0 && num > 0)
		{
			color = 8;
		}
		else if (num2 > 0)
		{
			color = 15;
		}
		string text3 = "";
		string text4 = "";
		double overall;
		double bestSlayer;
		string best;
		if (flag)
		{
			text3 = CasterEstimate(o, worldObject, dictionary, dictionary2, out overall, out bestSlayer);
			best = BestSpecies(dictionary, dictionary2, o, worldObject, bestSlayer);
		}
		else
		{
			OtherEstimate(o, worldObject, dictionary, dictionary2, out overall, out bestSlayer, out best);
		}
		string listedSlayer = null;
		double vsListed = VsListedSlayer(o, worldObject, dictionary, best, flag, out listedSlayer);
		if (!double.IsNaN(vsListed))
		{
			bestSlayer = vsListed;
		}
		text4 = ScoreText(overall, bestSlayer, best, listedSlayer);
		ref int reference = ref color;
		int num13;
		if (overall >= 0.02)
		{
			num13 = 10;
		}
		else if (listedSlayer != null)
		{
			// (against the slayer of that kind you keep: any real gain over it is the point - green, any loss red - the
			// same number the line shows)
			num13 = (bestSlayer > 0.005) ? 18 : ((bestSlayer < -0.005) ? 15 : 8);
		}
		else if (bestSlayer >= 0.05)
		{
			num13 = 18;
		}
		else
		{
			num13 = ((overall <= -0.02) ? 15 : 8);
		}
		reference = num13;
		if (dictionary.TryGetValue("grade", out var value6) | dictionary2.TryGetValue("grade", out var value7))
		{
			if (value6 != null && value7 != null)
			{
				list.Add("Grade " + value6.Text + " vs " + value7.Text + " (" + Signed(value6.Value - value7.Value, "%", "0") + ")");
			}
			else if (value6 != null)
			{
				list.Add("+ Grade " + value6.Text);
			}
			else
			{
				list.Add("- Grade " + value7.Text);
			}
		}
		List<string> list2 = new List<string>();
		foreach (string key in dictionary.Keys)
		{
			if (key != "grade" && !list2.Contains(key))
			{
				list2.Add(key);
			}
		}
		foreach (string key2 in dictionary2.Keys)
		{
			if (key2 != "grade" && !list2.Contains(key2))
			{
				list2.Add(key2);
			}
		}
		foreach (string item in list2)
		{
			bool flag7 = dictionary.TryGetValue(item, out value6);
			bool flag8 = dictionary2.TryGetValue(item, out value7);
			if (flag7 & flag8)
			{
				bool flag9 = item == "crush" || item.StartsWith("slayer:");
				list.Add(value6.Label + " " + value6.Text + " vs " + value7.Text + " (" + Signed(value6.Value - value7.Value, flag9 ? "x" : ((item == "cleave") ? "" : "%"), flag9 ? "0.00" : "0") + ")");
			}
			else if (flag7)
			{
				list.Add("+ " + value6.Label + " " + value6.Text);
			}
			else
			{
				list.Add("- " + value7.Label + " " + value7.Text);
			}
		}
		return text4 + " | " + (IsEquipped(worldObject) ? "vs equipped " : "vs ") + ItemLabels.Label(worldObject) + ": " + ((text3.Length > 0) ? (text3 + " | ") : "") + string.Join(", ", list.ToArray());
	}
}
