using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace MelkTank.Loot;

public class UtlProfile
{
	private class Reader
	{
		public string Text;

		public int Pos;

		public string Line()
		{
			if (Pos >= Text.Length)
			{
				throw new FormatException("Unexpected end of file");
			}
			int num = Text.IndexOf('\n', Pos);
			string text;
			if (num < 0)
			{
				text = Text.Substring(Pos);
				Pos = Text.Length;
			}
			else
			{
				text = Text.Substring(Pos, num - Pos);
				Pos = num + 1;
			}
			return text.EndsWith("\r") ? text.Substring(0, text.Length - 1) : text;
		}
	}

	public int Version;

	public string Nl = "\r\n";

	public List<UtlRule> Rules = new List<UtlRule>();

	public string Tail = "";

	public bool HadBom;

	public static UtlProfile Load(string path)
	{
		byte[] array = File.ReadAllBytes(path);
		bool flag = array.Length >= 3 && array[0] == 239 && array[1] == 187 && array[2] == 191;
		string text = new UTF8Encoding(encoderShouldEmitUTF8Identifier: false).GetString(array, flag ? 3 : 0, array.Length - (flag ? 3 : 0));
		UtlProfile utlProfile = Parse(text);
		utlProfile.HadBom = flag;
		return utlProfile;
	}

	public static UtlProfile Parse(string text)
	{
		UtlProfile utlProfile = new UtlProfile();
		utlProfile.Nl = (text.Contains("\r\n") ? "\r\n" : "\n");
		Reader reader = new Reader
		{
			Text = text
		};
		string text2 = reader.Line();
		int num;
		if (text2 == "UTL")
		{
			utlProfile.Version = int.Parse(reader.Line());
			num = int.Parse(reader.Line());
		}
		else
		{
			num = int.Parse(text2);
		}
		if (num < 0)
		{
			throw new FormatException("Not a VTank .utl profile (bad rule count)");
		}
		if (utlProfile.Version > 1)
		{
			throw new FormatException("Profile version " + utlProfile.Version + " - only version 1 is supported");
		}
		for (int i = 0; i < num; i++)
		{
			UtlRule utlRule = new UtlRule();
			utlRule.Name = reader.Line();
			utlRule.Expr = ((utlProfile.Version >= 1) ? reader.Line() : "");
			string[] array = reader.Line().Split(';');
			utlRule.Pri = array[0];
			utlRule.Act = ((array.Length > 1) ? array[1] : "0");
			utlRule.KeepN = ((utlRule.Act == "10") ? reader.Line() : null);
			for (int j = 2; j < array.Length; j++)
			{
				UtlReq utlReq = new UtlReq
				{
					Type = array[j]
				};
				if (utlProfile.Version >= 1)
				{
					utlReq.LenStr = reader.Line();
				}
				int pos = reader.Pos;
				UtlSpec.ReqType reqType = UtlSpec.Get(utlReq.Type);
				if (reqType != null)
				{
					utlReq.Vals = new List<string>();
					for (int k = 0; k < reqType.Fields.Length; k++)
					{
						utlReq.Vals.Add(reader.Line());
					}
				}
				else
				{
					if (utlReq.LenStr == null)
					{
						throw new FormatException("Unknown requirement type " + utlReq.Type + " in a version-0 profile");
					}
					reader.Pos += int.Parse(utlReq.LenStr);
				}
				utlReq.Raw = text.Substring(pos, reader.Pos - pos);
				utlRule.Reqs.Add(utlReq);
			}
			utlProfile.Rules.Add(utlRule);
		}
		utlProfile.Tail = text.Substring(reader.Pos);
		return utlProfile;
	}

	public string Serialize()
	{
		string value = Nl ?? "\r\n";
		bool flag = Version != 1;
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("UTL").Append(value).Append("1")
			.Append(value)
			.Append(Rules.Count)
			.Append(value);
		foreach (UtlRule rule in Rules)
		{
			stringBuilder.Append(rule.Name).Append(value).Append(rule.Expr ?? "")
				.Append(value);
			List<string> list = new List<string> { rule.Pri, rule.Act };
			foreach (UtlReq req in rule.Reqs)
			{
				list.Add(req.Type);
			}
			stringBuilder.Append(string.Join(";", list.ToArray())).Append(value);
			if (rule.Act == "10")
			{
				stringBuilder.Append(rule.KeepN ?? "1").Append(value);
			}
			foreach (UtlReq req2 in rule.Reqs)
			{
				if (!req2.Dirty && req2.LenStr != null && req2.Raw != null && !flag)
				{
					stringBuilder.Append(req2.LenStr).Append(value).Append(req2.Raw);
					continue;
				}
				if (req2.Vals == null)
				{
					stringBuilder.Append(req2.LenStr ?? req2.Raw.Length.ToString()).Append(value).Append(req2.Raw);
					continue;
				}
				StringBuilder stringBuilder2 = new StringBuilder();
				foreach (string val in req2.Vals)
				{
					stringBuilder2.Append(val).Append(value);
				}
				stringBuilder.Append(stringBuilder2.Length).Append(value).Append(stringBuilder2);
			}
		}
		stringBuilder.Append(Tail);
		return stringBuilder.ToString();
	}

	public UtlProfile Clone()
	{
		UtlProfile utlProfile = Parse(Serialize());
		utlProfile.HadBom = HadBom;
		return utlProfile;
	}

	public void Save(string path)
	{
		byte[] bytes = new UTF8Encoding(encoderShouldEmitUTF8Identifier: false).GetBytes(Serialize());
		using (FileStream fileStream = new FileStream(path, FileMode.Create, FileAccess.Write))
		{
			if (HadBom)
			{
				fileStream.Write(new byte[3] { 239, 187, 191 }, 0, 3);
			}
			fileStream.Write(bytes, 0, bytes.Length);
		}
		foreach (UtlRule rule in Rules)
		{
			foreach (UtlReq req in rule.Reqs)
			{
				req.Dirty = false;
			}
		}
		Version = 1;
	}
}
