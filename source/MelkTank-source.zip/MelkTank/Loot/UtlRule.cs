using System.Collections.Generic;

namespace MelkTank.Loot;

public class UtlRule
{
	public string Name = "New rule";

	public string Expr = "";

	public string Pri = "0";

	public string Act = "1";

	public string KeepN;

	public List<UtlReq> Reqs = new List<UtlReq>();

	public bool Off
	{
		get
		{
			foreach (UtlReq req in Reqs)
			{
				if (req.Type == "9999" && req.Vals != null && req.Vals.Count > 0 && req.Vals[0] == "true")
				{
					return true;
				}
			}
			return false;
		}
	}

	public bool KeepEach
	{
		get
		{
			foreach (UtlReq req in Reqs)
			{
				if (req.Type == "3005" && req.Vals != null && req.Vals.Count > 0 && req.Vals[0] == "true")
				{
					return true;
				}
			}
			return false;
		}
	}

	public bool IsSection => Name.TrimStart().StartsWith("*");

	public bool IsSpacer => Name.Trim().Length == 0 && Off;

	public void SetKeepEach(bool on)
	{
		UtlReq utlReq = Reqs.Find((UtlReq x) => x.Type == "3005");
		if (!on)
		{
			if (utlReq != null)
			{
				Reqs.Remove(utlReq);
			}
			return;
		}
		if (utlReq != null)
		{
			utlReq.Vals = new List<string> { "true" };
			utlReq.Dirty = true;
			return;
		}
		int num = Reqs.FindIndex((UtlReq x) => x.Type == "9999");
		if (num >= 0)
		{
			Reqs.Insert(num, UtlReq.New("3005", "true"));
		}
		else
		{
			Reqs.Add(UtlReq.New("3005", "true"));
		}
	}

	public void SetOff(bool off)
	{
		UtlReq utlReq = Reqs.Find((UtlReq x) => x.Type == "9999");
		if (!off)
		{
			if (utlReq != null)
			{
				Reqs.Remove(utlReq);
			}
		}
		else if (utlReq != null)
		{
			utlReq.Vals = new List<string> { "true" };
			utlReq.Dirty = true;
		}
		else
		{
			Reqs.Add(UtlReq.New("9999", "true"));
		}
	}

	public UtlRule Clone()
	{
		UtlRule utlRule = new UtlRule
		{
			Name = Name,
			Expr = Expr,
			Pri = Pri,
			Act = Act,
			KeepN = KeepN
		};
		foreach (UtlReq req in Reqs)
		{
			utlRule.Reqs.Add(new UtlReq
			{
				Type = req.Type,
				Vals = ((req.Vals == null) ? null : new List<string>(req.Vals)),
				LenStr = req.LenStr,
				Raw = req.Raw,
				Dirty = req.Dirty
			});
		}
		return utlRule;
	}
}
