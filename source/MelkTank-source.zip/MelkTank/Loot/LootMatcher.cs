using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;
using Decal.Adapter.Wrappers;

namespace MelkTank.Loot;

public static class LootMatcher
{
	public enum Verdict
	{
		No,
		Yes,
		NeedId
	}

	private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

	private static readonly Dictionary<string, Regex> _rx = new Dictionary<string, Regex>();

	public static readonly HashSet<string> Unsupported = new HashSet<string> { "14", "15", "16", "17", "2000", "2001", "2006", "2008" };

	private static readonly HashSet<int> NoIdLongs = new HashSet<int> { 19, 5, 218103814, 218103815, 218103808, 218103822, 218103821 };

	public const int RareIdKey = 17;

	public static Func<string, bool> RareFoundNamed = (string n) => false;

	private static readonly string[][] ElementWords = new string[8][]
	{
		new string[3] { "Nether", "Nether", "Void" },
		new string[2] { "Acid", "Acid" },
		new string[4] { "Fire", "Fire", "Flame", "Flaming" },
		new string[4] { "Cold", "Frost", "Cold", "Ice" },
		new string[4] { "Lightning", "Lightning", "Electric", "Shock" },
		new string[4] { "Slash", "Blade", "Slash", "Slashing" },
		new string[3] { "Pierce", "Pierce", "Piercing" },
		new string[4] { "Bludgeon", "Bludgeon", "Blunt", "Smash" }
	};

	private static readonly Regex RendEl = new Regex("^\\(\\?#T11 rend\\b[^)]*\\bel=(?<el>\\w+)", RegexOptions.IgnoreCase);

	public static UtlRule FirstMatch(UtlProfile p, WorldObject o)
	{
		if (p == null || o == null)
		{
			return null;
		}
		foreach (UtlRule rule in p.Rules)
		{
			if (rule.Off || !RuleMatches(rule, o))
			{
				continue;
			}
			return rule;
		}
		return null;
	}

	public static bool NeedsId(UtlReq q)
	{
		if (q.Vals == null)
		{
			return true;
		}
		if (Unsupported.Contains(q.Type))
		{
			return false;
		}
		switch (q.Type)
		{
		case "7":
		case "6":
		case "9999":
		case "3005":
		case "1000":
		case "1001":
		case "1002":
		case "1003":
		case "1004":
			return false;
		case "1":
			return I(V(q, 1)) != 1;
		case "3":
			if (I(V(q, 1)) == 17)
			{
				return false;
			}
			return !NoIdLongs.Contains(I(V(q, 1)));
		case "2":
		case "11":
		case "12":
		case "13":
			return !NoIdLongs.Contains(I(V(q, 1)));
		default:
			return true;
		}
	}

	public static Verdict RuleWithoutId(UtlRule r, WorldObject o)
	{
		bool flag = false;
		foreach (UtlReq req in r.Reqs)
		{
			if (UtlReq.Flag(req.Type))
			{
				continue;
			}
			if (OtherElement(req, o))
			{
				return Verdict.No;
			}
			if (NeedsId(req))
			{
				flag = true;
				continue;
			}
			bool flag2;
			try
			{
				flag2 = ReqMatches(req, o);
			}
			catch
			{
				flag2 = false;
			}
			if (flag2)
			{
				continue;
			}
			return Verdict.No;
		}
		return (!flag) ? Verdict.Yes : Verdict.NeedId;
	}

	public static bool DecideWithoutId(UtlProfile p, WorldObject o, out UtlRule rule)
	{
		rule = null;
		if (p == null || o == null)
		{
			return true;
		}
		foreach (UtlRule rule2 in p.Rules)
		{
			if (!rule2.Off)
			{
				switch (RuleWithoutId(rule2, o))
				{
				case Verdict.NeedId:
					return false;
				case Verdict.No:
					continue;
				}
				rule = rule2;
				return true;
			}
		}
		return true;
	}

	public static bool RuleMatches(UtlRule r, WorldObject o)
	{
		foreach (UtlReq req in r.Reqs)
		{
			if (!UtlReq.Flag(req.Type))
			{
				bool flag;
				try
				{
					flag = ReqMatches(req, o);
				}
				catch
				{
					flag = false;
				}
				if (!flag)
				{
					return false;
				}
			}
		}
		return true;
	}

	public static bool UsesUnsupported(UtlRule r)
	{
		foreach (UtlReq req in r.Reqs)
		{
			if (Unsupported.Contains(req.Type) || req.Vals == null)
			{
				return true;
			}
		}
		return false;
	}

	public static string NameElement(string name)
	{
		string text = null;
		string[][] elementWords = ElementWords;
		foreach (string[] array in elementWords)
		{
			for (int j = 1; j < array.Length; j++)
			{
				if (Regex.IsMatch(name ?? "", "\\b" + array[j] + "\\b", RegexOptions.IgnoreCase))
				{
					if (text != null && text != array[0])
					{
						return null;
					}
					text = array[0];
					break;
				}
			}
		}
		return text;
	}

	private static bool OtherElement(UtlReq q, WorldObject o)
	{
		if (q.Type != "1" || o == null)
		{
			return false;
		}
		Match match = RendEl.Match(V(q, 0));
		if (!match.Success)
		{
			return false;
		}
		string text = NameElement(o.Name);
		string text2 = match.Groups["el"].Value;
		if (text == null)
		{
			return false;
		}
		if (text2.Equals("Void", StringComparison.OrdinalIgnoreCase))
		{
			text2 = "Nether";
		}
		return !text.Equals(text2, StringComparison.OrdinalIgnoreCase);
	}

	private static string V(UtlReq q, int i)
	{
		return (q.Vals != null && i < q.Vals.Count) ? q.Vals[i] : "";
	}

	private static int I(string s)
	{
		int result;
		return int.TryParse(s.Trim(), NumberStyles.Integer, Inv, out result) ? result : 0;
	}

	private static double D(string s)
	{
		double result;
		return double.TryParse(s.Trim(), NumberStyles.Float, Inv, out result) ? result : 0.0;
	}

	public static Regex Rx(string pattern)
	{
		if (!_rx.TryGetValue(pattern ?? "", out var value))
		{
			value = new Regex(pattern ?? "", RegexOptions.None);
			_rx[pattern ?? ""] = value;
		}
		return value;
	}

	public static int LiveLong(WorldObject o, int key)
	{
		try
		{
			return o.Values((LongValueKey)key);
		}
		catch
		{
			return 0;
		}
	}

	public static double LiveDbl(WorldObject o, int key)
	{
		try
		{
			return o.Values((DoubleValueKey)key);
		}
		catch
		{
			return 0.0;
		}
	}

	public static string LiveStr(WorldObject o, int key)
	{
		try
		{
			return o.Values((StringValueKey)key) ?? "";
		}
		catch
		{
			return "";
		}
	}

	public static int Long(WorldObject o, int key)
	{
		int v;
		int r = GearSnap.TryLong(o, key, out v) ? v : LiveLong(o, key);
		// a wand's / staff's / orb's element isn't its weapon damage type (it has none) but its own (#45):
		// "Damage Type is Slash" on a caster goes by that
		if (r == 0 && key == 218103841)
		{
			r = GearSnap.TryLong(o, 45, out v) ? v : LiveLong(o, 45);
		}
		return r;
	}

	public static double Dbl(WorldObject o, int key)
	{
		double v;
		return GearSnap.TryDbl(o, key, out v) ? v : LiveDbl(o, key);
	}

	public static string Str(WorldObject o, int key)
	{
		string v;
		return GearSnap.TryStr(o, key, out v) ? v : LiveStr(o, key);
	}

	internal static bool ReqMatches(UtlReq q, WorldObject o)
	{
		if (q.Vals == null || Unsupported.Contains(q.Type))
		{
			return false;
		}
		switch (q.Type)
		{
		case "0":
		{
			Regex regex = Rx(V(q, 0));
			foreach (string item in SpellNames.Of(o))
			{
				if (regex.IsMatch(item))
				{
					return true;
				}
			}
			string text = LootFields.CloakProc(o);
			if (text == null)
			{
				return false;
			}
			if (regex.IsMatch(text))
			{
				return true;
			}
			string text2 = LootFields.NewProcFor(V(q, 0));
			return text2 != null && Rx(text2).IsMatch(text);
		}
		case "1":
			return Rx(V(q, 0)).IsMatch(Str(o, I(V(q, 1))));
		case "2":
			return Long(o, I(V(q, 1))) <= I(V(q, 0));
		case "3":
			if (I(V(q, 1)) == 17 && !o.HasIdData)
			{
				return (RareFoundNamed(o.Name) ? 1 : 0) >= I(V(q, 0));
			}
			return Long(o, I(V(q, 1))) >= I(V(q, 0));
		case "4":
			return Dbl(o, I(V(q, 1))) <= D(V(q, 0));
		case "5":
			return Dbl(o, I(V(q, 1))) >= D(V(q, 0));
		case "6":
			return false;
		case "7":
			return o.ObjectClass == (ObjectClass)I(V(q, 0));
		case "8":
			return SpellNames.Of(o).Count >= I(V(q, 0));
		case "9":
		{
			Regex regex2 = Rx(V(q, 0));
			Regex regex3 = ((V(q, 1).Length > 0) ? Rx(V(q, 1)) : null);
			int num6 = 0;
			foreach (string item2 in SpellNames.Of(o))
			{
				if (regex2.IsMatch(item2) && (regex3 == null || !regex3.IsMatch(item2)))
				{
					num6++;
				}
			}
			return num6 >= I(V(q, 2));
		}
		case "10":
		{
			double num4 = Long(o, 218103842);
			double num5 = Dbl(o, 167772171);
			return num4 * (1.0 - num5) >= D(V(q, 0));
		}
		case "11":
		{
			int num3 = I(V(q, 0));
			return (Long(o, I(V(q, 1))) & num3) != 0;
		}
		case "12":
			if (I(V(q, 1)) == 352 && I(V(q, 0)) == 2 && LootFields.CloakProc(o) == "Artful Dodger")
			{
				return true;
			}
			return Long(o, I(V(q, 1))) == I(V(q, 0));
		case "13":
			return Long(o, I(V(q, 1))) != I(V(q, 0));
		case "1000":
			return Character.EffectiveSkill(I(V(q, 1))) >= I(V(q, 0));
		case "1001":
			return Character.MainPackFreeSlots() >= I(V(q, 0));
		case "1002":
			return Character.Level() >= I(V(q, 0));
		case "1003":
			return Character.Level() <= I(V(q, 0));
		case "1004":
		{
			int num7 = Character.BaseSkill(I(V(q, 0)));
			return num7 >= I(V(q, 1)) && num7 <= I(V(q, 2));
		}
		case "2003":
			return (double)Long(o, I(V(q, 1))) >= D(V(q, 0));
		case "2005":
			return Dbl(o, I(V(q, 1))) >= D(V(q, 0));
		case "3003":
		case "3004":
		{
			if (!ArmorCompare.Estimate(o, out var pct, out var diff))
			{
				return false;
			}
			return ((q.Type == "3003") ? diff : pct) >= D(V(q, 0));
		}
		case "3001":
		case "3002":
		{
			if (!ItemCompare.Estimate(o, out var overall, out var bestSlayer))
			{
				return false;
			}
			double num2 = ((q.Type == "3001") ? overall : bestSlayer) * 100.0;
			return !double.IsInfinity(num2) && num2 != double.NegativeInfinity && num2 >= D(V(q, 0));
		}
		case "2007":
		{
			int num = 0;
			int[] array = new int[8] { 370, 371, 372, 373, 374, 375, 376, 379 };
			foreach (int key in array)
			{
				num += Long(o, key);
			}
			return (double)num >= D(V(q, 0));
		}
		default:
			return false;
		}
	}
}
