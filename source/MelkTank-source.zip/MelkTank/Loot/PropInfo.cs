namespace MelkTank.Loot;

public class PropInfo
{
	public int Id;

	public string Label;

	public string Group;

	public string Note;

	public string Tag;

	public bool Pick;

	public int Sent;
}
