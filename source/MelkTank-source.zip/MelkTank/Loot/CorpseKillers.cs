using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Decal.Adapter;
using Decal.Adapter.Wrappers;

namespace MelkTank.Loot;

public static class CorpseKillers
{
	private static readonly Regex KilledBy = new Regex("Killed by (?<who>.+?)\\.?\\s*$", RegexOptions.IgnoreCase | RegexOptions.Multiline);

	private static readonly Dictionary<int, string> _killer = new Dictionary<int, string>();

	private static readonly Dictionary<int, int> _asks = new Dictionary<int, int>();

	private static readonly Dictionary<int, DateTime> _askedAt = new Dictionary<int, DateTime>();

	private static DateTime _next = DateTime.MinValue;

	private const int MaxAsks = 3;

	private static readonly HashSet<string> _fellows = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

	private static int _leaderSeen;

	private static int _lockedSeen;

	private static int _openSeen;

	private static readonly Dictionary<string, int> _nameDepth = new Dictionary<string, int>();

	public static IEnumerable<string> Fellows => _fellows;

	public static int FellowCount => _fellows.Count;

	public static bool InFellow { get; private set; }

	public static int LeaderId { get; private set; }

	public static bool? Locked { get; private set; }

	public static bool? Open { get; private set; }

	private static string Me
	{
		get
		{
			try
			{
				return Globals.Core.CharacterFilter.Name ?? "";
			}
			catch
			{
				return "";
			}
		}
	}

	public static void ClearFellow()
	{
		_fellows.Clear();
		InFellow = false;
		LeaderId = 0;
		Locked = null;
		Open = null;
	}

	public static void Tick()
	{
		if (DateTime.Now < _next)
		{
			return;
		}
		_next = DateTime.Now.AddMilliseconds(300.0);
		try
		{
			WorldObject worldObject = null;
			double num = double.MaxValue;
			foreach (WorldObject item in Globals.Core.WorldFilter.GetLandscape())
			{
				if (item.ObjectClass != ObjectClass.Corpse || _killer.ContainsKey(item.Id))
				{
					continue;
				}
				_asks.TryGetValue(item.Id, out var value);
				if (value < 3 && (!_askedAt.TryGetValue(item.Id, out var value2) || !((DateTime.Now - value2).TotalSeconds < 2.0)))
				{
					double num2 = CombatEngine.Distance(item);
					if (num2 < 0.0)
					{
						num2 = 9999.0;
					}
					if (num2 < num)
					{
						worldObject = item;
						num = num2;
					}
				}
			}
			if (worldObject != null)
			{
				_asks.TryGetValue(worldObject.Id, out var value3);
				_asks[worldObject.Id] = value3 + 1;
				_askedAt[worldObject.Id] = DateTime.Now;
				Util.RequestId(worldObject.Id);
			}
		}
		catch
		{
		}
	}

	public static bool OnIdentified(int id)
	{
		try
		{
			WorldObject worldObject = Globals.Core.WorldFilter[id];
			if (worldObject == null || worldObject.ObjectClass != ObjectClass.Corpse)
			{
				return false;
			}
			string input = "";
			try
			{
				input = worldObject.Values(StringValueKey.FullDescription) ?? "";
			}
			catch
			{
			}
			Match match = KilledBy.Match(input);
			_killer[id] = (match.Success ? match.Groups["who"].Value.Trim() : "");
			return true;
		}
		catch
		{
			return false;
		}
	}

	public static void OnReleased(int id)
	{
		_killer.Remove(id);
		_asks.Remove(id);
		_askedAt.Remove(id);
	}

	public static string Killer(int id)
	{
		if (_killer.TryGetValue(id, out var value))
		{
			return value;
		}
		_asks.TryGetValue(id, out var value2);
		if (value2 >= 3 && (!_askedAt.TryGetValue(id, out var value3) || (DateTime.Now - value3).TotalSeconds >= 2.0))
		{
			return "";
		}
		return null;
	}

	private static bool IsOrOwns(string killer, string who)
	{
		if (string.IsNullOrEmpty(killer) || string.IsNullOrEmpty(who))
		{
			return false;
		}
		return string.Equals(killer, who, StringComparison.OrdinalIgnoreCase) || killer.StartsWith(who + "'s ", StringComparison.OrdinalIgnoreCase);
	}

	public static bool IsMine(string killer)
	{
		return IsOrOwns(killer, Me);
	}

	public static bool IsFellow(string killer)
	{
		foreach (string fellow in _fellows)
		{
			if (IsOrOwns(killer, fellow))
			{
				return true;
			}
		}
		return false;
	}

	public static bool Allowed(WorldObject o, bool fellowsToo, out bool pending)
	{
		pending = false;
		if (o == null)
		{
			return false;
		}
		if (string.Equals(o.Name, "Corpse of " + Me, StringComparison.OrdinalIgnoreCase))
		{
			return true;
		}
		string text = Killer(o.Id);
		if (text == null)
		{
			pending = true;
			return false;
		}
		if (text.Length == 0)
		{
			return true;
		}
		return IsMine(text) || (fellowsToo && IsFellow(text));
	}

	public static void OnServerMessage(Message m)
	{
		if (m == null || m.Type != 63408)
		{
			return;
		}
		int num;
		try
		{
			num = m.Value<int>("event");
		}
		catch
		{
			return;
		}
		switch (num)
		{
		case 702:
		{
			List<string> list2 = new List<string>();
			_nameDepth.Clear();
			_leaderSeen = 0;
			_lockedSeen = -1;
			_openSeen = -1;
			Walk(m, list2, 0);
			if (_leaderSeen != 0)
			{
				LeaderId = _leaderSeen;
			}
			if (_lockedSeen >= 0)
			{
				Locked = _lockedSeen != 0;
			}
			if (_openSeen >= 0)
			{
				Open = _openSeen != 0;
			}
			DropFellowshipName(list2);
			InFellow = true;
			_fellows.Clear();
			{
				foreach (string item in list2)
				{
					if (!string.Equals(item, Me, StringComparison.OrdinalIgnoreCase))
					{
						_fellows.Add(item);
					}
				}
				break;
			}
		}
		case 704:
		{
			InFellow = true;
			List<string> list = new List<string>();
			Walk(m, list, 0);
			{
				foreach (string item2 in list)
				{
					if (!string.Equals(item2, Me, StringComparison.OrdinalIgnoreCase))
					{
						_fellows.Add(item2);
					}
				}
				break;
			}
		}
		case 703:
			_fellows.Clear();
			InFellow = false;
			LeaderId = 0;
			Locked = null;
			Open = null;
			break;
		default:
			if (num != 164)
			{
				break;
			}
			goto case 163;
		case 163:
		{
			int num2 = 0;
			try
			{
				num2 = m.Value<int>(m.Count - 1);
			}
			catch
			{
			}
			int num3 = 0;
			try
			{
				num3 = Globals.Core.CharacterFilter.Id;
			}
			catch
			{
			}
			if (num2 != 0 && num2 == num3)
			{
				_fellows.Clear();
				InFellow = false;
				LeaderId = 0;
				Locked = null;
				Open = null;
			}
			else
			{
				if (num2 == 0)
				{
					break;
				}
				try
				{
					WorldObject worldObject = Globals.Core.WorldFilter[num2];
					if (worldObject != null)
					{
						_fellows.Remove(worldObject.Name);
					}
					break;
				}
				catch
				{
					break;
				}
			}
			break;
		}
		}
	}

	private static void Walk(Message m, List<string> names, int depth)
	{
		for (int i = 0; i < m.Count; i++)
		{
			object v = null;
			string n = null;
			try
			{
				v = m[i];
			}
			catch
			{
			}
			try
			{
				n = m.Name(i);
			}
			catch
			{
			}
			Visit(v, n, names, depth);
		}
	}

	private static void Walk(MessageStruct s, List<string> names, int depth)
	{
		if (s == null || depth > 8)
		{
			return;
		}
		for (int i = 0; i < s.Count; i++)
		{
			object v = null;
			string n = null;
			try
			{
				v = s[i];
			}
			catch
			{
			}
			try
			{
				n = s.Name(i);
			}
			catch
			{
			}
			Visit(v, n, names, depth);
		}
	}

	private static void DropFellowshipName(List<string> names)
	{
		if (names.Count < 2)
		{
			return;
		}
		int min = int.MaxValue;
		int num = int.MinValue;
		foreach (string name in names)
		{
			if (_nameDepth.TryGetValue(name, out var value))
			{
				min = Math.Min(min, value);
				num = Math.Max(num, value);
			}
		}
		if (min != num)
		{
			names.RemoveAll((string x) => _nameDepth.TryGetValue(x, out var value2) && value2 == min);
		}
	}

	private static void Visit(object v, string n, List<string> names, int depth)
	{
		if (v is MessageStruct)
		{
			Walk((MessageStruct)v, names, depth + 1);
			return;
		}
		if (n != null && (v is int || v is uint || v is bool || v is byte))
		{
			int num;
			if (v is int)
			{
				num = (int)v;
			}
			else if (v is uint)
			{
				num = (int)(uint)v;
			}
			else
			{
				num = ((!(v is bool)) ? ((byte)v) : (((bool)v) ? 1 : 0));
			}
			string text = n.ToLowerInvariant();
			if (text == "leader")
			{
				_leaderSeen = num;
			}
			else if (text.Contains("locked"))
			{
				_lockedSeen = num;
			}
			else if (text.Contains("open"))
			{
				_openSeen = num;
			}
		}
		if (v is string { Length: >0 } text2 && n != null && n.IndexOf("name", StringComparison.OrdinalIgnoreCase) >= 0 && !names.Contains(text2))
		{
			names.Add(text2);
			_nameDepth[text2] = depth;
		}
	}
}
