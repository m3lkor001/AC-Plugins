namespace MelkTank.Loot;

public class FieldDef
{
	public string Group;

	public string Label;

	public string Kind;

	public string Vk;

	public string Tag;

	public string Hint;

	public string Type;

	public string T11Id;

	public string Tip;

	public int? Key;

	public int? ModK;

	public string[] Ops;

	public bool IsAny;
}
