using System;
using System.Numerics;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public static class GiveWindow
{
	private static Hud _hud;

	private static int _target;

	private static int _count;

	private static int _delay = 500;

	private static string _targetName = "";

	private static string _item = "";

	private static string _note = "";

	private static Settings _s;

	private static bool _resetPos;

	public static bool Visible => _hud != null && _hud.Visible;

	public static void Init(Settings s)
	{
		_s = s;
		try
		{
			if (_hud == null)
			{
				_hud = UBService.Huds.CreateHud("MelkTank Give", BarIcon.Make("Give"));
				_hud.WindowSettings = ImGuiWindowFlags.NoCollapse | ImGuiWindowFlags.AlwaysAutoResize;
				_hud.OnPreRender += OnPreRender;
				_hud.OnRender += OnRender;
				_hud.Visible = false;
			}
			_hud.ShowInBar = s?.GiverInBar ?? true;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void SetInBar(bool on)
	{
		try
		{
			if (_hud != null)
			{
				_hud.ShowInBar = on;
			}
		}
		catch
		{
		}
	}

	public static void ResetPosition()
	{
		_resetPos = true;
		Show(on: true);
	}

	public static void Toggle()
	{
		Show(!Visible);
	}

	public static void Show(bool on)
	{
		try
		{
			if (_hud == null)
			{
				Init(_s);
			}
			if (_hud != null)
			{
				_hud.Visible = on;
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void OnPreRender(object sender, EventArgs e)
	{
		if (!_resetPos)
		{
			return;
		}
		_resetPos = false;
		if (WinMem.Has("Give"))
		{
			return;   // (this character's own place for it, put back by WinMem)
		}
		try
		{
			Vector2 displaySize = ImGui.GetIO().DisplaySize;
			ImGui.SetNextWindowPos(new Vector2(displaySize.X / 2f - 150f, displaySize.Y / 3f), ImGuiCond.Always);
		}
		catch
		{
		}
	}

	public static void Dispose()
	{
		try
		{
			UbCmd.StopGive();
		}
		catch
		{
		}
		try
		{
			if (_hud != null)
			{
				_hud.OnPreRender -= OnPreRender;
				_hud.OnRender -= OnRender;
				_hud.Dispose();
			}
		}
		catch
		{
		}
		_hud = null;
	}

	private static WorldObject Selected()
	{
		try
		{
			return CoreManager.Current.WorldFilter[CoreManager.Current.Actions.CurrentSelection];
		}
		catch
		{
			return null;
		}
	}

	private static long Carried(string name)
	{
		long num = 0L;
		try
		{
			foreach (WorldObject item in CoreManager.Current.WorldFilter.GetInventory())
			{
				if (item != null && ItemNames.Is(item, name) && item.Values(LongValueKey.EquippedSlots, 0) == 0)
				{
					num += Math.Max(1, item.Values(LongValueKey.StackCount, 1));
				}
			}
		}
		catch
		{
		}
		return num;
	}

	private static void OnRender(object sender, EventArgs e)
	{
		try
		{
			WinMem.Frame("Give", size: false);
			Vector4 col = new Vector4(0.6f, 0.6f, 0.6f, 1f);
			if (ImGui.Button("Target##gvt", new Vector2(60f, 0f)))
			{
				WorldObject worldObject = Selected();
				if (worldObject == null || (worldObject.ObjectClass != ObjectClass.Player && worldObject.ObjectClass != ObjectClass.Npc && worldObject.ObjectClass != ObjectClass.Vendor))
				{
					_note = "Select a player or NPC first.";
				}
				else
				{
					_target = worldObject.Id;
					_targetName = worldObject.Name;
					_note = "";
				}
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Who gets the items: select them, then click.");
			}
			ImGui.SameLine();
			if (_target != 0 && CoreManager.Current.WorldFilter[_target] != null)
			{
				ImGui.TextUnformatted(_targetName);
			}
			else
			{
				Im.TextColored(col, (_target != 0) ? (_targetName + " (not around)") : "nobody yet");
			}
			if (ImGui.Button("Item##gvi", new Vector2(60f, 0f)))
			{
				WorldObject worldObject2 = Selected();
				if (worldObject2 == null || Carried(ItemNames.Of(worldObject2)) == 0)
				{
					_note = "Select an item in your pack first.";
				}
				else
				{
					_item = ItemNames.Of(worldObject2);
					_note = "";
				}
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("What to give: select one in your pack, then click - every stack with that name goes.");
			}
			ImGui.SameLine();
			if (_item.Length > 0)
			{
				ImGui.TextUnformatted(_item + "  (" + Carried(_item).ToString("N0") + " carried)");
			}
			else
			{
				Im.TextColored(col, "nothing yet");
			}
			ImGui.SetNextItemWidth(100f);
			if (ImGui.InputInt("How many (0 = all)##gvn", ref _count))
			{
				_count = Math.Max(0, _count);
			}
			ImGui.SetNextItemWidth(100f);
			if (ImGui.InputInt("Delay (ms)##gvd", ref _delay, 100))
			{
				_delay = Math.Max(0, Math.Min(60000, _delay));
			}
			if (ImGui.IsItemHovered())
			{
				Im.SetTooltip("Wait this long between one hand-over and the next.");
			}
			if (UbCmd.Giving)
			{
				if (ImGui.Button("Stop##gvs", new Vector2(80f, 0f)))
				{
					UbCmd.StopGive();
					_note = "Stopped.";
				}
				ImGui.SameLine();
				Im.TextColored(col, UbCmd.GiveProgress);
			}
			else
			{
				bool flag = _target != 0 && _item.Length > 0;
				if (!flag)
				{
					ImGui.BeginDisabled();
				}
				if (ImGui.Button("Give##gvg", new Vector2(80f, 0f)) & flag)
				{
					_note = UbCmd.StartGive(_target, _item, _count, _delay);
				}
				if (!flag)
				{
					ImGui.EndDisabled();
				}
			}
			if (_note.Length > 0)
			{
				Im.TextColored(col, _note);
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}
}
