using System;
using System.Globalization;
using System.IO;
using System.Numerics;
#if !RETAIL
using ACGodot.DecalShim;
#endif
using ImGuiNET;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public class DayNightHud : IDisposable
{
	private readonly Hud _hud;

	private readonly Settings _s;

	private readonly Action _saveAll;

	private bool _shown;

	private const double HourLength = 476.25;

	private const double DayLength = 7620.0;

	private const double YearLength = 2743200.0;

	private bool _restored;

	private float[] _lastPos;

	private DateTime _dirtySince = DateTime.MinValue;

#if RETAIL
	public unsafe static double GameTicks
	{
		get
		{
			try
			{
				return *(double*)8616360 - 210.0 + 3810.0 + 27432000.0;
			}
			catch
			{
				return double.NaN;
			}
		}
	}
#else
	public static double GameTicks
	{
		get
		{
			double serverClock = Bridge.ServerClock;
			return (serverClock > 0.0) ? (serverClock - 210.0 + 3810.0 + 27432000.0) : double.NaN;
		}
	}
#endif

	private static string PosFile => Util.FullPath("MelkTank_DayNight.txt");

	public DayNightHud(Settings s, Action saveAll)
	{
		_s = s;
		_saveAll = saveAll;
		_hud = UBService.Huds.CreateHud("MelkTank Day/Night", BarIcon.Make("Time"));
		_hud.ShowInBar = false;
		_hud.WindowSettings = ImGuiWindowFlags.NoTitleBar | ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoCollapse | ImGuiWindowFlags.AlwaysAutoResize | ImGuiWindowFlags.NoBackground;
		_hud.OnPreRender += OnPreRender;
		_hud.OnRender += OnRender;
		_hud.Visible = s.DayNightHudOn;
		_shown = s.DayNightHudOn;
	}

	public void Sync()
	{
		if (_s.DayNightHudOn == _shown)
		{
			return;
		}
		_shown = _s.DayNightHudOn;
		try
		{
			_hud.Visible = _shown;
		}
		catch
		{
		}
	}

	public void Dispose()
	{
		try
		{
			_hud.OnPreRender -= OnPreRender;
			_hud.OnRender -= OnRender;
			_hud.Dispose();
		}
		catch
		{
		}
	}

	public static bool IsDay(double t)
	{
		int num = (int)Math.Floor(t % 7620.0 / 476.25);
		return num >= 4 && num < 12;
	}

	public static double SecondsToChange(double t)
	{
		double num = t % 7620.0;
		if (IsDay(t))
		{
			return 5715.0 - num;
		}
		double num2 = 1905.0;
		return (num < num2) ? (num2 - num) : (7620.0 - num + num2);
	}

	private void OnPreRender(object sender, EventArgs e)
	{
		if (_restored)
		{
			return;
		}
		_restored = true;
		try
		{
			if (!File.Exists(PosFile))
			{
				ImGui.SetNextWindowPos(new Vector2(415f, 5f), ImGuiCond.Always);
				return;
			}
			string[] array = File.ReadAllText(PosFile).Trim().Split('|');
			if (array.Length == 2 && float.TryParse(array[0], NumberStyles.Float, CultureInfo.InvariantCulture, out var result) && float.TryParse(array[1], NumberStyles.Float, CultureInfo.InvariantCulture, out var result2))
			{
				ImGui.SetNextWindowPos(new Vector2(result, result2), ImGuiCond.Always);
			}
		}
		catch
		{
		}
	}

	private void TrackPos()
	{
		Vector2 windowPos = ImGui.GetWindowPos();
		if (_lastPos == null || Math.Abs(windowPos.X - _lastPos[0]) > 0.5f || Math.Abs(windowPos.Y - _lastPos[1]) > 0.5f)
		{
			_lastPos = new float[2] { windowPos.X, windowPos.Y };
			_dirtySince = DateTime.Now;
		}
		if (_dirtySince != DateTime.MinValue && (DateTime.Now - _dirtySince).TotalSeconds > 1.5)
		{
			_dirtySince = DateTime.MinValue;
			try
			{
				File.WriteAllText(PosFile, _lastPos[0].ToString(CultureInfo.InvariantCulture) + "|" + _lastPos[1].ToString(CultureInfo.InvariantCulture));
			}
			catch
			{
			}
		}
	}

	private void OnRender(object sender, EventArgs e)
	{
		try
		{
			WinMem.Frame("Day/Night", size: false);
			TrackPos();
			// a see-through black panel behind it (the window itself has no background), so it reads over bright ground and sky
			Vector2 wp = ImGui.GetWindowPos();
			Vector2 ws = ImGui.GetWindowSize();
			ImGui.GetWindowDrawList().AddRectFilled(wp, wp + ws, ImGui.GetColorU32(new Vector4(0f, 0f, 0f, 0.55f)), 4f);
			double gameTicks = GameTicks;
			if (double.IsNaN(gameTicks) || gameTicks <= 0.0)
			{
				Im.TextDisabled("Day/night: -");
				return;
			}
			bool flag = IsDay(gameTicks);
			double num = SecondsToChange(gameTicks);
			float num2 = ImGui.GetTextLineHeight() * 1.3f;
			Vector2 cursorScreenPos = ImGui.GetCursorScreenPos();
			ImDrawListPtr windowDrawList = ImGui.GetWindowDrawList();
			Vector2 vector = new Vector2(cursorScreenPos.X + num2 / 2f, cursorScreenPos.Y + num2 / 2f);
			if (flag)
			{
				uint colorU = ImGui.GetColorU32(new Vector4(1f, 0.82f, 0.25f, 1f));
				windowDrawList.AddCircleFilled(vector, num2 * 0.26f, colorU, 20);
				for (int i = 0; i < 8; i++)
				{
					double num3 = (double)i * Math.PI / 4.0;
					Vector2 vector2 = new Vector2((float)Math.Cos(num3), (float)Math.Sin(num3));
					windowDrawList.AddLine(vector + vector2 * (num2 * 0.36f), vector + vector2 * (num2 * 0.48f), colorU, 1.6f);
				}
			}
			else
			{
				uint colorU2 = ImGui.GetColorU32(new Vector4(0.75f, 0.85f, 1f, 1f));
				uint colorU3 = ImGui.GetColorU32(new Vector4(0.08f, 0.1f, 0.18f, 1f));
				windowDrawList.AddCircleFilled(vector, num2 * 0.42f, colorU2, 24);
				windowDrawList.AddCircleFilled(vector + new Vector2(num2 * 0.2f, (0f - num2) * 0.12f), num2 * 0.36f, colorU3, 24);
			}
			ImGui.Dummy(new Vector2(num2, num2));
			ImGui.SameLine();
			int num4 = (int)Math.Ceiling(num / 60.0);
			string text = (flag ? "Night in " : "Day in ") + ((num4 >= 60) ? (num4 / 60 + "h " + num4 % 60 + "m") : (num4 + "m"));
			ImGui.SetCursorPosY(ImGui.GetCursorPosY() + (num2 - ImGui.GetTextLineHeight()) / 2f);
			ImGui.PushStyleColor(ImGuiCol.Text, flag ? new Vector4(1f, 0.9f, 0.55f, 1f) : new Vector4(0.75f, 0.85f, 1f, 1f));
			Im.Text(text);
			ImGui.PopStyleColor();
			if (ImGui.IsWindowHovered())
			{
				Im.SetTooltip("Dereth's " + (flag ? "day" : "night") + " - " + text.ToLowerInvariant() + " (real time).\nDrag to move. Turn off in Settings > Basic > Areas.");
			}
		}
		catch
		{
		}
	}
}
