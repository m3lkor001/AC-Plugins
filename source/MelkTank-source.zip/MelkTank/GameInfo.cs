using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using Decal.Adapter.Wrappers;

namespace MelkTank;

public static class GameInfo
{
	private const string SpeciesData = "0=2;1=1,0,2,5,6,4,3;2=4,6,5,2,0,1,3;3=6,1,2,3,5,0,4;4=6,1,4,3,2,5,0;5=4,3,2,0,1,5,6;6=2,0,5,3,1,4,6;7=0,2,1,6,3,5,4;8=6,0,1,5,3,2,4;9=1,2,0,3,6,5,4;10=1,4,2,0,5,3,6;11=2;12=2;13=1,3,0,5,6,4,2;14=6,3,2,1,4,0,5;15=2,0,1;16=5,2,4,3,0,1,6;17=2,0,3,1,5,4,6;18=2;19=6,0,1,2,3,5,4;20=2,0,1,3,4,5;21=0,4,6,3;22=6,2,1,4,0,3,5;23=6,0,1,3,2,5,4;24=6,3,2;25=2;26=5,2,0,6;27=0,2,1;28=5,3,0;29=4,5,2;30=1,2,0;31=6,0,1,2,3,4,5;32=5,1,3;33=2,0,1;34=2,0,1;35=1,0,2;36=2,6,0;37=2;38=5,2,0;39=6,2,1;40=2;41=2;42=3,2,0;43=2;44=2,0,1;45=2,5,3;46=6,0,2,1,3,4,5;47=1,0,2;48=5,2,0,3,1,6,4;49=6,2,0,1;50=2,6,1;51=2,1,0;52=6,2,1,0;53=5,1,2,4,6,3,0;54=5,2,0,1;55=1,5,4,2,6,3,0;56=5,1,3;57=2,0,5,3,1,4,6;58=2,0,5,3,1,4,6;59=5,2,0,3,1,6,4;60=4,2,0;61=6,2,0;62=2,0,1;63=3,4,6,5,1,2,0;64=2;65=2;66=2;67=2;68=2;69=2;70=4,3,0,2,1;71=1,5,4,0,2,6,3;72=2;73=2;74=2;75=5,0,2,6,1,4,3;76=2;77=6,2,0,1,3,4,5;78=4,6,5,2,3,0,1;79=2,0,6,5,4,3,1;80=6,2,1,0;81=1,0,6,2,3,4,5;82=2,1,0;83=4,2,0,1;84=1,2,0;85=2;86=2,0,1;87=2;88=1,0,2;89=0,1,2;90=2;91=2;92=1,0,2;93=2;94=2;95=6,2,1,0;96=2;-1=1,0,2,3,4,5,6;97=6;98=2,0,1;99=3,4,1,0,6,5,2;100=6,3,2,0,1,5,4;101=3,1,6,0,2,4,5";

	private const string OverrideData = "Magma Golem=5,1,0,2|Mist Golem=5,4,3,6,2,0,1|Nubilous Golem=4,5,3,2,0,1|Plasma Golem=4,5,3,2,0,1|Vapor Golem=5,4,15,4,3,6,2,0,1|Damaged Glacial Golem=6,1,0,2|Fractured Glacial Golem=6,1,0,2|Tanada Nanjou Shou-jen=3,4,6,5|Disgraced Nanjou Shou-jen=3,4,6,5|Magma Golem Exarch=5,1,0,2|Pillar of Fire=5,2,0|Infused Blood Golem=5,3,4,1,0,6,2|Infused Empyrean Blood Golem=5,3,4,2,6,0,1|Sapphire Golem=0,3,1,5,6,4,2|High Priestess Xik Minru=1,2,0|Contained Rift=2,1,0|Ebon Rift=2,1,0|Fallen Rift=2,1,0|Narrow Rift=2,1,0|Quiddity Rift=2,1,0|Shallow Rift=2,1,0|Tenebrous Rift=2,1,0|Umbral Rift=2,1,0|Unstable Rift=2,1,0|Aqueous Golem=4,6,5,3,2,1,0|Wave Golem=4,6,5,3,2,1,0|Unstable Magma Golem=5,1,0,2|Behemoth of Tenkarrdun=5,1,0,2|Small Magma Golem=5,1,0,2|Atlan's Crafting Golem=5,1,0,2|Bur Lizk=5,4,0,2|Dust Golem=5,4,6,3,0,1,2|Ancient Magma Golem=5,1,0,2|Frozen Ice Golem=6,1,0,2|Frozen Glacial Golem=6,1,0,2|Forge Golem=5,4,3,1,0,2|Frozen Gearknight=6|Diaphanous Nephol Golem=5,4,3,6,2,0,1|Tenuous Nephol Golem=5,4,3,6,2,0,1|Turbid Nephol Golem=5,4,3,6,2,0,1|Wall of Ice=6,1,0,2,3,4|Scold=5,1,0,2|Scold Chunk=5,1,0,2|Scold Lump=5,1,0,2|Freezing Mist Golem=5,4,3,6,2,0,1|Frost Golem=6,4,5,3|Elite Guardian=5,6|Enraged Ancient Soul=6,3,1,4,5,2,0|Mudmouth=6,4,3,5,1,0,2|Fiery Defender=5,2,4,1,0,3|Follower of Deewain=4,3,1,0,5,2,6|Chilled Defender=4,3,6,1,2,0,5|Charged Defender=5,3,4,2,1,0|Iron Golem Samurai=3,4,5,6,2,1,0|Clay Golem Samurai=1,5,6,4,3,2,0|Bronze Golem Samurai=4,3,5,6,2,1,0|Spectral Nanjou Shou-jen=1,6,2,3,4,5,0|Spectral Samurai=5,4,3,2,1,6,0|Spectral Claw Master=1,6,2,3,4,5,0";

	private const string CooldownData = "Asheron's Benediction=-32766|Asheron's Lesser Benediction=-32766|Blackmoor's Favor=-32765|Copper Medal of Vigor=-32761|Silver Medal of Vigor=-32761|Gold Medal of Vigor=-32761|Pyreal Medal of Vigor=-32761|Platinum Medal of Vigor=-32761|Copper Medal of Intellect=-32760|Silver Medal of Intellect=-32760|Gold Medal of Intellect=-32760|Pyreal Medal of Intellect=-32760|Platinum Medal of Intellect=-32760|Platinum Horn of Leadership=-32762|Pyreal Horn of Leadership=-32762|Gold Horn of Leadership=-32762|Silver Horn of Leadership=-32762|Bronze Horn of Leadership=-32762|Enhanced Health Elixir=-32764|Enhanced Mana Elixir=-32763";

	private const string HealKitData = "Greater Stamina Kit=1.1,200,2|Handy Healing Kit=1.0,50,1|Treated Healing Kit=2.0,25,1|Peerless Healing Kit=1.0,0,1|Excellent Healing Kit=1.5,10,1|Plentiful Healing Kit=1.6,100,1|Gifted Healing Kit=1.0,100,1|Adept Healing Kit=1.0,75,1|Gauntlet Health Kit=2.0,150,1|Eternal Health Kit=1.6,100,1|Renegade Herbal Kit=1.0,200,1|Greater Mana Kit=1.1,200,3|Medicated Mana Kit=10.0,500,3|Eternal Mana Kit=1.0,0,1|Eternal Stamina Kit=1.0,0,1|Greatest Stamina Kit=1.1,200,2|Lesser Mana Kit=1.6,100,3|Medicated Stamina Kit=10.0,500,2";

	private const string MemberData = "Black Rabbit|25|5\nIntense Shivering Crystalline Wisp|20|1020\nOlthoi Slasher|1|3190\nCow|12|20\nBurun Ruuk Fiend|75|385\nBurun Ruuk Soothsayer|75|410\nPyreal Target Drudge|76|10000\nOak Target Drudge|76|1000\nStraw Target Drudge|76|1000\nBaby Thrungus|82|3\nFalse Morel Thrungus|82|448\nGuruk Colossus|75|650\nGuruk Beast|75|550\nGuruk Brute|75|575\nGuruk Behemoth|75|700\nGuruk Smasher|75|525\nArmored Tusker|8|650\nTusker Liberator|8|250\nTuskie Thrower|8|80\nTusker Slave|8|325\nTusker Minion|31|90\nTusker Guard|8|375\nSilver Tusker|8|425\nReedshark Ravager|16|300\nTusker Worshipper|31|170\nJungle Phyntos Wasp|9|160\nTuskie Launcher|8|150\nStinging Chittick|33|300\nJungle Reaver|16|120\nWhite Phyntos Wasp|9|200\nTusker Redeemer|8|200\nReaper|16|500\nTuskie Gunner|8|200\nIron Spined Chittick|33|350\nInfected Assailer|8|700\nRampager|8|425\nAssailer|8|700\nPlated Tusker|8|800\nTusker Sycophant|31|225\nDark Magus|14|285\nDark Leech|14|198\nBlood Fiend|30|600\nChomu Sclavus|26|265\nSlithayr Tentacle|36|140\nSlithayr Tendril|36|180\nPutrid Moarsman|34|195\nSlithayr Eye Stalk|36|210\nSulthis Eye Stalk|36|310\nSulthis Tentacle|36|200\nSulthis Tendril|36|195\nFaisi Sclavus|26|205\nUlu Sclavus|26|198\nAffliction Wisp|20|360\nBlessed Moarsman|34|2000\nVerdant Moar|86|2220\nArdent Moar|86|2425\nBlighted Ardent Moarsman|34|2000\nBlighted Verdant Moarsman|34|2000\nSiessa Sclavus Soldier|26|1690\nAshris Niffis|45|3800\nKiller Phyntos Swarm|9|850\nKiller Phyntos Drone|9|1500\nKiller Phyntos Hive|-1|-1\nGiant Jungle Phyntos Wasp|9|2000\nKiller Phyntos Soldier|9|2000\nVerdant Moarsman|34|2000\nArdent Moarsman|34|2000\nSclavus Acolyte of T'thuun|26|2190\nBandit Mana Hunter|31|1500\nTentacle of T'thuun|36|1020\nTendril of T'thuun|36|810\nEyestalk of T'thuun|36|1230\nAfessa Sclavus Soldier|26|2200\nBlack Phyntos Hive|-1|-1\nBlack Phyntos Swarm|9|350\nNubilous Golem|13|300\nMist Golem|13|300\nBanderling Mangler|2|560\nBanderling Mauler|2|560\nAltered Drudge|3|215\nCoral Golem|13|600\nEmber|38|190\nBlack Phyntos Wasp|9|225\nMagma Golem|13|400\nCursed Bones|30|305\nFire Wisp|20|180\nRelic Bones|30|305\nFlamma|38|135\nGout|38|125\nBlighted Pyreal Golem|13|460\nMurk Drudge|3|325\nPhantom|77|315\nGreat Skeleton|30|300\nDrudge Sage|3|355\nDiamond Golem|13|575\nCursed Wisp|20|225\nFirestorm|38|330\nSpecter|77|295\nFlare|38|55\nBanderling Scalper|2|500\nDestroyer Grievver|44|520\nBanderling Savage|2|600\nCrystal Moiety|47|350\nLacerator|1|500\nOlthoi Warrior|1|300\nOlthoi Mutilator|1|350\nRaider Juggernaut|70|513\nBanderling Predator|2|500\nDrudge Cabalist|3|510\nAscendant Drudge|3|245\nAugmented Drudge|3|225\nUnconquered Drudge|3|300\nBanderling Aggressor|2|610\nDrudge Bloodletter|3|400\nPeerless Drudge|3|505\nTsuric|62|570\nNightmare Wisp|20|360\nPyreal Golem|13|460\nGotrok Tiatus|70|450\nVirindi Profane|19|500\nTumerok Trooper|6|400\nGotrok Titan|70|565\nTumerok War Monger|6|450\nGotrok Juggernaut|70|513\nDireland Rat|10|420\nParadox-touched Olthoi Warrior|1|2250\nParadox-touched Olthoi Noble|92|2000\nParadox-touched Olthoi Eviscerator|92|2000\nParadox-touched Olthoi Warrior Nymph|92|450\nParadox-touched Olthoi Eviscerator Nymph|92|698\nParadox-touched Olthoi Sentinel|92|20250\nParadox-touched Olthoi Lancer|92|1000\nParadox-touched Olthoi Noble Grub|92|300\nParadox-touched Olthoi Eviscerator Grub|92|323\nIncalescent Crystalline Wisp|20|720\nCrystalline Wisp|20|520\nShivering Crystalline Wisp|20|720\nAggregate Crystalline Wisp|20|1520\nVoltaic Crystalline Wisp|20|720\nCorroding Crystalline Wisp|20|720\nBanderling Guard|2|100\nTusker Crimsonback|8|110\nBrutish Monouga|28|190\nShadow|22|138\nShadow Lieutenant|22|190\nGoldenback Tusker|8|135\nElaniwood Golem|13|120\nWild Monouga|28|130\nScrawed Grievver|44|150\nDrudge Stalker|3|160\nSkeleton Lord|30|143\nSkeleton Captain|30|100\nHigh Tumerok|6|160\nTumerok Officer|6|110\nGold Phyntos Wasp|9|155\nCopper Golem|13|125\nSandstone Golem|13|115\nMite Scamp|7|45\nField Ursuin|46|80\nBanderling Raver|2|105\nReedshark Elder|16|60\nTumerok Scout|6|45\nTumerok Fighter|6|78\nBanderling Raider|2|83\nWood Golem|13|80\nLimestone Golem|13|80\nIvory Gromnie|15|60\nBroken Fragment|47|30\nShallows Shark|27|50\nAzure Gromnie|15|48\nGlissnal Niffis|45|115\nAdult Reedshark|16|60\nReedshark Pup|16|40\nListris Niffis|45|85\nVorous Shreth|32|65\nFemale Tusker|8|100\nSnowman|39|50\nHunter Shreth|32|50\nMite Squib|7|75\nDrudge Slinker|3|25\nMudlurk Mosswart|4|75\nBarker Mosswart|4|80\nMite Squire|7|85\nMale Tusker|8|100\nMite Sentry|7|80\nOutcast Monouga|28|40\nShadow Wisp|20|120\nGranite Golem|13|240\nRisen Knight|14|230\nCrude Monouga|28|125\nShadow Child|22|100\nCharge|42|125\nCopper Golem Kingpin|13|1500\nUrsuin Slasher|46|190\nVeteran Reedshark|16|60\nObeloth Raider|70|150\nGotrok Amploth|70|125\nGotrok Laigus|70|105\nTumerok Priest|6|185\nHarvest Reaper|30|10000\nSufut Zefir|29|90\nPumpkin Kin|93|190\nPumpkin Lord|93|1450\nVirindi Servant|19|125\nLich Lord|14|178\nSilver Rat|10|90\nVirindi Master|19|145\nScourge|60|140\nLaigus Lugian|5|105\nSkeleton Wraith|30|143\nPristine Doll|53|150\nAuroch Fire Yearling|11|70\nAuroch Fire Cow|11|95\nInnocuous Doll|53|115\nSotiris Hollow Minion|48|130\nLithos Raider|70|160\nInnocent Doll|53|150\nTumerok Warrior|6|103\nGreater Mu-miyah|14|80\nHorrible Mu-miyah|14|165\nFrost Golem|13|2350\nZombie Mage|14|1175\nSpirit Wisp|20|2125\nVirindi Monitor|19|1000\nShoguth Moarsman|98|2000\nMaguth Moarsman|98|2000\nMogshuth Moarsman|98|2000\nMoguth Moarsman|98|2000\nCorrupted Coral Golem|13|1600\nShogshuth Moarsman|98|2000\nMagshuth Moarsman|98|2000\nIllu Sclavus Soldier|26|2200\nSand Lurker|27|2670\nGreat Devourer|27|2670\nMaster Archer|31|1500\nMaster Mage|31|890\nMaster Soldier|31|1500\nDeep-sea Lava Golem|13|1600\nBrood Mother|98|2000\nSpawn Watcher|98|2000\nEgg|63|200\nSpawnling|98|400\nMoarsman Adherent of T'thuun|98|2000\nMoarsman Prior|98|2000\nMoarsman Priest of T'thuun|98|2000\nSpawn|98|500\nAuroch Cow|11|80\nAuroch Yearling|11|55\nCoral Tower|64|40000\nAuroch Bull|11|85\nOlthoi Soldier Grub|35|100\nOlthoi Eviscerator Grub|35|215\nOlthoi Grub|35|115\nOlthoi Nymph Grub|35|57\nBanderling Smasher|2|1710\nGrievver Violator|44|2150\nBanderling Crusher|2|1710\nBurrowing Grievver|44|2150\nBlack Coral Golem|13|500\nAggressive Swarm|85|1880\nChicken|69|3\nMosswart Fanatic|4|120\nOlthoi Drone|1|140\nOlthoi Nymph|1|115\nOlthoi Worker|1|215\nVirulent Grievver|44|180\nRough Monouga|28|115\nDrudge Sneaker|3|33\nMite Scion|7|25\nDrudge Servant|3|53\nBlue Phyntos Wasp|9|30\nBanderling Scout|2|50\nDrudge Prowler|3|45\nDrudge Skulker|3|20\nBlood Shreth|32|38\nMite Digger|7|60\nRed Phyntos Wasp|9|20\nScavenger Ursuin|46|45\nYoung Banderling|2|30\nCreeper Mosswart|4|40\nMite Snippet|7|20\nGnawer Shreth|32|15\nAugmented Tumerok|6|350\nRavenous Eater|79|740\nIntense Shivering Pillar|47|445\nIntense Aggregate Crystalline Wisp|20|2120\nIntense Incalescent Crystalline Wisp|20|1220\nIntense Incalescent Pillar|47|445\nMalus Shreth|32|245\nSinister Shadow|22|625\nNomad Mu-miyah|14|320\nDark Master|14|450\nRisen Lord|14|345\nTenebrous Shadow|22|450\nDrudge Mystic|3|400\nShadow Phantom|22|450\nShadow Wraith|22|500\nAbyssal Shadow|22|450\nTumerok High Priest|6|325\nBlighted Bane Grievver|44|538\nTelumiat Hollow Minion|48|450\nParoxysm Shadow|22|525\nMaelstrom Shadow|22|625\nGloom Drudge|3|400\nShadow Spectre|22|450\nVirindi Consul|19|350\nPlasma Golem|13|260\nPlatinum Golem|13|500\nVirindi Adjudicator|19|350\nVirindi Executor|19|275\nVirindi Desecrator|19|505\nChaos Wisp|20|400\nVirindi Profatrix|19|500\nVapor Golem|13|590\nPandemonium Shadow|22|510\nVirindi Puppet|19|115\nVirindi Inquisitor|19|500\nVirindi Artificer|19|7000\nMutated Mite|7|950\nInfested Rat|10|800\nRaven Augur|31|600\nGlissnal Nefane|45|800\nMangy Carenzi|55|900\nHelcan Margul|71|4000\nMottled Carenzi|55|1200\nDesecrated Doll|53|1000\nStalking Margul|71|800\nListris Nefane|45|1000\nPestilence Rat|10|1000\nSephal Nefane|45|2000\nRaven Conscript|31|680\nMalignant Marionette|54|4000\nBefouled Doll|53|1050\nHellion|71|6000\nDamned Marionette|54|8000\nInfernal Zefir|29|8000\nRavager|55|8000\nMonstrous Mite|7|5000\nSchism|19|1100\nBiaka|71|7500\nWretched|22|5000\nHastar the Misbegotten|22|8000\nPenumbral Horror|44|2000\nUmbral Rift|19|1000\nCursed Marionette|54|6000\nMalevolent Zefir|29|6000\nTenebrous Rift|19|900\nCreeping Margul|71|1200\nGraal Margul|71|5000\nRaven Hunter|31|450\nVoid Lord|22|2000\nDefiled Doll|53|1100\nTainted Carenzi|55|4000\nContagion Rat|10|6000\nParfal Nefane|45|5000\nDark Zefir|29|1200\nMisshapen Mite|7|800\nCosseted Doll|53|950\nOlthoi Servant|1|175\nOlthoi Needler|1|200\nDrudge Lurker|3|150\nMighty Oak Golem|13|425\nBlighted Oak Golem|13|260\nSparkling Dual Fragment|47|380\nNalif Zefir|29|105\nFerocious Monouga|28|225\nDrudge Ravener|3|160\nWily Monouga|28|190\nGold Golem|13|425\nUnruly Monouga|28|355\nCrystal Golem|13|1000\nTerrible Monouga|28|355\nCruel Monouga|28|290\nAzael Zefir|29|250\nCunning Monouga|28|290\nBanderling Striker|2|220\nBanderling Berserker|2|295\nUmbris Shadow|22|420\nVenomous Grievver|44|245\nObsidian Golem|13|200\nOak Golem|13|260\nRevenant|14|200\nFire Shreth|32|550\nAshen Bones|30|340\nSkeleton Bone Knight|30|223\nSkeleton Bone Lord|30|230\nGlacial Golem Margrave|13|5000\nFrost|61|220\nTumerok Major|6|300\nPanumbris Shadow|22|410\nDual Fragment|47|110\nScintilla|42|135\nStatic|42|20\nTumerok Taskmaster|6|330\nTumerok Gladiator|6|223\nAuroch Fire Bull|11|100\nDark Revenant|14|285\nBanished Grievver|44|1295\nMosswart Mire-Witch|4|190\nStrife Wisp|20|225\nArmored Skeleton|30|350\nAcidic Coral Golem|13|600\nDrudge Slave|3|60\nSkeletal Hero|30|380\nPhantasm|14|415\nAscendant Tumerok|6|365\nGotrok Extas|70|390\nStasis Wisp|20|225\nCrystal Shard|47|215\nBanderling Enforcer|2|400\nBanderling Thrasher|2|600\nInvading Silver Scope Phalanx|99|680\nInvading Copper Cog Phalanx|99|680\nBrumal|61|200\nHorripal|61|125\nRufous Grievver|44|290\nExtas Raider|70|390\nCrystal Minion|13|350\nCrystal Lord|13|15000\nPlate Armoredillo|17|350\nGelid|61|400\nBanderling Slayer|2|440\nReedshark Slasher|16|650\nAcidic Diamond Golem|13|575\nOlthoi Lancer|1|425\nCorrosion Wisp|20|325\nCaustic|60|250\nBanderling Antagonist|2|438\nDiamond Lord|13|645\nHyem|61|250\nGreat Revenant|14|350\nGauloth Shreth|32|550\nPyre Skeleton|30|6850\nPyre Minion|30|3000\nCorrupted Dread|77|15210\nWight|14|6210\nWight Captain|14|18255\nExhumed Bones Piles|-1|-1\nShambling Archivist|14|8000\nPyre Champion|30|12250\nHatred Wisp|20|20250\nWight Blade Sorcerer|14|6175\nLady Tairla Mhoire|77|200250\nSpectral Dread|77|20250\nSorrow Wisp|20|20125\nDespair Wisp|20|20125\nInsidious Monouga|28|475\nBlight Rat|10|1000\nLarge Blight Rat|10|1000\nBurun Ruuk Lout|75|325\nBurun Ruuk Seer|75|340\nDread Mattekar|23|171\nOlthoi Slayer|1|3690\nOlthoi Ripper|1|3840\nThe Chicken|69|3\nGotrok Gigas|70|200\nGotrok Lithos|70|140\nOlthoi Swarm Eviscerator|1|465\nOlthoi Swarm Mutilator|1|500\nOlthoi Brood Matron|1|1210\nDrudge Robber|3|45\nDrudge Robber Baron|3|60\nLinvak Ursuin|46|190\nBrown Rabbit|25|5\nOlthoi Swarm Nymph|1|215\nOlthoi Swarm Drone|1|300\nRuschk Laktar|81|2703\nAncient Coral Golem|13|650\nFrenzied Fiun|78|400\nInsatiable Eater|79|770\nAbhorrent Eater|79|693\nRuschk Draktehn|81|3225\nRuschk Kartak|81|1483\nRuschk Sadist|81|485\nSkeletal Mate|30|425\nRepugnant Eater|79|630\nManiacal Fiun|78|595\nRendeath Shreth|32|608\nSpectral Wisp|20|390\nFloeshark|16|760\nShallows Devourer|27|95\nDark Sorcerer|14|395\nFoul Moarsman|34|160\nSlithis Tendril|36|100\nSlithis Eye Stalk|36|150\nSlithis Tentacle|36|100\nIsland Armoredillo|17|135\nRank Moarsman|34|125\nMosswart Soul Trapper|4|160\nDread Idol|50|500\nMosswart Zealot|4|160\nMosswart Idolator|4|120\nShallows Destroyer|27|135\nMire Phyntos Wasp|9|30\nMosswart Townsfolk|4|180\nIdol|50|200\nGhost Wisp|20|50\nSwamp Rat|10|80\nWater Wisp|20|30\nMosswart Shaman|4|80\nKilif Zefir|29|50\nShallows Slayer|27|70\nShallows Lurker|27|68\nSparring Golem|13|35\nCarenzi Sentry|55|55\nCarenzi Pouchling|55|30\nHea Warrior|58|123\nCutthroat|31|150\nOlthoi Harvester|1|100\nStrand Siraluun|56|300\nOlthoi Gardener|1|110\nHarrower Grievver|44|410\nFragment|47|65\nHea Itealuan|58|190\nKithless Siraluun|56|400\nRabid Carenzi|55|300\nOlthoi Piercer|1|350\nMercenary|31|180\nEater|79|400\nOlthoi Soldier|1|200\nFeral Carenzi|55|375\nHea Elder Shaman|58|440\nOlthoi Eviscerator|1|350\nCopper Gromnie|15|410\nVirindi Observer|19|300\nBadlands Siraluun|56|500\nCarnivorous Carenzi|55|440\nGreat Elariwood Golem|13|700\nZharalim|31|220\nSavage Carenzi|55|500\nBrass Gromnie|15|390\nViamontian Mage|83|430\nHea Shaman|58|325\nViamontian Man-at-Arms|83|460\nHea Nualuan|58|210\nEbon Gromnie|15|300\nVoltarc|42|200\nWoodland Ursuin|46|360\nTimber Siraluun|56|345\nAssassin|31|180\nSable Gromnie|15|250\nHighwayman|31|130\nMarae Ursuin|46|300\nHea Windreave|58|163\nCarenzi Burrower|55|100\nCarenzi Stalker|55|200\nLittoral Siraluun|56|190\nUrsuin Slicer|46|410\nViamontian Knight|83|468\nEnku Zefir|29|350\nHea Champion|58|365\nRabid Eater|79|470\nViamontian Warcaster|83|473\nManuaka|16|360\nSahkurea|16|360\nHea Tuperea|58|330\nUtelari|16|360\nReshalra|16|360\nPoacher|31|190\nHea Drumspeaker|58|85\nMud Golem|13|40\nCanescent Mattekar|23|400\nShadow Nightmare|22|525\nNightmarish Doll|53|1100\nNightmarish Marionette|54|8000\nEbon Rift|19|800\nSoiled Doll|53|900\nDusk Zefir|29|1000\nGiant Mite|7|3000\nShadow Proctor|22|1800\nArtifex of the Living Darkness|19|5000\nVirindi Quidiox|19|5000\nArtifex of the Singularity|19|5000\nAvarice|19|500\nDisobedience|19|500\nChange|19|500\nChaos|19|500\nIndividuality|19|500\nUlgrim|19|500\nBandit|31|35\nBrigand|31|70\nHea Runner|58|70\nWater Golem|13|70\nSand Golem|13|110\nAun Elder Shaman|57|425\nAun Nualuan|57|160\nAun Itealuan|57|160\nScathisa|42|450\nHea Kanokeh|58|330\nHea Karenua|58|330\nHea Temenua|58|330\nCultist|31|154\nOlthoi Legionary|1|300\nSynnast|42|450\nVirindi Collector|19|275\nAun Hunter|57|80\nAun Ralirea|57|330\nEngorged Eater|79|400\nSapphire Golem|13|1000\nVoracious Eater|79|495\nRoyal Thaumaturge|83|510\nPrimeval Skeleton|30|385\nFractured Glacial Golem|13|1000\nViamontian Lord|83|720\nBokrok Lugian|5|450\nKroktok Lugian|5|450\nViamontian Hand|83|808\nUndead Captain|14|443\nViamontian Commander|83|495\nViamontian Counselor|83|490\nViamontian War Wizard|83|480\nViamontian Tribune|83|680\nRoyal Prison Warden|83|495\nMerciless Monouga|28|475\nDesert Rabbit|25|5\nOpor Niffis|45|160\nJade Gromnie|15|68\nAbominable Snowman|39|5180\nSnow Tusker Warrior|8|5250\nSnow Tusker Leader|8|5500\nGurog Henchman|100|2000\nGurog Soldier|100|2000\nFrozen Wight Sorcerer|14|6175\nFrozen Wight|14|6210\nGurog Minion|100|2000\nSnow Tusker|8|5000\nHoary Mattekar|23|475\nPugnacious Monouga|28|400\nDire Ursuin|46|215\nFrozen Wight Captain|14|18255\nTwisted Shadow|22|500\nBlack Rat|10|20\nMountain Rat|10|80\nShivver|61|200\nBound Crystal Golem|13|1000\nBound Coral Golem|13|600\nInvading Bronze Gauntlet Phalanx|99|680\nInvading Iron Blade Phalanx|99|680\nEnoki Thrungus|82|355\nTidal Siraluun|56|65\nHea Hunter|58|120\nMarsh Siraluun|56|45\nFerocious Ursuin|46|320\nSkeletal Champion|30|350\nShroud Cabal Raider|31|230\nShroud Cabal Raider Captain|31|400\nBanderling Bandit|2|160\nUnstable Magma Golem|13|150\nImperial Mu-miyah|14|355\nInferno|38|330\nTumerok Champion|6|365\nUnstable Rift|19|320\nGuardian Mu-miyah|14|165\nShivering Pillar|47|445\nIncalescent Pillar|47|445\nCorroding Pillar|47|445\nVoltaic Pillar|47|445\nDire Mattekar|23|171\nLesser Void Knight|22|625\nBloodthirsty Monouga|28|420\nBlighted Dire Ursuin|46|215\nUntamed Siraluun|56|450\nAun Herbalist|57|425\nHea Tnakarea|58|3225\nChief Grogbash|2|3225\nKorgluuk of Bur|75|3225\nChampion Bullgara|4|3225\nWarrior Corthos|5|3225\nGlormigoth|98|3225\nDarcusch the Barbarian|81|3225\nKerthump the Ear Taker|3|3225\nGrave Rat|10|1350\nDeathTail|10|200250\nBlood Curse Rat|10|1350\nLord Cynreft Mhoire|30|200250\nPillar of Fire|62|2000\nGlacial Golem|13|150\nObeloth Lugian|5|150\nSouthern Black Claw Raider|3|160\nCrystal Spur|47|120\nBlight Spirit|77|475\nBurun Ruuk Adept|75|250\nAste Sclavus|26|88\nEssa Sclavus|26|100\nBurun Ruuk Scamp|75|200\nAshen Moarsman|34|100\nEsper Ursuin|46|190\nChomu Sclavus Lord|26|255\nStorage Crate|-1|-1\nSiessa Sclavus|26|360\nAfesse Sclavus|26|420\nPatrician Phaerix|14|50000\nPatrician Kilkitris|14|50000\nIllu Sclavus|26|480\nLunnum|78|200000\nMosswart Swamp Lord|4|195\nMosswart Scavenger|4|300\nMosswart Scrounger|4|245\nWar Mattekar|23|700\nAdept of Lightning|83|513\nAdept of Frost|83|513\nAdept of Fire|83|513\nAdept of Acid|83|513\nTitanium Armoredillo|17|5000\nKirit Zefir|29|2000\nCrystal Shard Sentinel|47|200\nSentient Crystal Shard|47|15000\nOlthoi Larvae|35|1690\nDegenerate Shadow|22|600\nDepraved Shadow|22|605\nParfal Sleech|45|615\nListris Sleech|45|620\nDisgraced Nanjou Shou-jen|31|1400\nVirindi Paradox|19|5000\nStomper|8|500\nTortured Spirit|77|645\nMukkir Draktehn|89|3725\nMukkir Kartak|89|3725\nMukkir Laktar|89|3725\nUmbral Mukkir|89|3725\nTukora Lieutenant|5|4670\nTukora Commander|5|4670\nInflamed Ursuin|46|5000\nOlthoi Progenitor|1|2030\nMosswart Agitator|4|4190\nMosswart Elder|4|4110\nMosswart Gladiator|4|5000\nEnraged Ancient Soul|14|3000\nSwarm Demon|1|5000\nDemon Swarm Matron|1|300000\nDemon Swarm Clawbearer|1|700\nBanished Tumerok|6|530\nYoung Mosswart|4|25\nSir Bellas|83|12000\nWood Target Drudge|76|10000\nTownsperson|31|1500\nTan Rat|10|15\nSandy Armoredillo|17|115\nStringent|60|25\nGuruk Basher|75|400\nGuruk Boor|75|425\nFortress Barrier|-1|-1\nShadow Sprite|22|15\nSewer Rat|10|150\nSe Sclavus|26|85\nSwamp Gromnie|15|80\nUmbris Elite|22|605\nUmbris Elite Commander|22|12205\nAerbax|19|100200\nClaude the Dark Archmage|19|70000\nBurun Ruuk Adherent|75|315\nGreen Phyntos Wasp|9|25\nZombie|14|75\nMosswart Feeder|4|55\nLich|14|113\nHoary Armoredillo|17|200\nOlthoi Noble|1|300\nAcolyte of Storms|31|230\nAcolyte of Wind|31|230\nAcolyte of Breath|31|230\nBanderling Rogue|2|225\nFleshless Warrior|30|230\nBasalt Golem|13|260\nBanished Tusker|8|575\nSentient Fragment|47|180\nDread Ursuin|46|275\nBanished Olthoi|1|550\nBanished Mu-miyah|14|365\nBanished Phyntos Wasp|9|425\nBanished Drudge|3|425\nBanished Banderling|2|760\nBanished Shadow|22|620\nBanished Monouga|28|555\nDire Champion Golem|13|1800\nTanada Nanjou Shou-jen|31|1400\nVirindi Director|19|145\nTerebrous Hollow Minion|48|300\nTempest Wisp|20|375\nGuardian of the Singularity|19|1500\nListris Niffling|45|48\nGlissnal Niffling|45|60\nThe Gatekeeper|48|600\nThe Sage|19|700\nThe Auditor|19|700\nWithered Raider Justicar|70|10000\nWithered Raider Prefect|70|10000\nWithered Revered Tumerok Shaman|6|5000\nWithered Transcendent Tumerok|6|5000\nWithered Banderling Paragon|2|10000\nWithered Banderling Hierophant|2|6000\nWithered Drudge Seraph|3|5860\nWithered Drudge Seraph Mystic|3|6000\nFallen Shadow|22|5500\nFallen Marionette|54|8500\nFallen Margul|71|8000\nDoomshark|16|6000\nFallen Mite|7|5500\nBrown Bunny|41|3\nGotrok Obeloth|70|150\nWasteland Rat|10|180\nSpirit|77|220\nDoomed Spirit|77|635\nEntropy Wisp|20|500\nBone Scourge|30|500\nMu-miyah Sentinel|14|6130\nRadiant Crystal|47|5001\nDiseased Phyntos Wasp|9|635\nVirulence|60|565\nDazzling Crystal|47|5001\nBrilliant Crystal|47|5001\nUndead Miner|14|63\nUndead Minion|14|450\nFire Golem|13|600\nRemoran Sand Stalker|84|2500\nShallows Shredder|27|2670\nBlack Bunny|41|3\nGreat Mattekar|23|73\nWave Golem|13|2350\nShallows Gorger|27|2670\nScummy Moarsman|34|1900\nBarbaric Mukkir|89|2703\nCoruscating Mukkir|89|2703\nDecaying Ruschk Laktar|14|2703\nMukkir|89|1683\nFanatical Mukkir|89|2703\nVile Mukkir|89|2703\nFanatical Mukkir Ward Guardian|89|5406\nDark Crystal Spire|-1|-1\nBlack Coral Golem Viceroy|13|3250\nShambling Undead Ruschk|14|625\nDegenerate Shadow Commander|22|9200\nRemoran Corsair|84|610\nFouled Remoran|84|9160\nDegenerate Mukkir|89|618\nDepraved Mukkir|89|620\nHorrid Remoran|84|615\nDark Remoran|84|12165\nSodden Undead Ruschk|14|630\nBlighted Coral Golem|13|550\nBlighted Coral Golem Viceroy|13|3350\nDepraved Shadow Commander|22|12205\nLithos Lugian|5|140\nAmploth Raider|70|125\nDark Myrmidon|30|450\nDesert Bunny|41|3\nOlthoi Nettler|1|100\nGrey Rat|10|15\nMinion Leader|48|205\nGigas Raider|70|200\nBanderling Chief|2|130\nDesert Rat|10|80\nBanderling Captain|2|90\nBanderling Breeder|2|105\nIce Golem|13|90\nRevenant Antiquary|14|200\nTrusted Tusker|8|100\nRelic Watchman|30|550\nHellfire|38|540\nAerfalle's Weakened Apprentice|14|500\nOld Bones|30|25\nOlthoi Swarm Guardian|1|510\nOlthoi Egg|-1|-1\nOlthoi Brood Queen Elder|1|6000\nOlthoi Elder Brood Matron|1|1710\nAsh Gromnie|15|90\nMagma Golem Exarch|13|5000\nGuardian of the Lost Light|14|200\nFalatacot Consort|14|3005\nAncient Magma Golem|13|2350\nAltered Olthoi|1|280\nAugmented Olthoi|1|380\nMasonry Golem|13|2350\nIntense Corroding Crystalline Wisp|20|1020\nShroud Cabal Forager|31|175\nShroud Cabal Forager Captain|31|200\nTower Guardian|13|900000\nFilthy Mattekar|23|700\nSwarthy Mattekar|23|8000\nBattle Lord Gregor|14|20000\nBeaten Doll|53|110\nBattered Doll|53|115\nGotrok Montok|70|300\nNorthern Black Claw Raider|3|160\nReinforced Door|-1|-1\nOlthoi Swarm Worker|1|400\nRoyal Olthoi Guardian|1|510\nOlthoi Swarm Legionary|1|400\nOlthoi Swarm Soldier|1|380\nOlthoi Swarm Noble|1|400\nOlthoi Keeper|1|350\nYoung Olthoi Queen|1|5000\nOlthoi Noble Grub|35|200\nK'nath S'tath|21|60\nK'nath N'gell|21|55\nMox|60|175\nFaisi Disciple|26|205\nChomu Disciple|26|265\nAste Soul Harrier|26|238\nEssa Soul Harrier|26|200\nSoul Hunter|14|450\nCarrion Shreth|32|25\nWhite Mattekar|23|65\nExtas Lugian|5|390\nEssa Sclavus Lord|26|200\nUlu Sclavus Lord|26|228\nFaisi Sclavus Lord|26|255\nSata Sclavus Lord|26|215\nRed Rat|10|55\nBroken Doll|53|100\nBronze Armoredillo|17|100\nSkeleton Warrior|30|73\nSkeleton|30|45\nBak'tshay Guard|101|3500\nMu-miyah Guardian|14|8000\nBak'tshay Slave|101|5850\nBak'tshay|101|3000\nReedshark Hunter|16|4500\nMu-miyah Lord|14|10000\nMu-miyah Vizier|14|7000\nGuardian Armoredillo|17|6000\nMu-miyah Soldier|14|9000\nLesser Mu-miyah|14|65\nRust Gromnie|15|45\nStony Armoredillo|17|100\nReedshark Seeker|16|4500\nTamed Reaper|16|4500\nMu-miyah Champion|14|7000\nWar Reaper|16|4500\nSuspicious Scarecrow|49|68\nSmall Shadow Child|22|30\nBak'tshay Soldier|101|6850\nVirtuous Doll|53|50\nSilt Lurker|16|90\nDust Golem|13|15000\nCracked Stone Tablet|-1|-1\nShallow Rift|19|100\nBak'tshay Servant|101|4850\nBrown Armoredillo|17|60\nCharred Skeleton|30|73\nRed Phyntos Drone|9|50\nTumerok Worker|6|48\nShady Scarecrow|49|108\nFlicker|38|20\nTamed Armoredillo|17|7000\nSeared Skeleton|30|100\nUndead|14|43\nGigas Lugian|5|200\nWar Armoredillo|17|7000\nRickety Scarecrow|49|33\nBurning Sands Golem|13|15000\nMad Cow|12|120\nMinik Ra T'thuunixis|14|150000\nNivinizk T'thuunixis|14|150000\nKazyk Ri T'thuunixis|14|150000\nTthuun Pillar|-1|-1\nShifty Scarecrow|49|93\nDrudge Vagabond|3|58\nSmall Sand Golem|13|600\nSmall Sandstone Golem|13|575\nMosswart Chief|4|110\nMud Golem Sludge Lord|13|400\nThree Eyed Snowman|39|20000\nRock|13|2175\nFollower of Deewain|13|3525\nChilled Defender|13|25325\nFiery Defender|13|25325\nCharged Defender|13|25325\nFallen Rock|-1|-1\nMissile Defender|13|615\nIron Golem|13|200250\nAste Sclavus Lord|26|238\nGuruk Miscreant|75|450\nVoid Knight|22|5000\nCommander Jared Kurth|83|15000\nGuruk Crusher|75|500\nGuruk Heavy|75|475\nShadow-touched Virindi Paradox|19|5000\nOlthoi Sentinel|1|3000\nOlthoi Primordial|1|3000\nBanderling Hierophant|2|6000\nBanderling Paragon|2|10000\nDrudge Seraph|3|5000\nBile Grievver|44|5000\nDark Guardian|14|4500\nRevered Tumerok Shaman|6|5000\nK'nath I'km|21|3000\nK'nath X'ela|21|3000\nK'nath S'hirc|21|3000\nK'nath An'dras|21|3000\nK'nath N'aes|21|3000\nK'nath T'amt|21|3000\nK'nath Thea'reh|21|3000\nK'nath La'nal|21|3000\nDrudge Seraph Mystic|3|6000\nTremendous Monouga|28|100000\nAdolescent Ivory Gromnie|15|5000\nAdolescent Azure Gromnie|15|5000\nAdolescent Ash Gromnie|15|5000\nAdolescent Rust Gromnie|15|5000\nRaider Prefect|70|10000\nRaider Justicar|70|10000\nLich Oppressor|14|3700\nChimera|14|4000\nTormenter|30|5000\nArchfiend|30|5000\nTranscendent Tumerok|6|5000\nRuschk Haktar|81|1100\nMukkir Aspect of Grael|89|30000\nBanderling Champion|2|12000\nIron Blade Heavy Scout|99|9975\nSilver Scope Heavy Scout|99|9975\nCopper Cog Heavy Scout|99|9975\nShadow-touched Virindi Quidiox|19|5000\nSpiny Chittick|33|45\nReedshark Stripling|16|40\nTusker Kin|31|50\nIncendiary Knight|62|6130\nBound Light Falatacot|77|15210\nBound Pyre Champion|30|12250\nCorrupted Maiden|77|500\nRevenant Lord|14|6210\nLady Aerfalle|14|200250\nBound Spectral Handmaiden|77|490\nInjured Olthoi|1|60\nGold Shallows Shredder|27|5340\nAqueous Golem|13|2350\nGlissnal Sleech|45|9180\nBloodstone|47|20125\nAgitated Desert Phyntos Swarm|9|850\nRemoran Raker|84|4505\nGrimy Moarsman|34|1900\nMucky Moarsman|34|1900\nAstis Niffis|45|3180\nRemoran Sea Raptor|84|5510\nBenek Niffis|45|3180\nGold Moarsman|34|3800\nGold Niffis|45|6360\nGold Remoran|84|11020\nOutcast Lord|28|85\nParadox-touched Olthoi Swarm Eviscerator|92|3090\nParadox-touched Olthoi Ripper|92|3090\nParadox-touched Olthoi Slasher|92|2690\nParadox-touched Olthoi Flyer Nymph|92|638\nParadox-touched Olthoi Lacerator|92|2190\nParadox-touched Olthoi Queen|92|200000\nShambling Ruschk Chieftain|14|9195\nMukkir Progenitor|89|12000\nHellion Mukkir|89|9203\nAbyssal Totem|-1|-1\nTuskie Tosser|8|40\nDevastator|8|1000\nAnnihilator|8|5000\nObsidian Chittick|33|400\nHorned Chittick|33|120\nMowen Udaun|8|8000\nGotrok Fortress Guard|70|425\nSephal Niffis|45|180\nLady Saliane|77|20250\nCorrupted Grave Frost|61|150\nLord Hendrel|14|12175\nLord Trimere|30|16250\nNoble Remains|-1|-1\nGuardian Statue|-1|-1\nDoor|-1|-1\nFlame Guardian|38|250\nChick|69|1\nField Ursuin Cub|46|55\nCarrion Shrethlet|32|15\nBlood Shrethlet|32|20\nHunter Shrethlet|32|35\nDire Mattie|23|96\nGhastly Priestess|14|3000\nShambling Adherent|14|2500\nWorm Feast|14|6130\nSodden Cadaver|14|6130\nNarrow Rift|19|100\nTumideon Hollow Minion|48|250\nSingular Virindi Director|19|145\nGnawer Shrethlet|32|8\nVoid|-1|-1\nShadow Engineer|22|1675\nShadow Flyer|22|1100\nGrievver Shredder|44|2650\nDevourer Margul|71|3470\nShadow Vortex|22|40400\nShadow's Breath|22|1828\nEbon Mattekar|23|475\nMosswart Cringer|4|185\nMosswart Muck Stalker|4|180\nGragghk|4|190\nRaging Ursuin|46|375\nMartinate Virindi Inquisitor|19|500\nRusset Rat|10|15\nSpark|42|55\nMosswart Clinger|4|190\nHigh Mu-miyah|14|165\nRisen Soldier|14|165\nDark Marionette|54|160\nUrsuin Slasher Cub|46|100\nSandy Armoredillo Pup|17|65\nPortal Pillar|-1|-1\nPortal Keeper|83|720\nUnchained Knight|83|10200\nShore Armoredillo|17|120\nRoyal Vivimancer|83|2505\nMana Barrier|-1|-1\nTiatus Lugian|5|450\nLugian Juggernaut|5|513\nEnthralled Idolator|4|250\nTrue Believer|4|225\nCaptain Waliknua|6|520\nDesolation Moarsman|34|325\nGiant Imprisoned Monouga|28|600450\nChilly the Snowman|39|45\nGotrok Aetherium Miner|70|1000\nGotrok Mining Foreman|70|4000\nHea Apostate Shock Trooper|6|1000\nHea Apostate Warlord|6|3500\nApostate Servant|19|1000\nApostate Master|19|6000\nApostate Sapper|19|1000\nApostate Excavation Foreman|19|3000\nApostate Excavation Master|19|6000\nMaelstrom|62|570\nBane Grievver|44|538\nDiamond Golem Suzerain|13|18000\nMiasma|60|400\nApostate Nexus Hollow Minion|48|1000\nApostate Nexus Master|19|8000\nPuffball Thrungus|82|929\nFire Morel Thrungus|82|2922\nBlack Morel Thrungus|82|2922\nJelly Thrungus|82|929\nFrozen Wight High Acolyte|14|18255\nBlight Revenant|14|443\nBlight Lictor|14|1000\nK'nath T'aed|21|90\nK'nath N'osaj|21|60\nTumerok Standard Bearer|6|103\nTumerok Commander|6|160\nTumerok Lieutenant|6|110\nTumerok Controller|6|160\nWhite Rat|10|10\nTiofor Ursuin|46|115\nK'nath D'Nob|21|65\nK'nath Z'bog|21|50\nApozim|60|200\nLugian Warlord|70|260\nSwamp King|4|300\nSata Sclavus|26|145\nBuillic|60|230\nTundra Mattekar|23|186\nUber Penguin|80|4500\nElite Guardian|13|20000\nStone Fists|13|5000\nEthereal Wisp|20|20\nSnowy Mattekar|23|68\nAzaxis|19|25000\nEnthralled Zealot|4|275\nKillagurg|4|100000\nDreadful Ursuin|46|5000\nObliterator|8|50000\nBronze Gauntlet Heavy Scout|99|9975\nGold Gear Heavy Scout|99|9975\nPlatinum Golem Mountain King|13|25000\nFallen Tumerok|6|5500\nFallen Drudge|3|5500\nSmall Coral Golem|13|560\nRuschk Warlord|81|280\nMuck Glutton|34|300\nMiry Moarsman|34|400\nCold One|26|330\nSishalti Eye Stalk|36|480\nSishalti Tentacle|36|450\nSishalti Tendril|36|440\nBur Lizk|14|8000\nAstyrrian|42|450\nLaigus Raider|70|105\nParfal Niffis|45|29\nFallen Crystal Shard|47|15500\nViamontian Mercenary|83|360\nFamished Eater|79|325\nBlockade Guard|83|460\nFreshwater Armoredillo|17|105\nStony Armoredillo Pup|17|50\nBrown Armoredillo Pup|17|30\nK'nath B'orret|21|5000\nWest Armory Captain|77|20250\nRock Wall|-1|-1\nNorth Armory Captain|77|20250\nForge Golem|13|3500\nSpiny Armoredillo|17|45\nGreat Mattie|23|43\nWarlock of the Blood|14|950\nThrungus|82|28\nPallid Moar|86|70\nPallid Moarsman|34|110\nGuruk Destroyer|75|600\nThralled Guruk Spore Seeker|75|1030\nTormented Imperial Consort|14|3000\nInfused Blood Golem|13|1200\nFalatacot Blood Elder|14|3000\nFalatacot Prison Warden|14|3000\nDream Marauder|19|600\nPanumbral Soldier|22|6130\nThief of Dreams|19|5135\nThe Black Breath|22|858\nShade of Bael'Zharon|52|70000\nMu-miyah Channeller|14|7000\nMu-miyah Soothsayer|14|7000\nBak'tshay Lady|101|15130\nMu-miyah Grand Vizier|14|15200\nMu-miyah Slave Master|14|15200\nGreater Penumbral Horror|44|4000\nObsidian Sentient Fragment|47|15000\nLuminary Knight|62|6130\nInner Chamber Guardian|13|1616\nAtlan's Crafting Golem|13|2000\nBronze Armoredillo Pup|17|50\nBehemoth of Tenkarrdun|13|800\nTenkarrdun Hellfire|38|550\nRadiant Blood Crystal Array|-1|-1\nCharged Pillar|47|5000\nBurning Pillar|47|5000\nIorik Tendril|36|440\nIorik Eye Stalk|36|480\nIorik Tentacle|36|450\nGuardian of the Monolith|38|75000\nChained Tusker|8|500\nDark Bobo|8|200000\nMudmouth|59|300000\nImp|22|500\nParadox-touched Olthoi Ward Guardian|92|30250\nParadox-touched Olthoi Noble Nymph|92|450\nArmored Skeleton Lord|30|475\nRoyal Inquisitor|83|890\nBloated Eater|79|785\nHarraag|2|30000\nScoriscant|62|400\nPolar Ursuin|46|370\nHoarfrost|61|1625\nFrozen Ice Golem|13|1850\nWall of Ice|-1|-1\nFreezing Mist Golem|13|3850\nFrozen Glacial Golem|13|100350\nFrozen Gearknight|99|601\nIron Blade Knight|99|808\nBronze Gauntlet Knight|99|808\nIron Blade Lord|99|808\nGold Gear Knight|99|808\nCopper Cog Knight|99|808\nSilver Scope Knight|99|808\nMartinate Simulacrum|59|200\nMartinate Simulacrum Magician|59|154\nWhite Mattie|23|35\nTiofor Ursuin Cub|46|65\nZofrit Zefir|29|70\nDark Wisp|20|70\nTheral|62|500\nSirrocco|62|550\nAvalanche|62|500\nBlizzard|62|500\nConflagration|62|530\nCrystal Golem Imperator|13|20000\nTiatus Raider|70|450\nCorrupt Conflagration|62|2130\nVirindi Dreamslayer|19|12250\nVirindi Archmage of Dream|19|7675\nBloodstone Shard|47|5000\nBloodstone Fragment|47|3000\nLord Kastellar|14|150000\nGurog Guardian|100|2000\nBloodstone Crystal Stockpile|-1|-1\nMaster Bloodstone|47|150000\nUnstable Master Bloodstone Satellite|47|500\nMaster Bloodstone Satellite|47|1000\nInvading Silver Scope Squire|99|720\nInvading Iron Blade Squire|99|720\nInvading Iron Blade Knight|99|808\nInvading Bronze Gauntlet Knight|99|808\nMaster's Acolyte|31|600\nThe Master|31|500000\nBrown Mouse|10|6\nWhite Mouse|10|6\nThug|31|1975\nThug Boss|31|2075\nThe Unknown Warrior|31|50225\nSoldier|31|1500\nGladiator Diemos|13|600000\nGuardian of Diemos|13|1000\nPumpkin Buffer|40|25\nSmall Magma Golem|13|540\nInvading Copper Cog Knight|99|808\nBronze Statue of Thorsten Cragstone|63|245\nBronze Statue of a Zharalim|63|255\nBronze Statue of Ben Ten|63|235\nBronze Statue of a Sclavus|63|190\nShade of Lord Rytheran's Golem|13|430\nFiun Assistant|78|460\nBlighted Hoary Armoredillo|17|265\nTruffle Thrungus|82|218\nDire Champion Banderling|2|1110\nSubtle Simulacrum|59|154\nSimulacrum Doppelganger|59|3210\nAncient Luminary Knight|62|3500\nAncient Water Golem|13|8600\nAncient Aqueous Knight|62|3500\nAncient Sandstone Golem|13|9000\nObsidian Golem Noble|13|88000\nRage Wisp|20|18125\nAncient Mud Golem|13|8820\nAncient Tenebrous Knight|62|3500\nGaerlan|51|76000\nDire Champion Shadow|22|1955\nDire Champion Drudge|3|1500\nRynthid Minion of Rage|19|6175\nRift of Torment|19|10100\nDiscorporate Rynthid of Torment|19|100\nRynthid Crystal|-1|-1\nTormented Shadow|22|2380\nEnraged Shadow|22|2380\nRynthid Rager|19|12000\nRynthid Slayer|19|12000\nRynthid Sorcerer|19|7675\nRynthid Minion|19|6175\nEmpowered Hatred Wisp|20|20250\nRaging Rynthid Sorcerer|19|7675\nDiscorporate Rynthid of Rage|19|500\nLothus Guardian of Torment|19|20000\nDiscorporate Rynthid of Blind Rage|19|100\nRift of Blind Rage|19|10100\nCorrupt Minion of Rage|19|6175\nCorrupt Slayer|19|12250\nCorrupt Lugian|5|6770\nCorrupt Minion|19|6175\nCorrupt Rager|19|12250\nCorrupt Sorcerer|19|7675\nEmpowered Despair Wisp|20|20125\nRift of Rage|19|10100\nFiun Abayar|78|2080\nDire Champion Monouga|28|1800\nMaster of the Pack|16|125\nTwo Headed Snowman|39|70\nCorrupted Gravestone|-1|-1\nAbyssal Child|22|580\nWretched Child|22|2000\nPandemic Child|22|580\nFrozen Wight Archer|14|2200\nSnow Tuskie|8|2325\nZirconium Golem|13|61\nThe Guardian Spirit|40|115\nCave Penguin|80|900\nJibrit Zefir|29|25\nBanderling Raider Guardian|2|83\nBaron of Colier|14|113\nPile O' Bones|30|33\nAccursed Miner|30|33\nCursed Foreman|14|89\nLich Overseer|14|89\nDecaying Warrior|14|235\nBanderling Ogre|2|105\nMarionette|54|125\nSpectral Handmaiden|77|490\nVira al-Quain'ah's Spectre|77|870\nVira al-Quain'ah's Skeleton|30|920\nVira al-Quain'ah's Zombie|14|920\nGreat Cave Penguin|80|2700\nUndead Lieutenant|14|655\nFrigid Ice Golem|13|1810\nFrigid Mist Golem|13|2160\nBaby Penguin|80|30\nPenguin Guardian|80|4000\nCowardly Snowman|39|460\nTiny|80|38000\nPillar of Frost|62|2000\nSimulacrum Emulat|59|3330\nHollow Reaver|48|1800\nVirindi Fulguris|19|6375\nVirindi Signat|19|7175\nSimulacrum Shifter|59|26335\nElemental Protector|62|1700\nDuplicitous Simulacrum|59|494\nThe Crafter|59|845\nFrozen Crystal|-1|-1\nFrozen Dread|77|20000\nShadowy Pillar|-1|-1\nBanderling Leader|2|135\nSpectral Blade Master|77|2975\nClay Golem Samurai|13|5250\nSpectral Samurai|77|3750\nSpectral Nanjou Shou-jen|77|3175\nSpectral Bloodmage|77|5200\nSpectral Minion|77|2500\nSpectral Bushi|77|2850\nSpectral Claw Master|77|2975\nSpectral Archer|77|2200\nSpectral Claw Adept|77|2675\nSpectral Voidmage|77|5200\nIron Golem Samurai|13|5250\nBronze Golem Samurai|13|5250\nSarcophagus|-1|-1\nSpectral Blade Adept|77|2675\nClaw Master Gatekeeper|77|5175\nSamurai Gatekeeper|77|3750\nBushi Gatekeeper|77|2850\nBanished Lugian|5|590\nLesser Acolyte|14|175\nHigh Acolyte|14|175\nHeavy Drudge Prowler|3|50\nUndead Curator|14|53\nSclavus Guard|26|1110\nMoarsman Guard|34|1115\nDaimyo Idah|77|24750\nBlighted Sotiris Hollow Minion|48|130\nSimulacrum Mimic|59|4530\nRift of Consuming Torment|19|10100\nDiscorporate Rynthid of Consuming Torment|19|100\nAspect of Rage|19|150000\nRynthid Berserker|19|100000\nRynthid Ravager|19|100000\nSanctum Warding Crystal|-1|-1\nRaging Corrupt Sorcerer|19|7675\nCorrupt Bulwark|19|100200\nAspect of Avarice|19|320200\nDire Champion Virindi|19|1800\nAspect of Torment|19|150000\nEmpowered Sorrow Wisp|20|20150\nDesert Phyntos Swarm|9|1850\nDesert Cactus|-1|-1\nClay Golem Sekkou|13|4750\nBronze Golem Sekkou|13|4950\nIron Golem Sekkou|13|5250\nClay Golem Kachi|13|6250\nBronze Golem Kachi|13|7750\nIron Golem Kachi|13|12350\nSawato Bandit|31|600\nSpiked Grievver|44|185\nTumerok Champion Renegade|6|450\nGuardian of the Ritual|6|1650\nGotrok Ligias|70|1670\nRenegade Virindi|19|1625\nRenegade Adept Shaman|6|1650\nGotrok Ornost|70|1750\nGotrok Extias|70|1675\nRenegade Elite Trooper|6|4800\nThief|31|220\nBandit Mage|31|200\nBandit Lord|31|210\nAncient Mu-miyah|14|130\nEnsorcelled Weapon|77|4865\nTortured Servant|14|3540\nForge Guardian|14|9540\nTiatus Smithy|5|3760\nTiatus Overseer|5|11760\nZrikux|14|14878\nA'nekshay Temple Servant|101|3000\nA'nekshay|101|2610\nA'nekshay Temple Guardian|101|2610\nGrumpy Snowman|39|685\nOld Skeleton|30|838\nGurog Commander|100|395225\nCarpenter Wasp|9|25\nThieving Thrungus|82|15\nYoung Olthoi|1|40\nAdolescent Olthoi|1|40\nWight Sage|14|6120\nGeneral Tator'Klavuix|14|60250\nOrchard Slasher|1|2600\nParadox-touched Olthoi Portal Guard|92|20250\nTukora Sentinel|5|6950\nMu-miyah Kaymakam|14|14175\nA'nekshay Slave|101|2615\nA'nekshay Servant|101|2615\nMu-miyah Reporter|14|8200\nLord of the Two Lands|14|900000\nOrchard Slayer|1|2600\nNymph Maniac|1|2000\nOrchard Ripper|1|2900\nChampion of the Blood|30|1758\nDrudge Lootblade|3|6653\nDrudge Spellwink|3|3658\nDrudge Rumblefoot|3|8803\nDrudge Lifewhisk|3|3708\nDrudge Scampersnip|3|3816\nDrudge OG|3|690\nThe Peppermint Miser|3|295500\nKnee-Smasher|32|6000\nHead-Smasher|32|10000\nBoss-Smasher|32|25000\nVaeshok|14|7630\nTeth Wasp|9|8200\nTeth Skeleton|30|9699\nImperial Guard|14|1355\nImperial Archivist|14|1345\nCelestial Hand Scout|31|1000\nCaptain Donnarion|31|1415\nBenedino|31|2000\nTeth Golem|13|15250\nLugian Invader|5|41670\nTumerok Invader|6|62004\nRabid Bulldog|55|2650\nNesting Siraluun|56|3450\nRuuk Ranger|75|9375\nRuuk Soothsayer|75|10375\nGuruk Grunt|75|12206\nEnervating Rat|10|8001\nSanguinary Rat|10|8001\nCalamitous Rat|10|8001\nLugian Hunter Bandit|31|7260\nLugian Hunter Thug|31|6600\nLugian Hunter Mage|31|4500\nBandit Mana Hunter Boss|31|9510\nKnight of the Golden Flame|31|541001\nFreezing Wind|61|2780\nVelocifang|-1|12200\nTerraling|-1|25725\nRed Dragon|91|30470\nSir Galen|83|62000\nEvil Frosty|39|600220\nSilver Dragon|79|68200\nMegamaw|79|395225\nBlue Dragon|79|68200\nSummoned Master Mage|31|42625\nSummoned Master Archer|31|42625\nOlthoi Hive Eviscerator|1|6000\nVirindi Sentry|19|9075\nFilinuvekta Exalgrith|14|395225\nDamaged Glacial Golem|13|150\nCrazed Fiun|78|120\nBarbaric Ruschk|81|105\nRuschk Slayer|81|150\nRuschk Fiend|81|165\nMonouga Grunt|28|8500\nMonouga Barbarian|28|8500\nMonouga Controller|28|12725\nRiver Drudge|3|133\nFountain|-1|-1\nDRONE CAT|-1|90002000\nDemon Tusker|8|1150\nAggressive Penguin|80|30\nPenguin|80|30\nMorel Thrungus|82|34\nSpikey Armoredillo|17|38\nCrimini Thrungus|82|69\nSmall Fledgling Mukkir|89|88\nBrown Rat|10|30\nMosswart Mucker|4|75\nMad Star Marionette|54|43\nBronze Statue of a Mosswart|4|90\nBronze Statue of a Drudge|3|75\nBronze Statue of a Reedshark|16|70\nBronze Statue of a Gromnie|15|90\nOlthoi Swarm Harvester|1|175\nOlthoi Swarm Gardener|1|158\nCarnivorous Armoredillo|17|2740\nHollow Minion|48|110\nDranith Menacet|48|230\nBurun Ruuk Ruffian|75|280\nCursed Snake|17|930275\nGlassy Mayhem|71|11300\nOlthoi Shredder|1|723800\nSwarm Olthoi|1|1201800\nCaustic Olthoi Eviscerator|650|601800\nOlthoi Enforcer|92|99040\nSilenced Olthoi|92|7780\nInsatiable Olthoi|1|5100775\nNightHollow Blightspawn|1|1000004480\nVolatile Olthoi Egg|62|750095\nNightHollow Olthoi Queen|92|1000000384\nNightHollow Minion|1|293000\nNighthollow Archer|1|87200\nGeneral Garsh|70|8000\nJuvenile Lantern|88|15500\nLantern Golem|13|1550000\nLantern Guardian|21|9000000\nCoal Connoisseur|21|1000000704\nEngulfed Lantern|91|1990000\nLantern Assassin of Flames|31|12000300\nLord of the Lanterns|88|987138944\nIrritated Auroch|11|100\nOlthoi Overlord|1|90000704\nEaterous Butcher|79|5075500\nPickle Snek|17|930275\nSun Roasted Remoran|84|169500000\nTusker Slimeback|8|1100000\nMossy Hatchling|71|7751300\nDarktide Killer|31|80595\nDrudge Space Invader|3|2600000\nSun Baked Remoran|84|4041300\nMutated Carenzi|55|3961660\nHell Hornet|9|800700\nPocket Clay|13|6555985\nScrooge Penguin|13|1000250\nSand Remoran|84|4041300\nSlimy Badass Bones|30|42275\nAugmented Swarm Demon|1|3650\nOld Zombie|14|282\nBronze Statue of a Banderling|63|180\nBronze Statue of a Skeleton|63|210\nBronze Statue of a Golem|63|200\nBronze Statue of a Tumerok|63|250\nBronze Statue of a Shadow|63|620\nBronze Statue of a Grievver|63|538\nBronze Statue of a Virindi|63|175\nFloating Door|29|3331990\nBovine Wench|12|9400\nBovine Henchman|12|10400\nHell-Raised Cattle|12|2500800\nCorrosive Archer|77|3200\nHollow Pawn|48|3800\nVirindi Rival|19|7175\nLugian Launcher|5|21670\nTorment Wisp|20|29325\nTracking Fireball|62|1080\nVicious Remoran Sapper|84|11775\nPike Grievver|44|19750\nGrievver Darter|44|4750\nVibrant Shadow|22|9675\nMukkir Predator|89|12980\nCrazed Olthoi|1|22000\nTusker Heaver|8|3325\nDefensive Crystal|47|51045\nTundra Tusker|8|172725\nStinging Armoredillo|17|52390\nBlade Lieutenant|99|53000\nBlade Captain|99|125000\nTumerok Savage|6|82000\nBlade Champion|99|325000\nPyro Capped Thrungus|82|2923\nCaustic Thrungus|82|2923\nGlacial Spored Thrungus|82|2923\nNetherborne Olthoi Warrior|1|25001710\nNetherborne Olthoi Queen|1|50001712\nDefinitely a Well Inspector|31|666000\nHebian-To Sewer Rat|10|89900\nAugmented Eviscerator|1|3390\nTusker Menace|8|965\nVirindi Crossbowman|19|200625\nNighthollow Dart Chucker|6|87200\nNighthollow Hornet|9|1600000\nNighthollow Hornet Swarm|55|3961660\nNighthollow Ironfist|92|5108090\nNighthollow Margul|71|1776000\nNighthollow Murder Hornet|55|3961660\nNighthollow Olthoi Overlord|92|1760000\nEnraged Stomper|8|3015\nNewborn Virindi Inquisitor|19|800100\nVirindi Guardian|19|200625\nNighthollow Swarm Olthoi|1|1201800\nPIS|71|1776000\nFrozen Beast|61|500450\nThe Forgotten One|14|1504500\nRotting Corpse|78|23000500\nDire Carenzi|55|750000\nAncient Oak|13|3000750\nMossy Dragon|71|7751300\nPenumbral Shadowmage|22|1600\nRynthid Cow|12|3420\nDark Inferno|22|620\nSwamp Phyntos Wasp|9|1210\nRemoran Sapper|84|1200\nFierce Remoran Sapper|84|1615\nDrudge Wilter|3|2500\nChill|61|70\nUnstable Glacial Golem|13|150\nFrozen Cow|12|3420\nTiny Tim|100|200245\nChrysoberyl Cow|12|3420\nSpectral Divinity|77|500200\nShadow Cow|12|3420\nPixie of Pain|22|10660\nSnowy Mattie|23|38\nVicious Scarecrow|49|289\nVile Scarecrow|49|240\nVillainous Scarecrow|49|310\nSam|39|650\nScold|13|5000\nScold Chunk|13|1250\nScold Lump|13|625\nBaron Nuvillus|30|400\nVorous Shrethlet|32|40\nContained Rift|19|100\nDemented Zharalim|31|220\nCrazed Zharalim|31|220\nEmerald Gromnie|15|600\nAmethyst Gromnie|15|600\nSapphire Gromnie|15|600\nRuby Gromnie|15|600\nLeet Darktide Wizard|31|80000\nLeet Darktide Killer|31|800000\nElite Mercenary|31|20000200\nOaken Guardian|62|20200\nViridian Mite|7|600250\nBrier Wasp|9|8200\nPoisonous Brier Wasp|9|8250\nBrier Wasp Swarm|9|10200\nZefir Thorn Stalker|29|6200\nVermilion War Gromnie|15|15200\nVermilion Thorn Gromnie|15|8200\nA'nekshen Thorn Reaver|101|8200\nA'nekshen Thorn Dancer|101|8200\nA'nekshen Storm Reaver|101|8200\nVenomous Brier Wasp|9|8200\nZefir Thorn Ranger|29|6200\nEmerald Thorn Gromnie|15|8200\nSath'tik Tentacle|36|810\nSath'tik Eyestalk|36|1230\nSath'tik Tendril|36|810\nA'nekshen Storm Caller|101|8200\nGuardian Wisp|20|20200\nZefir Thorn Reaver|29|6200\nEmerald Hunting Gromnie|15|8200\nZefir Thorn Poisoner|29|6200\nCorrupted Guardian Wisp|20|20200\nA'nekshen Corrupt Storm Reaver|101|8200\nCorrupting Thorn Gromnie|15|8200\nA'nekshen Corrupt Thorn Reaver|101|8200\nA'nekshen Storm Corruptor|101|8200\nA'nekshen Thorn Corruptor|101|8200\nBrier Wasp Hive|9|-1\nCorrupted War Gromnie|15|15200\nZerzelikyr|15|200400\nWind Fury|101|80200\nNorshuntyr|62|200200\nNightBrier|101|80200\nTrained Attack Eater|79|30000\nBattle Hardend Archer|83|25325\nBattle Hardend Void Mage|83|30450\nBattle Hardend War Mage|83|30450\nDemented Fiun|78|235\nWall|-1|-1\nDrudge Balloon|3|603\nMitey Knight|7|28850\nFrost Maw|8|9105\nUnhappy Snowman|39|28850\nStrawberry Jam Golem|91|1682225\nDissolved Limb|36|1002630\nAcidic Crystal Mist|13|6555985\nAcidic Crystal|13|6555985\nPainful Conflagration|62|1000580\nToxic Moar|86|90002000\nThe Mist|20|10000700\nAcidic Crystal Lord|88|987138944\nLeet Darktide Archer|31|800\nRepulsive Olthoi|1|15500\nAbnormal Slug|1|15500\nFetid Olthoi|1|20000\nOlthoi Parasite|1|20000\nNighthollow Tumerok Headhunter|6|87200\nEgghead|82|4790300\nWinning Idol|50|16639655\nHoney Bee|9|28850\nA'nekshay Dave|101|450000\nVermis Shreth|-1|-1\nLugianator|5|46800\nBael'Zharon, The Hopeslayer|52|966666752\nThe True Bael'Zharon, The Hopeslayer|52|966666752\nGiant Phyntos Hive|9|-1\nGiant Phyntos Swarm|9|435\nGiant Phyntos Wasp|9|378\nElite Savage Carenzi|55|1280\nRyoga Kuroga|13|20270\nTumerok Heel Nipper|16|7010\nTumerok Sharpshooter|6|85910\nReedshark Ripper|16|7128010\nTumerokian Bowmans|31|800\nTumerokian Shaman|31|823\nTumerok Bruiser|6|95485\nTumerok Rager|6|2600535\nTumertoes|4|90002000\nTumerokian Blademaster|31|800000\nCopper Cog Trooper|99|325\nSilver Scope Trooper|99|325\nGold Gear Trooper|99|325\nBronze Gauntlet Trooper|99|325\nIron Blade Trooper|99|325\nSilver Scope Lesser Lord|99|460\nIron Blade Guardian|99|365\nCopper Cog Guardian|99|365\nBronze Gauntlet Guardian|99|365\nGold Gear Guardian|99|365\nSilver Scope Guardian|99|365\nGold Gear Lesser Lord|99|460\nIron Blade Lesser Lord|99|460\nBronze Gauntlet Lesser Lord|99|460\nCopper Cog Lesser Lord|-1|460\nSand Cow|12|3420\nAdamantine Golem|13|500500\nWithered Banderling Leader|2|15170\nCave Ursuin|46|360\nGrave Spirit|14|490\nFazenda Terror|46|1005\nDrudge Biter|3|674\nKernel Klank|3|10100\nCaptain Burnja|3|10000\nBonecrunch|3|30000\nCrystallius Rex|13|9500500\nDire Champion Skeleton|30|1552\nKing Carnivorous|17|50290\nDiamond Golem Invader|13|20000\nPlunderers of the Bloodstone|14|90000\nParfal Niffling|45|17\nAncient Platinum Golem|13|100640\nElemental Mage|31|100105\nMassive Muck Golem|91|1000048\nInner Sea Golem|13|1000660\nMassive Avalanche|62|1000580\nHungry Corpse|78|3000060\nMarsh Champion|56|315\nTidal Champion|56|425\nLittoral Champion|56|380\nStrand Champion|56|725\nTimber Champion|56|620\nKithless Champion|56|850\nUntamed Champion|56|960\nBadlands Champion|56|2168\nRoyal Swamp Gromnie|15|225\nRoyal Ivory Gromnie|15|195\nRoyal Azure Gromnie|15|183\nRoyal Jade Gromnie|15|198\nRoyal Ash Gromnie|15|350\nRoyal Sable Gromnie|15|700\nRoyal Ebon Gromnie|15|810\nRoyal Rust Gromnie|15|190\nRoyal Copper Gromnie|15|900\nRoyal Brass Gromnie|15|990\nElite Pouchling|55|175\nElite Mottled|55|1285\nElite Mangy|55|980\nElite Feral|55|770\nElite Carnivorous|55|770\nElite Rabid|55|665\nElite Stalker|55|560\nElite Burrower|55|445\nPolar Carenzi|55|60\nElite Polar|55|330\nElite Sentry|55|220\nBattle Hardend Soldier|83|30450\nSuspicious Rock|76|90335\nJust a Rock|60|6900335\nFalatacot Guard|14|2870\nFalatacot Raider|14|2610\nSclavus Patrol|26|1110\nSclavus Raider|26|820\nMoarsman Marauder|34|1270\nPatriarch's Executioner|14|10000\nFalatacot Patrol|14|3010\nFalatacot Marauder|14|2870\nSclavus Marauder|26|1110\nMoarsman Raider|34|800\nPatriarch's Champion|14|10000\nPatriarch's Elite Raider|14|10000\nPatriarch's Inquisitor|14|10000\nViamontian Archer|31|800\nViamontian Duelist-Mage|31|823\nClay|31|28\nUndead Cow|12|3420\nTranscendant Tumerok|6|5000\nBanderling Blade|2|105\nBanderling Bloodblade|2|130\nDrudge Hoarder|3|60\nLarge Silver Rat|10|90\nOversized Banderling Ogre|2|130\nMite Matron|7|100\nMosswart Overchief|4|110\nRavenous Mosswart|4|75\nGuardian of the Helm|14|95\nSycophantic Penguin|80|81\nRebellious Penguin|80|60\nRuschk Fledgemaster|81|130\nSmall Crackle|88|15500\nMaster of the Blade|31|900000000\nQuiddity Rift|19|370\nBaktak the Human Slayer|3|280\nOlthoi Guard|1|275\nOlthoi Advance Guard|1|410\nOlthoi Vanquisher|1|740\nMosswart Cynic|4|4275\nThunder Chicken|69|200000\nVery Mad Cow|12|10500\nFallen Rift|19|1600\nSinged Wretched|22|121350\nBurning Virindi Paradox|19|165000\nBurning Hellion|71|124888\nViamontian Blademaster|31|800000\nWut The|31|800000\nWarden of the Falatacot|51|10601950\nAncient Soul|14|950\nFalatacot Abbess|14|2160\nBiaka Mukkir|89|24305\nFalatacot Blood Prophetess|14|3010\nEhlyis Sleech|45|22235\nRoyal Mite Squire|7|200\nRoyal Mite Matron|7|215\nRoyal Mite Sentry|7|200\nMite Warrior Queen|7|260\nUrsuin Rug Alive|46|80\nDark Sarcophagus|68|25\nHard-Headed Skeleton|30|199\nDune Reaver|16|126\nOlthoi Hive Warrior|1|6400\nOlthoi Hive Piercer|1|6500\nVirindi Clandestine|19|10075\nOlthoi Hive Mutilator|1|4935\nOlthoi Hive Soldier|1|4750\nOlthoi Hive Guardian|1|54760\nOlthoi Hive Noble|-1|-1\nOlthoi Hive Brood|1|6030\nOlthoi Hive Queen|1|50000\nWade Boggs Viamontian Cousin|31|900000000\nViamontian Executioner|31|900000000\nStormin' Norman|31|900000000\nCultist High Priest|31|890\nCultist Cohort|31|1075\nRenselm|14|7000\nGeraine|31|200000\nBurnt Void Knight|22|96150\nIncendiary Guard|62|4130\nGalvanic Guard|62|4130\nMosswart Worshipper|4|820\nGlacial Guard|62|4130\nCaustic Guard|62|4130\nZharalim Assassin|31|250000\nThunderclasp|31|10000095\nAqueous Guard|62|4130\nFormless Shadow|22|1500\nTenebrous Guard|62|4130\nLuminary Guard|62|4130\nIce Crystal|47|3000\nAcid Crystal|47|3000\nFire Crystal|47|3000\nElectric Crystal|47|3000\nBurnt Pizza|62|120630\nPizza Grievver|44|180780\nGreen Pepper|21|799330\nBlack Olive|21|1029330\nPepperoni|21|793430\nPineapple|21|799330\nPizza Gromnie|15|205650\nPizza Tusker|8|3951000\nThe Pizzanator|13|10001450\nFester Isn't Fun|92|5108090\nDesert Corpse|14|588\nDecaying Mu-Miyah|14|8075\nNasty Brass Monkey|8|6400\nMosswart Assailant|4|8650\nBoreas|62|40000352\nZippity Zappy|31|8000023\nStatic Crystal|13|6555985\nGrand Master of Flames|31|12001200\nAncient Diamond Golem|13|560\nPoltergeist|77|550\nDaimyo Nobanuga|77|25000\nInvading Bronze Gauntlet Squire|99|720\nInvading Copper Cog Squire|99|720\nInvading Silver Scope Knight|99|808\nEnraged Maintenance Bot|99|50000400\nFrigid Drudge|3|10000608\nNumb Miner|5|10000120\nUpgraded Wall of Ice|-1|-1\nElite Ravager|55|8200\nTrue Hive Reaper|1|1802100\nTrue Hive Spineripper|1|2202300\nTrue Hive Harvester|1|1201850\nRenegade Commander Walanawa|6|5000\nRenegade Commander Kianar|6|5000\nBeefy Shadow Cow|12|32144920\nBeefy Rynthid Cow|12|22144920\nBeefy Frozen Cow|12|22144920\nBeefy Chrysoberyl Cow|12|22144920\nBeefy Undead Cow|12|22144920\nBeefy Sand Cow|12|22144920\nThe Beef|12|99990592\nInvading Iron Blade Commander|99|5208\nGear Hunter|59|1200\nGear Hunter Mage|59|890\nApostate Overseer|19|7500\nGeneral Tarkaris|59|1340\nSubverted Copper Cog Knight|99|808\nSubverted Iron Blade Knight|99|808\nSubverted Bronze Gauntlet Knight|99|808\nSubverted Silver Scope Knight|99|808\nApostate Virindi Executor|19|2875\nApostate Virindi Inquisitor|19|2875\nStockpile Guardian|99|808\nBright Aetherium Ore Stockpile|40|-1\nIron Blade Warmaster|99|7225\nApostate Rift Aggressor|19|1100\nApostate Grand Director|19|100000\nIron Blade Overseer|99|200251\nVirindi Preceptor|19|275\nChakron Flux Virindi Master|19|350\nChakron Flux Virindi Servant|19|350\nGurog Bruiser|100|5000\nMargul Roamer|71|1200\nFierce Margul Roamer|71|1210\nVicious Margul Roamer|71|3470\nRaging Moar|86|1420\nEnraged Moar|86|1420\nFierce Mukkir|89|2683\nVicious Mukkir|89|3688\nSeared Guard|30|283\nCharred Miner|30|753\nForeman Brelax|30|953\nLord Cambarth|30|953\nMaster of the Swamp|4|110\nTormented Patriarch|14|600\nVault Mistress Niktari Xsu|14|12000\nCrystal of the Dark Isle|47|200000\nSouth Armory Captain|77|20250\nEast Armory Captain|77|20250\nOccult Child|22|16100\nVicky|31|568896\nHe Who Lives Behind the Row|54|586916\nScavenger Ursuin Cub|46|25\nBurning Puppeteer|54|2000250\nBurning Biaka|71|194900\nWarden of the Haebrous|51|10601950\nEnchantment Proctor|62|2000\nArtifice Proctor|62|2000\nVerdancy Proctor|62|2000\nStrife Proctor|62|2000\nArtifex of the Elements|19|5000\nStasis|62|19800\nTempest|62|19800\nStrife|38|20000\nCorrosion|60|4700\nEssence of Enchantment|40|150000\nEssence of Verdancy|40|150000\nHand of Verdancy|60|23000\nEssence of Artifice|40|150000\nEssence of Strife|40|40000\nHarbinger|62|200000\nChild of Verdancy|62|10000\nChild of Enchantment|62|10000\nPillar of Lightning|62|2000\nChild of Strife|62|10000\nChild of Artifice|62|10000\nPillar of Acid|62|2000\nGummy Kitty|46|500000\nEmpyrean Handler|101|3851950\nIcy Winds|31|823\nTyrant Darkspire Golem|13|3481300\nButcherous Eater|79|1066600\nDarkspire Phyntos Swarm|9|1571425\nInvasive Hellfire Siraluun|56|921935\nTumerok Warmonger|6|5485650\nGuruk Hulk|75|625\nGuruk Gorefiend|75|750\nBurun Ruuk Shaman|75|460\nBurun Ruuk Savage|75|425";

	public static readonly DmgType[] El = new DmgType[7]
	{
		DmgType.Blade,
		DmgType.Pierce,
		DmgType.Bludgeon,
		DmgType.Acid,
		DmgType.Lightning,
		DmgType.Cold,
		DmgType.Fire
	};

	private static Dictionary<int, List<DmgType>> _species;

	private static Dictionary<string, List<DmgType>> _overrides;

	private static Dictionary<string, int> _cooldown;

	private static Dictionary<string, int[]> _members;

	private static Dictionary<string, double[]> _kits;

	private static readonly HashSet<string> VagueSpecies = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
	{
		"Unknown", "Food", "Target", "Wall", "Device", "Energy", "Harvest", "Touched", "Statue", "Elemental",
		"Human"
	};

	public static IEnumerable<KeyValuePair<string, int[]>> VtMembers
	{
		get
		{
			Load();
			return _members;
		}
	}

	public static IEnumerable<int> AllSpecies
	{
		get
		{
			Load();
			return _species.Keys;
		}
	}


	// ── VTank's game info (its gameinfodb, 2025-11-17): built in, and kept as a file you can change -
	// Profiles\Monsters\vtank_gameinfo.txt (written from the built-in copy the first time; read again when it changes) ──

	private static readonly string[] ElNames = new string[7] { "Slash", "Pierce", "Bludgeon", "Acid", "Lightning", "Cold", "Fire" };

	private static DateTime _fileTime = DateTime.MinValue;

	private static DateTime _checkAt = DateTime.MinValue;

	private static readonly object _loadLock = new object();

	/// <summary>Where the VTank game info file is.</summary>
	public static string DataFile => Util.FullPath(Path.Combine("Profiles", "Monsters", "vtank_gameinfo.txt"));

	/// <summary>What the last read of the file said (for the Monster DB tab).</summary>
	public static string DataNote = "";

	private static int ElIndex(string s)
	{
		s = (s ?? "").Trim();
		if (int.TryParse(s, out var n))
		{
			return n;
		}
		switch (s.ToLowerInvariant())
		{
		case "slash": case "slashing": case "blade": return 0;
		case "pierce": case "piercing": return 1;
		case "bludgeon": case "bludgeoning": case "blunt": return 2;
		case "acid": return 3;
		case "lightning": case "electric": return 4;
		case "cold": case "frost": return 5;
		case "fire": case "flame": return 6;
		}
		return -1;
	}

	private static List<DmgType> Rank(string s)
	{
		List<DmgType> list = new List<DmgType>();
		string[] array = s.Split(',');
		foreach (string s2 in array)
		{
			int result = ElIndex(s2);
			if (result >= 0 && result < El.Length && !list.Contains(El[result]))
			{
				list.Add(El[result]);
			}
		}
		return list;
	}

	private static string RankText(List<DmgType> r)
	{
		List<string> list = new List<string>();
		foreach (DmgType item in r)
		{
			int num = Array.IndexOf(El, item);
			if (num >= 0)
			{
				list.Add(ElNames[num]);
			}
		}
		return string.Join(", ", list.ToArray());
	}

	private static double[] Kit(string s)
	{
		string[] array = s.Split(',');
		double[] array2 = new double[3];
		for (int i = 0; i < 3 && i < array.Length; i++)
		{
			double.TryParse(array[i].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out array2[i]);
		}
		return array2;
	}

	private static void Load()
	{
		if (_species != null)
		{
			// (the file looked at again now and then: a change to it is picked up while playing)
			if (DateTime.Now < _checkAt)
			{
				return;
			}
			_checkAt = DateTime.Now.AddSeconds(10.0);
			try
			{
				if (!File.Exists(DataFile) || File.GetLastWriteTimeUtc(DataFile) == _fileTime)
				{
					return;
				}
			}
			catch
			{
				return;
			}
		}
		lock (_loadLock)
		{
			Dictionary<int, List<DmgType>> species = new Dictionary<int, List<DmgType>>();
			Dictionary<string, List<DmgType>> overrides = new Dictionary<string, List<DmgType>>(StringComparer.OrdinalIgnoreCase);
			Dictionary<string, int> cooldown = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
			Dictionary<string, double[]> kits = new Dictionary<string, double[]>(StringComparer.OrdinalIgnoreCase);
			Dictionary<string, int[]> members = new Dictionary<string, int[]>(StringComparer.OrdinalIgnoreCase);
			// the built-in copy first: anything the file doesn't have a section for comes from it
			foreach (string text in SpeciesData.Split(';'))
			{
				int num = text.IndexOf('=');
				if (num > 0 && int.TryParse(text.Substring(0, num), out var result))
				{
					species[result] = Rank(text.Substring(num + 1));
				}
			}
			foreach (string text2 in OverrideData.Split('|'))
			{
				int num2 = text2.LastIndexOf('=');
				if (num2 > 0)
				{
					overrides[text2.Substring(0, num2)] = Rank(text2.Substring(num2 + 1));
				}
			}
			foreach (string text3 in CooldownData.Split('|'))
			{
				int num3 = text3.LastIndexOf('=');
				if (num3 > 0 && int.TryParse(text3.Substring(num3 + 1), out var result2))
				{
					cooldown[text3.Substring(0, num3)] = result2;
				}
			}
			foreach (string text4 in HealKitData.Split('|'))
			{
				int num4 = text4.LastIndexOf('=');
				if (num4 > 0)
				{
					kits[text4.Substring(0, num4)] = Kit(text4.Substring(num4 + 1));
				}
			}
			foreach (string text5 in MemberData.Split('\n'))
			{
				string[] array = text5.Split('|');
				if (array.Length == 3 && int.TryParse(array[1], out var result3) && int.TryParse(array[2], out var result4))
				{
					members[array[0]] = new int[2] { result3, result4 };
				}
			}
			string dataFile = DataFile;
			try
			{
				if (File.Exists(dataFile))
				{
					_fileTime = File.GetLastWriteTimeUtc(dataFile);
					ReadFile(dataFile, species, overrides, cooldown, kits, members);
				}
				else
				{
					WriteFile(dataFile, species, overrides, cooldown, kits, members);
					_fileTime = File.GetLastWriteTimeUtc(dataFile);
					DataNote = "Written from the built-in copy (" + DateTime.Now.ToString("HH:mm") + ")";
				}
			}
			catch (Exception ex)
			{
				DataNote = "Couldn't read it - using the built-in copy: " + ex.Message;
				Util.LogError(ex);
			}
			_overrides = overrides;
			_cooldown = cooldown;
			_kits = kits;
			_members = members;
			_species = species;
		}
	}

	/// <summary>The file's sections replace the built-in ones they name ([species], [overrides], [monsters], [cooldowns],
	/// [healkits]): a section left out keeps the built-in data.</summary>
	private static void ReadFile(string path, Dictionary<int, List<DmgType>> species, Dictionary<string, List<DmgType>> overrides,
		Dictionary<string, int> cooldown, Dictionary<string, double[]> kits, Dictionary<string, int[]> members)
	{
		string section = "";
		int lines = 0, bad = 0;
		HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		foreach (string raw in File.ReadAllLines(path))
		{
			string line = raw;
			// (a comment: a line starting with #, or " #" after the value)
			int c = line.IndexOf(" #", StringComparison.Ordinal);
			if (c >= 0)
			{
				line = line.Substring(0, c);
			}
			line = line.Trim();
			if (line.Length == 0 || line.StartsWith("#", StringComparison.Ordinal))
			{
				continue;
			}
			if (line.StartsWith("[", StringComparison.Ordinal) && line.EndsWith("]", StringComparison.Ordinal))
			{
				section = line.Substring(1, line.Length - 2).Trim().ToLowerInvariant();
				if (seen.Add(section))
				{
					// (this section is the file's: the built-in one goes)
					switch (section)
					{
					case "species": species.Clear(); break;
					case "overrides": overrides.Clear(); break;
					case "cooldowns": cooldown.Clear(); break;
					case "healkits": kits.Clear(); break;
					case "monsters": members.Clear(); break;
					}
				}
				continue;
			}
			lines++;
			bool ok = false;
			switch (section)
			{
			case "species":
			{
				int num = line.IndexOf('=');
				if (num > 0 && int.TryParse(line.Substring(0, num).Trim(), out var result))
				{
					species[result] = Rank(line.Substring(num + 1));
					ok = true;
				}
				break;
			}
			case "overrides":
			{
				int num2 = line.LastIndexOf('=');
				if (num2 > 0)
				{
					overrides[line.Substring(0, num2).Trim()] = Rank(line.Substring(num2 + 1));
					ok = true;
				}
				break;
			}
			case "cooldowns":
			{
				int num3 = line.LastIndexOf('=');
				if (num3 > 0 && int.TryParse(line.Substring(num3 + 1).Trim(), out var result2))
				{
					cooldown[line.Substring(0, num3).Trim()] = result2;
					ok = true;
				}
				break;
			}
			case "healkits":
			{
				int num4 = line.LastIndexOf('=');
				if (num4 > 0)
				{
					kits[line.Substring(0, num4).Trim()] = Kit(line.Substring(num4 + 1));
					ok = true;
				}
				break;
			}
			case "monsters":
			{
				string[] array = line.Split('|');
				if (array.Length == 3 && int.TryParse(array[1].Trim(), out var result3) && int.TryParse(array[2].Trim(), out var result4))
				{
					members[array[0].Trim()] = new int[2] { result3, result4 };
					ok = true;
				}
				break;
			}
			}
			if (!ok)
			{
				bad++;
			}
		}
		DataNote = "Read " + DateTime.Now.ToString("HH:mm") + ": " + lines + " lines" + ((bad > 0) ? (", " + bad + " not understood (skipped)") : "");
	}

	private static void WriteFile(string path, Dictionary<int, List<DmgType>> species, Dictionary<string, List<DmgType>> overrides,
		Dictionary<string, int> cooldown, Dictionary<string, double[]> kits, Dictionary<string, int[]> members)
	{
		List<string> list = new List<string>
		{
			"# VTank's game info for MelkTank - from VTank's gameinfodb (2025-11-17). Change it as you like: MelkTank reads it again",
			"# within a few seconds of it being saved. Your own Monster DB entries (Settings\\MelkTank_MonsterDb.txt) still win over it.",
			"# A section left out (or this whole file deleted) falls back to MelkTank's built-in copy; a deleted file is written again.",
			"# Damage types: Slash, Pierce, Bludgeon, Acid, Lightning, Cold, Fire - an order is best first.",
			"# '#' starts a comment (at the start of a line, or after a space).",
			"",
			"[species]",
			"# species number = damage order",
		};
		List<int> keys = new List<int>(species.Keys);
		keys.Sort();
		foreach (int item in keys)
		{
			string name = "";
			try
			{
				name = MonsterMatch.SpeciesName(item) ?? "";
			}
			catch
			{
			}
			list.Add(item + " = " + RankText(species[item]) + ((name.Length > 0) ? (" # " + name) : ""));
		}
		list.Add("");
		list.Add("[overrides]");
		list.Add("# a monster with its own damage order (not its species')");
		foreach (KeyValuePair<string, List<DmgType>> item2 in overrides)
		{
			list.Add(item2.Key + " = " + RankText(item2.Value));
		}
		list.Add("");
		list.Add("[monsters]");
		list.Add("# name | species number | max health");
		List<string> names = new List<string>(members.Keys);
		names.Sort(StringComparer.OrdinalIgnoreCase);
		foreach (string item3 in names)
		{
			list.Add(item3 + " | " + members[item3][0] + " | " + members[item3][1]);
		}
		list.Add("");
		list.Add("[cooldowns]");
		list.Add("# item = its shared cooldown");
		foreach (KeyValuePair<string, int> item4 in cooldown)
		{
			list.Add(item4.Key + " = " + item4.Value);
		}
		list.Add("");
		list.Add("[healkits]");
		list.Add("# kit = bonus, uses (0: unlimited), kind");
		foreach (KeyValuePair<string, double[]> item5 in kits)
		{
			list.Add(item5.Key + " = " + string.Join(",", Array.ConvertAll(item5.Value, (double d) => d.ToString(CultureInfo.InvariantCulture))));
		}
		Directory.CreateDirectory(Path.GetDirectoryName(path));
		File.WriteAllLines(path, list.ToArray());
	}

	public static List<DmgType> Ranking(WorldObject o)
	{
		if (o == null)
		{
			return new List<DmgType>();
		}
		return Ranking(o.Name, Species(o));
	}

	public static List<DmgType> Ranking(string name, int species)
	{
		Load();
		MonsterDb.Entry entry = MonsterDb.Get(name);
		if (entry != null && entry.Ranking.Count > 0)
		{
			return entry.Ranking;
		}
		if (_overrides.TryGetValue(name ?? "", out var value) && value.Count > 0)
		{
			return value;
		}
		if (_species.TryGetValue(species, out value) && value.Count > 0)
		{
			return value;
		}
		value = MonsterDb.SpeciesRanking(species);
		return value ?? new List<DmgType>();
	}

	public static List<DmgType> PetRanking(WorldObject o)
	{
		return Ranking(o);
	}

	public static List<DmgType> SpeciesRanking(int species)
	{
		Load();
		List<DmgType> value = MonsterDb.SpeciesRanking(species);
		if (value != null && value.Count > 0)
		{
			return value;
		}
		return _species.TryGetValue(species, out value) ? value : new List<DmgType>();
	}

	public static List<DmgType> VtSpeciesRanking(int species)
	{
		Load();
		List<DmgType> value;
		return _species.TryGetValue(species, out value) ? value : new List<DmgType>();
	}

	public static List<DmgType> VtOverride(string name)
	{
		Load();
		List<DmgType> value;
		return _overrides.TryGetValue(name ?? "", out value) ? value : null;
	}

	public static int VtSpecies(string name)
	{
		Load();
		int[] value;
		return _members.TryGetValue(name ?? "", out value) ? value[0] : 0;
	}

	public static int VtMaxHealth(string name)
	{
		Load();
		int[] value;
		return _members.TryGetValue(name ?? "", out value) ? value[1] : 0;
	}

	public static int Species(WorldObject o)
	{
		Load();
		int num = 0;
		MonsterDb.Entry entry = MonsterDb.Get(o.Name);
		if (entry != null && entry.SpeciesEdited && entry.Species > 0)
		{
			return entry.Species;
		}
		try
		{
			num = o.Values(LongValueKey.Species);
		}
		catch
		{
		}
		if (num <= 0 && entry != null)
		{
			num = entry.Species;
		}
		if (num <= 0 && _members.TryGetValue(o.Name ?? "", out var value))
		{
			num = value[0];
		}
		if (num <= 0)
		{
			num = SpeciesByName(o.Name);
		}
		return num;
	}

	public static int SpeciesByName(string name)
	{
		Load();
		string text = (name ?? "").Trim();
		if (text.Length == 0)
		{
			return 0;
		}
		List<string> list = new List<string>(text.Split(new char[1] { ' ' }, StringSplitOptions.RemoveEmptyEntries));
		for (int num = list.Count; num >= 2; num--)
		{
			string text2 = string.Join(" ", list.GetRange(0, num).ToArray());
			MonsterDb.Entry entry = MonsterDb.Get(text2);
			if (entry != null && entry.Species > 0)
			{
				return entry.Species;
			}
			if (_members.TryGetValue(text2, out var value) && value[0] > 0)
			{
				return value[0];
			}
		}
		int result = 0;
		int num2 = 0;
		for (int i = 0; i < list.Count; i++)
		{
			for (int j = 1; j <= 2 && i + j <= list.Count; j++)
			{
				string text3 = string.Join("", list.GetRange(i, j).ToArray()).Trim(new char[3] { '\'', ',', '.' });
				string[] array = new string[2]
				{
					text3,
					text3.EndsWith("s") ? text3.Substring(0, text3.Length - 1) : text3
				};
				foreach (string text4 in array)
				{
					int num3 = MonsterMatch.SpeciesId(text4);
					if (num3 > 0 && !VagueSpecies.Contains(text4) && text4.Length > num2)
					{
						result = num3;
						num2 = text4.Length;
					}
				}
			}
		}
		return result;
	}

	public static int MaxHealth(string name)
	{
		Load();
		MonsterDb.Entry entry = MonsterDb.Get(name);
		if (entry != null && entry.MaxHp > 0)
		{
			return entry.MaxHp;
		}
		int[] value;
		return (_members.TryGetValue(name ?? "", out value) && value[1] > 0) ? value[1] : (-1);
	}

	public static int CooldownGroup(string name)
	{
		Load();
		int value;
		return _cooldown.TryGetValue(name ?? "", out value) ? value : 0;
	}

	public static double KitRestore(string name)
	{
		Load();
		double[] value;
		return _kits.TryGetValue(name ?? "", out value) ? value[0] : 0.0;
	}

	public static int KitSkill(string name)
	{
		Load();
		double[] value;
		return _kits.TryGetValue(name ?? "", out value) ? ((int)value[1]) : 0;
	}
}
