using Decal.Adapter;
using Decal.Adapter.Wrappers;

namespace MelkTank;

public static class Globals
{
	public const string PluginName = "MelkTank";

	public static PluginHost Host { get; private set; }

	public static CoreManager Core { get; private set; }

	public static void Init(PluginHost host, CoreManager core)
	{
		Host = host;
		Core = core;
	}
}
