using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Numerics;
using Decal.Adapter;
using ImGuiNET;

namespace MelkTank;

internal static class WinMem
{
	private static Dictionary<string, float[]> _saved;

	private static readonly HashSet<string> _restored = new HashSet<string>();

	private static DateTime _dirtySince = DateTime.MinValue;

	private static string _char;

	private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

	/// <summary>The character is known: positions are kept per character. Another character logged in (same game
	/// session, or a plugin that stays loaded across logins): the last one's are saved and this one's put back.</summary>
	public static bool Ready
	{
		get
		{
			string text = "";
			try
			{
				text = CoreManager.Current.CharacterFilter.Name ?? "";
			}
			catch
			{
			}
			if (text.Length == 0)
			{
				return _char != null;   // (between characters: the last one's, until the next is in)
			}
			if (text != _lastName)
			{
				_lastName = text;
				char[] invalidFileNameChars = Path.GetInvalidFileNameChars();
				foreach (char oldChar in invalidFileNameChars)
				{
					text = text.Replace(oldChar, '_');
				}
				text = text.Replace(' ', '_');
				if (_char != null && text != _char)
				{
					if (_dirtySince != DateTime.MinValue && _saved != null)
					{
						Save();
					}
					_saved = null;
					_restored.Clear();
				}
				_char = text;
			}
			return true;
		}
	}

	private static string _lastName;

	/// <summary>This character has a place kept for the window.</summary>
	public static bool Has(string name)
	{
		Load();
		return _saved != null && _saved.ContainsKey(name);
	}

	private static string FilePath => Util.FullPath("MelkTank_Windows_" + _char + ".txt");

	private static void Load()
	{
		if (!Ready || _saved != null)
		{
			return;
		}
		_saved = new Dictionary<string, float[]>(StringComparer.Ordinal);
		try
		{
			if (!File.Exists(FilePath))
			{
				return;
			}
			string[] array = File.ReadAllLines(FilePath);
			foreach (string text in array)
			{
				string[] array2 = text.Split('|');
				if (array2.Length == 5)
				{
					float[] array3 = new float[4];
					bool flag = true;
					for (int j = 0; j < 4; j++)
					{
						flag &= float.TryParse(array2[j + 1], NumberStyles.Float, Inv, out array3[j]);
					}
					if (flag)
					{
						_saved[array2[0]] = array3;
					}
				}
			}
		}
		catch
		{
		}
	}

	public static void Frame(string name, bool size = true)
	{
		try
		{
			Load();
			if (_saved == null)
			{
				return;
			}
			if (_restored.Add(name) && _saved.TryGetValue(name, out var value))
			{
				ImGui.SetWindowPos(new Vector2(value[0], value[1]), ImGuiCond.Always);
				if (size && value[2] > 50f && value[3] > 30f)
				{
					ImGui.SetWindowSize(new Vector2(value[2], value[3]), ImGuiCond.Always);
				}
				return;
			}
			Vector2 windowPos = ImGui.GetWindowPos();
			Vector2 windowSize = ImGui.GetWindowSize();
			float[] array = new float[4] { windowPos.X, windowPos.Y, windowSize.X, windowSize.Y };
			if (!_saved.TryGetValue(name, out value) || Math.Abs(value[0] - array[0]) > 0.5f || Math.Abs(value[1] - array[1]) > 0.5f || Math.Abs(value[2] - array[2]) > 0.5f || Math.Abs(value[3] - array[3]) > 0.5f)
			{
				_saved[name] = array;
				_dirtySince = DateTime.Now;
			}
			if (_dirtySince != DateTime.MinValue && (DateTime.Now - _dirtySince).TotalSeconds > 1.5)
			{
				Save();
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void Save()
	{
		_dirtySince = DateTime.MinValue;
		try
		{
			List<string> list = new List<string>();
			foreach (KeyValuePair<string, float[]> item in _saved)
			{
				list.Add(item.Key + "|" + string.Join("|", Array.ConvertAll(item.Value, (float f) => f.ToString(Inv))));
			}
			string text = FilePath + ".tmp";
			File.WriteAllLines(text, list.ToArray());
			if (File.Exists(FilePath))
			{
				File.Delete(FilePath);
			}
			File.Move(text, FilePath);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}
}
