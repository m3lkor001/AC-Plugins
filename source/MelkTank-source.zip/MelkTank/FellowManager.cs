using System;
using System.Collections.Generic;
using System.Numerics;
using System.Text.RegularExpressions;
#if !RETAIL
using AcClient;
#endif
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Loot;

namespace MelkTank;

public static class FellowManager
{
	public class Fship
	{
		public string Name;

		public string Leader;
	}

	private class Vote
	{
		public int Id;

		public string Type;

		public string Param;

		public string Caller;

		public DateTime Ends;

		public Dictionary<string, bool> Votes = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
	}

	public const int MaxMembers = int.MaxValue;

	private static Settings _s;

	private static readonly Regex TellRx = new Regex("^(?<n>.+?) tells you, \"(?<m>.*)\"\\s*$");

	private static readonly Dictionary<string, DateTime> _tried = new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);

	private static DateTime _nextScan = DateTime.MinValue;

	private static DateTime _nextLandblock = DateTime.MinValue;

	private static DateTime _nextCreate = DateTime.MinValue;

	private static readonly List<string> _log = new List<string>();

	private static bool _wasIn;

	private static bool _iMadeIt;

	private static DateTime _openAt = DateTime.MinValue;

	private static int _reStep;

	private static DateTime _reAt = DateTime.MinValue;

	private static DateTime _reStarted = DateTime.MinValue;

	private static readonly List<string> _reNames = new List<string>();

	private static string _reName = "";

	private static readonly List<Fship> _list = new List<Fship>();

	private static DateTime _listAt = DateTime.MinValue;

	private static DateTime _listUntil = DateTime.MinValue;

	private static DateTime _listAsked = DateTime.MinValue;

	private static readonly Regex ListRx = new Regex("^'(?<f>.*)'\\s+led by\\s+(?<l>.+?)\\s*$");

	private static bool _joining;

	private static bool _joinWaitList;

	private static string _joinLeader;

	private static DateTime _joinAt;

	private static readonly HashSet<string> _joinTried = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

	private static readonly Regex RefuseRx = new Regex("full|lock|closed|not (?:taking|accepting|recruiting)|no room|private|sorry", RegexOptions.IgnoreCase);

	private static readonly Regex TagRx = new Regex("<Tell:[^>]*>(.*?)<\\\\Tell>");

	private const string Tag = "[MT Fellow Manager] ";

	private static readonly Regex CmdTellRx = new Regex("^(?<n>.+?) tells you, \"(?<m>.*)\"\\s*$");

	private static readonly List<Vote> _votes = new List<Vote>();

	private static int _voteId;

	private static readonly Dictionary<string, DateTime> _voteCalled = new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);

	private const double VoteSecs = 120.0;

	private const double VoteCooldownSecs = 180.0;

	private const double AddWaitSecs = 60.0;

	private static readonly List<string> _waiting = new List<string>();

	private static string _spotFor;

	private static DateTime _spotUntil = DateTime.MinValue;

	private static readonly string[] VoteTypes = new string[4] { "kick", "ban", "giveleader", "setopen" };

	public static Action SaveAll;

	public static Func<int> CurrentTier;

	private static bool On => _s != null && _s.MasterEnabled;

	private static bool Full => CorpseKillers.FellowCount + 1 >= int.MaxValue;

	private static string Me
	{
		get
		{
			try
			{
				return CoreManager.Current.CharacterFilter.Name ?? "";
			}
			catch
			{
				return "";
			}
		}
	}

	private static int MyId
	{
		get
		{
			try
			{
				return CoreManager.Current.CharacterFilter.Id;
			}
			catch
			{
				return 0;
			}
		}
	}

	public static bool IsLeader
	{
		get
		{
			if (!CorpseKillers.InFellow)
			{
				return false;
			}
			int leaderId = CorpseKillers.LeaderId;
			return (leaderId != 0) ? (leaderId == MyId) : (_iMadeIt || CorpseKillers.FellowCount == 0);
		}
	}

	public static void Init(Settings s)
	{
		_s = s;
	}

	public static bool SetOpen(bool open)
	{
		try
		{
			CM_Fellowship.Event_ChangeFellowOpeness(open ? 1 : 0);
			return true;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			return false;
		}
	}

	private static void RecreateTick()
	{
		if (!_s.FellowRelock)
		{
			_reStep = 0;
		}
		else
		{
			if (DateTime.Now < _reAt)
			{
				return;
			}
			switch (_reStep)
			{
			case 0:
				if (CorpseKillers.InFellow && CorpseKillers.Locked == true && IsLeader)
				{
					_reNames.Clear();
					_reNames.AddRange(CorpseKillers.Fellows);
					_reName = (_s.FellowName ?? "").Trim();
					if (_reName.Length == 0)
					{
						_reName = Me + "'s Fellowship";
					}
					Util.WriteToChat("Fellowship: locked by a quest - making it again and inviting " + _reNames.Count + " back.");
					Note("locked - disbanding to make it again");
					Util.Command("/fship disband");
					_reStep = 1;
					_reAt = DateTime.Now.AddSeconds(3.0);
					_reStarted = DateTime.Now;
				}
				break;
			case 1:
				if (CorpseKillers.InFellow)
				{
					_reAt = DateTime.Now.AddSeconds(2.0);
					if ((DateTime.Now - _reStarted).TotalSeconds > 20.0)
					{
						_reStep = 0;
						_reAt = DateTime.Now.AddSeconds(60.0);
						Note("the disband didn't go through");
					}
				}
				else
				{
					Util.Command("/fship create " + _reName);
					_reStep = 2;
					_reAt = DateTime.Now.AddSeconds(3.0);
				}
				break;
			case 2:
				if (!CorpseKillers.InFellow)
				{
					_reStep = 0;
					Note("couldn't make it again");
					break;
				}
				if (_s.FellowOpenOnCreate)
				{
					SetOpen(open: true);
				}
				foreach (string reName in _reNames)
				{
					_tried.Remove(reName);
					Util.Command("/fship add " + reName);
				}
				Note("made it again - invited " + _reNames.Count + " back");
				_reStep = 0;
				_reAt = DateTime.Now.AddSeconds(30.0);
				break;
			}
		}
	}

	public static void LoggedIn()
	{
		CorpseKillers.ClearFellow();
		_tried.Clear();
		_list.Clear();
		_listAt = DateTime.MinValue;
		_joining = false;
		_nextLandblock = DateTime.Now.AddSeconds(30.0);
		_nextCreate = DateTime.Now.AddSeconds(20.0);
	}

	private static bool Ignored(string name)
	{
		string[] array = (_s.FellowIgnore ?? "").Split(',');
		foreach (string text in array)
		{
			if (text.Trim().Length > 0 && string.Equals(text.Trim(), name, StringComparison.OrdinalIgnoreCase))
			{
				return true;
			}
		}
		return false;
	}

	private static bool IsFellow(string name)
	{
		foreach (string fellow in CorpseKillers.Fellows)
		{
			if (string.Equals(fellow, name, StringComparison.OrdinalIgnoreCase))
			{
				return true;
			}
		}
		return false;
	}

	private static void Note(string s)
	{
		_log.Insert(0, DateTime.Now.ToString("HH:mm") + "  " + s);
		if (_log.Count > 8)
		{
			_log.RemoveAt(_log.Count - 1);
		}
	}

	private static bool Add(string name, string why)
	{
		if (string.IsNullOrEmpty(name) || string.Equals(name, Me, StringComparison.OrdinalIgnoreCase))
		{
			return false;
		}
		if (IsFellow(name) || Ignored(name) || Full)
		{
			return false;
		}
		if (_tried.TryGetValue(name, out var value) && (DateTime.Now - value).TotalMinutes < 2.0)
		{
			return false;
		}
		_tried[name] = DateTime.Now;
		Util.Command("/fship add " + name);
		Note("added " + name + " (" + why + ")");
		return true;
	}

	private static void AskList()
	{
		_listAsked = DateTime.Now;
		Util.Command("/fship list");
	}

	private static void ReadList(string text)
	{
		string[] array = text.Replace("\r", "").Split('\n');
		foreach (string text2 in array)
		{
			string text3 = text2.Trim();
			if (text3.Length == 0)
			{
				continue;
			}
			if (text3.IndexOf("[FSHIP]", StringComparison.OrdinalIgnoreCase) >= 0 && text3.IndexOf("Fellowships in your area", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				_list.Clear();
				_listAt = DateTime.Now;
				_listUntil = DateTime.Now.AddSeconds(3.0);
			}
			else
			{
				if (DateTime.Now > _listUntil)
				{
					continue;
				}
				if (text3.Trim('-').Length == 0)
				{
					_listUntil = DateTime.MinValue;
					ListDone();
					continue;
				}
				if (text3.StartsWith("No fellowships found", StringComparison.OrdinalIgnoreCase))
				{
					_listUntil = DateTime.MinValue;
					ListDone();
					continue;
				}
				Match match = ListRx.Match(text3);
				if (match.Success)
				{
					_list.Add(new Fship
					{
						Name = match.Groups["f"].Value,
						Leader = match.Groups["l"].Value.Trim()
					});
					_listUntil = DateTime.Now.AddSeconds(1.5);
				}
				else
				{
					_listUntil = DateTime.MinValue;
					ListDone();
				}
			}
		}
	}

	private static void ListDone()
	{
		if (_joinWaitList)
		{
			_joinWaitList = false;
			JoinNext();
		}
	}

	public static void JoinFirst()
	{
		if (CorpseKillers.InFellow)
		{
			Util.WriteToChat("Fellowship: you're already in one - leave it first.");
			return;
		}
		_joining = true;
		_joinTried.Clear();
		_joinLeader = null;
		if ((DateTime.Now - _listAt).TotalSeconds > 20.0)
		{
			_joinWaitList = true;
			_joinAt = DateTime.Now;
			AskList();
		}
		else
		{
			JoinNext();
		}
	}

	public static void JoinStop(string why)
	{
		if (_joining)
		{
			_joining = false;
			_joinWaitList = false;
			_joinLeader = null;
			Note("join: " + why);
			Util.WriteToChat("Fellowship: " + why);
		}
	}

	private static void JoinNext()
	{
		if (!_joining)
		{
			return;
		}
		foreach (Fship item in _list)
		{
			if (_joinTried.Contains(item.Leader) || Ignored(item.Leader))
			{
				continue;
			}
			_joinTried.Add(item.Leader);
			_joinLeader = item.Leader;
			_joinAt = DateTime.Now;
			Util.Command("/t " + item.Leader + ", xp");
			Note("asked " + item.Leader + " to join '" + item.Name + "'");
			return;
		}
		JoinStop((_list.Count == 0) ? "no fellowships in your area." : "none of the fellowships here took you.");
	}

	private static void JoinTick()
	{
		if (!_joining)
		{
			return;
		}
		if (CorpseKillers.InFellow)
		{
			JoinStop("joined" + ((_joinLeader != null) ? (" " + _joinLeader + "'s fellowship.") : "."));
		}
		else if (_joinWaitList)
		{
			if ((DateTime.Now - _joinAt).TotalSeconds > 8.0)
			{
				_joinWaitList = false;
				JoinNext();
			}
		}
		else if (_joinLeader != null && (DateTime.Now - _joinAt).TotalSeconds > 20.0)
		{
			Note(_joinLeader + " didn't add you");
			JoinNext();
		}
	}

	// the server's /autofellow (ILT: everyone in the area joins its open fellowship while it's on): what it last said
	private static bool? _autoFellow = AutoKept(out _autoSaidAt);

	private static DateTime _autoSaidAt;

	// kept over a hot reload (the server won't say it again until something is sent)
	private static void KeepAuto()
	{
		try
		{
			AppDomain.CurrentDomain.SetData("MelkTank.AutoFellow", (_autoFellow == true ? "1|" : _autoFellow == false ? "0|" : "?|") + _autoSaidAt.Ticks);
		}
		catch
		{
		}
	}

	private static bool? AutoKept(out DateTime at)
	{
		at = DateTime.MinValue;
		try
		{
			string[] p = (AppDomain.CurrentDomain.GetData("MelkTank.AutoFellow") as string ?? "").Split('|');
			if (p.Length == 2 && long.TryParse(p[1], out long ticks))
			{
				at = new DateTime(ticks);
				return p[0] == "1" ? true : p[0] == "0" ? false : null;
			}
		}
		catch
		{
		}
		return null;
	}

	// the server's /autofellow has you in the area's fellowship (said so in the last 10 minutes): opening, creating,
	// re-locking, /fship landblock and adding people are its business - each try only gets "...is always open to
	// everyone in the area" back. Away from that area MelkTank's own upkeep comes back.
	private static bool ServerFellow => _autoFellow == true && (DateTime.Now - _autoSaidAt).TotalMinutes < 10.0;

	// "Auto fellowship is ON - you are in the Tou Tou fellowship (16 members). Use /autofellow on or /autofellow off."
	private static readonly Regex AutoFellowRx = new Regex("auto ?fellow(?:ship)? is (on|off)", RegexOptions.IgnoreCase);

	private static void ReadAutoFellow(string text)
	{
		Match m = AutoFellowRx.Match(text);
		if (m.Success)
		{
			_autoFellow = m.Groups[1].Value.Equals("on", StringComparison.OrdinalIgnoreCase);
			_autoSaidAt = DateTime.Now;
			KeepAuto();
		}
		// "The Tou Tou fellowship is always open to everyone in the area. Everyone here is in it while /autofellow is on."
		// - the server's answer to a /fship command while its area fellowship has you
		else if (text.IndexOf("is always open to everyone in the area", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			_autoFellow = true;
			_autoSaidAt = DateTime.Now;
			KeepAuto();
		}
	}

	public static void OnChat(string text)
	{
		if (string.IsNullOrEmpty(text))
		{
			return;
		}
		text = TagRx.Replace(text, "$1");
		ReadList(text);
		ReadAutoFellow(text);
		if (_joining && _joinLeader != null)
		{
			Match match = TellRx.Match(text.Trim());
			if (match.Success && string.Equals(match.Groups["n"].Value.Trim(), _joinLeader, StringComparison.OrdinalIgnoreCase) && RefuseRx.IsMatch(match.Groups["m"].Value))
			{
				Note(_joinLeader + " said no: " + match.Groups["m"].Value);
				JoinNext();
				return;
			}
			if (!match.Success && text.IndexOf(_joinLeader, StringComparison.OrdinalIgnoreCase) >= 0 && Regex.IsMatch(text, "not online|is not available|could not be found|doesn't exist|is away|ignoring you", RegexOptions.IgnoreCase))
			{
				Note(_joinLeader + " can't be told");
				JoinNext();
				return;
			}
		}
		if (!On || ManagerTell(text) || (!_s.FellowAuto && !_s.FmOn))
		{
			return;
		}
		Match match2 = TellRx.Match(text.Trim());
		if (!match2.Success)
		{
			return;
		}
		string text2 = match2.Groups["m"].Value.Trim().TrimEnd(new char[3] { '!', '.', '?' }).Trim();
		bool flag = false;
		string[] array = (_s.FellowKeywords ?? "xp").Split(',');
		foreach (string text3 in array)
		{
			if (text3.Trim().Length > 0 && string.Equals(text3.Trim(), text2, StringComparison.OrdinalIgnoreCase))
			{
				flag = true;
				break;
			}
		}
		if (!flag)
		{
			return;
		}
		string text4 = match2.Groups["n"].Value.Trim();
		if (!CorpseKillers.InFellow)
		{
			Note(text4 + " asked - you're not in a fellowship");
		}
		else if (CorpseKillers.Locked == true || (!IsLeader && CorpseKillers.Open == false))
		{
			Tell(text4, "Sorry, the fellowship is " + ((CorpseKillers.Locked == true) ? "locked" : "closed") + ". The leader is " + LeaderName() + ".");
			Note(text4 + " asked - the fellowship is " + ((CorpseKillers.Locked == true) ? "locked" : "closed"));
		}
		else
		{
			if (WaitingListXp(text4))
			{
				return;
			}
			if (_s.FmOn && !IsLeader && CorpseKillers.LeaderId != 0)
			{
				Tell(text4, "I'm not the leader - tell " + LeaderName() + " 'xp'.");
			}
			else if (Full)
			{
				Note(text4 + " asked - the fellowship is full");
				if (_s.FmOn)
				{
					Tell(text4, "Sorry, the fellowship is full.");
				}
			}
			else
			{
				Add(text4, "told you " + text2);
			}
		}
	}

	public static void Tick()
	{
		try
		{
			JoinTick();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		try
		{
			if (_s != null && _s.FmOn && _s.MasterEnabled)
			{
				WaitingTick();
				VotesTick();
			}
		}
		catch (Exception ex2)
		{
			Util.LogError(ex2);
		}
		try
		{
			bool inFellow = CorpseKillers.InFellow;
			if (inFellow && !_wasIn)
			{
				_iMadeIt = CorpseKillers.FellowCount == 0;
			}
			if (!inFellow)
			{
				_iMadeIt = false;
			}
			if (inFellow && !_wasIn && CorpseKillers.FellowCount == 0 && _s != null && _s.FellowOpenOnCreate && !ServerFellow)
			{
				_openAt = DateTime.Now.AddSeconds(2.0);
			}
			_wasIn = inFellow;
			if (_openAt != DateTime.MinValue && DateTime.Now >= _openAt)
			{
				_openAt = DateTime.MinValue;
				if (inFellow && !ServerFellow && SetOpen(open: true))
				{
					Note("opened the fellowship");
				}
			}
		}
		catch (Exception ex3)
		{
			Util.LogError(ex3);
		}
		if (!On || _s == null)
		{
			return;
		}
		// the server's /autofellow has you in the area's fellowship: creating, re-locking, /fship landblock and adding
		// people are its business (each try only gets "...is always open to everyone in the area" back)
		// (for 10 minutes after the server last said so: away from that area MelkTank's own fellowship upkeep comes back,
		// and back in it one try gets the answer again)
		if (ServerFellow)
		{
			return;
		}
		try
		{
			RecreateTick();
		}
		catch (Exception ex4)
		{
			Util.LogError(ex4);
		}
		try
		{
			bool inFellow2 = CorpseKillers.InFellow;
			if (!inFellow2 && _s.FellowCreate && DateTime.Now >= _nextCreate)
			{
				_nextCreate = DateTime.Now.AddMinutes(1.0);
				string text = (_s.FellowName ?? "").Trim();
				if (text.Length == 0)
				{
					text = Me + "'s Fellowship";
				}
				Util.Command("/fship create " + text);
				Note("created " + text);
			}
			else
			{
				if (!inFellow2)
				{
					return;
				}
				if (_s.FellowLandblock && DateTime.Now >= _nextLandblock)
				{
					_nextLandblock = DateTime.Now.AddMinutes(Math.Max(1f, _s.FellowLandblockMin));
					if (!Full)
					{
						Util.Command("/fship landblock");
						Note("/fship landblock");
					}
				}
				if (!_s.FellowScan || !(DateTime.Now >= _nextScan))
				{
					return;
				}
				_nextScan = DateTime.Now.AddSeconds(10.0);
				{
					foreach (WorldObject item in CoreManager.Current.WorldFilter.GetByObjectClass(ObjectClass.Player))
					{
						if (Full || ((!(_s.FellowScanRange > 0f) || !(CombatEngine.Distance(item) > (double)_s.FellowScanRange)) && Add(item.Name, "came into view")))
						{
							break;
						}
					}
					return;
				}
			}
		}
		catch (Exception ex5)
		{
			Util.LogError(ex5);
		}
	}

	public static bool Draw(Action<string> tip)
	{
		bool flag = false;
		Vector4 vector = new Vector4(0.6f, 0.6f, 0.6f, 1f);
		Vector4 vector2 = new Vector4(0.45f, 0.9f, 0.45f, 1f);
		bool inFellow = CorpseKillers.InFellow;
		Im.TextColored(inFellow ? vector2 : vector, inFellow ? ("In a fellowship - " + (CorpseKillers.FellowCount + 1) + " members") : "Not in a fellowship");
		if (inFellow && CorpseKillers.FellowCount > 0 && ImGui.IsItemHovered())
		{
			Im.SetTooltip(string.Join("\n", new List<string>(CorpseKillers.Fellows).ToArray()));
		}
		flag |= ImGui.Checkbox("Auto fellow management##fauto", ref _s.FellowAuto);
		Im.SetTooltipIfHovered("/mt set FellowAuto on|off");
		tip("Like VTank: someone tells you \"xp\" while you're in a fellowship -> /fship add them.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(120f);
		flag |= ImGui.InputText("tells##fkeys", ref _s.FellowKeywords, 64u);
		tip("What a tell has to say (the whole message, any case). Several: xp, fellow, fs");
		flag |= DrawManager(tip);
		flag |= ImGui.Checkbox("Add players who show up##fscan", ref _s.FellowScan);
		Im.SetTooltipIfHovered("/mt set FellowScan on|off");
		tip("Every 10 s: anyone in view who isn't in the fellowship gets /fship add (one at a time, each name at most every 2 min).\nIn a dungeon the client sees the whole dungeon, so leave the range at 0 for 'everyone'.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		flag |= ImGui.InputFloat("m (0 = any)##frange", ref _s.FellowScanRange, 10f, 50f, "%.0f");
		Im.SetTooltipIfHovered("/mt set FellowScanRange <number>");
		if (_s.FellowScanRange < 0f)
		{
			_s.FellowScanRange = 0f;
		}
		flag |= ImGui.Checkbox("/fship landblock every##flb", ref _s.FellowLandblock);
		Im.SetTooltipIfHovered("/mt set FellowLandblock on|off");
		tip("Invites everyone in your landblock on a timer (while you're in a fellowship and it isn't full).");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		flag |= ImGui.InputFloat("min##flbmin", ref _s.FellowLandblockMin, 1f, 5f, "%.0f");
		Im.SetTooltipIfHovered("/mt set FellowLandblockMin <number>");
		if (_s.FellowLandblockMin < 1f)
		{
			_s.FellowLandblockMin = 1f;
		}
		flag |= ImGui.Checkbox("Create a fellowship when I'm not in one##fcreate", ref _s.FellowCreate);
		Im.SetTooltipIfHovered("/mt set FellowCreate on|off");
		tip("Not in a fellowship (logged in, disbanded, kicked): /fship create with this name - so you never lose XP / Lum for being out of one.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(160f);
		flag |= ImGui.InputTextWithHint("##fname", Me + "'s Fellowship", ref _s.FellowName, 64u);
		flag |= ImGui.Checkbox("Make it again if a quest locks it##frelock", ref _s.FellowRelock);
		Im.SetTooltipIfHovered("/mt set FellowRelock on|off");
		tip("You lead it and a quest locks the fellowship: it's disbanded, made again (same name) and everyone in it is\ninvited back - so new people can still join. Locked or closed, an 'xp' gets told who leads it and that it's closed.");
		flag |= ImGui.Checkbox("Open it as soon as it's created##fopen", ref _s.FellowOpenOnCreate);
		Im.SetTooltipIfHovered("/mt set FellowOpenOnCreate on|off");
		tip("A fellowship you make (with Create, /fship create or the panel) is set Open a couple of seconds later -\nanyone can join it without an invite, like VTank does.");
		ImGui.SetNextItemWidth(260f);
		flag |= ImGui.InputTextWithHint("Never add##fign", "names, comma separated", ref _s.FellowIgnore, 512u);
		if (ImGui.Button("Create##fbc"))
		{
			string text = (_s.FellowName ?? "").Trim();
			Util.Command("/fship create " + ((text.Length > 0) ? text : (Me + "'s Fellowship")));
		}
		ImGui.SameLine();
		if (ImGui.Button("Open##fbo") && SetOpen(open: true))
		{
			Note("opened the fellowship");
		}
		tip("Sets your fellowship Open (you have to be its leader).");
		ImGui.SameLine();
		if (ImGui.Button("Add selected##fba"))
		{
			Util.Command("/fship add");
		}
		tip("/fship add with no name invites the player you have selected.");
		ImGui.SameLine();
		if (ImGui.Button("Landblock now##fbl"))
		{
			Util.Command("/fship landblock");
		}
		ImGui.SameLine();
		if (ImGui.Button("Leave##fbq"))
		{
			Util.Command("/fship leave");
		}
		ImGui.SameLine();
		if (ImGui.Button("Disband##fbd"))
		{
			Util.Command("/fship disband");
		}
		if (ImGui.Button("List fellowships here##fls"))
		{
			AskList();
		}
		tip("/fship list - the fellowships in your landblock (a dungeon, a farming spot).");
		ImGui.SameLine();
		if (!_joining)
		{
			if (ImGui.Button("Join first free##fjoin"))
			{
				JoinFirst();
			}
		}
		else if (ImGui.Button("Stop joining##fjoinx"))
		{
			JoinStop("stopped.");
		}
		tip("Tells the first leader on the list \"xp\". If they say it's full / locked / closed, or you aren't added\nwithin 20 s, it tries the next one. Stops once you're in a fellowship.");
		ImGui.SameLine();
		if (ImGui.Button((_autoFellow == true ? "Auto fellow: ON" : _autoFellow == false ? "Auto fellow: OFF" : "Auto fellow: ?") + "##fauto"))
		{
			// (not known yet: plain /autofellow says which; known: switched to the other)
			Util.Command(_autoFellow == true ? "/autofellow off" : _autoFellow == false ? "/autofellow on" : "/autofellow");
		}
		tip("The server's /autofellow: while it's ON you're in the area's open fellowship (the Tou Tou one, open to everyone\nthere). Click to switch it - the first click (\"?\") just asks the server which it is.");
		if (_joining)
		{
			ImGui.SameLine();
			Im.TextColored(new Vector4(0.95f, 0.85f, 0.35f, 1f), (_joinLeader != null) ? ("asking " + _joinLeader + "...") : "getting the list...");
		}
		if (_listAt != DateTime.MinValue)
		{
			if (_list.Count == 0)
			{
				Im.TextColored(vector, "  No fellowships found here (" + _listAt.ToString("HH:mm") + ")");
			}
			foreach (Fship item in _list)
			{
				Im.TextColored(_joinTried.Contains(item.Leader) ? vector : vector2, "  '" + item.Name + "' led by " + item.Leader);
				ImGui.SameLine();
				if (ImGui.SmallButton("xp##fj" + item.Leader))
				{
					Util.Command("/t " + item.Leader + ", xp");
					Note("asked " + item.Leader);
				}
			}
		}
		foreach (string item2 in _log)
		{
			Im.TextColored(vector, item2);
		}
		return flag;
	}

	private static string LeaderName()
	{
		int leaderId = CorpseKillers.LeaderId;
		if (leaderId == 0)
		{
			return "unknown";
		}
		if (leaderId == MyId)
		{
			return Me;
		}
		try
		{
			WorldObject worldObject = CoreManager.Current.WorldFilter[leaderId];
			if (worldObject != null)
			{
				return worldObject.Name;
			}
		}
		catch
		{
		}
		return "someone else";
	}

	private static void Tell(string who, string text)
	{
		Util.Command("/t " + who + ", [MT Fellow Manager] " + text);
	}

	private static void Fellow(string text)
	{
		Util.Command("/f [MT Fellow Manager] " + text);
	}

	private static string Readable(double secs)
	{
		int num = (int)Math.Ceiling(Math.Max(0.0, secs));
		int num2 = num / 60;
		num %= 60;
		return (num2 > 0) ? (num2 + " min " + num + " s") : (num + " s");
	}

	private static bool ManagerTell(string text)
	{
		if (_s == null || !_s.FmOn)
		{
			return false;
		}
		Match match = CmdTellRx.Match(text.Trim());
		if (!match.Success)
		{
			return false;
		}
		string who = match.Groups["n"].Value.Trim();
		string text2 = match.Groups["m"].Value.Trim();
		if (text2.StartsWith("[MT Fellow Manager]") || text2.StartsWith("[VT Fellow Manager]"))
		{
			return false;
		}
		string[] array = text2.Split(new char[1] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
		if (array.Length == 0)
		{
			return false;
		}
		switch (array[0].ToLowerInvariant().TrimEnd(new char[3] { '!', '.', '?' }))
		{
		case "help":
			Tell(who, "Commands: xp (join / waiting list), line (your place), remove (leave the list), leader, location, startvote kick|ban|giveleader|setopen <name or true/false>, vote <id> yes|no.");
			return true;
		case "leader":
			Tell(who, "The leader is " + LeaderName() + ".");
			return true;
		case "location":
			if (!IsFellow(who))
			{
				Tell(who, "Sorry, I only send my location to fellows.");
				return true;
			}
			Tell(who, "I'm at " + WhereAmI() + ".");
			return true;
		case "line":
		{
			int num2 = _waiting.FindIndex((string x) => string.Equals(x, who, StringComparison.OrdinalIgnoreCase));
			Tell(who, (num2 < 0) ? ("You aren't on the waiting list" + ((_waiting.Count > 0) ? (" (" + _waiting.Count + " waiting).") : " - there isn't one.")) : ("You're number " + (num2 + 1) + " of " + _waiting.Count + "."));
			return true;
		}
		case "remove":
		{
			int num = _waiting.RemoveAll((string x) => string.Equals(x, who, StringComparison.OrdinalIgnoreCase));
			if (string.Equals(_spotFor, who, StringComparison.OrdinalIgnoreCase))
			{
				_spotFor = null;
				_spotUntil = DateTime.MinValue;
				num++;
			}
			Tell(who, (num > 0) ? "You've been taken off the list." : "You weren't on the list.");
			return true;
		}
		case "startvote":
			StartVote(who, array);
			return true;
		case "vote":
			CastVote(who, array);
			return true;
		default:
			return false;
		}
	}

	private static bool WaitingListXp(string who)
	{
		if (_s == null || !_s.FmOn || !_s.FmWaitList || !IsLeader)
		{
			return false;
		}
		if (_spotFor != null && string.Equals(_spotFor, who, StringComparison.OrdinalIgnoreCase))
		{
			_spotFor = null;
			_spotUntil = DateTime.MinValue;
			_tried.Remove(who);
			Add(who, "their spot on the waiting list");
			return true;
		}
		bool flag = _spotFor != null && DateTime.Now < _spotUntil;
		if (!Full && !flag)
		{
			return false;
		}
		int num = _waiting.FindIndex((string x) => string.Equals(x, who, StringComparison.OrdinalIgnoreCase));
		if (num < 0)
		{
			_waiting.Add(who);
			num = _waiting.Count - 1;
			Note(who + " on the waiting list (#" + (num + 1) + ")");
		}
		Tell(who, "The fellowship is full - you're number " + (num + 1) + " on the waiting list. You'll be added automatically when there's room; tell me 'remove' if you don't want to be, or 'line' to check your place.");
		return true;
	}

	private static void WaitingTick()
	{
		if (_s == null || !_s.FmOn || !_s.FmWaitList)
		{
			return;
		}
		if (!IsLeader)
		{
			if (_waiting.Count <= 0 && _spotFor == null)
			{
				return;
			}
			foreach (string item in _waiting)
			{
				Tell(item, "You've been dropped from the waiting list - I'm not leading the fellowship any more.");
			}
			_waiting.Clear();
			_spotFor = null;
			return;
		}
		if (_spotFor != null)
		{
			if (IsFellow(_spotFor))
			{
				Note(_spotFor + " joined from the waiting list");
				_spotFor = null;
			}
			else if (DateTime.Now >= _spotUntil)
			{
				Tell(_spotFor, "I couldn't add you (offline, too far away, or the invite wasn't accepted) - you're off the list. Tell me 'xp' to get back in line.");
				Note(_spotFor + " couldn't be added - next");
				_spotFor = null;
			}
		}
		if (_spotFor == null && _waiting.Count > 0 && !Full)
		{
			_spotFor = _waiting[0];
			_waiting.RemoveAt(0);
			_spotUntil = DateTime.Now.AddSeconds(60.0);
			_tried.Remove(_spotFor);
			Tell(_spotFor, "There's room now - adding you to the fellowship.");
			Util.Command("/fship add " + _spotFor);
			Note("adding " + _spotFor + " from the waiting list");
		}
	}

	private static bool VoteOn(string type)
	{
		return type switch
		{
			"kick" => _s.FmVoteKick, 
			"ban" => _s.FmVoteBan, 
			"giveleader" => _s.FmVoteLeader, 
			"setopen" => _s.FmVoteOpen, 
			_ => false, 
		};
	}

	private static void StartVote(string who, string[] w)
	{
		if (!IsLeader)
		{
			Tell(who, "I'm not the fellowship leader - " + LeaderName() + " is.");
			return;
		}
		if (!IsFellow(who))
		{
			Tell(who, "Only fellows can start a vote.");
			return;
		}
		if (w.Length < 3)
		{
			Tell(who, "Usage: startvote kick|ban|giveleader|setopen <name, or true/false for setopen>.");
			return;
		}
		string text = w[1].ToLowerInvariant();
		if (Array.IndexOf(VoteTypes, text) < 0)
		{
			Tell(who, "Unknown vote type '" + w[1] + "' - kick, ban, giveleader or setopen.");
			return;
		}
		if (!VoteOn(text))
		{
			string who2 = who;
			string text2;
			if (text == "giveleader")
			{
				text2 = "give leader";
			}
			else
			{
				text2 = ((text == "setopen") ? "open / close the fellowship" : text);
			}
			Tell(who2, "Votes to " + text2 + " are turned off in this fellowship.");
			return;
		}
		string text3 = string.Join(" ", w, 2, w.Length - 2).Trim();
		if (text == "setopen")
		{
			string text4 = text3.ToLowerInvariant();
			if (text4 != "true" && text4 != "false")
			{
				Tell(who, "setopen needs true or false.");
				return;
			}
			text3 = text4;
		}
		else
		{
			string text5 = FellowNamed(text3);
			if (text5 == null)
			{
				Tell(who, text3 + " isn't in the fellowship.");
				return;
			}
			if (text != "giveleader" && string.Equals(text5, Me, StringComparison.OrdinalIgnoreCase))
			{
				Tell(who, "I can't " + text + " myself.");
				return;
			}
			text3 = text5;
		}
		if (_voteCalled.TryGetValue(who, out var value) && (DateTime.Now - value).TotalSeconds < 180.0)
		{
			Tell(who, "You started a vote too recently - wait another " + Readable(180.0 - (DateTime.Now - value).TotalSeconds) + ".");
			return;
		}
		foreach (Vote vote2 in _votes)
		{
			if (vote2.Type == text && string.Equals(vote2.Param, text3, StringComparison.OrdinalIgnoreCase))
			{
				Tell(who, "That vote is already going (vote " + vote2.Id + ").");
				return;
			}
		}
		Vote vote = new Vote
		{
			Id = ++_voteId,
			Type = text,
			Param = text3,
			Caller = who,
			Ends = DateTime.Now.AddSeconds(120.0)
		};
		vote.Votes[who] = true;
		_votes.Add(vote);
		_voteCalled[who] = DateTime.Now;
		Fellow(who + " started vote " + vote.Id + ": " + Say(vote) + ". Tell me 'vote " + vote.Id + " yes' or 'vote " + vote.Id + " no' - 2 minutes.");
		Note("vote " + vote.Id + ": " + Say(vote) + " (by " + who + ")");
		CheckVote(vote, timeUp: false);
	}

	private static string Say(Vote v)
	{
		return v.Type switch
		{
			"kick" => "kick " + v.Param, 
			"ban" => "ban " + v.Param, 
			"giveleader" => "make " + v.Param + " the leader", 
			_ => ((v.Param == "true") ? "open" : "close") + " the fellowship", 
		};
	}

	private static void CastVote(string who, string[] w)
	{
		if (!IsLeader)
		{
			Tell(who, "I'm not the fellowship leader - " + LeaderName() + " is.");
			return;
		}
		if (!IsFellow(who) && !string.Equals(who, Me, StringComparison.OrdinalIgnoreCase))
		{
			Tell(who, "Only fellows can vote.");
			return;
		}
		string text = ((w.Length >= 3) ? w[2].ToLowerInvariant() : "");
		if (w.Length < 3 || !int.TryParse(w[1], out var id) || (text != "yes" && text != "no"))
		{
			Tell(who, "Votes look like: vote <id> yes, or vote <id> no.");
			return;
		}
		Vote vote = _votes.Find((Vote x) => x.Id == id);
		if (vote == null)
		{
			Tell(who, "There's no vote " + id + " going.");
			return;
		}
		vote.Votes[who] = text == "yes";
		Count(vote, out var yes, out var no);
		Fellow("Vote " + vote.Id + " (" + Say(vote) + "): " + yes + " yes, " + no + " no.");
		CheckVote(vote, timeUp: false);
	}

	private static void Count(Vote v, out int yes, out int no)
	{
		yes = (no = 0);
		foreach (KeyValuePair<string, bool> vote in v.Votes)
		{
			if (vote.Value)
			{
				yes++;
			}
			else
			{
				no++;
			}
		}
	}

	private static void CheckVote(Vote v, bool timeUp)
	{
		Count(v, out var yes, out var no);
		int num = CorpseKillers.FellowCount + 1;
		bool flag = yes * 2 > num;
		if (!timeUp && !flag)
		{
			return;
		}
		_votes.Remove(v);
		bool flag2 = yes > no;
		Fellow("Vote " + v.Id + " (" + Say(v) + ") " + (flag2 ? "passed" : "failed") + " (" + yes + " yes, " + no + " no).");
		Note("vote " + v.Id + " " + (flag2 ? "passed" : "failed"));
		if (!flag2)
		{
			return;
		}
		switch (v.Type)
		{
		case "kick":
			Util.Command("/fship remove " + v.Param);
			break;
		case "ban":
			Util.Command("/fship remove " + v.Param);
			if (!Ignored(v.Param))
			{
				_s.FellowIgnore = (((_s.FellowIgnore ?? "").Trim().Length > 0) ? (_s.FellowIgnore.Trim() + ", " + v.Param) : v.Param);
				if (SaveAll != null)
				{
					SaveAll();
				}
			}
			break;
		case "giveleader":
		{
			int num2 = PlayerId(v.Param);
			if (num2 == 0)
			{
				Fellow("I can't see " + v.Param + " to hand over the leader.");
				break;
			}
			try
			{
				CM_Fellowship.Event_AssignNewLeader((uint)num2);
				break;
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
				break;
			}
		}
		case "setopen":
			SetOpen(v.Param == "true");
			break;
		}
	}

	private static void VotesTick()
	{
		foreach (Vote item in new List<Vote>(_votes))
		{
			if (!IsLeader)
			{
				_votes.Clear();
				Fellow("I'm not the leader any more - the votes are off.");
				break;
			}
			if (DateTime.Now >= item.Ends)
			{
				CheckVote(item, timeUp: true);
			}
		}
	}

	private static string FellowNamed(string name)
	{
		if (string.Equals(name, Me, StringComparison.OrdinalIgnoreCase))
		{
			return Me;
		}
		foreach (string fellow in CorpseKillers.Fellows)
		{
			if (string.Equals(fellow, name, StringComparison.OrdinalIgnoreCase))
			{
				return fellow;
			}
		}
		return null;
	}

	private static int PlayerId(string name)
	{
		try
		{
			foreach (WorldObject item in CoreManager.Current.WorldFilter.GetByObjectClass(ObjectClass.Player))
			{
				if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
				{
					return item.Id;
				}
			}
		}
		catch
		{
		}
		return 0;
	}

	private static string WhereAmI()
	{
		uint num = 0u;
		try
		{
			num = (uint)CoreManager.Current.Actions.Landcell;
		}
		catch
		{
		}
		string text = " (" + num.ToString("X8") + ")";
		if ((num & 0xFFFF) >= 256)
		{
			return Locations.Here(null) + text;
		}
		int num2 = -1;
		try
		{
			if (CurrentTier != null)
			{
				num2 = CurrentTier();
			}
		}
		catch
		{
		}
		return ((num2 >= 10) ? ("Tier " + num2 + ", ") : "") + Locations.Coords() + text;
	}

	private static bool DrawManager(Action<string> tip)
	{
		bool flag = false;
		Vector4 col = new Vector4(0.6f, 0.6f, 0.6f, 1f);
		flag |= ImGui.Checkbox("Fellow manager (answer tells as the leader)##fm", ref _s.FmOn);
		Im.SetTooltipIfHovered("/mt set FmOn on|off");
		tip("[MT Fellow Manager]: when you lead the fellowship, people can tell you: xp, line, remove, leader, location, help,\nstartvote kick|ban|giveleader|setopen <name / true|false>, vote <id> yes|no.\nAnswers go back as tells, votes are announced in /f. Votes last 2 minutes; one per person every 3 minutes.");
		if (_s.FmOn)
		{
			ImGui.Indent(16f);
			flag |= ImGui.Checkbox("Waiting list when full##fmwait", ref _s.FmWaitList);
			Im.SetTooltipIfHovered("/mt set FmWaitList on|off");
			tip("Full (29): 'xp' puts them in line. When there's room the next one is added straight away (/fship add) -\nif they aren't in within a minute (offline, didn't accept), the one after them is.");
			ImGui.SameLine();
			flag |= ImGui.Checkbox("Kick votes##fmk", ref _s.FmVoteKick);
			Im.SetTooltipIfHovered("/mt set FmVoteKick on|off");
			ImGui.SameLine();
			flag |= ImGui.Checkbox("Ban votes##fmb", ref _s.FmVoteBan);
			Im.SetTooltipIfHovered("/mt set FmVoteBan on|off");
			tip("A ban kicks them and puts them on 'Never add'.");
			ImGui.SameLine();
			flag |= ImGui.Checkbox("Leader votes##fml", ref _s.FmVoteLeader);
			Im.SetTooltipIfHovered("/mt set FmVoteLeader on|off");
			ImGui.SameLine();
			flag |= ImGui.Checkbox("Open votes##fmo", ref _s.FmVoteOpen);
			Im.SetTooltipIfHovered("/mt set FmVoteOpen on|off");
			tip("Votes of a kind that's off get an answer that they're turned off here.");
			if (_waiting.Count > 0 || _spotFor != null)
			{
				Im.TextColored(col, "Waiting: " + ((_spotFor != null) ? (_spotFor + " (being added)" + ((_waiting.Count > 0) ? ", " : "")) : "") + string.Join(", ", _waiting.ToArray()));
			}
			foreach (Vote vote in _votes)
			{
				Count(vote, out var yes, out var no);
				Im.TextColored(col, "Vote " + vote.Id + ": " + Say(vote) + " - " + yes + " yes, " + no + " no, " + Readable((vote.Ends - DateTime.Now).TotalSeconds) + " left");
			}
			if (!IsLeader && CorpseKillers.InFellow)
			{
				Im.TextColored(col, "(you aren't the leader - it only answers when you are)");
			}
			ImGui.Unindent(16f);
		}
		return flag;
	}
}
