using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Numerics;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

public class ItemBar : IDisposable
{
	public class Entry
	{
		public string Name;

		public int Icon;

		public bool On = true;

		public long Count;
	}

	private static ItemBar _cur;

	private readonly Hud _hud;

	private readonly Settings _s;

	private readonly Action _saveAll;

	private readonly List<Entry> _list = new List<Entry>();

	private DateTime _countAt = DateTime.MinValue;

	private int _editIdx = -1;

	private int _editIcon;

	private string _editName = "";

	private bool _shown;

	private static readonly Vector4 CountColor = new Vector4(0.35f, 0.85f, 0.95f, 1f);

	private readonly Dictionary<string, List<Entry>> _profiles = new Dictionary<string, List<Entry>>(StringComparer.OrdinalIgnoreCase);

	private readonly List<string> _order = new List<string>();

	private DateTime _profMtime = DateTime.MinValue;

	private readonly Dictionary<int, ManagedTexture> _tex = new Dictionary<int, ManagedTexture>();

	private bool _restored;

	private float[] _lastPos;

	private DateTime _dirtySince = DateTime.MinValue;

	private bool _pushed;

	private string _newName = "";

	private bool _confirmDel;

	private static string ProfFile => Util.FullPath("MelkTank_ItemBarProfiles.txt");

	private string Active
	{
		get
		{
			string text = (_s.ItemBarProfile ?? "").Trim();
			return (text.Length > 0) ? text : "Default";
		}
	}

	private static string PosFile => Util.FullPath("MelkTank_ItemBarPos.txt");

	public ItemBar(Settings s, Action saveAll)
	{
		_s = s;
		_saveAll = saveAll;
		Load();
		_hud = UBService.Huds.CreateHud("MelkTank Items", BarIcon.Make("Items"));
		_hud.ShowInBar = false;
		_hud.WindowSettings = ImGuiWindowFlags.NoTitleBar | ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoCollapse | ImGuiWindowFlags.AlwaysAutoResize | ImGuiWindowFlags.NoFocusOnAppearing;
		_hud.OnPreRender += OnPreRender;
		_hud.OnRender += OnRender;
		_shown = s.ItemBarShow;
		_hud.Visible = _shown;
		_cur = this;
	}

	public void Dispose()
	{
		if (_cur == this)
		{
			_cur = null;
		}
		try
		{
			_hud.OnPreRender -= OnPreRender;
			_hud.OnRender -= OnRender;
			_hud.Dispose();
		}
		catch
		{
		}
		foreach (ManagedTexture value in _tex.Values)
		{
			try
			{
				value?.Dispose();
			}
			catch
			{
			}
		}
		_tex.Clear();
	}

	private void Load()
	{
		_profiles.Clear();
		_order.Clear();
		try
		{
			if (File.Exists(ProfFile))
			{
				_profMtime = File.GetLastWriteTimeUtc(ProfFile);
				string[] array = Util.Locked(ProfFile, () => File.ReadAllLines(ProfFile));
				foreach (string text in array)
				{
					string[] array2 = text.Split('\t');
					if (array2[0].Trim().Length == 0)
					{
						continue;
					}
					List<Entry> list = Prof(array2[0].Trim());
					if (array2.Length >= 2 && array2[1].Length != 0)
					{
						Entry entry = new Entry
						{
							Name = array2[1]
						};
						if (array2.Length > 2)
						{
							int.TryParse(array2[2], out entry.Icon);
						}
						if (array2.Length > 3)
						{
							entry.On = array2[3] != "0";
						}
						list.Add(entry);
					}
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
		SetActive(Active);
	}

	private List<Entry> Prof(string name)
	{
		if (!_profiles.TryGetValue(name, out var value))
		{
			value = new List<Entry>();
			_profiles[name] = value;
			_order.Add(name);
		}
		return value;
	}

	private void SetActive(string name)
	{
		List<Entry> collection = Prof(name);
		_list.Clear();
		_list.AddRange(collection);
		if (!string.Equals(_s.ItemBarProfile, name, StringComparison.Ordinal))
		{
			_s.ItemBarProfile = name;
			if (_saveAll != null)
			{
				_saveAll();
			}
		}
		_countAt = DateTime.MinValue;
	}

	private void Save()
	{
		List<Entry> list = Prof(Active);
		list.Clear();
		list.AddRange(_list);
		WriteProfiles();
	}

	private void WriteProfiles()
	{
		List<string> lines = new List<string>();
		foreach (string item in _order)
		{
			List<Entry> list = _profiles[item];
			if (list.Count == 0)
			{
				lines.Add(item);
			}
			foreach (Entry item2 in list)
			{
				lines.Add(item + "\t" + item2.Name + "\t" + item2.Icon.ToString(CultureInfo.InvariantCulture) + "\t" + (item2.On ? "1" : "0"));
			}
		}
		try
		{
			Util.Locked(ProfFile, () =>
			{
				File.WriteAllLines(ProfFile, lines.ToArray());
			});
			_profMtime = File.GetLastWriteTimeUtc(ProfFile);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void ReloadIfChanged()
	{
		try
		{
			if (File.Exists(ProfFile))
			{
				DateTime lastWriteTimeUtc = File.GetLastWriteTimeUtc(ProfFile);
				if (lastWriteTimeUtc != _profMtime)
				{
					Load();
				}
			}
		}
		catch
		{
		}
	}

	public void Tick()
	{
		if (_s.ItemBarShow != _shown)
		{
			_shown = _s.ItemBarShow;
			try
			{
				_hud.Visible = _shown && HasOn();
			}
			catch
			{
			}
		}
		if ((DateTime.Now - _countAt).TotalSeconds < 3.0)
		{
			return;
		}
		_countAt = DateTime.Now;
		ReloadIfChanged();
		Count();
		try
		{
			bool flag = _shown && HasOn();
			if (_hud.Visible != flag)
			{
				_hud.Visible = flag;
			}
		}
		catch
		{
		}
	}

	private bool HasOn()
	{
		foreach (Entry item in _list)
		{
			if (item.On)
			{
				return true;
			}
		}
		return false;
	}

	private void Count()
	{
		Dictionary<string, long> dictionary = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase);
		Dictionary<string, int> dictionary2 = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				string key = item.Name ?? "";
				dictionary.TryGetValue(key, out var value);
				dictionary[key] = value + Math.Max(1, item.Values(LongValueKey.StackCount, 1));
				if (!dictionary2.ContainsKey(key))
				{
					try
					{
						dictionary2[key] = item.Icon;
					}
					catch
					{
					}
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			return;
		}
		bool flag = false;
		foreach (Entry item2 in _list)
		{
			item2.Count = (dictionary.TryGetValue(item2.Name, out var value2) ? value2 : 0);
			if (item2.Icon == 0 && dictionary2.TryGetValue(item2.Name, out var value3) && value3 != 0)
			{
				item2.Icon = value3;
				flag = true;
			}
		}
		if (flag)
		{
			Save();
		}
	}

	private void DrawIcon(int icon, float size)
	{
		ManagedTexture value = null;
		if (icon != 0)
		{
			if ((icon & 0xFF000000u) == 0)
			{
				icon |= 0x6000000;
			}
			if (!_tex.TryGetValue(icon, out value))
			{
				try
				{
					value = (ManagedTexture)Activator.CreateInstance(typeof(ManagedTexture), (uint)icon);
				}
				catch
				{
					value = null;
				}
				_tex[icon] = value;
			}
		}
		if (value != null)
		{
			try
			{
				ImGui.Image(value.TexturePtr, new Vector2(size, size));
				return;
			}
			catch
			{
			}
		}
		ImGui.Dummy(new Vector2(size, size));
	}

	private void OnPreRender(object sender, EventArgs e)
	{
		float nextWindowBgAlpha = Math.Max(0f, Math.Min(1f, _s.ItemBarOpacity));
		ImGui.SetNextWindowBgAlpha(nextWindowBgAlpha);
		ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, new Vector2(3f, 3f));
		ImGui.PushStyleVar(ImGuiStyleVar.ItemSpacing, new Vector2(4f, 1f));
		ImGui.PushStyleVar(ImGuiStyleVar.WindowBorderSize, 0f);
		ImGui.PushStyleVar(ImGuiStyleVar.WindowRounding, 0f);
		_pushed = true;
		if (_restored)
		{
			return;
		}
		_restored = true;
		try
		{
			if (!File.Exists(PosFile))
			{
				ImGui.SetNextWindowPos(new Vector2(4f, 140f), ImGuiCond.Always);
				return;
			}
			string[] array = File.ReadAllText(PosFile).Trim().Split('|');
			if (array.Length == 2 && float.TryParse(array[0], NumberStyles.Float, CultureInfo.InvariantCulture, out var result) && float.TryParse(array[1], NumberStyles.Float, CultureInfo.InvariantCulture, out var result2))
			{
				ImGui.SetNextWindowPos(new Vector2(result, result2), ImGuiCond.Always);
			}
		}
		catch
		{
		}
	}

	private void OnRender(object sender, EventArgs e)
	{
		try
		{
			WinMem.Frame("Item bar", size: false);
			if (_pushed)
			{
				ImGui.PopStyleVar(4);
				_pushed = false;
			}
			TrackPos();
			float num = Math.Max(0.5f, Math.Min(2f, _s.ItemBarScale));
			ImGui.SetWindowFontScale(num);
			float num2 = 24f * num;
			float num3 = (num2 - ImGui.GetTextLineHeight()) / 2f;
			foreach (Entry item in _list)
			{
				if (item.On)
				{
					DrawIcon(item.Icon, num2);
					if (ImGui.IsItemHovered())
					{
						Im.SetTooltip(item.Name);
					}
					ImGui.SameLine();
					float cursorPosY = ImGui.GetCursorPosY();
					ImGui.SetCursorPosY(cursorPosY + num3);
					Im.TextColored(CountColor, item.Count.ToString(CultureInfo.InvariantCulture));
					ImGui.SetCursorPosY(cursorPosY + num2 + 1f);
					ImGui.Dummy(new Vector2(0f, 0f));
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private void TrackPos()
	{
		Vector2 windowPos = ImGui.GetWindowPos();
		if (_lastPos == null || Math.Abs(windowPos.X - _lastPos[0]) > 0.5f || Math.Abs(windowPos.Y - _lastPos[1]) > 0.5f)
		{
			_lastPos = new float[2] { windowPos.X, windowPos.Y };
			_dirtySince = DateTime.Now;
		}
		if (_dirtySince != DateTime.MinValue && (DateTime.Now - _dirtySince).TotalSeconds > 1.5)
		{
			_dirtySince = DateTime.MinValue;
			try
			{
				File.WriteAllText(PosFile, _lastPos[0].ToString(CultureInfo.InvariantCulture) + "|" + _lastPos[1].ToString(CultureInfo.InvariantCulture));
			}
			catch
			{
			}
		}
	}

	public static void DrawTab(Settings s)
	{
		ItemBar cur = _cur;
		if (cur == null)
		{
			Im.TextDisabled("(not running)");
		}
		else
		{
			cur.DrawTabInner();
		}
	}

	private void DrawTabInner()
	{
		Im.Text("Profile");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(160f);
		if (ImGui.BeginCombo("##ibprof", Active))
		{
			string[] array = _order.ToArray();
			foreach (string text in array)
			{
				if (ImGui.Selectable(text + "##ibp" + text, string.Equals(text, Active, StringComparison.OrdinalIgnoreCase)))
				{
					SetActive(text);
				}
			}
			ImGui.EndCombo();
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Profiles are shared by every character - pick one here; changes to it show on every character using it.");
		}
		ImGui.SameLine();
		ImGui.SetNextItemWidth(120f);
		ImGui.InputTextWithHint("##ibnew", "new name", ref _newName, 40u);
		ImGui.SameLine();
		string text2 = (_newName ?? "").Trim().Replace("\t", " ");
		bool flag = text2.Length > 0 && !_profiles.ContainsKey(text2);
		if (!flag)
		{
			ImGui.BeginDisabled();
		}
		if (ImGui.Button("New##ibpnew"))
		{
			Prof(text2);
			WriteProfiles();
			SetActive(text2);
			_newName = "";
		}
		ImGui.SameLine();
		if (ImGui.Button("Copy##ibpcopy"))
		{
			List<Entry> list = Prof(text2);
			foreach (Entry item in _list)
			{
				list.Add(new Entry
				{
					Name = item.Name,
					Icon = item.Icon,
					On = item.On
				});
			}
			WriteProfiles();
			SetActive(text2);
			_newName = "";
		}
		if (!flag)
		{
			ImGui.EndDisabled();
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("A new profile with this one's items, under the name typed in.");
		}
		ImGui.SameLine();
		if (_order.Count <= 1)
		{
			ImGui.BeginDisabled();
		}
		if (!_confirmDel)
		{
			if (ImGui.Button("Delete##ibpdel"))
			{
				_confirmDel = true;
			}
		}
		else
		{
			if (ImGui.Button("Sure?##ibpdel2"))
			{
				_profiles.Remove(Active);
				_order.RemoveAll((string x) => string.Equals(x, Active, StringComparison.OrdinalIgnoreCase));
				WriteProfiles();
				SetActive((_order.Count > 0) ? _order[0] : "Default");
				_confirmDel = false;
			}
			ImGui.SameLine();
			if (ImGui.Button("No##ibpdel3"))
			{
				_confirmDel = false;
			}
		}
		if (_order.Count <= 1)
		{
			ImGui.EndDisabled();
		}
		ImGui.Separator();
		if (ImGui.Button("Add selected##ibadd"))
		{
			try
			{
				WorldObject o = Globals.Core.WorldFilter[Globals.Core.Actions.CurrentSelection];
				if (o == null)
				{
					Util.WriteToChat("Items: select an item first.");
				}
				else if (_list.Exists((Entry x) => string.Equals(x.Name, o.Name, StringComparison.OrdinalIgnoreCase)))
				{
					Util.WriteToChat("Items: " + o.Name + " is already on the list.");
				}
				else
				{
					_list.Add(new Entry
					{
						Name = o.Name,
						Icon = o.Icon
					});
					Save();
					_countAt = DateTime.MinValue;
				}
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
			}
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Adds the item you have selected (by its name - every stack of it you carry is counted).");
		}
		ImGui.SameLine();
		bool v = _s.ItemBarShow;
		if (ImGui.Checkbox("Show pop-up##ibshow", ref v))
		{
			_s.ItemBarShow = v;
			if (_saveAll != null)
			{
				_saveAll();
			}
		}
		ImGui.SameLine(0f, 16f);
		ImGui.SetNextItemWidth(140f);
		float v2 = _s.ItemBarOpacity;
		if (ImGui.SliderFloat("Opacity##ibop", ref v2, 0f, 1f, "%.2f"))
		{
			_s.ItemBarOpacity = v2;
		}
		if (ImGui.IsItemDeactivatedAfterEdit() && _saveAll != null)
		{
			_saveAll();
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("The pop-up's background (0 = see-through).");
		}
		ImGui.SameLine(0f, 16f);
		ImGui.SetNextItemWidth(140f);
		float v3 = _s.ItemBarScale;
		if (ImGui.SliderFloat("Scale##ibsc", ref v3, 0.5f, 2f, "%.2fx"))
		{
			_s.ItemBarScale = Math.Max(0.5f, Math.Min(2f, v3));
		}
		if (ImGui.IsItemDeactivatedAfterEdit() && _saveAll != null)
		{
			_saveAll();
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("The pop-up's size - icons and numbers (0.5x - 2x).");
		}
		if (_list.Count == 0)
		{
			Im.TextDisabled("Nothing yet - select an item and click Add selected.");
			return;
		}
		int num = -1;
		int num2 = 0;
		int num3 = -1;
		bool flag2 = false;
		if (ImGui.BeginTable("##ibtable", 5, ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit))
		{
			ImGui.TableSetupColumn("On");
			ImGui.TableSetupColumn("");
			ImGui.TableSetupColumn("Item", ImGuiTableColumnFlags.WidthStretch);
			ImGui.TableSetupColumn("Carried");
			ImGui.TableSetupColumn("");
			ImGui.TableHeadersRow();
			for (int num4 = 0; num4 < _list.Count; num4++)
			{
				Entry en = _list[num4];
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				bool v4 = en.On;
				if (ImGui.Checkbox("##ibon" + num4, ref v4))
				{
					en.On = v4;
					flag2 = true;
				}
				ImGui.TableSetColumnIndex(1);
				DrawIcon(en.Icon, ImGui.GetFrameHeight());
				ImGui.TableSetColumnIndex(2);
				ImGui.AlignTextToFramePadding();
				Im.Text(en.Name);
				ImGui.TableSetColumnIndex(3);
				ImGui.AlignTextToFramePadding();
				Im.TextColored(CountColor, en.Count.ToString("N0", CultureInfo.InvariantCulture));
				ImGui.TableSetColumnIndex(4);
				if (num4 == 0)
				{
					ImGui.BeginDisabled();
				}
				if (ImGui.ArrowButton("##ibup" + num4, ImGuiDir.Up))
				{
					num = num4;
					num2 = -1;
				}
				if (num4 == 0)
				{
					ImGui.EndDisabled();
				}
				ImGui.SameLine();
				if (num4 == _list.Count - 1)
				{
					ImGui.BeginDisabled();
				}
				if (ImGui.ArrowButton("##ibdn" + num4, ImGuiDir.Down))
				{
					num = num4;
					num2 = 1;
				}
				if (num4 == _list.Count - 1)
				{
					ImGui.EndDisabled();
				}
				ImGui.SameLine();
				if (ImGui.SmallButton(((_editIdx == num4) ? "Close" : "Edit") + "##ibed" + num4))
				{
					if (_editIdx == num4)
					{
						_editIdx = -1;
					}
					else
					{
						_editIdx = num4;
						_editName = en.Name;
						_editIcon = en.Icon;
					}
				}
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip("Change the item's name (what's counted) or its icon");
				}
				ImGui.SameLine();
				if (ImGui.SmallButton("x##ibdel" + num4))
				{
					num3 = num4;
				}
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip("Take it off the list");
				}
				if (_editIdx != num4)
				{
					continue;
				}
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(1);
				DrawIcon(_editIcon, ImGui.GetFrameHeight());
				ImGui.TableSetColumnIndex(2);
				ImGui.SetNextItemWidth(-1f);
				ImGui.InputText("##ibedname" + num4, ref _editName, 128u);
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip("The exact name as the game shows it - every stack with this name in your pack is counted.");
				}
				ImGui.TableSetColumnIndex(3);
				if (ImGui.SmallButton("Icon from selected##ibedic" + num4))
				{
					WorldObject worldObject = null;
					try
					{
						worldObject = CoreManager.Current.WorldFilter[CoreManager.Current.Actions.CurrentSelection];
					}
					catch
					{
					}
					if (worldObject != null)
					{
						try
						{
							_editIcon = worldObject.Icon;
						}
						catch
						{
						}
					}
					else
					{
						Util.WriteToChat("Items: select an item first.");
					}
				}
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip("Uses the icon of the item you have selected.");
				}
				ImGui.TableSetColumnIndex(4);
				if (ImGui.SmallButton("Save##ibedok" + num4))
				{
					string nm = (_editName ?? "").Trim();
					if (nm.Length == 0)
					{
						Util.WriteToChat("Items: the name can't be empty.");
					}
					else if (_list.Exists((Entry x) => x != en && string.Equals(x.Name, nm, StringComparison.OrdinalIgnoreCase)))
					{
						Util.WriteToChat("Items: " + nm + " is already on the list.");
					}
					else
					{
						bool flag3 = !string.Equals(en.Name, nm, StringComparison.OrdinalIgnoreCase);
						en.Name = nm;
						en.Icon = ((!flag3 || _editIcon != en.Icon) ? _editIcon : 0);
						_editIdx = -1;
						flag2 = true;
						_countAt = DateTime.MinValue;
					}
				}
				ImGui.SameLine();
				if (ImGui.SmallButton("Cancel##ibedno" + num4))
				{
					_editIdx = -1;
				}
			}
			ImGui.EndTable();
		}
		if (num >= 0)
		{
			int index = num + num2;
			Entry value = _list[num];
			_list[num] = _list[index];
			_list[index] = value;
			flag2 = true;
		}
		if (num >= 0 || num3 >= 0)
		{
			_editIdx = -1;
		}
		if (num3 >= 0)
		{
			_list.RemoveAt(num3);
			flag2 = true;
		}
		if (flag2)
		{
			Save();
		}
	}
}
