using System;
using System.Numerics;
using ImGuiNET;
using UtilityBelt.Service;
using UtilityBelt.Service.Views;

namespace MelkTank;

/// <summary>
/// Session > Lum's pop-out: a window of its own that stays open. Rate: what's banked (luminance and coins) and every
/// rate from the Lum tab, with /b d and /clap all. Tx: everything of one kind - coins or luminance - to a character
/// (the same names as Session > Bank's transfers).
/// </summary>
public static class LumPopout
{
    private static Hud _hud;
    private static readonly Vector4 Cyan = new Vector4(0.35f, 0.85f, 0.95f, 1f), Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f), Gold = new Vector4(0.95f, 0.8f, 0.3f, 1f);

    public static bool Open => _hud != null && _hud.Visible;

    /// <summary>Shown or hidden (kept per character, so it's back after a relog).</summary>
    public static void Show(bool on)
    {
        Settings s = PluginCore.CurrentSettings;
        if (s != null && s.LumPopOut != on) { s.LumPopOut = on; PluginCore.SaveAllNow(); }
        if (on && _hud == null)
        {
            _hud = UBService.Huds.CreateHud("MelkTank Lum", BarIcon.Make("Lum"));
            _hud.ShowInBar = false;
            // (sized by you - the grip at its bottom right corner - and kept; no longer sizing itself to what's in it)
            _hud.WindowSettings = ImGuiWindowFlags.NoCollapse;
            _hud.OnPreRender += PreRender;
            _hud.OnRender += Render;
        }
        if (_hud != null) _hud.Visible = on;
    }

    /// <summary>At login: open again if it was open.</summary>
    public static void Restore(Settings s)
    {
        if (s != null && s.LumPopOut) Show(true);
    }

    /// <summary>Closed with its own X: remembered as closed.</summary>
    public static void Tick()
    {
        Settings s = PluginCore.CurrentSettings;
        if (_hud != null && !_hud.Visible && s != null && s.LumPopOut) { s.LumPopOut = false; PluginCore.SaveAllNow(); }
    }

    public static void Dispose()
    {
        if (_hud == null) return;
        try { _hud.OnPreRender -= PreRender; _hud.OnRender -= Render; _hud.Dispose(); } catch { }
        _hud = null;
    }

    // its size the first time (after that, where you left it)
    private static void PreRender(object sender, EventArgs e)
    {
        try { ImGui.SetNextWindowSize(new Vector2(330f, 380f), ImGuiCond.FirstUseEver); } catch { }
    }

    private static void Render(object sender, EventArgs e)
    {
        try
        {
            WinMem.Frame("Lum");
            // (closed with its own X: remembered as closed)
            Settings s = PluginCore.CurrentSettings;
            if (s == null) { Im.TextDisabled("Not logged in."); return; }
            if (!ImGui.BeginTabBar("lumpoptabs")) return;
            if (ImGui.BeginTabItem("Rate##lumpoprate")) { DrawRate(); ImGui.EndTabItem(); }
            if (ImGui.BeginTabItem("Tx##lumpoptx")) { Session.DrawTransferAll(s); ImGui.EndTabItem(); }
            ImGui.EndTabBar();
        }
        catch (Exception ex)
        {
            Util.LogError(ex);
        }
    }

    private static void DrawRate()
    {
        long lum = Session.BankedLum, coins = Session.BankedCoins;
        Im.Text("Banked Lum");
        ImGui.SameLine(110f);
        Im.TextColored(Gold, lum >= 0 ? (lum >= 1000000 ? Session.Big(lum) : lum.ToString("N0")) : "?");
        if (lum >= 1000000 && ImGui.IsItemHovered()) Im.SetTooltip(lum.ToString("N0"));
        Im.Text("Banked coins");
        ImGui.SameLine(110f);
        Im.TextColored(Gold, coins >= 0 ? coins.ToString("N0") : "?");
        if (lum < 0 || coins < 0)
        {
            ImGui.SameLine();
            Im.TextColored(Grey, "(/b to read the bank)");
        }
        ImGui.Separator();
        LumTrack.DrawRateTable("lumpoprates", compact: true);
        ImGui.Separator();
        if (ImGui.Button("/b d##lumpopbd")) Util.Command("/b d");
        if (ImGui.IsItemHovered()) Im.SetTooltip("/b d - puts what you carry that the bank takes (pyreals, luminance, coins, keys...) into the bank.");
        ImGui.SameLine();
        if (ImGui.Button("/clap all##lumpopclap")) Util.Command("/clap all");
        if (ImGui.IsItemHovered()) Im.SetTooltip("Sends /clap all.");
        ImGui.SameLine();
        if (ImGui.Button("/b##lumpopb")) Util.Command("/b");
        if (ImGui.IsItemHovered()) Im.SetTooltip("/b - reads the bank again (the banked figures above).");
    }
}
