using System;
using System.Collections.Generic;
using System.Numerics;
using System.Reflection;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Loot;

namespace MelkTank;

public static class Dispel
{
	private class Bad
	{
		public int Id;

		public string Name;

		public DateTime At;

		public int Tries;
	}

	private static Settings _s;

	private static readonly Dictionary<int, Bad> _bad = new Dictionary<int, Bad>();

	private static DateTime _usedAt = DateTime.MinValue;

	private static DateTime _checkAt = DateTime.MinValue;

	private static bool _checking;

	private static string _last = "";

	public static Action SaveAll;

	private static string _addName = "";

	public static void Init(Settings s)
	{
		_s = s;
		_bad.Clear();
		_checking = false;
	}

	private static List<string> Ignored()
	{
		List<string> list = new List<string>();
		string[] array = (_s.DispelIgnore ?? "").Split(new char[2] { '\n', '|' }, StringSplitOptions.RemoveEmptyEntries);
		foreach (string text in array)
		{
			if (text.Trim().Length > 0)
			{
				list.Add(text.Trim());
			}
		}
		return list;
	}

	private static bool IsIgnored(string name)
	{
		foreach (string item in Ignored())
		{
			if (string.Equals(item, name, StringComparison.OrdinalIgnoreCase))
			{
				return true;
			}
		}
		return false;
	}

	private static void Ignore(string name)
	{
		if (!IsIgnored(name))
		{
			List<string> list = Ignored();
			list.Add(name);
			_s.DispelIgnore = string.Join("|", list.ToArray());
			if (SaveAll != null)
			{
				SaveAll();
			}
		}
	}

	private static bool Harmful(int spellId, string name)
	{
		if (!(SpellNames.Prop(spellId, "IsDebuff") is bool result))
		{
			string text = (name ?? "").ToLowerInvariant();
			return text.EndsWith(" other") || text.Contains(" other ") || text.Contains("curse") || text.Contains("corrosion") || text.Contains("corruption") || text.Contains("vulnerability") || text.Contains("imperil") || text.Contains("fester") || text.Contains("yield");
		}
		return result;
	}

	public static void OnChangeEnchantments(EventArgs e)
	{
		if (_s == null || !_s.DispelOn)
		{
			return;
		}
		try
		{
			EnchantmentWrapper enchantmentWrapper = null;
			string text = "";
			PropertyInfo property = e.GetType().GetProperty("Enchantment");
			if (property != null)
			{
				enchantmentWrapper = property.GetValue(e, null) as EnchantmentWrapper;
			}
			PropertyInfo property2 = e.GetType().GetProperty("Type");
			if (property2 != null)
			{
				text = Convert.ToString(property2.GetValue(e, null));
			}
			if (enchantmentWrapper == null || enchantmentWrapper.SpellId <= 0)
			{
				return;
			}
			if (text != "Add")
			{
				_bad.Remove(enchantmentWrapper.SpellId);
				return;
			}
			string text2 = SpellNames.Name(enchantmentWrapper.SpellId) ?? ("spell " + enchantmentWrapper.SpellId);
			if (text2.IndexOf("Vitae", StringComparison.OrdinalIgnoreCase) < 0 && Harmful(enchantmentWrapper.SpellId, text2) && !IsIgnored(text2) && !_bad.TryGetValue(enchantmentWrapper.SpellId, out var _))
			{
				_bad[enchantmentWrapper.SpellId] = new Bad
				{
					Id = enchantmentWrapper.SpellId,
					Name = text2,
					At = DateTime.Now
				};
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static bool OnYou(int spellId)
	{
		try
		{
			foreach (EnchantmentWrapper enchantment in CoreManager.Current.CharacterFilter.Enchantments)
			{
				if (enchantment.SpellId == spellId)
				{
					return true;
				}
			}
		}
		catch
		{
		}
		return false;
	}

	private static int FindItem(out string name)
	{
		name = null;
		foreach (WeaponItem item in _s.Items)
		{
			if (item.Kind != WeaponKind.Dispel)
			{
				continue;
			}
			WorldObject worldObject = Globals.Core.WorldFilter[item.Id];
			if (worldObject != null)
			{
				name = item.Name;
				return item.Id;
			}
			try
			{
				foreach (WorldObject item2 in InvCache.All())
				{
					if (string.Equals(item2.Name, item.Name, StringComparison.OrdinalIgnoreCase))
					{
						name = item2.Name;
						return item2.Id;
					}
				}
			}
			catch
			{
			}
		}
		return 0;
	}

	public static void Tick()
	{
		if (_s == null || !_s.DispelOn || !_s.MasterEnabled)
		{
			return;
		}
		try
		{
			if (_checking && DateTime.Now >= _checkAt)
			{
				_checking = false;
				foreach (Bad item in new List<Bad>(_bad.Values))
				{
					if (item.Tries != 0)
					{
						if (!OnYou(item.Id))
						{
							_bad.Remove(item.Id);
						}
						else if (item.Tries >= 2)
						{
							_bad.Remove(item.Id);
							Ignore(item.Name);
							Util.WriteToChat("Dispel: " + item.Name + " stays on after 2 dispels - not trying it again (Main > Dispel to take it off the list).");
						}
					}
				}
			}
			foreach (Bad item2 in new List<Bad>(_bad.Values))
			{
				if (!OnYou(item2.Id) && (DateTime.Now - item2.At).TotalSeconds > 2.0)
				{
					_bad.Remove(item2.Id);
				}
			}
			if (_bad.Count == 0 || _checking || (DateTime.Now - _usedAt).TotalSeconds < (double)Math.Max(1f, _s.DispelCooldownS))
			{
				return;
			}
			int num = FindItem(out var name);
			if (num == 0)
			{
				_last = "no dispel item on the Items tab (or none left)";
				return;
			}
			List<string> list = new List<string>();
			foreach (Bad value in _bad.Values)
			{
				value.Tries++;
				list.Add(value.Name);
			}
			Globals.Core.Actions.UseItem(num, 0);
			_usedAt = DateTime.Now;
			_checking = true;
			_checkAt = DateTime.Now.AddSeconds(2.5);
			_last = DateTime.Now.ToString("HH:mm:ss") + "  " + name + " for " + string.Join(", ", list.ToArray());
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static bool Draw(Action<string> tip)
	{
		bool flag = false;
		Vector4 col = new Vector4(0.6f, 0.6f, 0.6f, 1f);
		Vector4 col2 = new Vector4(0.95f, 0.85f, 0.35f, 1f);
		flag |= ImGui.Checkbox("Auto dispel", ref _s.DispelOn);
		Im.SetTooltipIfHovered("/mt set DispelOn on|off");
		tip("A harmful spell lands on you: the first dispel item on the Items tab (Rune of Dispel, a dispel gem) is used -\nalongside whatever else is going on. Add one: select it in your pack, Items tab > Add selected.");
		ImGui.SameLine();
		ImGui.SetNextItemWidth(90f);
		flag |= ImGui.InputFloat("s between uses##dispcd", ref _s.DispelCooldownS, 1f, 1f, "%.0f");
		Im.SetTooltipIfHovered("/mt set DispelCooldownS <number>");
		if (_s.DispelCooldownS < 1f)
		{
			_s.DispelCooldownS = 1f;
		}
		tip("The item's cooldown (the Rune of Dispel's is 6 s) plus a little.");
		if (FindItem(out var _) == 0)
		{
			Im.TextColored(col2, "No dispel item on the Items tab.");
		}
		if (_bad.Count > 0)
		{
			List<string> list = new List<string>();
			foreach (Bad value in _bad.Values)
			{
				list.Add(value.Name);
			}
			Im.TextColored(col2, "On you: " + string.Join(", ", list.ToArray()));
		}
		if (_last.Length > 0)
		{
			Im.TextColored(col, "Last: " + _last);
		}
		Im.TextColored(col, "Don't try to dispel (they stayed on after 2 dispels):");
		List<string> list2 = Ignored();
		if (list2.Count == 0)
		{
			Im.TextDisabled("  none yet");
		}
		string remove = null;
		foreach (string item in list2)
		{
			ImGui.TextUnformatted("  " + item);
			ImGui.SameLine();
			if (ImGui.SmallButton("x##dig" + item))
			{
				remove = item;
			}
		}
		if (remove != null)
		{
			list2.RemoveAll((string x) => x == remove);
			_s.DispelIgnore = string.Join("|", list2.ToArray());
			flag = true;
		}
		ImGui.SetNextItemWidth(220f);
		ImGui.InputTextWithHint("##dispadd", "spell name", ref _addName, 96u);
		ImGui.SameLine();
		if (ImGui.SmallButton("Add##dispadd") && _addName.Trim().Length > 0)
		{
			list2.Add(_addName.Trim());
			_s.DispelIgnore = string.Join("|", list2.ToArray());
			_addName = "";
			flag = true;
		}
		return flag;
	}
}
