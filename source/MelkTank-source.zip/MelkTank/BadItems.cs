using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;

namespace MelkTank;

public static class BadItems
{
	[UnmanagedFunctionPointer(CallingConvention.ThisCall)]
	private delegate int DeleteObjectFn(int maint, int id);

	private static Settings _s;

	private static readonly Dictionary<int, int> _fails = new Dictionary<int, int>();

	private static readonly Dictionary<int, DateTime> _retryAt = new Dictionary<int, DateTime>();

	private static readonly Queue<int> _scan = new Queue<int>();

	private static int _scanTotal;

	private static int _scanFound;

	private static DateTime _nextAsk = DateTime.MinValue;

	private static bool _scanning;

	public static readonly List<KeyValuePair<int, string>> Found = new List<KeyValuePair<int, string>>();

	public static string Status = "";

	private const int ObjectMaintPtr = 8661724;

	private const int DeleteObjectAt = 5279648;

	public static void Init(Settings s)
	{
		_s = s;
	}

	public static void OnServerMessage(Message m)
	{
		try
		{
			if (m.Type != 63408 || m.Value<int>("event") != 201)
			{
				return;
			}
			int num = m.Value<int>("object");
			if (m.Value<int>("success") != 0)
			{
				_fails.Remove(num);
				_retryAt.Remove(num);
			}
			else if (Carried(num))
			{
				_fails.TryGetValue(num, out var value);
				value++;
				_fails[num] = value;
				if (value < 2)
				{
					_retryAt[num] = DateTime.Now.AddSeconds(1.5);
					return;
				}
				_fails.Remove(num);
				_retryAt.Remove(num);
				Bugged(num);
			}
		}
		catch
		{
		}
	}

	private static bool Carried(int id)
	{
		try
		{
			WorldObject worldObject = CoreManager.Current.WorldFilter[id];
			if (worldObject == null)
			{
				return false;
			}
			int id2 = CoreManager.Current.CharacterFilter.Id;
			if (worldObject.Container == id2 || worldObject.Values(LongValueKey.Wielder, 0) == id2)
			{
				return true;
			}
			WorldObject worldObject2 = ((worldObject.Container != 0) ? CoreManager.Current.WorldFilter[worldObject.Container] : null);
			return worldObject2 != null && worldObject2.Container == id2;
		}
		catch
		{
			return false;
		}
	}

	private static string NameOf(int id)
	{
		try
		{
			WorldObject worldObject = CoreManager.Current.WorldFilter[id];
			return (worldObject != null) ? ItemNames.Of(worldObject) : ("0x" + id.ToString("X8"));
		}
		catch
		{
			return "0x" + id.ToString("X8");
		}
	}

	private static void Bugged(int id)
	{
		string text = NameOf(id);
		if (_scanning)
		{
			_scanFound++;
		}
		if (string.Equals(text, "Dove's Axe", StringComparison.OrdinalIgnoreCase))
		{
			return;
		}
		if (_s != null && _s.BadItemAutoRemove)
		{
			bool flag = Remove(id);
			if (_s.BadItemNotify)
			{
				Util.WriteToChat("Bugged item " + (flag ? "removed: " : "found (couldn't remove it): ") + text);
			}
			if (!flag)
			{
				Remember(id, text);
			}
		}
		else
		{
			Remember(id, text);
			if (_s == null || _s.BadItemNotify)
			{
				Util.WriteToChat("Bugged item found: " + text);
			}
		}
	}

	private static void Remember(int id, string name)
	{
		lock (Found)
		{
			Found.RemoveAll((KeyValuePair<int, string> k) => k.Key == id);
			Found.Add(new KeyValuePair<int, string>(id, name));
		}
	}

#if RETAIL
	public unsafe static bool Remove(int id)
	{
		try
		{
			if (!Carried(id))
			{
				return false;
			}
			int num = *(int*)8661724;
			if (num == 0)
			{
				return false;
			}
			((DeleteObjectFn)Marshal.GetDelegateForFunctionPointer((IntPtr)5279648, typeof(DeleteObjectFn)))(num, id);
			lock (Found)
			{
				Found.RemoveAll((KeyValuePair<int, string> k) => k.Key == id);
			}
			InvCache.Invalidate();
			return true;
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			return false;
		}
	}
#else
	public static bool Remove(int id)
	{
		return false;
	}
#endif

	public static void ScanNow()
	{
		_scan.Clear();
		try
		{
			foreach (WorldObject item in CoreManager.Current.WorldFilter.GetInventory())
			{
				_scan.Enqueue(item.Id);
			}
		}
		catch
		{
		}
		_scanTotal = _scan.Count;
		_scanFound = 0;
		_scanning = true;
		Status = "checking " + _scanTotal + " items...";
		Util.WriteToChat("Bugged items: checking " + _scanTotal + " items...");
	}

	public static void Tick()
	{
		DateTime now = DateTime.Now;
		if (_retryAt.Count > 0)
		{
			List<int> list = new List<int>();
			foreach (KeyValuePair<int, DateTime> item in _retryAt)
			{
				if (now >= item.Value)
				{
					list.Add(item.Key);
				}
			}
			foreach (int item2 in list)
			{
				_retryAt.Remove(item2);
				_retryAt[item2] = DateTime.MaxValue;
				try
				{
					Util.RequestId(item2);
				}
				catch
				{
				}
			}
			if (_retryAt.Count > 50)
			{
				_retryAt.Clear();
				_fails.Clear();
			}
		}
		if (!_scanning || now < _nextAsk)
		{
			return;
		}
		if (_scan.Count == 0)
		{
			if (!(now < _nextAsk.AddSeconds(4.0)) && (_retryAt.Count <= 0 || !(now < _nextAsk.AddSeconds(8.0))))
			{
				_scanning = false;
				Status = "last scan: " + _scanTotal + " items, " + ((_scanFound == 0) ? "none bugged" : (_scanFound + " bugged"));
				Util.WriteToChat("Bugged items: done - " + ((_scanFound == 0) ? "none found." : (_scanFound + " found.")));
			}
			return;
		}
		int id = _scan.Dequeue();
		try
		{
			Util.RequestId(id);
		}
		catch
		{
		}
		_nextAsk = now.AddMilliseconds(100.0);
		Status = "checking... " + (_scanTotal - _scan.Count) + " / " + _scanTotal;
	}

	public static bool Draw(Settings s)
	{
		bool flag = false;
		if (!ImGui.TreeNode("Bugged items###bugitems"))
		{
			return false;
		}
		flag |= ImGui.Checkbox("Remove bugged items##bugauto", ref s.BadItemAutoRemove);
		Im.SetTooltipIfHovered("/mt set BadItemAutoRemove on|off");
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("An item in your inventory the server can't identify (twice) is one the client made up - it can't be moved or\nstacked. It's taken out of the client's own list (nothing is sent to the server; a relog clears it too).\nDove's Axe is never removed.");
		}
		ImGui.SameLine();
		flag |= ImGui.Checkbox("Say when one is found##bugnote", ref s.BadItemNotify);
		Im.SetTooltipIfHovered("/mt set BadItemNotify on|off");
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("A chat line with the item's name.");
		}
		ImGui.SameLine();
		if (ImGui.Button(_scanning ? "Scanning...##bugscan" : "Scan now##bugscan") && !_scanning)
		{
			ScanNow();
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Identify everything you carry to find bugged items (also /mtank clearbugged).\nWithout a scan, any failed ID of something you carry is still caught.");
		}
		if (Status.Length > 0)
		{
			Im.TextDisabled(Status);
		}
		List<KeyValuePair<int, string>> list;
		lock (Found)
		{
			list = new List<KeyValuePair<int, string>>(Found);
		}
		foreach (KeyValuePair<int, string> item in list)
		{
			Im.Text(item.Value);
			if (!string.Equals(item.Value, "Dove's Axe", StringComparison.OrdinalIgnoreCase))
			{
				ImGui.SameLine();
				if (ImGui.SmallButton("Remove##bugrm" + item.Key))
				{
					Remove(item.Key);
				}
			}
		}
		ImGui.TreePop();
		return flag;
	}
}
