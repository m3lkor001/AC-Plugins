using System.Linq;

namespace MelkTank;

public class MonsterRule
{
	public const string DefaultName = "<< DEFAULT >>";

	public string Name;

	public int Priority = 1;

	public bool[] Slots = new bool[MelkTank.Slots.All.Length];

	public DmgType Dmg = DmgType.Auto;

	public DmgType ExVuln = DmgType.Auto;

	public string Weapon = "<AUTO>";

	public string Offhand = "<AUTO>";

	public DmgType PetDmg = DmgType.Auto;

	public bool Alert;

	// what can hurt it: some monsters are immune to magic (banshees, Valley of Death), some only take one kind
	public bool Magic = true;

	public bool Melee = true;

	public bool Missile = true;

	public bool AllAttacks => Magic && Melee && Missile;

	public bool Allows(WeaponKind k)
	{
		return k switch
		{
			WeaponKind.Caster => Magic,
			WeaponKind.Melee => Melee,
			WeaponKind.Missile => Missile,
			_ => true,
		};
	}

	public string AttackText => AllAttacks ? "Any" : string.Join("+", new[] { Magic ? "Magic" : null, Melee ? "Melee" : null, Missile ? "Missile" : null }.Where(x => x != null)) is var t && t.Length > 0 ? t : "None";

	public bool IsDefault => Name == "<< DEFAULT >>";

	public MonsterRule(string name)
	{
		Name = name;
	}

	public bool Has(Slot s)
	{
		// (no spells on what magic can't touch: its debuffs and war slots are skipped)
		return Magic && Slots[(int)s];
	}
}
