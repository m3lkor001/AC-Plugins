using System;
using System.Collections.Generic;
using Decal.Adapter.Wrappers;

namespace MelkTank;

public class Stacker
{
	private class Known
	{
		public int Max;

		public string Key;
	}

	private class Entry
	{
		public WorldObject O;

		public int Id;

		public int Container;

		public int Stack;

		public int Max;

		public string Key;
	}

	private const int EquippedSlotsKey = 10;

	private readonly Settings _s;

	private readonly Action<string> _log;

	private readonly Dictionary<int, int> _tries = new Dictionary<int, int>();

	private readonly Dictionary<int, DateTime> _skipUntil = new Dictionary<int, DateTime>();

	private DateTime _next = DateTime.MinValue;

	private readonly Dictionary<int, Known> _known = new Dictionary<int, Known>();

	private DateTime _knownClearAt = DateTime.MinValue;

	private bool _idle;

	private int _idleVersion;

	private DateTime _idleRecheck = DateTime.MinValue;

	public Stacker(Settings s, Action<string> log)
	{
		_s = s;
		_log = log;
	}

	private static int Stack(WorldObject o)
	{
		try
		{
			int num = o.Values(LongValueKey.StackCount);
			return (num < 1) ? 1 : num;
		}
		catch
		{
			return 1;
		}
	}

	private static int StackMax(WorldObject o)
	{
		try
		{
			return o.Values(LongValueKey.StackMax);
		}
		catch
		{
			return 0;
		}
	}

	private static bool Worn(WorldObject o)
	{
		try
		{
			return o.Values(LongValueKey.EquippedSlots) != 0;
		}
		catch
		{
			return false;
		}
	}

	public void Tick(bool canAct)
	{
		if (!_s.AutoStack)
		{
			_tries.Clear();
			_skipUntil.Clear();
			return;
		}
		DateTime now = DateTime.Now;
		if (now < _next)
		{
			return;
		}
		_next = now.AddMilliseconds(Tuning.V("StackLookMs"));
		int id;
		try
		{
			id = Globals.Core.CharacterFilter.Id;
		}
		catch
		{
			return;
		}
		if (id == 0 || !canAct)
		{
			return;
		}
		if (PackOrganizer.ServerBusy())
		{
			return;
		}
		try
		{
			if (Globals.Core.Actions.BusyState != 0)
			{
				return;
			}
		}
		catch
		{
		}
		int version = InvCache.Version;
		if (_idle && version == _idleVersion && now < _idleRecheck)
		{
			return;
		}
		_idle = false;
		if (now >= _knownClearAt)
		{
			_known.Clear();
			_knownClearAt = now.AddMinutes(2.0);
		}
		List<Entry> list = new List<Entry>();
		List<Entry> list2 = new List<Entry>();
		Dictionary<string, List<Entry>> dictionary = new Dictionary<string, List<Entry>>();
		HashSet<int> hashSet = new HashSet<int>();
		try
		{
			foreach (WorldObject item in InvCache.All())
			{
				if (!_known.TryGetValue(item.Id, out var value))
				{
					value = new Known
					{
						Max = StackMax(item)
					};
					if (value.Max > 1)
					{
						value.Key = item.Type + "|" + item.Name;
					}
					_known[item.Id] = value;
				}
				if (value.Max <= 1)
				{
					continue;
				}
				int container = item.Container;
				if (container != 0 && !Worn(item))
				{
					Entry entry = new Entry
					{
						O = item,
						Id = item.Id,
						Container = container,
						Stack = Stack(item),
						Max = value.Max,
						Key = value.Key
					};
					if (!dictionary.TryGetValue(entry.Key, out var value2))
					{
						value2 = (dictionary[entry.Key] = new List<Entry>());
					}
					value2.Add(entry);
					if (container == id)
					{
						list.Add(entry);
						hashSet.Add(entry.Id);
					}
					else if (entry.Stack < entry.Max)
					{
						list2.Add(entry);
						hashSet.Add(entry.Id);
					}
				}
			}
		}
		catch
		{
			return;
		}
		if (_tries.Count > 0)
		{
			foreach (int item2 in new List<int>(_tries.Keys))
			{
				if (!hashSet.Contains(item2))
				{
					_tries.Remove(item2);
				}
			}
		}
		if (list.Count == 0 && list2.Count == 0)
		{
			Rest(version, now);
			return;
		}
		List<Entry> list4 = new List<Entry>(list);
		list4.AddRange(list2);
		foreach (Entry item3 in list4)
		{
			int id2 = item3.Id;
			List<Entry> list5 = dictionary[item3.Key];
			if (list5.Count < 2)
			{
				continue;
			}
			bool flag = item3.Container == id;
			if (_skipUntil.TryGetValue(id2, out var value3) && now < value3)
			{
				continue;
			}
			WorldObject o = item3.O;
			Entry entry2 = null;
			Entry entry3 = null;
			int stack = item3.Stack;
			foreach (Entry item4 in list5)
			{
				if (item4.Id == id2 || item4.Stack >= item4.Max)
				{
					continue;
				}
				bool flag2 = item4.Stack < stack || (item4.Stack == stack && item4.Id < id2);
				if (item4.Container == id)
				{
					if (!(!flag | flag2) && (entry3 == null || item4.Stack > entry3.Stack))
					{
						entry3 = item4;
					}
				}
				else if (!(!flag & flag2) && (entry2 == null || item4.Stack > entry2.Stack))
				{
					entry2 = item4;
				}
			}
			WorldObject worldObject = entry2?.O;
			WorldObject worldObject2 = entry3?.O;
			if (worldObject == null)
			{
				worldObject = worldObject2;
			}
			if (worldObject == null)
			{
				continue;
			}
			_tries.TryGetValue(id2, out var value4);
			if (value4 >= 3)
			{
				_tries.Remove(id2);
				_skipUntil[id2] = now.AddMinutes(2.0);
				if (_log != null)
				{
					_log("STACK gave up on " + o.Name + " for 2 min");
				}
				continue;
			}
			_tries[id2] = value4 + 1;
			try
			{
				Globals.Core.Actions.MoveItem(id2, worldObject.Id);
			}
			catch (Exception ex)
			{
				Util.LogError(ex);
				_skipUntil[id2] = now.AddMinutes(2.0);
				continue;
			}
			if (_log != null)
			{
				_log("STACK " + o.Name + " x" + Stack(o) + " -> stack of " + Stack(worldObject) + "/" + StackMax(worldObject) + " [" + worldObject.Id + "]");
			}
			_next = now.AddMilliseconds(Tuning.V("StackMoveMs"));
			return;
		}
		Rest(version, now);
	}

	private void Rest(int version, DateTime now)
	{
		_idle = true;
		_idleVersion = version;
		_idleRecheck = now.AddSeconds(60.0);
	}
}
