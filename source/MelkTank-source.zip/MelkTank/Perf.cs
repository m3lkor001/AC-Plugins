using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using Decal.Adapter;

namespace MelkTank;

public static class Perf
{
	public class Part
	{
		public string Name;

		public long Ticks;

		public long Max;

		public int Calls;

		public double MsPerSec;

		public double MaxMs;

		public double AvgMsPerSec;

		public double PeakMs;

		public int CallsPerSec;

		public int Windows;
	}

	private static readonly Dictionary<string, Part> _parts = new Dictionary<string, Part>();

	private static long _windowStart = Stopwatch.GetTimestamp();

	private static readonly double ToMs = 1000.0 / (double)Stopwatch.Frequency;

	private static int _frames;

	public static int FrameNo;

	private static int _windows;

	private static int _logLines;

	private static int _slowLines;

	private static readonly StringBuilder _frameParts = new StringBuilder();

	public static double FrameMsPerSec { get; private set; }

	public static int Fps { get; private set; }

	public static long Begin()
	{
		return Stopwatch.GetTimestamp();
	}

	public static long Lap(string name, long t0)
	{
		long timestamp = Stopwatch.GetTimestamp();
		long num = timestamp - t0;
		if (!_parts.TryGetValue(name, out var value))
		{
			Dictionary<string, Part> parts = _parts;
			Part part = new Part
			{
				Name = name
			};
			value = part;
			parts[name] = part;
		}
		value.Ticks += num;
		value.Calls++;
		// a part that took long enough to be felt as a hitch: written down with the time (MelkTank_Slow.txt)
		double ms = (double)num * ToMs;
		if (ms >= 2.0 && _frameParts.Length < 1500)
		{
			_frameParts.Append(" | ").Append(name.Trim()).Append(' ').Append(ms.ToString("0"));
		}
		if (ms >= 40.0 && !name.StartsWith(" ", StringComparison.Ordinal))
		{
			try
			{
				string path = Util.FullPath("MelkTank_Slow.txt");
				if (++_slowLines % 200 == 0 && File.Exists(path) && new FileInfo(path).Length > 300000)
				{
					File.Delete(path);
				}
				File.AppendAllText(path, DateTime.Now.ToString("HH:mm:ss.fff") + "  " + ms.ToString("0").PadLeft(5) + " ms  " + name.Trim() + "   (this frame, parts of 2 ms+:" + _frameParts.ToString() + ")" + Environment.NewLine);
			}
			catch
			{
			}
		}
		if (num > value.Max)
		{
			value.Max = num;
		}
		return timestamp;
	}

	public static void Frame()
	{
		_frameParts.Clear();
		_frames++;
		FrameNo++;
		long timestamp = Stopwatch.GetTimestamp();
		double num = (double)(timestamp - _windowStart) * ToMs / 1000.0;
		if (num < 5.0)
		{
			return;
		}
		double num2 = 0.0;
		foreach (Part value in _parts.Values)
		{
			value.MsPerSec = (double)value.Ticks * ToMs / num;
			value.MaxMs = (double)value.Max * ToMs;
			if (value.MaxMs > value.PeakMs)
			{
				value.PeakMs = value.MaxMs;
			}
			value.CallsPerSec = (int)Math.Round((double)value.Calls / num);
			value.AvgMsPerSec = ((value.Windows == 0) ? value.MsPerSec : (value.AvgMsPerSec * 0.8 + value.MsPerSec * 0.2));
			value.Windows++;
			if (!value.Name.StartsWith("  ", StringComparison.Ordinal))
			{
				num2 += value.MsPerSec;
			}
			value.Ticks = 0L;
			value.Max = 0L;
			value.Calls = 0;
		}
		FrameMsPerSec = num2;
		Fps = (int)Math.Round((double)_frames / num);
		_frames = 0;
		_windowStart = timestamp;
		if (++_windows != 4 && _windows % 12 != 0)
		{
			return;
		}
		Settings currentSettings = PluginCore.CurrentSettings;
		if (currentSettings != null && currentSettings.PerfLog)
		{
			if (_windows % 12 == 0)
			{
				WriteLogLine();
			}
			WriteFile();
		}
	}

	private static void WriteLogLine()
	{
		try
		{
			string text = "";
			try
			{
				text = CoreManager.Current.CharacterFilter.Name ?? "";
			}
			catch
			{
			}
			if (text.Length == 0)
			{
				return;
			}
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append(DateTime.Now.ToString("yyyy-MM-dd HH:mm")).Append(" | b").Append(474)
				.Append(" | ")
				.Append(FrameMsPerSec.ToString("0.0"))
				.Append(" ms/s | ")
				.Append(Fps)
				.Append(" fps");
			int num = 0;
			foreach (Part item in Sorted())
			{
				if (!item.Name.StartsWith("  ", StringComparison.Ordinal))
				{
					stringBuilder.Append(" | ").Append(item.Name).Append(' ')
						.Append(item.AvgMsPerSec.ToString("0.0"))
						.Append(" (peak ")
						.Append(item.PeakMs.ToString("0"))
						.Append(')');
					if (++num >= 6)
					{
						break;
					}
				}
			}
			string text2 = Util.FullPath("MelkTank_PerfLog_" + text.Replace(' ', '_') + ".txt");
			File.AppendAllText(text2, stringBuilder.ToString() + Environment.NewLine);
			if (++_logLines % 60 == 0)
			{
				FileInfo fileInfo = new FileInfo(text2);
				if (fileInfo.Exists && fileInfo.Length > 307200)
				{
					string[] array = File.ReadAllLines(text2);
					string[] array2 = new string[array.Length / 2];
					Array.Copy(array, array.Length - array2.Length, array2, 0, array2.Length);
					File.WriteAllLines(text2, array2);
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void WriteFile()
	{
		try
		{
			string text = "";
			try
			{
				text = CoreManager.Current.CharacterFilter.Name ?? "";
			}
			catch
			{
			}
			if (text.Length == 0)
			{
				return;
			}
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine("MelkTank timing - " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " - build " + BuildInfo.Label + " - " + text);
			stringBuilder.AppendLine(FrameMsPerSec.ToString("0.0") + " ms of every second (" + (FrameMsPerSec / 10.0).ToString("0.0") + "%) at " + Fps + " fps. Inventory list: " + InvCache.Rebuilds + " rebuilds for " + InvCache.Uses + " uses.");
			stringBuilder.AppendLine("ms/s avg | ms/s now | longest 5s | peak since last write | runs/s | part");
			foreach (Part item in Sorted())
			{
				stringBuilder.AppendLine(item.AvgMsPerSec.ToString("0.00").PadLeft(8) + " | " + item.MsPerSec.ToString("0.00").PadLeft(8) + " | " + item.MaxMs.ToString("0.0").PadLeft(10) + " | " + item.PeakMs.ToString("0.0").PadLeft(21) + " | " + item.CallsPerSec.ToString().PadLeft(6) + " | " + item.Name);
				item.PeakMs = 0.0;
			}
			File.WriteAllText(Util.FullPath("MelkTank_Perf_" + text.Replace(' ', '_') + ".txt"), stringBuilder.ToString());
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static List<Part> Sorted()
	{
		List<Part> list = new List<Part>(_parts.Values);
		list.Sort((Part a, Part b) => b.AvgMsPerSec.CompareTo(a.AvgMsPerSec));
		return list;
	}

	public static string Summary(int top)
	{
		List<Part> list = Sorted();
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("Perf: ").Append(FrameMsPerSec.ToString("0.0")).Append(" ms of every second at ")
			.Append(Fps)
			.Append(" fps (")
			.Append((FrameMsPerSec / 10.0).ToString("0.0"))
			.Append("%)");
		for (int i = 0; i < list.Count && i < top; i++)
		{
			stringBuilder.Append((i == 0) ? " - " : ", ").Append(list[i].Name.Trim()).Append(' ')
				.Append(list[i].AvgMsPerSec.ToString("0.00"))
				.Append(" (max ")
				.Append(list[i].MaxMs.ToString("0.0"))
				.Append(" ms)");
		}
		return stringBuilder.ToString();
	}
}
