using System;
using System.Collections.Generic;
using System.Numerics;
using Decal.Adapter.Wrappers;
using ImGuiNET;

namespace MelkTank;

public class MonsterDbTab
{
	private static readonly Vector4 Grey = new Vector4(0.6f, 0.6f, 0.6f, 1f);

	private static readonly Vector4 Yellow = new Vector4(0.95f, 0.85f, 0.35f, 1f);

	private static readonly Vector4 Green = new Vector4(0.45f, 0.85f, 0.45f, 1f);

	private static readonly Vector4 Cyan = new Vector4(0.45f, 0.8f, 0.95f, 1f);

	private static readonly DmgType[] AllEl = new DmgType[8]
	{
		DmgType.Fire,
		DmgType.Cold,
		DmgType.Lightning,
		DmgType.Acid,
		DmgType.Blade,
		DmgType.Pierce,
		DmgType.Bludgeon,
		DmgType.Void
	};

	private static readonly string[] Views = new string[3] { "My monsters", "VTank monsters", "Species" };

	private int _view;

	private string _filter = "";

	private string _editName;

	private int _editSpecies = -1;

	private List<DmgType> _editRank;

	private string[] _speciesNames;

	private static void Tip(string s)
	{
		Im.SetTooltipIfHovered(s);
	}

	private string[] SpeciesNames()
	{
		if (_speciesNames != null)
		{
			return _speciesNames;
		}
		int speciesCount = MonsterMatch.SpeciesCount;
		_speciesNames = new string[speciesCount];
		_speciesNames[0] = "(unknown)";
		for (int i = 1; i < speciesCount; i++)
		{
			_speciesNames[i] = i + " " + MonsterMatch.SpeciesName(i);
		}
		return _speciesNames;
	}

	private static string Short(List<DmgType> r)
	{
		if (r == null || r.Count == 0)
		{
			return "-";
		}
		List<string> list = new List<string>();
		foreach (DmgType item in r)
		{
			list.Add(item switch
			{
				DmgType.Bludgeon => "Bludg", 
				DmgType.Lightning => "Light", 
				_ => item.ToString(), 
			});
		}
		return string.Join(" > ", list.ToArray());
	}

	private bool Match(string s)
	{
		return _filter.Trim().Length == 0 || (s ?? "").IndexOf(_filter.Trim(), StringComparison.OrdinalIgnoreCase) >= 0;
	}

	public void Draw()
	{
		ImGui.SetNextItemWidth(160f);
		ImGui.Combo("##dbview", ref _view, Views, Views.Length);
		ImGui.SameLine();
		ImGui.SetNextItemWidth(200f);
		ImGui.InputTextWithHint("##dbflt", "filter...", ref _filter, 80u);
		ImGui.SameLine();
		if (ImGui.Button("Add selected monster"))
		{
			WorldObject worldObject = null;
			try
			{
				worldObject = Globals.Core.WorldFilter[Globals.Core.Actions.CurrentSelection];
			}
			catch
			{
			}
			if (worldObject == null || worldObject.ObjectClass != ObjectClass.Monster)
			{
				Util.WriteToChat("Select a monster first.");
			}
			else
			{
				MonsterDb.Entry orAdd = MonsterDb.GetOrAdd(worldObject.Name);
				if (orAdd.Species == 0)
				{
					orAdd.Species = GameInfo.Species(worldObject);
				}
				if (orAdd.MaxHp == 0)
				{
					int num = GameInfo.MaxHealth(worldObject.Name);
					if (num > 0)
					{
						orAdd.MaxHp = num;
					}
				}
				try
				{
					Util.RequestId(worldObject.Id);
				}
				catch
				{
				}
				MonsterDb.Touch(orAdd);
				MonsterDb.Changed(now: true);
				_view = 0;
				_filter = worldObject.Name;
			}
		}
		Tip("Adds the selected monster to your list (and appraises it). Appraised monsters are added on their own too.");
		if (_view == 0)
		{
			DrawMine();
		}
		else if (_view == 1)
		{
			DrawVtank();
		}
		else
		{
			DrawSpecies();
		}
		DrawRankEditor();
	}

	private void DrawMine()
	{
		List<MonsterDb.Entry> list = new List<MonsterDb.Entry>();
		foreach (MonsterDb.Entry item in MonsterDb.All)
		{
			if (Match(item.Name) || Match(item.Notes) || Match(MonsterMatch.SpeciesName(item.Species)))
			{
				list.Add(item);
			}
		}
		list.Sort((MonsterDb.Entry a, MonsterDb.Entry b) => string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase));
		Im.TextColored(Grey, list.Count + " of " + MonsterDb.Count + " saved (MelkTank_MonsterDb.txt, every character). Yellow = changed by you. Damage order: click to change.");
		float y = ((_editRank != null) ? (-230) : (-4));
		if (!ImGui.BeginTable("dbmine", 8, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY, new Vector2(0f, y)))
		{
			return;
		}
		ImGui.TableSetupColumn("Name", ImGuiTableColumnFlags.WidthFixed, 190f);
		ImGui.TableSetupColumn("Species", ImGuiTableColumnFlags.WidthFixed, 120f);
		ImGui.TableSetupColumn("Max HP", ImGuiTableColumnFlags.WidthFixed, 90f);
		ImGui.TableSetupColumn("Lvl", ImGuiTableColumnFlags.WidthFixed, 40f);
		ImGui.TableSetupColumn("Damage order (best first)", ImGuiTableColumnFlags.WidthFixed, 230f);
		ImGui.TableSetupColumn("Seen", ImGuiTableColumnFlags.WidthFixed, 40f);
		ImGui.TableSetupColumn("Notes", ImGuiTableColumnFlags.WidthStretch);
		ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 22f);
		ImGui.TableSetupScrollFreeze(0, 1);
		ImGui.TableHeadersRow();
		string text = null;
		foreach (MonsterDb.Entry item2 in list)
		{
			ImGui.PushID("m" + item2.Name);
			ImGui.TableNextRow();
			ImGui.TableSetColumnIndex(0);
			ImGui.TextUnformatted(item2.Name);
			if (item2.LastSeen != DateTime.MinValue)
			{
				Tip("Last seen " + item2.LastSeen.ToString("yyyy-MM-dd HH:mm"));
			}
			ImGui.TableSetColumnIndex(1);
			int current_item = ((item2.Species < SpeciesNames().Length && item2.Species >= 0) ? item2.Species : 0);
			if (item2.SpeciesEdited)
			{
				ImGui.PushStyleColor(ImGuiCol.Text, Yellow);
			}
			ImGui.SetNextItemWidth(-1f);
			if (ImGui.Combo("##sp", ref current_item, SpeciesNames(), SpeciesNames().Length))
			{
				item2.Species = current_item;
				item2.SpeciesEdited = true;
				MonsterDb.Touch(item2);
				MonsterDb.Changed(now: true);
			}
			if (item2.SpeciesEdited)
			{
				ImGui.PopStyleColor();
			}
			Tip(item2.SpeciesEdited ? "Set by you - appraisals won't change it. Right-click: back to what the game says." : "From the game's appraisal.");
			if (item2.SpeciesEdited && ImGui.IsItemClicked(ImGuiMouseButton.Right))
			{
				item2.SpeciesEdited = false;
				MonsterDb.Touch(item2);
				MonsterDb.Changed(now: true);
			}
			ImGui.TableSetColumnIndex(2);
			int v = item2.MaxHp;
			if (item2.HpEdited)
			{
				ImGui.PushStyleColor(ImGuiCol.Text, Yellow);
			}
			ImGui.SetNextItemWidth(-1f);
			if (ImGui.InputInt("##hp", ref v, 0, 0))
			{
				item2.MaxHp = Math.Max(0, v);
				item2.HpEdited = true;
				MonsterDb.Touch(item2);
				MonsterDb.Changed(now: true);
			}
			if (item2.HpEdited)
			{
				ImGui.PopStyleColor();
			}
			Tip("Used by maxhp monster rules (when the monster itself hasn't been appraised)." + (item2.HpEdited ? "\nSet by you. Right-click: let appraisals set it again." : ""));
			if (item2.HpEdited && ImGui.IsItemClicked(ImGuiMouseButton.Right))
			{
				item2.HpEdited = false;
				MonsterDb.Touch(item2);
				MonsterDb.Changed(now: true);
			}
			ImGui.TableSetColumnIndex(3);
			Im.TextColored(Grey, (item2.Level > 0) ? item2.Level.ToString() : "-");
			ImGui.TableSetColumnIndex(4);
			bool flag = item2.Ranking.Count > 0;
			List<DmgType> list2 = (flag ? item2.Ranking : GameInfo.Ranking(item2.Name, item2.Species));
			ImGui.PushStyleColor(ImGuiCol.Text, flag ? Yellow : Grey);
			if (ImGui.Selectable(Short(list2) + "##rk", _editName == item2.Name))
			{
				StartEdit(item2.Name, -1, list2);
			}
			ImGui.PopStyleColor();
			string s;
			if (flag)
			{
				s = "Its own order (set by you).";
			}
			else
			{
				s = ((list2.Count > 0) ? ("From its species (" + MonsterMatch.SpeciesName(item2.Species) + ") - click to give it its own.") : "Unknown - click to set it.");
			}
			Tip(s);
			ImGui.TableSetColumnIndex(5);
			Im.TextColored(Grey, item2.Seen.ToString());
			ImGui.TableSetColumnIndex(6);
			string input = item2.Notes;
			ImGui.SetNextItemWidth(-1f);
			if (ImGui.InputText("##nt", ref input, 200u))
			{
				item2.Notes = input;
				MonsterDb.Touch(item2);
				MonsterDb.Changed(now: false);
			}
			if (ImGui.IsItemDeactivatedAfterEdit())
			{
				MonsterDb.Touch(item2);
				MonsterDb.Changed(now: true);
			}
			ImGui.TableSetColumnIndex(7);
			if (ImGui.SmallButton("x"))
			{
				text = item2.Name;
			}
			Tip("Remove from your list (it's added again the next time it's appraised).");
			ImGui.PopID();
		}
		ImGui.EndTable();
		if (text != null)
		{
			MonsterDb.Remove(text);
			if (_editName == text)
			{
				_editRank = null;
			}
		}
	}

	private void DrawVtank()
	{
		List<KeyValuePair<string, int[]>> list = new List<KeyValuePair<string, int[]>>();
		int num = 0;
		foreach (KeyValuePair<string, int[]> vtMember in GameInfo.VtMembers)
		{
			num++;
			if (Match(vtMember.Key) || Match(MonsterMatch.SpeciesName(vtMember.Value[0])))
			{
				list.Add(vtMember);
			}
		}
		list.Sort((KeyValuePair<string, int[]> a, KeyValuePair<string, int[]> b) => string.Compare(a.Key, b.Key, StringComparison.OrdinalIgnoreCase));
		int num2 = 300;
		Im.TextColored(Grey, "VTank's game info (from its gameinfodb, 2025-11-17): " + list.Count + " of " + num + ((list.Count > num2) ? (" - showing the first " + num2 + ", type to narrow it") : "") + ". 'Copy' puts one in your list to change.");
		Im.TextColored(Grey, "Kept in " + GameInfo.DataFile + " - yours to change (read again a few seconds after it's saved; delete it to get the original back)." + ((GameInfo.DataNote.Length > 0) ? ("  " + GameInfo.DataNote) : ""));
		float y = ((_editRank != null) ? (-230) : (-4));
		if (!ImGui.BeginTable("dbvt", 5, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY, new Vector2(0f, y)))
		{
			return;
		}
		ImGui.TableSetupColumn("Name", ImGuiTableColumnFlags.WidthFixed, 230f);
		ImGui.TableSetupColumn("Species", ImGuiTableColumnFlags.WidthFixed, 130f);
		ImGui.TableSetupColumn("Max HP", ImGuiTableColumnFlags.WidthFixed, 70f);
		ImGui.TableSetupColumn("Damage order (best first)", ImGuiTableColumnFlags.WidthStretch);
		ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 50f);
		ImGui.TableSetupScrollFreeze(0, 1);
		ImGui.TableHeadersRow();
		int num3 = 0;
		foreach (KeyValuePair<string, int[]> item in list)
		{
			if (++num3 > num2)
			{
				break;
			}
			ImGui.PushID("v" + item.Key);
			ImGui.TableNextRow();
			ImGui.TableSetColumnIndex(0);
			bool flag = MonsterDb.Get(item.Key) != null;
			if (flag)
			{
				Im.TextColored(Green, item.Key);
			}
			else
			{
				ImGui.TextUnformatted(item.Key);
			}
			if (flag)
			{
				Tip("Also in your list - yours is used.");
			}
			ImGui.TableSetColumnIndex(1);
			ImGui.TextUnformatted(item.Value[0] + " " + MonsterMatch.SpeciesName(item.Value[0]));
			ImGui.TableSetColumnIndex(2);
			ImGui.TextUnformatted(item.Value[1].ToString());
			ImGui.TableSetColumnIndex(3);
			List<DmgType> list2 = GameInfo.VtOverride(item.Key);
			if (list2 != null)
			{
				Im.TextColored(Cyan, Short(list2));
				Tip("Its own exception in VTank's data (not its species' order).");
			}
			else
			{
				Im.TextColored(Grey, Short(GameInfo.VtSpeciesRanking(item.Value[0])));
			}
			ImGui.TableSetColumnIndex(4);
			if (ImGui.SmallButton("Copy"))
			{
				MonsterDb.Entry orAdd = MonsterDb.GetOrAdd(item.Key);
				if (orAdd.Species == 0)
				{
					orAdd.Species = item.Value[0];
				}
				if (orAdd.MaxHp == 0)
				{
					orAdd.MaxHp = item.Value[1];
				}
				if (orAdd.Ranking.Count == 0 && list2 != null)
				{
					orAdd.Ranking = new List<DmgType>(list2);
				}
				MonsterDb.Touch(orAdd);
				MonsterDb.Changed(now: true);
				_view = 0;
				_filter = item.Key;
			}
			ImGui.PopID();
		}
		ImGui.EndTable();
	}

	private void DrawSpecies()
	{
		Im.TextColored(Grey, "Each species' damage order, best first. Yours (yellow) wins over VTank's. Click an order to change it.");
		float y = ((_editRank != null) ? (-230) : (-4));
		if (!ImGui.BeginTable("dbsp", 4, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY, new Vector2(0f, y)))
		{
			return;
		}
		ImGui.TableSetupColumn("Species", ImGuiTableColumnFlags.WidthFixed, 160f);
		ImGui.TableSetupColumn("Damage order (best first)", ImGuiTableColumnFlags.WidthFixed, 300f);
		ImGui.TableSetupColumn("VTank's", ImGuiTableColumnFlags.WidthStretch);
		ImGui.TableSetupColumn("", ImGuiTableColumnFlags.WidthFixed, 50f);
		ImGui.TableSetupScrollFreeze(0, 1);
		ImGui.TableHeadersRow();
		for (int i = 1; i < MonsterMatch.SpeciesCount; i++)
		{
			string text = MonsterMatch.SpeciesName(i);
			if (!Match(text) && !Match(i.ToString()))
			{
				continue;
			}
			ImGui.PushID("s" + i);
			ImGui.TableNextRow();
			ImGui.TableSetColumnIndex(0);
			ImGui.TextUnformatted(i + " " + text);
			ImGui.TableSetColumnIndex(1);
			bool flag = MonsterDb.HasSpeciesRanking(i);
			List<DmgType> list = GameInfo.SpeciesRanking(i);
			ImGui.PushStyleColor(ImGuiCol.Text, flag ? Yellow : Vector4.One);
			if (ImGui.Selectable(Short(list) + "##srk", _editSpecies == i))
			{
				StartEdit(null, i, list);
			}
			ImGui.PopStyleColor();
			ImGui.TableSetColumnIndex(2);
			Im.TextColored(Grey, Short(GameInfo.VtSpeciesRanking(i)));
			ImGui.TableSetColumnIndex(3);
			if (flag && ImGui.SmallButton("reset"))
			{
				MonsterDb.SetSpeciesRanking(i, null);
				if (_editSpecies == i)
				{
					_editRank = null;
				}
			}
			if (flag)
			{
				Tip("Back to VTank's order.");
			}
			ImGui.PopID();
		}
		ImGui.EndTable();
	}

	private void StartEdit(string name, int species, List<DmgType> current)
	{
		_editName = name;
		_editSpecies = species;
		_editRank = new List<DmgType>(current ?? new List<DmgType>());
	}

	private void DrawRankEditor()
	{
		if (_editRank == null)
		{
			return;
		}
		ImGui.Separator();
		Im.TextColored(Cyan, "Damage order for " + ((_editName != null) ? _editName : ("species " + _editSpecies + " " + MonsterMatch.SpeciesName(_editSpecies))) + " - best first. Auto damage uses the first one you have a wand / weapon for.");
		if (ImGui.BeginChild("rkedit", new Vector2(0f, 170f), border: true))
		{
			int num = -1;
			int num2 = -1;
			int num3 = -1;
			for (int i = 0; i < _editRank.Count; i++)
			{
				ImGui.PushID("r" + i);
				ImGui.TextUnformatted(i + 1 + ". " + _editRank[i]);
				ImGui.SameLine(130f);
				if (i > 0)
				{
					if (Im.SmallUp("^"))
					{
						num = i;
					}
				}
				else
				{
					ImGui.Dummy(new Vector2(18f, 1f));
				}
				ImGui.SameLine();
				if (i < _editRank.Count - 1)
				{
					if (Im.SmallDown("v"))
					{
						num2 = i;
					}
				}
				else
				{
					ImGui.Dummy(new Vector2(18f, 1f));
				}
				ImGui.SameLine();
				if (ImGui.SmallButton("x"))
				{
					num3 = i;
				}
				ImGui.PopID();
			}
			if (num > 0)
			{
				DmgType value = _editRank[num];
				_editRank[num] = _editRank[num - 1];
				_editRank[num - 1] = value;
			}
			if (num2 >= 0)
			{
				DmgType value2 = _editRank[num2];
				_editRank[num2] = _editRank[num2 + 1];
				_editRank[num2 + 1] = value2;
			}
			if (num3 >= 0)
			{
				_editRank.RemoveAt(num3);
			}
			bool flag = true;
			DmgType[] allEl = AllEl;
			for (int j = 0; j < allEl.Length; j++)
			{
				DmgType item = allEl[j];
				if (!_editRank.Contains(item))
				{
					if (!flag)
					{
						ImGui.SameLine();
					}
					flag = false;
					if (ImGui.SmallButton("+ " + item))
					{
						_editRank.Add(item);
					}
				}
			}
			if (!flag)
			{
				Tip("Add it at the end. Leave out what it's immune to.");
			}
		}
		ImGui.EndChild();
		if (ImGui.Button("Save order"))
		{
			if (_editName != null)
			{
				MonsterDb.Entry orAdd = MonsterDb.GetOrAdd(_editName);
				orAdd.Ranking = new List<DmgType>(_editRank);
				MonsterDb.Touch(orAdd);
				MonsterDb.Changed(now: true);
			}
			else
			{
				MonsterDb.SetSpeciesRanking(_editSpecies, _editRank);
			}
			_editRank = null;
			_editName = null;
			_editSpecies = -1;
		}
		ImGui.SameLine();
		if (_editName != null && ImGui.Button("Use the species' order"))
		{
			MonsterDb.Entry entry = MonsterDb.Get(_editName);
			if (entry != null)
			{
				entry.Ranking.Clear();
				MonsterDb.Touch(entry);
				MonsterDb.Changed(now: true);
			}
			_editRank = null;
			_editName = null;
		}
		if (_editName != null)
		{
			Tip("Clears its own order: it follows its species again.");
		}
		ImGui.SameLine();
		if (ImGui.Button("Cancel"))
		{
			_editRank = null;
			_editName = null;
			_editSpecies = -1;
		}
	}
}
