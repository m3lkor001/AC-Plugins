using System;
using System.Collections.Generic;
using System.Globalization;
using System.Numerics;
using System.Reflection;
using AcClient;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;
using MelkTank.Loot;

namespace MelkTank;

public static unsafe class NameTags
{
	public class Style
	{
		public bool On = true;

		public int TagColor;

		public float TagSize = 0.15f;

		public int TickerColor;

		public float TickerSize = 0.1f;
	}

	private class Tag
	{
		public int Id;

		public ObjectClass Oc;

		public string Kind;

		public int Heritage;

		public D3DObj Text;

		public D3DObj Ticker;

		public D3DObj Vuln;

		public int VulnIcon = -1;

		public int TextLen;

		public bool VulnVis;

		public float TextH;

		public float VulnSz;

		public float TagSize;

		public float LastSide = float.NaN;

		public bool TextVis;

		public bool TickerVis;

		public bool ShowTicker;

		public bool NeedsProcess = true;

		public int LastLevel = int.MaxValue;

		public int LastMonarch = int.MaxValue;

		public int AssessCount;

		public int DbLevel;

		public float LastAssessRange = float.MaxValue;

		public DateTime NextAssess = DateTime.MinValue;

		public DateTime LastThunk = DateTime.MinValue;
	}

	public static readonly string[] Kinds = new string[7] { "Player", "Pet", "AllegiancePlayer", "Portal", "Npc", "Vendor", "Monster" };

	private static readonly string[] Labels = new string[7] { "Players", "Pets", "Allegiance players", "Portals", "NPCs", "Vendors", "Monsters" };

	private static readonly Dictionary<string, Style> _styles = new Dictionary<string, Style>();

	private static string _stylesFrom;

	private static readonly Dictionary<int, Tag> _tags = new Dictionary<int, Tag>();

	private static bool _on;

	private static bool _restyle;

	private static bool _rebuild;

	private static DateTime _scanAt = DateTime.MinValue;

	private static bool _frameHooked;

	private static DateTime _frameAt = DateTime.MinValue;

	private static readonly Dictionary<int, int> _vulnIcons = new Dictionary<int, int>();

	private static DateTime _assessGap = DateTime.MinValue;

	private static Style Def(string k)
	{
		int num;
		switch (k)
		{
		case "AllegiancePlayer":
		case "Portal":
			num = -16711936;
			break;
		case "Npc":
			num = -256;
			break;
		case "Vendor":
			num = -65281;
			break;
		case "Monster":
			num = -65536;
			break;
		default:
			num = -16711681;
			break;
		}
		Style style = new Style();
		style.TagColor = num;
		style.TickerColor = num;
		return style;
	}

	public static Style StyleFor(Settings s, string kind)
	{
		string text = ((s == null) ? "" : (s.NtStyles ?? ""));
		if (!object.ReferenceEquals(text, _stylesFrom))
		{
			_stylesFrom = text;
			_styles.Clear();
			string[] array = text.Split(new char[1] { ';' });
			foreach (string text2 in array)
			{
				int num = text2.IndexOf(':');
				if (num > 0)
				{
					string[] array2 = text2.Substring(num + 1).Split(new char[1] { ',' });
					if (array2.Length >= 5)
					{
						Style style = new Style();
						style.On = array2[0] != "0";
						int.TryParse(array2[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out style.TagColor);
						float.TryParse(array2[2], NumberStyles.Float, CultureInfo.InvariantCulture, out style.TagSize);
						int.TryParse(array2[3], NumberStyles.Integer, CultureInfo.InvariantCulture, out style.TickerColor);
						float.TryParse(array2[4], NumberStyles.Float, CultureInfo.InvariantCulture, out style.TickerSize);
						_styles[text2.Substring(0, num)] = style;
					}
				}
			}
		}
		if (!_styles.TryGetValue(kind, out var value))
		{
			value = Def(kind);
			_styles[kind] = value;
		}
		return value;
	}

	private static void SaveStyles(Settings s)
	{
		List<string> list = new List<string>();
		string[] kinds = Kinds;
		foreach (string text in kinds)
		{
			Style style = StyleFor(s, text);
			list.Add(text + ":" + ((!style.On) ? "0" : "1") + "," + style.TagColor.ToString(CultureInfo.InvariantCulture) + "," + style.TagSize.ToString("0.###", CultureInfo.InvariantCulture) + "," + style.TickerColor.ToString(CultureInfo.InvariantCulture) + "," + style.TickerSize.ToString("0.###", CultureInfo.InvariantCulture));
		}
		Dictionary<string, Style> dictionary = new Dictionary<string, Style>(_styles);
		s.NtStyles = string.Join(";", list.ToArray());
		_stylesFrom = s.NtStyles;
		_styles.Clear();
		foreach (KeyValuePair<string, Style> item in dictionary)
		{
			_styles[item.Key] = item.Value;
		}
		_restyle = true;
	}

	private static bool KindOn(Settings s, ObjectClass oc)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Invalid comparison between Unknown and I4
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Invalid comparison between Unknown and I4
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Invalid comparison between Unknown and I4
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Invalid comparison between Unknown and I4
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Invalid comparison between Unknown and I4
		if ((int)oc == 24)
		{
			return StyleFor(s, "Player").On || StyleFor(s, "AllegiancePlayer").On;
		}
		if ((int)oc == 5)
		{
			return StyleFor(s, "Monster").On || StyleFor(s, "Pet").On;
		}
		string text;
		if ((int)oc == 14)
		{
			text = "Portal";
		}
		else if ((int)oc == 37)
		{
			text = "Npc";
		}
		else
		{
			text = (((int)oc != 25) ? null : "Vendor");
		}
		return text != null && StyleFor(s, text).On;
	}

	public static void Tick(Settings s)
	{
		//IL_025f: Unknown result type (might be due to invalid IL or missing references)
		bool flag = s != null && s.NtEnabled && LoggedIn() && !UbTagsOn() && !VideoKill.Blanked;
		if (flag != _on)
		{
			if (flag)
			{
				Start();
			}
			else
			{
				Stop();
			}
		}
		if (!_on)
		{
			return;
		}
		try
		{
			if (_rebuild)
			{
				_rebuild = false;
				foreach (Tag value3 in _tags.Values)
				{
					Drop(value3);
				}
				_tags.Clear();
				_scanAt = DateTime.MinValue;
			}
			List<int> list = new List<int>();
			foreach (Tag value4 in _tags.Values)
			{
				if (!Update(s, value4, force: false))
				{
					list.Add(value4.Id);
				}
			}
			foreach (int item in list)
			{
				if (_tags.TryGetValue(item, out var value))
				{
					Drop(value);
					_tags.Remove(item);
				}
			}
			if (_restyle)
			{
				_restyle = false;
				foreach (Tag value5 in _tags.Values)
				{
					Display(s, value5);
				}
				_scanAt = DateTime.MinValue;
			}
			if (!(DateTime.Now >= _scanAt))
			{
				return;
			}
			_scanAt = DateTime.Now.AddSeconds(2.0);
			int id = CoreManager.Current.CharacterFilter.Id;
			foreach (WorldObject item2 in CoreManager.Current.WorldFilter.GetLandscape())
			{
				if (item2 == null || item2.Id == id)
				{
					continue;
				}
				bool flag2 = KindOn(s, item2.ObjectClass);
				if (_tags.TryGetValue(item2.Id, out var value2))
				{
					if (!flag2)
					{
						Drop(value2);
						_tags.Remove(item2.Id);
					}
				}
				else if (flag2)
				{
					Add(s, item2);
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static bool LoggedIn()
	{
		try
		{
			return CoreManager.Current.CharacterFilter.LoginStatus == 3;
		}
		catch
		{
			return false;
		}
	}

	public static bool UbTagsOn()
	{
		try
		{
			Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
			foreach (Assembly assembly in assemblies)
			{
				if (assembly.FullName.StartsWith("UtilityBelt,", StringComparison.Ordinal))
				{
					Type type = assembly.GetType("UtilityBelt.Tools.Nametags");
					FieldInfo fieldInfo = ((!(type != null)) ? null : type.GetField("enabled", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic));
					if (fieldInfo != null && (bool)fieldInfo.GetValue(null))
					{
						return true;
					}
				}
			}
		}
		catch
		{
		}
		return false;
	}

	private static void Start()
	{
		_on = true;
		_scanAt = DateTime.MinValue;
		HookFrame(on: true);
	}

	public static void Stop()
	{
		_on = false;
		HookFrame(on: false);
		foreach (Tag value in _tags.Values)
		{
			Drop(value);
		}
		_tags.Clear();
	}

	private static void Add(Settings s, WorldObject o)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Invalid comparison between Unknown and I4
		Tag tag = new Tag();
		tag.Id = o.Id;
		tag.Oc = o.ObjectClass;
		tag.Kind = ((object)o.ObjectClass/*cast due to constrained. prefix*/).ToString();
		tag.Heritage = o.Values((LongValueKey)188, -1);
		Tag tag2 = tag;
		D3DService d3DService = CoreManager.Current.D3DService;
		tag2.Text = d3DService.MarkObjectWith3DText(o.Id, o.Name, "Arial", 0);
		tag2.TextLen = (o.Name ?? "").Length;
		tag2.Ticker = d3DService.MarkObjectWith3DText(o.Id, "Loading...", "Arial", 0);
		tag2.Text.OrientToCamera(false);
		tag2.Ticker.OrientToCamera(false);
		tag2.Text.Visible = false;
		tag2.Ticker.Visible = false;
		if ((int)tag2.Oc == 5 && s.NtVulnIcon)
		{
			int num = VulnIconFor(o);
			if (num > 0)
			{
				tag2.VulnIcon = num;
				tag2.Vuln = d3DService.MarkObjectWithIcon(o.Id, num);
				tag2.Vuln.OrientToCamera(false);
				tag2.Vuln.Visible = false;
			}
			else
			{
				tag2.VulnIcon = 0;
			}
		}
		_tags[o.Id] = tag2;
		Update(s, tag2, force: true);
		Display(s, tag2);
	}

	private static void Drop(Tag t)
	{
		try
		{
			if (t.Ticker != null)
			{
				((DisposableByRefObject)t.Ticker).Dispose();
			}
		}
		catch
		{
		}
		try
		{
			if (t.Text != null)
			{
				((DisposableByRefObject)t.Text).Dispose();
			}
		}
		catch
		{
		}
		try
		{
			if (t.Vuln != null)
			{
				((DisposableByRefObject)t.Vuln).Dispose();
			}
		}
		catch
		{
		}
		t.Text = null;
		t.Ticker = null;
		t.Vuln = null;
	}

	private static void Display(Settings s, Tag t)
	{
		if (t.Text == null)
		{
			return;
		}
		Style style = StyleFor(s, t.Kind);
		if (!style.On)
		{
			D3DObj text = t.Text;
			bool visible = false;
			t.Ticker.Visible = visible;
			text.Visible = visible;
			t.TextVis = (t.TickerVis = false);
			if (t.Vuln != null)
			{
				t.Vuln.Visible = false;
				t.VulnVis = false;
			}
			return;
		}
		float num = 1.1f;
		if (t.Heritage == 8)
		{
			num += 0.21f;
		}
		else if (t.Heritage > 5 && t.Heritage < 10 && t.Heritage != 7)
		{
			num += 0.1f;
		}
		t.Ticker.Color = style.TickerColor;
		t.Ticker.Scale(style.TickerSize);
		t.Ticker.Anchor(t.Id, num, 0f, 0f, 0f);
		t.Text.Color = style.TagColor;
		t.Text.Scale(style.TagSize);
		float num2 = num + ((!t.ShowTicker) ? 0f : (t.Ticker.ScaleY / 2f));
		t.Text.Anchor(t.Id, num2, 0f, 0f, 0f);
		if (t.Vuln != null)
		{
			float num3 = Math.Max(0.12f, style.TagSize * 1.2f);
			t.Vuln.Scale(num3);
			t.TextH = num2;
			t.VulnSz = num3;
			t.TagSize = style.TagSize;
			if (s.NtVulnPos == 1)
			{
				PlaceBeside(s, t, force: true);
			}
			else
			{
				t.Vuln.Anchor(t.Id, num2 + style.TagSize * 0.9f + num3 / 2f, 0f, 0f, 0f);
			}
		}
	}

	private static void SetName(Tag t, string text)
	{
		t.Text.SetText((D3DTextType)1, text, "Arial", 0);
		t.TextLen = text.Length;
		t.LastSide = float.NaN;
	}

	private static void HookFrame(bool on)
	{
		try
		{
			if (on && !_frameHooked)
			{
				CoreManager.Current.RenderFrame += OnFrame;
				_frameHooked = true;
			}
			else if (!on && _frameHooked)
			{
				CoreManager.Current.RenderFrame -= OnFrame;
				_frameHooked = false;
			}
		}
		catch
		{
		}
	}

	private static void OnFrame(object sender, EventArgs e)
	{
		try
		{
			if (!_on || (DateTime.Now - _frameAt).TotalMilliseconds < 40.0)
			{
				return;
			}
			_frameAt = DateTime.Now;
			Settings currentSettings = PluginCore.CurrentSettings;
			if (currentSettings == null || currentSettings.NtVulnPos != 1)
			{
				return;
			}
			foreach (Tag value in _tags.Values)
			{
				if (value.VulnVis)
				{
					PlaceBeside(currentSettings, value, force: false);
				}
			}
		}
		catch
		{
		}
	}

	private static void PlaceBeside(Settings s, Tag t, bool force)
	{
		if (t.Vuln == null)
		{
			return;
		}
		int num = 0;
		int num2 = 0;
		try
		{
			num = CoreManager.Current.Actions.Underlying.GetPhysicsObjectPtr(CoreManager.Current.CharacterFilter.Id);
			num2 = CoreManager.Current.Actions.Underlying.GetPhysicsObjectPtr(t.Id);
		}
		catch
		{
		}
		if (num == 0 || num2 == 0)
		{
			return;
		}
		WorldObject val = CoreManager.Current.WorldFilter[CoreManager.Current.CharacterFilter.Id];
		WorldObject val2 = CoreManager.Current.WorldFilter[t.Id];
		if (val == null || val2 == null)
		{
			return;
		}
		CoordsObject val3 = val.Coordinates();
		CoordsObject val4 = val2.Coordinates();
		if (!(val3 == (CoordsObject)null) && !(val4 == (CoordsObject)null))
		{
			float num3 = (float)(val3.EastWest * 240.0);
			float num4 = (float)(val3.NorthSouth * 240.0);
			float num5 = (float)(val4.EastWest * 240.0);
			float num6 = (float)(val4.NorthSouth * 240.0);
			float num7 = 1f;
			try
			{
				num7 = ((CPhysicsObj*)num2)->m_scale;
			}
			catch
			{
			}
			if (!(num7 > 0.2f) || !(num7 < 20f))
			{
				num7 = 1f;
			}
			float num8 = num5 - num3;
			float num9 = num6 - num4;
			float num10 = (float)Math.Sqrt(num8 * num8 + num9 * num9);
			if (num10 < 0.01f)
			{
				num8 = 0f;
				num9 = 1f;
				num10 = 1f;
			}
			num8 /= num10;
			num9 /= num10;
			float num11 = (float)t.TextLen * 0.55f * t.TagSize / 2f + t.TagSize * 0.4f + t.VulnSz / 2f;
			num11 *= s.NtVulnGap * num7;
			float num12 = num9 * num11;
			float num13 = (0f - num8) * num11;
			float num14 = (float)Math.Round(Math.Atan2(num13, num12), 2) + num11;
			if (force || num14 != t.LastSide)
			{
				t.LastSide = num14;
				t.Vuln.Anchor(t.Id, t.TextH, num12, num13, t.TagSize * 0.35f * num7);
			}
		}
	}

	private static int VulnIconFor(WorldObject o)
	{
		List<DmgType> list;
		try
		{
			list = GameInfo.Ranking(o);
		}
		catch
		{
			return 0;
		}
		if (list == null || list.Count == 0)
		{
			return 0;
		}
		int num;
		switch (list[0])
		{
		case DmgType.Fire:
			num = 21;
			break;
		case DmgType.Cold:
			num = 1060;
			break;
		case DmgType.Acid:
			num = 521;
			break;
		case DmgType.Lightning:
			num = 1084;
			break;
		case DmgType.Blade:
			num = 1127;
			break;
		case DmgType.Pierce:
			num = 1151;
			break;
		case DmgType.Bludgeon:
			num = 1048;
			break;
		case DmgType.Void:
			num = 5349;
			break;
		default:
			return 0;
		}
		if (_vulnIcons.TryGetValue(num, out var value))
		{
			return value;
		}
		value = SpellNames.Icon(num);
		if (value > 0)
		{
			_vulnIcons[num] = value;
		}
		return value;
	}

	private unsafe static bool Update(Settings s, Tag t, bool force)
	{
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Invalid comparison between Unknown and I4
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f2: Invalid comparison between Unknown and I4
		//IL_0250: Unknown result type (might be due to invalid IL or missing references)
		//IL_0256: Invalid comparison between Unknown and I4
		if (!force && (DateTime.Now - t.LastThunk).TotalSeconds < 1.0)
		{
			return true;
		}
		t.LastThunk = DateTime.Now;
		WorldObject val = CoreManager.Current.WorldFilter[t.Id];
		if (val == null)
		{
			return false;
		}
		int num = 0;
		try
		{
			num = CoreManager.Current.Actions.Underlying.GetPhysicsObjectPtr(t.Id);
		}
		catch
		{
		}
		if (num == 0)
		{
			return true;
		}
		float num2 = float.MaxValue;
		try
		{
			num2 = *(float*)(num + 32);
		}
		catch
		{
		}
		bool flag = num2 > s.NtMaxRange;
		if (force || (t.NeedsProcess && !flag))
		{
			if ((int)t.Oc == 24)
			{
				if (val.Values((LongValueKey)25, -1) > 0)
				{
					int num3 = val.Values((LongValueKey)25, 1);
					if (num3 != t.LastLevel)
					{
						t.LastLevel = num3;
						SetName(t, val.Name + " [" + num3 + "]");
					}
					int num4 = val.Values((LongValueKey)218103820, 0);
					if (num4 != t.LastMonarch)
					{
						t.LastMonarch = num4;
						if (num4 == 0)
						{
							t.ShowTicker = false;
						}
						else
						{
							if (SharesAllegiance(t.Id, num4))
							{
								t.Kind = "AllegiancePlayer";
							}
							t.ShowTicker = true;
							t.Ticker.SetText((D3DTextType)1, "<" + ((num4 != t.Id) ? val.Values((StringValueKey)21, "") : val.Name) + ">", "Arial", 0);
						}
					}
					t.NeedsProcess = false;
				}
				else
				{
					Assess(t, num2);
				}
			}
			else if ((int)t.Oc == 14)
			{
				if (val.HasIdData)
				{
					t.NeedsProcess = false;
					t.ShowTicker = true;
					t.Ticker.SetText((D3DTextType)1, "<" + val.Values((StringValueKey)38, "") + ">", "Arial", 0);
				}
				else
				{
					Assess(t, num2);
				}
			}
			else if ((int)t.Oc == 5)
			{
				bool flag2 = false;
				try
				{
					ACCWeenieObject* weenieObject = (*CObjectMaint.s_pcInstance)->GetWeenieObject((uint)t.Id);
					flag2 = weenieObject != null && weenieObject->pwd._pet_owner != 0;
				}
				catch
				{
				}
				if (flag2)
				{
					t.Kind = "Pet";
					t.NeedsProcess = false;
				}
				else if (val.Values((LongValueKey)25, -1) > 0)
				{
					t.NeedsProcess = false;
					SetName(t, val.Name + " [" + val.Values((LongValueKey)25, 1) + "]");
				}
				else if (t.DbLevel == 0)
				{
					MonsterDb.Entry entry = MonsterDb.Get(val.Name);
					if (entry != null && entry.Level > 0)
					{
						t.DbLevel = entry.Level;
						SetName(t, val.Name + " [" + entry.Level + "]");
					}
					else
					{
						t.DbLevel = -1;
					}
				}
			}
			else
			{
				t.NeedsProcess = false;
			}
			Display(s, t);
		}
		bool flag3 = StyleFor(s, t.Kind).On;
		if (flag || !flag3)
		{
			if (t.TextVis)
			{
				t.Text.Visible = false;
				t.TextVis = false;
			}
			if (t.TickerVis)
			{
				t.Ticker.Visible = false;
				t.TickerVis = false;
			}
			if (t.VulnVis)
			{
				t.Vuln.Visible = false;
				t.VulnVis = false;
			}
		}
		else
		{
			if (!t.TextVis)
			{
				t.Text.Visible = true;
				t.TextVis = true;
			}
			if (!t.TickerVis && t.ShowTicker)
			{
				t.Ticker.Visible = true;
				t.TickerVis = true;
			}
			if (t.Vuln != null && !t.VulnVis && t.Kind == "Monster")
			{
				t.Vuln.Visible = true;
				t.VulnVis = true;
			}
			else if (t.Vuln != null && t.VulnVis && t.Kind != "Monster")
			{
				t.Vuln.Visible = false;
				t.VulnVis = false;
			}
		}
		return true;
	}

	private static bool SharesAllegiance(int id, int monarch)
	{
		int num = 0;
		try
		{
			num = CoreManager.Current.WorldFilter[CoreManager.Current.CharacterFilter.Id].Values((LongValueKey)218103820, 0);
		}
		catch
		{
		}
		return monarch == num || id == num;
	}

	private static void Assess(Tag t, float range)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Invalid comparison between Unknown and I4
		if ((int)t.Oc == 5)
		{
			t.NeedsProcess = false;
		}
		else if (t.AssessCount > 10)
		{
			t.NeedsProcess = false;
		}
		else
		{
			if (DateTime.Now < t.NextAssess || range >= t.LastAssessRange || DateTime.Now < _assessGap)
			{
				return;
			}
			try
			{
				CombatEngine currentEngine = PluginCore.CurrentEngine;
				if (currentEngine != null && currentEngine.Looter.Busy)
				{
					return;
				}
			}
			catch
			{
			}
			_assessGap = DateTime.Now.AddSeconds(2.0);
			t.LastAssessRange = range;
			t.NextAssess = DateTime.Now.AddSeconds(5.0);
			t.AssessCount++;
			try
			{
				Util.RequestId(t.Id);
			}
			catch
			{
			}
		}
	}

	private static Vector4 ToV(int argb)
	{
		return new Vector4((float)(uint)((argb >>> 16) & 0xFF) / 255f, (float)(uint)((argb >>> 8) & 0xFF) / 255f, (float)(uint)(argb & 0xFF) / 255f, (float)(uint)((argb >>> 24) & 0xFF) / 255f);
	}

	private static int FromV(Vector4 v)
	{
		Func<float, uint> func = (float f) => (uint)Math.Max(0, Math.Min(255, (int)Math.Round(f * 255f)));
		return (int)((func(v.W) << 24) | (func(v.X) << 16) | (func(v.Y) << 8) | func(v.Z));
	}

	public static bool Draw(Settings s)
	{
		bool flag = false;
		flag |= ImGui.Checkbox("Show name tags##nton", ref s.NtEnabled);
		Im.SetTooltipIfHovered("/mt set NtEnabled on|off");
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("Names over players (level, <allegiance>), pets, portals (<where they go>), NPCs, vendors and monsters (level).");
		}
		ImGui.SameLine(0f, 16f);
		ImGui.SetNextItemWidth(140f);
		if (Im.WithTip("/mt set NtMaxRange <number>", ImGui.SliderFloat("Max range (m)##ntrange", ref s.NtMaxRange, 5f, 150f, "%.0f")))
		{
			flag = true;
		}
		ImGui.SameLine(0f, 16f);
		if (Im.WithTip("/mt set NtVulnIcon on|off", ImGui.Checkbox("Vuln icon##ntvuln", ref s.NtVulnIcon)))
		{
			flag = true;
			_rebuild = true;
		}
		if (ImGui.IsItemHovered())
		{
			Im.SetTooltip("A small icon on each monster's tag: the damage type it takes most (from Monsters > DB, else VTank's order).");
		}
		if (s.NtVulnIcon)
		{
			ImGui.SameLine();
			ImGui.SetNextItemWidth(110f);
			if (ImGui.Combo("##ntvulnpos", ref s.NtVulnPos, "Above name\0Beside level\0"))
			{
				flag = true;
				_restyle = true;
			}
			if (s.NtVulnPos == 1)
			{
				ImGui.SameLine();
				ImGui.SetNextItemWidth(110f);
				if (Im.WithTip("/mt set NtVulnGap <number>", ImGui.SliderFloat("Spacing##ntvulngap", ref s.NtVulnGap, 0.5f, 2f, "%.2f")))
				{
					flag = true;
					_restyle = true;
				}
				if (ImGui.IsItemHovered())
				{
					Im.SetTooltip("How far right of the name the icon sits - nudge it if it overlaps the level or floats too far off.");
				}
			}
		}
		if (UbTagsOn())
		{
			Im.TextColored(new Vector4(1f, 0.8f, 0.3f, 1f), "UtilityBelt's own name tags are on, so MelkTank's wait (no doubles).");
			ImGui.SameLine();
			if (ImGui.SmallButton("Turn UB's off##ntuboff"))
			{
				Util.Command("/ub opt set Nametags.Enabled false");
			}
		}
		if (ImGui.BeginTable("##nttbl", 6, (ImGuiTableFlags)8256))
		{
			ImGui.TableSetupColumn("Show");
			ImGui.TableSetupColumn("Kind", (ImGuiTableColumnFlags)8);
			ImGui.TableSetupColumn("Name color");
			ImGui.TableSetupColumn("Name size");
			ImGui.TableSetupColumn("Line 2 color");
			ImGui.TableSetupColumn("Line 2 size");
			ImGui.TableHeadersRow();
			bool flag2 = false;
			for (int i = 0; i < Kinds.Length; i++)
			{
				Style style = StyleFor(s, Kinds[i]);
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				flag2 |= ImGui.Checkbox("##nton" + i, ref style.On);
				ImGui.TableSetColumnIndex(1);
				ImGui.AlignTextToFramePadding();
				Im.Text(Labels[i]);
				ImGui.TableSetColumnIndex(2);
				Vector4 v = ToV(style.TagColor);
				if (ImGui.ColorEdit4("##ntc" + i, ref v, (ImGuiColorEditFlags)65568))
				{
					style.TagColor = FromV(v);
					flag2 = true;
				}
				ImGui.TableSetColumnIndex(3);
				ImGui.SetNextItemWidth(70f);
				if (ImGui.DragFloat("##nts" + i, ref style.TagSize, 0.005f, 0.05f, 1f, "%.2f"))
				{
					flag2 = true;
				}
				ImGui.TableSetColumnIndex(4);
				Vector4 v2 = ToV(style.TickerColor);
				if (ImGui.ColorEdit4("##ntk" + i, ref v2, (ImGuiColorEditFlags)65568))
				{
					style.TickerColor = FromV(v2);
					flag2 = true;
				}
				ImGui.TableSetColumnIndex(5);
				ImGui.SetNextItemWidth(70f);
				if (ImGui.DragFloat("##ntks" + i, ref style.TickerSize, 0.005f, 0.05f, 1f, "%.2f"))
				{
					flag2 = true;
				}
			}
			ImGui.EndTable();
			if (flag2)
			{
				SaveStyles(s);
				flag = true;
			}
		}
		Im.TextColored(new Vector4(0.6f, 0.6f, 0.6f, 1f), "Line 2: <allegiance> over players, <destination> over portals.");
		if (ImGui.Button("Back to UB's colors##ntdef"))
		{
			s.NtStyles = "";
			_stylesFrom = null;
			_restyle = true;
			flag = true;
		}
		return flag;
	}
}
