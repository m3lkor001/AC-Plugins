using System;
using System.IO;
using System.Reflection;

namespace MelkTank;

public static class VTankStandIn
{
	private const string Flag = "MelkTank.VTankStandIn";

	public static bool TankOn = true;

	public static bool VirindiOn = true;

	public const string ServedKey = "MelkTank.VTankServed";

	public static bool VTankOff
	{
		get
		{
			try
			{
				return AppDomain.CurrentDomain.GetData("MelkTank.VTankServed") != null;
			}
			catch
			{
				return false;
			}
		}
	}

	public static void Hook()
	{
		try
		{
			AppDomain currentDomain = AppDomain.CurrentDomain;
			if (currentDomain.GetData("MelkTank.VTankStandIn") is ResolveEventHandler value)
			{
				currentDomain.AssemblyResolve -= value;
			}
			ResolveEventHandler resolveEventHandler = Resolve;
			currentDomain.AssemblyResolve += resolveEventHandler;
			currentDomain.SetData("MelkTank.VTankStandIn", resolveEventHandler);
		}
		catch
		{
		}
	}

	private static Assembly Resolve(object sender, ResolveEventArgs e)
	{
		try
		{
			if (e.Name == null)
			{
				return null;
			}
			string text = e.Name.Split(new char[1] { ',' })[0].Trim();
			if (text.Length == 0 || text.StartsWith("System", StringComparison.OrdinalIgnoreCase) || text.StartsWith("ICSharpCode", StringComparison.OrdinalIgnoreCase) || text.StartsWith("sqlite", StringComparison.OrdinalIgnoreCase))
			{
				return null;
			}
			if ((!string.Equals(text, "uTank2", StringComparison.OrdinalIgnoreCase)) ? (!VirindiOn) : (!TankOn))
			{
				return null;
			}
			Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
			foreach (Assembly assembly in assemblies)
			{
				if (string.Equals(assembly.GetName().Name, text, StringComparison.OrdinalIgnoreCase))
				{
					if (string.Equals(text, "uTank2", StringComparison.OrdinalIgnoreCase))
					{
						Served();
					}
					return assembly;
				}
			}
			bool flag = string.Equals(text, "uTank2", StringComparison.OrdinalIgnoreCase);
			if ((!flag) ? (!VirindiOn) : (!TankOn))
			{
				return null;
			}
			string path = ((!flag) ? (text + ".dll") : "utank2-i.dll");
			string[] array = Roots();
			foreach (string text2 in array)
			{
				if (!Directory.Exists(text2))
				{
					continue;
				}
				string text3 = Path.Combine(Path.Combine(text2, "VirindiTank"), path);
				if (File.Exists(text3))
				{
					if (flag)
					{
						Served();
					}
					return Assembly.LoadFrom(text3);
				}
				string[] directories = Directory.GetDirectories(text2);
				foreach (string path2 in directories)
				{
					text3 = Path.Combine(path2, path);
					if (File.Exists(text3))
					{
						if (flag)
						{
							Served();
						}
						return Assembly.LoadFrom(text3);
					}
				}
			}
		}
		catch
		{
		}
		return null;
	}

	private static void Served()
	{
		try
		{
			AppDomain.CurrentDomain.SetData("MelkTank.VTankServed", "1");
		}
		catch
		{
		}
	}

	private static string[] Roots()
	{
		string text = "";
		try
		{
			text = Path.GetDirectoryName(typeof(VTankStandIn).Assembly.Location) ?? "";
		}
		catch
		{
		}
		if (text.Length == 0)
		{
			try
			{
				text = Util.FullPath("");
			}
			catch
			{
			}
		}
		string text2 = "";
		try
		{
			text2 = Path.GetFullPath(Path.Combine(text, "..\\..\\VirindiPlugins"));
		}
		catch
		{
		}
		return new string[4] { text2, "C:\\Games\\VirindiPlugins", "C:\\Program Files (x86)\\VirindiPlugins", "C:\\Program Files\\VirindiPlugins" };
	}
}
