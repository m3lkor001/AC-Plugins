// the retail build only: names both Decal/UtilityBelt and System define, settled the way the ACGodot build reads them
global using Hud = UtilityBelt.Service.Views.Hud;
global using Vector4 = System.Numerics.Vector4;
global using Message = Decal.Adapter.Message;
global using CM_Combat = AcClient.CM_Combat;
global using CM_Inventory = AcClient.CM_Inventory;
global using CM_Fellowship = AcClient.CM_Fellowship;
global using CM_UI = AcClient.CM_UI;
global using CM_Character = AcClient.CM_Character;
global using ATTACK_HEIGHT = AcClient.ATTACK_HEIGHT;
