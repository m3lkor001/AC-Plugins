using System;
using System.Reflection;
using System.Runtime.InteropServices;
using Decal.Adapter;

namespace MelkTank;

public static class VideoKill
{
	[UnmanagedFunctionPointer(CallingConvention.ThisCall)]
	private delegate void ThisVoid(int self);

	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	private delegate void CdeclVoid();

	private const int DrawEntry = 4544016;

	private static readonly int[] DrawCalls = new int[1] { 4268038 };

	private const string HookedKey = "MelkTank.VideoKillHooked";

	private static readonly ThisVoid OrigDraw = (ThisVoid)Marshal.GetDelegateForFunctionPointer((IntPtr)4544016, typeof(ThisVoid));

	private static readonly ThisVoid SetNormalMode = (ThisVoid)Marshal.GetDelegateForFunctionPointer((IntPtr)4534624, typeof(ThisVoid));

	private static readonly ThisVoid UpdateViewer = (ThisVoid)Marshal.GetDelegateForFunctionPointer((IntPtr)4537728, typeof(ThisVoid));

	private static readonly CdeclVoid DeviceActivate = (CdeclVoid)Marshal.GetDelegateForFunctionPointer((IntPtr)4428528, typeof(CdeclVoid));

	private static readonly CdeclVoid DeviceDeactivate = (CdeclVoid)Marshal.GetDelegateForFunctionPointer((IntPtr)4428576, typeof(CdeclVoid));

	private static ThisVoid _hook;

	private static bool _hooked;

	private static bool _bgOnly;

	private static bool _watching;

	private static readonly bool[] _patched = new bool[2];

	public unsafe static bool Focused => *(byte*)8618391 == 1;

	private unsafe static int ClientHwnd => *(int*)8618404;

	public static bool Blanked
	{
		get
		{
			if (_hooked)
			{
				return !_bgOnly || !Focused;
			}
			if (UbVideoPatch(out var enabled, out var bgOnly) && enabled)
			{
				return !bgOnly || !Focused;
			}
			return false;
		}
	}

	[DllImport("user32.dll")]
	private static extern IntPtr GetForegroundWindow();

	[DllImport("kernel32.dll")]
	private static extern bool VirtualProtect(IntPtr addr, UIntPtr size, uint prot, out uint old);

	public static void Tick(Settings s)
	{
		if (s != null)
		{
			bool videoKill = s.VideoKill;
			_bgOnly = s.VideoKillBgOnly;
			if (videoKill && !_hooked)
			{
				Hook();
			}
			else if (!videoKill && _hooked)
			{
				Unhook();
			}
		}
	}

	private unsafe static int ReadCall(int at)
	{
		return (*(byte*)at == 232) ? (*(int*)(at + 1) + at + 5) : 0;
	}

	private unsafe static bool PatchCall(int at, IntPtr target)
	{
		if (*(byte*)at != 232)
		{
			return false;
		}
		if (!VirtualProtect((IntPtr)at, (UIntPtr)5u, 64u, out var old))
		{
			return false;
		}
		*(int*)(at + 1) = (int)target - (at + 5);
		VirtualProtect((IntPtr)at, (UIntPtr)5u, old, out var _);
		return true;
	}

	private static void Hook()
	{
		try
		{
			object data = AppDomain.CurrentDomain.GetData("MelkTank.VideoKillHooked");
			int num = ReadCall(DrawCalls[0]);
			if (num != 4544016 && (!(data is int) || (int)data != num))
			{
				return;
			}
			_hook = OnDraw;
			IntPtr functionPointerForDelegate = Marshal.GetFunctionPointerForDelegate(_hook);
			bool flag = false;
			for (int i = 0; i < DrawCalls.Length; i++)
			{
				int num2 = ReadCall(DrawCalls[i]);
				if (num2 != 4544016 && (!(data is int) || (int)data != num2))
				{
					_patched[i] = false;
					continue;
				}
				_patched[i] = PatchCall(DrawCalls[i], functionPointerForDelegate);
				flag |= _patched[i];
			}
			if (!flag)
			{
				_hook = null;
				return;
			}
			AppDomain.CurrentDomain.SetData("MelkTank.VideoKillHooked", (int)functionPointerForDelegate);
			_hooked = true;
			if (!_watching)
			{
				CoreManager.Current.WindowMessage += OnWindowMessage;
				_watching = true;
			}
			if (GetForegroundWindow() != (IntPtr)ClientHwnd)
			{
				DeviceDeactivate();
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	public static void Unhook()
	{
		try
		{
			if (_watching)
			{
				try
				{
					CoreManager.Current.WindowMessage -= OnWindowMessage;
				}
				catch
				{
				}
				_watching = false;
			}
			if (!_hooked)
			{
				return;
			}
			for (int i = 0; i < DrawCalls.Length; i++)
			{
				if (_patched[i] && PatchCall(DrawCalls[i], (IntPtr)4544016))
				{
					_patched[i] = false;
				}
			}
			_hooked = false;
			AppDomain.CurrentDomain.SetData("MelkTank.VideoKillHooked", null);
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static void OnDraw(int smartBox)
	{
		try
		{
			if (_bgOnly && Focused)
			{
				OrigDraw(smartBox);
				return;
			}
			SetNormalMode(smartBox);
			UpdateViewer(smartBox);
		}
		catch
		{
		}
	}

	private static void OnWindowMessage(object sender, WindowMessageEventArgs e)
	{
		try
		{
			if (!_hooked)
			{
				return;
			}
			switch (e.Msg)
			{
			case 513:
			case 516:
			case 519:
			case 523:
				if (!Focused)
				{
					DeviceActivate();
				}
				break;
			}
		}
		catch
		{
		}
	}

	private static bool UbVideoPatch(out bool enabled, out bool bgOnly)
	{
		enabled = false;
		bgOnly = false;
		try
		{
			Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
			foreach (Assembly assembly in assemblies)
			{
				if (!assembly.FullName.StartsWith("UtilityBelt.Helper,", StringComparison.Ordinal))
				{
					continue;
				}
				Type type = assembly.GetType("UBHelper.VideoPatch");
				if (!(type == null))
				{
					FieldInfo field = type.GetField("_enabled", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
					FieldInfo field2 = type.GetField("_bgOnly", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
					if (!(field == null))
					{
						enabled = (bool)field.GetValue(null);
						bgOnly = field2 != null && (bool)field2.GetValue(null);
						return true;
					}
				}
			}
		}
		catch
		{
		}
		return false;
	}
}
