using System;
using System.Reflection;

namespace MelkTank;

public static class UbLootWatchFix
{
	private static DateTime _next = DateTime.MinValue;

	private static bool _said;

	public static void Tick(Settings s)
	{
		if (s == null || !s.VtUbLootWatch || DateTime.Now < _next)
		{
			return;
		}
		_next = DateTime.Now.AddSeconds(10.0);
		if (!VTankOff())
		{
			return;
		}
		try
		{
			Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
			foreach (Assembly assembly in assemblies)
			{
				if (!assembly.FullName.StartsWith("UtilityBelt,", StringComparison.Ordinal))
				{
					continue;
				}
				Type type = assembly.GetType("UtilityBelt.UtilityBeltPlugin");
				Type type2 = assembly.GetType("UtilityBelt.Tools.InventoryManager");
				if (type == null || type2 == null)
				{
					continue;
				}
				FieldInfo field = type.GetField("Instance", BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
				object obj = ((!(field != null)) ? null : field.GetValue(null));
				FieldInfo field2 = type.GetField("InventoryManager", BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
				object obj2 = ((obj == null || !(field2 != null)) ? null : field2.GetValue(obj));
				MethodInfo method = type2.GetMethod("Core_RadarUpdate", BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic, null, new Type[1] { typeof(double) }, null);
				if (obj2 == null || method == null)
				{
					continue;
				}
				Assembly[] assemblies2 = AppDomain.CurrentDomain.GetAssemblies();
				foreach (Assembly assembly2 in assemblies2)
				{
					if (!assembly2.FullName.StartsWith("UtilityBelt.Helper,", StringComparison.Ordinal))
					{
						continue;
					}
					Type type3 = assembly2.GetType("UBHelper.Core");
					Type type4 = ((!(type3 != null)) ? null : type3.GetNestedType("Del_RadarUpdate", BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic));
					MethodInfo methodInfo = ((!(type3 != null)) ? null : type3.GetMethod("remove_RadarUpdate", BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic));
					if (!(type4 == null) && !(methodInfo == null))
					{
						Delegate obj3;
						try
						{
							obj3 = Delegate.CreateDelegate(type4, obj2, method);
						}
						catch
						{
							continue;
						}
						methodInfo.Invoke(null, new object[1] { obj3 });
						if (!_said)
						{
							_said = true;
							Util.WriteToChat("VTank off: stopped UtilityBelt waiting for VTank's loot profile (its RadarUpdate errors).");
						}
					}
				}
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
		}
	}

	private static bool VTankOff()
	{
		return VTankStandIn.VTankOff;
	}
}
