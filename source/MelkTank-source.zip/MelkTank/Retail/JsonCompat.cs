// the retail build only (.NET Framework has no System.Text.Json): the two calls Breeding uses, on the framework's own
// JSON serializer. Files written here are read back here only (the retail plugin folder isn't ACGodot's).
using System.IO;
using System.Runtime.Serialization.Json;
using System.Text;

namespace System.Text.Json
{
	public static class JsonSerializer
	{
		public static string Serialize<T>(T value)
		{
			var ser = new DataContractJsonSerializer(typeof(T), new DataContractJsonSerializerSettings { UseSimpleDictionaryFormat = true });
			using (var ms = new MemoryStream())
			{
				ser.WriteObject(ms, value);
				return Encoding.UTF8.GetString(ms.ToArray());
			}
		}

		public static T Deserialize<T>(string json)
		{
			var ser = new DataContractJsonSerializer(typeof(T), new DataContractJsonSerializerSettings { UseSimpleDictionaryFormat = true });
			using (var ms = new MemoryStream(Encoding.UTF8.GetBytes(json ?? "")))
			{
				return (T)ser.ReadObject(ms);
			}
		}
	}
}

namespace System.Text.Json.Serialization
{
	[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
	public sealed class JsonIgnoreAttribute : Attribute
	{
	}
}
