using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;

namespace MelkTank;

public static class MemWatch
{
	private static DateTime _next = DateTime.MinValue;

	private static DateTime _nextLog = DateTime.MinValue;

	private static bool _toldNoLauncher;

	public static long InUse { get; private set; }

	public static DateTime PendingSince { get; private set; } = DateTime.MinValue;

	public static bool Relogging { get; private set; }

	public static double GB => (double)InUse / 1073741824.0;

	private static void LogLine(CombatEngine e)
	{
		string text = "";
		try
		{
			text = Globals.Core.CharacterFilter.Name ?? "";
		}
		catch
		{
		}
		StringBuilder stringBuilder = new StringBuilder();
		string text2 = text;
		foreach (char c in text2)
		{
			stringBuilder.Append((!char.IsLetterOrDigit(c)) ? '_' : c);
		}
		if (stringBuilder.Length == 0)
		{
			return;
		}
		string path = Util.FullPath(string.Concat("MelkTank_MemLog_", stringBuilder, ".csv"));
		long num = 0L;
		long num2 = 0L;
		try
		{
			Process currentProcess = Process.GetCurrentProcess();
			currentProcess.Refresh();
			num = currentProcess.PrivateMemorySize64;
			num2 = currentProcess.WorkingSet64;
		}
		catch
		{
		}
		if (num <= 0)
		{
			num = HotCleanup.PrivateBytes();
		}
		long used = 0L;
		HotCleanup.AddressSpace(out used, out var _);
		long totalMemory = GC.GetTotalMemory(forceFullCollection: false);
		int num3 = 0;
		int num4 = 0;
		Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
		foreach (Assembly assembly in assemblies)
		{
			num4++;
			if (assembly.FullName.StartsWith("MelkTankCore,", StringComparison.Ordinal))
			{
				num3++;
			}
		}
		int num5 = -1;
		int num6 = -1;
		try
		{
			num5 = Globals.Core.WorldFilter.GetAll().Count;
		}
		catch
		{
		}
		try
		{
			num6 = Globals.Core.WorldFilter.GetInventory().Count;
		}
		catch
		{
		}
		long num7 = 0L;
		try
		{
			num7 = Session.Kills;
		}
		catch
		{
		}
		bool flag = !File.Exists(path);
		string text3 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "," + (num >> 20) + "," + (num2 >> 20) + "," + (used >> 20) + "," + (totalMemory >> 20) + "," + Math.Max(0L, num - totalMemory >> 20) + "," + num3 + "," + num4 + "," + num5 + "," + num6 + "," + num7 + "," + GC.CollectionCount(2);
		Util.AppendShared(path, ((!flag) ? "" : ("time,private MB,in use MB,address space MB,.NET heap MB,rest (client + native) MB,MelkTank builds loaded,assemblies,objects known,inventory,kills,gen2 GCs" + Environment.NewLine)) + text3 + Environment.NewLine);
	}

	public static void Tick(Settings s, CombatEngine e)
	{
		if (s == null || e == null || Relogging || DateTime.Now < _next)
		{
			return;
		}
		_next = DateTime.Now.AddSeconds(15.0);
		try
		{
			Process currentProcess = Process.GetCurrentProcess();
			currentProcess.Refresh();
			InUse = currentProcess.WorkingSet64;
		}
		catch
		{
			return;
		}
		if (s.MemLog && DateTime.Now >= _nextLog)
		{
			_nextLog = DateTime.Now.AddSeconds(60.0);
			try
			{
				LogLine(e);
			}
			catch
			{
			}
		}
		if (!s.AutoRelogOn || s.AutoRelogGB <= 0f)
		{
			PendingSince = DateTime.MinValue;
			return;
		}
		if (GB < (double)s.AutoRelogGB)
		{
			PendingSince = DateTime.MinValue;
			_toldNoLauncher = false;
			return;
		}
		if (!Remote.LauncherManaged)
		{
			if (!_toldNoLauncher)
			{
				_toldNoLauncher = true;
				Util.WriteToChat("Memory " + GB.ToString("0.00") + " GB - past " + s.AutoRelogGB.ToString("0.0#") + " GB, but this game wasn't started by the MelkTank launcher, so nothing would start it again: not relogging.");
			}
			PendingSince = DateTime.MinValue;
			return;
		}
		if (PendingSince == DateTime.MinValue)
		{
			PendingSince = DateTime.Now;
			Util.WriteToChat("Memory " + GB.ToString("0.00") + " GB - past " + s.AutoRelogGB.ToString("0.0#") + " GB: relogging at the next calm moment (Settings > Basic > Memory).");
		}
		bool flag = e.CalmNow && s.MasterEnabled;
		int num = Math.Max(1, s.AutoRelogWaitMin);
		bool flag2 = (DateTime.Now - PendingSince).TotalMinutes >= (double)num;
		if (flag || flag2)
		{
			Relogging = true;
			string text = "memory " + GB.ToString("0.00") + " GB" + ((!flag) ? (" (no calm moment in " + num + " min)") : "");
			Util.WriteToChat("Relogging now - " + text + ". The PC service starts the game again.");
			try
			{
				Notes.Add("planned relog - " + text, "auto", quiet: true);
			}
			catch
			{
			}
			Remote.PlannedRelog(text);
		}
	}
}
