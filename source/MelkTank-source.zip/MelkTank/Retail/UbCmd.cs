using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using AcClient;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using MelkTank.Metas;

namespace MelkTank;

public static unsafe class UbCmd
{
	private enum Where
	{
		All,
		Inventory,
		Landscape
	}

	private class GiveStep
	{
		public int Item;

		public int Amount;
	}

	private struct WRECT
	{
		public int L;

		public int T;

		public int R;

		public int B;
	}

	[UnmanagedFunctionPointer(CallingConvention.ThisCall)]
	private delegate void ThisVoid(int self);

	[UnmanagedFunctionPointer(CallingConvention.ThisCall)]
	private delegate float ThisFloat(int self);

	[UnmanagedFunctionPointer(CallingConvention.ThisCall)]
	private delegate void ThisVoidInt(int self, int a);

	[UnmanagedFunctionPointer(CallingConvention.ThisCall)]
	private delegate double ThisDouble(int self);

	[UnmanagedFunctionPointer(CallingConvention.ThisCall)]
	private delegate bool ThisHeading(int self, float deg, int send);

	private enum JState
	{
		Idle,
		Turning,
		Charging,
		Checking
	}

	private static readonly Regex Head = new Regex("^[/@]ub\\s+(?<verb>[a-z]+)\\s*(?<rest>.*)$", RegexOptions.IgnoreCase);

	private static readonly Regex UseRx = new Regex("^(?<one>.+?)(?=\\son|$)( on (?<two>.+))?$");

	private static readonly Regex GiveRx = new Regex("^((?<n>\\d+)? ?(?<item>.+?) to (?<to>.+)|(?<stop>stop|cancel|quit|abort))$");

	private static readonly Queue<GiveStep> _give = new Queue<GiveStep>();

	private static int _giveTarget;

	private static int _giveWaitItem;

	private static int _giveDelayMs;

	private static int _giveDone;

	private static int _giveTotal;

	private static DateTime _giveSent = DateTime.MinValue;

	private static readonly ThisVoid CommenceJump = (ThisVoid)Marshal.GetDelegateForFunctionPointer((IntPtr)5684432, typeof(ThisVoid));

	private static readonly ThisFloat JumpPower = (ThisFloat)Marshal.GetDelegateForFunctionPointer((IntPtr)5684624, typeof(ThisFloat));

	private static readonly ThisVoidInt DoJump = (ThisVoidInt)Marshal.GetDelegateForFunctionPointer((IntPtr)5684816, typeof(ThisVoidInt));

	private static readonly ThisDouble MaxSpeed = (ThisDouble)Marshal.GetDelegateForFunctionPointer((IntPtr)5408960, typeof(ThisDouble));

	private static readonly ThisHeading SetHeading = (ThisHeading)Marshal.GetDelegateForFunctionPointer((IntPtr)5327968, typeof(ThisHeading));

	private static JState _j = JState.Idle;

	private static float _jHeading;

	private static float _jPower;

	private static bool _jShift;

	private static bool _jW;

	private static bool _jX;

	private static bool _jZ;

	private static bool _jC;

	private static DateTime _jAt;

	private static DateTime _jCharge;

	private static DateTime _jTurnAsk;

	private static DateTime _jReleased;

	private static int _jTries;

	private static bool _jAir;

	private static double _jX0;

	private static double _jY0;

	private static double _jZ0;

	private static bool _frameHooked;

	private static readonly Regex JumpRx = new Regex("^((?<h>[\\.\\d]+)\\s+)?(?<ms>\\d+)?$");

	private static float _jStartP;

	private static bool _jRising;

	private static DateTime _jChargeStart;

	public static bool Giving => _giveTarget != 0;

	public static string GiveProgress => (_giveTarget != 0) ? (_giveDone + " of " + _giveTotal + " stacks handed over") : "";

	public static bool Jumping => _j != JState.Idle;

	private unsafe static int CombatSystem => *(int*)8853100;

	private unsafe static int Physics => *(int*)8670568;

	private unsafe static int MotionInterp
	{
		get
		{
			int physics = Physics;
			if (physics == 0)
			{
				return 0;
			}
			int num = *(int*)(physics + 196);
			return (num != 0) ? (*(int*)num) : 0;
		}
	}

	public static bool Try(string command)
	{
		return Try(command, ours: false);
	}

	public static bool Try(string command, bool ours)
	{
		Settings currentSettings = PluginCore.CurrentSettings;
		if (currentSettings == null || (!currentSettings.UbNative && !ours) || string.IsNullOrEmpty(command))
		{
			return false;
		}
		Match match = Head.Match(command.Trim());
		if (!match.Success)
		{
			return false;
		}
		string value = match.Groups["verb"].Value;
		string text = match.Groups["rest"].Value.Trim();
		string text2 = value.ToLowerInvariant();
		try
		{
			if (text2.StartsWith("use"))
			{
				return Use(value.Substring(3), text);
			}
			if (text2.StartsWith("select"))
			{
				return Select(value.Substring(6), text);
			}
			if (text2.StartsWith("give"))
			{
				return Give(value.Substring(4), text);
			}
			if (text2 == "face")
			{
				return Face(text);
			}
			if (text2.StartsWith("jump"))
			{
				return Jump(text2.Substring(4), text);
			}
			switch (text2)
			{
			case "combatstate":
				return CombatStateCmd(text);
			case "fellow":
				return Fellow(text);
			case "resolution":
				return Resolution(text);
			case "mexec":
				if (UbExpr.Own)
				{
					object v = Expr.Eval(text, out var error);
					Util.WriteToChat((error == null) ? ("Result: [" + Expr.TypeName(v) + "] " + Expr.Str(v)) : ("mexec error: " + error));
					return true;
				}
				break;
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			Util.WriteToChat("/ub " + value + ": " + ex.Message);
			return true;
		}
		return false;
	}

	private static WorldObject Special(string name)
	{
		WorldFilter worldFilter = CoreManager.Current.WorldFilter;
		if (int.TryParse(name, out var result) && worldFilter[result] != null)
		{
			return worldFilter[result];
		}
		try
		{
			result = Convert.ToInt32(name, 16);
			if (worldFilter[result] != null)
			{
				return worldFilter[result];
			}
		}
		catch
		{
		}
		if (name == "selected")
		{
			int currentSelection = CoreManager.Current.Actions.CurrentSelection;
			if (currentSelection != 0 && worldFilter[currentSelection] != null)
			{
				return worldFilter[currentSelection];
			}
		}
		return null;
	}

	private static bool NameIs(WorldObject o, string name, bool partial)
	{
		return (!partial) ? ItemNames.Is(o, name) : ItemNames.Contains(o, name);
	}

	private static WorldObject Find(string name, Where where, bool partial, WorldObject exclude = null)
	{
		WorldObject val = Special(name);
		if (val != null)
		{
			return val;
		}
		WorldFilter worldFilter = CoreManager.Current.WorldFilter;
		if (where != Where.Landscape)
		{
			foreach (WorldObject item in worldFilter.GetInventory())
			{
				if (item != null && (exclude == null || item.Id != exclude.Id) && NameIs(item, name, partial))
				{
					return item;
				}
			}
			if (where == Where.All && CoreManager.Current.Actions.OpenedContainer != 0)
			{
				foreach (WorldObject item2 in worldFilter.GetByContainer(CoreManager.Current.Actions.OpenedContainer))
				{
					if (item2 != null && (exclude == null || item2.Id != exclude.Id) && NameIs(item2, name, partial))
					{
						return item2;
					}
				}
			}
			if (where == Where.Inventory)
			{
				return null;
			}
		}
		WorldObject result = null;
		double num = double.MaxValue;
		foreach (WorldObject item3 in worldFilter.GetLandscape())
		{
			if (item3 != null && (exclude == null || item3.Id != exclude.Id) && NameIs(item3, name, partial))
			{
				double num2 = CombatEngine.Distance(item3);
				if (num2 < num)
				{
					num = num2;
					result = item3;
				}
			}
		}
		return result;
	}

	private static WorldObject FindPerson(string name, bool partial, params ObjectClass[] oc)
	{
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		WorldObject val = ((!string.IsNullOrEmpty(name)) ? Special(name) : null);
		if (val != null)
		{
			return val;
		}
		int id = CoreManager.Current.CharacterFilter.Id;
		WorldObject result = null;
		double num = double.MaxValue;
		foreach (WorldObject item in CoreManager.Current.WorldFilter.GetLandscape())
		{
			if (item != null && item.Id != id && Array.IndexOf(oc, item.ObjectClass) >= 0 && (string.IsNullOrEmpty(name) || ((!partial) ? ItemNames.Is(item, name) : ItemNames.Contains(item, name))))
			{
				double num2 = CombatEngine.Distance(item);
				if (num2 < num)
				{
					num = num2;
					result = item;
				}
			}
		}
		return result;
	}

	private static bool Flags(string f, out Where where, out bool partial)
	{
		f = f.ToLowerInvariant();
		partial = f.Contains("p");
		where = (f.Contains("i") ? Where.Inventory : (f.Contains("l") ? Where.Landscape : Where.All));
		if (f.Contains("i") && f.Contains("l"))
		{
			Util.WriteToChat("l and i cannot be used in the same command");
			return false;
		}
		return true;
	}

	private static bool Use(string f, string rest)
	{
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Invalid comparison between Unknown and I4
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Invalid comparison between Unknown and I4
		if (!Flags(f, out var where, out var partial) || rest.Length == 0)
		{
			return true;
		}
		Match match = UseRx.Match(rest);
		string value = match.Groups["one"].Value;
		string value2 = match.Groups["two"].Value;
		WorldObject val = Find(value, where, partial);
		if (val == null)
		{
			Util.WriteToChat("Could not find object: " + value);
			return true;
		}
		if (string.IsNullOrEmpty(value2))
		{
			Util.WriteToChat("using " + val.Name);
			CoreManager.Current.Actions.UseItem(val.Id, 0);
			return true;
		}
		WorldObject val2 = Find(value2, Where.All, partial, val);
		if (val2 == null)
		{
			Util.WriteToChat(value2 + " is null");
			return true;
		}
		Util.WriteToChat("using " + val.Name + " on " + val2.Name);
		if ((int)val.ObjectClass == 31 && (int)CoreManager.Current.Actions.CombatMode == 8)
		{
			CoreManager.Current.Actions.SelectItem(val2.Id);
			CoreManager.Current.Actions.UseItem(val.Id, 1, val2.Id);
		}
		else
		{
			CoreManager.Current.Actions.ApplyItem(val.Id, val2.Id);
		}
		return true;
	}

	private static bool Select(string f, string rest)
	{
		if (!Flags(f, out var where, out var partial) || rest.Length == 0)
		{
			return true;
		}
		WorldObject val = Find(rest, where, partial);
		if (val != null)
		{
			CoreManager.Current.Actions.SelectItem(val.Id);
		}
		return true;
	}

	private static bool Give(string f, string rest)
	{
		Match match = GiveRx.Match(rest);
		if (!match.Success)
		{
			Util.WriteToChat("Usage: /ub give[p][P][r] [count] <item> to <target>");
			return true;
		}
		if (match.Groups["stop"].Success && match.Groups["stop"].Value.Length > 0)
		{
			_give.Clear();
			_giveTarget = 0;
			Util.WriteToChat("give: stopped.");
			return true;
		}
		bool partial = f.Contains("P");
		bool flag = f.Contains("p");
		bool flag2 = f.Contains("r");
		int result = 0;
		if (match.Groups["n"].Success)
		{
			int.TryParse(match.Groups["n"].Value, out result);
		}
		if (result < 1)
		{
			result = int.MaxValue;
		}
		string value = match.Groups["item"].Value;
		string value2 = match.Groups["to"].Value;
		WorldObject val = FindPerson(value2, partial, (ObjectClass)24, (ObjectClass)37);
		if (val == null)
		{
			Util.WriteToChat("give: player " + value2 + " not found");
			return true;
		}
		if (_give.Count > 0)
		{
			Util.WriteToChat("give: already giving - wait, or /ub give stop");
			return true;
		}
		Regex regex = ((!flag2) ? null : new Regex(value));
		long num = result;
		foreach (WorldObject item in CoreManager.Current.WorldFilter.GetInventory())
		{
			if (num <= 0)
			{
				break;
			}
			if (item != null)
			{
				string text = item.Name ?? "";
				bool flag3;
				if (flag2)
				{
					flag3 = regex.IsMatch(text);
				}
				else
				{
					flag3 = ((!flag) ? text.Equals(value, StringComparison.OrdinalIgnoreCase) : (text.IndexOf(value, StringComparison.OrdinalIgnoreCase) >= 0));
				}
				if (flag3)
				{
					int num2 = Math.Max(1, item.Values((LongValueKey)218103814, 1));
					int num3 = (int)Math.Min(num2, num);
					_give.Enqueue(new GiveStep
					{
						Item = item.Id,
						Amount = num3
					});
					num -= num3;
				}
			}
		}
		if (_give.Count == 0)
		{
			Util.WriteToChat("give: no " + value + " in your pack");
			return true;
		}
		_giveTarget = val.Id;
		_giveWaitItem = 0;
		_giveDelayMs = 0;
		_giveDone = 0;
		_giveTotal = _give.Count;
		return true;
	}

	public static string StartGive(int targetId, string itemName, long count, int delayMs)
	{
		if (_give.Count > 0 || _giveTarget != 0)
		{
			return "Already giving - Stop first.";
		}
		WorldObject val = CoreManager.Current.WorldFilter[targetId];
		if (val == null)
		{
			return "The target isn't around any more.";
		}
		long num = ((count <= 0) ? long.MaxValue : count);
		foreach (WorldObject item in CoreManager.Current.WorldFilter.GetInventory())
		{
			if (num <= 0)
			{
				break;
			}
			if (item != null && ItemNames.Is(item, itemName) && item.Values((LongValueKey)10, 0) == 0)
			{
				int num2 = Math.Max(1, item.Values((LongValueKey)218103814, 1));
				int num3 = (int)Math.Min(num2, num);
				_give.Enqueue(new GiveStep
				{
					Item = item.Id,
					Amount = num3
				});
				num -= num3;
			}
		}
		if (_give.Count == 0)
		{
			return "No " + itemName + " in your pack.";
		}
		_giveTarget = targetId;
		_giveWaitItem = 0;
		_giveDelayMs = Math.Max(0, delayMs);
		_giveDone = 0;
		_giveTotal = _give.Count;
		return "Giving " + itemName + " to " + val.Name + " (" + _giveTotal + " stack" + ((_giveTotal != 1) ? "s" : "") + ").";
	}

	public static void StopGive()
	{
		_give.Clear();
		_giveTarget = 0;
		_giveWaitItem = 0;
	}

	private static void GiveTick()
	{
		if (_giveTarget == 0)
		{
			return;
		}
		if (_giveWaitItem != 0)
		{
			WorldObject val = CoreManager.Current.WorldFilter[_giveWaitItem];
			bool flag = val == null || (val.Container != CoreManager.Current.CharacterFilter.Id && !InPack(val));
			if (!flag && (DateTime.Now - _giveSent).TotalSeconds < 3.0)
			{
				return;
			}
			if (flag)
			{
				_giveDone++;
			}
			_giveWaitItem = 0;
		}
		if (_giveDelayMs > 0 && (DateTime.Now - _giveSent).TotalMilliseconds < (double)_giveDelayMs)
		{
			return;
		}
		if (_give.Count == 0)
		{
			_giveTarget = 0;
			return;
		}
		GiveStep giveStep = _give.Dequeue();
		if (CoreManager.Current.WorldFilter[giveStep.Item] != null)
		{
			CM_Inventory.Event_GiveObjectRequest((uint)_giveTarget, (uint)giveStep.Item, (uint)giveStep.Amount);
			_giveWaitItem = giveStep.Item;
			_giveSent = DateTime.Now;
		}
	}

	private static bool InPack(WorldObject o)
	{
		try
		{
			foreach (WorldObject item in CoreManager.Current.WorldFilter.GetInventory())
			{
				if (item.Id == o.Id)
				{
					return true;
				}
			}
		}
		catch
		{
		}
		return false;
	}

	private static bool Face(string rest)
	{
		if (!double.TryParse(rest, NumberStyles.Float, CultureInfo.InvariantCulture, out var result))
		{
			Util.WriteToChat("Invalid heading: " + rest);
			return true;
		}
		CoreManager.Current.Actions.FaceHeading(result, true);
		return true;
	}

	private static bool CombatStateCmd(string rest)
	{
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		CombatState combatMode;
		switch (rest.Trim().ToLowerInvariant())
		{
		case "peace":
			combatMode = (CombatState)1;
			break;
		case "melee":
			combatMode = (CombatState)2;
			break;
		case "missile":
			combatMode = (CombatState)4;
			break;
		case "magic":
			combatMode = (CombatState)8;
			break;
		default:
			Util.WriteToChat("Usage: /ub combatstate (peace|melee|missile|magic)");
			return true;
		}
		CoreManager.Current.Actions.SetCombatMode(combatMode);
		return true;
	}

	private static bool Fellow(string rest)
	{
		string text = rest.ToLowerInvariant();
		switch (text)
		{
		case "quit":
			CM_Fellowship.Event_Quit(0);
			return true;
		case "disband":
			CM_Fellowship.Event_Quit(1);
			return true;
		case "open":
		case "close":
			CM_Fellowship.Event_ChangeFellowOpeness((text == "open") ? 1 : 0);
			return true;
		default:
		{
			Match match = Regex.Match(rest, "^(?<v>recruit|dismiss|leader)(?<p>p)?(?: (?<n>.+))?$", RegexOptions.IgnoreCase);
			if (!match.Success)
			{
				return false;
			}
			string text2 = match.Groups["v"].Value.ToLowerInvariant();
			string text3 = match.Groups["n"].Value.Trim();
			WorldObject val = FindPerson(text3, match.Groups["p"].Success && match.Groups["p"].Value.Length > 0, (ObjectClass)24);
			if (val == null)
			{
				Util.WriteToChat("fellow " + text2 + ": no player " + ((text3.Length <= 0) ? "nearby" : text3));
				return true;
			}
			if (text2 == "recruit")
			{
				CM_Fellowship.Event_Recruit((uint)val.Id);
			}
			else if (text2 == "dismiss")
			{
				CM_Fellowship.Event_Dismiss((uint)val.Id);
			}
			else
			{
				CM_Fellowship.Event_AssignNewLeader((uint)val.Id);
			}
			return true;
		}
		}
	}

	[DllImport("user32.dll")]
	private static extern bool SystemParametersInfo(int action, int param, ref WRECT r, int winIni);

	[DllImport("user32.dll")]
	private static extern bool AdjustWindowRectEx(ref WRECT r, int style, bool menu, int exStyle);

	[DllImport("user32.dll")]
	private static extern int GetWindowLong(IntPtr h, int idx);

	[DllImport("user32.dll")]
	private static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int w, int hgt, int flags);

	private unsafe static bool ResolutionMax(string extra)
	{
		Settings currentSettings = PluginCore.CurrentSettings;
		int num = currentSettings?.ResMaxReserve ?? 0;
		if (int.TryParse((extra ?? "").Trim(), out var result) && result >= 0 && result < 600)
		{
			num = result;
			if (currentSettings != null)
			{
				currentSettings.ResMaxReserve = result;
				try
				{
					PluginCore.SaveAllNow();
				}
				catch
				{
				}
			}
		}
		WRECT r = default;
		if (!SystemParametersInfo(48, 0, ref r, 0))
		{
			Util.WriteToChat("resolution max: couldn't read the desktop size.");
			return true;
		}
		IntPtr hwnd = CoreManager.Current.Decal.Hwnd;
		int windowLong = GetWindowLong(hwnd, -16);
		int windowLong2 = GetWindowLong(hwnd, -20);
		WRECT r2 = default;
		AdjustWindowRectEx(ref r2, windowLong, menu: false, windowLong2);
		int num2 = r.R - r.L - (r2.R - r2.L);
		int num3 = r.B - r.T - (r2.B - r2.T) - num;
		if (num2 < 100 || num3 < 100)
		{
			Util.WriteToChat("resolution max: the desktop came back as " + (r.R - r.L) + "x" + (r.B - r.T) + " - not used.");
			return true;
		}
		Util.WriteToChat("Setting Resolution " + num2 + "x" + num3 + " (desktop " + (r.R - r.L) + "x" + (r.B - r.T) + " less the window frame" + ((num <= 0) ? "" : (" and " + num + " px for the taskbar / title bar")) + ")" + ((num != 0) ? "" : " - if it goes under your taskbar: /mt resolution max <pixels to leave off>, e.g. /mt resolution max 70"));
		*(ushort*)8489828 = (ushort)num3;
		*(ushort*)8489830 = (ushort)num2;
		SetWindowPos(hwnd, IntPtr.Zero, r.L, r.T, 0, 0, 21);
		return true;
	}

	private unsafe static bool Resolution(string rest)
	{
		string text = rest.Trim();
		if (text.Equals("max", StringComparison.OrdinalIgnoreCase) || text.StartsWith("max ", StringComparison.OrdinalIgnoreCase))
		{
			return ResolutionMax(text.Substring(3));
		}
		Match match = Regex.Match(rest, "^(\\d+)[x ](\\d+)$");
		if (!match.Success || !ushort.TryParse(match.Groups[1].Value, out var result) || !ushort.TryParse(match.Groups[2].Value, out var result2) || result < 100 || result2 < 100 || result > 10000 || result2 > 10000)
		{
			Util.WriteToChat("Requested resolution was not valid (" + rest + ")");
			return true;
		}
		Util.WriteToChat("Setting Resolution " + result + "x" + result2);
		*(ushort*)8489828 = result2;
		*(ushort*)8489830 = result;
		return true;
	}

	private static bool Jump(string f, string rest)
	{
		if (_j != JState.Idle)
		{
			Util.WriteToChat("You are already jumping. try again later.");
			return true;
		}
		Match match = JumpRx.Match(rest);
		if (!match.Success)
		{
			Util.WriteToChat("Usage: /ub jump[swzxc] [heading] [holdtime]");
			return true;
		}
		int result = 0;
		if (match.Groups["ms"].Success && match.Groups["ms"].Value.Length > 0 && (!int.TryParse(match.Groups["ms"].Value, out result) || result < 0 || result > 1000))
		{
			Util.WriteToChat("holdtime should be a number between 0 and 1000");
			return true;
		}
		double result2 = CoreManager.Current.Actions.Heading;
		bool flag = false;
		if (match.Groups["h"].Success && match.Groups["h"].Value.Length > 0)
		{
			if (!double.TryParse(match.Groups["h"].Value, NumberStyles.Float, CultureInfo.InvariantCulture, out result2) || result2 < 0.0 || result2 > 359.0)
			{
				Util.WriteToChat("direction should be a number between 0 and 359");
				return true;
			}
			flag = true;
		}
		_jHeading = (float)result2;
		_jPower = Math.Min(1f, (float)result / 1000f);
		_jShift = f.Contains("s");
		_jW = f.Contains("w");
		_jX = f.Contains("x");
		_jZ = f.Contains("z");
		_jC = f.Contains("c");
		_jAt = DateTime.Now;
		_jTries = 0;
		if (flag)
		{
			CoreManager.Current.Actions.FaceHeading(result2, true);
			_jTurnAsk = DateTime.Now;
			_j = JState.Turning;
		}
		else
		{
			StartCharge();
		}
		if (!_frameHooked)
		{
			CoreManager.Current.RenderFrame += OnFrame;
			_frameHooked = true;
		}
		return true;
	}

	private static void StartCharge()
	{
		_j = JState.Charging;
		_jCharge = DateTime.Now;
		_jChargeStart = DateTime.Now;
		int combatSystem = CombatSystem;
		_jStartP = 0f;
		_jRising = false;
		try
		{
			if (combatSystem != 0)
			{
				_jStartP = JumpPower(combatSystem);
			}
		}
		catch
		{
		}
		CommenceJump(combatSystem);
	}

	private static void JumpDone()
	{
		_j = JState.Idle;
		if (_frameHooked)
		{
			try
			{
				CoreManager.Current.RenderFrame -= OnFrame;
			}
			catch
			{
			}
			_frameHooked = false;
		}
	}

	private static void OnFrame(object sender, EventArgs e)
	{
		try
		{
			if ((DateTime.Now - _jAt).TotalSeconds > 20.0)
			{
				Util.WriteToChat("Jump: gave up (took too long).");
				JumpDone();
				return;
			}
			if (_j == JState.Turning)
			{
				double num = Math.Abs(CoreManager.Current.Actions.Heading - (double)_jHeading) % 360.0;
				if (num > 180.0)
				{
					num = 360.0 - num;
				}
				if (num < 1.5)
				{
					StartCharge();
				}
				else if ((DateTime.Now - _jAt).TotalSeconds > 5.0)
				{
					Util.WriteToChat("Jump: turning failed.");
					JumpDone();
				}
				else if ((DateTime.Now - _jTurnAsk).TotalSeconds > 0.5)
				{
					_jTurnAsk = DateTime.Now;
					CoreManager.Current.Actions.FaceHeading((double)_jHeading, true);
				}
				return;
			}
			if (_j == JState.Checking)
			{
				double x;
				double y;
				double z;
				if (Airborne())
				{
					_jAir = true;
				}
				else if (_jAir)
				{
					JumpDone();
				}
				else if (MyPos(out x, out y, out z) && (z - _jZ0 > 0.15 || Math.Abs(x - _jX0) + Math.Abs(y - _jY0) > 0.3))
				{
					JumpDone();
				}
				else if (!((DateTime.Now - _jReleased).TotalSeconds < 1.5))
				{
					if (++_jTries >= 3)
					{
						Util.WriteToChat("Jump: failed to jump 3 times.");
						JumpDone();
					}
					else
					{
						StartCharge();
					}
				}
				return;
			}
			if (_j != JState.Charging)
			{
				JumpDone();
				return;
			}
			int combatSystem = CombatSystem;
			if (combatSystem == 0)
			{
				JumpDone();
				return;
			}
			float num2 = JumpPower(combatSystem);
			if (!_jRising)
			{
				if (!(num2 < _jStartP - 0.001f) && !(num2 < _jPower) && !((DateTime.Now - _jChargeStart).TotalSeconds > 0.25))
				{
					return;
				}
				_jRising = true;
			}
			if (num2 < _jPower)
			{
				if ((DateTime.Now - _jCharge).TotalSeconds > 1.25)
				{
					_jCharge = DateTime.Now;
					CommenceJump(combatSystem);
				}
			}
			else
			{
				MyPos(out _jX0, out _jY0, out _jZ0);
				Release();
				_jReleased = DateTime.Now;
				_jAir = false;
				_j = JState.Checking;
			}
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			JumpDone();
		}
	}

	private unsafe static bool MyPos(out double x, out double y, out double z)
	{
		x = (y = (z = 0.0));
		try
		{
			int physics = Physics;
			if (physics == 0)
			{
				return false;
			}
			CPhysicsObj* ptr = (CPhysicsObj*)physics;
			x = ptr->m_position.frame.m_fOrigin.x;
			y = ptr->m_position.frame.m_fOrigin.y;
			z = ptr->m_position.frame.m_fOrigin.z;
			return true;
		}
		catch
		{
			return false;
		}
	}

	private static bool Airborne()
	{
		try
		{
			int physics = Physics;
			return physics != 0 && (((CPhysicsObj*)physics)->transient_state & 1) == 0;
		}
		catch
		{
			return false;
		}
	}

	private unsafe static void Release()
	{
		int motionInterp = MotionInterp;
		if (motionInterp == 0)
		{
			DoJump(CombatSystem, 1);
			return;
		}
		double num = MaxSpeed(motionInterp) / 4.0;
		if (_jW || _jX)
		{
			if (_jW)
			{
				*(int*)(motionInterp + 76) = 1140850695;
				*(float*)(motionInterp + 80) = ((!_jShift) ? ((float)num) : 1f);
			}
			else
			{
				*(int*)(motionInterp + 76) = 1157627909;
				*(float*)(motionInterp + 80) = ((!_jShift) ? ((float)(-0.65 * num)) : (-1f));
			}
		}
		else
		{
			*(int*)(motionInterp + 76) = 1090519043;
		}
		if (_jZ || _jC)
		{
			*(int*)(motionInterp + 84) = 1694498831;
			double num2 = num * 1.248;
			if (_jShift)
			{
				num2 *= 0.5;
			}
			if (num2 > 3.0)
			{
				num2 = 3.0;
			}
			*(float*)(motionInterp + 88) = ((!_jC) ? ((float)(0.0 - num2)) : ((float)num2));
		}
		else
		{
			*(int*)(motionInterp + 84) = 0;
		}
		*(int*)(motionInterp + 92) = 0;
		SetHeading(Physics, _jHeading, 0);
		DoJump(CombatSystem, 1);
		if (_jZ || _jC)
		{
			*(int*)(motionInterp + 84) = 0;
		}
		if (_jW || _jX)
		{
			*(int*)(motionInterp + 76) = 1090519043;
		}
	}

	public static void Tick()
	{
		try
		{
			GiveTick();
		}
		catch (Exception ex)
		{
			Util.LogError(ex);
			_give.Clear();
			_giveTarget = 0;
		}
	}

	public static void Dispose()
	{
		JumpDone();
		_give.Clear();
		_giveTarget = 0;
	}
}
