using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Runtime.CompilerServices;

namespace MelkTank;

internal static class BarIcon
{
	[CompilerGenerated]
	private static Dictionary<string, int> _003C_003Ef__switch_0024map9;

	public static string LabelFor(string title)
	{
		string text = title ?? "";
		if (text != null)
		{
			if (_003C_003Ef__switch_0024map9 == null)
			{
				Dictionary<string, int> dictionary = new Dictionary<string, int>(7);
				dictionary.Add("MelkTank", 0);
				dictionary.Add("MelksBuffer", 1);
				dictionary.Add("MelksPetSummoner", 2);
				dictionary.Add("MelksLuminanceTracker", 3);
				dictionary.Add("MelksQuestTracker", 4);
				dictionary.Add("MLT Kills", 5);
				dictionary.Add("MLT XP", 6);
				_003C_003Ef__switch_0024map9 = dictionary;
			}
			if (_003C_003Ef__switch_0024map9.TryGetValue(text, out var value))
			{
				switch (value)
				{
				case 0:
					return "Tank";
				case 1:
					return "Buff";
				case 2:
					return "Pet";
				case 3:
					return "Lum";
				case 4:
					return "QB";
				case 5:
					return "Kill";
				case 6:
					return "XP";
				}
			}
		}
		if (text.StartsWith("Melks"))
		{
			text = text.Substring(5);
		}
		text = text.Replace(" ", "");
		return (text.Length <= 4) ? text : text.Substring(0, 4);
	}

	public static Bitmap Make(string label)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected Obj, but got Unknown
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Expected Obj, but got Unknown
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Expected Obj, but got Unknown
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Expected Obj, but got Unknown
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_0228: Expected Obj, but got Unknown
		try
		{
			Bitmap val = new Bitmap(32, 32, (PixelFormat)2498570);
			Graphics val2 = Graphics.FromImage((Image)(object)val);
			try
			{
				val2.SmoothingMode = (SmoothingMode)4;
				val2.TextRenderingHint = (TextRenderingHint)3;
				val2.Clear(Color.Transparent);
				int num = 0;
				foreach (char c in label)
				{
					num = num * 31 + c;
				}
				Color[] array = new Color[6]
				{
					Color.FromArgb(255, 46, 110, 160),
					Color.FromArgb(255, 120, 60, 150),
					Color.FromArgb(255, 40, 130, 90),
					Color.FromArgb(255, 160, 90, 30),
					Color.FromArgb(255, 150, 45, 60),
					Color.FromArgb(255, 70, 90, 110)
				};
				Color color = array[(num & 0x7FFFFFFF) % array.Length];
				SolidBrush val3 = new SolidBrush(color);
				try
				{
					val2.FillRectangle((Brush)(object)val3, 1, 1, 30, 30);
				}
				finally
				{
					((IDisposable)val3)?.Dispose();
				}
				Pen val4 = new Pen(Color.FromArgb(200, 255, 255, 255));
				try
				{
					val2.DrawRectangle(val4, 1, 1, 29, 29);
				}
				finally
				{
					((IDisposable)val4)?.Dispose();
				}
				float num2 = 15f;
				Font val5 = null;
				SizeF sizeF;
				while (true)
				{
					if (val5 != null)
					{
						val5.Dispose();
					}
					val5 = new Font(FontFamily.GenericSansSerif, num2, (FontStyle)1, (GraphicsUnit)2);
					sizeF = val2.MeasureString(label, val5);
					if ((sizeF.Width <= 28f && sizeF.Height <= 28f) || num2 <= 7f)
					{
						break;
					}
					num2--;
				}
				SolidBrush val6 = new SolidBrush(Color.White);
				try
				{
					val2.DrawString(label, val5, (Brush)(object)val6, (32f - sizeF.Width) / 2f, (32f - sizeF.Height) / 2f);
				}
				finally
				{
					((IDisposable)val6)?.Dispose();
				}
				val5.Dispose();
			}
			finally
			{
				((IDisposable)val2)?.Dispose();
			}
			return val;
		}
		catch
		{
			return null;
		}
	}
}
