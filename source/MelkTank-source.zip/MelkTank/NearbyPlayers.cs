using System;
using System.Collections.Generic;
using System.Globalization;
using System.Numerics;
using System.Text;
using Decal.Adapter;
using Decal.Adapter.Wrappers;
using ImGuiNET;

namespace MelkTank;

public static class NearbyPlayers
{
	private class Seen
	{
		public int Id;

		public string Name = "";

		public DateTime First;

		public DateTime Last;

		public double Dist = -1.0;

		public double Closest = double.MaxValue;

		public double RouteClosest = double.MaxValue;

		public bool InRange;

		public bool WasIn;

		public readonly List<int> Steps = new List<int>();

		public int VisitIdx = -1;

		public double VisitBest = double.MaxValue;
	}

	public const double RangeM = 60.0;

	public const double RouteM = 10.0;

	private const int Keep = 10;

	private const int Remember = 50;

	private static readonly Dictionary<int, Seen> _seen = new Dictionary<int, Seen>();

	private static DateTime _next = DateTime.MinValue;

	private static readonly Vector4 PGreen = new Vector4(0.45f, 0.9f, 0.45f, 1f);

	private static readonly Vector4 PGrey = new Vector4(0.62f, 0.62f, 0.62f, 1f);

	private static readonly Vector4 POrange = new Vector4(1f, 0.6f, 0.27f, 1f);

	public static void Clear()
	{
		lock (_seen)
		{
			_seen.Clear();
		}
	}

	public static void Tick()
	{
		DateTime now = DateTime.Now;
		if (now < _next)
		{
			return;
		}
		_next = now.AddSeconds(1.0);
		CoreManager core = Globals.Core;
		int id = core.CharacterFilter.Id;
		CoordsObject coordsObject = core.WorldFilter[id]?.Coordinates();
		if (coordsObject == null)
		{
			return;
		}
		List<double[]> p = RoutePath();
		lock (_seen)
		{
			foreach (Seen value2 in _seen.Values)
			{
				value2.WasIn = value2.InRange;
				value2.InRange = false;
				value2.Dist = -1.0;
			}
			foreach (WorldObject item in core.WorldFilter.GetByObjectClass(ObjectClass.Player))
			{
				if (item.Id == id)
				{
					continue;
				}
				CoordsObject coordsObject2 = item.Coordinates();
				if (coordsObject2 == null)
				{
					continue;
				}
				double num = (coordsObject2.NorthSouth - coordsObject.NorthSouth) * 240.0;
				double num2 = (coordsObject2.EastWest - coordsObject.EastWest) * 240.0;
				double num3 = Math.Sqrt(num * num + num2 * num2);
				if (num3 > 60.0)
				{
					continue;
				}
				if (!_seen.TryGetValue(item.Id, out var value))
				{
					value = new Seen
					{
						Id = item.Id,
						First = now
					};
					_seen[item.Id] = value;
				}
				if (!value.WasIn)
				{
					value.VisitIdx = -1;
					value.VisitBest = double.MaxValue;
				}
				value.Name = item.Name ?? "";
				value.Last = now;
				value.InRange = true;
				value.Dist = num3;
				if (num3 < value.Closest)
				{
					value.Closest = num3;
				}
				double num4 = DistToPath(p, coordsObject2.NorthSouth * 240.0, coordsObject2.EastWest * 240.0, out var step);
				if (num4 < value.RouteClosest)
				{
					value.RouteClosest = num4;
				}
				if (num4 < value.VisitBest && step > 0)
				{
					value.VisitBest = num4;
					if (value.VisitIdx >= 0 && value.VisitIdx < value.Steps.Count)
					{
						value.Steps[value.VisitIdx] = step;
					}
					else
					{
						value.Steps.Add(step);
						value.VisitIdx = value.Steps.Count - 1;
					}
					if (value.VisitIdx > 0 && value.Steps[value.VisitIdx - 1] == step)
					{
						value.Steps.RemoveAt(value.VisitIdx);
						value.VisitIdx--;
					}
					while (value.Steps.Count > 10)
					{
						value.Steps.RemoveAt(0);
						value.VisitIdx--;
					}
				}
			}
			if (_seen.Count > 50)
			{
				List<Seen> list = new List<Seen>(_seen.Values);
				list.Sort((Seen x, Seen y) => y.Last.CompareTo(x.Last));
				for (int num5 = 50; num5 < list.Count; num5++)
				{
					_seen.Remove(list[num5].Id);
				}
			}
		}
	}

	private static List<double[]> RoutePath()
	{
		List<double[]> list = new List<double[]>();
		try
		{
			NavRoute navRoute = PluginCore.CurrentEngine?.Nav.CurrentRoute;
			if (navRoute == null)
			{
				return list;
			}
			for (int i = 0; i < navRoute.Steps.Count; i++)
			{
				RouteStep routeStep = navRoute.Steps[i];
				if (routeStep.Kind == StepKind.Point || routeStep.Kind == StepKind.Use)
				{
					list.Add(new double[3]
					{
						routeStep.NS * 240.0,
						routeStep.EW * 240.0,
						i + 1
					});
				}
			}
		}
		catch
		{
		}
		return list;
	}

	private static double DistToPath(List<double[]> p, double n, double e, out int step)
	{
		double num = double.MaxValue;
		step = 0;
		for (int i = 0; i < p.Count; i++)
		{
			if (i + 1 < p.Count)
			{
				double num2 = p[i][0];
				double num3 = p[i][1];
				double num4 = p[i + 1][0];
				double num5 = p[i + 1][1];
				double num6 = num4 - num2;
				double num7 = num5 - num3;
				double num8 = num6 * num6 + num7 * num7;
				int num9 = (int)p[i][2];
				double num10;
				if (num8 > 90000.0)
				{
					num10 = Math.Sqrt((n - num2) * (n - num2) + (e - num3) * (e - num3));
				}
				else
				{
					double num11 = ((num8 <= 0.0) ? 0.0 : Math.Max(0.0, Math.Min(1.0, ((n - num2) * num6 + (e - num3) * num7) / num8)));
					double num12 = num2 + num11 * num6 - n;
					double num13 = num3 + num11 * num7 - e;
					num10 = Math.Sqrt(num12 * num12 + num13 * num13);
					if (num11 >= 0.5)
					{
						num9 = (int)p[i + 1][2];
					}
				}
				if (num10 < num)
				{
					num = num10;
					step = num9;
				}
			}
			else
			{
				double num10 = Math.Sqrt((n - p[i][0]) * (n - p[i][0]) + (e - p[i][1]) * (e - p[i][1]));
				if (num10 < num)
				{
					num = num10;
					step = (int)p[i][2];
				}
			}
		}
		return num;
	}

	private static List<Seen> Sorted()
	{
		List<Seen> list;
		lock (_seen)
		{
			list = new List<Seen>(_seen.Values);
		}
		list.Sort((Seen x, Seen y) =>
		{
			if (x.InRange != y.InRange)
			{
				return (!x.InRange) ? 1 : (-1);
			}
			return x.InRange ? x.Dist.CompareTo(y.Dist) : y.Last.CompareTo(x.Last);
		});
		return list;
	}

	private static string Ago(TimeSpan t)
	{
		double num = Math.Max(0.0, t.TotalSeconds);
		if (num < 60.0)
		{
			return (int)num + "s";
		}
		if (num < 3600.0)
		{
			return (int)(num / 60.0) + "m";
		}
		return (int)(num / 3600.0) + "h " + ((int)(num % 3600.0 / 60.0)).ToString("00") + "m";
	}

	public static void Draw()
	{
		List<Seen> list = Sorted();
		DateTime now = DateTime.Now;
		int count = list.FindAll((Seen x) => x.InRange).Count;
		int count2 = list.FindAll((Seen x) => x.RouteClosest <= 10.0).Count;
		Im.TextColored(PGrey, count + " within " + 60.0.ToString("0") + " m now - " + count2 + " crossed your route (came within " + 10.0.ToString("0") + " m of the selected route's path). Since you logged in.");
		if (list.Count == 0)
		{
			Im.TextColored(PGrey, "Nobody yet.");
		}
		else
		{
			if (!ImGui.BeginTable("nearplayers", 6, ImGuiTableFlags.Borders | ImGuiTableFlags.RowBg | ImGuiTableFlags.SizingFixedFit | ImGuiTableFlags.ScrollY, new Vector2(0f, 300f)))
			{
				return;
			}
			ImGui.TableSetupColumn("Player", ImGuiTableColumnFlags.WidthFixed, 170f);
			ImGui.TableSetupColumn("Now", ImGuiTableColumnFlags.WidthFixed, 70f);
			ImGui.TableSetupColumn("Closest", ImGuiTableColumnFlags.WidthFixed, 55f);
			ImGui.TableSetupColumn("First seen", ImGuiTableColumnFlags.WidthFixed, 70f);
			ImGui.TableSetupColumn("Route", ImGuiTableColumnFlags.WidthFixed, 110f);
			ImGui.TableSetupColumn("Near step", ImGuiTableColumnFlags.WidthFixed, 140f);
			ImGui.TableSetupScrollFreeze(0, 1);
			ImGui.TableHeadersRow();
			foreach (Seen item in list)
			{
				bool flag = item.RouteClosest <= 10.0;
				ImGui.TableNextRow();
				ImGui.TableSetColumnIndex(0);
				Im.TextColored(item.InRange ? Vector4.One : PGrey, item.Name);
				ImGui.TableSetColumnIndex(1);
				if (item.InRange)
				{
					Im.TextColored(PGreen, item.Dist.ToString("0") + " m");
				}
				else
				{
					Im.TextColored(PGrey, Ago(now - item.Last) + " ago");
				}
				ImGui.TableSetColumnIndex(2);
				ImGui.TextUnformatted((item.Closest == double.MaxValue) ? "-" : (item.Closest.ToString("0") + " m"));
				ImGui.TableSetColumnIndex(3);
				Im.TextColored(PGrey, Ago(now - item.First) + " ago");
				ImGui.TableSetColumnIndex(4);
				if (item.RouteClosest == double.MaxValue)
				{
					Im.TextColored(PGrey, "-");
				}
				else
				{
					Im.TextColored(flag ? POrange : PGrey, flag ? ("CROSSED (" + item.RouteClosest.ToString("0") + " m)") : (item.RouteClosest.ToString("0") + " m away"));
				}
				ImGui.TableSetColumnIndex(5);
				ImGui.TextUnformatted((item.Steps.Count == 0) ? "-" : string.Join(", ", item.Steps.ConvertAll((int x) => x.ToString()).ToArray()));
			}
			ImGui.EndTable();
		}
	}

	public static void AppendJson(StringBuilder b, Func<string, string> q)
	{
		CultureInfo inv = CultureInfo.InvariantCulture;
		List<Seen> list = Sorted();
		DateTime now = DateTime.Now;
		b.Append(",\n  \"playersRange\": ").Append(60.0.ToString("0", inv));
		b.Append(",\n  \"playersRouteM\": ").Append(10.0.ToString("0", inv));
		b.Append(",\n  \"players\": [");
		for (int i = 0; i < list.Count && i < 10; i++)
		{
			Seen seen = list[i];
			b.Append((i == 0) ? "\n    {" : ",\n    {");
			b.Append("\"name\": ").Append(q(seen.Name));
			b.Append(", \"near\": ").Append(seen.InRange ? "true" : "false");
			b.Append(", \"dist\": ").Append(seen.InRange ? seen.Dist.ToString("0", inv) : "-1");
			b.Append(", \"closest\": ").Append(seen.Closest.ToString("0", inv));
			b.Append(", \"agoSecs\": ").Append(((long)(now - seen.Last).TotalSeconds).ToString(inv));
			b.Append(", \"firstAgoSecs\": ").Append(((long)(now - seen.First).TotalSeconds).ToString(inv));
			b.Append(", \"route\": ").Append((seen.RouteClosest <= 10.0) ? "true" : "false");
			b.Append(", \"routeSteps\": ").Append(q(string.Join(", ", seen.Steps.ConvertAll((int x) => x.ToString(inv)).ToArray())));
			b.Append(", \"routeDist\": ").Append((seen.RouteClosest == double.MaxValue) ? "-1" : seen.RouteClosest.ToString("0", inv));
			b.Append("}");
		}
		b.Append("\n  ]");
	}
}
