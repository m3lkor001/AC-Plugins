MelkTank for Asheron's Call (InfiniteLeaftide) - combat, buffs, pets, nav, metas, looting, Monster-Dex catching
============================================================

What's in here
--------------
  MelksTank\MelkTank.dll        the plugin Decal loads
  MelksTank\MelkTankCore.dll    everything else
  MelksTank\Settings\           monster database, zone landblocks, saved locations
  MelksTank\Profiles\           loot profiles, metas, nav routes, monster lists

You need first
--------------
  - Decal
  - UtilityBelt (the windows are drawn with UtilityBelt's window system - it has to be installed and on)

Install
-------
  1. Put this zip in your Decal Plugins folder (where your other plugins live, e.g. C:\Games\Decal Plugins)
     and "Extract here".
  2. Open Decal (the Decal Agent - its tray icon), click Add, and pick
        MelksTank\MelkTank.dll  (NOT MelkTankCore.dll - the small MelkTank.dll loads it; keep the two together)
     Make sure it's ticked (enabled).
  3. Start the game. Your settings are saved next to the dll the first time you change something.

Updating later
--------------
  Extract a newer zip over the top - your settings and logs aren't in the zip, so they're kept.
  MelkTank reloads itself when MelkTankCore.dll is replaced, so you can update it with the game running.
