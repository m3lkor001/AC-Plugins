#!/usr/bin/env python3
"""
MelkTank Launcher - a Linux replacement for ThwargLauncher's window.

Starts your Asheron's Call clients with Decal (through Wine), tells MelkTank which character to log in,
shows the server and each account's status, and never closes a client on its own.
"""

import os
import subprocess
import sys
import threading
from datetime import datetime, timezone

from PySide6.QtCore import QObject, Qt, QTimer, Signal
from PySide6.QtGui import QAction, QColor, QFont
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFormLayout,
                               QHBoxLayout, QHeaderView, QLabel, QLineEdit, QMainWindow, QMessageBox,
                               QPushButton, QSpinBox, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
                               QAbstractItemView, QPlainTextEdit, QToolButton, QSizePolicy)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mtcore  # noqa: E402

CHAR_SCREEN = "(character screen)"


def ago(dt):
    if not dt:
        return "-"
    s = int((datetime.now(timezone.utc) - dt).total_seconds())
    if s < 60:
        return "%ds ago" % s
    if s < 3600:
        return "%dm ago" % (s // 60)
    return "%dh %dm ago" % (s // 3600, (s % 3600) // 60)


def since(dt):
    if not dt:
        return ""
    s = int((datetime.now(timezone.utc) - dt).total_seconds())
    return "%dh %02dm" % (s // 3600, (s % 3600) // 60)


class Bus(QObject):
    """Signals from worker threads to the window."""
    message = Signal(str)
    server = Signal(str, object)   # server name, True/False/None
    done = Signal()


# ── Dialogs ────────────────────────────────────────────────────────

class AccountDialog(QDialog):
    def __init__(self, cfg, acct=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Account")
        self.cfg = cfg
        acct = acct or {"account": "", "password": "", "server": cfg["servers"][0]["name"] if cfg["servers"] else "",
                        "character": "", "enabled": True}
        form = QFormLayout(self)
        self.account = QLineEdit(acct["account"])
        self.password = QLineEdit(acct.get("password", ""))
        self.password.setEchoMode(QLineEdit.Password)
        show = QCheckBox("Show")
        show.toggled.connect(lambda on: self.password.setEchoMode(QLineEdit.Normal if on else QLineEdit.Password))
        pw = QHBoxLayout()
        pw.addWidget(self.password)
        pw.addWidget(show)
        self.server = QComboBox()
        for s in cfg["servers"]:
            self.server.addItem(s["name"])
        i = self.server.findText(acct.get("server", ""))
        if i >= 0:
            self.server.setCurrentIndex(i)
        self.character = QComboBox()
        self.character.setEditable(True)
        self.character.addItem(CHAR_SCREEN)
        for c in mtcore.known_characters(cfg, acct["account"]):
            self.character.addItem(c)
        self.character.setCurrentText(acct.get("character") or CHAR_SCREEN)
        self.enabled = QCheckBox("Include in \"Launch ticked\"")
        self.enabled.setChecked(acct.get("enabled", True))
        self.restart = QCheckBox("Restart if it crashes (when that's on in Settings)")
        self.restart.setChecked(acct.get("auto_restart", True))
        self.corner = QComboBox()
        for text, val in (("Top-left corner", "top-left"), ("Bottom-right corner", "bottom-right"), ("Leave it where it is", "none")):
            self.corner.addItem(text, val)
        i = self.corner.findData(acct.get("window_corner") or "top-left")
        self.corner.setCurrentIndex(max(0, i))
        self.corner.setToolTip("Once the character is in the game (and the window has stopped resizing), its window is\n"
                               "moved here; 5 s later the focus is taken off the games so they stop drawing.")
        form.addRow("Account", self.account)
        form.addRow("Password", pw)
        form.addRow("Server", self.server)
        form.addRow("Character", self.character)
        form.addRow("", QLabel("Leave it on (character screen) to pick by hand.\n"
                               "The list fills in after this account has reached the character screen once."))
        form.addRow("", self.enabled)
        form.addRow("", self.restart)
        form.addRow("Game window after login", self.corner)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)

    def value(self):
        ch = self.character.currentText().strip()
        return {"account": self.account.text().strip(), "password": self.password.text(),
                "server": self.server.currentText(), "character": "" if ch == CHAR_SCREEN else ch,
                "enabled": self.enabled.isChecked(), "auto_restart": self.restart.isChecked(),
                "window_corner": self.corner.currentData()}


class ServersDialog(QDialog):
    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Servers")
        self.resize(640, 260)
        lay = QVBoxLayout(self)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Name", "Address", "Port", "Read-only dats", "Character slots"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        for s in cfg["servers"]:
            self._add(s)
        lay.addWidget(self.table)
        row = QHBoxLayout()
        add = QPushButton("Add")
        add.clicked.connect(lambda: self._add({"name": "", "host": "", "port": 9000, "rodat": False, "slots": 11}))
        rem = QPushButton("Remove")
        rem.clicked.connect(lambda: self.table.removeRow(self.table.currentRow()))
        row.addWidget(add)
        row.addWidget(rem)
        row.addStretch()
        lay.addLayout(row)
        lay.addWidget(QLabel("Character slots: how many rows the server's character screen has (ACE default 11) - "
                             "auto-login uses it to click the right row."))
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        lay.addWidget(buttons)

    def _add(self, s):
        r = self.table.rowCount()
        self.table.insertRow(r)
        self.table.setItem(r, 0, QTableWidgetItem(s["name"]))
        self.table.setItem(r, 1, QTableWidgetItem(s["host"]))
        self.table.setItem(r, 2, QTableWidgetItem(str(s["port"])))
        cb = QCheckBox()
        cb.setChecked(bool(s.get("rodat")))
        self.table.setCellWidget(r, 3, cb)
        self.table.setItem(r, 4, QTableWidgetItem(str(s.get("slots", 11))))

    def value(self):
        out = []
        for r in range(self.table.rowCount()):
            name = (self.table.item(r, 0).text() if self.table.item(r, 0) else "").strip()
            host = (self.table.item(r, 1).text() if self.table.item(r, 1) else "").strip()
            if not name or not host:
                continue
            try:
                port = int(self.table.item(r, 2).text())
            except Exception:
                port = 9000
            try:
                slots = int(self.table.item(r, 4).text())
            except Exception:
                slots = 11
            out.append({"name": name, "host": host, "port": port, "rodat": self.table.cellWidget(r, 3).isChecked(),
                        "slots": slots})
        return out


class SettingsDialog(QDialog):
    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Settings")
        self.resize(720, 0)
        w = cfg["wine"]
        self.mode = QComboBox()
        self.mode.addItems(["direct", "system"])
        self.mode.setCurrentText(w.get("mode", "direct"))
        self.wine_path = QLineEdit(w["wine_path"])
        self.prefix = QLineEdit(w["prefix"])
        self.esync = QCheckBox("esync")
        self.esync.setChecked(bool(w.get("esync")))
        self.fsync = QCheckBox("fsync")
        self.fsync.setChecked(bool(w.get("fsync")))
        syncs = QHBoxLayout()
        syncs.addWidget(self.esync)
        syncs.addWidget(self.fsync)
        syncs.addStretch()
        self.client = QLineEdit(cfg["client"])
        self.injector = QLineEdit(cfg["injector"])
        self.decal = QCheckBox("Load Decal (needs ThwargLauncher's injector.dll)")
        self.decal.setChecked(cfg.get("use_decal", True))
        self.picker = QComboBox()
        self.picker.addItem("MelkTank", "melktank")
        self.picker.addItem("ThwargFilter", "thwargfilter")
        self.picker.setCurrentIndex(max(0, self.picker.findData(cfg.get("character_picker", "thwargfilter"))))
        self.restart = QCheckBox("Restart a client automatically if it crashes")
        self.restart.setChecked(bool(cfg.get("auto_restart", False)))
        self.frozen = QCheckBox("Restart a client that stops answering, or whose login gets stuck")
        self.frozen.setChecked(bool(cfg.get("restart_frozen", False)))
        self.frozen_min = QSpinBox()
        self.frozen_min.setRange(1, 30)
        self.frozen_min.setValue(int(cfg.get("frozen_minutes", 3)))
        self.frozen_min.setSuffix(" min without word")
        self.frozen_wait = QSpinBox()
        self.frozen_wait.setRange(0, 600)
        self.frozen_wait.setValue(int(cfg.get("frozen_wait_seconds", 60)))
        self.frozen_wait.setSuffix(" s before starting it again")
        frozen_row = QHBoxLayout()
        frozen_row.addWidget(self.frozen_min)
        frozen_row.addWidget(self.frozen_wait)
        frozen_row.addStretch()
        self.delay = QSpinBox()
        self.delay.setRange(5, 300)
        self.delay.setValue(int(cfg.get("launch_delay", 20)))
        self.delay.setSuffix(" s")
        self.port = QSpinBox()
        self.port.setRange(1024, 65535)
        self.port.setValue(int(cfg["service"]["port"]))
        self.token = QLineEdit(cfg["service"]["token"])
        self.token.setReadOnly(True)
        self.back = QCheckBox("Start the game again when the server comes back after a shutdown (a patch, a restart)")
        self.back.setChecked(bool(cfg.get("server_back_restart", True)))
        self.back_window = QSpinBox()
        self.back_window.setRange(1, 120)
        self.back_window.setValue(int(cfg.get("server_back_window_minutes", 15)))
        self.back_window.setSuffix(" min before it went down")
        self.back_wait = QSpinBox()
        self.back_wait.setRange(0, 1800)
        self.back_wait.setValue(int(cfg.get("server_back_wait_seconds", 90)))
        self.back_wait.setSuffix(" s after it's back")
        back_row = QHBoxLayout()
        back_row.addWidget(QLabel("Logged out up to"))
        back_row.addWidget(self.back_window)
        back_row.addWidget(QLabel("  started"))
        back_row.addWidget(self.back_wait)
        back_row.addStretch()

        outer = QVBoxLayout(self)
        opened = set(cfg.get("settings_open") or ["restarts", "server"])
        self.sections = {}

        def section(key, title):
            box = QWidget()
            v = QVBoxLayout(box)
            v.setContentsMargins(0, 0, 0, 0)
            head = QToolButton()
            head.setText(title)
            head.setCheckable(True)
            head.setChecked(key in opened)
            head.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
            head.setArrowType(Qt.DownArrow if key in opened else Qt.RightArrow)
            head.setStyleSheet("QToolButton { border: none; font-weight: bold; }")
            head.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            body = QWidget()
            f = QFormLayout(body)
            f.setContentsMargins(18, 0, 0, 6)
            body.setVisible(key in opened)

            def toggled(on, h=head, b=body):
                h.setArrowType(Qt.DownArrow if on else Qt.RightArrow)
                b.setVisible(on)
                QTimer.singleShot(0, lambda: self.resize(self.width(), self.sizeHint().height()))
            head.toggled.connect(toggled)
            v.addWidget(head)
            v.addWidget(body)
            outer.addWidget(box)
            self.sections[key] = head
            return f

        form = section("restarts", "Restarts")
        form.addRow("", self.restart)
        form.addRow("", QLabel("Only clients that got into the game. A client you close yourself, or one that's frozen\n"
                               "but still open, isn't restarted. At most 3 restarts per account in 30 minutes.\n"
                               "The phone service does the watching, so it works with this window closed."))
        form.addRow("", self.frozen)
        form.addRow("", frozen_row)
        form.addRow("", QLabel("Stopped answering (frozen or lost its connection): closed (forced) after the time above,\n"
                               "then started again after the wait. Login stuck at the character screen: 1 more minute,\n"
                               "then closed, then started again after the wait. Only for accounts ticked to restart,\n"
                               "not while the server is down, at most 3 times per account in 30 minutes."))

        form = section("server", "Server shutdowns")
        form.addRow("", self.back)
        form.addRow("", back_row)
        form.addRow("", QLabel("A shutdown logs everyone off, which looks like a normal logout. Accounts (ticked to restart)\n"
                               "that logged out within the time above before the server stopped answering are started\n"
                               "again once it answers, after the wait (it may not take logins straight away).\n"
                               "The server is checked every minute - every 20 s while it's down."))

        form = section("launching", "Launching")
        form.addRow("Character picked by", self.picker)
        form.addRow("Time between launches", self.delay)

        form = section("wine", "Game && Wine setup")
        form.addRow("Wine", self.mode)
        form.addRow("Wine program (direct)", self.wine_path)
        form.addRow("Wine prefix", self.prefix)
        form.addRow("", syncs)
        form.addRow("acclient.exe (Windows path)", self.client)
        form.addRow("injector.dll (Windows path)", self.injector)
        form.addRow("", self.decal)

        form = section("phone", "Phone service")
        form.addRow("Phone service port", self.port)
        form.addRow("Phone app key", self.token)
        form.addRow("", QLabel("Type the phone app key into the app once. Changes to the port apply when the "
                               "service restarts:\n  systemctl --user restart melktank-service"))
        outer.addStretch()
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        outer.addWidget(buttons)

    def apply(self, cfg):
        w = cfg["wine"]
        w["mode"] = self.mode.currentText()
        w["wine_path"] = self.wine_path.text().strip()
        w["prefix"] = self.prefix.text().strip()
        w["esync"] = self.esync.isChecked()
        w["fsync"] = self.fsync.isChecked()
        cfg["client"] = self.client.text().strip()
        cfg["injector"] = self.injector.text().strip()
        cfg["use_decal"] = self.decal.isChecked()
        cfg["character_picker"] = self.picker.currentData()
        cfg["auto_restart"] = self.restart.isChecked()
        cfg["restart_frozen"] = self.frozen.isChecked()
        cfg["frozen_minutes"] = self.frozen_min.value()
        cfg["frozen_wait_seconds"] = self.frozen_wait.value()
        cfg["launch_delay"] = self.delay.value()
        cfg["service"]["port"] = self.port.value()
        cfg["server_back_restart"] = self.back.isChecked()
        cfg["server_back_window_minutes"] = self.back_window.value()
        cfg["server_back_wait_seconds"] = self.back_wait.value()
        cfg["settings_open"] = [k for k, h in self.sections.items() if h.isChecked()]


# ── Main window ────────────────────────────────────────────────────

COLS = ["Launch", "Account", "Character", "Status", "In game", ""]


def dur(secs):
    """3h 12m / 12m / 40s"""
    secs = int(secs or 0)
    if secs >= 86400:
        return "%dd %dh" % (secs // 86400, secs % 86400 // 3600)
    if secs >= 3600:
        return "%dh %02dm" % (secs // 3600, secs % 3600 // 60)
    if secs >= 60:
        return "%dm" % (secs // 60)
    return "%ds" % secs


KIND_COLOUR = {"in_game": "#5ccc6a", "launch": "#5ad6f2", "restart": "#5ad6f2", "closed": "#9a9a9a",
               "closed_phone": "#9a9a9a", "unresponsive": "#e8a33a", "disconnected": "#e8a33a", "killed": "#e8a33a",
               "server_down": "#e8a33a", "server_up": "#5ccc6a", "crashed": "#e06060", "stuck": "#e06060",
               "launch_failed": "#e06060", "gave_up": "#e06060", "reset": "#b685f2"}


class ClientLogDialog(QDialog):
    """The client history: when each client was launched, got in, stopped answering, crashed, was closed and
    restarted - with how long each run lasted, and a summary of the last 24 hours."""

    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.setWindowTitle("Client log")
        self.resize(980, 560)
        lay = QVBoxLayout(self)
        top = QHBoxLayout()
        top.addWidget(QLabel("Account"))
        self.who = QComboBox()
        self.who.addItem("All", "")
        for a in cfg["accounts"]:
            self.who.addItem(a.get("label") or a["account"], a["account"])
        self.who.currentIndexChanged.connect(self.fill)
        top.addWidget(self.who)
        top.addStretch()
        b = QPushButton("Refresh")
        b.clicked.connect(self.fill)
        top.addWidget(b)
        b = QPushButton("Full launcher log")
        b.clicked.connect(lambda: subprocess.Popen(["xdg-open", mtcore.LOG_PATH]))
        top.addWidget(b)
        lay.addLayout(top)
        self.summary = QLabel("")
        self.summary.setTextFormat(Qt.RichText)
        self.summary.setWordWrap(True)
        lay.addWidget(self.summary)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["When", "Account", "What", "Ran for", "Details"])
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.verticalHeader().setVisible(False)
        h = self.table.horizontalHeader()
        h.setSectionResizeMode(QHeaderView.ResizeToContents)
        h.setSectionResizeMode(4, QHeaderView.Stretch)
        lay.addWidget(self.table, 1)
        self.fill()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.fill)
        self.timer.start(15000)

    def name_of(self, account):
        a = mtcore.find_account(self.cfg, account)
        return (a.get("label") or account) if a else account

    def fill(self):
        acct = self.who.currentData() or None
        now = datetime.now().timestamp()
        parts = []
        for name, s in mtcore.events_summary(self.cfg).items():
            if acct and name.lower() != acct.lower():
                continue
            head = "<b>%s</b>" % self.name_of(name)
            if s["inGameSince"]:
                head += " - <span style='color:#5ccc6a'>in game %s</span>%s" % (
                    dur(now - s["inGameSince"]), (" as " + s["char"]) if s.get("char") else "")
            else:
                head += " - <span style='color:#9a9a9a'>not in game</span>"
            bits = ["%s in game" % dur(s["uptime"]), "longest run %s" % dur(s["longest"])]
            for key, word in (("restarts", "restart"), ("crashes", "crash"), ("unresponsive", "freeze"),
                              ("disconnects", "disconnect"), ("stuck", "stuck login")):
                if s[key]:
                    plural = "es" if word.endswith("sh") else "s"
                    bits.append("%d %s%s" % (s[key], word, plural if s[key] != 1 else ""))
            parts.append(head + "<br>&nbsp;&nbsp;last 24 h: " + ", ".join(bits))
        self.summary.setText("<br>".join(parts) or "Nothing recorded yet.")
        evs = mtcore.read_events(acct, limit=500)
        evs.reverse()
        self.table.setRowCount(len(evs))
        for r, e in enumerate(evs):
            t = datetime.fromtimestamp(e.get("t", 0))
            when = t.strftime("%H:%M:%S") if t.date() == datetime.now().date() else t.strftime("%b %d %H:%M")
            kind = e.get("kind", "")
            cells = [when, self.name_of(e.get("account", "")) + ((" (" + e["char"] + ")") if e.get("char") else ""),
                     mtcore.EVENT_KINDS.get(kind, kind), dur(e["ran"]) if e.get("ran") is not None else "", e.get("text", "")]
            for c, text in enumerate(cells):
                it = QTableWidgetItem(text)
                if c == 2:
                    it.setForeground(QColor(KIND_COLOUR.get(kind, "#e8e8e8")))
                self.table.setItem(r, c, it)


class Main(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("MelkTank Launcher")
        self.resize(940, 420)
        self.cfg = mtcore.load_config()
        self.bus = Bus(self)   # owned by the window, so it's cleaned up with it
        self.bus.message.connect(self.say)
        self.bus.server.connect(self.on_server)
        self.bus.done.connect(self.on_launch_done)
        self.server_states = {}
        self.busy = False

        central = QWidget()
        lay = QVBoxLayout(central)

        top = QHBoxLayout()
        self.server_label = QLabel("Servers: checking...")
        f = QFont()
        f.setPointSize(f.pointSize() + 1)
        self.server_label.setFont(f)
        top.addWidget(self.server_label)
        b = QPushButton("Check now")
        b.setToolTip("Check the servers again right away (the phone service checks too, for its restarts)")
        b.clicked.connect(self.check_now)
        top.addWidget(b)
        top.addStretch()
        self.decal_label = QLabel("Decal: ...")
        self.decal_label.setFont(f)
        top.addWidget(self.decal_label)
        self.decal_btn = QPushButton("Start Decal")
        self.decal_btn.clicked.connect(self.toggle_decal)
        top.addWidget(self.decal_btn)
        top.addSpacing(16)
        b = QPushButton("Log...")
        b.setToolTip("Client history: launches, time in game, freezes, disconnects, crashes, restarts")
        b.clicked.connect(self.open_client_log)
        top.addWidget(b)
        b = QPushButton("Servers...")
        b.clicked.connect(self.edit_servers)
        top.addWidget(b)
        b = QPushButton("Settings...")
        b.clicked.connect(self.edit_settings)
        top.addWidget(b)
        lay.addLayout(top)

        self.table = QTableWidget(0, len(COLS))
        self.table.setHorizontalHeaderLabels(COLS)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        h = self.table.horizontalHeader()
        h.setSectionResizeMode(QHeaderView.ResizeToContents)
        h.setSectionResizeMode(3, QHeaderView.Stretch)
        self.table.doubleClicked.connect(lambda _: self.edit_account())
        lay.addWidget(self.table)

        row = QHBoxLayout()
        for text, fn in (("Add account", self.add_account), ("Edit", self.edit_account), ("Remove", self.remove_account)):
            b = QPushButton(text)
            b.clicked.connect(fn)
            row.addWidget(b)
        row.addStretch()
        self.launch_btn = QPushButton("Launch ticked")
        self.launch_btn.setDefault(True)
        self.launch_btn.clicked.connect(self.launch_ticked)
        row.addWidget(self.launch_btn)
        lay.addLayout(row)

        self.status = QLabel("")
        self.status.setWordWrap(True)
        lay.addWidget(self.status)
        self.setCentralWidget(central)

        log_action = QAction("Open launcher log", self)
        log_action.triggered.connect(self.open_log)
        self.menuBar().addMenu("&Help").addAction(log_action)

        self.rebuild()
        problems = mtcore.check_setup(self.cfg)
        if problems:
            self.say("Setup: " + " ".join(problems))

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(5000)
        self.server_timer = QTimer(self)
        self.server_timer.timeout.connect(self.check_servers)
        self.server_timer.start(60000)
        self.check_servers()

    # ── table ──

    def rebuild(self):
        self.table.setRowCount(0)
        for a in self.cfg["accounts"]:
            r = self.table.rowCount()
            self.table.insertRow(r)
            cb = QCheckBox()
            cb.setChecked(a.get("enabled", True))
            cb.toggled.connect(lambda on, acct=a: self.set_enabled(acct, on))
            cell = QWidget()
            cl = QHBoxLayout(cell)
            cl.setContentsMargins(8, 0, 0, 0)
            cl.addWidget(cb)
            self.table.setCellWidget(r, 0, cell)
            self.table.setItem(r, 1, QTableWidgetItem(a["account"]))
            self.table.setItem(r, 2, QTableWidgetItem(a.get("character") or CHAR_SCREEN))
            # Launch / Stop (MelkTank logs out and closes the game) / Kill (ends the process at once)
            cell2 = QWidget()
            bl = QHBoxLayout(cell2)
            bl.setContentsMargins(2, 0, 2, 0)
            bl.setSpacing(4)
            btn = QPushButton("Launch")
            btn.clicked.connect(lambda _=False, name=a["account"]: self.launch([name]))
            bl.addWidget(btn)
            stop = QPushButton("Stop game")
            stop.setToolTip("MelkTank logs the character out and closes the game (like Exit on the phone).")
            stop.clicked.connect(lambda _=False, name=a["account"]: self.stop_game(name))
            bl.addWidget(stop)
            kill = QPushButton("Kill")
            kill.setToolTip("Ends the game's process straight away - for a frozen or stuck client. Not restarted as a crash.")
            kill.clicked.connect(lambda _=False, name=a["account"]: self.kill_game(name))
            bl.addWidget(kill)
            self.table.setCellWidget(r, 5, cell2)
        self.refresh()

    def stop_game(self, name):
        if not mtcore.client_pids(name):
            self.say("No running client found for %s." % name)
            return
        mtcore.send_command(self.cfg, name, "quit")
        mtcore.event(name, "closed_launcher", "Stop game from the launcher")
        self.say("Asked %s to log out and close the game." % name)

    def kill_game(self, name):
        if not mtcore.client_pids(name):
            self.say("No running client found for %s." % name)
            return
        if QMessageBox.question(self, "Kill the game", "End %s's game process right now?\n(Nothing is saved first - use Stop game for a normal exit.)" % name) != QMessageBox.Yes:
            return

        def work():
            ok, msg = mtcore.kill_client(self.cfg, name, wait=1.0, kind="closed_launcher", why="Killed from the launcher",
                                         note="Closed from the launcher")
            self.bus.message.emit(msg)
        threading.Thread(target=work, daemon=True).start()

    def refresh_decal(self):
        running = bool(mtcore.decal_agent_pids())
        on = (mtcore.load_config().get("decal_agent") or {}).get("enabled", True)
        if running:
            self.decal_label.setText("Decal: running")
            self.decal_label.setStyleSheet("color: #2e9d4f;")
        else:
            self.decal_label.setText("Decal: stopped" + ("" if on else " (kept off)"))
            self.decal_label.setStyleSheet("color: #9e9e9e;" if not on else "color: #d79b00;")
        self.decal_btn.setText("Stop Decal" if running else "Start Decal")

    def toggle_decal(self):
        running = bool(mtcore.decal_agent_pids())
        self.decal_btn.setEnabled(False)

        def work():
            ok, msg = mtcore.set_decal(not running)
            self.cfg.setdefault("decal_agent", {})["enabled"] = not running   # so saving Settings later keeps it
            self.bus.message.emit(msg)
        threading.Thread(target=work, daemon=True).start()
        QTimer.singleShot(2500, lambda: (self.decal_btn.setEnabled(True), self.refresh_decal()))

    def refresh(self):
        try:
            self.refresh_decal()
        except Exception:
            pass
        for r, a in enumerate(self.cfg["accounts"]):
            st = mtcore.read_status(self.cfg, a["account"])
            state = mtcore.client_state(st)
            if state == "offline":
                text, color = "Offline", QColor("#9e9e9e")
            elif state == "charselect":
                note = (st.get("loginNote") or "").strip()
                text, color = "Character screen" + (" - " + note if note else ""), QColor("#d79b00")
            else:
                text = "In game: %s" % st.get("character", "")
                if st.get("paused"):
                    text += " (paused by %s)" % st.get("pausedBy", "")
                elif not st.get("master", True):
                    text += " (MelkTank OFF)"
                color = QColor("#2e9d4f")
            item = QTableWidgetItem(text)
            item.setForeground(color)
            self.table.setItem(r, 3, item)
            online = state == "online"
            self.table.setItem(r, 4, QTableWidgetItem(since(mtcore.parse_iso(st.get("loginTime"))) if online else ""))

    def selected_account(self):
        r = self.table.currentRow()
        return self.cfg["accounts"][r] if 0 <= r < len(self.cfg["accounts"]) else None

    def set_enabled(self, acct, on):
        acct["enabled"] = on
        mtcore.save_config(self.cfg)

    def add_account(self):
        d = AccountDialog(self.cfg, None, self)
        if d.exec():
            v = d.value()
            if not v["account"]:
                return
            if mtcore.find_account(self.cfg, v["account"]):
                QMessageBox.warning(self, "Account", "%s is already in the list." % v["account"])
                return
            self.cfg["accounts"].append(v)
            mtcore.save_config(self.cfg)
            self.rebuild()

    def edit_account(self):
        a = self.selected_account()
        if not a:
            return
        d = AccountDialog(self.cfg, a, self)
        if d.exec():
            a.update(d.value())
            mtcore.save_config(self.cfg)
            self.rebuild()

    def remove_account(self):
        a = self.selected_account()
        if a and QMessageBox.question(self, "Remove", "Remove %s from the launcher?" % a["account"]) == QMessageBox.Yes:
            self.cfg["accounts"].remove(a)
            mtcore.save_config(self.cfg)
            self.rebuild()

    def edit_servers(self):
        d = ServersDialog(self.cfg, self)
        if d.exec():
            self.cfg["servers"] = d.value()
            mtcore.save_config(self.cfg)
            self.check_servers()

    def edit_settings(self):
        d = SettingsDialog(self.cfg, self)
        if d.exec():
            d.apply(self.cfg)
            mtcore.save_config(self.cfg)
            problems = mtcore.check_setup(self.cfg)
            self.say("Setup: " + " ".join(problems) if problems else "Settings saved.")

    # ── servers ──

    def check_servers(self):
        servers = list(self.cfg["servers"])

        def work():
            for s in servers:
                self.bus.server.emit(s["name"], mtcore.server_up(s["host"], s["port"]))
        threading.Thread(target=work, daemon=True).start()

    def check_now(self):
        self.server_label.setText("Servers: checking...")
        mtcore.ask_server_check()
        self.check_servers()

    def on_server(self, name, up):
        self.server_states[name] = up
        parts = []
        for s in self.cfg["servers"]:
            v = self.server_states.get(s["name"], "?")
            mark = "✓ up" if v is True else "✗ down" if v is False else "? no address" if v is None else "…"
            parts.append("%s  %s" % (s["name"], mark))
        self.server_label.setText("   |   ".join(parts) or "No servers set up")

    # ── launching ──

    def launch_ticked(self):
        self.launch([a["account"] for a in self.cfg["accounts"] if a.get("enabled", True)])

    def launch(self, names):
        if self.busy:
            self.say("Still launching - one moment.")
            return
        if not names:
            self.say("Nothing ticked.")
            return
        running = [n for n in names if mtcore.client_state(mtcore.read_status(self.cfg, n)) != "offline"]
        if running and QMessageBox.question(
                self, "Already running",
                "%s looks like it's already running. Start another client anyway?" % ", ".join(running)) != QMessageBox.Yes:
            names = [n for n in names if n not in running]
            if not names:
                return
        self.busy = True
        self.launch_btn.setEnabled(False)
        cfg = mtcore.load_config()

        def work():
            mtcore.launch_many(cfg, names, progress=self.bus.message.emit, manual=True)   # you're at the PC: keep the focus
            self.bus.done.emit()
        threading.Thread(target=work, daemon=True).start()

    def on_launch_done(self):
        self.busy = False
        self.launch_btn.setEnabled(True)
        self.refresh()

    def say(self, text):
        self.status.setText(datetime.now().strftime("%H:%M:%S  ") + text)

    def open_client_log(self):
        d = ClientLogDialog(self.cfg, self)
        d.setAttribute(Qt.WA_DeleteOnClose)
        d.show()

    def open_log(self):
        subprocess.Popen(["xdg-open", mtcore.LOG_PATH])


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("MelkTank Launcher")
    w = Main()
    w.show()
    ret = app.exec()
    # tidy up while Qt is still running, so closing the window doesn't print
    # "shared QObject was deleted directly"
    w.timer.stop()
    w.server_timer.stop()
    w.deleteLater()
    app.processEvents()
    del w
    sys.exit(ret)


if __name__ == "__main__":
    main()
