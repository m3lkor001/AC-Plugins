#!/bin/bash
# MelkTank Remote - one-time setup for the Linux launcher and the phone service.
# Run it from this folder:   bash setup.sh
# Safe to run again (after an update, or to repair something).
set -e
cd "$(dirname "$(readlink -f "$0")")"
HERE="$(pwd)"
echo "== MelkTank Remote setup in $HERE"

# 1. Python + the window toolkit (PySide6) in a private folder, nothing system-wide
if ! command -v python3 >/dev/null; then
    echo "python3 is missing:  sudo pacman -S python"; exit 1
fi
if [ ! -x .venv/bin/python ]; then
    echo "-- creating .venv"
    python3 -m venv .venv
fi
if ! .venv/bin/python -c "import PySide6" 2>/dev/null; then
    echo "-- installing PySide6 (one-time download, about 100 MB)"
    .venv/bin/pip install --quiet --upgrade pip || true
    if ! .venv/bin/pip install --quiet PySide6; then
        # no PySide6 wheel for this Python yet: use Manjaro's package instead
        echo "-- pip couldn't install PySide6; trying Manjaro's pyside6 package (asks for your password)"
        sudo pacman -S --needed --noconfirm pyside6
        rm -rf .venv
        python3 -m venv --system-site-packages .venv
    fi
fi
.venv/bin/python -c "import PySide6" || { echo "PySide6 still missing - install it with: sudo pacman -S pyside6"; exit 1; }

# 2. The Decal launch helper goes into the Wine prefix (C:\Games\MelkTankRemote\mtlaunch.exe)
if [ -f mtlaunch.exe.b64 ]; then
    base64 -d mtlaunch.exe.b64 > mtlaunch.exe
fi
.venv/bin/python - <<'EOF'
import mtcore
cfg = mtcore.load_config()          # writes ~/.config/melktank/config.json the first time
print("-- helper installed at", mtcore.install_helper(cfg, "mtlaunch.exe"))
problems = mtcore.check_setup(cfg)
if problems:
    print("!! Still to fix (Settings in the launcher):")
    for p in problems:
        print("   -", p)
else:
    print("-- paths look good")
EOF

# 3. Does the Wine build run on this PC (outside the Lutris flatpak)?
WINE=$(.venv/bin/python -c "import mtcore;c=mtcore.load_config();print(mtcore.wine_command(c)[0])")
if "$WINE" --version >/dev/null 2>&1; then
    echo "-- wine ok: $("$WINE" --version)"
else
    echo "!! $WINE doesn't start on this PC. Either install the 32-bit libraries Wine needs"
    echo "   (sudo pacman -S wine  pulls them in) or switch the launcher's Settings to 'system' Wine."
fi

# 4. Menu entry for the launcher
mkdir -p "$HOME/.local/share/applications"
cat > "$HOME/.local/share/applications/melktank-launcher.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=MelkTank Launcher
Comment=Asheron's Call launcher with MelkTank auto-login
Exec="$HERE/.venv/bin/python" "$HERE/launcher.py"
Icon=applications-games
Terminal=false
Categories=Game;
EOF
echo "-- menu entry: MelkTank Launcher"
cat > "$HOME/.local/share/applications/melktank-loot-editor.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=MelkTank Loot Editor
Comment=Edit MelkTank / VTank loot profiles outside the game
Exec="$HERE/.venv/bin/python" "$HERE/LootEditor/loot_editor.py"
Icon=accessories-text-editor
Terminal=false
Categories=Game;
EOF
echo "-- menu entry: MelkTank Loot Editor"

# 5. The phone service, started with your desktop session and restarted if it stops
# (the game windows it starts for the phone's Launch button need your display, so that's passed in too)
mkdir -p "$HOME/.config/systemd/user"
DISPLAY_ENV=""
for v in DISPLAY WAYLAND_DISPLAY XAUTHORITY; do
    if [ -n "${!v}" ]; then DISPLAY_ENV="${DISPLAY_ENV}Environment=$v=${!v}"$'\n'; fi
done
cat > "$HOME/.config/systemd/user/melktank-service.service" <<EOF
[Unit]
Description=MelkTank phone service
After=network-online.target

[Service]
ExecStart="$HERE/.venv/bin/python" "$HERE/service.py"
Restart=on-failure
RestartSec=10
${DISPLAY_ENV}
[Install]
WantedBy=default.target
EOF
systemctl --user daemon-reload || echo "!! systemd user services aren't available - start the service by hand: .venv/bin/python service.py"
systemctl --user enable --now melktank-service.service >/dev/null 2>&1 || true
systemctl --user restart melktank-service.service || true
sleep 1
if systemctl --user is-active --quiet melktank-service.service; then
    echo "-- phone service running"
else
    echo "!! phone service didn't start:  journalctl --user -u melktank-service -n 30"
fi

# 6. What the phone app needs
PORT=$(.venv/bin/python -c "import mtcore;print(mtcore.load_config()['service']['port'])")
KEY=$(.venv/bin/python -c "import mtcore;print(mtcore.load_config()['service']['token'])")
TSIP=""
if command -v tailscale >/dev/null; then TSIP=$(tailscale ip -4 2>/dev/null | head -1); fi
echo
echo "== Phone app settings"
echo "   Address:  ${TSIP:-(install Tailscale first, then run: tailscale ip -4)}"
echo "   Port:     $PORT"
echo "   App key:  $KEY"
echo
echo "Done. Start the launcher from your menu (MelkTank Launcher) or:  $HERE/.venv/bin/python $HERE/launcher.py"
