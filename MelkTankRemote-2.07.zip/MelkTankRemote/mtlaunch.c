/*
 * mtlaunch.exe - starts acclient.exe with Decal loaded, for the MelkTank Linux launcher.
 * Runs inside Wine. Uses ThwargLauncher's injector.dll (the same call ThwargLauncher makes), so nothing new is
 * injected - only the launcher window around it is replaced.
 *
 *   mtlaunch.exe <injector.dll> <acclient.exe> [client arguments...]
 *   mtlaunch.exe --enter <pid>     clicks the character screen's Enter button in that client's window
 *                                  (ThwargFilter selects the character and clicks Enter at once; under Wine the
 *                                  Enter click can land before the selection has gone through, so the launcher
 *                                  clicks it again a few times until MelkTank reports the character in the world)
 *
 * Prints "PID <n>" on success, "ERROR <text>" otherwise. Built without the C runtime to stay tiny:
 *   i686-w64-mingw32-gcc -Os -s -nostdlib -e _start@0 -o mtlaunch.exe mtlaunch.c -lkernel32 -ladvapi32 -lshell32 -luser32
 */
#include <windows.h>
#include <shellapi.h>

typedef int (__cdecl *LaunchInjected_t)(const wchar_t *command_line, const wchar_t *working_directory,
                                        const wchar_t *inject_dll_path, const char *initialize_function);

static void out(const char *s)
{
    DWORD n;
    WriteFile(GetStdHandle(STD_OUTPUT_HANDLE), s, lstrlenA(s), &n, NULL);
}

static void fail(const char *msg, DWORD code)
{
    char buf[400];
    wsprintfA(buf, "ERROR %s (code %lu)\r\n", msg, (unsigned long)code);
    out(buf);
    ExitProcess(1);
}

static HWND found;
static DWORD foundArea;

static BOOL CALLBACK FindMain(HWND w, LPARAM pid)
{
    DWORD p = 0;
    GetWindowThreadProcessId(w, &p);
    if (p != (DWORD)pid || !IsWindowVisible(w) || GetWindow(w, GW_OWNER)) return TRUE;
    RECT r;
    if (!GetClientRect(w, &r)) return TRUE;
    DWORD area = (DWORD)((r.right - r.left) * (r.bottom - r.top));
    if (area >= foundArea) { found = w; foundArea = area; }
    return TRUE;
}

/* The same clicks ThwargFilter sends (PostMsgs.SendMouseClick): move, left down, left up at x,y in the window. */
static void Click(HWND w, int x, int y)
{
    LPARAM loc = (LPARAM)((y << 16) | (x & 0xffff));
    PostMessageW(w, WM_MOUSEMOVE, 0, loc);
    PostMessageW(w, WM_LBUTTONDOWN, 1, loc);
    PostMessageW(w, WM_LBUTTONUP, 0, loc);
}

static wchar_t cmd[8192], workdir[MAX_PATH * 2], agent[MAX_PATH], inject[MAX_PATH * 2];

void __stdcall start(void)
{
    int argc = 0;
    wchar_t **argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    if (!argv || argc < 3) fail("usage: mtlaunch.exe <injector.dll> <acclient.exe> [args...]", 0);

    if (lstrcmpiW(argv[1], L"--enter") == 0)
    {
        DWORD pid = 0;
        for (const wchar_t *c = argv[2]; *c >= L'0' && *c <= L'9'; c++) pid = pid * 10 + (DWORD)(*c - L'0');
        EnumWindows(FindMain, (LPARAM)pid);
        if (!found) fail("no window for that client", pid);
        Click(found, 0x015C, 0x0185);   /* the Enter button (ThwargFilter's numbers) */
        out("OK\r\n");
        ExitProcess(0);
    }
    const wchar_t *injector = argv[1], *client = argv[2];

    /* Decal's Inject.dll: HKLM\SOFTWARE\Decal\Agent  AgentPath */
    DWORD size = sizeof(agent);
    LONG r = RegGetValueW(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Decal\\Agent", L"AgentPath", RRF_RT_REG_SZ, NULL, agent, &size);
    if (r != ERROR_SUCCESS) fail("Decal isn't installed in this Wine prefix (no AgentPath)", (DWORD)r);
    lstrcpyW(inject, agent);
    int len = lstrlenW(inject);
    if (len > 0 && inject[len - 1] != L'\\') lstrcatW(inject, L"\\");
    lstrcatW(inject, L"Inject.dll");
    if (GetFileAttributesW(inject) == INVALID_FILE_ATTRIBUTES) fail("Decal's Inject.dll not found", GetLastError());

    /* working directory = the client's folder */
    lstrcpynW(workdir, client, MAX_PATH * 2);
    for (int i = lstrlenW(workdir) - 1; i >= 0; i--) if (workdir[i] == L'\\') { workdir[i] = 0; break; }

    /* command line exactly as ThwargLauncher builds it: "<exe> <args>" */
    lstrcpynW(cmd, client, 8000);
    for (int i = 3; i < argc; i++)
    {
        if (lstrlenW(cmd) + lstrlenW(argv[i]) + 2 >= 8192) break;
        lstrcatW(cmd, L" ");
        lstrcatW(cmd, argv[i]);
    }

    HMODULE h = LoadLibraryW(injector);
    if (!h) fail("can't load injector.dll", GetLastError());
    LaunchInjected_t launch = (LaunchInjected_t)GetProcAddress(h, "LaunchInjected");
    if (!launch) fail("injector.dll has no LaunchInjected", GetLastError());

    int pid = launch(cmd, workdir, inject, "DecalStartup");
    if (pid <= 0) fail("LaunchInjected failed", (DWORD)pid);
    char buf[64];
    wsprintfA(buf, "PID %d\r\n", pid);
    out(buf);
    ExitProcess(0);
}
