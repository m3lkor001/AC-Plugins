/* Brings Decal's agent window up (it sits in the tray): asks the agent for "Configure" - the same as the tray
   icon's right-click menu - then puts the window in front. Prints what it did. */
#include <windows.h>
#include <stdio.h>
#include <string.h>
#define ID_CONFIGURE 32771
static int visible = 0, hidden = 0, asked = 0;
static void front(HWND h) {
    ShowWindow(h, SW_RESTORE);
    SetWindowPos(h, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
    SetWindowPos(h, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
    SetForegroundWindow(h);
}
static BOOL CALLBACK each(HWND h, LPARAM l) {
    char t[256]; t[0] = 0;
    GetWindowTextA(h, t, sizeof t);
    if (strncmp(t, "Decal Agent", 11) != 0) return TRUE;
    RECT r; GetWindowRect(h, &r);
    /* the plugin list is "Decal Agent 2.9.8.3" and big; the tray's own window is just "Decal Agent" */
    if (t[11] != 0 && IsWindowVisible(h) && r.right - r.left > 150) { front(h); printf("in front: %s\n", t); visible++; }
    else if (t[11] == 0) { hidden++; if (l) { PostMessageA(h, WM_COMMAND, ID_CONFIGURE, 0); printf("asked for Configure: %s (%ldx%ld)\n", t, r.right - r.left, r.bottom - r.top); asked++; } }
    return TRUE;
}
int main(void) {
    int i;
    EnumWindows(each, 0);
    if (visible) return 0;
    if (!hidden) { printf("not found\n"); return 1; }
    EnumWindows(each, 1);
    for (i = 0; i < 20; i++) { Sleep(300); visible = 0; hidden = 0; EnumWindows(each, 0); if (visible) return 0; }
    printf("asked %d window(s), nothing showed\n", asked);
    return 1;
}
