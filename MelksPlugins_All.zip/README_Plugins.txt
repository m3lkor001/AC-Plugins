Melk's Plugins for Asheron's Call (InfiniteLeaftide)
=====================================================

What's in here
--------------
  MelksTank\               MelkTank - combat, buffs, pets, nav, metas, looting, Monster-Dex catching
     MelkTank.dll          the plugin Decal loads (a small loader)
     MelkTankCore.dll      everything else (the loader loads it - keep the two together)
     Settings\             monster database, zone landblocks, saved locations
     Profiles\             loot profiles, metas, nav routes, monster lists
  MelksQB\                 MelksQB quest tracker
     MelksQuestTracker.dll
     MelksQuestTrackerCore.dll  (the loader loads it - keep the two together)
     QuestDatabase.xml     every quest, its QB flags and its walkthrough
  MelksLuminanceTracker\   luminance / coin tracker
     MelksLuminanceTracker.dll
     MelksLuminanceTrackerCore.dll

You need first
--------------
  - Decal 2.9.8.3 (the current version)
  - UtilityBelt, installed and ticked in Decal (the windows are drawn with UtilityBelt's window system)
  - .NET Framework 4.8 (already part of Windows 10 / 11)

Windows: the dlls must not be "blocked"
---------------------------------------
  Windows marks files that came from the internet as blocked, and Decal can't register a blocked dll -
  it says "Failed to register". After extracting, right-click each of the three loader dlls (listed under
  Install) -> Properties -> if there's an "Unblock" tick box at the bottom of the General tab, tick it -> OK.
  Or unblock all of them at once in PowerShell (change the path to your Decal Plugins folder):
     Get-ChildItem "C:\Games\Decal Plugins\Melks*" -Recurse | Unblock-File

Install
-------
  1. Put the zip in your Decal Plugins folder (where your other plugins live, e.g. C:\Games\Decal Plugins)
     and "Extract here". You get the three folders above.
  2. Open Decal (the Decal Agent - right-click the Decal icon in the tray, or run "Decal Agent"), click Add,
     and pick each plugin's dll:
        MelksTank\MelkTank.dll                (NOT MelkTankCore.dll)
        MelksQB\MelksQuestTracker.dll
        MelksLuminanceTracker\MelksLuminanceTracker.dll
     Make sure each one is ticked (enabled).
  3. Start the game. Each plugin gets a window / bar icon. Settings are saved per character next to the dll
     the first time you change something.

If Decal says "Failed to register"
----------------------------------
  1. You picked a zip - Decal can only add a .dll. Extract the zip first and add the dll from the
     extracted folder.
  2. The dll is blocked - see "the dlls must not be blocked" above.
  3. You picked a Core dll - pick the small one without "Core" in its name.
  4. The dll was moved out of its folder - each loader and its Core dll must stay together in the plugin's folder.
  5. The folder is on OneDrive or a network drive - put the plugins on your local disk (e.g. C:\Games\Decal Plugins).
  6. Decal is older than 2.9.8.3 - update Decal.
  Plugins that register but show no window: UtilityBelt isn't installed or isn't ticked in Decal.

Updating later
--------------
  Extract the newer zip over the top (then unblock the dll if Windows has blocked it). Your settings and logs are separate files and aren't in the zip,
  so they're kept. All three reload themselves when their Core dll is replaced, so you can update with the game running.
  (A new loader dll - MelkTank.dll, MelksQuestTracker.dll, MelksLuminanceTracker.dll - needs a game restart.)

  The MelksQB dungeon maps aren't in this set - keep your existing MelksQB\Maps folder.
