# MelkTank

Combat replacement for Virindi Tank. The window is drawn with ImGui through UtilityBelt.Service, not VVS.

## Build and install

A prebuilt `MelkTank.dll` is provided. To install it:

1. Copy it into this folder.
2. In Decal's Agent, click **Add**, browse to it, and enable it.
3. UtilityBelt must be running. The window shows up in UtilityBelt's HUD bar as **MelkTank**.

To rebuild it yourself, run `dotnet build -c Release`. The project file references the DLLs in your Wine prefix directly.

Chat commands: `/mtank on`, `/mtank off`, `/mtank pause`, `/mtank resume`, `/mtank status`.

## Tabs

- **Main:** the combat on/off switch and attack range.
  - "Stop VTank navigation while in combat" holds VTank's route while monsters are in range or anything you've DoT'd is still alive.
  - Choose whether to debuff all nearby monsters first or only the target.
  - Refresh DoTs, refresh vulns, and how many seconds before expiry to reapply.
  - The level 1 checkboxes for DoT, vuln, war and void. Unchecked means level 8.
  - Default attack type and the melee/missile attack key.
  - Duration calibration fields.
  - The Melk's buffer and pet summoner toggles.
- **Monsters:** works like VTank's Monsters tab.
  - F B G I Y V are vulns. A R S pick arcs, rings or streaks. WC FC Cp DC Cs are DoTs.
  - Rings are the level 6 (Cassius' Ring of Fire, Clouded Soul, ...) or level 7 "II" versions. "Level 1 ring" on the Main tab picks level 6.
  - P is priority. -1 means never attack.
  - Use **Add** to type a monster name, or **Add Sel** to add the selected monster.
- **Items:** select a weapon, wand or shield in your pack and click **Add Selected**. The type and element are guessed and can be changed.
- **Tracking:** every monster being tracked, with its debuffs and the time left on each.

## How the debuff loop works

Monsters in range are sorted by priority, then by distance.

The plugin casts the first missing or expiring debuff on the first monster that needs one. It waits for `You cast <spell> on <monster>` before moving on. That message records an expiry of the base duration (from the Spells sheet) times the calibrated multiplier.

Resists, fizzles, or no confirmation within 4 seconds put that debuff on a 3-second back-off for that monster.

Once nothing needs debuffing, it attacks the top target.

## Working with MelksBuffer and MelksPetSummoner

Both plugins already pause VTank while they need the character. Their pause and resume code now also calls `MelkTank.PluginCore.Pause` and `Resume`. While either one is working, MelkTank stops casting, equipping and changing combat mode. It picks up again once both have finished.

## Duration

Multiplier = in-game minutes ÷ base minutes for one known buff. The default is 9270 ÷ 90 = **103×**, which is 154 h 30 m on a level 8 creature buff with 2,000 augs.

## Verified vs. still to test

**Verified:** the plugin builds against your installed `Decal.Adapter` 2.9.8.3, the Decal interop DLLs and `UtilityBelt.Service`, which includes ImGui. That build checked every call it makes:

- The HUD: `CreateHud`, `OnPreRender`, `OnRender` and `ShowInBar`.
- Every ImGui table and widget.
- Casting, `BusyState`, combat mode and the window handle.

Equipping and wield detection copy what MelksBuffer already does in game. It switches to peace mode, then "uses" the item, and treats `Wielder` matching your character as wielded.

**Still to test in game:**
- **Melee and missile attacks:** these press your attack key in the AC window. Pick the key on the Main tab and turn on auto-repeat attacks.
- **Cast confirmation:** casts are confirmed by the chat line `You cast <spell> on <monster>`.
- **Melk's buffer and pet summoner:** toggled with `/mbuff on|off` and `/mpets on|off`.
