// The landscape: a base texture per cell corner recipe, up to three blended overlays and two road layers, as AC draws
// it. Ported from OpenAC's terrain_modern shaders (MIT). Each vertex carries its cell's recipe (layer indices, alpha
// map indices, rotations) in CUSTOM0..3 as floats; 255 means "none".
shader_type spatial;
render_mode cull_disabled, diffuse_lambert, specular_schlick_ggx;

uniform sampler2DArray terrain_tex : source_color, filter_linear_mipmap_anisotropic, repeat_enable;
uniform sampler2DArray alpha_tex : filter_linear, repeat_disable;
uniform float tiling[36];
// where building floors lie on the ground (set per landblock): the ground isn't drawn there
uniform sampler2D floor_mask : filter_nearest, repeat_disable;
uniform bool has_floor_mask = false;
// the doorway and window openings near the camera, by building (see ObjectStreamer.PortalsChanged). Ground seen
// through one of a building's openings that lies inside that building isn't drawn, so its rooms show through.
uniform sampler2D portal_data : filter_nearest, repeat_disable;
uniform int portal_count = 0;
// the building the camera is inside (its index in portal_data), or -1: then only the ground seen out through that
// building's openings is drawn - any other ground in view is under its floors
uniform int portal_inside = -1;
// ground too steep to walk up (steeper than AC's floor slope, a normal under 0.664 upright): tinted dark red
uniform bool steep_tint = false;
// water: which texture layers are water (1; 0.5 the deep sea), and whether it's drawn moving and shining, with foam
// along the shore (Options > Video: lighting and effects)
uniform float water_layer[36];
uniform bool water_fx = true;
// ground detail (Options > Video: lighting and effects): a little bumpiness made from the textures themselves (near the
// camera), and steep slopes textured from the side so cliffs aren't smeared (the game maps every cell from above)
uniform bool detail_bump = true;
uniform float bump_strength = 1.0;
uniform bool triplanar = true;

varying vec2 base_uv;
varying vec2 lb_uv;
varying vec3 w_pos;
varying vec3 w_true;   // where the ground really is (before the floors-win offset, which tilts it with distance)
varying vec3 w_nrm;    // the ground's normal (world)
varying flat vec4 v_c0;   // base layer, overlay 0 layer, overlay 0 alpha, overlay 0 rotation
varying flat vec4 v_c1;   // overlay 1 layer / alpha, overlay 2 layer / alpha
varying flat vec4 v_c2;   // road 0 layer / alpha, road 1 layer / alpha
varying flat vec4 v_c3;   // overlay 1, overlay 2, road 0, road 1 rotations

void vertex() {
	// Building floors lie right on the ground: the ground is drawn a little lower (more with distance, as depth
	// precision falls off) so floors always win. Retail and OpenAC do the same with a small offset.
	vec3 world = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	w_true = world - INV_VIEW_MATRIX[3].xyz;   // (from the camera: small numbers, so the slope is exact far off too)
	float dist = length(world - INV_VIEW_MATRIX[3].xyz);
	VERTEX.y -= 0.02 + dist * 0.0004;
	lb_uv = vec2(VERTEX.x / 192.0, -VERTEX.z / 192.0);
	w_pos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	base_uv = UV;
	w_nrm = (MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz;
	v_c0 = CUSTOM0;
	v_c1 = CUSTOM1;
	v_c2 = CUSTOM2;
	v_c3 = CUSTOM3;
}

float idx(float v) { return v >= 254.0 ? -1.0 : v; }

vec2 rotate_uv(vec2 uv, float r) {
	if (r > 2.5) return vec2(uv.y, 1.0 - uv.x);
	if (r > 1.5) return vec2(1.0 - uv.x, 1.0 - uv.y);
	if (r > 0.5) return vec2(1.0 - uv.y, uv.x);
	return uv;
}

vec4 sample_terrain(float layer) {
	float tl = tiling[int(layer)];
	vec2 uv = base_uv * tl;
	if (!triplanar) return texture(terrain_tex, vec3(uv, layer));
	// steep ground: also sampled from the side (east-west and north-south), blended by which way it faces, so the
	// texture keeps its size on a cliff instead of stretching down it. (Gradients worked out before any branch.)
	vec2 ux = w_pos.zy * (tl / 24.0), uz = w_pos.xy * (tl / 24.0);
	vec2 dux = dFdx(ux), duy = dFdy(ux), dzx = dFdx(uz), dzy = dFdy(uz), dtx = dFdx(uv), dty = dFdy(uv);
	vec4 top = textureGrad(terrain_tex, vec3(uv, layer), dtx, dty);
	vec3 n = normalize(w_nrm);
	float steep = smoothstep(0.82, 0.55, abs(n.y));
	if (steep <= 0.001) return top;
	vec2 bw = pow(abs(n.xz), vec2(4.0));
	bw /= max(bw.x + bw.y, 1e-4);
	vec4 side = textureGrad(terrain_tex, vec3(ux, layer), dux, duy) * bw.x + textureGrad(terrain_tex, vec3(uz, layer), dzx, dzy) * bw.y;
	return mix(top, side, steep);
}

float sample_alpha(float alpha_layer, float rot) {
	return texture(alpha_tex, vec3(rotate_uv(base_uv, rot), alpha_layer)).r;
}

// one overlay: its texture, with the alpha map's weight in .a
vec4 overlay(float layer, float alpha_layer, float rot) {
	vec4 t = sample_terrain(layer);
	if (alpha_layer >= 0.0) t.a = sample_alpha(alpha_layer, rot);
	return t;
}

vec4 mask_blend3(vec4 t0, vec4 t1, vec4 t2, float h0, float h1, float h2) {
	float a0 = h0 == 0.0 ? 1.0 : t0.a;
	float a1 = h1 == 0.0 ? 1.0 : t1.a;
	float a2 = h2 == 0.0 ? 1.0 : t2.a;
	float ar = 1.0 - (a0 * a1 * a2);
	float safe = max(ar, 1e-6);
	a0 = 1.0 - a0;
	a1 = 1.0 - a1;
	a2 = 1.0 - a2;
	vec3 r = a0 * t0.rgb + (1.0 - a0) * a1 * t1.rgb + (1.0 - a1) * a2 * t2.rgb;
	return vec4(r / safe, ar);
}

// whether the segment from o to o + d crosses the triangle (a, b, c)
bool crosses(vec3 o, vec3 d, vec3 a, vec3 b, vec3 c) {
	vec3 e1 = b - a, e2 = c - a;
	vec3 p = cross(d, e2);
	float det = dot(e1, p);
	if (abs(det) < 1e-7) return false;
	float inv = 1.0 / det;
	vec3 s = o - a;
	float u = dot(s, p) * inv;
	if (u < 0.0 || u > 1.0) return false;
	vec3 q = cross(s, e1);
	float v = dot(d, q) * inv;
	if (v < 0.0 || u + v > 1.0) return false;
	float t = dot(e2, q) * inv;
	return t > 0.0 && t < 1.0;
}

// how many of building i's openings the view of p crosses: odd means p is on the other side of the walls from the
// camera (seen in through a door, or out through a window from inside); even means in and out again, or neither
// whether p is ground under a level opening (a cave's mouth open to the sky, like a pit): the room below is
// open upward, so the ground anywhere beneath the opening (and a little above it) belongs to the room, not the
// landscape, and isn't drawn.
bool over_hole(vec3 p, vec3 a, vec3 b, vec3 c) {
	vec3 n = cross(b - a, c - a);
	float len = length(n);
	if (len < 1e-6 || abs(n.y) < 0.7 * len) return false;
	vec2 v0 = c.xz - a.xz, v1 = b.xz - a.xz, v2 = p.xz - a.xz;
	float d00 = dot(v0, v0), d01 = dot(v0, v1), d11 = dot(v1, v1), d20 = dot(v2, v0), d21 = dot(v2, v1);
	float den = d00 * d11 - d01 * d01;
	if (abs(den) < 1e-8) return false;
	float u = (d11 * d20 - d01 * d21) / den, v = (d00 * d21 - d01 * d20) / den;
	if (u < 0.0 || v < 0.0 || u + v > 1.0) return false;
	float y = a.y - (n.x * (p.x - a.x) + n.z * (p.z - a.z)) / n.y;
	return p.y > y - 40.0 && p.y < y + 1.0;
}

// -1: p is over a level opening (not drawn). Otherwise:
int crossings(int i, vec3 cam, vec3 p) {
	int first = int(texelFetch(portal_data, ivec2(i * 3, 0), 0).w + 0.5);
	int count = int(texelFetch(portal_data, ivec2(i * 3 + 1, 0), 0).w + 0.5);
	int n = 0;
	for (int t = first; t < first + count; t++) {
		vec3 a = texelFetch(portal_data, ivec2(t * 3, 1), 0).xyz;
		vec3 b = texelFetch(portal_data, ivec2(t * 3 + 1, 1), 0).xyz;
		vec3 c = texelFetch(portal_data, ivec2(t * 3 + 2, 1), 0).xyz;
		if (over_hole(p, a, b, c)) return -1;
		if (crosses(cam, p - cam, a, b, c)) n++;
	}
	return n;
}

// from outside: ground inside a building, seen in through its openings (and not out again)
bool behind_opening(vec3 cam, vec3 p) {
	for (int i = 0; i < portal_count; i++) {
		vec4 lo = texelFetch(portal_data, ivec2(i * 3, 0), 0);
		vec4 hi = texelFetch(portal_data, ivec2(i * 3 + 1, 0), 0);
		if (any(lessThan(p, lo.xyz - vec3(0.3))) || any(greaterThan(p, hi.xyz + vec3(0.3)))) continue;
		int n = crossings(i, cam, p);
		if (n < 0 || (n & 1) == 1) return true;
	}
	return false;
}

void fragment() {
	if (has_floor_mask && texture(floor_mask, lb_uv).r > 0.5) discard;
	if (portal_inside >= 0) {
		int n = crossings(portal_inside, CAMERA_POSITION_WORLD, w_pos);
		if (n < 0 || (n & 1) == 0) discard;
	} else if (portal_count > 0 && behind_opening(CAMERA_POSITION_WORLD, w_pos)) discard;
	float base_l = idx(v_c0.x);
	float o0 = idx(v_c0.y), o0a = idx(v_c0.z);
	float o1 = idx(v_c1.x), o1a = idx(v_c1.y);
	float o2 = idx(v_c1.z), o2a = idx(v_c1.w);
	float r0 = idx(v_c2.x), r0a = idx(v_c2.y);
	float r1 = idx(v_c2.z), r1a = idx(v_c2.w);

	vec4 base_c = base_l >= 0.0 ? sample_terrain(base_l) : vec4(0.0);

	vec4 ovl = vec4(0.0);
	if (o0 >= 0.0) {
		float h0 = 1.0, h1 = o1 >= 0.0 ? 1.0 : 0.0, h2 = o2 >= 0.0 ? 1.0 : 0.0;
		vec4 t0 = overlay(o0, o0a, v_c0.w);
		vec4 t1 = h1 > 0.0 ? overlay(o1, o1a, mod(v_c3.x, 4.0)) : vec4(0.0);
		vec4 t2 = h2 > 0.0 ? overlay(o2, o2a, v_c3.y) : vec4(0.0);
		ovl = mask_blend3(t0, t1, t2, h0, h1, h2);
	}

	vec4 road = vec4(0.0);
	if (r0 >= 0.0) {
		road = sample_terrain(r0);
		if (r0a >= 0.0) {
			float a0 = sample_alpha(r0a, v_c3.z);
			road.a = 1.0 - a0;
			if (r1 >= 0.0 && r1a >= 0.0) road.a = 1.0 - a0 * sample_alpha(r1a, v_c3.w);
		}
	}

	vec3 rgb = base_c.rgb * ((1.0 - ovl.a) * (1.0 - road.a))
	         + ovl.rgb * (ovl.a * (1.0 - road.a))
	         + road.rgb * road.a;

	// how much of this point is water (and of that, deep sea): the same blend as the colours, of each layer's flags
	float water = 0.0, deep = 0.0;
	if (water_fx) {
		float fb = base_l >= 0.0 ? water_layer[int(base_l)] : 0.0;
		vec2 wb = vec2(fb > 0.0 ? 1.0 : 0.0, fb > 0.25 && fb < 0.75 ? 1.0 : 0.0);
		vec2 wo = vec2(0.0);
		float oa = 0.0;
		if (o0 >= 0.0) {
			float h1 = o1 >= 0.0 ? 1.0 : 0.0, h2 = o2 >= 0.0 ? 1.0 : 0.0;
			float f0 = water_layer[int(o0)], f1 = h1 > 0.0 ? water_layer[int(o1)] : 0.0, f2 = h2 > 0.0 ? water_layer[int(o2)] : 0.0;
			float a0 = o0a >= 0.0 ? sample_alpha(o0a, v_c0.w) : 1.0;
			float a1 = h1 > 0.0 && o1a >= 0.0 ? sample_alpha(o1a, mod(v_c3.x, 4.0)) : 1.0;
			float a2 = h2 > 0.0 && o2a >= 0.0 ? sample_alpha(o2a, v_c3.y) : 1.0;
			vec4 w4 = mask_blend3(vec4(f0 > 0.0 ? 1.0 : 0.0, f0 > 0.25 && f0 < 0.75 ? 1.0 : 0.0, 0.0, a0),
			                      vec4(f1 > 0.0 ? 1.0 : 0.0, f1 > 0.25 && f1 < 0.75 ? 1.0 : 0.0, 0.0, a1),
			                      vec4(f2 > 0.0 ? 1.0 : 0.0, f2 > 0.25 && f2 < 0.75 ? 1.0 : 0.0, 0.0, a2), 1.0, h1, h2);
			wo = w4.rg;
			oa = w4.a;
		}
		vec2 w = wb * ((1.0 - oa) * (1.0 - road.a)) + wo * (oa * (1.0 - road.a));
		water = clamp(w.x, 0.0, 1.0);
		deep = clamp(w.y, 0.0, 1.0);
	}

	// bumpiness from the texture's own light and dark (a bump map made on the fly), near the camera, not on water
	if (detail_bump) {
		float h = dot(rgb, vec3(0.3, 0.59, 0.11)) * 0.12 * bump_strength;
		vec3 dpdx = dFdx(w_true), dpdy = dFdy(w_true);
		float dhx = dFdx(h), dhy = dFdy(h);
		vec3 n = normalize(w_nrm);
		vec3 r1 = cross(dpdy, n), r2 = cross(n, dpdx);
		float det = dot(dpdx, r1);
		float fade = (1.0 - smoothstep(35.0, 80.0, length(w_true))) * (1.0 - water);
		if (abs(det) > 1e-8 && fade > 0.001) {
			vec3 grad = (dhx * r1 + dhy * r2) / det;
			vec3 bn = normalize(n - grad);
			NORMAL = normalize(mix(NORMAL, normalize((VIEW_MATRIX * vec4(bn, 0.0)).xyz), fade));
		}
	}

	float spec = 0.0, rough = 1.0;
	if (water > 0.01) {
		// ripples: a few waves of different sizes, moving different ways
		vec3 wp = w_pos;
		float t = TIME;
		vec2 g = vec2(0.0);
		g += vec2(0.8, 0.6) * cos(dot(wp.xz, vec2(0.8, 0.6)) * 0.55 + t * 1.3) * 0.06;
		g += vec2(-0.5, 0.86) * cos(dot(wp.xz, vec2(-0.5, 0.86)) * 0.9 + t * 1.7) * 0.04;
		g += vec2(0.96, -0.28) * cos(dot(wp.xz, vec2(0.96, -0.28)) * 1.7 + t * 2.3) * 0.025;
		g += vec2(-0.3, -0.95) * cos(dot(wp.xz, vec2(-0.3, -0.95)) * 3.1 + t * 2.9) * 0.015;
		vec3 wn = normalize(vec3(-g.x, 1.0, -g.y));
		vec3 vn = normalize((VIEW_MATRIX * vec4(wn, 0.0)).xyz);
		NORMAL = normalize(mix(NORMAL, vn, water));
		// darker the deeper it is; the sky's sheen at a low angle
		vec3 v = normalize(CAMERA_POSITION_WORLD - wp);
		float fres = pow(1.0 - clamp(abs(dot(wn, v)), 0.0, 1.0), 5.0);
		vec3 wc = rgb * mix(0.85, 0.6, deep);
		wc = mix(wc, vec3(0.55, 0.65, 0.72), fres * 0.45);
		// foam where water meets the land (the blend between them), moving
		float edge = 1.0 - abs(water * 2.0 - 1.0);
		float churn = 0.5 + 0.5 * sin(t * 1.6 + wp.x * 0.9 + wp.z * 0.7) * sin(t * 1.1 - wp.x * 0.5 + wp.z * 1.3);
		float foam = smoothstep(0.35, 0.95, edge) * (0.55 + 0.45 * churn);
		wc = mix(wc, vec3(0.92, 0.95, 0.97), foam * 0.45);
		rgb = mix(rgb, wc, water);
		spec = 0.6 * water * (1.0 - foam * 0.6);
		rough = mix(1.0, 0.07, water * (1.0 - foam * 0.7));
	}
	// last, so nothing above paints over it (the water's colour and foam came after it once and hid it)
	if (steep_tint) {
		vec3 sn = normalize(cross(dFdx(w_true), dFdy(w_true)));
		// (and deep water - a cell that's water at all four corners, flagged +4 on custom3.x: it can't be walked into)
		if (abs(sn.y) < 0.664 || v_c3.x > 3.5) rgb = mix(rgb, vec3(0.45, 0.04, 0.04), 0.5);
	}
	ALBEDO = clamp(rgb, 0.0, 1.0);
	ROUGHNESS = rough;
	SPECULAR = spec;
}
