MelkTank (build b346, Nov 12 2026) - combat / nav / loot / buff / pet plugin, a Virindi Tank replacement.

Install
1. Unzip so this folder is  C:\Games\Decal Plugins\MelksTank  (any folder works).
2. Decal Agent > Add > pick MelkTank.dll in this folder, and tick it.
   Needs UtilityBelt (with UtilityBelt.Service) running.
3. MelkTank.dll is a small loader: it loads MelkTankCore.dll and picks up a newer MelkTankCore.dll
   dropped in while the game runs (no restart needed).

Virindi Tank can stay off: Settings > Advanced > VTank replacement keeps UtilityBelt working without it.
Coming from Virindi Tank / Virindi Sense: Settings > Basic > Import from Virindi Tank / Virindi Sense.
Settings, logs and profiles are made in Settings\, Logs\ and Profiles\ the first time it runs.
