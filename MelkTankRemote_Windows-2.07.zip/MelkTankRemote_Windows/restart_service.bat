@echo off
rem Stops the MelkTank phone service and starts it again.
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Process -Filter \"Name like 'python%%'\" | Where-Object { $_.CommandLine -match 'run_service\.pyw|service\.py' -and $_.CommandLine -match [regex]::Escape('%~dp0') } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }"
timeout /t 2 /nobreak >nul
start "" "%~dp0.venv\Scripts\pythonw.exe" "%~dp0run_service.pyw"
echo Phone service restarted.
timeout /t 3 >nul
