# MelkTank Remote for Windows - setup. Run setup.bat (it runs this).
$ErrorActionPreference = "Continue"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here

Write-Host "MelkTank Remote setup" -ForegroundColor Cyan

# 1. Python
$pyExe = $null; $pyArgs = @()
foreach ($c in @("py -3", "python")) {
    $parts = $c.Split(" ")
    $exe = $parts[0]; $args0 = @($parts | Select-Object -Skip 1)
    try {
        $v = & $exe @args0 -c "import sys; print('%d.%d' % sys.version_info[:2])" 2>$null
        if ($LASTEXITCODE -eq 0 -and $v -and [version]$v -ge [version]"3.10") { $pyExe = $exe; $pyArgs = $args0; break }
    } catch {}
}
if (-not $pyExe) {
    Write-Host "Python 3.10 or newer wasn't found. Install it from https://www.python.org/downloads/windows/" -ForegroundColor Red
    Write-Host "(tick 'Add python.exe to PATH'), then run setup.bat again."
    exit 1
}

# 2. A private Python for MelkTank (in this folder) with Qt, psutil and Pillow
if (-not (Test-Path "$here\.venv\Scripts\python.exe")) {
    Write-Host "Creating the Python environment..."
    & $pyExe @pyArgs -m venv "$here\.venv"
}
$vpy = "$here\.venv\Scripts\python.exe"
$vpyw = "$here\.venv\Scripts\pythonw.exe"
Write-Host "Installing PySide6, psutil and Pillow (a few minutes the first time)..."
& $vpy -m pip install --upgrade --quiet pip
& $vpy -m pip install --quiet PySide6 psutil pillow
if ($LASTEXITCODE -ne 0) { Write-Host "pip install failed - check the internet connection and run setup.bat again." -ForegroundColor Red; exit 1 }

# 3. Where MelkTank is installed
$default = "C:\Games\Decal Plugins\MelksTank"
$cur = & $vpy -c "import mtcore; print(mtcore.load_config().get('plugin_dir') or '')"
if ($cur) { $default = $cur }
$plugin = Read-Host "MelkTank plugin folder (the one with MelkTank.dll) [$default]"
if (-not $plugin) { $plugin = $default }
if (-not (Test-Path "$plugin\MelkTank.dll")) {
    Write-Host "Note: MelkTank.dll isn't in $plugin - you can fix the folder later in the launcher's Settings > Game setup." -ForegroundColor Yellow
}
$env:MT_PLUGIN = $plugin
$remote = & $vpy -c "import os, mtcore; c = mtcore.load_config(); c['plugin_dir'] = os.environ['MT_PLUGIN']; mtcore.save_config(c); print(mtcore.install_helper(c, 'mtlaunch.exe'))"
Write-Host "mtlaunch.exe copied to $remote"

# 4. Shortcuts: Start menu (Launcher, Loot Editor) and Startup (the phone service)
$ws = New-Object -ComObject WScript.Shell
function Link($path, $target, $arguments) {
    $s = $ws.CreateShortcut($path)
    $s.TargetPath = $target
    $s.Arguments = $arguments
    $s.WorkingDirectory = $here
    $s.Save()
}
$menu = Join-Path ([Environment]::GetFolderPath("Programs")) "MelkTank"
New-Item -ItemType Directory -Force -Path $menu | Out-Null
Link "$menu\MelkTank Launcher.lnk" $vpyw "`"$here\launcher.py`""
Link "$menu\MelkTank Loot Editor.lnk" $vpyw "`"$here\loot_editor.py`""
Link "$menu\MelkTank Phone Service.lnk" $vpyw "`"$here\run_service.pyw`""
Link (Join-Path ([Environment]::GetFolderPath("Startup")) "MelkTank Phone Service.lnk") $vpyw "`"$here\run_service.pyw`""
Write-Host "Start menu shortcuts made (MelkTank folder); the phone service starts when you sign in."

# 5. Let the phone reach the service (port 8765)
$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if ($admin) {
    if (-not (Get-NetFirewallRule -DisplayName "MelkTank phone service" -ErrorAction SilentlyContinue)) {
        New-NetFirewallRule -DisplayName "MelkTank phone service" -Direction Inbound -Protocol TCP -LocalPort 8765 -Action Allow -Profile Any | Out-Null
    }
    Write-Host "Firewall: port 8765 allowed."
} else {
    Write-Host "Firewall: when Windows asks whether Python may use the network, click Allow (tick Private and Public)." -ForegroundColor Yellow
    Write-Host "  (or run setup.bat once with 'Run as administrator' to add the rule)"
}

# 6. Start the service now
Start-Process $vpyw -ArgumentList "`"$here\run_service.pyw`"" -WorkingDirectory $here
Write-Host ""
Write-Host "Done. Next: open 'MelkTank Launcher' from the Start menu, add your accounts, then see README.txt for the phone." -ForegroundColor Green
