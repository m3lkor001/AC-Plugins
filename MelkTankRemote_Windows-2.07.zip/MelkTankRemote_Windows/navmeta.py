"""Routes (.mtnav) and metas (.mtmet / .met) for the phone's nav and meta editors.

Files live in MelkTank's Profiles/Navs and Profiles/Metas. After a save the running games are told to read the
file again (MelkTank keeps its own copy of each route, and of the loaded meta).
"""
import base64
import json
import os
import shutil
import time
import xml.etree.ElementTree as ET

import mtcore

_HERE = os.path.dirname(os.path.abspath(__file__))


def nav_dir(cfg):
    return os.path.join(mtcore.plugin_dir(cfg), "Profiles", "Navs")


def meta_dir(cfg):
    return os.path.join(mtcore.plugin_dir(cfg), "Profiles", "Metas")


def _win_path(cfg, path):
    """The game's (Windows) name for a file under drive_c."""
    if os.name == "nt":
        return os.path.abspath(path)
    rel = os.path.relpath(path, mtcore.drive_c(cfg))
    return "C:\\" + rel.replace("/", "\\")


def _safe(name):
    bad = '<>:"/\\|?*'
    n = "".join("_" if c in bad else c for c in (name or "").strip())
    return n.strip(". ") or "New route"


def _inside(base, rel):
    p = os.path.normpath(os.path.join(base, (rel or "").replace("\\", "/").lstrip("/")))
    if not (p == base or p.startswith(base + os.sep)):
        raise ValueError("bad path")
    return p


def _trash(cfg, path):
    """Moves a file to MelkTank's _to_delete (never deleted outright)."""
    td = os.path.join(mtcore.plugin_dir(cfg), "_to_delete")
    os.makedirs(td, exist_ok=True)
    base = os.path.basename(path)
    dst = os.path.join(td, time.strftime("%Y%m%d-%H%M%S-") + base)
    shutil.move(path, dst)


def _backup(path):
    if os.path.exists(path):
        shutil.copy2(path, path + ".bak")


def _push(cfg, action, name, value="", feature=""):
    sent = []
    for a in cfg.get("accounts", []):
        if mtcore.client_pids(a["account"]):
            mtcore.send_command(cfg, a["account"], action, feature=feature, value=value, name=name)
            sent.append(a["account"])
    return sent


def _mtime(path):
    try:
        return int(os.path.getmtime(path) * 1000)
    except OSError:
        return 0


# ── routes ──────────────────────────────────────────────────────────────────────────────

def nav_list(cfg):
    base = nav_dir(cfg)
    out = []
    for root, dirs, files in os.walk(base):
        dirs[:] = [d for d in dirs if d.lower() != "spots"]
        for f in files:
            if not f.lower().endswith(".mtnav"):
                continue
            p = os.path.join(root, f)
            rel = os.path.relpath(p, base).replace(os.sep, "/")
            name, steps = os.path.splitext(f)[0], 0
            try:
                r = ET.parse(p).getroot()
                if r.tag != "MelkTankRoute":
                    continue
                name = r.get("name") or name
                steps = len(r.findall("Step"))
            except Exception:
                pass
            out.append({"name": name, "file": rel, "steps": steps, "mtime": _mtime(p)})
    out.sort(key=lambda x: x["name"].lower())
    return {"routes": out, "presets": nav_presets(cfg), "presetList": preset_list(cfg)}


def nav_presets(cfg):
    p = os.path.join(mtcore.plugin_dir(cfg), "Settings", "MelkTank_NavPresets.xml")
    try:
        return [e.get("name") for e in ET.parse(p).getroot().findall("Preset") if e.get("name")]
    except Exception:
        return []


def nav_read(cfg, rel):
    p = _inside(nav_dir(cfg), rel)
    r = ET.parse(p).getroot()
    steps = []
    for s in r.findall("Step"):
        st = dict(s.attrib)
        conds = [dict(c.attrib) for c in s.findall("Cond")]
        if conds:
            st["conds"] = conds
        steps.append(st)
    return {"file": rel.replace("\\", "/"), "mtime": _mtime(p), "attrs": dict(r.attrib), "steps": steps}


def _nav_xml(cfg, data, path):
    attrs = dict(data.get("attrs") or {})
    attrs["file"] = _win_path(cfg, path)
    root = ET.Element("MelkTankRoute")
    order = ["name", "mode", "file", "arrive"]
    for k in order + [k for k in attrs if k not in order]:
        if k in attrs and attrs[k] is not None and str(attrs[k]) != "":
            root.set(k, str(attrs[k]))
    for st in data.get("steps") or []:
        e = ET.SubElement(root, "Step")
        for k in ["kind", "ns", "ew", "z", "text", "wait", "op", "count"] + [k for k in st if k not in ("kind", "ns", "ew", "z", "text", "wait", "op", "count", "conds")]:
            if k in st and k != "conds" and st[k] is not None:
                v = str(st[k])
                if k in ("op",) and v == "":
                    continue
                if k == "count" and v in ("", "0"):
                    continue
                e.set(k, v)
        for c in st.get("conds") or []:
            ce = ET.SubElement(e, "Cond")
            for k, v in c.items():
                if v is not None:
                    ce.set(k, str(v))
    ET.indent(root, space="  ")
    return ET.tostring(root, encoding="unicode")


def nav_save(cfg, rel, data, mtime=None, force=False):
    """Writes a route. The name decides the file name (a rename renames the file). Returns the saved route."""
    base = nav_dir(cfg)
    old = _inside(base, rel) if rel else None
    if old and os.path.exists(old) and mtime and not force and abs(_mtime(old) - int(mtime)) > 2:
        return None, "The route was changed on the PC since you opened it - open it again (or save anyway)."
    name = ((data.get("attrs") or {}).get("name") or "").strip() or "New route"
    folder = os.path.dirname(old) if old else base
    path = os.path.join(folder, _safe(name) + ".mtnav")
    if path != old and os.path.exists(path):
        return None, "There's already a route file " + os.path.basename(path) + "."
    oldname = None
    if old and os.path.exists(old):
        try:
            oldname = ET.parse(old).getroot().get("name")
        except Exception:
            pass
    data.setdefault("attrs", {})["name"] = name
    xml = _nav_xml(cfg, data, path)
    os.makedirs(folder, exist_ok=True)
    _backup(path)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(xml)
    os.replace(tmp, path)
    newrel = os.path.relpath(path, base).replace(os.sep, "/")
    if old and path != old and os.path.exists(old):
        _trash(cfg, old)
    sent = _push(cfg, "navfile", newrel, value="changed", feature=oldname if oldname and oldname != name else "")
    return {"route": nav_read(cfg, newrel), "sent": sent}, None


def nav_new(cfg, name, copy_of=None):
    base = nav_dir(cfg)
    name = (name or "").strip() or "New route"
    if copy_of:
        data = nav_read(cfg, copy_of)
        data["attrs"]["name"] = name
    else:
        data = {"attrs": {"name": name, "mode": "0", "arrive": "2.5"}, "steps": []}
    path = os.path.join(base, _safe(name) + ".mtnav")
    if os.path.exists(path):
        return None, "There's already a route called " + name + "."
    res, err = nav_save(cfg, None, data)
    return res, err


def nav_delete(cfg, rel):
    p = _inside(nav_dir(cfg), rel)
    name = None
    try:
        name = ET.parse(p).getroot().get("name")
    except Exception:
        pass
    _trash(cfg, p)
    sent = _push(cfg, "navfile", rel, value="deleted", feature=name or "")
    return {"sent": sent}


# ── presets (Settings/MelkTank_NavPresets.xml: <NavPresets><Preset name mode arrive><Step .../></Preset>...) ──
# MelkTank checks the file every few seconds and reads it again when it changed, so no push is needed.

def _presets_path(cfg):
    return os.path.join(mtcore.plugin_dir(cfg), "Settings", "MelkTank_NavPresets.xml")


def _presets_root(cfg):
    p = _presets_path(cfg)
    if os.path.exists(p):
        return ET.parse(p).getroot()
    return ET.Element("NavPresets")


def preset_read(cfg, name):
    p = _presets_path(cfg)
    for e in _presets_root(cfg).findall("Preset"):
        if e.get("name") == name:
            steps = []
            for s in e.findall("Step"):
                st = dict(s.attrib)
                conds = [dict(c.attrib) for c in s.findall("Cond")]
                if conds:
                    st["conds"] = conds
                steps.append(st)
            return {"preset": name, "mtime": _mtime(p), "attrs": dict(e.attrib), "steps": steps}
    raise FileNotFoundError(name)


def _write_presets(cfg, root):
    p = _presets_path(cfg)
    ET.indent(root, space="  ")
    _backup(p)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(ET.tostring(root, encoding="unicode"))
    os.replace(tmp, p)


def preset_save(cfg, old_name, data, mtime=None, force=False):
    p = _presets_path(cfg)
    if os.path.exists(p) and mtime and not force and abs(_mtime(p) - int(mtime)) > 2:
        return None, "The presets were changed on the PC since you opened this one - open it again (or save anyway)."
    root = _presets_root(cfg)
    attrs = dict(data.get("attrs") or {})
    name = (attrs.get("name") or "").strip() or "New preset"
    for e in root.findall("Preset"):
        if e.get("name") == name and name != old_name:
            return None, "There's already a preset called " + name + "."
    # the new element, built like a route's (then renamed)
    tmp = ET.fromstring(_nav_xml(cfg, {"attrs": {"name": name, "mode": attrs.get("mode", "0"), "arrive": attrs.get("arrive", "2.5")},
                                       "steps": data.get("steps") or []}, _presets_path(cfg)))
    tmp.tag = "Preset"
    tmp.attrib.pop("file", None)
    done = False
    kids = list(root)
    for i, e in enumerate(kids):
        if e.tag == "Preset" and e.get("name") == (old_name or name):
            root.remove(e)
            root.insert(i, tmp)
            done = True
            break
    if not done:
        root.append(tmp)
    _write_presets(cfg, root)
    sent = []
    if old_name and old_name != name:
        sent = _rename_preset_uses(cfg, old_name, name)
    return {"route": preset_read(cfg, name), "renamedIn": sent}, None


def _rename_preset_uses(cfg, old, new):
    """A renamed preset: the routes that use it are changed to the new name (and the games told)."""
    base = nav_dir(cfg)
    changed = []
    for r in nav_list(cfg)["routes"]:
        path = os.path.join(base, r["file"])
        try:
            tree = ET.parse(path)
            hit = False
            for st in tree.getroot().findall("Step"):
                if st.get("kind") == "Preset" and st.get("text") == old:
                    st.set("text", new)
                    hit = True
            if hit:
                ET.indent(tree.getroot(), space="  ")
                _backup(path)
                with open(path, "w", encoding="utf-8", newline="\r\n") as f:
                    f.write(ET.tostring(tree.getroot(), encoding="unicode"))
                _push(cfg, "navfile", r["file"], value="changed")
                changed.append(r["name"])
        except Exception:
            pass
    return changed


def preset_new(cfg, name, copy_of=None):
    name = (name or "").strip() or "New preset"
    data = {"attrs": {"name": name, "mode": "0", "arrive": "2.5"}, "steps": []}
    if copy_of:
        src = preset_read(cfg, copy_of)
        data["steps"] = src["steps"]
    return preset_save(cfg, None, data)


def preset_delete(cfg, name):
    root = _presets_root(cfg)
    for e in root.findall("Preset"):
        if e.get("name") == name:
            root.remove(e)
    _write_presets(cfg, root)
    return {"ok": True}


def preset_list(cfg):
    out = []
    for e in _presets_root(cfg).findall("Preset"):
        out.append({"name": e.get("name"), "steps": len(e.findall("Step"))})
    return out


# ── metas ───────────────────────────────────────────────────────────────────────────────
# VTank's format: "1", "CondAct", then a table (CType, AType, CData, AData, State). Values are typed lines:
# i / s / d / b + one line, ba + length line + raw bytes, TABLE + columns, flags, row count, rows. Latin-1, CRLF.

ENC = "latin-1"


class _Reader:
    def __init__(self, b):
        self.b, self.p = b, 0

    def line(self):
        i = self.b.find(b"\n", self.p)
        if i < 0:
            i = len(self.b)
        e = i
        if e > self.p and self.b[e - 1:e] == b"\r":
            e -= 1
        s = self.b[self.p:e].decode(ENC)
        self.p = min(len(self.b), i + 1)
        return s

    def raw(self, n):
        r = self.b[self.p:self.p + n]
        self.p += n
        return r


def _rval(r):
    t = r.line()
    if t in ("i", "s", "d", "b"):
        return {"t": t, "s": r.line()}
    if t == "ba":
        n = int(r.line() or "0")
        return {"t": "ba", "b64": base64.b64encode(r.raw(n)).decode("ascii")}
    if t == "TABLE":
        return {"t": "TABLE", **_rtable(r)}
    raise ValueError("unknown value type " + repr(t))


def _rtable(r):
    nc = int(r.line())
    cols = [r.line() for _ in range(nc)]
    flags = [r.line() for _ in range(nc)]
    n = int(r.line())
    rows = [[_rval(r) for _ in range(nc)] for _ in range(n)]
    return {"cols": cols, "flags": flags, "rows": rows}


def _is_list(v):
    return v.get("t") == "TABLE" and v.get("cols") == ["K", "V"]


def _cond(typ, data):
    c = {"type": typ}
    if typ in (2, 3, 21) and _is_list(data):
        c["kids"] = [_cond(int(row[0]["s"]), row[1]) for row in data["rows"]]
    else:
        c["data"] = data
    return c


def _act(typ, data):
    a = {"type": typ}
    if typ == 3 and _is_list(data):
        a["kids"] = [_act(int(row[0]["s"]), row[1]) for row in data["rows"]]
    else:
        a["data"] = data
    return a


def _kidsval(kids, fn):
    return {"t": "TABLE", "cols": ["K", "V"], "flags": ["n", "n"],
            "rows": [[{"t": "i", "s": str(int(k["type"]))}, fn(k)] for k in kids]}


def _cval(c):
    if c.get("kids") is not None:
        return _kidsval(c["kids"], _cval)
    return c.get("data") or {"t": "i", "s": "0"}


def _aval(a):
    if a.get("kids") is not None:
        return _kidsval(a["kids"], _aval)
    return a.get("data") or {"t": "i", "s": "0"}


def _wline(o, s):
    o.append((s + "\r\n").encode(ENC, errors="replace"))


def _wval(o, v):
    t = v.get("t", "i")
    _wline(o, t)
    if t == "ba":
        b = base64.b64decode(v.get("b64") or "")
        _wline(o, str(len(b)))
        o.append(b)
    elif t == "TABLE":
        _wtable(o, v)
    else:
        _wline(o, str(v.get("s", "")))


def _wtable(o, t):
    cols = t.get("cols") or []
    flags = t.get("flags") or ["n"] * len(cols)
    _wline(o, str(len(cols)))
    for c in cols:
        _wline(o, c)
    for f in flags:
        _wline(o, f)
    rows = t.get("rows") or []
    _wline(o, str(len(rows)))
    for row in rows:
        for v in row:
            _wval(o, v)


def meta_parse(b):
    r = _Reader(b)
    r.line()
    if r.line() != "CondAct":
        raise ValueError("not a VTank meta (no CondAct table)")
    t = _rtable(r)
    rules = []
    for row in t["rows"]:
        if len(row) < 5:
            continue
        rules.append({"cond": _cond(int(row[0]["s"]), row[2]), "act": _act(int(row[1]["s"]), row[3]), "state": row[4]["s"]})
    return rules


def meta_bytes(rules):
    rows = []
    for ru in rules:
        c, a = ru["cond"], ru["act"]
        rows.append([{"t": "i", "s": str(int(c["type"]))}, {"t": "i", "s": str(int(a["type"]))}, _cval(c), _aval(a),
                     {"t": "s", "s": ru.get("state") or "Default"}])
    o = []
    _wline(o, "1")
    _wline(o, "CondAct")
    _wtable(o, {"cols": ["CType", "AType", "CData", "AData", "State"], "flags": ["n"] * 5, "rows": rows})
    return b"".join(o)


_TYPES = None


def meta_types():
    global _TYPES
    if _TYPES is None:
        with open(os.path.join(_HERE, "metatypes.json"), encoding="utf-8") as f:
            _TYPES = json.load(f)
    return _TYPES


def meta_list(cfg):
    base = meta_dir(cfg)
    out = []
    for root, dirs, files in os.walk(base):
        for f in files:
            if not f.lower().endswith((".mtmet", ".met")):
                continue
            p = os.path.join(root, f)
            out.append({"name": os.path.splitext(f)[0], "file": os.path.relpath(p, base).replace(os.sep, "/"), "mtime": _mtime(p)})
    out.sort(key=lambda x: x["name"].lower())
    return {"metas": out, "types": meta_types(), "routes": [r["name"] for r in nav_list(cfg)["routes"]]}


def meta_read(cfg, rel):
    p = _inside(meta_dir(cfg), rel)
    with open(p, "rb") as f:
        rules = meta_parse(f.read())
    return {"file": rel.replace("\\", "/"), "name": os.path.splitext(os.path.basename(p))[0], "mtime": _mtime(p), "rules": rules}


def meta_save(cfg, rel, data, mtime=None, force=False):
    base = meta_dir(cfg)
    old = _inside(base, rel) if rel else None
    if old and os.path.exists(old) and mtime and not force and abs(_mtime(old) - int(mtime)) > 2:
        return None, "The meta was changed on the PC since you opened it - open it again (or save anyway)."
    name = (data.get("name") or "").strip() or "New meta"
    ext = os.path.splitext(old)[1] if old else ".mtmet"
    folder = os.path.dirname(old) if old else base
    path = os.path.join(folder, _safe(name) + ext)
    if path != old and os.path.exists(path):
        return None, "There's already a meta file " + os.path.basename(path) + "."
    b = meta_bytes(data.get("rules") or [])
    meta_parse(b)   # reads back: never write something the game can't read
    os.makedirs(folder, exist_ok=True)
    _backup(path)
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(b)
    os.replace(tmp, path)
    if old and path != old and os.path.exists(old):
        _trash(cfg, old)
    newrel = os.path.relpath(path, base).replace(os.sep, "/")
    sent = _push(cfg, "metafile", os.path.splitext(os.path.basename(path))[0])
    return {"meta": meta_read(cfg, newrel), "sent": sent}, None


def meta_new(cfg, name, copy_of=None):
    name = (name or "").strip() or "New meta"
    if os.path.exists(os.path.join(meta_dir(cfg), _safe(name) + ".mtmet")):
        return None, "There's already a meta called " + name + "."
    if copy_of:
        data = meta_read(cfg, copy_of)
    else:
        data = {"rules": [{"state": "Default", "cond": {"type": 0, "data": {"t": "i", "s": "0"}},
                           "act": {"type": 0, "data": {"t": "i", "s": "0"}}}]}
    data["name"] = name
    return meta_save(cfg, None, data)


def meta_delete(cfg, rel):
    _trash(cfg, _inside(meta_dir(cfg), rel))
    return {"ok": True}
