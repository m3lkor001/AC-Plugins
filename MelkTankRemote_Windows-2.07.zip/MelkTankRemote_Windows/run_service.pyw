"""
Keeps the MelkTank phone service running on Windows (the Startup-folder shortcut runs this with pythonw).
The service stops itself when its files are updated (exit code 3): it's started again at once with the new
files. If it stops for any other reason it's started again after 10 seconds. Only one copy runs.
"""
import ctypes
import os
import subprocess
import sys
import time

here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, here)

# one copy only
ctypes.windll.kernel32.CreateMutexW(None, False, "Local\\MelkTankPhoneService")
if ctypes.windll.kernel32.GetLastError() == 183:   # ERROR_ALREADY_EXISTS
    sys.exit(0)

import mtcore  # noqa: E402  (for the log folder)

os.makedirs(mtcore.LOG_DIR, exist_ok=True)
out_path = os.path.join(mtcore.LOG_DIR, "service-output.log")
while True:
    started = time.time()
    with open(out_path, "a", encoding="utf-8") as out:
        p = subprocess.Popen([sys.executable, os.path.join(here, "service.py")], cwd=here, stdout=out,
                             stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, creationflags=0x08000000)
        code = p.wait()
    if code == 3:
        time.sleep(1)
        continue
    mtcore.log("phone service stopped (exit %s) - starting it again in 10 s" % code)
    time.sleep(10)
