# MelkTank Remote (Linux)

A Linux launcher for Asheron's Call (in place of ThwargLauncher's window) with MelkTank auto-login, a loot
profile editor, and a phone app that shows each character's status and switches MelkTank's features from
anywhere over Tailscale. Needs the MelkTank plugin (the other zip) installed in Decal.

## What's in this folder

| File | What it does |
| --- | --- |
| `launcher.py` | The launcher window: servers, accounts, character per account, Launch / Launch ticked |
| `service.py` | Small web service the phone app talks to (runs in the background via systemd) |
| `mtcore.py`, `navmeta.py` | Shared code: config, launching through Wine, status files, commands, nav/meta files |
| `loot_editor.py`, `lootmodel.py`, `loot_spec.json` | Loot profile editor (outside the game) |
| `metatypes.json` | Meta rule / action names for the phone's meta editor |
| `mtlaunch.exe` | Small Windows helper that starts `acclient.exe` with Decal (setup copies it into the Wine prefix) |
| `MelkTankRemote.apk` | The Android app |
| `setup.sh` | One-time setup |

Settings and passwords are kept in `~/.config/melktank/config.json` (only your user can read it).
Logs: `~/.cache/melktank/launcher.log`.

## Setup on the PC

1. Unzip this folder somewhere in your home folder, e.g. `~/MelkTankRemote`.
2. `cd ~/MelkTankRemote && bash setup.sh`
   (installs PySide6 into a private `.venv`, copies the helper into the Wine prefix, adds menu entries
   for **MelkTank Launcher** and **MelkTank Loot Editor**, and starts the phone service).
   It prints the **app key** and the PC's Tailscale address at the end.
3. Start **MelkTank Launcher** from the menu. Open **Settings...** first and check:
   - Wine: the Wine binary and the Wine prefix your game is installed in (the defaults are a Lutris
     install at `~/Games/ac`)
   - the paths to `acclient.exe` and ThwargLauncher's `injector.dll` inside the prefix
4. **Add** each account: account name, password, server, then the character (the list fills in after the
   account has reached the character screen once).
5. Close any other clients, then **Launch ticked**.

Characters are picked on the character screen by ThwargFilter (Settings → Character picked by) if
ThwargLauncher's Decal filter is installed and enabled; MelkTank's own auto-login is the other choice.

## Tailscale (so the phone can reach the PC)

On the PC (Arch/Manjaro shown):
```
sudo pacman -S tailscale
sudo systemctl enable --now tailscaled
sudo tailscale up
tailscale ip -4        # the address for the phone app
```
On the phone: install Tailscale from the Play Store and sign in with the same account.

## The phone app

Install `MelkTankRemote.apk` (allow installs from your browser/files app when Android asks). Open it → Settings:
- PC address: the `tailscale ip -4` address
- Port: 8765
- App key: printed by `setup.sh` (also in the launcher's Settings)

Tap **Let alerts run in the background** and set the app to *Unrestricted* in the phone's battery settings,
or the phone may stop the alerts.

## Useful commands

```
systemctl --user status melktank-service      # is the phone service running?
systemctl --user restart melktank-service     # after changing the port
journalctl --user -u melktank-service -n 50   # its errors
```
