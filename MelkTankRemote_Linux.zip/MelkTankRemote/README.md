# MelkTank Remote

A Linux launcher for Asheron's Call (replaces ThwargLauncher's window), MelkTank auto-login, and a phone app that
shows each character's status and lets you switch MelkTank's features from anywhere over Tailscale.

## What's in this folder

| File | What it does |
| --- | --- |
| `launcher.py` | The launcher window: servers (✓/✗), accounts, character per account, Launch / Launch ticked |
| `service.py` | Small web service the phone app talks to (runs in the background via systemd) |
| `mtcore.py` | Shared code: config, launching through Wine, status files, commands |
| `mtlaunch.exe.b64` | The Windows helper that starts `acclient.exe` with Decal (decoded by `setup.sh`) |
| `mtlaunch.c` | Source of that helper |
| `setup.sh` | One-time setup |

Settings and passwords: `~/.config/melktank/config.json` (only your user can read it).
Logs: `~/.cache/melktank/launcher.log`.

## Setup on the PC

1. Build MelkTank as usual (it has a new `Remote.cs`):
   `cd "/home/m3lkor/Games/ac/drive_c/Games/Decal Plugins/MelksTank" && msbuild /p:Configuration=Release`
   then swap the DLL in your usual way.
2. `cd ~/MelkTankRemote && bash setup.sh`
   It prints the **app key** and the PC's Tailscale address at the end.
3. Start **MelkTank Launcher** from the menu. In **Edit** for each account: type the password, pick the
   character (the list fills in after the account reaches the character screen once), OK.
4. Close Lutris/ThwargLauncher clients first, then **Launch ticked**.

Characters are logged in by ThwargFilter (Settings → Character picked by), the Decal network filter
ThwargLauncher installed - it loads before the character screen, so it must stay enabled in Decal. MelkTank's own
auto-login is the other choice there.

## Tailscale (so the phone can reach the PC)

On the PC:
```
sudo pacman -S tailscale
sudo systemctl enable --now tailscaled
sudo tailscale up
tailscale ip -4        # the address for the phone app
```
On the phone: install Tailscale from the Play Store and sign in with the same account.

## The phone app

Install `MelkTankRemote.apk` (allow installs from your browser/files app when Android asks). Open it → Settings:
- PC address: the `tailscale ip -4` address
- Port: 8765
- App key: from `setup.sh` (also in the launcher's Settings)
- MelkTank update interval: 15-600 seconds (default 45)
- Alerts: offline, died, idle (default 5 minutes without an attack while combat is on)

Tap **Let alerts run in the background**, and set the app to *Unrestricted* in the phone's battery settings, or
Samsung may stop the alerts.

## Files MelkTank and the launcher share

All in `C:\Games\MelkTankRemote` (`~/Games/ac/drive_c/Games/MelkTankRemote`), one set per account:

- `launch_<account>.txt` - written by the launcher: character to log in
- `status_<account>.json` - written by MelkTank every interval: in-game time, last attack, lum, coins, on/off states
- `cmd_<account>_<time>.txt` - one per phone command; MelkTank applies and deletes it
- `remote_settings.txt` - the update interval

## Useful commands

```
systemctl --user status melktank-service      # is the phone service running?
systemctl --user restart melktank-service     # after changing the port
journalctl --user -u melktank-service -n 50   # its errors
```
