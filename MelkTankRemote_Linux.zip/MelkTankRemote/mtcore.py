"""
mtcore - shared code for the MelkTank Linux launcher and the phone service.

Everything MelkTank and the launcher say to each other goes through small files in the Wine prefix's
C:\\Games\\MelkTankRemote folder, one set per account (see MelkTank's Remote.cs):

    launch_<account>.txt     written here before a launch: which character MelkTank should log in
    status_<account>.json    written by MelkTank: logged-in time, last attack, lum, coins, what's on/off
    cmd_<account>_<n>.txt    written here (from the phone): one command per file, MelkTank applies and deletes it
    remote_settings.txt      written here: how often MelkTank writes the status file

Nothing in here kills or restarts a game client on its own.
"""

import json
import os
import re
import secrets
import shutil
import socket
import subprocess
import threading
import time
from datetime import datetime, timezone

HOME = os.path.expanduser("~")
CONFIG_DIR = os.path.join(os.environ.get("XDG_CONFIG_HOME", os.path.join(HOME, ".config")), "melktank")
CONFIG_PATH = os.path.join(CONFIG_DIR, "config.json")
LOG_DIR = os.path.join(os.environ.get("XDG_CACHE_HOME", os.path.join(HOME, ".cache")), "melktank")
LOG_PATH = os.path.join(LOG_DIR, "launcher.log")

FEATURES = ["master", "combat", "nav", "loot", "summon", "buff", "debug", "meta"]

DEFAULT_CONFIG = {
    "wine": {
        # "direct": run the wine binary below straight on this PC (the same Wine build Lutris uses for the prefix)
        # "system": the PC's own `wine` from PATH
        "mode": "direct",
        "wine_path": os.path.join(HOME, ".var/app/net.lutris.Lutris/data/lutris/runners/wine/wine-ge-8-26-x86_64/bin/wine"),
        "prefix": os.path.join(HOME, "Games/ac"),
        "esync": True,
        "fsync": True,
        "extra_env": {},
    },
    "client": "C:\\Turbine\\Asheron's Call\\acclient.exe",
    "injector": "C:\\Program Files\\Thwargle Games\\ThwargLauncher\\injector.dll",
    "use_decal": True,
    # Decal's own program (the agent, its tray icon): the phone service starts it and starts it again if it closes.
    # exe "" = find DenAgent.exe in the prefix's Decal folder.
    "decal_agent": {"enabled": True, "exe": ""},
    # after a client gets into the world: its window to the top-left corner, then 5 s later the focus off the games
    "focus_after_login": True,
    # who clicks the character on the character screen: "melktank" (MelkTank's Remote) or "thwargfilter"
    # (ThwargFilter, if it's still enabled in Decal - it loads earlier than plugins do)
    "character_picker": "thwargfilter",
    "launch_delay": 20,
    # restart a client that crashed (the phone service watches; off until you tick it in Settings)
    "auto_restart": False,
    # a client that's still open but hasn't written its status for this long (frozen, or lost its connection):
    # close it (forced), wait, start it again. Also a login stuck at the character screen: 1 more minute, then
    # closed, wait, started again. Off until you tick it in Settings.
    "restart_frozen": False,
    "frozen_minutes": 3,
    "frozen_wait_seconds": 60,
    # the server shuts down (a patch, a restart) and logs everyone off: a normal logout this many minutes before it
    # went down counts as its shutdown, and the account is started again this many seconds after it's back
    "server_back_restart": True,
    "server_back_window_minutes": 15,
    "server_back_wait_seconds": 90,
    "servers": [
        {"name": "InfiniteLeaftide", "host": "infiniteleaftide.online", "port": 9000, "rodat": False, "slots": 11},
    ],
    "accounts": [
        {"account": "m3lkor00001", "password": "", "server": "InfiniteLeaftide", "character": "", "enabled": True, "auto_restart": True},
        {"account": "m3lkor000001", "password": "", "server": "InfiniteLeaftide", "character": "", "enabled": True, "auto_restart": True},
    ],
    "service": {"bind": "0.0.0.0", "port": 8765, "token": ""},
}


# ── Config ──────────────────────────────────────────────────────────

_cfg_lock = threading.RLock()


def _merge(default, loaded):
    out = dict(default)
    for k, v in (loaded or {}).items():
        if isinstance(v, dict) and isinstance(default.get(k), dict):
            out[k] = _merge(default[k], v)
        else:
            out[k] = v
    return out


def load_config():
    with _cfg_lock:
        cfg = json.loads(json.dumps(DEFAULT_CONFIG))
        if os.path.exists(CONFIG_PATH):
            try:
                with open(CONFIG_PATH, encoding="utf-8") as f:
                    cfg = _merge(cfg, json.load(f))
            except Exception as ex:  # a broken file: keep the defaults, say so in the log
                log("config unreadable, using defaults: %s" % ex)
        if not cfg["service"].get("token"):
            cfg["service"]["token"] = secrets.token_urlsafe(18)
            save_config(cfg)
        return cfg


def save_config(cfg):
    with _cfg_lock:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        tmp = CONFIG_PATH + ".tmp"
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)   # it holds passwords: only you can read it
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
        os.replace(tmp, CONFIG_PATH)


def log(msg):
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(datetime.now().strftime("%Y-%m-%d %H:%M:%S  ") + msg + "\n")
    except Exception:
        pass


# ── Client history: launches, time in the game, freezes, disconnects, crashes, restarts ──
# One JSON line per event in client_events.jsonl: {"t": epoch, "account", "kind", "text", "char", "ran": seconds}.
# "ran" = how long the character had been in the game when it ended (closed, crashed, froze ...).

EVENTS_PATH = os.path.join(LOG_DIR, "client_events.jsonl")
EVENT_KINDS = {
    "launch": "Launched", "launch_failed": "Launch failed", "in_game": "In game", "unresponsive": "Not responding",
    "disconnected": "Disconnected", "closed": "Logged out", "closed_phone": "Closed from the phone",
    "killed": "Closed (frozen)", "crashed": "Crashed", "restart": "Restarting", "stuck": "Stuck at login",
    "gave_up": "Gave up restarting", "reset": "Game reset", "server_down": "Server down", "server_up": "Server back up",
}
ENDS_RUN = {"closed", "closed_phone", "killed", "crashed", "reset", "disconnected", "unresponsive"}
_ev_lock = threading.Lock()


def read_events(account=None, limit=None, since=None):
    """Events oldest first (all accounts, or one); since = epoch."""
    out = []
    try:
        with open(EVENTS_PATH, encoding="utf-8") as f:
            for line in f:
                try:
                    e = json.loads(line)
                except ValueError:
                    continue
                if account and (e.get("account") or "").lower() != account.lower():
                    continue
                if since and e.get("t", 0) < since:
                    continue
                out.append(e)
    except OSError:
        pass
    return out[-limit:] if limit else out


def _open_run(account):
    """The in_game event of the run that's still going (no end after it), or None."""
    for e in reversed(read_events(account)):
        if e.get("kind") == "in_game":
            return e
        if e.get("kind") in ENDS_RUN or e.get("kind") in ("launch", "stuck"):
            return None
    return None


def last_event(account):
    ev = read_events(account, limit=1)
    return ev[-1] if ev else None


def event(account, kind, text="", t=None, **extra):
    """Records one client event (and how long it had been in the game, for the ones that end a run)."""
    try:
        with _ev_lock:
            rec = {"t": int(t or time.time()), "account": account, "kind": kind, "text": text or EVENT_KINDS.get(kind, kind)}
            if kind in ENDS_RUN or kind == "restart":
                run = _open_run(account)
                if run:
                    rec["ran"] = max(0, rec["t"] - int(run["t"]))
                    if run.get("char") and "char" not in extra:
                        rec["char"] = run["char"]
            rec.update({k: v for k, v in extra.items() if v not in (None, "")})
            os.makedirs(LOG_DIR, exist_ok=True)
            with open(EVENTS_PATH, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec) + "\n")
            # keep it from growing forever: past 2 MB, keep the newest half
            if os.path.getsize(EVENTS_PATH) > 2 * 1024 * 1024:
                with open(EVENTS_PATH, encoding="utf-8") as f:
                    lines = f.readlines()
                tmp = EVENTS_PATH + ".tmp"
                with open(tmp, "w", encoding="utf-8") as f:
                    f.writelines(lines[len(lines) // 2:])
                os.replace(tmp, EVENTS_PATH)
    except Exception as ex:
        log("event %s %s not recorded: %s" % (account, kind, ex))


def note_in_game(cfg, account, st):
    """Called while a character is in the game: records the start of the run once (at its login time)."""
    run = _open_run(account)
    if run:
        return
    t = None
    lt = parse_iso((st or {}).get("loginTime"))
    if lt:
        t = lt.timestamp()
        if t > time.time() + 60 or t < time.time() - 7 * 86400:
            t = None
    text = "In the game as %s" % ((st or {}).get("character") or "?")
    le = last_event(account)
    if le and t and t < le.get("t", 0):
        t, text = None, "Answering again as %s" % ((st or {}).get("character") or "?")   # came back after going quiet
    event(account, "in_game", text, t=t, char=(st or {}).get("character"))


def events_summary(cfg, hours=24):
    """Per account: in the game since, and the last `hours`: time in game, runs, longest run, restarts,
    crashes, freezes, disconnects."""
    now = time.time()
    since = now - hours * 3600
    out = {}
    for a in cfg.get("accounts", []):
        name = a["account"]
        evs = read_events(name)
        s = {"account": name, "inGameSince": None, "char": None, "uptime": 0, "runs": 0, "longest": 0,
             "restarts": 0, "crashes": 0, "unresponsive": 0, "disconnects": 0, "stuck": 0, "last": None}
        start = None
        for e in evs:
            k, t = e.get("kind"), e.get("t", 0)
            if k == "in_game":
                start = e
            elif start and (k in ENDS_RUN or k in ("launch", "stuck")):
                a0, b0 = max(start["t"], since), t
                if b0 > a0:
                    s["uptime"] += b0 - a0
                if t >= since:
                    s["runs"] += 1
                    s["longest"] = max(s["longest"], t - start["t"])
                start = None
            if t >= since:
                if k == "restart": s["restarts"] += 1
                elif k == "crashed": s["crashes"] += 1
                elif k == "unresponsive": s["unresponsive"] += 1
                elif k == "disconnected": s["disconnects"] += 1
                elif k == "stuck": s["stuck"] += 1
        if start:
            s["inGameSince"] = start["t"]
            s["char"] = start.get("char")
            s["uptime"] += now - max(start["t"], since)
            s["longest"] = max(s["longest"], now - start["t"])
        if evs:
            s["last"] = evs[-1]
        s["uptime"] = int(s["uptime"])
        s["longest"] = int(s["longest"])
        out[name] = s
    return out


def find_server(cfg, name):
    for s in cfg["servers"]:
        if s["name"].lower() == (name or "").lower():
            return s
    return cfg["servers"][0] if cfg["servers"] else None


def find_account(cfg, account):
    for a in cfg["accounts"]:
        if a["account"].lower() == (account or "").lower():
            return a
    return None


# ── Paths ───────────────────────────────────────────────────────────

def drive_c(cfg):
    return os.path.join(cfg["wine"]["prefix"], "drive_c")


def remote_dir(cfg):
    d = os.path.join(drive_c(cfg), "Games", "MelkTankRemote")
    os.makedirs(d, exist_ok=True)
    return d


def win_to_unix(cfg, path):
    """C:\\Turbine\\x.exe -> <prefix>/drive_c/Turbine/x.exe"""
    p = path.replace("\\", "/")
    if re.match(r"^[A-Za-z]:/", p):
        p = p[3:]
    return os.path.join(drive_c(cfg), p)


# ── loot profiles (the out-of-game loot editors) ─────────────────────

def plugin_dir(cfg):
    return os.path.join(drive_c(cfg), "Games", "Decal Plugins", "MelksTank")


def plugin_file(cfg, name, char_part=None):
    """A MelkTank file: Settings\\<name> (or Settings\\<character>\\<name>) since the folders were tidied (b57),
    else the plugin folder itself (older builds)."""
    d = plugin_dir(cfg)
    sub = os.path.join("Settings", char_part.replace("_", " ").strip(), name) if char_part else os.path.join("Settings", name)
    new = os.path.join(d, sub)
    return new if os.path.exists(new) or not os.path.exists(os.path.join(d, name)) else os.path.join(d, name)


CORE_DLL, CORE_OLD, CORE_SWAP = "MelkTankCore.dll", "MelkTankCore.old.dll", "MelkTankCore.swap.dll"


def _build_info(path):
    if not os.path.exists(path):
        return None
    st = os.stat(path)
    return {"time": time.strftime("%b %d %H:%M:%S", time.localtime(st.st_mtime)).replace(" 0", " "), "mtime": st.st_mtime, "bytes": st.st_size}


def core_builds(cfg):
    """MelkTank's running build (MelkTankCore.dll, loaded by the MelkTank.dll loader) and the previous one."""
    d = plugin_dir(cfg)
    return {"current": _build_info(os.path.join(d, CORE_DLL)), "previous": _build_info(os.path.join(d, CORE_OLD))}


def rollback_core(cfg):
    """Swaps MelkTankCore.dll with MelkTankCore.old.dll: the previous build becomes the running one (and the one that
    was running becomes 'previous', so doing it again undoes it). Every client's loader sees the change and reloads
    within a few seconds - no relog."""
    d = plugin_dir(cfg)
    cur, old, tmp = (os.path.join(d, n) for n in (CORE_DLL, CORE_OLD, CORE_SWAP))
    if not os.path.exists(old):
        return False, "There's no previous build (MelkTankCore.old.dll) to go back to."
    if not os.path.exists(cur):
        os.replace(old, cur)
        return True, "Put the previous build in place (there was no current one). The game loads it in a few seconds."
    was, back = _build_info(cur), _build_info(old)
    os.replace(cur, tmp)
    try:
        os.replace(old, cur)
    except Exception:
        os.replace(tmp, cur)
        raise
    os.replace(tmp, old)
    log("rollback: MelkTankCore %s -> %s" % (was["time"], back["time"]))
    return True, "Rolled back to the build of %s (from %s). The game reloads it in a few seconds; tap again to undo." % (back["time"], was["time"])


def loot_dir(cfg):
    """Where MelkTank reads its .utl loot profiles: Settings > Loot's folder, else Profiles/Loot (b57 on),
    else VTank's (older builds), else the plugin folder."""
    try:
        with open(plugin_file(cfg, "MelkTank_Settings.xml"), encoding="utf-8-sig") as f:
            for m in re.finditer(r"<LootProfileDir>([^<]+)</LootProfileDir>", f.read()):
                d = win_to_unix(cfg, m.group(1).strip())
                if os.path.isdir(d):
                    return d
    except OSError:
        pass
    pl = os.path.join(plugin_dir(cfg), "Profiles", "Loot")
    if os.path.isdir(pl):
        return pl
    for d in (r"C:\Games\VirindiPlugins\VirindiTank", r"C:\Program Files\VirindiPlugins\VirindiTank",
              r"C:\Program Files (x86)\VirindiPlugins\VirindiTank"):
        u = win_to_unix(cfg, d)
        if os.path.isdir(u):
            return u
    return plugin_dir(cfg)


def _loot_path(cfg, name):
    name = os.path.basename(name or "")
    if not name.lower().endswith(".utl"):
        raise ValueError("not a .utl profile")
    return os.path.join(loot_dir(cfg), name)


def loot_list(cfg):
    d = loot_dir(cfg)
    out = []
    try:
        for n in sorted(os.listdir(d), key=str.lower):
            if n.lower().endswith(".utl"):
                st = os.stat(os.path.join(d, n))
                out.append({"name": n, "mtime": int(st.st_mtime * 1000), "size": st.st_size})
    except OSError:
        pass
    return {"dir": d, "profiles": out}


def loot_load(cfg, name):
    import lootmodel
    path = _loot_path(cfg, name)
    return lootmodel.Profile.load(path), int(os.stat(path).st_mtime * 1000)


_loot_backed_up = set()


def loot_save(cfg, name, profile, expected_mtime=None, force=False):
    """Writes a profile. Refuses (returns False, current mtime) when the file changed since it was opened
    (expected_mtime), unless force. The first save of a file per service run keeps a .bak copy."""
    path = _loot_path(cfg, name)
    cur = int(os.stat(path).st_mtime * 1000) if os.path.exists(path) else None
    if not force and expected_mtime is not None and cur is not None and abs(cur - int(expected_mtime)) > 1:
        return False, cur
    if cur is not None and path not in _loot_backed_up:
        try:
            shutil.copy2(path, path + ".bak")
        except OSError:
            pass
        _loot_backed_up.add(path)
    profile.save(path)
    log("loot profile saved: %s" % os.path.basename(path))
    return True, int(os.stat(path).st_mtime * 1000)


def loot_push(cfg, name):
    """Tells every running MelkTank to read this profile again (a hunting character uses the changes straight away)."""
    sent = []
    for a in cfg.get("accounts", []):
        if client_pids(a["account"]):
            send_command(cfg, a["account"], "reloadloot", name=os.path.basename(name))
            sent.append(a["account"])
    return sent


def account_key(account):
    """Same as Remote.Key in MelkTank: lower case, letters/digits/-/_ only."""
    s = "".join(c if (c.isalnum() or c in "-_") else "_" for c in (account or "").strip().lower())
    return s or "unknown"


def _atomic_write(path, text):
    tmp = path + ".tmp-%d" % os.getpid()
    with open(tmp, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(text)
    os.replace(tmp, path)


def utc_now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def parse_iso(s):
    if not s:
        return None
    try:
        s = s.strip().replace("Z", "+00:00")
        s = re.sub(r"(\.\d{6})\d+", r"\1", s)   # .NET writes 7 decimal places
        d = datetime.fromisoformat(s)
        if d.tzinfo is None:
            d = d.replace(tzinfo=timezone.utc)
        return d
    except Exception:
        return None


# ── Server status (same UDP login packet ThwargLauncher sends) ──────

_LOGIN_PACKET = bytes([
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x93, 0x00, 0xd0, 0x05, 0x00, 0x00, 0x00, 0x00, 0x40, 0x00, 0x00, 0x00,
    0x04, 0x00, 0x31, 0x38, 0x30, 0x32, 0x00, 0x00, 0x34, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x3e, 0xb8, 0xa8, 0x58, 0x1c, 0x00, 0x61, 0x63, 0x73, 0x65, 0x72, 0x76, 0x65, 0x72, 0x74, 0x72, 0x61, 0x63, 0x6b, 0x65,
    0x72, 0x3a, 0x6a, 0x6a, 0x39, 0x68, 0x32, 0x36, 0x68, 0x63, 0x73, 0x67, 0x67, 0x63, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00])


def server_check_path():
    return os.path.join(LOG_DIR, "server_check_now")


def ask_server_check():
    """Asks the phone service to check the servers right now (the launcher's Check now button)."""
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(server_check_path(), "w") as f:
            f.write(str(time.time()))
    except Exception:
        pass


def server_up(host, port, timeout=3.0):
    """True when the server answers a login packet (any reply counts), False when it doesn't, None if the name won't resolve."""
    try:
        ip = socket.gethostbyname(host)
    except OSError:
        return None
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.settimeout(timeout)
        s.sendto(_LOGIN_PACKET, (ip, int(port)))
        s.recvfrom(2048)
        return True
    except OSError:
        return False
    finally:
        s.close()


# ── Status files from MelkTank ──────────────────────────────────────

def read_status(cfg, account):
    path = os.path.join(remote_dir(cfg), "status_%s.json" % account_key(account))
    try:
        with open(path, encoding="utf-8-sig") as f:
            st = json.load(f)
    except Exception:
        return None
    st["_file_age"] = time.time() - os.path.getmtime(path)
    return st


def _char_file_part(name):
    return "".join(ch if ch.isalnum() else "_" for ch in (name or ""))


def read_settings(cfg, account):
    """The character's MelkTank settings for the phone's settings page: the single-value settings (from its
    MelkTank_Live_[character].xml mirror), the Tuning values (labels and ranges from MelkTank_TuningInfo.json) and its
    settings snapshots. None when the character isn't known yet."""
    import xml.etree.ElementTree as ET
    st = read_status(cfg, account) or {}
    char = st.get("character") or ""
    if not char:
        return None
    d = plugin_dir(cfg)
    part = _char_file_part(char)
    path = plugin_file(cfg, "MelkTank_Live_%s.xml" % part, part)
    with open(path, encoding="utf-8-sig") as f:
        text = f.read()
    root = ET.fromstring(text[text.index("\n") + 1:])
    settings, tuned = [], {}
    for c in root:
        if len(c) == 0:
            v = c.text or ""
            kind = "bool" if v in ("True", "False") else "number" if re.fullmatch(r"-?\d+(\.\d+)?", v) else "text"
            settings.append({"name": c.tag, "value": v, "kind": kind})
        elif c.tag == "Tuning":
            for t in c:
                tuned[t.get("k")] = t.get("v")
    tuning = []
    try:
        with open(plugin_file(cfg, "MelkTank_TuningInfo.json"), encoding="utf-8-sig") as f:
            for t in json.load(f):
                t["value"] = float(tuned[t["key"]]) if t["key"] in tuned else t["default"]
                tuning.append(t)
    except Exception:
        pass
    snaps = []
    sd = os.path.join(d, "Settings", "Snapshots")
    if not os.path.isdir(sd):
        sd = os.path.join(d, "Snapshots")
    if os.path.isdir(sd):
        pre = part + "_"
        for fn in sorted(os.listdir(sd), key=str.lower):
            if fn.startswith(pre) and fn.endswith(".xml"):
                mt = os.path.getmtime(os.path.join(sd, fn))
                snaps.append({"name": fn[len(pre):-4], "time": time.strftime("%b %d %H:%M", time.localtime(mt)).replace(" 0", " "), "mtime": mt})
    return {"character": char, "settings": settings, "tuning": tuning, "snapshots": snaps,
            "mirrorAge": time.time() - os.path.getmtime(path)}


def read_session(cfg, account):
    """MelkTank's session_<account>.json (this session's numbers, kills and looted items), or None."""
    path = os.path.join(remote_dir(cfg), "session_%s.json" % account_key(account))
    try:
        with open(path, encoding="utf-8-sig") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def client_state(st):
    """'offline', 'charselect' or 'online' from a status dict (None = no file)."""
    if not st or not st.get("running", False):
        return "offline"
    interval = max(15, int(st.get("interval") or 45))
    upd = parse_iso(st.get("updated"))
    age = (datetime.now(timezone.utc) - upd).total_seconds() if upd else st.get("_file_age", 1e9)
    if age > max(interval * 2.5, interval + 60):
        return "offline"   # MelkTank stopped writing: the client closed or froze
    return "online" if st.get("loggedIn") else "charselect"


def known_characters(cfg, account):
    """The characters MelkTank last saw on this account's character screen."""
    st = read_status(cfg, account)
    return list(st.get("characters") or []) if st else []


_ACCT_RE = re.compile(r"(?:^|\s)-a\s+(\S+)", re.IGNORECASE)
_last_dup_note = [None]


def _ppid(pid):
    try:
        with open("/proc/%d/stat" % pid, "rb") as f:
            stat = f.read().decode("utf-8", "replace")
        return int(stat.rsplit(")", 1)[1].split()[1])
    except Exception:
        return 0


def running_clients():
    """How many game clients are running on this PC. Wine can show one game as more than one process with the
    same command line (the starter and the game itself), so clients are counted once per account; a process
    without an account on its command line counts unless its parent is already a counted client."""
    try:
        procs = _client_procs()
    except Exception:
        return 0
    pids = {pid for pid, _ in procs}
    accounts, loose = set(), 0
    for pid, cmd in procs:
        m = _ACCT_RE.search(cmd)
        if m:
            accounts.add(m.group(1).lower())
        elif _ppid(pid) not in pids:
            loose += 1
    count = len(accounts) + loose
    if len(procs) != count:
        note = "; ".join("%d<-%d %s" % (pid, _ppid(pid), re.sub(r"(-v\s+)\S+", r"\1******", cmd).strip())
                         for pid, cmd in procs)
        if note != _last_dup_note[0]:
            _last_dup_note[0] = note
            log("client count: %d processes -> %d clients: %s" % (len(procs), count, note))
    return count


def _client_procs():
    """(pid, command line) of every running acclient.exe. Wine shows a game's Windows command line
    ("C:\\...\\acclient.exe -a <account> -v ...") as the process's command line."""
    procs = []
    for d in os.listdir("/proc"):
        if not d.isdigit():
            continue
        try:
            with open("/proc/%s/cmdline" % d, "rb") as f:
                raw = f.read()
        except OSError:
            continue
        exe = raw.split(b"\0", 1)[0].decode("utf-8", "replace").strip().strip('"').lower()
        # the program itself must be acclient.exe (so a shell or script that merely mentions it never matches)
        if exe.endswith("acclient.exe") or exe.split(" -")[0].strip().strip('"').endswith("acclient.exe"):
            procs.append((int(d), raw.replace(b"\0", b" ").decode("utf-8", "replace")))
    return procs


def _keep_old_launch_log(path, keep=10):
    """Keeps the last launch's Wine output (the game's crash messages end up there) as
    launch-<account>.<date-time>.log instead of overwriting it; only the newest `keep` per account are kept."""
    import glob
    try:
        if not os.path.exists(path) or os.path.getsize(path) == 0:
            return
        stamp = datetime.fromtimestamp(os.path.getmtime(path)).strftime("%Y%m%d-%H%M%S")
        base = path[:-len(".log")]
        os.replace(path, "%s.%s.log" % (base, stamp))
        old = sorted(glob.glob(glob.escape(base) + ".2*.log"))
        for f in old[:-keep]:
            os.remove(f)
    except OSError as ex:
        log("couldn't keep the old launch log %s: %s" % (path, ex))


def client_memory():
    """{account: (resident bytes, virtual bytes)} for each running client (the biggest of its processes)."""
    out = {}
    for pid, cmd in _client_procs():
        m = _ACCT_RE.search(cmd)
        if not m:
            continue
        rss = vsz = 0
        try:
            with open("/proc/%d/status" % pid) as f:
                for line in f:
                    if line.startswith("VmRSS:"):
                        rss = int(line.split()[1]) * 1024
                    elif line.startswith("VmSize:"):
                        vsz = int(line.split()[1]) * 1024
        except (OSError, ValueError):
            continue
        acct = m.group(1)
        if rss > out.get(acct, (0, 0))[0]:
            out[acct] = (rss, vsz)
    return out


def client_pids(account):
    """Process ids of the acclient.exe running for this account."""
    pat = re.compile(r"(^|\s)-a\s+%s(\s|$)" % re.escape(account), re.IGNORECASE)
    return [pid for pid, cmd in _client_procs() if pat.search(cmd)]


def kill_client(cfg, account, wait=5.0, kind="closed_phone", why=""):
    """Closes this account's game client (asks first, forces it after a few seconds). Returns (ok, message)."""
    import signal
    pids = client_pids(account)
    if not pids:
        return False, "No running client found for %s." % account
    for pid in pids:
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError:
            pass
    deadline = time.time() + wait
    while time.time() < deadline and any(os.path.exists("/proc/%d" % p) for p in pids):
        time.sleep(0.25)
    forced = False
    for pid in pids:
        if os.path.exists("/proc/%d" % pid):
            forced = True
            try:
                os.kill(pid, signal.SIGKILL)
            except OSError:
                pass
    # mark it closed so nothing mistakes it for a crash (and the phone shows it offline right away)
    path = os.path.join(remote_dir(cfg), "status_%s.json" % account_key(account))
    try:
        with open(path, encoding="utf-8-sig") as f:
            st = json.load(f)
        st.update(running=False, loggedIn=False, loginNote="Closed from the phone", updated=utc_now_iso())
        tmp = path + ".tmp-%d" % os.getpid()
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(st, f, indent=2)
        os.replace(tmp, path)
    except Exception:
        pass
    log("closed client for %s (pid %s%s)" % (account, ",".join(map(str, pids)), ", forced" if forced else ""))
    if kind:
        event(account, kind, (why or EVENT_KINDS.get(kind, kind)) + (" (had to be forced)" if forced else ""))
    return True, "Closed %s's client%s." % (account, " (it had to be forced)" if forced else "")


def _mark_closed(cfg, account, note):
    path = os.path.join(remote_dir(cfg), "status_%s.json" % account_key(account))
    try:
        with open(path, encoding="utf-8-sig") as f:
            st = json.load(f)
        st.update(running=False, loggedIn=False, loginNote=note, updated=utc_now_iso())
        tmp = path + ".tmp-%d" % os.getpid()
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(st, f, indent=2)
        os.replace(tmp, path)
    except Exception:
        pass


# ── Window focus (X11: XFCE etc.) ───────────────────────────────────

def _x11():
    import ctypes
    x = ctypes.cdll.LoadLibrary("libX11.so.6")
    x.XOpenDisplay.restype = ctypes.c_void_p
    x.XOpenDisplay.argtypes = [ctypes.c_char_p]
    x.XDefaultRootWindow.restype = ctypes.c_ulong
    x.XDefaultRootWindow.argtypes = [ctypes.c_void_p]
    x.XInternAtom.restype = ctypes.c_ulong
    x.XInternAtom.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]
    x.XGetWindowProperty.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_long, ctypes.c_long,
                                     ctypes.c_int, ctypes.c_ulong, ctypes.POINTER(ctypes.c_ulong),
                                     ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_ulong),
                                     ctypes.POINTER(ctypes.c_ulong), ctypes.POINTER(ctypes.c_void_p)]
    x.XFree.argtypes = [ctypes.c_void_p]
    x.XSendEvent.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.c_int, ctypes.c_long, ctypes.c_void_p]
    x.XFlush.argtypes = [ctypes.c_void_p]
    x.XCloseDisplay.argtypes = [ctypes.c_void_p]
    return x


def _xprop(x, d, w, name, req_type, as_text=False):
    """A window property: a list of numbers (format 32), or text."""
    import ctypes
    atom = x.XInternAtom(d, name.encode(), 0)
    at, af, n, after, data = ctypes.c_ulong(), ctypes.c_int(), ctypes.c_ulong(), ctypes.c_ulong(), ctypes.c_void_p()
    if x.XGetWindowProperty(d, w, atom, 0, 4096, 0, req_type, ctypes.byref(at), ctypes.byref(af), ctypes.byref(n),
                            ctypes.byref(after), ctypes.byref(data)) != 0 or not data.value:
        return "" if as_text else []
    try:
        if as_text:
            return ctypes.string_at(data.value, n.value).decode("utf-8", "replace")
        if af.value != 32:
            return []
        arr = ctypes.cast(data.value, ctypes.POINTER(ctypes.c_ulong))
        return [arr[i] for i in range(n.value)]
    finally:
        x.XFree(data)


def _game_window(account, act):
    """Finds this account's game window and calls act(x, display, root, window, send) -> message.
    send(window, "_NET_...", [up to 5 numbers]) sends a window-manager request. Returns (ok, message)."""
    import ctypes
    pids = set(client_pids(account))
    if not pids:
        return False, "No running client for %s." % account
    try:
        x = _x11()
    except OSError as ex:
        return False, "Can't use X11 here: %s" % ex
    d = x.XOpenDisplay(None)
    if not d:
        return False, "Can't open the display (DISPLAY=%s)." % os.environ.get("DISPLAY", "")
    try:
        root = x.XDefaultRootWindow(d)
        XA_WINDOW, XA_CARDINAL = 33, 6
        utf8 = x.XInternAtom(d, b"UTF8_STRING", 0)
        best, best_score = 0, -1
        for w in _xprop(x, d, root, "_NET_CLIENT_LIST", XA_WINDOW):
            pid = (_xprop(x, d, w, "_NET_WM_PID", XA_CARDINAL) or [0])[0]
            if pid not in pids:
                continue
            title = _xprop(x, d, w, "_NET_WM_NAME", utf8, True)
            score = 2 if "asheron" in title.lower() else 1
            if score > best_score:
                best, best_score = w, score
        if not best:
            return False, "Couldn't find %s's game window." % account

        class ClientMessage(ctypes.Structure):
            _fields_ = [("type", ctypes.c_int), ("serial", ctypes.c_ulong), ("send_event", ctypes.c_int),
                        ("display", ctypes.c_void_p), ("window", ctypes.c_ulong), ("message_type", ctypes.c_ulong),
                        ("format", ctypes.c_int), ("data", ctypes.c_long * 5)]

        class XEvent(ctypes.Union):
            _fields_ = [("xclient", ClientMessage), ("pad", ctypes.c_long * 24)]

        def send(win, atom, data):
            ev = XEvent()
            ev.xclient.type = 33                     # ClientMessage
            ev.xclient.send_event = 1
            ev.xclient.window = win
            ev.xclient.message_type = x.XInternAtom(d, atom.encode(), 0)
            ev.xclient.format = 32
            for i, v in enumerate(data[:5]):
                ev.xclient.data[i] = v
            mask = (1 << 20) | (1 << 19)             # SubstructureRedirect | SubstructureNotify
            x.XSendEvent(d, root, 0, mask, ctypes.byref(ev))
            x.XFlush(d)

        return True, act(x, d, root, best, send)
    finally:
        x.XCloseDisplay(d)


def unfocus_games():
    """Takes the focus off the game windows (their 3D drawing pauses): gives it to the MelkTank Launcher window,
    or, if that isn't open, to the desktop. Returns (ok, message)."""
    import ctypes
    try:
        x = _x11()
    except OSError as ex:
        return False, "Can't use X11 here: %s" % ex
    d = x.XOpenDisplay(None)
    if not d:
        return False, "Can't open the display (DISPLAY=%s)." % os.environ.get("DISPLAY", "")
    try:
        root = x.XDefaultRootWindow(d)
        XA_WINDOW, XA_ATOM = 33, 4
        utf8 = x.XInternAtom(d, b"UTF8_STRING", 0)
        desktop_type = x.XInternAtom(d, b"_NET_WM_WINDOW_TYPE_DESKTOP", 0)
        launcher = desktop = 0
        for w in _xprop(x, d, root, "_NET_CLIENT_LIST", XA_WINDOW):
            title = _xprop(x, d, w, "_NET_WM_NAME", utf8, True)
            if title.strip() == "MelkTank Launcher":
                launcher = w
            elif desktop_type in _xprop(x, d, w, "_NET_WM_WINDOW_TYPE", XA_ATOM):
                desktop = desktop or w
        if not desktop:   # xfdesktop isn't always in the client list: look through the stacking list too
            for w in _xprop(x, d, root, "_NET_CLIENT_LIST_STACKING", XA_WINDOW):
                if desktop_type in _xprop(x, d, w, "_NET_WM_WINDOW_TYPE", XA_ATOM):
                    desktop = w
                    break
        target = launcher or desktop
        if not target:
            return False, "Couldn't find the launcher or the desktop to give the focus to - open the MelkTank Launcher."

        class ClientMessage(ctypes.Structure):
            _fields_ = [("type", ctypes.c_int), ("serial", ctypes.c_ulong), ("send_event", ctypes.c_int),
                        ("display", ctypes.c_void_p), ("window", ctypes.c_ulong), ("message_type", ctypes.c_ulong),
                        ("format", ctypes.c_int), ("data", ctypes.c_long * 5)]

        class XEvent(ctypes.Union):
            _fields_ = [("xclient", ClientMessage), ("pad", ctypes.c_long * 24)]

        ev = XEvent()
        ev.xclient.type = 33
        ev.xclient.send_event = 1
        ev.xclient.window = target
        ev.xclient.message_type = x.XInternAtom(d, b"_NET_ACTIVE_WINDOW", 0)
        ev.xclient.format = 32
        ev.xclient.data[0] = 2
        x.XSendEvent(d, root, 0, (1 << 20) | (1 << 19), ctypes.byref(ev))
        x.XFlush(d)
        return True, "Focus moved to the %s - the game windows stop drawing." % ("MelkTank Launcher" if launcher else "desktop")
    finally:
        x.XCloseDisplay(d)


def focus_client(account):
    """Gives this account's game window the focus (raised, un-minimised). Returns (ok, message)."""
    def act(x, d, root, w, send):
        send(w, "_NET_ACTIVE_WINDOW", [2])   # 2 = from a pager / taskbar: window managers honour it
        return "Focused %s's game window." % account
    return _game_window(account, act)


def press_game_key(account, key="b"):
    """Focuses this account's game window and presses a real key in it (X11 XTest - the game reads the keyboard
    itself, so a key posted to its window is ignored). key is an X keysym name ("b", "F12"...). Returns (ok, message)."""
    import ctypes
    try:
        xt = ctypes.cdll.LoadLibrary("libXtst.so.6")
    except OSError as ex:
        return False, "Can't press keys here (libXtst missing): %s" % ex
    try:
        wake_screen()
    except Exception:
        pass

    def act(x, d, root, w, send):
        active = (_xprop(x, d, root, "_NET_ACTIVE_WINDOW", 33) or [0])[0]
        was = active == w
        if not was:
            send(w, "_NET_ACTIVE_WINDOW", [2])
            deadline = time.time() + 3
            while time.time() < deadline:   # wait until it really has the focus
                time.sleep(0.15)
                active = (_xprop(x, d, root, "_NET_ACTIVE_WINDOW", 33) or [0])[0]
                if active == w:
                    break
            # the game only starts reading the keyboard once Wine has activated it: give it a second
            time.sleep(1.2)
        else:
            time.sleep(0.1)
        focus = "already focused" if was else ("focused" if active == w else "NOT focused (active window %#x)" % active)
        x.XStringToKeysym.restype = ctypes.c_ulong
        x.XStringToKeysym.argtypes = [ctypes.c_char_p]
        x.XKeysymToKeycode.restype = ctypes.c_ubyte
        x.XKeysymToKeycode.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
        xt.XTestFakeKeyEvent.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_int, ctypes.c_ulong]
        code = x.XKeysymToKeycode(d, x.XStringToKeysym(key.encode()))
        if not code:
            return "No key code for %s." % key
        xt.XTestFakeKeyEvent(d, code, 1, 0)
        x.XFlush(d)
        time.sleep(0.15)   # held across a few game frames
        xt.XTestFakeKeyEvent(d, code, 0, 0)
        x.XFlush(d)
        return "Pressed %s (keycode %d) in %s's game window (%s)." % (key, code, account, focus)
    return _game_window(account, act)


def click_game_screen(account, sx, sy, shot_width=2400):
    """Focuses this account's game window and left-clicks the screen at (sx, sy) given in screenshot pixels (the
    screenshot is scaled to shot_width wide). Real mouse input (XTest). Returns (ok, message)."""
    import ctypes
    try:
        xt = ctypes.cdll.LoadLibrary("libXtst.so.6")
    except OSError as ex:
        return False, "Can't click here (libXtst missing): %s" % ex

    def act(x, d, root, w, send):
        x.XDisplayWidth.restype = ctypes.c_int
        x.XDisplayWidth.argtypes = [ctypes.c_void_p, ctypes.c_int]
        width = x.XDisplayWidth(d, 0)
        k = width / float(shot_width) if width > shot_width else 1.0
        px, py = int(round(sx * k)), int(round(sy * k))
        if (_xprop(x, d, root, "_NET_ACTIVE_WINDOW", 33) or [0])[0] != w:
            send(w, "_NET_ACTIVE_WINDOW", [2])
            time.sleep(1.2)
        xt.XTestFakeMotionEvent.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_ulong]
        xt.XTestFakeButtonEvent.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_int, ctypes.c_ulong]
        xt.XTestFakeMotionEvent(d, -1, px, py, 0)
        x.XFlush(d)
        time.sleep(0.3)
        xt.XTestFakeButtonEvent(d, 1, 1, 0)
        x.XFlush(d)
        time.sleep(0.1)
        xt.XTestFakeButtonEvent(d, 1, 0, 0)
        x.XFlush(d)
        return "Clicked %d,%d (screen %d,%d) in %s's game window." % (sx, sy, px, py, account)
    return _game_window(account, act)


def move_client_window(account, left=0, top=0):
    """Moves this account's game window so its top-left corner is at (left, top) - e.g. after changing the game's
    resolution left half of it off the screen. Also focuses it. Returns (ok, message)."""
    def act(x, d, root, w, send):
        send(w, "_NET_WM_STATE", [0, x.XInternAtom(d, b"_NET_WM_STATE_MAXIMIZED_VERT", 0),
                                  x.XInternAtom(d, b"_NET_WM_STATE_MAXIMIZED_HORZ", 0), 2])   # un-maximise first
        # gravity NorthWest (1), x and y given (bits 8, 9), from a pager (2 << 12)
        send(w, "_NET_MOVERESIZE_WINDOW", [1 | (1 << 8) | (1 << 9) | (2 << 12), int(left), int(top), 0, 0])
        send(w, "_NET_ACTIVE_WINDOW", [2])
        return "Moved %s's game window to the top-left corner." % account
    return _game_window(account, act)


def _win_geometry(x, d, w):
    """(left, top, width, height) of a window on the screen (its inside, without the title bar / border)."""
    import ctypes
    x.XGetGeometry.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.POINTER(ctypes.c_ulong), ctypes.POINTER(ctypes.c_int),
                               ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_uint), ctypes.POINTER(ctypes.c_uint),
                               ctypes.POINTER(ctypes.c_uint), ctypes.POINTER(ctypes.c_uint)]
    x.XTranslateCoordinates.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_int, ctypes.c_int,
                                        ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_ulong)]
    r, gx, gy, gw, gh, bw, dp = (ctypes.c_ulong(), ctypes.c_int(), ctypes.c_int(), ctypes.c_uint(), ctypes.c_uint(),
                                 ctypes.c_uint(), ctypes.c_uint())
    x.XGetGeometry(d, w, ctypes.byref(r), ctypes.byref(gx), ctypes.byref(gy), ctypes.byref(gw), ctypes.byref(gh),
                   ctypes.byref(bw), ctypes.byref(dp))
    ax, ay, child = ctypes.c_int(), ctypes.c_int(), ctypes.c_ulong()
    x.XTranslateCoordinates(d, w, x.XDefaultRootWindow(d), 0, 0, ctypes.byref(ax), ctypes.byref(ay), ctypes.byref(child))
    return ax.value, ay.value, gw.value, gh.value


def client_window_size(account):
    """(width, height) of this account's game window, or None."""
    ok, res = _game_window(account, lambda x, d, root, w, send: _win_geometry(x, d, w)[2:])
    return res if ok else None


def move_client_corner(account, corner="top-left"):
    """Moves this account's game window into a corner of the screen's usable area (above the taskbar):
    "top-left" or "bottom-right" (its bottom-right corner in the screen's). Returns (ok, message)."""
    if corner != "bottom-right":
        return move_client_window(account)

    def act(x, d, root, w, send):
        _l, _t, cw, ch = _win_geometry(x, d, w)
        ext = _xprop(x, d, w, "_NET_FRAME_EXTENTS", 6) or [0, 0, 0, 0]          # title bar / borders: l r t b
        wa = (_xprop(x, d, root, "_NET_WORKAREA", 6) or [])[:4]
        if len(wa) < 4:
            wa = [0, 0] + list(_win_geometry(x, d, root)[2:])
        left = wa[0] + wa[2] - (cw + ext[0] + ext[1])
        top = wa[1] + wa[3] - (ch + ext[2] + ext[3])
        send(w, "_NET_WM_STATE", [0, x.XInternAtom(d, b"_NET_WM_STATE_MAXIMIZED_VERT", 0),
                                  x.XInternAtom(d, b"_NET_WM_STATE_MAXIMIZED_HORZ", 0), 2])   # un-maximise first
        send(w, "_NET_MOVERESIZE_WINDOW", [1 | (1 << 8) | (1 << 9) | (2 << 12), int(left), int(top), 0, 0])
        send(w, "_NET_ACTIVE_WINDOW", [2])
        return "Moved %s's game window (%dx%d) to the bottom-right corner (%d,%d)." % (account, cw, ch, left, top)
    return _game_window(account, act)


def wait_window_settled(account, still=3, timeout=45):
    """Waits until the game window has kept the same size for `still` seconds (a plugin resizes it during login)."""
    deadline = time.time() + timeout
    last, same = None, 0
    while time.time() < deadline:
        size = client_window_size(account)
        if size and size == last:
            same += 1
            if same >= still:
                return size
        else:
            same = 0
        last = size
        time.sleep(1)
    return last


# ── Decal's agent ───────────────────────────────────────────────────

def decal_agent_path(cfg):
    """The Unix path of Decal's agent program, or "" if it isn't there."""
    import glob
    dc = cfg.get("decal_agent") or {}
    if dc.get("exe"):
        p = win_to_unix(cfg, dc["exe"])
        return p if os.path.isfile(p) else ""
    for folder in ("Program Files/Decal 3.0", "Program Files (x86)/Decal 3.0", "Program Files/Decal"):
        for f in glob.glob(os.path.join(drive_c(cfg), glob.escape(folder), "*")):
            if os.path.basename(f).lower() == "denagent.exe":
                return f
    return ""


def decal_agent_pids():
    pids = []
    for d in os.listdir("/proc"):
        if not d.isdigit():
            continue
        try:
            with open("/proc/%s/cmdline" % d, "rb") as f:
                raw = f.read().replace(b"\0", b" ").decode("utf-8", "replace").lower()
        except OSError:
            continue
        if "denagent.exe" in raw and "acclient" not in raw:
            pids.append(int(d))
    return pids


def start_decal_agent(cfg):
    """Starts Decal's agent in the game's prefix. Returns (ok, message)."""
    path = decal_agent_path(cfg)
    if not path:
        return False, "Decal's agent (DenAgent.exe) wasn't found in the Decal folder."
    win = "C:\\" + os.path.relpath(path, drive_c(cfg)).replace("/", "\\")
    os.makedirs(LOG_DIR, exist_ok=True)
    try:
        with open(os.path.join(LOG_DIR, "decal-agent.log"), "w") as out:
            subprocess.Popen(wine_command(cfg) + [win], cwd=os.path.dirname(path), env=wine_env(cfg), stdout=out,
                             stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, start_new_session=True)
    except OSError as ex:
        return False, "Couldn't start Decal's agent: %s" % ex
    log("decal agent: started %s" % win)
    return True, "Started Decal's agent."


def stop_decal_agent():
    """Closes Decal's agent (asks first, then forces). Returns (ok, message)."""
    import signal
    pids = decal_agent_pids()
    if not pids:
        return True, "Decal's agent isn't running."
    for pid in pids:
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError:
            pass
    deadline = time.time() + 4
    while time.time() < deadline and any(os.path.exists("/proc/%d" % p) for p in pids):
        time.sleep(0.25)
    for pid in pids:
        if os.path.exists("/proc/%d" % pid):
            try:
                os.kill(pid, signal.SIGKILL)
            except OSError:
                pass
    log("decal agent: stopped")
    return True, "Stopped Decal's agent."


def set_decal(on):
    """Start / Stop from the launcher or the phone: also switches the service's keep-it-running on or off,
    so a stopped agent stays stopped. Returns (ok, message)."""
    with _cfg_lock:
        cfg = load_config()
        cfg.setdefault("decal_agent", {})["enabled"] = bool(on)
        save_config(cfg)
    if on:
        return (True, "Decal's agent is already running.") if decal_agent_pids() else start_decal_agent(cfg)
    return stop_decal_agent()


_asleep_cache = [0.0, None, ""]


def screen_asleep():
    """(True / False / None, how): is the screen asleep - the monitor off (DPMS standby / suspend / off) or the
    screensaver running? None when there's no way to tell. A logout while it's asleep wasn't you."""
    now = time.time()
    if now - _asleep_cache[0] < 5:
        return _asleep_cache[1], _asleep_cache[2]
    state, how = None, ""
    try:
        if shutil.which("xset") and os.environ.get("DISPLAY"):
            r = subprocess.run(["xset", "q"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL, timeout=5)
            m = re.search(r"Monitor is (\w+)", (r.stdout or b"").decode("utf-8", "replace"))
            if m:
                state, how = m.group(1).lower() != "on", "monitor " + m.group(1).lower()
        if not state and shutil.which("xfce4-screensaver-command"):
            r = subprocess.run(["xfce4-screensaver-command", "-q"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL, timeout=5)
            out = (r.stdout or b"").decode("utf-8", "replace").lower()
            if "is active" in out:
                state, how = True, "screensaver on"
            elif "inactive" in out and state is None:
                state, how = False, "screensaver off"
    except Exception as ex:
        how = "couldn't tell (%s)" % ex
    _asleep_cache[:] = [now, state, how]
    return state, how


def wake_screen(log_result=False):
    """Turns the monitor back on and counts as user activity, so the screen isn't asleep while a client logs in
    (the game ignores the Enter click while the screen is off). XFCE: xfce4-screensaver-command; KDE Wayland:
    kscreen-doctor; X11: xset; any
    desktop with the freedesktop screensaver service: SimulateUserActivity. Whatever isn't there is skipped."""
    tries = []
    if shutil.which("kscreen-doctor") and os.environ.get("WAYLAND_DISPLAY"):
        tries.append(["kscreen-doctor", "--dpms", "on"])
    if shutil.which("xfce4-screensaver-command"):   # XFCE: ends the screensaver (shows the unlock box if it locks)
        tries.append(["xfce4-screensaver-command", "--deactivate"])
    if shutil.which("xset") and os.environ.get("DISPLAY"):
        tries.append(["xset", "dpms", "force", "on"])
        tries.append(["xset", "s", "reset"])
    if shutil.which("busctl"):
        tries.append(["busctl", "--user", "call", "org.freedesktop.ScreenSaver", "/org/freedesktop/ScreenSaver",
                      "org.freedesktop.ScreenSaver", "SimulateUserActivity"])
    done = []
    for cmd in tries:
        try:
            r = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, stdin=subprocess.DEVNULL, timeout=5)
            done.append("%s %s" % (cmd[0], "ok" if r.returncode == 0 else
                                   "failed (%s)" % (r.stderr or b"").decode("utf-8", "replace").strip()[-80:]))
        except Exception as ex:
            done.append("%s failed (%s)" % (cmd[0], ex))
    if log_result:
        log("wake screen: " + (", ".join(done) or "no way to wake the screen found"))


# Who starts the client again after a stuck login: the phone service sets this to its own queued launch.
relaunch_hook = None
_login_retries = {}   # account (lower) -> [epoch of each retry]


def _retry_failed_login(cfg, account, launched_at):
    """A login that got stuck at the character screen: give it 1 more minute, then close the client, wait
    1 minute and launch it again (the "restart_frozen" option; at most 3 times per account in 30 minutes)."""
    if not cfg.get("restart_frozen"):
        return
    acct = find_account(cfg, account)
    if not acct or not acct.get("auto_restart", True):
        return
    key = account.lower()
    now = time.time()
    tries = [t for t in _login_retries.get(key, []) if now - t < 30 * 60]
    if len(tries) >= 3:
        log("login retry %s: stuck 3 times in 30 minutes - leaving it" % account)
        event(account, "gave_up", "Stuck at login 3 times in 30 minutes - left it")
        return
    tries.append(now)
    _login_retries[key] = tries
    wait = max(0, int(cfg.get("frozen_wait_seconds", 60)))

    def work():
        time.sleep(60)
        if _logged_in_since(cfg, account, launched_at):
            log("login retry %s: got in after all" % account)
            return
        ok, msg = kill_client(cfg, account, wait=5.0, kind=None)
        log("login retry %s: still not in the game - %s Starting it again in %d s (%d of 3)." % (account, msg, wait, len(tries)))
        event(account, "restart", "Still not in the game - closed it, starting again in %d s (%d of 3)" % (wait, len(tries)))
        time.sleep(wait)
        hook = relaunch_hook
        ok, msg = hook(account) if hook else launch_account(load_config(), account)
        log("login retry %s: %s" % (account, msg))
    threading.Thread(target=work, daemon=True).start()


def _mark_stuck(cfg, account, tries):
    """The game started but never got into the world: say so in the status, so the phone shows it and alerts."""
    path = os.path.join(remote_dir(cfg), "status_%s.json" % account_key(account))
    try:
        try:
            with open(path, encoding="utf-8-sig") as f:
                st = json.load(f)
        except (OSError, ValueError):
            st = {}
        st.update(running=False, loggedIn=False, loginStuck=int(time.time()),
                  loginNote="Stuck at the character screen - %d Enter clicks didn't get in. Try PC screenshot, "
                            "then Reset game." % tries,
                  updated=utc_now_iso())
        tmp = path + ".tmp-%d" % os.getpid()
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(st, f, indent=2)
        os.replace(tmp, path)
    except Exception as ex:
        log("enter nudge %s: couldn't write the stuck note: %s" % (account, ex))
    event(account, "stuck", "Stuck at the character screen (%d Enter clicks didn't get in)" % tries)


def wineserver_command(cfg):
    """The wineserver that goes with the Wine the launcher uses."""
    w = cfg["wine"]
    if w.get("mode") == "system":
        return shutil.which("wineserver") or "wineserver"
    return os.path.join(os.path.dirname(w["wine_path"]), "wineserver")


def reset_game(cfg):
    """Closes every game client at once and stops Wine for the prefix (wineserver -k), clearing anything stuck
    after a crash. Returns (ok, message)."""
    import signal
    procs = _client_procs()
    for pid, _ in procs:
        try:
            os.kill(pid, signal.SIGKILL)
        except OSError:
            pass
    ws = "not run"
    try:
        r = subprocess.run([wineserver_command(cfg), "-k"], env=wine_env(cfg), stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL, timeout=20)
        ws = "ok" if r.returncode == 0 else "exit %d" % r.returncode
    except Exception as ex:
        ws = str(ex)
    time.sleep(1)
    left = len(_client_procs())
    for a in cfg["accounts"]:
        _mark_closed(cfg, a["account"], "Reset from the phone")
        le = last_event(a["account"])
        if le and le.get("kind") not in ENDS_RUN and le.get("kind") not in ("stuck", "gave_up", "launch_failed"):
            event(a["account"], "reset", "Game reset (every client closed, Wine stopped)")
    log("reset game: killed %d client process(es), wineserver -k %s, %d left" % (len(procs), ws, left))
    if left:
        return False, "Closed %d game process(es), but %d are still running." % (len(procs), left)
    return True, "Closed %d game process(es) and stopped Wine." % len(procs)


# A tiny script run with the launcher's own Python (it has Qt): grabs the whole desktop as a JPEG on stdout.
_SHOT_SCRIPT = r"""
import sys
from PySide6.QtGui import QGuiApplication
from PySide6.QtCore import QBuffer, QByteArray, QIODevice, Qt
app = QGuiApplication(sys.argv)
scr = app.primaryScreen()
g = scr.virtualGeometry()
pix = scr.grabWindow(0, g.x(), g.y(), g.width(), g.height())
if pix.isNull():
    sys.exit(2)
if pix.width() > 2400:
    pix = pix.scaledToWidth(2400, Qt.SmoothTransformation)
ba = QByteArray()
buf = QBuffer(ba)
buf.open(QIODevice.WriteOnly)
pix.save(buf, "JPG", 72)
sys.stdout.buffer.write(bytes(ba))
"""


def screenshot():
    """The PC's screen as JPEG bytes, or raises. Qt first (X11), then grim (Wayland), ImageMagick, scrot."""
    import sys
    wake_screen()      # a blanked screen (screensaver) photographs as plain black
    time.sleep(2)
    tries = [
        [sys.executable, "-c", _SHOT_SCRIPT],
        ["grim", "-t", "jpeg", "-"],
        ["import", "-silent", "-window", "root", "jpeg:-"],
    ]
    errors = []
    for cmd in tries:
        if cmd[0] != sys.executable and not shutil.which(cmd[0]):
            continue
        try:
            r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.DEVNULL, timeout=20)
            if r.returncode == 0 and len(r.stdout) > 1000:
                return r.stdout
            errors.append("%s: %s" % (os.path.basename(cmd[0]), (r.stderr or b"").decode("utf-8", "replace").strip()[-200:] or "exit %d" % r.returncode))
        except Exception as ex:
            errors.append("%s: %s" % (os.path.basename(cmd[0]), ex))
    if shutil.which("scrot"):
        tmp = os.path.join(LOG_DIR, "shot.jpg")
        try:
            subprocess.run(["scrot", "-o", tmp], timeout=20, check=True)
            with open(tmp, "rb") as f:
                return f.read()
        except Exception as ex:
            errors.append("scrot: %s" % ex)
    log("screenshot failed: " + " | ".join(errors))
    raise RuntimeError("Couldn't take a screenshot (" + ("; ".join(errors) or "no screenshot tool found") + ")")


# ── Commands and settings for MelkTank ──────────────────────────────

def send_command(cfg, account, action, feature="", value="", name=""):
    lines = ["action=" + action]
    if feature:
        lines.append("feature=" + feature)
    if value:
        lines.append("value=" + value)
    if name:
        lines.append("name=" + name.replace("\r", " ").replace("\n", " "))
    stamp = "%015d" % int(time.time() * 1000)
    path = os.path.join(remote_dir(cfg), "cmd_%s_%s.txt" % (account_key(account), stamp))
    _atomic_write(path, "\n".join(lines) + "\n")
    log("command for %s: %s" % (account, "action=chat (from the phone)" if action == "chat" else " ".join(lines)))
    return path


def get_interval(cfg):
    path = os.path.join(remote_dir(cfg), "remote_settings.txt")
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                if line.strip().lower().startswith("interval="):
                    return max(15, min(600, int(line.split("=", 1)[1].strip())))
    except Exception:
        pass
    return 45


def read_chat(cfg, account):
    """MelkTank's chat_<account>.json (the last 200 chat lines), or None."""
    path = os.path.join(remote_dir(cfg), "chat_%s.json" % account_key(account))
    try:
        with open(path, encoding="utf-8-sig") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def read_organize(cfg, account):
    """MelkTank's organize_<account>.json (Items > Organize: the switch, rules, packs and the lists to pick from), or None."""
    path = os.path.join(remote_dir(cfg), "organize_%s.json" % account_key(account))
    try:
        with open(path, encoding="utf-8-sig") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def read_inventory(cfg, account):
    """MelkTank's inventory_<account>.json (equipped items and the main pack, with ID lines once identified), or None."""
    path = os.path.join(remote_dir(cfg), "inventory_%s.json" % account_key(account))
    try:
        with open(path, encoding="utf-8-sig") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def set_live(cfg, on, session=False, seconds=12, chat=False):
    """The app's Live switch: MelkTank writes every 2 s while live.txt's time is ahead (the app renews it with
    each refresh, so it lapses on its own within seconds of the app closing). session: the session page is open."""
    path = os.path.join(remote_dir(cfg), "live.txt")
    if not on:
        try:
            os.remove(path)
        except OSError:
            pass
        return
    _atomic_write(path, "until=%d\nsession=%d\nchat=%d\n" % (int(time.time()) + int(seconds), 1 if session else 0, 1 if chat else 0))


def set_interval(cfg, seconds):
    seconds = max(15, min(600, int(seconds)))
    _atomic_write(os.path.join(remote_dir(cfg), "remote_settings.txt"), "interval=%d\n" % seconds)
    return seconds


# ── Launching ───────────────────────────────────────────────────────

HELPER_NAME = "mtlaunch.exe"


def helper_unix(cfg):
    return os.path.join(remote_dir(cfg), HELPER_NAME)


def install_helper(cfg, source):
    """Copies mtlaunch.exe into the prefix (C:\\Games\\MelkTankRemote) so Wine can run it."""
    dst = helper_unix(cfg)
    if os.path.abspath(source) != os.path.abspath(dst):
        shutil.copy2(source, dst)
    return dst


def wine_command(cfg):
    w = cfg["wine"]
    if w.get("mode") == "system":
        return [shutil.which("wine") or "wine"]
    return [w["wine_path"]]


def wine_env(cfg):
    w = cfg["wine"]
    env = dict(os.environ)
    env["WINEPREFIX"] = w["prefix"]
    env["WINEARCH"] = "win32"
    env["WINEDEBUG"] = "-all"
    if w.get("esync"):
        env["WINEESYNC"] = "1"
    if w.get("fsync"):
        env["WINEFSYNC"] = "1"
    for k, v in (w.get("extra_env") or {}).items():
        env[str(k)] = str(v)
    return env


def check_setup(cfg):
    """Problems that would stop a launch, as plain sentences (empty list = ready)."""
    problems = []
    w = cfg["wine"]
    if not os.path.isdir(w["prefix"]):
        problems.append("Wine prefix not found: " + w["prefix"])
    if w.get("mode") != "system" and not os.path.isfile(w["wine_path"]):
        problems.append("Wine not found: " + w["wine_path"])
    if w.get("mode") == "system" and not shutil.which("wine"):
        problems.append("No `wine` on this PC's PATH.")
    if not os.path.isfile(win_to_unix(cfg, cfg["client"])):
        problems.append("acclient.exe not found: " + cfg["client"])
    if cfg.get("use_decal", True):
        if not os.path.isfile(win_to_unix(cfg, cfg["injector"])):
            problems.append("ThwargLauncher's injector.dll not found: " + cfg["injector"])
        if not os.path.isfile(helper_unix(cfg)):
            problems.append("mtlaunch.exe isn't in " + remote_dir(cfg) + " (run setup.sh again).")
    return problems


def thwarg_appdata(cfg):
    """The ThwargLauncher folder in the prefix's AppData (where ThwargFilter looks for launch files), or None."""
    users = os.path.join(drive_c(cfg), "users")
    try:
        for u in sorted(os.listdir(users)):
            d = os.path.join(users, u, "AppData", "Roaming", "ThwargLauncher")
            if os.path.isdir(d):
                return d
    except OSError:
        pass
    return None


def write_launch_file(cfg, acct):
    srv = find_server(cfg, acct.get("server")) or {}
    character = (acct.get("character") or "").strip()
    picker = cfg.get("character_picker", "thwargfilter")
    text = "time=%s\ncharacter=%s\nserver=%s\nslots=%d\npicker=%s\n" % (
        utc_now_iso(), character, srv.get("name", ""), int(srv.get("slots") or 11), picker)
    _atomic_write(os.path.join(remote_dir(cfg), "launch_%s.txt" % account_key(acct["account"])), text)

    if picker == "thwargfilter" and character:
        # ThwargFilter's own launch file (same format ThwargLauncher writes); it only acts on one under 45s old
        base = thwarg_appdata(cfg)
        if base:
            os.makedirs(os.path.join(base, "LaunchFiles"), exist_ok=True)
            now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.0000000Z")
            tf = "FileVersion:1.2\nTimestamp=TimeUtc:'%s'\nServerName:%s\nAccountName:%s\nCharacterName:%s\n" % (
                now, srv.get("name", ""), acct["account"], character)
            _atomic_write(os.path.join(base, "LaunchFiles", "launch_ThwargFilter_%s_%s.txt" % (srv.get("name", ""), acct["account"])), tf)
        else:
            log("ThwargFilter launch file not written: no ThwargLauncher folder in the prefix")


def launch_account(cfg, account, manual=False):
    """Starts one client for this account. Returns (ok, message). manual = started from the launcher window by you
    (you're at the PC): after login its window is placed, but the focus is left on it."""
    acct = find_account(cfg, account)
    if not acct:
        return False, "No account named %s." % account
    if not acct.get("password"):
        return False, "No password saved for %s." % account
    srv = find_server(cfg, acct.get("server"))
    if not srv:
        return False, "No server set up."
    problems = check_setup(cfg)
    if problems:
        return False, " ".join(problems)
    wake_screen(log_result=True)
    try:
        ip = socket.gethostbyname(srv["host"])
    except OSError:
        return False, "Can't look up %s - is the internet up?" % srv["host"]

    write_launch_file(cfg, acct)
    client_args = ["-a", acct["account"], "-v", acct["password"], "-h", "%s:%d" % (ip, int(srv["port"])),
                   "-rodat", "on" if srv.get("rodat") else "off"]
    client_win = cfg["client"]
    if cfg.get("use_decal", True):
        cmd = wine_command(cfg) + ["C:\\Games\\MelkTankRemote\\" + HELPER_NAME, cfg["injector"], client_win] + client_args
    else:
        cmd = wine_command(cfg) + [client_win] + client_args
    cwd = os.path.dirname(win_to_unix(cfg, client_win))
    shown = " ".join(c if c != acct["password"] else "******" for c in cmd)
    log("launch %s: %s" % (acct["account"], shown))
    event(acct["account"], "launch", "Starting the game")
    # Wine's output goes to a file, not a pipe: Wine's background server (and the game) inherit it and keep it open
    os.makedirs(LOG_DIR, exist_ok=True)
    out_path = os.path.join(LOG_DIR, "launch-%s.log" % account_key(acct["account"]))
    _keep_old_launch_log(out_path)
    try:
        with open(out_path, "w") as out:
            p = subprocess.Popen(cmd, cwd=cwd, env=wine_env(cfg), stdout=out, stderr=subprocess.STDOUT,
                                 stdin=subprocess.DEVNULL, start_new_session=True)
    except OSError as ex:
        return False, "Couldn't start Wine: %s" % ex

    if not cfg.get("use_decal", True):
        return True, "Started %s (no Decal)." % acct["account"]
    # mtlaunch prints "PID n" once the client is up with Decal (or "ERROR ...") and exits
    deadline = time.time() + 90
    lines = []
    while time.time() < deadline:
        time.sleep(0.5)
        try:
            with open(out_path, errors="replace") as f:
                lines = [ln.strip() for ln in f if ln.strip()]
        except OSError:
            lines = []
        for line in lines:
            if line.startswith("PID "):
                log("launched %s: %s" % (acct["account"], line))
                if (acct.get("character") or "").strip() and cfg.get("character_picker", "thwargfilter") == "thwargfilter":
                    _start_enter_nudge(cfg, acct["account"], line[4:].strip(), time.time(), manual)
                else:
                    _watch_login(cfg, acct["account"], time.time(), manual)
                return True, "Started %s." % acct["account"]
            if line.startswith("ERROR"):
                log("launch failed %s: %s" % (acct["account"], line))
                event(acct["account"], "launch_failed", line[6:])
                return False, line[6:]
        if p.poll() is not None and p.returncode != 0:
            break
    tail = " / ".join(lines[-3:]) if lines else "no output"
    log("launch unclear %s: %s" % (acct["account"], tail))
    event(acct["account"], "launch_failed", "Launch didn't confirm: " + tail)
    return False, "Launch didn't confirm (%s) - check the game window." % tail


def _logged_in_since(cfg, account, since):
    """True once MelkTank's status file says the character is in the world, written after the launch."""
    st = read_status(cfg, account)
    if not st or not st.get("loggedIn"):
        return False
    path = os.path.join(remote_dir(cfg), "status_%s.json" % account_key(account))
    try:
        return os.path.getmtime(path) >= since
    except OSError:
        return False


def _after_login(cfg, account, manual=False):
    """Once the character is in the world: the game window to the top-left corner, then 5 s later the focus off
    the games (they stop drawing). focus_after_login off: leave the window alone."""
    if not cfg.get("focus_after_login", True):
        return
    acct = find_account(cfg, account) or {}
    corner = acct.get("window_corner") or "top-left"
    if corner == "none":
        return
    time.sleep(2)
    wait_window_settled(account)      # a plugin resizes the window during login: place it once that's done
    ok, msg = move_client_corner(account, corner)
    log("after login %s: %s" % (account, msg))
    if manual:
        log("after login %s: started from the launcher - leaving the focus on it" % account)
        return
    time.sleep(5)
    ok, msg = unfocus_games()
    log("after login %s: %s" % (account, msg))


def _watch_login(cfg, account, launched_at, manual=False, timeout=180):
    """No Enter clicks to send (no character picked for this account): just wait for it to be in the world."""
    def work():
        deadline = launched_at + timeout
        while time.time() < deadline:
            time.sleep(3)
            if _logged_in_since(cfg, account, launched_at):
                _after_login(cfg, account, manual)
                return
    threading.Thread(target=work, daemon=True).start()


def _start_enter_nudge(cfg, account, pid, launched_at, manual=False):
    """ThwargFilter selects the character and clicks Enter in the same instant; under Wine the Enter click can
    arrive before the selection has gone through, leaving the character picked but not logged in. So: from 15 s
    after the launch, click Enter again every 4 s (mtlaunch.exe --enter) until MelkTank reports the character in
    the world, for at most 75 s. Clicking Enter with a character already selected just logs it in."""
    def work():
        time.sleep(15)
        deadline = launched_at + 90
        tries = 0
        while time.time() < deadline:
            if _logged_in_since(cfg, account, launched_at):
                log("enter nudge %s: in the world after %d extra click(s)" % (account, tries))
                _after_login(cfg, account, manual)
                return
            wake_screen()
            try:
                subprocess.run(wine_command(cfg) + ["C:\\Games\\MelkTankRemote\\" + HELPER_NAME, "--enter", str(pid)],
                               env=wine_env(cfg), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                               stdin=subprocess.DEVNULL, timeout=20)
                tries += 1
            except Exception as ex:
                log("enter nudge %s: %s" % (account, ex))
            time.sleep(4)
        log("enter nudge %s: gave up after %d click(s)" % (account, tries))
        _mark_stuck(cfg, account, tries)
        _retry_failed_login(cfg, account, launched_at)
    threading.Thread(target=work, daemon=True).start()


def launch_many(cfg, accounts, progress=None, manual=False):
    """Launches accounts one after another, launch_delay seconds apart. progress(text) is called along the way."""
    results = []
    for i, a in enumerate(accounts):
        if i > 0:
            delay = int(cfg.get("launch_delay") or 20)
            if progress:
                progress("Waiting %ds before %s..." % (delay, a))
            time.sleep(delay)
        if progress:
            progress("Starting %s..." % a)
        ok, msg = launch_account(cfg, a, manual)
        results.append((a, ok, msg))
        if progress:
            progress(msg)
    return results
