#!/usr/bin/env python3
"""
MelkTank Loot Editor - the in-game loot editor, out of the game.

Edits the VTank .utl loot profiles MelkTank uses (same folder, same fields, same file format - a profile saved
without changes is byte-for-byte the same). Save writes the file; Push saves and tells every running MelkTank to
read it again, so a character that's hunting uses the changes straight away; Sync reads the file again from disk
(picking up changes made in game or on the phone). T11+ requirements (ILT mods, rends...) are shown but can only
be changed in game.
"""
import os
import sys

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QHBoxLayout, QInputDialog,
                               QLabel, QLineEdit, QListWidget, QListWidgetItem, QMainWindow, QMessageBox, QPushButton,
                               QScrollArea, QSplitter, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lootmodel as lm  # noqa: E402
import mtcore  # noqa: E402

GREY, GREEN, ORANGE, PURPLE, RED, CYAN = "#9a9a9a", "#5ccc6a", "#e8a33a", "#b685f2", "#e06060", "#5ad6f2"
ACT_COLOUR = {"0": GREY, "1": GREEN, "10": GREEN, "2": ORANGE, "3": PURPLE, "5": CYAN, "6": CYAN}


class FieldPicker(QDialog):
    """What should the item have? - the field list by group, with a search box (like the in-game picker)."""

    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("Add requirement")
        self.resize(480, 520)
        lay = QVBoxLayout(self)
        self.search = QLineEdit()
        self.search.setPlaceholderText("What should the item have? e.g. armor level, biting, ring...")
        lay.addWidget(self.search)
        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        lay.addWidget(self.tree, 1)
        self.tip = QLabel("")
        self.tip.setWordWrap(True)
        self.tip.setStyleSheet("color: %s" % GREY)
        lay.addWidget(self.tip)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.search.textChanged.connect(self.fill)
        self.tree.itemDoubleClicked.connect(lambda *_: self.accept())
        self.tree.currentItemChanged.connect(self.show_tip)
        self.fill()

    def fill(self):
        q = self.search.text().strip().lower()
        self.tree.clear()
        groups = {}
        for i, f in enumerate(lm.FIELDS):
            text = f["label"] + ("  -  " + f["hint"] if f.get("hint") else "")
            if q and q not in text.lower() and q not in (f.get("tip") or "").lower():
                continue
            g = groups.get(f["group"])
            if g is None:
                g = groups[f["group"]] = QTreeWidgetItem([f["group"]])
                self.tree.addTopLevelItem(g)
            it = QTreeWidgetItem([text])
            it.setData(0, Qt.UserRole, i)
            g.addChild(it)
        self.tree.expandAll()

    def show_tip(self, cur, _prev):
        i = cur.data(0, Qt.UserRole) if cur else None
        self.tip.setText(lm.FIELDS[i].get("tip") or "" if i is not None else "")

    def picked(self):
        it = self.tree.currentItem()
        return it.data(0, Qt.UserRole) if it else None


class ReqRowWidget(QWidget):
    """One requirement: X, what it checks, compare, value - changes go straight back into the rule."""

    def __init__(self, editor, rule, index):
        super().__init__()
        self.editor, self.rule, self.index = editor, rule, index
        q = rule.reqs[index]
        self.row = lm.to_row(q)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        x = QPushButton("X")
        x.setFixedWidth(26)
        x.setStyleSheet("background:#8a2a2a;color:white")
        x.setToolTip("Remove this requirement")
        x.clicked.connect(self.remove)
        lay.addWidget(x)
        if self.row is None or self.row.get("ro") or self.row.get("f", -1) < 0 and self.row.get("rawtype") is None:
            lab = QLabel((lm.row_say(self.row) if self.row else "Unknown requirement " + q.type) + "   (change it in game)")
            lab.setStyleSheet("color: %s" % GREY)
            lay.addWidget(lab, 1)
            return
        f = lm.FIELDS[self.row["f"]] if self.row["f"] >= 0 else None
        name = QPushButton(lm.field_label(self.row) if f else lm.row_say(self.row))
        name.setToolTip((f.get("tip") or "") if f else "")
        name.clicked.connect(self.change_field)
        lay.addWidget(name)
        if f is None:
            self._raw_values(lay)
        else:
            self._controls(lay, f)
        lay.addStretch(1)

    # ── controls by kind (same as the in-game editor) ──
    def _controls(self, lay, f):
        k, row = f["kind"], self.row
        if k in ("int", "dbl"):
            if f.get("any"):
                key = QLineEdit(str(row.get("key") or ""))
                key.setFixedWidth(90)
                key.setToolTip("Property number")
                key.textEdited.connect(lambda t: self._set_key(t))
                lay.addWidget(key)
            ops = f["ops"] or ([">=", "<="] if k == "dbl" else [">=", "<=", "=", "!="])
            self._op(lay, ops)
            if f.get("vk") and f["vk"] in lm.MAPS:
                self._map(lay, f["vk"], 0)
            else:
                self._num(lay, 0, 100)
        elif k == "str":
            lay.addWidget(QLabel("matches"))
            self._text(lay, 0, "regex, | = or", 280)
        elif k == "aethrating":
            cb = QComboBox()
            for n, c in zip(lm.SPEC["ratingNames"], lm.SPEC["ratingCodes"]):
                cb.addItem("%s (%s)" % (n, c))
            ri = lm._rating_index(row.get("key") or 372)
            cb.setCurrentIndex(max(0, ri))
            cb.currentIndexChanged.connect(lambda i: self._set_key(str(lm.SPEC["ratingKeys"][i])))
            lay.addWidget(cb)
            lay.addWidget(QLabel("at least"))
            self._num(lay, 0, 80)
        elif k == "oclass":
            lay.addWidget(QLabel("is"))
            cb = QComboBox()
            cb.addItems(lm.SPEC["objectClasses"])
            cb.setCurrentIndex(max(0, min(lm.to_int(row["v"][0]), cb.count() - 1)))
            cb.currentIndexChanged.connect(lambda i: self._set_v(0, str(i)))
            lay.addWidget(cb)
        elif k == "spellname":
            self._text(lay, 0, "spell name, | = or", 280)
        elif k == "cloakspell":
            lay.addWidget(QLabel("is"))
            ck = QComboBox()
            ck.addItems(lm.SPEC["cloakKinds"])
            ck.setCurrentIndex(max(0, min(lm.to_int(row["v"][0]), ck.count() - 1)))
            ce = QComboBox()
            ce.addItems(lm.SPEC["cloakElements"])
            ce.setCurrentIndex(max(0, min(lm.to_int(row["v"][1]), ce.count() - 1)))
            ce.setVisible(ck.currentIndex() == 6)
            ck.currentIndexChanged.connect(lambda i: (self._set_v(0, str(i)), ce.setVisible(i == 6)))
            ce.currentIndexChanged.connect(lambda i: self._set_v(1, str(i)))
            lay.addWidget(ck)
            lay.addWidget(ce)
        elif k == "spells":
            lay.addWidget(QLabel("at least"))
            self._num(lay, 2, 45)
            lay.addWidget(QLabel("like"))
            self._text(lay, 0, "Legendary|Epic", 190)
            lay.addWidget(QLabel("but not"))
            self._text(lay, 1, "(optional)", 130)
        elif k == "charlvl":
            self._op(lay, [">=", "<="])
            self._num(lay, 0, 80)
        elif k == "charskill":
            self._map(lay, "skill", 1)
            lay.addWidget(QLabel("at least"))
            self._num(lay, 0, 80)
        elif k == "charbase":
            self._map(lay, "skill", 0)
            lay.addWidget(QLabel("from"))
            self._num(lay, 1, 70)
            lay.addWidget(QLabel("to"))
            self._num(lay, 2, 70)
        elif k in ("spellcount", "packslots", "calc"):
            lay.addWidget(QLabel("at least"))
            self._num(lay, 0, 100)
        elif k == "t11":
            self._t11(lay, f)
        elif k == "raw":
            self._raw_values(lay)

    # T11+ (ILT text lines): the same choices as the in-game editor
    def _t11(self, lay, f):
        tid, d, row = f["t11"], lm.SPEC["t11"][f["t11"]], self.row
        p = row.setdefault("p", [])
        mod = (lm.mod_by_key(lm.p_get(p, "k")) or lm.SPEC["mods"][0]) if tid == "mod" else None
        has_value = bool(mod.get("fmt")) if mod else not d["novalue"]
        if has_value:
            lay.addWidget(QLabel("at least"))
            e = QLineEdit(lm.p_get(p, "v") or "")
            e.setFixedWidth(70)
            e.textEdited.connect(lambda t: self._set_p("v", t))
            lay.addWidget(e)
            unit = (((mod.get("unit") or "") + "  (range " + (mod.get("band") or "") + ")").strip()) if mod else (d["unit"] or "")
            u = QLabel(unit)
            u.setStyleSheet("color: %s" % GREY)
            lay.addWidget(u)
        elif mod:
            u = QLabel("on or off - it has no number")
            u.setStyleSheet("color: %s" % GREY)
            lay.addWidget(u)
        opt = d.get("opt")
        if opt == "el":
            lay.addWidget(QLabel("element"))
            self._choice(lay, "el", [("any", "")] + [(x, x) for x in lm.SPEC["rends"]], 110)
        elif opt == "sp":
            lay.addWidget(QLabel("slayer of"))
            t11 = lm.SPEC["slayerT11"]
            items = [("any species", "")] + [(x, x) for x in t11] + [("── every other species ──", None)] + \
                    [(x, x) for x in lm.SPEC["slayerAll"] if x not in t11]
            self._choice(lay, "sp", items, 170)
        elif opt == "grade":
            g = (lm.p_get(p, "g") or "C")[:1].upper()
            if lm.p_get(p, "g") != g:
                lm.p_set(p, "g", g)        # an older "C+" setting shows as C (saved only if changed)
            lay.addWidget(QLabel("at least"))
            self._choice(lay, "g", [(x, x) for x in reversed(lm.SPEC["gearGrades"])], 60)
            u = QLabel("(F worst ... S best; each takes its - and +: B = B-, B, B+)")
            u.setStyleSheet("color: %s" % GREY)
            lay.addWidget(u)
        elif opt == "name":
            lay.addWidget(QLabel("spell contains"))
            e = QLineEdit(lm.p_get(p, "name") or "")
            e.setPlaceholderText("any - or Nether Arc")
            e.setMinimumWidth(170)
            e.textEdited.connect(lambda t: self._set_p("name", t.strip()))
            lay.addWidget(e)
        if tid in ("mod", "modcount"):
            lay.addWidget(QLabel("on"))
            w = row.get("where") or d["where"]
            cb = QComboBox()
            cb.addItem("Armor, jewelry, shields", "14")
            cb.addItem("Weapons", "16")
            cb.setCurrentIndex(1 if w == "16" else 0)
            cb.currentIndexChanged.connect(lambda i: self._set_where(cb.itemData(i)))
            lay.addWidget(cb)

    def _choice(self, lay, key, items, w):
        cb = QComboBox()
        cb.setMinimumWidth(w)
        cur = lm.p_get(self.row["p"], key) or ""
        sel = 0
        for i, (text, val) in enumerate(items):
            cb.addItem(text, val)
            if val is None:     # a heading, not a choice
                cb.model().item(i).setEnabled(False)
            elif val == cur:
                sel = i
        if cur and not any(v == cur for _t, v in items):
            cb.addItem(cur, cur)
            sel = cb.count() - 1
        cb.setCurrentIndex(sel)
        cb.currentIndexChanged.connect(lambda i: self._set_p(key, cb.itemData(i) or ""))
        lay.addWidget(cb)

    def _set_p(self, k, v):
        lm.p_set(self.row.setdefault("p", []), k, v)
        self._store()

    def _set_where(self, w):
        self.row["where"] = w
        self._store()

    def _raw_values(self, lay):
        rt = lm.REQTYPES.get(lm.FIELDS[self.row["f"]]["type"] if self.row["f"] >= 0 else self.row.get("rawtype"))
        for i, val in enumerate(self.row["v"]):
            if rt and i < len(rt["fields"]):
                lay.addWidget(QLabel(rt["fields"][i][0]))
            self._text(lay, i, "", 110)

    def _op(self, lay, ops):
        cb = QComboBox()
        for o in ops:
            cb.addItem(lm.OPNAMES.get(o, o), o)
        if self.row.get("op") in ops:
            cb.setCurrentIndex(ops.index(self.row["op"]))
        cb.currentIndexChanged.connect(lambda i: self._set_op(ops[i]))
        lay.addWidget(cb)

    def _map(self, lay, vk, vi):
        cb = QComboBox()
        items = lm.MAPS[vk]
        cur = self.row["v"][vi] if vi < len(self.row["v"]) else ""
        for key, text in items:
            cb.addItem(text, key)
        idx = next((i for i, (key, _t) in enumerate(items) if key == cur), -1)
        if idx < 0:
            cb.addItem(cur, cur)
            idx = cb.count() - 1
        cb.setCurrentIndex(idx)
        cb.currentIndexChanged.connect(lambda i: self._set_v(vi, cb.itemData(i)))
        lay.addWidget(cb)

    def _num(self, lay, vi, w):
        e = QLineEdit(self.row["v"][vi] if vi < len(self.row["v"]) else "")
        e.setFixedWidth(w)
        e.textEdited.connect(lambda t: self._set_v(vi, t))
        lay.addWidget(e)

    def _text(self, lay, vi, hint, w):
        e = QLineEdit(self.row["v"][vi] if vi < len(self.row["v"]) else "")
        e.setPlaceholderText(hint)
        e.setMinimumWidth(w)
        e.textEdited.connect(lambda t: self._set_v(vi, t))
        lay.addWidget(e)

    # ── changes ──
    def _store(self):
        self.rule.reqs[self.index] = lm.from_row(self.row)
        self.editor.changed()

    def _set_v(self, i, val):
        while len(self.row["v"]) <= i:
            self.row["v"].append("")
        self.row["v"][i] = val
        self._store()

    def _set_op(self, op):
        self.row["op"] = op
        self._store()

    def _set_key(self, t):
        try:
            self.row["key"] = int(t)
        except ValueError:
            return
        self._store()

    def remove(self):
        del self.rule.reqs[self.index]
        self.editor.changed()
        self.editor.show_rule()

    def change_field(self):
        d = FieldPicker(self)
        if d.exec() and d.picked() is not None:
            self.rule.reqs[self.index] = lm.from_row(lm.new_row(d.picked()))
            self.editor.changed()
            self.editor.show_rule()


class LootEditor(QMainWindow):
    def __init__(self):
        super().__init__()
        self.cfg = mtcore.load_config()
        self.profile, self.file, self.mtime, self.dirty, self.sel = None, None, None, False, -1
        self.setWindowTitle("MelkTank Loot Editor")
        self.resize(1150, 720)
        root = QWidget()
        self.setCentralWidget(root)
        v = QVBoxLayout(root)

        # Profile bar: pick, Sync, Save, Push, Save as
        bar = QHBoxLayout()
        bar.addWidget(QLabel("<b style='color:%s'>Profile</b>" % CYAN))
        self.pick = QComboBox()
        self.pick.setMinimumWidth(320)
        self.pick.activated.connect(self.pick_changed)
        bar.addWidget(self.pick)
        self.btn_sync = QPushButton("Sync")
        self.btn_sync.setToolTip("Reads the profile again from disk - picks up changes saved in game or on the phone.\nUnsaved edits here are dropped.")
        self.btn_sync.clicked.connect(self.sync)
        self.btn_save = QPushButton("Save")
        self.btn_save.setToolTip("Writes the profile to its .utl file (the first save each run keeps a .utl.bak copy).")
        self.btn_save.clicked.connect(lambda: self.save(push=False))
        self.btn_push = QPushButton("Push")
        self.btn_push.setToolTip("Saves, then tells every running MelkTank to read this profile again -\na character that's hunting uses the changes straight away.")
        self.btn_push.clicked.connect(lambda: self.save(push=True))
        self.btn_saveas = QPushButton("Save as...")
        self.btn_saveas.clicked.connect(self.save_as)
        for b in (self.btn_sync, self.btn_save, self.btn_push, self.btn_saveas):
            bar.addWidget(b)
        self.counts = QLabel("")
        self.counts.setStyleSheet("color:%s" % GREY)
        bar.addWidget(self.counts)
        bar.addStretch(1)
        v.addLayout(bar)
        self.folder = QLabel("")
        self.folder.setStyleSheet("color:%s" % GREY)
        v.addWidget(self.folder)

        split = QSplitter()
        v.addWidget(split, 1)

        # Rule list
        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 0, 0)
        tools = QHBoxLayout()
        self.filter = QLineEdit()
        self.filter.setPlaceholderText("filter rules")
        self.filter.textChanged.connect(self.fill_rules)
        tools.addWidget(self.filter)
        for text, fn in (("+ Rule", self.add_rule), ("+ Section", self.add_section), ("Copy", self.copy_rule),
                         ("Up", lambda: self.move(-1)), ("Down", lambda: self.move(1))):
            b = QPushButton(text)
            b.clicked.connect(fn)
            tools.addWidget(b)
        lv.addLayout(tools)
        self.rules = QListWidget()
        from PySide6.QtGui import QFontDatabase
        mono = QFontDatabase.systemFont(QFontDatabase.FixedFont)
        mono.setPointSize(10)
        self.rules.setFont(mono)
        self.rules.currentRowChanged.connect(self.rule_picked)
        self.rules.itemChanged.connect(self.rule_ticked)
        lv.addWidget(self.rules, 1)
        hint = QLabel("first match wins - tick = rule on")
        hint.setStyleSheet("color:%s" % GREY)
        lv.addWidget(hint)
        split.addWidget(left)

        # Rule editor
        self.edit_area = QScrollArea()
        self.edit_area.setWidgetResizable(True)
        split.addWidget(self.edit_area)
        split.setSizes([420, 730])

        self.status = self.statusBar()
        self.fill_profiles()

    # ── profiles ──
    def fill_profiles(self, select=None):
        info = mtcore.loot_list(self.cfg)
        self.folder.setText("Folder: " + info["dir"])
        names = [p["name"] for p in info["profiles"]]
        self.pick.clear()
        self.pick.addItems(names)
        target = select or self.file or (names[0] if names else None)
        if target in names:
            self.pick.setCurrentIndex(names.index(target))
            self.load(target)
        elif not names:
            self.status.showMessage("No .utl profiles in " + info["dir"])

    def pick_changed(self, _i):
        name = self.pick.currentText()
        if name == self.file:
            return
        if self.dirty and QMessageBox.question(self, "Unsaved changes", "Drop the unsaved changes to %s?" % self.file) != QMessageBox.Yes:
            self.pick.setCurrentText(self.file)
            return
        self.load(name)

    def load(self, name):
        try:
            self.profile, self.mtime = mtcore.loot_load(self.cfg, name)
        except Exception as ex:
            QMessageBox.warning(self, "Couldn't read", "%s: %s" % (name, ex))
            return
        self.file, self.dirty = name, False
        self.sel = 0 if self.profile.rules else -1
        self.fill_rules()
        self.status.showMessage("Read " + name)

    def sync(self):
        if not self.file:
            return
        if self.dirty and QMessageBox.question(self, "Sync", "Drop the unsaved changes and read %s again?" % self.file) != QMessageBox.Yes:
            return
        keep = self.sel
        self.fill_profiles(self.file)
        self.sel = min(keep, len(self.profile.rules) - 1) if self.profile else -1
        self.fill_rules()
        self.status.showMessage("Synced " + self.file + " from disk")

    def save(self, push):
        if not self.profile:
            return
        ok, mt = mtcore.loot_save(self.cfg, self.file, self.profile, self.mtime)
        if not ok:
            if QMessageBox.question(self, "Changed on disk",
                                    "%s was changed since you opened it (in game or on the phone).\n\nSave anyway (overwrites those changes)?"
                                    % self.file) != QMessageBox.Yes:
                return
            ok, mt = mtcore.loot_save(self.cfg, self.file, self.profile, None, True)
        self.mtime, self.dirty = mt, False
        msg = "Saved " + self.file
        if push:
            sent = mtcore.loot_push(self.cfg, self.file)
            msg += (" - pushed to " + ", ".join(sent)) if sent else " - no game running to push to"
        self.fill_rules()
        self.status.showMessage(msg)

    def save_as(self):
        if not self.profile:
            return
        name, ok = QInputDialog.getText(self, "Save as", "New profile name:", text=os.path.splitext(self.file)[0] + " copy")
        if not ok or not name.strip():
            return
        name = name.strip()
        if not name.lower().endswith(".utl"):
            name += ".utl"
        if os.path.exists(os.path.join(mtcore.loot_dir(self.cfg), name)) and \
                QMessageBox.question(self, "Save as", name + " exists - overwrite it?") != QMessageBox.Yes:
            return
        mtcore.loot_save(self.cfg, name, self.profile, None, True)
        self.file, self.dirty = name, False
        self.fill_profiles(name)

    def changed(self):
        self.dirty = True
        self.btn_save.setText("Save *")
        self.btn_save.setStyleSheet("background:#9a7020;color:white")
        self.refresh_rule_text()

    # ── rule list ──
    def fill_rules(self):
        self.btn_save.setText("Save *" if self.dirty else "Save")
        self.btn_save.setStyleSheet("background:#9a7020;color:white" if self.dirty else "")
        self.rules.blockSignals(True)
        self.rules.clear()
        p = self.profile
        if not p:
            self.rules.blockSignals(False)
            return
        f = self.filter.text().strip().lower()
        for i, r in enumerate(p.rules):
            it = QListWidgetItem()
            it.setData(Qt.UserRole, i)
            self._rule_item(it, r)
            it.setHidden(bool(f) and f not in r.name.lower())
            self.rules.addItem(it)
        active = sum(1 for r in p.rules if not r.off and not r.is_section)
        self.counts.setText("(%d rules) (%d on)" % (len(p.rules), active))
        if 0 <= self.sel < len(p.rules):
            self.rules.setCurrentRow(self.sel)
        self.rules.blockSignals(False)
        self.show_rule()

    def _rule_item(self, it, r):
        spacer = not r.name.strip() and r.off
        label = "------" if spacer else (r.name.strip() or "(no name)")
        if not r.is_section and not spacer:
            act = ("Keep " + (r.keepn or "1")) if r.act == "10" else lm.action_name(r.act)
            label = "%-40s  %s" % (label, act)
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Unchecked if r.off else Qt.Checked)
        it.setText(label)
        it.setForeground(QColor(RED if r.is_section else GREY if r.off else ACT_COLOUR.get(r.act, "#e8e8e8")))

    def refresh_rule_text(self):
        if self.profile and 0 <= self.sel < self.rules.count():
            self.rules.blockSignals(True)
            self._rule_item(self.rules.item(self.sel), self.profile.rules[self.sel])
            self.rules.blockSignals(False)

    def rule_picked(self, row):
        self.sel = row
        self.show_rule()

    def rule_ticked(self, it):
        i = it.data(Qt.UserRole)
        r = self.profile.rules[i]
        on = it.checkState() == Qt.Checked
        if on == r.off:
            r.set_off(not on)
            self.changed()
            if i == self.sel:
                self.show_rule()

    def insert(self, r):
        at = self.sel + 1 if 0 <= self.sel < len(self.profile.rules) else 0
        self.profile.rules.insert(at, r)
        self.sel = at
        self.dirty = True
        self.fill_rules()

    def add_rule(self):
        if self.profile:
            self.insert(lm.Rule("New rule"))

    def add_section(self):
        if self.profile:
            r = lm.Rule("***** New section *****")
            r.reqs.append(lm.Req.new("1", "do not edit", "1"))
            r.set_off(True)
            self.insert(r)

    def copy_rule(self):
        if self.profile and 0 <= self.sel < len(self.profile.rules):
            s = self.profile.rules[self.sel]
            c = lm.Rule(s.name + " copy", s.expr, s.pri, s.act, s.keepn,
                        [lm.Req(q.type, list(q.vals) if q.vals is not None else None, q.lenstr, q.raw, q.dirty) for q in s.reqs])
            self.insert(c)

    def move(self, d):
        p = self.profile
        if not p or not 0 <= self.sel < len(p.rules) or not 0 <= self.sel + d < len(p.rules):
            return
        p.rules[self.sel], p.rules[self.sel + d] = p.rules[self.sel + d], p.rules[self.sel]
        self.sel += d
        self.dirty = True
        self.fill_rules()

    # ── rule editor ──
    def show_rule(self):
        w = QWidget()
        v = QVBoxLayout(w)
        p = self.profile
        if not p or not 0 <= self.sel < len(p.rules):
            v.addWidget(QLabel("Click a rule to edit it."))
            v.addStretch(1)
            self.edit_area.setWidget(w)
            return
        r = p.rules[self.sel]
        top = QHBoxLayout()
        top.addWidget(QLabel("Name"))
        name = QLineEdit(r.name)
        name.textEdited.connect(lambda t: (setattr(r, "name", t), self.changed()))
        top.addWidget(name, 1)
        spacer = not r.name.strip() and r.off
        if not r.is_section and not spacer:
            act = QComboBox()
            act.addItems(lm.ACT_NAMES)
            if r.act in lm.ACT_IDS:
                act.setCurrentIndex(lm.ACT_IDS.index(r.act))
            else:
                act.addItem(lm.action_name(r.act))
                act.setCurrentIndex(act.count() - 1)
            act.setToolTip("MelkTank loots Keep, Salvage, Sell and Keep up to; No loot stops later rules from looting it.\n"
                           "Chunk / Reveal: looted like Keep, then broken up with the Aetheria Hammer / revealed with an\n"
                           "Aetheria Mana Stone when it's calm (Settings > Items). Saved as User 1 / User 2.")
            keep = QLineEdit(r.keepn or "1")
            keep.setFixedWidth(50)
            keep.setVisible(r.act == "10")
            keep_lab = QLabel("up to")
            keep_lab.setVisible(r.act == "10")

            def act_changed(i):
                if i < len(lm.ACT_IDS):
                    r.act = lm.ACT_IDS[i]
                    if r.act == "10" and not r.keepn:
                        r.keepn = "1"
                    keep.setVisible(r.act == "10")
                    keep_lab.setVisible(r.act == "10")
                    self.changed()
            act.currentIndexChanged.connect(act_changed)
            keep.textEdited.connect(lambda t: (setattr(r, "keepn", t), self.changed()))
            top.addWidget(act)
            top.addWidget(keep_lab)
            top.addWidget(keep)
        dele = QPushButton("Delete rule")
        dele.setStyleSheet("background:#8a2a2a;color:white")
        dele.clicked.connect(self.delete_rule)
        top.addWidget(dele)
        v.addLayout(top)
        if r.is_section or spacer:
            lab = QLabel("A heading in the list - VTank never matches it.")
            lab.setStyleSheet("color:%s" % GREY)
            v.addWidget(lab)
            v.addStretch(1)
            self.edit_area.setWidget(w)
            return
        head = QLabel("<b style='color:%s'>Requirements - all must match</b>" % CYAN)
        v.addWidget(head)
        shown = 0
        for i, q in enumerate(r.reqs):
            if q.type == "9999":
                continue
            v.addWidget(ReqRowWidget(self, r, i))
            shown += 1
        if not shown:
            lab = QLabel("No requirements: this rule matches every item.")
            lab.setStyleSheet("color:%s" % GREY)
            v.addWidget(lab)
        add = QPushButton("+ Add requirement")
        add.setToolTip("Pick what the item should have - armor level, biting strike, a spell, a slot ...")
        add.clicked.connect(lambda: self.add_req(r))
        row = QHBoxLayout()
        row.addWidget(add)
        row.addStretch(1)
        v.addLayout(row)
        v.addStretch(1)
        self.edit_area.setWidget(w)

    def add_req(self, r):
        d = FieldPicker(self)
        if d.exec() and d.picked() is not None:
            nq = lm.from_row(lm.new_row(d.picked()))
            off = next((i for i, q in enumerate(r.reqs) if q.type == "9999"), -1)
            if off >= 0:
                r.reqs.insert(off, nq)    # keep the off switch last
            else:
                r.reqs.append(nq)
            self.changed()
            self.show_rule()

    def delete_rule(self):
        p = self.profile
        if p and 0 <= self.sel < len(p.rules):
            del p.rules[self.sel]
            self.sel = min(self.sel, len(p.rules) - 1)
            self.dirty = True
            self.fill_rules()

    def closeEvent(self, e):
        if self.dirty and QMessageBox.question(self, "Unsaved changes", "Close without saving %s?" % self.file) != QMessageBox.Yes:
            e.ignore()
            return
        e.accept()


def dark(app):
    """Dark, like the in-game editor."""
    from PySide6.QtGui import QPalette
    app.setStyle("Fusion")
    pal = QPalette()
    for role, c in ((QPalette.Window, "#1e1f24"), (QPalette.WindowText, "#e8e8e8"), (QPalette.Base, "#15161a"),
                    (QPalette.AlternateBase, "#24262c"), (QPalette.Text, "#e8e8e8"), (QPalette.Button, "#2c3240"),
                    (QPalette.ButtonText, "#e8e8e8"), (QPalette.Highlight, "#33507a"), (QPalette.HighlightedText, "#ffffff"),
                    (QPalette.ToolTipBase, "#2c3240"), (QPalette.ToolTipText, "#e8e8e8"), (QPalette.PlaceholderText, "#777777")):
        pal.setColor(role, QColor(c))
    app.setPalette(pal)


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("MelkTank Loot Editor")
    dark(app)
    w = LootEditor()
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
