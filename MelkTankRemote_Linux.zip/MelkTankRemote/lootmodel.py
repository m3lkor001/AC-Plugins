"""
VTank (VTClassic) .utl loot profiles, read and written exactly like MelkTank's in-game loot editor (UtlProfile.cs),
plus its friendly "rows" (LootFields.cs: ToRow / FromRow / RowSay) for the out-of-game editors.

A profile saved without changes is byte-for-byte the file that was opened; requirements you didn't touch keep their
exact text. The field list (loot_spec.json) is generated from MelkTank's own tables, so both editors offer the same fields.
T11+ rows (ILT mods, rends, cast on strike...) are built with the same patterns as the in-game editor.
"""
import json
import math
import os
import re
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(HERE, "loot_spec.json"), encoding="utf-8") as _f:
    SPEC = json.load(_f)

FIELDS = SPEC["fields"]
MAPS = {k: [tuple(p) for p in v] for k, v in SPEC["maps"].items()}
REQTYPES = {t["id"]: t for t in SPEC["reqtypes"]}
CATALOG = SPEC["catalog"]
OPNAMES = SPEC["opNames"]
INT_TYPE = {">=": "3", "<=": "2", "=": "12", "!=": "13", "flag": "11"}
DBL_TYPE = {">=": "5", "<=": "4"}
CLOAK_DR_KEY = 352
RING_SPELLS = [None, "Searing Disc", "Halo of Frost", "Cassius' Ring of Fire", "Eye of the Storm", "Clouded Soul",
               "Horizon's Blades", "Nuhmudira's Spines", "Tectonic Rifts"]
# the editor's action list (MelkTank's): Keep, Salvage, Sell, Keep up to, No loot, Chunk (User 1), Reveal (User 2)
ACT_IDS = ["1", "2", "3", "10", "0", "5", "6"]
ACT_NAMES = ["Keep", "Salvage", "Sell", "Keep up to", "No loot", "Chunk (hammer)", "Reveal (aetheria)"]


def js_num(s):
    if s is None:
        return 0.0
    s = str(s).strip()
    if not s:
        return 0.0
    try:
        d = float(s)
        return 0.0 if math.isnan(d) or math.isinf(d) else d
    except ValueError:
        return 0.0


def to_int(s):
    return int(math.floor(js_num(s)))


def action_name(act):
    if act in ACT_IDS:
        return ACT_NAMES[ACT_IDS.index(act)]
    try:
        a = int(act)
        if 0 <= a < len(SPEC["actions"]):
            return SPEC["actions"][a]
    except ValueError:
        pass
    return "Action " + str(act)


# ── the file ─────────────────────────────────────────────────────────

class Req:
    def __init__(self, type_, vals=None, lenstr=None, raw=None, dirty=False):
        self.type, self.vals, self.lenstr, self.raw, self.dirty = type_, vals, lenstr, raw, dirty

    @staticmethod
    def new(type_, *vals):
        return Req(type_, list(vals), dirty=True)


class Rule:
    def __init__(self, name="New rule", expr="", pri="0", act="1", keepn=None, reqs=None):
        self.name, self.expr, self.pri, self.act, self.keepn = name, expr, pri, act, keepn
        self.reqs = reqs if reqs is not None else []

    @property
    def off(self):
        return any(q.type == "9999" and q.vals and q.vals[0] == "true" for q in self.reqs)

    def set_off(self, off):
        q = next((x for x in self.reqs if x.type == "9999"), None)
        if not off:
            if q is not None:
                self.reqs.remove(q)
            return
        if q is not None:
            q.vals, q.dirty = ["true"], True
        else:
            self.reqs.append(Req.new("9999", "true"))

    @property
    def is_section(self):
        return self.name.lstrip().startswith("*")


class ParseError(Exception):
    pass


class Profile:
    def __init__(self):
        self.version, self.nl, self.rules, self.tail, self.bom = 1, "\r\n", [], "", False

    @staticmethod
    def load(path):
        with open(path, "rb") as f:
            b = f.read()
        bom = b[:3] == b"\xef\xbb\xbf"
        p = Profile.parse(b[3 if bom else 0:].decode("utf-8"))
        p.bom = bom
        return p

    @staticmethod
    def parse(text):
        p = Profile()
        p.nl = "\r\n" if "\r\n" in text else "\n"
        pos = [0]

        def line():
            if pos[0] >= len(text):
                raise ParseError("Unexpected end of file")
            i = text.find("\n", pos[0])
            if i < 0:
                ln, pos[0] = text[pos[0]:], len(text)
            else:
                ln, pos[0] = text[pos[0]:i], i + 1
            return ln[:-1] if ln.endswith("\r") else ln

        first = line()
        if first == "UTL":
            p.version = int(line())
            count = int(line())
        else:
            p.version = 0
            count = int(first)
        if count < 0:
            raise ParseError("Not a VTank .utl profile (bad rule count)")
        if p.version > 1:
            raise ParseError("Profile version %d - only version 1 is supported" % p.version)
        for _ in range(count):
            r = Rule()
            r.name = line()
            r.expr = line() if p.version >= 1 else ""
            parts = line().split(";")
            r.pri = parts[0]
            r.act = parts[1] if len(parts) > 1 else "0"
            r.keepn = line() if r.act == "10" else None
            for t in parts[2:]:
                q = Req(t)
                if p.version >= 1:
                    q.lenstr = line()
                start = pos[0]
                spec = REQTYPES.get(t)
                if spec is not None:
                    q.vals = [line() for _ in spec["fields"]]
                elif q.lenstr is not None:
                    pos[0] += int(q.lenstr)          # unknown type: skip by length, like VTClassic
                else:
                    raise ParseError("Unknown requirement type %s in a version-0 profile" % t)
                q.raw = text[start:pos[0]]
                r.reqs.append(q)
            p.rules.append(r)
        p.tail = text[pos[0]:]
        return p

    def serialize(self):
        nl = self.nl or "\r\n"
        up = self.version != 1
        out = ["UTL", nl, "1", nl, str(len(self.rules)), nl]
        for r in self.rules:
            out += [r.name, nl, r.expr or "", nl, ";".join([r.pri, r.act] + [q.type for q in r.reqs]), nl]
            if r.act == "10":
                out += [r.keepn or "1", nl]
            for q in r.reqs:
                if not q.dirty and q.lenstr is not None and q.raw is not None and not up:
                    out += [q.lenstr, nl, q.raw]
                    continue
                if q.vals is None:
                    out += [q.lenstr if q.lenstr is not None else str(len(q.raw)), nl, q.raw]
                    continue
                body = "".join(v + nl for v in q.vals)
                # VTClassic counts characters (C# string length); UTF-16 units for anything outside the BMP
                out += [str(len(body.encode("utf-16-le")) // 2), nl, body]
        out.append(self.tail)
        return "".join(out)

    def save(self, path):
        data = self.serialize().encode("utf-8")
        tmp = path + ".tmp"
        with open(tmp, "wb") as f:
            if self.bom:
                f.write(b"\xef\xbb\xbf")
            f.write(data)
        os.replace(tmp, path)
        for r in self.rules:
            for q in r.reqs:
                q.dirty = False
        self.version = 1


# ── friendly rows (LootFields.cs) ─────────────────────────────────────

def field_index(kind, key=None, type_=None):
    for i, f in enumerate(FIELDS):
        if f["kind"] == kind and (key is None or f["key"] == key) and (type_ is None or f["type"] == type_):
            return i
    return -1


ANY = {k: next(i for i, f in enumerate(FIELDS) if f["group"] == "Advanced" and f["key"] is None and f["kind"] == k)
       for k in ("int", "dbl", "str")}


def prop(kind, pid):
    p = CATALOG.get(kind, {}).get(str(pid))
    return p if p else {"label": "Property %d" % pid, "group": "", "pick": False, "sent": -1}


def cat_kind(f):
    return "double" if f["kind"] == "dbl" else "string" if f["kind"] == "str" else "int"


NEW_PROCS = ["Calming Breeze", "Smoke Screen", "Artful Dodger", "Asheron's Grace"]   # the T11+ cloak procs since the patch


def ring_pattern(el):
    if 0 < el < len(RING_SPELLS):
        return "^" + RING_SPELLS[el] + "$"
    return "^(" + "|".join(RING_SPELLS[1:]) + ")$"


def cloak_pattern(kind, el):
    if kind == 0: return "^Shroud of Darkness \\(Melee\\)$"
    if kind == 1: return "^Shroud of Darkness \\(Missile\\)$"
    if kind == 2: return "^Shroud of Darkness \\(Magic\\)$"
    if kind == 3: return "^Shroud of Darkness \\((Melee|Missile|Magic)\\)$"
    if kind == 5: return "^Cloaked in Skill$"
    if kind == 6: return ring_pattern(el)
    if kind == 7:
        r = ring_pattern(0)
        return "^(Shroud of Darkness \\((Melee|Missile|Magic)\\)|Cloaked in Skill|" + r[2:-2] + ")$"
    if 8 <= kind <= 11:
        return "^" + NEW_PROCS[kind - 8] + "$"
    if kind == 12:
        return "^(" + "|".join(NEW_PROCS) + ")$"
    return None


def read_cloak_pattern(p):
    for kind in range(len(SPEC["cloakKinds"])):
        if kind == 6:
            for el in range(len(SPEC["cloakElements"])):
                if ring_pattern(el) == p:
                    return kind, el
            continue
        if cloak_pattern(kind, 0) == p:
            return kind, 0
    return None


# ── T11+ pattern builders: the same text as the in-game editor (LootFields.cs), character for character ──

LINE = "(?:^|\\n)- "


def js_round(d):
    return math.floor(d + 0.5)


def int_ge(n):
    """Regex for a whole number >= n."""
    n = max(0, math.floor(js_num(n) if isinstance(n, str) else n))
    if n == 0:
        return "\\d+"
    s = str(int(n))
    L = len(s)
    alts = ["[1-9]\\d{" + str(L) + ",}"]
    for i in range(L):
        d = ord(s[i]) - 48
        if d < 9:
            rest = L - i - 1
            alts.append(s[:i] + ("9" if d + 1 == 9 else "[" + str(d + 1) + "-9]") +
                        (("\\d" if rest == 1 else "\\d{" + str(rest) + "}") if rest > 0 else ""))
    alts.append(s)
    return "(?:" + "|".join(alts) + ")"


def dec_ge(t):
    """Regex for a number with up to 2 decimals >= t."""
    T = int(max(0, js_round(js_num(t) * 100)))
    ip, fp = T // 100, T % 100
    frac = "(?:\\.\\d{1,2})?"
    alts = [int_ge(ip + 1) + frac]
    if fp == 0:
        alts.append(str(ip) + frac)
    else:
        d1, d2 = fp // 10, fp % 10
        f = []
        if d1 < 9:
            f.append("\\." + ("9" if d1 + 1 == 9 else "[" + str(d1 + 1) + "-9]") + "\\d?")
        f.append("\\." + str(d1) + "\\d?" if d2 == 0 else "\\." + str(d1) + ("9" if d2 == 9 else "[" + str(d2) + "-9]"))
        alts.append(str(ip) + "(?:" + "|".join(f) + ")")
    return "(?:" + "|".join(alts) + ")"


def esc(s):
    """JS-style escape: . * + ? ^ $ { } ( ) | [ ] \\ only (not spaces or #)."""
    return "".join("\\" + c if c in ".*+?^${}()|[]\\" else c for c in (s or ""))


def tag_enc(s):
    out = []
    for x in (s or "").encode("utf-8"):
        c = chr(x)
        out.append(c if x < 128 and (c.isalnum() or c in "-_.!~*'") else "%%%02X" % x)
    return "".join(out)


def mod_by_key(k):
    n = math.floor(js_num(k))
    return next((m for m in SPEC["mods"] if m["key"] == n), None)


def gear_grade_pattern(mn):
    grades = SPEC["gearGrades"]
    m = "C" if not mn else mn[0].upper()
    at = grades.index(m) if m in grades else 0
    return LINE + "(?:Gear )?Grade: [" + "".join(grades[at:]) + "][+\\-]?(?![A-Za-z0-9])"


def mod_pattern(mod, mn):
    if not mod.get("fmt"):
        return LINE + esc(mod["name"]) + "(?=\\r?\\n|$)"
    v = js_round(js_num(mn) * 10) if mod.get("tenths") else js_num(mn)
    fmt = mod["fmt"]
    at = fmt.index("{0}")
    return LINE + esc(mod["name"]) + " " + esc(fmt[:at]) + int_ge(v) + "(?!\\d)" + esc(fmt[at + 3:])


def p_get(p, k):
    for kv in p or []:
        if kv[0] == k:
            return kv[1]
    return None


def p_set(p, k, v):
    """Replaces the setting in place (keeps the order) or adds it at the end - like the in-game editor."""
    for i, kv in enumerate(p):
        if kv[0] == k:
            p[i] = [k, v]
            return
    p.append([k, v])


def t11_body(tid, p):
    v = p_get(p, "v")
    if tid == "biting": return LINE + "Biting Strike: \\+" + int_ge(v) + "(?!\\d)\\s?%"
    if tid == "crush": return LINE + "Crushing Blow: " + dec_ge(v) + "x"
    if tid == "rend":
        # the game writes nether as "Void Rending" - the picker says Nether, so match either word
        el = p_get(p, "el")
        word = "\\w+" if not el else "(?:Void|Nether)" if el.lower() in ("nether", "void") else esc(el)
        return LINE + word + " Rending: \\+" + int_ge(v) + "(?!\\d)\\s?%"
    if tid == "slayer":
        sp = p_get(p, "sp")
        return LINE + (esc(sp) if sp else "[^\\n:]+") + " Slayer: " + dec_ge(v) + "x"
    if tid == "cleave": return LINE + "Cleaving: \\+" + int_ge(v) + "(?!\\d) Targets"
    if tid == "spellrend": return LINE + "Spell Armor Rend: " + int_ge(v) + "(?!\\d)\\s?%"
    if tid == "armorcl": return LINE + "Armor Cleaving: " + int_ge(v) + "(?!\\d)\\s?%"
    if tid == "shieldcl": return LINE + "Shield Cleaving: " + int_ge(v) + "(?!\\d)\\s?%"
    if tid == "split": return LINE + "Split Arrow: \\+" + int_ge(v) + "(?!\\d) Targets"
    if tid == "proc":
        n = p_get(p, "name")
        return LINE + "Cast on Strike: " + ("[^\\n]*" + esc(n) if n else "")
    if tid == "modcount": return "Modifiers:\\n(?:- [^\\n]*(?:\\r?\\n|$)){" + str(max(1, int(math.floor(js_num(v))))) + "}"
    if tid == "mod": return mod_pattern(mod_by_key(p_get(p, "k")) or SPEC["mods"][0], v)
    if tid == "gear": return gear_grade_pattern(p_get(p, "g"))
    return ""


def t11_pattern(tid, p):
    head = "(?#T11 " + tid + "".join(" " + kv[0] + "=" + tag_enc(kv[1]) for kv in (p or []) if kv[1]) + ")"
    return head + t11_body(tid, p)


T11_HEAD = re.compile(r"^\(\?#T11 ([A-Za-z0-9_]+)([^)]*)\)")


def read_t11(rx):
    m = T11_HEAD.match(rx or "")
    if not m or m.group(1) not in SPEC["t11"]:
        return None
    pairs = []
    for kv in m.group(2).split():
        k, _, v = kv.partition("=")
        try:
            v = urllib.parse.unquote(v)
        except Exception:
            pass
        pairs.append([k, v])
    return m.group(1), pairs


def _rating_index(key):
    return SPEC["ratingKeys"].index(key) if key in SPEC["ratingKeys"] else -1


def to_row(q):
    """The requirement as an editor row: {"f": field index, "key", "op", "v": [...], "p": [...], "where", "ro"}.
    None for a requirement type nobody knows (kept as is)."""
    if q.vals is None:
        return None
    v = q.vals
    V = lambda i: v[i] if i < len(v) else ""
    T = q.type
    row = {"f": -1, "key": None, "op": None, "v": [], "p": [], "where": None, "ro": False}
    if T == "12" and to_int(V(1)) == CLOAK_DR_KEY and to_int(V(0)) == 2:
        row.update(f=field_index("cloakspell"), v=["4", "0"]); return row
    if T == "0":
        ck = read_cloak_pattern(V(0))
        if ck:
            row.update(f=field_index("cloakspell"), v=[str(ck[0]), str(ck[1])]); return row
    int_op = {"3": ">=", "2": "<=", "12": "=", "13": "!=", "11": "flag"}.get(T)
    if T == "3" and _rating_index(to_int(V(1))) >= 0:
        row.update(f=field_index("aethrating"), key=to_int(V(1)), op=">=", v=[V(0)]); return row
    if int_op:
        key = to_int(V(1))
        fi = field_index("int", key)
        row.update(f=fi if fi >= 0 else ANY["int"], key=key, op=int_op, v=[V(0)]); return row
    if T in ("5", "4"):
        key = to_int(V(1))
        fi = field_index("dbl", key)
        row.update(f=fi if fi >= 0 else ANY["dbl"], key=key, op=">=" if T == "5" else "<=", v=[V(0)]); return row
    if T == "1":
        t = read_t11(V(0))
        if t:
            tid, pairs = t
            k = next((val for kk, val in pairs if kk == "k"), None)
            fi = next((i for i, f in enumerate(FIELDS) if f["kind"] == "t11" and f["t11"] == tid and
                       (tid != "mod" or f["modk"] == to_int(k))), -1)
            if fi >= 0:
                row.update(f=fi, p=pairs, where=V(1)); return row
        key = to_int(V(1))
        fi = field_index("str", key)
        row.update(f=fi if fi >= 0 else ANY["str"], key=key, op="matches", v=[V(0)]); return row
    simple = {"7": ("oclass", None), "0": ("spellname", None), "8": ("spellcount", ">="), "1001": ("packslots", ">=")}
    if T in simple:
        kind, op = simple[T]
        row.update(f=field_index(kind), op=op, v=[V(0)]); return row
    if T == "9":
        row.update(f=field_index("spells"), v=list(v)); return row
    if T in ("1002", "1003"):
        row.update(f=field_index("charlvl"), op=">=" if T == "1002" else "<=", v=[V(0)]); return row
    if T == "1000":
        row.update(f=field_index("charskill"), op=">=", v=[V(0), V(1)]); return row
    if T == "1004":
        row.update(f=field_index("charbase"), v=list(v)); return row
    fi = field_index("calc", type_=T)
    if fi >= 0:
        row.update(f=fi, op=">=", v=[V(0)]); return row
    fi = field_index("raw", type_=T)
    if fi >= 0:
        row.update(f=fi, v=list(v)); return row
    row.update(f=-1, v=list(v), rawtype=T)     # a requirement type with no field: shown by its type name
    return row


def new_row(fi):
    f = FIELDS[fi]
    row = {"f": fi, "key": f["key"] if f["key"] is not None else (159 if f["kind"] == "dbl" else 16 if f["kind"] == "str" else 28),
           "op": f["ops"][0] if f["ops"] else ">=", "v": [], "p": [], "where": None, "ro": False}
    k = f["kind"]
    defaults = {"grade": "800", "slot": "2097152", "material": "64", "dmgtype": "16", "skill": "46", "mastery": "1",
                "attack": "31200", "heritage": "1", "charm": "50000", "petstat": "1", "imbue": "17400", "unench": "9999"}
    if k in ("int", "dbl"): row["v"] = [defaults.get(f["vk"], "0")]
    if k == "str": row.update(op="matches", v=[""])
    if k == "t11":
        tid, d = f["t11"], SPEC["t11"][f["t11"]]
        if tid == "mod":
            m = mod_by_key(f["modk"])
            p_set(row["p"], "k", str(f["modk"]))
            if m and m.get("fmt"):
                b = (m.get("band") or "0-0").split("-")
                mid = js_round((js_num(b[0]) + js_num(b[1])) / 2)
                p_set(row["p"], "v", "5" if m.get("tenths") else str(int(mid)) if mid == int(mid) else repr(mid))
        elif tid == "gear":
            p_set(row["p"], "g", "C")
        elif not d["novalue"]:
            p_set(row["p"], "v", d["def"])
        row["where"] = d["where"]
    if k == "oclass": row["v"] = ["2"]
    if k == "spellname": row["v"] = [""]
    if k == "cloakspell": row["v"] = ["0", "0"]
    if k == "spells": row["v"] = ["Legendary", "", "1"]
    if k in ("spellcount", "packslots", "charlvl"): row["v"] = ["1"]
    if k == "calc": row["v"] = ["0"]
    if k == "aethrating": row.update(op=">=", v=["1"])
    if k == "charskill": row["v"] = ["0", "6"]
    if k == "charbase": row["v"] = ["6", "0", "999"]
    if k == "raw":
        rt = REQTYPES.get(f["type"])
        row["v"] = ["0"] * (len(rt["fields"]) if rt else 0)
    return row


def from_row(row):
    """The row as a file requirement (new, dirty)."""
    fi = row.get("f", -1)
    v = row.get("v") or []
    V = lambda i, d: v[i] if i < len(v) and v[i] is not None else d
    if fi < 0:
        return Req.new(row.get("rawtype", "0"), *[str(x) for x in v])
    f = FIELDS[fi]
    key = row.get("key")
    key = str(key) if key is not None else (str(f["key"]) if f["key"] is not None else None)
    op = row.get("op") or ""
    k = f["kind"]
    if k == "int": return Req.new(INT_TYPE.get(op, "3"), V(0, "0"), key or "28")
    if k == "aethrating": return Req.new("3", V(0, "1"), key or "372")
    if k == "t11":
        return Req.new("1", t11_pattern(f["t11"], row.get("p") or []), row.get("where") or SPEC["t11"][f["t11"]]["where"])
    if k == "dbl": return Req.new(DBL_TYPE.get(op, "5"), V(0, "0"), key or "159")
    if k == "str": return Req.new("1", V(0, ""), key or "1")
    if k == "oclass": return Req.new("7", V(0, "2"))
    if k == "spellname": return Req.new("0", V(0, ""))
    if k == "cloakspell":
        ck, ce = to_int(V(0, "0")), to_int(V(1, "0"))
        if ck == 4:
            return Req.new("12", "2", str(CLOAK_DR_KEY))
        return Req.new("0", cloak_pattern(ck, ce) or cloak_pattern(7, 0))
    if k == "spells": return Req.new("9", V(0, ""), V(1, ""), V(2, "1"))
    if k == "spellcount": return Req.new("8", V(0, "1"))
    if k == "charlvl": return Req.new("1003" if op == "<=" else "1002", V(0, "1"))
    if k == "charskill": return Req.new("1000", V(0, "0"), V(1, "6"))
    if k == "charbase": return Req.new("1004", V(0, "6"), V(1, "0"), V(2, "999"))
    if k == "packslots": return Req.new("1001", V(0, "1"))
    if k == "calc": return Req.new(f["type"], V(0, "0"))
    rt = REQTYPES.get(f["type"])
    vals = [V(i, "0") for i in range(len(rt["fields"]))] if rt else [str(x) for x in v]
    return Req.new(f["type"], *vals)


def map_text(vk, x):
    m = MAPS.get(vk) if vk else None
    if not m:
        return x
    if vk == "grade":
        n = js_num(x)
        for key, val in m:
            if n >= js_num(key):
                return val[0] + " (" + x + ")"
        return "F (" + x + ")"
    for key, val in m:
        if key == x:
            return val
    return x


def field_label(row):
    f = FIELDS[row["f"]]
    if f.get("any") and row.get("key") is not None:
        return prop(cat_kind(f), row["key"])["label"]
    return f["label"]


def skill_name(x):
    t = map_text("skill", x)
    return "Skill " + x if t == x else t


def row_say(row):
    """The requirement in plain words: "Armor Level at least 500"."""
    v = row.get("v") or []
    V = lambda i: v[i] if i < len(v) else ""
    if row.get("f", -1) < 0:
        rt = REQTYPES.get(row.get("rawtype"))
        return (rt["name"] if rt else "Unknown requirement " + str(row.get("rawtype"))) + (": " + ", ".join(v) if v else "")
    f = FIELDS[row["f"]]
    op = OPNAMES.get(row.get("op") or "", "")
    k = f["kind"]
    if k in ("int", "dbl"): return field_label(row) + " " + op + " " + map_text(f["vk"], V(0))
    if k == "str": return field_label(row) + " matches " + V(0)
    if k == "t11":
        p = dict(row.get("p") or [])
        val = p.get("v", "")
        tid = f["t11"]
        if tid == "mod":
            m = next((x for x in SPEC["mods"] if str(x["key"]) == p.get("k")), SPEC["mods"][0])
            return (m["name"] + " at least " + val + (m["unit"] or "")) if m["fmt"] else "Has " + m["name"]
        if tid == "modcount": return "At least " + val + " modifier lines"
        if tid == "gear": return "Gear Grade at least " + (p.get("g") or "C")
        if tid == "proc":
            n = p.get("name")
            return "Cast on Strike" + (": " + n if n else " (any)")
        d = SPEC["t11"][tid]
        opt = p.get("el") or p.get("sp") or ""
        unit = d["unit"] or ""
        return d["label"] + (" (" + opt + ")" if opt else "") + " at least " + val + ("" if unit.startswith("%") or unit.startswith("x") else " ") + unit
    if k == "oclass":
        c = to_int(V(0))
        oc = SPEC["objectClasses"]
        return "Item type is " + (oc[c] if 0 <= c < len(oc) else V(0))
    if k == "spellname": return "Has a spell named like " + V(0)
    if k == "cloakspell":
        ck, ce = to_int(V(0)), to_int(V(1))
        kinds, els = SPEC["cloakKinds"], SPEC["cloakElements"]
        if not 0 <= ck < len(kinds): ck = 0
        if not 0 <= ce < len(els): ce = 0
        if ck == 6: return "Cloak spell: Ring Spell (" + ("any element" if ce == 0 else els[ce]) + ")"
        return "Cloak spell: " + kinds[ck]
    if k == "spells": return "At least " + V(2) + " spell(s) like " + V(0) + (", not " + V(1) if V(1) else "")
    if k == "spellcount": return "At least " + V(0) + " spells"
    if k == "charlvl": return "Character level " + op + " " + V(0)
    if k == "charskill": return skill_name(V(1)) + " skill at least " + V(0)
    if k == "charbase": return skill_name(V(0)) + " base skill " + V(1) + " to " + V(2)
    if k == "packslots": return "At least " + V(0) + " free main pack slots"
    if k == "calc": return f["label"] + " at least " + V(0)
    if k == "aethrating":
        ri = _rating_index(row.get("key") if row.get("key") is not None else 372)
        return "Rating " + ((SPEC["ratingNames"][ri] + " (" + SPEC["ratingCodes"][ri] + ")") if ri >= 0 else "?") + " at least " + V(0)
    return f["label"] + (": " + ", ".join(v) if v else "")


# ── JSON for the phone (and anything else that edits over the web API) ─────

def req_json(q):
    row = to_row(q)
    return {"type": q.type, "vals": q.vals, "lenstr": q.lenstr, "raw": q.raw, "dirty": q.dirty,
            "row": row, "say": row_say(row) if row else "Unknown requirement " + q.type, "off": q.type == "9999",
            "label": field_label(row) if row and row.get("f", -1) >= 0 else ""}


def row_req_json(d):
    """The phone's requirement editor: {"f": field} = a new requirement, {"row": {...}} = an edited one.
    Answers the requirement as the file will have it (type, vals), with its row and words."""
    if d.get("row") is not None:
        return req_json(from_row(d["row"]))
    return req_json(from_row(new_row(int(d["f"]))))


def profile_json(p, name, mtime):
    return {"name": name, "mtime": mtime, "version": p.version, "nl": p.nl, "tail": p.tail, "bom": p.bom,
            "rules": [{"name": r.name, "expr": r.expr, "pri": r.pri, "act": r.act, "keepn": r.keepn,
                       "off": r.off, "section": r.is_section, "actName": action_name(r.act),
                       "reqs": [req_json(q) for q in r.reqs]} for r in p.rules]}


def profile_from_json(d):
    """Back from the phone. A requirement with "row" changed (edited=true) is rebuilt from the row; the rest keep
    their exact text."""
    p = Profile()
    p.version, p.nl, p.tail, p.bom = d.get("version", 1), d.get("nl", "\r\n"), d.get("tail", ""), d.get("bom", False)
    for rj in d.get("rules", []):
        r = Rule(rj.get("name", ""), rj.get("expr", ""), rj.get("pri", "0"), rj.get("act", "1"), rj.get("keepn"))
        if r.act == "10" and not r.keepn:
            r.keepn = "1"
        for qj in rj.get("reqs", []):
            if qj.get("edited") and qj.get("row") is not None:
                r.reqs.append(from_row(qj["row"]))
            else:
                r.reqs.append(Req(qj["type"], qj.get("vals"), qj.get("lenstr"), qj.get("raw"), bool(qj.get("dirty"))))
        if rj.get("setOff") is not None:
            r.set_off(bool(rj["setOff"]))
        p.rules.append(r)
    return p
