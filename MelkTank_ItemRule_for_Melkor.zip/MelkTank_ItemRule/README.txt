MelkTank b642 + Pack Organizer "Item" rule
Only Src/PackOrganizer.cs changed (BuildInfo.Time was tagged "+WCID test"
for the test build only - not part of the patch).

FILES
  REQUEST.txt                         the feature request
  PackOrganizer_item.patch            unified diff against b642's PackOrganizer.cs
  PackOrganizer.cs                    the whole changed file
  MelkTankCore_b642_ItemRule_test.dll the retail build I tested (b642 + this)

THE CHANGE
- Kind.Template added at the END of the enum (= 6), so saved rules keep
  their numbers. Shown as "Item".
- KindOrder / KindShownNames: the combo shows Item first; _newKind still
  holds the Kind's own number (Remote's "kinds" list is unchanged order).
- _newKind defaults to Kind.Template.
- Rule.Text for Item rules: "#objectid:name|..." (names are labels only).
  Parsed once per text into a cached HashSet (ObjectIds). Plain
  "wcid:name" entries (from my earlier WCID test) still match by WCID via
  TemplateOf(wo) = wo.Values((LongValueKey)218103808), else wo.Type.
- Editor: "add sel" button + a BeginCombo dropdown of the added items, each
  with an x to remove - keeps the editor on one line.
- Describe(): just the item names.
- ItemFirst(rules): Item rules are tried before the others in both places
  that pick a rule for an item (Step and the single-item move), each group
  keeping its own order.

Not done: the ACGodot build (same source - it should just build), and
MelkTank Remote's rule editor (it gets the new "Item" name in "kinds" but
has no add-selected for it).
