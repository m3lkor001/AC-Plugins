"""
winplat - the Windows side of mtcore.

mtcore was written for Linux (the game under Wine, X11 windows, /proc). On Windows, mtcore calls
patch(globals()) at the end of its module, which swaps in these versions:

    folders        %APPDATA%\\MelkTank (settings, logs); the plugin folder comes from config "plugin_dir"
    processes      psutil instead of /proc
    game windows   user32 (find by process id, focus, move, real key presses and clicks with SendInput)
    screenshot     Pillow's ImageGrab
    Wine           not used: programs run directly
"""

import ctypes
import json
import os
import re
import subprocess
import sys
import time

if os.name != "nt":
    raise ImportError("winplat is only for Windows")

from ctypes import wintypes

import psutil

user32 = ctypes.WinDLL("user32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

HWND = wintypes.HWND
ULONG_PTR = ctypes.c_size_t
CREATE_NO_WINDOW = 0x08000000


# ── small Windows helpers ───────────────────────────────────────────

class _Quiet(subprocess.Popen):
    """Programs started without a console window flashing up (the service runs with pythonw)."""
    def __init__(self, *a, **kw):
        kw.pop("start_new_session", None)
        if not kw.get("creationflags"):
            kw["creationflags"] = CREATE_NO_WINDOW
        super().__init__(*a, **kw)


_real_replace = os.replace


def _replace(src, dst, *a, **kw):
    """os.replace that waits a moment when the plugin has the file open (Windows won't swap an open file)."""
    for i in range(20):
        try:
            return _real_replace(src, dst, *a, **kw)
        except PermissionError:
            if i == 19:
                raise
            time.sleep(0.05)


_dpi_done = [False]


def _dpi():
    """Screen pixels, not scaled ones (so screenshots and clicks line up at 125% / 150% scaling)."""
    if _dpi_done[0]:
        return
    _dpi_done[0] = True
    try:
        user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))   # per monitor v2
    except Exception:
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            pass


class RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long), ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


class MONITORINFO(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", RECT), ("rcWork", RECT), ("dwFlags", wintypes.DWORD)]


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", ctypes.c_long), ("dy", ctypes.c_long), ("mouseData", wintypes.DWORD),
                ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]


class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]


class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD), ("wParamH", wintypes.WORD)]


class _INPUTU(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT)]


class INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("u", _INPUTU)]


user32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int]
user32.GetWindowThreadProcessId.argtypes = [HWND, ctypes.POINTER(wintypes.DWORD)]
user32.GetWindowThreadProcessId.restype = wintypes.DWORD
user32.GetWindowTextW.argtypes = [HWND, wintypes.LPWSTR, ctypes.c_int]
user32.IsWindowVisible.argtypes = [HWND]
user32.IsIconic.argtypes = [HWND]
user32.ShowWindow.argtypes = [HWND, ctypes.c_int]
user32.SetForegroundWindow.argtypes = [HWND]
user32.BringWindowToTop.argtypes = [HWND]
user32.GetForegroundWindow.restype = HWND
user32.GetWindowRect.argtypes = [HWND, ctypes.POINTER(RECT)]
user32.GetClientRect.argtypes = [HWND, ctypes.POINTER(RECT)]
user32.SetWindowPos.argtypes = [HWND, HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT]
user32.MonitorFromWindow.argtypes = [HWND, wintypes.DWORD]
user32.MonitorFromWindow.restype = ctypes.c_void_p
user32.GetMonitorInfoW.argtypes = [ctypes.c_void_p, ctypes.POINTER(MONITORINFO)]
user32.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
user32.FindWindowW.restype = HWND
user32.GetShellWindow.restype = HWND
user32.PostMessageW.argtypes = [HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
user32.AttachThreadInput.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.BOOL]
user32.MapVirtualKeyW.argtypes = [wintypes.UINT, wintypes.UINT]
user32.GetSystemMetrics.argtypes = [ctypes.c_int]
user32.SetCursorPos.argtypes = [ctypes.c_int, ctypes.c_int]
_ENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, HWND, wintypes.LPARAM)
user32.EnumWindows.argtypes = [_ENUMPROC, wintypes.LPARAM]


def _title(hwnd):
    buf = ctypes.create_unicode_buffer(512)
    user32.GetWindowTextW(hwnd, buf, 512)
    return buf.value


def _windows_of(pids):
    """Visible top-level windows of these processes: [(hwnd, title)]."""
    found = []

    def cb(hwnd, _):
        if user32.IsWindowVisible(hwnd):
            pid = wintypes.DWORD()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if pid.value in pids:
                found.append((hwnd, _title(hwnd)))
        return True
    user32.EnumWindows(_ENUMPROC(cb), 0)
    return found


def _send_input(*inputs):
    arr = (INPUT * len(inputs))(*inputs)
    return user32.SendInput(len(inputs), arr, ctypes.sizeof(INPUT))


def _key_input(vk, up=False):
    i = INPUT()
    i.type = 1   # keyboard
    i.u.ki.wScan = user32.MapVirtualKeyW(vk, 0)
    i.u.ki.dwFlags = 0x0008 | (0x0002 if up else 0)   # scan code (the game reads DirectInput), key up
    return i


def _mouse_input(flags):
    i = INPUT()
    i.type = 0
    i.u.mi.dwFlags = flags
    return i


def _focus(hwnd):
    """Brings a window to the front with the keyboard focus (Windows only lets the foreground app do that, so the
    input of the current foreground window is borrowed for a moment)."""
    if user32.IsIconic(hwnd):
        user32.ShowWindow(hwnd, 9)   # SW_RESTORE
    fg = user32.GetForegroundWindow()
    if fg == hwnd:
        return True
    me = kernel32.GetCurrentThreadId()
    other = user32.GetWindowThreadProcessId(fg, None) if fg else 0
    attached = bool(other and other != me and user32.AttachThreadInput(me, other, True))
    try:
        user32.BringWindowToTop(hwnd)
        ok = user32.SetForegroundWindow(hwnd)
    finally:
        if attached:
            user32.AttachThreadInput(me, other, False)
    if not ok or user32.GetForegroundWindow() != hwnd:
        _send_input(_key_input(0x12), _key_input(0x12, True))   # a tap of Alt unlocks SetForegroundWindow
        user32.SetForegroundWindow(hwnd)
    return user32.GetForegroundWindow() == hwnd


def _frame(hwnd):
    """(window rect, visible frame rect): Windows 10/11 windows have invisible borders around the visible frame."""
    r = RECT()
    user32.GetWindowRect(hwnd, ctypes.byref(r))
    v = RECT()
    try:
        if ctypes.windll.dwmapi.DwmGetWindowAttribute(hwnd, 9, ctypes.byref(v), ctypes.sizeof(v)) != 0:
            v = r
    except Exception:
        v = r
    return r, v


def _work_area(hwnd):
    mi = MONITORINFO()
    mi.cbSize = ctypes.sizeof(MONITORINFO)
    user32.GetMonitorInfoW(user32.MonitorFromWindow(hwnd, 2), ctypes.byref(mi))   # nearest monitor
    return mi.rcWork


def _place(hwnd, left, top):
    """Moves a window so its visible frame's top-left corner is at (left, top)."""
    user32.ShowWindow(hwnd, 9)   # un-maximise
    r, v = _frame(hwnd)
    user32.SetWindowPos(hwnd, None, int(left) - (v.left - r.left), int(top) - (v.top - r.top), 0, 0,
                        0x0001 | 0x0004)   # no size, no z-order


_KEYS = {"return": 0x0D, "enter": 0x0D, "escape": 0x1B, "esc": 0x1B, "space": 0x20, "tab": 0x09,
         "backspace": 0x08, "delete": 0x2E, "up": 0x26, "down": 0x28, "left": 0x25, "right": 0x27}


def _vk(key):
    k = (key or "").strip()
    if len(k) == 1:
        return ord(k.upper())
    m = re.match(r"^[Ff](\d{1,2})$", k)
    if m and 1 <= int(m.group(1)) <= 24:
        return 0x6F + int(m.group(1))
    return _KEYS.get(k.lower(), 0)


# ── patch ───────────────────────────────────────────────────────────

def patch(g):
    """Replaces mtcore's Linux parts (g = mtcore's globals())."""
    subprocess.Popen = _Quiet
    os.replace = _replace

    appdata = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Roaming")
    base = os.path.join(appdata, "MelkTank")
    g["CONFIG_DIR"] = base
    g["CONFIG_PATH"] = os.path.join(base, "config.json")
    g["LOG_DIR"] = os.path.join(base, "logs")
    g["LOG_PATH"] = os.path.join(g["LOG_DIR"], "launcher.log")
    g["EVENTS_PATH"] = os.path.join(g["LOG_DIR"], "client_events.jsonl")

    log = g["log"]
    _ACCT_RE = g["_ACCT_RE"]
    sysdrive = (os.environ.get("SystemDrive") or "C:") + "\\"

    # the defaults that fit a Windows PC
    d = g["DEFAULT_CONFIG"]
    d["plugin_dir"] = "C:\\Games\\Decal Plugins\\MelksTank"
    d["wine"]["wine_path"] = ""
    d["wine"]["prefix"] = ""
    for pf in ("C:\\Program Files (x86)", "C:\\Program Files"):
        inj = pf + "\\Thwargle Games\\ThwargLauncher\\injector.dll"
        if os.path.isfile(inj):
            d["injector"] = inj
            break
    else:
        d["injector"] = "C:\\Program Files (x86)\\Thwargle Games\\ThwargLauncher\\injector.dll"

    # ── folders ──
    def drive_c(cfg):
        return sysdrive

    def win_to_unix(cfg, path):
        return path

    def plugin_dir(cfg):
        return cfg.get("plugin_dir") or d["plugin_dir"]

    def remote_dir(cfg):
        # the plugin's own rule: ...\Decal Plugins\MelksTank -> ...\MelkTankRemote
        r = os.path.join(os.path.dirname(os.path.dirname(os.path.normpath(plugin_dir(cfg)))), "MelkTankRemote")
        os.makedirs(r, exist_ok=True)
        return r

    def thwarg_appdata(cfg):
        p = os.path.join(appdata, "ThwargLauncher")
        return p if os.path.isdir(p) else None

    def wine_command(cfg):
        return []

    def wine_env(cfg):
        return dict(os.environ)

    def check_setup(cfg):
        problems = []
        if not os.path.isfile(cfg["client"]):
            problems.append("acclient.exe not found: " + cfg["client"])
        if not os.path.isdir(plugin_dir(cfg)):
            problems.append("MelkTank's plugin folder not found: %s (Settings > Game setup)." % plugin_dir(cfg))
        if cfg.get("use_decal", True):
            if not os.path.isfile(cfg["injector"]):
                problems.append("ThwargLauncher's injector.dll not found: " + cfg["injector"])
            if not os.path.isfile(g["helper_unix"](cfg)):
                problems.append("mtlaunch.exe isn't in " + remote_dir(cfg) + " (run setup.bat again).")
        return problems

    # ── processes ──
    def _client_procs():
        out = []
        for p in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                if (p.info["name"] or "").lower() != "acclient.exe":
                    continue
                out.append((p.info["pid"], " ".join(p.info["cmdline"] or [])))
            except (psutil.Error, TypeError):
                continue
        return out

    def _ppid(pid):
        try:
            return psutil.Process(pid).ppid()
        except psutil.Error:
            return 0

    def client_memory():
        out = {}
        for pid, cmd in _client_procs():
            m = _ACCT_RE.search(cmd)
            if not m:
                continue
            try:
                mi = psutil.Process(pid).memory_info()
            except psutil.Error:
                continue
            acct = m.group(1)
            if mi.rss > out.get(acct, (0, 0))[0]:
                out[acct] = (mi.rss, mi.vms)
        return out

    def decal_agent_pids():
        out = []
        for p in psutil.process_iter(["pid", "name"]):
            if (p.info["name"] or "").lower() == "denagent.exe":
                out.append(p.info["pid"])
        return out

    def start_decal_agent(cfg):
        path = g["decal_agent_path"](cfg)
        if not path:
            return False, "Decal's agent (DenAgent.exe) wasn't found in the Decal folder."
        try:
            subprocess.Popen([path], cwd=os.path.dirname(path), stdin=subprocess.DEVNULL,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=0)
        except OSError as ex:
            return False, "Couldn't start Decal's agent: %s" % ex
        log("decal agent: started %s" % path)
        return True, "Started Decal's agent."

    def reset_game(cfg):
        procs = _client_procs()
        for pid, _ in procs:
            g["_kill_pid"](pid, True)
        time.sleep(1)
        left = len(_client_procs())
        for a in cfg["accounts"]:
            g["_mark_closed"](cfg, a["account"], "Reset from the phone")
            le = g["last_event"](a["account"])
            if le and le.get("kind") not in g["ENDS_RUN"] and le.get("kind") not in ("stuck", "gave_up", "launch_failed"):
                g["event"](a["account"], "reset", "Game reset (every client closed)")
        log("reset game: killed %d client process(es), %d left" % (len(procs), left))
        if left:
            return False, "Closed %d game process(es), but %d are still running." % (len(procs), left)
        return True, "Closed %d game process(es)." % len(procs)

    def _kill_pid(pid, force=False):
        try:
            p = psutil.Process(pid)
            p.kill() if force else p.terminate()
        except psutil.Error:
            pass

    def _pid_alive(pid):
        try:
            return psutil.Process(pid).status() != psutil.STATUS_ZOMBIE
        except psutil.Error:
            return False

    # ── the screen ──
    def screen_asleep():
        return None, ""

    def wake_screen(log_result=False):
        try:
            kernel32.SetThreadExecutionState(ctypes.c_uint(0x00000002 | 0x00000001))   # display + system required
            _send_input(_mouse_input(0x0001))   # a mouse move of 0 pixels counts as activity
            if log_result:
                log("wake screen: ok")
        except Exception as ex:
            if log_result:
                log("wake screen failed: %s" % ex)

    orig_shot = g["screenshot"]

    def screenshot():
        _dpi()
        wake_screen()
        time.sleep(1)
        try:
            import io
            from PIL import Image, ImageGrab
            img = ImageGrab.grab(all_screens=True).convert("RGB")
            if img.width > 2400:
                img = img.resize((2400, int(img.height * 2400 / img.width)), Image.LANCZOS)
            buf = io.BytesIO()
            img.save(buf, "JPEG", quality=72)
            return buf.getvalue()
        except Exception as ex:
            log("screenshot with Pillow failed (%s) - trying Qt" % ex)
            return orig_shot()

    # ── game windows ──
    def _game_window(account, act):
        """act(hwnd) -> message. Returns (ok, message)."""
        _dpi()
        pids = set(g["client_pids"](account))
        if not pids:
            return False, "No running client for %s." % account
        wins = _windows_of(pids)
        if not wins:
            return False, "Couldn't find %s's game window." % account
        wins.sort(key=lambda w: "asheron" in w[1].lower(), reverse=True)
        return True, act(wins[0][0])

    def focus_client(account):
        return _game_window(account, lambda h: "Focused %s's game window." % account if _focus(h)
                            else "Asked Windows to focus %s's game window." % account)

    def unfocus_games():
        target = user32.FindWindowW(None, "MelkTank Launcher")
        what = "MelkTank Launcher"
        if not target:
            target, what = user32.FindWindowW("Progman", None) or user32.GetShellWindow(), "desktop"
        if not target:
            return False, "Couldn't find the launcher or the desktop to give the focus to."
        _focus(target)
        return True, "Focus moved to the %s." % what

    def press_game_key(account, key="b"):
        vk = _vk(key)
        if not vk:
            return False, "No key code for %s." % key
        wake_screen()

        def act(h):
            was = user32.GetForegroundWindow() == h
            if not was:
                _focus(h)
                time.sleep(1.2)   # the game starts reading the keyboard once it's active
            _send_input(_key_input(vk))
            time.sleep(0.15)
            _send_input(_key_input(vk, True))
            return "Pressed %s in %s's game window (%s)." % (key, account, "already focused" if was else "focused")
        return _game_window(account, act)

    def click_game_screen(account, sx, sy, shot_width=2400):
        def act(h):
            vl, vt = user32.GetSystemMetrics(76), user32.GetSystemMetrics(77)   # the whole desktop, as ImageGrab sees it
            vw = user32.GetSystemMetrics(78)
            k = vw / float(shot_width) if vw > shot_width else 1.0
            px, py = vl + int(round(sx * k)), vt + int(round(sy * k))
            if user32.GetForegroundWindow() != h:
                _focus(h)
                time.sleep(1.2)
            user32.SetCursorPos(px, py)
            time.sleep(0.3)
            _send_input(_mouse_input(0x0002))   # left down
            time.sleep(0.1)
            _send_input(_mouse_input(0x0004))   # left up
            return "Clicked %d,%d (screen %d,%d) in %s's game window." % (sx, sy, px, py, account)
        return _game_window(account, act)

    def move_client_window(account, left=0, top=0):
        def act(h):
            wa = _work_area(h)
            _place(h, wa.left + int(left), wa.top + int(top))
            _focus(h)
            return "Moved %s's game window to the top-left corner." % account
        return _game_window(account, act)

    def client_window_size(account):
        def act(h):
            r = RECT()
            user32.GetClientRect(h, ctypes.byref(r))
            return (r.right - r.left, r.bottom - r.top)
        ok, res = _game_window(account, act)
        return res if ok else None

    def move_client_corner(account, corner="top-left"):
        if corner != "bottom-right":
            return move_client_window(account)

        def act(h):
            wa = _work_area(h)
            _r, v = _frame(h)
            w, ht = v.right - v.left, v.bottom - v.top
            _place(h, wa.right - w, wa.bottom - ht)
            _focus(h)
            return "Moved %s's game window (%dx%d) to the bottom-right corner." % (account, w, ht)
        return _game_window(account, act)

    for name, fn in list(locals().items()):
        if callable(fn) and name in g and name not in ("log", "orig_shot"):
            g[name] = fn
    g["_game_window"] = _game_window
