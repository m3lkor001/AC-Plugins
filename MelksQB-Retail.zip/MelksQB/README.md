# MelksQuestTracker - setup & known assumptions

This is a first draft, written to match the patterns in your MelksLuminanceTracker
plugin, but **not compiled or tested** on my end (no Decal SDK / game client available
to me). Here's what you need to do to get it building, and what to double check.

## 1. Files you need to add from your lum tracker project

This project is missing the shared plumbing that MelksLuminanceTracker already has -
copy these from that project folder into this one:

- `Properties/AssemblyInfo.cs` - **then change the GUID inside it**. If you run both
  plugins in Decal at the same time, they cannot share a GUID.
- `VirindiViews/ViewSystemSelector.cs`
- `VirindiViews/Wrapper.cs`
- `VirindiViews/Wrapper_Decal.cs`
- `VirindiViews/Wrapper_MyHuds.cs`
- `VirindiViews/Wrapper_WireupHelper.cs`

## 2. Fix the HintPaths in MelksQuestTracker.csproj

Same as your lum tracker's `.csproj` - point `Decal.Adapter`, `Decal.Interop.Core`, and
`VirindiViewService` at wherever they actually live on your machine.

## 3. QuestDatabase.xml

Generated directly from your "Quest List" and "Qb List" tabs:

- **766** quests from Quest List
- **4,091 of 4,096** QB flags matched to a quest by name (case-insensitive match against
  Quest List's Quest Name column)
- The **5 leftover flags** and **53 Qb List "buckets"** that never matched a Quest List
  row by name (things like `Retired`, `UnObtainable`, blank quest names, and one
  capitalization mismatch I fixed by matching case-insensitively) got bundled into
  synthetic quests named `[REVIEW] <bucket name>` with `needsReview="true"`, so no data
  was silently dropped - you'll see them at the bottom of a name-sort and can merge/fix
  them by hand in the XML whenever you get to it.
- It's a loose file next to the compiled DLL (not embedded in the DLL), specifically so
  you can hand-edit it - add a `<Flag>` line, fix a link, adjust `possibleQb`, etc. -
  without recompiling. Format:

```xml
<!-- questGiver: optional, comma separated if several NPCs; shown on the Main tab detail panel -->
<Quest name="Harbinger" link="https://Leaftidewiki.com/Harbinger" startTown="" questGiver="Some NPC Name"
       repeatable="true" possibleQb="43" lockpickRequired="false" fellowRequired="false"
       minLevel="60" recLevel="100" timeMinutes="0" notes="">
  <Flag>SomeFlagName</Flag>
  <Flag>AnotherFlagName</Flag>
</Quest>
```

## 4. Things I could not verify and had to guess at - please test these first

- **Chat capture trigger**: I match each incoming chat line against the *exact* set of
  4,096 known flag names rather than trying to detect color. Test with `/mqt debug on`,
  then `/mqt collect`, and watch for `[debug] captured: ...` lines. If nothing gets
  captured, the most likely cause is the actual chat text isn't byte-for-byte identical
  to what's in Qb List (extra whitespace, a prefix character, etc.) - send me a captured
  debug-off vs debug-on comparison and I'll adjust the match logic (e.g. trim more
  aggressively, or match case-insensitively instead of exact).
- **Section header text**: I only know the `"Your incomplete quest bonus list:"` line for
  certain. I'm guessing there's a matching header for the completed section but I treat
  *any* line containing "quest bonus list" as a harmless section marker, so this should
  degrade safely either way - just flag it if the real header text does something odd.
- **`Enabled` and text-color properties**: set via reflection so a missing property
  quietly no-ops instead of breaking compilation. If your `IButton`/`IStaticText` really
  don't support them, the countdown text and `[pct%]` prefix are the safe fallback -
  everything still works, just without the greying-out/coloring.
- **Main tab list is paginated (15 rows), not a real grid.** If your VirindiViewService
  build has an actual multi-row list/grid control, tell me which one and I'll redo that
  page to use it instead - would look a lot better than button-rows-with-Prev/Next.
- **Clipboard**: `System.Windows.Forms.Clipboard` needs an STA thread; I spin up a
  short-lived one in `Util.SetClipboardText`. This is a standard pattern but worth
  confirming it actually works in your Decal host process.

## 5. Commands

- `/mqt collect` - same as clicking Collect QB List (60s cooldown either way)
- `/mqt copy` - same as clicking Copy to Clipboard
- `/mqt reload` - reload QuestDatabase.xml without restarting the plugin
- `/mqt reset confirm` - wipes this character's saved progress
- `/mqt debug [on/off]`
- `/mqt help`

## 6. What's NOT done yet

- I have not merged in anything from other plugins you mentioned - send those over and
  I'll fold in whatever's relevant.
- No fellowship-wide/shared-account view - it's per-character, matching your existing
  `characterKey` pattern (`Server-CharacterName`). Say the word if you want a
  cross-character rollup on the Main tab.
