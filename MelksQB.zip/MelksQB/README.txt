MelksQB quest tracker for Asheron's Call (InfiniteLeaftide) - quest flags, walkthroughs, kill tasks, dungeon maps
============================================================

What's in here
--------------
  MelksQB\MelksQuestTracker.dll
  MelksQB\QuestDatabase.xml     every quest, its QB flags and its walkthrough
  MelksQB\Maps\                 dungeon maps (the map window) - in MelksQB_Maps1.zip and MelksQB_Maps2.zip:
                                extract both the same way, into the Decal Plugins folder

You need first
--------------
  - Decal
  - UtilityBelt (the windows are drawn with UtilityBelt's window system - it has to be installed and on)

Install
-------
  1. Put this zip in your Decal Plugins folder (where your other plugins live, e.g. C:\Games\Decal Plugins)
     and "Extract here".
  2. Open Decal (the Decal Agent - its tray icon), click Add, and pick
        MelksQB\MelksQuestTracker.dll
     Make sure it's ticked (enabled).
  3. Start the game. Your settings are saved next to the dll the first time you change something.

Updating later
--------------
  Extract a newer zip over the top - your settings and logs aren't in the zip, so they're kept.
  Close the game first - it only loads at start-up.
