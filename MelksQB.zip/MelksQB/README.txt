MelksQB / MelksQuestTracker (Nov 12 2026) - quest tracker, kill tasks, travel planner, world and dungeon maps.

Install
1. Unzip so this folder is  C:\Games\Decal Plugins\MelksQB.
2. Decal Agent > Add > pick MelksQuestTracker.dll, and tick it. Needs UtilityBelt (UtilityBelt.Service).
3. MelksQuestTracker.dll is a loader for MelksQuestTrackerCore.dll (a newer core can be dropped in while playing).

QuestDatabase.xml is the quest list; Travel\ holds the travel locations and sea map.
The ACMaps dungeon maps (Maps\, about 60 MB) aren't in this zip - copy that folder over separately if wanted.
