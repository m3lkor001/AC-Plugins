MelksQB quest tracker for Asheron's Call (InfiniteLeaftide) - quest flags, walkthroughs, kill tasks
============================================================

What's in here
--------------
  MelksQB\MelksQuestTracker.dll       the plugin Decal loads (a small loader)
  MelksQB\MelksQuestTrackerCore.dll   everything else (the loader loads it - keep the two together)
  MelksQB\QuestDatabase.xml           every quest, its QB flags and its walkthrough

  (The dungeon maps for the map window aren't in this zip. If you have them already, keep your MelksQB\Maps folder.)

You need first
--------------
  - Decal
  - UtilityBelt (the windows are drawn with UtilityBelt's window system - it has to be installed and on)

Install
-------
  1. Put this zip in your Decal Plugins folder (where your other plugins live, e.g. C:\Games\Decal Plugins)
     and "Extract here".
  2. Open Decal (the Decal Agent - its tray icon), click Add, and pick
        MelksQB\MelksQuestTracker.dll  (NOT MelksQuestTrackerCore.dll)
     Make sure it's ticked (enabled).
  3. Start the game. Your settings are saved next to the dll the first time you change something.

Updating later
--------------
  Extract a newer zip over the top - your settings and logs aren't in the zip, so they're kept.
  It reloads itself when MelksQuestTrackerCore.dll is replaced, so you can update it with the game running
  (/mqt hotreload does it by hand). A new MelksQuestTracker.dll (the loader) needs a game restart.
